"""
Unit tests for LangChain memory adapters.

Test coverage includes:
- SynapseMemory class for long-term agent memory
- SynapseChatHistory class for chat message persistence
- Memory variable loading and context injection
- Message persistence and retrieval

Note: Tests are skipped if langchain-core is not installed.
"""

import uuid
from unittest.mock import AsyncMock, patch

import pytest

try:
    from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage

    langchain_available = True
except ImportError:
    langchain_available = False


if langchain_available:
    from synapse_layer.langchain_memory import SynapseChatHistory, SynapseMemory
    from synapse_layer.a2a_client import TaskResult
    from .conftest import TEST_API_KEY, TEST_USER_ID, make_task_result


# Skip all tests in this module if langchain-core is not available
pytestmark = pytest.mark.skipif(not langchain_available, reason="langchain-core not installed")


# ============================================================================
# TestSynapseMemory - Long-term Agent Memory (7 tests)
# ============================================================================


class TestSynapseMemory:
    """Test SynapseMemory class for long-term agent memory."""

    def test_synapse_memory_initialization(self):
        """Test SynapseMemory initialization with required parameters."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )
        assert memory.api_key == TEST_API_KEY
        assert memory.user_id == TEST_USER_ID
        assert memory.memory_key == "history"
        assert memory.recall_limit == 10

    def test_synapse_memory_with_custom_memory_key(self):
        """Test SynapseMemory with custom memory key."""
        custom_key = "custom_history"
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
            memory_key=custom_key,
        )
        assert memory.memory_key == custom_key

    def test_synapse_memory_with_custom_recall_limit(self):
        """Test SynapseMemory with custom recall limit."""
        custom_limit = 20
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
            recall_limit=custom_limit,
        )
        assert memory.recall_limit == custom_limit

    def test_synapse_memory_variables_property(self):
        """Test memory_variables property returns memory key."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )
        variables = memory.memory_variables
        assert isinstance(variables, list)
        assert "history" in variables

    def test_synapse_memory_with_custom_input_key(self):
        """Test SynapseMemory with custom input key."""
        custom_input_key = "user_input"
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
            input_key=custom_input_key,
        )
        assert memory.input_key == custom_input_key

    @pytest.mark.asyncio
    async def test_load_memory_variables(self):
        """Test loading memory variables with mock recall."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        # Mock the _recall method
        mock_memories = [
            "Memory 1: User prefers dark mode",
            "Memory 2: User has API access",
        ]

        with patch.object(SynapseMemory, "_recall") as mock_recall:
            mock_recall.return_value = mock_memories

            inputs = {"query": "user preferences"}
            result = await memory.load_memory_variables(inputs)

            assert isinstance(result, dict)
            assert "history" in result

    @pytest.mark.asyncio
    async def test_save_context_stores_memory(self):
        """Test save_context stores input/output pairs."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        with patch.object(SynapseMemory, "_store") as mock_store:
            inputs = {"input": "Hello"}
            outputs = {"output": "Hi there!"}

            await memory.save_context(inputs, outputs)

            # Verify _store was called
            assert mock_store.called


# ============================================================================
# TestSynapseChatHistory - Chat Message Persistence (6 tests)
# ============================================================================


class TestSynapseChatHistory:
    """Test SynapseChatHistory class for chat message persistence."""

    def test_chat_history_initialization(self):
        """Test SynapseChatHistory initialization."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )
        assert history.api_key == TEST_API_KEY
        assert history.user_id == TEST_USER_ID

    def test_chat_history_with_custom_recall_limit(self):
        """Test SynapseChatHistory with custom recall limit."""
        custom_limit = 15
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
            recall_limit=custom_limit,
        )
        assert history.recall_limit == custom_limit

    def test_messages_property_empty(self):
        """Test messages property when empty."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )
        messages = history.messages
        assert isinstance(messages, list)

    @pytest.mark.asyncio
    async def test_add_human_message(self):
        """Test adding a human message."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        message = HumanMessage(content="Hello, assistant!")

        with patch.object(SynapseChatHistory, "_persist") as mock_persist:
            await history.add_message(message)
            assert mock_persist.called

    @pytest.mark.asyncio
    async def test_add_ai_message(self):
        """Test adding an AI message."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        message = AIMessage(content="Hello, user!")

        with patch.object(SynapseChatHistory, "_persist") as mock_persist:
            await history.add_message(message)
            assert mock_persist.called

    def test_clear_messages(self):
        """Test clearing messages."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        history.clear()
        assert history.messages == []


# ============================================================================
# TestMemoryIntegration - Integration Tests (4 tests)
# ============================================================================


class TestMemoryIntegration:
    """Test integration scenarios with real-like workflows."""

    @pytest.mark.asyncio
    async def test_memory_workflow_store_and_recall(self):
        """Test typical workflow: store then recall."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        # Mock the underlying store and recall operations
        with patch.object(SynapseMemory, "_store") as mock_store:
            with patch.object(SynapseMemory, "_recall") as mock_recall:
                mock_recall.return_value = [
                    "User preference: dark mode",
                    "User language: English",
                ]

                # Save context (store)
                await memory.save_context(
                    {"input": "What's your preference?"},
                    {"output": "Dark mode"},
                )

                # Load variables (recall)
                variables = await memory.load_memory_variables(
                    {"query": "preferences"}
                )

                assert variables is not None
                assert "history" in variables

    @pytest.mark.asyncio
    async def test_chat_history_with_multiple_messages(self):
        """Test chat history with multiple sequential messages."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        messages = [
            HumanMessage(content="First message"),
            AIMessage(content="First response"),
            HumanMessage(content="Second message"),
            AIMessage(content="Second response"),
        ]

        with patch.object(SynapseChatHistory, "_persist"):
            for msg in messages:
                await history.add_message(msg)

            # Verify messages were processed
            # (Note: actual persistence happens in _persist)

    @pytest.mark.asyncio
    async def test_memory_with_tq_scoring(self):
        """Test memory recall with Trust Quotient scoring."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        # Mock recall with TQ scores
        mock_memories_with_tq = [
            "Memory 1 (TQ: 0.85): Important user preference",
            "Memory 2 (TQ: 0.72): Secondary information",
            "Memory 3 (TQ: 0.65): Older observation",
        ]

        with patch.object(SynapseMemory, "_recall") as mock_recall:
            mock_recall.return_value = mock_memories_with_tq

            variables = await memory.load_memory_variables(
                {"query": "user information"}
            )

            assert variables is not None
            # Verify TQ-weighted ordering
            recalled = variables.get("history", [])
            assert len(recalled) > 0

    def test_memory_clear_idempotent(self):
        """Test that clear is idempotent."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        # First clear
        memory.clear()
        assert memory.messages == []

        # Second clear should not raise
        memory.clear()
        assert memory.messages == []


# ============================================================================
# TestMemoryWithDifferentSources - Source Type Handling (3 tests)
# ============================================================================


class TestMemoryWithDifferentSources:
    """Test memory handling with different message sources."""

    @pytest.mark.asyncio
    async def test_system_message_persistence(self):
        """Test persistence of system messages."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        system_msg = SystemMessage(content="You are a helpful assistant.")

        with patch.object(SynapseChatHistory, "_persist") as mock_persist:
            await history.add_message(system_msg)
            assert mock_persist.called

    @pytest.mark.asyncio
    async def test_human_ai_message_sequence(self):
        """Test alternating human and AI messages."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        human_msg = HumanMessage(content="Hello")
        ai_msg = AIMessage(content="Hi there!")

        with patch.object(SynapseChatHistory, "_persist"):
            await history.add_message(human_msg)
            await history.add_message(ai_msg)

            # Both messages should be processed without error

    @pytest.mark.asyncio
    async def test_memory_with_empty_content(self):
        """Test handling messages with empty content."""
        history = SynapseChatHistory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        empty_msg = HumanMessage(content="")

        with patch.object(SynapseChatHistory, "_persist") as mock_persist:
            await history.add_message(empty_msg)
            # Should still attempt to persist
            assert mock_persist.called


# ============================================================================
# TestEdgeCasesMemory - Edge Cases for Memory (2 tests)
# ============================================================================


class TestEdgeCasesMemory:
    """Test edge cases in memory handling."""

    @pytest.mark.asyncio
    async def test_memory_with_very_long_content(self):
        """Test memory with very long content."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        long_content = "x" * 10000  # 10KB of content

        with patch.object(SynapseMemory, "_store") as mock_store:
            await memory.save_context(
                {"input": long_content},
                {"output": "processed"},
            )
            assert mock_store.called

    def test_memory_with_special_characters(self):
        """Test memory handling with special characters."""
        memory = SynapseMemory(
            api_key=TEST_API_KEY,
            user_id=TEST_USER_ID,
        )

        special_text = "Hello! @#$%^&*() 你好 🚀 Ñoño"

        # Should initialize without error
        assert memory is not None
