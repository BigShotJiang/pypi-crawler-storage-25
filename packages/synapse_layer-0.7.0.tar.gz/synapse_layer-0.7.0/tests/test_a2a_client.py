"""
Unit tests for SynapseA2AClient.

Test coverage includes:
- Client initialization and configuration
- Task submission and response parsing
- Convenience wrapper methods
- TaskResult and TaskState enums
- Error handling and edge cases
- Async context manager functionality
"""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from synapse_layer.a2a_client import (
    DEFAULT_BASE_URL,
    VALID_SKILL_IDS,
    SynapseA2AClient,
    TaskResult,
    TaskState,
)

from .conftest import (
    TEST_API_KEY,
    TEST_BASE_URL,
    TEST_USER_ID,
    make_rpc_error,
    make_rpc_success,
    make_task_result,
)


# ============================================================================
# TestSynapseA2AClientInit - Client Initialization (5 tests)
# ============================================================================


class TestSynapseA2AClientInit:
    """Test client initialization and configuration."""

    def test_client_init_with_defaults(self, api_key):
        """Test client initialization with default URL and timeout."""
        client = SynapseA2AClient(api_key=api_key)
        assert client.api_key == api_key
        assert client.base_url == DEFAULT_BASE_URL
        assert client.timeout == 30

    def test_client_init_with_custom_url(self, api_key):
        """Test client initialization with custom base URL."""
        custom_url = "https://custom.example.com"
        client = SynapseA2AClient(api_key=api_key, base_url=custom_url)
        assert client.api_key == api_key
        assert client.base_url == custom_url

    def test_client_init_with_custom_timeout(self, api_key):
        """Test client initialization with custom timeout."""
        client = SynapseA2AClient(api_key=api_key, timeout=60)
        assert client.timeout == 60

    def test_client_init_preserves_api_key(self, api_key):
        """Test that API key is properly stored."""
        client = SynapseA2AClient(api_key=api_key)
        assert client.api_key == api_key
        assert isinstance(client.api_key, str)

    def test_client_init_with_all_parameters(self, api_key):
        """Test client initialization with all parameters."""
        custom_url = "https://custom.example.com"
        custom_timeout = 45
        client = SynapseA2AClient(
            api_key=api_key,
            base_url=custom_url,
            timeout=custom_timeout,
        )
        assert client.api_key == api_key
        assert client.base_url == custom_url
        assert client.timeout == custom_timeout


# ============================================================================
# TestSendTask - Task Submission and Response Handling (6 tests)
# ============================================================================


class TestSendTask:
    """Test send_task method and task submission."""

    def test_send_task_with_invalid_skill(self, api_key, user_id):
        """Test sending a task with an unsupported skill."""
        invalid_skill = "invalid_skill_xyz"
        params = {"user_id": user_id}

        client = SynapseA2AClient(api_key=api_key)
        with pytest.raises(ValueError, match="Unknown skill"):
            # Need to be in async context first
            import asyncio

            async def run_test():
                async with client as c:
                    await c.send_task(invalid_skill, params)

            asyncio.run(run_test())

    @pytest.mark.asyncio
    async def test_send_task_requires_valid_skill(self, api_key, user_id):
        """Test that send_task rejects invalid skills."""
        async with SynapseA2AClient(api_key=api_key) as client:
            with pytest.raises(ValueError, match="Unknown skill"):
                await client.send_task("invalid_skill", {"user_id": user_id})

    @pytest.mark.asyncio
    async def test_send_task_formats_request(self, api_key, user_id):
        """Test that send_task formats request properly."""
        skill_id = "store_memory"
        params = {
            "user_id": user_id,
            "content": "Test memory",
            "source_type": "inference",
            "confidence": 0.85,
        }

        async with SynapseA2AClient(api_key=api_key) as client:
            # Patch the session.post to verify request formatting
            with patch.object(client.session, "post") as mock_post:
                mock_response = AsyncMock()
                mock_response.json = AsyncMock(
                    return_value={
                        "id": 1,
                        "result": {"memory_id": str(uuid.uuid4())},
                    }
                )
                mock_post.return_value.__aenter__.return_value = mock_response

                result = await client.send_task(skill_id, params)

                # Verify the request was made
                assert mock_post.called
                assert result.status == TaskState.COMPLETED

    def test_valid_skill_ids_available(self):
        """Test that VALID_SKILL_IDS contains expected skills."""
        expected_skills = [
            "store_memory",
            "recall_memory",
            "create_handover",
            "resolve_conflict",
            "forget_memory",
        ]
        for skill in expected_skills:
            assert skill in VALID_SKILL_IDS

    def test_all_valid_skills_are_strings(self):
        """Test that all VALID_SKILL_IDS are strings."""
        for skill_id in VALID_SKILL_IDS:
            assert isinstance(skill_id, str)

    def test_valid_skill_ids_contain_store_memory(self):
        """Test that store_memory is in VALID_SKILL_IDS."""
        assert "store_memory" in VALID_SKILL_IDS

    def test_valid_skill_ids_contain_recall_memory(self):
        """Test that recall_memory is in VALID_SKILL_IDS."""
        assert "recall_memory" in VALID_SKILL_IDS


# ============================================================================
# TestParseResponse - RPC Response Parsing (4 tests)
# ============================================================================


class TestParseResponse:
    """Test response parsing logic."""

    def test_parse_success_response(self, task_id):
        """Test parsing a successful RPC response."""
        response = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"memory_id": str(uuid.uuid4())},
        }
        result = SynapseA2AClient._parse_response(response, 1)

        assert result.task_id == "1"
        assert result.status == TaskState.COMPLETED
        assert result.output == response["result"]
        assert result.error is None

    def test_parse_error_response(self):
        """Test parsing an RPC error response."""
        response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32600,
                "message": "Invalid Request",
            },
        }
        result = SynapseA2AClient._parse_response(response, 1)

        assert result.status == TaskState.FAILED
        assert "Invalid Request" in result.error

    def test_parse_response_with_missing_result(self):
        """Test parsing response without result field."""
        response = {"jsonrpc": "2.0", "id": 1}
        result = SynapseA2AClient._parse_response(response, 1)

        assert result.status == TaskState.FAILED
        assert result.error is not None

    def test_parse_response_with_error_field(self):
        """Test parsing response with error field."""
        response = {
            "jsonrpc": "2.0",
            "id": 1,
            "error": {
                "code": -32000,
                "message": "Database error",
            },
        }
        result = SynapseA2AClient._parse_response(response, 1)
        assert result.status == TaskState.FAILED
        assert "Database error" in result.error


# ============================================================================
# TestConvenienceWrappers - High-level Methods (5+ tests)
# ============================================================================


class TestConvenienceWrappers:
    """Test convenience wrapper methods."""

    @pytest.mark.asyncio
    async def test_store_memory_wrapper(self, api_key, user_id, task_id):
        """Test store_memory convenience method."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=task_id,
                status=TaskState.COMPLETED,
                output={"memory_id": str(uuid.uuid4())},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.store_memory(
                    user_id=user_id,
                    content="Test memory",
                    source_type="inference",
                    confidence=0.9,
                )

            assert result.task_id == task_id
            assert result.status == TaskState.COMPLETED
            mock_send.assert_called_once()

    @pytest.mark.asyncio
    async def test_recall_memory_wrapper(self, api_key, user_id, task_id):
        """Test recall_memory convenience method."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=task_id,
                status=TaskState.COMPLETED,
                output={"memories": []},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.recall_memory(
                    user_id=user_id,
                    query="test query",
                    limit=5,
                )

            assert result.task_id == task_id
            mock_send.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_handover_wrapper(self, api_key, user_id, task_id):
        """Test create_handover convenience method."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=task_id,
                status=TaskState.COMPLETED,
                output={"handover_package": "base64data"},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.create_handover(
                    user_id=user_id,
                    target_model="gpt-4o",
                    summary="Test handover",
                )

            assert result.task_id == task_id
            mock_send.assert_called_once()

    @pytest.mark.asyncio
    async def test_resolve_conflict_wrapper(self, api_key, user_id, task_id):
        """Test resolve_conflict convenience method."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=task_id,
                status=TaskState.COMPLETED,
                output={"resolved": True},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.resolve_conflict(
                    user_id=user_id,
                    memory_id=str(uuid.uuid4()),
                )

            assert result.task_id == task_id
            mock_send.assert_called_once()

    @pytest.mark.asyncio
    async def test_forget_memory_wrapper(self, api_key, user_id, task_id):
        """Test forget_memory convenience method."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=task_id,
                status=TaskState.COMPLETED,
                output={"deleted": True},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.forget_memory(
                    user_id=user_id,
                    memory_id=str(uuid.uuid4()),
                )

            assert result.task_id == task_id
            mock_send.assert_called_once()


# ============================================================================
# TestTaskResult - TaskResult Dataclass (8 tests)
# ============================================================================


class TestTaskResult:
    """Test TaskResult dataclass."""

    def test_task_result_creation(self, task_id):
        """Test creating a TaskResult instance."""
        result = TaskResult(
            task_id=task_id,
            status="completed",
            output={"test": "data"},
            error=None,
        )
        assert result.task_id == task_id
        assert result.status == "completed"

    def test_task_result_with_error(self, task_id):
        """Test TaskResult with error state."""
        error_msg = "Test error"
        result = TaskResult(
            task_id=task_id,
            status="failed",
            output=None,
            error=error_msg,
        )
        assert result.status == "failed"
        assert result.error == error_msg

    def test_task_result_string_representation(self, task_id):
        """Test TaskResult string representation."""
        result = TaskResult(
            task_id=task_id,
            status="completed",
            output=None,
            error=None,
        )
        result_str = str(result)
        assert task_id in result_str
        assert "completed" in result_str

    def test_task_result_with_empty_output(self, task_id):
        """Test TaskResult with empty output dict."""
        result = TaskResult(
            task_id=task_id,
            status="completed",
            output={},
            error=None,
        )
        assert result.output == {}

    def test_task_result_with_complex_output(self, task_id):
        """Test TaskResult with complex nested output."""
        complex_output = {
            "memories": [
                {"id": "1", "content": "test"},
                {"id": "2", "content": "test2"},
            ],
            "metadata": {"total": 2},
        }
        result = TaskResult(
            task_id=task_id,
            status="completed",
            output=complex_output,
            error=None,
        )
        assert result.output == complex_output
        assert len(result.output["memories"]) == 2

    def test_task_result_json_serialization(self, task_id):
        """Test TaskResult can be converted to dict."""
        result = TaskResult(
            task_id=task_id,
            status="completed",
            output={"key": "value"},
            error=None,
        )
        # Dataclass can be converted to dict
        result_dict = {
            "task_id": result.task_id,
            "status": result.status,
            "output": result.output,
            "error": result.error,
        }
        assert result_dict["task_id"] == task_id

    def test_task_result_equality(self, task_id):
        """Test TaskResult equality comparison."""
        result1 = TaskResult(task_id=task_id, status=TaskState.COMPLETED, output=None, error=None)
        result2 = TaskResult(task_id=task_id, status=TaskState.COMPLETED, output=None, error=None)
        assert result1 == result2


# ============================================================================
# TestTaskState - TaskState Enum (2 tests)
# ============================================================================


class TestTaskState:
    """Test TaskState enum."""

    def test_task_state_values(self):
        """Test TaskState enum contains all required states."""
        assert hasattr(TaskState, "SUBMITTED")
        assert hasattr(TaskState, "WORKING")
        assert hasattr(TaskState, "COMPLETED")
        assert hasattr(TaskState, "FAILED")
        assert hasattr(TaskState, "CANCELLED")

    def test_task_state_string_representation(self):
        """Test TaskState enum string representation."""
        assert str(TaskState.COMPLETED) == "TaskState.COMPLETED"


# ============================================================================
# TestAsyncContextManager - Context Manager Functionality (3 tests)
# ============================================================================


class TestAsyncContextManager:
    """Test async context manager functionality."""

    @pytest.mark.asyncio
    async def test_client_context_manager(self, api_key):
        """Test client can be used as async context manager."""
        async with SynapseA2AClient(api_key=api_key) as client:
            assert client is not None
            assert client.api_key == api_key

    @pytest.mark.asyncio
    async def test_context_manager_session_creation(self, api_key):
        """Test context manager creates session."""
        async with SynapseA2AClient(api_key=api_key) as client:
            # Session should be created
            assert client.session is not None

    @pytest.mark.asyncio
    async def test_context_manager_handles_exceptions(self, api_key):
        """Test context manager handles exceptions properly."""
        with pytest.raises(RuntimeError):
            async with SynapseA2AClient(api_key=api_key):
                raise RuntimeError("Test error")


# ============================================================================
# TestEdgeCases - Edge Cases and Error Handling (6+ tests)
# ============================================================================


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_client_with_empty_api_key(self):
        """Test client initialization with empty API key."""
        # Should not raise, but may fail on actual request
        client = SynapseA2AClient(api_key="")
        assert client.api_key == ""

    def test_parse_response_with_malformed_json(self):
        """Test parsing malformed JSON response."""
        # Should handle gracefully with invalid response
        response = {"id": 1}  # Missing both result and error
        result = SynapseA2AClient._parse_response(response, 1)
        assert result.status == TaskState.FAILED

    @pytest.mark.asyncio
    async def test_store_memory_with_zero_confidence(self, api_key, user_id):
        """Test store_memory with confidence = 0."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=str(uuid.uuid4()),
                status=TaskState.COMPLETED,
                output={},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.store_memory(
                    user_id=user_id,
                    content="test",
                    source_type="user_input",
                    confidence=0.0,
                )
                assert result.status == TaskState.COMPLETED

    @pytest.mark.asyncio
    async def test_store_memory_with_max_confidence(self, api_key, user_id):
        """Test store_memory with confidence = 1.0."""
        with patch.object(SynapseA2AClient, "send_task") as mock_send:
            mock_send.return_value = TaskResult(
                task_id=str(uuid.uuid4()),
                status=TaskState.COMPLETED,
                output={},
            )

            async with SynapseA2AClient(api_key=api_key) as client:
                result = await client.store_memory(
                    user_id=user_id,
                    content="test",
                    source_type="user_input",
                    confidence=1.0,
                )
                assert result.status == TaskState.COMPLETED

    @pytest.mark.asyncio
    async def test_client_not_in_context(self, api_key, user_id):
        """Test that client requires async context."""
        client = SynapseA2AClient(api_key=api_key)
        with pytest.raises(RuntimeError):
            await client.send_task("store_memory", {"user_id": user_id})


# ============================================================================
# TestDefaultConstants - Default Values and Constants (2 tests)
# ============================================================================


class TestDefaultConstants:
    """Test default values and constants."""

    def test_default_base_url_is_set(self):
        """Test that DEFAULT_BASE_URL is properly configured."""
        assert DEFAULT_BASE_URL is not None
        assert isinstance(DEFAULT_BASE_URL, str)
        assert len(DEFAULT_BASE_URL) > 0
        assert DEFAULT_BASE_URL.startswith("https://")

    def test_valid_skill_ids_is_set(self):
        """Test that VALID_SKILL_IDS is a set with expected skills."""
        assert isinstance(VALID_SKILL_IDS, set)
        assert len(VALID_SKILL_IDS) == 5
        expected = {"store_memory", "recall_memory", "create_handover", "resolve_conflict", "forget_memory"}
        assert VALID_SKILL_IDS == expected
