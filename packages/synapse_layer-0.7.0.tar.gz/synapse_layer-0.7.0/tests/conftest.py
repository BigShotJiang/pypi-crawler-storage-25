"""
Shared test fixtures and helper functions for Synapse Layer SDK tests.

Provides:
- Constants for testing (API keys, user IDs, skill IDs)
- Helper functions for RPC responses and task results
- pytest fixtures for common test parameters
"""

import uuid
from typing import Any, Dict

import pytest


# ============================================================================
# Constants
# ============================================================================

TEST_API_KEY = "test-api-key-" + str(uuid.uuid4())[:8]
TEST_USER_ID = str(uuid.uuid4())
TEST_BASE_URL = "https://rbeycxzizrrdmxpilepc.supabase.co/functions/v1"

VALID_SKILL_IDS = [
    "store_memory",
    "recall_memory",
    "create_handover",
    "resolve_conflict",
    "forget_memory",
]

SOURCE_TYPES = ["user_input", "api_response", "inference", "handover", "system"]


# ============================================================================
# Helper Functions for RPC Responses
# ============================================================================


def make_rpc_success(task_id: str, output: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create a successful JSON-RPC 2.0 response.

    Args:
        task_id: Task identifier
        output: Response output data

    Returns:
        JSON-RPC success response
    """
    return {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {
            "task_id": task_id,
            "status": "completed",
            "output": output,
            "error": None,
        },
    }


def make_rpc_error(error_code: int, error_message: str) -> Dict[str, Any]:
    """
    Create a JSON-RPC 2.0 error response.

    Args:
        error_code: RPC error code
        error_message: Error message

    Returns:
        JSON-RPC error response
    """
    return {
        "jsonrpc": "2.0",
        "id": 1,
        "error": {
            "code": error_code,
            "message": error_message,
        },
    }


def make_task_result(
    task_id: str,
    status: str = "completed",
    output: Dict[str, Any] = None,
    error: str = None,
) -> Dict[str, Any]:
    """
    Create a task result object.

    Args:
        task_id: Task identifier
        status: Task status (submitted, working, completed, failed, cancelled)
        output: Task output (if successful)
        error: Error message (if failed)

    Returns:
        Task result dictionary
    """
    return {
        "task_id": task_id,
        "status": status,
        "output": output or {},
        "error": error,
    }


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def api_key():
    """Provide a test API key."""
    return TEST_API_KEY


@pytest.fixture
def user_id():
    """Provide a test user ID."""
    return TEST_USER_ID


@pytest.fixture
def task_id():
    """Provide a test task ID."""
    return str(uuid.uuid4())


@pytest.fixture
def base_url():
    """Provide a test base URL."""
    return TEST_BASE_URL


@pytest.fixture
def success_task(task_id):
    """Provide a successful task result."""
    return {
        "task_id": task_id,
        "status": "completed",
        "output": {"memory_id": str(uuid.uuid4()), "stored_at": "2025-01-01T00:00:00Z"},
        "error": None,
    }


@pytest.fixture
def failed_task(task_id):
    """Provide a failed task result."""
    return {
        "task_id": task_id,
        "status": "failed",
        "output": None,
        "error": "Authentication failed",
    }


@pytest.fixture
def rpc_success_response(task_id):
    """Provide a successful RPC response."""
    return make_rpc_success(
        task_id,
        {"memory_id": str(uuid.uuid4()), "stored_at": "2025-01-01T00:00:00Z"},
    )


@pytest.fixture
def rpc_error_response():
    """Provide an error RPC response."""
    return make_rpc_error(-32600, "Invalid Request")


@pytest.fixture
def memory_content():
    """Provide sample memory content."""
    return "Important context: User preference is dark mode. Last interaction: 2025-01-01."


@pytest.fixture
def memory_query():
    """Provide a sample memory query."""
    return "user preferences for dark mode"


@pytest.fixture
def recall_result():
    """Provide a sample recall result."""
    return {
        "memories": [
            {
                "id": str(uuid.uuid4()),
                "content": "User prefers dark mode",
                "source_type": "user_input",
                "tq_score": 0.85,
                "confidence": 0.9,
                "recency": 0.8,
                "usage": 3,
                "created_at": "2025-01-01T00:00:00Z",
                "updated_at": "2025-01-01T12:00:00Z",
            },
            {
                "id": str(uuid.uuid4()),
                "content": "User has accepted cookies",
                "source_type": "api_response",
                "tq_score": 0.72,
                "confidence": 0.85,
                "recency": 0.7,
                "usage": 2,
                "created_at": "2024-12-25T00:00:00Z",
                "updated_at": "2024-12-25T12:00:00Z",
            },
        ],
        "total": 2,
    }


@pytest.fixture
def handover_context():
    """Provide sample handover context."""
    return {
        "user_id": TEST_USER_ID,
        "target_model": "claude-3.5-sonnet",
        "summary": "User context: Dark mode preference, technical background, interested in AI.",
        "signature": "hmac_sha256_signature_here",
        "timestamp": "2025-01-01T00:00:00Z",
    }


@pytest.fixture
def memory_input_params(user_id, memory_content):
    """Provide memory input parameters."""
    return {
        "user_id": user_id,
        "content": memory_content,
        "source_type": "inference",
        "confidence": 0.85,
    }


@pytest.fixture
def recall_input_params(user_id, memory_query):
    """Provide recall input parameters."""
    return {
        "user_id": user_id,
        "query": memory_query,
        "limit": 5,
    }


@pytest.fixture
def handover_input_params(user_id):
    """Provide handover input parameters."""
    return {
        "user_id": user_id,
        "target_model": "gpt-4o",
        "summary": "Important user context for handover",
    }
