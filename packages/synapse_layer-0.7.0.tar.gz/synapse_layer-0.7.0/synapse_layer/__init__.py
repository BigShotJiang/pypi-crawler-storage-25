"""
Synapse Layer - Universal Memory Layer for AI Agents

A persistent, private, model-agnostic, open-source memory solution for AI agents.
Provides seamless integration with LangChain, CrewAI, and custom Agent-to-Agent (A2A) protocols.

Modules:
    a2a_client: JSON-RPC 2.0 client for Agent-to-Agent communication
    langchain_memory: LangChain adapters (SynapseMemory, SynapseChatHistory)
    crewai_tools: CrewAI tools (SynapseStoreMemoryTool, SynapseRecallMemoryTool, SynapseHandoverTool)

Key Features:
    - Persistent encrypted memory storage
    - Trust Quotient (TQ) weighting: TQ = (confidence_score * 0.4) + (recency_score * 0.3) + (usage_normalized * 0.3)
    - Semantic search with pgvector HNSW
    - Neural Handover with HMAC-SHA256 signatures
    - GDPR/LGPD compliance (soft-delete with audit trail)
    - Zero-Knowledge Context preservation

Author: Ismael Marchi
License: Apache 2.0
Version: 0.7.0

Example:
    >>> from synapse_layer import SynapseA2AClient
    >>> async with SynapseA2AClient(api_key="your-key") as client:
    ...     result = await client.store_memory(
    ...         user_id="user-123",
    ...         content="Important context",
    ...         source_type="inference",
    ...         confidence=0.9
    ...     )
    ...     print(result)
"""

__version__ = "0.7.0"
__author__ = "Ismael Marchi"
__license__ = "Apache-2.0"
__all__ = [
    # Core client
    "SynapseA2AClient",
    # Data types
    "TaskResult",
    "TaskState",
    # Constants
    "DEFAULT_BASE_URL",
    "VALID_SKILL_IDS",
    # Version
    "__version__",
    "__author__",
    "__license__",
]

# Import core components
from .a2a_client import (
    DEFAULT_BASE_URL,
    VALID_SKILL_IDS,
    SynapseA2AClient,
    TaskResult,
    TaskState,
)

# Try to import optional adapters
try:
    from .langchain_memory import SynapseMemory, SynapseChatHistory

    __all__.extend(["SynapseMemory", "SynapseChatHistory"])
except ImportError:
    pass

try:
    from .crewai_tools import (
        SynapseHandoverTool,
        SynapseRecallMemoryTool,
        SynapseStoreMemoryTool,
        HandoverInput,
        RecallMemoryInput,
        StoreMemoryInput,
    )

    __all__.extend(
        [
            "SynapseStoreMemoryTool",
            "SynapseRecallMemoryTool",
            "SynapseHandoverTool",
            "StoreMemoryInput",
            "RecallMemoryInput",
            "HandoverInput",
        ]
    )
except ImportError:
    pass
