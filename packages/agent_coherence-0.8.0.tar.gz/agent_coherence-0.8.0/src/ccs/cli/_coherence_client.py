# Copyright (c) 2026 Arbiter contributors.
# The Coherence Protocol for AI Agents

"""Shared HTTP client helpers for the four agent-coherence-* console scripts.

The coordinator binds to 127.0.0.1 with shared-secret Bearer auth
(KTD-12). Each console script needs:

1. Resolve the workspace root.
2. Read the port from ``<root>/.coherence/server.pid``.
3. Read the bearer secret from ``<root>/.coherence/hook.secret``.
4. Make an authenticated request with a short timeout.

Failures degrade gracefully — these scripts run interactively and should
print a one-line human message + exit 1 rather than dump a stack trace.
"""

from __future__ import annotations

import json
import logging
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ccs.adapters.claude_code.lifecycle import read_port_from_file as _read_port_from_file

logger = logging.getLogger(__name__)

#: HTTP timeout for CLI requests. The coordinator's per-request watchdog is
#: 4s; we add headroom for connection setup. CLI users are interactive so a
#: 6s ceiling is preferable to retrying.
CLI_HTTP_TIMEOUT_SEC = 6.0


def err(message: str) -> None:
    """Write a diagnostic / error line to stderr.

    P2 ce-review fix #15 (cli-readiness): error output must go to stderr so
    agents composing workflows can read machine-parseable data from stdout
    (e.g., ``port=$(agent-coherence-coordinator)``) without prose pollution.
    Success output stays on stdout via plain ``print()``.
    """
    print(message, file=sys.stderr, flush=True)


def validate_relative_path(p: str) -> str | None:
    """Client-side path pre-check before sending to the coordinator.

    Reject absolute paths, ``..`` traversal, and empty input. Returns
    None on valid, a reason string on invalid.

    M-02 layer-distinction note: this is the CLI-side check (light;
    designed for friendly operator error messages before the request
    is built). The server-side check is
    :func:`ccs.adapters.claude_code.coordinator_server.validate_path`
    — STRICTER (also rejects backslash-leading paths, control characters,
    paths longer than MAX_PATH_LEN, non-string types). The server-side
    check is the authoritative gate; this CLI check is for fast feedback
    without a coordinator round-trip. Do NOT remove either — they live
    at different layers of the trust boundary.

    P2 ce-review fix #6 (maintainability): consolidates the
    ``_validate_path`` helper that previously existed byte-for-byte in
    both coherence_track.py and coherence_untrack.py — divergence risk
    eliminated. Both scripts now import this single source of truth."""
    if not p:
        return "empty"
    if p.startswith("/"):
        return "path must be relative (no leading '/')"
    if ".." in Path(p).parts:
        return "path must not contain '..' traversal"
    return None


@dataclass(frozen=True)
class CoordinatorEndpoint:
    """Resolved (port, bearer_token) pair for the local coordinator."""

    port: int
    bearer: str

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"


class CoordinatorUnavailable(Exception):
    """Coordinator is not running or its auth surface is missing.

    Carries a human-readable message the console script prints verbatim.
    """


def resolve_endpoint(coordinator_root: Path) -> CoordinatorEndpoint:
    """Read port + secret from ``<root>/.coherence/`` or raise
    :class:`CoordinatorUnavailable` with an operator-friendly message."""
    coherence_dir = coordinator_root / ".coherence"
    pid_file = coherence_dir / "server.pid"
    secret_file = coherence_dir / "hook.secret"

    port = _read_port_from_file(pid_file)
    if port is None:
        raise CoordinatorUnavailable(
            "no coordinator running for this workspace "
            f"(no port in {pid_file}); start one with `agent-coherence-coordinator`"
        )

    if not secret_file.is_file():
        raise CoordinatorUnavailable(
            "coordinator authentication unavailable "
            f"(missing {secret_file}); restart with `agent-coherence-coordinator`"
        )

    try:
        bearer = secret_file.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise CoordinatorUnavailable(
            f"could not read {secret_file}: {exc}"
        ) from exc

    if not bearer:
        raise CoordinatorUnavailable(
            f"{secret_file} is empty; restart with `agent-coherence-coordinator`"
        )

    return CoordinatorEndpoint(port=port, bearer=bearer)


def get(
    endpoint: CoordinatorEndpoint,
    path: str,
    *,
    extra_headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Authenticated GET. Raises :class:`CoordinatorUnavailable` on network
    error; raises :class:`urllib.error.HTTPError` for non-2xx so the caller
    can format status codes explicitly.

    R12 (Unit 6): ``extra_headers`` lets local-operator CLIs (e.g.,
    ``agent-coherence-status``) add ``Coherence-Local-Operator: true``
    for the elevated ``/status?detail=full`` tier without hard-coding
    that header here."""
    headers: dict[str, str] = {
        "Authorization": f"Bearer {endpoint.bearer}",
        "Host": "127.0.0.1",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(
        url=f"{endpoint.base_url}{path}",
        method="GET",
        headers=headers,
    )
    return _execute(req)


def post(
    endpoint: CoordinatorEndpoint,
    path: str,
    body: dict[str, Any],
    *,
    extra_headers: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Authenticated POST with JSON body.

    M-04 / finding #28: ``extra_headers`` mirrors the pattern on ``get()``
    so callers can add e.g. ``Coherence-Local-Operator: true`` without
    reimplementing the urllib transport layer.
    """
    payload = json.dumps(body).encode("utf-8")
    headers: dict[str, str] = {
        "Authorization": f"Bearer {endpoint.bearer}",
        "Host": "127.0.0.1",
        "Content-Type": "application/json",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(
        url=f"{endpoint.base_url}{path}",
        data=payload,
        method="POST",
        headers=headers,
    )
    return _execute(req)


def _execute(req: urllib.request.Request) -> dict[str, Any]:
    try:
        with urllib.request.urlopen(req, timeout=CLI_HTTP_TIMEOUT_SEC) as resp:
            raw = resp.read()
    except urllib.error.HTTPError:
        # Caller handles status-code-specific paths.
        raise
    except urllib.error.URLError as exc:
        raise CoordinatorUnavailable(
            f"could not reach coordinator at {req.full_url}: {exc.reason}"
        ) from exc
    except (OSError, TimeoutError) as exc:
        raise CoordinatorUnavailable(
            f"network error talking to coordinator: {exc}"
        ) from exc

    if not raw:
        return {}
    try:
        return json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise CoordinatorUnavailable(
            f"coordinator returned non-JSON response: {exc}"
        ) from exc


def http_status_from_error(exc: urllib.error.HTTPError) -> dict[str, Any] | None:
    """Best-effort JSON decode of an HTTPError body, for one-line user output."""
    try:
        raw = exc.read()
    except Exception:
        return None
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return None
