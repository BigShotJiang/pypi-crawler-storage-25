"""Command-line interface for depot-dl.

Subcommands:
    download   fetch files from one or more manifests
    list       list files in a manifest (no download)
    info       show metadata about a manifest
    login      interactive login, caches credentials
    logout     clear cached credentials
    whoami     show current logged-in user
    version    print version

All commands share a single login session: one handshake, N operations.
"""

from __future__ import annotations

# gevent patching first, before anything from steam / our client
from depot_dl import _monkey  # noqa: F401

import argparse
import logging
import sys
from pathlib import Path
from typing import Sequence

from depot_dl import __version__
from depot_dl.client import DEFAULT_CACHE_DIR, DepotClient, LoginOptions
from depot_dl.downloader import (
    DownloadRequest,
    DownloadResult,
    FileProgress,
    download_manifest,
    iter_manifest_files,
)
from depot_dl.errors import (
    AppAccessError,
    AuthenticationError,
    ManifestUnavailableError,
    PyDepotError,
    RateLimitError,
)
from depot_dl.filters import FileFilter

log = logging.getLogger("depot-dl")


# ----------------------------------------------------------------------
# Argument parser
# ----------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="depot-dl",
        description="A modern Python Steam depot downloader with single-session "
                    "manifest fetching.",
    )
    p.add_argument("--log-level", default="info",
                   choices=["debug", "info", "warning", "error"])
    p.add_argument("--cache-dir", type=Path, default=DEFAULT_CACHE_DIR,
                   help="Where to store cached credentials (default: ~/.depot-dl)")

    sub = p.add_subparsers(dest="command", required=True)

    # --- download ---------------------------------------------------
    dl = sub.add_parser("download", help="Download files from one or more manifests")
    _add_auth_args(dl)
    _add_depot_args(dl)
    dl.add_argument("--manifest", action="append", type=int, default=[],
                    help="Manifest ID (repeatable)")
    dl.add_argument("--manifest-file", type=Path,
                    help="File containing manifest IDs (one per line)")
    dl.add_argument("--filelist", type=Path,
                    help="Filelist with patterns (DepotDownloader-compatible)")
    dl.add_argument("--file", dest="file_pattern", action="append", default=[],
                    help="Download only files matching this pattern (repeatable, "
                         "supports glob and regex: prefix)")
    dl.add_argument("--output", type=Path, default=Path("./downloads"))
    dl.add_argument("--name-template", default=None,
                    help="Flatten-layout template, e.g. '{file}_{manifest}'")
    dl.add_argument("--max-chunks", type=int, default=8)
    dl.add_argument("--validate", action="store_true",
                    help="Re-hash existing files; re-download on mismatch")
    dl.add_argument("--overwrite", action="store_true",
                    help="Re-download even if output exists")
    dl.add_argument("--no-skip-existing", dest="skip_existing",
                    action="store_false", default=True)
    dl.add_argument("--dry-run", action="store_true",
                    help="Resolve manifests but do not download")
    dl.set_defaults(func=cmd_download)

    # --- list -------------------------------------------------------
    ls = sub.add_parser("list", help="List files in a manifest")
    _add_auth_args(ls)
    _add_depot_args(ls)
    ls.add_argument("--manifest", type=int, required=True)
    ls.add_argument("--filter", dest="filter_glob", default=None,
                    help="Single glob/regex pattern to filter output")
    ls.set_defaults(func=cmd_list)

    # --- info -------------------------------------------------------
    info = sub.add_parser("info", help="Show metadata about a manifest")
    _add_auth_args(info)
    _add_depot_args(info)
    info.add_argument("--manifest", type=int, required=True)
    info.set_defaults(func=cmd_info)

    # --- login ------------------------------------------------------
    login = sub.add_parser("login", help="Interactive login, cache credentials")
    _add_auth_args(login)
    login.set_defaults(func=cmd_login)

    # --- logout -----------------------------------------------------
    logout = sub.add_parser("logout", help="Clear cached credentials")
    logout.set_defaults(func=cmd_logout)

    # --- whoami -----------------------------------------------------
    whoami = sub.add_parser("whoami", help="Show cached user")
    whoami.set_defaults(func=cmd_whoami)

    # --- version ----------------------------------------------------
    ver = sub.add_parser("version", help="Print version")
    ver.set_defaults(func=cmd_version)

    return p


def _add_auth_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("authentication")
    g.add_argument("--user", help="Steam username")
    g.add_argument("--password", help="Steam password (prefer interactive prompt)")
    g.add_argument("--anonymous", action="store_true",
                   help="Use anonymous account (works only for some apps)")


def _add_depot_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("depot")
    g.add_argument("--app", type=int, required=True, help="AppID")
    g.add_argument("--depot", type=int, required=True, help="DepotID")


# ----------------------------------------------------------------------
# Command implementations
# ----------------------------------------------------------------------


def cmd_download(args: argparse.Namespace) -> int:
    manifests = _collect_manifests(args.manifest, args.manifest_file)
    if not manifests:
        log.error("No manifests specified. Use --manifest or --manifest-file.")
        return 2

    if args.filelist and args.file_pattern:
        file_filter = FileFilter.from_file(args.filelist)
        extra = FileFilter.from_patterns(args.file_pattern)
        file_filter._patterns.extend(extra._patterns)
    elif args.filelist:
        file_filter = FileFilter.from_file(args.filelist)
    elif args.file_pattern:
        file_filter = FileFilter.from_patterns(args.file_pattern)
    else:
        file_filter = FileFilter()
    log.info("File filter: %s", file_filter.describe())
    log.info("Planning %d manifest(s)", len(manifests))

    if args.dry_run:
        for mid in manifests:
            print(f"would download manifest {mid}")
        return 0

    # Auto-enable per-manifest subfolders when downloading multiple manifests
    # without a name template, so files from different manifests don't collide.
    use_subdir = len(manifests) > 1 and not args.name_template

    with _login(args) as client:
        client.ensure_app_access(args.app)

        ok = 0
        fail = 0
        for mid in manifests:
            request = DownloadRequest(
                app_id=args.app,
                depot_id=args.depot,
                manifest_id=mid,
                output_dir=args.output,
                file_filter=file_filter,
                max_chunks=args.max_chunks,
                validate=args.validate,
                overwrite=args.overwrite,
                skip_existing=args.skip_existing,
                name_template=args.name_template,
                manifest_subdir=use_subdir,
            )
            try:
                result = download_manifest(
                    client, request, on_progress=_print_progress
                )
            except ManifestUnavailableError as exc:
                print(f"  SKIP manifest {mid}: unavailable ({exc.reason})")
                fail += 1
                continue
            except PyDepotError as exc:
                print(f"  FAIL manifest {mid}: {exc}")
                fail += 1
                continue
            except Exception as exc:  # noqa: BLE001
                print(f"  FAIL manifest {mid}: {exc}")
                fail += 1
                continue
            _report(result)
            ok += 1

    print()
    print(f"Done: {ok} ok, {fail} failed")
    return 0 if fail == 0 else 1


def cmd_list(args: argparse.Namespace) -> int:
    with _login(args) as client:
        client.ensure_app_access(args.app)
        flt = (
            FileFilter.from_patterns([args.filter_glob])
            if args.filter_glob
            else FileFilter()
        )
        for name, size in iter_manifest_files(
            client, args.app, args.depot, args.manifest, flt
        ):
            print(f"{size:>12}  {name}")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    with _login(args) as client:
        client.ensure_app_access(args.app)
        manifest = client.get_manifest(args.app, args.depot, args.manifest)
        total = sum(mf.size for mf in manifest.iter_files() if mf.is_file)
        files = sum(1 for mf in manifest.iter_files() if mf.is_file)
        print(f"app         {args.app}")
        print(f"depot       {args.depot}")
        print(f"manifest    {args.manifest}")
        print(f"files       {files}")
        print(f"total size  {total:,} bytes")
    return 0


def cmd_login(args: argparse.Namespace) -> int:
    with _login(args) as client:
        steam = client.steam
        name = getattr(steam, "username", None) or getattr(steam, "user", None)
        print(f"Logged in as {name or '(unknown)'}")
        print(f"Credentials cached in {args.cache_dir / 'credentials'}")
    return 0


def cmd_logout(args: argparse.Namespace) -> int:
    creds = args.cache_dir / "credentials"
    if not creds.exists():
        print("No cached credentials.")
        return 0
    import shutil
    shutil.rmtree(creds)
    print(f"Cleared {creds}")
    return 0


def cmd_whoami(args: argparse.Namespace) -> int:
    creds = args.cache_dir / "credentials"
    if not creds.exists():
        print("Not logged in (no cached credentials).")
        return 1
    sessions = sorted(p.name for p in creds.iterdir() if p.is_file())
    if not sessions:
        print("Not logged in (empty credentials cache).")
        return 1
    print("Cached sessions:")
    for s in sessions:
        print(f"  {s}")
    return 0


def cmd_version(_args: argparse.Namespace) -> int:
    print(f"depot-dl {__version__}")
    return 0


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _login(args: argparse.Namespace) -> DepotClient:
    client = DepotClient(cache_dir=args.cache_dir)
    try:
        client.login(
            LoginOptions(
                username=getattr(args, "user", None),
                password=getattr(args, "password", None),
                anonymous=getattr(args, "anonymous", False),
                cache_dir=args.cache_dir,
            )
        )
    except RateLimitError as exc:
        log.error(str(exc))
        sys.exit(3)
    except AuthenticationError as exc:
        log.error("Login failed: %s", exc)
        sys.exit(2)
    return client


def _collect_manifests(
    inline: list[int], from_file: Path | None
) -> list[int]:
    out: list[int] = list(inline)
    if from_file:
        for raw in from_file.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            try:
                out.append(int(line.split()[0]))
            except ValueError:
                log.warning("Skipping unparseable manifest line: %r", line)
    # Dedupe, preserve order
    seen: set[int] = set()
    unique: list[int] = []
    for m in out:
        if m not in seen:
            seen.add(m)
            unique.append(m)
    return unique


def _print_progress(p: FileProgress) -> None:
    bar_width = 30
    filled = int(bar_width * p.percent / 100)
    bar = "#" * filled + "-" * (bar_width - filled)
    sys.stderr.write(f"\r  [{bar}] {p.percent:5.1f}%  {p.file}")
    sys.stderr.flush()
    if p.bytes_done >= p.bytes_total:
        sys.stderr.write("\n")


def _report(result: DownloadResult) -> None:
    mb = result.bytes_downloaded / (1024 * 1024)
    print(
        f"manifest {result.manifest_id}: "
        f"{len(result.files_downloaded)} downloaded, "
        f"{len(result.files_skipped)} skipped, "
        f"{mb:.2f} MB"
    )


# ----------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    level = args.log_level.upper()
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s")
    # Suppress noisy gevent/steam tracebacks unless --log-level debug
    if level != "DEBUG":
        logging.getLogger("gevent").setLevel(logging.CRITICAL)
        logging.getLogger("steam").setLevel(logging.WARNING)
    try:
        return args.func(args) or 0
    except AppAccessError as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 4
    except PyDepotError as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nAborted.", file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001
        print(f"\nUnexpected error: {exc}", file=sys.stderr)
        log.debug("Full traceback:", exc_info=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
