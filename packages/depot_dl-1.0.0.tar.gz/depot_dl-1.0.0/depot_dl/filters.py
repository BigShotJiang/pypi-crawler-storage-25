"""File selection filters for manifest downloads.

Supports the same filelist format as DepotDownloader:
    - Plain paths match exactly
    - Lines with glob characters (*, ?, [) are treated as fnmatch globs
    - Lines prefixed with "regex:" are compiled as regular expressions
    - Lines starting with # are comments
    - Blank lines are ignored

Matching is case-insensitive by default (Steam file paths are typically
lowercase but not guaranteed, and this matches DepotDownloader behavior).
"""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from depot_dl.errors import FilelistError

_GLOB_CHARS = frozenset("*?[")


@dataclass(frozen=True)
class _Pattern:
    """A single compiled pattern entry."""
    source: str
    kind: str  # "exact", "glob", "regex"
    matcher: re.Pattern[str]


@dataclass
class FileFilter:
    """Decides whether a given file path from a manifest should be downloaded.

    An empty filter matches everything (no filelist supplied).

    Example:
        f = FileFilter.from_patterns([
            "game/steam.inf",
            "*.swf",
            r"regex:.*\\.cfg$",
        ])
        assert f.matches("game/steam.inf")
        assert f.matches("Brawlhalla.swf")
        assert f.matches("cfg/autoexec.cfg")
        assert not f.matches("data.bin")
    """

    _patterns: list[_Pattern] = field(default_factory=list)
    case_sensitive: bool = False

    @classmethod
    def from_file(cls, path: str | Path, *, case_sensitive: bool = False) -> FileFilter:
        """Load a filelist file and compile its patterns."""
        p = Path(path)
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            raise FilelistError(f"Cannot read filelist {p}: {exc}") from exc
        return cls.from_patterns(lines, case_sensitive=case_sensitive)

    @classmethod
    def from_patterns(
        cls,
        patterns: Iterable[str],
        *,
        case_sensitive: bool = False,
    ) -> FileFilter:
        """Compile an iterable of pattern strings into a FileFilter."""
        compiled: list[_Pattern] = []
        flags = 0 if case_sensitive else re.IGNORECASE

        for raw in patterns:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            if line.startswith("regex:"):
                expr = line[len("regex:"):]
                try:
                    matcher = re.compile(expr, flags)
                except re.error as exc:
                    raise FilelistError(
                        f"Invalid regex in filelist: {expr!r} ({exc})"
                    ) from exc
                compiled.append(_Pattern(source=line, kind="regex", matcher=matcher))
                continue

            if any(c in _GLOB_CHARS for c in line):
                matcher = re.compile(fnmatch.translate(line), flags)
                compiled.append(_Pattern(source=line, kind="glob", matcher=matcher))
                continue

            # Exact path match (normalized to forward slashes)
            normalized = line.replace("\\", "/")
            matcher = re.compile(
                "^" + re.escape(normalized) + "$",
                flags,
            )
            compiled.append(_Pattern(source=line, kind="exact", matcher=matcher))

        return cls(_patterns=compiled, case_sensitive=case_sensitive)

    def matches(self, file_path: str) -> bool:
        """Return True if `file_path` should be included.

        An empty filter matches everything.
        """
        if not self._patterns:
            return True
        normalized = file_path.replace("\\", "/")
        return any(p.matcher.search(normalized) for p in self._patterns)

    def is_empty(self) -> bool:
        return not self._patterns

    def describe(self) -> str:
        if not self._patterns:
            return "(match all)"
        parts = []
        for p in self._patterns:
            src = p.source
            if p.kind == "regex" and src.startswith("regex:"):
                src = src[len("regex:"):]
            parts.append(f"{p.kind}:{src}")
        return ", ".join(parts)
