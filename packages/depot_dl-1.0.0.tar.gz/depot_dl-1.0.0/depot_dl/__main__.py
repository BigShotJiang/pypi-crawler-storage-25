"""Enable `python -m depot_dl`."""

from depot_dl.cli import main

if __name__ == "__main__":
    main()
