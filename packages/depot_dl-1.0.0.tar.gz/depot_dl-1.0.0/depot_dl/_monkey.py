"""gevent monkey-patching.

The `steam` package is built on gevent. Monkey-patching must happen before
any stdlib socket/ssl/threading code runs, so this module gets imported at
the very top of anything that touches the Steam protocol.

Importing this module has the side effect of patching the standard library.
It is idempotent.
"""

from __future__ import annotations

from gevent import monkey as _monkey

if not _monkey.is_module_patched("socket"):
    _monkey.patch_all(thread=False)
