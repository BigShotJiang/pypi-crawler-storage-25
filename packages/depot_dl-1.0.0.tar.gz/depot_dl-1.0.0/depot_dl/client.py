"""Single-session Steam client for depot-dl.

This module wraps `steam.client.SteamClient` and `steam.client.cdn.CDNClient`
into a single reusable object. The login handshake happens once; everything
else (manifest fetches, chunk downloads) runs over the established session.

Why this matters: the official DepotDownloader logs in once per invocation.
Running it in a loop over N manifests produces N logins, which hits Steam's
login rate limit. depot-dl's `DepotClient` logs in exactly once per program
run regardless of how many manifests you fetch.
"""

from __future__ import annotations

# Monkey-patch stdlib before any Steam-related import.
from depot_dl import _monkey  # noqa: F401

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Iterator

from depot_dl.errors import (
    AppAccessError,
    AuthenticationError,
    ManifestUnavailableError,
    RateLimitError,
)

if TYPE_CHECKING:
    from steam.client import SteamClient as _SteamClient  # type: ignore
    from steam.client.cdn import CDNClient as _CDNClient  # type: ignore

log = logging.getLogger(__name__)

DEFAULT_CACHE_DIR = Path(os.path.expanduser("~")) / ".depot-dl"


def _patch_get_chunk(cdn: object) -> None:
    """Monkey-patch CDNClient.get_chunk to handle Valve's VSZa (Zstandard) format.

    The steam library v1.4.4 only handles VZ (LZMA) and PK (ZIP). Newer depots
    use VSZa: 4-byte magic + 4-byte CRC32 + zstd data + 15-byte footer.

    VSZa layout:
      [0:4]     magic   b'VSZa'
      [4:8]     crc32   of decompressed data
      [8:-15]   zstd    compressed payload
      [-15:-11] crc32   (duplicate)
      [-11:-7]  decompressed size (int32 LE)
      [-7:-4]   padding
      [-3:]     footer  b'zsv'
    """
    import struct
    from binascii import crc32
    from io import BytesIO
    from zipfile import ZipFile

    import lzma
    import zstandard

    from steam.core.crypto import symmetric_decrypt
    from steam.exceptions import SteamError

    def patched_get_chunk(self, app_id, depot_id, chunk_id):
        if (depot_id, chunk_id) in self._chunk_cache:
            return self._chunk_cache[(depot_id, chunk_id)]

        resp = self.cdn_cmd('depot', '%s/chunk/%s' % (depot_id, chunk_id))
        data = symmetric_decrypt(resp.content, self.get_depot_key(app_id, depot_id))

        if data[:2] == b'VZ':
            if data[-2:] != b'zv':
                raise SteamError("VZ: Invalid footer: %s" % repr(data[-2:]))
            if data[2:3] != b'a':
                raise SteamError("VZ: Invalid version: %s" % repr(data[2:3]))

            vzfilter = lzma._decode_filter_properties(lzma.FILTER_LZMA1, data[7:12])
            vzdec = lzma.LZMADecompressor(lzma.FORMAT_RAW, filters=[vzfilter])
            checksum, decompressed_size = struct.unpack('<II', data[-10:-2])
            data = vzdec.decompress(data[12:-9])[:decompressed_size]
            if crc32(data) != checksum:
                raise SteamError("VZ: CRC32 checksum doesn't match for decompressed data")
        elif data[:4] == b'VSZa':
            if data[-3:] != b'zsv':
                raise SteamError("VSZa: Invalid footer: %s" % repr(data[-3:]))
            decompressed_size = struct.unpack_from('<i', data, len(data) - 11)[0]
            compressed = data[8:-15]
            dctx = zstandard.ZstdDecompressor()
            data = dctx.decompress(compressed, max_output_size=decompressed_size)
        elif data[:2] == b'PK':
            with ZipFile(BytesIO(data)) as zf:
                data = zf.read(zf.filelist[0])
        else:
            raise SteamError("Unknown chunk format: %s" % repr(data[:4]))

        self._chunk_cache[(depot_id, chunk_id)] = data
        return data

    import types
    cdn.get_chunk = types.MethodType(patched_get_chunk, cdn)


@dataclass
class LoginOptions:
    username: str | None = None
    password: str | None = None
    anonymous: bool = False
    cache_dir: Path = DEFAULT_CACHE_DIR


class DepotClient:
    """A persistent, reusable Steam client for depot operations.

    Typical usage:

        client = DepotClient()
        client.login(LoginOptions(username="you"))
        manifest = client.get_manifest(app_id, depot_id, manifest_id)
        ...
        client.close()

    Or as a context manager:

        with DepotClient() as client:
            client.login(LoginOptions(username="you"))
            ...
    """

    def __init__(self, cache_dir: Path = DEFAULT_CACHE_DIR) -> None:
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._steam: _SteamClient | None = None
        self._cdn: _CDNClient | None = None
        self._logged_in = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def login(self, options: LoginOptions | None = None) -> None:
        """Authenticate against Steam. Must be called before any depot ops.

        Email/2FA code is required once per program run. The session is then
        reused for all subsequent manifest fetches and chunk downloads.
        """
        from steam.client import SteamClient
        from steam.client.cdn import CDNClient
        from steam.enums import EResult

        opts = options or LoginOptions()
        steam = SteamClient()

        creds_dir = self._cache_dir / "credentials"
        creds_dir.mkdir(parents=True, exist_ok=True)
        steam.set_credential_location(str(creds_dir))

        if opts.anonymous:
            log.info("Logging in anonymously")
            result = steam.anonymous_login()
        elif opts.username:
            log.info("Logging in as %s", opts.username)
            result = steam.cli_login(
                username=opts.username,
                password=opts.password or "",
            )
        else:
            raise AuthenticationError(
                "No credentials supplied. Provide --user or --anonymous."
            )

        if result != EResult.OK:
            name = getattr(result, "name", str(result))
            if name == "RateLimitExceeded":
                raise RateLimitError(
                    "Steam rate limited this login. Wait 30+ minutes."
                )
            raise AuthenticationError(f"Steam login failed: {name}")

        self._steam = steam
        cdn = CDNClient(steam)
        _patch_get_chunk(cdn)
        cdn.load_licenses()
        log.debug(
            "Loaded %d licensed apps, %d licensed depots",
            len(cdn.licensed_app_ids),
            len(cdn.licensed_depot_ids),
        )
        self._cdn = cdn
        self._logged_in = True
        log.info("Login successful — session will be reused for all manifests")

    def logout(self) -> None:
        if self._steam is not None:
            try:
                self._steam.logout()
            except Exception:  # noqa: BLE001
                pass
        self._steam = None
        self._cdn = None
        self._logged_in = False

    def close(self) -> None:
        self.logout()

    def __enter__(self) -> "DepotClient":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Depot operations
    # ------------------------------------------------------------------

    @property
    def is_logged_in(self) -> bool:
        return self._logged_in

    @property
    def cdn(self) -> "_CDNClient":
        if self._cdn is None:
            raise AuthenticationError("Not logged in. Call login() first.")
        return self._cdn

    @property
    def steam(self) -> "_SteamClient":
        if self._steam is None:
            raise AuthenticationError("Not logged in. Call login() first.")
        return self._steam

    def ensure_app_access(self, app_id: int) -> None:
        """Best-effort check — skipped because resolving packages to apps is
        expensive. Steam will reject at manifest fetch if access is missing."""

    def get_manifest(
        self,
        app_id: int,
        depot_id: int,
        manifest_id: int,
        branch: str = "public",
    ):
        """Fetch a single manifest from Steam.

        Automatically obtains a manifest request code (required by Steam CDN
        for authenticated downloads) before fetching the manifest itself.
        """
        try:
            code = self.cdn.get_manifest_request_code(
                app_id, depot_id, manifest_id, branch
            )
            return self.cdn.get_manifest(
                app_id, depot_id, manifest_id, manifest_request_code=code
            )
        except Exception as exc:  # noqa: BLE001
            raise ManifestUnavailableError(
                manifest_id, reason=str(exc)
            ) from exc

    def iter_manifests(
        self, app_id: int, depot_id: int, manifest_ids: list[int]
    ) -> Iterator[tuple[int, object]]:
        """Yield (manifest_id, manifest) pairs, skipping unavailable ones."""
        for mid in manifest_ids:
            try:
                yield mid, self.get_manifest(app_id, depot_id, mid)
            except ManifestUnavailableError as exc:
                log.warning("Skipping manifest %s: %s", mid, exc.reason)
                continue
