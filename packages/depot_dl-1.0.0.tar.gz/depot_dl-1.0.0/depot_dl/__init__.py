"""depot-dl — a modern Python Steam depot downloader.

Library surface:
    from depot_dl import DepotClient, DownloadRequest, FileFilter
    from depot_dl import errors

The heavy Steam-protocol imports (which pull in gevent via the `steam`
package) are loaded lazily on first attribute access, so importing `depot-dl`
alone — or just using `FileFilter` — does not drag in gevent.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from depot_dl.filters import FileFilter  # gevent-free, safe to eagerly import

__all__ = [
    "DepotClient",
    "DownloadRequest",
    "DownloadResult",
    "FileProgress",
    "FileFilter",
]

__version__ = "1.0.0"

if TYPE_CHECKING:
    from depot_dl.client import DepotClient
    from depot_dl.downloader import DownloadRequest, DownloadResult, FileProgress


_LAZY = {
    "DepotClient": ("depot_dl.client", "DepotClient"),
    "DownloadRequest": ("depot_dl.downloader", "DownloadRequest"),
    "DownloadResult": ("depot_dl.downloader", "DownloadResult"),
    "FileProgress": ("depot_dl.downloader", "FileProgress"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY:
        import importlib
        module_name, attr = _LAZY[name]
        module = importlib.import_module(module_name)
        value = getattr(module, attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module 'depot-dl' has no attribute {name!r}")
