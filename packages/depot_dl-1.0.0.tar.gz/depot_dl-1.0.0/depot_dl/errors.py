"""Typed exceptions for depot-dl.

Callers can catch specific failure modes instead of a generic Exception.
"""

from __future__ import annotations


class PyDepotError(Exception):
    """Base class for all depot-dl errors."""


class AuthenticationError(PyDepotError):
    """Raised when Steam login fails."""


class RateLimitError(AuthenticationError):
    """Raised when Steam returns RateLimitExceeded.

    depot-dl's single-session design should make this rare — it only happens
    on the initial login. If you see this, wait 30+ minutes before retrying.
    """


class AppAccessError(PyDepotError):
    """Raised when the current account does not have a license for the app."""


class ManifestUnavailableError(PyDepotError):
    """Raised when a manifest cannot be fetched from Steam.

    Steam allows developers to drop old manifests from their CDN. When that
    happens there is no workaround — the data is gone.
    """

    def __init__(self, manifest_id: int, reason: str | None = None) -> None:
        msg = f"Manifest {manifest_id} unavailable"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)
        self.manifest_id = manifest_id
        self.reason = reason


class ChunkDownloadError(PyDepotError):
    """Raised when a chunk repeatedly fails to download or decrypt."""


class FilelistError(PyDepotError):
    """Raised when a filelist file cannot be parsed."""


class ConfigError(PyDepotError):
    """Raised on invalid configuration."""
