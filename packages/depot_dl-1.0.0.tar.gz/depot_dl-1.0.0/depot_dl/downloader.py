"""Manifest-level downloading: file selection, chunk fetching, on-disk assembly.

This module is deliberately decoupled from the CLI and from authentication.
It takes a `DepotClient` (already logged in) and a `DownloadRequest` and
produces files on disk.

Concurrency
-----------
Two orthogonal levers:

- `max_chunks`: parallel chunks per file (via gevent.pool.Pool)
- `concurrent_manifests`: parallel manifests in flight (outer loop; caller
  should spawn their own greenlets if desired — this module handles one
  manifest at a time for simplicity and predictable on-disk layout).

Resume
------
Before downloading, each target file is checked against its expected size
on disk. If it matches, the file is skipped unless `validate=True`, in which
case we re-hash and compare to the manifest's SHA1.
"""

from __future__ import annotations

# gevent patch must happen before steam imports
from depot_dl import _monkey  # noqa: F401

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterator

from gevent.pool import Pool

from depot_dl.client import DepotClient
from depot_dl.errors import ChunkDownloadError
from depot_dl.filters import FileFilter

log = logging.getLogger(__name__)


# ----------------------------------------------------------------------
# Public types
# ----------------------------------------------------------------------


@dataclass
class DownloadRequest:
    """Everything needed to fetch files from a single manifest."""

    app_id: int
    depot_id: int
    manifest_id: int
    output_dir: Path
    file_filter: FileFilter = field(default_factory=FileFilter)
    max_chunks: int = 8
    validate: bool = False
    skip_existing: bool = True
    overwrite: bool = False
    name_template: str | None = None  # {file}, {manifest}, {app}, {depot}, {date}
    manifest_subdir: bool = False  # put each manifest in its own subfolder

    def __post_init__(self) -> None:
        self.output_dir = Path(self.output_dir)


@dataclass
class FileProgress:
    """Emitted during a download for progress reporting."""

    file: str
    bytes_done: int
    bytes_total: int

    @property
    def percent(self) -> float:
        if self.bytes_total == 0:
            return 100.0
        return 100.0 * self.bytes_done / self.bytes_total


@dataclass
class DownloadResult:
    """Summary returned when a manifest download finishes."""

    app_id: int
    depot_id: int
    manifest_id: int
    files_downloaded: list[Path]
    files_skipped: list[Path]
    bytes_downloaded: int
    creation_date: str | None = None  # YYYY-MM-DD from manifest metadata

    @property
    def total_files(self) -> int:
        return len(self.files_downloaded) + len(self.files_skipped)


# ----------------------------------------------------------------------
# Core download logic
# ----------------------------------------------------------------------


def download_manifest(
    client: DepotClient,
    request: DownloadRequest,
    *,
    on_progress: Callable[[FileProgress], None] | None = None,
) -> DownloadResult:
    """Download files from a single manifest.

    This is the library-level entry point. CLI code should call it directly
    rather than re-implementing the loop.
    """
    manifest = client.get_manifest(
        request.app_id, request.depot_id, request.manifest_id
    )

    creation_date = _extract_creation_date(manifest)

    # The steam library exposes manifest.iter_files() -> ManifestFile objects
    # with .filename, .size, .is_file, .chunks
    targets = [
        mf for mf in manifest.iter_files()
        if mf.is_file and request.file_filter.matches(mf.filename)
    ]

    request.output_dir.mkdir(parents=True, exist_ok=True)

    downloaded: list[Path] = []
    skipped: list[Path] = []
    bytes_total = 0

    for mf in targets:
        dest = _resolve_dest(request, mf.filename, creation_date=creation_date)
        dest.parent.mkdir(parents=True, exist_ok=True)

        if _should_skip(dest, mf, request):
            log.debug("Skipping existing %s", dest)
            skipped.append(dest)
            continue

        written = _download_file(
            client=client,
            app_id=request.app_id,
            depot_id=request.depot_id,
            manifest_file=mf,
            dest=dest,
            max_chunks=request.max_chunks,
            on_progress=on_progress,
        )
        downloaded.append(dest)
        bytes_total += written

    return DownloadResult(
        app_id=request.app_id,
        depot_id=request.depot_id,
        manifest_id=request.manifest_id,
        files_downloaded=downloaded,
        files_skipped=skipped,
        bytes_downloaded=bytes_total,
        creation_date=creation_date,
    )


def iter_manifest_files(
    client: DepotClient,
    app_id: int,
    depot_id: int,
    manifest_id: int,
    file_filter: FileFilter | None = None,
) -> Iterator[tuple[str, int]]:
    """Yield (filename, size) for every file in a manifest matching the filter.

    Used by the `list` CLI command. Does not download anything.
    """
    manifest = client.get_manifest(app_id, depot_id, manifest_id)
    flt = file_filter or FileFilter()
    for mf in manifest.iter_files():
        if not mf.is_file:
            continue
        if flt.matches(mf.filename):
            yield mf.filename, mf.size


# ----------------------------------------------------------------------
# Internals
# ----------------------------------------------------------------------


def _extract_creation_date(manifest: object) -> str | None:
    """Pull the YYYY-MM-DD creation date from a manifest, if available.

    The steam library stores it in different places depending on version:
    - manifest.metadata.creation_time (unix timestamp)
    - manifest.creation_time
    """
    ts = None
    meta = getattr(manifest, "metadata", None)
    if meta is not None:
        ts = getattr(meta, "creation_time", None)
    if ts is None:
        ts = getattr(manifest, "creation_time", None)
    if ts is None:
        return None
    try:
        dt = datetime.fromtimestamp(int(ts), tz=timezone.utc)
        return dt.strftime("%Y-%m-%d")
    except (ValueError, TypeError, OSError):
        return None


def _resolve_dest(
    request: DownloadRequest,
    filename: str,
    *,
    creation_date: str | None = None,
) -> Path:
    """Compute the on-disk path for a given manifest file."""
    normalized = filename.replace("\\", "/")

    if request.name_template:
        # Flat layout: all files renamed by template into output_dir
        basename = Path(normalized).name
        stem = Path(basename).stem
        suffix = Path(basename).suffix
        rendered = request.name_template.format(
            file=stem,
            manifest=request.manifest_id,
            app=request.app_id,
            depot=request.depot_id,
            date=creation_date or "unknown",
        )
        return request.output_dir / f"{rendered}{suffix}"

    if request.manifest_subdir:
        # Tree layout: each manifest in its own subfolder, preserving paths
        date_prefix = f"{creation_date}_" if creation_date else ""
        subdir = f"{date_prefix}{request.manifest_id}"
        return request.output_dir / subdir / normalized

    # Single-manifest mode: files directly into output_dir preserving paths
    return request.output_dir / normalized


def _should_skip(dest: Path, manifest_file: object, request: DownloadRequest) -> bool:
    if request.overwrite:
        return False
    if not dest.exists():
        return False
    if not request.skip_existing:
        return False

    expected_size = getattr(manifest_file, "size", None)
    if expected_size is None:
        return True
    if dest.stat().st_size != expected_size:
        return False

    if request.validate:
        expected_sha = getattr(manifest_file, "sha_content", None) or getattr(
            manifest_file, "filename_sha", None
        )
        if expected_sha is None:
            return True
        if _sha1_of(dest) != expected_sha:
            log.info("Validation mismatch on %s, will re-download", dest.name)
            return False
    return True


def _sha1_of(path: Path) -> bytes:
    h = hashlib.sha1()  # noqa: S324 — Steam uses SHA1 for chunk/file hashes
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.digest()


def _download_file(
    *,
    client: DepotClient,
    app_id: int,
    depot_id: int,
    manifest_file: object,
    dest: Path,
    max_chunks: int,
    on_progress: Callable[[FileProgress], None] | None,
) -> int:
    """Download all chunks of a file in parallel and assemble on disk."""
    total_size: int = getattr(manifest_file, "size", 0)
    chunks = list(getattr(manifest_file, "chunks", []))
    if not chunks:
        dest.touch()
        return 0

    # Pre-allocate the file so chunks can be written to their offsets directly.
    with dest.open("wb") as fh:
        fh.truncate(total_size)

    progress_done = [0]

    def fetch(chunk) -> None:
        chunk_id = chunk.sha.hex() if isinstance(chunk.sha, bytes) else str(chunk.sha)
        try:
            data = client.cdn.get_chunk(app_id, depot_id, chunk_id)
        except Exception as exc:  # noqa: BLE001
            raise ChunkDownloadError(
                f"Failed to fetch chunk {chunk_id}: {exc}"
            ) from exc

        with dest.open("r+b") as fh:
            fh.seek(chunk.offset)
            fh.write(data)

        progress_done[0] += len(data)
        if on_progress:
            on_progress(
                FileProgress(
                    file=getattr(manifest_file, "filename", str(dest)),
                    bytes_done=progress_done[0],
                    bytes_total=total_size,
                )
            )

    import gevent
    from gevent.lock import BoundedSemaphore

    greenlets = []
    sem = BoundedSemaphore(max(1, max_chunks))

    def _guarded_fetch(chunk):
        with sem:
            fetch(chunk)

    for chunk in chunks:
        g = gevent.spawn(_guarded_fetch, chunk)
        g.link_exception(lambda _: None)  # suppress gevent's stderr traceback
        greenlets.append(g)

    gevent.joinall(greenlets, raise_error=False)

    errors = [g.exception for g in greenlets if g.exception is not None]
    if errors:
        raise ChunkDownloadError(str(errors[0]))

    return total_size
