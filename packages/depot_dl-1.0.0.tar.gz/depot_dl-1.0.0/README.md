# depot-dl

Python Steam depot downloader built for **single-session, many-manifest**
workflows. Unlike the official DepotDownloader, depot-dl logs in **once** and
reuses the same authenticated session across every manifest request — no more
getting rate-limited by Steam's login throttle when fetching historical builds.

## Why depot-dl?

The official [DepotDownloader](https://github.com/SteamRE/DepotDownloader) is a
great tool, but each invocation performs a fresh Steam login. If you need to
fetch dozens or hundreds of historical manifests, you'll hit
`RateLimitExceeded` after a few dozen requests and get locked out for hours.

**depot-dl's core design:** one login, one session, N manifests. You can fetch
hundreds of historical builds in a single run without tripping Steam's rate
limiter, because only one login handshake ever happens.

## Installation

```bash
pip install depot-dl
```

Or from source:

```bash
git clone https://github.com/bitalizer/depot-dl
cd depot-dl
pip install -e .
```

## Quick start

### Download a single manifest

```bash
depot-dl download --app 440 --depot 441 \
    --manifest 3087768970110163342 --user YOUR_STEAM_LOGIN
```

### Download many manifests in one session

```bash
# manifests.txt — one manifest ID per line
echo 3087768970110163342 > manifests.txt
echo 1619985635172051553 >> manifests.txt

depot-dl download --app 440 --depot 441 \
    --manifest-file manifests.txt \
    --user YOUR_STEAM_LOGIN
```

### Only download specific files

```bash
depot-dl download --app 440 --depot 441 \
    --manifest-file manifests.txt \
    --file "*.cfg" \
    --user YOUR_STEAM_LOGIN
```

Or use a filelist file (same format as DepotDownloader):

```
# filelist.txt
regex:.*\.cfg$
*.json
```

```bash
depot-dl download --app 440 --depot 441 \
    --manifest-file manifests.txt \
    --filelist filelist.txt \
    --user YOUR_STEAM_LOGIN
```

### Flat output with name templates

```bash
depot-dl download --app 440 --depot 441 \
    --manifest-file manifests.txt \
    --file "game.exe" \
    --name-template "{file}_{date}_{manifest}" \
    --user YOUR_STEAM_LOGIN
```

Template variables: `{file}`, `{manifest}`, `{app}`, `{depot}`, `{date}`

### List files in a manifest

```bash
depot-dl list --app 440 --depot 441 --manifest 3087768970110163342 --user YOUR_STEAM_LOGIN
```

### Get manifest info

```bash
depot-dl info --app 440 --depot 441 --manifest 3087768970110163342 --user YOUR_STEAM_LOGIN
```

## Filelist format

depot-dl supports the same filelist format as DepotDownloader:

```
# comment lines start with #
game/steam.inf
regex:.*\.cfg$
*.swf
```

- Plain paths match exactly
- `regex:` prefix enables regex matching
- Anything with glob characters (`*`, `?`, `[`) is treated as a glob
- Case-insensitive matching by default

## Authentication

Email/2FA code is required once per run. The session is then reused for all
manifests in that run.

```bash
depot-dl login --user YOUR_STEAM_LOGIN     # interactive login
depot-dl whoami                            # show cached user
depot-dl logout                            # clear cached credentials
```

Anonymous mode is supported for free-to-play apps:

```bash
depot-dl download --app <id> --depot <id> --manifest <id> --anonymous
```

## Concurrency

Chunk downloads are parallelized per file via `--max-chunks` (default 8).
Manifests are processed sequentially within a single session.

## Library usage

```python
from depot_dl import DepotClient, DownloadRequest, FileFilter

client = DepotClient()
client.login(username="YOUR_STEAM_LOGIN")

request = DownloadRequest(
    app_id=440,
    depot_id=441,
    manifest_id=3087768970110163342,
    output_dir="./downloads",
    file_filter=FileFilter.from_patterns(["*.cfg"]),
)

for progress in client.download(request):
    print(f"{progress.file}: {progress.percent:.1f}%")
```

## License

MIT — see [LICENSE](LICENSE).

## Credits

Built on top of [ValvePython/steam](https://github.com/ValvePython/steam) for
Steam protocol handling. Inspired by the
[SteamRE/DepotDownloader](https://github.com/SteamRE/DepotDownloader) project.
