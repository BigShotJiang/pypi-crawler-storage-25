# Changelog

All notable changes to this project will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/).

## [9.6.0] - 2026-05-02

Closes [agentculture/agentirc#22](https://github.com/agentculture/agentirc/issues/22) — promote the in-process embedding API. Unblocks [agentculture/culture#308](https://github.com/agentculture/culture/issues/308) Phase A2-Bridge: culture's `culture/bots/virtual_client.py` (231 LOC, near-line-for-line copy of agentirc's internal `VirtualClient`) collapses to a thin wrapper around the public class, and `culture/cli/server.py:_run_server` can construct an `agentirc.ircd.IRCd` directly instead of going through the `agentirc serve` subprocess.

### Added

- **`agentirc.virtual_client.VirtualClient`** is now public, semver-tracked. `from agentirc.virtual_client import VirtualClient` is the canonical import. Class behaviour is unchanged — the file moved from `agentirc/_internal/virtual_client.py` to `agentirc/virtual_client.py` with no edits to the class body.
- **`agentirc.ircd.IRCd`** is now public, semver-tracked. The locked-in surface is the constructor (`IRCd(config: ServerConfig)`), the lifecycle methods (`await ircd.start()`, `await ircd.stop()`), `await ircd.emit_event(event)`, and the `subscription_registry`, `clients`, `channels`, `config`, and `system_client` attributes. Other attributes on `IRCd` remain implementation detail and may change without a major bump.
- **Embedding worked example** in `docs/api-stability.md` showing how to construct an `IRCd` in-process, register a `VirtualClient`, and run until shutdown. Includes a member-by-member breakdown of the public `IRCd` surface and the `VirtualClient` constructor / method signatures.

### Deprecated

- **`agentirc._internal.virtual_client.VirtualClient`** still resolves via a transitional re-export module that emits `DeprecationWarning` on import. Removal is scheduled for 10.0.0. All in-tree call sites (`ircd.py`, `server_link.py`, `channel.py`, `skills/rooms.py`) have been retargeted at the public path so the shim never fires under our own tests.

### Notes

- This release is purely additive at the Python level. No protocol changes, no CLI changes, no behaviour changes. The wire surface (the `agentirc.io/bot` CAP, `EVENTSUB`/`EVENTUNSUB`/`EVENT`/`EVENTERR`/`EVENTPUB` verbs, the canonical 5-field envelope) is identical to 9.5.0 and stays byte-locked.
- Citation manifest updated: `culture-virtual-client` now targets `agentirc/virtual_client.py`. New entry `agentirc-internal-virtual-client-shim` covers the deprecation re-export.

## [9.5.0] - 2026-05-02

Closes [agentculture/agentirc#15](https://github.com/agentculture/agentirc/issues/15) — out-of-process bot extension API. Unblocks [agentculture/culture#308](https://github.com/agentculture/culture/issues/308) Phase A2 (bot rewrite against the public API).

### Added

- **IRCv3 `agentirc.io/bot` capability.** Advertised in `CAP LS` output. When negotiated via `CAP REQ`, gates four behaviours: silent JOIN/PART/QUIT broadcasts (other channel members see nothing), no auto-op on a fresh-channel first-joiner, `+` prefix in NAMES output, `B` flag in WHO output. Channel membership is added normally; events still fire (subscribers see them via `EVENTSUB`).
- **`EVENTSUB` / `EVENTUNSUB` / `EVENT` / `EVENTERR` IRC verbs** for streaming events to bots out-of-process. `EVENTSUB <sub-id> [type=<glob>] [channel=<name>] [nick=<glob>]`: filters AND-ed; `type` and `nick` accept `fnmatch`-style globs; `channel` accepts an exact name, `*`, or empty (nick-scoped only). Multiple concurrent subscriptions per client are allowed. Wire format: `:server EVENT <sub-id> <type> <channel-or-*> <nick> :<base64-json-envelope>` carrying the canonical 5-field envelope. Per-subscription bounded queue (default 1024); on overflow the server emits `EVENTERR <sub-id> :backpressure-overflow` and drops the subscription (connection stays open). Subscriptions die on client disconnect.
- **`EVENTPUB` IRC verb** for bots to emit custom-typed events back into the stream. `EVENTPUB <type> <channel-or-*> :<base64-json-data>`. Type validated against `EVENT_TYPE_RE` (dotted lowercase, ≥1 dot — single-segment names like `message` and `topic` are reserved for built-in vocabulary). Server fills `nick` from the bot's connection nick (not spoofable) and `timestamp` from `time.time()` so federation peers see consistent clocks. `_`-prefixed keys are stripped from the payload before emit.
- New internal module `agentirc._internal.event_subscriptions` with the `Subscription` dataclass and `SubscriptionRegistry`. `IRCd.subscription_registry` exposes the registry; `IRCd.emit_event` dispatches every event through it.
- `agentirc.protocol.SEVENT` verb constant (added in 9.5.0a2; reaffirmed here).

### Changed

- **`webhook_port` is no longer bound by `IRCd.start()`.** The field stays in `ServerConfig` so culture's `~/.culture/server.yaml` keeps loading unchanged, but `agentirc` no longer instantiates the HTTP listener. Consumers that need webhook→bot dispatch host their own listener (see `docs/deployment.md`). No deprecation warning at runtime — the docs change is sufficient.
- `Channel.add()` no longer auto-ops bot-CAP clients (real or `VirtualClient`). A bot joining an empty channel stays unprivileged; the next human becomes op.
- `Channel.get_prefix()` returns `+` for bot-CAP members in NAMES output.
- `Client._build_who_flags()` adds the `B` flag for bot-CAP members in WHO output (composes with `H` and `@`/`+`).
- `VirtualClient` gains a class-level `caps = frozenset({"agentirc.io/bot", "message-tags"})` so the in-process system bot is treated identically to a real CAP-bot.
- `Client._handle_cap` `CAP LS` reply now lists supported caps from a class-level `_SUPPORTED_CAPS` frozenset (centralised; removing a cap is a major bump).
- `agentirc/_internal/bots/http_listener.py` module docstring notes the no-op stub is scheduled for removal in 9.6.0.

### Notes

- This is the **final slice** of the bot extension API. `9.5.0a1` shipped the public `agentirc.protocol` declarations; `9.5.0a2` switched the federation wire format to the 5-field envelope; this release wires the actual behaviour.
- **Federation interop unchanged from 9.5.0a2.** 9.4→9.5 federation works (sniff tolerance); 9.5→9.4 emit breaks until peers upgrade.
- The `agentirc.skill.{Event, EventType}` re-export shim from 9.5.0a1 stays through the 9.x line; removal is scheduled for 10.0.0.
- The `agentirc/_internal/bots/` synthesize stubs (`bot_manager.py`, `http_listener.py`) stay through the 9.5.x cycle; removal is scheduled for 9.6.0 once Phase A2 confirms no consumer imports them.

## [9.5.0a2] - 2026-05-02

### Changed

- **Wire format: SEVENT payload and IRCv3 `event-data` tag now carry the 5-field envelope** `{type, channel, nick, data, timestamp}`. Both the federation seam (`SEVENT` between linked servers) and the human-visible `#system` PRIVMSG `event-data` tag emit the new shape via `IRCd._build_event_envelope` + `IRCd._encode_event_data`. Type-specific keys (e.g. `text`, `room_id`, `purpose`) now nest under `data`; `nick` and `channel` remain at the top level. See `docs/superpowers/specs/2026-05-01-bot-extension-api-design.md` § Decision A for the rationale.
- `IRCd._build_event_payload` is replaced by `IRCd._build_event_envelope` (internal — no public API impact). Old name removed; the only two callsites (`_surface_event_privmsg` and `ServerLink.relay_event`'s SEVENT fallback) updated in the same commit.

### Added

- `ServerLink._is_envelope(decoded)` — sniff helper that recognises the new envelope shape vs. the legacy data-only dict at decode time. `_handle_sevent` uses it for asymmetric tolerance (see Notes).
- `agentirc.protocol.SEVENT` — verb-name constant for the federation event-relay verb. Used by the new test suite and the outbound relay path. Other agentirc-side string-literal callsites are tracked separately in [#11](https://github.com/agentculture/agentirc/issues/11).
- `tests/test_wire_format_envelope.py` — 12 tests including a golden-file byte-equality lock-in for the canonical JSON encoding (any future change to the encoder that breaks this is a wire-format break and requires a major bump), plus regression guards for the trust-bypass and underscore-injection fixes below.

### Security

- **`ServerLink._handle_sevent` now treats the SEVENT verb-arg channel as authoritative.** The previous draft of this PR (pre-review) used the envelope's `channel` field on the receive side, which would have allowed a malformed/malicious peer to bypass `_check_incoming_trust` by sending `target="*"` (no trust check) while putting a restricted channel name in the envelope. The verb-arg channel is what the trust gate already protects, so the receiver now ignores any envelope channel claim and uses `verb_channel` for both the trust check and the resulting `Event.channel`.
- **Peer-supplied `_`-prefixed keys are stripped from incoming SEVENT data before emit.** `_render` and similar server-internal hints would otherwise let a peer dictate human-readable surfacing on this server. The receiver strips every key starting with `_` from the decoded data before adding its own `_origin` marker.

### Fixed

- **`IRCd._encode_event_data` fallback now produces a valid 5-field envelope instead of `b"{}"`.** A serialization failure used to emit a bare empty dict, which fails the receiver's envelope sniff and is misclassified as legacy data-only — worse than emitting an event with no type-specific payload. The fallback now emits `{type, channel, nick, data: {}, timestamp: time.time()}` so consumers can still parse the shape.

### Notes

- **Federation interop story.** A 9.5 daemon's `_handle_sevent` sniffs the decoded payload: if it has a top-level `type` (string) and `data` (dict), treat as 9.5+ envelope; otherwise treat as ≤9.4 legacy data-only and reconstruct an `Event` from the SEVENT verb args + the bare data dict. This gives 9.5 receivers asymmetric tolerance — they read traffic from both upgraded and pre-9.5 peers — so federations can roll forward one peer at a time. The reverse direction (9.5 emit → 9.4 receive) does **not** work; 9.4 daemons have no sniff and will fail to find expected `data` fields. Operators must either upgrade all peers in lockstep, or roll one at a time and accept that 9.5-emitted events drop on still-9.4 peers until those peers also upgrade. This matches the migration cost the spec calls out.
- **Audit JSONL is unchanged.** `agentirc/_internal/telemetry/audit.py:build_audit_record` continues to record the legacy data-only payload (data dict with `nick`/`channel` merged in via `setdefault`, `_`-prefixed keys stripped). Ops dashboards and downstream log processors that read the audit JSONL keep their existing field shape; the 5-field envelope is reserved for the public network surface (SEVENT payload + IRCv3 `event-data` tag).
- **Audit timestamp on legacy peers.** When `_handle_sevent` decodes a legacy payload from a ≤9.4 peer, no originating timestamp is available; the receiver assigns `time.time()` to the reconstructed `Event.timestamp`. 9.5+ peers preserve the originating timestamp.
- This is the **wire-format slice** of the bot extension API. The next slice (9.5.0a3) wires the bot CAP behavior (`agentirc.io/bot`), the `EVENTSUB`/`EVENTUNSUB`/`EVENTPUB` handlers, and the `SubscriptionRegistry`. 9.5.0 final adds `webhook_port` unbinding and flips `docs/api-stability.md` to "current".
- Tracks [agentculture/agentirc#15](https://github.com/agentculture/agentirc/issues/15).

## [9.5.0a1] - 2026-05-02

### Added

- Public `agentirc.protocol` exports for the bot extension API: the `Event` dataclass, the `EventType` enum, 20 per-type `EVENT_TYPE_*` string constants, the `EVENTSUB` / `EVENTUNSUB` / `EVENT` / `EVENTERR` / `EVENTPUB` verb constants, and the `BOT_CAP = "agentirc.io/bot"` capability identifier. `Event.type` is widened to `EventType | str` so federation peers can deliver event types this version doesn't recognise. See `docs/superpowers/specs/2026-05-01-bot-extension-api-design.md` for the full design and `docs/extension-api.md` for the bot-author quick reference.
- `ServerConfig.event_subscription_queue_max: int = 1024` — per-subscription queue bound. Recognised by `ServerConfig.from_yaml` and `cli._resolve_config()` as a top-level YAML key. Consumed by the subscription registry that lands in 9.5.0a3.
- `agentirc.skill` keeps re-exporting `Event` and `EventType` for backward compat; the re-export shim is removed in 9.6.0 once Phase A2 confirms no consumer relies on the path.

### Changed

- `EventType` upgraded from `enum.Enum` to `enum.StrEnum`. Members keep their `.value` strings unchanged, but Python consumers now observe new identity semantics: `isinstance(EventType.JOIN, str)` is `True`, `EventType.JOIN == "user.join"` is `True`, JSON serialization emits the bare string. Internal call sites verified — none compare `EventType.X` against a bare string today, so the truthier equality is pure improvement; downstream consumers that did string-equality round-trips against `EventType` see strictly more matches, never fewer.

### Notes

- This is the **declarations slice** of the bot extension API. No daemon-level behavior changes: `EVENTSUB` etc. are reserved verb constants but the daemon does not yet handle them; `BOT_CAP` is exported but not yet advertised in `CAP LS` output. The wire-format envelope refactor lands in 9.5.0a2; the bot CAP behavior, subscription verbs, `EVENTPUB`, and `webhook_port` unbinding land in 9.5.0a3 / 9.5.0 final.
- Tracks [agentculture/agentirc#15](https://github.com/agentculture/agentirc/issues/15).

## [9.4.1] - 2026-05-01

### Documentation

- Marked the bootstrap closed in `docs/superpowers/specs/2026-04-30-bootstrap-design.md` and `CLAUDE.md`. Tasks 16–18 (tag `v9.4.0`, verify PyPI publish, report-back to culture) are done; the spec status note now reads as a closed timeline ("Released ✅"), and `CLAUDE.md`'s "Current state" reads "bootstrap complete (9.4.0 released)" with a non-blocking follow-ups list linking to issues #7–#12 (Track A wire-format fixes, steward backport, callsite sweep, A2 test migration).
- Fixed 14 stale `OriNachum/*` GitHub URLs in `pyproject.toml` and the bootstrap spec to canonical `agentculture/*` paths. Investigation showed these weren't merely stylistic — `https://github.com/OriNachum/culture` returns 404 and `https://github.com/OriNachum/agentirc` 301-redirects to the wrong path. URL fixes only; sha256s are content-hashed and unaffected. `cite check` still passes.

### Notes

- Functionally identical to `9.4.0`. Published as a fresh PyPI release because `publish.yml` triggers on push-to-`main` and PyPI rejects re-publishing the same version with different sha256.

## [9.4.0] - 2026-05-01

### Added

- `ServerConfig.from_yaml(path)` — public classmethod on
  `agentirc.config.ServerConfig` that loads `~/.culture/server.yaml`
  (or any YAML file). Recognises `server`, `telemetry`, `links`,
  `webhook_port`, `data_dir`, `system_bots` keys; silently ignores
  culture-only top-level keys (`supervisor`, `agents`, `buffer_size`,
  `poll_interval`, `sleep_start`, `sleep_end`, `webhooks`) so the same
  file can drive both `culture server` and `agentirc` daemons.
- CLI handlers (`serve`, `start`, `restart`) now overlay CLI flags on
  top of YAML config. Precedence: explicit CLI flag (sentinel-`None`
  detection) > YAML key > built-in default. Closes the bootstrap
  acceptance criterion *"`agentirc start --config <path>` behaves
  indistinguishably from `culture server start`"*.
- New runtime dependency: `pyyaml>=6.0`.
- `docs/api-stability.md` — semver contract for the three public
  modules (`agentirc.config`, `agentirc.cli`, `agentirc.protocol`),
  full member list per module, internal-may-refactor list, wire-format
  quirks paragraph, versioning history.
- `docs/cli.md` — verb table (8 verbs), per-verb flag reference, exit
  codes, stderr formatting, YAML/CLI precedence, and the agentirc-vs-
  culture differences table.
- `docs/deployment.md` — on-disk footprint, systemd `Type=simple`
  example unit, container deployment, standalone deployment,
  multi-host federation, log rotation (logrotate `copytruncate` rule),
  coexistence with culture, backup recommendations.

### Changed

- `agentirc/cli.py:_add_start_flags` — argparse defaults for `--name`,
  `--host`, `--port`, `--link`, `--webhook-port`, `--data-dir` are now
  sentinel `None` rather than concrete values. The user-visible
  defaults (`0.0.0.0`, `6667`, `7680`, `~/.culture/data`) are still
  documented in help strings and live on the `ServerConfig` dataclass;
  the change lets `_resolve_config` distinguish "user-supplied" from
  "argparse-filled" when overlaying CLI on YAML.

### Removed

- `agentirc/cli.py:_maybe_warn_unused_config` — the
  *"`--config` was supplied, but YAML config loading is not yet wired
  (PR-B4)"* warning that PR #4 review (Qodo + Copilot) requested. YAML
  loading is now wired; the warning was the placeholder for this PR.

### Notes

- Bootstrap is functionally + docs complete as of 9.4.0. Remaining
  work per the spec status note: acceptance-criteria spot-check (Task
  14) and release ceremony (Tasks 16–18 — tag, publish, report-back to
  culture). The cross-repo wire-format fixes (Track A) and steward
  backport of `pr-sonar.sh` are the only outstanding follow-ups.
- 13 new tests in `tests/test_config_loader.py` exercise
  `ServerConfig.from_yaml` (missing/empty/malformed files, unknown-key
  tolerance, telemetry/links sections) and the `_resolve_config` merge
  (CLI overrides YAML, YAML used when CLI absent, defaults on both
  absent, links wholesale-replace). Total suite: 328 tests, ~28s under
  `pytest -n auto`.

## [9.3.0] - 2026-05-01

### Added

- Test suite migration (PR-B3): 36 server-core / telemetry tests
  vendored from `culture@df50942` (~6,500 LOC). 315 tests run under
  `pytest -n auto` in ~29 seconds.
  - 21 server-core tests in `tests/` cover IRC lifecycle, channels,
    rooms, threads, history, federation (S2S), events, mentions,
    and the icon skill.
  - 15 telemetry integration tests in `tests/telemetry/` cover audit
    JSONL emission, OTLP span injection on dispatch, S2S relay
    spans, metrics initialization, and trace-context propagation.
  - Test helper modules `_fakes.py` and `_metrics_helpers.py` also
    vendored verbatim under the same package.
- `tests/conftest.py` — adapted from culture. Drops the
  `_BOTS_DIR_*` patches and the `server_with_bot` /
  `server_with_bots` fixtures (see Changed below). Keeps the
  `IRCTestClient` raw-TCP helper and the IRCd lifecycle, telemetry,
  and audit fixtures.
- `.claude/skills/pr-review/scripts/pr-sonar.sh` — new script that
  fetches every SonarCloud issue, security hotspot, and duplication
  measure for a PR via the SonarCloud API. `workflow.sh poll` now
  runs it after `pr-comments.sh`; `workflow.sh sonar <PR>` runs it
  standalone. Closes the gap where the GitHub-side poll only saw
  the SonarCloud bot's "Quality Gate failed" link without the
  underlying findings. Re-vendor to `steward` after this PR merges.
- Three `[tool.citation]` packages:
  `culture-tests-conftest` (paraphrase),
  `culture-tests-server-core` (mostly quote, paraphrase for
  `test_events_basic.py`), and `culture-tests-telemetry` (mostly
  quote, paraphrase for `test_tracing.py`).

### Changed

- `agentirc/server_link.py:_replay_event` — parameter renamed from
  `_seq` (PR-B1's unused-arg compliance variant) back to `seq` to
  match the upstream signature culture's tests assume; signature
  carries `# noqa: ARG002 # NOSONAR S1172`. Hash refreshed.

### Fixed (post-review)

- `requires-python = ">=3.10"` → `">=3.11"`; classifiers updated
  (drop 3.10, add 3.13). Resolves Copilot/Qodo "asyncio.timeout
  not in 3.10" findings. The 3.10 floor was inherited from PR-B1/B2
  and would have ImportError'd on the first test run.
- 2 SonarCloud `python:S5332` security hotspots cleared via
  `# NOSONAR S5332` annotations on `tests/telemetry/test_config.py`'s
  localhost OTLP test fixtures (URLs never reach the wire).
- New `tests/_helpers.py` (agentirc-native, not cited) extracts the
  duplicated "boot two linked IRCds" pattern into `boot_linked_pair`
  + `link_pair`. Refactored 9 sites that previously inlined ~22
  lines of identical scaffolding: 5 in `test_federation.py`, 3 in
  `test_link_reconnect.py`, plus the `linked_servers` conftest
  fixture. Drops ~180 duplicated lines, addressing SonarCloud's
  >3% duplication threshold while keeping the cited test bodies
  readable. Re-snapshots from culture replay this extraction
  mechanically.
- 42 SonarCloud OPEN issues cleared via inline `# NOSONAR <rule>`
  annotations: `python:S1172` (server_link `_replay_event`'s upstream
  signature compat), `python:S2068` (3 test fixture passwords),
  `python:S7483` (3 `IRCTestClient.recv*` / `_wait_for_span` timeout
  params kept by upstream design — see `RECV_TIMEOUT_SECONDS`
  module-level note), `python:S7494` (2 `dict(t.split("=") for t in
  tags)` patterns vendored verbatim from culture), `python:S125`
  (1 `# 311 RPL_WHOISUSER` documentation comment SonarCloud
  misclassified as commented-out code), `python:S1481` × 21
  (`server_a, server_b = linked_servers` tuple-unpack sites where
  one or both vars are used by the federation fixture but unread in
  the test body — same idiom across 3 files; underscore-prefix
  rename would diverge from culture upstream and complicate
  re-snapshots).

### Deferred / out of scope

- Three bot-fixtured telemetry tests
  (`test_bot_event_dispatch_span.py`, `test_bot_run_span.py`,
  `test_metrics_bots.py`) and `test_welcome_bot.py` stay in culture
  — they depend on the real `BotManager` (forbidden by agentirc's
  dependency boundary). Bucket C tests (cli/console/daemon/clients)
  also remain in culture indefinitely.
- `tests/telemetry/conftest.py` is not migrated; its only consumer
  was the deferred bot-fixtured tests above.
- Bootstrap docs (`docs/api-stability.md`, `docs/cli.md`,
  `docs/deployment.md`) ship in PR-B4.

## [9.2.0] - 2026-05-01

### Added

- `agentirc/protocol.py` — public, semver-tracked module consolidating
  IRC verb names, numeric reply codes (re-exported from
  `_internal.protocol.replies`), and IRCv3 / agentirc tag names. Wire-
  format quirks (`ROOMETAEND`, `ROOMETASET` typos; `ERR_NOSUCHCHANNEL`
  semantic misuse; `STHREAD` verb collapse) are preserved verbatim with
  explanatory comments — they require coordinated cross-repo bumps to
  fix.
- `agentirc/client.py` — IRC client transport vendored from
  `culture/agentirc/client.py` at SHA `df50942`. Body unchanged; only
  imports rewritten. The bootstrap spec originally said this would
  "stay in culture" but its dependency surface (already-vendored
  `_internal` support modules + opentelemetry) made vendoring the
  cleaner path. Without it, `agentirc/ircd.py:580`'s runtime
  `from agentirc.client import Client` raised `ImportError` on the
  first TCP IRC connection.
- Real `agentirc/cli.py` — verb dispatch extracted from
  `culture/cli/server.py`. New verbs: `serve` (foreground, no PID;
  for systemd `Type=simple` and containers), `restart`, `link`
  (peer-spec validator), `logs` (cat / tail of `~/.culture/logs/server-
  <name>.log`). Existing verbs `start`/`stop`/`status` reuse culture's
  proven daemonize / `_wait_for_port` / `_wait_for_graceful_stop` /
  `_force_kill` helpers.
- Internal support modules:
  - `agentirc/_internal/pidfile.py` — PID/port file management.
    `is_managed_process()` recognizes both `culture` and
    `agentirc`/`agentirc-cli` argv tokens; `is_culture_process` is
    preserved as a thin alias.
  - `agentirc/_internal/cli_shared/{constants,mesh}.py` — minimal
    subset of `culture/cli/shared`. Keeps `DEFAULT_CONFIG`, `LOG_DIR`,
    `culture_runtime_dir()`, `parse_link()`. Drops everything that
    touched `culture.bots.config`, `culture.credentials`,
    `culture.mesh_config`.
- Citations recorded in `[tool.citation]`: `culture-pidfile`,
  `culture-cli-shared`, `culture-client`, `culture-cli-server`.

### Changed

- Default server name changed from `culture` to `agentirc` in
  `agentirc.cli`. PID/port files at `~/.culture/pids/server-<name>.{pid,
  port}` keep their existing layout per the "Defaults preserve culture
  continuity" rule, but the default fallback name no longer collides
  with culture's daemon when both run on the same host.
- Dropped culture-only verbs (`default`, `rename`, `archive`,
  `unarchive`) from agentirc's CLI surface — they manage culture's
  agent manifest, which agentirc does not own.
- Dropped `--mesh-config` from `agentirc start` — depends on
  `culture.credentials` / `culture.mesh_config` (out of scope).

### Notes

- End-to-end smoke verified: `agentirc start --port 16667` boots,
  TCP NICK/USER handshake returns `001 RPL_WELCOME` from a real
  `IRCd`, `agentirc stop` shuts cleanly. `agentirc serve` is now
  byte-indistinguishable from `culture server start` for the lifecycle
  contract culture's shim relies on.
- Test suite migration (PR-B3) is the only remaining bootstrap slice.

## [9.1.0] - 2026-04-30

### Added

- Server-core vendored from `culture` at SHA `df50942`. The `agentirc`
  package now contains the IRCd (`ircd.py`), server-to-server linking
  (`server_link.py`), channel/event/store/skill modules, `remote_client.py`
  (peer-server ghost client), and the four built-in skills
  (`skills/{rooms,threads,history,icon}.py`).
- Internal vendored support modules under `agentirc/_internal/`:
  - `aio` (`maybe_await`)
  - `constants` (system user/channel constants)
  - `protocol/` (IRC `Message` and numeric `replies`)
  - `telemetry/` (OpenTelemetry audit/tracing/metrics — full subpackage)
  - `virtual_client` (`VirtualClient` for in-process bot integration)
  - `bots/{bot_manager,http_listener}` (no-op stubs; culture replaces
    these at runtime when wrapping an `IRCd`)
- `[tool.citation]` block in `pyproject.toml` enumerating every vendored
  file with a quote/paraphrase/synthesize status, source URL, and
  sha256, validated by `cite check`.
- Runtime dependencies: `opentelemetry-api`, `opentelemetry-sdk`,
  `opentelemetry-exporter-otlp-proto-grpc` (all `>=1.22`).
- Dev dependency: `citation-cli` (provides the `cite` console script).

### Changed

- Bootstrap spec deviation: `remote_client.py` was originally listed as
  "do not copy" but turned out to be server-side (used by `server_link`
  and `virtual_client` for peer-server users in channel member lists).
  Vendored as public `agentirc/remote_client.py`. See commit `8b4a6d8`.

### Notes

- `agentirc/cli.py` still ships only `version`; the `serve|start|stop|
  restart|status|link|logs` lifecycle verbs remain stubs. The real CLI
  is the next slice (PR-B2).
- Tests are not migrated yet (PR-B3).

## [9.0.0] - 2026-04-30

### Added

- Initial bootstrap of `agentirc-cli` as an installable Python package.
- Skeleton `agentirc/{__init__,__main__,cli}.py` with `version` verb
  wired up and lifecycle verbs (`serve|start|stop|restart|status|link|
  logs`) as stubs.
- Console scripts: both `agentirc` and `agentirc-cli` map to
  `agentirc.cli:main`.
- Major version starts at `9.0.0` to leapfrog the
  `agentirc-cli==8.7.X.devN` squat that culture previously published to
  TestPyPI, so dev releases sort as the actual "Latest".
