
# 📂 System Architecture


The `bizutl` suite is designed with a clean separation of concerns, ensuring high performance and modularity.

[Full Documentation & Architecture (with Diagrams) at Codeberg](https://codeberg.org/yellow-x-black/bizutl)

[Wiki at Codeberg](https://codeberg.org/yellow-x-black/bizutl/wiki)

* ***File explorer***

    * Foundational navigation & keyword search (Recursive)

* ***File to markdown***

    * Universal file-to-markdown utility

* ***Japan stats api***

    * High-performance e-stat integration (asyncio)

* ***Office to pdf***

    * Office document conversion (Libre/soffice)

* ***Pdf editor***

    * PDF viewing and editing (pypdf)

```text

bizutl/

├── LICENSE
├── README.md
├── bizutl
│   ├── config
│   ├── file_explorer
│   ├── file_to_markdown
│   ├── japan_stats_api
│   ├── launcher
│   │   ├── bizutl_cli.py / # Unified CLI Entry Point
│   │   └── bizutl_gui.py / # Unified GUI Entry Point
│   ├── office_to_pdf
│   └── pdf_editor
├── docs
│   └── assets / # Logo
├── pyproject.toml
├── tests / # Global test suite
└── uv.lock
```
