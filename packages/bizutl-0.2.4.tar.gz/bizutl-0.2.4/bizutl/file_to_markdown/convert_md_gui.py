import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QDir, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QLabel,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from bizutl.config.base_config import is_wsl
from bizutl.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    GUILogTools,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_settingup_log_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from bizutl.file_to_markdown.converter_md_engine import ConvertToMd


class MainApp_Of_CTM(QMainWindow):
    """GUI app"""

    log: Signal = Signal(str)

    @wrap_settingup_log_with_gui
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.obj_of_lt: GUILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: ConvertToMd = ConvertToMd(self.obj_of_lt.logger)
        self.setup_ui()

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)
        self.obj_of_lt.logger.info(msg)

    @Slot(str)
    def append_log_to_qtextedit(self, msg: str) -> None:
        """Append log to QTextEdit."""
        self.log_area.append(msg)

    @wrap_notifying_result_with_gui
    def setup_ui(self) -> None:
        """Configure the User Interface."""
        # Title
        self.setWindowTitle("Specified file to Markdown file batch conversion app")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # Main
        main_scroll_area: QScrollArea = QScrollArea()
        main_scroll_area.setWidgetResizable(True)
        base_layout.addWidget(main_scroll_area)
        main_container: QWidget = QWidget()
        main_container_layout: QFormLayout = QFormLayout(main_container)
        main_scroll_area.setWidget(main_container)
        # Overview
        overview_area: QTextEdit = QTextEdit()
        overview_area.setReadOnly(True)
        lines_of_overview: list = []
        lines_of_overview.append(
            "Below is a list of file extensions that can be specified as the source for conversion.\n"
        )
        for key, info in self.obj_of_cls.file_types.items():
            values: str = ""
            for value in info:
                values += f"{value}, "
            values = values.rstrip(", ")
            lines_of_overview.append(f"{key}: {values}")
        overview_area.setText("\n".join(lines_of_overview))
        main_container_layout.addRow(QLabel("Notice: "))
        main_container_layout.addRow(overview_area)
        # Source
        self.label_src: QLabel = QLabel("Source directory: Not selected")
        main_container_layout.addRow(self.label_src)
        btn_select_src: QPushButton = QPushButton("Browse the source directory")
        main_container_layout.addRow(btn_select_src)
        btn_select_src.clicked.connect(self.browse_src_directory)
        btn_open_src: QPushButton = QPushButton("Open the source directory")
        main_container_layout.addRow(btn_open_src)
        btn_open_src.clicked.connect(self.open_explorer_in_src_directory)
        # List of target files
        main_container_layout.addRow(QLabel("List of files to be converted: "))
        self.lst_widget: QListWidget = QListWidget()
        main_container_layout.addRow(self.lst_widget)
        # Destination
        self.label_dst: QLabel = QLabel("Destination directory: Not selected")
        main_container_layout.addRow(self.label_dst)
        btn_select_dst: QPushButton = QPushButton("Browse the destination directory")
        main_container_layout.addRow(btn_select_dst)
        btn_select_dst.clicked.connect(self.browse_dst_directory)
        btn_open_dst: QPushButton = QPushButton("Open the destination directory")
        main_container_layout.addRow(btn_open_dst)
        btn_open_dst.clicked.connect(self.open_explorer_in_dst_directory)
        # Progress
        main_container_layout.addRow(QLabel("Progress: "))
        self.progress_bar: QProgressBar = QProgressBar()
        main_container_layout.addRow(self.progress_bar)
        # Execute
        btn_convert: QPushButton = QPushButton("Execute")
        main_container_layout.addRow(btn_convert)
        btn_convert.clicked.connect(self.convert_all_files)
        # Log
        self.log_area: QTextEdit = QTextEdit()
        self.log_area.setReadOnly(True)
        main_container_layout.addRow(QLabel("Log: "))
        main_container_layout.addRow(self.log_area)

    def display_file_lst(self) -> None:
        """Display the list of files."""
        self.obj_of_cls.create_file_lst()
        self.lst_widget.clear()
        for f in self.obj_of_cls.filtered_lst_of_f:
            file_p: Path = Path(f)
            file_s: str = file_p.name
            self.lst_widget.addItem(file_s)
        self.progress_bar.setValue(0)

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_src_directory(self) -> None:
        """Browse the source directory."""
        self.obj_of_cls.src_directory_path = QFileDialog.getExistingDirectory(
            self,
            caption="Browse source directory",
            dir=QDir.homePath(),
            options=QFileDialog.Option.ShowDirsOnly,
        )
        if not self.obj_of_cls.src_directory_path:
            raise Exception("Browse the source directory.")
        directory_p: Path = Path(self.obj_of_cls.src_directory_path).expanduser()
        self.obj_of_cls.src_directory_path = str(directory_p)
        self.label_src.setText(f"Source directory: {self.obj_of_cls.src_directory_path}")
        if self.obj_of_cls.dst_directory_path:
            self.display_file_lst()

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_dst_directory(self) -> None:
        """Browse the destination directory."""
        self.obj_of_cls.dst_directory_path = QFileDialog.getExistingDirectory(
            self,
            caption="Browse destination directory",
            dir=QDir.homePath(),
            options=QFileDialog.Option.ShowDirsOnly,
        )
        if not self.obj_of_cls.dst_directory_path:
            raise Exception("Browse the destination directory.")
        directory_p: Path = Path(self.obj_of_cls.dst_directory_path).expanduser()
        self.obj_of_cls.dst_directory_path = str(directory_p)
        self.label_dst.setText(f"Destination directory: {self.obj_of_cls.dst_directory_path}")
        if self.obj_of_cls.src_directory_path:
            self.display_file_lst()

    def open_explorer(self, directory_path: str) -> None:
        """Open File Explorer."""
        if directory_path == "":
            raise Exception("Browse the directory.")
        if is_wsl():
            # Convert to Windows path (/mnt/c/... format)
            win_path: str = subprocess.check_output(args=["wslpath", "-w", directory_path], text=True).strip()
            self.showMinimized()
            subprocess.Popen(["explorer.exe", win_path])
        else:
            # Native
            subprocess.Popen(["xdg-open", directory_path])

    @Slot()
    @wrap_notifying_result_with_gui
    def open_explorer_in_src_directory(self) -> None:
        """Open File Explorer in the source directory."""
        self.open_explorer(self.obj_of_cls.src_directory_path)

    @Slot()
    @wrap_notifying_result_with_gui
    def open_explorer_in_dst_directory(self) -> None:
        """Open File Explorer in the destination directory."""
        self.open_explorer(self.obj_of_cls.dst_directory_path)

    @Slot()
    @wrap_notifying_result_with_gui
    def convert_all_files(self) -> None:
        """Convert all files at once."""
        if not self.obj_of_cls.filtered_lst_of_f:
            raise Exception("The file list has not been initialized.")
        self.progress_bar.setRange(0, self.obj_of_cls.number_of_f)
        for i in range(self.obj_of_cls.number_of_f):
            self.obj_of_cls.convert_file()
            self.progress_bar.setValue(i + 1)
            if self.obj_of_cls.complete:
                break
            self.obj_of_cls.move_to_next_file()


def create_window(app: QApplication) -> MainApp_Of_CTM:
    window: MainApp_Of_CTM = MainApp_Of_CTM(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
