from logging import Logger
from pathlib import Path
from typing import Any

from markitdown import MarkItDown

from bizutl.config.base_config import get_log_extra


class ConvertToMd:
    """
    Convert the specified files to the Markdown files.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.logger: Logger = logger
        # Dictionary of extensions
        self.file_types: dict = {
            "PDF": [".pdf"],
            "Excel": [".xlsx"],
            "Word": [".docx"],
            "PowerPoint": [".pptx"],
            "HTML": [".html"],
            "CSV": [".csv"],
            "JSON": [".json"],
            "XML": [".xml"],
        }
        # List of extensions
        self.valid_exts: list = sum(self.file_types.values(), [])
        # Source directory path
        self.src_directory_path: str = ""
        # Destination directory path
        self.dst_directory_path: str = ""
        # List of files after filtering
        self.filtered_lst_of_f: list = []
        # Number of files in the source directory
        self.number_of_f: int = 0
        # markitdown object
        self.md: MarkItDown = MarkItDown()
        # Pointer to the file list
        self.p: int = 0
        # Source file path being processed
        self.current_src_file_path: str = ""
        # Destination file path being processed
        self.current_dst_file_path: str = ""
        # Number of files processed
        self.count: int = 0
        # Number of files successfully processed
        self.success: int = 0
        # Whether all files were converted successfully
        self.complete: bool = False

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
            self.logger.info(
                "Below is a list of file extensions that can be specified as the source for conversion."
            )
            exts: str = "\n"
            for key, info in self.file_types.items():
                values: str = ""
                for value in info:
                    values += f"{value}, "
                values = values.rstrip(", ")
                exts += f"{key}: {values}\n"
            self.logger.info(exts)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def set_file_path(self) -> bool:
        """Set the source and destination file paths for the target file"""
        result: bool = False
        try:
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
            current_file_src_p: Path = Path(self.current_src_file_path)
            current_file_dst_p: Path = Path(self.dst_directory_path) / f"{current_file_src_p.stem}.md"
            self.current_dst_file_path = str(current_file_dst_p)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def create_file_lst(self) -> bool:
        """Create a file list in the source directory"""
        result: bool = False
        # Initialize
        self.p = 0
        self.count = 0
        self.success = 0
        self.complete = False
        try:
            self.filtered_lst_of_f = [
                str(f) for f in Path(self.src_directory_path).glob("*") if f.suffix.lower() in self.valid_exts
            ]
            self.number_of_f = len(self.filtered_lst_of_f)
            if not self.number_of_f:
                raise Exception("There is no source file to convert.")
            self.set_file_path()
        except Exception:
            self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            self.logger.info(f"Number of files: {self.number_of_f}")
            self.logger.info(f"Destination directory: {self.dst_directory_path}")
        finally:
            pass
        return result

    def move_to_previous_file(self) -> bool:
        """Move the target file to the previous file"""
        result: bool = False
        try:
            if not self.p:
                self.p = self.number_of_f - 1
            else:
                self.p -= 1
            self.set_file_path()
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def move_to_next_file(self) -> bool:
        """Move the target file to the next file"""
        result: bool = False
        try:
            if self.p == self.number_of_f - 1:
                self.p = 0
            else:
                self.p += 1
            self.set_file_path()
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def convert_file(self) -> bool:
        """Convert the target file to a Markdown file."""
        result: bool = False
        try:
            self.logger.info(
                f"* [{self.count + 1} / {self.number_of_f}]", extra=get_log_extra(func_flag=True)
            )
            self.logger.info(f"{self.current_src_file_path} => {self.current_dst_file_path}")
            try:
                doc: Any = self.md.convert(self.current_src_file_path)
                current_file_dst_p: Path = Path(self.current_dst_file_path)
                current_file_dst_p.write_text(doc.text_content, encoding="utf-8")
            except Exception:
                self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
                raise
            else:
                self.success += 1
                self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            finally:
                self.count += 1
                if self.count == self.number_of_f:
                    if self.success == self.number_of_f:
                        self.complete = True
                        self.logger.info("***Completed***", extra=get_log_extra(func_flag=True))
                    else:
                        self.logger.error("Some files failed to convert.")
        except Exception:
            raise
        else:
            pass
        finally:
            pass
        return result
