import asyncio
import re
import sys
from logging import Logger

import httpx
import pandas as pd
from pandas.io.parsers import TextFileReader
from PySide6.QtCore import QModelIndex, QObject, Qt, QThread, Signal, Slot
from PySide6.QtGui import QStandardItem, QStandardItemModel
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTableView,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from bizutl.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    GUILogTools,
    clear_widget,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_settingup_log_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from bizutl.japan_stats_api.stats_engine import GetJapanGovernmentStatistics


class GetIdsWorker(QObject):
    """Asynchronous worker for retrieving a list of statistics table IDs."""

    finished: Signal = Signal(bool)
    error: Signal = Signal(str)
    log: Signal = Signal(str)

    def __init__(self, logger: Logger, APP_ID: str, lst_of_data_type: list, lst_of_get_type: list):
        """Constructor"""
        super().__init__()
        # Share
        self.logger: Logger = logger
        self.obj_of_cls: GetJapanGovernmentStatistics = GetJapanGovernmentStatistics(self.logger)
        self.obj_of_cls.APP_ID = APP_ID
        self.obj_of_cls.lst_of_data_type = lst_of_data_type
        self.obj_of_cls.lst_of_get_type = lst_of_get_type
        self.loop: asyncio.AbstractEventLoop | None = None
        self.task: asyncio.Task | None = None

    def execute(self) -> None:
        """Execute."""
        result: bool = False
        try:
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)
            self.task = self.loop.create_task(self.obj_of_cls.export_stats_table_ids_to_csv_file())
            result = self.loop.run_until_complete(self.task)
        except asyncio.CancelledError:
            result = False
        except httpx.HTTPStatusError as e:
            self.error.emit(str(e))
        except httpx.RequestError as e:
            self.error.emit(str(e))
        except Exception as e:
            self.error.emit(str(e))
        else:
            pass
        finally:
            pass
        if self.loop is not None:
            try:
                self.loop.run_until_complete(self.loop.shutdown_asyncgens())
            except Exception:
                pass
            else:
                pass
            finally:
                self.loop.close()
        self.finished.emit(result)

    def cancel(self) -> None:
        """Cancel."""
        if self.loop and self.task:
            self.loop.call_soon_threadsafe(self.task.cancel)


class MainApp_Of_GJGS(QMainWindow):
    """GUI app"""

    log: Signal = Signal(str)

    @wrap_settingup_log_with_gui
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.obj_of_lt: GUILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: GetJapanGovernmentStatistics = GetJapanGovernmentStatistics(self.obj_of_lt.logger)
        self.setup_first_ui()
        self.worker_of_getting_ids: GetIdsWorker | None = None
        self.thread_of_getting_ids: QThread | None = None

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)
        self.obj_of_lt.logger.info(msg)

    @Slot(str)
    def append_log_to_qtextedit(self, msg: str) -> None:
        """Append log to QTextEdit."""
        self.log_area.append(msg)

    @wrap_notifying_result_with_gui
    def setup_first_ui(self) -> None:
        """Configure the first User Interface."""
        # Title
        self.setWindowTitle("Japan government statistics display app")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        # Main
        self.main_layout: QVBoxLayout = QVBoxLayout(central)
        # Top
        self.top_layout: QHBoxLayout = QHBoxLayout()
        self.main_layout.addLayout(self.top_layout, stretch=2)
        # Top left (Statistics table ID)
        self.top_left_grp_bx: QGroupBox = QGroupBox(title="Statistics table ID")
        self.layout_of_top_left: QVBoxLayout = QVBoxLayout(self.top_left_grp_bx)
        self.top_left_scroll_area: QScrollArea = QScrollArea()
        self.top_left_scroll_area.setWidgetResizable(True)
        self.layout_of_top_left.addWidget(self.top_left_scroll_area)
        self.top_layout.addWidget(self.top_left_grp_bx, stretch=1)
        self.setup_second_ui()
        # Top right (Log)
        self.top_right_grp_bx: QGroupBox = QGroupBox(title="Log")
        self.layout_of_top_right: QVBoxLayout = QVBoxLayout(self.top_right_grp_bx)
        self.top_right_scroll_area: QScrollArea = QScrollArea()
        self.top_right_scroll_area.setWidgetResizable(True)
        self.top_right_container: QWidget = QWidget()
        self.top_right_container_layout: QVBoxLayout = QVBoxLayout(self.top_right_container)
        self.log_area: QTextEdit = QTextEdit()
        self.log_area.setReadOnly(True)
        self.top_right_container_layout.addWidget(self.log_area)
        self.top_right_scroll_area.setWidget(self.top_right_container)
        self.layout_of_top_right.addWidget(self.top_right_scroll_area)
        self.top_layout.addWidget(self.top_right_grp_bx, stretch=1)
        # Bottom
        self.bottom_layout: QHBoxLayout = QHBoxLayout()
        self.main_layout.addLayout(self.bottom_layout, stretch=2)
        # Bottom left (Statistics table)
        self.bottom_left_grp_bx: QGroupBox = QGroupBox(title="Statistical table")
        self.layout_of_bottom_left: QVBoxLayout = QVBoxLayout(self.bottom_left_grp_bx)
        self.bottom_left_scroll_area: QScrollArea = QScrollArea()
        self.bottom_left_scroll_area.setWidgetResizable(True)
        self.layout_of_bottom_left.addWidget(self.bottom_left_scroll_area)
        self.bottom_layout.addWidget(self.bottom_left_grp_bx, stretch=1)
        # Bottom right (Functions)
        self.bottom_right_grp_bx: QGroupBox = QGroupBox(title="Function")
        self.layout_of_bottom_right: QVBoxLayout = QVBoxLayout(self.bottom_right_grp_bx)
        self.bottom_right_scroll_area: QScrollArea = QScrollArea()
        self.bottom_right_scroll_area.setWidgetResizable(True)
        self.bottom_right_container: QWidget = QWidget()
        self.bottom_right_container_layout: QVBoxLayout = QVBoxLayout(self.bottom_right_container)
        self.bottom_right_form: QFormLayout = QFormLayout()
        self.bottom_right_container_layout.addLayout(self.bottom_right_form)
        self.bottom_right_scroll_area.setWidget(self.bottom_right_container)
        self.layout_of_bottom_right.addWidget(self.bottom_right_scroll_area)
        self.bottom_layout.addWidget(self.bottom_right_grp_bx, stretch=1)
        # Application ID
        self.app_id_text: QLineEdit = QLineEdit()
        self.app_id_text.editingFinished.connect(self.get_app_id)
        self.bottom_right_form.addRow(QLabel("Application ID: "), self.app_id_text)
        # Data type
        self.data_type_combo: QComboBox = QComboBox()
        for key, desc in self.obj_of_cls.dct_of_data_type.items():
            self.data_type_combo.addItem(f"{key}: {desc}", userData=key)
        self.data_type_combo.currentIndexChanged.connect(self.get_data_type)
        self.get_data_type(0)
        self.bottom_right_form.addRow(QLabel("Data type: "), self.data_type_combo)
        # Retrieval method
        self.get_type_combo: QComboBox = QComboBox()
        for key, desc in self.obj_of_cls.dct_of_get_type.items():
            self.get_type_combo.addItem(f"{key}: {desc}", userData=key)
        self.get_type_combo.currentIndexChanged.connect(self.get_get_type)
        self.get_get_type(0)
        self.bottom_right_form.addRow(QLabel("Get type: "), self.get_type_combo)
        # Retrieve the list of statistics table IDs
        self.get_ids_btn: QPushButton = QPushButton("Get the list of statistical table IDs")
        self.get_ids_btn.clicked.connect(self.get_lst_of_ids)
        # Cancel the retrieval of the list of statistics table IDs
        self.cancel_getting_ids_btn: QPushButton = QPushButton("Cancel")
        self.cancel_getting_ids_btn.clicked.connect(self.cancel_getting_lst_of_ids)
        self.bottom_right_form.addRow(self.get_ids_btn, self.cancel_getting_ids_btn)
        # Display the list of statistics table IDs
        display_ids_btn: QPushButton = QPushButton("Display the list of statistical table IDs")
        self.bottom_right_form.addRow(display_ids_btn)
        display_ids_btn.clicked.connect(self.display_ids)
        # Filter the list of statistics table IDs
        filter_ids_btn: QPushButton = QPushButton("Filter the list of table IDs")
        self.bottom_right_form.addRow(filter_ids_btn)
        filter_ids_btn.clicked.connect(self.filter_lst_of_ids)
        # Filter keyword
        self.keyword_text: QPlainTextEdit = QPlainTextEdit()
        self.keyword_text.textChanged.connect(self.get_keyword)
        self.bottom_right_form.addRow(QLabel("Keywords\n(one keyword per line): "), self.keyword_text)
        # Search method
        self.match_type_combo: QComboBox = QComboBox()
        for key, desc in self.obj_of_cls.dct_of_match_type.items():
            self.match_type_combo.addItem(f"{key}: {desc}", userData=key)
        self.match_type_combo.currentIndexChanged.connect(self.get_match_type)
        self.get_match_type(0)
        self.bottom_right_form.addRow(QLabel("Match type: "), self.match_type_combo)
        # Extraction method
        self.logic_type_combo: QComboBox = QComboBox()
        for key, desc in self.obj_of_cls.dct_of_logic_type.items():
            self.logic_type_combo.addItem(f"{key}: {desc}", userData=key)
        self.logic_type_combo.currentIndexChanged.connect(self.get_logic_type)
        self.get_logic_type(0)
        self.bottom_right_form.addRow(QLabel("Logic type: "), self.logic_type_combo)
        # Display the specified statistics table
        display_table_btn: QPushButton = QPushButton("Display the statistics table")
        self.bottom_right_form.addRow(display_table_btn)
        display_table_btn.clicked.connect(self.display_table)
        # Filter the specified statistics table
        filter_table_btn: QPushButton = QPushButton("Filter the statistics table")
        self.bottom_right_form.addRow(filter_table_btn)
        filter_table_btn.clicked.connect(self.filter_table)
        # Export the specified statistics table to a CSV file
        output_btn: QPushButton = QPushButton("Export the statistics table to CSV file")
        self.bottom_right_form.addRow(output_btn)
        output_btn.clicked.connect(self.output_table)
        # Credits
        credit_area: QVBoxLayout = QVBoxLayout()
        self.main_layout.addLayout(credit_area)
        credit_notation: QLabel = QLabel("\n".join(self.obj_of_cls.credit_text))
        credit_area.addWidget(credit_notation)

    @Slot(QModelIndex)
    def get_id_from_lst(self, index: QModelIndex) -> None:
        """Get the user-specified statistics table ID from the list."""
        if index is None:
            raise Exception("The user-specified statistics table ID could not be obtained.")
        # Row number
        r: int = index.row()
        # Column number
        # Statistics table ID
        c_of_id: int = 0
        # Statistics name
        c_of_stat_name: int = 1
        # Title
        c_of_title: int = 2
        self.obj_of_cls.STATS_DATA_ID = self.top_left_model.item(r, c_of_id).text()
        self.obj_of_cls.STAT_NAME = self.top_left_model.item(r, c_of_stat_name).text()
        self.obj_of_cls.TITLE = self.top_left_model.item(r, c_of_title).text()
        self.display_info(
            f"User-specified statistics table ID: {self.obj_of_cls.STATS_DATA_ID}\n"
            f"Statistic name: {self.obj_of_cls.STAT_NAME}\n"
            f"Title: {self.obj_of_cls.TITLE}"
        )

    def setup_second_ui(self) -> None:
        """Configure the second User Interface."""
        clear_widget(self.top_left_scroll_area)
        self.top_left_container: QWidget = QWidget()
        self.top_left_container_layout: QVBoxLayout = QVBoxLayout(self.top_left_container)
        self.top_left_scroll_area.setWidget(self.top_left_container)
        self.top_left_table: QTableView = QTableView()
        self.top_left_container_layout.addWidget(self.top_left_table)
        self.top_left_model: QStandardItemModel = QStandardItemModel()
        # Add header
        self.top_left_model.setHorizontalHeaderLabels(self.obj_of_cls.header_of_ids_l)
        self.top_left_table.setModel(self.top_left_model)
        self.top_left_table.clicked.connect(self.get_id_from_lst)

    def setup_third_ui(self) -> None:
        """Configure third the User Interface."""
        if self.obj_of_cls.pd_df is None:
            raise Exception("DataFrame is none.")
        clear_widget(self.bottom_left_scroll_area)
        self.bottom_left_container: QWidget = QWidget()
        self.bottom_left_container_layout: QVBoxLayout = QVBoxLayout(self.bottom_left_container)
        self.bottom_left_scroll_area.setWidget(self.bottom_left_container)
        self.bottom_left_table: QTableView = QTableView(self)
        self.bottom_left_container_layout.addWidget(
            QLabel(f"User-specified statistics table ID: {self.obj_of_cls.STATS_DATA_ID}")
        )
        self.bottom_left_container_layout.addWidget(QLabel(f"Statistic name: {self.obj_of_cls.STAT_NAME}"))
        self.bottom_left_container_layout.addWidget(QLabel(f"Title: {self.obj_of_cls.TITLE}"))
        self.bottom_left_container_layout.addWidget(self.bottom_left_table)
        self.bottom_left_model: QStandardItemModel = QStandardItemModel()
        # Add header
        self.bottom_left_model.setHorizontalHeaderLabels(self.obj_of_cls.pd_df.columns.tolist())
        for r in self.obj_of_cls.pd_df.itertuples(index=False):
            items = [QStandardItem(str(v)) for v in r]
            self.bottom_left_model.appendRow(items)
        self.bottom_left_table.setModel(self.bottom_left_model)
        self.bottom_left_table.resizeColumnsToContents()

    def check_first_form(self) -> None:
        """Check the first form entry."""
        if self.obj_of_cls.APP_ID == "":
            raise Exception(
                "Obtain (https://www.e-stat.go.jp/) "
                "and enter the Japan Government Statistics API application ID."
            )
        if not self.obj_of_cls.lst_of_data_type:
            raise Exception("Select the data type.")

    def check_second_form(self) -> None:
        """Check the second form entry."""
        if not self.obj_of_cls.lst_of_match_type:
            raise Exception("Select the match type.")
        if not self.obj_of_cls.lst_of_keyword:
            raise Exception("Enter the keywords.")
        if not self.obj_of_cls.lst_of_logic_type:
            raise Exception("Select the logic type.")
        if len(self.obj_of_cls.lst_of_keyword) == 1:
            # Extraction method is OR only
            self.logic_type_combo.setCurrentIndex(0)

    @Slot()
    def get_app_id(self) -> None:
        """Get the application ID."""
        tmp: str = self.app_id_text.text().strip()
        if not re.fullmatch(r"[a-z0-9]+", tmp):
            raise Exception("Enter the following characters: \n* Lowercase English letters\n* Numbers")
        self.obj_of_cls.APP_ID = tmp

    @Slot(int)
    def get_data_type(self, index: int) -> None:
        """Get the data type."""
        key: str = self.data_type_combo.itemData(index)
        desc: str = self.obj_of_cls.dct_of_data_type[key]
        self.obj_of_cls.lst_of_data_type = [key, desc]

    @Slot(int)
    def get_get_type(self, index: int) -> None:
        """Get the get type."""
        key: str = self.get_type_combo.itemData(index)
        desc: str = self.obj_of_cls.dct_of_get_type[key]
        self.obj_of_cls.lst_of_get_type = [key, desc]

    @Slot(int)
    def get_match_type(self, index: int) -> None:
        """Get the match type."""
        key: str = self.match_type_combo.itemData(index)
        desc: str = self.obj_of_cls.dct_of_match_type[key]
        self.obj_of_cls.lst_of_match_type = [key, desc]

    @Slot(int)
    def get_logic_type(self, index: int) -> None:
        """Get the logic type."""
        key: str = self.logic_type_combo.itemData(index)
        desc: str = self.obj_of_cls.dct_of_logic_type[key]
        self.obj_of_cls.lst_of_logic_type = [key, desc]

    @Slot()
    def get_keyword(self) -> None:
        """Get the keywords."""
        self.obj_of_cls.lst_of_keyword = [
            line.strip() for line in self.keyword_text.toPlainText().splitlines() if line.strip()
        ]

    @Slot(str)
    def setup_when_error_occurs_while_getting_ids(self, error: str) -> None:
        """Setup when error occurs while getting ids."""
        # Disable the cancel button
        self.cancel_getting_ids_btn.setEnabled(False)
        # Enable the retrieve button
        self.get_ids_btn.setEnabled(True)

    @Slot(bool)
    def setup_after_getting_ids(self, flag: bool) -> None:
        """Setup after getting ids."""
        # Disable the cancel button
        self.cancel_getting_ids_btn.setEnabled(False)
        # Enable the retrieve button
        self.get_ids_btn.setEnabled(True)

    @Slot()
    def cleanup_after_getting_ids(self) -> None:
        """Clean up after getting the list of statistics table IDs."""
        self.worker_of_getting_ids = None
        self.thread_of_getting_ids = None

    @Slot()
    @wrap_notifying_result_with_gui
    def get_lst_of_ids(self) -> None:
        """Get the list of statistics table IDs."""
        if self.thread_of_getting_ids is not None and self.thread_of_getting_ids.isRunning():
            raise Exception("Getting the list of statistics table IDs...")
        self.check_first_form()
        # Retrieval method is asynchronous only
        self.get_type_combo.setCurrentIndex(0)
        self.worker_of_getting_ids = GetIdsWorker(
            self.obj_of_lt.logger,
            self.obj_of_cls.APP_ID,
            self.obj_of_cls.lst_of_data_type,
            self.obj_of_cls.lst_of_get_type,
        )
        self.thread_of_getting_ids = QThread()
        self.worker_of_getting_ids.moveToThread(self.thread_of_getting_ids)
        # Enable the cancel button
        self.cancel_getting_ids_btn.setEnabled(True)
        # Disable the retrieve button
        self.get_ids_btn.setEnabled(False)
        self.thread_of_getting_ids.started.connect(self.worker_of_getting_ids.execute)
        self.worker_of_getting_ids.log.connect(
            self.append_log_to_qtextedit, Qt.ConnectionType.QueuedConnection
        )
        self.worker_of_getting_ids.finished.connect(self.thread_of_getting_ids.quit)
        self.worker_of_getting_ids.error.connect(self.thread_of_getting_ids.quit)
        self.worker_of_getting_ids.error.connect(self.setup_when_error_occurs_while_getting_ids)
        self.worker_of_getting_ids.finished.connect(self.setup_after_getting_ids)
        self.thread_of_getting_ids.finished.connect(self.worker_of_getting_ids.deleteLater)
        self.thread_of_getting_ids.finished.connect(self.thread_of_getting_ids.deleteLater)
        self.thread_of_getting_ids.finished.connect(self.cleanup_after_getting_ids)
        self.thread_of_getting_ids.start()

    @Slot()
    @wrap_notifying_result_with_gui
    def cancel_getting_lst_of_ids(self) -> None:
        """Cancel getting the list of statistics table IDs."""
        if self.worker_of_getting_ids is not None:
            self.worker_of_getting_ids.cancel()
        # Disable the cancel button
        self.cancel_getting_ids_btn.setEnabled(False)
        # Disable the retrieve button
        self.get_ids_btn.setEnabled(False)

    @Slot()
    @wrap_notifying_result_with_gui
    def display_ids(self) -> None:
        """Display the list of statistics table IDs."""
        csv_files: list = list(self.obj_of_cls.directory_p_of_ids.glob("*.csv"))
        if not csv_files:
            raise Exception("Get the list of statistical table IDs.")
        self.setup_second_ui()
        for csv_file in csv_files:
            reader: TextFileReader = pd.read_csv(filepath_or_buffer=str(csv_file), chunksize=1, dtype=str)
            for chunk in reader:
                for _, row in chunk.iterrows():
                    items: list = [QStandardItem(str(v)) for v in row]
                    self.top_left_model.appendRow(items)
        self.top_left_table.resizeColumnsToContents()

    @Slot()
    @wrap_notifying_result_with_gui
    def filter_lst_of_ids(self) -> None:
        """Filter the list of statistics table IDs."""
        csv_files: list = list(self.obj_of_cls.directory_p_of_ids.glob(pattern="*.csv"))
        if not csv_files:
            raise Exception("Get the list of statistical table IDs.")
        self.check_second_form()
        self.setup_second_ui()
        for csv_file in csv_files:
            reader: TextFileReader = pd.read_csv(filepath_or_buffer=str(csv_file), chunksize=1, dtype=str)
            for chunk in reader:
                pd_df: pd.DataFrame = self.obj_of_cls.filter_pd_df(chunk)
                for _, row in pd_df.iterrows():
                    items: list = [QStandardItem(str(v)) for v in row]
                    self.top_left_model.appendRow(items)
        self.top_left_table.resizeColumnsToContents()

    @Slot()
    @wrap_notifying_result_with_gui
    def display_table(self) -> None:
        """Display the user-specified statistics table."""
        if self.obj_of_cls.STATS_DATA_ID == "":
            raise Exception("Select statistics table ID.")
        self.check_first_form()
        # Retrieval method is synchronous only
        self.get_type_combo.setCurrentIndex(1)
        self.obj_of_cls.get_user_specified_stats_table()
        self.setup_third_ui()

    @Slot()
    @wrap_notifying_result_with_gui
    def filter_table(self) -> None:
        """Filter the user-specified statistics table."""
        if self.obj_of_cls.pd_df is None:
            raise Exception("DataFrame is none.")
        self.check_second_form()
        self.obj_of_cls.pd_df = self.obj_of_cls.filter_pd_df(self.obj_of_cls.pd_df)
        self.setup_third_ui()
        self.obj_of_cls.print_user_specified_stats_table()

    @Slot()
    @wrap_notifying_result_with_gui
    def output_table(self) -> None:
        """Export the user-specified statistics table to CSV file."""
        if self.obj_of_cls.pd_df is None:
            raise Exception("DataFrame is none.")
        self.obj_of_cls.export_user_specified_stats_table_to_csv_file()


def create_window(app: QApplication) -> MainApp_Of_GJGS:
    window: MainApp_Of_GJGS = MainApp_Of_GJGS(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
