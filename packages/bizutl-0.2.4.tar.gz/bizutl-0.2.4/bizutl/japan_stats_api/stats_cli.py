import asyncio
import re

from bizutl.config.cli_config import (
    CLILogTools,
    input_and_check_number,
    input_bool,
    input_lst,
    wrap_execution_with_cli,
    wrap_repeating_input,
    wrap_settingup_log_with_cli,
    wrap_start_up_with_cli,
)
from bizutl.japan_stats_api.stats_engine import GetJapanGovernmentStatistics


class GJGS_With_Cli:
    @wrap_settingup_log_with_cli
    def __init__(self):
        """Constructor"""
        self.obj_of_lt: CLILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: GetJapanGovernmentStatistics = GetJapanGovernmentStatistics(self.obj_of_lt.logger)

    @wrap_repeating_input
    def input_app_id(self) -> str:
        """Enter your Japan Government Statistics API application ID."""
        app_id: str = ""
        keyward: str = "Japan Government Statistics API application ID"
        app_id = input(f"Obtain (https://www.e-stat.go.jp/) and enter the {keyward}: ").strip()
        if app_id == "":
            raise Exception(f"The {keyward} is not entered.")
        if not re.fullmatch(r"[a-z0-9]+", app_id):
            raise Exception("Enter the following characters: \n* Lowercase English letters\n* Numbers")
        return app_id

    def select_element(self, keyword: str, dct: dict) -> list:
        """Select the element."""
        lst: list = []
        try:
            # Convert to a list
            lst = list(dct.items())
            formatted_lst: list = [f"({i}) {k}: {v}" for i, (k, v) in enumerate(lst, start=1)]
            print(*formatted_lst, sep="\n")
            choice: int = input_and_check_number(keyword, len(lst))
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"Error: \n{str(e)}")
        else:
            pass
        finally:
            pass
        return lst[choice - 1]

    @wrap_repeating_input
    def input_stats_data_id(self) -> str:
        """Enter the statistical table ID."""
        table_id: str = ""
        keyword: str = "statistical table ID"
        # Digits
        DIGIT: int = 10
        table_id = input(f"Enter the {keyword}: ").strip()
        if table_id == "":
            raise Exception(f"The {keyword} is not entered.")
        if not table_id.isdecimal():
            raise Exception(f"The {keyword} is not a number.")
        if len(table_id) != DIGIT:
            raise Exception(f"The {keyword} is {DIGIT} digits.")
        return table_id

    @wrap_execution_with_cli
    async def execute(self) -> bool:
        """Execute."""
        result: bool = False
        self.obj_of_cls.APP_ID = self.input_app_id()
        self.obj_of_cls.lst_of_data_type = self.select_element("data type", self.obj_of_cls.dct_of_data_type)
        if input_bool(
            f"{self.obj_of_cls.export_stats_table_ids_to_csv_file.__doc__} => Would you like to do it?"
        ):
            # Retrieval method is asynchronous only
            self.obj_of_cls.lst_of_get_type = list(list(self.obj_of_cls.dct_of_get_type.items())[0])
            try:
                # Write the statistics table IDs to a CSV file
                await self.obj_of_cls.export_stats_table_ids_to_csv_file()
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
            else:
                pass
            finally:
                pass
        self.obj_of_cls.STATS_DATA_ID = self.input_stats_data_id()
        # Retrieval method is synchronous only
        self.obj_of_cls.lst_of_get_type = list(list(self.obj_of_cls.dct_of_get_type.items())[1])
        self.obj_of_cls.get_user_specified_stats_table()
        if self.obj_of_cls.pd_df is None:
            raise Exception("The DataFrame of the specified statistical table does not exist.")
        self.obj_of_cls.print_user_specified_stats_table()
        if input_bool("Filter the statistics table?"):
            self.obj_of_cls.lst_of_match_type = self.select_element(
                "match type", self.obj_of_cls.dct_of_match_type
            )
            self.obj_of_cls.lst_of_keyword = input_lst(input, "Enter the keyword to filter: ")
            if len(self.obj_of_cls.lst_of_keyword) == 1:
                self.obj_of_cls.lst_of_logic_type = list(list(self.obj_of_cls.dct_of_logic_type.items())[0])
            else:
                self.obj_of_cls.lst_of_logic_type = self.select_element(
                    "logic type", self.obj_of_cls.dct_of_logic_type
                )
            self.obj_of_cls.pd_df = self.obj_of_cls.filter_pd_df(self.obj_of_cls.pd_df)
            self.obj_of_cls.print_user_specified_stats_table()
        if input_bool(
            f"{self.obj_of_cls.export_user_specified_stats_table_to_csv_file.__doc__}"
            " => Would you like to do it?"
        ):
            self.obj_of_cls.export_user_specified_stats_table_to_csv_file()
        result = True
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: GJGS_With_Cli = GJGS_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
