from bizutl.config.cli_config import (
    CLILogTools,
    input_src_dst_directory_path,
    wrap_execution_with_cli,
    wrap_settingup_log_with_cli,
    wrap_start_up_with_cli,
)


class CLTP_With_Cli:
    @wrap_settingup_log_with_cli
    def __init__(self):
        """Constructor"""
        # Error check
        from bizutl.office_to_pdf.converter_pdf_engine import ConvertLibreToPDF

        self.obj_of_lt: CLILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: ConvertLibreToPDF = ConvertLibreToPDF(self.obj_of_lt.logger)

    @wrap_execution_with_cli
    def execute(self) -> bool:
        """Execute."""
        result: bool = False
        self.obj_of_cls.src_directory_path, self.obj_of_cls.dst_directory_path = (
            input_src_dst_directory_path()
        )
        self.obj_of_cls.create_file_lst()
        for _ in range(self.obj_of_cls.number_of_f):
            self.obj_of_cls.convert_file()
            if self.obj_of_cls.complete:
                break
            self.obj_of_cls.move_to_next_file()
        result = True
        return result


@wrap_start_up_with_cli
def main() -> bool:
    result: bool = False
    obj_with_cli: CLTP_With_Cli = CLTP_With_Cli()
    result = obj_with_cli.execute()
    return result


if __name__ == "__main__":
    main()
