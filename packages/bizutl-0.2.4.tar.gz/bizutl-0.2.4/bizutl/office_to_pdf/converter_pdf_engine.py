import shutil
import subprocess
from logging import Logger
from pathlib import Path

from bizutl.config.base_config import get_log_extra


class ConvertLibreToPDF:
    """
    Convert Office files to PDF files.
    LibreOffice required.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.command: str = "soffice"
        # Check if the command path is set correctly
        if not shutil.which(self.command):
            raise ImportError(
                "Install LibreOffice (https://www.libreoffice.org/) "
                f"and add the {self.command} command to your path."
            )
        self.logger: Logger = logger
        # Dictionary of extensions
        self.file_types: dict = {
            "Excel": [".xls", ".xlsx"],
            "Word": [".doc", ".docx"],
            "Powerpoint": [".ppt", ".pptx"],
            "Calc": [".ods"],
            "Writer": [".odt"],
            "Impress": [".odp"],
        }
        # List of extensions
        self.valid_exts: list = sum(self.file_types.values(), [])
        # Source directory path
        self.src_directory_path: str = ""
        # Destination directory path
        self.dst_directory_path: str = ""
        # List of files after filtering
        self.filtered_lst_of_f: list = []
        # Number of files in the source directory
        self.number_of_f: int = 0
        # Pointer to the file list
        self.p: int = 0
        # Source file path being processed
        self.current_src_file_path: str = ""
        # Number of files processed
        self.count: int = 0
        # Number of files successfully processed
        self.success: int = 0
        # Whether all files were converted successfully
        self.complete: bool = False

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
            self.logger.info(
                "Below is a list of file extensions that can be specified as the source for conversion."
            )
            exts: str = "\n"
            for key, info in self.file_types.items():
                values: str = ""
                for value in info:
                    values += f"{value}, "
                values = values.rstrip(", ")
                exts += f"{key}: {values}\n"
            self.logger.info(exts)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def create_file_lst(self) -> bool:
        """Create a file list in the source directory."""
        result: bool = False
        # Initialize
        self.p = 0
        self.count = 0
        self.success = 0
        self.complete = False
        try:
            self.filtered_lst_of_f = [
                str(f) for f in Path(self.src_directory_path).glob("*") if f.suffix.lower() in self.valid_exts
            ]
            self.number_of_f = len(self.filtered_lst_of_f)
            if not self.number_of_f:
                raise Exception("There is no source file to convert.")
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            self.logger.info(f"Number of files: {self.number_of_f}")
            self.logger.info(f"Destination directory: {self.dst_directory_path}")
        finally:
            pass
        return result

    def move_to_previous_file(self) -> bool:
        """Move the target file to the previous file."""
        result: bool = False
        try:
            if not self.p:
                self.p = self.number_of_f - 1
            else:
                self.p -= 1
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def move_to_next_file(self) -> bool:
        """Move the target file to the next file."""
        result: bool = False
        try:
            if self.p == self.number_of_f - 1:
                self.p = 0
            else:
                self.p += 1
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def convert_file(self) -> bool:
        """Convert the file to a PDF file."""
        result: bool = False
        try:
            self.logger.info(
                f"* [{self.count + 1} / {self.number_of_f}]", extra=get_log_extra(func_flag=True)
            )
            self.logger.info(f"{self.current_src_file_path} -> PDF")
            convert_obj: subprocess.CompletedProcess = subprocess.run(
                args=[
                    self.command,
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    self.dst_directory_path,
                    self.current_src_file_path,
                ],
                capture_output=True,
                text=True,
            )
            result = not convert_obj.returncode
            self.count += 1
            if result:
                self.success += 1
                self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            else:
                self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            if self.count == self.number_of_f:
                if self.success == self.number_of_f:
                    self.complete = True
                    self.logger.info("***Completed***", extra=get_log_extra(func_flag=True))
                else:
                    self.logger.error("Some files failed to convert.")
        except Exception:
            raise
        else:
            pass
        finally:
            pass
        return result
