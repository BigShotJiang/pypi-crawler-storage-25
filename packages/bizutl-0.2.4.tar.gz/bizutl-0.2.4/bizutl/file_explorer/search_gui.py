import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QDir, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from bizutl.config.base_config import is_wsl
from bizutl.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    GUILogTools,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_settingup_log_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from bizutl.file_explorer.explorer_engine import GetFileList


class MainApp_Of_GFL(QMainWindow):
    """GUI app"""

    log: Signal = Signal(str)

    @wrap_settingup_log_with_gui
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.obj_of_lt: GUILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: GetFileList = GetFileList(self.obj_of_lt.logger)
        self.setup_ui()

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)
        self.obj_of_lt.logger.info(msg)

    @Slot(str)
    def append_log_to_qtextedit(self, msg: str) -> None:
        """Append log to QTextEdit."""
        self.log_area.append(msg)

    @wrap_notifying_result_with_gui
    def setup_ui(self) -> None:
        """Configure the User Interface."""
        # Title
        self.setWindowTitle("Directory file list display app")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # Main
        main_scroll_area: QScrollArea = QScrollArea()
        main_scroll_area.setWidgetResizable(True)
        base_layout.addWidget(main_scroll_area)
        main_container: QWidget = QWidget()
        main_container_layout: QFormLayout = QFormLayout(main_container)
        main_scroll_area.setWidget(main_container)
        # Directory
        self.directory_label: QLabel = QLabel("Directory: Not selected")
        main_container_layout.addRow(self.directory_label)
        browse_directory_btn: QPushButton = QPushButton("Browse the directory")
        main_container_layout.addRow(browse_directory_btn)
        browse_directory_btn.clicked.connect(self.browse_directory)
        open_directory_btn: QPushButton = QPushButton("Open the directory")
        main_container_layout.addRow(open_directory_btn)
        open_directory_btn.clicked.connect(self.open_explorer)
        # Recursive
        self.recursive_checkbox: QCheckBox = QCheckBox("Search including subdirectories (recursive)")
        main_container_layout.addRow(self.recursive_checkbox)
        self.recursive_checkbox.toggled.connect(self.get_recursive)
        # Search pattern
        main_container_layout.addRow(QLabel("Pattern:"))
        self.pattern_input: QLineEdit = QLineEdit()
        self.pattern_input.setPlaceholderText("Enter a pattern...")
        self.pattern_input.editingFinished.connect(self.get_pattern)
        main_container_layout.addRow(self.pattern_input)
        # Execute
        search_btn: QPushButton = QPushButton("Search by pattern")
        main_container_layout.addRow(search_btn)
        search_btn.clicked.connect(self.search_files)
        # Log
        self.log_area: QTextEdit = QTextEdit()
        self.log_area.setReadOnly(True)
        main_container_layout.addRow(QLabel("Log:"))
        main_container_layout.addRow(self.log_area)

    @Slot()
    def get_recursive(self) -> None:
        """Get whether it is recursive."""
        self.obj_of_cls.recursive = self.recursive_checkbox.isChecked()
        self.obj_of_cls.search_directly_under_directory()

    @Slot()
    def get_pattern(self) -> None:
        """Get the search pattern."""
        self.obj_of_cls.pattern = self.pattern_input.text().strip()

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_directory(self) -> None:
        """Browse the directory."""
        self.obj_of_cls.directory_path = QFileDialog.getExistingDirectory(
            self, caption="Browse the directory", dir=QDir.homePath(), options=QFileDialog.Option.ShowDirsOnly
        )
        if not self.obj_of_cls.directory_path:
            raise Exception("Browse the directory.")
        directory_p: Path = Path(self.obj_of_cls.directory_path).expanduser()
        self.obj_of_cls.directory_path = str(directory_p)
        self.directory_label.setText(self.obj_of_cls.directory_path)
        self.obj_of_cls.search_directly_under_directory()

    @Slot()
    @wrap_notifying_result_with_gui
    def open_explorer(self) -> None:
        """Open File Explorer."""
        if self.obj_of_cls.directory_path == "":
            raise Exception("Browse the directory.")
        if is_wsl():
            # Convert to Windows path (/mnt/c/... format)
            win_path: str = subprocess.check_output(
                args=["wslpath", "-w", self.obj_of_cls.directory_path], text=True
            ).strip()
            self.showMinimized()
            subprocess.Popen(["explorer.exe", win_path])
        else:
            # Native
            subprocess.Popen(["xdg-open", self.obj_of_cls.directory_path])

    @Slot()
    @wrap_notifying_result_with_gui
    def search_files(self) -> None:
        """Search for files."""
        if self.obj_of_cls.directory_path == "":
            raise Exception("Browse the directory.")
        if self.obj_of_cls.pattern == "":
            raise Exception("Pattern is none.")
        self.obj_of_cls.extract_by_pattern()


def create_window(app: QApplication) -> MainApp_Of_GFL:
    window: MainApp_Of_GFL = MainApp_Of_GFL(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
