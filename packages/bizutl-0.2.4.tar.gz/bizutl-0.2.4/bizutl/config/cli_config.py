import asyncio
import inspect
import sys
from functools import wraps
from logging import INFO, Formatter, StreamHandler
from pathlib import Path
from typing import Any, Callable

from bizutl.config.base_config import (
    BaseLogTools,
    CustomBranchFormatter,
    convert_from_dt_type_to_str_type,
    get_log_extra,
)


class CLILogTools(BaseLogTools):
    """
    A utility class for configuring a logger with file, stream handlers.
    ex.
    * logger.debug()
    * logger.info()
    * logger.warning()
    * logger.error()
    * logger.critical()
    """

    def __init__(self):
        """Constructor"""
        super().__init__()

    def setup_stream_handler(self) -> bool:
        """
        Configures and attaches a StreamHandler
        that outputs log messages to standard output.
        """
        result: bool = False
        try:
            self.stream_handler: StreamHandler = StreamHandler(sys.stdout)
            self.stream_handler.setLevel(INFO)
            self.str_of_stream_formatter: str = "%(message)s"
            self.stream_formatter: Formatter = CustomBranchFormatter(fmt=self.str_of_stream_formatter)
            self.stream_handler.setFormatter(self.stream_formatter)
            self.logger.addHandler(self.stream_handler)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result


def wrap_repeating_input(func):
    @wraps(wrapped=func)
    def wrapper(*args, **kwargs):
        result: Any | None = None
        while True:
            try:
                result = func(*args, **kwargs)
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"Error: \n{str(e)}")
            else:
                break
            finally:
                pass
        return result

    return wrapper


@wrap_repeating_input
def input_bool(msg: str) -> bool:
    """Enter yes or no."""
    result: bool = False
    binary_choices: dict = {
        "yes": ("1", "Yes", "yes", "Y", "y"),
        "no": ("0", "No", "no", "N", "n"),
    }
    binary_choice: str = ""
    binary_choice = input(f"{msg}\n(Yes => y or No => n): ").strip()
    match binary_choice:
        case var if var in binary_choices["yes"]:
            result = True
        case var if var in binary_choices["no"]:
            pass
        case _:
            raise Exception("The input is invalid.")
    return result


@wrap_repeating_input
def input_directory_path(keyword: str) -> str:
    """Enter the directory path."""
    directory_s: str = ""
    directory_s = input(f"Enter the {keyword} directory path: ").strip()
    if directory_s == "":
        raise Exception(f"The {keyword} directory path is not entered.")
    directory_p: Path = Path(directory_s).expanduser()
    directory_s = str(directory_p)
    if not directory_p.exists():
        raise Exception(f"The {keyword} directory does not exist.")
    if not directory_p.is_dir():
        raise Exception("The input is not a directory.")
    return directory_s


@wrap_repeating_input
def input_file_path(ext: str) -> str:
    """Enter the file path."""
    file_s: str = ""
    file_type: str = ext.replace(".", "", 1).upper()
    file_s = input(f"Enter the {file_type} file path: ").strip()
    if file_s == "":
        raise Exception(f"The {file_type} file path is not entered.")
    file_p: Path = Path(file_s).expanduser()
    file_s = str(file_p)
    if not file_p.exists():
        raise Exception(f"The {file_type} file does not exist.")
    if not file_p.is_file():
        raise Exception("The input is not a file.")
    if file_p.suffix.lower() != ext:
        raise Exception(f"The file extension is not {ext}.")
    return file_s


@wrap_repeating_input
def input_and_check_number(keyword: str, total: int) -> int:
    """Input and check number."""
    num: int = 0
    value: str = input(f"Enter the {keyword}: ").strip()
    if value == "":
        raise Exception(f"The {keyword} is not entered.")
    if not value.isdecimal():
        raise Exception(f"The {keyword} is not a number.")
    num = int(value)
    if 1 > num or num > total:
        raise Exception(f"The {keyword} is invalid.")
    return num


def input_lst(func: Callable, arg: str) -> list:
    """Enter multiple things."""
    lst: list = []
    try:
        while True:
            print("Enter each one in order.")
            element: str = func(arg)
            lst.append(element)
            keep: bool = input_bool("Is there anything else to enter?")
            if not keep:
                if lst:
                    break
                else:
                    print("Nothing has been entered yet.")
    except KeyboardInterrupt:
        raise
    except Exception as e:
        print(f"Error: \n{str(e)}")
    else:
        pass
    finally:
        pass
    return lst


def input_src_dst_directory_path() -> tuple:
    """Enter the path of the source and destination directories."""
    src_directory_s: str = input_directory_path("source")
    dst_directory_s: str = input_directory_path("destination")
    return (src_directory_s, dst_directory_s)


def wrap_settingup_log_with_cli(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        def _setup_log_with_cli() -> None:
            """Set up log."""
            # Path to the log directory
            directory_p: Path = Path(__file__).parent / "__log__"
            # If the log directory does not exist, create it
            directory_p.mkdir(parents=True, exist_ok=True)
            # Log file name
            file_name: str = f"log_{convert_from_dt_type_to_str_type("for_file_name")}.log"
            file_p: Path = directory_p / file_name
            self.obj_of_lt.file_path_of_log = str(file_p)
            self.obj_of_lt.setup_file_handler(self.obj_of_lt.file_path_of_log)
            self.obj_of_lt.setup_stream_handler()
            self.obj_of_lt.logger.propagate = False
            self.obj_of_cls.append_log_for_constructor()

        result: None = None
        self.obj_of_lt: CLILogTools = CLILogTools()
        try:
            func(self, *args, **kwargs)
            _setup_log_with_cli()
        except ImportError as e:
            print(f"Error: \n{str(e)}")
            raise
        except Exception as e:
            print(f"Error: \n{str(e)}")
            raise
        else:
            self.obj_of_lt.log_msg = f"Log file path: \n{self.obj_of_lt.file_path_of_log}"
            self.obj_of_lt.logger.info(self.obj_of_lt.log_msg)
        finally:
            pass
        return result

    return wrapper


def wrap_execution_with_cli(func):
    @wraps(wrapped=func)
    def wrapper(self, *args, **kwargs):
        result: bool = False
        while True:
            try:
                result = func(self, *args, **kwargs)
                if inspect.iscoroutine(result):
                    result = bool(asyncio.run(result))
            except KeyboardInterrupt:
                raise
            except Exception as e:
                self.obj_of_lt.logger.critical(
                    f"***Processing failed.***: \n{str(e)}",
                    extra=get_log_extra(file_flag=True, func_flag=True),
                )
            else:
                self.obj_of_lt.logger.info(
                    "***Processing succeeded.***", extra=get_log_extra(file_flag=True, func_flag=True)
                )
            finally:
                pass
            if input_bool("Do you want to quit the processing?"):
                break
        return result

    return wrapper


def wrap_start_up_with_cli(func):
    @wraps(wrapped=func)
    def wrapper(*args, **kwargs):
        result: bool = False
        try:
            result = func(*args, **kwargs)
        except ImportError:
            sys.exit(0)
        except KeyboardInterrupt:
            sys.exit(0)
        except Exception:
            sys.exit(0)
        else:
            pass
        finally:
            pass
        return result

    return wrapper
