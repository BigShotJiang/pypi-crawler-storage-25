import pytest

from bizutl.office_to_pdf import convert_pdf_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.office_to_pdf.convert_pdf_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        convert_pdf_cli.main()
