import pytest

from bizutl.file_to_markdown import convert_md_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.file_to_markdown.convert_md_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        convert_md_cli.main()
