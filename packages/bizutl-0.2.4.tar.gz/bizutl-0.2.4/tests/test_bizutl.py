import pytest

from bizutl.launcher import bizutl_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.launcher.bizutl_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        bizutl_cli.main()
