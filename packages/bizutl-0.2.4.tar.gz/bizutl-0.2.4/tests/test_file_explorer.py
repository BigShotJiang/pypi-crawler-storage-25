import pytest

from bizutl.file_explorer import search_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.file_explorer.search_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        search_cli.main()
