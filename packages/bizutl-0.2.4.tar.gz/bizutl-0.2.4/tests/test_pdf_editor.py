import pytest

from bizutl.pdf_editor import edit_pdf_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.pdf_editor.edit_pdf_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        edit_pdf_cli.main()
