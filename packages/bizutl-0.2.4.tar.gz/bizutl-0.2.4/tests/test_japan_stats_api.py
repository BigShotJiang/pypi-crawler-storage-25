import pytest

from bizutl.japan_stats_api import stats_cli


def test_func(monkeypatch):
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("bizutl.japan_stats_api.stats_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        stats_cli.main()
