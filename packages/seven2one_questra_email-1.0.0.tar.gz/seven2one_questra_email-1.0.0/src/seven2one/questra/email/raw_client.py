"""Raw client for Questra Email.

Provides direct access to the Email Service REST operations.
"""

from __future__ import annotations

import logging
import os

from seven2one.questra.authentication import QuestraAuthentication

from .operations import EmailOperations
from .transport import RESTTransport

logger = logging.getLogger(__name__)


class _QuestraEmailCore:
    """Low-level REST client for the Questra Email Service.

    Args:
        url: Base URL of the email service.
        auth_client: Authenticated :class:`~seven2one.questra.authentication.QuestraAuthentication` instance.

    Raises:
        ValueError: If ``url`` is not provided and ``QUESTRA_EMAIL_URL`` is not set.
        ValueError: If ``auth_client`` is not authenticated.

    Environment Variables:
        QUESTRA_EMAIL_URL: Fallback for ``url`` if not passed explicitly.

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.email import QuestraEmail

        auth = QuestraAuthentication(url="...", username="svc", password="secret")
        client = QuestraEmail(
            url="https://questra.example.com/emailservice/", auth_client=auth
        )
        result = client.raw.email.get_version()
        ```
    """

    def __init__(
        self,
        url: str | None = None,
        *,
        auth_client: QuestraAuthentication,
    ) -> None:
        url = url or os.getenv("QUESTRA_EMAIL_URL")
        if not url:
            raise ValueError("url is required. Pass url= or set QUESTRA_EMAIL_URL.")

        if not auth_client.is_authenticated():
            raise ValueError(
                "QuestraAuthentication is not authenticated. "
                "Please authenticate the client before passing it."
            )

        logger.info(f"Initializing _QuestraEmailCore. url={url}")

        self._transport = RESTTransport(
            base_url=url,
            get_access_token_func=auth_client.get_access_token,
        )

        self._email = EmailOperations(
            rest_get_func=self._transport.get,
            rest_post_func=self._transport.post,
        )

        logger.info("_QuestraEmailCore initialized successfully")

    @property
    def email(self) -> EmailOperations:
        """Access to email operations."""
        return self._email
