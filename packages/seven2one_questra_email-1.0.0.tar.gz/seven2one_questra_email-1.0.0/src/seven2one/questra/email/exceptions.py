"""
Exceptions for the Questra Email package.
"""

from __future__ import annotations


class EmailError(Exception):
    """Base exception for all Questra Email errors."""


class EmailHTTPError(EmailError):
    """Raised when the email service returns a non-2xx HTTP status code.

    Attributes:
        status_code: The HTTP status code returned by the service.
        response_text: The raw response body, truncated to 500 characters.
    """

    def __init__(self, status_code: int, message: str, response_text: str = "") -> None:
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code
        self.response_text = response_text


class EmailConnectionError(EmailError):
    """Raised when a network or connection error occurs while contacting the email service."""
