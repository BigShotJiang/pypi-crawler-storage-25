"""Attachment wrapper for file uploads in ``send()``."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO


@dataclass
class Attachment:
    """Wraps a file to attach to an email sent via ``send()``.

    ``send()`` detects ``Attachment`` values, reads the file content, and
    transmits it to the email service as base64-encoded data.

    Args:
        file_data: File path (``str``/``Path``), raw bytes, or open binary file
            object (``BinaryIO``).
        filename: Sent to the server. Auto-derived from path when ``None``.
            Required when ``file_data`` is a ``BinaryIO`` or ``bytes``.

    Example:
        ```python
        from seven2one.questra.email import QuestraEmail, Attachment

        # From a file path
        client.send(
            to="user@example.com",
            subject="Report",
            html_body="<p>See attached.</p>",
            attachments=Attachment("/path/to/report.pdf"),
        )

        # From raw bytes (e.g. a generated PDF)
        client.send(
            to="user@example.com",
            subject="Inline",
            text_body="See attached.",
            attachments=Attachment(pdf_bytes, filename="output.pdf"),
        )

        # From an open file object
        with open("scan.pdf", "rb") as f:
            client.send(
                to="user@example.com",
                subject="Scan",
                text_body="See attached.",
                attachments=Attachment(f, filename="scan.pdf"),
            )
        ```
    """

    file_data: str | Path | bytes | BinaryIO
    filename: str | None = field(default=None)

    def resolve_filename(self) -> str:
        """Return the filename to send to the server.

        Returns:
            The explicit ``filename`` if set, otherwise the basename of the path.

        Raises:
            ValueError: If ``file_data`` is a ``BinaryIO`` or ``bytes`` and
                ``filename`` is not set.
        """
        if self.filename is not None:
            return self.filename
        if isinstance(self.file_data, (str, Path)):
            return Path(self.file_data).name
        raise ValueError(
            "Attachment.filename must be provided when file_data is bytes or a file object."
        )

    def read_content(self) -> bytes:
        """Read and return the raw file content.

        Returns:
            The full binary content of the file.

        Raises:
            FileNotFoundError: If ``file_data`` is a path that does not exist.
        """
        if isinstance(self.file_data, bytes):
            return self.file_data
        if isinstance(self.file_data, (str, Path)):
            path = Path(self.file_data)
            if not path.exists():
                raise FileNotFoundError(f"Attachment file not found: {path}")
            return path.read_bytes()
        return self.file_data.read()
