"""Tests for database models, engine, and queries."""

from __future__ import annotations

import pytest
from sqlalchemy import create_engine, inspect

from carbonation.db.engine import init_db, verify_schema
from carbonation.db.models import (
    FileBase,
    FileComponent,
    FileStatus,
    get_file_model,
    validate_extract_metadata,
)
from carbonation.db.queries import (
    bulk_insert_components,
    bulk_mark_cleared,
    find_or_create_file_group,
    get_archive_count,
    get_delivery_count,
    get_status_counts,
    query_files,
    record_component,
    update_component_status,
    update_file_metadata,
)


class TestFileModel:
    def test_get_file_model_returns_registered_subclass(self):
        model = get_file_model()
        assert issubclass(model, FileBase)
        assert model.__tablename__ == "files"

    def test_file_model_has_core_fields(self):
        model = get_file_model()
        column_names = {c.name for c in model.__table__.columns}
        assert "id" in column_names
        assert "watch_name" in column_names
        assert "group_key" in column_names
        assert "complete" in column_names
        assert "created_at" in column_names
        assert "modified_at" in column_names


class TestValidateExtractMetadata:
    def test_valid_metadata(self):
        from datetime import datetime

        errors = validate_extract_metadata(
            {
                "label": "test",
                "start": datetime(2026, 1, 1),
                "stop": datetime(2026, 1, 2),
                "category": "alpha",
                "origin": "sensor-1",
            }
        )
        assert errors == []

    def test_none_for_nullable_column(self):
        errors = validate_extract_metadata({"label": None})
        assert errors == []

    def test_wrong_type(self):
        errors = validate_extract_metadata({"start": "not-a-datetime"})
        assert len(errors) == 1
        assert "expected datetime" in errors[0]
        assert "got str" in errors[0]

    def test_float_column_accepts_float(self):
        errors = validate_extract_metadata({"quality": 0.95})
        assert errors == []

    def test_float_column_accepts_int(self):
        # int is a valid value for a Float column — SQLAlchemy widens it.
        errors = validate_extract_metadata({"quality": 1})
        assert errors == []

    def test_float_column_rejects_string(self):
        # The whole point of the fix: a Float column is now type-checked
        # rather than silently skipped.
        errors = validate_extract_metadata({"quality": "0.95"})
        assert len(errors) == 1
        assert "expected float" in errors[0]
        assert "got str" in errors[0]

    def test_unknown_column(self):
        errors = validate_extract_metadata({"nonexistent": 42})
        assert len(errors) == 1
        assert "Unknown column" in errors[0]

    def test_base_column_rejected(self):
        errors = validate_extract_metadata({"watch_name": "sneaky"})
        assert len(errors) == 1
        assert "base column" in errors[0]

    def test_multiple_errors(self):
        errors = validate_extract_metadata(
            {
                "start": "bad",
                "nonexistent": 42,
            }
        )
        assert len(errors) == 2

    def test_empty_dict_valid(self):
        errors = validate_extract_metadata({})
        assert errors == []


class TestAlembicMigrations:
    def test_core_migration_creates_tables(self):
        """Core alembic branch creates base tables on a fresh database."""
        from carbonation.db.engine import run_migrations

        engine = create_engine("sqlite:///:memory:")
        run_migrations(engine)  # no plugin: only the core branch upgrades

        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert "files" in tables
        assert "file_components" in tables
        assert "service_state" in tables
        assert "alembic_version" in tables
        engine.dispose()

    def test_init_db_runs_plugin_migration(self, test_plugin):
        """init_db runs core + plugin alembic branches; plugin columns appear."""

        engine = create_engine("sqlite:///:memory:")
        init_db(engine, test_plugin.spec)

        inspector = inspect(engine)
        file_columns = {c["name"] for c in inspector.get_columns("files")}
        # Plugin columns from the test plugin's p001 migration
        assert "label" in file_columns
        assert "start" in file_columns
        assert "category" in file_columns
        # Base columns from core migration
        assert "watch_name" in file_columns
        assert "group_key" in file_columns
        engine.dispose()

    def test_init_db_idempotent(self, test_plugin):
        """Running init_db twice doesn't fail."""

        engine = create_engine("sqlite:///:memory:")
        init_db(engine, test_plugin.spec)
        init_db(engine, test_plugin.spec)
        engine.dispose()

    def test_no_drift_after_init(self, test_plugin):
        """No drift after a fresh init_db (drift now == missing tables only)."""
        from carbonation.db.engine import check_schema_drift

        engine = create_engine("sqlite:///:memory:")
        init_db(engine, test_plugin.spec)
        drift = check_schema_drift(engine)
        assert drift == []
        engine.dispose()

    def test_drift_detects_missing_required_table(self):
        """check_schema_drift flags an empty database (no tables exist)."""
        from carbonation.db.engine import check_schema_drift

        engine = create_engine("sqlite:///:memory:")
        drift = check_schema_drift(engine)
        # Three required tables, none of them exist yet.
        assert len(drift) == 3
        assert any("files" in d for d in drift)
        assert any("file_components" in d for d in drift)
        assert any("service_state" in d for d in drift)
        engine.dispose()


class TestSchemaCreation:
    def test_creates_both_tables(self, db_engine):
        inspector = inspect(db_engine)
        tables = set(inspector.get_table_names())
        assert "files" in tables
        assert "file_components" in tables

    def test_file_components_columns(self, db_engine):
        inspector = inspect(db_engine)
        columns = {c["name"] for c in inspector.get_columns("file_components")}
        expected = {
            "id",
            "watch_name",
            "filename",
            "source_path",
            "archive_path",
            "size_bytes",
            "status",
            "in_delivery",
            "in_archive",
            "group_id",
            "error_message",
            "detected_at",
            "archived_at",
            "cleared_at",
            "metadata",
        }
        assert expected.issubset(columns)

    def test_file_components_has_fk_to_files(self, db_engine):
        inspector = inspect(db_engine)
        fks = inspector.get_foreign_keys("file_components")
        fk_tables = {fk["referred_table"] for fk in fks}
        assert "files" in fk_tables

    def test_verify_schema_succeeds(self, db_engine):
        assert verify_schema(db_engine) is True

    def test_verify_schema_fails_on_empty_db(self):
        engine = create_engine("sqlite:///:memory:")
        assert verify_schema(engine) is False
        engine.dispose()


class TestRecordComponent:
    def test_inserts_and_returns_id(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
            size_bytes=1024,
        )
        assert isinstance(cid, int)
        assert cid > 0

    def test_defaults_to_detected_status(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.DETECTED

    def test_unique_source_path(self, db_session):
        record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        with pytest.raises(Exception):  # IntegrityError
            record_component(
                db_session,
                watch_name="test",
                filename="data.csv",
                source_path="/delivery/data.csv",
            )


class TestUpdateComponentStatus:
    def test_updates_status(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(db_session, cid, FileStatus.WAITING)
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.WAITING

    def test_archived_sets_in_archive(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(
            db_session,
            cid,
            FileStatus.ARCHIVED,
            archive_path="/archive/data.csv",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.ARCHIVED
        assert row.in_archive is True
        assert row.archived_at is not None
        assert row.archive_path == "/archive/data.csv"

    def test_cleared_sets_in_delivery_false(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(db_session, cid, FileStatus.CLEARED)
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.CLEARED
        assert row.in_delivery is False
        assert row.cleared_at is not None

    def test_error_message_stored(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(
            db_session,
            cid,
            FileStatus.FAILED,
            error_message="disk full",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.error_message == "disk full"


class TestBulkOperations:
    def _insert_three(self, db_session):
        """Helper: insert 3 components, return their ids."""
        ids = []
        for i in range(3):
            cid = record_component(
                db_session,
                watch_name="test",
                filename=f"file{i}.csv",
                source_path=f"/delivery/file{i}.csv",
                size_bytes=100 * (i + 1),
            )
            ids.append(cid)
        return ids

    def test_bulk_insert(self, db_session):
        records = [
            {
                "watch_name": "test",
                "filename": f"bulk{i}.csv",
                "source_path": f"/delivery/bulk{i}.csv",
                "size_bytes": 500,
                "status": FileStatus.DETECTED,
                "in_delivery": True,
                "in_archive": False,
            }
            for i in range(5)
        ]
        bulk_insert_components(db_session, records)
        assert get_delivery_count(db_session) == 5

    def test_bulk_insert_empty(self, db_session):
        bulk_insert_components(db_session, [])
        assert get_delivery_count(db_session) == 0

    def test_bulk_insert_across_chunk_boundary(self, db_session):
        """Bug #15 (Phase 3a): a first-run reconcile with 100k+ files used
        to pack every row into one multi-row INSERT, overflowing dialect
        parameter caps. The chunked implementation must still produce the
        same final row count, with the chunk boundary being irrelevant to
        the caller.
        """
        # SQLite chunk size is 500. Build a batch that spans two chunks
        # plus a partial tail to exercise all three loop shapes.
        n = 1200
        records = [
            {
                "watch_name": "test",
                "filename": f"chunk{i}.csv",
                "source_path": f"/delivery/chunk{i}.csv",
                "size_bytes": 100,
                "status": FileStatus.DETECTED,
                "in_delivery": True,
                "in_archive": False,
            }
            for i in range(n)
        ]
        bulk_insert_components(db_session, records)
        assert get_delivery_count(db_session) == n

    def test_bulk_insert_ignore_conflicts_chunked(self, db_session):
        """Chunked ON CONFLICT DO NOTHING path still dedups against existing rows."""
        # Seed one row that will collide with the bulk insert's first record.
        bulk_insert_components(
            db_session,
            [
                {
                    "watch_name": "test",
                    "filename": "dup0.csv",
                    "source_path": "/delivery/dup0.csv",
                    "size_bytes": 1,
                    "status": FileStatus.DETECTED,
                    "in_delivery": True,
                    "in_archive": False,
                }
            ],
        )
        # Now bulk-insert 800 records (spans chunk boundary) including the
        # duplicate. ignore_conflicts should skip the dup; count becomes 800.
        records = [
            {
                "watch_name": "test",
                "filename": f"dup{i}.csv",
                "source_path": f"/delivery/dup{i}.csv",
                "size_bytes": 1,
                "status": FileStatus.DETECTED,
                "in_delivery": True,
                "in_archive": False,
            }
            for i in range(800)
        ]
        bulk_insert_components(db_session, records, ignore_conflicts=True)
        assert get_delivery_count(db_session) == 800

    def test_bulk_mark_cleared(self, db_session):
        ids = self._insert_three(db_session)
        bulk_mark_cleared(db_session, ids)

        for cid in ids:
            row = db_session.execute(
                FileComponent.__table__.select().where(
                    FileComponent.__table__.c.id == cid
                )
            ).first()
            assert row.in_delivery is False
            assert row.status == FileStatus.CLEARED

    def test_bulk_mark_cleared_preserves_archived(self, db_session):
        ids = self._insert_three(db_session)
        # Mark first as archived
        update_component_status(
            db_session,
            ids[0],
            FileStatus.ARCHIVED,
            archive_path="/archive/file0.csv",
        )
        bulk_mark_cleared(db_session, ids)

        # Archived should keep its status
        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[0]
            )
        ).first()
        assert row.status == FileStatus.ARCHIVED
        assert row.in_delivery is False  # still marked as not in delivery

    def test_bulk_mark_cleared_preserves_failed(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(
            db_session,
            ids[1],
            FileStatus.FAILED,
            error_message="disk full",
        )
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[1]
            )
        ).first()
        assert row.status == FileStatus.FAILED

    def test_bulk_mark_cleared_replaces_timed_out(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(db_session, ids[2], FileStatus.TIMED_OUT)
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[2]
            )
        ).first()
        assert row.status == FileStatus.CLEARED

    def test_bulk_mark_cleared_replaces_not_selected(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(db_session, ids[2], FileStatus.NOT_SELECTED)
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[2]
            )
        ).first()
        assert row.status == FileStatus.CLEARED


class TestQueryHelpers:
    def test_get_status_counts(self, db_session):
        for i in range(3):
            record_component(
                db_session,
                watch_name="test",
                filename=f"f{i}.csv",
                source_path=f"/d/f{i}.csv",
            )
        update_component_status(
            db_session, 1, FileStatus.ARCHIVED, archive_path="/a/f0.csv"
        )
        update_component_status(db_session, 2, FileStatus.WAITING)

        counts = get_status_counts(db_session)
        assert counts.get("archived", 0) == 1
        assert counts.get("waiting", 0) == 1
        assert counts.get("detected", 0) == 1

    def test_get_delivery_count(self, db_session):
        for i in range(3):
            record_component(
                db_session,
                watch_name="test",
                filename=f"f{i}.csv",
                source_path=f"/d/f{i}.csv",
            )
        assert get_delivery_count(db_session) == 3

        # Clear one
        update_component_status(db_session, 1, FileStatus.CLEARED)
        assert get_delivery_count(db_session) == 2

    def test_get_archive_count(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="f.csv",
            source_path="/d/f.csv",
        )
        assert get_archive_count(db_session) == 0

        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path="/a/f.csv"
        )
        assert get_archive_count(db_session) == 1


class TestFindOrCreateFileGroupRollback:
    """Bug #17 (Phase 2g): on IntegrityError (concurrent worker created
    the same group first), the function used to call ``session.rollback()``
    — discarding any uncommitted upstream work in the outer transaction.
    The savepoint-based fix must localize the rollback to the failed
    INSERT only.
    """

    def test_outer_writes_survive_conflict_recovery(self, db_session, monkeypatch):
        # Pre-create the group through a normal commit so the recovery
        # SELECT inside the IntegrityError handler will find it.
        gid_pre = find_or_create_file_group(
            db_session, watch_name="w", group_key="k", file_type="t"
        )
        db_session.commit()

        # Stage an upstream write in the outer transaction.
        cid = record_component(
            db_session,
            watch_name="w",
            filename="upstream.csv",
            source_path="/delivery/upstream.csv",
            size_bytes=42,
        )

        # Force find_or_create's SELECT to miss so the INSERT path runs,
        # then have the INSERT raise IntegrityError as if a concurrent
        # worker beat us to it.
        from sqlalchemy.exc import IntegrityError

        from carbonation.db import queries as q

        original_execute = db_session.execute
        call_count = {"n": 0}

        def fake_execute(stmt, *args, **kwargs):
            # First two executes inside find_or_create:
            #   1. SELECT (should "miss" so we hit the INSERT branch)
            #   2. INSERT (should raise IntegrityError)
            #   3. SELECT recovery (should succeed)
            call_count["n"] += 1
            if call_count["n"] == 1:
                # Return an empty Result-like that yields .first() == None.
                class _Empty:
                    def first(self):
                        return None

                return _Empty()
            if call_count["n"] == 2:
                raise IntegrityError("simulated", None, Exception("conflict"))
            # Restore real execute for the recovery SELECT and any later calls.
            db_session.execute = original_execute  # type: ignore[method-assign]
            return original_execute(stmt, *args, **kwargs)

        db_session.execute = fake_execute  # type: ignore[method-assign]

        gid = q.find_or_create_file_group(
            db_session, watch_name="w", group_key="k", file_type="t"
        )

        # Recovery returned the pre-existing group id.
        assert gid == gid_pre

        # The outer-transaction insert (record_component) MUST survive.
        comp = q.get_component_by_source_path(db_session, "/delivery/upstream.csv")
        assert comp is not None, (
            "record_component write was discarded by find_or_create's rollback"
        )
        assert comp["id"] == cid
        assert comp["size_bytes"] == 42


class TestQueryFilesScalarFilters:
    """Bug #5 (Phase 1d): unsuffixed scalar filters were silently dropped.

    The original ``query_files`` dispatch chain only handled list/tuple and
    bool values for unsuffixed keys, so ``{"watch_name": "w1"}`` (str) or
    ``{"id": 5}`` (int) returned the entire table with no WHERE clause.
    Documented behavior per the docstring is "exact match" for scalars.
    """

    def _seed_two_groups(self, db_session) -> None:
        """Insert two distinct file rows with different watch_name + label."""
        gid1 = find_or_create_file_group(
            db_session, watch_name="w1", group_key="g1", file_type="t"
        )
        update_file_metadata(db_session, gid1, {"label": "alpha"})
        gid2 = find_or_create_file_group(
            db_session, watch_name="w2", group_key="g2", file_type="t"
        )
        update_file_metadata(db_session, gid2, {"label": "beta"})
        db_session.commit()

    def test_string_filter_applies_equality(self, db_session):
        self._seed_two_groups(db_session)
        rows = query_files(db_session, {"watch_name": "w1"})
        assert len(rows) == 1
        assert rows[0]["watch_name"] == "w1"

    def test_int_filter_applies_equality(self, db_session):
        self._seed_two_groups(db_session)
        # Pick an id that we know exists
        all_rows = query_files(db_session, {})
        target_id = all_rows[0]["id"]

        rows = query_files(db_session, {"id": target_id})
        assert len(rows) == 1
        assert rows[0]["id"] == target_id

    def test_string_filter_no_match_returns_empty(self, db_session):
        self._seed_two_groups(db_session)
        rows = query_files(db_session, {"watch_name": "nonexistent"})
        assert rows == []

    def test_list_filter_still_works(self, db_session):
        """Regression guard: list/IN behavior must not break when scalars are added."""
        self._seed_two_groups(db_session)
        rows = query_files(db_session, {"watch_name": ["w1", "w2"]})
        assert len(rows) == 2
