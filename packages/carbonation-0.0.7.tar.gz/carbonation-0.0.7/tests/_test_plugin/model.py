"""File model for the test plugin.

Fields here must cover both unit-test expectations (``label``) and
integration-test expectations (``start``, ``stop``, ``category``,
``origin``, ``source``). All domain columns are nullable so they can be
populated after group creation.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, String
from sqlalchemy.orm import Mapped, mapped_column

from carbonation.db.models import FileBase


class File(FileBase):
    __tablename__ = "files"

    label: Mapped[str | None] = mapped_column(String(255), nullable=True)
    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True)
    origin: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # Float column exercises the numeric branch of validate_extract_metadata
    # and the float min/max query filters.
    quality: Mapped[float | None] = mapped_column(Float, nullable=True)
