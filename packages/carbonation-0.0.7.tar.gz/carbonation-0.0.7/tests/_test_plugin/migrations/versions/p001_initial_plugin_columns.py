"""Initial plugin columns for the test plugin.

Revision ID: p001
Revises:
Create Date: 2026-04-22
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "p001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = ("test_plugin",)
depends_on: Union[str, Sequence[str], None] = ("core",)


def upgrade() -> None:
    op.add_column("files", sa.Column("label", sa.String(255), nullable=True))
    op.add_column("files", sa.Column("start", sa.DateTime, nullable=True))
    op.add_column("files", sa.Column("stop", sa.DateTime, nullable=True))
    op.add_column("files", sa.Column("category", sa.String(255), nullable=True))
    op.add_column("files", sa.Column("origin", sa.String(255), nullable=True))
    op.add_column("files", sa.Column("source", sa.String(255), nullable=True))
    op.add_column("files", sa.Column("quality", sa.Float, nullable=True))


def downgrade() -> None:
    op.drop_column("files", "quality")
    op.drop_column("files", "source")
    op.drop_column("files", "origin")
    op.drop_column("files", "category")
    op.drop_column("files", "stop")
    op.drop_column("files", "start")
    op.drop_column("files", "label")
