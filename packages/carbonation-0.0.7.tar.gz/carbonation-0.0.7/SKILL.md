---
name: carbonation-plugin
description: Build or modify a carbonation plugin package — the Plugin spec, FileBase model, extractors, plugin rule callables, and alembic plugin-branch migrations. Use when creating a new plugin, adding a typed column, writing an extractor, or wiring selection/routing/grouping functions into rules.toml.
---

# Building a carbonation plugin

A carbonation **plugin** is an installable Python package that teaches the service how to describe *your* files: the typed columns on the `files` table, how files are grouped, how a complete group becomes metadata, and (optionally) selection/routing decisions made in code.

One plugin per carbonation process. It is discovered via the `carbonation.plugin` entry point, or pinned by `[plugins] package = "..."` in `config.toml`.

## Start here: scaffold, don't hand-write

`carbonation init` generates a correct plugin skeleton. Prefer it over building from scratch.

```bash
carbonation init --dir myproject     # writes config.toml, rules.toml, my_plugin/
cd myproject
uv pip install -e ./my_plugin        # install plugin into carbonation's env
carbonation check config             # validate config + rules + plugin wiring
carbonation db init                  # create schema (core + plugin alembic branches)
```

The scaffold is the reference implementation. When unsure how a piece fits, read the generated `my_plugin/`, or the in-repo examples: [examples/my_plugin/](examples/my_plugin/) and [tests/_test_plugin/](tests/_test_plugin/).

## Package layout

```
my_plugin/
├── pyproject.toml               # declares the carbonation.plugin entry point
└── my_plugin/
    ├── __init__.py              # builds `plugin = Plugin(...)`  ← the contract
    ├── model.py                 # FileBase subclass, __tablename__ = "files"
    ├── extractors.py            # extract_* functions
    ├── rules.py                 # optional group / selection / routing callables
    └── migrations/versions/     # alembic revisions (plugin branch)
```

`pyproject.toml` must declare the `carbonation.plugin` entry point. Minimal complete file (matches what `carbonation init` generates):

```toml
[project]
name = "my_plugin"
dynamic = ["version"]
requires-python = ">=3.11"
dependencies = ["carbonation", "sqlalchemy>=2.0"]

[project.entry-points."carbonation.plugin"]
my_plugin = "my_plugin"          # value = import path; carbonation reads its top-level `plugin`

[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"
fallback-version = "0.0.0"

[tool.hatch.build.hooks.vcs]
version-file = "my_plugin/_version.py"

[tool.hatch.build.targets.wheel]
packages = ["my_plugin"]
```

The entry-point value may also target the `Plugin` instance directly (`my_plugin = "my_plugin:plugin"`); both shapes work.

## The Plugin spec (`__init__.py`)

```python
from pathlib import Path
from carbonation import Plugin

from .model import File
from .extractors import extract_sample
from .rules import should_archive, route_by_category

plugin = Plugin(
    file_model=File,                                  # required
    extractors={"sample": extract_sample},            # all dicts optional
    group_functions={},
    selection_functions={"should_archive": should_archive},
    routing_functions={"by_category": route_by_category},
    migrations_path=Path(__file__).parent / "migrations" / "versions",
    query_defaults={"order_by": "-start"},            # optional CLI/API defaults
)
```

Only `file_model` is required. A deployment using only declarative rules can ship `Plugin(file_model=File)`. `query_defaults` keys are `limit` / `order_by` / `columns`; any column name they reference (e.g. `-start`) must exist on your `File` model.

### How each dict is referenced and called

| Plugin dict | `rules.toml` reference | carbonation calls it as |
|---|---|---|
| `extractors` | `[<rs>.metadata]` → `extract = "<name>"` | `fn(file_paths)` — positional `list[Path]` |
| `group_functions` | `[<rs>.completeness]` → `group_by = "plugin"`, `group_function = "<name>"` | `fn(file_path=<Path>)` |
| `selection_functions` | `[[<rs>.selection]]` → `type = "plugin"`, `function = "<name>"`, optional `kwargs` | `fn(metadata=<dict>, **kwargs)` |
| `routing_functions` | `[[<rs>.routing]]` → `type = "plugin"`, `function = "<name>"` | `fn(metadata=<dict>)` (no kwargs) |

(`<rs>` = a rule-set name in `rules.toml`.) Declarative shapes — stem grouping, `has_keys` / `field`+`matches` selection, glob `match`+`archive` routing — live entirely in `rules.toml` and never touch the plugin. Reach for a plugin callable only when the declarative form can't express what you need.

### Callable signatures

```python
def extract(file_paths: list[Path]) -> dict[str, Any]: ...   # keys = File columns
def group(*, file_path: Path) -> str | None: ...             # group name, or None to skip
def select(*, metadata: dict, **kwargs) -> bool: ...         # True = accept group
def route(*, metadata: dict) -> str | None: ...              # archive name, or None -> try next rule (then watch default)
```

Use keyword-only params (`*,`) for group/select/route so future carbonation versions can pass extra context without breaking your signature. Selection/routing functions that raise are caught and treated as reject/fall-through, so a buggy callable fails closed.

The `metadata` dict passed to `select`/`route` is the **full raw extractor output**, not just the typed columns — so functions can read keys that aren't `File` columns (e.g. a `priority` field you extract but don't store as a column).

### Referencing callables from rules.toml

The Plugin dicts are only half the contract; the other half is `rules.toml`. Concrete stanzas for each kind:

```toml
[signal-rules.metadata]
extract = "sample"                       # -> extractors["sample"]

[signal-rules.completeness]
group_by = "plugin"                      # plugin grouping instead of stem
group_function = "by_stem_prefix"        # -> group_functions["by_stem_prefix"]
expected_extensions = [".json", ".dat"]  # all must be present for the group to complete
primary_extension = ".json"              # the group's "main" file

[[signal-rules.selection]]
type = "plugin"
function = "category_allowlist"          # -> selection_functions["category_allowlist"]
kwargs = { allowed = ["alpha", "beta"] } # each key becomes a NAMED arg: select(*, metadata, allowed=...)

[[signal-rules.routing]]
type = "plugin"
function = "route_priority"              # -> routing_functions["route_priority"]; routing takes NO kwargs
```

The `kwargs` keys map straight to your function's parameter names, so write the function to accept them by name plus a catch-all for forward-compat:

```python
def category_allowlist(*, metadata: dict, allowed: list[str] | None = None, **_) -> bool:
    return metadata.get("category") in (allowed or [])
```

`kwargs` works as an inline table (`kwargs = { allowed = [...] }`) or a sub-table (`[signal-rules.selection.kwargs]` ... `allowed = [...]`); both parse to the same dict. Routing rules have no `kwargs` — a routing function only ever receives `metadata`.

### Completeness essentials

- **`expected_extensions` gates completeness; it's independent of what the extractor reads.** A file can be required for the group to complete yet never opened by `extract()` — e.g. `[".csv", ".json", ".txt"]` waits for all three, but the extractor may read only the `.json`.
- **`primary_extension`** names the group's "main" component (its archive path is recorded on the group row; it's the representative re-enqueued on re-evaluation). Set it to the extension you extract metadata from. `carbonation check config` warns if it isn't in `expected_extensions`.
- **One self-describing file per group:** just `expected_extensions = [".json"]` (and `primary_extension = ".json"`) with `group_by = "stem"` — no plugin grouping needed.

### Grouping & completeness gotcha: compound suffixes

Stem grouping and `expected_extensions` both use Python's `Path` semantics, which only recognize the **last** suffix:

- `group_by = "stem"` keys on `Path.stem`, so `STATION_0101.meta.json` → `STATION_0101.meta` (NOT `STATION_0101`). A `.csv` payload and its `.meta.json` sidecar land in **different groups** and never complete — silently.
- `expected_extensions` matches `Path.suffix`, so the sidecar's extension is `.json`, not `.meta.json`. Write `expected_extensions = [".csv", ".json"]`.

So for sidecar/compound-suffix files (`.meta.json`, `.tar.gz`), declarative stem grouping is the case where you **must** drop to a plugin `group_function` to normalize the key:

```python
def by_payload_stem(*, file_path: Path, **_) -> str | None:
    # STATION_0101.csv and STATION_0101.meta.json -> "STATION_0101"
    return file_path.name.split(".", 1)[0]
```

Wire it with `group_by = "plugin"` + `group_function = "by_payload_stem"` (see the rules.toml block above).

## The FileBase model — three rules the type checker won't catch

```python
from datetime import datetime
from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column
from carbonation.db.models import FileBase

class File(FileBase):
    __tablename__ = "files"
    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
```

1. **Every domain column must be nullable.** The group row is inserted *before* extraction runs, so columns are `NULL` at insert and filled later. A `nullable=False` column breaks that first insert.
2. **Don't re-declare inherited columns.** `id, watch_name, file_type, group_key, complete, archive_path, metadata, created_at, completed_at, modified_at, retention_date` come from `FileBase` (the `FILEBASE_COLUMNS` frozenset in [src/carbonation/db/models.py](src/carbonation/db/models.py) is authoritative). Re-declaring one is a validation error.
3. **Extractor values must match the column's Python type.** Carbonation runs each extract dict through `validate_extract_metadata()`. For the types below, a mismatch is logged as an error and fails the group (RETRY_PENDING → FAILED). Type mapping (`_SA_TYPE_TO_PYTHON` in [src/carbonation/db/models.py](src/carbonation/db/models.py) is authoritative):

   | SQLAlchemy type | return |
   |---|---|
   | `String`, `Text` | `str` |
   | `Integer`, `SmallInteger`, `BigInteger` | `int` |
   | `Float`, `Double` | `float` (an `int` is accepted and widened) |
   | `Numeric` | `Decimal` (a `float`/`int` is accepted) |
   | `Boolean` | `bool` |
   | `DateTime` | `datetime` (parse ISO strings in the extractor — don't return strings) |
   | `JSON` | `dict, list, str, int, float, bool, None` |

   **This table is not exhaustive.** A column whose SA type isn't listed is **not type-checked** — `validate_extract_metadata` silently skips it, so a wrong return type passes validation and only surfaces as garbage at query time. To get real validation for an unlisted type, add it to `_SA_TYPE_TO_PYTHON` (and the query-filter maps in `api.py` / `commands/query.py`) in a carbonation PR.

   **Use the bare base type so the column is queryable.** The CLI/API filter generation dispatches on the *exact* SA type class (`Float`, `String`, `Integer`, …), not subclasses. A `Float` subclass, a dialect type (`mysql.DOUBLE`), or `Numeric(asdecimal=...)` validates fine but produces **no** `--<col>-min`/`--<col>-max` (or `--<col>`) option — so declare plain `Float`/`Double`/`Numeric`/`String`/etc. on your model.

The raw extractor dict is always also stored in the `metadata` JSON column; typed columns are for querying. (Returning a `datetime` is safe even though it lands in JSON — carbonation installs a datetime-aware `json_serializer` on the engine.)

## Migrations: model changes need a plugin migration

The model and the database schema are kept in sync by **you**, via alembic. Editing `model.py` alone does nothing to the DB. Every column change needs a migration on the plugin's alembic branch.

```bash
carbonation db revision -m "add retention_days column"               # hand-write the body
carbonation db revision -m "add retention_days column" --autogenerate # diff model vs live DB
carbonation db upgrade                                                # apply
```

`carbonation db revision` (in [src/carbonation/commands/db.py](src/carbonation/commands/db.py)) writes to `migrations_path`, bootstraps the first revision onto a new branch (`branch_label = <package>`, `depends_on = ("core",)`), and pins later revisions to the plugin branch head. You normally don't write these flags by hand.

The first revision is the only one with hand-relevant flags — it must establish the branch and depend on core:

```python
revision = "p001"
down_revision = None
branch_labels = ("my_plugin",)        # conventionally the package import name
depends_on = ("core",)                # core's `files` table must exist first
```

Every revision after the first just chains on the plugin branch — no branch_labels, no depends_on:

```python
revision = "p002"
down_revision = "p001"                 # the previous plugin revision
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("files", sa.Column("quality_score", sa.Float, nullable=True))

def downgrade() -> None:
    op.drop_column("files", "quality_score")
```

Notes:
- `--autogenerate` requires `db init`/`db upgrade` to have run first, and surfaces *all* drift including core's — review and trim the output, never commit it blind.
- Carbonation runs `alembic upgrade heads` (plural) so both the core and plugin branches advance together under one `alembic_version` table.
- An `index=True` on a model column is **not** applied by the model alone — the migration must also `op.create_index(...)` (and `op.drop_index(...)` in `downgrade`). `--autogenerate` emits these for you; hand-written migrations must include them.

### Adding a typed column (full flow)

1. Add a nullable `Mapped[...]` column to `model.py`.
2. `carbonation db revision -m "add foo" --autogenerate`, then review/trim.
3. Return a `"foo"` key from the extractor(s), typed to match the column.
4. `carbonation db upgrade`.

Skip step 2 and the column silently never exists: extraction writes it only to the JSON blob, and `--foo` queries return zero rows with no error.

## Testing

Copy the in-repo pattern ([tests/_test_plugin/](tests/_test_plugin/) + [tests/conftest.py](tests/conftest.py)): make your plugin a real importable package and run the **real** alembic migrations against in-memory SQLite.

```python
from sqlalchemy import create_engine
from carbonation.db.engine import run_migrations
from carbonation.plugin import LoadedPlugin
from tests import _test_plugin as plugin_module

TEST_PLUGIN = LoadedPlugin(spec=plugin_module.plugin, module=plugin_module)

@pytest.fixture
def db_engine():
    engine = create_engine("sqlite:///:memory:")
    run_migrations(engine, TEST_PLUGIN.spec)   # NOT Base.metadata.create_all
    yield engine
    engine.dispose()
```

- **Import the plugin module at conftest load** — that registers your `FileBase` subclass with `Base.metadata`, which the alembic env and `validate_extract_metadata` read.
- **Use `run_migrations`, not `create_all`** — the point is to exercise the real multi-branch composition and catch branch-config bugs.
- **If a test stores `datetime`-bearing metadata, build the engine with carbonation's serializer:** `create_engine(url, json_serializer=json_serializer)` (import from `carbonation.db.engine`). The plain engine above uses stdlib `json.dumps`, which can't serialize `datetime` — production installs the datetime-aware serializer, so a metadata-storing test on a plain engine fails where production succeeds.

To drive a group insert/query in a test, use the functions in [src/carbonation/db/queries.py](src/carbonation/db/queries.py):

```python
from carbonation.db.queries import (
    find_or_create_file_group, update_file_metadata, mark_group_complete, query_files,
)

gid = find_or_create_file_group(session, watch_name="w", group_key="grp", file_type=None)
md = {"category": "alpha", "start": datetime(2026, 1, 1)}
# Pass raw_metadata= to also populate the JSON `metadata` column — the service
# does this automatically, but a hand-written test must pass it explicitly,
# or the JSON column stays NULL and the serializer above is never exercised.
update_file_metadata(session, gid, md, raw_metadata=md)
mark_group_complete(session, gid)
session.commit()
rows = query_files(session, {"category": "alpha"})
```

## Verify your work

Run these after any plugin change; all should pass cleanly:

```bash
carbonation check config     # resolves every rules.toml plugin reference against your Plugin dicts
carbonation db upgrade       # plugin branch applies on top of core
carbonation db status        # confirms required tables + reports groups missing metadata
```

A missing-key typo in `rules.toml` surfaces at `check config` / startup (not at the first file), naming the rule set, field path, bad key, and available keys — e.g. `rule set 'sig' field 'metadata.extract': 'nope' not in plugin extractors (available: sample)`. A short "available" list usually means your `Plugin(...)` dict is missing an entry.

## Full reference

[docs/plugin-development.md](docs/plugin-development.md) is the long-form reference (alembic branch internals, error-message catalog, rename/split-extractor flows, `query_defaults` detail). Read it when this skill's summary isn't enough.

Anchor files:
- [src/carbonation/plugin.py](src/carbonation/plugin.py) — `Plugin`, `LoadedPlugin`, `resolve_plugin_callable`
- [src/carbonation/db/models.py](src/carbonation/db/models.py) — `FileBase`, `FILEBASE_COLUMNS`, `validate_extract_metadata`, `_SA_TYPE_TO_PYTHON`
- [src/carbonation/config.py](src/carbonation/config.py) — `_bind_plugin_callables` (how references resolve)
- [src/carbonation/db/engine.py](src/carbonation/db/engine.py) — `run_migrations`, `_build_alembic_config`
