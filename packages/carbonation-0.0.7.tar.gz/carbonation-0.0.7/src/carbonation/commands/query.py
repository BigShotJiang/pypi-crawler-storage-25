"""Query commands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from carbonation.cli import cli, _load_service_context, AppContext


def _column_to_options(col: Any) -> list[click.Option]:
    """Generate Click options for a single SQLAlchemy column."""
    from sqlalchemy import DateTime as SADateTime, String as SAString
    from sqlalchemy import (
        BigInteger,
        Boolean,
        Double,
        Float,
        Integer,
        Numeric,
        SmallInteger,
    )

    name = col.name
    cli_name = name.replace("_", "-")
    col_type = type(col.type)
    opts: list[click.Option] = []

    if col_type is SADateTime:
        opts.append(
            click.Option(
                [f"--{cli_name}-after"],
                type=click.STRING,
                default=None,
                help=f"Filter {name} >= value (ISO 8601)",
            )
        )
        opts.append(
            click.Option(
                [f"--{cli_name}-before"],
                type=click.STRING,
                default=None,
                help=f"Filter {name} <= value (ISO 8601)",
            )
        )
    elif col_type is SAString:
        opts.append(
            click.Option(
                [f"--{cli_name}"],
                type=click.STRING,
                multiple=True,
                help=f"Filter by {name} (repeatable, supports % wildcards)",
            )
        )
    elif col_type in (Integer, SmallInteger, BigInteger):
        opts.append(
            click.Option(
                [f"--{cli_name}-min"],
                type=click.INT,
                default=None,
                help=f"Filter {name} >= value",
            )
        )
        opts.append(
            click.Option(
                [f"--{cli_name}-max"],
                type=click.INT,
                default=None,
                help=f"Filter {name} <= value",
            )
        )
    elif col_type in (Float, Double, Numeric):
        opts.append(
            click.Option(
                [f"--{cli_name}-min"],
                type=click.FLOAT,
                default=None,
                help=f"Filter {name} >= value",
            )
        )
        opts.append(
            click.Option(
                [f"--{cli_name}-max"],
                type=click.FLOAT,
                default=None,
                help=f"Filter {name} <= value",
            )
        )
    elif col_type is Boolean:
        opts.append(
            click.Option(
                [f"--{cli_name}/--no-{cli_name}"],
                default=None,
                help=f"Filter by {name}",
            )
        )

    return opts


class QueryFilesCommand(click.Command):
    """Click command that discovers filter options from the plugin File model at invoke time."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        from sqlalchemy import DateTime as SADateTime

        from carbonation.db.models import FILEBASE_COLUMNS, get_file_model

        # Short-circuit for --help so the user doesn't need a working DB
        # (or valid config) just to see the command's help text.
        if any(a in ("--help", "-h") for a in args):
            return super().parse_args(ctx, args)

        # Load AppContext before parsing so we can discover columns
        assert ctx.parent is not None and ctx.parent.parent is not None
        config_path = ctx.parent.parent.params.get("config_path", Path("config.toml"))
        app = _load_service_context(config_path)
        ctx.ensure_object(dict)
        ctx.obj["app"] = app

        # Add dynamic options for domain columns.  The command object is
        # reused across invocations, so track which param names have already
        # been added to avoid duplicates.
        existing_names = {p.name for p in self.params}
        FileModel = get_file_model()
        table = FileModel.__table__
        has_start_stop = False
        for col in table.columns:
            if col.name in FILEBASE_COLUMNS:
                continue
            for opt in _column_to_options(col):
                if opt.name not in existing_names:
                    self.params.append(opt)
                    existing_names.add(opt.name)

        # Detect start/stop pair for --daterange
        col_names = {col.name for col in table.columns}
        col_types = {col.name: type(col.type) for col in table.columns}
        if (
            "start" in col_names
            and "stop" in col_names
            and col_types["start"] is SADateTime
            and col_types["stop"] is SADateTime
        ):
            has_start_stop = True
            if "daterange" not in existing_names:
                self.params.append(
                    click.Option(
                        ["--daterange"],
                        type=click.STRING,
                        default=None,
                        help="Filter by start/stop overlap (TIME or START/END, ISO 8601)",
                    )
                )
            if "age" not in existing_names:
                self.params.append(
                    click.Option(
                        ["--age"],
                        type=click.STRING,
                        default=None,
                        help="Max age — files with stop > now - DURATION (e.g. 7d, 24h)",
                    )
                )

        ctx.obj["has_start_stop"] = has_start_stop
        return super().parse_args(ctx, args)


def _build_filters(ctx: click.Context, params: dict[str, Any]) -> dict[str, Any]:
    """Convert parsed CLI params into the filter dict expected by query_files()."""
    from datetime import datetime as dt, timedelta, timezone

    from carbonation.config import parse_daterange, parse_duration

    filters: dict[str, Any] = {}

    for key, value in params.items():
        if key in ("format", "limit", "count", "columns", "order_by"):
            continue
        if value is None or value == () or value == []:
            continue

        # Convert CLI param name back to filter key
        filter_key = key.replace("-", "_")

        if filter_key == "daterange":
            filters["_daterange"] = parse_daterange(value)
        elif filter_key == "age":
            seconds = parse_duration(value)
            filters["_age"] = dt.now(timezone.utc) - timedelta(seconds=seconds)
        elif filter_key.endswith("_after") or filter_key.endswith("_before"):
            filters[filter_key] = dt.fromisoformat(value)
        else:
            filters[filter_key] = value

    return filters


def _format_output(
    rows: list[dict[str, Any]],
    fmt: str,
    columns: list[str] | None = None,
) -> None:
    """Format and print query results."""
    import csv
    import io
    import json as json_mod

    if not rows:
        click.echo("No results.")
        return

    if columns:
        rows = [{k: v for k, v in row.items() if k in columns} for row in rows]

    if fmt == "json":

        def _serialize(obj: Any) -> str:
            if hasattr(obj, "isoformat"):
                return obj.isoformat()
            return str(obj)

        click.echo(json_mod.dumps(rows, indent=2, default=_serialize))

    elif fmt == "csv":
        out = io.StringIO()
        keys = list(rows[0].keys())
        writer = csv.DictWriter(out, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
        click.echo(out.getvalue().rstrip())

    else:  # table (default)
        from rich.console import Console
        from rich.table import Table as RichTable

        console = Console()
        table = RichTable(show_lines=False)
        keys = list(rows[0].keys())
        for k in keys:
            table.add_column(k)
        for row in rows:
            table.add_row(*[str(v) if v is not None else "" for v in row.values()])
        console.print(table)


@cli.group()
def query() -> None:
    """Query the database."""


@query.command("files", cls=QueryFilesCommand)
@click.option("--watch-name", multiple=True, help="Filter by watch name (repeatable)")
@click.option(
    "--type", "file_type", multiple=True, help="Filter by file type (repeatable)"
)
@click.option("--group-key", multiple=True, help="Filter by group key (repeatable)")
@click.option(
    "--complete/--no-complete", default=None, help="Filter by completion status"
)
@click.option(
    "--created-after",
    type=click.STRING,
    default=None,
    help="Groups created after (ISO 8601)",
)
@click.option(
    "--created-before",
    type=click.STRING,
    default=None,
    help="Groups created before (ISO 8601)",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["table", "csv", "json"]),
    default="table",
    help="Output format",
)
@click.option("--limit", type=click.INT, default=None, help="Max rows to return")
@click.option("--count", is_flag=True, help="Print count only")
@click.option(
    "--columns",
    type=click.STRING,
    default=None,
    help="Comma-separated column names to display",
)
@click.option(
    "--order-by",
    type=click.STRING,
    default=None,
    help="Column to sort by (prefix with - for descending)",
)
@click.pass_context
def query_files_cmd(ctx: click.Context, **params: Any) -> None:
    """Query the files table with dynamic plugin-based filters."""
    from carbonation.db.queries import query_files

    app: AppContext = ctx.obj["app"]
    session = app.session_factory()

    try:
        filters = _build_filters(ctx, params)
        fmt = params.get("fmt", "table")
        count = params.get("count", False)

        # Apply plugin query_defaults for params the user didn't pass
        qd = app.plugin.spec.query_defaults or {}
        limit = (
            params.get("limit") if params.get("limit") is not None else qd.get("limit")
        )
        order_by = (
            params.get("order_by")
            if params.get("order_by") is not None
            else qd.get("order_by")
        )
        columns_str = params.get("columns")
        if columns_str:
            display_columns = columns_str.split(",")
        elif "columns" in qd and qd["columns"] is not None:
            display_columns = qd["columns"]
        else:
            display_columns = None

        if count:
            n = query_files(session, filters, count_only=True)
            click.echo(n)
        else:
            rows = query_files(
                session,
                filters,
                columns=display_columns,
                limit=limit,
                order_by=order_by,
            )
            assert isinstance(rows, list)
            _format_output(rows, fmt, columns=display_columns)
    finally:
        session.close()
