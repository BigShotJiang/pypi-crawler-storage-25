"""\
Tip: Meme
    <del>A monad is a **monoid** in the category of **endofunctors**.</del>

Monadic interfaces that enable
structured ways to compose and manipulate computations on a single effectful construction.

The module defines three abstract classes: [`Functor`][apfel.core.monad.Functor],
[`Applicative`][apfel.core.monad.Applicative], and [`Monad`][apfel.core.monad.Monad].

# Rationale

Monadic abstractions like [`Functor`](https://hackage.haskell.org/package/base/docs/Data-Functor.html){.ref .hs}, [`Applicative`](https://hackage.haskell.org/package/base/docs/Control-Applicative.html){.ref .hs}, and [`Monad`](https://hackage.haskell.org/package/base/docs/Control-Monad.html){.ref .hs} are popularized by Haskell.
Although Python has weak support for functional programming, we include these abstractions to provide a uniform interface for such calculations.

Under the hood, these abstractions use dynamic single dispatch provided in [`apfel.core.dispatch`](dispatch.md), which
allows us to define monadic helper functions for standard built-in types.
This module provides default implementations for `list`, `tuple`, `set`, and `function` as `Functor`, `Applicative`, and `Monad`, `dict` as `Functor`.

Note that we losen the constraints of such abstractions, as writing pure functional code is not a goal of this library.

# Usage

Here's a high-level comparison of the three.
Assume `Value` is a `Monad`.
**A `Monad` is always a `Functor` and an `Applicative`.**

```python

value = Value(42)

assert value.map  (      lambda x: x + 1 ) == Value(43)
assert value.apply(Value(lambda x: x + 1)) == Value(43)
assert value.bind (lambda x: Value(x + 1)) == Value(43)

```

If you are familiar with Rust,
[`Option`](https://doc.rust-lang.org/std/option/enum.Option.html){.ref .rs} is a `Monad`,
[`Option.map`](https://doc.rust-lang.org/std/option/enum.Option.html#method.map){.ref .rs} is its `Functor.map`,
[`Option.and_then`](https://doc.rust-lang.org/std/option/enum.Option.html#method.and_then){.ref .rs} is its `Monad.bind`.

## Case: `list`

```python
assert Functor.map([1, 2, 3], lambda x: x + 1) == [2, 3, 4]
assert Applicative.apply([1, 2, 3], [lambda x: x + 1, lambda x: x + 2]) == [2, 3, 4, 3, 4, 5]
assert Monad.bind([1, 2, 3], lambda x: [x, x + 1]) == [1, 2, 2, 3, 3, 4]
```

## Case: `function`

`Functor.map` of a function is exactly a composition of functions.

```python
assert Functor.map(lambda x: x * 2, lambda x: x + 1)(2) == 5
```
"""

from abc import abstractmethod

# override is in typing only since Python 3.12
from typing_extensions import override

from apfel.core.dispatch import ABCDispatch


class Functor(ABCDispatch):
    """\
    ```python
    class Functor[T](ABC):
        map
    ```

    A [functor](https://en.wikipedia.org/wiki/Functor) is a type that can apply
    a function to its inner value(s) without changing its structure.

    To implement a `Functor`, you need to implement at least the `map` method.

    See [Functor](https://wiki.haskell.org/Functor){.ref .hs} for more information.
    """

    @abstractmethod
    def map(self, func, /):
        """\
        ```python
        def map[F, R](self, func: F, /) -> Self[R]
            where F: Callable[[T], R]
        ```

        Apply a function to the inner value(s) of the functor, returning a new 
        instance of the functor.
        This corresponds to the [`fmap`](https://hackage.haskell.org/package/base/docs/Prelude.html#v:fmap){.ref .hs} in Haskell.
        
        Built-in [`map`](https://docs.python.org/3/library/functions.html#map){.ref .py} function
        returns an iterator, not a new instance of the functor.

        Example:
            ```python
            add = lambda x: x + 1
            Functor.map([1, 2, 3], add) # [2, 3, 4]
            map([1, 2, 3], add)         # <map object at ...>
            ```

        Args:
            func (Callable[[T], R]): The function to apply.

        Returns:
            A new instance of the functor with transformed inner value(s).
        """
        ...


class Applicative(Functor, ABCDispatch):
    """\
    ```python
    class Applicative[T](Functor):
        pure
        apply
    ```

    An [applicative functor](https://en.wikipedia.org/wiki/Applicative_functor) is a functor
    extended with the ability to apply an effectful function to its inner value(s).

    To implement an `Applicative`, you need to implement at least the `pure` and `apply` methods.

    See [Applicative](https://wiki.haskell.org/Applicative){ .ref .hs } for more information.
    """

    @classmethod
    @abstractmethod
    def pure(cls, value, /):
        """\
        ```python
        def pure(cls, value: T, /) -> Self[T]
        ```

        Wrap a value into the applicative structure.

        Args:
            value: The value to wrap.

        Returns:
            A new instance of the applicative with the value wrapped.
        """
        ...

    @abstractmethod
    def apply(self, func, /):
        """\
        ```python
        def apply[F, R](self, func: F) -> Self[R]
            where F: Self[Callable[[T], R]]
        ```

        Applies a function wrapped inside the applicative structure to the inner value(s) of this applicative.

        Args:
            func: The function to apply, wrapped within the applicative structure.

        Returns:
            A new instance of the applicative with the transformed inner value(s).
        """
        ...

    @override
    def map(self, func, /):
        # ? This is the default implementation of `Functor.map` for `Applicative`.
        # ? ```haskell
        # ? map f x = pure f <*> x
        # ? ```

        cls = type(self)
        return Applicative.apply[cls](self, Applicative.pure[cls](func))  # type: ignore


class Monad(Applicative, ABCDispatch):
    """\
    ```python
    class Monad[T](Applicative):
        bind
        (Applicative.pure)
    ```

    A [monad](https://en.wikipedia.org/wiki/Monad_(functional_programming)) is an applicative
    functor extended with the ability to reuse results of previous computations and chain
    effectful computations together.

    To implement a `Monad`, you need to implement at least the `bind` method, and
    the [`pure`][apfel.core.monad.Applicative.pure] method from `Applicative`.

    See [Monad](https://wiki.haskell.org/Monad){ .ref .hs } for more information.

    Notes:
        `return` is a reserved keyword in Python, and Haskell [`return`](https://hackage.haskell.org/package/base/docs/Prelude.html#v:return){.ref .hs} is a historical mistake that is now
        pointing to [`pure`](https://hackage.haskell.org/package/base/docs/Prelude.html#v:pure){.ref .hs}.
    """

    @abstractmethod
    def bind(self, func, /):
        """\
        ```python
        def bind[F, R](self, func: F) -> Self[R]
            where F: Callable[[T], Self[R]]
        ```

        Chain a new monadic computation to the current one.

        The argument `f` maps a pure value of the monad's inner type to the monadic value.
        `bind` chains this computation to the one it represents.
        If its computation fails, the following computations will not be executed.

        The function `f` is called a [Kleisli arrow](https://en.wikipedia.org/wiki/Kleisli_category).
        This `bind` operation has other names in different programming languages.
        For example, in [`Option`](https://doc.rust-lang.org/std/option/enum.Option.html){.ref .rs} monad, it is called [`and_then`](https://doc.rust-lang.org/std/option/enum.Option.html#method.and_then){.ref .rs}.

        Args:
            f: The function that returns a new monadic computation.

        Returns:
            A new instance of the monad with the result of the chained computation.
        """
        ...

    @override
    def apply(self, func, /):
        # ? This is the default implementation of `Applicative.apply` for `Monad`.
        # ? ```haskell
        # ? apply f x = f >>= \g -> x >>= \y -> return (g y)
        # ? ```

        return Monad.bind(  # type: ignore
            func,
            lambda g: Monad.bind(self, lambda y: Applicative.pure[type(self)](g(y))),  # type: ignore
        )

    @override
    def map(self, func, /):
        # ? This is the default implementation of `Functor.map` for `Monad`.
        # ? ```haskell
        # ? map f x = x >>= \a -> return (f a)
        # ? ```

        return Monad.bind(self, lambda a: Applicative.pure[type(self)](func(a)))  # type: ignore

from . import _implementation # noqa: E402
"""
Use the default implementations for the built-in types, namely `list`, `tuple`, `set`, `dict` and `function`.
Besides `dict` which is only a `Functor`, all other types are `Functor`, `Applicative`, and `Monad`.

This function should be called before using the monadic abstractions.

See the [module level usage guide][apfel.core.monad--usage] for more information.
"""
for name, impl in vars(_implementation).items():
    if name.startswith("do_impl_for_"):
        impl()

fmap = Functor.map
"""
An alias for [`Functor.map`][apfel.core.monad.Functor.map].
"""

__all__ = ["Functor", "Applicative", "Monad", "fmap"]
