"""oa-bench: OA Evaluation Battery CLI.

Domain-agnostic matched-pair deployment-safety auditing.
"""

__version__ = "1.0.6"
__battery_version__ = "v1.0"
__schema_version__ = "v1.0"
