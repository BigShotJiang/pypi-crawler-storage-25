"""Canon extension system."""

from .installer import InstallResult, install_extension, uninstall_extension
from .manifest import ExtensionManifest, load_manifest
from .registry import Registry, load_registry
from .template import scaffold_extension

__all__ = [
    "ExtensionManifest",
    "InstallResult",
    "Registry",
    "install_extension",
    "load_manifest",
    "load_registry",
    "scaffold_extension",
    "uninstall_extension",
]
