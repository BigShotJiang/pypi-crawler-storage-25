"""Extension registry — tracks installed extensions in .canon/extensions/.registry.json."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

REGISTRY_SCHEMA_VERSION = "1"
REGISTRY_FILENAME = ".registry.json"


@dataclass
class InstalledExtension:
    """Record of a single installed extension."""

    version: str
    installed_at: str  # ISO 8601
    source: str  # "local" | "dev" (Phase 2 adds "catalog", "repo")
    dev_mode: bool
    enabled: bool
    source_path: str  # original path (for dev mode tracking / display)
    installed_files: list[str] = field(default_factory=list)


@dataclass
class Registry:
    """Top-level registry tracking all installed extensions."""

    schema_version: str = REGISTRY_SCHEMA_VERSION
    extensions: dict[str, InstalledExtension] = field(default_factory=dict)


def registry_path(project_root: Path) -> Path:
    """Return the path to .canon/extensions/.registry.json."""
    return project_root / ".canon" / "extensions" / REGISTRY_FILENAME


def load_registry(project_root: Path) -> Registry:
    """Load registry from disk. Returns empty Registry if file missing.

    Raises ValueError with actionable message if the file is corrupted.
    """
    path = registry_path(project_root)
    if not path.exists():
        return Registry()
    try:
        data = json.loads(path.read_text())
        extensions = {}
        for ext_id, ext_data in data.get("extensions", {}).items():
            extensions[ext_id] = InstalledExtension(**ext_data)
        return Registry(
            schema_version=data.get("schema_version", REGISTRY_SCHEMA_VERSION),
            extensions=extensions,
        )
    except (json.JSONDecodeError, TypeError, KeyError) as exc:
        raise ValueError(
            f"Extension registry is corrupted ({path}): {exc}\n"
            f"Delete {path} to reset, then re-install extensions."
        ) from exc


def save_registry(project_root: Path, registry: Registry) -> None:
    """Write registry to disk atomically, creating parent dirs as needed.

    Writes to a temp file then renames to avoid corruption on crash/SIGKILL.
    """
    path = registry_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "schema_version": registry.schema_version,
        "extensions": {ext_id: asdict(ext) for ext_id, ext in registry.extensions.items()},
    }
    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(json.dumps(data, indent=2) + "\n")
    tmp_path.replace(path)  # atomic on POSIX


def add_extension(registry: Registry, ext_id: str, entry: InstalledExtension) -> None:
    """Register an installed extension. Raises ValueError if already present."""
    if ext_id in registry.extensions:
        raise ValueError(f"Extension already installed: {ext_id!r}")
    registry.extensions[ext_id] = entry


def remove_extension(registry: Registry, ext_id: str) -> InstalledExtension:
    """Unregister an extension. Raises KeyError if not found."""
    if ext_id not in registry.extensions:
        raise KeyError(f"Extension not installed: {ext_id!r}")
    return registry.extensions.pop(ext_id)


def get_extension(registry: Registry, ext_id: str) -> InstalledExtension | None:
    """Look up an extension by ID. Returns None if not found."""
    return registry.extensions.get(ext_id)
