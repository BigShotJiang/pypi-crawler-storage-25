"""Extension installer — add/remove extensions and their artifacts."""

from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from .manifest import (
    ExtensionManifest,
    check_canon_version_compat,
    load_manifest,
    validate_file_references,
)
from .registry import (
    InstalledExtension,
    add_extension,
    load_registry,
    remove_extension,
    save_registry,
)

logger = logging.getLogger(__name__)


def get_canon_version() -> str:
    """Get the current canon version from package metadata."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("canonhq")
    except PackageNotFoundError:
        logger.debug("canonhq package not found in metadata — assuming dev build")
        return "0.0.0"


@dataclass
class InstallResult:
    """Result of an extension installation."""

    ext_id: str
    version: str
    installed_files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def install_extension(
    project_root: Path,
    source_dir: Path,
    *,
    dev_mode: bool = False,
) -> InstallResult:
    """Install an extension from a local directory.

    Raises FileNotFoundError if manifest missing.
    Raises ValueError on validation failure or ID collision.

    On failure after partial file placement, rolls back all changes.
    """
    source_dir = source_dir.resolve()

    # 1. Load & validate manifest
    manifest = load_manifest(source_dir)
    ext_id = manifest.extension.id

    # 2. Validate file references
    errors = validate_file_references(manifest, source_dir)
    if errors:
        raise ValueError(
            f"Extension {ext_id!r} has invalid file references:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    # 3. Check canon version compatibility
    canon_version = get_canon_version()
    if not check_canon_version_compat(manifest.requires.canon_version, canon_version):
        raise ValueError(
            f"Extension {ext_id!r} requires canon {manifest.requires.canon_version}, "
            f"but current version is {canon_version}"
        )

    # 4. Check for ID collision
    registry = load_registry(project_root)
    if ext_id in registry.extensions:
        raise ValueError(f"Extension already installed: {ext_id!r}")

    # 5-7. Copy/symlink, place files, register — with rollback on failure
    ext_dest = project_root / ".canon" / "extensions" / ext_id
    ext_dest.parent.mkdir(parents=True, exist_ok=True)
    installed_files: list[str] = []

    try:
        if dev_mode:
            ext_dest.symlink_to(source_dir)
        else:
            shutil.copytree(source_dir, ext_dest, symlinks=True)

        # 6. Place skill and command files
        installed_files.extend(_place_skills(manifest, source_dir, project_root, dev_mode))
        installed_files.extend(_place_commands(manifest, source_dir, project_root, dev_mode))

        # 7. Register
        entry = InstalledExtension(
            version=manifest.extension.version,
            installed_at=datetime.now(UTC).isoformat(),
            source="dev" if dev_mode else "local",
            dev_mode=dev_mode,
            enabled=True,
            source_path=str(source_dir),
            installed_files=installed_files,
        )
        add_extension(registry, ext_id, entry)
        save_registry(project_root, registry)
    except Exception:
        # Rollback: remove any files we placed
        logger.debug("Install failed for %s, rolling back", ext_id)
        _remove_placed_files(project_root, installed_files)
        if ext_dest.is_symlink():
            ext_dest.unlink()
        elif ext_dest.is_dir():
            shutil.rmtree(ext_dest, ignore_errors=True)
        raise

    # Log Phase 2+ components that were skipped
    warnings: list[str] = []
    if manifest.provides.adapters:
        warnings.append(
            f"Skipped {len(manifest.provides.adapters)} adapter(s) — "
            "adapter registration requires Phase 2"
        )
    if manifest.provides.hooks:
        warnings.append(
            f"Skipped {len(manifest.provides.hooks)} hook(s) — hook integration requires Phase 2"
        )
    if manifest.provides.mcp_tools:
        warnings.append(
            f"Skipped {len(manifest.provides.mcp_tools)} MCP tool(s) — "
            "MCP tool registration requires Phase 3"
        )
    if manifest.provides.agents:
        warnings.append(
            f"Skipped {len(manifest.provides.agents)} agent(s) — agent placement requires Phase 3"
        )

    return InstallResult(
        ext_id=ext_id,
        version=manifest.extension.version,
        installed_files=installed_files,
        warnings=warnings,
    )


def uninstall_extension(project_root: Path, ext_id: str) -> list[str]:
    """Remove an installed extension and all its artifacts.

    Raises KeyError if not installed.
    """
    registry = load_registry(project_root)
    entry = remove_extension(registry, ext_id)
    # Save registry first so extension is unregistered even if cleanup fails.
    # This prevents the "can't uninstall, can't reinstall" deadlock.
    save_registry(project_root, registry)

    # Remove placed files (best-effort — continues on per-file errors)
    removed = _remove_placed_files(project_root, entry.installed_files)

    # Remove extension directory
    ext_dir = project_root / ".canon" / "extensions" / ext_id
    try:
        if ext_dir.is_symlink():
            ext_dir.unlink()
        elif ext_dir.is_dir():
            shutil.rmtree(ext_dir)
    except OSError as exc:
        logger.warning(
            "Could not remove extension directory %s: %s — delete it manually",
            ext_dir,
            exc,
        )

    return removed


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _place_skills(
    manifest: ExtensionManifest,
    ext_source: Path,
    project_root: Path,
    dev_mode: bool,
) -> list[str]:
    """Copy/symlink skill SKILL.md files to .canon/skills/{name}/SKILL.md.

    On partial failure, cleans up already-placed files before re-raising.
    """
    placed: list[str] = []
    try:
        for skill in manifest.provides.skills:
            src = (ext_source / skill.file).resolve()
            if not src.is_relative_to(ext_source.resolve()):
                raise ValueError(f"Skill file escapes extension directory: {skill.file}")
            dest_dir = project_root / ".canon" / "skills" / skill.name
            dest = dest_dir / "SKILL.md"
            if not dest.resolve().is_relative_to(project_root.resolve()):
                raise ValueError(f"Skill name escapes project directory: {skill.name}")
            dest_dir.mkdir(parents=True, exist_ok=True)
            _copy_or_link(src, dest, dev_mode)
            placed.append(str(dest.relative_to(project_root)))
    except Exception:
        _remove_placed_files(project_root, placed)
        raise
    return placed


def _place_commands(
    manifest: ExtensionManifest,
    ext_source: Path,
    project_root: Path,
    dev_mode: bool,
) -> list[str]:
    """Copy/symlink command .md files to .claude/commands/{name}.md.

    On partial failure, cleans up already-placed files before re-raising.
    """
    placed: list[str] = []
    try:
        for cmd in manifest.provides.commands:
            src = (ext_source / cmd.file).resolve()
            if not src.is_relative_to(ext_source.resolve()):
                raise ValueError(f"Command file escapes extension directory: {cmd.file}")
            dest_dir = project_root / ".claude" / "commands"
            dest = dest_dir / f"{cmd.name}.md"
            if not dest.resolve().is_relative_to(project_root.resolve()):
                raise ValueError(f"Command name escapes project directory: {cmd.name}")
            dest_dir.mkdir(parents=True, exist_ok=True)
            _copy_or_link(src, dest, dev_mode)
            placed.append(str(dest.relative_to(project_root)))
    except Exception:
        _remove_placed_files(project_root, placed)
        raise
    return placed


def _copy_or_link(src: Path, dst: Path, dev_mode: bool) -> None:
    """If dev_mode, create a symlink dst -> src. Otherwise, copy.

    Raises FileExistsError if destination already exists (prevents
    cross-extension conflicts where two extensions claim the same name).
    """
    if dst.exists() or dst.is_symlink():
        raise FileExistsError(
            f"Destination already exists (possible cross-extension conflict): {dst}"
        )
    if dev_mode:
        dst.symlink_to(src.resolve())
    else:
        shutil.copy2(src, dst)


def _remove_placed_files(project_root: Path, files: list[str]) -> list[str]:
    """Delete each file in the list. Returns actually-removed paths.

    Also cleans up empty parent directories up to project_root.
    Continues on per-file errors, logging warnings.
    """
    removed: list[str] = []
    root = project_root.resolve()
    for rel_path in files:
        full_path = project_root / rel_path
        # Check the logical path (not resolved — symlinks point outside project by design).
        # Normalize to catch ".." components without following symlinks.
        normalized = (project_root / rel_path).resolve(strict=False)
        if full_path.is_symlink():
            # For symlinks, check that the link itself is within bounds
            normalized = full_path.parent.resolve() / full_path.name
        if not normalized.is_relative_to(root):
            logger.warning("Skipping out-of-bounds path during cleanup: %s", rel_path)
            continue
        if full_path.exists() or full_path.is_symlink():
            try:
                full_path.unlink()
                removed.append(rel_path)
            except OSError as exc:
                logger.warning("Failed to remove %s: %s", rel_path, exc)
                continue
            # Clean up empty parent dirs
            parent = full_path.parent
            while parent != project_root and parent.exists():
                try:
                    parent.rmdir()  # only succeeds if empty
                    parent = parent.parent
                except OSError:
                    break
    return removed
