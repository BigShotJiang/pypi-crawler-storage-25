"""Extension scaffolding — canon extension create."""

from __future__ import annotations

from pathlib import Path


def scaffold_extension(
    target_dir: Path,
    ext_id: str,
    *,
    with_skill: bool = False,
    with_command: bool = False,
    with_hook: bool = False,
    with_adapter: bool = False,
    author: str = "",
) -> list[str]:
    """Create a new extension directory with template files.

    Returns list of created file paths (relative to target_dir).
    Raises FileExistsError if target_dir already exists.
    """
    if target_dir.exists():
        raise FileExistsError(f"Directory already exists: {target_dir}")

    target_dir.mkdir(parents=True)
    created: list[str] = []

    # Always create manifest and README
    manifest_content = _render_manifest(
        ext_id,
        with_skill=with_skill,
        with_command=with_command,
        with_hook=with_hook,
        with_adapter=with_adapter,
        author=author,
    )
    (target_dir / "canon-extension.yml").write_text(manifest_content)
    created.append("canon-extension.yml")

    (target_dir / "README.md").write_text(_render_readme(ext_id))
    created.append("README.md")

    # Conditional components
    if with_skill:
        skill_dir = target_dir / "skills" / ext_id
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(_render_skill(ext_id))
        created.append(f"skills/{ext_id}/SKILL.md")

    if with_command:
        cmd_dir = target_dir / "commands"
        cmd_dir.mkdir(parents=True)
        (cmd_dir / f"{ext_id}.md").write_text(_render_command(ext_id))
        created.append(f"commands/{ext_id}.md")

    if with_hook:
        hook_dir = target_dir / "hooks"
        hook_dir.mkdir(parents=True)
        (hook_dir / ".gitkeep").touch()
        created.append("hooks/.gitkeep")

    return created


# ---------------------------------------------------------------------------
# Template renderers
# ---------------------------------------------------------------------------


def _render_manifest(
    ext_id: str,
    *,
    with_skill: bool,
    with_command: bool,
    with_hook: bool,
    with_adapter: bool,
    author: str,
) -> str:
    def _ystr(s: str) -> str:
        """Safely quote a string for YAML double-quoted scalar."""
        escaped = s.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'

    lines = [
        'schema_version: "1"',
        "",
        "extension:",
        f"  id: {_ystr(ext_id)}",
        f"  name: {_ystr(ext_id.replace('-', ' ').title())}",
        '  version: "0.1.0"',
        '  description: "TODO: Describe your extension"',
    ]
    if author:
        lines.append(f"  author: {_ystr(author)}")
    else:
        lines.append('  author: ""')
    lines += [
        '  repository: ""',
        '  license: "MIT"',
        "",
        "requires:",
        '  canon_version: ">=1.0.0"',
        "",
        "provides:",
    ]

    if with_skill:
        lines += [
            "  skills:",
            f'    - name: "{ext_id}"',
            f'      file: "skills/{ext_id}/SKILL.md"',
            '      description: "TODO: Describe this skill"',
        ]

    if with_command:
        lines += [
            "  commands:",
            f'    - name: "{ext_id}"',
            f'      file: "commands/{ext_id}.md"',
            '      description: "TODO: Describe this command"',
        ]

    if with_adapter:
        lines += [
            "  adapters:",
            f'    - id: "{ext_id}"',
            '      entry_point: ""  # e.g. "my_package:MyAdapter"',
        ]

    if with_hook:
        lines += [
            "  hooks:",
            '    - event: "Stop"',
            '      type: "command"',
            '      command: "echo Extension hook fired"',
            "      timeout: 5",
        ]

    if not any([with_skill, with_command, with_adapter, with_hook]):
        lines += [
            "  skills: []",
            "  commands: []",
        ]

    lines += [
        "",
        "tags: []",
    ]

    return "\n".join(lines) + "\n"


def _render_readme(ext_id: str) -> str:
    name = ext_id.replace("-", " ").title()
    return f"""# {name}

A Canon extension.

## Installation

```bash
canon extension add /path/to/{ext_id}
```

## Usage

TODO: Describe how to use this extension.

## Development

```bash
# Install in dev mode (symlinks — edits propagate instantly)
canon extension add --dev /path/to/{ext_id}

# Validate manifest
canon extension validate /path/to/{ext_id}
```
"""


def _render_skill(ext_id: str) -> str:
    name = ext_id.replace("-", " ").title()
    return f"""---
name: {ext_id}
description: "TODO: Describe when this skill should be used"
---

# {name}

TODO: Add skill instructions here.
"""


def _render_command(ext_id: str) -> str:
    name = ext_id.replace("-", " ").title()
    return f"""---
description: "{name}"
---

# {name}

TODO: Add command instructions here.

## Arguments

$ARGUMENTS
"""
