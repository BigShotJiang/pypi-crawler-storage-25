"""Extension manifest (canon-extension.yml) Pydantic models."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, field_validator

logger = logging.getLogger(__name__)

RESERVED_IDS = frozenset({"canon", "core", "builtin"})
ID_PATTERN = re.compile(r"^[a-z][a-z0-9-]{1,48}[a-z0-9]$")

MANIFEST_FILENAME = "canon-extension.yml"
# Skill/command names must be simple identifiers (no path components)
_SAFE_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9-]*$")


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------


class ExtensionMeta(BaseModel):
    """Extension metadata (required in every manifest)."""

    id: str
    name: str
    version: str
    description: str = ""
    author: str = ""
    repository: str = ""
    license: str = ""
    homepage: str = ""

    @field_validator("id")
    @classmethod
    def validate_id(cls, v: str) -> str:
        if v in RESERVED_IDS:
            raise ValueError(f"Reserved extension ID: {v!r}")
        if not ID_PATTERN.match(v):
            raise ValueError(f"Extension ID must match {ID_PATTERN.pattern}, got: {v!r}")
        return v


class RequiresSpec(BaseModel):
    """Compatibility requirements."""

    canon_version: str = ">=0.1.0"
    python: str = ""
    tools: list[dict[str, Any]] = []
    commands: list[str] = []


class SkillSpec(BaseModel):
    """A skill provided by the extension."""

    name: str
    file: str  # relative path, e.g. "skills/foo/SKILL.md"
    description: str = ""

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not _SAFE_NAME_PATTERN.match(v):
            raise ValueError(f"Skill name must match [a-z][a-z0-9-]* (got {v!r})")
        return v


class CommandSpec(BaseModel):
    """A slash command provided by the extension."""

    name: str
    file: str  # e.g. "commands/my-cmd.md"
    description: str = ""

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not _SAFE_NAME_PATTERN.match(v):
            raise ValueError(f"Command name must match [a-z][a-z0-9-]* (got {v!r})")
        return v


class AdapterSpec(BaseModel):
    """A ticket adapter (Phase 2 — parsed but not acted on in Phase 1)."""

    id: str
    entry_point: str = ""
    capabilities: dict[str, bool] = {}


class HookSpec(BaseModel):
    """A lifecycle hook (Phase 2+ — parsed but not acted on)."""

    event: str
    type: str = "command"
    command: str = ""
    timeout: int = 10


class McpToolSpec(BaseModel):
    """An MCP tool (Phase 3 — parsed but not acted on)."""

    name: str
    handler: str = ""
    description: str = ""
    input_schema: dict[str, Any] = {}


class AgentSpec(BaseModel):
    """An agent (Phase 3 — parsed but not acted on)."""

    name: str
    file: str
    description: str = ""


class ProvidesSpec(BaseModel):
    """What the extension provides."""

    adapters: list[AdapterSpec] = []
    skills: list[SkillSpec] = []
    commands: list[CommandSpec] = []
    hooks: list[HookSpec] = []
    mcp_tools: list[McpToolSpec] = []
    agents: list[AgentSpec] = []
    config: list[dict[str, Any]] = []


# ---------------------------------------------------------------------------
# Root model
# ---------------------------------------------------------------------------


class ExtensionManifest(BaseModel):
    """Root model for canon-extension.yml."""

    schema_version: str = "1"
    extension: ExtensionMeta
    requires: RequiresSpec = RequiresSpec()
    provides: ProvidesSpec = ProvidesSpec()
    hooks: dict[str, Any] = {}
    tags: list[str] = []
    defaults: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Loading and validation
# ---------------------------------------------------------------------------


def load_manifest(extension_dir: Path) -> ExtensionManifest:
    """Load and validate canon-extension.yml from a directory.

    Raises FileNotFoundError if manifest missing.
    Raises pydantic.ValidationError on schema errors.
    Raises yaml.YAMLError on malformed YAML.
    """
    manifest_path = extension_dir / MANIFEST_FILENAME
    if not manifest_path.exists():
        raise FileNotFoundError(f"Extension manifest not found: {manifest_path}")
    with open(manifest_path) as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(f"Expected YAML mapping in {manifest_path}, got {type(data).__name__}")
    return ExtensionManifest.model_validate(data)


def validate_file_references(manifest: ExtensionManifest, extension_dir: Path) -> list[str]:
    """Check that all file paths in provides exist on disk and stay within the extension dir.

    Returns a list of error messages (empty means valid).
    """
    errors: list[str] = []
    ext_root = extension_dir.resolve()

    for skill in manifest.provides.skills:
        path = (extension_dir / skill.file).resolve()
        if not path.is_relative_to(ext_root):
            errors.append(f"Skill file escapes extension directory: {skill.file}")
        elif not path.exists():
            errors.append(f"Skill file not found: {skill.file}")

    for cmd in manifest.provides.commands:
        path = (extension_dir / cmd.file).resolve()
        if not path.is_relative_to(ext_root):
            errors.append(f"Command file escapes extension directory: {cmd.file}")
        elif not path.exists():
            errors.append(f"Command file not found: {cmd.file}")

    for agent in manifest.provides.agents:
        path = (extension_dir / agent.file).resolve()
        if not path.is_relative_to(ext_root):
            errors.append(f"Agent file escapes extension directory: {agent.file}")
        elif not path.exists():
            errors.append(f"Agent file not found: {agent.file}")

    return errors


def check_canon_version_compat(required: str, current: str) -> bool:
    """Check if current canon version satisfies the requires.canon_version range.

    Uses packaging.specifiers for full PEP 440 constraint support
    (>=, <, !=, ~=, etc.).
    """
    from packaging.specifiers import InvalidSpecifier, SpecifierSet

    try:
        return current in SpecifierSet(required)
    except InvalidSpecifier:
        logger.warning("Invalid version specifier %r — rejecting", required)
        return False
