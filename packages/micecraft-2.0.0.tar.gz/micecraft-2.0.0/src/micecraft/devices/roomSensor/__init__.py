"""Room sensory block."""
