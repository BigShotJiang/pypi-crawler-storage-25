"""PyPI registry adapter for share-it-on."""

import os
import re
import tomllib

from ..utils import run

NAME = "pypi"


def read_version(dir_path):
    """Read the version from pyproject.toml in the given directory."""
    toml_path = os.path.join(dir_path, "pyproject.toml")
    with open(toml_path, "rb") as f:
        data = tomllib.load(f)
    return data["project"]["version"]


def write_version(dir_path, version):
    """Write a new version to pyproject.toml using regex replacement.

    tomllib is read-only (no stdlib TOML writer), so we use a regex to
    replace the version string in-place while preserving all other formatting.
    """
    toml_path = os.path.join(dir_path, "pyproject.toml")
    with open(toml_path, "r", encoding="utf-8") as f:
        content = f.read()
    updated = re.sub(
        r'^(version\s*=\s*)"[^"]+"',
        rf'\g<1>"{version}"',
        content,
        count=1,
        flags=re.MULTILINE,
    )
    with open(toml_path, "w", encoding="utf-8") as f:
        f.write(updated)


def get_version_file():
    """Returns the filename that holds the version for this registry."""
    return "pyproject.toml"


def get_template_dir():
    """Returns path to the pypi-specific template directory."""
    return os.path.join(os.path.dirname(__file__), "..", "..", "templates", "pypi")


def get_shared_template_dir():
    """Returns path to the shared template directory."""
    return os.path.join(os.path.dirname(__file__), "..", "..", "templates", "shared")


def get_template_vars(dir_path):
    """Extract template variables from the target project's pyproject.toml."""
    toml_path = os.path.join(dir_path, "pyproject.toml")
    with open(toml_path, "rb") as f:
        data = tomllib.load(f)

    project = data.get("project", {})
    name = project.get("name", "")
    version = project.get("version", "0.1.0")

    # Extract author -- fall back to git config
    author = ""
    try:
        author = run("git", ["config", "user.name"])
    except Exception:
        pass

    # Extract repo name from project.urls
    repo_name = ""
    urls = project.get("urls", {})
    for url in urls.values():
        match = re.search(r"github\.com/([^/\s\"]+/[^/\s\"]+)", url)
        if match:
            repo_name = match.group(1).removesuffix(".git")
            break

    # Derive binCommand from project.scripts (CLI entry points)
    bin_command = ""
    scripts = project.get("scripts", {})
    if scripts:
        bin_command = next(iter(scripts))  # first script entry

    # Derive the actual Python import name.
    # 1) Check hatch build config for an explicit packages list.
    import_name = None
    hatch = data.get("tool", {}).get("hatch", {})
    packages = (
        hatch.get("build", {}).get("targets", {}).get("wheel", {}).get("packages")
    )
    if packages and isinstance(packages, list) and len(packages) > 0:
        # Strip src/ prefix (common hatch src layout) and convert path to module name
        first_pkg = packages[0]
        import_name = first_pkg.removeprefix("src/").replace("/", ".")

    # 2) Fall back to filesystem detection, then underscore convention.
    if not import_name:
        underscored = name.replace("-", "_")
        if os.path.isdir(os.path.join(dir_path, underscored)):
            import_name = underscored
        elif os.path.isdir(os.path.join(dir_path, name)):
            import_name = name
        else:
            import_name = underscored  # fallback to convention

    return {
        "name": name,
        "version": version,
        "binCommand": bin_command,
        "author": author,
        "repoName": repo_name,
        "importName": import_name,
    }


def get_template_mappings():
    """Returns pypi-specific template mappings (template file -> target path)."""
    return [
        {"template": "ci.yml.tpl", "target": ".github/workflows/ci.yml"},
        {"template": "workflow.yml.tpl", "target": ".github/workflows/workflow.yml"},
    ]


def get_shared_template_mappings():
    """Returns shared template mappings."""
    return [
        {"template": "CHANGELOG.md.tpl", "target": "CHANGELOG.md"},
        {"template": "gitignore.tpl", "target": ".gitignore"},
        {"template": "LICENSE.tpl", "target": "LICENSE"},
        {"template": "CLAUDE.md.tpl", "target": "CLAUDE.md"},
        {"template": "check-prs.sh.tpl", "target": "scripts/check-prs.sh"},
        {"template": "record-gif.sh.tpl", "target": "scripts/record-gif.sh"},
        {"template": "pre-release.sh.tpl", "target": "scripts/pre-release.sh"},
        {"template": "pre-push-hook.sh.tpl", "target": "scripts/pre-push-hook.sh"},
        {"template": "claude-settings.json.tpl", "target": ".claude/settings.json"},
    ]


def check_project_exists(dir_path):
    """Returns True if a pyproject.toml exists in the given directory."""
    return os.path.exists(os.path.join(dir_path, "pyproject.toml"))


def get_project_init_hint():
    """Hint for users who haven't initialized their project yet."""
    return 'Run "uv init" first'
