"""Registry lookup for share-it-on."""

from . import npm, pypi

REGISTRIES = {"npm": npm, "pypi": pypi}
