"""Allow running as python -m share_it_on."""
from . import main

main()
