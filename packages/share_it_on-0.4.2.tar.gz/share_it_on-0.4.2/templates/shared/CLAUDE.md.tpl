# {{name}}

## Release workflow

This project uses [share-it-on](https://github.com/smm-h/share-it-on) for release orchestration.

- Update CHANGELOG.md with a `## X.Y.Z` entry describing changes
- Run `share-it-on <registry> release [patch|minor|major]` to bump version and create a GitHub Release
- CI handles publishing automatically via the publish workflow
- Never publish manually — always use `share-it-on <registry> release`
- Requires `NPM_TOKEN` secret on GitHub (for npm projects)
- Use `share-it-on <registry> release --dry-run` to preview a release without making changes

## Conventions

- No tokens or secrets in command-line arguments (use env vars or config files)
- All file writes to shared state should be atomic (write to tmp, then rename)
- External calls (APIs, CLI tools) must have timeouts and graceful fallbacks
- Use `npm link` (npm) or `uv pip install -e .` (Python) for local development
- CI runs smoke tests on every push; manual testing for UI/UX changes
