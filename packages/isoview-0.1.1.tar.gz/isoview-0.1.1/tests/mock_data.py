import numpy as np
from pathlib import Path
from scipy.ndimage import gaussian_filter


def generate_beads_volume(
    shape: tuple[int, int, int] = (32, 128, 128),
    num_beads: int = 200,
    bead_radius: float = 1.2,
    noise_level: float = 5.0,
    max_intensity: int = 4000,
) -> np.ndarray:
    """
    Generate a synthetic light-sheet microscopy volume containing randomly
    distributed Gaussian 'beads'.

    Args:
        shape: Output volume shape (Z, Y, X)
        num_beads: Number of synthetic beads to place in the volume
        bead_radius: Standard deviation for the Gaussian blur applied to beads
        noise_level: Standard deviation of background Gaussian noise
        max_intensity: Maximum pixel intensity for the beads scaling

    Returns:
        uint16 numpy array representing the 3D volume
    """
    volume = np.zeros(shape, dtype=np.float32)

    # Generate random centers for the beads
    # We clip to avoid putting points precisely on the boundary which might crop weirdly
    z = np.random.randint(2, shape[0] - 2, num_beads)
    y = np.random.randint(2, shape[1] - 2, num_beads)
    x = np.random.randint(2, shape[2] - 2, num_beads)

    # Place strong impulses at bead locations
    volume[z, y, x] = 1000.0

    # Blur to create the physical span of the "bead" point spread function
    volume = gaussian_filter(volume, sigma=(bead_radius * 1.5, bead_radius, bead_radius))

    # Add varying normal background noise
    noise = np.random.normal(100.0, noise_level, shape)
    volume += noise

    # Normalize to specified max intensity
    volume = np.clip(volume, 0, None)
    current_max = volume.max()
    if current_max > 0:
        volume = (volume / current_max) * max_intensity

    return volume.astype(np.uint16)


def create_mock_tiled_dataset(base_dir: Path, num_tiles: int = 2, shape: tuple = (10, 64, 64)):
    """
    Creates a mock tiled dataset using the generated bead data matching
    isoview directory structures (e.g. TL1/TL1_CM0.stack).
    """
    base_dir = Path(base_dir)
    base_dir.mkdir(parents=True, exist_ok=True)

    from isoview.io import write_volume

    for i in range(1, num_tiles + 1):
        tl_name = f"TL{i}"
        tl_dir = base_dir / tl_name
        tl_dir.mkdir(exist_ok=True)

        # simulated cameras 0 and 1
        for cam in [0, 1]:
            vol = generate_beads_volume(shape=shape)
            out_path = tl_dir / f"{tl_name}_CM{cam}.tif"
            write_volume(vol, out_path, pixel_spacing=np.array([2.0, 1.0, 1.0]))
