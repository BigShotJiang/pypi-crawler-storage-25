% Generate MATLAB KLB reference data for Python comparison tests
%
% Usage: matlab -batch "run('test/save_matlab_refs.m')"

clc; clear;

scriptPath = mfilename('fullpath');
[scriptDir, ~, ~] = fileparts(scriptPath);
repoRoot = fileparts(scriptDir);

% Add MATLAB I/O functions
ioPath = fullfile(repoRoot, 'matlab', 'io');
addpath(ioPath);

if ~exist('readKLBstack', 'file')
    error('readKLBstack not found in %s', ioPath);
end

% Configuration
dataDir = 'D:\W2_DATA\foconnell\isoview_development\mosquito-larva_20250930_165806.corrected\SPM00\TM000000';
outputDir = fullfile(scriptDir, 'matlab_output');

testFiles = {
    'SPM00_TM000000_CM00_CHN00.klb'
    'SPM00_TM000000_CM01_CHN00.klb'
    'SPM00_TM000000_CM02_CHN01.klb'
    'SPM00_TM000000_CM03_CHN01.klb'
};

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

fprintf('Reading %d KLB files\n\n', length(testFiles));

for idx = 1:length(testFiles)
    filename = testFiles{idx};
    klbPath = fullfile(dataDir, filename);

    fprintf('[%d/%d] %s\n', idx, length(testFiles), filename);

    if ~exist(klbPath, 'file')
        fprintf('  Skipped (not found)\n\n');
        continue;
    end

    % Read KLB
    tic;
    volume = readKLBstack(klbPath, feature('numcores'));
    readTime = toc;

    % Save as MAT
    [~, baseName, ~] = fileparts(filename);
    matPath = fullfile(outputDir, sprintf('%s_matlab.mat', baseName));

    tic;
    save(matPath, 'volume', '-v7.3');
    saveTime = toc;

    fprintf('  Shape: [%s] %s\n', num2str(size(volume)), class(volume));
    fprintf('  Range: [%d, %d]\n', min(volume(:)), max(volume(:)));
    fprintf('  Read: %.1fs | Save: %.1fs\n\n', readTime, saveTime);
end

fprintf('Done. References saved to: %s\n', outputDir);
