"""Basic pyklb functionality test."""

import sys
from pathlib import Path

import numpy as np
import pyklb

DATA_DIR = Path(
    r"D:\W2_DATA\foconnell\isoview_development"
    r"\mosquito-larva_20250930_165806.corrected\SPM00\TM000000"
)
TEST_FILE = "SPM00_TM000000_CM00_CHN00.klb"


def test_import():
    """Test pyklb import."""
    print("Testing pyklb import...")
    version = getattr(pyklb, '__version__', 'unknown')
    print(f"  pyklb version: {version}")


def test_header_read():
    """Test KLB header reading."""
    test_path = DATA_DIR / TEST_FILE
    if not test_path.exists():
        print(f"  Skipping: {test_path} not found")
        return

    print(f"\nTesting header read: {TEST_FILE}")
    header = pyklb.readheader(str(test_path))

    print(f"  Shape: {header['imagesize_tczyx']}")
    print(f"  Dtype: {header['datatype']}")
    print(f"  Compression: {header['compression']}")
    print(f"  Pixel spacing: {header['pixelspacing_tczyx']}")


def test_volume_read():
    """Test KLB volume reading."""
    test_path = DATA_DIR / TEST_FILE
    if not test_path.exists():
        print(f"  Skipping: {test_path} not found")
        return

    print(f"\nTesting volume read: {TEST_FILE}")
    volume = pyklb.readfull(str(test_path))

    print(f"  Shape: {volume.shape}")
    print(f"  Dtype: {volume.dtype}")
    print(f"  Range: [{volume.min()}, {volume.max()}]")
    print(f"  Mean: {volume.mean():.2f}")
    print(f"  Memory: {volume.nbytes / 1024**2:.0f} MB")

    # Sanity checks
    assert volume.ndim == 3, f"Expected 3D volume, got {volume.ndim}D"
    assert volume.size > 0, "Volume is empty"
    assert np.isfinite(volume).all(), "Volume contains non-finite values"
    print("  Sanity checks passed")


def main():
    """Run all tests."""
    print("=" * 80)
    print("PyKLB Functionality Test")
    print("=" * 80)

    try:
        test_import()
        test_header_read()
        test_volume_read()
        print("\n" + "=" * 80)
        print("All tests passed")
    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
