"""Test MATLAB and Python KLB readers produce identical results."""

from pathlib import Path
from typing import Tuple

import h5py
import numpy as np
import pyklb

try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

DATA_DIR = Path(
    r"D:\W2_DATA\foconnell\isoview_development"
    r"\mosquito-larva_20250930_165806.corrected\SPM00\TM000000"
)
MATLAB_REF_DIR = Path(__file__).parent / "matlab_output"

TEST_FILES = [
    "SPM00_TM000000_CM00_CHN00.klb",
    "SPM00_TM000000_CM01_CHN00.klb",
    "SPM00_TM000000_CM02_CHN01.klb",
    "SPM00_TM000000_CM03_CHN01.klb",
]


def read_klb_python(filepath: Path) -> np.ndarray:
    """Read KLB file using pyklb."""
    return pyklb.readfull(str(filepath))


def read_klb_matlab_reference(matlab_file: Path) -> np.ndarray:
    """Load MATLAB-saved KLB data from .mat file (v7.3 HDF5 format)."""
    with h5py.File(matlab_file, 'r') as f:
        # HDF5 stores in column-major order, transpose to row-major
        return np.transpose(f['volume'][:])


def match_axis_order(matlab_vol: np.ndarray, python_vol: np.ndarray) -> Tuple[np.ndarray, bool]:
    """Match Python volume axis order to MATLAB.

    MATLAB: (Y, X, Z), Python: (Z, Y, X)

    Returns:
        Transposed python volume and whether match was successful
    """
    if matlab_vol.shape == python_vol.shape:
        return python_vol, True

    # Try common permutations
    for perm in [(2, 1, 0), (0, 2, 1), (1, 2, 0), (2, 0, 1), (1, 0, 2)]:
        test_vol = np.transpose(python_vol, perm)
        if test_vol.shape == matlab_vol.shape:
            return test_vol, True

    return python_vol, False


def compare_volumes(matlab_vol: np.ndarray, python_vol: np.ndarray) -> dict:
    """Compare MATLAB and Python volumes."""
    python_vol, matched = match_axis_order(matlab_vol, python_vol)

    if not matched:
        return {
            'shapes_match': False,
            'matlab_shape': matlab_vol.shape,
            'python_shape': python_vol.shape,
        }

    exactly_equal = np.array_equal(matlab_vol, python_vol)
    diff = np.abs(matlab_vol.astype(np.float64) - python_vol.astype(np.float64))

    return {
        'shapes_match': True,
        'exactly_equal': exactly_equal,
        'max_diff': float(diff.max()),
        'mean_diff': float(diff.mean()),
        'allclose': np.allclose(matlab_vol, python_vol, rtol=1e-5, atol=0),
    }


# pytest-based tests
if HAS_PYTEST:
    @pytest.mark.parametrize("filename", TEST_FILES)
    def test_klb_matlab_python_match(filename):
        """Verify MATLAB and Python KLB readers produce identical results."""
        klb_path = DATA_DIR / filename
        matlab_ref = MATLAB_REF_DIR / f"{Path(filename).stem}_matlab.mat"

        if not klb_path.exists():
            pytest.skip(f"KLB file not found: {klb_path}")
        if not matlab_ref.exists():
            pytest.skip(f"MATLAB reference not found. Run save_matlab_klb.m first.")

        matlab_vol = read_klb_matlab_reference(matlab_ref)
        python_vol = read_klb_python(klb_path)

        results = compare_volumes(matlab_vol, python_vol)

        assert results['shapes_match'], \
            f"Shape mismatch: MATLAB {results.get('matlab_shape')} vs Python {results.get('python_shape')}"
        assert results['exactly_equal'] or results['allclose'], \
            f"Volumes differ: max_diff={results['max_diff']}"


def run_comparison():
    """Run comparison for all test files (non-pytest usage)."""
    if not DATA_DIR.exists():
        print(f"Error: Data directory not found: {DATA_DIR}")
        return

    if not MATLAB_REF_DIR.exists():
        print(f"Error: MATLAB references not found. Run save_matlab_klb.m first.")
        return

    print("KLB MATLAB vs Python Comparison")
    print("=" * 80)

    results = []
    for filename in TEST_FILES:
        klb_path = DATA_DIR / filename
        matlab_ref = MATLAB_REF_DIR / f"{Path(filename).stem}_matlab.mat"

        if not klb_path.exists() or not matlab_ref.exists():
            continue

        print(f"\n{filename}")

        matlab_vol = read_klb_matlab_reference(matlab_ref)
        python_vol = read_klb_python(klb_path)

        result = compare_volumes(matlab_vol, python_vol)
        results.append(result)

        print(f"  Shapes: MATLAB {matlab_vol.shape} | Python {python_vol.shape}")
        if result['shapes_match']:
            print(f"  Match: {'exact' if result['exactly_equal'] else 'numerical'}")
            print(f"  Max diff: {result['max_diff']}")
        else:
            print(f"  Error: Shape mismatch")

    print("\n" + "=" * 80)
    exact = sum(1 for r in results if r.get('exactly_equal', False))
    close = sum(1 for r in results if r.get('allclose', False) and not r.get('exactly_equal', False))
    print(f"Results: {exact} exact, {close} close, {len(results)} total")

    if all(r.get('exactly_equal') or r.get('allclose', False) for r in results):
        print("All tests passed")
    else:
        print("Some tests failed")


if __name__ == "__main__":
    run_comparison()
