"""convert OME-TIFF volumes to webknossos-compatible zarr v3.

output layout matches webknossos conventions:
  - 4D arrays (C, X, Y, Z) with dimension_names ["c", "x", "y", "z"]
  - pyramid dirs named by mag factor: 1/, 2-2-1/, 4-4-1/, ...
  - Z padded to shard boundary
  - datasource-properties.json at dataset root
  - codec chain: transpose(3,2,1,0) -> bytes(le) -> zstd
"""

import json
import sys
import time
from pathlib import Path

import numpy as np
import tifffile

from isoview.io import _mag_label


def _read_spacing_from_ome(path: Path) -> tuple[float, float, float] | None:
    """extract ZYX pixel spacing (um) from OME-TIFF metadata."""
    import xml.etree.ElementTree as ET

    tf = tifffile.TiffFile(str(path))
    if not tf.ome_metadata:
        return None

    root = ET.fromstring(tf.ome_metadata)
    ns = {"ome": "http://www.openmicroscopy.org/Schemas/OME/2016-06"}
    pixels = root.find(".//ome:Pixels", ns)
    if pixels is None:
        return None

    try:
        sz = float(pixels.get("PhysicalSizeZ", 0))
        sy = float(pixels.get("PhysicalSizeY", 0))
        sx = float(pixels.get("PhysicalSizeX", 0))
        if sz > 0 and sy > 0 and sx > 0:
            return (sz, sy, sx)
    except (ValueError, TypeError):
        pass
    return None


def _to_cxyz(vol_zyx: np.ndarray) -> np.ndarray:
    """ZYX -> CXYZ (C=1)."""
    return np.transpose(vol_zyx, (2, 1, 0))[np.newaxis]


def _pad_to_multiple(arr: np.ndarray, axis: int, multiple: int) -> np.ndarray:
    """zero-pad arr along axis to next multiple."""
    size = arr.shape[axis]
    pad_n = (multiple - size % multiple) % multiple
    if pad_n == 0:
        return arr
    pad_widths = [(0, 0)] * arr.ndim
    pad_widths[axis] = (0, pad_n)
    return np.pad(arr, pad_widths)


def _write_array(store, name, data, chunks_4d, shards_4d, compressors,
                 filters, serializer):
    """write a single 4D zarr v3 array with sharding."""
    import zarr

    kwargs = dict(
        store=store, name=name,
        shape=data.shape, dtype=data.dtype,
        chunks=chunks_4d,
        shards=shards_4d,
        compressors=compressors,
        filters=filters,
        serializer=serializer,
        dimension_names=["c", "x", "y", "z"],
        zarr_format=3, overwrite=True,
    )
    arr = zarr.create_array(**kwargs)
    arr[:] = data


def tiff2wk(args):
    """main entry point for tiff2wk conversion."""
    import zarr
    from zarr.codecs import ZstdCodec, TransposeCodec, BytesCodec

    from isoview.io import _compute_anisotropic_mags, _median_downsample

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"error: {input_path} not found", file=sys.stderr)
        sys.exit(1)

    # output directory
    if args.output:
        out_dir = Path(args.output)
    else:
        out_dir = input_path.parent / f"{input_path.stem}_wk"
    out_dir.mkdir(parents=True, exist_ok=True)

    # pixel spacing
    if args.spacing:
        spacing_zyx = tuple(args.spacing)
    else:
        spacing_zyx = _read_spacing_from_ome(input_path)
        if spacing_zyx is None:
            print(
                "error: no pixel spacing in TIFF metadata. "
                "use --spacing Z Y X",
                file=sys.stderr,
            )
            sys.exit(1)

    print(f"input:   {input_path}")
    print(f"output:  {out_dir}")
    print(f"spacing: Z={spacing_zyx[0]:.4f} Y={spacing_zyx[1]:.5f} X={spacing_zyx[2]:.5f} um")

    # read volume
    t0 = time.perf_counter()
    vol = tifffile.imread(str(input_path))
    if vol.ndim != 3:
        print(f"error: expected 3D volume, got {vol.ndim}D shape {vol.shape}", file=sys.stderr)
        sys.exit(1)
    print(f"loaded:  {vol.shape} {vol.dtype} ({vol.nbytes / 1e9:.2f} GB) "
          f"in {time.perf_counter() - t0:.1f}s")

    # settings
    layer_name = args.layer
    chunk_n = args.chunks
    shard_xy = args.shard_xy
    shard_z = args.shard_z
    level = args.compression_level

    # 3D ZYX chunks/shards (for pyramid computation and downsampling)
    chunks_3d = (chunk_n, chunk_n, chunk_n)
    shards_3d = (shard_z, shard_xy, shard_xy)

    # 4D CXYZ chunks/shards
    chunks_4d = (1, chunk_n, chunk_n, chunk_n)
    shards_4d = (1, shard_xy, shard_xy, shard_z)

    # codec chain: transpose -> bytes -> zstd (matches wk)
    filters = [TransposeCodec(order=(3, 2, 1, 0))]
    serializer = BytesCodec()
    compressors = [ZstdCodec(level=level, checksum=True)]

    # compute pyramid mags
    if args.no_pyramid:
        mags = [(1, 1, 1)]
    else:
        mags = _compute_anisotropic_mags(spacing_zyx, vol.shape, args.max_levels)
    print(f"mags:    {[_mag_label(m) for m in mags]}")

    # zarr store
    store = zarr.storage.LocalStore(str(out_dir))

    # write base mag
    t_write = time.perf_counter()
    base_4d = _to_cxyz(vol)
    base_4d = _pad_to_multiple(base_4d, axis=3, multiple=shard_z)
    base_label = _mag_label(mags[0])
    print(f"writing: {layer_name}/{base_label}  shape={list(base_4d.shape)}", end="", flush=True)
    _write_array(store, f"{layer_name}/{base_label}", base_4d,
                 chunks_4d, shards_4d, compressors, filters, serializer)
    print(f"  ({time.perf_counter() - t_write:.1f}s)")

    # write pyramid levels
    if len(mags) > 1:
        current = vol
        prev_mag = mags[0]
        for mag in mags[1:]:
            t_lev = time.perf_counter()
            step_factors = tuple(m // p for m, p in zip(mag, prev_mag))
            current = _median_downsample(current, step_factors)
            if current.dtype != vol.dtype:
                current = current.astype(vol.dtype)

            level_4d = _to_cxyz(current)
            # clamp shards to level shape, then pad Z
            lev_shards_4d = tuple(min(s, d) for s, d in zip(shards_4d, level_4d.shape))
            lev_shards_4d = tuple(max(c, (s // c) * c) for s, c in zip(lev_shards_4d, chunks_4d))
            level_4d = _pad_to_multiple(level_4d, axis=3, multiple=lev_shards_4d[3])
            # re-clamp after padding
            lev_shards_4d = tuple(min(s, d) for s, d in zip(shards_4d, level_4d.shape))
            lev_shards_4d = tuple(max(c, (s // c) * c) for s, c in zip(lev_shards_4d, chunks_4d))
            lev_chunks_4d = tuple(min(c, d) for c, d in zip(chunks_4d, level_4d.shape))

            label = _mag_label(mag)
            print(f"writing: {layer_name}/{label}  shape={list(level_4d.shape)}", end="", flush=True)
            _write_array(store, f"{layer_name}/{label}", level_4d,
                         lev_chunks_4d, lev_shards_4d, compressors, filters, serializer)
            print(f"  ({time.perf_counter() - t_lev:.1f}s)")
            prev_mag = mag

    # ome-ngff multiscales on the layer group
    spacing_nm = [
        float(spacing_zyx[2]) * 1000,  # X nm
        float(spacing_zyx[1]) * 1000,  # Y nm
        float(spacing_zyx[0]) * 1000,  # Z nm
    ]
    datasets = []
    for mag in mags:
        label = _mag_label(mag)
        scale = [
            1.0,
            spacing_nm[0] * mag[2],  # X
            spacing_nm[1] * mag[1],  # Y
            spacing_nm[2] * mag[0],  # Z
        ]
        datasets.append({
            "path": label,
            "coordinateTransformations": [{"type": "scale", "scale": scale}],
        })

    axes = [
        {"name": "c", "type": "channel"},
        {"name": "x", "type": "space", "unit": "nanometer"},
        {"name": "y", "type": "space", "unit": "nanometer"},
        {"name": "z", "type": "space", "unit": "nanometer"},
    ]
    multiscales = [{"axes": axes, "datasets": datasets}]

    root = zarr.open_group(store=store, mode="a", zarr_format=3)
    layer_grp = root.require_group(layer_name)
    layer_grp.attrs["ome"] = {"version": "0.5", "multiscales": multiscales}

    # datasource-properties.json
    dataset_name = args.name or out_dir.name
    mag_entries = []
    for mag in mags:
        label = _mag_label(mag)
        mag_entries.append({
            "mag": [mag[2], mag[1], mag[0]],  # XYZ
            "path": f"./{layer_name}/{label}",
            "axisOrder": {"c": 0, "x": 1, "y": 2, "z": 3},
        })

    ds_props = {
        "id": {"name": dataset_name, "team": ""},
        "scale": {
            "factor": [
                float(spacing_zyx[2]),  # X
                float(spacing_zyx[1]),  # Y
                float(spacing_zyx[0]),  # Z
            ],
            "unit": "micrometer",
        },
        "dataLayers": [{
            "name": layer_name,
            "category": "color",
            "boundingBox": {
                "topLeft": [0, 0, 0],
                "width": int(vol.shape[2]),   # X
                "height": int(vol.shape[1]),  # Y
                "depth": int(vol.shape[0]),   # Z
            },
            "elementClass": str(vol.dtype),
            "dataFormat": "zarr3",
            "mags": mag_entries,
            "numChannels": 1,
        }],
        "version": 1,
    }

    props_path = out_dir / "datasource-properties.json"
    props_path.write_text(json.dumps(ds_props, indent=4))

    elapsed = time.perf_counter() - t0
    # total output size
    total_bytes = sum(f.stat().st_size for f in out_dir.rglob("*") if f.is_file())
    print(f"\ndone in {elapsed:.1f}s  output: {total_bytes / 1e6:.0f} MB")
    print(f"datasource: {props_path}")
