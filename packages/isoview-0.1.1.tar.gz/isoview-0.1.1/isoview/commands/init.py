"""isoview init — scaffold pipeline scripts for a dataset."""

from pathlib import Path

CORRECT_TEMPLATE = '''from pathlib import Path
from isoview import ProcessingConfig, correct_stack

raw_stack_path = Path(r"{data_path}")

config = ProcessingConfig(
    # root folder containing flat SPC##_TM#####_*.stack files
    # mode auto-detected: multiple TM = timelapse, single TM + multiple SPC = tiled
    input_dir=raw_stack_path,

    timepoints=None,                       # (default=None) None = auto-detect from TM## in filenames
    corrected_suffix=".corrected",          # (default=".corrected") output folder suffix

    # output
    output_format="tif",                      # (default="zarr") tif, klb, or zarr
    compression="zstd",                     # (default="zstd") zstd, lzw, deflate, or None
    compression_level=9,                    # (default=3) 1-22 for zstd, 1-9 for others
    workers=16,

    # pyramids
    pyramid=True,                           # generate resolution pyramids (only for OME-TIFF)
    pyramid_max_layers=4,                   # maximum number of additional pyramid levels

    # pixel correction
    median_kernel=(3, 3),                   # (default=(3,3)) dead pixel filter kernel, None to disable
    background_percentile=5.0,              # (default=5.0) percentile for background estimation
    mask_percentile=1.0,                    # (default=1.0) percentile for mask threshold
    subsample_factor=100,                   # (default=100) subsampling for percentile computation

    # segmentation
    segment_mode=1,                         # (default=1) 0=none, 1=generate+save masks
    gauss_kernel=5,                         # (default=5) gaussian filter kernel size
    gauss_sigma=2.0,                        # (default=2.0) gaussian filter sigma
    segment_threshold=0.5,                  # (default=0.4) threshold for foreground segmentation
    splitting=10,                           # (default=10) block size (currently for gaussian filtering only)

    # tenengrad sharpness
    do_tenengrad=True,                      # (default=False) per-Z tenengrad plot per camera pair

    # microscope parameters
    detection_objective_mag=16.0,           # (default=None) None = read from XML
    # pixel_spacing_z=None,                 # (default=None) None = read from XML (axial_step)
    # pixel_spacing_camera=6.5,             # (default=6.5) physical camera pixel size (um)

    # per-view cropping, keyed by view index (0=VW00, 90=VW90)
    # crop_left=None,                       # (default=None) {{view: pixels}}
    # crop_top=None,                        # (default=None) {{view: pixels}}
    # crop_width=None,                      # (default=None) {{view: pixels}}
    # crop_height=None,                     # (default=None) {{view: pixels}}
    # crop_front=None,                      # (default=None) {{view: z-planes}}
    # crop_depth=None,                      # (default=None) {{view: z-planes}}
)

if __name__ == "__main__":
    correct_stack(config)
'''

FUSE_TEMPLATE = '''from pathlib import Path
from isoview import ProcessingConfig, multi_fuse

raw_stack_path = Path(r"{data_path}")

config = ProcessingConfig(
    # input: folder with flat SPC##_TM#####_*.stack files
    # corrected data read from input_dir.parent / f"{{input_dir.name}}{{corrected_suffix}}"
    # fused output goes to .corrected/Results/MultiFused_{{blending_method}}/
    input_dir=raw_stack_path,
    corrected_suffix=".corrected",          # (default=".corrected") output folder suffix
    output_format="tif",                    # (default="zarr") tif, klb, or zarr

    # pyramids
    pyramid=True,                           # (default=True)
    pyramid_max_layers=4,                   # max additional levels (default=4)

    timepoints=None,                        # (default=None) None = auto-detect from TM## in filenames
    workers=4,

    # blending: how to combine the two camera views along Z
    blending_method="geometric",            # (default="geometric") geometric or adaptive
    blending_range=4,                       # how many Z-planes to blend over (default=20)
    transition_plane=None,                  # Z-index where cameras cross over (default=None = center)

    # which camera is sharper at low Z
    # 1 = CM00/CM02 (first in pair), 2 = CM01/CM03 (second in pair)
    front_flag=2,

    # coarse grid search for XY alignment between camera pairs
    search_offsets_x=(-200, 250, 10),       # (default=(-50,50,10))
    search_offsets_y=(-250, 250, 10),       # (default=(-50,50,10))

    # mask / background
    mask_percentile=1.0,                    # (default=1.0)
    background_percentile=5.0,              # (default=5.0)

    # microscope parameters
    detection_objective_mag=16.0,           # (default=None) None = read from XML
    # pixel_spacing_z=None,                 # (default=None) None = read from XML
    # pixel_spacing_camera=6.5,             # (default=6.5) camera pixel size in um

    # flip / rotation overrides
    # rotation=0,                           # 0: none, 1: 90 cw, -1: 90 ccw
    # flip_horizontal=True,
    # flip_vertical=False,
    # flip_z=False,
)

if __name__ == "__main__":
    multi_fuse(
        config,
        estimate_params=True,
        apply_fusion=True,
        overwrite=True,
    )
'''


def init_pipeline(data_path: Path) -> Path:
    """create scripts/ next to data_path with pre-filled pipeline scripts."""
    data_path = Path(data_path).resolve()
    if not data_path.is_dir():
        raise FileNotFoundError(f"data directory not found: {data_path}")

    scripts_dir = data_path.parent / "scripts"
    scripts_dir.mkdir(exist_ok=True)

    path_str = str(data_path)

    correct_file = scripts_dir / "correct_stack.py"
    correct_file.write_text(CORRECT_TEMPLATE.format(data_path=path_str))

    fuse_file = scripts_dir / "multi_fuse.py"
    fuse_file.write_text(FUSE_TEMPLATE.format(data_path=path_str))

    return scripts_dir
