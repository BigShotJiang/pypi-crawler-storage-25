"""Main processing pipeline for isoview microscopy data."""

import json
import logging
import shutil
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import numpy as np

from .config import ProcessingConfig
from .log import setup_logging, setup_queue_logging, start_log_listener

logger = logging.getLogger(__name__)
from .corrections import correct_dead_pixels, estimate_background, percentile_interp
from .io import (
    detect_mode,
    detect_project_contents,
    read_all_xml_metadata,
    read_background_values,
    read_volume,
    write_volume,
)
from .segmentation import create_coordinate_masks, fuse_masks, segment_foreground
from .transforms import crop_volume


@dataclass
class RunLog:
    """Structured log for a pipeline run."""

    pipeline: str
    config_dict: dict = field(default_factory=dict)
    started_at: str = ""
    completed_at: str = ""
    elapsed_seconds: float = 0.0
    steps: list = field(default_factory=list)
    summary: dict = field(default_factory=dict)

    _start_time: float = field(default=0.0, repr=False)

    def start(self):
        self._start_time = time.time()
        self.started_at = datetime.now(UTC).isoformat(timespec="seconds")

    def finish(self):
        self.completed_at = datetime.now(UTC).isoformat(timespec="seconds")
        self.elapsed_seconds = round(time.time() - self._start_time, 1)
        succeeded = sum(1 for s in self.steps if s.get("status") == "success")
        skipped = sum(1 for s in self.steps if s.get("status") == "skipped")
        failed = sum(1 for s in self.steps if s.get("status") == "failed")
        self.summary = {
            "total_items": len(self.steps),
            "succeeded": succeeded,
            "skipped": skipped,
            "failed": failed,
        }

    def to_dict(self) -> dict:
        return {
            "config": self.config_dict,
            "pipeline": self.pipeline,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "elapsed_seconds": self.elapsed_seconds,
            "steps": self.steps,
            "summary": self.summary,
        }

    def save(self, path: "str | Path"):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: "str | Path") -> "RunLog":
        with open(path) as f:
            d = json.load(f)
        log = cls(pipeline=d.get("pipeline", ""))
        log.config_dict = d.get("config", {})
        log.started_at = d.get("started_at", "")
        log.completed_at = d.get("completed_at", "")
        log.elapsed_seconds = d.get("elapsed_seconds", 0.0)
        log.steps = d.get("steps", [])
        log.summary = d.get("summary", {})
        return log


class IsoviewProcessor:
    """Process multi-view light sheet microscopy data."""

    def __init__(self, config: ProcessingConfig):
        """Initialize processor with configuration."""
        self.config = config
        setup_logging()
        self.structure = detect_mode(config.input_dir, config.specimen)
        self.contents = detect_project_contents(
            config.input_dir, config.corrected_suffix, config.specimen
        )

        # load metadata from XML (use first specimen for initial config)
        spc = config.specimens[0] if config.specimens else config.specimen
        self.metadata, self.per_camera_metadata = read_all_xml_metadata(
            config.input_dir, spc
        )

        if self.metadata:
            self.config.update_from_metadata(self.metadata)

        # background values (shared across all tiles/timepoints)
        bg_files = self.contents.get("backgrounds", [])
        if not bg_files and self.structure == "tiled":
            # tiled: backgrounds are in the first tile entry
            first_tile = next(iter(self.contents.get("tiles", {}).values()), None)
            bg_files = first_tile["backgrounds"] if first_tile else []
        self.background_values = read_background_values(bg_files, percentile=self.config.background_percentile)

        # per-camera crop info for metadata adjustment (populated during load)
        self._crop_info = {}
        # RunLog state
        self._current_step = None
        self._last_load_info = None
        # optional queue for reporting per-camera progress to main process
        self._progress_queue = None

        # create output directory
        self.config.output_dir.mkdir(exist_ok=True)
        self.config.projection_dir.mkdir(exist_ok=True)

    def _find_raw_stack(self, timepoint: int, camera: int) -> Path | None:
        """look up raw stack path from scan result, matching any CHN for this camera."""
        if self.structure == "tiled":
            stacks = self.contents["tiles"].get(f"SPM{timepoint:02d}", {}).get("raw_stacks", {})
        else:
            stacks = self.contents["timepoints"].get(timepoint, {}).get("raw_stacks", {})
        # keys are (camera, chn) — find first match for this camera
        for (cam, _chn), path in stacks.items():
            if cam == camera:
                return path
        return None

    def process_single_timepoint(self, timepoint: int) -> None:
        """Process single timepoint or specimen.

        crop, rotate, flip, dead pixel correction

        Args:
            timepoint: timepoint index (or specimen index for tiled mode)
        """
        # tiled: output_dir/SPM##/ (files directly here)
        # timelapse: output_dir/SPM##/TM######/
        if self.config.tiled:
            output_subdir = self.config.output_dir / f"SPM{timepoint:02d}"
        else:
            output_subdir = (
                self.config.output_dir
                / f"SPM{self.config.specimen:02d}"
                / f"TM{timepoint:06d}"
            )
        output_subdir.mkdir(exist_ok=True, parents=True)

        # copy XML files to output (preserves wavelength, filter, laser power, etc.)
        self._copy_xml_files(timepoint, output_subdir)

        if self.config.reference_channels is not None:
            ref_groups = self.config.reference_channels
            dep_groups = self.config.dependent_channels or [[] for _ in ref_groups]
        else:
            # each channel is independent reference
            ref_groups = [[ch] for ch in self.config.views]
            dep_groups = [[] for _ in self.config.views]

        # process each camera
        for cam_idx, camera in enumerate(self.config.cameras):
            self._process_single_camera(
                timepoint, camera, cam_idx, output_subdir, ref_groups, dep_groups
            )

        # tenengrad diagnostic after all cameras are corrected
        if self.config.do_tenengrad:
            try:
                self._save_tenengrad_diagnostic(timepoint, output_subdir)
            except Exception as e:
                logger.warning(f"tenengrad diagnostic failed: {e}")

    def _process_single_camera(
        self,
        timepoint: int,
        camera: int,
        cam_idx: int,
        output_dir: Path,
        ref_groups: list[list[int]],
        dep_groups: list[list[int]],
    ) -> None:
        """Process single camera."""
        # get the valid channel for this camera from the mapping
        valid_view = self.config.camera_view_map.get(camera)

        # process each reference group, but only if it matches the camera's channel
        for r_idx, (ref_channels, dep_channels) in enumerate(zip(ref_groups, dep_groups)):
            # filter ref_channels to only include the valid channel for this camera
            filtered_refs = [ch for ch in ref_channels if ch == valid_view]
            filtered_deps = [ch for ch in dep_channels if ch == valid_view]

            if not filtered_refs:
                # no valid channels for this camera in this group
                continue

            self._process_single_channel_group(
                timepoint, camera, cam_idx, output_dir, filtered_refs, filtered_deps
            )

    def _process_single_channel_group(
        self,
        timepoint: int,
        camera: int,
        cam_idx: int,
        output_dir: Path,
        ref_channels: list[int],
        dep_channels: list[int],
    ) -> None:
        """Process channel group."""
        cam_start = time.time()
        view = self.config.camera_view_map.get(camera, 0)
        cam_entry = {
            "camera": camera,
            "view": view,
            "status": "success",
            "timings": {},
        }

        # skip if output already exists and overwrite is disabled
        if not self.config.overwrite:
            all_exist = True
            for channel in list(ref_channels) + list(dep_channels):
                prefix = self._file_prefix(timepoint, camera)
                found = any(
                    (output_dir / f"{prefix}{ext}").exists()
                    for ext in [".ome.tif", ".tif", ".tiff", ".klb", ".zarr"]
                )
                if not found:
                    all_exist = False
                    break
            if all_exist:
                logger.info(f"CM{camera} VW{ref_channels[0]:02d} skipped (output exists)")
                cam_entry["status"] = "skipped"
                if hasattr(self, "_current_step") and self._current_step:
                    self._current_step["cameras"].append(cam_entry)
                return

        ref_stacks = []
        ref_masks = []

        for channel in ref_channels:
            self._last_load_info = None
            stack = self._load_and_preprocess(timepoint, camera, cam_idx, channel)
            if stack is None:
                continue  # skip missing files
            # capture load info
            if self._last_load_info:
                cam_entry["input_shape"] = self._last_load_info["input_shape"]
                cam_entry["output_shape"] = self._last_load_info["output_shape"]
                cam_entry["timings"].update(self._last_load_info["timings"])

            subsampled = stack.ravel()[:: self.config.subsample_factor]
            subsampled = subsampled[subsampled > 0]
            min_intensity_stack = percentile_interp(subsampled, self.config.background_percentile)

            # generate segmentation mask if needed
            if self.config.segment_mode == 1:
                t0 = time.time()
                mask = segment_foreground(
                    stack,
                    kernel_sigma=self.config.gauss_sigma,
                    kernel_size=self.config.gauss_kernel,
                    threshold=self.config.segment_threshold,
                    mask_percentile=self.config.mask_percentile,
                    scaling=self.config.scaling,
                    splitting=self.config.splitting,
                    subsample_factor=self.config.subsample_factor,
                    verbose=False,
                )
                segment_time = round(time.time() - t0, 1)
                logger.debug(f"CM{camera} segment: {segment_time:.1f}s")
                cam_entry["timings"]["segment"] = segment_time
                ref_masks.append(mask)

                # save min intensity for both mask and stack
                min_intensity_mask = percentile_interp(
                    mask.ravel()[:: self.config.subsample_factor], self.config.mask_percentile
                )
                min_intensity = np.array([min_intensity_mask, min_intensity_stack])
            else:
                min_intensity = min_intensity_stack

            # save min intensity
            self._save_min_intensity(output_dir, timepoint, camera, min_intensity)

            ref_stacks.append((stack, channel))

        # skip if no stacks loaded (all files missing for this camera)
        if not ref_stacks:
            cam_entry["status"] = "skipped"
            cam_entry["elapsed_seconds"] = round(time.time() - cam_start, 1)
            if hasattr(self, "_current_step") and self._current_step:
                self._current_step["cameras"].append(cam_entry)
            return

        # fuse masks if multiple references
        if len(ref_masks) > 1 and self.config.segment_mode == 1:
            fused_mask = fuse_masks(ref_masks)
        elif ref_masks:
            fused_mask = ref_masks[0]
        else:
            fused_mask = None

        # build master channel list (refs + deps)
        master_list = list(ref_channels) + list(dep_channels)

        # save segmentation mask (not applied here; used later by multi_fuse)
        if self.config.segment_mode == 1 and fused_mask is not None:
            self._save_segmentation_mask_file(
                output_dir, timepoint, camera, fused_mask
            )

        # save reference stacks
        t_save = time.time()
        for stack, channel in ref_stacks:
            # save volume
            self._save_volume_file(output_dir, timepoint, camera, stack)
            cam_entry["output_shape"] = list(stack.shape)

            # save xy projection
            projection = np.max(stack, axis=0)
            self._save_projection_file(timepoint, camera, projection)

        # generate and save coordinate masks
        if self.config.segment_mode == 1 and fused_mask is not None:
            xz_mask, xy_mask = create_coordinate_masks(fused_mask, self.config.splitting)
            self._save_coordinate_masks(
                output_dir, timepoint, camera, xz_mask, xy_mask
            )

        for channel in dep_channels:
            stack = self._load_and_preprocess(timepoint, camera, cam_idx, channel)
            if stack is None:
                continue  # skip missing files

            subsampled = stack.ravel()[:: self.config.subsample_factor]
            subsampled = subsampled[subsampled > 0]
            min_intensity = percentile_interp(subsampled, self.config.background_percentile)
            self._save_min_intensity(output_dir, timepoint, camera, min_intensity)

            # save volume
            self._save_volume_file(output_dir, timepoint, camera, stack)

            # save xy projection
            projection = np.max(stack, axis=0)
            self._save_projection_file(timepoint, camera, projection)

        cam_entry["timings"]["save"] = round(time.time() - t_save, 1)
        cam_entry["elapsed_seconds"] = round(time.time() - cam_start, 1)
        if hasattr(self, "_current_step") and self._current_step:
            self._current_step["cameras"].append(cam_entry)
        if self._progress_queue is not None:
            self._progress_queue.put(("cam_done", camera, cam_entry["elapsed_seconds"]))

    def _load_and_preprocess(
        self,
        timepoint: int,
        camera: int,
        cam_idx: int,
        channel: int,
    ) -> np.ndarray | None:
        """Load stack and apply preprocessing (crop, rotate, flip, dead pixel correction).

        Returns:
            Preprocessed volume, or None if stack file not found
        """
        # find and read stack
        stack_path = self._find_raw_stack(timepoint, camera)
        if stack_path is None:
            logger.warning(f"CM{camera} skipped (file not found)")
            return None
        t0 = time.time()
        stack = read_volume(stack_path)
        raw_shape = stack.shape
        read_time = round(time.time() - t0, 1)
        logger.info(f"CM{camera} read: {stack.shape} in {read_time:.1f}s")

        # apply per-view cropping (both cameras in a pair get the same crop)
        view = self.config.camera_view_map[camera]
        crop = self.config.get_crop(view)
        crop_front = crop["front"]
        crop_depth = crop["depth"]
        crop_top = crop["top"]
        crop_height = crop["height"]
        crop_left = crop["left"]
        crop_width = crop["width"]

        if crop_top or crop_left or crop_front or crop_height or crop_width or crop_depth:
            stack = crop_volume(
                stack,
                top=crop_top,
                left=crop_left,
                height=crop_height,
                width=crop_width,
                front=crop_front,
                depth=crop_depth,
            )
            # track crop info for metadata adjustment
            self._crop_info[camera] = {
                "raw_shape": raw_shape,
                "crop_front": crop_front,
                "crop_depth": crop_depth,
                "crop_top": crop_top,
                "crop_height": crop_height,
                "crop_left": crop_left,
                "crop_width": crop_width,
            }

        correct_time = None
        if self.config.median_kernel is not None:
            if cam_idx < len(self.background_values):
                bg = self.background_values[cam_idx]
            else:
                bg = estimate_background(
                    stack,
                    percentile=self.config.background_percentile,
                    subsample=self.config.subsample_factor,
                )
            t0 = time.time()
            stack = correct_dead_pixels(stack, bg, self.config.median_kernel)
            correct_time = round(time.time() - t0, 1)
            logger.info(f"CM{camera} correct: {correct_time:.1f}s")

        # store timings for RunLog (consumed by _process_single_channel_group)
        self._last_load_info = {
            "input_shape": list(raw_shape),
            "output_shape": list(stack.shape),
            "timings": {"read": read_time, "correct": correct_time},
        }
        return stack

    def _copy_xml_files(self, timepoint: int, output_dir: Path) -> None:
        """copy channel XML files to output directory, patching objective mag if overridden."""
        output_dir.mkdir(parents=True, exist_ok=True)

        if self.structure == "tiled":
            tile = self.contents["tiles"].get(f"SPM{timepoint:02d}")
            xml_map = tile["xml"] if tile else {}
        else:
            tp = self.contents["timepoints"].get(timepoint)
            xml_map = tp["xml"] if tp else {}

        user_mag = self.config._user_detection_objective_mag
        for ch, xml_path in xml_map.items():
            target = output_dir / f"{self._xml_prefix(timepoint, ch)}.xml"
            if not target.exists():
                if user_mag is not None:
                    self._copy_xml_with_patched_mag(xml_path, target, user_mag)
                else:
                    shutil.copy2(xml_path, target)

    @staticmethod
    def _copy_xml_with_patched_mag(src: Path, dst: Path, mag: float) -> None:
        """copy XML file, replacing objective magnification in @detection_objective."""
        import re

        text = src.read_text()
        # replace all NNx patterns inside detection_objective attribute value
        def _patch_obj(m):
            val = re.sub(r'(\d+(?:\.\d+)?)x', f'{mag:g}x', m.group(1))
            return f'detection_objective="{val}"'
        text = re.sub(r'detection_objective="([^"]*)"', _patch_obj, text)
        dst.write_text(text)

    def _save_min_intensity(
        self,
        output_dir: Path,
        timepoint: int,
        camera: int,
        min_intensity,
    ) -> None:
        """Save min intensity to npz file."""
        filename = f"{self._file_prefix(timepoint, camera)}.minIntensity.npz"
        np.savez(output_dir / filename, min_intensity=min_intensity)

    def _save_segmentation_mask_file(
        self,
        output_dir: Path,
        timepoint: int,
        camera: int,
        mask: np.ndarray,
    ) -> None:
        """Save segmentation mask."""
        prefix = self._file_prefix(timepoint, camera)
        write_volume(
            mask,
            output_dir / f"{prefix}.segmentationMask{self.config.extension}",
            compression=self.config.compression,
            compression_level=self.config.compression_level,
        )

    def _save_coordinate_masks(
        self,
        output_dir: Path,
        timepoint: int,
        camera: int,
        xz_mask: np.ndarray,
        xy_mask: np.ndarray,
    ) -> None:
        """Save xz and xy coordinate masks."""
        prefix = self._file_prefix(timepoint, camera)

        write_volume(
            xz_mask[np.newaxis, :, :],
            output_dir / f"{prefix}.xzMask{self.config.flat_extension}",
            compression=self.config.compression,
            compression_level=self.config.compression_level,
        )

        write_volume(
            xy_mask[np.newaxis, :, :],
            output_dir / f"{prefix}.xyMask{self.config.flat_extension}",
            compression=self.config.compression,
            compression_level=self.config.compression_level,
        )

    def _save_volume_file(
        self,
        output_dir: Path,
        timepoint: int,
        camera: int,
        volume: np.ndarray,
    ) -> None:
        """Save processed volume."""
        prefix = self._file_prefix(timepoint, camera)

        # per-camera metadata (wavelength, stage position, crop provenance)
        camera_metadata = self.per_camera_metadata.get(camera, {}).copy()
        camera_metadata["min_intensity"] = float(np.min(volume))
        if camera in self._crop_info:
            ci = self._crop_info[camera]
            camera_metadata["raw_shape"] = list(ci["raw_shape"])
            camera_metadata["crop_params"] = {
                k: ci[k]
                for k in (
                    "crop_front", "crop_depth", "crop_top",
                    "crop_height", "crop_left", "crop_width",
                )
            }
            dz = float(self.config.pixel_spacing[0])
            dxy = float(self.config.pixel_spacing[1])
            if ci["crop_front"] and "stage_z" in (self.metadata or {}):
                camera_metadata["stage_z"] = self.metadata["stage_z"] + ci["crop_front"] * dz
            if ci["crop_top"] and "stage_y" in (self.metadata or {}):
                camera_metadata["stage_y"] = self.metadata["stage_y"] + ci["crop_top"] * dxy
            if ci["crop_left"] and "stage_x" in (self.metadata or {}):
                camera_metadata["stage_x"] = self.metadata["stage_x"] + ci["crop_left"] * dxy

        write_volume(
            volume,
            output_dir / f"{prefix}{self.config.extension}",
            pixel_spacing=self.config.pixel_spacing,
            compression=self.config.compression,
            compression_level=self.config.compression_level,
            chunks=self.config.zarr_chunks,
            shards=self.config.zarr_shards,
            metadata=self.metadata,
            camera_metadata=camera_metadata,
            pyramid=self.config.pyramid,
            pyramid_max_layers=self.config.pyramid_max_layers,
        )

    def _save_projection_file(
        self,
        timepoint: int,
        camera: int,
        projection: np.ndarray,
    ) -> None:
        """Save xy projection as 2D image (no OME metadata)."""
        import tifffile

        self.config.projection_dir.mkdir(parents=True, exist_ok=True)
        prefix = self._file_prefix(timepoint, camera)
        proj_path = (
            self.config.projection_dir / f"{prefix}.xyProjection{self.config.flat_extension}"
        )
        # write as simple 2D tiff without OME metadata
        kwargs = {}
        if self.config.compression is not None:
            kwargs["compression"] = self.config.compression
            kwargs["compressionargs"] = {"level": self.config.compression_level}
        tifffile.imwrite(proj_path, projection, **kwargs)

    def _save_raw_projections(self, timepoint: int) -> None:
        """save xy max projections of raw .stack files (no transforms or corrections)."""
        import tifffile

        raw_proj_dir = self.config.input_dir.parent / f"{self.config.input_dir.name}.raw.projections"
        raw_proj_dir.mkdir(parents=True, exist_ok=True)

        for camera in self.config.cameras:
            stack_path = self._find_raw_stack(timepoint, camera)
            if stack_path is None:
                continue
            stack = read_volume(stack_path)
            projection = np.max(stack, axis=0)
            channel = self.config.camera_view_map.get(camera, 0)
            prefix = self._file_prefix(timepoint, camera)
            proj_path = raw_proj_dir / f"{prefix}.xyProjection{self.config.flat_extension}"
            kwargs = {}
            if self.config.compression is not None:
                kwargs["compression"] = self.config.compression
                kwargs["compressionargs"] = {"level": self.config.compression_level}
            tifffile.imwrite(proj_path, projection, **kwargs)
            logger.info(f"raw projection CM{camera}: {proj_path.name}")

    def _save_tenengrad_diagnostic(self, timepoint: int, output_subdir: Path) -> None:
        """generate per-Z tenengrad difference plot for each camera pair.

        loads corrected volumes and segmentation masks from disk, computes
        tenengrad within the intersection mask, and saves a diagnostic PNG.
        """
        import cv2
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from scipy.ndimage import gaussian_filter1d

        SMOOTH = 5
        CAM_COLORS = ["#4fc3f7", "#81c784", "#ffb74d", "#e57373"]

        diag_dir = self.config.diagnostics_dir
        if diag_dir is None:
            diag_dir = self.config.output_dir / "diagnostics"
        diag_dir.mkdir(parents=True, exist_ok=True)

        ext = self.config.extension

        for cam_a, cam_b in self.config.camera_pairs:
            prefix_a = self._file_prefix(timepoint, cam_a)
            prefix_b = self._file_prefix(timepoint, cam_b)

            vol_a_path = output_subdir / f"{prefix_a}{ext}"
            vol_b_path = output_subdir / f"{prefix_b}{ext}"
            mask_a_path = output_subdir / f"{prefix_a}.segmentationMask{ext}"
            mask_b_path = output_subdir / f"{prefix_b}.segmentationMask{ext}"

            if not vol_a_path.exists() or not vol_b_path.exists():
                logger.debug(f"tenengrad: skipping CM{cam_a}-CM{cam_b}, volumes missing")
                continue

            vol_a = read_volume(vol_a_path)
            vol_b = read_volume(vol_b_path)
            nz = vol_a.shape[0]

            # build shared mask from intersection of both segmentation masks
            if mask_a_path.exists() and mask_b_path.exists():
                mask_a = read_volume(mask_a_path) > 0
                mask_b = read_volume(mask_b_path) > 0
                shared_mask = mask_a & mask_b
            else:
                shared_mask = np.ones(vol_a.shape, dtype=bool)

            # per-Z tenengrad within shared mask
            ten_a = np.zeros(nz, dtype=np.float64)
            ten_b = np.zeros(nz, dtype=np.float64)
            for zi in range(nz):
                m = shared_mask[zi]
                if not m.any():
                    continue
                for vol, ten in [(vol_a, ten_a), (vol_b, ten_b)]:
                    slc = vol[zi].astype(np.float32)
                    gx = cv2.Sobel(slc, cv2.CV_32F, 1, 0, ksize=3)
                    gy = cv2.Sobel(slc, cv2.CV_32F, 0, 1, ksize=3)
                    ten[zi] = float((gx**2 + gy**2)[m].mean())

            sm_a = gaussian_filter1d(ten_a, SMOOTH)
            sm_b = gaussian_filter1d(ten_b, SMOOTH)
            diff = sm_a - sm_b
            z_axis = np.arange(nz)

            fig, axes = plt.subplots(1, 2, figsize=(14, 4), facecolor="#1a1a1a")

            # tenengrad vs z
            ax = axes[0]
            ax.set_facecolor("#1a1a1a")
            ax.plot(z_axis, sm_a, color=CAM_COLORS[cam_a], linewidth=1.5, label=f"CM{cam_a}")
            ax.plot(z_axis, sm_b, color=CAM_COLORS[cam_b], linewidth=1.5, label=f"CM{cam_b}")
            ax.set_title(f"Tenengrad vs Z — CM{cam_a:02d} vs CM{cam_b:02d}",
                         color="white", fontsize=11)
            ax.set_xlabel("Z slice", color="#aaa")
            ax.set_ylabel("mean tenengrad", color="#aaa")
            ax.tick_params(colors="#666")
            for s in ax.spines.values():
                s.set_color("#444")
            ax.legend(fontsize=9, facecolor="#2a2a2a", edgecolor="#444", labelcolor="white")

            # difference
            ax = axes[1]
            ax.set_facecolor("#1a1a1a")
            ax.fill_between(z_axis, diff, 0, where=diff > 0, color=CAM_COLORS[cam_a], alpha=0.4)
            ax.fill_between(z_axis, diff, 0, where=diff < 0, color=CAM_COLORS[cam_b], alpha=0.4)
            ax.plot(z_axis, diff, color="white", linewidth=1.5)
            ax.axhline(0, color="#666", linestyle="--", linewidth=0.8)

            sc = np.where(np.diff(np.sign(diff)))[0]
            if len(sc) > 0:
                cz = int(sc[0])
                ax.axvline(cz, color="#ff5252", linestyle="--", linewidth=1.5)
                ax.text(cz + 1, 0.92, f"z={cz}", color="#ff5252", fontsize=10,
                        transform=ax.get_xaxis_transform())

            ax.set_title(
                f"Tenengrad Difference — CM{cam_a:02d} vs CM{cam_b:02d}\n"
                f"(+ = CM{cam_a} sharper)",
                color="white", fontsize=11,
            )
            ax.set_xlabel("Z slice", color="#aaa")
            ax.tick_params(colors="#666")
            for s in ax.spines.values():
                s.set_color("#444")

            fig.tight_layout()

            # naming: SPM00_TM000000_CM00_CM01_tenengrad.png
            if self.config.tiled:
                name = f"SPM{timepoint:02d}_CM{cam_a:02d}_CM{cam_b:02d}_tenengrad.png"
            else:
                name = (
                    f"SPM{self.config.specimen:02d}_TM{timepoint:06d}"
                    f"_CM{cam_a:02d}_CM{cam_b:02d}_tenengrad.png"
                )
            out_path = diag_dir / name
            fig.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#1a1a1a")
            plt.close(fig)
            logger.info(f"tenengrad diagnostic: {out_path.name}")

    def _file_prefix(self, timepoint: int, camera: int) -> str:
        """return filename prefix: SPM##_CM## (tiled) or SPM##_TM######_CM## (timelapse)."""
        if self.config.tiled:
            return f"SPM{timepoint:02d}_CM{camera:02d}"
        return f"SPM{self.config.specimen:02d}_TM{timepoint:06d}_CM{camera:02d}"

    def _xml_prefix(self, timepoint: int, channel: int) -> str:
        """return xml filename prefix: SPM##_CHN## (tiled) or SPM##_TM######_CHN## (timelapse)."""
        if self.config.tiled:
            return f"SPM{timepoint:02d}_CHN{channel:02d}"
        return f"SPM{self.config.specimen:02d}_TM{timepoint:06d}_CHN{channel:02d}"

    def run(self) -> RunLog:
        """Process all timepoints or tiles. Returns run log."""
        self.log = RunLog(pipeline="correction", config_dict=self.config.to_dict())
        self.log.start()
        try:
            if self.config.tiled:
                self._run_tiled()
            else:
                self._run_timepoints()
        finally:
            self.log.finish()
            self._save_config()
        return self.log

    def _save_config(self) -> None:
        """write correction results to isoview_config.json."""
        try:
            from .config import config_diff
            from .config import CONFIG_FILENAME, IsoviewConfig

            cfg_path = self.config.input_dir.parent / CONFIG_FILENAME
            ic = IsoviewConfig.load_or_create(cfg_path, root=self.config.input_dir.parent)

            # populate microscope section and paths on first run
            if not ic.microscope and self.metadata:
                ic.set_microscope(self.metadata, self.config)
            if not ic.paths:
                ic.set_paths(self.config)

            label = self.config.corrected_suffix.lstrip(".")
            ic.add_correction(label, config_diff(self.config), self.log)
            ic.save(cfg_path)
        except Exception as e:
            logger.warning(f"failed to save isoview_config: {e}")

    def _run_tiled(self) -> None:
        """Process tiled acquisition data (multiple specimens, single timepoint)."""
        specimens = self.config.specimens or []
        n_specimens = len(specimens)
        n_cameras = len(self.config.cameras)
        spm_labels = [f"SPM{s:02d}" for s in specimens]
        print(f"processing {n_specimens} specimens: {spm_labels}")
        print(f"cameras: {self.config.cameras}, views: {self.config.views}")
        print(f"segment_mode: {self.config.segment_mode}, output: {self.config.output_format}")

        if self.config.workers > 1:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            from multiprocessing import Manager
            config_dict = self.config.to_dict()
            print(f"parallel mode: {self.config.workers} workers")
            manager = Manager()
            progress_queue = manager.Queue()
            with ProcessPoolExecutor(max_workers=self.config.workers) as pool:
                futures = {
                    pool.submit(_correction_tile_worker, config_dict, spc, progress_queue): spc
                    for spc in specimens
                }
                done_count = 0
                seen = set()
                while done_count < len(futures):
                    newly_done = [f for f in futures if f.done() and id(f) not in seen]
                    for f in newly_done:
                        seen.add(id(f))
                        done_count += 1
                        spc = futures[f]
                        step = f.result()
                        self.log.steps.append(step)
                        elapsed = step.get("elapsed_seconds", 0)
                        status = step.get("status", "?")
                        print(f"  SPM{spc:02d} {status} ({elapsed}s) [{done_count}/{len(futures)}]")
                    if done_count < len(futures):
                        time.sleep(0.5)
        else:
            for spc in specimens:
                tp_start = time.time()
                spm_key = f"SPM{spc:02d}"
                spm_dir = self.config.output_dir / spm_key
                if self.config.log:
                    setup_logging(spm_dir, log_filename="correction.log")

                # load per-specimen metadata
                metadata, _ = read_all_xml_metadata(self.config.input_dir, spc)
                if metadata:
                    self.config.update_from_metadata(metadata)

                # per-specimen crop overrides
                _crop_fields = (
                    "crop_front",
                    "crop_depth",
                    "crop_top",
                    "crop_height",
                    "crop_left",
                    "crop_width",
                )
                orig_crops = {}
                if self.config.tile_crops and spm_key in self.config.tile_crops:
                    tile_crop = self.config.tile_crops[spm_key]
                    for param in _crop_fields:
                        orig_crops[param] = getattr(self.config, param)
                        if param in tile_crop:
                            setattr(self.config, param, tile_crop[param])

                logger.info(f"{spm_key}")

                # init step log
                self._current_step = {"name": spm_key, "cameras": [], "status": "success"}

                # raw MIP before any correction
                self._save_raw_projections(spc)

                try:
                    self.process_single_timepoint(spc)
                except Exception as e:
                    self._current_step["status"] = "failed"
                    self._current_step["error"] = str(e)
                    raise
                finally:
                    self._current_step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                    self.log.steps.append(self._current_step)
                    self._current_step = None

                # restore per-specimen crop overrides
                for param, orig_val in orig_crops.items():
                    setattr(self.config, param, orig_val)

                logger.info(f"{spm_key} - {time.time() - tp_start:.1f}s")

    def _run_timepoints(self) -> None:
        """Process timepoint data."""
        n_timepoints = len(self.config.timepoints)
        n_cameras = len(self.config.cameras)
        log_dir = self.config.output_dir / f"SPM{self.config.specimen:02d}"

        print(
            f"processing {n_timepoints} timepoints: {self.config.timepoints[0]} to {self.config.timepoints[-1]}"
        )
        print(f"cameras: {self.config.cameras}, views: {self.config.views}")
        print(f"segment_mode: {self.config.segment_mode}, output: {self.config.output_format}")

        if self.config.workers > 1:
            from concurrent.futures import ProcessPoolExecutor, as_completed
            from multiprocessing import Manager
            config_dict = self.config.to_dict()
            print(f"parallel mode: {self.config.workers} workers")
            manager = Manager()
            progress_queue = manager.Queue()
            log_queue = None
            listener = None
            if self.config.log:
                log_queue = manager.Queue()
                log_dir.mkdir(parents=True, exist_ok=True)
                listener = start_log_listener(log_queue, log_dir / "correction.log")
            logger.info(f"processing {n_timepoints} timepoints: {self.config.timepoints[0]} to {self.config.timepoints[-1]}")
            with ProcessPoolExecutor(max_workers=self.config.workers) as pool:
                futures = {
                    pool.submit(_correction_tp_worker, config_dict, tp, progress_queue, log_queue): tp
                    for tp in self.config.timepoints
                }
                done_count = 0
                seen = set()
                while done_count < len(futures):
                    newly_done = [f for f in futures if f.done() and id(f) not in seen]
                    for f in newly_done:
                        seen.add(id(f))
                        done_count += 1
                        tp = futures[f]
                        step = f.result()
                        self.log.steps.append(step)
                        elapsed = step.get("elapsed_seconds", 0)
                        status = step.get("status", "?")
                        print(f"  TM{tp:06d} {status} ({elapsed}s) [{done_count}/{len(futures)}]")
                    if done_count < len(futures):
                        time.sleep(0.5)
            if listener is not None:
                listener.stop()
        else:
            if self.config.log:
                setup_logging(log_dir, log_filename="correction.log")
            logger.info(f"processing {n_timepoints} timepoints: {self.config.timepoints[0]} to {self.config.timepoints[-1]}")
            for timepoint in self.config.timepoints:
                tp_start = time.time()

                self._current_step = {"name": f"TM{timepoint:06d}", "cameras": [], "status": "success"}
                self._save_raw_projections(timepoint)
                try:
                    self.process_single_timepoint(timepoint)
                except Exception as e:
                    self._current_step["status"] = "failed"
                    self._current_step["error"] = str(e)
                    raise
                finally:
                    self._current_step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                    self.log.steps.append(self._current_step)
                    self._current_step = None

                logger.info(f"TM{timepoint:06d} - {time.time() - tp_start:.1f}s")


def _correction_tp_worker(config_dict: dict, timepoint: int, progress_queue=None, log_queue=None) -> dict:
    """top-level worker for parallel timepoint correction."""
    if log_queue is not None:
        setup_queue_logging(log_queue)
    config = ProcessingConfig.from_dict(config_dict)
    config.timepoints = [timepoint]
    processor = IsoviewProcessor(config)
    processor._progress_queue = progress_queue
    processor._current_step = {"name": f"TM{timepoint:06d}", "cameras": [], "status": "success"}
    tp_start = time.time()
    try:
        processor._save_raw_projections(timepoint)
        processor.process_single_timepoint(timepoint)
        status = "success"
    except Exception as e:
        status = "failed"
        processor._current_step["status"] = "failed"
        processor._current_step["error"] = str(e)
        raise
    finally:
        elapsed = round(time.time() - tp_start, 1)
    logger.info(f"TM{timepoint:06d} - {elapsed:.1f}s")
    step = processor._current_step
    step["status"] = status
    step["elapsed_seconds"] = elapsed
    return step


def _correction_tile_worker(config_dict: dict, specimen: int, progress_queue=None) -> dict:
    """top-level worker for parallel tile correction."""
    config = ProcessingConfig.from_dict(config_dict)
    spm_key = f"SPM{specimen:02d}"
    spm_dir = config.output_dir / spm_key
    if config.log:
        setup_logging(spm_dir, log_filename="correction.log")

    # per-specimen crop overrides
    _crop_fields = (
        "crop_front", "crop_depth", "crop_top",
        "crop_height", "crop_left", "crop_width",
    )
    if config.tile_crops and spm_key in config.tile_crops:
        tile_crop = config.tile_crops[spm_key]
        for param in _crop_fields:
            if param in tile_crop:
                setattr(config, param, tile_crop[param])

    processor = IsoviewProcessor(config)
    processor._progress_queue = progress_queue
    processor._current_step = {"name": spm_key, "cameras": [], "status": "success"}
    tp_start = time.time()
    try:
        processor._save_raw_projections(specimen)
        processor.process_single_timepoint(specimen)
        status = "success"
    except Exception as e:
        status = "failed"
        processor._current_step["status"] = "failed"
        processor._current_step["error"] = str(e)
        raise
    finally:
        elapsed = round(time.time() - tp_start, 1)
    logger.info(f"{spm_key} - {elapsed:.1f}s")
    step = processor._current_step
    step["status"] = status
    step["elapsed_seconds"] = elapsed
    return step


def correct_stack(config: ProcessingConfig) -> None:
    """correct all timepoints or tiles in config."""
    processor = IsoviewProcessor(config)
    processor.run()


