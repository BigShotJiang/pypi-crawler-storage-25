from typing import Optional

import numpy as np
from scipy.ndimage import map_coordinates


def transform_camera_slice(
    slice2d: np.ndarray,
    x_offset: float,
    y_offset: float,
    rotation_deg: float
) -> np.ndarray:
    """
    Transform 2D slice (XY plane) with x/y offset and rotation.

    Equivalent to MATLAB transformCamera - applies rotation around center
    then x/y translation. Used for camera-camera fusion.

    Parameters
    ----------
    slice2d : ndarray
        2D slice (X, Y) from XY plane (one Z slice)
    x_offset : float
        X offset in pixels
    y_offset : float
        Y offset in pixels
    rotation_deg : float
        Rotation angle in degrees around Z axis

    Returns
    -------
    ndarray
        Transformed slice (X, Y)
    """
    x_size, y_size = slice2d.shape

    # create coordinate grids
    xi, yi = np.meshgrid(np.arange(x_size), np.arange(y_size), indexing='ij')

    # center coordinates
    cx = (x_size - 1) / 2.0
    cy = (y_size - 1) / 2.0

    # center the grid
    xi_c = xi - cx
    yi_c = yi - cy

    # rotation matrix (matches MATLAB convention)
    # matlab uses: RR = [cos -sin; sin cos] with XYaux = [X Y] * RR
    # which gives: X_new = cos*x + sin*y, Y_new = -sin*x + cos*y
    theta = np.deg2rad(rotation_deg)
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)

    # rotate around center (matlab convention: X_new = cos*x + sin*y, Y_new = -sin*x + cos*y)
    xi_rot = cos_t * xi_c + sin_t * yi_c
    yi_rot = -sin_t * xi_c + cos_t * yi_c

    # recenter and apply translation
    xi_new = xi_rot + cx - x_offset
    yi_new = yi_rot + cy - y_offset

    # interpolate
    coords = np.array([xi_new.ravel(), yi_new.ravel()])
    transformed = map_coordinates(
        slice2d.astype(np.float64), coords, order=3, mode='constant', cval=0
    ).reshape(slice2d.shape)

    # mask out-of-bounds
    valid = (xi_new >= 0) & (xi_new < x_size) & (yi_new >= 0) & (yi_new < y_size)
    transformed = transformed * valid

    # clip to valid range before dtype conversion — cubic interpolation can
    # produce negative values (ringing) which wrap to 65535 in uint16
    if np.issubdtype(slice2d.dtype, np.integer):
        info = np.iinfo(slice2d.dtype)
        np.clip(transformed, info.min, info.max, out=transformed)

    return transformed.astype(slice2d.dtype)


def _correlation_cost_camera(
    params: np.ndarray,
    slice1: np.ndarray,
    slice2: np.ndarray
) -> float:
    """
    Cost function for camera alignment optimization.

    Equivalent to MATLAB transformCamera objective function.
    Returns negative correlation (for minimization).

    Parameters
    ----------
    params : ndarray
        [x_offset, y_offset, rotation_deg]
    slice1 : ndarray
        Reference slice (X, Y)
    slice2 : ndarray
        Moving slice (X, Y)

    Returns
    -------
    float
        Negative normalized correlation coefficient
    """
    x_offset, y_offset, rotation_deg = params

    transformed = transform_camera_slice(slice2, x_offset, y_offset, rotation_deg)

    # compute correlation on valid region
    valid = (transformed > 0) & (slice1 > 0)
    if valid.sum() < 100:
        return 1.0

    s1 = slice1[valid].astype(np.float64)
    s2 = transformed[valid].astype(np.float64)

    s1_norm = s1 - s1.mean()
    s2_norm = s2 - s2.mean()

    std1 = s1_norm.std()
    std2 = s2_norm.std()

    if std1 < 1e-8 or std2 < 1e-8:
        return 1.0

    corr = np.mean(s1_norm * s2_norm) / (std1 * std2)
    return -corr


def gradient_descent_optimize(
    cost_fn,
    x0: np.ndarray,
    step_size: np.ndarray,
    tol_x: float = 1e-3,
    tol_fun: float = 1e-6,
    max_evals: int = 400,
    beta: float = 0.5
) -> tuple[np.ndarray, float, int]:
    """
    Gradient descent optimizer with adaptive step size.

    Equivalent to MATLAB fminuncFA by Fernando Amat.
    Uses numerical gradient and line search with backtracking.

    Parameters
    ----------
    cost_fn : callable
        Cost function f(x) -> float to minimize
    x0 : ndarray
        Initial parameter vector
    step_size : ndarray
        Step size for each parameter (for gradient estimation)
    tol_x : float
        Convergence tolerance for parameter change
    tol_fun : float
        Convergence tolerance for function value change
    max_evals : int
        Maximum number of function evaluations
    beta : float
        Line search backtracking factor

    Returns
    -------
    x_sol : ndarray
        Optimal parameters
    f_val : float
        Optimal function value
    exit_flag : int
        1=converged (function), 2=converged (x), 3=max evals
    """
    n = len(x0)
    x = x0.copy().astype(np.float64)
    step_size = np.asarray(step_size, dtype=np.float64)

    alpha = 1.0  # adaptive multiplier for line search
    num_eval = 0

    f0 = cost_fn(x)
    num_eval += 1

    # track best found
    f_best = f0
    x_best = x.copy()

    while num_eval < max_evals:
        # compute gradient numerically
        g = np.zeros(n)
        for k in range(n):
            h = np.zeros(n)
            h[k] = step_size[k]

            fp = cost_fn(x + h)
            num_eval += 1
            if fp < f_best:
                f_best = fp
                x_best = x + h

            fm = cost_fn(x - h)
            num_eval += 1
            if fm < f_best:
                f_best = fm
                x_best = x - h

            g[k] = (fp - fm) / (2.0 * step_size[k])

        # line search
        g_norm = np.linalg.norm(g)
        if g_norm < 1e-10:
            break

        mu = alpha * 5.0 * np.min(np.abs(step_size / (g + 1e-10)))
        f1 = cost_fn(x - mu * g)
        num_eval += 1

        aux_alpha = 1.0
        while f1 > f0 and np.linalg.norm(mu * g) > tol_x:
            mu *= beta
            f1 = cost_fn(x - mu * g)
            num_eval += 1
            aux_alpha *= beta

        # update adaptive alpha
        alpha = 0.3 * alpha + 0.7 * alpha * aux_alpha

        # check convergence
        if np.linalg.norm(mu * g) < tol_x and f_best + tol_fun >= min(f1, f0):
            if f1 < f0:
                return x - mu * g, f1, 2
            else:
                return x, f0, 2

        if abs(f1 - f0) / (abs(f0) + 1e-10) < tol_fun and f_best + tol_fun >= min(f1, f0):
            if f1 < f0:
                return x - mu * g, f1, 1
            else:
                return x, f0, 1

        # update position
        if f1 <= f_best:
            x = x - mu * g
            f0 = f1
        else:
            x = x_best.copy()
            f0 = f_best

        f_best = f0
        x_best = x.copy()

    return x, f0, 3


def estimate_camera_transform(
    ref_volume: np.ndarray,
    moving_volume: np.ndarray,
    search_x: tuple[int, int, int] = (-50, 50, 10),
    search_y: tuple[int, int, int] = (-50, 50, 10),
    z_slice: Optional[int] = None,
) -> dict:
    """
    Estimate camera-camera alignment transform (x/y offset + rotation).

    Equivalent to MATLAB camera alignment in multiFuse.
    Uses coarse grid search then fine gradient descent with rotation.

    Parameters
    ----------
    ref_volume : ndarray
        Reference volume (Z, Y, X)
    moving_volume : ndarray
        Moving volume (Z, Y, X)
    search_x : tuple
        (start, stop, step) for coarse x search
    search_y : tuple
        (start, stop, step) for coarse y search
    z_slice : int or None
        Z slice to use. None uses MIP (max intensity projection).

    Returns
    -------
    dict
        Contains 'x_offset', 'y_offset', 'rotation', 'correlation', 'method'
    """
    z_size, y_size, x_size = ref_volume.shape

    # get representative XY slice
    if z_slice is None:
        # use max intensity projection
        slice1 = ref_volume.max(axis=0).astype(np.float64).T      # (X, Y)
        slice2 = moving_volume.max(axis=0).astype(np.float64).T   # (X, Y)
    else:
        slice1 = ref_volume[z_slice, :, :].T.astype(np.float64)   # (X, Y)
        slice2 = moving_volume[z_slice, :, :].T.astype(np.float64)

    # coarse grid search (no rotation)
    x_offsets = np.arange(search_x[0], search_x[1] + 1, search_x[2])
    y_offsets = np.arange(search_y[0], search_y[1] + 1, search_y[2])

    best_corr = -np.inf
    best_x = 0.0
    best_y = 0.0

    intensity_ref = slice1.sum()

    for x_off in x_offsets:
        # shift in x
        if x_off >= 0:
            shifted_x = np.zeros_like(slice2)
            shifted_x[x_off:, :] = slice2[:-x_off or None, :]
        else:
            shifted_x = np.zeros_like(slice2)
            shifted_x[:x_off, :] = slice2[-x_off:, :]

        for y_off in y_offsets:
            # shift in y
            if y_off >= 0:
                shifted = np.zeros_like(shifted_x)
                shifted[:, y_off:] = shifted_x[:, :-y_off or None]
            else:
                shifted = np.zeros_like(shifted_x)
                shifted[:, :y_off] = shifted_x[:, -y_off:]

            intensity_shifted = shifted.sum()
            if intensity_shifted < 1e-10:
                continue

            # normalized intensity product correlation (MATLAB style)
            product = slice1 * shifted
            corr = product.sum() / (intensity_ref * intensity_shifted + 1e-10)

            if corr > best_corr:
                best_corr = corr
                best_x = float(x_off)
                best_y = float(y_off)

    # fine optimization with rotation starting from coarse result
    x0 = np.array([best_x, best_y, 0.0])  # [x_offset, y_offset, rotation_deg]
    step_size = np.array([1.0, 1.0, 0.1])

    cost_fn = lambda p: _correlation_cost_camera(p, slice1, slice2)

    x_sol, f_val, _ = gradient_descent_optimize(cost_fn, x0, step_size)

    return {
        'x_offset': float(x_sol[0]),
        'y_offset': float(x_sol[1]),
        'z_offset': 0.0,
        'rotation': float(x_sol[2]),
        'correlation': float(-f_val),
        'coarse_x': best_x,
        'coarse_y': best_y,
        'method': 'camera_gradient_descent'
    }


def apply_camera_transform(
    volume: np.ndarray,
    transform: dict
) -> np.ndarray:
    """
    Apply camera transform (x/y offset + rotation) to full volume.

    Transforms each XY slice (for each Z) with the same x/y offset and rotation.

    Parameters
    ----------
    volume : ndarray
        Input volume (Z, Y, X)
    transform : dict
        Contains 'x_offset', 'y_offset', and 'rotation'

    Returns
    -------
    ndarray
        Transformed volume (Z, Y, X)
    """
    x_offset = transform.get('x_offset', 0.0)
    y_offset = transform.get('y_offset', 0.0)
    rotation = transform.get('rotation', 0.0)

    z_size, y_size, x_size = volume.shape
    result = np.zeros_like(volume)

    for z in range(z_size):
        # extract XY slice, transform, put back
        slice_xy = volume[z, :, :].T  # (X, Y)
        transformed = transform_camera_slice(slice_xy, x_offset, y_offset, rotation)
        result[z, :, :] = transformed.T  # back to (Y, X)

    return result


def rotate_volume(volume: np.ndarray, rotation: int) -> np.ndarray:
    """
    Rotate 3d volume by 90 degrees.

    Parameters
    ----------
    volume : ndarray
        3D image stack (z, y, x)
    rotation : int
        0 (none), 1 (90 deg cw), -1 (90 deg ccw)

    Returns
    -------
    ndarray
        Rotated volume
    """
    if rotation == 0:
        return volume
    elif rotation == 1:
        return np.rot90(volume, k=-1, axes=(1, 2))
    elif rotation == -1:
        return np.rot90(volume, k=1, axes=(1, 2))
    else:
        raise ValueError(f"invalid rotation: {rotation}")


def flip_volume(volume: np.ndarray, horizontal: bool, vertical: bool) -> np.ndarray:
    """
    Flip volume horizontally and/or vertically.

    Parameters
    ----------
    volume : ndarray
        3D image stack (z, y, x)
    horizontal : bool
        Flip left-right
    vertical : bool
        Flip top-bottom

    Returns
    -------
    ndarray
        Flipped volume
    """
    result = volume
    if horizontal:
        result = result[:, :, ::-1]
    if vertical:
        result = result[:, ::-1, :]
    return result


def crop_volume(
    volume: np.ndarray,
    top: int = 0,
    left: int = 0,
    height: Optional[int] = None,
    width: Optional[int] = None,
    front: int = 0,
    depth: Optional[int] = None,
) -> np.ndarray:
    """
    Crop 3d volume to specified roi.

    Parameters
    ----------
    volume : ndarray
        3D image stack (z, y, x)
    top : int, default=0
        Crop start y
    left : int, default=0
        Crop start x
    height : int or None, default=None
        Crop height, None uses full
    width : int or None, default=None
        Crop width, None uses full
    front : int, default=0
        Crop start z
    depth : int or None, default=None
        Crop depth, None uses full

    Returns
    -------
    ndarray
        Cropped volume
    """
    z, y, x = volume.shape

    if height is None:
        height = y - top
    if width is None:
        width = x - left
    if depth is None:
        depth = z - front

    return volume[
        front : front + depth,
        top : top + height,
        left : left + width,
    ]


def apply_mask(volume: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Apply binary mask to volume.

    Parameters
    ----------
    volume : ndarray
        3D image stack
    mask : ndarray
        Binary mask (0 or 1)

    Returns
    -------
    ndarray
        Masked volume
    """
    return volume * mask


