"""Configuration for isoview processing pipeline."""

import logging
from typing import Optional
import json
from dataclasses import dataclass, field, fields, MISSING
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)

# default camera sensor pixel size in micrometers
CAMERA_PIXEL_SIZE = 6.5

# default camera pairs: opposing cameras to flip and fuse
# CM0+CM1 -> channel 0 (VW00, Z-scan), CM2+CM3 -> channel 1 (VW90, Y-scan)
DEFAULT_CAMERA_PAIRS = [(0, 1), (2, 3)]

# Which cameras belong in which view. 
DEFAULT_CAMERA_VIEW_MAP = {0: 0, 1: 0, 2: 90, 3: 90}


@dataclass
class ProcessingConfig:
    """Configuration for IsoView image processing pipeline."""

    # paths
    input_dir: Path
    output_dir: Path | None = None
    projection_dir: Path | None = None

    # specimen and timepoint selection
    specimen: int = 0
    specimens: list[int] | None = None  # None = auto-detect from SPC## in filenames
    timepoints: list[int] | None = None  # None = auto-detect all
    cameras: list[int] | None = None  # None = derive from camera_pairs
    views: list[int] = field(default_factory=lambda: [0, 90])

    corrected_suffix: str = ".corrected"  # folder suffix, e.g. ".corrected.python"

    # per-view cropping, keyed by view index (0=VW00, 90=VW90)
    # e.g. crop_depth={90: 476} drops last 20 z-slices from VW90 only
    crop_left: dict[int, int] | None = None
    crop_top: dict[int, int] | None = None
    crop_width: dict[int, int] | None = None
    crop_height: dict[int, int] | None = None
    crop_front: dict[int, int] | None = None
    crop_depth: dict[int, int] | None = None

    # per-specimen crop overrides (tiled mode only)
    # structure: {specimen_key: {crop_param: {view: value}}}
    # e.g. tile_crops={"SPM03": {"crop_depth": {0: 460, 90: 470}}}
    tile_crops: dict[str, dict[str, dict[int, int]]] | None = None

    # (WIP - UNUSED)
    # per-specimen VW90->VW00 orientation (tiled mode only)
    # each specimen maps to {"flip_axis": int|None, "rotation": int}
    # operations: transpose(1,0,2) to swap Z/Y, then rotate, then flip
    # rotation: 0=none, 1=90CW, 2=180, -1=90CCW (in YX plane, axes 1,2)
    # flip_axis: None=no flip, 0=Z, 1=Y, 2=X
    # e.g. {"SPM01": {"flip_axis": 1}, "SPM02": {"flip_axis": 0}}
    view_orientation: Optional[dict[str, dict]] = None

    # file formats
    output_format: str = "zarr"  # klb, tiff, or zarr
    compression: str | None = (
        "zstd"  # zstd, lzw, deflate (tiff); blosc-zstd, blosc-lz4, gzip (zarr); None = no compression
    )
    compression_level: int = 5  # 1-9, higher = smaller files, slower writes
    zarr_chunks: tuple[int, int, int] | None = None  # (z, y, x) chunk size for zarr, None = auto
    zarr_shards: tuple[int, int, int] | None = (
        None  # (z, y, x) shard size for zarr, None = auto (10 frames/shard for z>=20)
    )
    zarr_consolidate: bool = (
        True  # consolidate projections and masks into single OME-Zarr file (only for zarr output)
    )

    # parallelism
    workers: int = 1  # parallel workers for timepoint/tile processing (1 = sequential)
    log: bool = True  # write .log files next to output data

    # pyramids
    pyramid: bool = True  # generate resolution pyramids (only for OME-TIFF)
    pyramid_max_layers: int = 4  # maximum number of additional pyramid levels

    # pixel correction
    median_kernel: tuple[int, int] | None = (3, 3)

    # background estimation
    background_percentile: float = 5.0
    mask_percentile: float = 1.0
    subsample_factor: int = 100

    # segmentation
    # segment_mode: 0=no segmentation, 1=generate+save masks (applied during fusion)
    segment_mode: int = 1
    gauss_kernel: int = 5
    gauss_sigma: float = 2.0
    segment_threshold: float = 0.4
    splitting: int = 10  # for memory-efficient gaussian filtering

    # transformations
    rotation: int = 0  # 0: none, 1: 90° cw, -1: 90° ccw
    flip_horizontal: bool = True
    flip_vertical: bool = False
    cameras_rotated: bool = False  # rotated camera orientation (skips final reslice for VW90)

    # microscope parameters (defaults, overridden by XML metadata when available)
    pixel_spacing_z: float | None = None  # z_step from XML, or set manually
    detection_objective_mag: float | None = None  # from XML, or set manually (None = use XML)
    pixel_spacing_camera: float = CAMERA_PIXEL_SIZE  # camera sensor pixel size in um

    # channel dependencies (for multi-channel segmentation)
    reference_channels: list[list[int]] | None = None
    dependent_channels: list[list[int]] | None = None

    # camera-view mapping (hardcoded: CM0,1->VW00, CM2,3->VW90)
    camera_view_map: dict[int, int] | None = None

    # camera pairs (opposing views to flip and fuse)
    camera_pairs: list[tuple[int, int]] | None = None  # [(0, 1), (2, 3)]
    blending_method: str = "geometric"  # auto, adaptive, geometric, average
    blending_range: int = 20  # transition zone width in Z-planes
    transition_plane: int | None = None  # Z-index for geometric blending, None = center
    flip_z: bool = False  # flip second camera along Z before fusion (opposing cameras)
    front_flag: int = 1  # which camera has quality in front (1=ref, 2=transformed)
    search_offsets_x: tuple[int, int, int] = (-50, 50, 10)  # (start, stop, step)
    search_offsets_y: tuple[int, int, int] = (-50, 50, 10)
    # optimizer: gradient_descent only (MATLAB fminuncFA equivalent)

    # skip existing
    overwrite: bool = False  # overwrite existing output files, False = skip

    # diagnostic output
    save_diagnostics: bool = True  # save diagnostic PNG images during processing
    do_tenengrad: bool = False
    diagnostics_dir: Path | None = (
        None  # directory for diagnostic images, None = output_dir/diagnostics
    )

    def __post_init__(self):
        """Initialize derived attributes."""
        import re

        # track whether user explicitly set camera_view_map / objective mag
        self._user_camera_view_map = self.camera_view_map
        self._user_detection_objective_mag = self.detection_objective_mag
        self.input_dir = Path(self.input_dir)
        self.output_format = self.output_format.lstrip(".")

        # auto-detect specimens and timepoints from flat SPC##_TM#####_*.stack files
        if self.specimens is None or self.timepoints is None:
            spc_set = set()
            tp_set = set()
            stack_re = re.compile(r"SPC(\d+)_TM(\d+)_.*\.stack")
            for e in self.input_dir.iterdir():
                if not e.is_file():
                    continue
                m = stack_re.match(e.name)
                if m:
                    spc_set.add(int(m.group(1)))
                    tp_set.add(int(m.group(2)))
            if not spc_set:
                raise ValueError(f"no SPC##_TM##_*.stack files found in {self.input_dir}")
            if self.specimens is None:
                self.specimens = sorted(spc_set)
            if self.timepoints is None:
                self.timepoints = sorted(tp_set)

        if self.output_dir is None:
            self.output_dir = self.input_dir.parent / f"{self.input_dir.name}{self.corrected_suffix}"
        else:
            self.output_dir = Path(self.output_dir)

        if self.projection_dir is None:
            self.projection_dir = self.output_dir.parent / f"{self.output_dir.name}.projections"
        else:
            self.projection_dir = Path(self.projection_dir)

        # pixel spacing calculations (deferred until update_from_metadata if pixel_spacing_z is None)
        self._compute_pixel_spacing()

    def _compute_pixel_spacing(self) -> None:
        """Compute pixel spacing array from microscope parameters."""
        # use default 16x if objective mag not yet set (will be updated from XML)
        obj_mag = self.detection_objective_mag if self.detection_objective_mag is not None else 16.0
        pixel_xy = self.pixel_spacing_camera / obj_mag
        # use default z spacing if not set (will be updated from XML metadata)
        z_spacing = self.pixel_spacing_z if self.pixel_spacing_z is not None else pixel_xy
        # Order: [z, y, x, t, c] for OME-Zarr compliance
        self.pixel_spacing = np.array([z_spacing, pixel_xy, pixel_xy, 1.0, 1.0])
        self.scaling = z_spacing / pixel_xy

        # sync segment flag with segment_mode
        self.segment = self.segment_mode == 1

        if self.camera_view_map is None:
            self.camera_view_map = dict(DEFAULT_CAMERA_VIEW_MAP)

        if self.camera_pairs is None:
            self.camera_pairs = list(DEFAULT_CAMERA_PAIRS)

        # derive cameras from camera_pairs if not explicitly set
        if self.cameras is None:
            self.cameras = sorted({c for pair in self.camera_pairs for c in pair})

        # validate camera pairs if flipping is enabled
        if self.flip_horizontal or self.flip_vertical:
            self._validate_camera_pairs()

    def update_from_metadata(self, metadata: dict) -> None:
        """Update config with values from XML metadata."""
        if "axial_step" in metadata:
            self.pixel_spacing_z = float(metadata["axial_step"])
            self._compute_pixel_spacing()
        elif "z_step" in metadata:
            self.pixel_spacing_z = float(metadata["z_step"])
            self._compute_pixel_spacing()

        if "objective_mag" in metadata and self._user_detection_objective_mag is None:
            self.detection_objective_mag = float(metadata["objective_mag"])
            self._compute_pixel_spacing()

        # camera_view_map from XML stack_direction, only if not explicitly set
        if "camera_view_map" in metadata and self._user_camera_view_map is None:
            self.camera_view_map = metadata["camera_view_map"]

    def _validate_camera_pairs(self) -> None:
        """Validate that all cameras belong to a pair when flipping is enabled."""
        paired_cameras = set()
        for cam0, cam1 in self.camera_pairs:
            paired_cameras.add(cam0)
            paired_cameras.add(cam1)

        for camera in self.cameras:
            if camera not in paired_cameras:
                raise ValueError(
                    f"camera {camera} is not in any pair but flipping is enabled. "
                    f"camera_pairs={self.camera_pairs}, cameras={self.cameras}"
                )

    @property
    def tiled(self) -> bool:
        """True when dataset is tiled (multiple specimens, single timepoint)."""
        return len(self.specimens) > 1 and len(self.timepoints) <= 1

    def get_crop(self, view: int) -> dict:
        """Get crop params for a view."""
        return {
            "front": (self.crop_front or {}).get(view, 0),
            "depth": (self.crop_depth or {}).get(view),
            "top": (self.crop_top or {}).get(view, 0),
            "height": (self.crop_height or {}).get(view),
            "left": (self.crop_left or {}).get(view, 0),
            "width": (self.crop_width or {}).get(view),
        }

    @property
    def extension(self) -> str:
        """File extension for 3D volumes (OME-TIFF for tif/tiff)."""
        if self.output_format in ("tif", "tiff"):
            return ".ome.tif"
        return f".{self.output_format}"

    @property
    def flat_extension(self) -> str:
        """File extension for 2D images (plain tif, no OME).
        zarr/klb fall back to .tif since they don't suit 2D outputs."""
        if self.output_format in ("zarr", "klb"):
            return ".tif"
        if self.output_format in ("tif", "tiff"):
            return ".tif"
        return f".{self.output_format}"

    # serialization

    _PATH_FIELDS = {
        "input_dir",
        "output_dir",
        "projection_dir",
        "diagnostics_dir",
    }
    _TUPLE_FIELDS = {
        "median_kernel",
        "search_offsets_x",
        "search_offsets_y",
        "zarr_chunks",
        "zarr_shards",
    }
    _INT_KEY_DICT_FIELDS = {
        "crop_left",
        "crop_top",
        "crop_width",
        "crop_height",
        "crop_front",
        "crop_depth",
        "camera_view_map",
    }

    def to_dict(self) -> dict:
        """Serialize config to a JSON-safe dict."""
        d = {}
        for f in fields(self):
            val = getattr(self, f.name)
            if isinstance(val, Path):
                val = str(val)
            elif isinstance(val, np.ndarray):
                val = val.tolist()
            elif isinstance(val, tuple):
                val = list(val)
            elif isinstance(val, list):
                val = [list(v) if isinstance(v, tuple) else v for v in val]
            elif isinstance(val, dict):
                val = _dict_to_json(val)
            d[f.name] = val
        return d

    def to_json(self, path: "str | Path") -> None:
        """Save config to JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def from_dict(cls, d: dict) -> "ProcessingConfig":
        """Reconstruct config from a dict (e.g. parsed JSON)."""
        d = dict(d)
        # drop removed fields from old configs
        d.pop("tiled", None)
        d.pop("tile_names", None)
        valid = {f.name for f in fields(cls)}
        d = {k: v for k, v in d.items() if k in valid}

        for name in cls._PATH_FIELDS:
            if name in d and d[name] is not None:
                d[name] = Path(d[name])

        for name in cls._TUPLE_FIELDS:
            if name in d and d[name] is not None:
                d[name] = tuple(d[name])

        if "camera_pairs" in d and d["camera_pairs"] is not None:
            d["camera_pairs"] = [tuple(p) for p in d["camera_pairs"]]

        for name in cls._INT_KEY_DICT_FIELDS:
            if name in d and d[name] is not None:
                d[name] = {int(k): v for k, v in d[name].items()}

        if "tile_crops" in d and d["tile_crops"] is not None:
            d["tile_crops"] = _restore_tile_crops(d["tile_crops"])

        return cls(**d)

    @classmethod
    def from_json(cls, path: "str | Path") -> "ProcessingConfig":
        """Load config from JSON file."""
        with open(path) as f:
            return cls.from_dict(json.load(f))


def _dict_to_json(d: dict) -> dict:
    """Recursively convert dict keys/values for JSON serialization."""
    out = {}
    for k, v in d.items():
        key = str(k) if not isinstance(k, str) else k
        if isinstance(v, dict):
            v = _dict_to_json(v)
        elif isinstance(v, Path):
            v = str(v)
        elif isinstance(v, tuple):
            v = list(v)
        elif isinstance(v, np.ndarray):
            v = v.tolist()
        out[key] = v
    return out


def _restore_tile_crops(d: dict) -> dict:
    """Restore tile_crops nested dict with int keys at leaf level."""
    out = {}
    for tile_name, crop_dict in d.items():
        out[tile_name] = {}
        for crop_param, view_dict in crop_dict.items():
            out[tile_name][crop_param] = {int(k): v for k, v in view_dict.items()}
    return out


# fields excluded from config_diff:
# - paths: stored separately in isoview_config.json
# - derived: populated by __post_init__ from other fields, not user-set
_DIFF_EXCLUDE = {
    "input_dir", "output_dir", "projection_dir",
    "diagnostics_dir",
    # derived in __post_init__ from camera_pairs / input_dir scanning
    "cameras", "timepoints", "specimens",
}

# fields where None means "use default" (populated by __post_init__)
# only include in diff if user explicitly set a non-default value
_NONE_MEANS_DEFAULT = {
    "camera_view_map", "camera_pairs",
}

# sentinel for fields with no default
_MISSING = object()


def _get_field_default(f):
    """get the default value for a dataclass field, or _MISSING."""
    if f.default is not MISSING:
        return f.default
    if f.default_factory is not MISSING:
        return f.default_factory()
    return _MISSING


def config_diff(config: "ProcessingConfig") -> dict:
    """return only fields that differ from ProcessingConfig defaults.

    paths (input_dir, output_dir, etc.) are excluded since they're
    stored separately in isoview_config.json. fields with no default (required)
    are also excluded. fields derived by __post_init__ from other fields
    are skipped unless the user explicitly set a non-standard value.
    """
    _STANDARD_DERIVED = {
        "camera_view_map": DEFAULT_CAMERA_VIEW_MAP,
        "camera_pairs": DEFAULT_CAMERA_PAIRS,
    }

    result = {}
    for f in fields(config):
        if f.name in _DIFF_EXCLUDE:
            continue
        default = _get_field_default(f)
        if default is _MISSING:
            continue
        val = getattr(config, f.name)

        # for fields where None means "use standard", skip if value matches standard
        if f.name in _NONE_MEANS_DEFAULT:
            standard = _STANDARD_DERIVED.get(f.name)
            if val == standard:
                continue

        # normalize for comparison
        cmp_val = str(val) if isinstance(val, Path) else val
        cmp_def = str(default) if isinstance(default, Path) else default
        if cmp_val != cmp_def:
            # json-safe value
            if isinstance(val, Path):
                val = str(val)
            elif isinstance(val, np.ndarray):
                val = val.tolist()
            elif isinstance(val, tuple):
                val = list(val)
            elif isinstance(val, dict):
                val = _dict_to_json(val)
            elif isinstance(val, list):
                val = [list(v) if isinstance(v, tuple) else v for v in val]
            result[f.name] = val
    return result


# isoview_config.json — single file tracking microscope params + all runs

CONFIG_FILENAME = "isoview_config.json"


def _run_summary(log) -> dict:
    """extract compact run summary from a RunLog."""
    return {
        "started_at": log.started_at,
        "completed_at": log.completed_at,
        "elapsed_seconds": log.elapsed_seconds,
        "status": "success" if log.summary.get("failed", 0) == 0 else "failed",
        "summary": log.summary,
    }


def _extract_microscope(metadata: dict, config) -> dict:
    """extract shared microscope params from XML metadata + config."""
    mic = {}
    if config.pixel_spacing_camera:
        mic["pixel_spacing_camera"] = config.pixel_spacing_camera
    if config.detection_objective_mag is not None:
        mic["detection_objective_mag"] = config.detection_objective_mag
    if config.pixel_spacing_z is not None:
        mic["pixel_spacing_z"] = config.pixel_spacing_z
    if config.detection_objective_mag:
        mic["pixel_spacing_xy"] = config.pixel_spacing_camera / config.detection_objective_mag
    if config.camera_view_map:
        mic["camera_view_map"] = {str(k): v for k, v in config.camera_view_map.items()}
    if config.camera_pairs:
        mic["camera_pairs"] = [list(p) for p in config.camera_pairs]
    for key in ("wavelength", "exposure_time", "fps", "specimen_name"):
        if key in metadata:
            mic[key] = metadata[key]
    return mic


def _extract_diff_from_full(config_dict: dict) -> dict:
    """extract diff-from-defaults from a full config dict."""
    try:
        cfg = ProcessingConfig.from_dict(config_dict)
        return config_diff(cfg)
    except Exception:
        d = dict(config_dict)
        for key in ("input_dir", "output_dir", "projection_dir",
                     "diagnostics_dir"):
            d.pop(key, None)
        return d


@dataclass
class IsoviewConfig:
    """single config file at dataset root."""

    root: Path
    version: int = 2
    paths: dict = field(default_factory=dict)
    microscope: dict = field(default_factory=dict)
    corrections: dict = field(default_factory=dict)
    fusions: dict = field(default_factory=dict)

    def set_paths(self, config) -> None:
        """store relative paths from config (relative to root)."""
        if config.input_dir:
            try:
                self.paths["raw"] = Path(config.input_dir).relative_to(self.root).as_posix()
            except ValueError:
                self.paths["raw"] = Path(config.input_dir).name
        if config.output_dir:
            try:
                self.paths["corrected"] = Path(config.output_dir).relative_to(self.root).as_posix()
            except ValueError:
                self.paths["corrected"] = Path(config.output_dir).name

    def add_correction(self, label: str, config_diff: dict, log=None, steps=None) -> dict:
        """register a correction run."""
        entry = {"config_diff": config_diff}
        if log is not None:
            entry["run"] = _run_summary(log)
        if steps is not None:
            entry["steps"] = steps
        elif log is not None:
            entry["steps"] = log.steps
        self.corrections[label] = entry
        return entry

    def add_fusion(self, correction_label: str, blending: str,
                   config_diff: dict, log=None, steps=None) -> dict:
        """register a fusion run."""
        key = f"{correction_label}/{blending}"
        entry = {"config_diff": config_diff}
        if log is not None:
            entry["run"] = _run_summary(log)
        if steps is not None:
            entry["steps"] = steps
        elif log is not None:
            entry["steps"] = log.steps
        self.fusions[key] = entry
        return entry

    def set_microscope(self, metadata: dict, config) -> None:
        """populate microscope section from XML metadata + config."""
        self.microscope = _extract_microscope(metadata, config)

    def save(self, path: Path | None = None) -> None:
        """save to isoview_config.json."""
        path = path or (self.root / CONFIG_FILENAME)
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        d = {"version": self.version}
        if self.paths:
            d["paths"] = self.paths
        d["microscope"] = self.microscope
        d["corrections"] = self.corrections
        d["fusions"] = self.fusions
        with open(path, "w") as f:
            json.dump(d, f, indent=2)
        logger.info(f"isoview_config saved: {path}")

    @classmethod
    def load(cls, path: Path) -> "IsoviewConfig":
        """load from JSON. handles v1 (old manifest.json) and v2."""
        path = Path(path)
        with open(path) as f:
            d = json.load(f)
        version = d.get("version", 1)
        if version < 2:
            return cls._from_v1(d, path)
        return cls(
            root=path.parent,
            version=d.get("version", 2),
            paths=d.get("paths", {}),
            microscope=d.get("microscope", {}),
            corrections=d.get("corrections", {}),
            fusions=d.get("fusions", {}),
        )

    @classmethod
    def _from_v1(cls, d: dict, path: Path) -> "IsoviewConfig":
        """convert v1 manifest.json to v2 IsoviewConfig."""
        root = Path(d.get("root", str(path.parent)))
        ic = cls(root=root)
        datasets = d.get("datasets", {})
        for _ds_name, ds_data in datasets.items():
            for label, corr in ds_data.get("corrections", {}).items():
                if label not in ic.corrections:
                    ic.corrections[label] = {
                        "config_diff": corr.get("config", {}),
                    }
                    if "run" in corr:
                        ic.corrections[label]["run"] = corr["run"]
                for fuse_label, fuse_data in corr.get("fusions", {}).items():
                    key = f"{label}/{fuse_label}"
                    if key not in ic.fusions:
                        ic.fusions[key] = {
                            "config_diff": fuse_data.get("config", {}),
                        }
                        if "run" in fuse_data:
                            ic.fusions[key]["run"] = fuse_data["run"]
        return ic

    @classmethod
    def load_or_create(cls, path: Path, root: Path | None = None) -> "IsoviewConfig":
        """load existing config or create a new one."""
        path = Path(path)
        if path.exists():
            return cls.load(path)
        # try old manifest.json for migration
        old = path.parent / "manifest.json"
        if old.exists() and path.name != "manifest.json":
            logger.info(f"migrating {old} -> {path}")
            return cls.load(old)
        return cls(root=root or path.parent)

    @classmethod
    def from_directory(cls, root: Path) -> "IsoviewConfig":
        """bootstrap by scanning existing run.json / correction_run.json files."""
        from .pipeline import RunLog

        root = Path(root)
        ic = cls(root=root)

        cfg_path = root / CONFIG_FILENAME
        if cfg_path.exists():
            return cls.load(cfg_path)

        old_path = root / "manifest.json"
        if old_path.exists():
            return cls.load(old_path)

        for log_path in sorted(root.rglob("correction_run.json")):
            log = RunLog.load(log_path)
            config_d = log.config_dict
            suffix = config_d.get("corrected_suffix", ".corrected")
            label = suffix.lstrip(".")
            diff = _extract_diff_from_full(config_d)
            ic.add_correction(label, diff, log)

        for log_path in sorted(root.glob("*.corrected*/run.json")):
            log = RunLog.load(log_path)
            if log.pipeline != "correction":
                continue
            config_d = log.config_dict
            suffix = config_d.get("corrected_suffix", ".corrected")
            label = suffix.lstrip(".")
            if label not in ic.corrections:
                diff = _extract_diff_from_full(config_d)
                ic.add_correction(label, diff, log)

        for log_path in sorted(root.rglob("fusion_run.json")):
            log = RunLog.load(log_path)
            config_d = log.config_dict
            blending = config_d.get("blending_method", "geometric")
            suffix = config_d.get("corrected_suffix", ".corrected")
            correction_label = suffix.lstrip(".")
            key = f"{correction_label}/{blending}"
            if key not in ic.fusions:
                diff = _extract_diff_from_full(config_d)
                ic.add_fusion(correction_label, blending, diff, log)

        for log_path in sorted(root.rglob("Results/*/run.json")):
            log = RunLog.load(log_path)
            if log.pipeline != "fusion":
                continue
            config_d = log.config_dict
            blending = config_d.get("blending_method", "geometric")
            suffix = config_d.get("corrected_suffix", ".corrected")
            correction_label = suffix.lstrip(".")
            key = f"{correction_label}/{blending}"
            if key not in ic.fusions:
                diff = _extract_diff_from_full(config_d)
                ic.add_fusion(correction_label, blending, diff, log)

        return ic
