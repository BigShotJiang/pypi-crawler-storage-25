"""Multiview microscopy GUI built on mbo_utilities/fastplotlib/imgui_bundle."""

__all__ = [
    "run_multiview_gui",
    "MultiviewViewer",
]


def __getattr__(name):
    if name == "run_multiview_gui":
        from ._app import run_multiview_gui
        return run_multiview_gui
    if name == "MultiviewViewer":
        from .viewers import MultiviewViewer
        return MultiviewViewer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
