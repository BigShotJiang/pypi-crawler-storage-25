"""Adapt isoview XML metadata to mbo_utilities-compatible dict."""

from __future__ import annotations


def isoview_metadata_to_dict(
    common_meta: dict,
    per_camera_meta: dict | None = None,
    stage: str = "raw",
) -> dict:
    """Translate isoview XML metadata to mbo_utilities format.

    Maps isoview keys to canonical METADATA_PARAMS names so
    MetadataPanel and normalize_resolution work out of the box.

    Parameters
    ----------
    common_meta : dict
        From read_all_xml_metadata() first return value.
    per_camera_meta : dict | None
        From read_all_xml_metadata() second return value.
    stage : str
        Processing stage: "raw", "corrected", or "fused".

    Returns
    -------
    dict
        Metadata dict with canonical + isoview-specific keys.
    """
    meta = {}

    # pixel resolution
    px = common_meta.get("pixel_resolution_um")
    if px is not None:
        meta["dx"] = px
        meta["dy"] = px

    # axial spacing
    dz = common_meta.get("axial_step") or common_meta.get("z_step") or common_meta.get("y_step")
    if dz is not None:
        meta["dz"] = dz

    # frame rate
    if "fps" in common_meta:
        meta["fs"] = common_meta["fps"]

    # z-planes
    if "zplanes" in common_meta:
        meta["num_zplanes"] = common_meta["zplanes"]

    # dimensions (first camera)
    dims = common_meta.get("dimensions")
    if dims is not None:
        import numpy as np
        d = dims[0] if (hasattr(dims, "ndim") and dims.ndim > 1) else dims
        meta["Lx"] = int(d[0])
        meta["Ly"] = int(d[1])

    # normalize all resolution aliases
    try:
        from mbo_utilities.metadata.params import normalize_resolution
        normalize_resolution(meta, dx=meta.get("dx"), dy=meta.get("dy"), dz=meta.get("dz"))
    except ImportError:
        pass

    # pass through isoview-specific fields
    _passthrough = [
        "data_header", "specimen_name", "timestamp", "time_point",
        "stage_x", "stage_y", "stage_z", "specimen_XYZT",
        "camera_view_map", "camera_type", "camera_roi",
        "wavelength", "illumination_arms", "illumination_filter",
        "detection_filter", "detection_objective", "objective_mag",
        "exposure_time", "laser_power", "experiment_notes",
        "stack_direction", "camera_pixel_size_um", "vps",
    ]
    for key in _passthrough:
        if key in common_meta:
            meta[key] = common_meta[key]

    meta["stage"] = stage
    meta["num_cameras"] = len(per_camera_meta) if per_camera_meta else 0

    # per-camera section
    if per_camera_meta:
        cameras = {}
        for cam_idx, cam_meta in per_camera_meta.items():
            cameras[f"camera_{cam_idx}"] = cam_meta
        meta["cameras"] = cameras

    return meta
