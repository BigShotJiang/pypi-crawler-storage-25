"""Entry point for the multiview GUI."""

from __future__ import annotations

import logging
from pathlib import Path
logger = logging.getLogger(__name__)

__all__ = ["run_multiview_gui"]


def _find_corrected_root(input_dir: Path) -> Path | None:
    """Walk up to find the directory with .corrected in its name."""
    p = input_dir
    for _ in range(3):
        if ".corrected" in p.name:
            return p
        p = p.parent
    return None


def _find_raw_dir(input_dir: Path) -> Path:
    """Find the raw data directory corresponding to a corrected/fused path.

    Handles suffixes like .corrected, .corrected_cropped, etc.
    Also walks up from subdirectories (e.g. SPM00 inside a corrected dir).
    Falls back to input_dir itself if no raw dir is found.
    """
    corrected_root = _find_corrected_root(input_dir)
    if corrected_root is not None:
        name = corrected_root.name
        for suffix in [".corrected_cropped", ".corrected_zarr", ".corrected"]:
            if suffix in name:
                candidate = corrected_root.parent / name.split(suffix)[0]
                if candidate.exists():
                    return candidate
    return input_dir


def _find_corrected_dir(input_dir: Path) -> Path:
    """Resolve the corrected data directory.

    Handles: already a corrected dir, subdirectory of one, or sibling.
    """
    # already a corrected dir
    if ".corrected" in input_dir.name:
        return input_dir
    # subdirectory of a corrected dir (e.g. SPM00 inside dataset.corrected)
    root = _find_corrected_root(input_dir)
    if root is not None:
        return root
    # look for sibling
    for candidate in sorted(input_dir.parent.glob(f"{input_dir.name}.corrected*")):
        if candidate.is_dir():
            return candidate
    return input_dir


def _infer_structure_from_corrected(corrected_dir: Path) -> str:
    """Infer tiled vs timepoint from corrected filenames.

    tiled: SPM##_CM##_VW##.* (no TM label in filename)
    timepoint: SPM##_TM######_CM##_VW##.*
    """
    import re
    for entry in corrected_dir.rglob("*"):
        if entry.suffix.lower() not in (".tif", ".tiff", ".zarr", ".klb"):
            continue
        if "_TM" in entry.name:
            return "timepoint"
        if re.search(r"SPM\d+_CM\d+_VW\d+", entry.name):
            return "tiled"
    return "timepoint"


def _detect_timepoints_from_corrected(corrected_dir: Path) -> list[int]:
    """Extract specimen/timepoint indices from corrected filenames."""
    import re
    indices = set()
    for f in corrected_dir.rglob("*"):
        if f.suffix.lower() not in (".tif", ".tiff", ".zarr", ".klb"):
            continue
        if any(s in f.name.lower() for s in ["mask", "projection", "minintensity"]):
            continue
        # timepoint: SPM00_TM000000_CM00_VW00.ome.tif
        m = re.search(r"_TM(\d+)_", f.name)
        if m:
            indices.add(int(m.group(1)))
            continue
        # tiled: SPM00_CM00_VW00.ome.tif (extract SPM index)
        m = re.search(r"^SPM(\d+)_CM\d+_VW\d+", f.name)
        if m:
            indices.add(int(m.group(1)))
    return sorted(indices) if indices else []


def _build_camera_name(
    cam_idx: int,
    camera_view_map: dict,
    common_meta: dict,
    per_camera_meta: dict,
) -> str:
    """Build a descriptive name like 'CM2 (VW90, 488nm)'."""
    parts = [f"CM{cam_idx}"]
    view = camera_view_map.get(cam_idx)
    if view is not None:
        parts.append(f"VW{view:02d}")
    # wavelength from per-camera meta or common
    cam_key = f"camera_{cam_idx}"
    wl = None
    if cam_key in per_camera_meta:
        wl = per_camera_meta[cam_key].get("wavelength")
    if wl is None:
        wl = common_meta.get("wavelength")
    if wl:
        parts.append(f"{wl}nm")
    return f"{parts[0]} ({', '.join(parts[1:])})" if len(parts) > 1 else parts[0]


def _load_volumes(
    input_dir: Path,
    specimen: int,
    timepoint: int,
    cameras: list[int],
    camera_view_map: dict,
    stage: str,
    structure: str,
    common_meta: dict,
    per_camera_meta: dict,
    contents: dict | None = None,
) -> tuple[list, list[str]]:
    """Load volumes for all cameras at a given timepoint/tile.

    Returns (volumes, camera_names) lists, same length as cameras.
    Volumes are LazyVolume instances (loaded on demand).
    """
    volumes = []
    names = []

    if stage == "raw":
        volumes, names = _load_raw(
            input_dir, specimen, timepoint, cameras,
            camera_view_map, structure, common_meta, per_camera_meta,
            contents=contents,
        )
    elif stage == "corrected":
        volumes, names = _load_corrected(
            input_dir, specimen, timepoint, cameras,
            camera_view_map, common_meta, per_camera_meta,
        )
    elif stage == "fused":
        volumes, names = _load_fused(
            input_dir, specimen, timepoint,
            common_meta, per_camera_meta,
        )

    return volumes, names


def _load_raw(
    input_dir: Path,
    specimen: int,
    timepoint: int,
    cameras: list[int],
    camera_view_map: dict,
    structure: str,
    common_meta: dict,
    per_camera_meta: dict,
    contents: dict | None = None,
) -> tuple[list, list[str]]:
    """Load raw .stack files lazily."""
    from isoview.io import LazyVolume

    volumes = []
    names = []

    for cam_idx in cameras:
        view = camera_view_map.get(cam_idx, 0)

        # look up path from scan result (match camera, any CHN)
        path = None
        if contents:
            if structure == "tiled":
                tile = contents["tiles"].get(f"SPM{timepoint:02d}")
                stacks = tile.get("raw_stacks", {}) if tile else {}
            else:
                tp = contents["timepoints"].get(timepoint)
                stacks = tp.get("raw_stacks", {}) if tp else {}
            for (cam, _chn), p in stacks.items():
                if cam == cam_idx:
                    path = p
                    break

        if path is None:
            logger.warning(f"no stack file for camera {cam_idx}, timepoint {timepoint}")
            continue

        # get dimensions from metadata
        dims_tuple = None
        dims_arr = common_meta.get("dimensions")
        if dims_arr is not None:
            d = dims_arr
            if hasattr(d, "ndim") and d.ndim > 1:
                row = min(cam_idx, len(d) - 1)
                d = d[row]
            dims_tuple = (int(d[0]), int(d[1]), int(d[2]))

        vol = LazyVolume(path, dimensions=dims_tuple)
        volumes.append(vol)
        names.append(_build_camera_name(cam_idx, camera_view_map, common_meta, per_camera_meta))

    return volumes, names


def _load_corrected(
    input_dir: Path,
    specimen: int,
    timepoint: int,
    cameras: list[int],
    camera_view_map: dict,
    common_meta: dict,
    per_camera_meta: dict,
) -> tuple[list, list[str]]:
    """Load corrected volumes lazily."""
    from isoview.io import LazyVolume

    volumes = []
    names = []

    corrected_dir = _find_corrected_dir(input_dir)

    for cam_idx in cameras:
        path = _find_corrected_file(corrected_dir, specimen, timepoint, cam_idx)

        if path is None:
            logger.warning(f"no corrected volume for CM{cam_idx}")
            continue

        vol = LazyVolume(path)
        volumes.append(vol)
        names.append(_build_camera_name(cam_idx, camera_view_map, common_meta, per_camera_meta))

    return volumes, names


def _find_corrected_file(
    corrected_dir: Path,
    specimen: int,
    timepoint: int,
    camera: int,
) -> Path | None:
    """Search for a corrected volume file across naming conventions."""
    spm = f"SPM{specimen:02d}"
    cm = f"CM{camera}"

    # search directories: SPM/TM nested, SPM subfolder, TM subfolder, root
    search_dirs = [
        corrected_dir / spm / f"TM{timepoint:06d}",
        corrected_dir / spm / f"TM{timepoint:05d}",
        corrected_dir / spm,
        corrected_dir / f"TM{timepoint:06d}",
        corrected_dir / f"TM{timepoint:05d}",
        corrected_dir,
    ]

    # file patterns: new (CM#), legacy (CM##_VW##)
    file_patterns = [
        f"{spm}_{cm}.*",                    # tiled: SPM00_CM0.ome.tif
        f"{spm}_TM*_{cm}.*",                # timepoint: SPM00_TM000000_CM0.ome.tif
        f"{spm}_{cm}_VW*.*",                # legacy tiled: SPM00_CM00_VW00.ome.tif
        f"{spm}_TM*_{cm}_VW*.*",            # legacy timepoint
        f"*_{cm}.*",                         # generic fallback
    ]

    # valid extensions
    valid_ext = {".tiff", ".tif", ".zarr", ".klb"}

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue
        for pattern in file_patterns:
            for match in sorted(search_dir.glob(pattern)):
                # skip masks, projections, npz, xml
                suffixes = match.suffixes  # e.g. ['.ome', '.tif'] or ['.tiff']
                ext = match.suffix.lower()
                if ext == ".tif" and ".ome" in match.name.lower():
                    ext = ".tif"  # .ome.tif is valid
                if ext not in valid_ext:
                    continue
                # skip mask/projection files
                stem_lower = match.stem.lower()
                if any(s in stem_lower for s in ["mask", "projection", "minintensity"]):
                    continue
                return match

    return None


def _load_fused(
    input_dir: Path,
    specimen: int,
    timepoint: int,
    common_meta: dict,
    per_camera_meta: dict,
) -> tuple[list, list[str]]:
    """Load fused volumes lazily."""
    from isoview.io import LazyVolume

    volumes = []
    names = []

    corrected_dir = _find_corrected_dir(input_dir)

    # search multiple fused dir names
    fused_dir = None
    for candidate in ["Results", "fused"]:
        d = corrected_dir / candidate
        if d.exists():
            fused_dir = d
            break

    if fused_dir is None:
        logger.warning(f"no fused/Results directory in {corrected_dir}")
        return volumes, names

    # walk Results/ tree: MultiFused_*/SPM##/ or MultiFused_*/SPM##/TM######/
    valid_ext = {".tiff", ".tif", ".zarr", ".klb"}
    spm = f"SPM{specimen:02d}"

    # collect candidate dirs (deepest first for specificity)
    search_dirs = []
    for method_dir in sorted(fused_dir.iterdir()):
        if not method_dir.is_dir():
            continue
        # MultiFused_*/SPM##/TM######/
        spm_dir = method_dir / spm
        if spm_dir.is_dir():
            for sub in sorted(spm_dir.iterdir()):
                if sub.is_dir():
                    search_dirs.append(sub)
            search_dirs.append(spm_dir)
        search_dirs.append(method_dir)
    search_dirs.append(fused_dir)

    for search_dir in search_dirs:
        for path in sorted(search_dir.iterdir()):
            if not (path.is_file() or path.suffix == ".zarr"):
                continue
            if path.suffix.lower() not in valid_ext:
                continue
            if any(s in path.name.lower() for s in ["mask", "projection"]):
                continue
            vol = LazyVolume(path)
            volumes.append(vol)
            names.append(path.stem.replace(".ome", ""))
        if volumes:
            break

    return volumes, names


def _is_jupyter() -> bool:
    """Check if running inside Jupyter."""
    try:
        from IPython import get_ipython
        ip = get_ipython()
        return ip is not None and "IPKernelApp" in ip.config
    except (ImportError, AttributeError):
        return False


def _link_colorbars(iw) -> None:
    """Sync vmin/vmax across all subplots so they share one contrast range."""
    hluts = []
    for subplot in iw.figure:
        if "histogram_lut" in subplot.docks["right"]:
            hluts.append(subplot.docks["right"]["histogram_lut"])

    if len(hluts) <= 1:
        return

    _syncing = [False]

    def _make_sync(source_hlut):
        def _sync(ev):
            if _syncing[0]:
                return
            _syncing[0] = True
            try:
                val = ev.info["value"]
                for h in hluts:
                    if h is not source_hlut:
                        setattr(h, ev.type, val)
            finally:
                _syncing[0] = False
        return _sync

    for hlut in hluts:
        handler = _make_sync(hlut)
        for img in hlut._images:
            img.add_event_handler(handler, "vmin", "vmax")


def run_multiview_gui(
    path: str | Path,
    specimen: int = 0,
    cameras: list[int] | None = None,
    timepoint: int | None = None,
    stage: str = "raw",
):
    """Launch the multiview microscopy viewer.

    Parameters
    ----------
    path : str | Path
        Root input directory (raw data, .corrected, or parent of .corrected).
    specimen : int
        Specimen index.
    cameras : list[int] | None
        Camera indices to display. None = auto-detect from XML.
    timepoint : int | None
        Initial timepoint/tile to display. None = first available.
    stage : str
        Processing stage: "raw", "corrected", or "fused".

    Returns
    -------
    ImageWidget | None
        Returns ImageWidget in Jupyter, None in standalone mode.
    """
    import fastplotlib as fpl
    from mbo_utilities.gui._setup import setup_imgui

    setup_imgui()

    from isoview.io import (
        read_all_xml_metadata,
        detect_project_contents,
        detect_mode,
    )
    from ._metadata import isoview_metadata_to_dict
    from .viewers.multiview import MultiviewViewer

    input_dir = Path(path)

    # auto-detect stage from path if user didn't explicitly set it
    if stage == "raw" and _find_corrected_root(input_dir) is not None:
        stage = "corrected"
        logger.info(f"auto-detected stage='corrected' from path")

    # for corrected/fused stage, find the raw dir for XML metadata
    raw_dir = _find_raw_dir(input_dir)

    # read metadata — try raw dir first, fall back to corrected dir
    common_meta, per_camera_meta = read_all_xml_metadata(raw_dir, specimen)
    if not common_meta:
        common_meta, per_camera_meta = read_all_xml_metadata(input_dir, specimen)

    # detect structure and timepoints via detect_project_contents
    structure = None
    contents = None
    for search_dir in [raw_dir, input_dir]:
        if structure is not None:
            break
        try:
            structure = detect_mode(search_dir, specimen)
            contents = detect_project_contents(search_dir, ".corrected", specimen)
        except (ValueError, FileNotFoundError):
            continue
    if structure is None:
        structure = _infer_structure_from_corrected(input_dir)
        logger.info(f"inferred structure '{structure}' from corrected files")

    # extract timepoints from scan result
    timepoints = None
    if contents:
        if contents["mode"] == "tiled":
            timepoints = sorted(int(k[3:]) for k in contents["tiles"])
        else:
            timepoints = sorted(contents["timepoints"].keys())
    if not timepoints:
        timepoints = _detect_timepoints_from_corrected(input_dir)
    if not timepoints:
        timepoints = [0]
        logger.warning("no timepoints detected, using [0]")

    if timepoint is None:
        timepoint = timepoints[0]

    # determine cameras
    camera_view_map = common_meta.get("camera_view_map", {})
    if cameras is None:
        cameras = sorted(camera_view_map.keys()) if camera_view_map else [0, 1, 2, 3]

    # adapt metadata
    adapted_meta = isoview_metadata_to_dict(common_meta, per_camera_meta, stage)

    # load initial volumes
    volumes, camera_names = _load_volumes(
        input_dir=input_dir,
        specimen=specimen,
        timepoint=timepoint,
        cameras=cameras,
        camera_view_map=camera_view_map,
        stage=stage,
        structure=structure,
        common_meta=common_meta,
        per_camera_meta=per_camera_meta,
        contents=contents,
    )

    if not volumes:
        raise FileNotFoundError(
            f"no volumes found for specimen={specimen}, timepoint={timepoint}, "
            f"stage={stage} in {input_dir}"
        )

    # figure layout
    n = len(volumes)
    if n <= 2:
        figure_shape = (1, n)
    elif n <= 4:
        figure_shape = (2, 2)
    else:
        figure_shape = (2, (n + 1) // 2)

    # create image widget
    figure_kwargs = {"size": (800, 600)}
    graphic_kwargs = {"vmin": 0, "vmax": 1000}
    try:
        from rendercanvas.pyqt6 import RenderCanvas  # noqa: F401
        figure_kwargs["canvas"] = "pyqt6"
        figure_kwargs["canvas_kwargs"] = {"present_method": "bitmap"}
    except (ImportError, RuntimeError):
        pass

    iw = fpl.ImageWidget(
        data=volumes,
        names=camera_names,
        slider_dim_names=["z"],
        figure_shape=figure_shape,
        cmap="gray",
        histogram_widget=True,
        figure_kwargs=figure_kwargs,
        graphic_kwargs=graphic_kwargs,
    )

    iw.show()

    # sync vmin/vmax across all subplots
    _link_colorbars(iw)

    # attach multiview viewer as edge window
    viewer = MultiviewViewer(
        image_widget=iw,
        fpath=str(input_dir),
        metadata=adapted_meta,
        per_camera_metadata=per_camera_meta,
        camera_names=camera_names,
        stage=stage,
        structure=structure,
        timepoints=timepoints,
        current_timepoint=timepoint,
        specimen=specimen,
        input_dir=str(raw_dir if stage == "raw" else input_dir),
        contents=contents,
    )

    gui = _make_edge_window(
        viewer=viewer,
        figure=iw.figure,
        size=280,
        location="right",
        title="Multiview",
    )
    iw.figure.add_gui(gui)

    if _is_jupyter():
        return iw

    fpl.loop.run()
    return None


def _make_edge_window(viewer, figure, **kwargs):
    """Create an EdgeWindow that delegates drawing to the viewer."""
    from fastplotlib.ui import EdgeWindow

    class _MultiviewEdgeWindow(EdgeWindow):
        def __init__(self, v, fig, **kw):
            super().__init__(figure=fig, **kw)
            self._viewer = v

        def update(self):
            self._viewer.draw()

    return _MultiviewEdgeWindow(viewer, figure, **kwargs)
