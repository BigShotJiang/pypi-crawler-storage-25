"""Viewer classes for multiview microscopy data."""

__all__ = ["MultiviewViewer"]


def __getattr__(name):
    if name == "MultiviewViewer":
        from .multiview import MultiviewViewer
        return MultiviewViewer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
