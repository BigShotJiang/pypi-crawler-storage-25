"""MultiviewViewer — side-by-side camera viewer for isoview data."""

from __future__ import annotations

from typing import TYPE_CHECKING

from imgui_bundle import imgui

from mbo_utilities.gui.viewers import BaseViewer

if TYPE_CHECKING:
    from fastplotlib.widgets import ImageWidget


class MultiviewViewer(BaseViewer):
    """Viewer for multi-camera light sheet microscopy data.

    Displays camera volumes side-by-side with synchronized Z slider.
    Provides metadata inspection and camera info panels.
    """

    name = "Multiview Viewer"

    def __init__(
        self,
        image_widget: ImageWidget,
        fpath: str | list[str],
        parent=None,
        *,
        metadata: dict | None = None,
        per_camera_metadata: dict | None = None,
        camera_names: list[str] | None = None,
        stage: str = "raw",
        structure: str = "timepoint",
        timepoints: list[int] | None = None,
        current_timepoint: int = 0,
        specimen: int = 0,
        input_dir: str | None = None,
        **kwargs,
    ):
        super().__init__(image_widget, fpath, parent, **kwargs)
        self._metadata = metadata or {}
        self._per_camera_metadata = per_camera_metadata or {}
        self._camera_names = camera_names or []
        self._stage = stage
        self._structure = structure
        self._timepoints = timepoints or []
        self._current_timepoint = current_timepoint
        self._specimen = specimen
        self._input_dir = input_dir
        self._contents = kwargs.get("contents")

        # panel instances (lazy)
        self._metadata_panel = None
        self._camera_info_panel = None
        self._stage_selector = None

    def _ensure_panels(self):
        """Lazily create panels on first draw."""
        if self._metadata_panel is None:
            from ..panels.metadata import MultiviewMetadataPanel
            self._metadata_panel = MultiviewMetadataPanel(self)
        if self._camera_info_panel is None:
            from ..panels.camera_info import CameraInfoPanel
            self._camera_info_panel = CameraInfoPanel(self)
        if self._stage_selector is None and self._timepoints:
            from ..widgets.stage_selector import StageSelectorWidget
            self._stage_selector = StageSelectorWidget(self)

    def get_metadata(self) -> dict:
        """Return adapted metadata dict for MetadataPanel."""
        return self._metadata

    def draw(self) -> None:
        """Render viewer UI: tab bar with preview, metadata, camera info."""
        self._ensure_panels()

        # stage selector at top (tile/timepoint navigation)
        if self._stage_selector is not None:
            self._stage_selector.draw()
            imgui.separator()

        if imgui.begin_tab_bar("##mv_tabs"):
            if imgui.begin_tab_item("Preview")[0]:
                self._draw_preview_tab()
                imgui.end_tab_item()

            if imgui.begin_tab_item("Metadata")[0]:
                if self._metadata_panel:
                    self._metadata_panel.draw_inline()
                imgui.end_tab_item()

            if imgui.begin_tab_item("Cameras")[0]:
                if self._camera_info_panel:
                    self._camera_info_panel.draw_inline()
                imgui.end_tab_item()

            imgui.end_tab_bar()

    def _draw_preview_tab(self):
        """Preview tab: basic info about loaded data."""
        imgui.text(f"stage: {self._stage}")
        imgui.text(f"structure: {self._structure}")

        data_arrays = self._get_data_arrays()
        if data_arrays:
            imgui.text(f"volumes loaded: {len(data_arrays)}")
            for i, arr in enumerate(data_arrays):
                name = self._camera_names[i] if i < len(self._camera_names) else f"#{i}"
                if hasattr(arr, "shape"):
                    imgui.text(f"  {name}: {arr.shape} {arr.dtype}")

        # current z index
        if self.image_widget is not None and self.image_widget.n_sliders > 0:
            indices = self.image_widget.indices
            if indices:
                imgui.text(f"z index: {indices[0]}")

    def draw_menu_bar(self) -> None:
        """Add viewer-specific menu items."""
        if imgui.begin_menu("View"):
            if imgui.menu_item("Metadata", "m")[0]:
                if self._metadata_panel:
                    self._metadata_panel.toggle()
            if imgui.menu_item("Camera Info")[0]:
                if self._camera_info_panel:
                    self._camera_info_panel.toggle()
            imgui.end_menu()

    def on_data_loaded(self) -> None:
        """Update panels when data changes."""
        super().on_data_loaded()

    def cleanup(self) -> None:
        """Release panel resources."""
        if self._metadata_panel:
            self._metadata_panel.cleanup()
        if self._camera_info_panel:
            self._camera_info_panel.cleanup()
        super().cleanup()
