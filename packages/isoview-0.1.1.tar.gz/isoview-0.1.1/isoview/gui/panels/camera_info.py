"""Camera info panel — per-camera summary table."""

from __future__ import annotations

import numpy as np
from imgui_bundle import imgui

from mbo_utilities.gui.panels import BasePanel

__all__ = ["CameraInfoPanel"]


class CameraInfoPanel(BasePanel):
    """Table showing per-camera dimensions, view, wavelength, direction."""

    name = "Camera Info"

    def __init__(self, viewer):
        super().__init__(viewer)

    def draw(self) -> None:
        """Draw as floating window."""
        if not self._visible:
            return

        expanded, opened = imgui.begin("Camera Info", self._visible)
        self._visible = opened
        if expanded:
            self.draw_inline()
        imgui.end()

    def draw_inline(self) -> None:
        """Draw inside a parent container."""
        metadata = {}
        if hasattr(self.viewer, "get_metadata"):
            metadata = self.viewer.get_metadata() or {}

        camera_view_map = metadata.get("camera_view_map", {})
        per_cam = metadata.get("cameras", {})
        wavelength = metadata.get("wavelength", "")

        # also pull data array shapes
        data_arrays = self.viewer._get_data_arrays()
        camera_names = getattr(self.viewer, "_camera_names", [])

        n_cols = 6
        if imgui.begin_table("##cam_table", n_cols, imgui.TableFlags_.borders_inner | imgui.TableFlags_.row_bg):
            imgui.table_setup_column("camera")
            imgui.table_setup_column("view")
            imgui.table_setup_column("shape (Z,Y,X)")
            imgui.table_setup_column("dtype")
            imgui.table_setup_column("direction")
            imgui.table_setup_column("wavelength")
            imgui.table_headers_row()

            for i, arr in enumerate(data_arrays):
                imgui.table_next_row()

                # camera name
                imgui.table_next_column()
                name = camera_names[i] if i < len(camera_names) else f"#{i}"
                imgui.text(name)

                # view assignment
                imgui.table_next_column()
                # try to extract camera index from name like "CM2 (...)"
                cam_idx = _parse_cam_idx(name)
                view = camera_view_map.get(cam_idx, "?") if cam_idx is not None else "?"
                imgui.text(f"VW{view:02d}" if isinstance(view, int) else str(view))

                # shape
                imgui.table_next_column()
                if hasattr(arr, "shape"):
                    imgui.text(str(arr.shape))
                else:
                    imgui.text("?")

                # dtype
                imgui.table_next_column()
                if hasattr(arr, "dtype"):
                    imgui.text(str(arr.dtype))
                else:
                    imgui.text("?")

                # direction (from per-camera metadata)
                imgui.table_next_column()
                cam_key = f"camera_{cam_idx}" if cam_idx is not None else None
                cam_meta = per_cam.get(cam_key, {}) if cam_key else {}
                direction = cam_meta.get("stack_direction", metadata.get("stack_direction", ""))
                imgui.text(str(direction))

                # wavelength
                imgui.table_next_column()
                wl = cam_meta.get("wavelength", wavelength)
                imgui.text(f"{wl}nm" if wl else "?")

            imgui.end_table()

        # summary
        imgui.separator()
        imgui.text(f"stage: {metadata.get('stage', '?')}")
        if metadata.get("dz"):
            imgui.same_line()
            imgui.text(f"| dz: {metadata['dz']:.4f} um")
        if metadata.get("dx"):
            imgui.same_line()
            imgui.text(f"| dx: {metadata['dx']:.4f} um")


def _parse_cam_idx(name: str) -> int | None:
    """Extract camera index from name like 'CM2 (VW90, 488nm)'."""
    import re
    m = re.match(r"CM(\d+)", name)
    return int(m.group(1)) if m else None
