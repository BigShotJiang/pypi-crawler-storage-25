"""Panel classes for multiview viewer."""

__all__ = ["MultiviewMetadataPanel", "CameraInfoPanel"]


def __getattr__(name):
    if name == "MultiviewMetadataPanel":
        from .metadata import MultiviewMetadataPanel
        return MultiviewMetadataPanel
    if name == "CameraInfoPanel":
        from .camera_info import CameraInfoPanel
        return CameraInfoPanel
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
