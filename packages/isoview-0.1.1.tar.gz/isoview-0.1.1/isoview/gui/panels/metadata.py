"""Metadata panel for multiview data.

Reuses mbo_utilities MetadataPanel rendering helpers for the tree view.
Organizes isoview metadata into logical sections.
"""

from __future__ import annotations

from typing import Any

from imgui_bundle import imgui, ImVec2

from mbo_utilities.gui.panels import BasePanel

# borrow rendering helpers from mbo_utilities
from mbo_utilities.gui.panels.metadata import (
    _render_item,
    _NAME_COLORS,
)

__all__ = ["MultiviewMetadataPanel"]

# isoview-specific sections for organized display
_SECTIONS = {
    "microscope": {
        "keys": [
            "detection_objective", "objective_mag", "dx", "dy", "dz",
            "camera_pixel_size_um", "pixel_resolution_um",
        ],
        "color": _NAME_COLORS["imaging"],
    },
    "acquisition": {
        "keys": [
            "wavelength", "exposure_time", "fs", "vps", "num_zplanes",
            "illumination_arms", "illumination_filter", "detection_filter",
            "laser_power", "Lx", "Ly",
        ],
        "color": _NAME_COLORS["acquisition"],
    },
    "stage_position": {
        "keys": ["stage_x", "stage_y", "stage_z", "specimen_XYZT"],
        "color": imgui.ImVec4(1.0, 0.7, 0.4, 1.0),  # orange
    },
    "experiment": {
        "keys": [
            "data_header", "specimen_name", "timestamp", "time_point",
            "experiment_notes", "stage", "camera_view_map", "num_cameras",
        ],
        "color": _NAME_COLORS["other"],
    },
}


class MultiviewMetadataPanel(BasePanel):
    """Metadata panel with isoview-aware section grouping."""

    name = "Metadata"

    def __init__(self, viewer):
        super().__init__(viewer)
        self._filter_text = ""

    def draw(self) -> None:
        """Draw as floating window (toggle via menu)."""
        if not self._visible:
            return

        io = imgui.get_io()
        screen_w, screen_h = io.display_size.x, io.display_size.y
        win_w = min(550, screen_w * 0.45)
        win_h = min(500, screen_h * 0.6)

        imgui.set_next_window_pos(
            ImVec2((screen_w - win_w) / 2, (screen_h - win_h) / 2),
            imgui.Cond_.first_use_ever,
        )
        imgui.set_next_window_size(ImVec2(win_w, win_h), imgui.Cond_.first_use_ever)

        expanded, opened = imgui.begin("Multiview Metadata", self._visible)
        self._visible = opened

        if expanded:
            self._draw_content()

        imgui.end()

    def draw_inline(self) -> None:
        """Draw inside a parent container (tab, child window)."""
        self._draw_content()

    def _draw_content(self):
        """Render metadata tree with search."""
        metadata = {}
        if hasattr(self.viewer, "get_metadata"):
            metadata = self.viewer.get_metadata() or {}

        if not metadata:
            imgui.text("no metadata loaded")
            return

        # search bar
        imgui.set_next_item_width(200)
        _, self._filter_text = imgui.input_text_with_hint(
            "##mv_meta_search", "search...", self._filter_text
        )
        imgui.separator()

        if imgui.begin_child("##mv_metadata_content"):
            # collect keys that belong to sections
            sectioned_keys = set()
            for section in _SECTIONS.values():
                sectioned_keys.update(section["keys"])

            # render organized sections
            for section_name, section_cfg in _SECTIONS.items():
                section_items = {
                    k: metadata[k] for k in section_cfg["keys"] if k in metadata
                }
                if not section_items:
                    continue

                imgui.push_style_color(
                    imgui.Col_.text, imgui.ImVec4(0.6, 0.6, 0.9, 1.0)
                )
                node_open = imgui.tree_node_ex(
                    section_name,
                    imgui.TreeNodeFlags_.default_open,
                )
                imgui.pop_style_color()

                if node_open:
                    for key, value in section_items.items():
                        _render_item(key, value, "", 0, self._filter_text, section_cfg["color"])
                    imgui.tree_pop()

            # cameras section (nested per-camera dicts)
            if "cameras" in metadata:
                imgui.push_style_color(
                    imgui.Col_.text, imgui.ImVec4(0.6, 0.6, 0.9, 1.0)
                )
                node_open = imgui.tree_node_ex(
                    "cameras (per-camera)",
                    imgui.TreeNodeFlags_.default_open,
                )
                imgui.pop_style_color()

                if node_open:
                    _render_item(
                        "cameras", metadata["cameras"], "", 0,
                        self._filter_text, _NAME_COLORS["other"],
                    )
                    imgui.tree_pop()

            # remaining keys not in any section
            other_keys = sorted(
                k for k in metadata
                if k not in sectioned_keys and k != "cameras"
            )
            if other_keys:
                imgui.push_style_color(
                    imgui.Col_.text, imgui.ImVec4(0.6, 0.6, 0.9, 1.0)
                )
                node_open = imgui.tree_node("other")
                imgui.pop_style_color()

                if node_open:
                    for key in other_keys:
                        _render_item(
                            key, metadata[key], "", 0,
                            self._filter_text, _NAME_COLORS["other"],
                        )
                    imgui.tree_pop()

            imgui.end_child()
