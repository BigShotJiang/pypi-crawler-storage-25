"""Specimen/timepoint navigation widget.

Provides a dropdown + arrow buttons to switch between specimens (SPM##)
or timepoints (TM#), reloading volumes into the ImageWidget.
"""

from __future__ import annotations

import logging
from pathlib import Path

from imgui_bundle import imgui

logger = logging.getLogger(__name__)

__all__ = ["StageSelectorWidget"]


class StageSelectorWidget:
    """Navigate between tiles or timepoints."""

    def __init__(self, viewer):
        self.viewer = viewer
        self._loading = False
        self._error: str | None = None

    @property
    def _timepoints(self) -> list[int]:
        return getattr(self.viewer, "_timepoints", [])

    @property
    def _current_idx(self) -> int:
        """Index into _timepoints list (not the timepoint value itself)."""
        tp = getattr(self.viewer, "_current_timepoint", 0)
        if tp in self._timepoints:
            return self._timepoints.index(tp)
        return 0

    def draw(self) -> None:
        """Render navigation controls."""
        tps = self._timepoints
        if not tps:
            return

        structure = getattr(self.viewer, "_structure", "timepoint")
        prefix = "tile" if structure == "tiled" else "timepoint"
        current_tp = getattr(self.viewer, "_current_timepoint", tps[0])
        current_idx = self._current_idx

        # left arrow
        if current_idx <= 0:
            imgui.begin_disabled()
        if imgui.arrow_button("##prev", imgui.Dir.left):
            self._navigate(tps[current_idx - 1])
        if current_idx <= 0:
            imgui.end_disabled()

        imgui.same_line()

        # combo dropdown
        if structure == "tiled":
            labels = [f"TL{tp}" for tp in tps]
        else:
            labels = [f"TM{tp:05d}" for tp in tps]

        imgui.set_next_item_width(120)
        if imgui.begin_combo(f"##{prefix}_combo", labels[current_idx]):
            for i, label in enumerate(labels):
                selected = (i == current_idx)
                if imgui.selectable(label, selected)[0]:
                    self._navigate(tps[i])
                if selected:
                    imgui.set_item_default_focus()
            imgui.end_combo()

        imgui.same_line()

        # right arrow
        if current_idx >= len(tps) - 1:
            imgui.begin_disabled()
        if imgui.arrow_button("##next", imgui.Dir.right):
            self._navigate(tps[current_idx + 1])
        if current_idx >= len(tps) - 1:
            imgui.end_disabled()

        # status
        imgui.same_line()
        imgui.text(f"({current_idx + 1}/{len(tps)})")

        if self._loading:
            imgui.same_line()
            imgui.text("loading...")

        if self._error:
            imgui.text_colored(imgui.ImVec4(1, 0.3, 0.3, 1), self._error)

    def _navigate(self, timepoint: int) -> None:
        """Load volumes for the selected timepoint and update ImageWidget."""
        if self._loading:
            return

        self._loading = True
        self._error = None

        try:
            from .._app import _load_volumes

            input_dir = getattr(self.viewer, "_input_dir", None)
            if input_dir is None:
                self._error = "no input directory set"
                return

            stage = getattr(self.viewer, "_stage", "raw")
            structure = getattr(self.viewer, "_structure", "timepoint")
            specimen = getattr(self.viewer, "_specimen", 0)
            metadata = getattr(self.viewer, "_metadata", {})
            camera_view_map = metadata.get("camera_view_map", {})

            # determine cameras from current display count
            n_subplots = len(self.viewer._get_data_arrays())
            cameras = sorted(camera_view_map.keys())[:n_subplots] if camera_view_map else list(range(n_subplots))

            volumes, names = _load_volumes(
                input_dir=Path(input_dir),
                specimen=specimen,
                timepoint=timepoint,
                cameras=cameras,
                camera_view_map=camera_view_map,
                stage=stage,
                structure=structure,
                common_meta=metadata,
                per_camera_meta=getattr(self.viewer, "_per_camera_metadata", {}),
                contents=getattr(self.viewer, "_contents", None),
            )

            if not volumes:
                self._error = f"no volumes found for {timepoint}"
                return

            # update image widget data in-place
            iw = self.viewer.image_widget
            if iw is not None and len(volumes) == len(list(iw.data)):
                iw.data = volumes

            self.viewer._current_timepoint = timepoint
            self.viewer._camera_names = names
            logger.info(f"loaded {timepoint}: {len(volumes)} volumes")

        except Exception as e:
            self._error = str(e)
            logger.error(f"failed to load {timepoint}: {e}")
        finally:
            self._loading = False
