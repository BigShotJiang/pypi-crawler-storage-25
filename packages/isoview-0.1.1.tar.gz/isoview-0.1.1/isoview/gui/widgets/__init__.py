"""Widget classes for multiview viewer."""

__all__ = ["StageSelectorWidget"]


def __getattr__(name):
    if name == "StageSelectorWidget":
        from .stage_selector import StageSelectorWidget
        return StageSelectorWidget
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
