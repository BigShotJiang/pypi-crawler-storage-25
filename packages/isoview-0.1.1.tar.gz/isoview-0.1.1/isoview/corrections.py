"""Pixel and intensity corrections for microscopy data."""

import numpy as np
from scipy.ndimage import median_filter


def percentile_interp(data: np.ndarray, percentile: float) -> float:
    """Compute percentile using (i+0.5)/n interpolation.

    Args:
        data: 1d array of values (will be sorted internally)
        percentile: percentile to compute (0-100)

    Returns:
        percentile value
    """
    if len(data) == 0:
        return 0.0

    sorted_data = np.sort(data)
    n = len(sorted_data)

    p_rank = 100.0 * (np.arange(n) + 0.5) / n

    # interpolate, clamp to min/max outside range
    return float(np.interp(percentile, p_rank, sorted_data,
                           left=sorted_data[0], right=sorted_data[-1]))


def correct_dead_pixels(
    volume: np.ndarray,
    background_value: float,
    kernel: tuple[int, int],
    verbose: bool = False,
) -> np.ndarray:
    """Detect and correct insensitive pixels using median filtering.

    Args:
        volume: 3d image stack (z, y, x)
        background_value: camera background intensity
        kernel: median filter kernel size (y, x)
        verbose: print detection statistics

    Returns:
        corrected volume
    """
    # detect dead pixels via deviation projection
    deviation_proj = np.std(volume.astype(np.float32), axis=0)
    deviation_filtered = median_filter(deviation_proj, size=kernel, mode="reflect")
    deviation_dist = np.abs(deviation_proj - deviation_filtered)
    deviation_thresh = _determine_threshold(np.sort(deviation_dist.ravel()))
    deviation_mask = deviation_dist > deviation_thresh

    # detect via mean projection
    mean_proj = np.mean(volume, axis=0) - background_value
    mean_filtered = median_filter(mean_proj, size=kernel, mode="reflect")
    mean_dist = np.abs((mean_proj - mean_filtered) / (mean_filtered + 1e-10))
    mean_thresh = _determine_threshold(np.sort(mean_dist.ravel()))
    mean_mask = mean_dist > mean_thresh

    # combine masks
    dead_pixel_mask = deviation_mask | mean_mask

    if verbose:
        n_dead = dead_pixel_mask.sum()
        pct = 100 * n_dead / dead_pixel_mask.size
        print(f"detected {n_dead} dead pixels ({pct:.1f}%)")

    # correct each frame
    corrected = volume.copy()
    for z in range(volume.shape[0]):
        frame = corrected[z]
        filtered = median_filter(frame, size=kernel, mode="reflect")
        frame[dead_pixel_mask] = filtered[dead_pixel_mask]
        corrected[z] = frame

    return corrected


def _determine_threshold(sorted_array: np.ndarray, max_samples: int = 50000) -> float:
    """Determine threshold using maximum distance from linear fit.

    matches matlab's determineThreshold: uses round() for subsampling and
    1-based indexing for the x coordinate.

    Args:
        sorted_array: sorted 1d array
        max_samples: subsample if array is larger

    Returns:
        threshold value
    """
    n = len(sorted_array)

    # subsample if too large (matlab uses round, not floor)
    if n > max_samples:
        step = round(n / max_samples)
        sorted_array = sorted_array[::step]
        n = len(sorted_array)

    # matlab uses 1-based indexing: X = (1:elements)'
    x = np.arange(1, n + 1)

    # find maximum distance from line connecting first and last points
    p1 = np.array([1, sorted_array[0]])
    p2 = np.array([n, sorted_array[-1]])
    vec = p2 - p1

    points = np.column_stack([x, sorted_array])
    h = np.dot(points - p1, vec) / (np.linalg.norm(vec) ** 2)
    proj = p1 + h[:, np.newaxis] * vec
    distances = np.linalg.norm(points - proj, axis=1)

    max_idx = np.argmax(distances)
    return sorted_array[max_idx]


def estimate_background(
    volume: np.ndarray,
    percentile: float = 5.0,
    subsample: int = 100,
) -> float:
    """Estimate background intensity from subsampled volume.

    Args:
        volume: 3d image stack
        percentile: percentile for background estimation
        subsample: subsampling factor

    Returns:
        background intensity value
    """
    subsampled = volume.ravel()[::subsample]
    subsampled = subsampled[subsampled > 0]
    return percentile_interp(subsampled, percentile)
