"""I/O operations for microscopy data."""

import re
from pathlib import Path
from typing import Optional

import numpy as np
import pyklb
import tifffile
import xmltodict

from mbo_utilities.metadata import _build_ome_metadata


CAMERA_PIXEL_SIZE = 6.5


class LazyVolume:
    """lazy wrapper for a single 3D volume file.

    implements the fastplotlib ArrayProtocol (shape, ndim, __getitem__)
    so volumes can be passed to ImageWidget without reading the full file.

    supports tiff, zarr, klb, and raw .stack formats.
    """

    def __init__(
        self,
        path: Path | str,
        dimensions: tuple[int, int, int] | None = None,
    ):
        self._path = Path(path)
        self._dimensions = dimensions
        self._arr = None  # lazy-opened backing array
        self._shape: tuple[int, ...] | None = None
        self._dtype: np.dtype | None = None
        self._init_metadata()

    def _init_metadata(self):
        """read shape and dtype without loading pixel data."""
        p = self._path
        if p.suffix == ".zarr":
            import zarr
            store = zarr.storage.LocalStore(str(p))
            root = zarr.open_group(store=store, mode="r")
            arr = _find_resolution_level(root, "1")
            if arr is None:
                arr = zarr.open_array(store=store, mode="r")
            # report 3D ZYX shape (squeeze leading singleton T,C)
            shape = arr.shape
            while len(shape) > 3 and shape[0] == 1:
                shape = shape[1:]
            self._shape = shape
            self._dtype = arr.dtype
            self._arr = arr
        elif p.suffix in (".tif", ".tiff") or str(p).endswith(".ome.tif"):
            tf = tifffile.TiffFile(str(p))
            series = tf.series[0]
            # report 3D ZYX shape (squeeze leading singleton T,C)
            shape = series.shape
            while len(shape) > 3 and shape[0] == 1:
                shape = shape[1:]
            self._shape = shape
            self._dtype = series.dtype
            self._arr = tf  # keep open for lazy page access
        elif p.suffix == ".klb":
            header = pyklb.readheader(str(p))
            self._shape = tuple(int(d) for d in header["imagesize_tczyx"][-3:])
            self._dtype = np.dtype(header["datatype"])
            # klb doesn't support lazy slicing; read on first access
        elif p.suffix == ".stack":
            dims = self._dimensions
            if dims is None:
                xml_path = _find_xml_for_stack(p)
                if xml_path:
                    meta = read_xml_metadata(xml_path)
                    if "dimensions" in meta:
                        d = meta["dimensions"]
                        if d.ndim > 1:
                            d = d[0]
                        dims = tuple(d)
            if dims is None:
                raise ValueError(f"dimensions required for .stack: {p}")
            width, height, _ = dims
            total_pixels = p.stat().st_size // 2
            depth = total_pixels // (height * width)
            self._shape = (depth, int(height), int(width))
            self._dtype = np.dtype("<u2")
            self._arr = np.memmap(p, dtype="<u2", mode="r", shape=self._shape)
        else:
            raise ValueError(f"unsupported format: {p.suffix}")

    @property
    def shape(self) -> tuple[int, ...]:
        return self._shape

    @property
    def ndim(self) -> int:
        return len(self._shape)

    @property
    def dtype(self) -> np.dtype:
        return self._dtype

    def _ensure_loaded(self):
        """materialize klb data on first slice access."""
        if self._arr is None:
            self._arr = pyklb.readfull(str(self._path))

    def __getitem__(self, key):
        if isinstance(self._arr, (np.ndarray, np.memmap)):
            return np.asarray(self._arr[key])

        if isinstance(self._arr, tifffile.TiffFile):
            return self._read_tiff_sliced(key)

        # zarr array — squeeze leading singleton dims to match reported 3D shape
        if hasattr(self._arr, "get_basic_selection"):
            ndim_extra = len(self._arr.shape) - len(self._shape)
            if ndim_extra > 0:
                prefix = (0,) * ndim_extra
                if isinstance(key, tuple):
                    full_key = prefix + key
                else:
                    full_key = prefix + (key,)
                return np.asarray(self._arr[full_key])
            return np.asarray(self._arr[key])

        # klb fallback: materialize then slice
        self._ensure_loaded()
        return self._arr[key]

    def _read_tiff_sliced(self, key):
        """read tiff pages on demand via page-based indexing."""
        nz = self._shape[0]
        # normalize key to tuple
        if not isinstance(key, tuple):
            key = (key,)
        # pad missing dims with full slices
        key = key + (slice(None),) * (3 - len(key))
        z_key, y_key, x_key = key

        # resolve z indices
        if isinstance(z_key, (int, np.integer)):
            if z_key < 0:
                z_key += nz
            pages = [self._arr.pages[z_key].asarray()]
            result = pages[0][y_key, x_key]
            return result
        elif isinstance(z_key, slice):
            indices = range(*z_key.indices(nz))
        elif isinstance(z_key, (list, np.ndarray)):
            indices = z_key
        else:
            indices = range(nz)

        pages = np.stack([self._arr.pages[i].asarray() for i in indices])
        return pages[:, y_key, x_key] if len(pages.shape) == 3 else pages

    def __array__(self) -> np.ndarray:
        """full materialization for np.asarray() compatibility."""
        return self[:]

    def close(self):
        """release file handles."""
        if hasattr(self._arr, "close") and callable(self._arr.close):
            self._arr.close()
        self._arr = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __repr__(self):
        return f"LazyVolume({self._path.name}, shape={self._shape}, dtype={self._dtype})"


def _mag_label(mag_zyx: tuple[int, int, int]) -> str:
    """convert ZYX mag tuple to directory label (XYZ, dash-separated).

    (1,1,1) -> "1",  (1,2,2) -> "2-2-1"
    """
    x, y, z = mag_zyx[2], mag_zyx[1], mag_zyx[0]
    if x == y == z:
        return str(x)
    return f"{x}-{y}-{z}"


def _find_resolution_level(root, level: str = "1"):
    """find the full-resolution array in an ome-zarr group.

    tries mag label "1" first, then falls back to "0" for legacy datasets.
    """
    if level in root:
        return root[level]
    if "0" in root:
        return root["0"]
    return None


def _write_zarr_v3_level(store, name, data, chunks, shards, compressors,
                         filters=None, serializer=None):
    """write a single zarr v3 array, with optional sharding."""
    import zarr

    kwargs = dict(
        store=store, name=name,
        shape=data.shape, dtype=data.dtype,
        chunks=chunks,
        compressors=compressors if compressors else None,
        zarr_format=3, overwrite=True,
    )
    if shards is not None:
        kwargs["shards"] = shards
    if filters is not None:
        kwargs["filters"] = filters
    if serializer is not None:
        kwargs["serializer"] = serializer
    arr = zarr.create_array(**kwargs)
    arr[:] = data


def _median_downsample(data: np.ndarray, factors: tuple[int, ...]) -> np.ndarray:
    """block-reduce via median, matching webknossos non_linear_filter_3d."""
    if all(f == 1 for f in factors):
        return data
    # trim to evenly divisible shape
    trimmed = tuple(s - s % f for s, f in zip(data.shape, factors))
    slices = tuple(slice(0, t) for t in trimmed)
    d = data[slices]
    # reshape into blocks and take median across block axes
    new_shape = []
    for s, f in zip(trimmed, factors):
        new_shape.extend([s // f, f])
    d = d.reshape(new_shape)
    # median over odd axes (the block-interior axes), from last to first
    for ax in range(len(factors) * 2 - 1, 0, -2):
        d = np.median(d, axis=ax)
    return d.astype(data.dtype)


def _compute_anisotropic_mags(
    voxel_size: tuple[float, float, float],
    shape: tuple[int, int, int],
    max_layers: int,
) -> list[tuple[int, int, int]]:
    """compute per-level mag factors using webknossos anisotropic algorithm.

    at each step, doubles the dimensions with smallest effective physical size
    to produce the most isotropic result. returns list of cumulative mag tuples
    starting from (1,1,1).
    """
    import math

    mags = [(1, 1, 1)]
    current_mag = [1, 1, 1]

    for _ in range(max_layers):
        effective = [m * v for m, v in zip(current_mag, voxel_size)]
        min_eff = min(effective)

        # candidate A: double all dims
        cand_a = [m * 2 for m in current_mag]
        eff_a = [m * v for m, v in zip(cand_a, voxel_size)]

        # candidate B: double only the smallest-effective dims
        cand_b = list(current_mag)
        for i, e in enumerate(effective):
            if math.isclose(e, min_eff, rel_tol=1e-6):
                cand_b[i] *= 2
        eff_b = [m * v for m, v in zip(cand_b, voxel_size)]

        # pick whichever is more isotropic (lower max/min ratio)
        ratio_a = max(eff_a) / min(eff_a) if min(eff_a) > 0 else float("inf")
        ratio_b = max(eff_b) / min(eff_b) if min(eff_b) > 0 else float("inf")
        chosen = cand_a if ratio_a <= ratio_b else cand_b

        # stop if any output dim would be < 64
        out_shape = [s // m for s, m in zip(shape, chosen)]
        if any(d < 64 for d in out_shape[1:]):  # check Y, X
            break

        current_mag = chosen
        mags.append(tuple(current_mag))

    return mags


def _prepare_ome_metadata(
    volume: np.ndarray,
    pixel_spacing: Optional[np.ndarray] = None,
    metadata: Optional[dict] = None,
    camera_metadata: Optional[dict] = None,
) -> dict:
    """Build OME-NGFF v0.5 metadata from isoview metadata.

    Translates isoview-specific keys to what _build_ome_metadata expects,
    injects pixel spacing as dx/dy/dz, and returns structured attrs dict.
    """
    ome_meta = dict(metadata) if metadata else {}

    # merge camera-specific metadata
    if camera_metadata:
        ome_meta.update(camera_metadata)

    # inject pixel spacing
    if pixel_spacing is not None:
        ome_meta["dz"] = float(pixel_spacing[0])
        ome_meta["dy"] = float(pixel_spacing[1])
        ome_meta["dx"] = float(pixel_spacing[2])

    # map isoview keys -> _build_ome_metadata keys
    if "data_header" in ome_meta and "name" not in ome_meta:
        ome_meta["name"] = ome_meta["data_header"]
    if "specimen_name" in ome_meta and "specimen" not in ome_meta:
        ome_meta["specimen"] = ome_meta["specimen_name"]
    if "wavelength" in ome_meta and "emission_wavelength" not in ome_meta:
        ome_meta["emission_wavelength"] = ome_meta["wavelength"]
    if "detection_objective" in ome_meta and "objective" not in ome_meta:
        ome_meta["objective"] = ome_meta["detection_objective"]
    if "timestamp" in ome_meta and "acquisition_date" not in ome_meta:
        ome_meta["acquisition_date"] = ome_meta["timestamp"]

    # convert numpy types for json serialization
    for key, value in list(ome_meta.items()):
        if isinstance(value, np.ndarray):
            ome_meta[key] = value.tolist()
        elif isinstance(value, (np.integer, np.floating)):
            ome_meta[key] = value.item()

    return _build_ome_metadata(
        shape=(1, 1) + volume.shape,
        dtype=volume.dtype,
        metadata=ome_meta,
        dims=("T", "C", "Z", "Y", "X"),
    )


def read_volume(path: Path, dimensions: Optional[tuple[int, int, int]] = None) -> np.ndarray:
    """Read 3D volume from file (klb, tiff, zarr, or stack).

    Args:
        path: file path
        dimensions: (width, height, depth) required for .stack files (MATLAB convention)
    """
    path = Path(path)

    if path.suffix == ".klb":
        volume = pyklb.readfull(str(path))
    elif path.suffix == ".zarr":
        try:
            import zarr
        except ImportError as e:
            raise ImportError(
                "zarr required for .zarr format. Install with: uv pip install 'isoview[parallel]'"
            ) from e

        # open zarr array (supports mag-named levels "1", legacy "0", or plain zarr)
        store = zarr.storage.LocalStore(str(path))
        root = zarr.open_group(store=store, mode="r")

        arr = _find_resolution_level(root, "1")
        if arr is None:
            arr = zarr.open_array(store=store, mode="r")

        volume = arr[:]
        # squeeze leading singleton T,C dims (5D TCZYX -> 3D ZYX)
        while volume.ndim > 3 and volume.shape[0] == 1:
            volume = volume[0]
    elif path.suffix in (".tif", ".tiff") or str(path).endswith(".ome.tif"):
        volume = tifffile.imread(path)
        # squeeze leading singleton T,C dims (5D TCZYX -> 3D ZYX)
        while volume.ndim > 3 and volume.shape[0] == 1:
            volume = volume[0]
    elif path.suffix == ".stack":
        # get height and width from xml, calculate depth from file size
        if dimensions is None:
            xml_path = _find_xml_for_stack(path)
            if xml_path:
                metadata = read_xml_metadata(xml_path)
                if "dimensions" in metadata:
                    dims = metadata["dimensions"]
                    if dims.ndim > 1:
                        dims = dims[0]
                    dimensions = tuple(dims)

        if dimensions is None:
            raise ValueError(f"dimensions required for .stack file: {path}")

        # calculate actual depth from file size
        # dimensions from XML are [width, height, depth] (MATLAB convention)
        width, height, _ = dimensions
        file_size = path.stat().st_size
        total_pixels = file_size // 2  # uint16 = 2 bytes
        depth = total_pixels // (height * width)

        # read binary stack (uint16, bsq format, little-endian)
        # bsq stores band-sequential: each z-slice stored row by row (y then x)
        volume = np.fromfile(path, dtype=np.uint16)
        volume = volume.reshape((depth, height, width))  # (z, y, x)
    else:
        raise ValueError(f"unsupported format: {path.suffix}")

    return volume


def _find_xml_for_stack(stack_path: Path) -> Optional[Path]:
    """Find associated XML metadata file for a stack file."""
    # try same directory with channel xml
    parent = stack_path.parent
    xml_files = list(parent.glob("*.xml"))
    if xml_files:
        return xml_files[0]

    # try parent directories
    for _ in range(2):
        parent = parent.parent
        xml_files = list(parent.glob("*.xml"))
        if xml_files:
            return xml_files[0]

    return None


def write_volume(
    volume: np.ndarray,
    path: Path,
    pixel_spacing: Optional[np.ndarray] = None,
    compression: Optional[str] = "blosc-zstd",
    compression_level: int = 5,
    chunks: Optional[tuple[int, int, int]] = None,
    shards: Optional[tuple[int, int, int]] = None,
    metadata: Optional[dict] = None,
    camera_subpath: Optional[str] = None,
    camera_metadata: Optional[dict] = None,
    pyramid: bool = False,
    pyramid_max_layers: int = 4,
) -> None:
    """Write 3D volume to file (klb, tiff, or zarr).

    Args:
        volume: 3D array (z, y, x)
        path: output file path
        pixel_spacing: physical spacing in micrometers [z, y, x]
        compression: compression codec name
            tiff: 'zstd', 'lzw', 'deflate', 'lzma', or None
            zarr: 'blosc-zstd', 'raw-zstd', 'blosc-lz4', 'blosc-lz4hc', 'gzip', 'bzip2', or None
        compression_level: compression level (1-9 for most codecs, 1-22 for zstd)
        chunks: inner chunk shape for zarr (z, y, x)
            - With sharding: size of individually accessible sub-chunks
            - Without sharding: standard chunk size
            - Default with sharding: (1, full_y, full_x) - one frame per chunk
            - Default without sharding: (10, 128, 128)
        shards: outer chunk/shard shape for zarr (z, y, x)
            - Enables Zarr v3 sharding to reduce file count
            - Groups multiple chunks into single storage objects
            - Recommended: (10, full_y, full_x) - 10 frames per shard file
            - None: disables sharding (default)
        metadata: common microscope metadata dictionary (written to root)
        camera_subpath: optional camera subgroup path (e.g., "camera_0") for multi-camera consolidated zarr
        camera_metadata: optional camera-specific metadata (written to camera subgroup)
        pyramid: whether to generate resolution pyramids (OME-TIFF or OME-Zarr)
        pyramid_max_layers: maximum number of additional pyramid levels
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.suffix == ".zarr":
        try:
            import zarr
            from zarr.codecs import BloscCodec, GzipCodec, BZ2
        except ImportError as e:
            raise ImportError(
                "zarr required for .zarr format. Install with: uv pip install 'isoview[parallel]'"
            ) from e

        # chunk size for ome-zarr (webknossos recommends 64-128 voxels^3)
        if chunks is None:
            chunks = (
                min(64, volume.shape[0]),
                min(64, volume.shape[1]),
                min(64, volume.shape[2]),
            )

        # auto-enable sharding for volumes large enough to benefit
        if shards is None and any(s > 128 for s in volume.shape):
            shards = (
                min(volume.shape[0], max(chunks[0], 64)),
                min(volume.shape[1], max(chunks[1], 512)),
                min(volume.shape[2], max(chunks[2], 512)),
            )
            # ensure shards are multiples of chunks
            shards = tuple(
                max(c, (s // c) * c) for s, c in zip(shards, chunks)
            )

        # build codec chain (zarr v3 API)
        compressors = []
        zarr_filters = None
        zarr_serializer = None
        if compression == "raw-zstd":
            # transpose -> bytes -> zstd (matches webknossos codec chain)
            from zarr.codecs import ZstdCodec, TransposeCodec, BytesCodec
            ndim = len(volume.shape)
            zarr_filters = [TransposeCodec(order=tuple(reversed(range(ndim))))]
            zarr_serializer = BytesCodec()
            compressors = [ZstdCodec(level=compression_level)]
        elif compression in ("zstd", "blosc-zstd"):
            compressors.append(BloscCodec(cname="zstd", clevel=compression_level, shuffle="bitshuffle"))
        elif compression in ("lz4", "blosc-lz4"):
            compressors.append(BloscCodec(cname="lz4", clevel=compression_level, shuffle="shuffle"))
        elif compression in ("lz4hc", "blosc-lz4hc"):
            compressors.append(BloscCodec(cname="lz4hc", clevel=compression_level, shuffle="bitshuffle"))
        elif compression in ("gzip", "deflate"):
            compressors.append(GzipCodec(level=compression_level))
        elif compression == "bzip2":
            compressors.append(BZ2(level=compression_level))
        elif compression is not None:
            raise ValueError(
                f"unsupported zarr compression: {compression}. "
                f"use 'zstd', 'raw-zstd', 'lz4', 'lz4hc', 'gzip', 'deflate', 'bzip2', or None"
            )

        # compute anisotropic mags (matching webknossos algorithm)
        if pyramid and pixel_spacing is not None:
            voxel_size = tuple(float(v) for v in pixel_spacing)
            mags = _compute_anisotropic_mags(voxel_size, volume.shape, pyramid_max_layers)
        elif pyramid:
            mags = [(1, 1, 1)]
            m = [1, 1, 1]
            for _ in range(pyramid_max_layers):
                m = [m[0], m[1] * 2, m[2] * 2]
                if any(volume.shape[i] // m[i] < 64 for i in (1, 2)):
                    break
                mags.append(tuple(m))
        else:
            mags = [(1, 1, 1)]

        # zarr v3 store
        store = zarr.storage.LocalStore(str(path))

        # group prefix for consolidated multi-camera mode
        group_prefix = camera_subpath or ""

        # wrap 3D ZYX as 5D TCZYX (1,1,Z,Y,X)
        vol_5d = volume[np.newaxis, np.newaxis]
        chunks_5d = (1, 1) + chunks
        shards_5d = (1, 1) + shards if shards is not None else None

        # write full-resolution level (named by mag label)
        base_label = _mag_label(mags[0])
        level_path = f"{group_prefix}/{base_label}" if group_prefix else base_label
        _write_zarr_v3_level(store, level_path, vol_5d, chunks_5d, shards_5d, compressors,
                             filters=zarr_filters, serializer=zarr_serializer)

        # build multiscales datasets list
        base_scale = [1.0, 1.0, 1.0, 1.0, 1.0]
        if pixel_spacing is not None:
            base_scale = [1.0, 1.0, float(pixel_spacing[0]), float(pixel_spacing[1]), float(pixel_spacing[2])]

        datasets = [
            {"path": base_label, "coordinateTransformations": [{"type": "scale", "scale": list(base_scale)}]}
        ]

        if len(mags) > 1:
            current = volume
            prev_mag = mags[0]
            for mag in mags[1:]:
                # per-step factors: ratio of this mag to previous mag
                step_factors = tuple(m // p for m, p in zip(mag, prev_mag))
                current = _median_downsample(current, step_factors)
                if current.dtype != volume.dtype:
                    current = current.astype(volume.dtype)

                cur_5d = current[np.newaxis, np.newaxis]
                level_chunks = tuple(min(c, s) for c, s in zip(chunks, current.shape))
                level_chunks_5d = (1, 1) + level_chunks
                level_shards_5d = None
                if shards is not None:
                    level_shards = tuple(
                        min(s, dim) for s, dim in zip(shards, current.shape)
                    )
                    level_shards = tuple(
                        max(c, (s // c) * c) for s, c in zip(level_shards, level_chunks)
                    )
                    level_shards_5d = (1, 1) + level_shards

                label = _mag_label(mag)
                lp = f"{group_prefix}/{label}" if group_prefix else label
                _write_zarr_v3_level(store, lp, cur_5d, level_chunks_5d, level_shards_5d, compressors,
                                     filters=zarr_filters, serializer=zarr_serializer)

                level_scale = [1.0, 1.0] + [base_scale[i + 2] * mag[i] for i in range(3)]
                datasets.append({
                    "path": label,
                    "coordinateTransformations": [{"type": "scale", "scale": level_scale}],
                })
                prev_mag = mag

        # NGFF v0.5 metadata in zarr.json (NgffV0_5Explorer reads this)
        meta = dict(metadata) if metadata else {}
        if camera_metadata:
            meta.update(camera_metadata)

        axes = [
            {"name": "t", "type": "time", "unit": "second"},
            {"name": "c", "type": "channel"},
            {"name": "z", "type": "space", "unit": "micrometer"},
            {"name": "y", "type": "space", "unit": "micrometer"},
            {"name": "x", "type": "space", "unit": "micrometer"},
        ]
        multiscales = [{
            "version": "0.5",
            "name": meta.get("data_header", "volume"),
            "axes": axes,
            "datasets": datasets,
        }]

        omero = {
            "channels": [{
                "active": True,
                "color": "00FF00",
                "label": f"{meta.get('wavelength', '')}nm" if "wavelength" in meta else "Channel 1",
                "window": {
                    "start": 0, "end": int(np.iinfo(volume.dtype).max) if np.issubdtype(volume.dtype, np.integer) else 1.0,
                    "min": 0, "max": int(np.iinfo(volume.dtype).max) if np.issubdtype(volume.dtype, np.integer) else 1.0,
                },
            }],
            "rdefs": {"defaultT": 0, "defaultZ": 0, "model": "greyscale"},
        }

        # write group-level attrs (zarr v3 puts these in zarr.json)
        root = zarr.open_group(store=store, mode="a", zarr_format=3)
        if group_prefix:
            grp = root.require_group(group_prefix)
        else:
            grp = root
        grp.attrs["multiscales"] = multiscales
        grp.attrs["omero"] = omero

    elif path.suffix == ".klb":
        if pixel_spacing is not None:
            spacing = [1.0, 1.0] + list(pixel_spacing[:3])
        else:
            spacing = [1.0, 1.0, 1.0, 1.0, 1.0]
        pyklb.writefull(volume, str(path), pixelspacing_tczyx=spacing)

    elif path.suffix in (".tif", ".tiff") or str(path).endswith(".ome.tif"):
        # map codec names to tifffile equivalents
        _tiff_codec_map = {
            "blosc-zstd": "zstd",
            "blosc-lz4": "lz4",
            "blosc-lz4hc": "lz4",
            "gzip": "deflate",
            "bzip2": "deflate",
        }
        tiff_kwargs = {"tile": (256, 256)}
        if compression is not None:
            codec = _tiff_codec_map.get(compression, compression)
            tiff_kwargs["compression"] = codec
            if codec not in ("lzw",):
                tiff_kwargs["compressionargs"] = {"level": compression_level}

        # write as OME-TIFF if path says .ome.tif or pixel_spacing provided
        is_ome = str(path).endswith(".ome.tif") or pixel_spacing is not None
        if is_ome:
            ome_metadata = {
                "axes": "TCZYX",
            }

            if pixel_spacing is not None:
                ome_metadata.update(
                    {
                        "PhysicalSizeX": float(pixel_spacing[2]),
                        "PhysicalSizeXUnit": "µm",
                        "PhysicalSizeY": float(pixel_spacing[1]),
                        "PhysicalSizeYUnit": "µm",
                        "PhysicalSizeZ": float(pixel_spacing[0]),
                        "PhysicalSizeZUnit": "µm",
                    }
                )
                # per-ifd resolution tags so fiji reads spacing at all pyramid levels
                _res_xy = (1.0 / float(pixel_spacing[2]), 1.0 / float(pixel_spacing[1]))
                _res_kwargs = {"resolution": _res_xy, "resolutionunit": "MICROMETER"}
            else:
                _res_kwargs = {}

            # merge microscope metadata into ome if available
            meta = dict(metadata) if metadata else {}
            if camera_metadata:
                meta.update(camera_metadata)

            # stage position -> per-plane PositionX/Y/Z
            if pixel_spacing is not None and (
                "stage_x" in meta or "stage_y" in meta or "stage_z" in meta
            ):
                n_planes = volume.shape[0]
                dz = float(pixel_spacing[0])
                plane = {}
                if "stage_x" in meta:
                    plane["PositionX"] = [meta["stage_x"]] * n_planes
                    plane["PositionXUnit"] = ["µm"] * n_planes
                if "stage_y" in meta:
                    plane["PositionY"] = [meta["stage_y"]] * n_planes
                    plane["PositionYUnit"] = ["µm"] * n_planes
                if "stage_z" in meta:
                    # per-plane Z = stage_z + plane_index * dz
                    plane["PositionZ"] = [meta["stage_z"] + i * dz for i in range(n_planes)]
                    plane["PositionZUnit"] = ["µm"] * n_planes
                if "exposure_time" in meta:
                    plane["ExposureTime"] = [meta["exposure_time"]] * n_planes
                    plane["ExposureTimeUnit"] = ["ms"] * n_planes
                ome_metadata["Plane"] = plane

            # channel metadata
            if "wavelength" in meta:
                ome_metadata["Channel"] = {"Name": f"{meta['wavelength']}nm"}
                if "emission_wavelength" not in meta:
                    ome_metadata["Channel"]["EmissionWavelength"] = float(meta["wavelength"])
                    ome_metadata["Channel"]["EmissionWavelengthUnit"] = "nm"

            # crop provenance in Description
            if "raw_shape" in meta and "crop_params" in meta:
                cp = meta["crop_params"]
                ome_metadata["Description"] = (
                    f"raw_shape_ZYX: {meta['raw_shape']}\n"
                    f"crop: front={cp.get('crop_front', 0)}, depth={cp.get('crop_depth')}, "
                    f"top={cp.get('crop_top', 0)}, height={cp.get('crop_height')}, "
                    f"left={cp.get('crop_left', 0)}, width={cp.get('crop_width')}"
                )

            # wrap as 5D TCZYX for OME-TIFF
            vol_5d = volume[np.newaxis, np.newaxis]

            if pyramid:
                # ome-tiff SubIFDs only reduce X/Y (same plane count per level)
                frame_pyramid = []
                current = volume
                for _ in range(pyramid_max_layers):
                    current = _median_downsample(current, (1, 2, 2))
                    if current.dtype != volume.dtype:
                        current = current.astype(volume.dtype)
                    if current.shape[1] < 64 or current.shape[2] < 64:
                        break
                    frame_pyramid.append(current[np.newaxis, np.newaxis])

            if pyramid and frame_pyramid:
                with tifffile.TiffWriter(path, bigtiff=True, ome=True) as tif:
                    tif.write(
                        vol_5d, subifds=len(frame_pyramid), metadata=ome_metadata,
                        **_res_kwargs, **tiff_kwargs,
                    )
                    for lvl, downsampled in enumerate(frame_pyramid, 1):
                        scale = 2 ** lvl
                        if _res_kwargs:
                            lvl_res = {
                                "resolution": (_res_xy[0] / scale, _res_xy[1] / scale),
                                "resolutionunit": "MICROMETER",
                            }
                        else:
                            lvl_res = {}
                        tif.write(downsampled, subfiletype=1, **lvl_res, **tiff_kwargs)
            else:
                tifffile.imwrite(
                    path,
                    vol_5d,
                    bigtiff=True,
                    ome=True,
                    metadata=ome_metadata,
                    **_res_kwargs,
                    **tiff_kwargs,
                )
        else:
            if pyramid:
                import logging

                logging.getLogger(__name__).warning(
                    "Pyramids requested but not writing OME-TIFF. Proceeding without pyramids."
                )
            tifffile.imwrite(path, volume, bigtiff=True, **tiff_kwargs)

    else:
        raise ValueError(f"unsupported format: {path.suffix}")


def write_to_consolidated_zarr(
    base_path: Path,
    subpath: str,
    volume: np.ndarray,
    pixel_spacing: Optional[np.ndarray] = None,
    compression: Optional[str] = "blosc-zstd",
    compression_level: int = 9,
    chunks: Optional[tuple[int, int, int]] = None,
    shards: Optional[tuple[int, int, int]] = None,
    label_metadata: Optional[dict] = None,
    camera_subpath: Optional[str] = None,
) -> None:
    """Write array to a consolidated OME-Zarr structure.

    Args:
        base_path: Base Zarr group path (e.g., .../data_TM000000_SPM00.zarr)
        subpath: Relative path within the Zarr group (e.g., "projections/xy", "labels/segmentation")
        volume: Array data to write
        pixel_spacing: Physical spacing in micrometers [z, y, x]
        compression: Compression type
        compression_level: Compression level (0-9)
        chunks: Chunk shape
        shards: Shard shape
        label_metadata: Optional metadata for label images (colors, properties)
        camera_subpath: Optional camera subgroup (e.g., "camera_0") for multi-camera structure
    """
    try:
        import zarr
        from zarr.codecs import BloscCodec, GzipCodec, BZ2
    except ImportError as e:
        raise ImportError(
            "zarr required for consolidated output. "
            "Install with: uv pip install 'isoview[parallel]'"
        ) from e

    # Open or create the base group
    store = zarr.storage.LocalStore(str(base_path))
    root = zarr.open_group(store=store, mode="a")

    # Navigate to camera subgroup if specified
    if camera_subpath:
        if camera_subpath not in root:
            root.create_group(camera_subpath)
        base_group = root[camera_subpath]
    else:
        base_group = root

    # Create subgroup structure
    parts = subpath.split("/")
    current_group = base_group
    for part in parts[:-1]:
        if part not in current_group:
            current_group = current_group.create_group(part)
        else:
            current_group = current_group[part]

    # Prepare compression codecs
    compressors = []
    if compression == "blosc-zstd":
        compressors.append(BloscCodec(cname="zstd", clevel=compression_level, shuffle="bitshuffle"))
    elif compression == "blosc-lz4":
        compressors.append(BloscCodec(cname="lz4", clevel=compression_level, shuffle="shuffle"))
    elif compression == "blosc-lz4hc":
        compressors.append(
            BloscCodec(cname="lz4hc", clevel=compression_level, shuffle="bitshuffle")
        )
    elif compression == "gzip":
        compressors.append(GzipCodec(level=compression_level))
    elif compression == "bzip2":
        compressors.append(BZ2(level=compression_level))

    # wrap 3D ZYX as 5D TCZYX
    vol_5d = volume[np.newaxis, np.newaxis]

    # auto-calculate chunks/shards (3D, then prepend T,C)
    if chunks is None:
        if shards is not None:
            chunks = (1, volume.shape[1], volume.shape[2])
        else:
            chunks = (
                min(10, volume.shape[0]),
                min(128, volume.shape[1]),
                min(128, volume.shape[2]),
            )

    if shards is None and volume.shape[0] >= 20:
        shards = (10, volume.shape[1], volume.shape[2])
        if chunks != (1, volume.shape[1], volume.shape[2]):
            chunks = (1, volume.shape[1], volume.shape[2])

    chunks_5d = (1, 1) + chunks
    shards_5d = (1, 1) + shards if shards is not None else None

    # create array
    array_name = parts[-1]

    # build full path from root (use mag label "1" for single-resolution)
    path_parts = []
    if camera_subpath:
        path_parts.append(camera_subpath)
    path_parts.extend(parts[:-1])
    path_parts.append(array_name)
    path_parts.append("1")
    full_array_path = "/".join(path_parts)

    kwargs = dict(
        store=store,
        name=full_array_path,
        shape=vol_5d.shape,
        chunks=chunks_5d,
        dtype=volume.dtype,
        compressors=compressors if compressors else None,
        zarr_format=3,
        overwrite=True,
    )
    if shards_5d is not None:
        kwargs["shards"] = shards_5d
    arr = zarr.create_array(**kwargs)

    # write data
    arr[:] = vol_5d

    # Add metadata to the array's parent group
    if array_name not in current_group:
        array_group = current_group.create_group(array_name)
    else:
        array_group = current_group[array_name]

    # write ome-ngff v0.5 metadata
    if not label_metadata:
        ome_attrs = _prepare_ome_metadata(volume, pixel_spacing)
        array_group.attrs.update(ome_attrs)

    # Add label metadata if provided
    if label_metadata:
        array_group.attrs["image-label"] = label_metadata


def setup_consolidated_zarr(
    base_path: Path,
    metadata: Optional[dict] = None,
    camera_subpath: Optional[str] = None,
) -> None:
    """Initialize a consolidated OME-Zarr file with proper structure.

    Creates the base group with metadata and prepares for labels/projections.

    Args:
        base_path: Path to the .zarr file
        metadata: Microscope metadata dictionary
        camera_subpath: Optional camera subgroup (e.g., "camera_0") for multi-camera structure
    """
    try:
        import zarr
    except ImportError as e:
        raise ImportError(
            "zarr required for consolidated output. "
            "Install with: uv pip install 'isoview[parallel]'"
        ) from e

    store = zarr.storage.LocalStore(str(base_path))
    root = zarr.open_group(store=store, mode="a")

    # Navigate to camera subgroup if specified
    if camera_subpath:
        if camera_subpath not in root:
            root.create_group(camera_subpath)
        base_group = root[camera_subpath]
    else:
        base_group = root

    # Create labels group
    if "labels" not in base_group:
        labels_group = base_group.create_group("labels")
        labels_group.attrs["labels"] = []  # Will be populated as labels are added

    # Create projections group (custom, not part of OME-Zarr spec but useful)
    if "projections" not in base_group:
        base_group.create_group("projections")

    # structured metadata is written by write_volume() via _prepare_ome_metadata()


def add_label_to_registry(
    base_path: Path,
    label_name: str,
    camera_subpath: Optional[str] = None,
) -> None:
    """Add a label to the labels registry in OME-Zarr.

    Args:
        base_path: Path to the .zarr file
        label_name: Name of the label (e.g., "segmentation", "xz_mask")
        camera_subpath: Optional camera subgroup (e.g., "camera_0") for multi-camera structure
    """
    try:
        import zarr
    except ImportError:
        return

    store = zarr.storage.LocalStore(str(base_path))
    root = zarr.open_group(store=store, mode="a")

    # Navigate to camera subgroup if specified
    if camera_subpath:
        if camera_subpath in root:
            base_group = root[camera_subpath]
        else:
            return
    else:
        base_group = root

    if "labels" in base_group:
        labels_group = base_group["labels"]
        current_labels = list(labels_group.attrs.get("labels", []))
        if label_name not in current_labels:
            current_labels.append(label_name)
            labels_group.attrs["labels"] = current_labels


def read_all_xml_metadata(input_dir: Path, specimen: int) -> tuple[dict, dict]:
    """Read and merge metadata from all XML files for a specimen.

    Args:
        input_dir: Root directory containing specimen data (or TL# folder for timelapse)
        specimen: Specimen number

    Returns:
        Tuple of (common_metadata, per_camera_metadata) where:
        - common_metadata: Metadata that's the same across all cameras
        - per_camera_metadata: Dict mapping camera index to camera-specific metadata
    """
    input_dir = Path(input_dir)

    # Find all XML files for this specimen
    xml_files = []

    # flat layout: ch##_spec##.xml in root
    xml_files.extend(sorted(input_dir.glob(f"ch*_spec{specimen:02d}.xml")))

    # flat layout without spec suffix: ch##.xml (not ch##_spec##.xml)
    if not xml_files:
        for f in sorted(input_dir.glob("ch*.xml")):
            if "_spec" not in f.stem:
                xml_files.append(f)

    # corrected dir patterns (SPM##_*_CHN##.xml, legacy: _VW##.xml)
    if not xml_files:
        xml_files.extend(sorted(input_dir.glob("*_CHN*.xml")))
    if not xml_files:
        xml_files.extend(sorted(input_dir.glob("*_VW*.xml")))
    if not xml_files:
        spm_dir = input_dir / f"SPM{specimen:02d}"
        if spm_dir.exists():
            xml_files.extend(sorted(spm_dir.glob("*_CHN*.xml")))
            if not xml_files:
                xml_files.extend(sorted(spm_dir.glob("*_VW*.xml")))

    if not xml_files:
        return {}, {}

    # Read all XML files, track channel from filename
    all_metadata = []
    file_channels = []  # channel number from filename for each xml
    for xml_file in xml_files:
        try:
            meta = read_xml_metadata(xml_file)
            all_metadata.append(meta)
            # extract channel from filename (e.g. ch00_spec00.xml -> 0, ch01.xml -> 1)
            ch_match = re.search(r"ch(\d+)", xml_file.stem)
            if ch_match:
                file_channels.append(int(ch_match.group(1)))
            else:
                # try CHN naming (e.g. SPM00_TM000000_CHN00.xml -> ch 0)
                chn_match = re.search(r"CHN(\d+)", xml_file.stem)
                if chn_match:
                    file_channels.append(int(chn_match.group(1)))
                else:
                    # legacy VW naming (e.g. SPM00_TM000000_VW00.xml -> ch 0)
                    vw_match = re.search(r"VW(\d+)", xml_file.stem)
                    file_channels.append(int(vw_match.group(1)) if vw_match else None)
        except Exception as e:
            print(f"Warning: Failed to read {xml_file}: {e}")
            continue

    if not all_metadata:
        return {}, {}

    # build camera_view_map from stack_direction
    # Z-scan -> cameras 0,1 -> VW00; Y-scan (90deg) -> cameras 2,3 -> VW90
    camera_view_map = {}
    for meta, ch in zip(all_metadata, file_channels):
        if ch is None:
            continue
        direction = meta.get("stack_direction", "")
        if "Z" in direction.upper():
            camera_view_map[0] = 0
            camera_view_map[1] = 0
        elif "Y" in direction.upper():
            camera_view_map[2] = 90
            camera_view_map[3] = 90

    # Separate common and per-camera metadata
    common_metadata = {}
    per_camera_metadata = {}

    # Get all keys from all metadata dicts
    all_keys = set()
    for meta in all_metadata:
        all_keys.update(meta.keys())

    # Helper function to check if values are equal
    def values_equal(v1, v2):
        if isinstance(v1, np.ndarray) and isinstance(v2, np.ndarray):
            return v1.shape == v2.shape and np.allclose(v1, v2)
        return v1 == v2

    for key in all_keys:
        # Collect values for this key across all cameras
        values = [meta.get(key) for meta in all_metadata if key in meta]

        if not values:
            continue

        # Check if all values are the same
        all_same = all(values_equal(values[0], v) for v in values[1:])

        if all_same:
            # Same across all cameras - add to common metadata
            common_metadata[key] = values[0]
        else:
            # Different across cameras - add to per-camera metadata
            for i, meta in enumerate(all_metadata):
                if key in meta:
                    if i not in per_camera_metadata:
                        per_camera_metadata[i] = {}
                    per_camera_metadata[i][key] = meta[key]

    if camera_view_map:
        common_metadata["camera_view_map"] = camera_view_map

    # unify z_step / y_step into axial_step (same physical spacing, different axis names)
    if "axial_step" not in common_metadata:
        for meta in all_metadata:
            if "z_step" in meta:
                common_metadata["axial_step"] = meta["z_step"]
                break
            if "y_step" in meta:
                common_metadata["axial_step"] = meta["y_step"]
                break

    return common_metadata, per_camera_metadata


def read_xml_metadata(xml_path: Path) -> dict:
    """Parse microscope metadata from xml file.

    Returns dictionary with both raw and calculated metadata fields.
    """
    with open(xml_path, "r") as f:
        data = xmltodict.parse(f.read())

    metadata = {}

    # handle push_config format
    config = data.get("push_config", {})
    info_list = config.get("info", [])
    if not isinstance(info_list, list):
        info_list = [info_list]

    # parse all info elements
    for info in info_list:
        # original fields to keep
        if "@data_header" in info:
            metadata["data_header"] = info["@data_header"]
        if "@specimen_name" in info:
            metadata["specimen_name"] = info["@specimen_name"]
        if "@timestamp" in info:
            metadata["timestamp"] = info["@timestamp"]
        if "@time_point" in info:
            metadata["time_point"] = int(info["@time_point"])
        if "@specimen_XYZT" in info:
            metadata["specimen_XYZT"] = info["@specimen_XYZT"]
            # parse "X=3000.000_Y=770.000_Z=770.000_T=0.0" into stage coords
            try:
                parts = dict(p.split("=") for p in info["@specimen_XYZT"].split("_"))
                metadata["stage_x"] = float(parts.get("X", 0))
                metadata["stage_y"] = float(parts.get("Y", 0))
                metadata["stage_z"] = float(parts.get("Z", 0))
            except (ValueError, KeyError):
                pass
        if "@angle" in info:
            metadata["angle"] = float(info["@angle"])
        if "@camera_index" in info:
            metadata["camera_index"] = info["@camera_index"]
        if "@camera_type" in info:
            metadata["camera_type"] = info["@camera_type"]
        if "@camera_roi" in info:
            metadata["camera_roi"] = info["@camera_roi"]
        if "@wavelength" in info:
            metadata["wavelength"] = info["@wavelength"]
        if "@illumination_arms" in info:
            metadata["illumination_arms"] = info["@illumination_arms"]
        if "@illumination_filter" in info:
            metadata["illumination_filter"] = info["@illumination_filter"]
        if "@exposure_time" in info:
            exposure_time = float(info["@exposure_time"])
            metadata["exposure_time"] = exposure_time
        if "@detection_filter" in info:
            metadata["detection_filter"] = info["@detection_filter"]
        if "@dimensions" in info:
            dims_str = info["@dimensions"]
            # split by comma for multiple cameras
            camera_dims = []
            for cam_dims in dims_str.split(","):
                dims = [int(x) for x in cam_dims.strip().split("x")]
                if len(dims) == 3:
                    camera_dims.append(dims)
            if camera_dims:
                metadata["dimensions"] = np.array(camera_dims)
        if "@z_step" in info:
            metadata["z_step"] = float(info["@z_step"])
        if "@y_step" in info:
            metadata["y_step"] = float(info["@y_step"])
        if "@stack_direction" in info:
            metadata["stack_direction"] = info["@stack_direction"]
        if "@planes" in info:
            metadata["planes"] = info["@planes"]
        if "@laser_power" in info:
            metadata["laser_power"] = info["@laser_power"]
        if "@experiment_notes" in info:
            metadata["experiment_notes"] = info["@experiment_notes"]
        if "@detection_objective" in info:
            metadata["detection_objective"] = info["@detection_objective"]
            obj_str = info["@detection_objective"].split(",")[0]  # first camera
            # Extract magnification: look for number followed by 'x'
            # e.g., "SpecialOptics 16x/0.70" -> 16
            import re

            mag_match = re.search(r"(\d+(?:\.\d+)?)x", obj_str, re.IGNORECASE)
            if mag_match:
                metadata["objective_mag"] = float(mag_match.group(1))

    # calculate derived fields
    if "dimensions" in metadata:
        dims = metadata["dimensions"]
        if dims.ndim > 1:
            dims = dims[0]  # use first camera
        metadata["zplanes"] = int(dims[-1])

    if "exposure_time" in metadata and "zplanes" in metadata:
        # fps = 1000 / exposure_time_ms
        metadata["fps"] = round(1000.0 / metadata["exposure_time"], 2)
        # vps = fps / zplanes (volumes per second)
        metadata["vps"] = round(metadata["fps"] / metadata["zplanes"], 2)

    # pixel resolution calculation
    # pixel size of C11440-22C camera = 6.5 um
    metadata["camera_pixel_size_um"] = CAMERA_PIXEL_SIZE

    if "objective_mag" in metadata:
        # pixel resolution = camera pixel size / magnification
        metadata["pixel_resolution_um"] = (
            metadata["camera_pixel_size_um"] / metadata["objective_mag"]
        )

    return metadata


def read_background_values(
    bg_files: list[Path],
    percentile: float = 3.0,
) -> list[float]:
    """compute background values from Background_*.tif files.

    Args:
        bg_files: list of background tif paths (sorted)
        percentile: percentile for background estimation (default 3.0)

    Returns:
        list of background values in file order
    """
    from .corrections import percentile_interp

    values = []
    for bg_file in bg_files:
        img = tifffile.imread(bg_file)
        bg = percentile_interp(img.ravel().astype(np.float64), percentile)
        values.append(bg)
    return values



# -- detect_project_contents --------------------------------------------------

# volume: SPM##[_{label}]_CM#.{ext} (excluding mask/projection suffixes)
# label group is optional: present for timelapse (TM######), absent for tiled
_CORRECTED_VOL_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d+)"
    r"(?!\.(?:segmentationMask|xzMask|xyMask|xyProjection|xzProjection|yzProjection|"
    r"minIntensity|mask2D|transformedMask2D|fusionMask|mask|fusedStack))"
    r"\.(ome\.tif|tif|tiff|klb|zarr)$"
)

# also match legacy names with _VW## suffix
_CORRECTED_VOL_RE_LEGACY = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d{2})_VW(\d{2})"
    r"(?!\.(?:segmentationMask|xzMask|xyMask|xyProjection|xzProjection|yzProjection|"
    r"minIntensity|mask2D|transformedMask2D|fusionMask|mask|fusedStack))"
    r"\.(ome\.tif|tif|tiff|klb|zarr)$"
)

_MASK_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d+)"
    r"\.(segmentationMask|xzMask|xyMask)"
    r"\.(ome\.tif|tif|tiff|klb|zarr)$"
)

_MASK_RE_LEGACY = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d{2})_VW(\d{2})"
    r"\.(segmentationMask|xzMask|xyMask)"
    r"\.(ome\.tif|tif|tiff|klb|zarr)$"
)

_PROJECTION_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d+)"
    r"\.(xyProjection|xzProjection|yzProjection)"
    r"\.(tif|tiff)$"
)

_PROJECTION_RE_LEGACY = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d{2})_VW(\d{2})"
    r"\.(xyProjection|xzProjection|yzProjection)"
    r"\.(tif|tiff)$"
)

_MIN_INTENSITY_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d+)\.minIntensity\.npz$"
)

_MIN_INTENSITY_RE_LEGACY = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d{2})_VW(\d{2})\.minIntensity\.npz$"
)

# fused: SPM##[_{label}]_CM##_CM##_VW##[.fusedStack].{ext}
_FUSED_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CM(\d{2})_CM(\d{2})_VW(\d{2})"
    r"(?:\.fusedStack)?"
    r"\.(ome\.tif|tif|tiff|klb|zarr)$"
)

# xml copied to corrected: SPM##[_label]_CHN##.xml (legacy: _VW##.xml)
_CORRECTED_XML_RE = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?CHN(\d{2})\.xml$"
)
_CORRECTED_XML_RE_LEGACY = re.compile(
    r"^SPM(\d{2})_(?:(.+?)_)?VW(\d{2})\.xml$"
)

_VOLUME_EXTENSIONS = (".ome.tif", ".tif", ".tiff", ".klb", ".zarr")


def detect_project_contents(
    root: Path | str,
    corrected_suffix: str = ".corrected",
    specimen: int = 0,
) -> dict:
    """Scan a project root and report what raw, corrected, and fused data exists.

    all raw data is flat/unstructured: SPC##_TM#####_ANG###_CM#_CHN##_PH#.stack
    mode is determined from SPC/TM counts:
      - multiple TM -> "timepoint" (timelapse)
      - single TM + multiple SPC -> "tiled" (spatial tiles)
      - single TM + single SPC -> "timepoint" (single acquisition)

    corrected output layout:
      root{suffix}/SPM##/TM######/...   (timelapse)
      root{suffix}/SPM##/...            (tiled, files directly in SPM## folder)

    Args:
        root: project root directory
        corrected_suffix: suffix for corrected directories (e.g. ".corrected")
        specimen: specimen number (used for timelapse mode)

    Returns:
        dict with mode, root, and per-tile or per-timepoint contents
    """
    root = Path(root)
    if not root.exists():
        raise FileNotFoundError(f"root does not exist: {root}")

    structure = detect_mode(root, specimen)
    result = {"mode": structure, "root": root}

    if structure == "tiled":
        result["tiles"] = _scan_tiled(root, corrected_suffix)
    else:
        result.update(_scan_timepoint_project(root, corrected_suffix, specimen))

    return result


def detect_mode(root: Path, specimen: int = 0) -> str:
    """Determine dataset mode from flat SPC##_TM#####_*.stack filenames.

    Returns:
        "tiled" — single TM, multiple SPC (spatial tiles)
        "timepoint" — multiple TM values, or single TM + single SPC
    """
    spc_set = set()
    tm_set = set()
    stack_re = re.compile(r"SPC(\d+)_TM(\d+)_.*\.stack")
    for entry in root.iterdir():
        if not entry.is_file():
            continue
        m = stack_re.match(entry.name)
        if m:
            spc_set.add(int(m.group(1)))
            tm_set.add(int(m.group(2)))

    if not spc_set:
        raise ValueError(f"no SPC##_TM##_*.stack files found in {root}")

    if len(tm_set) == 1 and len(spc_set) > 1:
        return "tiled"
    return "timepoint"


def _scan_tiled(root: Path, corrected_suffix: str) -> dict:
    """Scan a tiled project with flat SPC##_TM#####_*.stack files."""
    tiles = {}

    # parse all stack files, group by SPC##
    stack_re = re.compile(
        r"SPC(\d+)_TM(\d+)_ANG\d+_CM(\d+)_CHN(\d{2})_PH\d+\.stack"
    )
    stacks_by_spc: dict[int, dict] = {}
    for f in sorted(root.iterdir()):
        if not f.is_file():
            continue
        m = stack_re.fullmatch(f.name)
        if m:
            spc = int(m.group(1))
            cam = int(m.group(3))
            chn = int(m.group(4))
            stacks_by_spc.setdefault(spc, {})[(cam, chn)] = f

    # shared backgrounds
    bg_files = sorted(root.glob("Background_*.tif"))

    # xml: ch##_spec##.xml -> mapped by spec## to SPC##
    xml_by_spc: dict[int, dict[int, Path]] = {}
    xml_re = re.compile(r"ch(\d+)_spec(\d+)\.xml")
    for f in sorted(root.iterdir()):
        if not f.is_file():
            continue
        m = xml_re.fullmatch(f.name)
        if m:
            ch = int(m.group(1))
            spc = int(m.group(2))
            xml_by_spc.setdefault(spc, {})[ch] = f

    # corrected root
    corrected_root = root.parent / f"{root.name}{corrected_suffix}"

    for spc in sorted(stacks_by_spc):
        tile_key = f"SPM{spc:02d}"
        tile_info = {
            "raw_dir": root,
            "raw_stacks": stacks_by_spc[spc],
            "xml": xml_by_spc.get(spc, {}),
            "backgrounds": bg_files,
        }

        # corrected data: root.corrected/SPM##/
        spm_dir = corrected_root / tile_key
        if spm_dir.is_dir():
            tile_info["corrected"] = _scan_corrected_dir(spm_dir, spc, tile_key)
            tile_info["corrected"]["dir"] = spm_dir
        else:
            tile_info["corrected"] = None

        # fusion: root.corrected/Results/MultiFused_*/SPM##/
        results_dir = corrected_root / "Results"
        if results_dir.is_dir():
            tile_info["fusion"] = _scan_fusion_results(
                results_dir, spc, tile_key, tiled=True
            )
        else:
            tile_info["fusion"] = {}

        tiles[tile_key] = tile_info
    return tiles


def _scan_timepoint_project(
    root: Path, corrected_suffix: str, specimen: int
) -> dict:
    """Scan a timelapse project with flat SPC##_TM#####_*.stack files."""
    result = {}

    # backgrounds (shared in root)
    bg_files = sorted(root.glob("Background_*.tif"))
    result["backgrounds"] = bg_files

    # parse flat stacks
    spc_prefix = f"SPC{specimen:02d}_TM"
    stack_re = re.compile(
        rf"SPC{specimen:02d}_TM(\d+)_ANG\d+_CM(\d+)_CHN(\d{{2}})_PH\d+\.stack"
    )
    tp_set = set()
    flat_stacks: dict[int, dict] = {}
    for f in sorted(root.iterdir()):
        if not f.is_file():
            continue
        if f.name.startswith(spc_prefix) and f.suffix == ".stack":
            m = stack_re.fullmatch(f.name)
            if m:
                tp = int(m.group(1))
                cam = int(m.group(2))
                chn = int(m.group(3))
                tp_set.add(tp)
                flat_stacks.setdefault(tp, {})[(cam, chn)] = f

    # xml: ch##_spec##.xml or ch##.xml
    flat_xml: dict[int, Path] = {}
    for f in sorted(root.iterdir()):
        if not f.is_file():
            continue
        mx = re.fullmatch(
            rf"ch(\d+)(?:_spec{specimen:02d})?\.xml", f.name
        )
        if mx:
            flat_xml[int(mx.group(1))] = f

    # corrected root
    corrected_root = root.parent / f"{root.name}{corrected_suffix}"
    spm_dir = corrected_root / f"SPM{specimen:02d}"

    # also check corrected dir for timepoints (some may only exist there)
    if spm_dir.is_dir():
        for entry in spm_dir.iterdir():
            if entry.is_dir():
                m = re.fullmatch(r"TM(\d+)", entry.name)
                if m:
                    tp_set.add(int(m.group(1)))

    timepoints = {}
    for tp in sorted(tp_set):
        label = f"TM{tp:06d}"
        tp_info = {
            "raw_dir": root,
            "raw_stacks": flat_stacks.get(tp, {}),
            "xml": flat_xml,
        }

        # corrected: root.corrected/SPM##/TM######/
        corrected_tp_dir = spm_dir / label
        if corrected_tp_dir.is_dir():
            tp_info["corrected"] = _scan_corrected_dir(corrected_tp_dir, specimen, label)
            tp_info["corrected"]["dir"] = corrected_tp_dir
        else:
            tp_info["corrected"] = None

        # fusion: root.corrected/Results/MultiFused_*/SPM##/TM######/
        results_dir = corrected_root / "Results"
        if results_dir.is_dir():
            tp_info["fusion"] = _scan_fusion_results(
                results_dir, specimen, label, tiled=False
            )
        else:
            tp_info["fusion"] = {}

        timepoints[tp] = tp_info

    result["timepoints"] = timepoints
    return result


def _label_matches(spm_str: str, lbl: str | None, specimen: int, label: str) -> bool:
    """Check if extracted spm/label match expected values. lbl is None for tiled (no label in filename)."""
    return int(spm_str) == specimen and (lbl == label or lbl is None)


def _scan_corrected_dir(scan_dir: Path, specimen: int, label: str) -> dict:
    """Scan a corrected directory for volumes, masks, projections, etc."""
    volumes = {}
    masks = {}
    projections = {}
    min_intensity = {}
    xml_files = {}

    if not scan_dir.is_dir():
        return {
            "volumes": volumes,
            "masks": masks,
            "projections": projections,
            "min_intensity": min_intensity,
            "xml": xml_files,
        }

    for f in sorted(scan_dir.iterdir()):
        if not (f.is_file() or f.suffix == ".zarr"):
            continue
        name = f.name

        # volume (new: SPM##_CM#.ext, legacy: SPM##_CM##_VW##.ext)
        m = _CORRECTED_VOL_RE.match(name)
        if m:
            spm, lbl, cam = m.group(1), m.group(2), int(m.group(3))
            if _label_matches(spm, lbl, specimen, label):
                volumes[cam] = f
            continue
        m = _CORRECTED_VOL_RE_LEGACY.match(name)
        if m:
            spm, lbl, cam = m.group(1), m.group(2), int(m.group(3))
            if _label_matches(spm, lbl, specimen, label):
                volumes[cam] = f
            continue

        # mask (new: SPM##_CM#.mask.ext, legacy: SPM##_CM##_VW##.mask.ext)
        m = _MASK_RE.match(name)
        legacy_mask = False
        if not m:
            m = _MASK_RE_LEGACY.match(name)
            legacy_mask = True
        if m:
            spm, lbl, cam = m.group(1), m.group(2), int(m.group(3))
            mask_type = m.group(5) if legacy_mask else m.group(4)
            if _label_matches(spm, lbl, specimen, label):
                if cam not in masks:
                    masks[cam] = {}
                type_key = {"segmentationMask": "segmentation", "xzMask": "xz", "xyMask": "xy"}[mask_type]
                masks[cam][type_key] = f
            continue

        # projection (new: SPM##_CM#.proj.ext, legacy: SPM##_CM##_VW##.proj.ext)
        m = _PROJECTION_RE.match(name)
        legacy_proj = False
        if not m:
            m = _PROJECTION_RE_LEGACY.match(name)
            legacy_proj = True
        if m:
            spm, lbl, cam = m.group(1), m.group(2), int(m.group(3))
            proj_type = (m.group(5) if legacy_proj else m.group(4)).replace("Projection", "")
            if _label_matches(spm, lbl, specimen, label):
                if cam not in projections:
                    projections[cam] = {}
                projections[cam][proj_type] = f
            continue

        # min intensity
        m = _MIN_INTENSITY_RE.match(name)
        if not m:
            m = _MIN_INTENSITY_RE_LEGACY.match(name)
        if m:
            spm, lbl, cam = m.group(1), m.group(2), int(m.group(3))
            if _label_matches(spm, lbl, specimen, label):
                min_intensity[cam] = f
            continue

        # xml (corrected copies)
        m = _CORRECTED_XML_RE.match(name)
        if not m:
            m = _CORRECTED_XML_RE_LEGACY.match(name)
        if m:
            spm, lbl, ch = m.group(1), m.group(2), int(m.group(3))
            if _label_matches(spm, lbl, specimen, label):
                xml_files[ch] = f
            continue

    return {
        "volumes": volumes,
        "masks": masks,
        "projections": projections,
        "min_intensity": min_intensity,
        "xml": xml_files,
    }


def _scan_fusion_results(
    results_dir: Path, specimen: int, label: str, tiled: bool
) -> dict:
    """Scan Results/ for MultiFused_* method directories."""
    fusion = {}

    if not results_dir.is_dir():
        return fusion

    for method_dir in sorted(results_dir.iterdir()):
        if not method_dir.is_dir() or not method_dir.name.startswith("MultiFused_"):
            continue
        method = method_dir.name[len("MultiFused_"):]

        # tiled: label=SPM## -> method_dir/SPM##/
        # timelapse: label=TM###### -> method_dir/SPM##/TM######/
        if tiled:
            label_subdir = method_dir / label
        else:
            label_subdir = method_dir / f"SPM{specimen:02d}" / label
        if label_subdir.is_dir():
            pairs = _scan_fusion_pairs(label_subdir, specimen, label, tiled=tiled)
            if pairs:
                fusion[method] = {"dir": label_subdir, "pairs": pairs}

    return fusion


def _scan_fusion_pairs(
    scan_dir: Path, specimen: int, label: str, tiled: bool
) -> dict:
    """Scan a directory for fused volumes and companion files."""
    pairs = {}

    if not scan_dir.is_dir():
        return pairs

    entries = sorted(scan_dir.iterdir())
    entry_names = {e.name for e in entries}

    for f in entries:
        if not (f.is_file() or f.suffix == ".zarr"):
            continue

        m = _FUSED_RE.match(f.name)
        if not m:
            continue

        spm = int(m.group(1))
        lbl = m.group(2)
        cam0 = int(m.group(3))
        cam1 = int(m.group(4))
        vw = int(m.group(5))

        if not _label_matches(m.group(1), lbl, specimen, label):
            continue

        key = (cam0, cam1, vw)
        if key in pairs:
            continue

        spm_str = f"SPM{specimen:02d}"
        if lbl:
            base = f"{spm_str}_{lbl}_CM{cam0:02d}_CM{cam1:02d}_VW{vw:02d}"
        else:
            base = f"{spm_str}_CM{cam0:02d}_CM{cam1:02d}_VW{vw:02d}"

        # find companion files
        pair_info = {"fused": f}

        # 3D mask
        for ext in _VOLUME_EXTENSIONS:
            mask_name = f"{base}.mask{ext}"
            if mask_name in entry_names:
                pair_info["mask"] = scan_dir / mask_name
                break

        # fusion mask (2D)
        for ext in (".tif", ".tiff"):
            fm = f"{base}.fusionMask{ext}"
            if fm in entry_names:
                pair_info["fusion_mask"] = scan_dir / fm
                break

        # projections
        projs = {}
        for proj_type in ("xy", "xz", "yz"):
            for ext in (".tif", ".tiff"):
                pf = f"{base}.{proj_type}Projection{ext}"
                if pf in entry_names:
                    projs[proj_type] = scan_dir / pf
                    break
        if projs:
            pair_info["projections"] = projs

        pairs[key] = pair_info

    return pairs


def discover_fused_view_pairs(
    output_dir: Path,
    corrected_suffix: str = ".corrected",
) -> list[dict]:
    """find VW00/VW90 fused pairs in Results/MultiFused_*/SPM##/.

    returns list of dicts with keys:
      spm_key, method, vw00_path, vw90_path, label (TM###### or None)
    """
    output_dir = Path(output_dir)
    results_dir = output_dir / "Results"
    if not results_dir.is_dir():
        corrected_dir = output_dir.parent / f"{output_dir.name}{corrected_suffix}"
        results_dir = corrected_dir / "Results"

    if not results_dir.is_dir():
        return []

    vw_re = re.compile(r"(SPM\d+)_(?:(TM\d+)_)?CM\d+_CM\d+_VW(\d+)")

    pairs = []
    for method_dir in sorted(results_dir.iterdir()):
        if not method_dir.is_dir() or not method_dir.name.startswith("MultiFused_"):
            continue
        method = method_dir.name[len("MultiFused_"):]

        for spm_dir in sorted(method_dir.iterdir()):
            if not spm_dir.is_dir() or not spm_dir.name.startswith("SPM"):
                continue
            spm_key = spm_dir.name

            views = {}
            for f in sorted(spm_dir.rglob("*.ome.tif")):
                m = vw_re.match(f.stem.split(".")[0])
                if not m:
                    continue
                label = m.group(2)
                vw = int(m.group(3))
                if label not in views:
                    views[label] = {}
                if vw not in views[label]:
                    views[label][vw] = f

            for sub in sorted(spm_dir.iterdir()):
                if not sub.is_dir() or not sub.name.startswith("TM"):
                    continue
                for f in sorted(sub.glob("*.ome.tif")):
                    m = vw_re.match(f.stem.split(".")[0])
                    if not m:
                        continue
                    label = m.group(2)
                    vw = int(m.group(3))
                    if label not in views:
                        views[label] = {}
                    if vw not in views[label]:
                        views[label][vw] = f

            for label, vw_dict in views.items():
                if 0 in vw_dict and 90 in vw_dict:
                    pairs.append({
                        "spm_key": spm_key,
                        "method": method,
                        "label": label,
                        "vw00_path": vw_dict[0],
                        "vw90_path": vw_dict[90],
                    })

    return pairs
