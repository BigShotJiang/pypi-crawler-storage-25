"""Foreground segmentation for microscopy data."""

import logging
import warnings

import numpy as np
from scipy.ndimage import convolve1d

from .corrections import percentile_interp

logger = logging.getLogger(__name__)


def _make_gaussian_kernel(sigma: float, size: int) -> np.ndarray:
    """Create 1D Gaussian kernel."""
    half = int(np.ceil(size / 2))
    x = np.arange(-half, half + 1)
    kernel = np.exp(-(x ** 2) / (2 * sigma ** 2))
    return kernel / kernel.sum()


def _imgaussian_anisotropy(volume: np.ndarray, sigma: np.ndarray, size: np.ndarray) -> np.ndarray:
    """Apply separable 3D anisotropic Gaussian filter."""
    kernel_z = _make_gaussian_kernel(sigma[0], size[0])
    kernel_y = _make_gaussian_kernel(sigma[1], size[1])
    kernel_x = _make_gaussian_kernel(sigma[2], size[2])

    result = convolve1d(volume, kernel_z, axis=0, mode='nearest')
    result = convolve1d(result, kernel_y, axis=1, mode='nearest')
    result = convolve1d(result, kernel_x, axis=2, mode='nearest')

    return result


def segment_foreground(
    volume: np.ndarray,
    kernel_sigma: float,
    kernel_size: int,
    threshold: float,
    mask_percentile: float,
    scaling: float,
    splitting: int = 10,
    subsample_factor: int = 100,
    verbose: bool = False,
) -> np.ndarray:
    """Generate binary foreground mask using anisotropic gaussian filtering.

    Args:
        volume: 3d image stack (z, y, x)
        kernel_sigma: gaussian sigma in xy
        kernel_size: gaussian kernel size in xy
        threshold: adaptive threshold (0-1)
        mask_percentile: percentile for minimum intensity
        scaling: z/xy pixel spacing ratio
        splitting: number of slabs for memory efficiency
        subsample_factor: subsampling for percentile calculation
        verbose: print statistics

    Returns:
        binary mask (uint16: 0 or 1)
    """
    sigma_z = max(1.0, kernel_sigma / scaling)
    size_z = max(1, int(kernel_size / scaling))
    sigma = np.array([sigma_z, kernel_sigma, kernel_sigma])
    size = np.array([size_z, kernel_size, kernel_size])

    z_dim, y_dim, x_dim = volume.shape
    filtered = np.zeros_like(volume, dtype=np.uint16)
    margin = 2 * kernel_size

    for i in range(splitting):
        start = max(0, round((i / splitting) * y_dim) - margin)
        stop = min(y_dim, round(((i + 1) / splitting) * y_dim) + margin)

        slab = volume[:, start:stop, :].astype(np.float64)
        conv = _imgaussian_anisotropy(slab, sigma, size)

        if i == 0:
            filtered[:, :stop - margin, :] = np.round(conv[:, : stop - margin - start, :]).astype(np.uint16)
        elif i == splitting - 1:
            filtered[:, start + margin:, :] = np.round(conv[:, margin:, :]).astype(np.uint16)
        else:
            inner_start = margin
            inner_stop = stop - start - margin
            filtered[:, start + margin : stop - margin, :] = np.round(conv[:, inner_start:inner_stop, :]).astype(np.uint16)

    min_intensity = percentile_interp(filtered.ravel()[::subsample_factor], mask_percentile)

    total_sum = 0.0
    total_count = 0
    for i in range(splitting):
        start = round((i / splitting) * y_dim)
        stop = round(((i + 1) / splitting) * y_dim)
        slab = filtered[:, start:stop, :]
        above_min = slab[slab > min_intensity]
        total_sum += float(above_min.sum())
        total_count += above_min.size

    mean_intensity = total_sum / total_count if total_count > 0 else min_intensity
    level = min_intensity + (mean_intensity - min_intensity) * threshold

    mask = (filtered > level).astype(np.uint16)

    if verbose:
        fg_pct = 100 * mask.sum() / mask.size
        logger.debug(f"foreground: {fg_pct:.1f}%, min={min_intensity:.2f}, mean={mean_intensity:.2f}, level={level:.2f}")

    return mask


def fuse_masks(masks: list[np.ndarray]) -> np.ndarray:
    """Fuse multiple segmentation masks using logical or.

    Args:
        masks: list of binary masks

    Returns:
        fused binary mask
    """
    if not masks:
        raise ValueError("no masks to fuse")

    result = masks[0].astype(bool)
    for mask in masks[1:]:
        result |= mask.astype(bool)

    return result.astype(np.uint16)


def create_coordinate_masks(
    mask: np.ndarray,
    splitting: int = 10,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate coordinate masks for interpolation.

    Args:
        mask: binary foreground mask (z, y, x)
        splitting: number of slabs to split y-axis for memory-efficient processing

    Returns:
        xz_mask: shape (y, z), stores mean x coordinate at each (y, z) position
        xy_mask: shape (y, x), stores mean z coordinate at each (y, x) position
    """
    z_size, y_size, x_size = mask.shape

    # suppress expected nanmean warnings for all-nan slices (sparse masks)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)

        # xz_mask: (y, z) - for each (y, z), mean x coordinate
        xz_mask = np.zeros((y_size, z_size), dtype=np.uint16)
        for i in range(splitting):
            y_start = round((i / splitting) * y_size)
            y_stop = round(((i + 1) / splitting) * y_size)
            slab_height = y_stop - y_start

            x_coords = np.arange(x_size)[np.newaxis, np.newaxis, :]
            coord_vol = np.broadcast_to(x_coords, (z_size, slab_height, x_size)).astype(np.float32)
            coord_vol = np.copy(coord_vol)
            coord_vol[mask[:, y_start:y_stop, :] == 0] = np.nan
            slab_result = np.round(np.nanmean(coord_vol, axis=2)).astype(np.uint16)
            xz_mask[y_start:y_stop, :] = slab_result.T

        # xy_mask: (y, x) - for each (y, x), mean z coordinate
        xy_mask = np.zeros((y_size, x_size), dtype=np.uint16)
        for i in range(splitting):
            y_start = round((i / splitting) * y_size)
            y_stop = round(((i + 1) / splitting) * y_size)
            slab_height = y_stop - y_start

            z_coords = np.arange(z_size)[:, np.newaxis, np.newaxis]
            coord_vol = np.broadcast_to(z_coords, (z_size, slab_height, x_size)).astype(np.float32)
            coord_vol = np.copy(coord_vol)
            coord_vol[mask[:, y_start:y_stop, :] == 0] = np.nan
            xy_mask[y_start:y_stop, :] = np.round(np.nanmean(coord_vol, axis=0)).astype(np.uint16)

    return xz_mask, xy_mask
