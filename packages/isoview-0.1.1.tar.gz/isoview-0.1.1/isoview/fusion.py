"""Multi-view fusion for IsoView microscopy data."""

import logging
import time
from pathlib import Path
from typing import Literal

import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d
from .config import ProcessingConfig
from .log import setup_logging, setup_queue_logging, start_log_listener

logger = logging.getLogger(__name__)
from .intensity import (
    apply_intensity_correction,
    estimate_background,
    estimate_intensity_correction,
    subtract_background,
)
from .io import detect_project_contents, read_all_xml_metadata, read_volume, write_volume
from .masks import create_average_mask, create_fusion_mask, create_slice_mask, remove_mask_anomalies
from .pipeline import RunLog
from .transforms import (
    apply_camera_transform,
    estimate_camera_transform,
    flip_volume,
    rotate_volume,
)


def _write_2d(
    arr: np.ndarray, path: Path, compression: str | None = None, compression_level: int = 5
) -> None:
    """Write 2D array to file (tif or klb)."""
    import pyklb
    import tifffile

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.suffix in (".tif", ".tiff"):
        _tiff_codec_map = {
            "blosc-zstd": "zstd",
            "blosc-lz4": "lz4",
            "blosc-lz4hc": "lz4",
            "gzip": "deflate",
            "bzip2": "deflate",
        }
        kwargs = {}
        if compression is not None:
            codec = _tiff_codec_map.get(compression, compression)
            kwargs["compression"] = codec
            if codec not in ("lzw",):
                kwargs["compressionargs"] = {"level": compression_level}
        tifffile.imwrite(path, arr, **kwargs)
    elif path.suffix == ".klb":
        pyklb.writefull(arr, str(path))
    else:
        raise ValueError(f"unsupported 2D format: {path.suffix}")


def orient_view(
    vol: np.ndarray,
    flip_axis: int | None = None,
    rotation: int = 0,
    transpose_zy: bool = True,
) -> np.ndarray:
    """Orient an orthogonal view volume into the reference view's coordinate space.

    For IsoView: VW90 (Y-scan) -> VW00 (Z-scan) space.
    Operations applied in order: transpose Z/Y, rotate in YX plane, flip.

    Args:
        vol: 3D array (Z, Y, X)
        flip_axis: axis to flip (0=Z, 1=Y, 2=X), None=no flip
        rotation: 0=none, 1=90CW, 2=180, -1=90CCW (in YX plane after transpose)
        transpose_zy: swap Z and Y axes (True for orthogonal views)
    """
    out = vol
    if transpose_zy:
        out = out.transpose(1, 0, 2)
    if rotation != 0:
        # np.rot90 k=1 is CCW, so CW = k=-1
        k = {1: -1, -1: 1, 2: 2}.get(rotation)
        if k is None:
            raise ValueError(f"invalid rotation: {rotation}, use 0, 1, -1, or 2")
        out = np.rot90(out, k=k, axes=(1, 2))
    if flip_axis is not None:
        out = np.flip(out, axis=flip_axis)
    return np.ascontiguousarray(out)


def fuse_views(
    vol0: np.ndarray,
    vol1: np.ndarray,
    mask0: np.ndarray | None = None,
    mask1: np.ndarray | None = None,
    blending_method: str = "adaptive",
    blending_range: int = 20,
    transition_plane: int | None = None,
    front_flag: int = 1,
    search_x: tuple[int, int, int] = (-50, 50, 10),
    search_y: tuple[int, int, int] = (-50, 50, 10),
    mask_percentile: float = 1.0,
) -> tuple[np.ndarray, dict]:
    """
    Fuse two 3D volumes (camera-camera fusion).

    Core fusion function with no file I/O - operates purely on arrays.
    Estimates x/y offset + rotation in XY plane between two camera views.

    Parameters
    ----------
    vol0 : ndarray
        Reference volume (Z, Y, X)
    vol1 : ndarray
        Moving volume (Z, Y, X)
    mask0 : ndarray or None
        Binary mask for vol0, created if None
    mask1 : ndarray or None
        Binary mask for vol1, created if None
    blending_method : str
        Blending method: adaptive, geometric, average
    blending_range : int
        Width of transition zone in Z-planes
    transition_plane : int or None
        Z-index for geometric blending, None = center
    front_flag : int
        Which view is dominant in front (low Z). 1=view1, 2=view2
    search_x : tuple
        Registration search range (start, stop, step) for X
    search_y : tuple
        Registration search range (start, stop, step) for Y
    mask_percentile : float
        Percentile for mask creation if masks not provided

    Returns
    -------
    fused : ndarray
        Fused volume (Z, Y, X)
    params : dict
        Estimated parameters (transform, intensity correction)
    """
    # create masks if not provided
    if mask0 is None:
        mask0 = create_fusion_mask(vol0, mask_percentile)
    if mask1 is None:
        mask1 = create_fusion_mask(vol1, mask_percentile)

    original_dtype = vol0.dtype

    transform = estimate_camera_transform(
        vol0,
        vol1,
        search_x=search_x,
        search_y=search_y,
    )
    vol1_transformed = apply_camera_transform(vol1, transform)
    mask1_transformed = apply_camera_transform(mask1.astype(np.float32), transform) > 0.5

    # estimate and apply intensity correction (corrects whichever is dimmer)
    correction = estimate_intensity_correction(vol0, vol1_transformed, mask0, mask1_transformed)
    vol0_corrected, vol1_corrected = apply_intensity_correction(vol0, vol1_transformed, correction)

    # compute blending masks
    slice_mask0 = create_slice_mask(vol0_corrected, mask0)
    slice_mask1 = create_slice_mask(vol1_corrected, mask1_transformed)
    avg_mask = create_average_mask(slice_mask0, slice_mask1, mode="overlap")
    avg_mask = remove_mask_anomalies(avg_mask, vol0.shape[0], blending_range)

    # blend (single float->int conversion with rounding at the end)
    fused = blend_views(
        [vol0_corrected, vol1_corrected],
        [avg_mask, avg_mask],
        method=blending_method,
        blending_range=blending_range,
        transition_plane=transition_plane,
        front_flag=front_flag,
        output_dtype=original_dtype,
    )

    params = {
        "transform": transform,
        "correction": correction,
    }

    return fused, params


def _fusion_tp_worker(
    config_dict: dict, timepoint: int,
    estimate_params: bool = True, apply_fusion: bool = True, overwrite: bool = False,
    progress_queue=None, log_queue=None,
) -> dict:
    """top-level worker for parallel timepoint fusion."""
    import shutil
    if log_queue is not None:
        setup_queue_logging(log_queue)
    else:
        setup_logging()
    config = ProcessingConfig.from_dict(config_dict)

    raw_root = config.input_dir
    if config.corrected_suffix and config.corrected_suffix in config.input_dir.name:
        raw_name = config.input_dir.name.replace(config.corrected_suffix, "")
        raw_root = config.input_dir.parent / raw_name

    contents = None
    if raw_root.exists():
        try:
            contents = detect_project_contents(
                raw_root, config.corrected_suffix, config.specimen
            )
        except (ValueError, FileNotFoundError):
            pass

    # read XML metadata for pixel_spacing_z, objective_mag, camera_view_map
    # prefer corrected dir (may have patched objective mag) over raw
    metadata = None
    corrected_spm = config.output_dir / f"SPM{config.specimen:02d}"
    if corrected_spm.exists():
        metadata, _ = read_all_xml_metadata(corrected_spm, config.specimen)
    if not metadata and raw_root.exists():
        metadata, _ = read_all_xml_metadata(raw_root, config.specimen)
    if metadata:
        config.update_from_metadata(metadata)

    tp_start = time.time()
    label = f"TM{timepoint:06d}"
    logger.info(f"Processing timepoint {timepoint}")
    step = {"name": label, "pairs": [], "status": "success"}

    spm_key = f"SPM{config.specimen:02d}"
    input_folder = config.output_dir / spm_key / label
    if not input_folder.exists():
        logger.warning(f"folder not found: {input_folder}, skipping")
        step["status"] = "skipped"
        step["elapsed_seconds"] = round(time.time() - tp_start, 1)
        return step

    output_folder = (
        config.output_dir / "Results" / f"MultiFused_{config.blending_method}"
        / spm_key / label
    )

    tp_info = contents["timepoints"].get(timepoint) if contents else None
    if tp_info and tp_info.get("xml"):
        output_folder.mkdir(parents=True, exist_ok=True)
        for ch, xml_path in tp_info["xml"].items():
            if ch < len(config.camera_pairs):
                c0, c1 = config.camera_pairs[ch]
                vw = config.camera_view_map.get(c0, ch)
                target = output_folder / f"SPM{config.specimen:02d}_{label}_CM{c0:02d}_CM{c1:02d}_VW{vw:02d}.xml"
                if not target.exists():
                    shutil.copy2(xml_path, target)

    corrected = tp_info.get("corrected") if tp_info else None

    try:
        for cam0, cam1 in config.camera_pairs:
            channel = config.camera_view_map.get(cam0, 0)
            logger.info(f"Fusing cameras {cam0} + {cam1} (VW{channel:02d})")
            v0 = corrected["volumes"].get(cam0) if corrected else None
            v1 = corrected["volumes"].get(cam1) if corrected else None
            m0 = corrected["masks"].get(cam0, {}).get("segmentation") if corrected else None
            m1 = corrected["masks"].get(cam1, {}).get("segmentation") if corrected else None
            pair_info = _fuse_camera_pair(
                input_folder, output_folder, config.specimen, label,
                cam0, cam1, channel, config, estimate_params, apply_fusion, overwrite,
                vol0_path=v0, vol1_path=v1, mask0_path=m0, mask1_path=m1,
            )
            step["pairs"].append(pair_info)
            if progress_queue is not None:
                progress_queue.put(("pair_done", cam0, cam1))
    except Exception as e:
        step["status"] = "failed"
        step["error"] = str(e)
        raise
    finally:
        step["elapsed_seconds"] = round(time.time() - tp_start, 1)

    return step


def _fusion_tile_worker(
    config_dict: dict, specimen: int, contents: dict,
    estimate_params: bool = True, apply_fusion: bool = True, overwrite: bool = False,
    progress_queue=None, log_queue=None,
) -> dict:
    """top-level worker for parallel tile fusion."""
    import shutil
    if log_queue is not None:
        setup_queue_logging(log_queue)
    else:
        setup_logging()
    config = ProcessingConfig.from_dict(config_dict)

    tp_start = time.time()
    spm_key = f"SPM{specimen:02d}"
    logger.info(f"Processing {spm_key}")
    step = {"name": spm_key, "pairs": [], "status": "success"}

    # prefer corrected dir XML (may have patched objective mag) over raw
    corrected_spm = config.output_dir / spm_key
    metadata, _ = read_all_xml_metadata(corrected_spm, specimen) if corrected_spm.exists() else ({}, {})
    if not metadata:
        metadata, _ = read_all_xml_metadata(config.input_dir, specimen)
    if metadata and "camera_view_map" in metadata:
        config.camera_view_map = metadata["camera_view_map"]
    if metadata:
        config.update_from_metadata(metadata)

    input_folder = config.output_dir / spm_key
    if not input_folder.exists():
        logger.warning(f"corrected folder not found: {input_folder}, skipping")
        step["status"] = "skipped"
        step["elapsed_seconds"] = round(time.time() - tp_start, 1)
        return step

    output_folder = (
        config.output_dir / "Results" / f"MultiFused_{config.blending_method}" / spm_key
    )

    tile_info = contents["tiles"].get(spm_key, {})
    corrected = tile_info.get("corrected")

    if tile_info.get("xml"):
        output_folder.mkdir(parents=True, exist_ok=True)
        for ch, xml_path in tile_info["xml"].items():
            if ch < len(config.camera_pairs):
                c0, c1 = config.camera_pairs[ch]
                vw = config.camera_view_map.get(c0, ch)
                target = output_folder / f"{spm_key}_CM{c0:02d}_CM{c1:02d}_VW{vw:02d}.xml"
                if not target.exists():
                    shutil.copy2(xml_path, target)

    try:
        for cam0, cam1 in config.camera_pairs:
            channel = config.camera_view_map.get(cam0, 0)
            logger.info(f"Fusing cameras {cam0} + {cam1} (VW{channel:02d})")
            v0 = corrected["volumes"].get(cam0) if corrected else None
            v1 = corrected["volumes"].get(cam1) if corrected else None
            m0 = corrected["masks"].get(cam0, {}).get("segmentation") if corrected else None
            m1 = corrected["masks"].get(cam1, {}).get("segmentation") if corrected else None
            pair_info = _fuse_camera_pair(
                input_folder, output_folder, specimen, "",
                cam0, cam1, channel, config, estimate_params, apply_fusion, overwrite,
                vol0_path=v0, vol1_path=v1, mask0_path=m0, mask1_path=m1,
            )
            step["pairs"].append(pair_info)
            if progress_queue is not None:
                progress_queue.put(("pair_done", cam0, cam1))
    except Exception as e:
        step["status"] = "failed"
        step["error"] = str(e)
        raise
    finally:
        step["elapsed_seconds"] = round(time.time() - tp_start, 1)

    return step


def multi_fuse(
    config: ProcessingConfig,
    estimate_params: bool = True,
    apply_fusion: bool = True,
    overwrite: bool = False,
) -> RunLog:
    """
    Multi-view fusion (matches MATLAB multiFuse / multiFuse_tiled).

    Handles both timepoint mode (TM######) and tiled mode (SPM##).
    Mode is auto-detected from SPC/TM counts in raw data filenames.

    Parameters
    ----------
    config : ProcessingConfig
        Processing configuration with fusion parameters.
        Timepoint mode (multiple TM values):
          - corrected data in output_dir/SPM##/TM######/
        Tiled mode (multiple SPC, single TM):
          - corrected data in output_dir/SPM##/
    estimate_params : bool, default=True
        Estimate transformations and corrections
    apply_fusion : bool, default=True
        Apply fusion and save results
    overwrite : bool, default=False
        Overwrite existing fusion results

    Returns
    -------
    RunLog
        Structured log of the fusion run
    """
    if not config.camera_pairs:
        raise ValueError("No fusion pairs specified. Set camera_pairs.")

    log = RunLog(pipeline="fusion", config_dict=config.to_dict())
    log.start()

    setup_logging()
    print(f"Camera fusion: {config.camera_pairs}")
    print(f"Input: {config.input_dir}")
    print(f"Mode: {'tiled' if config.tiled else 'timepoint'}")
    print(f"Estimate params: {estimate_params}, Apply fusion: {apply_fusion}")
    logger.info(f"Camera fusion: {config.camera_pairs}")

    try:
        if config.tiled:
            _multi_fuse_tiled(config, estimate_params, apply_fusion, overwrite, log)
        else:
            _multi_fuse_timepoints(config, estimate_params, apply_fusion, overwrite, log)
    finally:
        log.finish()
        _save_fusion_config(config, log)

    print("Fusion complete!")
    return log


def _save_fusion_config(config, log) -> None:
    """write fusion results to isoview_config.json."""
    try:
        from .config import CONFIG_FILENAME, IsoviewConfig, config_diff

        cfg_path = config.input_dir.parent / CONFIG_FILENAME
        ic = IsoviewConfig.load_or_create(cfg_path, root=config.input_dir.parent)

        if not ic.paths:
            ic.set_paths(config)

        correction_label = config.corrected_suffix.lstrip(".")
        blending = config.blending_method
        ic.add_fusion(correction_label, blending, config_diff(config), log)
        ic.save(cfg_path)
    except Exception as e:
        logger.warning(f"failed to save isoview_config: {e}")


def _multi_fuse_timepoints(
    config: ProcessingConfig,
    estimate_params: bool,
    apply_fusion: bool,
    overwrite: bool,
    log: RunLog,
) -> None:
    """Timepoint mode: iterate TM###### folders."""
    import shutil

    print(f"Output: {config.output_dir}")

    # scan project for corrected volumes/masks and raw xml
    raw_root = config.input_dir
    if config.corrected_suffix and config.corrected_suffix in config.input_dir.name:
        raw_name = config.input_dir.name.replace(config.corrected_suffix, "")
        raw_root = config.input_dir.parent / raw_name

    contents = None
    if raw_root.exists():
        try:
            contents = detect_project_contents(
                raw_root, config.corrected_suffix, config.specimen
            )
        except (ValueError, FileNotFoundError):
            pass

    # read XML metadata for pixel_spacing_z, objective_mag, camera_view_map
    # prefer corrected dir (may have patched objective mag) over raw
    metadata = None
    corrected_spm = config.output_dir / f"SPM{config.specimen:02d}"
    if corrected_spm.exists():
        metadata, _ = read_all_xml_metadata(corrected_spm, config.specimen)
    if not metadata and raw_root.exists():
        metadata, _ = read_all_xml_metadata(raw_root, config.specimen)
    if metadata:
        config.update_from_metadata(metadata)

    n_timepoints = len(config.timepoints)
    n_pairs = len(config.camera_pairs)
    fusion_log_dir = config.output_dir / "Results" / f"MultiFused_{config.blending_method}"

    if config.workers > 1:
        from concurrent.futures import ProcessPoolExecutor, as_completed
        from multiprocessing import Manager
        config_dict = config.to_dict()
        print(f"parallel mode: {config.workers} workers")
        manager = Manager()
        progress_queue = manager.Queue()
        log_queue = None
        listener = None
        if config.log:
            log_queue = manager.Queue()
            fusion_log_dir.mkdir(parents=True, exist_ok=True)
            listener = start_log_listener(log_queue, fusion_log_dir / "fusion.log")
        logger.info(f"fusion: {n_timepoints} timepoints, {n_pairs} pairs")
        with ProcessPoolExecutor(max_workers=config.workers) as pool:
            futures = {
                pool.submit(
                    _fusion_tp_worker, config_dict, tp,
                    estimate_params, apply_fusion, overwrite, progress_queue, log_queue,
                ): tp
                for tp in config.timepoints
            }
            done_count = 0
            seen = set()
            while done_count < len(futures):
                newly_done = [f for f in futures if f.done() and id(f) not in seen]
                for f in newly_done:
                    seen.add(id(f))
                    done_count += 1
                    tp = futures[f]
                    step = f.result()
                    log.steps.append(step)
                    elapsed = step.get("elapsed_seconds", 0)
                    status = step.get("status", "?")
                    print(f"  TM{tp:06d} {status} ({elapsed}s) [{done_count}/{len(futures)}]")
                if done_count < len(futures):
                    time.sleep(0.5)
        if listener is not None:
            listener.stop()
    else:
        if config.log:
            setup_logging(fusion_log_dir, log_filename="fusion.log")
        logger.info(f"fusion: {n_timepoints} timepoints, {n_pairs} pairs")
        for timepoint in config.timepoints:
            tp_start = time.time()
            label = f"TM{timepoint:06d}"
            logger.info(f"Processing timepoint {timepoint}")

            step = {"name": label, "pairs": [], "status": "success"}

            # corrected input: output_dir/SPM##/TM######/
            spm_key = f"SPM{config.specimen:02d}"
            input_folder = config.output_dir / spm_key / label
            if not input_folder.exists():
                logger.warning(f"folder not found: {input_folder}, skipping")
                step["status"] = "skipped"
                step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                log.steps.append(step)
                continue

            output_folder = (
                config.output_dir / "Results" / f"MultiFused_{config.blending_method}"
                / spm_key / label
            )

            # copy XML files from scan result
            tp_info = contents["timepoints"].get(timepoint) if contents else None
            if tp_info and tp_info.get("xml"):
                output_folder.mkdir(parents=True, exist_ok=True)
                for ch, xml_path in tp_info["xml"].items():
                    if ch < len(config.camera_pairs):
                        c0, c1 = config.camera_pairs[ch]
                        vw = config.camera_view_map.get(c0, ch)
                        target = output_folder / f"SPM{config.specimen:02d}_{label}_CM{c0:02d}_CM{c1:02d}_VW{vw:02d}.xml"
                        if not target.exists():
                            shutil.copy2(xml_path, target)

            # get corrected file paths from scan result
            corrected = tp_info.get("corrected") if tp_info else None

            try:
                for cam0, cam1 in config.camera_pairs:
                    channel = config.camera_view_map.get(cam0, 0)
                    logger.info(f"Fusing cameras {cam0} + {cam1} (VW{channel:02d})")

                    # look up paths from scan result
                    v0 = corrected["volumes"].get(cam0) if corrected else None
                    v1 = corrected["volumes"].get(cam1) if corrected else None
                    m0 = corrected["masks"].get(cam0, {}).get("segmentation") if corrected else None
                    m1 = corrected["masks"].get(cam1, {}).get("segmentation") if corrected else None

                    pair_info = _fuse_camera_pair(
                        input_folder,
                        output_folder,
                        config.specimen,
                        label,
                        cam0,
                        cam1,
                        channel,
                        config,
                        estimate_params,
                        apply_fusion,
                        overwrite,
                        vol0_path=v0,
                        vol1_path=v1,
                        mask0_path=m0,
                        mask1_path=m1,
                    )
                    step["pairs"].append(pair_info)
            except Exception as e:
                step["status"] = "failed"
                step["error"] = str(e)
                raise
            finally:
                step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                log.steps.append(step)


def _multi_fuse_tiled(
    config: ProcessingConfig,
    estimate_params: bool,
    apply_fusion: bool,
    overwrite: bool,
    log: RunLog,
) -> None:
    """Tiled mode: iterate specimens (multiple SPC, single timepoint)."""
    specimens = config.specimens or []
    if not specimens:
        logger.warning(f"No specimens found in {config.input_dir}")
        return

    # scan project for corrected volumes/masks
    contents = detect_project_contents(
        config.input_dir, config.corrected_suffix, config.specimen
    )

    spm_labels = [f"SPM{s:02d}" for s in specimens]
    print(f"Specimens: {spm_labels}")

    n_specimens = len(specimens)
    n_pairs = len(config.camera_pairs)
    fusion_log_dir = config.output_dir / "Results" / f"MultiFused_{config.blending_method}"

    if config.workers > 1:
        from concurrent.futures import ProcessPoolExecutor, as_completed
        from multiprocessing import Manager
        config_dict = config.to_dict()
        print(f"parallel mode: {config.workers} workers")
        manager = Manager()
        progress_queue = manager.Queue()
        log_queue = None
        listener = None
        if config.log:
            log_queue = manager.Queue()
            fusion_log_dir.mkdir(parents=True, exist_ok=True)
            listener = start_log_listener(log_queue, fusion_log_dir / "fusion.log")
        logger.info(f"fusion: {n_specimens} specimens, {n_pairs} pairs")
        with ProcessPoolExecutor(max_workers=config.workers) as pool:
            futures = {
                pool.submit(
                    _fusion_tile_worker, config_dict, spc, contents,
                    estimate_params, apply_fusion, overwrite, progress_queue, log_queue,
                ): spc
                for spc in specimens
            }
            done_count = 0
            seen = set()
            while done_count < len(futures):
                newly_done = [f for f in futures if f.done() and id(f) not in seen]
                for f in newly_done:
                    seen.add(id(f))
                    done_count += 1
                    spc = futures[f]
                    step = f.result()
                    log.steps.append(step)
                    elapsed = step.get("elapsed_seconds", 0)
                    status = step.get("status", "?")
                    print(f"  SPM{spc:02d} {status} ({elapsed}s) [{done_count}/{len(futures)}]")
                if done_count < len(futures):
                    time.sleep(0.5)
        if listener is not None:
            listener.stop()
    else:
        if config.log:
            setup_logging(fusion_log_dir, log_filename="fusion.log")
        logger.info(f"fusion: {n_specimens} specimens, {n_pairs} pairs")
        for spc in specimens:
            tp_start = time.time()
            spm_key = f"SPM{spc:02d}"
            logger.info(f"Processing {spm_key}")

            step = {"name": spm_key, "pairs": [], "status": "success"}

            # read per-specimen XML (prefer corrected dir for patched objective mag)
            corrected_spm = config.output_dir / spm_key
            metadata, _ = read_all_xml_metadata(corrected_spm, spc) if corrected_spm.exists() else ({}, {})
            if not metadata:
                metadata, _ = read_all_xml_metadata(config.input_dir, spc)
            if metadata and "camera_view_map" in metadata:
                config.camera_view_map = metadata["camera_view_map"]
            if metadata:
                config.update_from_metadata(metadata)

            # corrected input: output_dir/SPM##/
            input_folder = config.output_dir / spm_key
            if not input_folder.exists():
                logger.warning(f"corrected folder not found: {input_folder}, skipping")
                step["status"] = "skipped"
                step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                log.steps.append(step)
                continue

            # output: output_dir/Results/MultiFused_<method>/SPM##/
            output_folder = (
                config.output_dir / "Results" / f"MultiFused_{config.blending_method}" / spm_key
            )

            # get corrected file paths from scan result
            tile_info = contents["tiles"].get(spm_key, {})
            corrected = tile_info.get("corrected")

            # copy XML files from scan result
            if tile_info.get("xml"):
                import shutil
                output_folder.mkdir(parents=True, exist_ok=True)
                for ch, xml_path in tile_info["xml"].items():
                    if ch < len(config.camera_pairs):
                        c0, c1 = config.camera_pairs[ch]
                        vw = config.camera_view_map.get(c0, ch)
                        target = output_folder / f"{spm_key}_CM{c0:02d}_CM{c1:02d}_VW{vw:02d}.xml"
                        if not target.exists():
                            shutil.copy2(xml_path, target)

            try:
                for cam0, cam1 in config.camera_pairs:
                    channel = config.camera_view_map.get(cam0, 0)
                    logger.info(f"Fusing cameras {cam0} + {cam1} (VW{channel:02d})")

                    # look up paths from scan result
                    v0 = corrected["volumes"].get(cam0) if corrected else None
                    v1 = corrected["volumes"].get(cam1) if corrected else None
                    m0 = corrected["masks"].get(cam0, {}).get("segmentation") if corrected else None
                    m1 = corrected["masks"].get(cam1, {}).get("segmentation") if corrected else None

                    pair_info = _fuse_camera_pair(
                        input_folder,
                        output_folder,
                        spc,
                        "",
                        cam0,
                        cam1,
                        channel,
                        config,
                        estimate_params,
                        apply_fusion,
                        overwrite,
                        vol0_path=v0,
                        vol1_path=v1,
                        mask0_path=m0,
                        mask1_path=m1,
                    )
                    step["pairs"].append(pair_info)
            except Exception as e:
                step["status"] = "failed"
                step["error"] = str(e)
                raise
            finally:
                step["elapsed_seconds"] = round(time.time() - tp_start, 1)
                log.steps.append(step)


def _fuse_camera_pair(
    input_folder: Path,
    output_folder: Path,
    specimen: int,
    label: str,
    cam0: int,
    cam1: int,
    channel: int,
    config: ProcessingConfig,
    estimate_params: bool,
    apply_fusion: bool,
    overwrite: bool,
    vol0_path: Path | None = None,
    vol1_path: Path | None = None,
    mask0_path: Path | None = None,
    mask1_path: Path | None = None,
) -> dict:
    """Fuse two cameras for a single label (TM000001 or SPM00 etc).

    Returns dict with pair info for RunLog.
    """
    pair_start = time.time()
    pair_info = {
        "cameras": [cam0, cam1],
        "view": channel,
        "status": "success",
        "timings": {},
    }

    output_folder.mkdir(parents=True, exist_ok=True)

    # base filename for all outputs
    spm = f"SPM{specimen:02d}"
    if label:
        base = f"{spm}_{label}_CM{cam0:02d}_CM{cam1:02d}_VW{channel:02d}"
    else:
        base = f"{spm}_CM{cam0:02d}_CM{cam1:02d}_VW{channel:02d}"
    fused_file = output_folder / f"{base}{config.extension}"

    # check all known extensions for existing output
    if not overwrite:
        for ext in [".ome.tif", ".tif", ".tiff", ".klb", ".zarr"]:
            existing = output_folder / f"{base}{ext}"
            if existing.exists():
                logger.info(f"Fusion exists: {existing.name}, skipping")
                pair_info["status"] = "skipped"
                pair_info["elapsed_seconds"] = round(time.time() - pair_start, 1)
                return pair_info

    # input volumes (paths passed from scan result)

    if vol0_path is None:
        logger.warning(f"Camera {cam0} volume not found, skipping")
        pair_info["status"] = "skipped"
        pair_info["error"] = f"camera {cam0} volume not found"
        pair_info["elapsed_seconds"] = round(time.time() - pair_start, 1)
        return pair_info
    if vol1_path is None:
        logger.warning(f"Camera {cam1} volume not found, skipping")
        pair_info["status"] = "skipped"
        pair_info["error"] = f"camera {cam1} volume not found"
        pair_info["elapsed_seconds"] = round(time.time() - pair_start, 1)
        return pair_info

    # load volumes
    t0 = time.time()
    logger.info(f"Loading {vol0_path.name}")
    vol0 = read_volume(vol0_path)
    logger.info(f"Loading {vol1_path.name}")
    vol1 = read_volume(vol1_path)
    pair_info["timings"]["load"] = round(time.time() - t0, 1)
    pair_info["input_shapes"] = [list(vol0.shape), list(vol1.shape)]

    # align second camera: flip-z, rotation, flip-h/v
    if config.flip_z:
        vol1 = np.flip(vol1, axis=0).copy()
        logger.info(f"Flipped cam{cam1} along Z")
    if config.rotation != 0:
        vol1 = rotate_volume(vol1, config.rotation)
        logger.info(f"Rotated cam{cam1} by {config.rotation * 90}deg")
    if config.flip_horizontal or config.flip_vertical:
        vol1 = flip_volume(vol1, config.flip_horizontal, config.flip_vertical)
        logger.info(f"Flipped cam{cam1} h={config.flip_horizontal} v={config.flip_vertical}")

    # remember original dtype for final output conversion
    original_dtype = vol0.dtype

    # load or create masks (paths passed from scan result)
    if mask0_path and mask0_path.exists():
        logger.info(f"Loading mask {mask0_path.name}")
        mask0 = read_volume(mask0_path) > 0
        logger.debug(f"mask0: {mask0.sum()}/{mask0.size} pixels ({100 * mask0.sum() / mask0.size:.1f}%)")
    else:
        logger.info(f"Creating mask for camera {cam0}")
        mask0 = create_fusion_mask(vol0, config.mask_percentile)
        logger.debug(f"mask0: {mask0.sum()}/{mask0.size} pixels ({100 * mask0.sum() / mask0.size:.1f}%)")

    if mask1_path and mask1_path.exists():
        logger.info(f"Loading mask {mask1_path.name}")
        mask1_raw = read_volume(mask1_path)
        # apply same transforms to mask
        if config.flip_z:
            mask1_raw = np.flip(mask1_raw, axis=0).copy()
        if config.rotation != 0:
            mask1_raw = rotate_volume(mask1_raw, config.rotation)
        if config.flip_horizontal or config.flip_vertical:
            mask1_raw = flip_volume(mask1_raw, config.flip_horizontal, config.flip_vertical)
        mask1 = mask1_raw > 0
        logger.debug(f"mask1: {mask1.sum()}/{mask1.size} pixels ({100 * mask1.sum() / mask1.size:.1f}%)")
    else:
        logger.info(f"Creating mask for camera {cam1}")
        mask1 = create_fusion_mask(vol1, config.mask_percentile)
        logger.debug(f"mask1: {mask1.sum()}/{mask1.size} pixels ({100 * mask1.sum() / mask1.size:.1f}%)")

    # estimate registration using camera mode (x/y + rotation)
    t0 = time.time()
    if estimate_params:
        logger.info(f"Estimating transformation cam{cam0} -> cam{cam1}")
        transform = estimate_camera_transform(
            vol0,
            vol1,
            search_x=config.search_offsets_x,
            search_y=config.search_offsets_y,
        )

        logger.info(
            f"Transform: offset=({transform['x_offset']:.2f}, {transform['y_offset']:.2f}), rot={transform['rotation']:.3f}deg, corr={transform['correlation']:.3f}"
        )
    else:
        # would need to load from metadata file - for now just estimate
        transform = estimate_camera_transform(vol0, vol1)
    pair_info["timings"]["register"] = round(time.time() - t0, 1)
    pair_info["transform"] = {
        "x_offset": float(transform["x_offset"]),
        "y_offset": float(transform["y_offset"]),
        "rotation": float(transform["rotation"]),
        "correlation": float(transform["correlation"]),
    }

    if not apply_fusion:
        pair_info["elapsed_seconds"] = round(time.time() - pair_start, 1)
        return pair_info

    logger.info("Applying fusion")

    # apply camera transforms (x/y + rotation per XY slice)
    vol1_transformed = apply_camera_transform(vol1, transform)
    mask1_transformed = apply_camera_transform(mask1.astype(np.float32), transform) > 0.5

    # subtract background from both volumes
    background = estimate_background(vol0, vol1_transformed, config.background_percentile)
    vol0_sub = subtract_background(vol0, background)
    vol1_sub = subtract_background(vol1_transformed, background)
    logger.debug(f"Background: {background:.1f}")

    # intensity correction (applied to whichever camera is dimmer, matching MATLAB)
    correction = estimate_intensity_correction(vol0_sub, vol1_sub, mask0, mask1_transformed)
    logger.debug(f"Intensity: factor={correction['factor']:.3f}, correcting={correction['correct_volume']}")
    vol0_sub, vol1_corrected = apply_intensity_correction(vol0_sub, vol1_sub, correction)
    pair_info["intensity"] = {
        "factor": float(correction["factor"]),
        "background": float(background),
    }

    logger.debug(f"vol0: min={vol0_sub.min()}, max={vol0_sub.max()}, mean={vol0_sub.mean():.1f}")
    logger.debug(f"vol1: min={vol1_corrected.min()}, max={vol1_corrected.max()}, mean={vol1_corrected.mean():.1f}")

    # compute blending masks (Y, X) containing Z-values
    slice_mask0 = create_slice_mask(vol0_sub, mask0)
    slice_mask1 = create_slice_mask(vol1_corrected, mask1_transformed)

    sm0_valid = (slice_mask0 > 0).sum()
    sm1_valid = (slice_mask1 > 0).sum()
    sm0_range = f", range [{slice_mask0[slice_mask0 > 0].min()}-{slice_mask0[slice_mask0 > 0].max()}]" if sm0_valid > 0 else ""
    sm1_range = f", range [{slice_mask1[slice_mask1 > 0].min()}-{slice_mask1[slice_mask1 > 0].max()}]" if sm1_valid > 0 else ""
    logger.debug(f"slice_mask0: {sm0_valid}/{slice_mask0.size} valid{sm0_range}")
    logger.debug(f"slice_mask1: {sm1_valid}/{slice_mask1.size} valid{sm1_range}")

    avg_mask = create_average_mask(slice_mask0, slice_mask1, mode="overlap")

    # auto: estimate blending parameters from tenengrad before mask cleanup
    z_size = vol0.shape[0]
    t0 = time.time()
    if config.blending_method == "auto":
        blend_params = estimate_blend_params(vol0_sub, vol1_corrected)
        logger.info(
            f"Auto blend: crossover_z={blend_params['crossover_z']}, "
            f"blending_range={blend_params['blending_range']}, "
            f"spatial_std={blend_params['spatial_std']:.1f}"
        )
        blending = blend_params["blending_range"]
        pair_info["auto_blend"] = {
            k: v for k, v in blend_params.items() if not k.startswith("tenengrad")
        }

        # save per-Z tenengrad profiles (cam0, cam1, diff) as 2D tiff
        ten_stack = np.stack([
            blend_params["tenengrad_cam0"],
            blend_params["tenengrad_cam1"],
            blend_params["tenengrad_diff"],
        ]).astype(np.float32)
        ten_file = output_folder / f"{base}.tenengrad{config.flat_extension}"
        _write_2d(ten_stack, ten_file, config.compression, config.compression_level)
    else:
        blending = config.blending_range

    # automatically reduce blending if volume is too small
    max_blending = (z_size - 1) // 2
    if blending > max_blending:
        logger.info(f"reduced blending range from {blending} to {max_blending} (z_size={z_size})")
        blending = max_blending

    # remove mask values too close to volume edges for blending
    valid_before = (avg_mask > 0).sum()
    if valid_before > 0:
        valid_vals = avg_mask[avg_mask > 0]
        logger.debug(f"avg mask before anomaly removal: {valid_before}/{avg_mask.size} valid, range [{valid_vals.min()}-{valid_vals.max()}]")
        logger.debug(f"anomaly removal will keep Z values in [{blending}, {z_size - blending}]")
        avg_mask = remove_mask_anomalies(avg_mask, z_size, blending)

    # if mask is empty, use geometric center (or auto crossover Z) as fallback
    valid_after = (avg_mask > 0).sum()
    if valid_after == 0:
        fallback_z = (
            blend_params["crossover_z"] if config.blending_method == "auto" else z_size // 2
        )
        logger.warning(f"Mask empty after anomaly removal! Using fallback Z={fallback_z}")
        avg_mask = np.full((vol0.shape[1], vol0.shape[2]), fallback_z, dtype=np.uint16)

    # empty mask pixels (where only one camera has data, e.g.
    # registration-shifted edges) are left as 0 so adaptive_blending
    # uses view1 directly there, avoiding blending signal with zeros

    valid_mask = avg_mask > 0
    if valid_mask.any():
        logger.debug(f"final mask: {valid_mask.sum()}/{avg_mask.size} valid, range [{avg_mask[valid_mask].min()}-{avg_mask[valid_mask].max()}]")
    else:
        logger.debug(f"final mask: 0/{avg_mask.size} valid")

    # auto always uses adaptive — the specimen mask handles registration
    # edges correctly (geometric would blend zeros at shifted edges)
    effective_method = "adaptive" if config.blending_method == "auto" else config.blending_method

    fused = blend_views(
        [vol0_sub, vol1_corrected],
        [avg_mask, avg_mask],
        method=effective_method,
        blending_range=blending,
        transition_plane=config.transition_plane,
        front_flag=config.front_flag,
        output_dtype=original_dtype,
    )
    pair_info["timings"]["fuse"] = round(time.time() - t0, 1)
    pair_info["output_shape"] = list(fused.shape)

    # debug: fused volume statistics
    logger.debug(f"Fused: min={fused.min()}, max={fused.max()}, mean={fused.mean():.1f}")

    # save fused volume with ome metadata
    t0 = time.time()
    write_volume(
        fused,
        fused_file,
        pixel_spacing=config.pixel_spacing,
        compression=config.compression,
        compression_level=config.compression_level,
        pyramid=config.pyramid,
        pyramid_max_layers=config.pyramid_max_layers,
    )
    logger.info(f"Saved fused: {fused_file.name}")

    # save projections (XY, XZ, YZ max projections) - 2D outputs
    proj_xy = fused.max(axis=0)  # Z projection -> (Y, X)
    proj_xz = fused.max(axis=1)  # Y projection -> (Z, X)
    proj_yz = fused.max(axis=2)  # X projection -> (Z, Y)

    proj_xy_file = output_folder / f"{base}.xyProjection{config.flat_extension}"
    proj_xz_file = output_folder / f"{base}.xzProjection{config.flat_extension}"
    proj_yz_file = output_folder / f"{base}.yzProjection{config.flat_extension}"

    _write_2d(proj_xy, proj_xy_file, config.compression, config.compression_level)
    _write_2d(proj_xz, proj_xz_file, config.compression, config.compression_level)
    _write_2d(proj_yz, proj_yz_file, config.compression, config.compression_level)

    # save 2D masks
    if label:
        cam0_base = f"{spm}_{label}_CM{cam0:02d}_VW{channel:02d}"
        cam1_base = f"{spm}_{label}_CM{cam1:02d}_VW{channel:02d}"
    else:
        cam0_base = f"{spm}_CM{cam0:02d}_VW{channel:02d}"
        cam1_base = f"{spm}_CM{cam1:02d}_VW{channel:02d}"
    _write_2d(
        slice_mask0.astype(np.uint16),
        output_folder / f"{cam0_base}.mask2D{config.flat_extension}",
        config.compression,
        config.compression_level,
    )
    _write_2d(
        slice_mask1.astype(np.uint16),
        output_folder / f"{cam1_base}.mask2D{config.flat_extension}",
        config.compression,
        config.compression_level,
    )
    _write_2d(
        slice_mask1.astype(np.uint16),
        output_folder / f"{cam1_base}.transformedMask2D{config.flat_extension}",
        config.compression,
        config.compression_level,
    )

    # save fusion mask (blending boundary)
    fusion_mask_file = output_folder / f"{base}.fusionMask{config.flat_extension}"
    _write_2d(
        avg_mask.astype(np.uint16), fusion_mask_file, config.compression, config.compression_level
    )

    # save combined 3D mask
    combined_mask = mask0.astype(np.uint8) | mask1_transformed.astype(np.uint8)
    mask_file = output_folder / f"{base}.mask{config.extension}"
    write_volume(
        combined_mask,
        mask_file,
        compression=config.compression,
        compression_level=config.compression_level,
        pyramid=config.pyramid,
        pyramid_max_layers=config.pyramid_max_layers,
    )

    pair_info["timings"]["save"] = round(time.time() - t0, 1)
    pair_info["elapsed_seconds"] = round(time.time() - pair_start, 1)

    logger.info("Saved intermediates: projections, masks, parameters")
    return pair_info


def estimate_blend_params(vol0, vol1, ds=4, smooth_sigma=5, strip_w=64):
    """estimate fusion parameters from tenengrad sharpness analysis.

    computes per-Z tenengrad for both volumes, finds the crossover Z
    (where the sharper camera switches), estimates blending_range from
    the FWHM of the transition, and checks spatial variability to
    decide between adaptive and geometric blending.

    Parameters
    ----------
    vol0, vol1 : ndarray
        volumes to fuse, shape (Z, Y, X)
    ds : int
        spatial downsample factor for speed
    smooth_sigma : float
        gaussian smoothing sigma for Z-profiles
    strip_w : int
        width of X-strips for spatial variability analysis

    Returns
    -------
    dict with keys: method, transition_plane, blending_range,
    crossover_z, spatial_std
    """
    nz = vol0.shape[0]

    # per-Z tenengrad (downsampled for speed)
    ten0 = np.zeros(nz, dtype=np.float64)
    ten1 = np.zeros(nz, dtype=np.float64)
    for zi in range(nz):
        for src, out in [(vol0, ten0), (vol1, ten1)]:
            slc = src[zi, ::ds, ::ds].astype(np.float32)
            gx = cv2.Sobel(slc, cv2.CV_32F, 1, 0, ksize=3)
            gy = cv2.Sobel(slc, cv2.CV_32F, 0, 1, ksize=3)
            out[zi] = float(np.mean(gx**2 + gy**2))

    # smooth and find crossover
    s0 = gaussian_filter1d(ten0, smooth_sigma)
    s1 = gaussian_filter1d(ten1, smooth_sigma)
    lo, hi = min(s0.min(), s1.min()), max(s0.max(), s1.max())
    rng = hi - lo if hi > lo else 1
    diff = (s0 - lo) / rng - (s1 - lo) / rng

    sc = np.where(np.diff(np.sign(diff)))[0]
    if len(sc) != 1:
        # no clean crossover — fallback to geometric center
        return {
            "method": "geometric",
            "transition_plane": nz // 2,
            "blending_range": 20,
            "crossover_z": nz // 2,
            "spatial_std": 0.0,
            "tenengrad_cam0": s0,
            "tenengrad_cam1": s1,
            "tenengrad_diff": diff,
        }

    crossover_z = int(sc[0])

    # blending_range from FWHM of derivative peak
    abs_deriv = gaussian_filter1d(np.abs(np.gradient(diff)), smooth_sigma)
    peak = abs_deriv.max()
    blending_range = 20
    if peak > 0:
        above = np.where(abs_deriv > peak / 2)[0]
        near = above[np.abs(above - crossover_z) < 80]
        if len(near) > 1:
            blending_range = max(10, min(int(near[-1] - near[0]), nz // 4))

    # spatial variability via X-strips
    nx = vol0.shape[2]
    n_strips = nx // strip_w
    strip_crosses = []
    for si in range(n_strips):
        x0 = si * strip_w
        st0 = np.zeros(nz)
        st1 = np.zeros(nz)
        for zi in range(nz):
            for src, out in [(vol0, st0), (vol1, st1)]:
                strip = src[zi, ::ds, x0 : x0 + strip_w].astype(np.float32)
                gx = cv2.Sobel(strip, cv2.CV_32F, 1, 0, ksize=3)
                gy = cv2.Sobel(strip, cv2.CV_32F, 0, 1, ksize=3)
                out[zi] = float(np.mean(gx**2 + gy**2))
        ss0 = gaussian_filter1d(st0, smooth_sigma)
        ss1 = gaussian_filter1d(st1, smooth_sigma)
        lo_s, hi_s = min(ss0.min(), ss1.min()), max(ss0.max(), ss1.max())
        rng_s = hi_s - lo_s if hi_s > lo_s else 1
        sdiff = (ss0 - lo_s) / rng_s - (ss1 - lo_s) / rng_s
        sc_s = np.where(np.diff(np.sign(sdiff)))[0]
        if len(sc_s) > 0:
            strip_crosses.append(int(np.median(sc_s)))

    spatial_std = float(np.std(strip_crosses)) if len(strip_crosses) > 2 else 0.0
    method = "adaptive" if spatial_std > 15 else "geometric"

    return {
        "method": method,
        "transition_plane": crossover_z,
        "blending_range": blending_range,
        "crossover_z": crossover_z,
        "spatial_std": spatial_std,
        "tenengrad_cam0": s0,
        "tenengrad_cam1": s1,
        "tenengrad_diff": diff,
    }


def blend_views(
    views: list[np.ndarray],
    masks: list[np.ndarray],
    method: Literal["adaptive", "geometric", "average", "auto"] = "adaptive",
    blending_range: int = 20,
    transition_plane: int | None = None,
    front_flag: int = 1,
    output_dtype: np.dtype | None = None,
    **kwargs,
) -> np.ndarray:
    """
    Blend multiple views into single fused volume.

    Parameters
    ----------
    views : list of ndarray
        Volumes to fuse, all same shape (Z, Y, X)
    masks : list of ndarray
        Binary masks or transition planes (Y, X) with Z-values
    method : str, default='adaptive'
        Fusion method: 'auto', 'adaptive', 'geometric', 'average'
    blending_range : int, default=20
        Transition zone width in pixels
    transition_plane : int or None, default=None
        For geometric method, Z-index of transition, None uses center
    front_flag : int, default=1
        Which view is dominant in front (low Z). 1=view1, 2=view2
    output_dtype : dtype or None
        Final output dtype. If integer, rounds before conversion to avoid
        truncation artifacts. None keeps the blending float32 output as-is.

    Returns
    -------
    ndarray
        Fused volume (Z, Y, X)
    """
    if len(views) != 2:
        raise ValueError("Currently only 2-view fusion is supported")

    if method == "auto":
        params = estimate_blend_params(views[0], views[1])
        logger.info(
            f"Auto blend: method={params['method']}, "
            f"crossover_z={params['crossover_z']}, "
            f"blending_range={params['blending_range']}, "
            f"spatial_std={params['spatial_std']:.1f}"
        )
        if params["method"] == "adaptive":
            fused = adaptive_blending(
                views[0], views[1], masks[0], params["blending_range"], front_flag
            )
        else:
            fused = geometric_blending(
                views[0], views[1], params["transition_plane"], params["blending_range"], front_flag
            )
    elif method == "adaptive":
        fused = adaptive_blending(views[0], views[1], masks[0], blending_range, front_flag)
    elif method == "geometric":
        fused = geometric_blending(views[0], views[1], transition_plane, blending_range, front_flag)
    elif method == "average":
        fused = average_fusion(views[0], views[1])
    else:
        raise ValueError(f"Unknown fusion method: {method}")

    # single final dtype conversion with proper rounding
    if output_dtype is not None and fused.dtype != output_dtype:
        if np.issubdtype(output_dtype, np.integer):
            dtype_info = np.iinfo(output_dtype)
            fused = np.clip(fused, dtype_info.min, dtype_info.max)
            np.round(fused, out=fused)
        fused = fused.astype(output_dtype)

    return fused


def adaptive_blending(view1, view2, mask, blending_range=20, front_flag=1):
    """
    Adaptive blending with smooth linear transition along Z axis.

    Matches MATLAB multiFuse: first stitches a hard-cut volume (view1 for
    z <= transition, view2 for z > transition), then overwrites only the
    blending zone with weighted sums. pixels where mask==0 keep the
    stitched value (view1 by default), avoiding the half-brightness
    artifact from averaging signal with zero-padded edges.

    Parameters
    ----------
    view1 : ndarray
        Reference view (Z, Y, X)
    view2 : ndarray
        Transformed view (Z, Y, X)
    mask : ndarray
        Transition plane topology (Y, X) containing Z-indices
    blending_range : int, default=20
        Width of blending zone in Z-planes
    front_flag : int, default=1
        Which view is dominant in front (low Z). 1=view1, 2=view2

    Returns
    -------
    ndarray
        Fused volume (Z, Y, X)

    Notes
    -----
    matlab convention: mask[y,x] contains the z-plane where transition occurs.
    front_flag controls which view dominates in the "front" (low z values).
    """
    Z, Y, X = view1.shape

    # swap views if front_flag == 2 (view2 should be in front)
    if front_flag == 2:
        view1, view2 = view2, view1

    # step 1: stitch — hard cut at transition plane (matches MATLAB)
    # where mask>0: view1 for z<=mask, view2 for z>mask
    # where mask==0: view1 only (no blending with zero-padded edges)
    mask_i = mask.astype(np.int32)
    z_grid = np.arange(Z, dtype=np.int32).reshape(Z, 1, 1)
    valid = mask_i > 0
    v1 = view1.astype(np.float32)
    v2 = view2.astype(np.float32)
    fused = v1.copy()
    back_region = valid & (z_grid > mask_i)
    fused[back_region] = v2[back_region]

    # step 2: blend — smooth the transition zone (only where mask>0)
    # front: z in [mask-br+1, mask], back: z in [mask+1, mask+br]
    # matches MATLAB linspace weights exactly
    br = blending_range
    w1_front = np.linspace(1.0, 0.5, br, dtype=np.float32)  # view1: 1.0 -> 0.5
    w2_front = np.linspace(0.0, 0.5, br, dtype=np.float32)  # view2: 0.0 -> 0.5
    w1_back = np.linspace(0.5, 0.0, br, dtype=np.float32)   # view1: 0.5 -> 0.0
    w2_back = np.linspace(0.5, 1.0, br, dtype=np.float32)   # view2: 0.5 -> 1.0

    # front blend zone
    for i in range(br):
        zi_off = i - br + 1  # -(br-1), ..., 0
        z_actual = mask_i + zi_off
        in_bounds = valid & (z_actual >= 0) & (z_actual < Z)
        if not in_bounds.any():
            continue
        ys, xs = np.where(in_bounds)
        zs = z_actual[ys, xs]
        fused[zs, ys, xs] = v1[zs, ys, xs] * w1_front[i] + v2[zs, ys, xs] * w2_front[i]

    # back blend zone
    for i in range(br):
        zi_off = i + 1  # 1, ..., br
        z_actual = mask_i + zi_off
        in_bounds = valid & (z_actual >= 0) & (z_actual < Z)
        if not in_bounds.any():
            continue
        ys, xs = np.where(in_bounds)
        zs = z_actual[ys, xs]
        fused[zs, ys, xs] = v1[zs, ys, xs] * w1_back[i] + v2[zs, ys, xs] * w2_back[i]

    return fused


def geometric_blending(view1, view2, transition_plane=None, blending_range=20, front_flag=1):
    """
    Geometric blending with fixed transition plane.

    Parameters
    ----------
    view1 : ndarray
        Reference view (Z, Y, X)
    view2 : ndarray
        Transformed view (Z, Y, X)
    transition_plane : int or None, default=None
        Z-index of transition, None uses center
    blending_range : int, default=20
        Width of blending zone in z-planes
    front_flag : int, default=1
        Which view is dominant in front (low Z). 1=view1, 2=view2

    Returns
    -------
    ndarray
        Fused volume (Z, Y, X)
    """
    Z, Y, X = view1.shape
    if transition_plane is None:
        transition_plane = Z // 2
    mask = np.full((Y, X), transition_plane, dtype=np.int32)
    return adaptive_blending(view1, view2, mask, blending_range, front_flag)


def average_fusion(view1, view2):
    """
    Simple arithmetic average of two views.

    Parameters
    ----------
    view1 : ndarray
        Reference view (Z, Y, X)
    view2 : ndarray
        Transformed view (Z, Y, X)

    Returns
    -------
    ndarray
        Fused volume (Z, Y, X), fused = (view1 + view2) / 2
    """
    return ((view1.astype(np.float32) + view2.astype(np.float32)) / 2).astype(view1.dtype)
