"""CLI entry point for isoview."""

import argparse
import sys


def _add_init_parser(subparsers):
    """register the 'init' subcommand."""
    p = subparsers.add_parser(
        "init",
        help="scaffold pipeline scripts for a dataset",
    )
    p.add_argument(
        "path",
        help="path to raw data directory",
    )
    p.set_defaults(func=_run_init)


def _run_init(args):
    from pathlib import Path
    from isoview.commands.init import init_pipeline

    scripts_dir = init_pipeline(Path(args.path))
    print(f"created pipeline scripts in {scripts_dir}")
    print(f"  correct_stack.py")
    print(f"  multi_fuse.py")


def _add_view_parser(subparsers):
    """register the 'view' (GUI) subcommand."""
    p = subparsers.add_parser("view", help="launch multiview GUI viewer")
    p.add_argument(
        "path",
        nargs="?",
        default=None,
        help="path to data directory (raw, .corrected, or parent)",
    )
    p.add_argument(
        "--stage", "-s",
        choices=["raw", "corrected", "fused"],
        default="raw",
        help="processing stage to view (default: raw)",
    )
    p.add_argument(
        "--specimen",
        type=int,
        default=0,
        help="specimen index (default: 0)",
    )
    p.add_argument(
        "--timepoint", "-t",
        type=int,
        default=None,
        help="initial timepoint/tile index (default: first available)",
    )
    p.add_argument(
        "--cameras", "-c",
        type=int,
        nargs="+",
        default=None,
        help="camera indices to display (default: auto-detect)",
    )
    p.set_defaults(func=_run_view)


def _run_view(args):
    if args.path is None:
        print("error: path is required for view command", file=sys.stderr)
        sys.exit(1)

    from isoview.gui import run_multiview_gui

    run_multiview_gui(
        path=args.path,
        specimen=args.specimen,
        cameras=args.cameras,
        timepoint=args.timepoint,
        stage=args.stage,
    )


def _add_tiff2wk_parser(subparsers):
    """register the 'tiff2wk' subcommand."""
    p = subparsers.add_parser(
        "tiff2wk",
        help="convert OME-TIFF to webknossos-compatible zarr v3",
    )
    p.add_argument(
        "input",
        help="input .ome.tif or .tif file (ZYX uint16)",
    )
    p.add_argument(
        "output",
        nargs="?",
        default=None,
        help="output directory (default: <input_stem>_wk/)",
    )
    p.add_argument(
        "--layer", "-l",
        default="raw",
        help="layer name in datasource-properties.json (default: raw)",
    )
    p.add_argument(
        "--name", "-n",
        default=None,
        help="dataset name (default: output directory name)",
    )
    p.add_argument(
        "--chunks",
        type=int,
        default=64,
        help="inner chunk size in voxels (default: 64)",
    )
    p.add_argument(
        "--shard-xy",
        type=int,
        default=512,
        help="shard size for X and Y axes (default: 512)",
    )
    p.add_argument(
        "--shard-z",
        type=int,
        default=64,
        help="shard size for Z axis (default: 64)",
    )
    p.add_argument(
        "--compression-level",
        type=int,
        default=5,
        help="zstd compression level (default: 5)",
    )
    p.add_argument(
        "--max-levels",
        type=int,
        default=5,
        help="max additional pyramid levels (default: 5)",
    )
    p.add_argument(
        "--no-pyramid",
        action="store_true",
        help="skip pyramid generation",
    )
    p.add_argument(
        "--spacing",
        type=float,
        nargs=3,
        metavar=("Z", "Y", "X"),
        default=None,
        help="override pixel spacing in micrometers (Z Y X). "
             "default: read from OME-TIFF metadata",
    )
    p.set_defaults(func=_run_tiff2wk)


def _run_tiff2wk(args):
    from isoview.commands.tiff2wk import tiff2wk
    tiff2wk(args)


def main():
    parser = argparse.ArgumentParser(
        prog="isoview",
        description="multiview light sheet microscopy toolkit",
    )
    subparsers = parser.add_subparsers(dest="command")

    _add_init_parser(subparsers)
    _add_view_parser(subparsers)
    _add_tiff2wk_parser(subparsers)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
