"""Isoview: multi-view light sheet microscopy processing pipeline."""

from .config import ProcessingConfig, DEFAULT_CAMERA_PAIRS, DEFAULT_CAMERA_VIEW_MAP
from .pipeline import IsoviewProcessor, RunLog, correct_stack
from .fusion import multi_fuse, fuse_views, orient_view, blend_views, estimate_blend_params
from .config import IsoviewConfig
from .transforms import (
    estimate_camera_transform,
    apply_camera_transform,
    gradient_descent_optimize,
)
from . import viz
from .io import read_volume, LazyVolume, detect_mode, detect_project_contents

__version__ = "0.1.0"

__all__ = [
    "ProcessingConfig",
    "DEFAULT_CAMERA_PAIRS",
    "DEFAULT_CAMERA_VIEW_MAP",
    "IsoviewProcessor",
    "RunLog",
    "correct_stack",
    "multi_fuse",
    "fuse_views",
    "orient_view",
    "blend_views",
    "estimate_blend_params",
    "estimate_camera_transform",
    "apply_camera_transform",
    "gradient_descent_optimize",
    "viz",
    "read_volume",
    "LazyVolume",
    "detect_mode",
    "detect_project_contents",
    "IsoviewConfig",
]
