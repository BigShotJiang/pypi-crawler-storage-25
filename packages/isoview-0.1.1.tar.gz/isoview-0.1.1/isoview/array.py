"""IsoviewArray - re-exported from mbo_utilities for backwards compatibility."""

try:
    from mbo_utilities.arrays.isoview import IsoviewArray
except ImportError:
    raise ImportError(
        "IsoviewArray requires mbo_utilities. Install with: "
        "pip install mbo_utilities[isoview]"
    )

__all__ = ["IsoviewArray"]
