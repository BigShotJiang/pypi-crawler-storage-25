"""logging setup for isoview pipeline."""

import logging
import logging.handlers
from pathlib import Path

_LOG_FMT = "%(asctime)s %(levelname)-5s %(name)s  %(message)s"
_LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

_configured_files: set[str] = set()


class _StderrHandler(logging.StreamHandler):
    """stderr handler for WARNING+ messages."""

    def __init__(self):
        super().__init__()
        self.setLevel(logging.WARNING)
        self.setFormatter(logging.Formatter("  %(levelname)s: %(message)s"))


def _ensure_stderr_handler(logger: logging.Logger) -> None:
    """attach stderr handler if not already present."""
    if not any(isinstance(h, _StderrHandler) for h in logger.handlers):
        logger.addHandler(_StderrHandler())


def setup_logging(
    log_dir: Path | None = None,
    name: str = "isoview",
    log_filename: str | None = None,
) -> logging.Logger:
    """configure file + stderr logging.

    Args:
        log_dir: directory for log file. None = stderr handler only (no file).
        name: logger name.
        log_filename: log file name. defaults to f"{name}.log".
    """
    root = logging.getLogger(name)
    root.setLevel(logging.DEBUG)
    _ensure_stderr_handler(root)

    if log_dir is not None:
        log_dir = Path(log_dir)
        filename = log_filename or f"{name}.log"
        log_path = log_dir / filename
        file_key = str(log_path.resolve())
        if file_key not in _configured_files:
            log_dir.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(logging.Formatter(_LOG_FMT, datefmt=_LOG_DATEFMT))
            root.addHandler(fh)
            _configured_files.add(file_key)

    return root


def setup_queue_logging(queue, name: str = "isoview") -> logging.Logger:
    """configure worker process to send log records via queue.

    used in parallel workers so the main process can safely write
    all records to a single file without data races.
    """
    root = logging.getLogger(name)
    root.setLevel(logging.DEBUG)
    _ensure_stderr_handler(root)

    if not any(isinstance(h, logging.handlers.QueueHandler) for h in root.handlers):
        root.addHandler(logging.handlers.QueueHandler(queue))

    return root


def start_log_listener(
    queue,
    log_path: Path,
) -> logging.handlers.QueueListener:
    """start a QueueListener that drains worker log records to a file.

    call listener.stop() after all workers are done.
    """
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_LOG_FMT, datefmt=_LOG_DATEFMT))
    listener = logging.handlers.QueueListener(queue, fh, respect_handler_level=True)
    listener.start()
    return listener
