"""Intensity correction estimation and application for multi-view fusion."""

import numpy as np
from typing import Literal

from .corrections import percentile_interp


def estimate_background(
    view1: np.ndarray,
    view2: np.ndarray,
    percentile: float = 5.0,
    subsample: int = 100
) -> float:
    """
    Estimate combined background from two views.

    Parameters
    ----------
    view1 : ndarray
        First view (Z, Y, X)
    view2 : ndarray
        Second view (Z, Y, X)
    percentile : float, default=5.0
        Percentile for background estimation
    subsample : int, default=100
        Subsampling factor (use every Nth pixel)

    Returns
    -------
    float
        Background intensity value
    """
    # subsample (flatten and take every Nth)
    flat1 = view1.ravel()[::subsample]
    flat2 = view2.ravel()[::subsample]

    # combine nonzero pixels from both views
    valid1 = flat1[flat1 > 0]
    valid2 = flat2[flat2 > 0]
    combined = np.concatenate([valid1, valid2])

    if len(combined) == 0:
        return 0.0

    return float(percentile_interp(combined.astype(np.float64), percentile))


def subtract_background(
    volume: np.ndarray,
    background: float
) -> np.ndarray:
    """
    Subtract background from volume, clipping to zero.

    Parameters
    ----------
    volume : ndarray
        Input volume (Z, Y, X)
    background : float
        Background value to subtract

    Returns
    -------
    ndarray
        Background-subtracted volume as float32. Stays in float to avoid
        truncation artifacts from repeated float->int conversions mid-pipeline.
    """
    result = volume.astype(np.float32) - background
    result = np.maximum(result, 0)

    return result



def estimate_intensity_correction(
    ref_volume: np.ndarray,
    moving_volume: np.ndarray,
    ref_mask: np.ndarray,
    moving_mask: np.ndarray,
    percentile: float = 5.0,
    method: Literal["percentile_ratio", "mean_ratio"] = "percentile_ratio"
) -> dict:
    """
    Estimate intensity correction factor between two views.

    Expects already background-subtracted volumes. Matches MATLAB behavior:
    compares total intensity in overlap region, corrects whichever camera
    is dimmer (factor always >= 1).

    Returns
    -------
    dict with 'factor' (>= 1.0), 'correct_volume' ('reference', 'moving',
    or 'none'), 'overlap_correlation', 'method'.
    """
    if method == "percentile_ratio":
        return _estimate_correction_percentile(
            ref_volume, moving_volume, ref_mask, moving_mask, percentile
        )
    elif method == "mean_ratio":
        return _estimate_correction_mean(
            ref_volume, moving_volume, ref_mask, moving_mask
        )
    else:
        raise ValueError(f"Unknown method: {method}")


def _estimate_correction_percentile(
    ref_volume: np.ndarray,
    moving_volume: np.ndarray,
    ref_mask: np.ndarray,
    moving_mask: np.ndarray,
    percentile: float
) -> dict:
    """
    Estimate correction factor between two views.

    Matches MATLAB: computes sum of positive voxels in overlap region,
    always corrects whichever camera is dimmer (factor >= 1).
    Expects already background-subtracted volumes from the caller.
    """
    # overlap only: compare intensities where both cameras have signal
    valid = (ref_mask > 0) & (moving_mask > 0) & (ref_volume > 0) & (moving_volume > 0)
    ref_valid = ref_volume[valid]
    mov_valid = moving_volume[valid]

    if len(ref_valid) == 0 or len(mov_valid) == 0:
        return {
            'factor': 1.0,
            'correct_volume': 'none',
            'overlap_correlation': 0.0,
            'method': 'percentile_ratio',
        }

    # sum positive voxels (volumes already background-subtracted by caller)
    ref_sum = np.sum(ref_valid, dtype=np.float64)
    mov_sum = np.sum(mov_valid, dtype=np.float64)

    if mov_sum == 0 or ref_sum == 0:
        return {
            'factor': 1.0,
            'correct_volume': 'none',
            'overlap_correlation': 0.0,
            'method': 'percentile_ratio',
        }

    # MATLAB: always correct the dimmer volume, factor always >= 1
    if ref_sum > mov_sum:
        factor = ref_sum / mov_sum
        correct_volume = 'moving'
    else:
        factor = mov_sum / ref_sum
        correct_volume = 'reference'

    # correlation on subsampled overlap (avoid multi-GiB float64 allocation)
    step = max(1, len(ref_valid) // 500_000)
    r_sub = ref_valid[::step].astype(np.float64)
    m_sub = mov_valid[::step].astype(np.float64)
    r_mean, m_mean = r_sub.mean(), m_sub.mean()
    r_dev, m_dev = r_sub - r_mean, m_sub - m_mean
    denom = np.sqrt((r_dev ** 2).sum() * (m_dev ** 2).sum())
    correlation = float((r_dev * m_dev).sum() / denom) if denom > 0 else 0.0

    return {
        'factor': float(factor),
        'correct_volume': correct_volume,
        'overlap_correlation': correlation,
        'method': 'percentile_ratio',
    }


def _estimate_correction_mean(
    ref_volume: np.ndarray,
    moving_volume: np.ndarray,
    ref_mask: np.ndarray,
    moving_mask: np.ndarray
) -> dict:
    """
    Simple mean ratio correction.

    Matches MATLAB: corrects whichever camera is dimmer, factor >= 1.
    Expects already background-subtracted volumes.
    """
    overlap_mask = (ref_mask > 0) & (moving_mask > 0) & \
                   (ref_volume > 0) & (moving_volume > 0)

    if overlap_mask.sum() == 0:
        return {
            'factor': 1.0,
            'correct_volume': 'none',
            'overlap_correlation': 0.0,
            'method': 'mean_ratio',
        }

    ref_overlap = ref_volume[overlap_mask]
    moving_overlap = moving_volume[overlap_mask]

    ref_mean = float(np.mean(ref_overlap, dtype=np.float64))
    moving_mean = float(np.mean(moving_overlap, dtype=np.float64))

    # MATLAB: always correct the dimmer volume, factor always >= 1
    if ref_mean > moving_mean and moving_mean > 0:
        factor = ref_mean / moving_mean
        correct_volume = 'moving'
    elif moving_mean > ref_mean and ref_mean > 0:
        factor = moving_mean / ref_mean
        correct_volume = 'reference'
    else:
        factor = 1.0
        correct_volume = 'none'

    step = max(1, len(ref_overlap) // 500_000)
    r_sub = ref_overlap[::step].astype(np.float64)
    m_sub = moving_overlap[::step].astype(np.float64)
    r_mean, m_mean = r_sub.mean(), m_sub.mean()
    r_dev, m_dev = r_sub - r_mean, m_sub - m_mean
    denom = np.sqrt((r_dev ** 2).sum() * (m_dev ** 2).sum())
    correlation = float((r_dev * m_dev).sum() / denom) if denom > 0 else 0.0

    return {
        'factor': float(factor),
        'correct_volume': correct_volume,
        'overlap_correlation': float(correlation),
        'method': 'mean_ratio',
    }


def apply_intensity_correction(
    ref_volume: np.ndarray,
    moving_volume: np.ndarray,
    correction: dict
) -> tuple[np.ndarray, np.ndarray]:
    """
    Apply intensity correction to whichever volume is dimmer.

    Matches MATLAB: always multiplies the dimmer volume up by factor >= 1.
    correction['correct_volume'] indicates which one ('reference' or 'moving').

    Returns
    -------
    tuple of (ref_corrected, moving_corrected)
        Both as float32. The brighter one is unchanged, the dimmer one
        is multiplied by factor.
    """
    factor = correction['factor']
    target = correction.get('correct_volume', 'moving')

    ref_out = ref_volume.astype(np.float32)
    mov_out = moving_volume.astype(np.float32)

    if target == 'moving':
        mov_out = mov_out * factor
    elif target == 'reference':
        ref_out = ref_out * factor

    return ref_out, mov_out


