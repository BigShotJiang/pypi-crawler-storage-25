% run_clusterPT_gaussian_gridsearch.m - run clusterPT with multiple gaussian sigma values
% runs only the first processing step (no fusion), cameras 0+1, no cropping
%
% usage:
%   matlab -batch "cd('c:/Users/RBO/repos/isoview/matlab'); run_clusterPT_gaussian_gridsearch"
%   or run interactively from MATLAB

addpath('C:\Users\RBO\repos\IsoView-Processing\src');

inputFolder = 'E:\isoview\Dme_E1_57C10_GCaMP6s_Simultaneous_6p22_20150528_163012';

% run with multiple gaussian sigma values for comparison
sigmaValues = [1.0, 2.0, 3.0, 5.0];

specimen   = 0;
timepoints = 0;
cameras    = [0 1];
channels   = 1;

% no cropping
startsLeft  = [];
startsTop   = [];
widths      = [];
heights     = [];
startsFront = [];
depths      = [];
dimensions  = [];

inputType   = 3;  % unstructured (flat directory)
outputType  = 0;  % KLB output
correctTIFF = 0;

segmentFlag  = 1;  % segment + mask
rotationFlag = 1;  % 90 degrees clockwise
flipHFlag    = 0;
flipVFlag    = 0;

medianRange = [3 3];
percentile  = [1 5 100];

splitting   = 10;
kernelSize  = 5;
% kernelSigma will be set per iteration

% voxel spacing
pixelSpacingZ = 0.40625;
detectionObjectiveMagnification = 16;
pixelSpacingCamera = 6.5;
pixelSpacingXY = pixelSpacingCamera / detectionObjectiveMagnification;
pixelSpacing   = [pixelSpacingXY, pixelSpacingXY, pixelSpacingZ, 1, 1];
scaling        = pixelSpacingZ / pixelSpacingXY;

references  = [];
dependents  = [];
thresholds  = [0.5 0.5];  % fixed threshold

loggingFlag = 0;
verbose     = 1;

localRun   = [1 0];
jobMemory  = [1 0];

%% loop over sigma values

for si = 1:length(sigmaValues)
    kernelSigma = sigmaValues(si);
    sigStr = strrep(sprintf('%.1f', kernelSigma), '.', 'p');  % 1.0 -> 1p0

    fprintf('\n=== Running with sigma = %.1f ===\n\n', kernelSigma);

    % output folder with sigma suffix (mat subfolder to avoid overwriting python)
    outputLabel = ['mat\output_sigma-' sigStr];
    projectionFolder = [inputFolder '.projections\' outputLabel];
    outputFolder = [inputFolder '.corrected\' outputLabel];
    globalMaskFolder = [inputFolder '.globalMask\' outputLabel];

    if exist(outputFolder, 'dir') ~= 7
        mkdir(outputFolder);
    end
    if exist(projectionFolder, 'dir') ~= 7
        mkdir(projectionFolder);
    end

    switch outputType
        case 0
            outputExtension = '.klb';
        case 1
            outputExtension = '.jp2';
        case 2
            outputExtension = '.tif';
    end

    % read background files
    if inputType == 0 || inputType == 2 || inputType == 3 || inputType == 4
        backgroundFiles = dir([inputFolder '\*.tif']);
    else
        backgroundFiles = dir([inputFolder '\*.jp2']);
    end

    backgroundValues = zeros(length(backgroundFiles), 1);
    for i = 1:length(backgroundFiles)
        source = [inputFolder '\' backgroundFiles(i).name];
        backgroundImage = readImage(source);
        backgroundValues(i) = single(prctile(backgroundImage(:), 3));

        if rotationFlag == 1
            backgroundImage = rot90(backgroundImage, 3);
        elseif rotationFlag == -1
            backgroundImage = rot90(backgroundImage, 1);
        end

        target = [outputFolder '\' backgroundFiles(i).name(1:(end - 4)) outputExtension];
        writeImage(backgroundImage, target);
    end

    % save job parameters
    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.' timeString '.mat'];

    save(parameterDatabase, ...
        'inputFolder', 'outputFolder', 'projectionFolder', 'globalMaskFolder', 'specimen', 'timepoints', 'cameras', 'channels', 'dimensions', ...
        'startsLeft', 'startsTop', 'widths', 'heights', 'startsFront', 'depths', 'inputType', 'outputType', 'correctTIFF', 'rotationFlag', ...
        'medianRange', 'percentile', 'segmentFlag', 'flipHFlag', 'flipVFlag', 'splitting', 'kernelSize', 'kernelSigma', 'pixelSpacing', 'scaling', ...
        'references', 'dependents', 'thresholds', 'loggingFlag', 'verbose', 'backgroundValues', 'jobMemory');

    % process timepoints
    nTimepoints = numel(timepoints);
    for t = 1:nTimepoints
        fprintf('Processing timepoint %04d with sigma %.1f\n', timepoints(t), kernelSigma);
        processTimepoint_RC(parameterDatabase, t, jobMemory(2));
    end

    % cleanup param file
    delete(parameterDatabase);
end

fprintf('\nDone. Outputs in:\n');
for si = 1:length(sigmaValues)
    sig = sigmaValues(si);
    sigStr = strrep(sprintf('%.1f', sig), '.', 'p');
    fprintf('  %s.corrected\\mat\\output_sigma-%s\n', inputFolder, sigStr);
end
