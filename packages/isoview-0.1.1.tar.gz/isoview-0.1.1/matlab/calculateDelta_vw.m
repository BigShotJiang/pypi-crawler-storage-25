function calculateDelta_vw(parameterDatabase, t, memoryEstimate)
% df/f worker for pre-fused isoview data (VW00 / VW90)

load(parameterDatabase);

version = 1.00;

configuration = cell(16, 1);
configuration{1}  = version;        configuration{2}  = t;
configuration{3}  = timeClusters;   configuration{4}  = dffSampling;
configuration{5}  = subOffset;      configuration{6}  = meanFraction;
configuration{7}  = scaling;        configuration{8}  = forceZero;
configuration{9}  = referenceOffset;
configuration{10} = inputString;    configuration{11} = viewString;
configuration{12} = specimen;       configuration{13} = rawExtension;
configuration{14} = baselineExtension;
configuration{15} = outputExtension;
configuration{16} = [jobMemory(1) memoryEstimate];

disp(['Processing time cluster ' num2str(t, '%.4d')]);

% load baseline stack for this cluster
baselineTP = timeClusters{t, 1};
baselinePath = fullfile(inputString, ...
    ['SPM' num2str(specimen, '%.2d')], ...
    ['TM' num2str(baselineTP, '%.6d')]);
baselineName = ['SPM' num2str(specimen, '%.2d') ...
    '_TM' num2str(baselineTP, '%.6d') ...
    '_' viewString '.baseline' baselineExtension];

referenceStack = double(readImage(fullfile(baselinePath, baselineName)));

if subOffset(1)
    referenceStack = referenceStack - subOffset(2);
end;

% process each timepoint in this cluster
for currentTP = timeClusters{t, 2}

    % load current stack
    currentStackPath = fullfile(inputString, ...
        ['SPM' num2str(specimen, '%.2d')], ...
        ['TM' num2str(currentTP, '%.6d')]);
    currentStackName = ['SPM' num2str(specimen, '%.2d') ...
        '_TM' num2str(currentTP, '%.6d') ...
        '_' viewString rawExtension];

    currentStack = double(readImage(fullfile(currentStackPath, currentStackName)));

    if subOffset(1)
        currentStack = currentStack - subOffset(2);
    end;

    % df/f: ((F - F0) / (F0 + offset) + scale_offset) * scale_multiplier
    currentStack = uint16(((currentStack - referenceStack) ./ (referenceStack + referenceOffset) + scaling(1)) .* scaling(2));
    if forceZero(1)
        currentStack(referenceStack <= forceZero(2)) = scaling(1) * scaling(2);
    end;

    % output to .dff sibling directory
    outputPath = fullfile([inputString '.dff'], ...
        ['SPM' num2str(specimen, '%.2d')], ...
        ['TM' num2str(currentTP, '%.6d')]);
    if exist(outputPath, 'dir') ~= 7
        mkdir(outputPath);
    end;

    prefix = ['SPM' num2str(specimen, '%.2d') ...
        '_TM' num2str(currentTP, '%.6d') ...
        '_' viewString];

    outputStackName        = [prefix '.dff' outputExtension];
    outputXYProjectionName = [prefix '.dff_xyProjection' outputExtension];
    outputXZProjectionName = [prefix '.dff_xzProjection' outputExtension];
    outputYZProjectionName = [prefix '.dff_yzProjection' outputExtension];

    writeImage(currentStack, fullfile(outputPath, outputStackName));
    writeImage(max(currentStack, [], 3), fullfile(outputPath, outputXYProjectionName));
    writeImage(squeeze(max(currentStack, [], 2)), fullfile(outputPath, outputXZProjectionName));
    writeImage(squeeze(max(currentStack, [], 1)), fullfile(outputPath, outputYZProjectionName));
end;

end
