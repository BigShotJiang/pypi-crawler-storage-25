%% parameters
% background subtraction / filtering on fused stacks
% reads from TimeFused (or MultiFused) output
% run once per view pair

timepoints   = 0:60;

inputDir     = 'D:\isoview_test\TimeFused\';
outputDir    = 'D:\isoview_test\TimeFused.Filtered\';
header       = '';
footer       = '_timeFused_blending';
% for MultiFused input instead:
%   inputDir  = 'D:\isoview_test\MultiFused\';
%   footer    = '_multiFused_blending';

specimen     = 0;
cameras      = [0 1];       % [2 3] for VW90
channels     = 0;

filterMode   = 2;           % 0 median, 1 mean, 2 gaussian
rangeArray   = 100;
scaling      = 2.031 / (6.5 / 16);

inputType    = 2;            % tif
outputType   = 2;            % tif
saveStacks   = 1;

localRun     = [1 0];
jobMemory    = [1 0];
coreMemory   = floor(((96 - 8) * 1024) / (12 * 1024));

%% job submission

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = min(feature('numcores'), 8);
    disp(' ');
    disp([num2str(localRun(2)) ' workers allocated.']);
end;

if length(cameras) == 2 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
elseif length(cameras) == 1 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
elseif length(cameras) == 2 && length(channels) == 1
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d')];
else
    error('Invalid camera/channel configuration.');
end;

switch inputType
    case 0; inputExtension = '.klb';
    case 1; inputExtension = '.jp2';
    case 2; inputExtension = '.tif';
end;
switch outputType
    case 0; outputExtension = '.klb';
    case 1; outputExtension = '.jp2';
    case 2; outputExtension = '.tif';
end;

for currentTP = length(timepoints):-1:1
    outputPath = [outputDir header '.TM' num2str(timepoints(currentTP), '%.6d') footer];
    fileNameHeader = ['SPM' num2str(specimen, '%.2d') '_TM' num2str(timepoints(currentTP), '%.6d') configurationString];
    secondHalfFilteredProjectedName = [outputPath '\' fileNameHeader '.fusedStack_xyBProjection.filtered_' num2str(rangeArray(end)) outputExtension];
    if exist(secondHalfFilteredProjectedName, 'file') == 2
        timepoints(currentTP) = [];
    end;
end;

if ~isempty(timepoints)
    nTimepoints = numel(timepoints);

    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.filterResults.' timeString '.mat'];

    save(parameterDatabase, ...
        'timepoints', 'inputDir', 'outputDir', 'header', 'footer', ...
        'specimen', 'cameras', 'channels', 'filterMode', 'rangeArray', 'scaling', ...
        'inputType', 'outputType', 'saveStacks', 'jobMemory');

    disp(' ');

    if localRun(2) > 1 && nTimepoints > 1
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        parpool(localRun(2));
        disp(' ');
        parfor t = 1:nTimepoints
            filterResults(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        disp(' ');
    else
        for t = 1:nTimepoints
            filterResults(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
    end;
else
    disp(' ');
    disp('Existing results detected for all timepoints. Submission aborted.');
    disp(' ');
end;
