%% parameters
% df/f computation for pre-fused isoview data (VW00 / VW90)
% requires baselines from localCR_vw.m
% run once per view: set viewString to 'CM00_CM01_VW00' or 'CM02_CM03_VW90'

viewString   = 'CM02_CM03_VW90';  % 'CM00_CM01_VW00' for the other view
timepoints   = 0:60;              % must match localCR_vw range
dffSampling  = 1;                 % must match localCR_vw
subOffset    = [0 100];           % [flag, value] subtract camera dark current before df/f
meanFraction = 0.1;               % fraction of mean baseline added to denominator
scaling      = [3 5000];          % [offset, multiplier] for dynamic range of df/f output
forceZero    = [1 20];            % [flag, threshold] zero out voxels where baseline <= threshold
specimen     = 0;

inputString  = 'D:\isoview_test';

rawExtension      = '.tif';       % converted fused stacks
baselineExtension = '.tif';       % baselines from localCR_vw
outputExtension   = '.tif';       % df/f output

localRun     = [1 0];             % [local_flag, num_workers] 0 for auto-detect cores
jobMemory    = [1 0];             % [auto_flag, estimated_GB]
coreMemory   = floor(((96 - 8) * 1024) / (12 * 1024));

%% job submission

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = min(feature('numcores'), 8);
    disp(' ');
    disp([num2str(localRun(2)) ' workers allocated.']);
end;

allTimepoints = timepoints;
ticks = 1:dffSampling:numel(timepoints);
existingResultsDetected = 0;

% check for existing results and skip completed timepoints
for currentTP = length(timepoints):-1:1
    outputPath = fullfile([inputString '.dff'], ...
        ['SPM' num2str(specimen, '%.2d')], ...
        ['TM' num2str(timepoints(currentTP), '%.6d')]);
    fileName = ['SPM' num2str(specimen, '%.2d') ...
        '_TM' num2str(timepoints(currentTP), '%.6d') ...
        '_' viewString '.dff_yzProjection' outputExtension];
    fullFilePath = fullfile(outputPath, fileName);

    if exist(fullFilePath, 'file') == 2
        timepoints(currentTP) = [];
        existingResultsDetected = 1;
    end;
end;

if ~isempty(timepoints)
    nAllTicks = numel(ticks);
    timeClusters = cell(nAllTicks, 2);

    for n = nAllTicks:-1:1
        startTime = max(allTimepoints(1), allTimepoints(ticks(n)) - floor(dffSampling / 2));
        if n == nAllTicks
            stopTime = allTimepoints(end);
        else
            stopTime = min(allTimepoints(end), allTimepoints(ticks(n)) + ceil(dffSampling / 2) - 1);
        end;

        currentCluster = startTime:stopTime;
        for c = numel(currentCluster):-1:1
            if isempty(find(timepoints == currentCluster(c), 1))
                currentCluster(c) = [];
            end;
        end;

        if ~isempty(currentCluster)
            timeClusters{n, 1} = allTimepoints(ticks(n));
            timeClusters{n, 2} = currentCluster;
        else
            timeClusters(n, :) = [];
        end;
    end;

    nTicks = size(timeClusters, 1);

    % compute reference offset from mid-timeseries baseline
    if ~existingResultsDetected
        referenceTime = allTimepoints(ticks(round(numel(ticks) / 2)));

        disp(' ');
        disp(['Determining denominator offset using baseline at t = ' num2str(referenceTime)]);

        outputRoot = [inputString '.dff'];
        if exist(outputRoot, 'dir') ~= 7
            mkdir(outputRoot);
        end;

        baselinePath = fullfile(inputString, ...
            ['SPM' num2str(specimen, '%.2d')], ...
            ['TM' num2str(referenceTime, '%.6d')]);
        baselineName = ['SPM' num2str(specimen, '%.2d') ...
            '_TM' num2str(referenceTime, '%.6d') ...
            '_' viewString '.baseline' baselineExtension];

        currentStack = readImage(fullfile(baselinePath, baselineName));
        if subOffset(1)
            currentStack = currentStack - subOffset(2);
        end;
        referenceOffset = ceil(meanFraction * mean(currentStack(currentStack > 0)));

        referencePath = fullfile(outputRoot, 'Reference');
        if exist(referencePath, 'dir') ~= 7
            mkdir(referencePath);
        end;

        save(fullfile(referencePath, [viewString '.referenceOffset.mat']), 'referenceOffset');
    else
        disp(' ');
        disp('Existing results detected, loading saved referenceOffset.');

        referencePath = fullfile([inputString '.dff'], 'Reference');
        load(fullfile(referencePath, [viewString '.referenceOffset.mat']));
    end;

    % estimate memory if needed
    if jobMemory(1) == 1
        samplePath = fullfile(inputString, ...
            ['SPM' num2str(specimen, '%.2d')], ...
            ['TM' num2str(timepoints(1), '%.6d')]);
        sampleName = ['SPM' num2str(specimen, '%.2d') ...
            '_TM' num2str(timepoints(1), '%.6d') ...
            '_' viewString rawExtension];
        fullSamplePath = fullfile(samplePath, sampleName);

        try
            headerInformation = imfinfo(fullSamplePath);
            stackDimensions = [headerInformation(1).Height headerInformation(1).Width numel(headerInformation)];
            unitX = 2 * stackDimensions(1) * stackDimensions(2) * stackDimensions(3) / (1024 ^ 3);
        catch
            error('Failed to read stack dimensions for memory estimation.');
        end;

        jobMemory(1, 2) = ceil(1.2 * 14 * unitX);
    end;

    % save parameter database
    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.calculateDelta_vw.' timeString '.mat'];

    save(parameterDatabase, ...
        'timepoints', 'timeClusters', 'dffSampling', 'subOffset', 'meanFraction', 'scaling', 'forceZero', ...
        'referenceOffset', 'inputString', 'viewString', 'specimen', ...
        'rawExtension', 'baselineExtension', 'outputExtension', 'jobMemory');

    disp(' ');

    if localRun(2) > 1 && nTicks > 1
        poolobj = gcp('nocreate');
        if ~isempty(poolobj)
            delete(poolobj);
        end
        parpool(localRun(2));

        disp(' ');
        parfor t = 1:nTicks
            calculateDelta_vw(parameterDatabase, t, jobMemory(2));
        end;

        disp(' ');
        poolobj = gcp('nocreate');
        if ~isempty(poolobj)
            delete(poolobj);
        end
        disp(' ');
    else
        for t = 1:nTicks
            calculateDelta_vw(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
    end;
else
    disp(' ');
    disp('Existing results detected for all timepoints. Submission aborted.');
    disp(' ');
end;
