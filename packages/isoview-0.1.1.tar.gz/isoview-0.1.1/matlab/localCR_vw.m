%% parameters
% baseline computation for pre-fused isoview data (VW00 / VW90)
% reads fused stacks directly (no median-filtered intermediates needed)
% run once per view: set viewString to 'CM00_CM01_VW00' or 'CM02_CM03_VW90'

viewString   = 'CM02_CM03_VW90';  % 'CM00_CM01_VW00' for the other view
timepoints   = 0:60;              % 61 timepoints available
dffSampling  = 1;                 % baseline at every timepoint
dffRadius    = 10;                % rolling window of ±10 timepoints
percentile   = 30;                % percentile used for baseline estimation
specimen     = 0;

inputString  = 'D:\isoview_test';

inputExtension  = '.tif';
outputExtension = '.tif';         % baselines saved as plain tif
poolWorkers     = 0;              % 0 for auto-detect

%% main loop

if poolWorkers == 0
    poolWorkers = feature('numcores');
    disp(' ');
    disp([num2str(poolWorkers) ' CPU cores detected.']);
end;

disp(' ');
disp('Setting up processing environment');

masterClock = tic;

ticks = 1:dffSampling:numel(timepoints);
timeArray = zeros(numel(ticks) + 1, 1);

% build path to first stack to get dimensions
sampleStackPath = fullfile(inputString, ...
    ['SPM' num2str(specimen, '%.2d')], ...
    ['TM' num2str(timepoints(1), '%.6d')]);
sampleStackName = ['SPM' num2str(specimen, '%.2d') ...
    '_TM' num2str(timepoints(1), '%.6d') ...
    '_' viewString inputExtension];
fullSampleStackPath = fullfile(sampleStackPath, sampleStackName);

headerInformation = imfinfo(fullSampleStackPath);
stackDimensions = [headerInformation(1).Height headerInformation(1).Width numel(headerInformation)];

dataPool = NaN(stackDimensions(1), stackDimensions(2), stackDimensions(3), 2 * dffRadius, 'single');

timeArray(1) = toc(masterClock);
disp(['Processing environment set up in ' num2str(timeArray(1), '%.2f') ' seconds']);

for t = 1:numel(ticks)
    disp(' ');
    disp(['Processing baseline data for tick ' num2str(t) ' of ' num2str(numel(ticks))]);

    masterClock = tic;

    if t == 1
        referenceTimePoints = timepoints(ticks(1:dffRadius));

        for r = 1:dffRadius
            currentTime = referenceTimePoints(r);
            disp(['* Loading image data at t = ' num2str(currentTime)]);

            stackPath = fullfile(inputString, ...
                ['SPM' num2str(specimen, '%.2d')], ...
                ['TM' num2str(currentTime, '%.6d')]);
            stackName = ['SPM' num2str(specimen, '%.2d') ...
                '_TM' num2str(currentTime, '%.6d') ...
                '_' viewString inputExtension];
            fullStackPath = fullfile(stackPath, stackName);

            dataPool(:, :, :, r) = readImage(fullStackPath);
        end;

        activeIndices = 1:dffRadius;
        newSlot = dffRadius + 1;
    else
        newTickIndex = dffRadius + t - 1;

        if newTickIndex <= numel(ticks)
            newTime = timepoints(ticks(newTickIndex));
            disp(['* Loading image data at t = ' num2str(newTime)]);

            stackPath = fullfile(inputString, ...
                ['SPM' num2str(specimen, '%.2d')], ...
                ['TM' num2str(newTime, '%.6d')]);
            stackName = ['SPM' num2str(specimen, '%.2d') ...
                '_TM' num2str(newTime, '%.6d') ...
                '_' viewString inputExtension];
            fullStackPath = fullfile(stackPath, stackName);

            dataPool(:, :, :, newSlot) = readImage(fullStackPath);

            indexFlag = find(activeIndices == newSlot, 1);
            if isempty(indexFlag)
                activeIndices = cat(2, activeIndices, newSlot);
            end;
        else
            disp(['* Removing image data at slot ' num2str(newSlot)]);
            dataPool(:, :, :, newSlot) = NaN;

            indexFlag = find(activeIndices == newSlot, 1);
            if ~isempty(indexFlag)
                activeIndices(indexFlag) = [];
            end;
        end;

        newSlot = newSlot + 1;
        if newSlot > (2 * dffRadius)
            newSlot = 1;
        end;
    end;

    disp('* Multi-threaded percentile computation');
    referenceStack = zeros(stackDimensions(1), stackDimensions(2), stackDimensions(3), 'uint16');
    parfor z = 1:stackDimensions(3)
        referenceStack(:, :, z) = prctile(dataPool(:, :, z, activeIndices), percentile, 4);
    end;

    disp('* Saving baseline stack');
    currentTimepoint = timepoints(ticks(t));

    % baselines written alongside the input stacks
    outputStackPath = fullfile(inputString, ...
        ['SPM' num2str(specimen, '%.2d')], ...
        ['TM' num2str(currentTimepoint, '%.6d')]);

    prefix = ['SPM' num2str(specimen, '%.2d') ...
        '_TM' num2str(currentTimepoint, '%.6d') ...
        '_' viewString];

    outputStackName        = [prefix '.baseline' outputExtension];
    outputXYProjectionName = [prefix '.baseline_xyProjection' outputExtension];
    outputXZProjectionName = [prefix '.baseline_xzProjection' outputExtension];
    outputYZProjectionName = [prefix '.baseline_yzProjection' outputExtension];

    writeImage(referenceStack, fullfile(outputStackPath, outputStackName));
    writeImage(max(referenceStack, [], 3), fullfile(outputStackPath, outputXYProjectionName));
    writeImage(squeeze(max(referenceStack, [], 2)), fullfile(outputStackPath, outputXZProjectionName));
    writeImage(squeeze(max(referenceStack, [], 1)), fullfile(outputStackPath, outputYZProjectionName));

    timeArray(t + 1) = toc(masterClock);
    disp(['Tick ' num2str(t) ' of ' num2str(numel(ticks)) ' (time point ' num2str(currentTimepoint) ') processed in ' num2str(timeArray(t + 1), '%.2f') ' seconds']);
end;

disp(' ');

poolobj = gcp('nocreate');
if ~isempty(poolobj)
    delete(poolobj);
end

disp(' ');
elapsedTime = sum(timeArray);
disp(['Processing completed in ' num2str(elapsedTime / 60, '%.2f') ' minutes']);
disp(' ');
