rootFolder = 'P:\SV3\RC_17-04-20\GCaMP6s_1_20170420_160545.corrected\MVD Results\';
timePoints = 0:394;

outPathxy=sprintf('%sxyProjections', rootFolder); 
if ~exist(outPathxy,'dir')
    mkdir(outPathxy);
end

outPathxz=sprintf('%sxzProjections', rootFolder);
if ~exist(outPathxz,'dir')
    mkdir(outPathxz);
end

outPathyz=sprintf('%syzProjections', rootFolder);
if ~exist(outPathyz,'dir')
mkdir(outPathyz);
end

for t = timePoints
    inputMVD = ['SPM00_TM' num2str(t, '%.6d') '_MVD_uint16.klb'];
    inputPath = [rootFolder inputMVD];
    stack = readImage(inputPath);
    writeImage(max(stack, [] , 3), [rootFolder 'xyProjections\' inputMVD(1:(end-3)) 'xyProjection.klb']);
    writeImage(squeeze(max(stack, [] , 2)), [rootFolder 'xzProjections\' inputMVD(1:(end-3)) 'xzProjection.klb']);
    writeImage(squeeze(max(stack, [] , 1)), [rootFolder 'yzProjections\' inputMVD(1:(end-3)) 'yzProjection.klb']);
end;