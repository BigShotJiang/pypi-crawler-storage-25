%% clusterMF.m - Multi-view fusion for IsoView data
% Configured for mosquito larva dataset, camera 0+1 fusion
% Matches Python isoview.fuse() parameters for comparison
%
% Uses corrected KLB output from clusterPT_RC.m as input
%
% Usage:
%   matlab -batch "run('C:\Users\RBO\repos\isoview\matlab\clusterMF.m')"

clc; clear;

% Add Isoview-Processing paths (for multiFuse.m and dependencies)
isoview_processing = 'C:\Users\RBO\repos\Isoview-Processing';
addpath(fullfile(isoview_processing, 'src'));
addpath(fullfile(isoview_processing, 'mbo_scripts'));

%% Configuration - matches Python test_fusion_cam01.py

timepoints   = 0;

% Input: corrected KLB files from clusterPT_RC.m
inputString  = 'D:\W2_DATA\foconnell\isoview_development\mosquito-larva_20250930_165806.corrected';

% Output: fusion results (same base directory)
outputString = 'D:\W2_DATA\foconnell\isoview_development\mosquito-larva_20250930_165806.corrected';

outputID     = '_cam01_fusion';
dataType     = 0;  % 0: unsegmented input

specimen     = 0;

% 2-view camera fusion: cameras 0 and 1, single channel
cameras      = [0 1];
channels     = 0;

%% Processing parameters - matching Python defaults

reducedIO    = 1;         % minimal logging
inputType    = 0;         % KLB format
outputType   = 0;         % KLB output
splitting    = 10;
kernelSize   = 5;
kernelSigma  = 2;
fraction     = 0;         % disable bwareaopen (mask_min_object_size=0)
maskMinimum  = [1 100];   % [percentile, subsampling] (mask_percentile=1.0, mask_subsample=100)
maskFactor   = 1.0;       % threshold factor
maskFusion   = 1;         % combine full masks (fusion_mask_fusion_mode=1)
padding      = [0 50];    % [mode, radius] (fusion_mask_padding=0, fusion_mask_padding_radius=50)
slabSizes    = [5 3];     % [channels, cameras] slab sizes
intSizes     = [10 5];    % [channels, cameras] intensity slab sizes
percentile   = 5;         % background percentile
subSampling  = [1 100];   % [slices, stacks] subsampling
medianFilter = 0;         % disable (fusion_median_filter_range=0 for testing)
preciseGauss = 1;         % double precision (fusion_precise_gauss=True)
gaussFilter  = [0 1];     % [kernel, sigma] - disabled (fusion_gauss_kernel=0)
optimizer    = 3;         % gradient descent
correction   = [1 1 0 0]; % enable intensity correction
fusionType   = 0;         % adaptive blending (fusion_type="adaptive_blending")
transitions  = [0 0];     % not used for adaptive blending
blending     = [20 20];   % [channels, cameras] blending ranges (fusion_blending_range=(20, 20))

enforceFlag  = ones(1, 25);  % run all steps
verbose      = 2;            % full output

cropping     = {[0 0 0 0 0 0]; [0 0 0 0 0 0]};  % no cropping
scaling      = 0.40625 / (6.5 / 16);  % axial/lateral pixel ratio

leftFlags    = [2 1];     % light sheet direction
flipHFlag    = 1;         % flip second camera horizontally (fusion_flip_h=True)
flipVFlag    = 0;         % no vertical flip (fusion_flip_v=False)

xOffsets     = -50:10:50; % search range (fusion_search_offsets_x=(-50, 50, 10))
yOffsets     = -50:10:50; % search range (fusion_search_offsets_y=(-50, 50, 10))

frontFlag    = 1;         % reference camera has quality in front

localRun     = [1 0];     % local execution, auto-detect cores
jobMemory    = [1 0];     % auto memory management

coreMemory   = floor(((96 - 8) * 1024) / (12 * 1024));

%% Job submission

if dataType == 1 && padding(1) > 0
    warning('Padded masks inconsistent with segmented input.');
end

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = feature('numcores');
    disp(' ');
    disp([num2str(localRun(2)) ' CPU cores detected.']);
end

% Configuration string for 2-view camera fusion
configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d')];
processingMode = 2;

inputExtension = '.klb';

% Check for existing results
for currentTP = length(timepoints):-1:1
    if exist([outputString '.TM' num2str(timepoints(currentTP), '%.6d') '_multiFused' outputID ...
            '/SPM' num2str(specimen, '%.2d') '_TM' num2str(timepoints(currentTP), '%.6d') configurationString '_jobCompleted.txt'], 'file') == 2
        timepoints(currentTP) = [];
    end
end

if ~isempty(timepoints)
    nTimepoints = numel(timepoints);

    currentTime = clock;
    timeString = [...
        num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.multiFuse.' timeString '.mat'];

    save(parameterDatabase, ...
        'timepoints', 'inputString', 'outputString', 'outputID', 'dataType', 'specimen', 'cameras', 'channels', 'reducedIO', 'inputType', 'outputType', ...
        'splitting', 'kernelSize', 'kernelSigma', 'fraction', 'maskMinimum', 'maskFactor', 'maskFusion', 'padding', ...
        'slabSizes', 'intSizes', 'percentile', 'subSampling', 'medianFilter', 'preciseGauss', 'gaussFilter', ...
        'optimizer', 'correction', 'fusionType', 'transitions', 'blending', 'enforceFlag', 'verbose', ...
        'cropping', 'scaling', 'leftFlags', 'flipHFlag', 'flipVFlag', 'xOffsets', 'yOffsets', 'frontFlag', 'jobMemory');

    disp(' ');
    disp(['Processing ' num2str(nTimepoints) ' timepoint(s)...']);
    disp(' ');

    for t = 1:nTimepoints
        disp(['Processing timepoint ' num2str(timepoints(t), '%.4d')]);
        multiFuse(parameterDatabase, t, jobMemory(2));
        disp(' ');
    end

    disp('Fusion complete!');
else
    disp(' ');
    disp('Existing results detected. Submission aborted.');
    disp(' ');
end
