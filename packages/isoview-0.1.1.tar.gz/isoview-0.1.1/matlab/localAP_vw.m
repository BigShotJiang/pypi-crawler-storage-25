%% parameters
% analyze per-timepoint transforms from clusterMF, smooth over time
% run once per view pair, matching cameras/channels from clusterMF_vw

timepoints   = 0:60;
fullInterval = 0:60;

outputString = 'D:\isoview_test\MultiFused';
outputID     = '_blending';
dataType     = 0;

specimen     = 0;
cameras      = [0 1];       % [2 3] for VW90
channels     = 0;

readFactors  = 1;
smoothing    = [1 20];       % rloess smoothing, window size
offsetRange  = 10;
angleRange   = 10;
intRange     = 5;
averaging    = 0;            % 0 for mean, 1 for median
staticFlag   = 0;            % 0 for time-dependent, 1 for static

analyzeParameters(...
    timepoints, fullInterval,...
    outputString, outputID, dataType,...
    specimen, cameras, channels, readFactors, smoothing,...
    offsetRange, angleRange, intRange, averaging, staticFlag)
