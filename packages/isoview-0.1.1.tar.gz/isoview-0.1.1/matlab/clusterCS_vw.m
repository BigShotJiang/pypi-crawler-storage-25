%% parameters
% drift correction and intensity normalization on fused stacks
% uses drift/intensity data from localEC_vw
% run once per view pair

inputRoot        = 'D:\isoview_test\TimeFused';
inputPattern     = '.TM??????_timeFused_blending\SPM00_TM??????_CM00_CM01_CHN00.fusedStack';
% VW90: '.TM??????_timeFused_blending\SPM00_TM??????_CM02_CM03_CHN00.fusedStack'

configRoot       = 'D:\isoview_test\Scripts\SPM00_CM00_CM01_CHN00_stackCorrection';
% VW90: 'D:\isoview_test\Scripts\SPM00_CM02_CM03_CHN00_stackCorrection'

outputRoot       = 'D:\isoview_test\TimeFused.Corrected';
headerPattern    = '.TM??????_timeFused_blending\';
filePattern      = 'SPM00_TM??????_CM00_CM01_CHN00.fusedStack';
% VW90: 'SPM00_TM??????_CM02_CM03_CHN00.fusedStack'

timepoints       = 0:60;
dataType         = 1;         % 0: projections only, 1: stacks + projections
percentile       = [1 10];

inputType        = 2;         % tif
outputType       = 2;         % tif

correctDrift     = 1;
referenceTime    = 30;        % mid-range reference timepoint
referenceROI     = [];

correctIntensity = 1;

maxStampDigits   = 6;
localRun         = [1 0];
jobMemory        = [1 0];
coreMemory       = floor(((96 - 8) * 1024) / (12 * 1024));

%% initialization

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = min(feature('numcores'), 8);
    disp(' ');
    disp([num2str(localRun(2)) ' workers allocated.']);
end;

switch outputType
    case 0; outputExtension = '.klb';
    case 1; outputExtension = '.jp2';
    case 2; outputExtension = '.tif';
end;

nTimepoints = numel(timepoints);
inputDatabase = cell(nTimepoints, 1);
outputDatabase = cell(nTimepoints, 2);

for n = 1:nTimepoints
    inputDatabase{n} = [inputRoot '\' headerPattern filePattern];
    outputDatabase{n, 1} = [outputRoot '\' headerPattern];
    outputDatabase{n, 2} = [outputRoot '\' headerPattern filePattern];
    for i = maxStampDigits:-1:1
        precision = ['%.' num2str(i) 'd'];
        positions1 = strfind(inputDatabase{n}, repmat('?', [1 i]));
        for k = 1:length(positions1)
            inputDatabase{n}(positions1(k):(positions1(k)+i-1)) = num2str(timepoints(n), precision);
        end;
        positions2 = strfind(outputDatabase{n, 1}, repmat('?', [1 i]));
        for k = 1:length(positions2)
            outputDatabase{n, 1}(positions2(k):(positions2(k)+i-1)) = num2str(timepoints(n), precision);
        end;
        positions3 = strfind(outputDatabase{n, 2}, repmat('?', [1 i]));
        for k = 1:length(positions3)
            outputDatabase{n, 2}(positions3(k):(positions3(k)+i-1)) = num2str(timepoints(n), precision);
        end;
    end;
end;

load([configRoot '\dimensions.mat']);
load([configRoot '\dimensionsMax.mat']);
load([configRoot '\dimensionsDeltas.mat']);

if correctDrift
    load([configRoot '\driftTable.mat']);
    xOffsets = driftTable(:, 2);
    yOffsets = driftTable(:, 3);
    zOffsets = driftTable(:, 4);
    referenceIndex = find(dimensions(:, 1) == referenceTime, 1);
    xOffsets = xOffsets(referenceIndex) - xOffsets;
    yOffsets = yOffsets(referenceIndex) - yOffsets;
    zOffsets = zOffsets(referenceIndex) - zOffsets;
else
    xOffsets = []; yOffsets = []; zOffsets = [];
end;

if correctIntensity
    load([configRoot '\intensityBackgrounds.mat']);
    load([configRoot '\intensityFactors.mat']);
else
    intensityBackgrounds = [];
    intensityFactors = [];
end;

%% job submission

for t = numel(timepoints):-1:1
    if exist([outputDatabase{t, 2} '_yzProjection.corrected' outputExtension], 'file') == 2
        timepoints(t) = [];
        inputDatabase(t) = [];
        outputDatabase(t, :) = [];
    end;
end;

if ~isempty(timepoints)
    nTimepoints = numel(timepoints);

    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.correctStack.' timeString '.mat'];

    save(parameterDatabase, ...
        'inputDatabase', 'outputDatabase', 'dataType', 'timepoints', 'dimensions', 'dimensionsMax', 'dimensionsDeltas', ...
        'correctIntensity', 'intensityBackgrounds', 'intensityFactors', 'correctDrift', 'inputType', 'outputType', ...
        'percentile', 'referenceROI', 'xOffsets', 'yOffsets', 'zOffsets', 'jobMemory');

    disp(' ');

    if localRun(2) > 1 && nTimepoints > 1
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        parpool(localRun(2));
        disp(' ');
        parfor t = 1:nTimepoints
            correctStack(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        disp(' ');
    else
        for t = 1:nTimepoints
            correctStack(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
    end;
else
    disp(' ');
    disp('Existing results detected for all timepoints. Submission aborted.');
    disp(' ');
end;
