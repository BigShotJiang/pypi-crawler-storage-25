%% parameters
% per-timepoint multi-view fusion for converted corrected data
% run once per view pair:
%   VW00: cameras = [0 1]
%   VW90: cameras = [2 3]

timepoints   = 0:60;

inputString  = 'D:\isoview_test\corrected';
outputString = 'D:\isoview_test\MultiFused';
outputID     = '_blending';
dataType     = 0;           % 0 for unsegmented clusterPT output

specimen     = 0;
cameras      = [0 1];       % [2 3] for VW90
channels     = 0;

reducedIO    = 1;
inputType    = 2;            % tif
outputType   = 2;            % tif
splitting    = 10;
kernelSize   = 5;
kernelSigma  = 2;
fraction     = 0;
maskMinimum  = [1 100];
maskFactor   = 1.0;
maskFusion   = 0;            % 0 for small specimens (both cameras see same thing)
padding      = [0 60];
slabSizes    = [5 3];
intSizes     = [10 5];
percentile   = 5;
subSampling  = [1 100];
medianFilter = 0;
preciseGauss = 1;
gaussFilter  = [3 1];
optimizer    = 3;
correction   = [1 1 0 0];
fusionType   = 0;            % 0 adaptive blending
transitions  = [0 0];
blending     = [20 4];

enforceFlag  = [1 1 1 1 1 1 1, 1 1 1 1 1 1 1, 1 1 1 1 1, 1 1 1 1 1 1];
verbose      = 1;

cropping     = {[0 0 0 0 0 0]; [0 0 0 0 0 0]};
scaling      = 2.031 / (6.5 / 16);

leftFlags    = [2 1];
flipHFlag    = 0;
flipVFlag    = 0;

xOffsets     = -180:10:180;
yOffsets     = -180:10:180;

frontFlag    = 1;

localRun     = [1 0];
jobMemory    = [1 0];
coreMemory   = floor(((96 - 8) * 1024) / (12 * 1024));

%% job submission

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = min(feature('numcores'), 8);
    disp(' ');
    disp([num2str(localRun(2)) ' workers allocated.']);
end;

if length(cameras) == 2 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
    processingMode = 0;
elseif length(cameras) == 1 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
    processingMode = 1;
elseif length(cameras) == 2 && length(channels) == 1
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d')];
    processingMode = 2;
else
    error('Invalid camera/channel configuration.');
end;

inputExtension = '.tif';

for currentTP = length(timepoints):-1:1
    if exist([outputString '.TM' num2str(timepoints(currentTP), '%.6d') '_multiFused' outputID ...
            '/SPM' num2str(specimen, '%.2d') '_TM' num2str(timepoints(currentTP), '%.6d') configurationString '_jobCompleted.txt'], 'file') == 2
        timepoints(currentTP) = [];
    end;
end;

if ~isempty(timepoints)
    nTimepoints = numel(timepoints);

    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.multiFuse.' timeString '.mat'];

    save(parameterDatabase, ...
        'timepoints', 'inputString', 'outputString', 'outputID', 'dataType', 'specimen', 'cameras', 'channels', 'reducedIO', 'inputType', 'outputType', ...
        'splitting', 'kernelSize', 'kernelSigma', 'fraction', 'maskMinimum', 'maskFactor', 'maskFusion', 'padding', ...
        'slabSizes', 'intSizes', 'percentile', 'subSampling', 'medianFilter', 'preciseGauss', 'gaussFilter', ...
        'optimizer', 'correction', 'fusionType', 'transitions', 'blending', 'enforceFlag', 'verbose', ...
        'cropping', 'scaling', 'leftFlags', 'flipHFlag', 'flipVFlag', 'xOffsets', 'yOffsets', 'frontFlag', 'jobMemory');

    disp(' ');

    if localRun(2) > 1 && nTimepoints > 1
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        parpool(localRun(2));
        disp(' ');
        parfor t = 1:nTimepoints
            multiFuse(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        disp(' ');
    else
        for t = 1:nTimepoints
            multiFuse(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
    end;
else
    disp(' ');
    disp('Existing results detected for all timepoints. Submission aborted.');
    disp(' ');
end;
