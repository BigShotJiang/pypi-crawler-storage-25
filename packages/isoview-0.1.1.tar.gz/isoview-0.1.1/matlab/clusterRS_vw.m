%% parameters
% functional registration (x/y translation) on fused stacks
% reads from TimeFused (or TimeFused.Corrected) output
% run once per view pair

timepoints   = 0:60;
references   = 20:40;         % stable timepoints for reference averaging

dffSampling  = 1;             % baseline interval (must match localCR_vw)
kernelSize   = 3;

inputString  = 'D:\isoview_test\TimeFused';
header       = '';
footer       = '_timeFused_blending';
dataType     = 1;             % 1: fused processed data
specimen     = 0;

cameras      = [0 1];         % [2 3] for VW90
channels     = 0;

inputType    = 2;              % tif
outputType   = 2;              % tif

localRun     = [1 0];
jobMemory    = [1 0];
coreMemory   = floor(((96 - 8) * 1024) / (12 * 1024));

%% job submission

if localRun(1) == 1 && localRun(2) == 0
    localRun(2) = min(feature('numcores'), 8);
    disp(' ');
    disp([num2str(localRun(2)) ' workers allocated.']);
end;

if length(cameras) == 2 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
elseif length(cameras) == 1 && length(channels) == 2
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CHN' num2str(channels(1), '%.2d') '_CHN' num2str(channels(2), '%.2d')];
elseif length(cameras) == 2 && length(channels) == 1
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CM' num2str(cameras(2), '%.2d') '_CHN' num2str(channels(1), '%.2d')];
elseif length(cameras) == 1 && length(channels) == 1
    configurationString = ['_CM' num2str(cameras(1), '%.2d') '_CHN' num2str(channels(1), '%.2d')];
else
    error('Invalid camera/channel configuration.');
end;

switch inputType
    case 0; inputExtension = '.klb';
    case 1; inputExtension = '.jp2';
    case 2; inputExtension = '.tif';
end;
switch outputType
    case 0; outputExtension = '.klb';
    case 1; outputExtension = '.jp2';
    case 2; outputExtension = '.tif';
end;

% check for existing results
for currentTP = length(timepoints):-1:1
    outputPath = [inputString '.registered\' header '.TM' num2str(timepoints(currentTP), '%.6d') footer];
    fileName = ['SPM' num2str(specimen, '%.2d') '_TM' num2str(timepoints(currentTP), '%.6d') configurationString '.shifts.mat'];
    if exist(fullfile(outputPath, fileName), 'file') == 2
        timepoints(currentTP) = [];
    end;
end;

if ~isempty(timepoints)
    nTimepoints = numel(timepoints);

    % generate reference stack
    disp(' ');
    disp('Generating reference stack');

    referencePath = [inputString '.registered\Reference'];
    if ~exist(referencePath, 'dir'); mkdir(referencePath); end;

    referenceStackName = ['SPM' num2str(specimen, '%.2d') configurationString '.referenceStack' outputExtension];

    if ~exist(fullfile(referencePath, referenceStackName), 'file')
        referenceStack = [];
        nReferences = 0;
        for r = 1:numel(references)
            refTP = references(r);
            refPath = [inputString '\' header '.TM' num2str(refTP, '%.6d') footer];
            refName = ['SPM' num2str(specimen, '%.2d') '_TM' num2str(refTP, '%.6d') configurationString '.fusedStack' inputExtension];
            fullRefPath = fullfile(refPath, refName);
            if exist(fullRefPath, 'file') == 2
                disp(['  adding t=' num2str(refTP)]);
                currentStack = single(readImage(fullRefPath));
                if isempty(referenceStack)
                    referenceStack = currentStack;
                else
                    referenceStack = referenceStack + currentStack;
                end;
                nReferences = nReferences + 1;
            end;
        end;
        if nReferences > 0
            referenceStack = uint16(referenceStack / nReferences);
            writeImage(referenceStack, fullfile(referencePath, referenceStackName));
            disp(['Reference stack saved (' num2str(nReferences) ' timepoints averaged)']);
        else
            error('No reference timepoints found.');
        end;
    else
        disp('Reference stack already exists, skipping.');
    end;

    % save parameter database
    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.registerStacks.' timeString '.mat'];

    medianFlags = zeros(1, numel(timepoints));
    medianFlags(1:dffSampling:end) = 1;

    save(parameterDatabase, ...
        'timepoints', 'references', 'medianFlags', 'dffSampling', 'kernelSize', ...
        'inputString', 'header', 'footer', 'dataType', 'specimen', 'cameras', 'channels', ...
        'inputType', 'outputType', 'jobMemory');

    disp(' ');

    if localRun(2) > 1 && nTimepoints > 1
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        parpool(localRun(2));
        disp(' ');
        parfor t = 1:nTimepoints
            registerStacks(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
        poolobj = gcp('nocreate');
        if ~isempty(poolobj); delete(poolobj); end
        disp(' ');
    else
        for t = 1:nTimepoints
            registerStacks(parameterDatabase, t, jobMemory(2));
        end;
        disp(' ');
    end;
else
    disp(' ');
    disp('Existing results detected for all timepoints. Submission aborted.');
    disp(' ');
end;
