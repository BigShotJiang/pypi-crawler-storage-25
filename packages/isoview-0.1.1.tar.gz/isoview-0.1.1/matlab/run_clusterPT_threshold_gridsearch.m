% run_clusterPT.m - run clusterPT with multiple threshold values for comparison
% runs only the first processing step (no fusion), cameras 0+1, no cropping
%
% usage:
%   matlab -batch "cd('c:/Users/RBO/repos/isoview/matlab'); run_clusterPT"
%   or run interactively from MATLAB

addpath('C:\Users\RBO\repos\IsoView-Processing\src');

inputFolder = 'E:\isoview\Dme_E1_57C10_GCaMP6s_Simultaneous_6p22_20150528_163012';

% run with multiple thresholds for comparison
thresholdValues = [0.3, 0.5, 0.7, 0.9];

specimen   = 0;
timepoints = 0;
cameras    = [0 1];
channels   = 1;

% no cropping
startsLeft  = [];
startsTop   = [];
widths      = [];
heights     = [];
startsFront = [];
depths      = [];
dimensions  = [];

inputType   = 3;  % unstructured (flat directory)
outputType  = 0;  % KLB output
correctTIFF = 0;

segmentFlag  = 1;  % segment + mask
rotationFlag = 1;  % 90 degrees clockwise
flipHFlag    = 0;
flipVFlag    = 0;

medianRange = [3 3];
percentile  = [1 5 100];

splitting   = 10;
kernelSize  = 5;
kernelSigma = 3;

% voxel spacing
pixelSpacingZ = 0.40625;
detectionObjectiveMagnification = 16;
pixelSpacingCamera = 6.5;
pixelSpacingXY = pixelSpacingCamera / detectionObjectiveMagnification;
pixelSpacing   = [pixelSpacingXY, pixelSpacingXY, pixelSpacingZ, 1, 1];
scaling        = pixelSpacingZ / pixelSpacingXY;

references  = [];
dependents  = [];

loggingFlag = 0;
verbose     = 1;

localRun   = [1 0];
jobMemory  = [1 0];

%% loop over threshold values

for ti = 1:length(thresholdValues)
    thr = thresholdValues(ti);
    thrStr = strrep(sprintf('%.1f', thr), '.', 'p');  % 0.3 -> 0p3

    fprintf('\n=== Running with threshold = %.1f ===\n\n', thr);

    % threshold for both cameras
    thresholds = [thr thr];

    % output folder with threshold suffix (mat subfolder to avoid overwriting python)
    outputLabel = ['mat\output_thr-' thrStr];
    projectionFolder = [inputFolder '.projections\' outputLabel];
    outputFolder = [inputFolder '.corrected\' outputLabel];
    globalMaskFolder = [inputFolder '.globalMask\' outputLabel];

    if exist(outputFolder, 'dir') ~= 7
        mkdir(outputFolder);
    end
    if exist(projectionFolder, 'dir') ~= 7
        mkdir(projectionFolder);
    end

    switch outputType
        case 0
            outputExtension = '.klb';
        case 1
            outputExtension = '.jp2';
        case 2
            outputExtension = '.tif';
    end

    % read background files
    if inputType == 0 || inputType == 2 || inputType == 3 || inputType == 4
        backgroundFiles = dir([inputFolder '\*.tif']);
    else
        backgroundFiles = dir([inputFolder '\*.jp2']);
    end

    backgroundValues = zeros(length(backgroundFiles), 1);
    for i = 1:length(backgroundFiles)
        source = [inputFolder '\' backgroundFiles(i).name];
        backgroundImage = readImage(source);
        backgroundValues(i) = single(prctile(backgroundImage(:), 3));

        if rotationFlag == 1
            backgroundImage = rot90(backgroundImage, 3);
        elseif rotationFlag == -1
            backgroundImage = rot90(backgroundImage, 1);
        end

        target = [outputFolder '\' backgroundFiles(i).name(1:(end - 4)) outputExtension];
        writeImage(backgroundImage, target);
    end

    % save job parameters
    currentTime = clock;
    timeString = [num2str(currentTime(1)) num2str(currentTime(2), '%.2d') num2str(currentTime(3), '%.2d') ...
        '_' num2str(currentTime(4), '%.2d') num2str(currentTime(5), '%.2d') num2str(round(currentTime(6) * 1000), '%.5d')];
    parameterDatabase = [pwd '\jobParameters.' timeString '.mat'];

    save(parameterDatabase, ...
        'inputFolder', 'outputFolder', 'projectionFolder', 'globalMaskFolder', 'specimen', 'timepoints', 'cameras', 'channels', 'dimensions', ...
        'startsLeft', 'startsTop', 'widths', 'heights', 'startsFront', 'depths', 'inputType', 'outputType', 'correctTIFF', 'rotationFlag', ...
        'medianRange', 'percentile', 'segmentFlag', 'flipHFlag', 'flipVFlag', 'splitting', 'kernelSize', 'kernelSigma', 'pixelSpacing', 'scaling', ...
        'references', 'dependents', 'thresholds', 'loggingFlag', 'verbose', 'backgroundValues', 'jobMemory');

    % process timepoints
    nTimepoints = numel(timepoints);
    for t = 1:nTimepoints
        fprintf('Processing timepoint %04d with threshold %.1f\n', timepoints(t), thr);
        processTimepoint_RC(parameterDatabase, t, jobMemory(2));
    end

    % cleanup param file
    delete(parameterDatabase);
end

fprintf('\nDone. Outputs in:\n');
for ti = 1:length(thresholdValues)
    thr = thresholdValues(ti);
    thrStr = strrep(sprintf('%.1f', thr), '.', 'p');
    fprintf('  %s.corrected\\mat\\output_thr-%s\n', inputFolder, thrStr);
end
