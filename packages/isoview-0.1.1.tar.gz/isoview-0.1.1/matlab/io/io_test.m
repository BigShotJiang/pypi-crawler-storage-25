%% io_test.m
% Convert KLB files to uncompressed TIFF format and copy metadata files
% Measures conversion/transfer times and file sizes
%
% Usage:
%   Run this script from MATLAB command window
%   Modify sourceRoot and destRoot as needed
%
% Author: Miller Brain Observatory
% Date: 2025-10-30

clc; clear;

% Add IsoView pipeline to path (needed for readKLBstack)
addpath(genpath("C:\Users\RBO\Documents\MATLAB\IsoView_Pipeline"))

%% Configuration
sourceRoot = '\\rbo-s1\S1_DATA\isoview\foconnell\io_corrected_test\klb';
destRoot   = '\\rbo-s1\S1_DATA\isoview\foconnell\io_corrected_test\tiff';

% Get all timepoint directories
timepointDirs = dir(fullfile(sourceRoot, 'TM*'));
timepointDirs = timepointDirs([timepointDirs.isdir]);

if isempty(timepointDirs)
    error('No timepoint directories found in: %s', sourceRoot);
end

fprintf('Found %d timepoint directories\n\n', numel(timepointDirs));

%% Statistics tracking
stats = struct();
stats.timepoints = cell(numel(timepointDirs), 1);
stats.klb_files = zeros(numel(timepointDirs), 1);
stats.klb_sizes_mb = zeros(numel(timepointDirs), 1);
stats.tiff_sizes_mb = zeros(numel(timepointDirs), 1);
stats.conversion_time_s = zeros(numel(timepointDirs), 1);
stats.copy_time_s = zeros(numel(timepointDirs), 1);
stats.total_time_s = zeros(numel(timepointDirs), 1);

totalStartTime = tic;

%% Process each timepoint
for tIdx = 1:numel(timepointDirs)
    tpName = timepointDirs(tIdx).name;
    fprintf('=== Processing %s (%d/%d) ===\n', tpName, tIdx, numel(timepointDirs));

    sourceTpDir = fullfile(sourceRoot, tpName);
    destTpDir   = fullfile(destRoot, tpName);

    % Create destination directory
    if ~exist(destTpDir, 'dir')
        mkdir(destTpDir);
    end

    % Find all files
    klbFiles = dir(fullfile(sourceTpDir, '*.klb'));
    xmlFiles = dir(fullfile(sourceTpDir, '*.xml'));
    matFiles = dir(fullfile(sourceTpDir, '*.mat'));

    fprintf('  Found: %d KLB, %d XML, %d MAT files\n', ...
        numel(klbFiles), numel(xmlFiles), numel(matFiles));

    % Track statistics for this timepoint
    stats.timepoints{tIdx} = tpName;
    stats.klb_files(tIdx) = numel(klbFiles);

    klbTotalSize = 0;
    tiffTotalSize = 0;

    %% Convert KLB to TIFF
    conversionStart = tic;

    for kIdx = 1:numel(klbFiles)
        klbPath = fullfile(sourceTpDir, klbFiles(kIdx).name);

        % Generate TIFF filename (replace .klb with .tif)
        [~, baseName, ~] = fileparts(klbFiles(kIdx).name);
        tiffPath = fullfile(destTpDir, [baseName '.tif']);

        fprintf('    [%d/%d] Converting %s... ', kIdx, numel(klbFiles), klbFiles(kIdx).name);

        fileStart = tic;

        % Read KLB
        try
            V = readKLBstack(klbPath);
        catch ME
            fprintf('ERROR reading KLB: %s\n', ME.message);
            continue;
        end

        % Write uncompressed TIFF
        try
            write_tiff_stack(tiffPath, V);
        catch ME
            fprintf('ERROR writing TIFF: %s\n', ME.message);
            continue;
        end

        fileTime = toc(fileStart);

        % Get file sizes
        klbInfo = dir(klbPath);
        tiffInfo = dir(tiffPath);
        klbSize = klbInfo.bytes / (1024^2);  % MB
        tiffSize = tiffInfo.bytes / (1024^2); % MB

        klbTotalSize = klbTotalSize + klbSize;
        tiffTotalSize = tiffTotalSize + tiffSize;

        fprintf('%.2f MB -> %.2f MB (%.2f s, %.2f MB/s)\n', ...
            klbSize, tiffSize, fileTime, tiffSize/fileTime);
    end

    stats.conversion_time_s(tIdx) = toc(conversionStart);
    stats.klb_sizes_mb(tIdx) = klbTotalSize;
    stats.tiff_sizes_mb(tIdx) = tiffTotalSize;

    %% Copy XML files
    copyStart = tic;

    for xIdx = 1:numel(xmlFiles)
        sourceFile = fullfile(sourceTpDir, xmlFiles(xIdx).name);
        destFile   = fullfile(destTpDir, xmlFiles(xIdx).name);
        copyfile(sourceFile, destFile);
    end

    fprintf('  Copied %d XML files\n', numel(xmlFiles));

    %% Copy MAT files (minIntensity, configuration, etc.)
    for mIdx = 1:numel(matFiles)
        sourceFile = fullfile(sourceTpDir, matFiles(mIdx).name);
        destFile   = fullfile(destTpDir, matFiles(mIdx).name);
        copyfile(sourceFile, destFile);
    end

    fprintf('  Copied %d MAT files\n', numel(matFiles));

    stats.copy_time_s(tIdx) = toc(copyStart);
    stats.total_time_s(tIdx) = stats.conversion_time_s(tIdx) + stats.copy_time_s(tIdx);

    fprintf('  Timepoint total: %.2f s (conversion: %.2f s, copy: %.2f s)\n', ...
        stats.total_time_s(tIdx), stats.conversion_time_s(tIdx), stats.copy_time_s(tIdx));
    fprintf('  Compression ratio: %.2fx (KLB: %.2f MB, TIFF: %.2f MB)\n\n', ...
        tiffTotalSize / klbTotalSize, klbTotalSize, tiffTotalSize);
end

totalTime = toc(totalStartTime);

%% Print summary statistics
fprintf('\n========================================\n');
fprintf('CONVERSION SUMMARY\n');
fprintf('========================================\n');
fprintf('Total timepoints processed: %d\n', numel(timepointDirs));
fprintf('Total KLB files converted: %d\n', sum(stats.klb_files));
fprintf('Total time: %.2f s (%.2f min)\n', totalTime, totalTime/60);
fprintf('\n');
fprintf('Total KLB size:  %.2f MB (%.2f GB)\n', ...
    sum(stats.klb_sizes_mb), sum(stats.klb_sizes_mb)/1024);
fprintf('Total TIFF size: %.2f MB (%.2f GB)\n', ...
    sum(stats.tiff_sizes_mb), sum(stats.tiff_sizes_mb)/1024);
fprintf('Overall compression ratio: %.2fx\n', ...
    sum(stats.tiff_sizes_mb) / sum(stats.klb_sizes_mb));
fprintf('\n');
fprintf('Average conversion time per timepoint: %.2f s\n', ...
    mean(stats.conversion_time_s));
fprintf('Average copy time per timepoint: %.2f s\n', ...
    mean(stats.copy_time_s));
fprintf('Average total time per timepoint: %.2f s\n', ...
    mean(stats.total_time_s));
fprintf('\n');
fprintf('Average throughput: %.2f MB/s\n', ...
    sum(stats.tiff_sizes_mb) / sum(stats.conversion_time_s));
fprintf('========================================\n');

%% Save statistics to CSV
statsTable = table(stats.timepoints, stats.klb_files, ...
    stats.klb_sizes_mb, stats.tiff_sizes_mb, ...
    stats.conversion_time_s, stats.copy_time_s, stats.total_time_s, ...
    'VariableNames', {'Timepoint', 'NumFiles', 'KLB_MB', 'TIFF_MB', ...
    'ConversionTime_s', 'CopyTime_s', 'TotalTime_s'});

csvPath = fullfile(destRoot, 'conversion_statistics.csv');
writetable(statsTable, csvPath);
fprintf('Statistics saved to: %s\n', csvPath);

%% Helper function: Write TIFF stack without compression
function write_tiff_stack(tiffPath, V)
% Write a 3D stack V (Y×X×Z) as an uncompressed multi-page TIFF
% Preserves uint8/uint16 data types

[H, W, Z] = size(V);

% Determine bit depth based on input type
if isa(V, 'uint8')
    bps = 8;
    toWrite = @(img) uint8(img);
elseif isa(V, 'uint16')
    bps = 16;
    toWrite = @(img) uint16(img);
else
    % Cast other types to uint16 without scaling
    warning('Input is %s; casting to uint16 without scaling.', class(V));
    bps = 16;
    toWrite = @(img) uint16(img);
end

% Delete existing file if present
if exist(tiffPath, 'file')
    delete(tiffPath);
end

% Create TIFF object
t = Tiff(tiffPath, 'w8');

% Write each Z plane
for z = 1:Z
    % Set TIFF tags for this slice
    setTag(t, struct(...
        'ImageLength',          H, ...
        'ImageWidth',           W, ...
        'Photometric',          Tiff.Photometric.MinIsBlack, ...
        'BitsPerSample',        bps, ...
        'SamplesPerPixel',      1, ...
        'PlanarConfiguration',  Tiff.PlanarConfiguration.Chunky, ...
        'Compression',          Tiff.Compression.None, ...
        'Software',             'MATLAB IsoView-Processing'));

    % Write the image data
    t.write(toWrite(V(:, :, z)));

    % Create new directory for next slice (except last one)
    if z < Z
        t.writeDirectory();
    end
end

% Close the TIFF file
t.close();
end
