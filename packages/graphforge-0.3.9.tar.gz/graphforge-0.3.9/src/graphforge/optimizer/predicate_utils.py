"""Utilities for analyzing and manipulating predicate expressions."""

from typing import Any

from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    ExtractExpression,
    FilterExpression,
    FunctionCall,
    LabelPredicate,
    ListComprehension,
    ParenthesizedExpr,
    PatternComprehension,
    PatternPredicate,
    PropertyAccess,
    QuantifierExpression,
    ReduceExpression,
    SubqueryExpression,
    Subscript,
    UnaryOp,
    Variable,
)


class PredicateAnalysis:
    """Utilities for analyzing predicate expressions."""

    @staticmethod
    def extract_conjuncts(predicate: Any) -> list[Any]:
        """Extract AND conjuncts from a predicate expression.

        Splits AND chains into a flat list. Does not split OR predicates
        as they must be evaluated together.

        Args:
            predicate: AST expression node

        Returns:
            List of conjunct expressions (single element if not an AND chain)

        Examples:
            a AND b AND c → [a, b, c]
            a OR b → [a OR b]
            a → [a]
        """
        if not isinstance(predicate, BinaryOp) or predicate.op != "AND":
            return [predicate]

        # Recursively extract from left and right
        conjuncts = []
        conjuncts.extend(PredicateAnalysis.extract_conjuncts(predicate.left))
        conjuncts.extend(PredicateAnalysis.extract_conjuncts(predicate.right))
        return conjuncts

    @staticmethod
    def combine_with_and(predicates: list[Any]) -> Any | None:
        """Combine multiple predicates with AND operator.

        Args:
            predicates: List of predicate expressions

        Returns:
            Single AND-combined expression, or None if empty list

        Examples:
            [a, b, c] → a AND b AND c
            [a] → a
            [] → None
        """
        if not predicates:
            return None

        if len(predicates) == 1:
            return predicates[0]

        # Build right-associative AND chain
        result = predicates[-1]
        for pred in reversed(predicates[:-1]):
            result = BinaryOp(op="AND", left=pred, right=result)
        return result

    @staticmethod
    def get_referenced_variables(expr: Any) -> set[str]:
        """
        Collect variable names referenced anywhere within an AST expression.

        Recursively walks the expression tree and returns the set of variable names that occur as
        references. Variables bound by comprehension/quantifier/reduce constructs (loop variables,
        accumulator) are excluded from the result, and variables local to subqueries are not
        collected. The walk recognizes direct Variable/Label/Property references, pattern
        predicates (node and relationship patterns and inline property values), function
        arguments, subscripts, case expressions, and other common expression forms.

        Parameters:
            expr (Any): AST expression node to inspect

        Returns:
            set[str]: Set of variable names referenced in the expression
        """
        variables = set()

        def walk(node: Any) -> None:
            """
            Recursively traverse an expression AST and collect referenced variable names
            into the enclosing `variables` set.

            Parameters:
                node (Any): An expression AST node or structure to walk. The function mutates
                    the surrounding `variables` set:
                    - Adds variable names referenced anywhere in the expression.
                    - Removes comprehension/quantifier loop variables and accumulators where
                      they are bound (so they are not counted as external references).
                    - Treats subqueries as self-contained (does not collect from them).
            """
            if isinstance(node, Variable):
                variables.add(node.name)
            elif isinstance(node, LabelPredicate):
                variables.add(node.variable)
            elif isinstance(node, PropertyAccess):
                if node.variable is not None:
                    variables.add(node.variable)
                elif node.base is not None:
                    walk(node.base)
            elif isinstance(node, BinaryOp):
                walk(node.left)
                walk(node.right)
            elif isinstance(node, UnaryOp):
                walk(node.operand)
            elif isinstance(node, PatternPredicate):
                # Collect variables referenced in pattern nodes and relationships
                from graphforge.ast.pattern import NodePattern, RelationshipPattern

                for part in node.parts:
                    if isinstance(part, Variable):
                        # First part can be a Variable after grammar restructuring
                        variables.add(part.name)
                    elif isinstance(part, NodePattern):
                        if part.variable:
                            variables.add(part.variable)
                        # Walk inline property predicates (e.g. {k: x} where x is a var)
                        if part.properties:
                            for prop_val in part.properties.values():
                                walk(prop_val)
                    elif isinstance(part, RelationshipPattern):
                        if part.variable:
                            variables.add(part.variable)
                        for prop_val in part.properties.values():
                            walk(prop_val)
                        if part.predicate is not None:
                            walk(part.predicate)
                    else:
                        # Generic expression in first position — walk it
                        walk(part)
            elif isinstance(node, FunctionCall):
                for arg in node.args:
                    walk(arg)
            elif isinstance(node, Subscript):
                walk(node.base)
                if node.index is not None:
                    walk(node.index)
                if node.start is not None:
                    walk(node.start)
                if node.end is not None:
                    walk(node.end)
            elif isinstance(node, ListComprehension):
                # Walk the source list and optional filter/map, but NOT the loop variable
                walk(node.list_expr)
                if node.filter_expr is not None:
                    walk(node.filter_expr)
                if node.map_expr is not None:
                    walk(node.map_expr)
                variables.discard(node.variable)
            elif isinstance(node, FilterExpression):
                walk(node.list_expr)
                walk(node.predicate)
                variables.discard(node.variable)
            elif isinstance(node, ExtractExpression):
                walk(node.list_expr)
                walk(node.map_expr)
                variables.discard(node.variable)
            elif isinstance(node, ReduceExpression):
                walk(node.initial_expr)
                walk(node.list_expr)
                walk(node.map_expr)
                variables.discard(node.variable)
                variables.discard(node.accumulator)
            elif isinstance(node, QuantifierExpression):
                walk(node.list_expr)
                walk(node.predicate)
                variables.discard(node.variable)
            elif isinstance(node, PatternComprehension):
                if node.filter_expr is not None:
                    walk(node.filter_expr)
                walk(node.map_expr)
            elif isinstance(node, CaseExpression):
                if node.subject is not None:
                    walk(node.subject)
                for condition, result in node.when_clauses:
                    walk(condition)
                    walk(result)
                if node.else_expr is not None:
                    walk(node.else_expr)
            elif isinstance(node, ParenthesizedExpr):
                walk(node.expr)
            elif isinstance(node, SubqueryExpression):
                pass  # Subqueries are self-contained; do not leak variable refs
            elif isinstance(node, dict):
                for value in node.values():
                    if isinstance(value, list):
                        for item in value:
                            walk(item)
                    else:
                        walk(value)
            elif isinstance(node, list):
                for item in node:
                    walk(item)
            # Literals don't reference variables

        walk(expr)
        return variables

    @staticmethod
    def estimate_selectivity(predicate: Any) -> float:
        """Estimate selectivity of a predicate (0.0 = very selective, 1.0 = not selective).

        Uses heuristics based on operator type. Lower values = more selective
        = fewer rows pass = should evaluate first.

        Args:
            predicate: AST expression node

        Returns:
            Estimated selectivity between 0.0 and 1.0

        Selectivity heuristics:
            - Equality (=): 0.1 (highly selective)
            - IS NULL: 0.1
            - IS NOT NULL: 0.9
            - Inequality (<, >, <=, >=): 0.5 (moderate)
            - <> (not equals): 0.9 (not selective)
            - OR: max(left, right) (least selective branch)
            - AND: min(left, right) (most selective branch)
            - Default: 0.5
        """
        if not isinstance(predicate, (BinaryOp, UnaryOp)):
            return 0.5

        if isinstance(predicate, BinaryOp):
            op = predicate.op

            # Equality is highly selective
            if op == "=":
                return 0.1

            # Not equals is not selective
            if op == "<>":
                return 0.9

            # Inequality is moderately selective
            if op in ("<", ">", "<=", ">="):
                return 0.5

            # OR takes max selectivity (least selective branch dominates)
            if op == "OR":
                left_sel = PredicateAnalysis.estimate_selectivity(predicate.left)
                right_sel = PredicateAnalysis.estimate_selectivity(predicate.right)
                return max(left_sel, right_sel)

            # AND takes min selectivity (most selective branch dominates)
            if op == "AND":
                left_sel = PredicateAnalysis.estimate_selectivity(predicate.left)
                right_sel = PredicateAnalysis.estimate_selectivity(predicate.right)
                return min(left_sel, right_sel)

        if isinstance(predicate, UnaryOp):
            op = predicate.op

            # IS NULL is highly selective (few NULLs in most datasets)
            if op == "IS NULL":
                return 0.1

            # IS NOT NULL is not selective (most values are non-NULL)
            if op == "IS NOT NULL":
                return 0.9

        # Default moderate selectivity
        return 0.5
