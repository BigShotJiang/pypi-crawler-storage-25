"""Runtime value types for openCypher.

This module implements the openCypher type system including:
- Scalar types: NULL, BOOLEAN, INTEGER, FLOAT, STRING
- Temporal types: DATE, DATETIME, TIME, DURATION
- Collection types: LIST, MAP, PATH

Values follow openCypher semantics including:
- NULL propagation in comparisons and operations
- Type-aware equality and comparison
- Conversion to/from Python types
"""

import datetime
from enum import Enum
import re
from typing import TYPE_CHECKING, Any

from dateutil import parser as dateutil_parser
from dateutil import tz as dateutil_tz
import isodate  # type: ignore[import-untyped]

if TYPE_CHECKING:
    from graphforge.types.graph import EdgeRef, NodeRef


class CypherType(Enum):
    """openCypher value types."""

    NULL = "NULL"
    BOOLEAN = "BOOLEAN"
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    STRING = "STRING"
    DATE = "DATE"
    DATETIME = "DATETIME"
    TIME = "TIME"
    DURATION = "DURATION"
    POINT = "POINT"
    DISTANCE = "DISTANCE"
    LIST = "LIST"
    MAP = "MAP"
    PATH = "PATH"


class CypherValue:
    """Base class for all openCypher values.

    All comparison operations follow openCypher semantics:
    - NULL in any operation propagates NULL
    - Type-aware comparisons
    """

    def __init__(self, value: Any, cypher_type: CypherType):
        self.value = value
        self.type = cypher_type

    def equals(self, other: Any) -> "CypherValue":
        """Check equality following openCypher semantics.

        Returns:
            CypherBool(True) if equal
            CypherBool(False) if not equal
            CypherNull if either operand is NULL
        """
        # Guard: non-CypherValue (e.g. NodeRef, EdgeRef) → not equal
        if not isinstance(other, CypherValue):
            return CypherBool(False)

        # NULL propagation
        if isinstance(self, CypherNull) or isinstance(other, CypherNull):
            return CypherNull()

        # Numeric types can be compared across int/float
        if self._is_numeric() and other._is_numeric():
            return CypherBool(self.value == other.value)

        # Same type comparison
        if self.type == other.type:
            if self.type in (CypherType.LIST, CypherType.MAP, CypherType.PATH):
                return self._deep_equals(other)
            if self.type in (CypherType.DATETIME, CypherType.TIME):
                return CypherBool(
                    self.value == other.value
                    and getattr(self, "_ns_residue", 0) == getattr(other, "_ns_residue", 0)
                )
            return CypherBool(self.value == other.value)

        # Different types are not equal
        return CypherBool(False)

    def less_than(self, other: Any) -> "CypherValue":
        """Check if this value is less than another.

        Returns:
            CypherBool(True/False) for comparable types
            CypherNull if either operand is NULL or types are incompatible
        """
        # Guard: non-CypherValue (e.g. NodeRef, EdgeRef) → incomparable → null
        if not isinstance(other, CypherValue):
            return CypherNull()

        # NULL propagation
        if isinstance(self, CypherNull) or isinstance(other, CypherNull):
            return CypherNull()

        # Numeric comparison
        if self._is_numeric() and other._is_numeric():
            return CypherBool(self.value < other.value)

        # String comparison
        if self.type == CypherType.STRING and other.type == CypherType.STRING:
            return CypherBool(self.value < other.value)

        # Boolean comparison (False < True)
        if self.type == CypherType.BOOLEAN and other.type == CypherType.BOOLEAN:
            return CypherBool(self.value < other.value)

        # List comparison (lexicographic)
        if self.type == CypherType.LIST and other.type == CypherType.LIST:
            for a, b in zip(self.value, other.value):
                a_lt_b = a.less_than(b)
                if isinstance(a_lt_b, CypherNull):
                    return CypherNull()
                if a_lt_b.value:
                    return CypherBool(True)
                b_lt_a = b.less_than(a)
                if isinstance(b_lt_a, CypherNull):
                    return CypherNull()
                if b_lt_a.value:
                    return CypherBool(False)
            # All elements equal so far, shorter list is less
            return CypherBool(len(self.value) < len(other.value))

        # Temporal comparison (DATE, DATETIME, TIME, DURATION)
        if self._is_temporal() and other._is_temporal():
            # Only allow comparison of same temporal types with matching timezone-awareness
            if self.type == other.type:
                sv, ov = self.value, other.value
                # Guard against naive vs aware comparison (would raise TypeError)
                if hasattr(sv, "tzinfo") and hasattr(ov, "tzinfo"):
                    if (sv.tzinfo is None) != (ov.tzinfo is None):
                        return CypherNull()
                try:
                    if sv == ov and self.type in (CypherType.DATETIME, CypherType.TIME):
                        # Tiebreak by _ns_residue (sub-microsecond nanoseconds)
                        ns_self = getattr(self, "_ns_residue", 0)
                        ns_other = getattr(other, "_ns_residue", 0)
                        return CypherBool(ns_self < ns_other)
                    return CypherBool(sv < ov)
                except TypeError:
                    return CypherNull()
            return CypherNull()

        # Incomparable types (e.g., int vs string, map vs node, temporal of different kind) → null
        return CypherNull()

    def _is_numeric(self) -> bool:
        """Check if this value is a numeric type."""
        return self.type in (CypherType.INTEGER, CypherType.FLOAT)

    def _is_temporal(self) -> bool:
        """Check if this value is a temporal type."""
        return self.type in (
            CypherType.DATE,
            CypherType.DATETIME,
            CypherType.TIME,
            CypherType.DURATION,
        )

    def _deep_equals(self, other: "CypherValue") -> "CypherValue":
        """Deep equality check for collections."""
        if self.type == CypherType.LIST:
            if len(self.value) != len(other.value):
                return CypherBool(False)
            has_null = False
            for a, b in zip(self.value, other.value):
                result = a.equals(b)
                if isinstance(result, CypherNull):
                    has_null = True
                elif not result.value:
                    return CypherBool(False)
            return CypherNull() if has_null else CypherBool(True)

        if self.type == CypherType.MAP:
            if set(self.value.keys()) != set(other.value.keys()):
                return CypherBool(False)
            has_null = False
            for key in self.value:
                result = self.value[key].equals(other.value[key])
                if isinstance(result, CypherNull):
                    has_null = True
                elif not result.value:
                    return CypherBool(False)
            return CypherNull() if has_null else CypherBool(True)

        if self.type == CypherType.PATH:
            # Path equality: same nodes and relationships in same order
            # Cast to CypherPath for type safety
            if not isinstance(other, CypherPath):
                return CypherBool(False)
            self_path = self if isinstance(self, CypherPath) else None
            other_path = other if isinstance(other, CypherPath) else None
            if self_path is None or other_path is None:
                return CypherBool(False)

            # Compare lengths first
            if len(self_path.nodes) != len(other_path.nodes):
                return CypherBool(False)

            # Compare node IDs (identity-based)
            for n1, n2 in zip(self_path.nodes, other_path.nodes):
                if n1.id != n2.id:
                    return CypherBool(False)

            # Compare relationship IDs (identity-based)
            for r1, r2 in zip(self_path.relationships, other_path.relationships):
                if r1.id != r2.id:
                    return CypherBool(False)

            return CypherBool(True)

        return CypherBool(False)

    def to_python(self) -> Any:
        """Convert this Cypher value to a Python value."""
        if self.type == CypherType.NULL:
            return None
        if self.type == CypherType.LIST:
            return [item.to_python() for item in self.value]
        if self.type == CypherType.MAP:
            return {key: val.to_python() for key, val in self.value.items()}
        if self.type == CypherType.PATH:
            # Return dict with nodes and relationships
            if isinstance(self, CypherPath):
                return {"nodes": self.nodes, "relationships": self.relationships}
            return self.value
        # Temporal types already store Python datetime/timedelta objects
        return self.value

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.value!r})"


class CypherNull(CypherValue):
    """Represents NULL in openCypher."""

    def __init__(self):
        super().__init__(None, CypherType.NULL)


class CypherBool(CypherValue):
    """Represents a boolean value in openCypher."""

    def __init__(self, value: bool):
        super().__init__(value, CypherType.BOOLEAN)


class CypherInt(CypherValue):
    """Represents an integer value in openCypher."""

    def __init__(self, value: int):
        super().__init__(value, CypherType.INTEGER)


class CypherFloat(CypherValue):
    """Represents a floating-point value in openCypher."""

    def __init__(self, value: float):
        super().__init__(value, CypherType.FLOAT)


class CypherString(CypherValue):
    """Represents a string value in openCypher."""

    def __init__(self, value: str):
        super().__init__(value, CypherType.STRING)


class _WideDate:
    """Thin replacement for datetime.date for years outside 1-9999.

    Stores (year, month, day) as plain ints.  Only used by CypherDate when
    the year is out of Python's datetime.date range.
    """

    __slots__ = ("day", "month", "year")

    def __init__(self, year: int, month: int, day: int) -> None:
        self.year = year
        self.month = month
        self.day = day

    def isoformat(self) -> str:
        sign = "-" if self.year < 0 else "+"
        return f"{sign}{abs(self.year):09d}-{self.month:02d}-{self.day:02d}"

    def __repr__(self) -> str:
        return f"_WideDate({self.year}, {self.month}, {self.day})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _WideDate):
            return (self.year, self.month, self.day) == (other.year, other.month, other.day)
        return NotImplemented

    def __hash__(self) -> int:
        return hash((self.year, self.month, self.day))


def _parse_iso_date_part(s: str) -> "datetime.date | _WideDate":
    """Parse a (possibly compact) ISO 8601 date string to datetime.date.

    Handles all openCypher date string formats including compact variants
    not supported by dateutil: ordinal (YYYYDDD), week (YYYYWww[D]),
    year-month (YYYYMM), and year-only (YYYY).
    """
    # Extended ISO year with ± prefix or >4 year digits: ±NNNNNNNNN-MM-DD
    m = re.match(r"^([+-]?\d{5,}|\-\d{4,})-(\d{2})-(\d{2})$", s)
    if m:
        year = int(m.group(1))
        month, day = int(m.group(2)), int(m.group(3))
        if 1 <= year <= 9999:
            return datetime.date(year, month, day)
        return _WideDate(year, month, day)
    # Also handle explicit '+YYYY-MM-DD' with 4-digit year
    m = re.match(r"^\+(\d{4})-(\d{2})-(\d{2})$", s)
    if m:
        return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    # Standard extended form YYYY-MM-DD or basic 8-digit YYYYMMDD — let dateutil handle
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s) or re.match(r"^\d{8}$", s):
        return dateutil_parser.parse(s).date()

    # Year-only: YYYY
    if re.match(r"^\d{4}$", s):
        return datetime.date(int(s), 1, 1)

    # Year-month with separator: YYYY-MM
    m = re.match(r"^(\d{4})-(\d{2})$", s)
    if m:
        return datetime.date(int(m.group(1)), int(m.group(2)), 1)

    # Year-month compact: YYYYMM (exactly 6 digits)
    m = re.match(r"^(\d{4})(\d{2})$", s)
    if m:
        return datetime.date(int(m.group(1)), int(m.group(2)), 1)

    # Ordinal with separator: YYYY-DDD
    m = re.match(r"^(\d{4})-(\d{3})$", s)
    if m:
        year, ordinal = int(m.group(1)), int(m.group(2))
        max_ordinal = 366 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 365
        if ordinal < 1 or ordinal > max_ordinal:
            raise ValueError(f"ordinal {ordinal} is out of range for year {year} (1-{max_ordinal})")
        return datetime.date(year, 1, 1) + datetime.timedelta(days=ordinal - 1)

    # Ordinal compact: YYYYDDD (exactly 7 digits)
    m = re.match(r"^(\d{4})(\d{3})$", s)
    if m:
        year, ordinal = int(m.group(1)), int(m.group(2))
        max_ordinal = 366 if (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)) else 365
        if ordinal < 1 or ordinal > max_ordinal:
            raise ValueError(f"ordinal {ordinal} is out of range for year {year} (1-{max_ordinal})")
        return datetime.date(year, 1, 1) + datetime.timedelta(days=ordinal - 1)

    # Week date with separators and day: YYYY-Www-D
    m = re.match(r"^(\d{4})-W(\d{2})-(\d)$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    # Week date compact with day: YYYYWwwD
    m = re.match(r"^(\d{4})W(\d{2})(\d)$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    # Week date with separator, no day: YYYY-Www → Monday of that week
    m = re.match(r"^(\d{4})-W(\d{2})$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)

    # Week date compact, no day: YYYYWww → Monday of that week
    m = re.match(r"^(\d{4})W(\d{2})$", s)
    if m:
        return datetime.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)

    # Fall back to dateutil for anything else
    return dateutil_parser.parse(s).date()


def _normalize_compact_time(t: str) -> str:
    """Expand a compact ISO 8601 time string to HH:MM:SS[.fff][tz] form.

    Handles: HH, HHMM, HHMMSS, HHMMSS.fff (with optional trailing timezone).
    Strings already containing ':' are returned unchanged.
    """
    # Extract trailing timezone: Z, +HH:MM, +HHMM, -HH, etc.
    tz_match = re.search(r"([+-]\d{2}:?\d{2}|[+-]\d{2}|Z)$", t)
    tz = tz_match.group(0) if tz_match else ""
    if tz_match is not None:
        t = t[: tz_match.start()]

    # Normalize compact offsets: +HHMM → +HH:MM, +HH → +HH:00
    if tz and tz != "Z":
        off_m = re.match(r"^([+-])(\d{2})(\d{2})?$", tz)
        if off_m:
            tz = f"{off_m.group(1)}{off_m.group(2)}:{off_m.group(3) or '00'}"

    # If already colon-separated, leave the time digits alone
    if ":" in t:
        return t + tz

    # Split fractional seconds — only HHMMSS.fff is a valid compact form
    frac = ""
    if "." in t:
        t, frac_part = t.split(".", 1)
        if len(t) != 6:
            raise ValueError(
                f"fractional compact time is only valid for HHMMSS.fff form, got {len(t)!r} digits"
            )
        frac = "." + frac_part

    if len(t) == 2:  # HH
        return f"{t}:00:00{frac}{tz}"
    if len(t) == 4:  # HHMM
        return f"{t[:2]}:{t[2:4]}:00{frac}{tz}"
    if len(t) == 6:  # HHMMSS
        return f"{t[:2]}:{t[2:4]}:{t[4:6]}{frac}{tz}"
    raise ValueError(f"unsupported compact time length {len(t)} for input: {t!r}")


def _extract_ns_from_str(s: str) -> "tuple[str, int]":
    """Extract sub-microsecond nanosecond residue from an ISO temporal string.

    Returns (cleaned_string, ns_residue) where cleaned_string has at most 6
    fractional digits (so Python datetime can parse it) and ns_residue is the
    3-digit sub-microsecond remainder (0-999).
    """
    import re as _re

    m = _re.search(r"\.\d{6}(\d{1,3})", s)
    if not m:
        return s, 0
    extra = m.group(1).ljust(3, "0")[:3]
    ns = int(extra)
    # Remove the extra digits from the string
    cleaned = s[: m.start(1)] + s[m.end(1) :]
    return cleaned, ns


class _WideDateTime:
    """Thin replacement for datetime.datetime for years outside 1-9999.

    Stores (year, month, day, hour, minute, second, microsecond) as plain ints.
    tzinfo is always None (naive).
    """

    __slots__ = ("day", "hour", "microsecond", "minute", "month", "second", "year")

    def __init__(
        self,
        year: int,
        month: int,
        day: int,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
        microsecond: int = 0,
    ) -> None:
        self.year = year
        self.month = month
        self.day = day
        self.hour = hour
        self.minute = minute
        self.second = second
        self.microsecond = microsecond

    @property
    def tzinfo(self) -> None:
        return None

    def isoformat(self) -> str:
        sign = "-" if self.year < 0 else "+"
        base = (
            f"{sign}{abs(self.year):09d}-{self.month:02d}-{self.day:02d}"
            f"T{self.hour:02d}:{self.minute:02d}:{self.second:02d}"
        )
        if self.microsecond:
            base += f".{self.microsecond:06d}"
        return base

    def __repr__(self) -> str:
        return (
            f"_WideDateTime({self.year},{self.month},{self.day},"
            f"{self.hour},{self.minute},{self.second},{self.microsecond})"
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _WideDateTime):
            return (
                self.year,
                self.month,
                self.day,
                self.hour,
                self.minute,
                self.second,
                self.microsecond,
            ) == (
                other.year,
                other.month,
                other.day,
                other.hour,
                other.minute,
                other.second,
                other.microsecond,
            )
        return NotImplemented

    def __hash__(self) -> int:
        return hash(
            (self.year, self.month, self.day, self.hour, self.minute, self.second, self.microsecond)
        )


class CypherDate(CypherValue):
    """Represents a date value in openCypher.

    Stores a Python datetime.date (or _WideDate for years outside 1-9999).
    Supports ISO 8601 date strings.
    """

    def __init__(self, value: "datetime.date | _WideDate | str"):
        if isinstance(value, str):
            value = _parse_iso_date_part(value)
        elif isinstance(value, datetime.datetime):
            value = value.date()
        super().__init__(value, CypherType.DATE)

    def __repr__(self) -> str:
        return f"CypherDate({self.value.isoformat()!r})"


class CypherDateTime(CypherValue):
    """Represents a datetime value in openCypher.

    Stores a Python datetime.datetime object with timezone support.
    Supports ISO 8601 datetime strings including compact variants.

    ``_ns_residue`` (0-999) stores the sub-microsecond nanosecond remainder that
    Python datetime cannot represent natively.
    """

    def __init__(
        self,
        value: "datetime.datetime | _WideDateTime | str",
        _ns_residue: int = 0,
        _iana_tz_name: "str | None" = None,
    ):
        if isinstance(value, str):
            # Extract sub-microsecond nanosecond residue before parsing
            value, str_ns = _extract_ns_from_str(value)
            if str_ns:
                _ns_residue = str_ns

            # Strip optional IANA timezone name suffix: e.g. [Europe/Stockholm]
            iana_m = re.search(r"\[([A-Za-z][A-Za-z0-9/_+\-]*)\]$", value)
            if iana_m:
                _iana_tz_name = iana_m.group(1)
                value = value[: iana_m.start()]

            if "T" in value:
                date_str, time_str = value.split("T", 1)
                date_part = _parse_iso_date_part(date_str)

                if isinstance(date_part, _WideDate):
                    # Wide year: parse time part manually, store as _WideDateTime
                    normalized_time = _normalize_compact_time(
                        re.sub(r"(?:[+-]\d{2}(?::?\d{2}(?::\d{2})?)?|Z)$", "", time_str)
                        if _iana_tz_name is not None
                        else time_str
                    )
                    _tp = dateutil_parser.parse("2000-01-01T" + normalized_time)
                    value = _WideDateTime(
                        date_part.year,
                        date_part.month,
                        date_part.day,
                        _tp.hour,
                        _tp.minute,
                        _tp.second,
                        _tp.microsecond,
                    )
                else:
                    if _iana_tz_name is not None:
                        # IANA zone is authoritative; strip any explicit offset so we can
                        # parse as a naive local time and then attach the named zone.
                        # Handles: Z, ±HH, ±HHMM, ±HH:MM, ±HH:MM:SS (e.g. +00:53:28)
                        time_local = re.sub(
                            r"(?:[+-]\d{2}(?::?\d{2}(?::\d{2})?)?|Z)$", "", time_str
                        )
                        normalized_time = (
                            _normalize_compact_time(time_local) if time_local else "00:00:00"
                        )
                    else:
                        normalized_time = _normalize_compact_time(time_str)

                    normalized = date_part.isoformat() + "T" + normalized_time
                    value = dateutil_parser.parse(normalized)

                    if _iana_tz_name is not None:
                        iana_tz = dateutil_tz.gettz(_iana_tz_name)
                        if iana_tz is None:
                            raise ValueError(f"Unknown IANA timezone: {_iana_tz_name!r}")
                        value = value.replace(tzinfo=iana_tz)
            else:
                # No 'T' — may be a date-only string or wide-year date
                date_only = _parse_iso_date_part(value)
                if isinstance(date_only, _WideDate):
                    value = _WideDateTime(date_only.year, date_only.month, date_only.day)
                else:
                    value = dateutil_parser.parse(value)

        super().__init__(value, CypherType.DATETIME)
        self._ns_residue: int = int(_ns_residue) % 1000
        self._iana_tz_name: str | None = _iana_tz_name

    def __repr__(self) -> str:
        return f"CypherDateTime({self.value.isoformat()!r})"


class CypherTime(CypherValue):
    """Represents a time value in openCypher.

    Stores a Python datetime.time object with timezone support.
    Supports ISO 8601 time strings.

    ``_ns_residue`` (0-999) stores the sub-microsecond nanosecond remainder that
    Python datetime.time cannot represent natively.
    """

    def __init__(self, value: datetime.time | datetime.datetime | str, _ns_residue: int = 0):
        if isinstance(value, str):
            # Extract sub-microsecond nanosecond residue before parsing
            value, str_ns = _extract_ns_from_str(value)
            if str_ns:
                _ns_residue = str_ns
            normalized = _normalize_compact_time(value)
            parsed = dateutil_parser.parse(normalized)
            value = parsed.timetz()
        elif isinstance(value, datetime.datetime):
            # Extract time component with timezone if datetime passed
            value = value.timetz()
        super().__init__(value, CypherType.TIME)
        self._ns_residue: int = int(_ns_residue) % 1000

    def __repr__(self) -> str:
        return f"CypherTime({self.value.isoformat()!r})"


def _parse_neg_component_duration_str(s: str) -> "datetime.timedelta | isodate.Duration":
    """Parse ISO 8601 duration strings that have per-component negative signs.

    isodate only handles a leading overall sign (e.g. -PT1S).  openCypher uses
    per-component signs (e.g. PT-1S, P1DT-0.001S).  Returns a timedelta or
    isodate.Duration.
    """
    import math
    import re

    m = re.match(
        r"^(-?)P"
        r"(?:(-?\d+(?:\.\d+)?)Y)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)W)?"
        r"(?:(-?\d+(?:\.\d+)?)D)?"
        r"(?:T"
        r"(?:(-?\d+(?:\.\d+)?)H)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)S)?"
        r")?$",
        s,
    )
    if not m:
        raise ValueError(f"Unrecognised ISO 8601 duration format: {s!r}")
    overall_sign = -1 if m.group(1) == "-" else 1
    years = float(m.group(2) or 0) * overall_sign
    months = float(m.group(3) or 0) * overall_sign
    weeks = float(m.group(4) or 0) * overall_sign
    days = float(m.group(5) or 0) * overall_sign
    hours = float(m.group(6) or 0) * overall_sign
    minutes = float(m.group(7) or 0) * overall_sign
    seconds = float(m.group(8) or 0) * overall_sign
    years_i = math.trunc(years)
    months_i = math.trunc(months)
    if years_i != 0 or months_i != 0:
        # Fractional parts of years/months cascade into the time component,
        # using the same average-month/year convention as the map constructor.
        frac_years = years - years_i
        frac_months = months - months_i
        frac_seconds = (frac_years * 365.2425 + frac_months * (365.2425 / 12)) * 86400
        total_us = round(
            ((weeks * 7 + days) * 86400 + hours * 3600 + minutes * 60 + seconds + frac_seconds)
            * 1_000_000
        )
        td = datetime.timedelta(microseconds=total_us)
        return isodate.Duration(
            years=years_i,
            months=months_i,
            days=td.days,
            seconds=td.seconds,
            microseconds=td.microseconds,
        )
    total_us = round(
        ((weeks * 7 + days) * 86400 + hours * 3600 + minutes * 60 + seconds) * 1_000_000
    )
    try:
        return datetime.timedelta(microseconds=total_us)
    except OverflowError:
        # Values too large for timedelta — store as _BigDuration with explicit components
        h_i = int(hours)
        mi_i = int(minutes)
        s_i = int(seconds)
        us_i = round((abs(seconds) - abs(s_i)) * 1_000_000) * (1 if seconds >= 0 else -1)
        return _BigDuration(
            years=0,
            months=0,
            days=int(days + weeks * 7),
            hours=h_i,
            minutes=mi_i,
            seconds=s_i,
            microseconds=us_i,
        )


def _trunc_div(total: int, unit: int) -> "tuple[int, int]":
    """Truncation-toward-zero division with remainder sharing the sign of total."""
    if total >= 0:
        return divmod(total, unit)
    q_abs, r_abs = divmod(-total, unit)
    return (-q_abs, 0) if r_abs == 0 else (-q_abs, -r_abs)


def _components_from_string(s: str) -> "tuple[int, int, int, int, int, int, int, int] | None":
    """Derive canonical components directly from an ISO 8601 duration string.

    Unlike _components_from_value, this preserves the days/time boundary as
    written in the string and handles per-component negative signs correctly
    (e.g. ``PT-59.999S`` → seconds=-59, us=-999000, NOT days=-1, hours=23…).
    Returns None if the string cannot be parsed.

    Returns (years, months, days, hours, minutes, seconds, microseconds, nanoseconds).
    Nanoseconds captures sub-microsecond precision from strings with 9 fractional digits.
    """
    import math
    import re

    m = re.match(
        r"^(-?)P"
        r"(?:(-?\d+(?:\.\d+)?)Y)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)W)?"
        r"(?:(-?\d+(?:\.\d+)?)D)?"
        r"(?:T"
        r"(?:(-?\d+(?:\.\d+)?)H)?"
        r"(?:(-?\d+(?:\.\d+)?)M)?"
        r"(?:(-?\d+(?:\.\d+)?)S)?"
        r")?$",
        s,
    )
    if not m:
        return None
    overall_sign = -1 if m.group(1) == "-" else 1
    years_f = float(m.group(2) or 0) * overall_sign
    months_f = float(m.group(3) or 0) * overall_sign
    weeks_f = float(m.group(4) or 0) * overall_sign
    days_f = float(m.group(5) or 0) * overall_sign
    hours_f = float(m.group(6) or 0) * overall_sign
    minutes_f = float(m.group(7) or 0) * overall_sign
    seconds_str = m.group(8)  # keep raw string for precision
    seconds_f = float(seconds_str or 0) * overall_sign

    years_i = math.trunc(years_f)
    months_f += (years_f - years_i) * 12.0
    months_i = math.trunc(months_f)
    days_f += (months_f - months_i) * 30.436875 + weeks_f * 7.0
    days_i = math.trunc(days_f)

    # Time part at nanosecond precision: use integer arithmetic on the seconds string
    # to avoid float rounding for sub-microsecond parts.
    time_us = round(
        ((days_f - days_i) * 86_400 + hours_f * 3_600 + minutes_f * 60 + seconds_f) * 1_000_000
    )
    # Extract sub-microsecond nanoseconds from seconds string (7th-9th decimal digits)
    ns_residue = 0
    if seconds_str:
        dot_idx = seconds_str.find(".")
        if dot_idx >= 0:
            frac = seconds_str[dot_idx + 1 :].ljust(9, "0")[:9]
            # digits 7-9 are the sub-microsecond nanoseconds
            ns_digits = frac[6:9] if len(frac) >= 7 else ""
            if ns_digits:
                ns_residue = int(ns_digits.ljust(3, "0")[:3]) * overall_sign

    canon_h, rem_us = _trunc_div(time_us, 3_600_000_000)
    canon_m, rem_us = _trunc_div(rem_us, 60_000_000)
    canon_s, canon_us = _trunc_div(rem_us, 1_000_000)
    return (years_i, months_i, days_i, canon_h, canon_m, canon_s, canon_us, ns_residue)


def _components_from_value(
    value: "datetime.timedelta | isodate.Duration | _BigDuration",
) -> tuple[int, int, int, int, int, int, int, int]:
    """Derive canonical (years, months, days, hours, minutes, seconds, microseconds, nanoseconds)
    from a timedelta, isodate.Duration, or _BigDuration.

    The days/time boundary is preserved as stored in the timedelta.days field.
    Time is normalised within the time part (seconds→minutes→hours) but hours
    are NOT absorbed into days.  This matches openCypher equality semantics
    where 13D+40H != 14D+16H.
    nanoseconds is always 0 here — it must be set separately from the map constructor.
    """
    if isinstance(value, _BigDuration):
        return (
            value.years,
            value.months,
            value.days,
            value.hours,
            value.minutes,
            value.seconds,
            value.microseconds,
            0,
        )
    if isinstance(value, isodate.Duration):
        years = int(getattr(value, "years", 0) or 0)
        months = int(getattr(value, "months", 0) or 0)
        td = value.tdelta if hasattr(value, "tdelta") else datetime.timedelta()
    else:
        years = 0
        months = 0
        td = value
    # Python timedelta normalises negative durations so that .days is always
    # negative and .seconds/.microseconds are always non-negative (e.g. -PT22H
    # becomes days=-1, seconds=7200).  openCypher uses truncation-toward-zero
    # semantics: keep the day part as written and express the remainder with its
    # natural sign.  We reconstruct total microseconds and decompose with
    # _trunc_div to recover the openCypher-expected representation.
    total_us = (td.days * 86_400 + td.seconds) * 1_000_000 + td.microseconds
    # For isodate.Duration the days part is authoritative; keep it and compute
    # the pure time microseconds as the remainder.
    if isinstance(value, isodate.Duration):
        d = td.days
        time_us = (td.seconds * 1_000_000) + td.microseconds
        if td.seconds < 0 or (td.seconds == 0 and td.microseconds < 0):
            # Already negative normalisation inside isodate — recompute from total
            time_us = total_us - d * 86_400_000_000
    else:
        # Pure timedelta: decompose total_us with truncation-toward-zero so that
        # the days component reflects the logical date boundary and the time part
        # keeps its sign (e.g. -PT22H → days=0, hours=-22).
        d, time_us = _trunc_div(total_us, 86_400_000_000)
    canon_h, rem_us = _trunc_div(time_us, 3_600_000_000)
    canon_m, rem_us = _trunc_div(rem_us, 60_000_000)
    canon_s, canon_us = _trunc_div(rem_us, 1_000_000)
    return (years, months, d, canon_h, canon_m, canon_s, canon_us, 0)


class _BigDuration:
    """Overflow-safe duration for values that exceed timedelta/isodate.Duration capacity.

    Stores (years, months, days, hours, minutes, seconds, microseconds) as Python ints.
    Used as CypherDuration.value when the duration is too large for timedelta.
    Compared component-wise; isoformat() produces ISO 8601 output.
    """

    __slots__ = ("days", "hours", "microseconds", "minutes", "months", "seconds", "years")

    def __init__(
        self,
        years: int = 0,
        months: int = 0,
        days: int = 0,
        hours: int = 0,
        minutes: int = 0,
        seconds: int = 0,
        microseconds: int = 0,
    ) -> None:
        self.years = years
        self.months = months
        self.days = days
        self.hours = hours
        self.minutes = minutes
        self.seconds = seconds
        self.microseconds = microseconds

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _BigDuration):
            return (
                self.years,
                self.months,
                self.days,
                self.hours,
                self.minutes,
                self.seconds,
                self.microseconds,
            ) == (
                other.years,
                other.months,
                other.days,
                other.hours,
                other.minutes,
                other.seconds,
                other.microseconds,
            )
        return NotImplemented

    def __hash__(self) -> int:
        return hash(
            (
                self.years,
                self.months,
                self.days,
                self.hours,
                self.minutes,
                self.seconds,
                self.microseconds,
            )
        )

    def __repr__(self) -> str:
        return (
            f"_BigDuration(years={self.years},months={self.months},days={self.days},"
            f"hours={self.hours},minutes={self.minutes},seconds={self.seconds},"
            f"microseconds={self.microseconds})"
        )


class CypherDuration(CypherValue):
    """Represents a duration value in openCypher.

    Stores a Python datetime.timedelta, isodate.Duration, or _BigDuration object.
    Supports ISO 8601 duration strings. When parsing ISO 8601 strings with
    years/months (e.g., "P1Y2M"), stores an isodate.Duration; otherwise stores
    a datetime.timedelta.

    The ``_components`` attribute holds
    (years, months, days, hours, minutes, seconds, microseconds, nanoseconds)
    where ``days`` is NOT normalized from hours.  This is used for
    component-wise equality per the openCypher spec.
    """

    def __init__(
        self,
        value: "datetime.timedelta | isodate.Duration | str",
        _components: "tuple[int,int,int,int,int,int,int,int] | None" = None,
    ):
        if isinstance(value, str):
            # Parse ISO 8601 duration string.  isodate does not support per-component
            # negative signs (e.g. "P1DT-0.001S"), so we fall back to a manual parser.
            # Derive _components directly from the string to preserve the days/time
            # boundary and per-component signs (Python timedelta normalisation loses
            # these for negative durations like PT-59.999S).
            original_str = value
            if _components is None:
                _components = _components_from_string(original_str)
            try:
                value = isodate.parse_duration(value)
            except (ValueError, isodate.isoerror.ISO8601Error, OverflowError):
                value = _parse_neg_component_duration_str(value)
        super().__init__(value, CypherType.DURATION)
        # Store canonical components for equality.  Caller may supply them
        # explicitly to preserve the original days/hours boundary.
        self._components: tuple[int, int, int, int, int, int, int, int] = (
            _components if _components is not None else _components_from_value(value)
        )
        # When the canonical components have no years or months (e.g. "P0.75M"
        # normalises to days only) but the stored value is still an isodate.Duration
        # with fractional months, replace it with a plain timedelta so that
        # value-based comparisons (used by the TCK harness) return the right result.
        if (
            isinstance(self.value, isodate.Duration)
            and self._components[0] == 0  # years
            and self._components[1] == 0  # months
        ):
            import contextlib

            _, _, d, h, m, s, us, _ns = self._components
            with contextlib.suppress(OverflowError):
                self.value = datetime.timedelta(
                    days=d, hours=h, minutes=m, seconds=s, microseconds=us
                )

    def equals(self, other: "CypherValue") -> "CypherValue":
        """Duration equality is component-wise per openCypher spec.

        Two durations are equal only if all canonical components match:
        years, months, days, hours, minutes, seconds, microseconds, nanoseconds.
        Unlike elapsed-time equality, 13D+40H != 14D+16H.
        """
        if isinstance(other, CypherNull):
            return CypherNull()
        if not isinstance(other, CypherDuration):
            return CypherBool(False)
        return CypherBool(self._components == other._components)

    def __repr__(self) -> str:
        if isinstance(self.value, _BigDuration):
            return f"CypherDuration({self.value!r})"
        return f"CypherDuration({isodate.duration_isoformat(self.value)!r})"


class CypherPoint(CypherValue):
    """Represents a point value in openCypher.

    Stores a dictionary with coordinate information. Supports:
    - 2D Cartesian: {"x": float, "y": float, "crs": "cartesian"}
    - 3D Cartesian: {"x": float, "y": float, "z": float, "crs": "cartesian-3d"}
    - WGS84 Geographic: {"latitude": float, "longitude": float, "crs": "wgs-84"}

    The coordinate reference system (crs) is optional and inferred from keys.
    """

    def __init__(self, coordinates: dict[str, float]):
        """Initialize a point from coordinate dictionary.

        Args:
            coordinates: Dict with coordinate keys (x/y or latitude/longitude)

        Raises:
            ValueError: If coordinates are invalid or incomplete
        """
        # Validate and normalize coordinates
        if "x" in coordinates and "y" in coordinates:
            # Cartesian coordinates
            x = float(coordinates["x"])
            y = float(coordinates["y"])
            if "z" in coordinates:
                # 3D Cartesian
                z = float(coordinates["z"])
                value = {"x": x, "y": y, "z": z, "crs": "cartesian-3d"}
            else:
                # 2D Cartesian
                value = {"x": x, "y": y, "crs": "cartesian"}
        elif "latitude" in coordinates and "longitude" in coordinates:
            # Geographic coordinates (WGS-84)
            lat = float(coordinates["latitude"])
            lon = float(coordinates["longitude"])
            # Validate latitude/longitude ranges
            if not -90 <= lat <= 90:
                raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
            if not -180 <= lon <= 180:
                raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
            value = {"latitude": lat, "longitude": lon, "crs": "wgs-84"}
        else:
            raise ValueError(
                "Point requires either (x, y) or (latitude, longitude) coordinates, "
                f"got: {list(coordinates.keys())}"
            )

        super().__init__(value, CypherType.POINT)

    def __repr__(self) -> str:
        return f"CypherPoint({self.value!r})"


class CypherDistance(CypherValue):
    """Represents a distance value in openCypher.

    Stores a float representing the Euclidean distance between two points.
    For WGS-84 points, uses the Haversine formula to compute great-circle distance.
    """

    def __init__(self, value: float):
        """Initialize a distance value.

        Args:
            value: Distance as a float (must be non-negative)

        Raises:
            ValueError: If distance is negative
        """
        if value < 0:
            raise ValueError(f"Distance must be non-negative, got {value}")
        super().__init__(float(value), CypherType.DISTANCE)

    def __repr__(self) -> str:
        return f"CypherDistance({self.value})"


class CypherList(CypherValue):
    """Represents a list value in openCypher."""

    def __init__(self, value: list["CypherValue"]):
        super().__init__(value, CypherType.LIST)


class CypherMap(CypherValue):
    """Represents a map (dictionary) value in openCypher."""

    def __init__(self, value: dict[str, "CypherValue"]):
        super().__init__(value, CypherType.MAP)


class CypherPath(CypherValue):
    """Represents a path through the graph.

    A path consists of an alternating sequence of nodes and relationships:
    node -> edge -> node -> edge -> node

    Attributes:
        nodes: List of NodeRef objects in the path (N nodes)
        relationships: List of EdgeRef objects connecting the nodes (N-1 relationships)

    The path structure ensures that:
    - len(relationships) == len(nodes) - 1
    - relationships[i] connects nodes[i] to nodes[i+1]

    Examples:
        >>> # Path with 3 nodes: A -> B -> C
        >>> path = CypherPath(
        ...     nodes=[node_a, node_b, node_c],
        ...     relationships=[edge_ab, edge_bc]
        ... )
        >>> path.length()  # Number of relationships
        2
        >>> len(path.nodes)
        3
    """

    def __init__(self, nodes: list["NodeRef"], relationships: list["EdgeRef"]):
        """Initialize a path from nodes and relationships.

        Args:
            nodes: List of NodeRef objects in the path
            relationships: List of EdgeRef objects connecting the nodes

        Raises:
            ValueError: If path structure is invalid
        """
        from graphforge.types.graph import EdgeRef, NodeRef

        # Validate types
        if not all(isinstance(n, NodeRef) for n in nodes):
            raise TypeError("All nodes must be NodeRef instances")
        if not all(isinstance(r, EdgeRef) for r in relationships):
            raise TypeError("All relationships must be EdgeRef instances")

        # Validate path structure
        if len(nodes) == 0:
            raise ValueError("Path must contain at least one node")
        if len(relationships) != len(nodes) - 1:
            raise ValueError(
                f"Path must have exactly len(nodes)-1 relationships: "
                f"got {len(nodes)} nodes and {len(relationships)} relationships"
            )

        # Validate connectivity
        for i, rel in enumerate(relationships):
            node_a = nodes[i]
            node_b = nodes[i + 1]
            # Check that relationship connects consecutive nodes
            # Allow traversal in either direction (for undirected or reversed patterns)
            forward_match = rel.src.id == node_a.id and rel.dst.id == node_b.id
            reverse_match = rel.src.id == node_b.id and rel.dst.id == node_a.id

            if not (forward_match or reverse_match):
                raise ValueError(
                    f"Relationship at index {i} does not connect nodes {i} and {i + 1}: "
                    f"relationship goes from {rel.src.id} to {rel.dst.id}, "
                    f"but path expects connection between {node_a.id} and {node_b.id}"
                )

        # Store as tuple for immutability
        self.nodes = nodes
        self.relationships = relationships

        # Store tuple of (nodes, relationships) as value for compatibility
        super().__init__((tuple(nodes), tuple(relationships)), CypherType.PATH)

    def length(self) -> int:
        """Return the length of the path (number of relationships)."""
        return len(self.relationships)

    def __repr__(self) -> str:
        """Readable string representation."""
        node_ids = " -> ".join(str(n.id) for n in self.nodes)
        return f"CypherPath([{node_ids}], length={self.length()})"


def from_python(value: Any) -> CypherValue:
    """Convert a Python value to a CypherValue.

    Args:
        value: Python value to convert

    Returns:
        Appropriate CypherValue subclass

    Raises:
        TypeError: If the value type is not supported
    """
    if value is None:
        return CypherNull()
    if isinstance(value, bool):
        return CypherBool(value)
    if isinstance(value, int):
        return CypherInt(value)
    if isinstance(value, float):
        return CypherFloat(value)
    if isinstance(value, str):
        return CypherString(value)
    # Temporal types (check datetime before date since datetime is subclass of date)
    if isinstance(value, datetime.datetime):
        return CypherDateTime(value)
    if isinstance(value, datetime.date):
        return CypherDate(value)
    if isinstance(value, datetime.time):
        return CypherTime(value)
    if isinstance(value, datetime.timedelta):
        return CypherDuration(value)
    # Collections
    if isinstance(value, list):
        return CypherList([from_python(item) for item in value])
    if isinstance(value, dict):
        return CypherMap({key: from_python(val) for key, val in value.items()})

    raise TypeError(f"Cannot convert Python type {type(value).__name__} to CypherValue")
