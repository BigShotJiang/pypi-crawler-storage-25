"""Type tracking for variables in query plans.

This module provides variable type tracking to detect type conflicts at compile time.
For example, a variable bound to a scalar value in WITH cannot be used as a node
in a subsequent MATCH clause.
"""

from enum import Enum


class VariableType(Enum):
    """Types for variables in query plans."""

    NODE = "node"
    RELATIONSHIP = "relationship"
    PATH = "path"
    SCALAR = "scalar"  # int, str, bool, list, map, etc.
    UNKNOWN = "unknown"  # For variables we haven't analyzed yet


class TypeContext:
    """Tracks variable types across query clauses."""

    def __init__(self):
        """Initialize an empty type context."""
        self._types: dict[str, VariableType] = {}
        # Variables from UNWIND whose element type is unknown at plan time (could be nodes)
        self._unwind_vars: set[str] = set()

    def bind_variable(self, name: str, var_type: VariableType) -> None:
        """Register a variable with its type.

        Args:
            name: Variable name
            var_type: Type of the variable
        """
        self._types[name] = var_type
        # Remove from UNWIND exemption set if the variable is rebound to a known type
        self._unwind_vars.discard(name)

    def bind_unwind_variable(self, name: str) -> None:
        """Register an UNWIND-produced variable as SCALAR with unknown element type.

        UNWIND list elements may be nodes/relationships at runtime, so they are
        exempt from VariableTypeConflict when used in node/relationship positions.
        """
        self._types[name] = VariableType.SCALAR
        self._unwind_vars.add(name)

    def get_type(self, name: str) -> VariableType:
        """Get the type of a variable.

        Args:
            name: Variable name

        Returns:
            VariableType for the variable, or UNKNOWN if not found
        """
        return self._types.get(name, VariableType.UNKNOWN)

    def has_variable(self, name: str) -> bool:
        """Check if a variable has been bound.

        Args:
            name: Variable name

        Returns:
            True if variable is bound, False otherwise
        """
        return name in self._types

    def validate_compatible(
        self, name: str, expected_type: VariableType, optional_context: bool = False
    ) -> None:
        """Validate that a variable can be used in a context requiring expected_type.

        Args:
            name: Variable name
            expected_type: Expected type for the variable
            optional_context: True when inside OPTIONAL MATCH; allows SCALAR (null)
                variables in node/relationship positions since the executor handles
                null values at runtime (e.g. WITH null AS a OPTIONAL MATCH (a)).

        Raises:
            SyntaxError: If variable type conflicts with expected type
        """
        actual_type = self.get_type(name)

        if actual_type == VariableType.UNKNOWN:
            # Variable not yet bound, will be bound by this usage
            return

        if actual_type != expected_type:
            # SCALAR variables from UNWIND (element type unknown at plan time) or from
            # OPTIONAL MATCH null-fills may hold node/relationship values at runtime.
            if (
                actual_type == VariableType.SCALAR
                and expected_type in (VariableType.NODE, VariableType.RELATIONSHIP)
                and (optional_context or name in self._unwind_vars)
            ):
                return
            raise SyntaxError(
                f"VariableTypeConflict: Variable `{name}` already bound to type "
                f"{actual_type.value}, cannot be used as {expected_type.value}"
            )

    def bound_variables(self) -> set[str]:
        """Return the set of all currently bound variable names."""
        return set(self._types.keys())

    def copy(self) -> "TypeContext":
        """Create a copy of this context for new query segments.

        Returns:
            New TypeContext with copied variable types
        """
        new_context = TypeContext()
        new_context._types = self._types.copy()
        new_context._unwind_vars = self._unwind_vars.copy()
        return new_context
