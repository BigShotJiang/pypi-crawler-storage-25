"""Query planner that converts AST to logical plans.

This module converts parsed AST into executable logical plans.
"""

from typing import Any

from graphforge.ast.clause import (
    CallClause,
    CreateClause,
    DeleteClause,
    LimitClause,
    MatchClause,
    MergeClause,
    OptionalMatchClause,
    OrderByClause,
    RemoveClause,
    ReturnClause,
    SetClause,
    SkipClause,
    UnwindClause,
    WhereClause,
    WithClause,
)
from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    FunctionCall,
    ListComprehension,
    Literal,
    ParenthesizedExpr,
    PropertyAccess,
    SubqueryExpression,
    Subscript,
    UnaryOp,
    Variable,
)
from graphforge.ast.pattern import Direction, NodePattern, RelationshipPattern
from graphforge.ast.query import CypherQuery
from graphforge.planner.operators import (
    Aggregate,
    Call,
    Create,
    Delete,
    ExpandEdges,
    Filter,
    Limit,
    Merge,
    OptionalExpandEdges,
    ProcedureCall,
    Project,
    Remove,
    ScanNodes,
    Set,
    Skip,
    Sort,
    Union,
    Unwind,
    With,
)
from graphforge.planner.types import TypeContext, VariableType


class QueryPlanner:
    """Plans query execution from AST."""

    def __init__(self, procedure_registry=None):
        """
        Create a QueryPlanner and initialize its internal planning state.

        Parameters:
            procedure_registry (optional): Registry used to resolve procedure signatures and
                scoping rules for CALL ... YIELD; may be None.

        Attributes initialized:
            _anon_counter (int): Counter for generating unique anonymous variable names.
            _type_context (TypeContext): Per-planner compile-time type context.
            _procedure_registry: The provided procedure registry or None.
            _proc_unscoped_outputs (set[str]): Procedure output names produced without an
                explicit YIELD (tracked for later scope validation).
            _extra_function_names (set[str]): Per-instance set of additional function names
                registered via register_extra_function.
        """
        self._anon_counter = 0
        self._type_context = TypeContext()
        self._procedure_registry = procedure_registry
        # Variables that exist as procedure outputs but weren't YIELDed (not in scope)
        self._proc_unscoped_outputs: set[str] = set()
        # Per-instance extra functions (from register_extra_function)
        self._extra_function_names: set[str] = set()

    def _generate_anonymous_variable(self) -> str:
        """
        Produce a unique internal variable name for anonymous pattern variables.

        Returns:
            variable_name (str): Unique internal variable name in the form '__anon_N' where N
                is an incrementing integer.
        """
        var = f"__anon_{self._anon_counter}"
        self._anon_counter += 1
        return var

    def plan(self, ast: CypherQuery, outer_scope_vars: set[str] | None = None) -> list[Any]:
        """Convert AST to logical plan operators.

        Operators are ordered for correct execution:
        1. MATCH (scan/expand)
        2. WHERE (filter)
        3. WITH (pipeline boundary) - optional
        4. ORDER BY (sort) - before projection to access all variables
        5. RETURN (project)
        6. SKIP/LIMIT

        Args:
            ast: Parsed query AST
            outer_scope_vars: Variable names visible from an enclosing (correlated) scope,
                e.g. outer MATCH variables visible inside an EXISTS subquery.

        Returns:
            List of logical plan operators
        """
        from graphforge.planner.types import TypeContext, VariableType

        # Reset type context for new query
        self._type_context = TypeContext()
        # Pre-declare outer-scope variables so correlated subqueries don't fail validation
        if outer_scope_vars:
            for v in outer_scope_vars:
                self._type_context.bind_variable(v, VariableType.UNKNOWN)
        self._proc_unscoped_outputs = set()

        # Validate boolean operator operands across all expressions
        self._validate_all_boolean_operands(ast)

        # Validate EXISTS subqueries contain no write clauses
        self._validate_exists_subqueries(ast)

        # Validate path variable does not collide with node/rel variable in same pattern
        self._validate_path_variable_conflicts(ast)

        # Check if query contains WITH clauses
        has_with = any(isinstance(c, WithClause) for c in ast.clauses)

        if has_with:
            # Split query at WITH boundaries and plan each segment
            return self._plan_with_query(ast)
        # Use traditional single-pass planning
        return self._plan_simple_query(ast.clauses)

    def _plan_simple_query(self, clauses: list, has_following_clauses: bool = False) -> list:
        """
        Plan a query segment that contains no WITH boundaries by emitting an ordered list of
        logical plan operators.

        Parameters:
            clauses (list): Sequence of clause AST nodes comprising the query segment to plan.
            has_following_clauses (bool): True when this segment is followed by additional
                clauses (e.g., a subsequent WITH), influencing CALL standalone vs in-query
                behaviour and related validations.

        Returns:
            operators (list): Ordered logical plan operators representing the execution plan
                for the given clauses.
        """
        # Collect clauses by type
        match_clauses = []
        optional_match_clauses = []
        unwind_clauses = []
        call_clauses = []
        create_clauses = []
        merge_clauses = []
        where_clause = None
        return_clause = None
        order_by_clause = None
        skip_clause = None
        limit_clause = None

        for clause in clauses:
            if isinstance(clause, MatchClause):
                match_clauses.append(clause)
            elif isinstance(clause, OptionalMatchClause):
                optional_match_clauses.append(clause)
            elif isinstance(clause, UnwindClause):
                unwind_clauses.append(clause)
            elif isinstance(clause, CallClause):
                call_clauses.append(clause)
            elif isinstance(clause, CreateClause):
                create_clauses.append(clause)
            elif isinstance(clause, MergeClause):
                merge_clauses.append(clause)
            elif isinstance(clause, WhereClause):
                where_clause = clause
            elif isinstance(clause, ReturnClause):
                return_clause = clause
            elif isinstance(clause, OrderByClause):
                order_by_clause = clause
            elif isinstance(clause, SkipClause):
                skip_clause = clause
            elif isinstance(clause, LimitClause):
                limit_clause = clause

        # Build operators in execution order
        operators = []

        # 1. Process reading clauses (MATCH, OPTIONAL MATCH, UNWIND, CALL) in order
        # This is important because UNWIND may depend on variables from MATCH, or vice versa
        # Track per-index which WHERE clauses are absorbed into an OPTIONAL MATCH scope
        # (null-fill semantics) so that only that specific WHERE is suppressed later.
        _clauses_list = list(clauses)
        _absorbed_where_indices: set[int] = set()
        for _ci, clause in enumerate(_clauses_list):
            if isinstance(clause, MatchClause):
                operators.extend(self._plan_match(clause))
                # If the next clause is a WHERE and there is another WHERE later (or this
                # is followed by an OPTIONAL MATCH), emit this WHERE inline as a Filter so
                # it is not lost when the later WHERE overwrites `where_clause`.
                _next_ci2 = _ci + 1
                _next2 = _clauses_list[_next_ci2] if _next_ci2 < len(_clauses_list) else None
                if isinstance(_next2, WhereClause):
                    # Check if there's a later WHERE clause that would overwrite this one
                    _later_where = any(
                        isinstance(_clauses_list[_k], WhereClause)
                        for _k in range(_ci + 2, len(_clauses_list))
                    )
                    if _later_where:
                        # Emit this WHERE inline; mark it absorbed so step 4 skips it
                        if self._contains_aggregate(_next2.predicate):
                            raise SyntaxError(
                                "InvalidAggregation: Aggregation functions are not allowed "
                                "in WHERE clause predicates"
                            )
                        self._validate_where_pattern_variables(_next2.predicate)
                        self._validate_function_arg_types(_next2.predicate)
                        operators.append(Filter(predicate=_next2.predicate))
                        _absorbed_where_indices.add(_next_ci2)
            elif isinstance(clause, OptionalMatchClause):
                # Peek: if the immediately following clause is WHERE, absorb it into the
                # optional scope so null-fill semantics are preserved.
                # Only absorb for edge patterns (node-rel-node, len >= 3): for single-node
                # patterns the WHERE should remain as an outer Filter so it can act as a
                # post-match filter (e.g. OPTIONAL MATCH (n) WHERE n.age > 30 DELETE n).
                _next_ci = _ci + 1
                _next = _clauses_list[_next_ci] if _next_ci < len(_clauses_list) else None
                _has_edge_pattern = any(
                    (isinstance(p, dict) and len(p.get("parts", [])) >= 3)
                    or (isinstance(p, list) and len(p) >= 3)
                    for p in clause.patterns
                )
                _opt_where = (
                    _next.predicate
                    if isinstance(_next, WhereClause) and _has_edge_pattern
                    else None
                )
                operators.extend(self._plan_optional_match(clause, where_predicate=_opt_where))
                if _opt_where is not None:
                    _absorbed_where_indices.add(_next_ci)
            elif isinstance(clause, UnwindClause):
                operators.append(Unwind(expression=clause.expression, variable=clause.variable))
                self._type_context.bind_unwind_variable(clause.variable)
            elif isinstance(clause, CallClause):
                if clause.procedure_name is not None:
                    # Procedure invocation: CALL proc.name(args) [YIELD ...]
                    # Standalone = CALL is the terminal clause (no RETURN, no following WITH)
                    is_standalone = not has_following_clauses and not any(
                        isinstance(c, ReturnClause) for c in clauses
                    )
                    # YIELD * is only allowed for standalone calls (no RETURN after CALL)
                    if clause.yield_star and not is_standalone:
                        raise SyntaxError(
                            "UnexpectedSyntax — YIELD * is only allowed in standalone "
                            "CALL (not in-query calls)"
                        )
                    # Implicit args (no parens) only allowed for standalone calls
                    if clause.arguments is None and not is_standalone:
                        raise SyntaxError(
                            "InvalidArgumentPassingMode — in-query CALL requires explicit arguments"
                        )
                    # Aggregation functions are not allowed in procedure arguments
                    if clause.arguments:
                        for arg_expr in clause.arguments:
                            if self._contains_aggregate(arg_expr):
                                raise SyntaxError(
                                    "InvalidAggregation — aggregation functions are not "
                                    "allowed in CALL procedure arguments"
                                )
                    # VariableAlreadyBound: YIELD must not introduce already-bound variables
                    if clause.yield_items and not is_standalone:
                        already_bound = set(self._type_context._types.keys())
                        seen_aliases: set[str] = set()
                        for item in clause.yield_items:
                            alias = item.alias
                            if alias is None and hasattr(item.expression, "name"):
                                alias = item.expression.name
                            if alias and alias in already_bound:
                                raise SyntaxError(
                                    f"VariableAlreadyBound — YIELD introduces `{alias}` "
                                    f"which is already bound in this scope"
                                )
                            if alias and alias in seen_aliases:
                                raise SyntaxError(
                                    f"VariableAlreadyBound — YIELD alias `{alias}` "
                                    f"appears more than once"
                                )
                            if alias:
                                seen_aliases.add(alias)
                                self._type_context.bind_variable(alias, VariableType.SCALAR)
                    operators.append(
                        ProcedureCall(
                            procedure_name=clause.procedure_name,
                            arguments=clause.arguments,  # None = implicit; [] = explicit empty
                            yield_items=clause.yield_items,
                            yield_star=clause.yield_star,
                            standalone=is_standalone,
                        )
                    )
                    # Track procedure output columns as unscoped when no YIELD in in-query call.
                    # These vars are not accessible in RETURN/WITH and trigger UndefinedVariable.
                    if (
                        not is_standalone
                        and not clause.yield_items
                        and not clause.yield_star
                        and self._procedure_registry is not None
                        and self._procedure_registry.exists(clause.procedure_name)
                    ):
                        defn = self._procedure_registry.get(clause.procedure_name)
                        for col in defn.output_columns:
                            self._proc_unscoped_outputs.add(col.name)
                else:
                    # Subquery form: CALL { query }
                    from graphforge.ast.query import UnionQuery

                    saved_type_context = self._type_context.copy()
                    try:
                        if isinstance(clause.query, UnionQuery):
                            branch_operators = []
                            for branch_ast in clause.query.branches:
                                branch_ops = self.plan(branch_ast)
                                branch_operators.append(branch_ops)
                            union_op = Union(branches=branch_operators, all=clause.query.all)
                            nested_operators = [union_op]
                        else:
                            nested_operators = self.plan(clause.query)
                        operators.append(Call(operators=nested_operators))
                    finally:
                        # Restore outer context but propagate variables projected by the
                        # subquery's RETURN clause into the outer scope.
                        subquery_ast = clause.query
                        if isinstance(subquery_ast, UnionQuery):
                            subquery_ast = (
                                subquery_ast.branches[0] if subquery_ast.branches else None
                            )
                        projected_vars: list[tuple[str, VariableType]] = []
                        if subquery_ast is not None:
                            for sub_clause in getattr(subquery_ast, "clauses", []):
                                if isinstance(sub_clause, ReturnClause):
                                    for item in sub_clause.items:
                                        alias = item.alias
                                        if alias is None and isinstance(item.expression, Variable):
                                            alias = item.expression.name
                                        if alias:
                                            # Preserve the actual inner type if available
                                            if isinstance(item.expression, Variable):
                                                expr_var = item.expression.name
                                                inner_type = self._type_context.get_type(expr_var)
                                                var_type = (
                                                    inner_type
                                                    if inner_type != VariableType.UNKNOWN
                                                    else VariableType.SCALAR
                                                )
                                            else:
                                                var_type = VariableType.SCALAR
                                            projected_vars.append((alias, var_type))
                        self._type_context = saved_type_context
                        for var_name_inner, projected_type in projected_vars:
                            self._type_context.bind_variable(var_name_inner, projected_type)

        # 3. Pre-validate write patterns in original clause order so each clause sees
        # variables bound by preceding clauses (e.g. MERGE (t) followed by CREATE (t)->()).
        # MERGE and CREATE are processed in sequence so a MERGE-bound variable is already
        # in type_context when a subsequent CREATE references it as a bare endpoint.
        for clause in clauses:
            if isinstance(clause, MergeClause):
                self._validate_merge_patterns(clause.patterns)
                self._validate_pattern_types(clause.patterns)
                if clause.on_create:
                    self._validate_set_clause_variables(clause.on_create)
                if clause.on_match:
                    self._validate_set_clause_variables(clause.on_match)
            elif isinstance(clause, CreateClause):
                self._validate_create_patterns(clause.patterns)
                self._bind_pattern_types(clause.patterns)

        # 4. WHERE (before write operations so filter applies to reading results)
        # Skip if this specific WHERE was absorbed into an OPTIONAL MATCH scope above.
        _where_clause_index = _clauses_list.index(where_clause) if where_clause is not None else -1
        if where_clause and _where_clause_index not in _absorbed_where_indices:
            # Aggregation functions are not allowed in WHERE predicates
            if self._contains_aggregate(where_clause.predicate):
                raise SyntaxError(
                    "InvalidAggregation: Aggregation functions are not allowed "
                    "in WHERE clause predicates"
                )
            self._validate_where_pattern_variables(where_clause.predicate)
            self._validate_function_arg_types(where_clause.predicate)
            operators.append(Filter(predicate=where_clause.predicate))

        # 5. Write operations (MERGE, SET, REMOVE, DELETE, CREATE) in original clause order
        # This preserves semantics like DELETE-before-MERGE and MERGE-before-SET.
        # Validate remaining write clauses (DELETE, SET) that weren't handled in step 3.
        for clause in clauses:
            if isinstance(clause, DeleteClause):
                self._validate_delete_clause_variables(clause)
            elif isinstance(clause, SetClause):
                self._validate_set_clause_variables(clause)

        # Now emit operators in original clause order for write operations
        _create_patterns: list[Any] = []
        for clause in clauses:
            if isinstance(clause, CreateClause):
                _create_patterns.extend(clause.patterns)
            elif isinstance(clause, MergeClause):
                # Flush any buffered CREATE first
                if _create_patterns:
                    operators.append(Create(patterns=_create_patterns))
                    _create_patterns = []
                operators.append(
                    Merge(
                        patterns=clause.patterns,
                        on_create=clause.on_create,
                        on_match=clause.on_match,
                    )
                )
            elif isinstance(clause, SetClause):
                if _create_patterns:
                    operators.append(Create(patterns=_create_patterns))
                    _create_patterns = []
                operators.append(Set(items=clause.items))
            elif isinstance(clause, RemoveClause):
                if _create_patterns:
                    operators.append(Create(patterns=_create_patterns))
                    _create_patterns = []
                operators.append(Remove(items=clause.items))
            elif isinstance(clause, DeleteClause):
                if _create_patterns:
                    operators.append(Create(patterns=_create_patterns))
                    _create_patterns = []
                operators.append(Delete(variables=clause.variables, detach=clause.detach))
        if _create_patterns:
            operators.append(Create(patterns=_create_patterns))

        # 10. RETURN
        if return_clause:
            # Validate RETURN clause compile-time constraints
            self._validate_return_clause(return_clause)

            # UndefinedVariable: check if RETURN references procedure outputs not YIELDed
            if self._proc_unscoped_outputs:
                for item in return_clause.items:
                    for var in self._collect_variables(item.expression):
                        if (
                            var.name in self._proc_unscoped_outputs
                            and not self._type_context.has_variable(var.name)
                        ):
                            raise SyntaxError(
                                f"UndefinedVariable — `{var.name}` is a procedure output "
                                f"that was not YIELDed"
                            )

            # Validate no aggregation inside list comprehensions
            for item in return_clause.items:
                self._validate_no_aggregate_in_list_comp(item.expression)

            # Validate function arg types (type/length/size on wrong entity types)
            for item in return_clause.items:
                self._validate_function_arg_types(item.expression)

            # Check if RETURN contains aggregations
            has_aggregates = self._has_aggregations(return_clause)

            # Validate ORDER BY aggregation rules (compile-time check)
            if order_by_clause:
                self._validate_order_by_aggregation(
                    order_by_clause.items,
                    return_clause.items,
                    has_aggregates,
                )
                # Build the set of aliases introduced by RETURN (used in both paths).
                return_aliases: set[str] = set()
                for item in return_clause.items:
                    if item.alias:
                        return_aliases.add(item.alias)
                    elif isinstance(item.expression, Variable):
                        return_aliases.add(item.expression.name)

                # When RETURN has DISTINCT (without aggregation), ORDER BY can only
                # reference projected expressions.
                # Rules:
                # - Aliases in RETURN are accessible by name in ORDER BY
                # - Variables projected directly (RETURN DISTINCT a) allow a.prop in ORDER BY
                # - Property accesses (RETURN DISTINCT a.name) do NOT grant access to a.age
                if return_clause.distinct and not has_aggregates:
                    projected_aliases: set[str] = set()
                    directly_projected_vars: set[str] = set()
                    # Track exact (variable, property) pairs from unaliased PropertyAccess.
                    # Use base.name when base is a Variable (takes precedence over .variable).
                    projected_prop_paths: set[tuple[str, str]] = set()
                    for item in return_clause.items:
                        if item.alias:
                            projected_aliases.add(item.alias)
                        if isinstance(item.expression, Variable):
                            directly_projected_vars.add(item.expression.name)
                        elif not item.alias and isinstance(item.expression, PropertyAccess):
                            pa = item.expression
                            owner = (
                                pa.base.name
                                if pa.base is not None and isinstance(pa.base, Variable)
                                else pa.variable
                            )
                            if owner:
                                projected_prop_paths.add((owner, pa.property))
                    for ob_item in order_by_clause.items:
                        ob_vars: set[str] = set()
                        self._collect_expr_variables(ob_vars, ob_item.expression)
                        ob_expr = ob_item.expression
                        # ORDER BY expr is an exact match for a projected property path
                        ob_owner: str | None = None
                        if isinstance(ob_expr, PropertyAccess):
                            ob_owner = (
                                ob_expr.base.name
                                if ob_expr.base is not None and isinstance(ob_expr.base, Variable)
                                else ob_expr.variable
                            )
                        is_exact_prop_match = (
                            ob_owner is not None
                            and (ob_owner, ob_expr.property) in projected_prop_paths
                        )
                        for var_name in ob_vars:
                            if var_name in projected_aliases:
                                continue  # explicit alias in RETURN DISTINCT
                            if var_name in directly_projected_vars:
                                continue  # node projected directly, a.prop is OK
                            if is_exact_prop_match:
                                continue  # e.g. RETURN DISTINCT a.name ORDER BY a.name
                            raise SyntaxError(
                                f"UndefinedVariable: Variable `{var_name}` is not "
                                f"projected by RETURN DISTINCT and cannot be used in "
                                f"ORDER BY"
                            )
                else:
                    # For non-DISTINCT RETURN, ORDER BY can reference any in-scope
                    # variable or a RETURN alias (including aggregation result aliases).
                    self._validate_order_by_scope(
                        order_by_clause.items, extra_aliases=return_aliases
                    )

            if has_aggregates:
                # 9a. ORDER BY must come BEFORE Aggregate for non-agg sort keys,
                #     but AFTER Aggregate when sorting by aggregate results.
                #     For simplicity, place Sort AFTER Aggregate so it sorts final output.
                # Use Aggregate operator for grouping and aggregation
                grouping_exprs, agg_exprs = self._split_aggregates(return_clause)
                operators.append(
                    Aggregate(
                        grouping_exprs=grouping_exprs,
                        agg_exprs=agg_exprs,
                        return_items=return_clause.items,
                    )
                )
                # Sort after aggregation (ORDER BY on aggregated output)
                if order_by_clause:
                    return_items = return_clause.items
                    operators.append(Sort(items=order_by_clause.items, return_items=return_items))
            else:
                # 9b. ORDER BY before non-aggregated projection
                if order_by_clause:
                    return_items = return_clause.items
                    operators.append(Sort(items=order_by_clause.items, return_items=return_items))
                # Use simple Project operator
                operators.append(Project(items=return_clause.items))

            # Add DISTINCT operator if needed
            if return_clause.distinct:
                from graphforge.planner.operators import Distinct

                operators.append(Distinct())
        elif order_by_clause:
            # ORDER BY without RETURN (edge case — still emit Sort for WITH pipelines)
            return_items = None
            operators.append(Sort(items=order_by_clause.items, return_items=return_items))

        # 11. SKIP/LIMIT
        if skip_clause:
            operators.append(Skip(count=skip_clause.count))
        if limit_clause:
            operators.append(Limit(count=limit_clause.count))

        return operators

    def _plan_with_query(self, ast: CypherQuery) -> list[Any]:
        """Plan a query with WITH clauses.

        WITH acts as a pipeline boundary, so we plan each segment separately
        and connect them with WITH operators.

        Args:
            ast: Query AST with WITH clauses

        Returns:
            List of logical plan operators
        """
        operators: list[Any] = []

        # Split clauses at WITH boundaries
        segments: list[list | WithClause] = []
        current_segment: list = []

        for clause in ast.clauses:
            if isinstance(clause, WithClause):
                # End current segment and start new one
                if current_segment:
                    segments.append(current_segment)
                    current_segment = []
                # Add WITH as its own segment marker
                segments.append(clause)
            else:
                current_segment.append(clause)

        # Add final segment
        if current_segment:
            segments.append(current_segment)

        # Plan each segment
        for segment in segments:
            if isinstance(segment, WithClause):
                # Validate WITH clause (Issue #172)
                self._validate_with_clause(segment)

                # Validate no aggregation inside list comprehensions in WITH items
                for item in segment.items:
                    self._validate_no_aggregate_in_list_comp(item.expression)

                # Validate function arg types in WITH items (type/length/size on wrong types)
                for item in segment.items:
                    self._validate_function_arg_types(item.expression)

                # Check if WITH contains aggregations
                has_aggregates = any(
                    self._contains_aggregate(item.expression) for item in segment.items
                )

                if segment.order_by:
                    # Validate ORDER BY variables against the PRE-narrowing scope
                    # (current type_context before _infer_with_types narrows it).
                    # Also allow aliases introduced by this same WITH clause (co-scope rule),
                    # including aggregation result aliases for aggregating WITH.
                    with_aliases: set[str] = set()
                    for item in segment.items:
                        if item.alias:
                            with_aliases.add(item.alias)
                        elif isinstance(item.expression, Variable):
                            with_aliases.add(item.expression.name)
                    self._validate_order_by_scope(
                        segment.order_by.items, extra_aliases=with_aliases
                    )
                    # Validate ORDER BY aggregation rules (compile-time check)
                    self._validate_order_by_aggregation(
                        segment.order_by.items,
                        segment.items,
                        has_aggregates,
                    )

                # Infer variable types from WITH and narrow scope to projected aliases.
                # Must come AFTER ORDER BY scope validation (ORDER BY uses pre-WITH scope).
                self._infer_with_types(segment)

                if has_aggregates:
                    # Split items into grouping and aggregation expressions
                    grouping_exprs = []
                    agg_exprs: list = []
                    seen_ids: set = set()
                    for item in segment.items:
                        if self._contains_aggregate(item.expression):
                            self._extract_aggregates(item.expression, seen_ids, agg_exprs)
                        else:
                            grouping_exprs.append(item.expression)

                    # Create Aggregate operator
                    operators.append(
                        Aggregate(
                            grouping_exprs=grouping_exprs,
                            agg_exprs=agg_exprs,
                            return_items=segment.items,
                        )
                    )

                    # Add optional WHERE, ORDER BY, DISTINCT, SKIP, LIMIT after aggregation
                    # Order matters: DISTINCT before SKIP/LIMIT
                    if segment.where:
                        operators.append(Filter(predicate=segment.where.predicate))
                    if segment.order_by:
                        operators.append(
                            Sort(items=segment.order_by.items, return_items=segment.items)
                        )
                    # Add DISTINCT operator before SKIP/LIMIT (after ORDER BY)
                    if segment.distinct:
                        from graphforge.planner.operators import Distinct

                        operators.append(Distinct())
                    if segment.skip:
                        operators.append(Skip(count=segment.skip.count))
                    if segment.limit:
                        operators.append(Limit(count=segment.limit.count))
                else:
                    # No aggregations - use simple With operator
                    # When DISTINCT is used, SKIP/LIMIT must be applied after the
                    # separate Distinct operator, not in the With operator itself
                    pred = segment.where.predicate if segment.where else None
                    sort_items = segment.order_by.items if segment.order_by else None
                    skip_count = (
                        segment.skip.count if (segment.skip and not segment.distinct) else None
                    )
                    limit_count = (
                        segment.limit.count if (segment.limit and not segment.distinct) else None
                    )

                    with_op = With(
                        items=segment.items,
                        distinct=segment.distinct,
                        predicate=pred,
                        sort_items=sort_items,
                        skip_count=skip_count,
                        limit_count=limit_count,
                    )
                    operators.append(with_op)

                    # Add DISTINCT operator if needed (before SKIP/LIMIT)
                    if segment.distinct:
                        from graphforge.planner.operators import Distinct

                        operators.append(Distinct())
                        # Add SKIP/LIMIT after DISTINCT
                        if segment.skip:
                            operators.append(Skip(count=segment.skip.count))
                        if segment.limit:
                            operators.append(Limit(count=segment.limit.count))
            elif isinstance(segment, list):
                # Determine if more segments follow this one (makes CALL in-query)
                seg_idx = segments.index(segment)
                has_following = seg_idx < len(segments) - 1
                operators.extend(
                    self._plan_simple_query(segment, has_following_clauses=has_following)
                )

        return operators

    def _plan_match(self, clause: MatchClause) -> list[Any]:
        """Plan MATCH clause into operators.

        Args:
            clause: MATCH clause from AST

        Returns:
            List of operators for the MATCH pattern
        """
        operators: list[Any] = []

        for pattern in clause.patterns:
            if not pattern:
                continue

            # Extract pattern parts from new format (dict with path_variable and parts)
            # or use pattern directly if it's old format (list)
            if isinstance(pattern, dict) and "parts" in pattern:
                path_var = pattern.get("path_variable")
                pattern_parts = pattern["parts"]
            else:
                # Old format: pattern is already a list
                pattern_parts = pattern
                path_var = None

            # MATCH p = pattern is invalid when p is already bound (VariableAlreadyBound)
            if path_var and self._type_context.has_variable(path_var):
                raise SyntaxError(
                    f"VariableAlreadyBound: path variable `{path_var}` is already bound"
                )

            # Handle simple node pattern
            if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                node_pattern = pattern_parts[0]
                var_name = node_pattern.variable or self._generate_anonymous_variable()

                # VALIDATE: Check if variable already bound to incompatible type
                self._type_context.validate_compatible(var_name, VariableType.NODE)

                # BIND: Register as node type
                self._type_context.bind_variable(var_name, VariableType.NODE)

                # Handle path variable if present
                if path_var:
                    self._type_context.validate_compatible(path_var, VariableType.PATH)
                    self._type_context.bind_variable(path_var, VariableType.PATH)

                operators.append(
                    ScanNodes(
                        variable=var_name,
                        labels=node_pattern.labels if node_pattern.labels else None,
                        path_var=path_var,
                    )
                )

                # Add Filter for inline property predicates
                if node_pattern.properties:
                    predicate = self._properties_to_predicate(
                        node_pattern.variable,  # type: ignore[arg-type]
                        node_pattern.properties,
                    )
                    operators.append(Filter(predicate=predicate))

            # Handle node-relationship-node pattern (single or multi-hop)
            elif len(pattern_parts) >= 3:
                # First node
                if isinstance(pattern_parts[0], NodePattern):
                    src_pattern = pattern_parts[0]
                    # Generate variable name for anonymous patterns
                    src_var = (
                        src_pattern.variable
                        if src_pattern.variable
                        else self._generate_anonymous_variable()
                    )

                    # VALIDATE: Check if variable already bound to incompatible type
                    self._type_context.validate_compatible(src_var, VariableType.NODE)

                    # BIND: Register as node type
                    self._type_context.bind_variable(src_var, VariableType.NODE)

                    operators.append(
                        ScanNodes(
                            variable=src_var,
                            labels=src_pattern.labels if src_pattern.labels else None,
                        )
                    )

                    # Add Filter for inline property predicates on src node
                    if src_pattern.properties:
                        predicate = self._properties_to_predicate(
                            src_var,
                            src_pattern.properties,
                        )
                        operators.append(Filter(predicate=predicate))

                # Determine number of hops
                # Pattern: node, rel, node, rel, node, ... (alternating)
                num_hops = (len(pattern_parts) - 1) // 2

                # Compile-time check: relationship variable uniqueness within a pattern
                # openCypher: the same relationship variable cannot appear more than once
                # in a single MATCH pattern (RelationshipUniquenessViolation)
                # Also generate planner-internal names for anonymous rels in multi-hop
                # patterns so runtime uniqueness can be enforced across anonymous hops.
                seen_pattern_rel_vars: set[str] = set()
                anon_rel_names: dict[int, str] = {}
                for _i in range(num_hops):
                    _rel = pattern_parts[1 + (_i * 2)]
                    if isinstance(_rel, RelationshipPattern):
                        if _rel.variable:
                            if _rel.variable in seen_pattern_rel_vars:
                                raise SyntaxError(
                                    f"RelationshipUniquenessViolation: "
                                    f"Relationship variable '{_rel.variable}' cannot be used "
                                    f"more than once in a single MATCH pattern"
                                )
                            seen_pattern_rel_vars.add(_rel.variable)
                        elif num_hops > 1:
                            # Multi-hop anonymous rel: generate an internal name so the
                            # executor can track this edge for relationship uniqueness.
                            _anon_name = self._generate_anonymous_variable()
                            anon_rel_names[_i] = _anon_name
                            seen_pattern_rel_vars.add(_anon_name)

                direction_map = {
                    Direction.OUT: "OUT",
                    Direction.IN: "IN",
                    Direction.UNDIRECTED: "UNDIRECTED",
                }

                # Check if any relationship is variable-length
                has_variable_length = any(
                    isinstance(pattern_parts[1 + (i * 2)], RelationshipPattern)
                    and (
                        pattern_parts[1 + (i * 2)].min_hops is not None
                        or pattern_parts[1 + (i * 2)].max_hops is not None
                    )
                    for i in range(num_hops)
                )

                # For multi-hop patterns with path binding and no variable-length:
                # Use ExpandMultiHop operator
                if num_hops > 1 and path_var and not has_variable_length:
                    from graphforge.planner.operators import ExpandMultiHop

                    # Collect all hops and filters
                    hops = []
                    filters: list[ScanNodes | Filter] = []
                    for hop_idx in range(num_hops):
                        rel_idx = 1 + (hop_idx * 2)
                        node_idx = rel_idx + 1

                        if rel_idx >= len(pattern_parts) or node_idx >= len(pattern_parts):
                            break

                        if not isinstance(pattern_parts[rel_idx], RelationshipPattern):
                            continue

                        rel_pattern = pattern_parts[rel_idx]
                        dst_pattern = pattern_parts[node_idx]

                        # Generate variable names
                        rel_var = (
                            rel_pattern.variable
                            if rel_pattern.variable
                            else None  # Anonymous relationship
                        )
                        dst_var = (
                            dst_pattern.variable
                            if dst_pattern.variable
                            else self._generate_anonymous_variable()
                        )

                        # VALIDATE and BIND types
                        if rel_var:
                            self._type_context.validate_compatible(
                                rel_var, VariableType.RELATIONSHIP
                            )
                            self._type_context.bind_variable(rel_var, VariableType.RELATIONSHIP)

                        self._type_context.validate_compatible(dst_var, VariableType.NODE)
                        self._type_context.bind_variable(dst_var, VariableType.NODE)

                        hops.append(
                            (
                                rel_var,
                                rel_pattern.types if rel_pattern.types else [],
                                direction_map[rel_pattern.direction],
                                dst_var,
                            )
                        )

                        # Collect label filter and property predicates for dst node
                        # (to be added AFTER ExpandMultiHop binds the variables)
                        if dst_pattern.labels:
                            filters.append(ScanNodes(variable=dst_var, labels=dst_pattern.labels))
                        if dst_pattern.properties:
                            predicate = self._properties_to_predicate(
                                dst_var,
                                dst_pattern.properties,
                            )
                            filters.append(Filter(predicate=predicate))

                    # Handle path variable if present
                    if path_var:
                        self._type_context.validate_compatible(path_var, VariableType.PATH)
                        self._type_context.bind_variable(path_var, VariableType.PATH)

                    # Add ExpandMultiHop operator first
                    operators.append(
                        ExpandMultiHop(
                            src_var=src_var,
                            hops=hops,
                            path_var=path_var,
                        )
                    )

                    # Then add filters (now that variables are bound)
                    operators.extend(filters)
                else:
                    # Single hop OR multi-hop without path binding OR has variable-length:
                    # Use individual ExpandEdges/ExpandVariableLength operators
                    prev_dst_var = src_var  # Initialize for multi-hop chaining
                    # Track per-hop path variable names when assembling a multi-hop named path
                    hop_path_var_list: list[str] = []
                    for hop_idx in range(num_hops):
                        rel_idx = 1 + (hop_idx * 2)
                        node_idx = rel_idx + 1

                        if rel_idx >= len(pattern_parts) or node_idx >= len(pattern_parts):
                            break

                        if not isinstance(pattern_parts[rel_idx], RelationshipPattern):
                            continue

                        rel_pattern = pattern_parts[rel_idx]
                        dst_pattern = pattern_parts[node_idx]

                        # Source is previous destination (or first src_var for first hop)
                        if hop_idx == 0:
                            current_src_var = src_var
                        else:
                            current_src_var = prev_dst_var

                        # Generate variable names for anonymous patterns
                        rel_var = (
                            rel_pattern.variable
                            if rel_pattern.variable
                            else anon_rel_names.get(hop_idx)
                            if num_hops > 1
                            else self._generate_anonymous_variable()
                        )
                        dst_var = (
                            dst_pattern.variable
                            if dst_pattern.variable
                            else self._generate_anonymous_variable()
                        )

                        # VALIDATE and BIND types
                        is_var_length = (
                            rel_pattern.min_hops is not None or rel_pattern.max_hops is not None
                        )
                        if rel_var:
                            # For var-length patterns, a pre-bound SCALAR rel_var may be a
                            # CypherList of edges from WITH — allow it (executor validates at
                            # runtime). Use optional_context=True to suppress the type error.
                            self._type_context.validate_compatible(
                                rel_var, VariableType.RELATIONSHIP, optional_context=is_var_length
                            )
                            self._type_context.bind_variable(rel_var, VariableType.RELATIONSHIP)

                        self._type_context.validate_compatible(dst_var, VariableType.NODE)
                        self._type_context.bind_variable(dst_var, VariableType.NODE)

                        # Assign hop-level path variable:
                        # - Single-hop with path_var: use path_var directly (no assembly needed)
                        # - Multi-hop with path_var: use a temp __path_hop_N var; AssemblePath
                        #   concatenates them into path_var after all hops complete
                        if path_var:
                            if num_hops == 1:
                                hop_path_var = path_var
                            else:
                                hop_path_var = self._generate_anonymous_variable()
                                hop_path_var_list.append(hop_path_var)
                        else:
                            hop_path_var = None

                        # Bind final path_var in type context; temp hop vars are internal
                        if (
                            hop_path_var == path_var
                            and hop_path_var
                            and not self._type_context.has_variable(hop_path_var)
                        ):
                            self._type_context.bind_variable(hop_path_var, VariableType.PATH)

                        # Check if this is a variable-length pattern
                        if is_var_length:
                            # Variable-length expansion — inline property predicates must be
                            # folded into ExpandVariableLength.predicate (applied per-hop
                            # during BFS) rather than as a post-expand Filter, because after
                            # the expand rel_var is bound to a CypherList of edges.
                            from graphforge.planner.operators import ExpandVariableLength

                            vl_pred = rel_pattern.predicate
                            if rel_pattern.properties and rel_var:
                                prop_pred = self._properties_to_predicate(
                                    rel_var, rel_pattern.properties
                                )
                                if vl_pred is not None:
                                    from graphforge.ast.expression import BinaryOp as _BinaryOp

                                    vl_pred = _BinaryOp(op="AND", left=vl_pred, right=prop_pred)
                                else:
                                    vl_pred = prop_pred

                            operators.append(
                                ExpandVariableLength(
                                    src_var=current_src_var,
                                    edge_var=rel_var,
                                    dst_var=dst_var,
                                    path_var=hop_path_var,
                                    edge_types=rel_pattern.types if rel_pattern.types else [],
                                    direction=direction_map[rel_pattern.direction],
                                    min_hops=rel_pattern.min_hops
                                    if rel_pattern.min_hops is not None
                                    else 1,
                                    max_hops=rel_pattern.max_hops,
                                    predicate=vl_pred,
                                )
                            )
                        else:
                            # Single-hop expansion
                            operators.append(
                                ExpandEdges(
                                    src_var=current_src_var,
                                    edge_var=rel_var,
                                    dst_var=dst_var,
                                    path_var=hop_path_var,
                                    edge_types=rel_pattern.types if rel_pattern.types else [],
                                    direction=direction_map[rel_pattern.direction],
                                    predicate=rel_pattern.predicate,
                                    pattern_rel_vars=frozenset(seen_pattern_rel_vars),
                                )
                            )

                            # Add Filter for inline property predicates on relationship
                            # (single-hop only — var-length predicates are folded above)
                            if rel_pattern.properties and rel_var:
                                rel_pred = self._properties_to_predicate(
                                    rel_var,
                                    rel_pattern.properties,
                                )
                                operators.append(Filter(predicate=rel_pred))

                        # Filter destination by labels (ScanNodes on bound var acts as label filter)
                        if dst_pattern.labels:
                            operators.append(ScanNodes(variable=dst_var, labels=dst_pattern.labels))

                        # Add Filter for inline property predicates on dst node
                        if dst_pattern.properties:
                            predicate = self._properties_to_predicate(
                                dst_var,
                                dst_pattern.properties,
                            )
                            operators.append(Filter(predicate=predicate))

                        # Track destination for next hop
                        prev_dst_var = dst_var

                    # For multi-hop named paths, assemble per-hop partial paths into path_var
                    if path_var and hop_path_var_list:
                        from graphforge.planner.operators import AssemblePath

                        operators.append(
                            AssemblePath(path_var=path_var, hop_path_vars=hop_path_var_list)
                        )
                        self._type_context.validate_compatible(path_var, VariableType.PATH)
                        self._type_context.bind_variable(path_var, VariableType.PATH)

        return operators

    def _plan_optional_match(
        self, clause: OptionalMatchClause, where_predicate: Any = None
    ) -> list[Any]:
        """Plan OPTIONAL MATCH clause into operators.

        Similar to _plan_match, but uses OptionalExpandEdges for left outer join semantics.

        Args:
            clause: OPTIONAL MATCH clause from AST
            where_predicate: Optional WHERE predicate to absorb into the optional scope.

        Returns:
            List of operators for the OPTIONAL MATCH pattern
        """
        operators: list[Any] = []

        for pattern in clause.patterns:
            if not pattern:
                continue

            # Extract pattern parts from new format (dict with path_variable and parts)
            # or use pattern directly if it's old format (list)
            if isinstance(pattern, dict) and "parts" in pattern:
                path_var = pattern.get("path_variable")
                pattern_parts = pattern["parts"]
            else:
                # Old format: pattern is already a list
                path_var = None
                pattern_parts = pattern

            # OPTIONAL MATCH p = pattern is invalid when p is already bound
            if path_var and self._type_context.has_variable(path_var):
                raise SyntaxError(
                    f"VariableAlreadyBound: path variable `{path_var}` is already bound"
                )

            # Handle simple node pattern
            if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                # OPTIONAL MATCH on a single node uses OptionalScanNodes
                # to preserve rows with NULL bindings when no match found
                from graphforge.planner.operators import OptionalScanNodes

                node_pattern = pattern_parts[0]
                operators.append(
                    OptionalScanNodes(
                        variable=node_pattern.variable,  # type: ignore[arg-type]
                        labels=node_pattern.labels if node_pattern.labels else None,
                        path_var=path_var,
                    )
                )

                # Bind node variable so downstream validations can see it
                if node_pattern.variable:
                    self._type_context.validate_compatible(
                        node_pattern.variable, VariableType.NODE, optional_context=True
                    )
                    self._type_context.bind_variable(node_pattern.variable, VariableType.NODE)

                # Bind path variable if present
                if path_var and not self._type_context.has_variable(path_var):
                    self._type_context.validate_compatible(path_var, VariableType.PATH)
                    self._type_context.bind_variable(path_var, VariableType.PATH)

                # Add Filter for inline property predicates
                if node_pattern.properties:
                    predicate = self._properties_to_predicate(
                        node_pattern.variable,  # type: ignore[arg-type]
                        node_pattern.properties,
                    )
                    operators.append(Filter(predicate=predicate))

            # Handle node-relationship-node pattern
            elif len(pattern_parts) >= 3:
                direction_map = {
                    Direction.OUT: "OUT",
                    Direction.IN: "IN",
                    Direction.UNDIRECTED: "UNDIRECTED",
                }

                if not isinstance(pattern_parts[0], NodePattern):
                    continue

                src_pattern = pattern_parts[0]
                src_var = (
                    src_pattern.variable
                    if src_pattern.variable
                    else self._generate_anonymous_variable()
                )

                # Record whether src was already bound before this OPTIONAL MATCH
                src_was_prebound = self._type_context.has_variable(src_var)

                # Emit ScanNodes only if src is not already bound
                if not src_was_prebound:
                    operators.append(
                        ScanNodes(
                            variable=src_var,
                            labels=src_pattern.labels if src_pattern.labels else None,
                        )
                    )
                    self._type_context.validate_compatible(
                        src_var, VariableType.NODE, optional_context=True
                    )
                    self._type_context.bind_variable(src_var, VariableType.NODE)
                    if src_pattern.properties:
                        predicate = self._properties_to_predicate(src_var, src_pattern.properties)
                        operators.append(Filter(predicate=predicate))
                    # Track how many ops were added for src so we can move them into a subplan
                    src_ops_added = 1 + (1 if src_pattern.properties else 0)
                else:
                    src_ops_added = 0
                    # Pre-bound: still validate type and filter by labels/properties
                    self._type_context.validate_compatible(
                        src_var, VariableType.NODE, optional_context=True
                    )
                    if src_pattern.labels:
                        operators.append(ScanNodes(variable=src_var, labels=src_pattern.labels))
                    if src_pattern.properties:
                        predicate = self._properties_to_predicate(src_var, src_pattern.properties)
                        operators.append(Filter(predicate=predicate))

                num_hops = (len(pattern_parts) - 1) // 2
                prev_dst_var = src_var
                introduced_vars: list[str] = []  # vars introduced by OPTIONAL MATCH pattern

                # Build the subplan for this optional pattern
                subplan: list[Any] = []
                # Track per-hop path variable names for multi-hop named path assembly
                opt_hop_path_var_list: list[str] = []

                for hop_idx in range(num_hops):
                    rel_idx = 1 + hop_idx * 2
                    node_idx = rel_idx + 1
                    if rel_idx >= len(pattern_parts) or node_idx >= len(pattern_parts):
                        break
                    if not isinstance(pattern_parts[rel_idx], RelationshipPattern):
                        continue

                    rel_pattern = pattern_parts[rel_idx]
                    dst_pattern = pattern_parts[node_idx]

                    current_src_var = prev_dst_var
                    rel_var = rel_pattern.variable or None
                    dst_var = (
                        dst_pattern.variable
                        if dst_pattern.variable
                        else self._generate_anonymous_variable()
                    )

                    is_single_hop = num_hops == 1
                    # Assign hop-level path variable:
                    # - Single-hop: use path_var directly
                    # - Multi-hop: use a unique anon var; AssemblePath joins them into path_var
                    if path_var:
                        if is_single_hop:
                            hop_path_var = path_var
                        else:
                            hop_path_var = self._generate_anonymous_variable()
                            opt_hop_path_var_list.append(hop_path_var)
                    else:
                        hop_path_var = None

                    # Combine absorbed WHERE + inline rel predicate + inline rel properties.
                    # For single-hop: absorbed WHERE folds into the expand operator.
                    # For multi-hop: absorbed WHERE is deferred until after all hops so all
                    # referenced variables (e.g. z in x.val < z.val) are bound.
                    from graphforge.ast.expression import BinaryOp as _BinaryOp

                    combined_where = where_predicate if (hop_idx == 0 and num_hops == 1) else None
                    # AND in rel_pattern.predicate (inline WHERE from relationship syntax)
                    if rel_pattern.predicate is not None:
                        if combined_where is not None:
                            combined_where = _BinaryOp(
                                op="AND", left=rel_pattern.predicate, right=combined_where
                            )
                        else:
                            combined_where = rel_pattern.predicate
                    if rel_pattern.properties:
                        if rel_var is None:
                            rel_var = self._generate_anonymous_variable()
                        rel_prop_pred = self._properties_to_predicate(
                            rel_var, rel_pattern.properties
                        )
                        if combined_where is not None:
                            combined_where = _BinaryOp(
                                op="AND", left=rel_prop_pred, right=combined_where
                            )
                        else:
                            combined_where = rel_prop_pred
                    # Inline dst properties — ANDed into combined_where for single-hop
                    # (passed as where_predicate to OptionalExpandEdges), or emitted as a
                    # separate Filter for multi-hop / var-length so dst_var is bound first.
                    if dst_pattern.properties:
                        dst_prop_pred: Any = self._properties_to_predicate(
                            dst_var, dst_pattern.properties
                        )
                    else:
                        dst_prop_pred = None

                    single_hop_where: Any = None
                    if rel_pattern.min_hops is not None or rel_pattern.max_hops is not None:
                        from graphforge.planner.operators import ExpandVariableLength

                        # ExpandVariableLength.predicate filters edges, not the dst node.
                        # Use rel-level predicate only; dst_prop_pred is emitted as a Filter below.
                        hop_op: Any = ExpandVariableLength(
                            src_var=current_src_var,
                            edge_var=rel_var,
                            dst_var=dst_var,
                            path_var=hop_path_var,
                            edge_types=rel_pattern.types if rel_pattern.types else [],
                            direction=direction_map[rel_pattern.direction],
                            min_hops=rel_pattern.min_hops
                            if rel_pattern.min_hops is not None
                            else 1,
                            max_hops=rel_pattern.max_hops,
                            predicate=combined_where,
                            optional=True,
                        )
                    else:
                        # For single-hop, use OptionalExpandEdges directly on operators.
                        # For multi-hop, use ExpandEdges inside the ApplyOptional subplan.
                        # Check if dst was pre-bound before this OPTIONAL MATCH
                        dst_was_prebound = (
                            dst_pattern.variable is not None
                            and self._type_context.has_variable(dst_pattern.variable)
                            and dst_pattern.variable not in introduced_vars
                        )
                        # Inline dst labels into OptionalExpandEdges for new vars;
                        # ScanNodes post-filter only for pre-bound vars (join semantics).
                        inline_dst_labels = (
                            dst_pattern.labels
                            if (dst_pattern.labels and not dst_was_prebound)
                            else []
                        )
                        # For single-hop: fold dst properties into combined_where so they are
                        # evaluated inside OptionalExpandEdges (correct null-fill semantics).
                        single_hop_where = combined_where
                        if is_single_hop and dst_prop_pred is not None:
                            single_hop_where = (
                                _BinaryOp(op="AND", left=dst_prop_pred, right=combined_where)
                                if combined_where is not None
                                else dst_prop_pred
                            )
                        if is_single_hop and src_was_prebound:
                            hop_op = OptionalExpandEdges(
                                src_var=current_src_var,
                                edge_var=rel_var,
                                dst_var=dst_var,
                                path_var=hop_path_var,
                                edge_types=rel_pattern.types if rel_pattern.types else [],
                                direction=direction_map[rel_pattern.direction],
                                where_predicate=single_hop_where,
                                dst_labels=inline_dst_labels,
                            )
                        elif is_single_hop:
                            # Unbound src: use ExpandEdges inside ApplyOptional subplan.
                            # WHERE and dst_prop_pred are handled as a Filter after the expand.
                            hop_op = ExpandEdges(
                                src_var=current_src_var,
                                edge_var=rel_var,
                                dst_var=dst_var,
                                path_var=hop_path_var,
                                edge_types=rel_pattern.types if rel_pattern.types else [],
                                direction=direction_map[rel_pattern.direction],
                                pattern_rel_vars=frozenset(),
                            )
                        else:
                            hop_op = ExpandEdges(
                                src_var=current_src_var,
                                edge_var=rel_var,
                                dst_var=dst_var,
                                path_var=hop_path_var,
                                edge_types=rel_pattern.types if rel_pattern.types else [],
                                direction=direction_map[rel_pattern.direction],
                                pattern_rel_vars=frozenset(),
                            )

                    is_var_length = (
                        rel_pattern.min_hops is not None or rel_pattern.max_hops is not None
                    )
                    # Single-hop with unbound src: move src scan ops into subplan so
                    # ApplyOptional can null-fill src when the whole pattern fails.
                    use_apply_optional_single_hop = is_single_hop and not src_was_prebound
                    if use_apply_optional_single_hop:
                        # Pull the src ScanNodes (and optional Filter) out of operators
                        # and into the subplan, then add the expand op.
                        src_ops = operators[-src_ops_added:] if src_ops_added else []
                        if src_ops_added:
                            del operators[-src_ops_added:]
                        subplan.extend(src_ops)
                        subplan.append(hop_op)
                        # Enforce dst labels inside the subplan (not outside) so that
                        # the null-fill from ApplyOptional correctly covers label mismatches.
                        if dst_pattern.labels and not dst_was_prebound:
                            from graphforge.planner.operators import ScanNodes as _ScanNodes

                            subplan.append(_ScanNodes(variable=dst_var, labels=dst_pattern.labels))
                        # Add WHERE + dst properties as a Filter inside the subplan
                        single_hop_filter: Any = None
                        if is_var_length and dst_prop_pred is not None:
                            single_hop_filter = dst_prop_pred
                        if single_hop_where is not None:
                            single_hop_filter = (
                                _BinaryOp(op="AND", left=single_hop_filter, right=single_hop_where)
                                if single_hop_filter is not None
                                else single_hop_where
                            )
                        if single_hop_filter is not None:
                            subplan.append(Filter(predicate=single_hop_filter))
                    elif is_single_hop:
                        operators.append(hop_op)
                        # For var-length single-hop, dst_var is bound after hop_op;
                        # emit a Filter for dst properties (not folded into predicate above).
                        if is_var_length and dst_prop_pred is not None:
                            operators.append(Filter(predicate=dst_prop_pred))
                    else:
                        subplan.append(hop_op)
                        # Apply rel-level WHERE and dst properties as a Filter after the expand
                        # (dst_var is bound at that point in the subplan).
                        multi_hop_filter: Any = None
                        if combined_where is not None and dst_prop_pred is not None:
                            multi_hop_filter = _BinaryOp(
                                op="AND", left=dst_prop_pred, right=combined_where
                            )
                        elif combined_where is not None:
                            multi_hop_filter = combined_where
                        elif dst_prop_pred is not None:
                            multi_hop_filter = dst_prop_pred
                        if multi_hop_filter is not None:
                            subplan.append(Filter(predicate=multi_hop_filter))

                    if rel_var:
                        rel_is_new = not self._type_context.has_variable(rel_var)
                        self._type_context.validate_compatible(
                            rel_var, VariableType.RELATIONSHIP, optional_context=True
                        )
                        self._type_context.bind_variable(rel_var, VariableType.RELATIONSHIP)
                        if rel_is_new:
                            introduced_vars.append(rel_var)
                    dst_is_new = not self._type_context.has_variable(dst_var)
                    self._type_context.validate_compatible(
                        dst_var, VariableType.NODE, optional_context=True
                    )
                    self._type_context.bind_variable(dst_var, VariableType.NODE)
                    if dst_is_new:
                        introduced_vars.append(dst_var)

                    # For pre-bound dst, still add ScanNodes for label filtering (join semantics)
                    # For new vars, labels are already inlined into OptionalExpandEdges
                    dst_was_prebound_check = (
                        dst_pattern.variable is not None
                        and dst_pattern.variable not in introduced_vars
                    )
                    if dst_pattern.labels and dst_was_prebound_check:
                        label_filter = ScanNodes(variable=dst_var, labels=dst_pattern.labels)
                        if is_single_hop:
                            operators.append(label_filter)
                        else:
                            subplan.append(label_filter)

                    prev_dst_var = dst_var

                # For multi-hop, emit the absorbed WHERE as a Filter after all hops,
                # so all pattern variables (including the final dst) are bound.
                if num_hops > 1 and where_predicate is not None and subplan:
                    subplan.append(Filter(predicate=where_predicate))

                # For multi-hop named paths, add AssemblePath inside the subplan
                if path_var and opt_hop_path_var_list:
                    from graphforge.planner.operators import AssemblePath

                    subplan.append(
                        AssemblePath(path_var=path_var, hop_path_vars=opt_hop_path_var_list)
                    )

                # Bind path variable for the whole pattern
                if path_var and not self._type_context.has_variable(path_var):
                    self._type_context.validate_compatible(path_var, VariableType.PATH)
                    self._type_context.bind_variable(path_var, VariableType.PATH)
                    introduced_vars.append(path_var)

                # Wrap subplan in ApplyOptional for multi-hop OR single-hop with unbound src
                if subplan and (num_hops > 1 or use_apply_optional_single_hop):
                    from graphforge.planner.operators import ApplyOptional

                    # For unbound src single-hop, src_var is also null-filled on failure
                    null_fill = list(introduced_vars)
                    if use_apply_optional_single_hop and src_var not in null_fill:
                        null_fill.insert(0, src_var)

                    operators.append(
                        ApplyOptional(
                            subplan=subplan,
                            null_fill_vars=null_fill,
                        )
                    )

        return operators

    def _properties_to_predicate(self, variable: str, properties: dict):
        """Convert inline property predicates to a WHERE predicate.

        Args:
            variable: Variable name to check properties on
            properties: Dict of property_name -> Expression

        Returns:
            BinaryOp predicate combining all property checks with AND
        """
        from graphforge.ast.expression import BinaryOp, PropertyAccess

        if not properties:
            return None

        predicates = []
        for prop_name, prop_value in properties.items():
            # Create: variable.property = value
            left = PropertyAccess(variable=variable, property=prop_name)
            predicate = BinaryOp(op="=", left=left, right=prop_value)
            predicates.append(predicate)

        # Combine with AND if multiple properties
        if len(predicates) == 1:
            return predicates[0]

        result = predicates[0]
        for pred in predicates[1:]:
            result = BinaryOp(op="AND", left=result, right=pred)

        return result

    def _validate_with_clause(self, with_clause: WithClause) -> None:
        """Validate WITH clause for compile-time errors (Issue #172).

        Checks for:
        1. Duplicate aliases (ColumnNameConflict)
        2. Unaliased expressions that aren't simple variables (NoExpressionAlias)

        Args:
            with_clause: WITH clause to validate

        Raises:
            SyntaxError: If validation fails
        """
        from graphforge.ast.expression import Variable, Wildcard

        # UnexpectedSyntax: pattern predicates are not allowed in WITH projections
        for item in with_clause.items:
            self._validate_no_pattern_predicate(item.expression)

        # Check for duplicate aliases
        seen_aliases = set()
        for item in with_clause.items:
            # Get the alias (explicit or implicit)
            alias = (
                item.alias
                if item.alias
                else (item.expression.name if isinstance(item.expression, Variable) else None)
            )

            if alias:
                if alias in seen_aliases:
                    raise SyntaxError(
                        f"ColumnNameConflict: Multiple result columns with the same "
                        f"name '{alias}' are not supported"
                    )
                seen_aliases.add(alias)

        # Check for unaliased expressions (only Variables and Wildcard can be unaliased)
        for item in with_clause.items:
            if not item.alias and not isinstance(item.expression, (Variable, Wildcard)):
                raise SyntaxError(
                    "NoExpressionAlias: All non-variable expressions in WITH must be aliased"
                )

        # AmbiguousAggregationExpression: same rule as RETURN — WITH items that contain
        # both an aggregate and a complex non-grouping expression are ambiguous.
        for item in with_clause.items:
            if isinstance(item.expression, Wildcard):
                continue
            if self._contains_aggregate(item.expression):
                self._validate_no_complex_non_agg(item.expression)

    def _infer_with_types(self, with_clause: WithClause) -> None:
        """Infer and register variable types from WITH clause expressions.

        Narrows the type context to only the variables projected by this WITH
        clause, removing variables that are no longer in scope.

        Args:
            with_clause: WITH clause to analyze
        """
        from graphforge.ast.expression import Variable, Wildcard

        keep_existing = any(isinstance(item.expression, Wildcard) for item in with_clause.items)

        # Compute new bindings using the current context (needed for type inference)
        new_bindings: list[tuple[str, VariableType]] = []
        for item in with_clause.items:
            if isinstance(item.expression, Wildcard):
                continue  # handled by keep_existing flag above

            # Get the alias (explicit or implicit from Variable)
            alias = (
                item.alias
                if item.alias
                else (item.expression.name if isinstance(item.expression, Variable) else None)
            )

            if not alias:
                continue

            # Infer type from expression
            expr_type = self._infer_expression_type(item.expression)
            new_bindings.append((alias, expr_type))

        # WITH * keeps existing scope and adds any new aliases from the clause.
        # Otherwise, narrow scope to only the projected aliases.
        new_context = self._type_context.copy() if keep_existing else TypeContext()
        for alias, expr_type in new_bindings:
            new_context.bind_variable(alias, expr_type)
        self._type_context = new_context

    def _infer_expression_type(self, expr: Any) -> "VariableType":
        """Infer the type of an expression.

        Args:
            expr: Expression to analyze

        Returns:
            VariableType for the expression
        """
        from graphforge.ast.expression import (
            FunctionCall,
            Literal,
            PropertyAccess,
            Subscript,
            Variable,
        )

        if isinstance(expr, Literal):
            # Literal values are definitively scalar (int, str, bool, list, map, null)
            return VariableType.SCALAR

        elif isinstance(expr, Variable):
            # Look up the variable's type
            return self._type_context.get_type(expr.name)

        elif isinstance(expr, PropertyAccess):
            # Property access on any type returns scalar
            return VariableType.SCALAR

        elif isinstance(expr, FunctionCall):
            # coalesce() returns whatever type its first non-null arg has; return UNKNOWN
            # so the type context allows coalesce(node_a, node_b) AS x in MATCH (x).
            if expr.name.upper() == "COALESCE":
                return VariableType.UNKNOWN
            # Function calls return scalars
            # (Special cases like nodes() or relationships() are rare)
            return VariableType.SCALAR

        elif isinstance(expr, Subscript):
            # Subscript (e.g., nodeList[i]) — runtime type unknown; skip type checking
            return VariableType.UNKNOWN

        else:
            # Complex expressions (BinaryOp, etc.) — type not statically known
            return VariableType.UNKNOWN

    def _bind_pattern_types(self, patterns: list[Any]) -> None:
        """Bind variable types from CREATE patterns with limited validation.

        CREATE should validate variables from PREVIOUS clauses (e.g., WITH 123 AS n, CREATE (n))
        but NOT validate duplicate variables within the SAME pattern (e.g., self-loops).

        Args:
            patterns: List of patterns to process
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        for pattern in patterns:
            # Get pattern parts - patterns can be dicts or objects with parts/element
            parts = None
            path_var = None

            if isinstance(pattern, dict):
                parts = pattern.get("parts", pattern.get("elements", []))
                path_var = pattern.get("path_variable")
            elif hasattr(pattern, "parts"):
                parts = pattern.parts
                path_var = getattr(pattern, "path_variable", None)
            elif hasattr(pattern, "elements"):
                parts = pattern.elements
                path_var = getattr(pattern, "path_variable", None)

            # Take snapshot of variables bound BEFORE this pattern
            pre_existing_vars = set()
            if parts:
                for part in parts:
                    if isinstance(part, (NodePattern, RelationshipPattern)) and part.variable:
                        if self._type_context.has_variable(part.variable):
                            pre_existing_vars.add(part.variable)

            # Now validate and bind
            if parts:
                for part in parts:
                    if isinstance(part, NodePattern):
                        if part.variable:
                            # Only validate if variable existed BEFORE this pattern
                            if part.variable in pre_existing_vars:
                                self._type_context.validate_compatible(
                                    part.variable, VariableType.NODE
                                )
                            # BIND: Register as node type
                            self._type_context.bind_variable(part.variable, VariableType.NODE)

                    elif isinstance(part, RelationshipPattern):
                        if part.variable:
                            # Only validate if variable existed BEFORE this pattern
                            if part.variable in pre_existing_vars:
                                self._type_context.validate_compatible(
                                    part.variable, VariableType.RELATIONSHIP
                                )
                            # BIND: Register as relationship type
                            self._type_context.bind_variable(
                                part.variable, VariableType.RELATIONSHIP
                            )

            # Handle path variable if present
            if path_var:
                # Validate if from previous clause
                if path_var in pre_existing_vars or self._type_context.has_variable(path_var):
                    self._type_context.validate_compatible(path_var, VariableType.PATH)
                # BIND: Register as path type
                self._type_context.bind_variable(path_var, VariableType.PATH)

    def _validate_pattern_types(self, patterns: list[Any]) -> None:
        """Validate and bind variable types from MERGE patterns.

        Args:
            patterns: List of patterns to validate
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        for pattern in patterns:
            # Get pattern parts - patterns can be dicts or objects with parts/elements
            parts = None
            path_var = None

            if isinstance(pattern, NodePattern):
                # Bare NodePattern (unit tests or direct AST construction)
                parts = [pattern]
            elif isinstance(pattern, dict):
                parts = pattern.get("parts", pattern.get("elements", []))
                path_var = pattern.get("path_variable")
            elif hasattr(pattern, "parts"):
                parts = pattern.parts
                path_var = getattr(pattern, "path_variable", None)
            elif hasattr(pattern, "elements"):
                parts = pattern.elements
                path_var = getattr(pattern, "path_variable", None)

            # Validate each part (node or relationship)
            if parts:
                part: Any
                for part in parts:
                    if isinstance(part, NodePattern):
                        if part.variable:
                            # VALIDATE: Check if variable already bound to incompatible type
                            self._type_context.validate_compatible(part.variable, VariableType.NODE)
                            # BIND: Register as node type
                            self._type_context.bind_variable(part.variable, VariableType.NODE)

                    elif isinstance(part, RelationshipPattern):
                        if part.variable:
                            # VALIDATE: Check if variable already bound to incompatible type
                            self._type_context.validate_compatible(
                                part.variable, VariableType.RELATIONSHIP
                            )
                            # BIND: Register as relationship type
                            self._type_context.bind_variable(
                                part.variable, VariableType.RELATIONSHIP
                            )

            # Handle path variable if present
            if path_var:
                # VALIDATE: Check if variable already bound to incompatible type
                self._type_context.validate_compatible(path_var, VariableType.PATH)
                # BIND: Register as path type
                self._type_context.bind_variable(path_var, VariableType.PATH)

    def _collect_variables(self, expr: Any) -> list["Variable"]:
        """Walk an expression tree and collect all Variable nodes."""
        if isinstance(expr, Variable):
            return [expr]
        result: list[Variable] = []
        if isinstance(expr, BinaryOp):
            result.extend(self._collect_variables(expr.left))
            result.extend(self._collect_variables(expr.right))
        elif isinstance(expr, FunctionCall):
            for arg in expr.args or []:
                result.extend(self._collect_variables(arg))
        elif isinstance(expr, (list, tuple)):
            for item in expr:
                result.extend(self._collect_variables(item))
        elif hasattr(expr, "__dict__"):
            for val in vars(expr).values():
                if val is not None and not isinstance(val, (str, int, float, bool)):
                    result.extend(self._collect_variables(val))
        return result

    def _has_aggregations(self, return_clause: ReturnClause) -> bool:
        """Check if RETURN clause contains any aggregation functions.

        Args:
            return_clause: RETURN clause to check

        Returns:
            True if any ReturnItem contains a FunctionCall
        """
        for item in return_clause.items:
            if self._contains_aggregate(item.expression):
                return True
        return False

    # Aggregation function names (canonical uppercase)
    _AGGREGATE_FUNCTIONS = frozenset(
        {
            "COUNT",
            "SUM",
            "AVG",
            "MIN",
            "MAX",
            "COLLECT",
            "PERCENTILEDISC",
            "PERCENTILECONT",
            "STDEV",
            "STDEVP",
        }
    )

    def _contains_aggregate(self, expr) -> bool:
        """Recursively check if an expression contains aggregation functions.

        Args:
            expr: Expression to check

        Returns:
            True if expression is or contains an aggregation FunctionCall
        """
        if isinstance(expr, FunctionCall):
            if expr.name.upper() in self._AGGREGATE_FUNCTIONS:
                return True
            # Recurse into non-aggregate function args (e.g., size(collect(a)))
            return any(self._contains_aggregate(arg) for arg in expr.args)
        elif isinstance(expr, BinaryOp):
            return self._contains_aggregate(expr.left) or self._contains_aggregate(expr.right)
        elif isinstance(expr, UnaryOp):
            return self._contains_aggregate(expr.operand)
        elif isinstance(expr, CaseExpression):
            subject_agg = expr.subject is not None and self._contains_aggregate(expr.subject)
            return (
                subject_agg
                or any(
                    self._contains_aggregate(cond) or self._contains_aggregate(result)
                    for cond, result in expr.when_clauses
                )
                or (expr.else_expr is not None and self._contains_aggregate(expr.else_expr))
            )
        elif isinstance(expr, ListComprehension):
            return (
                self._contains_aggregate(expr.list_expr)
                or (expr.filter_expr is not None and self._contains_aggregate(expr.filter_expr))
                or (expr.map_expr is not None and self._contains_aggregate(expr.map_expr))
            )
        elif isinstance(expr, Subscript):
            return self._contains_aggregate(expr.base)
        elif isinstance(expr, ParenthesizedExpr):
            return self._contains_aggregate(expr.expr)
        elif isinstance(expr, Literal) and isinstance(expr.value, dict):
            return any(
                not isinstance(val, (int, float, str, bool, type(None)))
                and self._contains_aggregate(val)
                for val in expr.value.values()
            )
        from graphforge.ast.expression import QuantifierExpression

        if isinstance(expr, QuantifierExpression):
            return self._contains_aggregate(expr.list_expr) or self._contains_aggregate(
                expr.predicate
            )
        return False

    def _extract_aggregates(self, expr, seen_ids: set, result: list) -> None:
        """Recursively extract aggregate FunctionCall nodes from an expression.

        Populates `result` with all distinct aggregate FunctionCall nodes found.
        Does not recurse into aggregate function args (aggregates cannot be nested).

        Args:
            expr: Expression to search
            seen_ids: Set of object ids already added (to avoid duplicates)
            result: List to append aggregate FunctionCall nodes into
        """
        if isinstance(expr, FunctionCall):
            if expr.name.upper() in self._AGGREGATE_FUNCTIONS:
                expr_id = id(expr)
                if expr_id not in seen_ids:
                    seen_ids.add(expr_id)
                    result.append(expr)
                return  # Don't recurse into aggregate args
            # Recurse into non-aggregate function args
            for arg in expr.args:
                self._extract_aggregates(arg, seen_ids, result)
        elif isinstance(expr, BinaryOp):
            self._extract_aggregates(expr.left, seen_ids, result)
            self._extract_aggregates(expr.right, seen_ids, result)
        elif isinstance(expr, UnaryOp):
            self._extract_aggregates(expr.operand, seen_ids, result)
        elif isinstance(expr, CaseExpression):
            if expr.subject is not None:
                self._extract_aggregates(expr.subject, seen_ids, result)
            for cond, res in expr.when_clauses:
                self._extract_aggregates(cond, seen_ids, result)
                self._extract_aggregates(res, seen_ids, result)
            if expr.else_expr is not None:
                self._extract_aggregates(expr.else_expr, seen_ids, result)
        elif isinstance(expr, ListComprehension):
            self._extract_aggregates(expr.list_expr, seen_ids, result)
            if expr.filter_expr is not None:
                self._extract_aggregates(expr.filter_expr, seen_ids, result)
            if expr.map_expr is not None:
                self._extract_aggregates(expr.map_expr, seen_ids, result)
        elif isinstance(expr, Subscript):
            self._extract_aggregates(expr.base, seen_ids, result)
        elif isinstance(expr, ParenthesizedExpr):
            self._extract_aggregates(expr.expr, seen_ids, result)
        elif isinstance(expr, Literal) and isinstance(expr.value, dict):
            for val in expr.value.values():
                if not isinstance(val, (int, float, str, bool, type(None))):
                    self._extract_aggregates(val, seen_ids, result)
        else:
            from graphforge.ast.expression import QuantifierExpression

            if isinstance(expr, QuantifierExpression):
                self._extract_aggregates(expr.list_expr, seen_ids, result)
                self._extract_aggregates(expr.predicate, seen_ids, result)

    def _split_aggregates(self, return_clause: ReturnClause) -> tuple[list, list]:
        """Split RETURN items into grouping expressions and aggregate function calls.

        For composite aggregate expressions (e.g., count(n) + 3), the embedded
        aggregate FunctionCall (count(n)) is extracted into agg_exprs, while the
        full expression remains accessible via return_items on the Aggregate operator.

        Args:
            return_clause: RETURN clause to split

        Returns:
            Tuple of (grouping_expressions, aggregate_function_calls)
        """
        grouping_exprs = []
        agg_exprs: list = []
        seen_ids: set = set()

        for item in return_clause.items:
            if self._contains_aggregate(item.expression):
                self._extract_aggregates(item.expression, seen_ids, agg_exprs)
            else:
                grouping_exprs.append(item.expression)

        return grouping_exprs, agg_exprs

    def _validate_no_aggregate_in_list_comp(self, expr: Any) -> None:
        """Recursively check that list comprehension map/filter don't contain aggregation.

        Aggregation inside a list comprehension is a SyntaxError (InvalidAggregation)
        because list comprehensions have their own element scope and do not group rows.

        Args:
            expr: Expression to validate

        Raises:
            SyntaxError: InvalidAggregation if aggregation is found inside a list comp
        """
        if isinstance(expr, ListComprehension):
            if expr.filter_expr is not None and self._contains_aggregate(expr.filter_expr):
                raise SyntaxError(
                    "InvalidAggregation: Aggregation functions are not allowed "
                    "in list comprehension filter expressions"
                )
            if expr.map_expr is not None and self._contains_aggregate(expr.map_expr):
                raise SyntaxError(
                    "InvalidAggregation: Aggregation functions are not allowed "
                    "in list comprehension mapping expressions"
                )
            # Recurse to catch nested comprehensions
            self._validate_no_aggregate_in_list_comp(expr.list_expr)
        elif isinstance(expr, BinaryOp):
            self._validate_no_aggregate_in_list_comp(expr.left)
            self._validate_no_aggregate_in_list_comp(expr.right)
        elif isinstance(expr, FunctionCall):
            for arg in expr.args:
                self._validate_no_aggregate_in_list_comp(arg)
        elif isinstance(expr, UnaryOp):
            self._validate_no_aggregate_in_list_comp(expr.operand)

    def _validate_order_by_scope(
        self, order_by_items: list, extra_aliases: set[str] | None = None
    ) -> None:
        """Validate that all variables referenced in ORDER BY items are in scope.

        Used for non-aggregating ORDER BY in WITH and RETURN (after scope narrowing).
        Parameters ($name) are substituted before parsing and are never Variable nodes,
        so they are never checked here.

        Args:
            order_by_items: List of OrderByItem objects to validate
            extra_aliases: Additional names that are valid (e.g., aliases introduced by
                the current WITH clause that are co-defined alongside the ORDER BY)

        Raises:
            SyntaxError: UndefinedVariable if any variable is not in current scope
        """
        allowed_extra = extra_aliases or set()
        for item in order_by_items:
            vars_found: set[str] = set()
            self._collect_expr_variables(vars_found, item.expression)
            for var_name in vars_found:
                if (
                    not var_name.startswith("$")
                    and not self._type_context.has_variable(var_name)
                    and var_name not in allowed_extra
                ):
                    raise SyntaxError(
                        f"UndefinedVariable: Variable `{var_name}` is not defined "
                        f"and cannot be used in ORDER BY"
                    )

    def _validate_order_by_aggregation(
        self,
        order_by_items: list,
        projected_items: list,
        has_aggregation: bool,
    ) -> None:
        """Validate ORDER BY expressions against openCypher aggregation rules.

        Enforces three compile-time rules:
        1. InvalidAggregation: ORDER BY has aggregates but RETURN/WITH does not.
        2. UndefinedVariable: ORDER BY aggregate expression uses variables not in
           the projected grouping scope.
        3. AmbiguousAggregationExpression: ORDER BY has aggregate mixed with a
           complex non-aggregate sub-expression.

        Args:
            order_by_items: OrderByItem list from the ORDER BY clause
            projected_items: ReturnItem/WithItem list from RETURN or WITH
            has_aggregation: Whether the RETURN/WITH clause itself aggregates

        Raises:
            SyntaxError: If any rule is violated
        """
        for item in order_by_items:
            if not self._contains_aggregate(item.expression):
                continue

            if not has_aggregation:
                raise SyntaxError(
                    "InvalidAggregation: Cannot use aggregation functions in ORDER BY "
                    "when the associated RETURN/WITH clause does not contain aggregations"
                )

            # Collect projected aggregate FunctionCall nodes for equality checks.
            # ORDER BY aggregates that structurally match a projected aggregate are
            # always valid; those that don't must only reference grouping aliases.
            projected_agg_exprs: list = []
            seen_ids_proj: set = set()
            for proj_item in projected_items:
                self._extract_aggregates(proj_item.expression, seen_ids_proj, projected_agg_exprs)

            # alias_vars: only aliases from non-aggregate projected items.
            # Used to validate args of ORDER BY aggregates not in projected_agg_exprs,
            # since post-aggregation rows only expose grouping-key aliases.
            alias_vars: set[str] = set()
            for proj_item in projected_items:
                if proj_item.alias and not self._contains_aggregate(proj_item.expression):
                    alias_vars.add(proj_item.alias)

            # grouping_vars: aliases + source variables from non-aggregate projected
            # items. Used to validate non-aggregate parts of ORDER BY expressions.
            grouping_vars: set[str] = set()
            for proj_item in projected_items:
                if proj_item.alias:
                    grouping_vars.add(proj_item.alias)
                if not self._contains_aggregate(proj_item.expression):
                    self._collect_expr_variables(grouping_vars, proj_item.expression)

            self._check_order_by_agg_expr(
                item.expression, grouping_vars, projected_agg_exprs, alias_vars
            )

    def _collect_expr_variables(self, result: set, expr) -> None:
        """Collect all variable names referenced in an expression.

        Args:
            result: Set to populate with variable names
            expr: Expression to traverse
        """
        from graphforge.ast.expression import PropertyAccess, Variable

        if isinstance(expr, Variable):
            result.add(expr.name)
        elif isinstance(expr, PropertyAccess):
            if expr.variable:
                result.add(expr.variable)
            elif expr.base is not None:
                self._collect_expr_variables(result, expr.base)
        elif isinstance(expr, BinaryOp):
            self._collect_expr_variables(result, expr.left)
            self._collect_expr_variables(result, expr.right)
        elif isinstance(expr, UnaryOp):
            self._collect_expr_variables(result, expr.operand)
        elif isinstance(expr, FunctionCall):
            if expr.name.upper() not in self._AGGREGATE_FUNCTIONS:
                for arg in expr.args:
                    self._collect_expr_variables(result, arg)
        elif isinstance(expr, ParenthesizedExpr):
            self._collect_expr_variables(result, expr.expr)

    def _check_order_by_agg_expr(
        self,
        expr,
        grouping_vars: set,
        projected_agg_exprs: list | None = None,
        alias_vars: set | None = None,
    ) -> None:
        """Recursively validate an ORDER BY expression that contains aggregates.

        Validates the non-aggregate portions of the expression against the grouping
        scope, raising errors for ambiguous or undefined references.

        When *projected_agg_exprs* is provided, aggregate FunctionCalls that do not
        match any projected aggregate are validated against *alias_vars* (the alias-
        only subset of the post-aggregation scope).  Aggregate calls that *do* match
        a projected aggregate are always valid.  When *projected_agg_exprs* is None
        the legacy behaviour is used: any aggregate call is unconditionally accepted.

        Args:
            expr: Expression to validate
            grouping_vars: Variable names from projected grouping expressions (aliases
                + source variables); used for non-aggregate sub-expression validation.
            projected_agg_exprs: Aggregate FunctionCall nodes from projected items.
                If provided, ORDER BY aggregates must either match one of these or have
                args that reference only *alias_vars*.
            alias_vars: Alias-only grouping var names.  Used to validate args of ORDER
                BY aggregates that are not present in *projected_agg_exprs*.

        Raises:
            SyntaxError: AmbiguousAggregationExpression or UndefinedVariable
        """
        if isinstance(expr, FunctionCall):
            if expr.name.upper() in self._AGGREGATE_FUNCTIONS:
                if projected_agg_exprs is not None:
                    # Valid if this is the same aggregate as one of the projected ones.
                    if any(expr == p for p in projected_agg_exprs):
                        return
                    # Different aggregate: args must only reference grouping aliases.
                    # Use _validate_agg_arg_scope (not _validate_non_agg_context) so
                    # that BinaryOps inside the aggregate arg raise UndefinedVariable
                    # rather than AmbiguousAggregationExpression.
                    arg_scope = alias_vars if alias_vars is not None else set()
                    for arg in expr.args:
                        self._validate_agg_arg_scope(arg, arg_scope)
                    return
                return  # projected_agg_exprs is None — legacy: always valid
            for arg in expr.args:
                if self._contains_aggregate(arg):
                    self._check_order_by_agg_expr(
                        arg, grouping_vars, projected_agg_exprs, alias_vars
                    )
        elif isinstance(expr, BinaryOp):
            left_has_agg = self._contains_aggregate(expr.left)
            right_has_agg = self._contains_aggregate(expr.right)
            if left_has_agg and right_has_agg:
                self._check_order_by_agg_expr(
                    expr.left, grouping_vars, projected_agg_exprs, alias_vars
                )
                self._check_order_by_agg_expr(
                    expr.right, grouping_vars, projected_agg_exprs, alias_vars
                )
            elif left_has_agg:
                self._validate_non_agg_context(expr.right, grouping_vars)
                self._check_order_by_agg_expr(
                    expr.left, grouping_vars, projected_agg_exprs, alias_vars
                )
            elif right_has_agg:
                self._validate_non_agg_context(expr.left, grouping_vars)
                self._check_order_by_agg_expr(
                    expr.right, grouping_vars, projected_agg_exprs, alias_vars
                )
        elif isinstance(expr, UnaryOp):
            if self._contains_aggregate(expr.operand):
                self._check_order_by_agg_expr(
                    expr.operand, grouping_vars, projected_agg_exprs, alias_vars
                )

    def _validate_non_agg_context(self, expr, grouping_vars: set) -> None:
        """Validate a non-aggregate sub-expression within an ORDER BY aggregate expression.

        A non-aggregate context must be a simple expression. Complex expressions
        (BinaryOp of non-aggregate terms) are rejected as ambiguous.

        Args:
            expr: Non-aggregate sub-expression to validate
            grouping_vars: Variable names from projected grouping expressions

        Raises:
            SyntaxError: AmbiguousAggregationExpression if complex,
                         UndefinedVariable if variable not in projected scope
        """
        from graphforge.ast.expression import Literal, PropertyAccess, Variable

        if isinstance(expr, Literal):
            return  # Constants are always valid
        elif isinstance(expr, Variable):
            if not expr.name.startswith("$") and expr.name not in grouping_vars:
                raise SyntaxError(
                    f"UndefinedVariable: Variable '{expr.name}' is not projected "
                    f"and cannot be used in ORDER BY with aggregation"
                )
        elif isinstance(expr, PropertyAccess):
            var = expr.variable
            if var is None and isinstance(expr.base, Variable):
                var = expr.base.name
            if var is not None and var not in grouping_vars:
                raise SyntaxError(
                    f"UndefinedVariable: Variable '{var}' is not projected "
                    f"and cannot be used in ORDER BY with aggregation"
                )
        elif isinstance(expr, BinaryOp):
            raise SyntaxError(
                "AmbiguousAggregationExpression: The non-aggregate portion of an ORDER BY "
                "expression containing aggregates must be a simple expression, not a "
                "complex expression combining multiple terms"
            )
        elif isinstance(expr, UnaryOp):
            self._validate_non_agg_context(expr.operand, grouping_vars)
        elif isinstance(expr, ParenthesizedExpr):
            self._validate_non_agg_context(expr.expr, grouping_vars)
        elif isinstance(expr, FunctionCall):
            if expr.name.upper() not in self._AGGREGATE_FUNCTIONS:
                for arg in expr.args:
                    self._validate_non_agg_context(arg, grouping_vars)

    def _validate_agg_arg_scope(self, expr, alias_vars: set) -> None:
        """Validate an argument of a non-projected ORDER BY aggregate.

        Unlike _validate_non_agg_context, BinaryOp is allowed here (it is simply
        an arithmetic sub-expression inside the aggregate).  Raises UndefinedVariable
        if any variable reference is not in *alias_vars*.

        Args:
            expr: Expression to validate (the arg of an aggregate FunctionCall)
            alias_vars: Alias-only variable names valid in post-aggregation scope

        Raises:
            SyntaxError: UndefinedVariable if a variable is not in alias_vars
        """
        from graphforge.ast.expression import Literal, PropertyAccess, Variable

        if isinstance(expr, Literal):
            return
        elif isinstance(expr, Variable):
            if not expr.name.startswith("$") and expr.name not in alias_vars:
                raise SyntaxError(
                    f"UndefinedVariable: Variable '{expr.name}' is not projected "
                    f"and cannot be used as an argument to an ORDER BY aggregate"
                )
        elif isinstance(expr, PropertyAccess):
            var = expr.variable
            if var is None and isinstance(expr.base, Variable):
                var = expr.base.name
            if var is not None and var not in alias_vars:
                raise SyntaxError(
                    f"UndefinedVariable: Variable '{var}' is not projected "
                    f"and cannot be used as an argument to an ORDER BY aggregate"
                )
        elif isinstance(expr, BinaryOp):
            self._validate_agg_arg_scope(expr.left, alias_vars)
            self._validate_agg_arg_scope(expr.right, alias_vars)
        elif isinstance(expr, UnaryOp):
            self._validate_agg_arg_scope(expr.operand, alias_vars)
        elif isinstance(expr, ParenthesizedExpr):
            self._validate_agg_arg_scope(expr.expr, alias_vars)
        elif isinstance(expr, FunctionCall):
            if expr.name.upper() not in self._AGGREGATE_FUNCTIONS:
                for arg in expr.args:
                    self._validate_agg_arg_scope(arg, alias_vars)

    def _validate_create_patterns(self, patterns: list[Any]) -> None:
        """
        Validate CREATE patterns for structural and scoping constraints.

        Validates per-pattern rules and raises SyntaxError (with one of the following error tags
        in the message) when a violation is detected:
        - VariableAlreadyBound: node re-creation with labels/properties, standalone re-creation,
          or relationship variable already bound (including intra-pattern rebinds)
        - NoSingleRelationshipType: relationship has zero or multiple types
        - RequiresDirectedRelationship: relationship is undirected
        - CreatingVarLength: variable-length relationship in CREATE
        - UndefinedVariable: a property expression references an unbound variable

        Behavior notes:
        - A previously bound node may be reused as a bare endpoint (no labels, no properties)
          in a non-standalone pattern; using a bound node with labels/properties or as a
          standalone CREATE pattern is rejected.
        - Tracks variables bound earlier within the same CREATE clause to detect intra-pattern
          rebindings such as `CREATE (n:Foo)-[:T]->(), (n:Bar)-[:T]->()`.
        - Validates expressions on node/relationship properties to ensure referenced variables
          are in scope.
        """
        # Track variables bound within this CREATE invocation (intra-pattern rebind check)
        bound_in_create: set[str] = set()
        bound_rel_in_create: set[str] = set()

        for pattern in patterns:
            parts = None
            if isinstance(pattern, dict):
                parts = pattern.get("parts", pattern.get("elements", []))
            elif hasattr(pattern, "parts"):
                parts = pattern.parts
            elif hasattr(pattern, "elements"):
                parts = pattern.elements
            if not parts:
                continue

            # A standalone pattern has only one NodePattern and no relationships.
            node_parts = [p for p in parts if isinstance(p, NodePattern)]
            rel_parts = [p for p in parts if isinstance(p, RelationshipPattern)]
            is_standalone_node = len(rel_parts) == 0 and len(node_parts) == 1

            for part in parts:
                if isinstance(part, NodePattern):
                    if part.variable:
                        already_bound = (
                            self._type_context.has_variable(part.variable)
                            or part.variable in bound_in_create
                        )
                        if already_bound:
                            # Bare endpoint (no labels, no properties) in a non-standalone
                            # pattern is valid — executor reuses the existing node.
                            # has_explicit_properties is True when {} was written (even empty).
                            has_labels = len(part.labels) > 0
                            has_properties = len(part.properties) > 0 or getattr(
                                part, "has_explicit_properties", False
                            )
                            if is_standalone_node or has_labels or has_properties:
                                raise SyntaxError(
                                    f"VariableAlreadyBound: Variable `{part.variable}` "
                                    f"already bound"
                                )
                        else:
                            # New node: check property expressions for undefined variables.
                            # Variables introduced earlier in the same CREATE pattern are valid.
                            for prop_expr in part.properties.values():
                                self._validate_expr_variables_in_scope(
                                    prop_expr, locally_bound=frozenset(bound_in_create)
                                )
                            bound_in_create.add(part.variable)
                    else:
                        # Anonymous node — check properties
                        for prop_expr in part.properties.values():
                            self._validate_expr_variables_in_scope(
                                prop_expr, locally_bound=frozenset(bound_in_create)
                            )

                elif isinstance(part, RelationshipPattern):
                    # Relationship variables are always invalid if already bound
                    if part.variable and (
                        self._type_context.has_variable(part.variable)
                        or part.variable in bound_rel_in_create
                    ):
                        raise SyntaxError(
                            f"VariableAlreadyBound: Variable `{part.variable}` already bound"
                        )
                    if part.variable:
                        bound_rel_in_create.add(part.variable)
                    if part.min_hops is not None or part.max_hops is not None:
                        raise SyntaxError(
                            "CreatingVarLength: Variable-length relationships cannot be created"
                        )
                    if len(part.types) == 0:
                        raise SyntaxError(
                            "NoSingleRelationshipType: Exactly one relationship type required"
                        )
                    if len(part.types) > 1:
                        raise SyntaxError(
                            "NoSingleRelationshipType: Exactly one relationship type required"
                        )
                    if part.direction == Direction.UNDIRECTED:
                        raise SyntaxError(
                            "RequiresDirectedRelationship: CREATE requires a directed relationship"
                        )
                    for prop_expr in part.properties.values():
                        self._validate_expr_variables_in_scope(
                            prop_expr, locally_bound=frozenset(bound_in_create)
                        )

    def _validate_merge_patterns(self, patterns: list[Any]) -> None:
        """Validate MERGE patterns for structural constraints.

        Raises SyntaxError for:
        - VariableAlreadyBound: node/relationship variable already bound in outer scope,
          or variable re-used with new labels/properties
        - NoSingleRelationshipType: relationship has zero or multiple types
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        for pattern in patterns:
            parts: list[Any] = []
            if isinstance(pattern, dict):
                parts = list(pattern.get("parts", pattern.get("elements", [])) or [])
            elif hasattr(pattern, "parts"):
                parts = pattern.parts
            elif hasattr(pattern, "elements"):
                parts = pattern.elements

            rel_parts = [p for p in parts if isinstance(p, RelationshipPattern)]
            node_parts = [p for p in parts if isinstance(p, NodePattern)]
            is_standalone_node = len(rel_parts) == 0 and len(node_parts) == 1

            for part in parts:
                if isinstance(part, NodePattern):
                    if part.variable and self._type_context.has_variable(part.variable):
                        # Standalone MERGE (a) re-merging already-bound node → error
                        # OR bound variable re-used with labels/properties → error
                        has_labels = len(part.labels) > 0
                        has_properties = len(part.properties) > 0 or getattr(
                            part, "has_explicit_properties", False
                        )
                        if is_standalone_node or has_labels or has_properties:
                            raise SyntaxError(
                                f"VariableAlreadyBound: Variable `{part.variable}` already bound"
                            )
                elif isinstance(part, RelationshipPattern):
                    if part.variable and self._type_context.has_variable(part.variable):
                        raise SyntaxError(
                            f"VariableAlreadyBound: Variable `{part.variable}` already bound"
                        )
                    # MERGE does not support variable-length relationships
                    if part.min_hops is not None or part.max_hops is not None:
                        raise SyntaxError(
                            "CreatingVarLength: Variable-length relationships cannot be used "
                            "in MERGE"
                        )
                    # MERGE requires exactly one relationship type
                    if rel_parts:
                        if len(part.types) == 0:
                            raise SyntaxError(
                                "NoSingleRelationshipType: Exactly one relationship type required "
                                "for MERGE"
                            )
                        if len(part.types) > 1:
                            raise SyntaxError(
                                "NoSingleRelationshipType: Exactly one relationship type required "
                                "for MERGE"
                            )

    def _validate_path_variable_conflicts(self, ast: Any) -> None:
        """Raise SyntaxError if a path variable name is also used as a node/rel variable
        within the same pattern (VariableAlreadyBound)."""
        from graphforge.ast.clause import MatchClause
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        for clause in ast.clauses:
            if not isinstance(clause, MatchClause):
                continue
            for pattern in clause.patterns:
                if not isinstance(pattern, dict) or "parts" not in pattern:
                    continue
                path_var = pattern.get("path_variable")
                if not path_var:
                    continue
                for part in pattern["parts"]:
                    if isinstance(part, (NodePattern, RelationshipPattern)):
                        if part.variable == path_var:
                            raise SyntaxError(
                                f"VariableAlreadyBound: Variable `{path_var}` used as both "
                                f"path variable and pattern element variable"
                            )

    def _validate_no_pattern_predicate(self, expr: Any) -> None:
        """Raise SyntaxError(UnexpectedSyntax) if expr contains a PatternPredicate.

        Pattern predicates are only allowed in WHERE clauses, not in projections,
        SET expressions, or other contexts.
        """
        from graphforge.ast.expression import PatternPredicate as PatternPredicateCls

        if isinstance(expr, PatternPredicateCls):
            raise SyntaxError("UnexpectedSyntax: Pattern expressions cannot be used here")
        if isinstance(expr, BinaryOp):
            self._validate_no_pattern_predicate(expr.left)
            self._validate_no_pattern_predicate(expr.right)
        elif isinstance(expr, UnaryOp):
            self._validate_no_pattern_predicate(expr.operand)
        elif isinstance(expr, FunctionCall):
            for arg in expr.args or []:
                self._validate_no_pattern_predicate(arg)
        elif hasattr(expr, "__dict__"):
            for val in vars(expr).values():
                if val is not None and not isinstance(val, (str, int, float, bool, frozenset)):
                    self._validate_no_pattern_predicate(val)

    def _validate_set_clause_variables(self, set_clause: Any) -> None:
        """Check that all variables referenced in SET items are in scope.

        Raises SyntaxError(UndefinedVariable) for any unbound variable.
        """
        from graphforge.ast.expression import PropertyAccess

        for item in set_clause.items:
            if len(item) == 2:
                # (PropertyAccess/Variable, expr)
                lhs, rhs = item
                if isinstance(lhs, PropertyAccess):
                    var_name = (
                        lhs.variable
                        if lhs.variable
                        else (
                            lhs.base.name
                            if lhs.base is not None and isinstance(lhs.base, Variable)
                            else None
                        )
                    )
                    if var_name and not self._type_context.has_variable(var_name):
                        raise SyntaxError(
                            f"UndefinedVariable: Variable `{var_name}` is not defined"
                        )
                elif isinstance(lhs, Variable):
                    if not self._type_context.has_variable(lhs.name):
                        raise SyntaxError(
                            f"UndefinedVariable: Variable `{lhs.name}` is not defined"
                        )
                self._validate_expr_variables_in_scope(rhs)
                self._validate_no_pattern_predicate(rhs)
            elif len(item) == 3:
                # (Variable, op, expr) — SET n = {map} or SET n += {map}
                lhs, _op, rhs = item
                if isinstance(lhs, Variable):
                    if not self._type_context.has_variable(lhs.name):
                        raise SyntaxError(
                            f"UndefinedVariable: Variable `{lhs.name}` is not defined"
                        )
                self._validate_expr_variables_in_scope(rhs)
                self._validate_no_pattern_predicate(rhs)

    def _validate_delete_clause_variables(self, delete_clause: Any) -> None:
        """Check that all variables in DELETE are in scope.

        Raises SyntaxError(UndefinedVariable) for any unbound variable.
        """
        for var_ref in delete_clause.variables:
            if isinstance(var_ref, str):
                if not self._type_context.has_variable(var_ref):
                    raise SyntaxError(f"UndefinedVariable: Variable `{var_ref}` is not defined")
            else:
                # Expression operand (PropertyAccess, Subscript) — validate inline
                self._validate_expr_variables_in_scope(var_ref)

    def _validate_return_clause(self, return_clause: Any) -> None:
        """Validate RETURN clause for compile-time errors.

        Raises SyntaxError for:
        - NoVariablesInScope: RETURN * with no variables in scope
        - ColumnNameConflict: duplicate output column names
        - UndefinedVariable: referencing a variable not in scope
        """
        from graphforge.ast.expression import Variable, Wildcard

        # UnexpectedSyntax: pattern predicates are not allowed in RETURN projections
        for item in return_clause.items:
            self._validate_no_pattern_predicate(item.expression)

        # NoVariablesInScope: RETURN * requires at least one user-visible bound variable.
        # Exclude __anon_* synthetic variables created for anonymous MATCH nodes.
        has_wildcard = any(isinstance(item.expression, Wildcard) for item in return_clause.items)
        if has_wildcard:
            visible_vars = {
                v for v in self._type_context.bound_variables() if not v.startswith("__anon_")
            }
            if not visible_vars:
                raise SyntaxError(
                    "NoVariablesInScope: RETURN * requires at least one variable in scope"
                )

        # ColumnNameConflict: duplicate column names
        seen_aliases: set[str] = set()
        for item in return_clause.items:
            alias = (
                item.alias
                if item.alias
                else (item.expression.name if isinstance(item.expression, Variable) else None)
            )
            if alias:
                if alias in seen_aliases:
                    raise SyntaxError(
                        f"ColumnNameConflict: Multiple result columns with the same "
                        f"name '{alias}' are not supported"
                    )
                seen_aliases.add(alias)

        # UndefinedVariable: free variable references must be in scope.
        # Skips variables locally bound by quantifiers, list/pattern comprehensions, etc.
        for item in return_clause.items:
            if isinstance(item.expression, Wildcard):
                continue
            for var in self._collect_free_variables(item.expression, frozenset()):
                # $param references are always valid — resolved at runtime
                if not var.name.startswith("$") and not self._type_context.has_variable(var.name):
                    raise SyntaxError(f"UndefinedVariable: Variable `{var.name}` is not defined")

        # AmbiguousAggregationExpression: a return item that contains both an aggregate
        # function and a complex (BinaryOp/FunctionCall) non-aggregate sub-expression
        # is ambiguous. Simple property accesses and variables are allowed.
        for item in return_clause.items:
            if isinstance(item.expression, Wildcard):
                continue
            if self._contains_aggregate(item.expression):
                self._validate_no_complex_non_agg(item.expression)
                self._validate_no_nondeterministic_in_agg(item.expression)

    def _validate_no_nondeterministic_in_agg(self, expr: Any) -> None:
        """Validate that aggregate function arguments do not contain non-deterministic functions.

        openCypher spec: aggregate arguments must be constant/deterministic expressions.
        Raises SyntaxError: NonConstantExpression if rand(), timestamp(), etc. found inside
        an aggregate.
        """
        _nondeterministic = frozenset({"RAND", "TIMESTAMP", "RANDOMUUID"})

        if isinstance(expr, FunctionCall):
            if expr.name.upper() in self._AGGREGATE_FUNCTIONS:
                # Walk the aggregate's args for non-deterministic functions
                for arg in expr.args:
                    self._check_nondeterministic_expr(arg, _nondeterministic)
                return
            # Non-aggregate function: recurse into args that contain aggregates
            for arg in expr.args:
                if self._contains_aggregate(arg):
                    self._validate_no_nondeterministic_in_agg(arg)
        elif isinstance(expr, BinaryOp):
            self._validate_no_nondeterministic_in_agg(expr.left)
            self._validate_no_nondeterministic_in_agg(expr.right)
        elif isinstance(expr, UnaryOp):
            self._validate_no_nondeterministic_in_agg(expr.operand)

    def _check_nondeterministic_expr(self, expr: Any, nondeterministic: frozenset) -> None:
        """Recursively check an expression for non-deterministic function calls."""
        if isinstance(expr, FunctionCall):
            if expr.name.upper() in nondeterministic:
                raise SyntaxError(
                    f"NonConstantExpression: {expr.name.lower()}() is not allowed as an "
                    f"argument to an aggregation function"
                )
            for arg in expr.args:
                self._check_nondeterministic_expr(arg, nondeterministic)
        elif isinstance(expr, BinaryOp):
            self._check_nondeterministic_expr(expr.left, nondeterministic)
            self._check_nondeterministic_expr(expr.right, nondeterministic)
        elif isinstance(expr, UnaryOp):
            self._check_nondeterministic_expr(expr.operand, nondeterministic)

    def _is_simple_non_agg_expr(self, expr: Any) -> bool:
        """Return True if expr is a "simple" non-aggregate expression.

        Simple means: Literal, Variable, PropertyAccess, or a Parenthesized/Unary
        wrapper around one of those. BinaryOp and non-aggregate FunctionCall are complex.
        """
        from graphforge.ast.expression import (
            Literal,
            ParenthesizedExpr,
            PropertyAccess,
            UnaryOp,
            Variable,
        )

        if isinstance(expr, (Literal, Variable, PropertyAccess)):
            return True
        if isinstance(expr, ParenthesizedExpr):
            return self._is_simple_non_agg_expr(expr.expr)
        if isinstance(expr, UnaryOp):
            return self._is_simple_non_agg_expr(expr.operand)
        # FunctionCall (non-agg) and BinaryOp are complex
        return False

    def _validate_no_complex_non_agg(self, expr: Any) -> None:
        """Recursively validate that within an aggregated expression, non-aggregate
        sub-expressions are simple (Variable, PropertyAccess, Literal) and not complex
        BinaryOps or non-aggregate FunctionCalls.

        Called only when expr contains an aggregate. Stops recursing into aggregate args.

        Raises:
            SyntaxError: AmbiguousAggregationExpression if a complex non-agg sub-expr found
        """
        from graphforge.ast.expression import (
            BinaryOp,
            FunctionCall,
            Literal,
            ParenthesizedExpr,
            PropertyAccess,
            UnaryOp,
            Variable,
        )

        if isinstance(expr, Literal):
            return
        if isinstance(expr, (Variable, PropertyAccess)):
            return
        if isinstance(expr, ParenthesizedExpr):
            self._validate_no_complex_non_agg(expr.expr)
            return
        if isinstance(expr, UnaryOp):
            self._validate_no_complex_non_agg(expr.operand)
            return
        if isinstance(expr, FunctionCall):
            if expr.name.upper() in self._AGGREGATE_FUNCTIONS:
                # This is the aggregate — don't recurse further
                return
            # Non-aggregate function call: recurse into any args that contain aggregates
            for arg in expr.args:
                if self._contains_aggregate(arg):
                    self._validate_no_complex_non_agg(arg)
            return
        if isinstance(expr, BinaryOp):
            has_agg_left = self._contains_aggregate(expr.left)
            has_agg_right = self._contains_aggregate(expr.right)
            if has_agg_left and has_agg_right:
                # Both sides contain aggregation — recurse into both
                self._validate_no_complex_non_agg(expr.left)
                self._validate_no_complex_non_agg(expr.right)
            elif has_agg_left:
                # Left has agg, right is pure non-agg: right must be simple
                # (BinaryOp or non-aggregate FunctionCall is considered complex)
                if not self._is_simple_non_agg_expr(expr.right):
                    raise SyntaxError(
                        "AmbiguousAggregationExpression: Expression contains both "
                        "an aggregation and a complex non-grouping expression"
                    )
                self._validate_no_complex_non_agg(expr.left)
            elif has_agg_right:
                # Right has agg, left is pure non-agg: left must be simple
                if not self._is_simple_non_agg_expr(expr.left):
                    raise SyntaxError(
                        "AmbiguousAggregationExpression: Expression contains both "
                        "an aggregation and a complex non-grouping expression"
                    )
                self._validate_no_complex_non_agg(expr.right)
            # else: neither side has agg — shouldn't happen if caller already checked

    def _collect_free_variables(self, expr: Any, locally_bound: frozenset[str]) -> list["Variable"]:
        """Walk an expression tree and collect only free Variable nodes.

        Respects locally-bound variables introduced by quantifiers, list/pattern
        comprehensions, and reduce expressions, so their loop variables are not
        reported as free references.
        """
        from graphforge.ast.expression import (
            ExtractExpression,
            FilterExpression,
            ListComprehension,
            PatternComprehension,
            PropertyAccess,
            QuantifierExpression,
            ReduceExpression,
            SubqueryExpression,
        )
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        if isinstance(expr, Variable):
            return [] if expr.name in locally_bound else [expr]
        # Subquery expressions (EXISTS/COUNT) have their own scope — do not recurse
        if isinstance(expr, SubqueryExpression):
            return []
        result: list[Variable] = []
        if isinstance(expr, PropertyAccess):
            if expr.base is not None:
                result.extend(self._collect_free_variables(expr.base, locally_bound))
            elif expr.variable is not None and expr.variable not in locally_bound:
                result.append(Variable(name=expr.variable))
        elif isinstance(expr, QuantifierExpression):
            new_bound = locally_bound | {expr.variable}
            result.extend(self._collect_free_variables(expr.list_expr, locally_bound))
            result.extend(self._collect_free_variables(expr.predicate, new_bound))
        elif isinstance(expr, ListComprehension):
            new_bound = locally_bound | {expr.variable}
            result.extend(self._collect_free_variables(expr.list_expr, locally_bound))
            if expr.filter_expr:
                result.extend(self._collect_free_variables(expr.filter_expr, new_bound))
            if expr.map_expr:
                result.extend(self._collect_free_variables(expr.map_expr, new_bound))
        elif isinstance(expr, PatternComprehension):
            # Collect variable names bound by the pattern (path var + node/rel anchors)
            pattern_bound: set[str] = set()
            raw_pattern = expr.pattern
            if isinstance(raw_pattern, dict):
                pv = raw_pattern.get("path_variable")
                if pv:
                    pattern_bound.add(pv)
                pattern_parts: list[Any] = list(
                    raw_pattern.get("parts", raw_pattern.get("elements", [])) or []
                )
            elif isinstance(raw_pattern, list):
                pattern_parts = raw_pattern
            else:
                pattern_parts = [raw_pattern]
            for part in pattern_parts:
                if isinstance(part, (NodePattern, RelationshipPattern)):
                    if part.variable:
                        pattern_bound.add(part.variable)
            new_bound = locally_bound | pattern_bound
            if expr.filter_expr:
                result.extend(self._collect_free_variables(expr.filter_expr, new_bound))
            result.extend(self._collect_free_variables(expr.map_expr, new_bound))
        elif isinstance(expr, FilterExpression):
            new_bound = locally_bound | {expr.variable}
            result.extend(self._collect_free_variables(expr.list_expr, locally_bound))
            result.extend(self._collect_free_variables(expr.predicate, new_bound))
        elif isinstance(expr, ExtractExpression):
            new_bound = locally_bound | {expr.variable}
            result.extend(self._collect_free_variables(expr.list_expr, locally_bound))
            result.extend(self._collect_free_variables(expr.map_expr, new_bound))
        elif isinstance(expr, ReduceExpression):
            new_bound = locally_bound | {expr.variable, expr.accumulator}
            result.extend(self._collect_free_variables(expr.initial_expr, locally_bound))
            result.extend(self._collect_free_variables(expr.list_expr, locally_bound))
            result.extend(self._collect_free_variables(expr.map_expr, new_bound))
        elif isinstance(expr, BinaryOp):
            result.extend(self._collect_free_variables(expr.left, locally_bound))
            result.extend(self._collect_free_variables(expr.right, locally_bound))
        elif isinstance(expr, FunctionCall):
            for arg in expr.args or []:
                result.extend(self._collect_free_variables(arg, locally_bound))
        elif isinstance(expr, (list, tuple)):
            for item in expr:
                result.extend(self._collect_free_variables(item, locally_bound))
        elif hasattr(expr, "__dict__"):
            for val in vars(expr).values():
                if val is not None and not isinstance(val, (str, int, float, bool, frozenset)):
                    result.extend(self._collect_free_variables(val, locally_bound))
        return result

    def _validate_expr_variables_in_scope(
        self, expr: Any, locally_bound: frozenset[str] = frozenset()
    ) -> None:
        """Check that all variables in expr are bound in the current scope.

        Raises SyntaxError(UndefinedVariable) for any unbound variable reference.
        """
        from graphforge.ast.expression import (
            CaseExpression,
            ExtractExpression,
            FilterExpression,
            ListComprehension,
            PatternComprehension,
            PatternPredicate,
            PropertyAccess,
            QuantifierExpression,
            ReduceExpression,
            SubqueryExpression,
        )

        def _check(e: Any, lb: frozenset[str] = locally_bound) -> None:
            if e is None or isinstance(e, (str, int, float, bool)):
                return
            # EXISTS/COUNT subqueries have their own scope — skip validation here
            if isinstance(e, SubqueryExpression):
                return
            if isinstance(e, Variable):
                # $param references are always valid — resolved at runtime
                if (
                    not e.name.startswith("$")
                    and e.name not in lb
                    and not self._type_context.has_variable(e.name)
                ):
                    raise SyntaxError(f"UndefinedVariable: Variable `{e.name}` is not defined")
            elif isinstance(e, PropertyAccess):
                if e.base is not None:
                    _check(e.base, lb)
                elif (
                    e.variable is not None
                    and e.variable not in lb
                    and not self._type_context.has_variable(e.variable)
                ):
                    raise SyntaxError(f"UndefinedVariable: Variable `{e.variable}` is not defined")
            elif isinstance(e, BinaryOp):
                _check(e.left, lb)
                _check(e.right, lb)
            elif isinstance(e, UnaryOp):
                _check(e.operand, lb)
            elif isinstance(e, FunctionCall):
                for arg in e.args or []:
                    _check(arg, lb)
            elif isinstance(e, ParenthesizedExpr):
                _check(e.expr, lb)
            elif isinstance(e, CaseExpression):
                if e.subject is not None:
                    _check(e.subject, lb)
                for cond, result in e.when_clauses:
                    _check(cond, lb)
                    _check(result, lb)
                if e.else_expr is not None:
                    _check(e.else_expr, lb)
            elif isinstance(e, ListComprehension):
                new_lb = lb | {e.variable}
                _check(e.list_expr, lb)
                if e.filter_expr is not None:
                    _check(e.filter_expr, new_lb)
                if e.map_expr is not None:
                    _check(e.map_expr, new_lb)
            elif isinstance(e, PatternComprehension):
                # Collect locally-bound vars from the pattern (path var + node/rel vars)
                pc_lb = set(lb)
                raw_pat = e.pattern
                if isinstance(raw_pat, dict):
                    pv = raw_pat.get("path_variable")
                    if pv:
                        pc_lb.add(pv)
                    for part in raw_pat.get("parts", []):
                        if hasattr(part, "variable") and part.variable:
                            pc_lb.add(part.variable)
                elif isinstance(raw_pat, list):
                    for part in raw_pat:
                        if hasattr(part, "variable") and part.variable:
                            pc_lb.add(part.variable)
                pc_lb_frozen = frozenset(pc_lb)
                if e.filter_expr is not None:
                    _check(e.filter_expr, pc_lb_frozen)
                _check(e.map_expr, pc_lb_frozen)
            elif isinstance(e, (QuantifierExpression, FilterExpression)):
                new_lb = lb | {e.variable}
                _check(e.list_expr, lb)
                _check(e.predicate, new_lb)
            elif isinstance(e, ExtractExpression):
                new_lb = lb | {e.variable}
                _check(e.list_expr, lb)
                _check(e.map_expr, new_lb)
            elif isinstance(e, ReduceExpression):
                new_lb = lb | {e.variable, e.accumulator}
                _check(e.initial_expr, lb)
                _check(e.list_expr, lb)
                _check(e.map_expr, new_lb)
            elif isinstance(e, PatternPredicate):
                # Pattern predicate: (n)-[:R]->()
                # Variables in the pattern are locally scoped (not checked against outer scope).
                # EXCEPT: any *named* variable that is NOT already bound in outer scope
                # and NOT the src node (first node) is an UndefinedVariable error.
                # The relationship variable and any node variable that introduces new bindings
                # are illegal — raise UndefinedVariable for them.
                from graphforge.ast.pattern import NodePattern as NodePatternCls
                from graphforge.ast.pattern import RelationshipPattern as RelationshipPatternCls

                for part in e.parts:
                    if isinstance(part, (NodePatternCls, RelationshipPatternCls)):
                        v = part.variable
                        if v and v not in lb and not self._type_context.has_variable(v):
                            raise SyntaxError(f"UndefinedVariable: Variable `{v}` is not defined")
            elif isinstance(e, (list, tuple)):
                for item in e:
                    _check(item, lb)
            elif hasattr(e, "__dict__"):
                for val in vars(e).values():
                    if val is not None and not isinstance(val, (str, int, float, bool, frozenset)):
                        _check(val, lb)

        _check(expr, locally_bound)

    def _validate_where_pattern_variables(self, predicate: Any) -> None:
        """
        Validate variable usage inside WHERE pattern predicates.

        Checks that variables referenced in pattern predicates (e.g., WHERE (a) or
        WHERE (a)-->(b)) are already bound in the enclosing scope and rejects using
        entity-typed variables (NODE, RELATIONSHIP, PATH) as bare boolean predicates.
        Recursively traverses common expression forms (parenthesized expressions, variables,
        property accesses, binary and unary ops, and PatternPredicate) to ensure any referenced
        variable is defined.

        Parameters:
            predicate (Any): AST expression node representing the WHERE predicate.

        Raises:
            SyntaxError: If a referenced variable is not defined in the current type context.
            SyntaxError: If an entity-typed variable (NODE, RELATIONSHIP, PATH) is used as a
                bare predicate (invalid boolean).
        """
        if isinstance(predicate, ParenthesizedExpr):
            inner = predicate.expr
            # (a) pattern predicate — inner is a Variable
            if isinstance(inner, Variable):
                if not self._type_context.has_variable(inner.name):
                    raise SyntaxError(f"UndefinedVariable: Variable `{inner.name}` is not defined")
                # Only reject entity-typed (non-boolean) variables as bare predicates
                var_type = self._type_context.get_type(inner.name)
                if var_type in (VariableType.NODE, VariableType.RELATIONSHIP, VariableType.PATH):
                    raise SyntaxError(
                        f"InvalidArgumentType: Type mismatch: expected Boolean, "
                        f"found {var_type.value} (WHERE ({inner.name}) is not a valid predicate)"
                    )
        elif isinstance(predicate, Variable):
            # Bare variable in WHERE expression (e.g. WHERE s.name = undefinedVar)
            if not predicate.name.startswith("$") and not self._type_context.has_variable(
                predicate.name
            ):
                raise SyntaxError(f"UndefinedVariable: Variable `{predicate.name}` is not defined")
        elif isinstance(predicate, PropertyAccess):
            # Property access on undefined variable (e.g. WHERE a.x = b.prop, b undefined)
            if (
                predicate.variable
                and not predicate.variable.startswith("$")
                and not self._type_context.has_variable(predicate.variable)
            ):
                raise SyntaxError(
                    f"UndefinedVariable: Variable `{predicate.variable}` is not defined"
                )
        elif isinstance(predicate, BinaryOp):
            self._validate_where_pattern_variables(predicate.left)
            self._validate_where_pattern_variables(predicate.right)
        elif isinstance(predicate, UnaryOp):
            self._validate_where_pattern_variables(predicate.operand)
        else:
            from graphforge.ast.expression import PatternPredicate as PatternPredicateCls
            from graphforge.ast.pattern import NodePattern as NodePatternCls
            from graphforge.ast.pattern import RelationshipPattern as RelationshipPatternCls

            if isinstance(predicate, PatternPredicateCls):
                # A relationship variable is locally scoped ONLY when it has an
                # inline predicate (e.g. [r:T WHERE r.prop > 0]).  Without an
                # inline predicate the variable must already be bound in the outer
                # scope, as required by the TCK UndefinedVariable scenarios.
                for part in predicate.parts:
                    if isinstance(part, NodePatternCls):
                        v = part.variable
                        if v and not self._type_context.has_variable(v):
                            raise SyntaxError(f"UndefinedVariable: Variable `{v}` is not defined")
                    elif isinstance(part, RelationshipPatternCls):
                        v = part.variable
                        if part.predicate:
                            # Rel variable is locally scoped when an inline predicate
                            # references it — allow it; validate the predicate itself.
                            local_rel_vars: set[str] = {v} if v else set()
                            self._validate_pattern_predicate_expr(part.predicate, local_rel_vars)
                        elif v and not self._type_context.has_variable(v):
                            raise SyntaxError(f"UndefinedVariable: Variable `{v}` is not defined")

    def _validate_pattern_predicate_expr(self, expr: Any, local_vars: set[str]) -> None:
        """Validate variables in an inline rel predicate, allowing local_vars.

        local_vars contains the declared rel variable (if any).  For anonymous
        relationships the inferred variable name (derived from the first
        PropertyAccess in the predicate) is also implicitly allowed, so we skip
        PropertyAccess nodes entirely — their base variable may be the inferred
        rel name which is unknown at planner time.
        """
        if expr is None:
            return
        if isinstance(expr, Variable):
            if (
                not expr.name.startswith("$")
                and expr.name not in local_vars
                and not self._type_context.has_variable(expr.name)
            ):
                raise SyntaxError(f"UndefinedVariable: Variable `{expr.name}` is not defined")
        elif isinstance(expr, PropertyAccess):
            # Skip: base variable may be the (inferred) anonymous rel var.
            pass
        elif isinstance(expr, BinaryOp):
            self._validate_pattern_predicate_expr(expr.left, local_vars)
            self._validate_pattern_predicate_expr(expr.right, local_vars)
        elif isinstance(expr, UnaryOp):
            self._validate_pattern_predicate_expr(expr.operand, local_vars)

    # All function names accepted by the evaluator (upper-cased).
    # Populated lazily on first use by _build_known_functions().
    _KNOWN_FUNCTION_NAMES: frozenset[str] | None = None

    @classmethod
    def _build_known_functions(cls) -> frozenset[str]:
        """
        Assemble the complete set of known function names used for planner validation.

        Combines function-name groups imported from the evaluator modules with a small set of
        additional aliases and returns them as an immutable set.

        Returns:
            frozenset[str]: A frozenset containing the recognized function names.
        """
        from graphforge.executor.evaluator import (
            AGGREGATE_FUNCTIONS,
            GRAPH_FUNCTIONS,
            LIST_FUNCTIONS,
            MATH_FUNCTIONS,
            PATH_FUNCTIONS,
            SPATIAL_FUNCTIONS,
            STRING_FUNCTIONS,
            TEMPORAL_FUNCTIONS,
            TYPE_FUNCTIONS,
        )

        return frozenset(
            AGGREGATE_FUNCTIONS
            | GRAPH_FUNCTIONS
            | LIST_FUNCTIONS
            | MATH_FUNCTIONS
            | PATH_FUNCTIONS
            | SPATIAL_FUNCTIONS
            | STRING_FUNCTIONS
            | TEMPORAL_FUNCTIONS
            | TYPE_FUNCTIONS
            | {
                # Additional aliases and functions not in the above sets
                "EXISTS",
                "COALESCE",
                "NULLIF",
                "ISEMPTY",
                "ELEMENTID",
                "TOUPPER",
                "TOLOWER",
                "TOBOOLEAN",
                "TOINTEGER",
                "TOFLOAT",
                "TOSTRING",
                "SHORTESTPATH",
                "ALLSHORTESTPATHS",
                "TRUNCATE",
                "SUBSTRING",
                "STARTSWITH",
                "ENDSWITH",
                "CONTAINS",
                "LTRIM",
                "RTRIM",
                "REPLACE",
                "SPLIT",
                "LEFT",
                "RIGHT",
            }
        )

    def register_extra_function(self, name: str) -> None:
        """
        Register a function name so the planner treats it as a known function and does not raise
        UnknownFunction errors.

        Parameters:
            name (str): The function name to register; comparison is case-insensitive (the name
                is stored upper-cased).
        """
        self._extra_function_names.add(name.upper())

    def _is_known_function(self, func_name_upper: str) -> bool:
        """
        Check whether a function name (already upper-cased) is recognized by the planner.

        This considers both the planner's built-in function names and any extra function names
        registered via register_extra_function.

        Parameters:
            func_name_upper (str): The function name in upper-case.

        Returns:
            True if the function name is recognized, False otherwise.
        """
        if QueryPlanner._KNOWN_FUNCTION_NAMES is None:
            QueryPlanner._KNOWN_FUNCTION_NAMES = self._build_known_functions()
        return (
            func_name_upper in QueryPlanner._KNOWN_FUNCTION_NAMES
            or func_name_upper in self._extra_function_names
        )

    def _validate_function_arg_types(self, expr: Any) -> None:
        """
        Validate and enforce entity-type constraints for function calls and property access
        within an expression.

        Raises SyntaxError when:
        - a property access targets a variable known to be a PATH.
        - a call to TYPE(x) is made where x is statically known to be a NODE.
        - a call to LENGTH(x) is made where x is statically known to be a NODE or RELATIONSHIP.
        - a call to SIZE(x) is made where x is statically known to be a PATH.
        - a function name (without a namespace) is not recognized by the planner.

        Checks are performed only when a variable's entity type is statically known via the
        planner's type context. The function recurses into sub-expressions to validate nested
        argument expressions.

        Parameters:
            expr: An expression AST node to validate.

        Raises:
            SyntaxError: On any of the invalid argument/function usages described above.
        """
        if isinstance(expr, PropertyAccess):
            check_var: str | None = None
            if expr.variable is not None:
                check_var = expr.variable
            elif isinstance(expr.base, Variable):
                check_var = expr.base.name
            if check_var is not None:
                var_type = self._type_context.get_type(check_var)
                if var_type == VariableType.PATH:
                    raise SyntaxError(
                        f"InvalidArgumentType: property access on path variable `{check_var}` "
                        f"is not allowed"
                    )
        if isinstance(expr, FunctionCall):
            func_name = expr.name.upper()
            if "." not in func_name and not self._is_known_function(func_name):
                raise SyntaxError(f"UnknownFunction: Unknown function `{expr.name}`")
            if func_name in ("TYPE", "LENGTH", "SIZE") and len(expr.args) == 1:
                arg = expr.args[0]
                if isinstance(arg, Variable):
                    var_type = self._type_context.get_type(arg.name)
                    if func_name == "TYPE" and var_type == VariableType.NODE:
                        raise SyntaxError(
                            f"InvalidArgumentType: type() requires a relationship, "
                            f"but `{arg.name}` is a node"
                        )
                    if func_name == "LENGTH" and var_type in (
                        VariableType.NODE,
                        VariableType.RELATIONSHIP,
                    ):
                        raise SyntaxError(
                            f"InvalidArgumentType: length() requires a string or path, "
                            f"but `{arg.name}` is a {var_type.value}"
                        )
                    if func_name == "SIZE" and var_type == VariableType.PATH:
                        raise SyntaxError(
                            "InvalidArgumentType: size() does not accept path arguments; "
                            "use length() instead"
                        )
        # Recurse into sub-expressions
        if isinstance(expr, BinaryOp):
            self._validate_function_arg_types(expr.left)
            self._validate_function_arg_types(expr.right)
        elif isinstance(expr, UnaryOp):
            self._validate_function_arg_types(expr.operand)
        elif isinstance(expr, FunctionCall):
            for arg in expr.args or []:
                self._validate_function_arg_types(arg)
        elif isinstance(expr, ParenthesizedExpr):
            self._validate_function_arg_types(expr.expr)
        elif isinstance(expr, CaseExpression):
            if expr.subject is not None:
                self._validate_function_arg_types(expr.subject)
            for cond, result in expr.when_clauses:
                self._validate_function_arg_types(cond)
                self._validate_function_arg_types(result)
            if expr.else_expr is not None:
                self._validate_function_arg_types(expr.else_expr)
        elif isinstance(expr, ListComprehension):
            self._validate_function_arg_types(expr.list_expr)
            if expr.filter_expr is not None:
                self._validate_function_arg_types(expr.filter_expr)
            if expr.map_expr is not None:
                self._validate_function_arg_types(expr.map_expr)
        elif isinstance(expr, Subscript):
            self._validate_function_arg_types(expr.base)
            self._validate_function_arg_types(expr.index)
        else:
            from graphforge.ast.expression import (
                ExtractExpression,
                FilterExpression,
                QuantifierExpression,
                ReduceExpression,
            )

            if isinstance(expr, QuantifierExpression):
                self._validate_function_arg_types(expr.list_expr)
                self._validate_function_arg_types(expr.predicate)
            elif isinstance(expr, FilterExpression):
                self._validate_function_arg_types(expr.list_expr)
                if expr.predicate is not None:
                    self._validate_function_arg_types(expr.predicate)
            elif isinstance(expr, ExtractExpression):
                self._validate_function_arg_types(expr.list_expr)
                self._validate_function_arg_types(expr.map_expr)
            elif isinstance(expr, ReduceExpression):
                self._validate_function_arg_types(expr.initial_expr)
                self._validate_function_arg_types(expr.list_expr)
                self._validate_function_arg_types(expr.map_expr)

    def _validate_exists_subqueries(self, ast: "CypherQuery") -> None:
        """Walk every expression in the query and reject write clauses inside EXISTS."""
        from graphforge.ast.clause import ReturnClause, WhereClause, WithClause

        for clause in ast.clauses:
            if isinstance(clause, WhereClause):
                self._validate_no_write_in_exists(clause.predicate)
            elif isinstance(clause, WithClause):
                for item in clause.items:
                    if hasattr(item, "expression"):
                        self._validate_no_write_in_exists(item.expression)
                if clause.where is not None:
                    self._validate_no_write_in_exists(clause.where.predicate)
            elif isinstance(clause, ReturnClause):
                for item in clause.items:
                    if hasattr(item, "expression"):
                        self._validate_no_write_in_exists(item.expression)

    def _validate_no_write_in_exists(self, expr: Any) -> None:
        """Raise SyntaxError if any EXISTS subquery body contains write clauses."""
        from graphforge.ast.clause import (
            CreateClause,
            DeleteClause,
            MergeClause,
            RemoveClause,
            SetClause,
        )
        from graphforge.ast.expression import (
            BinaryOp,
            CaseExpression,
            ListComprehension,
            SubqueryExpression,
            UnaryOp,
        )

        if isinstance(expr, SubqueryExpression):
            if expr.type == "EXISTS":
                if expr.query is not None:
                    write_types = (
                        SetClause,
                        RemoveClause,
                        CreateClause,
                        DeleteClause,
                        MergeClause,
                    )
                    from graphforge.ast.clause import WhereClause

                    for clause in expr.query.clauses:
                        if isinstance(clause, write_types):
                            raise SyntaxError(
                                "InvalidClauseComposition: an existential subquery cannot "
                                "contain write clauses (SET, REMOVE, CREATE, DELETE, MERGE)"
                            )
                        if isinstance(clause, WhereClause):
                            self._validate_no_write_in_exists(clause.predicate)
                if expr.where_predicate is not None:
                    self._validate_no_write_in_exists(expr.where_predicate)
        elif isinstance(expr, BinaryOp):
            self._validate_no_write_in_exists(expr.left)
            self._validate_no_write_in_exists(expr.right)
        elif isinstance(expr, UnaryOp):
            self._validate_no_write_in_exists(expr.operand)
        elif isinstance(expr, CaseExpression):
            if expr.subject is not None:
                self._validate_no_write_in_exists(expr.subject)
            for cond, res in expr.when_clauses:
                self._validate_no_write_in_exists(cond)
                self._validate_no_write_in_exists(res)
            if expr.else_expr is not None:
                self._validate_no_write_in_exists(expr.else_expr)
        elif isinstance(expr, ListComprehension):
            if expr.filter_expr:
                self._validate_no_write_in_exists(expr.filter_expr)

    def _validate_all_boolean_operands(self, ast: "CypherQuery") -> None:
        """Walk every expression in the query and validate boolean operator operands."""
        from graphforge.ast.clause import ReturnClause, WhereClause, WithClause

        for clause in ast.clauses:
            if isinstance(clause, ReturnClause):
                for item in clause.items:
                    if hasattr(item, "expression"):
                        self._validate_boolean_operands(item.expression)
            elif isinstance(clause, WhereClause):
                self._validate_boolean_operands(clause.predicate)
            elif isinstance(clause, WithClause):
                for item in clause.items:
                    if hasattr(item, "expression"):
                        self._validate_boolean_operands(item.expression)
                if clause.where:
                    self._validate_boolean_operands(clause.where)

    def _validate_boolean_operands(self, expr: Any) -> None:
        """Raise SyntaxError if AND/OR/XOR/NOT has a statically non-boolean literal operand.

        openCypher requires that the operands of boolean operators are boolean-typed.
        When a literal that is statically known to be non-boolean (integer, float, string,
        list, map) is used directly as an AND/OR/XOR/NOT operand, raise InvalidArgumentType.
        NULL literals are permitted (three-valued logic).
        """

        if isinstance(expr, BinaryOp):
            if expr.op in ("AND", "OR", "XOR"):
                for operand in (expr.left, expr.right):
                    self._check_bool_operand(operand)
                    self._validate_boolean_operands(operand)
            else:
                self._validate_boolean_operands(expr.left)
                self._validate_boolean_operands(expr.right)
        elif isinstance(expr, UnaryOp):
            if expr.op == "NOT":
                self._check_bool_operand(expr.operand)
            self._validate_boolean_operands(expr.operand)
        elif isinstance(expr, ParenthesizedExpr):
            self._validate_boolean_operands(expr.expr)
        elif isinstance(expr, CaseExpression):
            if expr.subject is not None:
                self._validate_boolean_operands(expr.subject)
            for cond, res in expr.when_clauses:
                self._validate_boolean_operands(cond)
                self._validate_boolean_operands(res)
            if expr.else_expr is not None:
                self._validate_boolean_operands(expr.else_expr)
        elif isinstance(expr, ListComprehension):
            self._validate_boolean_operands(expr.list_expr)
            if expr.filter_expr is not None:
                self._validate_boolean_operands(expr.filter_expr)
            if expr.map_expr is not None:
                self._validate_boolean_operands(expr.map_expr)
        elif isinstance(expr, SubqueryExpression):
            if expr.query is not None:
                self._validate_all_boolean_operands(expr.query)
            elif expr.where_predicate is not None:
                self._validate_boolean_operands(expr.where_predicate)

    def _check_bool_operand(self, expr: Any) -> None:
        """Raise SyntaxError if expr is a statically non-boolean, non-null literal."""
        from graphforge.ast.expression import Literal

        # Unwrap parens
        while isinstance(expr, ParenthesizedExpr):
            expr = expr.expr

        if isinstance(expr, Literal):
            val = expr.value
            # NULL is allowed; boolean is allowed; everything else is not
            if val is not None and not isinstance(val, bool):
                raise SyntaxError(
                    "InvalidArgumentType: AND/OR/XOR/NOT requires boolean operands, "
                    f"got literal {val!r}"
                )
        elif isinstance(expr, (list,)):
            # Inline list literal → non-boolean
            raise SyntaxError(
                "InvalidArgumentType: AND/OR/XOR/NOT requires boolean operands, got list"
            )
