"""openCypher parser for GraphForge.

This module provides the main parser interface that converts openCypher query
strings into AST representations using Lark and custom transformers.
"""

from functools import lru_cache
import math
from pathlib import Path
from typing import cast

from lark import Lark, Token, Transformer, v_args

from graphforge.ast.clause import (
    CreateClause,
    DeleteClause,
    LimitClause,
    MatchClause,
    MergeClause,
    OptionalMatchClause,
    OrderByClause,
    OrderByItem,
    RemoveClause,
    RemoveItem,
    ReturnClause,
    ReturnItem,
    SetClause,
    SkipClause,
    UnwindClause,
    WhereClause,
    WithClause,
)
from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    FunctionCall,
    LabelPredicate,
    Literal,
    ParenthesizedExpr,
    PropertyAccess,
    Subscript,
    UnaryOp,
    Variable,
    Wildcard,
)
from graphforge.ast.pattern import Direction, NodePattern, RelationshipPattern
from graphforge.ast.query import CypherQuery


def _decode_cypher_string(s: str) -> str:
    """Decode Cypher string escape sequences into their Python equivalents."""
    result = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            nxt = s[i + 1]
            if nxt == "\\":
                result.append("\\")
            elif nxt == "'":
                result.append("'")
            elif nxt == '"':
                result.append('"')
            elif nxt == "n":
                result.append("\n")
            elif nxt == "r":
                result.append("\r")
            elif nxt == "t":
                result.append("\t")
            elif nxt == "b":
                result.append("\b")
            elif nxt == "f":
                result.append("\f")
            elif nxt in ("u", "U"):
                # \uXXXX or \UXXXXXXXX — validate hex digits
                length = 4 if nxt == "u" else 8
                hex_part = s[i + 2 : i + 2 + length]
                valid_hex = set("0123456789abcdefABCDEF")
                if len(hex_part) < length or not all(c in valid_hex for c in hex_part):
                    raise SyntaxError(
                        f"InvalidUnicodeLiteral: Invalid unicode escape '\\{nxt}{hex_part}'"
                    )
                codepoint = int(hex_part, 16)
                if codepoint > 0x10FFFF:
                    raise SyntaxError(
                        f"InvalidUnicodeLiteral: Invalid unicode escape '\\{nxt}{hex_part}'"
                    )
                result.append(chr(codepoint))
                i += 2 + length
                continue
            else:
                result.append(s[i])
                result.append(nxt)
            i += 2
        else:
            result.append(s[i])
            i += 1
    return "".join(result)


@lru_cache(maxsize=1)
def _get_lark_parser():
    """Get cached Lark parser instance.

    The grammar is compiled once on first call and reused across
    all CypherParser instances, avoiding redundant compilation overhead.

    Returns:
        Lark: Compiled grammar parser instance
    """
    grammar_path = Path(__file__).parent / "cypher.lark"
    with grammar_path.open() as f:
        return Lark(f.read(), start="script", parser="lalr", propagate_positions=True)


class ASTTransformer(Transformer):
    """Transforms Lark parse tree into GraphForge AST."""

    def __init__(self, query_source: str = ""):
        super().__init__()
        self._query_source: str = query_source

    def _get_token_value(self, item):
        """Extract string value from Token or string, stripping backtick quoting."""
        if isinstance(item, Token):
            v = str(item.value)
        else:
            v = str(item)
        if v.startswith("`") and v.endswith("`"):
            return v[1:-1].replace("``", "`")
        return v

    # Script (multi-statement support)
    def script(self, items):
        """
        Transform the top-level script rule into a list of query AST nodes.

        Parameters:
            items: Iterable of parsed query AST nodes produced by the parser.

        Returns:
            list: A list containing the query AST nodes in the same order as parsed.
        """
        return list(items)

    def statement(self, items):
        """
        Pass through a statement parse rule and return the underlying union or query node.

        Parameters:
            items (list): Grammar-produced sequence for a statement where the first element is
                the actual union or query node.

        Returns:
            The underlying union or query AST node.
        """
        return items[0]

    def clause(self, items):
        """
        Pass through a parsed clause and return its single child node.

        Parameters:
            items (list): Sequence of transformed child nodes produced for the clause rule.

        Returns:
            The first child node from `items` representing the clause AST node.
        """
        return items[0]

    # Query
    def query(self, items):
        """
        Builds a CypherQuery node from a flat sequence of clause nodes.

        Parameters:
            items (iterable): Sequence of clause AST nodes in the order they appear in the query.

        Returns:
            CypherQuery: AST node whose `clauses` list contains the provided clause nodes in order.
        """
        return CypherQuery(clauses=list(items))

    def union_statement(self, items):
        """
        Builds a UnionQuery from a sequence of query branches interleaved with UNION tokens.

        Parses the provided items (a mix of query AST branches and union-type strings), validates
        that all union-type strings are consistent, and returns a UnionQuery combining the
        branches. If any union-type strings are present, the returned UnionQuery's `all` flag is
        set to `True` when they are `"UNION ALL"`, otherwise `False`.

        Parameters:
            items (list): Sequence containing query branch ASTs and union-type strings
                (`"UNION"` or `"UNION ALL"`).

        Returns:
            UnionQuery: AST node representing the UNION of the provided branches.

        Raises:
            ValueError: If both `"UNION"` and `"UNION ALL"` appear in the same statement.
        """
        from graphforge.ast.query import UnionQuery

        branches = []
        union_types = []
        for item in items:
            if isinstance(item, str):
                union_types.append(item)
            else:
                branches.append(item)

        if union_types:
            first_type = union_types[0]
            if not all(ut == first_type for ut in union_types):
                raise ValueError(
                    "Mixed UNION and UNION ALL in same query. "
                    "Use either UNION or UNION ALL consistently."
                )
            union_all = first_type == "UNION ALL"
        else:
            union_all = False

        return UnionQuery(branches=branches, all=union_all)

    def union_distinct(self, items):
        """Transform UNION (without ALL)."""
        return "UNION"

    def union_all(self, items):
        """
        Produce the sentinel value representing a 'UNION ALL' union type.

        Parameters:
            items (list): Parse-tree children (ignored).

        Returns:
            str: The sentinel string "UNION ALL" indicating the union-all modifier.
        """
        return "UNION ALL"

    # Clauses
    def match_clause(self, items):
        """
        Builds a MatchClause from parsed clause elements.

        Filters out string tokens produced by the parser and collects the remaining items as
        pattern objects used to construct the returned MatchClause.

        Parameters:
            items (list): Parsed elements of the MATCH clause; may include string tokens and
                pattern objects.

        Returns:
            MatchClause: AST node whose `patterns` list contains the non-string items extracted
            from `items`.
        """
        patterns = [item for item in items if not isinstance(item, str)]
        return MatchClause(patterns=patterns)

    def optional_match_clause(self, items):
        """Transform OPTIONAL MATCH clause."""
        patterns = [item for item in items if not isinstance(item, str)]
        return OptionalMatchClause(patterns=patterns)

    def create_clause(self, items):
        """Transform CREATE clause."""
        patterns = [item for item in items if not isinstance(item, str)]
        return CreateClause(patterns=patterns)

    def set_clause(self, items):
        """Transform SET clause."""
        return SetClause(items=list(items))

    def set_item(self, items):
        """Transform SET item (property = expression)."""
        property_access = items[0]
        expression = items[1]
        return (property_access, expression)

    def set_property(self, items):
        """Transform SET n.prop = expr."""
        from graphforge.ast.expression import PropertyAccess

        variable = items[0]
        prop_name = self._get_token_value(items[1])
        expr = items[2]
        prop_access = PropertyAccess(variable=variable.name, property=prop_name)
        return (prop_access, expr)

    def set_node_map(self, items):
        """Transform SET n = {map} — replace all properties."""
        return (items[0], "=", items[1])

    def set_node_map_augment(self, items):
        """Transform SET n += {map} — merge properties."""
        return (items[0], "+=", items[1])

    def set_labels(self, items):
        """Transform SET n:Label1:Label2 — add labels to node."""
        variable = items[0]
        labels = [self._get_token_value(label) for label in items[1:]]
        return (variable, ":+", labels)

    def set_property_paren(self, items):
        """Transform SET (n).prop = expr — parenthesized node property."""
        from graphforge.ast.expression import PropertyAccess

        variable = items[0]
        prop_name = self._get_token_value(items[1])
        expr = items[2]
        prop_access = PropertyAccess(variable=variable.name, property=prop_name)
        return (prop_access, expr)

    def remove_clause(self, items):
        """Transform REMOVE clause."""
        flat = []
        for item in items:
            if isinstance(item, list):
                flat.extend(item)
            else:
                flat.append(item)
        return RemoveClause(items=flat)

    def remove_property(self, items):
        """Transform REMOVE property item (e.g., n.age)."""
        property_access = items[0]
        return RemoveItem(
            item_type="property",
            variable=property_access.variable,
            name=property_access.property,
        )

    def remove_label(self, items):
        """Transform REMOVE label item (e.g., n:Person:Employee → two RemoveItems)."""
        variable = items[0]
        labels = items[1:]
        # Return a list for multi-label; remove_clause flattens via list(items)
        return [RemoveItem(item_type="label", variable=variable.name, name=lbl) for lbl in labels]

    def delete_expr(self, items):
        """Transform a single DELETE operand (variable, property access, or subscript)."""
        return items[0]

    def detach_delete(self, items):
        """Transform DETACH DELETE clause."""
        exprs = [item for item in items if item is not None]
        variables = [item.name if isinstance(item, Variable) else item for item in exprs]
        return DeleteClause(variables=variables, detach=True)

    def regular_delete(self, items):
        """Transform regular DELETE clause (without DETACH)."""
        exprs = [item for item in items if item is not None]
        variables = [item.name if isinstance(item, Variable) else item for item in exprs]
        return DeleteClause(variables=variables, detach=False)

    def merge_clause(self, items):
        """Transform MERGE clause with optional ON CREATE/ON MATCH actions."""
        patterns = []
        on_create = None
        on_match = None

        for item in items:
            if isinstance(item, str):
                continue
            if isinstance(item, tuple) and len(item) == 2:
                # merge_action returns (action_type, SetClause)
                action_type, set_clause = item
                if action_type == "on_create":
                    on_create = set_clause
                elif action_type == "on_match":
                    on_match = set_clause
            else:
                patterns.append(item)

        return MergeClause(patterns=patterns, on_create=on_create, on_match=on_match)

    def merge_action(self, items):
        """Transform merge action."""
        return items[0]

    def on_create_clause(self, items):
        """Transform ON CREATE SET clause."""
        return ("on_create", items[0])

    def on_match_clause(self, items):
        """Transform ON MATCH SET clause."""
        return ("on_match", items[0])

    def unwind_clause(self, items):
        """Transform UNWIND clause."""
        # items: [expression, variable]
        expression = items[0]
        variable = items[1]
        return UnwindClause(expression=expression, variable=variable.name)

    def call_subquery(self, items):
        """Transform CALL { query } subquery form."""
        from graphforge.ast.clause import CallClause

        return CallClause(
            query=items[0],
            procedure_name=None,
            arguments=None,
            yield_items=None,
            yield_star=False,
        )

    def call_procedure(self, items):
        """Transform CALL proc.name(args) [YIELD ...] form."""
        from graphforge.ast.clause import CallClause

        proc_name = items[0]  # already a string from proc_name transformer
        # remaining items: optional function_args result, optional yield result
        args: list = []
        yield_items = None
        yield_star = False
        for item in items[1:]:
            if isinstance(item, list):
                # count_star returns [] directly
                args = item
            elif isinstance(item, tuple) and len(item) == 2 and isinstance(item[1], bool):
                # regular_args/distinct_arg return (args_list, distinct_flag)
                args = list(item[0]) if item[0] else []
            elif isinstance(item, tuple) and item[0] == "__yield_star__":
                yield_star = True
            elif isinstance(item, tuple) and item[0] == "__yield_items__":
                yield_items = item[1]
        return CallClause(
            query=None,
            procedure_name=proc_name,
            arguments=args,
            yield_items=yield_items,
            yield_star=yield_star,
        )

    def call_procedure_implicit(self, items):
        """Transform CALL proc.name [YIELD ...] implicit-args form."""
        from graphforge.ast.clause import CallClause

        proc_name = items[0]
        yield_items = None
        yield_star = False
        for item in items[1:]:
            if isinstance(item, tuple) and item[0] == "__yield_star__":
                yield_star = True
            elif isinstance(item, tuple) and item[0] == "__yield_items__":
                yield_items = item[1]
        return CallClause(
            query=None,
            procedure_name=proc_name,
            arguments=None,  # None signals implicit args
            yield_items=yield_items,
            yield_star=yield_star,
        )

    def call_clause(self, items):
        """Transform CALL clause (fallback for legacy grammar match)."""
        from graphforge.ast.clause import CallClause

        return CallClause(
            query=items[0],
            procedure_name=None,
            arguments=None,
            yield_items=None,
            yield_star=False,
        )

    def proc_name(self, items):
        """
        Builds a qualified procedure name string from token parts.

        Parameters:
            items (list[Token | str]): Sequence of identifier or quoted-name segments that form
                the qualified procedure name.

        Returns:
            proc_name (str): The segments joined with dots (e.g. "db.proc.subproc").
        """
        return ".".join(self._get_token_value(t) for t in items)

    def yield_star(self, items):
        """
        Produce a sentinel tuple representing a YIELD * clause.

        Parameters:
            items (list): Parse children for this rule (ignored).

        Returns:
            tuple: The sentinel ("__yield_star__",) indicating a `YIELD *` occurrence.
        """
        return ("__yield_star__",)

    def yield_expression(self, items):
        """
        Create a ReturnItem representing a YIELD expression with an optional alias.

        Parameters:
            items (list): Parsed components where the first element is the expression
                and the optional second element is an alias token or identifier.

        Returns:
            ReturnItem: An object with `expression` set to the parsed expression and
            `alias` set to the alias string if provided, or `None` otherwise.
        """
        expression = items[0]
        alias = None
        if len(items) > 1:
            alias = self._get_token_value(items[1])
        return ReturnItem(expression=expression, alias=alias)

    def yield_clause(self, items):
        """
        Determine YIELD clause representation as either a yield-star sentinel or a yield-items
        sentinel with collected ReturnItem entries.

        Parameters:
            items (list): Parsed YIELD clause parts; may include a yield-star sentinel tuple
                ("__yield_star__") or ReturnItem objects.

        Returns:
            tuple: ("__yield_star__",) if a yield-star sentinel is present; otherwise
            ("__yield_items__", [ReturnItem, ...]) containing the collected ReturnItem instances.
        """
        for item in items:
            if isinstance(item, tuple) and item[0] == "__yield_star__":
                return ("__yield_star__",)
        return ("__yield_items__", [i for i in items if isinstance(i, ReturnItem)])

    def where_clause(self, items):
        """
        Builds a WhereClause AST node from the parsed predicate.

        Parameters:
            items (list): Parse-tree children for the WHERE clause; the first element is the
                predicate expression.

        Returns:
            WhereClause: AST node with its `predicate` set to the first item in `items`.
        """
        return WhereClause(predicate=items[0])

    def return_clause(self, items):
        """Transform RETURN clause."""
        return_items = []
        distinct = False

        for item in items:
            if isinstance(item, ReturnItem):
                return_items.append(item)
            elif isinstance(item, Token) and item.value.upper() == "DISTINCT":
                distinct = True

        return ReturnClause(items=return_items, distinct=distinct)

    def with_clause(self, items):
        """Transform WITH clause.

        Structure: return_item+ where_clause? order_by_clause? skip_clause? limit_clause?
        """
        # First collect all return items (before any optional clauses)
        return_items = []
        distinct = False
        where = None
        order_by = None
        skip = None
        limit = None

        for item in items:
            if isinstance(item, ReturnItem):
                return_items.append(item)
            elif isinstance(item, Token) and item.value.upper() == "DISTINCT":
                distinct = True
            elif isinstance(item, WhereClause):
                where = item
            elif isinstance(item, OrderByClause):
                order_by = item
            elif isinstance(item, SkipClause):
                skip = item
            elif isinstance(item, LimitClause):
                limit = item

        return WithClause(
            items=return_items,
            distinct=distinct,
            where=where,
            order_by=order_by,
            skip=skip,
            limit=limit,
        )

    def limit_clause(self, items):
        """Transform LIMIT clause."""
        return LimitClause(count=items[0])

    def skip_clause(self, items):
        """Transform SKIP clause."""
        return SkipClause(count=items[0])

    def order_by_clause(self, items):
        """Transform ORDER BY clause."""
        return OrderByClause(items=list(items))

    def order_by_item(self, items):
        """Transform ORDER BY item with optional direction."""
        expression = items[0]
        ascending = True  # Default is ASC
        if len(items) > 1:
            # Second item is the DIRECTION token
            direction = self._get_token_value(items[1]).upper()
            ascending = direction in ("ASC", "ASCENDING")
        return OrderByItem(expression=expression, ascending=ascending)

    # Patterns
    def pattern_with_binding(self, items):
        """
        Parse a pattern that binds a path variable to a pattern (e.g., `p = (a)-[:R]->(b)`).

        Parameters:
            items (list): Parse elements for the rule; contains a path Variable and a pattern
                parts list (Lark Token objects may be interleaved and are ignored).

        Returns:
            dict: {"path_variable": <str>, "parts": <list>} where `path_variable` is the
            variable name and `parts` is the list of pattern parts.
        """
        # items: [Variable, PAT_BIND_token, pattern_parts_list]
        # (PAT_BIND is a named terminal, not filtered by Lark's keep_all_tokens=False)
        from lark import Token as LarkToken

        non_token_items = [i for i in items if not isinstance(i, LarkToken)]
        path_var = non_token_items[0]
        pattern_parts = non_token_items[1]

        # Return dict with path variable and pattern parts
        return {"path_variable": path_var.name, "parts": pattern_parts}

    def pattern_without_binding(self, items):
        """Transform pattern without path binding."""
        # items: [pattern_parts_list]
        return {"path_variable": None, "parts": items[0]}

    def pattern_parts(self, items):
        """Transform pattern parts (node-rel-node-rel-node...)."""
        return items

    def node_pattern(self, items):
        """
        Parse a node pattern and produce a NodePattern describing its components.

        Scans the provided parse items for a variable, label groups, and a property map. Labels
        are returned as a list of label groups (each group is a list of label strings); if a flat
        list of label strings is encountered it is wrapped as a single group for compatibility.
        A property map may be supplied directly as a dict or as a Literal whose value is a dict;
        if present `has_explicit_properties` is set to True.

        Parameters:
            items (list): Parse-tree items that may include a Variable, a list of labels (either
                flat or nested groups), a dict of properties, or a Literal wrapping a dict.

        Returns:
            NodePattern: An AST node with attributes:
                - variable: the variable name or None
                - labels: list of label groups (disjunction of conjunctions)
                - properties: property dictionary (empty if none)
                - has_explicit_properties: True if a property map was explicitly provided
        """
        variable = None
        labels = []
        properties = {}
        has_explicit_properties = False

        for item in items:
            if isinstance(item, Variable):
                variable = item.name
            elif isinstance(item, list):
                # Check if it's the new nested list format (label groups)
                if item and isinstance(item[0], list):
                    # It's a list of label groups (disjunction of conjunctions)
                    labels = item
                elif all(isinstance(x, str) for x in item):
                    # It's a flat list of strings (old format, shouldn't happen anymore)
                    labels = [item]  # Wrap in a list to make it consistent
            elif isinstance(item, dict):
                properties = item
                has_explicit_properties = True
            elif isinstance(item, Literal) and isinstance(item.value, dict):
                # map_literal returns Literal(value=dict); extract the dict for patterns
                properties = item.value
                has_explicit_properties = True

        return NodePattern(
            variable=variable,
            labels=labels,
            properties=properties,
            has_explicit_properties=has_explicit_properties,
        )

    def relationship_pattern(self, items):
        """
        Extract the relationship pattern from transformer items.

        Parameters:
            items (list): Transformer-produced elements for a relationship pattern; the first
                element, if any, is expected to be the relationship pattern node.

        Returns:
            The relationship pattern object if present, otherwise None.
        """
        return items[0] if items else None

    def right_arrow_rel(self, items):
        """Transform outgoing relationship."""
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.OUT,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def left_arrow_rel(self, items):
        """Transform incoming relationship."""
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.IN,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def undirected_rel(self, items):
        """Transform undirected relationship."""
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.UNDIRECTED,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def pattern_where(self, items):
        """Transform pattern WHERE clause."""
        # items[0] is the expression
        return items[0] if items else None

    def _parse_rel_parts(self, items):
        """
        Extract relationship components from a sequence of transformer items produced for a
        relationship pattern.

        Parameters:
            items (list): List of parsed parts from a relationship production (may include a
                Variable, a list of type names, a dict or Literal(value=dict) for properties,
                a (min,max) tuple for variable-length hops, and/or an expression object for a
                pattern predicate).

        Returns:
            tuple: (variable, types, properties, min_hops, max_hops, predicate)
                - variable (str | None): Relationship variable name if present.
                - types (list[str]): List of relationship type names (empty if none).
                - properties (dict): Property map for the relationship (empty if none).
                - min_hops (int | None): Minimum hop count for a variable-length range.
                - max_hops (int | None): Maximum hop count for a variable-length range
                  (None if unbounded).
                - predicate (object | None): Predicate expression node associated with the
                  relationship, if any.
        """
        variable = None
        types = []
        properties = {}
        min_hops = None
        max_hops = None
        predicate = None

        for item in items:
            if isinstance(item, Variable):
                variable = item.name
            elif isinstance(item, list) and all(isinstance(x, str) for x in item):
                types = item
            elif isinstance(item, dict):
                properties = item
            elif isinstance(item, Literal) and isinstance(item.value, dict):
                # map_literal returns Literal(value=dict); extract dict for patterns
                properties = item.value
            elif isinstance(item, tuple) and len(item) == 2:
                # Variable-length range: (min_hops, max_hops)
                min_hops, max_hops = item
            elif not isinstance(item, (Token, str, type(None))):
                # Any non-structural value that isn't a Token or string is a
                # WHERE predicate expression (BinaryOp, UnaryOp, FunctionCall,
                # PropertyAccess, Variable, CaseExpression, etc.)
                predicate = item

        return variable, types, properties, min_hops, max_hops, predicate

    def var_length_unbounded(self, items):
        """Transform unbounded variable-length: *"""
        # * means 1 or more hops (unbounded)
        return (1, None)

    def var_length_min_max(self, items):
        """Transform variable-length with min and max: *1..3"""
        min_val = int(items[0])
        max_val = int(items[1])
        return (min_val, max_val)

    def var_length_min_only(self, items):
        """Transform variable-length with only min: *2.."""
        min_val = int(items[0])
        return (min_val, None)

    def var_length_max_only(self, items):
        """Transform variable-length with only max: *..3"""
        max_val = int(items[0])
        return (1, max_val)

    def var_length_exact(self, items):
        """Transform exact variable-length: *2 (exactly N hops)"""
        n = int(items[0])
        return (n, n)

    # Labels and types
    def labels(self, items):
        """Transform labels rule.

        Returns a list of label groups (disjunction of conjunctions).
        Example: :Person → [['Person']]
        Example: :Person:Employee → [['Person', 'Employee']]
        Example: :Person|Company → [['Person'], ['Company']]
        Example: :Person:Employee|Company:Startup → [['Person', 'Employee'], ['Company', 'Startup']]
        """
        # items[0] is the label_disjunction
        return items[0]

    def label_disjunction(self, items):
        """Transform label disjunction (list of label_conjunction groups)."""
        return list(items)

    def label_conjunction(self, items):
        """Transform a conjunction group of labels (list of IDENTIFIER tokens)."""
        return [self._get_token_value(item) for item in items]

    def label(self, items):
        """Transform single label (for REMOVE clause)."""
        return self._get_token_value(items[0])

    def rel_types(self, items):
        """
        Convert relationship type tokens into their string names.

        Parameters:
            items (list[Token | str]): Tokens or string values representing relationship types.

        Returns:
            list[str]: Relationship type names extracted from the tokens.
        """
        return [self._get_token_value(tok) for tok in items]

    # Expressions
    def return_all(self, items):
        """
        Create a ReturnItem representing RETURN * (a wildcard return).

        This produces a ReturnItem whose expression is a Wildcard() and whose alias is None.

        Returns:
            ReturnItem: A ReturnItem with `expression=Wildcard()` and `alias=None`.
        """
        # "*" means return all variables in scope
        # Use Wildcard expression to represent this
        return ReturnItem(expression=Wildcard(), alias=None)

    @v_args(meta=True)
    def return_expression(self, meta, items):
        """Transform return item with optional alias."""
        expression = items[0]
        alias = None
        if len(items) > 1:
            # Second item is the alias (IDENTIFIER token)
            alias = self._get_token_value(items[1])
        # Preserve original source text for unannotated return items (no alias).
        # openCypher requires the column name to match the source text exactly.
        source_text = None
        if alias is None and self._query_source and hasattr(meta, "start_pos"):
            source_text = self._query_source[meta.start_pos : meta.end_pos]
        return ReturnItem(expression=expression, alias=alias, source_text=source_text)

    def or_expr(self, items):
        """Transform OR expression."""
        if len(items) == 1:
            return items[0]
        # Build left-associative OR chain
        result = items[0]
        for item in items[1:]:
            result = BinaryOp(op="OR", left=result, right=item)
        return result

    def xor_expr(self, items):
        """Transform XOR expression."""
        if len(items) == 1:
            return items[0]
        # Build left-associative XOR chain
        result = items[0]
        for item in items[1:]:
            result = BinaryOp(op="XOR", left=result, right=item)
        return result

    def and_expr(self, items):
        """Transform AND expression."""
        if len(items) == 1:
            return items[0]
        # Build left-associative AND chain
        result = items[0]
        for item in items[1:]:
            result = BinaryOp(op="AND", left=result, right=item)
        return result

    def not_operation(self, items):
        """Transform NOT operation (when NOT keyword is present)."""
        # items[0] is the operand (result of transforming the inner not_expr)
        return UnaryOp(op="NOT", operand=items[0])

    def not_passthrough(self, items):
        """Transform not_expr when there's no NOT (just passes through comparison_expr)."""
        return items[0]

    def string_list_null_pred_expr(self, items):
        """Transform string/list/null predicate expression (higher precedence than comparison)."""
        if len(items) == 1:
            return items[0]
        # Process predicates left to right: [base, op1, ?right1, op2, ?right2, ...]
        result = items[0]
        i = 1
        while i < len(items):
            op = items[i]
            if op in ("IS NULL", "IS NOT NULL"):
                result = UnaryOp(op=op, operand=result)
                i += 1
            else:
                # Binary predicate: IN, STARTS WITH, ENDS WITH, CONTAINS
                result = BinaryOp(op=op, left=result, right=items[i + 1])
                i += 2
        return result

    def comparison_expr(self, items):
        """Transform comparison expression."""
        if len(items) == 1:
            return items[0]
        # Single comparison: [left, COMP_OP, right]
        if len(items) == 3:
            op = items[1] if isinstance(items[1], str) else self._get_token_value(items[1])
            return BinaryOp(op=op, left=items[0], right=items[2])
        # Chained comparisons: [a, op1, b, op2, c, ...] → chain as AND of pairwise
        comparisons = []
        for i in range(0, len(items) - 2, 2):
            op = (
                items[i + 1]
                if isinstance(items[i + 1], str)
                else self._get_token_value(items[i + 1])
            )
            comparisons.append(BinaryOp(op=op, left=items[i], right=items[i + 2]))
        result = comparisons[0]
        for comp in comparisons[1:]:
            result = BinaryOp(op="AND", left=result, right=comp)
        return result

    def starts_with(self, items):
        """Transform STARTS WITH operator."""
        return "STARTS WITH"

    def ends_with(self, items):
        """Transform ENDS WITH operator."""
        return "ENDS WITH"

    def contains(self, items):
        """Transform CONTAINS operator."""
        return "CONTAINS"

    def in_operator(self, items):
        """Transform IN operator."""
        return "IN"

    def is_null(self, items):
        """Transform IS NULL operator."""
        return "IS NULL"

    def is_not_null(self, items):
        """Transform IS NOT NULL operator."""
        return "IS NOT NULL"

    def add_expr(self, items):
        """Transform addition/subtraction expression."""
        if len(items) == 1:
            return items[0]
        # Build left-associative chain: mult_expr (("+"|"-") mult_expr)*
        result = items[0]
        i = 1
        while i < len(items):
            op = self._get_token_value(items[i])
            result = BinaryOp(op=op, left=result, right=items[i + 1])
            i += 2
        return result

    def mult_expr(self, items):
        """Transform multiplication/division/modulo expression."""
        if len(items) == 1:
            return items[0]
        # Build left-associative chain: power_expr (("*"|"/"|"%") power_expr)*
        result = items[0]
        i = 1
        while i < len(items):
            op = self._get_token_value(items[i])
            result = BinaryOp(op=op, left=result, right=items[i + 1])
            i += 2
        return result

    def power_expr(self, items):
        """Transform power/exponentiation expression.

        Left-associative per openCypher spec: 2^3^2 = (2^3)^2 = 64.
        """
        if len(items) == 1:
            return items[0]
        # Build left-associative chain: primary_expr ("^" unary_expr)*
        # Collect operands (every other item, starting at 0)
        operands = items[::2]
        # Build from left to right
        result = operands[0]
        for i in range(1, len(operands)):
            result = BinaryOp(op="^", left=result, right=operands[i])
        return result

    def unary_minus(self, items):
        """Transform unary minus expression (e.g., -5, -x)."""
        return UnaryOp(op="-", operand=items[0])

    def unary_passthrough(self, items):
        """Transform unary_expr when there's no unary minus (just passes through primary_expr)."""
        return items[0]

    def parenthesized_expr(self, items):
        """Wrap explicitly parenthesized expression to preserve parens in column names."""
        return ParenthesizedExpr(expr=items[0])

    def property_access(self, items):
        """Transform property access.

        Supports:
        - variable.property (e.g., n.name)
        - map_literal.property (e.g., {key: 'value'}.key)
        - list_literal.property (e.g., [1, 2, 3][0].prop)
        """
        base_expr = items[0]
        prop_name = self._get_token_value(items[1])

        # If base is a Variable, use variable field for backward compatibility
        if isinstance(base_expr, Variable):
            return PropertyAccess(variable=base_expr.name, property=prop_name)

        # Otherwise, use base field for expression-based property access
        return PropertyAccess(base=base_expr, property=prop_name)

    def subscript(self, items):
        """Transform subscript/slice expression.

        Supports:
        - list[index] - single index access
        - list[start..end] - slice with start and end
        - list[..end] - slice from beginning to end
        - list[start..] - slice from start to end of list
        """
        base_expr = items[0]
        index_info = items[1]  # This is the result from subscript_index

        # index_info is a Subscript object with index OR start/end set
        # Update it with the correct base
        return Subscript(
            base=base_expr,
            index=index_info.index,
            start=index_info.start,
            end=index_info.end,
        )

    def index_access(self, items):
        """Transform single index access: list[0]"""
        # items[0] is the index expression
        return Subscript(base=None, index=items[0], start=None, end=None)

    def slice_range(self, items):
        """Transform slice with start and end: list[1..3]"""
        # items[0] is start, items[1] is end
        return Subscript(base=None, index=None, start=items[0], end=items[1])

    def slice_from(self, items):
        """Transform slice from start to end: list[2..]"""
        # items[0] is start, end is None (implicit)
        return Subscript(base=None, index=None, start=items[0], end=None)

    def slice_to(self, items):
        """Transform slice from beginning to end: list[..3]"""
        # start is None (implicit), items[0] is end
        return Subscript(base=None, index=None, start=None, end=items[0])

    def slice_all(self, items):
        """Transform full slice: list[..]"""
        # Both start and end are None (implicit)
        return Subscript(base=None, index=None, start=None, end=None)

    def function_call(self, items):
        """Transform function call."""
        # First item is function name token
        func_name = self._get_token_value(items[0]).upper()
        # Second item (if present) is the args
        args = []
        distinct = False
        if len(items) > 1:
            args_item = items[1]
            if isinstance(args_item, tuple):
                # (args_list, distinct_flag)
                args, distinct = args_item
            else:
                args = args_item
        return FunctionCall(name=func_name, args=args, distinct=distinct)

    def namespaced_function_call(self, items):
        """Transform namespaced function call (e.g. date.truncate, duration.between)."""
        namespace = self._get_token_value(items[0]).upper()
        method = self._get_token_value(items[1]).upper()
        func_name = f"{namespace}.{method}"
        args = []
        if len(items) > 2:
            args_item = items[2]
            if isinstance(args_item, tuple):
                args, _ = args_item
            else:
                args = args_item if args_item else []
        return FunctionCall(name=func_name, args=args, distinct=False)

    def count_star(self, items):
        """Transform COUNT(*) - no arguments."""
        return []  # Empty args list

    def distinct_arg(self, items):
        """Transform DISTINCT argument."""
        return ([items[0]], True)  # (args_list, distinct=True)

    def regular_args(self, items):
        """Transform regular function arguments."""
        return (list(items), False)  # (args_list, distinct=False)

    def case_expr_searched(self, items):
        """Transform searched CASE expression: CASE WHEN cond THEN res... END."""
        when_clauses = []
        else_expr = None
        for item in items:
            if isinstance(item, tuple):
                when_clauses.append(item)
            else:
                else_expr = item
        return CaseExpression(when_clauses=when_clauses, else_expr=else_expr)

    def case_expr_simple(self, items):
        """Transform simple CASE expression: CASE subject WHEN val THEN res... END."""
        subject = items[0]
        when_clauses = []
        else_expr = None
        for item in items[1:]:
            if isinstance(item, tuple):
                when_clauses.append(item)
            else:
                else_expr = item
        return CaseExpression(when_clauses=when_clauses, else_expr=else_expr, subject=subject)

    def case_expr(self, items):
        """Transform CASE expression (legacy fallback).

        Structure: when_clause+ [else_expr]?
        """
        when_clauses = []
        else_expr = None

        for item in items:
            if isinstance(item, tuple):
                # when_clause returns (condition, result)
                when_clauses.append(item)
            else:
                # ELSE expression
                else_expr = item

        return CaseExpression(when_clauses=when_clauses, else_expr=else_expr)

    def when_clause(self, items):
        """
        Transform a WHEN ... THEN ... clause into a (condition, result) pair.

        Parameters:
            items (list): Two elements where the first is the condition expression and the
                second is the result expression.

        Returns:
            tuple: A pair (condition_expr, result_expr).
        """
        condition = items[0]
        result = items[1]
        return (condition, result)

    def pp_undirected(self, items):
        """
        Create a RelationshipPattern for an undirected bracketed relationship.

        Parameters:
            items: Parse-tree fragments representing the relationship's components (variable,
                types, properties, hop range and predicate).

        Returns:
            RelationshipPattern: An undirected relationship pattern with the parsed variable,
            types, properties, min_hops, max_hops, and predicate.
        """
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.UNDIRECTED,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def pp_right(self, items):
        """
        Builds a right-directed RelationshipPattern AST node from parsed relationship components.

        Parameters:
            items (list): Parse-tree components for a bracketed right-directed relationship
                (Lark items passed to the transformer).

        Returns:
            RelationshipPattern: A relationship pattern with direction set to OUT and fields
            populated from the parsed components (variable, types, properties, min_hops,
            max_hops, predicate).
        """
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.OUT,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def pp_left(self, items):
        """
        Create a RelationshipPattern representing a left-directed relationship (`<-[...] -`).

        Parameters:
            items (list): Parse-tree elements for the bracketed relationship (variable, types,
                properties, hop range, predicate).

        Returns:
            RelationshipPattern: A relationship pattern with direction set to `Direction.IN`
            and fields populated from the parsed parts.
        """
        variable, types, properties, min_hops, max_hops, predicate = self._parse_rel_parts(items)
        return RelationshipPattern(
            variable=variable,
            types=types,
            direction=Direction.IN,
            properties=properties,
            min_hops=min_hops,
            max_hops=max_hops,
            predicate=predicate,
        )

    def pp_left_bare(self, items):
        """
        Constructs a bare left-directed RelationshipPattern with no variable or types.

        Parameters:
            items (list): Ignored transformer items; present for grammar callback compatibility.

        Returns:
            RelationshipPattern: A relationship pattern with variable=None, types=[], and
            direction=Direction.IN.
        """
        return RelationshipPattern(variable=None, types=[], direction=Direction.IN)

    def pattern_predicate(self, items):
        """
        Constructs a PatternPredicate AST node from a parenthesized node expression followed
        by alternating relationship and node pattern parts.

        Parameters:
            items (list): Parse items where the first element is the expression inside the
                parentheses (typically a Variable for a bare node or a LabelPredicate for a
                labeled node) and the remaining elements alternate RelationshipPattern,
                NodePattern.

        Returns:
            PatternPredicate: An AST node whose `parts` list begins with a NodePattern
            reconstructed from the first expression (a Variable becomes a NodePattern with that
            variable name; a LabelPredicate becomes a NodePattern with the listed labels; any
            other expression becomes a synthetic NodePattern with no variable), followed by the
            provided relationship and node pattern parts.
        """
        from graphforge.ast.expression import PatternPredicate

        # First item is the expression from inside the parentheses
        expr = items[0]

        # Reconstruct a NodePattern for the first node
        if isinstance(expr, Variable):
            first_node = NodePattern(variable=expr.name, labels=[], properties={})
        elif isinstance(expr, LabelPredicate):
            # label_predicate: IDENTIFIER (":" IDENTIFIER)+ — e.g. n:Person:Admin
            # All labels form one conjunction group (node must have ALL of them)
            first_node = NodePattern(
                variable=expr.variable,
                labels=[list(expr.labels)],
                properties={},
            )
        else:
            # Fallback: bare expression — wrap as a synthetic NodePattern with no variable
            first_node = NodePattern(variable=None, labels=[], properties={})

        parts = [first_node, *list(items[1:])]
        return PatternPredicate(parts=parts)

    def exists_full(self, items):
        """
        Construct a SubqueryExpression representing a full EXISTS subquery (EXISTS { ... }).

        Parameters:
            items (list): Transformer items for the EXISTS block; the first non-Token item is
                the subquery AST used as the `query`.

        Returns:
            SubqueryExpression: An expression with `type="EXISTS"`, `query` set to the subquery
            AST, and `pattern_parts` and `where_predicate` set to None.
        """
        from graphforge.ast.expression import SubqueryExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        return SubqueryExpression(
            type="EXISTS", query=non_tokens[0], pattern_parts=None, where_predicate=None
        )

    def exists_simple(self, items):
        """
        Builds a SubqueryExpression representing a simple EXISTS pattern subquery.

        Parameters:
            items (list): Parser-produced items for the EXISTS clause (may include Lark Token
                objects, a pattern_parts structure, and optionally a WhereClause).

        Returns:
            SubqueryExpression: An expression with type "EXISTS", `query` set to None,
            `pattern_parts` set to the parsed pattern, and `where_predicate` set to the
            WhereClause predicate if present, otherwise None.
        """
        from graphforge.ast.clause import WhereClause
        from graphforge.ast.expression import SubqueryExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        pattern_parts = non_tokens[0]
        where_predicate = None
        if len(non_tokens) > 1 and isinstance(non_tokens[1], WhereClause):
            where_predicate = non_tokens[1].predicate
        return SubqueryExpression(
            type="EXISTS",
            query=None,
            pattern_parts=pattern_parts,
            where_predicate=where_predicate,
        )

    def exists_function(self, items):
        """
        Create a FunctionCall node for the legacy exists(expr) form.

        Returns:
            FunctionCall: a call named "EXISTS" with the parsed expression as its single
            argument and `distinct=False`.
        """
        non_tokens = [i for i in items if not isinstance(i, Token)]
        return FunctionCall(name="EXISTS", args=[non_tokens[0]], distinct=False)

    def count_subquery(self, items):
        """
        Create a SubqueryExpression representing a COUNT subquery.

        Parameters:
            items (list): Parse-tree items produced by Lark; the first non-Token item is used
                as the inner query AST.

        Returns:
            SubqueryExpression: An expression with type "COUNT", `query` set to the inner query
            AST, and `pattern_parts` and `where_predicate` set to None.
        """
        from graphforge.ast.expression import SubqueryExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        return SubqueryExpression(
            type="COUNT", query=non_tokens[0], pattern_parts=None, where_predicate=None
        )

    def count_call(self, items):
        """
        Builds a FunctionCall AST node for a count(...) aggregate call.

        Parses the transformer `items` to extract argument expressions and an optional distinct
        marker:
        - If a tuple of the form (args_list, True/False) is present, `distinct` is set
          accordingly.
        - If a plain list of arguments is present, those become the function arguments.

        Parameters:
            items (list): Parse-result fragments produced by the grammar (may include Lark
                Tokens, a list of argument expressions, or a tuple `(args_list, distinct_flag)`).

        Returns:
            FunctionCall: A FunctionCall node with `name="count"`, `args` set to the extracted
            argument list, and `distinct` set to `True` when DISTINCT was specified, `False`
            otherwise.
        """
        non_tokens = [i for i in items if not isinstance(i, Token)]
        args: list = []
        distinct = False
        if non_tokens:
            arg_item = non_tokens[0]
            if isinstance(arg_item, list):
                args = arg_item
            elif (
                isinstance(arg_item, tuple) and len(arg_item) == 2 and isinstance(arg_item[1], bool)
            ):
                args, distinct = arg_item[0], arg_item[1]
        return FunctionCall(name="count", args=args, distinct=distinct)

    def all_quantifier(self, items):
        """
        Create a QuantifierExpression for the ALL quantifier.

        Expects items to contain, in order: a variable (a Variable node or an object with a
        `name` attribute; otherwise its string form is used), the list expression, and the
        predicate expression.

        Returns:
            QuantifierExpression: An AST node representing
            `ALL(variable IN list_expr WHERE predicate)`.
        """
        from graphforge.ast.expression import QuantifierExpression

        # items[0] = variable, items[1] = list_expr, items[2] = predicate
        variable = items[0].name if hasattr(items[0], "name") else str(items[0])
        return QuantifierExpression(
            quantifier="ALL", variable=variable, list_expr=items[1], predicate=items[2]
        )

    def any_quantifier(self, items):
        """Transform ANY quantifier expression.

        Syntax: ANY(x IN list WHERE predicate)
        """
        from graphforge.ast.expression import QuantifierExpression

        variable = items[0].name if hasattr(items[0], "name") else str(items[0])
        return QuantifierExpression(
            quantifier="ANY", variable=variable, list_expr=items[1], predicate=items[2]
        )

    def none_quantifier(self, items):
        """Transform NONE quantifier expression.

        Syntax: NONE(x IN list WHERE predicate)
        """
        from graphforge.ast.expression import QuantifierExpression

        variable = items[0].name if hasattr(items[0], "name") else str(items[0])
        return QuantifierExpression(
            quantifier="NONE", variable=variable, list_expr=items[1], predicate=items[2]
        )

    def single_quantifier(self, items):
        """Transform SINGLE quantifier expression.

        Syntax: SINGLE(x IN list WHERE predicate)
        """
        from graphforge.ast.expression import QuantifierExpression

        variable = items[0].name if hasattr(items[0], "name") else str(items[0])
        return QuantifierExpression(
            quantifier="SINGLE", variable=variable, list_expr=items[1], predicate=items[2]
        )

    def filter_expr(self, items):
        """
        Constructs a FilterExpression AST node from parsed FILTER(...) parts.

        Parameters:
            items (list): Parser-produced items for a FILTER expression; may include Lark Token
                objects and three meaningful values (the loop variable, the list expression, and
                the predicate). Token instances are ignored.

        Returns:
            FilterExpression: An AST node with `variable` set to the loop variable name
            (string), `list_expr` set to the list expression, and `predicate` set to the
            predicate expression.
        """
        from graphforge.ast.expression import FilterExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        # non_tokens: [variable, list_expr, predicate]
        variable = non_tokens[0].name if hasattr(non_tokens[0], "name") else str(non_tokens[0])
        return FilterExpression(variable=variable, list_expr=non_tokens[1], predicate=non_tokens[2])

    def extract_expr(self, items):
        """
        Builds an ExtractExpression AST node from transformer items.

        Transforms a parsed EXTRACT(...) production into an ExtractExpression. Filters out Lark
        Token instances and expects the remaining items in the order: variable, list expression,
        map expression. The variable is converted to its `.name` attribute if present, otherwise
        to its string representation.

        Parameters:
            items (list): Sequence of transformer items (may include Lark Tokens). After
                filtering tokens, the list must contain [variable, list_expr, map_expr].

        Returns:
            ExtractExpression: An AST node with fields `variable` (str), `list_expr`, and
            `map_expr`.
        """
        from graphforge.ast.expression import ExtractExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        # non_tokens: [variable, list_expr, map_expr]
        variable = non_tokens[0].name if hasattr(non_tokens[0], "name") else str(non_tokens[0])
        return ExtractExpression(variable=variable, list_expr=non_tokens[1], map_expr=non_tokens[2])

    def reduce_expr(self, items):
        """
        Construct a ReduceExpression AST node from a parsed REDUCE expression.

        Parameters:
            items (list): Sequence of Lark tokens and AST fragments representing
                the REDUCE parts (accumulator assignment, initial expression,
                iterator variable, list expression, and map expression).

        Returns:
            ReduceExpression: AST node with fields `accumulator`, `initial_expr`,
            `variable`, `list_expr`, and `map_expr` populated from `items`.
        """
        from graphforge.ast.expression import ReduceExpression

        non_tokens = [i for i in items if not isinstance(i, Token)]
        # non_tokens: [accumulator, initial_expr, variable, list_expr, map_expr]
        accumulator = non_tokens[0].name if hasattr(non_tokens[0], "name") else str(non_tokens[0])
        variable = non_tokens[2].name if hasattr(non_tokens[2], "name") else str(non_tokens[2])
        return ReduceExpression(
            accumulator=accumulator,
            initial_expr=non_tokens[1],
            variable=variable,
            list_expr=non_tokens[3],
            map_expr=non_tokens[4],
        )

    def alias_name(self, items):
        """
        Extract the alias name string from an identifier or keyword token.

        Parameters:
            items (list): Parse items where the first element is an IDENTIFIER or keyword Token.

        Returns:
            str: The extracted token value with surrounding quotes/backticks removed and
            internal escapes unescaped.
        """
        return self._get_token_value(items[0])

    def variable(self, items):
        """
        Create a Variable AST node from a parsed identifier token.

        Parameters:
            items (list): Parse-tree children where the first element is an identifier token or
                raw string representing the variable name.

        Returns:
            Variable: AST Variable node with its `name` set to the identifier's string value.
        """
        return Variable(name=self._get_token_value(items[0]))

    def param_ref(self, items):
        """Transform $paramName parameter reference into a Variable named $paramName."""
        return Variable(name=f"${self._get_token_value(items[0])}")

    def label_predicate(self, items):
        """Transform label predicate expression: n:Person or n:Person:Employee."""
        variable = self._get_token_value(items[0])
        labels = [self._get_token_value(item) for item in items[1:]]
        return LabelPredicate(variable=variable, labels=labels)

    def _parse_int_token(self, s: str) -> int:
        """Decode a decimal, hexadecimal (0x/0X), or octal (0o/0O) integer token.

        Returns the raw Python int value without overflow checking.
        INT64 range validation is performed by the evaluator so that
        negation (-0x8000000000000000 = INT64_MIN) is handled correctly.
        """
        if s.startswith(("0x", "0X")):
            return int(s, 16)
        if s.startswith(("0o", "0O")):
            return int(s, 8)
        return int(s)

    # Literals
    def int_literal(self, items):
        """Transform integer literal."""
        return Literal(value=self._parse_int_token(str(items[0])))

    def float_literal(self, items):
        """Transform float literal."""
        val = float(items[0])
        if math.isinf(val):
            raise ValueError(f"Floating point overflow: {items[0]}")
        return Literal(value=val)

    def string_literal(self, items):
        """Transform string literal."""
        value = self._get_token_value(items[0])
        if (value.startswith('"') and value.endswith('"')) or (
            value.startswith("'") and value.endswith("'")
        ):
            value = value[1:-1]
        return Literal(value=_decode_cypher_string(value))

    def true_literal(self, items):
        """Transform true literal."""
        # items[0] is now a TRUE terminal token
        return Literal(value=True)

    def false_literal(self, items):
        """Transform false literal."""
        # items[0] is now a FALSE terminal token
        return Literal(value=False)

    def null_literal(self, items):
        """Transform null literal."""
        # items[0] is now a NULL terminal token
        return Literal(value=None)

    def list_literal(self, items):
        """Transform list literal.

        items can be empty (for []) or contain expressions.
        Returns a Literal containing a Python list, or a ListComprehension/PatternComprehension
        if that's what was parsed.
        """
        from graphforge.ast.expression import ListComprehension, PatternComprehension

        # Check if this is actually a comprehension (alternative rule)
        if len(items) == 1 and isinstance(items[0], (ListComprehension, PatternComprehension)):
            return items[0]

        # Filter out None values from optional expressions
        # Empty list [] comes through as [None] from Lark
        filtered_items = [item for item in items if item is not None]

        # items contains the expressions in the list
        # We return a Literal with a list of expressions
        # The executor will evaluate these expressions later
        return Literal(value=filtered_items)

    def comp_where_clause(self, items):
        """Transform WHERE clause in list comprehension.

        Returns the filter expression.
        """
        return ("WHERE", items[0])

    def comp_map_clause(self, items):
        """Transform map clause (|) in list comprehension.

        Returns the map expression.
        """
        return ("MAP", items[0])

    def list_comprehension(self, items):
        """
        Constructs a ListComprehension AST node from parsed list-comprehension components.

        Parameters:
            items (list): Parsed components in order: element variable (a Variable node or
                identifier token), the list expression, and zero or more tagged tuples for
                optional clauses — ("WHERE", predicate) and ("MAP", expression).

        Returns:
            ListComprehension: AST node with attributes `variable` (str), `list_expr`,
            `filter_expr` (predicate or None), and `map_expr` (expression or None).
        """
        from graphforge.ast.expression import ListComprehension

        # items[0] is a Variable object, extract the name
        variable = (
            items[0].name if isinstance(items[0], Variable) else self._get_token_value(items[0])
        )
        list_expr = items[1]
        filter_expr = None
        map_expr = None

        # Process optional WHERE and MAP clauses (tagged tuples from sub-rules)
        for item in items[2:]:
            if isinstance(item, tuple):
                tag, expr = item
                if tag == "WHERE":
                    filter_expr = expr
                elif tag == "MAP":
                    map_expr = expr

        return ListComprehension(
            variable=variable, list_expr=list_expr, filter_expr=filter_expr, map_expr=map_expr
        )

    def pattern_comprehension(self, items):
        """
        Create a PatternComprehension AST node for an unbound (no path variable) pattern
        comprehension.

        Parameters:
            items (list): Parsed components in order: a list of pattern parts (from the
                `pattern_parts` rule), zero or more optional tagged tuples (e.g.,
                `("WHERE", predicate)`), and the final map expression.

        Returns:
            PatternComprehension: AST node with `pattern` set to a dict containing
            `path_variable=None` and the parsed `parts`, `filter_expr` set to the WHERE
            predicate if present (otherwise `None`), and `map_expr` set to the comprehension's
            result expression.
        """
        from graphforge.ast.expression import PatternComprehension

        pattern_parts = items[0]  # list from pattern_parts rule
        filter_expr = None
        map_expr = items[-1]

        for item in items[1:-1]:
            if isinstance(item, tuple):
                tag, expr = item
                if tag == "WHERE":
                    filter_expr = expr

        pattern = {"path_variable": None, "parts": pattern_parts}
        return PatternComprehension(pattern=pattern, filter_expr=filter_expr, map_expr=map_expr)

    def pattern_comprehension_binding(self, items):
        """
        Parse a path-bound pattern comprehension and produce a PatternComprehension AST node.

        Parses a comprehension of the form `[p = (pattern parts) WHERE ... | expr]`. The `items`
        sequence is expected to contain a leading PAT_COMP_OPEN token (captures the bracket and
        bound identifier, e.g. "[p ="), then a pattern parts list, optional tagged clauses
        (such as `("WHERE", <expr>)`), and the final map expression. The bound identifier may
        be backtick-quoted and will be unquoted in the returned pattern.

        Parameters:
            items (list): Parse items from Lark where:
                - items[0] is the PAT_COMP_OPEN token containing the bound identifier,
                - subsequent elements include the pattern parts, zero or more tagged clause tuples,
                  and the final map expression. Lark Token instances are ignored when locating
                  semantic elements.

        Returns:
            PatternComprehension: AST node with `pattern` set to
            {"path_variable": <name>|None, "parts": <pattern_parts>}, `filter_expr` set to the
            WHERE expression if present or `None`, and `map_expr` set to the comprehension's
            result expression.
        """
        import re

        from lark import Token as LarkToken

        from graphforge.ast.expression import PatternComprehension

        # First item is the PAT_COMP_OPEN token: "[  varname  ="
        open_token = items[0]
        assert isinstance(open_token, LarkToken), f"Expected PAT_COMP_OPEN token, got {open_token}"
        # Extract identifier from token text e.g. "[p =" -> "p"
        m = re.match(r"\[\s*(`[^`]+`|[a-zA-Z_][a-zA-Z0-9_]*)\s*=", str(open_token))
        path_var_name = m.group(1).strip("`") if m else None

        # Remaining non-token items
        non_token = [i for i in items[1:] if not isinstance(i, LarkToken)]
        pattern_parts = non_token[0]
        filter_expr = None
        map_expr = non_token[-1]

        for item in non_token[1:-1]:
            if isinstance(item, tuple):
                tag, expr = item
                if tag == "WHERE":
                    filter_expr = expr

        pattern = {"path_variable": path_var_name, "parts": pattern_parts}
        return PatternComprehension(pattern=pattern, filter_expr=filter_expr, map_expr=map_expr)

    def map_literal(self, items):
        """
        Convert a Cypher map literal into a Literal containing a Python dict.

        Parameters:
            items (list): Sequence of (key, value_expression) tuples produced by `map_pair`;
                an optional None element appears when the map was empty.

        Returns:
            Literal: A Literal whose `value` is a dict built from the provided key/value pairs.
        """
        # items contains (key, value_expr) tuples from map_pair; Lark passes None for
        # the optional group when the map is empty (e.g. {}).
        pairs = [item for item in items if item is not None]
        return Literal(value=dict(pairs))

    def map_pair(self, items):
        """
        Parse and convert a map key-value pair from the parse tree.

        Parameters:
            items (list): Two-element list where the first element is a key token
                (IDENTIFIER or quoted STRING) and the second element is the value
                expression node.

        Returns:
            tuple: (key_string, value_expression) where `key_string` is the key with
            surrounding quotes removed for quoted string keys, and `value_expression`
            is the parsed value node.
        """
        # First item is the key (IDENTIFIER or STRING token)
        key = self._get_token_value(items[0])
        # Strip quotes from STRING keys
        if (key.startswith('"') and key.endswith('"')) or (
            key.startswith("'") and key.endswith("'")
        ):
            key = key[1:-1]
        # Second item is the value expression
        value_expr = items[1]
        return (key, value_expr)


class CypherParser:
    """Main parser for openCypher queries.

    Examples:
        >>> parser = CypherParser()
        >>> ast = parser.parse("MATCH (n:Person) RETURN n")
        >>> isinstance(ast, CypherQuery)
        True
    """

    def __init__(self):
        """
        Create a Cypher parser instance and load the cached Lark grammar.

        Stores the compiled Lark parser on self._lark for reuse.
        Bumps the recursion limit once at construction (additive, never lowered)
        so Lark's transformer can handle deeply nested literals without racing
        on the process-global limit in concurrent use.
        """
        import sys

        sys.setrecursionlimit(max(sys.getrecursionlimit(), sys.getrecursionlimit() + 500))
        self._lark = _get_lark_parser()

    def parse(self, query: str) -> "CypherQuery | list[CypherQuery]":
        """
        Parse a Cypher query string into GraphForge AST nodes.

        Parameters:
            query (str): The Cypher query string to parse.

        Returns:
            CypherQuery | list[CypherQuery]: A single `CypherQuery` when the input contains one
            statement, or a list of `CypherQuery` for multi-statement scripts.

        Raises:
            SyntaxError: If the query is syntactically invalid or parsing fails.
        """
        transformer = ASTTransformer(query_source=query)
        try:
            tree = self._lark.parse(query)
            result = transformer.transform(tree)
        except SyntaxError:
            raise
        except Exception as exc:
            # Wrap Lark parse errors (UnexpectedToken, UnexpectedCharacters, etc.)
            # into SyntaxError so callers have a single exception type to catch.
            raise SyntaxError(str(exc)) from exc
        # script rule always returns a list; unwrap single queries for backward compat
        if isinstance(result, list) and len(result) == 1:
            return cast("CypherQuery", result[0])
        return cast("list[CypherQuery]", result)


def parse_cypher(query: str) -> "CypherQuery | list[CypherQuery]":
    """Convenience function to parse a Cypher query.

    Args:
        query: The Cypher query string to parse

    Returns:
        CypherQuery AST node, or list of CypherQuery for multi-statement scripts
    """
    parser = CypherParser()
    return parser.parse(query)
