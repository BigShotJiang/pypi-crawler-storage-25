"""Procedure registry for CALL clause support.

Procedures are registered with metadata (parameter names/types, output column
names/types) and a callable that implements the procedure logic.

The TCK uses "test.*" procedures defined per-scenario via the BDD step
"there exists a procedure …". User code can register procedures on a GraphForge
instance via gf.register_procedure(…).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProcedureColumn:
    """A single input parameter or output column of a procedure."""

    name: str
    cypher_type: str  # "STRING", "INTEGER", "FLOAT", "BOOLEAN", "NUMBER", "ANY", etc.
    nullable: bool = True  # openCypher uses TYPE? for nullable


@dataclass
class ProcedureDefinition:
    """Metadata and implementation of a registered procedure.

    Attributes:
        name: Fully-qualified procedure name (e.g. "test.doNothing").
        parameters: Ordered list of input parameters.
        output_columns: Ordered list of output columns.
        implementation: Callable(*args) -> list[dict[str, Any]].
            Each dict maps output column names to Python values.
            If None the procedure has no outputs (void).
    """

    name: str
    parameters: list[ProcedureColumn] = field(default_factory=list)
    output_columns: list[ProcedureColumn] = field(default_factory=list)
    implementation: Callable[..., list[dict[str, Any]]] | None = None


class ProcedureRegistry:
    """Thread-local registry of available procedures.

    Each GraphForge instance owns one registry so procedures are scoped to
    the graph instance.  The TCK harness creates a fresh registry per scenario.
    """

    def __init__(self) -> None:
        self._procedures: dict[str, ProcedureDefinition] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, defn: ProcedureDefinition) -> None:
        """Register a procedure definition."""
        self._procedures[defn.name] = defn

    def register_from_tck(
        self,
        name: str,
        parameters: list[tuple[str, str]],
        output_columns: list[tuple[str, str]],
        rows: list[dict[str, Any]],
    ) -> None:
        """Register a procedure from TCK BDD step data.

        Args:
            name: Qualified procedure name.
            parameters: [(param_name, type_str), ...].
            output_columns: [(col_name, type_str), ...].
            rows: Static result rows — the procedure always returns this table,
                optionally filtered by matching input parameter values.
        """
        params = [ProcedureColumn(n, t) for n, t in parameters]
        outputs = [ProcedureColumn(n, t) for n, t in output_columns]
        static_rows = list(rows)
        param_names = [p.name for p in params]

        def _impl(*args: Any) -> list[dict[str, Any]]:
            # Reject wrong-arity calls.
            if len(args) != len(param_names):
                raise TypeError(
                    f"Procedure '{name}' expects {len(param_names)} argument(s), got {len(args)}"
                )
            # If no parameters, return all rows.
            if not param_names:
                return list(static_rows)
            # Filter rows by matching input args against parameter columns.
            result = []
            for row in static_rows:
                match = True
                for pname, arg_val in zip(param_names, args):
                    if pname not in row:
                        continue
                    row_val = row[pname]
                    # null arg matches null row value
                    if arg_val is None and row_val is None:
                        continue
                    if arg_val is None or row_val is None:
                        match = False
                        break
                    # Coerce for NUMBER type compatibility (int ≈ float)
                    a, r = arg_val, row_val
                    if isinstance(a, int) and isinstance(r, float):
                        a = float(a)
                    elif isinstance(a, float) and isinstance(r, int):
                        r = float(r)
                    if a != r:
                        match = False
                        break
                if match:
                    result.append(row)
            return result

        self._procedures[name] = ProcedureDefinition(
            name=name,
            parameters=params,
            output_columns=outputs,
            implementation=_impl,
        )

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> ProcedureDefinition | None:
        """Return the procedure definition or None if not found."""
        return self._procedures.get(name)

    def exists(self, name: str) -> bool:
        """Return True if a procedure with this name is registered."""
        return name in self._procedures

    def all_names(self) -> list[str]:
        """Return all registered procedure names."""
        return list(self._procedures.keys())
