"""In-memory graph store with adjacency lists.

This module provides an in-memory graph storage implementation using
adjacency lists for efficient traversal. This is the foundational storage
layer that will later be backed by persistent storage.

The Graph class stores:
- Nodes indexed by ID
- Edges indexed by ID
- Outgoing adjacency lists (node_id -> list of outgoing edges)
- Incoming adjacency lists (node_id -> list of incoming edges)
- Label index (label -> set of node IDs)
- Type index (edge_type -> set of edge IDs)
"""

from collections import defaultdict
import time

from graphforge.optimizer.statistics import GraphStatistics
from graphforge.types.graph import EdgeRef, NodeRef


class Graph:
    """In-memory graph store with adjacency list representation.

    The graph maintains several indexes for efficient queries:
    - Node storage: id -> NodeRef
    - Edge storage: id -> EdgeRef
    - Outgoing edges: node_id -> [EdgeRef]
    - Incoming edges: node_id -> [EdgeRef]
    - Label index: label -> {node_id}
    - Type index: edge_type -> {edge_id}

    Examples:
        >>> graph = Graph()
        >>> node = NodeRef(id=1, labels=frozenset(["Person"]), properties={})
        >>> graph.add_node(node)
        >>> graph.node_count()
        1
        >>> graph.get_node(1) == node
        True
    """

    def __init__(self):
        """Initialize an empty graph."""
        # Primary storage
        self._nodes: dict[int | str, NodeRef] = {}
        self._edges: dict[int | str, EdgeRef] = {}

        # Adjacency lists for traversal
        self._outgoing: dict[int | str, list[EdgeRef]] = defaultdict(list)
        self._incoming: dict[int | str, list[EdgeRef]] = defaultdict(list)

        # Indexes for efficient queries
        self._label_index: dict[str, set[int | str]] = defaultdict(set)
        self._type_index: dict[str, set[int | str]] = defaultdict(set)
        # Property equality index: prop_name → value → {node_id}
        self._prop_index: dict[str, dict[object, set[int | str]]] = defaultdict(
            lambda: defaultdict(set)
        )

        # Mutable statistics counters (built into GraphStatistics lazily on get_statistics())
        self._total_nodes: int = 0
        self._total_edges: int = 0
        self._node_counts_by_label: dict[str, int] = {}
        self._edge_counts_by_type: dict[str, int] = {}
        self._avg_degree_by_type: dict[str, float] = {}
        # Incremental unique-source tracking per edge type (avoids O(n) scan on insert)
        self._unique_sources_by_type: dict[str, set[int | str]] = defaultdict(set)
        # Tracks actual last-mutation time for GraphStatistics.last_updated
        self._stats_last_updated: float = time.time()
        # When True, _update_statistics_after_add_* only increments counters; avg_degree
        # and unique-source tracking are rebuilt once in _flush_deferred_stats().
        self._defer_stats: bool = False

    def add_node(self, node: NodeRef) -> None:
        """Add a node to the graph.

        Args:
            node: The node to add

        Note:
            If a node with this ID already exists, it will be replaced.
        """
        # Track if this is a new node (for statistics)
        is_new_node = node.id not in self._nodes

        # Remove old node from label index, property index, and statistics if it exists
        if not is_new_node:
            old_node = self._nodes[node.id]
            for label in old_node.labels:
                self._label_index[label].discard(node.id)
                count = self._node_counts_by_label.get(label, 0)
                if count > 1:
                    self._node_counts_by_label[label] = count - 1
                elif label in self._node_counts_by_label:
                    del self._node_counts_by_label[label]
            for prop_name, cypher_val in old_node.properties.items():
                val = cypher_val.value if hasattr(cypher_val, "value") else cypher_val
                if isinstance(val, (str, int, float, bool)) or val is None:
                    self._prop_index[prop_name][val].discard(node.id)

        # Store node
        self._nodes[node.id] = node

        # Update label index
        for label in node.labels:
            self._label_index[label].add(node.id)

        # Update property index (scalar values only — lists/maps are not hashable)
        for prop_name, cypher_val in node.properties.items():
            val = cypher_val.value if hasattr(cypher_val, "value") else cypher_val
            if isinstance(val, (str, int, float, bool)) or val is None:
                self._prop_index[prop_name][val].add(node.id)

        # Initialize adjacency lists if not present
        if node.id not in self._outgoing:
            self._outgoing[node.id] = []
        if node.id not in self._incoming:
            self._incoming[node.id] = []

        # Update statistics
        if is_new_node:
            self._update_statistics_after_add_node(node)
        else:
            # Replacement: increment counts for new labels (decrements already done above)
            for label in node.labels:
                self._node_counts_by_label[label] = self._node_counts_by_label.get(label, 0) + 1

    def get_node(self, node_id: int | str) -> NodeRef | None:
        """Get a node by its ID.

        Args:
            node_id: The node ID to retrieve

        Returns:
            The NodeRef if found, None otherwise
        """
        return self._nodes.get(node_id)

    def has_node(self, node_id: int | str) -> bool:
        """Check if a node exists in the graph.

        Args:
            node_id: The node ID to check

        Returns:
            True if the node exists, False otherwise
        """
        return node_id in self._nodes

    def node_count(self) -> int:
        """Get the number of nodes in the graph.

        Returns:
            The number of nodes
        """
        return len(self._nodes)

    def get_all_nodes(self) -> list[NodeRef]:
        """Get all nodes in the graph.

        Returns:
            List of all nodes
        """
        return list(self._nodes.values())

    def get_nodes_by_label(self, label: str) -> list[NodeRef]:
        """Get all nodes with a specific label.

        Args:
            label: The label to filter by

        Returns:
            List of nodes with the specified label
        """
        node_ids = self._label_index.get(label, set())
        return [self._nodes[node_id] for node_id in node_ids]

    def get_nodes_by_property(self, prop_name: str, value: object) -> list[NodeRef]:
        """Get all nodes where property equals value (exact match).

        Args:
            prop_name: Property name to match
            value: Python primitive to match (unwrapped from CypherValue)

        Returns:
            List of nodes with the specified property value
        """
        node_ids = self._prop_index.get(prop_name, {}).get(value, set())
        return [self._nodes[nid] for nid in node_ids if nid in self._nodes]

    def get_nodes_by_label_and_property(
        self, label: str, prop_name: str, value: object
    ) -> list[NodeRef]:
        """Get all nodes with a label AND a matching property value.

        Args:
            label: Required label
            prop_name: Property name to match
            value: Python primitive to match (unwrapped from CypherValue)

        Returns:
            List of nodes satisfying both constraints (intersection)
        """
        label_ids = self._label_index.get(label, set())
        prop_ids = self._prop_index.get(prop_name, {}).get(value, set())
        # Intersect the smaller set against the larger for efficiency
        if len(label_ids) <= len(prop_ids):
            return [self._nodes[nid] for nid in label_ids if nid in prop_ids and nid in self._nodes]
        return [self._nodes[nid] for nid in prop_ids if nid in label_ids and nid in self._nodes]

    def remove_node_from_indexes(self, node: NodeRef) -> None:
        """Remove a node from all indexes (label, property). Does not remove from _nodes.

        Called by the executor before removing a node from _nodes so that
        index invariants are maintained.
        """
        for label in node.labels:
            self._label_index[label].discard(node.id)
        for prop_name, cypher_val in node.properties.items():
            val = cypher_val.value if hasattr(cypher_val, "value") else cypher_val
            if isinstance(val, (str, int, float, bool)) or val is None:
                self._prop_index[prop_name][val].discard(node.id)

    def add_node_to_indexes(self, node: NodeRef) -> None:
        """Add a node to label and property indexes without touching _nodes or statistics.

        Used by the executor after in-place property/label mutations (SET, REMOVE)
        to keep the indexes consistent without a full add_node round-trip.
        """
        for label in node.labels:
            self._label_index[label].add(node.id)
        for prop_name, cypher_val in node.properties.items():
            val = cypher_val.value if hasattr(cypher_val, "value") else cypher_val
            if isinstance(val, (str, int, float, bool)) or val is None:
                self._prop_index[prop_name][val].add(node.id)

    def get_statistics(self) -> GraphStatistics:
        """Get current graph statistics for cost-based optimization.

        Returns:
            GraphStatistics instance built from mutable counters.
        """
        return GraphStatistics(
            total_nodes=self._total_nodes,
            total_edges=self._total_edges,
            node_counts_by_label=dict(self._node_counts_by_label),
            edge_counts_by_type=dict(self._edge_counts_by_type),
            avg_degree_by_type=dict(self._avg_degree_by_type),
            last_updated=time.time(),  # lazy: stamp at read time, not per mutation
        )

    def _update_statistics_after_add_node(self, node: NodeRef) -> None:
        """Update mutable node statistics counters."""
        self._total_nodes += 1
        for label in node.labels:
            self._node_counts_by_label[label] = self._node_counts_by_label.get(label, 0) + 1

    def _update_statistics_after_add_edge(self, edge: EdgeRef) -> None:
        """Update mutable edge statistics counters."""
        self._total_edges += 1
        self._edge_counts_by_type[edge.type] = self._edge_counts_by_type.get(edge.type, 0) + 1
        if self._defer_stats:
            # Unique-source and avg_degree rebuilt in bulk by _flush_deferred_stats().
            return
        # Incremental unique-source tracking (O(1))
        self._unique_sources_by_type[edge.type].add(edge.src.id)
        unique_sources = len(self._unique_sources_by_type[edge.type])
        self._avg_degree_by_type[edge.type] = self._edge_counts_by_type[edge.type] / max(
            unique_sources, 1
        )

    def _flush_deferred_stats(self) -> None:
        """Rebuild unique-source and avg_degree from adjacency lists after bulk ingest."""
        self._unique_sources_by_type.clear()
        self._avg_degree_by_type.clear()
        for edge in self._edges.values():
            self._unique_sources_by_type[edge.type].add(edge.src.id)
        for etype, count in self._edge_counts_by_type.items():
            unique = len(self._unique_sources_by_type.get(etype, set()))
            self._avg_degree_by_type[etype] = count / max(unique, 1)

    def add_edge(self, edge: EdgeRef) -> None:
        """Add an edge to the graph.

        Args:
            edge: The edge to add

        Raises:
            ValueError: If source or destination node doesn't exist

        Note:
            If an edge with this ID already exists, it will be replaced.
        """
        # Validate that nodes exist
        if edge.src.id not in self._nodes:
            raise ValueError(f"Source node {edge.src.id} not found in graph")
        if edge.dst.id not in self._nodes:
            raise ValueError(f"Destination node {edge.dst.id} not found in graph")

        # Track if this is a new edge (for statistics)
        is_new_edge = edge.id not in self._edges

        # Remove old edge from indexes and statistics if it exists
        if not is_new_edge:
            old_edge = self._edges[edge.id]
            self._outgoing[old_edge.src.id].remove(old_edge)
            self._incoming[old_edge.dst.id].remove(old_edge)
            self._type_index[old_edge.type].discard(edge.id)
            # Decrement old edge's type count
            old_count = self._edge_counts_by_type.get(old_edge.type, 0)
            if old_count > 1:
                self._edge_counts_by_type[old_edge.type] = old_count - 1
                # Check if src still has edges of old type before removing from unique-sources
                still_has_old_type = any(
                    e.type == old_edge.type
                    for e in self._outgoing.get(old_edge.src.id, [])
                    if e.id != old_edge.id
                )
                if not still_has_old_type:
                    self._unique_sources_by_type[old_edge.type].discard(old_edge.src.id)
                remaining = self._edge_counts_by_type[old_edge.type]
                unique_old = len(self._unique_sources_by_type.get(old_edge.type, set()))
                self._avg_degree_by_type[old_edge.type] = remaining / max(unique_old, 1)
            elif old_edge.type in self._edge_counts_by_type:
                del self._edge_counts_by_type[old_edge.type]
                self._avg_degree_by_type.pop(old_edge.type, None)
                self._unique_sources_by_type.pop(old_edge.type, None)

        # Store edge
        self._edges[edge.id] = edge

        # Update adjacency lists
        self._outgoing[edge.src.id].append(edge)
        self._incoming[edge.dst.id].append(edge)

        # Update type index
        self._type_index[edge.type].add(edge.id)

        # Update statistics
        if is_new_edge:
            self._update_statistics_after_add_edge(edge)
        else:
            # Replacement: add new edge type stats (total_edges unchanged)
            self._unique_sources_by_type[edge.type].add(edge.src.id)
            self._edge_counts_by_type[edge.type] = self._edge_counts_by_type.get(edge.type, 0) + 1
            unique_sources = len(self._unique_sources_by_type[edge.type])
            self._avg_degree_by_type[edge.type] = self._edge_counts_by_type[edge.type] / max(
                unique_sources, 1
            )

    def get_edge(self, edge_id: int | str) -> EdgeRef | None:
        """Get an edge by its ID.

        Args:
            edge_id: The edge ID to retrieve

        Returns:
            The EdgeRef if found, None otherwise
        """
        return self._edges.get(edge_id)

    def has_edge(self, edge_id: int | str) -> bool:
        """Check if an edge exists in the graph.

        Args:
            edge_id: The edge ID to check

        Returns:
            True if the edge exists, False otherwise
        """
        return edge_id in self._edges

    def edge_count(self) -> int:
        """Get the number of edges in the graph.

        Returns:
            The number of edges
        """
        return len(self._edges)

    def get_all_edges(self) -> list[EdgeRef]:
        """Get all edges in the graph.

        Returns:
            List of all edges
        """
        return list(self._edges.values())

    def get_edges_by_type(self, edge_type: str) -> list[EdgeRef]:
        """Get all edges of a specific type.

        Args:
            edge_type: The edge type to filter by

        Returns:
            List of edges with the specified type
        """
        edge_ids = self._type_index.get(edge_type, set())
        return [self._edges[edge_id] for edge_id in edge_ids]

    def get_outgoing_edges(self, node_id: int | str) -> list[EdgeRef]:
        """Get all edges going out from a node.

        Args:
            node_id: The source node ID

        Returns:
            List of outgoing edges (empty list if node doesn't exist)
        """
        return list(self._outgoing.get(node_id, []))

    def get_incoming_edges(self, node_id: int | str) -> list[EdgeRef]:
        """Get all edges coming into a node.

        Args:
            node_id: The destination node ID

        Returns:
            List of incoming edges (empty list if node doesn't exist)
        """
        return list(self._incoming.get(node_id, []))

    def clear(self) -> None:
        """Clear all graph data, resetting to an empty state.

        Removes all nodes, edges, indexes, and statistics.
        This is equivalent to creating a new Graph() but reuses the same object.
        """
        self._nodes.clear()
        self._edges.clear()
        self._outgoing.clear()
        self._incoming.clear()
        self._label_index.clear()
        self._type_index.clear()
        self._prop_index.clear()
        self._unique_sources_by_type.clear()
        self._total_nodes = 0
        self._total_edges = 0
        self._node_counts_by_label.clear()
        self._edge_counts_by_type.clear()
        self._avg_degree_by_type.clear()
        self._stats_last_updated = time.time()

    def copy_stats_from(self, source: "Graph") -> None:
        """Copy all mutable statistics counters from another Graph instance.

        Used by clone() to avoid duplicating private layout knowledge.
        Performs shallow copies of scalars and deep copies of mutable containers.
        """
        import copy

        self._total_nodes = source._total_nodes
        self._total_edges = source._total_edges
        self._node_counts_by_label = dict(source._node_counts_by_label)
        self._edge_counts_by_type = dict(source._edge_counts_by_type)
        self._avg_degree_by_type = dict(source._avg_degree_by_type)
        self._unique_sources_by_type = defaultdict(
            set, {k: copy.copy(v) for k, v in source._unique_sources_by_type.items()}
        )
        self._stats_last_updated = source._stats_last_updated

    def hydrate_stats(self, stats: GraphStatistics) -> None:
        """Restore mutable statistics counters from a persisted GraphStatistics snapshot.

        Used by the SQLite backend load path.
        """
        self._total_nodes = stats.total_nodes
        self._total_edges = stats.total_edges
        self._node_counts_by_label = dict(stats.node_counts_by_label)
        self._edge_counts_by_type = dict(stats.edge_counts_by_type)
        self._avg_degree_by_type = dict(stats.avg_degree_by_type)
        self._stats_last_updated = stats.last_updated

    def snapshot(self) -> dict:
        """Create a snapshot of the current graph state.

        Returns:
            Dictionary containing all graph data for restoration

        Note:
            This creates a deep copy of all internal structures to support
            transaction rollback. For large graphs, this may be memory intensive.
        """
        import copy

        return {
            "nodes": copy.deepcopy(self._nodes),
            "edges": copy.deepcopy(self._edges),
            "outgoing": copy.deepcopy(dict(self._outgoing)),
            "incoming": copy.deepcopy(dict(self._incoming)),
            "label_index": copy.deepcopy(dict(self._label_index)),
            "type_index": copy.deepcopy(dict(self._type_index)),
            "prop_index": copy.deepcopy(dict(self._prop_index)),
            "unique_sources_by_type": copy.deepcopy(dict(self._unique_sources_by_type)),
            "total_nodes": self._total_nodes,
            "total_edges": self._total_edges,
            "node_counts_by_label": dict(self._node_counts_by_label),
            "edge_counts_by_type": dict(self._edge_counts_by_type),
            "avg_degree_by_type": dict(self._avg_degree_by_type),
            "stats_last_updated": self._stats_last_updated,
        }

    def restore(self, snapshot: dict) -> None:
        """Restore graph state from a snapshot.

        Args:
            snapshot: Snapshot dictionary created by snapshot()

        Note:
            Completely replaces the current graph state with the snapshot state.
        """
        self._nodes = snapshot["nodes"]
        self._edges = snapshot["edges"]
        self._outgoing = defaultdict(list, snapshot["outgoing"])
        self._incoming = defaultdict(list, snapshot["incoming"])
        self._label_index = defaultdict(set, snapshot["label_index"])
        self._type_index = defaultdict(set, snapshot["type_index"])
        raw_prop = snapshot.get("prop_index", {})
        self._prop_index = defaultdict(
            lambda: defaultdict(set), {k: defaultdict(set, v) for k, v in raw_prop.items()}
        )
        self._unique_sources_by_type = defaultdict(set, snapshot.get("unique_sources_by_type", {}))
        self._total_nodes = snapshot.get("total_nodes", len(self._nodes))
        self._total_edges = snapshot.get("total_edges", len(self._edges))
        self._node_counts_by_label = snapshot.get("node_counts_by_label", {})
        self._edge_counts_by_type = snapshot.get("edge_counts_by_type", {})
        self._avg_degree_by_type = snapshot.get("avg_degree_by_type", {})
        self._stats_last_updated = snapshot.get("stats_last_updated", time.time())
