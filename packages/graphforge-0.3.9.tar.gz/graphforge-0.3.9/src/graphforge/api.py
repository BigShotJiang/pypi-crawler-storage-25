"""High-level API for GraphForge.

This module provides the main public interface for GraphForge.
"""

from collections import defaultdict
from contextlib import contextmanager
import copy
import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, field_validator

from graphforge.executor.executor import QueryExecutor
from graphforge.optimizer.optimizer import QueryOptimizer
from graphforge.parser.parser import CypherParser
from graphforge.planner.planner import QueryPlanner
from graphforge.storage.memory import Graph
from graphforge.storage.sqlite_backend import SQLiteBackend
from graphforge.types.graph import EdgeRef, NodeRef
from graphforge.types.values import (
    CypherBool,
    CypherDate,
    CypherDateTime,
    CypherDuration,
    CypherFloat,
    CypherInt,
    CypherList,
    CypherMap,
    CypherNull,
    CypherPoint,
    CypherString,
    CypherTime,
)

# Pydantic models for API validation


class QueryInput(BaseModel):
    """Validates openCypher query input."""

    query: str = Field(..., min_length=1, description="openCypher query string")

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """Validate query is not just whitespace."""
        if not v.strip():
            raise ValueError("Query cannot be empty or whitespace only")
        return v

    model_config = {"frozen": True}


class NodeInput(BaseModel):
    """Validates node creation input."""

    labels: list[str] = Field(default_factory=list, description="Node labels")

    @field_validator("labels")
    @classmethod
    def validate_labels(cls, v: list[str]) -> list[str]:
        """Validate label names."""
        for label in v:
            if not label:
                raise ValueError("Label cannot be empty string")
            if not label[0].isalpha():
                raise ValueError(f"Label must start with a letter: {label}")
            if not label.replace("_", "").isalnum():
                raise ValueError(f"Label must contain only alphanumeric and underscore: {label}")
        return v

    model_config = {"frozen": True}


class RelationshipInput(BaseModel):
    """Validates relationship creation input."""

    rel_type: str = Field(..., min_length=1, description="Relationship type")

    @field_validator("rel_type")
    @classmethod
    def validate_rel_type(cls, v: str) -> str:
        """Validate relationship type name."""
        if not v[0].isalpha() and v[0] != "_":
            raise ValueError(f"Relationship type must start with letter or underscore: {v}")
        if not v.replace("_", "").isalnum():
            raise ValueError(
                f"Relationship type must contain only alphanumeric and underscore: {v}"
            )
        return v

    model_config = {"frozen": True}


class DatasetNameInput(BaseModel):
    """Validates dataset name input."""

    name: str = Field(..., min_length=1, description="Dataset name")

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Validate dataset name is not just whitespace."""
        if not v.strip():
            raise ValueError("Dataset name cannot be empty or whitespace only")
        return v

    model_config = {"frozen": True}


class GraphForge:
    """Main GraphForge interface for graph operations.

    GraphForge provides an embedded graph database with openCypher query support.

    Examples:
        >>> gf = GraphForge()
        >>> # Create nodes with Python API
        >>> alice = gf.create_node(['Person'], name='Alice', age=30)
        >>> bob = gf.create_node(['Person'], name='Bob', age=25)
        >>> # Create relationships
        >>> knows = gf.create_relationship(alice, bob, 'KNOWS', since=2020)
        >>> # Query with openCypher
        >>> results = gf.execute("MATCH (p:Person) WHERE p.age > 25 RETURN p.name")
    """

    def __init__(self, path: str | Path | None = None, enable_optimizer: bool = True):
        """Initialize GraphForge.

        Args:
            path: Optional path to persistent storage (SQLite database file)
                  If None, uses in-memory storage.
                  If provided, loads existing graph or creates new database.
            enable_optimizer: Enable query optimization (default: True).
                  When enabled, applies filter pushdown and predicate reordering
                  for better performance.

        Raises:
            ValueError: If path is empty string or whitespace only

        Examples:
            >>> # In-memory graph (lost on exit)
            >>> gf = GraphForge()

            >>> # Persistent graph (saved to disk)
            >>> gf = GraphForge("my-graph.db")
            >>> # ... create nodes ...
            >>> gf.close()  # Save to disk

            >>> # Later, load the graph
            >>> gf = GraphForge("my-graph.db")  # Graph is still there

            >>> # Disable optimizer for debugging
            >>> gf = GraphForge(enable_optimizer=False)
        """
        # Validate path if provided
        if path is not None:
            if isinstance(path, str) and not path.strip():
                raise ValueError("Path cannot be empty or whitespace only")

        # Initialize storage backend
        self.backend: SQLiteBackend | None
        if path:
            # Use SQLite for persistence
            self.backend = SQLiteBackend(Path(path))
            self.graph = self._load_graph_from_backend()
            # Set next IDs based on existing data
            self._next_node_id = self.backend.get_next_node_id()
            self._next_edge_id = self.backend.get_next_edge_id()
        else:
            # Use in-memory storage
            self.backend = None
            self.graph = Graph()
            self._next_node_id = 1
            self._next_edge_id = 1

        # Track if database has been closed
        self._closed = False

        # Transaction state
        self._in_transaction = False
        self._transaction_snapshot: dict | None = None

        # Initialize query execution components
        self.parser = CypherParser()
        from graphforge.procedures.registry import ProcedureRegistry

        self.procedure_registry = ProcedureRegistry()
        self.planner = QueryPlanner(procedure_registry=self.procedure_registry)
        self.optimizer = QueryOptimizer() if enable_optimizer else None
        self.executor = QueryExecutor(
            self.graph,
            graphforge=self,
            planner=self.planner,
            procedure_registry=self.procedure_registry,
        )

    def register_procedure(self, defn: Any) -> None:
        """Register a user-defined procedure for use in CALL statements.

        Args:
            defn: A ProcedureDefinition instance describing the procedure's
                  name, parameters, output columns, and implementation callable.

        Example::

            from graphforge.procedures import ProcedureDefinition, ProcedureColumn

            def my_impl(x):
                return [{"out": x * 2}]

            gf.register_procedure(ProcedureDefinition(
                name="my.double",
                parameters=[ProcedureColumn("x", "INTEGER")],
                output_columns=[ProcedureColumn("out", "INTEGER")],
                implementation=my_impl,
            ))
            gf.execute("CALL my.double(21) YIELD out RETURN out")
        """
        self.procedure_registry.register(defn)

    @classmethod
    def from_dataset(cls, name: str, path: str | Path | None = None) -> "GraphForge":
        """Create a new GraphForge instance and load a dataset into it.

        This is a convenience method that combines instance creation with dataset loading.

        Args:
            name: Dataset name (e.g., "snap-ego-facebook", "neo4j-movie-graph")
            path: Optional path for persistent storage

        Returns:
            GraphForge instance with dataset loaded

        Raises:
            ValueError: If dataset name is empty or whitespace only
            pydantic.ValidationError: If dataset name fails validation

        Examples:
            >>> # Load dataset into in-memory graph
            >>> gf = GraphForge.from_dataset("snap-ego-facebook")
            >>>
            >>> # Load dataset into persistent storage
            >>> gf = GraphForge.from_dataset("neo4j-movie-graph", "movies.db")
        """
        from graphforge.datasets import load_dataset

        # Validate dataset name
        DatasetNameInput(name=name)

        instance = cls(path)
        load_dataset(instance, name)  # nosec B615 - Not Hugging Face, our own dataset loader
        return instance

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("GraphForge instance has been closed")

    def register_function(self, name: str, func: Any) -> None:
        """
        Register a custom scalar function for use in Cypher queries.

        The provided function is stored under the uppercased form of `name` for runtime execution
        and the planner is informed about the extra function so it can be recognized during
        planning.

        Parameters:
            name (str): Function name (case-insensitive; stored as uppercase).
            func (callable): A Python callable with signature (args, ctx, executor) that returns
                a Cypher value.
        """
        self.executor.custom_functions[name.upper()] = func
        self.planner.register_extra_function(name)

    def execute(self, query: str, parameters: dict[str, Any] | None = None) -> list[dict]:
        """
        Parse, plan, (optionally) optimize, and execute an openCypher query.

        Parameters:
            query (str): openCypher query string to execute.
            parameters (dict[str, Any] | None): Optional mapping of parameter names to values;
                parameters are accessible as $name in queries and are passed as implicit
                arguments to CALL proc.name (without parentheses).

        Returns:
            list[dict]: Result rows as a list of dictionaries.

        Raises:
            RuntimeError: If the GraphForge instance is closed.
            pydantic.ValidationError: If the query fails validation (for example, if it is empty
                or contains only whitespace).
        """
        self._ensure_open()
        # Validate query input
        QueryInput(query=query)
        # Parse query (may return a single CypherQuery or a list for multi-statement scripts)
        ast = self.parser.parse(query)

        # Multi-statement script: execute each query sequentially, return last result
        if isinstance(ast, list):
            results: list[dict] = []
            for single_ast in ast:
                results = self._execute_single_ast(single_ast, parameters=parameters)
            return results

        return self._execute_single_ast(ast, parameters=parameters)

    def _execute_single_ast(self, ast: Any, parameters: dict[str, Any] | None = None) -> list[dict]:
        """Execute a single parsed AST and return results."""
        from graphforge.ast.query import UnionQuery

        if isinstance(ast, UnionQuery):
            # Handle UNION query: plan and optimize each branch separately
            branch_operators = []
            # Update optimizer statistics for cost-based optimization
            if self.optimizer:
                self.optimizer.update_statistics(self.graph.get_statistics())
            for branch_ast in ast.branches:
                branch_ops = self.planner.plan(branch_ast)
                # Optimize each branch independently
                if self.optimizer:
                    branch_ops = self.optimizer.optimize(branch_ops)
                branch_operators.append(branch_ops)

            # Create Union operator
            from graphforge.planner.operators import Union

            union_op = Union(branches=branch_operators, all=ast.all)
            operators = [union_op]
        else:
            # Regular query
            operators = self.planner.plan(ast)

            # Optimize query plan with current graph statistics
            if self.optimizer:
                self.optimizer.update_statistics(self.graph.get_statistics())
                operators = self.optimizer.optimize(operators)

        return self.executor.execute(operators, parameters=parameters)

    def create_node(self, labels: list[str] | None = None, **properties: Any) -> NodeRef:
        """Create a node with labels and properties.

        Automatically assigns a unique node ID and converts Python values
        to CypherValue types.

        Args:
            labels: List of label strings (e.g., ['Person', 'Employee'])
            **properties: Property key-value pairs as Python types.
                Values are converted to CypherValue types:
                - int → CypherInt
                - float → CypherFloat
                - str → CypherString
                - bool → CypherBool
                - None → CypherNull
                - dict with {x, y} or {latitude, longitude} → CypherPoint
                - dict (other) → CypherMap
                - list → CypherList
                - date → CypherDate
                - datetime → CypherDateTime
                - time → CypherTime
                - timedelta → CypherDuration

        Returns:
            NodeRef for the created node

        Raises:
            ValueError: If labels are invalid (empty, don't start with letter, etc.)
            pydantic.ValidationError: If labels fail validation
            TypeError: If property values are unsupported types

        Examples:
            >>> gf = GraphForge()
            >>> alice = gf.create_node(['Person'], name='Alice', age=30)
            >>> bob = gf.create_node(['Person', 'Employee'], name='Bob', salary=50000)
            >>> # Create node with spatial property (Cartesian coordinates)
            >>> office = gf.create_node(['Place'], name='Office', location={"x": 1.0, "y": 2.0})
            >>> # Create node with geographic coordinates
            >>> sf = gf.create_node(
            ...     ['City'], name='SF', location={"latitude": 37.7749, "longitude": -122.4194}
            ... )
            >>> # Query the created nodes
            >>> results = gf.execute("MATCH (p:Person) RETURN p.name")
        """
        self._ensure_open()
        # Validate labels
        NodeInput(labels=labels or [])

        # Convert properties to CypherValues
        cypher_properties = {key: self._to_cypher_value(value) for key, value in properties.items()}

        # Create node with auto-generated ID
        node = NodeRef(
            id=self._next_node_id,
            labels=frozenset(labels or []),
            properties=cypher_properties,
        )

        # Add to graph
        self.graph.add_node(node)

        # Increment ID for next node
        self._next_node_id += 1

        return node

    def create_relationship(
        self, src: NodeRef, dst: NodeRef, rel_type: str, **properties: Any
    ) -> EdgeRef:
        """Create a relationship between two nodes.

        Automatically assigns a unique edge ID and converts Python values
        to CypherValue types.

        Args:
            src: Source node (NodeRef)
            dst: Destination node (NodeRef)
            rel_type: Relationship type (e.g., 'KNOWS', 'WORKS_AT')
            **properties: Property key-value pairs as Python types.
                Values are converted to CypherValue types (same as create_node).
                Supports Point coordinates: {"x": 1.0, "y": 2.0} or
                {"latitude": 37.7, "longitude": -122.4}

        Returns:
            EdgeRef for the created relationship

        Raises:
            ValueError: If rel_type is invalid (empty, doesn't start with letter/underscore, etc.)
            TypeError: If src or dst are not NodeRef instances
            pydantic.ValidationError: If rel_type fails validation

        Examples:
            >>> gf = GraphForge()
            >>> alice = gf.create_node(['Person'], name='Alice')
            >>> bob = gf.create_node(['Person'], name='Bob')
            >>> knows = gf.create_relationship(alice, bob, 'KNOWS', since=2020)
            >>> # Relationship with spatial property
            >>> travels = gf.create_relationship(
            ...     alice, bob, 'TRAVELS_TO', distance_from={"x": 0.0, "y": 0.0}
            ... )
            >>> # Query relationships
            >>> results = gf.execute("MATCH (a)-[r:KNOWS]->(b) RETURN a.name, b.name")
        """
        self._ensure_open()
        # Validate inputs
        if not isinstance(src, NodeRef):
            raise TypeError(f"src must be a NodeRef, got {type(src).__name__}")
        if not isinstance(dst, NodeRef):
            raise TypeError(f"dst must be a NodeRef, got {type(dst).__name__}")

        RelationshipInput(rel_type=rel_type)

        # Convert properties to CypherValues
        cypher_properties = {key: self._to_cypher_value(value) for key, value in properties.items()}

        # Create edge with auto-generated ID
        edge = EdgeRef(
            id=self._next_edge_id,
            type=rel_type,
            src=src,
            dst=dst,
            properties=cypher_properties,
        )

        # Add to graph
        self.graph.add_edge(edge)

        # Increment ID for next edge
        self._next_edge_id += 1

        return edge

    def create_node_bulk(
        self, labels: list[str], properties: dict[str, Any] | None = None
    ) -> NodeRef:
        """Create a node without per-call input validation — for trusted bulk ingest only.

        Skips Pydantic NodeInput validation. Labels and property values must already be valid.
        Use create_node() when accepting user-supplied input.

        Args:
            labels: List of label strings (pre-validated by caller)
            properties: Dict of property key → Python value (pre-validated by caller)

        Returns:
            NodeRef for the created node
        """
        self._ensure_open()
        cypher_properties = (
            {key: self._to_cypher_value(value) for key, value in properties.items()}
            if properties
            else {}
        )
        node = NodeRef(
            id=self._next_node_id,
            labels=frozenset(labels),
            properties=cypher_properties,
        )
        self.graph.add_node(node)
        self._next_node_id += 1
        return node

    def create_relationship_bulk(
        self,
        src: NodeRef,
        dst: NodeRef,
        rel_type: str,
        properties: dict[str, Any] | None = None,
    ) -> EdgeRef:
        """Create a relationship without per-call input validation — for trusted bulk ingest only.

        Skips Pydantic RelationshipInput validation. rel_type must already be valid.
        Use create_relationship() when accepting user-supplied input.

        Args:
            src: Source node (NodeRef)
            dst: Destination node (NodeRef)
            rel_type: Relationship type (pre-validated by caller)
            properties: Dict of property key → Python value (pre-validated by caller)

        Returns:
            EdgeRef for the created relationship
        """
        self._ensure_open()
        if not isinstance(src, NodeRef):
            raise TypeError(f"src must be a NodeRef, got {type(src).__name__}")
        if not isinstance(dst, NodeRef):
            raise TypeError(f"dst must be a NodeRef, got {type(dst).__name__}")
        cypher_properties = (
            {key: self._to_cypher_value(value) for key, value in properties.items()}
            if properties
            else {}
        )
        edge = EdgeRef(
            id=self._next_edge_id,
            type=rel_type,
            src=src,
            dst=dst,
            properties=cypher_properties,
        )
        self.graph.add_edge(edge)
        self._next_edge_id += 1
        return edge

    @contextmanager
    def bulk_ingest(self):
        """Context manager that defers per-edge statistics during bulk ingest.

        Suspends expensive per-edge avg_degree and unique-source tracking;
        rebuilds them in a single pass on exit. Use for large dataset loads.

        Example::

            with gf.bulk_ingest():
                for src_id, dst_id in edge_list:
                    gf.create_relationship_bulk(nodes[src_id], nodes[dst_id], 'EDGE')
        """
        self._ensure_open()
        self.graph._defer_stats = True
        try:
            yield
        finally:
            self.graph._defer_stats = False
            self.graph._flush_deferred_stats()

    def _to_cypher_value(self, value):
        """Convert Python value to CypherValue type.

        Args:
            value: Python value (str, int, float, bool, None, list, dict,
                   date, datetime, time, timedelta)

        Returns:
            Corresponding CypherValue instance

        Raises:
            TypeError: If value type is not supported
        """
        # Already a CypherValue (e.g. CypherTime with _ns_residue) — preserve as-is
        if isinstance(
            value,
            (
                CypherBool,
                CypherInt,
                CypherFloat,
                CypherString,
                CypherNull,
                CypherDate,
                CypherDateTime,
                CypherTime,
                CypherDuration,
                CypherList,
                CypherMap,
            ),
        ):
            return value

        # Handle None
        if value is None:
            return CypherNull()

        # Handle bool (must check before int since bool is subclass of int)
        if isinstance(value, bool):
            return CypherBool(value)

        # Handle int
        if isinstance(value, int):
            return CypherInt(value)

        # Handle float
        if isinstance(value, float):
            return CypherFloat(value)

        # Handle str
        if isinstance(value, str):
            return CypherString(value)

        # Handle temporal types (check datetime before date since datetime is subclass of date)
        if isinstance(value, datetime.datetime):
            return CypherDateTime(value)
        if isinstance(value, datetime.date):
            return CypherDate(value)
        if isinstance(value, datetime.time):
            return CypherTime(value)
        if isinstance(value, datetime.timedelta):
            return CypherDuration(value)

        # Handle isodate.Duration (used for ISO 8601 durations with years/months)
        try:
            import isodate  # type: ignore[import-untyped]

            if isinstance(value, isodate.Duration):
                return CypherDuration(value)
        except ImportError:
            pass

        # Handle list (recursively convert elements)
        if isinstance(value, list):
            return CypherList([self._to_cypher_value(item) for item in value])

        # Handle dict - check for Point coordinates before CypherMap
        if isinstance(value, dict):
            keys = set(value.keys())

            # Detect Cartesian coordinates: {x, y} or {x, y, z}, optionally with crs
            # Valid: {"x", "y"}, {"x", "y", "crs"}, {"x", "y", "z"}, {"x", "y", "z", "crs"}
            cartesian_2d = {"x", "y"}
            cartesian_2d_crs = {"x", "y", "crs"}
            cartesian_3d = {"x", "y", "z"}
            cartesian_3d_crs = {"x", "y", "z", "crs"}

            if keys in (cartesian_2d, cartesian_2d_crs, cartesian_3d, cartesian_3d_crs):
                try:
                    return CypherPoint(value)
                except (ValueError, TypeError):
                    # Invalid coordinates (out of range or non-numeric), fall through to CypherMap
                    pass

            # Detect Geographic coordinates: {latitude, longitude}, optionally with crs
            # Valid: {"latitude", "longitude"}, {"latitude", "longitude", "crs"}
            geographic = {"latitude", "longitude"}
            geographic_crs = {"latitude", "longitude", "crs"}

            if keys in (geographic, geographic_crs):
                try:
                    return CypherPoint(value)
                except (ValueError, TypeError):
                    # Invalid coordinates (out of range or non-numeric), fall through to CypherMap
                    pass

            # Default to CypherMap (recursively convert values)
            return CypherMap({key: self._to_cypher_value(val) for key, val in value.items()})

        # Unsupported type
        raise TypeError(
            f"Unsupported property value type: {type(value).__name__}. "
            "Supported types: str, int, float, bool, None, list, dict, "
            "date, datetime, time, timedelta"
        )

    def begin(self):
        """Begin an explicit transaction.

        Starts a new transaction by taking a snapshot of the current graph state.
        Changes made after begin() can be committed or rolled back.

        Raises:
            RuntimeError: If already in a transaction

        Examples:
            >>> gf = GraphForge("my-graph.db")
            >>> gf.begin()
            >>> alice = gf.create_node(['Person'], name='Alice')
            >>> gf.commit()  # Changes are saved

            >>> gf.begin()
            >>> bob = gf.create_node(['Person'], name='Bob')
            >>> gf.rollback()  # Bob is removed
        """
        self._ensure_open()
        if self._in_transaction:
            raise RuntimeError("Already in a transaction. Commit or rollback first.")

        # Take snapshot of current state (including ID counters for full rollback)
        snapshot = self.graph.snapshot()
        snapshot["_next_node_id"] = self._next_node_id
        snapshot["_next_edge_id"] = self._next_edge_id
        self._transaction_snapshot = snapshot
        self._in_transaction = True

    def commit(self):
        """Commit the current transaction.

        Saves all changes made since begin() to the database (if using persistence).
        Clears the transaction snapshot.

        Raises:
            RuntimeError: If not in a transaction

        Examples:
            >>> gf = GraphForge("my-graph.db")
            >>> gf.begin()
            >>> gf.create_node(['Person'], name='Alice')
            >>> gf.commit()  # Changes are now permanent
        """
        self._ensure_open()
        if not self._in_transaction:
            raise RuntimeError("Not in a transaction. Call begin() first.")

        # Save to backend if persistence is enabled
        if self.backend:
            self._save_graph_to_backend()

        # Clear transaction state
        self._in_transaction = False
        self._transaction_snapshot = None

    def rollback(self):
        """Roll back the current transaction.

        Reverts all changes made since begin() by restoring the snapshot.
        Works for both in-memory and persistent graphs.

        Raises:
            RuntimeError: If not in a transaction

        Examples:
            >>> gf = GraphForge("my-graph.db")
            >>> gf.begin()
            >>> gf.create_node(['Person'], name='Alice')
            >>> results = gf.execute("MATCH (p:Person) RETURN count(*)")
            >>> # count is 1
            >>> gf.rollback()  # Alice is gone
            >>> results = gf.execute("MATCH (p:Person) RETURN count(*)")
            >>> # count is 0
        """
        self._ensure_open()
        if not self._in_transaction:
            raise RuntimeError("Not in a transaction. Call begin() first.")

        # Restore graph from snapshot (including ID counters)
        snapshot = self._transaction_snapshot
        assert snapshot is not None
        self.graph.restore(snapshot)
        self._next_node_id = snapshot["_next_node_id"]
        self._next_edge_id = snapshot["_next_edge_id"]

        # Rollback SQLite transaction if using persistence
        if self.backend:
            self.backend.rollback()

        # Clear transaction state
        self._in_transaction = False
        self._transaction_snapshot = None

    def close(self):
        """Save graph and close database.

        If using SQLite backend, saves all nodes and edges to disk and
        commits the transaction. Safe to call multiple times.

        If in an active transaction, the transaction is committed before closing.

        Examples:
            >>> gf = GraphForge("my-graph.db")
            >>> # ... create nodes and edges ...
            >>> gf.close()  # Save to disk
        """
        if not self._closed:
            if self.backend:
                # Auto-commit any pending transaction
                if self._in_transaction:
                    self.commit()
                else:
                    # Save changes if not in explicit transaction
                    self._save_graph_to_backend()

                self.backend.close()

            self._closed = True

    def clear(self) -> None:
        """Clear all graph data, resetting to an empty state.

        Resets the graph, internal ID counters, and transaction state without
        recreating the parser, planner, optimizer, or executor. This allows
        reusing a GraphForge instance for a new workload with zero parsing
        overhead.

        Raises:
            RuntimeError: If the instance has been closed

        Examples:
            >>> gf = GraphForge()
            >>> gf.execute("CREATE (:Person {name: 'Alice'})")
            >>> results = gf.execute("MATCH (n) RETURN count(n) AS c")
            >>> results[0]['c'].value
            1
            >>> gf.clear()
            >>> results = gf.execute("MATCH (n) RETURN count(n) AS c")
            >>> results[0]['c'].value
            0
        """
        if self._closed:
            raise RuntimeError("GraphForge instance has been closed")

        if self.backend is not None:
            if self._in_transaction:
                self.backend.rollback()
            raise RuntimeError(
                "Cannot clear a GraphForge instance with persistent storage. "
                "Use in-memory instances only (GraphForge() without path)."
            )

        # Reset graph data
        self.graph.clear()

        # Reset ID counters
        self._next_node_id = 1
        self._next_edge_id = 1

        # Reset transaction state
        self._in_transaction = False
        self._transaction_snapshot = None

        # Clear custom functions from both executor and planner allowlist
        for name in list(self.executor.custom_functions):
            self.planner._extra_function_names.discard(name.upper())
        self.executor.custom_functions.clear()

    def clone(self) -> "GraphForge":
        """Create a deep copy of this GraphForge instance.

        Creates a new GraphForge instance with a deep copy of graph state
        (nodes, edges, properties, indexes, ID counters) and fresh
        CypherParser, QueryPlanner, QueryOptimizer, and QueryExecutor
        instances.  Only the compiled Lark grammar is shared, via the
        module-level ``@lru_cache`` on ``_get_lark_parser``.

        Returns:
            GraphForge: A new instance with copied graph state

        Raises:
            RuntimeError: If the instance has been closed or uses persistent storage

        Examples:
            >>> gf = GraphForge()
            >>> gf.execute("CREATE (:Person {name: 'Alice'})")
            >>> clone = gf.clone()
            >>> clone.execute("CREATE (:Person {name: 'Bob'})")
            >>> # Original has 1 node, clone has 2 nodes
            >>> gf.execute("MATCH (n) RETURN count(n) AS c")[0]['c'].value
            1
            >>> clone.execute("MATCH (n) RETURN count(n) AS c")[0]['c'].value
            2
        """
        if self._closed:
            raise RuntimeError("Cannot clone a closed GraphForge instance")

        if self.backend is not None:
            raise RuntimeError(
                "Cannot clone GraphForge instances with persistent storage. "
                "Use in-memory instances only (GraphForge() without path)."
            )

        # Create new instance with same configuration
        cloned = GraphForge(
            enable_optimizer=self.optimizer is not None,
        )

        # Manually copy graph state (deepcopy doesn't work well with defaultdicts)
        cloned.graph._nodes = copy.deepcopy(self.graph._nodes)
        cloned.graph._edges = copy.deepcopy(self.graph._edges)

        # Copy adjacency lists
        cloned.graph._outgoing = defaultdict(list)
        for node_id, edges in self.graph._outgoing.items():
            cloned.graph._outgoing[node_id] = copy.deepcopy(edges)

        cloned.graph._incoming = defaultdict(list)
        for node_id, edges in self.graph._incoming.items():
            cloned.graph._incoming[node_id] = copy.deepcopy(edges)

        # Copy indexes
        cloned.graph._label_index = defaultdict(set)
        for label, node_ids in self.graph._label_index.items():
            cloned.graph._label_index[label] = copy.copy(node_ids)

        cloned.graph._type_index = defaultdict(set)
        for edge_type, edge_ids in self.graph._type_index.items():
            cloned.graph._type_index[edge_type] = copy.copy(edge_ids)

        # Copy mutable statistics counters via Graph helper
        cloned.graph.copy_stats_from(self.graph)

        # Copy ID counters
        cloned._next_node_id = self._next_node_id
        cloned._next_edge_id = self._next_edge_id

        # Copy transaction state (should be False/None in typical usage)
        cloned._in_transaction = self._in_transaction
        cloned._transaction_snapshot = (
            copy.deepcopy(self._transaction_snapshot) if self._transaction_snapshot else None
        )

        # Note: Custom functions are intentionally NOT copied. Each clone gets
        # its own executor instance; custom functions must be re-registered on
        # the clone if needed.

        return cloned

    def _load_graph_from_backend(self) -> Graph:
        """Load graph from SQLite backend.

        Returns:
            Graph instance populated with nodes and edges from database
        """
        assert self.backend is not None
        graph = Graph()

        # Load all nodes
        nodes = self.backend.load_all_nodes()
        node_map = {}  # Map node_id to NodeRef

        for node in nodes:
            graph.add_node(node)
            node_map[node.id] = node

        # Load all edges (returns dict of edge data)
        edges_data = self.backend.load_all_edges()

        # Reconstruct EdgeRef instances with actual NodeRef objects
        for edge_id, (edge_type, src_id, dst_id, properties) in edges_data.items():
            src_node = node_map[src_id]
            dst_node = node_map[dst_id]

            edge = EdgeRef(
                id=edge_id,
                type=edge_type,
                src=src_node,
                dst=dst_node,
                properties=properties,
            )

            graph.add_edge(edge)

        # Load statistics (restore mutable counters from persisted snapshot)
        loaded_stats = self.backend.load_statistics()
        if loaded_stats is not None:
            graph.hydrate_stats(loaded_stats)

        return graph

    def _save_graph_to_backend(self):
        """Save graph to SQLite backend using truncate + bulk insert."""
        assert self.backend is not None

        try:
            # Full rewrite: truncate then bulk-insert all nodes and edges in two
            # round-trips instead of one INSERT per element.
            self.backend.truncate_graph()
            self.backend.save_nodes_bulk(self.graph.get_all_nodes())
            self.backend.save_edges_bulk(self.graph.get_all_edges())

            # Save statistics
            stats = self.graph.get_statistics()
            self.backend.save_statistics(stats)

            # Commit transaction
            self.backend.commit()
        except Exception:
            self.backend.rollback()
            raise
