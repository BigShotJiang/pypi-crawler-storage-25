"""Expression evaluator for query execution.

This module evaluates AST expressions in an execution context to produce
CypherValue results.
"""

from collections.abc import Sequence
import math
from typing import Any

from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    ExtractExpression,
    FilterExpression,
    FunctionCall,
    LabelPredicate,
    ListComprehension,
    Literal,
    ParenthesizedExpr,
    PatternComprehension,
    PatternPredicate,
    PropertyAccess,
    QuantifierExpression,
    ReduceExpression,
    SubqueryExpression,
    Subscript,
    UnaryOp,
    Variable,
)
from graphforge.types.graph import EdgeRef, NodeRef
from graphforge.types.values import (
    CypherBool,
    CypherDate,
    CypherDateTime,
    CypherDistance,
    CypherDuration,
    CypherFloat,
    CypherInt,
    CypherList,
    CypherMap,
    CypherNull,
    CypherPath,
    CypherPoint,
    CypherString,
    CypherTime,
    CypherValue,
    from_python,
)


class EntityNotFoundError(Exception):
    """Raised when accessing properties/labels of a deleted entity."""


# Error messages
XOR_TYPE_ERROR_MSG = "XOR requires boolean operands"

# INT64 bounds (openCypher spec §3.1.1)
_INT64_MIN = -(1 << 63)
_INT64_MAX = (1 << 63) - 1


class ExecutionContext:
    """Context for query execution.

    Maintains variable bindings during query execution.

    Attributes:
        bindings: Dictionary mapping variable names to values
    """

    def __init__(self):
        """Initialize empty execution context."""
        self.bindings: dict[str, Any] = {}
        # Optional: pre-computed aggregate values as a list of (FunctionCall, CypherValue)
        # pairs. Used for composite aggregate expressions (e.g. count(n) + 3) and
        # ORDER BY after aggregation. Stored as a list (not dict) to avoid hashing
        # issues with FunctionCall objects that have list fields.
        self.aggregate_cache: list | None = None
        # Track deleted entity IDs (set of int) so property access raises DeletedEntityAccess
        self.deleted_ids: set[int | str] = set()

    def bind(self, name: str, value: Any) -> None:
        """Bind a variable to a value.

        Args:
            name: Variable name
            value: Value to bind (NodeRef, EdgeRef, CypherValue)
        """
        self.bindings[name] = value

    def get(self, name: str) -> Any:
        """Get a variable's value.

        Args:
            name: Variable name

        Returns:
            The bound value

        Raises:
            KeyError: If variable is not bound
        """
        return self.bindings[name]

    def has(self, name: str) -> bool:
        """Check if a variable is bound.

        Args:
            name: Variable name

        Returns:
            True if variable is bound
        """
        return name in self.bindings


def evaluate_expression(expr: Any, ctx: ExecutionContext, executor: Any = None) -> CypherValue:
    """Evaluate an AST expression in a context.

    Args:
        expr: AST expression node
        ctx: Execution context with variable bindings
        executor: Optional QueryExecutor instance for subquery evaluation

    Returns:
        CypherValue result

    Raises:
        KeyError: If a referenced variable is not bound
        TypeError: If expression type is not supported
    """
    # Literal
    if isinstance(expr, Literal):
        value = expr.value
        # Handle nested structures (lists and maps)
        if isinstance(value, list):
            # Evaluate each item in the list
            evaluated_items = [
                evaluate_expression(item, ctx, executor)
                if isinstance(
                    item,
                    (
                        Literal,
                        Variable,
                        PropertyAccess,
                        Subscript,
                        BinaryOp,
                        UnaryOp,
                        FunctionCall,
                        CaseExpression,
                        ListComprehension,
                        PatternComprehension,
                        QuantifierExpression,
                        SubqueryExpression,
                        ParenthesizedExpr,
                    ),
                )
                else from_python(item)
                for item in value
            ]
            return CypherList(evaluated_items)
        elif isinstance(value, dict):
            # Evaluate each value in the dict
            evaluated_dict = {}
            for key, val in value.items():
                if isinstance(
                    val,
                    (
                        Literal,
                        Variable,
                        PropertyAccess,
                        Subscript,
                        BinaryOp,
                        UnaryOp,
                        FunctionCall,
                        CaseExpression,
                        ListComprehension,
                        PatternComprehension,
                        QuantifierExpression,
                        SubqueryExpression,
                        ParenthesizedExpr,
                    ),
                ):
                    evaluated_dict[key] = evaluate_expression(val, ctx, executor)
                else:
                    evaluated_dict[key] = from_python(val)
            return CypherMap(evaluated_dict)
        else:
            # Simple scalar value — check INT64 range for integers
            if isinstance(value, int) and not isinstance(value, bool):
                if not (_INT64_MIN <= value <= _INT64_MAX):
                    raise ValueError(
                        f"Integer overflow: literal {value!r} is outside the valid "
                        f"INT64 range [{_INT64_MIN}, {_INT64_MAX}]"
                    )
            return from_python(value)

    # Parenthesized expression — transparent wrapper, just evaluate inner
    if isinstance(expr, ParenthesizedExpr):
        return evaluate_expression(expr.expr, ctx, executor)

    # Variable reference
    if isinstance(expr, Variable):
        name = expr.name
        if name in ctx.bindings:
            return ctx.bindings[name]  # type: ignore[no-any-return]
        # $param references fall back to executor seed context (params survive WITH/Project)
        if name.startswith("$") and executor is not None:
            seed = getattr(executor, "_seed_ctx", None)
            if seed is not None and name in seed.bindings:
                return seed.bindings[name]  # type: ignore[no-any-return]
        return ctx.get(name)  # type: ignore[no-any-return]  # raises KeyError if not found

    # Label predicate: n:Person or n:Person:Employee or r:TYPE
    if isinstance(expr, LabelPredicate):
        obj = ctx.get(expr.variable)
        if isinstance(obj, CypherNull):
            return CypherNull()
        if isinstance(obj, EdgeRef):
            # For relationships, a single-label predicate checks the relationship type
            return CypherBool(len(expr.labels) == 1 and obj.type == expr.labels[0])
        if not isinstance(obj, NodeRef):
            return CypherBool(False)
        return CypherBool(all(label in obj.labels for label in expr.labels))

    # Property access
    if isinstance(expr, PropertyAccess):
        # Get the base object: either from variable or evaluate base expression
        if expr.variable:
            obj = ctx.get(expr.variable)
        elif expr.base:
            obj = evaluate_expression(expr.base, ctx, executor)
        else:
            raise ValueError("PropertyAccess must have either variable or base")

        # Handle NULL: accessing property on NULL returns NULL
        if isinstance(obj, CypherNull):
            return CypherNull()

        # Handle NodeRef/EdgeRef
        if isinstance(obj, (NodeRef, EdgeRef)):
            # Check if entity was deleted in this execution context
            if hasattr(ctx, "deleted_ids") and obj.id in ctx.deleted_ids:
                raise EntityNotFoundError(
                    "DeletedEntityAccess: Tried to access property of a deleted entity"
                )
            if expr.property in obj.properties:
                return obj.properties[expr.property]  # type: ignore[no-any-return]
            return CypherNull()

        # Handle CypherMap property access (Issue #173)
        if isinstance(obj, CypherMap):
            if expr.property in obj.value:
                return obj.value[expr.property]  # type: ignore[no-any-return]
            return CypherNull()

        # Handle temporal value property access
        if isinstance(obj, (CypherDate, CypherTime, CypherDateTime, CypherDuration)):
            return _get_temporal_property(obj, expr.property)

        raise TypeError(f"Cannot access property on {type(obj).__name__}")

    # Unary operations
    if isinstance(expr, UnaryOp):
        # Special case: fold -Literal(int) before the overflow check so that
        # -0x8000000000000000 = INT64_MIN is accepted even though the raw literal
        # 0x8000000000000000 exceeds INT64_MAX (openCypher §3.1.1).
        if (
            expr.op == "-"
            and isinstance(expr.operand, Literal)
            and isinstance(expr.operand.value, int)
            and not isinstance(expr.operand.value, bool)
        ):
            negated = -expr.operand.value
            if not (_INT64_MIN <= negated <= _INT64_MAX):
                raise ValueError(
                    f"Integer overflow: -{expr.operand.value!r} is outside the valid "
                    f"INT64 range [{_INT64_MIN}, {_INT64_MAX}]"
                )
            return CypherInt(negated)

        operand_val = evaluate_expression(expr.operand, ctx, executor)

        # IS NULL operator
        if expr.op == "IS NULL":
            return CypherBool(isinstance(operand_val, CypherNull))

        # IS NOT NULL operator
        if expr.op == "IS NOT NULL":
            return CypherBool(not isinstance(operand_val, CypherNull))

        # NOT operator
        if expr.op == "NOT":
            # Handle NULL: NOT NULL → NULL
            if isinstance(operand_val, CypherNull):
                return CypherNull()
            # Must be boolean
            if isinstance(operand_val, CypherBool):
                return CypherBool(not operand_val.value)
            raise TypeError("NOT requires boolean operand")

        # Unary minus operator
        if expr.op == "-":
            # Handle NULL: -NULL → NULL
            if isinstance(operand_val, CypherNull):
                return CypherNull()
            # Must be numeric
            if isinstance(operand_val, CypherInt):
                negated = -operand_val.value
                if not (_INT64_MIN <= negated <= _INT64_MAX):
                    raise ValueError(
                        f"Integer overflow: negation of {operand_val.value} exceeds INT64 range"
                    )
                return CypherInt(negated)
            if isinstance(operand_val, CypherFloat):
                return CypherFloat(-operand_val.value)
            raise TypeError(
                f"Unary minus requires numeric operand, got {type(operand_val).__name__}"
            )

        raise ValueError(f"Unknown unary operator: {expr.op}")

    # Binary operations
    if isinstance(expr, BinaryOp):
        # For AND/OR, implement short-circuit evaluation
        # XOR needs both operands but has special NULL handling
        # Other operators need both operands evaluated
        if expr.op in ("AND", "OR", "XOR"):
            left_val = evaluate_expression(expr.left, ctx, executor)

            # Three-valued short-circuit semantics for AND
            if expr.op == "AND":
                # false AND anything = false (short-circuit)
                if isinstance(left_val, CypherBool) and not left_val.value:
                    return CypherBool(False)

                # Evaluate right operand
                right_val = evaluate_expression(expr.right, ctx, executor)

                # true AND x = x (return right as-is, could be true/false/NULL)
                if isinstance(left_val, CypherBool) and left_val.value:
                    if isinstance(right_val, (CypherBool, CypherNull)):
                        return right_val
                    raise TypeError("AND requires boolean operands")

                # NULL AND false = false
                if isinstance(left_val, CypherNull):
                    if isinstance(right_val, CypherBool) and not right_val.value:
                        return CypherBool(False)
                    # NULL AND true = NULL, NULL AND NULL = NULL
                    if isinstance(right_val, (CypherBool, CypherNull)):
                        return CypherNull()
                    raise TypeError("AND requires boolean operands")

                raise TypeError("AND requires boolean operands")

            # Three-valued short-circuit semantics for OR
            if expr.op == "OR":
                # true OR anything = true (short-circuit)
                if isinstance(left_val, CypherBool) and left_val.value:
                    return CypherBool(True)

                # Evaluate right operand
                right_val = evaluate_expression(expr.right, ctx, executor)

                # false OR x = x (return right as-is, could be true/false/NULL)
                if isinstance(left_val, CypherBool) and not left_val.value:
                    if isinstance(right_val, (CypherBool, CypherNull)):
                        return right_val
                    raise TypeError("OR requires boolean operands")

                # NULL OR true = true
                if isinstance(left_val, CypherNull):
                    if isinstance(right_val, CypherBool) and right_val.value:
                        return CypherBool(True)
                    # NULL OR false = NULL, NULL OR NULL = NULL
                    if isinstance(right_val, (CypherBool, CypherNull)):
                        return CypherNull()
                    raise TypeError("OR requires boolean operands")

                raise TypeError("OR requires boolean operands")

            # Three-valued logic for XOR (no short-circuit possible)
            if expr.op == "XOR":
                right_val = evaluate_expression(expr.right, ctx, executor)

                # If either operand is NULL, result is NULL
                if isinstance(left_val, CypherNull) or isinstance(right_val, CypherNull):
                    # Validate the non-NULL operand is boolean (if any)
                    if isinstance(left_val, CypherNull) and not isinstance(
                        right_val, (CypherBool, CypherNull)
                    ):
                        raise TypeError(XOR_TYPE_ERROR_MSG)
                    if isinstance(right_val, CypherNull) and not isinstance(
                        left_val, (CypherBool, CypherNull)
                    ):
                        raise TypeError(XOR_TYPE_ERROR_MSG)
                    return CypherNull()

                # Both operands must be boolean
                if not isinstance(left_val, CypherBool) or not isinstance(right_val, CypherBool):
                    raise TypeError(XOR_TYPE_ERROR_MSG)

                # XOR truth table: true XOR true = false, true XOR false = true,
                # false XOR true = true, false XOR false = false
                return CypherBool(left_val.value != right_val.value)

        # For all other operators, evaluate both operands
        left_val = evaluate_expression(expr.left, ctx, executor)
        right_val = evaluate_expression(expr.right, ctx, executor)

        # Comparison operators
        # NaN: all ordering comparisons return false for numeric, null for incompatible types
        def _is_nan(v: Any) -> bool:
            return isinstance(v, CypherFloat) and math.isnan(v.value)

        if expr.op in (">", "<", ">=", "<="):
            if _is_nan(left_val) or _is_nan(right_val):
                if isinstance(left_val, (CypherInt, CypherFloat)) and isinstance(
                    right_val, (CypherInt, CypherFloat)
                ):
                    return CypherBool(False)
                return CypherNull()

        if expr.op == ">":
            # Try left < right first to allow NodeRef/non-CypherValue null propagation
            result = left_val.less_than(right_val)
            if isinstance(result, CypherBool):
                result = right_val.less_than(left_val)
            return result

        if expr.op == "<":
            return left_val.less_than(right_val)

        if expr.op == ">=":
            # left >= right  is  NOT (left < right)
            result = left_val.less_than(right_val)
            if isinstance(result, CypherNull):
                return result
            return CypherBool(not result.value)

        if expr.op == "<=":
            # left <= right  is  NOT (right < left)
            result = right_val.less_than(left_val)
            if isinstance(result, CypherNull):
                return result
            return CypherBool(not result.value)

        if expr.op == "=":
            return left_val.equals(right_val)

        if expr.op == "<>":
            result = left_val.equals(right_val)
            if isinstance(result, CypherNull):
                return result
            return CypherBool(not result.value)

        # IN operator: value IN list
        if expr.op == "IN":
            # anything IN NULL → NULL
            if isinstance(right_val, CypherNull):
                return CypherNull()

            # Right operand must be a list
            if not isinstance(right_val, CypherList):
                raise TypeError(
                    f"IN operator requires a list on the right side, got {type(right_val).__name__}"
                )

            # Empty list: value IN [] → false (even for NULL IN [])
            # This must come before NULL check on left operand
            if not right_val.value:
                return CypherBool(False)

            # NULL IN non-empty-list → NULL
            if isinstance(left_val, CypherNull):
                return CypherNull()

            # Check if left_val is in the list
            # Use three-valued logic: if any comparison is NULL and no match found, return NULL
            has_null = False
            for item in right_val.value:
                result = left_val.equals(item)
                if isinstance(result, CypherBool):
                    if result.value:
                        return CypherBool(True)  # Found a match
                elif isinstance(result, CypherNull):
                    has_null = True  # Track that we saw a NULL comparison

            # No match found: return NULL if we saw any NULL comparisons, else false
            return CypherNull() if has_null else CypherBool(False)

        # Arithmetic operators
        if expr.op in ("+", "-", "*", "/", "%", "^"):
            # NULL propagation: any NULL operand returns NULL
            if isinstance(left_val, CypherNull) or isinstance(right_val, CypherNull):
                return CypherNull()

            # Special case: string concatenation with +
            if expr.op == "+":
                from graphforge.types.values import CypherString, CypherValue

                # List concatenation / element append / prepend
                if isinstance(left_val, CypherList) or isinstance(right_val, CypherList):
                    if isinstance(left_val, CypherList) and isinstance(right_val, CypherList):
                        return CypherList(left_val.value + right_val.value)
                    if isinstance(left_val, CypherList):
                        return CypherList([*left_val.value, right_val])
                    # right_val is CypherList
                    return CypherList([left_val, *right_val.value])

                if (
                    not isinstance(left_val, CypherList)
                    and not isinstance(right_val, CypherList)
                    and (isinstance(left_val, CypherString) or isinstance(right_val, CypherString))
                ):
                    # Ensure both operands are CypherValue instances before accessing .value
                    if not isinstance(left_val, CypherValue) or not isinstance(
                        right_val, CypherValue
                    ):
                        raise TypeError(
                            f"String concatenation requires CypherValue operands, "
                            f"got {type(left_val).__name__} and {type(right_val).__name__}"
                        )

                    # Convert both to strings and concatenate
                    left_str = (
                        left_val.value
                        if isinstance(left_val, CypherString)
                        else str(left_val.value)
                    )
                    right_str = (
                        right_val.value
                        if isinstance(right_val, CypherString)
                        else str(right_val.value)
                    )
                    return CypherString(left_str + right_str)

            # Temporal arithmetic: datetime + duration, datetime - duration, datetime - datetime
            if expr.op in ("+", "-"):
                # Addition: temporal + duration or duration + temporal
                if expr.op == "+":
                    if isinstance(
                        left_val, (CypherDateTime, CypherDate, CypherTime)
                    ) and isinstance(right_val, CypherDuration):
                        return _add_duration(left_val, right_val)
                    elif isinstance(left_val, CypherDuration) and isinstance(
                        right_val, (CypherDateTime, CypherDate, CypherTime)
                    ):
                        return _add_duration(right_val, left_val)

                # Duration + Duration or Duration - Duration
                if isinstance(left_val, CypherDuration) and isinstance(right_val, CypherDuration):
                    import isodate  # type: ignore[import-untyped]

                    lv = left_val.value
                    rv = right_val.value
                    if expr.op == "+":
                        if isinstance(lv, isodate.Duration) or isinstance(rv, isodate.Duration):
                            ly = getattr(lv, "years", 0) or 0
                            lm = getattr(lv, "months", 0) or 0
                            ltd = lv.tdelta if isinstance(lv, isodate.Duration) else lv
                            ry = getattr(rv, "years", 0) or 0
                            rm = getattr(rv, "months", 0) or 0
                            rtd = rv.tdelta if isinstance(rv, isodate.Duration) else rv
                            result_dur = isodate.Duration(years=ly + ry, months=lm + rm, days=0) + (
                                ltd + rtd
                            )
                            return CypherDuration(result_dur)
                        else:
                            return CypherDuration(lv + rv)
                    elif expr.op == "-":
                        if isinstance(lv, isodate.Duration) or isinstance(rv, isodate.Duration):
                            ly = getattr(lv, "years", 0) or 0
                            lm = getattr(lv, "months", 0) or 0
                            ltd = lv.tdelta if isinstance(lv, isodate.Duration) else lv
                            ry = getattr(rv, "years", 0) or 0
                            rm = getattr(rv, "months", 0) or 0
                            rtd = rv.tdelta if isinstance(rv, isodate.Duration) else rv
                            result_dur = isodate.Duration(years=ly - ry, months=lm - rm, days=0) + (
                                ltd - rtd
                            )
                            return CypherDuration(result_dur)
                        else:
                            return CypherDuration(lv - rv)

                # Subtraction: temporal - duration or temporal - temporal
                if expr.op == "-":
                    if isinstance(
                        left_val, (CypherDateTime, CypherDate, CypherTime)
                    ) and isinstance(right_val, CypherDuration):
                        return _subtract_duration(left_val, right_val)
                    elif isinstance(left_val, (CypherDateTime, CypherDate)) and isinstance(
                        right_val, (CypherDateTime, CypherDate)
                    ):
                        return _duration_between(left_val, right_val)

            # Duration * number or number * duration
            if (
                expr.op == "*"
                and isinstance(left_val, CypherDuration)
                and isinstance(right_val, (CypherInt, CypherFloat))
            ):
                return _scale_duration(left_val, float(right_val.value))
            if (
                expr.op == "*"
                and isinstance(left_val, (CypherInt, CypherFloat))
                and isinstance(right_val, CypherDuration)
            ):
                return _scale_duration(right_val, float(left_val.value))

            # Duration / number
            if (
                expr.op == "/"
                and isinstance(left_val, CypherDuration)
                and isinstance(right_val, (CypherInt, CypherFloat))
            ):
                divisor = float(right_val.value)
                if divisor == 0:
                    raise ZeroDivisionError("Duration division by zero")
                return _scale_duration(left_val, 1.0 / divisor)

            # Type checking: both operands must be numeric
            if not isinstance(left_val, (CypherInt, CypherFloat)) or not isinstance(
                right_val, (CypherInt, CypherFloat)
            ):
                raise TypeError(
                    f"Arithmetic operator {expr.op} requires numeric operands, "
                    f"got {type(left_val).__name__} and {type(right_val).__name__}"
                )

            # Type coercion: if either operand is float, result is float
            result_type = (
                CypherFloat
                if isinstance(left_val, CypherFloat) or isinstance(right_val, CypherFloat)
                else CypherInt
            )

            # Convert to Python numeric types
            left_num = (
                float(left_val.value) if isinstance(left_val, CypherFloat) else int(left_val.value)
            )
            right_num = (
                float(right_val.value)
                if isinstance(right_val, CypherFloat)
                else int(right_val.value)
            )

            # Perform arithmetic operation
            arith_result: float | int
            if expr.op == "+":
                arith_result = left_num + right_num
            elif expr.op == "-":
                arith_result = left_num - right_num
            elif expr.op == "*":
                arith_result = left_num * right_num
            elif expr.op == "/":
                if right_num == 0:
                    # Integer division by zero → NULL; float division by zero → NaN
                    if result_type is CypherInt:
                        return CypherNull()
                    return CypherFloat(float("nan"))
                # Integer / integer = integer (truncation toward zero per openCypher spec)
                # Use pure integer arithmetic to avoid float precision loss for large values
                if result_type is CypherInt:
                    quotient = abs(int(left_num)) // abs(int(right_num))
                    if (left_num < 0) != (right_num < 0):
                        quotient = -quotient
                    return CypherInt(quotient)
                # Float involved = float result
                return CypherFloat(left_num / right_num)
            elif expr.op == "%":
                # Modulo by zero returns NULL
                if right_num == 0:
                    return CypherNull()
                arith_result = left_num % right_num
            elif expr.op == "^":
                # Power: always returns float per openCypher spec
                # Handle edge cases: division by zero, overflow, complex, non-finite
                try:
                    pow_result = left_num**right_num
                except (ZeroDivisionError, OverflowError):
                    # 0^-1, very large numbers, etc. return NULL
                    return CypherNull()

                # Check for complex or non-finite results
                if isinstance(pow_result, complex) or (
                    isinstance(pow_result, float) and not math.isfinite(pow_result)
                ):
                    return CypherNull()

                return CypherFloat(float(pow_result))
            else:
                raise ValueError(f"Unknown arithmetic operator: {expr.op}")

            # Return with appropriate type (except division which always returns float)
            if result_type is CypherFloat:
                return CypherFloat(float(arith_result))
            else:
                return CypherInt(int(arith_result))

        # String matching operators
        if expr.op in ("STARTS WITH", "ENDS WITH", "CONTAINS"):
            # NULL handling: any NULL operand returns NULL
            if isinstance(left_val, CypherNull) or isinstance(right_val, CypherNull):
                return CypherNull()

            # Type checking: both operands must be strings; type mismatch returns null
            from graphforge.types.values import CypherString

            if not isinstance(left_val, CypherString) or not isinstance(right_val, CypherString):
                return CypherNull()

            # Perform string matching
            if expr.op == "STARTS WITH":
                return CypherBool(left_val.value.startswith(right_val.value))
            elif expr.op == "ENDS WITH":
                return CypherBool(left_val.value.endswith(right_val.value))
            elif expr.op == "CONTAINS":
                return CypherBool(right_val.value in left_val.value)

        raise ValueError(f"Unknown binary operator: {expr.op}")

    # CASE expressions
    if isinstance(expr, CaseExpression):
        if expr.subject is not None:
            # Simple CASE: CASE subject WHEN val THEN res ... END
            subject_val = evaluate_expression(expr.subject, ctx, executor)
            for when_val_expr, result_expr in expr.when_clauses:
                when_val = evaluate_expression(when_val_expr, ctx, executor)
                eq = subject_val.equals(when_val)
                if isinstance(eq, CypherBool) and eq.value:
                    return evaluate_expression(result_expr, ctx, executor)
        else:
            # Searched CASE: CASE WHEN cond THEN res ... END
            for condition_expr, result_expr in expr.when_clauses:
                condition_val = evaluate_expression(condition_expr, ctx, executor)
                # NULL is treated as false, not propagated
                if isinstance(condition_val, CypherBool) and condition_val.value:
                    return evaluate_expression(result_expr, ctx, executor)

        # No WHEN matched - return ELSE or NULL
        if expr.else_expr is not None:
            return evaluate_expression(expr.else_expr, ctx, executor)

        return CypherNull()

    # List comprehensions
    if isinstance(expr, ListComprehension):
        # Evaluate the list expression
        list_val = evaluate_expression(expr.list_expr, ctx, executor)

        # Must be a list
        if not isinstance(list_val, CypherList):
            raise TypeError(f"IN requires a list, got {type(list_val).__name__}")

        items: list[CypherValue] = []
        for item in list_val.value:
            # Create new context with loop variable bound
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.aggregate_cache = ctx.aggregate_cache
            new_ctx.bind(expr.variable, item)

            # Apply filter if present
            if expr.filter_expr is not None:
                filter_val = evaluate_expression(expr.filter_expr, new_ctx, executor)
                # Skip if filter is false or NULL
                if not (isinstance(filter_val, CypherBool) and filter_val.value):
                    continue

            # Apply map transformation if present, otherwise use item as-is
            if expr.map_expr is not None:
                result_val = evaluate_expression(expr.map_expr, new_ctx, executor)
            else:
                result_val = item

            items.append(result_val)

        return CypherList(items)

    # Pattern comprehensions
    if isinstance(expr, PatternComprehension):
        from graphforge.ast.clause import MatchClause
        from graphforge.ast.query import CypherQuery

        # Create a temporary MATCH query from the pattern
        match_clause = MatchClause(patterns=[expr.pattern])
        temp_query = CypherQuery(clauses=[match_clause])

        # Plan the query
        operators = executor.planner.plan(temp_query)

        # Execute pattern matching with current context
        match_ctx = ExecutionContext()
        match_ctx.bindings = dict(ctx.bindings)
        match_ctx.aggregate_cache = ctx.aggregate_cache
        match_rows = [match_ctx]

        # Execute all operators to get pattern matches
        for i, op in enumerate(operators):
            match_rows = executor._execute_operator(op, match_rows, i, len(operators))

        # Collect results
        results: list[CypherValue] = []
        for match_row in match_rows:
            # Apply filter if present
            if expr.filter_expr is not None:
                filter_val = evaluate_expression(expr.filter_expr, match_row, executor)
                # Skip if filter is false or NULL
                if not (isinstance(filter_val, CypherBool) and filter_val.value):
                    continue

            # Evaluate map expression
            result_val = evaluate_expression(expr.map_expr, match_row, executor)
            results.append(result_val)

        return CypherList(results)

    # FILTER expression - filter list by predicate
    if isinstance(expr, FilterExpression):
        # Evaluate the list expression
        list_val = evaluate_expression(expr.list_expr, ctx, executor)

        # NULL list returns NULL
        if isinstance(list_val, CypherNull):
            return CypherNull()

        # Must be a list
        if not isinstance(list_val, CypherList):
            raise TypeError(f"FILTER requires a list, got {type(list_val).__name__}")

        filtered_items: list[CypherValue] = []
        for item in list_val.value:
            # Create new context with loop variable bound
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.aggregate_cache = ctx.aggregate_cache
            new_ctx.bind(expr.variable, item)

            # Evaluate predicate
            predicate_val = evaluate_expression(expr.predicate, new_ctx, executor)

            # Include item only if predicate is true (NULL treated as false)
            if isinstance(predicate_val, CypherBool) and predicate_val.value:
                filtered_items.append(item)

        return CypherList(filtered_items)

    # EXTRACT expression - map transformation over list
    if isinstance(expr, ExtractExpression):
        # Evaluate the list expression
        list_val = evaluate_expression(expr.list_expr, ctx, executor)

        # NULL list returns NULL
        if isinstance(list_val, CypherNull):
            return CypherNull()

        # Must be a list
        if not isinstance(list_val, CypherList):
            raise TypeError(f"EXTRACT requires a list, got {type(list_val).__name__}")

        extracted_items: list[CypherValue] = []
        for item in list_val.value:
            # Create new context with loop variable bound
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.aggregate_cache = ctx.aggregate_cache
            new_ctx.bind(expr.variable, item)

            # Apply map transformation
            result_val = evaluate_expression(expr.map_expr, new_ctx, executor)
            extracted_items.append(result_val)

        return CypherList(extracted_items)

    # REDUCE expression - fold/reduce with accumulator
    if isinstance(expr, ReduceExpression):
        # Evaluate initial value
        accumulator_val = evaluate_expression(expr.initial_expr, ctx, executor)

        # Evaluate the list expression
        list_val = evaluate_expression(expr.list_expr, ctx, executor)

        # NULL list returns NULL
        if isinstance(list_val, CypherNull):
            return CypherNull()

        # Must be a list
        if not isinstance(list_val, CypherList):
            raise TypeError(f"REDUCE requires a list, got {type(list_val).__name__}")

        # Iterate and update accumulator
        for item in list_val.value:
            # Create new context with both accumulator and loop variable bound
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.aggregate_cache = ctx.aggregate_cache
            new_ctx.bind(expr.accumulator, accumulator_val)
            new_ctx.bind(expr.variable, item)

            # Evaluate update expression
            accumulator_val = evaluate_expression(expr.map_expr, new_ctx, executor)

        return accumulator_val

    # Quantifier expressions (ALL, ANY, NONE, SINGLE)
    if isinstance(expr, QuantifierExpression):
        # Evaluate the list expression
        list_val = evaluate_expression(expr.list_expr, ctx, executor)

        # NULL list returns NULL (three-valued logic)
        if isinstance(list_val, CypherNull):
            return CypherNull()

        # Must be a list
        if not isinstance(list_val, CypherList):
            raise TypeError(f"Quantifier requires a list, got {type(list_val).__name__}")

        # Count satisfied items and track NULL predicates (three-valued logic)
        satisfied_count = 0
        false_count = 0
        null_count = 0

        for item in list_val.value:
            # Create new context with loop variable bound
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.aggregate_cache = ctx.aggregate_cache
            new_ctx.bind(expr.variable, item)

            # Evaluate predicate
            predicate_val = evaluate_expression(expr.predicate, new_ctx, executor)

            # Track predicate results with three-valued logic
            if isinstance(predicate_val, CypherBool):
                if predicate_val.value:
                    satisfied_count += 1
                else:
                    false_count += 1
            elif isinstance(predicate_val, CypherNull):
                null_count += 1
            else:
                # Non-boolean, non-null result counts as NULL (unknown)
                null_count += 1

        # Apply quantifier logic with openCypher three-valued semantics
        list_length = len(list_val.value)

        if expr.quantifier == "ALL":
            # ALL: False if any False, True if empty or all True, else NULL
            if false_count > 0:
                return CypherBool(False)
            elif list_length == 0 or (satisfied_count == list_length):  # noqa: PLR1714
                return CypherBool(True)
            else:  # No False, but at least one NULL
                return CypherNull()

        elif expr.quantifier == "ANY":
            # ANY: True if any True, NULL if any NULL but no True, else False
            if satisfied_count > 0:
                return CypherBool(True)
            elif null_count > 0:
                return CypherNull()
            else:
                return CypherBool(False)

        elif expr.quantifier == "NONE":
            # NONE: False if any True, NULL if any NULL but no True, else True
            if satisfied_count > 0:
                return CypherBool(False)
            elif null_count > 0:
                return CypherNull()
            else:
                return CypherBool(True)

        elif expr.quantifier == "SINGLE":
            # SINGLE: True if exactly one True and no NULLs,
            # False if more than one True,
            # NULL if any NULL exists (can't determine uniqueness)
            if satisfied_count == 1 and null_count == 0:
                return CypherBool(True)
            elif satisfied_count > 1:
                return CypherBool(False)
            elif null_count > 0:
                # Can't determine uniqueness when NULLs exist
                return CypherNull()
            else:
                return CypherBool(False)

        else:
            raise ValueError(f"Unknown quantifier: {expr.quantifier}")

    # Pattern predicate: (n)-[:R]->() as boolean existence check in WHERE
    if isinstance(expr, PatternPredicate):
        return _evaluate_pattern_predicate(expr, ctx, executor)

    # Subquery expressions (EXISTS, COUNT)
    if isinstance(expr, SubqueryExpression):
        if executor is None:
            raise TypeError("Subquery expressions require executor parameter")

        # Simple EXISTS form: EXISTS { pattern [WHERE expr] }
        if expr.pattern_parts is not None:
            return _evaluate_simple_exists(expr, ctx, executor)

        if executor.planner is None:
            raise TypeError("Subquery expressions require executor with planner configured")

        # Plan the nested query, exposing outer-scope variables for correlated subqueries
        outer_vars = set(ctx.bindings.keys())
        operators = executor.planner.plan(expr.query, outer_scope_vars=outer_vars)

        # Create a new execution context with current bindings (correlated subquery)
        subquery_ctx = ExecutionContext()
        subquery_ctx.bindings = dict(ctx.bindings)
        subquery_ctx.aggregate_cache = ctx.aggregate_cache

        # Execute the subquery
        subquery_rows = [subquery_ctx]
        for i, op in enumerate(operators):
            subquery_rows = executor._execute_operator(op, subquery_rows, i, len(operators))

        # Return result based on subquery type
        if expr.type == "EXISTS":
            return CypherBool(len(subquery_rows) > 0)
        elif expr.type == "COUNT":
            return CypherInt(len(subquery_rows))
        else:
            raise ValueError(f"Unknown subquery type: {expr.type}")

    # Subscript operations (list indexing and slicing)
    if isinstance(expr, Subscript):
        return _evaluate_subscript(expr, ctx, executor)

    # Function calls
    if isinstance(expr, FunctionCall):
        # Check aggregate cache first (used when aggregate results are pre-computed
        # and the function call appears inside a composite expression like count(n) + 3,
        # or when ORDER BY references an aggregate from RETURN).
        # The cache is a list of (FunctionCall, value) pairs; we use structural
        # equality (Pydantic __eq__) to match — avoiding hashing issues with list args.
        if ctx.aggregate_cache is not None:
            for cached_expr, cached_val in ctx.aggregate_cache:
                if cached_expr == expr:
                    return cached_val  # type: ignore[no-any-return]
        return _evaluate_function(expr, ctx, executor)

    raise TypeError(f"Cannot evaluate expression type: {type(expr).__name__}")


# Function categories
STRING_FUNCTIONS = {
    "LENGTH",
    "SUBSTRING",
    "UPPER",
    "LOWER",
    "TOUPPER",
    "TOLOWER",
    "TRIM",
    "REVERSE",
    "SPLIT",
    "REPLACE",
    "LEFT",
    "RIGHT",
    "LTRIM",
    "RTRIM",
}

# Alias normalization: camelCase variants → canonical names
STRING_FUNCTION_ALIASES = {
    "TOUPPER": "UPPER",
    "TOLOWER": "LOWER",
}
LIST_FUNCTIONS = {"TAIL", "HEAD", "LAST", "REVERSE", "RANGE", "SIZE"}
TYPE_FUNCTIONS = {"TOBOOLEAN", "TOINTEGER", "TOFLOAT", "TOSTRING", "TYPE"}
TEMPORAL_FUNCTIONS = {
    "DATE",
    "DATETIME",
    "LOCALDATETIME",
    "TIME",
    "LOCALTIME",
    "DURATION",
    "YEAR",
    "MONTH",
    "DAY",
    "HOUR",
    "MINUTE",
    "SECOND",
    "TRUNCATE",
}
SPATIAL_FUNCTIONS = {"POINT", "DISTANCE"}
MATH_FUNCTIONS = {
    "ABS",
    "CEIL",
    "FLOOR",
    "ROUND",
    "SIGN",
    "SQRT",
    "RAND",
    "POW",
    "E",
    "PI",
    "EXP",
    "LOG",
    "LOG10",
    "SIN",
    "COS",
    "TAN",
    "COT",
    "ASIN",
    "ACOS",
    "ATAN",
    "ATAN2",
    "DEGREES",
    "RADIANS",
    "TIMESTAMP",
}
GRAPH_FUNCTIONS = {"ID", "ELEMENTID", "LABELS", "PROPERTIES", "KEYS", "STARTNODE", "ENDNODE"}
PATH_FUNCTIONS = {"LENGTH", "NODES", "RELATIONSHIPS", "HEAD", "LAST"}
AGGREGATE_FUNCTIONS = {
    "COUNT",
    "SUM",
    "AVG",
    "MAX",
    "MIN",
    "COLLECT",
    "PERCENTILEDISC",
    "PERCENTILECONT",
    "STDEV",
    "STDEVP",
}


def is_aggregate_function(expr: Any) -> bool:
    """Check if an expression is an aggregate function call.

    Args:
        expr: AST expression node

    Returns:
        True if expr is an aggregate function call, False otherwise
    """
    if not isinstance(expr, FunctionCall):
        return False
    return expr.name.upper() in AGGREGATE_FUNCTIONS


def _scale_duration(duration: "CypherDuration", factor: float) -> "CypherDuration":
    """Multiply a duration by a scalar factor.

    Fractional results cascade down through the precision hierarchy exactly
    as in the DURATION(map) constructor.
    """
    import datetime
    import math

    import isodate

    dv = duration.value
    if isinstance(dv, isodate.Duration):
        # isodate stores years/months as Decimal; convert to float before arithmetic
        years_f = float(getattr(dv, "years", 0) or 0) * factor
        months_f = float(getattr(dv, "months", 0) or 0) * factor
        td = dv.tdelta if hasattr(dv, "tdelta") else datetime.timedelta()
    else:
        years_f = 0.0
        months_f = 0.0
        td = dv

    # Scale days and the time part SEPARATELY to preserve the days/time boundary.
    # calendar days are NOT normalized into time hours.
    days_f = float(td.days) * factor  # calendar days (integer component)
    # time part: td.seconds and td.microseconds (0..86399s, 0..999999us)
    time_ns = round((float(td.seconds) * 1_000_000_000 + float(td.microseconds) * 1_000) * factor)

    def _split(v: float) -> tuple[int, float]:
        t = math.trunc(v)
        return t, v - t

    years_i, years_frac = _split(years_f)
    months_f += years_frac * 12.0
    months_i, months_frac = _split(months_f)
    # Fractional months cascade to days
    days_f += months_frac * 30.436875
    days_i, days_frac = _split(days_f)
    # Fractional days cascade to the time part in nanoseconds
    time_ns += round(days_frac * 86_400 * 1_000_000_000)

    # Normalise time_ns into hours/minutes/seconds/microseconds
    # (do NOT fold back into days)
    ns_per_us = 1_000
    ns_per_s = 1_000_000_000
    ns_per_min = 60 * ns_per_s
    ns_per_hour = 60 * ns_per_min

    sign_t = -1 if time_ns < 0 else 1
    abs_t = abs(time_ns)
    hours_i_raw = abs_t // ns_per_hour
    rem = abs_t - hours_i_raw * ns_per_hour
    minutes_i_raw = rem // ns_per_min
    rem -= minutes_i_raw * ns_per_min
    seconds_i_raw = rem // ns_per_s
    rem -= seconds_i_raw * ns_per_s
    us_i_raw = rem // ns_per_us
    ns_i_raw = rem % ns_per_us
    hours_i = sign_t * int(hours_i_raw)
    minutes_i = sign_t * int(minutes_i_raw)
    seconds_i = sign_t * int(seconds_i_raw)
    us_i = sign_t * int(us_i_raw)
    ns_i = sign_t * int(ns_i_raw)

    components = (years_i, months_i, days_i, hours_i, minutes_i, seconds_i, us_i, ns_i)
    result_td = datetime.timedelta(
        days=days_i,
        hours=hours_i,
        minutes=minutes_i,
        seconds=seconds_i,
        microseconds=us_i,
    )
    if years_i != 0 or months_i != 0:
        return CypherDuration(
            isodate.Duration(
                years=years_i,
                months=months_i,
                days=result_td.days,
                seconds=result_td.seconds,
                microseconds=result_td.microseconds,
            ),
            _components=components,
        )
    return CypherDuration(result_td, _components=components)


def _add_duration(temporal: CypherValue, duration: CypherDuration) -> CypherValue:
    """Add duration to temporal value.

    Args:
        temporal: CypherDateTime, CypherDate, or CypherTime
        duration: CypherDuration to add

    Returns:
        New temporal value with duration added
    """
    import datetime

    import isodate

    duration_val = duration.value

    # Compute ns_residue carry for DATETIME and TIME: sum temporal + duration ns_residues.
    # If the sum >= 1000, carry +1 into the microsecond (add 1µs to td before applying).
    # If the sum < 0, borrow 1µs (subtract 1µs from td) and wrap to +1000.
    dur_ns = duration._components[7] if len(duration._components) > 7 else 0
    temporal_ns = getattr(temporal, "_ns_residue", 0)
    ns_sum = temporal_ns + dur_ns
    ns_carry = ns_sum // 1000  # +1 if overflow, 0 if normal
    result_ns = ns_sum % 1000  # 0-999

    if isinstance(temporal, CypherDateTime):
        # Add duration to datetime, preserving timezone
        dt = temporal.value
        if isinstance(duration_val, isodate.Duration):
            # isodate.Duration with years/months - needs calendar arithmetic
            result = duration_val + dt
        else:
            # timedelta - simple addition
            result = dt + duration_val
        if ns_carry != 0:
            result = result + datetime.timedelta(microseconds=ns_carry)
        return CypherDateTime(result, _ns_residue=result_ns)

    elif isinstance(temporal, CypherDate):
        # Add duration to date — only apply years/months/days; ignore time components
        date_val = temporal.value
        if isinstance(duration_val, isodate.Duration):
            dt = datetime.datetime.combine(date_val, datetime.time.min)
            # Build a date-only duration (drop hours/minutes/seconds from tdelta).
            # Use duration._components[2] (canonical days) — tdelta.days is Python-
            # normalised and may be 0 for durations like {days: 1, milliseconds: -1}.
            days_only = isodate.Duration(
                years=duration_val.years,
                months=duration_val.months,
                days=duration._components[2],
            )
            result_dt = days_only + dt
            return CypherDate(result_dt.date())
        else:
            # timedelta — only use the canonical days component
            result = date_val + datetime.timedelta(days=duration._components[2])
            return CypherDate(result)

    elif isinstance(temporal, CypherTime):
        # Add duration to time (ignores date components of duration)
        time_val = temporal.value
        if isinstance(duration_val, isodate.Duration):
            # Extract timedelta component from isodate.Duration
            td = duration_val.tdelta if hasattr(duration_val, "tdelta") else datetime.timedelta()
        else:
            td = duration_val

        if ns_carry != 0:
            td = td + datetime.timedelta(microseconds=ns_carry)
        # Combine time with fixed sentinel date, add timedelta, extract time with timezone
        # Use fixed date (2000-01-01) for deterministic computation
        dt = datetime.datetime.combine(datetime.date(2000, 1, 1), time_val)
        result_dt = dt + td
        # Preserve timezone with timetz()
        return CypherTime(result_dt.timetz(), _ns_residue=result_ns)

    else:
        raise TypeError(
            f"Cannot add duration to {type(temporal).__name__}, "
            "expected CypherDateTime, CypherDate, or CypherTime"
        )


def _subtract_duration(temporal: CypherValue, duration: CypherDuration) -> CypherValue:
    """Subtract duration from temporal value.

    Args:
        temporal: CypherDateTime, CypherDate, or CypherTime
        duration: CypherDuration to subtract

    Returns:
        New temporal value with duration subtracted
    """
    import datetime

    import isodate

    duration_val = duration.value

    # Compute ns_residue borrow for DATETIME and TIME: temporal ns minus duration ns.
    # If the result < 0, borrow 1µs (apply one extra µs subtraction) and wrap to +1000.
    dur_ns = duration._components[7] if len(duration._components) > 7 else 0
    temporal_ns = getattr(temporal, "_ns_residue", 0)
    ns_diff = temporal_ns - dur_ns
    ns_borrow = -1 if ns_diff < 0 else 0  # -1 means subtract 1 extra µs
    result_ns = ns_diff % 1000  # 0-999

    if isinstance(temporal, CypherDateTime):
        # Subtract duration from datetime, preserving timezone
        dt = temporal.value
        if isinstance(duration_val, isodate.Duration):
            # isodate.Duration with years/months - needs calendar arithmetic
            # Negate the duration components
            negated = isodate.Duration(
                years=-duration_val.years if hasattr(duration_val, "years") else 0,
                months=-duration_val.months if hasattr(duration_val, "months") else 0,
            )
            if hasattr(duration_val, "tdelta"):
                result = dt + negated - duration_val.tdelta
            else:
                result = dt + negated
        else:
            # timedelta - simple subtraction
            result = dt - duration_val
        if ns_borrow != 0:
            result = result + datetime.timedelta(microseconds=ns_borrow)
        return CypherDateTime(result, _ns_residue=result_ns)

    elif isinstance(temporal, CypherDate):
        # Subtract duration from date — only apply years/months/days; ignore time components
        date_val = temporal.value
        if isinstance(duration_val, isodate.Duration):
            dt = datetime.datetime.combine(date_val, datetime.time.min)
            # Build a date-only negated duration.
            # Use duration._components[2] (canonical days) — tdelta.days is Python-
            # normalised and may be 0 for durations like {days: 1, milliseconds: -1}.
            days_only_neg = isodate.Duration(
                years=-duration_val.years,
                months=-duration_val.months,
                days=-duration._components[2],
            )
            result_dt = days_only_neg + dt
            return CypherDate(result_dt.date())
        else:
            # timedelta — only use the canonical days component
            result = date_val - datetime.timedelta(days=duration._components[2])
            return CypherDate(result)

    elif isinstance(temporal, CypherTime):
        # Subtract duration from time (ignores date components of duration)
        time_val = temporal.value
        if isinstance(duration_val, isodate.Duration):
            # Extract timedelta component from isodate.Duration
            td = duration_val.tdelta if hasattr(duration_val, "tdelta") else datetime.timedelta()
        else:
            td = duration_val

        if ns_borrow != 0:
            td = td + datetime.timedelta(microseconds=-ns_borrow)
        # Combine time with fixed sentinel date, subtract timedelta, extract time with timezone
        # Use fixed date (2000-01-01) for deterministic computation
        dt = datetime.datetime.combine(datetime.date(2000, 1, 1), time_val)
        result_dt = dt - td
        # Preserve timezone with timetz()
        return CypherTime(result_dt.timetz(), _ns_residue=result_ns)

    else:
        raise TypeError(
            f"Cannot subtract duration from {type(temporal).__name__}, "
            "expected CypherDateTime, CypherDate, or CypherTime"
        )


def _duration_between(left: CypherValue, right: CypherValue) -> CypherDuration:
    """Calculate duration between two temporal values (left - right).

    Args:
        left: CypherDateTime or CypherDate (minuend)
        right: CypherDateTime or CypherDate (subtrahend)

    Returns:
        CypherDuration representing the time difference (left - right)
    """
    import datetime

    # Convert to comparable datetime objects
    if isinstance(left, CypherDate):
        left_dt = datetime.datetime.combine(left.value, datetime.time.min)
    elif isinstance(left, CypherDateTime):
        left_dt = left.value
    else:
        raise TypeError(f"Cannot calculate duration from {type(left).__name__}")

    if isinstance(right, CypherDate):
        right_dt = datetime.datetime.combine(right.value, datetime.time.min)
    elif isinstance(right, CypherDateTime):
        right_dt = right.value
    else:
        raise TypeError(f"Cannot calculate duration to {type(right).__name__}")

    # Normalize timezone awareness: if one is tz-aware and the other is naive,
    # make both aware using the same timezone
    if left_dt.tzinfo is not None and right_dt.tzinfo is None:
        # Left is aware, right is naive - attach left's timezone to right
        right_dt = right_dt.replace(tzinfo=left_dt.tzinfo)
    elif left_dt.tzinfo is None and right_dt.tzinfo is not None:
        # Left is naive, right is aware - attach right's timezone to left
        left_dt = left_dt.replace(tzinfo=right_dt.tzinfo)

    # Calculate timedelta: left - right
    duration = left_dt - right_dt
    return CypherDuration(duration)


def _truncate_temporal(temporal: CypherValue, unit: str) -> CypherValue:
    """Truncate temporal value to specified unit.

    Args:
        temporal: CypherDateTime, CypherDate, or CypherTime
        unit: Truncation unit ('year', 'month', 'day', 'hour', 'minute', 'second',
              'millisecond', 'microsecond')

    Returns:
        Truncated temporal value

    Raises:
        ValueError: If unit is invalid
        TypeError: If temporal type doesn't support the unit
    """
    import datetime

    valid_units = {
        "millennium",
        "century",
        "decade",
        "year",
        "weekyear",
        "quarter",
        "month",
        "week",
        "day",
        "hour",
        "minute",
        "second",
        "millisecond",
        "microsecond",
    }
    if unit not in valid_units:
        raise ValueError(
            f"Invalid truncation unit: {unit}. Valid units: {', '.join(sorted(valid_units))}"
        )

    def _truncate_date(date_val: "datetime.date") -> "datetime.date":
        """Truncate a date to the given unit."""
        if unit == "millennium":
            trunc_year = max(1, (date_val.year // 1000) * 1000)
            return datetime.date(trunc_year, 1, 1)
        elif unit == "century":
            trunc_year = max(1, (date_val.year // 100) * 100)
            return datetime.date(trunc_year, 1, 1)
        elif unit == "decade":
            trunc_year = date_val.year // 10 * 10
            return datetime.date(trunc_year or 1, 1, 1)
        elif unit == "year":
            return datetime.date(date_val.year, 1, 1)
        elif unit == "weekyear":
            # First Monday of ISO week 1 for the ISO year containing this date
            iso_year = date_val.isocalendar()[0]
            jan4 = datetime.date(iso_year, 1, 4)
            return jan4 - datetime.timedelta(days=jan4.weekday())
        elif unit == "quarter":
            first_month = ((date_val.month - 1) // 3) * 3 + 1
            return datetime.date(date_val.year, first_month, 1)
        elif unit == "month":
            return datetime.date(date_val.year, date_val.month, 1)
        elif unit == "week":
            # Monday of current ISO week
            return date_val - datetime.timedelta(days=date_val.weekday())
        elif unit == "day":
            return date_val
        else:
            raise TypeError(
                f"Cannot truncate date to {unit}. "
                "Date supports: millennium, century, decade, year, weekYear, "
                "quarter, month, week, day"
            )

    if isinstance(temporal, CypherDateTime):
        dt = temporal.value
        tz = dt.tzinfo

        dt_result: datetime.datetime
        if unit in (
            "millennium",
            "century",
            "decade",
            "year",
            "weekyear",
            "quarter",
            "month",
            "week",
        ):
            trunc_d = _truncate_date(dt.date())
            dt_result = datetime.datetime(trunc_d.year, trunc_d.month, trunc_d.day, 0, 0, 0, 0, tz)
        elif unit == "day":
            dt_result = datetime.datetime(dt.year, dt.month, dt.day, 0, 0, 0, 0, tz)
        elif unit == "hour":
            dt_result = datetime.datetime(dt.year, dt.month, dt.day, dt.hour, 0, 0, 0, tz)
        elif unit == "minute":
            dt_result = datetime.datetime(dt.year, dt.month, dt.day, dt.hour, dt.minute, 0, 0, tz)
        elif unit == "second":
            dt_result = datetime.datetime(
                dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, 0, tz
            )
        elif unit == "millisecond":
            # Truncate microseconds to millisecond boundary
            ms = dt.microsecond // 1000 * 1000
            dt_result = datetime.datetime(
                dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, ms, tz
            )
        elif unit == "microsecond":
            # Keep existing datetime as-is (already at microsecond precision)
            dt_result = dt
        else:
            raise ValueError(f"Invalid unit for datetime truncation: {unit}")

        return CypherDateTime(dt_result)

    elif isinstance(temporal, CypherDate):
        date_val = temporal.value

        date_result: datetime.date
        if unit in (
            "millennium",
            "century",
            "decade",
            "year",
            "weekyear",
            "quarter",
            "month",
            "week",
            "day",
        ):
            date_result = _truncate_date(date_val)
        else:
            raise TypeError(
                f"Cannot truncate date to {unit}. "
                "Date only supports truncation to: millennium, century, decade, year, "
                "weekYear, quarter, month, week, day"
            )

        return CypherDate(date_result)

    elif isinstance(temporal, CypherTime):
        time_val = temporal.value
        tz = time_val.tzinfo

        time_result: datetime.time
        if unit == "hour":
            time_result = datetime.time(time_val.hour, 0, 0, 0, tz)
        elif unit == "minute":
            time_result = datetime.time(time_val.hour, time_val.minute, 0, 0, tz)
        elif unit == "second":
            time_result = datetime.time(time_val.hour, time_val.minute, time_val.second, 0, tz)
        elif unit == "millisecond":
            # Truncate microseconds to millisecond boundary
            ms = time_val.microsecond // 1000 * 1000
            time_result = datetime.time(time_val.hour, time_val.minute, time_val.second, ms, tz)
        elif unit == "microsecond":
            # Keep existing time as-is (already at microsecond precision)
            time_result = time_val
        else:
            raise TypeError(
                f"Cannot truncate time to {unit}. "
                "Time only supports truncation to: hour, minute, second, millisecond, microsecond"
            )

        return CypherTime(time_result)

    else:
        raise TypeError(
            f"Cannot truncate {type(temporal).__name__}, "
            "expected CypherDateTime, CypherDate, or CypherTime"
        )


def _evaluate_simple_exists(
    expr: "SubqueryExpression", ctx: ExecutionContext, executor: Any
) -> CypherValue:
    """
    Evaluate a simple pattern EXISTS expression against the graph.

    Scans for at least one match of the pattern in expr.pattern_parts using ctx.bindings as
    the outer scope. Supports a bound or unbound source variable, label and relationship-type
    filtering, fixed- and variable-length hops (with optional relationship predicates), and
    enforces equality constraints for variables already bound in the outer context. If a WHERE
    predicate is provided, a match must also satisfy that predicate to be considered successful.

    Parameters:
        expr (SubqueryExpression): A subquery expression whose pattern_parts describe the path
            pattern and optional WHERE predicate.
        ctx (ExecutionContext): Execution context providing outer variable bindings and
            deleted-entity tracking.
        executor (Any): Executor providing graph access and planning utilities (used to
            enumerate nodes/edges and execute reachability checks).

    Returns:
        CypherBool: `CypherBool(True)` if a matching path exists (and satisfies WHERE when
        present), `CypherBool(False)` otherwise; returns `CypherNull()` when the pattern's
        source variable is bound to `NULL` in the outer context.
    """
    from graphforge.ast.pattern import NodePattern, RelationshipPattern
    from graphforge.types import CypherNull
    from graphforge.types.graph import NodeRef

    parts = expr.pattern_parts
    if not parts or not isinstance(parts[0], NodePattern):
        return CypherBool(False)

    src_pattern = parts[0]
    src_var = src_pattern.variable

    # Build list of seed contexts: one per candidate source node
    # If source is bound in outer context, start from that node only
    # Otherwise, scan all nodes with matching labels
    # _cur_node is a sentinel key used to carry the traversal's current node
    # through anonymous node patterns that have no variable name.
    _cur = "_cur_node"

    seed_bindings: list[dict] = []
    if src_var and src_var in ctx.bindings:
        src_node = ctx.get(src_var)
        if isinstance(src_node, CypherNull):
            return CypherNull()
        if isinstance(src_node, NodeRef):
            # Validate src labels if the pattern specifies them
            if src_pattern.labels:
                if not all(
                    lbl in src_node.labels for lbl_group in src_pattern.labels for lbl in lbl_group
                ):
                    return CypherBool(False)
            seed_bindings.append({src_var: src_node, _cur: src_node})
    else:
        # Unbound source — scan all nodes
        for node in executor.graph.get_all_nodes():
            if src_pattern.labels:
                if not all(
                    lbl in node.labels for lbl_group in src_pattern.labels for lbl in lbl_group
                ):
                    continue
            binding: dict = {_cur: node}
            if src_var:
                binding[src_var] = node
            seed_bindings.append(binding)

    hop_count = (len(parts) - 1) // 2

    def _extend_hop(current_bindings: list[dict], hop_idx: int) -> list[dict]:
        """
        Extend each path binding by performing the pattern hop at hop_idx and return the
        resulting binding dictionaries.

        For each input binding this evaluates the hop source (preferring a named source
        variable, falling back to the current-path sentinel) and, when the source is a node,
        produces new bindings for each matching traversal target. Enforces relationship
        direction and type filters, destination node label constraints, and equality with any
        already-bound destination variable in either the outer execution context or the current
        path. Supports fixed-length and variable-length relationship patterns. Returns an empty
        list if the hop does not apply (for example when the corresponding pattern element is
        not a relationship) or no extensions are found.

        Returns:
            list[dict]: New list of binding dictionaries extended with any bound relationship,
            destination node, and updated current-path sentinel entries produced by this hop.
        """
        rel_pattern = parts[1 + hop_idx * 2]
        dst_pattern = parts[2 + hop_idx * 2]
        if not isinstance(rel_pattern, RelationshipPattern):
            return []

        dir_val = (
            rel_pattern.direction
            if isinstance(rel_pattern.direction, str)
            else rel_pattern.direction.value
        )
        rel_var = rel_pattern.variable
        dst_var = dst_pattern.variable

        result_bindings: list[dict] = []
        for bindings in current_bindings:
            # Resolve current node: prefer named variable, fall back to _cur sentinel
            src_pat_for_hop = parts[hop_idx * 2]
            src_v = src_pat_for_hop.variable if hasattr(src_pat_for_hop, "variable") else None
            if src_v and src_v in bindings:
                node = bindings[src_v]
            elif _cur in bindings:
                node = bindings[_cur]
            else:
                continue

            if not isinstance(node, NodeRef):
                continue

            # Handle var-length hop
            if rel_pattern.min_hops is not None or rel_pattern.max_hops is not None:
                min_h = rel_pattern.min_hops if rel_pattern.min_hops is not None else 1
                max_h = rel_pattern.max_hops
                _rel_pred2 = getattr(rel_pattern, "predicate", None)
                _rel_var2 = getattr(rel_pattern, "variable", None)
                if _rel_pred2 is not None and _rel_var2 is None:
                    _rel_var2 = _infer_rel_var_from_predicate(_rel_pred2)
                reachable = _var_length_reachable(
                    executor,
                    node,
                    rel_pattern.types or [],
                    dir_val,
                    min_h,
                    max_h,
                    rel_predicate=_rel_pred2,
                    rel_var=_rel_var2,
                    base_ctx=ctx,
                )
                for dst_node in reachable:
                    if dst_pattern.labels:
                        if not all(
                            lbl in dst_node.labels
                            for lbl_group in dst_pattern.labels
                            for lbl in lbl_group
                        ):
                            continue
                    if dst_var and dst_var in ctx.bindings:
                        bound = ctx.bindings[dst_var]
                        if isinstance(bound, NodeRef) and bound.id != dst_node.id:
                            continue
                    elif dst_var and dst_var in bindings:
                        existing = bindings[dst_var]
                        if isinstance(existing, NodeRef) and existing.id != dst_node.id:
                            continue
                    new_bindings = dict(bindings)
                    new_bindings[_cur] = dst_node
                    if dst_var:
                        new_bindings[dst_var] = dst_node
                    result_bindings.append(new_bindings)
                continue

            if dir_val == "OUT":
                edges = executor.graph.get_outgoing_edges(node.id)
            elif dir_val == "IN":
                edges = executor.graph.get_incoming_edges(node.id)
            else:
                outgoing = executor.graph.get_outgoing_edges(node.id)
                incoming = executor.graph.get_incoming_edges(node.id)
                seen_ids: set = set()
                edges = []
                for e in outgoing + incoming:
                    if e.id not in seen_ids:
                        edges.append(e)
                        seen_ids.add(e.id)

            if rel_pattern.types:
                edges = [e for e in edges if e.type in rel_pattern.types]

            for edge in edges:
                if dir_val == "OUT":
                    dst_id = edge.dst.id
                elif dir_val == "IN":
                    dst_id = edge.src.id
                else:
                    dst_id = edge.dst.id if edge.src.id == node.id else edge.src.id

                dst_node = executor.graph.get_node(dst_id)
                if dst_node is None:
                    continue

                # Check dst labels
                if dst_pattern.labels:
                    if not all(
                        lbl in dst_node.labels
                        for lbl_group in dst_pattern.labels
                        for lbl in lbl_group
                    ):
                        continue

                # If dst is bound in outer context, enforce equality
                if dst_var and dst_var in ctx.bindings:
                    bound = ctx.bindings[dst_var]
                    if isinstance(bound, NodeRef) and bound.id != dst_id:
                        continue
                # If dst is already bound in current path, enforce equality
                elif dst_var and dst_var in bindings:
                    existing = bindings[dst_var]
                    if isinstance(existing, NodeRef) and existing.id != dst_id:
                        continue

                new_bindings = dict(bindings)
                if rel_var:
                    new_bindings[rel_var] = edge
                new_bindings[_cur] = dst_node
                if dst_var:
                    new_bindings[dst_var] = dst_node
                result_bindings.append(new_bindings)

        return result_bindings

    # Extend through each hop
    current = seed_bindings
    for hop_idx in range(hop_count):
        current = _extend_hop(current, hop_idx)
        if not current:
            return CypherBool(False)

    # Apply WHERE predicate if present
    if expr.where_predicate is None:
        return CypherBool(bool(current))

    for bindings in current:
        # Build evaluation context: outer ctx bindings + path bindings
        merged = dict(ctx.bindings)
        merged.update(bindings)
        eval_ctx = ExecutionContext()
        eval_ctx.bindings = merged
        val = evaluate_expression(expr.where_predicate, eval_ctx, executor)
        if isinstance(val, CypherBool) and val.value:
            return CypherBool(True)

    return CypherBool(False)


def _evaluate_pattern_predicate(
    expr: "PatternPredicate", ctx: ExecutionContext, executor: Any
) -> CypherValue:
    """
    Determine whether the pattern predicate matches any complete path starting from the
    resolved source node.

    Resolves the source from the first pattern part (a bound node variable or an expression).
    Traverses each hop in the pattern applying relationship direction, type filters, var-length
    reachability, destination label filters, and bound-variable equality checks; returns as
    soon as any full path is found.

    Returns:
        CypherBool: `CypherBool(True)` if any complete path matching the pattern exists from
        the resolved source, `CypherBool(False)` if none exists, `CypherNull()` if the resolved
        source evaluates to `CypherNull`.

    Raises:
        TypeError: if `executor` is not provided.
    """
    from graphforge.ast.pattern import NodePattern, RelationshipPattern
    from graphforge.types import CypherNull
    from graphforge.types.graph import NodeRef as _NodeRef

    if executor is None:
        raise TypeError("PatternPredicate requires executor parameter")

    parts = expr.parts
    if len(parts) < 3:
        return CypherBool(False)

    src_pattern = parts[0]
    # src_pattern is either a NodePattern (legacy) or a generic expression
    # (after grammar restructuring to avoid LALR ambiguity with parenthesized_expr)
    if isinstance(src_pattern, NodePattern):
        src_var = src_pattern.variable
        if src_var is None:
            return CypherBool(False)
        if src_var not in ctx.bindings:
            return CypherBool(False)
        src_node = ctx.get(src_var)
        if isinstance(src_node, _NodeRef) and src_pattern.labels:
            if not all(
                lbl in src_node.labels for lbl_group in src_pattern.labels for lbl in lbl_group
            ):
                return CypherBool(False)
    else:
        from graphforge.ast.expression import Variable as ASTVariable

        if isinstance(src_pattern, ASTVariable) and src_pattern.name not in ctx.bindings:
            return CypherBool(False)
        src_node = evaluate_expression(src_pattern, ctx, executor)
    if isinstance(src_node, CypherNull):
        return CypherNull()

    # Traverse each hop checking existence
    # We DFS through all hops; any complete path → True
    current_nodes = [src_node]

    hop_count = (len(parts) - 1) // 2
    for hop_idx in range(hop_count):
        rel_pattern = parts[1 + hop_idx * 2]
        dst_pattern = parts[2 + hop_idx * 2]

        if not isinstance(rel_pattern, RelationshipPattern):
            return CypherBool(False)

        next_nodes = []
        for node in current_nodes:
            from graphforge.types.graph import NodeRef

            if not isinstance(node, NodeRef):
                continue

            dir_val = (
                rel_pattern.direction
                if isinstance(rel_pattern.direction, str)
                else rel_pattern.direction.value
            )

            if dir_val == "OUT":
                edges = executor.graph.get_outgoing_edges(node.id)
            elif dir_val == "IN":
                edges = executor.graph.get_incoming_edges(node.id)
            else:
                outgoing = executor.graph.get_outgoing_edges(node.id)
                incoming = executor.graph.get_incoming_edges(node.id)
                seen = set()
                edges = []
                for e in outgoing + incoming:
                    if e.id not in seen:
                        edges.append(e)
                        seen.add(e.id)

            # Filter by type
            if rel_pattern.types:
                edges = [e for e in edges if e.type in rel_pattern.types]

            # Filter by var-length range
            if rel_pattern.min_hops is not None or rel_pattern.max_hops is not None:
                min_h = rel_pattern.min_hops if rel_pattern.min_hops is not None else 1
                max_h = rel_pattern.max_hops  # None = unbounded
                _rel_pred = getattr(rel_pattern, "predicate", None)
                _rel_var = getattr(rel_pattern, "variable", None)
                # If the pattern has no named variable but has a predicate (e.g.
                # [:LINK* WHERE r.weight > 0]), infer the variable name from the predicate.
                if _rel_pred is not None and _rel_var is None:
                    _rel_var = _infer_rel_var_from_predicate(_rel_pred)
                reachable = _var_length_reachable(
                    executor,
                    node,
                    rel_pattern.types,
                    dir_val,
                    min_h,
                    max_h,
                    rel_predicate=_rel_pred,
                    rel_var=_rel_var,
                    base_ctx=ctx,
                )
                for r_node in reachable:
                    # Apply dst label filter
                    if dst_pattern.labels:
                        if not all(
                            lbl in r_node.labels
                            for lbl_group in dst_pattern.labels
                            for lbl in lbl_group
                        ):
                            continue
                    # If dst is a bound variable, only accept paths reaching that exact node
                    if dst_pattern.variable and dst_pattern.variable in ctx.bindings:
                        bound_dst = ctx.bindings[dst_pattern.variable]
                        if not isinstance(bound_dst, NodeRef):
                            # Bound to NULL or non-node — no path can match
                            continue
                        if bound_dst.id != r_node.id:
                            continue
                    next_nodes.append(r_node)
                continue

            for edge in edges:
                dst_id = (
                    edge.dst.id
                    if dir_val == "OUT"
                    else (
                        edge.src.id
                        if dir_val == "IN"
                        else (edge.dst.id if edge.src.id == node.id else edge.src.id)
                    )
                )
                dst_node = executor.graph.get_node(dst_id)
                if dst_node is None:
                    continue

                # Evaluate inline relationship predicate (e.g. [r:T WHERE r.prop > 0])
                rel_pred = getattr(rel_pattern, "predicate", None)
                if rel_pred is not None:
                    rel_var = getattr(rel_pattern, "variable", None)
                    if rel_var is None:
                        rel_var = _infer_rel_var_from_predicate(rel_pred)
                    if rel_var is not None:
                        pred_ctx = ExecutionContext()
                        pred_ctx.bindings = dict(ctx.bindings)
                        pred_ctx.aggregate_cache = ctx.aggregate_cache
                        pred_ctx.bind(rel_var, edge)
                    else:
                        pred_ctx = ctx
                    pred_val = evaluate_expression(rel_pred, pred_ctx, executor)
                    if not isinstance(pred_val, CypherBool) or not pred_val.value:
                        continue

                # Check destination labels/properties
                if dst_pattern.labels:
                    if not all(
                        lbl in dst_node.labels
                        for lbl_group in dst_pattern.labels
                        for lbl in lbl_group
                    ):
                        continue

                # Check if dst is a bound variable — must match exactly
                if dst_pattern.variable and dst_pattern.variable in ctx.bindings:
                    bound_dst = ctx.bindings[dst_pattern.variable]
                    if not isinstance(bound_dst, NodeRef):
                        continue
                    if bound_dst.id != dst_id:
                        continue

                next_nodes.append(dst_node)

        if not next_nodes:
            return CypherBool(False)
        current_nodes = next_nodes

    return CypherBool(True)


def _infer_rel_var_from_predicate(predicate: Any) -> str | None:
    """Return the first variable name referenced in a relationship predicate.

    Used when a pattern has an anonymous rel variable (e.g. [:LINK* WHERE r.weight > 0])
    but the predicate still references a name.  We walk the full predicate tree and return
    the first PropertyAccess or Variable name found.
    """
    from graphforge.ast.expression import CaseExpression, FunctionCall, PropertyAccess, Variable

    if isinstance(predicate, PropertyAccess):
        return predicate.variable
    if isinstance(predicate, Variable):
        return predicate.name
    # Recurse into scalar child fields
    for attr in ("left", "right", "operand", "expression", "condition", "subject", "else_expr"):
        child = getattr(predicate, attr, None)
        if child is not None:
            result = _infer_rel_var_from_predicate(child)
            if result is not None:
                return result
    # Walk list-valued fields: FunctionCall.args, CaseExpression.when_clauses
    if isinstance(predicate, FunctionCall):
        for arg in predicate.args:
            result = _infer_rel_var_from_predicate(arg)
            if result is not None:
                return result
    if isinstance(predicate, CaseExpression):
        for cond, res in predicate.when_clauses:
            for child in (cond, res):
                result = _infer_rel_var_from_predicate(child)
                if result is not None:
                    return result
    return None


def _var_length_reachable(
    executor: Any,
    start: Any,
    edge_types: list[str],
    direction: str,
    min_hops: int,
    max_hops: int | None,
    rel_predicate: Any = None,
    rel_var: str | None = None,
    base_ctx: Any = None,
) -> list[Any]:
    """BFS to find nodes reachable within [min_hops, max_hops] for pattern predicate.

    Uses relationship uniqueness per openCypher spec: each edge may appear at most
    once in a path, but nodes may repeat.

    Args:
        rel_predicate: Optional WHERE predicate on the relationship (e.g. r.weight > 0).
                       Evaluated per edge; edges failing the predicate are not followed.
        rel_var: Name to bind each edge to when evaluating rel_predicate.
        base_ctx: ExecutionContext from the calling site, used as the base for predicate
                  evaluation so that outer variables remain in scope.
    """
    result = []
    # Stack: (node, depth, used_edge_ids)
    stack: list[tuple[Any, int, set]] = [(start, 0, set())]
    while stack:
        node, depth, used_edge_ids = stack.pop()
        if min_hops <= depth:
            result.append(node)
        if max_hops is not None and depth >= max_hops:
            continue

        if direction == "OUT":
            edges = executor.graph.get_outgoing_edges(node.id)
        elif direction == "IN":
            edges = executor.graph.get_incoming_edges(node.id)
        else:
            outgoing = executor.graph.get_outgoing_edges(node.id)
            incoming = executor.graph.get_incoming_edges(node.id)
            seen_ids: set = set()
            edges = []
            for e in outgoing + incoming:
                if e.id not in seen_ids:
                    edges.append(e)
                    seen_ids.add(e.id)

        if edge_types:
            edges = [e for e in edges if e.type in edge_types]

        for edge in edges:
            if edge.id in used_edge_ids:
                continue

            # Evaluate inline relationship predicate (e.g. [r* WHERE r.weight > 0])
            if rel_predicate is not None:
                from graphforge.executor.evaluator import evaluate_expression
                from graphforge.executor.executor import ExecutionContext

                pred_ctx = ExecutionContext()
                if base_ctx is not None:
                    pred_ctx.bindings = dict(base_ctx.bindings)
                if rel_var:
                    pred_ctx.bind(rel_var, edge)
                pred_result = evaluate_expression(rel_predicate, pred_ctx, executor)
                from graphforge.types.values import CypherBool

                if not (isinstance(pred_result, CypherBool) and pred_result.value):
                    continue

            if direction == "IN":
                nxt_id = edge.src.id
            elif direction == "OUT":
                nxt_id = edge.dst.id
            else:
                nxt_id = edge.dst.id if edge.src.id == node.id else edge.src.id

            nxt_node = executor.graph.get_node(nxt_id)
            if nxt_node:
                stack.append((nxt_node, depth + 1, used_edge_ids | {edge.id}))

    return result


def _evaluate_function(
    func_call: FunctionCall, ctx: ExecutionContext, executor: Any = None
) -> CypherValue:
    """Evaluate scalar function calls.

    Args:
        func_call: Function call AST node
        ctx: Execution context with variable bindings

    Returns:
        CypherValue result of the function

    Raises:
        ValueError: If function is unknown
        TypeError: If function arguments have invalid types
    """
    func_name = func_call.name.upper()

    # Check for custom registered functions first
    if (
        executor
        and hasattr(executor, "custom_functions")
        and func_name in executor.custom_functions
    ):
        from typing import cast

        custom_func = executor.custom_functions[func_name]
        # Evaluate arguments
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        # Call the custom function
        result = custom_func(args, ctx, executor)
        return cast(CypherValue, result)

    # COALESCE is special - it doesn't propagate NULL, returns first non-NULL value
    if func_name == "COALESCE":
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        for arg in args:
            if not isinstance(arg, CypherNull):
                return arg
        return CypherNull()

    # LENGTH is overloaded - works for both strings and paths
    if func_name == "LENGTH":
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if isinstance(arg, CypherPath):
            return _evaluate_path_function(func_name, args)
        if isinstance(arg, CypherString):
            return _evaluate_string_function(func_name, args)
        raise TypeError(f"LENGTH expects string or path argument, got {type(arg).__name__}")

    # HEAD is overloaded - works for both lists and paths
    if func_name == "HEAD":
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if isinstance(arg, CypherPath):
            return _evaluate_path_function(func_name, args)
        if isinstance(arg, CypherList):
            return _evaluate_list_function(func_name, args)
        raise TypeError(f"HEAD expects list or path argument, got {type(arg).__name__}")

    # LAST is overloaded - works for both lists and paths
    if func_name == "LAST":
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if isinstance(arg, CypherPath):
            return _evaluate_path_function(func_name, args)
        if isinstance(arg, CypherList):
            return _evaluate_list_function(func_name, args)
        raise TypeError(f"LAST expects list or path argument, got {type(arg).__name__}")

    # REVERSE is overloaded - works for both lists and strings
    if func_name == "REVERSE":
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if isinstance(arg, CypherList):
            return _evaluate_list_function(func_name, args)
        if isinstance(arg, CypherString):
            return _evaluate_string_function(func_name, args)
        raise TypeError(f"REVERSE expects list or string argument, got {type(arg).__name__}")

    # Graph functions need special handling for NodeRef/EdgeRef arguments
    if func_name in GRAPH_FUNCTIONS:
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        return _evaluate_graph_function(func_name, args, ctx)

    # Path functions need special handling for CypherPath arguments
    if func_name in PATH_FUNCTIONS:
        args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]
        return _evaluate_path_function(func_name, args)

    # EXISTS function for property existence checking
    # Must be evaluated BEFORE NULL propagation to handle property access correctly
    if func_name == "EXISTS":
        if len(func_call.args) != 1:
            raise ValueError("EXISTS expects exactly one argument")

        arg_expr = func_call.args[0]
        result = evaluate_expression(arg_expr, ctx, executor)
        return CypherBool(not isinstance(result, CypherNull))

    # Evaluate arguments
    args = [evaluate_expression(arg, ctx, executor) for arg in func_call.args]

    # NULL propagation: if any arg is NULL, return NULL (for most functions)
    if any(isinstance(arg, CypherNull) for arg in args):
        return CypherNull()

    # SIZE function for lists and strings
    if func_name == "SIZE":
        arg = args[0]
        if isinstance(arg, (CypherList, CypherString)):
            return CypherInt(len(arg.value))
        raise TypeError(f"SIZE expects list or string, got {type(arg).__name__}")

    # ISEMPTY function for lists, strings, and maps
    if func_name == "ISEMPTY":
        if len(args) == 0:
            raise TypeError("ISEMPTY expects exactly one argument")
        arg = args[0]
        if isinstance(arg, (CypherList, CypherString, CypherMap)):
            return CypherBool(len(arg.value) == 0)
        raise TypeError(f"ISEMPTY expects list, string, or map, got {type(arg).__name__}")

    # Dispatch to specific function handlers
    if func_name in STRING_FUNCTIONS:
        return _evaluate_string_function(func_name, args)
    elif func_name in LIST_FUNCTIONS:
        return _evaluate_list_function(func_name, args)
    elif func_name in MATH_FUNCTIONS:
        return _evaluate_math_function(func_name, args)
    elif func_name in TYPE_FUNCTIONS:
        return _evaluate_type_function(func_name, args)
    elif func_name in TEMPORAL_FUNCTIONS:
        return _evaluate_temporal_function(func_name, args, executor)
    elif func_name in SPATIAL_FUNCTIONS:
        return _evaluate_spatial_function(func_name, args)
    elif "." in func_name:
        return _evaluate_namespaced_function(func_name, args)
    else:
        raise ValueError(f"Unknown function: {func_name}")


def _evaluate_string_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate string functions.

    Args:
        func_name: Name of the string function (uppercase)
        args: List of evaluated arguments (non-NULL)

    Returns:
        CypherValue result of the string function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    # Normalize aliases to canonical names
    func_name = STRING_FUNCTION_ALIASES.get(func_name, func_name)

    if func_name == "LENGTH":
        # LENGTH(string) -> int
        if not isinstance(args[0], CypherString):
            raise TypeError(f"LENGTH expects string, got {type(args[0]).__name__}")
        return CypherInt(len(args[0].value))

    elif func_name == "SUBSTRING":
        # SUBSTRING(string, start) or SUBSTRING(string, start, length)
        if not isinstance(args[0], CypherString):
            raise TypeError(f"SUBSTRING expects string, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherInt):
            raise TypeError("SUBSTRING start must be integer")

        string = args[0].value
        start = args[1].value

        # Validate start is non-negative (openCypher requirement)
        if start < 0:
            raise TypeError("SUBSTRING start must be non-negative")

        if len(args) == 3:
            if not isinstance(args[2], CypherInt):
                raise TypeError("SUBSTRING length must be integer")
            length = args[2].value
            # Validate length is non-negative (openCypher requirement)
            if length < 0:
                raise TypeError("SUBSTRING length must be non-negative")
            return CypherString(string[start : start + length])
        else:
            return CypherString(string[start:])

    elif func_name == "UPPER":
        if not isinstance(args[0], CypherString):
            raise TypeError(f"UPPER expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value.upper())

    elif func_name == "LOWER":
        if not isinstance(args[0], CypherString):
            raise TypeError(f"LOWER expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value.lower())

    elif func_name == "TRIM":
        if not isinstance(args[0], CypherString):
            raise TypeError(f"TRIM expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value.strip())

    elif func_name == "REVERSE":
        if not isinstance(args[0], CypherString):
            raise TypeError(f"REVERSE expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value[::-1])

    elif func_name == "SPLIT":
        # SPLIT(string, delimiter) -> list of strings
        if len(args) != 2:
            raise TypeError(f"SPLIT expects 2 arguments, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(f"SPLIT expects string as first argument, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherString):
            raise TypeError(f"SPLIT expects string as delimiter, got {type(args[1]).__name__}")

        string = args[0].value
        delimiter = args[1].value

        # Empty delimiter: split into individual characters per openCypher spec
        if delimiter == "":
            parts = list(string)
        else:
            parts = string.split(delimiter)
        return CypherList([CypherString(part) for part in parts])

    elif func_name == "REPLACE":
        # REPLACE(string, search, replacement) -> string
        if len(args) != 3:
            raise TypeError(f"REPLACE expects 3 arguments, got {len(args)}")
        if not isinstance(args[0], CypherString):
            arg_type = type(args[0]).__name__
            raise TypeError(f"REPLACE expects string as first argument, got {arg_type}")
        if not isinstance(args[1], CypherString):
            arg_type = type(args[1]).__name__
            raise TypeError(f"REPLACE expects string as search argument, got {arg_type}")
        if not isinstance(args[2], CypherString):
            arg_type = type(args[2]).__name__
            raise TypeError(f"REPLACE expects string as replacement argument, got {arg_type}")

        string = args[0].value
        search = args[1].value
        replacement = args[2].value

        # Replace all occurrences
        result = string.replace(search, replacement)
        return CypherString(result)

    elif func_name == "LEFT":
        # LEFT(string, length) -> string
        if len(args) != 2:
            raise TypeError(f"LEFT expects 2 arguments, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(f"LEFT expects string as first argument, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherInt):
            raise TypeError(f"LEFT expects integer as length, got {type(args[1]).__name__}")

        string = args[0].value
        length = args[1].value

        # Negative length returns empty string (openCypher behavior)
        if length < 0:
            return CypherString("")

        return CypherString(string[:length])

    elif func_name == "RIGHT":
        # RIGHT(string, length) -> string
        if len(args) != 2:
            raise TypeError(f"RIGHT expects 2 arguments, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(f"RIGHT expects string as first argument, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherInt):
            raise TypeError(f"RIGHT expects integer as length, got {type(args[1]).__name__}")

        string = args[0].value
        length = args[1].value

        # Negative or zero length returns empty string (openCypher behavior)
        if length <= 0:
            return CypherString("")

        # If length exceeds string length, return entire string
        if length >= len(string):
            return CypherString(string)

        return CypherString(string[-length:])

    elif func_name == "LTRIM":
        # LTRIM(string) -> string (remove leading whitespace)
        if len(args) != 1:
            raise TypeError(f"LTRIM expects 1 argument, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(f"LTRIM expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value.lstrip())

    elif func_name == "RTRIM":
        # RTRIM(string) -> string (remove trailing whitespace)
        if len(args) != 1:
            raise TypeError(f"RTRIM expects 1 argument, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(f"RTRIM expects string, got {type(args[0]).__name__}")
        return CypherString(args[0].value.rstrip())

    raise ValueError(f"Unknown string function: {func_name}")


def _evaluate_math_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate math functions.

    Args:
        func_name: Name of the math function (uppercase)
        args: List of evaluated arguments (non-NULL)

    Returns:
        CypherValue result of the math function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    import math

    if func_name == "ABS":
        # ABS(number) -> number
        if len(args) != 1:
            raise TypeError(f"ABS expects 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, CypherInt):
            return CypherInt(abs(arg.value))
        elif isinstance(arg, CypherFloat):
            return CypherFloat(abs(arg.value))
        else:
            raise TypeError(f"ABS expects numeric argument, got {type(arg).__name__}")

    elif func_name == "CEIL":
        # CEIL(number) -> int (returns smallest integer >= number)
        if len(args) != 1:
            raise TypeError(f"CEIL expects 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, CypherInt):
            return arg  # Integer ceiling is itself
        elif isinstance(arg, CypherFloat):
            return CypherInt(math.ceil(arg.value))
        else:
            raise TypeError(f"CEIL expects numeric argument, got {type(arg).__name__}")

    elif func_name == "FLOOR":
        # FLOOR(number) -> int (returns largest integer <= number)
        if len(args) != 1:
            raise TypeError(f"FLOOR expects 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, CypherInt):
            return arg  # Integer floor is itself
        elif isinstance(arg, CypherFloat):
            return CypherInt(math.floor(arg.value))
        else:
            raise TypeError(f"FLOOR expects numeric argument, got {type(arg).__name__}")

    elif func_name == "ROUND":
        # ROUND(number, [precision]) -> number
        # With 1 arg: rounds to nearest integer
        # With 2 args: rounds to specified decimal places
        # Uses Neo4j tie-breaking: ties (x.5) round toward positive infinity
        if len(args) not in (1, 2):
            raise TypeError(f"ROUND expects 1 or 2 arguments, got {len(args)}")

        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"ROUND expects numeric argument, got {type(arg).__name__}")

        # Epsilon for detecting tie cases (fractional part is ±0.5)
        eps = 1e-10
        precision = 0 if len(args) == 1 else args[1].value

        if len(args) == 2:
            precision_arg = args[1]
            if not isinstance(precision_arg, CypherInt):
                raise TypeError(
                    f"ROUND precision must be integer, got {type(precision_arg).__name__}"
                )
            precision = precision_arg.value

        if isinstance(arg, CypherInt):
            # For integers with non-negative precision, no rounding needed
            if precision >= 0:
                return arg
            # For negative precision, round to tens, hundreds, etc.
            value = arg.value
        else:
            value = arg.value

        # Scale value by 10^precision to move decimal point
        scale = 10**precision
        scaled = value * scale

        # Check if scaled value is a tie case (fractional part is ±0.5)
        frac = abs(scaled - math.floor(scaled))
        is_tie = abs(frac - 0.5) < eps

        if is_tie:
            # Tie case: round toward positive infinity (use ceil)
            rounded_scaled = math.ceil(scaled)
        else:
            # Non-tie case: standard rounding (add 0.5 and floor)
            rounded_scaled = math.floor(scaled + 0.5)

        result = rounded_scaled / scale

        # Return appropriate type
        if isinstance(arg, CypherInt) and precision >= 0:
            return CypherInt(int(result))
        elif len(args) == 1:
            # Single arg: return float
            return CypherFloat(result)
        else:
            return CypherFloat(result)

    elif func_name == "SIGN":
        # SIGN(number) -> int (-1, 0, or 1)
        if len(args) != 1:
            raise TypeError(f"SIGN expects 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, (CypherInt, CypherFloat)):
            value = arg.value
        else:
            raise TypeError(f"SIGN expects numeric argument, got {type(arg).__name__}")

        if value > 0:
            return CypherInt(1)
        elif value < 0:
            return CypherInt(-1)
        else:
            return CypherInt(0)

    elif func_name == "SQRT":
        # SQRT(number) -> float (square root)
        if len(args) != 1:
            raise TypeError(f"sqrt() requires 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError("sqrt() requires a numeric argument")
        val = arg.value
        if val < 0:
            return CypherNull()
        return CypherFloat(math.sqrt(val))

    elif func_name == "RAND":
        # RAND() -> float in [0.0, 1.0)
        if len(args) != 0:
            raise TypeError(f"rand() requires 0 arguments, got {len(args)}")
        import random

        return CypherFloat(random.random())  # nosec B311

    elif func_name == "POW":
        # POW(base, exponent) -> number
        if len(args) != 2:
            raise TypeError(f"pow() requires 2 arguments, got {len(args)}")
        left, right = args[0], args[1]
        if isinstance(left, CypherNull) or isinstance(right, CypherNull):
            return CypherNull()
        if not isinstance(left, (CypherInt, CypherFloat)):
            raise TypeError("pow() requires numeric arguments")
        if not isinstance(right, (CypherInt, CypherFloat)):
            raise TypeError("pow() requires numeric arguments")
        lv = left.value
        rv = right.value
        try:
            result = lv**rv
            if isinstance(result, complex) or (
                isinstance(result, float) and not math.isfinite(result)
            ):
                return CypherNull()
            if (
                isinstance(lv, int)
                and isinstance(rv, int)
                and rv >= 0
                and isinstance(result, (int, float))
                and float(result) == int(result)
            ):
                return CypherInt(int(result))
            return CypherFloat(float(result))
        except (OverflowError, ZeroDivisionError, ValueError):
            return CypherNull()

    elif func_name == "E":
        if len(args) != 0:
            raise TypeError(f"e() requires 0 arguments, got {len(args)}")
        return CypherFloat(math.e)

    elif func_name == "PI":
        if len(args) != 0:
            raise TypeError(f"pi() requires 0 arguments, got {len(args)}")
        return CypherFloat(math.pi)

    elif func_name == "EXP":
        if len(args) != 1:
            raise TypeError(f"exp() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"exp() requires a numeric argument, got {type(arg).__name__}")
        try:
            return CypherFloat(math.exp(arg.value))
        except OverflowError:
            return CypherNull()

    elif func_name == "LOG":
        if len(args) != 1:
            raise TypeError(f"log() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"log() requires a numeric argument, got {type(arg).__name__}")
        if arg.value <= 0:
            return CypherNull()
        return CypherFloat(math.log(arg.value))

    elif func_name == "LOG10":
        if len(args) != 1:
            raise TypeError(f"log10() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"log10() requires a numeric argument, got {type(arg).__name__}")
        if arg.value <= 0:
            return CypherNull()
        return CypherFloat(math.log10(arg.value))

    elif func_name == "SIN":
        if len(args) != 1:
            raise TypeError(f"sin() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"sin() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.sin(arg.value))

    elif func_name == "COS":
        if len(args) != 1:
            raise TypeError(f"cos() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"cos() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.cos(arg.value))

    elif func_name == "TAN":
        if len(args) != 1:
            raise TypeError(f"tan() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"tan() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.tan(arg.value))

    elif func_name == "COT":
        if len(args) != 1:
            raise TypeError(f"cot() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"cot() requires a numeric argument, got {type(arg).__name__}")
        t = math.tan(arg.value)
        if t == 0:
            return CypherNull()
        return CypherFloat(1.0 / t)

    elif func_name == "ASIN":
        if len(args) != 1:
            raise TypeError(f"asin() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"asin() requires a numeric argument, got {type(arg).__name__}")
        if not (-1.0 <= arg.value <= 1.0):
            return CypherNull()
        return CypherFloat(math.asin(arg.value))

    elif func_name == "ACOS":
        if len(args) != 1:
            raise TypeError(f"acos() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"acos() requires a numeric argument, got {type(arg).__name__}")
        if not (-1.0 <= arg.value <= 1.0):
            return CypherNull()
        return CypherFloat(math.acos(arg.value))

    elif func_name == "ATAN":
        if len(args) != 1:
            raise TypeError(f"atan() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"atan() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.atan(arg.value))

    elif func_name == "ATAN2":
        if len(args) != 2:
            raise TypeError(f"atan2() requires 2 arguments, got {len(args)}")
        y, x = args[0], args[1]
        if not isinstance(y, (CypherInt, CypherFloat)):
            raise TypeError(f"atan2() requires numeric arguments, got {type(y).__name__}")
        if not isinstance(x, (CypherInt, CypherFloat)):
            raise TypeError(f"atan2() requires numeric arguments, got {type(x).__name__}")
        return CypherFloat(math.atan2(y.value, x.value))

    elif func_name == "DEGREES":
        if len(args) != 1:
            raise TypeError(f"degrees() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"degrees() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.degrees(arg.value))

    elif func_name == "RADIANS":
        if len(args) != 1:
            raise TypeError(f"radians() requires 1 argument, got {len(args)}")
        arg = args[0]
        if not isinstance(arg, (CypherInt, CypherFloat)):
            raise TypeError(f"radians() requires a numeric argument, got {type(arg).__name__}")
        return CypherFloat(math.radians(arg.value))

    elif func_name == "TIMESTAMP":
        if len(args) != 0:
            raise TypeError(f"timestamp() requires 0 arguments, got {len(args)}")
        import time

        return CypherInt(int(time.time() * 1000))

    raise ValueError(f"Unknown math function: {func_name}")


def _evaluate_subscript(
    subscript: Subscript, ctx: ExecutionContext, executor: Any = None
) -> CypherValue:
    """Evaluate subscript/slice operations on lists.

    Args:
        subscript: Subscript AST node with base and index/start/end
        ctx: Execution context
        executor: Optional executor for nested expressions

    Returns:
        CypherValue result (element or sublist)

    Raises:
        TypeError: If base is not a list
    """
    # Evaluate the base expression
    base_val = evaluate_expression(subscript.base, ctx, executor)

    # NULL propagation: if base is NULL, return NULL
    if isinstance(base_val, CypherNull):
        return CypherNull()

    # Node/relationship subscript: node['key'] or rel['key'] — dynamic property access
    if isinstance(base_val, (NodeRef, EdgeRef)):
        if hasattr(ctx, "deleted_ids") and base_val.id in ctx.deleted_ids:
            raise EntityNotFoundError(
                "DeletedEntityAccess: Tried to access property of a deleted entity"
            )
        if subscript.index is None:
            raise TypeError("Node/relationship subscript does not support slice syntax")
        key_val = evaluate_expression(subscript.index, ctx, executor)
        if isinstance(key_val, CypherNull):
            return CypherNull()
        if not isinstance(key_val, CypherString):
            raise TypeError(
                f"Node/relationship subscript key must be a string, got {type(key_val).__name__}"
            )
        raw = base_val.properties.get(key_val.value)
        if raw is None:
            return CypherNull()
        return raw if isinstance(raw, CypherValue) else from_python(raw)

    # Map subscript: map['key']
    if isinstance(base_val, CypherMap):
        if subscript.index is None:
            raise TypeError("Map subscript does not support slice syntax")
        key_val = evaluate_expression(subscript.index, ctx, executor)
        if isinstance(key_val, CypherNull):
            return CypherNull()
        if not isinstance(key_val, CypherString):
            raise TypeError(f"Map subscript key must be a string, got {type(key_val).__name__}")
        map_result: CypherValue = base_val.value.get(key_val.value, CypherNull())
        return map_result

    # Base must be a list
    if not isinstance(base_val, CypherList):
        raise TypeError(f"Subscript operation requires list or map, got {type(base_val).__name__}")

    list_value = base_val.value

    # Handle index access: list[i]
    if subscript.index is not None:
        index_val = evaluate_expression(subscript.index, ctx, executor)

        # NULL index returns NULL
        if isinstance(index_val, CypherNull):
            return CypherNull()

        if not isinstance(index_val, CypherInt):
            raise TypeError(f"List index must be integer, got {type(index_val).__name__}")

        index = index_val.value

        # Python supports negative indices naturally
        # Out of bounds returns NULL per openCypher spec
        try:
            from typing import cast

            return cast(CypherValue, list_value[index])
        except IndexError:
            return CypherNull()

    # Handle slice access: list[start..end]
    else:
        # Evaluate start and end (may be None)
        start_val = (
            None if subscript.start is None else evaluate_expression(subscript.start, ctx, executor)
        )
        end_val = (
            None if subscript.end is None else evaluate_expression(subscript.end, ctx, executor)
        )

        # NULL in slice returns NULL
        if isinstance(start_val, CypherNull) or isinstance(end_val, CypherNull):
            return CypherNull()

        # Convert to Python slice indices
        start = None if start_val is None else start_val.value
        end = None if end_val is None else end_val.value

        # Validate types
        if start is not None and not isinstance(start_val, CypherInt):
            raise TypeError(f"Slice start must be integer, got {type(start_val).__name__}")
        if end is not None and not isinstance(end_val, CypherInt):
            raise TypeError(f"Slice end must be integer, got {type(end_val).__name__}")

        # Perform slice (Python's slicing handles negative indices and bounds automatically)
        # Note: openCypher slicing is exclusive on the end, same as Python
        result = list_value[start:end]
        return CypherList(result)


def _evaluate_type_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate type conversion and introspection functions.

    Args:
        func_name: Name of the type function
        args: List of evaluated arguments (non-NULL)

    Returns:
        CypherValue result of the type function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    # Arity validation: these functions take exactly one argument
    _one_arg_funcs = {"TOBOOLEAN", "TOINTEGER", "TOFLOAT", "TOSTRING"}
    if func_name in _one_arg_funcs:
        if len(args) != 1:
            raise TypeError(f"{func_name.lower()}() takes exactly 1 argument ({len(args)} given)")

    # Special handling for NULL in type conversions
    if isinstance(args[0], CypherNull):
        return CypherNull()

    if func_name == "TOBOOLEAN":
        arg = args[0]

        # Boolean → Boolean (identity)
        if isinstance(arg, CypherBool):
            return arg

        # String → Boolean (only "true"/"false" case-insensitive)
        elif isinstance(arg, CypherString):
            value_lower = arg.value.lower()
            if value_lower == "true":
                return CypherBool(True)
            elif value_lower == "false":
                return CypherBool(False)
            else:
                return CypherNull()  # Invalid string → null (not an error)

        # Invalid types → TypeError per openCypher spec
        # (float, list, map, node, relationship, path)
        else:
            raise TypeError(f"toBoolean() cannot convert {type(arg).__name__} to boolean")

    elif func_name == "TOINTEGER":
        arg = args[0]

        # Integer → Integer (identity)
        if isinstance(arg, CypherInt):
            return arg

        # Float → Integer (truncate)
        elif isinstance(arg, CypherFloat):
            return CypherInt(int(arg.value))

        # String → Integer (parse; try int() then int(float()) for decimal strings)
        elif isinstance(arg, CypherString):
            try:
                return CypherInt(int(arg.value))
            except ValueError:
                try:
                    return CypherInt(int(float(arg.value)))
                except (ValueError, OverflowError):
                    return CypherNull()  # Unparseable string → null

        # Boolean → null (not convertible per openCypher spec)
        elif isinstance(arg, CypherBool):
            return CypherNull()

        # Invalid types → TypeError per openCypher spec
        # (list, map, node, relationship, path)
        else:
            raise TypeError(f"toInteger() cannot convert {type(arg).__name__} to integer")

    elif func_name == "TOFLOAT":
        arg = args[0]

        # Float → Float (identity)
        if isinstance(arg, CypherFloat):
            return arg

        # Integer → Float
        elif isinstance(arg, CypherInt):
            return CypherFloat(float(arg.value))

        # String → Float (parse; unparseable → null)
        elif isinstance(arg, CypherString):
            try:
                return CypherFloat(float(arg.value))
            except ValueError:
                return CypherNull()

        # Invalid types → TypeError per openCypher spec
        # (boolean, list, map, node, relationship, path)
        else:
            raise TypeError(f"toFloat() cannot convert {type(arg).__name__} to float")

    elif func_name == "TOSTRING":
        arg = args[0]

        # String → String (identity)
        if isinstance(arg, CypherString):
            return arg

        # Integer/Float → String (decimal representation)
        elif isinstance(arg, (CypherInt, CypherFloat)):
            if isinstance(arg, CypherFloat) and math.isnan(arg.value):
                return CypherString("NaN")
            return CypherString(str(arg.value))

        # Boolean → String ("true"/"false")
        elif isinstance(arg, CypherBool):
            return CypherString("true" if arg.value else "false")

        # Temporal types → ISO 8601 string
        elif isinstance(arg, (CypherDate, CypherTime, CypherDateTime)):
            iso = arg.value.isoformat()
            ns_res = getattr(arg, "_ns_residue", 0)
            if ns_res and isinstance(arg, (CypherTime, CypherDateTime)):
                # Insert 3 extra nanosecond digits after the 6-digit microsecond fractional part
                # Python isoformat gives .XXXXXX; we append 3 more digits before any tz offset
                import re as _re

                def _insert_ns(s: str, ns: int) -> str:
                    """Insert nanosecond residue digits into an ISO time string."""
                    return _re.sub(
                        r"(\.\d{6})(Z|[+-]\d{2}:\d{2}(?::\d{2})?|$)",
                        lambda m: f"{m.group(1)}{ns:03d}{m.group(2)}",
                        s,
                    )

                iso = _insert_ns(iso, ns_res)
            return CypherString(iso)

        elif isinstance(arg, CypherDuration):
            return CypherString(_cypher_duration_isoformat(arg))

        # Null → Null
        elif isinstance(arg, CypherNull):
            return CypherNull()

        # Complex types (list, map, node, relationship, path) → TypeError
        else:
            raise TypeError(
                f"InvalidArgumentValue: toString() cannot convert {type(arg).__name__} to string"
            )

    elif func_name == "TYPE":
        if len(args) != 1:
            raise TypeError(f"type() takes exactly 1 argument ({len(args)} given)")
        # TYPE function: returns relationship type string for EdgeRef only
        arg = args[0]

        if isinstance(arg, CypherNull):
            return CypherNull()

        # EdgeRef (relationship) → its type string
        if hasattr(arg, "src") and hasattr(arg, "type"):
            edge_ref: EdgeRef = arg  # type: ignore[assignment]
            return CypherString(edge_ref.type)

        # Any other value → TypeError per openCypher spec
        raise TypeError(
            f"InvalidArgumentValue: type() requires a relationship, got {type(arg).__name__}"
        )

    raise ValueError(f"Unknown type function: {func_name}")


# Sentinel value to distinguish missing keys from explicit null
_MISSING = object()


def _parse_timezone_str(timezone: str):
    """Parse a timezone string, accepting both IANA names and ±HH:MM numeric offsets.

    Args:
        timezone: IANA name (e.g. 'Europe/Stockholm') or offset (e.g. '+01:00', '-08:00')

    Returns:
        tzinfo object

    Raises:
        ValueError: If the timezone string is not recognised
    """
    import datetime
    import re

    offset_match = re.match(r"^([+-])(\d{2}):(\d{2})(?::(\d{2}))?$", timezone)
    if offset_match:
        sign, hours_str, minutes_str, seconds_str = offset_match.groups()
        h, m, s = int(hours_str), int(minutes_str), int(seconds_str or 0)
        if h > 23 or m > 59 or s > 59:
            raise ValueError(f"Invalid timezone offset: {timezone}")
        total_seconds = (h * 3600 + m * 60 + s) * (1 if sign == "+" else -1)
        return datetime.timezone(datetime.timedelta(seconds=total_seconds))
    from dateutil import tz

    tzinfo = tz.gettz(timezone)
    if tzinfo is None:
        raise ValueError(f"Invalid timezone: {timezone}")
    return tzinfo


def _extract_map_param(map_val: CypherMap, key: str, default: Any = _MISSING) -> Any:
    """Extract a parameter from a CypherMap.

    Args:
        map_val: CypherMap containing parameters
        key: Parameter key to extract
        default: Default value if key not present

    Returns:
        - int for CypherInt/CypherFloat
        - str for CypherString
        - CypherNull for present-but-null values
        - default (or _MISSING sentinel) for absent keys
    """
    cypher_val = map_val.value.get(key)
    if cypher_val is None:
        return default
    if isinstance(cypher_val, CypherNull):
        return cypher_val  # Return CypherNull itself to distinguish from missing
    if isinstance(cypher_val, (CypherInt, CypherFloat)):
        # Coerce numeric values to int for datetime constructors
        return int(cypher_val.value)
    elif isinstance(cypher_val, CypherString):
        return cypher_val.value
    else:
        raise TypeError(
            f"Temporal map parameter '{key}' must be int, float, or string, "
            f"got {type(cypher_val).__name__}: {cypher_val}"
        )


def _get_temporal_property(
    obj: "CypherDate | CypherTime | CypherDateTime | CypherDuration", prop: str
) -> "CypherValue":
    """Return the named component property of a temporal CypherValue.

    Implements the openCypher temporal component accessors for date, time,
    datetime, localdatetime and duration values.
    """
    import datetime

    if isinstance(obj, (CypherDate, CypherDateTime)):
        from graphforge.types.values import _WideDate, _WideDateTime

        raw_val = obj.value
        # _WideDate/_WideDateTime: year/month/day are accessible but calendar
        # arithmetic (isocalendar, ordinalDay, epochDay) is undefined.
        if isinstance(raw_val, (_WideDate, _WideDateTime)):
            wide_basic: dict[str, CypherValue] = {
                "year": CypherInt(raw_val.year),
                "month": CypherInt(raw_val.month),
                "day": CypherInt(raw_val.day),
            }
            if prop in wide_basic:
                return wide_basic[prop]
            # Time properties for _WideDateTime
            if isinstance(raw_val, _WideDateTime) and isinstance(obj, CypherDateTime):
                ns_res = getattr(obj, "_ns_residue", 0)
                wide_time: dict[str, CypherValue] = {
                    "hour": CypherInt(raw_val.hour),
                    "minute": CypherInt(raw_val.minute),
                    "second": CypherInt(raw_val.second),
                    "millisecond": CypherInt(raw_val.microsecond // 1000),
                    "microsecond": CypherInt(raw_val.microsecond),
                    "nanosecond": CypherInt(raw_val.microsecond * 1000 + ns_res),
                }
                if prop in wide_time:
                    return wide_time[prop]
            return CypherNull()

        d = raw_val.date() if isinstance(obj, CypherDateTime) else raw_val
        iso = d.isocalendar()  # (iso_year, iso_week, iso_weekday)
        iso_year, iso_week, iso_weekday = iso
        year_start = datetime.date(d.year, 1, 1)
        ordinal_day = (d - year_start).days + 1
        # epoch day: days since 1970-01-01
        epoch_day = (d - datetime.date(1970, 1, 1)).days
        quarter = (d.month - 1) // 3 + 1
        q_start = datetime.date(d.year, (quarter - 1) * 3 + 1, 1)
        day_of_quarter = (d - q_start).days + 1
        date_props: dict[str, CypherValue] = {
            "year": CypherInt(d.year),
            "month": CypherInt(d.month),
            "day": CypherInt(d.day),
            "week": CypherInt(iso_week),
            "weekYear": CypherInt(iso_year),
            "weekDay": CypherInt(iso_weekday),
            "dayOfWeek": CypherInt(iso_weekday),
            "quarter": CypherInt(quarter),
            "dayOfQuarter": CypherInt(day_of_quarter),
            "ordinalDay": CypherInt(ordinal_day),
            "epochDay": CypherInt(epoch_day),
        }
        if prop in date_props:
            return date_props[prop]
        if not isinstance(obj, CypherDateTime):
            return CypherNull()

    if isinstance(obj, (CypherTime, CypherDateTime)):
        t = obj.value.timetz() if isinstance(obj, CypherDateTime) else obj.value
        millisecond = t.microsecond // 1000
        microsecond = t.microsecond
        nanosecond = t.microsecond * 1000 + getattr(obj, "_ns_residue", 0)
        tz = t.tzinfo
        timezone_str: str | None = None
        offset_secs: int | None = None
        offset_mins: int | None = None
        if tz is not None:
            # For IANA zones, utcoffset(None) returns None; pass the datetime for DST lookup
            _dt_for_offset = obj.value if isinstance(obj, CypherDateTime) else None
            utc_off = tz.utcoffset(_dt_for_offset)
            if utc_off is not None:
                total_secs = int(utc_off.total_seconds())
                offset_secs = total_secs
                offset_mins = total_secs // 60
                sign = "+" if total_secs >= 0 else "-"
                abs_secs = abs(total_secs)
                h = abs_secs // 3600
                m = (abs_secs % 3600) // 60
                s = abs_secs % 60
                if s:
                    timezone_str = f"{sign}{h:02d}:{m:02d}:{s:02d}"
                else:
                    timezone_str = f"{sign}{h:02d}:{m:02d}"
        # For datetime, prefer the stored IANA name for .timezone accessor
        iana_name = getattr(obj, "_iana_tz_name", None) if isinstance(obj, CypherDateTime) else None
        tz_display = iana_name if iana_name is not None else timezone_str
        time_props: dict[str, CypherValue] = {
            "hour": CypherInt(t.hour),
            "minute": CypherInt(t.minute),
            "second": CypherInt(t.second),
            "millisecond": CypherInt(millisecond),
            "microsecond": CypherInt(microsecond),
            "nanosecond": CypherInt(nanosecond),
            "timezone": CypherString(tz_display) if tz_display is not None else CypherNull(),
            "offset": CypherString(timezone_str) if timezone_str is not None else CypherNull(),
            "offsetSeconds": CypherInt(offset_secs) if offset_secs is not None else CypherNull(),
            "offsetMinutes": CypherInt(offset_mins) if offset_mins is not None else CypherNull(),
            "epochMillis": CypherNull(),  # Only defined for datetime
            "epochSeconds": CypherNull(),  # Only defined for datetime
        }
        # For datetime, compute epochMillis and epochSeconds.
        # Use floor division from microseconds so pre-epoch values are consistent
        # (int(total_seconds()) truncates toward zero, giving epochSeconds=0 for
        # e.g. 1969-12-31T23:59:59.5Z while epochMillis would be -500).
        if isinstance(obj, CypherDateTime):
            dt = obj.value
            epoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
            if dt.tzinfo is not None:
                delta = dt - epoch
            else:
                delta = dt - datetime.datetime(1970, 1, 1)
            total_us = delta.days * 86_400_000_000 + delta.seconds * 1_000_000 + delta.microseconds
            time_props["epochMillis"] = CypherInt(total_us // 1000)
            time_props["epochSeconds"] = CypherInt(total_us // 1_000_000)
        if prop in time_props:
            return time_props[prop]
        return CypherNull()

    if isinstance(obj, CypherDuration):
        import math as _math

        # Use _components (years, months, days, hours, minutes, seconds, microseconds, nanoseconds)
        # which preserves the date/time boundary (days are NOT absorbed into hours).
        years_c, months_c, days_c, hours_c, minutes_c, seconds_c, us_c, ns_c = obj._components
        total_months = years_c * 12 + months_c
        total_days = days_c

        # Total microseconds in the TIME part only (not including date-part days).
        time_us = hours_c * 3_600_000_000 + minutes_c * 60_000_000 + seconds_c * 1_000_000 + us_c

        # "Total" accessors: whole units within the time part.
        # Use floor division so that the sub-second accessor is always non-negative,
        # matching Python timedelta.microseconds semantics and openCypher's convention.
        total_hours = time_us // 3_600_000_000
        total_minutes = time_us // 60_000_000
        total_seconds = time_us // 1_000_000
        total_ms = time_us // 1_000
        total_us_full = time_us
        total_ns = time_us * 1000 + ns_c  # ns_c carries sub-microsecond nanoseconds

        # "OfX" sub-unit components (from canonical _components values).
        months_of_year = months_c  # months component (e.g. 4 for P1Y4M)
        quarters_of_year = abs(months_c) // 3  # complete quarters in months component
        months_of_quarter = abs(months_c) % 3  # remaining months within quarter
        # Sub-second accessors use Python-normalized non-negative microsecond remainder.
        us_of_second = time_us % 1_000_000  # always 0 ≤ us_of_second < 1_000_000
        ms_of_second = us_of_second // 1000
        ns_of_second = us_of_second * 1000 + ns_c  # include sub-microsecond nanoseconds

        sign_val = -1 if (total_months < 0 or total_days < 0 or time_us < 0) else 1
        dur_props: dict[str, CypherValue] = {
            "years": CypherInt(_math.trunc(total_months / 12)),
            "quarters": CypherInt(_math.trunc(total_months / 3)),
            "months": CypherInt(total_months),
            "weeks": CypherInt(total_days // 7),
            "days": CypherInt(total_days),
            "hours": CypherInt(total_hours),
            "minutes": CypherInt(total_minutes),
            "seconds": CypherInt(total_seconds),
            "milliseconds": CypherInt(total_ms),
            "microseconds": CypherInt(total_us_full),
            "nanoseconds": CypherInt(total_ns),
            "monthsOfYear": CypherInt(months_of_year),
            "quartersOfYear": CypherInt(quarters_of_year),
            "monthsOfQuarter": CypherInt(months_of_quarter),
            "daysOfWeek": CypherInt(total_days % 7),
            "minutesOfHour": CypherInt(minutes_c),
            "secondsOfMinute": CypherInt(seconds_c),
            "millisecondsOfSecond": CypherInt(ms_of_second),
            "microsecondsOfSecond": CypherInt(us_of_second),
            "nanosecondsOfSecond": CypherInt(ns_of_second),
            "sign": CypherInt(sign_val),
        }
        if prop in dur_props:
            return dur_props[prop]
        return CypherNull()
    return CypherNull()  # type: ignore[unreachable]  # all union members handled above


def _evaluate_temporal_function(
    func_name: str, args: list[CypherValue], executor: Any = None
) -> CypherValue:
    """Evaluate temporal functions.

    Args:
        func_name: Name of the temporal function (uppercase)
        args: List of evaluated arguments (non-NULL)
        executor: Optional QueryExecutor for statement-clock access

    Returns:
        CypherValue result of the temporal function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    import calendar
    import datetime

    def _statement_now_utc() -> datetime.datetime:
        """Return the statement clock as a UTC-aware datetime."""
        if executor is not None and hasattr(executor, "_statement_clock_ns"):
            ns = executor._statement_clock_ns
            us = ns // 1000
            return datetime.datetime.fromtimestamp(us / 1_000_000, tz=datetime.timezone.utc)
        return datetime.datetime.now(tz=datetime.timezone.utc)

    def _statement_now_naive() -> datetime.datetime:
        """Return the statement clock as a naive (tz-less) datetime."""
        if executor is not None and hasattr(executor, "_statement_clock_ns"):
            ns = executor._statement_clock_ns
            us = ns // 1000
            return datetime.datetime.fromtimestamp(us / 1_000_000).replace(tzinfo=None)
        return datetime.datetime.now().replace(tzinfo=None)

    if func_name == "DATE":
        # date(), date(string), or date(map)
        if len(args) == 0:
            # date() returns current date
            return CypherDate(datetime.date.today())
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, CypherString):
                # date(string) parses ISO 8601 date
                return CypherDate(arg.value)
            elif isinstance(arg, (CypherDate, CypherDateTime)):
                # date(temporal) extracts the date component
                if isinstance(arg, CypherDate):
                    return arg
                return CypherDate(arg.value.date() if hasattr(arg.value, "date") else arg.value)
            elif isinstance(arg, CypherMap):
                year = _extract_map_param(arg, "year")
                month = _extract_map_param(arg, "month")
                day = _extract_map_param(arg, "day")
                week = _extract_map_param(arg, "week")
                day_of_week = _extract_map_param(arg, "dayOfWeek")
                quarter = _extract_map_param(arg, "quarter")
                day_of_quarter = _extract_map_param(arg, "dayOfQuarter")
                ordinal_day = _extract_map_param(arg, "ordinalDay")

                # Check if any parameter is explicitly null
                all_params = [
                    year,
                    month,
                    day,
                    week,
                    day_of_week,
                    quarter,
                    day_of_quarter,
                    ordinal_day,
                ]
                if any(isinstance(p, CypherNull) for p in all_params):
                    return CypherNull()

                # "Select" form: {date: base_date, ...overrides}
                base_cypher = arg.value.get("date")
                if base_cypher is not None and isinstance(
                    base_cypher, (CypherDate, CypherDateTime)
                ):
                    base = (
                        base_cypher.value
                        if isinstance(base_cypher, CypherDate)
                        else base_cypher.value.date()
                    )
                    if week is not _MISSING:
                        # week override: treat year (if given) as ISO year, preserve ISO weekday
                        iso_yr = year if year is not _MISSING else base.isocalendar()[0]
                        dow = day_of_week if day_of_week is not _MISSING else base.isoweekday()
                        jan4 = datetime.date(iso_yr, 1, 4)
                        week1_mon = jan4 - datetime.timedelta(days=jan4.weekday())
                        base = week1_mon + datetime.timedelta(weeks=week - 1, days=dow - 1)
                    else:
                        if year is not _MISSING:
                            base = base.replace(year=year)
                        if month is not _MISSING:
                            base = base.replace(month=month)
                        if day is not _MISSING:
                            base = base.replace(day=day)
                        if ordinal_day is not _MISSING:
                            jan1 = datetime.date(base.year, 1, 1)
                            base = jan1 + datetime.timedelta(days=ordinal_day - 1)
                        elif quarter is not _MISSING:
                            orig_q = (base.month - 1) // 3 + 1
                            orig_q_start = datetime.date(base.year, (orig_q - 1) * 3 + 1, 1)
                            day_in_q = (base - orig_q_start).days
                            new_q_start = datetime.date(base.year, (quarter - 1) * 3 + 1, 1)
                            base = new_q_start + datetime.timedelta(days=day_in_q)
                    return CypherDate(base)

                # Standard component forms — week/quarter/ordinal checked first so that
                # providing e.g. {year, week} doesn't fall through to calendar form.
                if year is not _MISSING and week is not _MISSING:
                    if day_of_week is _MISSING:
                        day_of_week = 1  # Default to Monday
                    if not (1 <= week <= 53):
                        raise ValueError(f"week must be between 1 and 53, got {week}")
                    if not (1 <= day_of_week <= 7):
                        raise ValueError(f"dayOfWeek must be between 1 and 7, got {day_of_week}")
                    jan4 = datetime.date(year, 1, 4)
                    week_one_monday = jan4 - datetime.timedelta(days=jan4.weekday())
                    target_date = week_one_monday + datetime.timedelta(
                        weeks=week - 1, days=day_of_week - 1
                    )
                    return CypherDate(target_date)
                elif year is not _MISSING and quarter is not _MISSING:
                    if day_of_quarter is _MISSING:
                        day_of_quarter = 1  # Default to first day of quarter
                    if not (1 <= quarter <= 4):
                        raise ValueError(f"quarter must be between 1 and 4, got {quarter}")
                    first_month = (quarter - 1) * 3 + 1
                    last_month = first_month + 2 if quarter < 4 else 12
                    days_in_quarter = sum(
                        calendar.monthrange(year, m)[1] for m in range(first_month, last_month + 1)
                    )
                    if not (1 <= day_of_quarter <= days_in_quarter):
                        raise ValueError(
                            f"dayOfQuarter must be between 1 and {days_in_quarter} "
                            f"for quarter {quarter} of year {year}, got {day_of_quarter}"
                        )
                    first_day = datetime.date(year, first_month, 1)
                    target_date = first_day + datetime.timedelta(days=day_of_quarter - 1)
                    return CypherDate(target_date)
                elif year is not _MISSING and ordinal_day is not _MISSING:
                    max_ordinal_day = 366 if calendar.isleap(year) else 365
                    if not (1 <= ordinal_day <= max_ordinal_day):
                        raise ValueError(
                            f"ordinalDay must be between 1 and {max_ordinal_day} "
                            f"for year {year}, got {ordinal_day}"
                        )
                    jan1 = datetime.date(year, 1, 1)
                    target_date = jan1 + datetime.timedelta(days=ordinal_day - 1)
                    return CypherDate(target_date)
                elif year is not _MISSING:
                    # Calendar form — month and day default to 1 (per openCypher)
                    if month is _MISSING:
                        month = 1
                    if day is _MISSING:
                        day = 1
                    return CypherDate(datetime.date(year, month, day))
                else:
                    raise TypeError(
                        "DATE map constructor requires at least: year "
                        "(month and day default to 1 if omitted)"
                    )
            else:
                raise TypeError(f"DATE expects string, date, or map, got {type(arg).__name__}")
        else:
            raise TypeError(f"DATE expects 0 or 1 argument, got {len(args)}")

    elif func_name == "DATETIME":
        # datetime(), datetime(string), or datetime(map)
        if len(args) == 0:
            # datetime() returns current datetime in UTC (per openCypher)
            return CypherDateTime(_statement_now_utc())
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, CypherString):
                # datetime(string) parses ISO 8601 datetime; default to UTC if no tz given
                cypher_dt = CypherDateTime(arg.value)
                if cypher_dt.value.tzinfo is None:
                    return CypherDateTime(cypher_dt.value.replace(tzinfo=datetime.timezone.utc))
                return cypher_dt
            elif isinstance(arg, CypherMap):
                # datetime(map) builds from components
                year = _extract_map_param(arg, "year")
                month = _extract_map_param(arg, "month")
                day = _extract_map_param(arg, "day")
                hour = _extract_map_param(arg, "hour", 0)
                minute = _extract_map_param(arg, "minute", 0)
                second = _extract_map_param(arg, "second", 0)
                millisecond = _extract_map_param(arg, "millisecond", 0)
                microsecond = _extract_map_param(arg, "microsecond", 0)
                nanosecond = _extract_map_param(arg, "nanosecond", 0)
                timezone = _extract_map_param(arg, "timezone")

                week = _extract_map_param(arg, "week")
                day_of_week = _extract_map_param(arg, "dayOfWeek")
                quarter = _extract_map_param(arg, "quarter")
                day_of_quarter = _extract_map_param(arg, "dayOfQuarter")
                ordinal_day = _extract_map_param(arg, "ordinalDay")

                # Check if any parameter is explicitly null
                all_params = [
                    year,
                    month,
                    day,
                    hour,
                    minute,
                    second,
                    millisecond,
                    microsecond,
                    nanosecond,
                    timezone,
                    week,
                    day_of_week,
                    quarter,
                    day_of_quarter,
                    ordinal_day,
                ]
                if any(isinstance(p, CypherNull) for p in all_params):
                    return CypherNull()

                # Total microseconds from all sub-second components; preserve sub-µs residue
                ns_residue_dt = nanosecond % 1000
                total_microsecond = microsecond + (millisecond * 1000) + (nanosecond // 1000)

                # Normalize microseconds overflow into seconds
                carry_seconds = total_microsecond // 1_000_000
                total_microsecond = total_microsecond % 1_000_000
                second += carry_seconds

                # Normalize seconds overflow into minutes
                carry_minutes = second // 60
                second = second % 60
                minute += carry_minutes

                # Normalize minutes overflow into hours
                carry_hours = minute // 60
                minute = minute % 60
                hour += carry_hours

                # "Select" form with separate date and time components
                _date_cypher_for_dt = arg.value.get("date")
                _time_cypher_for_dt = (
                    arg.value.get("time") if arg.value.get("datetime") is None else None
                )
                if (
                    _date_cypher_for_dt is not None
                    and isinstance(_date_cypher_for_dt, (CypherDate, CypherDateTime))
                    and _time_cypher_for_dt is not None
                    and isinstance(_time_cypher_for_dt, (CypherTime, CypherDateTime))
                ):
                    date_part_dt = (
                        _date_cypher_for_dt.value
                        if isinstance(_date_cypher_for_dt, CypherDate)
                        else _date_cypher_for_dt.value.date()
                    )
                    time_part_dt = (
                        _time_cypher_for_dt.value
                        if isinstance(_time_cypher_for_dt, CypherTime)
                        else _time_cypher_for_dt.value.timetz()
                    )
                    # Apply date-component overrides to the date part
                    if year is not _MISSING:
                        date_part_dt = date_part_dt.replace(year=year)
                    if month is not _MISSING:
                        date_part_dt = date_part_dt.replace(month=month)
                    if day is not _MISSING:
                        date_part_dt = date_part_dt.replace(day=day)
                    # Apply time-component overrides to the time part (only explicitly given keys)
                    _t_kw: dict = {}
                    for _k, _attr in [
                        ("hour", "hour"),
                        ("minute", "minute"),
                        ("second", "second"),
                    ]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _t_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _t_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _t_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _t_kw["microsecond"] = int(_rv_ns.value) // 1000
                    if _t_kw:
                        time_part_dt = time_part_dt.replace(**_t_kw)
                    _was_tz_aware = time_part_dt.tzinfo is not None
                    result_dt_combined = datetime.datetime.combine(date_part_dt, time_part_dt)
                    if timezone is not _MISSING:
                        _new_tz = _parse_timezone_str(timezone)
                        if _was_tz_aware:
                            result_dt_combined = result_dt_combined.astimezone(_new_tz)
                        else:
                            result_dt_combined = result_dt_combined.replace(tzinfo=_new_tz)
                    elif not _was_tz_aware:
                        result_dt_combined = result_dt_combined.replace(
                            tzinfo=datetime.timezone.utc
                        )
                    return CypherDateTime(result_dt_combined)

                # "Select" form: {datetime: base, ...overrides} — check before standard forms
                _dt_base_key = "datetime"
                base_dt_cypher = arg.value.get("datetime")
                if isinstance(base_dt_cypher, CypherNull):
                    return CypherNull()
                if base_dt_cypher is None:
                    _dt_base_key = "date"
                    base_dt_cypher = arg.value.get("date")
                    if isinstance(base_dt_cypher, CypherNull):
                        return CypherNull()
                if base_dt_cypher is not None and isinstance(
                    base_dt_cypher, (CypherDate, CypherDateTime)
                ):
                    if isinstance(base_dt_cypher, CypherDateTime):
                        base_dt = base_dt_cypher.value
                    else:
                        base_dt = datetime.datetime.combine(base_dt_cypher.value, datetime.time())
                    # When the base comes from a "date" key (not a full datetime), the time
                    # components start fresh (midnight, timezone-naive → UTC). The explicit
                    # hour/minute/second keys then build the time from scratch.
                    if _dt_base_key == "date" and isinstance(base_dt_cypher, CypherDateTime):
                        base_dt = base_dt.replace(
                            hour=0, minute=0, second=0, microsecond=0, tzinfo=None
                        )
                    base_d = base_dt.date()
                    if week is not _MISSING:
                        # week override: treat year (if given) as ISO year, preserve ISO weekday
                        iso_yr = year if year is not _MISSING else base_d.isocalendar()[0]
                        dow = day_of_week if day_of_week is not _MISSING else base_d.isoweekday()
                        jan4 = datetime.date(iso_yr, 1, 4)
                        week1_mon = jan4 - datetime.timedelta(days=jan4.weekday())
                        base_d = week1_mon + datetime.timedelta(weeks=week - 1, days=dow - 1)
                    else:
                        if year is not _MISSING:
                            base_d = base_d.replace(year=year)
                        if month is not _MISSING:
                            base_d = base_d.replace(month=month)
                        if day is not _MISSING:
                            base_d = base_d.replace(day=day)
                        if ordinal_day is not _MISSING:
                            jan1 = datetime.date(base_d.year, 1, 1)
                            base_d = jan1 + datetime.timedelta(days=ordinal_day - 1)
                        elif quarter is not _MISSING:
                            orig_q = (base_d.month - 1) // 3 + 1
                            orig_q_start = datetime.date(base_d.year, (orig_q - 1) * 3 + 1, 1)
                            day_in_q = (base_d - orig_q_start).days
                            new_q_start = datetime.date(base_d.year, (quarter - 1) * 3 + 1, 1)
                            base_d = new_q_start + datetime.timedelta(days=day_in_q)
                    result_dt = base_dt.replace(
                        year=base_d.year, month=base_d.month, day=base_d.day
                    )
                    # Apply explicit time-component overrides (hour/minute/second/subsecond)
                    _dt_time_kw: dict = {}
                    for _k, _attr in [("hour", "hour"), ("minute", "minute"), ("second", "second")]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _dt_time_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _dt_time_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _dt_time_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _dt_time_kw["microsecond"] = int(_rv_ns.value) // 1000
                    # Normalize hour overflow (same as map-form constructor)
                    if "hour" in _dt_time_kw:
                        _dt_carry = _dt_time_kw["hour"] // 24
                        _dt_time_kw["hour"] = _dt_time_kw["hour"] % 24
                        if _dt_carry > 0:
                            result_dt = result_dt + datetime.timedelta(days=_dt_carry)
                    if _dt_time_kw:
                        result_dt = result_dt.replace(**_dt_time_kw)
                    if timezone is not _MISSING:
                        new_tz = _parse_timezone_str(timezone)
                        # When using {datetime: base, timezone: new}, convert the timezone
                        # (astimezone); when building from a date base, just assign it.
                        if _dt_base_key == "datetime" and result_dt.tzinfo is not None:
                            result_dt = result_dt.astimezone(new_tz)
                        else:
                            result_dt = result_dt.replace(tzinfo=new_tz)
                    elif result_dt.tzinfo is None:
                        result_dt = result_dt.replace(tzinfo=datetime.timezone.utc)
                    return CypherDateTime(result_dt)

                # Determine date part — week/quarter/ordinal checked first so that
                # e.g. {year, week} doesn't fall through to the calendar form.
                if year is not _MISSING and week is not _MISSING:
                    if day_of_week is _MISSING:
                        day_of_week = 1  # Default to Monday
                    if not (1 <= week <= 53):
                        raise ValueError(f"week must be between 1 and 53, got {week}")
                    if not (1 <= day_of_week <= 7):
                        raise ValueError(f"dayOfWeek must be between 1 and 7, got {day_of_week}")
                    jan4 = datetime.date(year, 1, 4)
                    week_one_monday = jan4 - datetime.timedelta(days=jan4.weekday())
                    date_part = week_one_monday + datetime.timedelta(
                        weeks=week - 1, days=day_of_week - 1
                    )
                elif year is not _MISSING and quarter is not _MISSING:
                    if day_of_quarter is _MISSING:
                        day_of_quarter = 1  # Default to first day of quarter
                    if not (1 <= quarter <= 4):
                        raise ValueError(f"quarter must be between 1 and 4, got {quarter}")
                    first_month = (quarter - 1) * 3 + 1
                    last_month = first_month + 2 if quarter < 4 else 12
                    days_in_quarter = sum(
                        calendar.monthrange(year, m)[1] for m in range(first_month, last_month + 1)
                    )
                    if not (1 <= day_of_quarter <= days_in_quarter):
                        raise ValueError(
                            f"dayOfQuarter must be between 1 and {days_in_quarter} "
                            f"for quarter {quarter} of year {year}, got {day_of_quarter}"
                        )
                    first_day = datetime.date(year, first_month, 1)
                    date_part = first_day + datetime.timedelta(days=day_of_quarter - 1)
                elif year is not _MISSING and ordinal_day is not _MISSING:
                    max_ordinal_day = 366 if calendar.isleap(year) else 365
                    if not (1 <= ordinal_day <= max_ordinal_day):
                        raise ValueError(
                            f"ordinalDay must be between 1 and {max_ordinal_day} "
                            f"for year {year}, got {ordinal_day}"
                        )
                    jan1 = datetime.date(year, 1, 1)
                    date_part = jan1 + datetime.timedelta(days=ordinal_day - 1)
                elif year is not _MISSING:
                    # Calendar form — month and day default to 1 (per openCypher)
                    if month is _MISSING:
                        month = 1
                    if day is _MISSING:
                        day = 1
                    date_part = datetime.date(year, month, day)
                else:
                    raise TypeError(
                        "DATETIME map constructor requires at least: year "
                        "(month and day default to 1 if omitted)"
                    )

                # Check for time: key — combine computed date with given time
                _time_key = arg.value.get("time") if arg.value.get("datetime") is None else None
                if _time_key is not None and isinstance(_time_key, (CypherTime, CypherDateTime)):
                    _time_val = (
                        _time_key.value
                        if isinstance(_time_key, CypherTime)
                        else _time_key.value.timetz()
                    )
                    # Normalize IANA tzinfo to fixed offset at this specific datetime
                    _time_src_tz = _time_val.tzinfo
                    if _time_src_tz is not None:
                        _utc_off = _time_src_tz.utcoffset(
                            datetime.datetime.combine(date_part, _time_val)
                        )
                        if _utc_off is not None:
                            _time_val = _time_val.replace(tzinfo=datetime.timezone(_utc_off))
                            _time_src_tz = datetime.timezone(_utc_off)
                    dt = datetime.datetime.combine(date_part, _time_val)
                    # Apply any explicit time-component overrides (second, minute, etc.)
                    _dt_yr_time_kw: dict = {}
                    for _k, _attr in [
                        ("hour", "hour"),
                        ("minute", "minute"),
                        ("second", "second"),
                    ]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _dt_yr_time_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _dt_yr_time_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _dt_yr_time_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _dt_yr_time_kw["microsecond"] = int(_rv_ns.value) // 1000
                    # Normalize hour overflow (same as map-form constructor)
                    if "hour" in _dt_yr_time_kw:
                        _dt_yr_carry = _dt_yr_time_kw["hour"] // 24
                        _dt_yr_time_kw["hour"] = _dt_yr_time_kw["hour"] % 24
                        if _dt_yr_carry > 0:
                            dt = dt + datetime.timedelta(days=_dt_yr_carry)
                    if _dt_yr_time_kw:
                        dt = dt.replace(**_dt_yr_time_kw)
                    if timezone is not _MISSING:
                        new_tz = _parse_timezone_str(timezone)
                        if _time_src_tz is not None:
                            # Source had a timezone: convert (astimezone) to new tz
                            dt = dt.astimezone(new_tz)
                        else:
                            dt = dt.replace(tzinfo=new_tz)
                    elif _time_val.tzinfo is not None:
                        dt = dt.replace(tzinfo=_time_val.tzinfo)
                    elif dt.tzinfo is None:
                        dt = dt.replace(tzinfo=datetime.timezone.utc)
                    return CypherDateTime(dt)

                # Normalize hour overflow into days
                carry_days = hour // 24
                hour = hour % 24
                if carry_days > 0:
                    date_part = date_part + datetime.timedelta(days=carry_days)

                # Combine date and time
                dt = datetime.datetime.combine(
                    date_part, datetime.time(hour, minute, second, total_microsecond)
                )

                # Handle timezone: explicit override, or default UTC (datetime() not localdatetime)
                _dt_iana_name: str | None = None
                if timezone is not _MISSING:
                    import re as _re_tz

                    dt = dt.replace(tzinfo=_parse_timezone_str(timezone))
                    if not _re_tz.match(r"^[+-]\d{2}:\d{2}", str(timezone)):
                        _dt_iana_name = str(timezone)
                else:
                    dt = dt.replace(tzinfo=datetime.timezone.utc)

                return CypherDateTime(dt, _ns_residue=ns_residue_dt, _iana_tz_name=_dt_iana_name)
            elif isinstance(arg, CypherDateTime):
                # datetime(datetime) → return as-is
                # datetime(localdatetime) → add UTC timezone
                if arg.value.tzinfo is not None:
                    return arg
                return CypherDateTime(arg.value.replace(tzinfo=datetime.timezone.utc))
            else:
                raise TypeError(f"DATETIME expects string or map, got {type(arg).__name__}")
        else:
            raise TypeError(f"DATETIME expects 0 or 1 argument, got {len(args)}")

    elif func_name == "TIME":
        # time(), time(string), or time(map)
        if len(args) == 0:
            # time() returns current time in UTC (per openCypher)
            return CypherTime(_statement_now_utc().timetz())
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, CypherString):
                # time(string) parses ISO 8601 time.
                # Per openCypher: time literals always have a timezone (default UTC).
                ct = CypherTime(arg.value)
                if ct.value.tzinfo is None:
                    return CypherTime(ct.value.replace(tzinfo=datetime.timezone.utc))
                return ct
            elif isinstance(arg, CypherTime):
                # time(localtime) → add UTC; time(time_with_tz) → normalize IANA to fixed offset
                t = arg.value
                if t.tzinfo is None:
                    t = t.replace(tzinfo=datetime.timezone.utc)
                else:
                    utc_off = t.tzinfo.utcoffset(
                        datetime.datetime.combine(datetime.date(2000, 1, 1), t)
                    )
                    if utc_off is not None:
                        t = t.replace(tzinfo=datetime.timezone(utc_off))
                return CypherTime(t)
            elif isinstance(arg, CypherDateTime):
                # time(datetime_value) extracts time with fixed UTC offset
                dt_val = arg.value
                t = dt_val.timetz()
                if t.tzinfo is not None:
                    utc_off = t.tzinfo.utcoffset(dt_val)
                    if utc_off is not None:
                        t = t.replace(tzinfo=datetime.timezone(utc_off))
                elif t.tzinfo is None:
                    t = t.replace(tzinfo=datetime.timezone.utc)
                return CypherTime(t)
            elif isinstance(arg, CypherMap):
                # time(map): supports "select" form {time: base, ...overrides}
                base_time_cypher = arg.value.get("time") or arg.value.get("datetime")
                if base_time_cypher is not None and isinstance(
                    base_time_cypher, (CypherTime, CypherDateTime)
                ):
                    base_t = (
                        base_time_cypher.value.timetz()
                        if isinstance(base_time_cypher, CypherDateTime)
                        else base_time_cypher.value
                    )
                    h0, m0, s0 = base_t.hour, base_t.minute, base_t.second
                    us0 = base_t.microsecond
                    tz0 = base_t.tzinfo
                else:
                    h0, m0, s0, us0, tz0 = 0, 0, 0, 0, None

                hour = _extract_map_param(arg, "hour", h0)
                minute = _extract_map_param(arg, "minute", m0)
                second = _extract_map_param(arg, "second", s0)
                timezone = _extract_map_param(arg, "timezone")

                # Sub-second fields are cumulative per openCypher spec:
                # When nanosecond alone: it is the total nanoseconds (e.g. 645876123).
                # When multiple sub-second fields coexist, they contribute additively:
                #   total_ns = millisecond*1e6 + microsecond*1e3 + nanosecond
                _has_ns = "nanosecond" in arg.value
                _has_us = "microsecond" in arg.value
                _has_ms = "millisecond" in arg.value
                _ns_residue_time = 0
                if _has_ns and (_has_us or _has_ms):
                    # Multiple sub-second fields: additive combination
                    _ns_val = _extract_map_param(arg, "nanosecond", 0)
                    _us_val = _extract_map_param(arg, "microsecond", 0) if _has_us else 0
                    _ms_val = _extract_map_param(arg, "millisecond", 0) if _has_ms else 0
                    total_ns_t = _ms_val * 1_000_000 + _us_val * 1_000 + _ns_val
                    _ns_residue_time = total_ns_t % 1000
                    total_microsecond = total_ns_t // 1000
                elif _has_ns:
                    _ns_val = _extract_map_param(arg, "nanosecond", 0)
                    _ns_residue_time = _ns_val % 1000
                    total_microsecond = _ns_val // 1000
                elif _has_us:
                    _us_val = _extract_map_param(arg, "microsecond", 0)
                    total_microsecond = _us_val
                elif _has_ms:
                    _ms_val = _extract_map_param(arg, "millisecond", 0)
                    # Replace millisecond portion; keep sub-millisecond from base
                    total_microsecond = _ms_val * 1000 + (us0 % 1000)
                else:
                    total_microsecond = us0  # no sub-second override: use base directly

                # Check if any parameter is explicitly null
                all_sub = [
                    arg.value.get("nanosecond"),
                    arg.value.get("microsecond"),
                    arg.value.get("millisecond"),
                ]
                all_params = [hour, minute, second, timezone] + [
                    v for v in all_sub if v is not None
                ]
                if any(isinstance(p, CypherNull) for p in all_params):
                    return CypherNull()

                # Normalize microseconds overflow into seconds
                carry_seconds = total_microsecond // 1_000_000
                total_microsecond = total_microsecond % 1_000_000
                second += carry_seconds

                # Normalize seconds overflow into minutes
                carry_minutes = second // 60
                second = second % 60
                minute += carry_minutes

                # Normalize minutes overflow into hours
                carry_hours = minute // 60
                minute = minute % 60
                hour += carry_hours

                # Validate hour range (TIME cannot have day overflow)
                if hour >= 24:
                    raise ValueError(
                        f"TIME hour overflow: hour must be 0-23 after normalization, got {hour}. "
                        f"Consider using DATETIME if day rollover is needed."
                    )

                # Create time object
                t = datetime.time(hour, minute, second, total_microsecond)

                # Handle timezone: explicit override takes precedence, then base's tz
                if timezone is not _MISSING:
                    new_tz = _parse_timezone_str(timezone)
                    if tz0 is not None:
                        # Base had a timezone: convert (astimezone) rather than replace.
                        # Use a proxy date to enable timezone-aware arithmetic on time.
                        t_with_orig = t.replace(tzinfo=tz0)
                        _utc_off_orig = tz0.utcoffset(
                            datetime.datetime.combine(datetime.date(2000, 1, 1), t_with_orig)
                        )
                        if _utc_off_orig is not None:
                            t_with_orig = t_with_orig.replace(
                                tzinfo=datetime.timezone(_utc_off_orig)
                            )
                        dt_proxy = datetime.datetime.combine(datetime.date(2000, 1, 1), t_with_orig)
                        dt_converted = dt_proxy.astimezone(new_tz)
                        t = dt_converted.timetz()
                        # Normalize IANA to fixed offset
                        _new_utc_off = new_tz.utcoffset(dt_converted)
                        if _new_utc_off is not None:
                            t = t.replace(tzinfo=datetime.timezone(_new_utc_off))
                    else:
                        t = t.replace(tzinfo=new_tz)
                elif tz0 is not None:
                    # Normalize IANA timezone to fixed offset
                    _utc_off_ref = tz0.utcoffset(
                        datetime.datetime.combine(datetime.date(2000, 1, 1), t)
                    )
                    if _utc_off_ref is not None:
                        t = t.replace(tzinfo=datetime.timezone(_utc_off_ref))
                    else:
                        t = t.replace(tzinfo=tz0)
                elif base_time_cypher is not None:
                    # time({time: localtime_val, ...}) — localtime has no tz, add UTC
                    t = t.replace(tzinfo=datetime.timezone.utc)
                else:
                    # pure component form {hour: 12, minute: 31, ...} — default to UTC
                    t = t.replace(tzinfo=datetime.timezone.utc)

                return CypherTime(t, _ns_residue=_ns_residue_time)
            else:
                raise TypeError(
                    f"TIME expects string, time, datetime, or map, got {type(arg).__name__}"
                )
        else:
            raise TypeError(f"TIME expects 0 or 1 argument, got {len(args)}")

    elif func_name == "LOCALDATETIME":
        # localdatetime(), localdatetime(string), or localdatetime(map)
        if len(args) == 0:
            # localdatetime() returns current datetime without timezone
            return CypherDateTime(_statement_now_naive())
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, CypherString):
                # localdatetime(string) parses ISO 8601 datetime without timezone
                cypher_dt = CypherDateTime(arg.value)
                # Strip timezone if present to ensure naive datetime
                if cypher_dt.value.tzinfo is not None:
                    cypher_dt = CypherDateTime(cypher_dt.value.replace(tzinfo=None))
                return cypher_dt
            elif isinstance(arg, CypherMap):
                # localdatetime(map) builds from components (no timezone)
                year = _extract_map_param(arg, "year")
                month = _extract_map_param(arg, "month")
                day = _extract_map_param(arg, "day")
                hour = _extract_map_param(arg, "hour", 0)
                minute = _extract_map_param(arg, "minute", 0)
                second = _extract_map_param(arg, "second", 0)
                millisecond = _extract_map_param(arg, "millisecond", 0)
                microsecond = _extract_map_param(arg, "microsecond", 0)
                nanosecond = _extract_map_param(arg, "nanosecond", 0)

                week = _extract_map_param(arg, "week")
                day_of_week = _extract_map_param(arg, "dayOfWeek")
                quarter = _extract_map_param(arg, "quarter")
                day_of_quarter = _extract_map_param(arg, "dayOfQuarter")
                ordinal_day = _extract_map_param(arg, "ordinalDay")

                # Check if any parameter is explicitly null
                all_params = [
                    year,
                    month,
                    day,
                    hour,
                    minute,
                    second,
                    millisecond,
                    microsecond,
                    nanosecond,
                    week,
                    day_of_week,
                    quarter,
                    day_of_quarter,
                    ordinal_day,
                ]
                if any(isinstance(p, CypherNull) for p in all_params):
                    return CypherNull()

                # Total microseconds from all sub-second components; preserve sub-µs residue
                ns_residue_ldt = nanosecond % 1000
                total_microsecond = microsecond + (millisecond * 1000) + (nanosecond // 1000)

                # Normalize microseconds overflow into seconds
                carry_seconds = total_microsecond // 1_000_000
                total_microsecond = total_microsecond % 1_000_000
                second += carry_seconds

                # Normalize seconds overflow into minutes
                carry_minutes = second // 60
                second = second % 60
                minute += carry_minutes

                # Normalize minutes overflow into hours
                carry_hours = minute // 60
                minute = minute % 60
                hour += carry_hours

                # "Select" form with separate date and time components
                _date_cypher_for_ldt = arg.value.get("date")
                _time_cypher_for_ldt = (
                    arg.value.get("time")
                    if arg.value.get("localdatetime") is None and arg.value.get("datetime") is None
                    else None
                )
                if (
                    _date_cypher_for_ldt is not None
                    and isinstance(_date_cypher_for_ldt, (CypherDate, CypherDateTime))
                    and _time_cypher_for_ldt is not None
                    and isinstance(_time_cypher_for_ldt, (CypherTime, CypherDateTime))
                ):
                    date_part_ldt = (
                        _date_cypher_for_ldt.value
                        if isinstance(_date_cypher_for_ldt, CypherDate)
                        else _date_cypher_for_ldt.value.date()
                    )
                    time_part_ldt = (
                        _time_cypher_for_ldt.value
                        if isinstance(_time_cypher_for_ldt, CypherTime)
                        else _time_cypher_for_ldt.value.time()
                    ).replace(tzinfo=None)
                    # Apply date-component overrides to the date part
                    if year is not _MISSING:
                        date_part_ldt = date_part_ldt.replace(year=year)
                    if month is not _MISSING:
                        date_part_ldt = date_part_ldt.replace(month=month)
                    if day is not _MISSING:
                        date_part_ldt = date_part_ldt.replace(day=day)
                    # Apply time-component overrides to the time part (only explicitly given keys)
                    _lt_kw: dict = {}
                    for _k, _attr in [
                        ("hour", "hour"),
                        ("minute", "minute"),
                        ("second", "second"),
                    ]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _lt_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _lt_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _lt_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _lt_kw["microsecond"] = int(_rv_ns.value) // 1000
                    if _lt_kw:
                        time_part_ldt = time_part_ldt.replace(**_lt_kw)
                    result_ldt_combined = datetime.datetime.combine(date_part_ldt, time_part_ldt)
                    return CypherDateTime(result_ldt_combined)

                # "Select" form: {localdatetime: base, ...overrides} — check before standard forms
                _ldt_base_key = "localdatetime"
                base_ldt_cypher = arg.value.get("localdatetime")
                if isinstance(base_ldt_cypher, CypherNull):
                    return CypherNull()
                if base_ldt_cypher is None:
                    _ldt_base_key = "datetime"
                    base_ldt_cypher = arg.value.get("datetime")
                    if isinstance(base_ldt_cypher, CypherNull):
                        return CypherNull()
                if base_ldt_cypher is None:
                    _ldt_base_key = "date"
                    base_ldt_cypher = arg.value.get("date")
                    if isinstance(base_ldt_cypher, CypherNull):
                        return CypherNull()
                if base_ldt_cypher is not None and isinstance(
                    base_ldt_cypher, (CypherDate, CypherDateTime)
                ):
                    if isinstance(base_ldt_cypher, CypherDateTime):
                        base_ldt = base_ldt_cypher.value.replace(tzinfo=None)
                    else:
                        base_ldt = datetime.datetime.combine(base_ldt_cypher.value, datetime.time())
                    # When the base comes from a "date" key (not a full datetime/localdatetime),
                    # the time components start fresh (midnight, subseconds=0). The explicit
                    # hour/minute/second keys then build the time from scratch.
                    if _ldt_base_key == "date" and isinstance(base_ldt_cypher, CypherDateTime):
                        base_ldt = base_ldt.replace(hour=0, minute=0, second=0, microsecond=0)
                    base_d = base_ldt.date()
                    if week is not _MISSING:
                        # week override: treat year (if given) as ISO year, preserve ISO weekday
                        iso_yr = year if year is not _MISSING else base_d.isocalendar()[0]
                        dow = day_of_week if day_of_week is not _MISSING else base_d.isoweekday()
                        jan4 = datetime.date(iso_yr, 1, 4)
                        week1_mon = jan4 - datetime.timedelta(days=jan4.weekday())
                        base_d = week1_mon + datetime.timedelta(weeks=week - 1, days=dow - 1)
                    else:
                        if year is not _MISSING:
                            base_d = base_d.replace(year=year)
                        if month is not _MISSING:
                            base_d = base_d.replace(month=month)
                        if day is not _MISSING:
                            base_d = base_d.replace(day=day)
                        if ordinal_day is not _MISSING:
                            jan1 = datetime.date(base_d.year, 1, 1)
                            base_d = jan1 + datetime.timedelta(days=ordinal_day - 1)
                        elif quarter is not _MISSING:
                            orig_q = (base_d.month - 1) // 3 + 1
                            orig_q_start = datetime.date(base_d.year, (orig_q - 1) * 3 + 1, 1)
                            day_in_q = (base_d - orig_q_start).days
                            new_q_start = datetime.date(base_d.year, (quarter - 1) * 3 + 1, 1)
                            base_d = new_q_start + datetime.timedelta(days=day_in_q)
                    result_ldt = base_ldt.replace(
                        year=base_d.year, month=base_d.month, day=base_d.day
                    )
                    # Apply explicit time-component overrides (hour/minute/second/subsecond)
                    _ldt_time_kw: dict = {}
                    for _k, _attr in [("hour", "hour"), ("minute", "minute"), ("second", "second")]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _ldt_time_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _ldt_time_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _ldt_time_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _ldt_time_kw["microsecond"] = int(_rv_ns.value) // 1000
                    # Normalize hour overflow (same as map-form constructor)
                    if "hour" in _ldt_time_kw:
                        _ldt_carry = _ldt_time_kw["hour"] // 24
                        _ldt_time_kw["hour"] = _ldt_time_kw["hour"] % 24
                        if _ldt_carry > 0:
                            result_ldt = result_ldt + datetime.timedelta(days=_ldt_carry)
                    if _ldt_time_kw:
                        result_ldt = result_ldt.replace(**_ldt_time_kw)
                    return CypherDateTime(result_ldt)

                # Determine date part — week/quarter/ordinal checked first so that
                # e.g. {year, week} doesn't fall through to the calendar form.
                if year is not _MISSING and week is not _MISSING:
                    if day_of_week is _MISSING:
                        day_of_week = 1  # Default to Monday
                    if not (1 <= week <= 53):
                        raise ValueError(f"week must be between 1 and 53, got {week}")
                    if not (1 <= day_of_week <= 7):
                        raise ValueError(f"dayOfWeek must be between 1 and 7, got {day_of_week}")
                    jan4 = datetime.date(year, 1, 4)
                    week_one_monday = jan4 - datetime.timedelta(days=jan4.weekday())
                    date_part = week_one_monday + datetime.timedelta(
                        weeks=week - 1, days=day_of_week - 1
                    )
                elif year is not _MISSING and quarter is not _MISSING:
                    if day_of_quarter is _MISSING:
                        day_of_quarter = 1  # Default to first day of quarter
                    if not (1 <= quarter <= 4):
                        raise ValueError(f"quarter must be between 1 and 4, got {quarter}")
                    first_month = (quarter - 1) * 3 + 1
                    last_month = first_month + 2 if quarter < 4 else 12
                    days_in_quarter = sum(
                        calendar.monthrange(year, m)[1] for m in range(first_month, last_month + 1)
                    )
                    if not (1 <= day_of_quarter <= days_in_quarter):
                        raise ValueError(
                            f"dayOfQuarter must be between 1 and {days_in_quarter} "
                            f"for quarter {quarter} of year {year}, got {day_of_quarter}"
                        )
                    first_day = datetime.date(year, first_month, 1)
                    date_part = first_day + datetime.timedelta(days=day_of_quarter - 1)
                elif year is not _MISSING and ordinal_day is not _MISSING:
                    max_ordinal_day = 366 if calendar.isleap(year) else 365
                    if not (1 <= ordinal_day <= max_ordinal_day):
                        raise ValueError(
                            f"ordinalDay must be between 1 and {max_ordinal_day} "
                            f"for year {year}, got {ordinal_day}"
                        )
                    jan1 = datetime.date(year, 1, 1)
                    date_part = jan1 + datetime.timedelta(days=ordinal_day - 1)
                elif year is not _MISSING:
                    # Calendar form — month and day default to 1 (per openCypher)
                    if month is _MISSING:
                        month = 1
                    if day is _MISSING:
                        day = 1
                    date_part = datetime.date(year, month, day)
                else:
                    raise TypeError(
                        "LOCALDATETIME map constructor requires at least: year "
                        "(month and day default to 1 if omitted)"
                    )

                # Check for time: key — combine computed date with given time (no tz)
                _time_key_ldt = (
                    arg.value.get("time")
                    if (
                        arg.value.get("localdatetime") is None and arg.value.get("datetime") is None
                    )
                    else None
                )
                if _time_key_ldt is not None and isinstance(
                    _time_key_ldt, (CypherTime, CypherDateTime)
                ):
                    _time_val_ldt = (
                        _time_key_ldt.value.time()
                        if isinstance(_time_key_ldt, CypherDateTime)
                        else _time_key_ldt.value.replace(tzinfo=None)
                    )
                    dt = datetime.datetime.combine(date_part, _time_val_ldt)
                    # Apply any explicit time-component overrides (second, minute, etc.)
                    _ldt_yr_time_kw: dict = {}
                    for _k, _attr in [
                        ("hour", "hour"),
                        ("minute", "minute"),
                        ("second", "second"),
                    ]:
                        _rv = arg.value.get(_k)
                        if _rv is not None and not isinstance(_rv, CypherNull):
                            _ldt_yr_time_kw[_attr] = int(_rv.value)
                    _rv_ms = arg.value.get("millisecond")
                    _rv_us = arg.value.get("microsecond")
                    _rv_ns = arg.value.get("nanosecond")
                    if _rv_ms is not None and not isinstance(_rv_ms, CypherNull):
                        _ldt_yr_time_kw["microsecond"] = int(_rv_ms.value) * 1000
                    if _rv_us is not None and not isinstance(_rv_us, CypherNull):
                        _ldt_yr_time_kw["microsecond"] = int(_rv_us.value)
                    if _rv_ns is not None and not isinstance(_rv_ns, CypherNull):
                        _ldt_yr_time_kw["microsecond"] = int(_rv_ns.value) // 1000
                    # Normalize hour overflow (same as map-form constructor)
                    if "hour" in _ldt_yr_time_kw:
                        _ldt_yr_carry = _ldt_yr_time_kw["hour"] // 24
                        _ldt_yr_time_kw["hour"] = _ldt_yr_time_kw["hour"] % 24
                        if _ldt_yr_carry > 0:
                            dt = dt + datetime.timedelta(days=_ldt_yr_carry)
                    if _ldt_yr_time_kw:
                        dt = dt.replace(**_ldt_yr_time_kw)
                    return CypherDateTime(dt)

                # Normalize hour overflow into days
                carry_days = hour // 24
                hour = hour % 24
                if carry_days > 0:
                    date_part = date_part + datetime.timedelta(days=carry_days)

                # Combine date and time (no timezone for LOCALDATETIME)
                dt = datetime.datetime.combine(
                    date_part, datetime.time(hour, minute, second, total_microsecond)
                )

                return CypherDateTime(dt, _ns_residue=ns_residue_ldt)
            elif isinstance(arg, CypherDateTime):
                # localdatetime(datetime) → strip timezone
                # localdatetime(localdatetime) → return as-is
                if arg.value.tzinfo is not None:
                    return CypherDateTime(arg.value.replace(tzinfo=None))
                return arg
            else:
                raise TypeError(f"LOCALDATETIME expects string or map, got {type(arg).__name__}")
        else:
            raise TypeError(f"LOCALDATETIME expects 0 or 1 argument, got {len(args)}")

    elif func_name == "LOCALTIME":
        # localtime(), localtime(string), or localtime(map)
        if len(args) == 0:
            # localtime() returns current time without timezone
            return CypherTime(_statement_now_naive().time().replace(tzinfo=None))
        elif len(args) == 1:
            arg = args[0]
            if isinstance(arg, CypherString):
                # localtime(string) parses ISO 8601 time without timezone
                cypher_t = CypherTime(arg.value)
                # Strip timezone if present to ensure naive time
                if cypher_t.value.tzinfo is not None:
                    cypher_t = CypherTime(cypher_t.value.replace(tzinfo=None))
                return cypher_t
            elif isinstance(arg, CypherTime):
                # localtime(time_value) strips timezone
                return CypherTime(arg.value.replace(tzinfo=None))
            elif isinstance(arg, CypherDateTime):
                # localtime(datetime_value) extracts naive time component
                return CypherTime(arg.value.time().replace(tzinfo=None))
            elif isinstance(arg, CypherMap):
                # localtime(map): supports "select" form {time: base, ...overrides} (no timezone)
                base_time_cypher = (
                    arg.value.get("time") or arg.value.get("localtime") or arg.value.get("datetime")
                )
                if base_time_cypher is not None and isinstance(
                    base_time_cypher, (CypherTime, CypherDateTime)
                ):
                    base_t = (
                        base_time_cypher.value.time()
                        if isinstance(base_time_cypher, CypherDateTime)
                        else base_time_cypher.value.replace(tzinfo=None)
                    )
                    h0, m0, s0, us0 = base_t.hour, base_t.minute, base_t.second, base_t.microsecond
                else:
                    h0, m0, s0, us0 = 0, 0, 0, 0
                hour = _extract_map_param(arg, "hour", h0)
                minute = _extract_map_param(arg, "minute", m0)
                second = _extract_map_param(arg, "second", s0)

                # Sub-second fields are cumulative per openCypher spec:
                # When nanosecond is provided alone it is the total nanoseconds (e.g. 645876123).
                # When multiple sub-second fields coexist (millisecond + microsecond + nanosecond),
                # they contribute their respective sub-second parts additively:
                #   total_ns = millisecond*1e6 + microsecond*1e3 + nanosecond
                # When only millisecond or microsecond is provided (without nanosecond),
                # nanosecond is derived from total (e.g. microsecond: 645876 -> ns=645876000).
                _has_ns = "nanosecond" in arg.value
                _has_us = "microsecond" in arg.value
                _has_ms = "millisecond" in arg.value
                _ns_residue_lt = 0
                if _has_ns and (_has_us or _has_ms):
                    # Multiple sub-second fields: additive combination
                    _ns_val = _extract_map_param(arg, "nanosecond", 0)
                    _us_val = _extract_map_param(arg, "microsecond", 0) if _has_us else 0
                    _ms_val = _extract_map_param(arg, "millisecond", 0) if _has_ms else 0
                    total_ns_lt = _ms_val * 1_000_000 + _us_val * 1_000 + _ns_val
                    _ns_residue_lt = total_ns_lt % 1000
                    total_microsecond = total_ns_lt // 1000
                elif _has_ns:
                    _ns_val = _extract_map_param(arg, "nanosecond", 0)
                    _ns_residue_lt = _ns_val % 1000
                    total_microsecond = _ns_val // 1000
                elif _has_us:
                    _us_val = _extract_map_param(arg, "microsecond", 0)
                    total_microsecond = _us_val
                elif _has_ms:
                    _ms_val = _extract_map_param(arg, "millisecond", 0)
                    total_microsecond = _ms_val * 1000 + (us0 % 1000)
                else:
                    total_microsecond = us0

                # Check if any parameter is explicitly null
                all_sub = [
                    arg.value.get("nanosecond"),
                    arg.value.get("microsecond"),
                    arg.value.get("millisecond"),
                ]
                all_params = [hour, minute, second] + [v for v in all_sub if v is not None]
                if any(isinstance(p, CypherNull) for p in all_params):
                    return CypherNull()

                # Normalize microseconds overflow into seconds
                carry_seconds = total_microsecond // 1_000_000
                total_microsecond = total_microsecond % 1_000_000
                second += carry_seconds

                # Normalize seconds overflow into minutes
                carry_minutes = second // 60
                second = second % 60
                minute += carry_minutes

                # Normalize minutes overflow into hours
                carry_hours = minute // 60
                minute = minute % 60
                hour += carry_hours

                # Validate hour range (LOCALTIME cannot have day overflow)
                if hour >= 24:
                    raise ValueError(
                        f"LOCALTIME hour overflow: hour must be 0-23 after normalization, "
                        f"got {hour}. Consider using LOCALDATETIME if day rollover is needed."
                    )

                # Create time object (no timezone for LOCALTIME)
                t = datetime.time(hour, minute, second, total_microsecond)

                return CypherTime(t, _ns_residue=_ns_residue_lt)
            else:
                raise TypeError(
                    f"LOCALTIME expects string, time, datetime, or map, got {type(arg).__name__}"
                )
        else:
            raise TypeError(f"LOCALTIME expects 0 or 1 argument, got {len(args)}")

    elif func_name == "DURATION":
        # duration(string) or duration(map)
        if len(args) != 1:
            raise TypeError(f"DURATION expects 1 argument, got {len(args)}")

        arg = args[0]
        if isinstance(arg, CypherString):
            # duration(string) parses ISO 8601 duration
            return CypherDuration(arg.value)
        elif isinstance(arg, CypherMap):
            # duration(map) builds from components — extract as floats to support
            # fractional values (e.g. years: 12.5 → 12 years + 6 months)
            def _extract_float(key: str) -> Any:
                cv = arg.value.get(key)
                if cv is None:
                    return 0.0
                if isinstance(cv, CypherNull):
                    return cv
                if isinstance(cv, (CypherInt, CypherFloat)):
                    return float(cv.value)
                raise TypeError(
                    f"DURATION map parameter '{key}' must be numeric, got {type(cv).__name__}"
                )

            years_f = _extract_float("years")
            months_f = _extract_float("months")
            weeks_f = _extract_float("weeks")
            days_f = _extract_float("days")
            hours_f = _extract_float("hours")
            minutes_f = _extract_float("minutes")
            seconds_f = _extract_float("seconds")
            milliseconds_f = _extract_float("milliseconds")
            microseconds_f = _extract_float("microseconds")
            nanoseconds_f = _extract_float("nanoseconds")

            all_params = [
                years_f,
                months_f,
                weeks_f,
                days_f,
                hours_f,
                minutes_f,
                seconds_f,
                milliseconds_f,
                microseconds_f,
                nanoseconds_f,
            ]
            if any(isinstance(p, CypherNull) for p in all_params):
                return CypherNull()

            # Cascade fractional parts down through precision hierarchy.
            # Each fractional unit converts to the next lower unit:
            #   0.5 years  → 6 months
            #   0.5 months → 0.5 * 30.436875 days (avg days/month)
            #   0.5 weeks  → 3.5 days
            #   0.5 days   → 12 hours
            #   0.5 hours  → 30 minutes
            #   0.5 minutes → 30 seconds
            #   0.5 seconds → 500 milliseconds
            #   0.5 ms     → 500 microseconds
            #   0.5 µs     → 500 nanoseconds
            import math

            def _split(v: float) -> tuple[int, float]:
                """Return (integer part, fractional part) using truncation."""
                trunc = math.trunc(v)
                return trunc, v - trunc

            years_i, years_frac = _split(years_f)
            months_f += years_frac * 12.0
            months_i, months_frac = _split(months_f)
            days_f += months_frac * 30.436875 + weeks_f * 7.0
            days_i, days_frac = _split(days_f)
            hours_f += days_frac * 24.0
            hours_i, hours_frac = _split(hours_f)
            minutes_f += hours_frac * 60.0
            minutes_i, minutes_frac = _split(minutes_f)
            seconds_f += minutes_frac * 60.0
            seconds_i, seconds_frac = _split(seconds_f)
            milliseconds_f += seconds_frac * 1_000.0
            milliseconds_i, milliseconds_frac = _split(milliseconds_f)
            microseconds_f += milliseconds_frac * 1_000.0
            microseconds_i, microseconds_frac = _split(microseconds_f)
            nanoseconds_f += microseconds_frac * 1_000.0
            nanoseconds_i = math.trunc(nanoseconds_f)

            import isodate

            us_i = microseconds_i + (nanoseconds_i // 1000)

            # Compute canonical components for equality.
            # openCypher equality is component-wise: 13D+40H != 14D+16H.
            # We keep days_i as-is (not absorbed from hours) but normalize
            # within the time part (seconds→minutes→hours, but NOT hours→days).
            # Use truncation-toward-zero so negative durations like PT-1.999S
            # decompose correctly: -1999000µs → seconds=-1, us=-999000.
            time_td = datetime.timedelta(
                hours=hours_i,
                minutes=minutes_i,
                seconds=seconds_i,
                milliseconds=milliseconds_i,
                microseconds=us_i,
            )

            def _trunc_div_us(total: int, unit: int) -> "tuple[int, int]":
                """Truncation-toward-zero division with remainder of same sign as total."""
                if total >= 0:
                    return divmod(total, unit)
                q_abs, r_abs = divmod(-total, unit)
                return (-q_abs, 0) if r_abs == 0 else (-q_abs, -r_abs)

            # Recover signed total microseconds from Python's normalized timedelta
            time_us = (
                time_td.days * 86_400 * 1_000_000
                + time_td.seconds * 1_000_000
                + time_td.microseconds
            )
            canon_h, rem_us = _trunc_div_us(time_us, 3_600_000_000)
            canon_m, rem_us = _trunc_div_us(rem_us, 60_000_000)
            canon_s, canon_us = _trunc_div_us(rem_us, 1_000_000)
            # Preserve sub-microsecond nanosecond residue (0-999)
            ns_residue_dur = nanoseconds_i % 1000
            canonical = (
                years_i,
                months_i,
                days_i,
                canon_h,
                canon_m,
                canon_s,
                canon_us,
                ns_residue_dur,
            )

            # Build timedelta for the sub-month components
            td = datetime.timedelta(
                days=days_i,
                hours=hours_i,
                minutes=minutes_i,
                seconds=seconds_i,
                milliseconds=milliseconds_i,
                microseconds=us_i,
            )
            if years_i != 0 or months_i != 0:
                dur = isodate.Duration(
                    years=years_i,
                    months=months_i,
                    days=td.days,
                    seconds=td.seconds,
                    microseconds=td.microseconds,
                )
                return CypherDuration(dur, _components=canonical)
            else:
                return CypherDuration(td, _components=canonical)
        else:
            raise TypeError(f"DURATION expects string or map, got {type(arg).__name__}")

    # Temporal component extraction functions
    elif func_name == "YEAR":
        if len(args) != 1:
            raise TypeError(f"YEAR expects 1 argument, got {len(args)}")
        if not isinstance(args[0], (CypherDate, CypherDateTime)):
            raise TypeError(f"YEAR expects date or datetime, got {type(args[0]).__name__}")
        return CypherInt(args[0].value.year)

    elif func_name == "MONTH":
        if len(args) != 1:
            raise TypeError(f"MONTH expects 1 argument, got {len(args)}")
        if not isinstance(args[0], (CypherDate, CypherDateTime)):
            raise TypeError(f"MONTH expects date or datetime, got {type(args[0]).__name__}")
        return CypherInt(args[0].value.month)

    elif func_name == "DAY":
        if len(args) != 1:
            raise TypeError(f"DAY expects 1 argument, got {len(args)}")
        if not isinstance(args[0], (CypherDate, CypherDateTime)):
            raise TypeError(f"DAY expects date or datetime, got {type(args[0]).__name__}")
        return CypherInt(args[0].value.day)

    elif func_name == "HOUR":
        if len(args) != 1:
            raise TypeError(f"HOUR expects 1 argument, got {len(args)}")
        if isinstance(args[0], (CypherDateTime, CypherTime)):
            return CypherInt(args[0].value.hour)
        else:
            raise TypeError(f"HOUR expects datetime or time, got {type(args[0]).__name__}")

    elif func_name == "MINUTE":
        if len(args) != 1:
            raise TypeError(f"MINUTE expects 1 argument, got {len(args)}")
        if isinstance(args[0], (CypherDateTime, CypherTime)):
            return CypherInt(args[0].value.minute)
        else:
            raise TypeError(f"MINUTE expects datetime or time, got {type(args[0]).__name__}")

    elif func_name == "SECOND":
        if len(args) != 1:
            raise TypeError(f"SECOND expects 1 argument, got {len(args)}")
        if isinstance(args[0], (CypherDateTime, CypherTime)):
            return CypherInt(args[0].value.second)
        else:
            raise TypeError(f"SECOND expects datetime or time, got {type(args[0]).__name__}")

    elif func_name == "TRUNCATE":
        # truncate(unit, temporal) or temporal.truncate(unit)
        if len(args) != 2:
            raise TypeError(f"TRUNCATE expects 2 arguments, got {len(args)}")

        # First argument is the unit string
        if not isinstance(args[0], CypherString):
            raise TypeError(f"TRUNCATE unit must be string, got {type(args[0]).__name__}")
        unit = args[0].value.lower()

        # Second argument is the temporal value
        temporal = args[1]
        if not isinstance(temporal, (CypherDateTime, CypherDate, CypherTime)):
            raise TypeError(
                f"TRUNCATE expects datetime, date, or time as second argument, "
                f"got {type(temporal).__name__}"
            )

        # Truncate based on unit
        return _truncate_temporal(temporal, unit)

    raise ValueError(f"Unknown temporal function: {func_name}")


def _evaluate_spatial_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate spatial functions.

    Args:
        func_name: Name of the spatial function (uppercase)
        args: List of evaluated arguments (non-NULL)

    Returns:
        CypherValue result of the spatial function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    if func_name == "POINT":
        # point({x: 1.0, y: 2.0}) or point({latitude: 51.5, longitude: -0.1})
        if len(args) != 1:
            raise TypeError(f"POINT expects 1 argument, got {len(args)}")
        if not isinstance(args[0], CypherMap):
            raise TypeError(f"POINT expects map argument, got {type(args[0]).__name__}")

        # Convert CypherMap to dict of Python floats
        coordinates = {}
        for key, val in args[0].value.items():
            if isinstance(val, (CypherInt, CypherFloat)):
                coordinates[key] = float(val.value)
            else:
                raise TypeError(
                    f"POINT coordinate '{key}' must be numeric, got {type(val).__name__}"
                )

        return CypherPoint(coordinates)

    elif func_name == "DISTANCE":
        # distance(point1, point2)
        if len(args) != 2:
            raise TypeError(f"DISTANCE expects 2 arguments, got {len(args)}")
        if not isinstance(args[0], CypherPoint):
            raise TypeError(f"DISTANCE first argument must be point, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherPoint):
            raise TypeError(f"DISTANCE second argument must be point, got {type(args[1]).__name__}")

        p1 = args[0].value
        p2 = args[1].value

        # Check if both points use the same coordinate reference system
        if p1["crs"] != p2["crs"]:
            raise ValueError(
                f"Cannot calculate distance between points with different CRS: "
                f"{p1['crs']} and {p2['crs']}"
            )

        if p1["crs"] == "wgs-84":
            # Use Haversine formula for geographic coordinates
            distance = _haversine_distance(
                p1["latitude"], p1["longitude"], p2["latitude"], p2["longitude"]
            )
        elif p1["crs"] == "cartesian":
            # 2D Euclidean distance
            dx = p2["x"] - p1["x"]
            dy = p2["y"] - p1["y"]
            distance = (dx**2 + dy**2) ** 0.5
        elif p1["crs"] == "cartesian-3d":
            # 3D Euclidean distance
            dx = p2["x"] - p1["x"]
            dy = p2["y"] - p1["y"]
            dz = p2["z"] - p1["z"]
            distance = (dx**2 + dy**2 + dz**2) ** 0.5
        else:
            raise ValueError(f"Unknown coordinate reference system: {p1['crs']}")

        return CypherDistance(distance)

    raise ValueError(f"Unknown spatial function: {func_name}")


def _haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate great-circle distance between two WGS-84 points using Haversine formula.

    Args:
        lat1: Latitude of first point in degrees
        lon1: Longitude of first point in degrees
        lat2: Latitude of second point in degrees
        lon2: Longitude of second point in degrees

    Returns:
        Distance in meters
    """
    import math

    # Earth radius in meters
    earth_radius = 6371000

    # Convert to radians
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)

    # Haversine formula
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return earth_radius * c


def _evaluate_namespaced_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate namespaced functions like date.truncate(), duration.between(), etc.

    Args:
        func_name: Uppercase namespaced name, e.g. 'DATE.TRUNCATE'
        args: Evaluated arguments

    Returns:
        CypherValue result

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    import datetime

    if func_name in (
        "DATE.TRUNCATE",
        "DATETIME.TRUNCATE",
        "LOCALDATETIME.TRUNCATE",
        "TIME.TRUNCATE",
        "LOCALTIME.TRUNCATE",
    ):
        # date.truncate(unit, temporal[, {components}])
        if len(args) < 2:
            raise TypeError(f"{func_name} expects at least 2 arguments, got {len(args)}")
        if len(args) > 3:
            raise TypeError(f"{func_name} expects at most 3 arguments, got {len(args)}")
        if not isinstance(args[0], CypherString):
            raise TypeError(
                f"{func_name} first argument (unit) must be a string, got {type(args[0]).__name__}"
            )
        unit = args[0].value.lower()
        temporal = args[1]
        if not isinstance(temporal, (CypherDateTime, CypherDate, CypherTime)):
            raise TypeError(
                f"{func_name} second argument must be a temporal value, "
                f"got {type(temporal).__name__}"
            )
        result = _truncate_temporal(temporal, unit)
        # Normalize result type to match the expected output type of the function.
        # _truncate_temporal preserves the input type, but each truncate function
        # always returns a specific type regardless of input type.
        if func_name == "DATE.TRUNCATE" and isinstance(result, CypherDateTime):
            # date.truncate always returns CypherDate; extract date from datetime result
            result = CypherDate(result.value.date())
        elif func_name in ("DATETIME.TRUNCATE", "LOCALDATETIME.TRUNCATE") and isinstance(
            result, CypherDate
        ):
            # datetime/localdatetime.truncate with a date input: produce midnight datetime
            result = CypherDateTime(
                datetime.datetime(result.value.year, result.value.month, result.value.day)
            )
        elif (
            func_name == "LOCALDATETIME.TRUNCATE"
            and isinstance(result, CypherDateTime)
            and result.value.tzinfo is not None
        ):
            # localdatetime.truncate always returns a naive datetime; strip the timezone
            result = CypherDateTime(result.value.replace(tzinfo=None))
        # Optional third argument: map of sub-unit components to set after truncation
        if len(args) == 3:
            if not isinstance(args[2], CypherMap):
                raise TypeError(
                    f"{func_name} third argument (components) must be a map, "
                    f"got {type(args[2]).__name__}"
                )
        if len(args) == 3 and isinstance(args[2], CypherMap):
            components = args[2].value

            def _comp(key: str, fallback: int) -> int:
                v = components.get(key)
                if v is not None and not isinstance(v, CypherNull):
                    return int(v.value)
                return fallback

            if isinstance(result, CypherDateTime):
                dt = result.value
                tz = dt.tzinfo
                year = _comp("year", dt.year)
                month = _comp("month", dt.month)
                day = _comp("day", dt.day)
                hour = _comp("hour", dt.hour)
                minute = _comp("minute", dt.minute)
                second = _comp("second", dt.second)
                microsecond = _comp("microsecond", dt.microsecond)
                result = CypherDateTime(
                    datetime.datetime(year, month, day, hour, minute, second, microsecond, tz)
                )
                # Handle dayOfWeek: 1=Monday … 7=Sunday; only valid for week/weekYear units
                if unit in ("week", "weekyear"):
                    dow_v = components.get("dayOfWeek")
                    if dow_v is not None and not isinstance(dow_v, CypherNull):
                        dow = int(dow_v.value)
                        if not 1 <= dow <= 7:
                            raise ValueError(
                                f"dayOfWeek component must be between 1 (Monday) and "
                                f"7 (Sunday), got {dow}"
                            )
                        result = CypherDateTime(result.value + datetime.timedelta(days=dow - 1))
                # Handle timezone override for DATETIME.TRUNCATE and TIME.TRUNCATE
                if func_name in ("DATETIME.TRUNCATE", "TIME.TRUNCATE"):
                    tz_v = components.get("timezone")
                    if tz_v is not None and not isinstance(tz_v, CypherNull):
                        if not isinstance(tz_v, CypherString):
                            raise TypeError(
                                f"'timezone' component must be a string, "
                                f"got {type(tz_v).__name__} ({tz_v!r})"
                            )
                        new_tz = _parse_timezone_str(tz_v.value)
                        result = CypherDateTime(result.value.replace(tzinfo=new_tz))
            elif isinstance(result, CypherDate):
                d = result.value
                year = _comp("year", d.year)
                month = _comp("month", d.month)
                day = _comp("day", d.day)
                result = CypherDate(datetime.date(year, month, day))
                # Handle dayOfWeek: 1=Monday … 7=Sunday; only valid for week/weekYear units
                if unit in ("week", "weekyear"):
                    dow_v = components.get("dayOfWeek")
                    if dow_v is not None and not isinstance(dow_v, CypherNull):
                        dow = int(dow_v.value)
                        if not 1 <= dow <= 7:
                            raise ValueError(
                                f"dayOfWeek component must be between 1 (Monday) and "
                                f"7 (Sunday), got {dow}"
                            )
                        result = CypherDate(result.value + datetime.timedelta(days=dow - 1))
            elif isinstance(result, CypherTime):
                t = result.value
                tz = t.tzinfo
                hour = _comp("hour", t.hour)
                minute = _comp("minute", t.minute)
                second = _comp("second", t.second)
                microsecond = _comp("microsecond", t.microsecond)
                # Handle timezone override for TIME.TRUNCATE
                if func_name == "TIME.TRUNCATE":
                    tz_v = components.get("timezone")
                    if tz_v is not None and not isinstance(tz_v, CypherNull):
                        if not isinstance(tz_v, CypherString):
                            raise TypeError(
                                f"'timezone' component must be a string, "
                                f"got {type(tz_v).__name__} ({tz_v!r})"
                            )
                        tz = _parse_timezone_str(tz_v.value)
                result = CypherTime(datetime.time(hour, minute, second, microsecond, tz))
        # LOCALTIME.TRUNCATE / TIME.TRUNCATE with datetime input: extract time portion
        if func_name == "LOCALTIME.TRUNCATE" and isinstance(result, CypherDateTime):
            result = CypherTime(result.value.time())  # naive time (strip tz)
        elif func_name == "TIME.TRUNCATE" and isinstance(result, CypherDateTime):
            result = CypherTime(result.value.timetz())  # keep timezone
        # LOCALTIME.TRUNCATE always produces a naive time; strip tzinfo if present
        if func_name == "LOCALTIME.TRUNCATE" and isinstance(result, CypherTime):
            if result.value.tzinfo is not None:
                result = CypherTime(result.value.replace(tzinfo=None))
        # DATETIME.TRUNCATE and TIME.TRUNCATE must always produce tz-aware results (UTC default)
        if func_name == "DATETIME.TRUNCATE" and isinstance(result, CypherDateTime):
            if result.value.tzinfo is None:
                result = CypherDateTime(result.value.replace(tzinfo=datetime.timezone.utc))
        elif func_name == "TIME.TRUNCATE" and isinstance(result, CypherTime):
            if result.value.tzinfo is None:
                result = CypherTime(result.value.replace(tzinfo=datetime.timezone.utc))
        return result

    elif func_name == "DURATION.BETWEEN":
        # duration.between(t1, t2) -> duration FROM t1 TO t2 (= t2 - t1)
        if len(args) != 2:
            raise TypeError(f"duration.between() expects 2 arguments, got {len(args)}")
        return _duration_between_calendar(args[1], args[0])

    elif func_name == "DURATION.INMONTHS":
        # duration.inMonths(t1, t2) -> duration in months FROM t1 TO t2
        if len(args) != 2:
            raise TypeError(f"duration.inMonths() expects 2 arguments, got {len(args)}")
        return _duration_in_months(args[1], args[0])

    elif func_name == "DURATION.INDAYS":
        # duration.inDays(t1, t2) -> duration in days FROM t1 TO t2
        if len(args) != 2:
            raise TypeError(f"duration.inDays() expects 2 arguments, got {len(args)}")
        return _duration_in_days(args[1], args[0])

    elif func_name == "DURATION.INSECONDS":
        # duration.inSeconds(t1, t2) -> duration in seconds FROM t1 TO t2
        if len(args) != 2:
            raise TypeError(f"duration.inSeconds() expects 2 arguments, got {len(args)}")
        return _duration_in_seconds(args[1], args[0])

    elif func_name == "DATETIME.FROMEPOCH":
        # datetime.fromepoch(epochSeconds, nanoseconds) -> datetime (UTC)
        if len(args) != 2:
            raise TypeError(f"datetime.fromepoch() expects 2 arguments, got {len(args)}")
        if not isinstance(args[0], (CypherInt, CypherFloat)):
            raise TypeError(
                f"datetime.fromepoch() first argument must be numeric, got {type(args[0]).__name__}"
            )
        if not isinstance(args[1], (CypherInt, CypherFloat)):
            raise TypeError(
                "datetime.fromepoch() second argument must be numeric, "
                f"got {type(args[1]).__name__}"
            )
        epoch_secs = int(args[0].value)
        nanos = int(args[1].value)
        # Convert: epoch_secs full seconds + nanos sub-second (truncate to microseconds)
        micros = nanos // 1000
        dt = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(
            seconds=epoch_secs, microseconds=micros
        )
        return CypherDateTime(dt)

    elif func_name == "DATETIME.FROMEPOCHMILLIS":
        # datetime.fromepochmillis(epochMillis) -> datetime (UTC)
        if len(args) != 1:
            raise TypeError(f"datetime.fromepochmillis() expects 1 argument, got {len(args)}")
        if not isinstance(args[0], (CypherInt, CypherFloat)):
            raise TypeError(
                f"datetime.fromepochmillis() argument must be numeric, got {type(args[0]).__name__}"
            )
        epoch_millis = int(args[0].value)
        dt = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(
            milliseconds=epoch_millis
        )
        return CypherDateTime(dt)

    raise ValueError(f"Unknown namespaced function: {func_name}")


def _to_datetime(val: CypherValue) -> Any:
    """Convert a temporal CypherValue to a datetime.datetime for comparison."""
    import datetime

    from graphforge.types.values import _WideDate, _WideDateTime

    if isinstance(val, CypherDateTime):
        if isinstance(val.value, _WideDateTime):
            raise OverflowError(f"Year {val.value.year} is outside Python datetime range")
        return val.value
    elif isinstance(val, CypherDate):
        if isinstance(val.value, _WideDate):
            # Wide dates can't be converted to datetime.datetime; raise so callers can handle
            raise OverflowError(f"Year {val.value.year} is outside Python datetime range")
        return datetime.datetime.combine(val.value, datetime.time.min)
    elif isinstance(val, CypherTime):
        return datetime.datetime.combine(datetime.date(2000, 1, 1), val.value)
    raise TypeError(f"Expected temporal value, got {type(val).__name__}")


def _get_ymd(val: "CypherValue") -> "tuple[int, int, int, int, int, int, int]":
    """Return (year, month, day, hour, minute, second, microsecond) from any temporal value.

    Works for _WideDate/_WideDateTime-backed values as well as normal Python datetime types.
    """

    from graphforge.types.values import (
        CypherDate,
        CypherDateTime,
        CypherTime,
        _WideDate,
        _WideDateTime,
    )

    if isinstance(val, CypherDateTime):
        d = val.value
        if isinstance(d, _WideDateTime):
            return (d.year, d.month, d.day, d.hour, d.minute, d.second, d.microsecond)
        return (d.year, d.month, d.day, d.hour, d.minute, d.second, d.microsecond)
    if isinstance(val, CypherDate):
        d2 = val.value
        if isinstance(d2, _WideDate):
            return (d2.year, d2.month, d2.day, 0, 0, 0, 0)
        return (d2.year, d2.month, d2.day, 0, 0, 0, 0)
    if isinstance(val, CypherTime):
        t = val.value
        return (0, 1, 1, t.hour, t.minute, t.second, t.microsecond)
    raise TypeError(f"Expected temporal value, got {type(val).__name__}")


def _is_wide_date(val: "CypherValue") -> bool:
    """Return True if val is a CypherDate or CypherDateTime backed by a wide-year type."""
    from graphforge.types.values import CypherDate, CypherDateTime, _WideDate, _WideDateTime

    if isinstance(val, CypherDate) and isinstance(val.value, _WideDate):
        return True
    if isinstance(val, CypherDateTime) and isinstance(val.value, _WideDateTime):
        return True
    return False


def _duration_between_calendar(t1: CypherValue, t2: CypherValue) -> CypherDuration:
    """Calculate a calendar-aware duration from t2 to t1 (t1 - t2).

    Returns an isodate.Duration capturing years, months, days, and sub-day components.
    """
    import datetime

    import isodate

    # Wide-date fast path: pure integer calendar arithmetic (no datetime.date needed)
    if _is_wide_date(t1) or _is_wide_date(t2):
        y1, m1, d1, _, _, _, _ = _get_ymd(t1)
        y2, m2, d2, _, _, _, _ = _get_ymd(t2)
        total_months = (y1 - y2) * 12 + (m1 - m2)
        years = total_months // 12
        months = total_months % 12
        # Remaining days: adjust t2 by years/months, then subtract
        adj_year = y2 + years + (m2 - 1 + months) // 12
        adj_month = ((m2 - 1 + months) % 12) + 1
        import calendar as _cal2

        max_day = _cal2.monthrange(max(1, min(9999, adj_year)), adj_month)[1]
        adj_day = min(d2, max_day)
        rem_days = (
            (y1 * 365 + y1 // 4 - y1 // 100 + y1 // 400)
            + sum(_cal2.monthrange(max(1, min(9999, y1)), _m)[1] for _m in range(1, m1))
            + d1
        ) - (
            (adj_year * 365 + adj_year // 4 - adj_year // 100 + adj_year // 400)
            + sum(
                _cal2.monthrange(max(1, min(9999, adj_year)), _m)[1] for _m in range(1, adj_month)
            )
            + adj_day
        )
        dur = isodate.Duration(years=years, months=months) + datetime.timedelta(days=rem_days)
        components: tuple[int, int, int, int, int, int, int, int] = (
            years,
            months,
            rem_days,
            0,
            0,
            0,
            0,
            0,
        )
        return CypherDuration(dur, _components=components)

    # Cross-type: if either arg is time-only (no date component), compute time difference only
    if isinstance(t1, CypherTime) or isinstance(t2, CypherTime):

        def _get_tc(t: CypherValue) -> datetime.time:
            """Extract time component, preserving tz for CypherDateTime."""
            if isinstance(t, CypherTime):
                return t.value  # type: ignore[no-any-return]
            elif isinstance(t, CypherDateTime):
                return t.value.timetz()  # type: ignore[no-any-return]  # keeps tz if present
            return datetime.time(0, 0, 0)  # CypherDate: midnight

        time1 = _get_tc(t1)
        time2 = _get_tc(t2)

        if time1.tzinfo is not None and time2.tzinfo is not None:
            # Both tz-aware: compare in UTC
            def _utc(t: datetime.time) -> datetime.time:
                dt = datetime.datetime.combine(datetime.date(2000, 1, 1), t)
                return dt.astimezone(datetime.timezone.utc).time()

            time1 = _utc(time1)
            time2 = _utc(time2)
        else:
            # At least one is naive: strip tz from both, compare local values
            time1 = time1.replace(tzinfo=None)
            time2 = time2.replace(tzinfo=None)

        dt1_dummy = datetime.datetime.combine(datetime.date(2000, 1, 1), time1)
        dt2_dummy = datetime.datetime.combine(datetime.date(2000, 1, 1), time2)
        return CypherDuration(dt1_dummy - dt2_dummy)

    # localdatetime (naive CypherDateTime, lhs=t2) + date (rhs=t1):
    # per openCypher, yield a raw timedelta rather than a calendar Duration.
    if isinstance(t2, CypherDateTime) and t2.value.tzinfo is None and isinstance(t1, CypherDate):
        return CypherDuration(_to_datetime(t1) - _to_datetime(t2))

    dt1 = _to_datetime(t1)
    dt2 = _to_datetime(t2)

    # Normalize timezone awareness
    if dt1.tzinfo is not None and dt2.tzinfo is None:
        dt2 = dt2.replace(tzinfo=dt1.tzinfo)
    elif dt1.tzinfo is None and dt2.tzinfo is not None:
        dt1 = dt1.replace(tzinfo=dt2.tzinfo)

    # For tz-aware datetimes, normalize to fixed UTC offsets so that DST-observing
    # named zones (e.g. Europe/Stockholm) don't produce wall-clock arithmetic errors.
    # Python subtracts tz-aware datetimes using wall-clock offsets, which is correct
    # only for fixed-offset zones.  Convert each to its own UTC-offset equivalent.
    if dt1.tzinfo is not None and dt2.tzinfo is not None:
        offset1 = dt1.utcoffset()
        offset2 = dt2.utcoffset()
        if offset1 is not None:
            dt1 = dt1.replace(tzinfo=datetime.timezone(offset1))
        if offset2 is not None:
            dt2 = dt2.replace(tzinfo=datetime.timezone(offset2))

    # Calculate calendar delta (years and months)
    y1, m1 = dt1.year, dt1.month
    y2, m2, d2 = dt2.year, dt2.month, dt2.day

    total_months = (y1 - y2) * 12 + (m1 - m2)
    years = total_months // 12
    months = total_months % 12

    # Remaining days after subtracting year/month portion
    import calendar as _cal

    new_year = dt2.year + years + (dt2.month - 1 + months) // 12
    new_month = ((dt2.month - 1 + months) % 12) + 1
    try:
        adjusted_dt2 = dt2.replace(year=new_year, month=new_month)
    except ValueError:
        # e.g. March 31 + 1 month → April 30 (clamp day)
        max_day = _cal.monthrange(new_year, new_month)[1]
        adjusted_dt2 = dt2.replace(year=new_year, month=new_month, day=min(d2, max_day))

    remaining = dt1 - adjusted_dt2
    # Use truncation-toward-zero to split remaining into whole days + sub-day microseconds.
    # Python normalises negative timedeltas so .days is always negative and .seconds is
    # non-negative (e.g. -22h → days=-1, seconds=7200).  openCypher expects the sub-day
    # portion to carry the sign: -22h → days=0, total_time_seconds=-79200.
    total_rem_us = (
        remaining.days * 86_400 + remaining.seconds
    ) * 1_000_000 + remaining.microseconds
    # Truncation-toward-zero: compute whole days and signed remainder
    if total_rem_us >= 0:
        rem_days = total_rem_us // 86_400_000_000
        rem_time_us = total_rem_us % 86_400_000_000
    else:
        rem_days = -((-total_rem_us) // 86_400_000_000)
        rem_time_us = total_rem_us - rem_days * 86_400_000_000

    # Decompose rem_time_us into h/m/s/us using truncation-toward-zero
    rem_h = int(rem_time_us / 3_600_000_000)
    rem_time_us -= rem_h * 3_600_000_000
    rem_m = int(rem_time_us / 60_000_000)
    rem_time_us -= rem_m * 60_000_000
    rem_s = int(rem_time_us / 1_000_000)
    rem_us = rem_time_us - rem_s * 1_000_000

    dur_td = datetime.timedelta(
        days=rem_days, hours=rem_h, minutes=rem_m, seconds=rem_s, microseconds=rem_us
    )
    dur = isodate.Duration(years=years, months=months) + dur_td
    components = (years, months, rem_days, rem_h, rem_m, rem_s, rem_us, 0)
    return CypherDuration(dur, _components=components)


def _duration_in_months(t1: CypherValue, t2: CypherValue) -> CypherDuration:
    """Return duration between t2 and t1 expressed in whole months only.

    t1 is the destination (rhs), t2 is the origin (lhs). Returns the number of
    complete months in the interval [t2, t1], with the sign indicating direction.
    """
    import math

    import isodate

    # Cross-type: if either arg is time-only, return 0 months
    if isinstance(t1, CypherTime) or isinstance(t2, CypherTime):
        return CypherDuration(isodate.Duration(months=0))

    dt1 = _to_datetime(t1)  # destination
    dt2 = _to_datetime(t2)  # origin
    total_months = (dt1.year - dt2.year) * 12 + (dt1.month - dt2.month)

    # Day-of-month adjustment: the current month boundary hasn't been fully crossed
    # when the destination day hasn't reached the origin day yet (positive direction)
    # or has already passed the origin day (negative direction).
    if total_months > 0 and dt1.day < dt2.day:
        total_months -= 1
    elif total_months < 0 and dt1.day > dt2.day:
        total_months += 1
    elif dt1.day == dt2.day:
        # Same calendar day: refine with sub-day components.
        # Use UTC times when both are tz-aware; otherwise use clock (wall) values.
        import datetime as _dt

        both_aware = dt1.tzinfo is not None and dt2.tzinfo is not None

        def _day_us(dt: Any) -> int:
            d = dt.astimezone(_dt.timezone.utc) if both_aware else dt
            return int(
                d.hour * 3_600_000_000
                + d.minute * 60_000_000
                + d.second * 1_000_000
                + d.microsecond
            )

        to_us = _day_us(dt1)
        from_us = _day_us(dt2)
        if total_months > 0 and to_us < from_us:
            total_months -= 1
        elif total_months < 0 and to_us > from_us:
            total_months += 1

    # Normalise total_months → (years, months) using truncation toward zero so
    # that both components share the same sign (e.g. -23 → years=-1, months=-11).
    years = math.trunc(total_months / 12)
    months = total_months - years * 12
    return CypherDuration(isodate.Duration(years=years, months=months))


def _cypher_duration_isoformat(dur: "CypherDuration") -> str:
    """Serialize a CypherDuration to an openCypher-compliant ISO 8601 duration string.

    openCypher rules (unlike standard ISO 8601):
    - Components with negative values use per-component signs, e.g. P1DT-0.001S
    - Days are NOT normalized into hours (the day/time boundary is preserved)
    - Within the time part, seconds are normalized into minutes/hours
    - Nanoseconds are represented as fractional seconds (max 9 decimal places)

    Uses dur._components (years, months, days, hours, minutes, seconds, microseconds, nanoseconds)
    which are stored with truncation-toward-zero semantics so signs are correct.
    """
    components = dur._components
    years, months, days, hours, minutes, seconds, us = components[:7]
    ns = components[7] if len(components) > 7 else 0

    # Build date part
    date_part = "P"
    if years:
        date_part += f"{years}Y"
    if months:
        date_part += f"{months}M"
    if days:
        date_part += f"{days}D"

    # Build time part
    time_parts: list[str] = []
    if hours:
        time_parts.append(f"{hours}H")
    if minutes:
        time_parts.append(f"{minutes}M")
    if seconds or us or ns:
        if us or ns:
            # Combine seconds, fractional microseconds, and nanosecond residue preserving sign.
            # e.g. seconds=-1, us=-999000, ns=0 → -1 + (-999000/1e6) = -1.999
            s_val = seconds + us / 1_000_000 + ns / 1_000_000_000
            s_str = f"{s_val:.9f}".rstrip("0").rstrip(".")
            time_parts.append(f"{s_str}S")
        else:
            time_parts.append(f"{seconds}S")

    if not time_parts and not days and not years and not months:
        return "PT0S"

    time_str = ("T" + "".join(time_parts)) if time_parts else ""
    return date_part + time_str


def _duration_in_days(t1: CypherValue, t2: CypherValue) -> CypherDuration:
    """Return duration between t2 and t1 expressed in whole days only."""
    import datetime

    # Cross-type: if either arg is time-only, return 0 days
    if isinstance(t1, CypherTime) or isinstance(t2, CypherTime):
        return CypherDuration(datetime.timedelta(0))

    # Special case: tz-aware datetime (lhs=t2) + date (rhs=t1).
    # Coerce the date to the datetime's timezone (midnight in that tz), then take
    # the floor days from the full delta.  Pure date-subtraction overshoots by 1
    # because the lhs time-of-day means the boundary hasn't been crossed yet.
    if (
        isinstance(t2, CypherDateTime)
        and t2.value.tzinfo is not None
        and isinstance(t1, CypherDate)
    ):
        lhs_dt = t2.value
        rhs_dt = datetime.datetime.combine(t1.value, datetime.time.min, lhs_dt.tzinfo)
        delta = rhs_dt - lhs_dt
        return CypherDuration(datetime.timedelta(days=delta.days))

    # Default: use date components only (truncating time avoids off-by-one when time
    # parts cause timedelta.days to round in the wrong direction).
    def _get_date(t: CypherValue) -> datetime.date:
        if isinstance(t, CypherDate):
            return t.value  # type: ignore[no-any-return]
        elif isinstance(t, CypherDateTime):
            return t.value.date()  # type: ignore[no-any-return]
        return datetime.date(2000, 1, 1)

    d1 = _get_date(t1)
    d2 = _get_date(t2)
    delta = d1 - d2
    return CypherDuration(datetime.timedelta(days=delta.days))


def _julian_day_number(year: int, month: int, day: int) -> int:
    """Proleptic Gregorian Julian Day Number for any year."""
    a = (14 - month) // 12
    y = year + 4800 - a
    m = month + 12 * a - 3
    return day + (153 * m + 2) // 5 + 365 * y + y // 4 - y // 100 + y // 400 - 32045


def _duration_in_seconds(t1: CypherValue, t2: CypherValue) -> CypherDuration:
    """Return duration between t2 and t1 expressed in seconds (+ microseconds)."""
    import datetime

    # Wide-date fast path: use Julian Day Numbers so no timedelta overflow
    if _is_wide_date(t1) or _is_wide_date(t2):
        y1, mo1, d1, h1, mi1, s1, us1 = _get_ymd(t1)
        y2, mo2, d2, h2, mi2, s2, us2 = _get_ymd(t2)
        jdn1 = _julian_day_number(y1, mo1, d1)
        jdn2 = _julian_day_number(y2, mo2, d2)
        day_diff = jdn1 - jdn2
        time_us1 = h1 * 3_600_000_000 + mi1 * 60_000_000 + s1 * 1_000_000 + us1
        time_us2 = h2 * 3_600_000_000 + mi2 * 60_000_000 + s2 * 1_000_000 + us2
        total_us = day_diff * 86_400_000_000 + time_us1 - time_us2
        sign = -1 if total_us < 0 else 1
        rem = abs(total_us)
        hours_w = sign * int(rem // 3_600_000_000)
        rem = rem % 3_600_000_000
        minutes_w = sign * int(rem // 60_000_000)
        rem = rem % 60_000_000
        seconds_w = sign * int(rem // 1_000_000)
        us_w = sign * int(rem % 1_000_000)
        # Use _BigDuration to avoid timedelta overflow for extreme values
        from graphforge.types.values import _BigDuration as _BigDur

        val_w = _BigDur(hours=hours_w, minutes=minutes_w, seconds=seconds_w, microseconds=us_w)
        components_w: tuple[int, int, int, int, int, int, int, int] = (
            0,
            0,
            0,
            hours_w,
            minutes_w,
            seconds_w,
            us_w,
            0,
        )
        return CypherDuration(val_w, _components=components_w)

    def _td_to_cypher(delta: datetime.timedelta) -> CypherDuration:
        total_us = round(delta.total_seconds() * 1_000_000)
        # Decompose using truncation-toward-zero.  Floor division (//) gives wrong
        # results for negatives: -5_100_000 // 1_000_000 == -6, not -5.
        sign = -1 if total_us < 0 else 1
        rem = abs(total_us)
        hours = sign * int(rem // 3_600_000_000)
        rem = rem % 3_600_000_000
        minutes = sign * int(rem // 60_000_000)
        rem = rem % 60_000_000
        seconds = sign * int(rem // 1_000_000)
        us = sign * int(rem % 1_000_000)
        components: tuple[int, int, int, int, int, int, int, int] = (
            0,
            0,
            0,
            hours,
            minutes,
            seconds,
            us,
            0,
        )
        td = datetime.timedelta(hours=hours, minutes=minutes, seconds=seconds, microseconds=us)
        return CypherDuration(td, _components=components)

    # Mixed CypherDateTime + CypherTime: use the date from the datetime operand
    # so that DST rules are applied at the correct calendar date.
    if isinstance(t1, CypherTime) and isinstance(t2, CypherDateTime):
        dt2 = _to_datetime(t2)
        # combine() preserves t1.value's tzinfo, so dt1 already carries the time's tz
        dt1 = datetime.datetime.combine(dt2.date(), t1.value)
        if dt1.tzinfo is not None and dt2.tzinfo is not None:
            # Both tz-aware: normalise to UTC for correct elapsed-time arithmetic
            dt1 = dt1.astimezone(datetime.timezone.utc)
            dt2 = dt2.astimezone(datetime.timezone.utc)
        elif dt1.tzinfo is not None:
            # Time has tz, datetime is naive (localdatetime): treat as local clock values
            dt1 = dt1.replace(tzinfo=None)
        elif dt2.tzinfo is not None:
            # Time is naive, datetime has tz: interpret time in the datetime's timezone
            # so that DST rules for that date are applied correctly.
            dt1 = dt1.replace(tzinfo=dt2.tzinfo)
            dt1 = dt1.astimezone(datetime.timezone.utc)
            dt2 = dt2.astimezone(datetime.timezone.utc)
        return _td_to_cypher(dt1 - dt2)

    if isinstance(t2, CypherTime) and isinstance(t1, CypherDateTime):
        dt1 = _to_datetime(t1)
        # combine() preserves t2.value's tzinfo, so dt2 already carries the time's tz
        dt2 = datetime.datetime.combine(dt1.date(), t2.value)
        if dt1.tzinfo is not None and dt2.tzinfo is not None:
            # Both tz-aware: normalise to UTC
            dt1 = dt1.astimezone(datetime.timezone.utc)
            dt2 = dt2.astimezone(datetime.timezone.utc)
        elif dt1.tzinfo is not None:
            # Datetime has tz, time is naive (localtime): treat localtime as being in
            # the datetime's timezone
            dt2 = dt2.replace(tzinfo=dt1.tzinfo)
            dt1 = dt1.astimezone(datetime.timezone.utc)
            dt2 = dt2.astimezone(datetime.timezone.utc)
        elif dt2.tzinfo is not None:
            # Time has tz, datetime is naive (localdatetime): treat as local clock values
            dt2 = dt2.replace(tzinfo=None)
        return _td_to_cypher(dt1 - dt2)

    # Cross-type: if either arg is time-only, compute time difference only
    if isinstance(t1, CypherTime) or isinstance(t2, CypherTime):

        def _get_tc2(t: CypherValue) -> datetime.time:
            if isinstance(t, CypherTime):
                return t.value  # type: ignore[no-any-return]
            elif isinstance(t, CypherDateTime):
                return t.value.timetz()  # type: ignore[no-any-return]
            return datetime.time(0, 0, 0)

        time1 = _get_tc2(t1)
        time2 = _get_tc2(t2)

        if time1.tzinfo is not None and time2.tzinfo is not None:

            def _utc2(t: datetime.time) -> datetime.time:
                dt = datetime.datetime.combine(datetime.date(2000, 1, 1), t)
                return dt.astimezone(datetime.timezone.utc).time()

            time1 = _utc2(time1)
            time2 = _utc2(time2)
        else:
            time1 = time1.replace(tzinfo=None)
            time2 = time2.replace(tzinfo=None)

        dt1_dummy = datetime.datetime.combine(datetime.date(2000, 1, 1), time1)
        dt2_dummy = datetime.datetime.combine(datetime.date(2000, 1, 1), time2)
        delta = dt1_dummy - dt2_dummy
        total_us = round(delta.total_seconds() * 1_000_000)
        total_secs = total_us // 1_000_000
        us_remainder = total_us % 1_000_000
        return CypherDuration(datetime.timedelta(seconds=total_secs, microseconds=us_remainder))

    dt1 = _to_datetime(t1)
    dt2 = _to_datetime(t2)
    if dt1.tzinfo is not None and dt2.tzinfo is None:
        dt2 = dt2.replace(tzinfo=dt1.tzinfo)
    elif dt1.tzinfo is None and dt2.tzinfo is not None:
        dt1 = dt1.replace(tzinfo=dt2.tzinfo)
    # Convert both to UTC to handle DST correctly.
    # Using the same IANA tzinfo object with replace() causes Python to use
    # wall-clock difference instead of elapsed UTC time across DST boundaries.
    if dt1.tzinfo is not None:
        dt1 = dt1.astimezone(datetime.timezone.utc)
    if dt2.tzinfo is not None:
        dt2 = dt2.astimezone(datetime.timezone.utc)
    delta = dt1 - dt2
    total_us = round(delta.total_seconds() * 1_000_000)
    total_secs = total_us // 1_000_000
    us_remainder = total_us % 1_000_000
    return CypherDuration(datetime.timedelta(seconds=total_secs, microseconds=us_remainder))


def _evaluate_graph_function(
    func_name: str,
    args: Sequence[NodeRef | EdgeRef | CypherValue],
    ctx: "ExecutionContext | None" = None,
) -> CypherValue:
    """Evaluate graph element functions.

    These functions work with graph elements (nodes, relationships) rather than
    just CypherValues. They handle NodeRef and EdgeRef objects directly.

    Args:
        func_name: Name of the graph function (uppercase)
        args: List of evaluated arguments (may include NodeRef/EdgeRef)

    Returns:
        CypherValue result of the graph function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    if func_name == "ID":
        # id(node) or id(relationship)
        if len(args) != 1:
            raise TypeError(f"ID expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a node or relationship
        if isinstance(arg, (NodeRef, EdgeRef)):
            # Return the internal ID as an integer
            id_value = arg.id
            # ID might be int or str, convert to int if string
            if isinstance(id_value, str):
                try:
                    id_value = int(id_value)
                except ValueError:
                    # If ID is a non-numeric string, hash it to get an int
                    id_value = hash(id_value)
            return CypherInt(id_value)

        raise TypeError(f"ID expects node or relationship argument, got {type(arg).__name__}")

    if func_name == "ELEMENTID":
        # elementId(node) or elementId(relationship) — returns id as string (GQL spec)
        if len(args) != 1:
            raise TypeError(f"elementId expects 1 argument, got {len(args)}")
        arg = args[0]
        if isinstance(arg, CypherNull):
            return CypherNull()
        if isinstance(arg, (NodeRef, EdgeRef)):
            return CypherString(str(arg.id))
        raise TypeError(
            f"elementId expects node or relationship argument, got {type(arg).__name__}"
        )

    if func_name == "LABELS":
        # labels(node) - returns list of label strings for a node
        if len(args) != 1:
            raise TypeError(f"LABELS expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a node
        if isinstance(arg, NodeRef):
            # Check if entity was deleted in this execution context
            if ctx is not None and hasattr(ctx, "deleted_ids") and arg.id in ctx.deleted_ids:
                raise EntityNotFoundError(
                    "DeletedEntityAccess: Tried to access labels of a deleted entity"
                )
            # Return labels as a sorted list of CypherStrings
            labels_list: list[CypherValue] = [CypherString(label) for label in sorted(arg.labels)]
            return CypherList(labels_list)

        raise TypeError(f"LABELS expects node argument, got {type(arg).__name__}")

    if func_name == "PROPERTIES":
        # properties(node|relationship|map) - returns a map of all properties
        if len(args) != 1:
            raise TypeError(f"PROPERTIES expects 1 argument, got {len(args)}")

        arg = args[0]

        if isinstance(arg, CypherNull):
            return CypherNull()

        if isinstance(arg, (NodeRef, EdgeRef)):
            return CypherMap(dict(arg.properties))

        if isinstance(arg, CypherMap):
            return CypherMap(dict(arg.value))

        raise TypeError(
            f"PROPERTIES expects node, relationship, or map argument, got {type(arg).__name__}"
        )

    if func_name == "KEYS":
        # keys(node|relationship|map) - returns a list of property key strings
        if len(args) != 1:
            raise TypeError(f"KEYS expects 1 argument, got {len(args)}")

        arg = args[0]

        if isinstance(arg, CypherNull):
            return CypherNull()

        if isinstance(arg, (NodeRef, EdgeRef)):
            keys_list: list[CypherValue] = [CypherString(k) for k in sorted(arg.properties)]
            return CypherList(keys_list)

        if isinstance(arg, CypherMap):
            keys_list = [CypherString(k) for k in sorted(arg.value)]
            return CypherList(keys_list)

        raise TypeError(
            f"KEYS expects node, relationship, or map argument, got {type(arg).__name__}"
        )

    if func_name == "STARTNODE":
        # startNode(relationship) - returns the start node of a relationship
        if len(args) != 1:
            raise TypeError(f"STARTNODE expects 1 argument, got {len(args)}")

        arg = args[0]

        if isinstance(arg, CypherNull):
            return CypherNull()

        if isinstance(arg, EdgeRef):
            return arg.src  # type: ignore[return-value]

        raise TypeError(f"STARTNODE expects relationship argument, got {type(arg).__name__}")

    if func_name == "ENDNODE":
        # endNode(relationship) - returns the end node of a relationship
        if len(args) != 1:
            raise TypeError(f"ENDNODE expects 1 argument, got {len(args)}")

        arg = args[0]

        if isinstance(arg, CypherNull):
            return CypherNull()

        if isinstance(arg, EdgeRef):
            return arg.dst  # type: ignore[return-value]

        raise TypeError(f"ENDNODE expects relationship argument, got {type(arg).__name__}")

    raise ValueError(f"Unknown graph function: {func_name}")


def _evaluate_path_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate path functions.

    These functions work with CypherPath values.

    Args:
        func_name: Name of the path function (uppercase)
        args: List of evaluated arguments

    Returns:
        CypherValue result of the path function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    from graphforge.types.values import CypherPath

    if func_name == "LENGTH":
        # length(path) - returns the number of relationships in the path
        if len(args) != 1:
            raise TypeError(f"LENGTH expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a path
        if isinstance(arg, CypherPath):
            return CypherInt(arg.length())

        raise TypeError(f"LENGTH expects path argument, got {type(arg).__name__}")

    if func_name == "NODES":
        # nodes(path) - returns a list of nodes in the path
        if len(args) != 1:
            raise TypeError(f"NODES expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a path
        if isinstance(arg, CypherPath):
            # Return nodes as a list (NodeRef objects are stored directly)
            # Note: We store NodeRef objects directly in the list, not wrapped in CypherValues
            # This is consistent with how graph elements are handled elsewhere
            return CypherList(arg.nodes)  # type: ignore[arg-type]

        raise TypeError(f"NODES expects path argument, got {type(arg).__name__}")

    if func_name == "RELATIONSHIPS":
        # relationships(path) - returns a list of relationships in the path
        if len(args) != 1:
            raise TypeError(f"RELATIONSHIPS expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a path
        if isinstance(arg, CypherPath):
            # Return relationships as a list (EdgeRef objects are stored directly)
            # Note: We store EdgeRef objects directly in the list, not wrapped in CypherValues
            # This is consistent with how graph elements are handled elsewhere
            return CypherList(arg.relationships)  # type: ignore[arg-type]

        raise TypeError(f"RELATIONSHIPS expects path argument, got {type(arg).__name__}")

    if func_name == "HEAD":
        # head(path) - returns the first node in the path
        if len(args) != 1:
            raise TypeError(f"HEAD expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a path
        if isinstance(arg, CypherPath):
            if len(arg.nodes) == 0:
                return CypherNull()
            return arg.nodes[0]  # type: ignore[return-value]

        raise TypeError(f"HEAD expects path argument, got {type(arg).__name__}")

    if func_name == "LAST":
        # last(path) - returns the last node in the path
        if len(args) != 1:
            raise TypeError(f"LAST expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a path
        if isinstance(arg, CypherPath):
            if len(arg.nodes) == 0:
                return CypherNull()
            return arg.nodes[-1]  # type: ignore[return-value]

        raise TypeError(f"LAST expects path argument, got {type(arg).__name__}")

    raise ValueError(f"Unknown path function: {func_name}")


def _evaluate_list_function(func_name: str, args: list[CypherValue]) -> CypherValue:
    """Evaluate list functions.

    These functions work with CypherList values.

    Args:
        func_name: Name of the list function (uppercase)
        args: List of evaluated arguments

    Returns:
        CypherValue result of the list function

    Raises:
        ValueError: If function is unknown
        TypeError: If arguments have invalid types
    """
    if func_name == "TAIL":
        # tail(list) - returns all elements except the first
        if len(args) != 1:
            raise TypeError(f"TAIL expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a list
        if isinstance(arg, CypherList):
            if len(arg.value) == 0:
                return CypherList([])
            return CypherList(arg.value[1:])

        raise TypeError(f"TAIL expects list argument, got {type(arg).__name__}")

    if func_name == "HEAD":
        # head(list) - returns the first element or NULL for empty list
        if len(args) != 1:
            raise TypeError(f"HEAD expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a list
        if isinstance(arg, CypherList):
            if len(arg.value) == 0:
                return CypherNull()
            first_element: CypherValue = arg.value[0]
            return first_element

        raise TypeError(f"HEAD expects list argument, got {type(arg).__name__}")

    if func_name == "LAST":
        # last(list) - returns the last element or NULL for empty list
        if len(args) != 1:
            raise TypeError(f"LAST expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a list
        if isinstance(arg, CypherList):
            if len(arg.value) == 0:
                return CypherNull()
            last_element: CypherValue = arg.value[-1]
            return last_element

        raise TypeError(f"LAST expects list argument, got {type(arg).__name__}")

    if func_name == "REVERSE":
        # reverse(list) - returns list with elements in reverse order
        if len(args) != 1:
            raise TypeError(f"REVERSE expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a list
        if isinstance(arg, CypherList):
            return CypherList(list(reversed(arg.value)))

        raise TypeError(f"REVERSE expects list argument, got {type(arg).__name__}")

    if func_name == "RANGE":
        # range(start, end) or range(start, end, step)
        if len(args) < 2 or len(args) > 3:
            raise TypeError(f"RANGE expects 2 or 3 arguments, got {len(args)}")

        # Validate argument types
        if not isinstance(args[0], CypherInt):
            raise TypeError(f"RANGE start must be integer, got {type(args[0]).__name__}")
        if not isinstance(args[1], CypherInt):
            raise TypeError(f"RANGE end must be integer, got {type(args[1]).__name__}")

        start = args[0].value
        end = args[1].value
        step = 1

        if len(args) == 3:
            if not isinstance(args[2], CypherInt):
                raise TypeError(f"RANGE step must be integer, got {type(args[2]).__name__}")
            step = args[2].value

            # Validate step is not zero
            if step == 0:
                raise ValueError("RANGE step cannot be zero")

        # Generate range
        result_list: list[CypherValue] = []
        if step > 0:
            current = start
            while current <= end:
                result_list.append(CypherInt(current))
                current += step
        else:  # step < 0
            current = start
            while current >= end:
                result_list.append(CypherInt(current))
                current += step

        return CypherList(result_list)

    if func_name == "SIZE":
        # size(list) - returns the number of elements in the list
        if len(args) != 1:
            raise TypeError(f"SIZE expects 1 argument, got {len(args)}")

        arg = args[0]

        # Handle NULL
        if isinstance(arg, CypherNull):
            return CypherNull()

        # Check if argument is a list
        if isinstance(arg, CypherList):
            return CypherInt(len(arg.value))

        raise TypeError(f"SIZE expects list argument, got {type(arg).__name__}")

    raise ValueError(f"Unknown list function: {func_name}")
