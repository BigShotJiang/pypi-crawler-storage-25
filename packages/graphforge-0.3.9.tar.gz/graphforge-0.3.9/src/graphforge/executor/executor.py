"""Query executor that executes logical plans.

This module implements the execution engine that runs logical plan operators
against a graph store.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Any

from graphforge.ast.expression import (
    BinaryOp,
    CaseExpression,
    FunctionCall,
    ListComprehension,
    Literal,
    ParenthesizedExpr,
    PropertyAccess,
    QuantifierExpression,
    SubqueryExpression,
    UnaryOp,
    Variable,
)
from graphforge.executor.evaluator import ExecutionContext, evaluate_expression
from graphforge.planner.operators import (
    Aggregate,
    ApplyOptional,
    AssemblePath,
    Create,
    Delete,
    Distinct,
    ExpandEdges,
    ExpandMultiHop,
    ExpandVariableLength,
    Filter,
    Limit,
    Merge,
    OptionalExpandEdges,
    OptionalScanNodes,
    Project,
    Remove,
    ScanNodes,
    Set,
    Skip,
    Sort,
    Subquery,
    Union,
    Unwind,
    With,
)
from graphforge.storage.memory import Graph
from graphforge.types.values import (
    CypherBool,
    CypherDateTime,
    CypherDuration,
    CypherFloat,
    CypherInt,
    CypherList,
    CypherMap,
    CypherNull,
    CypherPath,
    CypherString,
    CypherTime,
    CypherValue,
    from_python,
)

if TYPE_CHECKING:
    from graphforge.types.graph import NodeRef


class SemanticError(Exception):
    """Runtime semantic error (e.g. MergeReadOwnWrites, type mismatches)."""


def _unwrap_cypher_val(val: Any) -> Any:
    """Unwrap a CypherValue to its Python primitive for procedure argument passing."""
    if isinstance(val, CypherNull):
        return None
    if isinstance(val, (CypherInt, CypherFloat, CypherBool, CypherString)):
        return val.value
    if isinstance(val, CypherList):
        return [_unwrap_cypher_val(v) for v in val.value]
    if isinstance(val, CypherMap):
        return {k: _unwrap_cypher_val(v) for k, v in val.value.items()}
    return val  # NodeRef / EdgeRef / raw value — pass as-is


def _python_to_cypher(val: Any) -> Any:
    """Wrap a Python primitive in the appropriate CypherValue."""
    if val is None:
        return CypherNull()
    if isinstance(val, bool):
        return CypherBool(val)
    if isinstance(val, int):
        return CypherInt(val)
    if isinstance(val, float):
        return CypherFloat(val)
    if isinstance(val, str):
        return CypherString(val)
    if isinstance(val, list):
        return CypherList([_python_to_cypher(v) for v in val])
    if isinstance(val, dict):
        return CypherMap({k: _python_to_cypher(v) for k, v in val.items()})
    return val  # Already a CypherValue / NodeRef / EdgeRef


def _check_proc_arg_type(param: Any, py_val: Any, proc_name: str, idx: int) -> None:
    """Validate that a Python value matches the procedure parameter type.

    Raises SyntaxError with code InvalidArgumentType on mismatch.
    Coercion rules: INTEGER is accepted for FLOAT and NUMBER; FLOAT is accepted
    for NUMBER.  Any other mismatch raises.
    """
    ctype = param.cypher_type.upper()
    if ctype in ("ANY", "ANY?"):
        return
    # Allowed Python types per Cypher type
    type_map = {
        "STRING": str,
        "INTEGER": int,
        "FLOAT": (int, float),  # int coerces to float
        "NUMBER": (int, float),
        "BOOLEAN": bool,
        "LIST": list,
        "MAP": dict,
    }
    # Booleans are subclass of int in Python — reject bool for INTEGER/FLOAT/NUMBER
    if isinstance(py_val, bool) and ctype in ("INTEGER", "FLOAT", "NUMBER"):
        raise SyntaxError(
            f"InvalidArgumentType — procedure `{proc_name}` parameter {idx + 1} "
            f"expects {param.cypher_type}, got BOOLEAN"
        )
    expected = type_map.get(ctype)
    if expected is not None and not isinstance(py_val, expected):  # type: ignore[arg-type]
        raise SyntaxError(
            f"InvalidArgumentType — procedure `{proc_name}` parameter {idx + 1} "
            f"expects {param.cypher_type}, got {type(py_val).__name__}"
        )


def _cypher_type_rank(val: Any) -> int:
    """Return numeric sort rank per openCypher type hierarchy.

    ASC order per openCypher spec:
      Map < Node < Relationship < List < Path < String < Boolean < Integer/Float
    NULL and NaN are handled separately in compare_cypher_values.
    """
    from graphforge.types.graph import EdgeRef, NodeRef as _NodeRef  # noqa: I001

    if isinstance(val, CypherMap):
        return 1
    if isinstance(val, _NodeRef):
        return 2
    if isinstance(val, EdgeRef):
        return 3
    if isinstance(val, CypherList):
        return 4
    if isinstance(val, CypherPath):
        return 5
    if isinstance(val, CypherString):
        return 6
    if isinstance(val, CypherBool):
        return 7
    if isinstance(val, (CypherInt, CypherFloat)):
        return 8
    return 9


def compare_cypher_values(val1: Any, val2: Any, ascending: bool) -> int:
    """Compare two Cypher values per openCypher sort semantics.

    Handles NULLs (last in ASC, first in DESC), NaN (after regular numeric values,
    before NULL within the numeric rank), and cross-type comparisons using the
    openCypher type hierarchy.

    ASC order: Map < Node < Relationship < List < Path < String < Boolean < Number < NaN < NULL
    """
    is_null1 = isinstance(val1, CypherNull)
    is_null2 = isinstance(val2, CypherNull)

    if is_null1 and is_null2:
        return 0
    if is_null1:
        return 1 if ascending else -1  # NULLs last in ASC, first in DESC
    if is_null2:
        return -1 if ascending else 1

    is_nan1 = isinstance(val1, CypherFloat) and math.isnan(val1.value)
    is_nan2 = isinstance(val2, CypherFloat) and math.isnan(val2.value)
    if is_nan1 and is_nan2:
        return 0

    rank1 = _cypher_type_rank(val1)
    rank2 = _cypher_type_rank(val2)
    if rank1 != rank2:
        diff = rank1 - rank2
        return diff if ascending else -diff

    # Within numeric rank: NaN sorts after regular numbers, before null
    if is_nan1:
        return 1 if ascending else -1
    if is_nan2:
        return -1 if ascending else 1

    # List comparison: element-by-element using full compare_cypher_values semantics
    # so that cross-type element comparisons (e.g. int vs null) are handled correctly.
    if isinstance(val1, CypherList) and isinstance(val2, CypherList):
        # strict=False: shorter list exhausts first; length diff handled below
        for a, b in zip(val1.value, val2.value, strict=False):
            cmp = compare_cypher_values(a, b, ascending=True)
            if cmp != 0:
                return cmp if ascending else -cmp
        # All shared elements equal; shorter list is smaller
        len_diff = len(val1.value) - len(val2.value)
        if len_diff != 0:
            sign = 1 if len_diff > 0 else -1
            return sign if ascending else -sign
        return 0

    # Same type rank — use less_than for intra-type ordering
    result = val1.less_than(val2)
    if isinstance(result, CypherBool):
        if result.value:
            return -1 if ascending else 1
        result2 = val2.less_than(val1)
        if isinstance(result2, CypherBool) and result2.value:
            return 1 if ascending else -1
        return 0
    return 0


def _cypher_to_python(cypher_val: CypherValue) -> Any:
    """Convert CypherValue to Python value for storage.

    Recursively converts CypherList and CypherMap to Python list and dict.

    Args:
        cypher_val: CypherValue to convert

    Returns:
        Python value (None, bool, int, float, str, list, dict)
    """
    if isinstance(cypher_val, CypherNull):
        return None
    elif isinstance(cypher_val, (CypherBool, CypherInt, CypherFloat)):
        return cypher_val.value
    elif isinstance(cypher_val, CypherList):
        return [_cypher_to_python(item) for item in cypher_val.value]
    elif isinstance(cypher_val, CypherMap):
        return {k: _cypher_to_python(v) for k, v in cypher_val.value.items()}
    elif isinstance(cypher_val, (CypherDateTime, CypherTime)):
        # Preserve the CypherValue wrapper so _ns_residue is not lost during graph storage
        return cypher_val
    elif isinstance(cypher_val, CypherDuration):
        # Preserve wrapper only when ns_residue is present, but rebuild _components from
        # the underlying value so date arithmetic gets the timedelta-normalised day count.
        ns = cypher_val._components[7] if len(cypher_val._components) > 7 else 0
        if ns:
            from graphforge.types.values import _components_from_value as _cfv

            new_c = (*_cfv(cypher_val.value)[:7], ns)
            return CypherDuration(cypher_val.value, _components=new_c)
        return cypher_val.value
    else:
        # CypherString, CypherDate, or any other type
        return cypher_val.value


def _expression_to_string(expr: Any, fallback_index: int | None = None) -> str:
    """Convert AST expression to its Cypher string representation.

    Used for generating column names when no explicit alias is provided.

    Args:
        expr: AST expression node
        fallback_index: Optional index to append to ambiguous/fallback names
                       for uniqueness (e.g., "CASE ... END_0", "expr_1")

    Returns:
        String representation of the expression
    """
    # Variable reference
    if isinstance(expr, Variable):
        return expr.name

    # Property access — may be nested (a.b.c uses base=PropertyAccess)
    if isinstance(expr, PropertyAccess):
        if expr.base is not None:
            base_name = _expression_to_string(expr.base)
            return f"{base_name}.{expr.property}"
        return f"{expr.variable}.{expr.property}"

    # Literal value
    if isinstance(expr, Literal):
        value = expr.value
        if value is None:
            return "null"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif isinstance(value, str):
            # Use single quotes for string literals in Cypher
            return f"'{value}'"
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, list):
            # List literal - format items directly
            def format_item(item: Any) -> str:
                if item is None:
                    return "null"
                elif isinstance(item, bool):
                    return "true" if item else "false"
                elif isinstance(item, str):
                    return f"'{item}'"
                else:
                    return str(item)

            items = [format_item(item) for item in value]
            return f"[{', '.join(items)}]"
        elif isinstance(value, dict):
            # Map literal - format values directly
            def format_value(v: Any) -> str:
                if v is None:
                    return "null"
                elif isinstance(v, bool):
                    return "true" if v else "false"
                elif isinstance(v, str):
                    return f"'{v}'"
                else:
                    return str(v)

            pairs = [f"{k}: {format_value(v)}" for k, v in value.items()]
            return f"{{{', '.join(pairs)}}}"
        else:
            return str(value)

    # Function call
    if isinstance(expr, FunctionCall):
        func_name = expr.name.lower()
        if not expr.args:
            # COUNT(*) special case
            return f"{func_name}(*)"
        args = [_expression_to_string(arg) for arg in expr.args]
        distinct_prefix = "DISTINCT " if expr.distinct else ""
        return f"{func_name}({distinct_prefix}{', '.join(args)})"

    # Explicitly parenthesized expression — preserve the parens in the column name
    if isinstance(expr, ParenthesizedExpr):
        return f"({_expression_to_string(expr.expr)})"

    # Binary operation
    if isinstance(expr, BinaryOp):
        left_str = _expression_to_string(expr.left)
        right_str = _expression_to_string(expr.right)
        # Column names reproduce the expression as written — no extra parens.
        # The AST already encodes correct evaluation order; parens are only added
        # when explicitly present in the original source (handled by ParenthesizedExpr).
        return f"{left_str} {expr.op} {right_str}"

    # Unary operation
    if isinstance(expr, UnaryOp):
        operand_str = _expression_to_string(expr.operand)
        if expr.op == "IS NULL":
            return f"{operand_str} IS NULL"
        elif expr.op == "IS NOT NULL":
            return f"{operand_str} IS NOT NULL"
        elif expr.op == "NOT":
            return f"NOT {operand_str}"
        elif expr.op == "-":
            return f"-{operand_str}"
        else:
            return f"{expr.op} {operand_str}"

    # CASE expression
    if isinstance(expr, CaseExpression):
        base = "CASE ... END"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # List comprehension
    if isinstance(expr, ListComprehension):
        base = "[...]"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Quantifier expression
    if isinstance(expr, QuantifierExpression):
        base = f"{expr.quantifier}(...)"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Subquery expression
    if isinstance(expr, SubqueryExpression):
        base = f"{expr.type} {{ ... }}"
        return f"{base}_{fallback_index}" if fallback_index is not None else base

    # Fallback for unknown expression types
    base = "expr"
    return f"{base}_{fallback_index}" if fallback_index is not None else base


def _return_item_key(return_item: Any, fallback_index: int | None = None) -> str:
    """Determine the column key for a return item.

    Prefers explicit alias, then original source text (for exact TCK column-name
    matching), then falls back to _expression_to_string reconstruction.
    """
    if return_item.alias:
        return str(return_item.alias)
    source_text: str | None = getattr(return_item, "source_text", None)
    if source_text:
        return source_text
    return _expression_to_string(return_item.expression, fallback_index=fallback_index)


class QueryExecutor:
    """Executes logical query plans against a graph.

    The executor processes a pipeline of operators, streaming rows through
    each stage of the query.
    """

    def __init__(self, graph: Graph, graphforge=None, planner=None, procedure_registry=None):
        """Initialize executor with a graph.

        Args:
            graph: The graph to query
            graphforge: Optional GraphForge instance for CREATE operations
            planner: Optional QueryPlanner instance for subquery execution
            procedure_registry: Optional ProcedureRegistry for CALL proc invocations
        """
        self.graph = graph
        self.graphforge = graphforge
        self.planner = planner
        self.procedure_registry = procedure_registry
        self.custom_functions: dict[str, Any] = {}
        # Statement clock: set once per query execution so zero-arg temporal functions
        # (datetime(), localtime(), etc.) return the same value within a single statement.
        self._statement_clock_ns: int = 0

    def execute(self, operators: list, parameters: dict | None = None) -> list[dict]:
        """Execute a pipeline of operators.

        Args:
            operators: List of logical plan operators
            parameters: Optional query parameters (for $param references and implicit CALL args).

        Returns:
            List of result rows (dicts mapping column names to values)
        """
        # Capture statement clock once so all zero-arg temporal functions (datetime(),
        # localtime(), etc.) return the same value within this statement execution.
        import time as _time_module

        self._statement_clock_ns = _time_module.time_ns()

        # Start with empty context, optionally pre-seeded with $parameters
        seed_ctx = ExecutionContext()
        if parameters:
            from graphforge.executor.executor import _python_to_cypher

            for pname, pval in parameters.items():
                seed_ctx.bind(f"${pname}", _python_to_cypher(pval))
        self._seed_ctx = seed_ctx
        rows: list[Any] = [seed_ctx]

        # Execute each operator in sequence
        for i, op in enumerate(operators):
            rows = self._execute_operator(op, rows, i, len(operators), operators)

        # If there's no Project or Aggregate operator in the pipeline (no RETURN clause),
        # return empty results (Cypher semantics: queries without RETURN produce no output)
        # Exception 1: Union operators contain their own RETURN clauses in branches
        # Exception 2: Standalone CALL to a procedure that yields output columns —
        #   the procedure columns become the result set directly (no RETURN needed)
        from graphforge.planner.operators import ProcedureCall as _ProcedureCall

        has_projection = any(isinstance(op, (Project, Aggregate, Union)) for op in operators)
        # A query ending in a write op (Delete/Set/Remove/Merge/Create) with no trailing
        # RETURN produces no output even if an intermediate Aggregate (WITH) is present.
        _trailing_write = operators and isinstance(
            operators[-1], (Delete, Set, Remove, Merge, Create)
        )
        if operators and (not has_projection or _trailing_write):
            # Check if the pipeline ends with a procedure call that has outputs
            if isinstance(operators[-1], _ProcedureCall):
                # Expose procedure output columns only (exclude anonymous and $param bindings)
                return [
                    {
                        k: v
                        for k, v in row.bindings.items()
                        if not k.startswith("__anon_") and not k.startswith("$")
                    }
                    if isinstance(row, ExecutionContext)
                    else row
                    for row in rows
                ]
            return []

        # When Sort is the last operator after Aggregate (for_with=True), rows are still
        # ExecutionContexts. Convert them to dicts here (per-row to handle Union branches).
        rows = [
            {k: v for k, v in row.bindings.items() if not k.startswith("__anon_")}
            if isinstance(row, ExecutionContext)
            else row
            for row in rows
        ]

        return rows

    @staticmethod
    def _extract_equality_hints(
        operators: list, from_index: int, variable: str
    ) -> list[tuple[str, object]]:
        """Return (prop_name, value) pairs from simple equality predicates on `variable`.

        Looks at the operator immediately after `from_index`. If it is a Filter whose
        predicate (or top-level AND chain) contains only `variable.prop = <literal>`
        equalities, return those pairs so the scan can use the property index.

        Returns an empty list if the next operator is not a Filter, if the predicate
        is too complex to push down, or if operators/from_index are invalid.
        """
        from graphforge.ast.expression import BinaryOp, Literal, PropertyAccess

        if not operators or from_index + 1 >= len(operators):
            return []
        next_op = operators[from_index + 1]
        if not isinstance(next_op, Filter):
            return []

        def _collect(pred: object) -> list[tuple[str, object]] | None:
            if isinstance(pred, BinaryOp):
                if pred.op == "=":
                    if (
                        isinstance(pred.left, PropertyAccess)
                        and pred.left.variable == variable
                        and isinstance(pred.right, Literal)
                    ):
                        val = pred.right.value
                        return [(pred.left.property, val)]
                    if (
                        isinstance(pred.right, PropertyAccess)
                        and pred.right.variable == variable
                        and isinstance(pred.left, Literal)
                    ):
                        val = pred.left.value
                        return [(pred.right.property, val)]
                if pred.op == "AND":
                    left = _collect(pred.left)
                    right = _collect(pred.right)
                    if left is not None and right is not None:
                        return left + right
            return None

        result = _collect(next_op.predicate)
        return result if result is not None else []

    @staticmethod
    def _pipeline_limit(operators: list, from_index: int) -> int | None:
        """Return the effective row budget visible from `from_index`, or None.

        Scans the remaining pipeline in reverse to propagate downstream demand
        back to the caller. Starting from the rightmost operator and working
        left, each static Limit sets the demand; each transparent With
        (no sort, predicate, or distinct — only a static limit_count/skip_count)
        translates that demand: upstream_rows = with_skip + min(with_limit, demand).
        Bare Skip operators add their count to the accumulated demand.
        Any blocking operator (Sort, Aggregate, Distinct, Filter, write ops)
        terminates the scan and returns None.
        Returns None if any dynamic (non-literal) Skip/Limit is encountered.
        """
        from graphforge.ast.expression import Literal

        _blocking = (Sort, Aggregate, Distinct, Filter, Create, Set, Remove, Delete, Merge)
        best: int | None = None
        for op in reversed(operators[from_index + 1 :]):
            if isinstance(op, _blocking):
                # Blocking op between from_index and any Limit — can't short-circuit.
                best = None
                break
            if isinstance(op, With):
                # Transparent only when With acts as a pure row-limiter:
                # no sort, no filter predicate, no distinct — only a static limit_count
                # (and optionally a static skip_count).
                if (
                    op.limit_count is not None
                    and not op.sort_items
                    and op.predicate is None
                    and not op.distinct
                    and isinstance(op.limit_count, Literal)
                    and isinstance(op.limit_count.value, int)
                    and (
                        op.skip_count is None
                        or (
                            isinstance(op.skip_count, Literal)
                            and isinstance(op.skip_count.value, int)
                        )
                    )
                ):
                    with_skip = op.skip_count.value if op.skip_count is not None else 0
                    # Clamp downstream demand by this With's limit, then add its skip.
                    # best=None means no Limit seen yet — With's own limit is the cap.
                    effective = (
                        op.limit_count.value if best is None else min(op.limit_count.value, best)
                    )
                    best = with_skip + effective
                else:
                    best = None
                    break
            elif isinstance(op, Skip):
                if isinstance(op.count, Literal) and isinstance(op.count.value, int):
                    # Skip adds to upstream demand (more rows needed to satisfy downstream).
                    if best is not None:
                        best += op.count.value
                    # If best is None, no limit downstream — skip doesn't constrain.
                else:
                    if best is not None:
                        best = None  # dynamic skip after a known limit — can't determine
                    break
            elif isinstance(op, Limit):
                if isinstance(op.count, Literal) and isinstance(op.count.value, int):
                    best = op.count.value if best is None else min(best, op.count.value)
                else:
                    best = None
                    break
        return best

    def _execute_operator(
        self,
        op,
        input_rows: list[Any],
        op_index: int,
        total_ops: int,
        operators: list | None = None,
    ) -> list[Any]:
        """Execute a single operator.

        Args:
            op: Logical plan operator
            input_rows: Input execution contexts
            op_index: Index of current operator in pipeline
            total_ops: Total number of operators in pipeline
            operators: Full operator pipeline (used for LIMIT look-ahead)

        Returns:
            Output execution contexts or dicts (for final Project/Aggregate)
        """
        row_limit = self._pipeline_limit(operators, op_index) if operators else None

        if isinstance(op, ScanNodes):
            return self._execute_scan(
                op, input_rows, row_limit=row_limit, operators=operators, op_index=op_index
            )

        if isinstance(op, OptionalScanNodes):
            return self._execute_optional_scan(op, input_rows)

        if isinstance(op, ExpandEdges):
            return self._execute_expand(op, input_rows, row_limit=row_limit)

        from graphforge.planner.operators import ExpandVariableLength

        if isinstance(op, ExpandVariableLength):
            return self._execute_variable_expand(op, input_rows)

        if isinstance(op, ExpandMultiHop):
            return self._execute_multi_hop(op, input_rows)

        if isinstance(op, AssemblePath):
            return self._execute_assemble_path(op, input_rows)

        if isinstance(op, OptionalExpandEdges):
            return self._execute_optional_expand(op, input_rows)

        if isinstance(op, ApplyOptional):
            return self._execute_apply_optional(op, input_rows)

        if isinstance(op, Filter):
            return self._execute_filter(op, input_rows)

        if isinstance(op, Project):
            return self._execute_project(op, input_rows)

        if isinstance(op, Limit):
            return self._execute_limit(op, input_rows)

        if isinstance(op, Skip):
            return self._execute_skip(op, input_rows)

        if isinstance(op, Sort):
            return self._execute_sort(op, input_rows)

        if isinstance(op, Aggregate):
            # Determine if we're in WITH context (more operators follow)
            # In WITH, return ExecutionContexts; in RETURN, return dicts
            for_with = op_index < total_ops - 1
            return self._execute_aggregate(op, input_rows, for_with=for_with)

        if isinstance(op, Create):
            return self._execute_create(op, input_rows)

        if isinstance(op, Set):
            return self._execute_set(op, input_rows)

        if isinstance(op, Remove):
            return self._execute_remove(op, input_rows)

        if isinstance(op, Delete):
            return self._execute_delete(op, input_rows)

        if isinstance(op, Merge):
            return self._execute_merge(op, input_rows)

        if isinstance(op, Unwind):
            return self._execute_unwind(op, input_rows, row_limit=row_limit)

        if isinstance(op, With):
            return self._execute_with(op, input_rows)

        if isinstance(op, Distinct):
            return self._execute_distinct(op, input_rows)

        if isinstance(op, Union):
            return self._execute_union(op, input_rows)

        from graphforge.planner.operators import Call, ProcedureCall

        if isinstance(op, Call):
            return self._execute_call(op, input_rows)

        if isinstance(op, ProcedureCall):
            return self._execute_procedure_call(op, input_rows)

        if isinstance(op, Subquery):
            return self._execute_subquery(op, input_rows)

        raise TypeError(f"Unknown operator type: {type(op).__name__}")

    def _node_matches_labels(self, node: NodeRef | CypherNull, label_spec: list[list[str]]) -> bool:
        """Check if a node matches a label specification.

        Args:
            node: The node to check (or CypherNull from OPTIONAL MATCH)
            label_spec: List of label groups (disjunction of conjunctions)
                       Example: [['Person']] - node must have 'Person'
                       Example: [['Person', 'Employee']] - node must have both
                       Example: [['Person'], ['Company']] - node must have Person OR Company

        Returns:
            True if node matches any label group, False otherwise (including if node is null)
        """
        # Handle null nodes (from OPTIONAL MATCH)
        if isinstance(node, CypherNull):
            return False

        # Check if ANY label group matches (OR between groups)
        for label_group in label_spec:
            # Check if ALL labels in this group are present (AND within group)
            if all(label in node.labels for label in label_group):
                return True
        return False

    def _execute_scan(
        self,
        op: ScanNodes,
        input_rows: list[ExecutionContext],
        row_limit: int | None = None,
        operators: list | None = None,
        op_index: int = 0,
    ) -> list[ExecutionContext]:
        """Execute ScanNodes operator.

        If the variable is already bound in the input context (e.g., from WITH),
        validate that the bound node matches the pattern instead of doing a full scan.
        Uses the property equality index when the next operator is a simple equality Filter.
        """
        result = []

        # For each input row
        for ctx in input_rows:
            # Check if variable is already bound (e.g., from WITH clause)
            if op.variable in ctx.bindings:
                # Variable already bound - validate it matches the pattern
                bound_node = ctx.get(op.variable)

                # Null node from OPTIONAL MATCH forwarding:
                # - With label requirements: null never has labels → discard
                # - Without label requirements: pass through (null propagates in OPTIONAL chain)
                if isinstance(bound_node, CypherNull):
                    if op.labels:
                        continue
                    result.append(ctx)
                    continue

                # Check if bound node has required labels
                if op.labels:
                    if self._node_matches_labels(bound_node, op.labels):
                        # Node matches pattern - check predicate
                        # Prepare context for predicate evaluation
                        eval_ctx = ctx
                        if op.path_var:
                            from graphforge.types import CypherPath

                            eval_ctx = ExecutionContext()
                            eval_ctx.bindings = dict(ctx.bindings)
                            path = CypherPath(nodes=[bound_node], relationships=[])
                            eval_ctx.bind(op.path_var, path)

                        # Apply pattern predicate if specified
                        if op.predicate is not None:
                            predicate_result = evaluate_expression(op.predicate, eval_ctx, self)
                            # Only include node if predicate evaluates to true
                            if not (
                                isinstance(predicate_result, CypherBool) and predicate_result.value
                            ):
                                continue  # Skip this node if predicate is not true

                        # Predicate passed - add result
                        result.append(eval_ctx)
                # No label requirements - check predicate
                elif op.path_var or op.predicate is not None:
                    from graphforge.types import CypherPath

                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    if op.path_var:
                        path = CypherPath(nodes=[bound_node], relationships=[])
                        new_ctx.bind(op.path_var, path)

                    # Apply pattern predicate if specified
                    if op.predicate is not None:
                        predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                        if not (
                            isinstance(predicate_result, CypherBool) and predicate_result.value
                        ):
                            continue  # Skip if predicate fails

                    result.append(new_ctx)
                else:
                    result.append(ctx)
            else:
                # Variable not bound - scan with index acceleration where possible
                eq_hints = self._extract_equality_hints(operators or [], op_index, op.variable)

                if op.labels and eq_hints:
                    # Property equality index acceleration for single label-group queries.
                    # When the scan has exactly one label group and at least one equality hint,
                    # intersect the label index with the property index instead of full scan.
                    if len(op.labels) == 1:
                        label_group = op.labels[0]
                        primary_label = label_group[0]
                        prop_name, prop_val = eq_hints[0]
                        if len(label_group) == 1:
                            group_nodes = self.graph.get_nodes_by_label_and_property(
                                primary_label, prop_name, prop_val
                            )
                        else:
                            group_nodes = self.graph.get_nodes_by_label_and_property(
                                primary_label, prop_name, prop_val
                            )
                            group_nodes = [
                                n
                                for n in group_nodes
                                if all(label in n.labels for label in label_group[1:])
                            ]
                        all_nodes: set = set(group_nodes)
                    else:
                        # Multi-group disjunction: label scan, let Filter handle property
                        all_nodes = set()
                        for label_group in op.labels:
                            group_nodes = self.graph.get_nodes_by_label(label_group[0])
                            if len(label_group) > 1:
                                group_nodes = [
                                    node
                                    for node in group_nodes
                                    if all(label in node.labels for label in label_group)
                                ]
                            all_nodes.update(group_nodes)
                    nodes = list(all_nodes)
                elif op.labels:
                    # Label-only scan (no property hint)
                    all_nodes = set()
                    for label_group in op.labels:
                        # Scan by first label in the group for efficiency
                        group_nodes = self.graph.get_nodes_by_label(label_group[0])

                        # Filter to nodes with ALL labels in this group (conjunction)
                        if len(label_group) > 1:
                            group_nodes = [
                                node
                                for node in group_nodes
                                if all(label in node.labels for label in label_group)
                            ]

                        # Add to result set
                        all_nodes.update(group_nodes)

                    nodes = list(all_nodes)
                else:
                    # Scan all nodes
                    nodes = self.graph.get_all_nodes()

                # Bind each node
                for node in nodes:
                    if row_limit is not None and len(result) >= row_limit:
                        return result

                    new_ctx = ExecutionContext()
                    # Copy existing bindings
                    new_ctx.bindings = dict(ctx.bindings)
                    # Bind new node
                    new_ctx.bind(op.variable, node)
                    # Bind path variable if requested (single-node path)
                    if op.path_var:
                        from graphforge.types import CypherPath

                        path = CypherPath(nodes=[node], relationships=[])
                        new_ctx.bind(op.path_var, path)

                    # Apply pattern predicate if specified
                    if op.predicate is not None:
                        predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                        # Only include node if predicate evaluates to true
                        if not (
                            isinstance(predicate_result, CypherBool) and predicate_result.value
                        ):
                            continue  # Skip this node if predicate is not true

                    result.append(new_ctx)

        return result

    def _execute_optional_scan(
        self, op: OptionalScanNodes, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute OptionalScanNodes operator with LEFT JOIN semantics.

        Like ScanNodes but preserves input rows with NULL binding when no match found.
        """
        result = []

        # For each input row
        for ctx in input_rows:
            # Check if variable is already bound (e.g., from WITH clause)
            if op.variable in ctx.bindings:
                # Variable already bound - validate it matches the pattern
                bound_node = ctx.get(op.variable)

                # Check if bound node has required labels
                if op.labels:
                    if self._node_matches_labels(bound_node, op.labels):
                        # Node matches pattern - keep the context
                        result.append(ctx)
                    else:
                        # Node doesn't match - OPTIONAL preserves row with NULL
                        new_ctx = ExecutionContext()
                        new_ctx.bindings = dict(ctx.bindings)
                        new_ctx.bind(op.variable, CypherNull())
                        result.append(new_ctx)
                else:
                    # No label requirements - keep the context
                    result.append(ctx)
            else:
                # Variable not bound - do normal scan
                if op.labels:
                    # Collect nodes from all label groups (disjunction)
                    all_nodes = set()
                    for label_group in op.labels:
                        # Scan by first label in the group for efficiency
                        group_nodes = self.graph.get_nodes_by_label(label_group[0])

                        # Filter to nodes with ALL labels in this group (conjunction)
                        if len(label_group) > 1:
                            group_nodes = [
                                node
                                for node in group_nodes
                                if all(label in node.labels for label in label_group)
                            ]

                        # Add to result set
                        all_nodes.update(group_nodes)

                    nodes = list(all_nodes)
                else:
                    # Scan all nodes
                    nodes = self.graph.get_all_nodes()

                if nodes:
                    # Bind each node
                    for node in nodes:
                        new_ctx = ExecutionContext()
                        new_ctx.bindings = dict(ctx.bindings)
                        new_ctx.bind(op.variable, node)
                        result.append(new_ctx)
                else:
                    # OPTIONAL semantics: No nodes found - preserve row with NULL
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    new_ctx.bind(op.variable, CypherNull())
                    result.append(new_ctx)

        return result

    def _execute_expand(
        self,
        op: ExpandEdges,
        input_rows: list[ExecutionContext],
        row_limit: int | None = None,
    ) -> list[ExecutionContext]:
        """Execute ExpandEdges operator."""
        # Check if we need to do incremental aggregation
        if op.agg_hint is not None:
            # agg_hint means an Aggregate follows in the pipeline, so _pipeline_limit
            # already returns None for this operator — row_limit is always None here.
            return self._execute_expand_with_aggregation(op, input_rows)

        # Standard expansion without aggregation
        result: list[ExecutionContext] = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Null node → no edges (openCypher: MATCH on null bindings produces no rows)
            if isinstance(src_node, CypherNull):
                continue

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED
                # For undirected, get both outgoing and incoming edges
                # BUT: self-loops will appear in both lists, so deduplicate them
                outgoing = self.graph.get_outgoing_edges(src_node.id)
                incoming = self.graph.get_incoming_edges(src_node.id)

                # Deduplicate edges - self-loops (src==dst) will appear in both lists
                # Use edge ID to identify duplicates
                seen_edge_ids = set()
                edges = []
                for edge in outgoing + incoming:
                    if edge.id not in seen_edge_ids:
                        edges.append(edge)
                        seen_edge_ids.add(edge.id)

            # Filter by type if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # Collect edge IDs already bound by OTHER named relationship variables in this
            # MATCH pattern to enforce relationship uniqueness.
            # openCypher: the same edge may not be bound to two different variables in one
            # MATCH pattern. We only check variables in op.pattern_rel_vars (the named rels
            # in the current pattern), excluding op.edge_var itself so that pre-bound edges
            # (passed through WITH) still act as constraints for this hop.
            from graphforge.types.graph import EdgeRef as _EdgeRef

            bound_edge_ids = {
                v.id
                for k, v in ctx.bindings.items()
                if isinstance(v, _EdgeRef) and k in op.pattern_rel_vars and k != op.edge_var
            }

            # Bind edge and dst node
            for edge in edges:
                if row_limit is not None and len(result) >= row_limit:
                    return result

                # Enforce relationship uniqueness: skip edges already bound in this pattern
                if edge.id in bound_edge_ids:
                    continue

                # If edge variable is already bound (e.g., from WITH), only keep matching edges
                if op.edge_var and op.edge_var in ctx.bindings:
                    bound_edge = ctx.bindings[op.edge_var]
                    if not (hasattr(bound_edge, "id") and bound_edge.id == edge.id):
                        continue

                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)

                if op.edge_var:
                    new_ctx.bind(op.edge_var, edge)

                # Determine dst node based on direction
                if op.direction == "OUT":
                    dst_node = edge.dst
                elif op.direction == "IN":
                    dst_node = edge.src
                else:  # UNDIRECTED - use whichever is not src
                    dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                # If dst variable is already bound, only keep matching destinations
                if op.dst_var in ctx.bindings:
                    bound_dst = ctx.bindings[op.dst_var]
                    if not (hasattr(bound_dst, "id") and bound_dst.id == dst_node.id):
                        continue

                new_ctx.bind(op.dst_var, dst_node)

                # Bind path variable if requested (single-hop path)
                if op.path_var:
                    from graphforge.types import CypherPath

                    path = CypherPath(nodes=[src_node, dst_node], relationships=[edge])
                    new_ctx.bind(op.path_var, path)

                # Apply pattern predicate if specified
                if op.predicate is not None:
                    predicate_result = evaluate_expression(op.predicate, new_ctx, self)
                    # Only include edge if predicate evaluates to true
                    if not (isinstance(predicate_result, CypherBool) and predicate_result.value):
                        continue  # Skip this edge if predicate is not true

                result.append(new_ctx)

        return result

    def _execute_expand_with_aggregation(
        self, op: ExpandEdges, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandEdges with incremental aggregation.

        Instead of materializing all edges, computes aggregations incrementally
        during traversal and yields one result per group.

        Args:
            op: ExpandEdges operator with agg_hint set
            input_rows: Input execution contexts

        Returns:
            List of execution contexts with aggregation results
        """
        hint = op.agg_hint
        assert hint is not None, "agg_hint must be set when calling this method"
        func_name = hint.func.upper()

        # Map: (group_key_tuple) -> aggregate_value
        # Group key is tuple of values for group_by variables
        aggregates: dict[tuple, Any] = {}

        # Map: (group_key_tuple) -> ExecutionContext (for binding group variables)
        group_contexts: dict[tuple, ExecutionContext] = {}

        # Process all expansions, accumulating aggregates
        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Null node → no edges (forwarded from OPTIONAL MATCH)
            if isinstance(src_node, CypherNull):
                continue

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED
                outgoing = self.graph.get_outgoing_edges(src_node.id)
                incoming = self.graph.get_incoming_edges(src_node.id)
                seen_edge_ids = set()
                edges = []
                for edge in outgoing + incoming:
                    if edge.id not in seen_edge_ids:
                        edges.append(edge)
                        seen_edge_ids.add(edge.id)

            # Filter by type if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # Process each edge and update aggregates
            for edge in edges:
                # Create temporary context for expression evaluation
                temp_ctx = ExecutionContext()
                temp_ctx.bindings = dict(ctx.bindings)

                if op.edge_var:
                    temp_ctx.bind(op.edge_var, edge)

                # Determine dst node
                if op.direction == "OUT":
                    dst_node = edge.dst
                elif op.direction == "IN":
                    dst_node = edge.src
                else:  # UNDIRECTED
                    dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                temp_ctx.bind(op.dst_var, dst_node)

                # Apply pattern predicate if specified
                if op.predicate is not None:
                    predicate_result = evaluate_expression(op.predicate, temp_ctx, self)
                    if not (isinstance(predicate_result, CypherBool) and predicate_result.value):
                        continue  # Skip this edge

                # Compute group key from group_by variables
                group_key_values = []
                for var_name in hint.group_by:
                    val = temp_ctx.get(var_name)
                    # Use the existing hashable conversion helper
                    hashable_val = self._value_to_hashable(val)
                    group_key_values.append(hashable_val)
                group_key = tuple(group_key_values)

                # Initialize aggregate for this group if needed
                if group_key not in aggregates:
                    aggregates[group_key] = self._initial_aggregate_value(func_name)
                    # Store the first context for this group (for binding group vars)
                    group_contexts[group_key] = temp_ctx

                # Update aggregate
                if func_name == "COUNT":
                    if hint.expr is not None:
                        # COUNT(expr) - only count non-NULL values
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            aggregates[group_key] += 1
                    else:
                        # COUNT(*) - count all rows
                        aggregates[group_key] += 1
                elif func_name == "SUM":
                    # Evaluate expression and add to sum
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            # Extract numeric value
                            if hasattr(value, "value"):
                                aggregates[group_key] += value.value
                elif func_name == "MIN":
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            val = value.value if hasattr(value, "value") else value
                            if aggregates[group_key] is None or val < aggregates[group_key]:
                                aggregates[group_key] = val
                elif func_name == "MAX":
                    if hint.expr is not None:
                        value = evaluate_expression(hint.expr, temp_ctx, self)
                        if not isinstance(value, CypherNull):
                            val = value.value if hasattr(value, "value") else value
                            if aggregates[group_key] is None or val > aggregates[group_key]:
                                aggregates[group_key] = val

        # Yield one context per group with aggregation result
        result = []
        for group_key, agg_value in aggregates.items():
            # Start with the context from this group
            ctx = group_contexts[group_key]
            new_ctx = ExecutionContext()

            # Bind group variables
            for var_name in hint.group_by:
                new_ctx.bind(var_name, ctx.get(var_name))

            # Bind aggregate result
            wrapped_value = self._wrap_aggregate_value(func_name, agg_value)
            new_ctx.bind(hint.result_var, wrapped_value)

            result.append(new_ctx)

        return result

    def _initial_aggregate_value(self, func_name: str) -> Any:
        """Get initial value for an aggregate function.

        Args:
            func_name: Aggregation function name

        Returns:
            Initial value for the aggregate
        """
        if func_name in {"COUNT", "SUM"}:
            return 0
        elif func_name in ("MIN", "MAX"):
            return None  # No value yet
        else:
            raise ValueError(f"Unsupported aggregate function: {func_name}")

    def _wrap_aggregate_value(self, func_name: str, value: Any) -> Any:
        """Wrap aggregate result as CypherValue.

        Args:
            func_name: Aggregation function name
            value: Raw aggregate value

        Returns:
            Wrapped CypherValue
        """
        from graphforge.types.values import CypherFloat, CypherInt, CypherNull

        if func_name == "COUNT":
            return CypherInt(value)
        elif func_name == "SUM":
            # Sum could be int or float
            if isinstance(value, float):
                return CypherFloat(value)
            else:
                return CypherInt(value)
        elif func_name in ("MIN", "MAX"):
            if value is None:
                return CypherNull()
            elif isinstance(value, float):
                return CypherFloat(value)
            elif isinstance(value, int):
                return CypherInt(value)
            else:
                # For other types, return as-is (could be string, etc.)
                from graphforge.types.values import CypherString

                return CypherString(str(value))
        else:
            raise ValueError(f"Unsupported aggregate function: {func_name}")

    def _match_exact_edge_sequence(
        self,
        src_node: Any,
        edges: list[Any],
        bound_dst: Any,
        op: Any,
        ctx: Any,
    ) -> list[Any]:
        """Validate that src_node traverses exactly `edges` in order, yielding a result row.

        Used when the relationship variable is pre-bound to a CypherList of EdgeRefs.
        Walks the edges one by one; each edge must connect the previous node to the next.
        If bound_dst is given, the final node must match it.
        """
        from graphforge.types.graph import EdgeRef as _EdgeRefCls
        from graphforge.types.graph import NodeRef as _NodeRefCls2

        hop_count = len(edges)

        # Enforce hop-range constraints — keep parity with DFS
        if hop_count < op.min_hops:
            return []
        if op.max_hops is not None and hop_count > op.max_hops:
            return []

        if not edges:
            # Empty list: src must equal dst (zero-hop path)
            if bound_dst is not None and src_node.id != bound_dst.id:
                return []
            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)
            new_ctx.bind(op.dst_var, src_node)
            if op.edge_var:
                new_ctx.bind(op.edge_var, CypherList([]))
            if op.path_var:
                from graphforge.types import CypherPath

                new_ctx.bind(op.path_var, CypherPath(nodes=[src_node], relationships=[]))
            return [new_ctx]

        current = src_node
        path_nodes = [src_node]
        for edge in edges:
            if not isinstance(edge, _EdgeRefCls):
                return []
            # Filter by edge type if specified
            if op.edge_types and edge.type not in op.edge_types:
                return []
            direction = op.direction
            if direction == "OUT":
                if not isinstance(current, _NodeRefCls2) or edge.src.id != current.id:
                    return []
                current = edge.dst
            elif direction == "IN":
                if not isinstance(current, _NodeRefCls2) or edge.dst.id != current.id:
                    return []
                current = edge.src
            else:  # UNDIRECTED
                if not isinstance(current, _NodeRefCls2):
                    return []
                if edge.src.id == current.id:
                    current = edge.dst
                elif edge.dst.id == current.id:
                    current = edge.src
                else:
                    return []
            path_nodes.append(current)

        if bound_dst is not None and current.id != bound_dst.id:
            return []

        new_ctx = ExecutionContext()
        new_ctx.bindings = dict(ctx.bindings)
        new_ctx.bind(op.dst_var, current)
        if op.edge_var:
            new_ctx.bind(op.edge_var, CypherList(list(edges)))
        if op.path_var:
            from graphforge.types import CypherPath

            new_ctx.bind(op.path_var, CypherPath(nodes=path_nodes, relationships=edges))
        return [new_ctx]

    def _execute_variable_expand(
        self, op: ExpandVariableLength, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandVariableLength operator with recursive traversal and cycle detection."""
        result = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Handle NULL source (propagated from a prior failed OPTIONAL MATCH hop)
            if isinstance(src_node, CypherNull):
                if getattr(op, "optional", False):
                    null_ctx = ExecutionContext()
                    null_ctx.bindings = dict(ctx.bindings)
                    if op.dst_var not in ctx.bindings:
                        null_ctx.bind(op.dst_var, CypherNull())
                    if op.edge_var and op.edge_var not in ctx.bindings:
                        null_ctx.bind(op.edge_var, CypherNull())
                    if op.path_var and op.path_var not in ctx.bindings:
                        null_ctx.bind(op.path_var, CypherNull())
                    result.append(null_ctx)
                # else: regular MATCH — drop the row
                continue

            # Check if dst_var is already bound — only yield paths reaching that specific node
            from graphforge.types.graph import EdgeRef
            from graphforge.types.graph import NodeRef as _NodeRefCls

            dst_bound = op.dst_var in ctx.bindings
            bound_dst_node = None
            if dst_bound:
                _bound_dst = ctx.get(op.dst_var)
                if isinstance(_bound_dst, _NodeRefCls):
                    bound_dst_node = _bound_dst
                elif isinstance(_bound_dst, CypherNull) and getattr(op, "optional", False):
                    # Bound dst is null from prior optional — propagate null
                    null_ctx = ExecutionContext()
                    null_ctx.bindings = dict(ctx.bindings)
                    if op.edge_var and op.edge_var not in ctx.bindings:
                        null_ctx.bind(op.edge_var, CypherNull())
                    if op.path_var and op.path_var not in ctx.bindings:
                        null_ctx.bind(op.path_var, CypherNull())
                    result.append(null_ctx)
                    continue
                else:
                    # dst is bound to something that isn't a node — no path can exist
                    continue

            # If edge_var is already bound (e.g. from a prior MATCH), seed the traversal
            # so that DFS only yields paths that include that specific relationship.
            bound_edge_id: str | int | None = None
            bound_edge_list: list[EdgeRef] | None = None  # for [rs*] with rs pre-bound as list
            if op.edge_var and op.edge_var in ctx.bindings:
                _bound_edge = ctx.get(op.edge_var)
                if isinstance(_bound_edge, EdgeRef):
                    bound_edge_id = _bound_edge.id
                elif isinstance(_bound_edge, CypherList):
                    # rs is a pre-bound list of edges — validate exact sequence.
                    # If any element is not an EdgeRef the binding is invalid; skip the row
                    # rather than falling back to unconstrained DFS.
                    _edge_refs = [e for e in _bound_edge.value if isinstance(e, EdgeRef)]
                    if len(_edge_refs) == len(_bound_edge.value):
                        bound_edge_list = _edge_refs
                    else:
                        continue  # mixed-type list cannot match a rel pattern

            # Pre-bound edge list: validate that src_node → rels → dst matches exactly
            if bound_edge_list is not None:
                found_rows = self._match_exact_edge_sequence(
                    src_node, bound_edge_list, bound_dst_node, op, ctx
                )
                result.extend(found_rows)
                continue

            # Seed used_edge_ids with edges already bound in context to enforce relationship
            # uniqueness across the full pattern per openCypher spec (#382).
            # Covers both single-edge bindings (EdgeRef) and var-length hop bindings
            # (CypherList of EdgeRef) from prior [*] hops in the same MATCH pattern.
            initial_used_edge_ids: set[str | int] = {
                v.id for v in ctx.bindings.values() if isinstance(v, EdgeRef)
            }
            for v in ctx.bindings.values():
                if isinstance(v, CypherList):
                    for item in v.value:
                        if isinstance(item, EdgeRef):
                            initial_used_edge_ids.add(item.id)
            if bound_edge_id is not None:
                # Do NOT pre-exclude the edge_var's own edge — it drives filtering below
                initial_used_edge_ids.discard(bound_edge_id)

            # Depth-first search with relationship uniqueness (openCypher spec).
            # Each relationship may appear at most once in a single path; nodes may repeat.
            # State: (current_node, edge_path, depth, used_edge_ids)
            stack: list[tuple[_NodeRefCls, list[EdgeRef], int, set[str | int]]] = [
                (src_node, [], 0, initial_used_edge_ids)
            ]
            dfs_rows: list[ExecutionContext] = []

            while stack:
                current_node, edge_path, depth, used_edge_ids = stack.pop()

                # Check if we've reached valid depth range
                if op.min_hops <= depth <= (op.max_hops if op.max_hops else float("inf")):
                    # If dst is bound, only emit rows where we reached the bound node
                    if bound_dst_node is not None and current_node.id != bound_dst_node.id:
                        pass  # skip — wrong destination
                    # If edge_var is bound to a specific edge, only emit paths containing it
                    elif bound_edge_id is not None and not any(
                        e.id == bound_edge_id for e in edge_path
                    ):
                        pass  # skip — required edge not in this path
                    else:
                        # Yield this path
                        new_ctx = ExecutionContext()
                        new_ctx.bindings = dict(ctx.bindings)

                        new_ctx.bind(op.dst_var, current_node)

                        # Bind edge list if variable provided — var-length rel variable
                        # is always a CypherList of EdgeRef values per openCypher spec.
                        if op.edge_var:
                            new_ctx.bind(op.edge_var, CypherList(edge_path))  # type: ignore[arg-type]

                        # Bind path if path variable is specified
                        if op.path_var:
                            from graphforge.types import CypherPath

                            nodes = [src_node]
                            for edge in edge_path:
                                if op.direction == "OUT":
                                    nodes.append(edge.dst)
                                elif op.direction == "IN":
                                    nodes.append(edge.src)
                                else:  # UNDIRECTED
                                    prev_node = nodes[-1]
                                    next_node = (
                                        edge.dst if edge.src.id == prev_node.id else edge.src
                                    )
                                    nodes.append(next_node)

                            path = CypherPath(nodes=nodes, relationships=edge_path)
                            new_ctx.bind(op.path_var, path)

                        dfs_rows.append(new_ctx)

                # Continue exploration if we haven't exceeded max depth
                if op.max_hops is None or depth < op.max_hops:
                    # Get edges based on direction
                    if op.direction == "OUT":
                        edges = self.graph.get_outgoing_edges(current_node.id)
                    elif op.direction == "IN":
                        edges = self.graph.get_incoming_edges(current_node.id)
                    else:  # UNDIRECTED
                        # For undirected, get both outgoing and incoming edges
                        # BUT: self-loops will appear in both lists, so deduplicate them
                        outgoing = self.graph.get_outgoing_edges(current_node.id)
                        incoming = self.graph.get_incoming_edges(current_node.id)

                        # Deduplicate edges - self-loops (src==dst) will appear in both lists
                        # Use edge ID to identify duplicates
                        seen_edge_ids = set()
                        edges = []
                        for edge in outgoing + incoming:
                            if edge.id not in seen_edge_ids:
                                edges.append(edge)
                                seen_edge_ids.add(edge.id)

                    # Filter by type if specified
                    if op.edge_types:
                        edges = [e for e in edges if e.type in op.edge_types]

                    # Apply pattern predicate to filter edges if specified
                    if op.predicate is not None:
                        filtered_edges = []
                        for edge in edges:
                            # Create a temporary context with the edge bound
                            temp_ctx = ExecutionContext()
                            temp_ctx.bindings = dict(ctx.bindings)
                            if op.edge_var:
                                temp_ctx.bind(op.edge_var, edge)
                            # Evaluate predicate
                            predicate_result = evaluate_expression(op.predicate, temp_ctx, self)
                            # Only include edge if predicate evaluates to true
                            if isinstance(predicate_result, CypherBool) and predicate_result.value:
                                filtered_edges.append(edge)
                        edges = filtered_edges

                    # Add edges to stack for exploration
                    for edge in edges:
                        # Skip relationships already used in this path (openCypher rel uniqueness)
                        if edge.id in used_edge_ids:
                            continue

                        # Determine next node
                        if op.direction == "OUT":
                            next_node = edge.dst
                        elif op.direction == "IN":
                            next_node = edge.src
                        else:  # UNDIRECTED
                            next_node = edge.dst if edge.src.id == current_node.id else edge.src

                        new_used = used_edge_ids | {edge.id}
                        stack.append((next_node, [*edge_path, edge], depth + 1, new_used))

            if dfs_rows:
                result.extend(dfs_rows)
            elif getattr(op, "optional", False):
                # No paths found in optional context — null-fill
                null_ctx = ExecutionContext()
                null_ctx.bindings = dict(ctx.bindings)
                if op.dst_var not in ctx.bindings:
                    null_ctx.bind(op.dst_var, CypherNull())
                if op.edge_var and op.edge_var not in ctx.bindings:
                    null_ctx.bind(op.edge_var, CypherNull())
                if op.path_var:
                    null_ctx.bind(op.path_var, CypherNull())
                result.append(null_ctx)

        return result

    def _execute_multi_hop(
        self, op: ExpandMultiHop, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ExpandMultiHop operator for fixed multi-hop patterns.

        Traverses a chain of relationships with specific types in sequence,
        building the complete path as it goes.
        """
        result = []

        for ctx in input_rows:
            src_node = ctx.get(op.src_var)

            # Track paths through the multi-hop traversal
            # Each state: (current_node, path_nodes, path_edges, hop_index)
            from graphforge.types.graph import EdgeRef

            states: list[tuple[NodeRef, list[NodeRef], list[EdgeRef], int]] = [
                (src_node, [src_node], [], 0)
            ]

            while states:
                current_node, path_nodes, path_edges, hop_idx = states.pop()

                # If we've completed all hops, emit result
                if hop_idx >= len(op.hops):
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)

                    # Bind all intermediate node variables
                    # path_nodes[0] is src (already bound)
                    # path_nodes[1..] are destinations from each hop
                    for i, (edge_var, _, _, dst_var) in enumerate(op.hops):
                        # Bind destination variable for this hop
                        new_ctx.bind(dst_var, path_nodes[i + 1])

                        # Bind edge variable if specified
                        if edge_var:
                            new_ctx.bind(edge_var, path_edges[i])

                    # Bind path variable if specified
                    if op.path_var:
                        from graphforge.types import CypherPath

                        path = CypherPath(nodes=path_nodes, relationships=path_edges)
                        new_ctx.bind(op.path_var, path)

                    result.append(new_ctx)
                    continue

                # Process current hop
                edge_var, edge_types, direction, dst_var = op.hops[hop_idx]

                # Get edges based on direction
                if direction == "OUT":
                    edges = self.graph.get_outgoing_edges(current_node.id)
                elif direction == "IN":
                    edges = self.graph.get_incoming_edges(current_node.id)
                else:  # UNDIRECTED
                    # Deduplicate self-loops (src==dst) that appear in both lists
                    _seen: set[int | str] = set()
                    edges = []
                    for _e in self.graph.get_outgoing_edges(
                        current_node.id
                    ) + self.graph.get_incoming_edges(current_node.id):
                        if _e.id not in _seen:
                            edges.append(_e)
                            _seen.add(_e.id)

                # Filter by type if specified
                if edge_types:
                    edges = [e for e in edges if e.type in edge_types]

                # IDs of edges already used in this path (for relationship uniqueness)
                used_edge_ids = {e.id for e in path_edges}

                # For each matching edge, continue traversal
                for edge in edges:
                    # Enforce relationship uniqueness: skip edges already used in this path
                    if edge.id in used_edge_ids:
                        continue

                    # Determine next node based on direction
                    if direction == "OUT":
                        next_node = edge.dst
                    elif direction == "IN":
                        next_node = edge.src
                    else:  # UNDIRECTED
                        next_node = edge.dst if edge.src.id == current_node.id else edge.src

                    # Add state for next hop
                    new_path_nodes = [*path_nodes, next_node]
                    new_path_edges = [*path_edges, edge]
                    states.append((next_node, new_path_nodes, new_path_edges, hop_idx + 1))

        return result

    def _execute_assemble_path(
        self, op: AssemblePath, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Concatenate per-hop CypherPath segments into a single named path.

        Each hop stores its partial path in a temp variable (__path_hop_N).
        This operator joins them: nodes are chained (dropping duplicate junction nodes),
        relationships are concatenated. If any hop segment is CypherNull (from
        OPTIONAL MATCH failure), the assembled path is also CypherNull.
        """
        result = []
        for ctx in input_rows:
            # Collect per-hop path segments
            segments: list[CypherPath | CypherNull] = []
            any_null = False
            for hpv in op.hop_path_vars:
                seg = ctx.get(hpv) if ctx.has(hpv) else CypherNull()
                if isinstance(seg, CypherNull):
                    any_null = True
                    break
                segments.append(seg)

            new_ctx = ExecutionContext()
            new_ctx.bindings = dict(ctx.bindings)

            if any_null:
                new_ctx.bind(op.path_var, CypherNull())
            else:
                # Concatenate: path = seg0.nodes + seg1.nodes[1:] + ...
                # segments contains only CypherPath values (any_null=False guards CypherNull)
                cypher_segs = [s for s in segments if isinstance(s, CypherPath)]
                all_nodes = list(cypher_segs[0].nodes)
                all_rels = list(cypher_segs[0].relationships)
                for seg in cypher_segs[1:]:
                    # Junction node is already the last node of all_nodes; skip seg[0]
                    all_nodes.extend(seg.nodes[1:])
                    all_rels.extend(seg.relationships)

                # openCypher relationship uniqueness: drop paths where any relationship
                # appears more than once (e.g. a bound r also traversed by a [*N..M] segment)
                rel_ids = [r.id for r in all_rels]
                if len(rel_ids) != len(set(rel_ids)):
                    for hpv in op.hop_path_vars:
                        new_ctx.bindings.pop(hpv, None)
                    continue

                new_ctx.bind(op.path_var, CypherPath(nodes=all_nodes, relationships=all_rels))

            # Clean up temp hop variables
            for hpv in op.hop_path_vars:
                new_ctx.bindings.pop(hpv, None)

            result.append(new_ctx)

        return result

    def _execute_filter(
        self, op: Filter, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute Filter operator."""
        result = []

        for ctx in input_rows:
            # Evaluate predicate
            value = evaluate_expression(op.predicate, ctx, self)

            # Keep row if predicate is true
            if isinstance(value, CypherBool) and value.value:
                result.append(ctx)

        return result

    def _execute_project(self, op: Project, input_rows: list[ExecutionContext]) -> list[dict]:
        """Execute Project operator."""
        from graphforge.ast.expression import Wildcard

        result = []

        for ctx in input_rows:
            row = {}
            for i, return_item in enumerate(op.items):
                # Handle Wildcard (*) - return all variables from context
                # Exclude planner-generated anonymous variables (starting with "__anon_")
                if isinstance(return_item.expression, Wildcard):
                    filtered_bindings = {
                        k: v for k, v in ctx.bindings.items() if not k.startswith("__anon_")
                    }
                    row.update(filtered_bindings)
                    continue

                # Extract expression and alias from ReturnItem
                value = evaluate_expression(return_item.expression, ctx, self)

                key = _return_item_key(return_item, fallback_index=i)

                row[key] = value
            result.append(row)

        return result

    def _execute_with(self, op: With, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute WITH operator.

        WITH acts as a pipeline boundary, projecting specified columns and
        optionally filtering, sorting, and paginating.

        Unlike Project, WITH returns ExecutionContexts (not final dicts) so the
        query can continue with more clauses.

        Args:
            op: WITH operator with items, predicate, sort_items, skip_count, limit_count
            input_rows: Input execution contexts

        Returns:
            List of ExecutionContexts with only the projected variables
        """
        from graphforge.ast.expression import Variable, Wildcard

        # Step 0: If ORDER BY is present, sort input rows BEFORE projecting.
        # ORDER BY in a WITH clause can reference pre-projection variables (e.g. from
        # a previous WITH) as well as new aliases introduced by this WITH clause itself.
        # We build an "enriched" context (original bindings + new aliases) for each row
        # and sort by those, then project the original rows in sorted order.
        if op.sort_items:
            from functools import cmp_to_key

            def _make_enriched_ctx(ctx: ExecutionContext) -> ExecutionContext:
                """Build context with original bindings plus new WITH aliases."""
                enriched = ExecutionContext()
                for k, v in ctx.bindings.items():
                    enriched.bind(k, v)
                enriched.aggregate_cache = ctx.aggregate_cache
                for return_item in op.items:
                    if isinstance(return_item.expression, Wildcard):
                        continue
                    if return_item.alias:
                        try:
                            val = evaluate_expression(return_item.expression, ctx, self)
                            enriched.bind(return_item.alias, val)
                        except (KeyError, TypeError):
                            pass
                return enriched

            enriched = [_make_enriched_ctx(ctx) for ctx in input_rows]

            def compare_pre_projection(i1: int, i2: int) -> int:
                for sort_item in op.sort_items:  # type: ignore[union-attr]
                    val1 = evaluate_expression(sort_item.expression, enriched[i1], self)
                    val2 = evaluate_expression(sort_item.expression, enriched[i2], self)
                    cmp = compare_cypher_values(val1, val2, sort_item.ascending)
                    if cmp != 0:
                        return cmp
                return 0

            sorted_indices = sorted(range(len(input_rows)), key=cmp_to_key(compare_pre_projection))
            input_rows = [input_rows[i] for i in sorted_indices]

        # Step 1: Project items into new contexts.
        # Keep a paired list of (pre_ctx, new_ctx) so that WHERE can see
        # pre-projection variables (openCypher: WITH WHERE is evaluated before
        # the scope is narrowed to projected names only).
        pairs: list[tuple[ExecutionContext, ExecutionContext]] = []

        for ctx in input_rows:
            new_ctx = ExecutionContext()
            bound_vars = set()  # Track variables to detect duplicates

            for return_item in op.items:
                # Handle Wildcard (*) - copy all variables from current context
                # Exclude planner-generated anonymous variables (starting with "__anon_")
                if isinstance(return_item.expression, Wildcard):
                    for var_name, value in ctx.bindings.items():
                        if not var_name.startswith("__anon_"):
                            # Check for duplicate with explicit aliases
                            if var_name in bound_vars:
                                raise ValueError(
                                    f"ColumnNameConflict: Variable '{var_name}' from wildcard "
                                    f"expansion conflicts with explicitly aliased column"
                                )
                            new_ctx.bind(var_name, value)
                            bound_vars.add(var_name)
                    continue

                # Evaluate expression
                value = evaluate_expression(return_item.expression, ctx, self)

                # Determine variable name to bind
                if return_item.alias:
                    # Explicit alias provided
                    var_name = return_item.alias
                elif isinstance(return_item.expression, Variable):
                    # No alias, but expression is a variable - use variable name
                    var_name = return_item.expression.name
                else:
                    # Complex expression without alias - skip binding
                    # (This is technically invalid Cypher, but we'll allow it)
                    continue

                # Check for duplicate
                if var_name in bound_vars:
                    raise ValueError(
                        f"ColumnNameConflict: Multiple result columns with the same "
                        f"name '{var_name}' are not supported"
                    )

                # Bind the value in the new context
                new_ctx.bind(var_name, value)
                bound_vars.add(var_name)

            pairs.append((ctx, new_ctx))

        # Step 2: Apply optional WHERE filter.
        # Evaluate the predicate against a merged context: pre-projection bindings
        # overlaid with new aliases. This lets WHERE reference both old variables
        # (e.g. `i`, `j` from UNWIND) and the new aliases introduced by this WITH.
        if op.predicate:
            filtered_pairs = []
            for pre_ctx, new_ctx in pairs:
                # Build merged context: original bindings + new aliases on top
                merged = ExecutionContext()
                for k, v in pre_ctx.bindings.items():
                    merged.bind(k, v)
                for k, v in new_ctx.bindings.items():
                    merged.bind(k, v)
                pred_val = evaluate_expression(op.predicate, merged, self)
                if isinstance(pred_val, CypherBool) and pred_val.value:
                    filtered_pairs.append((pre_ctx, new_ctx))
            pairs = filtered_pairs

        result = [new_ctx for _, new_ctx in pairs]

        # Step 3: Apply optional SKIP
        if op.skip_count is not None:
            _param_ctx = getattr(self, "_seed_ctx", ExecutionContext())
            skip_val = evaluate_expression(op.skip_count, _param_ctx, self)
            if not isinstance(skip_val, CypherInt) or skip_val.value < 0:
                raise TypeError(f"SKIP must be a non-negative integer, got {skip_val!r}")
            result = result[skip_val.value :]

        # Step 4: Apply optional LIMIT
        if op.limit_count is not None:
            _param_ctx = getattr(self, "_seed_ctx", ExecutionContext())
            limit_val = evaluate_expression(op.limit_count, _param_ctx, self)
            if not isinstance(limit_val, CypherInt) or limit_val.value < 0:
                raise TypeError(f"LIMIT must be a non-negative integer, got {limit_val!r}")
            result = result[: limit_val.value]

        return result

    def _execute_limit(self, op: Limit, input_rows: list) -> list:
        """Execute Limit operator."""
        param_ctx = getattr(self, "_seed_ctx", ExecutionContext())
        count_val = evaluate_expression(op.count, param_ctx, self)
        if not isinstance(count_val, CypherInt) or count_val.value < 0:
            raise TypeError(f"LIMIT must be a non-negative integer, got {count_val!r}")
        return input_rows[: count_val.value]

    def _execute_skip(self, op: Skip, input_rows: list) -> list:
        """Execute Skip operator."""
        param_ctx = getattr(self, "_seed_ctx", ExecutionContext())
        count_val = evaluate_expression(op.count, param_ctx, self)
        if not isinstance(count_val, CypherInt) or count_val.value < 0:
            raise TypeError(f"SKIP must be a non-negative integer, got {count_val!r}")
        return input_rows[count_val.value :]

    def _execute_distinct(self, op: Distinct, input_rows: list) -> list:
        """Execute DISTINCT operator.

        Removes duplicate rows by comparing all bound variables.
        Handles both ExecutionContext objects (before projection) and
        dict objects (after projection).
        """
        if not input_rows:
            return input_rows

        seen = set()
        result = []

        for ctx in input_rows:
            # Create hashable key from all bindings
            # Handle both ExecutionContext and dict types
            if isinstance(ctx, dict):
                # After projection - ctx is a dict
                keys = sorted(ctx.keys())
                key_items = []
                for var_name in keys:
                    value = ctx[var_name]
                    hashable = self._value_to_hashable(value)
                    key_items.append((var_name, hashable))
            else:
                # Before projection - ctx is ExecutionContext
                key_items = []
                for var_name in sorted(ctx.bindings.keys()):
                    value = ctx.bindings[var_name]
                    hashable = self._value_to_hashable(value)
                    key_items.append((var_name, hashable))

            key = tuple(key_items)
            if key not in seen:
                seen.add(key)
                result.append(ctx)

        return result

    def _execute_sort(self, op: Sort, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute Sort operator.

        Sorts rows by evaluating sort expressions and applying directions.
        NULL values are handled according to Cypher semantics:
        - ASC: NULLs last
        - DESC: NULLs first

        Supports referencing RETURN aliases by pre-evaluating RETURN expressions.
        """
        if not input_rows:
            return input_rows

        # Pre-evaluate RETURN expressions with aliases and extend contexts
        # This allows ORDER BY to reference aliases defined in RETURN
        # Keep mapping from extended context to original context
        # Note: Skip aggregate functions - they can't be evaluated until after Aggregate operator

        # Check if ORDER BY expressions can already be evaluated from input context
        # This happens after aggregation where aliases are already bound
        skip_return_items_eval = False
        if input_rows and op.items:
            try:
                # Try to evaluate all ORDER BY expressions from first context
                for order_item in op.items:
                    evaluate_expression(order_item.expression, input_rows[0], self)
                # If we got here, all ORDER BY expressions are available - skip return_items eval
                skip_return_items_eval = True
            except (KeyError, AttributeError, TypeError):
                # ORDER BY references something not in context or can't be typed correctly
                # (e.g. n+2 where n=NodeRef before alias renaming) — need return_items eval
                skip_return_items_eval = False

        extended_rows = []
        context_mapping = {}  # Maps id(extended_ctx) -> original_ctx

        for ctx in input_rows:
            extended_ctx = ExecutionContext()
            extended_ctx.bindings = dict(ctx.bindings)
            # Propagate aggregate cache so ORDER BY can resolve aggregate expressions
            extended_ctx.aggregate_cache = ctx.aggregate_cache

            # Add RETURN aliases to context (only if not after aggregation)
            if op.return_items and not skip_return_items_eval:
                for return_item in op.return_items:
                    if return_item.alias:
                        # Skip aggregate functions (COUNT, SUM, AVG, etc.)
                        # They must be evaluated by the Aggregate operator
                        from graphforge.executor.evaluator import is_aggregate_function

                        if not is_aggregate_function(return_item.expression):
                            try:
                                # Evaluate the expression and bind it with the alias name.
                                # This may override an existing binding of the same name
                                # (e.g. RETURN n.num AS n — renames variable n to its integer value)
                                value = evaluate_expression(return_item.expression, ctx, self)
                                extended_ctx.bind(return_item.alias, value)
                            except (KeyError, AttributeError, TypeError):
                                # Expression not evaluable in current scope (e.g. pre-aggregation
                                # variable referenced after aggregation) — silently skip
                                pass

            extended_rows.append(extended_ctx)
            context_mapping[id(extended_ctx)] = ctx

        from functools import cmp_to_key

        def _substitute_groupby_aliases(expr):
            """Recursively substitute return_item expressions with their alias Variables.

            This allows ORDER BY expressions like `a.name + 'C'` to be evaluated as
            `name + 'C'` when `a.name AS name` is a GROUP BY alias — even after
            aggregation has removed `a` from the context.
            """
            if op.return_items:
                for return_item in op.return_items:
                    if return_item.alias and self._expressions_match(expr, return_item.expression):
                        return Variable(name=return_item.alias)

            # Recursively substitute in compound expressions
            if isinstance(expr, ParenthesizedExpr):
                new_inner = _substitute_groupby_aliases(expr.expr)
                if new_inner is not expr.expr:
                    return ParenthesizedExpr(expr=new_inner)
            elif isinstance(expr, BinaryOp):
                new_left = _substitute_groupby_aliases(expr.left)
                new_right = _substitute_groupby_aliases(expr.right)
                if new_left is not expr.left or new_right is not expr.right:
                    return BinaryOp(op=expr.op, left=new_left, right=new_right)
            elif isinstance(expr, UnaryOp):
                new_operand = _substitute_groupby_aliases(expr.operand)
                if new_operand is not expr.operand:
                    return UnaryOp(op=expr.op, operand=new_operand)
            elif isinstance(expr, FunctionCall):
                new_args = [_substitute_groupby_aliases(a) for a in expr.args]
                if any(na is not a for na, a in zip(new_args, expr.args, strict=True)):
                    return FunctionCall(name=expr.name, args=new_args, distinct=expr.distinct)
            return expr

        def _eval_order_expr(expr, ctx):
            """Evaluate ORDER BY expression, falling back to alias/column name lookup."""
            try:
                return evaluate_expression(expr, ctx, self)
            except (KeyError, AttributeError):
                # After aggregation, ORDER BY may reference a pre-aggregation expression
                # that matches a return item alias (e.g. ORDER BY a.name where a.name AS name),
                # or a composite expression containing such sub-expressions (a.name + 'C').
                substituted = _substitute_groupby_aliases(expr)
                if substituted is not expr:
                    try:
                        return evaluate_expression(substituted, ctx, self)
                    except (KeyError, AttributeError):
                        pass
                # Fall back to column name string lookup
                col_name = _expression_to_string(expr)
                if col_name in ctx.bindings:
                    return ctx.bindings[col_name]
                raise

        def multi_key_compare(ctx1, ctx2):
            """Compare two contexts by all sort keys."""
            for order_item in op.items:
                val1 = _eval_order_expr(order_item.expression, ctx1)
                val2 = _eval_order_expr(order_item.expression, ctx2)
                cmp_result = compare_cypher_values(val1, val2, order_item.ascending)
                if cmp_result != 0:
                    return cmp_result
            return 0  # All keys equal

        sorted_extended_rows = sorted(extended_rows, key=cmp_to_key(multi_key_compare))

        # Map back to original contexts maintaining the sorted order
        result_rows = []
        for sorted_ctx in sorted_extended_rows:
            original_ctx = context_mapping[id(sorted_ctx)]
            result_rows.append(original_ctx)

        return result_rows

    def _expressions_match(self, expr1, expr2) -> bool:
        """Check if two expressions are semantically equivalent.

        Args:
            expr1: First expression
            expr2: Second expression

        Returns:
            True if expressions are semantically equivalent
        """
        from graphforge.ast.expression import Literal, PropertyAccess, Variable

        # Same object
        if expr1 is expr2:
            return True

        # Parentheses are syntactic grouping — compare by inner expression
        if isinstance(expr1, ParenthesizedExpr):
            return self._expressions_match(expr1.expr, expr2)
        if isinstance(expr2, ParenthesizedExpr):
            return self._expressions_match(expr1, expr2.expr)

        # Different types
        if not isinstance(expr1, type(expr2)):
            return False

        # Variable: compare by name
        if isinstance(expr1, Variable) and isinstance(expr2, Variable):
            return expr1.name == expr2.name

        # PropertyAccess: compare variable and property
        if isinstance(expr1, PropertyAccess) and isinstance(expr2, PropertyAccess):
            return (
                self._expressions_match(expr1.variable, expr2.variable)
                and expr1.property == expr2.property
            )

        # Literal: compare values
        if isinstance(expr1, Literal) and isinstance(expr2, Literal):
            return bool(expr1.value == expr2.value)

        # BinaryOp: compare operator and both operands
        if isinstance(expr1, BinaryOp) and isinstance(expr2, BinaryOp):
            return (
                expr1.op == expr2.op
                and self._expressions_match(expr1.left, expr2.left)
                and self._expressions_match(expr1.right, expr2.right)
            )

        # UnaryOp: compare operator and operand
        if isinstance(expr1, UnaryOp) and isinstance(expr2, UnaryOp):
            return expr1.op == expr2.op and self._expressions_match(expr1.operand, expr2.operand)

        # FunctionCall: compare function name and arguments
        if isinstance(expr1, FunctionCall) and isinstance(expr2, FunctionCall):
            if expr1.name.lower() != expr2.name.lower():
                return False
            if len(expr1.args) != len(expr2.args):
                return False
            return all(
                self._expressions_match(a1, a2)
                for a1, a2 in zip(expr1.args, expr2.args, strict=True)
            )

        # For other types, fall back to object identity
        return False

    def _execute_aggregate(
        self, op: Aggregate, input_rows: list[ExecutionContext], for_with: bool = False
    ) -> list[dict] | list[ExecutionContext]:
        """Execute Aggregate operator.

        Groups rows by grouping expressions and computes aggregation functions.

        Args:
            op: Aggregate operator
            input_rows: Input execution contexts
            for_with: If True, return ExecutionContexts for WITH; if False, return dicts for RETURN

        Returns:
            List of dicts (for RETURN) or ExecutionContexts (for WITH)
        """
        from collections import defaultdict

        # Handle empty input
        if not input_rows:
            # If no grouping (only aggregates), return one row with NULL/0 aggregates
            if not op.grouping_exprs:
                row = self._compute_aggregates_for_group(op, [], for_with=for_with)
                return [row]  # type: ignore[return-value]
            return []

        # Group rows by grouping expressions
        if op.grouping_exprs:
            # Multiple groups
            groups = defaultdict(list)
            for ctx in input_rows:
                # Compute grouping key
                key_values = tuple(
                    self._value_to_hashable(evaluate_expression(expr, ctx, self))
                    for expr in op.grouping_exprs
                )
                groups[key_values].append(ctx)
        else:
            # No grouping - single group with all rows
            groups = {(): input_rows}  # type: ignore[assignment]

        # Compute aggregates for each group
        result: list[Any] = []
        for group_key, group_rows in groups.items():
            row = self._compute_aggregates_for_group(op, group_rows, group_key, for_with=for_with)
            result.append(row)

        return result

    def _value_to_hashable(self, value):
        """Convert CypherValue to hashable key for grouping.

        Recursively handles CypherList and CypherMap to produce stable,
        hashable representations for use with COLLECT DISTINCT and grouping.
        """
        from graphforge.types.values import CypherList, CypherMap

        if isinstance(value, CypherNull):
            return None
        if isinstance(value, (CypherInt, CypherFloat, CypherBool)):
            return (type(value).__name__, value.value)
        if isinstance(value, CypherList):
            # Recursively convert list elements to hashable tuple
            return (type(value).__name__, tuple(self._value_to_hashable(v) for v in value.value))
        if isinstance(value, CypherMap):
            # Convert map to tuple of sorted (key, hashable-value) pairs
            return (
                type(value).__name__,
                tuple(sorted((k, self._value_to_hashable(v)) for k, v in value.value.items())),
            )
        if hasattr(value, "value"):
            # CypherString, etc.
            return (type(value).__name__, value.value)
        # NodeRef, EdgeRef have their own hash
        return value

    def _hashable_to_cypher_value(self, hashable_val):
        """Convert hashable representation back to CypherValue.

        Recursively reconstructs CypherList and CypherMap from their
        hashable tuple representations.
        """
        from graphforge.types.values import CypherList, CypherMap, CypherString

        if hashable_val is None:
            return CypherNull()
        elif isinstance(hashable_val, tuple) and len(hashable_val) == 2:
            type_name, val = hashable_val
            if type_name == "CypherInt":
                return CypherInt(val)
            elif type_name == "CypherFloat":
                return CypherFloat(val)
            elif type_name == "CypherBool":
                return CypherBool(val)
            elif type_name == "CypherString":
                return CypherString(val)
            elif type_name == "CypherList":
                # Recursively reconstruct list from tuple of hashable items
                reconstructed_items = [self._hashable_to_cypher_value(item) for item in val]
                return CypherList(reconstructed_items)
            elif type_name == "CypherMap":
                # Recursively reconstruct map from tuple of (key, hashable-value) pairs
                reconstructed_map = {k: self._hashable_to_cypher_value(v) for k, v in val}
                return CypherMap(reconstructed_map)

        # NodeRef, EdgeRef, or already a CypherValue
        return hashable_val

    def _compute_aggregates_for_group(
        self,
        op: Aggregate,
        group_rows: list[ExecutionContext],
        group_key=None,
        for_with: bool = False,
    ) -> dict | ExecutionContext:
        """Compute aggregates for a single group.

        Builds a cache of pre-computed aggregate values, then evaluates each
        return item's full expression using that cache. This handles both simple
        aggregate expressions (count(n)) and composite ones (count(n) + 3).

        Args:
            op: Aggregate operator
            group_rows: Rows in this group
            group_key: Tuple of grouping values (or None for single-group queries)
            for_with: If True, return ExecutionContext (for WITH); else return dict (for RETURN)

        Returns:
            Dict (for RETURN) or ExecutionContext (for WITH) with column values
        """
        # Step 1: Build aggregate cache as list of (FunctionCall, CypherValue) pairs.
        # List-based to avoid hashing issues; structural equality (Pydantic __eq__)
        # is used for lookup in evaluate_expression so ORDER BY expressions that are
        # structurally identical to RETURN aggregates resolve correctly.
        agg_cache: list = []
        seen_exprs: list = []  # Track already-added exprs for deduplication
        for agg_expr in op.agg_exprs:
            assert isinstance(agg_expr, FunctionCall)
            if not any(agg_expr == seen for seen in seen_exprs):
                agg_cache.append((agg_expr, self._compute_aggregation(agg_expr, group_rows)))
                seen_exprs.append(agg_expr)

        # Step 2: Build a fresh evaluation context from a sample row's bindings.
        # Using a fresh context (not mutating group_rows[0]) prevents cache leaking
        # onto upstream rows if evaluate_expression raises.
        # When group_rows is empty (e.g. MATCH on empty graph), fall back to seed context
        # so $param references resolve correctly.
        sample_ctx = ExecutionContext()
        if group_rows:
            sample_ctx.bindings = dict(group_rows[0].bindings)
        elif hasattr(self, "_seed_ctx"):
            sample_ctx.bindings = dict(self._seed_ctx.bindings)
        sample_ctx.aggregate_cache = agg_cache

        # Step 3: Evaluate each return item's full expression
        if for_with:
            out_ctx = ExecutionContext()
            # Propagate aggregate cache so downstream Sort can evaluate ORDER BY aggregates
            out_ctx.aggregate_cache = agg_cache
            for j, return_item in enumerate(op.return_items):
                var_name = _return_item_key(return_item, fallback_index=j)
                value = evaluate_expression(return_item.expression, sample_ctx, self)
                out_ctx.bind(var_name, value)
            return out_ctx
        else:
            row: dict[str, Any] = {}
            for j, return_item in enumerate(op.return_items):
                key = _return_item_key(return_item, fallback_index=j)
                row[key] = evaluate_expression(return_item.expression, sample_ctx, self)
            return row

    def _compute_aggregation(self, func_call: FunctionCall, group_rows: list[ExecutionContext]):
        """Compute a single aggregation function over a group.

        Args:
            func_call: FunctionCall node with aggregation function
            group_rows: Rows in the group

        Returns:
            CypherValue result of the aggregation
        """
        func_name = func_call.name.upper()

        # COUNT(*) or COUNT(expr)
        if func_name == "COUNT":
            if not func_call.args:  # COUNT(*)
                return CypherInt(len(group_rows))

            # COUNT(expr) - count non-NULL values
            count = 0
            seen: set[Any] | None = set() if func_call.distinct else None

            for ctx in group_rows:
                value = evaluate_expression(func_call.args[0], ctx, self)
                if not isinstance(value, CypherNull):
                    if func_call.distinct and seen is not None:
                        hashable = self._value_to_hashable(value)
                        if hashable not in seen:
                            seen.add(hashable)
                            count += 1
                    else:
                        count += 1

            return CypherInt(count)

        # COLLECT - always return a list (even if empty, unlike other aggregations)
        if func_name == "COLLECT":
            from graphforge.types.values import CypherList

            collected_values: list[CypherValue] = []
            seen_hashes: set[Any] = set()

            for ctx in group_rows:
                value = evaluate_expression(func_call.args[0], ctx, self)
                # Skip NULL values
                if not isinstance(value, CypherNull):
                    if func_call.distinct:
                        hashable = self._value_to_hashable(value)
                        if hashable not in seen_hashes:
                            seen_hashes.add(hashable)
                            collected_values.append(value)
                    else:
                        collected_values.append(value)

            return CypherList(collected_values)

        # SUM, AVG, MIN, MAX require evaluating the expression
        values: list[Any] = []
        for ctx in group_rows:
            value = evaluate_expression(func_call.args[0], ctx, self)
            if not isinstance(value, CypherNull):
                if func_call.distinct:
                    hashable = self._value_to_hashable(value)
                    if hashable not in (self._value_to_hashable(v) for v in values):
                        values.append(value)
                else:
                    values.append(value)

        # If no non-NULL values, return NULL for most functions
        if not values:
            return CypherNull()

        # SUM
        if func_name == "SUM":
            total: int | float = 0
            is_float = False
            for val in values:
                if isinstance(val, CypherFloat):
                    is_float = True
                    total += val.value
                elif isinstance(val, CypherInt):
                    total += val.value
            return CypherFloat(total) if is_float else CypherInt(int(total))

        # AVG
        if func_name == "AVG":
            total = 0.0
            for val in values:
                if isinstance(val, (CypherInt, CypherFloat)):
                    total += val.value
            return CypherFloat(total / len(values))

        # MIN — use sort-order comparison so mixed types (e.g. list vs string) are handled
        if func_name == "MIN":
            min_val = values[0]
            for val in values[1:]:
                if compare_cypher_values(val, min_val, ascending=True) < 0:
                    min_val = val
            return min_val

        # MAX — use sort-order comparison so mixed types are handled
        if func_name == "MAX":
            max_val = values[0]
            for val in values[1:]:
                if compare_cypher_values(val, max_val, ascending=True) > 0:
                    max_val = val
            return max_val

        # PERCENTILEDISC - discrete percentile (no interpolation)
        if func_name == "PERCENTILEDISC":
            # Second argument is the percentile value (0.0 to 1.0)
            if len(func_call.args) != 2:
                raise TypeError(f"percentileDisc expects 2 arguments, got {len(func_call.args)}")

            # Get percentile value from second argument
            percentile_expr = func_call.args[1]
            context = group_rows[0] if group_rows else ExecutionContext()
            percentile_val = evaluate_expression(percentile_expr, context, self)

            if isinstance(percentile_val, CypherNull):
                return CypherNull()

            if not isinstance(percentile_val, (CypherInt, CypherFloat)):
                raise TypeError("percentileDisc percentile must be a number")

            percentile = float(percentile_val.value)
            if not 0.0 <= percentile <= 1.0:
                raise ValueError("percentileDisc percentile must be between 0.0 and 1.0")

            if not values:
                return CypherNull()

            # Convert values to floats and sort
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    val_type = type(val).__name__
                    raise TypeError(f"percentileDisc requires numeric values, got {val_type}")

            numeric_values.sort()

            # Calculate index (discrete - no interpolation)
            if percentile == 1.0:
                index = len(numeric_values) - 1
            else:
                index = int(percentile * len(numeric_values))

            return CypherFloat(numeric_values[index])

        # PERCENTILECONT - continuous percentile (with linear interpolation)
        if func_name == "PERCENTILECONT":
            # Second argument is the percentile value (0.0 to 1.0)
            if len(func_call.args) != 2:
                raise TypeError(f"percentileCont expects 2 arguments, got {len(func_call.args)}")

            # Get percentile value from second argument
            percentile_expr = func_call.args[1]
            context = group_rows[0] if group_rows else ExecutionContext()
            percentile_val = evaluate_expression(percentile_expr, context, self)

            if isinstance(percentile_val, CypherNull):
                return CypherNull()

            if not isinstance(percentile_val, (CypherInt, CypherFloat)):
                raise TypeError("percentileCont percentile must be a number")

            percentile = float(percentile_val.value)
            if not 0.0 <= percentile <= 1.0:
                raise ValueError("percentileCont percentile must be between 0.0 and 1.0")

            if not values:
                return CypherNull()

            # Convert values to floats and sort
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    val_type = type(val).__name__
                    raise TypeError(f"percentileCont requires numeric values, got {val_type}")

            numeric_values.sort()

            # Calculate position with linear interpolation
            if percentile == 0.0:
                return CypherFloat(numeric_values[0])
            if percentile == 1.0:
                return CypherFloat(numeric_values[-1])

            # Linear interpolation between adjacent values
            position = percentile * (len(numeric_values) - 1)
            lower_index = int(position)
            upper_index = lower_index + 1

            if upper_index >= len(numeric_values):
                return CypherFloat(numeric_values[-1])

            # Interpolate
            fraction = position - lower_index
            lower_value = numeric_values[lower_index]
            upper_value = numeric_values[upper_index]
            result = lower_value + fraction * (upper_value - lower_value)

            return CypherFloat(result)

        # STDEV - sample standard deviation
        if func_name == "STDEV":
            if len(values) < 2:
                return CypherNull()

            # Convert to numeric values
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    raise TypeError(f"stDev requires numeric values, got {type(val).__name__}")

            # Calculate mean
            mean = sum(numeric_values) / len(numeric_values)

            # Calculate sample variance: sum((x - mean)^2) / (n - 1)
            variance = sum((x - mean) ** 2 for x in numeric_values) / (len(numeric_values) - 1)

            # Standard deviation is square root of variance
            import math

            std_dev = math.sqrt(variance)

            return CypherFloat(std_dev)

        # STDEVP - population standard deviation
        if func_name == "STDEVP":
            if not values:
                return CypherNull()

            # Convert to numeric values
            numeric_values = []
            for val in values:
                if isinstance(val, CypherInt):
                    numeric_values.append(float(val.value))
                elif isinstance(val, CypherFloat):
                    numeric_values.append(val.value)
                else:
                    raise TypeError(f"stDevP requires numeric values, got {type(val).__name__}")

            # Calculate mean
            mean = sum(numeric_values) / len(numeric_values)

            # Calculate population variance: sum((x - mean)^2) / n
            variance = sum((x - mean) ** 2 for x in numeric_values) / len(numeric_values)

            # Standard deviation is square root of variance
            import math

            std_dev = math.sqrt(variance)

            return CypherFloat(std_dev)

        raise ValueError(f"Unknown aggregation function: {func_name}")

    def _validate_pattern_variables(self, pattern_parts):
        """Validate pattern variables in CREATE pattern.

        Per openCypher semantics:
        - Node variables can appear multiple times (e.g., self-loops: CREATE (a)-[:R]->(a))
        - Relationship variables must be unique
        - A variable cannot be used for both a node and a relationship

        Args:
            pattern_parts: List of NodePattern/RelationshipPattern objects from pattern

        Raises:
            ValueError: If validation fails
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        node_vars = []
        rel_vars = []

        for part in pattern_parts:
            if hasattr(part, "variable") and part.variable:
                var_name = part.variable if isinstance(part.variable, str) else part.variable.name

                if isinstance(part, NodePattern):
                    node_vars.append(var_name)
                elif isinstance(part, RelationshipPattern):
                    rel_vars.append(var_name)

        # Check: relationship variables must be unique
        seen_rel_vars = set()
        for var in rel_vars:
            if var in seen_rel_vars:
                raise ValueError(
                    f"Variable '{var}' used multiple times for relationships in CREATE pattern. "
                    f"Each relationship variable must be unique."
                )
            seen_rel_vars.add(var)

        # Check: a variable cannot be both a node and a relationship
        node_var_set = set(node_vars)
        rel_var_set = set(rel_vars)
        overlap = node_var_set & rel_var_set
        if overlap:
            var = next(iter(overlap))
            raise ValueError(
                f"Variable '{var}' used for both node and relationship in CREATE pattern. "
                f"A variable must refer to only one type of entity."
            )

    def _execute_create(
        self, op: Create, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute CREATE operator.

        Creates nodes and relationships from patterns.

        Args:
            op: Create operator with patterns
            input_rows: Input execution contexts

        Returns:
            Execution contexts with created elements bound to variables
        """
        if not self.graphforge:
            raise RuntimeError("CREATE requires GraphForge instance")

        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        result = []

        # Process each input row (usually just one for CREATE)
        for ctx in input_rows:
            new_ctx = ExecutionContext()
            new_ctx.bindings = ctx.bindings.copy()

            # Process each pattern
            for pattern in op.patterns:
                if not pattern:
                    continue

                # Extract pattern parts from new format (dict with path_variable and parts)
                # or use pattern directly if it's old format (list)
                # Note: CREATE and MERGE do not support path binding
                if isinstance(pattern, dict) and "parts" in pattern:
                    pattern_parts = pattern["parts"]
                else:
                    # Old format: pattern is already a list
                    pattern_parts = pattern

                # Validate no duplicate variables in pattern
                self._validate_pattern_variables(pattern_parts)

                # Handle simple node pattern: CREATE (n:Person {name: 'Alice'})
                if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                    node_pattern = pattern_parts[0]
                    node = self._create_node_from_pattern(node_pattern, new_ctx)
                    if node_pattern.variable:
                        new_ctx.bindings[node_pattern.variable] = node

                # Handle node-relationship-node pattern: CREATE (a)-[r:KNOWS]->(b)
                elif len(pattern_parts) >= 3:
                    # First node
                    if isinstance(pattern_parts[0], NodePattern):
                        src_pattern = pattern_parts[0]
                        # Check if variable already bound (for connecting existing nodes)
                        if src_pattern.variable and src_pattern.variable in new_ctx.bindings:
                            src_node = new_ctx.bindings[src_pattern.variable]
                        else:
                            src_node = self._create_node_from_pattern(src_pattern, new_ctx)
                            if src_pattern.variable:
                                new_ctx.bindings[src_pattern.variable] = src_node

                    # Process all relationships in the pattern (multi-hop support)
                    # Pattern structure: node, rel, node, rel, node, ...
                    # Process pairs: (node[0], rel[1], node[2]), (node[2], rel[3], node[4]), ...
                    # Keep track of the last destination node for chaining
                    last_dst_node = src_node

                    for i in range(1, len(pattern_parts), 2):
                        if i + 1 >= len(pattern_parts):
                            break  # Need both relationship and destination node

                        if not isinstance(pattern_parts[i], RelationshipPattern):
                            continue  # Skip if not a relationship

                        rel_pattern = pattern_parts[i]
                        dst_pattern = pattern_parts[i + 1]

                        # Source node is the last created destination node from previous iteration
                        # (or the initial src_node for i==1)
                        src_node = last_dst_node

                        # Check if destination variable already bound
                        if dst_pattern.variable and dst_pattern.variable in new_ctx.bindings:
                            dst_node = new_ctx.bindings[dst_pattern.variable]
                        else:
                            dst_node = self._create_node_from_pattern(dst_pattern, new_ctx)
                            if dst_pattern.variable:
                                new_ctx.bindings[dst_pattern.variable] = dst_node

                        # Create relationship - handle direction:
                        # IN means arrow points left: (src)<-[r]-(dst), so edge is dst→src
                        rel_type = rel_pattern.types[0] if rel_pattern.types else "RELATED_TO"
                        from graphforge.ast.pattern import Direction

                        if rel_pattern.direction == Direction.IN:
                            edge = self._create_relationship_from_pattern(
                                dst_node, src_node, rel_type, rel_pattern, new_ctx
                            )
                        else:
                            edge = self._create_relationship_from_pattern(
                                src_node, dst_node, rel_type, rel_pattern, new_ctx
                            )
                        if rel_pattern.variable:
                            new_ctx.bindings[rel_pattern.variable] = edge

                        # Update last_dst_node for next iteration
                        last_dst_node = dst_node

            result.append(new_ctx)

        return result

    def _create_node_from_pattern(self, node_pattern, ctx: ExecutionContext):
        """Create a node from a NodePattern.

        Args:
            node_pattern: NodePattern from AST
            ctx: Execution context for evaluating property expressions

        Returns:
            Created NodeRef
        """
        # Validate no disjunctive labels in CREATE
        if node_pattern.labels and len(node_pattern.labels) > 1:
            raise ValueError(
                "Disjunctive labels (using '|') are not allowed in CREATE patterns. "
                "Use multiple CREATE statements or specify only conjunction of labels."
            )

        # Extract labels - flatten label groups for CREATE
        # For CREATE, we apply all labels from all groups (only one group allowed)
        labels = []
        if node_pattern.labels:
            for label_group in node_pattern.labels:
                labels.extend(label_group)

        # Extract and evaluate properties
        properties = {}
        if node_pattern.properties:
            for key, value_expr in node_pattern.properties.items():
                # Evaluate the expression to get the value
                cypher_value = evaluate_expression(value_expr, ctx, self)
                # Per openCypher spec, NULL means "no value" - skip NULL properties
                if not isinstance(cypher_value, CypherNull):
                    # Convert CypherValue to Python value (handles nested lists/maps)
                    properties[key] = _cypher_to_python(cypher_value)

        # Create node using GraphForge API
        node = self.graphforge.create_node(labels, **properties)
        return node

    def _create_relationship_from_pattern(
        self, src_node, dst_node, rel_type, rel_pattern, ctx: ExecutionContext
    ):
        """Create a relationship from a RelationshipPattern.

        Args:
            src_node: Source NodeRef
            dst_node: Destination NodeRef
            rel_type: Relationship type string
            rel_pattern: RelationshipPattern from AST
            ctx: Execution context for evaluating property expressions

        Returns:
            Created EdgeRef
        """
        # Extract and evaluate properties
        properties = {}
        if hasattr(rel_pattern, "properties") and rel_pattern.properties:
            for key, value_expr in rel_pattern.properties.items():
                # Evaluate the expression to get the value
                cypher_value = evaluate_expression(value_expr, ctx, self)
                # Per openCypher spec, NULL means "no value" - skip NULL properties
                if not isinstance(cypher_value, CypherNull):
                    # Convert CypherValue to Python value (handles nested lists/maps)
                    properties[key] = _cypher_to_python(cypher_value)

        # Create relationship using GraphForge API
        edge = self.graphforge.create_relationship(src_node, dst_node, rel_type, **properties)
        return edge

    def _execute_set(self, op: Set, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute SET operator.

        Updates properties on nodes and relationships.

        Args:
            op: Set operator with property assignments
            input_rows: Input execution contexts

        Returns:
            Updated execution contexts
        """
        result = []

        for ctx in input_rows:
            self._execute_set_items(op.items, ctx)
            result.append(ctx)

        return result

    def _execute_remove(
        self, op: Remove, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute REMOVE operator.

        Removes properties from nodes/relationships or labels from nodes.

        Args:
            op: Remove operator with items to remove
            input_rows: Input execution contexts

        Returns:
            Updated execution contexts
        """
        from graphforge.types.graph import NodeRef

        result = []

        for ctx in input_rows:
            # Process each REMOVE item
            for item in op.items:
                var_name = item.variable
                name = item.name

                # Get the element from context
                if var_name in ctx.bindings:
                    element = ctx.bindings[var_name]

                    if item.item_type == "property":
                        # Remove property if it exists
                        if hasattr(element, "properties") and name in element.properties:
                            from graphforge.types.graph import NodeRef as _NodeRef

                            if isinstance(element, _NodeRef):
                                self.graph.remove_node_from_indexes(element)
                            del element.properties[name]
                            if isinstance(element, _NodeRef):
                                self.graph.add_node_to_indexes(element)
                    elif item.item_type == "label":
                        # Remove label if it exists
                        # NodeRef is immutable, so we need to create a new one with updated labels
                        if hasattr(element, "labels") and name in element.labels:
                            # Create new labels set without the removed label
                            new_labels = set(element.labels)
                            new_labels.discard(name)

                            # Create new NodeRef with updated labels
                            new_node = NodeRef(
                                id=element.id,
                                labels=frozenset(new_labels),
                                properties=element.properties,
                            )

                            # Update the node in the graph
                            self.graph.add_node(new_node)

                            # Update the binding to reference the new node
                            ctx.bindings[var_name] = new_node

            result.append(ctx)

        return result

    def _execute_delete(
        self, op: Delete, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute DELETE operator.

        Removes nodes and relationships from the graph.

        Args:
            op: Delete operator with variables to delete
            input_rows: Input execution contexts

        Returns:
            Empty list (DELETE produces no output rows)

        Raises:
            ValueError: If trying to delete a node with relationships without DETACH
        """
        from graphforge.types.graph import EdgeRef, NodeRef

        for ctx in input_rows:
            for var_ref in op.variables:
                # Resolve the delete target — either a variable name (str) or an expression
                if isinstance(var_ref, str):
                    if var_ref not in ctx.bindings:
                        continue
                    element = ctx.bindings[var_ref]
                else:
                    element = evaluate_expression(var_ref, ctx, self)

                # Skip NULL values - they don't exist in the graph
                if isinstance(element, CypherNull) or element is None:
                    continue

                # Delete from graph
                if isinstance(element, NodeRef):
                    # Get all edges connected to this node
                    outgoing = self.graph.get_outgoing_edges(element.id)
                    incoming = self.graph.get_incoming_edges(element.id)
                    all_edges = outgoing + incoming

                    # Check if node has relationships
                    if all_edges and not op.detach:
                        raise ValueError(
                            "Cannot delete node with relationships. "
                            "Use DETACH DELETE to delete relationships first."
                        )

                    # Remove all connected edges first (if DETACH)
                    if op.detach:
                        for edge in all_edges:
                            # Write-through: remove from SQLite before mutating memory
                            if self.graphforge and self.graphforge.backend:
                                self.graphforge.backend.delete_edge(edge.id)
                            self.graph._edges.pop(edge.id, None)
                            # Remove from adjacency lists
                            if edge.src.id in self.graph._outgoing:
                                self.graph._outgoing[edge.src.id] = [
                                    e for e in self.graph._outgoing[edge.src.id] if e.id != edge.id
                                ]
                            if edge.dst.id in self.graph._incoming:
                                self.graph._incoming[edge.dst.id] = [
                                    e for e in self.graph._incoming[edge.dst.id] if e.id != edge.id
                                ]
                            # Remove from type index
                            if edge.type in self.graph._type_index:
                                self.graph._type_index[edge.type].discard(edge.id)

                    # Write-through: remove from SQLite before mutating memory
                    if self.graphforge and self.graphforge.backend:
                        self.graphforge.backend.delete_node(element.id)
                    # Remove from label + property indexes
                    self.graph.remove_node_from_indexes(element)
                    # Remove node
                    self.graph._nodes.pop(element.id, None)
                    # Remove adjacency lists
                    self.graph._outgoing.pop(element.id, None)
                    self.graph._incoming.pop(element.id, None)
                    # Track deletion in context so RETURN can detect access errors
                    if hasattr(ctx, "deleted_ids"):
                        ctx.deleted_ids.add(element.id)

                elif isinstance(element, EdgeRef):
                    # Write-through: remove from SQLite before mutating memory
                    if self.graphforge and self.graphforge.backend:
                        self.graphforge.backend.delete_edge(element.id)
                    # Remove edge
                    self.graph._edges.pop(element.id, None)
                    # Remove from adjacency lists
                    if element.src.id in self.graph._outgoing:
                        self.graph._outgoing[element.src.id] = [
                            e for e in self.graph._outgoing[element.src.id] if e.id != element.id
                        ]
                    if element.dst.id in self.graph._incoming:
                        self.graph._incoming[element.dst.id] = [
                            e for e in self.graph._incoming[element.dst.id] if e.id != element.id
                        ]
                    # Remove from type index
                    if element.type in self.graph._type_index:
                        self.graph._type_index[element.type].discard(element.id)
                    # Track deletion in context so RETURN can detect access errors
                    if hasattr(ctx, "deleted_ids"):
                        ctx.deleted_ids.add(element.id)

        # Return the input rows (DELETE passes rows through for RETURN clauses)
        return input_rows

    def _execute_merge(
        self, op: Merge, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute MERGE operator with ON CREATE SET and ON MATCH SET support.

        Creates patterns if they don't exist, or matches them if they do.
        Conditionally executes SET operations based on whether elements were created or matched.

        Args:
            op: Merge operator with patterns, on_create, and on_match clauses
            input_rows: Input execution contexts

        Returns:
            Execution contexts with matched or created elements
        """
        if not self.graphforge:
            raise RuntimeError("MERGE requires GraphForge instance")

        from graphforge.ast.pattern import NodePattern

        result = []

        # Process each input row
        for ctx in input_rows:
            new_ctx = ExecutionContext()
            new_ctx.bindings = ctx.bindings.copy()

            # Track whether we created anything (for ON CREATE SET)
            was_created = False

            # Process each pattern
            for pattern in op.patterns:
                if not pattern:
                    continue

                # Extract pattern parts from new format (dict with path_variable and parts)
                # or use pattern directly if it's old format (list)
                path_variable: str | None = None
                if isinstance(pattern, dict) and "parts" in pattern:
                    pattern_parts = pattern["parts"]
                    path_variable = pattern.get("path_variable")
                else:
                    # Old format: pattern is already a list
                    pattern_parts = pattern

                # Handle simple node pattern: MERGE (n:Person {name: 'Alice'})
                if len(pattern_parts) == 1 and isinstance(pattern_parts[0], NodePattern):
                    node_pattern = pattern_parts[0]

                    # Validate no disjunctive labels in MERGE
                    if node_pattern.labels and len(node_pattern.labels) > 1:
                        raise ValueError(
                            "Disjunctive labels (using '|') are not allowed in MERGE patterns. "
                            "Use multiple MERGE statements or specify only conjunction of labels."
                        )

                    # Collect all matching nodes (MERGE matches ALL, then creates if none found)
                    if node_pattern.labels:
                        all_candidates: set = set()
                        for label_group in node_pattern.labels:
                            group_candidates = self.graph.get_nodes_by_label(label_group[0])
                            if len(label_group) > 1:
                                group_candidates = [
                                    node
                                    for node in group_candidates
                                    if all(label in node.labels for label in label_group)
                                ]
                            all_candidates.update(group_candidates)
                        candidates = list(all_candidates)
                    else:
                        candidates = list(self.graph.get_all_nodes())

                    # Null property check before candidate search
                    if node_pattern.properties:
                        for _expr in node_pattern.properties.values():
                            _val = evaluate_expression(_expr, new_ctx, self)
                            if isinstance(_val, CypherNull):
                                raise SemanticError(
                                    "MergeReadOwnWrites: Cannot merge node "
                                    "using null property values"
                                )

                    matched_nodes = []
                    for node in candidates:
                        if node_pattern.properties:
                            node_matches = True
                            for key, value_expr in node_pattern.properties.items():
                                expected_value = evaluate_expression(value_expr, new_ctx, self)
                                if isinstance(expected_value, CypherNull):
                                    node_matches = False
                                    break
                                if key not in node.properties:
                                    node_matches = False
                                    break
                                node_value = node.properties[key]
                                if isinstance(node_value, CypherNull):
                                    node_matches = False
                                    break
                                comparison_result = node_value.equals(expected_value)
                                if (
                                    not isinstance(comparison_result, CypherBool)
                                    or not comparison_result.value
                                ):
                                    node_matches = False
                                    break
                            if node_matches:
                                matched_nodes.append(node)
                        else:
                            matched_nodes.append(node)

                    if matched_nodes:
                        was_created = False
                        # Produce one output row per matched node
                        # (handled below by expanding pending_contexts)
                        _merge_matched_nodes = matched_nodes
                        bound_node = matched_nodes[0]
                        if node_pattern.variable:
                            new_ctx.bindings[node_pattern.variable] = bound_node
                        if path_variable:
                            new_ctx.bindings[path_variable] = CypherPath(
                                nodes=[bound_node], relationships=[]
                            )
                        # Extra matches beyond matched_nodes[0] get ON MATCH SET here;
                        # the first match (new_ctx) is handled by the common ON MATCH path below.
                        for extra_node in matched_nodes[1:]:
                            extra_ctx = ExecutionContext()
                            extra_ctx.bindings = ctx.bindings.copy()
                            if node_pattern.variable:
                                extra_ctx.bindings[node_pattern.variable] = extra_node
                            if path_variable:
                                extra_ctx.bindings[path_variable] = CypherPath(
                                    nodes=[extra_node], relationships=[]
                                )
                            # Apply ON MATCH SET to extra contexts too
                            if op.on_match:
                                self._execute_set_items(op.on_match.items, extra_ctx)
                            result.append(extra_ctx)
                    else:
                        was_created = True
                        node = self._create_node_from_pattern(node_pattern, new_ctx)
                        if node_pattern.variable:
                            new_ctx.bindings[node_pattern.variable] = node
                        bound_node = node
                        if path_variable:
                            new_ctx.bindings[path_variable] = CypherPath(
                                nodes=[bound_node], relationships=[]
                            )

                # Handle node-relationship-node pattern: MERGE (a)-[r:KNOWS]->(b)
                elif len(pattern_parts) >= 3:
                    rel_var = (
                        pattern_parts[1].variable if hasattr(pattern_parts[1], "variable") else None
                    )
                    was_created, _merge_src, _merge_rels, _merge_dst = (
                        self._merge_relationship_pattern(pattern_parts, new_ctx)
                    )
                    # Emit one row per matched relationship (first is already in new_ctx)
                    for extra_rel in _merge_rels[1:]:
                        extra_ctx = ExecutionContext()
                        extra_ctx.bindings = new_ctx.bindings.copy()
                        if rel_var:
                            extra_ctx.bindings[rel_var] = extra_rel
                        if path_variable:
                            extra_ctx.bindings[path_variable] = CypherPath(
                                nodes=[_merge_src, _merge_dst], relationships=[extra_rel]
                            )
                        if not was_created and op.on_match:
                            self._execute_set_items(op.on_match.items, extra_ctx)
                        result.append(extra_ctx)
                    if path_variable:
                        new_ctx.bindings[path_variable] = CypherPath(
                            nodes=[_merge_src, _merge_dst], relationships=[_merge_rels[0]]
                        )

            # Execute conditional SET operations
            if was_created and op.on_create:
                # Execute ON CREATE SET
                self._execute_set_items(op.on_create.items, new_ctx)
            elif not was_created and op.on_match:
                # Execute ON MATCH SET
                self._execute_set_items(op.on_match.items, new_ctx)

            result.append(new_ctx)

        return result

    def _merge_relationship_pattern(self, pattern_parts: list, ctx: ExecutionContext) -> tuple:
        """Merge a relationship pattern (node-rel-node).

        Args:
            pattern_parts: List of pattern parts (nodes and relationships)
            ctx: Execution context

        Returns:
            4-tuple (was_created, src, rel, dst) where was_created is True if the
            pattern was newly created (False if matched), src is the source NodeRef,
            rel is the EdgeRef, and dst is the destination NodeRef.
        """
        from graphforge.ast.pattern import NodePattern, RelationshipPattern

        # For now, only support simple 3-part patterns: (a)-[r]->(b)
        # TODO: Support multi-hop patterns in the future
        if len(pattern_parts) != 3:
            raise ValueError(
                "MERGE currently only supports simple relationship patterns: (a)-[r]->(b)"
            )

        src_pattern = pattern_parts[0]
        rel_pattern = pattern_parts[1]
        dst_pattern = pattern_parts[2]

        if not isinstance(src_pattern, NodePattern):
            raise ValueError("First element of relationship pattern must be a node")
        if not isinstance(rel_pattern, RelationshipPattern):
            raise ValueError("Second element of relationship pattern must be a relationship")
        if not isinstance(dst_pattern, NodePattern):
            raise ValueError("Third element of relationship pattern must be a node")

        # Validate: null property values in MERGE pattern are not allowed
        for _pattern in (src_pattern, dst_pattern):
            if _pattern.properties:
                for _expr in _pattern.properties.values():
                    if isinstance(evaluate_expression(_expr, ctx, self), CypherNull):
                        raise SemanticError(
                            "MergeReadOwnWrites: Cannot merge node using null property values"
                        )
        if rel_pattern.properties:
            for _expr in rel_pattern.properties.values():
                if isinstance(evaluate_expression(_expr, ctx, self), CypherNull):
                    raise SemanticError(
                        "MergeReadOwnWrites: Cannot merge relationship using null property values"
                    )

        # Step 1: Resolve or create source node
        src_node = self._merge_node_in_context(src_pattern, ctx)

        # Step 2: Resolve or create destination node
        dst_node = self._merge_node_in_context(dst_pattern, ctx)

        # Step 3: Try to find existing relationship
        from graphforge.ast.pattern import Direction

        rel_type = rel_pattern.types[0] if rel_pattern.types else "RELATED_TO"
        found_rels: list = []

        # Get edges based on direction
        edges_to_check = []
        if rel_pattern.direction == Direction.OUT:
            # Outgoing: (src)-[r]->(dst)
            edges_to_check = self.graph.get_outgoing_edges(src_node.id)
        elif rel_pattern.direction == Direction.IN:
            # Incoming: (src)<-[r]-(dst), so check incoming edges of src_node
            edges_to_check = self.graph.get_incoming_edges(src_node.id)
        elif rel_pattern.direction == Direction.UNDIRECTED:
            # Undirected: (src)-[r]-(dst), check both directions
            outgoing = self.graph.get_outgoing_edges(src_node.id)
            incoming = self.graph.get_incoming_edges(src_node.id)
            # Deduplicate by edge ID
            seen_ids = set()
            for edge in outgoing + incoming:
                if edge.id not in seen_ids:
                    seen_ids.add(edge.id)
                    edges_to_check.append(edge)

        for edge in edges_to_check:
            # Check if edge connects to destination node (direction-aware)
            if rel_pattern.direction == Direction.OUT:
                if edge.dst.id != dst_node.id:
                    continue
            elif rel_pattern.direction == Direction.IN:
                if edge.src.id != dst_node.id:
                    continue
            elif rel_pattern.direction == Direction.UNDIRECTED:
                # For undirected, dst_node can be on either end
                if dst_node.id not in (edge.dst.id, edge.src.id):
                    continue

            # Check if edge type matches
            if edge.type != rel_type:
                continue

            # Check if edge properties match
            if rel_pattern.properties:
                match = True
                for key, value_expr in rel_pattern.properties.items():
                    expected_value = evaluate_expression(value_expr, ctx, self)

                    # NULL in pattern never matches
                    if isinstance(expected_value, CypherNull):
                        match = False
                        break

                    if key not in edge.properties:
                        match = False
                        break

                    # Compare CypherValue objects using equality
                    edge_value = edge.properties[key]

                    # NULL in edge property never matches
                    if isinstance(edge_value, CypherNull):
                        match = False
                        break

                    comparison_result = edge_value.equals(expected_value)

                    if not isinstance(comparison_result, CypherBool):
                        match = False
                        break

                    if not comparison_result.value:
                        match = False
                        break

                if match:
                    found_rels.append(edge)
            else:
                # No properties specified, just match on type
                found_rels.append(edge)

        # Step 4: Bind or create relationship
        if found_rels:
            # Relationships exist — bind first match; caller handles extras
            if rel_pattern.variable:
                ctx.bindings[rel_pattern.variable] = found_rels[0]
            return False, src_node, found_rels, dst_node
        else:
            # Relationship doesn't exist - create it and return (was_created=True, src, [rel], dst)
            # For IN direction, swap src and dst so stored edge direction is correct
            if rel_pattern.direction == Direction.IN:
                # Pattern: (src)<-[r]-(dst) means dst->src in storage
                edge = self._create_relationship_from_pattern(
                    dst_node, src_node, rel_type, rel_pattern, ctx
                )
            else:
                # OUT and UNDIRECTED: (src)-[r]->(dst) or (src)-[r]-(dst)
                edge = self._create_relationship_from_pattern(
                    src_node, dst_node, rel_type, rel_pattern, ctx
                )
            if rel_pattern.variable:
                ctx.bindings[rel_pattern.variable] = edge
            return True, src_node, [edge], dst_node

    def _merge_node_in_context(self, node_pattern, ctx: ExecutionContext):
        """Merge a single node (find or create) and bind to context.

        Args:
            node_pattern: NodePattern from AST
            ctx: Execution context

        Returns:
            NodeRef (found or created)
        """

        # Check if variable is already bound (from MATCH clause)
        if node_pattern.variable and node_pattern.variable in ctx.bindings:
            return ctx.bindings[node_pattern.variable]

        # Validate: null property values in MERGE node pattern are not allowed
        if node_pattern.properties:
            for _expr in node_pattern.properties.values():
                if isinstance(evaluate_expression(_expr, ctx, self), CypherNull):
                    raise SemanticError(
                        "MergeReadOwnWrites: Cannot merge node using null property values"
                    )

        # Validate no disjunctive labels in MERGE
        if node_pattern.labels and len(node_pattern.labels) > 1:
            raise ValueError(
                "Disjunctive labels (using '|') are not allowed in MERGE patterns. "
                "Use multiple MERGE statements or specify only conjunction of labels."
            )

        # Try to find existing node
        found_node = None

        if node_pattern.labels:
            # Collect candidate nodes from all label groups
            all_candidates = set()
            for label_group in node_pattern.labels:
                # Get nodes by first label in the group
                group_candidates = self.graph.get_nodes_by_label(label_group[0])

                # Filter to nodes with ALL labels in this group (conjunction)
                if len(label_group) > 1:
                    group_candidates = [
                        node
                        for node in group_candidates
                        if all(label in node.labels for label in label_group)
                    ]

                all_candidates.update(group_candidates)

            candidates = list(all_candidates)

            for node in candidates:
                # Check if properties match
                if node_pattern.properties:
                    match = True
                    for key, value_expr in node_pattern.properties.items():
                        expected_value = evaluate_expression(value_expr, ctx, self)

                        # NULL in pattern never matches
                        if isinstance(expected_value, CypherNull):
                            match = False
                            break

                        if key not in node.properties:
                            match = False
                            break

                        # Compare CypherValue objects using equality
                        node_value = node.properties[key]

                        # NULL in node property never matches
                        if isinstance(node_value, CypherNull):
                            match = False
                            break

                        comparison_result = node_value.equals(expected_value)

                        if not isinstance(comparison_result, CypherBool):
                            match = False
                            break

                        if not comparison_result.value:
                            match = False
                            break

                    if match:
                        found_node = node
                        break
                else:
                    # No properties specified, just match on labels
                    found_node = node
                    break

        # Bind found node or create new one
        if found_node:
            if node_pattern.variable:
                ctx.bindings[node_pattern.variable] = found_node
            return found_node
        else:
            node = self._create_node_from_pattern(node_pattern, ctx)
            if node_pattern.variable:
                ctx.bindings[node_pattern.variable] = node
            return node

    def _execute_set_items(self, items: list, ctx: ExecutionContext) -> None:
        """Execute SET items on a context (helper for conditional SET).

        Args:
            items: List of (target, expr) or (variable, op, expr) tuples
            ctx: Execution context to update
        """
        from graphforge.ast.expression import Variable

        for item in items:
            if len(item) == 3:
                target, op, value_expr = item
                var_name = target.name if isinstance(target, Variable) else str(target)

                if op == ":+":
                    # SET n:Label1:Label2 — add labels; value_expr is a list of label strings
                    if var_name in ctx.bindings:
                        from graphforge.types.graph import NodeRef

                        element = ctx.bindings[var_name]
                        if isinstance(element, NodeRef):
                            new_labels = frozenset(element.labels) | frozenset(value_expr)
                            updated = NodeRef(
                                id=element.id,
                                labels=new_labels,
                                properties=element.properties,
                            )
                            self.graph.add_node(updated)
                            # Update all bindings pointing at the same node id
                            for k in list(ctx.bindings.keys()):
                                if (
                                    isinstance(ctx.bindings[k], NodeRef)
                                    and ctx.bindings[k].id == element.id
                                ):
                                    ctx.bindings[k] = updated
                    continue

                # SET n = {map}  or  SET n += {map}
                if var_name not in ctx.bindings:
                    continue
                element = ctx.bindings[var_name]
                if isinstance(element, CypherNull):
                    # SET null += {map} or SET null = {map} → no-op (openCypher semantics)
                    continue
                if not hasattr(element, "properties"):
                    raise TypeError(
                        f"Type mismatch: expected a node or relationship for SET {var_name}, "
                        f"got {type(element).__name__}"
                    )
                new_value = evaluate_expression(value_expr, ctx, self)
                if isinstance(new_value, CypherMap):
                    props: dict = new_value.value
                elif isinstance(new_value, CypherNull):
                    props = {}
                elif isinstance(new_value, dict):
                    props = new_value
                elif hasattr(new_value, "properties"):
                    # SET r = node — copy properties, wrapping raw values to CypherValue
                    props = {
                        k: v if isinstance(v, CypherValue) else from_python(v)
                        for k, v in new_value.properties.items()
                    }
                else:
                    raise TypeError(
                        f"SET {var_name} = requires a map, got {type(new_value).__name__}"
                    )
                # Evict old property index entries before mutation
                from graphforge.types.graph import NodeRef as _NodeRef

                if isinstance(element, _NodeRef):
                    self.graph.remove_node_from_indexes(element)

                if op == "=":
                    # Replace all properties
                    element.properties.clear()
                    for k, v in props.items():
                        if not isinstance(v, CypherNull):
                            element.properties[k] = v
                else:
                    # += : merge/augment properties
                    for k, v in props.items():
                        if isinstance(v, CypherNull):
                            element.properties.pop(k, None)
                        else:
                            element.properties[k] = v

                if isinstance(element, _NodeRef):
                    self.graph.add_node_to_indexes(element)
                continue

            property_access, value_expr = item
            # Evaluate the target (should be a PropertyAccess node)
            if hasattr(property_access, "variable") and hasattr(property_access, "property"):
                var_name = (
                    property_access.variable.name
                    if hasattr(property_access.variable, "name")
                    else property_access.variable
                )
                prop_name = property_access.property

                # Get the node or edge from context
                if var_name in ctx.bindings:
                    element = ctx.bindings[var_name]

                    # openCypher: SET on null entity is a no-op
                    if isinstance(element, CypherNull):
                        continue

                    if not hasattr(element, "properties"):
                        continue

                    # Evaluate the new value
                    new_value = evaluate_expression(value_expr, ctx, self)

                    # Validate property type — list of maps is not a valid Cypher property
                    if isinstance(new_value, CypherList):
                        for item in new_value.value:  # noqa: PLW2901
                            if isinstance(item, CypherMap):
                                raise TypeError(
                                    "InvalidPropertyType: Property values can only be of primitive "
                                    "types or lists thereof"
                                )

                    # Keep property index in sync: evict old values before mutation
                    from graphforge.types.graph import NodeRef as _NodeRef

                    if isinstance(element, _NodeRef):
                        self.graph.remove_node_from_indexes(element)

                    # openCypher: SET n.prop = null removes the property
                    if isinstance(new_value, CypherNull):
                        element.properties.pop(prop_name, None)
                    else:
                        element.properties[prop_name] = new_value

                    if isinstance(element, _NodeRef):
                        self.graph.add_node_to_indexes(element)

    def _execute_unwind(
        self,
        op: Unwind,
        input_rows: list[ExecutionContext],
        row_limit: int | None = None,
    ) -> list[ExecutionContext]:
        """Execute UNWIND operator.

        Expands a list into multiple rows, binding each element to a variable.
        Stops after row_limit rows when the downstream pipeline has a static limit.

        Args:
            op: Unwind operator with expression and variable
            input_rows: Input execution contexts
            row_limit: Optional early-exit row budget from _pipeline_limit

        Returns:
            Expanded execution contexts (one per list element per input row)
        """
        result: list[ExecutionContext] = []

        # If no input rows, start with one empty context
        if not input_rows:
            input_rows = [ExecutionContext()]

        for ctx in input_rows:
            if row_limit is not None and len(result) >= row_limit:
                break

            # Evaluate the list expression
            value = evaluate_expression(op.expression, ctx, self)

            # Handle NULL - treated as empty list (produces no rows)
            if isinstance(value, CypherNull):
                continue

            # Handle CypherList
            if isinstance(value, CypherList):
                for item in value.value:
                    if row_limit is not None and len(result) >= row_limit:
                        break
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)
                    new_ctx.bind(op.variable, item)
                    result.append(new_ctx)
            else:
                # If not a list or NULL, wrap in a list
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(ctx.bindings)
                new_ctx.bind(op.variable, value)
                result.append(new_ctx)

        return result

    def _execute_optional_expand(
        self, op: OptionalExpandEdges, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute OptionalExpandEdges operator (left outer join).

        Like ExpandEdges, but preserves rows with NULL bindings when no matches found.
        This implements OPTIONAL MATCH semantics.

        Args:
            op: OptionalExpandEdges operator
            input_rows: Input execution contexts

        Returns:
            Execution contexts with expanded relationships or NULL bindings
        """
        from graphforge.types.graph import NodeRef

        result = []

        def _null_fill(base_ctx: ExecutionContext) -> ExecutionContext:
            """Null-fill vars introduced by this OPTIONAL MATCH hop.

            Pre-bound variables (already in bindings before this operator) are preserved.
            """
            null_ctx = ExecutionContext()
            null_ctx.bindings = dict(base_ctx.bindings)
            if op.dst_var not in base_ctx.bindings:
                null_ctx.bind(op.dst_var, CypherNull())
            if op.edge_var and op.edge_var not in base_ctx.bindings:
                null_ctx.bind(op.edge_var, CypherNull())
            if op.path_var:
                null_ctx.bind(op.path_var, CypherNull())
            for v in op.null_fill_vars:
                if v not in base_ctx.bindings:
                    null_ctx.bind(v, CypherNull())
            return null_ctx

        for ctx in input_rows:
            # Get source node
            if op.src_var not in ctx.bindings:
                result.append(_null_fill(ctx))
                continue

            src_node = ctx.get(op.src_var)
            if not isinstance(src_node, NodeRef):
                # Source is null (propagated from earlier failed optional hop)
                result.append(_null_fill(ctx))
                continue

            # Get edges based on direction
            if op.direction == "OUT":
                edges = self.graph.get_outgoing_edges(src_node.id)
            elif op.direction == "IN":
                edges = self.graph.get_incoming_edges(src_node.id)
            else:  # UNDIRECTED — deduplicate self-loops that appear in both lists
                _seen_ids: set[object] = set()
                edges = []
                for _e in self.graph.get_outgoing_edges(
                    src_node.id
                ) + self.graph.get_incoming_edges(src_node.id):
                    if _e.id not in _seen_ids:
                        edges.append(_e)
                        _seen_ids.add(_e.id)

            # Filter by edge types if specified
            if op.edge_types:
                edges = [e for e in edges if e.type in op.edge_types]

            # If edge_var is already bound (e.g., passed through WITH), only keep that edge
            if op.edge_var and op.edge_var in ctx.bindings:
                bound_edge = ctx.bindings[op.edge_var]
                if hasattr(bound_edge, "id"):
                    edges = [e for e in edges if e.id == bound_edge.id]
                else:
                    edges = []

            # If dst_var is already bound (from preceding MATCH), filter edges to
            # only those reaching that specific destination node — LEFT JOIN semantics.
            dst_bound = op.dst_var in ctx.bindings
            if dst_bound:
                from graphforge.types.graph import NodeRef as _NodeRef

                bound_dst = ctx.get(op.dst_var)
                if isinstance(bound_dst, _NodeRef):
                    # Enforce dst_labels against the pre-bound node before considering edges
                    if op.dst_labels and not self._node_matches_labels(bound_dst, op.dst_labels):
                        result.append(_null_fill(ctx))
                        continue
                    bound_dst_id = bound_dst.id

                    from graphforge.types.graph import EdgeRef as _EdgeRef

                    def _edge_dst_id(e: _EdgeRef, direction: str, src_id: object) -> object:
                        if direction == "OUT":
                            return e.dst.id
                        elif direction == "IN":
                            return e.src.id
                        return e.dst.id if e.src.id == src_id else e.src.id

                    matching_edges = [
                        e
                        for e in edges
                        if _edge_dst_id(e, op.direction, src_node.id) == bound_dst_id
                    ]
                    if matching_edges:
                        matched_dst_rows = []
                        for edge in matching_edges:
                            new_ctx = ExecutionContext()
                            new_ctx.bindings = dict(ctx.bindings)
                            if op.edge_var:
                                new_ctx.bind(op.edge_var, edge)
                            if op.path_var:
                                dst_node_bound = bound_dst
                                new_ctx.bind(
                                    op.path_var,
                                    CypherPath(
                                        nodes=[src_node, dst_node_bound], relationships=[edge]
                                    ),
                                )
                            # Apply absorbed WHERE predicate within optional scope
                            if op.where_predicate is not None:
                                pred_result = evaluate_expression(op.where_predicate, new_ctx, self)
                                if not (isinstance(pred_result, CypherBool) and pred_result.value):
                                    continue
                            matched_dst_rows.append(new_ctx)
                        if matched_dst_rows:
                            result.extend(matched_dst_rows)
                        else:
                            result.append(_null_fill(ctx))
                    else:
                        result.append(_null_fill(ctx))
                else:
                    # Bound dst is not a node (e.g. NULL) — treat as no match
                    result.append(_null_fill(ctx))
                continue

            # LEFT JOIN behavior
            if not edges:
                result.append(_null_fill(ctx))
            else:
                # INNER JOIN behavior - bind actual values, then apply optional WHERE
                matched_rows = []
                for edge in edges:
                    new_ctx = ExecutionContext()
                    new_ctx.bindings = dict(ctx.bindings)

                    # Bind edge if variable specified
                    if op.edge_var:
                        new_ctx.bind(op.edge_var, edge)

                    # Determine destination node based on direction
                    if op.direction == "OUT":
                        dst_node = edge.dst
                    elif op.direction == "IN":
                        dst_node = edge.src
                    else:  # UNDIRECTED - check which end is the source
                        dst_node = edge.dst if edge.src.id == src_node.id else edge.src

                    new_ctx.bind(op.dst_var, dst_node)

                    # Apply inline dst label filter
                    if op.dst_labels:
                        if not self._node_matches_labels(dst_node, op.dst_labels):
                            continue  # dst doesn't have required labels

                    if op.path_var:
                        new_ctx.bind(
                            op.path_var,
                            CypherPath(nodes=[src_node, dst_node], relationships=[edge]),
                        )

                    # Apply absorbed WHERE predicate within optional scope
                    if op.where_predicate is not None:
                        pred_result = evaluate_expression(op.where_predicate, new_ctx, self)
                        if not (isinstance(pred_result, CypherBool) and pred_result.value):
                            continue  # This candidate fails WHERE — skip

                    matched_rows.append(new_ctx)

                if matched_rows:
                    result.extend(matched_rows)
                else:
                    result.append(_null_fill(ctx))

        return result

    def _execute_apply_optional(
        self, op: ApplyOptional, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ApplyOptional operator (atomic multi-hop left outer join).

        For each outer row, runs the inner subplan. If results exist for that row,
        emit them. If no results exist, emit the outer row with null_fill_vars = NULL.
        """
        result = []

        for ctx in input_rows:
            # Execute the subplan seeded with this outer row's bindings
            subplan_rows = [ctx]
            for sub_op_idx, sub_op in enumerate(op.subplan):
                subplan_rows = self._execute_operator(
                    sub_op, subplan_rows, sub_op_idx, len(op.subplan)
                )
                if not subplan_rows:
                    break

            if subplan_rows:
                result.extend(subplan_rows)
            else:
                # No match — null-fill all pattern variables
                null_ctx = ExecutionContext()
                null_ctx.bindings = dict(ctx.bindings)
                for v in op.null_fill_vars:
                    null_ctx.bind(v, CypherNull())
                result.append(null_ctx)

        return result

    def _extract_column_names_from_branch(self, branch: list) -> set[str] | None:
        """Extract column names from a branch plan.

        Used for UNION validation when branches return no rows.

        Args:
            branch: List of operators in the branch

        Returns:
            Set of column names, or None if no Project/Aggregate operator found
        """
        # Find the last Project or Aggregate operator in the branch
        for op in reversed(branch):
            if isinstance(op, Project):
                columns = set()
                for i, return_item in enumerate(op.items):
                    columns.add(_return_item_key(return_item, fallback_index=i))
                return columns
            elif isinstance(op, Aggregate):
                columns = set()
                for j, return_item in enumerate(op.return_items):
                    columns.add(_return_item_key(return_item, fallback_index=j))
                return columns
        return None

    def _execute_union(self, op: Union, input_rows: list[ExecutionContext]) -> list[Any]:
        """Execute Union operator.

        Combines results from multiple query branches. Each branch is executed
        independently and results are merged.

        Args:
            op: Union operator with branches
            input_rows: Input execution contexts (typically empty for UNION at query level)

        Returns:
            Combined results from all branches (list of dicts or ExecutionContexts)

        Raises:
            ValueError: If branches have incompatible column sets
        """
        all_results: list[Any] = []
        branch_columns: list[tuple[int, set[str]]] = []

        # Execute each branch independently
        for branch_idx, branch in enumerate(op.branches):
            # Execute this branch's pipeline
            branch_results: list[Any] = input_rows if input_rows else [ExecutionContext()]
            for op_index, branch_op in enumerate(branch):
                branch_results = self._execute_operator(
                    branch_op, branch_results, op_index, len(branch)
                )

            # Track column names for validation
            columns: set[str] | None = None

            if branch_results and isinstance(branch_results[0], dict):
                # Non-empty results - extract columns from first row
                columns = set(branch_results[0].keys())
            elif not branch_results:
                # Empty results - extract column schema from branch plan
                columns = self._extract_column_names_from_branch(branch)

            # Add to branch_columns if we successfully extracted a schema
            # Store as (branch_index, columns) tuple to preserve original branch numbering
            if columns is not None:
                branch_columns.append((branch_idx, columns))

            all_results.extend(branch_results)

        # Validate that all branches have the same column names
        if branch_columns and len(branch_columns) > 1:
            first_branch_idx, first_columns = branch_columns[0]
            for branch_idx, cols in branch_columns[1:]:
                if cols != first_columns:
                    # Column mismatch - raise error
                    # Use 1-based numbering for user-facing error messages
                    first_branch_num = first_branch_idx + 1
                    current_branch_num = branch_idx + 1
                    missing_in_branch = first_columns - cols
                    extra_in_branch = cols - first_columns
                    error_parts = []
                    if missing_in_branch:
                        msg = (
                            f"missing columns {sorted(missing_in_branch)} "
                            f"in branch {current_branch_num}"
                        )
                        error_parts.append(msg)
                    if extra_in_branch:
                        msg = (
                            f"extra columns {sorted(extra_in_branch)} "
                            f"in branch {current_branch_num}"
                        )
                        error_parts.append(msg)
                    error_msg = (
                        f"All sub queries in an UNION must have the same column names "
                        f"(branch {first_branch_num} vs branch {current_branch_num}): "
                        f"{'; '.join(error_parts)}"
                    )
                    raise ValueError(error_msg)

        # UNION (not UNION ALL) requires deduplication
        if not op.all:
            # Convert to hashable representations for deduplication
            seen: set[tuple[Any, ...]] = set()
            deduplicated: list[Any] = []
            for row in all_results:
                key: tuple[Any, ...]
                if isinstance(row, ExecutionContext):
                    # Hash based on bindings
                    key = tuple(
                        sorted((k, self._value_to_hashable(v)) for k, v in row.bindings.items())
                    )
                else:
                    # Dict result (from RETURN)
                    key = tuple(sorted((k, self._value_to_hashable(v)) for k, v in row.items()))

                if key not in seen:
                    seen.add(key)
                    deduplicated.append(row)
            return deduplicated

        return all_results

    def _execute_call(self, op, input_rows: list[ExecutionContext]) -> list[ExecutionContext]:
        """Execute Call operator (for CALL { } subqueries).

        Executes a nested query pipeline for each input row, with variable scoping:
        - Correlated: Subquery inherits outer scope bindings and can return new variables
        - Used for CALL { } clauses that produce rows

        Args:
            op: Call operator with nested pipeline
            input_rows: Input execution contexts (outer query context)

        Returns:
            Execution contexts with combined bindings from outer and inner queries
        """
        from graphforge.planner.operators import Aggregate, Union

        result = []

        # Detect if this is a unit subquery (no Project/Aggregate/Union)
        # Unit subqueries produce exactly 1 row per input (execute side effects only)
        is_unit_subquery = not any(
            isinstance(nested_op, (Project, Aggregate, Union)) for nested_op in op.operators
        )

        for outer_ctx in input_rows:
            # Create subquery context with inherited bindings (correlated subquery)
            sub_ctx = ExecutionContext()
            sub_ctx.bindings = dict(outer_ctx.bindings)

            # Execute nested query pipeline
            sub_rows = [sub_ctx]
            for i, nested_op in enumerate(op.operators):
                sub_rows = self._execute_operator(nested_op, sub_rows, i, len(op.operators))

            if is_unit_subquery:
                # Unit subquery: always produce exactly 1 output row per input row
                # (Ignore sub_rows cardinality - just preserve outer bindings)
                combined_ctx = ExecutionContext()
                combined_ctx.bindings = dict(outer_ctx.bindings)
                result.append(combined_ctx)
            else:
                # Row-producing subquery: merge each sub_row with outer bindings
                # Dict from Project: merge returned columns into outer scope
                # ExecutionContext (non-unit): preserve cardinality
                for sub_row in sub_rows:
                    combined_ctx = ExecutionContext()
                    if isinstance(sub_row, dict):
                        # Dict from Project - merge returned columns into outer bindings
                        combined_ctx.bindings = {**outer_ctx.bindings, **sub_row}
                    else:
                        # ExecutionContext (no RETURN) - preserve outer bindings only
                        combined_ctx.bindings = dict(outer_ctx.bindings)
                    result.append(combined_ctx)

        return result

    def _execute_procedure_call(
        self, op, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute ProcedureCall operator (CALL proc.name(args) [YIELD ...]).

        Looks up the procedure in the registry, evaluates arguments against each
        input row, calls the implementation, and expands output rows into
        ExecutionContexts with YIELD columns bound.

        For standalone calls (no prior rows), a single empty seed context is used.
        """
        from graphforge.procedures.registry import ProcedureRegistry

        registry: ProcedureRegistry | None = self.procedure_registry
        if self.graphforge is not None:
            registry = getattr(self.graphforge, "procedure_registry", registry)

        # Unknown procedure → ProcedureError
        if registry is None or not registry.exists(op.procedure_name):
            raise ValueError(
                f"ProcedureError: ProcedureNotFound — unknown procedure `{op.procedure_name}`"
            )

        defn = registry.get(op.procedure_name)
        assert defn is not None  # already checked via registry.exists() above

        # Validate argument count for explicit calls
        if op.arguments is not None:  # None = implicit args
            if len(op.arguments) != len(defn.parameters):
                raise SyntaxError(
                    f"InvalidNumberOfArguments — procedure `{op.procedure_name}` "
                    f"expects {len(defn.parameters)} argument(s), "
                    f"got {len(op.arguments)}"
                )

        # Seed rows: standalone CALL starts with one empty context;
        # in-query CALL propagates from input (empty input = empty output).
        if op.standalone:
            contexts = input_rows if input_rows else [ExecutionContext()]
        else:
            contexts = input_rows  # may be empty — that's fine

        result: list[ExecutionContext] = []

        for outer_ctx in contexts:
            # Evaluate arguments
            if op.arguments is None:
                # Implicit args: look up parameter names in current parameters dict
                evaluated_args = []
                for param in defn.parameters:
                    cypher_val = outer_ctx.bindings.get(f"${param.name}")
                    if cypher_val is None:
                        # Try without $ prefix (in case parameters were injected directly)
                        cypher_val = outer_ctx.bindings.get(param.name)
                    if cypher_val is None:
                        raise SyntaxError(
                            f"ParameterMissing: MissingParameter — "
                            f"parameter `{param.name}` required by `{op.procedure_name}`"
                        )
                    evaluated_args.append(_unwrap_cypher_val(cypher_val))
            else:
                evaluated_args = []
                for expr in op.arguments:
                    val = evaluate_expression(expr, outer_ctx, self)
                    evaluated_args.append(_unwrap_cypher_val(val))

            # Validate argument types
            for i, (param, py_val) in enumerate(zip(defn.parameters, evaluated_args)):
                if py_val is None:
                    continue  # null is always allowed for nullable params
                _check_proc_arg_type(param, py_val, op.procedure_name, i)

            # Call procedure implementation
            if defn.implementation is None:
                proc_rows: list[dict] = []
            else:
                proc_rows = defn.implementation(*evaluated_args)

            # Determine output columns
            output_col_names = [c.name for c in defn.output_columns]

            # No output columns → void procedure
            if not output_col_names:
                # Standalone void: no rows produced
                # In-query void: pass input row through unchanged
                if not op.standalone:
                    combined = ExecutionContext()
                    combined.bindings = dict(outer_ctx.bindings)
                    result.append(combined)
                continue

            # Determine which columns to bind via YIELD
            if op.yield_star:
                # YIELD * — all output columns, standalone only
                yield_col_names = output_col_names
                yield_aliases = {name: name for name in output_col_names}
            elif op.yield_items is not None:
                # Explicit YIELD col1, col2 AS alias
                yield_col_names = []
                yield_aliases = {}
                seen_aliases: set[str] = set()
                for item in op.yield_items:
                    src = (
                        item.expression.name
                        if hasattr(item.expression, "name")
                        else str(item.expression)
                    )
                    alias = item.alias if item.alias else src
                    if alias in seen_aliases:
                        raise SyntaxError(
                            f"VariableAlreadyBound — YIELD alias `{alias}` used more than once"
                        )
                    seen_aliases.add(alias)
                    yield_col_names.append(src)
                    yield_aliases[src] = alias
            else:
                # No YIELD clause on standalone call — expose all columns
                yield_col_names = output_col_names
                yield_aliases = {name: name for name in output_col_names}

            for proc_row in proc_rows:
                new_ctx = ExecutionContext()
                new_ctx.bindings = dict(outer_ctx.bindings)
                for col_name in yield_col_names:
                    alias = yield_aliases.get(col_name, col_name)
                    raw = proc_row.get(col_name)
                    new_ctx.bind(alias, _python_to_cypher(raw))
                result.append(new_ctx)

        return result

    def _execute_subquery(
        self, _op: Subquery, input_rows: list[ExecutionContext]
    ) -> list[ExecutionContext]:
        """Execute Subquery operator (for EXISTS/COUNT expressions).

        NOTE: This is a placeholder - subqueries are evaluated in expression context
        via evaluator.py, not as standalone operators.

        Args:
            _op: Subquery operator with nested pipeline (unused - placeholder)
            input_rows: Input execution contexts

        Returns:
            Input contexts unchanged
        """
        # Subqueries are evaluated as expressions, not operators
        return input_rows
