"""Shared fixtures for perf/dataset QA tests."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
import json
from pathlib import Path
import resource
import time

import pytest

BASELINE_FILE = (
    Path(__file__).parent.parent.parent / "benchmarks" / "real_dataset_baseline_v0.3.9.json"
)


@contextmanager
def timed(label: str) -> Generator[dict, None, None]:
    """Context manager that records elapsed wall time into a result dict."""
    result: dict = {}
    start = time.perf_counter()
    try:
        yield result
    finally:
        result["elapsed"] = time.perf_counter() - start
        result["label"] = label


def load_baseline() -> dict:
    if BASELINE_FILE.exists():
        return json.loads(BASELINE_FILE.read_text())
    return {}


def save_baseline(data: dict) -> None:
    BASELINE_FILE.parent.mkdir(parents=True, exist_ok=True)
    BASELINE_FILE.write_text(json.dumps(data, indent=2))


@pytest.fixture(scope="session")
def baseline() -> Generator[dict, None, None]:
    """Session-scoped baseline results dict — saved to disk at teardown."""
    data = load_baseline()
    yield data
    save_baseline(data)


def record(baseline_data: dict, dataset: str, metric: str, value: float) -> None:
    baseline_data.setdefault(dataset, {})[metric] = round(value, 4)


def rss_mb() -> float:
    """Return current process RSS in megabytes.

    Uses ``resource.getrusage`` which is available on all POSIX platforms.
    On Linux ``ru_maxrss`` is in kilobytes; on macOS it is in bytes.
    """
    import sys

    rss_raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return rss_raw / (1024 * 1024)
    # Linux: value is in kibibytes
    return rss_raw / 1024


@contextmanager
def rss_snapshot() -> Generator[dict, None, None]:
    """Context manager that yields a dict populated with ``rss_delta_mb``.

    Usage::

        with rss_snapshot() as rss:
            do_something_memory_intensive()
        print(rss["rss_delta_mb"])

    Note: ``resource.getrusage`` reports the *peak* RSS of the process, not
    the current live RSS.  The delta therefore represents the net increase in
    peak RSS during the block — it will be zero if the block did not push RSS
    beyond the previous high-water mark.
    """
    result: dict = {}
    before = rss_mb()
    try:
        yield result
    finally:
        after = rss_mb()
        result["rss_delta_mb"] = round(after - before, 2)
