"""Real-dataset QA and performance profiling suite.

Validates correctness and measures latency against real SNAP graphs of
graduated sizes. Results are written to benchmarks/real_dataset_baseline_v0.3.9.json
for use as before/after deltas in v0.3.9 perf PRs.

Run with:
    make test-perf                     # all tiers
    make test-perf-xs                  # XS/S only (no large downloads)

Marks:
    perf        - any test in this suite
    perf_large  - requires downloading datasets ≥ 100 MB
"""

from __future__ import annotations

from pathlib import Path
import tempfile

import pytest

from graphforge import GraphForge
from graphforge.datasets.registry import load_dataset

from .conftest import record, timed

# ---------------------------------------------------------------------------
# Dataset tiers
# ---------------------------------------------------------------------------
#
# XS/S: already-cached small datasets — run unconditionally
# M:    ~15 MB download  (~334k nodes, ~925k edges)
# L:    ~500 MB download (~4M nodes, ~35M edges)
# XL:   ~1.7 GB download (~3M nodes, ~117M edges)

TIERS = {
    "xs-karate": {
        "name": "netrepo-karate",
        "expected_nodes": 34,
        "expected_edges": 78,
        "large": False,
        "sqlite_roundtrip": True,  # fast enough to round-trip via SQLite
    },
    "s-facebook": {
        "name": "snap-ego-facebook",
        "expected_nodes": 4039,
        "expected_edges": 88234,
        "large": False,
        # SQLite bulk I/O fixed in #421 — reload no longer hangs
        "sqlite_roundtrip": True,
    },
    "m-amazon": {
        "name": "snap-com-amazon",
        "expected_nodes": 334863,
        "expected_edges": 925872,
        "large": False,  # 15 MB — reasonable for CI if marked snap
        # SQLite bulk reload is O(n) and slow until #392 is fixed
        "sqlite_roundtrip": False,
    },
    "l-livejournal": {
        "name": "snap-com-livejournal",
        "expected_nodes": 3997962,
        "expected_edges": 34681189,
        "large": True,  # 500 MB compressed / ~12 GB RSS
        "sqlite_roundtrip": False,
        # count_edges (~260 s) and topn (~155 s) are too slow for routine runs;
        # exclude them so the L-tier run is manageable.
        "skip_queries": {"count_edges", "topn", "aggregation"},
    },
    "xl-cit-patents": {
        "name": "snap-cit-patents",
        "expected_nodes": 3774768,
        "expected_edges": 16518948,
        "large": True,  # 270 MB compressed / ~5.8 GB RSS
        "sqlite_roundtrip": False,
        # count_edges (~197 s cold) and topn (~52 s), aggregation (~21 s) are slow.
        "skip_queries": {"count_edges", "topn", "aggregation"},
    },
    "xxl-orkut": {
        "name": "snap-com-orkut",
        "expected_nodes": 3072441,
        "expected_edges": 117185083,
        "large": True,  # 1.7 GB compressed
        "sqlite_roundtrip": False,
        "skip_queries": {"count_edges", "topn", "aggregation"},
    },
}

# Queries run against every loaded graph
BENCHMARK_QUERIES = [
    ("count_nodes", "MATCH (n) RETURN count(n) AS c"),
    ("count_edges", "MATCH ()-[r]->() RETURN count(r) AS c"),
    ("label_filter", "MATCH (n:Node) RETURN count(n) AS c"),
    # Single-hop with LIMIT — exercises traversal without full expansion
    ("one_hop", "MATCH (a:Node)-[]->(b) RETURN id(b) AS bid LIMIT 1000"),
    ("aggregation", "MATCH (n:Node) RETURN count(n) AS total, labels(n)[0] AS lbl"),
    ("topn", "MATCH (n:Node) RETURN id(n) AS nid ORDER BY nid LIMIT 100"),
    # Two-hop with LIMIT — exercises LIMIT short-circuit (#423); fast now that
    # Expand stops after the limit is reached instead of fully materialising.
    ("two_hop_limit", "MATCH (a:Node)-[]->(b)-[]->(c) RETURN id(c) AS cid LIMIT 1000"),
]

# Two-hop full expansion (no LIMIT) — slow on M-tier (~9 s) because every reachable
# path is materialised.  Guarded by @pytest.mark.perf_slow so normal CI skips it.
# Run opt-in with:  pytest -m perf_slow tests/perf/
SLOW_QUERIES = [
    ("two_hop", "MATCH (a:Node)-[]->(b)-[]->(c) RETURN count(c) AS c"),
]


def _run_suite(tier_key: str, baseline: dict) -> None:
    """Load dataset, run correctness checks, measure query latencies."""
    cfg = TIERS[tier_key]
    dataset_name = cfg["name"]

    gf = GraphForge()

    # --- Ingestion ---
    with timed("ingest") as t:
        load_dataset(gf, dataset_name)
    record(baseline, tier_key, "ingest_s", t["elapsed"])

    # --- Correctness: node count ---
    node_count = gf.execute("MATCH (n) RETURN count(n) AS c")[0]["c"].value
    assert node_count == cfg["expected_nodes"], (
        f"{tier_key}: expected {cfg['expected_nodes']} nodes, got {node_count}"
    )
    record(baseline, tier_key, "nodes", node_count)

    # --- Correctness: edge count ---
    edge_count = gf.execute("MATCH ()-[r]->() RETURN count(r) AS c")[0]["c"].value
    assert edge_count == cfg["expected_edges"], (
        f"{tier_key}: expected {cfg['expected_edges']} edges, got {edge_count}"
    )
    record(baseline, tier_key, "edges", edge_count)

    # --- Query benchmarks ---
    skip_queries: set[str] = cfg.get("skip_queries", set())
    latencies: dict[str, float] = {}
    for label, query in BENCHMARK_QUERIES:
        if label in skip_queries:
            continue
        # cold run — assert non-empty to catch silent executor regressions
        with timed(label) as t:
            rows = gf.execute(query)
        assert rows, f"{tier_key}/{label}: expected at least one result row"
        cold = t["elapsed"]

        # warm run
        with timed(label + "_warm") as t:
            gf.execute(query)
        warm = t["elapsed"]

        latencies[f"{label}_cold_s"] = cold
        latencies[f"{label}_warm_s"] = warm

    for k, v in latencies.items():
        record(baseline, tier_key, k, v)

    # --- SQLite round-trip correctness ---
    # Skipped for M/L/XL until #392 (SQLite bulk reload) is fixed — reload is O(n)
    # with high per-row overhead and takes minutes for >10k edges.
    if cfg.get("sqlite_roundtrip", False):
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "roundtrip.db"

            gf_persist = GraphForge(str(db_path))
            with timed("persist_write") as t:
                load_dataset(gf_persist, dataset_name)
            gf_persist.close()
            record(baseline, tier_key, "persist_write_s", t["elapsed"])

            with timed("persist_read") as t:
                gf_reload = GraphForge(str(db_path))
            record(baseline, tier_key, "persist_read_s", t["elapsed"])

            reloaded_count = gf_reload.execute("MATCH (n) RETURN count(n) AS c")[0]["c"].value
            assert reloaded_count == cfg["expected_nodes"], (
                f"{tier_key}: after reload expected {cfg['expected_nodes']} nodes, got {reloaded_count}"
            )
            gf_reload.close()


# ---------------------------------------------------------------------------
# Test cases — one per tier
# ---------------------------------------------------------------------------


@pytest.mark.perf
@pytest.mark.snap
def test_xs_karate(baseline):
    _run_suite("xs-karate", baseline)


@pytest.mark.perf
@pytest.mark.snap
def test_s_facebook(baseline):
    _run_suite("s-facebook", baseline)


@pytest.mark.perf
@pytest.mark.snap
def test_m_amazon(baseline):
    _run_suite("m-amazon", baseline)


@pytest.mark.perf
@pytest.mark.snap
@pytest.mark.perf_large
def test_l_livejournal(baseline):
    _run_suite("l-livejournal", baseline)


@pytest.mark.perf
@pytest.mark.snap
@pytest.mark.perf_large
def test_xl_cit_patents(baseline):
    _run_suite("xl-cit-patents", baseline)


@pytest.mark.perf
@pytest.mark.snap
@pytest.mark.perf_large
def test_xxl_orkut(baseline):
    _run_suite("xxl-orkut", baseline)


# ---------------------------------------------------------------------------
# Slow-query baselines
# ---------------------------------------------------------------------------
# Two-hop full-expansion is fast enough on XS (karate, 34n/78e) — ~0.006 s —
# so it runs unconditionally.  On S/M-tiers (~9 s on M) it is guarded by the
# perf_slow marker and excluded from the default CI run.


@pytest.mark.perf
@pytest.mark.snap
@pytest.mark.perf_slow
def test_slow_queries_xs_karate(baseline):
    """Two-hop full-expansion on karate (XS) — runs via make test-perf-slow."""
    gf = GraphForge()
    load_dataset(gf, "netrepo-karate")
    for label, query in SLOW_QUERIES:
        with timed(label) as t:
            rows = gf.execute(query)
        assert rows, f"slow/{label}: expected at least one result row"
        record(baseline, "xs-karate-slow", f"{label}_cold_s", t["elapsed"])


@pytest.mark.perf
@pytest.mark.snap
@pytest.mark.perf_slow
def test_slow_queries_s_facebook(baseline):
    """Two-hop full-expansion on facebook (S) — several seconds, opt-in only."""
    gf = GraphForge()
    load_dataset(gf, "snap-ego-facebook")
    for label, query in SLOW_QUERIES:
        with timed(label) as t:
            rows = gf.execute(query)
        assert rows, f"slow/{label}: expected at least one result row"
        record(baseline, "s-facebook-slow", f"{label}_cold_s", t["elapsed"])
