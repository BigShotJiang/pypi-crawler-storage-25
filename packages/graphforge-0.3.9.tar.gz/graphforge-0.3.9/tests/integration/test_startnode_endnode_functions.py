"""Integration tests for startNode() and endNode() graph functions."""

import pytest

from graphforge import GraphForge


@pytest.fixture
def graph():
    gf = GraphForge()
    gf.execute("CREATE (:Person {name: 'Alice'})-[:KNOWS]->(:Person {name: 'Bob'})")
    return gf


class TestStartNode:
    def test_startnode_returns_source_node(self, graph):
        results = graph.execute("MATCH (a)-[r:KNOWS]->(b) RETURN startNode(r) AS s")
        assert len(results) == 1
        node = results[0]["s"]
        assert node.properties["name"].value == "Alice"

    def test_startnode_property_access(self, graph):
        results = graph.execute("MATCH (a)-[r:KNOWS]->(b) RETURN startNode(r).name AS name")
        assert results[0]["name"].value == "Alice"

    def test_startnode_null_returns_null(self, graph):
        results = graph.execute("RETURN startNode(null) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(results[0]["result"], CypherNull)


class TestEndNode:
    def test_endnode_returns_target_node(self, graph):
        results = graph.execute("MATCH (a)-[r:KNOWS]->(b) RETURN endNode(r) AS e")
        assert len(results) == 1
        node = results[0]["e"]
        assert node.properties["name"].value == "Bob"

    def test_endnode_property_access(self, graph):
        results = graph.execute("MATCH (a)-[r:KNOWS]->(b) RETURN endNode(r).name AS name")
        assert results[0]["name"].value == "Bob"

    def test_endnode_null_returns_null(self, graph):
        results = graph.execute("RETURN endNode(null) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(results[0]["result"], CypherNull)


class TestStartEndNodeComposed:
    def test_startnode_and_endnode_together(self, graph):
        results = graph.execute(
            "MATCH (a)-[r:KNOWS]->(b) RETURN startNode(r).name AS src, endNode(r).name AS dst"
        )
        assert results[0]["src"].value == "Alice"
        assert results[0]["dst"].value == "Bob"
