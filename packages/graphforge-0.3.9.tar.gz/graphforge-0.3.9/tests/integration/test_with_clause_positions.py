"""Integration tests for WITH clause position support (Issue #257).

Verify that multi-clause queries with WITH after SET, REMOVE, DELETE, and in
chained multi-part queries produce correct results end-to-end.
"""

from graphforge import GraphForge


class TestWithClausePositionExecution:
    """Execution-level tests — verify multi-WITH patterns produce correct results."""

    def test_match_set_with_return(self):
        """MATCH ... SET ... WITH ... RETURN propagates updated property."""
        gf = GraphForge()
        gf.execute("CREATE (:T {x: 0})")
        result = gf.execute("MATCH (n:T) SET n.x = 99 WITH n RETURN n.x AS val")
        assert len(result) == 1
        assert result[0]["val"].value == 99

    def test_match_with_set_with_return(self):
        """MATCH ... WITH ... SET ... WITH ... RETURN: two WITH segments."""
        gf = GraphForge()
        gf.execute("CREATE (:T {x: 0, y: 0})")
        result = gf.execute(
            "MATCH (n:T) WITH n SET n.x = 1 WITH n SET n.y = 2 WITH n RETURN n.x AS x, n.y AS y"
        )
        assert len(result) == 1
        assert result[0]["x"].value == 1
        assert result[0]["y"].value == 2

    def test_match_with_match_with_return(self):
        """MATCH ... WITH ... MATCH ... WITH ... RETURN: chained multi-part."""
        gf = GraphForge()
        gf.execute("CREATE (:A {v: 1})")
        gf.execute("CREATE (:B {v: 2})")
        result = gf.execute("MATCH (a:A) WITH a MATCH (b:B) WITH a, b RETURN a.v AS av, b.v AS bv")
        assert len(result) == 1
        assert result[0]["av"].value == 1
        assert result[0]["bv"].value == 2

    def test_three_segment_chain(self):
        """Three-segment multi-part query works correctly."""
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:R]->(:B)-[:R]->(:C)")
        result = gf.execute(
            "MATCH (a:A) WITH a "
            "MATCH (a)-[:R]->(b:B) WITH a, b "
            "MATCH (b)-[:R]->(c:C) WITH a, b, c "
            "RETURN a, b, c"
        )
        assert len(result) == 1

    def test_create_with_set_with_return(self):
        """CREATE ... WITH ... SET ... WITH ... RETURN creates and updates node."""
        gf = GraphForge()
        result = gf.execute("CREATE (n:T {x: 0}) WITH n SET n.x = 42 WITH n RETURN n.x AS val")
        assert len(result) == 1
        assert result[0]["val"].value == 42

    def test_set_with_produces_correct_row_count(self):
        """SET ... WITH produces one row per matched node."""
        gf = GraphForge()
        gf.execute("CREATE (:T {v: 1})")
        gf.execute("CREATE (:T {v: 2})")
        gf.execute("CREATE (:T {v: 3})")
        result = gf.execute("MATCH (n:T) SET n.updated = true WITH n RETURN n.v AS v ORDER BY v")
        assert len(result) == 3
        assert [r["v"].value for r in result] == [1, 2, 3]

    def test_match_remove_with_return(self):
        """MATCH ... REMOVE ... WITH ... RETURN: label removed, node still returned."""
        gf = GraphForge()
        gf.execute("CREATE (:A:B {x: 1})")
        result = gf.execute("MATCH (n:A:B) REMOVE n:B WITH n RETURN n.x AS x")
        assert len(result) == 1
        assert result[0]["x"].value == 1
        # Verify label was removed
        check = gf.execute("MATCH (n:B) RETURN n")
        assert len(check) == 0

    def test_existing_with_at_start_still_works(self):
        """Regression: WITH at query start (issue #172) still works."""
        gf = GraphForge()
        result = gf.execute("WITH 1 AS x, 2 AS y RETURN x + y AS sum")
        assert len(result) == 1
        assert result[0]["sum"].value == 3

    def test_existing_match_with_return_still_works(self):
        """Regression: simple MATCH ... WITH ... RETURN still works."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {name: 'Alice'})")
        result = gf.execute("MATCH (n:Person) WITH n RETURN n.name AS name")
        assert len(result) == 1
        assert result[0]["name"].value == "Alice"

    def test_with_where_filters_in_segment(self):
        """WITH clause with WHERE correctly filters rows in multi-segment query."""
        gf = GraphForge()
        gf.execute("CREATE (:T {v: 1})")
        gf.execute("CREATE (:T {v: 5})")
        gf.execute("CREATE (:T {v: 10})")
        result = gf.execute(
            "MATCH (n:T) WITH n WHERE n.v > 3 MATCH (m:T) WHERE m.v = n.v RETURN m.v AS val"
        )
        # Only nodes with v > 3 pass the WITH WHERE filter
        vals = sorted(r["val"].value for r in result)
        assert vals == [5, 10]
