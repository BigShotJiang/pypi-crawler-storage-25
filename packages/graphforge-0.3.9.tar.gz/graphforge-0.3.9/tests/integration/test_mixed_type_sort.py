"""Integration tests for ORDER BY mixed-type sort ordering (openCypher type hierarchy).

Per the openCypher spec, ASC order is:
  Map < Node < Relationship < List < Path < String < Boolean < Integer/Float < NaN < NULL
NULL sorts last in ASC, first in DESC.
"""

import pytest

from graphforge import GraphForge
from graphforge.types.values import CypherBool, CypherInt, CypherNull, CypherString


@pytest.fixture
def gf():
    return GraphForge()


class TestNullSorting:
    def test_nulls_last_asc(self, gf):
        results = gf.execute("UNWIND [3, null, 1, null, 2] AS x RETURN x ORDER BY x ASC")
        values = [r["x"] for r in results]
        non_null = [v.value for v in values if not isinstance(v, CypherNull)]
        nulls = [v for v in values if isinstance(v, CypherNull)]
        assert non_null == [1, 2, 3]
        assert len(nulls) == 2
        # Nulls must appear after all non-null values in ASC
        first_null_pos = next(i for i, v in enumerate(values) if isinstance(v, CypherNull))
        assert first_null_pos == 3

    def test_nulls_first_desc(self, gf):
        results = gf.execute("UNWIND [3, null, 1] AS x RETURN x ORDER BY x DESC")
        values = [r["x"] for r in results]
        assert isinstance(values[0], CypherNull)
        assert values[1].value == 3
        assert values[2].value == 1


class TestIntegerFloatSorting:
    def test_integers_sort_ascending(self, gf):
        results = gf.execute("UNWIND [3, 1, 2] AS x RETURN x ORDER BY x ASC")
        assert [r["x"].value for r in results] == [1, 2, 3]

    def test_integers_sort_descending(self, gf):
        results = gf.execute("UNWIND [3, 1, 2] AS x RETURN x ORDER BY x DESC")
        assert [r["x"].value for r in results] == [3, 2, 1]

    def test_floats_sort_ascending(self, gf):
        results = gf.execute("UNWIND [3.0, 1.5, 2.0] AS x RETURN x ORDER BY x ASC")
        assert [r["x"].value for r in results] == [1.5, 2.0, 3.0]


class TestStringsSorting:
    def test_strings_sort_ascending(self, gf):
        results = gf.execute("UNWIND ['banana', 'apple', 'cherry'] AS x RETURN x ORDER BY x ASC")
        assert [r["x"].value for r in results] == ["apple", "banana", "cherry"]


class TestMixedTypeSortHierarchy:
    def test_booleans_after_strings_before_numbers(self, gf):
        """In ASC order: strings < booleans < numbers (openCypher spec)."""
        results = gf.execute("UNWIND [42, true, 'hello'] AS x RETURN x ORDER BY x ASC")
        values = results
        # String (rank 6) < Boolean (rank 7) < Number (rank 8)
        assert isinstance(values[0]["x"], CypherString)
        assert isinstance(values[1]["x"], CypherBool)
        assert isinstance(values[2]["x"], CypherInt)

    def test_strings_before_numbers(self, gf):
        """In ASC order: strings < numbers (openCypher spec: String rank 6, Number rank 8)."""
        results = gf.execute("UNWIND [42, 'hello', 1] AS x RETURN x ORDER BY x ASC")
        values = results
        # String (rank 6) comes before Numbers (rank 8)
        assert isinstance(values[0]["x"], CypherString)
        assert isinstance(values[1]["x"], CypherInt)
        assert isinstance(values[2]["x"], CypherInt)

    def test_nulls_last_in_mixed_asc(self, gf):
        """Nulls sort after all other types in ASC."""
        results = gf.execute("UNWIND [null, 42, 'hello'] AS x RETURN x ORDER BY x ASC")
        values = results
        # String (rank 6) < Number (rank 8) < NULL (rank 9)
        assert isinstance(values[0]["x"], CypherString)
        assert isinstance(values[1]["x"], CypherInt)
        assert isinstance(values[2]["x"], CypherNull)

    def test_nulls_first_in_mixed_desc(self, gf):
        """Nulls sort before all other types in DESC."""
        results = gf.execute("UNWIND [null, 42, 'hello'] AS x RETURN x ORDER BY x DESC")
        values = results
        assert isinstance(values[0]["x"], CypherNull)

    def test_lists_before_strings(self, gf):
        """Lists sort before strings in ASC order (openCypher spec: List < String)."""
        results = gf.execute("UNWIND ['hello', [1, 2], 'world'] AS x RETURN x ORDER BY x ASC")
        values = results
        from graphforge.types.values import CypherList

        assert isinstance(values[0]["x"], CypherList)
        assert isinstance(values[1]["x"], CypherString)
        assert isinstance(values[2]["x"], CypherString)

    def test_node_sort_consistency(self, gf):
        """Multiple nodes sort in a stable, consistent order."""
        gf.execute("CREATE (:A {v: 1}), (:B {v: 2}), (:C {v: 3})")
        results = gf.execute("MATCH (n) RETURN n ORDER BY n.v ASC")
        assert len(results) == 3
        assert results[0]["n"].properties["v"].value == 1
        assert results[1]["n"].properties["v"].value == 2
        assert results[2]["n"].properties["v"].value == 3
