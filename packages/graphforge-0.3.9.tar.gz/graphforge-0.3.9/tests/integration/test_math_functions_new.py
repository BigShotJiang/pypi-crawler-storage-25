"""Integration tests for new math functions: e, pi, exp, log, log10,
sin, cos, tan, cot, asin, acos, atan, atan2, degrees, radians, timestamp."""

import math
import time

import pytest

from graphforge.api import GraphForge
from graphforge.types.values import CypherFloat, CypherInt, CypherNull


@pytest.fixture
def gf():
    return GraphForge()


class TestConstants:
    def test_e(self, gf):
        result = gf.execute("RETURN e() AS r")
        assert abs(result[0]["r"].value - math.e) < 1e-10

    def test_pi(self, gf):
        result = gf.execute("RETURN pi() AS r")
        assert abs(result[0]["r"].value - math.pi) < 1e-10

    def test_e_returns_float(self, gf):
        result = gf.execute("RETURN e() AS r")
        assert isinstance(result[0]["r"], CypherFloat)

    def test_pi_returns_float(self, gf):
        result = gf.execute("RETURN pi() AS r")
        assert isinstance(result[0]["r"], CypherFloat)


class TestExpLogFunctions:
    def test_exp_zero(self, gf):
        result = gf.execute("RETURN exp(0) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_exp_one(self, gf):
        result = gf.execute("RETURN exp(1) AS r")
        assert abs(result[0]["r"].value - math.e) < 1e-10

    def test_exp_float(self, gf):
        result = gf.execute("RETURN exp(2.0) AS r")
        assert abs(result[0]["r"].value - math.exp(2.0)) < 1e-10

    def test_exp_overflow_returns_null(self, gf):
        result = gf.execute("RETURN exp(1000) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_exp_null(self, gf):
        result = gf.execute("RETURN exp(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_log_one(self, gf):
        result = gf.execute("RETURN log(1) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_log_e(self, gf):
        result = gf.execute("RETURN log(e()) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_log_zero_returns_null(self, gf):
        result = gf.execute("RETURN log(0) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_log_negative_returns_null(self, gf):
        result = gf.execute("RETURN log(-1) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_log_null(self, gf):
        result = gf.execute("RETURN log(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_log10_one(self, gf):
        result = gf.execute("RETURN log10(1) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_log10_ten(self, gf):
        result = gf.execute("RETURN log10(10) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_log10_hundred(self, gf):
        result = gf.execute("RETURN log10(100) AS r")
        assert abs(result[0]["r"].value - 2.0) < 1e-10

    def test_log10_zero_returns_null(self, gf):
        result = gf.execute("RETURN log10(0) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_log10_null(self, gf):
        result = gf.execute("RETURN log10(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)


class TestTrigFunctions:
    def test_sin_zero(self, gf):
        result = gf.execute("RETURN sin(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_sin_pi_over_2(self, gf):
        result = gf.execute("RETURN sin(pi() / 2) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_sin_null(self, gf):
        result = gf.execute("RETURN sin(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_cos_zero(self, gf):
        result = gf.execute("RETURN cos(0) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_cos_pi(self, gf):
        result = gf.execute("RETURN cos(pi()) AS r")
        assert abs(result[0]["r"].value - (-1.0)) < 1e-10

    def test_cos_null(self, gf):
        result = gf.execute("RETURN cos(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_tan_zero(self, gf):
        result = gf.execute("RETURN tan(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_tan_pi_over_4(self, gf):
        result = gf.execute("RETURN tan(pi() / 4) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_tan_null(self, gf):
        result = gf.execute("RETURN tan(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_cot_pi_over_4(self, gf):
        result = gf.execute("RETURN cot(pi() / 4) AS r")
        assert abs(result[0]["r"].value - 1.0) < 1e-10

    def test_cot_zero_returns_null(self, gf):
        result = gf.execute("RETURN cot(0) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_cot_null(self, gf):
        result = gf.execute("RETURN cot(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_asin_zero(self, gf):
        result = gf.execute("RETURN asin(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_asin_one(self, gf):
        result = gf.execute("RETURN asin(1) AS r")
        assert abs(result[0]["r"].value - math.pi / 2) < 1e-10

    def test_asin_out_of_range_returns_null(self, gf):
        result = gf.execute("RETURN asin(2) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_asin_null(self, gf):
        result = gf.execute("RETURN asin(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_acos_one(self, gf):
        result = gf.execute("RETURN acos(1) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_acos_zero(self, gf):
        result = gf.execute("RETURN acos(0) AS r")
        assert abs(result[0]["r"].value - math.pi / 2) < 1e-10

    def test_acos_out_of_range_returns_null(self, gf):
        result = gf.execute("RETURN acos(2) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_acos_null(self, gf):
        result = gf.execute("RETURN acos(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_atan_zero(self, gf):
        result = gf.execute("RETURN atan(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_atan_one(self, gf):
        result = gf.execute("RETURN atan(1) AS r")
        assert abs(result[0]["r"].value - math.pi / 4) < 1e-10

    def test_atan_null(self, gf):
        result = gf.execute("RETURN atan(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_atan2_one_zero(self, gf):
        result = gf.execute("RETURN atan2(1, 0) AS r")
        assert abs(result[0]["r"].value - math.pi / 2) < 1e-10

    def test_atan2_zero_one(self, gf):
        result = gf.execute("RETURN atan2(0, 1) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_atan2_null_propagation(self, gf):
        result = gf.execute("RETURN atan2(null, 1) AS r")
        assert isinstance(result[0]["r"], CypherNull)


class TestConversionFunctions:
    def test_degrees_zero(self, gf):
        result = gf.execute("RETURN degrees(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_degrees_pi(self, gf):
        result = gf.execute("RETURN degrees(pi()) AS r")
        assert abs(result[0]["r"].value - 180.0) < 1e-10

    def test_degrees_null(self, gf):
        result = gf.execute("RETURN degrees(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_radians_zero(self, gf):
        result = gf.execute("RETURN radians(0) AS r")
        assert abs(result[0]["r"].value - 0.0) < 1e-10

    def test_radians_180(self, gf):
        result = gf.execute("RETURN radians(180) AS r")
        assert abs(result[0]["r"].value - math.pi) < 1e-10

    def test_radians_null(self, gf):
        result = gf.execute("RETURN radians(null) AS r")
        assert isinstance(result[0]["r"], CypherNull)

    def test_degrees_radians_roundtrip(self, gf):
        result = gf.execute("RETURN degrees(radians(45)) AS r")
        assert abs(result[0]["r"].value - 45.0) < 1e-10


class TestTimestamp:
    def test_timestamp_returns_int(self, gf):
        result = gf.execute("RETURN timestamp() AS r")
        assert isinstance(result[0]["r"], CypherInt)

    def test_timestamp_reasonable_value(self, gf):
        before = int(time.time() * 1000)
        result = gf.execute("RETURN timestamp() AS r")
        after = int(time.time() * 1000)
        ts = result[0]["r"].value
        assert before <= ts <= after

    def test_timestamp_positive(self, gf):
        result = gf.execute("RETURN timestamp() AS r")
        assert result[0]["r"].value > 0
