"""Integration tests for properties() and keys() graph functions.

Covers issue #240 — properties() on nodes/relationships/maps and keys() on
nodes, relationships, and maps.
"""

import pytest

from graphforge.api import GraphForge
from graphforge.types.values import CypherNull


@pytest.fixture
def gf():
    return GraphForge()


class TestPropertiesFunction:
    """properties(node|relationship|map) returns a CypherMap of all properties."""

    @pytest.mark.parametrize(
        "create_query,match_query",
        [
            (
                "CREATE (:P {name: 'Alice', age: 30})",
                "MATCH (n:P) RETURN properties(n) AS p",
            ),
            (
                "CREATE ()-[:KNOWS {since: 2020, weight: 1}]->()",
                "MATCH ()-[r:KNOWS]->() RETURN properties(r) AS p",
            ),
        ],
    )
    def test_properties_with_properties(self, gf, create_query, match_query):
        gf.execute(create_query)
        results = gf.execute(match_query)
        props = results[0]["p"].value
        assert len(props) > 0
        assert all(hasattr(v, "value") for v in props.values())

    @pytest.mark.parametrize(
        "create_query,match_query",
        [
            ("CREATE (:Empty)", "MATCH (n:Empty) RETURN properties(n) AS p"),
            ("CREATE ()-[:BARE]->()", "MATCH ()-[r:BARE]->() RETURN properties(r) AS p"),
        ],
    )
    def test_properties_no_properties(self, gf, create_query, match_query):
        gf.execute(create_query)
        results = gf.execute(match_query)
        assert results[0]["p"].value == {}

    def test_properties_of_node_values(self, gf):
        gf.execute("CREATE (:Q {name: 'Alice', age: 30})")
        results = gf.execute("MATCH (n:Q) RETURN properties(n) AS p")
        props = results[0]["p"].value
        assert props["name"].value == "Alice"
        assert props["age"].value == 30

    def test_properties_of_relationship_values(self, gf):
        gf.execute("CREATE ()-[:KNOWS {since: 2020, weight: 1}]->()")
        results = gf.execute("MATCH ()-[r:KNOWS]->() RETURN properties(r) AS p")
        props = results[0]["p"].value
        assert props["since"].value == 2020
        assert props["weight"].value == 1

    def test_properties_of_map(self, gf):
        results = gf.execute("RETURN properties({a: 1, b: 'x'}) AS p")
        props = results[0]["p"].value
        assert props["a"].value == 1
        assert props["b"].value == "x"

    def test_properties_null_returns_null(self, gf):
        results = gf.execute("RETURN properties(null) AS p")
        assert isinstance(results[0]["p"], CypherNull)

    def test_properties_result_is_usable_as_map(self, gf):
        gf.execute("CREATE (:R {x: 42})")
        results = gf.execute("MATCH (n:R) RETURN properties(n)['x'] AS v")
        assert results[0]["v"].value == 42


class TestKeysFunction:
    """keys(node|relationship|map) returns a sorted CypherList of key strings."""

    @pytest.mark.parametrize(
        "create_query,match_query,expected_keys",
        [
            (
                "CREATE (:K {b: 2, a: 1, c: 3})",
                "MATCH (n:K) RETURN keys(n) AS k",
                {"a", "b", "c"},
            ),
            (
                "CREATE ()-[:REL {z: 1, a: 2}]->()",
                "MATCH ()-[r:REL]->() RETURN keys(r) AS k",
                {"a", "z"},
            ),
        ],
    )
    def test_keys_sorted(self, gf, create_query, match_query, expected_keys):
        gf.execute(create_query)
        results = gf.execute(match_query)
        key_vals = [v.value for v in results[0]["k"].value]
        assert key_vals == sorted(key_vals)
        assert set(key_vals) == expected_keys

    @pytest.mark.parametrize(
        "create_query,match_query",
        [
            ("CREATE (:Bare)", "MATCH (n:Bare) RETURN keys(n) AS k"),
            ("CREATE ()-[:EMPTY]->()", "MATCH ()-[r:EMPTY]->() RETURN keys(r) AS k"),
        ],
    )
    def test_keys_no_properties(self, gf, create_query, match_query):
        gf.execute(create_query)
        results = gf.execute(match_query)
        assert results[0]["k"].value == []

    def test_keys_of_map(self, gf):
        results = gf.execute("RETURN keys({c: 3, a: 1, b: 2}) AS k")
        key_vals = [v.value for v in results[0]["k"].value]
        assert key_vals == ["a", "b", "c"]

    def test_keys_of_empty_map(self, gf):
        results = gf.execute("RETURN keys({}) AS k")
        assert results[0]["k"].value == []

    def test_keys_null_returns_null(self, gf):
        results = gf.execute("RETURN keys(null) AS k")
        assert isinstance(results[0]["k"], CypherNull)

    def test_keys_result_usable_in_size(self, gf):
        gf.execute("CREATE (:M {x: 1, y: 2, z: 3})")
        results = gf.execute("MATCH (n:M) RETURN size(keys(n)) AS s")
        assert results[0]["s"].value == 3
