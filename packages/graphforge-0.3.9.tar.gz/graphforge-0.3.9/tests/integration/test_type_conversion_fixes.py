"""Integration tests for type conversion fixes (#293) and split() edge cases (#307).

Covers:
- toFloat/toInteger/toBoolean raising TypeError for invalid types
- toInteger correctly parsing decimal strings (e.g., '2.9' → 2)
- split() with empty delimiter and edge cases
"""

import pytest

from graphforge.api import GraphForge
from graphforge.types.values import CypherFloat, CypherInt, CypherNull


@pytest.fixture
def gf():
    return GraphForge()


class TestToFloat:
    @pytest.mark.parametrize(
        "query,expected",
        [
            ("RETURN toFloat(1) AS r", 1.0),
            ("RETURN toFloat(1.5) AS r", 1.5),
            ("RETURN toFloat('3.14') AS r", 3.14),
        ],
        ids=["integer", "float", "string"],
    )
    def test_valid_inputs(self, gf, query, expected):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherFloat)
        assert abs(result[0]["r"].value - expected) < 1e-10

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toFloat('abc') AS r",
            "RETURN toFloat(null) AS r",
        ],
        ids=["invalid_string", "null"],
    )
    def test_null_return(self, gf, query):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherNull)

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toFloat(true) AS r",
            "RETURN toFloat([]) AS r",
            "RETURN toFloat({}) AS r",
        ],
        ids=["boolean", "list", "map"],
    )
    def test_type_error(self, gf, query):
        with pytest.raises(TypeError):
            gf.execute(query)


class TestToInteger:
    @pytest.mark.parametrize(
        "query,expected",
        [
            ("RETURN toInteger(2) AS r", 2),
            ("RETURN toInteger(2.9) AS r", 2),
            ("RETURN toInteger('2') AS r", 2),
            ("RETURN toInteger('2.9') AS r", 2),
            ("RETURN toInteger('1.7') AS r", 1),
        ],
        ids=["integer", "float_truncate", "string_int", "string_decimal", "string_decimal_down"],
    )
    def test_valid_inputs(self, gf, query, expected):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherInt)
        assert result[0]["r"].value == expected

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toInteger('foo') AS r",
            "RETURN toInteger(null) AS r",
            "RETURN toInteger(true) AS r",
        ],
        ids=["invalid_string", "null", "boolean"],
    )
    def test_null_return(self, gf, query):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherNull)

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toInteger([]) AS r",
            "RETURN toInteger({}) AS r",
        ],
        ids=["list", "map"],
    )
    def test_type_error(self, gf, query):
        with pytest.raises(TypeError):
            gf.execute(query)

    def test_list_comprehension_mixed(self, gf):
        result = gf.execute(
            "WITH [2, 2.9, '1.7'] AS things RETURN [n IN things | toInteger(n)] AS r"
        )
        vals = [v.value for v in result[0]["r"].value]
        assert vals == [2, 2, 1]

    def test_list_comprehension_with_unparseable(self, gf):
        result = gf.execute(
            "WITH ['2', '2.9', 'foo'] AS numbers RETURN [n IN numbers | toInteger(n)] AS r"
        )
        items = result[0]["r"].value
        assert items[0].value == 2
        assert items[1].value == 2
        assert isinstance(items[2], CypherNull)


class TestToBoolean:
    @pytest.mark.parametrize(
        "query,expected",
        [
            ("RETURN toBoolean('true') AS r", True),
            ("RETURN toBoolean('false') AS r", False),
            ("RETURN toBoolean(true) AS r", True),
        ],
        ids=["string_true", "string_false", "bool_identity"],
    )
    def test_valid_inputs(self, gf, query, expected):
        result = gf.execute(query)
        assert result[0]["r"].value is expected

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toBoolean('yes') AS r",
            "RETURN toBoolean(null) AS r",
        ],
        ids=["invalid_string", "null"],
    )
    def test_null_return(self, gf, query):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherNull)

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN toBoolean(1.0) AS r",
            "RETURN toBoolean([]) AS r",
            "RETURN toBoolean({}) AS r",
        ],
        ids=["float", "list", "map"],
    )
    def test_type_error(self, gf, query):
        with pytest.raises(TypeError):
            gf.execute(query)


class TestSplitEdgeCases:
    @pytest.mark.parametrize(
        "query,expected_parts",
        [
            ("RETURN split('a,b,c', ',') AS r", ["a", "b", "c"]),
            ("RETURN split(',a,', ',') AS r", ["", "a", ""]),
            ("RETURN split('abc', '') AS r", ["a", "b", "c"]),
        ],
        ids=["basic", "boundary_delimiters", "empty_delimiter"],
    )
    def test_valid_splits(self, gf, query, expected_parts):
        result = gf.execute(query)
        parts = [v.value for v in result[0]["r"].value]
        assert parts == expected_parts

    @pytest.mark.parametrize(
        "query",
        [
            "RETURN split(null, ',') AS r",
            "RETURN split('a', null) AS r",
        ],
        ids=["null_string", "null_delimiter"],
    )
    def test_null_inputs_return_null(self, gf, query):
        result = gf.execute(query)
        assert isinstance(result[0]["r"], CypherNull)
