"""Integration tests for variable-length pattern fixes (#381, #382).

#381: relationship predicates in [r* WHERE ...] evaluated during BFS
#382: cross-hop edge uniqueness in multi-segment variable-length patterns
"""

import pytest

from graphforge import GraphForge


@pytest.fixture()
def chain_graph():
    """A->B->C->D with weights on edges."""
    gf = GraphForge()
    gf.execute("""
        CREATE (a:Node {name: 'A'}),
               (b:Node {name: 'B'}),
               (c:Node {name: 'C'}),
               (d:Node {name: 'D'}),
               (a)-[:LINK {weight: 1}]->(b),
               (b)-[:LINK {weight: 0}]->(c),
               (c)-[:LINK {weight: 1}]->(d)
    """)
    return gf


@pytest.fixture()
def triangle_graph():
    """A->B->C->A (triangle), useful for edge-uniqueness tests."""
    gf = GraphForge()
    gf.execute("""
        CREATE (a:Node {name: 'A'}),
               (b:Node {name: 'B'}),
               (c:Node {name: 'C'}),
               (a)-[:LINK]->(b),
               (b)-[:LINK]->(c),
               (c)-[:LINK]->(a)
    """)
    return gf


# ── #381: relationship predicate in pattern predicates ────────────────────────


class TestVarLenRelPredicate:
    def test_pattern_predicate_with_rel_where_filters_path(self, chain_graph):
        """WHERE (a)-[r:LINK* WHERE r.weight > 0]->(d) is False when any hop weight=0."""
        results = chain_graph.execute("""
            MATCH (a:Node {name: 'A'}), (d:Node {name: 'D'})
            WHERE (a)-[:LINK* WHERE r.weight > 0]->(d)
            RETURN a.name AS name
        """)
        # A→B (w=1) → C (w=0) → D — the zero-weight hop blocks the path
        assert len(results) == 0

    def test_pattern_predicate_passes_when_all_hops_satisfy_predicate(self, chain_graph):
        """WHERE (a)-[r:LINK* WHERE r.weight > 0]->(b) is True for the direct hop."""
        results = chain_graph.execute("""
            MATCH (a:Node {name: 'A'}), (b:Node {name: 'B'})
            WHERE (a)-[:LINK* WHERE r.weight > 0]->(b)
            RETURN a.name AS name
        """)
        assert len(results) == 1
        assert results[0]["name"].value == "A"

    def test_no_predicate_follows_all_edges(self, chain_graph):
        """Without predicate, all reachable nodes returned regardless of weight."""
        results = chain_graph.execute("""
            MATCH (a:Node {name: 'A'})-[*]->(x:Node)
            RETURN x.name AS name
            ORDER BY name
        """)
        names = [r["name"].value for r in results]
        assert names == ["B", "C", "D"]

    def test_rel_predicate_with_named_var(self, chain_graph):
        """[r:LINK* WHERE r.weight = 1] via execute-level var-length expansion."""
        results = chain_graph.execute("""
            MATCH (a:Node {name: 'A'})-[r:LINK*1..1 WHERE r.weight = 1]->(b:Node)
            RETURN b.name AS name
        """)
        # Only A->B has weight=1 among direct hops
        names = [r["name"].value for r in results]
        assert "B" in names
        assert "C" not in names  # A->B->C goes through zero-weight edge


# ── #382: cross-hop edge uniqueness ───────────────────────────────────────────


class TestCrossHopEdgeUniqueness:
    def test_same_edge_cannot_appear_in_two_varlen_hops(self, triangle_graph):
        """MATCH (a)-[*]->(b)-[*]->(c) must not reuse an edge across the two [*] hops."""
        # In a triangle A->B->C->A, a valid path is A->B (hop1) then B->C->A (hop2).
        # An invalid path would be A->B (hop1, uses A->B edge) then reuse A->B edge in hop2.
        results = triangle_graph.execute("""
            MATCH (a:Node {name: 'A'})-[r1*1..1]->(b:Node)-[r2*1..1]->(c:Node)
            RETURN a.name AS a, b.name AS b, c.name AS c
            ORDER BY b, c
        """)
        # Valid paths: A->B->C, A->B->C->A would need B->C then C->A
        for row in results:
            a_name = row["a"].value
            b_name = row["b"].value
            c_name = row["c"].value
            # The intermediate node b must differ from both a and c in meaningful ways
            # Key invariant: the path a->b and b->c must use distinct edges
            assert a_name != c_name or b_name != a_name, (
                f"Suspicious path {a_name}->{b_name}->{c_name} may reuse an edge"
            )

    def test_linear_two_segment_varlen_correct(self, chain_graph):
        """MATCH (a)-[*1..1]->(b)-[*1..1]->(c) on a chain returns correct paths."""
        results = chain_graph.execute("""
            MATCH (a:Node)-[*1..1]->(b:Node)-[*1..1]->(c:Node)
            RETURN a.name AS a, b.name AS b, c.name AS c
            ORDER BY a, b, c
        """)
        path_triples = [(r["a"].value, r["b"].value, r["c"].value) for r in results]
        # Chain: A->B->C->D — valid 2-hop paths: (A,B,C), (B,C,D)
        assert ("A", "B", "C") in path_triples
        assert ("B", "C", "D") in path_triples
        # (A,B,B) would require reusing the A->B edge — must not appear
        for a, b, c in path_triples:
            assert a != b, "Start and intermediate must differ"
            assert b != c or a != c, "Path must use distinct edges"

    def test_no_self_loop_via_edge_reuse(self):
        """An edge cannot be traversed twice in the same path."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {name:'A'})-[:LINK]->(b:Node {name:'B'})")
        # [*1..2] from A: valid paths are A->B (1 hop) only
        # A->B->A would require the same edge twice if no return edge exists
        results = gf.execute("""
            MATCH (a:Node {name: 'A'})-[*1..2]->(x:Node)
            RETURN x.name AS name
        """)
        names = [r["name"].value for r in results]
        # B reachable at depth 1; no way back to A without reusing the edge
        assert "B" in names
        assert names.count("A") == 0  # A should not appear via edge reuse
