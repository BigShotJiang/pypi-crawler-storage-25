"""Integration tests for graph element (node/relationship) comparison.

Covers identity-based equality (WHERE a = b) and ORDER BY for nodes and
relationships, exercising the equals() and less_than() methods added to
NodeRef and EdgeRef in fix #263.
"""

import pytest

from graphforge.api import GraphForge


@pytest.fixture
def gf():
    return GraphForge()


class TestNodeEquality:
    """Integration tests for node identity comparison (WHERE a = b)."""

    def test_same_node_equals_itself(self, gf):
        gf.execute("CREATE ()")
        results = gf.execute("MATCH (a) WITH a MATCH (b) WHERE a = b RETURN count(b) AS cnt")
        assert results[0]["cnt"].value == 1

    def test_different_nodes_are_not_equal(self, gf):
        gf.execute("CREATE (), ()")
        results = gf.execute("MATCH (a), (b) WHERE a = b RETURN count(*) AS cnt")
        # Only the 2 self-pairings should match
        assert results[0]["cnt"].value == 2

    def test_node_not_equal_to_different_node(self, gf):
        gf.execute("CREATE (:A), (:B)")
        results = gf.execute("MATCH (a:A), (b:B) WHERE a = b RETURN count(*) AS cnt")
        assert results[0]["cnt"].value == 0

    def test_node_inequality_operator(self, gf):
        gf.execute("CREATE (:A), (:B)")
        results = gf.execute("MATCH (a:A), (b:B) WHERE a <> b RETURN count(*) AS cnt")
        assert results[0]["cnt"].value == 1


class TestRelationshipEquality:
    """Integration tests for relationship identity comparison (WHERE a = b)."""

    def test_same_relationship_equals_itself(self, gf):
        gf.execute("CREATE ()-[:T]->()")
        results = gf.execute(
            "MATCH ()-[a]->() WITH a MATCH ()-[b]->() WHERE a = b RETURN count(b) AS cnt"
        )
        assert results[0]["cnt"].value == 1

    def test_different_relationships_are_not_equal(self, gf):
        gf.execute("CREATE ()-[:T]->(), ()-[:T]->()")
        results = gf.execute("MATCH ()-[a]->(), ()-[b]->() WHERE a = b RETURN count(*) AS cnt")
        # Only 2 self-pairings match
        assert results[0]["cnt"].value == 2

    def test_relationship_not_equal_to_different_relationship(self, gf):
        gf.execute("CREATE ()-[:A]->(), ()-[:B]->()")
        results = gf.execute("MATCH ()-[a:A]->(), ()-[b:B]->() WHERE a = b RETURN count(*) AS cnt")
        assert results[0]["cnt"].value == 0

    def test_relationship_inequality_operator(self, gf):
        gf.execute("CREATE ()-[:A]->(), ()-[:B]->()")
        results = gf.execute("MATCH ()-[a:A]->(), ()-[b:B]->() WHERE a <> b RETURN count(*) AS cnt")
        assert results[0]["cnt"].value == 1


class TestNodeOrderBy:
    """Integration tests for ORDER BY with node variables."""

    def test_order_by_node_variable_ascending(self, gf):
        """ORDER BY a node variable sorts by internal ID ascending."""
        gf.execute("CREATE (:P), (:P), (:P)")
        results = gf.execute("MATCH (n:P) RETURN id(n) AS nid ORDER BY n ASC")
        ids = [r["nid"].value for r in results]
        assert ids == sorted(ids)

    def test_order_by_node_variable_descending(self, gf):
        """ORDER BY a node variable DESC sorts by internal ID descending."""
        gf.execute("CREATE (:P), (:P), (:P)")
        results = gf.execute("MATCH (n:P) RETURN id(n) AS nid ORDER BY n DESC")
        ids = [r["nid"].value for r in results]
        assert ids == sorted(ids, reverse=True)


class TestRelationshipOrderBy:
    """Integration tests for ORDER BY with relationship variables."""

    def test_order_by_relationship_variable_ascending(self, gf):
        """ORDER BY a relationship variable sorts by internal ID ascending."""
        gf.execute("CREATE ()-[:T]->(), ()-[:T]->(), ()-[:T]->()")
        results = gf.execute("MATCH ()-[r:T]->() RETURN id(r) AS rid ORDER BY r ASC")
        ids = [r["rid"].value for r in results]
        assert ids == sorted(ids)

    def test_order_by_relationship_variable_descending(self, gf):
        """ORDER BY a relationship variable DESC sorts by internal ID descending."""
        gf.execute("CREATE ()-[:T]->(), ()-[:T]->(), ()-[:T]->()")
        results = gf.execute("MATCH ()-[r:T]->() RETURN id(r) AS rid ORDER BY r DESC")
        ids = [r["rid"].value for r in results]
        assert ids == sorted(ids, reverse=True)


class TestCrossTypeComparison:
    """Integration tests for comparing graph elements against non-graph values."""

    def test_node_less_than_integer_is_null(self, gf):
        """node < integer should be NULL (incomparable types)."""
        gf.execute("CREATE ()")
        results = gf.execute("MATCH (n) RETURN (n < 1) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(results[0]["result"], CypherNull)

    def test_node_greater_than_integer_is_null(self, gf):
        """node > integer should be NULL (incomparable types)."""
        gf.execute("CREATE ()")
        results = gf.execute("MATCH (n) RETURN (n > 1) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(results[0]["result"], CypherNull)
