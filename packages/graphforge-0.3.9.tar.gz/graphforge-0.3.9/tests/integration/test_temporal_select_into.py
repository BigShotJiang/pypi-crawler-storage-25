"""Integration tests for temporal select-into constructors (cross-type projection).

These cover the openCypher Temporal3 TCK scenarios: projecting one temporal type
from another, optionally overriding individual components.
"""

import datetime

import pytest

from graphforge import GraphForge


@pytest.fixture
def gf():
    return GraphForge()


class TestDateSelectInto:
    """date({date: other}) / date({date: other, ...overrides})"""

    def test_select_date_from_date(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 11, day: 11}) AS other
            RETURN date({date: other}) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 11)

    def test_select_date_from_date_with_year_override(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 11, day: 11}) AS other
            RETURN date({date: other, year: 28}) AS result
        """)
        assert result[0]["result"].value == datetime.date(28, 11, 11)

    def test_select_date_from_date_with_day_override(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 11, day: 11}) AS other
            RETURN date({date: other, day: 28}) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 28)

    def test_select_date_from_localdatetime(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, month: 11, day: 11, hour: 12, minute: 31, second: 14})
                AS other
            RETURN date({date: other}) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 11)

    def test_select_date_from_datetime(self, gf):
        result = gf.execute("""
            WITH datetime({year: 1984, month: 11, day: 11, hour: 12, timezone: '+01:00'}) AS other
            RETURN date({date: other}) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 11)

    def test_select_date_passthrough(self, gf):
        """date(other) where other is already a date returns it unchanged."""
        result = gf.execute("""
            WITH date({year: 1984, month: 11, day: 11}) AS other
            RETURN date(other) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 11)

    def test_select_date_from_localdatetime_passthrough(self, gf):
        """date(localdatetime) extracts the date portion."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, month: 11, day: 11, hour: 12, minute: 31, second: 14})
                AS other
            RETURN date(other) AS result
        """)
        assert result[0]["result"].value == datetime.date(1984, 11, 11)


class TestLocalTimeSelectInto:
    """localtime({time: other}) / localtime({time: other, ...overrides})"""

    def test_select_localtime_from_localtime(self, gf):
        result = gf.execute("""
            WITH localtime({hour: 12, minute: 31, second: 14}) AS other
            RETURN localtime({time: other}) AS result
        """)
        assert result[0]["result"].value == datetime.time(12, 31, 14)

    def test_select_localtime_from_localtime_with_second_override(self, gf):
        result = gf.execute("""
            WITH localtime({hour: 12, minute: 31, second: 14}) AS other
            RETURN localtime({time: other, second: 42}) AS result
        """)
        assert result[0]["result"].value == datetime.time(12, 31, 42)

    def test_select_localtime_from_time(self, gf):
        result = gf.execute("""
            WITH time({hour: 12, minute: 31, second: 14, timezone: '+01:00'}) AS other
            RETURN localtime({time: other}) AS result
        """)
        assert result[0]["result"].value == datetime.time(12, 31, 14)

    def test_select_localtime_from_localdatetime(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN localtime({time: other}) AS result
        """)
        val = result[0]["result"].value
        assert val.hour == 12
        assert val.minute == 31
        assert val.second == 14

    def test_select_localtime_from_datetime(self, gf):
        result = gf.execute("""
            WITH datetime({year: 1984, month: 10, day: 11, hour: 12, timezone: '+01:00'}) AS other
            RETURN localtime({time: other}) AS result
        """)
        val = result[0]["result"].value
        assert val.hour == 12
        assert val.minute == 0

    def test_select_localtime_passthrough(self, gf):
        """localtime(other) where other is a localtime returns same time."""
        result = gf.execute("""
            WITH localtime({hour: 12, minute: 31, second: 14}) AS other
            RETURN localtime(other) AS result
        """)
        assert result[0]["result"].value == datetime.time(12, 31, 14)


class TestLocalDateTimeSelectInto:
    """localdatetime from date and/or time components."""

    def test_select_localdatetime_from_date(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN localdatetime({date: other, hour: 10, minute: 10, second: 10}) AS result
        """)
        val = result[0]["result"].value
        assert val == datetime.datetime(1984, 10, 11, 10, 10, 10)

    def test_select_localdatetime_from_date_with_day_override(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN localdatetime({date: other, day: 28, hour: 10, minute: 10, second: 10})
                AS result
        """)
        val = result[0]["result"].value
        assert val == datetime.datetime(1984, 10, 28, 10, 10, 10)

    def test_select_localdatetime_from_localdatetime(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN localdatetime({date: other, hour: 10, minute: 10, second: 10}) AS result
        """)
        val = result[0]["result"].value
        # The date is 1984-03-07 (ISO week 10, Wednesday)
        assert val.year == 1984
        assert val.month == 3
        assert val.day == 7
        assert val.hour == 10

    def test_select_localdatetime_from_datetime_component(self, gf):
        """localdatetime({datetime: other}) strips timezone."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN localdatetime({datetime: other}) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        assert val.month == 3
        assert val.day == 7
        assert val.hour == 12

    def test_select_localdatetime_datetime_with_overrides(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN localdatetime({datetime: other, day: 28, second: 42}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 28
        assert val.second == 42

    def test_select_localdatetime_passthrough(self, gf):
        """localdatetime(other) where other is localdatetime returns same value."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN localdatetime(other) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984

    def test_select_localdatetime_hour_overflow_carries_to_day(self, gf):
        """localdatetime({date: other, hour: 25}) carries overflow into the next day."""
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN localdatetime({date: other, hour: 25, minute: 0, second: 0}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 12
        assert val.hour == 1


class TestDateTimeSelectInto:
    """datetime from date and/or time components."""

    def test_select_datetime_from_date(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN datetime({date: other, hour: 10, minute: 10, second: 10}) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        assert val.month == 10
        assert val.day == 11
        assert val.hour == 10
        assert val.tzinfo is not None  # datetime always has timezone

    def test_select_datetime_from_date_with_timezone(self, gf):
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN datetime({date: other, hour: 10, minute: 10, second: 10,
                             timezone: '+05:00'}) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        utcoffset = val.utcoffset()
        assert utcoffset == datetime.timedelta(hours=5)

    def test_select_datetime_from_localdatetime(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN datetime({date: other, hour: 10, minute: 10, second: 10}) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        assert val.month == 3
        assert val.day == 7
        assert val.hour == 10

    def test_select_datetime_from_datetime_with_select(self, gf):
        """datetime({datetime: other}) preserves timezone and components."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN datetime({datetime: other}) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        assert val.month == 3
        assert val.day == 7

    def test_select_datetime_from_datetime_with_overrides(self, gf):
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN datetime({datetime: other, day: 28, second: 42}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 28
        assert val.second == 42

    def test_select_datetime_passthrough(self, gf):
        """datetime(other) where other is a localdatetime returns with UTC."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, week: 10, dayOfWeek: 3,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN datetime(other) AS result
        """)
        val = result[0]["result"].value
        assert val.year == 1984
        assert val.tzinfo is not None

    def test_select_datetime_from_date_strips_subseconds(self, gf):
        """datetime({date: other}) resets time to midnight; subseconds from source are cleared."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, month: 10, day: 11,
                                hour: 12, minute: 31, second: 14, millisecond: 645}) AS other
            RETURN datetime({date: other, hour: 9, minute: 0, second: 0}) AS result
        """)
        val = result[0]["result"].value
        assert val.microsecond == 0
        assert val.hour == 9

    def test_select_datetime_hour_overflow_carries_to_day(self, gf):
        """datetime({date: other, hour: 25}) carries hour overflow into the next day."""
        result = gf.execute("""
            WITH date({year: 1984, month: 10, day: 11}) AS other
            RETURN datetime({date: other, hour: 25, minute: 0, second: 0}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 12
        assert val.hour == 1

    def test_select_datetime_null_propagates(self, gf):
        """datetime({datetime: null}) returns null (three-valued logic)."""
        result = gf.execute("RETURN datetime({datetime: null}) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(result[0]["result"], CypherNull)

    def test_select_datetime_date_null_propagates(self, gf):
        """datetime({date: null}) returns null (three-valued logic)."""
        result = gf.execute("RETURN datetime({date: null}) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(result[0]["result"], CypherNull)


class TestTimeSelectInto:
    """time({time: other}) / time({time: other, timezone: ...})"""

    def test_select_time_from_aware_time_with_timezone(self, gf):
        """time({time: aware_other, timezone: '+05:00'}) converts (not replaces) the timezone."""
        result = gf.execute("""
            WITH time({hour: 12, minute: 0, second: 0, timezone: '+01:00'}) AS other
            RETURN time({time: other, timezone: '+05:00'}) AS result
        """)
        val = result[0]["result"].value
        assert val.hour == 16
        import datetime

        assert val.utcoffset() == datetime.timedelta(hours=5)

    def test_select_time_from_aware_time_preserves_subseconds(self, gf):
        """time({time: other}) where other has milliseconds preserves them."""
        result = gf.execute("""
            WITH time({hour: 12, minute: 0, second: 0, millisecond: 500, timezone: '+01:00'})
                AS other
            RETURN time({time: other}) AS result
        """)
        val = result[0]["result"].value
        assert val.microsecond == 500000


class TestNullPropagationSelectInto:
    """NULL propagation through select-into constructors."""

    def test_localdatetime_null_propagates(self, gf):
        """localdatetime({localdatetime: null}) returns null."""
        result = gf.execute("RETURN localdatetime({localdatetime: null}) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(result[0]["result"], CypherNull)

    def test_localdatetime_datetime_null_propagates(self, gf):
        """localdatetime({datetime: null}) returns null."""
        result = gf.execute("RETURN localdatetime({datetime: null}) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(result[0]["result"], CypherNull)

    def test_localdatetime_date_null_propagates(self, gf):
        """localdatetime({date: null}) returns null (falls through to year-based constructor)."""
        result = gf.execute("RETURN localdatetime({date: null}) AS result")
        from graphforge.types.values import CypherNull

        assert isinstance(result[0]["result"], CypherNull)

    def test_select_localdatetime_from_date_strips_subseconds(self, gf):
        """localdatetime({date: other}) resets time to midnight; subseconds cleared."""
        result = gf.execute("""
            WITH localdatetime({year: 1984, month: 10, day: 11,
                                hour: 12, minute: 0, second: 0, millisecond: 500}) AS other
            RETURN localdatetime({date: other, hour: 9, minute: 0, second: 0}) AS result
        """)
        val = result[0]["result"].value
        assert val.microsecond == 0
        assert val.hour == 9

    def test_datetime_year_time_hour_overflow(self, gf):
        """datetime({year: Y, time: t, hour: 25}) carries overflow into next day."""
        result = gf.execute("""
            WITH time({hour: 12, minute: 0, second: 0}) AS t
            RETURN datetime({year: 1984, month: 10, day: 11, time: t, hour: 25}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 12
        assert val.hour == 1

    def test_localdatetime_year_time_hour_overflow(self, gf):
        """localdatetime({year: Y, time: t, hour: 25}) carries overflow into next day."""
        result = gf.execute("""
            WITH time({hour: 12, minute: 0, second: 0}) AS t
            RETURN localdatetime({year: 1984, month: 10, day: 11, time: t, hour: 25}) AS result
        """)
        val = result[0]["result"].value
        assert val.day == 12
        assert val.hour == 1
