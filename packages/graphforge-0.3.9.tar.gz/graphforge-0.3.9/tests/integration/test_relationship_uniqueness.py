"""Integration tests for relationship uniqueness in MATCH patterns.

openCypher spec: the same relationship may not be bound more than once in a
single MATCH pattern. This covers both compile-time detection (same variable
reused in one pattern) and runtime enforcement (different variables bound to
the same edge).
"""

import pytest

from graphforge import GraphForge


class TestRelationshipUniquenessCompileTime:
    """Compile-time checks for relationship variable uniqueness."""

    def test_same_rel_var_twice_in_pattern_raises(self):
        """Using the same relationship variable twice in one pattern raises SyntaxError.

        Corresponds to TCK Match3[29].
        """
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="RelationshipUniquenessViolation"):
            gf.execute("MATCH (a)-[r]->()-[r]->(a) RETURN r")

    def test_same_rel_var_twice_typed_in_pattern_raises(self):
        """Same variable with type restriction still raises when used twice."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="RelationshipUniquenessViolation"):
            gf.execute("MATCH (a)-[r:T]->()-[r:T]->(b) RETURN r")

    def test_same_rel_var_three_times_raises(self):
        """Variable used a third time also triggers the check."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="RelationshipUniquenessViolation"):
            gf.execute("MATCH (a)-[r]->()-[r]->()-[r]->(b) RETURN r")

    def test_different_rel_vars_in_pattern_is_valid(self):
        """Two different relationship variables in the same pattern is fine."""
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T1]->(:B)-[:T2]->(:C)")
        results = gf.execute("MATCH (a)-[r1]->(b)-[r2]->(c) RETURN r1, r2")
        assert len(results) == 1

    def test_rel_var_reused_across_separate_match_clauses_is_valid(self):
        """The same relationship variable can appear in two separate MATCH clauses.

        Corresponds to TCK Match3[24].
        """
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T]->(:B)")
        results = gf.execute(
            "MATCH (a1)-[r:T]->() WITH r, a1 MATCH (a1)-[r:T]->(b2) RETURN a1, r, b2"
        )
        assert len(results) == 1


class TestRelationshipUniquenessRuntime:
    """Runtime enforcement: different variables cannot bind the same edge."""

    def test_two_hop_directed_pattern_excludes_reused_edge(self):
        """Multi-hop MATCH skips rows where the same edge fills two variables.

        Graph: (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)
        Query: MATCH (x:A)-[r1]->(y)-[r2]-(z)

        The row (A, T1, Looper, T1, A) must be excluded because T1 would fill
        both r1 and r2.  Expected 2 rows.  Corresponds to TCK Match3[15].
        """
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)")
        results = gf.execute("MATCH (x:A)-[r1]->(y)-[r2]-(z) RETURN x, r1, y, r2, z")
        assert len(results) == 2
        rel_pairs = {(row["r1"].type, row["r2"].type) for row in results}
        assert rel_pairs == {("T1", "LOOP"), ("T1", "T2")}

    def test_two_hop_undirected_pattern_excludes_reused_edge(self):
        """Fully undirected two-hop MATCH returns exactly 6 unique rows.

        Graph: (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)
        Query: MATCH (x)-[r1]-(y)-[r2]-(z)

        Expected 6 rows (no row may reuse the same edge for r1 and r2).
        Corresponds to TCK Match3[16].
        """
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)")
        results = gf.execute("MATCH (x)-[r1]-(y)-[r2]-(z) RETURN x, r1, y, r2, z")
        assert len(results) == 6
        # No row should have the same edge for r1 and r2
        for row in results:
            assert row["r1"].id != row["r2"].id
        rel_pairs = [(row["r1"].type, row["r2"].type) for row in results]
        # Verify exact set of pairs
        pair_set = set(rel_pairs)
        assert ("T1", "LOOP") in pair_set
        assert ("T1", "T2") in pair_set
        assert ("LOOP", "T1") in pair_set
        assert ("LOOP", "T2") in pair_set
        assert ("T2", "LOOP") in pair_set
        assert ("T2", "T1") in pair_set

    def test_simple_linear_pattern_unaffected(self):
        """Linear chains (no shared edges) are not affected by uniqueness check."""
        gf = GraphForge()
        gf.execute("CREATE (:A {name:'a'})-[:KNOWS]->(:B {name:'b'})-[:FRIEND]->(:C {name:'c'})")
        results = gf.execute("MATCH (a)-[r1]->(b)-[r2]->(c) RETURN r1, r2")
        assert len(results) == 1
        assert results[0]["r1"].type == "KNOWS"
        assert results[0]["r2"].type == "FRIEND"

    def test_self_loop_single_hop_still_matches(self):
        """Single-hop match on a self-loop returns one row (no uniqueness issue)."""
        gf = GraphForge()
        gf.execute("CREATE (a:A)-[:LOOP]->(a)")
        results = gf.execute("MATCH (a)-[r]->(b) RETURN a, r, b")
        assert len(results) == 1
        assert results[0]["r"].type == "LOOP"

    def test_anonymous_two_hop_excludes_reused_edge(self):
        """Anonymous multi-hop MATCH skips rows where the same edge fills two hops.

        Graph: (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)
        Query: MATCH (x)-[]-(y)-[]-(z)

        Expected 6 rows (anonymous hops still enforce relationship uniqueness).
        """
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)")
        results = gf.execute("MATCH (x)-[]-(y)-[]-(z) RETURN x, y, z")
        # Same 6 unique traversals as the named-edge version
        assert len(results) == 6

    def test_path_variable_multi_hop_excludes_reused_edge(self):
        """ExpandMultiHop (path variable) enforces relationship uniqueness.

        Graph: (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)
        Query: MATCH p=(x)-[r1]-(y)-[r2]-(z) RETURN r1, r2

        Expected 6 rows.  The same edge must not fill both r1 and r2.
        """
        gf = GraphForge()
        gf.execute("CREATE (:A)-[:T1]->(l:Looper), (l)-[:LOOP]->(l), (l)-[:T2]->(:B)")
        results = gf.execute("MATCH p=(x)-[r1]-(y)-[r2]-(z) RETURN r1, r2")
        assert len(results) == 6
        for row in results:
            assert row["r1"].id != row["r2"].id
