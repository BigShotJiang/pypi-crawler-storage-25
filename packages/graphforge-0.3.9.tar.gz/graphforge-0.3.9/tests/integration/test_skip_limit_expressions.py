"""Integration tests for SKIP/LIMIT accepting expression values."""

import pytest

from graphforge import GraphForge


@pytest.fixture
def graph():
    gf = GraphForge()
    for name in ["Alice", "Bob", "Carol", "Dave", "Eve"]:
        gf.execute(f"CREATE (:Person {{name: '{name}'}})")
    return gf


class TestLimitExpression:
    def test_limit_integer_literal(self, graph):
        results = graph.execute("MATCH (n:Person) RETURN n.name AS name ORDER BY n.name LIMIT 2")
        assert len(results) == 2
        assert results[0]["name"].value == "Alice"

    def test_limit_arithmetic_expression(self, graph):
        results = graph.execute(
            "MATCH (n:Person) RETURN n.name AS name ORDER BY n.name LIMIT 1 + 2"
        )
        assert len(results) == 3

    def test_limit_multiplication_expression(self, graph):
        results = graph.execute(
            "MATCH (n:Person) RETURN n.name AS name ORDER BY n.name LIMIT 2 * 2"
        )
        assert len(results) == 4

    def test_limit_zero(self, graph):
        results = graph.execute("MATCH (n:Person) RETURN n LIMIT 0")
        assert len(results) == 0


class TestSkipExpression:
    def test_skip_integer_literal(self, graph):
        results = graph.execute("MATCH (n:Person) RETURN n.name AS name ORDER BY n.name SKIP 3")
        assert len(results) == 2
        assert results[0]["name"].value == "Dave"

    def test_skip_arithmetic_expression(self, graph):
        results = graph.execute("MATCH (n:Person) RETURN n.name AS name ORDER BY n.name SKIP 1 + 2")
        assert len(results) == 2
        assert results[0]["name"].value == "Dave"

    def test_skip_zero(self, graph):
        results = graph.execute("MATCH (n:Person) RETURN n.name AS name SKIP 0")
        assert len(results) == 5


class TestSkipAndLimitExpressions:
    def test_skip_and_limit_both_expressions(self, graph):
        results = graph.execute(
            "MATCH (n:Person) RETURN n.name AS name ORDER BY n.name SKIP 1 + 1 LIMIT 2 * 1"
        )
        assert len(results) == 2
        assert results[0]["name"].value == "Carol"
        assert results[1]["name"].value == "Dave"

    def test_with_clause_limit_expression(self, graph):
        results = graph.execute(
            "MATCH (n:Person) WITH n ORDER BY n.name LIMIT 1 + 1 RETURN n.name AS name"
        )
        assert len(results) == 2
        assert results[0]["name"].value == "Alice"

    def test_with_clause_skip_expression(self, graph):
        results = graph.execute(
            "MATCH (n:Person) WITH n ORDER BY n.name SKIP 2 + 1 RETURN n.name AS name"
        )
        assert len(results) == 2
        assert results[0]["name"].value == "Dave"
