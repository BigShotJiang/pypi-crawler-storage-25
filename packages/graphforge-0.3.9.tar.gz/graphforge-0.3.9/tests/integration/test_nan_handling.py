"""Integration tests for NaN (Not a Number) handling per openCypher spec (#301).

Tests cover:
- 0.0/0.0 produces NaN (CypherFloat with nan value), not null
- 0/0 (integer) still produces null
- NaN in equality: NaN = anything → false, NaN <> anything → true
- NaN in ordering: <, >, <=, >= with numeric → false; with string → null
- NaN in arithmetic propagates (NaN + x = NaN, etc.)
- toString(NaN) returns "NaN"
- NaN sort order: after regular numbers, before null
"""

import math

import pytest

from graphforge import GraphForge
from graphforge.types.values import CypherBool, CypherFloat, CypherNull, CypherString


@pytest.mark.integration
class TestNaNProduction:
    """Tests that NaN is produced from float division by zero."""

    def test_float_div_zero_returns_nan(self):
        gf = GraphForge()
        result = gf.execute("RETURN 0.0 / 0.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert math.isnan(result.value)

    def test_float_div_zero_nonzero_returns_nan(self):
        """Non-zero float divided by zero returns NaN (evaluator returns nan before Python can raise)."""
        gf = GraphForge()
        result = gf.execute("RETURN 1.0 / 0.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert math.isnan(result.value)

    def test_int_div_zero_returns_null(self):
        """Integer division by zero remains NULL per openCypher spec."""
        gf = GraphForge()
        result = gf.execute("RETURN 0 / 0 AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_int_div_zero_nonzero_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 5 / 0 AS r")[0]["r"]
        assert isinstance(result, CypherNull)


@pytest.mark.integration
class TestNaNEquality:
    """Tests for NaN equality and inequality per openCypher spec.

    NaN is not equal to anything (including itself): NaN = x → false.
    NaN != anything: NaN <> x → true.
    """

    @pytest.mark.parametrize(
        "rhs",
        ["1", "1.0", "0.0 / 0.0", "'a'", "true", "null"],
        ids=["int", "float", "nan", "string", "bool", "null"],
    )
    def test_nan_equals_x_returns_false_or_null(self, rhs):
        gf = GraphForge()
        result = gf.execute(f"RETURN 0.0 / 0.0 = {rhs} AS r")[0]["r"]
        # NaN = null → null (null propagation); NaN = anything else → false
        if rhs == "null":
            assert isinstance(result, CypherNull)
        else:
            assert isinstance(result, CypherBool)
            assert result.value is False

    def test_nan_not_equal_int(self):
        gf = GraphForge()
        result = gf.execute("RETURN 0.0 / 0.0 <> 1 AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is True

    def test_nan_not_equal_self(self):
        gf = GraphForge()
        result = gf.execute("RETURN 0.0 / 0.0 <> 0.0 / 0.0 AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is True


@pytest.mark.integration
class TestNaNOrdering:
    """Tests for NaN ordering comparisons per openCypher spec.

    All ordering comparisons (>, <, >=, <=) between NaN and numeric return false.
    NaN compared to string (incompatible type) returns null.
    """

    @pytest.mark.parametrize(
        "op,rhs",
        [
            (">", "1"),
            (">=", "1"),
            ("<", "1"),
            ("<=", "1"),
            (">", "1.0"),
            (">=", "1.0"),
            ("<", "1.0"),
            ("<=", "1.0"),
            (">", "0.0 / 0.0"),
            ("<", "0.0 / 0.0"),
            (">=", "0.0 / 0.0"),
            ("<=", "0.0 / 0.0"),
        ],
        ids=[
            "gt_int",
            "gte_int",
            "lt_int",
            "lte_int",
            "gt_float",
            "gte_float",
            "lt_float",
            "lte_float",
            "gt_nan",
            "lt_nan",
            "gte_nan",
            "lte_nan",
        ],
    )
    def test_nan_ordering_with_numeric_returns_false(self, op, rhs):
        gf = GraphForge()
        result = gf.execute(f"RETURN 0.0 / 0.0 {op} {rhs} AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False

    @pytest.mark.parametrize("op", [">", ">=", "<", "<="])
    def test_nan_ordering_with_string_returns_null(self, op):
        gf = GraphForge()
        result = gf.execute(f"RETURN 0.0 / 0.0 {op} 'a' AS r")[0]["r"]
        assert isinstance(result, CypherNull)


@pytest.mark.integration
class TestNaNArithmetic:
    """Tests for NaN propagation in arithmetic."""

    def test_nan_plus_number(self):
        gf = GraphForge()
        result = gf.execute("RETURN 0.0 / 0.0 + 1.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert math.isnan(result.value)

    def test_nan_times_number(self):
        gf = GraphForge()
        result = gf.execute("RETURN 0.0 / 0.0 * 2.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert math.isnan(result.value)

    def test_number_minus_nan(self):
        gf = GraphForge()
        result = gf.execute("RETURN 5.0 - 0.0 / 0.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert math.isnan(result.value)


@pytest.mark.integration
class TestNaNStringConversion:
    """Tests for toString() with NaN."""

    def test_tostring_nan_returns_nan_string(self):
        gf = GraphForge()
        result = gf.execute("RETURN toString(0.0 / 0.0) AS r")[0]["r"]
        assert isinstance(result, CypherString)
        assert result.value == "NaN"


@pytest.mark.integration
class TestNaNSortOrder:
    """Tests for NaN sort order: after regular numbers, before null."""

    def test_nan_sorts_after_regular_float_asc(self):
        """NaN should appear after 1.5 and before null in ascending order."""
        gf = GraphForge()
        results = gf.execute("UNWIND [null, 0.0 / 0.0, 1.5] AS v RETURN v ORDER BY v ASC")
        values = [r["v"] for r in results]
        # Expected: 1.5, NaN, null
        assert isinstance(values[0], CypherFloat) and values[0].value == 1.5
        assert isinstance(values[1], CypherFloat) and math.isnan(values[1].value)
        assert isinstance(values[2], CypherNull)

    def test_nan_sorts_after_null_desc(self):
        """In descending order: null first, then NaN, then regular numbers."""
        gf = GraphForge()
        results = gf.execute("UNWIND [null, 0.0 / 0.0, 1.5] AS v RETURN v ORDER BY v DESC")
        values = [r["v"] for r in results]
        # Expected: null, NaN, 1.5
        assert isinstance(values[0], CypherNull)
        assert isinstance(values[1], CypherFloat) and math.isnan(values[1].value)
        assert isinstance(values[2], CypherFloat) and values[2].value == 1.5
