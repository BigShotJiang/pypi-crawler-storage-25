"""Integration tests for CALL procedure invocation."""

import pytest

from graphforge import GraphForge
from graphforge.procedures.registry import ProcedureColumn, ProcedureDefinition


@pytest.fixture
def gf():
    instance = GraphForge()

    # STRING procedure: returns labels
    instance.register_procedure(
        ProcedureDefinition(
            name="test.labels",
            parameters=[],
            output_columns=[ProcedureColumn(name="label", cypher_type="STRING")],
            implementation=lambda: [{"label": "A"}, {"label": "B"}, {"label": "C"}],
        )
    )

    # Lookup procedure: takes a name and returns city/country_code
    instance.register_procedure(
        ProcedureDefinition(
            name="test.lookup",
            parameters=[ProcedureColumn(name="name", cypher_type="STRING")],
            output_columns=[
                ProcedureColumn(name="city", cypher_type="STRING"),
                ProcedureColumn(name="country_code", cypher_type="INTEGER"),
            ],
            implementation=lambda name: [
                r
                for r in [
                    {"name": "Alice", "city": "London", "country_code": 44},
                    {"name": "Bob", "city": "Berlin", "country_code": 49},
                    {"name": "Alice", "city": "Sydney", "country_code": 61},
                ]
                if r["name"] == name
            ],
        )
    )

    # Void procedure
    instance.register_procedure(
        ProcedureDefinition(
            name="test.doNothing",
            parameters=[],
            output_columns=[],
            implementation=lambda: [],
        )
    )

    return instance


class TestStandaloneCall:
    def test_standalone_call_returns_all_rows(self, gf):
        result = gf.execute("CALL test.labels()")
        assert len(result) == 3
        labels = sorted(r["label"].value for r in result)
        assert labels == ["A", "B", "C"]

    def test_standalone_void_returns_empty(self, gf):
        result = gf.execute("CALL test.doNothing()")
        assert result == []

    def test_standalone_with_yield_star(self, gf):
        result = gf.execute("CALL test.labels() YIELD *")
        assert len(result) == 3

    def test_standalone_implicit_args(self, gf):
        result = gf.execute("CALL test.lookup", parameters={"name": "Alice"})
        assert len(result) == 2
        cities = sorted(r["city"].value for r in result)
        assert cities == ["London", "Sydney"]

    def test_standalone_no_param_bindings_in_result(self, gf):
        result = gf.execute("CALL test.lookup", parameters={"name": "Bob"})
        for row in result:
            for k in row:
                assert not k.startswith("$"), f"Unexpected param key '{k}' in result"

    def test_standalone_unknown_procedure_raises(self):
        gf = GraphForge()
        with pytest.raises(ValueError, match="ProcedureNotFound"):
            gf.execute("CALL unknown.proc()")


class TestInQueryCall:
    def test_inquery_call_with_yield(self, gf):
        result = gf.execute("CALL test.labels() YIELD label RETURN label")
        assert len(result) == 3

    def test_inquery_call_explicit_args(self, gf):
        result = gf.execute("CALL test.lookup('Alice') YIELD city RETURN city")
        assert len(result) == 2
        cities = sorted(r["city"].value for r in result)
        assert cities == ["London", "Sydney"]

    def test_inquery_call_yield_alias(self, gf):
        result = gf.execute("CALL test.labels() YIELD label AS lbl RETURN lbl")
        assert len(result) == 3
        for row in result:
            assert "lbl" in row

    def test_inquery_void_pass_through(self, gf):
        gf.execute("CREATE (:X {name: 'test'})")
        result = gf.execute("MATCH (n) CALL test.doNothing() RETURN n.name AS name")
        assert len(result) == 1
        assert result[0]["name"].value == "test"

    def test_inquery_call_cross_join(self, gf):
        """In-query CALL expands each input row against all procedure rows."""
        gf.execute("CREATE (:N), (:N)")
        result = gf.execute("MATCH (n:N) CALL test.labels() YIELD label RETURN n, label")
        # 2 nodes x 3 labels = 6 rows
        assert len(result) == 6

    def test_inquery_call_empty_match_no_rows(self, gf):
        """Empty MATCH means empty rows through procedure."""
        result = gf.execute("MATCH (n:Empty) CALL test.labels() YIELD label RETURN label")
        assert result == []

    def test_wrong_arg_count_raises(self, gf):
        with pytest.raises(SyntaxError, match="InvalidNumberOfArguments"):
            gf.execute("CALL test.lookup('a', 'b') YIELD city RETURN city")

    def test_undefined_variable_in_return_raises(self, gf):
        """CALL without YIELD should raise UndefinedVariable for RETURN."""
        with pytest.raises(SyntaxError, match="UndefinedVariable"):
            gf.execute("CALL test.lookup('Alice')\nRETURN city")

    def test_implicit_args_in_query_raises(self, gf):
        with pytest.raises(SyntaxError, match="InvalidArgumentPassingMode"):
            gf.execute("CALL test.lookup YIELD city RETURN city")

    def test_yield_star_in_query_raises(self, gf):
        with pytest.raises(SyntaxError, match="YIELD \\*"):
            gf.execute("CALL test.labels() YIELD * RETURN 1")
