"""Integration tests for operator precedence and null propagation fixes (issue #296).

Tests cover:
- Integer division returns integer (openCypher spec)
- Exponentiation (^) always returns float, is left-associative
- Unary minus has higher precedence than exponentiation
- IS NULL/IN/STARTS WITH have higher precedence than comparison operators
- less_than() returns null for incompatible types
- STARTS WITH/ENDS WITH/CONTAINS with non-string types returns null
"""

import pytest

from graphforge import GraphForge
from graphforge.types.values import CypherBool, CypherFloat, CypherInt, CypherNull


@pytest.mark.integration
class TestIntegerDivision:
    """Integer division should return integer per openCypher spec."""

    def test_exact_integer_division(self):
        gf = GraphForge()
        result = gf.execute("RETURN 10 / 2 AS r")[0]["r"]
        assert isinstance(result, CypherInt)
        assert result.value == 5

    def test_truncating_integer_division(self):
        gf = GraphForge()
        result = gf.execute("RETURN 7 / 2 AS r")[0]["r"]
        assert isinstance(result, CypherInt)
        assert result.value == 3

    def test_negative_integer_division_truncates_toward_zero(self):
        gf = GraphForge()
        result = gf.execute("RETURN -7 / 2 AS r")[0]["r"]
        assert isinstance(result, CypherInt)
        assert result.value == -3

    def test_float_division_returns_float(self):
        gf = GraphForge()
        result = gf.execute("RETURN 7.0 / 2 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert abs(result.value - 3.5) < 1e-9

    def test_int_div_float_returns_float(self):
        gf = GraphForge()
        result = gf.execute("RETURN 7 / 2.0 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert abs(result.value - 3.5) < 1e-9


@pytest.mark.integration
class TestExponentiation:
    """Exponentiation always returns float and is left-associative."""

    def test_int_power_int_returns_float(self):
        gf = GraphForge()
        result = gf.execute("RETURN 4 ^ 3 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 64.0

    def test_float_power_int_returns_float(self):
        gf = GraphForge()
        result = gf.execute("RETURN 4.0 ^ 3 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 64.0

    def test_left_associative_chaining(self):
        # Left-associative: 2^3^2 = (2^3)^2 = 64, NOT 2^(3^2) = 512
        gf = GraphForge()
        result = gf.execute("RETURN 2 ^ 3 ^ 2 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 64.0

    def test_precedence_over_multiplication(self):
        # 4^3 * 2^3 = 64 * 8 = 512 (^ has higher precedence than *)
        gf = GraphForge()
        result = gf.execute("RETURN 4 ^ 3 * 2 ^ 3 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 512.0

    def test_parenthesized_left_operand(self):
        # (4 ^ (3 * 2)) ^ 3 = (4^6)^3 = 4096^3 = 68719476736.0
        gf = GraphForge()
        result = gf.execute("RETURN 4 ^ (3 * 2) ^ 3 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == pytest.approx(68719476736.0)


@pytest.mark.integration
class TestUnaryMinusPrecedence:
    """Unary minus has higher precedence than exponentiation."""

    def test_unary_minus_before_power(self):
        # -3^2 = (-3)^2 = 9, NOT -(3^2) = -9
        gf = GraphForge()
        result = gf.execute("RETURN -3 ^ 2 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 9.0

    def test_explicit_parens_same_as_implicit(self):
        gf = GraphForge()
        result = gf.execute("RETURN (-3) ^ 2 AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == 9.0

    def test_explicit_parens_with_power_first(self):
        gf = GraphForge()
        result = gf.execute("RETURN -(3 ^ 2) AS r")[0]["r"]
        assert isinstance(result, CypherFloat)
        assert result.value == -9.0


@pytest.mark.integration
class TestIsNullPrecedence:
    """IS NULL/IS NOT NULL have higher precedence than comparison operators."""

    def test_is_null_higher_precedence_than_eq(self):
        # null IS NULL = null IS NULL → (null IS NULL) = (null IS NULL) → true = true → true
        gf = GraphForge()
        result = gf.execute("RETURN null IS NULL = null IS NULL AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is True

    def test_is_not_null_higher_precedence_than_eq(self):
        # null IS NOT NULL = null IS NULL → false = true → false
        gf = GraphForge()
        result = gf.execute("RETURN null IS NOT NULL = null IS NULL AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False

    def test_is_null_higher_precedence_than_ne(self):
        # null IS NULL <> null IS NOT NULL → true <> false → true
        gf = GraphForge()
        result = gf.execute("RETURN null IS NULL <> null IS NOT NULL AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is True

    def test_not_is_null_parses_correctly(self):
        # NOT null IS NULL → NOT (null IS NULL) → NOT true → false
        gf = GraphForge()
        result = gf.execute("RETURN NOT null IS NULL AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False


@pytest.mark.integration
class TestInPrecedence:
    """IN operator has higher precedence than comparison operators."""

    def test_in_higher_precedence_than_eq(self):
        # [1,2] = [3,4] IN [[3,4]] → [1,2] = ([3,4] IN [[3,4]]) → [1,2] = true → false
        gf = GraphForge()
        result = gf.execute("RETURN [1,2] = [3,4] IN [[3,4]] AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False

    def test_in_result_used_in_comparison(self):
        # [3,4] = [3,4] IN [[1,2],[3,4]] → [3,4] = ([3,4] IN [[1,2],[3,4]]) → [3,4] = true → false
        gf = GraphForge()
        result = gf.execute("RETURN [3,4] = [3,4] IN [[1,2],[3,4]] AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False


@pytest.mark.integration
class TestStringPredicatePrecedence:
    """String predicates (STARTS WITH, ENDS WITH, CONTAINS) have higher precedence than comparison."""

    def test_starts_with_null_propagation(self):
        # 'abc' STARTS WITH null → null
        gf = GraphForge()
        result = gf.execute("RETURN 'abc' STARTS WITH null AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_starts_with_non_string_returns_null(self):
        # 'abc' STARTS WITH true → null (type mismatch)
        gf = GraphForge()
        result = gf.execute("RETURN 'abc' STARTS WITH true AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_starts_with_non_string_left_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 123 STARTS WITH '1' AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_ends_with_non_string_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 'abc' ENDS WITH 123 AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_contains_non_string_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 456 CONTAINS '45' AS r")[0]["r"]
        assert isinstance(result, CypherNull)


@pytest.mark.integration
class TestIncomparableTypesReturnNull:
    """Comparing incompatible types with < > <= >= returns null."""

    def test_list_less_than_bool_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN [1, 2] < true AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_bool_less_than_list_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN true < [1, 2] AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_string_less_than_int_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 'abc' < 5 AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_int_less_than_string_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN 5 < 'abc' AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_list_greater_than_bool_returns_null(self):
        gf = GraphForge()
        result = gf.execute("RETURN [1, 2] > false AS r")[0]["r"]
        assert isinstance(result, CypherNull)

    def test_in_after_bool_comparison_returns_correct_value(self):
        # ([1,2] < [3,4]) IN [[3,4], false] → true IN [[3,4], false] → false
        # [1,2] < [3,4] does lexicographic list comparison and returns true
        gf = GraphForge()
        result = gf.execute("RETURN ([1, 2] < [3, 4]) IN [[3, 4], false] AS r")[0]["r"]
        assert isinstance(result, CypherBool)
        assert result.value is False


@pytest.mark.integration
class TestSubscriptOnParenthesizedExpression:
    """Subscript access works on parenthesized expressions (list concatenation result)."""

    def test_subscript_on_concatenated_list(self):
        # ([[1], [2, 3], [4, 5]] + [5, [6, 7], [8, 9], 10])[3] = 5 (4th element)
        gf = GraphForge()
        result = gf.execute("RETURN ([[1], [2, 3], [4, 5]] + [5, [6, 7], [8, 9], 10])[3] AS r")[0][
            "r"
        ]
        assert isinstance(result, CypherInt)
        assert result.value == 5

    def test_subscript_precedence_over_concatenation(self):
        # [[1], [2,3], [4,5]] + [5, [6,7], [8,9], 10][3] = original list + 10
        gf = GraphForge()
        from graphforge.types.values import CypherList

        result = gf.execute("RETURN [[1], [2, 3], [4, 5]] + [5, [6, 7], [8, 9], 10][3] AS r")[0][
            "r"
        ]
        assert isinstance(result, CypherList)
        # Last element should be 10 (the element at index 3)
        assert result.value[-1].value == 10
