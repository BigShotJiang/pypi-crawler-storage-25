"""Integration tests for list concatenation via the + operator.

Covers issue #265 — list + list, list + element, element + list.
"""

import pytest

from graphforge.api import GraphForge
from graphforge.types.values import CypherNull


@pytest.fixture
def gf():
    return GraphForge()


class TestListPlusListConcatenation:
    """List + List → concatenated list."""

    def test_two_integer_lists(self, gf):
        results = gf.execute("RETURN [1, 2] + [3, 4] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, 2, 3, 4]

    def test_two_string_lists(self, gf):
        results = gf.execute("RETURN ['a', 'b'] + ['c'] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == ["a", "b", "c"]

    def test_empty_list_plus_list(self, gf):
        results = gf.execute("RETURN [] + [1, 2] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, 2]

    def test_list_plus_empty_list(self, gf):
        results = gf.execute("RETURN [1, 2] + [] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, 2]

    def test_two_empty_lists(self, gf):
        results = gf.execute("RETURN [] + [] AS r")
        assert results[0]["r"].value == []

    def test_mixed_type_lists(self, gf):
        results = gf.execute("RETURN [1, 'x'] + [true] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, "x", True]


class TestListElementAppendPrepend:
    """List + element and element + List."""

    def test_append_integer_to_list(self, gf):
        results = gf.execute("RETURN [1, 2] + 3 AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, 2, 3]

    def test_prepend_integer_to_list(self, gf):
        results = gf.execute("RETURN 0 + [1, 2] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [0, 1, 2]

    def test_append_string_to_list(self, gf):
        results = gf.execute("RETURN ['a', 'b'] + 'c' AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == ["a", "b", "c"]

    def test_prepend_string_to_list(self, gf):
        results = gf.execute("RETURN 'z' + ['a', 'b'] AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == ["z", "a", "b"]


class TestListConcatenationNullHandling:
    """NULL propagation for list concatenation."""

    def test_null_plus_list_returns_null(self, gf):
        results = gf.execute("RETURN null + [1, 2] AS r")
        assert isinstance(results[0]["r"], CypherNull)

    def test_list_plus_null_returns_null(self, gf):
        results = gf.execute("RETURN [1, 2] + null AS r")
        assert isinstance(results[0]["r"], CypherNull)


class TestListConcatenationInContext:
    """List concatenation used in larger queries."""

    def test_concatenation_in_with_projection(self, gf):
        results = gf.execute("WITH [1, 2] + [3] AS l RETURN size(l) AS s")
        assert results[0]["s"].value == 3

    def test_concatenation_with_variable(self, gf):
        results = gf.execute("WITH [1, 2] AS a, [3, 4] AS b RETURN a + b AS r")
        vals = [v.value for v in results[0]["r"].value]
        assert vals == [1, 2, 3, 4]

    @pytest.mark.parametrize(
        "query,expected",
        [
            ("RETURN [1] + [2] + [3] AS r", [1, 2, 3]),
            ("RETURN [] + [] + [1] AS r", [1]),
            ("RETURN [1] + 2 + [3] AS r", [1, 2, 3]),
            ("RETURN 1 + [2] + [3] AS r", [1, 2, 3]),
        ],
    )
    def test_chained_concatenation(self, gf, query, expected):
        results = gf.execute(query)
        vals = [v.value for v in results[0]["r"].value]
        assert vals == expected
