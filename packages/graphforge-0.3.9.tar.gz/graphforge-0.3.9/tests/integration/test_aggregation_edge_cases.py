"""Integration tests for aggregation edge cases.

Tests for edge cases in aggregation operations.
"""

import pytest

from graphforge import GraphForge
from graphforge.types.values import CypherNull


class TestAggregationEdgeCases:
    """Tests for aggregation edge cases."""

    def test_aggregation_with_empty_result_in_with(self):
        """WITH clause with aggregation over empty result set."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {value: 1})")

        # Match nothing, then aggregate in WITH
        results = gf.execute("""
            MATCH (n:NonExistent)
            WITH COUNT(n) AS count
            RETURN count
        """)

        # COUNT of empty set is 0
        assert len(results) == 1
        assert results[0]["count"].value == 0

    def test_aggregation_with_empty_result_sum_in_with(self):
        """WITH clause with SUM over empty result set."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {value: 1})")

        # Match nothing, then aggregate SUM in WITH
        results = gf.execute("""
            MATCH (n:NonExistent)
            WITH SUM(n.value) AS total
            RETURN total
        """)

        # SUM of empty set is NULL
        assert len(results) == 1
        assert isinstance(results[0]["total"], CypherNull)

    def test_multiple_aggregations_with_empty_result_in_with(self):
        """WITH clause with multiple aggregations over empty result."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {value: 1})")

        # Match nothing, aggregate multiple functions in WITH
        results = gf.execute("""
            MATCH (n:NonExistent)
            WITH COUNT(n) AS count, SUM(n.value) AS sum,
                 AVG(n.value) AS avg
            RETURN count, sum, avg
        """)

        assert len(results) == 1
        assert results[0]["count"].value == 0
        assert isinstance(results[0]["sum"], CypherNull)
        assert isinstance(results[0]["avg"], CypherNull)

    def test_aggregation_after_filter_produces_empty_in_with(self):
        """WITH aggregation when filter produces empty set."""
        gf = GraphForge()
        gf.execute("""
            CREATE (a:Person {age: 30}),
                   (b:Person {age: 40})
        """)

        # Filter that matches nothing, then aggregate
        results = gf.execute("""
            MATCH (p:Person)
            WHERE p.age > 100
            WITH COUNT(p) AS count, AVG(p.age) AS avg_age
            RETURN count, avg_age
        """)

        assert len(results) == 1
        assert results[0]["count"].value == 0

    def test_count_star_with_empty_result(self):
        """COUNT(*) over empty result set."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node)")

        results = gf.execute("""
            MATCH (n:NonExistent)
            RETURN COUNT(*) AS count
        """)

        assert len(results) == 1
        assert results[0]["count"].value == 0

    def test_aggregation_with_grouping_and_empty_result(self):
        """Aggregation with GROUP BY over empty result."""
        gf = GraphForge()
        gf.execute("""
            CREATE (a:Item {cat: 'A', val: 10})
        """)

        # Match nothing, group and aggregate
        results = gf.execute("""
            MATCH (i:Item)
            WHERE i.cat = 'NonExistent'
            RETURN i.cat AS category, COUNT(i) AS count, SUM(i.val) AS total
        """)

        # Empty grouping returns no rows
        assert len(results) == 0

    def test_min_max_with_empty_result(self):
        """MIN and MAX aggregations over empty result."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {value: 1})")

        results = gf.execute("""
            MATCH (n:NonExistent)
            RETURN MIN(n.value) AS min_val, MAX(n.value) AS max_val
        """)

        assert len(results) == 1
        # MIN/MAX of empty set should be NULL
        assert isinstance(results[0]["min_val"], CypherNull)
        assert isinstance(results[0]["max_val"], CypherNull)

    def test_avg_with_empty_result(self):
        """AVG aggregation over empty result set."""
        gf = GraphForge()
        gf.execute("CREATE (a:Node {value: 1})")

        results = gf.execute("""
            MATCH (n:NonExistent)
            RETURN AVG(n.value) AS avg_val
        """)

        assert len(results) == 1
        # AVG of empty set should be NULL
        assert isinstance(results[0]["avg_val"], CypherNull)

    def test_aggregation_with_all_null_values(self):
        """Aggregation when all values are NULL."""
        gf = GraphForge()
        gf.execute("""
            CREATE (a:Item), (b:Item), (c:Item)
        """)

        results = gf.execute("""
            MATCH (i:Item)
            RETURN SUM(i.missing_prop) AS sum_val,
                   AVG(i.missing_prop) AS avg_val,
                   MIN(i.missing_prop) AS min_val,
                   MAX(i.missing_prop) AS max_val,
                   COUNT(i.missing_prop) AS count_val
        """)

        assert len(results) == 1
        # Aggregations over NULL values:
        # COUNT should be 0 (doesn't count NULLs)
        # Others should be NULL
        assert results[0]["count_val"].value == 0
        assert isinstance(results[0]["sum_val"], CypherNull)
        assert isinstance(results[0]["avg_val"], CypherNull)
        assert isinstance(results[0]["min_val"], CypherNull)
        assert isinstance(results[0]["max_val"], CypherNull)

    def test_mixed_null_and_values_in_aggregation(self):
        """Aggregation with mix of NULL and real values."""
        gf = GraphForge()
        gf.execute("""
            CREATE (a:Item {value: 10}),
                   (b:Item {value: 20}),
                   (c:Item)
        """)

        results = gf.execute("""
            MATCH (i:Item)
            RETURN SUM(i.value) AS sum_val,
                   AVG(i.value) AS avg_val,
                   COUNT(i.value) AS count_val,
                   COUNT(i) AS count_all
        """)

        assert len(results) == 1
        # SUM and AVG skip NULL values
        assert results[0]["sum_val"].value == 30
        assert results[0]["avg_val"].value == 15.0
        # COUNT(i.value) counts non-NULL
        assert results[0]["count_val"].value == 2
        # COUNT(i) counts all nodes
        assert results[0]["count_all"].value == 3


class TestOrderByAggregationValidation:
    """Tests for compile-time validation of ORDER BY aggregation rules (#295)."""

    def test_order_by_agg_not_in_return_raises_invalid_aggregation(self):
        """ORDER BY with aggregate when RETURN has no aggregation → InvalidAggregation."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="InvalidAggregation"):
            gf.execute("MATCH (n) RETURN n.num1 ORDER BY max(n.num2)")

    def test_order_by_agg_not_in_with_raises_invalid_aggregation(self):
        """ORDER BY with aggregate when WITH has no aggregation → InvalidAggregation."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="InvalidAggregation"):
            gf.execute("MATCH (n) WITH n.num1 AS foo ORDER BY max(n.num2) RETURN foo")

    def test_order_by_with_undefined_variable_raises(self):
        """ORDER BY aggregate expression using unprojected variable → UndefinedVariable."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="UndefinedVariable"):
            gf.execute(
                "MATCH (me)--(you) RETURN count(you.age) AS agg ORDER BY me.age + count(you.age)"
            )

    def test_order_by_complex_non_agg_expr_raises_ambiguous(self):
        """ORDER BY aggregate mixed with complex non-aggregate expression → AmbiguousAggregationExpression."""
        gf = GraphForge()
        with pytest.raises(SyntaxError, match="AmbiguousAggregationExpression"):
            gf.execute(
                "MATCH (me)--(you) RETURN me.age + you.age, count(*) AS cnt "
                "ORDER BY me.age + you.age + count(*)"
            )

    def test_order_by_agg_with_projected_alias_is_valid(self):
        """ORDER BY using a projected alias alongside aggregation should not raise."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {age: 10})")
        gf.execute("CREATE (:Person {age: 20})")
        # Should not raise - age is a projected grouping alias
        results = gf.execute("MATCH (n:Person) RETURN n.age AS age, count(*) AS cnt ORDER BY age")
        assert len(results) == 2
        assert results[0]["age"].value == 10
        assert results[1]["age"].value == 20

    def test_order_by_using_alias_with_aggregate_is_valid(self):
        """ORDER BY using projected alias alongside aggregate should not raise."""
        gf = GraphForge()
        gf.execute("CREATE (:Person {age: 30})")
        results = gf.execute("MATCH (me:Person) RETURN me.age AS age, count(*) AS cnt ORDER BY age")
        assert len(results) == 1
        assert results[0]["age"].value == 30

    def test_order_by_different_aggregate_than_projected_variable_arg_raises(self):
        """ORDER BY aggregate using a non-grouping variable raises UndefinedVariable.

        WithOrderBy4[13]: ORDER BY sum(sum) when WITH projects min(sum) — the inner
        variable 'sum' is not a grouping key alias and must raise UndefinedVariable.
        """
        gf = GraphForge()
        gf.execute("CREATE (:A {num: 1, num2: 4})")
        with pytest.raises(SyntaxError, match="UndefinedVariable"):
            gf.execute(
                "MATCH (a:A) "
                "WITH a, a.num + a.num2 AS sum "
                "WITH a.num2 % 3 AS mod, min(sum) AS min "
                "ORDER BY sum(sum) LIMIT 2 "
                "RETURN mod, min"
            )

    def test_order_by_different_aggregate_than_projected_property_arg_raises(self):
        """ORDER BY aggregate using non-grouping property expression raises UndefinedVariable.

        WithOrderBy4[14]: ORDER BY sum(a.num + a.num2) when WITH projects
        min(a.num + a.num2) — the property arg uses 'a' which is not a grouping alias.
        """
        gf = GraphForge()
        gf.execute("CREATE (:A {num: 1, num2: 4})")
        with pytest.raises(SyntaxError, match="UndefinedVariable"):
            gf.execute(
                "MATCH (a:A) "
                "WITH a.num2 % 3 AS mod, min(a.num + a.num2) AS min "
                "ORDER BY sum(a.num + a.num2) LIMIT 2 "
                "RETURN mod, min"
            )

    def test_order_by_same_aggregate_as_projected_is_valid(self):
        """ORDER BY using the same aggregate expression as projected does not raise.

        WithOrderBy4[11]: ORDER BY sum(a.num + a.num2) when WITH projects
        sum(a.num + a.num2) AS sum is valid.
        """
        gf = GraphForge()
        gf.execute(
            "CREATE (:A {num: 1, num2: 4}), (:A {num: 5, num2: 2}), "
            "(:A {num: 9, num2: 0}), (:A {num: 3, num2: 3}), (:A {num: 7, num2: 1})"
        )
        results = gf.execute(
            "MATCH (a:A) "
            "WITH a.num2 % 3 AS mod, sum(a.num + a.num2) AS sum "
            "ORDER BY sum(a.num + a.num2) LIMIT 2 "
            "RETURN mod, sum"
        )
        assert len(results) == 2
        # mod=2 → sum=7 (one node: num=5,num2=2), mod=1 → sum=13 (num=1,num2=4 and num=7,num2=1)
        sums = {row["mod"].value: row["sum"].value for row in results}
        assert sums[2] == 7
        assert sums[1] == 13
