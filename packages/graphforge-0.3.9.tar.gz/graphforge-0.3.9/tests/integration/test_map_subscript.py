"""Integration tests for map subscript access m['key'] on CypherMap.

Covers issue #264 — bracket-operator dynamic value access on maps.
"""

import pytest

from graphforge.api import GraphForge
from graphforge.types.values import CypherNull


@pytest.fixture
def gf():
    return GraphForge()


class TestMapSubscriptBasic:
    """Basic map key access via bracket operator."""

    def test_static_key_access(self, gf):
        results = gf.execute("WITH {name: 'Alice', age: 30} AS m RETURN m['name'] AS n")
        assert results[0]["n"].value == "Alice"

    def test_dynamic_key_from_variable(self, gf):
        results = gf.execute("WITH {name: 'Alice'} AS m, 'name' AS k RETURN m[k] AS n")
        assert results[0]["n"].value == "Alice"

    def test_dynamic_key_from_expression(self, gf):
        results = gf.execute("WITH {name: 'Alice'} AS m RETURN m[toString('name')] AS n")
        assert results[0]["n"].value == "Alice"

    def test_missing_key_returns_null(self, gf):
        results = gf.execute("WITH {name: 'Alice'} AS m RETURN m['age'] AS n")
        assert isinstance(results[0]["n"], CypherNull)

    @pytest.mark.parametrize(
        "key,expected",
        [
            ("name", "Mats"),
            ("Name", "Pontus"),
            ("nAMe", None),
        ],
    )
    def test_key_access_case_sensitivity(self, gf, key, expected):
        results = gf.execute(f"WITH {{name: 'Mats', Name: 'Pontus'}} AS m RETURN m['{key}'] AS n")
        if expected is None:
            assert isinstance(results[0]["n"], CypherNull)
        else:
            assert results[0]["n"].value == expected


class TestMapSubscriptNullHandling:
    """NULL propagation for map subscript."""

    def test_null_map_returns_null(self, gf):
        results = gf.execute("WITH null AS m RETURN m['key'] AS n")
        assert isinstance(results[0]["n"], CypherNull)

    def test_null_key_returns_null(self, gf):
        results = gf.execute("WITH {name: 'Alice'} AS m, null AS k RETURN m[k] AS n")
        assert isinstance(results[0]["n"], CypherNull)


class TestMapSubscriptChained:
    """Map subscript in multi-step queries."""

    def test_subscript_after_with_projection(self, gf):
        results = gf.execute("WITH {a: 1, b: 2} AS m WITH m['a'] AS val RETURN val")
        assert results[0]["val"].value == 1

    def test_subscript_result_used_in_where(self, gf):
        gf.execute("CREATE (:P {x: 10}), (:P {x: 20})")
        results = gf.execute(
            "MATCH (n:P) WITH {val: n.x} AS m WHERE m['val'] > 15 RETURN m['val'] AS v"
        )
        assert len(results) == 1
        assert results[0]["v"].value == 20


class TestMapSubscriptErrors:
    """Error cases for map subscript."""

    def test_integer_key_raises_type_error(self, gf):
        with pytest.raises(TypeError, match="string"):
            gf.execute("WITH {name: 'Alice'} AS m RETURN m[0] AS n")

    def test_non_map_non_list_raises_type_error(self, gf):
        with pytest.raises(TypeError):
            gf.execute("WITH 100 AS x RETURN x[0] AS n")
