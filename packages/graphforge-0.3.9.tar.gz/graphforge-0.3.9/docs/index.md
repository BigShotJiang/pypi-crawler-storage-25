# GraphForge

**An embedded, openCypher-compatible graph database for Python**

[![PyPI](https://img.shields.io/pypi/v/graphforge.svg)](https://pypi.org/project/graphforge/)
[![Python](https://img.shields.io/pypi/pyversions/graphforge.svg)](https://pypi.org/project/graphforge/)
[![Tests](https://github.com/DecisionNerd/graphforge/workflows/Test%20Suite/badge.svg)](https://github.com/DecisionNerd/graphforge/actions)
[![Coverage](https://codecov.io/gh/DecisionNerd/graphforge/graph/badge.svg)](https://codecov.io/gh/DecisionNerd/graphforge)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/DecisionNerd/graphforge/blob/main/LICENSE)

GraphForge lets you write openCypher queries against an in-memory or SQLite-backed graph with no external services. As of v0.3.9 it passes **all 3,885 openCypher TCK scenarios**.

```python
from graphforge import GraphForge

db = GraphForge()                           # in-memory
# db = GraphForge("path/to/graph.db")      # or persistent

db.execute("""
    CREATE (a:Person {name: 'Alice', age: 30})
    CREATE (b:Person {name: 'Bob',   age: 25})
    CREATE (a)-[:KNOWS {since: 2020}]->(b)
""")

for row in db.execute("""
    MATCH (p:Person)-[:KNOWS]->(friend)
    RETURN p.name AS person, friend.name AS friend
"""):
    print(row['person'].value, '→', row['friend'].value)
# Alice → Bob
```

---

## Getting Started

| | |
|---|---|
| [Installation](getting-started/installation.md) | Install via pip or uv |
| [Quick Start](getting-started/quickstart.md) | Your first graph in five minutes |
| [Tutorial](getting-started/tutorial.md) | Step-by-step guided walkthrough |

---

## User Guide

| | |
|---|---|
| [Cypher Reference](guide/cypher-guide.md) | Full openCypher language guide |
| [Graph Construction](guide/graph-construction.md) | Build graphs with Python API and Cypher |
| [Datasets](datasets/overview.md) | Load 100+ real-world networks |

---

## Use Cases

| | |
|---|---|
| [Knowledge Graph Construction](use-cases/knowledge-graph-construction.md) | Extract entities from text, build and refine ontologies |
| [Network Analysis](use-cases/network-analysis.md) | Degree, paths, communities — in notebooks |
| [LLM-Powered Workflows](use-cases/llm-workflows.md) | Store LLM extractions, build retrieval context |
| [AI Agent Tool Recall](use-cases/agent-tool-recall.md) | Graph-structured tool libraries for LLM agents |
| [Agent Grounding](use-cases/agent-grounding.md) | Ground agents in domain ontologies |

---

## Reference

| | |
|---|---|
| [API Reference](reference/api.md) | Python API documentation |
| [OpenCypher Compatibility](reference/opencypher-compatibility.md) | Feature matrix — v0.3.9 (100%) |
| [TCK Compliance](reference/tck-compliance.md) | 3,885 / 3,885 passing |
| [Changelog](reference/changelog.md) | Release history |

---

## Design Principles

1. **Correctness over performance** — openCypher semantics verified against the full TCK
2. **Zero configuration** — `pip install graphforge`, no servers, no connection strings
3. **Inspectable** — plain SQLite storage, readable with any SQLite tool
4. **Python-first** — results are Python objects; integrates naturally with pandas, NetworkX, LLM libraries
