# GraphForge Roadmap

**Last Updated:** 2026-05-04
**Current Version:** 0.3.9 (in progress)

---

## Released

### v0.3.8 — Full TCK Compliance
- 3,885/3,885 openCypher TCK scenarios passing (zero failures, zero expected failures)
- First embedded Python graph database with complete openCypher TCK compliance
- Full Cypher language support: MATCH, WHERE, RETURN, CREATE, SET, REMOVE, DELETE, MERGE, UNWIND, WITH, ORDER BY, SKIP, LIMIT, OPTIONAL MATCH, variable-length paths, pattern comprehension, temporal types, all standard functions

---

## In Progress

### v0.3.9 — Performance
**Theme:** Maximize the performance of the v0.3.x feature set — O(n) parsing, node/edge indexes, bulk ingestion, SQLite durability tuning, and LIMIT short-circuit.

| Area | Work | PR |
|------|------|----|
| LALR(1) parser migration | Linear-time parsing, unknown function detection | #430 |
| Property equality index | O(1) node lookup by property value | #427 |
| LIMIT short-circuit | Traversal stops at demand; UNWIND + WITH LIMIT optimised | #423, #443 |
| Bulk ingestion API | `create_node_bulk`, `bulk_ingest()` context manager | #444 |
| SQLite PRAGMA tuning | `synchronous=NORMAL`, 64 MB cache, `temp_store=MEMORY` | #446 |
| Recursion limit fix | `sys.setrecursionlimit` thread-safe, set once at init | #445 |
| `elementId()` function | GQL-spec string form of element identity | #447 |
| Test suite renovation | Zero-base fixture audit, marker consistency, parametrization | #438 |
| Perf baseline suite | Real-dataset benchmarks (S/M/L/XL tiers), v0.3.8→v0.3.9 delta | #441 |

**Release criteria:** All required items in [#387](https://github.com/DecisionNerd/graphforge/issues/387) met. Version bump + CHANGELOG promotion pending.

---

## Planned

### v0.3.10 — Analytics Integration
**Theme:** Bridge GraphForge to the Python analytics ecosystem. Export graphs directly to NetworkX and igraph; add a parse/plan cache to eliminate repeated parse overhead in notebook loops.

| Issue | Scope |
|-------|-------|
| [#391](https://github.com/DecisionNerd/graphforge/issues/391) | `gf.to_networkx()` and `gf.to_igraph()` with optional subgraph filtering; available as `graphforge[networkx]` / `graphforge[igraph]` extras |
| (stretch) | Parse/plan LRU cache, `GraphForge(cache_size=128)` |

Release tracker: [#448](https://github.com/DecisionNerd/graphforge/issues/448)

---

### v0.4.0 — Native SNA Algorithms
**Theme:** Bring core social network analysis algorithms into GraphForge as first-class `CALL` procedures, composable with Cypher `MATCH`/`RETURN`. Eliminates the need to export for common analytical tasks.

| Procedure | Algorithm |
|-----------|-----------|
| `CALL gf.algo.pageRank(...)` | Iterative PageRank |
| `CALL gf.algo.betweenness()` | Betweenness centrality |
| `CALL gf.algo.degree(...)` | Degree centrality (in/out) |
| `CALL gf.algo.wcc()` | Weakly connected components |
| `CALL gf.algo.scc()` | Strongly connected components (Tarjan's) |
| `CALL gf.algo.shortestPath(a, b)` | Dijkstra single-pair |
| `CALL gf.algo.bfs(start, ...)` | BFS / DFS traversal |

All procedures support `{nodeLabel, relationshipType, direction}` scoping. Results are Cypher result sets, composable with `YIELD` + `MATCH`/`RETURN`.

Release tracker: [#394](https://github.com/DecisionNerd/graphforge/issues/394)

---

### v1.0 — Production-Ready
**Theme:** Thread safety, large graph support, query plan visibility, operator streaming.

- Thread-safe `GraphForge` instances (connection pooling or per-thread graphs)
- Operator streaming pipeline (row-at-a-time, bounded memory)
- `EXPLAIN` / `PROFILE` query plan output
- Large graph support (> 20M edges)
- Stable, versioned public API

---

## Version Numbering

GraphForge follows [Semantic Versioning](https://semver.org/):

- **Patch** (`0.3.x`): Bug fixes, small improvements, no API changes
- **Minor** (`0.x.0`): New features, backwards-compatible API additions
- **Major** (`x.0.0`): Breaking API changes (first stable API at v1.0)

Pre-1.0, minor versions (`0.3 → 0.4`) may contain small breaking changes with clear migration notes in the CHANGELOG.
