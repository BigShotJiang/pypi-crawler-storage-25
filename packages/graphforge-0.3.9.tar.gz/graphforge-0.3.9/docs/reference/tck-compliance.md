# GraphForge TCK Compliance — v0.3.9

## Status: 3,885 / 3,885 passing (100%)

As of **v0.3.9 (2026-05-04)**, GraphForge passes all 3,885 openCypher TCK scenarios with:
- **0 failures**
- **0 expected failures (xfails)**
- **0 skipped**

This is the first GraphForge release to achieve complete openCypher TCK compliance.

## Regression Floor Policy

The TCK baseline is frozen at 3,885 passing / 0 failing as of v0.3.9.

Any PR that introduces a TCK regression (previously-passing test now fails) must either:
1. Fix the regression before merge, or
2. Open a tracking issue and mark the test as `xfail` with a documented reason

PRs that improve TCK compliance (new scenarios passing) are always welcome.

## Known Limitations

None in the TCK-covered scenarios as of v0.3.9.

The following areas are **not covered** by the openCypher TCK but have known limitations:

| Area | Limitation | Issue |
|------|------------|-------|
| Variable-length pattern edge uniqueness (cross-hop) | Multi-segment patterns may reuse edges | #382 |
| Relationship predicates in var-length patterns | Thread-through not fully implemented | #381 |
| `elementId()` function | Not implemented | #211 |

## Compliance History

| Version | TCK Passing | TCK Failing | Notes |
|---------|-------------|-------------|-------|
| v0.3.0  | 638         | 3,247       | Error validation complete |
| v0.3.6  | 2,507       | 1,378       | Core clause coverage |
| v0.3.7  | 3,235       | 650         | Sorting, aggregation, temporals |
| v0.3.9  | 3,885       | 0           | **Full compliance** |

## Test Infrastructure

TCK tests live in `tests/tck/`:
- `features/` — Gherkin `.feature` files from the openCypher TCK repository
- `steps/` — pytest-bdd step definitions
- `conftest.py` — fixture setup, graph initialization, result comparison helpers

Run the full TCK suite:
```bash
uv run pytest tests/tck/ -n auto
```

Run a specific feature:
```bash
uv run pytest tests/tck/ -k "Temporal"
```
