# Installation

## Requirements

Python 3.10 or newer (3.10–3.14 are all tested in CI).

## Install

```bash
# pip
pip install graphforge

# uv (recommended)
uv add graphforge
```

## Verify

```python
import graphforge
print(graphforge.__version__)   # 0.3.9
```

## Optional dependencies

```bash
# Zstandard compression for LDBC .tar.zst datasets
pip install zstandard
```

## Install from source

```bash
git clone https://github.com/DecisionNerd/graphforge.git
cd graphforge
uv sync --dev        # installs dev + test dependencies
make pre-push        # verify everything passes locally
```

## Next steps

- [Quick Start](quickstart.md) — build your first graph in five minutes
- [Tutorial](tutorial.md) — step-by-step guided walkthrough
