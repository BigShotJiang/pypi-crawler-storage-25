# Quick Start

Get a graph running in five minutes.

## Install

```bash
pip install graphforge
# or
uv add graphforge
```

## Create and Query a Graph

```python
from graphforge import GraphForge

db = GraphForge()   # in-memory; use GraphForge("graph.db") for persistence

# Create nodes and a relationship
db.execute("""
    CREATE (alice:Person {name: 'Alice', age: 30})
    CREATE (bob:Person   {name: 'Bob',   age: 25})
    CREATE (alice)-[:KNOWS {since: 2020}]->(bob)
""")

# Match and return results
results = db.execute("""
    MATCH (p:Person)-[:KNOWS]->(friend:Person)
    WHERE p.age > 25
    RETURN p.name AS person, friend.name AS friend, p.age AS age
    ORDER BY p.age DESC
""")

for row in results:
    print(f"{row['person'].value} (age {row['age'].value}) knows {row['friend'].value}")
# Alice (age 30) knows Bob
```

Results are `CypherValue` objects — use `.value` to get the Python value.

## Persist a Graph

```python
# Write to SQLite
db = GraphForge("research.db")
db.execute("CREATE (:Paper {title: 'Graph Neural Networks', year: 2024})")
db.close()

# Reload later
db = GraphForge("research.db")
result = db.execute("MATCH (p:Paper) RETURN p.title AS t")
print(result[0]['t'].value)   # Graph Neural Networks
```

## Build with the Python API

```python
alice = db.create_node(['Person', 'Employee'], name='Alice', age=30)
bob   = db.create_node(['Person'],             name='Bob',   age=25)
db.create_relationship(alice, bob, 'KNOWS', since=2020)
```

## Load a Real-World Dataset

```python
from graphforge import GraphForge
from graphforge.datasets import load_dataset, list_datasets

db = GraphForge()
load_dataset(db, "snap-ego-facebook")   # downloads and caches automatically

results = db.execute("""
    MATCH (n)-[r]->()
    RETURN n.id AS user, count(r) AS degree
    ORDER BY degree DESC LIMIT 5
""")

for row in results:
    print(f"User {row['user'].value}: {row['degree'].value} connections")
```

Browse available datasets:

```python
for ds in list_datasets(source="snap")[:5]:
    print(f"{ds.name}: {ds.nodes:,} nodes, {ds.edges:,} edges")
```

## Transactions

```python
db = GraphForge("graph.db")

db.begin()
try:
    db.execute("MATCH (p:Person {id: 123}) SET p.status = 'inactive'")
    db.execute("CREATE (:AuditLog {action: 'deactivate', user_id: 123})")
    db.commit()
except Exception:
    db.rollback()
    raise
finally:
    db.close()
```

## Next Steps

- [Tutorial](tutorial.md) — guided walkthrough with a full social network example
- [Cypher Reference](../guide/cypher-guide.md) — complete query language documentation
- [Datasets](../datasets/overview.md) — 100+ real-world networks
- [API Reference](../reference/api.md) — full Python API
