"""Clone git repositories and keep repo directories organized."""

import argparse
import logging
import os
import subprocess
import urllib.parse
from importlib.metadata import version

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)


def clone(git_url: str, repohome: str, dry_run: bool = False) -> None:
    """Clone git URL to a specified root directory."""
    clone_path: str = _get_clone_directory(repohome, git_url)
    if os.path.isdir(clone_path):
        print(f"Directory '{clone_path}' already exists.")
        return

    if dry_run:
        print(f"Would clone into '{clone_path}'.")
        return

    os.makedirs(clone_path)
    git_cmd = 'git', 'clone', git_url, clone_path
    clone_result = subprocess.run(git_cmd, capture_output=True)
    if clone_result.returncode != 0:
        logger.error("git clone failed: %s", clone_result.stderr.decode(errors='replace'))
        os.rmdir(clone_path)


def _get_clone_directory(repohome: str, git_url: str) -> str:
    """Return directory path, where the repo should be cloned."""
    url = urllib.parse.urlparse(git_url)
    if not url.scheme and not url.netloc and '@' in git_url and ':' in git_url:
        # SCP-style SSH URL: git@host:user/repo.git
        user_host, scp_path = git_url.split(':', 1)
        host = user_host.split('@').pop()
        path_dirname = _lstrip_git_url(scp_path)
        return os.path.join(repohome, host, path_dirname)

    path_dirname = _lstrip_git_url(url.path.lstrip('/'))
    # url.hostname strips username and port (e.g. user@host:22 -> host); None
    # when no netloc
    return os.path.join(repohome, url.hostname or '', path_dirname)


def _lstrip_git_url(url_path):
    """Remove known superfluous suffixes from URL path."""
    for suffix in ['/', '.git']:
        url_path = url_path.removesuffix(suffix)
    return url_path


def _parseargs() -> argparse.Namespace:
    """Parse command line arguments"""
    argdef = argparse.ArgumentParser(description="Clone a git URL")
    argdef.add_argument('git_url', help="git URL to be cloned")
    argdef.add_argument('--repohome',
                        default=os.path.expanduser('~/ref'),
                        help="Root directory, where to keep git repos.")
    argdef.add_argument('-n', '--dry-run', action='store_true',
                        help="Show clone directory without cloning.")
    argdef.add_argument('-v', '--verbose', action='store_true',
                        help="Enable debug logging.")
    argdef.add_argument('--version', action='version',
                        version=f'%(prog)s {version("refclone")}')

    return argdef.parse_args()


def run():
    """Provide entry point for setuptools."""
    args = _parseargs()
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    clone(args.git_url, args.repohome, dry_run=args.dry_run)
