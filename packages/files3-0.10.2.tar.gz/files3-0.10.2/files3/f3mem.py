"""
f3mem.py
~~~~~~~~

基于 OS 共享内存的 files3 内存版后端。
零 socket、零磁盘 IO、跨进程、重启丢失。

虚拟磁盘模式改进：
- 首次使用时自动启动全局后台守护进程 f3m，持续持有所有共享内存引用
- 用户进程退出仅 close 句柄，不 unlink，数据保留到系统重启
- 索引区自动扩容（目录块 + 动态索引块）
- 支持 TTL 惰性过期
"""
import sys
import struct
import pickle
import hashlib
import re
import time
import os
import atexit
import subprocess
import cloudpickle
from multiprocessing import shared_memory

from files3.f3bool import F3Bool, F3True, F3False
from files3.f3bool import CannotSaveError, CSEInst
from files3.f3info import PF_DTYPE
from files3.interface import F3Backend


# ==================== 常量 ====================
_DIR_NAME = 'f3mem_dir_v1'
_DIR_SIZE = 4096
_INIT_IDX_SIZE = 2 * 1024 * 1024
_IDX_GROWTH = 2
_MUTEX_NAME = 'f3mem_mtx'
_OLD_IDX_NAME = 'f3mem_idx_v1'
_BEACON_NAME = 'f3mem_beacon_v1'
_DAEMON_START_TIMEOUT = 5

# 模块级全局：持久持有活跃数据块引用，防止 GC/finalizer 关闭句柄
# releaseAll() 不清理此字典，确保虚拟磁盘语义
_LIVE_BLOCKS = {}


# ==================== 跨进程锁 ====================
if sys.platform == 'win32':
    import ctypes

    class _NamedMutex:
        def __init__(self, name):
            self._name = name
            self._handle = None

        def __enter__(self):
            self._handle = ctypes.windll.kernel32.CreateMutexW(None, False, self._name)
            if not self._handle:
                raise ctypes.WinError(ctypes.get_last_error())
            _ret = ctypes.windll.kernel32.WaitForSingleObject(self._handle, 0xFFFFFFFF)
            if _ret not in (0, 0x80):
                raise RuntimeError(f"WaitForSingleObject failed: {_ret:#x}")
            return self

        def __exit__(self, *args):
            ctypes.windll.kernel32.ReleaseMutex(self._handle)
            ctypes.windll.kernel32.CloseHandle(self._handle)
            self._handle = None
else:
    import fcntl

    class _NamedMutex:
        def __init__(self, name):
            self._path = f"/tmp/{name}.lock"
            self._fd = None

        def __enter__(self):
            self._fd = open(self._path, 'w')
            fcntl.flock(self._fd.fileno(), fcntl.LOCK_EX)
            return self

        def __exit__(self, *args):
            fcntl.flock(self._fd.fileno(), fcntl.LOCK_UN)
            self._fd.close()
            self._fd = None


# ==================== 序列化 ====================
def _MemDumps(obj):
    if isinstance(obj, F3Bool):
        raise CSEInst
    return cloudpickle.dumps(obj, protocol=5)


def _MemLoads(data):
    return pickle.loads(data)


# ==================== 守护进程代码（内嵌，通过 subprocess -c 启动）====================
# 守护进程自包含，不引用当前模块的任何变量/类
_DAEMON_CODE = r"""
import os, sys, struct, time, pickle
from multiprocessing import shared_memory

_DIR_NAME = 'f3mem_dir_v1'
_DIR_SIZE = 4096
_INIT_IDX_SIZE = 2097152
_BEACON_NAME = 'f3mem_beacon_v1'


def _read_dir(shm):
    buf = shm.buf
    nl = struct.unpack('!I', buf[:4])[0]
    if nl == 0 or nl > 256:
        return 'f3mem_idx_0', _INIT_IDX_SIZE
    name = bytes(buf[4:4 + nl]).decode('utf-8')
    sz = struct.unpack('!I', buf[4 + nl:8 + nl])[0]
    return name, sz


def _read_index(idx_shm):
    sz = struct.unpack('!I', idx_shm.buf[:4])[0]
    if sz:
        return pickle.loads(idx_shm.buf[4:4 + sz])
    return {}


# 信标：存 PID + ready 状态
_beacon = None
for _ in range(5):
    try:
        _beacon = shared_memory.SharedMemory(name=_BEACON_NAME, create=True, size=_DIR_SIZE)
        break
    except FileExistsError:
        try:
            _beacon = shared_memory.SharedMemory(name=_BEACON_NAME)
            break
        except FileNotFoundError:
            time.sleep(0.1)

if _beacon is None:
    sys.exit(1)

_beacon.buf[:4] = struct.pack('!I', os.getpid())
_beacon.buf[4:8] = struct.pack('!I', 0)

# 目录块
_dir_shm = None
for _ in range(5):
    try:
        _dir_shm = shared_memory.SharedMemory(name=_DIR_NAME, create=True, size=_DIR_SIZE)
        nb = b'f3mem_idx_0'
        _dir_shm.buf[:4] = struct.pack('!I', len(nb))
        _dir_shm.buf[4:4 + len(nb)] = nb
        _dir_shm.buf[4 + len(nb):8 + len(nb)] = struct.pack('!I', _INIT_IDX_SIZE)
        break
    except FileExistsError:
        try:
            _dir_shm = shared_memory.SharedMemory(name=_DIR_NAME)
            break
        except FileNotFoundError:
            time.sleep(0.1)

if _dir_shm is None:
    sys.exit(1)

# 初始索引块
_idx_name, _idx_size = _read_dir(_dir_shm)
_idx_shm = None
for _ in range(5):
    try:
        _idx_shm = shared_memory.SharedMemory(name=_idx_name, create=True, size=_idx_size)
        _idx_shm.buf[:4] = b'\x00\x00\x00\x00'
        break
    except FileExistsError:
        try:
            _idx_shm = shared_memory.SharedMemory(name=_idx_name)
            break
        except FileNotFoundError:
            time.sleep(0.1)

if _idx_shm is None:
    sys.exit(1)

_cur_name = _idx_name
_data_refs = {}
_last_ver = None
_beacon.buf[4:8] = struct.pack('!I', 1)

while True:
    _skip = False
    try:
        name, sz = _read_dir(_dir_shm)
        if name != _cur_name:
            if _idx_shm is not None:
                try:
                    _idx_shm.close()
                except Exception:
                    pass
            _idx_shm = None
            for _ in range(5):
                try:
                    _idx_shm = shared_memory.SharedMemory(name=name)
                    break
                except FileNotFoundError:
                    try:
                        _idx_shm = shared_memory.SharedMemory(name=name, create=True, size=sz)
                        _idx_shm.buf[:4] = b'\x00\x00\x00\x00'
                        break
                    except FileExistsError:
                        time.sleep(0.1)
            _cur_name = name
            _last_ver = None

        if _idx_shm is not None:
            # 快速版本号检查：索引未变更时跳过 scan
            buf = _idx_shm.buf
            if len(buf) >= 8:
                try:
                    _magic = struct.unpack('!I', buf[-4:])[0]
                    if _magic == 0xF3F3F3F3:
                        _ver = struct.unpack('!I', buf[-8:-4])[0]
                        if _ver == _last_ver:
                            _skip = True
                        else:
                            _last_ver = _ver
                except Exception:
                    pass

            if not _skip:
                try:
                    cache = _read_index(_idx_shm)
                    current_names = set()
                    for rec in cache.values():
                        if isinstance(rec, (tuple, list)) and len(rec) >= 2:
                            dname = rec[0]
                            current_names.add(dname)
                            if dname not in _data_refs:
                                try:
                                    _data_refs[dname] = shared_memory.SharedMemory(name=dname)
                                except FileNotFoundError:
                                    pass
                    for dname in list(_data_refs.keys()):
                        if dname not in current_names:
                            try:
                                _data_refs[dname].close()
                            except Exception:
                                pass
                            del _data_refs[dname]
                except Exception:
                    pass
    except Exception:
        pass
    time.sleep(0.2 if _skip else 0.05)
"""


# ==================== 守护进程管理 ====================
def _isProcessAlive(pid):
    if pid <= 0:
        return False
    if sys.platform == 'win32':
        import ctypes
        _kernel32 = ctypes.windll.kernel32
        _handle = _kernel32.OpenProcess(0x1000, False, pid)
        if not _handle:
            return False
        _kernel32.CloseHandle(_handle)
        return True
    else:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False


def _spawnDaemon():
    if sys.platform == 'win32':
        _si = subprocess.STARTUPINFO()
        _si.dwFlags = subprocess.STARTF_USESHOWWINDOW
        _si.wShowWindow = 0
        subprocess.Popen(
            [sys.executable, '-c', _DAEMON_CODE],
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            startupinfo=_si,
        )
    else:
        subprocess.Popen(
            [sys.executable, '-c', _DAEMON_CODE],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def _ensureDaemon():
    """确保全局守护进程 f3m 正在运行；若未运行则在锁保护下启动。"""
    # 快速路径
    try:
        _beacon = shared_memory.SharedMemory(name=_BEACON_NAME)
        _pid = struct.unpack('!I', _beacon.buf[:4])[0]
        _status = struct.unpack('!I', _beacon.buf[4:8])[0]
        _beacon.close()
        if _status == 1 and _isProcessAlive(_pid):
            return
    except FileNotFoundError:
        pass

    _lock = _NamedMutex('f3mem_daemon_mtx')
    with _lock:
        # 双重检查
        try:
            _beacon = shared_memory.SharedMemory(name=_BEACON_NAME)
            _pid = struct.unpack('!I', _beacon.buf[:4])[0]
            _status = struct.unpack('!I', _beacon.buf[4:8])[0]
            _beacon.close()
            if _status == 1 and _isProcessAlive(_pid):
                return
        except FileNotFoundError:
            pass

        _spawnDaemon()

        # 轮询等待守护进程就绪
        for _ in range(_DAEMON_START_TIMEOUT * 10):
            time.sleep(0.1)
            try:
                _beacon = shared_memory.SharedMemory(name=_BEACON_NAME)
                _status = struct.unpack('!I', _beacon.buf[4:8])[0]
                _beacon.close()
                if _status == 1:
                    return
            except FileNotFoundError:
                continue
        raise RuntimeError("f3m daemon failed to start within 5 seconds")


# ==================== 共享内存索引（支持自动扩容与 TTL）====================
class _MemIndex:
    def __init__(self):
        _ensureDaemon()
        self._dirShm = self._openDir()
        self._lock = _NamedMutex(_MUTEX_NAME)
        self._refs = {}
        self._idxShm = None
        self._idxSize = 0
        self._attachIndex()

    # ---- 目录块（只 attach，由守护进程创建并持久持有）----
    def _openDir(self):
        try:
            return shared_memory.SharedMemory(name=_DIR_NAME)
        except FileNotFoundError:
            raise RuntimeError(
                "f3mem directory shared memory not found. "
                "The f3m daemon may not be ready yet."
            )

    def _readDir(self, shm=None):
        _shm = shm or self._dirShm
        _buf = _shm.buf
        _nameLen = struct.unpack('!I', _buf[:4])[0]
        if _nameLen == 0 or _nameLen > 256:
            return 'f3mem_idx_0', _INIT_IDX_SIZE
        _name = bytes(_buf[4:4 + _nameLen]).decode('utf-8')
        _size = struct.unpack('!I', _buf[4 + _nameLen:8 + _nameLen])[0]
        return _name, _size

    def _writeDir(self, shm, name, size):
        _buf = shm.buf
        _nameBytes = name.encode('utf-8')
        _buf[:4] = struct.pack('!I', len(_nameBytes))
        _buf[4:4 + len(_nameBytes)] = _nameBytes
        _buf[4 + len(_nameBytes):8 + len(_nameBytes)] = struct.pack('!I', size)
        _rest = 8 + len(_nameBytes)
        if _rest < _DIR_SIZE:
            _buf[_rest:_DIR_SIZE] = b'\x00' * (_DIR_SIZE - _rest)

    # ---- 索引块动态 attach（只 attach，不 create）----
    def _attachIndex(self):
        if self._idxShm is not None:
            try:
                self._idxShm.close()
            except Exception:
                pass
        _idxName, _idxSize = self._readDir()
        try:
            self._idxShm = shared_memory.SharedMemory(name=_idxName)
        except FileNotFoundError:
            raise RuntimeError(
                f"Index block '{_idxName}' not found. "
                f"f3m daemon may have crashed or not finished initialization."
            )
        self._idxSize = _idxSize

    def _read(self):
        _sz = struct.unpack('!I', self._idxShm.buf[:4])[0]
        if _sz and _sz <= self._idxSize - 4:
            return pickle.loads(self._idxShm.buf[4:4 + _sz])
        return {}

    def _write(self, cache):
        _data = pickle.dumps(cache, protocol=5)
        if len(_data) > self._idxSize - 4:
            self._growIndex(len(_data))
        self._idxShm.buf[:4] = struct.pack('!I', len(_data))
        self._idxShm.buf[4:4 + len(_data)] = _data
        # 通知守护进程索引已变更：在 buf 末尾写入版本号 + magic
        _ver = (getattr(self, '_ver_counter', 0) + 1) & 0xFFFFFFFF
        self._ver_counter = _ver
        _off = self._idxSize - 8
        self._idxShm.buf[_off:_off + 4] = struct.pack('!I', _ver)
        self._idxShm.buf[_off + 4:_off + 8] = struct.pack('!I', 0xF3F3F3F3)

    def _growIndex(self, neededSize):
        """在锁保护下扩容索引区。"""
        with self._lock:
            # 双重检查
            self._attachIndex()
            _cache = self._read()
            _data = pickle.dumps(_cache, protocol=5)
            if len(_data) <= self._idxSize - 4:
                return

            _newSize = max(self._idxSize * _IDX_GROWTH, neededSize + 4 + 65536)
            _newName = f"f3mem_idx_{os.getpid()}_{int(time.time() * 1000) % 10000000}"

            _newShm = shared_memory.SharedMemory(name=_newName, create=True, size=_newSize)
            # 复制旧数据
            _oldLen = struct.unpack('!I', self._idxShm.buf[:4])[0]
            _newShm.buf[:4] = self._idxShm.buf[:4]
            if _oldLen:
                _newShm.buf[4:4 + _oldLen] = self._idxShm.buf[4:4 + _oldLen]

            # 更新目录
            _oldName, _ = self._readDir()
            self._writeDir(self._dirShm, _newName, _newSize)

            # unlink 旧索引块（守护进程仍持有，失败无妨）
            try:
                _oldShm = shared_memory.SharedMemory(name=_oldName)
                _oldShm.close()
                _oldShm.unlink()
            except Exception:
                pass

            self._idxShm.close()
            self._idxShm = _newShm
            self._idxSize = _newSize

    # ---- 带 TTL 的 CRUD ----
    def get(self, key):
        with self._lock:
            _cache = self._read()
            _rec = _cache.get(key)
            if _rec is None:
                return None
            # 兼容旧格式: (shmname, size) 或 (shmname, size, expire_at)
            if len(_rec) >= 3 and _rec[2] is not None and time.time() > _rec[2]:
                self._dropRecord(_cache, key, _rec, _write=False)
                self._write(_cache)
                return None
            return _rec

    def set(self, key, shmname, size, ttl=None, shm=None):
        with self._lock:
            _cache = self._read()
            _old = _cache.get(key)
            if _old:
                self._dropRecord(_cache, key, _old, _write=False)
            _expireAt = time.time() + ttl if ttl else None
            _cache[key] = (shmname, size, _expireAt)
            self._write(_cache)
        if shm is not None:
            self.hold(shmname, shm)

    def delete(self, key):
        with self._lock:
            _cache = self._read()
            _rec = _cache.get(key)
            if _rec is None:
                return False
            self._dropRecord(_cache, key, _rec, _write=False)
            self._write(_cache)
            return True

    def keys(self):
        with self._lock:
            _cache = self._read()
            _now = time.time()
            _expired = []
            for _k, _rec in list(_cache.items()):
                if len(_rec) >= 3 and _rec[2] is not None and _now > _rec[2]:
                    _expired.append((_k, _rec))
            if _expired:
                for _k, _rec in _expired:
                    self._dropRecord(_cache, _k, _rec, _write=False)
                self._write(_cache)
            return list(_cache.keys())

    def clear(self):
        with self._lock:
            _cache = self._read()
            for _k, _rec in list(_cache.items()):
                self._dropRecord(_cache, _k, _rec, _write=False)
            _cache.clear()
            self._write(_cache)

    def _dropRecord(self, cache, key, rec, *, _write=True):
        """从 cache 中移除 key，并 unlink 对应的数据块共享内存。"""
        if key in cache:
            del cache[key]
        if rec:
            _shmname = rec[0]
            self.release(_shmname)
            # 清理 _LIVE_BLOCKS 中的持久引用
            _live = _LIVE_BLOCKS.pop(_shmname, None)
            if _live is not None:
                try:
                    _live.close()
                except Exception:
                    pass
            try:
                _s = shared_memory.SharedMemory(name=_shmname)
                _s.close()
                _s.unlink()
            except Exception:
                pass
        if _write:
            self._write(cache)

    def hold(self, name, shm):
        self._refs[name] = shm
        # 为持久化单独再 attach 一次，避免 _refs.close() 关闭同一对象的句柄
        try:
            _LIVE_BLOCKS[name] = shared_memory.SharedMemory(name=name)
        except FileNotFoundError:
            pass

    def release(self, name):
        if name in self._refs:
            self._refs[name].close()
            del self._refs[name]
        # 旧块（覆盖/删除）不立即清理 _LIVE_BLOCKS，由守护进程在索引轮询后释放

    def releaseAll(self):
        """仅关闭本进程持有的共享内存引用，绝不 unlink 全局段（由守护进程持久持有）。
        活跃数据块引用保存在模块级 _LIVE_BLOCKS 中，防止 GC 关闭句柄。"""
        for _shm in list(self._refs.values()):
            try:
                _shm.close()
            except Exception:
                pass
        self._refs.clear()
        if self._idxShm is not None:
            try:
                self._idxShm.close()
            except Exception:
                pass
            self._idxShm = None
        if self._dirShm is not None:
            try:
                self._dirShm.close()
            except Exception:
                pass
            self._dirShm = None


# ==================== 用户接口 ====================
class F3Mem:
    _IDX = None
    _F3INSTS = ('_ns', '_IDX')
    _FUNCTION = type(lambda: ...)

    def __init__(self, ns=''):
        super().__setattr__('_ns', ns)
        if F3Mem._IDX is None:
            F3Mem._IDX = _MemIndex()
            atexit.register(F3Mem.releaseAll)
        # 运行时接口验证
        assert isinstance(self, F3Backend), "F3Mem must implement F3Backend protocol"

    # ---- 键管理 ----
    def _fullkey(self, key, skey=None):
        """生成索引中的完整键名。主键默认映射到 '_' 子键。"""
        if not isinstance(key, str):
            raise TypeError(f"key must be str, got {type(key)}")
        if skey is not None and not isinstance(skey, str):
            raise TypeError(f"skey must be str, got {type(skey)}")
        _skey = skey if skey is not None else '_'
        return f"{self._ns}:{key}/{_skey}"

    def _mkeyprefix(self, key):
        """返回主键的命名空间前缀，用于遍历子键。"""
        return f"{self._ns}:{key}/"

    def _nsprefix(self):
        """返回当前命名空间前缀。"""
        return f"{self._ns}:"

    def _shmname(self, fullkey):
        _h = hashlib.sha256(fullkey.encode()).hexdigest()[:24]
        # 使用唯一名称，避免与守护进程持有的旧块冲突（Windows 兼容性）
        return f"f3_{_h}_{os.getpid()}_{int(time.time() * 1000) % 10000000}"

    # ---- 内部存储/读取 ----
    def _store(self, fullkey, data, ttl=None):
        _size = len(data)
        _shmname = self._shmname(fullkey)

        _old = F3Mem._IDX.get(fullkey)
        if _old:
            _oldname = _old[0]
            F3Mem._IDX.release(_oldname)
            # 关闭 _LIVE_BLOCKS 中的旧块引用，否则 Windows 上 unlink 失败
            _old_live = _LIVE_BLOCKS.pop(_oldname, None)
            if _old_live is not None:
                try:
                    _old_live.close()
                except Exception:
                    pass
            try:
                _oldshm = shared_memory.SharedMemory(name=_oldname)
                _oldshm.close()
                _oldshm.unlink()
            except Exception:
                pass

        try:
            _shm = shared_memory.SharedMemory(name=_shmname, create=True, size=_size)
        except FileExistsError:
            _orphan = shared_memory.SharedMemory(name=_shmname)
            _orphan.close()
            _orphan.unlink()
            _shm = shared_memory.SharedMemory(name=_shmname, create=True, size=_size)

        try:
            _shm.buf[:_size] = data
        except Exception:
            _shm.close()
            _shm.unlink()
            raise

        F3Mem._IDX.set(fullkey, _shmname, _size, ttl=ttl, shm=_shm)
        return F3True

    def _load(self, fullkey, meta, *, error=False):
        _shmname = meta[0]
        _size = meta[1]
        try:
            _shm = shared_memory.SharedMemory(name=_shmname)
            _data = bytes(_shm.buf[:_size])
            _shm.close()
            return _MemLoads(_data)
        except FileNotFoundError:
            F3Mem._IDX.delete(fullkey)
            if error:
                raise KeyError(fullkey)
            return F3False
        except Exception:
            if error:
                raise
            return F3False

    def _mkeys(self):
        """返回所有主键名（去重）。"""
        _seen = set()
        _p = self._nsprefix()
        for _k in F3Mem._IDX.keys():
            if not _k.startswith(_p):
                continue
            _rest = _k[len(_p):]
            if '/' not in _rest:
                continue
            _mkey, _ = _rest.split('/', 1)
            if _mkey not in _seen:
                _seen.add(_mkey)
                yield _mkey

    def _mkeys_with_default(self):
        """返回有默认子键 '_' 的主键名（与 F3Shell 的 iter 语义一致）。"""
        _p = self._nsprefix()
        _seen = set()
        for _k in F3Mem._IDX.keys():
            if not _k.startswith(_p):
                continue
            _rest = _k[len(_p):]
            if '/' not in _rest:
                continue
            _mkey, _skey = _rest.split('/', 1)
            if _skey == '_' and _mkey not in _seen:
                _seen.add(_mkey)
                yield _mkey

    def _skeys(self, mkey):
        """返回指定主键下的所有子键名（排除 '_'）。"""
        _p = self._mkeyprefix(mkey)
        for _k in F3Mem._IDX.keys():
            if not _k.startswith(_p):
                continue
            _rest = _k[len(_p):]
            if _rest == '_':
                continue
            yield _rest

    # ---- 筛选语法（与 F3Shell 一致）----
    def _filter(self, item):
        """
        筛选支持: str, Ellipsis/slice, re.Pattern, func(name, type)->bool, list
        返回匹配的主键名列表。
        """
        if item is ... or isinstance(item, slice):
            return list(self.keys())
        if isinstance(item, str):
            return [item]
        if isinstance(item, self._FUNCTION):
            _result = []
            for _k in self.keys():
                try:
                    if item(_k, ''):
                        _result.append(_k)
                except Exception as err:
                    print(f"Bad filter function: {item}. Cause error: {err}\n\nPlease check your function(name, type)->bool and it's code.")
            return _result
        if isinstance(item, re.Pattern):
            return [_k for _k in self.keys() if item.match(_k)]
        if isinstance(item, list):
            _result = []
            for _it in item:
                _result.extend(self._filter(_it))
            return list(set(_result))
        raise TypeError(f"Unknown filter type: {type(item)}")

    # ---- CRUD（新增 ttl 参数）----
    def set(self, key, value, skey=None, *, ttl=None, error=False):
        try:
            _data = _MemDumps(value)
        except CannotSaveError:
            if error:
                raise
            return F3False
        except Exception:
            if error:
                raise
            return F3False

        # 如果设子键且默认子键不存在，先创建默认子键为 None
        if skey is not None:
            _default_fullkey = self._fullkey(key, '_')
            if F3Mem._IDX.get(_default_fullkey) is None:
                try:
                    _none_data = _MemDumps(None)
                    self._store(_default_fullkey, _none_data)
                except Exception:
                    pass  # 忽略默认子键创建失败

        fullkey = self._fullkey(key, skey)
        try:
            return self._store(fullkey, _data, ttl=ttl)
        except Exception:
            if error:
                raise
            return F3False

    def get(self, key, skey=None, *, error=False):
        fullkey = self._fullkey(key, skey)
        _meta = F3Mem._IDX.get(fullkey)
        if not _meta:
            return F3False
        return self._load(fullkey, _meta, error=error)

    def has(self, key, skey=None, *, error=False):
        if skey is not None:
            fullkey = self._fullkey(key, skey)
            return F3True if F3Mem._IDX.get(fullkey) is not None else F3False
        # skey is None: 检查主键命名空间下是否有任何条目
        _prefix = self._mkeyprefix(key)
        for _k in F3Mem._IDX.keys():
            if _k.startswith(_prefix):
                return F3True
        return F3False

    def delete(self, key, skey=None, *, error=False):
        if skey is None:
            _prefix = self._mkeyprefix(key)
            for _fk in list(F3Mem._IDX.keys()):
                if _fk.startswith(_prefix):
                    F3Mem._IDX.delete(_fk)
            # 与 F3Core 一致：目标不存在也返回 F3True
            return F3True
        else:
            fullkey = self._fullkey(key, skey)
            F3Mem._IDX.delete(fullkey)
            return F3True

    # ---- 列举 ----
    def list(self, key=None, *, error=False):
        if key is None:
            return list(self.keys())
        else:
            return list(self._skeys(key))

    def walk(self, *, error=False):
        _p = self._nsprefix()
        _mkeyMap = {}
        for _k in F3Mem._IDX.keys():
            if not _k.startswith(_p):
                continue
            _rest = _k[len(_p):]
            if '/' not in _rest:
                continue
            _mkey, _skey = _rest.split('/', 1)
            if _mkey not in _mkeyMap:
                _mkeyMap[_mkey] = []
            if _skey != '_':
                _mkeyMap[_mkey].append(_skey)
        for _mkey in _mkeyMap:
            yield _mkey, ''
            for _skey in _mkeyMap[_mkey]:
                yield _mkey, _skey

    def keys(self):
        # 与修复后的 F3Shell.iter 一致：返回所有主键（只要有任何子键）
        return self._mkeys()

    def values(self):
        for _k in self.keys():
            yield self.get(_k)

    def items(self):
        for _k in self.keys():
            yield _k, self.get(_k)

    def save(self, target=None, type=PF_DTYPE, sub_type=PF_DTYPE, *, error=False):
        """
        将 F3Mem 数据保存到文件系统（F3Shell）。
        :param target: str 工作目录，或 F3Shell 实例
        :param type:   主键后缀（仅当 target 为 str 时有效）
        :param sub_type: 子键后缀（仅当 target 为 str 时有效）
        :param error:  bool 是否抛出异常
        :return: F3Bool
        """
        from files3.f3shell import F3Shell
        if isinstance(target, F3Shell):
            _f = target
        else:
            _f = F3Shell(target or "", type, sub_type)
        try:
            for _mkey, _skey in self.walk():
                if _skey == '':
                    _val = self.get(_mkey)
                    _f.set(_mkey, _val, error=error)
                else:
                    _val = self.get(_mkey, _skey)
                    _f.set(_mkey, _val, _skey, error=error)
            return F3True
        except Exception:
            if error:
                raise
            return F3False

    def load(self, target=None, type=PF_DTYPE, sub_type=PF_DTYPE, *, error=False):
        """
        从文件系统（F3Shell）加载数据到 F3Mem。
        :param target: str 工作目录，或 F3Shell 实例
        :param type:   主键后缀（仅当 target 为 str 时有效）
        :param sub_type: 子键后缀（仅当 target 为 str 时有效）
        :param error:  bool 是否抛出异常
        :return: F3Bool
        """
        from files3.f3shell import F3Shell
        if isinstance(target, F3Shell):
            _f = target
        else:
            _f = F3Shell(target or "", type, sub_type)
        try:
            for _mkey, _skey in _f.walk():
                if _skey == '':
                    _val = _f.get(_mkey)
                    self.set(_mkey, _val)
                else:
                    _val = _f.get(_mkey, _skey)
                    self.set(_mkey, _val, _skey)
            return F3True
        except Exception:
            if error:
                raise
            return F3False

    def clear(self):
        _p = self._nsprefix()
        for _fk in list(F3Mem._IDX.keys()):
            if _fk.startswith(_p):
                F3Mem._IDX.delete(_fk)

    @classmethod
    def releaseAll(cls):
        """释放本进程持有的所有共享内存引用，不销毁全局段。"""
        if cls._IDX is not None:
            cls._IDX.releaseAll()
            cls._IDX = None

    # ---- 魔术方法 ----
    def __getitem__(self, item):
        if isinstance(item, tuple):
            if len(item) != 2 or not isinstance(item[0], str) or not isinstance(item[1], str):
                raise ValueError("Tuple key must be (str, str)")
            return self.get(item[0], item[1], error=True)
        _result = []
        for _k in self._filter(item):
            _result.append(self.get(_k, error=True))
        return F3False if not _result else (_result[0] if len(_result) == 1 else _result)

    def __setitem__(self, key, value):
        if isinstance(key, tuple):
            if len(key) != 2 or not isinstance(key[0], str) or not isinstance(key[1], str):
                raise ValueError("Tuple key must be (str, str)")
            self.set(key[0], value, key[1])
            return
        for _k in self._filter(key):
            self.set(_k, value)

    def __delitem__(self, key):
        if key is ...:
            self.clear()
            return
        if isinstance(key, tuple):
            if len(key) != 2 or not isinstance(key[0], str) or not isinstance(key[1], str):
                raise ValueError("Tuple key must be (str, str)")
            self.delete(key[0], key[1])
            return
        for _k in self._filter(key):
            self.delete(_k)

    def __contains__(self, item):
        _keys = list(self._filter(item))
        if not _keys:
            return False
        return all(self.has(_k) for _k in _keys)

    def __iter__(self):
        return iter(self.keys())

    def __len__(self):
        return len(list(self.keys()))

    def __getattr__(self, item):
        return self.get(item, error=False)

    def __setattr__(self, key, value):
        is_magic = (len(key) > 4 and key.startswith('__') and key.endswith('__'))
        if key in self._F3INSTS or is_magic:
            super().__setattr__(key, value)
        else:
            self.__setitem__(key, value)

    def __delattr__(self, item):
        self.delete(item)


# ==================== 便捷入口 ====================
def MemFiles(ns=''):
    return F3Mem(ns)
