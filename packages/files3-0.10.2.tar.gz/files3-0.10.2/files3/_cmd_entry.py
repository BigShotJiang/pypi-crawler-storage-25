"""
_cmd_entry.py
~~~~~~~~~~~~~

Command-line entry points for files3 (Windows only).
Provides f3 / f3open / f3assoc / f3unassoc CLI commands.
"""

import argparse
import os
import subprocess
import sys
import tempfile
import winreg
from files3.f3info import PF_DTYPE, F3Info
from files3.f3bool import F3Bool
from files3.f3shell import F3Shell as files


def _read_inst(_dir, _fname, _type):
    try:
        _f = files(_dir, _type)
    except Exception as err:
        print(f"Failed to create Files parser. -For {err}")
        return False

    _fullpath = os.path.join(_dir, _fname + _type)
    #print(_fullpath)
    if not os.path.exists(_fullpath):
        print(f"File:{_fname}{_type} not exists under:{_dir}.")
        return False

    # _ = _f.get(_fname)
    try:
        _ = _f.get(_fname)
    except Exception as err:
        print(f"Failed to load & parse target. -For {err}")
        return False

    if isinstance(_, F3Bool):
        print("File can't be a Files3File -For got the 'pfFalse'.")
        return False

    # 注入txt到临时目录
    with tempfile.NamedTemporaryFile('w+t', suffix='.txt', delete=False) as f:
        f.write(f'PythonInstance: {_fname}\n' + str(_))

    # open target
    path = os.path.abspath(f.name)
    os.system(f"start {path}")
    return True


# add cmd
_cmd_show_doc_ = """
show files3 data by txt browser
f3 [fname] 
f3 [fname] [type]
f3 [fname] -i [dir]
f3 [fname] [type] -i [dir]
@example:
    f3 a [.inst]  # default type is .inst | default dir is ''
    f3 a .obj
    # f3 a obj  # is error
    f3 a -i /datum
    f3 a .obj -i /datum
"""


def _cmd_show():
    """
    f3 [fname]
    f3 [fname] [ftype]
    f3 [fname] -i [dir]
    f3 [fname] [ftype] -i [dir]
    :return:
    """
    parser = argparse.ArgumentParser("Files3.CMDFilePreview")
    parser.add_argument('fname', help="Instance File's name", type=str)
    parser.add_argument('-t', '--type', help="Instance File's user-defined type. (like .XXX)", default=PF_DTYPE, type=str)
    parser.add_argument('-d', '--dir', help="Files3 entry's directory.", default="")
    try:
        args = parser.parse_args()
    except Exception as err:
        print(f"Failed to parse arguments. -For: {err}\n\n{_cmd_show_doc_}")
        return False
    # print("debug:", args)
    # get dir fname type
    return _read_inst(args.dir, args.fname, args.type)


_cmd_open_doc_ = """
open files3 data by txt browser
f3open [fpath]
@example:
    f3open /datum/a.inst
    f3open /datum/a.obj
    f3open /datum/a  # is error
"""


def _cmd_open():
    """
    f3open [fpath]
    :return:
    """
    # print(sys.argv)
    parser = argparse.ArgumentParser("Files3.CMDFileOpen")
    parser.add_argument('fpath', help="Instance File's path(like a/b/c.xxx)", type=str)
    try:
        args = parser.parse_args()
    except Exception as err:
        print(f"Failed to parse arguments. -For: {err}\n\n{_cmd_open_doc_}")
        return False

    try:
        dir, fname, ftype = F3Info.SplitPath(args.fpath)
    except Exception as err:
        print(f"Failed to locate File. -For: {err}\n\n{_cmd_open_doc_}")
        return False

    return _read_inst(dir, fname, ftype)


_cmd_assoc_doc_ = """
assoc specific file type to f3open (HKCU only, no admin required)
f3assoc [ftype]
@example:
    f3assoc .inst
    f3assoc .obj
    f3assoc .inst .obj  # is error
"""


_cmd_unassoc_doc_ = """
unassoc specific file type from f3open (HKCU only, no admin required)
f3unassoc [ftype]
@example:
    f3unassoc .inst
    f3unassoc .obj
"""


def _DeleteKeyTree(_hkey, _subkey):
    """Recursively delete a registry key and all its subkeys."""
    try:
        with winreg.OpenKey(_hkey, _subkey, 0, winreg.KEY_READ | winreg.KEY_WRITE) as _key:
            while True:
                try:
                    _name = winreg.EnumKey(_key, 0)
                    _DeleteKeyTree(_hkey, _subkey + "\\" + _name)
                except OSError:
                    break
        winreg.DeleteKey(_hkey, _subkey)
    except FileNotFoundError:
        pass


def _cmd_assoc():
    """
    f3assoc [ftype]
    注册表位置(仅HKCU, 无需管理员权限):
        HKEY_CURRENT_USER/Software/Classes/{EXTENSION}
            默认value = {PROG_ID}|(REG_SZ):str
            OpenWithProgids子键(空)
        HKEY_CURRENT_USER/Software/Classes/{PROG_ID}/shell/open/command
            默认value = {Description}|(REG_SZ):str
            DefaultIcon默认value = {abs_exepath},0|(REG_SZ):str
            shell/open/command默认value = "{abs_exepath}" "%1"|(REG_SZ):str
        HKEY_CURRENT_USER/Software/Microsoft/Windows/CurrentVersion/ApplicationAssociationToasts
            {PROG_ID}_{EXTENSION} = 0|(REG_DWORD):int
        HKEY_CURRENT_USER/Software/Microsoft/Windows/CurrentVersion/Explorer/FileExts/{EXTENSION}/OpenWithProgids
            默认value = |(REG_SZ):str  # 空的
            {PROG_ID} = |(REG_NONE):?  # 空的
    :return:
    """
    parser = argparse.ArgumentParser("Files3.CMDAssoc")
    parser.add_argument('ftype', help="Instance File's custom ftype(like .xxx)", type=str)
    try:
        args = parser.parse_args()
        _ = args.ftype
    except Exception as _err:
        print(f"Failed to parse arguments. -For: {_err}\n\n{_cmd_assoc_doc_}")
        return False

    py_exe = sys.executable
    f3open_exe = os.path.join(os.path.dirname(py_exe), "Scripts", "f3open.exe")
    if not os.path.exists(f3open_exe):
        print(f"Failed to locate f3open.exe. -For: {f3open_exe} is not exists")
        return False

    if not args.ftype.startswith("."):
        print(f"Failed to parse arguments. -For: {args.ftype} is not start with '.'")
        return False

    DESCRIPTION = f"Python Instance"
    PROG_ID = f"Files3.{args.ftype[1:]}_File"
    EXTENSION = args.ftype
    abs_exepath = os.path.abspath(f3open_exe)
    print(f"Program f3open.exe: {abs_exepath}")

    # HKCU/Software/Classes/{EXTENSION}
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{EXTENSION}") as _key:
        winreg.SetValue(_key, "", winreg.REG_SZ, PROG_ID)
        with winreg.CreateKey(_key, "OpenWithProgids") as _subkey:
            ...

    # HKCU/Software/Classes/{PROG_ID}/shell/open/command
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{PROG_ID}") as _key:
        winreg.SetValue(_key, "", winreg.REG_SZ, DESCRIPTION)
        with winreg.CreateKey(_key, "DefaultIcon") as _subkey:
            winreg.SetValue(_subkey, "", winreg.REG_SZ, f"{abs_exepath},0")
        with winreg.CreateKey(_key, "shell") as _subkey:
            with winreg.CreateKey(_subkey, "open") as _subsubkey:
                with winreg.CreateKey(_subsubkey, "command") as _subsubsubkey:
                    winreg.SetValue(_subsubsubkey, "", winreg.REG_SZ, f'"{abs_exepath}" "%1"')

    # ApplicationAssociationToasts
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"Software\\Microsoft\\Windows\\CurrentVersion\\ApplicationAssociationToasts") as _key:
        winreg.SetValueEx(_key, f"{PROG_ID}_{EXTENSION}", 0, winreg.REG_DWORD, 0)

    # FileExts/{EXTENSION}/OpenWithProgids
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, f"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\{EXTENSION}") as _key:
        winreg.SetValue(_key, "", winreg.REG_SZ, "")
        with winreg.CreateKey(_key, "OpenWithProgids") as _subkey:
            ...

    _result = subprocess.run(
        ['reg', 'add', f'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\{EXTENSION}\\OpenWithProgids', '/v', PROG_ID,
         '/t', 'REG_NONE', '/d', '', '/f'], capture_output=True)
    if _result.returncode != 0:
        print(f"Warning: reg add failed for REG_NONE value. stderr: {_result.stderr.decode('gbk', errors='ignore').strip()}")

    print(f"Success to assoc {EXTENSION} to {abs_exepath}")
    return True


def _cmd_unassoc():
    """
    f3unassoc [ftype]
    仅清理HKCU下的注册表项, 无需管理员权限。
    :return:
    """
    parser = argparse.ArgumentParser("Files3.CMDUnAssoc")
    parser.add_argument('ftype', help="Instance File's custom ftype(like .xxx)", type=str)
    try:
        args = parser.parse_args()
        _ = args.ftype
    except Exception as _err:
        print(f"Failed to parse arguments. -For: {_err}\n\n{_cmd_unassoc_doc_}")
        return False

    if not args.ftype.startswith("."):
        print(f"Failed to parse arguments. -For: {args.ftype} is not start with '.'")
        return False

    PROG_ID = f"Files3.{args.ftype[1:]}_File"
    EXTENSION = args.ftype

    _errs = []

    try:
        _DeleteKeyTree(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{EXTENSION}")
    except Exception as _err:
        _errs.append(f"HKCU\\Software\\Classes\\{EXTENSION}: {_err}")

    try:
        _DeleteKeyTree(winreg.HKEY_CURRENT_USER, f"Software\\Classes\\{PROG_ID}")
    except Exception as _err:
        _errs.append(f"HKCU\\Software\\Classes\\{PROG_ID}: {_err}")

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, f"Software\\Microsoft\\Windows\\CurrentVersion\\ApplicationAssociationToasts", 0, winreg.KEY_SET_VALUE) as _key:
            winreg.DeleteValue(_key, f"{PROG_ID}_{EXTENSION}")
    except FileNotFoundError:
        pass
    except Exception as _err:
        _errs.append(f"ApplicationAssociationToasts: {_err}")

    try:
        _DeleteKeyTree(winreg.HKEY_CURRENT_USER, f"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\{EXTENSION}")
    except Exception as _err:
        _errs.append(f"FileExts\\{EXTENSION}: {_err}")

    if _errs:
        print(f"Partially failed to unassoc {EXTENSION}:")
        for _e in _errs:
            print(f"  {_e}")
        return False

    print(f"Success to unassoc {EXTENSION} to {PROG_ID}")
    return True


if __name__ == '__main__':
    sys.argv = ['f3open', r"C:\Users\Administrator\Desktop\test\a.inst"]
    _cmd_open()
