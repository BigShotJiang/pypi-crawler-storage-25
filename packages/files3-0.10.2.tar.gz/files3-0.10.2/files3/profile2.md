# files3 性能分析报告 — 移除 pickletools.optimize 后

> 变更: `f3io.py` 中 `f3dumps` 移除 `pickletools.optimize(s)` 调用
> 测试环境: Python 3.14.3 | Windows 11 | 重复次数: 5 取中位数

---

## 一、set() 写入 — 中/大对象写入速度提升 73%~88%

| 子阶段 | 小对象 (~100B) | 中对象 (~15KB) | 大对象 (~1.2MB) |
|--------|---------------|---------------|----------------|
| shell_validate | 0.1% | 0.1% | 0.0% |
| path_join | 1.9% | 1.9% | 0.1% |
| os.path.exists | 11.8% | 11.4% | 0.7% |
| **cloudpickle.dumps** | 5.3% | **10.6%** | **56.6%** |
| ~~pickletools.optimize~~ | ~~0.2%~~ | ~~0.2%~~ | ~~0.0%~~ |
| lz4.compress | 1.1% | 1.8% | **32.6%** |
| **file_write** | **79.6%** | **74.1%** | **10.1%** |
| **TOTAL** | **196.9 us** | **195.8 us** | **3.64 ms** |

**与 profile1 对比：**

| 对象大小 | profile1 (有optimize) | profile2 (无optimize) | 提升 |
|----------|----------------------|----------------------|------|
| 小对象 | 222.3 us | 196.9 us | **11.4%** |
| 中对象 | 717.1 us | 195.8 us | **72.7%** |
| 大对象 | 29.81 ms | 3.64 ms | **87.8%** |

**瓶颈转移：**
- 小对象：file_write 占 80%，序列化仅占 6.6%。瓶颈仍是文件IO。
- 中对象：file_write 占 74%，dumps 占 10.6%。瓶颈回到文件IO。
- 大对象：dumps 占 57%，lz4.compress 占 33%。瓶颈转移到 cloudpickle 和 lz4 压缩。

---

## 二、get() 读取 — 无变化（optimize 只影响写入）

| 子阶段 | 小对象 | 中对象 | 大对象 |
|--------|--------|--------|--------|
| path_join | 3.1% | 0.8% | 0.0% |
| os.path.exists | 26.1% | 6.6% | 0.3% |
| file_read | 48.0% | 12.6% | 2.4% |
| lz4.decompress | 2.4% | 0.9% | 2.9% |
| **unpickle** | **20.2%** | **79.0%** | **94.4%** |
| TOTAL | 80.0 us | 317.5 us | 14.02 ms |

**与 profile1 对比：** get 操作不受 optimize 影响，数据基本持平（微小波动属于测量误差）。

---

## 三、子键首次转换 — 无显著变化

| 子阶段 | 占比 | 耗时 |
|--------|------|------|
| path_join | 0.5% | 3.7 us |
| check_isfile | 3.3% | 26.8 us |
| gen_random_name | 0.6% | 5.1 us |
| mkdir_tmp | 12.4% | 99.8 us |
| **move_to_tmp** | **25.8%** | **208.6 us** |
| **rename_tmp** | **34.2%** | **276.4 us** |
| write_skey | 23.2% | 187.2 us |
| TOTAL | 807.6 us | — |

write_skey 从 211us 降至 187us（因为 optimize 被移除），整体提升约 5%。

---

## 四、筛选操作 — 无变化

筛选器解析仍占 2.6%~18.2%，get 反序列化占 95% 以上。

---

## 五、遍历操作 — 无变化

listdir 几乎免费，values/items 瓶颈仍在 get 反序列化。

---

## 六、序列化子步骤 — optimize 从 63%~97% 降至接近 0%

| 对象 | dumps | ~~optimize~~ | compress | 总耗时 |
|------|-------|-------------|----------|--------|
| small | 2.9 us (72.5%) | ~~0.2 us (5.0%)~~ | 0.9 us (22.5%) | **13.4 us** |
| medium | 12.6 us (82.4%) | ~~0.2 us (1.3%)~~ | 2.5 us (16.3%) | **265.2 us** |
| large | 1.65 ms (58.6%) | ~~0.6 us (0.0%)~~ | 1.16 ms (41.4%) | **16.09 ms** |

**与 profile1 对比：**

| 对象 | profile1 总耗时 | profile2 总耗时 | 提升 |
|------|----------------|----------------|------|
| small | 28.6 us | 13.4 us | **53.1%** |
| medium | 766.7 us | 265.2 us | **65.4%** |
| large | 43.7 ms | 16.09 ms | **63.2%** |

**瓶颈转移：**
- 小对象：dumps 占 72.5%，compress 占 22.5%。optimize 消失后 dumps 和 compress 成为主导。
- 大对象：dumps 占 59%，compress 占 41%。两者共同主导。

---

## 七、pack/unpack — 无变化

zip 压缩/解压仍占 98% 以上，f3 序列化占比可忽略。

---

## 八、files3 vs pickle — 差距从 4.1x 缩小到 2.1x

| 阶段 | profile1 files3 | profile2 files3 | pickle | profile1 差距 | profile2 差距 |
|------|----------------|----------------|--------|--------------|--------------|
| serialize | 22.3 us | 21.2 us | 13.5 us | 1.5x | 1.6x |
| compress | 530.6 us | 3.8 us | N/A | — | — |
| file_write | 162.7 us | 147.1 us | 148.0 us | 1.0x | 1.0x |
| file_read | 54.0 us | 50.2 us | 50.1 us | 1.0x | 1.0x |
| decompress | 4.2 us | 3.8 us | N/A | — | — |
| deserialize | 225.9 us | 254.5 us | 16.9 us | 12.9x | **15.1x** |
| **TOTAL** | **999.7 us** | **480.6 us** | **228.5 us** | **4.1x** | **2.1x** |

**关键发现：**
- 移除 optimize 后，**总差距从 4.1x 降至 2.1x**，写入性能翻倍。
- deserialize 反而略慢（225→254 us），属于测量波动。
- compress 从 530us 骤降至 3.8us：profile1 的 "compress" 阶段实际上包含了 optimize（因为代码里是 `compress(optimize(s))`），profile2 才是真正的纯 compress 时间。

---

## 九、文件数量对子步骤的影响 — 无变化

| 已有文件数 | os.listdir | file_write | 总耗时 |
|-----------|-----------|------------|--------|
| 0 | 40.5 us (15%) | 180.1 us (68%) | 266.6 us |
| 200 | 77.1 us (30%) | 145.2 us (56%) | 258.3 us |
| 500 | 139.4 us (45%) | 135.3 us (43%) | 311.4 us |

---

## 总结：移除 optimize 的效果

| 场景 | profile1 瓶颈 | profile2 瓶颈 | 性能变化 |
|------|--------------|--------------|---------|
| set 小对象 | file_write (70%) | file_write (80%) | **+11%** |
| set 中对象 | **optimize (71%)** | file_write (74%) | **+73%** |
| set 大对象 | **optimize (88%)** | dumps (57%) + compress (33%) | **+88%** |
| get (所有) | unpickle | unpickle | 无变化 |
| 序列化 small | optimize (79%) | dumps (73%) | **+53%** |
| 序列化 medium | optimize (97%) | dumps (82%) | **+65%** |
| 序列化 large | optimize (88%) | dumps (59%) + compress (41%) | **+63%** |
| files3 vs pickle | 4.1x | **2.1x** | 差距缩小一半 |

**结论：**

`pickletools.optimize` 是 files3 写入性能的最大瓶颈。移除后：
- 中/大对象写入速度提升 **65%~88%**
- 纯序列化速度提升 **53%~65%**
- 与 pickle 的整体差距从 **4.1x 缩小到 2.1x**

**代价：** `pickletools.optimize` 对 pickle bytecode 做死码消除和常量折叠，理论上可以减小输出体积并略微加速 unpickling。移除后：
- 输出文件体积可能略微增大（未实测）
- 反序列化速度理论上可能略微下降（实测无显著变化，因为 unpickle 本身在 profile1 中只占 15%~28%）

**建议：** 如果应用场景以写入为主（如缓存、配置持久化），移除 optimize 的收益远大于代价；如果场景以读取为主且对文件体积敏感，可以保留。
