# files3

Windows平台的Python对象文件持久化存储库。以文件系统为后端，将任意Python对象序列化存储，提供类字典的交互接口。

---

## 一、应用导向

### 1.1 适用场景

| 场景 | 说明 |
|------|------|
| 配置持久化 | 替代json/yaml存储复杂Python数据结构（含自定义类、lambda、闭包） |
| 本地缓存 | 缓存函数计算结果、中间状态，支持任意可序列化对象 |
| 数据交换 | 通过文件系统在不同进程/脚本间传递Python对象 |
| 嵌入式打包 | 将资源文件打包为Python代码（`packpy`/`unpackpy`），随代码分发 |
| 实验数据保存 | 快速保存实验中间结果（模型、参数、状态），无需配置数据库 |

### 1.2 核心优势

- **任意对象存储**：基于cloudpickle，支持lambda、闭包、局部类、模块引用等标准pickle无法处理的类型
- **lz4压缩**：默认启用高速压缩，平衡存储空间和读写性能
- **源代码重链接**：保存`__main__`中定义的类/函数时，自动记录源文件路径，加载时自动修正模块名
- **类字典接口**：支持`f['key']`、`f.key`、`f.set()`等多种交互方式
- **子键支持**：单主键可扩展为多子键，主键自动转为文件夹管理

### 1.3 不推荐的场景

- 跨平台数据交换（仅支持Windows）
- 高并发写入场景（无锁机制，依赖文件系统原子性）
- 超大规模键值存储（数十万级以上，文件系统inode成为瓶颈）
- 需要SQL查询的复杂检索场景

---

## 二、架构描述

### 2.1 模块分层

```
┌─────────────────────────────────────────┐
│           Shell 层 (f3shell.py)          │
│     F3Shell — 文件系统后端，类字典API      │
│     参数校验 / 筛选语法 / 批量操作          │
├─────────────────────────────────────────┤
│           Mem 层 (f3mem.py)              │
│     F3Mem — 共享内存后端，类字典API        │
│     零磁盘IO / 跨进程 / 虚拟磁盘持久        │
│     守护进程持有引用，数据 survives releaseAll│
│     cloudpickle写入 + pickle读取           │
│     save/load — 内存与文件系统互转         │
├─────────────────────────────────────────┤
│           Core 层 (f3core.py)            │
│     F3Core — 核心CRUD，单例模式            │
│     调用 Info 解析路径，调用 IO 序列化       │
├─────────────────────────────────────────┤
│          Interface 层 (interface.py)      │
│     F3Backend — Protocol 统一接口协议      │
│     约束 F3Shell 与 F3Mem 行为一致          │
├─────────────────────────────────────────┤
│           Info 层 (f3info.py)            │
│     F3Info — 路径拼接 / 后缀管理            │
│     自动创建工作目录 / 规范化类型后缀         │
├─────────────────────────────────────────┤
│            IO 层 (f3io.py)               │
│     cloudpickle序列化 / lz4压缩           │
│     zip打包 / bytes与python代码互转         │
│     自定义Unpickler — __main__模块重链接   │
├─────────────────────────────────────────┤
│          Utils 层 (f3utils.py)           │
│     Singleton元类 / memoize / 帧追踪       │
├─────────────────────────────────────────┤
│          Bool 层 (f3bool.py)             │
│     F3Bool — 不可变布尔封装，防误存         │
└─────────────────────────────────────────┘
```

### 2.2 数据流向

```
写入:  set('key', obj)
       │
       ▼
   F3Shell ──参数校验──┐
       │               │
       ▼               ▼
   F3Core.set()    F3Info(key) ──► 生成完整路径
       │
       ▼
   f3dumps(obj) ──► cloudpickle.dumps([scp, obj])
                    pickletools.optimize(s)
                    lzf.compress(s)
       │
       ▼
   写入文件系统

读取:  get('key')
       │
       ▼
   F3Shell ──参数校验──┐
       │               │
       ▼               ▼
   F3Core.get()    F3Info(key) ──► 生成完整路径
       │
       ▼
   读取文件bytes
       │
       ▼
   f3loads(s) ──► lzf.decompress(s)
                  _F3Unpickler.load()
                  自动修正__main__模块路径
       │
       ▼
   返回obj
```

F3Mem 数据流向：
```
写入:  set('key', obj)
       │
       ▼
   F3Mem ──cloudpickle.dumps(obj, protocol=5)──► bytes
       │
       ▼
   创建 OS 共享内存块 ──► 写入 bytes
       │
       ▼
   更新索引块（pickle序列化索引字典）
       │
       ▼
   守护进程 f3m 轮询索引，持有数据块引用

读取:  get('key')
       │
       ▼
   F3Mem ──从索引块查找共享内存名称
       │
       ▼
   attach 共享内存块 ──► 读取 bytes
       │
       ▼
   pickle.loads(bytes)
       │
       ▼
   返回obj
```

### 2.3 序列化格式

```
文件结构（存储在文件系统）:
<workspace>/
    key1.ist          ──► 单文件 = 主键直接存储
    key2.ist/         ──► 文件夹 = 启用子键后主键变为文件夹
        _.ist         ──► 默认子键（主键原内容迁移至此）
        subA.ist      ──► 子键A
        subB.ist      ──► 子键B
```

每个`.ist`文件内部格式：
```
[16 bytes tail marker (可选)]
lz4(cloudpickle([source_code_path, python_object]))
```

F3Mem 内存结构：
```
目录块 (f3mem_dir_v1, 4KB)
  └─ 当前索引块名称 + 大小

索引块 (f3mem_idx_*, 动态扩容)
  └─ pickle({
       "ns:key/skey": (shm_name, data_size, expire_at),
       ...
     })

数据块 (f3_<hash>_<pid>_<timestamp>, 动态大小)
  └─ cloudpickle.dumps(obj, protocol=5)
```

**序列化差异**：F3Shell 使用 `cloudpickle + lz4压缩 + 源码路径记录`，F3Mem 使用 `cloudpickle写入 + pickle读取`（cloudpickle输出兼容标准pickle，读取端无需cloudpickle依赖）。

### 2.4 关键设计决策

- **F3Bool封装**：用`F3True`/`F3False`替代原生`True`/`False`返回，防止用户误将返回值再次存入files3（`F3Bool.__call__`抛出`CannotSaveError`）
- **Singleton元类**：`F3Core`全局唯一，避免多实例竞争文件句柄
- **F3Backend Protocol**：`typing.Protocol` 定义统一接口，`F3Shell` 与 `F3Mem` 均实现该协议，保证两套后端行为一致
- **_F3Unpickler.find_class**：重写pickle类查找逻辑，将`__main__`动态替换为实际源文件名，解决脚本重命名/移动后的反序列化问题
- **主键→文件夹自动转换**：首次使用子键时，原子性地将文件转为文件夹（临时目录+重命名），失败可回滚

---

## 三、接口描述

### 3.1 快速入口

```python
from files3 import files, f3, prefab, f3p
from files3 import memfiles, f3m

# files / f3 / F3Shell 完全等价（文件系统后端）
f = files('./data')

# memfiles / f3m / F3Mem 完全等价（共享内存后端）
m = memfiles('my_ns')
```

### 3.2 F3Shell — 用户交互类

#### 构造

| 签名 | 说明 |
|------|------|
| `F3Shell(path="", type=".ist", sub_type=".ist")` | `path`: 工作目录；`type`: 主键后缀；`sub_type`: 子键后缀 |

#### CRUD基础

| 方法 | 签名 | 返回 | 说明 |
|------|------|------|------|
| set | `set(key:str, obj:object, skey:str=None, *, error=False)` | `F3Bool` | 存储对象。`skey`非None时主键转为文件夹 |
| get | `get(key:str, skey:str=None, *, error=False)` | `object \| F3Bool` | 读取对象。文件不存在返回`F3False` |
| has | `has(key:str, skey:str=None, *, error=False)` | `F3Bool` | 检查是否存在 |
| delete | `delete(key:str, skey:str=None, *, error=False)` | `F3Bool` | 删除。不存在也返回`F3True` |
| list | `list(key:str=None, *, error=False)` | `list \| F3Bool` | `key=None`列主键；`key=str`列该主键的子键 |
| walk | `walk(*, error=False)` | `Iterable[(str,str)]` | 递归遍历所有主键和子键 |

#### 字典式访问（等效方法调用）

```python
f = files('./data')

# 写入
f['key'] = value        # 等价 f.set('key', value, error=True)
f.key = value           # 等价 f.set('key', value, error=True)
f['key', 'sub'] = value # 等价 f.set('key', value, 'sub', error=True)

# 读取
f['key']                # 等价 f.get('key', error=True)
f.key                   # 等价 f.get('key', error=False)
f['key', 'sub']         # 等价 f.get('key', 'sub', error=True)

# 删除
del f['key']            # 等价 f.delete('key', error=True)
del f.key               # 等价 f.delete('key', error=True)
del f[...]              # 删除所有主键

# 成员检查
'key' in f              # 等价 f.has('key', error=True)

# 迭代
for k in f: print(k)    # 迭代所有主键
len(f)                  # 主键数量
```

#### 筛选语法（`__getitem__` / `__setitem__` / `__delitem__`）

支持在方括号中使用高级筛选：

| 筛选器 | 说明 | 示例 |
|--------|------|------|
| `str` | 精确匹配key | `f['key']` |
| `...` 或 `slice[:]` | 全选 | `f[...]` |
| `re.Pattern` | 正则匹配key | `f[re.compile(r'^test_')]` |
| `func(name, type)->bool` | 函数过滤 | `f[lambda n,t: n.startswith('a')]` |
| `list` | 多个条件取并集 | `f['key1', 'key2', re.compile(r'x')]` |

```python
# 批量操作示例
f[...] = None           # 将所有主键设为None
f['a', 'b', 'c'] = 10   # 将a,b,c三个key设为10
f[re.compile(r'^temp')] = None  # 删除所有以temp开头的key
del f[lambda n, t: int(n) < 10] # 删除key数值小于10的项
```

#### 遍历方法

| 方法 | 返回 | 说明 |
|------|------|------|
| `keys()` | `Iterable[str]` | 主键迭代器 |
| `values()` | `Iterable[object]` | 值迭代器 |
| `items()` | `Iterable[(str, object)]` | 键值对迭代器 |

#### 类型与路径管理

| 方法 | 签名 | 返回 | 说明 |
|------|------|------|------|
| retype | `retype(new_type:str\|tuple, *mkeys, overwrite=False, error=False)` | `list` | 修改文件后缀。`tuple`可分别指定主/子键后缀 |
| relink | `relink(new_scp:str, *keys, error=False)` | `list` | 修正`__main__`对象的源文件路径 |
| hash | `hash(key:str, skey:str=None, *, error=False)` | `int \| F3Bool` | 计算文件指纹。文件夹会先zip打包再hash |

#### 序列化工具（类方法）

| 方法 | 签名 | 说明 |
|------|------|------|
| dumps | `dumps(obj, *, error=True)` | 对象 -> f3bytes |
| loads | `loads(data:f3bytes, *, error=True)` | f3bytes -> 对象 |
| pack | `pack(path:str, *, mode=ZIP_STORED, level=None, error=True)` | 文件/目录 -> f3bytes（内含zip） |
| unpack | `unpack(data:f3bytes, path:str=None, *, error=True, overwrite=False)` | f3bytes -> 解压到目录或返回ZipFile |
| bytes2py | `bytes2py(data:f3bytes, *, info='', error=True)` | bytes -> Python代码字符串 |
| py2bytes | `py2bytes(code:str, *, error=True)` | Python代码 -> bytes |
| packpy | `packpy(path:str, *, mode=ZIP_LZMA, level=9, error=True)` | 文件/目录 -> Python代码 |
| unpackpy | `unpackpy(code:str, extract_path=None, overwrite=False, *, error=True)` | Python代码 -> 解压 |

#### 预制工具（`prefab` / `p`）

| 方法 | 签名 | 说明 |
|------|------|------|
| testc | `testc(cmd:str) -> bool` | 测试命令是否存在（`where`） |
| aspy | `aspy(path:str, *, error=False, overwrite=False) -> F3Bool` | 打包目标为同名`.py`文件 |
| astarget | `astarget(path:str, *, error=False, overwrite=False) -> F3Bool` | 若目标不存在，从同名`.py`解压 |

### 3.3 F3Mem — 共享内存后端

基于 OS 共享内存的内存版 files3，零磁盘 IO、跨进程共享。接口与 `F3Shell` 完全一致（均实现 `F3Backend` Protocol）。

采用**虚拟磁盘模式**：全局守护进程 `f3m` 持续持有所有共享内存引用，用户进程退出仅 `close` 句柄，数据保留到系统重启。

#### 构造

| 签名 | 说明 |
|------|------|
| `F3Mem(ns='')` | `ns`: 命名空间，不同命名空间的数据相互隔离。默认空字符串 |

#### CRUD

与 `F3Shell` 完全一致的 `set/get/has/delete/list/walk/keys/values/items`，支持同样的字典式访问和筛选语法。

#### 独有方法

| 方法 | 签名 | 说明 |
|------|------|------|
| save | `save(target=None, type='.ist', sub_type='.ist', *, error=False)` | 将内存数据保存到文件系统。`target` 可为路径字符串或 `F3Shell` 实例 |
| load | `load(target=None, type='.ist', sub_type='.ist', *, error=False)` | 从文件系统加载数据到内存。`target` 可为路径字符串或 `F3Shell` 实例 |
| clear | `clear()` | 清空当前命名空间的所有数据 |
| releaseAll | `releaseAll()` | 释放所有共享内存资源（类方法） |

```python
from files3 import memfiles, files

m = memfiles('my_ns')
m['key'] = {'speed': 'fast'}
m['key', 'sub'] = 'zero_disk_io'

# 保存到文件系统
m.save('./backup')

# 从文件系统加载
m2 = memfiles('another_ns')
m2.load('./backup')

# 也可直接传入 files 实例
f = files('./backup')
m.save(f)
m2.load(f)

# 清理
m.clear()
F3Mem.releaseAll()
```

#### 注意事项

- **虚拟磁盘持久**：守护进程 `f3m` 持有共享内存引用，用户进程 `releaseAll()` 仅关闭句柄，数据保留到系统重启
- **命名空间隔离**：不同 `ns` 的数据互不可见
- **Windows限制**：共享内存命名依赖系统命名规则，避免过长命名空间
- **序列化**：写入使用 `cloudpickle`（支持 lambda、闭包、局部类），读取使用标准库 `pickle`（cloudpickle 输出兼容 pickle 格式）

### 3.4 F3Core — 核心CRUD（通常不直接使用）

单例类，被`F3Shell`内部调用。方法签名与`F3Shell`类似，但第一个参数为`F3Info`实例。

| 方法 | 说明 |
|------|------|
| `has(info, key, skey=None) -> F3Bool` | |
| `set(info, key, obj, skey=None, *, error=False) -> F3Bool` | |
| `get(info, key, skey=None, *, error=False) -> object` | |
| `delete(info, key, skey=None, *, error=False) -> F3Bool` | |
| `list(info, key=None, *, error=False) -> list` | |
| `iter(info) -> Iterable` | 主键迭代（生成器） |
| `walk(info) -> Iterable` | 递归遍历（生成`(mkey, skey)`） |
| `dumps(obj, *, error=True) -> bytes` | 静态方法 |
| `loads(s, *, error=True) -> object` | 静态方法 |

### 3.5 异常类型

| 异常 | 来源 | 说明 |
|------|------|------|
| `WorkspaceInvalidError` | `F3Info.__init__` | 工作目录路径以type/stype结尾 |
| `FolderCreateError` | `F3Core.set` | 创建子键文件夹失败 |
| `FileMoveError` | `F3Core.set` | 文件迁移到临时文件夹失败 |
| `FileRenameError` | `F3Core.set` | 临时文件夹重命名失败 |
| `ReadOnlyError` | `F3Bool.__setattr__` | 试图修改F3Bool属性 |
| `CannotSaveError` | `F3Bool.__call__` | 试图存储F3Bool实例 |
| `RetypeFailedError` | `F3Shell.retype` | 修改后缀失败 |
| `RelinkFailedError` | `F3Shell.relink` | 重链接源路径失败 |
| `NotF3InstError` | `f3io` | 数据不是有效的f3格式 |
| `NotF3UnpackableError` | `f3io` | 数据不是有效的zip格式 |
| `LostSourceCodeError` | `_F3Unpickler` | 找不到源文件路径 |

---

## 四、常见问题

### Q1: 为什么只能在Windows上使用？

files3依赖以下Windows专有机制：
- `win32api`/`win32gui`/`win32con` 用于文件关联和图标设置（`_cmd_entry.py`）
- `ctypes.windll.kernel32/shell32` 用于文件夹图标设置（`f3utils.py`）
- `subprocess.Popen("where cmd")` 用于命令检测

### Q2: 保存的对象加载时提示`ModuleNotFoundError`？

对象的类定义来自`__main__`模块（即直接运行的脚本），files3会记录该脚本的绝对路径。如果脚本被移动或重命名，反序列化时找不到原文件。

**解决**：使用`relink`方法重新绑定源路径：
```python
f.relink(r'F:\new_path\my_script.py', 'key1', 'key2')
```

如果对象类来自site-packages中的已安装包，确保该包已安装即可，无需relink。

### Q3: 为什么某些对象无法保存？

以下对象不能被cloudpickle序列化：
1. `F3Shell`实例或`F3Bool`实例（设计如此，防止循环引用）
2. 包含上述实例的对象（如字典中包含F3True）
3. 活动的异常对象（正在raise中）
4. 某些C扩展对象、生成器、文件句柄

**解决**：提取可序列化的数据部分单独存储。

### Q4: 如何批量删除所有数据？

```python
f = files('./data')
del f[...]          # 删除所有主键
```

或使用`shutil.rmtree`直接删除整个目录（更快，但绕过files3）。

### Q5: 子键（skey）的用途是什么？

子键允许一个主键下存储多个关联对象，主键自动变为文件夹：

```python
f = files('./data')
f.set('user', {'name': 'alice'})        # user.ist（文件）
f.set('user', {'age': 30}, skey='age')  # user.ist/（文件夹）
                                        # user.ist/_.ist  原内容
                                        # user.ist/age.ist 新内容

f['user', '_']      # 读取默认子键（原内容）
f['user', 'age']    # 读取age子键
f.list('user')      # ['_', 'age']  列出所有子键
```

### Q6: 如何在不同脚本间共享对象？

方案A：相同工作目录
```python
# script_a.py
f = files('./shared')
f['model'] = my_model

# script_b.py
f = files('./shared')
model = f['model']
```

方案B：导出为Python代码（无需files3环境）
```python
# 打包
code = files.packpy(r'F:\my_resource')
with open('resource.py', 'w') as f:
    f.write(code)

# 解压
from resource import F3DATA
from files3 import files
files.unpackpy(F3DATA, r'F:\extract_to')
```

### Q7: `error=True`和`error=False`的区别？

- `error=False`（默认）：操作失败返回`F3False`，不抛出异常
- `error=True`：操作失败直接抛出对应异常，方便调试

字典式访问（`f['key']`、`f['key']=v`）强制使用`error=True`。

### Q8: 文件后缀`.ist`是什么？

`.ist`是files3的默认后缀（**I**n**st**ance file），无特殊格式含义，只是标识文件由files3管理。可通过构造参数自定义：
```python
f = files('./data', type='.cfg', sub_type='.sub')
```

### Q9: 数据压缩率如何？

使用lz4压缩，特点是**极快**的压缩/解压速度，压缩率一般（约2-5倍，取决于数据类型）。如需更高压缩率，可使用`pack`的`mode=zipfile.ZIP_LZMA`参数。

### Q10: 如何设置文件夹图标？

```python
from files3.f3utils import SetFolderIcon, RestoreFolderIcon

SetFolderIcon(r'F:\my_folder', r'F:\icon.ico', iconidx=0)
RestoreFolderIcon(r'F:\my_folder')
```

### Q11: F3Mem 和 files 有什么区别？

| 特性 | files (F3Shell) | memfiles (F3Mem) |
|------|----------------|------------------|
| 后端 | 文件系统 | OS 共享内存 |
| 持久化 | 是（磁盘持久） | 是（虚拟磁盘，系统重启前持久） |
| 跨进程 | 通过文件系统 | 直接共享（零拷贝） |
| 磁盘 IO | 有 | 零 |
| 序列化 | cloudpickle + lz4 | cloudpickle写入 / pickle读取 |
| 适用场景 | 配置持久化、数据存储 | 高速缓存、进程间通信 |

### Q12: F3Mem 的数据会持久化吗？

F3Mem 采用**虚拟磁盘模式**。全局守护进程 `f3m` 持续持有所有共享内存引用，用户进程调用 `releaseAll()` 仅关闭自身句柄，数据保留到系统重启。

如需落盘持久化，使用 `save` 方法保存到文件系统：

```python
m = memfiles('my_ns')
m['data'] = large_object
m.save('./backup')  # 持久化到磁盘
```

### Q13: 为什么需要 F3Backend Protocol？

`F3Backend` 使用 `typing.Protocol` 定义统一接口，约束 `F3Shell`（文件系统后端）和 `F3Mem`（共享内存后端）提供一致的方法签名和行为语义。这保证了：

1. 用户可以在两套后端间无缝切换，代码无需修改
2. 新增后端时只需实现 Protocol 即可兼容现有代码
3. 运行时 `isinstance(obj, F3Backend)` 验证接口合规性
