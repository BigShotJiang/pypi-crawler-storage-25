"""
files3 分阶段耗时拆解分析
对每个场景的执行流程进行精细化 profiling，定位瓶颈所在
"""
import os
import sys
import time
import json
import pickle
import shutil
import random
import string
import statistics
import zipfile
import re
from datetime import datetime
from io import BytesIO

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from files3 import files, F3Shell
from files3.f3core import F3Core
from files3.f3info import F3Info
from files3.f3io import f3dumps, f3loads, packtarget, _F3Unpickler
from files3.f3utils import create_random_name
import cloudpickle
import lz4.frame as lzf
import pickletools

TEST_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_perf_profile_tmp')
REPEAT = 5


def ensure_clean():
    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)
    os.makedirs(TEST_DIR, exist_ok=True)


def fmt(t):
    if t < 0.000001:
        return f"{t*1e9:.1f} ns"
    elif t < 0.001:
        return f"{t*1e6:.2f} us"
    elif t < 1:
        return f"{t*1000:.3f} ms"
    else:
        return f"{t:.4f} s"


def pct(part, total):
    if total <= 0:
        return "0.0%"
    return f"{part/total*100:.1f}%"


class StageTimer:
    """分阶段计时器"""
    def __init__(self):
        self.stages = {}
        self._order = []
        self._t0 = None

    def start(self):
        self._t0 = time.perf_counter()

    def mark(self, name):
        t = time.perf_counter()
        if self._t0 is None:
            self._t0 = t
            return
        elapsed = t - self._t0
        self._t0 = t
        if name not in self.stages:
            self.stages[name] = []
            self._order.append(name)
        self.stages[name].append(elapsed)

    def summary(self, title, count=1):
        print(f"\n  [{title}]")
        total = sum(statistics.median(self.stages[k]) for k in self._order)
        for k in self._order:
            med = statistics.median(self.stages[k])
            print(f"    {k:<28} {fmt(med):<14} {pct(med, total):>6}  (per item: {fmt(med/count)})")
        print(f"    {'TOTAL':<28} {fmt(total):<14} {'100.0%':>6}")


def profile_set_flow():
    """拆解 set() 的完整流程"""
    print("\n" + "=" * 70)
    print("【Profiling 1】set() 完整流程拆解")
    print("=" * 70)

    ensure_clean()
    f = files(TEST_DIR)
    info = F3Info(TEST_DIR)
    core = F3Core()

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    for label, obj in test_objs:
        timer = StageTimer()
        for _ in range(REPEAT):
            key = f"key_{label}"
            timer.start()

            # stage: F3Shell 参数校验
            timer.mark("shell_validate")
            skey = None
            error = False

            # stage: F3Info 路径拼接
            _path = info(key, skey)
            timer.mark("path_join")

            # stage: 检查文件是否存在 (os.path.exists)
            _exists = os.path.exists(_path)
            timer.mark("os.path.exists")

            # stage: cloudpickle.dumps
            scp = os.path.abspath(__file__)
            s = cloudpickle.dumps([scp, obj])
            timer.mark("cloudpickle.dumps")

            # stage: pickletools.optimize (skipped)
            # s = pickletools.optimize(s)
            timer.mark("pickletools.optimize")

            # stage: lz4 compress
            s = lzf.compress(s)
            timer.mark("lz4.compress")

            # stage: 文件写入
            open(_path, "wb").write(s)
            timer.mark("file_write")

        timer.summary(f"set({label})")

        # 额外分析：序列化总占比
        ser_keys = ["cloudpickle.dumps", "pickletools.optimize", "lz4.compress"]
        ser_total = sum(statistics.median(timer.stages[k]) for k in ser_keys if k in timer.stages)
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> 序列化(dumps+optimize+compress)占总耗时 {pct(ser_total, total)}")
        print(f"    -> 文件IO占总耗时 {pct(statistics.median(timer.stages['file_write']), total)}")


def profile_get_flow():
    """拆解 get() 的完整流程"""
    print("\n" + "=" * 70)
    print("【Profiling 2】get() 完整流程拆解")
    print("=" * 70)

    ensure_clean()
    f = files(TEST_DIR)
    info = F3Info(TEST_DIR)

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    # 先写入
    for label, obj in test_objs:
        f.set(f"key_{label}", obj)

    for label, obj in test_objs:
        timer = StageTimer()
        for _ in range(REPEAT):
            key = f"key_{label}"
            timer.start()

            # stage: shell 校验
            timer.mark("shell_validate")

            # stage: 路径拼接
            _path = info(key)
            timer.mark("path_join")

            # stage: exists check
            _exists = os.path.exists(_path)
            timer.mark("os.path.exists")

            # stage: 文件读取
            raw = open(_path, 'rb').read()
            timer.mark("file_read")

            # stage: lz4 decompress
            raw = lzf.decompress(raw)
            timer.mark("lz4.decompress")

            # stage: unpickle
            file = BytesIO(raw)
            obj = _F3Unpickler(file).load()
            timer.mark("unpickle")

        timer.summary(f"get({label})")

        de_keys = ["lz4.decompress", "unpickle"]
        de_total = sum(statistics.median(timer.stages[k]) for k in de_keys if k in timer.stages)
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> 反序列化(decompress+unpickle)占总耗时 {pct(de_total, total)}")
        print(f"    -> 文件读取占总耗时 {pct(statistics.median(timer.stages['file_read']), total)}")


def profile_subkey_convert():
    """拆解子键首次转换（文件→文件夹）的每一步"""
    print("\n" + "=" * 70)
    print("【Profiling 3】子键首次转换（文件→文件夹）拆解")
    print("=" * 70)

    ensure_clean()
    f = files(TEST_DIR)
    info = F3Info(TEST_DIR)

    timer = StageTimer()
    for _ in range(REPEAT):
        ensure_clean()
        f.set("user", {"name": "alice"})
        key = "user"
        skey = "age"
        obj = {"age": 30}

        timer.start()

        # stage: 路径拼接 (主键)
        _path = info(key)
        timer.mark("path_join_mkey")

        # stage: 检查原文件是文件
        isfile = os.path.isfile(_path)
        timer.mark("check_isfile")

        # stage: 生成随机名
        rname = create_random_name(16)
        timer.mark("gen_random_name")

        # stage: 创建临时文件夹
        dirname = os.path.dirname(_path)
        tmp_folder = os.path.join(dirname, rname)
        os.mkdir(tmp_folder)
        timer.mark("mkdir_tmp")

        # stage: 移动原文件到临时文件夹
        tmp_file = os.path.join(tmp_folder, '_' + info.stype)
        os.rename(_path, tmp_file)
        timer.mark("move_to_tmp")

        # stage: 重命名临时文件夹为原文件名
        os.rename(tmp_folder, _path)
        timer.mark("rename_tmp")

        # stage: 写入子键文件
        _spath = info(key, skey)
        s = f3dumps(obj)
        open(_spath, "wb").write(s)
        timer.mark("write_skey")

    timer.summary("subkey-first-convert")

    atomic_keys = ["mkdir_tmp", "move_to_tmp", "rename_tmp"]
    atomic_total = sum(statistics.median(timer.stages[k]) for k in atomic_keys)
    total = sum(statistics.median(timer.stages[k]) for k in timer._order)
    print(f"    -> 原子转换操作(mkdir+move+rename)占总耗时 {pct(atomic_total, total)}")


def profile_filter_breakdown():
    """拆解筛选操作：筛选 vs get 的时间占比"""
    print("\n" + "=" * 70)
    print("【Profiling 4】筛选操作：筛选器 vs get 耗时占比")
    print("=" * 70)

    ensure_clean()
    f = files(TEST_DIR)
    for i in range(200):
        f.set(f"key_{i:03d}", {"idx": i})

    info = f._f3info

    # 4a: 全选
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        keys = f._shell_magic_filter_(..., type=False)
        timer.mark("filter_select")
        for k in keys:
            _ = f.get(k.replace(info.type, ''), error=True)
        timer.mark("get_all")
    timer.summary("filter-all-200", count=200)

    # 4b: 正则筛选
    pattern = re.compile(r"key_0[5-9]\d$")
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        keys = f._shell_magic_filter_(pattern, type=False)
        timer.mark("filter_select")
        for k in keys:
            _ = f.get(k.replace(info.type, ''), error=True)
        timer.mark("get_selected")
    timer.summary("filter-regex-50", count=50)

    filter_total = statistics.median(timer.stages["filter_select"])
    get_total = statistics.median(timer.stages["get_selected"])
    total = filter_total + get_total
    print(f"    -> 筛选器解析占总耗时 {pct(filter_total, total)}")
    print(f"    -> get反序列化占总耗时 {pct(get_total, total)}")

    # 4c: 函数筛选
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        keys = f._shell_magic_filter_(lambda n, t: int(n.split("_")[1]) % 2 == 0, type=False)
        timer.mark("filter_select")
        for k in keys:
            _ = f.get(k.replace(info.type, ''), error=True)
        timer.mark("get_selected")
    timer.summary("filter-func-100", count=100)


def profile_iterate_breakdown():
    """拆解遍历操作：listdir vs get 的占比"""
    print("\n" + "=" * 70)
    print("【Profiling 5】遍历操作：listdir vs get 耗时占比")
    print("=" * 70)

    for n in [100, 500]:
        ensure_clean()
        f = files(TEST_DIR)
        for i in range(n):
            f.set(f"k{i:04d}", {"idx": i})

        info = f._f3info

        # keys: 纯 listdir
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            _ = list(os.listdir(info.path))
            timer.mark("os.listdir")
        timer.summary(f"keys-{n}(pure-listdir)", count=n)

        # values: listdir + get
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            keys = []
            for fnametype in os.listdir(info.path):
                fname, ftype = os.path.splitext(fnametype)
                if ftype.lower() == info.type:
                    keys.append(fname)
            timer.mark("listdir+filter")
            for k in keys:
                _ = f.get(k, error=True)
            timer.mark("get_all")
        timer.summary(f"values-{n}", count=n)

        listdir_total = statistics.median(timer.stages["listdir+filter"])
        get_total = statistics.median(timer.stages["get_all"])
        total = listdir_total + get_total
        print(f"    -> listdir+filter 占总耗时 {pct(listdir_total, total)}")
        print(f"    -> get反序列化 占总耗时 {pct(get_total, total)}")


def profile_serialize_breakdown():
    """拆解序列化各子步骤"""
    print("\n" + "=" * 70)
    print("【Profiling 6】序列化各子步骤耗时拆解")
    print("=" * 70)

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    for label, obj in test_objs:
        timer = StageTimer()
        for _ in range(REPEAT):
            scp = os.path.abspath(__file__)

            timer.start()
            s = cloudpickle.dumps([scp, obj])
            timer.mark("cloudpickle.dumps")

            # s = pickletools.optimize(s)
            timer.mark("pickletools.optimize")

            s = lzf.compress(s)
            timer.mark("lz4.compress")

            # 反序列化
            s2 = lzf.decompress(s)
            timer.mark("lz4.decompress")

            file = BytesIO(s2)
            _ = _F3Unpickler(file).load()
            timer.mark("unpickle")

        timer.summary(f"serialize-{label}")

        ser_total = statistics.median(timer.stages["cloudpickle.dumps"]) + \
                    statistics.median(timer.stages["pickletools.optimize"]) + \
                    statistics.median(timer.stages["lz4.compress"])
        de_total = statistics.median(timer.stages["lz4.decompress"]) + \
                   statistics.median(timer.stages["unpickle"])
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)

        print(f"    -> 序列化(dumps+optimize+compress)占总耗时 {pct(ser_total, total)}")
        print(f"    -> 反序列化(decompress+unpickle)占总耗时 {pct(de_total, total)}")
        print(f"    -> dumps / optimize / compress 比例:")
        d = statistics.median(timer.stages["cloudpickle.dumps"])
        o = statistics.median(timer.stages["pickletools.optimize"])
        c = statistics.median(timer.stages["lz4.compress"])
        s = d + o + c
        print(f"       dumps={pct(d,s)}  optimize={pct(o,s)}  compress={pct(c,s)}")


def profile_pack_breakdown():
    """拆解 pack 的各子步骤"""
    print("\n" + "=" * 70)
    print("【Profiling 7】pack/unpack 各子步骤耗时拆解")
    print("=" * 70)

    pack_src = os.path.join(TEST_DIR, "pack_src")
    os.makedirs(pack_src, exist_ok=True)
    for i in range(20):
        with open(os.path.join(pack_src, f"file_{i}.txt"), "w") as fobj:
            fobj.write(''.join(random.choices(string.ascii_letters, k=1000)))

    # pack
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        # zip打包
        buffer = BytesIO()
        dirname, basename = os.path.split(pack_src)
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_STORED) as zf:
            for root, dirs, files_list in os.walk(pack_src):
                for file in files_list:
                    file_path = os.path.join(root, file)
                    arcname_relpath = os.path.relpath(file_path, dirname)
                    zf.write(file_path, arcname=arcname_relpath)
        timer.mark("zip_pack")

        data = buffer.getvalue()
        timer.mark("buffer_getvalue")

        s = cloudpickle.dumps([os.path.abspath(__file__), data])
        timer.mark("cloudpickle.dumps")

        # s = pickletools.optimize(s)
        timer.mark("pickletools.optimize")

        s = lzf.compress(s)
        timer.mark("lz4.compress")

    timer.summary("pack-dir")
    zip_total = statistics.median(timer.stages["zip_pack"])
    ser_total = statistics.median(timer.stages["cloudpickle.dumps"]) + \
                statistics.median(timer.stages["pickletools.optimize"]) + \
                statistics.median(timer.stages["lz4.compress"])
    total = sum(statistics.median(timer.stages[k]) for k in timer._order)
    print(f"    -> zip打包占总耗时 {pct(zip_total, total)}")
    print(f"    -> f3序列化(dumps+optimize+compress)占总耗时 {pct(ser_total, total)}")

    # 预先pack好数据用于unpack测试
    buffer = BytesIO()
    dirname, basename = os.path.split(pack_src)
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_STORED) as zf:
        for root, dirs, files_list in os.walk(pack_src):
            for file in files_list:
                file_path = os.path.join(root, file)
                arcname_relpath = os.path.relpath(file_path, dirname)
                zf.write(file_path, arcname=arcname_relpath)
    packed_data = buffer.getvalue()
    f3data = lzf.compress(cloudpickle.dumps([__file__, packed_data]))

    # unpack
    pack_dst = os.path.join(TEST_DIR, "pack_dst")
    timer = StageTimer()
    for _ in range(REPEAT):
        if os.path.exists(pack_dst):
            shutil.rmtree(pack_dst)

        timer.start()
        s = lzf.decompress(f3data)
        timer.mark("lz4.decompress")

        file = BytesIO(s)
        data = _F3Unpickler(file).load()
        timer.mark("unpickle")

        zf = zipfile.ZipFile(BytesIO(data), 'r')
        timer.mark("zip_open")

        os.makedirs(pack_dst, exist_ok=True)
        for fname in zf.namelist():
            zf.extract(fname, pack_dst)
        timer.mark("zip_extract")

    timer.summary("unpack-dir")
    de_total = statistics.median(timer.stages["lz4.decompress"]) + \
               statistics.median(timer.stages["unpickle"])
    zip_total = statistics.median(timer.stages["zip_open"]) + \
                statistics.median(timer.stages["zip_extract"])
    total = sum(statistics.median(timer.stages[k]) for k in timer._order)
    print(f"    -> f3反序列化占总耗时 {pct(de_total, total)}")
    print(f"    -> zip解压占总耗时 {pct(zip_total, total)}")


def profile_compare_with_pickle():
    """对比 files3 vs pickle 的各子步骤"""
    print("\n" + "=" * 70)
    print("【Profiling 8】files3 vs pickle 子步骤对比（中等字典）")
    print("=" * 70)

    obj = {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}
    fpath = os.path.join(TEST_DIR, "compare.test")

    # files3
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        s = cloudpickle.dumps([os.path.abspath(__file__), obj])
        timer.mark("cloudpickle.dumps")
        # s = pickletools.optimize(s)
        timer.mark("pickletools.optimize")
        s = lzf.compress(s)
        timer.mark("lz4.compress")
        open(fpath + ".f3", "wb").write(s)
        timer.mark("file_write")
        s = open(fpath + ".f3", "rb").read()
        timer.mark("file_read")
        s = lzf.decompress(s)
        timer.mark("lz4.decompress")
        file = BytesIO(s)
        _ = _F3Unpickler(file).load()
        timer.mark("unpickle")
    timer.summary("files3-full")

    # pickle
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        s = pickle.dumps(obj)
        timer.mark("pickle.dumps")
        open(fpath + ".pkl", "wb").write(s)
        timer.mark("file_write")
        s = open(fpath + ".pkl", "rb").read()
        timer.mark("file_read")
        _ = pickle.loads(s)
        timer.mark("pickle.loads")
    timer.summary("pickle-full")

    # 对比
    print("\n  【对比分析】")
    f3_ser = timer.stages  # 这不对，timer被覆盖了。需要用两个timer对象。

    # 重新做一次，分别收集
    f3_timer = StageTimer()
    pk_timer = StageTimer()
    for _ in range(REPEAT):
        # files3
        f3_timer.start()
        s = cloudpickle.dumps([os.path.abspath(__file__), obj])
        f3_timer.mark("serialize")
        s = lzf.compress(s)
        f3_timer.mark("compress")
        open(fpath + ".f3", "wb").write(s)
        f3_timer.mark("file_write")
        s = open(fpath + ".f3", "rb").read()
        f3_timer.mark("file_read")
        s = lzf.decompress(s)
        f3_timer.mark("decompress")
        file = BytesIO(s)
        _ = _F3Unpickler(file).load()
        f3_timer.mark("deserialize")

        # pickle
        pk_timer.start()
        s = pickle.dumps(obj)
        pk_timer.mark("serialize")
        open(fpath + ".pkl", "wb").write(s)
        pk_timer.mark("file_write")
        s = open(fpath + ".pkl", "rb").read()
        pk_timer.mark("file_read")
        _ = pickle.loads(s)
        pk_timer.mark("deserialize")

    print(f"\n    {'阶段':<20} {'files3':<14} {'pickle':<14} {'差距'}")
    print(f"    {'-'*60}")
    for k in ["serialize", "compress", "file_write", "file_read", "decompress", "deserialize"]:
        if k in f3_timer.stages:
            f3_v = statistics.median(f3_timer.stages[k])
            if k in ["compress", "decompress"]:
                print(f"    {k:<20} {fmt(f3_v):<14} {'N/A':<14} {'files3特有'}")
                continue
            pk_v = statistics.median(pk_timer.stages[k])
            ratio = f3_v / pk_v if pk_v > 0 else 0
            print(f"    {k:<20} {fmt(f3_v):<14} {fmt(pk_v):<14} {ratio:.1f}x")

    f3_total = sum(statistics.median(f3_timer.stages[k]) for k in f3_timer._order)
    pk_total = sum(statistics.median(pk_timer.stages[k]) for k in pk_timer._order)
    print(f"    {'-'*60}")
    print(f"    {'TOTAL':<20} {fmt(f3_total):<14} {fmt(pk_total):<14} {f3_total/pk_total:.1f}x")


def profile_file_count_impact():
    """拆解文件数量对各个子步骤的影响"""
    print("\n" + "=" * 70)
    print("【Profiling 9】文件数量对子步骤的影响拆解")
    print("=" * 70)

    for n in [0, 200, 500]:
        ensure_clean()
        f = files(TEST_DIR)
        for i in range(n):
            f.set(f"pre_{i:04d}", {"idx": i})

        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            # listdir（检查文件是否存在时隐含的成本）
            _ = os.listdir(TEST_DIR)
            timer.mark("os.listdir")

            # 路径拼接
            _path = os.path.join(TEST_DIR, "target.ist")
            timer.mark("path_join")

            # os.path.exists
            _ = os.path.exists(_path)
            timer.mark("os.path.exists")

            # 序列化
            s = f3dumps({"test": True})
            timer.mark("serialize")

            # 文件写入
            open(_path, "wb").write(s)
            timer.mark("file_write")

        timer.summary(f"write-with-{n}-files")

        listdir_time = statistics.median(timer.stages["os.listdir"])
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> os.listdir 占总耗时 {pct(listdir_time, total)} (files3内部没有显式listdir，但exists可能有影响)")


if __name__ == '__main__':
    print("=" * 70)
    print("files3 分阶段耗时拆解分析")
    print(f"重复次数: {REPEAT} | Python: {sys.version.split()[0]}")
    print("=" * 70)

    profile_set_flow()
    profile_get_flow()
    profile_subkey_convert()
    profile_filter_breakdown()
    profile_iterate_breakdown()
    profile_serialize_breakdown()
    profile_pack_breakdown()
    profile_compare_with_pickle()
    profile_file_count_impact()

    print("\n" + "=" * 70)
    print("分析完成")
    print("=" * 70)

    if os.path.exists(TEST_DIR):
        shutil.rmtree(TEST_DIR)
