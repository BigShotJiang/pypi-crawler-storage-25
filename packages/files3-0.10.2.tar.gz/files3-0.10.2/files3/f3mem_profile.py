"""
f3mem 分阶段耗时拆解分析
对 F3Mem 共享内存后端的执行流程进行精细化 profiling
"""
import os
import sys
import time
import pickle
import struct
import shutil
import statistics
import tempfile
from io import BytesIO

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from files3.f3mem import F3Mem, _MemIndex, _MemDumps, _MemLoads, _LIVE_BLOCKS
from files3.f3shell import F3Shell
from files3.f3bool import F3True, F3False
from multiprocessing import shared_memory
import cloudpickle

REPEAT = 5


_COUNTER = [0]

def _cleanup():
    """清理所有测试数据。"""
    for _ns in ['pf_t1', 'pf_t2', 'pf_t3', 'pf_t4', 'pf_t5',
                'pf_cmp', 'pf_shell', 'pf_count_10', 'pf_count_100',
                'pf_count_500', 'pf_ttl', 'pf_sub', 'pf_over']:
        try:
            _m = F3Mem(_ns)
            _m.clear()
        except Exception:
            pass
    F3Mem.releaseAll()
    for _name, _shm in list(_LIVE_BLOCKS.items()):
        try:
            _shm.close()
        except Exception:
            pass
    _LIVE_BLOCKS.clear()
    _COUNTER[0] = 0


def fmt(t):
    if t < 0.000001:
        return f"{t*1e9:.1f} ns"
    elif t < 0.001:
        return f"{t*1e6:.2f} us"
    elif t < 1:
        return f"{t*1000:.3f} ms"
    else:
        return f"{t:.4f} s"


def pct(part, total):
    if total <= 0:
        return "0.0%"
    return f"{part/total*100:.1f}%"


class StageTimer:
    def __init__(self):
        self.stages = {}
        self._order = []
        self._t0 = None

    def start(self):
        self._t0 = time.perf_counter()

    def mark(self, name):
        t = time.perf_counter()
        if self._t0 is None:
            self._t0 = t
            return
        elapsed = t - self._t0
        self._t0 = t
        if name not in self.stages:
            self.stages[name] = []
            self._order.append(name)
        self.stages[name].append(elapsed)

    def summary(self, title, count=1):
        print(f"\n  [{title}]")
        total = sum(statistics.median(self.stages[k]) for k in self._order)
        for k in self._order:
            med = statistics.median(self.stages[k])
            print(f"    {k:<28} {fmt(med):<14} {pct(med,total):>6}  (per item: {fmt(med/count)})")
        print(f"    {'TOTAL':<28} {fmt(total):<14} {'100.0%':>6}")


def profile_set_flow():
    print("\n" + "=" * 70)
    print("【Profiling 1】set() 完整流程拆解")
    print("=" * 70)

    _cleanup()

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    for label, obj in test_objs:
        m = F3Mem('pf_t1')
        timer = StageTimer()
        for _ in range(REPEAT):
            key = f"key_{label}"
            timer.start()

            # stage: cloudpickle.dumps
            data = cloudpickle.dumps(obj, protocol=5)
            timer.mark("cloudpickle.dumps")

            # stage: 创建共享内存块
            _size = len(data)
            _h = __import__('hashlib').sha256(f"pf_t1:{key}/_".encode()).hexdigest()[:24]
            _COUNTER[0] += 1
            _shmname = f"f3_{_h}_{os.getpid()}_{_COUNTER[0]}"
            _shm = shared_memory.SharedMemory(name=_shmname, create=True, size=_size)
            timer.mark("shm_create")

            # stage: 写入数据
            _shm.buf[:_size] = data
            timer.mark("shm_write")

            # stage: 索引写入 (含 read + write)
            _idx = F3Mem._IDX
            with _idx._lock:
                _cache = _idx._read()
                _cache[f"pf_t1:{key}/_"] = (_shmname, _size, None)
                _idx._write(_cache)
            timer.mark("idx_write")

            # stage: hold 持久引用
            _idx.hold(_shmname, _shm)
            timer.mark("hold_ref")

        timer.summary(f"set({label})")

        dumps_t = statistics.median(timer.stages["cloudpickle.dumps"])
        shm_t = statistics.median(timer.stages["shm_create"]) + statistics.median(timer.stages["shm_write"])
        idx_t = statistics.median(timer.stages["idx_write"])
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> 序列化(dumps) 占总耗时 {pct(dumps_t, total)}")
        print(f"    -> 共享内存(create+write) 占总耗时 {pct(shm_t, total)}")
        print(f"    -> 索引读写 占总耗时 {pct(idx_t, total)}")

    _cleanup()


def profile_get_flow():
    print("\n" + "=" * 70)
    print("【Profiling 2】get() 完整流程拆解")
    print("=" * 70)

    _cleanup()

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    m = F3Mem('pf_t2')
    for label, obj in test_objs:
        m.set(f"key_{label}", obj)

    for label, obj in test_objs:
        timer = StageTimer()
        _fk = f"pf_t2:key_{label}/_"
        for _ in range(REPEAT):
            timer.start()

            # stage: 索引读取
            _idx = F3Mem._IDX
            with _idx._lock:
                _cache = _idx._read()
                _rec = _cache.get(_fk)
            timer.mark("idx_read")

            # stage: attach 共享内存
            _shmname = _rec[0]
            _size = _rec[1]
            _shm = shared_memory.SharedMemory(name=_shmname)
            timer.mark("shm_attach")

            # stage: 读取 bytes
            _data = bytes(_shm.buf[:_size])
            timer.mark("shm_read")

            # stage: pickle.loads
            _shm.close()
            _result = pickle.loads(_data)
            timer.mark("pickle.loads")

        timer.summary(f"get({label})")

        idx_t = statistics.median(timer.stages["idx_read"])
        shm_t = statistics.median(timer.stages["shm_attach"]) + statistics.median(timer.stages["shm_read"])
        load_t = statistics.median(timer.stages["pickle.loads"])
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> 索引读取 占总耗时 {pct(idx_t, total)}")
        print(f"    -> 共享内存(attach+read) 占总耗时 {pct(shm_t, total)}")
        print(f"    -> 反序列化(pickle.loads) 占总耗时 {pct(load_t, total)}")

    _cleanup()


def profile_key_count():
    print("\n" + "=" * 70)
    print("【Profiling 3】key 数量对操作的影响")
    print("=" * 70)

    for n in [10, 100, 500]:
        _cleanup()
        m = F3Mem(f'pf_count_{n}')

        # 先写入 n 个 key
        for i in range(n):
            m.set(f"k{i:04d}", {"idx": i})

        # set 一个新 key
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            m.set("new_key", {"test": True})
            timer.mark("set_one")
        timer.summary(f"set-one-with-{n}-keys")

        # get 一个 key
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            _ = m.get("k0001")
            timer.mark("get_one")
        timer.summary(f"get-one-with-{n}-keys")

        # keys() 遍历
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            _ = list(m.keys())
            timer.mark("keys_all")
        timer.summary(f"keys-all-with-{n}-keys", count=n)

        # walk()
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            _ = list(m.walk())
            timer.mark("walk_all")
        timer.summary(f"walk-all-with-{n}-keys", count=n)

    _cleanup()


def profile_ttl():
    print("\n" + "=" * 70)
    print("【Profiling 4】TTL 过期检查开销")
    print("=" * 70)

    _cleanup()
    m = F3Mem('pf_ttl')

    # 写入 100 个 key，一半有 TTL
    for i in range(100):
        if i % 2 == 0:
            m.set(f"k{i:03d}", {"idx": i}, ttl=3600)
        else:
            m.set(f"k{i:03d}", {"idx": i})

    # get 时触发 TTL 检查
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        for i in range(100):
            _ = m.get(f"k{i:03d}")
        timer.mark("get_100_with_ttl")
    timer.summary("get-100-mixed-ttl", count=100)

    # keys() 时触发批量 TTL 检查
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        _ = list(m.keys())
        timer.mark("keys_100_with_ttl")
    timer.summary("keys-100-mixed-ttl", count=100)

    _cleanup()


def profile_clear():
    print("\n" + "=" * 70)
    print("【Profiling 5】clear() 性能")
    print("=" * 70)

    for n in [10, 100, 500]:
        _cleanup()
        m = F3Mem('pf_t3')
        for i in range(n):
            m.set(f"k{i:04d}", {"idx": i})

        timer = StageTimer()
        for _ in range(REPEAT):
            # 重新创建以隔离
            m = F3Mem('pf_t3')
            timer.start()
            m.clear()
            timer.mark("clear")
            # 重新写入用于下一轮
            for i in range(n):
                m.set(f"k{i:04d}", {"idx": i})
        timer.summary(f"clear-{n}-keys", count=n)

    _cleanup()


def profile_overwrite():
    print("\n" + "=" * 70)
    print("【Profiling 6】覆盖写入（旧块清理 + 新块创建）")
    print("=" * 70)

    _cleanup()
    m = F3Mem('pf_over')
    obj = {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}
    m.set("key", obj)

    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        m.set("key", obj)
        timer.mark("overwrite")
    timer.summary("overwrite-medium")

    # 拆解
    _fk = "pf_over:key/_"
    timer = StageTimer()
    for _ in range(REPEAT):
        data = cloudpickle.dumps(obj, protocol=5)
        _size = len(data)
        timer.start()

        # 获取旧记录
        _idx = F3Mem._IDX
        with _idx._lock:
            _cache = _idx._read()
            _old = _cache.get(_fk)
        timer.mark("idx_read_old")

        # 清理旧块
        if _old:
            _oldname = _old[0]
            _live = _LIVE_BLOCKS.pop(_oldname, None)
            if _live:
                _live.close()
            try:
                _s = shared_memory.SharedMemory(name=_oldname)
                _s.close()
                _s.unlink()
            except Exception:
                pass
        timer.mark("drop_old")

        # 创建新块
        _h = __import__('hashlib').sha256(_fk.encode()).hexdigest()[:24]
        _COUNTER[0] += 1
        _shmname = f"f3_{_h}_{os.getpid()}_{_COUNTER[0]}"
        _shm = shared_memory.SharedMemory(name=_shmname, create=True, size=_size)
        _shm.buf[:_size] = data
        timer.mark("shm_create_new")

        # 更新索引
        with _idx._lock:
            _cache = _idx._read()
            _cache[_fk] = (_shmname, _size, None)
            _idx._write(_cache)
        timer.mark("idx_write_new")

        _idx.hold(_shmname, _shm)
        timer.mark("hold_new")

    timer.summary("overwrite-breakdown")
    _cleanup()


def profile_subkey():
    print("\n" + "=" * 70)
    print("【Profiling 7】子键操作开销")
    print("=" * 70)

    _cleanup()
    m = F3Mem('pf_sub')

    obj = {"name": "alice"}

    # 无子键写入
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        m.set("user", obj)
        timer.mark("set_no_skey")
    timer.summary("set-no-skey")

    # 带子键写入
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        m.set("user", obj, skey="age")
        timer.mark("set_with_skey")
    timer.summary("set-with-skey")

    # 读取子键
    m.set("user", obj, skey="age")
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        _ = m.get("user", "age")
        timer.mark("get_skey")
    timer.summary("get-skey")

    # walk 带子键
    m.set("user", obj, skey="email")
    timer = StageTimer()
    for _ in range(REPEAT):
        timer.start()
        _ = list(m.walk())
        timer.mark("walk_with_skey")
    timer.summary("walk-with-skey")

    _cleanup()


def profile_compare_shell():
    print("\n" + "=" * 70)
    print("【Profiling 8】F3Mem vs F3Shell 子步骤对比")
    print("=" * 70)

    _cleanup()
    tmpdir = tempfile.mkdtemp()

    obj = {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}

    # F3Mem
    mem_timer = StageTimer()
    m = F3Mem('pf_cmp')
    for _ in range(REPEAT):
        mem_timer.start()
        m.set("key", obj)
        mem_timer.mark("mem_set")
        _ = m.get("key")
        mem_timer.mark("mem_get")
    mem_timer.summary("F3Mem-full")

    # F3Shell
    shell_timer = StageTimer()
    f = F3Shell(tmpdir)
    for _ in range(REPEAT):
        shell_timer.start()
        f.set("key", obj)
        shell_timer.mark("shell_set")
        _ = f.get("key")
        shell_timer.mark("shell_get")
    shell_timer.summary("F3Shell-full")

    # 对比
    print("\n  【对比分析】")
    print(f"    {'操作':<20} {'F3Mem':<14} {'F3Shell':<14} {'差距'}")
    print(f"    {'-'*60}")
    for op in ["mem_set", "mem_get"]:
        mem_v = statistics.median(mem_timer.stages[op])
        shell_op = op.replace("mem_", "shell_")
        shell_v = statistics.median(shell_timer.stages[shell_op])
        ratio = shell_v / mem_v if mem_v > 0 else 0
        print(f"    {op:<20} {fmt(mem_v):<14} {fmt(shell_v):<14} {ratio:.1f}x")

    mem_total = statistics.median(mem_timer.stages["mem_set"]) + statistics.median(mem_timer.stages["mem_get"])
    shell_total = statistics.median(shell_timer.stages["shell_set"]) + statistics.median(shell_timer.stages["shell_get"])
    print(f"    {'-'*60}")
    print(f"    {'TOTAL':<20} {fmt(mem_total):<14} {fmt(shell_total):<14} {shell_total/mem_total:.1f}x")

    _cleanup()
    shutil.rmtree(tmpdir, ignore_errors=True)


def profile_serialize_breakdown():
    print("\n" + "=" * 70)
    print("【Profiling 9】序列化子步骤拆解")
    print("=" * 70)

    test_objs = [
        ("small-dict", {"id": 42, "name": "test"}),
        ("medium-dict", {"users": [{"id": i, "name": f"u{i}"} for i in range(100)]}),
        ("large-dict", {"records": [{"id": i, "data": os.urandom(200)} for i in range(5000)]}),
    ]

    for label, obj in test_objs:
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            s = cloudpickle.dumps(obj, protocol=5)
            timer.mark("cloudpickle.dumps")

            s2 = pickle.loads(s)
            timer.mark("pickle.loads")

        timer.summary(f"serialize-{label}")

        dumps_t = statistics.median(timer.stages["cloudpickle.dumps"])
        loads_t = statistics.median(timer.stages["pickle.loads"])
        total = sum(statistics.median(timer.stages[k]) for k in timer._order)
        print(f"    -> dumps / loads 比例: {pct(dumps_t,total)} / {pct(loads_t,total)}")


def profile_index_read():
    print("\n" + "=" * 70)
    print("【Profiling 10】索引块读写性能")
    print("=" * 70)

    for n in [10, 100, 500, 1000]:
        _cleanup()
        m = F3Mem('pf_t4')
        for i in range(n):
            m.set(f"k{i:04d}", {"idx": i})

        _idx = F3Mem._IDX

        # 索引读取
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            with _idx._lock:
                _cache = _idx._read()
            timer.mark("idx_read")
        timer.summary(f"idx-read-{n}-keys")

        # 索引写入（覆盖一个 key）
        timer = StageTimer()
        for _ in range(REPEAT):
            timer.start()
            with _idx._lock:
                _cache = _idx._read()
                _cache[f"pf_t4:k0001/_"] = ("dummy", 10, None)
                _idx._write(_cache)
            timer.mark("idx_write")
        timer.summary(f"idx-write-{n}-keys")

        read_t = statistics.median(timer.stages["idx_write"])
        print(f"    -> 索引 pickle 数据量: {len(pickle.dumps(_cache, protocol=5))} bytes")

    _cleanup()


if __name__ == '__main__':
    print("=" * 70)
    print("F3Mem 分阶段耗时拆解分析")
    print(f"重复次数: {REPEAT} | Python: {sys.version.split()[0]}")
    print("=" * 70)

    profile_set_flow()
    profile_get_flow()
    profile_key_count()
    profile_ttl()
    profile_clear()
    profile_overwrite()
    profile_subkey()
    profile_compare_shell()
    profile_serialize_breakdown()
    profile_index_read()

    print("\n" + "=" * 70)
    print("分析完成")
    print("=" * 70)

    _cleanup()
