"""
files3 性能测试与耗时分析
覆盖多种工作场景，对比不同操作模式
"""
import os
import sys
import time
import json
import pickle
import shutil
import random
import string
import statistics
from datetime import datetime

# 将files3目录加入路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from files3 import files, f3, F3Shell, F3Core
from files3.f3io import f3dumps, f3loads

# ==================== 常量 ====================
TEST_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_perf_test_tmp')
REPEAT = 5  # 每项测试重复次数，取中位数


# ==================== 计时工具 ====================
class Timer:
    def __init__(self):
        self.records = []

    def __enter__(self):
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *args):
        self.t1 = time.perf_counter()
        self.elapsed = self.t1 - self.t0
        self.records.append(self.elapsed)

    def median(self):
        return statistics.median(self.records)

    def mean(self):
        return statistics.mean(self.records)

    def stdev(self):
        if len(self.records) < 2:
            return 0.0
        return statistics.stdev(self.records)

    def reset(self):
        self.records = []


def fmt(t):
    """格式化时间：秒或毫秒"""
    if t < 0.001:
        return f"{t*1e6:.2f} µs"
    elif t < 1:
        return f"{t*1000:.3f} ms"
    else:
        return f"{t:.4f} s"


def fmtrate(t, n, unit="ops"):
    """格式化速率"""
    if t <= 0:
        return "N/A"
    rate = n / t
    if rate >= 1e6:
        return f"{rate/1e6:.2f} M{unit}/s"
    elif rate >= 1e3:
        return f"{rate/1e3:.2f} K{unit}/s"
    else:
        return f"{rate:.2f} {unit}/s"


# ==================== 测试数据生成 ====================
def gen_small():
    """小对象：简单字典"""
    return {"id": 42, "name": "test", "flag": True}


def gen_medium():
    """中等对象：嵌套结构"""
    return {
        "users": [
            {"id": i, "name": f"user_{i}", "email": f"user_{i}@example.com"}
            for i in range(100)
        ],
        "metadata": {"version": "1.0", "created": str(datetime.now())},
        "settings": {"debug": False, "timeout": 30.5, "retries": 3}
    }


def gen_large():
    """大对象：大量数据"""
    return {
        "records": [
            {
                "id": i,
                "data": ''.join(random.choices(string.ascii_letters, k=200)),
                "tags": random.sample(["a", "b", "c", "d", "e"], k=random.randint(1, 3)),
                "score": random.random() * 100
            }
            for i in range(5000)
        ]
    }


def gen_custom_class():
    """自定义类（需要cloudpickle）"""
    class Point:
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def dist(self):
            return (self.x**2 + self.y**2) ** 0.5
        def __repr__(self):
            return f"Point({self.x}, {self.y})"

    class Container:
        def __init__(self):
            self.points = [Point(random.random(), random.random()) for _ in range(100)]
            self.name = "test_container"
        def total_dist(self):
            return sum(p.dist() for p in self.points)

    return Container()


def gen_bytes(n):
    """生成n字节的数据"""
    return os.urandom(n)


# ==================== 测试场景 ====================
class TestSuite:
    def __init__(self, path):
        self.path = path
        self.f = files(path)
        self.results = []

    def cleanup(self):
        if os.path.exists(self.path):
            shutil.rmtree(self.path)
        os.makedirs(self.path, exist_ok=True)
        self.f = files(self.path)

    def report(self, name, timer, count=1, note=""):
        med = timer.median()
        mean = timer.mean()
        stdev = timer.stdev()
        self.results.append({
            "name": name,
            "median": med,
            "mean": mean,
            "stdev": stdev,
            "count": count,
            "rate": count / med if med > 0 else 0,
            "note": note
        })
        rate_str = fmtrate(med, count)
        print(f"  [{name}] 中位数={fmt(med)}  均值={fmt(mean)}  标准差={fmt(stdev)}  速率={rate_str}  {note}")

    def run(self):
        print("=" * 80)
        print("files3 性能测试报告")
        print(f"测试目录: {self.path}")
        print(f"重复次数: {REPEAT}")
        print(f"Python: {sys.version}")
        print(f"时间: {datetime.now()}")
        print("=" * 80)

        # ---- 场景1: 基础CRUD，不同对象大小 ----
        self.scene_crud_sizes()

        # ---- 场景2: 子键操作 ----
        self.scene_subkey()

        # ---- 场景3: 批量操作 ----
        self.scene_batch()

        # ---- 场景4: 筛选操作 ----
        self.scene_filter()

        # ---- 场景5: 遍历操作（keys/values/items/walk/list） ----
        self.scene_iterate()

        # ---- 场景6: 序列化对比（files3 vs pickle vs json） ----
        self.scene_serialize_compare()

        # ---- 场景7: 文件数量对读写的影响 ----
        self.scene_file_count()

        # ---- 场景8: pack/unpack ----
        self.scene_pack()

        # ---- 汇总 ----
        self.summary()

    # ---- 场景1: 基础CRUD，不同对象大小 ----
    def scene_crud_sizes(self):
        print("\n" + "─" * 60)
        print("【场景1】基础CRUD — 不同对象大小")
        print("─" * 60)

        test_data = [
            ("small", gen_small(), "简单字典~100B"),
            ("medium", gen_medium(), "嵌套结构~15KB"),
            ("large", gen_large(), "大数据~1.2MB"),
            ("custom", gen_custom_class(), "自定义类+cloudpickle"),
        ]

        for label, obj, desc in test_data:
            self.cleanup()
            timer = Timer()
            for _ in range(REPEAT):
                with timer:
                    self.f.set(label, obj, error=True)
            self.report(f"set-{label}", timer, 1, f"写入 {desc}")

            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = self.f.get(label, error=True)
            self.report(f"get-{label}", timer, 1, f"读取 {desc}")

            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    self.f.has(label)
            self.report(f"has-{label}", timer, 1, f"检查 {desc}")

            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    self.f.delete(label)
            self.report(f"del-{label}", timer, 1, f"删除 {desc}")

    # ---- 场景2: 子键操作 ----
    def scene_subkey(self):
        print("\n" + "─" * 60)
        print("【场景2】子键操作 — 单主键多子键")
        print("─" * 60)

        self.cleanup()

        # 2a: 首次写入子键（触发文件→文件夹转换）
        timer = Timer()
        for _ in range(REPEAT):
            self.cleanup()
            with timer:
                self.f.set("user", {"name": "alice"})
                self.f.set("user", {"age": 30}, skey="age")
        self.report("subkey-first-convert", timer, 1, "首次子键，文件→文件夹转换")

        # 2b: 后续追加子键
        self.cleanup()
        self.f.set("user", {"name": "alice"})
        self.f.set("user", {"age": 30}, skey="age")
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                self.f.set("user", {"city": "beijing"}, skey="city")
        self.report("subkey-append", timer, 1, "已有文件夹追加子键")

        # 2c: 读取子键
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f.get("user", skey="age", error=True)
        self.report("subkey-get", timer, 1, "读取子键")

        # 2d: list子键
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f.list("user")
        self.report("subkey-list", timer, 1, "列出子键")

        # 2e: 批量子键写入
        self.cleanup()
        timer.reset()
        n = 50
        for _ in range(REPEAT):
            self.cleanup()
            with timer:
                for i in range(n):
                    self.f.set("batch", {"idx": i}, skey=f"k{i:03d}")
        self.report(f"subkey-batch-{n}", timer, n, f"批量写入{n}个子键")

    # ---- 场景3: 批量操作 ----
    def scene_batch(self):
        print("\n" + "─" * 60)
        print("【场景3】批量操作 — 不同数量级")
        print("─" * 60)

        for n in [10, 100, 500]:
            self.cleanup()
            data = {f"k{i:04d}": gen_small() for i in range(n)}

            # 批量写入
            timer = Timer()
            for _ in range(REPEAT):
                self.cleanup()
                with timer:
                    for k, v in data.items():
                        self.f.set(k, v)
            self.report(f"batch-set-{n}", timer, n, f"逐个写入{n}个key")

            # 批量读取
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    for k in data:
                        _ = self.f.get(k)
            self.report(f"batch-get-{n}", timer, n, f"逐个读取{n}个key")

            # 批量删除
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    for k in data:
                        self.f.delete(k)
                # 重新写入以便下次删除
                for k, v in data.items():
                    self.f.set(k, v)
            self.report(f"batch-del-{n}", timer, n, f"逐个删除{n}个key")

            # 字典式全删
            self.cleanup()
            for k, v in data.items():
                self.f.set(k, v)
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    del self.f[...]
                # 重新写入
                for k, v in data.items():
                    self.f.set(k, v)
            self.report(f"batch-del-all-{n}", timer, n, f"del f[...] 删除全部")

            # 批量同值写入（筛选语法）
            self.cleanup()
            keys = [f"k{i:04d}" for i in range(n)]
            timer.reset()
            for _ in range(REPEAT):
                self.cleanup()
                with timer:
                    self.f[keys] = gen_small()
            self.report(f"batch-sameval-{n}", timer, n, f"筛选语法批量同值写入{n}个key")

    # ---- 场景4: 筛选操作 ----
    def scene_filter(self):
        print("\n" + "─" * 60)
        print("【场景4】筛选操作 — 不同筛选器类型")
        print("─" * 60)

        self.cleanup()
        import re
        for i in range(200):
            self.f.set(f"key_{i:03d}", {"idx": i})

        # 4a: 精确匹配
        timer = Timer()
        for _ in range(REPEAT):
            with timer:
                _ = self.f["key_050"]
        self.report("filter-exact", timer, 1, "精确匹配单key")

        # 4b: 全选
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f[...]
        self.report("filter-all-200", timer, 200, "全选200个key")

        # 4c: 正则筛选
        pattern = re.compile(r"key_0[5-9]\d$")
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f[pattern]
        self.report("filter-regex", timer, 50, "正则匹配约50个key")

        # 4d: 函数筛选
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f[lambda n, t: int(n.split("_")[1]) % 2 == 0]
        self.report("filter-func", timer, 100, "函数筛选偶数key约100个")

        # 4e: 列表多条件
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                _ = self.f[["key_001", "key_050", "key_099", re.compile(r"key_1\d{2}$")]]
        self.report("filter-list", timer, 53, "列表多条件并集约53个")

    # ---- 场景5: 遍历操作 ----
    def scene_iterate(self):
        print("\n" + "─" * 60)
        print("【场景5】遍历操作 — keys/values/items/walk/list")
        print("─" * 60)

        for n in [100, 500]:
            self.cleanup()
            for i in range(n):
                self.f.set(f"k{i:04d}", {"idx": i})
                if i % 5 == 0:
                    self.f.set(f"k{i:04d}", {"sub": True}, skey="sub")

            # keys
            timer = Timer()
            for _ in range(REPEAT):
                with timer:
                    _ = list(self.f.keys())
            self.report(f"iter-keys-{n}", timer, n, f"keys遍历{n}个")

            # values
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = list(self.f.values())
            self.report(f"iter-values-{n}", timer, n, f"values遍历{n}个（含get）")

            # items
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = list(self.f.items())
            self.report(f"iter-items-{n}", timer, n, f"items遍历{n}个（含get）")

            # walk
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = list(self.f.walk())
            self.report(f"iter-walk-{n}", timer, n, f"walk递归遍历（含子键）")

            # list（无参）
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = self.f.list()
            self.report(f"iter-list-{n}", timer, n, f"list()列举{n}个")

    # ---- 场景6: 序列化对比 ----
    def scene_serialize_compare(self):
        print("\n" + "─" * 60)
        print("【场景6】序列化对比 — files3 vs pickle vs json")
        print("─" * 60)

        test_cases = [
            ("small-dict", gen_small()),
            ("medium-dict", gen_medium()),
            ("custom-class", gen_custom_class()),
        ]

        for label, obj in test_cases:
            # files3 dumps/loads
            timer = Timer()
            for _ in range(REPEAT):
                with timer:
                    s = f3dumps(obj)
                    _ = f3loads(s)
            self.report(f"ser-f3-{label}", timer, 1, "files3 dumps+loads")

            # pickle
            try:
                timer.reset()
                for _ in range(REPEAT):
                    with timer:
                        s = pickle.dumps(obj)
                        _ = pickle.loads(s)
                self.report(f"ser-pickle-{label}", timer, 1, "pickle dumps+loads")
            except Exception as e:
                print(f"  [ser-pickle-{label}] 跳过: {e}")

            # json（仅字典类数据）
            if label != "custom-class":
                timer.reset()
                for _ in range(REPEAT):
                    with timer:
                        s = json.dumps(obj).encode()
                        _ = json.loads(s.decode())
                self.report(f"ser-json-{label}", timer, 1, "json dumps+loads")

            # 对比文件写入
            self.cleanup()
            fpath = os.path.join(self.path, "testfile")

            # files3
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    s = f3dumps(obj)
                    open(fpath + ".f3", "wb").write(s)
                    s = open(fpath + ".f3", "rb").read()
                    _ = f3loads(s)
            self.report(f"file-f3-{label}", timer, 1, "files3 含文件IO")

            # pickle
            if label != "custom-class":
                timer.reset()
                for _ in range(REPEAT):
                    with timer:
                        s = pickle.dumps(obj)
                        open(fpath + ".pkl", "wb").write(s)
                        s = open(fpath + ".pkl", "rb").read()
                        _ = pickle.loads(s)
                self.report(f"file-pickle-{label}", timer, 1, "pickle 含文件IO")

    # ---- 场景7: 文件数量对读写的影响 ----
    def scene_file_count(self):
        print("\n" + "─" * 60)
        print("【场景7】文件数量对单key读写的影响")
        print("─" * 60)

        for n in [0, 50, 200, 500]:
            self.cleanup()
            # 预先创建n个文件
            for i in range(n):
                self.f.set(f"pre_{i:04d}", {"idx": i})

            # 写入新key
            timer = Timer()
            for _ in range(REPEAT):
                with timer:
                    self.f.set("target", {"test": True})
            self.report(f"write-with-{n}-files", timer, 1, f"目录已有{n}个文件时写入")

            # 读取新key
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = self.f.get("target")
            self.report(f"read-with-{n}-files", timer, 1, f"目录已有{n}个文件时读取")

            # has检查
            timer.reset()
            for _ in range(REPEAT):
                with timer:
                    _ = self.f.has("target")
            self.report(f"has-with-{n}-files", timer, 1, f"目录已有{n}个文件时has检查")

    # ---- 场景8: pack/unpack ----
    def scene_pack(self):
        print("\n" + "─" * 60)
        print("【场景8】pack/unpack — 文件/目录打包")
        print("─" * 60)

        # 创建测试目录
        pack_src = os.path.join(TEST_DIR, "pack_src")
        os.makedirs(pack_src, exist_ok=True)
        for i in range(20):
            with open(os.path.join(pack_src, f"file_{i}.txt"), "w") as fobj:
                fobj.write(''.join(random.choices(string.ascii_letters, k=1000)))

        # pack
        timer = Timer()
        for _ in range(REPEAT):
            with timer:
                data = F3Shell.pack(pack_src, error=True)
        self.report("pack-dir", timer, 1, f"打包目录({20}文件)")

        # unpack
        pack_dst = os.path.join(TEST_DIR, "pack_dst")
        timer.reset()
        for _ in range(REPEAT):
            if os.path.exists(pack_dst):
                shutil.rmtree(pack_dst)
            with timer:
                F3Shell.unpack(data, pack_dst, overwrite=True, error=True)
        self.report("unpack-dir", timer, 1, f"解压到目录")

        # packpy
        timer.reset()
        for _ in range(REPEAT):
            with timer:
                code = F3Shell.packpy(pack_src, error=True)
        self.report("packpy", timer, 1, f"打包为Python代码")

        # unpackpy
        timer.reset()
        for _ in range(REPEAT):
            if os.path.exists(pack_dst):
                shutil.rmtree(pack_dst)
            with timer:
                F3Shell.unpackpy(code, pack_dst, overwrite=True, error=True)
        self.report("unpackpy", timer, 1, f"从Python代码解压")

    # ---- 汇总 ----
    def summary(self):
        print("\n" + "=" * 80)
        print("【汇总表】所有测试项目中位数耗时")
        print("=" * 80)
        print(f"{'场景':<35} {'中位数':<14} {'速率':<16} {'说明'}")
        print("-" * 80)
        for r in self.results:
            rate_str = fmtrate(r["median"], r["count"])
            print(f"{r['name']:<35} {fmt(r['median']):<14} {rate_str:<16} {r['note']}")
        print("=" * 80)

        # 关键洞察
        print("\n【关键洞察】")

        # 找出最快和最慢的写入
        writes = [r for r in self.results if "set-" in r["name"] or "write-" in r["name"]]
        if writes:
            fastest = min(writes, key=lambda x: x["median"])
            slowest = max(writes, key=lambda x: x["median"])
            print(f"  • 最快写入: {fastest['name']} ({fmt(fastest['median'])})")
            print(f"  • 最慢写入: {slowest['name']} ({fmt(slowest['median'])})")

        # 读取vs写入
        for suffix in ["small", "medium", "large"]:
            set_r = next((r for r in self.results if r["name"] == f"set-{suffix}"), None)
            get_r = next((r for r in self.results if r["name"] == f"get-{suffix}"), None)
            if set_r and get_r:
                ratio = set_r["median"] / get_r["median"]
                print(f"  • {suffix}: 写入/读取比 = {ratio:.2f}x")

        # 批量效率
        for n in [100, 500]:
            batch = next((r for r in self.results if r["name"] == f"batch-set-{n}"), None)
            single = next((r for r in self.results if r["name"] == "set-small"), None)
            if batch and single:
                per_item = batch["median"] / n
                print(f"  • 批量{n}个: 平均每个 {fmt(per_item)} (单次={fmt(single['median'])})")

        # 文件数量影响
        base = next((r for r in self.results if r["name"] == "write-with-0-files"), None)
        if base:
            for n in [50, 200, 500]:
                r = next((r for r in self.results if r["name"] == f"write-with-{n}-files"), None)
                if r:
                    slowdown = r["median"] / base["median"]
                    print(f"  • 目录{n}个文件时写入变慢: {slowdown:.2f}x")

        # 序列化对比
        for label in ["small-dict", "medium-dict"]:
            f3_r = next((r for r in self.results if r["name"] == f"ser-f3-{label}"), None)
            pkl_r = next((r for r in self.results if r["name"] == f"ser-pickle-{label}"), None)
            if f3_r and pkl_r:
                ratio = f3_r["median"] / pkl_r["median"]
                print(f"  • {label}: files3/pickle 比 = {ratio:.2f}x (cloudpickle+lz4开销)")

        # 清理
        print(f"\n清理测试目录: {TEST_DIR}")
        if os.path.exists(TEST_DIR):
            shutil.rmtree(TEST_DIR)


if __name__ == '__main__':
    suite = TestSuite(TEST_DIR)
    suite.run()
