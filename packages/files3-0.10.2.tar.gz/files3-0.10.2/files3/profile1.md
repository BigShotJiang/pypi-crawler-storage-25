# files3 性能分析报告 — 分阶段耗时拆解

> 测试环境: Python 3.14.3 | Windows 11 | 重复次数: 5 取中位数

---

## 一、set() 写入 — 瓶颈随对象大小转移

| 子阶段 | 小对象 (~100B) | 中对象 (~15KB) | 大对象 (~1.2MB) |
|--------|---------------|---------------|----------------|
| shell_validate | 0.1% | 0.0% | 0.0% |
| path_join | 1.8% | 0.5% | 0.0% |
| os.path.exists | 11.0% | 3.3% | 0.1% |
| **cloudpickle.dumps** | 5.0% | 3.2% | 6.9% |
| **pickletools.optimize** | 11.3% | **70.8%** | **87.5%** |
| lz4.compress | 1.0% | 0.5% | 3.9% |
| **file_write** | **69.8%** | **21.7%** | 1.5% |

**瓶颈判定：**
- **小对象**：`file_write` 占 **70%**。序列化总占比仅 17%，文件IO是主导。
- **中对象**：`pickletools.optimize` 占 **71%**，反超文件IO成为第一瓶颈。
- **大对象**：`pickletools.optimize` 占 **87.5%**，序列化总占比 **98.4%**，文件IO只剩 1.5% 可忽略。

> 序列化内部比例（三子步骤）：`optimize` 占 78%~97%，`dumps` 占 2.5%~17%，`compress` 几乎可忽略。

---

## 二、get() 读取 — 反序列化主导

| 子阶段 | 小对象 | 中对象 | 大对象 |
|--------|--------|--------|--------|
| path_join | 3.2% | 0.8% | 0.0% |
| os.path.exists | 26.2% | 6.9% | 0.3% |
| **file_read** | **52.4%** | 15.2% | 2.9% |
| lz4.decompress | 2.4% | 1.1% | 3.6% |
| **unpickle** | 15.7% | **76.0%** | **93.2%** |

**瓶颈判定：**
- **小对象**：`file_read` 占 **52%**，文件读取是主导。
- **中对象**：`unpickle` 占 **76%**，反序列化反超。
- **大对象**：`unpickle` 占 **93.2%**，反序列化总占比 **96.8%**。

> 写入比读取慢约 2.4x，因为 `pickletools.optimize`（写独有）比 `unpickle`（读）更耗时。

---

## 三、子键首次转换 — 文件系统操作占大头

| 子阶段 | 占比 | 耗时 |
|--------|------|------|
| path_join | 0.5% | 4 us |
| check_isfile | 3.3% | 28 us |
| gen_random_name | 0.6% | 5 us |
| mkdir_tmp | 11.4% | 97 us |
| **move_to_tmp** | **25.5%** | **217 us** |
| **rename_tmp** | **33.9%** | **289 us** |
| write_skey | 24.8% | 211 us |

**瓶颈判定：** `rename_tmp` (34%) + `move_to_tmp` (25%) + `mkdir_tmp` (11%) = **70.9%**。文件系统原子转换是主要成本，后续子键追加无此开销。

---

## 四、筛选操作 — 筛选器解析可忽略

| 场景 | 筛选器解析 | get反序列化 | 结论 |
|------|-----------|-------------|------|
| 全选 200 个 | 18.4% | 81.6% | 全选需要遍历全部文件，筛选器本身略重 |
| 正则 ~50 个 | **5.1%** | **94.9%** | 筛选几乎不耗时 |
| 函数 ~100 个 | **2.6%** | **97.4%** | 筛选几乎不耗时 |

**瓶颈判定：** 无论哪种筛选器，**94% 以上耗时都在 get 反序列化**。`_shell_magic_filter_` 的遍历和匹配逻辑本身极快。

---

## 五、遍历操作 — listdir 几乎免费

| 操作 | listdir+filter | get反序列化 | 结论 |
|------|---------------|-------------|------|
| keys-100 | 100% | 0% | 纯文件名读取，45 us |
| values-100 | **1.2%** | **98.8%** | 瓶颈全在 get |
| keys-500 | 100% | 0% | 119 us |
| values-500 | **0.9%** | **99.1%** | 瓶颈全在 get |

**瓶颈判定：** `os.listdir` 在 500 文件时仅 119 us，`values()` 慢是因为每个 key 都要执行完整 get（含反序列化）。

---

## 六、序列化子步骤 — pickletools.optimize 是最大瓶颈

| 对象 | dumps | optimize | compress | 三者比例 |
|------|-------|----------|----------|---------|
| small | 3.3 us | 15.3 us | 0.9 us | dumps:17% optimize:79% compress:5% |
| medium | 13.9 us | 528.6 us | 2.6 us | dumps:3% optimize:97% compress:0.5% |
| large | 2.6 ms | 27.8 ms | 1.3 ms | dumps:8% optimize:88% compress:4% |

**瓶颈判定：** `pickletools.optimize` 在序列化三步骤中占 **79%~97%**。这是 Python 标准库中对 pickle bytecode 做死码消除和常量折叠的过程，与对象复杂度正相关。

---

## 七、pack/unpack — 瓶颈在 zip 不在 f3

| 操作 | 子阶段 | 占比 |
|------|--------|------|
| **pack** | zip_pack | **97.5%** |
| | f3序列化(dumps+optimize+compress) | 2.4% |
| **unpack** | zip_extract | **98.1%** |
| | f3反序列化(decompress+unpickle) | 0.5% |

**瓶颈判定：** pack 的 zip 压缩占 **97.5%**，unpack 的 zip 解压占 **98.1%**。f3 的序列化/反序列化在 pack 场景下占比极低。

---

## 八、files3 vs pickle — 差距在算法不在文件IO

| 阶段 | files3 | pickle | 差距 |
|------|--------|--------|------|
| serialize | 22.3 us | 15.1 us | 1.5x |
| compress (files3独有) | 530.6 us | N/A | — |
| file_write | 162.7 us | 156.2 us | **1.0x** |
| file_read | 54.0 us | 53.6 us | **1.0x** |
| decompress (files3独有) | 4.2 us | N/A | — |
| deserialize | 225.9 us | 17.5 us | **12.9x** |
| **TOTAL** | **999.7 us** | **242.4 us** | **4.1x** |

**瓶颈判定：**
- **文件IO几乎相同**（write 1.0x, read 1.0x），差距不在磁盘。
- files3 额外开销来自：`pickletools.optimize`（写）+ `cloudpickle` 更复杂的对象图遍历 + `_F3Unpickler` 的元数据解析和 `__main__` 模块修正（读）。
- 反序列化慢 **12.9x** 是因为 `_F3Unpickler.find_class` 需要遍历帧栈找源文件路径，且 `sys.path` 的 append/pop 也有开销。

---

## 九、文件数量对子步骤的影响

| 已有文件数 | os.listdir | os.path.exists | file_write | 总耗时 |
|-----------|-----------|----------------|------------|--------|
| 0 | 34 us (13%) | 19 us (8%) | 154 us (61%) | 251 us |
| 200 | 78 us (27%) | 21 us (7%) | 155 us (54%) | 288 us |
| 500 | **222 us (42%)** | 31 us (6%) | 231 us (43%) | **532 us** |

**瓶颈判定：**
- `os.path.exists` 几乎不受文件数量影响（19→31 us），这是 Windows 文件系统的哈希查找特性。
- 但**显式 `os.listdir` 随文件数线性增长**：0→500 文件时从 34us 涨到 222us。
- 500 文件时 `listdir` 占 **42%**，与 `file_write` 持平。
- **单 key 的 set/get/has 不受目录规模影响**，遍历类操作（keys/values/filter-all）会受影响。

---

## 总结：各场景瓶颈速查

| 场景 | 主要瓶颈 | 次要瓶颈 | 优化方向 |
|------|---------|---------|---------|
| set 小对象 | file_write (70%) | os.path.exists (11%) | SSD/缓存 |
| set 中/大对象 | pickletools.optimize (71~88%) | cloudpickle.dumps (7%) | 移除 optimize 或换算法 |
| get 小对象 | file_read (52%) | os.path.exists (26%) | 缓存热点 |
| get 中/大对象 | unpickle (76~93%) | lz4.decompress (4%) | 无法优化，pickle 固有成本 |
| 子键转换 | rename_tmp (34%) | move_to_tmp (26%) | 避免频繁转换 |
| 筛选/遍历 | get反序列化 (95~99%) | 筛选器本身 (3%) | 减少取值次数 |
| pack/unpack | zip 压缩/解压 (98%) | f3序列化 (1%) | 换 zip 模式 |
| files3 vs pickle | pickletools.optimize + 自定义Unpickler | — | 功能换速度 |
| 目录500文件 | os.listdir (42%) | file_write (43%) | 分目录存储 |

---

## 最关键发现

`pickletools.optimize` 是 files3 写入的最大隐藏瓶颈，在所有非微小对象的写入场景中占 **70%~88%** 的序列化时间。这是 Python 标准库中对 pickle bytecode 做死码消除和常量折叠的过程，与对象复杂度正相关。如果追求极致写入速度且不需要 pickle bytecode 优化，可以考虑移除 `pickletools.optimize` 调用（需验证兼容性）。
