import os
import random
import re
import sys
import time

# 内核工具                      backend
from files3.f3core import F3Core

# 加壳工具(主要用于用户交互)                    shell tool(user frendly API)
from files3.f3shell import F3Shell
from files3.f3bool import F3Bool, F3True, F3False
from files3.f3info import PF_DTYPE as _PF_DTYPE

files = F3Shell

class QuickTest_CustomClass:
    ...


def QuickTest_CustomFunction():
    ...

_QuickTestReference = ['256', '1.414', '<built-in function dir>', '<built-in function exec>', "<class 'files3.f3core.F3Core'>", '<function QuickTest_CustomFunction ', "<class 'files3.f3test.QuickTest_CustomClass'>", "(['.py', '.c', '.cpp', '.js'], <function QuickTest_CustomFunction }, 648)", '<built-in function eval>', "[<class 'enumerate'>, <built-in function eval>]", "[<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]", "[<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]", '3.1415926', "[<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]", "[<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]", "[<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]", "[<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]", "[<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]", "[<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]", "[<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]", "[<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]", "[<built-in function ascii>, [<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]]", "[<class 'complex'>, [<built-in function ascii>, [<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]]]", 'Hello, world!', '\n1. If he always holds umbrellas for others, why bother waiting for him in the rain? - "Happy breakup" by Liang Jingru2. Unfortunately, it\'s not you, accompanying me until the end - - "Unfortunately, it\'s not you" by Liang Jingru3. What cannot be obtained is always in turmoil, and those who are favored are confident and fearless - Eason Chan\'s "Red Rose"If we hadn\'t been so stubborn back then, and now we\'re not so regretful either - -- Liu Ruoying "Later"5. But later on, we were still lonely. You changed a few stops, and I kept wandering - Liu Ruoying, "The first sentence"I know it\'s not easy to be with you, we come from different heaven and earth—— Alan Tam7. Whose head has no dust, and whose shoulders have no dents—— Hao Yun\'s "Going to Dali"8. When we can still have it, but don\'t know how to grasp it, only after losing it can we understand how valuable love is - Xu Ruoxuan\'s "contour of happiness"9. Thinking that the right person is still waiting in the farthest place, so it\'s worth giving up everything - Xu Ruoxuan\'s "happy outline"10. Perhaps we always have to wait until we are moved by what we have lost, and only then can we realize that we also have so much. - Xu Ruoxuan\'s "happy outline"11. When I see you again, I will make myself firm and determined. Seeing you again, I will make myself pretend to be very firm - Xu Ruoxuan\'s "smiling eyes"12. Actually, I am really happy to have you waiting and holding your hand until the end - Xu Ruoxuan misses you so much13. Since we can\'t be together, please don\'t get close anymore - -- Xu Ruoxuan\'s "sweet torture"14. Not afraid of being blocked by thousands, only afraid of surrendering - Mayday\'s "Stubbornness"15. Love teaches us, can\'t you let go of it? - Twins, "I really want to love him."16. As long as I grow up, can I love you? Teach me to recognize love but not touch it. Wait until I grow up to love. I can\'t control this heart. Please accept it. Twins, "As long as I grow up,"17. Isn\'t it true that hard work and determination can lead to success? Why is there a gap in reality? Twins, "As long as I grow up,"18. I heard your name and felt a heartbeat. How many years have passed before the scars become invisible - Jiang Meiqi\'s "Friend of Friends"19. Friends of Friends, Our Last Connection - Jiang Meiqi\'s "Friends of Friends"20. It always makes someone on the street with a similar back, making it unbearable to be sad - Jiang Meiqi, "I think of you again."21. This is the best way. What was once missing you, you have already received it elsewhere - "That year\'s love letter" from Jiang Meiqi22. I believe you are just afraid of hurting me, not lying to me. If you have loved me so much, who would be willing to let it go? - Stefanie Sun "Starting to understand"23. Yesterday was still good, but tomorrow is my own - - Stefanie Sun "starting to understand"24. How long has it been since then? One day, you suddenly asked me if I also loved him at that time - "I miss him too," said Stefanie Sun25. I also miss him very much. We are all the same, and we have found wings in him. It was just because of you that he began to fly - - "I miss him too," said Stefanie Sun26. Turning around, I realized that I should bring back happiness - "My Love" by Stefanie Sun27. I believe that you are a good person, but what about love - "To the love of the past" by Liang Jingru28. I believe in the oath you gave me, just like the spring that will surely come - Zhang Shaohan\'s "Lost Beauty"29. At the very beginning, some things were already destined to grow old - Zhang Shaohan\'s "lost beauty"30. Just because I don\'t want to disturb, just because I\'m afraid you won\'t be able to explain, just because now in your eyes, she\'s more important than me - Daphne\'s "blessing on the street corner"31. If you don\'t want to ask or be notified, I can\'t control your world. If you don\'t want to ask or be notified, leave your blessings on the street corner32. I used to think you were the whole world, but that day was already so far away - Jolin Tsai\'s "Lemongrass Flavor"33. We\'re all right, it\'s just not suitable - Jolin Tsai\'s "Lemongrass Flavor"34. Our love is the scenery you pass by - Assang, always very quiet35. To be happy, safe, and even happier - - "In an instant" by Jinsha36. I used to think I would always be by his side, but now we have left in the sea of people - "Those flowers" by Fan Weiqi37. Perhaps the final landing point is different, perhaps we will meet again - Zheng Xiuwen\'s "mid air"38. Love is finally the past that you have deleted - - Wang Xinling\'s "Wings"39. Occasionally, I think of him, with some worries in my heart, and some love that has to be settled in different places - He Jie, "You must be happy."40. You were next to me, only making a face to face. On a sunny day in May, there was a flash of electricity - Faye Wong\'s "Flowing Years"41. I have lost it, but cherish it even more - "Beautiful" by Cai Jianya42. I won\'t cry anymore because I believe that we bravely love - - "beautiful love" by Jianya Tsai43. At that time, you were running on the playground, shouting loudly, "I love you, do you know -- Wang Zheng," We are all good children. "44. Although you still hold my hand, I am no longer in your heart - - Sun Yanzi, "I am not sad."45. I really understand. You\'re not someone who likes the new and dislikes the old. It\'s me who wasn\'t by your side when you were lonely. - Stefanie Sun, "I\'m not sad."46. I\'m not sad, it\'s nothing, it\'s just why tears flow. I don\'t understand either - "I\'m not sad," said Stefanie Sun47. Or perhaps this is the best outcome, breaking up now is always better than not loving youI procrastinated time and time again. Release your hand, leave you left and right, I walk forward. This will be me, the true liberation - - "I\'m not sad" by Stefanie Sun48. You know, I\'m waiting for you to come back - Twins, "You\'re the bravest."49. The most beautiful thing is to hear that you still remember. Actually, I am also grateful. When I heard that you still believe in love, Liu Ruoying "heard"50. I heard that there is a new face around me, and I heard that you have blessed me. - Liu Ruoying "Heard"51. I can only embrace the air, pretend it\'s you, never far away - Sun Li "Love is like air"52. You are more important than yourself. I also hope for a better change - Liang Jingru\'s "warmth"53. Fingers clenched tightly, but unable to hold onto eternity - Xu Ruoxuan\'s "Don\'t Love Me"54. Speak slowly, thank you for loving me once - Xu Ruoxuan "Don\'t love me"55. I still love you, with a little bit of hatred, and it takes time to balance. - Wen Lan "Wishing me a happy birthday"56. Holding hands and breaking up come from the same hands, becoming friends again, but why don\'t I know how to keep them? - Sun Yanzi "Rainy Day"57. You used to live in my heart, but now there\'s an empty place - Gigi Leung. "So love hurts so much," she said58. Familiar intersections, still bustling with people, who is waiting for me in the same place? - Tan Weiwei, "If I hadn\'t loved before"59. The hand I once held, promised to last forever in my memory - "If I hadn\'t loved before," said Tan Weiwei60. If I had never loved, never encountered a wound, and how lonely life would be - Tan Weiwei "If I had never loved"61. You don\'t make promises, nor do you apologize, but I\'m caught up in the predicted risks - Jolin Tsai\'s "sour and sweet"62. That day, standing at my fingertips, without asking anything, I believed that we would always be together. That year, there was no declaration, but holding you, I once held the whole world - Jolin Tsai, "sour and sweet"63. I would rather give up on you soberly and painfully, than wronging myself in the dream of love - "Too wronged" by Tao Jingying64. I am just cute, but not enough to be loved - - "Cute" by Yang Chenglin65. The sentence "I love you" always seems to lack courage - - "True or False Question" by Fan Weiqi66. These days, I occasionally think of your love, but facing these memories, I still feel warm - - Wen Lan\'s "Pocket"67. I will hide your warmth - Wen Lan\'s "pocket"68. Happiness is not easy, but why do you dare not? - "Worship" by Liang Jingru69. No matter what, it will get hurt no matter what - "For the future self" by Liang Jingru70. Before returning to reality, we sincerely said goodbye to each other. I said don\'t remember me in the future, just pretend that nothing has happened to us - Qin Hailu, "Nothing has happened."71. Actually, I rarely think of you, rarely recall, just in the evening————Liu Ruoying\'s "Evening"72. When I am alone, I forget that I will still be lonely - -- Liu Ruoying\'s "Evening"73. Life is not too long, there is no end to the future, is it enough to take me away - "Stars under the Sunshine" by Jin Haixin74. You see, I am still so gentle, but I am a friend of friends - Zhou Bichang\'s "First Anniversary"75. I locked up your photo, but I still remember your birthday - Zhou Bichang\'s "one-year anniversary"76. Happiness is a bubble, but at least I have caught - Miriam Yeung, "I\'m good."77. Although she said she wanted to forget, she still remembers everything - -- Luo Meiling\'s "Red Sunflower"78. I am very happy, please don\'t say that you love me again - Xianzi\'s "Third Party of the Third Party"79. Accustomed to being alone, I am not without you - Xian Zi\'s "Third Party of the Third Party"80. You can\'t see me crying before I turn around - SHE, "You\'re too honest."81. How could love lose to time - -- Wang Xinling "See you tomorrow"82. What a pity I still deserve to be invited, this is sympathy, not emotion - Jolin Tsai "Be You for a Day"83. Happiness cannot be described as sour or sweet candy - Liang Jingru\'s "Beautiful Life"84. I know memories are a kind of foolishness, and this life only allows me to be foolish once. - Hou Xiangting, "Tears shed for you"85. Love is too short, but memories are too long - Hou Xiangting\'s "Tokyo Kiss"86. Dreams are too short, regrets are too long - -- Xiao Yaxuan "No one"87. No one has ever come to my heart, I am just the place where you stopped midway - Xiao Yaxuan "No one"88. Actually, I have always wanted to tell you personally that it\'s not easy for you to love me, right? But you don\'t ask for the price - Mo Wenwei, "Actually, I have always wanted to tell you."89. Sometimes when we gather and leave, nothing lasts forever - -- Faye Wong\'s "Red Bean"90. I met you, it was the most beautiful accident - - Sun Yanzi "met"91. Sometimes, even without you, I feel the same way. At most, my eyes turn red again - Jin Haixin\'s "Sad Swing"92. I just want the lamp that will never be extinguished in the afterlife, to illuminate the people of this world\'s game. I just want the deepest kiss, and years later, there will still be your warmth - Lin Chenxi "I don\'t want to ask"93. I just want someone to be with me, no matter where tomorrow is. - Liu Ruoying, "When Love is Approaching"94. If I really decide to give my heart, can someone tell him not to make me sad? - Liu Ruoying "When love is approaching"95. I am not the only general in your eyes, just an inconspicuous soldier - Wang Fei\'s "chess piece"96. Anyway, in the end, everyone was lonely - "I don\'t want this either," said Faye Wong97. After you, I love myself more - "After Xiao Yaxuan"98. How long has it been since I was moved,If it weren\'t for your strong protection of me, if it weren\'t for your words, you wouldn\'t have much, but would be willing to leave the best for me - - "Daphne\'s Air Defense Shelter"99. The next second I shed tears, I completely understood that you are someone else and have nothing to do with my love. - Xu Huixin, "My Beautiful Love"100. I will learn to walk out of the past and bless tomorrow. - Wang Xinling "See you tomorrow"101. The fingerprint I left in your chaotic world is a heartless kiss to you———— Sun Yanzi\'s Invisible Man102. You don\'t want me to believe in eternity, you don\'t want me to be superstitious, you don\'t want me to be reckless———— Sun Yanzi\'s Invisible Man103. It is known that I am devout in love and superstitious. I know I rarely let go———— Sun Yanzi\'s Invisible Man104. Missing is the pain of breathing, it lives in every corner of me. Regretting not being considerate will hurt, hating not understanding you will hurt, wanting to see but not seeing will hurt the most———— Liang Jingru\'s "Breathing Pain"105. I swear I won\'t lie anymore. I\'ll hold you as tightly as I love you. My smile is fake, and my soul seems to be floating. If you come back, that\'s all———— Liang Jingru\'s "Breathing Pain"106. My world is changing for you day by day, you haven\'t noticed it, you can\'t see all my efforts. As long as today is over, I will love myself more and there will be no more vows from you in my world———— Guan Xinyan\'s "End Point"107. If one day we have the chance to meet again, will you remember the eternity we said———— BY2 is not mature enough108. I don\'t believe that love is difficult, there is no residual warmth———— Zhuo Wenxuan is "brave alone"109. I can\'t bear to part with it, but time can\'t go back. Loving you is worth it, but it\'s time to stop. You need to be okay without me. I can\'t bear to part with you. I held you tightly for the last time, what we missed. If we were wrong, it would be wrong. Don\'t worry about me, I don\'t love you anymore———— Xuanzi "cannot bear to part with"110. Who still remembers who said forever love me first? The previous sentence is our future wound———— Zhang Huimei "remembers"111. After too long, no one remembers those gentle moments back then. You and I held hands and said we were going to walk together until the end———— Zhang Huimei "remembers"112. I can\'t find it, I can\'t reach it, that so-called beauty of love. I don\'t want anything, do you know? If you understand this second of mine———— Fan Weiqi "can\'t make it"113. I want to see, I am searching for what you call the beauty of the future. I firmly rely on you, hold on tightly, and dare not miss a single bit. May you see———— Fan Weiqi "can\'t make it"114. A heart belongs to one person, what is considered fair in love———— "Unfair"115. Loving you is a lonely concern, not understanding the meaning of your smile. Only like a sunflower, silently persevering at night———— Lan Youshi\'s Lonely Hearts116. I used to be too young but absolutely sincere. The love I gave was always capricious, not understanding the love that only blooms once———— Blue Youshi once"Being too young"117. I don\'t want to forget you. If possible, I would rather remember all the sadness———— Guo Jing, "I don\'t want to forget you."118. Are you still afraid of constantly thinking of you in the dead of night, or are you afraid of accidentally hearing your news———— Stefanie Sun is "scared"119. I have been brave for too long and decided to live for you alone. I dare not speak out, so lonely. Illuminated the silence, love turned out to be lonely———— Zhang Huimei is "Brave"120. What I miss is saying everything. What I miss is dreaming together. What I miss is the impulse to love you even after an argument. What I miss is that you are so excited that you ask me for forgiveness, and it hurts me to hug you———— Sun Yanzi: "I miss it."\n', '<files3.f3test.QuickTest_CustomClass object ', 'None', 'False', '()', '[]', '{}', "(['.py', '.c', '.cpp', '.js'], {'language': 'python'}, 648)"]

_big_str = """
1. If he always holds umbrellas for others, why bother waiting for him in the rain? - "Happy breakup" by Liang Jingru2. Unfortunately, it's not you, accompanying me until the end - - "Unfortunately, it's not you" by Liang Jingru3. What cannot be obtained is always in turmoil, and those who are favored are confident and fearless - Eason Chan's "Red Rose"If we hadn't been so stubborn back then, and now we're not so regretful either - -- Liu Ruoying "Later"5. But later on, we were still lonely. You changed a few stops, and I kept wandering - Liu Ruoying, "The first sentence"I know it's not easy to be with you, we come from different heaven and earth—— Alan Tam7. Whose head has no dust, and whose shoulders have no dents—— Hao Yun's "Going to Dali"8. When we can still have it, but don't know how to grasp it, only after losing it can we understand how valuable love is - Xu Ruoxuan's "contour of happiness"9. Thinking that the right person is still waiting in the farthest place, so it's worth giving up everything - Xu Ruoxuan's "happy outline"10. Perhaps we always have to wait until we are moved by what we have lost, and only then can we realize that we also have so much. - Xu Ruoxuan's "happy outline"11. When I see you again, I will make myself firm and determined. Seeing you again, I will make myself pretend to be very firm - Xu Ruoxuan's "smiling eyes"12. Actually, I am really happy to have you waiting and holding your hand until the end - Xu Ruoxuan misses you so much13. Since we can't be together, please don't get close anymore - -- Xu Ruoxuan's "sweet torture"14. Not afraid of being blocked by thousands, only afraid of surrendering - Mayday's "Stubbornness"15. Love teaches us, can't you let go of it? - Twins, "I really want to love him."16. As long as I grow up, can I love you? Teach me to recognize love but not touch it. Wait until I grow up to love. I can't control this heart. Please accept it. Twins, "As long as I grow up,"17. Isn't it true that hard work and determination can lead to success? Why is there a gap in reality? Twins, "As long as I grow up,"18. I heard your name and felt a heartbeat. How many years have passed before the scars become invisible - Jiang Meiqi's "Friend of Friends"19. Friends of Friends, Our Last Connection - Jiang Meiqi's "Friends of Friends"20. It always makes someone on the street with a similar back, making it unbearable to be sad - Jiang Meiqi, "I think of you again."21. This is the best way. What was once missing you, you have already received it elsewhere - "That year's love letter" from Jiang Meiqi22. I believe you are just afraid of hurting me, not lying to me. If you have loved me so much, who would be willing to let it go? - Stefanie Sun "Starting to understand"23. Yesterday was still good, but tomorrow is my own - - Stefanie Sun "starting to understand"24. How long has it been since then? One day, you suddenly asked me if I also loved him at that time - "I miss him too," said Stefanie Sun25. I also miss him very much. We are all the same, and we have found wings in him. It was just because of you that he began to fly - - "I miss him too," said Stefanie Sun26. Turning around, I realized that I should bring back happiness - "My Love" by Stefanie Sun27. I believe that you are a good person, but what about love - "To the love of the past" by Liang Jingru28. I believe in the oath you gave me, just like the spring that will surely come - Zhang Shaohan's "Lost Beauty"29. At the very beginning, some things were already destined to grow old - Zhang Shaohan's "lost beauty"30. Just because I don't want to disturb, just because I'm afraid you won't be able to explain, just because now in your eyes, she's more important than me - Daphne's "blessing on the street corner"31. If you don't want to ask or be notified, I can't control your world. If you don't want to ask or be notified, leave your blessings on the street corner32. I used to think you were the whole world, but that day was already so far away - Jolin Tsai's "Lemongrass Flavor"33. We're all right, it's just not suitable - Jolin Tsai's "Lemongrass Flavor"34. Our love is the scenery you pass by - Assang, always very quiet35. To be happy, safe, and even happier - - "In an instant" by Jinsha36. I used to think I would always be by his side, but now we have left in the sea of people - "Those flowers" by Fan Weiqi37. Perhaps the final landing point is different, perhaps we will meet again - Zheng Xiuwen's "mid air"38. Love is finally the past that you have deleted - - Wang Xinling's "Wings"39. Occasionally, I think of him, with some worries in my heart, and some love that has to be settled in different places - He Jie, "You must be happy."40. You were next to me, only making a face to face. On a sunny day in May, there was a flash of electricity - Faye Wong's "Flowing Years"41. I have lost it, but cherish it even more - "Beautiful" by Cai Jianya42. I won't cry anymore because I believe that we bravely love - - "beautiful love" by Jianya Tsai43. At that time, you were running on the playground, shouting loudly, "I love you, do you know -- Wang Zheng," We are all good children. "44. Although you still hold my hand, I am no longer in your heart - - Sun Yanzi, "I am not sad."45. I really understand. You're not someone who likes the new and dislikes the old. It's me who wasn't by your side when you were lonely. - Stefanie Sun, "I'm not sad."46. I'm not sad, it's nothing, it's just why tears flow. I don't understand either - "I'm not sad," said Stefanie Sun47. Or perhaps this is the best outcome, breaking up now is always better than not loving youI procrastinated time and time again. Release your hand, leave you left and right, I walk forward. This will be me, the true liberation - - "I'm not sad" by Stefanie Sun48. You know, I'm waiting for you to come back - Twins, "You're the bravest."49. The most beautiful thing is to hear that you still remember. Actually, I am also grateful. When I heard that you still believe in love, Liu Ruoying "heard"50. I heard that there is a new face around me, and I heard that you have blessed me. - Liu Ruoying "Heard"51. I can only embrace the air, pretend it's you, never far away - Sun Li "Love is like air"52. You are more important than yourself. I also hope for a better change - Liang Jingru's "warmth"53. Fingers clenched tightly, but unable to hold onto eternity - Xu Ruoxuan's "Don't Love Me"54. Speak slowly, thank you for loving me once - Xu Ruoxuan "Don't love me"55. I still love you, with a little bit of hatred, and it takes time to balance. - Wen Lan "Wishing me a happy birthday"56. Holding hands and breaking up come from the same hands, becoming friends again, but why don't I know how to keep them? - Sun Yanzi "Rainy Day"57. You used to live in my heart, but now there's an empty place - Gigi Leung. "So love hurts so much," she said58. Familiar intersections, still bustling with people, who is waiting for me in the same place? - Tan Weiwei, "If I hadn't loved before"59. The hand I once held, promised to last forever in my memory - "If I hadn't loved before," said Tan Weiwei60. If I had never loved, never encountered a wound, and how lonely life would be - Tan Weiwei "If I had never loved"61. You don't make promises, nor do you apologize, but I'm caught up in the predicted risks - Jolin Tsai's "sour and sweet"62. That day, standing at my fingertips, without asking anything, I believed that we would always be together. That year, there was no declaration, but holding you, I once held the whole world - Jolin Tsai, "sour and sweet"63. I would rather give up on you soberly and painfully, than wronging myself in the dream of love - "Too wronged" by Tao Jingying64. I am just cute, but not enough to be loved - - "Cute" by Yang Chenglin65. The sentence "I love you" always seems to lack courage - - "True or False Question" by Fan Weiqi66. These days, I occasionally think of your love, but facing these memories, I still feel warm - - Wen Lan's "Pocket"67. I will hide your warmth - Wen Lan's "pocket"68. Happiness is not easy, but why do you dare not? - "Worship" by Liang Jingru69. No matter what, it will get hurt no matter what - "For the future self" by Liang Jingru70. Before returning to reality, we sincerely said goodbye to each other. I said don't remember me in the future, just pretend that nothing has happened to us - Qin Hailu, "Nothing has happened."71. Actually, I rarely think of you, rarely recall, just in the evening————Liu Ruoying's "Evening"72. When I am alone, I forget that I will still be lonely - -- Liu Ruoying's "Evening"73. Life is not too long, there is no end to the future, is it enough to take me away - "Stars under the Sunshine" by Jin Haixin74. You see, I am still so gentle, but I am a friend of friends - Zhou Bichang's "First Anniversary"75. I locked up your photo, but I still remember your birthday - Zhou Bichang's "one-year anniversary"76. Happiness is a bubble, but at least I have caught - Miriam Yeung, "I'm good."77. Although she said she wanted to forget, she still remembers everything - -- Luo Meiling's "Red Sunflower"78. I am very happy, please don't say that you love me again - Xianzi's "Third Party of the Third Party"79. Accustomed to being alone, I am not without you - Xian Zi's "Third Party of the Third Party"80. You can't see me crying before I turn around - SHE, "You're too honest."81. How could love lose to time - -- Wang Xinling "See you tomorrow"82. What a pity I still deserve to be invited, this is sympathy, not emotion - Jolin Tsai "Be You for a Day"83. Happiness cannot be described as sour or sweet candy - Liang Jingru's "Beautiful Life"84. I know memories are a kind of foolishness, and this life only allows me to be foolish once. - Hou Xiangting, "Tears shed for you"85. Love is too short, but memories are too long - Hou Xiangting's "Tokyo Kiss"86. Dreams are too short, regrets are too long - -- Xiao Yaxuan "No one"87. No one has ever come to my heart, I am just the place where you stopped midway - Xiao Yaxuan "No one"88. Actually, I have always wanted to tell you personally that it's not easy for you to love me, right? But you don't ask for the price - Mo Wenwei, "Actually, I have always wanted to tell you."89. Sometimes when we gather and leave, nothing lasts forever - -- Faye Wong's "Red Bean"90. I met you, it was the most beautiful accident - - Sun Yanzi "met"91. Sometimes, even without you, I feel the same way. At most, my eyes turn red again - Jin Haixin's "Sad Swing"92. I just want the lamp that will never be extinguished in the afterlife, to illuminate the people of this world's game. I just want the deepest kiss, and years later, there will still be your warmth - Lin Chenxi "I don't want to ask"93. I just want someone to be with me, no matter where tomorrow is. - Liu Ruoying, "When Love is Approaching"94. If I really decide to give my heart, can someone tell him not to make me sad? - Liu Ruoying "When love is approaching"95. I am not the only general in your eyes, just an inconspicuous soldier - Wang Fei's "chess piece"96. Anyway, in the end, everyone was lonely - "I don't want this either," said Faye Wong97. After you, I love myself more - "After Xiao Yaxuan"98. How long has it been since I was moved,If it weren't for your strong protection of me, if it weren't for your words, you wouldn't have much, but would be willing to leave the best for me - - "Daphne's Air Defense Shelter"99. The next second I shed tears, I completely understood that you are someone else and have nothing to do with my love. - Xu Huixin, "My Beautiful Love"100. I will learn to walk out of the past and bless tomorrow. - Wang Xinling "See you tomorrow"101. The fingerprint I left in your chaotic world is a heartless kiss to you———— Sun Yanzi's Invisible Man102. You don't want me to believe in eternity, you don't want me to be superstitious, you don't want me to be reckless———— Sun Yanzi's Invisible Man103. It is known that I am devout in love and superstitious. I know I rarely let go———— Sun Yanzi's Invisible Man104. Missing is the pain of breathing, it lives in every corner of me. Regretting not being considerate will hurt, hating not understanding you will hurt, wanting to see but not seeing will hurt the most———— Liang Jingru's "Breathing Pain"105. I swear I won't lie anymore. I'll hold you as tightly as I love you. My smile is fake, and my soul seems to be floating. If you come back, that's all———— Liang Jingru's "Breathing Pain"106. My world is changing for you day by day, you haven't noticed it, you can't see all my efforts. As long as today is over, I will love myself more and there will be no more vows from you in my world———— Guan Xinyan's "End Point"107. If one day we have the chance to meet again, will you remember the eternity we said———— BY2 is not mature enough108. I don't believe that love is difficult, there is no residual warmth———— Zhuo Wenxuan is "brave alone"109. I can't bear to part with it, but time can't go back. Loving you is worth it, but it's time to stop. You need to be okay without me. I can't bear to part with you. I held you tightly for the last time, what we missed. If we were wrong, it would be wrong. Don't worry about me, I don't love you anymore———— Xuanzi "cannot bear to part with"110. Who still remembers who said forever love me first? The previous sentence is our future wound———— Zhang Huimei "remembers"111. After too long, no one remembers those gentle moments back then. You and I held hands and said we were going to walk together until the end———— Zhang Huimei "remembers"112. I can't find it, I can't reach it, that so-called beauty of love. I don't want anything, do you know? If you understand this second of mine———— Fan Weiqi "can't make it"113. I want to see, I am searching for what you call the beauty of the future. I firmly rely on you, hold on tightly, and dare not miss a single bit. May you see———— Fan Weiqi "can't make it"114. A heart belongs to one person, what is considered fair in love———— "Unfair"115. Loving you is a lonely concern, not understanding the meaning of your smile. Only like a sunflower, silently persevering at night———— Lan Youshi's Lonely Hearts116. I used to be too young but absolutely sincere. The love I gave was always capricious, not understanding the love that only blooms once———— Blue Youshi once"Being too young"117. I don't want to forget you. If possible, I would rather remember all the sadness———— Guo Jing, "I don't want to forget you."118. Are you still afraid of constantly thinking of you in the dead of night, or are you afraid of accidentally hearing your news———— Stefanie Sun is "scared"119. I have been brave for too long and decided to live for you alone. I dare not speak out, so lonely. Illuminated the silence, love turned out to be lonely———— Zhang Huimei is "Brave"120. What I miss is saying everything. What I miss is dreaming together. What I miss is the impulse to love you even after an argument. What I miss is that you are so excited that you ask me for forgiveness, and it hurts me to hug you———— Sun Yanzi: "I miss it."
"""
def QuickTest(tolist=False):
    f = files(type='.inst')
    results = []
    # Basic Python Object
    _testnum = 32
    f.set('_t0', 256)
    f['_t1'] = 1.414
    f.set('_t2', 3.1415926)
    f.set('_t3', 'Hello, world!')
    f.set('_t4', None)
    f.set('_t5', False)
    f._t6 = ()
    f._t7 = []
    f._t8 = {}
    f.set('_t9', (['.py', '.c', '.cpp', '.js'], {"language": "python"}, 648))
    # Python Std Class/Method
    f.set('_t10', dir)
    f._t11 = exec
    f.set('_t12', F3Core)
    # Python Custom Class/Method
    f.set('_t13', QuickTest_CustomFunction)
    f.set('_t14', QuickTest_CustomClass)
    f.set('_t15', (['.py', '.c', '.cpp', '.js'], QuickTest_CustomFunction, {"language": "python", 'class': QuickTest_CustomClass}, 648))
    f._t16 = eval
    f._t17 = [enumerate, f._t16]
    f._t18 = [list, f._t17]
    f._t19 = [zip, f._t18]
    f._t20 = [chr, f._t19]
    f._t21 = [super, f._t20]
    f._t22 = [ord, f._t21]
    f._t23 = [print, f._t22]
    f._t24 = [pow, f._t23]
    f._t25 = [object, f._t24]
    f._t26 = [set, f._t25]
    f._t27 = [bytearray, f._t26]
    f._t28 = [ascii, f._t27]
    f._t29 = [complex, f._t28]
    f._t30 = _big_str
    f._t31 = QuickTest_CustomClass()
    for k, v in f.items():
        results.append(v)
        if random.randint(0, 1):
            f.delete(k)
        else:
            del f[k]

    output_f = files(os.getcwd(), ".f3bytes")
    output_f.set('QuickTest', results)
    output_f.set('QuickTestX10', results * 10)

    # Compare with the reference answer
    _score, _fails, _newlist = 0, [], []
    for v in results:
        v = str(v)
        v = re.sub('at 0x.+>', "", v)
        _newlist.append(v)
        if v in _QuickTestReference:
            _score += 1
        else:
            _fails.append(v)
    if tolist: return _newlist

    _score = str(round(_score * 100 / _testnum)) + '%'
    _reason = ("Failed: (CodeReturn)\n" + '\n'.join(_fails)) if _fails else "Test Ok!"
    return _score + '\n' + _reason

_AdvancedTestReference = ['1', '2', '3', '4', '114.514', 'Hello, world!', 'None', 'False', '(1, 2, 3)', '[4, 5, 6]', "{'a': 1, 'b': 2}", "(['.py', '.c', '.cpp', '.js'], {'language': 'python'}, 648)", '<built-in function dir>', '<built-in function exec>', "<class 'files3.f3test.QuickTest_CustomClass'>", '<files3.f3test.QuickTest_CustomClass object ', '<function QuickTest_CustomFunction ', "(['.py', '.c', '.cpp', '.js'], <function QuickTest_CustomFunction }, 648)", '<built-in function eval>', "[<class 'enumerate'>, <built-in function eval>]", "[<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]", "[<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]", "[<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]", "[<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]", "[<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]", "[<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]", "[<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]", "[<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]", "[<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]", "[<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]", "[<built-in function ascii>, [<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]]", "[<class 'complex'>, [<built-in function ascii>, [<class 'bytearray'>, [<class 'set'>, [<class 'object'>, [<built-in function pow>, [<built-in function print>, [<built-in function ord>, [<class 'super'>, [<built-in function chr>, [<class 'zip'>, [<class 'list'>, [<class 'enumerate'>, <built-in function eval>]]]]]]]]]]]]]", '\n1. If he always holds umbrellas for others, why bother waiting for him in the rain? - "Happy breakup" by Liang Jingru2. Unfortunately, it\'s not you, accompanying me until the end - - "Unfortunately, it\'s not you" by Liang Jingru3. What cannot be obtained is always in turmoil, and those who are favored are confident and fearless - Eason Chan\'s "Red Rose"If we hadn\'t been so stubborn back then, and now we\'re not so regretful either - -- Liu Ruoying "Later"5. But later on, we were still lonely. You changed a few stops, and I kept wandering - Liu Ruoying, "The first sentence"I know it\'s not easy to be with you, we come from different heaven and earth—— Alan Tam7. Whose head has no dust, and whose shoulders have no dents—— Hao Yun\'s "Going to Dali"8. When we can still have it, but don\'t know how to grasp it, only after losing it can we understand how valuable love is - Xu Ruoxuan\'s "contour of happiness"9. Thinking that the right person is still waiting in the farthest place, so it\'s worth giving up everything - Xu Ruoxuan\'s "happy outline"10. Perhaps we always have to wait until we are moved by what we have lost, and only then can we realize that we also have so much. - Xu Ruoxuan\'s "happy outline"11. When I see you again, I will make myself firm and determined. Seeing you again, I will make myself pretend to be very firm - Xu Ruoxuan\'s "smiling eyes"12. Actually, I am really happy to have you waiting and holding your hand until the end - Xu Ruoxuan misses you so much13. Since we can\'t be together, please don\'t get close anymore - -- Xu Ruoxuan\'s "sweet torture"14. Not afraid of being blocked by thousands, only afraid of surrendering - Mayday\'s "Stubbornness"15. Love teaches us, can\'t you let go of it? - Twins, "I really want to love him."16. As long as I grow up, can I love you? Teach me to recognize love but not touch it. Wait until I grow up to love. I can\'t control this heart. Please accept it. Twins, "As long as I grow up,"17. Isn\'t it true that hard work and determination can lead to success? Why is there a gap in reality? Twins, "As long as I grow up,"18. I heard your name and felt a heartbeat. How many years have passed before the scars become invisible - Jiang Meiqi\'s "Friend of Friends"19. Friends of Friends, Our Last Connection - Jiang Meiqi\'s "Friends of Friends"20. It always makes someone on the street with a similar back, making it unbearable to be sad - Jiang Meiqi, "I think of you again."21. This is the best way. What was once missing you, you have already received it elsewhere - "That year\'s love letter" from Jiang Meiqi22. I believe you are just afraid of hurting me, not lying to me. If you have loved me so much, who would be willing to let it go? - Stefanie Sun "Starting to understand"23. Yesterday was still good, but tomorrow is my own - - Stefanie Sun "starting to understand"24. How long has it been since then? One day, you suddenly asked me if I also loved him at that time - "I miss him too," said Stefanie Sun25. I also miss him very much. We are all the same, and we have found wings in him. It was just because of you that he began to fly - - "I miss him too," said Stefanie Sun26. Turning around, I realized that I should bring back happiness - "My Love" by Stefanie Sun27. I believe that you are a good person, but what about love - "To the love of the past" by Liang Jingru28. I believe in the oath you gave me, just like the spring that will surely come - Zhang Shaohan\'s "Lost Beauty"29. At the very beginning, some things were already destined to grow old - Zhang Shaohan\'s "lost beauty"30. Just because I don\'t want to disturb, just because I\'m afraid you won\'t be able to explain, just because now in your eyes, she\'s more important than me - Daphne\'s "blessing on the street corner"31. If you don\'t want to ask or be notified, I can\'t control your world. If you don\'t want to ask or be notified, leave your blessings on the street corner32. I used to think you were the whole world, but that day was already so far away - Jolin Tsai\'s "Lemongrass Flavor"33. We\'re all right, it\'s just not suitable - Jolin Tsai\'s "Lemongrass Flavor"34. Our love is the scenery you pass by - Assang, always very quiet35. To be happy, safe, and even happier - - "In an instant" by Jinsha36. I used to think I would always be by his side, but now we have left in the sea of people - "Those flowers" by Fan Weiqi37. Perhaps the final landing point is different, perhaps we will meet again - Zheng Xiuwen\'s "mid air"38. Love is finally the past that you have deleted - - Wang Xinling\'s "Wings"39. Occasionally, I think of him, with some worries in my heart, and some love that has to be settled in different places - He Jie, "You must be happy."40. You were next to me, only making a face to face. On a sunny day in May, there was a flash of electricity - Faye Wong\'s "Flowing Years"41. I have lost it, but cherish it even more - "Beautiful" by Cai Jianya42. I won\'t cry anymore because I believe that we bravely love - - "beautiful love" by Jianya Tsai43. At that time, you were running on the playground, shouting loudly, "I love you, do you know -- Wang Zheng," We are all good children. "44. Although you still hold my hand, I am no longer in your heart - - Sun Yanzi, "I am not sad."45. I really understand. You\'re not someone who likes the new and dislikes the old. It\'s me who wasn\'t by your side when you were lonely. - Stefanie Sun, "I\'m not sad."46. I\'m not sad, it\'s nothing, it\'s just why tears flow. I don\'t understand either - "I\'m not sad," said Stefanie Sun47. Or perhaps this is the best outcome, breaking up now is always better than not loving youI procrastinated time and time again. Release your hand, leave you left and right, I walk forward. This will be me, the true liberation - - "I\'m not sad" by Stefanie Sun48. You know, I\'m waiting for you to come back - Twins, "You\'re the bravest."49. The most beautiful thing is to hear that you still remember. Actually, I am also grateful. When I heard that you still believe in love, Liu Ruoying "heard"50. I heard that there is a new face around me, and I heard that you have blessed me. - Liu Ruoying "Heard"51. I can only embrace the air, pretend it\'s you, never far away - Sun Li "Love is like air"52. You are more important than yourself. I also hope for a better change - Liang Jingru\'s "warmth"53. Fingers clenched tightly, but unable to hold onto eternity - Xu Ruoxuan\'s "Don\'t Love Me"54. Speak slowly, thank you for loving me once - Xu Ruoxuan "Don\'t love me"55. I still love you, with a little bit of hatred, and it takes time to balance. - Wen Lan "Wishing me a happy birthday"56. Holding hands and breaking up come from the same hands, becoming friends again, but why don\'t I know how to keep them? - Sun Yanzi "Rainy Day"57. You used to live in my heart, but now there\'s an empty place - Gigi Leung. "So love hurts so much," she said58. Familiar intersections, still bustling with people, who is waiting for me in the same place? - Tan Weiwei, "If I hadn\'t loved before"59. The hand I once held, promised to last forever in my memory - "If I hadn\'t loved before," said Tan Weiwei60. If I had never loved, never encountered a wound, and how lonely life would be - Tan Weiwei "If I had never loved"61. You don\'t make promises, nor do you apologize, but I\'m caught up in the predicted risks - Jolin Tsai\'s "sour and sweet"62. That day, standing at my fingertips, without asking anything, I believed that we would always be together. That year, there was no declaration, but holding you, I once held the whole world - Jolin Tsai, "sour and sweet"63. I would rather give up on you soberly and painfully, than wronging myself in the dream of love - "Too wronged" by Tao Jingying64. I am just cute, but not enough to be loved - - "Cute" by Yang Chenglin65. The sentence "I love you" always seems to lack courage - - "True or False Question" by Fan Weiqi66. These days, I occasionally think of your love, but facing these memories, I still feel warm - - Wen Lan\'s "Pocket"67. I will hide your warmth - Wen Lan\'s "pocket"68. Happiness is not easy, but why do you dare not? - "Worship" by Liang Jingru69. No matter what, it will get hurt no matter what - "For the future self" by Liang Jingru70. Before returning to reality, we sincerely said goodbye to each other. I said don\'t remember me in the future, just pretend that nothing has happened to us - Qin Hailu, "Nothing has happened."71. Actually, I rarely think of you, rarely recall, just in the evening————Liu Ruoying\'s "Evening"72. When I am alone, I forget that I will still be lonely - -- Liu Ruoying\'s "Evening"73. Life is not too long, there is no end to the future, is it enough to take me away - "Stars under the Sunshine" by Jin Haixin74. You see, I am still so gentle, but I am a friend of friends - Zhou Bichang\'s "First Anniversary"75. I locked up your photo, but I still remember your birthday - Zhou Bichang\'s "one-year anniversary"76. Happiness is a bubble, but at least I have caught - Miriam Yeung, "I\'m good."77. Although she said she wanted to forget, she still remembers everything - -- Luo Meiling\'s "Red Sunflower"78. I am very happy, please don\'t say that you love me again - Xianzi\'s "Third Party of the Third Party"79. Accustomed to being alone, I am not without you - Xian Zi\'s "Third Party of the Third Party"80. You can\'t see me crying before I turn around - SHE, "You\'re too honest."81. How could love lose to time - -- Wang Xinling "See you tomorrow"82. What a pity I still deserve to be invited, this is sympathy, not emotion - Jolin Tsai "Be You for a Day"83. Happiness cannot be described as sour or sweet candy - Liang Jingru\'s "Beautiful Life"84. I know memories are a kind of foolishness, and this life only allows me to be foolish once. - Hou Xiangting, "Tears shed for you"85. Love is too short, but memories are too long - Hou Xiangting\'s "Tokyo Kiss"86. Dreams are too short, regrets are too long - -- Xiao Yaxuan "No one"87. No one has ever come to my heart, I am just the place where you stopped midway - Xiao Yaxuan "No one"88. Actually, I have always wanted to tell you personally that it\'s not easy for you to love me, right? But you don\'t ask for the price - Mo Wenwei, "Actually, I have always wanted to tell you."89. Sometimes when we gather and leave, nothing lasts forever - -- Faye Wong\'s "Red Bean"90. I met you, it was the most beautiful accident - - Sun Yanzi "met"91. Sometimes, even without you, I feel the same way. At most, my eyes turn red again - Jin Haixin\'s "Sad Swing"92. I just want the lamp that will never be extinguished in the afterlife, to illuminate the people of this world\'s game. I just want the deepest kiss, and years later, there will still be your warmth - Lin Chenxi "I don\'t want to ask"93. I just want someone to be with me, no matter where tomorrow is. - Liu Ruoying, "When Love is Approaching"94. If I really decide to give my heart, can someone tell him not to make me sad? - Liu Ruoying "When love is approaching"95. I am not the only general in your eyes, just an inconspicuous soldier - Wang Fei\'s "chess piece"96. Anyway, in the end, everyone was lonely - "I don\'t want this either," said Faye Wong97. After you, I love myself more - "After Xiao Yaxuan"98. How long has it been since I was moved,If it weren\'t for your strong protection of me, if it weren\'t for your words, you wouldn\'t have much, but would be willing to leave the best for me - - "Daphne\'s Air Defense Shelter"99. The next second I shed tears, I completely understood that you are someone else and have nothing to do with my love. - Xu Huixin, "My Beautiful Love"100. I will learn to walk out of the past and bless tomorrow. - Wang Xinling "See you tomorrow"101. The fingerprint I left in your chaotic world is a heartless kiss to you———— Sun Yanzi\'s Invisible Man102. You don\'t want me to believe in eternity, you don\'t want me to be superstitious, you don\'t want me to be reckless———— Sun Yanzi\'s Invisible Man103. It is known that I am devout in love and superstitious. I know I rarely let go———— Sun Yanzi\'s Invisible Man104. Missing is the pain of breathing, it lives in every corner of me. Regretting not being considerate will hurt, hating not understanding you will hurt, wanting to see but not seeing will hurt the most———— Liang Jingru\'s "Breathing Pain"105. I swear I won\'t lie anymore. I\'ll hold you as tightly as I love you. My smile is fake, and my soul seems to be floating. If you come back, that\'s all———— Liang Jingru\'s "Breathing Pain"106. My world is changing for you day by day, you haven\'t noticed it, you can\'t see all my efforts. As long as today is over, I will love myself more and there will be no more vows from you in my world———— Guan Xinyan\'s "End Point"107. If one day we have the chance to meet again, will you remember the eternity we said———— BY2 is not mature enough108. I don\'t believe that love is difficult, there is no residual warmth———— Zhuo Wenxuan is "brave alone"109. I can\'t bear to part with it, but time can\'t go back. Loving you is worth it, but it\'s time to stop. You need to be okay without me. I can\'t bear to part with you. I held you tightly for the last time, what we missed. If we were wrong, it would be wrong. Don\'t worry about me, I don\'t love you anymore———— Xuanzi "cannot bear to part with"110. Who still remembers who said forever love me first? The previous sentence is our future wound———— Zhang Huimei "remembers"111. After too long, no one remembers those gentle moments back then. You and I held hands and said we were going to walk together until the end———— Zhang Huimei "remembers"112. I can\'t find it, I can\'t reach it, that so-called beauty of love. I don\'t want anything, do you know? If you understand this second of mine———— Fan Weiqi "can\'t make it"113. I want to see, I am searching for what you call the beauty of the future. I firmly rely on you, hold on tightly, and dare not miss a single bit. May you see———— Fan Weiqi "can\'t make it"114. A heart belongs to one person, what is considered fair in love———— "Unfair"115. Loving you is a lonely concern, not understanding the meaning of your smile. Only like a sunflower, silently persevering at night———— Lan Youshi\'s Lonely Hearts116. I used to be too young but absolutely sincere. The love I gave was always capricious, not understanding the love that only blooms once———— Blue Youshi once"Being too young"117. I don\'t want to forget you. If possible, I would rather remember all the sadness———— Guo Jing, "I don\'t want to forget you."118. Are you still afraid of constantly thinking of you in the dead of night, or are you afraid of accidentally hearing your news———— Stefanie Sun is "scared"119. I have been brave for too long and decided to live for you alone. I dare not speak out, so lonely. Illuminated the silence, love turned out to be lonely———— Zhang Huimei is "Brave"120. What I miss is saying everything. What I miss is dreaming together. What I miss is the impulse to love you even after an argument. What I miss is that you are so excited that you ask me for forgiveness, and it hurts me to hug you———— Sun Yanzi: "I miss it."\n', '<files3.f3test.QuickTest_CustomClass object ', 'None', 'None', "<class 'files3.f3test.QuickTest_CustomClass'>", '<files3.f3test.QuickTest_CustomClass object ', 'None', "<class 'files3.f3test.QuickTest_CustomClass'>", '<files3.f3test.QuickTest_CustomClass object ']

def AdvancedTest(tolist=False):
    results = []
    f = files("", '.inst', '.sinst')
    _testnum = 37 + 1 + 3
    # skey 增删改查
    f.set('a', 1)
    f.set('a', 2, skey='b')
    f.set('a', 3, skey='c')
    f['a', 'd'] = 4
    f['a', 'e'] = 114.514
    f['a', 'f'] = 'Hello, world!'
    f['a', 'g'] = None
    f['a', 'h'] = False
    f['b'] = (1,2,3)
    f['b', 'a'] = [4,5,6]
    f['b', 'b'] = {'a': 1, 'b': 2}
    f['b', 'c'] = (['.py', '.c', '.cpp', '.js'], {"language": "python"}, 648)
    f['b', 'd'] = dir
    f['b', 'e'] = exec
    f['b', 'f'] = QuickTest_CustomClass
    f['b', 'g'] = QuickTest_CustomClass()
    f['b', 'h'] = QuickTest_CustomFunction
    f['b', 'i'] = (['.py', '.c', '.cpp', '.js'], QuickTest_CustomFunction, {"language": "python", 'class': QuickTest_CustomClass}, 648)
    f['b', 'j'] = eval
    f['b', 'k'] = [enumerate, eval]
    f['b', 'l'] = [list, f['b', 'k']]
    f['b', 'm'] = [zip, f['b', 'l']]
    f['b', 'n'] = [chr, f['b', 'm']]
    f['b', 'o'] = [super, f['b', 'n']]
    f['b', 'p'] = [ord, f['b', 'o']]
    f['b', 'q'] = [print, f['b', 'p']]
    f['b', 'r'] = [pow, f['b', 'q']]
    f['b', 's'] = [object, f['b', 'r']]
    f['b', 't'] = [set, f['b', 's']]
    f['b', 'u'] = [bytearray, f['b', 't']]
    f['b', 'v'] = [ascii, f['b', 'u']]
    f['b', 'w'] = [complex, f['b', 'v']]
    f['b', 'x'] = _big_str
    f['b', 'y'] = QuickTest_CustomClass()
    f['b', 'z'] = QuickTest_CustomFunction()
    f['c', 'a'] = QuickTest_CustomClass
    f['c', 'b'] = QuickTest_CustomClass()
    bs = f.pack(f._f3info('c'))
    for mkey, skey in f.walk():
        results.append(f[mkey, skey])


    for mkey, skey in f.walk():
        if random.randint(0, 1):
            f.delete(mkey, skey)
        else:
            del f[mkey, skey]

    f.unpack(bs, f._f3info.path)
    results.append(f['c'])
    results.append(f['c', 'a'])
    results.append(f['c', 'b'])
    f.delete('c')

    output_f = files(os.getcwd(), ".f3bytes")
    output_f.set('AdvancedTest', results)
    output_f.set('AdvancedTestX10', results * 10)

    # Compare with the reference answer
    _score, _fails, _newlist = 0, [], []
    for v in results:
        v = str(v)
        v = re.sub('at 0x.+>', "", v)
        _newlist.append(v)
        if v in _AdvancedTestReference:
            _score += 1
        else:
            _fails.append(v)

    if tolist: return _newlist

    _score = str(round(_score * 100 / _testnum)) + '%'
    _reason = ("Failed: (CodeReturn)\n" + '\n'.join(_fails)) if _fails else "Test Ok!"
    return _score + '\n' + _reason

def InterfaceTest():
    """
    接口一致性测试：验证 F3Backend Protocol、F3Mem 子键语义、
    F3Shell bug 修复、save/load 等功能。
    """
    import tempfile
    import shutil
    from files3.interface import F3Backend
    from files3.f3mem import F3Mem
    from files3.f3shell import F3Shell

    _testnum = 9
    _errors = []

    def _assert(cond, msg):
        if not cond:
            _errors.append(msg)

    # ===== Test 1: Protocol isinstance =====
    _assert(isinstance(F3Shell(), F3Backend), "T1: F3Shell is not F3Backend")
    _assert(isinstance(F3Mem('t1'), F3Backend), "T1: F3Mem is not F3Backend")

    # ===== Test 2: F3Mem subkey semantics =====
    m = F3Mem('t2')
    m.set('a', 1)
    m.set('b', 10, skey='sub')

    _assert(m.get('a') == 1, "T2: m.get('a') != 1")
    _assert(m.get('b') is None, "T2: m.get('b') should be None (default subkey)")
    _assert(m.get('b', 'sub') == 10, "T2: m.get('b', 'sub') != 10")
    _assert('sub' in m.list('b'), "T2: 'sub' not in m.list('b')")
    _assert('b' in list(m.keys()), "T2: 'b' not in m.keys()")

    _walk = list(m.walk())
    _assert(('a', '') in _walk, "T2: ('a', '') not in walk")
    _assert(('b', '') in _walk, "T2: ('b', '') not in walk")
    _assert(('b', 'sub') in _walk, "T2: ('b', 'sub') not in walk")

    # ===== Test 3: F3Mem / F3Shell consistency =====
    tmpdir = tempfile.mkdtemp()
    f = F3Shell(tmpdir)
    f.set('x', 100)
    f.set('y', 200, skey='s')

    m2 = F3Mem('t3')
    m2.set('x', 100)
    m2.set('y', 200, skey='s')

    _assert(list(f.keys()) == list(m2.keys()),
            f"T3: keys mismatch f={list(f.keys())} m={list(m2.keys())}")
    _assert(f.list('y') == m2.list('y'),
            f"T3: list('y') mismatch f={f.list('y')} m={m2.list('y')}")
    _assert(list(f.walk()) == list(m2.walk()),
            f"T3: walk mismatch f={list(f.walk())} m={list(m2.walk())}")
    _assert(f.get('y') == m2.get('y'), "T3: get('y') mismatch")
    _assert(f.get('y', 's') == m2.get('y', 's'), "T3: get('y', 's') mismatch")

    # ===== Test 4: F3Mem filter syntax =====
    m3 = F3Mem('t4')
    m3['a'] = 1
    m3['b'] = 2
    m3['c'] = 3

    _assert(m3[...] == [1, 2, 3], f"T4: m[...] != [1,2,3], got {m3[...]}")

    m3[['a', 'b']] = 99
    _assert(m3['a'] == 99, "T4: batch set 'a' failed")
    _assert(m3['b'] == 99, "T4: batch set 'b' failed")

    m3[re.compile(r'^b')] = 88
    _assert(m3['b'] == 88, "T4: regex set 'b' failed")

    m3[lambda n, t: n == 'c'] = 77
    _assert(m3['c'] == 77, "T4: func set 'c' failed")

    # ===== Test 5: F3Shell __contains__ =====
    _assert('x' in f, "T5: 'x' in f failed")
    _assert('z' not in f, "T5: 'z' not in f failed")
    _assert(re.compile(r'^x') in f, "T5: regex in f failed")
    _assert((lambda n, t: n == 'x') in f, "T5: func in f failed")
    _assert(['x', 'y'] in f, "T5: list in f failed")

    # ===== Test 6: F3Shell iter/list with subkey folder =====
    f2 = F3Shell(tmpdir)
    f2.set('p', 1)
    f2.set('p', 2, skey='q')
    _assert('p' in list(f2.keys()), "T6: 'p' not in keys after subkey")
    _assert('p' in f2.list(), "T6: 'p' not in list() after subkey")

    # ===== Test 7: F3Mem delete return value =====
    m4 = F3Mem('t7')
    _assert(m4.delete('nonexist') == F3True, "T7: delete nonexist should return F3True")
    _assert(m4.delete('nonexist', 'sub') == F3True, "T7: delete nonexist subkey should return F3True")

    # ===== Test 8: F3Mem save/load =====
    m5 = F3Mem('t8')
    m5['k1'] = 'hello'
    m5['k2', 'sk'] = 'world'

    tmpdir2 = tempfile.mkdtemp()
    _assert(m5.save(tmpdir2) == F3True, "T8: save failed")

    m6 = F3Mem('t8_load')
    _assert(m6.load(tmpdir2) == F3True, "T8: load failed")
    _assert(m6['k1'] == 'hello', "T8: load k1 mismatch")
    _assert(m6['k2', 'sk'] == 'world', "T8: load k2/sk mismatch")
    _assert('sk' in m6.list('k2'), "T8: load list('k2') mismatch")

    # load from F3Shell instance
    f3 = F3Shell(tmpdir2)
    m7 = F3Mem('t8_inst')
    _assert(m7.load(f3) == F3True, "T8: load from instance failed")
    _assert(m7['k1'] == 'hello', "T8: load inst k1 mismatch")

    # ===== Test 9: Cleanup =====
    m8 = F3Mem('t9')
    m8['x'] = 1
    m8.clear()
    _assert(list(m8.keys()) == [], "T9: clear failed")
    _assert(len(list(m8.keys())) == 0, "T9: len after clear != 0")

    # ===== Cleanup all =====
    for _ns in ['t2', 't3', 't4', 't7', 't8', 't8_load', 't8_inst', 't9']:
        _m = F3Mem(_ns)
        _m.clear()
    F3Mem.releaseAll()
    shutil.rmtree(tmpdir, ignore_errors=True)
    shutil.rmtree(tmpdir2, ignore_errors=True)

    # ===== Result =====
    _pass = _testnum - len(_errors)
    _score = str(round(_pass * 100 / _testnum)) + '%'
    _reason = ('Failed:\n' + '\n'.join(_errors)) if _errors else 'Test Ok!'
    return _score + '\n' + _reason


def MemIndexTest():
    """
    测试 F3Mem 索引自动扩容、TTL、旧格式兼容、进程退出清理
    """
    from files3.f3mem import F3Mem
    from files3.f3bool import F3True, F3False

    _errors = []

    def _assert(cond, msg):
        if not cond:
            _errors.append(msg)

    # Test 1: TTL 过期后 get 返回 F3False
    m = F3Mem('memidx_t1')
    m.set('a', 42, ttl=0.1)
    _assert(m.get('a') == 42, "T1: get before ttl should be 42")
    time.sleep(0.3)
    _assert(m.get('a') == F3False, "T1: get after ttl should be F3False")

    # Test 2: TTL 过期后 has 返回 F3False
    m2 = F3Mem('memidx_t2')
    m2.set('b', 1, ttl=0.1)
    time.sleep(0.3)
    _assert(m2.has('b') == F3False, "T2: has after ttl should be F3False")

    # Test 3: TTL 过期后 keys 不包含该 key
    m3 = F3Mem('memidx_t3')
    m3.set('c', 2, ttl=0.1)
    time.sleep(0.3)
    _assert('c' not in m3.keys(), "T3: expired key should not be in keys")

    # Test 4: skey TTL
    m4 = F3Mem('memidx_t4')
    m4.set('d', 3, skey='sub', ttl=0.1)
    time.sleep(0.3)
    _assert(m4.get('d', 'sub') == F3False, "T4: skey get after ttl should be F3False")

    # Test 5: 无 TTL 数据正常持久
    m5 = F3Mem('memidx_t5')
    m5.set('e', 5)
    _assert(m5.get('e') == 5, "T5: no ttl get should work")

    # Test 6: delete 正常清理
    m6 = F3Mem('memidx_t6')
    m6.set('f', 6)
    m6.delete('f')
    _assert(m6.get('f') == F3False, "T6: delete should remove key")

    # Test 7: clear 正常清理
    m7 = F3Mem('memidx_t7')
    m7.set('g', 7)
    m7.set('g', 8, skey='sub')
    m7.clear()
    _assert(m7.get('g') == F3False, "T7: clear should remove keys")
    _assert(m7.get('g', 'sub') == F3False, "T7: clear should remove subkeys")

    # Test 8: releaseAll 后能重新初始化
    F3Mem.releaseAll()
    m8 = F3Mem('memidx_t8')
    m8.set('h', 8)
    _assert(m8.get('h') == 8, "T8: after releaseAll reinit should work")

    # Cleanup
    for _ns in ['memidx_t1', 'memidx_t2', 'memidx_t3', 'memidx_t4',
                'memidx_t5', 'memidx_t6', 'memidx_t7', 'memidx_t8']:
        _m = F3Mem(_ns)
        _m.clear()
    F3Mem.releaseAll()

    _pass = 8 - len(_errors)
    _score = str(round(_pass * 100 / 8)) + '%'
    _reason = ('Failed:\n' + '\n'.join(_errors)) if _errors else 'Test Ok!'
    return _score + '\n' + _reason


def VirtualDiskTest():
    """
    虚拟磁盘模式测试：验证 releaseAll 后数据仍持久存在
    """
    from files3.f3mem import F3Mem
    from files3.f3bool import F3True, F3False

    _errors = []

    def _assert(cond, msg):
        if not cond:
            _errors.append(msg)

    # Test 1: releaseAll 后数据仍然可读
    m1 = F3Mem('vd_t1')
    m1.set('persist', 'hello')
    m1.set('persist', 'world', skey='sub')
    F3Mem.releaseAll()

    m2 = F3Mem('vd_t1')
    _assert(m2.get('persist') == 'hello', "T1: data should survive releaseAll")
    _assert(m2.get('persist', 'sub') == 'world', "T1: subkey should survive releaseAll")

    # Test 2: 新进程级实例可以访问同一命名空间
    m3 = F3Mem('vd_t1')
    m3.set('new', 123)
    _assert(m2.get('new') == 123, "T2: new instance should see cross-instance writes")

    # Test 3: clear 真正删除数据
    m4 = F3Mem('vd_t1')
    m4.clear()
    _assert(m4.get('persist') == F3False, "T3: clear should truly remove data")

    # Test 4: 空ns与有ns的数据隔离
    m_empty1 = F3Mem('')
    m_empty1.set('shared', 'empty_ns')
    m_ns1 = F3Mem('vd_ns')
    m_ns1.set('shared', 'named_ns')
    _assert(m_empty1.get('shared') == 'empty_ns', "T4: empty ns isolation")
    _assert(m_ns1.get('shared') == 'named_ns', "T4: named ns isolation")

    # Cleanup
    for _ns in ['vd_t1', 'vd_ns', '']:
        _m = F3Mem(_ns)
        _m.clear()
    F3Mem.releaseAll()

    _pass = 4 - len(_errors)
    _score = str(round(_pass * 100 / 4)) + '%'
    _reason = ('Failed:\n' + '\n'.join(_errors)) if _errors else 'Test Ok!'
    return _score + '\n' + _reason


if __name__ == '__main__':
    # Please test in __init__.py
    print("Please test in __init__.py")


