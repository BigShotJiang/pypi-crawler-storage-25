from soigia.tester import Tester


def test_tester_artifacts_roundtrip():
    tester = Tester()

    text_path = tester.write_text("sample.txt", "hello")
    assert text_path.exists()
    assert tester.read_text("sample.txt") == "hello"

    yaml_path = tester.write_yaml("config.yaml", {"name": "demo", "enabled": True})
    assert yaml_path.exists()
    payload = tester.read_yaml("config.yaml")
    assert payload["name"] == "demo"
    assert payload["enabled"] is True

    assert tester.exists("sample.txt")
    assert tester.root_dir().name == "soigia-sdk"
    tester.cleanup()
