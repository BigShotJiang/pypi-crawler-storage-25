def test_orm_examples_modules_import():
    import examples.db_sales
    import examples.db_school

    assert examples.db_sales.__name__ == "examples.db_sales"
    assert examples.db_school.__name__ == "examples.db_school"
