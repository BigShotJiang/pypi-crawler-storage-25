from pathlib import Path

from soigia.config import ConfigStore, default_config, load_config, resolve_config_path, save_config, upsert_account


def test_config_store_roundtrip_and_account_helpers():
    artifact_dir = Path.cwd() / ".config_test_artifacts"
    artifact_dir.mkdir(exist_ok=True)
    path = artifact_dir / "config.yaml"
    try:
        config = default_config()
        upsert_account(
            config,
            "binance",
            "main",
            {
                "label": "Binance main",
                "enabled": True,
                "credentials": {"api_key": "key-123", "api_secret": "secret-456"},
                "settings": {"account_type": "spot"},
                "notes": "Primary exchange account",
            },
        )
        saved_path = save_config(config, path)
        loaded = load_config(saved_path)
        store = ConfigStore(saved_path)

        assert resolve_config_path(saved_path) == saved_path.resolve()
        assert store.get_account("binance", "main")["credentials"]["api_key"] == "key-123"
        assert loaded["accounts"]["binance"]["main"]["settings"]["account_type"] == "spot"
        assert store.get_accounts("binance")
    finally:
        if path.exists():
            path.unlink()
