"""Import smoke tests for the public datatable entrypoint."""

import soigia
import soigia.datatable as dtpkg
import soigia.pipeline as ppkg

from soigia.datatable import DataTable, datatable
from soigia.pipeline import Pipeline
from soigia.demo import Shopee, ShopeeUpsertDemo


def test_datatable_module_exports_data_table():
    assert hasattr(dtpkg, "DataTable")
    assert dtpkg.DataTable is DataTable
    assert datatable is DataTable
    assert callable(dtpkg.from_faker)
    assert callable(dtpkg.from_factory)


def test_soigia_package_can_expose_datatable_entrypoint():
    assert soigia.datatable.DataTable is DataTable


def test_soigia_package_can_expose_pipeline_entrypoint():
    assert ppkg.Pipeline is Pipeline
    assert soigia.pipeline.Pipeline is Pipeline


def test_demo_can_load_from_csv_without_pandas(monkeypatch):
    from pathlib import Path

    sandbox = Path.cwd() / ".test_artifacts" / "demo_csv_load"
    sandbox.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(sandbox)

    pipeline = Shopee(name="demo")
    pipeline.load_data()

    assert isinstance(pipeline.datatable, DataTable)
    assert pipeline.datatable.to_rows() == [
        {"id": 1, "name": " alice ", "status": "new", "amount": 120.5},
        {"id": 2, "name": "bob", "status": "active", "amount": 80.0},
        {"id": 3, "name": "carol", "status": "active", "amount": 150.0},
    ]

    upsert_pipeline = ShopeeUpsertDemo(name="upsert-demo")
    upsert_pipeline.load_data()

    assert isinstance(upsert_pipeline.datatable, DataTable)
    assert upsert_pipeline.datatable.to_rows() == [
        {"id": 1, "name": "alice", "status": "new", "amount": 100.0},
        {"id": 2, "name": "bob", "status": "active", "amount": 200.0},
    ]


def test_demo_cli_runs_with_defaults_and_prints_table(monkeypatch, capsys):
    from pathlib import Path

    sandbox = Path.cwd() / ".test_artifacts" / "demo_cli_default"
    sandbox.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(sandbox)

    outcome = Shopee.cli([])
    captured = capsys.readouterr()

    assert outcome.success
    assert "alice" in captured.out.lower()


def test_demo_cli_can_disable_default_table_display(monkeypatch, capsys):
    from pathlib import Path

    sandbox = Path.cwd() / ".test_artifacts" / "demo_cli_no_show"
    sandbox.mkdir(parents=True, exist_ok=True)
    monkeypatch.chdir(sandbox)

    outcome = Shopee.cli(["--no-show-datatable"])
    captured = capsys.readouterr()

    assert outcome.success
    assert captured.out.strip() == ""
