"""Tests for fake-data helpers."""

from soigia.datatable import DataTable


def test_from_faker_generates_fake_rows():
    table = DataTable.from_faker(
        {
            "name": "name",
            "email": "email",
            "age": lambda fake: fake.random_int(min=18, max=30),
            "city": "city",
        },
        count=5,
        seed=7,
    )

    assert isinstance(table, DataTable)
    assert len(table) == 5
    assert set(["name", "email", "age", "city"]).issubset(table.columns)
    assert table["age"].between(18, 30).all()


def test_from_factory_generates_fake_rows_from_batch_factory():
    class FakeUserFactory:
        @classmethod
        def build_batch(cls, size=1, **kwargs):
            rows = []
            for idx in range(size):
                rows.append(
                    {
                        "name": f"user_{idx}",
                        "age": 20 + idx,
                        "city": kwargs.get("city", "hanoi"),
                    }
                )
            return rows

    table = DataTable.from_factory(FakeUserFactory, count=3, city="saigon")

    assert isinstance(table, DataTable)
    assert table.to_rows() == [
        {"name": "user_0", "age": 20, "city": "saigon"},
        {"name": "user_1", "age": 21, "city": "saigon"},
        {"name": "user_2", "age": 22, "city": "saigon"},
    ]
