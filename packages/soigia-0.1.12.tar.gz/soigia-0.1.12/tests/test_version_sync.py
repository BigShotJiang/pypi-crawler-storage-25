"""Version sync checks for release automation."""

from pathlib import Path
import re

import soigia


def test_package_version_matches_pyproject():
    pyproject_text = Path("pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'^version\s*=\s*"([^"]+)"\s*$', pyproject_text, flags=re.MULTILINE)
    assert match is not None
    assert soigia.__version__ == match.group(1)
