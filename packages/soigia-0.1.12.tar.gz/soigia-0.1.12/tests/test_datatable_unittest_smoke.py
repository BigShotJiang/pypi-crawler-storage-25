"""Smoke tests for the DataTable unittest-style helpers."""

import unittest

from soigia.datatable import DataTable


class DataTableUnittestSmoke(unittest.TestCase):
    def setUp(self):
        self.table = DataTable({"name": ["alice", "bob"], "age": [19, 24]})

    def test_assert_helpers_run_under_unittest(self):
        self.table.assertEqual(len(self.table), 2)
        self.table.assertIn("name", self.table.columns)
        self.table.assertIsInstance(self.table, DataTable)
        self.table.assertGreater(self.table["age"].max(), 20)

    def test_exception_helpers_run_under_unittest(self):
        with self.table.assertRaises(KeyError):
            _ = self.table["missing_column"]

        with self.table.assertRaisesRegex(ValueError, "bad"):
            raise ValueError("bad value")

        with self.table.assertNoLogs("soigia.unittest.smoke", level="INFO"):
            pass


if __name__ == "__main__":
    unittest.main(verbosity=2)
