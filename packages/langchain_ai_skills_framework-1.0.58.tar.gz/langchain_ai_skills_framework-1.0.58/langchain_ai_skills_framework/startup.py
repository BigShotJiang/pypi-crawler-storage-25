from __future__ import annotations

import logging

from langchain_ai_skills_framework.loaders.skill_sync import SkillSync
from langchain_ai_skills_framework.loaders.plugin_skill_store import PluginSkillStore
from langchain_ai_skills_framework.utilities.logger.log_levels import SRC_LOG_LEVELS

logger = logging.getLogger(__name__)
logger.setLevel(SRC_LOG_LEVELS["SKILLS"])


async def initialize_skills(
    *,
    user_store: PluginSkillStore,
    skill_sync: SkillSync,
) -> None:
    """Run skill framework initialization on server startup.

    This should be called once during the application lifespan.  It:
    1. Creates MongoDB indexes (idempotent).
    2. Syncs shared skills from GitHub/filesystem into MongoDB,
       inserting any that are missing without overwriting existing ones.
    """
    logger.info("Skills startup: ensuring indexes...")
    await user_store.ensure_indexes()

    logger.info("Skills startup: syncing shared skills to MongoDB...")
    try:
        result = await skill_sync.sync()
        logger.info(
            "Skills startup: sync complete — "
            "plugins_synced=%d skills_synced=%d resources_synced=%d "
            "scripts_synced=%d errors=%d",
            result.plugins_synced,
            result.skills_added,
            result.resources_added,
            result.scripts_added,
            result.errors,
        )
    except Exception:
        logger.exception(
            "Skills startup: marketplace sync failed — the gateway will continue with previously synced skills"
        )
