from __future__ import annotations

from typing import Any, Literal, Optional, Tuple, Type, override

from langchain_core.callbacks import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.tools import BaseTool, ToolException
from langgraph.prebuilt.tool_node import ToolRuntime
from pydantic import BaseModel, ConfigDict, Field

from langchain_ai_skills_framework.loaders.plugin_skill_store import (
    PluginSkillStore,
)
from langchain_ai_skills_framework.services.skill_operation_error import SkillOperationError
from langchain_ai_skills_framework.services.toggle_skill_sharing_service import ToggleSkillSharingService


class ToggleSkillSharingInput(BaseModel):
    """Input schema for the toggle_skill_sharing tool."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)

    plugin_name: str = Field(
        description="Name of the plugin containing the skill.",
    )
    skill_name: str = Field(
        description="Name of the skill to toggle sharing for.",
    )
    shared: bool = Field(
        description="True to share the skill with all users, False to make it private.",
    )
    runtime: ToolRuntime


class ToggleSkillSharingTool(BaseTool):
    """LangChain tool that toggles a skill between shared and private."""

    name: str = "toggle_skill_sharing"
    description: str = (
        "Toggle whether a saved skill is shared with all users or private to the owner. The skill must already exist."
    )
    args_schema: Type[BaseModel] = ToggleSkillSharingInput
    response_format: Literal["content", "content_and_artifact"] = "content_and_artifact"
    mongo_skill_loader: Optional[PluginSkillStore] = None

    @override
    def _run(
        self,
        *,
        plugin_name: str,
        skill_name: str,
        shared: bool,
        runtime: ToolRuntime,
        run_manager: CallbackManagerForToolRun | None = None,
    ) -> Tuple[str, str]:
        raise NotImplementedError("Synchronous execution is not supported. Use the asynchronous method instead.")

    @override
    async def _arun(
        self,
        *,
        plugin_name: str,
        skill_name: str,
        shared: bool,
        runtime: ToolRuntime,
        run_manager: AsyncCallbackManagerForToolRun | None = None,
    ) -> Tuple[str, str]:
        ctx: dict[str, Any] = runtime.context or {} if runtime else {}
        user_id = (ctx.get("user_id", "") or "").strip()

        service = ToggleSkillSharingService(mongo_skill_loader=self.mongo_skill_loader)
        try:
            message = await service.execute(
                user_id=user_id, plugin_name=plugin_name, skill_name=skill_name, shared=shared
            )
            return message, message
        except SkillOperationError as exc:
            raise ToolException(str(exc)) from exc

    @staticmethod
    def get_friendly_name(*, tool_input: dict[str, Any]) -> str:
        skill_name = str(tool_input.get("skill_name", "")) if tool_input else ""
        return f"Toggle Skill Sharing: {skill_name}" if skill_name else "Toggle Skill Sharing"
