from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.memory_extract import build_memory_extraction_tool_validator
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.forked.api import run_forked_agent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.tools import Bash, Edit, Glob, Grep, Read, Write
from comate_agent_sdk.tools.decorator import tool


@tool("Extra tool for tests", name="ExtraTool")
async def _extra_tool() -> str:
    return "extra"


def _tool_call(*, tool_call_id: str, name: str, arguments: dict) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(
            name=name,
            arguments=json.dumps(arguments, ensure_ascii=False),
        ),
    )


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self.model = "fake:model"
        self._completions = completions
        self._index = 0
        self.calls: list[list[object]] = []
        self.tool_names_per_call: list[list[str]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tool_choice, kwargs
        self.calls.append(list(messages))
        self.tool_names_per_call.append([tool.name for tool in (tools or [])])
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class TestMemoryWriteGate(unittest.IsolatedAsyncioTestCase):
    async def test_run_forked_agent_validator_rejects_write_outside_memory_dir(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(
                            tool_call_id="tc-write-1",
                            name="Write",
                            arguments={"file_path": "notes.txt", "content": "blocked\n"},
                        )
                    ]
                ),
                ChatInvokeCompletion(content="validator handled"),
            ]
        )
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(Write,),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp.name),
            ),
        )
        runtime = template.create_runtime()
        memory_dir = resolve_auto_memory_dir(runtime)
        validator = build_memory_extraction_tool_validator(memory_dir)

        result = await run_forked_agent(
            runtime,
            "child prompt",
            allowed_tools={"Write"},
            tool_use_validator=validator,
        )

        self.assertEqual(result, "validator handled")
        second_call_texts = [getattr(message, "text", "") for message in llm.calls[1]]
        self.assertTrue(any("memory directory" in text for text in second_call_texts))
        self.assertFalse((Path(tmp.name) / "notes.txt").exists())

    async def test_run_forked_memory_extraction_keeps_parent_tool_schema_for_cache_stability(self) -> None:
        llm = _FakeChatModel([ChatInvokeCompletion(content="done")])
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(Read, Grep, Glob, Bash, Write, Edit, _extra_tool),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp.name),
            ),
        )
        runtime = template.create_runtime()
        memory_dir = resolve_auto_memory_dir(runtime)

        await run_forked_agent(
            runtime,
            "child prompt",
            allowed_tools={"Read", "Grep", "Glob", "Bash", "Write", "Edit"},
            tool_use_validator=build_memory_extraction_tool_validator(memory_dir),
        )

        self.assertEqual(
            llm.tool_names_per_call[0],
            ["Read", "Grep", "Glob", "Bash", "Write", "Edit", "ExtraTool"],
        )

    def test_memory_extraction_validator_allows_read_search_and_bash_tools(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        memory_dir = Path(tmp.name) / "memory"
        memory_dir.mkdir()
        validator = build_memory_extraction_tool_validator(memory_dir)

        self.assertIsNone(validator("Read", {"file_path": "src/app.py"}))
        self.assertIsNone(validator("Grep", {"pattern": "needle"}))
        self.assertIsNone(validator("Glob", {"pattern": "**/*.py"}))
        self.assertIsNone(validator("Bash", {"command": "git status --short"}))

    def test_memory_extraction_validator_allows_nested_topic_files_but_rejects_memory_index(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        memory_dir = Path(tmp.name) / "memory"
        memory_dir.mkdir()
        validator = build_memory_extraction_tool_validator(memory_dir)

        self.assertIsNone(validator("Write", {"file_path": "memory/team/debugging.md"}))
        self.assertIsNone(validator("Edit", {"file_path": (memory_dir / "team" / "debugging.md").as_posix()}))
        self.assertIn("topic files", validator("Write", {"file_path": "memory/MEMORY.md"}) or "")
        self.assertIn("topic files", validator("Edit", {"file_path": "memory/team/MEMORY.md"}) or "")
        self.assertIn("topic files", validator("Write", {"file_path": "notes.md"}) or "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
