from __future__ import annotations

import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import AsyncMock

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.llm import invoke_llm
from comate_agent_sdk.agent.memory_runtime import start_relevant_memory_prefetch
from comate_agent_sdk.forked.runtime import ForkedAgentRuntime
from comate_agent_sdk.forked.snapshot import clone_context_ir_for_fork
from comate_agent_sdk.llm.messages import AssistantMessage, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tools.decorator import tool


@tool("Read files for tests", name="Read")
async def _read_tool(file_path: str) -> str:
    return file_path


@tool("Write files for tests", name="Write")
async def _write_tool(file_path: str, content: str) -> str:
    return f"{file_path}:{content}"


@tool("Run shell for tests", name="Bash")
async def _bash_tool(command: str) -> str:
    return command


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion] | None = None) -> None:
        self.model = "fake:model"
        self._completions = list(completions or [ChatInvokeCompletion(content="ok")])
        self._index = 0

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class TestForkedAgentRuntime(unittest.IsolatedAsyncioTestCase):
    def _build_parent_runtime(
        self,
        *,
        llm: _FakeChatModel,
        disallowed_tools: tuple[str, ...] | None = None,
    ) -> tuple[tempfile.TemporaryDirectory[str], object]:
        tmp = tempfile.TemporaryDirectory()
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(_read_tool, _write_tool, _bash_tool),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp.name),
                disallowed_tools=disallowed_tools,
            ),
        )
        runtime = template.create_runtime()
        runtime._context.add_message(UserMessage(content="parent-user"))
        runtime._context.add_message(AssistantMessage(content="parent-assistant", tool_calls=None))
        return tmp, runtime

    async def test_forked_runtime_uses_cloned_parent_context(self) -> None:
        tmp, parent = self._build_parent_runtime(llm=_FakeChatModel())
        self.addCleanup(tmp.cleanup)

        context_snapshot = clone_context_ir_for_fork(parent._context)
        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=context_snapshot,
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertIs(runtime._context, context_snapshot)
        self.assertIsNot(runtime._context, parent._context)
        self.assertEqual(runtime._context.total_tokens, parent._context.total_tokens)

    async def test_forked_runtime_always_uses_parent_llm_and_level(self) -> None:
        parent_llm = _FakeChatModel()
        tmp, parent = self._build_parent_runtime(llm=parent_llm)
        self.addCleanup(tmp.cleanup)

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertIs(runtime.llm, parent.llm)
        self.assertEqual(runtime.level, parent.level)

    async def test_forked_runtime_keeps_parent_tool_schema_and_message_view(self) -> None:
        tmp, parent = self._build_parent_runtime(llm=_FakeChatModel())
        self.addCleanup(tmp.cleanup)

        context_snapshot = clone_context_ir_for_fork(parent._context)
        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=context_snapshot,
            allowed_tools={"Read", "Bash"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertEqual(
            [definition.name for definition in runtime.tool_definitions],
            [definition.name for definition in parent.tool_definitions],
        )
        self.assertEqual(
            json.dumps([definition.model_dump() for definition in runtime.tool_definitions], sort_keys=True),
            json.dumps([definition.model_dump() for definition in parent.tool_definitions], sort_keys=True),
        )
        self.assertEqual(
            [message.model_dump(mode="json") for message in runtime.messages],
            [message.model_dump(mode="json") for message in context_snapshot.lower()],
        )
        info = await runtime.get_context_info()
        self.assertEqual(info.total_tokens, parent._context.total_tokens)

    async def test_forked_runtime_inherited_schema_respects_parent_disallowed_tools(self) -> None:
        tmp, parent = self._build_parent_runtime(
            llm=_FakeChatModel(),
            disallowed_tools=("Bash",),
        )
        self.addCleanup(tmp.cleanup)

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read", "Bash"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertEqual([definition.name for definition in runtime.tool_definitions], ["Read", "Write"])

    async def test_forked_runtime_disables_mcp_preload_hooks_and_compaction(self) -> None:
        tmp, parent = self._build_parent_runtime(llm=_FakeChatModel())
        self.addCleanup(tmp.cleanup)

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertIsNone(runtime.start_mcp_preload())
        await runtime.ensure_mcp_tools_loaded()
        self.assertIsNone(await runtime.run_hook_event("SessionStart"))
        self.assertIsNotNone(runtime._compaction_service)
        self.assertFalse(runtime._compaction_service.config.enabled)

    async def test_forked_runtime_query_keeps_mcp_preload_empty_and_never_compacts_large_parent_context(self) -> None:
        tmp, parent = self._build_parent_runtime(
            llm=_FakeChatModel(
                completions=[
                    ChatInvokeCompletion(
                        content="forked-result",
                        usage=ChatInvokeUsage(
                            prompt_tokens=20,
                            prompt_cached_tokens=None,
                            prompt_cache_creation_tokens=None,
                            prompt_image_tokens=None,
                            completion_tokens=6,
                            total_tokens=26,
                        ),
                    )
                ]
            )
        )
        self.addCleanup(tmp.cleanup)
        parent._context.add_message(UserMessage(content="X" * 50_000))

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )
        runtime._context.auto_compact = AsyncMock(side_effect=AssertionError("auto_compact should stay disabled"))  # type: ignore[method-assign]

        result = await runtime.query("child prompt")

        self.assertEqual(result, "forked-result")
        self.assertIsNone(runtime._mcp_preload_task)
        runtime._context.auto_compact.assert_not_called()  # type: ignore[attr-defined]

    async def test_forked_runtime_records_usage_into_parent_token_cost(self) -> None:
        llm = _FakeChatModel(
            completions=[
                ChatInvokeCompletion(
                    content="forked-result",
                    usage=ChatInvokeUsage(
                        prompt_tokens=11,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=5,
                        total_tokens=16,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        await invoke_llm(runtime)
        summary = await parent.token_cost.get_usage_summary(
            source_prefix="forked:memory:run-1"
        )

        self.assertIs(runtime.token_cost, parent.token_cost)
        self.assertEqual(summary.entry_count, 1)
        self.assertEqual(summary.total_tokens, 16)

    async def test_forked_runtime_disables_relevant_memory_prefetch(self) -> None:
        tmp, parent = self._build_parent_runtime(llm=_FakeChatModel())
        self.addCleanup(tmp.cleanup)

        runtime = ForkedAgentRuntime.from_parent(
            parent_runtime=parent,
            context_snapshot=clone_context_ir_for_fork(parent._context),
            allowed_tools={"Read"},
            max_turns=7,
            source_tag="memory",
            run_id="run-1",
        )

        self.assertFalse(getattr(runtime, "_relevant_memory_prefetch_enabled", True))
        self.assertIsNone(
            start_relevant_memory_prefetch(
                runtime,
                "how should we handle database integration tests",
            )
        )
