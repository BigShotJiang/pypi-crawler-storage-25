"""Skill 系统（兼容 Claude Code SKILL.md 格式）"""

from comate_agent_sdk.skill.bundled import (
    BundledSkillDefinition,
    get_builtin_skill_names,
    get_builtin_skills,
)
from comate_agent_sdk.skill.context import apply_skill_context
from comate_agent_sdk.skill.execution import SkillInvocationResult, invoke_skill_by_name
from comate_agent_sdk.skill.loader import discover_skills
from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.skill.prompts import (
    generate_skill_listing,
    generate_skill_usage_guide,
)
from comate_agent_sdk.skill.skill_tool import create_skill_tool

__all__ = [
    "BundledSkillDefinition",
    "SkillDefinition",
    "discover_skills",
    "get_builtin_skills",
    "get_builtin_skill_names",
    "create_skill_tool",
    "apply_skill_context",
    "generate_skill_usage_guide",
    "generate_skill_listing",
    "SkillInvocationResult",
    "invoke_skill_by_name",
]
