"""Skill 定义模型（兼容 Claude Code SKILL.md 格式）"""

import logging
import re
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from comate_agent_sdk.utils.yaml_utils import safe_load_frontmatter

logger = logging.getLogger(__name__)


def model_invocable_skills(skills: list[Any] | tuple[Any, ...] | None) -> list[Any]:
    return [
        skill
        for skill in list(skills or [])
        if not bool(getattr(skill, "disable_model_invocation", False))
    ]


def _parse_bool_frontmatter(value: object, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "yes", "on", "1"}:
            return True
        if normalized in {"false", "no", "off", "0"}:
            return False
    return bool(value)


def _frontmatter_value(
    frontmatter: dict[str, object],
    *keys: str,
) -> object | None:
    for key in keys:
        if key in frontmatter:
            return frontmatter[key]
    return None


def _parse_argument_names(value: object | None) -> tuple[str, ...]:
    if value is None:
        return ()

    if isinstance(value, str):
        raw_names = value.split()
    elif isinstance(value, list):
        raw_names = [item for item in value if isinstance(item, str)]
    else:
        return ()

    return tuple(
        name.strip()
        for name in raw_names
        if name.strip() and not name.strip().isdigit()
    )


def _parse_arguments(args: str) -> list[str]:
    if not args.strip():
        return []
    try:
        return shlex.split(args)
    except ValueError:
        return args.split()


def _substitute_arguments(
    content: str,
    args: str | None,
    *,
    argument_names: tuple[str, ...] = (),
) -> str:
    if args is None:
        return content

    parsed_args = _parse_arguments(args)
    original = content

    for index, name in enumerate(argument_names):
        content = re.sub(
            rf"\${re.escape(name)}(?![\[\w])",
            parsed_args[index] if index < len(parsed_args) else "",
            content,
        )

    content = re.sub(
        r"\$ARGUMENTS\[(\d+)\]",
        lambda match: parsed_args[int(match.group(1))]
        if int(match.group(1)) < len(parsed_args)
        else "",
        content,
    )
    content = re.sub(
        r"\$(\d+)(?!\w)",
        lambda match: parsed_args[int(match.group(1))]
        if int(match.group(1)) < len(parsed_args)
        else "",
        content,
    )
    content = content.replace("$ARGUMENTS", args)

    if content == original and args:
        content = f"{content.rstrip()}\n\nARGUMENTS: {args}"

    return content


def _parse_yaml_frontmatter(
    frontmatter_text: str,
    *,
    used_legacy_opening: bool,
    used_legacy_closing: bool,
    skill_path: str | None = None,
) -> dict[str, object]:
    location = f" (skill: {skill_path})" if skill_path else ""
    if used_legacy_opening:
        logger.warning(
            f"Skill frontmatter is missing opening fence '---'; parsing legacy format{location}"
        )

    if used_legacy_closing:
        logger.warning(
            f"Skill frontmatter uses legacy closing fence '--'; prefer '---'{location}"
        )

    frontmatter = safe_load_frontmatter(frontmatter_text, source=skill_path or "skill frontmatter")
    if not isinstance(frontmatter, dict):
        raise ValueError(f"Skill frontmatter must be a YAML mapping{location}")

    return frontmatter


def _try_split_legacy_frontmatter_without_opening(
    content: str, skill_path: str | None = None
) -> tuple[dict[str, object], str] | None:
    """兼容历史遗留格式：没有 opening fence，但存在 YAML 头和 closing fence。"""
    lines = content.splitlines()
    closing_index: int | None = None
    used_legacy_closing = False

    for index, line in enumerate(lines):
        stripped_line = line.strip()
        if stripped_line == "---":
            closing_index = index
            break
        if stripped_line == "--":
            closing_index = index
            used_legacy_closing = True
            break
        if not stripped_line or ":" not in stripped_line:
            return None

    if closing_index is None or closing_index == 0:
        return None

    frontmatter_text = "\n".join(lines[:closing_index])
    prompt = "\n".join(lines[closing_index + 1 :]).strip()
    frontmatter = _parse_yaml_frontmatter(
        frontmatter_text,
        used_legacy_opening=True,
        used_legacy_closing=used_legacy_closing,
        skill_path=skill_path,
    )
    return frontmatter, prompt


def _split_frontmatter(content: str, skill_path: str | None = None) -> tuple[dict[str, object], str]:
    """分离 Skill frontmatter 和正文。

    兼容两种 closing fence：
    - `---`：标准 YAML frontmatter 结束符
    - `--`：历史遗留写法，保持兼容并记录 warning
    """
    if not content.startswith("---"):
        legacy_split = _try_split_legacy_frontmatter_without_opening(content, skill_path=skill_path)
        if legacy_split is not None:
            return legacy_split
        return {}, content

    lines = content.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, content

    closing_index: int | None = None
    used_legacy_closing = False

    for index, line in enumerate(lines[1:], start=1):
        stripped_line = line.strip()
        if stripped_line == "---":
            closing_index = index
            break
        if stripped_line == "--":
            closing_index = index
            used_legacy_closing = True
            break

    if closing_index is None:
        return {}, content

    frontmatter_text = "\n".join(lines[1:closing_index])
    prompt = "\n".join(lines[closing_index + 1 :]).strip()
    frontmatter = _parse_yaml_frontmatter(
        frontmatter_text,
        used_legacy_opening=False,
        used_legacy_closing=used_legacy_closing,
        skill_path=skill_path,
    )
    return frontmatter, prompt


@dataclass(frozen=True, slots=True)
class SkillDefinition:
    """Skill 定义（兼容 Claude Code SKILL.md 格式）"""

    # 核心字段
    name: str  # 如果 frontmatter 没有 name，使用目录名
    description: str  # 如果 frontmatter 没有 description，使用 prompt 第一段
    prompt: str  # Markdown 正文

    # 可选字段（Frontmatter）
    model: str | None = None  # [已弃用] 该字段已被忽略，请使用 Subagent 代替
    argument_hint: str | None = None  # 暂时保留但不使用
    argument_names: tuple[str, ...] = ()
    when_to_use: str | None = None
    disable_model_invocation: bool = False
    user_invocable: bool = True  # 暂时保留但不使用

    # 资源路径（自动发现）
    base_dir: Path | None = None
    scripts_dir: Path | None = None
    references_dir: Path | None = None
    assets_dir: Path | None = None

    @classmethod
    def from_markdown(
        cls,
        content: str,
        dir_name: str,
        base_dir: Path | None = None,
        namespace: str | None = None,
        use_frontmatter_name: bool = True,
    ) -> "SkillDefinition":
        """从 Markdown 内容解析 Skill

        Args:
            content: SKILL.md 文件内容
            dir_name: Skill 目录名（用作 name 的后备值）
            base_dir: Skill 基础目录路径
            namespace: 命名空间前缀（来自父目录名），拼接为 namespace:short_name
            use_frontmatter_name: 是否允许 frontmatter name 覆盖调用名
        """
        skill_path = str(base_dir) if base_dir else dir_name
        frontmatter, prompt = _split_frontmatter(content, skill_path=skill_path)

        # 提取 name（优先 frontmatter，后备为目录名；有 namespace 时拼接前缀）
        short_name_raw = frontmatter.get("name") if use_frontmatter_name else None
        short_name_raw = short_name_raw or dir_name
        short_name = str(short_name_raw)
        name = f"{namespace}:{short_name}" if namespace else short_name

        # 提取 description（优先 frontmatter，后备为 prompt 第一段）
        description_raw = frontmatter.get("description")
        description = str(description_raw).strip() if description_raw is not None else None
        if not description and prompt:
            # 使用第一段作为 description
            first_paragraph = prompt.split("\n\n")[0].strip()
            description = first_paragraph[:200]  # 限制长度
            # 移除 markdown 标题标记
            if description.startswith("#"):
                description = description.lstrip("#").strip()

        if not description:
            description = f"Skill: {name}"

        model_raw = frontmatter.get("model")
        argument_hint_raw = _frontmatter_value(frontmatter, "argument-hint", "argument_hint")
        when_to_use_raw = _frontmatter_value(frontmatter, "when_to_use", "when-to-use")

        return cls(
            name=name,
            description=description,
            prompt=prompt,
            model=str(model_raw) if model_raw is not None else None,
            argument_hint=str(argument_hint_raw) if argument_hint_raw is not None else None,
            argument_names=_parse_argument_names(frontmatter.get("arguments")),
            when_to_use=str(when_to_use_raw).strip() if when_to_use_raw is not None else None,
            disable_model_invocation=_parse_bool_frontmatter(
                _frontmatter_value(
                    frontmatter,
                    "disable-model-invocation",
                    "disable_model_invocation",
                ),
                default=False,
            ),
            user_invocable=_parse_bool_frontmatter(
                _frontmatter_value(frontmatter, "user-invocable", "user_invocable"),
                default=True,
            ),
            base_dir=base_dir,
        )

    @classmethod
    def from_directory(
        cls,
        skill_dir: Path,
        namespace: str | None = None,
        use_frontmatter_name: bool = True,
    ) -> "SkillDefinition":
        """从目录加载 Skill（支持资源打包）

        目录结构：
        .agent/skills/skillname/
        ├── SKILL.md  (必需)
        ├── scripts/  (可选)
        ├── references/  (可选)
        └── assets/  (可选)
        """
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            raise ValueError(f"No SKILL.md found in {skill_dir}")

        content = skill_md.read_text(encoding="utf-8")
        skill = cls.from_markdown(
            content,
            dir_name=skill_dir.name,
            base_dir=skill_dir,
            namespace=namespace,
            use_frontmatter_name=use_frontmatter_name,
        )

        scripts_dir = skill_dir / "scripts" if (skill_dir / "scripts").exists() else None
        references_dir = skill_dir / "references" if (skill_dir / "references").exists() else None
        assets_dir = skill_dir / "assets" if (skill_dir / "assets").exists() else None

        return cls(
            name=skill.name,
            description=skill.description,
            prompt=skill.prompt,
            model=skill.model,
            argument_hint=skill.argument_hint,
            argument_names=skill.argument_names,
            when_to_use=skill.when_to_use,
            disable_model_invocation=skill.disable_model_invocation,
            user_invocable=skill.user_invocable,
            base_dir=skill.base_dir,
            scripts_dir=scripts_dir,
            references_dir=references_dir,
            assets_dir=assets_dir,
        )

    def get_prompt(
        self,
        *,
        args: str | None = None,
        session_id: str | None = None,
        context: object | None = None,
    ) -> str:
        """获取完整 prompt（替换 Claude Code 兼容变量和参数）。"""
        _ = context
        prompt = self.prompt
        if self.base_dir:
            base_dir = self.base_dir.as_posix()
            prompt = f"Base directory for this skill: {base_dir}\n\n{prompt}"
            prompt = prompt.replace("{baseDir}", base_dir)
            prompt = prompt.replace("${CLAUDE_SKILL_DIR}", base_dir)
        if session_id is not None:
            prompt = prompt.replace("${CLAUDE_SESSION_ID}", session_id)
        prompt = _substitute_arguments(
            prompt,
            args,
            argument_names=self.argument_names,
        )
        return prompt
