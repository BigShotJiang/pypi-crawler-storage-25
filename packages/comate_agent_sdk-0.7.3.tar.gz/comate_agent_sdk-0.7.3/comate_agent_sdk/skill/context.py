"""Skill execution context helpers.

历史上 Skill 支持通过 frontmatter（例如 allowed-tools）修改 Agent 的运行时环境。
该能力已移除：Skill 只负责提供一组可被模型加载的本地指令，不再对工具权限/模型配置产生副作用。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage

if TYPE_CHECKING:
    from comate_agent_sdk.agent.service import Agent
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.skill.models import SkillDefinition

NO_SESSION_MEMORY_AVAILABLE = "No session memory available."


@dataclass(frozen=True, slots=True)
class SkillifyContext:
    """Rendered context inputs for the bundled skillify prompt."""

    session_memory: str
    user_messages: str


def apply_skill_context(agent: "Agent", skill_def: "SkillDefinition") -> None:
    """应用 Skill 的 execution context 修改（已弃用，当前为 no-op）。

    保留该函数仅用于向后兼容外部 import。
    """
    _ = agent
    _ = skill_def
    return


def build_skillify_context(context: "ContextIR") -> SkillifyContext:
    """从当前 ContextIR 只读提取 skillify prompt 输入。"""
    conversation_items = list(context.iter_conversation_items())
    latest_summary_index: int | None = None
    latest_summary = ""

    for index, item in enumerate(conversation_items):
        if item.destroyed or item.item_type != ItemType.COMPACTION_SUMMARY:
            continue
        text = str(item.content_text or "").strip()
        if text:
            latest_summary_index = index
            latest_summary = text

    start_index = 0 if latest_summary_index is None else latest_summary_index + 1
    ordinary_user_messages: list[str] = []
    for item in conversation_items[start_index:]:
        if item.destroyed or item.item_type != ItemType.USER_MESSAGE:
            continue
        message = item.message
        if not isinstance(message, UserMessage):
            continue
        if bool(getattr(message, "is_meta", False)):
            continue
        text = str(message.text or "").strip()
        if not text or _is_command_metadata_message(text):
            continue
        ordinary_user_messages.append(text)

    return SkillifyContext(
        session_memory=latest_summary or NO_SESSION_MEMORY_AVAILABLE,
        user_messages="\n\n".join(ordinary_user_messages),
    )


def _is_command_metadata_message(text: str) -> bool:
    return "<command-message>" in text or "<command-name>" in text
