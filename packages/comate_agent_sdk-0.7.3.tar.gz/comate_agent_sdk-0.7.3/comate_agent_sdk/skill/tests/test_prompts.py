"""skill prompt API 拆分后的测试。"""

from __future__ import annotations

import unittest

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.skill.prompts import (
    LISTING_OPENING_LINE,
    MAX_LISTING_DESC_CHARS,
    generate_skill_listing,
    generate_skill_usage_guide,
)


class TestGenerateSkillUsageGuide(unittest.TestCase):
    def test_usage_guide_contains_skill_use_block(self) -> None:
        guide = generate_skill_usage_guide()
        self.assertIn("<skill_use>", guide)
        self.assertIn("</skill_use>", guide)

    def test_usage_guide_does_not_contain_skills_listing_block(self) -> None:
        guide = generate_skill_usage_guide()
        self.assertNotIn("<skills>", guide)
        self.assertNotIn("</skills>", guide)

    def test_usage_guide_does_not_contain_file_path_marker(self) -> None:
        guide = generate_skill_usage_guide()
        self.assertNotIn("(file:", guide)


class TestGenerateSkillListing(unittest.TestCase):
    def test_listing_uses_claude_code_opening_line(self) -> None:
        listing = generate_skill_listing(
            [SkillDefinition(name="demo", description="d", prompt="p")]
        )
        self.assertEqual(listing.split("\n", 1)[0], LISTING_OPENING_LINE)

    def test_listing_omits_file_path_suffix(self) -> None:
        listing = generate_skill_listing(
            [SkillDefinition(name="demo", description="d", prompt="p")]
        )
        self.assertNotIn("(file:", listing)

    def test_listing_appends_when_to_use_with_dash(self) -> None:
        listing = generate_skill_listing(
            [
                SkillDefinition(
                    name="commit",
                    description="Create commits.",
                    prompt="p",
                    when_to_use="When the user asks to prepare a commit.",
                )
            ]
        )
        self.assertIn(
            "- commit: Create commits. - When the user asks to prepare a commit.",
            listing,
        )

    def test_listing_no_when_to_use_only_description(self) -> None:
        listing = generate_skill_listing(
            [SkillDefinition(name="bare", description="Just description.", prompt="p")]
        )
        line = next(line for line in listing.splitlines() if line.startswith("- bare:"))
        self.assertEqual(line, "- bare: Just description.")

    def test_listing_filters_disable_model_invocation(self) -> None:
        listing = generate_skill_listing(
            [
                SkillDefinition(name="visible", description="d1", prompt="p"),
                SkillDefinition(
                    name="hidden",
                    description="d2",
                    prompt="p",
                    disable_model_invocation=True,
                ),
            ]
        )
        self.assertIn("- visible:", listing)
        self.assertNotIn("- hidden:", listing)

    def test_listing_filters_builtin_skillify(self) -> None:
        from comate_agent_sdk.skill.bundled import get_builtin_skills

        listing = generate_skill_listing(
            [
                *get_builtin_skills(),
                SkillDefinition(name="visible", description="d1", prompt="p"),
            ]
        )

        self.assertIn("- visible:", listing)
        self.assertNotIn("- skillify:", listing)

    def test_listing_respects_max_chars(self) -> None:
        long_desc = "X" * (MAX_LISTING_DESC_CHARS + 50)
        listing = generate_skill_listing(
            [SkillDefinition(name="long", description=long_desc, prompt="p")]
        )
        line = next(line for line in listing.splitlines() if line.startswith("- long:"))
        desc_part = line.split(": ", 1)[1]
        self.assertEqual(len(desc_part), MAX_LISTING_DESC_CHARS)
        self.assertTrue(desc_part.endswith("..."))

    def test_listing_returns_empty_string_when_no_active_skills(self) -> None:
        listing = generate_skill_listing(
            [
                SkillDefinition(
                    name="hidden",
                    description="d",
                    prompt="p",
                    disable_model_invocation=True,
                )
            ]
        )
        self.assertEqual(listing, "")

    def test_listing_returns_empty_string_when_skills_empty(self) -> None:
        self.assertEqual(generate_skill_listing([]), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
