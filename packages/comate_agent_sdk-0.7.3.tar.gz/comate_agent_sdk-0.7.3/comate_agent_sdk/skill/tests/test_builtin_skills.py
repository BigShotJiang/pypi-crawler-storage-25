from __future__ import annotations

import asyncio

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.skill.bundled import get_builtin_skill_names, get_builtin_skills
from comate_agent_sdk.skill.execution import invoke_skill_by_name


def _skillify():
    return next(skill for skill in get_builtin_skills() if skill.name == "skillify")


def test_builtin_registry_exposes_user_only_skillify() -> None:
    skill = _skillify()

    assert get_builtin_skill_names() == {"skillify"}
    assert skill.name == "skillify"
    assert skill.description
    assert skill.argument_hint is not None
    assert skill.when_to_use
    assert skill.user_invocable is True
    assert skill.disable_model_invocation is True


def test_builtin_skillify_renders_runtime_context_and_user_description() -> None:
    ctx = ContextIR()
    ctx.conversation.items.append(
        ContextItem(
            item_type=ItemType.COMPACTION_SUMMARY,
            message=UserMessage(content="compact memory"),
            content_text="compact memory",
        )
    )
    ctx.add_message(UserMessage(content="make a skill from this workflow"))

    prompt = _skillify().get_prompt(
        args="create a release helper",
        session_id="session-123",
        context=ctx,
    )

    assert "create a release helper" in prompt
    assert "compact memory" in prompt
    assert "make a skill from this workflow" in prompt
    assert ".agent/skills/<skill-name>/SKILL.md" in prompt
    assert "~/.agent/skills/<skill-name>/SKILL.md" in prompt
    assert "AskUserQuestion" in prompt
    assert "Do not generate `allowed-tools`" in prompt
    assert "\nallowed-tools:" not in prompt
    assert "\ncontext:" not in prompt


def test_static_disk_skill_get_prompt_still_ignores_runtime_context() -> None:
    from comate_agent_sdk.skill.models import SkillDefinition

    ctx = ContextIR()
    ctx.add_message(UserMessage(content="runtime text"))
    skill = SkillDefinition(name="demo", description="demo", prompt="Run.")

    assert skill.get_prompt(context=ctx) == "Run."


def test_user_slash_invokes_runtime_aware_builtin_skillify() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._session_id = "session-123"
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = list(get_builtin_skills())

    agent = FakeAgent()
    agent._context.add_message(UserMessage(content="turn before skillify"))

    result = asyncio.run(
        invoke_skill_by_name(
            agent,  # type: ignore[arg-type]
            "/skillify",
            args="create a debugging skill",
            invocation_source="user_slash",
        )
    )

    skill_items = [
        item
        for item in agent._context.conversation.items
        if item.item_type == ItemType.SKILL_PROMPT
    ]

    assert result.success
    assert len(skill_items) == 1
    assert skill_items[0].message is not None
    assert "create a debugging skill" in skill_items[0].message.text
    assert "turn before skillify" in skill_items[0].message.text
