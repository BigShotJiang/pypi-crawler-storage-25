from __future__ import annotations

import asyncio
import json
from pathlib import Path

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.skill.execution import execute_skill_call
from comate_agent_sdk.skill.execution import invoke_skill_by_name
from comate_agent_sdk.skill.execution import rebuild_skill_tool
from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.llm.messages import Function, ToolCall


def test_rebuild_skill_tool_skips_strategy_when_skill_is_disallowed() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="demo", description="d", prompt="p")
            ]
            self._runtime_state.tools = []
            self._tool_map = {}
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": ("Skill",)})()

    agent = FakeAgent()
    rebuild_skill_tool(agent)  # type: ignore[arg-type]

    assert [tool.name for tool in agent._runtime_state.tools] == ["Skill"]
    assert agent._context.header.find_one_by_type(ItemType.SKILL_STRATEGY) is None
    assert agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_rebuild_skill_tool_refreshes_both_strategy_and_listing() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="demo", description="d", prompt="p")
            ]
            self._runtime_state.tools = []
            self._tool_map = {}
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": ()})()

    agent = FakeAgent()
    rebuild_skill_tool(agent)  # type: ignore[arg-type]

    strategy_item = agent._context.header.find_one_by_type(ItemType.SKILL_STRATEGY)
    assert strategy_item is not None
    assert "<skill_use>" in (strategy_item.content_text or "")
    assert "<skills>" not in (strategy_item.content_text or "")

    listing_item = agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING)
    assert listing_item is not None
    assert "The following skills are available for use with the Skill tool:" in (
        listing_item.content_text or ""
    )
    assert "- demo: d" in (listing_item.content_text or "")


def test_rebuild_skill_tool_removes_listing_when_no_skills_left() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._context.set_skill_strategy("<skill_use>old</skill_use>")
            self._context.set_skill_listing("old listing")
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = []
            self._runtime_state.tools = []
            self._tool_map = {}
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": ()})()

    agent = FakeAgent()
    rebuild_skill_tool(agent)  # type: ignore[arg-type]

    assert agent._context.header.find_one_by_type(ItemType.SKILL_STRATEGY) is None
    assert agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_rebuild_skill_tool_does_not_create_tool_for_user_only_skills() -> None:
    from comate_agent_sdk.skill.bundled import get_builtin_skills

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = list(get_builtin_skills())
            self._runtime_state.tools = []
            self._tool_map = {}
            self._is_subagent = False
            self.is_team_member = False
            self.config = type("C", (), {"disallowed_tools": ()})()

    agent = FakeAgent()
    rebuild_skill_tool(agent)  # type: ignore[arg-type]

    assert [tool.name for tool in agent._runtime_state.tools] == []
    assert "Skill" not in agent._tool_map
    assert agent._context.header.find_one_by_type(ItemType.SKILL_STRATEGY) is None
    assert agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_execute_skill_call_accepts_claude_skill_and_args_fields() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._session_id = "session-123"
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(
                    name="demo",
                    description="d",
                    prompt="Use $target in ${CLAUDE_SESSION_ID} from ${CLAUDE_SKILL_DIR}.",
                    argument_names=("target",),
                    base_dir=Path("/tmp/demo"),
                )
            ]

    agent = FakeAgent()
    tool_call = ToolCall(
        id="tc_skill",
        function=Function(
            name="Skill",
            arguments=json.dumps({"skill": "/demo", "args": "README.md"}),
        ),
    )

    result = asyncio.run(execute_skill_call(agent, tool_call))  # type: ignore[arg-type]
    agent._context.flush_pending_skill_items()

    skill_items = [
        item
        for item in agent._context.conversation.items
        if item.item_type == ItemType.SKILL_PROMPT
    ]

    assert not result.is_error
    assert len(skill_items) == 1
    assert skill_items[0].message is not None
    assert (
        skill_items[0].message.text
        == "Base directory for this skill: /tmp/demo\n\n"
        "Use README.md in session-123 from /tmp/demo."
    )


def test_execute_skill_call_keeps_legacy_skill_name_field() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._session_id = "session-123"
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="legacy", description="d", prompt="Legacy.")
            ]

    agent = FakeAgent()
    tool_call = ToolCall(
        id="tc_skill",
        function=Function(
            name="Skill",
            arguments=json.dumps({"skill_name": "legacy"}),
        ),
    )

    result = asyncio.run(execute_skill_call(agent, tool_call))  # type: ignore[arg-type]

    assert not result.is_error


def test_invoke_skill_by_name_user_slash_flushes_skill_prompt() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._session_id = "session-123"
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(
                    name="demo",
                    description="d",
                    prompt="Use $target.",
                    argument_names=("target",),
                )
            ]

    agent = FakeAgent()

    result = asyncio.run(
        invoke_skill_by_name(
            agent,  # type: ignore[arg-type]
            "/demo",
            args="README.md",
            invocation_source="user_slash",
            flush=True,
        )
    )

    skill_items = [
        item
        for item in agent._context.conversation.items
        if item.item_type == ItemType.SKILL_PROMPT
    ]
    assert result.success
    assert len(skill_items) == 1
    assert skill_items[0].message is not None
    assert skill_items[0].message.text == "Use README.md."


def test_invoke_skill_by_name_flush_false_keeps_pending_until_barrier_flush() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(name="demo", description="d", prompt="Prompt.")
            ]

    agent = FakeAgent()

    result = asyncio.run(
        invoke_skill_by_name(
            agent,  # type: ignore[arg-type]
            "demo",
            invocation_source="model_tool",
            flush=False,
        )
    )

    assert result.success
    assert not [
        item
        for item in agent._context.conversation.items
        if item.item_type == ItemType.SKILL_PROMPT
    ]

    agent._context.flush_pending_skill_items()
    assert [
        item
        for item in agent._context.conversation.items
        if item.item_type == ItemType.SKILL_PROMPT
    ]


def test_user_slash_rejects_non_user_invocable_skill() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(
                    name="hidden",
                    description="d",
                    prompt="Prompt.",
                    user_invocable=False,
                )
            ]

    result = asyncio.run(
        invoke_skill_by_name(
            FakeAgent(),  # type: ignore[arg-type]
            "hidden",
            invocation_source="user_slash",
        )
    )

    assert not result.success
    assert "not user-invocable" in result.message


def test_disable_model_invocation_allows_user_slash_but_rejects_model_tool() -> None:
    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.skills = [
                SkillDefinition(
                    name="user-only",
                    description="d",
                    prompt="Prompt.",
                    disable_model_invocation=True,
                )
            ]

    agent = FakeAgent()
    user_result = asyncio.run(
        invoke_skill_by_name(
            agent,  # type: ignore[arg-type]
            "user-only",
            invocation_source="user_slash",
        )
    )
    assert user_result.success

    tool_call = ToolCall(
        id="tc_skill",
        function=Function(
            name="Skill",
            arguments=json.dumps({"skill": "user-only"}),
        ),
    )
    model_result = asyncio.run(execute_skill_call(agent, tool_call))  # type: ignore[arg-type]

    assert model_result.is_error
    assert "disabled for model invocation" in model_result.content
