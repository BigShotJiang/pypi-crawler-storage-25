from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage, UserMessage
from comate_agent_sdk.skill.context import (
    NO_SESSION_MEMORY_AVAILABLE,
    build_skillify_context,
)


def _summary(text: str) -> ContextItem:
    return ContextItem(
        item_type=ItemType.COMPACTION_SUMMARY,
        message=UserMessage(content=text),
        content_text=text,
    )


def test_skillify_context_returns_latest_compaction_summary() -> None:
    ctx = ContextIR()
    ctx.conversation.items.append(_summary("old summary"))
    ctx.add_message(UserMessage(content="after old summary"))
    ctx.conversation.items.append(_summary("latest summary"))

    result = build_skillify_context(ctx)

    assert result.session_memory == "latest summary"


def test_skillify_context_uses_fallback_when_no_summary_exists() -> None:
    ctx = ContextIR()
    ctx.add_message(UserMessage(content="ordinary request"))

    result = build_skillify_context(ctx)

    assert result.session_memory == NO_SESSION_MEMORY_AVAILABLE


def test_skillify_context_extracts_only_ordinary_user_messages_after_latest_compact_boundary() -> None:
    ctx = ContextIR()
    ctx.add_message(UserMessage(content="before compact"))
    ctx.conversation.items.append(_summary("memory"))
    ctx.add_message(UserMessage(content="first ordinary request"))
    ctx.add_message(UserMessage(content="<command-message>demo</command-message>"))
    ctx.add_message(UserMessage(content="<command-name>/demo</command-name>"))
    ctx.add_message(UserMessage(content="<system-reminder>\ninternal\n</system-reminder>", is_meta=True))
    ctx.add_message(UserMessage(content="skill prompt", is_meta=True), item_type=ItemType.SKILL_PROMPT)
    ctx.add_message(
        UserMessage(content="<system-reminder>\ninternal\n</system-reminder>", is_meta=True),
        item_type=ItemType.SYSTEM_REMINDER,
    )
    ctx.add_message(AssistantMessage(content="assistant reply"))
    ctx.add_message(
        ToolMessage(tool_call_id="tc1", tool_name="Read", content="tool output"),
        item_type=ItemType.TOOL_RESULT,
    )
    ctx.add_message(UserMessage(content="second ordinary request"))

    result = build_skillify_context(ctx)

    assert result.user_messages == "first ordinary request\n\nsecond ordinary request"


def test_skillify_context_does_not_mutate_context_ir() -> None:
    ctx = ContextIR()
    ctx.conversation.items.append(_summary("memory"))
    ctx.add_message(UserMessage(content="ordinary request"))
    before_ids = [item.id for item in ctx.conversation.items]
    before_turn = ctx.turn_number

    build_skillify_context(ctx)

    assert [item.id for item in ctx.conversation.items] == before_ids
    assert ctx.turn_number == before_turn


def test_skillify_context_clear_history_fallback_after_context_clear() -> None:
    ctx = ContextIR()
    ctx.conversation.items.append(_summary("memory"))
    ctx.clear()

    result = build_skillify_context(ctx)

    assert result.session_memory == NO_SESSION_MEMORY_AVAILABLE
    assert result.user_messages == ""
