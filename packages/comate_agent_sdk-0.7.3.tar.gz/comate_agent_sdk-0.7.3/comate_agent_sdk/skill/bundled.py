from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable

from comate_agent_sdk.prompts import load_prompt, render_prompt
from comate_agent_sdk.skill.context import (
    NO_SESSION_MEMORY_AVAILABLE,
    SkillifyContext,
    build_skillify_context,
)

if TYPE_CHECKING:
    from comate_agent_sdk.context.ir import ContextIR

_SKILLIFY_PROMPT_ID = "skill/skillify.md"
_DEFAULT_PROJECT_SKILL_PATH = ".agent/skills/<skill-name>/SKILL.md"
_PERSONAL_SKILL_PATH = "~/.agent/skills/<skill-name>/SKILL.md"


PromptRenderer = Callable[[str | None, str | None, "ContextIR | None"], str]


@dataclass(frozen=True, slots=True)
class BundledSkillDefinition:
    """SDK-bundled skill definition with the same public shape as disk skills."""

    name: str
    description: str
    prompt_id: str
    argument_hint: str | None = None
    argument_names: tuple[str, ...] = ()
    when_to_use: str | None = None
    disable_model_invocation: bool = False
    user_invocable: bool = True
    _renderer: PromptRenderer | None = None

    def get_prompt(
        self,
        *,
        args: str | None = None,
        session_id: str | None = None,
        context: "ContextIR | None" = None,
    ) -> str:
        if self._renderer is not None:
            return self._renderer(args, session_id, context)
        _ = session_id
        _ = context
        return render_prompt(
            load_prompt(self.prompt_id),
            variables={"ARGUMENTS": args or ""},
            source=self.prompt_id,
        )


def _render_skillify_prompt(
    args: str | None,
    session_id: str | None,
    context: "ContextIR | None",
) -> str:
    _ = session_id
    skillify_context = (
        build_skillify_context(context)
        if context is not None
        else SkillifyContext(
            session_memory=NO_SESSION_MEMORY_AVAILABLE,
            user_messages="",
        )
    )
    user_description = str(args or "").strip()
    if user_description:
        user_description_block = (
            f'The user described this process as: "{user_description}"'
        )
    else:
        user_description_block = "No initial process description was provided by the user."

    return render_prompt(
        load_prompt(_SKILLIFY_PROMPT_ID),
        variables={
            "USER_DESCRIPTION_BLOCK": user_description_block,
            "SESSION_MEMORY": skillify_context.session_memory,
            "USER_MESSAGES": skillify_context.user_messages,
            "DEFAULT_PROJECT_SKILL_PATH": _DEFAULT_PROJECT_SKILL_PATH,
            "PERSONAL_SKILL_PATH": _PERSONAL_SKILL_PATH,
        },
        source=_SKILLIFY_PROMPT_ID,
    )


_BUILTIN_SKILLS: tuple[BundledSkillDefinition, ...] = (
    BundledSkillDefinition(
        name="skillify",
        description=(
            "Capture this session's repeatable process into a skill. "
            "Call at the end of the process you want to capture with an optional description."
        ),
        prompt_id=_SKILLIFY_PROMPT_ID,
        argument_hint="[description of the process you want to capture]",
        when_to_use=(
            "Use when the user wants to turn the current session's repeatable process "
            "into a reusable skill."
        ),
        disable_model_invocation=True,
        user_invocable=True,
        _renderer=_render_skillify_prompt,
    ),
)


def get_builtin_skills() -> tuple[BundledSkillDefinition, ...]:
    return tuple(_BUILTIN_SKILLS)


def get_builtin_skill_names() -> set[str]:
    return {skill.name for skill in _BUILTIN_SKILLS}
