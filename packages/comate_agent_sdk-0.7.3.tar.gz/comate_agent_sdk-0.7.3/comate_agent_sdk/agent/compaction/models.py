"""
Models for the compaction subservice.
"""

from __future__ import annotations

from dataclasses import dataclass, field


DEFAULT_THRESHOLD_RATIO = 0.85


@dataclass
class CompactionConfig:
    """Configuration for the compaction service.

    Attributes:
            enabled: Whether compaction is enabled. Defaults to True.
            threshold_ratio: Ratio of context window at which compaction triggers.
            threshold_tokens: Optional absolute token threshold for compaction.
            model: Optional model to use for generating summaries.
            summary_system_prompt: Optional custom system prompt override.
            summary_prompt: Optional custom user prompt override.
    """

    enabled: bool = True
    threshold_ratio: float = DEFAULT_THRESHOLD_RATIO
    threshold_tokens: int | None = None
    model: str | None = None
    summary_system_prompt: str | None = None
    summary_prompt: str | None = None


@dataclass
class CompactionResult:
    """Result of a compaction operation."""

    compacted: bool
    original_tokens: int = 0
    new_tokens: int = 0
    summary: str | None = None
    failure_reason: str | None = None
    failure_detail: str | None = None
    stop_reason: str | None = None
    raw_content_length: int = 0


@dataclass
class ManualCompactionResult:
    """Result of a user-triggered/manual compaction operation."""

    attempted: bool
    compacted: bool
    cancelled: bool = False
    tokens_before: int = 0
    tokens_after: int = 0
    reason: str = ""
    meta_records: list[dict[str, object]] = field(default_factory=list)
