from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING, Callable

from comate_agent_sdk.agent.memory_store import format_memory_manifest, scan_memory_headers
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.forked.api import run_forked_agent
from comate_agent_sdk.prompts import load_prompt, render_prompt

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger("comate_agent_sdk.agent.memory")

_EXTRACTION_ALLOWED_TOOLS = {"Read", "Grep", "Glob", "Bash", "Write", "Edit"}
_WRITE_TOOL_NAMES = {"Write", "Edit"}


@dataclass(slots=True)
class MemoryExtractionRequest:
    cursor_id: str | None
    last_item_id: str
    new_message_count: int
    conversation_slice: str
    existing_memories: str


@dataclass(slots=True)
class MemoryExtractionState:
    last_cursor_message_id: str | None = None
    active_task: asyncio.Task[None] | None = field(default=None, repr=False)
    active_request: MemoryExtractionRequest | None = None
    pending_request: MemoryExtractionRequest | None = None


def start_background_memory_extraction(agent: "AgentRuntime") -> None:
    if not _should_run_background_extraction(agent):
        return

    state = _ensure_memory_extraction_state(agent)
    active_task = state.active_task
    if active_task is not None and not active_task.done():
        cursor_id = (
            state.active_request.last_item_id
            if state.active_request is not None
            else state.last_cursor_message_id
        )
        request = _build_extraction_request(agent, cursor_id=cursor_id)
        if request is not None:
            state.pending_request = request
        return

    request = _build_extraction_request(agent, cursor_id=state.last_cursor_message_id)
    if request is None:
        return

    if _has_successful_memory_write_since(agent, cursor_id=state.last_cursor_message_id):
        state.last_cursor_message_id = request.last_item_id
        state.pending_request = None
        return

    _launch_extraction(agent, state, request)


def build_memory_extraction_tool_validator(
    memory_dir: Path,
) -> Callable[[str, dict[str, object]], str | None]:
    memory_root = Path(memory_dir).expanduser().resolve()

    def _validator(tool_name: str, tool_input: dict[str, object]) -> str | None:
        if tool_name not in _WRITE_TOOL_NAMES:
            return None

        raw_path = str(tool_input.get("file_path") or "").strip()
        if _is_allowed_memory_topic_path(raw_path, memory_root):
            return None

        return (
            "Memory extraction may only write topic files inside the memory directory: "
            f"{memory_root.as_posix()}"
        )

    return _validator


def render_memory_extraction_prompt(
    *,
    memory_dir: Path,
    new_message_count: int,
    conversation_slice: str,
    existing_memories: str,
) -> str:
    del conversation_slice
    return render_prompt(
        load_prompt("memory/extract.md"),
        variables={
            "MEMORY_DIR_PATH": _normalize_memory_dir_for_prompt(memory_dir),
            "NEW_MESSAGE_COUNT": str(max(0, int(new_message_count))),
            "EXISTING_MEMORIES": str(existing_memories or "").strip() or "(none)",
        },
        source="memory/extract.md",
    )


def _ensure_memory_extraction_state(agent: "AgentRuntime") -> MemoryExtractionState:
    state = getattr(agent, "_memory_extraction_state", None)
    if isinstance(state, MemoryExtractionState):
        return state

    state = MemoryExtractionState()
    agent._memory_extraction_state = state
    return state


def _should_run_background_extraction(agent: "AgentRuntime") -> bool:
    if bool(getattr(agent, "_is_subagent", False)):
        return False
    if not bool(getattr(agent, "_memory_extraction_enabled", True)):
        return False
    if agent.llm is None:
        return False

    try:
        memory_dir = resolve_auto_memory_dir(agent)
    except Exception as exc:
        logger.warning(f"无法解析 memory 目录，跳过 background extraction: {exc}")
        return False
    return memory_dir.exists()


def _launch_extraction(
    agent: "AgentRuntime",
    state: MemoryExtractionState,
    request: MemoryExtractionRequest,
) -> None:
    async def _runner() -> None:
        advance_cursor = False
        try:
            advance_cursor = await _run_extraction_request(agent, request)
        except Exception as exc:  # pragma: no cover - defensive path
            logger.warning(f"Background memory extraction failed: {exc}", exc_info=True)
        finally:
            if advance_cursor:
                state.last_cursor_message_id = request.last_item_id

            state.active_request = None
            state.active_task = None

            pending = state.pending_request
            state.pending_request = None
            if pending is not None:
                _launch_extraction(agent, state, pending)

    state.active_request = request
    state.active_task = asyncio.create_task(_runner())


async def _run_extraction_request(
    agent: "AgentRuntime",
    request: MemoryExtractionRequest,
) -> bool:
    if not request.conversation_slice.strip():
        return False

    memory_dir = resolve_auto_memory_dir(agent)
    prompt = render_memory_extraction_prompt(
        memory_dir=memory_dir,
        new_message_count=request.new_message_count,
        conversation_slice=request.conversation_slice,
        existing_memories=request.existing_memories,
    )
    validator = build_memory_extraction_tool_validator(memory_dir)

    await run_forked_agent(
        parent_runtime=agent,
        prompt=prompt,
        allowed_tools=_EXTRACTION_ALLOWED_TOOLS,
        tool_use_validator=validator,
        max_turns=5,
        source_tag="memory_extraction",
    )
    logger.info(
        "Background memory extraction completed for %s new message(s)",
        request.new_message_count,
    )
    return True


def _build_extraction_request(
    agent: "AgentRuntime",
    *,
    cursor_id: str | None,
) -> MemoryExtractionRequest | None:
    items = _items_since_cursor(agent, cursor_id=cursor_id)
    if not items:
        return None

    memory_dir = resolve_auto_memory_dir(agent)
    existing_memories = format_memory_manifest(scan_memory_headers(memory_dir))
    return MemoryExtractionRequest(
        cursor_id=cursor_id,
        last_item_id=items[-1].id,
        new_message_count=_count_new_messages(items),
        conversation_slice=_render_conversation_slice(items),
        existing_memories=existing_memories,
    )


def _items_since_cursor(
    agent: "AgentRuntime",
    *,
    cursor_id: str | None,
) -> list[ContextItem]:
    items = [item for item in agent._context.iter_conversation_items() if not item.destroyed]
    if cursor_id is None:
        return items

    found_cursor = False
    collected: list[ContextItem] = []
    for item in items:
        if not found_cursor:
            if item.id == cursor_id:
                found_cursor = True
            continue
        collected.append(item)

    if found_cursor:
        return collected

    logger.info("Memory extraction cursor missing after conversation mutation, fallback to current conversation snapshot")
    return items


def _has_successful_memory_write_since(
    agent: "AgentRuntime",
    *,
    cursor_id: str | None,
) -> bool:
    items = _items_since_cursor(agent, cursor_id=cursor_id)
    if not items:
        return False

    successful_tool_results = {
        str(item.message.tool_call_id)
        for item in items
        if item.item_type == ItemType.TOOL_RESULT
        and item.message is not None
        and not bool(getattr(item.message, "is_error", False))
        and str(getattr(item.message, "tool_name", "") or "") in _WRITE_TOOL_NAMES
    }
    if not successful_tool_results:
        return False

    memory_dir = resolve_auto_memory_dir(agent)
    for item in items:
        if item.item_type != ItemType.ASSISTANT_MESSAGE or item.message is None:
            continue
        tool_calls = getattr(item.message, "tool_calls", None) or []
        for tool_call in tool_calls:
            if tool_call.id not in successful_tool_results:
                continue
            if str(tool_call.function.name or "") not in _WRITE_TOOL_NAMES:
                continue
            try:
                args = json.loads(tool_call.function.arguments or "{}")
            except Exception:
                continue
            if not isinstance(args, dict):
                continue
            if _is_auto_memory_path(str(args.get("file_path") or ""), memory_dir):
                return True
    return False


def _count_new_messages(items: list[ContextItem]) -> int:
    return sum(
        1
        for item in items
        if item.item_type in {
            ItemType.USER_MESSAGE,
            ItemType.TEAM_INBOX_TURN,
            ItemType.ASSISTANT_MESSAGE,
        }
    )


def _render_conversation_slice(items: list[ContextItem]) -> str:
    sections: list[str] = []
    for item in items:
        if item.item_type in {ItemType.SYSTEM_REMINDER, ItemType.SKILL_PROMPT}:
            continue

        text = str(item.content_text or "").strip()
        if not text:
            continue

        label = _conversation_label(item)
        sections.append(f"{label}\n{text}")
    return "\n\n".join(sections).strip()


def _conversation_label(item: ContextItem) -> str:
    if item.item_type == ItemType.USER_MESSAGE:
        return "USER:"
    if item.item_type == ItemType.TEAM_INBOX_TURN:
        return "TEAM_INBOX:"
    if item.item_type == ItemType.ASSISTANT_MESSAGE:
        return "ASSISTANT:"
    if item.item_type == ItemType.TOOL_RESULT:
        tool_name = str(item.tool_name or getattr(item.message, "tool_name", "") or "tool")
        if item.is_tool_error:
            return f"TOOL_RESULT_ERROR[{tool_name}]:"
        return f"TOOL_RESULT[{tool_name}]:"
    if item.item_type == ItemType.COMPACTION_SUMMARY:
        return "COMPACTION_SUMMARY:"
    return f"{item.item_type.value.upper()}:"


def _normalize_memory_dir_for_prompt(memory_dir: Path) -> str:
    normalized = memory_dir.expanduser().resolve().as_posix()
    if not normalized.endswith("/"):
        normalized = f"{normalized}/"
    return normalized


def _is_allowed_memory_topic_path(user_path: str, memory_root: Path) -> bool:
    raw = str(user_path or "").strip()
    if not raw:
        return False

    memory_root = Path(memory_root).expanduser().resolve()
    candidate = Path(raw).expanduser()
    if candidate.is_absolute():
        resolved = candidate.resolve()
        if not _path_is_relative_to(resolved, memory_root):
            return False
        return resolved != memory_root and _is_topic_memory_filename(resolved)

    parts = [part for part in PurePosixPath(raw).parts if part not in ("", ".")]
    if any(part == ".." for part in parts):
        return False
    if len(parts) < 2:
        return False
    if parts[0].lower() != "memory":
        return False

    return _is_topic_memory_filename(Path(*parts[1:]))


def _is_auto_memory_path(user_path: str, memory_root: Path) -> bool:
    raw = str(user_path or "").strip()
    if not raw:
        return False

    memory_root = Path(memory_root).expanduser().resolve()
    candidate = Path(raw).expanduser()
    if candidate.is_absolute():
        return _path_is_relative_to(candidate.resolve(), memory_root)

    parts = [part for part in PurePosixPath(raw).parts if part not in ("", ".")]
    if not parts or any(part == ".." for part in parts):
        return False

    if len(parts) == 1 and parts[0].lower() == "memory.md":
        return True
    return parts[0].lower() == "memory" and len(parts) > 1


def _is_topic_memory_filename(path: Path) -> bool:
    return path.suffix.lower() == ".md" and path.name.lower() != "memory.md"


def _path_is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False
