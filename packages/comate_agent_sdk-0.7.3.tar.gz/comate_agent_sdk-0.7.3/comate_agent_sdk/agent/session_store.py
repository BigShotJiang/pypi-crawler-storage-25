"""Session persistence: serialization, delta events, and JSONL replay.

Extracted from chat_session.py to keep ChatSession focused on orchestration.
"""

from __future__ import annotations

import json
import logging
import platform
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from comate_agent_sdk.context.file_track import FileTrackState
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    BaseMessage,
    DeveloperMessage,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from comate_agent_sdk.tokens.views import TokenUsageEntry
from comate_agent_sdk.utils.paths import PathInput, PathInputError, normalize_path_input

logger = logging.getLogger("comate_agent_sdk.agent.session_store")

PERSISTENCE_SCHEMA_VERSION = "3.0"
SESSION_METADATA_FILENAME = "session.json"
EXTERNAL_TURNS_JOURNAL_FILENAME = "external_turns.jsonl"


class SessionStoreError(Exception):
    pass


def normalize_cwd(cwd: PathInput | None) -> Path:
    """规范化 cwd（agent 运行项目目录），缺失或非法时快速失败。"""
    if cwd is None:
        raise SessionStoreError("cwd is required to resolve session root")
    try:
        return normalize_path_input(cwd, field_name="cwd")
    except PathInputError as exc:
        raise SessionStoreError(str(exc)) from exc


def cwd_to_path_key(cwd: Path) -> str:
    """将 cwd 路径转为安全的目录名 key。

    规则：resolve() 后用 as_posix() 统一分隔符，
    将 / 替换为 -，Windows 下额外处理 : 和大小写。

    示例：/home/hyc/projects/agent-sdk → -home-hyc-projects-agent-sdk
    """
    resolved = normalize_cwd(cwd)
    path_str = resolved.as_posix()          # 统一用 / 分隔符
    if platform.system() == "Windows":
        path_str = path_str.lower()         # Windows 不区分大小写
        path_str = path_str.replace(":", "")  # 去掉盘符冒号 C:/foo → c/foo
    return path_str.replace("/", "-")       # / → -


def default_sessions_dir(cwd: Path) -> Path:
    """返回指定 cwd 下的 sessions 存储目录。"""
    key = cwd_to_path_key(normalize_cwd(cwd))
    return Path.home() / ".agent" / "sessions" / key


def default_session_root(session_id: str, *, cwd: Path) -> Path:
    return default_sessions_dir(cwd) / session_id


def session_metadata_path(session_root: Path) -> Path:
    return session_root / SESSION_METADATA_FILENAME


def external_turns_journal_path(session_root: Path) -> Path:
    return session_root / EXTERNAL_TURNS_JOURNAL_FILENAME


def build_session_metadata(
    *,
    session_id: str,
    task_namespace: str,
    team_name: str = "",
    cwd: str = "",
) -> dict[str, str]:
    payload = {
        "session_id": str(session_id).strip(),
        "task_namespace": str(task_namespace).strip(),
    }
    normalized_team_name = str(team_name).strip()
    if normalized_team_name:
        payload["team_name"] = normalized_team_name
    normalized_cwd = str(cwd).strip()
    if normalized_cwd:
        payload["cwd"] = normalized_cwd
    return payload


def load_session_metadata(session_root: Path) -> dict[str, str] | None:
    path = session_metadata_path(session_root)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    session_id = str(data.get("session_id", "")).strip()
    task_namespace = str(data.get("task_namespace", "")).strip()
    if not session_id or not task_namespace:
        return None
    payload = {
        "session_id": session_id,
        "task_namespace": task_namespace,
    }
    team_name = str(data.get("team_name", "")).strip()
    if team_name:
        payload["team_name"] = team_name
    cwd_val = str(data.get("cwd", "")).strip()
    if cwd_val:
        payload["cwd"] = cwd_val
    return payload


def write_session_metadata(
    session_root: Path,
    *,
    session_id: str,
    task_namespace: str,
    team_name: str = "",
    cwd: str = "",
) -> None:
    session_root.mkdir(parents=True, exist_ok=True)
    path = session_metadata_path(session_root)
    payload = build_session_metadata(
        session_id=session_id,
        task_namespace=task_namespace,
        team_name=team_name,
        cwd=cwd,
    )
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def resolve_session_root(
    *,
    session_id: str,
    cwd: Path,
) -> Path:
    """统一解析当前 session_root（仅 cwd 语义）。"""
    return default_session_root(session_id, cwd=cwd)


def _as_relative_path(path_str: str, *, base: Path) -> str:
    try:
        p = Path(path_str)
    except Exception:
        return path_str

    if not p.is_absolute():
        return path_str

    try:
        return str(p.relative_to(base))
    except Exception:
        return path_str


def serialize_message_for_persistence(
    message: BaseMessage,
    *,
    offload_root: Path,
    item_offload_path: str | None,
) -> dict:
    data = message.model_dump(mode="json")

    # ToolMessage: 避免将大输出写进 jsonl；同时把 offload_path 规范为相对路径，支持 fork/迁移
    if isinstance(message, ToolMessage):
        if data.get("offload_path"):
            data["offload_path"] = _as_relative_path(str(data["offload_path"]), base=offload_root)
        if item_offload_path:
            data["offload_path"] = item_offload_path

        # destroyed/offloaded 时不写 content（已卸载到文件/已丢弃）
        if bool(data.get("destroyed")) or bool(data.get("offloaded")):
            data["content"] = ""

    return data


def deserialize_message(data: dict) -> BaseMessage:
    role = data.get("role")
    if role == "user":
        return UserMessage.model_validate(data)
    if role == "assistant":
        return AssistantMessage.model_validate(data)
    if role == "tool":
        return ToolMessage.model_validate(data)
    if role == "system":
        return SystemMessage.model_validate(data)
    if role == "developer":
        return DeveloperMessage.model_validate(data)
    raise SessionStoreError(f"Unsupported message role: {role}")


def conversation_item_to_dict(*, item: ContextItem, offload_root: Path) -> dict:
    message_data = (
        serialize_message_for_persistence(
            item.message,
            offload_root=offload_root,
            item_offload_path=item.offload_path,
        )
        if item.message is not None
        else None
    )

    return {
        "id": item.id,
        "item_type": item.item_type.value,
        "message": message_data,
        "content_text": item.content_text,
        "token_count": item.token_count,
        "priority": item.priority,
        "ephemeral": item.ephemeral,
        "destroyed": item.destroyed,
        "tool_name": item.tool_name,
        "created_at": item.created_at,
        "metadata": item.metadata,
        "cache_hint": item.cache_hint,
        "offload_path": item.offload_path,
        "offloaded": item.offloaded,
        "is_tool_error": item.is_tool_error,
        "created_turn": item.created_turn,
    }


def conversation_item_dict_to_item(*, data: dict, offload_root: Path) -> ContextItem:
    message_data = data.get("message")
    message = deserialize_message(message_data) if message_data else None

    # ToolMessage 的 offload_path 在 jsonl 中保存为相对路径；恢复到内存时转为绝对路径（便于 serializer 展示）
    if isinstance(message, ToolMessage) and message.offloaded and message.offload_path:
        msg_path = str(message.offload_path)
        try:
            if not Path(msg_path).is_absolute():
                message.offload_path = str(offload_root / msg_path)
        except Exception:
            pass

        if data.get("destroyed") is True:
            message.destroyed = True
        if data.get("offloaded") is True:
            message.offloaded = True

    return ContextItem(
        id=data.get("id") or uuid.uuid4().hex[:8],
        item_type=ItemType(data["item_type"]),
        message=message,
        content_text=data.get("content_text", ""),
        token_count=int(data.get("token_count", 0)),
        priority=int(data.get("priority", 50)),
        ephemeral=bool(data.get("ephemeral", False)),
        destroyed=bool(data.get("destroyed", False)),
        tool_name=data.get("tool_name"),
        created_at=float(data.get("created_at", 0.0)),
        metadata=data.get("metadata", {}) or {},
        cache_hint=bool(data.get("cache_hint", False)),
        offload_path=data.get("offload_path"),
        offloaded=bool(data.get("offloaded", False)),
        is_tool_error=bool(data.get("is_tool_error", False)),
        created_turn=int(data.get("created_turn", 0)),
    )


@dataclass(frozen=True)
class ConversationState:
    """用于生成增量持久化的最小状态快照。"""

    ids: tuple[str, ...]
    by_id: dict[str, tuple[bool, bool, str | None, bool, str | None, bool]]
    # (item.destroyed, item.offloaded, item.offload_path, tool_msg.destroyed, tool_msg.offload_path, tool_msg.offloaded)

    @classmethod
    def capture(cls, items: list[ContextItem]) -> "ConversationState":
        ids: list[str] = []
        by_id: dict[str, tuple[bool, bool, str | None, bool, str | None, bool]] = {}

        for item in items:
            ids.append(item.id)
            tool_destroyed = False
            tool_offload_path: str | None = None
            tool_offloaded = False
            if isinstance(item.message, ToolMessage):
                tool_destroyed = bool(item.message.destroyed)
                tool_offload_path = item.message.offload_path
                tool_offloaded = bool(item.message.offloaded)
            by_id[item.id] = (
                bool(item.destroyed),
                bool(item.offloaded),
                item.offload_path,
                tool_destroyed,
                tool_offload_path,
                tool_offloaded,
            )

        return cls(ids=tuple(ids), by_id=by_id)


def build_conversation_event(
    *,
    session_id: str,
    turn_number: int,
    before: ConversationState,
    after_items: list[ContextItem],
    offload_root: Path,
) -> dict:
    pre_set = set(before.ids)
    post_ids = [item.id for item in after_items]
    post_set = set(post_ids)

    removed_ids = [item_id for item_id in before.ids if item_id not in post_set]
    added_items = [item for item in after_items if item.id not in pre_set]

    expected_post_ids = [item_id for item_id in before.ids if item_id in post_set]
    expected_post_ids.extend([item.id for item in added_items])

    if post_ids != expected_post_ids:
        return {
            "schema_version": PERSISTENCE_SCHEMA_VERSION,
            "session_id": session_id,
            "turn_number": turn_number,
            "op": "conversation_reset",
            "conversation": {
                "items": [
                    conversation_item_to_dict(item=item, offload_root=offload_root)
                    for item in after_items
                ]
            },
        }

    updates: list[dict] = []
    for item in after_items:
        if item.id not in pre_set:
            continue

        prev = before.by_id.get(item.id)
        if prev is None:
            continue

        (
            prev_item_destroyed,
            prev_item_offloaded,
            prev_item_offload_path,
            prev_tool_destroyed,
            prev_tool_offload_path,
            prev_tool_offloaded,
        ) = prev

        cur_tool_destroyed = False
        cur_tool_offload_path: str | None = None
        cur_tool_offloaded = False
        if isinstance(item.message, ToolMessage):
            cur_tool_destroyed = bool(item.message.destroyed)
            cur_tool_offload_path = item.message.offload_path
            cur_tool_offloaded = bool(item.message.offloaded)

        cur = (
            bool(item.destroyed),
            bool(item.offloaded),
            item.offload_path,
            cur_tool_destroyed,
            cur_tool_offload_path,
            cur_tool_offloaded,
        )

        if cur == prev:
            continue

        upd: dict = {"id": item.id}
        if bool(item.destroyed) != prev_item_destroyed:
            upd["destroyed"] = bool(item.destroyed)
        if bool(item.offloaded) != prev_item_offloaded:
            upd["offloaded"] = bool(item.offloaded)
        if item.offload_path != prev_item_offload_path:
            upd["offload_path"] = item.offload_path

        if isinstance(item.message, ToolMessage):
            msg_upd: dict = {}
            if bool(item.message.destroyed) != prev_tool_destroyed:
                msg_upd["destroyed"] = bool(item.message.destroyed)
            if bool(item.message.offloaded) != prev_tool_offloaded:
                msg_upd["offloaded"] = bool(item.message.offloaded)
            if item.message.offload_path != prev_tool_offload_path:
                if item.message.offload_path:
                    msg_upd["offload_path"] = _as_relative_path(
                        str(item.message.offload_path),
                        base=offload_root,
                    )
                else:
                    msg_upd["offload_path"] = None
            if msg_upd:
                upd["message"] = msg_upd

        updates.append(upd)

    return {
        "schema_version": PERSISTENCE_SCHEMA_VERSION,
        "session_id": session_id,
        "turn_number": turn_number,
        "op": "conversation_delta",
        "conversation": {
            "adds": [
                conversation_item_to_dict(item=item, offload_root=offload_root)
                for item in added_items
            ],
            "updates": updates,
            "removes": list(removed_ids),
        },
    }


def token_usage_entry_to_dict(*, entry: TokenUsageEntry) -> dict:
    return entry.model_dump(mode="json")


def token_usage_entry_dict_to_entry(*, data: dict) -> TokenUsageEntry:
    return TokenUsageEntry.model_validate(data)


def build_usage_event(
    *,
    session_id: str,
    turn_number: int,
    added_entries: list[TokenUsageEntry],
    context_usage: int | None = None,
) -> dict | None:
    if not added_entries:
        return None

    usage_data: dict = {
        "adds": [
            token_usage_entry_to_dict(entry=entry)
            for entry in added_entries
        ]
    }
    if context_usage is not None and context_usage > 0:
        usage_data["context_usage"] = context_usage

    return {
        "schema_version": PERSISTENCE_SCHEMA_VERSION,
        "session_id": session_id,
        "turn_number": turn_number,
        "op": "usage_delta",
        "usage": usage_data,
    }


def build_header_snapshot_event(
    *,
    session_id: str,
    snapshot: dict[str, Any],
    turn_number: int = 0,
) -> dict:
    return {
        "schema_version": PERSISTENCE_SCHEMA_VERSION,
        "session_id": session_id,
        "turn_number": max(0, int(turn_number)),
        "op": "header_snapshot",
        "header": snapshot,
    }


def build_file_track_state_event(
    *,
    session_id: str,
    turn_number: int,
    state: FileTrackState,
) -> dict:
    return {
        "schema_version": PERSISTENCE_SCHEMA_VERSION,
        "session_id": session_id,
        "turn_number": max(0, int(turn_number)),
        "op": "file_track_state_snapshot",
        "file_track_state": state.serialize(),
    }


def build_deferred_items_event(
    *,
    session_id: str,
    turn_number: int,
    items: list[ContextItem],
    offload_root: Path,
) -> dict:
    return {
        "schema_version": PERSISTENCE_SCHEMA_VERSION,
        "session_id": session_id,
        "turn_number": max(0, int(turn_number)),
        "op": "deferred_items_reset",
        "deferred": {
            "items": [
                conversation_item_to_dict(item=item, offload_root=offload_root)
                for item in items
            ]
        },
    }


def slice_usage_delta(
    usage_history: list[TokenUsageEntry],
    *,
    before_count: int,
) -> list[TokenUsageEntry]:
    if before_count < 0 or before_count > len(usage_history):
        return list(usage_history)
    return list(usage_history[before_count:])


def replay_session_events(
    *,
    path: Path,
    offload_root: Path,
    max_turn: int | None = None,
) -> tuple[int, list[ContextItem], list[TokenUsageEntry]]:
    if not path.exists():
        return 0, [], []

    items_by_id: dict[str, ContextItem] = {}
    order: list[str] = []
    usage_entries: list[TokenUsageEntry] = []
    last_turn = 0

    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue

            if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                continue

            turn_number = int(data.get("turn_number", 0))
            if max_turn is not None and turn_number > max_turn:
                continue
            if turn_number > last_turn:
                last_turn = turn_number

            op = data.get("op")
            if op == "usage_reset":
                usage_entries = []
                continue
            if op == "usage_delta":
                usage = data.get("usage") or {}
                for entry_data in usage.get("adds", []) or []:
                    try:
                        usage_entries.append(token_usage_entry_dict_to_entry(data=entry_data))
                    except Exception as e:
                        logger.warning(f"Failed to replay usage entry: {e}", exc_info=True)
                continue

            convo = data.get("conversation") or {}

            if op == "conversation_reset":
                items_by_id = {}
                order = []
                for item_data in convo.get("items", []) or []:
                    item = conversation_item_dict_to_item(data=item_data, offload_root=offload_root)
                    items_by_id[item.id] = item
                    order.append(item.id)
                continue

            if op != "conversation_delta":
                continue

            removes = convo.get("removes", []) or []
            if removes:
                remove_set = set(str(x) for x in removes)
                for rid in remove_set:
                    items_by_id.pop(rid, None)
                order = [item_id for item_id in order if item_id not in remove_set]

            for item_data in convo.get("adds", []) or []:
                item = conversation_item_dict_to_item(data=item_data, offload_root=offload_root)
                items_by_id[item.id] = item
                order.append(item.id)

            for upd in convo.get("updates", []) or []:
                item_id = upd.get("id")
                if not item_id:
                    continue
                item = items_by_id.get(item_id)
                if item is None:
                    continue

                if "destroyed" in upd:
                    item.destroyed = bool(upd["destroyed"])
                if "offloaded" in upd:
                    item.offloaded = bool(upd["offloaded"])
                if "offload_path" in upd:
                    item.offload_path = upd["offload_path"]

                msg_upd = upd.get("message") or {}
                if isinstance(item.message, ToolMessage) and msg_upd:
                    if "destroyed" in msg_upd:
                        item.message.destroyed = bool(msg_upd["destroyed"])
                    if "offloaded" in msg_upd:
                        item.message.offloaded = bool(msg_upd["offloaded"])
                    if "offload_path" in msg_upd:
                        rel = msg_upd["offload_path"]
                        if rel:
                            try:
                                if not Path(str(rel)).is_absolute():
                                    item.message.offload_path = str(offload_root / str(rel))
                                else:
                                    item.message.offload_path = str(rel)
                            except Exception:
                                item.message.offload_path = str(rel)
                        else:
                            item.message.offload_path = None

    items: list[ContextItem] = []
    for item_id in order:
        item = items_by_id.get(item_id)
        if item is not None:
            items.append(item)

    return last_turn, items, usage_entries


def replay_deferred_items_events(
    *,
    path: Path,
    offload_root: Path,
    max_turn: int | None = None,
) -> list[ContextItem]:
    if not path.exists():
        return []

    deferred_items: list[ContextItem] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue

            if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                continue

            turn_number = int(data.get("turn_number", 0))
            if max_turn is not None and turn_number > max_turn:
                continue

            if data.get("op") != "deferred_items_reset":
                continue

            deferred = data.get("deferred") or {}
            deferred_items = [
                conversation_item_dict_to_item(data=item_data, offload_root=offload_root)
                for item_data in deferred.get("items", []) or []
            ]

    return deferred_items


def replay_file_track_state_snapshot(
    *,
    path: Path,
    max_turn: int | None = None,
) -> FileTrackState | None:
    if not path.exists():
        return None

    latest: FileTrackState | None = None
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue

            if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                continue

            turn_number = int(data.get("turn_number", 0))
            if max_turn is not None and turn_number > max_turn:
                continue
            if data.get("op") != "file_track_state_snapshot":
                continue

            payload = data.get("file_track_state")
            if isinstance(payload, dict):
                latest = FileTrackState.deserialize(payload)

    return latest


def replay_header_snapshot(
    *,
    path: Path,
    max_turn: int | None = None,
) -> dict[str, Any] | None:
    if not path.exists():
        return None

    snapshot: dict[str, Any] | None = None
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue
            if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                continue

            turn_number = int(data.get("turn_number", 0))
            if max_turn is not None and turn_number > max_turn:
                continue
            if data.get("op") != "header_snapshot":
                continue
            if snapshot is not None:
                # 固定首版 header：后续快照不覆盖。
                continue

            header = data.get("header")
            if isinstance(header, dict):
                snapshot = header

    return snapshot


def replay_conversation_events(*, path: Path, offload_root: Path) -> tuple[int, list[ContextItem]]:
    turn_number, items, _ = replay_session_events(path=path, offload_root=offload_root)
    return turn_number, items


def replay_session_events_until_turn(
    *,
    path: Path,
    offload_root: Path,
    max_turn: int,
) -> tuple[int, list[ContextItem], list[TokenUsageEntry]]:
    return replay_session_events(
        path=path,
        offload_root=offload_root,
        max_turn=max_turn,
    )


def events_jsonl_append(path: Path, event: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def rewrite_session_id_in_jsonl(path: Path, *, session_id: str) -> None:
    if not path.exists():
        return

    lines: list[str] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue
            data["session_id"] = session_id
            lines.append(json.dumps(data, ensure_ascii=False))

    with path.open("w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")


def replay_external_turn_journal(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []

    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            raw = line.strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except Exception:
                continue
            if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                continue
            records.append(data)
    return records
