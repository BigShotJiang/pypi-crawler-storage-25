from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from comate_agent_sdk.utils.yaml_utils import safe_load_frontmatter

MAX_SCAN_FILE_COUNT = 200
MAX_FRONTMATTER_LINES = 30
MAX_SURFACED_MEMORY_BYTES = 4_096
MAX_MEMORY_LINES = 200


@dataclass(frozen=True, slots=True)
class MemoryHeader:
    path: Path
    filename: str
    description: str
    memory_type: str
    mtime_ms: float


@dataclass(frozen=True, slots=True)
class SurfacedMemoryDocument:
    path: Path
    content: str
    mtime_ms: float
    truncated: bool
    byte_count: int


def scan_memory_headers(
    memory_dir: Path,
    *,
    max_files: int = MAX_SCAN_FILE_COUNT,
    max_frontmatter_lines: int = MAX_FRONTMATTER_LINES,
) -> list[MemoryHeader]:
    memory_root = Path(memory_dir).expanduser().resolve()
    if not memory_root.exists():
        return []

    paths = sorted(
        [
            path
            for path in memory_root.rglob("*.md")
            if path.is_file() and path.name.lower() != "memory.md"
        ],
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )[:max_files]

    headers: list[MemoryHeader] = []
    for path in paths:
        header = _read_memory_header(path, memory_root=memory_root, max_frontmatter_lines=max_frontmatter_lines)
        if header is not None:
            headers.append(header)
    return headers


def read_memory_document_for_surface(
    path: Path,
    *,
    max_bytes: int = MAX_SURFACED_MEMORY_BYTES,
) -> SurfacedMemoryDocument:
    resolved_path = Path(path).expanduser().resolve()
    text = resolved_path.read_text(encoding="utf-8")

    # Step 1: 行数截断
    lines = text.splitlines(keepends=True)
    line_truncated = len(lines) > MAX_MEMORY_LINES
    if line_truncated:
        text = "".join(lines[:MAX_MEMORY_LINES])

    # Step 2: 字节截断
    encoded = text.encode("utf-8")
    byte_truncated = len(encoded) > max_bytes
    if byte_truncated:
        encoded = encoded[:max_bytes]
        text = encoded.decode("utf-8", errors="ignore")

    # Step 3: 截断提示
    truncated = line_truncated or byte_truncated
    if truncated:
        hint = f"\n\n> This memory file was truncated. Read the complete file at: {resolved_path.as_posix()}"
        text = text + hint

    final_bytes = len(text.encode("utf-8"))
    return SurfacedMemoryDocument(
        path=resolved_path,
        content=text,
        mtime_ms=resolved_path.stat().st_mtime * 1000,
        truncated=truncated,
        byte_count=final_bytes,
    )


def format_memory_manifest(headers: list[MemoryHeader]) -> str:
    lines: list[str] = []
    for header in headers:
        timestamp = datetime.fromtimestamp(
            header.mtime_ms / 1000,
            tz=timezone.utc,
        ).isoformat(timespec="seconds").replace("+00:00", "Z")
        lines.append(
            f"- [{header.memory_type}] {header.filename} ({timestamp}): {header.description}"
        )
    return "\n".join(lines)


def _read_memory_header(
    path: Path,
    *,
    memory_root: Path,
    max_frontmatter_lines: int,
) -> MemoryHeader | None:
    prefix_lines = path.read_text(encoding="utf-8").splitlines()[:max_frontmatter_lines]
    prefix_text = "\n".join(prefix_lines)
    frontmatter = _extract_frontmatter(prefix_text, source=path.as_posix())

    description = " ".join(str(frontmatter.get("description") or "").split())
    if not description:
        return None

    memory_type = str(frontmatter.get("type") or "reference").strip() or "reference"
    return MemoryHeader(
        path=path.resolve(),
        filename=str(path.relative_to(memory_root)),
        description=description,
        memory_type=memory_type,
        mtime_ms=path.stat().st_mtime * 1000,
    )


def _extract_frontmatter(text: str, *, source: str) -> dict[str, object]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}

    for idx in range(1, len(lines)):
        if lines[idx].strip() != "---":
            continue
        payload = "\n".join(lines[1:idx]).strip()
        if not payload:
            return {}
        return safe_load_frontmatter(payload, source=source)

    return {}
