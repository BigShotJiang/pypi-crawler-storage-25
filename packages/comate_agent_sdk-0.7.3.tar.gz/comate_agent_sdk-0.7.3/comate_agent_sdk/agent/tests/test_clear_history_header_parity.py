from __future__ import annotations

import tempfile
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        return ChatInvokeCompletion(content="ok")


def test_clear_history_keeps_auto_agents_inert_when_agent_tool_not_enabled() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=("Read",),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp),
            ),
        )
        runtime = template.create_runtime()

    assert runtime._context.header.find_one_by_type(ItemType.SUBAGENT_STRATEGY) is None
    assert runtime._context.session_state.find_one_by_type(ItemType.SUBAGENT_LISTING) is None

    runtime.clear_history()

    assert runtime._context.header.find_one_by_type(ItemType.SUBAGENT_STRATEGY) is None
    assert runtime._context.session_state.find_one_by_type(ItemType.SUBAGENT_LISTING) is None
    system_prompt = runtime._context.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
    assert system_prompt is not None
    assert "Solo mode" in system_prompt.content_text
    assert "Subagent mode" not in system_prompt.content_text
