from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig, USER_INSTRUCTION_NOTICE
from comate_agent_sdk.agent.system_prompt import (
    AUTO_MEMORY_DIR_PLACEHOLDER,
    SystemPromptConfig,
    resolve_memory_usage_prompt,
    resolve_system_prompt,
)


GENERAL_OPENING_LINE = (
    "You are Comate, an AI-powered agent developed by AndyLee. an interactive general AI agent running on a user's computer that helps users as a general AI agent."
)
SOFTWARE_ENGINEERING_OPENING_LINE = (
    "You are Comate, an AI-powered coding agent developed by AndyLee. You run locally on the user's computer and help with software engineering tasks. You are NOT related to Baidu Comate or any other product with a similar name."
)


class _FakeChatModel:
    def __init__(self):
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


def _first_non_empty_line(text: str) -> str:
    for line in text.splitlines():
        if line.strip():
            return line.strip()
    return ""


def test_default_role_uses_general_opening_line() -> None:
    prompt = resolve_system_prompt(None)
    assert _first_non_empty_line(prompt) == GENERAL_OPENING_LINE
    assert "# Identity & Communication" in prompt
    assert "# Capabilities" in prompt
    assert "# Execution" in prompt
    assert "# Context" in prompt
    assert "<agent_loop>" not in prompt


def test_general_role_uses_general_opening_line() -> None:
    prompt = resolve_system_prompt(None, role="general")
    assert _first_non_empty_line(prompt) == GENERAL_OPENING_LINE


def test_custom_role_uses_text_as_opening_line() -> None:
    custom_opening = "You are a data analysis expert that helps users explore datasets."
    prompt = resolve_system_prompt(None, role=custom_opening)
    assert _first_non_empty_line(prompt) == custom_opening
    assert "# Identity & Communication" in prompt


def test_custom_role_with_append_mode() -> None:
    custom_opening = "You are a security auditor."
    prompt = resolve_system_prompt(
        SystemPromptConfig(content="EXTRA_RULES", mode="append"),
        role=custom_opening,
    )
    assert _first_non_empty_line(prompt) == custom_opening
    assert "EXTRA_RULES" in prompt


def test_custom_role_ignored_when_system_prompt_override() -> None:
    custom_opening = "You are a data analysis expert."
    prompt = resolve_system_prompt("FULL_OVERRIDE", role=custom_opening)
    assert prompt.startswith("FULL_OVERRIDE")
    assert custom_opening not in prompt


def test_string_system_prompt_override_ignores_role() -> None:
    prompt = resolve_system_prompt("CUSTOM_PROMPT", role="general")
    assert prompt.startswith("CUSTOM_PROMPT")
    assert "<agent_loop>" not in prompt


def test_system_prompt_config_override_ignores_role() -> None:
    prompt = resolve_system_prompt(
        SystemPromptConfig(content="OVERRIDE_PROMPT", mode="override"),
        role="general",
    )
    assert prompt.startswith("OVERRIDE_PROMPT")
    assert "<agent_loop>" not in prompt


def test_system_prompt_append_uses_role_aware_default_prompt() -> None:
    prompt = resolve_system_prompt(
        SystemPromptConfig(content="APPENDED_PROMPT", mode="append"),
        role="general",
    )
    assert _first_non_empty_line(prompt) == GENERAL_OPENING_LINE
    assert "APPENDED_PROMPT" in prompt
    assert "<agent_loop>" not in prompt


def test_runtime_role_propagation_and_header_opening_line() -> None:
    template = Agent(
        llm=_FakeChatModel(),  # type: ignore[arg-type]
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            setting_sources=None,
            role="general",
        ),
    )
    runtime = template.create_runtime()
    assert template.role == "general"
    assert runtime.config.role == "general"
    assert _first_non_empty_line(runtime.messages[0].text) == GENERAL_OPENING_LINE


def test_auto_memory_dir_placeholder_replaced_when_provided() -> None:
    prompt = resolve_system_prompt(
        f"Dir: {AUTO_MEMORY_DIR_PLACEHOLDER}",
        auto_memory_dir="/tmp/project-memory",
    )
    assert AUTO_MEMORY_DIR_PLACEHOLDER not in prompt
    assert f"{Path('/tmp/project-memory').resolve().as_posix()}/" in prompt


def test_auto_memory_dir_is_not_injected_without_placeholder() -> None:
    prompt = resolve_system_prompt("CUSTOM_PROMPT", auto_memory_dir="/tmp/project-memory")
    assert prompt.startswith("CUSTOM_PROMPT")
    assert "<agent_loop>" not in prompt


def test_memory_usage_prompt_includes_normalized_memory_dir() -> None:
    prompt = resolve_memory_usage_prompt("/tmp/project-memory")

    assert "<memory_usage>" in prompt
    assert f"`{Path('/tmp/project-memory').resolve().as_posix()}/`" in prompt
    assert "# auto memory" in prompt
    assert "This directory already exists" in prompt
    assert "type: {{user, feedback, project, reference}}" in prompt
    assert "Memory and other forms of persistence" in prompt
    assert "MEMORY.md" not in prompt


def test_memory_usage_prompt_includes_verification_guidance() -> None:
    prompt = resolve_memory_usage_prompt("/tmp/project-memory")

    assert "Before recommending from memory" in prompt
    assert "claim that it existed" in prompt
    assert "check the file exists" in prompt
    assert "grep for it" in prompt


def test_agent_package_exports_user_instruction_notice() -> None:
    assert USER_INSTRUCTION_NOTICE.startswith("<system-reminder>")
    assert "highly relevant to your task" in USER_INSTRUCTION_NOTICE
