import asyncio
from unittest.mock import AsyncMock

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.context.file_track import FileTrackState
from comate_agent_sdk.context.items import ContextItem, DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.partial_compaction import (
    PartialCompactionResult,
    build_boundary_item,
)
from comate_agent_sdk.llm.messages import ToolMessage, UserMessage


class FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        raise AssertionError("post-compact replay tests must not call the LLM")


def build_chat_session_with_files(tmp_path, *, files: dict[str, str]) -> ChatSession:
    for relpath, content in files.items():
        path = tmp_path / relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    agent = Agent(
        llm=FakeChatModel(),
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            setting_sources=None,
        ),
    )
    sess = ChatSession(agent, session_id="s1", cwd=tmp_path)
    sess._agent._file_track_state = FileTrackState()
    return sess


def make_partial_result(*, tail_items: list[ContextItem]) -> PartialCompactionResult:
    boundary = build_boundary_item(
        trigger="check",
        pre_compact_tokens=50_000,
        post_compact_tokens=12_000,
        summary_item_id="sum-1",
        tail_kept_count=len(tail_items),
        tail_kept_tokens=sum(item.token_count for item in tail_items),
    )
    summary = ContextItem(
        id="sum-1",
        item_type=ItemType.COMPACTION_SUMMARY,
        message=UserMessage(content="<summary>old work</summary>"),
        content_text="<summary>old work</summary>",
        token_count=100,
        priority=DEFAULT_PRIORITIES[ItemType.COMPACTION_SUMMARY],
    )
    return PartialCompactionResult(
        boundary_item=boundary,
        summary_item=summary,
        prefix_items=[],
        tail_items=tail_items,
        pivot_index=0,
        diagnostics={},
    )


def make_tool_result_item(tool_name: str, path: str, content: str) -> ContextItem:
    msg = ToolMessage(
        tool_call_id="tc-read",
        tool_name=tool_name,
        content=content,
        execution_meta={"file_ops": {"file_path": path}},
        raw_envelope={"meta": {"resolved_file_path": path}},
    )
    return ContextItem(
        item_type=ItemType.TOOL_RESULT,
        message=msg,
        content_text=content,
        token_count=max(1, len(content) // 4),
        priority=DEFAULT_PRIORITIES[ItemType.TOOL_RESULT],
        tool_name=tool_name,
        metadata={
            "tool_name": tool_name,
            "tool_execution_meta": msg.execution_meta,
            "tool_raw_envelope": msg.raw_envelope,
        },
    )


def test_replay_returns_attachments_for_recent_files(tmp_path):
    sess = build_chat_session_with_files(tmp_path, files={
        "a.py": "print('a')",
        "b.py": "print('b')",
    })
    sess._agent._file_track_state.record(str(tmp_path / "a.py"), "read")
    sess._agent._file_track_state.record(str(tmp_path / "b.py"), "write")

    result = make_partial_result(tail_items=[])
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    assert len(attachments) == 2


def test_replay_skips_files_in_tail(tmp_path):
    sess = build_chat_session_with_files(tmp_path, files={"a.py": "x"})
    sess._agent._file_track_state.record(str(tmp_path / "a.py"), "read")
    tail_with_a = [make_tool_result_item("Read", str(tmp_path / "a.py"), "x")]

    result = make_partial_result(tail_items=tail_with_a)
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    assert len(attachments) == 0


def test_replay_handles_missing_file(tmp_path):
    sess = build_chat_session_with_files(tmp_path, files={})
    sess._agent._file_track_state.record(str(tmp_path / "ghost.py"), "read")

    result = make_partial_result(tail_items=[])
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    assert len(attachments) == 0
    assert "ghost.py" in str(result.boundary_item.metadata.get("missing_files", []))


def test_replay_truncates_oversize_file(tmp_path):
    huge = "x" * 100_000
    sess = build_chat_session_with_files(tmp_path, files={"big.py": huge})
    sess._agent._file_track_state.record(str(tmp_path / "big.py"), "read")

    result = make_partial_result(tail_items=[])
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    assert len(attachments) == 1
    assert "<truncated" in attachments[0].message.content


def test_replay_respects_total_budget(tmp_path):
    files = {f"f{i}.py": "x" * 30_000 for i in range(5)}
    sess = build_chat_session_with_files(tmp_path, files=files)
    for i in range(5):
        sess._agent._file_track_state.record(str(tmp_path / f"f{i}.py"), "read")

    result = make_partial_result(tail_items=[])
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    total = sum(len(attachment.message.content) for attachment in attachments)
    assert total <= 50_000 * 4


def test_replay_failure_does_not_raise(tmp_path):
    sess = build_chat_session_with_files(tmp_path, files={})
    sess._read_file_from_disk = AsyncMock(side_effect=PermissionError("boom"))
    sess._agent._file_track_state.record(str(tmp_path / "a.py"), "read")

    result = make_partial_result(tail_items=[])
    attachments = asyncio.run(sess._post_compact_replay_files(result))

    assert attachments == []


def test_chat_session_binds_and_clears_post_compact_hook(tmp_path):
    sess = build_chat_session_with_files(tmp_path, files={})
    assert getattr(sess._agent, "_post_compact_replay_files").__self__ is sess

    asyncio.run(sess.close())

    assert getattr(sess._agent, "_post_compact_replay_files", None) is None
