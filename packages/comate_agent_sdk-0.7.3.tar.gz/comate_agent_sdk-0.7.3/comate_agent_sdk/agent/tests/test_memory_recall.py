from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig, StopEvent
from comate_agent_sdk.agent.memory_runtime import (
    _memory_age_days,
    _render_relevant_memory_reminder,
    collect_surfaced_relevant_memories,
    consume_ready_relevant_memory_prefetch,
    should_prefetch_relevant_memories,
    start_relevant_memory_prefetch,
)
from comate_agent_sdk.agent.memory_store import SurfacedMemoryDocument
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    SystemMessage,
    ToolCall,
    UserMessage,
)
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.prompts import load_prompt
from comate_agent_sdk.tools import tool


class _SelectionOnlyFakeChatModel:
    def __init__(self, *, selected_memories: list[str]) -> None:
        self.selected_memories = list(selected_memories)
        self.calls = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, output_format, kwargs
        self.calls += 1
        return ChatInvokeCompletion(
            content=json.dumps({"selected_memories": self.selected_memories}, ensure_ascii=False)
        )


class _InspectingSelectionFakeChatModel(_SelectionOnlyFakeChatModel):
    def __init__(self, *, selected_memories: list[str]) -> None:
        super().__init__(selected_memories=selected_memories)
        self.captured_messages: list[list[object]] = []

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        self.captured_messages.append(list(messages))
        return await super().ainvoke(
            messages,
            tools=tools,
            tool_choice=tool_choice,
            output_format=output_format,
            **kwargs,
        )


class _MainAndSelectionFakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"
        self.main_messages: list[list[object]] = []
        self.side_query_calls = 0

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        del tool_choice, output_format, kwargs
        serialized = "\n".join(
            getattr(message, "text", str(getattr(message, "content", "")))
            for message in messages
        )
        if tools is None and "You are selecting which saved memory files are clearly relevant" in serialized:
            self.side_query_calls += 1
            await asyncio.sleep(0.05)
            return ChatInvokeCompletion(
                content='{"selected_memories":["feedback_db_no_mocks.md"]}'
            )

        self.main_messages.append(list(messages))
        if len(self.main_messages) == 1:
            return ChatInvokeCompletion(
                tool_calls=[
                    ToolCall(
                        id="tc_noop",
                        function=Function(name="NoOp", arguments="{}"),
                    )
                ]
            )
        if len(self.main_messages) == 2:
            return ChatInvokeCompletion(content="done")
        raise AssertionError(f"Unexpected main ainvoke call #{len(self.main_messages)}")


class _ImmediateSelectorMainModel(_MainAndSelectionFakeChatModel):
    """与 _MainAndSelectionFakeChatModel 相同，但 side query 不 sleep，使 prefetch 立即完成。

    区分 side query 和 main LLM 调用的方式：
    - side query（memory selector）：side_query() 调用时 tools=None，且消息含 selector 关键字
    - main LLM 调用：AgentConfig(tools=(NoOp,)) 使 tools 不为 None
    因此 `tools is None` + 关键字双重判断能精确区分两条路径。
    """

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        serialized = "\n".join(
            getattr(message, "text", str(getattr(message, "content", "")))
            for message in messages
        )
        if tools is None and "You are selecting which saved memory files are clearly relevant" in serialized:
            self.side_query_calls += 1
            # 不 sleep：prefetch 在首轮 LLM 调用前即可完成
            return ChatInvokeCompletion(
                content='{"selected_memories":["feedback_db_no_mocks.md"]}'
            )
        self.main_messages.append(list(messages))
        if len(self.main_messages) == 1:
            return ChatInvokeCompletion(
                tool_calls=[
                    ToolCall(
                        id="tc_noop",
                        function=Function(name="NoOp", arguments="{}"),
                    )
                ]
            )
        if len(self.main_messages) == 2:
            return ChatInvokeCompletion(content="done")
        raise AssertionError(f"Unexpected main ainvoke call #{len(self.main_messages)}")


class _BlockedSelectorFollowupModel:
    def __init__(self, *, release_event: asyncio.Event) -> None:
        self.model = "fake:model"
        self._release_event = release_event
        self.main_messages: list[list[object]] = []
        self.side_query_calls = 0

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        del tool_choice, output_format, kwargs
        serialized = "\n".join(
            getattr(message, "text", str(getattr(message, "content", "")))
            for message in messages
        )
        if tools is None and "You are selecting which saved memory files are clearly relevant" in serialized:
            self.side_query_calls += 1
            await self._release_event.wait()
            return ChatInvokeCompletion(
                content='{"selected_memories":["feedback_db_no_mocks.md"]}'
            )

        self.main_messages.append(list(messages))
        if len(self.main_messages) == 1:
            return ChatInvokeCompletion(
                tool_calls=[
                    ToolCall(
                        id="tc_noop",
                        function=Function(name="NoOp", arguments="{}"),
                    )
                ]
            )
        if len(self.main_messages) == 2:
            return ChatInvokeCompletion(content="done")
        raise AssertionError(f"Unexpected main ainvoke call #{len(self.main_messages)}")


class TestMemoryRecall(unittest.IsolatedAsyncioTestCase):
    def test_memory_select_prompt_allows_empty_selection_and_recent_tools(self) -> None:
        prompt = load_prompt("memory/select_relevant.md")

        self.assertIn("empty list", prompt)
        self.assertIn("Recently used tools", prompt)

    def test_should_prefetch_relevant_memories_skips_single_word_queries(self) -> None:
        self.assertFalse(should_prefetch_relevant_memories("hello"))
        self.assertTrue(should_prefetch_relevant_memories("hello world"))

    def test_should_prefetch_relevant_memories_triggers_for_cjk_queries(self) -> None:
        # CJK text has no whitespace; fall back to char count (>= 4).
        self.assertFalse(should_prefetch_relevant_memories("好"))        # 1 char
        self.assertFalse(should_prefetch_relevant_memories("你好吗"))    # 3 chars
        self.assertTrue(should_prefetch_relevant_memories("我叫什么"))    # 4 chars
        self.assertTrue(should_prefetch_relevant_memories("我住在哪里"))  # 5 chars

    def test_collect_surfaced_relevant_memories_reads_metadata_from_conversation(self) -> None:
        ctx = ContextIR()
        ctx.add_message(
            UserMessage(content="<system-reminder>\nmem\n</system-reminder>", is_meta=True),
            item_type=ItemType.SYSTEM_REMINDER,
            metadata={
                "origin": "relevant_memory",
                "memory_paths": ["/tmp/a.md", "/tmp/b.md"],
                "memory_total_bytes": 123,
            },
        )

        paths, total_bytes = collect_surfaced_relevant_memories(ctx)

        self.assertSetEqual(paths, {"/tmp/a.md", "/tmp/b.md"})
        self.assertEqual(total_bytes, 123)

    async def test_start_relevant_memory_prefetch_selects_and_reads_topic_files(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )
            (memory_dir / "project_auth.md").write_text(
                "---\nname: project_auth\ndescription: auth rewrite driven by compliance\ntype: project\n---\n"
                "Auth rewrite context.\n",
                encoding="utf-8",
            )

            lowered_static_header = "\n".join(
                str(message.content)
                for message in runtime._context.lower()
                if isinstance(message, SystemMessage)
            )
            self.assertNotIn("feedback_db_no_mocks.md", lowered_static_header)
            self.assertNotIn("integration tests must hit real database", lowered_static_header)
            self.assertNotIn("project_auth.md", lowered_static_header)
            self.assertNotIn("auth rewrite driven by compliance", lowered_static_header)

            prefetch = start_relevant_memory_prefetch(runtime, "how should we handle database integration tests")

            self.assertIsNotNone(prefetch)
            assert prefetch is not None
            documents = await prefetch.task

            self.assertEqual(llm.calls, 1)
            self.assertEqual([document.path.name for document in documents], ["feedback_db_no_mocks.md"])
            self.assertIn("Don't mock the database", documents[0].content)

    async def test_start_relevant_memory_prefetch_respects_runtime_flag(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            runtime._relevant_memory_prefetch_enabled = False

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(
                runtime,
                "how should we handle database integration tests",
            )

            self.assertIsNone(prefetch)
            self.assertEqual(llm.calls, 0)

    async def test_consume_ready_relevant_memory_prefetch_injects_once(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            runtime._memory_extraction_enabled = False
            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")
            assert prefetch is not None
            await prefetch.task

            first = consume_ready_relevant_memory_prefetch(runtime, prefetch)
            second = consume_ready_relevant_memory_prefetch(runtime, prefetch)

            self.assertTrue(first)
            self.assertFalse(second)
            reminders = [
                item
                for item in runtime._context.get_deferred_items_snapshot()
                if item.item_type == ItemType.DEFERRED_META
                and item.metadata.get("origin") == "relevant_memory"
            ]
            self.assertEqual(len(reminders), 1)
            self.assertIn("feedback_db_no_mocks.md", reminders[0].content_text)

    async def test_start_relevant_memory_prefetch_works_without_context_memory_field(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            runtime._context = SimpleNamespace(conversation=runtime._context.conversation)

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")

            self.assertIsNotNone(prefetch)
            assert prefetch is not None
            documents = await prefetch.task

            self.assertEqual([document.path.name for document in documents], ["feedback_db_no_mocks.md"])

    async def test_start_relevant_memory_prefetch_includes_recent_tools_in_selector_input(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _InspectingSelectionFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: database gotchas\ntype: feedback\n---\n"
                "Database gotchas.\n",
                encoding="utf-8",
            )

            runtime._context.add_message(
                AssistantMessage(
                    content=None,
                    tool_calls=[
                        ToolCall(
                            id="tc-read-1",
                            function=Function(name="Read", arguments='{"file":"a.py"}'),
                        )
                    ],
                )
            )
            runtime._context.add_message(
                AssistantMessage(
                    content=None,
                    tool_calls=[
                        ToolCall(
                            id="tc-bash-1",
                            function=Function(name="Bash", arguments='{"cmd":"pytest"}'),
                        )
                    ],
                )
            )
            runtime._context.add_message(
                AssistantMessage(
                    content=None,
                    tool_calls=[
                        ToolCall(
                            id="tc-read-2",
                            function=Function(name="Read", arguments='{"file":"b.py"}'),
                        )
                    ],
                )
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")

            assert prefetch is not None
            await prefetch.task

            self.assertEqual(len(llm.captured_messages), 1)
            serialized = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.captured_messages[0]
            )
            self.assertIn("Available memories:", serialized)
            self.assertIn("- [feedback] feedback_db_no_mocks.md", serialized)
            self.assertIn("database gotchas", serialized)
            self.assertIn("Recently used tools: Read, Bash", serialized)

    async def test_start_relevant_memory_prefetch_omits_recent_tools_section_when_none(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _InspectingSelectionFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: database gotchas\ntype: feedback\n---\n"
                "Database gotchas.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")

            assert prefetch is not None
            await prefetch.task

            self.assertEqual(len(llm.captured_messages), 1)
            serialized = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.captured_messages[0]
            )
            self.assertNotIn("Recently used tools:", serialized)

    async def test_start_relevant_memory_prefetch_defaults_to_current_llm_even_with_low_level(self) -> None:
        """配置了 LOW level 时，记忆召回仍使用主 agent 模型（不再自动降级）。"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            main_llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            low_llm = _SelectionOnlyFakeChatModel(selected_memories=["project_auth.md"])
            template = Agent(
                llm=main_llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    llm_levels={"LOW": low_llm},  # type: ignore[arg-type]
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )
            (memory_dir / "project_auth.md").write_text(
                "---\nname: project_auth\ndescription: auth rewrite driven by compliance\ntype: project\n---\n"
                "Auth rewrite context.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")
            assert prefetch is not None
            documents = await prefetch.task

            self.assertEqual(main_llm.calls, 1)
            self.assertEqual(low_llm.calls, 0)
            self.assertEqual([document.path.name for document in documents], ["feedback_db_no_mocks.md"])

    async def test_start_relevant_memory_prefetch_respects_env_level_override(self) -> None:
        """通过 COMATE_AGENT_SDK_MEMORY_LLM_LEVEL env 可以覆盖为指定 level。"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            main_llm = _SelectionOnlyFakeChatModel(selected_memories=["project_auth.md"])
            low_llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=main_llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    llm_levels={"LOW": low_llm},  # type: ignore[arg-type]
                    env={"COMATE_AGENT_SDK_MEMORY_LLM_LEVEL": "haiku"},
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )
            (memory_dir / "project_auth.md").write_text(
                "---\nname: project_auth\ndescription: auth rewrite driven by compliance\ntype: project\n---\n"
                "Auth rewrite context.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")
            assert prefetch is not None
            documents = await prefetch.task

            self.assertEqual(main_llm.calls, 0)
            self.assertEqual(low_llm.calls, 1)
            self.assertEqual([document.path.name for document in documents], ["feedback_db_no_mocks.md"])

    async def test_start_relevant_memory_prefetch_falls_back_to_current_llm_without_low_level(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            main_llm = _SelectionOnlyFakeChatModel(selected_memories=["feedback_db_no_mocks.md"])
            template = Agent(
                llm=main_llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            runtime._runtime_state.llm_levels = None

            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            prefetch = start_relevant_memory_prefetch(runtime, "database integration tests guidance")
            assert prefetch is not None
            documents = await prefetch.task

            self.assertEqual(main_llm.calls, 1)
            self.assertEqual([document.path.name for document in documents], ["feedback_db_no_mocks.md"])

    def test_render_relevant_memory_reminder_includes_freshness(self) -> None:
        now = datetime.now(timezone.utc)
        documents = [
            SurfacedMemoryDocument(
                path=Path("/tmp/recent.md"),
                content="recent memory",
                mtime_ms=now.timestamp() * 1000,
                truncated=False,
                byte_count=len("recent memory".encode("utf-8")),
            ),
            SurfacedMemoryDocument(
                path=Path("/tmp/yesterday.md"),
                content="yesterday memory",
                mtime_ms=(now - timedelta(days=1, minutes=5)).timestamp() * 1000,
                truncated=False,
                byte_count=len("yesterday memory".encode("utf-8")),
            ),
            SurfacedMemoryDocument(
                path=Path("/tmp/older.md"),
                content="older memory",
                mtime_ms=(now - timedelta(days=3, minutes=5)).timestamp() * 1000,
                truncated=False,
                byte_count=len("older memory".encode("utf-8")),
            ),
        ]

        rendered = _render_relevant_memory_reminder(documents)

        self.assertIn("<system-reminder>", rendered)
        self.assertIn("Relevant memory surfaced for this turn", rendered)

        # Today: label only, no staleness caveat
        self.assertIn("Memory (saved today): /tmp/recent.md", rendered)

        # Yesterday: label only, no staleness caveat
        self.assertIn("Memory (saved yesterday): /tmp/yesterday.md", rendered)

        # 3 days ago: staleness caveat + label
        self.assertIn("This memory is 3 days old.", rendered)
        self.assertIn("Memories are point-in-time observations, not live state", rendered)
        self.assertIn("Memory (saved 3 days ago): /tmp/older.md", rendered)

        # Fresh memories must NOT have staleness caveat
        # Split rendered by document to check isolation
        recent_section = rendered.split("/tmp/recent.md")[0].split("Relevant memory surfaced")[-1]
        self.assertNotIn("point-in-time observations", recent_section)

    async def test_query_stream_surfaces_relevant_memory_on_followup_iteration_only_once(self) -> None:
        @tool("No-op tool for memory recall test", name="NoOp")
        async def NoOp() -> str:
            await asyncio.sleep(0.1)
            return "ok"

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _MainAndSelectionFakeChatModel()
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(NoOp,),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            events = [event async for event in runtime.query_stream("please help with database integration tests")]

            self.assertEqual([event.reason for event in events if isinstance(event, StopEvent)], ["completed"])
            self.assertEqual(len(llm.main_messages), 2)

            first_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[0]
            )
            second_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[1]
            )
            self.assertNotIn("feedback_db_no_mocks.md", first_call_text)
            self.assertIn("feedback_db_no_mocks.md", second_call_text)

            reminders = [
                item
                for item in runtime._context.get_deferred_items_snapshot()
                if item.item_type == ItemType.DEFERRED_META
                and item.metadata.get("origin") == "relevant_memory"
            ]
            self.assertEqual(len(reminders), 1)
            self.assertEqual(llm.side_query_calls, 1)

    async def test_memory_not_injected_before_first_llm_even_if_prefetch_complete(self) -> None:
        """G1: 即使 prefetch 在首轮 LLM 前就完成，memory 也不注入到首轮；仅在工具执行后注入。

        确定性机制：patch precheck_and_compact 加入 asyncio.sleep(0)，保证 prefetch task
        在 consume_ready_relevant_memory_prefetch 调用前已经完成（task.done() == True）。
        当前代码（consume 在 LLM 前）会把已完成的 prefetch 注入到首轮，导致 assertNotIn 失败。
        """

        @tool("No-op tool for G1 consume position test", name="NoOp")
        async def NoOp() -> str:
            return "ok"

        async def _yielding_precheck_and_compact(agent):  # type: ignore[no-untyped-def]
            # yield 一次，让 prefetch task 有机会在 consume 调用前完成
            await asyncio.sleep(0)
            return False, None, []

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _ImmediateSelectorMainModel()
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(NoOp,),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            runtime._memory_extraction_enabled = False  # 避免后台 extraction task 干扰 ainvoke 计数
            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            with patch(
                "comate_agent_sdk.agent.runner_engine.compaction.precheck_and_compact",
                side_effect=_yielding_precheck_and_compact,
            ):
                events = [event async for event in runtime.query_stream("please help with database integration tests")]

            self.assertEqual([event.reason for event in events if isinstance(event, StopEvent)], ["completed"])
            self.assertEqual(len(llm.main_messages), 2)

            first_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[0]
            )
            second_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[1]
            )
            # 关键断言：首轮 LLM 调用绝对不含 memory（即使 prefetch 已完成）
            self.assertNotIn("feedback_db_no_mocks.md", first_call_text)
            # 工具执行后的第二轮 LLM 调用必须含 memory
            self.assertIn("feedback_db_no_mocks.md", second_call_text)

    async def test_query_stream_consumes_ready_memory_before_followup_llm(self) -> None:
        @tool("No-op tool for followup consume timing test", name="NoOp")
        async def NoOp() -> str:
            return "ok"

        release_event = asyncio.Event()
        precheck_calls = 0

        async def _precheck_and_release(agent):  # type: ignore[no-untyped-def]
            nonlocal precheck_calls
            precheck_calls += 1
            if precheck_calls == 2:
                release_event.set()
                await asyncio.sleep(0)
            return False, None, []

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            llm = _BlockedSelectorFollowupModel(release_event=release_event)
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(NoOp,),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )
            runtime = template.create_runtime(cwd=root, session_id="s1")
            runtime._memory_extraction_enabled = False
            memory_dir = resolve_auto_memory_dir(runtime)
            (memory_dir / "feedback_db_no_mocks.md").write_text(
                "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                "Don't mock the database in integration tests.\n",
                encoding="utf-8",
            )

            with patch(
                "comate_agent_sdk.agent.runner_engine.compaction.precheck_and_compact",
                side_effect=_precheck_and_release,
            ):
                events = [event async for event in runtime.query_stream("please help with database integration tests")]

            self.assertEqual([event.reason for event in events if isinstance(event, StopEvent)], ["completed"])
            self.assertEqual(len(llm.main_messages), 2)

            first_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[0]
            )
            second_call_text = "\n".join(
                getattr(message, "text", str(getattr(message, "content", "")))
                for message in llm.main_messages[1]
            )
            self.assertNotIn("feedback_db_no_mocks.md", first_call_text)
            self.assertIn("feedback_db_no_mocks.md", second_call_text)

            deferred_items = [
                item
                for item in runtime._context.get_deferred_items_snapshot()
                if item.item_type == ItemType.DEFERRED_META
                and item.metadata.get("origin") == "relevant_memory"
            ]
            self.assertEqual(len(deferred_items), 1)
            self.assertEqual(llm.side_query_calls, 1)


class TestMemoryAgeDays(unittest.TestCase):
    def test_today_returns_zero(self) -> None:
        now_ms = datetime.now(timezone.utc).timestamp() * 1000
        self.assertEqual(_memory_age_days(now_ms), 0)

    def test_yesterday_returns_one(self) -> None:
        yesterday_ms = (datetime.now(timezone.utc) - timedelta(days=1, minutes=5)).timestamp() * 1000
        self.assertEqual(_memory_age_days(yesterday_ms), 1)

    def test_three_days_ago(self) -> None:
        older_ms = (datetime.now(timezone.utc) - timedelta(days=3, minutes=5)).timestamp() * 1000
        self.assertEqual(_memory_age_days(older_ms), 3)

    def test_future_clamps_to_zero(self) -> None:
        future_ms = (datetime.now(timezone.utc) + timedelta(days=1)).timestamp() * 1000
        self.assertEqual(_memory_age_days(future_ms), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
