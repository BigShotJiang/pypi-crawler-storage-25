from __future__ import annotations

import json
import tempfile
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.memory_runtime import start_relevant_memory_prefetch
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.agent.setup import setup_memory_usage
from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import SystemMessage, UserMessage


class _NoopChatModel:
    model = "fake:noop"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


def _fake_agent(enabled: bool, tmpdir: Path):
    class A:
        _memory_extraction_enabled = enabled
        _context = ContextIR()

        def _resolve_memory_usage_prompt(self) -> str:
            return "MEMORY_USAGE_BODY"

    agent = A()
    agent._runtime_state = type("S", (), {"cwd": str(tmpdir)})()
    setattr(agent, "_shared_auto_memory_dir", tmpdir)
    return agent


def test_memory_extraction_disabled_skips_injection() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        agent = _fake_agent(enabled=False, tmpdir=Path(tmp))
        setup_memory_usage(agent)  # type: ignore[arg-type]
        assert agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE) is None


def test_memory_extraction_enabled_injects_memory_usage() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        agent = _fake_agent(enabled=True, tmpdir=Path(tmp))
        setup_memory_usage(agent)  # type: ignore[arg-type]
        item = agent._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
        assert item is not None
        assert "MEMORY_USAGE_BODY" in item.content_text


def _assert_no_memory_prompt_or_meta_messages(runtime) -> None:  # type: ignore[no-untyped-def]
    messages = runtime._context.lower()
    system_text = "\n".join(
        str(message.content)
        for message in messages
        if isinstance(message, SystemMessage)
    )
    meta_user_text = "\n".join(
        str(message.content)
        for message in messages
        if isinstance(message, UserMessage) and bool(getattr(message, "is_meta", False))
    )

    assert "<memory_usage>" not in system_text
    assert "feedback_db_no_mocks.md" not in system_text
    assert "integration tests must hit real database" not in system_text
    assert "feedback_db_no_mocks.md" not in meta_user_text
    assert "integration tests must hit real database" not in meta_user_text
    assert "Memory (saved" not in meta_user_text


def test_agent_options_memory_background_disabled_skips_prompt_and_meta_memory() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        template = Agent(
            llm=_NoopChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                cwd=root,
                offload_enabled=False,
                setting_sources=None,
                memory_background_enabled=False,
            ),
        )
        runtime = template.create_runtime(cwd=root, session_id="s1")
        memory_dir = resolve_auto_memory_dir(runtime)
        memory_dir.mkdir(parents=True, exist_ok=True)
        (memory_dir / "feedback_db_no_mocks.md").write_text(
            "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
            "Don't mock the database in integration tests.\n",
            encoding="utf-8",
        )

        prefetch = start_relevant_memory_prefetch(
            runtime,
            "database integration tests guidance",
        )

        assert prefetch is None
        _assert_no_memory_prompt_or_meta_messages(runtime)


def test_settings_memory_background_disabled_skips_prompt_and_meta_memory() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        agent_dir = root / ".agent"
        agent_dir.mkdir()
        (agent_dir / "settings.json").write_text(
            json.dumps(
                {
                    "env": {
                        "COMATE_AGENT_SDK_MEMORY_BACKGROUND_ENABLED": "false",
                    },
                }
            ),
            encoding="utf-8",
        )
        template = Agent(
            llm=_NoopChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                cwd=root,
                offload_enabled=False,
                setting_sources=("project",),
            ),
        )
        runtime = template.create_runtime(cwd=root, session_id="s1")
        memory_dir = resolve_auto_memory_dir(runtime)
        memory_dir.mkdir(parents=True, exist_ok=True)
        (memory_dir / "feedback_db_no_mocks.md").write_text(
            "---\nname: feedback_db_no_mocks\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
            "Don't mock the database in integration tests.\n",
            encoding="utf-8",
        )

        prefetch = start_relevant_memory_prefetch(
            runtime,
            "database integration tests guidance",
        )

        assert prefetch is None
        _assert_no_memory_prompt_or_meta_messages(runtime)
