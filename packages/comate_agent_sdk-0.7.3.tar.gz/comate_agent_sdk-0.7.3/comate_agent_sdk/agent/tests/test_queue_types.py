from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
import sys
from types import MappingProxyType

import pytest


def test_message_origin_values_are_stable_strings() -> None:
	from comate_agent_sdk.agent.queue_types import MessageOrigin

	assert MessageOrigin.HUMAN == "human"
	assert MessageOrigin.EXTERNAL == "external"
	assert MessageOrigin.COORDINATOR == "coordinator"
	assert MessageOrigin.TASK_NOTIFICATION == "task_notification"


def test_queued_message_is_frozen_and_preserves_metadata() -> None:
	from comate_agent_sdk.agent.queue_types import MessageOrigin, QueuedMessage

	metadata = MappingProxyType({"server": "slack"})
	message = QueuedMessage(
		message_id="msg-1",
		content="hello",
		origin=MessageOrigin.EXTERNAL,
		enqueued_at=datetime(2026, 4, 28, tzinfo=UTC),
		origin_metadata=metadata,
	)

	assert message.message_id == "msg-1"
	assert message.content == "hello"
	assert message.origin is MessageOrigin.EXTERNAL
	assert message.origin_metadata is metadata
	with pytest.raises(FrozenInstanceError):
		message.message_id = "msg-2"  # type: ignore[misc]


def test_queue_types_do_not_import_chat_session_at_runtime() -> None:
	queue_types_module = sys.modules.pop("comate_agent_sdk.agent.queue_types", None)
	chat_session_module = sys.modules.pop("comate_agent_sdk.agent.chat_session", None)
	try:
		import comate_agent_sdk.agent.queue_types  # noqa: F401

		assert "comate_agent_sdk.agent.chat_session" not in sys.modules
	finally:
		sys.modules.pop("comate_agent_sdk.agent.queue_types", None)
		if queue_types_module is not None:
			sys.modules["comate_agent_sdk.agent.queue_types"] = queue_types_module
		if chat_session_module is not None:
			sys.modules["comate_agent_sdk.agent.chat_session"] = chat_session_module
