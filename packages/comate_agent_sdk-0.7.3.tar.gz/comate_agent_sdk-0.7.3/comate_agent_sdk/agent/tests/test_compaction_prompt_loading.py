def test_summary_prompt_loaded_from_markdown():
    from comate_agent_sdk.agent.compaction.service import CompactionService

    service = CompactionService()
    prompt = service._load_summary_system_prompt()

    assert "9 sections" in prompt
    assert "1. Primary Request" in prompt
    assert "9. Optional Next Step" in prompt


def test_legacy_default_constants_removed():
    import comate_agent_sdk.agent.compaction.models as models

    assert not hasattr(models, "DEFAULT_SUMMARY_SYSTEM_PROMPT")
    assert not hasattr(models, "DEFAULT_SUMMARY_PROMPT")
