from __future__ import annotations

import asyncio
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

from comate_agent_sdk.agent.tool_exec import execute_tool_call
from comate_agent_sdk.llm.messages import Function, ToolCall, ToolMessage


def _make_tool_call(name: str, arguments: str = "{}") -> ToolCall:
    return ToolCall(id=f"call-{name}", type="function", function=Function(name=name, arguments=arguments))


def _make_agent() -> MagicMock:
    agent = MagicMock()
    agent.config.dependency_overrides = None
    agent.config.disallowed_tools = []
    agent._tool_map = {}
    agent._runtime_state.tools = []
    agent.tool_definitions = [
        SimpleNamespace(name="Read"),
        SimpleNamespace(name="Write"),
        SimpleNamespace(name="Bash"),
    ]
    agent.run_hook_event = AsyncMock()
    agent._run_controller = None
    return agent


def _make_tool(name: str, *, result: str = "ok", call_log: list[str] | None = None):
    tool = MagicMock()
    tool.name = name
    tool.definition.parameters = {"type": "object", "properties": {}, "required": []}

    async def _execute(_overrides=None, **kwargs):
        del _overrides, kwargs
        if call_log is not None:
            call_log.append(name)
        return result

    tool.execute = _execute
    return tool


@contextmanager
def _stub_tool_exec_internals(tool_message: ToolMessage):
    @contextmanager
    def _fake_bind(**_kw):
        yield

    with (
        patch("comate_agent_sdk.agent.tool_exec._resolve_system_tool_context_kwargs", return_value={"project_root": "/tmp"}),
        patch("comate_agent_sdk.tools.system_context.bind_system_tool_context", _fake_bind),
        patch("comate_agent_sdk.agent.tool_exec._run_pre_tool_pipeline", new_callable=AsyncMock, return_value=({}, None)),
        patch("comate_agent_sdk.agent.tool_exec._build_tool_result_message", return_value=tool_message),
        patch("comate_agent_sdk.agent.tool_exec._set_span_output"),
        patch("comate_agent_sdk.agent.tool_exec._record_tool_result"),
        patch("comate_agent_sdk.agent.tool_exec.Laminar", None),
    ):
        yield


def test_allowed_tools_absent_keeps_existing_behavior() -> None:
    async def _run() -> ToolMessage:
        agent = _make_agent()
        agent._tool_map = {"Read": _make_tool("Read")}
        success = ToolMessage(tool_call_id="call-Read", tool_name="Read", content="ok", is_error=False)
        with _stub_tool_exec_internals(success):
            return await execute_tool_call(agent, _make_tool_call("Read"))

    result = asyncio.run(_run())

    assert result.is_error is False
    assert result.tool_name == "Read"


def test_allowed_tools_rejects_non_whitelisted_tool_before_execution() -> None:
    call_log: list[str] = []

    async def _run() -> ToolMessage:
        agent = _make_agent()
        agent._allowed_tools = {"Read", "Write"}
        agent._tool_map = {
            "Read": _make_tool("Read", call_log=call_log),
            "Write": _make_tool("Write", call_log=call_log),
            "Bash": _make_tool("Bash", call_log=call_log),
        }
        success = ToolMessage(tool_call_id="call-Read", tool_name="Read", content="ok", is_error=False)
        with _stub_tool_exec_internals(success):
            return await execute_tool_call(agent, _make_tool_call("Bash"))

    result = asyncio.run(_run())

    assert result.is_error is True
    assert result.tool_name == "Bash"
    assert "not allowed" in result.text
    assert "Available tools: Read, Write" in result.text
    assert call_log == []


def test_allowed_tools_permits_whitelisted_tools() -> None:
    call_log: list[str] = []

    async def _run() -> tuple[ToolMessage, ToolMessage]:
        agent = _make_agent()
        agent._allowed_tools = {"Read", "Write"}
        agent._tool_map = {
            "Read": _make_tool("Read", call_log=call_log),
            "Write": _make_tool("Write", call_log=call_log),
        }
        read_success = ToolMessage(tool_call_id="call-Read", tool_name="Read", content="ok", is_error=False)
        write_success = ToolMessage(tool_call_id="call-Write", tool_name="Write", content="ok", is_error=False)
        with _stub_tool_exec_internals(read_success):
            read_result = await execute_tool_call(agent, _make_tool_call("Read"))
        with _stub_tool_exec_internals(write_success):
            write_result = await execute_tool_call(agent, _make_tool_call("Write"))
        return read_result, write_result

    read_result, write_result = asyncio.run(_run())

    assert read_result.is_error is False
    assert write_result.is_error is False
    assert call_log == ["Read", "Write"]


def test_allowed_tools_does_not_mutate_tool_definitions() -> None:
    async def _run() -> tuple[ToolMessage, list[str]]:
        agent = _make_agent()
        agent._allowed_tools = {"Read"}
        agent._tool_map = {"Read": _make_tool("Read")}
        schema_before = [definition.name for definition in agent.tool_definitions]
        success = ToolMessage(tool_call_id="call-Read", tool_name="Read", content="ok", is_error=False)
        with _stub_tool_exec_internals(success):
            result = await execute_tool_call(agent, _make_tool_call("Bash"))
        schema_after = [definition.name for definition in agent.tool_definitions]
        return result, [*schema_before, "|", *schema_after]

    result, schema_names = asyncio.run(_run())

    assert result.is_error is True
    assert schema_names == ["Read", "Write", "Bash", "|", "Read", "Write", "Bash"]


def test_disallowed_tools_still_takes_precedence_over_allowed_tools() -> None:
    async def _run() -> ToolMessage:
        agent = _make_agent()
        agent._allowed_tools = {"Read"}
        agent.config.disallowed_tools = ["Read"]
        agent._tool_map = {"Read": _make_tool("Read")}
        success = ToolMessage(tool_call_id="call-Read", tool_name="Read", content="ok", is_error=False)
        with _stub_tool_exec_internals(success):
            return await execute_tool_call(agent, _make_tool_call("Read"))

    result = asyncio.run(_run())

    assert result.is_error is True
    assert "disallowed" in result.text
