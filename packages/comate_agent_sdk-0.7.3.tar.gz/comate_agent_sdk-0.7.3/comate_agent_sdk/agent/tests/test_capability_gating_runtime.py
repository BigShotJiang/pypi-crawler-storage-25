from __future__ import annotations

import tempfile
from dataclasses import replace
from pathlib import Path

import pytest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.subagent.models import AgentDefinition


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        return ChatInvokeCompletion(content="ok")


def _agent_def() -> AgentDefinition:
    return AgentDefinition(name="researcher", description="r", prompt="p")


def _skill_def() -> SkillDefinition:
    return SkillDefinition(name="demo", description="d", prompt="p")


def _create_runtime(config: AgentConfig):
    with tempfile.TemporaryDirectory() as tmp:
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=replace(
                config,
                cwd=Path(tmp),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        return template.create_runtime()


def test_allowlist_agent_sentinel_without_agents_fails_fast() -> None:
    with pytest.raises(ValueError, match="Agent capability"):
        _create_runtime(AgentConfig(tools=("Agent",), agents=()))


def test_allowlist_skill_sentinel_without_skills_fails_fast(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("comate_agent_sdk.skill.discover_skills", lambda project_root=None: [])
    with pytest.raises(ValueError, match="Skill capability"):
        _create_runtime(AgentConfig(tools=("Skill",), skills=()))


def test_explicit_agents_present_but_agent_not_requested_fails_fast() -> None:
    with pytest.raises(ValueError, match="Agent capability"):
        _create_runtime(AgentConfig(tools=(), agents=(_agent_def(),)))


def test_explicit_skills_present_but_skill_not_requested_fails_fast() -> None:
    with pytest.raises(ValueError, match="Skill capability"):
        _create_runtime(AgentConfig(tools=(), skills=(_skill_def(),)))


def test_auto_builtin_agents_without_agent_sentinel_do_not_fail_and_do_not_create_agent_tool() -> None:
    runtime = _create_runtime(AgentConfig(tools=("Read",), agents=None))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Read" in tool_names
    assert "Agent" not in tool_names


def test_tools_none_with_agents_allows_agent_capability() -> None:
    runtime = _create_runtime(AgentConfig(tools=None, agents=(_agent_def(),)))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Agent" in tool_names


def test_tools_none_with_skills_allows_skill_capability() -> None:
    runtime = _create_runtime(AgentConfig(tools=None, skills=(_skill_def(),)))
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Skill" in tool_names


def test_tools_none_with_only_builtin_skillify_does_not_create_model_skill_tool(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("comate_agent_sdk.skill.discover_skills", lambda project_root=None: [])

    runtime = _create_runtime(AgentConfig(tools=None, skills=None))

    skill_names = {skill.name for skill in runtime._runtime_state.skills or []}
    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "skillify" in skill_names
    assert "Skill" not in tool_names
    assert runtime._context.header.find_one_by_type(ItemType.SKILL_STRATEGY) is None
    assert runtime._context.session_state.find_one_by_type(ItemType.SKILL_LISTING) is None


def test_tools_none_with_builtin_skillify_and_normal_skill_creates_model_skill_tool(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("comate_agent_sdk.skill.discover_skills", lambda project_root=None: [])

    runtime = _create_runtime(AgentConfig(tools=None, skills=(_skill_def(),)))

    tool_names = {t.name for t in runtime._runtime_state.tools}
    assert "Skill" in tool_names
    listing = runtime._context.session_state.find_one_by_type(ItemType.SKILL_LISTING)
    assert listing is not None
    assert "- demo:" in listing.content_text
    assert "- skillify:" not in listing.content_text


def test_allowlist_skill_sentinel_with_only_user_only_builtin_fails_fast(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("comate_agent_sdk.skill.discover_skills", lambda project_root=None: [])

    with pytest.raises(ValueError, match="model-invocable|模型可调用"):
        _create_runtime(AgentConfig(tools=("Skill",), skills=None))


def test_user_configured_skill_cannot_override_builtin_skillify() -> None:
    with pytest.raises(ValueError, match="skillify"):
        _create_runtime(
            AgentConfig(
                tools=None,
                skills=(SkillDefinition(name="skillify", description="d", prompt="p"),),
            )
        )


def test_discovered_skill_cannot_override_builtin_skillify() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        skill_dir = root / ".agent" / "skills" / "skillify"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: skillify\ndescription: conflict\n---\n\nPrompt.",
            encoding="utf-8",
        )

        with pytest.raises(ValueError, match="skillify"):
            Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    cwd=root,
                    offload_enabled=False,
                    setting_sources=None,
                ),
            )


def test_disallowed_agent_conflict_fails_fast() -> None:
    with pytest.raises(ValueError, match="disallowed_tools"):
        _create_runtime(
            AgentConfig(
                tools=("Agent",),
                agents=(_agent_def(),),
                disallowed_tools=("Agent",),
            )
        )


def test_disallowed_skill_conflict_fails_fast() -> None:
    with pytest.raises(ValueError, match="disallowed_tools"):
        _create_runtime(
            AgentConfig(
                tools=("Skill",),
                skills=(_skill_def(),),
                disallowed_tools=("Skill",),
            )
        )
