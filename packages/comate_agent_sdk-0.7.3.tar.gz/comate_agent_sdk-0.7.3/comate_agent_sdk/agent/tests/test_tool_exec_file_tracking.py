import json
import unittest
from pathlib import Path
from types import SimpleNamespace

from comate_agent_sdk.agent.tool_exec import execute_tool_call
from comate_agent_sdk.context.file_track import FileTrackState
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools import tool


class _FakeAgent:
    def __init__(self, tools) -> None:
        self._tool_map = {tool_obj.name: tool_obj for tool_obj in tools}
        self.config = SimpleNamespace(
            dependency_overrides={},
            permission_mode="default",
            tool_approval_callback=None,
            disallowed_tools=None,
            add_dirs=None,
            env=None,
        )
        self._runtime_state = SimpleNamespace(
            cwd=Path.cwd(),
            llm_levels=None,
            tool_approval_callback=None,
            skills=None,
        )
        self._session_id = "s_test"
        self.name = None
        self._is_subagent = False
        self._subagent_source_prefix = None
        self._token_cost = None
        self._context = None
        self._file_track_state = FileTrackState()

    async def run_hook_event(self, event_name: str, **kwargs):  # type: ignore[no-untyped-def]
        return None

    def add_hidden_user_message(self, content: str) -> None:
        _ = content


def _call(name: str, file_path: str = "/tmp/a.py") -> ToolCall:
    return ToolCall(
        id=f"call-{name}",
        type="function",
        function=Function(
            name=name,
            arguments=json.dumps({"file_path": file_path}, ensure_ascii=False),
        ),
    )


@tool("Read tool for file tracking tests", name="Read")
async def _Read(file_path: str) -> dict:
    return ok(data={"content": "read-content"}, meta={"resolved_file_path": file_path})


@tool("Edit tool for file tracking tests", name="Edit")
async def _Edit(file_path: str) -> dict:
    return ok(data={"content": "edit-content"}, meta={"resolved_file_path": file_path})


@tool("Write tool for file tracking tests", name="Write")
async def _Write(file_path: str) -> dict:
    return ok(data={"content": "write-content"}, meta={"resolved_file_path": file_path})


@tool("Bash tool for file tracking tests", name="Bash")
async def _Bash(command: str) -> str:
    return command


@tool("Read tool that returns a resolved path", name="Read")
async def _ReadResolved(file_path: str) -> dict:
    return ok(
        data={"content": "read-content"},
        meta={"resolved_file_path": f"{file_path}.resolved"},
    )


@tool("Read tool that fails", name="Read")
async def _ReadFailed(file_path: str) -> dict:
    return err("READ_FAILED", f"failed to read {file_path}")


class TestToolExecFileTracking(unittest.IsolatedAsyncioTestCase):
    async def test_execute_tool_call_records_read_edit_write_success(self) -> None:
        agent = _FakeAgent([_Read, _Edit, _Write])

        await execute_tool_call(agent, _call("Read", "/tmp/a.py"))
        await execute_tool_call(agent, _call("Edit", "/tmp/b.py"))
        await execute_tool_call(agent, _call("Write", "/tmp/c.py"))

        touches = {touch.path: touch.last_op for touch in agent._file_track_state.recent(10)}
        self.assertEqual(touches["/tmp/a.py"], "read")
        self.assertEqual(touches["/tmp/b.py"], "edit")
        self.assertEqual(touches["/tmp/c.py"], "write")

    async def test_execute_tool_call_prefers_resolved_file_path_from_envelope(self) -> None:
        agent = _FakeAgent([_ReadResolved])

        await execute_tool_call(agent, _call("Read", "relative.py"))

        touches = {touch.path: touch.last_op for touch in agent._file_track_state.recent(10)}
        self.assertEqual(touches["relative.py.resolved"], "read")
        self.assertNotIn("relative.py", touches)

    async def test_execute_tool_call_does_not_track_other_tools(self) -> None:
        agent = _FakeAgent([_Bash])
        tool_call = ToolCall(
            id="call-Bash",
            type="function",
            function=Function(
                name="Bash",
                arguments=json.dumps({"command": "ls"}, ensure_ascii=False),
            ),
        )

        await execute_tool_call(agent, tool_call)

        self.assertEqual(agent._file_track_state.recent(10), [])

    async def test_execute_tool_call_does_not_track_failed_tool(self) -> None:
        agent = _FakeAgent([_ReadFailed])

        result = await execute_tool_call(agent, _call("Read", "/tmp/a.py"))

        self.assertTrue(result.is_error)
        self.assertEqual(agent._file_track_state.recent(10), [])
