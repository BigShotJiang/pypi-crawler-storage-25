from __future__ import annotations

from pathlib import Path

from comate_agent_sdk.agent.memory_extract import render_memory_extraction_prompt
from comate_agent_sdk.agent.system_prompt import resolve_memory_usage_prompt


def test_memory_usage_prompt_marks_topic_files_as_canonical_memory() -> None:
    prompt = resolve_memory_usage_prompt("/tmp/project-memory")

    assert "# auto memory" in prompt
    assert "This directory already exists" in prompt
    assert "There are several discrete types of memory that you can store in your memory system" in prompt
    assert "<name>user</name>" in prompt
    assert "<name>feedback</name>" in prompt
    assert "<name>project</name>" in prompt
    assert "<name>reference</name>" in prompt
    assert "Record from failure AND success" in prompt
    assert "<body_structure>" in prompt
    assert "Write each memory to its own file" in prompt
    assert "description: {{one-line description — used to decide relevance in future conversations" in prompt
    assert "## Before recommending from memory" in prompt
    assert "The memory says X exists" in prompt
    assert "## How to search memories" not in prompt
    assert "## Manual memory access" not in prompt
    assert "## Searching past context" not in prompt
    assert "MEMORY.md" not in prompt
    assert "{{MEMORY_DIR_PATH}}" not in prompt
    assert f"{Path('/tmp/project-memory').resolve().as_posix()}/" in prompt


def test_memory_extraction_prompt_includes_quality_guardrails() -> None:
    prompt = render_memory_extraction_prompt(
        memory_dir=Path("/tmp/project-memory"),
        new_message_count=2,
        conversation_slice="USER: The user prefers terse responses.\nASSISTANT: Acknowledged.",
        existing_memories="- [feedback] feedback_style.md (2026-04-14T00:00:00Z): user prefers terse responses",
    )

    assert "Update an existing topic file instead of creating a duplicate." in prompt
    assert "Read" in prompt
    assert "Grep" in prompt
    assert "Glob" in prompt
    assert "Bash" in prompt
    assert "Write" in prompt
    assert "Edit" in prompt
    assert "External system locations belong in `reference` memory." in prompt
    assert "Do not save code structure, file paths, or architecture snapshots." in prompt
    assert "Do not save information inferred from source code, search results, shell output, or git history." in prompt
    assert "Automatic extraction only creates or updates topic files. Do not delete memories and do not touch `MEMORY.md`." in prompt
    assert "Analyze only the recent 2 message(s) above" in prompt
    assert "If those messages are vague or low-value, do not write any memory." in prompt
    assert "The user prefers terse responses." not in prompt
