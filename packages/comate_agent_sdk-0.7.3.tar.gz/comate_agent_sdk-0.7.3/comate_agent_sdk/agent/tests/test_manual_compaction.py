from __future__ import annotations

import asyncio
import time
import unittest
from pathlib import Path
from types import SimpleNamespace

from comate_agent_sdk.agent.compaction import CompactionService
from comate_agent_sdk.agent.runner_engine.compaction import manual_compact_context
from comate_agent_sdk.context.env import EnvOptions
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import AssistantMessage, UserMessage


class _FakeSummaryLLM:
    model = "fake-summary-model"

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        del messages, tools, tool_choice
        return SimpleNamespace(
            content="<summary>manual compact summary</summary>",
            usage=None,
            stop_reason="end_turn",
            thinking=None,
        )


class _Tracker:
    def __init__(self) -> None:
        self.reset_calls = 0

    def reset_after_compaction(self) -> None:
        self.reset_calls += 1


class TestManualCompaction(unittest.TestCase):
    def _build_agent(self) -> SimpleNamespace:
        context = ContextIR()
        for idx in range(16):
            user_text = ("old context " * 10_000) if idx == 0 else f"hello-{idx}"
            context.add_message(UserMessage(content=user_text, is_meta=False))
            context.add_message(AssistantMessage(content=f"answer-{idx}"))
        context.set_skill_listing(
            "The following skills are available for use with the Skill tool:\n\n- demo: d"
        )
        llm = _FakeSummaryLLM()
        tracker = _Tracker()
        service = CompactionService(llm=llm)
        return SimpleNamespace(
            _context=context,
            _compaction_service=service,
            llm=llm,
            _context_usage_tracker=tracker,
            config=SimpleNamespace(
                offload_enabled=False,
                offload_token_threshold=0,
                emit_compaction_meta_events=False,
                env_options=EnvOptions(
                    system_env=True,
                    git_env=False,
                    working_dir=Path.cwd(),
                ),
            ),
            _runtime_state=SimpleNamespace(
                offload_policy=None,
                user_instruction=None,
                cwd=Path.cwd(),
            ),
            _context_fs=None,
            _token_cost=None,
            _effective_level="MID",
            _is_subagent=False,
            name=None,
        )

    def _build_short_agent(self) -> SimpleNamespace:
        agent = self._build_agent()
        agent._context.replace_conversation([
            agent._context.conversation.items[0],
            agent._context.conversation.items[1],
        ])
        agent._context_usage_tracker.reset_calls = 0
        return agent

    def test_manual_compaction_success(self) -> None:
        agent = self._build_agent()
        listing_before = agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING)
        self.assertIsNotNone(listing_before)
        listing_id = listing_before.id
        listing_text = listing_before.content_text

        result = asyncio.run(manual_compact_context(agent))

        listing_after = agent._context.session_state.find_one_by_type(ItemType.SKILL_LISTING)
        self.assertIsNotNone(listing_after)
        self.assertEqual(listing_after.id, listing_id)
        self.assertEqual(listing_after.content_text, listing_text)
        self.assertTrue(result.attempted)
        self.assertTrue(result.compacted)
        self.assertFalse(result.cancelled)
        self.assertGreater(result.tokens_before, 0)
        self.assertGreater(result.tokens_after, 0)
        self.assertEqual(agent._context_usage_tracker.reset_calls, 1)
        self.assertGreaterEqual(len(agent._context.conversation.items), 2)
        self.assertEqual(agent._context.conversation.items[0].item_type, ItemType.COMPACTION_BOUNDARY)
        self.assertEqual(agent._context.conversation.items[1].item_type, ItemType.COMPACTION_SUMMARY)
        self.assertIsNotNone(
            agent._context.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
        )
        self.assertIsNone(
            agent._context.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
        )

    def test_manual_compaction_respects_cooldown(self) -> None:
        agent = self._build_agent()
        agent._summary_compaction_cooldown_until = time.monotonic() + 5.0
        agent._summary_compaction_last_reason = "summary_failed_or_empty"

        result = asyncio.run(manual_compact_context(agent))

        self.assertFalse(result.attempted)
        self.assertFalse(result.compacted)
        self.assertIn("cooldown:", result.reason)
        self.assertEqual(agent._context_usage_tracker.reset_calls, 0)

    def test_manual_compaction_no_op_returns_user_friendly_reason(self) -> None:
        agent = self._build_short_agent()

        result = asyncio.run(manual_compact_context(agent))

        self.assertTrue(result.attempted)
        self.assertFalse(result.compacted)
        self.assertFalse(result.cancelled)
        self.assertIn("There is not enough older conversation to compact yet", result.reason)
        self.assertIn("The context was left unchanged", result.reason)
        self.assertIn(
            "The system keeps the most recent 15 user turns and their related assistant/tool context",
            result.reason,
        )
        self.assertNotIn("partial_compact_no_op", result.reason)
        self.assertTrue(
            any(
                record.get("reason") == "partial_compact_no_op:rounds_insufficient"
                for record in result.meta_records
            )
        )


if __name__ == "__main__":
    unittest.main()
