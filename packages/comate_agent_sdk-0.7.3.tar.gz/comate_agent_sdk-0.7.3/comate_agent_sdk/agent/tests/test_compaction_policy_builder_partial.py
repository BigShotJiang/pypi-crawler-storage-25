from types import SimpleNamespace

from comate_agent_sdk.agent.runner_engine.compaction import _build_compaction_policy
from comate_agent_sdk.context.budget import TokenCounter


def test_build_compaction_policy_injects_partial_compactor_and_trigger():
    async def post_hook(result):
        del result
        return []

    agent = SimpleNamespace(
        config=SimpleNamespace(offload_enabled=False, offload_token_threshold=1_000),
        _context_fs=None,
        _runtime_state=SimpleNamespace(offload_policy=None),
        _compaction_service=SimpleNamespace(llm=None),
        llm=object(),
        _is_subagent=False,
        name=None,
        _token_cost=None,
        _effective_level=None,
        _context=SimpleNamespace(token_counter=TokenCounter()),
        _post_compact_replay_files=post_hook,
    )

    policy = _build_compaction_policy(agent, threshold=1_000, trigger="manual")

    assert policy.compaction_trigger == "manual"
    assert policy._partial_compactor is not None
    assert policy._post_compact_hook is post_hook
    assert policy._partial_compactor.config.min_rounds_to_keep == policy.dialogue_rounds_keep_min
