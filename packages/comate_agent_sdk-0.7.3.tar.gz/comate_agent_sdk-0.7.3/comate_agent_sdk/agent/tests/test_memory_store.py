from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent.memory_store import (
    format_memory_manifest,
    read_memory_document_for_surface,
    scan_memory_headers,
)


class TestMemoryStore(unittest.TestCase):
    def test_scan_memory_headers_excludes_index_and_sorts_by_mtime_desc(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            memory_dir = Path(td)
            (memory_dir / "MEMORY.md").write_text("- @router.md - index\n", encoding="utf-8")

            older = memory_dir / "project_auth.md"
            older.write_text(
                "---\nname: project_auth\ndescription: auth rewrite driven by compliance\ntype: project\n---\nbody\n",
                encoding="utf-8",
            )

            newer = memory_dir / "feedback_testing.md"
            newer.write_text(
                "---\nname: feedback_testing\ndescription: integration tests must hit real database\ntype: feedback\n---\nbody\n",
                encoding="utf-8",
            )

            os.utime(older, (1_700_000_000, 1_700_000_000))
            os.utime(newer, (1_800_000_000, 1_800_000_000))

            headers = scan_memory_headers(memory_dir)

            self.assertEqual([header.filename for header in headers], ["feedback_testing.md", "project_auth.md"])
            self.assertEqual(headers[0].memory_type, "feedback")
            self.assertEqual(headers[0].description, "integration tests must hit real database")

            manifest = format_memory_manifest(headers)
            self.assertTrue(all(line.startswith("- [") for line in manifest.splitlines()))
            self.assertIn("- [feedback] feedback_testing.md", manifest)
            self.assertIn("integration tests must hit real database", manifest)
            self.assertIn("project_auth.md", manifest)
            self.assertNotIn("MEMORY.md", manifest)

    def test_scan_memory_headers_skips_topic_files_without_frontmatter_description(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            memory_dir = Path(td)
            (memory_dir / "feedback_missing_description.md").write_text(
                "---\nname: feedback_missing_description\ntype: feedback\n---\n"
                "This body should not be used as a recall description.\n",
                encoding="utf-8",
            )
            (memory_dir / "feedback_valid.md").write_text(
                "---\nname: feedback_valid\ndescription: user prefers terse responses\ntype: feedback\n---\n"
                "Keep responses concise.\n",
                encoding="utf-8",
            )

            headers = scan_memory_headers(memory_dir)

            self.assertEqual([header.filename for header in headers], ["feedback_valid.md"])
            self.assertEqual(headers[0].description, "user prefers terse responses")

    def test_read_memory_document_for_surface_truncates_body_with_notice(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "feedback_testing.md"
            path.write_text(
                "---\nname: feedback_testing\ndescription: integration tests must hit real database\ntype: feedback\n---\n"
                + ("A" * 200),
                encoding="utf-8",
            )

            document = read_memory_document_for_surface(path, max_bytes=80)

            self.assertEqual(document.path, path.resolve())
            self.assertTrue(document.truncated)
            self.assertIn("feedback_testing", document.content)
            self.assertIn("truncated", document.content.lower())

    def test_scan_memory_headers_recursive_finds_subdir_files(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            memory_dir = Path(td)
            subdir = memory_dir / "project-a"
            subdir.mkdir()
            (subdir / "api.md").write_text(
                "---\ndescription: project a api docs\ntype: reference\n---\nbody\n",
                encoding="utf-8",
            )

            headers = scan_memory_headers(memory_dir)

            self.assertEqual(len(headers), 1)
            self.assertEqual(Path(headers[0].filename), Path("project-a") / "api.md")

    def test_scan_memory_headers_excludes_subdir_memory_md(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            memory_dir = Path(td)
            subdir = memory_dir / "project-a"
            subdir.mkdir()
            (subdir / "MEMORY.md").write_text(
                "---\ndescription: should be excluded\ntype: reference\n---\nbody\n",
                encoding="utf-8",
            )
            (subdir / "valid.md").write_text(
                "---\ndescription: valid memory in subdir\ntype: feedback\n---\nbody\n",
                encoding="utf-8",
            )

            headers = scan_memory_headers(memory_dir)
            filenames = [h.filename for h in headers]

            self.assertEqual([Path(f) for f in filenames], [Path("project-a") / "valid.md"])

    def test_read_memory_document_truncates_by_lines_with_hint(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "big.md"
            # 写 201 行，每行约 10 字节，总大小远小于 4096B
            lines = [f"line {i:03d}" for i in range(201)]
            path.write_text("\n".join(lines), encoding="utf-8")

            document = read_memory_document_for_surface(path)

            self.assertTrue(document.truncated)
            # 第 201 行不应出现在截断内容中
            self.assertNotIn("line 200", document.content)
            # 截断提示应包含 "truncated" 和文件绝对路径
            self.assertIn("truncated", document.content.lower())
            self.assertIn(path.resolve().as_posix(), document.content)

    def test_read_memory_document_no_truncation_when_within_limits(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "small.md"
            # 100 行，每行 5 字节，总大小远小于 4096B
            lines = [f"l{i:03d}" for i in range(100)]
            path.write_text("\n".join(lines), encoding="utf-8")

            document = read_memory_document_for_surface(path)

            self.assertFalse(document.truncated)
            self.assertNotIn("truncated", document.content.lower())
            self.assertIn("l099", document.content)


if __name__ == "__main__":
    unittest.main(verbosity=2)
