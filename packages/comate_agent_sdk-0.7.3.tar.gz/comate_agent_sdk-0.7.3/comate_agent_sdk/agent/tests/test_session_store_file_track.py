from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession


class FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):
        raise AssertionError("file track persistence tests must not call the LLM")


def make_agent() -> Agent:
    return Agent(
        llm=FakeChatModel(),
        config=AgentConfig(
            tools=(),
            agents=(),
            offload_enabled=False,
            setting_sources=None,
        ),
    )


def build_chat_session_with_store(tmp_path, session_id: str = "s1") -> ChatSession:
    session = ChatSession(make_agent(), session_id=session_id, cwd=tmp_path)
    session._ensure_header_persisted()
    return session


def test_file_track_snapshot_event_roundtrip(tmp_path):
    from comate_agent_sdk.agent.session_store import (
        PERSISTENCE_SCHEMA_VERSION,
        build_file_track_state_event,
        events_jsonl_append,
        replay_file_track_state_snapshot,
    )
    from comate_agent_sdk.context.file_track import FileTrackState

    path = tmp_path / "context.jsonl"
    state = FileTrackState()
    state.record("/a.py", "read")
    state.record("/b.py", "edit")

    event = build_file_track_state_event(
        session_id="s1",
        turn_number=3,
        state=state,
    )
    assert event["schema_version"] == PERSISTENCE_SCHEMA_VERSION
    assert event["op"] == "file_track_state_snapshot"
    events_jsonl_append(path, event)

    restored = replay_file_track_state_snapshot(path=path)
    assert restored is not None
    assert {touch.path for touch in restored.recent(10)} == {"/a.py", "/b.py"}


def test_file_track_state_persisted_across_resume(tmp_path):
    sess1 = build_chat_session_with_store(tmp_path)
    sess1._agent._file_track_state.record("/x.py", "read")
    sess1._persist_file_track_state_if_dirty()

    sess2 = ChatSession.resume(make_agent(), session_id=sess1.session_id, cwd=tmp_path)

    assert "/x.py" in {touch.path for touch in sess2._agent._file_track_state.recent(10)}


def test_clear_history_clears_file_track_state_and_persists_empty_snapshot(tmp_path):
    sess = build_chat_session_with_store(tmp_path)
    sess._agent._file_track_state.record("/x.py", "read")
    sess._persist_file_track_state_if_dirty()

    sess.clear_history()

    assert sess._agent._file_track_state.recent(10) == []
    resumed = ChatSession.resume(make_agent(), session_id=sess.session_id, cwd=tmp_path)
    assert resumed._agent._file_track_state.recent(10) == []


def test_restore_conversation_to_turn_restores_file_track_snapshot_at_target_turn(tmp_path):
    sess = build_chat_session_with_store(tmp_path)
    sess._turn_number = 1
    sess._agent._file_track_state.record("/old.py", "read")
    sess._persist_file_track_state_if_dirty()

    sess._turn_number = 2
    sess._agent._file_track_state.record("/future.py", "write")
    sess._persist_file_track_state_if_dirty()

    sess.restore_conversation_to_turn(target_turn=1)

    paths = {touch.path for touch in sess._agent._file_track_state.recent(10)}
    assert "/old.py" in paths
    assert "/future.py" not in paths
