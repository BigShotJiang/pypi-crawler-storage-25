# Skillify

{{USER_DESCRIPTION_BLOCK}}

You are capturing this session's repeatable process as a reusable SDK skill.

## Session Context

Session memory:

<session_memory>
{{SESSION_MEMORY}}
</session_memory>

User messages after the latest compact boundary:

<user_messages>
{{USER_MESSAGES}}
</user_messages>

## Task

### Step 1: Analyze Before Asking

Before asking any questions, analyze the session and identify:

- The repeatable process that was performed
- The inputs or parameters someone would need to provide
- The steps in order
- The success criteria and artifacts for each step
- Places where the user corrected or steered the process
- Tools that were needed
- Whether any steps can safely run concurrently

### Step 2: Interview The User

Use `AskUserQuestion` for every question. Do not ask plain-text questions.

Run a concise multi-round interview and stop once you have enough information.

Round 1:

- Suggest a skill name and one-line description.
- Ask the user to confirm or rename the skill.
- Suggest the high-level goal and concrete success criteria.

Round 2:

- Present the high-level steps as a numbered list.
- Suggest arguments if the skill needs parameters.
- Ask where to save the skill. Recommend project scope by default:
  - This repo: `{{DEFAULT_PROJECT_SKILL_PATH}}`
  - Personal: `{{PERSONAL_SKILL_PATH}}`

Round 3:

- For each major step, confirm outputs, success criteria, artifacts, checkpoints, and hard rules.
- Ask whether any independent steps should run concurrently.
- Ask whether any step requires a human checkpoint before irreversible or high-risk actions.

Round 4:

- Confirm when this skill should be invoked.
- Suggest trigger phrases and example user messages.
- Ask for any gotchas only if they are still unclear.

### Step 3: Draft SKILL.md

Draft a single `SKILL.md` using only SDK-supported frontmatter fields:

```markdown
---
name: <skill-name>
description: <one-line description>
when_to_use: <detailed invocation guidance>
argument-hint: "<argument placeholders>"
arguments:
  - <argument_name>
---

# <Skill Title>

## Inputs
- `$argument_name`: Description of this input

## Goal
Clearly state the workflow goal and completion criteria.

## Steps

### 1. Step Name
Specific actions to perform.

**Success criteria**: Define what proves this step is complete.
```

Omit `argument-hint` and `arguments` when the skill has no parameters.

Do not generate `allowed-tools`.
Do not generate `context`.
Do not generate `agent`.
Do not generate hooks, plugin metadata, or unsupported frontmatter fields.

Step guidance:

- Every step must include success criteria.
- Include artifacts when later steps need data produced by earlier steps.
- Include human checkpoints before irreversible actions, destructive actions, sending messages, or publishing changes.
- Preserve user corrections and hard preferences as rules inside the relevant step.
- Keep simple skills simple.

### Step 4: Review And Save

Before writing any file, present the complete `SKILL.md` content for user review in a fenced markdown code block.

Then ask for confirmation with `AskUserQuestion` using a concise question such as: "Does this SKILL.md look good to save?"

After confirmation:

1. Create the selected skill directory.
2. Write `SKILL.md`.
3. Tell the user where it was saved and how to invoke it as `/<skill-name> [arguments]`.
