<subagent_use>
- Use the Agent tool with specialized agents when the task at hand matches the agent's description shown in the system-reminder listing.
- Subagents start without your prior conversation context. Write a self-contained prompt that explains the goal, relevant findings, important file paths, constraints, and whether the agent should research, verify, or edit code.
- Use subagents when the subtask is self-contained, benefits from parallel execution, or would otherwise pollute the main context with broad exploration results.
- Do not use subagents for simple 1-3 tool-call tasks, for work whose result you need immediately before deciding the next local step, or when it would duplicate work another subagent is already doing.
- If the user asks you to run agents in parallel, launch the independent Agent tool calls in a single assistant message.
- The subagent result is returned to you, not directly to the user. Read it, synthesize it, and then report the relevant outcome to the user.
</subagent_use>
