CRITICAL: Respond with TEXT ONLY. Do NOT call any tools. You already have all
the context you need in the conversation above. Tool calls will be REJECTED
and waste your only turn.

Your task is to create a detailed summary of the conversation so far, paying
close attention to the user's explicit requests and your previous actions.
This summary should be thorough in capturing technical details, code patterns,
and architectural decisions that would be essential for continuing development
work without losing context.

Before providing your final summary, wrap your analysis in <analysis> tags to
organize your thoughts and ensure you've covered all necessary points. In your
analysis process:

1. Chronologically analyze each message and section of the conversation. For
each section thoroughly identify:
   - The user's explicit requests and intents
   - Your approach to addressing the user's requests
   - Key decisions, technical concepts and code patterns
   - Specific details like file names, full code snippets, function signatures,
     file edits
   - Errors that you ran into and how you fixed them
   - Pay special attention to specific user feedback that you received
2. Double-check for technical accuracy and completeness, addressing each
required element thoroughly.

Your summary should include the following 9 sections:

1. Primary Request and Intent: Capture all of the user's explicit requests and
intents in detail
2. Key Technical Concepts: List all important technical concepts, technologies,
and frameworks discussed.
3. Files and Code Sections: Enumerate specific files and code sections examined,
modified, or created. Include full code snippets where applicable and a summary
of why this file read or edit is important.
4. Errors and fixes: List all errors that you ran into, and how you fixed them.
Pay special attention to specific user feedback.
5. Problem Solving: Document problems solved and any ongoing troubleshooting
efforts.
6. All user messages: List ALL user messages that are not tool results. These
are critical for understanding the users' feedback and changing intent.
7. Pending Tasks: Outline any pending tasks that you have explicitly been asked
to work on.
8. Current Work: Describe in detail precisely what was being worked on
immediately before this summary request, paying special attention to the most
recent messages from both user and assistant. Include file names and code
snippets where applicable.
9. Optional Next Step: List the next step that you will take that is related to
the most recent work you were doing. IMPORTANT: ensure that this step is
DIRECTLY in line with the user's most recent explicit requests, and the task
you were working on immediately before this summary request. If your last task
was concluded, then only list next steps if they are explicitly in line with
the users request. If there is a next step, include direct quotes from the most
recent conversation showing exactly what task you were working on and where you
left off. If no next step exists, write N/A.

Here's an example of how your output should be structured:

<example>
<analysis>
[Your thought process, ensuring all points are covered thoroughly and accurately]
</analysis>

<summary>
1. Primary Request and Intent:
   [Detailed description]

2. Key Technical Concepts:
   - [Concept 1]
   - [Concept 2]

3. Files and Code Sections:
   - [File Name 1]
      - [Summary of why this file is important]
      - [Summary of changes made, if any]
      - [Important Code Snippet]

4. Errors and fixes:
    - [Detailed description of error 1]:
      - [How you fixed the error]
      - [User feedback if any]

5. Problem Solving:
   [Description of solved problems and ongoing troubleshooting]

6. All user messages:
    - [Detailed non tool use user message]

7. Pending Tasks:
   - [Task 1]
   - [Task 2]

8. Current Work:
   [Precise description of current work]

9. Optional Next Step:
   [Optional Next step to take]
</summary>
</example>

Please provide your summary based on the conversation so far. You MUST respond
with ONLY the <analysis>...</analysis> block followed by the
<summary>...</summary> block as your text output.
