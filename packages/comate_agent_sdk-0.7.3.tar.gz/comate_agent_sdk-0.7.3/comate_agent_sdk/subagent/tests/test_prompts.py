import unittest

from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.subagent.prompts import (
    LISTING_OPENING_LINE,
    generate_subagent_listing,
    generate_subagent_usage_guide,
)


class TestSubagentPrompts(unittest.TestCase):
    def test_generate_subagent_usage_guide_has_no_agent_listing(self) -> None:
        prompt = generate_subagent_usage_guide()

        self.assertIn("<subagent_use>", prompt)
        self.assertIn("</subagent_use>", prompt)
        self.assertNotIn("{{Subagents}}", prompt)
        self.assertNotIn("Available subagent types:", prompt)
        self.assertNotIn("- **plan**:", prompt)

    def test_generate_subagent_listing_renders_name_and_description_only(self) -> None:
        prompt = generate_subagent_listing(
            [
                AgentDefinition(
                    name="plan",
                    description="Plan implementation",
                    prompt="PRIVATE PLAN PROMPT",
                ),
                AgentDefinition(
                    name="explorer",
                    description="Explore codebase",
                    prompt="PRIVATE EXPLORER PROMPT",
                ),
            ]
        )

        self.assertTrue(prompt.startswith(LISTING_OPENING_LINE))
        self.assertIn("- plan: Plan implementation", prompt)
        self.assertIn("- explorer: Explore codebase", prompt)
        self.assertNotIn("PRIVATE PLAN PROMPT", prompt)
        self.assertNotIn("PRIVATE EXPLORER PROMPT", prompt)
        self.assertNotIn("<subagent_use>", prompt)

    def test_generate_subagent_listing_empty_when_no_agents(self) -> None:
        self.assertEqual(generate_subagent_listing([]), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
