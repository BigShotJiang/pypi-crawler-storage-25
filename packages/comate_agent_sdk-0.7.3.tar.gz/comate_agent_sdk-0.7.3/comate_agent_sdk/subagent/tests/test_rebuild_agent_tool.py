from __future__ import annotations

from pathlib import Path

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.subagent.agent_tool import rebuild_agent_tool
from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.tools import ToolRegistry
from comate_agent_sdk.tools.decorator import tool


def test_rebuild_agent_tool_skips_strategy_when_agent_is_disallowed(monkeypatch) -> None:
    @tool("agent tool", name="Agent")
    async def fake_agent_tool() -> str:
        return ""

    def fake_create_agent_tool(**kwargs):  # type: ignore[no-untyped-def]
        return fake_agent_tool

    monkeypatch.setattr(
        "comate_agent_sdk.subagent.agent_tool.create_agent_tool",
        fake_create_agent_tool,
    )

    class FakeAgent:
        def __init__(self) -> None:
            self._context = ContextIR()
            self._runtime_state = type("S", (), {})()
            self._runtime_state.agents = [
                AgentDefinition(name="worker", description="w", prompt="p")
            ]
            self._runtime_state.tools = []
            self._runtime_state.tool_registry = ToolRegistry()
            self._runtime_state.cwd = Path.cwd()
            self._runtime_state.llm_levels = {}
            self._runtime_state.user_instruction = None
            self._tool_map = {}
            self._is_subagent = False
            self.is_team_member = False
            self.llm = None
            self._token_cost = None
            self.config = type(
                "C",
                (),
                {
                    "dependency_overrides": None,
                    "use_streaming_task": False,
                    "env_options": None,
                    "disallowed_tools": ("Agent",),
                },
            )()

    agent = FakeAgent()
    rebuild_agent_tool(agent)  # type: ignore[arg-type]

    assert [tool.name for tool in agent._runtime_state.tools] == ["Agent"]
    assert agent._context.header.find_one_by_type(ItemType.SUBAGENT_STRATEGY) is None
    assert agent._context.session_state.find_one_by_type(ItemType.SUBAGENT_LISTING) is None
