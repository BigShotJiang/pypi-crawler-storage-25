"""Subagent prompt helpers（usage guide 与 listing 分离）。"""

from __future__ import annotations

from comate_agent_sdk.prompts import load_prompt
from comate_agent_sdk.subagent.models import AgentDefinition

_SUBAGENT_STRATEGY_TEMPLATE = load_prompt("subagent/strategy.md")
LISTING_OPENING_LINE = "Available agent types for the Agent tool:"


def generate_subagent_usage_guide() -> str:
    """返回 SDK 内置 subagent 行为指南。"""
    return _SUBAGENT_STRATEGY_TEMPLATE


def generate_subagent_listing(agents: list[AgentDefinition]) -> str:
    """生成 subagent listing 纯文本；<system-reminder> 包裹由 lowering 添加。"""
    if not agents:
        return ""

    lines = [f"- {agent.name}: {agent.description}" for agent in agents]
    return f"{LISTING_OPENING_LINE}\n\n" + "\n".join(lines)
