"""Partial compact implementation.

该模块只负责 conversation 段的 pivot 选择、摘要输入构造与结果组装。
文件回放由 ChatSession 通过 post-compact hook 注入，避免 Context 层读取磁盘。
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from comate_agent_sdk.context.budget import TokenCounter
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ContextItem, ItemType
from comate_agent_sdk.llm.messages import SystemMessage, UserMessage

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class PartialCompactionConfig:
    min_rounds_to_keep: int = 15
    max_tail_tokens: int = 30_000
    summary_target_min_tokens: int = 2_000
    enable: bool = True


@dataclass
class PartialCompactionResult:
    boundary_item: ContextItem
    summary_item: ContextItem
    prefix_items: list[ContextItem]
    tail_items: list[ContextItem]
    pivot_index: int
    diagnostics: dict[str, Any] = field(default_factory=dict)


def build_boundary_item(
    *,
    trigger: str,
    pre_compact_tokens: int,
    post_compact_tokens: int,
    summary_item_id: str,
    tail_kept_count: int,
    tail_kept_tokens: int,
) -> ContextItem:
    return ContextItem(
        item_type=ItemType.COMPACTION_BOUNDARY,
        message=SystemMessage(content="<compaction_boundary/>"),
        metadata={
            "trigger": trigger,
            "pre_compact_tokens": pre_compact_tokens,
            "post_compact_tokens": post_compact_tokens,
            "summary_item_id": summary_item_id,
            "tail_kept_count": tail_kept_count,
            "tail_kept_tokens": tail_kept_tokens,
            "timestamp": _iso_now(),
        },
    )


def _iso_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


class PartialCompactor:
    """pivot 边界模式的 partial compact 策略。"""

    def __init__(
        self,
        config: PartialCompactionConfig,
        compaction_service: Any,
        token_counter: TokenCounter,
        *,
        llm: Any = None,
        level: Any = None,
    ) -> None:
        self.config = config
        self._compaction_service = compaction_service
        self._token_counter = token_counter
        self._llm = llm
        self._level = level
        self.last_no_op_reason: str | None = None

    async def compact(
        self,
        context: ContextIR,
        *,
        trigger: str = "auto",
    ) -> PartialCompactionResult | None:
        self.last_no_op_reason = None
        items = list(context.conversation.items)
        prefix_items, suffix_start, _ = self._split_after_latest_boundary(items)

        pivot = self._choose_pivot(items)
        if pivot is None:
            self.last_no_op_reason = "rounds_insufficient"
            log.info("partial compact: rounds insufficient, no-op")
            return None

        pre_pivot_items = [
            item
            for item in items[suffix_start:pivot]
            if item.item_type != ItemType.COMPACTION_BOUNDARY
        ]
        pre_pivot_tokens = sum(_item_tokens(self._token_counter, item) for item in pre_pivot_items)
        if pre_pivot_tokens < self.config.summary_target_min_tokens:
            self.last_no_op_reason = "pre_pivot_tokens_below_min"
            log.info(
                "partial compact: pre_pivot tokens %d < min %d, no-op",
                pre_pivot_tokens,
                self.config.summary_target_min_tokens,
            )
            return None

        pre_pivot_messages = [
            item.message for item in pre_pivot_items if item.message is not None
        ]
        compaction_result = await self._compaction_service.compact(
            pre_pivot_messages,
            self._llm,
            level=self._level,
            original_tokens=pre_pivot_tokens,
        )
        if not compaction_result.compacted or not compaction_result.summary:
            failure_reason = getattr(compaction_result, "failure_reason", None)
            self.last_no_op_reason = (
                f"summary_failed_or_empty:{failure_reason}"
                if failure_reason
                else "summary_failed_or_empty"
            )
            log.warning(
                "partial compact: summary generation failed: %s",
                failure_reason,
            )
            return None

        summary_id = f"sum-{uuid.uuid4().hex[:8]}"
        summary_item = ContextItem(
            item_type=ItemType.COMPACTION_SUMMARY,
            message=UserMessage(content=compaction_result.summary),
            content_text=compaction_result.summary,
            token_count=self._token_counter.count(compaction_result.summary),
            priority=DEFAULT_PRIORITIES[ItemType.COMPACTION_SUMMARY],
            metadata={"id": summary_id},
        )

        tail_items = items[pivot:]
        tail_tokens = sum(
            _item_tokens(self._token_counter, item)
            for item in tail_items
            if item.item_type != ItemType.COMPACTION_BOUNDARY
        )
        post_compact_tokens = int(getattr(compaction_result, "new_tokens", 0) or 0) + tail_tokens
        boundary_item = build_boundary_item(
            trigger=trigger,
            pre_compact_tokens=pre_pivot_tokens,
            post_compact_tokens=post_compact_tokens,
            summary_item_id=summary_id,
            tail_kept_count=len(tail_items),
            tail_kept_tokens=tail_tokens,
        )

        return PartialCompactionResult(
            boundary_item=boundary_item,
            summary_item=summary_item,
            prefix_items=prefix_items,
            tail_items=tail_items,
            pivot_index=pivot,
            diagnostics={
                "pre_pivot_tokens": pre_pivot_tokens,
                "tail_tokens": tail_tokens,
            },
        )

    def _choose_pivot(self, items: list[ContextItem]) -> int | None:
        """返回 pivot index；items[pivot:] 是必须保留的 tail。

        min_rounds_to_keep 是硬约束，max_tail_tokens 仅作为预算告警。
        二次压缩时只在 latest boundary 之后的 suffix 中选择 pivot。
        """
        _, suffix_start, suffix = self._split_after_latest_boundary(items)

        round_starts: list[int] = []
        for local_idx, item in enumerate(suffix):
            if item.item_type == ItemType.COMPACTION_BOUNDARY:
                continue
            if item.item_type == ItemType.USER_MESSAGE:
                round_starts.append(local_idx)

        if len(round_starts) < self.config.min_rounds_to_keep:
            return None

        pivot_by_rounds = round_starts[-self.config.min_rounds_to_keep]

        spent = 0
        pivot_by_tokens = len(suffix)
        for idx in range(len(suffix) - 1, -1, -1):
            item = suffix[idx]
            if item.item_type == ItemType.COMPACTION_BOUNDARY:
                continue
            tokens = _item_tokens(self._token_counter, item)
            if spent + tokens > self.config.max_tail_tokens:
                pivot_by_tokens = idx + 1
                break
            spent += tokens
        else:
            pivot_by_tokens = 0

        if pivot_by_tokens > pivot_by_rounds:
            log.warning(
                "partial compact: min_rounds tail exceeds max_tail_tokens; "
                "preserving recent rounds over token budget"
            )

        return suffix_start + pivot_by_rounds

    def _split_after_latest_boundary(
        self,
        items: list[ContextItem],
    ) -> tuple[list[ContextItem], int, list[ContextItem]]:
        """返回 (prefix_to_preserve, suffix_start_index, suffix_to_compact)。"""
        latest_boundary_index = None
        for idx in range(len(items) - 1, -1, -1):
            if items[idx].item_type == ItemType.COMPACTION_BOUNDARY:
                latest_boundary_index = idx
                break

        if latest_boundary_index is None:
            return [], 0, list(items)

        suffix_start = latest_boundary_index + 1
        return list(items[:suffix_start]), suffix_start, list(items[suffix_start:])


def _extract_text(item: ContextItem) -> str:
    if item.content_text:
        return item.content_text
    message = item.message
    if message is None:
        return ""
    text = getattr(message, "text", None)
    if isinstance(text, str):
        return text
    content = getattr(message, "content", "")
    return content if isinstance(content, str) else str(content)


def _item_tokens(token_counter: TokenCounter, item: ContextItem) -> int:
    if item.token_count > 0:
        return item.token_count
    return token_counter.count(_extract_text(item))
