"""Header item 顺序定义。"""

from __future__ import annotations

from comate_agent_sdk.context.items import ItemType

STATIC_HEADER_ITEM_ORDER: dict[ItemType, int] = {
    ItemType.SYSTEM_PROMPT: 0,
    ItemType.PROJECT_CONTEXT: 1,
    ItemType.MEMORY_USAGE: 2,
    ItemType.TOOL_STRATEGY: 3,
    ItemType.SUBAGENT_STRATEGY: 4,
    ItemType.SKILL_STRATEGY: 5,
}

SESSION_STATE_ITEM_ORDER: dict[ItemType, int] = {
    ItemType.USER_INSTRUCTION: -1,  # 排在 session_state 最前
    ItemType.SYSTEM_ENV: 0,
    ItemType.GIT_ENV: 1,
    ItemType.MCP_TOOL: 2,
    ItemType.OUTPUT_STYLE: 3,
    ItemType.SUBAGENT_LISTING: 4,
    ItemType.SKILL_LISTING: 5,
}

STATIC_HEADER_ITEM_TYPES_IN_ORDER: tuple[ItemType, ...] = tuple(
    item_type for item_type, _ in sorted(STATIC_HEADER_ITEM_ORDER.items(), key=lambda kv: kv[1])
)

SESSION_STATE_ITEM_TYPES_IN_ORDER: tuple[ItemType, ...] = tuple(
    item_type for item_type, _ in sorted(SESSION_STATE_ITEM_ORDER.items(), key=lambda kv: kv[1])
)

# Backward-compatible aliases.
HEADER_ITEM_ORDER: dict[ItemType, int] = STATIC_HEADER_ITEM_ORDER
HEADER_ITEM_TYPES_IN_ORDER: tuple[ItemType, ...] = STATIC_HEADER_ITEM_TYPES_IN_ORDER
