"""File touch tracking for post-compact replay."""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass


@dataclass
class FileTouch:
    path: str
    last_op: str
    last_ts: float


class FileTrackState:
    def __init__(self) -> None:
        self._touches: dict[str, FileTouch] = {}
        self._dirty = False

    @property
    def dirty(self) -> bool:
        return self._dirty

    def mark_clean(self) -> None:
        self._dirty = False

    def clear(self) -> None:
        self._touches.clear()
        self._dirty = True

    def record(self, path: str, op: str) -> None:
        self._touches[path] = FileTouch(path=path, last_op=op, last_ts=time.time())
        self._dirty = True

    def recent(self, limit: int) -> list[FileTouch]:
        return sorted(
            self._touches.values(),
            key=lambda touch: touch.last_ts,
            reverse=True,
        )[:limit]

    def serialize(self) -> dict:
        return {
            "version": 1,
            "touches": [asdict(touch) for touch in self._touches.values()],
        }

    @classmethod
    def deserialize(cls, data: dict) -> "FileTrackState":
        state = cls()
        for touch_data in data.get("touches", []):
            touch = FileTouch(**touch_data)
            state._touches[touch.path] = touch
        state.mark_clean()
        return state
