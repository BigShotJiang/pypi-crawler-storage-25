import asyncio

import pytest

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ContextItem, DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.partial_compaction import (
    PartialCompactionConfig,
    PartialCompactionResult,
    PartialCompactor,
    build_boundary_item,
)
from comate_agent_sdk.context.compaction import SelectiveCompactionPolicy
from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage, UserMessage


def test_config_defaults_align_with_dialogue_rounds_keep_min():
    cfg = PartialCompactionConfig()
    assert cfg.min_rounds_to_keep == 15
    assert cfg.max_tail_tokens == 30_000
    assert cfg.summary_target_min_tokens == 2_000
    assert cfg.enable is True


def test_build_boundary_item_metadata():
    item = build_boundary_item(
        trigger="auto",
        pre_compact_tokens=50_000,
        post_compact_tokens=12_000,
        summary_item_id="sum-1",
        tail_kept_count=4,
        tail_kept_tokens=8_000,
    )
    assert item.metadata["trigger"] == "auto"
    assert item.metadata["pre_compact_tokens"] == 50_000
    assert isinstance(item.metadata, dict)


def make_user(text: str, tokens: int = 100) -> ContextItem:
    return ContextItem(
        item_type=ItemType.USER_MESSAGE,
        message=UserMessage(content=text),
        content_text=text,
        token_count=tokens,
        priority=DEFAULT_PRIORITIES[ItemType.USER_MESSAGE],
    )


def make_assistant(text: str, tokens: int = 100) -> ContextItem:
    return ContextItem(
        item_type=ItemType.ASSISTANT_MESSAGE,
        message=AssistantMessage(content=text),
        content_text=text,
        token_count=tokens,
        priority=DEFAULT_PRIORITIES[ItemType.ASSISTANT_MESSAGE],
    )


def make_boundary() -> ContextItem:
    return build_boundary_item(
        trigger="check",
        pre_compact_tokens=1_000,
        post_compact_tokens=400,
        summary_item_id="sum-old",
        tail_kept_count=2,
        tail_kept_tokens=400,
    )


def make_summary(text: str) -> ContextItem:
    return ContextItem(
        item_type=ItemType.COMPACTION_SUMMARY,
        message=UserMessage(content=text),
        content_text=text,
        token_count=100,
        priority=DEFAULT_PRIORITIES[ItemType.COMPACTION_SUMMARY],
    )


def make_tool_result_item(tool_name: str, path: str, content: str, tokens: int = 100) -> ContextItem:
    msg = ToolMessage(
        tool_call_id=f"tc-{tool_name.lower()}",
        tool_name=tool_name,
        content=content,
        execution_meta={"file_ops": {"file_path": path}},
        raw_envelope={"meta": {"resolved_file_path": path}},
    )
    return ContextItem(
        item_type=ItemType.TOOL_RESULT,
        message=msg,
        content_text=content,
        token_count=tokens,
        priority=DEFAULT_PRIORITIES[ItemType.TOOL_RESULT],
        tool_name=tool_name,
        metadata={
            "tool_name": tool_name,
            "tool_execution_meta": msg.execution_meta,
            "tool_raw_envelope": msg.raw_envelope,
        },
    )


def build_minimal_context_ir_with_conversation(items: list[ContextItem]) -> ContextIR:
    ctx = ContextIR()
    ctx.replace_conversation(items)
    return ctx


class FakeTokenCounter:
    def count(self, text: str) -> int:
        return max(1, len(text) // 4)


class FakeCompactionService:
    async def compact(self, messages, llm=None, *, level=None, original_tokens: int = 0):
        del messages, llm, level
        from comate_agent_sdk.agent.compaction.models import CompactionResult

        return CompactionResult(
            compacted=True,
            summary="<summary>9-section content here</summary>",
            original_tokens=original_tokens,
            new_tokens=8_000,
        )


def _round_items(count: int, tokens_per_item: int = 100) -> list[ContextItem]:
    items: list[ContextItem] = []
    for i in range(1, count + 1):
        items.append(make_user(f"Q{i}", tokens_per_item))
        items.append(make_assistant(f"A{i}", tokens_per_item))
    return items


def build_ir_with_long_conversation(
    *,
    token_total: int,
    include_tool_result_in_tail: bool,
) -> ContextIR:
    ctx = ContextIR()
    items = [
        make_user("old request", token_total // 4),
        make_assistant("old answer", token_total // 4),
        make_user("middle request", token_total // 4),
        make_assistant("middle answer", token_total // 4),
        make_user("recent request", 100),
        make_assistant("recent answer", 100),
    ]
    if include_tool_result_in_tail:
        items.append(make_tool_result_item("Read", "/tmp/a.py", "raw file content", 100))
    ctx.replace_conversation(items)
    ctx.add_system_reminder_message("temporary compact reminder")
    ctx.add_deferred_meta_message("temporary deferred meta")
    return ctx


def build_ir_with_short_conversation_and_system_reminder() -> ContextIR:
    ctx = ContextIR()
    ctx.replace_conversation([make_user("only one round", 100), make_assistant("answer", 100)])
    ctx.add_system_reminder_message("temporary compact reminder")
    ctx.add_deferred_meta_message("temporary deferred meta")
    return ctx


def build_ir_with_existing_boundary_and_long_suffix() -> ContextIR:
    ctx = ContextIR()
    old_boundary = make_boundary()
    old_boundary.id = "old-boundary"
    ctx.replace_conversation([
        old_boundary,
        make_summary("previous compact summary"),
        make_user("suffix request 1", 300),
        make_assistant("suffix answer 1", 300),
        make_user("suffix request 2", 300),
        make_assistant("suffix answer 2", 300),
        make_user("suffix request 3", 300),
        make_assistant("suffix answer 3", 300),
    ])
    return ctx


def test_pivot_by_min_rounds_only():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, max_tail_tokens=10_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = _round_items(3, tokens_per_item=100)

    pivot = cmp._choose_pivot(items)

    assert pivot == 2


def test_pivot_by_max_tail_tokens_only():
    cfg = PartialCompactionConfig(min_rounds_to_keep=1, max_tail_tokens=30_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = [
        make_user("Q1", 20_000),
        make_assistant("A1", 20_000),
        make_user("Q2", 20_000),
        make_assistant("A2", 20_000),
        make_user("Q3", 20_000),
        make_assistant("A3", 5_000),
    ]

    pivot = cmp._choose_pivot(items)

    assert pivot == 4


def test_pivot_prefers_min_rounds_when_tail_budget_allows():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, max_tail_tokens=30_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = _round_items(6, tokens_per_item=2_500)

    pivot = cmp._choose_pivot(items)

    assert pivot == 8


def test_pivot_never_cuts_inside_min_rounds_when_tail_budget_conflicts():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, max_tail_tokens=1_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = _round_items(3, tokens_per_item=2_000)

    pivot = cmp._choose_pivot(items)

    assert pivot == 2


def test_pivot_returns_none_when_rounds_insufficient():
    cfg = PartialCompactionConfig(min_rounds_to_keep=15)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = [make_user("Q1"), make_assistant("A1")]

    assert cmp._choose_pivot(items) is None


def test_pivot_skips_existing_boundary():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, max_tail_tokens=10_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = [
        make_user("Q1", 100),
        make_assistant("A1", 100),
        make_boundary(),
        make_user("Q2", 100),
        make_assistant("A2", 100),
        make_user("Q3", 100),
        make_assistant("A3", 100),
        make_user("Q4", 100),
        make_assistant("A4", 100),
    ]

    pivot = cmp._choose_pivot(items)

    assert pivot == 5


def test_split_by_latest_boundary_preserves_prefix():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, max_tail_tokens=10_000)
    cmp = PartialCompactor(cfg, compaction_service=None, token_counter=FakeTokenCounter())
    items = [
        make_boundary(),
        make_summary("old summary"),
        make_user("Q2", 100),
        make_assistant("A2", 100),
        make_boundary(),
        make_summary("newer summary"),
        make_user("Q3", 100),
        make_assistant("A3", 100),
        make_user("Q4", 100),
        make_assistant("A4", 100),
        make_user("Q5", 100),
        make_assistant("A5", 100),
    ]

    prefix, suffix_start, suffix = cmp._split_after_latest_boundary(items)

    assert prefix == items[:5]
    assert suffix_start == 5
    assert suffix == items[5:]


def test_compact_returns_none_when_no_benefit():
    cfg = PartialCompactionConfig(
        min_rounds_to_keep=2,
        summary_target_min_tokens=10_000,
    )
    cmp = PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
    items = [
        make_user("Q1", 100),
        make_assistant("A1", 100),
        make_user("Q2", 100),
        make_assistant("A2", 100),
        make_user("Q3", 100),
        make_assistant("A3", 100),
    ]
    ir = build_minimal_context_ir_with_conversation(items)

    result = asyncio.run(cmp.compact(ir))

    assert result is None


def test_compact_returns_result_with_boundary_summary_tail():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, summary_target_min_tokens=100)
    cmp = PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
    items = [
        make_user("Q1", 100),
        make_assistant("A1", 100),
        make_user("Q2", 100),
        make_assistant("A2", 100),
        make_user("Q3", 100),
        make_assistant("A3", 100),
    ]
    ir = build_minimal_context_ir_with_conversation(items)

    result = asyncio.run(cmp.compact(ir, trigger="manual"))

    assert result is not None
    assert result.boundary_item.item_type == ItemType.COMPACTION_BOUNDARY
    assert result.boundary_item.metadata["trigger"] == "manual"
    assert result.summary_item.item_type == ItemType.COMPACTION_SUMMARY
    assert "9-section" in result.summary_item.message.content
    assert len(result.tail_items) == 4
    assert result.pivot_index == 2


def test_assert_min_rounds_ge_dialogue_rounds_keep_min():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2)
    policy = SelectiveCompactionPolicy(dialogue_rounds_keep_min=15)

    with pytest.raises(AssertionError, match="min_rounds_to_keep"):
        policy.set_partial_compactor(
            PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
        )


def test_partial_compact_runs_after_preclean_before_destructive_selective_stages():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, summary_target_min_tokens=100)
    policy = SelectiveCompactionPolicy(
        dialogue_rounds_keep_min=2,
        threshold=1_000,
    )
    policy.set_partial_compactor(
        PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
    )
    ir = build_ir_with_long_conversation(token_total=2_000, include_tool_result_in_tail=True)

    compacted = asyncio.run(policy.compact(ir))

    assert compacted is True
    items = list(ir.conversation.items)
    assert items[0].item_type == ItemType.COMPACTION_BOUNDARY
    assert items[1].item_type == ItemType.COMPACTION_SUMMARY
    assert any(item.item_type == ItemType.TOOL_RESULT for item in items[2:])
    assert not any(item.item_type == ItemType.SYSTEM_REMINDER for item in items)
    assert ir.get_deferred_items_snapshot() == []


def test_partial_compact_no_op_does_not_fall_back_to_legacy_summary():
    cfg = PartialCompactionConfig(min_rounds_to_keep=15, summary_target_min_tokens=100)
    policy = SelectiveCompactionPolicy(threshold=1_000)
    policy.set_partial_compactor(
        PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
    )
    ir = build_ir_with_short_conversation_and_system_reminder()
    before = list(ir.conversation.items)
    before_deferred = ir.get_deferred_items_snapshot()

    compacted = asyncio.run(policy.compact(ir))

    assert compacted is False
    assert ir.conversation.items == before
    assert ir.get_deferred_items_snapshot() == before_deferred
    assert any(
        record.reason == "partial_compact_no_op:rounds_insufficient"
        for record in policy.meta_records
    )


def test_recompact_preserves_prefix_through_latest_boundary():
    cfg = PartialCompactionConfig(min_rounds_to_keep=2, summary_target_min_tokens=100)
    policy = SelectiveCompactionPolicy(dialogue_rounds_keep_min=2, threshold=1_000)
    policy.set_partial_compactor(
        PartialCompactor(cfg, FakeCompactionService(), FakeTokenCounter())
    )
    ir = build_ir_with_existing_boundary_and_long_suffix()
    old_boundary_id = ir.conversation.items[0].id

    compacted = asyncio.run(policy.compact(ir))

    assert compacted is True
    items = list(ir.conversation.items)
    assert items[0].id == old_boundary_id
    assert items[0].item_type == ItemType.COMPACTION_BOUNDARY
    assert items[1].item_type == ItemType.COMPACTION_BOUNDARY
    assert items[2].item_type == ItemType.COMPACTION_SUMMARY
