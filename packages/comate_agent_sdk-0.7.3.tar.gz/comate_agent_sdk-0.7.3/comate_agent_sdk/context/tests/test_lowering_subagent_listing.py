"""SUBAGENT_LISTING lowering 形态测试。"""

from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.lower import LoweringPipeline
from comate_agent_sdk.llm.messages import SystemMessage, UserMessage

_SUBAGENT_OPENING = "Available agent types for the Agent tool:"
_SKILL_OPENING = "The following skills are available for use with the Skill tool:"


def _lower(ctx: ContextIR):
    return LoweringPipeline.lower(ctx)


def test_lowering_subagent_listing_is_standalone_system_reminder_message() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYS", cache=True)
    ctx.set_subagent_listing(f"{_SUBAGENT_OPENING}\n\n- demo: hello")

    messages = _lower(ctx)
    listings = [
        m for m in messages
        if isinstance(m, UserMessage)
        and m.is_meta
        and "<system-reminder>" in m.content
        and _SUBAGENT_OPENING in m.content
    ]

    assert len(listings) == 1
    assert listings[0].content.startswith("<system-reminder>\n")
    assert listings[0].content.endswith("\n</system-reminder>")
    assert "- demo: hello" in listings[0].content


def test_lowering_emits_subagent_listing_before_skill_listing() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYS", cache=True)
    ctx.set_user_instruction("UINSTR")
    ctx.set_subagent_listing(f"{_SUBAGENT_OPENING}\n\n- agent: x")
    ctx.set_skill_listing(f"{_SKILL_OPENING}\n\n- skill: x")
    ctx.set_system_env("ENV")

    messages = _lower(ctx)

    indices: dict[str, int] = {}
    for idx, message in enumerate(messages):
        content = str(getattr(message, "content", ""))
        if isinstance(message, SystemMessage):
            indices.setdefault("system", idx)
        elif isinstance(message, UserMessage) and message.is_meta and "<user_instructions>" in content:
            indices["user_instruction"] = idx
        elif isinstance(message, UserMessage) and message.is_meta and _SUBAGENT_OPENING in content:
            indices["subagent_listing"] = idx
        elif isinstance(message, UserMessage) and message.is_meta and _SKILL_OPENING in content:
            indices["skill_listing"] = idx
        elif isinstance(message, UserMessage) and message.is_meta and "ENV" in content:
            indices["session_state"] = idx

    assert (
        indices["system"]
        < indices["user_instruction"]
        < indices["subagent_listing"]
        < indices["skill_listing"]
        < indices["session_state"]
    )


def test_lowering_no_subagent_listing_when_item_absent() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYS", cache=True)

    messages = _lower(ctx)

    assert all(_SUBAGENT_OPENING not in str(getattr(m, "content", "")) for m in messages)


def test_lowering_no_subagent_listing_when_item_empty() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYS", cache=True)
    ctx.set_subagent_listing("")

    messages = _lower(ctx)

    assert all(_SUBAGENT_OPENING not in str(getattr(m, "content", "")) for m in messages)


def test_lowering_subagent_listing_not_merged_into_session_state_text_block() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYS", cache=True)
    ctx.set_system_env("ENV_LINE")
    ctx.set_subagent_listing(f"{_SUBAGENT_OPENING}\n\n- demo: x")

    messages = _lower(ctx)
    session_state_msgs = [
        m for m in messages
        if isinstance(m, UserMessage) and m.is_meta and "ENV_LINE" in str(m.content)
    ]

    assert len(session_state_msgs) == 1
    assert _SUBAGENT_OPENING not in session_state_msgs[0].content
