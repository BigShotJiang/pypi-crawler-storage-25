import time

from comate_agent_sdk.context.file_track import FileTrackState


def test_record_three_ops():
    state = FileTrackState()
    state.record("/a.py", "read")
    state.record("/b.py", "edit")
    state.record("/c.py", "write")
    assert len(state._touches) == 3


def test_record_dedup_keeps_latest_only():
    state = FileTrackState()
    state.record("/a.py", "read")
    first_ts = state._touches["/a.py"].last_ts
    time.sleep(0.01)
    state.record("/a.py", "edit")
    second_ts = state._touches["/a.py"].last_ts
    assert second_ts > first_ts
    assert state._touches["/a.py"].last_op == "edit"
    assert len(state._touches) == 1


def test_recent_returns_top_n_by_timestamp_desc():
    state = FileTrackState()
    for path in ["/a", "/b", "/c", "/d", "/e", "/f"]:
        state.record(path, "read")
        time.sleep(0.001)
    top3 = state.recent(3)
    assert [touch.path for touch in top3] == ["/f", "/e", "/d"]


def test_serialize_deserialize_roundtrip():
    first = FileTrackState()
    first.record("/a.py", "read")
    first.record("/b.py", "write")
    blob = first.serialize()
    second = FileTrackState.deserialize(blob)
    assert second.recent(10) == first.recent(10)
    assert second.dirty is False


def test_dirty_flag_can_be_cleared_after_persist():
    state = FileTrackState()
    assert state.dirty is False
    state.record("/a.py", "read")
    assert state.dirty is True
    state.mark_clean()
    assert state.dirty is False


def test_clear_removes_touches_and_marks_dirty():
    state = FileTrackState()
    state.record("/a.py", "read")
    state.mark_clean()
    state.clear()
    assert state.recent(10) == []
    assert state.dirty is True
