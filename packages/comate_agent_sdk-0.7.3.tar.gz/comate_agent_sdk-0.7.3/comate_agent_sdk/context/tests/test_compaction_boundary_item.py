from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ContextItem, ItemType
from comate_agent_sdk.context.lower import LoweringPipeline
from comate_agent_sdk.llm.messages import AssistantMessage, SystemMessage, UserMessage


def test_compaction_boundary_enum_exists():
    assert hasattr(ItemType, "COMPACTION_BOUNDARY")
    assert ItemType.COMPACTION_BOUNDARY.value == "compaction_boundary"


def test_compaction_boundary_priority_is_never_compacted():
    assert DEFAULT_PRIORITIES[ItemType.COMPACTION_BOUNDARY] == 100


def test_boundary_metadata_is_mutable_dict():
    item = ContextItem(
        item_type=ItemType.COMPACTION_BOUNDARY,
        message=SystemMessage(content="<compaction_boundary/>"),
        metadata={
            "trigger": "auto",
            "pre_compact_tokens": 50_000,
            "post_compact_tokens": 12_000,
            "summary_item_id": "sum-123",
            "tail_kept_count": 4,
            "tail_kept_tokens": 8_000,
        },
    )
    assert item.item_type == ItemType.COMPACTION_BOUNDARY
    assert isinstance(item.metadata, dict)

    item.metadata["files_replayed"] = ["a.py", "b.py"]
    item.metadata["missing_files"] = []
    assert item.metadata["files_replayed"] == ["a.py", "b.py"]


def test_boundary_metadata_readers_must_use_get_with_default():
    item = ContextItem(
        item_type=ItemType.COMPACTION_BOUNDARY,
        message=SystemMessage(content="<compaction_boundary/>"),
        metadata={
            "trigger": "manual",
            "pre_compact_tokens": 30_000,
            "post_compact_tokens": 8_000,
            "summary_item_id": "sum-456",
            "tail_kept_count": 2,
            "tail_kept_tokens": 3_000,
        },
    )
    assert item.metadata.get("files_replayed", []) == []
    assert item.metadata.get("missing_files", []) == []
    assert item.metadata.get("skipped_due_to_budget", []) == []


def test_lowering_outputs_boundary_as_system_reminder():
    boundary = ContextItem(
        item_type=ItemType.COMPACTION_BOUNDARY,
        message=SystemMessage(content="<compaction_boundary/>"),
        metadata={
            "trigger": "auto",
            "pre_compact_tokens": 50_000,
            "post_compact_tokens": 12_000,
            "timestamp": "2026-05-08T10:00:00",
        },
    )
    ir = ContextIR()
    ir.replace_conversation([boundary])

    messages = LoweringPipeline.lower(ir)

    assert len(messages) == 1
    assert isinstance(messages[0], UserMessage)
    assert messages[0].is_meta is True
    rendered = messages[0].content
    assert "<system-reminder>" in rendered
    assert "compaction_boundary" in rendered.lower() or "compacted" in rendered.lower()
    assert "Pre-compact tokens" in rendered
    assert "50000" in rendered


def test_round_ranges_skip_compaction_boundary():
    from comate_agent_sdk.context.compaction import _compute_round_ranges

    items = [
        ContextItem(item_type=ItemType.USER_MESSAGE, message=UserMessage(content="Q1")),
        ContextItem(item_type=ItemType.ASSISTANT_MESSAGE, message=AssistantMessage(content="A1")),
        ContextItem(
            item_type=ItemType.COMPACTION_BOUNDARY,
            message=SystemMessage(content="<compaction_boundary/>"),
        ),
        ContextItem(item_type=ItemType.USER_MESSAGE, message=UserMessage(content="Q2")),
        ContextItem(item_type=ItemType.ASSISTANT_MESSAGE, message=AssistantMessage(content="A2")),
    ]

    ranges = _compute_round_ranges(items)

    assert ranges == [(0, 1), (3, 4)]
