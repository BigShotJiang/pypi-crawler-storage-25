import json
from pathlib import Path

import pytest

from comate_agent_sdk.context.fs import ContextFileSystem
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import ToolMessage


def test_offload_tool_result_uses_utf8_when_default_locale_is_gbk(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fs = ContextFileSystem(root_path=tmp_path / "ctx", session_id="session-1")
    original_write_text = Path.write_text

    def gbk_default_write_text(
        self: Path,
        data: str,
        encoding: str | None = None,
        errors: str | None = None,
        newline: str | None = None,
    ) -> int:
        if encoding is None:
            data.encode("gbk")
        return original_write_text(
            self,
            data,
            encoding=encoding,
            errors=errors,
            newline=newline,
        )

    monkeypatch.setattr(Path, "write_text", gbk_default_write_text)

    item = ContextItem(
        id="tool-result-1",
        item_type=ItemType.TOOL_RESULT,
        message=ToolMessage(
            tool_call_id="call-1",
            tool_name="Read",
            content="running ▶ complete",
        ),
        content_text="running ▶ complete",
        token_count=10,
        tool_name="Read",
        metadata={"display": "running ▶ complete"},
    )

    result = fs.offload_tool_result(
        item,
        tool_call_id="call-1",
        tool_name="Read",
        result_token_count=10,
    )

    payload = json.loads((fs.root_path / result.relative_path).read_text(encoding="utf-8"))
    index = json.loads((fs.root_path / "index.json").read_text(encoding="utf-8"))
    assert payload["content"] == "running ▶ complete"
    assert index["items"]["tool-result-1"]["metadata"]["display"] == "running ▶ complete"


def test_load_reads_utf8_when_default_locale_is_gbk(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root_path = tmp_path / "ctx"
    result_path = root_path / "tool_result" / "Read" / "call-1.json"
    result_path.parent.mkdir(parents=True)
    result_path.write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "item_id": "tool-result-1",
                "tool_call_id": "call-1",
                "tool_name": "Read",
                "content": "running ▶ complete",
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    (root_path / "index.json").write_text(
        json.dumps(
            {
                "version": "1.0",
                "session_id": "session-1",
                "items": {
                    "tool-result-1": {
                        "item_id": "tool-result-1",
                        "item_type": "tool_result",
                        "file_path": "tool_result/Read/call-1.json",
                        "original_token_count": 10,
                        "offloaded_at": 0.0,
                        "metadata": {"display": "running ▶ complete"},
                    }
                },
                "tool_calls": {},
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    original_read_text = Path.read_text

    def gbk_default_read_text(
        self: Path,
        encoding: str | None = None,
        errors: str | None = None,
    ) -> str:
        if encoding is None:
            return self.read_bytes().decode("gbk")
        return original_read_text(self, encoding=encoding, errors=errors)

    monkeypatch.setattr(Path, "read_text", gbk_default_read_text)

    fs = ContextFileSystem(root_path=root_path, session_id="session-1")

    assert fs.load("tool-result-1") == "running ▶ complete"
