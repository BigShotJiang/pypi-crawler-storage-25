"""SUBAGENT_LISTING registry 一致性测试。"""

from __future__ import annotations

from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.header.order import (
    SESSION_STATE_ITEM_ORDER,
    SESSION_STATE_ITEM_TYPES_IN_ORDER,
    STATIC_HEADER_ITEM_ORDER,
)
from comate_agent_sdk.context.info import _build_categories
from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.offload import OffloadPolicy


def test_subagent_listing_item_type_exists() -> None:
    assert ItemType.SUBAGENT_LISTING.value == "subagent_listing"


def test_subagent_listing_priority_is_never_compressed() -> None:
    assert DEFAULT_PRIORITIES[ItemType.SUBAGENT_LISTING] == 100


def test_subagent_listing_in_session_state_order_before_skill_listing() -> None:
    assert ItemType.SUBAGENT_LISTING in SESSION_STATE_ITEM_ORDER
    assert ItemType.SUBAGENT_LISTING in SESSION_STATE_ITEM_TYPES_IN_ORDER
    assert (
        SESSION_STATE_ITEM_ORDER[ItemType.OUTPUT_STYLE]
        < SESSION_STATE_ITEM_ORDER[ItemType.SUBAGENT_LISTING]
        < SESSION_STATE_ITEM_ORDER[ItemType.SKILL_LISTING]
    )


def test_subagent_listing_not_in_static_header_order() -> None:
    assert ItemType.SUBAGENT_LISTING not in STATIC_HEADER_ITEM_ORDER


def test_subagent_listing_offload_disabled() -> None:
    policy = OffloadPolicy()
    assert policy.type_enabled["subagent_listing"] is False


def test_subagent_listing_in_context_info_categories() -> None:
    ctx = ContextIR()
    ctx.set_subagent_listing("LISTING_TEXT")

    status = ctx.get_budget_status()
    labels = {category.label for category in _build_categories(status.tokens_by_type, ctx)}

    assert "Subagent Listing" in labels
