from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ContextItem
from comate_agent_sdk.context.lower import LoweringPipeline
from comate_agent_sdk.llm.messages import UserMessage


def test_file_attachment_enum_exists():
    assert hasattr(ItemType, "FILE_ATTACHMENT")
    assert ItemType.FILE_ATTACHMENT.value == "file_attachment"


def test_file_attachment_priority_is_never_compacted_by_selective_stage():
    assert DEFAULT_PRIORITIES[ItemType.FILE_ATTACHMENT] == 100


def test_lowering_outputs_file_attachment_as_meta_user_message():
    ir = ContextIR()
    attachment = ContextItem(
        item_type=ItemType.FILE_ATTACHMENT,
        message=UserMessage(
            content=(
                '<file_attachment path="/tmp/a.py" last_op="read">\n'
                "print('a')\n"
                "</file_attachment>"
            ),
            is_meta=True,
        ),
        content_text="print('a')",
        metadata={
            "post_compact_attachment": True,
            "file_path": "/tmp/a.py",
            "last_op": "read",
        },
    )
    ir.replace_conversation([attachment])

    messages = LoweringPipeline.lower(ir)

    assert len(messages) == 1
    assert isinstance(messages[0], UserMessage)
    assert messages[0].is_meta is True
    assert "<file_attachment" in messages[0].content
