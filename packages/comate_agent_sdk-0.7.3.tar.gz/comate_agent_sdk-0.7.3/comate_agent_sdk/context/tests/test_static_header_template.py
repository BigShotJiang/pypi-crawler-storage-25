from __future__ import annotations

from comate_agent_sdk.agent.system_prompt import resolve_system_prompt
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.llm.messages import SystemMessage


def _lowered_system_prompt(ctx: ContextIR) -> str:
    lowered = ctx.lower()
    system_messages = [message for message in lowered if isinstance(message, SystemMessage)]
    assert len(system_messages) == 1
    return str(system_messages[0].content)


def test_default_system_prompt_template_injects_dynamic_static_header_items() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt(resolve_system_prompt(None), cache=False)
    ctx.set_memory_usage("<memory_usage>MEMORY</memory_usage>", cache=False)
    ctx.set_subagent_strategy("<subagent_use>- use Agent when helpful</subagent_use>")
    ctx.set_skill_strategy("<skill_use>- load on demand</skill_use>")

    lowered_text = _lowered_system_prompt(ctx)

    assert "# Capabilities" in lowered_text
    assert "# Context" in lowered_text
    assert lowered_text.count("<memory_usage>") == 1
    context_pos = lowered_text.index("# Context")
    memory_pos = lowered_text.index("<memory_usage>")
    notes_pos = lowered_text.index("<system_notes>")
    assert context_pos < memory_pos < notes_pos
    assert lowered_text.count("<subagent_use>") == 1
    assert "<skills>" not in lowered_text
    assert lowered_text.count("<skill_use>") == 1


def test_static_header_without_placeholders_keeps_legacy_append_order() -> None:
    """各 header 段之间用空行分隔（段间空行语义），但 append 顺序维持不变。"""
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM", cache=False)
    ctx.set_memory_usage("MEMORY", cache=False)
    ctx.set_subagent_strategy("SUBAGENT")
    ctx.set_skill_strategy("SKILL")

    lowered_text = _lowered_system_prompt(ctx)

    assert lowered_text == "SYSTEM\n\nMEMORY\n\nSUBAGENT\n\nSKILL"


def test_tool_strategy_placeholder_still_supported_for_older_custom_prompts() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM\n{{TOOL_STRATEGY}}\nTAIL", cache=False)
    ctx.set_tool_strategy("TOOL_STRATEGY_BODY")

    lowered_text = _lowered_system_prompt(ctx)

    assert lowered_text == "SYSTEM\nTOOL_STRATEGY_BODY\nTAIL"


def test_static_header_sections_are_blank_line_separated() -> None:
    """顶级 `#` section 之间必须存在空行分隔；section 内部标题与首行正文紧挨（无空行）。"""
    from comate_agent_sdk.context.lower import LoweringPipeline

    ctx = ContextIR()
    ctx.set_system_prompt("SOME BODY\n</system_notes>", cache=False)
    ctx.set_tool_strategy("# Using your tools\n- rule A")

    messages = LoweringPipeline.lower(ctx)
    text = str(messages[0].content)

    # </system_notes> 与 # Using your tools 之间必须隔一个空行
    assert "</system_notes>\n\n# Using your tools" in text
    # # 标题与正文首行之间保持单换行（不强制空行）
    assert "# Using your tools\n- rule A" in text
    assert "# Using your tools\n\n- rule A" not in text


def test_normalize_section_text_behaviour() -> None:
    from comate_agent_sdk.prompts import normalize_section_text

    # # 标题下紧跟正文 → 保持单换行
    assert normalize_section_text("# Title\n- bullet") == "# Title\n- bullet"
    # 顶级 # 标题下存在空行 → 吃掉空行，标题与正文紧挨
    assert normalize_section_text("# Title\n\n- bullet") == "# Title\n- bullet"
    # 条件渲染残留的多换行 → 先折叠再紧挨
    assert normalize_section_text("# Title\n\n\n- bullet") == "# Title\n- bullet"
    # 二级 ## 标题 → 保持原样（只处理顶级 #）
    assert normalize_section_text("## Sub\n\n- bullet") == "## Sub\n\n- bullet"
    # 段内出现 # 标题 → 同样吃掉其后的空行
    assert normalize_section_text("intro\n# Inner\n\n- bullet") == "intro\n# Inner\n- bullet"
    # 非 # 开头 → 保持原样
    assert normalize_section_text("- one\n- two") == "- one\n- two"
    # 连续 3+ 换行（非标题后）→ 折叠为一个空行
    assert normalize_section_text("A\n\n\n\nB") == "A\n\nB"
    # 首尾空白 → 去除
    assert normalize_section_text("\n\n  # Title\n\nbody\n\n") == "# Title\nbody"
    # 空字符串 → 空字符串
    assert normalize_section_text("") == ""
    assert normalize_section_text("   \n  \n") == ""


def test_project_context_lowered_after_system_prompt_and_before_tool_strategy() -> None:
    """PROJECT_CONTEXT must appear AFTER SYSTEM_PROMPT and BEFORE TOOL_STRATEGY in lowered output.

    语义：用户自定义 system_prompt（含 subagent 的 prompt）先建立身份，
    project_context 紧随其后给出空间坐标，再进入工具/策略说明。
    """
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.lower import LoweringPipeline

    ctx = ContextIR()
    ctx.set_system_prompt("You are a test agent.\n\n{{MEMORY_USAGE}}")
    ctx.set_project_context("<project_context>\nworking_directory: /tmp\n</project_context>")
    ctx.set_memory_usage("<memory_usage>mem</memory_usage>")
    ctx.set_tool_strategy("- **Read**: read files")

    messages = LoweringPipeline.lower(ctx)
    system_msg = messages[0]
    text = system_msg.content

    sp_pos = text.index("You are a test agent.")
    pc_pos = text.index("<project_context>")
    ts_pos = text.index("- **Read**")
    assert sp_pos < pc_pos, f"system_prompt ({sp_pos}) must come before project_context ({pc_pos})"
    assert pc_pos < ts_pos, f"project_context ({pc_pos}) must come before tool_strategy ({ts_pos})"
    # MEMORY_USAGE was inlined via {{MEMORY_USAGE}} template substitution — must not be duplicated
    assert text.count("<memory_usage>") == 1
