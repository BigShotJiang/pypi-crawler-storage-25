"""Tests for Argos Python SDK"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import httpx

from argos import create_client, ArgosClient, ArgosConfig, Decision, Event
from argos.errors import (
    ArgosError,
    ArgosAuthenticationError,
    ArgosRateLimitError,
    ArgosTimeoutError,
    ArgosCircuitOpenError,
)


class TestArgosConfig:
    """Test ArgosConfig."""
    
    def test_config_from_string(self):
        """Test creating config from API key string."""
        config = ArgosConfig(api_key="test_key")
        assert config.api_key == "test_key"
        assert config.base_url == "https://argos-api.tachynoix.net"
    
    def test_config_from_dict(self):
        """Test creating config from dict."""
        config = ArgosConfig({"api_key": "test_key", "base_url": "http://custom"})
        assert config.api_key == "test_key"
        assert config.base_url == "http://custom"


class TestDecision:
    """Test Decision model."""
    
    def test_decision_allowed(self):
        """Test allow decision."""
        decision = Decision(verdict="Allow", reason="No policy matched")
        assert decision.is_allowed
        assert not decision.is_blocked
    
    def test_decision_blocked(self):
        """Test block decision."""
        decision = Decision(verdict="Block", reason="Matched policy")
        assert decision.is_blocked
        assert not decision.is_allowed
    
    def test_decision_pending(self):
        """Test pending decision."""
        decision = Decision(verdict="Pending")
        assert decision.is_pending


class TestEvent:
    """Test Event model."""
    
    def test_event_creation(self):
        """Test creating an event."""
        event_data = {
            "ID": "test_id",
            "SessionID": "session_id",
            "EnvironmentID": "env_id",
            "Time": "2024-01-01T00:00:00Z",
            "Payload": {"event_type": "login"},
        }
        event = Event(**event_data)
        assert event.id == "test_id"
        assert event.payload["event_type"] == "login"


class TestCreateClient:
    """Test create_client helper."""
    
    def test_create_client_defaults(self):
        """Test create_client with defaults."""
        client = create_client(api_key="test_key")
        assert client.config.api_key == "test_key"
        assert client.config.base_url == "https://argos-api.tachynoix.net"
    
    def test_create_client_custom(self):
        """Test create_client with custom params."""
        client = create_client(api_key="test", base_url="http://custom")
        assert client.config.base_url == "http://custom"


class TestRetryLogic:
    """Test retry and circuit breaker logic."""
    
    def test_calculate_delay_exponential(self):
        """Test exponential backoff calculation."""
        client = create_client(
            api_key="test",
            retry_base_delay=1.0,
            retry_jitter=False,
        )
        
        delay1 = client._calculate_delay(1)
        delay2 = client._calculate_delay(2)
        delay3 = client._calculate_delay(3)
        
        # Exponential: 1s, 2s, 4s
        assert delay1 == 1.0
        assert delay2 == 2.0
        assert delay3 == 4.0
    
    def test_calculate_delay_linear(self):
        """Test linear backoff calculation."""
        client = create_client(
            api_key="test",
            retry_base_delay=1.0,
            retry_strategy="linear",
            retry_jitter=False,
        )
        
        delay1 = client._calculate_delay(1)
        delay2 = client._calculate_delay(2)
        delay3 = client._calculate_delay(3)
        
        # Linear: 1s, 2s, 3s
        assert delay1 == 1.0
        assert delay2 == 2.0
        assert delay3 == 3.0
    
    def test_calculate_delay_max(self):
        """Test delay capped at max."""
        client = create_client(
            api_key="test",
            retry_base_delay=10.0,
            retry_max_delay=5.0,
            retry_jitter=False,
        )
        
        delay = client._calculate_delay(10)  # Would be 10 * 2^9 = 5120
        assert delay == 5.0  # Capped at max
    
    def test_circuit_breaker_opens(self):
        """Test circuit breaker opens after threshold."""
        client = create_client(
            api_key="test",
            circuit_breaker_threshold=3,
        )
        
        # Record failures
        client._record_failure()
        client._record_failure()
        assert not client._is_circuit_open()
        
        # Third failure opens circuit
        client._record_failure()
        assert client._is_circuit_open()
    
    def test_circuit_breaker_resets_after_timeout(self):
        """Test circuit breaker resets after timeout."""
        client = create_client(
            api_key="test",
            circuit_breaker_threshold=1,
            circuit_breaker_timeout=0,  # Immediate reset
        )
        
        client._record_failure()
        assert client._is_circuit_open()
        
        # After timeout, should reset
        import time
        time.sleep(0.01)
        
        assert not client._is_circuit_open()
    
    def test_circuit_breaker_success(self):
        """Test success resets failure count."""
        client = create_client(
            api_key="test",
            circuit_breaker_threshold=3,
        )
        
        client._record_failure()
        client._record_failure()
        client._record_success()
        
        # Should be back to 0
        assert client._failure_count == 0


class TestQueueOperations:
    """Test event queue operations."""
    
    def test_queue_event(self):
        """Test queueing events."""
        client = create_client(api_key="test")
        
        client.queue_event(
            payload={"event_type": "test"},
            metadata={"externalID": "test_1"}
        )
        
        assert len(client._event_queue) == 1
    
    def test_queue_full(self):
        """Test queue size limit."""
        client = create_client(api_key="test", queue_size=2)
        
        client.queue_event({"event": 1})
        client.queue_event({"event": 2})
        client.queue_event({"event": 3})  # Should drop oldest
        
        assert len(client._event_queue) == 2
        # Oldest should be dropped
        assert client._event_queue[0]["event"] == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
