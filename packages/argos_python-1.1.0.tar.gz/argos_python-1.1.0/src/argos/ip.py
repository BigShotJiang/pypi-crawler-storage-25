import ipaddress
from typing import Optional, List, Union

def is_ip_in_cidr(ip_str: str, cidr_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        if '/' not in cidr_str:
            return ip == ipaddress.ip_address(cidr_str)
        network = ipaddress.ip_network(cidr_str, strict=False)
        return ip in network
    except ValueError:
        return False

def extract_client_ip(
    direct_ip: str, 
    x_forwarded_for: Optional[str] = None, 
    x_real_ip: Optional[str] = None, 
    trusted_proxies: Optional[List[str]] = None
) -> str:
    if not direct_ip:
        direct_ip = "unknown"
        
    if not trusted_proxies:
        return direct_ip

    is_trusted = False
    for cidr in trusted_proxies:
        if is_ip_in_cidr(direct_ip, cidr):
            is_trusted = True
            break
            
    if not is_trusted:
        return direct_ip

    if x_forwarded_for:
        parts = [p.strip() for p in x_forwarded_for.split(',')]
        for part in parts:
            if not part:
                continue
            part_trusted = False
            for cidr in trusted_proxies:
                if is_ip_in_cidr(part, cidr):
                    part_trusted = True
                    break
            
            if not part_trusted:
                try:
                    ipaddress.ip_address(part)
                    return part
                except ValueError:
                    pass

    if x_real_ip:
        try:
            ipaddress.ip_address(x_real_ip)
            return x_real_ip
        except ValueError:
            pass

    return direct_ip
