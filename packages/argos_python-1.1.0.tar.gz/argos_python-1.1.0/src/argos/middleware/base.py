"""Argos SDK - Base Middleware"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, Optional

from ..client import ArgosClient
from ..errors import ArgosError
from ..models import Decision

logger = logging.getLogger("argos.middleware")


class MiddlewareConfig:
    """Configuration for Argos middleware."""

    def __init__(
        self,
        mode: str = "async",
        include_headers: bool = True,
        include_body: bool = False,
        exclude_paths: Optional[list[str]] = None,
        identity_header: Optional[str] = "X-User-ID",
        custom_payload_builder: Optional[Callable] = None,
    ):
        self.mode = mode
        self.include_headers = include_headers
        self.include_body = include_body
        self.exclude_paths = exclude_paths or ["/health", "/metrics", "/_health"]
        self.identity_header = identity_header
        self.custom_payload_builder = custom_payload_builder


class BaseMiddleware(ABC):
    """Base class for Argos middleware."""

    def __init__(self, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        self.client = client
        self.config = config or MiddlewareConfig()
        self._queue_task: Optional[asyncio.Task] = None
        self._event_buffer: list[dict] = []

    @abstractmethod
    def get_request_data(self, request: Any) -> dict:
        """Extract relevant data from the request."""
        pass

    @abstractmethod
    def get_client_ip(self, request: Any) -> str:
        """Extract client IP from request."""
        pass

    @abstractmethod
    def get_user_id(self, request: Any) -> Optional[str]:
        """Extract user ID from request."""
        pass

    def should_skip(self, path: str) -> bool:
        """Check if path should be skipped."""
        for exclude in self.config.exclude_paths:
            if path.startswith(exclude):
                return True
        return False

    def build_payload(self, request: Any) -> dict:
        """Build the event payload from request."""
        if self.config.custom_payload_builder:
            return self.config.custom_payload_builder(request)

        data = self.get_request_data(request)

        payload = {
            "event_type": data.get("method", "request").lower(),
            "path": data.get("path", ""),
            "user_id": self.get_user_id(request) or data.get("user_id", "anonymous"),
            "ip_address": self.get_client_ip(request),
            "status": "success",
        }

        if self.config.include_headers and data.get("headers"):
            payload["headers"] = data.get("headers")

        if self.config.include_body and data.get("body"):
            payload["body"] = data.get("body")

        return payload

    async def process_sync(self, request: Any) -> Decision:
        """Process request synchronously - wait for decision."""
        payload = self.build_payload(request)
        client_ip = self.get_client_ip(request)
        env_id = self.client.get_environment_id()

        try:
            event = await self.client.aingest(
                payload=payload,
                metadata={
                    "source": "middleware-sync",
                    "client_ip": client_ip,
                    "env_id": env_id,
                },
            )
            # Use signal from ingest response directly
            signal = event.signal or "allow"
            return Decision(verdict=signal, reason="ingest_response")
        except ArgosError as e:
            logger.error(f"Error processing request: {e}")
            return Decision(verdict="allow", reason="error_allow")

    async def process_async(self, request: Any) -> Decision:
        """Process request asynchronously - queue and return pending."""
        payload = self.build_payload(request)
        client_ip = self.get_client_ip(request)
        env_id = self.client.get_environment_id()

        try:
            await self.client.aqueue_event(
                payload=payload,
                metadata={
                    "source": "middleware-async",
                    "client_ip": client_ip,
                    "env_id": env_id,
                },
            )
        except Exception as e:
            logger.error(f"Error queueing event: {e}")

        return Decision(verdict="allow", reason="async_pending")

    async def process(self, request: Any) -> Decision:
        """Process request based on mode - check blocklist first."""
        # Check if client IP is blocked before processing
        blocked, reason = await self.check_blocklist(request)
        if blocked:
            return Decision(verdict="block", reason=f"ip_blocked: {reason}")

        if self.config.mode == "sync":
            return await self.process_sync(request)
        elif self.config.mode == "async":
            return await self.process_async(request)
        else:
            return await self.process_async(request)

    async def check_blocklist(self, request: Any) -> tuple[bool, str]:
        """
        Check if the client IP is blocked.

        Returns:
            Tuple of (is_blocked: bool, reason: str)
        """
        client_ip = self.get_client_ip(request)
        if not client_ip or client_ip == "unknown":
            return False, ""

        try:
            blocked, reason = await self.client.ais_blocked(client_ip)
            return blocked, reason
        except Exception as e:
            logger.error(f"Error checking blocklist: {e}")
            return False, ""


def create_middleware(client: ArgosClient, mode: str = "async", **kwargs):
    """Create an Argos middleware function."""
    try:
        from .fastapi import FastAPIMiddleware

        return FastAPIMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    try:
        from .starlette import StarletteMiddleware

        return StarletteMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    try:
        from .flask import FlaskMiddleware

        return FlaskMiddleware(client, MiddlewareConfig(mode=mode, **kwargs))
    except ImportError:
        pass

    raise ImportError(
        "No compatible framework detected. Install with: pip install argos[fastapi] or argos[flask]"
    )
