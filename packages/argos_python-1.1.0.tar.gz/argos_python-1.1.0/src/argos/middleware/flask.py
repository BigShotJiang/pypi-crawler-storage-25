"""Argos SDK - Flask Middleware"""

import logging
from typing import Any, Optional

from .base import MiddlewareConfig
from ..client import ArgosClient
from ..models import Decision

logger = logging.getLogger("argos.middleware.flask")


class FlaskMiddleware:
    """Flask middleware for Argos security."""

    def __init__(self, app: Any, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        self.app = app
        self.client = client
        self.config = config or MiddlewareConfig()
        self._register_middleware()

    def _register_middleware(self):
        """Register the middleware with Flask."""
        self.app.before_request(self._before_request)
        self.app.after_request(self._after_request)

    def get_request_data(self, request) -> dict:
        """Extract data from Flask request."""
        data = {
            "method": request.method,
            "path": request.path,
            "query": request.query_string.decode() if request.query_string else "",
        }

        if request.method in ("POST", "PUT", "PATCH"):
            if request.data:
                data["body"] = request.data.decode("utf-8", errors="replace")
            elif request.form:
                form_data = {}
                for k, v in request.form.items():
                    form_data[k] = v
                data["form"] = form_data
            elif request.json:
                data["json"] = request.json

        if self.config.include_headers:
            data["headers"] = dict(request.headers)

        return data

    def get_client_ip(self, request) -> str:
        """Extract client IP from Flask request."""
        from ..ip import extract_client_ip

        direct_ip = request.remote_addr or "unknown"
        return extract_client_ip(
            direct_ip,
            request.headers.get("X-Forwarded-For"),
            request.headers.get("X-Real-IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request) -> Optional[str]:
        """Extract user ID from Flask request."""
        if self.config.identity_header:
            user_id = request.headers.get(self.config.identity_header)
            if user_id:
                return user_id

        for header in ["X-User-ID", "X-Auth-User-ID", "Remote-User"]:
            user_id = request.headers.get(header)
            if user_id:
                return user_id

        return None

    def build_payload(self, request) -> dict:
        """Build the event payload from request."""
        if self.config.custom_payload_builder:
            return self.config.custom_payload_builder(request)

        data = self.get_request_data(request)

        payload = {
            "event_type": data.get("method", "request").lower(),
            "path": data.get("path", ""),
            "user_id": self.get_user_id(request) or data.get("user_id", "anonymous"),
            "ip_address": self.get_client_ip(request),
            "status": "success",
        }

        if data.get("body"):
            payload["body"] = data["body"]
        elif data.get("form"):
            payload["form"] = data["form"]
        elif data.get("json"):
            payload["json"] = data["json"]

        if self.config.include_headers and data.get("headers"):
            payload["headers"] = data["headers"]

        return payload

    def should_skip(self, path: str) -> bool:
        """Check if path should be skipped."""
        for exclude in self.config.exclude_paths:
            if path.startswith(exclude):
                return True
        return False

    def _before_request(self):
        """Process request before it reaches the route handler."""
        from flask import request, g

        if self.should_skip(request.path):
            return None

        client_ip = self.get_client_ip(request)
        if client_ip and client_ip != "unknown":
            try:
                blocked, reason = self.client.is_blocked(client_ip)
                if blocked:
                    response = {"error": "blocked", "reason": "IP blocked by Argos: " + reason}
                    from flask import make_response

                    resp = make_response(response, 403)
                    resp.headers["X-Argos-Verdict"] = "block"
                    resp.headers["X-Argos-Reason"] = "ip_blocked:" + reason
                    return resp
            except Exception as e:
                logger.error(f"Error checking blocklist: {e}")

        if self.config.mode == "sync":
            try:
                payload = self.build_payload(request)
                client_ip = self.get_client_ip(request)
                env_id = self.client.get_environment_id()
                event = self.client.ingest(
                    payload=payload,
                    metadata={
                        "source": "middleware-flask-sync",
                        "client_ip": client_ip,
                        "env_id": env_id,
                    },
                )
                signal = event.signal or "allow"
                decision = Decision(verdict=signal, reason="ingest_response")
                g.argos_decision = decision

                if decision.verdict.lower() == "block":
                    return {"error": "blocked", "reason": decision.reason}, 403
            except Exception as e:
                logger.error(f"Error processing request: {e}")
        else:
            try:
                payload = self.build_payload(request)
                client_ip = self.get_client_ip(request)
                env_id = self.client.get_environment_id()
                self.client.queue_event(
                    payload=payload,
                    metadata={
                        "source": "middleware-flask-async",
                        "client_ip": client_ip,
                        "env_id": env_id,
                    },
                )
            except Exception as e:
                logger.error(f"Error queueing event: {e}")

        return None

    def _after_request(self, response):
        """Add Argos headers to response."""
        from flask import g

        if hasattr(g, "argos_decision"):
            decision = g.argos_decision
            response.headers["X-Argos-Verdict"] = decision.verdict
            response.headers["X-Argos-Reason"] = decision.reason
        else:
            response.headers["X-Argos-Verdict"] = "allow"
            response.headers["X-Argos-Reason"] = "async_pending"

        return response
