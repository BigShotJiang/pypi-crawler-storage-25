"""Argos SDK - FastAPI Middleware"""

import logging
from typing import Any, Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from .base import MiddlewareConfig
from ..client import ArgosClient

logger = logging.getLogger("argos.middleware.fastapi")


class FastAPIMiddleware(BaseHTTPMiddleware):
    """FastAPI middleware for Argos security."""

    def __init__(self, app: Any, client: ArgosClient, config: Optional[MiddlewareConfig] = None):
        super().__init__(app)
        self.client = client
        self.config = config or MiddlewareConfig()

    async def get_request_body(self, request: Request) -> dict:
        """Extract request body asynchronously."""
        try:
            body = await request.body()
            if body:
                return {"body": body.decode("utf-8", errors="replace")}
        except Exception:
            pass
        return {}

    async def get_request_data(self, request: Request) -> dict:
        """Extract data from FastAPI request."""
        data = {
            "method": request.method,
            "path": request.url.path,
            "query": str(request.url.query),
        }

        if request.method in ("POST", "PUT", "PATCH"):
            body_data = await self.get_request_body(request)
            data.update(body_data)

        if self.config.include_headers:
            headers_dict = {}
            for k, v in request.headers.items():
                headers_dict[k] = v
            data["headers"] = headers_dict

        return data

    def get_client_ip(self, request: Request) -> str:
        """Extract client IP from FastAPI request."""
        from ..ip import extract_client_ip

        direct_ip = "unknown"
        if request.client:
            direct_ip = request.client.host

        return extract_client_ip(
            direct_ip,
            request.headers.get("X-Forwarded-For"),
            request.headers.get("X-Real-IP"),
            self.client.config.trusted_proxies
        )

    def get_user_id(self, request: Request) -> Optional[str]:
        """Extract user ID from FastAPI request."""
        if self.config.identity_header:
            user_id = request.headers.get(self.config.identity_header)
            if user_id:
                return user_id

        for header in ["X-User-ID", "X-Auth-User-ID", "Remote-User"]:
            user_id = request.headers.get(header)
            if user_id:
                return user_id

        return None

    def should_skip(self, path: str) -> bool:
        """Check if path should be skipped."""
        for exclude in self.config.exclude_paths:
            if path.startswith(exclude):
                return True
        return False

    async def build_payload(self, request: Request) -> dict:
        """Build the event payload from request."""
        if self.config.custom_payload_builder:
            return self.config.custom_payload_builder(request)

        data = await self.get_request_data(request)

        payload = {
            "event_type": data.get("method", "request").lower(),
            "path": data.get("path", ""),
            "query": data.get("query", ""),
            "user_id": self.get_user_id(request) or data.get("user_id", "anonymous"),
            "ip_address": self.get_client_ip(request),
            "user_agent": request.headers.get("user-agent", ""),
            "status": "success",
        }

        if data.get("body"):
            payload["body"] = data["body"]

        if self.config.include_headers and data.get("headers"):
            payload["headers"] = data["headers"]

        return payload

    async def process_sync(self, request: Request) -> Any:
        """Process request synchronously - wait for decision."""
        from ..models import Decision

        payload = await self.build_payload(request)
        user_id = self.get_user_id(request)
        client_ip = self.get_client_ip(request)
        env_id = self.client.get_environment_id()

        try:
            event = await self.client.aingest(
                payload=payload,
                metadata={
                    "source": "middleware-sync",
                    "ipAddress": client_ip,
                    "userAgent": request.headers.get("user-agent", "") or "",
                    "externalID": user_id if user_id else "anonymous",
                    "client_ip": client_ip,
                    "env_id": env_id,
                },
            )

            # Debug logging
            logger.info(
                f"Event signal: {event.signal}, anomaly_score: {getattr(event, 'anomaly_score', None)}"
            )

            # Event now contains signal/verdict directly
            if event.signal == "BLOCK":
                score = getattr(event, "anomaly_score", 0)
                if score and score > 0:
                    reason = f"anomaly_score={score}"
                else:
                    reason = "blocked"
                return Decision(verdict="block", reason=reason)

            return Decision(verdict="allow", reason="ok")
        except Exception as e:
            logger.error(f"Error processing request: {e}")
            return Decision(verdict="allow", reason=f"error: {e}")

    async def process_async(self, request: Request) -> Any:
        """Process request asynchronously - queue and return pending."""
        from ..models import Decision

        payload = await self.build_payload(request)
        user_id = self.get_user_id(request)
        client_ip = self.get_client_ip(request)
        env_id = self.client.get_environment_id()

        try:
            await self.client.aqueue_event(
                payload=payload,
                metadata={
                    "source": "middleware-async",
                    "ipAddress": client_ip,
                    "userAgent": request.headers.get("user-agent", "") or "",
                    "externalID": user_id if user_id else "anonymous",
                    "client_ip": client_ip,
                    "env_id": env_id,
                },
            )
        except Exception as e:
            logger.error(f"Error queueing event: {e}")

        return Decision(verdict="allow", reason="async_pending")

    async def process(self, request: Request) -> Any:
        """Process request based on mode."""
        if self.config.mode == "sync":
            return await self.process_sync(request)
        else:
            return await self.process_async(request)

    async def check_blocklist(self, request: Request) -> tuple[bool, str]:
        """Check if the client IP is blocked."""
        client_ip = self.get_client_ip(request)
        if not client_ip or client_ip == "unknown":
            return False, ""

        try:
            blocked, reason = await self.client.ais_blocked(client_ip)
            return blocked, reason
        except Exception as e:
            logger.error(f"Error checking blocklist: {e}")
            # Don't block on errors - just log and continue
            return False, ""

    async def dispatch(self, request: Request, call_next):
        """Process the request through Argos."""
        if self.should_skip(request.url.path):
            return await call_next(request)

        blocked, reason = await self.check_blocklist(request)
        if blocked:
            return Response(
                content='{"error": "blocked", "reason": "IP blocked by Argos: ' + reason + '"}',
                status_code=403,
                media_type="application/json",
                headers={"X-Argos-Verdict": "block", "X-Argos-Reason": "ip_blocked:" + reason},
            )

        decision = await self.process(request)

        if decision.verdict.lower() == "block" and self.config.mode == "sync":
            return Response(
                content='{"error": "blocked", "reason": "' + decision.reason + '"}',
                status_code=403,
                media_type="application/json",
            )

        response = await call_next(request)
        response.headers["X-Argos-Verdict"] = decision.verdict
        response.headers["X-Argos-Reason"] = decision.reason

        return response
