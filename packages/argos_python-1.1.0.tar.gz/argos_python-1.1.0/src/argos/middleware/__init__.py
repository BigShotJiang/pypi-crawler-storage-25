"""Argos SDK - Middleware"""

from .base import BaseMiddleware, MiddlewareConfig, create_middleware


def __getattr__(name):
    if name == "FlaskMiddleware":
        from .flask import FlaskMiddleware
        return FlaskMiddleware
    elif name == "FastAPIMiddleware":
        from .fastapi import FastAPIMiddleware
        return FastAPIMiddleware
    elif name == "StarletteMiddleware":
        from .starlette import StarletteMiddleware
        return StarletteMiddleware
    elif name == "DjangoMiddleware":
        from .django import DjangoMiddleware
        return DjangoMiddleware
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BaseMiddleware",
    "MiddlewareConfig", 
    "create_middleware",
    "FlaskMiddleware",
    "FastAPIMiddleware",
    "StarletteMiddleware",
    "DjangoMiddleware",
]
