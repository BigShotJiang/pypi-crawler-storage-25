"""Argos SDK - Error Types"""


class ArgosError(Exception):
    """Base exception for all Argos errors."""

    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class ArgosAPIError(ArgosError):
    """Exception for API errors (non-2xx responses)."""

    def __init__(self, message: str, status_code: int, response: str):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class ArgosAuthenticationError(ArgosAPIError):
    """Exception for authentication errors (401)."""

    pass


class ArgosRateLimitError(ArgosAPIError):
    """Exception for rate limit errors (429)."""

    def __init__(self, message: str, status_code: int, response: str, retry_after: float):
        super().__init__(message, status_code, response)
        self.retry_after = retry_after


class ArgosTimeoutError(ArgosError):
    """Exception for timeout errors."""

    pass


class ArgosCircuitOpenError(ArgosError):
    """Exception when circuit breaker is open."""

    pass


class ArgosValidationError(ArgosError):
    """Exception for validation errors."""

    pass


class ArgosQueueFullError(ArgosError):
    """Exception when event queue is full."""

    pass


# Backwards compatibility aliases
argosError = ArgosError
argosAPIError = ArgosAPIError
argosAuthenticationError = ArgosAuthenticationError
argosRateLimitError = ArgosRateLimitError
argosTimeoutError = ArgosTimeoutError
argosCircuitOpenError = ArgosCircuitOpenError
argosValidationError = ArgosValidationError
argosQueueFullError = ArgosQueueFullError
