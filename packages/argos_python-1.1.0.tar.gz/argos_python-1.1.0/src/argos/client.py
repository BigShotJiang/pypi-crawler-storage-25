"""Argos Security SDK - Core Client"""

import asyncio
import json
import logging
import random
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import dataclass
from enum import Enum
from queue import Queue, Full
from threading import Lock
from typing import Any, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import urljoin

from .errors import (
    ArgosError,
    ArgosAPIError,
    ArgosAuthenticationError,
    ArgosRateLimitError,
    ArgosTimeoutError,
    ArgosCircuitOpenError,
)
from .models import Decision, Event, BlockStatus, BlocklistEntry

logger = logging.getLogger("argos")


class RetryStrategy(str, Enum):
    """Retry strategy for failed requests."""

    NONE = "none"
    EXPONENTIAL = "exponential"
    LINEAR = "linear"


@dataclass
class ArgosConfig:
    """Configuration for the Argos client."""

    api_key: str
    base_url: str = "https://argos-api.tachynoix.net"
    timeout: float = 30.0
    max_retries: int = 3
    retry_strategy: RetryStrategy = RetryStrategy.EXPONENTIAL
    retry_base_delay: float = 0.5
    retry_max_delay: float = 30.0
    retry_jitter: bool = True
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout: float = 60.0
    max_connections: int = 100
    queue_size: int = 1000
    sync_mode: bool = False
    auto_block_on_block: bool = False  # Automatically block IP when ingest returns BLOCK verdict
    auto_block_ttl: float = 3600.0  # TTL in seconds for auto-blocked IPs (default 1 hour)
    trusted_proxies: Optional[list[str]] = None
    environment_id: Optional[str] = None  # Auto-detected from API key


class ArgosClient:
    """
    Main client for interacting with the Argos security API.

    Features:
    - Synchronous and asynchronous operations
    - Automatic retry with exponential backoff
    - Circuit breaker pattern
    - Request queuing for resilience

    Example:
        client = ArgosClient(
            api_key="argus_env_...",
            base_url="https://api.argos.io"
        )

        # Ingest event
        event = client.ingest({
            "event_type": "login",
            "user_id": "user123",
            "status": "success"
        })

        # Get decision
        decision = client.get_decision(event.id)
        if decision.verdict == "block":
            # block the request
            pass
    """

    def __init__(self, config: ArgosConfig | dict | str, **kwargs):
        if isinstance(config, str):
            config = {"api_key": config}
        if isinstance(config, dict):
            config = ArgosConfig(**config, **kwargs)

        self.config = config

        # Circuit breaker state
        self._failure_count = 0
        self._last_failure_time: Optional[float] = None
        self._circuit_open = False
        self._lock = Lock()

        # Queue for offline resilience
        self._event_queue: list[dict] = []
        self._queue_lock = Lock()

        # Auto-detect environment_id if not provided
        if not self.config.environment_id:
            self._detect_environment()

    def _detect_environment(self) -> None:
        """Auto-detect environment_id from API key."""
        try:
            response = self._request("GET", "/api/v1/me")
            self.config.environment_id = response.get("environment_id", "")
            if self.config.environment_id:
                logger.info(f"[Argos] Auto-detected environment_id: {self.config.environment_id}")
        except Exception as e:
            logger.warning(f"[Argos] Could not auto-detect environment_id: {e}")

    def get_environment_id(self) -> str:
        """Get the environment_id for this client."""
        return self.config.environment_id or ""

    def _get_headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "X-API-Key": self.config.api_key,
            "User-Agent": "Argos-Python-SDK/1.0.0",
        }

    def _is_circuit_open(self) -> bool:
        """Check if circuit breaker is open."""
        if not self._circuit_open:
            return False

        if self._last_failure_time:
            elapsed = time.time() - self._last_failure_time
            if elapsed > self.config.circuit_breaker_timeout:
                logger.info("Circuit breaker: attempting reset")
                self._circuit_open = False
                self._failure_count = 0
                return False

        return True

    def _record_failure(self) -> None:
        """Record a failure for circuit breaker."""
        with self._lock:
            self._failure_count += 1
            self._last_failure_time = time.time()

            if self._failure_count >= self.config.circuit_breaker_threshold:
                self._circuit_open = True
                logger.warning(f"Circuit breaker opened after {self._failure_count} failures")

    def _record_success(self) -> None:
        """Record a success for circuit breaker."""
        with self._lock:
            self._failure_count = 0
            self._circuit_open = False

    def _calculate_delay(self, attempt: int) -> float:
        """Calculate retry delay with exponential backoff and optional jitter."""
        if self.config.retry_strategy == RetryStrategy.LINEAR:
            delay = self.config.retry_base_delay * attempt
        else:
            delay = self.config.retry_base_delay * (2 ** (attempt - 1))

        delay = min(delay, self.config.retry_max_delay)

        if self.config.retry_jitter:
            delay = delay * (0.5 + random.random() * 0.5)

        return delay

    def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        """Make HTTP request with retry logic and circuit breaker."""
        if self._is_circuit_open():
            raise ArgosCircuitOpenError("Circuit breaker is open. Too many recent failures.")

        last_error: Exception = ArgosError("Unknown error")

        url = urljoin(self.config.base_url, endpoint)
        if params:
            query_string = "&".join(f"{k}={v}" for k, v in params.items())
            url = f"{url}?{query_string}"

        for attempt in range(self.config.max_retries + 1):
            try:
                data = json.dumps(json_data).encode("utf-8") if json_data else None

                request = Request(
                    url,
                    data=data,
                    headers=self._get_headers(),
                    method=method,
                )

                with urlopen(request, timeout=self.config.timeout) as response:
                    self._record_success()
                    response_body = response.read().decode("utf-8")
                    if response_body:
                        return json.loads(response_body)
                    return {}

            except HTTPError as e:
                body = e.read().decode("utf-8") if e.fp else ""

                # Handle 403 as a valid response (BLOCK verdict) not an error
                if e.code == 403:
                    try:
                        resp_data = json.loads(body) if body else {}
                        if "event_id" in resp_data:
                            # Valid security response with event data
                            return resp_data
                    except (json.JSONDecodeError, ValueError):
                        pass

                # Don't record success on error
                self._record_failure()

                if e.code == 401:
                    raise ArgosAuthenticationError(
                        "Invalid API key",
                        e.code,
                        body,
                    )
                elif e.code == 429:
                    retry_after = 60.0
                    try:
                        retry_after = float(e.headers.get("Retry-After", 60))
                    except (ValueError, TypeError):
                        pass
                    raise ArgosRateLimitError(
                        "Rate limit exceeded",
                        e.code,
                        body,
                        retry_after,
                    )
                elif e.code >= 500:
                    raise ArgosAPIError(
                        f"Server error: {e.code}",
                        e.code,
                        body,
                    )
                else:
                    raise ArgosAPIError(
                        f"API error: {e.code}",
                        e.code,
                        body,
                    )

            except URLError as e:
                last_error = ArgosError(f"Connection error: {e.reason}")
                if attempt < self.config.max_retries:
                    delay = self._calculate_delay(attempt + 1)
                    logger.warning(f"Connection error, retrying in {delay:.2f}s")
                    time.sleep(delay)
                else:
                    self._record_failure()

            except TimeoutError as e:
                last_error = ArgosTimeoutError(f"Request timeout: {e}")
                if attempt < self.config.max_retries:
                    delay = self._calculate_delay(attempt + 1)
                    logger.warning(f"Request timeout, retrying in {delay:.2f}s")
                    time.sleep(delay)
                else:
                    self._record_failure()

            except Exception as e:
                last_error = ArgosError(f"Unexpected error: {e}")
                self._record_failure()
                raise

        raise last_error

    def ingest(self, payload: dict, metadata: Optional[dict] = None) -> Event:
        """
        Ingest a single event to the Argos API.

        Args:
            payload: Event data (event_type, user_id, status, etc.)
            metadata: Optional metadata (externalID, sessionID, source, etc.)

        Returns:
            Event: The created event with ID and details
        """
        data = {"payload": payload}
        if metadata:
            # Ensure externalID is present (required by backend)
            if "externalID" not in metadata and "external_id" not in metadata:
                metadata["externalID"] = "anonymous"
            data["metadata"] = metadata

        response = self._request("POST", "/api/v1/ingest", json_data=data)

        # Build event with signal/verdict from response
        event = Event(
            id=response.get("event_id"),
            event_id=response.get("event_id"),
            signal=response.get("verdict"),
            anomaly_score=response.get("anomaly_score", 0),
            payload=payload,
        )

        # Auto-block IP if verdict is BLOCK and auto-block is enabled
        if self.config.auto_block_on_block and response.get("verdict", "").upper() == "BLOCK":
            client_ip = metadata.get("client_ip") if metadata else None
            env_id = metadata.get("env_id") if metadata else None
            if client_ip and env_id:
                try:
                    self.block_ip(client_ip, env_id, "auto_blocked: ML verdict")
                    logger.info(f"[Argos] Auto-blocked IP {client_ip} after BLOCK verdict")
                except Exception as e:
                    logger.error(f"[Argos] Auto-block failed for IP {client_ip}: {e}")

        return event

    def ingest_batch(
        self,
        payloads: list[dict],
        metadata: Optional[list[dict]] = None,
    ) -> list[Event]:
        """
        Ingest multiple events in a single batch request.
        """
        data = {"payloads": payloads}

        # Ensure each metadata has externalID
        formatted_metadata = []
        if metadata:
            for i, m in enumerate(metadata):
                if m is None:
                    m = {}
                if "externalID" not in m and "external_id" not in m:
                    m["externalID"] = f"batch_{i}"
                formatted_metadata.append(m)
            data["metadata"] = formatted_metadata
        else:
            # Create default metadata for each payload
            for i in range(len(payloads)):
                formatted_metadata.append({"externalID": f"batch_{i}"})
            data["metadata"] = formatted_metadata

        response = self._request("POST", "/api/v1/ingest/batch", json_data=data)

        # Handle response - each item has event_id
        events = []
        if isinstance(response, list):
            for i, resp in enumerate(response):
                if isinstance(resp, dict):
                    events.append(
                        Event(
                            ID=resp.get("event_id"),
                            id=resp.get("event_id"),
                            signal=resp.get("verdict"),
                            anomaly_score=resp.get("anomaly_score"),
                            payload=payloads[i] if i < len(payloads) else {},
                        )
                    )
        return events

    def get_decision(self, event_id: str) -> Decision:
        """
        Get the decision/verdict for an event.
        """
        if not event_id:
            return Decision(verdict="allow", reason="no_event_id")

        try:
            response = self._request("GET", f"/api/v1/events/{event_id}/decision")
            return Decision(
                verdict=response.get("verdict", "allow"),
                reason=response.get("reason", ""),
            )
        except Exception as e:
            # If get_decision fails, return a default allow decision
            return Decision(verdict="allow", reason=f"decision_unavailable: {e}")

    def queue_event(self, payload: dict, metadata: Optional[dict] = None) -> None:
        """
        Queue an event for later processing.
        """
        with self._queue_lock:
            if len(self._event_queue) >= self.config.queue_size:
                logger.warning("Event queue full, dropping oldest event")
                self._event_queue.pop(0)

            event = {"payload": payload}
            if metadata:
                event["metadata"] = metadata
            self._event_queue.append(event)

    def flush_queue(self) -> list[Event]:
        """
        Flush all queued events to the API.
        """
        with self._queue_lock:
            if not self._event_queue:
                return []

            payloads = []
            metadata = []

            for event in self._event_queue:
                payloads.append(event["payload"])
                if "metadata" in event:
                    m = event["metadata"]
                    # Ensure externalID
                    if "externalID" not in m and "external_id" not in m:
                        m["externalID"] = "queued_event"
                    metadata.append(m)

            self._event_queue.clear()

        if metadata:
            return self.ingest_batch(payloads, metadata)
        else:
            return self.ingest_batch(payloads)

    def health_check(self) -> dict:
        """Check the health of the Argos API."""
        return self._request("GET", "/health")

    def is_blocked(self, ip: str) -> tuple[bool, str]:
        """
        Check if an IP is blocked in Argos.

        Args:
            ip: The IP address to check

        Returns:
            Tuple of (is_blocked: bool, reason: str)
        """
        response = self._request("GET", "/api/v1/admin/blocklist/ip/check", params={"ip": ip})
        blocked = response.get("blocked", False)
        reason = response.get("reason", "")
        return blocked, reason

    def is_user_blocked(self, user_id: str) -> tuple[bool, str]:
        """
        Check if a user_id is blocked in Argos.

        Args:
            user_id: The user ID to check

        Returns:
            Tuple of (is_blocked: bool, reason: str)
        """
        response = self._request(
            "GET", "/api/v1/admin/blocklist/user/check", params={"user_id": user_id}
        )
        blocked = response.get("blocked", False)
        reason = response.get("reason", "")
        return blocked, reason

    def check_access(self, ip: Optional[str] = None, user_id: Optional[str] = None) -> BlockStatus:
        """
        Check if an IP or user_id is blocked.

        Returns:
            BlockStatus: Detailed block information
        """
        status = BlockStatus(blocked=False)

        if ip:
            blocked, reason = self.is_blocked(ip)
            status.ip_blocked = blocked
            status.ip_reason = reason
            if blocked:
                status.blocked = True
                status.block_reason = reason

        if user_id:
            blocked, reason = self.is_user_blocked(user_id)
            status.user_blocked = blocked
            status.user_reason = reason
            if blocked:
                status.blocked = True
                if not status.block_reason:
                    status.block_reason = reason
                else:
                    status.block_reason = f"{status.block_reason}; {reason}"

        return status

    def get_blocklist(self) -> list[BlocklistEntry]:
        """
        Get all blocklist entries.

        Returns:
            List of blocklist entries
        """
        response = self._request("GET", "/api/v1/admin/blocklist")
        entries = []
        if isinstance(response, list):
            for item in response:
                if isinstance(item, dict):
                    entries.append(
                        BlocklistEntry(
                            id=item.get("id"),
                            type=item.get("type"),
                            value=item.get("value"),
                            reason=item.get("reason", ""),
                            blocked_at=item.get("blocked_at", ""),
                            expires_at=item.get("expires_at"),
                            environment_id=item.get("environment_id", ""),
                        )
                    )
        return entries

    def block_ip(self, ip: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """
        Add an IP to the blocklist.

        Args:
            ip: The IP address to block
            environment_id: The environment ID
            reason: Optional reason for blocking

        Returns:
            BlocklistEntry: The created blocklist entry
        """
        data = {
            "type": "ip",
            "value": ip,
            "environment_id": environment_id,
        }
        if reason:
            data["reason"] = reason

        logger.info(f"[Argos.block_ip] sending data={data}")
        response = self._request("POST", "/api/v1/admin/blocklist", json_data=data)
        logger.info(f"[Argos.block_ip] response={response}")
        return BlocklistEntry(
            id=response.get("id"),
            type=response.get("type"),
            value=response.get("value"),
            reason=response.get("reason", ""),
            blocked_at=response.get("blocked_at", ""),
            expires_at=response.get("expires_at"),
            environment_id=response.get("environment_id", ""),
        )

    def block_user(self, user_id: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """
        Add a user to the blocklist.

        Args:
            user_id: The user ID to block
            environment_id: The environment ID
            reason: Optional reason for blocking

        Returns:
            BlocklistEntry: The created blocklist entry
        """
        data = {
            "type": "user",
            "value": user_id,
            "environment_id": environment_id,
        }
        if reason:
            data["reason"] = reason

        response = self._request("POST", "/api/v1/admin/blocklist", json_data=data)
        return BlocklistEntry(
            id=response.get("id"),
            type=response.get("type"),
            value=response.get("value"),
            reason=response.get("reason", ""),
            blocked_at=response.get("blocked_at", ""),
            expires_at=response.get("expires_at"),
            environment_id=response.get("environment_id", ""),
        )

    def unblock(self, entry_id: str) -> None:
        """
        Remove an entry from the blocklist.

        Args:
            entry_id: The blocklist entry ID to remove
        """
        self._request("DELETE", f"/api/v1/admin/blocklist/{entry_id}")

    async def ahealth_check(self) -> dict:
        """Check the health of the Argos API (async)."""
        return self.health_check()

    async def ais_blocked(self, ip: str) -> tuple[bool, str]:
        """
        Check if an IP is blocked in Argos (async).
        """
        return self.is_blocked(ip)

    async def ais_user_blocked(self, user_id: str) -> tuple[bool, str]:
        """
        Check if a user_id is blocked in Argos (async).
        """
        return self.is_user_blocked(user_id)

    async def acheck_access(
        self, ip: Optional[str] = None, user_id: Optional[str] = None
    ) -> BlockStatus:
        """
        Check if an IP or user_id is blocked (async).
        """
        return self.check_access(ip, user_id)

    async def aget_blocklist(self) -> list[BlocklistEntry]:
        """Get all blocklist entries (async)."""
        return self.get_blocklist()

    async def ablock_ip(self, ip: str, environment_id: str, reason: str = "") -> BlocklistEntry:
        """Add an IP to the blocklist (async)."""
        return self.block_ip(ip, environment_id, reason)

    async def ablock_user(
        self, user_id: str, environment_id: str, reason: str = ""
    ) -> BlocklistEntry:
        """Add a user to the blocklist (async)."""
        return self.block_user(user_id, environment_id, reason)

    async def aunblock(self, entry_id: str) -> None:
        """Remove an entry from the blocklist (async)."""
        return self.unblock(entry_id)

    async def aingest(self, payload: dict, metadata: Optional[dict] = None) -> Event:
        """Ingest a single event to the Argos API (async)."""
        return self.ingest(payload, metadata)

    async def aingest_batch(
        self, payloads: list[dict], metadata: Optional[list[dict]] = None
    ) -> list[Event]:
        """Ingest multiple events in a single batch request (async)."""
        return self.ingest_batch(payloads, metadata)

    async def aget_decision(self, event_id: str) -> Decision:
        """Get the decision/verdict for an event (async)."""
        return self.get_decision(event_id)

    async def aqueue_event(self, payload: dict, metadata: Optional[dict] = None) -> None:
        """Queue an event for later processing (async)."""
        self.queue_event(payload, metadata)

    async def aflush_queue(self) -> list[Event]:
        """Flush all queued events to the API (async)."""
        return self.flush_queue()

    def close(self) -> None:
        """Close the client and release resources."""
        pass

    def __enter__(self) -> "ArgosClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"ArgosClient(base_url={self.config.base_url}, api_key=***)"


# Convenience function for quick initialization
def create_client(
    api_key: str,
    base_url: str = "https://argos-api.tachynoix.net",
    **kwargs,
) -> ArgosClient:
    """
    Create an ArgosClient with sensible defaults.

    Args:
        api_key: Your Argos API key (env or environment key)
        base_url: Base URL of the Argos API
        **kwargs: Additional configuration options

    Returns:
        ArgosClient: Configured client instance
    """
    return ArgosClient(
        {
            "api_key": api_key,
            "base_url": base_url,
            **kwargs,
        }
    )
