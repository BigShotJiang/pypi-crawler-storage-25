"""argos SDK - Data Models"""

from datetime import datetime
from typing import Any, Optional


class Event:
    """Represents an event sent to argos."""

    def __init__(
        self,
        ID: Optional[str] = None,
        id: Optional[str] = None,
        event_id: Optional[str] = None,
        SessionID: Optional[str] = None,
        session_id: Optional[str] = None,
        EnvironmentID: Optional[str] = None,
        environment_id: Optional[str] = None,
        Time: Optional[str] = None,
        time: Optional[str] = None,
        created_at: Optional[str] = None,
        Payload: Optional[dict[str, Any]] = None,
        payload: Optional[dict[str, Any]] = None,
        anomaly_score: Optional[float] = None,
        signal: Optional[str] = None,
        Session: Optional[dict] = None,
        Environment: Optional[dict] = None,
        Decision: Optional[dict] = None,
        Investigations: Optional[list] = None,
    ):
        self.id = ID or id or event_id
        self.event_id = event_id
        self.session_id = SessionID or session_id
        self.environment_id = EnvironmentID or environment_id
        self.time = Time or time or created_at
        self.payload = Payload or payload
        self.session = Session
        self.environment = Environment
        self.decision = Decision
        self.investigations = Investigations
        self.anomaly_score = anomaly_score
        self.signal = signal

    def __repr__(self) -> str:
        event_type = "unknown"
        if self.payload and isinstance(self.payload, dict):
            event_type = self.payload.get("event_type", "unknown")
        return f"Event(id={self.id}, type={event_type})"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "environment_id": self.environment_id,
            "time": self.time,
            "payload": self.payload,
        }


class Decision:
    """Represents a decision/verdict from argos."""

    def __init__(
        self,
        verdict: str,
        reason: str = "",
    ):
        self.verdict = verdict
        self.reason = reason

    def __repr__(self) -> str:
        return f"Decision(verdict={self.verdict}, reason={self.reason})"

    @property
    def is_allowed(self) -> bool:
        return self.verdict.lower() == "allow"

    @property
    def is_blocked(self) -> bool:
        return self.verdict.lower() == "block"

    @property
    def is_pending(self) -> bool:
        return self.verdict.lower() == "pending"

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "reason": self.reason,
        }


class Investigation:
    """Represents an investigation created by argos."""

    def __init__(
        self,
        id: str,
        event_id: str,
        status: str,
        created_at: str,
        findings: Optional[dict] = None,
    ):
        self.id = id
        self.event_id = event_id
        self.status = status
        self.created_at = created_at
        self.findings = findings

    def __repr__(self) -> str:
        return f"Investigation(id={self.id}, status={self.status})"


class Session:
    """Represents a session from argos."""

    def __init__(
        self,
        id: str,
        identity_id: str,
        environment_id: str,
        started_at: str,
        ended_at: Optional[str] = None,
        user_agent: Optional[str] = None,
        ip_address: Optional[str] = None,
    ):
        self.id = id
        self.identity_id = identity_id
        self.environment_id = environment_id
        self.started_at = started_at
        self.ended_at = ended_at
        self.user_agent = user_agent
        self.ip_address = ip_address

    def __repr__(self) -> str:
        return f"Session(id={self.id})"


class BlockStatus:
    """Represents the result of an access check."""

    def __init__(
        self,
        ip_blocked: bool = False,
        ip_reason: str = "",
        user_blocked: bool = False,
        user_reason: str = "",
        blocked: bool = False,
        block_reason: str = "",
    ):
        self.ip_blocked = ip_blocked
        self.ip_reason = ip_reason
        self.user_blocked = user_blocked
        self.user_reason = user_reason
        self.blocked = blocked
        self.block_reason = block_reason

    def __repr__(self) -> str:
        return f"BlockStatus(blocked={self.blocked}, reason={self.block_reason})"

    def to_dict(self) -> dict:
        return {
            "ip_blocked": self.ip_blocked,
            "ip_reason": self.ip_reason,
            "user_blocked": self.user_blocked,
            "user_reason": self.user_reason,
            "blocked": self.blocked,
            "block_reason": self.block_reason,
        }


class BlocklistEntry:
    """Represents an entry in the blocklist."""

    def __init__(
        self,
        id: str,
        type: str,
        value: str,
        reason: str = "",
        blocked_at: str = "",
        expires_at: Optional[str] = None,
        environment_id: str = "",
    ):
        self.id = id
        self.type = type
        self.value = value
        self.reason = reason
        self.blocked_at = blocked_at
        self.expires_at = expires_at
        self.environment_id = environment_id

    def __repr__(self) -> str:
        return f"BlocklistEntry(type={self.type}, value={self.value})"

    @property
    def is_ip(self) -> bool:
        return self.type == "ip"

    @property
    def is_user(self) -> bool:
        return self.type == "user"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "value": self.value,
            "reason": self.reason,
            "blocked_at": self.blocked_at,
            "expires_at": self.expires_at,
            "environment_id": self.environment_id,
        }
