import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy
from argos import create_client
from argos.middleware.flask import FlaskMiddleware
from argos.middleware.base import MiddlewareConfig

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

#JIDAR_API_KEY = "89f4d2b116960f338cb13a047ca4b428"
JIDAR_API_KEY = "argus_env_279167afabb2ce2e0c95a441dca8cd9f"
JIDAR_BASE_URL = "http://localhost:7656"

#JIDAR_BASE_URL = "http://argos-api.tachyonix.net"

argos_client = create_client(
    api_key=JIDAR_API_KEY,
    base_url=JIDAR_BASE_URL,
    auto_block_on_block=True,
    auto_block_ttl=3600.0,
)

FlaskMiddleware(app, argos_client, MiddlewareConfig(
    mode="sync",
    include_headers=True,
    exclude_paths=["/static"],
))


class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    complete = db.Column(db.Boolean, default=False)


@app.route('/')
def index():
    todos = Todo.query.all()
    return render_template('index.html', todos=todos)


@app.route('/add', methods=['POST'])
def add():
    title = request.form.get('title')
    if title:
        new_todo = Todo(title=title)
        db.session.add(new_todo)
        db.session.commit()
    return redirect(url_for('index'))


@app.route('/update/<int:todo_id>')
def update(todo_id):
    todo = Todo.query.get_or_404(todo_id)
    todo.complete = not todo.complete
    db.session.commit()
    return redirect(url_for('index'))


@app.route('/delete/<int:todo_id>')
def delete(todo_id):
    todo = Todo.query.get_or_404(todo_id)
    db.session.delete(todo)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
