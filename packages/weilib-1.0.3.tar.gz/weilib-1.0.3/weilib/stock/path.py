import os


def data_directory():
    """
     存储数据的文件侠   
     返回值：
        str:文件夹名称 stock_data
    """
    directory = 'stock_data'
    # 检查目录是否存在，如果不存在则创建
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory

def save_path(file_name:str=None, file_extension:str='csv'):
    """
    获取指定股票数据的保存路径。

    参数：
        file_name: 文件名如 'his_603416'，如果为 None 则返回目录路径
        file_extension: 文件扩展名，默认为 'csv'
    返回值：
        str: 数据保存的完整路径，如 'stock_data/his_603416.csv'
    """
    directory = data_directory()
    if file_name:
        file_name = f"{file_name}.{file_extension}"
        return os.path.join(directory, file_name)
    else:
        return directory
    
def stock_his_transaction_data_file_name(code:str,file_extension='csv'):
    '''
    获取指定股票历史交易数据的保存路径。

    参数：
        code: 股票代码，如 '603416'
        file_extension: 文件扩展名，默认为 'csv'
    返回值：
        str: 数据保存的完整路径，如 'stock_data/his_603416.csv
    '''
    code = 'his_'+code
    return save_path(file_name=code, file_extension=file_extension)

def stock_all_latest_transaction_data_file_name():
    '''
    获取所有股票最新交易数据的保存路径。
    '''
    name = 'stock_all_latest_transaction_data'
    return save_path(file_name=name)

def boards_list_data_file_name():
    '''
    获取股票板块数据列表的保存路径。
    '''
    name = 'boards_list_data'
    return save_path(file_name=name)

def board_stocks_data_file_name(board_code:str):
    '''
    获取指定板块成份股数据的保存路径。

    参数：
        board_code: 板块代码，如 'BK0801'
    返回值：
        str: 数据保存的完整路径，如 'stock_data/board_stocks_data_BK0801.csv'
    '''
    name = 'board_stocks_data_'+board_code
    return save_path(file_name=name)
