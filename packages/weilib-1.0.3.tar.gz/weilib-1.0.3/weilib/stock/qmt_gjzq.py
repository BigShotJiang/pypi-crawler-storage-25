from datetime import datetime, timedelta
import os
import sys
import pandas as pd
from tqdm import tqdm
from xtquant import xtdata
import path
import indicator
'''
国金证券数据接口
'''

def get_stocks_base_info(stock_list):
    """
        获取股票基本信息。
        参数：
            stock_list: 股票代码列表
        返回：
            股票详细信息的 DataFrame
    """
    normal_stocks = []
    for code in stock_list:
        detail = xtdata.get_instrument_detail(code)
        # if not detail:
        #     continue  # 找不到合约，跳过
        
        if detail.get('TotalVolume', 0)>0:  # 只保留正常上市的股票 
             normal_stocks.append({
            '代码': code,
            '股票代码': detail.get('ExchangeCode', ''),
            '市场': detail.get('ExchangeID', ''),
            '名称': detail.get('InstrumentName', ''),
            'IPO日期': detail.get('OpenDate', '19000101'),
            '上市日期': detail.get('OpenDate', '19000101'),
            '退市日期': detail.get('ExpireDate', '99999999'),
            '交易日期': detail.get('TradingDay', ''),
            '昨收': detail.get('PreClose', 0.0),
            '涨停价': detail.get('UpStopPrice', 0.0),
            '跌停价': detail.get('DownStopPrice', 0.0),
            '总股本': detail.get('TotalVolume', 0),
            '流通股': detail.get('FloatVolume', 0),
            '类型': detail.get('ProductID', 0),
            '是否停牌': '是' if detail.get('InstrumentStatus',0)>0 else '否',
            '停牌天数': detail.get('InstrumentStatus',0),
            '是否交易': detail.get('IsTrading ', 0),
            })
    normal_stocks = pd.DataFrame(normal_stocks)
    return normal_stocks

def get_sector_stock_list(sector_name:str="沪深京A股"):
    """
        获取指定板块的股票代码列表。
        参数：
            sector_name: 板块名称，如 "沪深京A股"
        返回：
            df: 包含股票代码、名称、市场等信息的 DataFrame
    """
    stock_list = xtdata.get_stock_list_in_sector(sector_name)
    # 过滤：只保留 以 0、3、6、9 开头的股票代码
    stock_list = [s for s in stock_list if s[0] in ('0', '3', '6', '9')]
    stock_list = get_stocks_base_info(stock_list)
    return stock_list


def all_stock_latest_transaction_data():
    """
    获取所有A股的最新数据，包含日期、代码、最新价格、开盘价、最高价、最低价和成交量。
    返回：
        df: 包含所有A股最新数据的 DataFrame
    """

    # stock_list = xtdata.get_stock_list_in_sector("沪深京A股")
    stock_list = get_sector_stock_list("沪深京A股")
    tick_data = xtdata.get_full_tick(stock_list['代码'].tolist())

    #转换成列表 → 再生成 DataFrame
    result = []
    for code, data in tick_data.items():
        timetag = data.get("timetag", "")
        # timetag 格式：20260401102530 （年月日时分秒）
        if len(timetag) >= 8:
            date = timetag[:8]              # 取出 20260401
            date = f"{date[:4]}-{date[4:6]}-{date[6:8]}"  # 转成 2026-04-01
        else:
            date = ""

        result.append({
            "日期": date,
            "代码": code,
            "最新": data.get("lastPrice", 0.0),  # 最新价格
            "今开": data.get("open", 0.0),
            "最高": data.get("high", 0.0),
            "最低": data.get("low", 0.0),
            "成交量": data.get("volume", 0),
            "成交额": data.get("amount", 0.0),
        })

    df = pd.DataFrame(result)
    df = df[df['成交量'] > 0]  # 过滤掉成交量为0的行
    df = df[df['最新'] > 0]  # 过滤掉最新价格为0的行
    df = stock_list.merge(df, on='代码', how='left')  # 将股票列表和最新数据合并

    df['总市值'] = df['最新'] * df['总股本']
    df['流通值'] = df['最新'] * df['流通股']
    df['流通市值'] = df['流通值']
    df['涨跌额'] = df['最新'] - df['昨收']
    df['涨跌幅'] = round(df['涨跌额'] * 100 / df['昨收'],2)
    df['换手率'] = round(df['成交量'] * 10000 / df['流通股'],4)
    df['总换手率'] = round(df['成交量'] * 10000 / df['总股本'],4)
    df['振幅'] = round((df['最高'] - df['最低'])*100 / df['昨收'],2)

    df = df.sort_values('涨跌幅', ascending=False)
    df['序号'] = range(1, len(df)+1)
    df['最新价'] = df['最新'] # 兼容之前的字段名
    filename = path.stock_all_latest_transaction_data_file_name()
    df.to_csv(filename, index=False, encoding='utf-8-sig')
    return df

def download_stock_history_data(stock_code:str, period:str='1d', start_date:str='20230101', end_date:str='20501231'):
    """
    下载国金股票的历史k线数据。
    参数：
        stock_code: 股票代码，如 '603416.SH'
        period: 数据周期，如 '1d'（日线）、'1m'（分钟线）等
        start_date: 起始日期，格式为 'YYYYMMDD'
        end_date: 结束日期，格式为 'YYYYMMDD'
    """
    try:
        xtdata.download_history_data(stock_code, period, start_time=start_date, end_time=end_date, incrementally = None)
        df = xtdata.get_local_data(stock_list=[stock_code], period=period, start_time=start_date, end_time=end_date)
        df = pd.DataFrame(list(df.values())[0])
        df = df.rename(columns={
            'time': '日期',
            'open': '开盘',
            'high': '最高',
            'low': '最低',
            'close': '收盘',
            'volume': '成交量',
            'amount': '成交额',
            'preClose': '昨收',
            'settle': '结算价',
            'suspendFlag': '停牌'
        })
        df['日期'] = df.index
        df['日期'] = pd.to_datetime(df['日期'], unit='ms').dt.strftime('%Y-%m-%d')
        df = df[['日期', '开盘', '最高', '最低', '收盘', '成交量', '成交额', '昨收', '停牌']]
        baseinfo = get_stocks_base_info([stock_code])
        if not baseinfo.empty:
            baseinfo = baseinfo.iloc[0]
            df['代码'] = stock_code
            df['股票代码'] = baseinfo['股票代码']
            df['名称'] = baseinfo['名称']
            df['市场'] = baseinfo['市场']
            df['IPO日期'] = baseinfo['IPO日期']
            df['上市日期'] = baseinfo['上市日期']
            df['退市日期'] = baseinfo['退市日期']
            df['总股本'] = baseinfo['总股本']
            df['流通股'] = baseinfo['流通股']


        df['date'] = pd.to_datetime(df['日期'],format='%Y-%m-%d')
        df['总市值'] = df['收盘'] * df['总股本']
        df['流通值'] = df['收盘'] * df['流通股']
        df['涨跌额'] = df['收盘'] - df['昨收']
        df['涨跌幅'] = round(df['涨跌额'] * 100 / df['昨收'],2)
        df['换手率'] = round(df['成交量'] * 100 / df['流通股'],4)
        df['总换手率'] = round(df['成交量'] * 100 / df['总股本'],4)

        df = indicator.MA_AND_VMA(df)
        filename = path.stock_his_transaction_data_file_name(stock_code)
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        return df
    except Exception as e:
        print(f"下载 {stock_code} 历史数据时发生错误: {e}")
        return None     

def download_all_stocks_history_data(start_date='20200101', period='1d',end_date='20501231'):
    """
    批量下载国金所有股票的历史数据。
    参数：
        start_date: 起始日期，格式为 'YYYYMMDD'
        period: 数据周期，如 '1d'（日线）、'1m'（分钟线）等
        end_date: 结束日期，格式为 'YYYYMMDD'
    """
    all_stocks = all_stock_latest_transaction_data()
    total = len(all_stocks)
    progress = tqdm(total=total, desc=f"国金股票历史数据下载中: ")
    for stock in all_stocks.itertuples():
        download_stock_history_data(stock_code=stock.代码, period=period, start_date=start_date, end_date=end_date)
        progress.update(1)
    progress.close()
    print("所有股票的历史数据下载完成。")    


def stock_his_transaction_data(code:str,start_at:str=None,end_at:str=None, reload:bool=False,readonly:bool=False):
    """
    指定股票在指定日期的历史交易数据(含今天),日期格式: 2025-01-01

    参数：
        code(str): 代码 如 '603416.SH'

        start_at(str,None): 开始时间, None为上一年的1月1日开始

        end_at(str,None): 不填则为今天

        reload(bool,False): 默认为 false. true=非交易时段将重新获取数据并保存到文件.(如果传入不同时段，则需要重新下载数据)

        readonly(bool,False): 默认为 false. true=只读取文件中的数据,文件不存在才去下载数据.

    返回值：

        pandas.DataFrame: AKShare的数据, 异常会返回 None
    """
    dt = datetime.now()
    hour = dt.hour
    weekday = datetime.today().weekday() + 1
    

    fname = path.stock_his_transaction_data_file_name(code)

    # 不传结束日期则取今天作结束日期
    # if end_at is None:
    #     end_at = datetime.today().strftime("%Y%m%d")

    # 非交易时间，取本地已保存的文件数据
    if hour < 9 or hour >= 15 or hour==12 or weekday>5 or readonly==True:
        # 检查文件是否存在
        if os.path.exists(fname)==False or reload ==True:
            if download_stock_history_data(code)==False:
                return None
    else:
        if download_stock_history_data(code)==False:
            return None
    data = pd.read_csv(fname)
    if start_at is not None:
        data = data.query(f"'{start_at}'<=日期")
    if end_at is not None:
        data = data.query(f"日期 <= '{end_at}'")    
    return data

def all_stock_close_geq_open_days_of_yesterday(re_calc:bool=False):
    '''
    统计昨天连续收盘价大于等于开盘价的天数

    参数：
        re_calc(bool,False): 是否重算. 默认直接读取文件
    返回值：
        pandas.DataFrame: AKShare的数据, 异常会返回 None
    '''
    
    fname = path.save_path('all_stock_close_geq_open_days_of_yesterday')
    if os.path.exists(fname)==False or re_calc==True:
        result = []
        all_stocks = all_stock_latest_transaction_data()
        total = len(all_stocks)
        progress = tqdm(total=total, desc="正在计算连阳天数: ")
        for stock in all_stocks.itertuples():
            item = {}
            code = stock.代码
            item['代码'] = code
            item['名称'] = stock.名称
            item['连阳天数'] = 0
            item['连阳涨幅'] = ''
            hisd = stock_his_transaction_data(code=stock.代码,readonly=True)
            close_end = stock.最新
            close_start = stock.今开
            if len(hisd) > 1:
                counter = 1
                days = 0
                while counter<50 and counter<len(hisd)-1:
                    tmp = hisd.iloc[-counter]
                    if tmp.收盘 <= tmp.开盘:
                        break
                    counter = counter + 1
                    days = days + 1
                    close_start = tmp.开盘
                item['连阳天数'] = days
                if close_start>0 and days>1:
                    item['连阳涨幅'] = round(((close_end-close_start)*100/close_start),2)
            result.append(item)
            progress.update(1)
        progress.close()
        result = pd.DataFrame(result)
        if len(result)>0:
            # 将数据保存到 CSV 文件
            result.to_csv(fname, index=False,encoding='utf-8-sig')    
    else:
        result =  pd.read_csv(fname)
        result['代码'] = result['代码']
    return result

def calc_all_stock_signal_list(data:pd.DataFrame=None,addrow:bool=False,callback=None, re_calc:bool=False):
    '''
    通过回测，计算所有股票的交易信号

    参数：
        data(pandas.DataFrame): 所有股票最新交易数据.
        addrow(bool,false):是否把最新交易数据添加到股票的历史数据,默认:false  (如果盘后已经下载好数据,则此处应该设置为false)
        callback(traderBack): 回测的策略回调方法,默认:traderBack.trade_back_cl_001
        re_calc(bool,False): 是否重算
    
    返回值：
        pandas.DataFrame: AKShare的数据, 异常会返回 None
    '''

    fname = path.save_path('all_stock_trader_back_data')
    if os.path.exists(fname)==False or re_calc==True:
        if data is None:
            data = all_stock_latest_transaction_data()
            data = data[data['最新']>data['今开']]
        rs_data = calc_signal_list(data=data,addrow=addrow,callback=callback)
        if len(rs_data)>0:
            # 将数据保存到 CSV 文件
            rs_data.to_csv(fname, index=False,encoding='utf-8-sig')
    read_data =   pd.read_csv(fname)
    return read_data

def calc_signal_list(data:pd.DataFrame=None, addrow:bool=True,callback=None):
    '''
    通过回测，计算交易信号

    参数：
        data(pandas.DataFrame): 所有股票最新交易数据.
        addrow(bool,true):是否把最新交易数据添加到股票的历史数据,默认:true  (已弃用)
        callback(traderBack): 回测的策略回调方法,默认:traderBack.trade_back_cl_001
    
    返回值：
        pandas.DataFrame: AKShare的数据, 异常会返回 None
    '''
    if data is None:
        return None
    if callback is None or data is None:
        return None    

    all_back_trade_data = []
    total = len(data)
    progress = tqdm(total=total, desc="正在回测数据: ")
    for stock in data.itertuples():
        try:
            stock = stock_his_transaction_data(stock_code=stock.代码)
            code = stock.代码
            start_at = datetime.today() - timedelta(days=60)
            start_at = datetime.strftime(start_at,'%Y-%m-%d')
            end_at = '2099-01-01'
            tb_data = callback(code,start_at,end_at)
            tb_data.insert(1,stock.名称)
            all_back_trade_data.append(tb_data)
            progress.update(1)        
        except Exception as e:
            print(f'{stock.代码}: {e}')
    progress.close()
    df_abtd = pd.DataFrame(all_back_trade_data,columns = ['代码','名称','本金','总金','盈亏','详细','signal','最新信号','最新盈亏','交易记录'])
    return df_abtd