
import numpy as np
import pandas as pd


# 指标	优点	缺点	适用场景
# KDJ	反应灵敏，能看到转向	假信号多，震荡市失效	趋势行情
# MACD	趋势明确，信号可靠	滞后严重	大趋势判断
# RSI	简单直观	钝化严重	震荡行情
# 布林带压力支撑明确	单边市容易失效	震荡行情


def MA_AND_VMA(data:pd.DataFrame=None,days=[3,5,10,20,30,60],sort_by:str='日期'):
    """
        计算价格和成交量的移动平均值并返回

    参数：
        data(pandas.DataFrame): 包含 '收盘','成交量' 的数据.
        days(str,None): 计算的指标时间. 默认为 [3,5,10,20,30,60] 即计划MA和VMA的时间分别为3,5,10,20,30,60天. 可以传入一个列表指定需要计算的指标时间.
        sort_by(str): 排序的列名

    返回值：
        pandas.DataFrame: AKShare的数据, 异常会返回 None        
    """
    if data is None:
        print(f'传入的数据为None')
        return data
    if len(days)<=0:
        days = [3,5,10,20,30,60]
        
    data = data.sort_values(by=sort_by)

    for d in days:
        data[f'MA{d}'] = data['收盘'].rolling(window=d).mean().round(2)
        data[f'VMA{d}'] = data['成交量'].rolling(window=d).mean().round(0)
    return data

def KDJ(data:pd.DataFrame=None, n=9, m1=3, m2=3):
    """
    计算KDJ指标并返回.
    特点：反应灵敏，能看到转向.
    缺点：假信号多，震荡市失效
    适用场景：适合趋势行情中的短线操作。
    参数：
        data(pandas.DataFrame): 包含 '收盘','最高','最低' 的数据.
        n(int): 计算RSV的周期，默认为9。
        m1(int): 计算K值的平滑周期，默认为3。
        m2(int): 计算D值的平滑周期，默认为3。   
    返回值：
        pandas.DataFrame: 包含KDJ指标的DataFrame，异常会返回 None        
    """
    
    high_n = data['最高'].rolling(window=n).max()
    low_n = data['最低'].rolling(window=n).min()
    rsv = (data['收盘'] - low_n) / (high_n - low_n) * 100
    
    # 使用 ewm 模拟递归平滑（alpha = 1/3）
    data['K'] = rsv.ewm(alpha=1/m1, adjust=False).mean()
    data['D'] = data['K'].ewm(alpha=1/m2, adjust=False).mean()
    data['J'] = 3 * data['K'] - 2 * data['D']
    data['RSV'] = rsv
        
    return data

def MACD(data:pd.DataFrame=None, fast=12, slow=26, signal=9):
    '''
    计算MACD指标并返回.
    特点：趋势明确，信号可靠.
    缺点：滞后严重.
    适用场景：适合大趋势判断.   

    短线参数：fast=6, slow=13, signal=5 灵敏，假信号多

    中线参数：fast=12, slow=26, signal=9 标准，最常用

    长线参数：fast=26, slow=52, signal=18 平滑，滞后大

    参数：
        data(pandas.DataFrame): 包含 '收盘' 的数据.
        fast(int): 快速EMA的周期，默认为12。
        slow(int): 慢速EMA的周期，默认为26。
        signal(int): 信号线的周期，默认为9。
    返回值：
        pandas.DataFrame: 包含MACD指标的DataFrame，异常会返回 None
    '''
    # EMA
    ema_fast = data['收盘'].ewm(span=fast, adjust=False).mean()
    ema_slow = data['收盘'].ewm(span=slow, adjust=False).mean()
    
    # MACD 线 & 信号线 & 柱状图
    data['MACD'] = ema_fast - ema_slow
    data['MACD_SIGNAL'] = data['MACD'].ewm(span=signal, adjust=False).mean()
    data['MACD_HIST'] = data['MACD'] - data['MACD_SIGNAL']
    
    return data

# ==========================
# 1. BOLL 布林带（ Bollinger Bands ）
# ==========================
def BOLL(df, window=20, num_std=2):
    """
    布林带 - 判断价格高低位置和波动率
    
    参数:
    - window: 周期，默认20
    - num_std: 标准差倍数，默认2
    
    返回:
    - BOLL_U: 上轨
    - BOLL_M: 中轨（SMA）
    - BOLL_L: 下轨
    - BOLL_WIDTH: 带宽（波动率）
    - BOLL_PCT: 价格位置百分比

    【原理】
    布林带由三条线组成：中轨（SMA20）、上轨（中轨+2倍标准差）、下轨（中轨-2倍标准差）
    价格在轨道内运行，触及轨道边缘时容易反转

    【应用场景】
    1. 震荡行情中的高抛低吸
    2. 判断波动率变化（带宽收窄预示变盘）
    3. 趋势行情中的回调支撑/压力

    【买卖信号】
    买入信号：
    - 价格触及下轨 + 开始反弹
    - 价格从下轨向上突破中轨
    - 带宽极度收窄后向上开口

    卖出信号：
    - 价格触及上轨 + 开始回落
    - 价格从上轨向下跌破中轨
    - 带宽极度收窄后向下开口

    【注意事项】
    - 单边趋势中会失效（价格会沿着上轨/下轨一直走）
    - 参数需要根据品种波动率调整（波动大的用3倍标准差）
    - 带宽收窄时预示变盘，但无法判断方向

    【参数优化】
    - 短线：window=10, num_std=2
    - 中线：window=20, num_std=2（标准）
    - 长线：window=50, num_std=2.5
    - 加密货币：window=20, num_std=3（波动大）
    """
    df_copy = df.copy()
    
    # 计算中轨（简单移动平均）
    df_copy['BOLL_M'] = df_copy['收盘'].rolling(window=window).mean()
    
    # 计算标准差
    df_copy['BOLL_STD'] = df_copy['收盘'].rolling(window=window).std()
    
    # 计算上下轨
    df_copy['BOLL_U'] = df_copy['BOLL_M'] + (df_copy['BOLL_STD'] * num_std)
    df_copy['BOLL_L'] = df_copy['BOLL_M'] - (df_copy['BOLL_STD'] * num_std)
    
    # 带宽（波动率指标）
    df_copy['BOLL_WIDTH'] = (df_copy['BOLL_U'] - df_copy['BOLL_L']) / df_copy['BOLL_M']
    
    # 价格在布林带中的位置（0-1）
    df_copy['BOLL_PCT'] = (df_copy['收盘'] - df_copy['BOLL_L']) / (df_copy['BOLL_U'] - df_copy['BOLL_L'])
    
    return df_copy

# ==========================
# 2. RSI 相对强弱指数（ Relative Strength Index ）
# ==========================
def RSI(df, window=14):
    """
    RSI - 判断超买超卖和动能强弱
    
    参数:
    - window: 周期，默认14
    
    返回:
    - RSI: 0-100之间的数值

    【原理】
    RSI比较一段时间内的平均涨幅和平均跌幅，数值0-100
    >70超买，<30超卖，50是多空分界线

    【应用场景】
    1. 判断超买超卖区域
    2. 寻找背离信号（强反转信号）
    3. 确认趋势强度

    买入信号：
    - RSI < 30（超卖区）
    - RSI从30以下上穿30
    - 底背离：价格新低，RSI没新低

    卖出信号：
    - RSI > 70（超买区）
    - RSI从70以上下穿70
    - 顶背离：价格新高，RSI没新高

    【RSI区域划分】
    - RSI > 80  →  极度超买，强烈卖出信号
    - 70-80     →  超买区，准备卖出
    - 50-70     →  强势区，持仓或回调买入
    - 30-50     →  弱势区，观望或反弹卖出
    - 20-30     →  超卖区，准备买入
    - RSI < 20  →  极度超卖，强烈买入信号

    【注意事项】
    - ⚠️ 强趋势中RSI会长期在70以上或30以下（钝化）
    - ⚠️ 背离信号需要其他指标确认
    - ⚠️ 参数越大越平滑，越小越敏感

    【参数优化】
    - 短线：window=7（更敏感）
    - 中线：window=14（标准）
    - 长线：window=21（更平滑）
    - 加密货币：window=7（波动大需要更敏感）
    """
    df_copy = df.copy()
    
    # 计算价格变化
    delta = df_copy['收盘'].diff()
    
    # 分离上涨和下跌
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    # 计算平均涨幅和平均跌幅
    avg_gain = gain.rolling(window=window).mean()
    avg_loss = loss.rolling(window=window).mean()
    
    # 计算RSI
    rs = avg_gain / avg_loss
    df_copy['RSI'] = 100 - (100 / (1 + rs))
    
    # 可选：平滑处理（ Wilder's smoothing ）
    # avg_gain = gain.ewm(alpha=1/window, adjust=False).mean()
    # avg_loss = loss.ewm(alpha=1/window, adjust=False).mean()
    
    return df_copy


# ==========================
# 3. CCI 顺势指标（ Commodity Channel Index ）
# ==========================
def CCI(df, window=20):
    """
    CCI - 判断价格偏离程度和趋势转折
    
    参数:
    - window: 周期，默认20
    
    返回:
    - CCI: 无范围限制，通常在-100到+100之间

    【原理】
    - CCI衡量价格与统计平均价格的偏离程度
    - +100以上超买，-100以下超卖，没有上下限

    【应用场景】
    1. 识别超买超卖（比RSI更灵敏）
    2. 发现趋势转折点
    3. 识别极端行情

    买入信号：
    - CCI从-100以下上穿-100
    - CCI从-100到+100区域的向上突破
    - CCI从+100以上回落到+100附近企稳（加仓）

    卖出信号：
    - CCI从+100以上下穿+100
    - CCI从+100到-100区域的向下跌破
    - CCI从-100以下反弹到-100附近受阻（减仓）

    【CCI区域划分】
    - CCI > +200  →  极度超买，强烈卖出
    - +100 ~ +200 →  超买区，准备卖出
    - -100 ~ +100 →  正常波动区，观望
    - -200 ~ -100 →  超卖区，准备买入
    - CCI < -200  →  极度超卖，强烈买入

    【注意事项】
    - ⚠️ 比RSI敏感，假信号更多
    - ⚠️ 适合趋势行情，震荡市会频繁发出信号
    - ⚠️ 结合趋势指标（如MACD）使用效果更好

    【参数优化】
    - 短线：window=14（更敏感）
    - 中线：window=20（标准）
    - 长线：window=50（更平滑）

    【实战技巧】
    CCI + MACD 组合：
    - MACD > 0（多头趋势）+ CCI从-100上穿 = 强烈买入
    - MACD < 0（空头趋势）+ CCI从+100下穿 = 强烈卖出
    """
    df_copy = df.copy()
    
    # 典型价格（TP）= (最高+最低+收盘)/3
    tp = (df_copy['最高'] + df_copy['最低'] + df_copy['收盘']) / 3
    
    # 计算TP的移动平均
    tp_ma = tp.rolling(window=window).mean()
    
    # 计算平均偏差（Mean Deviation）
    md = tp.rolling(window=window).apply(lambda x: np.abs(x - x.mean()).mean())
    
    # 计算CCI
    df_copy['CCI'] = (tp - tp_ma) / (0.015 * md)
    
    return df_copy


# ==========================
# 4. WR 威廉指标（ Williams %R ）
# ==========================
def WR(df, window=14):
    """
    威廉指标 - 判断超买超卖和收盘价位置
    
    参数:
    - window: 周期，默认14
    
    返回:
    - WR: -100到0之间的数值

    【原理】
    威廉指标衡量收盘价在N周期高低点区间的位置
    - 数值-100到0，-80以下超卖，-20以上超买（注意与RSI相反）.

    【应用场景】
    1. 判断超买超卖（比RSI更敏感）
    2. 寻找趋势转折点
    3. 确认K线形态

    【买卖信号】
    买入信号：
    - WR < -80（超卖区）
    - WR从-80以下上穿-80
    - 底背离：价格新低，WR没新低

    卖出信号：
    - WR > -20（超买区）
    - WR从-20以上下穿-20
    - 顶背离：价格新高，WR没新高

    【WR区域划分】
    - WR > -10   →  极度超买，强烈卖出
    - 20 ~ -10  →  超买区，准备卖出
    - 50 ~ -20  →  正常区，观望
    - 80 ~ -50  →  超卖区，准备买入
    - WR < -90   →  极度超卖，强烈买入

    【注意事项】
    - ⚠️ 与RSI相反：RSI>80是超买，WR>-20是超买
    - ⚠️ 震荡市效果好，趋势市会钝化
    - ⚠️ 参数太大会滞后，太小会频繁信号

    【参数优化】
    - 短线：window=10
    - 中线：window=14（标准）
    - 长线：window=21

    【实战技巧】
    WR + KDJ 组合：
    - KDJ低位金叉 + WR < -80 = 强烈买入
    - KDJ高位死叉 + WR > -20 = 强烈卖出
    """
    df_copy = df.copy()
    
    # N周期最高价和最低价
    high_n = df_copy['最高'].rolling(window=window).max()
    low_n = df_copy['最低'].rolling(window=window).min()
    
    # 计算威廉指标
    # 公式: WR = (最高价 - 收盘价) / (最高价 - 最低价) * -100
    df_copy['WR'] = (high_n - df_copy['收盘']) / (high_n - low_n) * (-100)
    
    return df_copy


# ==========================
# 5. EMV 简易波动指标（ Ease of Movement Value ）
# ==========================
def EMV(df, window=14):
    """
    简易波动指标 - 判断价格与成交量的关系
    
    参数:
    - window: 平滑周期，默认14
    
    返回:
    - EMV: 波动指标
    - MAEMV: EMV的移动平均

    【原理】
    - EMV将价格变动与成交量结合，判断资金流向
    - 正值表示价格上涨不需要大成交量（健康上涨）
    - 负值表示价格下跌或上涨需要大成交量（异常）

    【应用场景】
    1. 判断主力资金真实流向
    2. 识别量价背离
    3. 确认趋势健康程度

    买入信号：
    - EMV上穿0轴
    - EMV持续为正且向上
    - MAEMV从负转正

    卖出信号：
    - EMV下穿0轴
    - EMV持续为负且向下
    - MAEMV从正转负

    【EMV区域划分】
    - EMV > 0.2   →  强势上涨，健康
    - 0 ~ 0.2     →  温和上涨，可持有
    - -0.2 ~ 0    →  弱势，观望或减仓
    - EMV < -0.2  →  强势下跌，空头

    【注意事项】
    - ⚠️ 需要配合成交量使用，单独使用效果差
    - ⚠️ 大单边行情中EMV会持续同向
    - ⚠️ 横盘震荡时EMV在0轴附近频繁穿越

    【参数优化】
    - 短线：window=7
    - 中线：window=14（标准）
    - 长线：window=21

    【实战技巧】
    EMV + OBV 组合：
    - EMV > 0 且 OBV创新高 = 主力吸筹
    - EMV < 0 且 OBV创新低 = 主力出货
    """
    df_copy = df.copy()
    
    # 计算中间价
    mid = (df_copy['最高'] + df_copy['最低']) / 2
    
    # 计算价格变动比例
    mid_diff = mid.diff()
    
    # 计算成交量比例
    high_low_diff = df_copy['最高'] - df_copy['最低']
    volume_ratio = (df_copy['成交量'] / 100000000) / high_low_diff  # 缩放处理
    
    # 计算EMV
    df_copy['EMV'] = mid_diff / volume_ratio
    
    # 平滑处理
    df_copy['MAEMV'] = df_copy['EMV'].rolling(window=window).mean()
    
    return df_copy


# ==========================
# 6. SAR 抛物线转向（ Parabolic SAR ）
# ==========================
def SAR(df, acceleration=0.02, maximum=0.2):
    """
    抛物线转向 - 判断趋势方向和止损点
    
    参数:
    - acceleration: 步长（加速度），默认0.02
    - maximum: 最大步长，默认0.2
    
    返回:
    - SAR: 止损转向点
    - SAR_TREND: 1=上涨，-1=下跌

    【原理】
    - SAR通过一系列点跟踪价格趋势，点位于价格下方为上涨趋势
    - 点位于价格上方为下跌趋势，点即为止损位

    【应用场景】
    1. 判断趋势方向
    2. 设置动态止损位
    3. 捕捉趋势反转点
    
    买入信号：
    - SAR从价格上方转到下方（趋势向上）
    - SAR持续在价格下方

    卖出信号：
    - SAR从价格下方转到上方（趋势向下）
    - SAR持续在价格上方

    【SAR特点】
    - 上涨趋势：SAR点在K线下方，跟随价格上升
    - 下跌趋势：SAR点在K线上方，跟随价格下降
    - 趋势越强，SAR点与价格距离越大

    【注意事项】
    - ⚠️ 震荡市中SAR会频繁反转（左右打脸）
    - ⚠️ 参数需要根据波动率调整
    - ⚠️ 适合有明确趋势的品种

    【参数优化】
    - 保守（减少反转）：acceleration=0.01, maximum=0.1
    - 标准：acceleration=0.02, maximum=0.2
    - 激进（捕捉反转）：acceleration=0.03, maximum=0.3

    【实战技巧】
    SAR + ADX 组合：
    - ADX > 25（强趋势）+ SAR向上 = 顺势做多
    - ADX < 20（无趋势）+ 禁止使用SAR
    """
    df_copy = df.copy()
    
    # 初始化
    sar = [float('nan')] * len(df_copy)
    trend = [1]  # 1=上涨，-1=下跌
    ep = [df_copy['最高'].iloc[0]]  # 极值点 Extreme Point
    af = [acceleration]  # 加速因子 Acceleration Factor
    
    for i in range(1, len(df_copy)):
        high = df_copy['最高'].iloc[i]
        low = df_copy['最低'].iloc[i]
        
        if trend[-1] == 1:  # 上涨趋势
            sar_i = sar[i-1] if not pd.isna(sar[i-1]) else low - (low - high) * acceleration
            sar_i = min(sar_i, low)
            
            if high > ep[-1]:
                ep.append(high)
                af.append(min(af[-1] + acceleration, maximum))
            else:
                ep.append(ep[-1])
                af.append(af[-1])
            
            if low <= sar_i:  # 趋势反转
                sar.append(ep[-1])
                trend.append(-1)
                ep.append(high)
                af.append(acceleration)
            else:
                sar.append(sar_i)
                trend.append(1)
        
        else:  # 下跌趋势
            sar_i = sar[i-1] if not pd.isna(sar[i-1]) else high + (high - low) * acceleration
            sar_i = max(sar_i, high)
            
            if low < ep[-1]:
                ep.append(low)
                af.append(min(af[-1] + acceleration, maximum))
            else:
                ep.append(ep[-1])
                af.append(af[-1])
            
            if high >= sar_i:  # 趋势反转
                sar.append(ep[-1])
                trend.append(1)
                ep.append(low)
                af.append(acceleration)
            else:
                sar.append(sar_i)
                trend.append(-1)
    
    df_copy['SAR'] = sar
    df_copy['SAR_TREND'] = trend
    
    return df_copy


# ==========================
# 完整使用示例
# ==========================
def demo_all_indicators(df):
    """
    演示所有指标的使用方法
    
    示例数据（需要真实数据）
    df = pd.read_csv('your_data.csv')
    
    假设已有数据
    df = pd.DataFrame({
        '开盘': [...],
        '最高': [...],
        '最低': [...],
        '收盘': [...],
        '成交量': [...]
    })

    # 生成综合信号
    df['BUY'] = (
        (df['RSI'] < 30) &                    # RSI超卖
        (df['WR'] < -80) &                    # WR超卖
        (df['CCI'] < -100) &                  # CCI超卖
        (df['收盘'] <= df['BOLL_L']) &       # 触及布林下轨
        (df['SAR_TREND'] == 1)                # SAR向上
    )
    """
    
    # 计算所有指标
    df = BOLL(df, window=20, num_std=2)
    df = RSI(df, window=14)
    df = CCI(df, window=20)
    df = WR(df, window=14)
    df = EMV(df, window=14)
    df = SAR(df, acceleration=0.02, maximum=0.2)
    
    # 生成综合信号
    df['BUY'] = (
        (df['RSI'] < 30) &                    # RSI超卖
        (df['WR'] < -80) &                    # WR超卖
        (df['CCI'] < -100) &                  # CCI超卖
        (df['close'] <= df['BOLL_L']) &       # 触及布林下轨
        (df['SAR_TREND'] == 1)                # SAR向上
    )
    
    return df

# ==========================
# 多指标组合策略
# ==========================
def multi_indicator_strategy(df):
    """
    多个指标组合的综合策略
    1. 计算所有指标
    2. 定义强买入和强卖出信号（至少3个指标共振）
    3. 震荡市过滤（带宽收窄时用RSI和WR，趋势市用SAR和布林带）

    参数:
    - df: 包含 '开盘','最高','最低','收盘','成交量' 的DataFrame
    返回:
    - df: 包含所有指标和BUY和SELL信号的DataFrame
    """
    df = BOLL(df)
    df = RSI(df)
    df = CCI(df)
    df = WR(df)
    df = EMV(df)
    df = SAR(df)
    
    # 强买入信号（至少3个指标共振）
    strong_buy = (
        ((df['RSI'] < 30) | (df['WR'] < -80) | (df['CCI'] < -100)).sum(axis=1) >= 2
    ) & (df['收盘'] <= df['BOLL_L']) & (df['SAR_TREND'] == 1)
    
    # 强卖出信号
    strong_sell = (
        ((df['RSI'] > 70) | (df['WR'] > -20) | (df['CCI'] > 100)).sum(axis=1) >= 2
    ) & (df['收盘'] >= df['BOLL_U']) & (df['SAR_TREND'] == -1)
    
    # 震荡市过滤（避免假信号）
    trending = (df['BOLL_WIDTH'] > df['BOLL_WIDTH'].rolling(50).mean())  # 带宽大于均值，有趋势
    range_market = ~trending  # 震荡市
    
    # 震荡市用RSI和WR，趋势市用SAR和布林带
    buy_signal = (range_market & strong_buy) | (trending & (df['SAR_TREND'] == 1))
    sell_signal = (range_market & strong_sell) | (trending & (df['SAR_TREND'] == -1))
    
    df['BUY'] = buy_signal
    df['SELL'] = sell_signal
    
    return df