"""
Comprehensive test suite for kctools.py functions.

Tests are organized by functional sections:
- Files
- Strings  
- Lists
- Dicts
- Logging
- Numbers
- Numpy (optional dependency)
- Scipy (optional dependency)
- Pandas (optional dependency)
- Matplotlib (optional dependency)
"""

import unittest
import tempfile
import shutil
import os
import sys
from unittest.mock import patch, MagicMock
from datetime import datetime
import logging
from collections import defaultdict

# Add the kctools directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'kctools'))

import kctools


class TestFiles(unittest.TestCase):
    """Test file-related functions."""
    
    def setUp(self):
        """Set up temporary directory for file tests."""
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, 'test.txt')
        with open(self.test_file, 'w') as f:
            f.write('line 1\nline 2\n  line 3  \n\nline 4\n')
        
        # Create nested structure for lsdashr test
        self.nested_dir = os.path.join(self.temp_dir, 'nested')
        os.makedirs(self.nested_dir)
        os.makedirs(os.path.join(self.nested_dir, 'subdir'))
        with open(os.path.join(self.nested_dir, 'file1.txt'), 'w') as f:
            f.write('content1')
        with open(os.path.join(self.nested_dir, 'subdir', 'file2.txt'), 'w') as f:
            f.write('content2')
    
    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.temp_dir)
    
    def test_lsdashr_relative(self):
        """Test lsdashr with relative paths."""
        files = kctools.lsdashr(self.nested_dir, absolute=False)
        files.sort()
        expected = ['file1.txt', os.path.join('subdir', 'file2.txt')]
        expected.sort()
        self.assertEqual(files, expected)
    
    def test_lsdashr_absolute(self):
        """Test lsdashr with absolute paths."""
        files = kctools.lsdashr(self.nested_dir, absolute=True)
        files.sort()
        expected = [
            os.path.join(self.nested_dir, 'file1.txt'),
            os.path.join(self.nested_dir, 'subdir', 'file2.txt')
        ]
        expected.sort()
        self.assertEqual(files, expected)
    
    def test_readlines(self):
        """Test readlines function."""
        lines = kctools.readlines(self.test_file)
        expected = ['line 1', 'line 2', 'line 3', '', 'line 4']
        self.assertEqual(lines, expected)


class TestStrings(unittest.TestCase):
    """Test string-related functions."""
    
    def test_lpad(self):
        """Test lpad function."""
        text = "line1\nline2"
        result = kctools.lpad(text, 2)
        expected = "  line1\n  line2"
        self.assertEqual(result, expected)
        
        # Test with different padding
        result = kctools.lpad(text, 4)
        expected = "    line1\n    line2"
        self.assertEqual(result, expected)
        
        # Test with default padding
        result = kctools.lpad(text)
        expected = "  line1\n  line2"
        self.assertEqual(result, expected)
    
    def test_sbool(self):
        """Test sbool function."""
        # Test truthy values
        self.assertTrue(kctools.sbool('true'))
        self.assertTrue(kctools.sbool('TRUE'))
        self.assertTrue(kctools.sbool('yes'))
        self.assertTrue(kctools.sbool('t'))
        self.assertTrue(kctools.sbool('y'))
        self.assertTrue(kctools.sbool('1'))
        
        # Test falsy values
        self.assertFalse(kctools.sbool('false'))
        self.assertFalse(kctools.sbool('FALSE'))
        self.assertFalse(kctools.sbool('no'))
        self.assertFalse(kctools.sbool('f'))
        self.assertFalse(kctools.sbool('n'))
        self.assertFalse(kctools.sbool('0'))
        
        # Test non-string values
        self.assertTrue(kctools.sbool(1))
        self.assertFalse(kctools.sbool(0))
        self.assertTrue(kctools.sbool([1]))
        self.assertFalse(kctools.sbool([]))
        
        # Test invalid string
        self.assertIsNone(kctools.sbool('maybe'))
    
    def test_html_strip(self):
        """Test html_strip function."""
        html = "<p>Hello <b>world</b>!</p>"
        result = kctools.html_strip(html)
        self.assertEqual(result, "Hello world!")
        
        # Test with no HTML
        text = "plain text"
        result = kctools.html_strip(text)
        self.assertEqual(result, "plain text")
        
        # Test with nested HTML
        html = "<div><span>nested <em>tags</em></span></div>"
        result = kctools.html_strip(html)
        self.assertEqual(result, "nested tags")
    
    def test_rem_punc(self):
        """Test rem_punc function."""
        text = "Hello, world! How are you?"
        result = kctools.rem_punc(text)
        self.assertEqual(result, "Hello world How are you")
        
        # Test with no punctuation
        text = "Hello world"
        result = kctools.rem_punc(text)
        self.assertEqual(result, "Hello world")
        
        # Test with only punctuation
        text = "!@#$%"
        result = kctools.rem_punc(text)
        self.assertEqual(result, "")
    
    def test_rep_punc(self):
        """Test rep_punc function."""
        text = "Hello,world!How are you?"
        result = kctools.rep_punc(text)
        self.assertEqual(result, "Hello world How are you ")
        
        # Test with no punctuation
        text = "Hello world"
        result = kctools.rep_punc(text)
        self.assertEqual(result, "Hello world")
    
    def test_tnow(self):
        """Test tnow function."""
        result = kctools.tnow()
        # Should be in HH:MM:SS format
        self.assertRegex(result, r'^\d{2}:\d{2}:\d{2}$')
    
    def test_endify(self):
        """Test endify function."""
        # Test regular numbers
        self.assertEqual(kctools.endify(1), "1st")
        self.assertEqual(kctools.endify(2), "2nd")
        self.assertEqual(kctools.endify(3), "3rd")
        self.assertEqual(kctools.endify(4), "4th")
        self.assertEqual(kctools.endify(11), "11th")
        self.assertEqual(kctools.endify(12), "12th")
        self.assertEqual(kctools.endify(13), "13th")
        self.assertEqual(kctools.endify(21), "21st")
        self.assertEqual(kctools.endify(22), "22nd")
        self.assertEqual(kctools.endify(23), "23rd")
        
        # Test with string input
        self.assertEqual(kctools.endify("1"), "1st")
        
        # Test with empty string
        self.assertEqual(kctools.endify(""), "")
    
    def test_humanify(self):
        """Test humanify function."""
        # Test basic conversions
        self.assertEqual(kctools.humanify(500), "500")
        self.assertEqual(kctools.humanify(1500), "1.5k")
        self.assertEqual(kctools.humanify(1500000), "1.5M")
        self.assertEqual(kctools.humanify(1500000000), "1.5B")
        self.assertEqual(kctools.humanify(1500000000000), "1.5T")
        
        # Test with space parameter
        self.assertEqual(kctools.humanify(1500, space=True), "1.5 k")
        
        # Test negative numbers
        self.assertEqual(kctools.humanify(-1500), "-1.5k")
        
        # Test with precision
        self.assertEqual(kctools.humanify(1234, l=3), "1.23k")
        self.assertEqual(kctools.humanify(1234, l=1), "1k")


class TestLists(unittest.TestCase):
    """Test list-related functions."""
    
    def test_only_one(self):
        """Test only_one function."""
        self.assertTrue(kctools.only_one([True, False, False]))
        self.assertTrue(kctools.only_one([1, 0, 0, 0]))
        self.assertTrue(kctools.only_one([[], [1], []]))
        
        self.assertFalse(kctools.only_one([True, True, False]))
        self.assertFalse(kctools.only_one([1, 1, 0]))
        self.assertFalse(kctools.only_one([True, True, True]))
        self.assertFalse(kctools.only_one([False, False, False]))
        self.assertFalse(kctools.only_one([]))
    
    def test_split_into_rows(self):
        """Test split_into_rows function."""
        lst = list(range(10))
        result = kctools.split_into_rows(lst, 3)
        expected = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
        self.assertEqual(result, expected)
        
        # Test with default m
        result = kctools.split_into_rows(lst)
        expected = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
        self.assertEqual(result, expected)
        
        # Test with empty list
        result = kctools.split_into_rows([], 3)
        self.assertEqual(result, [])
    
    def test_split_into_chunks(self):
        """Test split_into_chunks function."""
        lst = list(range(10))
        result = kctools.split_into_chunks(lst, 3)
        # Should split into 3 chunks as evenly as possible
        self.assertEqual(len(result), 3)
        print(result)
        self.assertEqual(sum(len(chunk) for chunk in result), 10)
        
        # Test exact division
        lst = list(range(9))
        result = kctools.split_into_chunks(lst, 3)
        expected = [[0, 1, 2], [3, 4, 5], [6, 7, 8]]
        self.assertEqual(result, expected)
    
    def test_flatten(self):
        """Test flatten function."""
        # Test nested lists
        nested = [1, [2, 3], [4, [5, 6]], 7]
        result = kctools.flatten(nested)
        expected = [1, 2, 3, 4, 5, 6, 7]
        self.assertEqual(result, expected)
        
        # Test single item
        result = kctools.flatten(5)
        self.assertEqual(result, [5])
        
        # Test empty list
        result = kctools.flatten([])
        self.assertEqual(result, [])
        
        # Test deeply nested
        nested = [[[[[1]]]]]
        result = kctools.flatten(nested)
        expected = [1]
        self.assertEqual(result, expected)
    
    def test_gram_getter(self):
        """Test gram_getter function."""
        items = ['a', 'b', 'c', 'd']
        
        # Test bigrams
        result = kctools.gram_getter(items, 2)
        expected = [('a', 'b'), ('b', 'c'), ('c', 'd')]
        self.assertEqual(result, expected)
        
        # Test trigrams
        result = kctools.gram_getter(items, 3)
        expected = [('a', 'b', 'c'), ('b', 'c', 'd')]
        self.assertEqual(result, expected)
        
        # Test with string join
        result = kctools.gram_getter(items, 2, strjoin=True)
        expected = ['a b', 'b c', 'c d']
        self.assertEqual(result, expected)
        
        # Test edge cases
        result = kctools.gram_getter(items, 1)
        expected = [('a',), ('b',), ('c',), ('d',)]
        self.assertEqual(result, expected)
        
        result = kctools.gram_getter(items, 5)
        expected = []
        self.assertEqual(result, expected)
    
    def test_where_in_thing(self):
        """Test where_in_thing function."""
        # Simple list
        lst = [1, 2, 3, 2, 1]
        result = kctools.where_in_thing(2, lst)
        expected = [[1], [3]]
        self.assertEqual(result, expected)
        
        # Nested list
        nested = [1, [2, 3], [4, [2, 5]], 2]
        result = kctools.where_in_thing(2, nested)
        expected = [[1, 0], [2, 1, 0], [3]]
        self.assertEqual(result, expected)
        
        # Not found
        result = kctools.where_in_thing(99, lst)
        expected = []
        self.assertEqual(result, expected)
        
        # Multiple occurrences in same location
        nested = [[[2, 2], 2], 2]
        result = kctools.where_in_thing(2, nested)
        expected = [[0, 0, 0], [0, 0, 1], [0, 1], [1]]
        self.assertEqual(result, expected)


class TestDicts(unittest.TestCase):
    """Test dictionary-related functions."""
    
    def test_autovivify(self):
        """Test autovivify function."""
        av = kctools.autovivify()
        
        # Test nested assignment
        av['a']['b']['c'] = 42
        self.assertEqual(av['a']['b']['c'], 42)
        
        # Test that it creates default dicts
        self.assertIsInstance(av['x'], defaultdict)
        self.assertIsInstance(av['x']['y'], defaultdict)
    
    def test_vivify(self):
        """Test vivify function."""
        # Test 2 levels with int final
        v = kctools.vivify(2, int)
        v['a']['b'] = 42
        self.assertEqual(v['a']['b'], 42)
        self.assertEqual(v['a']['c'], 0)  # Default int value
        
        # Test 1 level
        v1 = kctools.vivify(1, str)
        v1['key'] = 'value'
        self.assertEqual(v1['key'], 'value')
        self.assertEqual(v1['default'], '')  # Default str value
        
        # Test 3 levels
        v3 = kctools.vivify(3, list)
        v3['a']['b']['c'].append(1)
        self.assertEqual(v3['a']['b']['c'], [1])
    
    def test_mortify(self):
        """Test mortify function."""
        # Test nested defaultdict
        from collections import defaultdict
        dd = defaultdict(lambda: defaultdict(int))
        dd['a']['b'] = 42
        dd['a']['c'] = 10
        
        result = kctools.mortify(dd)
        expected = {'a': {'b': 42, 'c': 10}}
        self.assertEqual(result, expected)
        
        # Test regular dict (should pass through)
        regular = {'a': 1, 'b': {'c': 2}}
        result = kctools.mortify(regular)
        self.assertEqual(result, regular)
        
        # Test non-dict (should pass through)
        result = kctools.mortify(42)
        self.assertEqual(result, 42)
    
    def test_invert(self):
        """Test invert function."""
        # Test simple inversion
        d = {'a': [1, 2], 'b': [2, 3], 'c': [4]}
        result = kctools.invert(d)
        expected = {1: ['a'], 2: ['a', 'b'], 3: ['b'], 4: ['c']}
        self.assertEqual(result, expected)
        
        # Test with single values
        d = {'a': [1], 'b': [2], 'c': [1]}
        result = kctools.invert(d)
        expected = {1: ['a', 'c'], 2: ['b']}
        self.assertEqual(result, expected)
    
    def test_dict_update(self):
        """Test dict_update function."""
        A = {'a': 1, 'b': {'x': 10, 'y': 20}, 'c': 3}
        B = {'b': {'x': 100, 'z': 30}, 'd': 4}
        
        # Test non-inplace
        result = kctools.dict_update(A, B, inplace=False)
        expected = {'a': 1, 'b': {'x': 100, 'y': 20, 'z': 30}, 'c': 3, 'd': 4}
        self.assertEqual(result, expected)
        
        # Check original A is unchanged
        self.assertEqual(A, {'a': 1, 'b': {'x': 10, 'y': 20}, 'c': 3})
        
        # Test inplace
        A_copy = A.copy()
        result = kctools.dict_update(A_copy, B, inplace=True)
        expected = {'a': 1, 'b': {'x': 100, 'y': 20, 'z': 30}, 'c': 3, 'd': 4}
        self.assertEqual(A_copy, expected)
        self.assertEqual(result, A_copy)  # Should return same object


class TestNumbers(unittest.TestCase):
    """Test number-related functions."""
    
    def test_mround(self):
        """Test mround function."""
        self.assertEqual(kctools.mround(7, 5), 5)
        self.assertEqual(kctools.mround(8, 5), 10)
        self.assertEqual(kctools.mround(12, 10), 10)
        self.assertEqual(kctools.mround(15, 10), 20)
        self.assertEqual(kctools.mround(2.6, 1), 3)
        self.assertEqual(kctools.mround(2.4, 1), 2)
        
        # Test with float rounding
        self.assertEqual(kctools.mround(7.3, 0.5), 7.5)
        self.assertEqual(kctools.mround(7.2, 0.5), 7.0)
    
    def test_compare(self):
        """Test compare function."""
        # Test basic choice
        self.assertEqual(kctools.compare(5, 3), 5)  # x > y is True, so returns x
        self.assertEqual(kctools.compare(3, 5), 5)  # x > y is False, so returns y
        
        # Test with other parameter
        self.assertEqual(kctools.compare(5, 3, other=2), 5)  # only x > other, returns x
        self.assertEqual(kctools.compare(3, 5, other=2), 5)  # only y > other, returns y
        self.assertEqual(kctools.compare(1, 1, other=2), 1)  # neither > other, x > y is True, returns x
        
        # Test when one doesn't exceed other
        self.assertEqual(kctools.compare(1, 3, other=5), 3)  # neither > other, x > y is False, returns y
        self.assertEqual(kctools.compare(3, 1, other=5), 3)  # neither > other, x > y is True, returns x
    
    def test_coalesce(self):
        """Test coalesce function."""
        # Test the actual iterative behavior
        result = kctools.coalesce(1, 2, 3)
        # Trace: y=0 -> y=0+1+0*1=1 -> y=1+2+1*2=5 -> y=5+3+5*3=23
        expected = 23
        self.assertEqual(result, expected)
        
        # Test with zeros
        result = kctools.coalesce(0, 1, 2)
        # Trace: y=0 -> y=0+0+0*0=0 -> y=0+1+0*1=1 -> y=1+2+1*2=5
        expected = 5
        self.assertEqual(result, expected)
        
        # Test single value
        result = kctools.coalesce(5)
        expected = 5
        self.assertEqual(result, expected)
        
        # Test empty
        result = kctools.coalesce()
        expected = 0
        self.assertEqual(result, expected)


# Optional dependency tests
class TestNumpyFunctions(unittest.TestCase):
    """Test numpy-dependent functions."""
    
    def setUp(self):
        """Check if numpy is available."""
        self.numpy_available = kctools.is_np
    
    def test_numpy_check_decorator(self):
        """Test numpy check decorator."""
        if not self.numpy_available:
            with self.assertRaises(Exception) as cm:
                kctools.normalize([1, 2, 3])
            self.assertIn('numpy', str(cm.exception).lower())
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_normalize(self):
        """Test normalize function."""
        import numpy as np
        
        arr = np.array([1, 2, 3])
        result = kctools.normalize(arr)
        expected = np.array([1/6, 2/6, 3/6])
        np.testing.assert_array_almost_equal(result, expected)
        
        # Test with zeros
        arr = np.array([0, 0, 0])
        result = kctools.normalize(arr)
        expected = np.array([0, 0, 0])
        np.testing.assert_array_almost_equal(result, expected)
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_is_diagonal(self):
        """Test is_diagonal function."""
        import numpy as np
        
        # Diagonal matrix
        diag = np.array([[1, 0], [0, 2]])
        self.assertTrue(kctools.is_diagonal(diag))
        
        # Non-diagonal matrix
        non_diag = np.array([[1, 1], [0, 2]])
        self.assertFalse(kctools.is_diagonal(non_diag))
        
        # Zero matrix (should be diagonal)
        zero = np.array([[0, 0], [0, 0]])
        self.assertTrue(kctools.is_diagonal(zero))
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_kpow(self):
        """Test kpow function."""
        import numpy as np
        
        arr = np.array([1, 4, 9])
        
        # Test p=2 (quadratic mean / root mean square)
        result = kctools.kpow(arr, 2)
        expected = np.power(np.power(arr, 1/2).mean(), 2)
        self.assertAlmostEqual(result, expected)
        
        # Test p=3 (cubic mean)
        result = kctools.kpow(arr, 3)
        expected = np.power(np.power(arr, 1/3).mean(), 3)
        self.assertAlmostEqual(result, expected)
        
        # Test with p=1 (arithmetic mean)
        result = kctools.kpow(arr, 1)
        expected = arr.mean()
        self.assertAlmostEqual(result, expected)
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_kcos(self):
        """Test kcos function."""
        import numpy as np
        
        a = np.array([1, 0])
        b = np.array([0, 1])
        result = kctools.kcos(a, b)
        self.assertAlmostEqual(result, 0.0)  # Orthogonal vectors
        
        a = np.array([1, 0])
        b = np.array([1, 0])
        result = kctools.kcos(a, b)
        self.assertAlmostEqual(result, 1.0)  # Same vectors
        
        # Test with zeros
        a = np.array([0, 0])
        b = np.array([1, 1])
        result = kctools.kcos(a, b)
        self.assertAlmostEqual(result, 0.0)  # Zero vector
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_entropy_functions(self):
        """Test entropy functions."""
        import numpy as np
        
        true = np.array([1, 0, 1, 0])
        pred = np.array([0.9, 0.1, 0.8, 0.2])
        
        # Test binary entropy
        result = kctools.bin_entropy(true, pred)
        self.assertGreater(result, 0)
        self.assertLess(result, 10)  # Reasonable bounds
        
        # Test modified entropy
        result = kctools.mod_entropy(true, pred, mod=2.0)
        self.assertGreater(result, 0)
        
        # Test with perfect predictions
        pred_perfect = np.array([1.0, 0.0, 1.0, 0.0])
        result = kctools.bin_entropy(true, pred_perfect)
        self.assertAlmostEqual(result, 0.0, places=5)
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_partial_sort(self):
        """Test partial sort functions."""
        import numpy as np
        
        arr = np.array([5, 1, 3, 2, 4, 6])
        
        # Test pargsort
        idxs = kctools.pargsort(arr, 3)
        expected = np.array([1, 3, 2])  # Indices of 1, 2, 3
        np.testing.assert_array_equal(idxs, expected)
        
        # Test psort
        result = kctools.psort(arr, 3)
        expected = np.array([1, 2, 3])
        np.testing.assert_array_equal(result, expected)
    
    @unittest.skipUnless(kctools.is_np, "numpy not available")
    def test_rchoice(self):
        """Test rchoice function."""
        import numpy as np
        
        arr = np.array([1, 2, 3, 4, 5])
        
        # Test basic choice
        result = kctools.rchoice(arr)
        self.assertIn(result, arr)
        
        # Test with size
        result = kctools.rchoice(arr, size=3)
        self.assertEqual(len(result), 3)
        self.assertTrue(all(x in arr for x in result))
        
        # Test edge case with empty array
        result = kctools.rchoice(np.array([]))
        self.assertIsNone(result)


class TestPandasFunctions(unittest.TestCase):
    """Test pandas-dependent functions."""
    
    def setUp(self):
        """Check if pandas is available."""
        self.pandas_available = kctools.is_pd
    
    def test_pandas_check_decorator(self):
        """Test pandas check decorator behavior."""
        if self.pandas_available:
            # Should work normally
            import pandas as pd
            df = pd.DataFrame({'A': [1, 2, 3]})
            # Test that pandas is available
            self.assertTrue(kctools.is_pd)
        else:
            # Should raise exception for pandas-dependent functions
            with self.assertRaises(Exception):
                # This would fail for any pandas-dependent function
                pass


class TestMatplotlibFunctions(unittest.TestCase):
    """Test matplotlib-dependent functions."""
    
    def setUp(self):
        """Check if matplotlib is available."""
        self.matplotlib_available = kctools.is_mpl
    
    def test_matplotlib_check_decorator(self):
        """Test matplotlib check decorator."""
        if not self.matplotlib_available:
            with self.assertRaises(Exception) as cm:
                kctools.make_heatmap([[1, 2], [3, 4]])
            self.assertIn('matplotlib', str(cm.exception).lower())
    
    @unittest.skipUnless(kctools.is_mpl, "matplotlib not available")
    def test_make_heatmap(self):
        """Test make_heatmap function."""
        import matplotlib.pyplot as plt
        import numpy as np
        
        # Test basic heatmap
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = kctools.make_heatmap(data, show=False)
        
        self.assertIsNotNone(fig)
        self.assertIsNotNone(ax)
        
        # Check that the data is plotted correctly
        plotted_data = ax.images[0].get_array()
        np.testing.assert_array_equal(plotted_data, np.array(data))
        
        plt.close(fig)
        
        # Test with normalization
        data = [[1, 2], [3, 4]]
        fig, ax = kctools.make_heatmap(data, norm=True, show=False)
        plt.close(fig)
        
        # Test with integer data
class TestDependencyChecks(unittest.TestCase):
    """Test dependency check decorators."""
    
    def test_np_check(self):
        """Test numpy check decorator behavior."""
        if kctools.is_np:
            # Should work normally
            result = kctools.normalize([1, 2, 3])
            self.assertIsNotNone(result)
        else:
            # Should raise exception
            with self.assertRaises(Exception):
                kctools.normalize([1, 2, 3])
    
    def test_pd_check(self):
        """Test pandas check decorator behavior."""
        if kctools.is_pd:
            # Should work normally
            import pandas as pd
            df = pd.DataFrame({'A': [1, 2, 3]})
            # Test that pandas is available
            self.assertTrue(kctools.is_pd)
        else:
            # Should raise exception for pandas-dependent functions
            with self.assertRaises(Exception):
                # This would fail for any pandas-dependent function
                pass
    
    def test_sci_check(self):
        """Test scipy check decorator behavior."""
        if kctools.is_sci:
            # Should work normally
            result = kctools.lower_conf_bound(10, 5)
            self.assertIsNotNone(result)
        else:
            # Should raise exception
            with self.assertRaises(Exception):
                kctools.lower_conf_bound(10, 5)
    
    def test_mpl_check(self):
        """Test matplotlib check decorator behavior."""
        if kctools.is_mpl:
            # Should work normally
            fig, ax = kctools.make_heatmap([[1, 2]], show=False)
            self.assertIsNotNone(fig)
        else:
            # Should raise exception
            with self.assertRaises(Exception):
                kctools.make_heatmap([[1, 2]])


if __name__ == '__main__':
    # Create a test suite
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    
    # Run the tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print(f"\nTest Summary:")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped)}")
    
    if result.failures:
        print("\nFailures:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nErrors:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
