import unittest
import sys
import os

# Add to kctools directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'kctools'))

from classes.lock import Lock, locker


class TestLock(unittest.TestCase):
    """Test Lock class functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.lock_obj = Lock()
    
    def test_copy(self):
        """Test copy method."""
        # Test basic copy
        original = Lock()
        original._lock = True
        original.test_attr = "test_value"
        
        copy_obj = original.copy()
        
        # Should be different objects
        self.assertIsNot(original, copy_obj)
        self.assertIsNot(original.__dict__, copy_obj.__dict__)
        
        # Should have same attributes
        self.assertEqual(copy_obj._lock, True)
        self.assertEqual(copy_obj.test_attr, "test_value")
        
        # Should be independent
        copy_obj._lock = False
        copy_obj.test_attr = "modified"
        self.assertEqual(original._lock, True)  # Original unchanged
        self.assertEqual(original.test_attr, "test_value")  # Original unchanged
    
    def test_lock(self):
        """Test lock method."""
        # Test locking
        result = self.lock_obj.lock(True)
        self.assertTrue(self.lock_obj._lock)
        self.assertIs(result, self.lock_obj)  # Should return self
        
        # Test unlocking
        result = self.lock_obj.lock(False)
        self.assertFalse(self.lock_obj._lock)
        self.assertIs(result, self.lock_obj)  # Should return self
        
        # Test with boolean conversion
        result = self.lock_obj.lock(1)
        self.assertTrue(self.lock_obj._lock)
        
        result = self.lock_obj.lock(0)
        self.assertFalse(self.lock_obj._lock)
    
    def test_unlock(self):
        """Test unlock method."""
        # Lock first
        self.lock_obj.lock(True)
        self.assertTrue(self.lock_obj._lock)
        
        # Unlock
        result = self.lock_obj.unlock()
        self.assertFalse(self.lock_obj._lock)
        self.assertIs(result, self.lock_obj)  # Should return self
    
    def test_locker_decorator_unlocked(self):
        """Test locker decorator when unlocked."""
        class TestClass(Lock):
            def __init__(self):
                super().__init__()
                self.value = 0
                self.history = []
            
            @locker
            def increment(self, amount=1):
                self.value += amount
                self.history.append(amount)
                return self
        
        obj = TestClass()
        obj.lock(False)  # Ensure unlocked
        
        # Method should modify original object
        result = obj.increment(5)
        
        self.assertIs(result, obj)  # Should return same object
        self.assertEqual(obj.value, 5)  # Original modified
        self.assertEqual(obj.history, [5])
    
    def test_locker_decorator_locked(self):
        """Test locker decorator when locked."""
        class TestClass(Lock):
            def __init__(self):
                super().__init__()
                self.value = 0
                self.history = []
            
            @locker
            def increment(self, amount=1):
                self.value += amount
                self.history.append(amount)
                return self
        
        obj = TestClass()
        obj.lock(True)  # Lock the object
        
        # Method should return copy, not modify original
        result = obj.increment(5)
        
        self.assertIsNot(result, obj)  # Should return different object
        self.assertEqual(obj.value, 0)  # Original unchanged
        self.assertEqual(obj.history, [])  # Original unchanged
        self.assertEqual(result.value, 5)  # Copy modified
        self.assertEqual(result.history, [5])  # Copy modified
        
        # Original should still be locked
        self.assertTrue(obj._lock)
        # Copy should also be locked
        self.assertTrue(result._lock)
    
    def test_locker_decorator_no_lock_attribute(self):
        """Test locker decorator when object has no _lock attribute."""
        class TestClass:
            def __init__(self):
                self.value = 0
            
            @locker
            def increment(self, amount=1):
                self.value += amount
                return self
        
        obj = TestClass()
        
        # Should work normally when no _lock attribute
        result = obj.increment(5)
        self.assertIs(result, obj)  # Should return same object
        self.assertEqual(obj.value, 5)
    
    def test_locker_decorator_nested_objects(self):
        """Test locker decorator with nested objects."""
        class TestClass(Lock):
            def __init__(self):
                super().__init__()
                self.nested = {'data': [1, 2, 3]}
            
            @locker
            def add_nested(self, value):
                self.nested['data'].append(value)
                return self
        
        obj = TestClass()
        obj.lock(True)
        
        result = obj.add_nested(4)
        
        # Original should be unchanged
        self.assertEqual(obj.nested['data'], [1, 2, 3])
        # Copy should be modified
        self.assertEqual(result.nested['data'], [1, 2, 3, 4])
        
        # Verify deep copy - nested objects are independent
        result.nested['data'].append(5)
        self.assertEqual(obj.nested['data'], [1, 2, 3])  # Original still unchanged
        self.assertEqual(result.nested['data'], [1, 2, 3, 4, 5])  # Copy changed further
    
    def test_locker_decorator_multiple_calls(self):
        """Test locker decorator with multiple method calls."""
        class TestClass(Lock):
            def __init__(self):
                super().__init__()
                self.value = 0
            
            @locker
            def add(self, amount):
                self.value += amount
                return self
            
            @locker
            def multiply(self, factor):
                self.value *= factor
                return self
        
        obj = TestClass()
        obj.lock(True)
        
        # Chain operations
        result1 = obj.add(10)
        result2 = result1.multiply(2)
        
        # Original should be unchanged
        self.assertEqual(obj.value, 0)
        # Final result should be 20
        self.assertEqual(result2.value, 20)
        
        # All objects should be independent
        self.assertIsNot(obj, result1)
        self.assertIsNot(result1, result2)
    
    def test_locker_decorator_with_args_kwargs(self):
        """Test locker decorator with various arguments."""
        class TestClass(Lock):
            def __init__(self):
                super().__init__()
                self.data = {}
            
            @locker
            def update_data(self, key, value, extra=None):
                self.data[key] = value
                if extra:
                    self.data['extra'] = extra
                return self
        
        obj = TestClass()
        obj.lock(True)
        
        # Test with positional and keyword arguments
        result = obj.update_data('test', 42, extra='bonus')
        
        # Original should be unchanged
        self.assertEqual(obj.data, {})
        # Copy should be updated
        self.assertEqual(result.data, {'test': 42, 'extra': 'bonus'})


if __name__ == '__main__':
    unittest.main()
