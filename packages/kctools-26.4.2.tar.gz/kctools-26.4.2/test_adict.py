import unittest
import sys
import os

# Add the kctools directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'kctools'))

from classes.adict import ADict


class TestADict(unittest.TestCase):
    """Test ADict class functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.adict1 = ADict({'a': 1, 'b': 2, 'c': 3})
        self.adict2 = ADict({'a': 10, 'b': 20, 'd': 40})
        self.adict_nested1 = ADict({'x': ADict({'y': 5, 'z': 10}), 'w': 15})
        self.adict_nested2 = ADict({'x': ADict({'y': 2, 'u': 20}), 'v': 25})
        self.regular_dict = {'a': 100, 'e': 50}
    
    def test_init(self):
        """Test ADict initialization."""
        # Test with dictionary
        adict = ADict({'a': 1, 'b': 2})
        self.assertEqual(adict['a'], 1)
        self.assertEqual(adict['b'], 2)
        self.assertTrue(adict._default)
        
        # Test with list of tuples
        adict = ADict([('a', 1), ('b', 2)])
        self.assertEqual(adict['a'], 1)
        self.assertEqual(adict['b'], 2)
        
        # Test with default=False
        adict = ADict({'a': 1}, default=False)
        self.assertFalse(adict._default)
    
    def test_addition_with_dict(self):
        """Test addition with regular dictionary."""
        result = self.adict1 + self.regular_dict
        expected = {'a': 101, 'b': 2, 'c': 3, 'e': 50}
        self.assertEqual(result, expected)
    
    def test_addition_with_adict(self):
        """Test addition with another ADict."""
        result = self.adict1 + self.adict2
        expected = {'a': 11, 'b': 22, 'c': 3, 'd': 40}
        self.assertEqual(result, expected)
    
    def test_addition_nested_adict(self):
        """Test addition with nested ADict."""
        result = self.adict_nested1 + self.adict_nested2
        expected = {'x': {'y': 7, 'z': 10, 'u': 20}, 'w': 15, 'v': 25}
        self.assertEqual(result, expected)
    
    def test_addition_with_sets(self):
        """Test addition with sets."""
        adict1 = ADict({'a': {1, 2}, 'b': 3})
        adict2 = ADict({'a': {3, 4}, 'c': 5})
        result = adict1 + adict2
        expected = {'a': {1, 2, 3, 4}, 'b': 3, 'c': 5}
        self.assertEqual(result, expected)
    
    def test_raddition(self):
        """Test reverse addition."""
        result = self.regular_dict + self.adict1
        expected = {'a': 101, 'b': 2, 'c': 3, 'e': 50}
        self.assertEqual(result, expected)
    
    def test_addition_type_error(self):
        """Test addition with invalid type."""
        with self.assertRaises(TypeError):
            self.adict1 + "invalid"
        
        with self.assertRaises(TypeError):
            "invalid" + self.adict1
    
    def test_multiplication_with_number(self):
        """Test multiplication with number."""
        result = self.adict1 * 2
        expected = {'a': 2, 'b': 4, 'c': 6}
        self.assertEqual(result, expected)
    
    def test_multiplication_with_zero(self):
        """Test multiplication with zero."""
        result = self.adict1 * 0
        expected = {'a': 0, 'b': 0, 'c': 0}
        self.assertEqual(result, expected)
    
    def test_multiplication_with_dict(self):
        """Test multiplication with dictionary."""
        result = self.adict1 * {'a': 2, 'c': 3}
        expected = {'a': 2, 'b': 2, 'c': 9}
        self.assertEqual(result, expected)
    
    def test_rmultiplication(self):
        """Test reverse multiplication."""
        result = 2 * self.adict1
        expected = {'a': 2, 'b': 4, 'c': 6}
        self.assertEqual(result, expected)
    
    def test_multiplication_type_error(self):
        """Test multiplication with invalid type."""
        with self.assertRaises(TypeError):
            self.adict1 * "invalid"
        
        with self.assertRaises(TypeError):
            "invalid" * self.adict1
    
    def test_true_division_with_number(self):
        """Test true division with number."""
        result = self.adict1 / 2
        expected = {'a': 0.5, 'b': 1.0, 'c': 1.5}
        self.assertEqual(result, expected)
    
    def test_true_division_with_dict(self):
        """Test true division with dictionary."""
        result = self.adict1 / {'a': 2, 'c': 3}
        expected = {'a': 0.5, 'b': 2, 'c': 1.0}
        self.assertEqual(result, expected)
    
    def test_true_division_by_zero(self):
        """Test true division by zero."""
        with self.assertRaises(ZeroDivisionError):
            self.adict1 / 0
    
    def test_rtrue_division(self):
        """Test reverse true division."""
        result = 10 / self.adict1
        expected = {'a': 10, 'b': 5, 'c': 3.3333333333333335}
        self.assertEqual(result, expected)
    
    def test_floor_division_with_number(self):
        """Test floor division with number."""
        result = self.adict1 // 2
        expected = {'a': 0, 'b': 1, 'c': 1}
        self.assertEqual(result, expected)
    
    def test_floor_division_with_dict(self):
        """Test floor division with dictionary."""
        result = self.adict1 // {'a': 2, 'c': 3}
        expected = {'a': 0, 'b': 2, 'c': 1}
        self.assertEqual(result, expected)
    
    def test_floor_division_by_zero(self):
        """Test floor division by zero."""
        with self.assertRaises(ZeroDivisionError):
            self.adict1 // 0
    
    def test_rfloor_division(self):
        """Test reverse floor division."""
        result = 10 // self.adict1
        expected = {'a': 10, 'b': 5, 'c': 3}
        self.assertEqual(result, expected)
    
    def test_apply_with_number(self):
        """Test apply method with number."""
        result = self.adict1.apply(2, lambda x, y: x + y)
        expected = {'a': 3, 'b': 4, 'c': 5}
        self.assertEqual(result, expected)
    
    def test_apply_with_dict(self):
        """Test apply method with dictionary."""
        result = self.adict1.apply({'a': 5, 'c': 10}, lambda x, y: x * y)
        expected = {'a': 5, 'b': 2, 'c': 30}
        self.assertEqual(result, expected)
    
    def test_apply_with_default_false(self):
        """Test apply method with default=False."""
        adict = ADict({'a': 1, 'b': 2}, default=False)
        result = adict.apply({'c': 3, 'd': 4}, lambda x, y: x + y)
        expected = {'a': 1, 'b': 2}  # No new keys added
        self.assertEqual(result, expected)
    
    def test_apply_with_default_true(self):
        """Test apply method with default=True."""
        result = self.adict1.apply({'c': 10, 'd': 20}, lambda x, y: x + y, default=True)
        expected = {'a': 1, 'b': 2, 'c': 13, 'd': 20}
        self.assertEqual(result, expected)
    
    def test_apply_type_errors(self):
        """Test apply method type errors."""
        with self.assertRaises(TypeError):
            self.adict1.apply(2, "not a function")
        
        with self.assertRaises(TypeError):
            self.adict1.apply("invalid", lambda x, y: x + y)
    
    def test_deepcopy_independence(self):
        """Test that operations don't modify original."""
        original = ADict({'a': 1, 'b': 2})
        result = original + {'a': 10}
        
        # Original should be unchanged
        self.assertEqual(original, {'a': 1, 'b': 2})
        self.assertEqual(result, {'a': 11, 'b': 2})
        
        # Result should be independent
        result['a'] = 100
        self.assertEqual(original['a'], 1)  # Original unchanged
    
    def test_mixed_types(self):
        """Test operations with mixed types."""
        adict = ADict({'a': 1, 'b': 'string', 'c': [1, 2, 3]})
        
        # Addition should only affect numeric types
        result = adict + {'a': 5, 'b': ' appended'}
        expected = {'a': 6, 'b': 'string appended', 'c': [1, 2, 3]}
        self.assertEqual(result, expected)
        
        # Multiplication should only affect numeric types
        result = adict * 2
        expected = {'a': 2, 'b': 'string', 'c': [1, 2, 3]}
        self.assertEqual(result, expected)
    
    def test_empty_adict(self):
        """Test operations with empty ADict."""
        empty = ADict()
        
        # Addition
        result = empty + {'a': 1, 'b': 2}
        expected = {'a': 1, 'b': 2}
        self.assertEqual(result, expected)
        
        # Multiplication
        result = empty * 5
        self.assertEqual(result, {})
        
        # Division
        result = empty / 2
        self.assertEqual(result, {})
    
    def test_string_representation(self):
        """Test string representation."""
        adict = ADict({'a': 1, 'b': 2})
        str_repr = str(adict)
        self.assertIn('a', str_repr)
        self.assertIn('b', str_repr)
        self.assertIn('1', str_repr)
        self.assertIn('2', str_repr)


if __name__ == '__main__':
    unittest.main()
