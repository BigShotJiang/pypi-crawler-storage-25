"""
Runfra MCP server.

Exposes three tools that wrap the Runfra REST API as Model Context Protocol
calls so an LLM in Claude Desktop, Cursor, or any other MCP-aware host can
generate images and product scenes inside a conversation.

Auth
----
The server reads the Runfra API key from the ``RUNFRA_API_KEY`` environment
variable. The MCP host (Cursor / Claude Desktop) is responsible for setting
this when it spawns the server — see README for ``mcp.json`` examples.
The optional ``RUNFRA_BASE_URL`` env var overrides the API base URL
(default ``https://api.runfra.com``); useful for staging deployments.

Tools
-----
- runfra_create_image_job        text-to-image, returns job_id immediately.
- runfra_get_job_result          poll a job; optional bounded wait.
- runfra_create_product_scene    image-to-image from a public URL +
                                 scene prompt; combines /v1/uploads/input-image-by-url
                                 and /v1/jobs in one call.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any

import httpx
from fastmcp import FastMCP

# ─── Constants ──────────────────────────────────────────────────────────────

DEFAULT_BASE_URL = "https://api.runfra.com"
POLL_INTERVAL_S = 3.0
MAX_WAIT_SECONDS = 300  # hard cap so a tool call can never hang indefinitely

# Runfra rate-limits POST /v1/jobs at 20 req/min; GET /result at 120 req/min.
# Per-request timeout for the underlying HTTP client.
HTTP_REQUEST_TIMEOUT_S = 30.0

# ─── Auth + transport helpers ───────────────────────────────────────────────


def _api_key() -> str:
    key = os.environ.get("RUNFRA_API_KEY")
    if not key:
        raise RuntimeError(
            "RUNFRA_API_KEY environment variable is not set. "
            "Get a key at https://runfra.com/dashboard/api-keys and set it "
            "in your MCP client config (Claude Desktop / Cursor mcp.json)."
        )
    return key


def _base_url() -> str:
    return os.environ.get("RUNFRA_BASE_URL", DEFAULT_BASE_URL).rstrip("/")


def _headers() -> dict[str, str]:
    return {
        "X-API-Key": _api_key(),
        "Content-Type": "application/json",
    }


def _clamp_wait(seconds: int) -> int:
    if seconds < 0:
        return 0
    if seconds > MAX_WAIT_SECONDS:
        return MAX_WAIT_SECONDS
    return seconds


async def _poll_until_done(
    client: httpx.AsyncClient,
    job_id: str,
    wait_seconds: int,
) -> dict[str, Any]:
    """Internal helper. Polls /v1/jobs/{id}/result until terminal or timeout.

    On terminal state (200): returns the response body.
    On timeout: returns ``{job_id, status: 'running', timeout_exceeded: True}``.
    On error (4xx other than 202, or 5xx): raises RuntimeError with the body.
    """
    base = _base_url()
    deadline = asyncio.get_event_loop().time() + wait_seconds
    while True:
        r = await client.get(f"{base}/v1/jobs/{job_id}/result", headers=_headers())
        if r.status_code == 200:
            return r.json()
        if r.status_code != 202:
            raise RuntimeError(
                f"GET /v1/jobs/{job_id}/result returned {r.status_code}: {r.text}"
            )
        # 202 = still running.
        if asyncio.get_event_loop().time() >= deadline:
            return {
                "job_id": job_id,
                "status": "running",
                "timeout_exceeded": True,
                "wait_for_seconds_used": wait_seconds,
                "hint": (
                    "Job is still running. Call runfra_get_job_result with "
                    "the same job_id (and optionally a higher wait_for_seconds) "
                    "to check again."
                ),
            }
        await asyncio.sleep(POLL_INTERVAL_S)


# ─── MCP server ─────────────────────────────────────────────────────────────

mcp = FastMCP(
    name="Runfra",
    instructions=(
        "Tools for generating images via the Runfra API. "
        "Use runfra_create_image_job for text-to-image, "
        "runfra_create_product_scene for image-to-image from a public URL, "
        "and runfra_get_job_result to poll a job by ID. "
        "Reference image URLs must be public HTTPS — Runfra refuses private/"
        "internal IP ranges."
    ),
)


@mcp.tool
async def runfra_create_image_job(
    prompt: str,
    model: str = "stable-diffusion-xl-base-1.0",
    width: int = 1024,
    height: int = 1024,
    batch_size: int = 1,
    quality_mode: str = "strict",
    negative_prompt: str | None = None,
) -> dict[str, Any]:
    """Submit a text-to-image generation job.

    Returns immediately with the job_id and seeds. Call
    runfra_get_job_result(job_id, wait_for_seconds=...) to fetch results.

    Args:
        prompt: 1–2000 characters describing the image to generate.
        model: Model name. One of ``stable-diffusion-xl-base-1.0`` (SDXL,
            default), ``flux-schnell``, or ``flux-dev`` (RunFra Pro).
            Cost scales with model + resolution; SDXL 1024×1024 is 3 credits/image,
            flux-schnell is 4, flux-dev is 14.
        width: Output width in pixels, 512–1024.
        height: Output height in pixels, 512–1024.
        batch_size: Number of candidate images to generate. 1–100. Tier caps
            apply: anonymous=4, free=8, paid=100. Larger batches improve the
            Top Pick selection.
        quality_mode: ``strict`` (default), ``soft``, or ``off``. Controls
            how aggressively the quality filter rejects candidates.
        negative_prompt: Optional. Things to avoid. Silently ignored by
            flux-schnell and flux-dev.

    Returns:
        ``{"job_id": str, "status": "queued", "seeds": list[int]}``
    """
    payload: dict[str, Any] = {
        "prompt": prompt,
        "model_name": model,
        "width": width,
        "height": height,
        "batch_size": batch_size,
        "quality_mode": quality_mode,
    }
    if negative_prompt:
        payload["negative_prompt"] = negative_prompt

    base = _base_url()
    async with httpx.AsyncClient(timeout=HTTP_REQUEST_TIMEOUT_S) as client:
        r = await client.post(f"{base}/v1/jobs", json=payload, headers=_headers())
    if r.status_code != 201:
        raise RuntimeError(
            f"POST /v1/jobs returned HTTP {r.status_code}: {r.text}"
        )
    return r.json()


@mcp.tool
async def runfra_get_job_result(
    job_id: str,
    wait_for_seconds: int = 0,
) -> dict[str, Any]:
    """Get the current state of a Runfra job.

    By default returns the latest snapshot in one shot — non-blocking. If
    ``wait_for_seconds`` is greater than 0, polls every 3 seconds until
    terminal (succeeded / failed / cancelled) or the timeout elapses; on
    timeout returns the in-progress state with ``timeout_exceeded: true``.

    Args:
        job_id: The job UUID returned by runfra_create_image_job or
            runfra_create_product_scene.
        wait_for_seconds: 0 (default) returns immediately. Otherwise the
            maximum time to wait, in seconds. Hard-capped at 300.

    Returns:
        Terminal: ``{job_id, status: "succeeded"|"failed"|"cancelled",
        best_result_url?, result_urls?, items?, ...}``.
        Mid-flight: ``{detail: "Job is running"}`` (when ``wait_for_seconds=0``).
        Timeout: as terminal but with ``timeout_exceeded: true``.
    """
    wait_for_seconds = _clamp_wait(wait_for_seconds)
    base = _base_url()
    async with httpx.AsyncClient(timeout=HTTP_REQUEST_TIMEOUT_S) as client:
        if wait_for_seconds == 0:
            r = await client.get(
                f"{base}/v1/jobs/{job_id}/result", headers=_headers()
            )
            if r.status_code in (200, 202):
                body = r.json()
                if r.status_code == 202:
                    body.setdefault("job_id", job_id)
                    body.setdefault("status", "running")
                return body
            raise RuntimeError(
                f"GET /v1/jobs/{job_id}/result returned HTTP {r.status_code}: "
                f"{r.text}"
            )
        return await _poll_until_done(client, job_id, wait_for_seconds)


@mcp.tool
async def runfra_create_product_scene(
    image_url: str,
    scene_prompt: str,
    width: int = 512,
    height: int = 512,
    strength: float = 0.6,
    crop_anchor: str = "center",
    wait_for_seconds: int = 90,
) -> dict[str, Any]:
    """Generate a product scene from a public image URL plus a scene prompt.

    Two backend calls in one tool:
      1. POST /v1/uploads/input-image-by-url — server fetches the public URL
         (SSRF-guarded; private IPs are refused), normalises to RGB PNG,
         registers a private 24-hour stored asset.
      2. POST /v1/jobs with pipeline_mode=img2img — runs SDXL img2img against
         the stored reference image.

    Locked to SDXL; output capped at 768×768. By default the tool polls up
    to 90 seconds for completion (most product-scene jobs finish within
    that window); set ``wait_for_seconds=0`` for fire-and-forget and pair
    with runfra_get_job_result later.

    Args:
        image_url: Public HTTPS URL of the product / reference image.
            PNG, JPEG, or WebP, ≤10 MB, longest side ≤1024 px. http://,
            file://, data:, and any host that resolves to a private/reserved
            IP range are refused.
        scene_prompt: 1–2000 characters describing the desired scene
            ("on a marble countertop in golden-hour light"). The reference
            image dictates composition; this prompt drives style and
            surroundings.
        width: Output width 384–768, multiple of 64. Default 512.
        height: Output height 384–768, multiple of 64. Default 512.
            ``width × height`` must not exceed 768 × 768.
        strength: Denoising strength 0.4–0.9. Lower keeps the reference
            visible; higher lets the prompt re-imagine the frame. Default 0.6.
        crop_anchor: Where to anchor the cover-crop when the reference and
            output aspect ratios differ. ``center`` (default), ``top``,
            ``bottom``, ``left``, ``right``, ``top-left``, ``top-right``,
            ``bottom-left``, ``bottom-right``.
        wait_for_seconds: 0 returns the job_id immediately; otherwise polls
            up to that many seconds for completion. Hard-capped at 300.

    Returns:
        On completion: ``{job_id, status: "succeeded", best_result_url, ...}``.
        On timeout: ``{job_id, status: "running", timeout_exceeded: true}``.
    """
    wait_for_seconds = _clamp_wait(wait_for_seconds)
    base = _base_url()
    headers = _headers()

    async with httpx.AsyncClient(timeout=HTTP_REQUEST_TIMEOUT_S) as client:
        # ── 1. Fetch the URL into private storage ──
        r = await client.post(
            f"{base}/v1/uploads/input-image-by-url",
            json={"image_url": image_url},
            headers=headers,
        )
        if r.status_code != 201:
            raise RuntimeError(
                f"POST /v1/uploads/input-image-by-url returned HTTP "
                f"{r.status_code}: {r.text}"
            )
        upload = r.json()
        storage_key = upload.get("input_storage_key")
        if not storage_key:
            raise RuntimeError(
                f"Runfra did not return input_storage_key: {upload}"
            )

        # ── 2. Submit img2img job ──
        r = await client.post(
            f"{base}/v1/jobs",
            json={
                "prompt": scene_prompt,
                "pipeline_mode": "img2img",
                "input_storage_key": storage_key,
                "width": width,
                "height": height,
                "strength": strength,
                "crop_anchor": crop_anchor,
                "batch_size": 1,
                # Server locks img2img to SDXL regardless; sending it makes intent explicit.
                "model_name": "stable-diffusion-xl-base-1.0",
            },
            headers=headers,
        )
        if r.status_code != 201:
            raise RuntimeError(
                f"POST /v1/jobs (img2img) returned HTTP {r.status_code}: {r.text}"
            )
        submit = r.json()

        if wait_for_seconds == 0:
            return submit

        # ── 3. Poll until terminal or timeout ──
        return await _poll_until_done(client, submit["job_id"], wait_for_seconds)


# ─── Entry point ────────────────────────────────────────────────────────────


def main() -> None:
    """Run the MCP server using FastMCP's default stdio transport.

    MCP clients (Claude Desktop, Cursor) spawn this process and communicate
    with it over stdin/stdout — no network port is opened.
    """
    mcp.run()


if __name__ == "__main__":
    main()
