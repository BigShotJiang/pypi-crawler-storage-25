"""Runfra MCP server — three tools that wrap the Runfra image generation API."""

from runfra_mcp.server import main, mcp

__version__ = "0.1.0"
__all__ = ["main", "mcp"]
