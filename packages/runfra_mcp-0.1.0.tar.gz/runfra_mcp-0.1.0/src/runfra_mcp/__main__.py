"""Allow `python -m runfra_mcp` as an alternative to the `runfra-mcp` script."""

from runfra_mcp.server import main

if __name__ == "__main__":
    main()
