"""Low-level scan result contracts shared by core, models, and scanners."""

import json
import logging
import time
from enum import Enum
from typing import Any, Final

from pydantic import BaseModel, ConfigDict, Field, field_serializer

logger = logging.getLogger("modelaudit.scanners")

INCONCLUSIVE_SCAN_OUTCOME: Final[str] = "inconclusive"
SCAN_OUTCOME_METADATA_KEY: Final[str] = "scan_outcome"
SCAN_OUTCOME_REASONS_METADATA_KEY: Final[str] = "scan_outcome_reasons"
SCAN_OUTCOME_MESSAGE_METADATA_KEY: Final[str] = "scan_outcome_message"
OPERATIONAL_ERROR_METADATA_KEY: Final[str] = "operational_error"
UNCLASSIFIED_SCAN_FAILURE_REASON: Final[str] = "scanner_reported_unsuccessful_without_outcome"


def scan_result_has_inconclusive_outcome(scan_result: "ScanResult") -> bool:
    """Return True when the scanner explicitly marked coverage as inconclusive."""
    return scan_result.metadata.get(SCAN_OUTCOME_METADATA_KEY) == INCONCLUSIVE_SCAN_OUTCOME


def mark_inconclusive_scan_result(scan_result: "ScanResult", reason: str) -> None:
    """Mark a scan result as inconclusive while preserving existing reasons."""
    scan_result.metadata["analysis_incomplete"] = True
    scan_result.metadata[SCAN_OUTCOME_METADATA_KEY] = INCONCLUSIVE_SCAN_OUTCOME
    scan_result.metadata.setdefault(
        SCAN_OUTCOME_MESSAGE_METADATA_KEY,
        "Scan analysis incomplete; failed closed because full coverage was not available.",
    )

    existing_reasons = scan_result.metadata.get(SCAN_OUTCOME_REASONS_METADATA_KEY)
    reasons = existing_reasons if isinstance(existing_reasons, list) else []
    if reason not in reasons:
        reasons.append(reason)
    scan_result.metadata[SCAN_OUTCOME_REASONS_METADATA_KEY] = reasons
    scan_result._refresh_metadata_dependent_state()


def normalize_unclassified_scan_failure(scan_result: "ScanResult") -> None:
    """Fail closed when a scanner reports success=False without explicit outcome metadata."""
    if scan_result.success:
        return
    if bool(scan_result.metadata.get(OPERATIONAL_ERROR_METADATA_KEY)):
        return
    if scan_result_has_inconclusive_outcome(scan_result):
        return
    mark_inconclusive_scan_result(scan_result, UNCLASSIFIED_SCAN_FAILURE_REASON)


class IssueSeverity(Enum):
    """Enum for issue severity levels"""

    DEBUG = "debug"  # Debug information
    INFO = "info"  # Informational, not a security concern
    WARNING = "warning"  # Potential issue, needs review
    CRITICAL = "critical"  # Definite security concern


class CheckStatus(Enum):
    """Enum for check status"""

    PASSED = "passed"  # Check passed successfully
    FAILED = "failed"  # Check failed (issue found)
    SKIPPED = "skipped"  # Check was skipped


class Check(BaseModel):
    """Pydantic model representing a single security check performed during scanning"""

    model_config = ConfigDict(
        validate_assignment=True,
        extra="allow",  # Allow extra fields for extensibility
    )

    name: str = Field(..., description="Name of the check performed")
    status: CheckStatus = Field(..., description="Whether the check passed or failed")
    message: str = Field(..., description="Description of what was checked")
    severity: IssueSeverity | None = Field(None, description="Severity (only for failed checks)")
    location: str | None = Field(None, description="File position, line number, etc.")
    details: dict[str, Any] = Field(default_factory=dict, description="Additional check details")
    why: str | None = Field(None, description="Explanation (mainly for failed checks)")
    rule_code: str | None = Field(default=None, description="Rule code associated with this check")
    timestamp: float = Field(default_factory=time.time, description="Timestamp when check was performed")

    @field_serializer("status")
    def serialize_status(self, status: CheckStatus) -> str:
        """Serialize status enum to string value"""
        return status.value

    @field_serializer("severity")
    def serialize_severity(self, severity: IssueSeverity | None) -> str | None:
        """Serialize severity enum to string value"""
        return severity.value if severity else None

    def to_dict(self) -> dict[str, Any]:
        """Convert the check to a dictionary for serialization (backward compatibility)"""
        return self.model_dump(exclude_none=True, mode="json")

    def __str__(self) -> str:
        """String representation of the check"""
        status_symbol = "✓" if self.status == CheckStatus.PASSED else "✗"
        prefix = f"[{status_symbol}] {self.name}"
        if self.rule_code:
            prefix = f"[{self.rule_code}] {prefix}"
        if self.location:
            prefix += f" ({self.location})"
        return f"{prefix}: {self.message}"


class Issue(BaseModel):
    """Pydantic model representing a single issue found during scanning"""

    model_config = ConfigDict(
        validate_assignment=True,
        extra="allow",  # Allow extra fields for extensibility
    )

    message: str = Field(..., description="Description of the issue")
    severity: IssueSeverity = Field(default=IssueSeverity.WARNING, description="Issue severity level")
    location: str | None = Field(None, description="File position, line number, etc.")
    details: dict[str, Any] = Field(default_factory=dict, description="Additional details about the issue")
    why: str | None = Field(None, description="Explanation of why this is a security concern")
    timestamp: float = Field(default_factory=time.time, description="Timestamp when issue was detected")
    type: str | None = Field(None, description="Type of issue for categorization")
    rule_code: str | None = Field(default=None, description="Rule code associated with this issue")

    @field_serializer("severity")
    def serialize_severity(self, severity: IssueSeverity) -> str:
        """Serialize severity enum to string value"""
        return severity.value

    def to_dict(self) -> dict[str, Any]:
        """Convert the issue to a dictionary for serialization (backward compatibility)"""
        return self.model_dump(exclude_none=True, mode="json")

    def __str__(self) -> str:
        """String representation of the issue"""
        severity_str = self.severity.value if hasattr(self.severity, "value") else str(self.severity)
        prefix = f"[{severity_str.upper()}]"
        if self.rule_code:
            prefix = f"[{self.rule_code}] {prefix}"
        if self.location:
            prefix += f" ({self.location})"
        return f"{prefix}: {self.message}"


class ScanResult:
    """Collects and manages issues found during scanning"""

    def __init__(self, scanner_name: str = "unknown", scanner: Any | None = None):
        self.scanner_name = scanner_name
        self.scanner = scanner  # Reference to the scanner for whitelist checks
        self.issues: list[Issue] = []
        self.checks: list[Check] = []  # All checks performed (passed and failed)
        self.start_time = time.time()
        self.end_time: float | None = None
        self.bytes_scanned: int = 0
        self.success: bool = True
        self.metadata: dict[str, Any] = {}
        self._metadata_restored_critical: bool = False

    def add_check(
        self,
        name: str,
        passed: bool,
        message: str,
        severity: IssueSeverity | None = None,
        location: str | None = None,
        details: dict[str, Any] | None = None,
        why: str | None = None,
        rule_code: str | None = None,
    ) -> None:
        """Add a check result (passed or failed) with rule support and rule-based severity."""
        from .config import get_config
        from .config.explanations import get_message_explanation
        from .rules import RuleRegistry, Severity

        severity_map = {
            Severity.CRITICAL: IssueSeverity.CRITICAL,
            Severity.HIGH: IssueSeverity.CRITICAL,
            Severity.MEDIUM: IssueSeverity.WARNING,
            Severity.LOW: IssueSeverity.INFO,
            Severity.INFO: IssueSeverity.INFO,
        }

        # Auto-detect rule code if not provided.
        # Preserve scanner-provided severity semantics by only attaching the
        # code here, not remapping severity from rule defaults.
        if not rule_code and not passed:
            match = RuleRegistry.find_matching_rule(message)
            if match:
                rule_code, _rule = match

        config = get_config()

        # Check if rule is suppressed
        if rule_code and config.is_suppressed(rule_code, location):
            logger.debug(f"Suppressed {rule_code}: {message}")
            return

        # Apply severity override only when explicitly configured by the user.
        if rule_code and rule_code in config.severity:
            configured_severity = config.get_severity(rule_code, Severity.MEDIUM)
            mapped = severity_map.get(configured_severity)
            if mapped is not None:
                severity = mapped

        status = CheckStatus.PASSED if passed else CheckStatus.FAILED

        # For failed checks, ensure we have a severity
        if not passed and severity is None:
            severity = IssueSeverity.WARNING

        # Apply whitelist downgrading logic for failed checks if scanner is available
        if not passed and self.scanner:
            # At this point severity cannot be None due to the check above
            assert severity is not None
            severity, details = self.scanner._apply_whitelist_downgrade(
                severity,
                details,
                result_metadata=self.metadata,
                message=message,
                rule_code=rule_code,
                check_name=name,
            )

        check = Check(
            name=name,
            status=status,
            message=message,
            severity=severity,
            location=location,
            details=details or {},
            why=why,
            rule_code=rule_code,
        )
        self.checks.append(check)

        # If the check failed, also add it as an issue for backward compatibility
        if not passed:
            if why is None:
                why = get_message_explanation(message, context=self.scanner_name)
            # Severity should never be None here due to check above, but add assertion for type checker
            assert severity is not None

            # Note: whitelist downgrading was already applied above (lines 160-163)
            # before creating the Check, so we use the same downgraded severity here

            issue = Issue(
                message=message,
                severity=severity,
                location=location,
                details=details or {},
                why=why,
                type=f"{self.scanner_name}_check",
                rule_code=rule_code,
            )
            self.issues.append(issue)

            log_level = (
                logging.CRITICAL
                if severity == IssueSeverity.CRITICAL
                else (
                    logging.WARNING
                    if severity == IssueSeverity.WARNING
                    else (logging.INFO if severity == IssueSeverity.INFO else logging.DEBUG)
                )
            )
            logger.log(log_level, str(issue))
        else:
            # Log successful checks at DEBUG level
            logger.debug(f"Check passed: {name} - {message}")

    def _add_issue(
        self,
        message: str,
        severity: IssueSeverity = IssueSeverity.WARNING,
        location: str | None = None,
        details: dict[str, Any] | None = None,
        why: str | None = None,
        rule_code: str | None = None,
    ) -> None:
        """Add an issue to the result with rule support"""
        # For backward compatibility: INFO/DEBUG severities are treated as passing checks
        passed = severity in (IssueSeverity.DEBUG, IssueSeverity.INFO)
        self.add_check(
            name="Legacy Security Check",
            passed=passed,
            message=message,
            severity=severity,
            location=location,
            details=details,
            why=why,
            rule_code=rule_code,
        )
        if passed:
            return

    def add_issue(
        self,
        message: str,
        severity: IssueSeverity = IssueSeverity.WARNING,
        location: str | None = None,
        details: dict[str, Any] | None = None,
        why: str | None = None,
        rule_code: str | None = None,
    ) -> None:
        """Backward-compatible public issue adder."""
        self._add_issue(message, severity=severity, location=location, details=details, why=why, rule_code=rule_code)

    def merge(self, other: "ScanResult") -> None:
        """Merge another scan result into this one"""
        self.issues.extend(other.issues)
        self.checks.extend(other.checks)  # Merge checks as well
        self.bytes_scanned += other.bytes_scanned
        # Merge metadata dictionaries
        for key, value in other.metadata.items():
            if key in self.metadata and isinstance(self.metadata[key], dict) and isinstance(value, dict):
                self.metadata[key].update(value)
            else:
                self.metadata[key] = value

    def finish(self, success: bool = True) -> None:
        """Mark the scan as finished"""
        restored_critical = self._restore_result_metadata_whitelist_downgrades()
        self.end_time = time.time()
        self.success = success
        if (restored_critical or self._metadata_restored_critical) and self.has_errors:
            self.success = False

    @staticmethod
    def _severity_from_original_whitelist_value(value: Any) -> IssueSeverity | None:
        if isinstance(value, IssueSeverity):
            return value
        if not isinstance(value, str):
            return None
        try:
            return IssueSeverity[value]
        except KeyError:
            try:
                return IssueSeverity(value.lower())
            except ValueError:
                return None

    def _restore_result_metadata_whitelist_downgrades(self) -> bool:
        """Restore downgraded severities when result metadata later marks incomplete coverage."""
        metadata_exempt = getattr(self.scanner, "_result_metadata_whitelist_downgrade_exempt", None)
        if not callable(metadata_exempt) or not metadata_exempt(self.metadata):
            return False

        restored_critical = False

        def restore_finding(finding: Check | Issue) -> None:
            nonlocal restored_critical
            if finding.details.get("whitelist_downgrade") is not True:
                return
            original_severity = self._severity_from_original_whitelist_value(finding.details.get("original_severity"))
            if original_severity is None:
                return
            finding.severity = original_severity
            finding.details.pop("whitelist_downgrade", None)
            finding.details["whitelist_downgrade_restored"] = True
            if original_severity == IssueSeverity.CRITICAL:
                restored_critical = True

        for check in self.checks:
            restore_finding(check)
        for issue in self.issues:
            restore_finding(issue)
        if restored_critical:
            self._metadata_restored_critical = True
        return restored_critical

    def _refresh_metadata_dependent_state(self) -> None:
        """Reconcile severities and success after metadata changes outside finish()."""
        restored_critical = self._restore_result_metadata_whitelist_downgrades()
        if self.end_time is not None and restored_critical and self.has_errors:
            self.success = False

    @property
    def duration(self) -> float:
        """Return the duration of the scan in seconds"""
        if self.end_time is None:
            return time.time() - self.start_time
        return self.end_time - self.start_time

    @property
    def has_errors(self) -> bool:
        """Return True if there are any critical-level issues"""
        return any(issue.severity == IssueSeverity.CRITICAL for issue in self.issues)

    @property
    def has_warnings(self) -> bool:
        """Return True if there are any warning-level issues"""
        return any(issue.severity == IssueSeverity.WARNING for issue in self.issues)

    def to_dict(self) -> dict[str, Any]:
        """Convert the scan result to a dictionary for serialization"""
        # Only count WARNING and CRITICAL severity checks as failures
        # INFO and DEBUG are informational - they should not count as failures
        failed_checks_count = sum(
            1
            for c in self.checks
            if c.status == CheckStatus.FAILED and c.severity in (IssueSeverity.WARNING, IssueSeverity.CRITICAL)
        )

        return {
            "scanner": self.scanner_name,
            "success": self.success,
            "duration": self.duration,
            "bytes_scanned": self.bytes_scanned,
            "issues": [issue.to_dict() for issue in self.issues],
            "checks": [check.to_dict() for check in self.checks],  # Include all checks
            "metadata": self.metadata,
            "has_errors": self.has_errors,
            "has_warnings": self.has_warnings,
            "total_checks": len(self.checks),
            "passed_checks": sum(1 for c in self.checks if c.status == CheckStatus.PASSED),
            "failed_checks": failed_checks_count,
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert the scan result to a JSON string"""
        return json.dumps(self.to_dict(), indent=indent)

    def summary(self) -> str:
        """Return a human-readable summary of the scan result"""
        error_count = sum(1 for issue in self.issues if issue.severity == IssueSeverity.CRITICAL)
        warning_count = sum(1 for issue in self.issues if issue.severity == IssueSeverity.WARNING)
        info_count = sum(1 for issue in self.issues if issue.severity == IssueSeverity.INFO)

        result = []
        result.append(f"Scan completed in {self.duration:.2f}s")
        result.append(
            f"Scanned {self.bytes_scanned} bytes with scanner '{self.scanner_name}'",
        )
        result.append(
            f"Found {len(self.issues)} issues ({error_count} critical, {warning_count} warnings, {info_count} info)",
        )

        # If there are any issues, show them
        if self.issues:
            result.append("\nIssues:")
            for issue in self.issues:
                result.append(f"  {issue}")

        return "\n".join(result)

    def __str__(self) -> str:
        """String representation of the scan result"""
        return self.summary()
