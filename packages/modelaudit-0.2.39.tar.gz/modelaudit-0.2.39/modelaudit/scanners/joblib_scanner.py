"""Scanner for Joblib serialized model files (.joblib)."""

from __future__ import annotations

import bz2
import io
import lzma
import os
import pickletools
import zlib
from collections.abc import Callable
from contextlib import suppress
from typing import Any, ClassVar

from ..detectors.cve_patterns import analyze_cve_patterns, enhance_scan_result_with_cve
from ..scanner_selection import add_scanner_selection_skip_check, embedded_pickle_scanner
from ..utils.file.detection import read_magic_bytes
from .base import INCONCLUSIVE_SCAN_OUTCOME, BaseScanner, IssueSeverity, ScanResult
from .pickle_scanner import PickleScanner, _looks_like_pickle

_JOBLIB_NUMPY_ARRAY_WRAPPER_REF = "joblib.numpy_pickle.NumpyArrayWrapper"
_JOBLIB_NUMPY_ARRAY_REQUIRED_REFS = {
    _JOBLIB_NUMPY_ARRAY_WRAPPER_REF,
    "numpy.ndarray",
    "numpy.dtype",
}
_JOBLIB_NUMPY_ARRAY_MODULE_PREFIXES = ("joblib.numpy_pickle", "numpy")
_MAX_JOBLIB_ARRAY_ALIGNMENT_PADDING = 64
_JOBLIB_TAIL_DANGER_SCAN_BYTES = 4096
_JOBLIB_TAIL_DANGEROUS_SEEDS = (
    b"\x80\x01",
    b"\x80\x02",
    b"\x80\x03",
    b"\x80\x04",
    b"\x80\x05",
    b"cos\n",
    b"cposix\n",
    b"cnt\n",
    b"subprocess",
    b"os.system",
    b"builtins",
    b"eval",
    b"exec",
    b"pickle.loads",
    b"marshal.loads",
)


def _has_trusted_joblib_numpy_array_refs(references: object) -> bool:
    """Return True for the narrow benign import set used by Joblib numpy arrays."""
    if not isinstance(references, list):
        return False

    observed_refs: set[str] = set()
    for reference in references:
        if not isinstance(reference, dict) or bool(reference.get("is_dangerous")):
            return False
        import_reference = reference.get("import_reference")
        module = reference.get("module")
        if not isinstance(import_reference, str) or not isinstance(module, str):
            return False
        if module not in _JOBLIB_NUMPY_ARRAY_MODULE_PREFIXES and not any(
            module.startswith(f"{prefix}.") for prefix in _JOBLIB_NUMPY_ARRAY_MODULE_PREFIXES
        ):
            return False
        observed_refs.add(import_reference)

    return _JOBLIB_NUMPY_ARRAY_REQUIRED_REFS.issubset(observed_refs)


def _parse_unknown_opcode_position(result: ScanResult) -> int | None:
    for issue in result.issues:
        if issue.rule_code != "S901" or issue.details.get("category") != "parse_error":
            continue
        position = _parse_position_from_exception(issue.details.get("parse_error"))
        if position is not None:
            return position

    for check in result.checks:
        if check.rule_code != "S902" or check.details.get("notice_code") != "parse_incomplete":
            continue
        position = _parse_position_from_exception(check.details.get("exception"))
        if position is not None:
            return position

    return None


def _parse_position_from_exception(exception: object) -> int | None:
    if not isinstance(exception, str) or "at position " not in exception:
        return None
    position_text = exception.split("at position ", 1)[1].split(",", 1)[0]
    try:
        return int(position_text)
    except ValueError:
        return None


def _looks_like_joblib_numpy_array_tail(tail: bytes) -> bool:
    """Return True for Joblib's raw ndarray tail framing after NumpyArrayWrapper metadata."""
    if not tail:
        return False
    padding_length = tail[0]
    if padding_length > _MAX_JOBLIB_ARRAY_ALIGNMENT_PADDING or padding_length >= len(tail):
        return False

    padding = tail[1 : 1 + padding_length]
    if padding != (b"\xff" * padding_length):
        return False

    raw_array_data = tail[1 + padding_length :]
    if not raw_array_data:
        return False
    if _looks_like_pickle(raw_array_data):
        return False

    probe = raw_array_data[:_JOBLIB_TAIL_DANGER_SCAN_BYTES].lower()
    return not any(seed in probe for seed in _JOBLIB_TAIL_DANGEROUS_SEEDS)


class JoblibScanner(BaseScanner):
    """Scanner for joblib serialized files."""

    name = "joblib"
    description = "Scans joblib files by decompressing and analyzing embedded pickle"
    supported_extensions: ClassVar[list[str]] = [".joblib"]

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize Joblib scanning limits and the embedded Pickle scanner."""
        super().__init__(config)
        self.pickle_scanner, self.scanner_selection = embedded_pickle_scanner(self.config, PickleScanner)
        # Security limits
        self.max_decompression_ratio = self.config.get("max_decompression_ratio", 100.0)
        self.max_decompressed_size = self.config.get(
            "max_decompressed_size",
            10 * 1024 * 1024 * 1024,
        )  # 10GB for large ML models
        self.chunk_size = self.config.get("chunk_size", 8192)  # 8KB chunks

    @classmethod
    def can_handle(cls, path: str) -> bool:
        """Return True for existing `.joblib` files."""
        if not os.path.isfile(path):
            return False
        ext = os.path.splitext(path)[1].lower()
        return ext == ".joblib"

    def _read_file_safely(self, path: str) -> bytes:
        """Read file in chunks using the base class helper."""
        return super()._read_file_safely(path)

    def _max_decompressed_output_bytes(self, compressed_size: int) -> int:
        """Compute the effective decompression output cap for one compressed payload."""
        max_by_ratio = self.max_decompressed_size
        if compressed_size > 0:
            max_by_ratio = int(self.max_decompression_ratio * compressed_size)
        return min(self.max_decompressed_size, max_by_ratio)

    def _check_decompressed_size(self, decompressed_size: int) -> None:
        """Fail when the decompressed payload exceeds the absolute size limit."""
        if decompressed_size > self.max_decompressed_size:
            raise ValueError(
                f"Decompressed size too large: {decompressed_size} bytes (max: {self.max_decompressed_size})",
            )

    def _check_decompression_ratio(self, decompressed_size: int, compressed_size: int) -> None:
        """Fail when decompression expands beyond the configured ratio limit."""
        if compressed_size <= 0:
            return

        ratio = decompressed_size / compressed_size
        if ratio > self.max_decompression_ratio:
            raise ValueError(
                f"Suspicious compression ratio: {ratio:.1f}x (max: {self.max_decompression_ratio}x) - "
                f"possible compression bomb"
            )

    def _decompress_with_limited_output(self, decompressor: Any, data: bytes) -> bytes:
        """Decompress one stream while enforcing absolute-size and ratio budgets."""
        compressed_size = len(data)
        max_output_bytes = self._max_decompressed_output_bytes(compressed_size)
        output_limit = max_output_bytes + 1

        decompressed = bytearray(decompressor.decompress(data, output_limit))
        if len(decompressed) > output_limit:
            raise ValueError("Internal decompression limit exceeded")

        self._check_decompressed_size(len(decompressed))
        self._check_decompression_ratio(len(decompressed), compressed_size)

        if len(decompressed) == output_limit:
            raise ValueError(
                f"Decompressed size too large: {len(decompressed)} bytes (max: {max_output_bytes})",
            )

        remaining_output_budget = output_limit - len(decompressed)
        if remaining_output_budget > 0 and hasattr(decompressor, "flush"):
            decompressed.extend(decompressor.flush(remaining_output_budget))
            self._check_decompressed_size(len(decompressed))
            self._check_decompression_ratio(len(decompressed), compressed_size)
            if len(decompressed) > output_limit:
                raise ValueError(
                    f"Decompressed size too large: {len(decompressed)} bytes (max: {max_output_bytes})",
                )

        if getattr(decompressor, "unused_data", b""):
            raise ValueError("Trailing data found after compressed joblib stream")

        if not getattr(decompressor, "eof", True):
            raise ValueError("Incomplete compressed joblib stream")

        return bytes(decompressed)

    def _safe_decompress(self, data: bytes) -> bytes:
        """Safely decompress data with bomb protection"""
        codec_attempts: list[tuple[str, Callable[[], Any]]] = [
            ("zlib", zlib.decompressobj),
            ("gzip", lambda: zlib.decompressobj(zlib.MAX_WBITS | 16)),
            ("bz2", bz2.BZ2Decompressor),
            ("lzma", lzma.LZMADecompressor),
        ]
        decode_errors: list[str] = []

        for codec_name, decompressor_factory in codec_attempts:
            try:
                return self._decompress_with_limited_output(decompressor_factory(), data)
            except (OSError, EOFError, lzma.LZMAError, zlib.error) as exc:
                decode_errors.append(f"{codec_name}: {exc}")

        raise ValueError(
            "Unable to decompress joblib file: " + "; ".join(decode_errors or ["no supported decoder matched"]),
        )

    def _scan_pickle_payload(self, payload: bytes, result: ScanResult, context: str) -> None:
        """Analyze a raw or decompressed pickle payload with CVE and opcode checks."""
        self._detect_cve_patterns(payload, result, context)
        self._scan_for_joblib_specific_threats(payload, result, context)

        if self.pickle_scanner is None:
            add_scanner_selection_skip_check(
                result,
                context,
                "pickle",
                self.scanner_selection,
                context="embedded joblib pickle analysis",
            )
            result.bytes_scanned = len(payload)
            return

        with io.BytesIO(payload) as file_like:
            sub_result = self.pickle_scanner.scan_stream(
                file_like,
                len(payload),
                source=context,
            )
        result.merge(sub_result)
        self._downgrade_embedded_pickle_parse_errors(result)
        self._mark_trusted_numpy_wrapper_tail(result, payload)
        result.bytes_scanned = len(payload)

    @staticmethod
    def _downgrade_embedded_pickle_parse_errors(result: ScanResult) -> None:
        for issue in result.issues:
            if issue.rule_code == "S901" and issue.details.get("category") == "parse_error":
                issue.severity = IssueSeverity.INFO
        for check in result.checks:
            if check.rule_code == "S901" and check.details.get("category") == "parse_error":
                check.severity = IssueSeverity.INFO

    @staticmethod
    def _mark_trusted_numpy_wrapper_tail(result: ScanResult, payload: bytes) -> None:
        if result.metadata.get("trusted_incomplete_tail") is True:
            return
        if result.metadata.get("scan_outcome") != INCONCLUSIVE_SCAN_OUTCOME:
            return
        if result.metadata.get("failure_reason") != "unknown_opcode_or_format_error":
            return
        if any(issue.severity in {IssueSeverity.WARNING, IssueSeverity.CRITICAL} for issue in result.issues):
            return
        if not _has_trusted_joblib_numpy_array_refs(result.metadata.get("import_references")):
            return

        tail_start = _parse_unknown_opcode_position(result)
        if tail_start is None or tail_start >= len(payload):
            return
        if not _looks_like_joblib_numpy_array_tail(payload[tail_start:]):
            return

        result.metadata["trusted_incomplete_tail"] = True
        result.metadata["trusted_incomplete_tail_reason"] = "joblib_numpy_array_payload"

    def _looks_like_raw_pickle_payload(self, data: bytes) -> bool:
        """Return True when `.joblib` bytes should be scanned directly as pickle."""
        if _looks_like_pickle(data):
            return True

        if len(data) >= 2 and data[0] == 0x80 and data[1] <= 5:
            return True

        try:
            probe = io.BytesIO(data[:4096])
            for _opcode_count, (opcode, _arg, _pos) in enumerate(pickletools.genops(probe), 1):
                if opcode.name == "STOP":
                    return True
                if _opcode_count >= 16:
                    break
        except Exception:
            return False

        return False

    def _record_joblib_operational_error(self, result: ScanResult, reason: str) -> None:
        """Mark a Joblib scan as operationally incomplete for CLI exit-code aggregation."""
        result.metadata["operational_error"] = True
        result.metadata["operational_error_reason"] = reason

    def _detect_cve_patterns(self, data: bytes, result: ScanResult, context: str) -> None:
        """Detect CVE-specific patterns in joblib file data."""
        # Convert bytes to string for pattern analysis (ignore decode errors)
        try:
            content_str = data.decode("utf-8", errors="ignore")
        except UnicodeDecodeError:
            content_str = ""

        # Analyze for CVE patterns
        cve_attributions = analyze_cve_patterns(content_str, data)

        if cve_attributions:
            # Add CVE information to result
            enhance_scan_result_with_cve(result, [content_str], data)

            # Add specific checks for each CVE found
            for attr in cve_attributions:
                severity = IssueSeverity.CRITICAL if attr.severity == "CRITICAL" else IssueSeverity.WARNING

                result.add_check(
                    name=f"CVE Detection: {attr.cve_id}",
                    passed=False,
                    message=f"Detected {attr.cve_id}: {attr.description}",
                    severity=severity,
                    location=f"{context}",
                    details={
                        "cve_id": attr.cve_id,
                        "cvss": attr.cvss,
                        "cwe": attr.cwe,
                        "affected_versions": attr.affected_versions,
                        "confidence": attr.confidence,
                        "patterns_matched": attr.patterns_matched,
                        "remediation": attr.remediation,
                    },
                    why=f"This file contains patterns associated with {attr.cve_id}, "
                    f"a {attr.severity.lower()} vulnerability affecting {attr.affected_versions}. "
                    f"Remediation: {attr.remediation}",
                )

    def _scan_for_joblib_specific_threats(self, data: bytes, result: ScanResult, context: str) -> None:
        """Scan for joblib-specific security threats beyond general pickle issues."""
        # CVE-2024-34997 specific detection
        numpy_wrapper_patterns = [
            b"NumpyArrayWrapper",
            b"read_array",
            b"numpy_pickle",
        ]

        found_numpy_patterns = []
        for pattern in numpy_wrapper_patterns:
            if pattern in data:
                found_numpy_patterns.append(pattern.decode("utf-8", errors="ignore"))

        if found_numpy_patterns and b"pickle.load" in data:
            result.add_check(
                name="CVE-2024-34997 Risk Detection",
                passed=False,
                message="Detected NumpyArrayWrapper with pickle.load - potential CVE-2024-34997 exploitation",
                severity=IssueSeverity.WARNING,
                location=context,
                details={
                    "cve": "CVE-2024-34997",
                    "patterns": found_numpy_patterns,
                    "risk": "NumpyArrayWrapper deserialization vulnerability",
                },
                why="NumpyArrayWrapper.read_array() combined with pickle.load() can be exploited "
                "for arbitrary code execution if the data source is untrusted.",
            )

        # Check for sklearn model loading patterns with dangerous operations
        if b"sklearn" in data and b"joblib.load" in data:
            dangerous_combos = [
                (b"os.system", "system command execution"),
                (b"subprocess", "process spawning"),
                (b"eval", "code evaluation"),
                (b"exec", "code execution"),
            ]

            for pattern, description in dangerous_combos:
                if pattern in data:
                    result.add_check(
                        name="CVE-2020-13092 Risk Detection",
                        passed=False,
                        message=f"Detected sklearn/joblib.load with {description} - "
                        f"potential CVE-2020-13092 exploitation",
                        severity=IssueSeverity.CRITICAL,
                        location=context,
                        details={
                            "cve": "CVE-2020-13092",
                            "sklearn_pattern": "sklearn + joblib.load",
                            "dangerous_pattern": pattern.decode("utf-8", errors="ignore"),
                            "risk": "scikit-learn deserialization vulnerability",
                        },
                        why=f"scikit-learn models loaded via joblib.load() with {description} "
                        f"can execute arbitrary code during deserialization.",
                    )

    def scan(self, path: str) -> ScanResult:
        """Scan one Joblib file as direct pickle, compressed pickle, or zip-backed content."""
        path_check_result = self._check_path(path)
        if path_check_result:
            return path_check_result

        size_check = self._check_size_limit(path)
        if size_check:
            return size_check

        result = self._create_result()
        file_size = self.get_file_size(path)
        result.metadata["file_size"] = file_size

        try:
            self.current_file_path = path
            magic = read_magic_bytes(path, 4)
            data = self._read_file_safely(path)

            if magic.startswith(b"PK"):
                # Treat as zip archive
                from .zip_scanner import ZipScanner

                zip_scanner = ZipScanner(self.config)
                sub_result = zip_scanner.scan(path)
                result.merge(sub_result)
                result.bytes_scanned = sub_result.bytes_scanned
                result.metadata.update(sub_result.metadata)
                result.finish(success=sub_result.success)
                return result

            if self._looks_like_raw_pickle_payload(data):
                self._scan_pickle_payload(data, result, path)
            else:
                # Try safe decompression
                try:
                    decompressed = self._safe_decompress(data)
                    # Record successful decompression check
                    compressed_size = len(data)
                    decompressed_size = len(decompressed)
                    if compressed_size > 0:
                        ratio = decompressed_size / compressed_size
                        result.add_check(
                            name="Compression Bomb Detection",
                            passed=True,
                            message=f"Compression ratio ({ratio:.1f}x) is within safe limits",
                            location=path,
                            details={
                                "compressed_size": compressed_size,
                                "decompressed_size": decompressed_size,
                                "ratio": ratio,
                                "max_ratio": self.max_decompression_ratio,
                            },
                            rule_code=None,  # Passing check
                        )
                except ValueError as e:
                    # Size/ratio limit errors are informational - may indicate large legitimate models
                    # Compression bombs are DoS concerns, not RCE vectors
                    result.add_check(
                        name="Compression Bomb Detection",
                        passed=False,
                        message=str(e),
                        severity=IssueSeverity.INFO,
                        location=path,
                        details={"security_check": "compression_bomb_detection"},
                        rule_code="S902",
                    )
                    self._record_joblib_operational_error(result, "joblib_wrapper_decode_failed")
                    result.finish(success=False)
                    return result
                except Exception as e:
                    result.add_check(
                        name="Joblib Decompression",
                        passed=False,
                        message=f"Error decompressing joblib file: {e}",
                        severity=IssueSeverity.CRITICAL,
                        location=path,
                        details={
                            "exception": str(e),
                            "exception_type": type(e).__name__,
                        },
                        rule_code="S902",
                    )
                    self._record_joblib_operational_error(result, "joblib_decompression_failed")
                    result.finish(success=False)
                    return result
                self._scan_pickle_payload(decompressed, result, f"{path} (decompressed)")
        except Exception as e:  # pragma: no cover
            result.add_check(
                name="Joblib File Scan",
                passed=False,
                message=f"Error scanning joblib file: {e}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={
                    "exception": str(e),
                    "exception_type": type(e).__name__,
                },
                rule_code="S902",
            )
            self._record_joblib_operational_error(result, "joblib_scan_failed")
            result.finish(success=False)
            return result

        has_security_findings = any(
            issue.severity in {IssueSeverity.WARNING, IssueSeverity.CRITICAL} for issue in result.issues
        )
        has_trusted_incomplete_tail = result.metadata.get("trusted_incomplete_tail") is True
        if (
            result.metadata.get("scan_outcome") == INCONCLUSIVE_SCAN_OUTCOME
            and not has_security_findings
            and not has_trusted_incomplete_tail
        ):
            result.finish(success=False)
        else:
            result.finish(success=not result.has_errors)
        return result

    def extract_metadata(self, file_path: str) -> dict[str, Any]:
        """Extract joblib metadata."""
        metadata = super().extract_metadata(file_path)

        allow_deserialization = bool(self.config.get("allow_metadata_deserialization"))

        if not allow_deserialization:
            metadata["deserialization_skipped"] = True
            metadata["reason"] = "Deserialization disabled for metadata extraction"
            return metadata

        try:
            import joblib

            # Try to load the joblib file
            obj = joblib.load(file_path)

            metadata.update(
                {
                    "joblib_version": joblib.__version__,
                    "object_type": type(obj).__name__,
                    "object_module": getattr(type(obj), "__module__", "unknown"),
                }
            )

            # Analyze sklearn models specifically
            if hasattr(obj, "_sklearn_version"):
                metadata["sklearn_version"] = str(obj._sklearn_version)

            if hasattr(obj, "get_params"):
                try:
                    try:
                        params = obj.get_params(deep=False)
                    except TypeError:
                        params = obj.get_params()
                    metadata.update(
                        {
                            "model_parameters": len(params),
                            "key_parameters": list(params.keys())[:10],  # First 10 parameters
                        }
                    )
                except Exception:
                    metadata["model_parameters_unavailable"] = True

            # Check for common sklearn model attributes
            if hasattr(obj, "n_features_in_"):
                metadata["n_features_in"] = obj.n_features_in_

            if hasattr(obj, "classes_"):
                metadata.update(
                    {
                        "n_classes": len(obj.classes_),
                        "classes": list(obj.classes_)[:10]
                        if len(obj.classes_) <= 10
                        else f"{len(obj.classes_)} classes",
                    }
                )

            if hasattr(obj, "feature_importances_"):
                metadata["has_feature_importances"] = True
                with suppress(Exception):
                    importances = obj.feature_importances_
                    metadata["feature_importance_stats"] = {
                        "min": float(min(importances)),
                        "max": float(max(importances)),
                        "mean": float(sum(importances) / len(importances)),
                    }
            else:
                metadata["has_feature_importances"] = False

            # Check for ensemble models
            if hasattr(obj, "estimators_"):
                metadata.update(
                    {
                        "is_ensemble": True,
                        "n_estimators": len(obj.estimators_),
                    }
                )
            else:
                metadata["is_ensemble"] = False

        except Exception as e:
            metadata["extraction_error"] = str(e)
            metadata["extraction_error_type"] = type(e).__name__

        return metadata
