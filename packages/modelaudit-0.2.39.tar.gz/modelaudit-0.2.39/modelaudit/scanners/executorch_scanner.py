"""Scanner for ExecuTorch model files (.pte)."""

import os
import tempfile
import zipfile
from typing import Any, BinaryIO, ClassVar, cast

from ..scanner_selection import add_scanner_selection_skip_check, embedded_pickle_scanner
from ..utils import sanitize_archive_path
from ..utils.file.detection import (
    _is_executorch_binary_signature,
    _is_valid_executorch_binary,
    is_executorch_archive,
)
from .base import BaseScanner, IssueSeverity, ScanResult
from .pickle_scanner import PickleScanner
from .picklescan_adapter import (
    apply_pickle_member_context,
)


class ExecuTorchScanner(BaseScanner):
    """Scanner for PyTorch Mobile/ExecuTorch archives (.ptl, .pte)."""

    name = "executorch"
    description = "Scans ExecuTorch mobile model files for suspicious content"
    supported_extensions: ClassVar[list[str]] = [".ptl", ".pte"]

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        super().__init__(config)
        self.pickle_scanner, self.scanner_selection = embedded_pickle_scanner(self.config, PickleScanner)

    @classmethod
    def can_handle(cls, path: str) -> bool:
        if not os.path.isfile(path):
            return False
        ext = os.path.splitext(path)[1].lower()
        if ext in cls.supported_extensions:
            return True
        return is_executorch_archive(path)

    @staticmethod
    def _read_header(path: str, length: int = 4) -> bytes:
        try:
            with open(path, "rb") as f:
                return f.read(length)
        except Exception:
            return b""

    def scan(self, path: str) -> ScanResult:
        path_check_result = self._check_path(path)
        if path_check_result:
            return path_check_result

        size_check = self._check_size_limit(path)
        if size_check:
            return size_check

        result = self._create_result()
        file_size = self.get_file_size(path)
        result.metadata["file_size"] = file_size

        header = self._read_header(path, length=8)
        valid_binary_program = _is_executorch_binary_signature(header) and _is_valid_executorch_binary(path)
        if valid_binary_program:
            result.add_check(
                name="ExecuTorch Binary Format Validation",
                passed=True,
                message="Valid ExecuTorch binary program format detected",
                location=path,
                details={"path": path, "format": "executorch_binary"},
            )

        should_scan_archive = header.startswith(b"PK")
        if valid_binary_program and not should_scan_archive:
            try:
                should_scan_archive = zipfile.is_zipfile(path)
            except OSError:
                should_scan_archive = False

        if valid_binary_program and not should_scan_archive:
            result.bytes_scanned = file_size
            result.finish(success=True)
            return result

        if not should_scan_archive:
            result.add_check(
                name="ExecuTorch Archive Format Validation",
                passed=False,
                message=f"Not a valid ExecuTorch archive: {path}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={"path": path},
                rule_code="S104",
            )
            result.finish(success=False)
            return result

        try:
            self.current_file_path = path
            with zipfile.ZipFile(path, "r") as z:
                safe_entries: list[str] = []
                for name in z.namelist():
                    temp_base = os.path.join(tempfile.gettempdir(), "extract")
                    _, is_safe = sanitize_archive_path(name, temp_base)
                    if not is_safe:
                        result.add_check(
                            name="Path Traversal Protection",
                            passed=False,
                            message=f"Archive entry {name} attempted path traversal outside the archive",
                            severity=IssueSeverity.CRITICAL,
                            location=f"{path}:{name}",
                            details={"entry": name},
                            rule_code="S405",
                        )
                        continue
                    safe_entries.append(name)

                pickle_files = [n for n in safe_entries if n.endswith(".pkl")]
                result.metadata["pickle_files"] = pickle_files
                bytes_scanned = 0

                for name in pickle_files:
                    member_info = z.getinfo(name)
                    bytes_scanned += member_info.file_size
                    if self.pickle_scanner is None:
                        add_scanner_selection_skip_check(
                            result,
                            f"{path}:{name}",
                            "pickle",
                            self.scanner_selection,
                            context="embedded ExecuTorch pickle analysis",
                        )
                        continue

                    with z.open(name, "r") as file_like:
                        sub_result = self.pickle_scanner.scan_stream(
                            cast(BinaryIO, file_like),
                            member_info.file_size,
                            source=f"{path}:{name}",
                        )
                    apply_pickle_member_context(sub_result, archive_path=path, member_name=name)
                    result.merge(sub_result)

                for name in safe_entries:
                    if name.endswith(".py"):
                        result.add_check(
                            name="Python File Detection",
                            passed=False,
                            message=f"Python code file found in ExecuTorch model: {name}",
                            severity=IssueSeverity.INFO,
                            location=f"{path}:{name}",
                            details={"file": name},
                            rule_code="S507",  # Python embedded code
                        )
                        result.add_check(
                            name="Executable File Detection",
                            passed=False,
                            message=f"Executable file found in ExecuTorch model: {name}",
                            severity=IssueSeverity.CRITICAL,
                            location=f"{path}:{name}",
                            details={"file": name},
                            rule_code="S104",
                        )

                result.bytes_scanned = bytes_scanned
        except zipfile.BadZipFile:
            result.add_check(
                name="ZIP File Format Validation",
                passed=False,
                message=f"Not a valid zip file: {path}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={"path": path},
                rule_code="S902",
            )
            result.finish(success=False)
            return result
        except Exception as e:  # pragma: no cover - unexpected errors
            result.add_check(
                name="ExecuTorch File Scan",
                passed=False,
                message=f"Error scanning ExecuTorch file: {e!s}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={
                    "exception": str(e),
                    "exception_type": type(e).__name__,
                },
                rule_code="S902",
            )
            result.finish(success=False)
            return result

        result.finish(success=True)
        return result
