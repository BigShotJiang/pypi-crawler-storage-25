"""Scanner for OCI container image layers containing model artifacts."""

import json
import os
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Any, ClassVar
from urllib.parse import urlparse

from ..utils import is_within_directory, sanitize_archive_path
from ..utils.file.detection import (
    MARKED_PROTOCOL0_GLOBAL_RE,
    PROTOCOL0_GLOBAL_RE,
    detect_file_format,
)
from ..utils.model_extensions import get_model_extensions
from ._archive_locations import rewrite_extracted_member_location
from .base import BaseScanner, IssueSeverity, ScanResult

# Try to import yaml for YAML manifests
try:
    import yaml

    HAS_YAML = True
except Exception:
    HAS_YAML = False


class OciLayerScanner(BaseScanner):
    """Scanner for OCI/Artifactory manifest files with .tar.gz layers."""

    name = "oci_layer"
    description = "Scans container manifests and embedded layers for model files"
    supported_extensions: ClassVar[list[str]] = [".manifest"]
    _DETECTED_FORMAT_SUFFIXES: ClassVar[dict[str, str]] = {
        "pickle": ".pkl",
        "onnx": ".onnx",
        "hdf5": ".h5",
        "safetensors": ".safetensors",
        "numpy": ".npy",
        "protobuf": ".pb",
        "zip": ".zip",
        "gguf": ".gguf",
        "ggml": ".gguf",
    }
    _LAYER_ARCHIVE_SUFFIX: ClassVar[str] = ".tar.gz"
    _MANIFEST_PROBE_CHUNK_BYTES: ClassVar[int] = 8192
    _MEMBER_HEADER_PROBE_BYTES: ClassVar[int] = 64
    _DEFAULT_MAX_LAYER_FILE_SIZE: ClassVar[int] = 10 * 1024 * 1024 * 1024
    _REMOTE_LAYER_REF_SCHEMES: ClassVar[frozenset[str]] = frozenset({"http", "https", "s3", "gs", "oci"})

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        configured_max_file_size = self.config.get("max_file_size")
        if configured_max_file_size == 0:
            self.max_layer_file_size = 0
        else:
            self.max_layer_file_size = self._normalize_positive_int_config(
                configured_max_file_size,
                self._DEFAULT_MAX_LAYER_FILE_SIZE,
            )

    @staticmethod
    def _get_scannable_extension(member_name: str) -> str | None:
        suffixes = [suffix.lower() for suffix in Path(member_name.rstrip(" .")).suffixes]
        if not suffixes:
            return None

        scannable_extensions = get_model_extensions()
        best_candidate: tuple[int, int, str] | None = None

        for start in range(len(suffixes)):
            for end in range(len(suffixes), start, -1):
                candidate = "".join(suffixes[start:end])
                if candidate not in scannable_extensions:
                    continue
                candidate_width = end - start
                if (
                    best_candidate is None
                    or candidate_width > best_candidate[0]
                    or (candidate_width == best_candidate[0] and start < best_candidate[1])
                ):
                    best_candidate = (candidate_width, start, candidate)

        return best_candidate[2] if best_candidate is not None else None

    @classmethod
    def can_handle(cls, path: str) -> bool:
        if not os.path.isfile(path):
            return False
        ext = os.path.splitext(path)[1].lower()
        if ext not in cls.supported_extensions:
            return False

        # Check for .tar.gz references case-insensitively without reading the
        # whole file into memory at once.
        try:
            probe_tail = ""
            with open(path, encoding="utf-8", errors="ignore") as f:
                while chunk := f.read(cls._MANIFEST_PROBE_CHUNK_BYTES):
                    haystack = f"{probe_tail}{chunk}".lower()
                    if cls._LAYER_ARCHIVE_SUFFIX in haystack:
                        return True
                    probe_tail = haystack[-(len(cls._LAYER_ARCHIVE_SUFFIX) - 1) :]
            return False
        except Exception:
            return False

    @staticmethod
    def _normalize_layer_ref(layer_ref: str) -> str:
        """Trim manifest layer refs so cosmetic suffix whitespace cannot hide .tar.gz layers."""
        return layer_ref.strip().rstrip(" .")

    @staticmethod
    def _is_remote_layer_ref(layer_ref: str) -> bool:
        """Return True when a layer reference points to a remote URL-like location."""
        parsed = urlparse(layer_ref.strip())
        return parsed.scheme.lower() in OciLayerScanner._REMOTE_LAYER_REF_SCHEMES and bool(parsed.netloc)

    @classmethod
    def _collect_layer_paths(cls, manifest_data: Any) -> list[str]:
        """Collect layer refs from manifest layer fields without treating arbitrary strings as layers."""
        layer_paths: list[str] = []

        def _append_layer_ref(value: Any) -> None:
            if isinstance(value, str) and cls._normalize_layer_ref(value).lower().endswith(cls._LAYER_ARCHIVE_SUFFIX):
                layer_paths.append(value)

        def _collect_layer_value(value: Any) -> None:
            if isinstance(value, str):
                _append_layer_ref(value)
            elif isinstance(value, list):
                for item in value:
                    _collect_layer_value(item)
            elif isinstance(value, dict):
                for key, item in value.items():
                    if str(key).lower() in {"layers", "urls"}:
                        _collect_layer_value(item)

        def _walk_manifest(obj: Any) -> None:
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if str(key).lower() == "layers":
                        _collect_layer_value(value)
                    elif isinstance(value, (dict, list)):
                        _walk_manifest(value)
            elif isinstance(obj, list):
                for item in obj:
                    _walk_manifest(item)

        _walk_manifest(manifest_data)
        return layer_paths

    @staticmethod
    def _rewrite_embedded_location(
        location: str | None,
        *,
        manifest_path: str,
        layer_ref: str,
        member_name: str,
        extracted_path: str,
    ) -> str:
        """Replace temporary extraction paths with the original OCI member location."""
        member_location = f"{manifest_path}:{layer_ref}:{member_name}"
        return rewrite_extracted_member_location(
            location,
            extracted_path,
            member_location,
            preserve_non_delimited_suffix=True,
        )

    @classmethod
    def _get_detected_format_suffix(cls, extracted_path: str) -> str | None:
        """Return a canonical suffix for detected content-based formats."""
        detected_format = detect_file_format(extracted_path)
        return cls._DETECTED_FORMAT_SUFFIXES.get(detected_format)

    @staticmethod
    def _looks_like_model_member_prefix(data: bytes) -> bool:
        """Return True when an extensionless or misnamed member has model-like magic bytes."""
        if len(data) >= 8 and data[4:8] == b"TFL3":
            return True
        if data.startswith(
            (
                b"\x80\x02",
                b"\x80\x03",
                b"\x80\x04",
                b"\x80\x05",
                b"\x89HDF\r\n\x1a\n",
                b"\x93NUMPY",
                b"GGUF",
                b"GGML",
                b"GGMF",
                b"GGJT",
                b"GGLA",
                b"GGSA",
                b"PK\x03\x04",
                b"PK\x05\x06",
                b"PK\x07\x08",
                b"\x08\x01\x12\x00",
                b"ONNX",
                b"onnx",
                b"<?xml",
            )
        ):
            return True
        if PROTOCOL0_GLOBAL_RE.match(data) or MARKED_PROTOCOL0_GLOBAL_RE.match(data):
            return True

        for offset in range(1, len(data)):
            shifted_prefix = data[offset:]
            if shifted_prefix.startswith(
                (
                    b"\x80\x02",
                    b"\x80\x03",
                    b"\x80\x04",
                    b"\x80\x05",
                    b"\x89HDF\r\n\x1a\n",
                    b"\x93NUMPY",
                    b"GGUF",
                    b"GGML",
                    b"GGMF",
                    b"GGJT",
                    b"GGLA",
                    b"GGSA",
                    b"PK\x03\x04",
                    b"PK\x05\x06",
                    b"PK\x07\x08",
                    b"\x08\x01\x12\x00",
                    b"ONNX",
                    b"onnx",
                    b"<?xml",
                )
            ):
                return True
            if PROTOCOL0_GLOBAL_RE.match(shifted_prefix) or MARKED_PROTOCOL0_GLOBAL_RE.match(shifted_prefix):
                return True

        return False

    def scan(self, path: str) -> ScanResult:
        path_check = self._check_path(path)
        if path_check:
            return path_check

        size_check = self._check_size_limit(path)
        if size_check:
            return size_check

        result = self._create_result()
        manifest_data: Any = None

        try:
            with open(path, encoding="utf-8", errors="ignore") as f:
                text = f.read()
            try:
                manifest_data = json.loads(text)
            except Exception:
                if HAS_YAML:
                    manifest_data = yaml.safe_load(text)
                else:
                    raise
        except Exception as e:
            result.add_check(
                name="OCI Manifest Parse",
                passed=False,
                message=f"Error parsing manifest: {e}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={"exception_type": type(e).__name__},
                rule_code="S902",
            )
            result.finish(success=False)
            return result

        layer_paths = self._collect_layer_paths(manifest_data)

        manifest_dir = os.path.dirname(path)
        scan_complete = True

        for layer_ref in layer_paths:
            normalized_layer_ref = self._normalize_layer_ref(layer_ref)
            layer_path, is_safe = sanitize_archive_path(layer_ref, manifest_dir)

            if not is_safe or not is_within_directory(manifest_dir, layer_path):
                scan_complete = False
                result.add_check(
                    name="Layer Path Traversal Protection",
                    passed=False,
                    message=f"Layer reference {layer_ref} attempted path traversal outside manifest directory",
                    severity=IssueSeverity.CRITICAL,
                    location=f"{path}:{layer_ref}",
                    details={"layer": layer_ref, "resolved_path": layer_path},
                    rule_code="S405",
                )
                continue

            if not os.path.exists(layer_path):
                if self._is_remote_layer_ref(layer_ref):
                    scan_complete = False
                    result.add_check(
                        name="Remote Layer Resolution Check",
                        passed=False,
                        message=f"Remote layer was not scanned because it is not available locally: {layer_ref}",
                        severity=IssueSeverity.WARNING,
                        location=f"{path}:{layer_ref}",
                        details={
                            "layer": layer_ref,
                            "resolved_path": layer_path,
                        },
                        rule_code="S902",
                    )
                    continue
                scan_complete = False
                result.add_check(
                    name="Layer File Existence Check",
                    passed=False,
                    message=f"Layer not found: {layer_ref}",
                    severity=IssueSeverity.WARNING,
                    location=f"{path}:{layer_ref}",
                    rule_code="S902",
                )
                continue
            try:
                layer_size = os.path.getsize(layer_path)
                if self.max_layer_file_size > 0 and layer_size > self.max_layer_file_size:
                    scan_complete = False
                    result.add_check(
                        name="Layer File Size Check",
                        passed=False,
                        message=(
                            f"Layer {normalized_layer_ref} is too large to scan: "
                            f"{layer_size} bytes (max: {self.max_layer_file_size})"
                        ),
                        severity=IssueSeverity.WARNING,
                        location=f"{path}:{layer_ref}",
                        details={
                            "layer": layer_ref,
                            "normalized_layer": normalized_layer_ref,
                            "size": layer_size,
                            "max_file_size": self.max_layer_file_size,
                        },
                        rule_code="S902",
                    )
                    continue

                with tarfile.open(layer_path, "r:gz") as tar:
                    for member in tar:
                        if not member.isfile():
                            continue
                        name = member.name
                        matched_ext = self._get_scannable_extension(name)
                        if self.max_layer_file_size > 0 and member.size > self.max_layer_file_size:
                            scan_complete = False
                            result.add_check(
                                name="Layer Member Size Check",
                                passed=False,
                                message=(
                                    f"Layer member {name} is too large to scan: "
                                    f"{member.size} bytes (max: {self.max_layer_file_size})"
                                ),
                                severity=IssueSeverity.WARNING,
                                location=f"{path}:{layer_ref}:{name}",
                                details={
                                    "layer": layer_ref,
                                    "member": name,
                                    "size": member.size,
                                    "max_file_size": self.max_layer_file_size,
                                },
                                rule_code="S902",
                            )
                            continue

                        fileobj = tar.extractfile(member)
                        if fileobj is None:
                            scan_complete = False
                            result.add_check(
                                name="Layer Member Extraction",
                                passed=False,
                                message=f"Layer member {name} was not extracted from {layer_ref}",
                                severity=IssueSeverity.WARNING,
                                location=f"{path}:{layer_ref}:{name}",
                                details={"layer": layer_ref, "member": name},
                                rule_code="S902",
                            )
                            continue
                        header_prefix = b""
                        tmp_path: str | None = None
                        try:
                            if matched_ext is None:
                                header_prefix = fileobj.read(self._MEMBER_HEADER_PROBE_BYTES)

                            with tempfile.NamedTemporaryFile(
                                suffix=matched_ext or "",
                                delete=False,
                            ) as tmp:
                                tmp_path = tmp.name
                                if header_prefix:
                                    tmp.write(header_prefix)
                                shutil.copyfileobj(fileobj, tmp)

                            from .. import core

                            nested_config = dict(self.config)
                            try:
                                _oci_depth = int(nested_config.get("_archive_depth", 0))
                            except (TypeError, ValueError):
                                _oci_depth = 0
                            nested_config["_archive_depth"] = max(_oci_depth, 0) + 1

                            file_result = core.scan_file(tmp_path, nested_config)
                            detected_suffix = self._get_detected_format_suffix(tmp_path)
                            if (
                                file_result.scanner_name == "unknown"
                                and detected_suffix
                                and not tmp_path.endswith(detected_suffix)
                            ):
                                retargeted_path = f"{tmp_path}{detected_suffix}"
                                os.replace(tmp_path, retargeted_path)
                                tmp_path = retargeted_path
                                file_result = core.scan_file(tmp_path, nested_config)
                            for check in file_result.checks:
                                check.location = self._rewrite_embedded_location(
                                    check.location,
                                    manifest_path=path,
                                    layer_ref=layer_ref,
                                    member_name=name,
                                    extracted_path=tmp_path,
                                )
                            for issue in file_result.issues:
                                issue.location = self._rewrite_embedded_location(
                                    issue.location,
                                    manifest_path=path,
                                    layer_ref=layer_ref,
                                    member_name=name,
                                    extracted_path=tmp_path,
                                )
                                if issue.details is None:
                                    issue.details = {}
                                issue.details["layer"] = layer_ref
                            result.merge(file_result)
                            if not file_result.success or file_result.has_errors:
                                scan_complete = False
                        finally:
                            fileobj.close()
                            if tmp_path and os.path.exists(tmp_path):
                                os.unlink(tmp_path)
            except Exception as e:
                scan_complete = False
                result.add_check(
                    name="Layer Processing",
                    passed=False,
                    message=f"Error processing layer {layer_ref}: {e}",
                    severity=IssueSeverity.WARNING,
                    location=f"{path}:{layer_ref}",
                    details={"exception_type": type(e).__name__},
                    rule_code="S902",
                )

        result.finish(success=scan_complete and not result.has_errors)
        return result
