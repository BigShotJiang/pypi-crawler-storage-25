"""GGUF/GGML scanner that combines comprehensive parsing with security checks."""

from __future__ import annotations

import os
import struct
from typing import Any, BinaryIO, ClassVar

from .base import INCONCLUSIVE_SCAN_OUTCOME, BaseScanner, IssueSeverity, ScanResult

# Map ggml_type enum to (block_size, type_size) for comprehensive validation
# Values derived from ggml source
_GGML_TYPE_INFO = {
    0: (1, 4),  # F32
    1: (1, 2),  # F16
    2: (32, 18),  # Q4_0
    3: (32, 20),  # Q4_1
    6: (32, 22),  # Q5_0
    7: (32, 24),  # Q5_1
    8: (32, 34),  # Q8_0
    9: (32, 36),  # Q8_1
    10: (256, 84),  # Q2_K
    11: (256, 110),  # Q3_K
    12: (256, 144),  # Q4_K
    13: (256, 176),  # Q5_K
    14: (256, 210),  # Q6_K
    15: (256, 292),  # Q8_K
}
_UINT64_MAX: int = 2**64 - 1

# Accepted GGML variant magic bytes
GGML_VARIANT_MAGICS = {
    b"GGML",
    b"GGMF",
    b"GGJT",
    b"GGLA",
    b"GGSA",
}
GGUF_PARSE_INCONCLUSIVE_REASON = "gguf_parse_incomplete"
GGUF_STRUCTURE_INCONCLUSIVE_REASON = "gguf_structure_validation_failed"


class GgufScanner(BaseScanner):
    """Scanner for GGUF/GGML model files with comprehensive parsing and security checks."""

    name = "gguf"
    description = "Validates GGUF/GGML model file headers, metadata, and tensor integrity"
    default_max_file_read_size: ClassVar[int] = 0
    # Include common GGML variant extensions as well
    supported_extensions: ClassVar[list[str]] = [
        ".gguf",
        ".ggml",
        ".ggmf",
        ".ggjt",
        ".ggla",
        ".ggsa",
    ]

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        self.max_uncompressed = self.config.get(
            "max_uncompressed",
            100 * 1024 * 1024 * 1024,
        )  # 100GB for large GGUF models

    @staticmethod
    def _mark_inconclusive(result: ScanResult, reason: str) -> None:
        """Mark malformed GGUF/GGML framing as an explicit inconclusive scan."""
        result.metadata["analysis_incomplete"] = True
        result.metadata["scan_outcome"] = INCONCLUSIVE_SCAN_OUTCOME

        reasons = result.metadata.get("scan_outcome_reasons")
        if not isinstance(reasons, list):
            reasons = []
            result.metadata["scan_outcome_reasons"] = reasons
        if reason not in reasons:
            reasons.append(reason)

    @staticmethod
    def _has_security_findings(result: ScanResult) -> bool:
        """Return True when GGUF scanning found WARNING/CRITICAL security findings."""
        return any(issue.severity in {IssueSeverity.WARNING, IssueSeverity.CRITICAL} for issue in result.issues)

    def _finish_result(self, result: ScanResult) -> None:
        """Finalize success so inconclusive/no-finding scans fail closed."""
        if result.metadata.get("scan_outcome") == INCONCLUSIVE_SCAN_OUTCOME and not self._has_security_findings(result):
            result.finish(success=False)
            return

        result.finish(success=not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues))

    @classmethod
    def can_handle(cls, path: str) -> bool:
        if not os.path.isfile(path):
            return False

        ext = os.path.splitext(path)[1].lower()
        if ext not in cls.supported_extensions:
            return False

        try:
            with open(path, "rb") as f:
                magic = f.read(4)
            return magic == b"GGUF" or magic in GGML_VARIANT_MAGICS
        except Exception:
            return False

    def scan(self, path: str) -> ScanResult:
        path_check_result = self._check_path(path)
        if path_check_result:
            return path_check_result

        size_check = self._check_size_limit(path)
        if size_check:
            return size_check

        result = self._create_result()
        file_size = self.get_file_size(path)
        result.metadata["file_size"] = file_size

        # Add file integrity check for compliance
        self.add_file_integrity_check(path, result)

        try:
            self.current_file_path = path
            with open(path, "rb") as f:
                magic = f.read(4)
                if magic == b"GGUF":
                    self._scan_gguf(f, file_size, result)
                elif magic in GGML_VARIANT_MAGICS:
                    self._scan_ggml(f, file_size, magic, result)
                else:
                    result.add_check(
                        name="File Format Recognition",
                        passed=False,
                        message=f"Unrecognized file format: {magic!r}",
                        severity=IssueSeverity.INFO,
                        location=path,
                        details={"magic_bytes": magic.hex()},
                        rule_code="S903",
                    )
                    self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
                    result.finish(success=False)
                    return result
        except Exception as e:
            result.add_check(
                name="GGUF/GGML File Scan",
                passed=False,
                message=f"Error scanning GGUF/GGML file: {e!s}",
                severity=IssueSeverity.INFO,
                location=path,
                details={"exception": str(e), "exception_type": type(e).__name__},
                rule_code="S1005",  # Invalid signature/corrupted file
            )
            self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
            result.finish(success=False)
            return result

        self._finish_result(result)
        return result

    def _read_string(self, f: BinaryIO, max_length: int = 1024 * 1024) -> str:
        """Read a string with length checking for security.

        Args:
            f: Binary file to read from
            max_length: Maximum allowed string length (default 1MB)

        Returns:
            Decoded UTF-8 string

        Raises:
            ValueError: String length exceeds limit, unexpected EOF, or other parsing error
        """
        (length,) = struct.unpack("<Q", f.read(8))
        if length > max_length:
            raise ValueError(f"String length {length} exceeds maximum {max_length}")
        data = f.read(length)
        if len(data) != length:
            raise ValueError("Unexpected end of file while reading string")
        return data.decode("utf-8", "ignore")

    def _scan_gguf(self, f: BinaryIO, file_size: int, result: ScanResult) -> None:
        """Comprehensive GGUF file scanning with security checks."""
        if file_size < 24:
            result.add_check(
                name="GGUF File Size Validation",
                passed=False,
                message="File too small to contain GGUF metadata",
                severity=IssueSeverity.INFO,
                location=self.current_file_path,
                details={"file_size": file_size, "min_required": 24},
                rule_code="S902",
            )
            self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
            return

        # Read header
        version = struct.unpack("<I", f.read(4))[0]
        n_tensors = struct.unpack("<Q", f.read(8))[0]
        n_kv = struct.unpack("<Q", f.read(8))[0]

        result.metadata.update(
            {
                "format": "gguf",
                "version": version,
                "n_tensors": n_tensors,
                "n_kv": n_kv,
            },
        )

        # Parse metadata with security checks
        metadata: dict[str, Any] = {}
        try:
            for _i in range(n_kv):
                key = self._read_string(f)

                # Security check for suspicious keys
                if any(x in key for x in ("../", "..\\", "/", "\\")):
                    result.add_check(
                        name="Metadata Key Security Check",
                        passed=False,
                        message=f"Suspicious metadata key with path traversal: {key}",
                        severity=IssueSeverity.WARNING,
                        location=self.current_file_path,
                        details={"suspicious_key": key},
                        rule_code="S405",
                    )

                (value_type,) = struct.unpack("<I", f.read(4))
                value = self._read_value(f, value_type)
                metadata[key] = value

                # Security check for suspicious values
                if isinstance(value, str) and any(p in value for p in ("/", "\\", ";", "&&", "|", "`")):
                    result.add_check(
                        name="Metadata Value Security Check",
                        passed=False,
                        message=f"Suspicious metadata value for key '{key}': {value}",
                        severity=IssueSeverity.INFO,
                        location=self.current_file_path,
                        details={"key": key, "value": str(value)[:200]},
                        rule_code="S902",
                    )

            result.metadata["metadata"] = metadata
        except Exception as e:
            # Parsing errors are informational - indicate corruption/format issues, not security threats
            result.add_check(
                name="GGUF Metadata Parsing",
                passed=False,
                message=f"GGUF metadata parse error: {e}",
                severity=IssueSeverity.INFO,
                location=self.current_file_path,
                details={"error": str(e), "error_type": type(e).__name__},
                rule_code="S902",
            )
            self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
            return

        # Align to tensor data
        # Note: general.alignment may be absent in files created by some tools (e.g., llama.cpp).
        # Only apply alignment if explicitly specified in metadata.
        metadata_end = f.tell()
        tensor_data_alignment = 32
        alignment = metadata.get("general.alignment")

        if alignment is not None:
            # Accept only positive power-of-two integers
            if (
                isinstance(alignment, int)
                and not isinstance(alignment, bool)
                and alignment > 0
                and (alignment & (alignment - 1)) == 0
            ):
                # Explicit alignment specified - apply it
                tensor_data_alignment = alignment
                pad = (alignment - (metadata_end % alignment)) % alignment
                if pad:
                    f.seek(pad, os.SEEK_CUR)
            else:
                result.add_check(
                    name="GGUF Alignment Validation",
                    passed=False,
                    message=f"Invalid alignment value: {alignment}",
                    severity=IssueSeverity.WARNING,
                    location=self.current_file_path,
                    details={"alignment": alignment, "requirement": "power-of-two positive integer"},
                    rule_code="S902",
                )

        # Parse tensor information
        tensors = []
        try:
            for _i in range(n_tensors):
                t_name = self._read_string(f)
                (nd,) = struct.unpack("<I", f.read(4))

                # Hard limit on dimensions to prevent DoS attacks
                if nd > 1000:
                    result.add_check(
                        name="Tensor Dimension Validation",
                        passed=False,
                        message=f"Tensor {t_name} has excessive dimensions ({nd}), skipping for security",
                        rule_code="S804",
                        severity=IssueSeverity.CRITICAL,
                        location=self.current_file_path,
                        details={"tensor_name": t_name, "dimensions": nd, "max_allowed": 1000},
                    )
                    # Skip the rest of this tensor's data to prevent DoS
                    f.seek(nd * 8 + 4 + 8, os.SEEK_CUR)  # Skip dims + type + offset
                    continue

                if nd > 8:
                    result.add_check(
                        name="Tensor Dimension Count Check",
                        passed=False,
                        message=f"Tensor {t_name} has suspicious number of dimensions: {nd}",
                        severity=IssueSeverity.WARNING,
                        location=self.current_file_path,
                        details={"tensor_name": t_name, "dimensions": nd, "max_normal": 8},
                        rule_code="S804",
                    )

                dims = [struct.unpack("<Q", f.read(8))[0] for _ in range(nd)]
                (t_type,) = struct.unpack("<I", f.read(4))
                (offset,) = struct.unpack("<Q", f.read(8))

                tensors.append(
                    {
                        "name": t_name,
                        "dims": dims,
                        "type": t_type,
                        "offset": offset,
                    },
                )

            result.metadata["tensors"] = [{"name": t["name"], "type": t["type"], "dims": t["dims"]} for t in tensors]
        except Exception as e:
            # Parsing errors are informational - indicate corruption/format issues, not security threats
            result.add_check(
                name="GGUF Tensor Parsing",
                passed=False,
                message=f"GGUF tensor parse error: {e}",
                severity=IssueSeverity.INFO,
                location=self.current_file_path,
                details={"error": str(e), "error_type": type(e).__name__},
                rule_code="S902",
            )
            self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
            return

        # Calculate tensor data section start (offsets in tensor info are relative to this)
        # According to GGUF spec, tensor data is aligned after tensor info section
        tensor_info_end = f.tell()
        # Use default 32-byte alignment if not specified (GGUF spec default)
        pad_to_tensor_data = (tensor_data_alignment - (tensor_info_end % tensor_data_alignment)) % tensor_data_alignment
        tensor_data_start = tensor_info_end + pad_to_tensor_data
        # Only check bounds if there are tensors (empty models don't have tensor data)
        if n_tensors > 0 and tensor_data_start > file_size:
            result.add_check(
                name="Tensor Data Section Bounds",
                passed=False,
                message="Tensor data start exceeds file size",
                severity=IssueSeverity.INFO,
                location=self.current_file_path,
                details={"tensor_data_start": tensor_data_start, "file_size": file_size},
            )
            self._mark_inconclusive(result, GGUF_STRUCTURE_INCONCLUSIVE_REASON)
            return

        # Validate tensor sizes and offsets
        for idx, tensor in enumerate(tensors):
            try:
                nelements = 1
                has_invalid_dimension = False
                for d in tensor["dims"]:
                    if d <= 0 or d > 2**31:
                        result.add_check(
                            name="Tensor Dimension Value Validation",
                            passed=False,
                            message=f"Tensor {tensor['name']} has invalid dimension: {d}",
                            severity=IssueSeverity.INFO,
                            location=self.current_file_path,
                            details={"tensor_name": tensor["name"], "invalid_dimension": d},
                            rule_code="S902",
                        )
                        self._mark_inconclusive(result, GGUF_STRUCTURE_INCONCLUSIVE_REASON)
                        has_invalid_dimension = True
                        break
                    nelements *= d

                # Skip tensor validation if any dimension is invalid
                if has_invalid_dimension:
                    continue

                # Check for extremely large tensors using correct size calculation
                # For quantized types, use the actual type information
                info = _GGML_TYPE_INFO.get(tensor["type"])
                if info is None:
                    result.add_check(
                        name="Tensor Type Validation",
                        passed=False,
                        message=f"Tensor {tensor['name']} uses unknown GGML type {tensor['type']}",
                        severity=IssueSeverity.INFO,
                        location=self.current_file_path,
                        details={"tensor_name": tensor["name"], "tensor_type": tensor["type"]},
                        rule_code="S902",
                    )
                    self._mark_inconclusive(result, GGUF_STRUCTURE_INCONCLUSIVE_REASON)
                    continue

                # For quantized types, calculate based on block and type size
                blck, ts = info
                estimated_size = ((nelements + blck - 1) // blck) * ts

                if estimated_size > self.max_uncompressed:
                    result.add_check(
                        name="Tensor Size Limit Check",
                        passed=False,
                        message=f"Tensor {tensor['name']} estimated size ({estimated_size}) exceeds limit",
                        rule_code="S902",
                        severity=IssueSeverity.CRITICAL,
                        location=self.current_file_path,
                        details={
                            "tensor_name": tensor["name"],
                            "estimated_size": estimated_size,
                            "limit": self.max_uncompressed,
                        },
                    )

                # Validate tensor type and size.
                # Note: tensor offsets are relative to tensor_data_start, not file start.
                if nelements % blck != 0:
                    result.add_check(
                        name="Tensor Block Alignment Check",
                        passed=False,
                        message=f"Tensor {tensor['name']} not aligned to block size {blck}",
                        severity=IssueSeverity.WARNING,
                        location=self.current_file_path,
                        details={"tensor_name": tensor["name"], "block_size": blck, "elements": nelements},
                        rule_code="S804",
                    )

                expected = ((nelements + blck - 1) // blck) * ts
                tensor_abs_start = tensor_data_start + tensor["offset"]
                tensor_abs_end = tensor_abs_start + expected
                offset_overflows_uint64 = tensor["offset"] > _UINT64_MAX - tensor_data_start
                end_overflows_uint64 = tensor_abs_start > _UINT64_MAX - expected

                if (
                    offset_overflows_uint64
                    or end_overflows_uint64
                    or tensor_abs_start > file_size
                    or tensor_abs_end > file_size
                ):
                    result.add_check(
                        name="Tensor Data Bounds Check",
                        passed=False,
                        message=f"Tensor {tensor['name']} data extends outside file bounds",
                        severity=IssueSeverity.WARNING,
                        location=self.current_file_path,
                        details={
                            "tensor_name": tensor["name"],
                            "offset": tensor["offset"],
                            "expected": expected,
                            "tensor_data_start": tensor_data_start,
                            "tensor_abs_start": tensor_abs_start,
                            "tensor_abs_end": tensor_abs_end,
                            "file_size": file_size,
                            "offset_overflows_uint64": offset_overflows_uint64,
                            "end_overflows_uint64": end_overflows_uint64,
                        },
                        rule_code="S902",
                    )
                    continue

                # Calculate actual size: use next tensor's offset, or file size for last tensor
                if idx + 1 < len(tensors):
                    next_offset = tensors[idx + 1]["offset"]
                    if next_offset < tensor["offset"]:
                        result.add_check(
                            name="Tensor Offset Order Validation",
                            passed=False,
                            message=f"Non-monotonic offsets for tensor {tensor['name']}",
                            severity=IssueSeverity.WARNING,
                            location=self.current_file_path,
                            details={"current_offset": tensor["offset"], "next_offset": next_offset},
                        )
                        continue
                    actual = next_offset - tensor["offset"]
                else:
                    # Last tensor: calculate from absolute position to end of file
                    actual = file_size - tensor_abs_start

                # Allow for alignment padding (tensors may be aligned to 32 bytes)
                # Only flag if difference is more than alignment padding
                if abs(expected - actual) > tensor_data_alignment:
                    result.add_check(
                        name="Tensor Size Consistency Check",
                        passed=False,
                        message=f"Size mismatch for tensor {tensor['name']}",
                        severity=IssueSeverity.WARNING,
                        location=self.current_file_path,
                        details={
                            "tensor_name": tensor["name"],
                            "expected": expected,
                            "actual": actual,
                            "alignment_tolerance": tensor_data_alignment,
                        },
                        rule_code="S902",
                    )
            except (OverflowError, ValueError) as e:
                result.add_check(
                    name="Tensor Validation Error",
                    passed=False,
                    message=f"Error validating tensor {tensor['name']}: {e}",
                    severity=IssueSeverity.INFO,
                    location=self.current_file_path,
                    details={"tensor_name": tensor["name"], "error": str(e)},
                    rule_code="S804",
                )
                self._mark_inconclusive(result, GGUF_STRUCTURE_INCONCLUSIVE_REASON)

        result.bytes_scanned = f.tell()

    def _scan_ggml(
        self,
        f: BinaryIO,
        file_size: int,
        magic: bytes,
        result: ScanResult,
    ) -> None:
        """Basic GGML file validation with security checks."""
        result.metadata["format"] = "ggml"
        result.metadata["magic"] = magic.decode("ascii", "ignore")

        if file_size < 32:
            result.add_check(
                name="GGML File Size Validation",
                passed=False,
                message="File too small to be valid GGML",
                severity=IssueSeverity.INFO,
                location=self.current_file_path,
                details={"file_size": file_size, "min_required": 32},
                rule_code="S1005",  # Invalid signature/corrupted file
            )
            self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
            return

        # Basic heuristic validation
        try:
            version_bytes = f.read(4)
            if len(version_bytes) < 4:
                result.add_check(
                    name="GGML Header Integrity Check",
                    passed=False,
                    message="Truncated GGML header",
                    severity=IssueSeverity.INFO,
                    location=self.current_file_path,
                    details={"header_bytes_read": len(version_bytes), "expected": 4},
                    rule_code="S902",
                )
                self._mark_inconclusive(result, GGUF_PARSE_INCONCLUSIVE_REASON)
                return

            version = struct.unpack("<I", version_bytes)[0]
            result.metadata["version"] = version

            if version > 10000:  # Reasonable upper bound
                result.add_check(
                    name="GGML Version Check",
                    passed=False,
                    message=f"Suspicious GGML version: {version}",
                    severity=IssueSeverity.WARNING,
                    location=self.current_file_path,
                    details={"version": version, "max_expected": 10000},
                    rule_code="S902",
                )
        except Exception as e:
            result.add_check(
                name="GGML Header Parsing",
                passed=False,
                message=f"Error parsing GGML header: {e}",
                severity=IssueSeverity.CRITICAL,
                location=self.current_file_path,
                details={"error": str(e), "error_type": type(e).__name__},
                rule_code="S902",
            )

        result.bytes_scanned = file_size

    def _read_value(self, f: BinaryIO, vtype: int) -> Any:
        """Read a value of the specified type with security checks."""
        if vtype == 0:  # UINT8
            return struct.unpack("<B", f.read(1))[0]
        if vtype == 1:  # INT8
            return struct.unpack("<b", f.read(1))[0]
        if vtype == 2:  # UINT16
            return struct.unpack("<H", f.read(2))[0]
        if vtype == 3:  # INT16
            return struct.unpack("<h", f.read(2))[0]
        if vtype == 4:  # UINT32
            return struct.unpack("<I", f.read(4))[0]
        if vtype == 5:  # INT32
            return struct.unpack("<i", f.read(4))[0]
        if vtype == 6:  # FLOAT32
            return struct.unpack("<f", f.read(4))[0]
        if vtype == 7:  # BOOL
            return struct.unpack("<B", f.read(1))[0] != 0
        if vtype == 8:  # STRING
            return self._read_string(f)
        if vtype == 9:  # ARRAY
            subtype = struct.unpack("<I", f.read(4))[0]
            (count,) = struct.unpack("<Q", f.read(8))
            return [self._read_value(f, subtype) for _ in range(count)]
        if vtype == 10:  # UINT64
            return struct.unpack("<Q", f.read(8))[0]
        if vtype == 11:  # INT64
            return struct.unpack("<q", f.read(8))[0]
        if vtype == 12:  # FLOAT64
            return struct.unpack("<d", f.read(8))[0]

        raise ValueError(f"Unknown metadata type {vtype}")

    def extract_metadata(self, file_path: str) -> dict[str, Any]:
        """Extract GGUF metadata."""
        metadata = super().extract_metadata(file_path)

        try:
            with open(file_path, "rb") as f:
                # Read GGUF header
                magic = f.read(4)
                if magic != b"GGUF":
                    metadata["error"] = "Invalid GGUF magic bytes"
                    return metadata

                version = struct.unpack("<I", f.read(4))[0]
                tensor_count = struct.unpack("<Q", f.read(8))[0]
                metadata_count = struct.unpack("<Q", f.read(8))[0]

                metadata.update(
                    {
                        "gguf_version": version,
                        "tensor_count": tensor_count,
                        "metadata_count": metadata_count,
                    }
                )

                # Read metadata fields
                gguf_metadata = {}
                for _ in range(metadata_count):
                    try:
                        # Read key
                        key = self._read_string(f)

                        # Read value type
                        vtype = struct.unpack("<I", f.read(4))[0]

                        # Read value
                        value = self._read_value(f, vtype)
                        gguf_metadata[key] = value

                    except Exception as e:
                        gguf_metadata["error_reading_metadata"] = str(e)
                        break

                # Extract key model information
                model_info = {}

                # Common GGUF metadata keys
                key_fields = [
                    "general.name",
                    "general.architecture",
                    "general.quantization_version",
                    "general.file_type",
                    "general.parameter_count",
                    "general.context_length",
                    "tokenizer.ggml.model",
                    "tokenizer.ggml.tokens",
                    "tokenizer.chat_template",
                ]

                for field in key_fields:
                    if field in gguf_metadata:
                        model_info[field.replace(".", "_")] = gguf_metadata[field]

                if model_info:
                    metadata["model_info"] = model_info

                # Summary info
                metadata.update(
                    {
                        "has_model_name": "general.name" in gguf_metadata,
                        "has_tokenizer": any(key.startswith("tokenizer.") for key in gguf_metadata),
                        "has_chat_template": "tokenizer.chat_template" in gguf_metadata,
                        "architecture": gguf_metadata.get("general.architecture", "unknown"),
                        "parameter_count": gguf_metadata.get("general.parameter_count", "unknown"),
                    }
                )

                # Security relevant info
                if "tokenizer.chat_template" in gguf_metadata:
                    template = gguf_metadata["tokenizer.chat_template"]
                    if isinstance(template, str) and len(template) > 1000:
                        metadata["large_chat_template"] = True
                        metadata["chat_template_size"] = len(template)

        except Exception as e:
            metadata["extraction_error"] = str(e)

        return metadata
