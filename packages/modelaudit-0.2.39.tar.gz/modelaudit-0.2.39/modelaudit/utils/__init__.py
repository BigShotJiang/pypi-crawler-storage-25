# Utils package for ModelAudit
"""Utilities for ModelAudit.

Organized into subcategories:
- file/ - File handling utilities (detection, filtering, streaming)
- sources/ - Model source integrations (cloud, HuggingFace, JFrog, DVC)
- helpers/ - Generic utilities (retry, caching, types)
"""

import os
import re
from collections.abc import Iterable
from pathlib import Path

from .file.filtering import DEFAULT_SKIP_EXTENSIONS, DEFAULT_SKIP_FILENAMES, should_skip_file
from .sources.dvc import resolve_dvc_file


def _absolute_without_resolving(path: str | os.PathLike[str]) -> Path:
    """Return an absolute path without following filesystem symlinks."""
    return Path(os.path.abspath(os.fspath(path)))


def is_within_directory(base_dir: str, target: str) -> bool:
    """Return True if the target path is within the given base directory."""
    base_path = Path(base_dir).resolve()
    target_path = Path(target).resolve()
    if os.name == "nt":
        base_norm = os.path.normcase(os.path.normpath(str(base_path)))
        target_norm = os.path.normcase(os.path.normpath(str(target_path)))
        try:
            return os.path.commonpath([target_norm, base_norm]) == base_norm
        except ValueError:
            return False
    try:
        return target_path.is_relative_to(base_path)
    except AttributeError:  # Python < 3.9
        try:
            return os.path.commonpath([target_path, base_path]) == str(base_path)
        except ValueError:
            return False


def normalize_path_for_match(path: str) -> str:
    """Normalize a path string for safe, cross-platform prefix comparisons."""
    normalized = path.replace("\\", "/")
    normalized = re.sub(r"/+", "/", normalized)
    if normalized.startswith("/?/"):
        normalized = normalized[3:]
    return normalized.rstrip("/").lower()


def is_absolute_archive_path(path: str) -> bool:
    """Return True if the path is absolute in a platform-agnostic archive context."""
    normalized = path.replace("\\", "/")
    return normalized.startswith("/") or bool(re.match(r"^[a-zA-Z]:", normalized))


def is_critical_system_path(path: str, critical_paths: Iterable[str]) -> bool:
    """Return True if path targets a critical system location (normalized match)."""
    normalized_path = normalize_path_for_match(path)
    for critical in critical_paths:
        normalized_critical = normalize_path_for_match(critical)
        if normalized_path == normalized_critical or normalized_path.startswith(f"{normalized_critical}/"):
            return True
    return False


def sanitize_archive_path(entry_name: str, base_dir: str) -> tuple[str, bool]:
    """Return normalized path for archive entry and whether it stays within base.

    Parameters
    ----------
    entry_name: str
        Name of the entry in the archive.
    base_dir: str
        Intended extraction directory used for normalization.

    Returns
    -------
    tuple[str, bool]
        (resolved_path, is_safe) where ``is_safe`` is ``False`` if the entry
        would escape ``base_dir`` when extracted.
    """
    base_path = _absolute_without_resolving(base_dir)
    # Normalize separators
    entry = entry_name.replace("\\", "/")
    is_absolute = is_absolute_archive_path(entry)
    if is_absolute:
        # Absolute paths are not allowed
        archive_suffix = entry.lstrip("/").replace("/", os.sep)
        unsafe_resolved = os.path.normpath(f"{base_path}{os.sep}{archive_suffix}")
        return unsafe_resolved, False
    entry = entry.lstrip("/")
    resolved = _absolute_without_resolving(base_path / entry)
    base_str = os.path.normpath(str(base_path))
    resolved_str = os.path.normpath(str(resolved))
    if os.name == "nt":
        base_str = os.path.normcase(base_str)
        resolved_str = os.path.normcase(resolved_str)
    try:
        is_safe = os.path.commonpath([resolved_str, base_str]) == base_str
    except ValueError:  # Windows: different drives
        is_safe = False
    return str(resolved), is_safe
