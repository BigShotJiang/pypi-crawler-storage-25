"""Command-line interface for ModelAudit security scanner."""

import contextlib
import json
import logging
import os
import re
import shutil
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, NoReturn

import click
from yaspin import yaspin
from yaspin.spinners import Spinners

from . import __version__
from .auth.client import auth_client
from .auth.config import (
    cloud_config,
    config,
    get_config_directory_path,
    get_user_email,
    get_user_id,
    is_delegated_from_promptfoo,
    set_user_email,
)
from .cache.trusted_config_store import TrustedConfigStore
from .config import ModelAuditConfig, set_config
from .config.local_config import find_local_config_for_paths
from .core import determine_exit_code, scan_model_directory_or_file
from .integrations.jfrog import scan_jfrog_artifact
from .integrations.sarif_formatter import format_sarif_output
from .models import ModelAuditResultModel
from .rules import Rule, RuleRegistry, Severity
from .scanner_results import IssueSeverity
from .scanner_selection import (
    SCANNER_SELECTION_CONFIG_KEY,
    collect_suppressed_preferred_scanners,
    policy_from_config,
    scanner_catalog,
    scanner_selection_config_from_inputs,
    selected_scanner_extensions,
)
from .scanners.base import make_trusted_source_provenance
from .telemetry import (
    flush_telemetry,
    record_command_used,
    record_download_completed,
    record_download_started,
    record_feature_used,
    record_scan_completed,
    record_scan_failed,
    record_scan_started,
)
from .utils import resolve_dvc_file
from .utils.helpers.auto_defaults import (
    apply_auto_overrides,
    detect_ci_environment,
    generate_auto_defaults,
    parse_size_string,
)
from .utils.helpers.interrupt_handler import interruptible_scan
from .utils.sources.cloud_storage import (
    download_from_cloud,
    is_cloud_url,
    redact_cloud_error_for_display,
    redact_url_for_display,
)
from .utils.sources.huggingface import (
    download_file_from_hf,
    download_model,
    extract_model_id_from_path,
    is_huggingface_file_url,
    is_huggingface_url,
    redact_huggingface_url_for_display,
    redact_huggingface_urls_in_text,
)
from .utils.sources.jfrog import is_jfrog_url, redact_jfrog_error_for_display, redact_jfrog_url_for_display
from .utils.sources.pytorch_hub import download_pytorch_hub_model, is_pytorch_hub_url

logger = logging.getLogger("modelaudit")


def _display_path(path: str) -> str:
    """Return a path safe for user-facing CLI output."""
    if is_cloud_url(path):
        return redact_url_for_display(path)
    if is_jfrog_url(path):
        return redact_jfrog_url_for_display(path)
    return redact_huggingface_url_for_display(path)


def _display_error(error: object, path: str) -> str:
    """Return an error safe for user-facing CLI output."""
    return redact_cloud_error_for_display(error, path) if is_cloud_url(path) else str(error)


@dataclass
class _ScanRuntimeConfig:
    """Resolved scan settings used by source dispatch and scan execution."""

    config: dict[str, Any]
    timeout: int
    show_progress: bool
    cache_enabled: bool
    cache_dir: str | None
    output_format: str
    show_styled_output: bool
    selective_download: bool
    stream_analysis: bool
    scan_and_delete: bool
    max_file_size: int
    max_total_size: int
    skip_non_model_files: bool
    strict_license: bool
    use_hf_whitelist: bool
    max_download_bytes: int | None
    jfrog_api_token: str | None
    jfrog_access_token: str | None
    mlflow_registry_uri: str | None
    scanner_selection: dict[str, Any] | None
    scanner_selection_metadata: dict[str, Any] | None
    scannable_extensions: frozenset[str] | None


@dataclass
class _SourceDispatchResult:
    """Result of source resolution for one path."""

    actual_path: str
    local_scan_required: bool = True
    temp_path: str | None = None
    source_model_id: str | None = None
    source_model_source: str | None = None


@dataclass
class _ScanPathState:
    """Bookkeeping for scanned artifacts and deferred cleanup."""

    scanned_paths: list[str] = field(default_factory=list)
    temp_cleanup_entries: list[tuple[str, bool]] = field(default_factory=list)

    def track_streaming_paths_for_sbom(
        self,
        streaming_result: ModelAuditResultModel,
        fallback_path: str,
    ) -> None:
        """Track concrete streamed artifact paths so SBOM includes all scanned components."""
        added_path = False
        for asset in streaming_result.assets:
            if asset.path:
                self.scanned_paths.append(asset.path)
                added_path = True

        if not added_path:
            self.scanned_paths.append(fallback_path)

    def defer_temp_cleanup(self, temp_path: str | None, *, cache_enabled: bool, verbose: bool) -> None:
        """Track temporary artifacts for post-SBOM cleanup."""
        if temp_path and os.path.exists(temp_path) and not cache_enabled:
            self.temp_cleanup_entries.append((temp_path, os.path.isdir(temp_path)))
            if verbose:
                logger.debug(f"Deferring cleanup of temporary artifact: {temp_path}")


def should_use_color() -> bool:
    """Check if colors should be used in output."""
    # Respect NO_COLOR environment variable
    if os.getenv("NO_COLOR"):
        return False
    # Only use colors if output is a TTY
    return sys.stdout.isatty()


def should_show_spinner() -> bool:
    """Check if spinners should be shown."""
    # Only show spinners if output is a TTY
    return sys.stdout.isatty()


def style_text(text: str, **kwargs: Any) -> str:
    """Style text only if colors are enabled."""
    if should_use_color():
        return click.style(text, **kwargs)
    return text


def get_trusted_config_store() -> TrustedConfigStore:
    """Return the persistent store used for trusted local configs."""
    return TrustedConfigStore()


def can_use_trusted_local_config(output_format: str) -> bool:
    """Return True when the current scan mode supports trusted local configs."""
    return (
        output_format == "text"
        and sys.stdin.isatty()
        and sys.stdout.isatty()
        and not detect_ci_environment()
        and not is_delegated_from_promptfoo()
    )


def maybe_load_trusted_local_config(
    paths: list[str],
    output_format: str,
    *,
    quiet: bool,
) -> tuple[ModelAuditConfig | None, bool, Path | None]:
    """Load a trusted local config for interactive text scans when available."""
    if not can_use_trusted_local_config(output_format):
        return None, False, None

    candidate = find_local_config_for_paths(paths)
    if candidate is None:
        return None, False, None

    store = get_trusted_config_store()
    if store.is_trusted(candidate):
        return ModelAuditConfig.load(candidate.config_path), True, candidate.config_path

    if quiet:
        return None, False, None

    click.echo(style_text(f"Found local ModelAudit config at {candidate.config_path}", fg="cyan"))
    click.echo("It can suppress findings or change severities.")
    choice = click.prompt(
        "Use it? [y] once, [a] always, [n] no",
        type=click.Choice(["y", "a", "n"], case_sensitive=False),
        default="n",
        show_choices=False,
    ).lower()

    if choice == "n":
        return None, False, None

    if choice == "a":
        store.trust(candidate)

    return ModelAuditConfig.load(candidate.config_path), True, candidate.config_path


def build_scan_rule_config(
    paths: list[str],
    suppress: tuple[str, ...],
    severity_overrides: dict[str, str],
    *,
    output_format: str,
    quiet: bool,
) -> tuple[ModelAuditConfig, bool, Path | None]:
    """Build the effective scan rule config, including trusted local policy when enabled."""
    base_config, local_config_applied, local_config_path = maybe_load_trusted_local_config(
        paths,
        output_format,
        quiet=quiet,
    )
    cli_config = ModelAuditConfig.from_cli_args(
        suppress=list(suppress) if suppress else None,
        severity=severity_overrides if severity_overrides else None,
        base_config=base_config,
    )
    return cli_config, local_config_applied, local_config_path


def expand_paths(paths: tuple[str, ...]) -> tuple[list[str], list[str]]:
    """Expand and validate input paths with type safety."""
    expanded: list[str] = []
    missing_globs: list[str] = []
    for path_str in paths:
        if "://" in path_str:
            expanded.append(path_str)
            continue

        # Handle glob patterns and resolve paths
        path = Path(path_str)
        is_remote_url = bool(re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", path_str))
        if ("*" in path_str or "?" in path_str) and not is_remote_url:
            # Handle glob patterns
            import glob

            matches = glob.glob(path_str, recursive=True)
            if matches:
                expanded.extend(matches)
            else:
                missing_globs.append(path_str)
        else:
            expanded.append(str(path.resolve()) if path.exists() else path_str)
    return expanded, missing_globs


def parse_severity_overrides(values: tuple[str, ...]) -> dict[str, str]:
    """Parse CLI severity override arguments of the form CODE=LEVEL."""
    overrides: dict[str, str] = {}
    valid_levels = {severity.value for severity in Severity}
    for entry in values:
        if "=" not in entry:
            raise click.BadParameter("Severity overrides must use CODE=LEVEL format (e.g., S101=CRITICAL)")
        code, level = entry.split("=", 1)
        code = code.strip().upper()
        level = level.strip().upper()
        if not code or not level:
            raise click.BadParameter("Severity overrides must include both a rule code and a severity level")
        if RuleRegistry.get_rule(code) is None:
            raise click.BadParameter(f"Unknown rule code '{code}' in --severity override")
        if level not in valid_levels:
            allowed = ", ".join(sorted(valid_levels))
            raise click.BadParameter(f"Invalid severity level '{level}'. Allowed values: {allowed}")
        overrides[code] = level
    return overrides


def get_severity_color(severity: str) -> str:
    """Map severity string to a color for CLI display."""
    mapping = {
        "CRITICAL": "red",
        "HIGH": "red",
        "MEDIUM": "yellow",
        "LOW": "blue",
        "INFO": "green",
    }
    return mapping.get(severity.upper(), "white")


def create_progress_callback_wrapper(progress_callback: Any | None, spinner: Any | None) -> Any | None:
    """Create a type-safe progress callback wrapper."""
    if not progress_callback:
        return None

    def wrapped_callback(message: str, percentage: float) -> None:
        """Wrapped progress callback with type safety."""
        try:
            progress_callback(message, percentage)
            if spinner and hasattr(spinner, "text"):
                spinner.text = message
        except Exception as e:
            logger.warning(f"Progress callback error: {e}")

    return wrapped_callback


def is_mlflow_uri(path: str) -> bool:
    """Check if a path is an MLflow model URI."""
    return path.startswith("models:/")


def _resolve_scan_paths(paths: tuple[str, ...], scan_start_time: float) -> list[str]:
    """Expand user paths, resolve DVC pointers, warn on unmatched globs, and fail fast if empty."""
    expanded_paths, missing_globs = expand_paths(paths)

    dvc_expanded_paths: list[str] = []
    for path in expanded_paths:
        if os.path.isfile(path) and path.endswith(".dvc"):
            targets = resolve_dvc_file(path)
            if targets:
                dvc_expanded_paths.extend(targets)
            else:
                dvc_expanded_paths.append(path)
        else:
            dvc_expanded_paths.append(path)

    if missing_globs:
        click.echo(
            style_text(
                f"Warning: glob pattern(s) did not match any files: {', '.join(missing_globs)}",
                fg="yellow",
            ),
            err=True,
        )
        click.echo("Note: glob expansion is only applied to local paths.", err=True)

    if not dvc_expanded_paths:
        click.echo(
            style_text(
                "No matching paths found. Check your paths or glob patterns.",
                fg="red",
                bold=True,
            ),
            err=True,
        )
        record_scan_failed(time.time() - scan_start_time, "No matching paths")
        flush_telemetry()
        sys.exit(2)

    return dvc_expanded_paths


def _build_user_scan_overrides(
    *,
    format: str | None,
    timeout: int | None,
    max_size: str | None,
    cache_dir: str | None,
    progress: bool,
    no_cache: bool,
    no_whitelist: bool,
    stream: bool,
    strict: bool,
    verbose: bool,
    quiet: bool,
    scanners: tuple[str, ...],
    exclude_scanners: tuple[str, ...],
    scan_start_time: float,
) -> dict[str, Any]:
    """Normalize scan command flags into config overrides."""
    user_overrides: dict[str, Any] = {}
    if format is not None:
        user_overrides["format"] = format
    if timeout is not None:
        user_overrides["timeout"] = timeout
    if max_size is not None:
        try:
            user_overrides["max_file_size"] = parse_size_string(max_size)
            user_overrides["max_total_size"] = parse_size_string(max_size)
        except ValueError as exc:
            click.echo(f"Error parsing --max-size: {exc}", err=True)
            record_scan_failed(time.time() - scan_start_time, f"Invalid max-size: {exc}")
            flush_telemetry()
            sys.exit(2)

    if cache_dir is not None:
        user_overrides["cache_dir"] = str(Path(cache_dir).expanduser())
        user_overrides["use_cache"] = True

    if progress:
        user_overrides["show_progress"] = True
    if no_cache:
        user_overrides["use_cache"] = False
    if no_whitelist:
        user_overrides["use_hf_whitelist"] = False
    if stream:
        user_overrides["scan_and_delete"] = True
    if strict:
        user_overrides["skip_non_model_files"] = False
        user_overrides["selective_download"] = False
        user_overrides["strict_license"] = True
        user_overrides["use_cache"] = False
        user_overrides["use_hf_whitelist"] = False
    if verbose:
        user_overrides["verbose"] = True
    if quiet:
        user_overrides["verbose"] = False

    if scanners or exclude_scanners:
        try:
            user_overrides[SCANNER_SELECTION_CONFIG_KEY] = scanner_selection_config_from_inputs(
                scanners=scanners,
                exclude_scanners=exclude_scanners,
            )
        except ValueError as exc:
            click.echo(f"Error parsing scanner selection: {exc}", err=True)
            record_scan_failed(time.time() - scan_start_time, f"Invalid scanner selection: {exc}")
            flush_telemetry()
            sys.exit(2)

    return user_overrides


def _resolve_scan_runtime_config(
    expanded_paths: list[str],
    *,
    format: str | None,
    output: str | None,
    timeout: int | None,
    max_size: str | None,
    cache_dir: str | None,
    progress: bool,
    no_cache: bool,
    no_whitelist: bool,
    stream: bool,
    strict: bool,
    verbose: bool,
    quiet: bool,
    scanners: tuple[str, ...],
    exclude_scanners: tuple[str, ...],
    suppress: tuple[str, ...],
    severity: tuple[str, ...],
    scan_start_time: float,
) -> _ScanRuntimeConfig:
    """Build the effective scan runtime settings and apply rule config."""
    auto_defaults = generate_auto_defaults(expanded_paths)
    user_overrides = _build_user_scan_overrides(
        format=format,
        timeout=timeout,
        max_size=max_size,
        cache_dir=cache_dir,
        progress=progress,
        no_cache=no_cache,
        no_whitelist=no_whitelist,
        stream=stream,
        strict=strict,
        verbose=verbose,
        quiet=quiet,
        scanners=scanners,
        exclude_scanners=exclude_scanners,
        scan_start_time=scan_start_time,
    )
    config_values = apply_auto_overrides(user_overrides, auto_defaults)

    final_cache = config_values.get("use_cache", True)
    final_format = config_values.get("format", "text")
    final_cache_dir = config_values.get("cache_dir") if final_cache else None
    show_styled_output = final_format == "text" or bool(output)

    severity_overrides = parse_severity_overrides(severity)
    try:
        cli_config, local_config_applied, local_config_path = build_scan_rule_config(
            expanded_paths,
            suppress,
            severity_overrides,
            output_format=final_format,
            quiet=quiet,
        )
    except ValueError as exc:
        raise click.BadParameter(str(exc)) from exc
    set_config(cli_config)

    if local_config_applied:
        if final_cache:
            final_cache = False
            final_cache_dir = None
        if not quiet and show_styled_output and local_config_path is not None:
            click.echo(style_text(f"Using local ModelAudit config: {local_config_path}", fg="cyan"))
            click.echo(style_text("Scan result cache disabled for this run.", fg="yellow"))

    max_download_bytes = None
    if max_size is not None:
        with contextlib.suppress(ValueError):
            max_download_bytes = parse_size_string(max_size)

    scanner_selection = config_values.get(SCANNER_SELECTION_CONFIG_KEY)
    scanner_policy = policy_from_config(config_values)
    scannable_extensions = (
        selected_scanner_extensions(scanner_policy, conservative=True) if scanner_policy.active else None
    )

    return _ScanRuntimeConfig(
        config=config_values,
        timeout=config_values.get("timeout", 3600),
        show_progress=config_values.get("show_progress", False),
        cache_enabled=final_cache,
        cache_dir=final_cache_dir,
        output_format=final_format,
        show_styled_output=show_styled_output,
        selective_download=config_values.get("selective_download", True),
        stream_analysis=config_values.get("stream_analysis", False),
        scan_and_delete=config_values.get("scan_and_delete", False),
        max_file_size=config_values.get("max_file_size", 0),
        max_total_size=config_values.get("max_total_size", 0),
        skip_non_model_files=config_values.get("skip_non_model_files", True),
        strict_license=config_values.get("strict_license", False),
        use_hf_whitelist=config_values.get("use_hf_whitelist", True),
        max_download_bytes=max_download_bytes,
        jfrog_api_token=os.getenv("JFROG_API_TOKEN"),
        jfrog_access_token=os.getenv("JFROG_ACCESS_TOKEN"),
        mlflow_registry_uri=os.getenv("MLFLOW_TRACKING_URI"),
        scanner_selection=scanner_selection if isinstance(scanner_selection, dict) else None,
        scanner_selection_metadata=scanner_policy.to_metadata() if scanner_policy.active else None,
        scannable_extensions=scannable_extensions,
    )


def _scanner_selection_overrides(runtime: _ScanRuntimeConfig) -> dict[str, Any]:
    """Return config kwargs needed to preserve scanner selection across scan paths."""
    if runtime.scanner_selection is None:
        return {}
    return {SCANNER_SELECTION_CONFIG_KEY: runtime.scanner_selection}


def _show_scan_runtime_defaults(
    runtime: _ScanRuntimeConfig,
    expanded_paths: list[str],
    blacklist: tuple[str, ...],
    *,
    quiet: bool,
    verbose: bool,
) -> None:
    """Emit resolved defaults and the scan header for text-friendly outputs."""
    if not quiet and runtime.show_styled_output:
        if verbose:
            click.echo(f"Defaults: {len(expanded_paths)} path(s) analyzed")
            for key, value in runtime.config.items():
                if key != "cache_dir":
                    click.echo(f"   • {key}: {value}")
        elif not runtime.config.get("colors", True):
            pass

    if runtime.show_styled_output and not quiet:
        delegation_note = ""
        if is_delegated_from_promptfoo():
            delegation_note = style_text(" (via promptfoo)", dim=True)

        header = [
            "─" * 80,
            style_text("ModelAudit Security Scanner", fg="blue", bold=True) + delegation_note,
            style_text(
                "Scanning for potential security issues in ML model files",
                fg="cyan",
            ),
            "─" * 80,
        ]
        click.echo("\n".join(header))
        display_paths = [_display_path(path) for path in expanded_paths]
        click.echo(f"Paths to scan: {style_text(', '.join(display_paths), fg='green')}")
        if blacklist:
            click.echo(
                f"Additional blacklist patterns: {style_text(', '.join(blacklist), fg='yellow')}",
            )
        click.echo("─" * 80)
        click.echo("")


def _configure_scan_logging(verbose: bool) -> None:
    """Set CLI logging verbosity and suppress noisy internals in normal mode."""
    if verbose:
        logger.setLevel(logging.DEBUG)
        logging.getLogger("modelaudit.core").setLevel(logging.DEBUG)
        return

    logging.getLogger("modelaudit.core").setLevel(logging.WARNING)
    logging.getLogger("modelaudit.utils.helpers.secure_hasher").setLevel(logging.WARNING)
    logging.getLogger("modelaudit.cache.cache_manager").setLevel(logging.WARNING)


def _initialize_progress_tracking(
    runtime: _ScanRuntimeConfig,
    expanded_paths: list[str],
    *,
    output: str | None,
    verbose: bool,
) -> tuple[Any | None, list[Any]]:
    """Create optional progress tracking/reporters for text stdout scans."""
    progress_tracker = None
    progress_reporters: list[Any] = []

    if not runtime.show_progress or not expanded_paths:
        return progress_tracker, progress_reporters

    try:
        from .progress import ConsoleProgressReporter, ProgressTracker

        progress_tracker = ProgressTracker(update_interval=2.0)

        if progress_tracker and runtime.output_format == "text" and not output:
            console_reporter = ConsoleProgressReporter(  # type: ignore[possibly-unresolved-reference]
                update_interval=2.0,
                disable_on_non_tty=True,
                show_bytes=True,
                show_items=True,
            )
            progress_reporters.append(console_reporter)
            progress_tracker.add_reporter(console_reporter)
    except (ImportError, RecursionError) as exc:
        if verbose:
            if isinstance(exc, RecursionError):
                click.echo("Progress tracking disabled due to import cycle", err=True)
            else:
                click.echo("Progress tracking not available (missing dependencies)", err=True)
        runtime.show_progress = False

    return progress_tracker, progress_reporters


def _complete_progress_tracking(progress_tracker: Any | None, *, verbose: bool) -> None:
    """Finalize progress tracker state after all paths have been processed."""
    if not progress_tracker:
        return

    try:
        from .progress import ProgressPhase

        progress_tracker.set_phase(ProgressPhase.FINALIZING, "Completing scan and generating report")
        progress_tracker.complete()
    except (ImportError, RecursionError):
        if verbose:
            click.echo("Progress tracking completion skipped due to import issues", err=True)
    except Exception as exc:
        logger.warning(f"Error completing progress tracking: {exc}")


def _cleanup_progress_reporters(progress_reporters: list[Any]) -> None:
    """Close progress reporters safely."""
    for reporter in progress_reporters:
        try:
            if hasattr(reporter, "cleanup"):
                reporter.cleanup()
            elif hasattr(reporter, "close"):
                reporter.close()
        except Exception as exc:
            logger.warning(f"Error cleaning up progress reporter: {exc}")


def _cleanup_temp_artifacts(temp_cleanup_entries: list[tuple[str, bool]], *, verbose: bool) -> None:
    """Delete deferred temporary files/directories after SBOM generation."""
    for temp_path, is_dir in temp_cleanup_entries:
        if os.path.exists(temp_path):
            try:
                if is_dir:
                    shutil.rmtree(temp_path)
                else:
                    os.remove(temp_path)
                if verbose:
                    logger.debug(f"Cleaned up temporary artifact: {temp_path}")
            except Exception as exc:
                logger.warning(f"Failed to clean up temporary artifact {temp_path}: {exc!s}")


def _write_scan_sbom(
    sbom: str | None,
    audit_result: ModelAuditResultModel,
    expanded_paths: list[str],
    path_state: _ScanPathState,
    *,
    scan_and_delete: bool,
) -> None:
    """Write CycloneDX SBOM output from the concrete paths that were scanned."""
    if not sbom:
        return

    from .integrations.sbom_generator import generate_sbom_pydantic

    asset_paths = list(
        dict.fromkeys(asset.path for asset in audit_result.assets if asset.path and asset.type != "skipped")
    )
    if asset_paths and scan_and_delete:
        paths_for_sbom = asset_paths
    else:
        paths_for_sbom = path_state.scanned_paths if path_state.scanned_paths else expanded_paths

    sbom_text = generate_sbom_pydantic(paths_for_sbom, audit_result)
    with open(sbom, "w", encoding="utf-8") as sbom_file:
        sbom_file.write(sbom_text)


def _format_scan_output(
    audit_result: ModelAuditResultModel,
    expanded_paths: list[str],
    *,
    output_format: str,
    verbose: bool,
) -> str:
    """Render scan results in the requested output format."""
    if output_format == "json":
        if not verbose:
            audit_result.issues = [issue for issue in audit_result.issues if issue.severity != IssueSeverity.DEBUG]
            audit_result.checks = [check for check in audit_result.checks if check.severity != IssueSeverity.DEBUG]
        return audit_result.model_dump_json(indent=2, exclude_none=True)

    if output_format == "sarif":
        return format_sarif_output(audit_result, expanded_paths, verbose)

    return format_text_output(audit_result.model_dump(), verbose)


def _emit_scan_output(
    output_text: str,
    audit_result: ModelAuditResultModel,
    *,
    output: str | None,
    output_format: str,
    verbose: bool,
) -> None:
    """Write rendered scan output to a file or stdout and preserve text-mode UX."""
    if output:
        with open(output, "w", encoding="utf-8") as output_file:
            output_file.write(output_text)

        click.echo(f"Results written to {output}")

        if verbose:
            visible_issues = audit_result.issues
            if visible_issues:
                critical_count = len([issue for issue in visible_issues if issue.severity == IssueSeverity.CRITICAL])
                warning_count = len([issue for issue in visible_issues if issue.severity == IssueSeverity.WARNING])
                if critical_count > 0:
                    click.echo(f"Found {critical_count} critical issue(s), {warning_count} warning(s)")
                elif warning_count > 0:
                    click.echo(f"Found {warning_count} warning(s)")
                else:
                    click.echo(f"Found {len(visible_issues)} informational issue(s)")
            else:
                click.echo("No security issues found")
        return

    if output_format == "text":
        click.echo("\n" + "─" * 80)
    click.echo(output_text)


def _format_scanner_catalog(output_format: str) -> str:
    """Render registered scanners for CLI discovery."""
    scanners = scanner_catalog()
    if output_format == "json":
        return json.dumps({"scanners": scanners}, indent=2)

    lines = ["Registered scanners:"]
    for scanner in scanners:
        extensions = ", ".join(scanner["extensions"]) if scanner["extensions"] else "-"
        dependencies = ", ".join(scanner["dependencies"]) if scanner["dependencies"] else "-"
        lines.extend(
            [
                f"{scanner['id']} ({scanner['class']})",
                f"  extensions: {extensions}",
                f"  dependencies: {dependencies}",
                f"  {scanner['description']}",
            ]
        )
    return "\n".join(lines)


def _emit_scanner_catalog(*, output_format: str, output: str | None) -> None:
    """Write scanner discovery output to a file or stdout."""
    if output_format == "sarif":
        click.echo("Error: --list-scanners supports text or json output, not sarif", err=True)
        sys.exit(2)

    output_text = _format_scanner_catalog(output_format)
    if output:
        with open(output, "w", encoding="utf-8") as output_file:
            output_file.write(output_text)
            output_file.write("\n")
        return
    click.echo(output_text)


def _announce_suppressed_preferred_scanners(suppressions: list[dict[str, Any]]) -> None:
    """Print a stderr warning summarizing preferred scanners suppressed by selection."""
    suppressed_ids = sorted({entry["scanner_id"] for entry in suppressions})
    click.echo(
        "Warning: scanner selection suppressed the preferred scanner(s) for "
        f"{len(suppressions)} file(s): {', '.join(suppressed_ids)}. "
        "These files were not analyzed by the scanner that routing would normally pick; "
        "rerun without --scanners/--exclude-scanner or widen the selection to close the gap.",
        err=True,
    )
    for entry in suppressions[:5]:
        click.echo(f"  - {entry['location']} (would have used: {entry['scanner_id']})", err=True)
    if len(suppressions) > 5:
        click.echo(f"  … and {len(suppressions) - 5} more", err=True)


def _record_suppressed_preferred_scanners(audit_result: ModelAuditResultModel) -> list[dict[str, Any]]:
    """Populate audit metadata with preferred-scanner suppressions and return them."""
    suppressions = collect_suppressed_preferred_scanners(audit_result.checks or [])
    if not suppressions:
        return suppressions

    if audit_result.scanner_selection is None:
        audit_result.scanner_selection = {}
    audit_result.scanner_selection["suppressed_preferred_scanner_ids"] = sorted(
        {entry["scanner_id"] for entry in suppressions}
    )
    return suppressions


def _record_scan_end_and_exit(audit_result: ModelAuditResultModel, scan_start_time: float) -> NoReturn:
    """Record final telemetry and exit with the scan result's status code."""
    scan_duration = time.time() - scan_start_time
    try:
        if audit_result.has_errors:
            record_scan_failed(scan_duration, "Scan completed with errors")
        else:
            record_scan_completed(scan_duration, audit_result.model_dump())
    finally:
        flush_telemetry()

    sys.exit(determine_exit_code(audit_result))


def _should_skip_non_model_file(scan_path: str, runtime: _ScanRuntimeConfig, *, verbose: bool) -> bool:
    """Return True when the local scan prefilter should skip a non-model file."""
    if not runtime.skip_non_model_files or not os.path.isfile(scan_path):
        return False

    _, ext = os.path.splitext(scan_path)
    ext = ext.lower()
    if ext in (".py", ".js", ".html", ".css"):
        if verbose:
            logger.debug(f"Skipped: {scan_path} (non-model file)")
        if runtime.show_styled_output:
            click.echo(f"Skipping non-model file: {scan_path}")
        return True

    if ext != ".txt":
        return False

    from modelaudit.scanners import SCANNER_REGISTRY

    if any(cls().can_handle(scan_path) for cls in SCANNER_REGISTRY):
        return False

    if verbose:
        logger.debug(f"Skipped: {scan_path} (non-model .txt file)")
    if runtime.show_styled_output:
        click.echo(f"Skipping non-model file: {scan_path}")
    return True


def _create_path_progress_callback(
    *,
    spinner: Any | None,
    progress_tracker: Any | None,
    actual_path: str,
) -> Any | None:
    """Build the legacy spinner callback or enhanced tracker callback for one path."""
    progress_callback = None
    if spinner and not progress_tracker:

        def update_progress(message: str, percentage: float, spinner_bound: Any = spinner) -> None:
            spinner_bound.text = f"{message} ({percentage:.1f}%)"

        return update_progress

    if not progress_tracker:
        return progress_callback

    try:
        from .progress import ProgressPhase

        if os.path.isfile(actual_path):
            total_bytes = os.path.getsize(actual_path)
            total_items = 1
        elif os.path.isdir(actual_path):
            total_bytes = sum(
                file_path.stat().st_size for file_path in Path(actual_path).rglob("*") if file_path.is_file()
            )
            total_items = len(list(Path(actual_path).rglob("*")))
        else:
            total_bytes = 0
            total_items = 1

        progress_tracker.stats.total_bytes = total_bytes
        progress_tracker.stats.total_items = total_items
        progress_tracker.set_phase(ProgressPhase.INITIALIZING, f"Starting scan: {actual_path}")
    except (ImportError, RecursionError):
        return None

    def enhanced_progress_callback(message: str, percentage: float) -> None:
        if progress_tracker:
            bytes_processed = int((percentage / 100.0) * total_bytes) if total_bytes > 0 else 0
            progress_tracker.update_bytes(bytes_processed, message)

            message_lower = message.lower()
            if "loading" in message_lower:
                progress_tracker.set_phase(ProgressPhase.LOADING, message)
            elif "analyzing" in message_lower or "scanning" in message_lower:
                progress_tracker.set_phase(ProgressPhase.ANALYZING, message)
            elif "checking" in message_lower:
                progress_tracker.set_phase(ProgressPhase.CHECKING, message)

        if spinner:
            spinner.text = f"{message} ({percentage:.1f}%)"

    return enhanced_progress_callback


def _scan_local_or_downloaded_path(
    path: str,
    source_result: _SourceDispatchResult,
    audit_result: ModelAuditResultModel,
    path_state: _ScanPathState,
    runtime: _ScanRuntimeConfig,
    progress_tracker: Any | None,
    blacklist: tuple[str, ...],
    *,
    verbose: bool,
) -> None:
    """Scan a local artifact or a downloaded path resolved by source dispatch."""
    actual_path = source_result.actual_path
    display_path = _display_path(path)
    if _should_skip_non_model_file(actual_path, runtime, verbose=verbose):
        return

    spinner = None
    if runtime.show_styled_output and should_show_spinner():
        spinner_text = f"Scanning {style_text(display_path, fg='cyan')}"
        spinner = yaspin(Spinners.dots, text=spinner_text)
        spinner.start()
    elif runtime.show_styled_output:
        click.echo(f"Scanning {display_path}...")

    try:
        progress_callback = _create_path_progress_callback(
            spinner=spinner,
            progress_tracker=progress_tracker,
            actual_path=actual_path,
        )

        if runtime.scan_and_delete and os.path.isdir(actual_path):
            from .core import scan_model_streaming
            from .utils.helpers.file_iterator import iterate_files_streaming

            if spinner:
                spinner.text = "Starting streaming scan of directory..."
            elif runtime.show_styled_output:
                click.echo(style_text("🔄 Starting streaming scan of directory...", fg="cyan"))

            file_generator = iterate_files_streaming(actual_path)
            streaming_result = scan_model_streaming(
                file_generator=file_generator,
                timeout=runtime.timeout,
                delete_after_scan=False,
                scan_root=actual_path,
                progress_callback=progress_callback,
                blacklist_patterns=list(blacklist) if blacklist else None,
                max_file_size=runtime.max_file_size,
                max_total_size=runtime.max_total_size,
                strict_license=runtime.strict_license,
                skip_file_types=runtime.skip_non_model_files,
                use_hf_whitelist=runtime.use_hf_whitelist,
                cache_enabled=runtime.cache_enabled,
                cache_dir=runtime.cache_dir,
                **_scanner_selection_overrides(runtime),
            )
            audit_result.aggregate_scan_result(streaming_result.model_dump())
            path_state.track_streaming_paths_for_sbom(streaming_result, actual_path)

            if spinner:
                spinner.ok(style_text("✅ Streaming scan complete", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo(style_text("✅ Streaming scan complete", fg="green", bold=True))
            return

        config_overrides: dict[str, Any] = {
            "enable_progress": bool(progress_tracker),
            "progress_update_interval": 2.0,
            "cache_enabled": runtime.cache_enabled,
            "cache_dir": runtime.cache_dir,
            **_scanner_selection_overrides(runtime),
        }
        if source_result.source_model_id and source_result.source_model_source == "huggingface":
            config_overrides["_trusted_source_provenance"] = make_trusted_source_provenance(
                source_result.source_model_id,
                source_result.source_model_source,
            )

        if runtime.max_file_size > 0 or runtime.max_total_size > 0:
            record_feature_used(
                "large_model_support",
                max_file_size=runtime.max_file_size,
                max_total_size=runtime.max_total_size,
            )

        scan_results: ModelAuditResultModel = scan_model_directory_or_file(
            actual_path,
            blacklist_patterns=list(blacklist) if blacklist else None,
            timeout=runtime.timeout,
            max_file_size=runtime.max_file_size,
            max_total_size=runtime.max_total_size,
            strict_license=runtime.strict_license,
            progress_callback=progress_callback,
            skip_file_types=runtime.skip_non_model_files,
            use_hf_whitelist=runtime.use_hf_whitelist,
            **config_overrides,
        )
        audit_result.aggregate_scan_result(scan_results.model_dump())
        path_state.scanned_paths.append(actual_path)

        visible_issues = [
            issue for issue in list(scan_results.issues) if verbose or issue.severity != IssueSeverity.DEBUG
        ]
        issue_count = len(visible_issues)
        has_critical = any(issue.severity == IssueSeverity.CRITICAL for issue in visible_issues)

        if spinner:
            spinner.text = f"Scanned {style_text(display_path, fg='cyan')}"
            if issue_count == 0:
                spinner.ok(style_text("✅ Clean", fg="green", bold=True))
            elif has_critical:
                spinner.fail(
                    style_text(
                        f"🚨 Found {issue_count} issue{'s' if issue_count > 1 else ''} (CRITICAL)",
                        fg="red",
                        bold=True,
                    ),
                )
            else:
                spinner.ok(
                    style_text(
                        f"⚠️  Found {issue_count} issue{'s' if issue_count > 1 else ''}",
                        fg="yellow",
                        bold=True,
                    ),
                )
        elif runtime.show_styled_output:
            if issue_count == 0:
                click.echo(f"Scanned {display_path}: Clean")
            else:
                issues_str = "issue" if issue_count == 1 else "issues"
                if has_critical:
                    click.echo(f"Scanned {display_path}: Found {issue_count} {issues_str} (CRITICAL)")
                else:
                    click.echo(f"Scanned {display_path}: Found {issue_count} {issues_str}")
    except Exception as exc:
        display_error = _display_error(exc, path)
        if spinner:
            spinner.text = f"Error scanning {style_text(display_path, fg='cyan')}"
            spinner.fail(style_text("❌ Error", fg="red", bold=True))
        elif runtime.show_styled_output:
            click.echo(f"Error scanning {display_path}")

        logger.error(f"Error during scan of {display_path}: {display_error}", exc_info=verbose)
        click.echo(f"Error scanning {display_path}: {display_error}", err=True)
        audit_result.has_errors = True
        path_state.scanned_paths.append(actual_path)

        if progress_tracker:
            progress_tracker.report_error(exc)


def _resolve_scan_source_for_path(
    path: str,
    audit_result: ModelAuditResultModel,
    path_state: _ScanPathState,
    runtime: _ScanRuntimeConfig,
    blacklist: tuple[str, ...],
    *,
    verbose: bool,
    dry_run: bool,
) -> _SourceDispatchResult | None:
    """Resolve one source path and execute source-native scans when they should bypass local scanning."""
    if is_huggingface_file_url(path):
        display_path = redact_huggingface_url_for_display(path)
        download_spinner = None
        temp_dir = None
        if runtime.show_styled_output and should_show_spinner():
            download_spinner = yaspin(
                Spinners.dots, text=f"Downloading file from {style_text(display_path, fg='cyan')}"
            )
            download_spinner.start()
        elif runtime.show_styled_output:
            click.echo(f"Downloading file from {display_path}...")

        try:
            if runtime.cache_enabled and runtime.cache_dir:
                hf_cache_dir = Path(runtime.cache_dir) / "huggingface"
            elif runtime.cache_enabled:
                hf_cache_dir = Path.home() / ".modelaudit" / "cache" / "huggingface"
            else:
                import tempfile

                hf_cache_dir = Path(tempfile.mkdtemp(prefix="modelaudit_hf_"))
                temp_dir = str(hf_cache_dir)

            download_path = download_file_from_hf(path, cache_dir=hf_cache_dir)
            source_model_id, source_model_source = extract_model_id_from_path(path)

            if not runtime.cache_enabled and temp_dir is None:
                temp_dir = str(hf_cache_dir)

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo(style_text("✅ Download complete", fg="green", bold=True))

            return _SourceDispatchResult(
                actual_path=str(download_path),
                temp_path=temp_dir,
                source_model_id=source_model_id,
                source_model_source=source_model_source,
            )
        except Exception as exc:
            if download_spinner:
                download_spinner.fail(style_text("❌ Download failed", fg="red", bold=True))
            elif runtime.show_styled_output:
                click.echo(style_text("❌ Download failed", fg="red", bold=True))

            error_msg = redact_huggingface_urls_in_text(str(exc))
            logger.error(f"Failed to download file from {display_path}: {error_msg}", exc_info=verbose)
            click.echo(f"Error downloading file from {display_path}: {error_msg}", err=True)
            audit_result.has_errors = True
            path_state.defer_temp_cleanup(
                temp_dir,
                cache_enabled=runtime.cache_enabled,
                verbose=verbose,
            )
            return None

    if is_huggingface_url(path):
        display_path = redact_huggingface_url_for_display(path)
        if runtime.show_styled_output:
            click.echo(f"\n📥 Preparing to download from {style_text(display_path, fg='cyan')}")

            try:
                from .utils.sources.huggingface import get_model_info

                model_info = get_model_info(path)
                size_bytes = model_info["total_size"]
                if size_bytes == 0:
                    size_str = "Unknown size"
                elif size_bytes >= 1024 * 1024 * 1024:
                    size_str = f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
                elif size_bytes >= 1024 * 1024:
                    size_str = f"{size_bytes / (1024 * 1024):.2f} MB"
                else:
                    size_str = f"{size_bytes / 1024:.2f} KB"

                click.echo(f"   Model: {model_info['model_id']}")
                click.echo(f"   Size: {size_str} ({model_info['file_count']} files)")

                if runtime.scan_and_delete:
                    click.echo(style_text("   Mode: Streaming (scan and delete to save disk)", fg="cyan"))
            except Exception as exc:
                logger.debug("Unable to display HuggingFace model metadata for %s: %s", path, exc)

        temp_dir = None
        try:
            source_model_id, source_model_source = extract_model_id_from_path(path)
            if runtime.cache_enabled and runtime.cache_dir:
                hf_cache_dir = Path(runtime.cache_dir)
            elif runtime.cache_enabled:
                hf_cache_dir = Path.home() / ".modelaudit" / "cache"
            else:
                import tempfile

                hf_cache_dir = Path(tempfile.mkdtemp(prefix="modelaudit_hf_"))
                temp_dir = str(hf_cache_dir)

            record_download_started("huggingface", display_path)
            record_feature_used("huggingface_download", cache_enabled=runtime.cache_enabled)
            download_start = time.time()
            trusted_source_provenance = None
            if source_model_id and source_model_source == "huggingface":
                trusted_source_provenance = make_trusted_source_provenance(
                    source_model_id,
                    source_model_source,
                )

            if runtime.scan_and_delete:
                from .core import scan_model_streaming
                from .utils.sources.huggingface import download_model_streaming

                if runtime.show_styled_output:
                    click.echo(style_text("🔄 Starting streaming scan...", fg="cyan"))

                file_generator = download_model_streaming(
                    path,
                    cache_dir=hf_cache_dir,
                    show_progress=runtime.show_progress,
                )

                streaming_kwargs: dict[str, Any] = {}
                if trusted_source_provenance is not None:
                    streaming_kwargs["_trusted_source_provenance"] = trusted_source_provenance
                streaming_kwargs.update(_scanner_selection_overrides(runtime))

                streaming_result = scan_model_streaming(
                    file_generator=file_generator,
                    timeout=runtime.timeout,
                    delete_after_scan=True,
                    blacklist_patterns=list(blacklist) if blacklist else None,
                    max_file_size=runtime.max_file_size,
                    max_total_size=runtime.max_total_size,
                    strict_license=runtime.strict_license,
                    skip_file_types=runtime.skip_non_model_files,
                    use_hf_whitelist=runtime.use_hf_whitelist,
                    cache_enabled=runtime.cache_enabled,
                    cache_dir=runtime.cache_dir,
                    **streaming_kwargs,
                )
                audit_result.aggregate_scan_result(streaming_result.model_dump())
                path_state.track_streaming_paths_for_sbom(streaming_result, path)

                download_duration = time.time() - download_start
                record_download_completed("huggingface", download_duration, 0, display_path)

                if runtime.show_styled_output:
                    click.echo(style_text("✅ Streaming scan complete", fg="green", bold=True))

                return _SourceDispatchResult(
                    actual_path=path,
                    local_scan_required=False,
                    temp_path=temp_dir,
                    source_model_id=source_model_id,
                    source_model_source=source_model_source,
                )

            download_spinner = None
            if runtime.show_styled_output and should_show_spinner():
                download_spinner = yaspin(Spinners.dots, text="Downloading model files...")
                download_spinner.start()

            show_progress = runtime.show_styled_output and should_show_spinner()
            download_path = download_model(path, cache_dir=hf_cache_dir, show_progress=show_progress)
            download_duration = time.time() - download_start
            try:
                download_size = sum(
                    file_path.stat().st_size for file_path in Path(download_path).rglob("*") if file_path.is_file()
                )
                record_download_completed("huggingface", download_duration, download_size, display_path)
            except Exception:
                record_download_completed("huggingface", download_duration, 0, display_path)

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo(style_text("✅ Download complete", fg="green", bold=True))

            return _SourceDispatchResult(
                actual_path=str(download_path),
                temp_path=temp_dir,
                source_model_id=source_model_id,
                source_model_source=source_model_source,
            )
        except Exception as exc:
            if runtime.show_styled_output:
                click.echo(style_text("❌ Download/scan failed", fg="red", bold=True))

            error_msg = redact_huggingface_urls_in_text(str(exc))
            if "insufficient disk space" in error_msg.lower():
                logger.error(f"Disk space error for {display_path}: {error_msg}")
                click.echo(style_text(f"\n⚠️  {error_msg}", fg="yellow"), err=True)
                click.echo(
                    style_text(
                        "💡 Tip: Use --stream to minimize disk usage, or use "
                        "--cache-dir to specify a directory with more space",
                        fg="cyan",
                    ),
                    err=True,
                )
            else:
                logger.error(f"Failed to process model from {display_path}: {error_msg}", exc_info=verbose)
                click.echo(f"Error processing model from {display_path}: {error_msg}", err=True)

            audit_result.has_errors = True
            path_state.defer_temp_cleanup(
                temp_dir,
                cache_enabled=runtime.cache_enabled,
                verbose=verbose,
            )
            return None

    if is_pytorch_hub_url(path):
        download_spinner = None
        try:
            record_download_started("pytorch_hub", path)
            record_feature_used("pytorch_hub_download", cache_enabled=runtime.cache_enabled)
            download_start = time.time()

            if runtime.scan_and_delete:
                from .core import scan_model_streaming
                from .utils.sources.pytorch_hub import download_pytorch_hub_model_streaming

                if runtime.show_styled_output:
                    click.echo(style_text("🔄 Starting streaming scan...", fg="cyan"))

                file_generator = download_pytorch_hub_model_streaming(
                    path,
                    show_progress=runtime.show_progress,
                )
                streaming_result = scan_model_streaming(
                    file_generator=file_generator,
                    timeout=runtime.timeout,
                    delete_after_scan=True,
                    blacklist_patterns=list(blacklist) if blacklist else None,
                    max_file_size=runtime.max_file_size,
                    max_total_size=runtime.max_total_size,
                    strict_license=runtime.strict_license,
                    skip_file_types=runtime.skip_non_model_files,
                    use_hf_whitelist=runtime.use_hf_whitelist,
                    cache_enabled=runtime.cache_enabled,
                    cache_dir=runtime.cache_dir,
                    **_scanner_selection_overrides(runtime),
                )
                path_state.track_streaming_paths_for_sbom(streaming_result, path)
                audit_result.aggregate_scan_result(streaming_result.model_dump())
                record_download_completed("pytorch_hub", time.time() - download_start, 0, path)

                if runtime.show_styled_output:
                    click.echo(style_text("✅ Streaming scan complete", fg="green", bold=True))

                return _SourceDispatchResult(actual_path=path, local_scan_required=False)

            if runtime.show_styled_output and should_show_spinner():
                spinner_text = f"Downloading from {style_text(path, fg='cyan')}"
                download_spinner = yaspin(Spinners.dots, text=spinner_text)
                download_spinner.start()
            elif runtime.show_styled_output:
                click.echo(f"Downloading from {path}...")

            download_path = download_pytorch_hub_model(
                path,
                cache_dir=Path(runtime.cache_dir) if runtime.cache_dir else None,
            )
            download_duration = time.time() - download_start
            try:
                download_size = sum(
                    file_path.stat().st_size for file_path in Path(download_path).rglob("*") if file_path.is_file()
                )
                record_download_completed("pytorch_hub", download_duration, download_size, path)
            except Exception:
                record_download_completed("pytorch_hub", download_duration, 0, path)

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo("Downloaded successfully")

            return _SourceDispatchResult(actual_path=str(download_path), temp_path=str(download_path))
        except Exception as exc:
            if download_spinner:
                download_spinner.fail(style_text("❌ Download failed", fg="red", bold=True))
            elif runtime.show_styled_output:
                click.echo("Download failed")

            error_msg = str(exc)
            if "insufficient disk space" in error_msg.lower():
                logger.error(f"Disk space error for {path}: {error_msg}")
                click.echo(style_text(f"\n⚠️  {error_msg}", fg="yellow"), err=True)
                click.echo(
                    style_text(
                        "💡 Tip: Free up disk space or use --cache-dir to specify a directory with more space",
                        fg="cyan",
                    ),
                    err=True,
                )
            else:
                logger.error(f"Failed to download model from {path}: {error_msg}", exc_info=verbose)
                click.echo(f"Error downloading model from {path}: {error_msg}", err=True)

            audit_result.has_errors = True
            return None

    if is_cloud_url(path):
        if dry_run:
            import asyncio

            from .utils.sources.cloud_storage import analyze_cloud_target

            try:
                metadata = asyncio.run(analyze_cloud_target(path))
                click.echo(f"\n📊 Preview for {style_text(redact_url_for_display(path), fg='cyan')}:")
                click.echo(f"   Type: {metadata['type']}")

                if metadata["type"] == "file":
                    click.echo(f"   Size: {metadata.get('human_size', 'unknown')}")
                    click.echo(f"   Estimated download time: {metadata.get('estimated_time', 'unknown')}")
                elif metadata["type"] == "directory":
                    click.echo(f"   Files: {metadata.get('file_count', 0)}")
                    click.echo(f"   Total size: {metadata.get('human_size', 'unknown')}")
                    click.echo(f"   Estimated download time: {metadata.get('estimated_time', 'unknown')}")

                    if runtime.selective_download:
                        from .utils.sources.cloud_storage import filter_scannable_files

                        scannable = filter_scannable_files(
                            metadata.get("files", []),
                            scannable_extensions=runtime.scannable_extensions,
                        )
                        click.echo(f"   Scannable files: {len(scannable)} of {metadata.get('file_count', 0)}")

                return _SourceDispatchResult(actual_path=path, local_scan_required=False)
            except Exception as exc:
                click.echo(f"Error analyzing {redact_url_for_display(path)}: {exc!s}", err=True)
                audit_result.has_errors = True
                return None

        download_spinner = None
        try:
            record_download_started("cloud_storage", path)
            record_feature_used("cloud_storage_download", cache_enabled=runtime.cache_enabled)
            download_start = time.time()

            if runtime.scan_and_delete:
                from .core import scan_model_streaming
                from .utils.sources.cloud_storage import download_from_cloud_streaming

                if runtime.show_styled_output:
                    click.echo(style_text("🔄 Starting streaming scan from cloud storage...", fg="cyan"))

                cloud_stream_kwargs: dict[str, Any] = {}
                if runtime.scannable_extensions is not None:
                    cloud_stream_kwargs["scannable_extensions"] = runtime.scannable_extensions
                file_generator = download_from_cloud_streaming(
                    path,
                    cache_dir=Path(runtime.cache_dir) if runtime.cache_dir else None,
                    max_size=runtime.max_download_bytes,
                    show_progress=runtime.show_progress,
                    selective=runtime.selective_download,
                    **cloud_stream_kwargs,
                )
                streaming_result = scan_model_streaming(
                    file_generator=file_generator,
                    timeout=runtime.timeout,
                    delete_after_scan=True,
                    blacklist_patterns=list(blacklist) if blacklist else None,
                    max_file_size=runtime.max_file_size,
                    max_total_size=runtime.max_total_size,
                    strict_license=runtime.strict_license,
                    skip_file_types=runtime.skip_non_model_files,
                    use_hf_whitelist=runtime.use_hf_whitelist,
                    cache_enabled=runtime.cache_enabled,
                    cache_dir=runtime.cache_dir,
                    **_scanner_selection_overrides(runtime),
                )
                path_state.track_streaming_paths_for_sbom(streaming_result, path)
                audit_result.aggregate_scan_result(streaming_result.model_dump())
                record_download_completed("cloud_storage", time.time() - download_start, 0, path)

                if runtime.show_styled_output:
                    click.echo(style_text("✅ Streaming scan complete", fg="green", bold=True))

                return _SourceDispatchResult(actual_path=path, local_scan_required=False)

            if runtime.show_styled_output and should_show_spinner():
                spinner_text = f"Downloading from {style_text(redact_url_for_display(path), fg='cyan')}"
                download_spinner = yaspin(Spinners.dots, text=spinner_text)
                download_spinner.start()
            elif runtime.show_styled_output:
                click.echo(f"Downloading from {redact_url_for_display(path)}...")

            cloud_download_kwargs: dict[str, Any] = {}
            if runtime.scannable_extensions is not None:
                cloud_download_kwargs["scannable_extensions"] = runtime.scannable_extensions
            download_path = download_from_cloud(  # type: ignore[assignment]
                path,
                cache_dir=Path(runtime.cache_dir) if runtime.cache_dir else None,
                max_size=runtime.max_download_bytes,
                use_cache=runtime.cache_enabled,
                show_progress=verbose,
                selective=runtime.selective_download,
                stream_analyze=runtime.stream_analysis,
                **cloud_download_kwargs,
            )
            download_duration = time.time() - download_start
            try:
                download_size = sum(
                    file_path.stat().st_size for file_path in Path(download_path).rglob("*") if file_path.is_file()
                )
                record_download_completed("cloud_storage", download_duration, download_size, path)
            except Exception:
                record_download_completed("cloud_storage", download_duration, 0, path)

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo("Downloaded successfully")

            return _SourceDispatchResult(
                actual_path=str(download_path),
                temp_path=str(download_path) if not runtime.cache_enabled else None,
            )
        except Exception as exc:
            if download_spinner:
                download_spinner.fail(style_text("❌ Download failed", fg="red", bold=True))
            elif runtime.show_styled_output:
                click.echo("Download failed")

            error_msg = _display_error(exc, path)
            if "insufficient disk space" in error_msg.lower():
                logger.error(f"Disk space error for {redact_url_for_display(path)}: {error_msg}")
                click.echo(style_text(f"\n⚠️  {error_msg}", fg="yellow"), err=True)
                click.echo(
                    style_text(
                        "💡 Tip: Free up disk space or use --cache-dir to specify a directory with more space",
                        fg="cyan",
                    ),
                    err=True,
                )
            else:
                logger.error(f"Failed to download from {redact_url_for_display(path)}: {error_msg}", exc_info=verbose)
                click.echo(f"Error downloading from {redact_url_for_display(path)}: {error_msg}", err=True)

            audit_result.has_errors = True
            return None

    if is_mlflow_uri(path):
        download_spinner = None
        if runtime.show_styled_output and should_show_spinner():
            download_spinner = yaspin(Spinners.dots, text=f"Downloading from {style_text(path, fg='cyan')}")
            download_spinner.start()
        elif runtime.show_styled_output:
            click.echo(f"Downloading from {path}...")

        try:
            record_download_started("mlflow", path)
            record_feature_used("mlflow_download")
            download_start = time.time()

            from .integrations.mlflow import scan_mlflow_model

            results: ModelAuditResultModel = scan_mlflow_model(
                path,
                registry_uri=runtime.mlflow_registry_uri,
                timeout=runtime.timeout,
                blacklist_patterns=list(blacklist) if blacklist else None,
                max_file_size=runtime.max_file_size,
                max_total_size=runtime.max_total_size,
                cache_enabled=runtime.cache_enabled,
                cache_dir=runtime.cache_dir,
                use_hf_whitelist=runtime.use_hf_whitelist,
                **_scanner_selection_overrides(runtime),
            )

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded & Scanned", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo("Downloaded and scanned successfully")

            audit_result.aggregate_scan_result(results.model_dump())
            record_download_completed("mlflow", time.time() - download_start, results.bytes_scanned, path)
            return _SourceDispatchResult(actual_path=path, local_scan_required=False)
        except Exception as exc:
            if download_spinner:
                download_spinner.fail(style_text("❌ Download failed", fg="red", bold=True))
            elif runtime.show_styled_output:
                click.echo("Download failed")

            logger.error(f"Failed to download model from {path}: {exc!s}", exc_info=verbose)
            click.echo(f"Error downloading model from {path}: {exc!s}", err=True)
            audit_result.has_errors = True
            return None

    if is_jfrog_url(path):
        display_path = redact_jfrog_url_for_display(path)
        download_spinner = None
        if runtime.show_styled_output and should_show_spinner():
            download_spinner = yaspin(
                Spinners.dots,
                text=f"Downloading and scanning from {style_text(display_path, fg='cyan')}",
            )
            download_spinner.start()
        elif runtime.show_styled_output:
            click.echo(f"Downloading and scanning from {display_path}...")

        try:
            record_download_started("jfrog", path)
            record_feature_used("jfrog_download")
            download_start = time.time()

            jfrog_scan_kwargs: dict[str, Any] = {}
            if runtime.scannable_extensions is not None:
                jfrog_scan_kwargs["scannable_extensions"] = runtime.scannable_extensions
            jfrog_results: ModelAuditResultModel = scan_jfrog_artifact(
                path,
                api_token=runtime.jfrog_api_token,
                access_token=runtime.jfrog_access_token,
                timeout=runtime.timeout,
                blacklist_patterns=list(blacklist) if blacklist else None,
                max_file_size=runtime.max_file_size,
                max_total_size=runtime.max_total_size,
                strict_license=runtime.strict_license,
                skip_file_types=runtime.skip_non_model_files,
                cache_enabled=runtime.cache_enabled,
                cache_dir=runtime.cache_dir,
                selective_download=runtime.selective_download,
                use_hf_whitelist=runtime.use_hf_whitelist,
                **jfrog_scan_kwargs,
                **_scanner_selection_overrides(runtime),
            )

            if download_spinner:
                download_spinner.ok(style_text("✅ Downloaded and scanned", fg="green", bold=True))
            elif runtime.show_styled_output:
                click.echo("Downloaded and scanned successfully")

            audit_result.aggregate_scan_result(jfrog_results.model_dump())
            record_download_completed("jfrog", time.time() - download_start, jfrog_results.bytes_scanned, path)
            return _SourceDispatchResult(actual_path=path, local_scan_required=False)
        except Exception as exc:
            if download_spinner:
                download_spinner.fail(style_text("❌ Download/scan failed", fg="red", bold=True))
            elif runtime.show_styled_output:
                click.echo("Download/scan failed")

            error_msg = redact_jfrog_error_for_display(exc, path)
            logger.error(f"Failed to download/scan model from {display_path}: {error_msg}", exc_info=verbose)
            click.echo(f"Error downloading/scanning model from {display_path}: {error_msg}", err=True)
            audit_result.has_errors = True
            return None

    if not os.path.exists(path):
        click.echo(f"Error: Path does not exist: {path}", err=True)
        audit_result.has_errors = True
        return None

    return _SourceDispatchResult(actual_path=path)


class DefaultCommandGroup(click.Group):
    """Custom group that makes 'scan' the default command"""

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        """Get command by name, return None if not found"""
        # Simply delegate to parent's get_command - no default logic here
        return click.Group.get_command(self, ctx, cmd_name)

    def resolve_command(  # type: ignore[override]
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str | None, click.Command | None, list[str]]:
        """Resolve command, using 'scan' as default when paths are provided"""
        # If we have args and the first arg is not a known command, use 'scan' as default
        if args and args[0] not in self.list_commands(ctx):
            # Insert 'scan' at the beginning
            args = ["scan", *list(args)]

        return super().resolve_command(ctx, args)

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Show help with both commands but emphasize scan as primary"""
        formatter.write_text("ModelAudit - Security scanner for ML model files")
        formatter.write_paragraph()

        formatter.write_text("Usage:")
        with formatter.indentation():
            formatter.write_text("modelaudit [OPTIONS] PATHS...  # Scan files (default command)")
            formatter.write_text("modelaudit scan [OPTIONS] PATHS...  # Explicit scan command")

        formatter.write_paragraph()
        formatter.write_text("Examples:")
        with formatter.indentation():
            formatter.write_text("modelaudit model.pkl")
            formatter.write_text("modelaudit /path/to/models/")
            formatter.write_text("modelaudit https://huggingface.co/user/model")
            formatter.write_text("modelaudit https://pytorch.org/hub/pytorch_vision_resnet/")

        formatter.write_paragraph()
        formatter.write_text("Other commands:")
        with formatter.indentation():
            formatter.write_text("modelaudit doctor       # Diagnose scanner compatibility")
            formatter.write_text("modelaudit cache clear  # Clear scan results cache")
            formatter.write_text("modelaudit cache stats  # Show cache statistics")

        formatter.write_paragraph()
        formatter.write_text("For detailed help on scanning:")
        with formatter.indentation():
            formatter.write_text("modelaudit scan --help")

        formatter.write_paragraph()
        formatter.write_text("Options:")
        self.format_options(ctx, formatter)


@click.group(cls=DefaultCommandGroup)
@click.version_option(__version__)
def cli() -> None:
    """Static scanner for ML models"""


@cli.group()
def auth() -> None:
    """Manage authentication"""


@auth.command()
@click.option("-o", "--org", "org_id", help="The organization id to login to.")
@click.option(
    "-h",
    "--host",
    help="The host of the promptfoo instance. This needs to be the url of the API if different from the app url.",
)
@click.option("-k", "--api-key", help="Login using an API key.")
def login(org_id: str | None, host: str | None, api_key: str | None) -> None:
    """Login"""
    import time

    start_time = time.time()
    try:
        token = None
        api_host = host or cloud_config.get_api_host()

        # Record telemetry (stub for now)
        # telemetry.record('command_used', {'name': 'auth login'})

        if api_key:
            token = api_key
            result = auth_client.validate_and_set_api_token(token, api_host)
            user = result["user"]

            # Store token in global config and handle email sync
            existing_email = get_user_email()
            if existing_email and existing_email != user.email:
                click.echo(
                    style_text(f"Updating local email configuration from {existing_email} to {user.email}", fg="yellow")
                )
            set_user_email(user.email)
            record_command_used("auth_login", duration=time.time() - start_time, success=True, api_key_login=True)
            click.echo(style_text("Successfully logged in", fg="green"))
            return
        else:
            click.echo(
                f"Please login or sign up at {style_text('https://promptfoo.app', fg='green')} to get an API key."
            )
            click.echo(
                f"After logging in, you can get your api token at "
                f"{style_text('https://promptfoo.app/welcome', fg='green')}"
            )
            record_command_used("auth_login", duration=time.time() - start_time, success=False, api_key_login=False)

        return

    except Exception as error:
        error_message = str(error)
        record_command_used(
            "auth_login",
            duration=time.time() - start_time,
            success=False,
            error_type=type(error).__name__,
        )
        click.echo(f"Authentication failed: {error_message}", err=True)
        sys.exit(1)


@auth.command()
def logout() -> None:
    """Logout"""
    import time

    start_time = time.time()
    email = get_user_email()
    api_key = cloud_config.get_api_key()

    if not email and not api_key:
        record_command_used("auth_logout", duration=time.time() - start_time, success=True, was_logged_in=False)
        click.echo(style_text("You're already logged out - no active session to terminate", fg="yellow"))
        return

    cloud_config.delete()
    # Always unset email on logout
    set_user_email("")
    record_command_used("auth_logout", duration=time.time() - start_time, success=True, was_logged_in=True)
    click.echo(style_text("Successfully logged out", fg="green"))
    return


@auth.command()
def whoami() -> None:
    """Show current user information"""
    import time

    start_time = time.time()
    try:
        email = get_user_email()
        api_key = cloud_config.get_api_key()

        if not email or not api_key:
            record_command_used("auth_whoami", duration=time.time() - start_time, success=False, logged_in=False)
            click.echo(f"Not logged in. Run {style_text('modelaudit auth login', bold=True)} to login.")
            return

        user_info = auth_client.get_user_info()
        user = user_info.get("user", {})
        organization = user_info.get("organization", {})

        click.echo(style_text("Currently logged in as:", fg="green", bold=True))
        click.echo(f"User: {style_text(user.get('email', 'Unknown'), fg='cyan')}")
        click.echo(f"Organization: {style_text(organization.get('name', 'Unknown'), fg='cyan')}")
        click.echo(f"App URL: {style_text(cloud_config.get_app_url(), fg='cyan')}")

        # Record telemetry (stub for now)
        # telemetry.record('command_used', {'name': 'auth whoami'})
        record_command_used("auth_whoami", duration=time.time() - start_time, success=True, logged_in=True)

    except Exception as error:
        error_message = str(error)
        record_command_used(
            "auth_whoami",
            duration=time.time() - start_time,
            success=False,
            error_type=type(error).__name__,
        )
        click.echo(f"Failed to get user info: {error_message}", err=True)
        sys.exit(1)


@cli.group()
def cache() -> None:
    """Manage scan results cache"""


@cache.command()
@click.option("--cache-dir", type=click.Path(), help="Cache directory path [default: ~/.modelaudit/cache/scan_results]")
@click.option("--dry-run", is_flag=True, help="Show what would be cleared without actually clearing")
def clear(cache_dir: str | None, dry_run: bool) -> None:
    """Clear the entire scan results cache"""
    import time

    start_time = time.time()
    from .cache import get_cache_manager

    try:
        cache_manager = get_cache_manager(cache_dir, enabled=True)

        if dry_run:
            stats = cache_manager.get_stats()
            total_entries = stats.get("total_entries", 0)
            total_size_mb = stats.get("total_size_mb", 0.0)

            record_command_used(
                "cache_clear",
                duration=time.time() - start_time,
                success=True,
                dry_run=True,
                entries=total_entries,
            )
            click.echo(f"Would clear {total_entries} cache entries ({total_size_mb:.1f}MB)")
            return

        # Get stats before clearing for reporting
        stats = cache_manager.get_stats()
        total_entries = stats.get("total_entries", 0)
        total_size_mb = stats.get("total_size_mb", 0.0)

        # Clear the cache
        try:
            cache_manager.clear()
            success_msg = f"Cleared {total_entries} cache entries ({total_size_mb:.1f}MB)"
            record_command_used(
                "cache_clear",
                duration=time.time() - start_time,
                success=True,
                dry_run=False,
                entries=total_entries,
            )
            click.echo(style_text(success_msg, fg="green"))
        except PermissionError as e:
            error_msg = f"Permission denied while clearing cache: {e}"
            record_command_used(
                "cache_clear",
                duration=time.time() - start_time,
                success=False,
                dry_run=False,
                error_type=type(e).__name__,
            )
            click.echo(style_text(error_msg, fg="red"), err=True)
            click.echo("Try running with elevated permissions or check cache directory permissions.", err=True)
            sys.exit(1)
        except OSError as e:
            error_msg = f"File system error while clearing cache: {e}"
            record_command_used(
                "cache_clear",
                duration=time.time() - start_time,
                success=False,
                dry_run=False,
                error_type=type(e).__name__,
            )
            click.echo(style_text(error_msg, fg="red"), err=True)
            sys.exit(1)

    except Exception as e:
        error_msg = f"Failed to clear cache: {e}"
        record_command_used(
            "cache_clear",
            duration=time.time() - start_time,
            success=False,
            dry_run=dry_run,
            error_type=type(e).__name__,
        )
        click.echo(style_text(error_msg, fg="red"), err=True)
        sys.exit(1)


@cache.command()
@click.option("--cache-dir", type=click.Path(), help="Cache directory path [default: ~/.modelaudit/cache/scan_results]")
@click.option("--max-age", type=int, default=30, help="Maximum age of entries to keep in days [default: 30]")
@click.option("--dry-run", is_flag=True, help="Show what would be cleaned without actually cleaning")
def cleanup(cache_dir: str | None, max_age: int, dry_run: bool) -> None:
    """Clean up old cache entries"""
    import time

    start_time = time.time()
    from .cache import get_cache_manager

    try:
        cache_manager = get_cache_manager(cache_dir, enabled=True)

        if dry_run:
            # For dry run, we'd need to implement a preview method
            # For now, just show current stats
            stats = cache_manager.get_stats()
            total_entries = stats.get("total_entries", 0)
            total_size_mb = stats.get("total_size_mb", 0.0)

            record_command_used(
                "cache_cleanup",
                duration=time.time() - start_time,
                success=True,
                dry_run=True,
                max_age=max_age,
                entries=total_entries,
            )
            click.echo(f"Would cleanup cache entries older than {max_age} days")
            click.echo(f"Current cache: {total_entries} entries ({total_size_mb:.1f}MB)")
            return

        # Clean up old entries
        removed_count = cache_manager.cleanup(max_age)
        record_command_used(
            "cache_cleanup",
            duration=time.time() - start_time,
            success=True,
            dry_run=False,
            max_age=max_age,
            removed_count=removed_count,
        )

        if removed_count > 0:
            success_msg = f"Removed {removed_count} old cache entries (>{max_age} days old)"
            click.echo(style_text(success_msg, fg="green"))
        else:
            click.echo("No old cache entries found to remove")

    except Exception as e:
        error_msg = f"Failed to cleanup cache: {e}"
        record_command_used(
            "cache_cleanup",
            duration=time.time() - start_time,
            success=False,
            dry_run=dry_run,
            max_age=max_age,
            error_type=type(e).__name__,
        )
        click.echo(style_text(error_msg, fg="red"), err=True)
        sys.exit(1)


@cache.command()
@click.option("--cache-dir", type=click.Path(), help="Cache directory path [default: ~/.modelaudit/cache/scan_results]")
def stats(cache_dir: str | None) -> None:
    """Show cache statistics"""
    import time

    start_time = time.time()
    from .cache import get_cache_manager

    try:
        cache_manager = get_cache_manager(cache_dir, enabled=True)
        stats = cache_manager.get_stats()

        click.echo("Cache Statistics")
        click.echo("=" * 20)

        enabled = stats.get("enabled", False)
        if not enabled:
            record_command_used("cache_stats", duration=time.time() - start_time, success=True, enabled=False)
            click.echo(style_text("Cache is disabled", fg="yellow"))
            return

        total_entries = stats.get("total_entries", 0)
        total_size_mb = stats.get("total_size_mb", 0.0)
        cache_hits = stats.get("cache_hits", 0)
        cache_misses = stats.get("cache_misses", 0)
        hit_rate = stats.get("hit_rate", 0.0)

        click.echo(f"Total entries: {total_entries}")
        click.echo(f"Total size: {total_size_mb:.1f}MB")
        click.echo(f"Cache hits: {cache_hits}")
        click.echo(f"Cache misses: {cache_misses}")
        click.echo(f"Hit rate: {hit_rate:.1%}")

        if total_entries > 0:
            avg_size_kb = (total_size_mb * 1024) / total_entries
            click.echo(f"Average entry size: {avg_size_kb:.1f}KB")

        record_command_used(
            "cache_stats",
            duration=time.time() - start_time,
            success=True,
            enabled=True,
            entries=total_entries,
        )

    except Exception as e:
        error_msg = f"Failed to get cache stats: {e}"
        record_command_used(
            "cache_stats", duration=time.time() - start_time, success=False, error_type=type(e).__name__
        )
        click.echo(style_text(error_msg, fg="red"), err=True)
        sys.exit(1)


@cli.command("delegate-info", hidden=True)
def delegate_info() -> None:
    """Internal command to show delegation status"""

    from .auth.config import config

    is_delegated = config.is_delegated()
    auth_source = config.get_auth_source()
    api_key_available = config.is_authenticated()

    info = {"delegated": is_delegated, "auth_source": auth_source, "api_key_available": api_key_available}

    click.echo(json.dumps(info, indent=2))


@cli.command("scan")
@click.argument("paths", nargs=-1, type=str, required=False)
# Core output control (4 flags)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["text", "json", "sarif"]),
    help="Output format (text, json, or sarif) [default: auto-detected]",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path (prints to stdout if not specified)",
)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option("--quiet", "-q", is_flag=True, help="Silence detection messages")
# Security behavior (2 flags)
@click.option(
    "--blacklist",
    "-b",
    multiple=True,
    help="Additional blacklist patterns to check against model names",
)
@click.option(
    "--strict",
    is_flag=True,
    help="Strict mode: imply --no-whitelist and --no-cache, scan all file types, strict license validation",
)
@click.option(
    "--no-whitelist",
    is_flag=True,
    help="Disable HuggingFace whitelist severity downgrading",
)
@click.option(
    "--suppress",
    "-s",
    multiple=True,
    help="Suppress specific rule codes (e.g., -s S101). Can be specified multiple times.",
)
@click.option(
    "--severity",
    "-S",
    multiple=True,
    help="Override rule severities, format CODE=LEVEL (e.g., S101=CRITICAL). Can be specified multiple times.",
)
@click.option(
    "--scanners",
    multiple=True,
    help="Only run the selected scanners (comma-separated or repeat the flag). Accepts scanner IDs or class names.",
)
@click.option(
    "--exclude-scanner",
    "exclude_scanners",
    multiple=True,
    help="Exclude scanners from the active scanner set (comma-separated or repeat the flag).",
)
@click.option(
    "--list-scanners",
    is_flag=True,
    help="List registered scanner IDs, class names, extensions, and dependencies, then exit.",
)
# Progress & reporting (2 flags)
@click.option(
    "--progress",
    is_flag=True,
    help="Force enable progress reporting (auto-detected by default)",
)
@click.option(
    "--sbom",
    type=click.Path(),
    help="Write CycloneDX SBOM to the specified file",
)
# Override defaults (2 flags)
@click.option(
    "--timeout",
    "-t",
    type=int,
    help="Override auto-detected timeout in seconds",
)
@click.option(
    "--max-size",
    type=str,
    help="Override auto-detected size limits (e.g., 10GB, 500MB)",
)
# Preview/debugging (2 flags)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview what would be scanned/downloaded without actually doing it",
)
@click.option(
    "--no-cache",
    is_flag=True,
    help="Force disable caching (overrides defaults)",
)
@click.option(
    "--cache-dir",
    type=click.Path(),
    help="Cache directory path (overrides default cache location)",
)
@click.option(
    "--stream",
    is_flag=True,
    help="Stream scan: download files one-by-one, scan immediately, then delete to save disk space",
)
def scan_command(
    paths: tuple[str, ...],
    format: str | None,
    output: str | None,
    verbose: bool,
    quiet: bool,
    blacklist: tuple[str, ...],
    strict: bool,
    no_whitelist: bool,
    suppress: tuple[str, ...],
    severity: tuple[str, ...],
    scanners: tuple[str, ...],
    exclude_scanners: tuple[str, ...],
    list_scanners: bool,
    progress: bool,
    sbom: str | None,
    timeout: int | None,
    max_size: str | None,
    dry_run: bool,
    no_cache: bool,
    cache_dir: str | None,
    stream: bool,
) -> None:
    """Scan files, directories, HuggingFace models, MLflow models, cloud storage,
    or JFrog artifacts for security issues.

    Uses defaults based on input type.

    \b
    Examples:
        modelaudit scan model.pkl                    # Local file - fast scan
        modelaudit scan s3://bucket/models/          # Cloud - auto caching + progress
        modelaudit scan hf://user/llama              # HuggingFace - selective download
        modelaudit scan models:/model/v1             # MLflow - registry integration

        # Override defaults when needed
        modelaudit scan large-model.pt --max-size 20GB --timeout 7200

        # Strict mode for security-critical scans
        modelaudit scan model.pkl --strict --format json --output report.json

    \b
    Defaults:
        • Input type (local/cloud/registry) → optimal download & caching
        • File size (>1GB) → large model optimizations + progress bars
        • Terminal type (TTY/CI) → appropriate UI (progress vs quiet)
        • Cloud operations → automatic caching, size limits, timeouts

    \b
    Authentication:
        • JFrog: Set JFROG_API_TOKEN or JFROG_ACCESS_TOKEN environment variables
        • MLflow: Set MLFLOW_TRACKING_URI environment variable

    \b
    Exit codes:
        0 - Success, no security issues found
        1 - Security issues found (scan completed successfully)
        2 - Errors occurred during scanning
    """
    scan_start_time = time.time()
    if list_scanners:
        output_format = format or "text"
        _emit_scanner_catalog(output_format=output_format, output=output)
        record_command_used("scan", duration=time.time() - scan_start_time, list_scanners=True, format=output_format)
        flush_telemetry()
        return

    if not paths:
        click.echo("Error: Missing argument 'PATHS...'.", err=True)
        record_scan_failed(time.time() - scan_start_time, "No paths provided")
        flush_telemetry()
        sys.exit(2)

    # Telemetry options - only include non-sensitive data
    # DO NOT include actual blacklist patterns or file paths - only counts
    telemetry_options = {
        "format": format,
        "timeout": timeout,
        "max_file_size": max_size,
        "has_blacklist": bool(blacklist),
        "num_blacklist_patterns": len(blacklist) if blacklist else 0,
        "progress": progress,
        "has_output_file": bool(output),
        "has_sbom": bool(sbom),
        "verbose": verbose,
        "cache_enabled": not no_cache,
        "strict": strict,
        "no_whitelist": no_whitelist,
        "dry_run": dry_run,
        "has_scanner_selection": bool(scanners or exclude_scanners),
        "num_paths": len(paths),
    }

    record_command_used("scan", duration=None, **telemetry_options)
    record_scan_started(list(paths), telemetry_options)

    expanded_paths = _resolve_scan_paths(paths, scan_start_time)
    runtime = _resolve_scan_runtime_config(
        expanded_paths,
        format=format,
        output=output,
        timeout=timeout,
        max_size=max_size,
        cache_dir=cache_dir,
        progress=progress,
        no_cache=no_cache,
        no_whitelist=no_whitelist,
        stream=stream,
        strict=strict,
        verbose=verbose,
        quiet=quiet,
        scanners=scanners,
        exclude_scanners=exclude_scanners,
        suppress=suppress,
        severity=severity,
        scan_start_time=scan_start_time,
    )
    _show_scan_runtime_defaults(
        runtime,
        expanded_paths,
        blacklist,
        quiet=quiet,
        verbose=verbose,
    )
    _configure_scan_logging(verbose)
    progress_tracker, progress_reporters = _initialize_progress_tracking(
        runtime,
        expanded_paths,
        output=output,
        verbose=verbose,
    )

    # Aggregated results using Pydantic model from the start
    from .models import create_initial_audit_result

    audit_result = create_initial_audit_result()
    if runtime.scanner_selection_metadata is not None:
        audit_result.scanner_selection = dict(runtime.scanner_selection_metadata)
    path_state = _ScanPathState()

    # Scan each path with interrupt handling
    with interruptible_scan() as interrupt_handler:
        for path in expanded_paths:
            source_result = _SourceDispatchResult(actual_path=path)
            should_break = False

            try:
                resolved_source = _resolve_scan_source_for_path(
                    path,
                    audit_result,
                    path_state,
                    runtime,
                    blacklist,
                    verbose=verbose,
                    dry_run=dry_run,
                )
                if resolved_source is None:
                    continue

                source_result = resolved_source
                if source_result.local_scan_required:
                    _scan_local_or_downloaded_path(
                        path,
                        source_result,
                        audit_result,
                        path_state,
                        runtime,
                        progress_tracker,
                        blacklist,
                        verbose=verbose,
                    )

            except Exception as exc:
                logger.error(f"Unexpected error processing {path}: {exc!s}", exc_info=verbose)
                click.echo(f"Unexpected error processing {path}: {exc!s}", err=True)
                path_state.scanned_paths.append(source_result.actual_path)
                audit_result.has_errors = True

                if progress_tracker:
                    progress_tracker.report_error(exc)

            finally:
                path_state.defer_temp_cleanup(
                    source_result.temp_path,
                    cache_enabled=runtime.cache_enabled,
                    verbose=verbose,
                )

                if interrupt_handler.is_interrupted():
                    logger.debug("Scan interrupted by user")
                    if not any(issue.message == "Scan interrupted by user" for issue in audit_result.issues):
                        from .scanner_results import Issue

                        interruption_issue = Issue(
                            message="Scan interrupted by user",
                            severity=IssueSeverity.INFO,
                            location=None,
                            details={"interrupted": True},
                            timestamp=time.time(),
                            why=None,
                            type=None,
                        )
                        audit_result.issues.append(interruption_issue)
                    should_break = True

            if should_break:
                break

    _complete_progress_tracking(progress_tracker, verbose=verbose)
    _cleanup_progress_reporters(progress_reporters)
    audit_result.finalize_statistics()
    audit_result.deduplicate_issues()

    _write_scan_sbom(
        sbom,
        audit_result,
        expanded_paths,
        path_state,
        scan_and_delete=runtime.scan_and_delete,
    )
    _cleanup_temp_artifacts(path_state.temp_cleanup_entries, verbose=verbose)

    suppressions = _record_suppressed_preferred_scanners(audit_result)
    if suppressions:
        _announce_suppressed_preferred_scanners(suppressions)
    output_text = _format_scan_output(
        audit_result,
        expanded_paths,
        output_format=runtime.output_format,
        verbose=verbose,
    )
    _emit_scan_output(
        output_text,
        audit_result,
        output=output,
        output_format=runtime.output_format,
        verbose=verbose,
    )
    _record_scan_end_and_exit(audit_result, scan_start_time)


def format_text_output(results: dict[str, Any], verbose: bool = False) -> str:
    """Format scan results as human-readable text with colors"""
    output_lines = []

    # Add scan summary header
    output_lines.append(style_text("\n📊 SCAN SUMMARY", fg="white", bold=True))
    output_lines.append("" + "─" * 60)

    # Add scan metrics in a grid format
    metrics = []

    # Scanner info
    if results.get("scanner_names"):
        scanner_names = results["scanner_names"]
        if len(scanner_names) == 1:
            metrics.append(("Scanner", scanner_names[0], "blue"))
        else:
            metrics.append(("Scanners", ", ".join(scanner_names), "blue"))

    # Duration
    if "duration" in results:
        duration = results["duration"]
        duration_str = f"{duration:.3f}s" if duration < 0.01 else f"{duration:.2f}s"
        metrics.append(("Duration", duration_str, "cyan"))

    # Files scanned
    if "files_scanned" in results:
        metrics.append(("Files", str(results["files_scanned"]), "cyan"))

    # Data size
    if "bytes_scanned" in results:
        bytes_scanned = results["bytes_scanned"]
        if bytes_scanned >= 1024 * 1024 * 1024:
            size_str = f"{bytes_scanned / (1024 * 1024 * 1024):.2f} GB"
        elif bytes_scanned >= 1024 * 1024:
            size_str = f"{bytes_scanned / (1024 * 1024):.2f} MB"
        elif bytes_scanned >= 1024:
            size_str = f"{bytes_scanned / 1024:.2f} KB"
        else:
            size_str = f"{bytes_scanned} bytes"
        metrics.append(("Size", size_str, "cyan"))

    # Display metrics in a formatted grid
    for label, value, color in metrics:
        label_str = style_text(f"  {label}:", fg="bright_black")
        value_str = style_text(value, fg=color, bold=True)
        output_lines.append(f"{label_str} {value_str}")

    # Add authentication status (inspired by semgrep's approach)
    from .scanners import _registry

    available_scanners = _registry.get_available_scanners()
    total_scanners = len(_registry.get_scanner_classes())  # Total possible scanners
    authenticated = config.is_authenticated()

    if authenticated:
        auth_label = style_text("  Promptfoo Cloud:", fg="bright_black")
        auth_value = style_text("Logged in", fg="green", bold=True)
        output_lines.append(f"{auth_label} {auth_value}")
        # Show enhanced scanner count for authenticated users
        scanner_label = style_text("  Enhanced Scanners:", fg="bright_black")
        scanner_value = style_text(f"{len(available_scanners)}/{total_scanners}", fg="green", bold=True)
        output_lines.append(f"{scanner_label} {scanner_value}")
    else:
        auth_label = style_text("  Promptfoo Cloud:", fg="bright_black")
        auth_value = style_text("Not logged in", fg="yellow", bold=True)
        output_lines.append(f"{auth_label} {auth_value}")
        # Show limited scanner info for unauthenticated users
        scanner_label = style_text("  Basic Scanners:", fg="bright_black")
        scanner_value = style_text(f"{len(available_scanners)}/{total_scanners}", fg="yellow", bold=True)
        output_lines.append(f"{scanner_label} {scanner_value}")

        # Add gentle encouragement to login (only if we have failures or limited functionality)
        if len(available_scanners) < total_scanners:
            output_lines.append("")
            tip_icon = "💡"
            tip_text = "Login for enhanced scanning with cloud models and fewer false positives"
            login_cmd = style_text("modelaudit auth login", fg="cyan", bold=True)
            output_lines.append(f"  {tip_icon} {tip_text}")
            output_lines.append(f"     Run {login_cmd} to get started")

    # Add model information if available
    if "file_metadata" in results:
        for _file_path, metadata in results["file_metadata"].items():
            if metadata.get("model_info"):
                model_info = metadata["model_info"]
                output_lines.append("")
                output_lines.append(style_text("  Model Information:", fg="bright_black"))

                if "model_type" in model_info:
                    output_lines.append(f"  • Type: {style_text(model_info['model_type'], fg='cyan')}")
                if "architectures" in model_info:
                    arch_str = (
                        ", ".join(model_info["architectures"])
                        if isinstance(model_info["architectures"], list)
                        else model_info["architectures"]
                    )
                    output_lines.append(f"  • Architecture: {style_text(arch_str, fg='cyan')}")
                if "num_layers" in model_info:
                    output_lines.append(f"  • Layers: {style_text(str(model_info['num_layers']), fg='cyan')}")
                if "hidden_size" in model_info:
                    output_lines.append(f"  • Hidden Size: {style_text(str(model_info['hidden_size']), fg='cyan')}")
                if "vocab_size" in model_info:
                    vocab_str = f"{model_info['vocab_size']:,}"
                    output_lines.append(f"  • Vocab Size: {style_text(vocab_str, fg='cyan')}")
                if "framework_version" in model_info:
                    output_lines.append(f"  • Framework: {style_text(model_info['framework_version'], fg='cyan')}")
                break  # Only show the first model info found

    # Add security check statistics
    if "total_checks" in results and results["total_checks"] > 0:
        total = results["total_checks"]
        passed = results.get("passed_checks", 0)
        failed = results.get("failed_checks", 0)
        success_rate = (passed / total * 100) if total > 0 else 0

        output_lines.append("")
        output_lines.append(style_text("  Security Checks:", fg="bright_black"))

        # Show check counts with visual indicator
        check_str = f"  ✅ {passed} passed / "
        if failed > 0:
            check_str += style_text(f"❌ {failed} failed", fg="red")
        else:
            check_str += style_text(f"✅ {failed} failed", fg="green")
        check_str += f" (Total: {total})"
        output_lines.append(check_str)

        # Show success rate with color coding
        if success_rate >= 95:
            rate_color = "green"
            rate_icon = "✅"
        elif success_rate >= 80:
            rate_color = "yellow"
            rate_icon = "⚠️"
        else:
            rate_color = "red"
            rate_icon = "🚨"

        rate_str = style_text(f"  {rate_icon} Success Rate: {success_rate:.1f}%", fg=rate_color, bold=True)
        output_lines.append(rate_str)

    # Show failed checks if any exist
    failed_checks_list = [c for c in results.get("checks", []) if c.get("status") == "failed"]
    if failed_checks_list:
        output_lines.append("")
        output_lines.append(style_text("  Failed Checks (non-critical):", fg="yellow"))
        # Group failed checks by name to avoid repetition
        check_groups: dict[str, list[str]] = {}
        for check in failed_checks_list:
            check_name = check.get("name", "Unknown check")
            if check_name not in check_groups:
                check_groups[check_name] = []
            check_groups[check_name].append(check.get("message", ""))

        # Show unique failed check types
        for check_name, messages in list(check_groups.items())[:5]:  # Show first 5 types
            unique_msg = messages[0] if messages else ""
            if len(messages) > 1:
                output_lines.append(f"    • {check_name} ({len(messages)} occurrences)")
            else:
                output_lines.append(f"    • {check_name}: {unique_msg}")
        if len(check_groups) > 5:
            output_lines.append(f"    ... and {len(check_groups) - 5} more check types")

    # Add issue summary
    issues = results.get("issues", [])
    # Filter out DEBUG severity issues when not in verbose mode
    visible_issues = [issue for issue in issues if verbose or _get_issue_attr(issue, "severity") != "debug"]

    # Count issues by severity
    severity_counts = {
        "critical": 0,
        "warning": 0,
        "info": 0,
        "debug": 0,
    }

    for issue in issues:
        severity = _get_issue_attr(issue, "severity", "warning")
        if severity in severity_counts:
            severity_counts[severity] += 1

    # Display issue summary
    output_lines.append("")
    output_lines.append(style_text("\n🔍 SECURITY FINDINGS", fg="white", bold=True))
    output_lines.append("" + "─" * 60)

    if visible_issues:
        # Show issue counts with icons
        summary_parts = []
        if severity_counts["critical"] > 0:
            summary_parts.append(
                "  "
                + style_text(
                    f"🚨 {severity_counts['critical']} Critical",
                    fg="red",
                    bold=True,
                ),
            )
        if severity_counts["warning"] > 0:
            summary_parts.append(
                "  "
                + style_text(
                    f"⚠️  {severity_counts['warning']} Warning{'s' if severity_counts['warning'] > 1 else ''}",
                    fg="yellow",
                ),
            )
        if severity_counts["info"] > 0:
            summary_parts.append(
                "  " + style_text(f"[i] {severity_counts['info']} Info", fg="blue"),
            )
        if verbose and severity_counts["debug"] > 0:
            summary_parts.append(
                "  " + style_text(f"🐛 {severity_counts['debug']} Debug", fg="cyan"),
            )

        output_lines.extend(summary_parts)

        # Group issues by severity for better organization
        output_lines.append("")

        # Display critical issues first
        critical_issues = [issue for issue in visible_issues if _get_issue_attr(issue, "severity") == "critical"]
        if critical_issues:
            output_lines.append(
                style_text("  🚨 Critical Issues", fg="red", bold=True),
            )
            output_lines.append("  " + "─" * 40)
            for issue in critical_issues:
                _format_issue(issue, output_lines, "critical")
                output_lines.append("")

        # Display warnings
        warning_issues = [issue for issue in visible_issues if _get_issue_attr(issue, "severity") == "warning"]
        if warning_issues:
            if critical_issues:
                output_lines.append("")
            output_lines.append(style_text("  ⚠️  Warnings", fg="yellow", bold=True))
            output_lines.append("  " + "─" * 40)
            for issue in warning_issues:
                _format_issue(issue, output_lines, "warning")
                output_lines.append("")

        # Display info issues
        info_issues = [issue for issue in visible_issues if _get_issue_attr(issue, "severity") == "info"]
        if info_issues:
            if critical_issues or warning_issues:
                output_lines.append("")
            output_lines.append(style_text("  [i] Information", fg="blue", bold=True))
            output_lines.append("  " + "─" * 40)
            for issue in info_issues:
                _format_issue(issue, output_lines, "info")
                output_lines.append("")

        # Display debug issues if verbose
        if verbose:
            debug_issues = [issue for issue in visible_issues if _get_issue_attr(issue, "severity") == "debug"]
            if debug_issues:
                if critical_issues or warning_issues or info_issues:
                    output_lines.append("")
                output_lines.append(style_text("  🐛 Debug", fg="cyan", bold=True))
                output_lines.append("  " + "─" * 40)
                for issue in debug_issues:
                    _format_issue(issue, output_lines, "debug")
                    output_lines.append("")
    else:
        # Check if no files were scanned to show appropriate message
        files_scanned = results.get("files_scanned", 0)
        if files_scanned == 0:
            output_lines.append(
                "  " + style_text("⚠️  No model files found to scan", fg="yellow", bold=True),
            )
        else:
            output_lines.append(
                "  " + style_text("✅ No security issues detected", fg="green", bold=True),
            )
        output_lines.append("")

    # Add a footer with final status
    output_lines.append("")
    output_lines.append("═" * 80)

    # Check if scan had operational errors first (highest priority in exit code)
    has_operational_errors = bool(results.get("has_errors"))
    files_scanned = results.get("files_scanned", 0)
    has_critical_findings = any(_get_issue_attr(issue, "severity") == "critical" for issue in visible_issues)
    has_warning_findings = any(_get_issue_attr(issue, "severity") == "warning" for issue in visible_issues)
    has_security_findings = has_critical_findings or has_warning_findings
    if has_operational_errors:
        status_icon = "❌"
        status_msg = "SCAN COMPLETED WITH OPERATIONAL ERRORS"
        status_color = "red"
        output_lines.append(f"  {style_text(f'{status_icon} {status_msg}', fg=status_color, bold=True)}")
        output_lines.append(
            f"  {style_text('Review warnings above and use --verbose for troubleshooting details.', fg='yellow')}"
        )
    # Determine overall status
    elif has_security_findings:
        if has_critical_findings:
            status_icon = "❌"
            status_msg = "CRITICAL SECURITY ISSUES FOUND"
            status_color = "red"
        elif has_warning_findings:
            status_icon = "⚠️"
            status_msg = "WARNINGS DETECTED"
            status_color = "yellow"
        status_line = style_text(f"{status_icon} {status_msg}", fg=status_color, bold=True)
        output_lines.append(f"  {status_line}")
    # Check if no files were scanned
    elif files_scanned == 0:
        status_icon = "❌"
        status_msg = "NO FILES SCANNED"
        status_color = "red"
        output_lines.append(f"  {style_text(f'{status_icon} {status_msg}', fg=status_color, bold=True)}")
        output_lines.append(
            f"  {style_text('Warning: No model files were found at the specified location.', fg='yellow')}"
        )
    elif visible_issues:
        if has_critical_findings:
            status_icon = "❌"
            status_msg = "CRITICAL SECURITY ISSUES FOUND"
            status_color = "red"
        elif has_warning_findings:
            status_icon = "⚠️"
            status_msg = "WARNINGS DETECTED"
            status_color = "yellow"
        else:
            # Only info/debug issues
            status_icon = "[i]"
            status_msg = "INFORMATIONAL FINDINGS"
            status_color = "blue"
        status_line = style_text(f"{status_icon} {status_msg}", fg=status_color, bold=True)
        output_lines.append(f"  {status_line}")
    else:
        status_icon = "✅"
        status_msg = "NO ISSUES FOUND"
        status_color = "green"
        status_line = style_text(f"{status_icon} {status_msg}", fg=status_color, bold=True)
        output_lines.append(f"  {status_line}")

    output_lines.append("═" * 80)

    # Add encouragement message for unauthenticated users after successful scans
    # (similar to promptfoo's approach)
    if not config.is_authenticated() and not visible_issues:
        output_lines.append("")
        encouragement_msg = "» Want enhanced scanning with cloud models and team sharing?"
        signup_link = style_text("https://promptfoo.app", fg="green", bold=True)
        encouragement_line = f"  {encouragement_msg} Sign up at {signup_link}"
        output_lines.append(encouragement_line)

    return "\n".join(output_lines)


def _get_issue_attr(issue: dict[str, Any] | Any, attr: str, default: Any = None) -> Any:
    """Safely get an attribute from an issue whether it's a dict or Pydantic object."""
    if isinstance(issue, dict):
        return issue.get(attr, default)
    else:
        # Assume it's a Pydantic object
        return getattr(issue, attr, default)


def _format_issue(
    issue: dict[str, Any] | Any,
    output_lines: list[str],
    severity: str,
) -> None:
    """Format a single issue with proper indentation and styling"""
    message = _get_issue_attr(issue, "message", "Unknown issue")
    location = _get_issue_attr(issue, "location", "")

    # Icon based on severity
    icons = {
        "critical": "    └─ 🚨",
        "warning": "    └─ ⚠️ ",
        "info": "    └─ [i] ",
        "debug": "    └─ 🐛",
    }

    # Build the issue line
    icon = icons.get(severity, "    └─ ")

    if location:
        location_str = style_text(f"[{location}]", fg="cyan", bold=True)
        output_lines.append(f"{icon} {location_str}")
        output_lines.append(f"       {style_text(message, fg='bright_white')}")
    else:
        output_lines.append(f"{icon} {style_text(message, fg='bright_white')}")

    # Add "Why" explanation if available
    why = _get_issue_attr(issue, "why")
    if why:
        why_label = style_text("Why:", fg="magenta", bold=True)
        # Wrap long explanations
        import textwrap

        wrapped_why = textwrap.fill(
            why,
            width=65,
            initial_indent="",
            subsequent_indent="           ",
        )
        output_lines.append(f"       {why_label} {wrapped_why}")

    # Add details if available
    details = _get_issue_attr(issue, "details", {})
    if details:
        for key, value in details.items():
            if value:  # Only show non-empty values
                detail_label = style_text(f"{key}:", fg="bright_black")
                detail_value = style_text(str(value), fg="bright_white")
                output_lines.append(f"       {detail_label} {detail_value}")


def _display_failure_details(summary: dict[str, Any]) -> None:
    """Display categorized failure information from scanner summary."""
    # Show dependency errors with install commands
    if summary["dependency_errors"]:
        click.echo("\nMissing Dependencies:")
        for scanner_id, info in summary["dependency_errors"].items():
            click.secho(f"  ❌ {scanner_id}", fg="red")
            click.echo(f"     Dependencies: {', '.join(info['dependencies'])}")
            click.echo(f"     Install: {info['install_command']}")

    # Show NumPy compatibility errors separately
    if summary["numpy_errors"]:
        click.echo("\nNumPy Compatibility Issues:")
        for scanner_id, error in summary["numpy_errors"].items():
            click.secho(f"  ⚠️  {scanner_id}", fg="yellow")
            click.echo(f"     {error}")

    # Show other errors
    other_errors = {
        k: v
        for k, v in summary["failed_scanner_details"].items()
        if k not in summary["dependency_errors"] and k not in summary["numpy_errors"]
    }
    if other_errors:
        click.echo("\nOther Issues:")
        for scanner_id, error_msg in other_errors.items():
            click.secho(f"  ❌ {scanner_id}", fg="red")
            click.echo(f"     {error_msg}")


@cli.command("metadata")
@click.argument("path", type=click.Path(exists=True, readable=True, dir_okay=True, file_okay=True))
@click.option(
    "--format", "output_format", type=click.Choice(["json", "yaml", "table"]), default="table", help="Output format"
)
@click.option("--output", type=click.Path(), help="Output file path")
@click.option("--security-only", is_flag=True, help="Show only security-relevant metadata")
@click.option(
    "--trust-loaders",
    is_flag=True,
    help="Allow metadata extraction to deserialize models (unsafe on untrusted inputs; defaults to off)",
)
def metadata(path: str, output_format: str, output: str | None, security_only: bool, trust_loaders: bool) -> None:
    """Extract and display model metadata."""
    import time

    start_time = time.time()
    from .metadata_extractor import ModelMetadataExtractor

    try:
        extractor = ModelMetadataExtractor()
        metadata = extractor.extract(path, security_only=security_only, allow_deserialization=trust_loaders)

        if output_format == "json":
            output_text = json.dumps(metadata, indent=2)
        elif output_format == "yaml":
            try:
                import yaml

                output_text = yaml.dump(metadata, default_flow_style=False, sort_keys=False)
            except ImportError:
                click.secho("Warning: PyYAML not installed, falling back to JSON", fg="yellow")
                output_text = json.dumps(metadata, indent=2)
        else:  # table format
            output_text = _format_metadata_table(metadata)

        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write(output_text)
            click.secho(f"Metadata written to {output}", fg="green")
        else:
            click.echo(output_text)

        record_command_used(
            "metadata",
            duration=time.time() - start_time,
            success=True,
            format=output_format,
            security_only=security_only,
            trust_loaders=trust_loaders,
            output_file=bool(output),
        )

    except Exception as e:
        record_command_used(
            "metadata",
            duration=time.time() - start_time,
            success=False,
            format=output_format,
            error_type=type(e).__name__,
        )
        click.secho(f"Error extracting metadata: {e}", fg="red")
        sys.exit(1)


def _format_metadata_table(metadata: dict[str, Any]) -> str:
    """Format metadata as a readable table."""
    output = []

    if "directory" in metadata:
        # Directory summary
        output.append(f"Directory: {metadata['directory']}")
        output.append(f"Total Files: {metadata['summary']['total_files']}")
        output.append("\nFormats:")
        for fmt, count in metadata["summary"]["formats"].items():
            output.append(f"  {fmt}: {count}")
        output.append("\nFiles:")
        for file_meta in metadata["files"][:10]:  # Show first 10 files
            output.append(f"  {file_meta.get('file', 'unknown')} ({file_meta.get('format', 'unknown')})")
        if len(metadata["files"]) > 10:
            output.append(f"  ... and {len(metadata['files']) - 10} more")
    else:
        # Single file
        output.append(f"File: {metadata.get('file', 'unknown')}")
        output.append(f"Format: {metadata.get('format', 'unknown')}")
        output.append(f"Size: {metadata.get('file_size', 0):,} bytes")

        # Show key metadata fields
        for key, value in metadata.items():
            if key not in ["file", "path", "format", "file_size"]:
                if isinstance(value, str | int | float | bool):
                    output.append(f"{key.replace('_', ' ').title()}: {value}")
                elif isinstance(value, dict) and len(value) <= 5:
                    output.append(f"{key.replace('_', ' ').title()}:")
                    for k, v in value.items():
                        output.append(f"  {k}: {v}")
                elif isinstance(value, list) and len(value) <= 10:
                    output.append(f"{key.replace('_', ' ').title()}: {', '.join(map(str, value))}")

    return "\n".join(output)


@cli.command()
@click.option(
    "--show-failed",
    is_flag=True,
    help="Show detailed information about failed scanners",
)
def doctor(show_failed: bool) -> None:
    """Diagnose scanner availability and dependencies"""
    import sys
    import time

    from .scanners import _registry

    start_time = time.time()
    click.echo("ModelAudit Scanner Diagnostic Report")
    click.echo("=" * 40)

    # System information
    click.echo(f"Python version: {sys.version.split()[0]}")

    # NumPy status
    numpy_compatible, numpy_status = _registry.get_numpy_status()
    numpy_color = "green" if numpy_compatible else "yellow"
    click.echo("NumPy status: ", nl=False)
    click.secho(numpy_status, fg=numpy_color)

    # Get comprehensive summary
    summary = _registry.get_available_scanners_summary()

    click.echo(f"\nTotal scanners: {summary['total_scanners']}")
    click.echo(f"Loaded successfully: {summary['loaded_scanners']}")
    click.echo(f"Failed to load: {summary['failed_scanners']}")

    # Show success rate with color coding
    success_rate = summary.get("success_rate", 0.0)
    if success_rate < 100.0:
        if success_rate >= 80.0:
            rate_color = "yellow"
        elif success_rate >= 60.0:
            rate_color = "red"
        else:
            rate_color = "bright_red"
        click.echo("Success rate: ", nl=False)
        click.secho(f"{success_rate}%", fg=rate_color)

    # Show detailed failure information if requested
    if show_failed and summary["failed_scanners"] > 0:
        _display_failure_details(summary)

    if summary["loaded_scanner_list"]:
        click.echo("\n" + style_text("Available Scanners:", fg="green"))
        for scanner in summary["loaded_scanner_list"]:
            click.echo(f"  ✅ {scanner}")

    # Enhanced recommendations
    if summary["failed_scanners"] > 0:
        click.echo("\n" + style_text("Recommendations:", fg="blue"))

        # Check for NumPy compatibility issues
        if summary.get("numpy_errors"):
            click.echo("• NumPy compatibility issues detected:")
            click.echo("  For NumPy 1.x compatibility: pip install 'numpy<2.0'")
            click.echo("  Then reinstall ML frameworks: pip install --force-reinstall tensorflow torch h5py")

        # Aggregate missing dependencies with grouped installation command
        all_missing_deps = set()
        for dep_info in summary.get("dependency_errors", {}).values():
            all_missing_deps.update(dep_info.get("dependencies", []))

        if all_missing_deps:
            click.echo(f"• Install missing dependencies: pip install modelaudit[{','.join(sorted(all_missing_deps))}]")

        click.echo("• Core functionality works even with missing optional dependencies")
        click.echo("• Run 'modelaudit doctor --show-failed' for detailed error messages")
    else:
        click.secho("\n✓ All scanners loaded successfully!", fg="green")

    record_command_used(
        "doctor",
        duration=time.time() - start_time,
        success=True,
        show_failed=show_failed,
        failed_scanners=summary["failed_scanners"],
    )


def display_rules(rules: dict[str, Rule], output_format: str) -> None:
    """Display rules in requested format."""
    if output_format == "json":
        rules_list = [
            {
                "code": code,
                "name": rule.name,
                "severity": rule.default_severity.value,
                "description": rule.description,
            }
            for code, rule in sorted(rules.items())
        ]
        click.echo(json.dumps(rules_list, indent=2))
    else:
        click.echo(style_text("Code   Severity   Name", bold=True))
        click.echo(style_text("----   --------   ----", bold=True))
        for code, rule in sorted(rules.items()):
            severity_text = style_text(rule.default_severity.value, fg=get_severity_color(rule.default_severity.value))
            click.echo(f"{code:<6} {severity_text:<10} {rule.name}")


@cli.command("rules")
@click.argument("rule_code", required=False)
@click.option("--list", "list_rules", is_flag=True, help="List all rules")
@click.option("--category", help="Show rules in a category range (e.g., 100-199)")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
def rules_command(rule_code: str | None, list_rules: bool, category: str | None, output_format: str) -> None:
    """View and explain security rules."""
    RuleRegistry.initialize()

    if rule_code:
        rule = RuleRegistry.get_rule(rule_code.upper())
        if not rule:
            click.echo(f"Rule {rule_code} not found", err=True)
            sys.exit(1)

        if output_format == "json":
            click.echo(
                json.dumps(
                    {
                        "code": rule.code,
                        "name": rule.name,
                        "severity": rule.default_severity.value,
                        "description": rule.description,
                    },
                    indent=2,
                )
            )
        else:
            click.echo(f"Code: {style_text(rule.code, bold=True)}")
            click.echo(f"Name: {rule.name}")
            severity_text = style_text(rule.default_severity.value, fg=get_severity_color(rule.default_severity.value))
            click.echo(f"Default Severity: {severity_text}")
            click.echo(f"Description: {rule.description}")
    elif category:
        try:
            if "-" in category:
                start_str, end_str = category.split("-")
                start = int(start_str)
                end = int(end_str)
            else:
                start = int(category)
                end = start + 99

            rules = RuleRegistry.get_rules_by_range(start, end)
            if not rules:
                click.echo(f"No rules found in range S{start}-S{end}", err=True)
                sys.exit(1)

            display_rules(rules, output_format)
        except ValueError:
            click.echo(f"Invalid category format: {category}", err=True)
            sys.exit(1)
    else:
        rules = RuleRegistry.get_all_rules()
        display_rules(rules, output_format)


def _get_platform_info() -> dict[str, Any]:
    """Get platform information for debug output."""
    import platform

    return {
        "os": sys.platform,
        "release": platform.release(),
        "arch": platform.machine(),
        "pythonVersion": platform.python_version(),
        "pythonExecutable": sys.executable,
        "pythonRecursionLimit": sys.getrecursionlimit(),
    }


def _get_install_info() -> dict[str, Any]:
    """Get ModelAudit installation information for debug output."""
    from importlib.metadata import PackageNotFoundError

    info: dict[str, Any] = {}

    # Check if editable install
    try:
        from importlib.metadata import distribution

        dist = distribution("modelaudit")

        # Get install location using public API (locate_file returns install root)
        with contextlib.suppress(Exception):
            install_root = dist.locate_file("")
            install_path = str(install_root)
            home = str(Path.home())
            if install_path.startswith(home):
                install_path = "~" + install_path[len(home) :]
            info["location"] = install_path

        # Check for editable install via direct_url.json
        direct_url_text = dist.read_text("direct_url.json")
        if direct_url_text:
            direct_url = json.loads(direct_url_text)
            if direct_url.get("dir_info", {}).get("editable", False):
                info["editable"] = True
            else:
                info["editable"] = False
        else:
            info["editable"] = False

    except PackageNotFoundError:
        info["editable"] = None
        info["location"] = "not installed as package"
    except Exception:
        info["editable"] = None

    return info


def _redact_proxy_url(proxy_url: str | None) -> str | None:
    """Redact credentials from proxy URLs while preserving host/port for debugging.

    Proxy URLs often contain credentials (http://user:pass@host:port).
    Since debug output is meant to be pasted in bug reports, we must redact
    the credentials while keeping the scheme/host/port for troubleshooting.
    """
    if not proxy_url:
        return None
    try:
        from urllib.parse import urlsplit, urlunsplit

        parts = urlsplit(proxy_url)
        if parts.username or parts.password:
            # Rebuild URL without credentials
            netloc = parts.hostname or ""
            if parts.port:
                netloc += f":{parts.port}"
            return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))
    except Exception:
        # If parsing fails, return a safe indicator rather than the raw URL
        return "<proxy configured>"
    return proxy_url


def _get_env_info() -> dict[str, Any]:
    """Get environment variable information for debug output."""
    from .telemetry import is_telemetry_enabled

    return {
        "telemetryDisabled": not is_telemetry_enabled(),
        "noColor": bool(os.getenv("NO_COLOR")),
        "ciEnvironment": bool(os.getenv("CI")),
        "jfrogConfigured": bool(os.getenv("JFROG_API_TOKEN") or os.getenv("JFROG_ACCESS_TOKEN")),
        "mlflowConfigured": bool(os.getenv("MLFLOW_TRACKING_URI")),
        "httpProxy": _redact_proxy_url(os.getenv("HTTP_PROXY") or os.getenv("http_proxy")),
        "httpsProxy": _redact_proxy_url(os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")),
        "noProxy": os.getenv("NO_PROXY") or os.getenv("no_proxy") or None,
    }


def _get_dependency_versions() -> dict[str, Any]:
    """Get versions of key dependencies for debug output.

    Uses importlib.metadata to get versions WITHOUT importing modules.
    This avoids mutex/threading issues from ML framework initialization.
    """
    from importlib.metadata import PackageNotFoundError, version

    def _get_version(package_name: str) -> str | None:
        """Get package version from metadata without importing the module."""
        try:
            return version(package_name)
        except PackageNotFoundError:
            return None
        except Exception:
            return None

    # Core dependencies (should always be installed)
    core = {
        "click": _get_version("click"),
        "pyyaml": _get_version("pyyaml"),
        "requests": _get_version("requests"),
        "platformdirs": _get_version("platformdirs"),
    }

    # ML framework dependencies (optional, scanner-specific)
    ml_frameworks = {
        "numpy": _get_version("numpy"),
        "torch": _get_version("torch"),
        "tensorflow": _get_version("tensorflow"),
        "onnx": _get_version("onnx"),
        "jax": _get_version("jax"),
        "flax": _get_version("flax"),
    }

    # Format/serialization dependencies (optional)
    serialization = {
        "h5py": _get_version("h5py"),
        "safetensors": _get_version("safetensors"),
        "msgpack": _get_version("msgpack"),
        "joblib": _get_version("joblib"),
    }

    # Utility dependencies (optional)
    utilities = {
        "huggingface_hub": _get_version("huggingface-hub"),
        "posthog": _get_version("posthog"),
        "jinja2": _get_version("jinja2"),
        "py7zr": _get_version("py7zr"),
        "xgboost": _get_version("xgboost"),
    }

    # Filter out None values for cleaner output
    def filter_installed(deps: dict[str, str | None]) -> dict[str, str]:
        return {k: v for k, v in deps.items() if v is not None}

    result: dict[str, Any] = {
        "core": filter_installed(core),
        "mlFrameworks": filter_installed(ml_frameworks),
        "serialization": filter_installed(serialization),
        "utilities": filter_installed(utilities),
    }

    return result


def _get_auth_info() -> dict[str, Any]:
    """Get authentication information for debug output."""
    return {
        "authenticated": config.is_authenticated(),
        "authSource": config.get_auth_source() if config.is_authenticated() else None,
        "delegatedFromPromptfoo": is_delegated_from_promptfoo(),
    }


def _get_scanner_info(verbose: bool = False) -> dict[str, Any]:
    """Get scanner information for debug output."""
    from .scanners import _registry

    summary = _registry.get_available_scanners_summary()

    info: dict[str, Any] = {
        "total": summary["total_scanners"],
        "available": summary["loaded_scanners"],
        "failed": summary["failed_scanners"],
        "successRate": summary["success_rate"],
        "availableList": summary.get("loaded_scanner_list", []),
    }

    # Only include failure details if there are failures
    if summary["failed_scanners"] > 0:
        info["failedList"] = list(summary["failed_scanner_details"].keys())

        if verbose:
            info["failedDetails"] = summary["failed_scanner_details"]
            if summary["dependency_errors"]:
                info["dependencyErrors"] = summary["dependency_errors"]
            if summary["numpy_errors"]:
                info["numpyErrors"] = summary["numpy_errors"]

    return info


def _sanitize_debug_path(path: str) -> str:
    """Sanitize filesystem paths for debug output."""
    home = str(Path.home())
    if path.startswith(home):
        return "~" + path[len(home) :]
    if os.path.isabs(path):
        return "<outside-home path redacted>"
    return path


def _get_cache_info() -> dict[str, Any]:
    """Get cache information for debug output."""
    try:
        from .cache import get_cache_manager

        cache_manager = get_cache_manager(enabled=True)
        stats = cache_manager.get_stats()

        # Get cache directory path with ~ expansion for privacy
        cache_dir_path: str | None = None
        if cache_manager.cache is not None:
            cache_dir_path = _sanitize_debug_path(str(cache_manager.cache.cache_dir))

        return {
            "enabled": True,
            "directory": cache_dir_path,
            "entries": stats.get("total_entries", 0),
            "sizeMb": round(stats.get("total_size_mb", 0.0), 2),
            "hitRate": round(stats.get("hit_rate", 0.0), 4),
        }
    except Exception as e:
        return {
            "enabled": False,
            "error": str(e)[:100],
        }


def _get_config_info() -> dict[str, Any]:
    """Get configuration information for debug output."""
    # Shared config with promptfoo
    shared_config_dir = get_config_directory_path()
    shared_config_path = os.path.join(shared_config_dir, "promptfoo.yaml")
    shared_display_path = _sanitize_debug_path(shared_config_path)

    # ModelAudit-specific config
    home = str(Path.home())
    modelaudit_config_path = os.path.join(home, ".modelaudit", "user_config.json")
    modelaudit_display_path = "~/.modelaudit/user_config.json"

    return {
        "sharedConfigPath": shared_display_path,
        "sharedConfigExists": os.path.exists(shared_config_path),
        "modelauditConfigPath": modelaudit_display_path,
        "modelauditConfigExists": os.path.exists(modelaudit_config_path),
        "userIdGenerated": bool(get_user_id()),
    }


def _safe_get_section(func: Any, section_name: str) -> dict[str, Any]:
    """Safely execute a debug info function, returning error on failure."""
    try:
        result = func()
        return result if isinstance(result, dict) else {"value": result}
    except Exception as e:
        return {"error": f"Failed to retrieve {section_name}: {str(e)[:100]}"}


def _format_debug_output(debug_info: dict[str, Any], verbose: bool) -> str:
    """Format debug info as pretty-printed output with quick diagnosis."""
    lines = []

    # Header
    border = "═" * 80
    lines.append(border)
    lines.append(style_text("ModelAudit Debug Information", fg="blue", bold=True))
    lines.append(border)

    # JSON output
    lines.append(json.dumps(debug_info, indent=2, default=str))

    lines.append(border)
    lines.append(
        style_text(
            "Please include this output when reporting issues:",
            fg="yellow",
        )
    )
    lines.append(style_text("https://github.com/promptfoo/modelaudit/issues", fg="cyan"))
    lines.append("")

    # Quick diagnosis section
    lines.append(style_text("Quick diagnosis:", fg="white", bold=True))

    # Platform status
    platform_info = debug_info.get("platform", {})
    python_ver = platform_info.get("pythonVersion", "unknown")
    os_name = platform_info.get("os", "unknown")
    arch = platform_info.get("arch", "unknown")
    lines.append(f"  ✅ Python {python_ver} on {os_name} ({arch})")

    # Dependencies summary
    deps_info = debug_info.get("dependencies", {})
    ml_frameworks = deps_info.get("mlFrameworks", {})
    ml_installed = [k for k in ["torch", "tensorflow", "onnx", "jax"] if k in ml_frameworks]
    if ml_installed:
        lines.append(f"  ✅ ML frameworks: {', '.join(ml_installed)}")
    else:
        lines.append(style_text("  ⚠️  No ML frameworks installed (torch, tensorflow, onnx, jax)", fg="yellow"))

    # Scanner status
    scanner_info = debug_info.get("scanners", {})
    available = scanner_info.get("available", 0)
    total = scanner_info.get("total", 0)
    failed = scanner_info.get("failed", 0)

    if failed == 0:
        lines.append(f"  ✅ {available}/{total} scanners available")
    else:
        lines.append(style_text(f"  ⚠️  {available}/{total} scanners available ({failed} unavailable)", fg="yellow"))
        if not verbose:
            lines.append(style_text("     Run with --verbose for failure details", dim=True))

    # NumPy status (get from dependencies)
    numpy_version = ml_frameworks.get("numpy")
    if numpy_version:
        # NumPy 2.x may have compatibility issues with some ML frameworks
        major_version = int(numpy_version.split(".")[0]) if numpy_version else 0
        if major_version >= 2:
            lines.append(style_text(f"  ⚠️  NumPy {numpy_version} (v2 may have ML framework issues)", fg="yellow"))
        else:
            lines.append(f"  ✅ NumPy {numpy_version}")
    else:
        lines.append(style_text("  ⚠️  NumPy not installed", fg="yellow"))

    # Cache status
    cache_info = debug_info.get("cache", {})
    if cache_info.get("enabled"):
        entries = cache_info.get("entries", 0)
        size_mb = cache_info.get("sizeMb", 0)
        lines.append(f"  ✅ Cache enabled ({entries} entries, {size_mb} MB)")
    else:
        cache_error = cache_info.get("error", "disabled")
        lines.append(style_text(f"  ⚠️  Cache: {cache_error}", fg="yellow"))

    # Auth status
    auth_info = debug_info.get("auth", {})
    if auth_info.get("authenticated"):
        source = auth_info.get("authSource", "unknown")
        lines.append(f"  ✅ Authenticated via {source}")
    else:
        lines.append(style_text("  ⚠️  Not authenticated (enhanced scanning unavailable)", fg="yellow"))

    # Telemetry status
    env_info = debug_info.get("env", {})
    if env_info.get("telemetryDisabled"):
        lines.append("  [i] Telemetry disabled")

    lines.append(border)

    return "\n".join(lines)


@cli.command()
@click.option("--json", "output_json", is_flag=True, help="Output raw JSON without formatting")
@click.option("--verbose", "-v", is_flag=True, help="Include additional diagnostic details")
def debug(output_json: bool, verbose: bool) -> None:
    """Display debug information for troubleshooting.

    Outputs comprehensive diagnostic information useful for:

    \b
    - Filing bug reports on GitHub
    - Troubleshooting scanner issues
    - Verifying configuration and authentication
    - Checking environment setup

    \b
    Examples:
        modelaudit debug                    # Pretty-printed output
        modelaudit debug --json             # Raw JSON for scripting
        modelaudit debug --verbose          # Include detailed scanner errors
    """
    import time

    start_time = time.time()
    # Build debug info dictionary
    debug_info: dict[str, Any] = {
        "version": __version__,
        "platform": _safe_get_section(_get_platform_info, "platform"),
        "install": _safe_get_section(_get_install_info, "install"),
        "dependencies": _safe_get_section(_get_dependency_versions, "dependencies"),
        "env": _safe_get_section(_get_env_info, "env"),
        "auth": _safe_get_section(_get_auth_info, "auth"),
        "scanners": _safe_get_section(lambda: _get_scanner_info(verbose), "scanners"),
        "cache": _safe_get_section(_get_cache_info, "cache"),
        "config": _safe_get_section(_get_config_info, "config"),
    }

    if output_json:
        # Raw JSON output for scripting
        click.echo(json.dumps(debug_info, indent=2, default=str))
    else:
        # Pretty-printed output with quick diagnosis
        click.echo(_format_debug_output(debug_info, verbose))

    record_command_used(
        "debug", duration=time.time() - start_time, success=True, output_json=output_json, verbose=verbose
    )


def main() -> None:
    if sys.version_info < (3, 10):  # noqa: UP036 — intentional safety net for bypassed requires-python
        click.echo(
            click.style(
                f"WARNING: modelaudit requires Python 3.10+, but you are running "
                f"Python {sys.version_info[0]}.{sys.version_info[1]}. "
                f"Please upgrade: https://www.promptfoo.dev/docs/model-audit/",
                fg="yellow",
            ),
            err=True,
        )
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    cli()


if __name__ == "__main__":
    main()
