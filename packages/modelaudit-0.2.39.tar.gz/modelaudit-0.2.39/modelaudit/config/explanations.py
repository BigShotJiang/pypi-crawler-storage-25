"""
Security issue explanations for ModelAudit.

This module provides centralized, security-team-friendly explanations
for common security issues found in ML model files.
"""

# Common explanations for dangerous imports and modules
DANGEROUS_IMPORTS: dict[str, str] = {
    "os": (
        "The 'os' module provides direct access to operating system functions, allowing execution of arbitrary system "
        "commands, file system manipulation, and environment variable access. Malicious models can use this to "
        "compromise the host system, steal data, or install malware."
    ),
    "posix": (
        "The 'posix' module provides direct access to POSIX system calls on Unix-like systems. Like the 'os' module, "
        "it can execute arbitrary system commands and manipulate the file system. The 'posix.system' function is "
        "equivalent to 'os.system' and poses the same security risks."
    ),
    "nt": (
        "The 'nt' module is a Windows-specific alias for 'os', exposing the same system command and file operations. "
        "Attackers can invoke functions like 'nt.system' to execute arbitrary commands."
    ),
    "ntpath": (
        "The 'ntpath' module provides Windows path manipulation utilities. These can be abused to access or modify "
        "restricted system paths, facilitating privilege escalation or data exfiltration."
    ),
    "posixpath": (
        "The 'posixpath' module provides POSIX path manipulation utilities. Attackers can leverage it to traverse or "
        "access restricted paths on Unix-like systems."
    ),
    "sys": (
        "The 'sys' module provides access to interpreter internals and system-specific parameters. It can be used to "
        "modify the Python runtime, access command-line arguments, or manipulate the module import system to load "
        "malicious code."
    ),
    "subprocess": (
        "The 'subprocess' module allows spawning new processes and executing system commands. This is a critical "
        "security risk as it enables arbitrary command execution on the host system."
    ),
    "eval": (
        "The 'eval' function executes arbitrary Python code from strings. This is extremely dangerous as it allows "
        "dynamic code execution, potentially running any malicious code embedded in the model."
    ),
    "exec": (
        "The 'exec' function executes arbitrary Python statements from strings. Like eval, this enables unrestricted "
        "code execution and is a severe security risk."
    ),
    "__import__": (
        "The '__import__' function dynamically imports modules at runtime. Attackers can use this to load malicious "
        "modules or bypass import restrictions."
    ),
    "importlib": (
        "The 'importlib' module provides programmatic module importing capabilities. It can be used to dynamically "
        "load malicious code or bypass security controls."
    ),
    "pickle": (
        "Nested pickle operations (pickle.load/loads within a pickle) can indicate attempts to obfuscate malicious "
        "payloads or create multi-stage attacks."
    ),
    "base64": (
        "Base64 encoding/decoding functions are often used to obfuscate malicious payloads, making them harder to "
        "detect through static analysis."
    ),
    "socket": (
        "The 'socket' module enables network communication. Malicious models can use this to exfiltrate data, download "
        "additional payloads, or establish command & control channels."
    ),
    "ctypes": (
        "The 'ctypes' module provides low-level system access through foreign function interfaces. It can bypass "
        "Python's safety features and directly manipulate memory or call system libraries."
    ),
    "pty": (
        "The 'pty' module provides pseudo-terminal utilities. The 'spawn' function can be used to create interactive "
        "shells, potentially giving attackers remote access."
    ),
    "platform": (
        "Functions like 'platform.system' or 'platform.popen' can be used for system reconnaissance or command "
        "execution."
    ),
    "shutil": (
        "The 'shutil' module provides high-level file operations. Functions like 'rmtree' can recursively delete "
        "directories, potentially causing data loss."
    ),
    "tempfile": ("Unsafe temp file creation (like 'mktemp') can lead to race conditions and security vulnerabilities."),
    "runpy": (
        "The 'runpy' module executes Python modules as scripts, potentially running malicious code embedded in the "
        "model."
    ),
    "operator.attrgetter": (
        "The 'attrgetter' function can be used to access object attributes dynamically, potentially bypassing "
        "access controls or reaching sensitive data."
    ),
    "builtins": (
        "Direct access to builtin functions can be used to bypass restrictions or access dangerous functionality "
        "like eval/exec."
    ),
    "dill": (
        "The 'dill' module extends pickle's capabilities to serialize almost any Python object, including lambda "
        "functions and code objects. This significantly increases the attack surface for code execution."
    ),
    "torch.jit": (
        "The 'torch.jit' module can load and execute serialized TorchScript artifacts. In untrusted model files, "
        "this can introduce unsafe runtime behavior and should be treated as a high-risk import surface."
    ),
    "torch._dynamo": (
        "The 'torch._dynamo' internals drive dynamic graph capture and compilation. Importing these internals from "
        "untrusted pickle payloads is suspicious because they enable advanced runtime execution pathways."
    ),
    "torch._inductor": (
        "The 'torch._inductor' compiler backend can generate and execute optimized kernels at runtime. In model "
        "artifacts, this is a risky import surface that should be reviewed as potentially unsafe."
    ),
    "torch.compile": (
        "The 'torch.compile' API triggers runtime compilation and execution pipelines. In untrusted serialized "
        "payloads, this can be used to reach risky execution paths and should be flagged."
    ),
    "torch.storage._load_from_bytes": (
        "The 'torch.storage._load_from_bytes' function reconstructs storages from raw bytes and can be abused in "
        "malicious pickle chains. References from untrusted payloads should be treated as dangerous."
    ),
    "numpy.f2py": (
        "The 'numpy.f2py' toolchain bridges Python and compiled Fortran extensions. References in untrusted "
        "pickles are risky because they can touch native-code compilation/loading paths."
    ),
    "numpy.distutils": (
        "The 'numpy.distutils' build utilities are tied to extension module compilation and setup workflows. "
        "Importing them from serialized model payloads is suspicious and may indicate unsafe behavior."
    ),
    "numpy.load": (
        "The 'numpy.load' function can recursively deserialize object arrays via pickle support, enabling "
        "second-stage payload loading from attacker-controlled files."
    ),
    "site.main": (
        "The 'site.main' function executes Python startup path initialization and can trigger module-level "
        "execution side effects in attacker-influenced environments."
    ),
    "_io.FileIO": (
        "The '_io.FileIO' constructor performs direct file reads and writes, enabling arbitrary local file access "
        "without using higher-level safety wrappers."
    ),
    "test.support.script_helper.assert_python_ok": (
        "The 'assert_python_ok' helper launches a Python subprocess. In untrusted pickle payloads this is command "
        "execution behavior, not benign test plumbing."
    ),
    "_osx_support._read_output": (
        "The '_osx_support._read_output' helper executes shell commands to capture output, enabling command "
        "execution from deserialization payloads."
    ),
    "_aix_support._read_cmd_output": (
        "The '_aix_support._read_cmd_output' helper executes commands and captures process output, creating direct "
        "command-execution risk."
    ),
    "_pyrepl.pager.pipe_pager": (
        "The '_pyrepl.pager.pipe_pager' helper invokes pager subprocess flows and can be abused for process "
        "execution during model loading."
    ),
    "torch.serialization.load": (
        "The 'torch.serialization.load' loader performs nested PyTorch and pickle deserialization, which can invoke "
        "attacker-controlled reconstruction callables."
    ),
    "torch._inductor.codecache.compile_file": (
        "The 'torch._inductor.codecache.compile_file' path compiles and loads generated code artifacts, enabling "
        "arbitrary code execution when attacker-controlled."
    ),
    "numpy.f2py.crackfortran.getlincoef": (
        "The 'numpy.f2py.crackfortran.getlincoef' helper belongs to NumPy's f2py Fortran parsing and code-"
        "generation pipeline. It is tooling code, not benign tensor reconstruction logic, so invoking it from a "
        "pickle indicates a path into attacker-controlled parser behavior."
    ),
    "torch._dynamo.guards.GuardBuilder.get": (
        "The 'torch._dynamo.guards.GuardBuilder.get' helper resolves TorchDynamo guard logic over live runtime "
        "objects. In an untrusted pickle this is execution-oriented helper code, not safe model reconstruction."
    ),
    "torch.fx.experimental.symbolic_shapes.ShapeEnv.evaluate_guards_expression": (
        "The 'ShapeEnv.evaluate_guards_expression' helper evaluates symbolic-shape guard expressions, turning "
        "deserialization into runtime expression evaluation."
    ),
    "torch.utils.collect_env.run": (
        "The 'torch.utils.collect_env.run' helper launches subprocesses to collect environment details. In a "
        "pickle payload this is process-execution behavior, not benign model loading."
    ),
    "torch.utils._config_module.ConfigModule.load_config": (
        "The 'ConfigModule.load_config' helper loads Python-driven runtime configuration into a live module. "
        "Triggering it from deserialization opens an attacker-controlled configuration path."
    ),
    "torch.utils.bottleneck.__main__.run_cprofile": (
        "The 'run_cprofile' bottleneck entrypoint executes target code under the profiler, so using it during "
        "unpickling is an execution path rather than safe tensor reconstruction."
    ),
    "torch.utils.bottleneck.__main__.run_autograd_prof": (
        "The 'run_autograd_prof' bottleneck entrypoint runs target code under autograd profiling, which is "
        "execution-oriented helper behavior rather than benign model loading."
    ),
    "torch.utils.data.datapipes.utils.decoder.basichandlers": (
        "The 'basichandlers' helper dispatches DataPipes decode handlers for external content types. In an "
        "untrusted pickle it opens a non-reconstruction processing path that should be treated as dangerous."
    ),
}

# Explanations for dangerous pickle opcodes
DANGEROUS_OPCODES = {
    "REDUCE": (
        "The REDUCE opcode calls a callable with arguments, effectively executing arbitrary Python functions. This is "
        "the primary mechanism for pickle-based code execution attacks through __reduce__ methods."
    ),
    "INST": (
        "The INST opcode instantiates objects by calling their class constructor. Malicious classes can execute code "
        "in __init__ methods during unpickling."
    ),
    "OBJ": (
        "The OBJ opcode creates class instances. Like INST, this can trigger code execution through object "
        "initialization."
    ),
    "NEWOBJ": (
        "The NEWOBJ opcode creates new-style class instances. It can execute initialization code and is commonly "
        "used in pickle exploits."
    ),
    "NEWOBJ_EX": (
        "The NEWOBJ_EX opcode is an extended version of NEWOBJ with additional capabilities for creating objects, "
        "potentially executing initialization code."
    ),
    "BUILD": (
        "The BUILD opcode updates object state and can trigger code execution through __setstate__ or __setattr__ "
        "methods."
    ),
    "PERSID": (
        "The PERSID opcode resolves an object through the unpickler's persistent_load callback. Model framework "
        "loaders can use this callback for external storage resolution, so untrusted persistent IDs should be "
        "reviewed instead of treated as ordinary scalar data."
    ),
    "BINPERSID": (
        "The BINPERSID opcode resolves an object through the unpickler's persistent_load callback using a stack "
        "operand as the persistent ID. Model framework loaders can use this callback for external storage "
        "resolution, so untrusted persistent IDs should be reviewed instead of treated as ordinary scalar data."
    ),
    "STACK_GLOBAL": (
        "The STACK_GLOBAL opcode imports modules and retrieves attributes dynamically. Outside ML contexts, this "
        "often indicates attempts to access dangerous functionality."
    ),
    "GLOBAL": (
        "The GLOBAL opcode imports and accesses module attributes. When referencing dangerous modules, this "
        "indicates potential security risks."
    ),
    # Memo-based attack opcodes - can reference previously stored dangerous objects
    "BINGET": (
        "The BINGET opcode retrieves an object from the pickle memo by index. Attackers can use this to "
        "reference dangerous objects that were stored earlier in the pickle stream, enabling indirect attacks."
    ),
    "LONG_BINGET": (
        "The LONG_BINGET opcode retrieves an object from the pickle memo using a 4-byte index. Like BINGET, "
        "it can be used in memo-based attacks to reference dangerous objects stored earlier."
    ),
    "BINPUT": (
        "The BINPUT opcode stores an object in the pickle memo. In attack chains, this allows storing dangerous "
        "callable objects for later retrieval via BINGET, enabling multi-stage attacks."
    ),
    "LONG_BINPUT": (
        "The LONG_BINPUT opcode stores an object in the pickle memo using a 4-byte index. Used in conjunction "
        "with LONG_BINGET for memo-based attacks with larger indexes."
    ),
    # Extension registry opcodes - can reference external dangerous modules
    "EXT1": (
        "The EXT1 opcode references a registered extension by 1-byte code. Extension registry entries can "
        "map to dangerous callables, enabling code execution via pre-registered malicious extensions."
    ),
    "EXT2": (
        "The EXT2 opcode references a registered extension by 2-byte code. Like EXT1, it can invoke dangerous "
        "functionality through the pickle extension registry."
    ),
    "EXT4": (
        "The EXT4 opcode references a registered extension by 4-byte code. Extension registry attacks can "
        "bypass module-based detection by using numeric codes instead of module names."
    ),
    # Protocol 4+ framing opcode
    "FRAME": (
        "The FRAME opcode (Protocol 4+) introduces a frame boundary for chunked data. While not directly "
        "dangerous, it can be used to obfuscate payload structure and evade pattern-based detection."
    ),
}

# Explanations for specific patterns and behaviors
PATTERN_EXPLANATIONS = {
    "base64_payload": (
        "Base64-encoded data in models often conceals malicious payloads. Legitimate ML models rarely need encoded "
        "strings unless handling specific data formats."
    ),
    "hex_encoded": (
        "Hexadecimal-encoded strings (\\x00 format) can hide malicious code or data. This obfuscation technique is "
        "commonly used to evade detection."
    ),
    "lambda_layer": (
        "Lambda layers in Keras/TensorFlow can contain arbitrary Python code that executes during model inference. "
        "Unlike standard layers, these can perform system operations beyond tensor computations."
    ),
    "executable_in_zip": (
        "Executable files (.exe, .sh, .bat, etc.) within model archives are highly suspicious. ML models should "
        "only contain weights and configuration, not executables."
    ),
    "dissimilar_weights": (
        "Weight vectors that are completely dissimilar to others in the same layer may indicate injected malicious "
        "data masquerading as model parameters."
    ),
    "outlier_neurons": (
        "Neurons with weight distributions far outside the normal range might encode hidden functionality or "
        "backdoors rather than learned features."
    ),
    "blacklisted_name": (
        "This model name appears on security blacklists, indicating known malicious models or naming patterns "
        "associated with attacks."
    ),
    "manifest_name_mismatch": (
        "Model names in manifests that don't match expected patterns may indicate tampered or malicious models "
        "trying to impersonate legitimate ones."
    ),
    "encoded_strings": (
        "Encoded or obfuscated strings in model files often hide malicious payloads or commands from security scanners."
    ),
    "pickle_size_limit": (
        "Extremely large pickle files may indicate embedded malicious data or attempts to cause resource exhaustion."
    ),
    "pickle_expansion_attack": (
        "Repeated memo expansion, dense DUP usage, and extreme memo read/write imbalance can indicate a pickle "
        "bomb designed to consume excessive CPU or memory during unpickling."
    ),
    "nested_pickle": (
        "Pickle operations within pickled data (nested pickling) is often used to create multi-stage exploits or "
        "hide malicious payloads."
    ),
    "torch_legacy": (
        "Legacy PyTorch formats may have unpatched vulnerabilities. The _use_new_zipfile_serialization=False flag "
        "indicates use of the older, less secure format."
    ),
}

# Explanations for suspicious TensorFlow operations
#
# Risk Categories:
# - CRITICAL: Code execution (PyFunc, PyCall, ExecuteOp, ShellExecute), native library loading
#   (LoadLibrary/LoadLibraryV2), & System access (SystemConfig)
# - HIGH: File system operations (ReadFile, WriteFile, Save, SaveV2, MergeV2Checkpoints)
# - MEDIUM: Data processing with potential exploits (DecodeRaw, DecodeJpeg, DecodePng)
#
# Threat Context: Malicious ML models embed these operations to execute during model loading/inference,
# bypassing security tools that typically trust ML models. Used for RCE, data exfiltration, backdoors,
# and supply chain attacks.
TF_OP_EXPLANATIONS = {
    # Code execution operations - CRITICAL RISK
    "PyFunc": (
        "The PyFunc operation executes arbitrary Python code in the TensorFlow graph, which attackers can "
        "abuse to run system commands or other malicious code."
    ),
    "PyFuncStateless": (
        "The PyFuncStateless operation executes arbitrary Python code without maintaining state between calls, "
        "which attackers can abuse to run system commands or other malicious code."
    ),
    "EagerPyFunc": (
        "The EagerPyFunc operation executes arbitrary Python code in eager execution mode, which attackers can "
        "abuse to run system commands or other malicious code during model loading or inference."
    ),
    "PyCall": (
        "The PyCall operation invokes Python callbacks during graph execution, creating dangerous security risks "
        "by allowing arbitrary code execution that could compromise the system."
    ),
    "ExecuteOp": (
        "ExecuteOp allows running arbitrary operations and poses severe security risks by enabling "
        "malicious code execution that could compromise the host system."
    ),
    # System operations - CRITICAL RISK
    "ShellExecute": (
        "ShellExecute runs shell commands from the TensorFlow graph, posing severe security risks by enabling "
        "arbitrary command execution, potentially compromising the host system."
    ),
    "LoadLibrary": (
        "LoadLibrary loads native TensorFlow op libraries from the graph, creating dangerous security risks "
        "because an untrusted model can point runtime execution at attacker-controlled native code."
    ),
    "LoadLibraryV2": (
        "LoadLibraryV2 loads native TensorFlow op libraries from the graph, creating dangerous security risks "
        "because an untrusted model can point runtime execution at attacker-controlled native code."
    ),
    "SystemConfig": (
        "SystemConfig operations access or modify system configuration, creating dangerous security risks "
        "by enabling reconnaissance or privilege escalation attacks."
    ),
    # File system operations - HIGH RISK
    "ReadFile": (
        "ReadFile retrieves data from arbitrary files; malicious models could exfiltrate secrets or read "
        "sensitive files."
    ),
    "WriteFile": (
        "WriteFile writes data to arbitrary locations, which could overwrite files or drop malicious payloads."
    ),
    "Save": (
        "Save operations write checkpoint data. Attackers might use them to persist malicious data or "
        "overwrite existing files."
    ),
    "SaveV2": ("SaveV2 is a variant of Save with similar risks of writing arbitrary files during graph execution."),
    "MergeV2Checkpoints": (
        "MergeV2Checkpoints manipulates TensorFlow checkpoints by reading and writing checkpoint files, "
        "which could be used to overwrite existing files or inject malicious parameters."
    ),
    # Data processing operations - MEDIUM RISK
    "DecodeRaw": ("DecodeRaw processes raw binary data that may be malicious or cause resource exhaustion."),
    "DecodeJpeg": (
        "DecodeJpeg decodes JPEG images; crafted images may exploit vulnerabilities or consume excessive resources."
    ),
    "DecodePng": ("DecodePng decodes PNG data, which could be abused with malformed inputs."),
    # Checkpoint and table operations - HIGH RISK
    "LoadAndRemapMatrix": (
        "LoadAndRemapMatrix loads matrix data from arbitrary file paths, which could be used to read "
        "sensitive files or load malicious data into the model."
    ),
    "RestoreV2": (
        "RestoreV2 restores checkpoint data from files, enabling file system access that could be used "
        "to read sensitive data or load malicious parameters."
    ),
    "ParseTensor": (
        "ParseTensor deserializes serialized tensor payloads from strings, which attackers could abuse to "
        "feed malicious data into downstream graph logic or unsafe parsing paths."
    ),
    "LookupTableImport": (
        "LookupTableImport imports data from external files into lookup tables, which could be used to "
        "read sensitive files or inject malicious data."
    ),
    "InitializeTable": (
        "InitializeTable initializes lookup tables from external files, which could be used to read "
        "sensitive files or inject malicious data during model initialization."
    ),
    "LookupTableImportV2": (
        "LookupTableImportV2 imports data from external files into lookup tables (V2 variant), which could "
        "be used to read sensitive files or inject malicious data."
    ),
    "InitializeTableV2": (
        "InitializeTableV2 initializes lookup tables from external files (V2 variant), which could be used "
        "to read sensitive files or inject malicious data during model initialization."
    ),
    # Queue operations - MEDIUM RISK (data exfiltration)
    "QueueEnqueue": (
        "QueueEnqueue enqueues data to TensorFlow queues, which could be used as a data exfiltration "
        "vector to send sensitive information to external systems."
    ),
    "QueueEnqueueV2": (
        "QueueEnqueueV2 enqueues data to TensorFlow queues (V2 variant), which attackers could abuse as a "
        "data exfiltration vector to send sensitive information to external systems."
    ),
    "QueueDequeue": (
        "QueueDequeue dequeues data from TensorFlow queues, which could be used as a data exfiltration "
        "vector or to inject malicious data into the inference pipeline."
    ),
    "QueueDequeueV2": (
        "QueueDequeueV2 dequeues data from TensorFlow queues (V2 variant), which could be used as a data "
        "exfiltration vector or to inject malicious data into the inference pipeline."
    ),
    "QueueEnqueueMany": (
        "QueueEnqueueMany batch enqueues data to TensorFlow queues, which attackers could abuse as a "
        "high-throughput data exfiltration vector to send large amounts of sensitive information."
    ),
    "QueueDequeueMany": (
        "QueueDequeueMany batch dequeues data from TensorFlow queues, which attackers could abuse as a "
        "high-throughput data exfiltration vector or to inject large amounts of malicious data."
    ),
    # Side-channel operations - MEDIUM RISK
    "Print": (
        "Print outputs data to stdout, which attackers could abuse as a side-channel to leak sensitive "
        "information such as model parameters, input data, or system information."
    ),
    "PrintV2": (
        "PrintV2 outputs data to stdout (V2 variant), which attackers could abuse as a side-channel to leak "
        "sensitive information such as model parameters, input data, or system information."
    ),
    # Denial of service operations - MEDIUM RISK
    "Assert": (
        "Assert can crash inference pipelines if assertions fail, which could be used for denial of service "
        "attacks or to cause unexpected behavior in production systems."
    ),
    "Abort": (
        "Abort immediately terminates execution, which could be used for denial of service attacks "
        "to crash inference pipelines or disrupt production systems."
    ),
}


# Function to get explanation for a security issue
def get_explanation(category: str, specific_item: str | None = None) -> str | None:
    """
    Get a security explanation for a given category and item.

    Args:
        category: The category of security issue ('import', 'opcode', 'pattern', 'tf_op')
        specific_item: The specific item (e.g., 'os', 'REDUCE', 'base64_payload', 'PyFunc')

    Returns:
        A security-team-friendly explanation, or None if not found
    """
    # Use pattern matching for cleaner category-based lookups (Python 3.10+)
    match category:
        case "import" if specific_item in DANGEROUS_IMPORTS:
            return DANGEROUS_IMPORTS[specific_item]
        case "opcode" if specific_item in DANGEROUS_OPCODES:
            return DANGEROUS_OPCODES[specific_item]
        case "pattern" if specific_item in PATTERN_EXPLANATIONS:
            return PATTERN_EXPLANATIONS[specific_item]
        case "tf_op" if specific_item in TF_OP_EXPLANATIONS:
            return TF_OP_EXPLANATIONS[specific_item]

    return None


# Convenience functions for common use cases
def get_import_explanation(module_name: str) -> str | None:
    """Get explanation for a dangerous import/module."""
    if module_name in DANGEROUS_IMPORTS:
        return get_explanation("import", module_name)

    parts = module_name.split(".")
    for i in range(len(parts) - 1, 0, -1):
        parent = ".".join(parts[:i])
        if parent in DANGEROUS_IMPORTS:
            return get_explanation("import", parent)

    base_module = parts[0]
    return get_explanation("import", base_module)


def get_opcode_explanation(opcode_name: str) -> str | None:
    """Get explanation for a dangerous pickle opcode."""
    return get_explanation("opcode", opcode_name)


def get_pattern_explanation(pattern_name: str) -> str | None:
    """Get explanation for a suspicious pattern."""
    return get_explanation("pattern", pattern_name)


def get_tf_op_explanation(op_name: str) -> str | None:
    """Get explanation for a suspicious TensorFlow operation."""
    return get_explanation("tf_op", op_name)


# Default explanations for common issue messages when no explicit "why"
# is provided at the call site.
COMMON_MESSAGE_EXPLANATIONS = {
    # Archive and compression security issues
    "Maximum ZIP nesting depth": (
        "Deeply nested archives can be used to hide malicious content or create"
        " zip bombs that exhaust system resources during extraction."
    ),
    "ZIP file contains too many entries": (
        "Large numbers of archive entries may indicate a malicious zip bomb designed to"
        " overwhelm the scanner or extraction process."
    ),
    "Archive entry": (
        "Archive paths should never resolve outside the extraction directory as"
        " this enables path traversal attacks where attackers can overwrite arbitrary files."
    ),
    "Symlink": (
        "Symlinks inside archives can point to sensitive locations and enable path traversal attacks when extracted."
    ),
    "Decompressed size too large": (
        "Maliciously crafted compressed data can expand to enormous sizes"
        " (compression bombs) to exhaust system memory and crash the application."
    ),
    "Not a valid zip file": (
        "Corrupted or malformed archives could be used to crash tools or hide malicious payloads."
    ),
    # File integrity and validation issues
    "File too small": (
        "Files smaller than expected may be truncated or corrupted, which is"
        " often a sign of tampering or incomplete downloads."
    ),
    "File too large": (
        "Extremely large files may be used for denial-of-service attacks by"
        " exhausting system resources during processing."
    ),
    "File type validation failed": (
        "Mismatched file headers and extensions may indicate file spoofing attacks"
        " where malicious content is disguised as a legitimate model format."
    ),
    # ML-specific security patterns
    "Custom objects found": (
        "Custom objects in ML models can contain arbitrary Python code that executes"
        " during model loading, potentially compromising the system."
    ),
    "External reference": (
        "External file references in models can be used to access sensitive data"
        " or load malicious content from outside the model file."
    ),
    "Lambda layer": (
        "Lambda layers in neural networks can execute arbitrary Python code during"
        " model inference, bypassing normal security controls."
    ),
    "Custom layer": (
        "Custom layers may contain untrusted code that executes during model"
        " operations, potentially performing malicious actions."
    ),
    "Unusual layer configuration": (
        "Non-standard layer configurations may indicate model tampering or"
        " hidden functionality designed to bypass security measures."
    ),
    "Custom metric": (
        "Custom metrics can execute arbitrary code during training or evaluation,"
        " potentially compromising the ML pipeline."
    ),
    "Custom loss function": (
        "Custom loss functions may contain malicious code that executes during model training or inference."
    ),
    # Dependency and module issues
    "Module not installed": (
        "Missing required modules may indicate supply chain attacks where"
        " attackers rely on users installing malicious packages."
    ),
    "Import error": (
        "Import failures may indicate tampered dependencies or attempts to"
        " load malicious modules not present in the environment."
    ),
    "Deprecated module": ("Deprecated modules may have unpatched security vulnerabilities that attackers can exploit."),
    # General security and scanning issues
    "Too many": (
        "Excessive quantities of data structures may indicate a malicious attempt"
        " to overwhelm the system or hide malicious content."
    ),
    "Error scanning": (
        "Scanning errors may indicate corrupted files, unsupported formats, or"
        " malicious content designed to crash security tools."
    ),
    "Timeout": (
        "Processing timeouts may indicate maliciously crafted content designed"
        " to cause denial-of-service by consuming excessive computational resources."
    ),
    "Memory limit exceeded": (
        "Excessive memory usage may indicate malicious content designed to"
        " crash the system or hide attacks within resource exhaustion."
    ),
    # Metadata and configuration issues
    "Missing metadata": (
        "Missing or incomplete metadata may indicate tampered models or attempts to hide malicious modifications."
    ),
    "Invalid metadata": (
        "Corrupted metadata may indicate file tampering or malicious modifications to model configurations."
    ),
    "Unexpected metadata": (
        "Unusual metadata fields may contain hidden payloads or indicate model tampering by malicious actors."
    ),
}


def get_message_explanation(message: str, context: str | None = None) -> str | None:
    """Return a default explanation for an issue message if available.

    Args:
        message: The issue message to find an explanation for
        context: Optional context to provide more specific explanations
                (e.g., scanner name, file type, etc.)

    Returns:
        An explanation string if a matching pattern is found, None otherwise
    """
    # First try to find a basic explanation
    base_explanation = None
    for prefix, explanation in COMMON_MESSAGE_EXPLANATIONS.items():
        if message.startswith(prefix):
            base_explanation = explanation
            break

    # If no base explanation found, return None
    if base_explanation is None:
        return None

    # If context is provided, try to enhance the explanation
    if context:
        enhanced_explanation = _enhance_explanation_with_context(message, base_explanation, context)
        if enhanced_explanation:
            return enhanced_explanation

    return base_explanation


def _enhance_explanation_with_context(message: str, base_explanation: str, context: str) -> str | None:
    """Enhance explanations based on context information."""
    context_lower = context.lower()

    # ML model-specific context enhancements
    if any(scanner in context_lower for scanner in ["pickle", "pytorch", "keras", "tensorflow"]):
        if message.startswith("Custom objects found"):
            return (
                "Custom objects in ML models can execute arbitrary Python code during model loading. "
                "This is particularly dangerous in pickle-based formats where object deserialization "
                "can trigger immediate code execution without user consent."
            )
        if message.startswith("File too large"):
            return (
                "Extremely large model files may indicate embedded malicious data or denial-of-service "
                "attacks. ML models with unexpectedly large sizes should be verified for legitimate "
                "architectural reasons before deployment."
            )

    # Archive-specific context enhancements
    elif any(scanner in context_lower for scanner in ["zip", "tar", "archive"]):
        if message.startswith("Archive entry"):
            return (
                "Archive path traversal is especially dangerous in ML model deployments where "
                "automated systems may extract models to predictable locations, enabling "
                "attackers to overwrite critical system files or model configurations."
            )

    # ONNX/compiled model context
    elif any(scanner in context_lower for scanner in ["onnx", "tflite", "compiled"]) and message.startswith("Custom"):
        return (
            base_explanation + " In compiled models, custom components may bypass "
            "the sandboxing that interpreted models provide, making them particularly risky."
        )

    # Return None if no context-specific enhancement applies
    return None


def _get_explanation_with_default(explanations: dict[str, str], explanation_type: str, default: str) -> str:
    """Return a mapped explanation or a deterministic fallback string."""
    return explanations.get(explanation_type, default)


# CVE-2025-32434 Specific Explanations
def get_cve_2025_32434_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2025-32434 vulnerability types"""

    explanations = {
        "pytorch_version": (
            "CVE-2025-32434 affects PyTorch versions ≤2.5.1 and allows remote code execution "
            "when loading models with torch.load(weights_only=True). The 'weights_only=True' "
            "parameter was commonly believed to provide security protection, but this "
            "vulnerability demonstrates that malicious pickle files can still execute "
            "arbitrary code regardless of this setting. Upgrade to PyTorch 2.6.0+ immediately."
        ),
        "weights_only_false_security": (
            "This model contains dangerous pickle opcodes that can execute arbitrary code "
            "even when loaded with torch.load(weights_only=True). This is the core of "
            "CVE-2025-32434 - the 'weights_only=True' parameter does NOT provide security "
            "protection against sophisticated attacks. The parameter is a feature flag, not "
            "a security boundary. Never rely on it for security with untrusted models."
        ),
        "dangerous_opcodes": (
            "The detected opcodes (REDUCE, INST, OBJ, NEWOBJ, STACK_GLOBAL, BUILD) are "
            "fundamental pickle operations that enable arbitrary code execution. These "
            "opcodes can invoke __reduce__ methods, instantiate arbitrary classes, and "
            "import dangerous modules. CVE-2025-32434 exploits the fact that torch.load() "
            "processes these opcodes even with weights_only=True, allowing malicious models "
            "to execute code during the loading process."
        ),
        "opcode_sequences": (
            "Specific opcode sequences have been identified that indicate CVE-2025-32434 "
            "exploitation attempts. These include PyTorch imports followed by execution "
            "opcodes, chained REDUCE operations for complex payloads, and eval/exec "
            "patterns with embedded string data. These sequences represent sophisticated "
            "attacks designed to bypass the weights_only=True assumption."
        ),
        "torchscript_vulnerabilities": (
            "TorchScript models can contain embedded code that executes during compilation "
            "or loading. CVE-2025-32434 can be combined with TorchScript injection to "
            "create multi-stage attacks. Dangerous patterns include serialization injection, "
            "module manipulation, hook injection, and bytecode-level code execution. "
            "These attacks can persist even after model loading completes."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "This issue is related to CVE-2025-32434, a critical PyTorch vulnerability. "
        "Review the CVE documentation and update to PyTorch 2.6.0+ immediately.",
    )


def get_cve_2026_24747_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2026-24747 vulnerability types."""

    explanations = {
        "setitem_abuse": (
            "CVE-2026-24747 exploits a flaw in PyTorch's weights_only=True restricted "
            "unpickler that allows SETITEM/SETITEMS opcodes to operate on unexpected "
            "object types. In legitimate pickles, SETITEM populates dicts. In this attack, "
            "SETITEM is applied to reconstructed tensor objects, allowing the attacker to "
            "manipulate object attributes and achieve heap layout control for code execution."
        ),
        "tensor_metadata_mismatch": (
            "This model contains tensor storage declarations that do not match the actual "
            "binary blob sizes in the archive. CVE-2026-24747 exploits such mismatches to "
            "cause the restricted unpickler to allocate incorrectly sized memory regions, "
            "enabling heap layout manipulation. Legitimate PyTorch models always have "
            "consistent tensor metadata."
        ),
        "restricted_unpickler_bypass": (
            "Unlike CVE-2025-32434 (where weights_only=True did not enforce restrictions), "
            "CVE-2026-24747 bypasses the enforcement mechanism itself. The restricted unpickler "
            "correctly blocks REDUCE/GLOBAL with dangerous modules, but fails to restrict "
            "SETITEM/SETITEMS on non-dict objects, allowing type confusion attacks that "
            "ultimately achieve control flow hijacking."
        ),
        "pytorch_version": (
            "CVE-2026-24747 affects all PyTorch versions before 2.10.0. The fix adds type "
            "checking to SETITEM/SETITEMS opcodes in the restricted unpickler, ensuring they "
            "can only operate on dict objects. Upgrade immediately and consider SafeTensors."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "This issue is related to CVE-2026-24747, a high-severity PyTorch vulnerability "
        "that bypasses weights_only=True via SETITEM abuse. Update to PyTorch 2.10.0+.",
    )


def get_cve_2025_51480_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2025-51480 (ONNX external-data write traversal)."""

    explanations = {
        "arbitrary_file_overwrite": (
            "CVE-2025-51480 (CVSS 8.8): onnx.save() with external data can write "
            "tensor bytes to attacker-controlled external_data locations. If a "
            "location includes path traversal, saving a malicious model may "
            "overwrite arbitrary files outside the model directory."
        ),
        "path_traversal": (
            "ONNX external_data locations are file paths. Traversal components "
            "like '../' can escape the output directory and redirect writes to "
            "sensitive files when save_external_data is used."
        ),
        "onnx_version": (
            "CVE-2025-51480 affects ONNX versions through 1.17.0. Upgrade to a "
            "patched version, validate external_data paths, and run model "
            "processing with least privilege."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2025-51480: ONNX external_data path traversal can enable arbitrary file overwrite during save operations.",
    )


def get_cve_2022_45907_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2022-45907 vulnerability types."""

    explanations = {
        "eval_injection": (
            "CVE-2022-45907 exploits torch.jit.annotations.parse_type_line(), which passes "
            "user-controlled type annotation strings directly to Python's eval(). An attacker "
            "can craft a malicious type annotation string that, when parsed, executes arbitrary "
            "code. This affects any code path that processes untrusted TorchScript type annotations."
        ),
        "type_annotation_parsing": (
            "The vulnerable function parse_type_line in torch.jit.annotations processes type "
            "annotation strings from TorchScript models. Since it uses eval() internally, any "
            "string that reaches this function can execute arbitrary Python code, including "
            "system commands, file operations, and network access."
        ),
        "pytorch_version": (
            "CVE-2022-45907 affects all PyTorch versions before 1.13.1. The fix replaces the "
            "unsafe eval()-based type parsing with a safe AST-based parser. Upgrade to "
            "PyTorch 1.13.1+ immediately and avoid processing type annotations from untrusted sources."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "This issue is related to CVE-2022-45907, a critical PyTorch vulnerability "
        "involving unsafe eval() in type annotation parsing. Update to PyTorch 1.13.1+.",
    )


def get_cve_2024_5480_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2024-5480 vulnerability types."""

    explanations = {
        "rpc_function_injection": (
            "CVE-2024-5480 exploits the torch.distributed.rpc framework's lack of function "
            "call validation. The RPC framework accepts arbitrary callable references, including "
            "builtins.eval and builtins.exec, allowing a remote attacker to execute arbitrary "
            "code on any node in the distributed training cluster."
        ),
        "python_udf_exploit": (
            "The PythonUDF mechanism in torch.distributed.rpc allows sending arbitrary Python "
            "functions to remote workers. Without validation, an attacker can send eval() or "
            "exec() calls as PythonUDF payloads, achieving remote code execution on the target "
            "node. This is especially dangerous in distributed training setups."
        ),
        "pytorch_version": (
            "CVE-2024-5480 (CVSS 10.0) affects all PyTorch versions before 2.2.3. The fix adds "
            "validation to restrict which functions can be called via RPC. Upgrade to "
            "PyTorch 2.2.3+ immediately and restrict RPC access to trusted nodes only."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "This issue is related to CVE-2024-5480, a maximum-severity PyTorch vulnerability "
        "in the RPC framework. Update to PyTorch 2.2.3+ and restrict RPC access.",
    )


def get_cve_2024_48063_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2024-48063 vulnerability types."""

    explanations = {
        "remote_module_deserialization": (
            "CVE-2024-48063 exploits the deserialization of torch.distributed.rpc.RemoteModule "
            "objects. RemoteModule uses Python's pickle for serialization, and its __reduce__ "
            "method can be crafted to execute arbitrary code during deserialization. An attacker "
            "can create a malicious RemoteModule pickle payload that runs code when loaded."
        ),
        "rpc_pickle_exploit": (
            "The RemoteModule class in torch.distributed.rpc serializes its state using pickle. "
            "Since pickle deserialization can execute arbitrary code via __reduce__, an attacker "
            "who can inject a crafted RemoteModule payload into the RPC communication channel "
            "can achieve remote code execution. This is disputed by PyTorch maintainers as "
            "'intended behavior' since pickle is inherently unsafe."
        ),
        "pytorch_version": (
            "CVE-2024-48063 affects all PyTorch versions before 2.5.0. While disputed as "
            "'intended behavior,' the vulnerability poses real risks in environments where "
            "RemoteModule objects may come from untrusted sources. Upgrade to PyTorch 2.5.0+ "
            "and avoid deserializing RemoteModule objects from untrusted sources."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "This issue is related to CVE-2024-48063, a critical PyTorch vulnerability "
        "involving RemoteModule deserialization. Update to PyTorch 2.5.0+.",
    )


def get_pytorch_security_explanation(issue_type: str) -> str:
    """Get PyTorch-specific security explanations"""

    explanations = {
        "pickle_serialization": (
            "PyTorch models use Python's pickle format for serialization, which is inherently "
            "unsafe. Pickle can execute arbitrary code during deserialization through __reduce__ "
            "methods, class instantiation, and module imports. This is not a bug but a "
            "fundamental design characteristic. Use SafeTensors format for better security."
        ),
        "model_source_validation": (
            "Model files should only be loaded from trusted, verified sources. Implement "
            "cryptographic signature verification, hash validation, and supply chain security "
            "practices. Never load models from untrusted URLs, user uploads, or unverified "
            "repositories without thorough security scanning."
        ),
        "safe_loading_practices": (
            "Safe model loading requires: (1) PyTorch 2.6.0+, (2) weights_only=True as basic "
            "precaution, (3) model source validation, (4) hash verification, (5) security "
            "scanning with tools like ModelAudit, and (6) sandboxed loading for untrusted "
            "models. Consider migrating to SafeTensors format for inherent safety."
        ),
        "torchscript_security": (
            "TorchScript models contain compiled code that can include dangerous operations. "
            "Validate all script modules for unsafe operations, avoid dynamic code generation, "
            "and review hook functions for malicious behavior. TorchScript can bypass some "
            "Python-level security controls, making validation critical."
        ),
    }

    return explanations.get(
        issue_type,
        "This is a PyTorch-specific security concern. Review PyTorch security best practices "
        "and ensure you're following safe model loading procedures.",
    )


def get_cve_2025_9906_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-9906: Keras enable_unsafe_deserialization config bypass.

    CVE-2025-9906 (HIGH): config.json in .keras archives can invoke
    keras.config.enable_unsafe_deserialization() to disable safe_mode from within
    the loading process, then include malicious Lambda layers. Fixed in Keras 3.11.0.
    """
    explanations = {
        "config_bypass": (
            "CVE-2025-9906: The config.json inside this .keras archive references "
            "enable_unsafe_deserialization, which can disable safe_mode from within the "
            "deserialization process itself. This allows an attacker to bypass safe_mode=True "
            "and then load malicious Lambda layers or other unsafe components. "
            "Upgrade to Keras >= 3.11.0 and only load models from trusted sources."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-9906: config.json can disable safe_mode via enable_unsafe_deserialization. "
        "Upgrade to Keras >= 3.11.0.",
    )


def get_cve_2025_49655_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-49655: Keras TorchModuleWrapper deserialization RCE.

    CVE-2025-49655 (CVSS 9.8 CRITICAL): TorchModuleWrapper layer in Keras 3.11.0-3.11.2
    calls torch.load(weights_only=False) in from_config(), enabling arbitrary code execution
    via pickle deserialization. Fixed in Keras 3.11.3.
    """
    explanations = {
        "torch_module_wrapper": (
            "CVE-2025-49655: The TorchModuleWrapper layer in Keras 3.11.0-3.11.2 calls "
            "torch.load(weights_only=False) during from_config() deserialization, which allows "
            "arbitrary code execution via crafted pickle payloads in the model weights. "
            "Any .keras model containing a TorchModuleWrapper layer is potentially exploitable. "
            "Upgrade to Keras >= 3.11.3 where weights_only=True is enforced."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-49655: TorchModuleWrapper uses unsafe torch.load deserialization. Upgrade to Keras >= 3.11.3.",
    )


def get_cve_2025_12058_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-12058: Keras StringLookup vocabulary path loading.

    CVE-2025-12058 (CVSS 5.9 MODERATE): A crafted .keras archive can configure
    StringLookup with a local or remote vocabulary path. During model loading,
    Keras may read arbitrary local files or make remote requests even with
    safe_mode=True. Fixed in Keras 3.12.0.
    """
    explanations = {
        "stringlookup_external_vocabulary": (
            "CVE-2025-12058: This .keras archive configures a StringLookup layer with a "
            "vocabulary value that points to an external path or URL. In affected Keras "
            "versions, Model.load_model may read arbitrary local files or make server-side "
            "requests while loading the model, even when safe_mode=True is enabled. "
            "Upgrade to Keras >= 3.12.0 and avoid models that rely on external vocabulary paths."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-12058: StringLookup vocabulary paths can load local files or remote URLs. "
        "Upgrade to Keras >= 3.12.0.",
    )


def get_cve_2025_12060_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-12060: Keras get_file archive extraction traversal.

    CVE-2025-12060 (CVSS 8.8 HIGH): A crafted .keras archive can configure
    keras.utils.get_file(extract=True) with a remote tar archive. During model
    loading, affected Keras versions may extract traversal or symlink entries
    outside the intended cache directory. Fixed in Keras 3.12.0.
    """
    explanations = {
        "get_file_extract_tar": (
            "CVE-2025-12060: The config.json references keras.utils.get_file with "
            "extract=True and a remote tar-like archive URL. In affected Keras versions, "
            "loading the model may download and extract attacker-controlled archive entries "
            "that traverse outside the intended destination. Upgrade to Keras >= 3.12.0 "
            "and reject untrusted models that fetch and extract remote archives."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-12060: keras.utils.get_file(extract=True) can extract remote tar archives "
        "with traversal entries. Upgrade to Keras >= 3.12.0.",
    )


def get_cve_2025_1550_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-1550: Keras safe_mode bypass via config.json module references.

    CVE-2025-1550 (CVSS 9.8 CRITICAL): Keras Model.load_model allows arbitrary code execution
    even with safe_mode=True by specifying arbitrary Python modules/functions in config.json
    inside .keras ZIP archives. Fixed in Keras 3.9.0.
    """
    explanations = {
        "dangerous_module": (
            "CVE-2025-1550: The config.json inside this .keras archive references a dangerous "
            "Python module (e.g., os, subprocess, builtins) in a layer's module or fn_module field. "
            "Keras versions < 3.9.0 import and execute these modules during Model.load_model even "
            "with safe_mode=True, enabling arbitrary code execution. "
            "Upgrade to Keras >= 3.9.0 and re-save models from trusted sources only."
        ),
        "untrusted_module": (
            "CVE-2025-1550: The config.json inside this .keras archive references a Python module "
            "outside the standard Keras/TensorFlow ecosystem in a layer's module or fn_module field. "
            "Keras versions < 3.9.0 do not restrict which modules can be referenced in config.json, "
            "allowing safe_mode bypass. While this module may be benign, verify it is not being used "
            "to execute arbitrary code. Upgrade to Keras >= 3.9.0."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-1550: Keras config.json module references may bypass safe_mode. Upgrade to Keras >= 3.9.0.",
    )


def get_cve_2025_8747_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-8747: Keras get_file gadget bypass.

    CVE-2025-8747 (HIGH): Bypass of CVE-2025-1550 fix. Uses keras.utils.get_file
    as a gadget to download and execute arbitrary files even with safe_mode=True.
    Fixed in Keras 3.11.0.
    """
    explanations = {
        "get_file_gadget": (
            "CVE-2025-8747: The config.json references keras.utils.get_file along with "
            "a URL, indicating a potential safe_mode bypass. This gadget can download "
            "arbitrary files from remote URLs during model loading, even with safe_mode=True. "
            "This bypasses the CVE-2025-1550 module allowlist fix. "
            "Upgrade to Keras >= 3.11.0 and only load models from trusted sources."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-8747: keras.utils.get_file can be abused as a gadget to bypass safe_mode. "
        "Upgrade to Keras >= 3.11.0.",
    )


def get_cve_2025_9905_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2025-9905: Keras H5 safe_mode ignored for Lambda layers.

    CVE-2025-9905 (CVSS 7.3 HIGH): Keras Model.load_model silently ignores
    safe_mode=True when loading .h5/.hdf5 files. Lambda layers execute arbitrary
    code without any safe mode check. Fixed in Keras 3.11.3.
    """
    explanations = {
        "h5_safe_mode_bypass": (
            "CVE-2025-9905: Keras Model.load_model silently ignores safe_mode=True when "
            "loading H5/HDF5 files. Lambda layers in H5 models can execute arbitrary Python "
            "code during deserialization with no safe mode protection. This means passing "
            "safe_mode=True provides a false sense of security for H5 format models. "
            "Upgrade to Keras >= 3.11.3 or convert models to .keras format which supports safe_mode."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2025-9905: H5 format ignores safe_mode=True for Lambda layers. Upgrade to Keras >= 3.11.3.",
    )


def get_cve_2024_3660_explanation(issue_type: str) -> str:
    """Get explanation for CVE-2024-3660: Keras Lambda layer code injection.

    CVE-2024-3660 (CVSS 9.8 CRITICAL): Keras Lambda layers allow arbitrary Python
    code injection during model loading. The code is executed when the model is
    deserialized, enabling remote code execution. Fixed in Keras 2.13.
    """
    explanations = {
        "lambda_code_injection": (
            "CVE-2024-3660: Keras Lambda layers contain arbitrary Python code that executes "
            "during model loading/deserialization. An attacker can craft a malicious model "
            "with Lambda layers that run arbitrary code when the model is loaded. "
            "Remove Lambda layers from untrusted models or upgrade Keras to >= 2.13 "
            "which adds safe_mode protections (though note H5 format safe_mode has its own "
            "issues per CVE-2025-9905)."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        issue_type,
        "CVE-2024-3660: Lambda layers enable arbitrary code injection during model loading. Upgrade to Keras >= 2.13.",
    )


def get_cve_2022_25882_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2022-25882 (ONNX external_data path traversal)."""
    explanations = {
        "path_traversal": (
            "CVE-2022-25882 (CVSS 7.5): ONNX models can reference external data files "
            "using the external_data location field. By using path traversal sequences "
            "like '../../etc/passwd', an attacker can craft an ONNX model that reads "
            "arbitrary files from the filesystem when loaded. This enables information "
            "disclosure attacks, including reading sensitive configuration files, SSH keys, "
            "and other private data."
        ),
        "directory_escape": (
            "The external_data location field resolves to a path outside the model "
            "directory. This is a directory traversal attack that bypasses the expected "
            "sandboxing of model files. Legitimate ONNX models should only reference "
            "external data files within the same directory as the model file."
        ),
        "onnx_version": (
            "CVE-2022-25882 affects ONNX versions prior to 1.13.0. The fix adds "
            "validation to reject external data paths that resolve outside the model "
            "directory. Update to ONNX 1.13.0 or later and validate model files before "
            "loading with untrusted inputs."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2022-25882: ONNX external_data path traversal vulnerability. "
        "Validate that external_data paths do not escape the model directory.",
    )


def get_cve_2024_27318_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2024-27318 (ONNX nested path traversal bypass)."""
    explanations = {
        "nested_traversal": (
            "CVE-2024-27318 (CVSS 7.5): ONNX external_data locations that start "
            "with a legitimate directory prefix followed by '../' segments bypass "
            "the lstrip-based sanitization added for CVE-2022-25882. For example, "
            "'subdir/../../etc/passwd' passes the lstrip('.') check but still "
            "resolves outside the model directory."
        ),
        "onnx_version": (
            "CVE-2024-27318 affects ONNX versions through 1.15.x where the "
            "external_data path validation relied on lstrip-based sanitization. "
            "Upgrade to ONNX >= 1.16.0 and validate that external_data paths "
            "resolve within the model directory."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2024-27318: ONNX nested path traversal bypasses CVE-2022-25882 "
        "sanitization via paths like 'subdir/../../etc/passwd'. Validate "
        "external_data paths resolve within the model directory.",
    )


def get_cve_2019_6446_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2019-6446 (NumPy allow_pickle RCE)."""
    explanations = {
        "object_dtype": (
            "CVE-2019-6446 (CVSS 9.8): NumPy .npy/.npz files with object dtype "
            "use pickle serialization to store arbitrary Python objects. When "
            "numpy.load() is called with allow_pickle=True (the default before "
            "NumPy 1.16.3), these files can execute arbitrary code during "
            "deserialization. The attacker embeds malicious pickle payloads in "
            "the array data that execute when loaded."
        ),
        "allow_pickle": (
            "Prior to NumPy 1.16.3, numpy.load() defaulted to allow_pickle=True, "
            "which automatically deserializes pickled objects in .npy/.npz files. "
            "After the fix, allow_pickle defaults to False and raises an error "
            "when loading object arrays. However, many codebases still explicitly "
            "pass allow_pickle=True, remaining vulnerable."
        ),
        "numpy_version": (
            "CVE-2019-6446 was addressed in NumPy 1.16.3 by changing the "
            "default of allow_pickle from True to False. Update to NumPy >= "
            "1.16.3 and ensure your code never uses allow_pickle=True with "
            "untrusted input files. Prefer numeric dtypes over object arrays."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2019-6446: NumPy allow_pickle enables RCE via object dtype arrays. "
        "Use NumPy >= 1.16.3 and never allow_pickle=True with untrusted files.",
    )


def get_cve_2025_23304_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2025-23304 (NeMo Hydra _target_ injection)."""
    explanations = {
        "hydra_target_injection": (
            "CVE-2025-23304 (CVSS 7.6): NVIDIA NeMo model files (.nemo) contain "
            "YAML configuration with Hydra _target_ fields that specify Python "
            "callables to instantiate. An attacker can set _target_ to dangerous "
            "functions like os.system or subprocess.call. When the model is loaded "
            "and hydra.utils.instantiate() processes the config, arbitrary code "
            "executes. Over 700 models on HuggingFace use the NeMo format."
        ),
        "dangerous_target": (
            "The _target_ field references a known dangerous Python callable "
            "such as os.system, subprocess.Popen, eval, or exec. Hydra will "
            "attempt to import and call this function with the remaining config "
            "values as arguments, enabling full remote code execution."
        ),
        "nemo_version": (
            "CVE-2025-23304 was fixed in NeMo 2.3.2 which adds safe_instantiate() "
            "to validate _target_ values before execution. This function recursively "
            "checks all _target_ values in the config and rejects dangerous ones. "
            "Update to NeMo >= 2.3.2 and never load .nemo files from untrusted sources."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2025-23304: NeMo Hydra _target_ injection enables RCE via malicious "
        "model metadata. Update to NeMo >= 2.3.2.",
    )


def get_cve_2026_1669_explanation(vulnerability_type: str) -> str:
    """Get specific explanation for CVE-2026-1669 (Keras HDF5 external reference disclosure)."""
    explanations = {
        "hdf5_external_reference": (
            "CVE-2026-1669 (CVSS 8.1): Keras weight loading can follow HDF5 "
            "ExternalLink entries or external storage segments embedded in an "
            "HDF5 weight file, causing bytes from attacker-chosen host paths "
            "to be read into model tensors during deserialization. A crafted "
            ".h5 or .keras model can therefore disclose local files to the "
            "loaded model. Upgrade to Keras >= 3.12.1 or >= 3.13.2 and reject "
            "weights that use HDF5 external references."
        ),
        "keras_version": (
            "CVE-2026-1669 affects Keras versions >= 3.0.0, < 3.12.1 and >= "
            "3.13.0, < 3.13.2. Fixed releases harden loading against HDF5 "
            "external references in model weights. Update to Keras >= 3.12.1 "
            "or >= 3.13.2 and avoid loading untrusted HDF5 weights."
        ),
    }

    return _get_explanation_with_default(
        explanations,
        vulnerability_type,
        "CVE-2026-1669: Keras HDF5 weight loading can follow external references "
        "and disclose host file contents. Upgrade to Keras >= 3.12.1 or >= 3.13.2.",
    )
