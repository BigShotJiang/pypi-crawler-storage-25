"""Tests for streaming scan-and-delete functionality."""

import os
import pickle
import tempfile
import time
from collections.abc import Iterator
from pathlib import Path
from unittest.mock import patch

import pytest

from modelaudit.core import determine_exit_code, scan_model_directory_or_file, scan_model_streaming
from modelaudit.scanners.base import IssueSeverity, ScanResult
from modelaudit.utils.helpers.file_iterator import iterate_files_streaming
from modelaudit.utils.helpers.secure_hasher import compute_aggregate_hash


@pytest.fixture
def temp_test_files() -> Iterator[list[Path]]:
    """Create temporary test files for streaming."""
    files: list[Path] = []
    for i in range(3):
        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".txt") as tmp:
            tmp.write(f"Test content {i}")
            files.append(Path(tmp.name))
    yield files
    # Cleanup
    for file_path in files:
        if file_path.exists():
            file_path.unlink()


def create_mock_scan_result(bytes_scanned: int = 1024, with_critical_issue: bool = False) -> ScanResult:
    """Create a mock ScanResult for testing."""
    result = ScanResult(scanner_name="test_scanner")
    result.bytes_scanned = bytes_scanned
    result.success = True
    if with_critical_issue:
        result.add_issue("Detected malicious behavior", severity=IssueSeverity.CRITICAL, location="test.pkl")
    return result


def create_mock_location_scan_result(
    resolved_path: Path,
    *,
    issue_suffix: str = ":payload",
    check_suffix: str = " (weights)",
) -> ScanResult:
    """Create a mock result whose locations are anchored to the resolved target."""
    result = ScanResult(scanner_name="test_scanner")
    result.bytes_scanned = 128
    result.add_check(
        name="Suspicious Payload",
        passed=False,
        message="Detected malicious behavior",
        severity=IssueSeverity.CRITICAL,
        location=f"{resolved_path}{issue_suffix}",
    )
    result.add_check(
        name="Layout Inspection",
        passed=True,
        message="Model structure inspected",
        location=f"{resolved_path}{check_suffix}",
    )
    result.finish(success=True)
    return result


def test_scan_model_directory_or_file_streaming_path() -> None:
    """Ensure stream:// paths route to streaming analysis."""
    stream_url = "s3://bucket/model.pkl"
    scan_result = ScanResult(scanner_name="streaming")
    scan_result.bytes_scanned = 123
    scan_result.finish(success=True)

    with (
        patch("modelaudit.core.stream_analyze_file") as mock_stream,
        patch("modelaudit.scanners.get_scanner_for_file") as mock_scanner,
    ):
        dummy_scanner = object()
        mock_scanner.return_value = dummy_scanner
        mock_stream.return_value = (scan_result, True)

        result = scan_model_directory_or_file(f"stream://{stream_url}")

        args, kwargs = mock_scanner.call_args
        assert args[0] == stream_url
        assert "config" in kwargs
        mock_stream.assert_called_once_with(stream_url, dummy_scanner)
        assert result.files_scanned == 1
        assert result.bytes_scanned == 123
        assert determine_exit_code(result) == 0


def test_scan_model_directory_or_file_partial_streaming_path_returns_exit_code_2() -> None:
    """Partial stream:// analysis without findings should be explicit and fail closed."""
    stream_url = "s3://bucket/model.pkl"
    scan_result = ScanResult(scanner_name="streaming")
    scan_result.bytes_scanned = 128
    scan_result.finish(success=True)

    with (
        patch("modelaudit.core.stream_analyze_file") as mock_stream,
        patch("modelaudit.scanners.get_scanner_for_file") as mock_scanner,
    ):
        dummy_scanner = object()
        mock_scanner.return_value = dummy_scanner
        mock_stream.return_value = (scan_result, False)

        result = scan_model_directory_or_file(f"stream://{stream_url}")

    metadata = result.file_metadata[stream_url].model_dump()
    assert metadata["scan_outcome"] == "inconclusive"
    assert metadata["analysis_incomplete"] is True
    assert "streaming_analysis_incomplete" in metadata["scan_outcome_reasons"]
    assert "failed closed" in metadata["scan_outcome_message"]
    assert any(issue.message == "Streaming analysis was partial - only analyzed file header" for issue in result.issues)
    assert result.has_errors is False
    assert result.files_scanned == 1
    assert result.success is False
    assert determine_exit_code(result) == 2


def test_scan_model_directory_or_file_partial_streaming_security_finding_returns_exit_code_1() -> None:
    """Security findings should outrank partial stream:// analysis metadata."""
    stream_url = "s3://bucket/model.pkl"
    scan_result = ScanResult(scanner_name="streaming")
    scan_result.bytes_scanned = 128
    scan_result.add_issue(
        "Dangerous payload found in streamed prefix",
        severity=IssueSeverity.CRITICAL,
        location=stream_url,
    )
    scan_result.finish(success=True)

    with (
        patch("modelaudit.core.stream_analyze_file") as mock_stream,
        patch("modelaudit.scanners.get_scanner_for_file") as mock_scanner,
    ):
        dummy_scanner = object()
        mock_scanner.return_value = dummy_scanner
        mock_stream.return_value = (scan_result, False)

        result = scan_model_directory_or_file(f"stream://{stream_url}")

    metadata = result.file_metadata[stream_url].model_dump()
    assert metadata["scan_outcome"] == "inconclusive"
    assert result.success is True
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_basic(temp_test_files: list[Path]) -> None:
    """Test basic streaming scan functionality."""

    def file_generator() -> Iterator[tuple[Path, bool]]:
        """Generator that yields (path, is_last) tuples."""
        for i, file_path in enumerate(temp_test_files):
            is_last = i == len(temp_test_files) - 1
            yield (file_path, is_last)

    with patch("modelaudit.core.scan_file") as mock_scan:
        # Mock scan_file to return scan results
        mock_scan.side_effect = [create_mock_scan_result(bytes_scanned=100) for _ in temp_test_files]

        # Run streaming scan (don't delete for this test)
        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

        # Verify results
        assert result.bytes_scanned == 300  # 3 files * 100 bytes
        assert result.files_scanned == 3
        assert result.has_errors is False
        assert result.content_hash is not None
        assert len(result.content_hash) == 64  # SHA256 hex string


def test_scan_model_streaming_skips_non_model_files(tmp_path: Path) -> None:
    """Streaming directory scans should honor the normal skip_file_types policy."""
    ignored_file = tmp_path / "notes.log"
    ignored_file.write_text("debug output")
    model_file = tmp_path / "model.pkl"
    with model_file.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_scan_result(bytes_scanned=100)

        result = scan_model_streaming(
            file_generator=iter([(ignored_file, False), (model_file, True)]),
            timeout=30,
            delete_after_scan=False,
            skip_file_types=True,
        )

    mock_scan.assert_called_once()
    assert mock_scan.call_args.args[0] == str(model_file)
    assert mock_scan.call_args.kwargs["config"]["skip_file_types"] is True
    assert result.files_scanned == 1


def test_scan_model_streaming_preserves_license_metadata_when_skipped(tmp_path: Path) -> None:
    """Skipped license files should still populate file metadata in streaming mode."""
    license_file = tmp_path / "license.txt"
    license_file.write_text("MIT License\nCopyright 2026 Example")

    with patch("modelaudit.core.scan_file") as mock_scan:
        result = scan_model_streaming(
            file_generator=iter([(license_file, True)]),
            timeout=30,
            delete_after_scan=False,
            skip_file_types=True,
        )

    mock_scan.assert_not_called()
    assert result.files_scanned == 0
    assert str(license_file) in result.file_metadata
    metadata = result.file_metadata[str(license_file)].model_dump()
    assert "license_info" in metadata
    assert "copyright_notices" in metadata


def test_scan_model_streaming_skip_file_types_preserves_malicious_findings(tmp_path: Path) -> None:
    """Prefiltering should skip non-model files without dropping model security findings."""
    ignored_file = tmp_path / "notes.log"
    ignored_file.write_text("debug output")
    model_file = tmp_path / "model.pkl"
    with model_file.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_scan_result(bytes_scanned=100, with_critical_issue=True)

        result = scan_model_streaming(
            file_generator=iter([(ignored_file, False), (model_file, True)]),
            timeout=30,
            delete_after_scan=False,
            skip_file_types=True,
        )

    mock_scan.assert_called_once()
    assert mock_scan.call_args.args[0] == str(model_file)
    assert result.files_scanned == 1
    assert any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_keeps_non_model_files_when_skip_disabled(tmp_path: Path) -> None:
    """The skip_file_types flag should remain opt-out for streaming scans."""
    ignored_file = tmp_path / "notes.log"
    ignored_file.write_text("debug output")
    model_file = tmp_path / "model.pkl"
    with model_file.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_scan_result(bytes_scanned=100)

        result = scan_model_streaming(
            file_generator=iter([(ignored_file, False), (model_file, True)]),
            timeout=30,
            delete_after_scan=False,
            skip_file_types=False,
        )

    assert [call.args[0] for call in mock_scan.call_args_list] == [str(ignored_file), str(model_file)]
    assert result.files_scanned == 2


def test_scan_model_streaming_skips_huggingface_cache_metadata(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Streaming scans should skip HF bookkeeping metadata like regular scans."""
    hf_home = tmp_path / ".cache" / "huggingface"
    monkeypatch.setenv("HF_HOME", str(hf_home))
    snapshots_dir = hf_home / "hub" / "models--test-model" / "snapshots" / "abc123"
    snapshots_dir.mkdir(parents=True)

    metadata_file = snapshots_dir / "config.json.metadata"
    metadata_file.write_text("{}")
    model_file = snapshots_dir / "model.pkl"
    with model_file.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_scan_result(bytes_scanned=100)

        result = scan_model_streaming(
            file_generator=iter([(metadata_file, False), (model_file, True)]),
            timeout=30,
            delete_after_scan=False,
            scan_root=str(snapshots_dir),
            cache_enabled=False,
        )

    mock_scan.assert_called_once()
    assert mock_scan.call_args.args[0] == str(model_file)
    assert result.files_scanned == 1


def test_scan_model_streaming_scans_local_file_named_main(tmp_path: Path) -> None:
    """A local payload named like an HF ref must still be scanned in streaming mode."""
    payload = tmp_path / "main"
    payload.write_bytes(b"\x80\x02cos\nsystem\n.")

    result = scan_model_streaming(
        file_generator=iter([(payload, True)]),
        timeout=30,
        delete_after_scan=False,
        cache_enabled=False,
    )

    assert result.files_scanned == 1
    assert any(issue.severity == IssueSeverity.CRITICAL and "system" in issue.message for issue in result.issues)
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_symlink_outside_directory_matches_normal_scan(
    tmp_path: Path,
    requires_symlinks: None,
) -> None:
    """Local streaming scans should reject symlinks that escape the requested directory."""
    base_dir = tmp_path / "base"
    base_dir.mkdir()
    outside_dir = tmp_path / "outside"
    outside_dir.mkdir()

    with (base_dir / "safe.pkl").open("wb") as f:
        pickle.dump({"data": "safe"}, f)
    with (outside_dir / "secret.pkl").open("wb") as f:
        pickle.dump({"data": "secret"}, f)

    symlink_path = base_dir / "link.pkl"
    symlink_path.symlink_to(outside_dir / "secret.pkl")

    normal_result = scan_model_directory_or_file(str(base_dir), cache_enabled=False)
    streaming_result = scan_model_streaming(
        file_generator=iterate_files_streaming(base_dir),
        timeout=30,
        delete_after_scan=False,
        scan_root=str(base_dir),
        cache_enabled=False,
    )

    normal_traversal_issues = [i for i in normal_result.issues if "path traversal" in i.message.lower()]
    streaming_traversal_issues = [i for i in streaming_result.issues if "path traversal" in i.message.lower()]

    assert len(normal_traversal_issues) == 1
    assert len(streaming_traversal_issues) == 1
    assert normal_traversal_issues[0].location == str(symlink_path)
    assert streaming_traversal_issues[0].location == str(symlink_path)
    assert streaming_traversal_issues[0].severity == IssueSeverity.CRITICAL
    assert normal_result.files_scanned == 1
    assert streaming_result.files_scanned == 1


def test_scan_model_streaming_symlink_outside_directory_without_safe_files_returns_security_exit_code(
    tmp_path: Path,
    requires_symlinks: None,
) -> None:
    """Traversal findings should keep the security exit code even when no files were scanned."""
    base_dir = tmp_path / "base"
    base_dir.mkdir()
    outside_dir = tmp_path / "outside"
    outside_dir.mkdir()

    with (outside_dir / "secret.pkl").open("wb") as f:
        pickle.dump({"data": "secret"}, f)

    symlink_path = base_dir / "link.pkl"
    symlink_path.symlink_to(outside_dir / "secret.pkl")

    result = scan_model_streaming(
        file_generator=iterate_files_streaming(base_dir),
        timeout=30,
        delete_after_scan=False,
        scan_root=str(base_dir),
        cache_enabled=False,
    )

    traversal_issues = [issue for issue in result.issues if "path traversal" in issue.message.lower()]

    assert result.files_scanned == 0
    assert result.has_errors is False
    assert len(traversal_issues) == 1
    assert traversal_issues[0].location == str(symlink_path)
    assert traversal_issues[0].severity == IssueSeverity.CRITICAL
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_hf_cache_symlink_allowed(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    requires_symlinks: None,
) -> None:
    """Local streaming scans should preserve HuggingFace cache symlink handling."""
    hf_home = tmp_path / ".cache" / "huggingface"
    monkeypatch.setenv("HF_HOME", str(hf_home))
    cache_dir = hf_home / "hub" / "models--test-model"
    snapshots_dir = cache_dir / "snapshots" / "abc123"
    blobs_dir = cache_dir / "blobs"
    snapshots_dir.mkdir(parents=True)
    blobs_dir.mkdir(parents=True)

    blob_path = blobs_dir / "blob123"
    with blob_path.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    model_link = snapshots_dir / "model.pkl"
    os.symlink(os.path.relpath(blob_path, model_link.parent), model_link)

    result = scan_model_streaming(
        file_generator=iterate_files_streaming(snapshots_dir),
        timeout=30,
        delete_after_scan=False,
        scan_root=str(snapshots_dir),
        cache_enabled=False,
    )

    path_traversal_issues = [i for i in result.issues if "path traversal" in i.message.lower()]
    assert result.files_scanned == 1
    assert len(path_traversal_issues) == 0


def test_scan_model_streaming_hf_home_cache_symlink_allowed(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    requires_symlinks: None,
) -> None:
    """Custom HF_HOME cache roots should preserve symlink handling in streaming scans."""
    monkeypatch.setenv("HF_HOME", str(tmp_path / "custom-hf-home"))
    cache_dir = tmp_path / "custom-hf-home" / "hub" / "models--test-model"
    snapshots_dir = cache_dir / "snapshots" / "abc123"
    blobs_dir = cache_dir / "blobs"
    snapshots_dir.mkdir(parents=True)
    blobs_dir.mkdir(parents=True)

    blob_path = blobs_dir / "blob123"
    with blob_path.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    model_link = snapshots_dir / "model.pkl"
    os.symlink(os.path.relpath(blob_path, model_link.parent), model_link)

    result = scan_model_streaming(
        file_generator=iterate_files_streaming(snapshots_dir),
        timeout=30,
        delete_after_scan=False,
        scan_root=str(snapshots_dir),
        cache_enabled=False,
    )

    path_traversal_issues = [i for i in result.issues if "path traversal" in i.message.lower()]
    assert result.files_scanned == 1
    assert len(path_traversal_issues) == 0


def test_scan_model_streaming_symlink_reports_source_path_consistently(
    tmp_path: Path,
    requires_symlinks: None,
) -> None:
    """Streaming scans should report source paths even when scanning a resolved symlink target."""
    base_dir = tmp_path / "base"
    nested_dir = base_dir / "nested"
    nested_dir.mkdir(parents=True)

    resolved_target = nested_dir / "model.pkl"
    with resolved_target.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    source_link = base_dir / "link.pkl"
    source_link.symlink_to(resolved_target.relative_to(source_link.parent))

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_location_scan_result(resolved_target)

        result = scan_model_streaming(
            file_generator=iter([(source_link, True)]),
            timeout=30,
            delete_after_scan=False,
            scan_root=str(base_dir),
            cache_enabled=False,
        )

    assert mock_scan.call_args[0][0] == str(resolved_target)
    assert result.files_scanned == 1
    assert result.assets[0].path == str(source_link)
    assert result.assets[0].size == resolved_target.stat().st_size

    metadata = result.file_metadata[str(source_link)].model_dump()
    assert metadata["source_path"] == str(source_link)
    assert metadata["resolved_path"] == str(resolved_target)

    assert result.issues[0].location == f"{source_link}:payload"
    check_locations = {check.name: check.location for check in result.checks}
    assert check_locations["Suspicious Payload"] == f"{source_link}:payload"
    assert check_locations["Layout Inspection"] == f"{source_link} (weights)"


def test_scan_model_streaming_hf_cache_symlink_reports_snapshot_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    requires_symlinks: None,
) -> None:
    """HuggingFace cache symlinks should keep snapshot paths in streamed results."""
    hf_home = tmp_path / ".cache" / "huggingface"
    monkeypatch.setenv("HF_HOME", str(hf_home))
    cache_dir = hf_home / "hub" / "models--test-model"
    snapshots_dir = cache_dir / "snapshots" / "abc123"
    blobs_dir = cache_dir / "blobs"
    snapshots_dir.mkdir(parents=True)
    blobs_dir.mkdir(parents=True)

    blob_path = blobs_dir / "blob123"
    with blob_path.open("wb") as f:
        pickle.dump({"data": "safe"}, f)

    model_link = snapshots_dir / "model.pkl"
    os.symlink(os.path.relpath(blob_path, model_link.parent), model_link)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = create_mock_location_scan_result(blob_path, issue_suffix="", check_suffix=":tensor")

        result = scan_model_streaming(
            file_generator=iterate_files_streaming(snapshots_dir),
            timeout=30,
            delete_after_scan=False,
            scan_root=str(snapshots_dir),
            cache_enabled=False,
        )

    assert mock_scan.call_args[0][0] == str(blob_path)
    assert result.files_scanned == 1
    assert result.assets[0].path == str(model_link)

    metadata = result.file_metadata[str(model_link)].model_dump()
    assert metadata["source_path"] == str(model_link)
    assert metadata["resolved_path"] == str(blob_path)

    assert result.issues[0].location == str(model_link)
    check_locations = {check.name: check.location for check in result.checks}
    assert check_locations["Suspicious Payload"] == str(model_link)
    assert check_locations["Layout Inspection"] == f"{model_link}:tensor"


def test_scan_model_streaming_with_deletion(temp_test_files: list[Path]) -> None:
    """Test that files are deleted after scanning in streaming mode."""

    def file_generator() -> Iterator[tuple[Path, bool]]:
        for i, file_path in enumerate(temp_test_files):
            is_last = i == len(temp_test_files) - 1
            yield (file_path, is_last)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.side_effect = [create_mock_scan_result(bytes_scanned=100) for _ in temp_test_files]

        # Verify files exist before scan
        for f in temp_test_files:
            assert f.exists()

        # Run streaming scan with deletion
        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=True,
        )

        # Verify files were deleted
        for f in temp_test_files:
            assert not f.exists()

    # Verify scan completed
    assert result.files_scanned == 3
    assert result.content_hash is not None


def test_scan_model_streaming_critical_findings_do_not_set_operational_errors(
    temp_test_files: list[Path],
) -> None:
    """Security findings in streaming mode should still return the security exit code."""

    def file_generator():
        yield (temp_test_files[0], True)

    finding = ScanResult(scanner_name="test_scanner")
    finding.bytes_scanned = 1024
    finding.success = True
    finding.add_issue(
        "Detected malicious payload",
        severity=IssueSeverity.CRITICAL,
        location=str(temp_test_files[0]),
    )

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.return_value = finding

        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

    assert result.files_scanned == 1
    assert len(result.issues) == 1
    assert result.issues[0].message == "Detected malicious payload"
    assert result.issues[0].severity == IssueSeverity.CRITICAL
    assert result.issues[0].location == str(temp_test_files[0])
    assert result.has_errors is False
    assert result.success is True
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_informational_failed_scan_does_not_set_operational_errors(
    temp_test_files: list[Path],
) -> None:
    """Informational failed scans should not override security findings with exit code 2."""

    def file_generator():
        yield (temp_test_files[0], False)
        yield (temp_test_files[1], True)

    info_result = ScanResult(scanner_name="numpy")
    info_result.add_issue(
        "Object-dtype payload contains trailing bytes after the embedded pickle stream",
        severity=IssueSeverity.INFO,
        location="trailing.npy",
    )
    info_result.finish(success=False)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.side_effect = [info_result, create_mock_scan_result(with_critical_issue=True)]

        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

    assert result.files_scanned == 2
    assert result.success is True
    assert result.has_errors is False
    assert determine_exit_code(result) == 1


def test_scan_model_streaming_bare_failed_scan_fails_closed(
    temp_test_files: list[Path],
) -> None:
    """Streaming dict aggregation should preserve bare failed-scan inconclusive metadata."""

    def file_generator() -> Iterator[tuple[Path, bool]]:
        yield (temp_test_files[0], True)

    info_result = ScanResult(scanner_name="numpy")
    info_result.add_issue(
        "Object-dtype payload contains trailing bytes after the embedded pickle stream",
        severity=IssueSeverity.INFO,
        location=str(temp_test_files[0]),
    )
    info_result.finish(success=False)

    with patch("modelaudit.core.scan_file", return_value=info_result):
        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

    metadata = result.file_metadata[str(temp_test_files[0])]
    assert metadata["scan_outcome"] == "inconclusive"
    assert "scanner_reported_unsuccessful_without_outcome" in metadata["scan_outcome_reasons"]
    assert result.has_errors is False
    assert result.success is False
    assert determine_exit_code(result) == 2


def test_scan_model_streaming_operational_info_failure_sets_exit_code_2(
    temp_test_files: list[Path],
) -> None:
    """Informational coverage failures must still fail closed when flagged as operational."""

    def file_generator():
        yield (temp_test_files[0], True)

    info_result = ScanResult(scanner_name="pickle")
    info_result.add_check(
        name="Large File Coverage Check",
        passed=False,
        message=(
            "Error scanning file: scanner pickle does not support bounded large-file analysis "
            "for this file size; aborting to avoid partial coverage."
        ),
        severity=IssueSeverity.INFO,
        location=str(temp_test_files[0]),
    )
    info_result.metadata["operational_error"] = True
    info_result.metadata["operational_error_reason"] = "unsupported_bounded_large_file_analysis"
    info_result.finish(success=False)

    with patch("modelaudit.core.scan_file", return_value=info_result):
        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

    assert result.files_scanned == 1
    assert result.success is False
    assert result.has_errors is True
    assert determine_exit_code(result) == 2


def test_scan_model_streaming_content_hash_deterministic():
    """Test that content hash is deterministic for same files."""
    # Create two files with same content
    files1 = []
    files2 = []

    for _i in range(2):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as tmp:
            tmp.write("Same content")
            files1.append(Path(tmp.name))

    for _i in range(2):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as tmp:
            tmp.write("Same content")
            files2.append(Path(tmp.name))

    try:

        def gen1():
            for i, f in enumerate(files1):
                yield (f, i == len(files1) - 1)

        def gen2():
            for i, f in enumerate(files2):
                yield (f, i == len(files2) - 1)

        with patch("modelaudit.core.scan_file") as mock_scan:
            mock_scan.side_effect = [create_mock_scan_result() for _ in files1 + files2]

            result1 = scan_model_streaming(file_generator=gen1(), timeout=30, delete_after_scan=False)
            result2 = scan_model_streaming(file_generator=gen2(), timeout=30, delete_after_scan=False)

            # Same content should produce same hash
            assert result1.content_hash == result2.content_hash

    finally:
        for file_path in files1 + files2:
            if file_path.exists():
                file_path.unlink()


def test_scan_model_streaming_empty_generator():
    """Test streaming scan with empty file generator."""

    def empty_generator():
        return
        yield  # Make it a generator

    result = scan_model_streaming(
        file_generator=empty_generator(),
        timeout=30,
        delete_after_scan=True,
    )

    # Should complete without errors but with no results
    assert result.files_scanned == 0
    assert result.bytes_scanned == 0
    assert result.content_hash is None or result.content_hash == compute_aggregate_hash([])


def test_scan_model_streaming_scan_error_handling(temp_test_files):
    """Test that scan errors are handled gracefully in streaming mode."""

    def file_generator():
        for i, file_path in enumerate(temp_test_files):
            is_last = i == len(temp_test_files) - 1
            yield (file_path, is_last)

    with patch("modelaudit.core.scan_file") as mock_scan:
        # First file succeeds, second fails, third succeeds
        mock_scan.side_effect = [
            create_mock_scan_result(),
            Exception("Scan failed"),
            create_mock_scan_result(),
        ]

        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

        # Should have errors flag set
        assert result.has_errors is True
        # Should have scanned 2 files (1st and 3rd)
        assert result.files_scanned == 2


@pytest.mark.slow
def test_scan_model_streaming_timeout():
    """Test that timeout is respected in streaming mode."""
    # Create multiple files to trigger timeout between scans
    temp_files = []
    for i in range(3):
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
            f.write(f"Test {i}")
            temp_files.append(Path(f.name))

    try:

        def slow_generator():
            for i, f in enumerate(temp_files):
                yield (f, i == len(temp_files) - 1)

        with patch("modelaudit.core.scan_file") as mock_scan:
            # Make each scan take 0.5 seconds (3 files = 1.5s total)
            def slow_scan(*args, **kwargs):
                time.sleep(0.5)
                return create_mock_scan_result()

            mock_scan.side_effect = slow_scan

            # Set timeout to 1 second (should complete 1-2 files, then timeout)
            result = scan_model_streaming(
                file_generator=slow_generator(),
                timeout=1,  # 1 second timeout
                delete_after_scan=False,
            )

            # Should timeout and have errors
            assert result.has_errors is True
            # Should have scanned at least 1 file but not all 3
            assert 1 <= result.files_scanned < 3

    finally:
        for file_path in temp_files:
            if file_path.exists():
                file_path.unlink()


def test_compute_aggregate_hash_empty_list():
    """Test aggregate hash computation with empty list."""
    result = compute_aggregate_hash([])
    # Should return hash of empty string
    expected = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    assert result == expected


def test_compute_aggregate_hash_single_hash():
    """Test aggregate hash computation with single hash."""
    file_hash = "a" * 64  # Mock SHA256 hash
    result = compute_aggregate_hash([file_hash])
    assert len(result) == 64
    assert result != file_hash  # Should be different (hash of hash)


def test_compute_aggregate_hash_multiple_hashes():
    """Test aggregate hash computation with multiple hashes."""
    hashes = [
        "a" * 64,
        "b" * 64,
        "c" * 64,
    ]
    result = compute_aggregate_hash(hashes)
    assert len(result) == 64


def test_compute_aggregate_hash_order_independence():
    """Test that aggregate hash is order-independent (sorted)."""
    hashes = ["aaa", "bbb", "ccc"]
    reversed_hashes = ["ccc", "bbb", "aaa"]

    result1 = compute_aggregate_hash(hashes)
    result2 = compute_aggregate_hash(reversed_hashes)

    # Should be the same (sorted internally)
    assert result1 == result2


def test_scan_model_streaming_progress_callback(temp_test_files: list[Path]) -> None:
    """Test that progress callback is called during streaming scan."""
    progress_calls: list[tuple[str, float]] = []

    def progress_callback(message: str, percentage: float) -> None:
        progress_calls.append((message, percentage))

    def file_generator() -> Iterator[tuple[Path, bool]]:
        for i, file_path in enumerate(temp_test_files):
            yield (file_path, i == len(temp_test_files) - 1)

    with patch("modelaudit.core.scan_file") as mock_scan:
        mock_scan.side_effect = [create_mock_scan_result() for _ in temp_test_files]

        scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            progress_callback=progress_callback,
            delete_after_scan=False,
        )

        # Should have received progress updates
        assert len(progress_calls) > 0
        # Should have both hashing and scanning messages
        messages = [msg for msg, _ in progress_calls]
        assert any("Hashing" in msg for msg in messages)
        assert any("Scanning" in msg for msg in messages)


def test_scan_model_streaming_asset_creation(temp_test_files: list[Path]) -> None:
    """Test that assets are created during streaming scan."""

    def file_generator() -> Iterator[tuple[Path, bool]]:
        for i, file_path in enumerate(temp_test_files):
            yield (file_path, i == len(temp_test_files) - 1)

    with (
        patch("modelaudit.core.scan_file") as mock_scan,
        patch("modelaudit.utils.helpers.assets.asset_from_scan_result") as mock_asset,
    ):
        mock_scan.side_effect = [create_mock_scan_result() for _ in temp_test_files]

        # Mock asset creation
        mock_asset.return_value = {
            "path": "test",
            "type": "test",
            "size": 100,
        }

        result = scan_model_streaming(
            file_generator=file_generator(),
            timeout=30,
            delete_after_scan=False,
        )

        # asset_from_scan_result should be called for each file
        assert result.success is True
        assert result.files_scanned == len(temp_test_files)
        assert mock_asset.call_count == 3
