"""Tests for SkopsScanner covering CVE-2025-54412, CVE-2025-54413, CVE-2025-54886."""

import os
import zipfile
from pathlib import Path
from typing import Any

import pytest

from modelaudit.cache import get_cache_manager, reset_cache_manager
from modelaudit.core import determine_exit_code, scan_model_directory_or_file
from modelaudit.models import ModelAuditResultModel
from modelaudit.scanners.base import INCONCLUSIVE_SCAN_OUTCOME, CheckStatus, IssueSeverity
from modelaudit.scanners.skops_scanner import SkopsScanner

SAMPLES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "samples")


def _make_numeric_npy(element_count: int = 64) -> bytes:
    header = f"{{'descr': '<f8', 'fortran_order': False, 'shape': ({element_count},), }}"
    header_bytes = header.encode("latin1")
    header_len = len(header_bytes) + 1
    padding_len = (16 - ((10 + header_len) % 16)) % 16
    padded_header = header_bytes + (b" " * padding_len) + b"\n"
    return (
        b"\x93NUMPY\x01\x00" + len(padded_header).to_bytes(2, "little") + padded_header + (b"\x00" * element_count * 8)
    )


def _scan_twice_with_cache(
    path: Path,
    cache_dir: Path,
    *,
    max_files_in_archive: int | None = None,
    max_skops_file_size: int | None = None,
    max_zip_entry_read_size: int | None = None,
) -> tuple[ModelAuditResultModel, ModelAuditResultModel]:
    scan_kwargs: dict[str, Any] = {
        "cache_enabled": True,
        "cache_dir": str(cache_dir),
        "min_cache_file_size": 0,
    }
    if max_files_in_archive is not None:
        scan_kwargs["max_files_in_archive"] = max_files_in_archive
    if max_skops_file_size is not None:
        scan_kwargs["max_skops_file_size"] = max_skops_file_size
    if max_zip_entry_read_size is not None:
        scan_kwargs["max_zip_entry_read_size"] = max_zip_entry_read_size

    first = scan_model_directory_or_file(str(path), **scan_kwargs)
    second = scan_model_directory_or_file(str(path), **scan_kwargs)
    return first, second


def _assert_inconclusive_reason(metadata: Any, reason: str) -> None:
    assert metadata.get("scan_outcome") == INCONCLUSIVE_SCAN_OUTCOME
    assert reason in metadata.get("scan_outcome_reasons", [])


class TestSkopsScannerCanHandle:
    """Test the can_handle method."""

    def test_can_handle_skops_extension(self, tmp_path: Path) -> None:
        """Test that scanner handles .skops files."""
        skops_file = tmp_path / "model.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')

        assert SkopsScanner.can_handle(str(skops_file)) is True

    def test_cannot_handle_non_skops_extension(self, tmp_path: Path) -> None:
        """Test that scanner rejects non-.skops files."""
        other_file = tmp_path / "model.pkl"
        other_file.write_bytes(b"not a skops file")

        assert SkopsScanner.can_handle(str(other_file)) is False

    def test_cannot_handle_nonexistent_file(self) -> None:
        """Test that scanner rejects nonexistent files."""
        assert SkopsScanner.can_handle("/nonexistent/path/model.skops") is False

    def test_cannot_handle_directory(self, tmp_path: Path) -> None:
        """Test that scanner rejects directories."""
        skops_dir = tmp_path / "model.skops"
        skops_dir.mkdir()

        assert SkopsScanner.can_handle(str(skops_dir)) is False


class TestSkopsScannerCVE2025_54412:
    """Test CVE-2025-54412: OperatorFuncNode trusted-type confusion detection."""

    def test_detects_operatorfuncnode_pattern(self, tmp_path: Path) -> None:
        """Test detection of OperatorFuncNode pattern in file names."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("OperatorFuncNode_exploit.json", '{"type": "exploit"}')
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        cve_checks = [c for c in result.checks if "CVE-2025-54412" in c.name]
        assert len(cve_checks) > 0
        assert cve_checks[0].status == CheckStatus.FAILED
        assert cve_checks[0].severity == IssueSeverity.CRITICAL

    def test_reduce_pattern_no_false_positive(self, tmp_path: Path) -> None:
        """Test that __reduce__ filenames do NOT trigger CVE-2025-54412.

        __reduce__ is a standard Python serialization method used by ALL
        sklearn Cython types (e.g. sklearn.tree._tree.Tree).  It was
        intentionally removed from CVE-2025-54412 pattern matching to
        prevent false positives on legitimate models.
        """
        skops_file = tmp_path / "legitimate.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("__reduce__payload.bin", b"malicious content")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        cve_checks = [c for c in result.checks if "CVE-2025-54412" in c.name]
        # __reduce__ alone should NOT trigger CVE-2025-54412
        failed = [c for c in cve_checks if c.status == CheckStatus.FAILED]
        assert len(failed) == 0

    def test_no_false_positive_clean_file(self, tmp_path: Path) -> None:
        """Test that clean skops files don't trigger CVE-2025-54412."""
        skops_file = tmp_path / "clean.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')
            zf.writestr("model.bin", b"model weights")
            zf.writestr("metadata.json", '{"name": "clean_model"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        cve_54412_checks = [c for c in result.checks if "CVE-2025-54412" in c.name]
        # Should not have any CVE-2025-54412 failed checks
        failed = [c for c in cve_54412_checks if c.status == CheckStatus.FAILED]
        assert len(failed) == 0


class TestSkopsScannerCVE2025_54413:
    """Test CVE-2025-54413: MethodNode inconsistency detection."""

    def test_detects_methodnode_pattern(self, tmp_path: Path) -> None:
        """Test detection of MethodNode pattern in file names."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("MethodNode_accessor.json", '{"type": "method"}')
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        cve_checks = [c for c in result.checks if "CVE-2025-54413" in c.name]
        assert len(cve_checks) > 0
        assert cve_checks[0].status == CheckStatus.FAILED
        assert cve_checks[0].severity == IssueSeverity.CRITICAL

    def test_detects_getattr_pattern(self, tmp_path: Path) -> None:
        """Test detection of __getattr__ pattern."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("__getattr__hook.py", "malicious code")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        cve_checks = [c for c in result.checks if "CVE-2025-54413" in c.name]
        assert len(cve_checks) > 0
        assert cve_checks[0].status == CheckStatus.FAILED
        assert cve_checks[0].severity == IssueSeverity.CRITICAL


class TestSkopsScannerCVE2025_54886:
    """Test CVE-2025-54886: Card.get_model silent joblib fallback detection."""

    def test_detects_card_with_get_model(self, tmp_path: Path) -> None:
        """Test detection of Card.get_model with joblib references."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            card_content = """
            # Model Card
            This model uses get_model() to load the model.
            Fallback to joblib for compatibility.
            """
            zf.writestr("model_card.md", card_content)
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        cve_checks = [c for c in result.checks if "CVE-2025-54886" in c.name]
        assert len(cve_checks) > 0
        assert cve_checks[0].status == CheckStatus.FAILED
        assert cve_checks[0].severity == IssueSeverity.CRITICAL

    def test_detects_readme_with_joblib(self, tmp_path: Path) -> None:
        """Test detection of README with joblib fallback pattern."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            readme_content = """
            # Model README
            Load the model using joblib.load() if skops fails.
            """
            zf.writestr("README.md", readme_content)
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        cve_checks = [c for c in result.checks if "CVE-2025-54886" in c.name]
        assert len(cve_checks) > 0
        assert cve_checks[0].status == CheckStatus.FAILED
        assert cve_checks[0].severity == IssueSeverity.CRITICAL

    def test_download_text_in_readme_is_not_cve_54886(self, tmp_path: Path) -> None:
        """Benign README prose containing 'download' must not trigger CVE-2025-54886."""
        skops_file = tmp_path / "benign_readme.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("README.md", "# Model Card\nDownload this safe model from the release page.\n")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is True
        cve_checks = [c for c in result.checks if "CVE-2025-54886" in c.name and c.status == CheckStatus.FAILED]
        assert len(cve_checks) == 0


class TestSkopsScannerJoblibFallback:
    """Test unsafe joblib fallback detection."""

    def test_detects_joblib_load_pattern(self, tmp_path: Path) -> None:
        """Test detection of joblib.load patterns in file content."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("model.pkl", b"joblib.load(model_path)")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        joblib_checks = [c for c in result.checks if "Joblib" in c.name]
        assert len(joblib_checks) > 0
        assert joblib_checks[0].status == CheckStatus.FAILED
        assert joblib_checks[0].severity == IssueSeverity.WARNING

    def test_detects_pickle_load_pattern(self, tmp_path: Path) -> None:
        """Test detection of pickle.load patterns."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("loader.py", b"import pickle\npickle.load(f)")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        joblib_checks = [c for c in result.checks if "Joblib" in c.name]
        assert len(joblib_checks) > 0
        assert joblib_checks[0].status == CheckStatus.FAILED
        assert joblib_checks[0].severity == IssueSeverity.WARNING

    def test_no_false_positive_sklearn_in_schema_json(self, tmp_path: Path) -> None:
        """Regression: schema.json with sklearn type refs must NOT trigger joblib fallback.

        Real .skops files contain a schema.json that references sklearn module
        paths (e.g. "sklearn.linear_model.LogisticRegression"). These are type
        schema references, not pickle/joblib deserialization code.
        """
        skops_file = tmp_path / "legit.skops"
        schema_content = (
            '{"__class__": "sklearn.linear_model._logistic.LogisticRegression",'
            ' "__module__": "sklearn.linear_model._logistic",'
            ' "content": {"C": {"__class__": "float", "content": 1.0}}}'
        )
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema.json", schema_content)
            zf.writestr("step/0/content/0.npy", b"\x93NUMPY\x01\x00model data")

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        joblib_checks = [c for c in result.checks if "Joblib" in c.name and c.status == CheckStatus.FAILED]
        assert len(joblib_checks) == 0, (
            f"False positive: schema.json triggered Unsafe Joblib Fallback Detection: {joblib_checks}"
        )

    def test_no_false_positive_sklearn_in_schema_bare(self, tmp_path: Path) -> None:
        """Regression: bare 'schema' file (no .json ext) must also be excluded.

        Some skops archives use a file named just ``schema`` without the
        ``.json`` extension.  The metadata exclusion must cover both variants.
        """
        skops_file = tmp_path / "legit_bare.skops"
        schema_content = (
            '{"__class__": "sklearn.ensemble._forest.RandomForestClassifier",'
            ' "__module__": "sklearn.ensemble._forest",'
            ' "content": {"n_estimators": {"__class__": "int", "content": 100}}}'
        )
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema", schema_content)
            zf.writestr("step/0/content/0.npy", b"\x93NUMPY\x01\x00model data")

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        joblib_checks = [c for c in result.checks if "Joblib" in c.name and c.status == CheckStatus.FAILED]
        assert len(joblib_checks) == 0, (
            f"False positive: bare 'schema' file triggered Unsafe Joblib Fallback Detection: {joblib_checks}"
        )

    def test_sklearn_in_data_file_still_detected(self, tmp_path: Path) -> None:
        """Ensure sklearn references in non-metadata files are still flagged."""
        skops_file = tmp_path / "suspicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')
            # sklearn reference in a data file IS suspicious
            zf.writestr("payload.bin", b"import sklearn; sklearn.externals.joblib.load(f)")

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        joblib_checks = [c for c in result.checks if "Joblib" in c.name and c.status == CheckStatus.FAILED]
        assert len(joblib_checks) > 0, "sklearn in a data file should still be flagged"


class TestSkopsScannerEdgeCases:
    """Test edge cases and error handling."""

    def test_handles_empty_archive(self, tmp_path: Path) -> None:
        """Test handling of empty ZIP archive."""
        skops_file = tmp_path / "empty.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            pass  # Create empty archive

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        # Should complete without error
        assert result.success is True

    def test_handles_corrupted_file(self, tmp_path: Path) -> None:
        """Test handling of corrupted/non-ZIP file."""
        skops_file = tmp_path / "corrupted.skops"
        skops_file.write_bytes(b"not a valid zip file content")

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        _assert_inconclusive_reason(result.metadata, "skops_not_zip_archive")
        format_checks = [c for c in result.checks if c.name == "Skops File Format Check"]
        assert len(format_checks) > 0

    def test_handles_deeply_nested_files(self, tmp_path: Path) -> None:
        """Test handling of deeply nested file paths."""
        skops_file = tmp_path / "nested.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            deep_path = "/".join(["dir"] * 10) + "/model.bin"
            zf.writestr(deep_path, b"model data")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        # Should complete without error
        assert result.success is True

    def test_handles_unicode_filenames(self, tmp_path: Path) -> None:
        """Test handling of unicode characters in filenames."""
        skops_file = tmp_path / "unicode.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("模型_data.json", '{"name": "test"}')
            zf.writestr("données_modèle.bin", b"model data")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        # Should complete without error
        assert result.success is True

    def test_handles_decompression_bomb(self, tmp_path: Path) -> None:
        """Test that archives exceeding max file count are rejected."""
        skops_file = tmp_path / "bomb.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            for i in range(15):
                zf.writestr(f"file_{i}.bin", b"data")

        scanner = SkopsScanner(config={"max_files_in_archive": 5})
        result = scanner.scan(str(skops_file))

        assert result.success is False
        _assert_inconclusive_reason(result.metadata, "skops_archive_file_count_limited")
        bomb_checks = [c for c in result.checks if "Archive Bomb" in c.name]
        assert len(bomb_checks) > 0
        assert bomb_checks[0].status == CheckStatus.FAILED

    def test_rejects_archive_exceeding_uncompressed_size_limit(self, tmp_path: Path) -> None:
        """Archive should fail when total uncompressed bytes exceed max_skops_file_size."""
        skops_file = tmp_path / "size_limit.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("README.md", "A" * 4096)
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner(config={"max_skops_file_size": 2048})
        result = scanner.scan(str(skops_file))

        assert result.success is False
        _assert_inconclusive_reason(result.metadata, "skops_archive_uncompressed_size_limited")
        size_checks = [c for c in result.checks if "Archive Uncompressed Size Limit" in c.name]
        assert len(size_checks) > 0
        assert size_checks[0].status == CheckStatus.FAILED

    def test_oversized_readme_entry_marks_scan_incomplete(self, tmp_path: Path) -> None:
        """Oversized archive entries should fail closed when bounded reads skip them."""
        skops_file = tmp_path / "oversized_readme.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("README.md", "get_model via joblib.load" * 512)
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner(config={"max_zip_entry_read_size": 128, "max_skops_file_size": 10 * 1024 * 1024})
        result = scanner.scan(str(skops_file))

        assert result.success is False
        _assert_inconclusive_reason(result.metadata, "skops_zip_entry_size_limited")
        oversized_checks = [c for c in result.checks if c.name == "Skops Oversized ZIP Entry"]
        assert len(oversized_checks) == 1
        assert oversized_checks[0].details["entry"] == "README.md"
        cve_checks = [c for c in result.checks if "CVE-2025-54886" in c.name and c.status == CheckStatus.FAILED]
        assert len(cve_checks) == 0

    def test_oversized_numpy_payload_does_not_mark_skops_incomplete(self, tmp_path: Path) -> None:
        """Large Skops numeric arrays are covered by nested scanners, not Skops CVE text matching."""
        skops_file = tmp_path / "oversized_array.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')
            zf.writestr("step/0/content/0.npy", _make_numeric_npy())

        scanner = SkopsScanner(config={"max_zip_entry_read_size": 128, "max_skops_file_size": 10 * 1024 * 1024})
        result = scanner.scan(str(skops_file))

        assert result.success is True
        assert "scan_outcome" not in result.metadata
        oversized_checks = [c for c in result.checks if c.name == "Skops Oversized ZIP Entry"]
        assert len(oversized_checks) == 0

    def test_oversized_entry_warning_is_emitted_once(self, tmp_path: Path) -> None:
        """Repeated detector passes over one oversized member should emit one incomplete warning."""
        skops_file = tmp_path / "oversized_methodnode.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("payload.bin", "MethodNode __getattr__" * 512)
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner(config={"max_zip_entry_read_size": 128, "max_skops_file_size": 10 * 1024 * 1024})
        result = scanner.scan(str(skops_file))

        oversized_checks = [c for c in result.checks if c.name == "Skops Oversized ZIP Entry"]
        assert len(oversized_checks) == 1
        assert oversized_checks[0].details["entry"] == "payload.bin"
        assert result.success is False
        assert result.metadata["oversized_zip_entries"] == ["payload.bin"]

    def test_oversized_entry_core_exits_one_and_avoids_cache_reuse(self, tmp_path: Path) -> None:
        """Aggregate scans should preserve fail-closed exit and avoid reusing incomplete outer results."""
        skops_file = tmp_path / "oversized_readme.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("README.md", "get_model via joblib.load" * 512)
            zf.writestr("schema.json", '{"version": "1.0"}')

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(
                skops_file,
                cache_dir,
                max_zip_entry_read_size=128,
                max_skops_file_size=10 * 1024 * 1024,
            )

            for result in (first, second):
                assert result.success is True
                assert determine_exit_code(result) == 1
                assert "skops" in result.scanner_names
                metadata = result.file_metadata[str(skops_file)]
                _assert_inconclusive_reason(metadata, "skops_zip_entry_size_limited")
                assert any("Skipped oversized ZIP entry README.md" in str(issue.message) for issue in result.issues)

            assert get_cache_manager(str(cache_dir), enabled=True).get_stats()["cache_hits"] == 0
        finally:
            reset_cache_manager()

    def test_archive_file_count_limit_core_exits_two_and_avoids_cache_reuse(self, tmp_path: Path) -> None:
        """Core scans should fail closed and avoid caching when Skops file-count limits stop analysis."""
        skops_file = tmp_path / "too_many_files.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for index in range(6):
                zf.writestr(f"file_{index}.bin", b"data")

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(
                skops_file,
                cache_dir,
                max_files_in_archive=5,
                max_skops_file_size=10 * 1024 * 1024,
            )

            for result in (first, second):
                assert result.success is False
                assert determine_exit_code(result) == 2
                metadata = result.file_metadata[str(skops_file)]
                _assert_inconclusive_reason(metadata, "skops_archive_file_count_limited")
                assert any("Archive contains 6 files" in str(issue.message) for issue in result.issues)

            stats = get_cache_manager(str(cache_dir), enabled=True).get_stats()
            assert stats["cache_hits"] == 0
            assert stats["total_entries"] == 0
        finally:
            reset_cache_manager()

    def test_archive_uncompressed_size_limit_core_exits_two_and_avoids_cache_reuse(self, tmp_path: Path) -> None:
        """Core scans should fail closed and avoid caching when Skops aggregate size limits stop analysis."""
        skops_file = tmp_path / "too_large.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("README.md", "A" * 4096)
            zf.writestr("schema.json", '{"version": "1.0"}')

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(
                skops_file,
                cache_dir,
                max_skops_file_size=2048,
            )

            for result in (first, second):
                assert result.success is False
                assert determine_exit_code(result) == 2
                metadata = result.file_metadata[str(skops_file)]
                _assert_inconclusive_reason(metadata, "skops_archive_uncompressed_size_limited")
                assert any("uncompressed content exceeds" in str(issue.message) for issue in result.issues)

            stats = get_cache_manager(str(cache_dir), enabled=True).get_stats()
            assert stats["cache_hits"] == 0
            assert stats["total_entries"] == 0
        finally:
            reset_cache_manager()

    def test_not_zip_core_exits_one_and_avoids_cache_reuse(self, tmp_path: Path) -> None:
        """A non-ZIP .skops path is incomplete Skops coverage, not a cacheable clean result."""
        skops_file = tmp_path / "not_zip.skops"
        skops_file.write_bytes(b"not a zip archive")

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(skops_file, cache_dir)

            for result in (first, second):
                assert result.success is True
                assert determine_exit_code(result) == 1
                metadata = result.file_metadata[str(skops_file)]
                _assert_inconclusive_reason(metadata, "skops_not_zip_archive")
                assert any("not a ZIP archive" in str(issue.message) for issue in result.issues)

            stats = get_cache_manager(str(cache_dir), enabled=True).get_stats()
            assert stats["cache_hits"] == 0
            assert stats["total_entries"] == 0
        finally:
            reset_cache_manager()

    def test_bad_zip_core_exits_two_and_avoids_cache_reuse(self, tmp_path: Path) -> None:
        """A corrupt ZIP-like .skops path should also fail closed and stay uncached."""
        skops_file = tmp_path / "bad_zip.skops"
        skops_file.write_bytes(b"PK\x03\x04not a complete zip")

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(skops_file, cache_dir)

            for result in (first, second):
                assert result.success is False
                assert determine_exit_code(result) == 2
                metadata = result.file_metadata[str(skops_file)]
                _assert_inconclusive_reason(metadata, "skops_bad_zip_file")
                assert any("Invalid ZIP file" in str(issue.message) for issue in result.issues)

            stats = get_cache_manager(str(cache_dir), enabled=True).get_stats()
            assert stats["cache_hits"] == 0
            assert stats["total_entries"] == 0
        finally:
            reset_cache_manager()

    def test_oversized_numpy_payload_core_exits_zero_and_still_caches(self, tmp_path: Path) -> None:
        """Oversized numeric arrays should not become Skops CVE false positives in aggregate scans."""
        skops_file = tmp_path / "large_array.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')
            zf.writestr("step/0/content/0.npy", _make_numeric_npy())

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(
                skops_file,
                cache_dir,
                max_zip_entry_read_size=128,
                max_skops_file_size=10 * 1024 * 1024,
            )

            for result in (first, second):
                assert result.success is True
                assert determine_exit_code(result) == 0
                metadata = result.file_metadata[str(skops_file)]
                assert "scan_outcome" not in metadata
                assert not any("Skipped oversized ZIP entry" in str(issue.message) for issue in result.issues)

            assert get_cache_manager(str(cache_dir), enabled=True).get_stats()["cache_hits"] >= 1
        finally:
            reset_cache_manager()

    def test_small_benign_core_scan_still_caches(self, tmp_path: Path) -> None:
        """Clean Skops scans should still be cacheable."""
        skops_file = tmp_path / "small_benign.skops"
        with zipfile.ZipFile(skops_file, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("README.md", "normal safe model card")
            zf.writestr("schema.json", '{"version": "1.0"}')

        cache_dir = tmp_path / "cache"
        reset_cache_manager()
        try:
            first, second = _scan_twice_with_cache(
                skops_file,
                cache_dir,
                max_zip_entry_read_size=128,
                max_skops_file_size=10 * 1024 * 1024,
            )

            assert first.success is True
            assert second.success is True
            assert determine_exit_code(first) == 0
            assert determine_exit_code(second) == 0
            assert get_cache_manager(str(cache_dir), enabled=True).get_stats()["cache_hits"] >= 1
        finally:
            reset_cache_manager()

    def test_counts_embedded_member_bytes(self, tmp_path: Path) -> None:
        """Embedded member scans should contribute to total bytes_scanned."""
        skops_file = tmp_path / "byte_count.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("schema.json", '{"version": "1.0"}')
            zf.writestr("weights.bin", b"model weights")

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is True
        assert result.bytes_scanned > skops_file.stat().st_size


class TestSkopsScannerMultipleCVEs:
    """Test detection of multiple CVEs in a single file."""

    def test_detects_multiple_cves(self, tmp_path: Path) -> None:
        """Test that scanner can detect multiple CVEs in one file."""
        skops_file = tmp_path / "multi_exploit.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            # CVE-2025-54412 pattern
            zf.writestr("OperatorFuncNode.json", '{"exploit": true}')
            # CVE-2025-54413 pattern
            zf.writestr("MethodNode_hook.py", "malicious")
            # CVE-2025-54886 pattern
            zf.writestr("model_card.md", "use get_model() with joblib fallback")
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        assert result.success is False
        # Should detect all three CVEs
        cve_54412 = [c for c in result.checks if "CVE-2025-54412" in c.name]
        cve_54413 = [c for c in result.checks if "CVE-2025-54413" in c.name]
        cve_54886 = [c for c in result.checks if "CVE-2025-54886" in c.name]

        assert len(cve_54412) > 0
        assert len(cve_54413) > 0
        assert len(cve_54886) > 0

        # All failed checks should be critical
        all_cve_checks = cve_54412 + cve_54413 + cve_54886
        for check in all_cve_checks:
            if check.status == CheckStatus.FAILED:
                assert check.severity == IssueSeverity.CRITICAL


class TestSkopsScannerCVEDetails:
    """Test that CVE details are properly populated."""

    def test_cve_details_include_required_fields(self, tmp_path: Path) -> None:
        """Test that CVE checks include all required detail fields."""
        skops_file = tmp_path / "malicious.skops"
        with zipfile.ZipFile(skops_file, "w") as zf:
            zf.writestr("OperatorFuncNode.json", '{"exploit": true}')
            zf.writestr("schema.json", '{"version": "1.0"}')

        scanner = SkopsScanner()
        result = scanner.scan(str(skops_file))

        cve_checks = [c for c in result.checks if "CVE-2025-54412" in c.name and c.status == CheckStatus.FAILED]
        assert len(cve_checks) > 0

        check = cve_checks[0]
        details = check.details

        # Verify required fields
        assert "cve_id" in details
        assert "cvss" in details
        assert "cwe" in details
        assert "affected_versions" in details
        assert "remediation" in details
        assert "skops < 0.12.0" in details["affected_versions"]
        assert "0.12.0" in details["remediation"]


class TestSkopsScannerRealModel:
    """Integration tests using a real .skops model from HuggingFace."""

    REAL_SKOPS = os.path.join(SAMPLES_DIR, "pipeline.skops")

    @pytest.mark.skipif(
        not os.path.isfile(os.path.join(SAMPLES_DIR, "pipeline.skops")),
        reason="Real .skops sample not available",
    )
    def test_can_handle_real_skops_model(self) -> None:
        """Test that scanner recognises a real .skops file (scikit-learn/persistence)."""
        assert SkopsScanner.can_handle(self.REAL_SKOPS) is True

    @pytest.mark.skipif(
        not os.path.isfile(os.path.join(SAMPLES_DIR, "pipeline.skops")),
        reason="Real .skops sample not available",
    )
    def test_scan_real_skops_model_no_cve_false_positives(self) -> None:
        """Test that a legitimate model doesn't trigger CVE detections."""
        scanner = SkopsScanner()
        result = scanner.scan(self.REAL_SKOPS)

        assert result.success is True

        # No CVE checks should fail on a legitimate model
        cve_failed = [
            c
            for c in result.checks
            if any(cve in c.name for cve in ["CVE-2025-54412", "CVE-2025-54413", "CVE-2025-54886"])
            and c.status == CheckStatus.FAILED
        ]
        assert len(cve_failed) == 0, f"False positive CVE detections: {[c.name for c in cve_failed]}"

    @pytest.mark.skipif(
        not os.path.isfile(os.path.join(SAMPLES_DIR, "pipeline.skops")),
        reason="Real .skops sample not available",
    )
    def test_scan_real_skops_model_metadata(self) -> None:
        """Test that scan metadata is populated for a real model."""
        scanner = SkopsScanner()
        result = scanner.scan(self.REAL_SKOPS)

        assert result.metadata.get("file_size", 0) > 0
        assert result.metadata.get("file_count", 0) > 0
