import os
from pathlib import Path
from typing import Any

import pytest

# Skip if msgpack is not available before importing it
pytest.importorskip("msgpack")

import msgpack

from modelaudit.scanners.base import CheckStatus, IssueSeverity
from modelaudit.scanners.flax_msgpack_scanner import FlaxMsgpackScanner


def create_msgpack_file(path: Path, data: Any) -> None:
    """Helper to create msgpack files with specific data."""
    with open(path, "wb") as f:
        f.write(msgpack.packb(data, use_bin_type=True))


def create_malicious_msgpack_file(path):
    """Create a msgpack file with suspicious content."""
    malicious_data = {
        "params": {"w": list(range(5))},
        "__reduce__": "malicious_function",
        "code": "import os; os.system('rm -rf /')",
        "suspicious_blob": b"eval(compile('malicious code', 'string', 'exec'))" * 1000,
    }
    create_msgpack_file(path, malicious_data)


def test_flax_msgpack_valid_checkpoint(tmp_path):
    """Test scanning a valid Flax checkpoint."""
    path = tmp_path / "model.msgpack"
    # Create realistic Flax checkpoint structure
    data = {
        "params": {
            "layers_0": {"kernel": [[0.1, 0.2], [0.3, 0.4]], "bias": [0.1, 0.2]},
            "layers_1": {"kernel": [[0.5, 0.6]], "bias": [0.3]},
        },
        "opt_state": {"step": 1000},
        "metadata": {"model_name": "test_model", "version": "1.0"},
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    assert result.success is True
    assert result.metadata.get("top_level_type") == "dict"
    assert "params" in result.metadata.get("top_level_keys", [])
    assert (
        len(
            [issue for issue in result.issues if issue.severity == IssueSeverity.INFO],
        )
        == 0
    )


def test_flax_msgpack_suspicious_content(tmp_path):
    """Test detection of suspicious patterns in msgpack content."""
    path = tmp_path / "suspicious.msgpack"
    create_malicious_msgpack_file(path)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    # Should detect multiple security issues (CRITICAL or INFO severity)
    security_issues = [
        issue for issue in result.issues if issue.severity in (IssueSeverity.CRITICAL, IssueSeverity.INFO)
    ]
    assert len(security_issues) > 0, f"Expected security issues but got: {result.issues}"

    # Check for specific threats
    issue_messages = [issue.message for issue in result.issues]

    # Should detect suspicious key or code patterns
    found_threats = any(
        "__reduce__" in msg or "os.system" in msg or "suspicious" in msg.lower() for msg in issue_messages
    )
    assert found_threats, f"Expected to detect threats but got messages: {issue_messages}"


def test_flax_msgpack_malicious_content_marks_scan_unsuccessful(tmp_path: Path) -> None:
    """CRITICAL msgpack findings should make the scan unsuccessful."""
    path = tmp_path / "malicious.msgpack"
    create_msgpack_file(path, {"params": {"w": [1, 2, 3]}, "__reduce__": "os.system"})

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is False
    assert any(
        issue.severity == IssueSeverity.CRITICAL and issue.message == "Suspicious object attribute detected: __reduce__"
        for issue in result.issues
    )


def test_flax_msgpack_restore_fn_custom_value_no_critical(tmp_path: Path) -> None:
    """Benign Orbax restore function names should not be key-name criticals."""
    path = tmp_path / "benign_restore_fn.msgpack"
    create_msgpack_file(path, {"params": {"w": [1, 2, 3]}, "restore_fn": "custom_deserialize"})

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is True
    assert not [
        issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL and "restore_fn" in issue.message
    ]


def test_flax_msgpack_restore_fn_dangerous_value_still_critical(tmp_path: Path) -> None:
    """Function metadata that directly names dangerous callables should stay critical."""
    path = tmp_path / "dangerous_restore_fn.msgpack"
    create_msgpack_file(path, {"params": {"w": [1, 2, 3]}, "restore_fn": "eval"})

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is False
    assert any(
        issue.severity == IssueSeverity.CRITICAL
        and issue.message == "Suspicious object attribute value detected: restore_fn"
        for issue in result.issues
    )


@pytest.mark.parametrize(
    ("metadata_key", "dangerous_callable"),
    [
        ("restore_fn", "eval"),
        ("jax_fn", "exec"),
        ("compiled_fn", "compile"),
        ("exec_fn", "os.system"),
        ("transform_fn", "subprocess.run"),
        ("__tree_flatten__", "__import__"),
        ("__tree_unflatten__", "subprocess.Popen"),
    ],
)
def test_flax_msgpack_function_metadata_key_value_combinations(
    tmp_path: Path,
    metadata_key: str,
    dangerous_callable: str,
) -> None:
    """Function metadata keys should be value-aware across common callable names."""
    for value, should_be_critical in ((dangerous_callable, True), ("custom_deserialize", False)):
        path = tmp_path / f"{metadata_key.strip('_') or 'dunder'}_{value.replace('.', '_')}.msgpack"
        create_msgpack_file(path, {"params": {"w": [1, 2, 3]}, metadata_key: value})

        result = FlaxMsgpackScanner().scan(str(path))
        key_critical_issues = [
            issue
            for issue in result.issues
            if issue.severity == IssueSeverity.CRITICAL and metadata_key in issue.message
        ]

        if should_be_critical:
            assert key_critical_issues, f"Expected CRITICAL for {metadata_key}={value!r}: {result.issues}"
        else:
            assert not key_critical_issues, f"Expected no CRITICAL for {metadata_key}={value!r}: {result.issues}"


def test_flax_msgpack_jax_internal_key_metadata_is_not_critical(tmp_path: Path) -> None:
    """JAX internal metadata key names should not become critical without dangerous values."""
    path = tmp_path / "benign_jax_internal_keys.msgpack"
    create_msgpack_file(
        path,
        {
            "params": {"w": [1, 2, 3]},
            "__jax_array__": {"dtype": "float32", "shape": [3]},
            "__tree_flatten__": "tree_def",
            "__tree_unflatten__": "tree_def",
        },
    )

    result = FlaxMsgpackScanner().scan(str(path))

    critical_messages = [issue.message for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]
    assert not any("__jax_array__" in message for message in critical_messages)
    assert not any("__tree_flatten__" in message for message in critical_messages)
    assert not any("__tree_unflatten__" in message for message in critical_messages)


def test_flax_msgpack_metadata_system_os_keys_not_critical(tmp_path: Path) -> None:
    """Environment-like top-level metadata keys should not be unconditional criticals."""
    path = tmp_path / "benign_system_metadata.msgpack"
    create_msgpack_file(path, {"params": {"w": [1, 2, 3]}, "system": "linux", "os": "linux-x86_64"})

    result = FlaxMsgpackScanner().scan(str(path))

    assert not [
        issue
        for issue in result.issues
        if issue.severity == IssueSeverity.CRITICAL and "top-level keys" in issue.message.lower()
    ]


def test_flax_msgpack_respects_file_size_limit(tmp_path: Path) -> None:
    """Scanner should fail closed before reading files larger than max_file_read_size."""
    path = tmp_path / "too_large.msgpack"
    create_msgpack_file(path, {"params": {"w": list(range(64))}})

    result = FlaxMsgpackScanner(config={"max_file_read_size": 10}).scan(str(path))

    assert result.success is False
    size_checks = [
        check for check in result.checks if check.name == "File Size Limit" and check.status == CheckStatus.FAILED
    ]
    assert len(size_checks) == 1


def test_flax_msgpack_scans_trailing_msgpack_objects(tmp_path: Path) -> None:
    """A malicious second msgpack object after a benign first object must still be scanned."""
    path = tmp_path / "trailing_malicious.msgpack"
    payload = msgpack.packb({"params": {"w": [1, 2, 3]}}, use_bin_type=True)
    payload += msgpack.packb({"__reduce__": "os.system"}, use_bin_type=True)
    path.write_bytes(payload)

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is False
    assert result.metadata.get("msgpack_object_count") == 2
    stream_checks = [
        check
        for check in result.checks
        if check.name == "Msgpack Stream Integrity Check" and check.status == CheckStatus.FAILED
    ]
    assert len(stream_checks) == 1
    assert any(
        issue.severity == IssueSeverity.CRITICAL
        and issue.message == "Suspicious object attribute detected: __reduce__"
        and issue.location == "root[msgpack_object_1]/__reduce__"
        for issue in result.issues
    )


def test_flax_msgpack_benign_trailing_dict_object_is_info_only(tmp_path: Path) -> None:
    """Valid trailing dict objects should be scanned without warning-level stream noise."""
    path = tmp_path / "benign_two_objects.msgpack"
    payload = msgpack.packb({"params": {"a": [1, 2]}}, use_bin_type=True)
    payload += msgpack.packb({"params": {"b": [3, 4]}}, use_bin_type=True)
    path.write_bytes(payload)

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is True
    assert result.metadata.get("msgpack_object_count") == 2
    stream_checks = [
        check
        for check in result.checks
        if check.name == "Msgpack Stream Integrity Check" and check.status == CheckStatus.FAILED
    ]
    assert len(stream_checks) == 1
    assert stream_checks[0].severity == IssueSeverity.INFO
    assert stream_checks[0].details["trailing_objects_are_container_like"] is True


def test_flax_msgpack_scalar_trailing_junk_stays_warning(tmp_path: Path) -> None:
    """Scalar trailing bytes are still surfaced as warning-level stream integrity findings."""
    path = tmp_path / "scalar_trailing_junk.msgpack"
    payload = msgpack.packb({"params": {"w": [1, 2, 3]}}, use_bin_type=True) + b"garbage"
    path.write_bytes(payload)

    result = FlaxMsgpackScanner().scan(str(path))

    assert result.success is True
    stream_checks = [
        check
        for check in result.checks
        if check.name == "Msgpack Stream Integrity Check" and check.status == CheckStatus.FAILED
    ]
    assert len(stream_checks) == 1
    assert stream_checks[0].severity == IssueSeverity.WARNING
    assert stream_checks[0].details["trailing_objects_are_container_like"] is False


def test_flax_msgpack_caps_trailing_stream_object_count(tmp_path: Path) -> None:
    """Too many trailing msgpack objects should fail closed without materializing the full stream."""
    path = tmp_path / "many_objects.msgpack"
    payload = msgpack.packb({"params": {"root": [1]}}, use_bin_type=True)
    payload += b"".join(msgpack.packb({"params": {"n": [index]}}, use_bin_type=True) for index in range(8))
    path.write_bytes(payload)

    result = FlaxMsgpackScanner(config={"max_msgpack_stream_objects": 4}).scan(str(path))

    assert result.success is False
    assert result.metadata.get("operational_error") is True
    assert result.metadata.get("operational_error_reason") == "msgpack_stream_object_limit_exceeded"
    object_limit_checks = [
        check
        for check in result.checks
        if check.name == "Msgpack Stream Object Limit" and check.status == CheckStatus.FAILED
    ]
    assert len(object_limit_checks) == 1
    assert object_limit_checks[0].details["max_msgpack_stream_objects"] == 4


def test_flax_msgpack_large_containers(tmp_path):
    """Test detection of containers with excessive items."""
    path = tmp_path / "large.msgpack"
    # Create oversized containers (default limit is 50000)
    # Use smaller sizes in CI to avoid memory issues
    is_ci = os.getenv("CI") or os.getenv("GITHUB_ACTIONS")
    dict_size = 52000 if is_ci else 60000  # Just over limit, but smaller in CI
    list_size = 51000 if is_ci else 55000  # Just over limit, but smaller in CI

    large_dict = {f"key_{i}": f"value_{i}" for i in range(dict_size)}
    large_list = list(range(list_size))

    data = {"params": {"large_dict": large_dict, "large_list": large_list}}
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    info_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.INFO]
    assert len(info_issues) >= 2  # Should report both large containers at INFO level

    issue_messages = [issue.message for issue in info_issues]
    assert any("excessive items" in msg for msg in issue_messages)


def test_flax_msgpack_deep_nesting(tmp_path):
    """Test detection of excessive recursion depth."""
    path = tmp_path / "deep.msgpack"

    # Create deeply nested structure
    deep_data: dict[str, Any] = {"level": 0}
    current: dict[str, Any] = deep_data
    for i in range(1, 150):  # Deeper than default limit
        current["nested"] = {"level": i}
        current = current["nested"]

    create_msgpack_file(path, deep_data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.INFO]
    assert any("recursion depth exceeded" in issue.message for issue in critical_issues)


def test_flax_msgpack_non_standard_structure(tmp_path):
    """Test detection of non-standard Flax structures using structural analysis."""
    path = tmp_path / "nonstandard.msgpack"
    # Create structure that doesn't look like a Flax checkpoint
    data = {
        "random_key": "random_value",
        "another_key": [1, 2, 3],
        "not_flax": {"definitely": "not a model"},
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    # Scanner behavior may vary - either flag suspicious structure or recognize as non-ML file
    # Check that the scan completes without critical errors
    assert result.success is True or len(result.issues) > 0

    # If warnings exist, they should be about structure or non-ML content
    warning_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.WARNING]
    if warning_issues:
        # Warnings should be about structure or content, not malicious patterns
        assert all(
            "suspicious" in issue.message.lower()
            or "structure" in issue.message.lower()
            or "data" in issue.message.lower()
            or "ml" in issue.message.lower()
            for issue in warning_issues
        )


def test_flax_msgpack_corrupted(tmp_path):
    """Test handling of corrupted msgpack files."""
    path = tmp_path / "corrupt.msgpack"
    data = {"params": {"w": list(range(5))}}
    create_msgpack_file(path, data)

    # Corrupt the file by truncating it
    original_data = path.read_bytes()
    path.write_bytes(original_data[:-10])

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    # Scanner may report corruption via has_errors or via issues/checks
    # Check for any indication of corrupted/invalid file
    all_messages = [issue.message for issue in result.issues]
    all_messages.extend([check.message for check in result.checks])

    has_error_indication = (
        result.has_errors
        or any(
            "Invalid msgpack format" in msg or "Unexpected error processing" in msg or "corrupt" in msg.lower()
            for msg in all_messages
        )
        or not result.success
    )
    assert has_error_indication, (
        f"Expected error indication for corrupted file but got: "
        f"issues={result.issues}, checks={result.checks}, success={result.success}"
    )


def test_flax_msgpack_enhanced_jax_support(tmp_path):
    """Test enhanced JAX-specific functionality."""
    path = tmp_path / "jax_model.flax"

    # Create JAX model with transformer architecture
    data = {
        "params": {
            "transformer": {
                "attention": {"query": b"\x00" * 1000, "key": b"\x00" * 1000},
                "feed_forward": {"dense": b"\x00" * 2000},
            }
        },
        "opt_state": {"step": 1000, "learning_rate": 0.001},
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    assert result.success
    # Should detect transformer architecture
    assert result.metadata.get("model_architecture") == "transformer"
    estimated_params = result.metadata.get("estimated_parameters")
    assert estimated_params is not None and estimated_params > 0

    # Should detect optimizer state
    jax_metadata = result.metadata.get("jax_metadata", {})
    assert jax_metadata.get("has_optimizer_state") is True


def test_flax_msgpack_orbax_format_detection(tmp_path):
    """Test detection of Orbax checkpoint format."""
    path = tmp_path / "orbax_checkpoint.orbax"

    data = {
        "__orbax_metadata__": {"version": "0.1.0", "format": "flax"},
        "state": {"params": {"layer": b"\x00" * 1000}},
        "metadata": {"step": 5000},
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    assert result.success

    # Should detect Orbax format
    jax_metadata = result.metadata.get("jax_metadata", {})
    assert jax_metadata.get("orbax_format") is True

    # Should have check about Orbax detection
    # Now using checks instead of issues - look for passed check with Orbax message
    orbax_checks = [check for check in result.checks if "Orbax checkpoint format detected" in check.message]
    assert len(orbax_checks) > 0, "No Orbax detection check found"
    assert orbax_checks[0].status.value == "passed"


def test_flax_msgpack_jax_specific_threats(tmp_path):
    """Test detection of JAX-specific security threats."""
    path = tmp_path / "malicious_jax.jax"

    data = {
        "params": {"layer": b"\x00" * 100},
        "__jax_array__": "fake_array_metadata",
        "custom_transform": "jax.jit(eval(malicious_code))",
        "shape": [-1, 100],  # Invalid negative dimension
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    # Should detect multiple threats (CRITICAL, WARNING, or INFO severity)
    security_issues = [
        issue
        for issue in result.issues
        if issue.severity in (IssueSeverity.CRITICAL, IssueSeverity.WARNING, IssueSeverity.INFO)
    ]

    # Check for JAX-specific threats
    issues_messages = [issue.message for issue in security_issues]

    # Scanner message may say "JAX array metadata" or "Suspicious object attribute detected: __jax_array__"
    assert any("__jax_array__" in msg or "JAX array" in msg for msg in issues_messages)
    # Negative dimensions check - may not be implemented in all scanner versions
    # assert any("negative dimensions" in msg for msg in issues_messages)


def test_flax_msgpack_large_model_support(tmp_path):
    """Test support for large transformer models."""
    path = tmp_path / "large_model.msgpack"

    # Create scanner with lower blob limit for testing
    is_ci = os.getenv("CI") or os.getenv("GITHUB_ACTIONS")
    blob_limit = 5 * 1024 * 1024 if is_ci else 10 * 1024 * 1024  # 5MB in CI, 10MB locally
    scanner = FlaxMsgpackScanner(config={"max_blob_bytes": blob_limit})

    # Simulate large model embedding
    embedding_size = 10 * 1024 * 1024 if is_ci else 20 * 1024 * 1024  # 10MB in CI, 20MB locally
    large_embedding = b"\x00" * embedding_size

    data = {
        "params": {
            "embedding": {"vocab_embedding": large_embedding},
            "transformer": {"layer_0": {"attention": b"\x00" * 1000}},
        }
    }
    create_msgpack_file(path, data)

    result = scanner.scan(str(path))

    assert result.success

    # Should handle large blobs without flagging as suspicious for legitimate models
    info_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.INFO]
    # The large blob should be detected but at INFO level, not CRITICAL
    large_blob_issues = [issue for issue in info_issues if "large binary blob" in issue.message.lower()]
    assert len(large_blob_issues) >= 1


def test_flax_msgpack_can_handle_extensions(tmp_path):
    """Test that scanner can handle all JAX/Flax file extensions."""
    extensions = [".msgpack", ".flax", ".orbax", ".jax"]

    for ext in extensions:
        test_file = tmp_path / f"test{ext}"
        test_file.write_bytes(b"\x81\xa4test\xa5value")  # Simple msgpack

        assert FlaxMsgpackScanner.can_handle(str(test_file))


@pytest.mark.slow
def test_flax_msgpack_ml_context_confidence(tmp_path):
    """Test ML context confidence scoring.

    Note: This test is marked as slow because it creates a large (~150MB)
    simulated GPT-2 model file which takes significant time to serialize,
    write to disk, and scan.
    """
    path = tmp_path / "ml_model.msgpack"

    # Create data that strongly indicates ML model
    # Using smaller matrices to reduce test time while still being representative
    data = {
        "params": {
            "transformer": {
                "attention": {"query": b"\x00" * (768 * 768 * 4)},  # 768x768 matrix (~2.4MB)
                "feed_forward": {"dense": b"\x00" * (768 * 3072 * 4)},  # 768x3072 matrix (~9.4MB)
            },
            "embedding": {"token_embedding": b"\x00" * (50257 * 768 * 4)},  # GPT-2 vocab size (~147MB)
        }
    }
    create_msgpack_file(path, data)

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    assert result.success

    # Should have high confidence this is an ML model
    jax_metadata = result.metadata.get("jax_metadata", {})
    assert jax_metadata.get("confidence", 0) >= 0.7
    assert jax_metadata.get("is_ml_model") is True

    # Should find evidence of transformer architecture
    assert "transformer" in result.metadata.get("model_architecture", "")


def test_flax_msgpack_trailing_data(tmp_path):
    """Test detection of trailing data after msgpack content."""
    path = tmp_path / "trailing.msgpack"
    data = {"params": {"w": [1, 2, 3]}}
    create_msgpack_file(path, data)

    # Add trailing bytes
    original_data = path.read_bytes()
    path.write_bytes(original_data + b"TRAILING_GARBAGE_DATA")

    scanner = FlaxMsgpackScanner()
    result = scanner.scan(str(path))

    # Trailing data detection may not be implemented in all scanner versions
    # Just verify the scan completes without errors
    # If trailing data detection is implemented, it would be at INFO severity
    all_issues = result.issues
    trailing_detected = any("trailing" in issue.message.lower() for issue in all_issues)
    # This test passes if either trailing is detected or scan completes successfully
    assert result.success or trailing_detected


def test_flax_msgpack_large_binary_blob(tmp_path: Path) -> None:
    """Test oversized blob detection with a small custom threshold.

    Keep this fixture tiny so the regular xdist lane does not stall on one
    worker while still exercising the exact size-threshold check.
    """
    threshold_bytes = 1024
    blob_size_bytes = 2 * threshold_bytes

    path = tmp_path / "large_blob.msgpack"
    # Create large binary blob (exceeds threshold)
    large_blob = b"X" * blob_size_bytes
    data = {"params": {"normal_param": [1, 2, 3]}, "suspicious_blob": large_blob}
    create_msgpack_file(path, data)

    # Configure scanner with appropriate threshold
    config = {"max_blob_bytes": threshold_bytes}
    scanner = FlaxMsgpackScanner(config=config)
    result = scanner.scan(str(path))

    info_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.INFO]
    assert any("Suspiciously large binary blob" in issue.message for issue in info_issues)


def test_flax_msgpack_custom_config(tmp_path):
    """Test scanner with custom configuration parameters."""
    path = tmp_path / "test.msgpack"
    create_malicious_msgpack_file(path)

    # Test with custom config
    custom_config = {
        "max_recursion_depth": 10,
        "max_items_per_container": 100,
        "suspicious_patterns": [r"custom_threat"],
    }

    scanner = FlaxMsgpackScanner(config=custom_config)
    result = scanner.scan(str(path))

    # Should still detect some issues but with different thresholds
    assert len(result.issues) > 0
