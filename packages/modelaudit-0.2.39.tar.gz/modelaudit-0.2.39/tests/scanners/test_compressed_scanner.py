import bz2
import gzip
import io
import lzma
import pickle
import tarfile
import zlib
from collections.abc import Callable
from pathlib import Path
from typing import Literal

import pytest

from modelaudit.scanners import get_scanner_for_file
from modelaudit.scanners.base import CheckStatus, IssueSeverity
from modelaudit.scanners.compressed_scanner import CompressedScanner, _MissingOptionalDependencyError

TarWriteMode = Literal["w:gz", "w:bz2", "w:xz"]


class _MaliciousPayload:
    def __reduce__(self) -> tuple[object, tuple[str]]:
        return (eval, ("print('owned')",))


_LZ4_FRAME_MAGIC = b"\x04\x22\x4d\x18"


class _FakeLz4FrameDecompressor:
    def __init__(self, frames: dict[bytes, bytes], error_type: type[RuntimeError]) -> None:
        self.frames = frames
        self.error_type = error_type
        self.max_lengths: list[int] = []
        self.eof = False
        self.needs_input = True
        self.unused_data = b""

    def decompress(self, data: bytes, max_length: int = -1) -> bytes:
        self.max_lengths.append(max_length)
        if not data.startswith(_LZ4_FRAME_MAGIC):
            raise self.error_type("Invalid lz4 frame")

        marker_start = len(_LZ4_FRAME_MAGIC)
        marker = data[marker_start : marker_start + 1]
        if marker not in self.frames:
            raise self.error_type("Invalid lz4 frame")

        output = self.frames[marker]
        if max_length >= 0 and len(output) > max_length:
            raise AssertionError("Fake lz4 frame output exceeded max_length")

        self.eof = True
        self.needs_input = True
        self.unused_data = data[marker_start + 1 :]
        return output


class _FakeLz4FrameModule:
    class LZ4FrameError(RuntimeError):
        pass

    def __init__(self, frames: dict[bytes, bytes]) -> None:
        self.frames = frames
        self.decompressors: list[_FakeLz4FrameDecompressor] = []
        self.LZ4FrameDecompressor: Callable[[], _FakeLz4FrameDecompressor] = self._create_decompressor

    def _create_decompressor(self) -> _FakeLz4FrameDecompressor:
        decompressor = _FakeLz4FrameDecompressor(self.frames, self.LZ4FrameError)
        self.decompressors.append(decompressor)
        return decompressor


class _FakeLz4ChunkContext:
    def __init__(self, frames: dict[bytes, bytes], error_type: type[RuntimeError]) -> None:
        self.frames = frames
        self.error_type = error_type
        self.max_lengths: list[int] = []

    def decompress_chunk(self, data: bytes, max_length: int = -1) -> tuple[bytes, int, bool]:
        self.max_lengths.append(max_length)
        if not data.startswith(_LZ4_FRAME_MAGIC):
            raise self.error_type("Invalid lz4 frame")

        marker_start = len(_LZ4_FRAME_MAGIC)
        marker = data[marker_start : marker_start + 1]
        if marker not in self.frames:
            raise self.error_type("Invalid lz4 frame")

        output = self.frames[marker]
        if max_length >= 0 and len(output) > max_length:
            raise AssertionError("Fake lz4 frame output exceeded max_length")

        return output, marker_start + 1, True


class _FakeLz4ChunkModule:
    class LZ4FrameError(RuntimeError):
        pass

    def __init__(self, frames: dict[bytes, bytes]) -> None:
        self.frames = frames
        self.contexts: list[_FakeLz4ChunkContext] = []

    def create_decompression_context(self) -> _FakeLz4ChunkContext:
        context = _FakeLz4ChunkContext(self.frames, self.LZ4FrameError)
        self.contexts.append(context)
        return context

    def decompress_chunk(
        self,
        context: _FakeLz4ChunkContext,
        data: bytes,
        max_length: int = -1,
    ) -> tuple[bytes, int, bool]:
        return context.decompress_chunk(data, max_length=max_length)


def test_compressed_scanner_can_handle_requires_matching_signature(tmp_path: Path) -> None:
    valid_gzip_path = tmp_path / "model.pkl.gz"
    valid_gzip_path.write_bytes(gzip.compress(pickle.dumps({"weights": [1, 2, 3]})))

    invalid_gzip_path = tmp_path / "model.txt.gz"
    invalid_gzip_path.write_bytes(b"not-gzip")

    assert CompressedScanner.can_handle(str(valid_gzip_path)) is True
    assert CompressedScanner.can_handle(str(invalid_gzip_path)) is False


def test_compressed_scanner_can_handle_header_routed_misnamed_wrapper(tmp_path: Path) -> None:
    disguised_gzip_path = tmp_path / "model.jpg"
    disguised_gzip_path.write_bytes(gzip.compress(pickle.dumps({"weights": [1, 2, 3]})))

    near_match_path = tmp_path / "near-match.jpg"
    near_match_path.write_bytes(b"\x1f\x00not-a-gzip-stream")

    assert CompressedScanner.can_handle(str(disguised_gzip_path)) is True
    assert CompressedScanner.can_handle(str(near_match_path)) is False


def test_compressed_scanner_can_handle_rejects_invalid_zlib_header_near_match(tmp_path: Path) -> None:
    zlib_path = tmp_path / "payload.bin.zlib"
    zlib_path.write_bytes(b"\x78\x00" + b"not-a-valid-zlib-stream")

    assert CompressedScanner.can_handle(str(zlib_path)) is False


@pytest.mark.parametrize(
    ("filename", "mode"),
    [
        ("model.tar.gz", "w:gz"),
        ("model.tar.bz2", "w:bz2"),
        ("model.tar.xz", "w:xz"),
    ],
)
def test_compound_tar_wrappers_route_to_tar_scanner(
    tmp_path: Path,
    filename: str,
    mode: TarWriteMode,
) -> None:
    archive_path = tmp_path / filename
    payload = b"weights"

    with tarfile.open(archive_path, mode) as tar:
        info = tarfile.TarInfo("weights.bin")
        info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))

    scanner = get_scanner_for_file(str(archive_path))

    assert scanner is not None
    assert scanner.name == "tar"


@pytest.mark.parametrize(
    ("filename", "mode"),
    [
        ("safe.tar.gz", "w:gz"),
        ("safe.tar.bz2", "w:bz2"),
        ("safe.tar.xz", "w:xz"),
    ],
)
def test_compound_tar_wrappers_scan_benign_payloads_without_critical_findings(
    tmp_path: Path,
    filename: str,
    mode: TarWriteMode,
) -> None:
    archive_path = tmp_path / filename
    payload = pickle.dumps({"weights": [1, 2, 3]})

    with tarfile.open(archive_path, mode) as tar:
        info = tarfile.TarInfo("safe.pkl")
        info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))

    scanner = get_scanner_for_file(str(archive_path))

    assert scanner is not None
    assert scanner.name == "tar"

    result = scanner.scan(str(archive_path))
    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]

    assert critical_issues == []


@pytest.mark.parametrize(
    ("filename", "mode"),
    [
        ("malicious.tar.gz", "w:gz"),
        ("malicious.tar.bz2", "w:bz2"),
        ("malicious.tar.xz", "w:xz"),
    ],
)
def test_compound_tar_wrappers_surface_malicious_inner_findings(
    tmp_path: Path,
    filename: str,
    mode: TarWriteMode,
) -> None:
    archive_path = tmp_path / filename
    payload = pickle.dumps({"payload": _MaliciousPayload()})

    with tarfile.open(archive_path, mode) as tar:
        info = tarfile.TarInfo("evil.pkl")
        info.size = len(payload)
        tar.addfile(info, io.BytesIO(payload))

    scanner = get_scanner_for_file(str(archive_path))

    assert scanner is not None
    assert scanner.name == "tar"

    result = scanner.scan(str(archive_path))
    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]

    assert critical_issues
    assert any("eval" in issue.message.lower() for issue in critical_issues)
    assert any(issue.location == f"{archive_path}:evil.pkl" for issue in critical_issues)


def test_compressed_scanner_routes_benign_inner_payload(tmp_path: Path) -> None:
    safe_pickle = pickle.dumps({"layer": [1, 2, 3]})
    path = tmp_path / "safe_model.pkl.gz"
    path.write_bytes(gzip.compress(safe_pickle))

    scanner = CompressedScanner()
    result = scanner.scan(str(path))

    assert result.success is True

    routing_checks = [c for c in result.checks if c.name == "Compressed Wrapper Inner Scanner Routing"]
    assert routing_checks and routing_checks[0].status == CheckStatus.PASSED

    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]
    assert len(critical_issues) == 0


def test_compressed_scanner_surfaces_malicious_inner_findings(tmp_path: Path) -> None:
    malicious_pickle = pickle.dumps({"payload": _MaliciousPayload()})
    path = tmp_path / "malicious.pkl.gz"
    path.write_bytes(gzip.compress(malicious_pickle))

    scanner = CompressedScanner()
    result = scanner.scan(str(path))

    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]

    assert critical_issues
    assert any("eval" in issue.message.lower() for issue in critical_issues)
    assert any(issue.location == f"{path} -> malicious.pkl" for issue in critical_issues)


def test_compressed_scanner_surfaces_malicious_inner_findings_from_zlib_wrapper(tmp_path: Path) -> None:
    malicious_pickle = pickle.dumps({"payload": _MaliciousPayload()})
    path = tmp_path / "malicious.pkl.zlib"
    path.write_bytes(zlib.compress(malicious_pickle))

    scanner = CompressedScanner()
    result = scanner.scan(str(path))

    critical_issues = [issue for issue in result.issues if issue.severity == IssueSeverity.CRITICAL]

    assert critical_issues
    assert any("eval" in issue.message.lower() for issue in critical_issues)
    assert any(issue.location == f"{path} -> malicious.pkl" for issue in critical_issues)


def test_compressed_scanner_corrupt_stream_is_warning_not_critical(tmp_path: Path) -> None:
    path = tmp_path / "broken_payload.gz"
    path.write_bytes(b"\x1f\x8b\x08\x00\x00\x00\x00\x00")

    scanner = CompressedScanner()
    result = scanner.scan(str(path))

    decode_checks = [c for c in result.checks if c.name == "Compressed Wrapper Stream Decode"]
    assert decode_checks and decode_checks[0].status == CheckStatus.FAILED
    assert decode_checks[0].severity == IssueSeverity.WARNING


@pytest.mark.parametrize(
    ("extension", "compressor"),
    [
        (".bz2", bz2.compress),
        (".xz", lzma.compress),
        (".zlib", zlib.compress),
    ],
)
def test_compressed_scanner_enforces_decompression_size_limit(
    tmp_path: Path,
    extension: str,
    compressor: Callable[[bytes], bytes],
) -> None:
    data = b"A" * 4096
    path = tmp_path / f"oversize_payload.bin{extension}"
    path.write_bytes(compressor(data))

    scanner = CompressedScanner(config={"compressed_max_decompressed_bytes": 512})
    result = scanner.scan(str(path))

    limit_checks = [c for c in result.checks if c.name == "Compressed Wrapper Decompression Limits"]
    assert limit_checks and limit_checks[0].status == CheckStatus.FAILED
    assert limit_checks[0].severity == IssueSeverity.WARNING


def test_compressed_scanner_enforces_decompression_ratio_limit(tmp_path: Path) -> None:
    highly_compressible = b"0" * 20_000
    path = tmp_path / "ratio_payload.bin.gz"
    path.write_bytes(gzip.compress(highly_compressible))

    scanner = CompressedScanner(config={"compressed_max_decompression_ratio": 5.0})
    result = scanner.scan(str(path))

    ratio_checks = [c for c in result.checks if c.name == "Compressed Wrapper Decompression Limits"]
    assert ratio_checks and ratio_checks[0].status == CheckStatus.FAILED
    assert ratio_checks[0].severity == IssueSeverity.WARNING


def test_compressed_scanner_false_positive_control_high_ratio_within_policy(tmp_path: Path) -> None:
    highly_compressible = b"0" * 20_000
    path = tmp_path / "policy_ok_payload.txt.gz"
    path.write_bytes(gzip.compress(highly_compressible))

    scanner = CompressedScanner(
        config={
            "compressed_max_decompressed_bytes": 64 * 1024,
            "compressed_max_decompression_ratio": 5000.0,
        },
    )
    result = scanner.scan(str(path))

    ratio_failures = [
        c
        for c in result.checks
        if c.name == "Compressed Wrapper Decompression Limits" and c.status == CheckStatus.FAILED
    ]
    assert len(ratio_failures) == 0


def test_read_zlib_stream_uses_bounded_decompression(monkeypatch: pytest.MonkeyPatch) -> None:
    class _FakeDecompressor:
        def __init__(self) -> None:
            self.max_lengths: list[int] = []
            self.flush_lengths: list[int] = []
            self.eof = True
            self.unconsumed_tail = b""
            self.unused_data = b""

        def decompress(self, _chunk: bytes, max_length: int = 0) -> bytes:
            self.max_lengths.append(max_length)
            return b"x" * min(256, max_length)

        def flush(self, length: int = 0) -> bytes:
            self.flush_lengths.append(length)
            return b""

    fake_decompressor = _FakeDecompressor()

    monkeypatch.setattr(
        "modelaudit.scanners.compressed_scanner.zlib.decompressobj",
        lambda: fake_decompressor,
    )

    CompressedScanner._read_zlib_stream_with_limits(
        source=io.BytesIO(b"compressed"),
        destination=io.BytesIO(),
        max_decompressed_bytes=1024,
        max_ratio=100.0,
        compressed_size=10,
        chunk_size=4,
    )

    assert fake_decompressor.max_lengths
    assert fake_decompressor.max_lengths == [4, 4, 4]
    assert fake_decompressor.flush_lengths == [4]


def test_read_concatenated_stream_uses_chunk_bounded_decompression() -> None:
    class _FakeDecompressor:
        def __init__(self) -> None:
            self.max_lengths: list[int] = []
            self.eof = False
            self.needs_input = True
            self.unused_data = b""

        def decompress(self, _chunk: bytes, max_length: int = 0) -> bytes:
            self.max_lengths.append(max_length)
            self.eof = True
            return b"x" * max_length

    fake_decompressors: list[_FakeDecompressor] = []

    def _factory() -> _FakeDecompressor:
        fake_decompressor = _FakeDecompressor()
        fake_decompressors.append(fake_decompressor)
        return fake_decompressor

    total_out = CompressedScanner._read_concatenated_stream_with_limits(
        source=io.BytesIO(b"x"),
        destination=io.BytesIO(),
        decompressor_factory=_factory,
        error_types=(ValueError,),
        codec="fake",
        max_decompressed_bytes=512 * 1024 * 1024,
        max_ratio=1000.0,
        compressed_size=1,
        chunk_size=8,
    )

    assert total_out == 8
    assert [length for fake in fake_decompressors for length in fake.max_lengths] == [8]


def test_read_lz4_stream_uses_chunk_bounded_decompression() -> None:
    fake_lz4_frame = _FakeLz4FrameModule({b"S": b"12345678"})
    destination = io.BytesIO()

    total_out = CompressedScanner._read_lz4_stream_with_limits(
        source=io.BytesIO(_LZ4_FRAME_MAGIC + b"S"),
        destination=destination,
        lz4_frame=fake_lz4_frame,
        max_decompressed_bytes=512 * 1024 * 1024,
        max_ratio=1000.0,
        compressed_size=1,
        chunk_size=8,
    )

    assert total_out == 8
    assert destination.getvalue() == b"12345678"
    assert [length for fake in fake_lz4_frame.decompressors for length in fake.max_lengths] == [8]


def test_read_lz4_stream_falls_back_to_chunk_api_when_decompressor_class_missing() -> None:
    fake_lz4_frame = _FakeLz4ChunkModule({b"S": b"12345678"})
    destination = io.BytesIO()

    total_out = CompressedScanner._read_lz4_stream_with_limits(
        source=io.BytesIO(_LZ4_FRAME_MAGIC + b"S"),
        destination=destination,
        lz4_frame=fake_lz4_frame,
        max_decompressed_bytes=512 * 1024 * 1024,
        max_ratio=1000.0,
        compressed_size=1,
        chunk_size=8,
    )

    assert total_out == 8
    assert destination.getvalue() == b"12345678"
    assert [length for context in fake_lz4_frame.contexts for length in context.max_lengths] == [8]


def test_read_zlib_stream_allows_exact_limit_real_stream() -> None:
    payload = b"A" * 1024
    compressed = zlib.compress(payload)
    destination = io.BytesIO()

    total_out = CompressedScanner._read_zlib_stream_with_limits(
        source=io.BytesIO(compressed),
        destination=destination,
        max_decompressed_bytes=len(payload),
        max_ratio=1000.0,
        compressed_size=len(compressed),
        chunk_size=1,
    )

    assert total_out == len(payload)
    assert destination.getvalue() == payload


def test_compressed_scanner_rejects_raw_trailer_after_zlib_member(tmp_path: Path) -> None:
    """A raw trailer after a valid zlib stream must not hide an unscanned pickle payload."""
    safe_pickle = pickle.dumps({"safe": [1, 2, 3]})
    malicious_pickle_trailer = b'cos\nsystem\n(S"echo owned"\ntR.'

    path = tmp_path / "payload.pkl.zlib"
    path.write_bytes(zlib.compress(safe_pickle) + malicious_pickle_trailer)

    result = CompressedScanner().scan(str(path))

    decode_checks = [check for check in result.checks if check.name == "Compressed Wrapper Stream Decode"]
    assert decode_checks and decode_checks[0].status == CheckStatus.FAILED
    assert "invalid zlib stream" in decode_checks[0].message.lower()
    assert result.success is False
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


@pytest.mark.parametrize(
    ("filename", "compressor"),
    [
        ("payload.pkl.bz2", bz2.compress),
        ("payload.pkl.xz", lzma.compress),
    ],
)
def test_compressed_scanner_rejects_raw_trailer_after_bzip2_or_xz_member(
    tmp_path: Path,
    filename: str,
    compressor: Callable[[bytes], bytes],
) -> None:
    """A raw trailer after a valid stream must not hide an unscanned pickle payload."""
    safe_pickle = pickle.dumps({"safe": [1, 2, 3]})
    malicious_pickle_trailer = b'cos\nsystem\n(S"echo owned"\ntR.'

    path = tmp_path / filename
    path.write_bytes(compressor(safe_pickle) + malicious_pickle_trailer)

    result = CompressedScanner().scan(str(path))

    decode_checks = [check for check in result.checks if check.name == "Compressed Wrapper Stream Decode"]
    assert decode_checks and decode_checks[0].status == CheckStatus.FAILED
    assert "invalid" in decode_checks[0].message.lower()
    assert result.success is False
    assert result.has_warnings is True
    assert result.has_errors is False
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_allows_concatenated_zlib_members(tmp_path: Path) -> None:
    """Concatenated zlib members should remain a supported benign encoding shape."""
    payload_a = pickle.dumps({"weights": [1, 2, 3]}, protocol=4)
    payload_b = pickle.dumps({"bias": [4, 5, 6]}, protocol=4)

    path = tmp_path / "safe_multi_stream.pkl.zlib"
    path.write_bytes(zlib.compress(payload_a) + zlib.compress(payload_b))

    result = CompressedScanner().scan(str(path))

    assert result.success is True
    assert not any(
        check.name == "Compressed Wrapper Stream Decode" and check.status == CheckStatus.FAILED
        for check in result.checks
    )
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


@pytest.mark.parametrize(
    ("filename", "compressor"),
    [
        ("safe_multi_stream.pkl.bz2", bz2.compress),
        ("safe_multi_stream.pkl.xz", lzma.compress),
    ],
)
def test_compressed_scanner_allows_concatenated_bzip2_and_xz_members(
    tmp_path: Path,
    filename: str,
    compressor: Callable[[bytes], bytes],
) -> None:
    """Concatenated valid members should remain supported for bzip2 and xz."""
    payload_a = pickle.dumps({"weights": [1, 2, 3]}, protocol=4)
    payload_b = pickle.dumps({"bias": [4, 5, 6]}, protocol=4)

    path = tmp_path / filename
    path.write_bytes(compressor(payload_a) + compressor(payload_b))

    result = CompressedScanner().scan(str(path))

    assert result.success is True
    assert not any(
        check.name == "Compressed Wrapper Stream Decode" and check.status == CheckStatus.FAILED
        for check in result.checks
    )
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_rejects_raw_trailer_after_lz4_frame(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A raw trailer after a valid lz4 frame must not hide an unscanned pickle payload."""
    safe_pickle = pickle.dumps({"safe": [1, 2, 3]})
    malicious_pickle_trailer = b'cos\nsystem\n(S"echo owned"\ntR.'
    fake_lz4_frame = _FakeLz4FrameModule({b"S": safe_pickle})

    monkeypatch.setattr(CompressedScanner, "_get_lz4_frame_module", staticmethod(lambda: fake_lz4_frame))

    path = tmp_path / "payload.pkl.lz4"
    path.write_bytes(_LZ4_FRAME_MAGIC + b"S" + malicious_pickle_trailer)

    result = CompressedScanner().scan(str(path))

    decode_checks = [check for check in result.checks if check.name == "Compressed Wrapper Stream Decode"]
    assert decode_checks and decode_checks[0].status == CheckStatus.FAILED
    assert "invalid lz4 stream" in decode_checks[0].message.lower()
    assert result.success is False
    assert result.has_warnings is True
    assert result.has_errors is False
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_rejects_raw_trailer_after_lz4_chunk_api_frame(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The legacy chunk API fallback must also fail closed on raw trailer bytes."""
    safe_pickle = pickle.dumps({"safe": [1, 2, 3]})
    malicious_pickle_trailer = b'cos\nsystem\n(S"echo owned"\ntR.'
    fake_lz4_frame = _FakeLz4ChunkModule({b"S": safe_pickle})

    monkeypatch.setattr(CompressedScanner, "_get_lz4_frame_module", staticmethod(lambda: fake_lz4_frame))

    path = tmp_path / "payload.pkl.lz4"
    path.write_bytes(_LZ4_FRAME_MAGIC + b"S" + malicious_pickle_trailer)

    result = CompressedScanner().scan(str(path))

    decode_checks = [check for check in result.checks if check.name == "Compressed Wrapper Stream Decode"]
    assert decode_checks and decode_checks[0].status == CheckStatus.FAILED
    assert "invalid lz4 stream" in decode_checks[0].message.lower()
    assert result.success is False
    assert result.has_warnings is True
    assert result.has_errors is False
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_allows_concatenated_lz4_frames(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Concatenated valid lz4 frames should remain supported when lz4 is installed."""
    payload_a = pickle.dumps({"weights": [1, 2, 3]}, protocol=4)
    payload_b = pickle.dumps({"bias": [4, 5, 6]}, protocol=4)
    fake_lz4_frame = _FakeLz4FrameModule({b"A": payload_a, b"B": payload_b})

    monkeypatch.setattr(CompressedScanner, "_get_lz4_frame_module", staticmethod(lambda: fake_lz4_frame))

    path = tmp_path / "safe_multi_frame.pkl.lz4"
    path.write_bytes(_LZ4_FRAME_MAGIC + b"A" + _LZ4_FRAME_MAGIC + b"B")

    result = CompressedScanner().scan(str(path))

    assert result.success is True
    assert not any(
        check.name == "Compressed Wrapper Stream Decode" and check.status == CheckStatus.FAILED
        for check in result.checks
    )
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_allows_concatenated_lz4_chunk_api_frames(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The legacy chunk API fallback should preserve valid concatenated lz4 frames."""
    payload_a = pickle.dumps({"weights": [1, 2, 3]}, protocol=4)
    payload_b = pickle.dumps({"bias": [4, 5, 6]}, protocol=4)
    fake_lz4_frame = _FakeLz4ChunkModule({b"A": payload_a, b"B": payload_b})

    monkeypatch.setattr(CompressedScanner, "_get_lz4_frame_module", staticmethod(lambda: fake_lz4_frame))

    path = tmp_path / "safe_multi_frame.pkl.lz4"
    path.write_bytes(_LZ4_FRAME_MAGIC + b"A" + _LZ4_FRAME_MAGIC + b"B")

    result = CompressedScanner().scan(str(path))

    assert result.success is True
    assert not any(
        check.name == "Compressed Wrapper Stream Decode" and check.status == CheckStatus.FAILED
        for check in result.checks
    )
    assert not any(issue.severity == IssueSeverity.CRITICAL for issue in result.issues)


def test_compressed_scanner_missing_lz4_dependency_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    lz4_path = tmp_path / "payload.bin.lz4"
    lz4_path.write_bytes(b"\x04\x22\x4d\x18" + b"\x00" * 16)

    def _raise_missing_dependency() -> None:
        raise _MissingOptionalDependencyError("Optional dependency 'lz4' is not installed")

    monkeypatch.setattr(CompressedScanner, "_get_lz4_frame_module", staticmethod(_raise_missing_dependency))

    scanner = CompressedScanner()
    result = scanner.scan(str(lz4_path))

    dependency_checks = [c for c in result.checks if c.name == "Compressed Wrapper Optional Dependency"]
    assert dependency_checks and dependency_checks[0].status == CheckStatus.FAILED
    assert dependency_checks[0].severity == IssueSeverity.INFO
