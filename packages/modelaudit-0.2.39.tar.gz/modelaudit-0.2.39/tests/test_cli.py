import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from modelaudit import __version__
from modelaudit.cache.trusted_config_store import TrustedConfigStore
from modelaudit.cli import cli, expand_paths, format_text_output
from modelaudit.core import scan_model_directory_or_file
from modelaudit.models import ModelAuditResultModel, create_initial_audit_result
from tests.cli_output import parse_click_json_output


def default_remote_cache_dir() -> str:
    """Compute the CLI's default remote cache root at assertion time."""
    return str(Path.home() / ".modelaudit" / "cache")


def strip_ansi(text: str) -> str:
    """Strip ANSI color codes from text for testing."""
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def create_mock_scan_result(**kwargs: Any) -> ModelAuditResultModel:
    """Create a mock ModelAuditResultModel for testing."""
    result = create_initial_audit_result()

    # Set default values
    result.bytes_scanned = kwargs.get("bytes_scanned", 1024)
    result.files_scanned = kwargs.get("files_scanned", 1)
    result.has_errors = kwargs.get("has_errors", False)
    result.success = kwargs.get("success", True)

    # Add issues if provided
    if "issues" in kwargs:
        import time

        from modelaudit.scanners.base import Issue

        issues = []
        for issue_dict in kwargs["issues"]:
            issue = Issue(
                message=issue_dict.get("message", "Test issue"),
                severity=issue_dict.get("severity", "warning"),
                location=issue_dict.get("location"),
                timestamp=time.time(),
                details=issue_dict.get("details", {}),
                why=None,
                type=None,
            )
            issues.append(issue)
        result.issues = issues

    # Add assets if provided
    if "assets" in kwargs:
        from modelaudit.models import AssetModel

        assets = []
        for asset_dict in kwargs["assets"]:
            asset = AssetModel(
                path=asset_dict.get("path", "/test/path"),
                type=asset_dict.get("type", "test"),
                size=asset_dict.get("size", 0),
                tensors=asset_dict.get("tensors"),
                keys=asset_dict.get("keys"),
                contents=asset_dict.get("contents"),
            )
            assets.append(asset)
        result.assets = assets

    # Add scanners if provided
    if "scanners" in kwargs:
        result.scanner_names = kwargs["scanners"]

    # Add file metadata if provided
    if "file_metadata" in kwargs:
        from modelaudit.models import FileMetadataModel

        result.file_metadata = {
            path: metadata if isinstance(metadata, FileMetadataModel) else FileMetadataModel(**metadata)
            for path, metadata in kwargs["file_metadata"].items()
        }

    result.finalize_statistics()
    return result


def test_cli_help():
    """Test the CLI help command."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Usage:" in result.output
    assert "scan" in result.output  # Should list the scan command


def test_cli_version():
    """Test the CLI version command."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output


def test_scan_command_help():
    """Test the scan command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--help"])
    assert result.exit_code == 0
    assert "Usage:" in result.output
    assert "--blacklist" in result.output
    assert "--format" in result.output
    assert "--output" in result.output
    assert "--timeout" in result.output
    assert "--verbose" in result.output
    assert "--max-size" in result.output  # Updated from --max-file-size
    assert "--strict" in result.output  # New consolidated flag
    assert "--no-whitelist" in result.output
    assert "--dry-run" in result.output  # New flag
    assert "Defaults:" in result.output or "Automatic defaults:" in result.output


def test_scan_invalid_severity_level_option(tmp_path):
    """Invalid severity override values should fail fast."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--severity", "S101=SEVERE"])

    assert result.exit_code == 2
    assert "Invalid severity level" in result.output
    assert "CRITICAL" in result.output


def test_scan_unknown_rule_code_in_severity_option(tmp_path):
    """Unknown rule codes in --severity should fail fast."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--severity", "S9999=CRITICAL"])

    assert result.exit_code == 2
    assert "Unknown rule code" in result.output
    assert "S9999" in result.output


def test_scan_unknown_rule_code_in_suppress_option(tmp_path):
    """Unknown rule codes in --suppress should fail fast."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--suppress", "S9999"])

    assert result.exit_code == 2
    assert "Unknown rule code" in result.output
    assert "S9999" in result.output


def test_scan_does_not_auto_load_untrusted_local_config(tmp_path: Path) -> None:
    """Scanning should not auto-apply suppressions from local config files."""
    import tarfile

    model_file = tmp_path / "evil.tar"
    with tarfile.open(model_file, "w") as tar:
        payload_file = tmp_path / "payload.txt"
        payload_file.write_text("content")
        tar.add(payload_file, arcname="../evil.txt")

    (tmp_path / ".modelaudit.toml").write_text('suppress = ["S405"]\n')

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(model_file), "--format", "json"], catch_exceptions=False)

    assert result.exit_code == 1
    output_payload = parse_click_json_output(result.output)
    assert any(issue.get("rule_code") == "S405" for issue in output_payload.get("issues", []))


def test_scan_json_subprocess_separates_logs_from_stdout_for_findings(tmp_path: Path) -> None:
    """Real process execution should keep JSON stdout parseable even when findings are logged."""
    import tarfile

    model_file = tmp_path / "evil.tar"
    with tarfile.open(model_file, "w") as tar:
        payload_file = tmp_path / "payload.txt"
        payload_file.write_text("content")
        tar.add(payload_file, arcname="../evil.txt")

    completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(model_file), "--format", "json"],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 1
    assert completed.stdout.lstrip().startswith("{")
    output_payload = json.loads(completed.stdout)
    assert any(issue.get("rule_code") == "S405" for issue in output_payload.get("issues", []))
    assert "[S405]" in completed.stderr


def test_scan_json_subprocess_single_skipped_file_keeps_stdout_parseable(tmp_path: Path) -> None:
    """Single-file skips should not prepend human text ahead of JSON stdout."""
    skipped_file = tmp_path / "skip.py"
    skipped_file.write_text("print('hello')\n")

    completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(skipped_file), "--format", "json"],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 2
    assert "Skipping non-model file:" not in completed.stdout
    assert completed.stdout.lstrip().startswith("{")

    output_payload = json.loads(completed.stdout)
    assert output_payload["files_scanned"] == 0
    assert output_payload["issues"] == []


def test_scan_json_subprocess_mixed_directory_keeps_stdout_parseable(tmp_path: Path) -> None:
    """Directory scans should remain valid JSON when non-model files are skipped."""
    import pickle

    skipped_file = tmp_path / "skip.py"
    skipped_file.write_text("print('hello')\n")
    model_file = tmp_path / "safe.pkl"
    model_file.write_bytes(pickle.dumps({"ok": 1}))

    completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(tmp_path), "--format", "json"],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0
    assert "Skipping non-model file:" not in completed.stdout
    assert completed.stdout.lstrip().startswith("{")

    output_payload = json.loads(completed.stdout)
    assert output_payload["files_scanned"] >= 1
    assert any(asset.get("path") == str(model_file) for asset in output_payload.get("assets", []))


def test_scan_sarif_subprocess_single_skipped_file_reports_cli_exit_code(tmp_path: Path) -> None:
    """SARIF invocation metadata should reflect the CLI exit code for skipped scans."""
    skipped_file = tmp_path / "skip.py"
    skipped_file.write_text("print('hello')\n")
    env = {**os.environ, "PROMPTFOO_DISABLE_TELEMETRY": "1"}

    completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(skipped_file), "--format", "sarif", "--no-cache"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )

    assert completed.returncode == 2
    sarif_payload = json.loads(completed.stdout)
    invocation = sarif_payload["runs"][0]["invocations"][0]
    assert invocation["exitCode"] == 2
    assert invocation["executionSuccessful"] is False
    assert invocation["exitCodeDescription"] == "No files were scanned"
    assert invocation["properties"]["filesScanned"] == 0


def test_scan_sarif_subprocess_preserves_modelaudit_rule_codes() -> None:
    """SARIF rule identifiers should match ModelAudit rule codes from JSON output."""
    model_file = Path("tests/assets/samples/pickles/malicious_system_call.pkl").resolve()
    env = {**os.environ, "PROMPTFOO_DISABLE_TELEMETRY": "1"}

    json_completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(model_file), "--format", "json", "--no-cache"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    sarif_completed = subprocess.run(
        [sys.executable, "-m", "modelaudit", "scan", str(model_file), "--format", "sarif", "--no-cache"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )

    assert json_completed.returncode == 1
    assert sarif_completed.returncode == 1

    json_payload = json.loads(json_completed.stdout)
    expected_rule_codes = {issue["rule_code"] for issue in json_payload["issues"] if issue.get("rule_code")}
    assert "S201" in expected_rule_codes

    sarif_payload = json.loads(sarif_completed.stdout)
    run = sarif_payload["runs"][0]
    result_rule_ids = {result["ruleId"] for result in run["results"]}
    result_property_rule_codes = {
        result["properties"]["rule_code"] for result in run["results"] if result.get("properties")
    }
    driver_rule_ids = {rule["id"] for rule in run["tool"]["driver"]["rules"]}
    driver_property_rule_codes = {
        rule["properties"]["rule_code"] for rule in run["tool"]["driver"]["rules"] if rule.get("properties")
    }

    assert expected_rule_codes <= result_rule_ids
    assert expected_rule_codes <= result_property_rule_codes
    assert expected_rule_codes <= driver_rule_ids
    assert expected_rule_codes <= driver_property_rule_codes
    assert run["invocations"][0]["exitCode"] == 1
    assert run["invocations"][0]["executionSuccessful"] is True


def test_scan_can_apply_local_config_once_when_confirmed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Interactive scans can apply a local config for the current run only."""
    import tarfile

    model_file = tmp_path / "evil.tar"
    with tarfile.open(model_file, "w") as tar:
        payload = tmp_path / "payload.txt"
        payload.write_text("content")
        tar.add(payload, arcname="../evil.txt")

    (tmp_path / ".modelaudit.toml").write_text('suppress = ["S405"]\n')
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("modelaudit.cli.can_use_trusted_local_config", lambda output_format: output_format == "text")
    monkeypatch.setattr(
        "modelaudit.cli.get_trusted_config_store",
        lambda: TrustedConfigStore(tmp_path / "cache" / "trusted_local_configs.json"),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(model_file), "--format", "text"], input="y\n", catch_exceptions=False)
    output = strip_ansi(result.output)

    assert result.exit_code == 0
    assert "Found local ModelAudit config" in output
    assert "Using local ModelAudit config" in output
    assert "NO ISSUES FOUND" in output
    trust_store = TrustedConfigStore(tmp_path / "cache" / "trusted_local_configs.json")
    assert not trust_store.store_path.exists()


def test_scan_can_remember_trusted_local_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Choosing to trust a local config should persist for future interactive runs."""
    import tarfile

    model_file = tmp_path / "evil.tar"
    with tarfile.open(model_file, "w") as tar:
        payload = tmp_path / "payload.txt"
        payload.write_text("content")
        tar.add(payload, arcname="../evil.txt")

    (tmp_path / ".modelaudit.toml").write_text('suppress = ["S405"]\n')
    trust_store = TrustedConfigStore(tmp_path / "cache" / "trusted_local_configs.json")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("modelaudit.cli.can_use_trusted_local_config", lambda output_format: output_format == "text")
    monkeypatch.setattr("modelaudit.cli.get_trusted_config_store", lambda: trust_store)

    runner = CliRunner()
    first_result = runner.invoke(
        cli,
        ["scan", str(model_file), "--format", "text"],
        input="a\n",
        catch_exceptions=False,
    )
    second_result = runner.invoke(cli, ["scan", str(model_file), "--format", "text"], catch_exceptions=False)

    assert first_result.exit_code == 0
    assert second_result.exit_code == 0
    assert trust_store.store_path.exists()
    assert "Found local ModelAudit config" in strip_ansi(first_result.output)
    assert "Found local ModelAudit config" not in strip_ansi(second_result.output)


def test_scan_reprompts_when_trusted_local_config_changes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Remembered trust should be invalidated when the local config file changes."""
    import tarfile

    model_file = tmp_path / "evil.tar"
    with tarfile.open(model_file, "w") as tar:
        payload = tmp_path / "payload.txt"
        payload.write_text("content")
        tar.add(payload, arcname="../evil.txt")

    config_path = tmp_path / ".modelaudit.toml"
    config_path.write_text('suppress = ["S405"]\n')
    trust_store = TrustedConfigStore(tmp_path / "cache" / "trusted_local_configs.json")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("modelaudit.cli.can_use_trusted_local_config", lambda output_format: output_format == "text")
    monkeypatch.setattr("modelaudit.cli.get_trusted_config_store", lambda: trust_store)

    runner = CliRunner()
    first_result = runner.invoke(
        cli,
        ["scan", str(model_file), "--format", "text"],
        input="a\n",
        catch_exceptions=False,
    )

    config_path.write_text("suppress = []\n")
    second_result = runner.invoke(
        cli,
        ["scan", str(model_file), "--format", "text"],
        input="n\n",
        catch_exceptions=False,
    )

    assert first_result.exit_code == 0
    assert second_result.exit_code == 1
    assert trust_store.store_path.exists()
    assert "Found local ModelAudit config" in strip_ansi(first_result.output)
    assert "Found local ModelAudit config" in strip_ansi(second_result.output)


def test_scan_disables_cache_when_local_config_is_applied(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Applying a local config should bypass scan-result caching for safety."""
    target_file = tmp_path / "model.dat"
    target_file.write_bytes(b"test content")
    (tmp_path / ".modelaudit.toml").write_text('suppress = ["S710"]\n')

    captured: dict[str, object] = {}

    def fake_scan_model_directory_or_file(path: str, **kwargs: Any) -> ModelAuditResultModel:
        captured["path"] = path
        captured.update(kwargs)
        return create_mock_scan_result()

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("modelaudit.cli.can_use_trusted_local_config", lambda output_format: output_format == "text")
    monkeypatch.setattr(
        "modelaudit.cli.get_trusted_config_store",
        lambda: TrustedConfigStore(tmp_path / "cache" / "trusted_local_configs.json"),
    )
    monkeypatch.setattr("modelaudit.cli.scan_model_directory_or_file", fake_scan_model_directory_or_file)

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(target_file), "--format", "text"], input="y\n", catch_exceptions=False)

    assert result.exit_code == 0
    assert captured["cache_enabled"] is False


def test_scan_nonexistent_file():
    """Test scanning a nonexistent file."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "nonexistent_file.pkl"])
    # The CLI might exit with a non-zero code for errors
    # But it should mention the error in the output
    assert "Error" in result.output
    assert "not exist" in result.output.lower() or "not found" in result.output.lower()


def test_scan_file(tmp_path):
    """Test scanning a file."""
    # Create a test file
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file)], catch_exceptions=True)

    # Just check that the command ran and produced some output
    assert result.output  # Should have some output
    # With automatic defaults, non-model files may be skipped or shown differently
    # Just check that it completed successfully
    assert result.exit_code == 0


def test_scan_directory(tmp_path):
    """Test scanning a directory."""
    # Create a test directory with files
    test_dir = tmp_path / "test_dir"
    test_dir.mkdir()
    (test_dir / "file1.pkl").write_bytes(b"test content 1")
    (test_dir / "file2.bin").write_bytes(b"test content 2")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_dir)], catch_exceptions=True)

    # Just check that the command ran and produced some output
    assert result.output  # Should have some output
    # Verify that the scan produced results (works with both text and JSON formats)
    assert (
        "Files:" in result.output
        or "Size:" in result.output
        or "bytes_scanned" in result.output
        or "files_scanned" in result.output
    )


def test_scan_multiple_paths(tmp_path):
    """Test scanning multiple paths."""
    # Create test files
    file1 = tmp_path / "file1.dat"
    file1.write_bytes(b"test content 1")

    file2 = tmp_path / "file2.dat"
    file2.write_bytes(b"test content 2")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(file1), str(file2)], catch_exceptions=True)

    # Just check that the command ran and produced some output
    assert result.output  # Should have some output
    # Verify that the scan produced results (works with both text and JSON formats)
    assert (
        "Files:" in result.output
        or "Size:" in result.output
        or "bytes_scanned" in result.output
        or "files_scanned" in result.output
    )


def test_scan_with_blacklist(tmp_path):
    """Test scanning with blacklist patterns."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["scan", str(test_file), "--blacklist", "pattern1", "--blacklist", "pattern2"],
        catch_exceptions=True,
    )

    # Just check that the command ran and produced some output
    assert result.output  # Should have some output
    assert result.exit_code == 0  # Command should complete successfully
    # With automatic defaults, the specific output format may vary


def test_scan_json_output(tmp_path):
    """Test scanning with JSON output format."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json"])

    # For JSON output, we should be able to parse the output as JSON
    # regardless of the exit code
    try:
        output_json = parse_click_json_output(result.output)
        assert "files_scanned" in output_json
        assert "issues" in output_json
        assert output_json["files_scanned"] == 1
    except json.JSONDecodeError:
        pytest.fail("Output is not valid JSON")


def test_scan_output_file(tmp_path):
    """Test scanning with output to a file."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    output_file = tmp_path / "output.txt"

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--output", str(output_file)])

    # The file should be created regardless of the exit code
    assert output_file.exists()
    assert output_file.read_text()  # Should not be empty
    assert f"Results written to {output_file}" in result.output


def test_scan_json_output_to_file(tmp_path):
    """Test scanning with JSON output to a file - JSON should be valid and not mixed with progress."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    output_file = tmp_path / "output.json"

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json", "--output", str(output_file)])

    # The file should be created
    assert output_file.exists()

    # JSON in file should be valid and parseable
    try:
        output_json = json.loads(output_file.read_text())
        assert "files_scanned" in output_json
        assert "issues" in output_json
        assert output_json["files_scanned"] == 1
    except json.JSONDecodeError:
        pytest.fail("JSON output file is not valid JSON")

    # Stdout should contain confirmation message (and potentially progress output)
    assert f"Results written to {output_file}" in result.output


def test_scan_json_to_stdout_no_progress_interference(tmp_path):
    """Test that JSON to stdout remains valid (no progress output mixed in)."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json"])

    # Output should be valid JSON when going to stdout (no progress interference)
    try:
        output_json = parse_click_json_output(result.output)
        assert "files_scanned" in output_json
        assert "issues" in output_json
    except json.JSONDecodeError:
        pytest.fail("JSON output to stdout is not valid JSON - may be corrupted by progress")


def test_scan_sbom_output(tmp_path):
    """Test scanning with SBOM output."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    sbom_file = tmp_path / "sbom.json"

    runner = CliRunner()
    runner.invoke(cli, ["scan", str(test_file), "--sbom", str(sbom_file)])

    assert sbom_file.exists()
    try:
        json.loads(sbom_file.read_text())
    except json.JSONDecodeError:
        pytest.fail("SBOM output is not valid JSON")


def test_scan_output_utf8_locale(tmp_path):
    """Ensure output file is valid UTF-8 even with ASCII locale."""
    test_file = tmp_path / "utf8_test.dat"
    test_file.write_bytes(b"test content")

    output_file = tmp_path / "output.txt"

    runner = CliRunner()
    env = os.environ.copy()
    env.update({"LC_ALL": "C", "LANG": "C"})
    runner.invoke(cli, ["scan", str(test_file), "--output", str(output_file)], env=env)

    assert output_file.exists()
    try:
        output_file.read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        pytest.fail("Output file is not valid UTF-8")


def test_scan_sbom_utf8_locale(tmp_path):
    """Ensure SBOM file is valid UTF-8 even with ASCII locale."""
    test_file = tmp_path / "utf8_test.dat"
    test_file.write_bytes(b"test content")

    sbom_file = tmp_path / "sbom.json"

    runner = CliRunner()
    env = os.environ.copy()
    env.update({"LC_ALL": "C", "LANG": "C"})
    runner.invoke(cli, ["scan", str(test_file), "--sbom", str(sbom_file)], env=env)

    assert sbom_file.exists()
    try:
        sbom_file.read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        pytest.fail("SBOM file is not valid UTF-8")


def test_scan_verbose_mode(tmp_path):
    """Test scanning in verbose mode."""
    test_file = tmp_path / "test_file.dat"
    test_file.write_bytes(b"test content")

    runner = CliRunner()
    # Use catch_exceptions=True to handle any errors in the CLI
    result = runner.invoke(
        cli,
        ["scan", str(test_file), "--verbose"],
        catch_exceptions=True,
    )

    # In verbose mode, we should see more output
    # With automatic defaults and new output format, check for successful completion
    assert result.output  # Should have some output
    assert result.exit_code == 0  # Should complete successfully
    # New output format may not contain "Scanning" text


def test_scan_max_file_size(tmp_path):
    """Test scanning with max file size limit."""
    # Create a file larger than our limit
    test_file = tmp_path / "large_file.dat"
    test_file.write_bytes(b"x" * 1000)  # 1000 bytes

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "scan",
            str(test_file),
            "--max-size",
            "500",  # 500 bytes limit
        ],
        catch_exceptions=True,
    )

    # Just check that the command ran and produced some output
    assert result.output  # Should have some output
    # Note: JSON output format doesn't include file paths
    assert "500" in result.output or "File too large" in result.output  # Should mention the max file size or error


def test_format_text_output():
    """Test the format_text_output function."""
    # Create a sample results dictionary
    results = {
        "path": "/path/to/model",
        "files_scanned": 5,
        "bytes_scanned": 1024,
        "duration": 0.5,
        "issues": [
            {
                "message": "Test issue",
                "severity": "warning",
                "location": "test.pkl",
                "details": {"test": "value"},
            },
        ],
        "has_errors": False,
    }

    # Test normal output
    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)
    assert "Files:" in clean_output and "5" in clean_output
    assert "Test issue" in clean_output
    assert "warning" in clean_output.lower()

    # Test verbose output
    output = format_text_output(results, verbose=True)
    clean_output = strip_ansi(output)
    assert "Files:" in clean_output and "5" in clean_output
    assert "Test issue" in clean_output
    assert "warning" in clean_output.lower()
    # Verbose might include details, but we can't guarantee it


def test_format_text_output_only_debug_issues():
    """Ensure debug-only issues result in a success status."""
    results = {
        "files_scanned": 1,
        "bytes_scanned": 10,
        "duration": 0.1,
        "issues": [
            {"message": "Debug info", "severity": "debug", "location": "file.pkl"},
        ],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)
    assert "No security issues detected" in clean_output
    assert "NO ISSUES FOUND" in clean_output


def test_format_text_output_operational_errors_status():
    """Ensure operational errors are surfaced in final text status."""
    results = {
        "files_scanned": 1,
        "bytes_scanned": 10,
        "duration": 0.1,
        "issues": [],
        "has_errors": True,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)
    assert "SCAN COMPLETED WITH OPERATIONAL ERRORS" in clean_output
    assert "NO ISSUES FOUND" not in clean_output


def test_format_text_output_only_info_issues():
    """Ensure info-only issues result in a success status."""
    results = {
        "files_scanned": 1,
        "bytes_scanned": 10,
        "duration": 0.1,
        "issues": [
            {"message": "Info message", "severity": "info", "location": "file.pkl"},
        ],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)
    assert "1 Info" in clean_output
    assert "INFORMATIONAL FINDINGS" in clean_output  # Info issues show INFORMATIONAL FINDINGS
    assert "WARNINGS DETECTED" not in clean_output


def test_format_text_output_debug_and_info_issues():
    """Ensure debug and info issues (no warnings) result in a success status."""
    results = {
        "files_scanned": 1,
        "bytes_scanned": 10,
        "duration": 0.1,
        "issues": [
            {"message": "Debug info", "severity": "debug", "location": "file1.pkl"},
            {"message": "Info message", "severity": "info", "location": "file2.pkl"},
        ],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=True)
    clean_output = strip_ansi(output)
    assert "1 Info" in clean_output
    assert "1 Debug" in clean_output
    assert "INFORMATIONAL FINDINGS" in clean_output  # Info issues show INFORMATIONAL FINDINGS
    assert "WARNINGS DETECTED" not in clean_output


def test_format_text_output_fast_scan_duration():
    """Test duration formatting for very fast scans (< 0.01 seconds)."""
    results = {
        "path": "/path/to/model",
        "files_scanned": 1,
        "bytes_scanned": 512,
        "duration": 0.005,  # Very fast scan < 0.01 seconds
        "issues": [],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)

    # Should show 3 decimal places for very fast scans
    assert "Duration:" in clean_output and "0.005s" in clean_output
    assert "Files:" in clean_output and "1" in clean_output
    assert "No security issues detected" in clean_output


def test_scan_huggingface_url_help():
    """Test that HuggingFace URL examples are in the help text."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--help"])
    assert result.exit_code == 0
    assert "hf://user/llama" in result.output  # Updated to new example format
    assert "s3://bucket/models/" in result.output
    assert "models:/model/v1" in result.output


def test_scan_jfrog_url_help():
    """Test that JFrog authentication is mentioned in the help text."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--help"])
    assert result.exit_code == 0
    assert "JFROG_API_TOKEN" in result.output  # Updated to check for auth info instead of URL example


def test_scan_mlflow_url_help():
    """Test that MLflow URL examples are in the help text."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--help"])
    assert result.exit_code == 0
    assert "models:/model/v1" in result.output  # Updated to match new example format
    assert "MLFLOW_TRACKING_URI" in result.output  # Check for auth info


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.download_model")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_huggingface_url_success(mock_rmtree, mock_scan, mock_download, mock_is_hf_url, tmp_path):
    """Test successful scanning of a HuggingFace URL."""
    # Setup mocks
    mock_is_hf_url.return_value = True
    # Create a real temp directory for the test
    test_model_dir = tmp_path / "test_model"
    test_model_dir.mkdir()
    # Create a dummy file inside to make it look like a real model
    (test_model_dir / "model.bin").write_text("dummy model")

    mock_download.return_value = test_model_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=1024, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "--format", "text", "https://huggingface.co/test/model"])

    # Should succeed
    assert result.exit_code == 0
    # With automatic defaults and new output format, check for successful completion
    assert (
        "SCAN SUMMARY" in result.output
        or "Files:" in result.output
        or "Duration:" in result.output
        or "Clean" in result.output
        or "Downloaded" in result.output
    )

    # Verify download was called
    mock_download.assert_called_once()

    # Verify scan was called with downloaded path
    mock_scan.assert_called_once()
    call_args = mock_scan.call_args
    assert call_args[0][0] == str(test_model_dir)
    provenance = call_args.kwargs["_trusted_source_provenance"]
    assert provenance.model_id == "test/model"
    assert provenance.model_source == "huggingface"

    # Verify cleanup was attempted (only when not using cache)
    mock_rmtree.assert_called()


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.download_model")
def test_scan_huggingface_url_download_failure(mock_download, mock_is_hf_url):
    """Test handling of download failure for HuggingFace URL."""
    # Setup mocks
    mock_is_hf_url.return_value = True
    mock_download.side_effect = Exception("Download failed")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "https://huggingface.co/test/model"])

    # Should fail with error code 2
    assert result.exit_code == 2
    assert "Error processing model" in result.output or "Error downloading model" in result.output
    assert "Download failed" in result.output


@patch("modelaudit.cli.download_file_from_hf")
def test_scan_huggingface_file_download_failure_redacts_url(mock_download_file):
    """Redact direct-file URL secrets from CLI download failures."""
    mock_download_file.side_effect = Exception(
        "Failed request https://huggingface.co/test/model/resolve/main/file.bin?token=hf_secret"
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["scan", "https://huggingface.co/test/model/resolve/main/file.bin?token=hf_secret"],
    )

    output = strip_ansi(result.output)
    assert result.exit_code == 2
    assert "hf_secret" not in output
    assert "token=" not in output
    assert "https://huggingface.co/test/model/resolve/main/file.bin" in output


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.download_model")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_huggingface_url_with_issues(mock_rmtree, mock_scan, mock_download, mock_is_hf_url, tmp_path):
    """Test scanning a HuggingFace URL that has security issues."""
    # Setup mocks
    mock_is_hf_url.return_value = True
    # Create a real temp directory for the test
    test_model_dir = tmp_path / "test_model"
    test_model_dir.mkdir()
    # Create a dummy file inside to make it look like a real model
    (test_model_dir / "model.pkl").write_text("dummy model")

    mock_download.return_value = test_model_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=2048,
        issues=[
            {
                "message": "Dangerous import detected",
                "severity": "critical",
                "location": "model.pkl",
            }
        ],
        files_scanned=1,
        assets=[],
        has_errors=False,
        scanners=["pickle_scanner"],
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--format", "text", "--no-cache", "hf://test/malicious-model"])

    # Should exit with code 1 (security issues found)
    assert result.exit_code == 1
    assert (
        "Downloaded" in result.output
        or "issue" in result.output.lower()
        or "Downloaded successfully" in result.output
        or "Downloading from" in result.output
    )

    # Verify cleanup was still attempted
    mock_rmtree.assert_called()


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.download_model")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_huggingface_no_cache_uses_ephemeral_cache_dir(
    mock_rmtree: MagicMock,
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_hf_url: MagicMock,
    tmp_path: Path,
) -> None:
    """No-cache HuggingFace model scans should use a private temp cache, not HF's shared cache."""
    mock_is_hf_url.return_value = True
    downloaded_dir = tmp_path / "downloaded"
    downloaded_dir.mkdir()
    (downloaded_dir / "model.safetensors").write_bytes(b"weights")
    mock_download.return_value = downloaded_dir
    mock_scan.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--quiet", "--no-cache", "hf://test/model"])

    assert result.exit_code == 0
    cache_dir = mock_download.call_args.kwargs["cache_dir"]
    assert isinstance(cache_dir, Path)
    assert cache_dir.name.startswith("modelaudit_hf_")
    mock_rmtree.assert_called()


@patch("tempfile.mkdtemp")
@patch("shutil.rmtree")
@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.download_model")
def test_scan_huggingface_no_cache_download_failure_cleans_ephemeral_cache_dir(
    mock_download: MagicMock,
    mock_is_hf_url: MagicMock,
    mock_rmtree: MagicMock,
    mock_mkdtemp: MagicMock,
    tmp_path: Path,
) -> None:
    """No-cache HuggingFace failures should still clean up the private temp cache directory."""
    mock_is_hf_url.return_value = True
    temp_cache_dir = tmp_path / "modelaudit_hf_failed"
    temp_cache_dir.mkdir()
    mock_mkdtemp.return_value = str(temp_cache_dir)
    mock_download.side_effect = Exception("Download failed")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "hf://test/model"])

    assert result.exit_code == 2
    mock_rmtree.assert_called_once_with(str(temp_cache_dir))


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_no_whitelist_passes_config_and_preserves_critical_exit_code(mock_scan: MagicMock, tmp_path: Path) -> None:
    """--no-whitelist should disable downgrade config and keep CRITICAL findings as exit-code 1."""
    test_file = tmp_path / "model.pkl"
    test_file.write_bytes(b"dummy")

    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=2048,
        issues=[
            {
                "message": "Dangerous import detected",
                "severity": "critical",
                "location": "model.pkl",
                "details": {},
            }
        ],
        files_scanned=1,
        assets=[],
        has_errors=False,
        scanners=["pickle_scanner"],
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json", "--no-whitelist"])

    assert result.exit_code == 1
    mock_scan.assert_called_once()
    assert mock_scan.call_args.kwargs["use_hf_whitelist"] is False


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_defaults_keep_whitelist_enabled(mock_scan: MagicMock, tmp_path: Path) -> None:
    """Without flags, whitelist downgrading remains enabled for backward compatibility."""
    test_file = tmp_path / "model.pkl"
    test_file.write_bytes(b"dummy")
    mock_scan.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json"])

    assert result.exit_code == 0
    mock_scan.assert_called_once()
    assert mock_scan.call_args.kwargs["use_hf_whitelist"] is True


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_strict_implies_no_whitelist_and_no_cache(mock_scan: MagicMock, tmp_path: Path) -> None:
    """--strict should imply both --no-whitelist and --no-cache."""
    test_file = tmp_path / "model.pkl"
    test_file.write_bytes(b"dummy")
    mock_scan.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json", "--strict"])

    assert result.exit_code == 0
    mock_scan.assert_called_once()
    assert mock_scan.call_args.kwargs["use_hf_whitelist"] is False
    assert mock_scan.call_args.kwargs["cache_enabled"] is False
    assert mock_scan.call_args.kwargs["skip_file_types"] is False


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_default_skips_non_model_python_files(mock_scan: MagicMock, tmp_path: Path) -> None:
    test_file = tmp_path / "helper.py"
    test_file.write_text("print('not a model')\n")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json"])
    parsed = parse_click_json_output(result.output)

    assert result.exit_code == 2
    mock_scan.assert_not_called()
    assert parsed["files_scanned"] == 0


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_strict_scans_non_model_python_files(mock_scan: MagicMock, tmp_path: Path) -> None:
    test_file = tmp_path / "helper.py"
    test_file.write_text("print('not a model')\n")
    mock_scan.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", str(test_file), "--format", "json", "--strict"])

    assert result.exit_code == 0
    mock_scan.assert_called_once()
    assert mock_scan.call_args.kwargs["skip_file_types"] is False


@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_mixed_paths_and_urls(mock_scan):
    """Test scanning both local paths and HuggingFace URLs in one command."""
    runner = CliRunner()

    with patch("modelaudit.cli.is_huggingface_url") as mock_is_hf, patch("os.path.exists") as mock_exists:
        # Setup mocks - first arg is local path, second is URL
        mock_is_hf.side_effect = [False, True]
        mock_exists.return_value = False  # Local path doesn't exist

        result = runner.invoke(cli, ["scan", "/local/path/model.pkl", "https://huggingface.co/test/model"])

        # Should report error for missing local file
        assert "Path does not exist: /local/path/model.pkl" in result.output


@patch("modelaudit.cli.is_pytorch_hub_url")
@patch("modelaudit.cli.download_pytorch_hub_model")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_pytorchhub_url_success(mock_rmtree, mock_scan, mock_download, mock_is_ph_url, tmp_path):
    """Test scanning a PyTorch Hub URL successfully."""
    mock_is_ph_url.return_value = True
    test_dir = tmp_path / "hub"
    test_dir.mkdir()
    (test_dir / "model.pt").write_text("dummy")
    mock_download.return_value = test_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=1, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "https://pytorch.org/hub/pytorch_vision_resnet/"])

    assert result.exit_code == 0
    mock_download.assert_called_once()
    mock_scan.assert_called_once()
    # With automatic defaults, PyTorch Hub URLs enable caching by default, so no cleanup
    mock_rmtree.assert_not_called()


@patch("modelaudit.cli.is_pytorch_hub_url")
@patch("modelaudit.cli.download_pytorch_hub_model")
def test_scan_pytorchhub_url_download_failure(mock_download, mock_is_ph_url):
    """Test download failure for PyTorch Hub URL."""
    mock_is_ph_url.return_value = True
    mock_download.side_effect = Exception("boom")
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "https://pytorch.org/hub/pytorch_vision_resnet/"])

    assert result.exit_code == 2
    assert "Error downloading model" in result.output


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
@patch("modelaudit.core.scan_model_streaming")
def test_scan_huggingface_streaming_success(mock_scan_streaming, mock_download_streaming, mock_is_hf_url, tmp_path):
    """Test streaming scan with --stream flag."""
    # Setup mocks
    mock_is_hf_url.return_value = True

    # Create temporary files for streaming
    test_files = []
    for i in range(3):
        test_file = tmp_path / f"model_shard_{i}.bin"
        test_file.write_text(f"dummy content {i}")
        test_files.append(test_file)

    # Mock file generator
    def file_generator():
        for i, f in enumerate(test_files):
            yield (f, i == len(test_files) - 1)

    mock_download_streaming.return_value = file_generator()

    # Mock streaming scan result with content_hash
    mock_result = create_mock_scan_result(bytes_scanned=300, files_scanned=3, has_errors=False)
    mock_result.content_hash = "a" * 64  # Mock SHA256 hash
    mock_scan_streaming.return_value = mock_result

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "--format", "json", "https://huggingface.co/test/streaming-model"])

    # Should succeed
    assert result.exit_code == 0

    # Verify streaming functions were called
    mock_download_streaming.assert_called_once()
    mock_scan_streaming.assert_called_once()
    streaming_provenance = mock_scan_streaming.call_args.kwargs["_trusted_source_provenance"]
    assert streaming_provenance.model_id == "test/streaming-model"
    assert streaming_provenance.model_source == "huggingface"

    # Verify content_hash is in JSON output
    try:
        output_json = parse_click_json_output(result.output)
        assert "content_hash" in output_json
        assert output_json["content_hash"] == "a" * 64
        assert output_json["files_scanned"] == 3
    except json.JSONDecodeError:
        pytest.fail("Output is not valid JSON")


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
@patch("modelaudit.core.scan_model_streaming")
@patch("shutil.rmtree")
def test_scan_huggingface_strict_streaming_uses_ephemeral_cache_dir(
    mock_rmtree: MagicMock,
    mock_scan_streaming: MagicMock,
    mock_download_streaming: MagicMock,
    mock_is_hf_url: MagicMock,
    tmp_path: Path,
) -> None:
    """Strict streaming scans should use a private temp cache instead of the shared HF cache."""
    mock_is_hf_url.return_value = True

    streamed_file = tmp_path / "weights.bin"
    streamed_file.write_bytes(b"weights")

    def file_generator():
        yield (streamed_file, True)

    mock_download_streaming.return_value = file_generator()
    mock_scan_streaming.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "--strict", "--quiet", "hf://test/model"])

    assert result.exit_code == 0
    cache_dir = mock_download_streaming.call_args.kwargs["cache_dir"]
    assert isinstance(cache_dir, Path)
    assert cache_dir.name.startswith("modelaudit_hf_")
    mock_rmtree.assert_called()


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
@patch("modelaudit.core.scan_model_streaming")
def test_scan_huggingface_streaming_sbom_includes_streamed_assets(
    mock_scan_streaming, mock_download_streaming, mock_is_hf_url, tmp_path
):
    """Streaming scans should build SBOM components from discovered artifacts."""
    mock_is_hf_url.return_value = True

    streamed_files = []
    file_hashes = {}
    file_sizes = {}
    for name in ("config.json", "model.safetensors", "tokenizer.json"):
        file_path = tmp_path / name
        content = f"streamed content for {name}".encode()
        file_path.write_bytes(content)
        streamed_files.append(file_path)
        import hashlib

        file_hashes[str(file_path)] = hashlib.sha256(content).hexdigest()
        file_sizes[str(file_path)] = len(content)

    def file_generator():
        for index, file_path in enumerate(streamed_files):
            yield (file_path, index == len(streamed_files) - 1)

    mock_download_streaming.return_value = file_generator()

    mock_result = create_mock_scan_result(
        bytes_scanned=sum(file_path.stat().st_size for file_path in streamed_files),
        files_scanned=len(streamed_files),
        has_errors=False,
        assets=[
            {
                "path": str(file_path),
                "type": "streamed",
                "size": file_sizes[str(file_path)],
            }
            for file_path in streamed_files
        ],
        file_metadata={
            str(file_path): {
                "file_size": file_sizes[str(file_path)],
                "file_hashes": {"sha256": file_hashes[str(file_path)]},
            }
            for file_path in streamed_files
        },
    )
    mock_scan_streaming.return_value = mock_result

    for file_path in streamed_files:
        file_path.unlink()

    sbom_file = tmp_path / "streamed.sbom.json"

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "--quiet", "--sbom", str(sbom_file), "hf://test/model"])

    assert result.exit_code == 0
    assert sbom_file.exists()
    sbom_data = json.loads(sbom_file.read_text())
    components = {component["name"]: component for component in sbom_data["components"]}

    assert set(components) == {file_path.name for file_path in streamed_files}
    assert "model" not in components

    for file_path in streamed_files:
        component = components[file_path.name]
        properties = {prop["name"]: prop["value"] for prop in component["properties"]}

        assert properties["size"] == str(file_sizes[str(file_path)])
        assert component["hashes"][0]["alg"] == "SHA-256"
        assert component["hashes"][0]["content"] == file_hashes[str(file_path)]


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.cli.is_huggingface_file_url", return_value=False)
@patch("modelaudit.cli.download_model")
@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_huggingface_sbom_excludes_download_cache_files(
    mock_scan, mock_download, mock_is_hf_file_url, mock_is_hf_url, tmp_path
):
    """Remote SBOM generation should ignore HuggingFace cache bookkeeping files."""
    mock_is_hf_url.return_value = True

    downloaded_dir = tmp_path / "gpt2"
    downloaded_dir.mkdir()
    real_files = {
        downloaded_dir / "config.json": b'{"model_type":"gpt2"}',
        downloaded_dir / "merges.txt": b"merge rules",
        downloaded_dir / "model.safetensors": b"weights",
    }
    for file_path, content in real_files.items():
        file_path.write_bytes(content)

    cache_dir = downloaded_dir / ".cache" / "huggingface" / "download"
    cache_dir.mkdir(parents=True)
    (cache_dir / "config.json.metadata").write_text("{}")
    (cache_dir / ".gitignore").write_text("*\n")

    mock_download.return_value = downloaded_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=sum(len(content) for content in real_files.values()),
        files_scanned=len(real_files),
        has_errors=False,
        assets=[
            {
                "path": str(file_path),
                "type": "streamed",
                "size": len(content),
            }
            for file_path, content in real_files.items()
        ],
    )

    sbom_file = tmp_path / "downloaded.sbom.json"

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--quiet", "--sbom", str(sbom_file), "hf://test/model"])

    assert result.exit_code == 0

    sbom_data = json.loads(sbom_file.read_text())
    component_names = {component["name"] for component in sbom_data["components"]}

    assert component_names == {file_path.name for file_path in real_files}
    assert "config.json.metadata" not in component_names
    assert ".gitignore" not in component_names


def test_scan_directory_skips_huggingface_cache_bookkeeping(tmp_path):
    """Directory scans should not surface HuggingFace cache bookkeeping files as assets."""
    model_dir = tmp_path / "model"
    model_dir.mkdir()
    (model_dir / "config.json").write_text('{"model_type":"gpt2"}')
    (model_dir / "model.safetensors").write_bytes(b"weights")

    cache_dir = model_dir / ".cache" / "huggingface" / "download"
    cache_dir.mkdir(parents=True)
    (cache_dir / "config.json.metadata").write_text("{}")
    (cache_dir / ".gitignore").write_text("*\n")

    result = scan_model_directory_or_file(str(model_dir))

    asset_names = {os.path.basename(asset.path) for asset in result.assets}
    assert "config.json" in asset_names
    assert "model.safetensors" in asset_names
    assert "config.json.metadata" not in asset_names
    assert ".gitignore" not in asset_names


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
@patch("modelaudit.core.scan_model_streaming")
def test_scan_huggingface_streaming_with_issues(mock_scan_streaming, mock_download_streaming, mock_is_hf_url, tmp_path):
    """Test streaming scan with security issues detected."""
    mock_is_hf_url.return_value = True

    # Mock file generator
    test_file = tmp_path / "malicious.pkl"
    test_file.write_text("malicious content")

    def file_generator():
        yield (test_file, True)

    mock_download_streaming.return_value = file_generator()

    # Mock scan result with issues
    mock_result = create_mock_scan_result(
        bytes_scanned=100,
        files_scanned=1,
        issues=[{"message": "Dangerous import detected", "severity": "critical", "location": "malicious.pkl"}],
        has_errors=False,
    )
    mock_result.content_hash = "b" * 64
    mock_scan_streaming.return_value = mock_result

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "hf://test/malicious-model"])

    # Should exit with code 1 (security issues found)
    assert result.exit_code == 1

    # Verify streaming functions were called
    mock_download_streaming.assert_called_once()
    mock_scan_streaming.assert_called_once()


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
def test_scan_huggingface_streaming_download_failure(mock_download_streaming, mock_is_hf_url):
    """Test handling of download failure in streaming mode."""
    mock_is_hf_url.return_value = True
    mock_download_streaming.side_effect = Exception("Streaming download failed")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "https://huggingface.co/test/model"])

    # Should fail with error code 2
    assert result.exit_code == 2
    assert "Error" in result.output


@patch("modelaudit.cli.is_huggingface_url")
@patch("modelaudit.utils.sources.huggingface.download_model_streaming")
@patch("modelaudit.core.scan_model_streaming")
def test_scan_huggingface_streaming_scan_errors(mock_scan_streaming, mock_download_streaming, mock_is_hf_url, tmp_path):
    """Test handling of scan errors during streaming."""
    mock_is_hf_url.return_value = True

    # Mock file generator
    test_file = tmp_path / "test.bin"
    test_file.write_text("test content")

    def file_generator():
        yield (test_file, True)

    mock_download_streaming.return_value = file_generator()

    # Mock scan result with errors
    mock_result = create_mock_scan_result(bytes_scanned=100, files_scanned=1, has_errors=True)
    mock_result.content_hash = "c" * 64
    mock_scan_streaming.return_value = mock_result

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "hf://test/model"])

    # Should exit with code 2 (scan errors)
    assert result.exit_code == 2

    # Verify streaming functions were called
    mock_download_streaming.assert_called_once()
    mock_scan_streaming.assert_called_once()


def test_scan_stream_help():
    """Test that --stream flag appears in help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--help"])
    assert result.exit_code == 0
    assert "--stream" in result.output
    assert "download files one-by-one" in result.output.lower() or "stream" in result.output.lower()


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_cloud_url_success(
    mock_rmtree: MagicMock,
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_cloud: MagicMock,
    tmp_path: Path,
) -> None:
    """Test scanning a cloud storage URL successfully."""
    mock_is_cloud.return_value = True
    test_dir = tmp_path / "cloud"
    test_dir.mkdir()
    (test_dir / "model.bin").write_text("dummy")
    mock_download.return_value = test_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=123, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "s3://bucket/model.bin"])

    assert result.exit_code == 0
    mock_download.assert_called_once()
    mock_rmtree.assert_called()


@patch("os.remove")
@patch("shutil.rmtree")
@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_cloud_file_no_cache_cleans_up_downloaded_file(
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_cloud: MagicMock,
    mock_rmtree: MagicMock,
    mock_remove: MagicMock,
    tmp_path: Path,
) -> None:
    """No-cache cloud scans should delete downloaded files, not treat them as directories."""
    mock_is_cloud.return_value = True
    downloaded_file = tmp_path / "downloaded-model.bin"
    downloaded_file.write_bytes(b"weights")
    mock_download.return_value = downloaded_file
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=123, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "s3://bucket/model.bin"])

    assert result.exit_code == 0
    mock_remove.assert_called_once_with(str(downloaded_file))
    mock_rmtree.assert_not_called()


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
def test_scan_cloud_url_download_failure(mock_download: MagicMock, mock_is_cloud: MagicMock) -> None:
    """Test download failure for cloud storage URL."""
    mock_is_cloud.return_value = True
    mock_download.side_effect = Exception("boom")
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "s3://bucket/model.bin"])

    assert result.exit_code == 2
    assert "Error downloading" in result.output


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
def test_scan_cloud_url_download_failure_redacts_signed_url(mock_download: MagicMock, mock_is_cloud: MagicMock) -> None:
    """Signed cloud URL secrets should not leak through shared CLI output."""
    url = "s3://bucket/model.bin?X-Amz-Signature=secret"
    mock_is_cloud.return_value = True
    mock_download.side_effect = Exception(f"Forbidden while opening {url}")
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", url])

    assert result.exit_code == 2
    assert "s3://bucket/model.bin" in result.output
    assert "X-Amz-Signature" not in result.output
    assert "secret" not in result.output


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_cloud_url_with_issues(
    mock_rmtree: MagicMock,
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_cloud: MagicMock,
    tmp_path: Path,
) -> None:
    """Test scanning a cloud storage URL that has issues."""
    mock_is_cloud.return_value = True
    test_dir = tmp_path / "cloud"
    test_dir.mkdir()
    (test_dir / "model.pkl").write_text("dummy")
    mock_download.return_value = test_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=123,
        issues=[{"message": "bad", "severity": "critical", "location": "model.pkl"}],
        files_scanned=1,
        assets=[],
        has_errors=False,
        scanners=["pickle"],
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "gs://bucket/model.pkl"])

    assert result.exit_code == 1
    mock_rmtree.assert_called()


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
@patch("modelaudit.cli.scan_model_directory_or_file")
@patch("shutil.rmtree")
def test_scan_cloud_url_no_cache_with_cache_dir_cleans_downloads(
    mock_rmtree: MagicMock,
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_cloud: MagicMock,
    tmp_path: Path,
) -> None:
    """--no-cache must not preserve remote downloads just because --cache-dir was provided."""
    mock_is_cloud.return_value = True
    test_dir = tmp_path / "cloud-nocache"
    test_dir.mkdir()
    (test_dir / "model.bin").write_text("dummy")
    mock_download.return_value = test_dir
    mock_scan.return_value = create_mock_scan_result(
        bytes_scanned=123, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test"]
    )

    cache_dir = tmp_path / "cache"
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--no-cache", "--cache-dir", str(cache_dir), "s3://bucket/model.bin"])

    assert result.exit_code == 0
    mock_download.assert_called_once()
    assert mock_download.call_args.kwargs["cache_dir"] is None
    mock_rmtree.assert_called()


@patch("modelaudit.cli.is_cloud_url")
@patch("modelaudit.cli.download_from_cloud")
@patch("modelaudit.cli.scan_model_directory_or_file")
def test_scan_cloud_url_strict_disables_selective_prefiltering(
    mock_scan: MagicMock,
    mock_download: MagicMock,
    mock_is_cloud: MagicMock,
    tmp_path: Path,
) -> None:
    """Strict mode should disable cloud-side selective filtering."""
    mock_is_cloud.return_value = True
    test_dir = tmp_path / "cloud-strict"
    test_dir.mkdir()
    (test_dir / "helper.py").write_text("print('strict cloud file')\n")
    mock_download.return_value = test_dir
    mock_scan.return_value = create_mock_scan_result(files_scanned=1, issues=[])

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--strict", "s3://bucket/model-prefix/"])

    assert result.exit_code == 0
    mock_download.assert_called_once()
    assert mock_download.call_args.kwargs["selective"] is False
    mock_scan.assert_called_once()
    assert mock_scan.call_args.kwargs["skip_file_types"] is False


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_success(
    mock_scan_jfrog: MagicMock,
    mock_is_jfrog: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Test scanning a JFrog URL."""
    monkeypatch.setenv("HOME", str(tmp_path))
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.return_value = create_mock_scan_result(
        bytes_scanned=512, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "https://company.jfrog.io/artifactory/repo/model.bin"])

    assert result.exit_code == 0
    mock_scan_jfrog.assert_called_once_with(
        "https://company.jfrog.io/artifactory/repo/model.bin",
        api_token=None,
        access_token=None,
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        strict_license=False,
        skip_file_types=True,
        cache_enabled=True,
        cache_dir=default_remote_cache_dir(),
        selective_download=True,
        use_hf_whitelist=True,
    )


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_download_failure(mock_scan_jfrog, mock_is_jfrog):
    """Test handling of JFrog download failures."""
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.side_effect = Exception("fail")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "https://company.jfrog.io/artifactory/repo/model.bin"])

    assert result.exit_code == 2
    assert "Error downloading/scanning model" in result.output


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_download_failure_redacts_sensitive_url(mock_scan_jfrog, mock_is_jfrog):
    """JFrog CLI errors should not print URL credentials or query tokens."""
    raw_url = "https://user:leaky-pass@company.jfrog.io/artifactory/repo/model.bin?token=leaky-token"
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.side_effect = Exception(f"failed to fetch {raw_url}")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", raw_url])

    assert result.exit_code == 2
    assert "https://<credentials-redacted>@company.jfrog.io/artifactory/repo/model.bin" in result.output
    assert "user:leaky-pass" not in result.output
    assert "leaky-token" not in result.output
    assert "?token=" not in result.output


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_with_auth(
    mock_scan_jfrog: MagicMock,
    mock_is_jfrog: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Test scanning a JFrog URL with authentication."""
    monkeypatch.setenv("HOME", str(tmp_path))
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.return_value = create_mock_scan_result(
        bytes_scanned=512, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    runner = CliRunner()
    # Use environment variable instead of CLI flag
    result = runner.invoke(
        cli,
        [
            "scan",
            "https://company.jfrog.io/artifactory/repo/model.bin",
            "--timeout",
            "600",
        ],
        env={"JFROG_API_TOKEN": "test-token"},
    )

    assert result.exit_code == 0
    mock_scan_jfrog.assert_called_once_with(
        "https://company.jfrog.io/artifactory/repo/model.bin",
        api_token="test-token",
        access_token=None,
        timeout=600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        strict_license=False,
        skip_file_types=True,
        cache_enabled=True,
        cache_dir=default_remote_cache_dir(),
        selective_download=True,
        use_hf_whitelist=True,
    )


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_with_cache_dir(mock_scan_jfrog: MagicMock, mock_is_jfrog: MagicMock, tmp_path: Path) -> None:
    """Test scanning a JFrog URL with an explicit cache directory."""
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.return_value = create_mock_scan_result(
        bytes_scanned=512, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    cache_dir = tmp_path / "jfrog-cache"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["scan", "--cache-dir", str(cache_dir), "https://company.jfrog.io/artifactory/repo/model.bin"],
    )

    assert result.exit_code == 0
    mock_scan_jfrog.assert_called_once_with(
        "https://company.jfrog.io/artifactory/repo/model.bin",
        api_token=None,
        access_token=None,
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        strict_license=False,
        skip_file_types=True,
        cache_enabled=True,
        cache_dir=str(cache_dir),
        selective_download=True,
        use_hf_whitelist=True,
    )


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_no_cache_overrides_cache_dir(
    mock_scan_jfrog: MagicMock, mock_is_jfrog: MagicMock, tmp_path: Path
) -> None:
    """Test that --no-cache disables JFrog caching even when --cache-dir is set."""
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.return_value = create_mock_scan_result(
        bytes_scanned=512, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    cache_dir = tmp_path / "jfrog-cache"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "scan",
            "--cache-dir",
            str(cache_dir),
            "--no-cache",
            "https://company.jfrog.io/artifactory/repo/model.bin",
        ],
    )

    assert result.exit_code == 0
    mock_scan_jfrog.assert_called_once_with(
        "https://company.jfrog.io/artifactory/repo/model.bin",
        api_token=None,
        access_token=None,
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        strict_license=False,
        skip_file_types=True,
        cache_enabled=False,
        cache_dir=None,
        selective_download=True,
        use_hf_whitelist=True,
    )


@patch("modelaudit.cli.is_jfrog_url")
@patch("modelaudit.cli.scan_jfrog_artifact")
def test_scan_jfrog_url_strict_disables_selective_prefiltering(
    mock_scan_jfrog: MagicMock, mock_is_jfrog: MagicMock
) -> None:
    """Strict JFrog scans should disable folder prefiltering before scanning."""
    mock_is_jfrog.return_value = True
    mock_scan_jfrog.return_value = create_mock_scan_result(
        bytes_scanned=512, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--strict", "https://company.jfrog.io/artifactory/repo/models/"])

    assert result.exit_code == 0
    assert mock_scan_jfrog.call_args.kwargs["selective_download"] is False
    assert mock_scan_jfrog.call_args.kwargs["skip_file_types"] is False
    assert mock_scan_jfrog.call_args.kwargs["use_hf_whitelist"] is False
    assert mock_scan_jfrog.call_args.kwargs["cache_enabled"] is False
    assert mock_scan_jfrog.call_args.kwargs["cache_dir"] is None


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_success(
    mock_scan_mlflow: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Test successful scanning of an MLflow URI."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # Setup mock
    mock_scan_mlflow.return_value = create_mock_scan_result(
        bytes_scanned=1024, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    runner = CliRunner()
    result = runner.invoke(
        cli, ["scan", "--format", "text", "models:/TestModel/1"], env={"MLFLOW_TRACKING_URI": "http://localhost:5000"}
    )

    # Should succeed
    assert result.exit_code == 0
    # Check for scan summary or successful completion indicators
    assert (
        "SCAN SUMMARY" in result.output
        or "Files:" in result.output
        or "Duration:" in result.output
        or "Clean" in result.output
    )

    # Verify MLflow scan was called with correct parameters
    mock_scan_mlflow.assert_called_once_with(
        "models:/TestModel/1",
        registry_uri="http://localhost:5000",
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        cache_enabled=True,
        cache_dir=default_remote_cache_dir(),
        use_hf_whitelist=True,
    )


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_with_options(
    mock_scan_mlflow: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Test MLflow URI scanning with additional options."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # Setup mock
    mock_scan_mlflow.return_value = create_mock_scan_result(
        bytes_scanned=2048,
        issues=[{"message": "Test issue", "severity": "warning"}],
        files_scanned=1,
        assets=[],
        has_errors=False,
        scanners=["test_scanner"],
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "scan",
            "models:/TestModel/Production",
            "--timeout",
            "600",
            "--max-size",
            "5000000",  # Combined limit (using the larger value)
            "--verbose",
        ],
        env={"MLFLOW_TRACKING_URI": "http://mlflow.example.com"},
    )

    # Should succeed with findings
    assert result.exit_code == 1  # Exit code 1 indicates issues found

    # Verify MLflow scan was called with environment-based options
    mock_scan_mlflow.assert_called_once_with(
        "models:/TestModel/Production",
        registry_uri="http://mlflow.example.com",
        timeout=600,
        blacklist_patterns=None,
        max_file_size=5000000,
        max_total_size=5000000,
        cache_enabled=True,
        cache_dir=default_remote_cache_dir(),
        use_hf_whitelist=True,
    )


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_with_cache_dir(mock_scan_mlflow: MagicMock, tmp_path: Path) -> None:
    """Test scanning an MLflow URI with an explicit cache directory."""
    mock_scan_mlflow.return_value = create_mock_scan_result(
        bytes_scanned=1024, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    cache_dir = tmp_path / "mlflow-cache"
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--cache-dir", str(cache_dir), "models:/TestModel/1"])

    assert result.exit_code == 0
    mock_scan_mlflow.assert_called_once_with(
        "models:/TestModel/1",
        registry_uri=None,
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        cache_enabled=True,
        cache_dir=str(cache_dir),
        use_hf_whitelist=True,
    )


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_no_cache_overrides_cache_dir(mock_scan_mlflow: MagicMock, tmp_path: Path) -> None:
    """Test that --no-cache disables MLflow caching even when --cache-dir is set."""
    mock_scan_mlflow.return_value = create_mock_scan_result(
        bytes_scanned=1024, issues=[], files_scanned=1, assets=[], has_errors=False, scanners=["test_scanner"]
    )

    cache_dir = tmp_path / "mlflow-cache"
    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--cache-dir", str(cache_dir), "--no-cache", "models:/TestModel/1"])

    assert result.exit_code == 0
    mock_scan_mlflow.assert_called_once_with(
        "models:/TestModel/1",
        registry_uri=None,
        timeout=3600,
        blacklist_patterns=None,
        max_file_size=0,
        max_total_size=0,
        cache_enabled=False,
        cache_dir=None,
        use_hf_whitelist=True,
    )


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_error(mock_scan_mlflow):
    """Test error handling for MLflow URI scanning."""
    # Setup mock to raise an error
    mock_scan_mlflow.side_effect = Exception("MLflow connection failed")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "models:/TestModel/1"])

    # Should fail with error code 2
    assert result.exit_code == 2
    assert "Error downloading model" in result.output
    assert "MLflow connection failed" in result.output


@patch("modelaudit.integrations.mlflow.scan_mlflow_model")
def test_scan_mlflow_uri_json_format(mock_scan_mlflow):
    """Test MLflow URI scanning with JSON output format."""
    # Setup mock
    mock_scan_mlflow.return_value = create_mock_scan_result(
        bytes_scanned=1024,
        issues=[],
        files_scanned=1,
        assets=[{"path": "model.pkl", "type": "pickle"}],
        has_errors=False,
        scanners=["pickle"],
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "models:/TestModel/1", "--format", "json"])

    # Should succeed and output JSON
    assert result.exit_code == 0

    # Should contain JSON output
    assert "bytes_scanned" in result.output
    assert "files_scanned" in result.output
    assert "assets" in result.output


def test_is_mlflow_uri():
    """Test the is_mlflow_uri helper function."""
    from modelaudit.cli import is_mlflow_uri

    # Test valid MLflow URIs
    assert is_mlflow_uri("models:/MyModel/1")
    assert is_mlflow_uri("models:/MyModel/Production")
    assert is_mlflow_uri("models:/MyModel/Staging")

    # Test invalid URIs
    assert not is_mlflow_uri("/path/to/model.pkl")
    assert not is_mlflow_uri("https://huggingface.co/model")
    assert not is_mlflow_uri("hf://model")
    assert not is_mlflow_uri("model.pkl")
    assert not is_mlflow_uri("models:invalid")


def test_format_text_output_normal_scan_duration():
    """Test duration formatting for normal scans (>= 0.01 seconds)."""
    results = {
        "path": "/path/to/model",
        "files_scanned": 2,
        "bytes_scanned": 2048,
        "duration": 0.25,  # Normal scan >= 0.01 seconds
        "issues": [],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)

    # Should show 2 decimal places for normal scans
    assert "Duration:" in clean_output and "0.25s" in clean_output
    assert "Files:" in clean_output and "2" in clean_output
    assert "No security issues detected" in clean_output


def test_format_text_output_edge_case_duration():
    """Test duration formatting for edge case exactly at 0.01 seconds."""
    results = {
        "path": "/path/to/model",
        "files_scanned": 1,
        "bytes_scanned": 1024,
        "duration": 0.01,  # Edge case exactly at threshold
        "issues": [],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)

    # Should show 2 decimal places (>= 0.01 branch)
    assert "Duration:" in clean_output and "0.01s" in clean_output
    assert "Files:" in clean_output and "1" in clean_output
    assert "No security issues detected" in clean_output


def test_format_text_output_very_fast_scan_with_issues():
    """Test duration formatting for very fast scan with issues."""
    results = {
        "path": "/path/to/model",
        "files_scanned": 1,
        "bytes_scanned": 256,
        "duration": 0.003,  # Very fast scan with issues
        "issues": [
            {
                "message": "Suspicious pattern detected",
                "severity": "warning",
                "location": "malicious.pkl",
                "details": {"pattern": "eval"},
            },
        ],
        "has_errors": False,
    }

    output = format_text_output(results, verbose=False)
    clean_output = strip_ansi(output)

    # Should show 3 decimal places for very fast scans
    assert "Duration:" in clean_output and "0.003s" in clean_output
    assert "Files:" in clean_output and "1" in clean_output
    assert "Suspicious pattern detected" in clean_output
    assert "warning" in output.lower()


def test_exit_code_clean_scan(tmp_path):
    """Test exit code 0 when scan is clean with no issues."""
    import pickle

    # Create a clean pickle file that should have no security issues
    test_file = tmp_path / "clean_model.pkl"
    data = {
        "weights": [1.0, 2.0, 3.0],
        "biases": [0.1, 0.2, 0.3],
        "model_name": "clean_model",
    }
    with (test_file).open("wb") as f:
        pickle.dump(data, f)

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--format", "text", str(test_file)])

    # Should exit with code 0 for clean scan
    assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
    # The output might not say "No issues found" if there are debug messages,
    # so let's be less strict
    assert "scan completed successfully" in result.output.lower() or "no issues found" in result.output.lower()


def test_exit_code_security_issues(tmp_path):
    """Test exit code 1 when security issues are found."""
    import pickle

    # Create a malicious pickle file
    evil_pickle_path = tmp_path / "malicious.pkl"

    class MaliciousClass:
        def __reduce__(self):
            return (os.system, ('echo "This is a malicious pickle"',))

    with evil_pickle_path.open("wb") as f:
        pickle.dump(MaliciousClass(), f)

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--format", "text", str(evil_pickle_path)])

    # Should exit with code 1 for security findings
    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}. Output: {result.output}"
    # Check for error, warning, or critical in output
    output_lower = result.output.lower()
    assert "error" in output_lower or "warning" in output_lower or "critical" in output_lower, (
        f"Expected 'error', 'warning', or 'critical' in output, but got: {result.output}"
    )


def test_exit_code_security_issues_streaming_local_directory(tmp_path: Path) -> None:
    """Streaming local-directory scans should keep security findings as exit code 1 without deleting originals."""
    import pickle

    evil_pickle_path = tmp_path / "malicious.pkl"
    expected_global = f"{os.system.__module__}.system"

    class MaliciousClass:
        def __reduce__(self):
            return (os.system, ('echo "This is a malicious pickle"',))

    with evil_pickle_path.open("wb") as f:
        pickle.dump(MaliciousClass(), f)

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "--format", "text", str(tmp_path)])

    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}. Output: {result.output}"
    assert expected_global in result.output, f"Expected malicious finding in output, got: {result.output}"
    assert evil_pickle_path.exists()


def test_exit_code_streaming_symlink_traversal_without_safe_files(tmp_path: Path, requires_symlinks: None) -> None:
    """Streaming traversal findings should exit 1 even when no files are ultimately scanned."""
    import pickle

    base_dir = tmp_path / "base"
    base_dir.mkdir()
    outside_dir = tmp_path / "outside"
    outside_dir.mkdir()

    with (outside_dir / "secret.pkl").open("wb") as f:
        pickle.dump({"data": "secret"}, f)

    symlink_path = base_dir / "link.pkl"
    symlink_path.symlink_to(outside_dir / "secret.pkl")

    runner = CliRunner()
    result = runner.invoke(cli, ["scan", "--stream", "--format", "text", str(base_dir)])

    output = strip_ansi(result.output)

    assert result.exit_code == 1, f"Expected exit code 1, got {result.exit_code}. Output: {result.output}"
    assert str(symlink_path) in output
    assert "Path traversal outside scanned directory" in output
    assert "CRITICAL SECURITY ISSUES FOUND" in output
    assert "NO FILES SCANNED" not in output


def test_exit_code_scan_errors(tmp_path):
    """Test exit code 2 when errors occur during scanning."""
    runner = CliRunner()

    # Try to scan a non-existent file
    result = runner.invoke(cli, ["scan", "/path/that/does/not/exist/file.pkl"])

    # Should exit with code 2 for scan errors
    assert result.exit_code == 2
    assert "Error" in result.output


def test_doctor_command():
    """Test the doctor command for scanner diagnostics."""
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code == 0
    assert "ModelAudit Scanner Diagnostic Report" in result.output
    assert "Python version:" in result.output
    assert "NumPy status:" in result.output
    assert "Total scanners:" in result.output
    assert "Loaded successfully:" in result.output
    assert "Failed to load:" in result.output


def test_doctor_command_with_show_failed():
    """Test the doctor command with --show-failed flag."""
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--show-failed"])

    assert result.exit_code == 0
    assert "ModelAudit Scanner Diagnostic Report" in result.output

    # Should show failed scanners if any exist
    if "Failed to load: 0" not in result.output:
        assert "Failed Scanners:" in result.output or "Recommendations:" in result.output


def test_doctor_command_numpy_status():
    """Test that doctor command provides NumPy compatibility information."""
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])

    assert result.exit_code == 0
    assert "NumPy" in result.output

    # Should provide either success message or recommendations
    success_indicators = ["All scanners loaded successfully!", "Recommendations:"]
    assert any(indicator in result.output for indicator in success_indicators)


# --- expand_paths and glob-empty-scan-paths tests ---


class TestExpandPaths:
    """Tests for the expand_paths function."""

    def test_expand_paths_literal_file(self, tmp_path):
        """Literal file path is resolved and returned."""
        f = tmp_path / "model.pkl"
        f.write_bytes(b"data")
        expanded, missing = expand_paths((str(f),))
        assert len(expanded) == 1
        assert str(f.resolve()) in expanded[0]
        assert missing == []

    def test_expand_paths_nonexistent_literal(self):
        """Non-existent literal path is kept as-is (no glob)."""
        expanded, missing = expand_paths(("/no/such/file.pkl",))
        assert expanded == ["/no/such/file.pkl"]
        assert missing == []

    def test_expand_paths_glob_matches(self, tmp_path):
        """Glob pattern that matches files returns them."""
        (tmp_path / "a.pkl").write_bytes(b"a")
        (tmp_path / "b.pkl").write_bytes(b"b")
        pattern = str(tmp_path / "*.pkl")
        expanded, missing = expand_paths((pattern,))
        assert len(expanded) == 2
        assert missing == []

    def test_expand_paths_glob_no_match(self, tmp_path):
        """Glob pattern matching nothing is reported in missing_globs."""
        pattern = str(tmp_path / "*.nonexistent")
        expanded, missing = expand_paths((pattern,))
        assert expanded == []
        assert missing == [pattern]

    def test_expand_paths_mixed_globs(self, tmp_path):
        """Mix of matching and non-matching globs."""
        (tmp_path / "model.h5").write_bytes(b"data")
        good = str(tmp_path / "*.h5")
        bad = str(tmp_path / "*.zzz")
        expanded, missing = expand_paths((good, bad))
        assert len(expanded) == 1
        assert missing == [bad]

    def test_expand_paths_recursive_glob(self, tmp_path):
        """Recursive glob (**) works."""
        sub = tmp_path / "subdir"
        sub.mkdir()
        (sub / "deep.bin").write_bytes(b"x")
        pattern = str(tmp_path / "**" / "*.bin")
        expanded, missing = expand_paths((pattern,))
        assert len(expanded) >= 1
        assert missing == []

    def test_expand_paths_question_mark_glob(self, tmp_path):
        """Single-char wildcard (?) is treated as a glob."""
        (tmp_path / "a.pt").write_bytes(b"x")
        pattern = str(tmp_path / "?.pt")
        expanded, missing = expand_paths((pattern,))
        assert len(expanded) == 1
        assert missing == []

    def test_expand_paths_signed_cloud_url_is_not_a_glob(self):
        """Signed cloud URLs may contain query wildcards but are not local globs."""
        url = "s3://bucket/model.bin?X-Amz-Signature=secret"

        expanded, missing = expand_paths((url,))
        assert expanded == [url]
        assert missing == []

    def test_expand_paths_url_query_is_not_glob(self):
        """Remote URLs with query strings should stay literal."""
        url = "https://company.jfrog.io/artifactory/repo/model.bin?token=secret"

        expanded, missing = expand_paths((url,))
        assert expanded == [url]
        assert missing == []

    def test_expand_paths_empty_input(self):
        """Empty tuple returns empty results."""
        expanded, missing = expand_paths(())
        assert expanded == []
        assert missing == []


class TestScanGlobFailFast:
    """Tests for scan command behavior with unmatched globs."""

    def test_scan_unmatched_glob_exits_2(self, tmp_path):
        """Scan with only unmatched globs exits with code 2."""
        runner = CliRunner()
        pattern = str(tmp_path / "*.nonexistent_extension")
        result = runner.invoke(cli, ["scan", pattern])
        assert result.exit_code == 2
        assert "No matching paths found" in strip_ansi(result.output + (result.stderr or ""))

    def test_scan_unmatched_glob_warns(self, tmp_path):
        """Scan with a mix of valid file + unmatched glob warns but continues."""
        f = tmp_path / "real.dat"
        f.write_bytes(b"content")
        bad_glob = str(tmp_path / "*.zzzzz")
        runner = CliRunner()
        result = runner.invoke(cli, ["scan", str(f), bad_glob], catch_exceptions=True)
        # Should NOT exit 2 since there's a valid path
        assert result.exit_code != 2
        # Warning should appear in stderr
        combined = strip_ansi(result.output + (result.stderr or ""))
        assert "did not match any files" in combined or "Warning" in combined

    @patch("modelaudit.cli.record_scan_failed")
    @patch("modelaudit.cli.flush_telemetry")
    def test_scan_unmatched_glob_records_telemetry(self, mock_flush, mock_record_failed, tmp_path):
        """Telemetry is recorded and flushed on early exit."""
        runner = CliRunner()
        pattern = str(tmp_path / "*.nonexistent_extension")
        runner.invoke(cli, ["scan", pattern])
        mock_record_failed.assert_called_once()
        # Duration should be a positive float, not hardcoded 0.0
        duration_arg = mock_record_failed.call_args[0][0]
        assert isinstance(duration_arg, float)
        assert duration_arg >= 0.0
        assert mock_record_failed.call_args[0][1] == "No matching paths"
        mock_flush.assert_called_once()

    @patch("modelaudit.cli.record_scan_failed")
    @patch("modelaudit.cli.flush_telemetry")
    def test_scan_invalid_max_size_records_telemetry(self, mock_flush, mock_record_failed, tmp_path):
        """Invalid --max-size should record telemetry failure and flush before exit."""
        runner = CliRunner()
        target = tmp_path / "model.pkl"
        target.write_bytes(b"content")

        result = runner.invoke(cli, ["scan", str(target), "--max-size", "not-a-size"])

        assert result.exit_code == 2
        assert "Error parsing --max-size" in result.output
        mock_record_failed.assert_called_once()
        duration_arg = mock_record_failed.call_args[0][0]
        assert isinstance(duration_arg, float)
        assert duration_arg >= 0.0
        assert "Invalid max-size" in mock_record_failed.call_args[0][1]
        mock_flush.assert_called_once()
