# Release Process

Releases are automated via [release-please](https://github.com/googleapis/release-please).

## Workflow

1. **Write Conventional Commits** - Use `feat:`, `fix:`, `docs:`, etc. prefixes
2. **Merge to main** - Release-please creates/updates a "Release PR" automatically
3. **Review Release PR** - Contains auto-generated CHANGELOG and version bump
4. **Merge Release PR** - Triggers GitHub Release and PyPI publish

## Version Scheme (0ver)

This project uses [0ver](https://0ver.org/) - we stay in 0.x.y indefinitely:

- `fix:` commits bump **patch** (0.2.21 -> 0.2.22)
- `feat:` commits bump **patch** (0.2.21 -> 0.2.22)
- `feat!:` or `BREAKING CHANGE:` bumps **minor** (0.2.21 -> 0.3.0)

## Manual Version Override

To force a specific version, add to your commit message:

```
feat: major new feature

Release-As: 1.0.0
```

## Commit Conventions

- **NEVER commit directly to main branch** - always create a feature branch
- Use Conventional Commit format for ALL commit messages
- Add user-visible entries under `## [Unreleased]` in `CHANGELOG.md` during feature/fix work
- release-please creates versioned release sections from commit history when the Release PR is merged
- Keep commit messages concise and descriptive

Examples:

```
feat: add support for TensorFlow SavedModel scanning
fix: handle corrupt pickle files gracefully
test: add unit tests for ONNX scanner
chore: update dependencies to latest versions
```

## Pull Request Guidelines

- **Branch naming**: `feat/scanner-improvements`, `fix/pickle-parsing`, `chore/update-deps`
- Create PRs using GitHub CLI: `gh pr create`
- Keep PR bodies short and focused
- **PR titles must follow Conventional Commits format** (validated by CI)
- Include minimal test instructions in PR body:

```markdown
## Test Instructions

uv run pytest tests/test_affected_component.py
uv run modelaudit test-file.pkl
```

## Pre-Release Checklist (Maintainers)

Before merging a release PR:

1. Confirm release PR version/changelog content looks correct.
2. Confirm required checks are green (`CI Success`, `Docker CI Success`, docs checks, CodeQL).
3. Confirm release build validation passed:
   - `twine check dist/*`
   - exactly one wheel + one sdist, both matching the release version
   - clean-room install smoke tests from wheel and sdist
   - project URL metadata checks (`Bug Tracker`, `Changelog`)
   - standalone `modelaudit-picklescan` Rust gates pass: `cargo fmt`,
     `cargo check`, `cargo clippy -D warnings`, `cargo test`, wheel build, and
     clean-room wheel smoke test
4. Confirm no unreviewed high-severity security findings are outstanding.
5. Merge release PR, then verify GitHub Release and PyPI publish completed.

## Rollback Procedure

If a release goes wrong, use the least disruptive rollback path:

1. If the release PR is not merged yet:
   - close or update the release PR and regenerate with new commits.
2. If GitHub release exists but PyPI publish failed:
   - fix workflow/secrets issues and rerun the failed publish job.
3. If a bad package version was published:
   - yank the affected version on PyPI,
   - ship a follow-up patch release with a clear changelog note.
4. If release metadata/tagging is incorrect:
   - prefer a corrective follow-up release over rewriting public history.
