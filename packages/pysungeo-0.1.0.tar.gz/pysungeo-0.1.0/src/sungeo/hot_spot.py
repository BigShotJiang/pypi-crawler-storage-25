"""
Local G (Getis-Ord Gi*) hotspot intensity statistic.

Calculate Local G hotspot statistics for spatial points and polygons.

Note
----
This implementation uses PySAL's ``esda.G_Local`` which follows the
Ord & Getis (1995) z-score formula. R's ``spdep::localG`` uses the
original Getis & Ord (1992) ratio-based formula with a different variance
normalization. Both correctly identify the same hot/cold spots (signs
and rankings match), but the z-score magnitudes differ systematically.
"""

from __future__ import annotations

import warnings

import geopandas as gpd
import numpy as np

# R spdep style → libpysal transform letter
_STYLE_MAP = {
    "W": "R",  # row-standardized
    "B": "B",  # binary
    "C": "D",  # globally standardized
    "S": "V",  # variance stabilizing
    "U": "O",  # original
}


def hot_spot(
    insert: gpd.GeoDataFrame,
    variable: str | np.ndarray | None = None,
    style: str = "W",
    k: int = 9,
    remove_missing: bool = True,
    NA_Value: float = 0,
    include_Moran: bool = False,
) -> gpd.GeoDataFrame:
    """Calculate Local G (Getis-Ord Gi*) hotspot intensity.

    Parameters
    ----------
    insert : GeoDataFrame
        Spatial layer (point or polygon geometries).
    variable : str or array-like
        Column name or numeric array of values to analyse.
    style : str
        Spatial weights style: ``"W"`` (row-standardised, default),
        ``"B"`` (binary), ``"C"`` (globally standardised), ``"U"``,
        ``"S"``.
    k : int
        Number of neighbours for k-NN (used for point geometries).
        Default ``9``.
    remove_missing : bool
        If ``True``, exclude rows with NA values.  If ``False``,
        substitute NAs with *NA_Value*.
    NA_Value : float
        Substitute for missing values when ``remove_missing=False``.
        Default ``0``.
    include_Moran : bool
        Also compute Local Moran's I.  Default ``False``.

    Returns
    -------
    GeoDataFrame
        Input with ``LocalG`` column appended (and ``LocalM`` if
        *include_Moran* is ``True``).
    """
    from esda.getisord import G_Local
    from esda.moran import Moran_Local
    from libpysal.weights import Queen, W

    insert = insert.copy()

    # ── resolve variable ─────────────────────────────────────────────
    if isinstance(variable, str):
        vals = insert[variable].to_numpy(dtype=float)
    elif variable is not None:
        vals = np.asarray(variable, dtype=float)
    else:
        raise ValueError("variable must be a column name or numeric array.")

    # ── detect geometry type ─────────────────────────────────────────
    geom_types = set(insert.geom_type)
    is_polygon = geom_types.issubset({"Polygon", "MultiPolygon"})
    is_point = geom_types.issubset({"Point", "MultiPoint"})

    if not is_polygon and not is_point:
        raise ValueError(
            "insert must contain only Polygon/MultiPolygon or Point geometries."
        )

    pysal_style = _STYLE_MAP.get(style.upper(), "R")

    # ── polygon path: queen contiguity → Gi (no self) ────────────────
    if is_polygon:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            w = Queen.from_dataframe(insert, silence_warnings=True)
        w.transform = pysal_style

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            lg = G_Local(vals, w, star=False)
        insert["LocalG"] = lg.Zs

        if include_Moran:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                lm = Moran_Local(vals, w)
            insert["LocalM"] = lm.Is

        return insert

    # ── point path: k-NN including self → Gi* ────────────────────────
    if is_point:
        na_mask = np.isnan(vals)
        if remove_missing and na_mask.any():
            keep = ~na_mask
            insert_clean = insert[keep].copy().reset_index(drop=True)
            vals_clean = vals[keep]
        elif not remove_missing and na_mask.any():
            vals = vals.copy()
            vals[na_mask] = NA_Value
            vals_clean = vals
            insert_clean = insert.copy().reset_index(drop=True)
            keep = None
        else:
            vals_clean = vals
            insert_clean = insert.copy().reset_index(drop=True)
            keep = None

        # Build KNN including self (matches R's RANN::nn2(X, X, k=k))
        from scipy.spatial import KDTree

        coords = np.column_stack([
            insert_clean.geometry.x, insert_clean.geometry.y
        ])
        tree = KDTree(coords)
        _, indices = tree.query(coords, k=k)

        neighbors = {i: indices[i].tolist() for i in range(len(coords))}
        weights_dict = {i: [1.0] * k for i in range(len(coords))}
        w = W(neighbors, weights_dict, silence_warnings=True)
        w.transform = pysal_style

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            lg = G_Local(vals_clean, w, star=True)

        if remove_missing and na_mask.any():
            insert["LocalG"] = np.nan
            insert.loc[~na_mask, "LocalG"] = lg.Zs
        else:
            insert["LocalG"] = lg.Zs

        if include_Moran:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                lm = Moran_Local(vals_clean, w)
            if remove_missing and na_mask.any():
                insert["LocalM"] = np.nan
                insert.loc[~na_mask, "LocalM"] = lm.Is
            else:
                insert["LocalM"] = lm.Is

        return insert