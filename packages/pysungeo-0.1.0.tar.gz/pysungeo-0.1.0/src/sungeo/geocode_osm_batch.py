"""
geocode_osm_batch  –  Batch geocode multiple addresses via Nominatim.

Python port of SUNGEO R package ``geocode_osm_batch.R``.

Loops over :func:`geocode_osm` with a configurable delay between
requests to respect Nominatim's rate-limit policy (max 1 req/sec).
"""

from __future__ import annotations

import time
import warnings
from typing import Optional

import pandas as pd

from sungeo.geocode_osm import geocode_osm


def geocode_osm_batch(
    query: list[str],
    delay: float = 1.0,
    match_num: int = 1,
    return_all: bool = False,
    details: bool = False,
    user_agent: Optional[str] = None,
    verbose: bool = False,
) -> pd.DataFrame:
    """Batch geocode multiple addresses via OpenStreetMap Nominatim.

    Parameters
    ----------
    query : list[str]
        List of address or place name strings to geocode.
    delay : float
        Seconds to wait between requests.  Default ``1.0``.
        Values below 1.0 are raised to 1.0 with a warning, per
        Nominatim usage policy.
    match_num : int
        Which match to return per query.  Default ``1``.
    return_all : bool
        If ``True``, return all matches per query.  Default ``False``.
    details : bool
        If ``True``, include extra columns (``osm_type``, ``importance``,
        bounding box).  Default ``False``.
    user_agent : str, optional
        HTTP User-Agent string.
    verbose : bool
        Print progress messages.  Default ``False``.

    Returns
    -------
    pandas.DataFrame
        Concatenated results for all queries, same columns as
        :func:`geocode_osm`.
    """

    if not query:
        raise ValueError("query must be a non-empty list of strings.")

    # Enforce minimum delay (matches R behavior)
    if delay < 1:
        warnings.warn(
            "OSM Nominatim Usage Policy requires maximum of 1 request "
            "per second. Setting delay to 1.",
            UserWarning,
            stacklevel=2,
        )
        delay = 1.0

    results = []

    for i, q in enumerate(query):
        # Per-query error handling (matches R's tryCatch per iteration)
        try:
            result = geocode_osm(
                query=q,
                match_num=match_num,
                return_all=return_all,
                details=details,
                user_agent=user_agent,
            )
        except Exception:
            # On any failure, produce an NA-filled row (matches R fallback)
            result = _fallback_row(q, details)

        results.append(result)

        # Sleep after every query including the last (matches R's Sys.sleep)
        time.sleep(delay)

        if verbose:
            addresses = "; ".join(result["address"].dropna().astype(str).tolist())
            print(f"{i + 1}/{len(query)} {addresses}")

    return pd.concat(results, ignore_index=True)


def _fallback_row(query: str, details: bool) -> pd.DataFrame:
    """Return a single-row DataFrame with NaN values (fallback on error)."""
    row = {
        "query": query,
        "osm_id": None,
        "address": None,
        "longitude": float("nan"),
        "latitude": float("nan"),
    }
    if details:
        row["osm_type"] = None
        row["importance"] = float("nan")
        row["bbox_ymin"] = float("nan")
        row["bbox_ymax"] = float("nan")
        row["bbox_xmin"] = float("nan")
        row["bbox_xmax"] = float("nan")

    out = pd.DataFrame([row])

    if details:
        col_order = [
            "query", "osm_id", "osm_type", "importance", "address",
            "longitude", "latitude",
            "bbox_ymin", "bbox_ymax", "bbox_xmin", "bbox_xmax",
        ]
    else:
        col_order = ["query", "osm_id", "address", "longitude", "latitude"]

    return out[[c for c in col_order if c in out.columns]]