"""
geocode_osm  –  Geocode addresses using OpenStreetMap's Nominatim API.

Python port of SUNGEO R package ``geocode_osm.R``.

Converts a place name or address string to geographic coordinates
(longitude, latitude) by querying the free Nominatim API.

**Nominatim usage policy:** max 1 request per second.
For batch geocoding, use :func:`geocode_osm_batch`.
"""

from __future__ import annotations

import warnings
from typing import Optional
from urllib.parse import quote

import pandas as pd
import requests


# Default User-Agent identifying this package
_DEFAULT_UA = "pysungeo/0.1.0 (SUNGEO Python geoprocessing toolkit)"

# Nominatim endpoint
_ROOT_URL = "https://nominatim.openstreetmap.org/search"


def geocode_osm(
    query: str,
    match_num: int = 1,
    return_all: bool = False,
    details: bool = False,
    user_agent: Optional[str] = None,
) -> pd.DataFrame:
    """Geocode an address or place name via OpenStreetMap Nominatim.

    Parameters
    ----------
    query : str
        Address or place name to geocode.  Must be a single string.
        For multiple addresses, use :func:`geocode_osm_batch`.
    match_num : int
        Which match to return if the query matches multiple locations.
        Default ``1`` (highest-ranking match by relevance).  1-indexed.
    return_all : bool
        If ``True``, return all matches (overrides *match_num*).
        Default ``False``.
    details : bool
        If ``True``, include ``osm_type``, ``importance``, and bounding
        box columns.  Default ``False``.
    user_agent : str, optional
        HTTP User-Agent string for the Nominatim request.  Nominatim
        requires a valid User-Agent identifying your application.
        Default: ``"pysungeo/0.1.0 ..."``.

    Returns
    -------
    pandas.DataFrame
        Columns (always): ``query``, ``osm_id``, ``address``,
        ``longitude``, ``latitude``.

        Additional columns if ``details=True``: ``osm_type``,
        ``importance``, ``bbox_ymin``, ``bbox_ymax``, ``bbox_xmin``,
        ``bbox_xmax``.

        If the query returns no results or the server is unreachable,
        returns a single-row DataFrame with ``NaN`` / ``None`` values.

    Examples
    --------
    >>> geocode_osm("Michigan Stadium")
           query     osm_id                address  longitude  latitude
    0  Michigan...  ...       Michigan Stadium...  -83.7485   42.2658

    >>> geocode_osm("Michigan Stadium", details=True)
    # … includes osm_type, importance, bbox_* columns
    """

    # ── Validate input ──
    if isinstance(query, (list, tuple)):
        if len(query) > 1:
            warnings.warn(
                "Returning first result only. Please use "
                "geocode_osm_batch() to geocode multiple addresses.",
                UserWarning,
                stacklevel=2,
            )
        query = query[0] if query else ""

    if not isinstance(query, str) or not query.strip():
        return _empty_result(query="" if not isinstance(query, str) else query,
                             details=details)

    # ── User-Agent ──
    if user_agent is None:
        user_agent = _DEFAULT_UA

    # ── Build URL and call API ──
    params = {
        "q": query,
        "format": "json",
        "polygon": "1",
        "addressdetails": "1",
    }

    try:
        resp = requests.get(
            _ROOT_URL,
            params=params,
            headers={"User-Agent": user_agent},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, ValueError) as exc:
        print(
            "Cannot access OSM server. Please check your internet "
            "connection and try again."
        )
        return _empty_result(query, details=details)

    # ── Parse results ──
    if not data:
        return _empty_result(query, details=details)

    # Select which matches to return
    if return_all:
        indices = list(range(len(data)))
    else:
        idx = match_num - 1  # convert 1-indexed to 0-indexed
        if idx < 0 or idx >= len(data):
            return _empty_result(query, details=details)
        indices = [idx]

    rows = []
    for i in indices:
        item = data[i]
        bbox = item.get("boundingbox", [None, None, None, None])
        row = {
            "query": query,
            "osm_id": str(item.get("osm_id", "")),
            "address": str(item.get("display_name", "")),
            "longitude": _safe_float(item.get("lon")),
            "latitude": _safe_float(item.get("lat")),
        }
        if details:
            row["osm_type"] = str(item.get("osm_type", ""))
            row["importance"] = _safe_float(item.get("importance"))
            row["bbox_ymin"] = _safe_float(bbox[0]) if len(bbox) > 0 else None
            row["bbox_ymax"] = _safe_float(bbox[1]) if len(bbox) > 1 else None
            row["bbox_xmin"] = _safe_float(bbox[2]) if len(bbox) > 2 else None
            row["bbox_xmax"] = _safe_float(bbox[3]) if len(bbox) > 3 else None
        rows.append(row)

    out = pd.DataFrame(rows)

    # Ensure column order matches R
    if details:
        col_order = [
            "query", "osm_id", "osm_type", "importance", "address",
            "longitude", "latitude",
            "bbox_ymin", "bbox_ymax", "bbox_xmin", "bbox_xmax",
        ]
    else:
        col_order = ["query", "osm_id", "address", "longitude", "latitude"]

    out = out[[c for c in col_order if c in out.columns]]
    return out


# ──────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────

def _safe_float(val) -> Optional[float]:
    """Convert a value to float, returning NaN on failure."""
    if val is None:
        return float("nan")
    try:
        return float(val)
    except (ValueError, TypeError):
        return float("nan")


def _empty_result(query: str, details: bool) -> pd.DataFrame:
    """Return a single-row DataFrame with NaN values (no result found)."""
    row = {
        "query": query,
        "osm_id": None,
        "address": None,
        "longitude": float("nan"),
        "latitude": float("nan"),
    }
    if details:
        row["osm_type"] = None
        row["importance"] = float("nan")
        row["bbox_ymin"] = float("nan")
        row["bbox_ymax"] = float("nan")
        row["bbox_xmin"] = float("nan")
        row["bbox_xmax"] = float("nan")

    out = pd.DataFrame([row])

    if details:
        col_order = [
            "query", "osm_id", "osm_type", "importance", "address",
            "longitude", "latitude",
            "bbox_ymin", "bbox_ymax", "bbox_xmin", "bbox_xmax",
        ]
    else:
        col_order = ["query", "osm_id", "address", "longitude", "latitude"]

    return out[[c for c in col_order if c in out.columns]]