"""
Fix polygon geometries.

Validate and repair broken/self-intersecting geometries in a GeoDataFrame
by iteratively applying a zero-width buffer.
"""

from __future__ import annotations

import warnings

import geopandas as gpd
from shapely.validation import make_valid


def fix_geom(x: gpd.GeoDataFrame, n_it: int = 10) -> gpd.GeoDataFrame:
    """Check validity and fix broken polygon geometries.

    Iteratively applies a zero-width buffer (up to *n_it* times) until all
    geometries pass ``shapely.is_valid``.  Falls back to
    ``shapely.validation.make_valid`` for stubborn cases.

    Parameters
    ----------
    x : GeoDataFrame
        Polygon layer to check and fix.
    n_it : int
        Maximum repair iterations.  Default ``10``.

    Returns
    -------
    GeoDataFrame
        Same structure as *x* with repaired geometries.

    Raises
    ------
    ValueError
        If geometries are still invalid after *n_it* iterations.
    """
    x = x.copy()

    for i in range(1, n_it + 1):
        validity = x.geometry.is_valid

        if validity.all():
            break

        # Zero-width buffer trick (same as R's st_buffer(x, dist=0))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            x.geometry = x.geometry.buffer(0)

        validity = x.geometry.is_valid

        if validity.all():
            break

        # Last iteration: try make_valid as final fallback
        if i == n_it:
            x.geometry = x.geometry.apply(make_valid)
            validity = x.geometry.is_valid
            if not validity.all():
                raise ValueError(
                    "Non-convergence for polygon; please increase n_it "
                    "or check whether the polygon is corrupted."
                )

    return x