"""
Relative scale and nesting coefficients.

Calculate relative scale and nesting metrics for changes of support
from a source polygon layer to an overlapping (but spatially misaligned)
destination polygon layer.
"""

from __future__ import annotations


import geopandas as gpd
import numpy as np
import pandas as pd

# All supported metric names
ALL_METRICS = (
    "rs", "rn", "rs_sym", "rn_sym", "rs_alt", "rn_alt",
    "rs_nn", "rn_nn", "p_intact", "full_nest", "ro", "gmi",
)


def nesting(
    poly_from: gpd.GeoDataFrame,
    poly_to: gpd.GeoDataFrame,
    metrix: str | list[str] = "all",
    tol_: float = 0.001,
    by_unit: bool = False,
) -> dict:
    """Calculate relative scale and nesting metrics between two polygon layers.

    Parameters
    ----------
    poly_from : GeoDataFrame
        Source polygon layer.
    poly_to : GeoDataFrame
        Destination polygon layer. Must have the same CRS as *poly_from*.
    metrix : str or list of str
        Which metrics to compute. ``"all"`` (default) returns every metric.
        Otherwise pass one or more of: ``"rs"``, ``"rn"``, ``"rs_sym"``,
        ``"rn_sym"``, ``"rs_alt"``, ``"rn_alt"``, ``"rs_nn"``, ``"rn_nn"``,
        ``"p_intact"``, ``"full_nest"``, ``"ro"``, ``"gmi"``.
    tol_ : float
        Minimum intersection area in square metres to keep (filters slivers).
        Default ``0.001``.
    by_unit : bool
        If ``True``, append a per-source-unit DataFrame as the ``"by_unit"``
        entry of the returned dict.

    Returns
    -------
    dict
        Keys are the requested metric names with float values.
        If *by_unit* is ``True``, the key ``"by_unit"`` maps to a
        :class:`~pandas.DataFrame` indexed by source unit row number.
    """

    # ── validate inputs ──────────────────────────────────────────────
    if poly_from is None or poly_to is None:
        raise ValueError(
            "poly_from and poly_to must both be GeoDataFrames with Polygon/MultiPolygon geometry."
        )
    for name, gdf in (("poly_from", poly_from), ("poly_to", poly_to)):
        geom_types = set(gdf.geom_type)
        if not geom_types.issubset({"Polygon", "MultiPolygon"}):
            raise ValueError(
                f"{name} must contain only Polygon or MultiPolygon geometries, "
                f"got {geom_types}."
            )

    # ── resolve metric list ──────────────────────────────────────────
    if isinstance(metrix, str):
        metrix = [metrix]
    if "all" in metrix:
        metrix = list(ALL_METRICS)
    else:
        metrix = [m for m in metrix if m in ALL_METRICS]
    if not metrix:
        raise ValueError(f"No valid metrics requested. Choose from {ALL_METRICS}.")

    # ── CRS alignment ────────────────────────────────────────────────
    # Make copies so we don't mutate caller's data
    poly_from = poly_from.copy()
    poly_to = poly_to.copy()

    if poly_from.crs != poly_to.crs:
        poly_from = poly_from.to_crs(poly_to.crs)

    # Reproject to WGS 84 first (if not already), then to LAEA
    if poly_from.crs is None or poly_from.crs.to_epsg() != 4326:
        poly_from = poly_from.to_crs(epsg=4326)
        poly_to = poly_to.to_crs(epsg=4326)

    coords = np.concatenate(
        [np.array(geom.exterior.coords) if geom.geom_type == "Polygon"
         else np.concatenate([np.array(p.exterior.coords) for p in geom.geoms])
         for geom in poly_to.geometry]
    )
    med_x = float(np.median(coords[:, 0]))
    med_y = float(np.median(coords[:, 1]))

    laea_crs = f"+proj=laea +lon_0={med_x} +lat_0={med_y}"
    poly_from = poly_from.to_crs(laea_crs)
    poly_to = poly_to.to_crs(laea_crs)

    # ── check bounding-box overlap ───────────────────────────────────
    from shapely.geometry import box

    b1 = box(*poly_from.total_bounds)
    b2 = box(*poly_to.total_bounds)
    if not b1.intersects(b2):
        raise ValueError("Zero overlap between polygons.")

    # ── assign temporary IDs and areas ───────────────────────────────
    poly_from = poly_from.reset_index(drop=True)
    poly_to = poly_to.reset_index(drop=True)
    poly_from["ID_1_"] = np.arange(1, len(poly_from) + 1)
    poly_to["ID_2_"] = np.arange(1, len(poly_to) + 1)
    poly_from["area_1_"] = poly_from.geometry.area
    poly_to["area_2_"] = poly_to.geometry.area

    # ── intersection ─────────────────────────────────────────────────
    o_sf = gpd.overlay(
        poly_from[["ID_1_", "area_1_", "geometry"]],
        poly_to[["ID_2_", "area_2_", "geometry"]],
        how="intersection",
        keep_geom_type=False,
    )
    o_sf["area_ix_"] = o_sf.geometry.area
    o_sf["area_in_"] = o_sf["area_ix_"] / o_sf["area_1_"]

    # Apply tolerance filter (used in every metric)
    df = pd.DataFrame(o_sf.drop(columns="geometry"))
    df_tol = df[df["area_in_"] > tol_].copy()

    # ── per-unit scaffold ────────────────────────────────────────────
    if by_unit:
        nesting_dt = pd.DataFrame({"index": np.arange(1, len(poly_from) + 1)})

    # ── metric computation ───────────────────────────────────────────
    results: dict = {}

    # --- rs -----------------------------------------------------------
    if "rs" in metrix:
        results["rs"] = float(
            (df_tol["area_1_"] < df_tol["area_2_"]).astype(float).mean()
        )
        if by_unit:
            byun = (
                df_tol.groupby("ID_1_")
                .apply(lambda g: (g["area_1_"] < g["area_2_"]).astype(float).mean(), include_groups=False)
            )
            nesting_dt["rs"] = nesting_dt["index"].map(byun)

    # --- rn (also needed for rn_sym) ----------------------------------
    if "rn" in metrix or "rn_sym" in metrix:
        rn_byun = df_tol.groupby("ID_1_").apply(
            lambda g: ((g["area_ix_"] / g["area_1_"]) ** 2).sum(),
            include_groups=False,
        )
        rn_val = float(rn_byun.mean())
        results["rn"] = rn_val  # may be overwritten if not requested, but harmless
        if by_unit and "rn" in metrix:
            nesting_dt["rn"] = nesting_dt["index"].map(rn_byun)

    # --- rs_sym -------------------------------------------------------
    if "rs_sym" in metrix:
        indicator = (
            (df_tol["area_1_"] < df_tol["area_2_"]).astype(float)
            - (df_tol["area_1_"] > df_tol["area_2_"]).astype(float)
        )
        results["rs_sym"] = float(indicator.mean())

    # --- rn_sym -------------------------------------------------------
    if "rn_sym" in metrix:
        # Reverse intersection: poly_to ∩ poly_from
        o_sf_2 = gpd.overlay(
            poly_to[["ID_2_", "area_2_", "geometry"]],
            poly_from[["ID_1_", "area_1_", "geometry"]],
            how="intersection",
            keep_geom_type=False,
        )
        o_sf_2["area_ix_"] = o_sf_2.geometry.area
        o_sf_2["area_in_"] = o_sf_2["area_ix_"] / o_sf_2["area_2_"]
        df2 = pd.DataFrame(o_sf_2.drop(columns="geometry"))
        df2_tol = df2[df2["area_in_"] > tol_]

        rn_reverse_byun = df2_tol.groupby("ID_2_").apply(
            lambda g: ((g["area_ix_"] / g["area_2_"]) ** 2).sum(),
            include_groups=False,
        )
        results["rn_sym"] = float(rn_val - rn_reverse_byun.mean())

    # remove rn from results if not explicitly requested
    if "rn" not in metrix:
        results.pop("rn", None)

    # --- rs_alt -------------------------------------------------------
    if "rs_alt" in metrix:
        mean_a2 = df_tol["area_2_"].mean()
        results["rs_alt"] = float(
            ((df_tol["area_2_"] - df_tol["area_1_"]) / mean_a2).mean()
        )
        if by_unit:
            byun = df_tol.groupby("ID_1_").apply(
                lambda g: float(((g["area_2_"] - g["area_1_"]) / g["area_2_"].mean()).mean()),
                include_groups=False,
            )
            nesting_dt["rs_alt"] = nesting_dt["index"].map(byun)

    # --- rn_alt -------------------------------------------------------
    if "rn_alt" in metrix:
        rn_alt_byun = df_tol.groupby("ID_1_")["area_in_"].max()
        results["rn_alt"] = float(rn_alt_byun.mean())
        if by_unit:
            nesting_dt["rn_alt"] = nesting_dt["index"].map(rn_alt_byun)

    # --- helper: full_nest_byun (used by rs_nn, rn_nn, full_nest) -----
    def _compute_full_nest_byun() -> pd.Series:
        """Return Series indexed by ID_1_ with 1 if unit is fully nested, 0 otherwise."""
        g = df_tol.groupby("ID_1_")
        coverage = g["area_ix_"].sum() / g["area_1_"].mean()
        count = g.size()
        return ((coverage == 1.0) & (count == 1)).astype(int)

    # --- rs_nn --------------------------------------------------------
    if "rs_nn" in metrix:
        fn_byun = _compute_full_nest_byun()
        non_nested_ids = fn_byun[fn_byun != 1].index
        nn_rows = df_tol[df_tol["ID_1_"].isin(non_nested_ids)]
        if len(nn_rows) > 0:
            results["rs_nn"] = float(
                (nn_rows["area_1_"] < nn_rows["area_2_"]).astype(float).mean()
            )
        else:
            results["rs_nn"] = np.nan
        if by_unit:
            rs_byun = df_tol.groupby("ID_1_").apply(
                lambda g: (g["area_1_"] < g["area_2_"]).astype(float).mean(),
                include_groups=False,
            )
            nesting_dt["rs_nn"] = nesting_dt["index"].map(rs_byun)
            nested_ids = fn_byun[fn_byun == 1].index
            nesting_dt.loc[nesting_dt["index"].isin(nested_ids), "rs_nn"] = np.nan

    # --- rn_nn --------------------------------------------------------
    if "rn_nn" in metrix:
        fn_byun = _compute_full_nest_byun()
        non_nested_ids = fn_byun[fn_byun != 1].index
        nn_rows = df_tol[df_tol["ID_1_"].isin(non_nested_ids)]
        if len(nn_rows) > 0:
            rn_nn_byun = nn_rows.groupby("ID_1_").apply(
                lambda g: ((g["area_ix_"] / g["area_1_"]) ** 2).sum(),
                include_groups=False,
            )
            results["rn_nn"] = float(rn_nn_byun.mean())
        else:
            results["rn_nn"] = np.nan
        if by_unit:
            rn_byun_all = df_tol.groupby("ID_1_").apply(
                lambda g: ((g["area_ix_"] / g["area_1_"]) ** 2).sum(),
                include_groups=False,
            )
            nesting_dt["rn_nn"] = nesting_dt["index"].map(rn_byun_all)
            nested_ids = fn_byun[fn_byun == 1].index
            nesting_dt.loc[nesting_dt["index"].isin(nested_ids), "rn_nn"] = np.nan

    # --- p_intact -----------------------------------------------------
    if "p_intact" in metrix:
        counts = df_tol.groupby("ID_1_").size()
        results["p_intact"] = float((counts == 1).mean())
        if by_unit:
            nesting_dt["p_intact"] = nesting_dt["index"].map(
                (counts == 1).astype(int)
            )

    # --- full_nest ----------------------------------------------------
    if "full_nest" in metrix:
        fn_byun = _compute_full_nest_byun()
        results["full_nest"] = float(fn_byun.mean())
        if by_unit:
            nesting_dt["full_nest"] = nesting_dt["index"].map(fn_byun)

    # --- ro -----------------------------------------------------------
    if "ro" in metrix:
        from shapely.ops import unary_union

        union_from = unary_union(poly_from.geometry.buffer(0))
        union_to = unary_union(poly_to.geometry.buffer(0))

        area_all_1 = union_from.area
        area_under_1 = union_from.difference(union_to).area
        area_all_2 = union_to.area
        area_under_2 = union_to.difference(union_from).area

        results["ro"] = float(
            (1 - area_under_2 / area_all_2) - (1 - area_under_1 / area_all_1)
        )

    # --- gmi ----------------------------------------------------------
    if "gmi" in metrix:
        gmi_byun = df_tol.groupby("ID_1_").apply(
            lambda g: 1 - ((g["area_ix_"] / g["area_1_"]) ** 2).sum(),
            include_groups=False,
        )
        results["gmi"] = float(gmi_byun.mean())
        if by_unit:
            nesting_dt["gmi"] = nesting_dt["index"].map(gmi_byun)

    # ── assemble output ──────────────────────────────────────────────
    # Preserve requested order
    out = {m: results[m] for m in metrix if m in results}
    if by_unit:
        out["by_unit"] = nesting_dt
    return out