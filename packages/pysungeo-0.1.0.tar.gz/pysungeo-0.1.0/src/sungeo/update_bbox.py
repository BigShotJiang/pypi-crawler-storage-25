"""
Update bounding box of a GeoDataFrame.

Recalculate the bounding box from actual geometry coordinates, e.g. after
subsetting or cropping.

Note
----
In ``geopandas``, ``GeoDataFrame.total_bounds`` is always computed on the
fly, so a stale bounding box is rarely a problem.  This function is provided
for R parity and for cases where an explicit refresh is desired.
"""

from __future__ import annotations

import geopandas as gpd


def update_bbox(sfobj: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Recalculate and update the bounding box of a GeoDataFrame.

    Parameters
    ----------
    sfobj : GeoDataFrame
        Layer whose bounding box should be refreshed.

    Returns
    -------
    GeoDataFrame
        A copy with the geometry column reset so that any cached spatial
        index or bounds metadata reflects the current geometries.
    """
    sfobj = sfobj.copy()
    # Re-assign the geometry column to force geopandas to rebuild its
    # internal spatial index and any cached bounds.
    sfobj = sfobj.set_geometry(sfobj.geometry.values)
    return sfobj