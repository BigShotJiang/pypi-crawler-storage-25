"""
get_info  –  Query metadata about available SUNGEO data files.

Python port of SUNGEO R package ``get_info.R``.

Reads the bundled ``available_data.json`` metadata file and reports
what countries, topics, geosets, spatial units, and year ranges are
available on the SUNGEO server.  Does NOT make live API calls.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional, Union

import pandas as pd


# ──────────────────────────────────────────────
#  Data loading
# ──────────────────────────────────────────────

_DATA_DIR = Path(__file__).resolve().parent / "data"


def _load_available_data() -> dict:
    """Load the available_data.json metadata bundled with the package."""
    path = _DATA_DIR / "available_data.json"
    with open(path, "r") as f:
        return json.load(f)


def _load_cc_dict() -> pd.DataFrame:
    """Load the country-code dictionary."""
    path = _DATA_DIR / "cc_dict.csv"
    return pd.read_csv(path, dtype=str)


def _names_to_iso3(country_names: list[str]) -> list[str]:
    """Convert country names to ISO-3 codes using cc_dict."""
    cc = _load_cc_dict()
    iso3s = []
    for name in country_names:
        match = cc.loc[cc["country_name_alt"] == name, "country_iso3"]
        if not match.empty:
            iso3s.append(match.iloc[0])
    return list(dict.fromkeys(iso3s))


# ──────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────

def _topic_to_df(entry) -> pd.DataFrame:
    """Convert a single available_data entry (list of dicts) to DataFrame."""
    if isinstance(entry, list):
        return pd.DataFrame(entry)
    if isinstance(entry, dict):
        return pd.DataFrame([entry])
    return pd.DataFrame()


def _filter_by_country(avail: dict, iso3s: list[str]) -> dict:
    """Filter each topic/geoset entry to rows matching the given ISO3 codes."""
    filtered = {}
    for key, entries in avail.items():
        df = _topic_to_df(entries)
        if "country_iso3" in df.columns:
            sub = df[df["country_iso3"].isin(iso3s)]
            if len(sub) > 0:
                filtered[key] = sub
    return filtered


def _summarize_countries(subset: dict) -> dict:
    """For each key, extract comma-separated country_iso3 values."""
    result = {}
    for key, df in subset.items():
        if isinstance(df, pd.DataFrame) and "country_iso3" in df.columns:
            result[key] = ", ".join(df["country_iso3"].tolist())
        else:
            result[key] = ""
    return result


def _summarize_units(subset: dict) -> dict:
    """For each key, extract comma-separated space_units values."""
    result = {}
    for key, df in subset.items():
        if isinstance(df, pd.DataFrame) and "space_units" in df.columns:
            all_units = set()
            for val in df["space_units"].dropna():
                all_units.update(str(val).split(", "))
            result[key] = ", ".join(sorted(all_units))
        else:
            result[key] = ""
    return result


def _summarize_years(subset: dict, topic_keys: list[str]) -> dict:
    """For each topic key, extract year ranges."""
    result = {}
    for key in topic_keys:
        if key in subset:
            df = subset[key] if isinstance(subset[key], pd.DataFrame) else _topic_to_df(subset[key])
            if "year_range" in df.columns:
                all_years = []
                for val in df["year_range"].dropna().unique():
                    all_years.extend(re.split(r"[,\-\s]+", str(val)))
                result[key] = ", ".join(sorted(set(all_years)))
            else:
                result[key] = ""
    return result


def _compute_year_range(years_by_topic: dict) -> str:
    """Compute the overall min-max year range from year strings."""
    all_nums = []
    for val in years_by_topic.values():
        for part in re.split(r"[,\-\s]+", str(val)):
            part = part.strip()
            if part.isdigit():
                all_nums.append(int(part))
    if all_nums:
        return f"{min(all_nums)}-{max(all_nums)}"
    return ""


def _make_desc(name: str, countries_str: str) -> str:
    """Build description: 'name (countries)' or 'name (N countries)' if >3."""
    n = len([c for c in countries_str.split(",") if c.strip()])
    if n > 3:
        return f"{name} ({n} countries)"
    return f"{name} ({countries_str})"


def _build_summary(
    n_countries: int,
    n_topics: int,
    n_units: int,
    n_geosets: int,
    topic_descs: list[str],
    geoset_descs: list[str],
    footer: str = "Please narrow your search criteria for more informative results.",
) -> list[str]:
    """Build the summary message lines."""
    lines = [
        "-----------------------------------------",
        "Summary of data available through SUNGEO",
        "-----------------------------------------",
        "",
        f"Found data for {n_countries} countries, {n_topics} topics",
        f"{n_units} spatial units, {n_geosets} geographic boundary sets",
        "",
        "-------",
        "Topics",
        "-------",
        *topic_descs,
        "",
        "-------",
        "Geosets",
        "-------",
        *geoset_descs,
        "",
        "-------",
        "See 'topics' and 'geosets' slots for details on spatial units and years.",
    ]
    if footer:
        lines.append(footer)
    lines.append("-------")
    return lines


# ──────────────────────────────────────────────
#  Public API
# ──────────────────────────────────────────────

def get_info(
    country_names: Optional[Union[str, list[str]]] = None,
    country_iso3s: Optional[Union[str, list[str]]] = None,
    topics: Optional[Union[str, list[str]]] = None,
) -> dict:
    """Query metadata about available SUNGEO data.

    Parameters
    ----------
    country_names : str or list[str], optional
        Country name(s) to filter by.
    country_iso3s : str or list[str], optional
        ISO-3 country code(s) to filter by.
    topics : str or list[str], optional
        Topic(s) to filter by, in ``"Category:Subcategory:Source"`` format.

    Returns
    -------
    dict
        Keys: ``"summary"`` (list of printable strings),
        ``"topics"`` (dict of DataFrames), ``"geosets"`` (dict of DataFrames).
    """

    # ── Normalise inputs ──
    if isinstance(country_names, str):
        country_names = [country_names]
    if isinstance(country_iso3s, str):
        country_iso3s = [country_iso3s]
    if isinstance(topics, str):
        topics = [topics]

    # ── Resolve country names → ISO3 ──
    if not country_iso3s and country_names:
        country_iso3s = _names_to_iso3(country_names)

    # ── Load metadata ──
    avail_all = _load_available_data()

    # Separate topic keys vs geoset keys
    all_topic_keys = [k for k in avail_all if not k.startswith("Geoset")]
    all_geoset_keys = [k for k in avail_all if k.startswith("Geoset")]

    # ══════════════════════════════════════════
    #  Mode 1: No filters (default)
    # ══════════════════════════════════════════
    if not country_iso3s and not topics:
        subset = {k: _topic_to_df(v) for k, v in avail_all.items()}
        return _build_output(subset, all_topic_keys, all_geoset_keys, avail_all,
                             footer="Please narrow your search criteria for more informative results.")

    # ══════════════════════════════════════════
    #  Mode 2: Filter by topic only
    # ══════════════════════════════════════════
    if not country_iso3s and topics:
        subset = {}
        for t in topics:
            if t in avail_all:
                subset[t] = _topic_to_df(avail_all[t])
        return _build_output_topic_filter(subset, topics, avail_all)

    # ══════════════════════════════════════════
    #  Mode 3: Filter by country only
    # ══════════════════════════════════════════
    if country_iso3s and not topics:
        subset = _filter_by_country(avail_all, country_iso3s)
        topic_keys = [k for k in subset if not k.startswith("Geoset")]
        geoset_keys = [k for k in subset if k.startswith("Geoset")]
        return _build_output(subset, topic_keys, geoset_keys, avail_all)

    # ══════════════════════════════════════════
    #  Mode 4: Filter by both topic and country
    # ══════════════════════════════════════════
    subset_by_country = _filter_by_country(avail_all, country_iso3s)
    subset = {}
    for t in topics:
        if t in subset_by_country:
            df = subset_by_country[t]
            if len(df) > 0:
                subset[t] = df
    return _build_output_topic_filter(subset, topics, avail_all)


# ──────────────────────────────────────────────
#  Output builders
# ──────────────────────────────────────────────

def _build_output(
    subset: dict,
    topic_keys: list[str],
    geoset_keys: list[str],
    avail_all: dict,
    footer: str = "",
) -> dict:
    """Build output for default / country-only modes."""

    country_map = _summarize_countries(subset)
    units_map = _summarize_units(subset)

    # Stats
    all_countries = set()
    for c in country_map.values():
        all_countries.update([x.strip() for x in c.split(",") if x.strip()])
    n_countries = len(all_countries)

    all_units = set()
    for u in units_map.values():
        all_units.update([x.strip() for x in u.split(",") if x.strip()])
    n_units = len(all_units)

    n_topics = len(topic_keys)
    n_geosets = len(geoset_keys)

    # Descriptions
    topic_descs = [
        _make_desc(k, country_map.get(k, ""))
        for k in topic_keys
    ]
    geoset_descs = [
        _make_desc(k, country_map.get(k, ""))
        for k in geoset_keys
    ]

    summary = _build_summary(
        n_countries, n_topics, n_units, n_geosets,
        topic_descs, geoset_descs, footer=footer,
    )

    for line in summary:
        print(line)

    topics_out = {k: subset[k] for k in topic_keys if k in subset}
    geosets_out = {k: subset[k] for k in geoset_keys if k in subset}

    return {"summary": summary, "topics": topics_out, "geosets": geosets_out}


def _build_output_topic_filter(
    subset: dict,
    requested_topics: list[str],
    avail_all: dict,
) -> dict:
    """Build output for topic-only / topic+country modes."""

    country_map = _summarize_countries(subset)
    units_map = _summarize_units(subset)

    # Stats
    all_countries = set()
    for c in country_map.values():
        all_countries.update([x.strip() for x in c.split(",") if x.strip()])
    n_countries = len(all_countries)

    all_units = set()
    for u in units_map.values():
        all_units.update([x.strip() for x in u.split(",") if x.strip()])
    n_units = len(all_units)

    # Find relevant geosets
    geoset_names = set()
    for k, df in subset.items():
        if isinstance(df, pd.DataFrame) and "geosets" in df.columns:
            for val in df["geosets"].dropna():
                geoset_names.update(re.split(r"[,\s]+", str(val)))
    geoset_keys = [f"Geoset:{g}" for g in sorted(geoset_names) if g]
    n_geosets = len(geoset_names)

    topic_keys = [k for k in subset if not k.startswith("Geoset")]
    n_topics = len(topic_keys)

    # Descriptions
    topic_descs = [
        _make_desc(k, country_map.get(k, ""))
        for k in topic_keys
    ]

    # Geoset descriptions: filter geoset data to relevant countries
    geoset_country_map = {}
    for gk in geoset_keys:
        if gk in avail_all:
            gdf = _topic_to_df(avail_all[gk])
            if "country_iso3" in gdf.columns:
                relevant = gdf[gdf["country_iso3"].isin(all_countries)]
                geoset_country_map[gk] = ", ".join(relevant["country_iso3"].tolist())
            else:
                geoset_country_map[gk] = ""
        else:
            geoset_country_map[gk] = ""

    geoset_descs = [
        _make_desc(k, geoset_country_map.get(k, ""))
        for k in geoset_keys
    ]

    summary = _build_summary(
        n_countries, n_topics, n_units, n_geosets,
        topic_descs, geoset_descs, footer="",
    )

    for line in summary:
        print(line)

    topics_out = {k: subset[k] for k in topic_keys if k in subset}

    # Geosets: filter to relevant countries
    geosets_out = {}
    for gk in geoset_keys:
        if gk in avail_all:
            gdf = _topic_to_df(avail_all[gk])
            if "country_iso3" in gdf.columns:
                geosets_out[gk] = gdf[gdf["country_iso3"].isin(all_countries)]
            else:
                geosets_out[gk] = gdf

    return {"summary": summary, "topics": topics_out, "geosets": geosets_out}