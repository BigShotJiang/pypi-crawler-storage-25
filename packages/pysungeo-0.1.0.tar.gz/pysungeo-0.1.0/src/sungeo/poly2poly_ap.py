"""
Area- and population-weighted polygon-to-polygon interpolation.

Interpolate values from a source polygon layer to an overlapping (but
spatially misaligned) destination polygon layer using area and/or
population weights.
"""

from __future__ import annotations

import warnings
from functools import reduce
from typing import Callable

import geopandas as gpd
import numpy as np
import pandas as pd


def _weighted_mean(x: np.ndarray, w: np.ndarray) -> float:
    """Default aggregation: weighted mean, ignoring NaN."""
    mask = ~(np.isnan(x) | np.isnan(w))
    if mask.sum() == 0:
        return np.nan
    return float(np.average(x[mask], weights=w[mask]))


def poly2poly_ap(
    poly_from: gpd.GeoDataFrame,
    poly_to: gpd.GeoDataFrame,
    poly_to_id: str,
    geo_vor: gpd.GeoDataFrame | None = None,
    methodz: str | list[str] = "aw",
    char_methodz: str = "aw",
    pop_raster=None,
    varz: str | list[str] | list[list[str]] | None = None,
    funz: Callable | list[Callable] | None = None,
    pycno_varz: str | list[str] | None = None,
    char_varz: str | list[str] | None = None,
    char_assign: str | list[str] = "biggest_overlap",
    seed: int = 1,
) -> gpd.GeoDataFrame:
    """Interpolate values from source polygons to destination polygons.

    Parameters
    ----------
    poly_from : GeoDataFrame
        Source polygon layer with variables to interpolate.
    poly_to : GeoDataFrame
        Destination polygon layer.
    poly_to_id : str
        Name of the unique ID column in *poly_to*.
    geo_vor : GeoDataFrame, optional
        Voronoi polygons (used internally by ``point2poly_tess``).
    methodz : str or list of str
        ``"aw"`` (area weighting), ``"pw"`` (population weighting), or both.
    char_methodz : str
        Weighting method for character variables. Default ``"aw"``.
    pop_raster : rasterio DatasetReader, optional
        Population raster, required when ``methodz`` includes ``"pw"``.
    varz : str, list of str, or list of lists
        Numeric variable name(s) to interpolate.  When a list of lists,
        each sublist can have its own aggregation function in *funz*.
    funz : callable or list of callables
        Aggregation function(s) matching *varz*.  Each must accept
        ``(x, w)`` where *x* is a numeric array and *w* is weights.
        Default: weighted mean.
    pycno_varz : str or list of str, optional
        Subset of *varz* that are spatially extensive (counts/totals)
        requiring mass-preserving (pycnophylactic) rescaling.
    char_varz : str or list of str, optional
        Character variable name(s) to interpolate.
    char_assign : str or list of str
        ``"biggest_overlap"`` and/or ``"all_overlap"``.
    seed : int
        Random seed.  Default ``1``.

    Returns
    -------
    GeoDataFrame
        *poly_to* geometries with interpolated values appended.
    """

    rng = np.random.default_rng(seed)

    # ── normalise inputs ─────────────────────────────────────────────
    if isinstance(methodz, str):
        methodz = [methodz]
    if isinstance(char_assign, str):
        char_assign = [char_assign]

    # varz → list of lists
    if varz is None:
        varz = []
    elif isinstance(varz, str):
        varz = [[varz]]
    elif isinstance(varz, list) and len(varz) > 0 and isinstance(varz[0], str):
        varz = [varz]
    # now varz is list of lists

    # funz → list of callables, same length as varz
    if funz is None:
        funz = [_weighted_mean] * len(varz)
    elif callable(funz):
        funz = [funz]

    if len(varz) != len(funz):
        raise ValueError(
            "Length of variable list does not equal length of function list."
        )

    # pycno_varz
    if pycno_varz is None:
        pycno_varz = []
    elif isinstance(pycno_varz, str):
        pycno_varz = [pycno_varz]

    # char_varz
    if char_varz is None:
        char_varz = []
    elif isinstance(char_varz, str):
        char_varz = [char_varz]

    # Validate population raster
    if "pw" in methodz and pop_raster is None:
        raise ValueError("No population raster provided.")

    # ── make working copies ──────────────────────────────────────────
    poly_from = poly_from.copy()
    poly_to = poly_to.copy()

    # ── Reproject to equal-area CRS for accurate area calculations ──
    _orig_crs = poly_from.crs
    if _orig_crs is not None and not _orig_crs.is_projected:
        # Use LAEA centred on destination polygons
        _bounds = poly_to.total_bounds
        _med_x = (_bounds[0] + _bounds[2]) / 2
        _med_y = (_bounds[1] + _bounds[3]) / 2
        _proj_crs = f"+proj=laea +lon_0={_med_x} +lat_0={_med_y}"
        poly_from = poly_from.to_crs(_proj_crs)
        poly_to = poly_to.to_crs(_proj_crs)

    # ── Section A: compute polygon areas / population totals ─────────
    if "aw" in methodz or "aw" in char_methodz:
        poly_from["AREA_TOTAL_FROM"] = poly_from.geometry.area
        poly_to["AREA_TOTAL_TO"] = poly_to.geometry.area

    if "pw" in methodz:
        from rasterstats import zonal_stats

        pop_from = zonal_stats(poly_from, pop_raster, stats=["sum"])
        poly_from["POP_TOTAL_FROM"] = [s["sum"] for s in pop_from]

        pop_to = zonal_stats(poly_to, pop_raster, stats=["sum"])
        poly_to["POP_TOTAL_TO"] = [s["sum"] for s in pop_to]

    # ── Section B: intersection ──────────────────────────────────────
    poly_to["Return_ID"] = np.arange(1, len(poly_to) + 1)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        # Buffer(0) to fix any invalid geometries before intersection
        pf = poly_from.copy()
        pt = poly_to.copy()
        pf.geometry = pf.geometry.buffer(0)
        pt.geometry = pt.geometry.buffer(0)

        int_1 = gpd.overlay(pf, pt, how="intersection", keep_geom_type=False)
        int_1.geometry = int_1.geometry.buffer(0)

    # Drop empty geometries
    int_1 = int_1[~int_1.is_empty].copy()

    # ── area weights ─────────────────────────────────────────────────
    if "aw" in methodz or "aw" in char_methodz:
        int_1["AREA_INT"] = int_1.geometry.area
        int_1["AREA_W_EXV"] = int_1["AREA_INT"] / int_1["AREA_TOTAL_FROM"]
        int_1["AREA_W_INV"] = int_1["AREA_INT"] / int_1["AREA_TOTAL_TO"]

    # ── population weights ───────────────────────────────────────────
    if "pw" in methodz:
        pop_int = zonal_stats(int_1, pop_raster, stats=["sum"])
        int_1["POP_INT"] = [s["sum"] for s in pop_int]
        int_1["POP_W_EXV"] = int_1["POP_INT"] / int_1["POP_TOTAL_FROM"]
        int_1["POP_W_INV"] = int_1["POP_INT"] / int_1["POP_TOTAL_TO"]

        # Impute missing population values with k-NN median
        _impute_pop(int_1, k=10)

    # ── build aggregation table ──────────────────────────────────────
    # Drop geometry for tabular operations
    agg_cols = [c for c in int_1.columns if c != "geometry"]
    agg_df = pd.DataFrame(int_1[agg_cols])

    # ── flatten var/fun/method into a task list ──────────────────────
    tasks = []  # list of (var_name, func, method, is_char)
    for var_group, fn in zip(varz, funz):
        for v in var_group:
            for m in methodz:
                tasks.append((v, fn, m, False))
    for cv in char_varz:
        tasks.append((cv, None, char_methodz, True))

    # ── aggregate character variables ────────────────────────────────
    char_results = []
    for var_name, _, method, is_char in tasks:
        if not is_char:
            continue
        w_col = "AREA_W_INV" if method == "aw" else "POP_W_INV"
        for assign_rule in char_assign:
            if assign_rule == "biggest_overlap":
                agg = (
                    agg_df.groupby("Return_ID")
                    .apply(
                        lambda g, v=var_name, wc=w_col: "|".join(
                            g.loc[g[wc] == g[wc].max(), v]
                            .dropna()
                            .unique()
                            .astype(str)
                        ),
                        include_groups=False,
                    )
                    .rename(var_name)
                )
            else:  # all_overlap
                agg = (
                    agg_df.groupby("Return_ID")
                    .apply(
                        lambda g, v=var_name: "|".join(
                            g[v].dropna().unique().astype(str)
                        ),
                        include_groups=False,
                    )
                    .rename(var_name)
                )
            char_results.append(agg.reset_index())

    # ── aggregate numeric variables (intensive by default) ───────────
    num_results = []
    for var_name, fn, method, is_char in tasks:
        if is_char:
            continue
        w_col = "AREA_W_INV" if method == "aw" else "POP_W_INV"
        out_name = f"{var_name}_{method}"

        grouped = agg_df.groupby("Return_ID")
        agg = grouped.apply(
            lambda g, v=var_name, wc=w_col, f=fn: f(
                g[v].to_numpy(dtype=float),
                g[wc].to_numpy(dtype=float),
            ),
            include_groups=False,
        ).rename(out_name)
        num_results.append(agg.reset_index())

    # ── pycnophylactic (mass-preserving) rescaling ───────────────────
    pycno_results = []
    for pv in pycno_varz:
        sum_from = float(poly_from[pv].sum())
        for method in methodz:
            w_col = "AREA_W_EXV" if method == "aw" else "POP_W_EXV"
            out_name = f"{pv}_{method}"

            grouped = agg_df.groupby("Return_ID")
            ext_agg = grouped.apply(
                lambda g, v=pv, wc=w_col: (
                    g[v].to_numpy(dtype=float) * g[wc].to_numpy(dtype=float)
                ).sum(),
                include_groups=False,
            ).rename(out_name)

            # Rescale to preserve original sum
            current_sum = ext_agg.sum()
            if current_sum != 0:
                ext_agg = ext_agg * (sum_from / current_sum)

            pycno_results.append(ext_agg.reset_index())

    # ── combine all results ──────────────────────────────────────────
    all_results = char_results + num_results
    # Overwrite intensive results with pycnophylactic where applicable
    for pr in pycno_results:
        col = [c for c in pr.columns if c != "Return_ID"][0]
        # Remove the intensive version if it exists
        all_results = [
            r for r in all_results
            if not any(c == col for c in r.columns if c != "Return_ID")
        ]
        all_results.append(pr)

    if all_results:
        merged = reduce(
            lambda l, r: pd.merge(l, r, on="Return_ID", how="outer"),
            all_results,
        )
    else:
        merged = pd.DataFrame({"Return_ID": np.arange(1, len(poly_to) + 1)})

    # ── join back to destination polygons ─────────────────────────────
    result = poly_to.merge(merged, on="Return_ID", how="left")
    result = result.drop(columns=["Return_ID"])

    # Clean up temp columns
    for col in ["AREA_TOTAL_TO", "POP_TOTAL_TO"]:
        if col in result.columns:
            result = result.drop(columns=[col])

    # Reproject back to original CRS
    if _orig_crs is not None and result.crs != _orig_crs:
        result = result.to_crs(_orig_crs)

    return result


def _impute_pop(int_1: gpd.GeoDataFrame, k: int = 10) -> None:
    """Impute missing POP_INT values using k-nearest-neighbor median.

    Modifies *int_1* in place.
    """
    na_mask = int_1["POP_INT"].isna()
    if na_mask.sum() == 0:
        return

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        centroids = int_1.geometry.centroid

    coords = np.column_stack([centroids.x, centroids.y])

    from scipy.spatial import KDTree

    tree = KDTree(coords)
    na_indices = np.where(na_mask)[0]

    for idx in na_indices:
        dists, neighbors = tree.query(coords[idx], k=min(k + 1, len(coords)))
        # Exclude self (first neighbor)
        neighbor_vals = int_1["POP_INT"].iloc[neighbors[1:]].dropna()
        if len(neighbor_vals) > 0:
            int_1.iloc[idx, int_1.columns.get_loc("POP_INT")] = neighbor_vals.median()

    # Recompute weights for imputed rows
    still_na_exv = int_1["POP_W_EXV"].isna()
    if still_na_exv.any():
        int_1.loc[still_na_exv, "POP_W_EXV"] = np.minimum(
            1.0,
            int_1.loc[still_na_exv, "POP_INT"]
            / int_1.loc[still_na_exv, "POP_TOTAL_FROM"],
        )
    still_na_inv = int_1["POP_W_INV"].isna()
    if still_na_inv.any():
        int_1.loc[still_na_inv, "POP_W_INV"] = np.minimum(
            1.0,
            int_1.loc[still_na_inv, "POP_INT"]
            / int_1.loc[still_na_inv, "POP_TOTAL_TO"],
        )