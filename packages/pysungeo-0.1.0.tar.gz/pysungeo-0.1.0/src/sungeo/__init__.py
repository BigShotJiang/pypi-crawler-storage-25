# sungeo: Sub-National Geospatial Data Archive: Geoprocessing Toolkit (Python)

"""
pysungeo — Python port of the SUNGEO R package.

Sub-National Geospatial Data Archive: tools for converting, merging,
and analyzing geospatial data across different boundary sets, spatial
units, and time periods.

Available modules
-----------------
Geometry & CRS utilities:
    sungeo.fix_geom          — repair invalid geometries
    sungeo.utm_select        — auto-select optimal projected CRS
    sungeo.update_bbox        — update GeoDataFrame bounding box
    sungeo.df2sf             — convert DataFrame to GeoDataFrame

Polygon-to-polygon:
    sungeo.poly2poly_ap      — area-weighted polygon transfer
    sungeo.nesting           — polygon containment metrics

Point-to-polygon interpolation:
    sungeo.point2poly_simp   — simple spatial join aggregation
    sungeo.point2poly_tess   — Voronoi tessellation interpolation
    sungeo.point2poly_krige  — kriging interpolation

Line-to-polygon:
    sungeo.line2poly         — line length/density/distance metrics

Spatial statistics:
    sungeo.hot_spot          — Local G hot spot analysis

Raster conversion:
    sungeo.sf2raster         — polygon/point ↔ raster conversion

Geocoding:
    sungeo.geocode_osm       — single-address geocoding via Nominatim
    sungeo.geocode_osm_batch — batch geocoding with rate limiting

API & metadata:
    sungeo.get_data          — download data from the SUNGEO API
    sungeo.get_info          — query available data catalog

Utilities:
    sungeo.smart_round       — round with significant digit preservation
    sungeo.make_ticker       — date-to-ID mapping table
    sungeo.merge_list        — tournament-style DataFrame merge

Usage::

    from sungeo.utm_select import utm_select
    from sungeo.poly2poly_ap import poly2poly_ap
    from sungeo.hot_spot import hot_spot
"""

__version__ = "0.1.0"