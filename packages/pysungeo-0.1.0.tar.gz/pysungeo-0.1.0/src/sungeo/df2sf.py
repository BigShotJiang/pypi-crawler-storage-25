"""
Convert a DataFrame or CSV into a GeoDataFrame of points.

Takes longitude/latitude columns (or vectors) and produces an ``sf``-style
point layer, removing rows with missing or unusable coordinates.
"""

from __future__ import annotations

import pathlib

import geopandas as gpd
import numpy as np
import pandas as pd


def df2sf(
    x_coord: str | np.ndarray | list,
    y_coord: str | np.ndarray | list,
    input_data: pd.DataFrame | None = None,
    file: str | pathlib.Path | None = None,
    n_max: int | None = None,
    start: int = 0,
    projection_input: str = "EPSG:4326",
    zero_policy: bool = False,
    show_removed: bool = False,
) -> gpd.GeoDataFrame | dict:
    """Convert a DataFrame or CSV with coordinate columns into a GeoDataFrame.

    Parameters
    ----------
    x_coord : str, array-like
        Longitude / easting values.  If *input_data* or *file* is provided,
        can be a column name (str).
    y_coord : str, array-like
        Latitude / northing values.  Same rules as *x_coord*.
    input_data : DataFrame, optional
        Table containing the coordinate columns.
    file : str or Path, optional
        Path to a CSV file.  Overrides *input_data* if both are given.
    n_max : int, optional
        Maximum rows to read from *file*.  ``None`` means read all.
    start : int
        Number of rows to skip at the top of *file*.  Default ``0``.
    projection_input : str
        CRS string for the coordinates.  Default ``"EPSG:4326"`` (WGS 84).
    zero_policy : bool
        If ``True``, also remove rows where either coordinate is exactly 0.
    show_removed : bool
        If ``True``, return a dict with ``"Spatial_Coordinates"`` (the
        GeoDataFrame) and ``"Removed_Rows"`` (indices of dropped rows).

    Returns
    -------
    GeoDataFrame or dict
    """

    # ── Part 1: read CSV if provided ─────────────────────────────────
    if file is not None:
        input_data = pd.read_csv(
            file,
            nrows=n_max,
            skiprows=range(1, start + 1) if start > 0 else None,
        )

    # ── Part 2: extract coordinate arrays ────────────────────────────
    if input_data is not None and isinstance(x_coord, str) and isinstance(y_coord, str):
        x_vals = input_data[x_coord].to_numpy(dtype=float)
        y_vals = input_data[y_coord].to_numpy(dtype=float)
    else:
        x_vals = np.asarray(x_coord, dtype=float)
        y_vals = np.asarray(y_coord, dtype=float)

    # ── Part 3: identify bad rows ────────────────────────────────────
    bad = np.isnan(x_vals) | np.isnan(y_vals)
    if zero_policy:
        bad = bad | (x_vals == 0) | (y_vals == 0)

    removed_idx = np.where(bad)[0]
    keep = ~bad

    # ── Part 4: filter ───────────────────────────────────────────────
    x_clean = x_vals[keep]
    y_clean = y_vals[keep]

    # ── Part 5–7: build GeoDataFrame ─────────────────────────────────
    from shapely.geometry import Point

    geometry = [Point(x, y) for x, y in zip(x_clean, y_clean)]

    if input_data is not None:
        result = gpd.GeoDataFrame(
            input_data.loc[keep].reset_index(drop=True),
            geometry=geometry,
            crs=projection_input,
        )
    else:
        result = gpd.GeoDataFrame(
            geometry=geometry,
            crs=projection_input,
        )

    # ── return ───────────────────────────────────────────────────────
    if show_removed:
        return {
            "Spatial_Coordinates": result,
            "Removed_Rows": removed_idx,
        }
    return result