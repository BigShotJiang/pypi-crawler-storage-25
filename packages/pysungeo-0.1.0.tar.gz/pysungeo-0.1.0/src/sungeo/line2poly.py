"""
Line-in-polygon analysis.

Compute line geometry statistics (length, density, distance) for each
polygon in a destination layer.
"""

from __future__ import annotations

import warnings

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.ops import unary_union

from sungeo.utm_select import utm_select

# ── unit conversion (metres to target) ───────────────────────────────
_LINEAR_TO_M = {
    "m": 1.0,
    "km": 1_000.0,
    "mi": 1_609.344,
    "ft": 0.3048,
    "yd": 0.9144,
    "nmi": 1_852.0,
}


def _convert_linear(value_m: float | np.ndarray, unit: str) -> float | np.ndarray:
    """Convert metres to *unit*."""
    return value_m / _LINEAR_TO_M.get(unit, 1.0)


def _convert_area(value_m2: float | np.ndarray, unit: str) -> float | np.ndarray:
    """Convert square metres to *unit*²."""
    factor = _LINEAR_TO_M.get(unit, 1.0)
    return value_m2 / (factor * factor)


def line2poly(
    linez: gpd.GeoDataFrame,
    polyz: gpd.GeoDataFrame,
    poly_id: str,
    measurez: str | list[str] | None = None,
    outvar_name: str = "line",
    unitz: str = "km",
    reproject: bool = True,
    na_val=np.nan,
    verbose: bool = True,
) -> gpd.GeoDataFrame:
    """Compute line geometry statistics for each polygon.

    Parameters
    ----------
    linez : GeoDataFrame
        Source polyline layer.
    polyz : GeoDataFrame
        Destination polygon layer.
    poly_id : str
        Unique ID column name in *polyz*.
    measurez : str or list of str
        Which metrics to compute: ``"length"``, ``"density"``,
        ``"distance"``, or any combination.  Default: all three.
    outvar_name : str
        Prefix for output column names.  Default ``"line"``.
    unitz : str
        Linear unit for output.  Default ``"km"``.
    reproject : bool
        Temporarily reproject to a planar CRS for accurate measurements.
        Default ``True``.
    na_val : scalar
        Fill value for polygons with no overlapping lines.  Default ``NaN``.
    verbose : bool
        Print progress messages.  Default ``True``.

    Returns
    -------
    GeoDataFrame
        *polyz* with added columns:
        ``{outvar_name}_length``, ``{outvar_name}_area``,
        ``{outvar_name}_density``, ``{outvar_name}_distance``
        (depending on *measurez*).
    """

    if measurez is None:
        measurez = ["length", "density", "distance"]
    elif isinstance(measurez, str):
        measurez = [measurez]

    # ── working copies ───────────────────────────────────────────────
    linez = linez.copy()
    polyz = polyz.copy()
    orig_crs = polyz.crs

    # ── reproject to planar CRS ──────────────────────────────────────
    if reproject:
        if verbose:
            print("Finding optimal planar projection...")
        polyz_tr = utm_select(polyz)
        linez_tr = utm_select(linez)
    else:
        polyz_tr = polyz
        linez_tr = linez

    # ── overlay: intersect lines with polygons ───────────────────────
    if verbose:
        print("Conducting overlay operations...")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        lp_o = gpd.overlay(
            linez_tr,
            polyz_tr[[poly_id, "geometry"]],
            how="intersection",
            keep_geom_type=False,
        )

    # Compute length of each clipped segment in metres, then convert
    lp_o["sgeoz_length"] = _convert_linear(lp_o.geometry.length, unitz)

    # Aggregate total length per polygon
    length_agg = (
        lp_o.groupby(poly_id)["sgeoz_length"]
        .sum()
        .reset_index()
    )

    # ── distance to nearest line ─────────────────────────────────────
    if "distance" in measurez:
        if verbose:
            print("Computing distances...")
        line_union = unary_union(linez_tr.geometry)
        polyz_tr[f"{outvar_name}_distance"] = _convert_linear(
            polyz_tr.geometry.distance(line_union).to_numpy(), unitz
        )

    # ── length ───────────────────────────────────────────────────────
    if "length" in measurez or "density" in measurez:
        polyz_tr = polyz_tr.merge(length_agg, on=poly_id, how="left")
        polyz_tr["sgeoz_length"] = polyz_tr["sgeoz_length"].fillna(na_val)
        polyz_tr = polyz_tr.rename(
            columns={"sgeoz_length": f"{outvar_name}_length"}
        )

    # ── density ──────────────────────────────────────────────────────
    if "density" in measurez:
        polyz_tr[f"{outvar_name}_area"] = _convert_area(
            polyz_tr.geometry.area.to_numpy(), unitz
        )
        length_col = polyz_tr[f"{outvar_name}_length"]
        area_col = polyz_tr[f"{outvar_name}_area"]
        density = length_col / area_col
        polyz_tr[f"{outvar_name}_density"] = density.fillna(na_val)

    # ── reproject back ───────────────────────────────────────────────
    if reproject:
        if verbose:
            print("Restoring original projection...")
        polyz_tr = polyz_tr.to_crs(orig_crs)

    return polyz_tr