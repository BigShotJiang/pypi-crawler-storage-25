"""
make_ticker  –  Create a date-to-ID mapping table in SUNGEO-compliant format.

Python port of SUNGEO R package ``make_ticker.R``.

Generates a DataFrame where every day in the requested range gets a row
with multiple temporal identifiers: day ID (TID), week code (YRWK),
week ID (WID), month code (YRMO), month ID (MID), and year (YEAR).
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional

import numpy as np
import pandas as pd


def _yyyymmdd_to_date(yyyymmdd: int) -> date:
    """Convert an integer like ``19000101`` to a Python ``date``."""
    s = str(int(yyyymmdd))
    return date(int(s[:4]), int(s[4:6]), int(s[6:8]))


def _date_to_yyyymmdd(d: date) -> int:
    """Convert a Python ``date`` to integer ``YYYYMMDD``."""
    return int(d.strftime("%Y%m%d"))


def _build_block(start: date, end: date, pre1900: bool) -> pd.DataFrame:
    """Build a raw ticker block for a contiguous date range.

    Parameters
    ----------
    start, end : date
        Inclusive date range.
    pre1900 : bool
        If ``True``, IDs are negative (counting backwards from 0).
        If ``False``, IDs are positive (counting forward from 1).
    """
    days = pd.date_range(start, end, freq="D")
    n = len(days)
    if n == 0:
        return pd.DataFrame(
            columns=["DATE", "DATE_ALT", "TID", "WID", "YRMO", "MID", "YEAR"]
        )

    df = pd.DataFrame({"DATE_ALT": days})
    df["DATE"] = (
        df["DATE_ALT"].dt.year * 10000
        + df["DATE_ALT"].dt.month * 100
        + df["DATE_ALT"].dt.day
    ).astype(int)

    if not pre1900:
        # Forward IDs: 1, 2, 3, ...
        df["TID"] = np.arange(1, n + 1, dtype=int)
        df["WID"] = np.repeat(np.arange(1, n // 7 + 2), 7)[:n].astype(int)
    else:
        # Backward IDs: ..., -2, -1, 0  (most recent pre-1900 day = 0)
        df["TID"] = np.arange(1 - n, 1, dtype=int)
        wid_fwd = np.repeat(np.arange(1, n // 7 + 2), 7)[:n]
        df["WID"] = (1 - wid_fwd[::-1]).astype(int)

    # YRMO and MID
    df["YRMO"] = (
        df["DATE_ALT"].dt.year * 100 + df["DATE_ALT"].dt.month
    ).astype(int)

    if not pre1900:
        # MID: consecutive month index, forward
        _, inverse = np.unique(df["YRMO"].values, return_inverse=True)
        df["MID"] = (inverse + 1).astype(int)
    else:
        # MID: consecutive month index, backward (0 = last pre-1900 month)
        unique_yrmo = df["YRMO"].unique()
        # Reverse: most recent month maps to 0
        rank_reversed = {
            v: 1 - (len(unique_yrmo) - i) for i, v in enumerate(unique_yrmo)
        }
        df["MID"] = df["YRMO"].map(rank_reversed).astype(int)

    df["YEAR"] = df["DATE_ALT"].dt.year.astype(int)

    return df


def _compute_yrwk(df: pd.DataFrame) -> pd.DataFrame:
    """Compute the YRWK column (year × 1000 + week-within-year)."""
    if len(df) == 0:
        df["YRWK"] = pd.Series(dtype=int)
        return df

    # For each WID, find the year of the last day in that week.
    # R does: setnames(ticker[, unique(YEAR), by=WID], "V1", "YEAR")
    #         then !duplicated(WID, fromLast=TRUE) → keeps LAST year per WID
    wid_year = (
        df.groupby("WID", sort=False)["YEAR"]
        .last()
        .reset_index()
    )
    wid_year = wid_year.drop_duplicates(subset="WID", keep="last")

    # Within each year, rank WIDs sequentially → YRWK = YEAR*1000 + rank
    wid_year = wid_year.sort_values("WID").reset_index(drop=True)
    wid_year["_rank"] = wid_year.groupby("YEAR").cumcount() + 1
    wid_year["YRWK"] = (wid_year["YEAR"] * 1000 + wid_year["_rank"]).astype(int)

    # Merge back
    yrwk_map = dict(zip(wid_year["WID"], wid_year["YRWK"]))
    df["YRWK"] = df["WID"].map(yrwk_map).astype(int)

    return df


def make_ticker(
    date_min: int = 19000101,
    date_max: Optional[int] = None,
) -> pd.DataFrame:
    """Create a date-to-ID mapping table in SUNGEO-compliant format.

    Parameters
    ----------
    date_min : int
        Start date as ``YYYYMMDD`` integer.  Default ``19000101``.
    date_max : int, optional
        End date as ``YYYYMMDD`` integer.  Default: today.

    Returns
    -------
    pandas.DataFrame
        Columns: ``DATE`` (int), ``DATE_ALT`` (Timestamp), ``TID`` (int),
        ``YRWK`` (int), ``WID`` (int), ``YRMO`` (int), ``MID`` (int),
        ``YEAR`` (int).  Sorted by ``TID``.
    """

    if date_max is None:
        date_max = _date_to_yyyymmdd(date.today())

    d_min = _yyyymmdd_to_date(date_min)
    d_max = _yyyymmdd_to_date(date_max)

    pivot = date(1900, 1, 1)
    pre_end = date(1899, 12, 31)

    # ── Case 1: entirely ≥ 1900 ──
    if date_min >= 19000101:
        df = _build_block(pivot, d_max, pre1900=False)

    # ── Case 2: spans 1900 boundary ──
    elif date_min < 19000101 and date_max >= 19000101:
        pre = _build_block(d_min, pre_end, pre1900=True)
        post = _build_block(pivot, d_max, pre1900=False)
        df = pd.concat([pre, post], ignore_index=True)

    # ── Case 3: entirely < 1900 ──
    else:
        df = _build_block(d_min, pre_end, pre1900=True)

    # Filter to requested range
    df = df[(df["DATE"] >= date_min) & (df["DATE"] <= date_max)].copy()
    df = df.reset_index(drop=True)

    # Compute YRWK
    df = _compute_yrwk(df)

    # Final column order + sort
    df = df[["DATE", "DATE_ALT", "TID", "YRWK", "WID", "YRMO", "MID", "YEAR"]]
    df = df.sort_values("TID").reset_index(drop=True)

    return df