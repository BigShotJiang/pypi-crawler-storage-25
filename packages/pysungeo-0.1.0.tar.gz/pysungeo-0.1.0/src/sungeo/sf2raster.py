"""
sf2raster  –  Convert GeoDataFrame (polygon or point) to a regularly-spaced
              raster, or reverse-convert a raster back to a polygon GeoDataFrame.

Python port of SUNGEO R package ``sf2raster.R``.

Raster results are returned as plain dicts with keys:
    - ``data``      : numpy 2-D array (nrow × ncol)
    - ``transform`` : rasterio ``Affine`` transform
    - ``crs``       : CRS object (from the input GeoDataFrame)
    - ``nodata``    : nodata sentinel value
    - ``name``      : variable / band name (string)

Use :func:`write_raster` to save a raster dict to a GeoTIFF file.
"""

from __future__ import annotations

import warnings
from typing import Any, Callable, Optional, Union

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.transform import from_bounds, rowcol
from rasterio.features import rasterize as rio_rasterize


# ──────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────

def _default_agg(x):
    """Default aggregation function: mean ignoring NaN."""
    return np.nanmean(x)


def _make_raster_dict(
    data: np.ndarray,
    transform: rasterio.Affine,
    crs: Any,
    nodata: float,
    name: str,
) -> dict:
    """Build the standard raster result dictionary."""
    return {
        "data": data,
        "transform": transform,
        "crs": crs,
        "nodata": nodata,
        "name": name,
    }


def _wrap_funcs(funcs) -> list:
    """Ensure *funcs* is a list of callables."""
    if funcs is None:
        return [_default_agg]
    if callable(funcs) and not isinstance(funcs, list):
        return [funcs]
    if not isinstance(funcs, list):
        return list(funcs)
    return funcs


# ──────────────────────────────────────────────
#  Public API
# ──────────────────────────────────────────────

def sf2raster(
    polyz_from: Optional[gpd.GeoDataFrame] = None,
    pointz_from: Optional[gpd.GeoDataFrame] = None,
    input_variable: Optional[str] = None,
    reverse: bool = False,
    poly_to: Optional[gpd.GeoDataFrame] = None,
    return_output: Optional[dict] = None,
    return_field: Optional[dict] = None,
    aggregate_function: Optional[Union[Callable, list[Callable]]] = None,
    reverse_function: Optional[Union[Callable, list[Callable]]] = None,
    grid_dim: tuple[int, int] = (1000, 1000),
    cartogram: bool = False,
    carto_var: Optional[str] = None,
    message_out: bool = True,
    return_list: bool = False,
) -> Union[dict, gpd.GeoDataFrame]:
    """Convert a GeoDataFrame to a raster grid, or reverse the conversion.

    Parameters
    ----------
    polyz_from : GeoDataFrame, optional
        Source **polygon** layer.  Mutually exclusive with *pointz_from*.
    pointz_from : GeoDataFrame, optional
        Source **point** layer.  Mutually exclusive with *polyz_from*.
    input_variable : str, optional
        Column name of the numeric variable to burn into the raster.
    reverse : bool
        If ``True``, convert a raster **back** to a polygon GeoDataFrame.
        Requires *poly_to*, *return_output*, and *return_field*.
    poly_to : GeoDataFrame, optional
        Destination polygon layer (reverse mode only).  Must contain
        a ``"Field"`` column matching the field raster.
    return_output : dict, optional
        Output raster dict produced by a previous forward call
        (reverse mode only).
    return_field : dict, optional
        Field-ID raster dict produced by a previous forward call
        (reverse mode only).
    aggregate_function : callable or list[callable], optional
        Aggregation function(s) applied when multiple values fall in the
        same raster cell.  Must accept a numeric vector.
        Default: ``numpy.nanmean``.
    reverse_function : callable or list[callable], optional
        Aggregation function(s) for the reverse conversion.
        Default: ``numpy.nanmean``.
    grid_dim : tuple[int, int]
        Raster dimensions ``(nrow, ncol)``.  Default ``(1000, 1000)``.
    cartogram : bool
        Apply a contiguous cartogram transformation before rasterising
        (polygon input only).  **Not yet supported in pysungeo** — raises
        ``NotImplementedError``.
    carto_var : str, optional
        Variable whose values scale polygon areas in the cartogram.
    message_out : bool
        Print informational status messages.  Default ``True``.
    return_list : bool
        If ``True``, return the full result dictionary instead of just
        the output raster.  Default ``False``.

    Returns
    -------
    dict  (forward mode, ``return_list=False``)
        A single raster dict for *input_variable*.
    dict  (forward mode, ``return_list=True``)
        Polygon input → ``{"return_output", "return_centroid", "poly_to",
        "return_field"}``.
        Point input → ``{"return_output", "return_point"}``.
    GeoDataFrame  (reverse mode)
        Polygons with aggregated raster values joined back.
    """

    # ── Normalise function lists ──
    aggregate_function = _wrap_funcs(aggregate_function)
    reverse_function = _wrap_funcs(reverse_function)

    # ── Input validation ──
    if not reverse:
        if polyz_from is not None and pointz_from is not None:
            raise ValueError(
                "Please enter only one type of input (polygon or point)."
            )

        check_obj = polyz_from if polyz_from is not None else pointz_from
        if check_obj is None:
            raise ValueError(
                "Either polyz_from or pointz_from must be provided."
            )
        if not isinstance(check_obj, gpd.GeoDataFrame):
            raise TypeError(
                "Only GeoDataFrame objects are accepted. "
                "Please convert to a GeoDataFrame and re-run."
            )

        # Warn about geographic CRS (just like R)
        if (message_out
                and check_obj.crs is not None
                and not check_obj.crs.is_projected):
            warnings.warn(
                "Input has a geographic CRS.  Consider reprojecting to a "
                "meter-based projected CRS before using this function.  "
                "Default grid resolution is in meters.",
                UserWarning,
                stacklevel=2,
            )
    else:
        if poly_to is None or return_output is None or return_field is None:
            raise ValueError(
                "For reverse conversion, poly_to, return_output, and "
                "return_field must all be specified."
            )
        if not isinstance(poly_to, gpd.GeoDataFrame):
            raise TypeError("poly_to must be a GeoDataFrame.")

    # ══════════════════════════════════════════
    #  FORWARD MODE
    # ══════════════════════════════════════════
    if not reverse:
        nrow, ncol = int(grid_dim[0]), int(grid_dim[1])

        if message_out:
            print(
                f"Converting GeoDataFrame into a regularly spaced raster "
                f"grid of dimensions: {nrow} by {ncol}"
            )

        # ── Cartogram (not yet supported) ──
        if cartogram:
            if polyz_from is None:
                raise ValueError(
                    "Cartogram transformation is only available for "
                    "polygon inputs."
                )
            if carto_var is None:
                raise ValueError(
                    "Please supply carto_var for cartogram transformation."
                )
            raise NotImplementedError(
                "Cartogram transformation is not yet supported in pysungeo. "
                "The R version uses cartogram::cartogram_cont() which has no "
                "direct Python equivalent.  Consider pre-processing in R, or "
                "use an external cartogram library."
            )

        # ── Polygon → Raster ──
        if polyz_from is not None:
            return _forward_polygon(
                polyz_from, input_variable, nrow, ncol,
                return_list,
            )

        # ── Point → Raster ──
        return _forward_point(
            pointz_from, input_variable, nrow, ncol,
            aggregate_function, return_list,
        )

    # ══════════════════════════════════════════
    #  REVERSE MODE
    # ══════════════════════════════════════════
    if message_out:
        print(
            "Converting regularly spaced raster grid into "
            "GeoDataFrame polygon object"
        )

    return _reverse(poly_to, return_output, return_field, reverse_function)


# ──────────────────────────────────────────────
#  Forward: Polygon → Raster
# ──────────────────────────────────────────────

def _forward_polygon(
    polyz_from: gpd.GeoDataFrame,
    input_variable: Optional[str],
    nrow: int,
    ncol: int,
    return_list: bool,
) -> Union[dict, dict]:
    """Rasterise a polygon GeoDataFrame."""

    polyz_from = polyz_from.copy()
    polyz_from["Field"] = np.arange(1, len(polyz_from) + 1)

    # Subset to Field + input_variable + geometry
    keep = ["Field"]
    if input_variable is not None:
        if input_variable not in polyz_from.columns:
            raise ValueError(
                f"input_variable '{input_variable}' not found in polyz_from."
            )
        keep.append(input_variable)
    keep.append(polyz_from.geometry.name)
    polyz_from = polyz_from[keep]
    polyz_from_keep = polyz_from.copy()

    crs = polyz_from.crs
    xmin, ymin, xmax, ymax = polyz_from.total_bounds
    transform = from_bounds(xmin, ymin, xmax, ymax, ncol, nrow)
    res_x = (xmax - xmin) / ncol

    # 1) Burn polygon Field IDs into a raster --------------------------
    shapes_field = list(zip(polyz_from.geometry, polyz_from["Field"]))
    field_data = rio_rasterize(
        shapes_field,
        out_shape=(nrow, ncol),
        transform=transform,
        fill=0,
        dtype="int32",
    ).astype("float64")

    field_result = _make_raster_dict(field_data, transform, crs, 0.0, "Field")

    # 2) Map input_variable values onto the raster ---------------------
    if input_variable is not None:
        lookup = dict(zip(polyz_from["Field"], polyz_from[input_variable]))
        output_data = np.full((nrow, ncol), np.nan, dtype="float64")
        for fid, val in lookup.items():
            mask = field_data == fid
            if np.isnan(val) if isinstance(val, float) else False:
                output_data[mask] = np.nan
            else:
                output_data[mask] = val
    else:
        output_data = field_data.copy()

    output_result = _make_raster_dict(
        output_data, transform, crs, np.nan,
        input_variable or "Field",
    )

    # 3) Centroid layer: buffer centroids by 1 pixel, mask output ------
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        centroid_geoms = polyz_from_keep.geometry.centroid
        centroid_buffers = centroid_geoms.buffer(res_x)

    centroid_mask_shapes = [(g, 1) for g in centroid_buffers]
    centroid_mask_arr = rio_rasterize(
        centroid_mask_shapes,
        out_shape=(nrow, ncol),
        transform=transform,
        fill=0,
        dtype="uint8",
    )
    centroid_data = output_data.copy()
    centroid_data[centroid_mask_arr == 0] = np.nan

    centroid_result = _make_raster_dict(
        centroid_data, transform, crs, np.nan,
        input_variable or "Field",
    )

    result_dict = {
        "return_output": output_result,
        "return_centroid": centroid_result,
        "poly_to": polyz_from_keep,
        "return_field": field_result,
    }

    if not return_list:
        return result_dict["return_output"]
    return result_dict


# ──────────────────────────────────────────────
#  Forward: Point → Raster
# ──────────────────────────────────────────────

def _forward_point(
    pointz_from: gpd.GeoDataFrame,
    input_variable: Optional[str],
    nrow: int,
    ncol: int,
    aggregate_function: list[Callable],
    return_list: bool,
) -> Union[dict, dict]:
    """Rasterise a point GeoDataFrame."""

    pointz_from = pointz_from.copy()

    if input_variable is not None:
        if input_variable not in pointz_from.columns:
            raise ValueError(
                f"input_variable '{input_variable}' not found in pointz_from."
            )
        keep = [input_variable, pointz_from.geometry.name]
        pointz_from = pointz_from[keep]
    pointz_from_keep = pointz_from.copy()

    crs = pointz_from.crs
    xmin, ymin, xmax, ymax = pointz_from.total_bounds

    # Pad degenerate bounding boxes (single point, collinear points)
    if xmax - xmin < 1e-12:
        pad = 1.0 if (xmax == 0 and xmin == 0) else abs(xmin) * 0.01 + 1.0
        xmin -= pad
        xmax += pad
    if ymax - ymin < 1e-12:
        pad = 1.0 if (ymax == 0 and ymin == 0) else abs(ymin) * 0.01 + 1.0
        ymin -= pad
        ymax += pad

    transform = from_bounds(xmin, ymin, xmax, ymax, ncol, nrow)

    # Map each point to its raster cell --------------------------------
    xs = np.array([g.x for g in pointz_from.geometry])
    ys = np.array([g.y for g in pointz_from.geometry])
    rows, cols = rowcol(transform, xs, ys)
    rows = np.clip(np.asarray(rows, dtype=int), 0, nrow - 1)
    cols = np.clip(np.asarray(cols, dtype=int), 0, ncol - 1)
    cell_ids = rows * ncol + cols

    # Build a plain DataFrame for groupby (drop geometry) ---------------
    work = pd.DataFrame({"_cell_id": cell_ids})
    if input_variable is not None:
        work["Var"] = pointz_from[input_variable].values

    # Aggregate by cell ------------------------------------------------
    if input_variable is not None:
        agg_func = aggregate_function[0]
        grouped = (
            work.groupby("_cell_id")["Var"]
            .agg(agg_func)
            .reset_index()
        )
        grouped.columns = ["_cell_id", "Var"]
    else:
        grouped = (
            work.groupby("_cell_id")
            .size()
            .reset_index(name="Var")
        )

    # Fill raster array ------------------------------------------------
    output_data = np.full((nrow, ncol), np.nan, dtype="float64")
    cids = grouped["_cell_id"].values.astype(int)
    vals = grouped["Var"].values.astype(float)
    r_idx, c_idx = np.divmod(cids, ncol)
    valid = (r_idx >= 0) & (r_idx < nrow) & (c_idx >= 0) & (c_idx < ncol)
    output_data[r_idx[valid], c_idx[valid]] = vals[valid]

    output_result = _make_raster_dict(
        output_data, transform, crs, np.nan,
        input_variable or "count",
    )

    result_dict = {
        "return_output": output_result,
        "return_point": pointz_from_keep,
    }

    if not return_list:
        return result_dict["return_output"]
    return result_dict


# ──────────────────────────────────────────────
#  Reverse: Raster → Polygon GeoDataFrame
# ──────────────────────────────────────────────

def _reverse(
    poly_to: gpd.GeoDataFrame,
    return_output: dict,
    return_field: dict,
    reverse_function: list[Callable],
) -> gpd.GeoDataFrame:
    """Convert a raster back to a polygon GeoDataFrame.

    Groups raster cells by the polygon Field ID they belong to and
    aggregates the output variable with *reverse_function*.
    """

    field_data = return_field["data"]
    output_data = return_output["data"]
    output_name = return_output.get("name", "value")

    # Flatten both arrays into a table
    df = pd.DataFrame({
        "Field": field_data.flatten(),
        output_name: output_data.flatten(),
    })

    # Keep only cells that belong to a polygon (Field > 0, not NaN)
    df = df[(df["Field"] > 0) & df["Field"].notna()]
    df = df.dropna(subset=[output_name])

    # Aggregate per polygon
    agg_df = (
        df.groupby("Field")
        .agg({output_name: reverse_function[0]})
        .reset_index()
    )

    # Join back to the polygon geometry
    poly_to = poly_to.copy()
    geom_col = poly_to.geometry.name
    poly_sub = poly_to[["Field", geom_col]].copy()
    result = poly_sub.merge(agg_df, on="Field", how="left")
    result = gpd.GeoDataFrame(result, geometry=geom_col, crs=poly_to.crs)

    return result


# ──────────────────────────────────────────────
#  I/O utility
# ──────────────────────────────────────────────

def write_raster(raster_dict: dict, filepath: str) -> None:
    """Write a raster dict to a single-band GeoTIFF.

    Parameters
    ----------
    raster_dict : dict
        Raster dict as returned by :func:`sf2raster`.
    filepath : str
        Output file path (e.g. ``"output.tif"``).
    """
    data = raster_dict["data"]
    height, width = data.shape
    nodata_val = raster_dict["nodata"]

    # rasterio requires a concrete nodata tag; NaN is fine for float
    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": data.dtype.name,
        "crs": raster_dict["crs"],
        "transform": raster_dict["transform"],
    }
    if nodata_val is not None and not (
        isinstance(nodata_val, float) and np.isnan(nodata_val)
    ):
        profile["nodata"] = nodata_val

    with rasterio.open(filepath, "w", **profile) as dst:
        dst.write(data, 1)