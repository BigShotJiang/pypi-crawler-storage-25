"""
merge_list  –  Merge a list of DataFrames on their common columns.

Python port of SUNGEO R package ``merge_list.R``.

Uses a pairwise tournament-style merge: pairs of tables are merged
simultaneously, then the results are paired again, until a single
table remains.  Each pair is joined with a full outer join on their
shared column names.
"""

from __future__ import annotations

from typing import Union

import pandas as pd


def merge_list(
    lst: list[pd.DataFrame],
) -> pd.DataFrame:
    """Merge a list of DataFrames on common columns.

    Parameters
    ----------
    lst : list[DataFrame]
        Two or more DataFrames to merge.  Each pair is joined on the
        columns they share (``intersect(names(a), names(b))``), using a
        full outer join so no rows are lost.

    Returns
    -------
    pandas.DataFrame
        A single merged DataFrame.

    Raises
    ------
    ValueError
        If *lst* is empty.

    Examples
    --------
    >>> import pandas as pd
    >>> A = pd.DataFrame({"month": ["Jan","Feb"], "year": [2020,2020], "A": [1,2]})
    >>> B = pd.DataFrame({"year": [2020], "B": [99]})
    >>> merge_list([A, B])
      month  year  A   B
    0   Jan  2020  1  99
    1   Feb  2020  2  99
    """

    if not lst:
        raise ValueError("lst must contain at least one DataFrame.")

    # Work on a copy so we don't mutate the caller's list
    lst = list(lst)

    while len(lst) > 1:
        new_lst = []
        for i in range(0, len(lst), 2):
            if i == len(lst) - 1:
                # Odd one out → pass through
                new_lst.append(lst[i])
            else:
                left = lst[i]
                right = lst[i + 1]
                common = list(set(left.columns) & set(right.columns))
                if common:
                    merged = pd.merge(left, right, on=common, how="outer")
                else:
                    # No common columns → cross join
                    merged = pd.merge(left, right, how="cross")
                # Drop duplicate columns (keep first occurrence)
                merged = merged.loc[:, ~merged.columns.duplicated()]
                new_lst.append(merged)
        lst = new_lst

    return lst[0]