"""
get_data  –  Download data from the SUNGEO API server.

Python port of SUNGEO R package ``get_data.R``.

Fetches geospatial data from the SUNGEO API for specified countries,
topics, geographic boundary sets, and time ranges.  Returns a pandas
DataFrame with the requested data.
"""

from __future__ import annotations

import re
import time
import warnings
from datetime import date
from pathlib import Path
from typing import Callable, Optional, Union

import numpy as np
import pandas as pd
import requests

from sungeo.make_ticker import make_ticker
from sungeo.merge_list import merge_list


# ──────────────────────────────────────────────
#  Constants
# ──────────────────────────────────────────────

_API_BASE = (
    "https://api-sungeo-org-sungeo-api.apps.gnosis.lsa.umich.edu/data"
)

_DATA_DIR = Path(__file__).resolve().parent / "data"

# Topics whose data is time-invariant (no date range in URL)
_TIME_INVARIANT = {
    "Demographics:Ethnicity:GREG",
    "Infrastructure:Roads:gRoads",
    "Terrain:Elevation:ETOPO1",
    "Terrain:LandCover:GLCC",
}

# Topic → available time resolutions (pipe-separated)
_TOPIC_TIME = {
    "Demographics:Ethnicity:EPR": "YEAR",
    "Demographics:Ethnicity:GREG": "YEAR",
    "Demographics:Population:GHS": "YEAR",
    "Elections:LowerHouse:CLEA": "YEAR|MONTH",
    "Events:PoliticalViolence:ABADarfur": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ACLED": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:BeissingerProtest": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:BeissingerRiot": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:BeissingerUkraine": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:COCACW": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ESOCAfghanistanWITS": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ESOCIraqSIGACT": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ESOCIraqWITS": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ESOCMexicoDrugRelatedMurders": "YEAR",
    "Events:PoliticalViolence:ESOCMexicoHomicide": "YEAR",
    "Events:PoliticalViolence:ESOCPakistanBFRS": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:ESOCPakistanWITS": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:GED": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:Lankina": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:NIRI": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:NVMS": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:PITF": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:SCAD": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:yzCaucasus2000": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:yzChechnya": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:yzLibya": "YEAR|MONTH|WEEK",
    "Events:PoliticalViolence:yzUkraine2014": "YEAR|MONTH|WEEK",
    "Infrastructure:Roads:gRoads": "YEAR",
    "Infrastructure:NightLights:DMSP": "YEAR",
    "PublicHealth:Covid19:JHUCSSEC19": "YEAR|MONTH|WEEK",
    "Terrain:Elevation:ETOPO1": "YEAR",
    "Terrain:LandCover:GLCC": "YEAR",
    "Weather:AirTemperatureAndPrecipitation:NOAA": "YEAR|MONTH",
}


# ──────────────────────────────────────────────
#  Country code lookup
# ──────────────────────────────────────────────

def _load_cc_dict() -> pd.DataFrame:
    """Load the country-code dictionary bundled with the package."""
    path = _DATA_DIR / "cc_dict.csv"
    return pd.read_csv(path, dtype=str)


def _names_to_iso3(country_names: list[str]) -> list[str]:
    """Convert country names to ISO-3 codes using cc_dict."""
    cc = _load_cc_dict()
    iso3s = []
    for name in country_names:
        match = cc.loc[
            cc["country_name_alt"] == name, "country_iso3"
        ]
        if not match.empty:
            iso3s.append(match.iloc[0])
    return list(dict.fromkeys(iso3s))  # unique, order-preserving


# ──────────────────────────────────────────────
#  URL builder
# ──────────────────────────────────────────────

def _build_url(
    iso3: str,
    geoset: str,
    geoset_yr: int,
    space_unit: str,
    time_unit: str,
    topic: str,
    year_min: int,
    year_max: int,
    cache_param: bool,
) -> str:
    """Build the API request URL for a single country × topic."""
    base = (
        f"{_API_BASE}/{iso3}/{geoset}/{geoset_yr}/"
        f"{space_unit.upper()}/{time_unit.upper()}"
    )
    params = f"?include={topic}&cacheEnabled={str(cache_param).lower()}"
    if topic not in _TIME_INVARIANT:
        params += f"&date={year_min}-{year_max}"
    return base + params


# ──────────────────────────────────────────────
#  Time-precision adjustment
# ──────────────────────────────────────────────

def _adjust_time_unit(topic: str, requested_time_unit: str) -> str:
    """If the topic doesn't support the requested time resolution,
    fall back to the coarsest available."""
    avail = _TOPIC_TIME.get(topic, "YEAR")
    if not re.search(avail, requested_time_unit, re.IGNORECASE):
        # Use last (coarsest) available
        return avail.split("|")[-1].lower()
    return requested_time_unit


# ──────────────────────────────────────────────
#  Date-table merge
# ──────────────────────────────────────────────

def _merge_with_ticker(
    df: pd.DataFrame,
    time_unit: str,
    year_min: int,
    year_max: int,
) -> pd.DataFrame:
    """Merge API results with a make_ticker() calendar table."""

    time_cols = {"WID", "DATE", "TID", "YRMO", "MID", "YEAR", "YRWK"}
    present = time_cols & set(df.columns)
    if not present:
        return df

    today_int = int(date.today().strftime("%Y%m%d"))
    date_max_int = min(int(f"{year_max}1231"), today_int)
    ticker = make_ticker(
        date_min=int(f"{year_min}0101"),
        date_max=date_max_int,
    )

    # Convert temporal columns to string for merge compatibility
    for col in ["YEAR", "YRMO", "YRWK"]:
        if col in ticker.columns:
            ticker[col] = ticker[col].astype(str)
        if col in df.columns:
            df[col] = df[col].astype(str)

    common = list(set(ticker.columns) & set(df.columns))
    if not common:
        return df

    if len(common) == 1:
        cv = common[0]
        if re.search("year", time_unit, re.IGNORECASE):
            ticker = ticker.drop_duplicates(subset="YEAR")
            ticker = ticker[ticker[cv].isin(df[cv])]
        elif re.search("month", time_unit, re.IGNORECASE):
            ticker = ticker.drop_duplicates(subset="YRMO")
            ticker = ticker[ticker[cv].isin(df[cv])]
        elif re.search("week", time_unit, re.IGNORECASE):
            ticker = ticker.drop_duplicates(subset="YRWK")
            ticker = ticker[ticker[cv].isin(df[cv])]
        # Cast common var to string on both sides
        ticker[cv] = ticker[cv].astype(str)
        df[cv] = df[cv].astype(str)
        df = pd.merge(ticker, df, on=cv, how="outer")
    else:
        if re.search("year", time_unit, re.IGNORECASE):
            common = [c for c in ["YEAR"] if c in common]
            ticker = ticker.drop_duplicates(subset="YEAR")
            ticker = ticker[ticker["YEAR"].isin(df["YEAR"])]
            ticker = ticker[common]
        elif re.search("month", time_unit, re.IGNORECASE):
            common = [c for c in ["YEAR", "YRMO", "MID"] if c in common]
            ticker = ticker.drop_duplicates(subset="YRMO")
            ticker = ticker[ticker["YRMO"].isin(df["YRMO"])]
            ticker = ticker[common]
        elif re.search("week", time_unit, re.IGNORECASE):
            common = [c for c in ["YEAR", "YRMO", "MID", "YRWK", "WID"]
                       if c in common]
            ticker = ticker.drop_duplicates(subset="YRWK")
            ticker = ticker[ticker["WID"].isin(df["WID"])]
            ticker = ticker[common]
        # Cast all common vars to string
        for cv in common:
            ticker[cv] = ticker[cv].astype(str)
            df[cv] = df[cv].astype(str)
        df = pd.merge(ticker, df, on=common, how="outer")

    return df


# ──────────────────────────────────────────────
#  Error message formatting
# ──────────────────────────────────────────────

def _format_error(msg: str, short_message: bool) -> str:
    """Shorten error messages if requested."""
    if short_message and "not all of the provided topics" in str(msg):
        brackets = re.findall(r"\[.+?\]", str(msg))
        topics_b = [b for b in brackets if ":" in b]
        countries_b = [b for b in brackets if ":" not in b]
        if topics_b and countries_b:
            return f"{', '.join(topics_b)} missing for {', '.join(countries_b)}"
    return str(msg)[:200]


# ──────────────────────────────────────────────
#  Public API
# ──────────────────────────────────────────────

def get_data(
    country_names: Optional[Union[str, list[str]]] = None,
    country_iso3: Optional[Union[str, list[str]]] = None,
    geoset: str = "GADM",
    geoset_yr: int = 2018,
    space_unit: str = "adm1",
    time_unit: str = "year",
    topics: Optional[Union[str, list[str]]] = None,
    year_min: int = 1990,
    year_max: int = 2017,
    print_url: bool = True,
    print_time: bool = True,
    error_stop: bool = False,
    by_topic: bool = True,
    skip_missing: bool = True,
    cache_param: bool = False,
    short_message: bool = True,
) -> pd.DataFrame:
    """Download data from the SUNGEO API.

    Parameters
    ----------
    country_names : str or list[str], optional
        Country name(s).  Converted to ISO-3 codes internally.
    country_iso3 : str or list[str], optional
        ISO 3166-1 alpha-3 country code(s).
    geoset : str
        Geographic boundary set.  Default ``"GADM"``.
    geoset_yr : int
        Year of geographic boundaries.  Default ``2018``.
    space_unit : str
        Geographic level: ``"adm0"``, ``"adm1"``, ``"adm2"``,
        ``"cst"``, ``"hex05"``, ``"prio"``.  Default ``"adm1"``.
    time_unit : str
        Temporal resolution: ``"year"``, ``"month"``, ``"week"``.
        Default ``"year"``.
    topics : str or list[str]
        Data topic(s) in ``"Category:Subcategory:Source"`` format.
    year_min, year_max : int
        Time range.  Default ``1990``–``2017``.
    print_url : bool
        Print fetched URLs.  Default ``True``.
    print_time : bool
        Print elapsed time.  Default ``True``.
    error_stop : bool
        Raise on error.  Default ``False``.
    by_topic : bool
        Separate request per country × topic.  Default ``True``.
    skip_missing : bool
        Skip missing topics, fill with NaN.  Default ``True``.
    cache_param : bool
        Enable server-side caching.  Default ``False``.
    short_message : bool
        Shorten error messages.  Default ``True``.

    Returns
    -------
    pandas.DataFrame
        Requested data from the SUNGEO API.
    """

    # ── Validate inputs ──
    if country_names is None and country_iso3 is None:
        raise ValueError(
            "Please provide at least one country_names or country_iso3."
        )
    if topics is None:
        raise ValueError("Please specify at least one topic.")

    # Normalise to lists
    if isinstance(country_names, str):
        country_names = [country_names]
    if isinstance(country_iso3, str):
        country_iso3 = [country_iso3]
    if isinstance(topics, str):
        topics = [topics]

    # ── Resolve country codes ──
    if not country_iso3 and country_names:
        country_iso3 = _names_to_iso3(country_names)
        if not country_iso3:
            raise ValueError(
                f"Could not resolve any country codes for: {country_names}"
            )

    t1 = time.time()

    # ══════════════════════════════════════════
    #  by_topic = False  (single combined request)
    # ══════════════════════════════════════════
    if not by_topic:
        url_string = (
            f"{_API_BASE}/{','.join(country_iso3)}/{geoset}/{geoset_yr}/"
            f"{space_unit.upper()}/{time_unit.upper()}"
            f"?include={','.join(topics)}"
            f"&date={year_min}-{year_max}"
            f"&cacheEnabled={str(cache_param).lower()}"
        )
        if print_url:
            print(f"Fetching: {url_string.replace(_API_BASE + '/', '')}")

        sungeo_data = _fetch_and_parse(
            url_string, error_stop, short_message,
        )

        if print_time:
            print(f"{time.time() - t1:.1f} seconds")

        return sungeo_data

    # ══════════════════════════════════════════
    #  by_topic = True  (per country × topic)
    # ══════════════════════════════════════════

    data_list = []

    for iso in country_iso3:
        topic_results = []

        for tp in topics:
            # Adjust time precision
            tu = _adjust_time_unit(tp, time_unit)

            url_string = _build_url(
                iso, geoset, geoset_yr, space_unit, tu,
                tp, year_min, year_max, cache_param,
            )

            if print_url:
                print(
                    f"Fetching: {url_string.replace(_API_BASE + '/', '')}"
                )

            result = _fetch_single_topic(
                url_string, error_stop, short_message,
                time_unit=tu,
                year_min=year_min,
                year_max=year_max,
            )
            topic_results.append(result)

        # ── Combine topics for this country ──
        good = [
            r for r in topic_results
            if r is not None and len(r) > 0 and "error" not in r.columns
        ]
        errors = [
            (i, r) for i, r in enumerate(topic_results)
            if r is not None and "error" in r.columns
        ]
        zeros = [
            i for i, r in enumerate(topic_results)
            if r is None or len(r) == 0
        ]

        topic_out = None
        if skip_missing and good:
            topic_out = merge_list(good) if len(good) > 1 else good[0].copy()

            # Build message about errors/zeros
            msg_parts = []
            if errors:
                err_msgs = []
                for idx, edf in errors:
                    err_code = edf["error"].iloc[0] if "error" in edf.columns else ""
                    err_msg = edf["message"].iloc[0] if "message" in edf.columns else ""
                    # Truncate at "in 'on clause" (R behavior)
                    txt = f"{err_code}. {err_msg}".split(" in 'on clause")[0][:200]
                    err_msgs.append(f"{topics[idx]}. Error code {txt}")
                msg_parts.append("ERRORS: " + ", ".join(err_msgs) + ".")
            if zeros:
                zero_names = [topics[i] for i in zeros]
                msg_parts.append("ZERO ROWS: " + ", ".join(zero_names) + ".")

            if msg_parts:
                topic_out["message"] = "   ".join(msg_parts)
        elif skip_missing and not good:
            topic_out = None
        elif not skip_missing:
            topic_out = merge_list(good) if good else None

        if topic_out is not None:
            data_list.append(topic_out)

    if print_url:
        print("Combining...")

    if not data_list:
        if print_time:
            print(f"{time.time() - t1:.1f} seconds")
        return pd.DataFrame()

    sungeo_data = pd.concat(data_list, ignore_index=True)

    # ── Remove redundant time columns ──
    drop_cols_map = {
        "year": ["YRMO", "MID", "YRWK", "WID", "DATE", "DATE_ALT", "TID"],
        "month": ["YRWK", "WID", "DATE", "DATE_ALT", "TID"],
        "week": ["DATE", "DATE_ALT", "TID"],
    }
    drop_cols = drop_cols_map.get(time_unit.lower(), [])
    existing_drop = [c for c in drop_cols if c in sungeo_data.columns]
    if existing_drop:
        sungeo_data = sungeo_data.drop(columns=existing_drop)

    # Remove duplicates
    sungeo_data = sungeo_data.drop_duplicates().reset_index(drop=True)

    if print_time:
        print(f"{time.time() - t1:.1f} seconds")

    return sungeo_data


# ──────────────────────────────────────────────
#  Internal fetch helpers
# ──────────────────────────────────────────────

def _fetch_and_parse(
    url: str,
    error_stop: bool,
    short_message: bool,
) -> pd.DataFrame:
    """Fetch URL and parse JSON (for by_topic=False mode)."""

    try:
        resp = requests.get(url, timeout=120)
        text = resp.text
        # Fix malformed JSON (consecutive objects without comma)
        text = text.replace("}{", "},{")
        data = resp.json() if text.strip().startswith("[") else __import__("json").loads(text)
    except Exception as exc:
        if error_stop:
            raise RuntimeError(f"Failed to fetch {url}: {exc}") from exc
        return pd.DataFrame({"error": [500], "message": [str(exc)]})

    if isinstance(data, dict) and "error" in data:
        code = data["error"].get("code", 500)
        msg = _format_error(data["error"].get("message", ""), short_message)
        if error_stop:
            raise RuntimeError(f"ERROR {code}. {msg}")
        print(f"ERROR {code} ({url.replace(_API_BASE + '/', '')})")
        return pd.DataFrame({"error": [code], "message": [msg]})

    if isinstance(data, dict) and "data" in data:
        items = data["data"]
        if not items:
            return pd.DataFrame()
        return pd.concat(
            [pd.DataFrame(d) for d in items],
            ignore_index=True,
        )

    if isinstance(data, list):
        if not data:
            return pd.DataFrame()
        return pd.concat(
            [pd.DataFrame(d) if isinstance(d, dict) else pd.DataFrame([d])
             for d in data],
            ignore_index=True,
        )

    return pd.DataFrame(data)


def _fetch_single_topic(
    url: str,
    error_stop: bool,
    short_message: bool,
    time_unit: str,
    year_min: int,
    year_max: int,
) -> Optional[pd.DataFrame]:
    """Fetch a single topic and merge with ticker if temporal data."""

    try:
        resp = requests.get(url, timeout=120)
        text = resp.text

        if "Fatal error" in text:
            msg = re.sub(r"<.*?>|\n", "", text)
            if error_stop:
                raise RuntimeError(f"ERROR 500. {msg}")
            print(f"ERROR 500")
            return pd.DataFrame({"error": [500], "message": [msg]})

        text = text.replace("}{", "},{")
        data = __import__("json").loads(text)

    except requests.RequestException as exc:
        print(f"ERROR: {url} {exc}")
        if error_stop:
            raise
        return pd.DataFrame({"error": [500], "message": [str(exc)]})
    except Exception as exc:
        print(f"ERROR: {url} {exc}")
        if error_stop:
            raise
        return pd.DataFrame({"error": [500], "message": [str(exc)]})

    # ── Check for API error ──
    if isinstance(data, dict) and "error" in data:
        code = data["error"].get("code", 500) if isinstance(data["error"], dict) else 500
        raw_msg = data["error"].get("message", "") if isinstance(data["error"], dict) else str(data["error"])
        msg = _format_error(raw_msg, short_message)
        if error_stop:
            raise RuntimeError(f"ERROR {code}. {msg}")
        print(f"ERROR {code}, {msg}")
        return pd.DataFrame({"error": [code], "message": [msg]})

    # ── Parse successful response ──
    if isinstance(data, list):
        if not data:
            return pd.DataFrame()
        frames = []
        for d in data:
            if isinstance(d, dict):
                frames.append(pd.DataFrame([d]) if not any(isinstance(v, list) for v in d.values()) else pd.DataFrame(d))
            elif isinstance(d, list):
                frames.append(pd.DataFrame(d))
            else:
                frames.append(pd.DataFrame([d]))
        df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    elif isinstance(data, dict):
        df = pd.DataFrame([data]) if not any(isinstance(v, list) for v in data.values()) else pd.DataFrame(data)
    else:
        df = pd.DataFrame()

    if df.empty:
        return df

    # ── Merge with ticker if temporal columns present ──
    df = _merge_with_ticker(df, time_unit, year_min, year_max)

    return df