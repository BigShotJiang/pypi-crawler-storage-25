"""
point2poly_krige  –  Point-to-polygon interpolation using Ordinary or
                     Universal Kriging with automatic variogram fitting.

Python port of SUNGEO R package ``point2poly_krige.R``.

Uses :mod:`pykrige` for kriging and automatic variogram model selection
(tries spherical, exponential, gaussian, linear and picks the model
with the smallest residual sum of squares on the empirical variogram).
"""

from __future__ import annotations

import warnings
from typing import Any, Callable, Optional, Union

import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point

from sungeo.utm_select import utm_select
from sungeo.df2sf import df2sf


# ──────────────────────────────────────────────
#  Variogram model auto-selection
# ──────────────────────────────────────────────

_CANDIDATE_MODELS = ["spherical", "exponential", "gaussian", "linear"]


def _auto_select_model(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    use_universal: bool = False,
    drift_terms: Optional[list] = None,
    specified_drift: Optional[list[np.ndarray]] = None,
):
    """Try several variogram models and return the fitted kriging object
    whose model has the lowest RSS against the empirical semivariogram.

    Parameters
    ----------
    x, y, z : array-like
        Coordinates and values of observed data.
    use_universal : bool
        If ``True``, fit :class:`~pykrige.uk.UniversalKriging`;
        otherwise :class:`~pykrige.ok.OrdinaryKriging`.
    drift_terms, specified_drift
        Passed through to ``UniversalKriging`` when *use_universal* is True.

    Returns
    -------
    krig_obj
        The pykrige kriging object with the best variogram model.
    """
    from pykrige.ok import OrdinaryKriging
    from pykrige.uk import UniversalKriging

    best_rss = np.inf
    best_obj = None

    for model in _CANDIDATE_MODELS:
        try:
            if use_universal:
                kobj = UniversalKriging(
                    x, y, z,
                    variogram_model=model,
                    drift_terms=drift_terms or [],
                    specified_drift=specified_drift,
                    verbose=False,
                    enable_plotting=False,
                )
            else:
                kobj = OrdinaryKriging(
                    x, y, z,
                    variogram_model=model,
                    verbose=False,
                    enable_plotting=False,
                )

            # Compute RSS between empirical and fitted variogram
            fitted_sv = kobj.variogram_function(
                kobj.variogram_model_parameters, kobj.lags
            )
            rss = float(np.sum((kobj.semivariance - fitted_sv) ** 2))

            if rss < best_rss:
                best_rss = rss
                best_obj = kobj
        except Exception:
            continue

    if best_obj is None:
        raise RuntimeError(
            "All variogram models failed to fit. Check input data for "
            "sufficient spatial variation and adequate sample size."
        )

    return best_obj


# ──────────────────────────────────────────────
#  Raster extraction helpers
# ──────────────────────────────────────────────

def _extract_raster_at_polygons(raster_path, polyz, funz):
    """Extract aggregated raster values within each polygon.

    Uses :func:`rasterstats.zonal_stats`.
    """
    import rasterstats

    stats = rasterstats.zonal_stats(
        polyz, raster_path, stats=None,
        add_stats={"_agg": funz},
        nodata=np.nan,
    )
    return np.array([s["_agg"] if s["_agg"] is not None else np.nan for s in stats])


def _extract_raster_at_points(raster_path, pointz):
    """Sample raster values at point locations."""
    import rasterio

    xs = np.array([g.x for g in pointz.geometry])
    ys = np.array([g.y for g in pointz.geometry])

    with rasterio.open(raster_path) as src:
        # Reproject points to raster CRS if needed
        pts_crs = pointz.crs
        raster_crs = src.crs
        if pts_crs is not None and raster_crs is not None:
            from pyproj import Transformer
            if not pts_crs.equals(raster_crs):
                transformer = Transformer.from_crs(
                    pts_crs, raster_crs, always_xy=True
                )
                xs, ys = transformer.transform(xs, ys)

        coords = list(zip(xs, ys))
        vals = np.array([v[0] for v in src.sample(coords)], dtype=float)
        # Replace nodata with NaN
        if src.nodata is not None:
            vals[vals == src.nodata] = np.nan

    return vals


def _ensure_raster_list(rasterz):
    """Normalise *rasterz* to a list of file paths / readers."""
    if rasterz is None:
        return []
    if isinstance(rasterz, (str, bytes)):
        return [rasterz]
    if not isinstance(rasterz, list):
        return [rasterz]
    return rasterz


# ──────────────────────────────────────────────
#  Grid creation helper
# ──────────────────────────────────────────────

def _make_prediction_grid(polyz, nz_grid):
    """Create a regular grid of points within the polygon extent and
    assign each grid point to the polygon it falls in (or nearest).

    Returns a GeoDataFrame of grid points with an ``ID_kriggrid``
    column indicating which polygon each point belongs to.
    """
    xmin, ymin, xmax, ymax = polyz.total_bounds

    if isinstance(nz_grid, (list, tuple)):
        nx, ny = int(nz_grid[0]), int(nz_grid[1])
    else:
        nx = ny = int(nz_grid)

    xs = np.linspace(xmin, xmax, nx)
    ys = np.linspace(ymin, ymax, ny)
    grid_x, grid_y = np.meshgrid(xs, ys)
    grid_points = [Point(gx, gy) for gx, gy in zip(grid_x.ravel(), grid_y.ravel())]

    grid_gdf = gpd.GeoDataFrame(
        geometry=grid_points, crs=polyz.crs
    )

    # Assign each grid point to a polygon
    polyz_work = polyz.copy()
    polyz_work["ID_kriggrid"] = np.arange(1, len(polyz_work) + 1)

    # Spatial join: points within polygons
    joined = gpd.sjoin(
        grid_gdf, polyz_work[["ID_kriggrid", polyz_work.geometry.name]],
        how="left", predicate="within",
    )

    # For points that didn't fall in any polygon → assign to nearest
    unmatched = joined["ID_kriggrid"].isna()
    if unmatched.any():
        for idx in joined[unmatched].index:
            pt = grid_gdf.geometry.iloc[idx]
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                dists = polyz_work.geometry.distance(pt)
            nearest_idx = dists.idxmin()
            joined.loc[idx, "ID_kriggrid"] = polyz_work.loc[nearest_idx, "ID_kriggrid"]

    # Drop duplicates (points in overlapping polygons → keep first)
    joined = joined[~joined.index.duplicated(keep="first")]

    grid_gdf["ID_kriggrid"] = joined["ID_kriggrid"].astype(int).values

    # Also copy polygon attributes to grid (needed for xvarz in universal kriging)
    for col in polyz_work.columns:
        if col not in ("ID_kriggrid", polyz_work.geometry.name):
            id_to_val = dict(zip(polyz_work["ID_kriggrid"], polyz_work[col]))
            grid_gdf[col] = grid_gdf["ID_kriggrid"].map(id_to_val)

    return grid_gdf, polyz_work


# ──────────────────────────────────────────────
#  Public API
# ──────────────────────────────────────────────

def point2poly_krige(
    pointz: Union[gpd.GeoDataFrame, pd.DataFrame],
    polyz: Union[gpd.GeoDataFrame, pd.DataFrame],
    rasterz=None,
    yvarz: Optional[Union[str, list[str]]] = None,
    xvarz: Optional[Union[str, list[str]]] = None,
    pycno_yvarz: Optional[Union[str, list[str]]] = None,
    funz: Optional[Callable] = None,
    use_grid: bool = False,
    nz_grid: Union[int, tuple[int, int]] = 25,
    blockz: Union[int, float] = 0,
    pointz_x_coord: Optional[str] = None,
    pointz_y_coord: Optional[str] = None,
    polyz_x_coord: Optional[str] = None,
    polyz_y_coord: Optional[str] = None,
    messagez: str = "",
) -> gpd.GeoDataFrame:
    """Interpolate point values to polygons using Kriging.

    Performs Ordinary or Universal Kriging with automatic variogram
    model selection (tries spherical, exponential, gaussian, linear and
    picks the model with the smallest RSS against the empirical
    semivariogram).

    Parameters
    ----------
    pointz : GeoDataFrame or DataFrame
        Source point layer.  If a plain DataFrame, *pointz_x_coord* and
        *pointz_y_coord* must be specified.
    polyz : GeoDataFrame or DataFrame
        Destination polygon layer.  If a plain DataFrame, *polyz_x_coord*
        and *polyz_y_coord* must be specified.
    rasterz : str, list[str], or None
        Path(s) to raster covariate file(s) for Universal Kriging.
    yvarz : str or list[str]
        Column name(s) of numeric variable(s) to interpolate.
    xvarz : str or list[str], optional
        Column name(s) of covariate variables present in both *pointz*
        and *polyz* for Universal Kriging.
    pycno_yvarz : str or list[str], optional
        Subset of *yvarz* for mass-preserving (pycnophylactic) rescaling.
        Only used when ``use_grid=True``.
    funz : callable, optional
        Aggregation function.  Default: ``numpy.nanmean``.
    use_grid : bool
        If ``True``, first krige to a regular grid then aggregate
        predictions to polygons.  Default ``False``.
    nz_grid : int or tuple[int, int]
        Grid dimensions (columns, rows) when ``use_grid=True``.
        Default ``25``.
    blockz : int or float
        Block size in CRS units for block kriging.  Default ``0``
        (point kriging).  **Note:** pykrige does not natively support
        block kriging; if *blockz* > 0 a warning is issued and point
        kriging is used instead.
    pointz_x_coord, pointz_y_coord : str, optional
        Coordinate column names if *pointz* is a plain DataFrame.
    polyz_x_coord, polyz_y_coord : str, optional
        Coordinate column names if *polyz* is a plain DataFrame.
    messagez : str
        Optional message printed during estimation.

    Returns
    -------
    GeoDataFrame
        Polygon layer with kriging predictions appended.
        For each variable in *yvarz*, columns ``{var}.pred``,
        ``{var}.var``, and ``{var}.stdev`` are added.
    """

    if funz is None:
        funz = lambda x, **kw: np.nanmean(x)

    # ── Normalise yvarz / xvarz / pycno_yvarz to lists ──
    if yvarz is None:
        raise ValueError("yvarz must be specified.")
    if isinstance(yvarz, str):
        yvarz = [yvarz]
    if isinstance(xvarz, str):
        xvarz = [xvarz]
    if isinstance(pycno_yvarz, str):
        pycno_yvarz = [pycno_yvarz]

    # ── Block kriging warning ──
    if blockz > 0:
        warnings.warn(
            "pykrige does not natively support block kriging. "
            "Falling back to point kriging (blockz=0).",
            UserWarning,
            stacklevel=2,
        )
        blockz = 0

    # ════════════════════════════════════════════
    #  1.  Prepare inputs
    # ════════════════════════════════════════════

    krig_pointz = _prepare_geo(
        pointz, pointz_x_coord, pointz_y_coord, "pointz"
    )
    krig_polyz = _prepare_geo(
        polyz, polyz_x_coord, polyz_y_coord, "polyz"
    )

    # ── Validate xvarz ──
    if xvarz is not None:
        for xv in xvarz:
            if xv not in krig_pointz.columns:
                raise ValueError(
                    f"xvarz column '{xv}' not found in pointz."
                )
            if xv not in krig_polyz.columns:
                raise ValueError(
                    f"xvarz column '{xv}' not found in polyz."
                )

    # ════════════════════════════════════════════
    #  2.  Extract raster covariates (if any)
    # ════════════════════════════════════════════

    raster_list = _ensure_raster_list(rasterz)
    raster_col_names: list[str] = []

    if raster_list:
        for i, rpath in enumerate(raster_list):
            col_name = f"_raster_{i}"
            raster_col_names.append(col_name)

            # Extract at polygons
            poly_vals = _extract_raster_at_polygons(rpath, krig_polyz, funz)
            # Jitter if constant (matches R behavior)
            if np.nanstd(poly_vals) == 0:
                poly_vals = poly_vals + np.random.default_rng(42).normal(
                    0, 1e-6, len(poly_vals)
                )
            krig_polyz[col_name] = poly_vals

            # Extract at points
            pt_vals = _extract_raster_at_points(rpath, krig_pointz)
            if np.nanstd(pt_vals) == 0:
                pt_vals = pt_vals + np.random.default_rng(42).normal(
                    0, 1e-6, len(pt_vals)
                )
            krig_pointz[col_name] = pt_vals

        # Add raster columns to xvarz
        if xvarz is None:
            xvarz = raster_col_names
        else:
            xvarz = list(xvarz) + raster_col_names

    # ════════════════════════════════════════════
    #  3.  Prediction grid (if use_grid)
    # ════════════════════════════════════════════

    grid_gdf = None
    polyz_with_id = None
    if use_grid:
        grid_gdf, polyz_with_id = _make_prediction_grid(krig_polyz, nz_grid)

    # ════════════════════════════════════════════
    #  4.  Reproject to planar CRS
    # ════════════════════════════════════════════

    crs_input = krig_polyz.crs
    if crs_input is not None and not crs_input.is_projected:
        polyz_layer = utm_select(krig_polyz)
        pointz_layer = krig_pointz.to_crs(polyz_layer.crs)
        if grid_gdf is not None:
            grid_gdf = grid_gdf.to_crs(polyz_layer.crs)
    else:
        polyz_layer = krig_polyz.copy()
        pointz_layer = krig_pointz.to_crs(polyz_layer.crs)
        if grid_gdf is not None:
            grid_gdf = grid_gdf.to_crs(polyz_layer.crs)

    # ════════════════════════════════════════════
    #  5.  Kriging
    # ════════════════════════════════════════════

    if messagez:
        print(messagez)

    use_universal = xvarz is not None and len(xvarz) > 0

    if use_grid:
        krige_results = _krige_loop(
            pointz_layer, grid_gdf, yvarz, xvarz, use_universal,
        )
        krige_out = _aggregate_grid(
            krige_results, grid_gdf, polyz_layer, polyz_with_id,
            yvarz, funz, pycno_yvarz, krig_pointz,
        )
    else:
        krige_results = _krige_loop(
            pointz_layer, polyz_layer, yvarz, xvarz, use_universal,
        )
        krige_out = _bind_direct(polyz_layer, krige_results)

    return krige_out


# ──────────────────────────────────────────────
#  Input preparation
# ──────────────────────────────────────────────

def _prepare_geo(obj, x_col, y_col, label):
    """Convert *obj* to a GeoDataFrame.  Handles sf (GeoDataFrame),
    plain DataFrame (with coordinate columns), and sets CRS to
    EPSG:4326 if missing.
    """
    if isinstance(obj, gpd.GeoDataFrame):
        gdf = obj.copy()
    elif isinstance(obj, pd.DataFrame):
        if x_col is None or y_col is None:
            raise ValueError(
                f"Please supply both {label}_x_coord and {label}_y_coord."
            )
        gdf = df2sf(x_coord=x_col, y_coord=y_col, input_data=obj)
    else:
        raise TypeError(
            f"Please supply a GeoDataFrame or DataFrame for {label}."
        )

    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")

    return gdf


# ──────────────────────────────────────────────
#  Core kriging loop
# ──────────────────────────────────────────────

def _krige_loop(
    pointz_layer: gpd.GeoDataFrame,
    target_layer: gpd.GeoDataFrame,
    yvarz: list[str],
    xvarz: Optional[list[str]],
    use_universal: bool,
) -> list[pd.DataFrame]:
    """For each variable in *yvarz*, fit a kriging model and predict
    at the target locations (polygon centroids or grid points).

    Returns a list of DataFrames, one per yvar, each with columns
    ``{var}.pred``, ``{var}.var``, ``{var}.stdev``.
    """

    # Prediction coordinates
    if target_layer.geometry.iloc[0].geom_type in ("Point", "MultiPoint"):
        pred_x = np.array([g.x for g in target_layer.geometry])
        pred_y = np.array([g.y for g in target_layer.geometry])
    else:
        centroids = target_layer.geometry.centroid
        pred_x = np.array([c.x for c in centroids])
        pred_y = np.array([c.y for c in centroids])

    # Source coordinates
    src_x = np.array([g.x for g in pointz_layer.geometry])
    src_y = np.array([g.y for g in pointz_layer.geometry])

    results = []

    for yvar in yvarz:
        # Remove NAs in the y variable
        mask = ~pointz_layer[yvar].isna()

        # Also remove NAs in xvarz if universal kriging
        if use_universal and xvarz:
            for xv in xvarz:
                if xv in pointz_layer.columns:
                    mask = mask & ~pointz_layer[xv].isna()

        src_x_clean = src_x[mask.values]
        src_y_clean = src_y[mask.values]
        src_z_clean = pointz_layer.loc[mask, yvar].values.astype(float)

        # Build drift arrays for universal kriging
        drift_terms = None
        specified_drift_data = None
        specified_drift_pred = None

        if use_universal and xvarz:
            drift_terms = ["specified"]
            specified_drift_data = [
                pointz_layer.loc[mask, xv].values.astype(float)
                for xv in xvarz
            ]
            specified_drift_pred = [
                target_layer[xv].values.astype(float)
                for xv in xvarz
                if xv in target_layer.columns
            ]

        # Auto-select best variogram model
        kobj = _auto_select_model(
            src_x_clean, src_y_clean, src_z_clean,
            use_universal=use_universal,
            drift_terms=drift_terms,
            specified_drift=specified_drift_data,
        )

        # Predict
        if use_universal and specified_drift_pred:
            z_pred, ss_pred = kobj.execute(
                "points", pred_x, pred_y,
                specified_drift_arrays=specified_drift_pred,
            )
        else:
            z_pred, ss_pred = kobj.execute("points", pred_x, pred_y)

        z_pred = np.asarray(z_pred).ravel()
        ss_pred = np.asarray(ss_pred).ravel()

        df = pd.DataFrame({
            f"{yvar}.pred": z_pred,
            f"{yvar}.var": ss_pred,
            f"{yvar}.stdev": np.sqrt(np.abs(ss_pred)),
        })
        results.append(df)

    return results


# ──────────────────────────────────────────────
#  Output assembly: direct (no grid)
# ──────────────────────────────────────────────

def _bind_direct(
    polyz_layer: gpd.GeoDataFrame,
    krige_results: list[pd.DataFrame],
) -> gpd.GeoDataFrame:
    """Bind kriging predictions directly to the polygon layer."""
    out = polyz_layer.copy()
    for df in krige_results:
        for col in df.columns:
            out[col] = df[col].values
    return out


# ──────────────────────────────────────────────
#  Output assembly: grid → polygon aggregation
# ──────────────────────────────────────────────

def _aggregate_grid(
    krige_results: list[pd.DataFrame],
    grid_gdf: gpd.GeoDataFrame,
    polyz_layer: gpd.GeoDataFrame,
    polyz_with_id: gpd.GeoDataFrame,
    yvarz: list[str],
    funz: Callable,
    pycno_yvarz: Optional[list[str]],
    krig_pointz_orig: gpd.GeoDataFrame,
) -> gpd.GeoDataFrame:
    """Aggregate grid-level kriging predictions to polygons."""

    # Combine all krige result columns with grid IDs
    combined = pd.DataFrame({"ID_kriggrid": grid_gdf["ID_kriggrid"].values})
    for df in krige_results:
        for col in df.columns:
            combined[col] = df[col].values

    # Group by polygon ID and aggregate
    pred_cols = [c for c in combined.columns if c != "ID_kriggrid"]
    agg_dict = {c: lambda x: funz(x) for c in pred_cols}
    # Use explicit aggregation to avoid lambda closure issues
    agg_result = combined.groupby("ID_kriggrid")[pred_cols].agg(
        lambda x: funz(np.asarray(x))
    ).reset_index()

    # ── Pycnophylactic rescaling ──
    if pycno_yvarz:
        for pvar in pycno_yvarz:
            sum_from = krig_pointz_orig[pvar].sum()
            match_cols = [c for c in agg_result.columns if c.startswith(pvar)]
            for mc in match_cols:
                current_sum = agg_result[mc].sum()
                if current_sum != 0:
                    agg_result[mc] = agg_result[mc] * (sum_from / current_sum)

    # Merge back to polygon geometry
    polyz_out = polyz_layer.copy()
    polyz_out["ID_kriggrid"] = polyz_with_id["ID_kriggrid"].values
    polyz_out = polyz_out.merge(agg_result, on="ID_kriggrid", how="left")
    polyz_out = polyz_out.drop(columns=["ID_kriggrid"])
    polyz_out = gpd.GeoDataFrame(
        polyz_out, geometry=polyz_layer.geometry.name, crs=polyz_layer.crs
    )

    return polyz_out