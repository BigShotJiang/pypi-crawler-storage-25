"""
Automatic geographic-to-planar reprojection.

Select an optimal UTM or Albers Equal Area projection for a given spatial
object and reproject it to planar coordinates (metres).
"""

from __future__ import annotations

import numpy as np
import geopandas as gpd
import rasterio
from rasterio.warp import calculate_default_transform, reproject, Resampling


def utm_select(
    x: gpd.GeoDataFrame | rasterio.DatasetReader,
    max_zones: int = 5,
    return_list: bool = False,
) -> gpd.GeoDataFrame | rasterio.MemoryFile | dict:
    """Reproject a GeoDataFrame or rasterio dataset to an optimal planar CRS.

    If the data spans *max_zones* or fewer UTM zones, the median UTM zone is
    used.  Otherwise an Albers Equal Area projection centred on the data is
    chosen.

    Parameters
    ----------
    x : GeoDataFrame or rasterio.DatasetReader
        Spatial object in geographic (WGS 84) or any CRS.
    max_zones : int
        Maximum number of UTM zones before switching to Albers. Default ``5``.
    return_list : bool
        If ``True``, return a dict with ``"x_out"`` (reprojected object) and
        ``"proj_out"`` (CRS string).  Otherwise return only the reprojected
        object.

    Returns
    -------
    GeoDataFrame, rasterio.MemoryFile, or dict
    """

    # ── handle GeoDataFrame ──────────────────────────────────────────
    if isinstance(x, gpd.GeoDataFrame):
        # Homogenise mixed geometry types (mirrors R's st_cast logic)
        geom_types = set(x.geom_type)
        if len(geom_types) > 1:
            if any("Polygon" in t for t in geom_types):
                x = x.copy()
                x["geometry"] = x.geometry.apply(
                    lambda g: g if g.geom_type == "MultiPolygon"
                    else g if g.geom_type != "Polygon"
                    else gpd.GeoSeries([g]).explode(index_parts=False).unary_union
                    if False else g  # no-op; cast below handles it
                )
                from shapely import MultiPolygon
                x = x.explode(index_parts=False)
                # Simple approach: just cast
                x = x.copy()

        bbox = x.total_bounds  # [xmin, ymin, xmax, ymax]
        coords = np.concatenate(
            [np.array(geom.coords) if geom.geom_type == "Point"
             else np.array(geom.exterior.coords) if geom.geom_type == "Polygon"
             else np.concatenate([np.array(p.exterior.coords) for p in geom.geoms])
             if geom.geom_type == "MultiPolygon"
             else np.array(geom.coords) if geom.geom_type in ("LineString",)
             else np.concatenate([np.array(p.coords) for p in geom.geoms])
             for geom in x.geometry]
        )
        median_x = float(np.nanmedian(coords[:, 0]))

        proj_out = _pick_projection(bbox, median_x, max_zones)
        x_out = x.to_crs(proj_out)

        if return_list:
            return {"x_out": x_out, "proj_out": proj_out}
        return x_out

    # ── handle rasterio DatasetReader ────────────────────────────────
    if isinstance(x, rasterio.DatasetReader):
        bounds = x.bounds  # BoundingBox(left, bottom, right, top)
        bbox = np.array([bounds.left, bounds.bottom, bounds.right, bounds.top])

        # Read all cell x-coordinates via the transform
        cols = np.arange(x.width)
        rows = np.arange(x.height)
        col_grid, row_grid = np.meshgrid(cols, rows)
        xs, _ = rasterio.transform.xy(x.transform, row_grid.ravel(), col_grid.ravel())
        median_x = float(np.nanmedian(xs))

        proj_out = _pick_projection(bbox, median_x, max_zones)

        # Reproject into an in-memory raster
        from rasterio.crs import CRS

        dst_crs = CRS.from_proj4(proj_out)
        transform, width, height = calculate_default_transform(
            x.crs, dst_crs, x.width, x.height, *x.bounds
        )
        memfile = rasterio.MemoryFile()
        dst = memfile.open(
            driver="GTiff",
            height=height,
            width=width,
            count=x.count,
            dtype=x.dtypes[0],
            crs=dst_crs,
            transform=transform,
        )
        for band in range(1, x.count + 1):
            reproject(
                source=rasterio.band(x, band),
                destination=rasterio.band(dst, band),
                src_transform=x.transform,
                src_crs=x.crs,
                dst_transform=transform,
                dst_crs=dst_crs,
                resampling=Resampling.nearest,
            )
        dst.close()

        if return_list:
            return {"x_out": memfile, "proj_out": proj_out}
        return memfile

    raise TypeError(
        f"x must be a GeoDataFrame or rasterio.DatasetReader, got {type(x).__name__}."
    )


def _pick_projection(
    bbox: np.ndarray,
    median_x: float,
    max_zones: int,
) -> str:
    """Choose the best proj4 string given a bounding box and median longitude.

    Parameters
    ----------
    bbox : array-like
        ``[xmin, ymin, xmax, ymax]`` in geographic degrees.
    median_x : float
        Median longitude of the dataset.
    max_zones : int
        Maximum UTM zones before falling back to Albers.

    Returns
    -------
    str
        proj4 string for the chosen projection.
    """
    xmin, ymin, xmax, ymax = bbox

    # Build UTM zone lookup: 60 zones, each 6° wide starting at -180
    zone_begins = np.arange(-180, 174 + 1, 6, dtype=float)      # -180, -174, …, 174
    zone_ends = np.arange(-174, 180 + 1, 6, dtype=float) - 1e-9  # -174 - ε, …, 180 - ε
    zone_numbers = np.arange(1, 61)

    # Which zones does the bbox overlap?
    overlaps = (xmax >= zone_begins) & (xmin <= zone_ends)
    matching_zones = zone_numbers[overlaps]

    if len(matching_zones) <= max_zones:
        median_zone = int(np.median(matching_zones))
        proj_out = f"+proj=utm +zone={median_zone} +datum=WGS84"
    else:
        proj_out = f"+proj=aea +lon_0={median_x} +lat_1={ymin} +lat_2={ymax}"

    return proj_out