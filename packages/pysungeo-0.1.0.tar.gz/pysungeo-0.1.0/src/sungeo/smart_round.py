"""
smart_round  –  Round numbers while preserving at least one significant digit.

Python port of SUNGEO R package ``smart_round.R``.

Prevents information loss when rounding very small numbers to zero
(e.g. ``0.00037`` rounded to 2 decimals becomes ``0.0004`` rather than
``0.00``).
"""

from __future__ import annotations

from typing import Optional, Union

import numpy as np


def smart_round(
    x: Union[float, int, list, np.ndarray],
    rnd: int = 0,
    return_char: bool = True,
) -> Union[list[str], np.ndarray]:
    """Round numeric values with minimal information loss.

    Parameters
    ----------
    x : float, int, list, or numpy array
        Value(s) to round.
    rnd : int
        Number of decimal places.  Default ``0``.
    return_char : bool
        If ``True`` (default), return a list of formatted strings.
        If ``False``, return a numpy float array.

    Returns
    -------
    list[str] or numpy.ndarray
        Rounded values, either as character strings or floats.

    Examples
    --------
    >>> smart_round([0.0013, 2.3, -1, 3.14159], rnd=2)
    ['0.001', '2.3', '-1.0', '3.14']

    >>> smart_round([0.0013, 2.3, -1, 3.14159], rnd=2, return_char=False)
    array([ 0.001,  2.3  , -1.   ,  3.14 ])
    """

    # ── Normalise input to numpy array ──
    scalar = not hasattr(x, "__len__")
    x = np.asarray(x, dtype=float).ravel()

    threshold = 1.0 * 10.0 ** (-rnd)

    # Step 1: decide per-element whether normal round or signif
    rounded = np.round(x, rnd)
    needs_signif = np.abs(rounded) < threshold

    x_ = np.empty_like(x, dtype=float)

    # Where normal rounding keeps information → use round(x, rnd)
    x_[~needs_signif] = rounded[~needs_signif]

    # Where rounding produces zero → use signif(x, 1) to keep first
    # significant digit.  numpy doesn't have signif(); replicate it:
    #   signif(v, 1) = round(v, -int(floor(log10(|v|))))
    if needs_signif.any():
        vals = x[needs_signif]
        sig = np.zeros_like(vals)
        for i, v in enumerate(vals):
            if v == 0.0:
                sig[i] = 0.0
            else:
                # signif(v, 1) = round(v, -floor(log10(|v|)))
                decimals = -int(np.floor(np.log10(abs(v))))
                sig[i] = round(v, decimals)
        x_[needs_signif] = sig

    # Step 2: cleanup pass — round once more at rnd+1 to reduce float noise
    threshold2 = 1.0 * 10.0 ** (-(rnd + 1))
    rounded2 = np.round(x_, rnd + 1)
    ok = np.abs(rounded2) >= threshold2
    x_[ok] = rounded2[ok]

    # ── Format output ──
    if return_char:
        result = [str(v) for v in x_]
        if scalar:
            return result[0]
        return result

    if scalar:
        return x_[0]
    return x_