"""
Point-to-polygon interpolation, tessellation method.

Two-step interpolation: (1) tessellate points into Voronoi polygons,
(2) use polygon-to-polygon interpolation from Voronoi cells to
destination polygons via :func:`poly2poly_ap`.
"""

from __future__ import annotations

import warnings
from typing import Callable

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import MultiPoint
from shapely.ops import voronoi_diagram, unary_union

from sungeo.fix_geom import fix_geom
from sungeo.poly2poly_ap import poly2poly_ap, _weighted_mean


def point2poly_tess(
    pointz: gpd.GeoDataFrame,
    polyz: gpd.GeoDataFrame,
    poly_id: str,
    methodz: str | list[str] = "aw",
    char_methodz: str = "aw",
    pop_raster=None,
    varz: str | list[str] | list[list[str]] | None = None,
    funz: Callable | list[Callable] | None = None,
    pycno_varz: str | list[str] | None = None,
    char_varz: str | list[str] | None = None,
    char_assign: str | list[str] = "biggest_overlap",
    return_tess: bool = False,
    seed: int = 1,
) -> gpd.GeoDataFrame | dict:
    """Interpolate point values to polygons via Voronoi tessellation.

    Parameters
    ----------
    pointz : GeoDataFrame
        Source point layer.
    polyz : GeoDataFrame
        Destination polygon layer.
    poly_id : str
        Unique ID column name in *polyz*.
    methodz : str or list of str
        ``"aw"`` (area weighting) and/or ``"pw"`` (population weighting).
    char_methodz : str
        Weighting method for character variables. Default ``"aw"``.
    pop_raster : rasterio DatasetReader, optional
        Population raster (required for ``"pw"``).
    varz : str, list of str, or list of lists
        Numeric variable name(s) to interpolate.
    funz : callable or list of callables
        Aggregation function(s).  Default: weighted mean.
    pycno_varz : str or list of str, optional
        Extensive variables needing mass-preserving rescaling.
    char_varz : str or list of str, optional
        Character variable name(s) to interpolate.
    char_assign : str or list of str
        ``"biggest_overlap"`` and/or ``"all_overlap"``.
    return_tess : bool
        If ``True``, also return the intermediate Voronoi tessellation.
    seed : int
        Random seed.  Default ``1``.

    Returns
    -------
    GeoDataFrame or dict
        If *return_tess* is ``False``, the destination polygon layer with
        interpolated values.  If ``True``, a dict with ``"result"`` and
        ``"tess"``.
    """

    rng = np.random.default_rng(seed)

    # ── validate ─────────────────────────────────────────────────────
    if isinstance(methodz, str):
        methodz = [methodz]
    if "pw" in methodz and pop_raster is None:
        raise ValueError("No population raster provided.")

    # ── working copies ───────────────────────────────────────────────
    pointz = pointz.copy()
    polyz = polyz.copy()

    # ── Step 1: create union boundary ────────────────────────────────
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        polyz_union = unary_union(polyz.geometry)
        polyz_union_gdf = gpd.GeoDataFrame(geometry=[polyz_union], crs=polyz.crs)
        polyz_union_gdf = fix_geom(polyz_union_gdf)
        polyz_union = polyz_union_gdf.geometry.iloc[0]

    # ── Step 2: jitter and crop points ───────────────────────────────
    # Jitter slightly to avoid co-located points
    coords = np.column_stack([pointz.geometry.x, pointz.geometry.y])
    jitter_scale = 1e-8
    coords[:, 0] += rng.uniform(-jitter_scale, jitter_scale, len(coords))
    coords[:, 1] += rng.uniform(-jitter_scale, jitter_scale, len(coords))

    from shapely.geometry import Point, box as shapely_box

    pointz_crop = pointz.copy()
    pointz_crop.geometry = [Point(x, y) for x, y in coords]

    # Crop to bounding box of union polygon
    bbox = polyz_union.bounds  # (minx, miny, maxx, maxy)
    bbox_geom = shapely_box(*bbox)
    mask = pointz_crop.geometry.within(bbox_geom)
    pointz_crop = pointz_crop[mask].copy()
    pointz_crop["Unique_ID"] = np.arange(1, len(pointz_crop) + 1)

    # ── Step 3: build Voronoi tessellation ───────────────────────────
    if len(pointz_crop) <= 1 or len(set(pointz_crop.geometry)) == 1:
        # Single point or all co-located: use the full union polygon
        geo_vor = gpd.GeoDataFrame(
            {"Unique_ID": [1] if len(pointz_crop) == 1 else [np.nan]},
            geometry=[polyz_union],
            crs=polyz.crs,
        )
    else:
        multipoint = MultiPoint(list(pointz_crop.geometry))
        vor_result = voronoi_diagram(multipoint)

        # Convert voronoi result to individual polygons
        vor_polys = list(vor_result.geoms)

        # Clip to study area boundary
        clipped = []
        for vp in vor_polys:
            clipped_geom = vp.intersection(polyz_union)
            if not clipped_geom.is_empty:
                clipped.append(clipped_geom)

        geo_vor = gpd.GeoDataFrame(geometry=clipped, crs=polyz.crs)

        # ── Step 4: match Voronoi cells to source points ────────────
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            intersections = geo_vor.geometry.apply(
                lambda cell: [
                    i for i, pt in enumerate(pointz_crop.geometry)
                    if cell.contains(pt)
                ]
            )

        geo_vor["Unique_ID"] = np.nan
        for idx, matches in enumerate(intersections):
            if len(matches) == 1:
                geo_vor.loc[idx, "Unique_ID"] = pointz_crop.iloc[matches[0]]["Unique_ID"]

        # ── Step 5: clip to study area ───────────────────────────────
        geo_vor = fix_geom(geo_vor)

    # ── Step 6: merge point attributes to Voronoi cells ──────────────
    pointz_attrs = pointz_crop.drop(columns="geometry")
    geo_vor = geo_vor.merge(pointz_attrs, on="Unique_ID", how="left")

    # ── Step 7: polygon-to-polygon interpolation ─────────────────────
    result = poly2poly_ap(
        poly_from=geo_vor,
        poly_to=polyz,
        poly_to_id=poly_id,
        methodz=methodz,
        char_methodz=char_methodz,
        pop_raster=pop_raster,
        varz=varz,
        funz=funz,
        pycno_varz=pycno_varz,
        char_varz=char_varz,
        char_assign=char_assign,
        seed=seed,
    )

    # ── clean up and return ──────────────────────────────────────────
    if "Unique_ID" in result.columns:
        result = result.drop(columns=["Unique_ID"])
    if "Unique_ID" in geo_vor.columns:
        geo_vor = geo_vor.drop(columns=["Unique_ID"])

    if return_tess:
        return {"result": result, "tess": geo_vor}
    return result