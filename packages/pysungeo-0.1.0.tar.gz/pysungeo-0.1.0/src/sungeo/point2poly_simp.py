"""
Point-to-polygon interpolation, simple overlay method.

Assign and aggregate values from a source point layer to a destination
polygon layer using point-in-polygon overlay.
"""

from __future__ import annotations

import warnings
from functools import reduce
from typing import Callable

import geopandas as gpd
import numpy as np
import pandas as pd


def _default_sum(x):
    """Default aggregation: sum ignoring NaN."""
    return float(np.nansum(x))


def point2poly_simp(
    pointz: gpd.GeoDataFrame,
    polyz: gpd.GeoDataFrame,
    varz: str | list[str] | list[list[str]] | None = None,
    char_varz: str | list[str] | None = None,
    funz: Callable | list[Callable] | None = None,
    na_val=np.nan,
    drop_na_cols: bool = False,
) -> gpd.GeoDataFrame:
    """Assign/aggregate point values to polygons via point-in-polygon overlay.

    Parameters
    ----------
    pointz : GeoDataFrame
        Source point layer.
    polyz : GeoDataFrame
        Destination polygon layer.
    varz : str, list of str, or list of lists
        Variable name(s) to aggregate.  When a list of lists, each sublist
        can have its own aggregation function in *funz*.
    char_varz : str or list of str, optional
        Names of character-string variables in *varz* (for type coercion
        in the output).
    funz : callable or list of callables
        Aggregation function(s) matching *varz*.  Each must accept a
        single array ``x``.  Default: ``sum(x, na.rm=True)``.
    na_val : scalar or list
        Fill value for polygons containing no points.  Default ``NaN``.
        Can be a list matching *varz* groups.
    drop_na_cols : bool
        If ``True``, drop columns that are entirely NA.  Default ``False``.

    Returns
    -------
    GeoDataFrame
        *polyz* geometries with aggregated values from *pointz* appended.
    """

    # ── normalise inputs ─────────────────────────────────────────────
    # varz → list of lists
    if varz is None:
        varz = []
    elif isinstance(varz, str):
        varz = [[varz]]
    elif isinstance(varz, list) and len(varz) > 0 and isinstance(varz[0], str):
        varz = [varz]

    # funz → list of callables
    if funz is None:
        funz = [_default_sum]
    elif callable(funz):
        funz = [funz]

    if len(varz) != len(funz) and len(varz) > 0 and len(funz) > 0:
        raise ValueError(
            "Length of variable list does not equal length of function list."
        )

    # na_val → list
    if not isinstance(na_val, list):
        na_val = [na_val] * len(varz)

    # char_varz
    if char_varz is None:
        char_varz = []
    elif isinstance(char_varz, str):
        char_varz = [char_varz]

    # ── make working copies ──────────────────────────────────────────
    pointz = pointz.copy()
    polyz = polyz.copy()

    # ── CRS alignment ────────────────────────────────────────────────
    if pointz.crs != polyz.crs:
        polyz = polyz.to_crs(pointz.crs)

    # ── optionally drop all-NA columns ───────────────────────────────
    if drop_na_cols:
        na_cols = pointz.columns[pointz.drop(columns="geometry").isna().all()]
        pointz = pointz.drop(columns=na_cols)

    # ── point-in-polygon overlay ─────────────────────────────────────
    polyz["polygon_id_"] = np.arange(1, len(polyz) + 1)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        joined = gpd.sjoin(
            pointz, polyz[["polygon_id_", "geometry"]],
            how="left", predicate="within",
        )

    # ── flatten task list ────────────────────────────────────────────
    tasks = []  # (var_name, func, na_fill)
    for group_idx, (var_group, fn) in enumerate(zip(varz, funz)):
        fill = na_val[group_idx] if group_idx < len(na_val) else np.nan
        for v in var_group:
            tasks.append((v, fn, fill))

    # ── aggregate per polygon ────────────────────────────────────────
    agg_results = []
    for var_name, fn, _ in tasks:
        subset = joined[["polygon_id_", var_name]].dropna(subset=["polygon_id_"])

        agg = (
            subset.groupby("polygon_id_")[var_name]
            .agg(fn)
            .rename(var_name)
            .reset_index()
        )
        agg_results.append(agg)

    # ── combine aggregations ─────────────────────────────────────────
    if agg_results:
        combined = reduce(
            lambda l, r: pd.merge(l, r, on="polygon_id_", how="outer"),
            agg_results,
        )
        # Remove rows with NA polygon_id (points outside all polygons)
        combined = combined.dropna(subset=["polygon_id_"])
    else:
        combined = pd.DataFrame({"polygon_id_": np.arange(1, len(polyz) + 1)})

    # ── join to destination polygons ─────────────────────────────────
    result = polyz.merge(combined, on="polygon_id_", how="left")

    # ── fill NA values ───────────────────────────────────────────────
    for var_name, _, fill in tasks:
        if var_name in result.columns:
            result[var_name] = result[var_name].fillna(fill)

    # ── coerce types to match source layer ───────────────────────────
    all_var_names = [v for group in varz for v in group]
    for v in all_var_names:
        if v in pointz.columns and v in result.columns:
            src_dtype = pointz[v].dtype
            if v in char_varz:
                result[v] = result[v].astype(str)
            else:
                try:
                    result[v] = result[v].astype(src_dtype)
                except (ValueError, TypeError):
                    pass

    # ── clean up ─────────────────────────────────────────────────────
    result = result.drop(columns=["polygon_id_"])

    return result