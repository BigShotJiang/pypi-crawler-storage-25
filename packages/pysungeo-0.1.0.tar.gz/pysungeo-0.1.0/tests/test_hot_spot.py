"""Tests for sungeo.hot_spot.

Test strategy:
    R (spdep::localG) uses Getis & Ord (1992) ratio-based variance.
    Python (esda.G_Local) uses Ord & Getis (1995) linearized variance.
    Both correctly identify the same hot/cold spots. We verify this via:
    1. SIGN AGREEMENT — every unit has the same sign in R and Python
    2. RANK CORRELATION — Spearman ≈ 1 (same ordering)
    3. SYNTHETIC CLUSTERING — 60-point dataset proves the statistic works
    4. PROPERTY TESTS — z-scores in range, no NAs, columns preserved, etc.
"""

import pathlib

import geopandas as gpd
import numpy as np
import pytest
from scipy.stats import spearmanr
from shapely.geometry import Point, box

from sungeo.hot_spot import hot_spot

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"

# ── R reference values (all 16 z-scores) ─────────────────────────────
R_POLY_LOCALG = np.array([
    1.330995, -0.250478, -0.632617, -2.129077, 0.877946, 1.361500,
    1.193203, 0.568758, -1.119032, 1.543869, 1.795078, 0.625543,
    -2.215059, -1.776741, -0.099017, -0.757327,
])

R_POINT_LOCALG = np.array([
    1.038652, -0.941938, -2.238047, -2.557916, 0.549178, -0.465808,
    2.389463, -2.871344, 0.791205, 2.114292, 2.200499, 2.386639,
    -2.768470, -3.431392, -0.307326, -1.431882,
])


# ── fixtures ─────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def poly_gdf():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


@pytest.fixture(scope="module")
def point_gdf():
    return gpd.read_file(DATA_DIR / "clea_deu2009_pt.gpkg")


@pytest.fixture(scope="module")
def result_poly(poly_gdf):
    return hot_spot(insert=poly_gdf, variable="to1")


@pytest.fixture(scope="module")
def result_points(point_gdf):
    return hot_spot(insert=point_gdf, variable=point_gdf["to1"].to_numpy())


@pytest.fixture(scope="module")
def result_moran(poly_gdf):
    return hot_spot(insert=poly_gdf, variable="to1", include_Moran=True)


# ══════════════════════════════════════════════════════════════════════
# 1. SIGN AND RANK AGREEMENT WITH R
# ══════════════════════════════════════════════════════════════════════
class TestSignAgreementWithR:
    """Both implementations must identify the same hot/cold spots."""

    def test_polygon_all_signs_match(self, result_poly):
        py_signs = np.sign(result_poly["LocalG"].values)
        r_signs = np.sign(R_POLY_LOCALG)
        np.testing.assert_array_equal(py_signs, r_signs)

    def test_point_all_signs_match(self, result_points):
        py_signs = np.sign(result_points["LocalG"].dropna().values)
        r_signs = np.sign(R_POINT_LOCALG)
        np.testing.assert_array_equal(py_signs, r_signs)


class TestRankAgreementWithR:
    """Rankings must be strongly correlated.

    With n=16 and two known sources of difference (Getis-Ord 1992 vs
    Ord-Getis 1995 variance formula, plus libpysal vs spdep neighbor
    construction), one or two rank swaps among similarly-valued units
    is expected. Each swap costs ~0.06 in Spearman. Threshold of 0.90
    accommodates up to ~2 swaps while still requiring strong agreement."""

    def test_polygon_rank_correlation(self, result_poly):
        corr, _ = spearmanr(result_poly["LocalG"].values, R_POLY_LOCALG)
        assert corr > 0.90, f"Spearman correlation {corr} too low"

    def test_point_rank_correlation(self, result_points):
        py_vals = result_points["LocalG"].dropna().values
        corr, _ = spearmanr(py_vals, R_POINT_LOCALG)
        assert corr > 0.90, f"Spearman correlation {corr} too low"


# ══════════════════════════════════════════════════════════════════════
# 2. STRUCTURAL TESTS
# ══════════════════════════════════════════════════════════════════════
class TestStructure:

    def test_polygon_row_count(self, result_poly):
        assert len(result_poly) == 16

    def test_point_row_count(self, result_points):
        assert len(result_points) == 16

    def test_polygon_has_localg(self, result_poly):
        assert "LocalG" in result_poly.columns

    def test_point_has_localg(self, result_points):
        assert "LocalG" in result_points.columns

    def test_polygon_no_na(self, result_poly):
        assert result_poly["LocalG"].isna().sum() == 0

    def test_returns_geodataframe(self, result_poly):
        assert isinstance(result_poly, gpd.GeoDataFrame)

    def test_variable_as_string_matches_vector(self, poly_gdf):
        r_vec = hot_spot(insert=poly_gdf, variable=poly_gdf["to1"].to_numpy())
        r_str = hot_spot(insert=poly_gdf, variable="to1")
        np.testing.assert_allclose(
            r_str["LocalG"].values, r_vec["LocalG"].values, rtol=1e-6)


# ══════════════════════════════════════════════════════════════════════
# 3. MORAN'S I
# ══════════════════════════════════════════════════════════════════════
class TestMoran:

    def test_has_both_columns(self, result_moran):
        assert "LocalG" in result_moran.columns
        assert "LocalM" in result_moran.columns

    def test_localm_no_na(self, result_moran):
        assert result_moran["LocalM"].isna().sum() == 0

    def test_localm_has_variation(self, result_moran):
        assert result_moran["LocalM"].std() > 0

    def test_moran_for_points(self, point_gdf):
        result = hot_spot(insert=point_gdf,
                          variable=point_gdf["to1"].to_numpy(),
                          include_Moran=True)
        assert "LocalG" in result.columns
        assert "LocalM" in result.columns


# ══════════════════════════════════════════════════════════════════════
# 4. STATISTICAL PROPERTIES
# ══════════════════════════════════════════════════════════════════════
class TestStatisticalProperties:

    def test_localg_in_zscore_range(self, result_poly):
        vals = result_poly["LocalG"]
        assert vals.min() > -10
        assert vals.max() < 10

    def test_has_both_positive_and_negative_poly(self, result_poly):
        assert (result_poly["LocalG"] > 0).any()
        assert (result_poly["LocalG"] < 0).any()

    def test_has_both_positive_and_negative_points(self, result_points):
        vals = result_points["LocalG"].dropna()
        assert (vals > 0).any()
        assert (vals < 0).any()

    def test_different_k_changes_result(self, point_gdf):
        r5 = hot_spot(insert=point_gdf, variable="to1", k=5)
        r12 = hot_spot(insert=point_gdf, variable="to1", k=12)
        assert not np.allclose(r5["LocalG"].values, r12["LocalG"].values)


# ══════════════════════════════════════════════════════════════════════
# 5. SYNTHETIC CLUSTERING (implementation-independent proof)
# ══════════════════════════════════════════════════════════════════════
class TestSyntheticClustering:

    def test_hot_and_cold_spots(self):
        """60 points: 30 high-value clustered left, 30 low-value right.
        Any correct Gi implementation must detect these clusters."""
        np.random.seed(42)
        n = 30
        hot_vals = np.random.uniform(80, 100, n)
        cold_vals = np.random.uniform(0, 20, n)
        hot_xy = np.column_stack([np.random.uniform(0, 5, n),
                                  np.random.uniform(0, 5, n)])
        cold_xy = np.column_stack([np.random.uniform(20, 25, n),
                                   np.random.uniform(0, 5, n)])

        gdf = gpd.GeoDataFrame(
            {"val": np.concatenate([hot_vals, cold_vals])},
            geometry=[Point(x, y) for x, y in
                      np.vstack([hot_xy, cold_xy])],
            crs="EPSG:4326",
        )
        result = hot_spot(insert=gdf, variable=gdf["val"].to_numpy(), k=9)

        assert result["LocalG"].iloc[:n].mean() > 0, "Hot cluster must be positive"
        assert result["LocalG"].iloc[n:].mean() < 0, "Cold cluster must be negative"


# ══════════════════════════════════════════════════════════════════════
# 6. MISSING VALUES
# ══════════════════════════════════════════════════════════════════════
class TestMissingValues:

    def test_remove_missing_true(self):
        gdf = gpd.GeoDataFrame(
            {"val": [1., 2., np.nan, 4., 5., 6., 7., 8., 9., 10.]},
            geometry=[Point(i, 0) for i in range(10)],
            crs="EPSG:4326",
        )
        result = hot_spot(insert=gdf, variable=gdf["val"].to_numpy(),
                          k=3, remove_missing=True)
        assert np.isnan(result["LocalG"].iloc[2])
        assert result["LocalG"].dropna().shape[0] == 9

    def test_remove_missing_false(self):
        gdf = gpd.GeoDataFrame(
            {"val": [1., 2., np.nan, 4., 5., 6., 7., 8., 9., 10.]},
            geometry=[Point(i, 0) for i in range(10)],
            crs="EPSG:4326",
        )
        result = hot_spot(insert=gdf, variable=gdf["val"].to_numpy(),
                          k=3, remove_missing=False, NA_Value=0)
        assert result["LocalG"].isna().sum() == 0


# ══════════════════════════════════════════════════════════════════════
# 7. COLUMN PRESERVATION & INPUT SAFETY
# ══════════════════════════════════════════════════════════════════════
class TestColumnPreservation:

    def test_polygon(self, poly_gdf, result_poly):
        for col in poly_gdf.columns:
            assert col in result_poly.columns

    def test_points(self, point_gdf, result_points):
        for col in point_gdf.columns:
            assert col in result_points.columns


class TestInputSafety:

    def test_does_not_mutate_polygon(self, poly_gdf):
        orig_cols = list(poly_gdf.columns)
        hot_spot(insert=poly_gdf, variable="to1")
        assert "LocalG" not in poly_gdf.columns
        assert list(poly_gdf.columns) == orig_cols

    def test_does_not_mutate_points(self, point_gdf):
        orig_cols = list(point_gdf.columns)
        hot_spot(insert=point_gdf, variable=point_gdf["to1"].to_numpy())
        assert "LocalG" not in point_gdf.columns
        assert list(point_gdf.columns) == orig_cols


# ══════════════════════════════════════════════════════════════════════
# 8. ERROR HANDLING
# ══════════════════════════════════════════════════════════════════════
class TestErrors:

    def test_no_variable_raises(self, poly_gdf):
        with pytest.raises(ValueError):
            hot_spot(insert=poly_gdf, variable=None)

    def test_mixed_geometry_raises(self):
        gdf = gpd.GeoDataFrame(
            {"val": [1.0, 2.0]},
            geometry=[Point(0, 0), box(1, 1, 2, 2)],
            crs="EPSG:4326",
        )
        with pytest.raises(ValueError, match="Polygon.*Point"):
            hot_spot(insert=gdf, variable=gdf["val"].to_numpy())