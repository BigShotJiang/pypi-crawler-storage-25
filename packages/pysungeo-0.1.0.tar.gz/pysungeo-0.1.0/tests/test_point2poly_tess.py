"""Tests for sungeo.point2poly_tess against R reference output.

Reference values generated in R using:
    point2poly_tess(pointz=clea_deu2009_pt, polyz=hex_05_deu, ...)

This function depends on:
    - fix_geom() — repairs invalid geometries in union polygon and Voronoi cells
    - poly2poly_ap() — polygon-to-polygon interpolation in the second step
Both are tested indirectly through the full pipeline here.
"""

import pathlib

import geopandas as gpd
import numpy as np
import pytest
from shapely.geometry import Point, box

from sungeo.point2poly_tess import point2poly_tess
from sungeo.point2poly_simp import point2poly_simp

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"

# ── R reference values ───────────────────────────────────────────────
R_REF = {
    "test1_nrow": 257,
    "test1_to1_aw_mean": 0.6970559,
    "test1_to1_aw_min": 0.6047214,
    "test1_to1_aw_max": 0.7375996,
    "test1_to1_aw_na_count": 0,
    "test2_tess_nrow": 16,
    "test2_result_nrow": 257,
    "test3_vv1_aw_sum": 43371190,
    "test3_vv1_original_sum": 43371190,
    "test3_to1_aw_mean": 0.6966174,
    "test3_has_win1": True,
}


# ── fixtures ─────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def pointz():
    return gpd.read_file(DATA_DIR / "clea_deu2009_pt.gpkg")


@pytest.fixture(scope="module")
def polyz():
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def result_single(pointz, polyz):
    """Test case 1: single intensive variable, area weighting."""
    return point2poly_tess(
        pointz=pointz, polyz=polyz,
        poly_id="HEX_ID", varz="to1",
    )


@pytest.fixture(scope="module")
def result_tess(pointz, polyz):
    """Test case 2: return tessellation."""
    return point2poly_tess(
        pointz=pointz, polyz=polyz,
        poly_id="HEX_ID", varz="to1",
        return_tess=True,
    )


@pytest.fixture(scope="module")
def result_multi(pointz, polyz):
    """Test case 3: multiple variables + pycnophylactic + char vars."""
    return point2poly_tess(
        pointz=pointz, polyz=polyz,
        poly_id="HEX_ID",
        varz=[["to1", "pvs1_margin"], ["vv1"]],
        pycno_varz="vv1",
        funz=[
            lambda x, w: float(np.average(x[~np.isnan(x)], weights=w[~np.isnan(x)])),
            lambda x, w: float((x * w).sum()),
        ],
        char_varz=["win1_pty_n"],
    )


# ── R cross-check: single variable ──────────────────────────────────
class TestSingleVariable:

    def test_row_count(self, result_single):
        assert len(result_single) == R_REF["test1_nrow"]

    def test_output_column_exists(self, result_single):
        assert "to1_aw" in result_single.columns

    def test_mean(self, result_single):
        mean_val = result_single["to1_aw"].mean()
        assert mean_val == pytest.approx(R_REF["test1_to1_aw_mean"], abs=0.02)

    def test_min(self, result_single):
        min_val = result_single["to1_aw"].min()
        assert min_val == pytest.approx(R_REF["test1_to1_aw_min"], abs=0.02)

    def test_max(self, result_single):
        max_val = result_single["to1_aw"].max()
        assert max_val == pytest.approx(R_REF["test1_to1_aw_max"], abs=0.02)

    def test_no_na(self, result_single):
        """Voronoi tessellation should fill every hex cell — no NAs."""
        assert result_single["to1_aw"].isna().sum() == R_REF["test1_to1_aw_na_count"]

    def test_returns_geodataframe(self, result_single):
        assert isinstance(result_single, gpd.GeoDataFrame)

    def test_destination_id_preserved(self, result_single):
        assert "HEX_ID" in result_single.columns


# ── R cross-check: return tessellation ───────────────────────────────
class TestReturnTess:

    def test_returns_dict(self, result_tess):
        assert isinstance(result_tess, dict)
        assert "result" in result_tess
        assert "tess" in result_tess

    def test_result_row_count(self, result_tess):
        assert len(result_tess["result"]) == R_REF["test2_result_nrow"]

    def test_tess_is_geodataframe(self, result_tess):
        assert isinstance(result_tess["tess"], gpd.GeoDataFrame)

    def test_tess_has_polygons(self, result_tess):
        geom_types = set(result_tess["tess"].geom_type)
        assert geom_types.issubset({"Polygon", "MultiPolygon", "GeometryCollection"})


# ── R cross-check: multi-variable + pycnophylactic + char vars ──────
class TestMultiVariable:

    def test_pycnophylactic_sum(self, result_multi):
        result_sum = result_multi["vv1_aw"].sum()
        assert result_sum == pytest.approx(R_REF["test3_vv1_aw_sum"], rel=0.01)

    def test_to1_mean(self, result_multi):
        mean_val = result_multi["to1_aw"].mean()
        assert mean_val == pytest.approx(R_REF["test3_to1_aw_mean"], abs=0.02)

    def test_char_column_exists(self, result_multi):
        assert "win1_pty_n" in result_multi.columns

    def test_intensive_in_range(self, result_multi):
        valid = result_multi["to1_aw"].dropna()
        assert valid.min() >= 0
        assert valid.max() <= 1


# ── integration: tess vs simp (the reason this function exists) ──────
class TestTessVsSimp:

    def test_tess_has_fewer_nas_than_simp(self, pointz, polyz, result_single):
        """The whole motivation for tessellation: fewer empty cells."""
        simp_result = point2poly_simp(
            pointz=pointz, polyz=polyz,
            varz="to1",
            funz=lambda x: float(np.nanmean(x)),
        )
        tess_na_count = result_single["to1_aw"].isna().sum()
        simp_na_count = simp_result["to1"].isna().sum()
        assert tess_na_count < simp_na_count

    def test_tess_fills_all_cells(self, result_single):
        """Tessellation should produce a value for every destination cell."""
        assert result_single["to1_aw"].isna().sum() == 0


# ── integration: Voronoi cells cover the study area (fix_geom works) ─
class TestVoronoiCoverage:

    def test_tess_covers_study_area(self, result_tess, polyz):
        """Voronoi cells should cover approximately the same area as the
        destination polygons. If fix_geom failed silently, there would be
        gaps and the total area would be smaller."""
        tess = result_tess["tess"]

        # Reproject both to a planar CRS for area comparison
        bounds = polyz.total_bounds
        med_x = (bounds[0] + bounds[2]) / 2
        med_y = (bounds[1] + bounds[3]) / 2
        proj_crs = f"+proj=laea +lon_0={med_x} +lat_0={med_y}"

        tess_proj = tess.to_crs(proj_crs)
        polyz_proj = polyz.to_crs(proj_crs)

        tess_area = tess_proj.geometry.area.sum()
        polyz_area = polyz_proj.geometry.area.sum()

        # Voronoi cells should cover at least 90% of the destination area
        assert tess_area >= polyz_area * 0.90

    def test_tess_geometries_valid(self, result_tess):
        """All Voronoi cells should be valid geometries (fix_geom's job)."""
        tess = result_tess["tess"]
        assert tess.geometry.is_valid.all()


# ── edge case: single point ──────────────────────────────────────────
class TestSinglePoint:

    def test_single_point(self):
        """With one point, the entire study area becomes one Voronoi cell."""
        point = gpd.GeoDataFrame(
            {"val": [42.0]},
            geometry=[Point(10.0, 51.0)],
            crs="EPSG:4326",
        )
        polys = gpd.GeoDataFrame(
            {"pid": ["A", "B"]},
            geometry=[box(9, 50, 10.5, 51.5), box(10.5, 50, 12, 51.5)],
            crs="EPSG:4326",
        )
        result = point2poly_tess(
            pointz=point, polyz=polys,
            poly_id="pid", varz="val",
        )
        assert len(result) == 2
        # Both polygons should get the same value (only one source)
        valid = result["val_aw"].dropna()
        assert len(valid) > 0


# ── input safety ─────────────────────────────────────────────────────
class TestInputSafety:

    def test_does_not_mutate_pointz(self, pointz, polyz):
        orig_cols = list(pointz.columns)
        orig_len = len(pointz)
        point2poly_tess(pointz=pointz, polyz=polyz, poly_id="HEX_ID", varz="to1")
        assert list(pointz.columns) == orig_cols
        assert len(pointz) == orig_len

    def test_does_not_mutate_polyz(self, pointz, polyz):
        orig_cols = list(polyz.columns)
        orig_len = len(polyz)
        point2poly_tess(pointz=pointz, polyz=polyz, poly_id="HEX_ID", varz="to1")
        assert list(polyz.columns) == orig_cols
        assert len(polyz) == orig_len


# ── error handling ───────────────────────────────────────────────────
class TestErrors:

    def test_pw_without_raster_raises(self, pointz, polyz):
        with pytest.raises(ValueError, match="population raster"):
            point2poly_tess(
                pointz=pointz, polyz=polyz,
                poly_id="HEX_ID", varz="to1",
                methodz="pw",
            )