"""Tests for sungeo.fix_geom."""

import pathlib

import geopandas as gpd
import pytest
from shapely.geometry import Polygon

from sungeo.fix_geom import fix_geom

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


@pytest.fixture(scope="module")
def clea_gdf():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


class TestFixGeom:

    def test_valid_input_unchanged(self, clea_gdf):
        """Already-valid geometries should pass through without error."""
        result = fix_geom(clea_gdf)
        assert len(result) == len(clea_gdf)
        assert result.geometry.is_valid.all()

    def test_fixes_bowtie(self):
        """A self-intersecting 'bowtie' polygon should be repaired."""
        # Bowtie: edges cross each other → invalid
        bowtie = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        gdf = gpd.GeoDataFrame(geometry=[bowtie], crs="EPSG:4326")
        assert not gdf.geometry.is_valid.all()

        result = fix_geom(gdf)
        assert result.geometry.is_valid.all()

    def test_columns_preserved(self, clea_gdf):
        result = fix_geom(clea_gdf)
        assert list(result.columns) == list(clea_gdf.columns)

    def test_does_not_mutate_input(self, clea_gdf):
        original_geom = clea_gdf.geometry.copy()
        fix_geom(clea_gdf)
        assert clea_gdf.geometry.equals(original_geom)


class TestFixGeomIteration:
    """Tests targeting the iteration loop (lines 59-63) and edge cases."""

    def test_multiple_invalid_geometries(self):
        """Multiple invalid polygons should all be repaired."""
        bowtie1 = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        bowtie2 = Polygon([(10, 10), (12, 12), (12, 10), (10, 12)])
        gdf = gpd.GeoDataFrame(
            {"val": [1, 2]},
            geometry=[bowtie1, bowtie2],
            crs="EPSG:4326",
        )
        assert not gdf.geometry.is_valid.all()
        result = fix_geom(gdf)
        assert result.geometry.is_valid.all()
        assert len(result) == 2

    def test_mixed_valid_invalid(self):
        """Mix of valid and invalid geometries — all should be valid after."""
        valid = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
        bowtie = Polygon([(2, 0), (4, 2), (4, 0), (2, 2)])
        gdf = gpd.GeoDataFrame(
            {"val": [1, 2]},
            geometry=[valid, bowtie],
            crs="EPSG:4326",
        )
        result = fix_geom(gdf)
        assert result.geometry.is_valid.all()
        assert len(result) == 2
        # Valid geometry should be unchanged
        assert result.geometry.iloc[0].equals(valid)

    def test_n_it_parameter(self):
        """n_it controls maximum iterations."""
        bowtie = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        gdf = gpd.GeoDataFrame(geometry=[bowtie], crs="EPSG:4326")
        # With n_it=1, should still fix (bowtie needs only 1 iteration)
        result = fix_geom(gdf, n_it=1)
        assert result.geometry.is_valid.all()

    def test_preserves_crs(self):
        """CRS should be preserved through the fix."""
        bowtie = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        gdf = gpd.GeoDataFrame(geometry=[bowtie], crs="EPSG:32632")
        result = fix_geom(gdf)
        assert result.crs == gdf.crs

    def test_preserves_attributes(self):
        """Non-geometry columns should be preserved."""
        bowtie = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        gdf = gpd.GeoDataFrame(
            {"name": ["test"], "value": [42.0]},
            geometry=[bowtie],
            crs="EPSG:4326",
        )
        result = fix_geom(gdf)
        assert result["name"].iloc[0] == "test"
        assert result["value"].iloc[0] == 42.0

    def test_returns_geodataframe(self):
        """Output should always be a GeoDataFrame."""
        bowtie = Polygon([(0, 0), (2, 2), (2, 0), (0, 2)])
        gdf = gpd.GeoDataFrame(geometry=[bowtie], crs="EPSG:4326")
        result = fix_geom(gdf)
        assert isinstance(result, gpd.GeoDataFrame)