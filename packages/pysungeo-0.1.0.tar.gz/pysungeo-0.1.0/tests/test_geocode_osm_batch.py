"""
Tests for sungeo.geocode_osm_batch

Test categories:
    1. R cross-check (column structure, row counts)
    2. Core behavior (multiple queries, concatenation)
    3. Delay enforcement (minimum 1 second)
    4. Error handling (per-query failure, empty list)
    5. Verbose output
    6. Live integration tests (skipped by default)
"""

import warnings
from unittest.mock import patch, MagicMock

import numpy as np
import pandas as pd
import pytest

from sungeo.geocode_osm_batch import geocode_osm_batch

# ────────────────────────────────────────────────
#  R reference values
# ────────────────────────────────────────────────

R_REF = {
    "basic_columns": ["query", "osm_id", "address", "longitude", "latitude"],
    "detail_columns": [
        "query", "osm_id", "osm_type", "importance", "address",
        "longitude", "latitude",
        "bbox_ymin", "bbox_ymax", "bbox_xmin", "bbox_xmax",
    ],
    "three_cities_nrow": 3,
    "three_cities_queries": ["Ann Arbor", "East Lansing", "Columbus"],
    "three_cities_osm_ids": ["135130", "134923", "182706"],
    "three_cities_lon": [-83.74846, -84.47217, -83.00071],
    "three_cities_lat": [42.28137, 42.73203, 39.96226],
}

# ────────────────────────────────────────────────
#  Mock data
# ────────────────────────────────────────────────

MOCK_ANN_ARBOR = [
    {
        "osm_type": "relation", "osm_id": 135130,
        "lat": "42.28137", "lon": "-83.74846",
        "display_name": "Ann Arbor, Washtenaw County, Michigan, United States",
        "importance": 0.7,
        "boundingbox": ["42.222", "42.324", "-83.799", "-83.676"],
    },
]

MOCK_EAST_LANSING = [
    {
        "osm_type": "relation", "osm_id": 134923,
        "lat": "42.73203", "lon": "-84.47217",
        "display_name": "East Lansing, Ingham County, Michigan, United States",
        "importance": 0.6,
        "boundingbox": ["42.694", "42.773", "-84.506", "-84.441"],
    },
]

MOCK_COLUMBUS = [
    {
        "osm_type": "relation", "osm_id": 182706,
        "lat": "39.96226", "lon": "-83.00071",
        "display_name": "Columbus, Franklin County, Ohio, United States",
        "importance": 0.8,
        "boundingbox": ["39.808", "40.157", "-83.201", "-82.771"],
    },
]

MOCK_EMPTY = []


def _mock_get(response_data):
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = response_data
    mock_resp.raise_for_status.return_value = None
    return mock_resp


# ────────────────────────────────────────────────
#  Autouse fixture: patch time.sleep so tests run instantly
# ────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _no_sleep():
    """Patch time.sleep in all tests to avoid real delays."""
    with patch("sungeo.geocode_osm_batch.time.sleep") as mock_sleep:
        yield mock_sleep


# Helper to suppress the min-delay warning in tests that use delay<1
def _ignore_delay_warning():
    warnings.filterwarnings("ignore", message=".*Nominatim.*")


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK
# ════════════════════════════════════════════════

class TestRCrossCheck:
    @patch("sungeo.geocode_osm.requests.get")
    def test_three_cities_nrow(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        assert len(result) == R_REF["three_cities_nrow"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_basic_columns_match_r(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        assert list(result.columns) == R_REF["basic_columns"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_detail_columns_match_r(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"],
                delay=0, details=True,
            )
        assert list(result.columns) == R_REF["detail_columns"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_query_column_matches_input(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        assert result["query"].tolist() == R_REF["three_cities_queries"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_osm_ids_match_r(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        assert result["osm_id"].tolist() == R_REF["three_cities_osm_ids"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_longitudes_match_r(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        for i, ref_lon in enumerate(R_REF["three_cities_lon"]):
            assert result["longitude"].iloc[i] == pytest.approx(ref_lon, abs=0.001)

    @patch("sungeo.geocode_osm.requests.get")
    def test_latitudes_match_r(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        for i, ref_lat in enumerate(R_REF["three_cities_lat"]):
            assert result["latitude"].iloc[i] == pytest.approx(ref_lat, abs=0.001)

    @patch("sungeo.geocode_osm.requests.get")
    def test_addresses_contain_city_names(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        assert "Ann Arbor" in result["address"].iloc[0]
        assert "East Lansing" in result["address"].iloc[1]
        assert "Columbus" in result["address"].iloc[2]


# ════════════════════════════════════════════════
#  2. CORE BEHAVIOR
# ════════════════════════════════════════════════

class TestCoreBehavior:
    @patch("sungeo.geocode_osm.requests.get")
    def test_single_query(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_ANN_ARBOR)
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(["Ann Arbor"], delay=0)
        assert len(result) == 1
        assert result["query"].iloc[0] == "Ann Arbor"

    @patch("sungeo.geocode_osm.requests.get")
    def test_coordinates_populated(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(["Ann Arbor", "Columbus"], delay=0)
        assert result["latitude"].iloc[0] == pytest.approx(42.27, abs=0.05)
        assert result["latitude"].iloc[1] == pytest.approx(39.96, abs=0.05)

    @patch("sungeo.geocode_osm.requests.get")
    def test_index_is_sequential(self, mock_get):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "East Lansing"], delay=0,
            )
        assert list(result.index) == [0, 1]


# ════════════════════════════════════════════════
#  3. DELAY ENFORCEMENT
# ════════════════════════════════════════════════

class TestDelayEnforcement:
    @patch("sungeo.geocode_osm.requests.get")
    def test_delay_below_1_warns(self, mock_get, _no_sleep):
        mock_get.return_value = _mock_get(MOCK_ANN_ARBOR)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            geocode_osm_batch(["Ann Arbor"], delay=0.5)
        rate_warns = [x for x in w if "Nominatim" in str(x.message)]
        assert len(rate_warns) >= 1
        # Delay should have been raised to 1
        _no_sleep.assert_called_with(1.0)

    @patch("sungeo.geocode_osm.requests.get")
    def test_delay_zero_warns(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_ANN_ARBOR)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            geocode_osm_batch(["Ann Arbor"], delay=0)
        rate_warns = [x for x in w if "Nominatim" in str(x.message)]
        assert len(rate_warns) >= 1

    @patch("sungeo.geocode_osm.requests.get")
    def test_delay_1_no_warning(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_ANN_ARBOR)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            geocode_osm_batch(["Ann Arbor"], delay=1.0)
        rate_warns = [x for x in w if "Nominatim" in str(x.message)]
        assert len(rate_warns) == 0

    @patch("sungeo.geocode_osm.requests.get")
    def test_sleep_called_per_query(self, mock_get, _no_sleep):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_EAST_LANSING),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            geocode_osm_batch(
                ["Ann Arbor", "East Lansing", "Columbus"], delay=0,
            )
        # Sleep called after every query including last (matches R)
        assert _no_sleep.call_count == 3


# ════════════════════════════════════════════════
#  4. ERROR HANDLING
# ════════════════════════════════════════════════

class TestErrorHandling:
    def test_empty_list_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            geocode_osm_batch([])

    @patch("sungeo.geocode_osm.requests.get")
    def test_one_failure_doesnt_kill_batch(self, mock_get):
        import requests as req
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            req.ConnectionError("fail"),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(
                ["Ann Arbor", "BadPlace", "Columbus"], delay=0,
            )
        assert len(result) == 3
        assert not pd.isna(result["longitude"].iloc[0])
        assert pd.isna(result["longitude"].iloc[1])
        assert not pd.isna(result["longitude"].iloc[2])

    @patch("sungeo.geocode_osm.requests.get")
    def test_failure_row_has_correct_query(self, mock_get):
        import requests as req
        mock_get.side_effect = req.ConnectionError("fail")
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(["FailPlace"], delay=0)
        assert result["query"].iloc[0] == "FailPlace"

    @patch("sungeo.geocode_osm.requests.get")
    def test_all_fail_returns_all_nan_rows(self, mock_get):
        import requests as req
        mock_get.side_effect = req.ConnectionError("fail")
        with warnings.catch_warnings():
            _ignore_delay_warning()
            result = geocode_osm_batch(["A", "B"], delay=0)
        assert len(result) == 2
        assert pd.isna(result["longitude"].iloc[0])
        assert pd.isna(result["longitude"].iloc[1])


# ════════════════════════════════════════════════
#  5. VERBOSE OUTPUT
# ════════════════════════════════════════════════

class TestVerbose:
    @patch("sungeo.geocode_osm.requests.get")
    def test_verbose_prints(self, mock_get, capsys):
        mock_get.side_effect = [
            _mock_get(MOCK_ANN_ARBOR),
            _mock_get(MOCK_COLUMBUS),
        ]
        with warnings.catch_warnings():
            _ignore_delay_warning()
            geocode_osm_batch(
                ["Ann Arbor", "Columbus"], delay=0, verbose=True,
            )
        captured = capsys.readouterr().out
        assert "1/2" in captured
        assert "2/2" in captured

    @patch("sungeo.geocode_osm.requests.get")
    def test_verbose_false_silent(self, mock_get, capsys):
        mock_get.return_value = _mock_get(MOCK_ANN_ARBOR)
        with warnings.catch_warnings():
            _ignore_delay_warning()
            geocode_osm_batch(["Ann Arbor"], delay=0, verbose=False)
        captured = capsys.readouterr().out
        assert "1/" not in captured


# ════════════════════════════════════════════════
#  6. LIVE INTEGRATION TESTS (skipped by default)
# ════════════════════════════════════════════════

@pytest.mark.skipif(
    True,
    reason="Live API tests disabled by default. Set to False to enable.",
)
class TestLiveAPI:
    def test_three_cities(self):
        result = geocode_osm_batch(
            ["Ann Arbor", "East Lansing", "Columbus"],
            delay=1.5, verbose=True,
        )
        assert len(result) == 3
        assert not result["longitude"].isna().any()

    def test_three_cities_details(self):
        result = geocode_osm_batch(
            ["Ann Arbor", "East Lansing", "Columbus"],
            delay=1.5, details=True,
        )
        assert list(result.columns) == R_REF["detail_columns"]