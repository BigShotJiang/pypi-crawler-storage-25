"""
Tests for sungeo.get_data

Test categories:
    1. R cross-check — live API tests (skipped by default)
    2. Input validation (missing params, bad types)
    3. Country code resolution
    4. URL building
    5. Time-precision adjustment
    6. Ticker merge logic (with mocked API)
    7. Error handling (error_stop, skip_missing)

Live tests call the real SUNGEO API and are skipped by default.
Enable by changing the skipif condition to False.
"""

import json
import re
import warnings
from unittest.mock import patch, MagicMock

import numpy as np
import pandas as pd
import pytest

from sungeo.get_data import (
    get_data,
    _names_to_iso3,
    _build_url,
    _adjust_time_unit,
    _merge_with_ticker,
    _format_error,
)

# ────────────────────────────────────────────────
#  R reference values (from RStudio)
# ────────────────────────────────────────────────

R_REF = {
    "test1_single": {
        "nrow": 204,
        "ncol": 34,
        "cols": [
            "YEAR", "POLYGON_ID", "ADM0_ISO3", "ADM0_NAME", "ADM0_CODE",
            "ADM1_NAME", "ADM1_CODE", "ADM2_NAME", "ADM2_CODE",
            "ADM3_NAME", "ADM3_CODE", "CST_NAME", "CST_CODE",
            "HEX05_CODE", "HEX05_X", "HEX05_Y", "PRIO_CODE", "PRIO_COL",
            "PRIO_ROW", "PRIO_X", "PRIO_Y", "GEOSET", "GEOSET_YEAR",
            "GEOSET_VERSION", "GEOSET_UNIT", "CENTROID_LONG",
            "CENTROID_LAT", "GHS_VERSION", "GHS_POP_COUNT", "GHS_POP_KM2",
            "GHS_POP_COUNT_LI", "GHS_POP_KM2_LI", "GHS_POP_COUNT_MR",
            "GHS_POP_KM2_MR",
        ],
        "years": ["2000", "2001", "2002", "2003", "2004", "2005"],
    },
    "test2_multi_country": {
        "nrow": 138,
        "ncol": 34,
    },
    "test3_multi_topic": {
        "nrow": 36,
        "ncol": 43,
        "cols": [
            "POLYGON_ID", "ADM0_ISO3", "ADM0_NAME", "ADM0_CODE",
            "ADM1_NAME", "ADM1_CODE", "ADM2_NAME", "ADM2_CODE",
            "ADM3_NAME", "ADM3_CODE", "CST_NAME", "CST_CODE",
            "HEX05_CODE", "HEX05_X", "HEX05_Y", "PRIO_CODE", "PRIO_COL",
            "PRIO_ROW", "PRIO_X", "PRIO_Y", "GEOSET", "GEOSET_YEAR",
            "GEOSET_VERSION", "GEOSET_UNIT", "CENTROID_LONG",
            "CENTROID_LAT", "YEAR", "GHS_VERSION", "GHS_POP_COUNT",
            "GHS_POP_KM2", "GHS_POP_COUNT_LI", "GHS_POP_KM2_LI",
            "GHS_POP_COUNT_MR", "GHS_POP_KM2_MR", "ETOPO1_VERSION",
            "ETOPO_ELEV_MEAN", "ETOPO_ELEV_SD", "ETOPO_ELEV_MIN",
            "ETOPO_ELEV_MAX", "ETOPO_SLOPE_MEAN", "ETOPO_SLOPE_SD",
            "ETOPO_SLOPE_MIN", "ETOPO_SLOPE_MAX",
        ],
    },
    "test4_iso3": {
        "nrow": 68,
        "ncol": 34,
    },
}


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK — LIVE API (skipped by default)
# ════════════════════════════════════════════════

# To enable: change True to False
@pytest.mark.skipif(
    True,
    reason="Live API tests disabled by default. Set to False to enable.",
)
class TestLiveRCrossCheck:
    """These tests call the real SUNGEO API and compare against R output."""

    def test1_single_country_topic(self):
        result = get_data(
            country_names="Afghanistan",
            topics="Demographics:Population:GHS",
            year_min=2000, year_max=2005,
            print_url=False, print_time=False,
        )
        ref = R_REF["test1_single"]
        assert len(result) == ref["nrow"]
        assert len(result.columns) == ref["ncol"]
        # Check key columns present
        for col in ["YEAR", "POLYGON_ID", "ADM0_ISO3", "GHS_POP_COUNT"]:
            assert col in result.columns
        # Check years
        years = sorted(result["YEAR"].unique().tolist())
        assert years == ref["years"]

    def test2_multi_country(self):
        result = get_data(
            country_names=["Afghanistan", "Albania"],
            topics="Demographics:Population:GHS",
            year_min=2000, year_max=2002,
            print_url=False, print_time=False,
        )
        ref = R_REF["test2_multi_country"]
        assert len(result) == ref["nrow"]
        assert len(result.columns) == ref["ncol"]
        # Both countries present
        iso3s = result["ADM0_ISO3"].unique().tolist()
        assert "AFG" in iso3s
        assert "ALB" in iso3s

    def test3_multi_topic(self):
        result = get_data(
            country_names="Albania",
            topics=["Demographics:Population:GHS", "Terrain:Elevation:ETOPO1"],
            year_min=2000, year_max=2002,
            print_url=False, print_time=False,
        )
        ref = R_REF["test3_multi_topic"]
        assert len(result) == ref["nrow"]
        assert len(result.columns) == ref["ncol"]
        # Should have columns from both topics
        assert "GHS_POP_COUNT" in result.columns
        assert "ETOPO_ELEV_MEAN" in result.columns

    def test4_iso3_input(self):
        result = get_data(
            country_iso3="AFG",
            topics="Demographics:Population:GHS",
            year_min=2000, year_max=2001,
            print_url=False, print_time=False,
        )
        ref = R_REF["test4_iso3"]
        assert len(result) == ref["nrow"]
        assert len(result.columns) == ref["ncol"]

    def test_returns_dataframe(self):
        result = get_data(
            country_iso3="AFG",
            topics="Demographics:Population:GHS",
            year_min=2000, year_max=2001,
            print_url=False, print_time=False,
        )
        assert isinstance(result, pd.DataFrame)

    def test_multi_topic_columns_from_r(self):
        """Column names should match R exactly for multi-topic query."""
        result = get_data(
            country_names="Albania",
            topics=["Demographics:Population:GHS", "Terrain:Elevation:ETOPO1"],
            year_min=2000, year_max=2002,
            print_url=False, print_time=False,
        )
        ref_cols = set(R_REF["test3_multi_topic"]["cols"])
        actual_cols = set(result.columns)
        # All R columns should be present (Python may have extras like 'message')
        missing = ref_cols - actual_cols
        assert not missing, f"Missing columns from R: {missing}"


# ════════════════════════════════════════════════
#  2. INPUT VALIDATION
# ════════════════════════════════════════════════

class TestInputValidation:
    def test_no_country_raises(self):
        with pytest.raises(ValueError, match="country"):
            get_data(topics="Demographics:Population:GHS")

    def test_no_topics_raises(self):
        with pytest.raises(ValueError, match="topic"):
            get_data(country_names="Afghanistan")

    def test_string_inputs_normalised(self):
        """Single strings should be auto-wrapped to lists."""
        # This just tests that the function doesn't crash on strings
        # (actual API call is mocked)
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.text = "[]"
            mock_resp.json.return_value = []
            mock_get.return_value = mock_resp
            result = get_data(
                country_iso3="AFG",
                topics="Demographics:Population:GHS",
                print_url=False, print_time=False,
            )
            assert isinstance(result, pd.DataFrame)


# ════════════════════════════════════════════════
#  3. COUNTRY CODE RESOLUTION
# ════════════════════════════════════════════════

class TestCountryCodeResolution:
    def test_afghanistan(self):
        iso3s = _names_to_iso3(["Afghanistan"])
        assert "AFG" in iso3s

    def test_albania(self):
        iso3s = _names_to_iso3(["Albania"])
        assert "ALB" in iso3s

    def test_multiple_countries(self):
        iso3s = _names_to_iso3(["Afghanistan", "Albania"])
        assert "AFG" in iso3s
        assert "ALB" in iso3s

    def test_unknown_country_returns_empty(self):
        iso3s = _names_to_iso3(["Nonexistentland"])
        assert iso3s == []

    def test_unresolvable_raises(self):
        with pytest.raises(ValueError, match="Could not resolve"):
            get_data(
                country_names="Nonexistentland",
                topics="Demographics:Population:GHS",
                print_url=False, print_time=False,
            )

    def test_iso3_bypasses_lookup(self):
        """When country_iso3 is given, no name lookup is needed."""
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.text = "[]"
            mock_resp.json.return_value = []
            mock_get.return_value = mock_resp
            get_data(
                country_iso3="AFG",
                topics="Demographics:Population:GHS",
                print_url=False, print_time=False,
            )
            # URL should contain AFG
            called_url = mock_get.call_args[0][0]
            assert "AFG" in called_url


# ════════════════════════════════════════════════
#  4. URL BUILDING
# ════════════════════════════════════════════════

class TestURLBuilding:
    def test_basic_url(self):
        url = _build_url(
            "AFG", "GADM", 2018, "adm1", "year",
            "Demographics:Population:GHS", 2000, 2005, False,
        )
        assert "AFG" in url
        assert "GADM" in url
        assert "ADM1" in url
        assert "YEAR" in url
        assert "Demographics:Population:GHS" in url
        assert "date=2000-2005" in url

    def test_time_invariant_no_date(self):
        url = _build_url(
            "ALB", "GADM", 2018, "adm1", "year",
            "Terrain:Elevation:ETOPO1", 2000, 2005, False,
        )
        assert "date=" not in url

    def test_cache_enabled(self):
        url = _build_url(
            "AFG", "GADM", 2018, "adm1", "year",
            "Demographics:Population:GHS", 2000, 2005, True,
        )
        assert "cacheEnabled=true" in url

    def test_cache_disabled(self):
        url = _build_url(
            "AFG", "GADM", 2018, "adm1", "year",
            "Demographics:Population:GHS", 2000, 2005, False,
        )
        assert "cacheEnabled=false" in url


# ════════════════════════════════════════════════
#  5. TIME-PRECISION ADJUSTMENT
# ════════════════════════════════════════════════

class TestTimePrecision:
    def test_year_for_year_topic(self):
        result = _adjust_time_unit("Demographics:Population:GHS", "year")
        assert result == "year"

    def test_month_for_year_only_topic_falls_back(self):
        """GHS only supports YEAR, so requesting month should fall back."""
        result = _adjust_time_unit("Demographics:Population:GHS", "month")
        assert result.lower() == "year"

    def test_month_for_noaa(self):
        """NOAA supports YEAR|MONTH, so month should work."""
        result = _adjust_time_unit(
            "Weather:AirTemperatureAndPrecipitation:NOAA", "month"
        )
        assert result == "month"

    def test_week_for_noaa_falls_back(self):
        """NOAA supports YEAR|MONTH only, so week should fall back to MONTH."""
        result = _adjust_time_unit(
            "Weather:AirTemperatureAndPrecipitation:NOAA", "week"
        )
        assert result.lower() == "month"

    def test_week_for_acled(self):
        """ACLED supports YEAR|MONTH|WEEK, so week should work."""
        result = _adjust_time_unit(
            "Events:PoliticalViolence:ACLED", "week"
        )
        assert result == "week"

    def test_unknown_topic_defaults_to_year(self):
        result = _adjust_time_unit("Unknown:Topic:Source", "month")
        assert result.lower() == "year"


# ════════════════════════════════════════════════
#  6. TICKER MERGE LOGIC
# ════════════════════════════════════════════════

class TestTickerMerge:
    def test_no_time_columns_returns_unchanged(self):
        df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
        result = _merge_with_ticker(df, "year", 2000, 2002)
        assert result.equals(df)

    def test_year_column_merged(self):
        df = pd.DataFrame({"YEAR": ["2000", "2001"], "val": [10, 20]})
        result = _merge_with_ticker(df, "year", 2000, 2001)
        assert "YEAR" in result.columns
        assert "val" in result.columns
        assert len(result) >= 2


# ════════════════════════════════════════════════
#  7. ERROR HANDLING
# ════════════════════════════════════════════════

class TestErrorHandling:
    def test_api_error_stop_true_raises(self):
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.text = json.dumps({
                "error": {"code": 404, "message": "Not found"}
            })
            mock_resp.json.return_value = {
                "error": {"code": 404, "message": "Not found"}
            }
            mock_get.return_value = mock_resp
            with pytest.raises(RuntimeError, match="ERROR 404"):
                get_data(
                    country_iso3="AFG",
                    topics="Demographics:Population:GHS",
                    error_stop=True,
                    print_url=False, print_time=False,
                )

    def test_api_error_stop_false_returns_df(self):
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.text = json.dumps({
                "error": {"code": 404, "message": "Not found"}
            })
            mock_resp.json.return_value = {
                "error": {"code": 404, "message": "Not found"}
            }
            mock_get.return_value = mock_resp
            result = get_data(
                country_iso3="AFG",
                topics="Demographics:Population:GHS",
                error_stop=False,
                print_url=False, print_time=False,
            )
            # Should return empty or error df, not crash
            assert isinstance(result, pd.DataFrame)

    def test_network_failure_error_stop_false(self):
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_get.side_effect = ConnectionError("No internet")
            result = get_data(
                country_iso3="AFG",
                topics="Demographics:Population:GHS",
                error_stop=False,
                print_url=False, print_time=False,
            )
            assert isinstance(result, pd.DataFrame)

    def test_network_failure_error_stop_true_raises(self):
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_get.side_effect = ConnectionError("No internet")
            with pytest.raises(Exception):
                get_data(
                    country_iso3="AFG",
                    topics="Demographics:Population:GHS",
                    error_stop=True,
                    print_url=False, print_time=False,
                )

    def test_format_error_short(self):
        msg = "not all of the provided topics [Demographics:Pop:GHS] [AFG]"
        result = _format_error(msg, short_message=True)
        assert "missing for" in result

    def test_format_error_long(self):
        msg = "Some long error message"
        result = _format_error(msg, short_message=True)
        assert result == msg

    def test_fatal_error_response(self):
        with patch("sungeo.get_data.requests.get") as mock_get:
            mock_resp = MagicMock()
            mock_resp.text = "<html>Fatal error: something broke</html>"
            mock_get.return_value = mock_resp
            result = get_data(
                country_iso3="AFG",
                topics="Demographics:Population:GHS",
                error_stop=False,
                print_url=False, print_time=False,
            )
            assert isinstance(result, pd.DataFrame)


# ════════════════════════════════════════════════
#  8. REDUNDANT COLUMN REMOVAL
# ════════════════════════════════════════════════

class TestColumnRemoval:
    def test_year_mode_drops_sub_year_cols(self):
        """In yearly mode, YRMO/MID/YRWK/WID/DATE/DATE_ALT/TID should be dropped."""
        df = pd.DataFrame({
            "YEAR": [2000],
            "YRMO": [200001],
            "MID": [1],
            "val": [10],
        })
        # Simulate what get_data does at the end
        drop_cols = ["YRMO", "MID", "YRWK", "WID", "DATE", "DATE_ALT", "TID"]
        existing = [c for c in drop_cols if c in df.columns]
        result = df.drop(columns=existing)
        assert "YRMO" not in result.columns
        assert "MID" not in result.columns
        assert "YEAR" in result.columns
        assert "val" in result.columns