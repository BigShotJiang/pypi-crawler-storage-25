"""
Tests for sungeo.sf2raster

Test categories:
    1. R cross-check (polygon raster, point raster, round-trip)
    2. Structural tests (shapes, keys, types, CRS)
    3. Value sanity tests (ranges, NaN counts, variable values)
    4. Synthetic tests (hand-calculated expected values)
    5. Input safety (no mutation of input GeoDataFrames)
    6. Error handling (bad inputs, missing params)
    7. Edge cases (single polygon, single point, collinear points)
    8. write_raster I/O
"""

import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import geopandas as gpd
from shapely.geometry import box, Point, MultiPoint

from sungeo.sf2raster import sf2raster, write_raster
from sungeo.utm_select import utm_select

# ────────────────────────────────────────────────
#  R reference values (from RStudio, grid_dim 50×50 / 25×25)
# ────────────────────────────────────────────────

R_REF = {
    "test1_poly": {
        "nrow": 50,
        "ncol": 50,
        "min_val": 0.604721,
        "max_val": 0.7376,
        "mean_val": 0.699444,
        "na_count": 887,
        "non_na_count": 1613,
    },
    "test2_point": {
        "nrow": 25,
        "ncol": 25,
        "min_val": 0.604721,
        "max_val": 0.7376,
        "mean_val": 0.697388,
        "na_count": 610,
        "non_na_count": 15,
    },
    "test3_roundtrip": {
        "nrow": 16,
        "to1_mean": 0.696887,
        "to1_min": 0.604721,
        "to1_max": 0.7376,
        "to1_na_count": 0,
    },
}

# ────────────────────────────────────────────────
#  Data paths & fixtures
# ────────────────────────────────────────────────

DATA_DIR = Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


@pytest.fixture(scope="module")
def clea():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


@pytest.fixture(scope="module")
def clea_pt():
    return gpd.read_file(DATA_DIR / "clea_deu2009_pt.gpkg")


@pytest.fixture(scope="module")
def clea_proj(clea):
    return utm_select(clea)


@pytest.fixture(scope="module")
def clea_pt_proj(clea_pt):
    return utm_select(clea_pt)


@pytest.fixture(scope="module")
def poly_raster_50(clea_proj):
    """Polygon → raster, 50×50 grid."""
    return sf2raster(
        polyz_from=clea_proj,
        input_variable="to1",
        grid_dim=(50, 50),
        message_out=False,
    )


@pytest.fixture(scope="module")
def poly_raster_50_full(clea_proj):
    """Polygon → raster, 50×50 grid, return_list=True."""
    return sf2raster(
        polyz_from=clea_proj,
        input_variable="to1",
        grid_dim=(50, 50),
        return_list=True,
        message_out=False,
    )


@pytest.fixture(scope="module")
def point_raster_25(clea_pt_proj):
    """Point → raster, 25×25 grid."""
    return sf2raster(
        pointz_from=clea_pt_proj,
        input_variable="to1",
        grid_dim=(25, 25),
        message_out=False,
    )


@pytest.fixture(scope="module")
def roundtrip_result(poly_raster_50_full):
    """Raster → polygon (reverse)."""
    return sf2raster(
        reverse=True,
        poly_to=poly_raster_50_full["poly_to"],
        return_output=poly_raster_50_full["return_output"],
        return_field=poly_raster_50_full["return_field"],
        message_out=False,
    )


# ────────────────────────────────────────────────
#  Synthetic fixtures
# ────────────────────────────────────────────────

@pytest.fixture(scope="module")
def synth_polys():
    """Three non-overlapping unit squares with known values."""
    return gpd.GeoDataFrame(
        {
            "val": [10.0, 20.0, 30.0],
            "geometry": [box(0, 0, 1, 1), box(1, 0, 2, 1), box(0, 1, 1, 2)],
        },
        crs="EPSG:32632",
    )


@pytest.fixture(scope="module")
def synth_points():
    """Four points, two co-located, with known values."""
    return gpd.GeoDataFrame(
        {
            "val": [100.0, 200.0, 300.0, 400.0],
            "geometry": [
                Point(0.5, 0.5),
                Point(1.5, 0.5),
                Point(0.5, 1.5),
                Point(0.5, 0.5),  # co-located with first
            ],
        },
        crs="EPSG:32632",
    )


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK TESTS
# ════════════════════════════════════════════════

class TestRCrossCheckPolygon:
    """Test polygon raster against R reference (50×50)."""

    def test_shape(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        assert poly_raster_50["data"].shape == (ref["nrow"], ref["ncol"])

    def test_min_val(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        data = poly_raster_50["data"]
        assert np.nanmin(data) == pytest.approx(ref["min_val"], abs=0.01)

    def test_max_val(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        data = poly_raster_50["data"]
        assert np.nanmax(data) == pytest.approx(ref["max_val"], abs=0.01)

    def test_mean_val(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        data = poly_raster_50["data"]
        assert np.nanmean(data) == pytest.approx(ref["mean_val"], abs=0.01)

    def test_non_na_count(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        data = poly_raster_50["data"]
        non_na = np.count_nonzero(~np.isnan(data))
        # Allow some tolerance for edge pixel differences between GEOS versions
        assert non_na == pytest.approx(ref["non_na_count"], rel=0.05)

    def test_na_count(self, poly_raster_50):
        ref = R_REF["test1_poly"]
        data = poly_raster_50["data"]
        na = np.count_nonzero(np.isnan(data))
        assert na == pytest.approx(ref["na_count"], rel=0.05)


class TestRCrossCheckPoint:
    """Test point raster against R reference (25×25)."""

    def test_shape(self, point_raster_25):
        ref = R_REF["test2_point"]
        assert point_raster_25["data"].shape == (ref["nrow"], ref["ncol"])

    def test_min_val(self, point_raster_25):
        ref = R_REF["test2_point"]
        data = point_raster_25["data"]
        assert np.nanmin(data) == pytest.approx(ref["min_val"], abs=0.01)

    def test_max_val(self, point_raster_25):
        ref = R_REF["test2_point"]
        data = point_raster_25["data"]
        assert np.nanmax(data) == pytest.approx(ref["max_val"], abs=0.01)

    def test_mean_val(self, point_raster_25):
        ref = R_REF["test2_point"]
        data = point_raster_25["data"]
        assert np.nanmean(data) == pytest.approx(ref["mean_val"], abs=0.01)

    def test_non_na_count(self, point_raster_25):
        ref = R_REF["test2_point"]
        data = point_raster_25["data"]
        non_na = np.count_nonzero(~np.isnan(data))
        # Points map 1:1 to cells; 16 points but some may share a cell
        assert non_na == pytest.approx(ref["non_na_count"], abs=2)

    def test_na_count(self, point_raster_25):
        ref = R_REF["test2_point"]
        data = point_raster_25["data"]
        total = data.size
        non_na = np.count_nonzero(~np.isnan(data))
        na = total - non_na
        assert na == pytest.approx(ref["na_count"], abs=2)


class TestRCrossCheckRoundTrip:
    """Test polygon → raster → polygon round-trip against R reference."""

    def test_nrow(self, roundtrip_result):
        ref = R_REF["test3_roundtrip"]
        assert len(roundtrip_result) == ref["nrow"]

    def test_mean(self, roundtrip_result):
        ref = R_REF["test3_roundtrip"]
        assert roundtrip_result["to1"].mean() == pytest.approx(
            ref["to1_mean"], abs=0.01
        )

    def test_min(self, roundtrip_result):
        ref = R_REF["test3_roundtrip"]
        assert roundtrip_result["to1"].min() == pytest.approx(
            ref["to1_min"], abs=0.01
        )

    def test_max(self, roundtrip_result):
        ref = R_REF["test3_roundtrip"]
        assert roundtrip_result["to1"].max() == pytest.approx(
            ref["to1_max"], abs=0.01
        )

    def test_no_na(self, roundtrip_result):
        ref = R_REF["test3_roundtrip"]
        assert roundtrip_result["to1"].isna().sum() == ref["to1_na_count"]


# ════════════════════════════════════════════════
#  2. STRUCTURAL TESTS
# ════════════════════════════════════════════════

class TestStructural:
    def test_poly_raster_is_dict(self, poly_raster_50):
        assert isinstance(poly_raster_50, dict)

    def test_poly_raster_keys(self, poly_raster_50):
        assert set(poly_raster_50.keys()) == {
            "data", "transform", "crs", "nodata", "name",
        }

    def test_poly_raster_name(self, poly_raster_50):
        assert poly_raster_50["name"] == "to1"

    def test_poly_raster_crs_preserved(self, poly_raster_50, clea_proj):
        # Both should reference the same projected CRS
        assert poly_raster_50["crs"] is not None

    def test_poly_full_keys(self, poly_raster_50_full):
        assert set(poly_raster_50_full.keys()) == {
            "return_output", "return_centroid", "poly_to", "return_field",
        }

    def test_poly_full_poly_to_has_field(self, poly_raster_50_full):
        assert "Field" in poly_raster_50_full["poly_to"].columns

    def test_poly_full_field_raster_shape(self, poly_raster_50_full):
        assert poly_raster_50_full["return_field"]["data"].shape == (50, 50)

    def test_point_raster_is_dict(self, point_raster_25):
        assert isinstance(point_raster_25, dict)

    def test_point_full_keys(self, clea_pt_proj):
        result = sf2raster(
            pointz_from=clea_pt_proj,
            input_variable="to1",
            grid_dim=(25, 25),
            return_list=True,
            message_out=False,
        )
        assert set(result.keys()) == {"return_output", "return_point"}

    def test_roundtrip_is_geodataframe(self, roundtrip_result):
        assert isinstance(roundtrip_result, gpd.GeoDataFrame)

    def test_roundtrip_has_geometry(self, roundtrip_result):
        assert roundtrip_result.geometry.name in roundtrip_result.columns


# ════════════════════════════════════════════════
#  3. VALUE SANITY TESTS
# ════════════════════════════════════════════════

class TestValueSanity:
    def test_poly_values_in_turnout_range(self, poly_raster_50):
        data = poly_raster_50["data"]
        valid = data[~np.isnan(data)]
        assert valid.min() >= 0.0
        assert valid.max() <= 1.0

    def test_point_values_in_turnout_range(self, point_raster_25):
        data = point_raster_25["data"]
        valid = data[~np.isnan(data)]
        assert valid.min() >= 0.0
        assert valid.max() <= 1.0

    def test_centroid_layer_sparser_than_output(self, poly_raster_50_full):
        out_data = poly_raster_50_full["return_output"]["data"]
        cen_data = poly_raster_50_full["return_centroid"]["data"]
        out_nonnan = np.count_nonzero(~np.isnan(out_data))
        cen_nonnan = np.count_nonzero(~np.isnan(cen_data))
        assert cen_nonnan < out_nonnan

    def test_field_raster_unique_ids(self, poly_raster_50_full):
        field = poly_raster_50_full["return_field"]["data"]
        valid = field[field > 0]
        unique_ids = np.unique(valid)
        # Should have at most 16 unique polygon IDs
        assert len(unique_ids) <= 16
        assert len(unique_ids) >= 1

    def test_roundtrip_values_close_to_original(self, roundtrip_result, clea_proj):
        # Raster aggregation may shift values slightly, but mean should be close
        orig_mean = clea_proj["to1"].mean()
        rt_mean = roundtrip_result["to1"].mean()
        assert rt_mean == pytest.approx(orig_mean, abs=0.02)


# ════════════════════════════════════════════════
#  4. SYNTHETIC TESTS
# ════════════════════════════════════════════════

class TestSyntheticPolygon:
    def test_three_squares_values(self, synth_polys):
        r = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 20),
            message_out=False,
        )
        valid = r["data"][~np.isnan(r["data"])]
        unique_vals = set(np.unique(valid))
        assert unique_vals == {10.0, 20.0, 30.0}

    def test_three_squares_shape(self, synth_polys):
        r = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 20),
            message_out=False,
        )
        assert r["data"].shape == (10, 20)

    def test_three_squares_roundtrip(self, synth_polys):
        fwd = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 20),
            return_list=True,
            message_out=False,
        )
        rev = sf2raster(
            reverse=True,
            poly_to=fwd["poly_to"],
            return_output=fwd["return_output"],
            return_field=fwd["return_field"],
            message_out=False,
        )
        assert sorted(rev["val"].tolist()) == [10.0, 20.0, 30.0]

    def test_field_ids_sequential(self, synth_polys):
        fwd = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 20),
            return_list=True,
            message_out=False,
        )
        assert list(fwd["poly_to"]["Field"]) == [1, 2, 3]


class TestSyntheticPoint:
    def test_colocated_points_mean(self, synth_points):
        """Two points at (0.5, 0.5) with values 100 and 400 → mean = 250."""
        r = sf2raster(
            pointz_from=synth_points,
            input_variable="val",
            grid_dim=(10, 10),
            message_out=False,
        )
        valid = r["data"][~np.isnan(r["data"])]
        assert 250.0 in valid  # mean of 100 and 400

    def test_colocated_points_sum(self, synth_points):
        """Two points at (0.5, 0.5) with values 100 and 400 → sum = 500."""
        r = sf2raster(
            pointz_from=synth_points,
            input_variable="val",
            grid_dim=(10, 10),
            aggregate_function=lambda x: np.nansum(x),
            message_out=False,
        )
        valid = r["data"][~np.isnan(r["data"])]
        assert 500.0 in valid

    def test_three_occupied_cells(self, synth_points):
        """4 points, 2 co-located → 3 distinct cells."""
        r = sf2raster(
            pointz_from=synth_points,
            input_variable="val",
            grid_dim=(10, 10),
            message_out=False,
        )
        non_na = np.count_nonzero(~np.isnan(r["data"]))
        assert non_na == 3


class TestCustomReverseFunction:
    def test_reverse_with_max(self, synth_polys):
        fwd = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 20),
            return_list=True,
            message_out=False,
        )
        rev = sf2raster(
            reverse=True,
            poly_to=fwd["poly_to"],
            return_output=fwd["return_output"],
            return_field=fwd["return_field"],
            reverse_function=lambda x: np.nanmax(x),
            message_out=False,
        )
        # All pixels in each polygon have the same value, so max == mean
        assert sorted(rev["val"].tolist()) == [10.0, 20.0, 30.0]


# ════════════════════════════════════════════════
#  5. INPUT SAFETY
# ════════════════════════════════════════════════

class TestInputSafety:
    def test_polygon_input_not_mutated(self, synth_polys):
        original_cols = list(synth_polys.columns)
        original_vals = synth_polys["val"].tolist()
        sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(5, 5),
            message_out=False,
        )
        assert list(synth_polys.columns) == original_cols
        assert synth_polys["val"].tolist() == original_vals
        assert "Field" not in synth_polys.columns

    def test_point_input_not_mutated(self, synth_points):
        original_cols = list(synth_points.columns)
        original_vals = synth_points["val"].tolist()
        sf2raster(
            pointz_from=synth_points,
            input_variable="val",
            grid_dim=(5, 5),
            message_out=False,
        )
        assert list(synth_points.columns) == original_cols
        assert synth_points["val"].tolist() == original_vals

    def test_reverse_poly_to_not_mutated(self, synth_polys):
        fwd = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(5, 5),
            return_list=True,
            message_out=False,
        )
        poly_to = fwd["poly_to"]
        original_cols = list(poly_to.columns)
        sf2raster(
            reverse=True,
            poly_to=poly_to,
            return_output=fwd["return_output"],
            return_field=fwd["return_field"],
            message_out=False,
        )
        assert list(poly_to.columns) == original_cols


# ════════════════════════════════════════════════
#  6. ERROR HANDLING
# ════════════════════════════════════════════════

class TestErrorHandling:
    def test_both_inputs_raises(self, synth_polys, synth_points):
        with pytest.raises(ValueError, match="only one type"):
            sf2raster(
                polyz_from=synth_polys,
                pointz_from=synth_points,
                input_variable="val",
                message_out=False,
            )

    def test_no_input_raises(self):
        with pytest.raises(ValueError):
            sf2raster(input_variable="val", message_out=False)

    def test_wrong_type_raises(self):
        with pytest.raises(TypeError, match="GeoDataFrame"):
            sf2raster(polyz_from="not_a_gdf", input_variable="x", message_out=False)

    def test_missing_reverse_params_raises(self, synth_polys):
        with pytest.raises(ValueError, match="reverse"):
            sf2raster(reverse=True, poly_to=synth_polys, message_out=False)

    def test_missing_column_polygon_raises(self, synth_polys):
        with pytest.raises(ValueError, match="not found"):
            sf2raster(
                polyz_from=synth_polys,
                input_variable="nonexistent",
                message_out=False,
            )

    def test_missing_column_point_raises(self, synth_points):
        with pytest.raises(ValueError, match="not found"):
            sf2raster(
                pointz_from=synth_points,
                input_variable="nonexistent",
                message_out=False,
            )

    def test_cartogram_raises_not_implemented(self, synth_polys):
        with pytest.raises(NotImplementedError, match="[Cc]artogram"):
            sf2raster(
                polyz_from=synth_polys,
                input_variable="val",
                cartogram=True,
                carto_var="val",
                message_out=False,
            )

    def test_cartogram_point_raises(self, synth_points):
        with pytest.raises(ValueError, match="polygon"):
            sf2raster(
                pointz_from=synth_points,
                input_variable="val",
                cartogram=True,
                carto_var="val",
                message_out=False,
            )

    def test_cartogram_no_var_raises(self, synth_polys):
        with pytest.raises(ValueError, match="carto_var"):
            sf2raster(
                polyz_from=synth_polys,
                input_variable="val",
                cartogram=True,
                message_out=False,
            )

    def test_reverse_wrong_type_raises(self):
        with pytest.raises(TypeError, match="GeoDataFrame"):
            sf2raster(
                reverse=True,
                poly_to="bad",
                return_output={},
                return_field={},
                message_out=False,
            )


# ════════════════════════════════════════════════
#  7. EDGE CASES
# ════════════════════════════════════════════════

class TestEdgeCases:
    def test_single_polygon(self):
        gdf = gpd.GeoDataFrame(
            {"val": [42.0], "geometry": [box(0, 0, 10, 10)]},
            crs="EPSG:32632",
        )
        r = sf2raster(
            polyz_from=gdf, input_variable="val",
            grid_dim=(5, 5), message_out=False,
        )
        valid = r["data"][~np.isnan(r["data"])]
        assert np.all(valid == 42.0)

    def test_single_point(self):
        gdf = gpd.GeoDataFrame(
            {"val": [99.0], "geometry": [Point(5, 5)]},
            crs="EPSG:32632",
        )
        r = sf2raster(
            pointz_from=gdf, input_variable="val",
            grid_dim=(5, 5), message_out=False,
        )
        non_na = np.count_nonzero(~np.isnan(r["data"]))
        assert non_na == 1
        assert 99.0 in r["data"][~np.isnan(r["data"])]

    def test_collinear_points_x(self):
        """Points on same x-axis (degenerate bbox width)."""
        gdf = gpd.GeoDataFrame(
            {"val": [10.0, 20.0], "geometry": [Point(1, 0), Point(1, 2)]},
            crs="EPSG:32632",
        )
        r = sf2raster(
            pointz_from=gdf, input_variable="val",
            grid_dim=(5, 5), message_out=False,
        )
        assert r["data"].shape == (5, 5)
        non_na = np.count_nonzero(~np.isnan(r["data"]))
        assert non_na >= 2

    def test_collinear_points_y(self):
        """Points on same y-axis (degenerate bbox height)."""
        gdf = gpd.GeoDataFrame(
            {"val": [10.0, 20.0], "geometry": [Point(0, 1), Point(2, 1)]},
            crs="EPSG:32632",
        )
        r = sf2raster(
            pointz_from=gdf, input_variable="val",
            grid_dim=(5, 5), message_out=False,
        )
        assert r["data"].shape == (5, 5)
        non_na = np.count_nonzero(~np.isnan(r["data"]))
        assert non_na >= 2

    def test_geographic_crs_warning(self):
        gdf = gpd.GeoDataFrame(
            {"val": [1.0], "geometry": [box(0, 0, 1, 1)]},
            crs="EPSG:4326",
        )
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            sf2raster(
                polyz_from=gdf, input_variable="val",
                grid_dim=(5, 5), message_out=True,
            )
            geo_warns = [x for x in w if "geographic CRS" in str(x.message)]
            assert len(geo_warns) >= 1

    def test_no_warning_projected_crs(self):
        gdf = gpd.GeoDataFrame(
            {"val": [1.0], "geometry": [box(0, 0, 1, 1)]},
            crs="EPSG:32632",
        )
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            sf2raster(
                polyz_from=gdf, input_variable="val",
                grid_dim=(5, 5), message_out=True,
            )
            geo_warns = [x for x in w if "geographic CRS" in str(x.message)]
            assert len(geo_warns) == 0

    def test_large_grid_dim(self, synth_polys):
        """Ensure larger grids work without error."""
        r = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(200, 200),
            message_out=False,
        )
        assert r["data"].shape == (200, 200)


# ════════════════════════════════════════════════
#  8. WRITE RASTER I/O
# ════════════════════════════════════════════════

class TestWriteRaster:
    def test_write_and_read(self, synth_polys, tmp_path):
        r = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 10),
            message_out=False,
        )
        filepath = str(tmp_path / "test_output.tif")
        write_raster(r, filepath)

        import rasterio

        with rasterio.open(filepath) as src:
            data = src.read(1)
            assert data.shape == (10, 10)
            assert src.crs is not None

    def test_roundtrip_values_via_file(self, synth_polys, tmp_path):
        r = sf2raster(
            polyz_from=synth_polys,
            input_variable="val",
            grid_dim=(10, 10),
            message_out=False,
        )
        filepath = str(tmp_path / "test_vals.tif")
        write_raster(r, filepath)

        import rasterio

        with rasterio.open(filepath) as src:
            data = src.read(1)
            valid = data[~np.isnan(data)]
            assert set(np.unique(valid)) == {10.0, 20.0, 30.0}