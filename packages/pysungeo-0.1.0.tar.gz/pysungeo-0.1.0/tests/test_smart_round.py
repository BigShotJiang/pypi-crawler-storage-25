"""
Tests for sungeo.smart_round

Test categories:
    1. R example cross-checks (documented examples from R docstring)
    2. Core behavior (signif preservation, normal rounding)
    3. Edge cases (zero, negative, scalar, large values)
    4. Output format (return_char True/False)
    5. Error handling
"""

import numpy as np
import pytest

from sungeo.smart_round import smart_round


# ════════════════════════════════════════════════
#  1. R EXAMPLE CROSS-CHECKS
# ════════════════════════════════════════════════

class TestRExamples:
    """Values from R: smart_round(c(.0013, 2.3, -1, pi), rnd=2)"""

    def test_char_output(self):
        r = smart_round([0.0013, 2.3, -1, np.pi], rnd=2)
        assert r == ["0.001", "2.3", "-1.0", "3.14"]

    def test_numeric_output(self):
        r = smart_round([0.0013, 2.3, -1, np.pi], rnd=2, return_char=False)
        expected = np.array([0.001, 2.3, -1.0, 3.14])
        np.testing.assert_allclose(r, expected, atol=1e-10)


# ════════════════════════════════════════════════
#  2. CORE BEHAVIOR: SIGNIF PRESERVATION
# ════════════════════════════════════════════════

class TestSignifPreservation:
    """When normal rounding gives zero, smart_round keeps 1 significant digit."""

    def test_small_positive(self):
        # 0.0013 rounded to 2 decimals → 0.00 → smart: 0.001
        r = smart_round([0.0013], rnd=2, return_char=False)
        assert r[0] == pytest.approx(0.001, abs=1e-10)

    def test_small_negative(self):
        # -0.00045 rounded to 2 decimals → 0.00 → smart: -0.0004
        r = smart_round([-0.00045], rnd=2, return_char=False)
        assert r[0] == pytest.approx(-0.0004, abs=1e-10)

    def test_very_small(self):
        # 0.000006 rounded to 2 decimals → 0.00 → smart: 0.000006
        r = smart_round([0.000006], rnd=2, return_char=False)
        assert r[0] == pytest.approx(6e-6, abs=1e-10)

    def test_normal_rounding_preserved(self):
        # 2.3 rounded to 2 decimals → 2.3 (no intervention needed)
        r = smart_round([2.3], rnd=2, return_char=False)
        assert r[0] == pytest.approx(2.3, abs=1e-10)

    def test_pi_rnd0(self):
        r = smart_round([np.pi], rnd=0, return_char=False)
        assert r[0] == pytest.approx(3.0, abs=1e-10)

    def test_pi_rnd3(self):
        r = smart_round([np.pi], rnd=3, return_char=False)
        assert r[0] == pytest.approx(3.142, abs=0.001)

    def test_already_exact(self):
        r = smart_round([1.5, 2.5, 3.5], rnd=1, return_char=False)
        np.testing.assert_allclose(r, [1.5, 2.5, 3.5], atol=1e-10)


# ════════════════════════════════════════════════
#  3. EDGE CASES
# ════════════════════════════════════════════════

class TestEdgeCases:
    def test_zero(self):
        r = smart_round([0.0], rnd=2, return_char=False)
        assert r[0] == pytest.approx(0.0, abs=1e-10)

    def test_integer_input(self):
        r = smart_round([5], rnd=2, return_char=False)
        assert r[0] == pytest.approx(5.0, abs=1e-10)

    def test_negative_one(self):
        r = smart_round([-1], rnd=2, return_char=False)
        assert r[0] == pytest.approx(-1.0, abs=1e-10)

    def test_large_number(self):
        r = smart_round([123456.789], rnd=1, return_char=False)
        assert r[0] == pytest.approx(123456.8, abs=0.1)

    def test_scalar_input_char(self):
        r = smart_round(0.0013, rnd=2)
        assert isinstance(r, str)
        assert r == "0.001"

    def test_scalar_input_numeric(self):
        r = smart_round(0.0013, rnd=2, return_char=False)
        assert isinstance(r, (float, np.floating))

    def test_rnd_zero(self):
        r = smart_round([0.0013, 2.3, -1, np.pi], rnd=0)
        assert r[0] == "0.001"  # too small → signif
        assert r[1] == "2.0"
        assert r[2] == "-1.0"
        assert r[3] == "3.0"

    def test_mixed_small_and_normal(self):
        vals = [0.00001, 0.5, 100, -0.00003]
        r = smart_round(vals, rnd=2, return_char=False)
        assert r[0] == pytest.approx(1e-5, abs=1e-10)
        assert r[1] == pytest.approx(0.5, abs=1e-10)
        assert r[2] == pytest.approx(100.0, abs=1e-10)
        assert r[3] == pytest.approx(-3e-5, abs=1e-10)

    def test_numpy_array_input(self):
        arr = np.array([0.0013, 2.3])
        r = smart_round(arr, rnd=2, return_char=False)
        assert isinstance(r, np.ndarray)


# ════════════════════════════════════════════════
#  4. OUTPUT FORMAT
# ════════════════════════════════════════════════

class TestOutputFormat:
    def test_return_char_true_gives_strings(self):
        r = smart_round([1.0, 2.0], rnd=1, return_char=True)
        assert all(isinstance(v, str) for v in r)

    def test_return_char_false_gives_array(self):
        r = smart_round([1.0, 2.0], rnd=1, return_char=False)
        assert isinstance(r, np.ndarray)

    def test_list_length_matches_input(self):
        vals = [1, 2, 3, 4, 5]
        r_char = smart_round(vals, rnd=1)
        r_num = smart_round(vals, rnd=1, return_char=False)
        assert len(r_char) == 5
        assert len(r_num) == 5