"""Tests for sungeo.point2poly_simp against R reference output.

Reference values generated manually in R using st_within + aggregate
on clea_deu2009_pt → hex_05_deu, with FUN=sum for vv1.
"""

import pathlib

import geopandas as gpd
import numpy as np
import pandas as pd
import pytest
from shapely.geometry import Point, box

from sungeo.point2poly_simp import point2poly_simp

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"

# ── R reference values (clea_deu2009_pt → hex_05_deu, varz="vv1") ───
R_REF = {
    "nrow": 257,
    "vv1_sum": 43371190,
    "vv1_mean": 2891413,
    "vv1_na_count": 242,
    "vv1_min": 338611,
    "vv1_max": 9389412,
    "original_sum": 43371190,
}


# ── fixtures ─────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def pointz():
    return gpd.read_file(DATA_DIR / "clea_deu2009_pt.gpkg")


@pytest.fixture(scope="module")
def polyz():
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def result_default(pointz, polyz):
    """Test case 1: single variable, default sum."""
    return point2poly_simp(pointz=pointz, polyz=polyz, varz="vv1")


# ── structure tests ──────────────────────────────────────────────────
class TestStructure:

    def test_returns_geodataframe(self, result_default):
        assert isinstance(result_default, gpd.GeoDataFrame)

    def test_row_count_matches_destination(self, result_default, polyz):
        assert len(result_default) == len(polyz)

    def test_output_has_variable_column(self, result_default):
        assert "vv1" in result_default.columns

    def test_destination_columns_preserved(self, result_default, polyz):
        for col in polyz.columns:
            if col != "polygon_id_":
                assert col in result_default.columns


# ── R cross-check tests ───────────────────────────────────────────────
class TestRCrossCheck:

    def test_row_count(self, result_default):
        assert len(result_default) == R_REF["nrow"]

    def test_vv1_sum(self, result_default):
        result_sum = result_default["vv1"].dropna().sum()
        assert result_sum == pytest.approx(R_REF["vv1_sum"], rel=0.01)

    def test_vv1_mean(self, result_default):
        result_mean = result_default["vv1"].dropna().mean()
        assert result_mean == pytest.approx(R_REF["vv1_mean"], rel=0.01)

    def test_vv1_na_count(self, result_default):
        assert result_default["vv1"].isna().sum() == R_REF["vv1_na_count"]

    def test_vv1_min(self, result_default):
        result_min = result_default["vv1"].dropna().min()
        assert result_min == pytest.approx(R_REF["vv1_min"], rel=0.01)

    def test_vv1_max(self, result_default):
        result_max = result_default["vv1"].dropna().max()
        assert result_max == pytest.approx(R_REF["vv1_max"], rel=0.01)

    def test_sum_equals_original(self, result_default):
        result_sum = result_default["vv1"].dropna().sum()
        assert result_sum == pytest.approx(R_REF["original_sum"], rel=0.01)


# ── value correctness tests ──────────────────────────────────────────
class TestValues:

    def test_sum_preserved(self, pointz, result_default):
        """Default aggregation is sum — total should be preserved
        across polygons that contain points."""
        original_sum = pointz["vv1"].sum()
        result_sum = result_default["vv1"].dropna().sum()
        assert result_sum == pytest.approx(original_sum, rel=0.01)

    def test_na_for_empty_polygons(self, result_default):
        """Polygons with no points should have NA (default na_val)."""
        # Some hex cells won't contain any points
        # Just check that NAs exist (not all cells have points)
        assert result_default["vv1"].isna().sum() >= 0  # could be 0 if all cells have points

    def test_no_negative_vote_counts(self, result_default):
        """Vote counts should never be negative."""
        valid = result_default["vv1"].dropna()
        assert (valid >= 0).all()


# ── na_val replacement tests ─────────────────────────────────────────
class TestNaVal:

    def test_na_replaced_with_zero(self, pointz, polyz):
        result = point2poly_simp(pointz=pointz, polyz=polyz, varz="vv1", na_val=0)
        assert result["vv1"].isna().sum() == 0

    def test_na_replaced_with_custom(self, pointz, polyz):
        result = point2poly_simp(pointz=pointz, polyz=polyz, varz="vv1", na_val=-999)
        assert (result["vv1"] == -999).sum() >= 0  # may have empty cells


# ── multiple variable tests ──────────────────────────────────────────
class TestMultiVariable:

    def test_multi_varz_funz(self, pointz, polyz):
        result = point2poly_simp(
            pointz=pointz, polyz=polyz,
            varz=[["to1", "pvs1_margin"], ["vv1"]],
            funz=[
                lambda x: float(np.nanmean(x)),
                lambda x: float(np.nansum(x)),
            ],
            na_val=[np.nan, 0],
        )
        assert "to1" in result.columns
        assert "pvs1_margin" in result.columns
        assert "vv1" in result.columns
        # vv1 should have no NAs (filled with 0)
        assert result["vv1"].isna().sum() == 0

    def test_mean_in_range(self, pointz, polyz):
        """Mean aggregation should produce values within original range."""
        result = point2poly_simp(
            pointz=pointz, polyz=polyz,
            varz="to1",
            funz=lambda x: float(np.nanmean(x)),
        )
        valid = result["to1"].dropna()
        assert valid.min() >= pointz["to1"].min() - 0.01
        assert valid.max() <= pointz["to1"].max() + 0.01

    def test_char_variable(self, pointz, polyz):
        result = point2poly_simp(
            pointz=pointz, polyz=polyz,
            varz=[["win1_pty_n"]],
            funz=[lambda x: " | ".join(x.dropna().unique().astype(str))],
            char_varz="win1_pty_n",
        )
        assert "win1_pty_n" in result.columns


# ── synthetic data tests (controlled geometry) ───────────────────────
class TestSynthetic:

    def test_simple_count(self):
        """3 points in polygon A, 1 point in polygon B, 0 in polygon C."""
        points = gpd.GeoDataFrame(
            {"val": [10, 20, 30, 40]},
            geometry=[Point(1, 1), Point(2, 2), Point(3, 3), Point(6, 6)],
            crs="EPSG:4326",
        )
        polygons = gpd.GeoDataFrame(
            {"pid": ["A", "B", "C"]},
            geometry=[box(0, 0, 4, 4), box(5, 5, 7, 7), box(10, 10, 12, 12)],
            crs="EPSG:4326",
        )
        result = point2poly_simp(pointz=points, polyz=polygons, varz="val")
        # A: sum(10,20,30)=60, B: 40, C: NA
        vals = result.set_index("pid")["val"]
        assert vals["A"] == pytest.approx(60)
        assert vals["B"] == pytest.approx(40)
        assert np.isnan(vals["C"])

    def test_custom_mean(self):
        """Test mean aggregation on synthetic data."""
        points = gpd.GeoDataFrame(
            {"val": [10.0, 20.0, 30.0]},
            geometry=[Point(1, 1), Point(2, 2), Point(3, 3)],
            crs="EPSG:4326",
        )
        polygons = gpd.GeoDataFrame(
            {"pid": ["A"]},
            geometry=[box(0, 0, 5, 5)],
            crs="EPSG:4326",
        )
        result = point2poly_simp(
            pointz=points, polyz=polygons,
            varz="val", funz=lambda x: float(np.nanmean(x)),
        )
        assert result["val"].iloc[0] == pytest.approx(20.0)


# ── error handling ───────────────────────────────────────────────────
class TestErrors:

    def test_mismatched_varz_funz_raises(self, pointz, polyz):
        with pytest.raises(ValueError, match="Length"):
            point2poly_simp(
                pointz=pointz, polyz=polyz,
                varz=[["to1"], ["vv1"]],
                funz=[lambda x: x.mean()],
            )

    def test_does_not_mutate_input(self, pointz, polyz):
        orig_cols = list(polyz.columns)
        point2poly_simp(pointz=pointz, polyz=polyz, varz="vv1")
        assert "polygon_id_" not in polyz.columns
        assert list(polyz.columns) == orig_cols