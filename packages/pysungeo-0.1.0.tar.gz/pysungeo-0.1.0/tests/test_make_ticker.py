"""
Tests for sungeo.make_ticker

Test categories:
    1. R cross-checks (first10, year2000, pre1900, boundary, single day)
    2. Structural tests (columns, types, sort order)
    3. Value sanity tests (monotonicity, date consistency)
    4. Edge cases (pre-1900 only, leap year, single day)
"""

import numpy as np
import pandas as pd
import pytest

from sungeo.make_ticker import make_ticker


# ────────────────────────────────────────────────
#  R reference values (from RStudio)
# ────────────────────────────────────────────────

R_REF = {
    "test1_first10": {
        "nrow": 10,
        "cols": ["DATE", "DATE_ALT", "TID", "YRWK", "WID", "YRMO", "MID", "YEAR"],
        "TID": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        "WID": [1, 1, 1, 1, 1, 1, 1, 2, 2, 2],
        "YRWK": [1900001] * 7 + [1900002] * 3,
        "YRMO": [190001] * 10,
        "MID": [1] * 10,
    },
    "test2_year2000": {
        "nrow": 366,
        "TID_min": 36525,
        "TID_max": 36890,
        "WID_min": 5218,
        "WID_max": 5270,
        "YRMO_nunique": 12,
        "MID_min": 1201,
        "MID_max": 1212,
    },
    "test3_pre1900": {
        "nrow": 12,
        "TID": [-11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0],
        "WID": [-1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0],
        "YRWK": [1899001] * 5 + [1899002] * 7,
        "MID": [0] * 12,
    },
    "test4_boundary": {
        "nrow": 7,
        "TID": [-3, -2, -1, 0, 1, 2, 3],
        "WID": [0, 0, 0, 0, 1, 1, 1],
        "YRWK": [1899001, 1899001, 1899001, 1899001,
                 1900001, 1900001, 1900001],
        "MID": [0, 0, 0, 0, 1, 1, 1],
        "DATE": [18991228, 18991229, 18991230, 18991231,
                 19000101, 19000102, 19000103],
    },
    "test5_single": {
        "nrow": 1,
        "TID": 43830,
        "WID": 6262,
        "YRWK": 2020001,
        "MID": 1441,
    },
}


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK TESTS
# ════════════════════════════════════════════════

class TestRCrossCheckFirst10:
    """First 10 days of 1900."""

    @pytest.fixture(scope="class")
    def t(self):
        return make_ticker(19000101, 19000110)

    def test_nrow(self, t):
        assert len(t) == R_REF["test1_first10"]["nrow"]

    def test_columns(self, t):
        assert list(t.columns) == R_REF["test1_first10"]["cols"]

    def test_tid(self, t):
        assert t["TID"].tolist() == R_REF["test1_first10"]["TID"]

    def test_wid(self, t):
        assert t["WID"].tolist() == R_REF["test1_first10"]["WID"]

    def test_yrwk(self, t):
        assert t["YRWK"].tolist() == R_REF["test1_first10"]["YRWK"]

    def test_yrmo(self, t):
        assert t["YRMO"].tolist() == R_REF["test1_first10"]["YRMO"]

    def test_mid(self, t):
        assert t["MID"].tolist() == R_REF["test1_first10"]["MID"]


class TestRCrossCheckYear2000:
    """Full year 2000 (leap year)."""

    @pytest.fixture(scope="class")
    def t(self):
        return make_ticker(20000101, 20001231)

    def test_nrow(self, t):
        assert len(t) == R_REF["test2_year2000"]["nrow"]

    def test_tid_min(self, t):
        assert t["TID"].min() == R_REF["test2_year2000"]["TID_min"]

    def test_tid_max(self, t):
        assert t["TID"].max() == R_REF["test2_year2000"]["TID_max"]

    def test_wid_min(self, t):
        assert t["WID"].min() == R_REF["test2_year2000"]["WID_min"]

    def test_wid_max(self, t):
        assert t["WID"].max() == R_REF["test2_year2000"]["WID_max"]

    def test_yrmo_nunique(self, t):
        assert t["YRMO"].nunique() == R_REF["test2_year2000"]["YRMO_nunique"]

    def test_mid_min(self, t):
        assert t["MID"].min() == R_REF["test2_year2000"]["MID_min"]

    def test_mid_max(self, t):
        assert t["MID"].max() == R_REF["test2_year2000"]["MID_max"]


class TestRCrossCheckPre1900:
    """Last 12 days of 1899 (pre-1900 negative IDs)."""

    @pytest.fixture(scope="class")
    def t(self):
        return make_ticker(18991220, 18991231)

    def test_nrow(self, t):
        assert len(t) == R_REF["test3_pre1900"]["nrow"]

    def test_tid(self, t):
        assert t["TID"].tolist() == R_REF["test3_pre1900"]["TID"]

    def test_wid(self, t):
        assert t["WID"].tolist() == R_REF["test3_pre1900"]["WID"]

    def test_yrwk(self, t):
        assert t["YRWK"].tolist() == R_REF["test3_pre1900"]["YRWK"]

    def test_mid(self, t):
        assert t["MID"].tolist() == R_REF["test3_pre1900"]["MID"]


class TestRCrossCheckBoundary:
    """Spanning the 1900 boundary."""

    @pytest.fixture(scope="class")
    def t(self):
        return make_ticker(18991228, 19000103)

    def test_nrow(self, t):
        assert len(t) == R_REF["test4_boundary"]["nrow"]

    def test_date(self, t):
        assert t["DATE"].tolist() == R_REF["test4_boundary"]["DATE"]

    def test_tid(self, t):
        assert t["TID"].tolist() == R_REF["test4_boundary"]["TID"]

    def test_wid(self, t):
        assert t["WID"].tolist() == R_REF["test4_boundary"]["WID"]

    def test_yrwk(self, t):
        assert t["YRWK"].tolist() == R_REF["test4_boundary"]["YRWK"]

    def test_mid(self, t):
        assert t["MID"].tolist() == R_REF["test4_boundary"]["MID"]


class TestRCrossCheckSingleDay:
    """Single day: Jan 1, 2020."""

    @pytest.fixture(scope="class")
    def t(self):
        return make_ticker(20200101, 20200101)

    def test_nrow(self, t):
        assert len(t) == R_REF["test5_single"]["nrow"]

    def test_tid(self, t):
        assert t["TID"].iloc[0] == R_REF["test5_single"]["TID"]

    def test_wid(self, t):
        assert t["WID"].iloc[0] == R_REF["test5_single"]["WID"]

    def test_yrwk(self, t):
        assert t["YRWK"].iloc[0] == R_REF["test5_single"]["YRWK"]

    def test_mid(self, t):
        assert t["MID"].iloc[0] == R_REF["test5_single"]["MID"]


# ════════════════════════════════════════════════
#  2. STRUCTURAL TESTS
# ════════════════════════════════════════════════

class TestStructural:
    def test_columns_present(self):
        t = make_ticker(20200101, 20200110)
        expected = ["DATE", "DATE_ALT", "TID", "YRWK", "WID", "YRMO", "MID", "YEAR"]
        assert list(t.columns) == expected

    def test_returns_dataframe(self):
        t = make_ticker(20200101, 20200110)
        assert isinstance(t, pd.DataFrame)

    def test_date_column_int(self):
        t = make_ticker(20200101, 20200110)
        assert t["DATE"].dtype in [np.int64, np.int32, int]

    def test_tid_column_int(self):
        t = make_ticker(20200101, 20200110)
        assert t["TID"].dtype in [np.int64, np.int32, int]

    def test_sorted_by_tid(self):
        t = make_ticker(20190601, 20200301)
        assert (t["TID"].diff().dropna() > 0).all()

    def test_default_date_max_is_today(self):
        from datetime import date
        t = make_ticker(20260101)
        last_date = t["DATE"].iloc[-1]
        today = int(date.today().strftime("%Y%m%d"))
        assert last_date == today


# ════════════════════════════════════════════════
#  3. VALUE SANITY TESTS
# ════════════════════════════════════════════════

class TestValueSanity:
    def test_tid_monotonic(self):
        t = make_ticker(19500101, 19500131)
        assert t["TID"].is_monotonic_increasing

    def test_wid_non_decreasing(self):
        t = make_ticker(19500101, 19500228)
        assert (t["WID"].diff().dropna() >= 0).all()

    def test_mid_non_decreasing(self):
        t = make_ticker(19500101, 19500301)
        assert (t["MID"].diff().dropna() >= 0).all()

    def test_year_from_date(self):
        t = make_ticker(20100601, 20100630)
        assert (t["YEAR"] == 2010).all()

    def test_yrmo_format(self):
        t = make_ticker(20200301, 20200315)
        assert (t["YRMO"] == 202003).all()

    def test_date_range_matches_request(self):
        t = make_ticker(20200101, 20200110)
        assert t["DATE"].iloc[0] == 20200101
        assert t["DATE"].iloc[-1] == 20200110

    def test_no_duplicate_dates(self):
        t = make_ticker(20000101, 20001231)
        assert t["DATE"].is_unique

    def test_consecutive_days(self):
        t = make_ticker(20200101, 20200131)
        date_alt = pd.to_datetime(t["DATE_ALT"])
        diffs = date_alt.diff().dropna()
        assert (diffs == pd.Timedelta(days=1)).all()

    def test_pre1900_tid_ends_at_zero(self):
        t = make_ticker(18990101, 18991231)
        assert t["TID"].iloc[-1] == 0

    def test_post1900_tid_starts_at_one(self):
        t = make_ticker(19000101, 19000105)
        assert t["TID"].iloc[0] == 1


# ════════════════════════════════════════════════
#  4. EDGE CASES
# ════════════════════════════════════════════════

class TestEdgeCases:
    def test_single_day_post1900(self):
        t = make_ticker(19500601, 19500601)
        assert len(t) == 1

    def test_single_day_pre1900(self):
        t = make_ticker(18500101, 18500101)
        assert len(t) == 1

    def test_leap_year_feb29(self):
        t = make_ticker(20000228, 20000301)
        assert len(t) == 3  # Feb 28, Feb 29, Mar 1
        assert 20000229 in t["DATE"].values

    def test_entirely_pre1900(self):
        t = make_ticker(18500101, 18501231)
        assert len(t) == 365
        assert (t["TID"] <= 0).all()
        assert (t["YEAR"] == 1850).all()

    def test_full_year_row_count(self):
        # 2023 is not a leap year → 365 days
        t = make_ticker(20230101, 20231231)
        assert len(t) == 365

    def test_full_leap_year_row_count(self):
        # 2024 is a leap year → 366 days
        t = make_ticker(20240101, 20241231)
        assert len(t) == 366