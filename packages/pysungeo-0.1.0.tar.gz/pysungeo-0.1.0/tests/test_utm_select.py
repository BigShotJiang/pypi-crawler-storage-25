"""Tests for sungeo.utm_select."""

import pathlib

import geopandas as gpd
import numpy as np
import pytest

from sungeo.utm_select import utm_select

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


# ── fixtures ─────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def hex_gdf():
    """Load hexagonal grid over Germany."""
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def clea_gdf():
    """Load German electoral districts."""
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


# ── test: correct UTM zone is picked ────────────────────────────────
class TestProjectionChoice:

    def test_hex_picks_utm_zone_32(self, hex_gdf):
        """Germany spans UTM zones 32-33. Median should be zone 32."""
        result = utm_select(hex_gdf, return_list=True)
        assert "+proj=utm" in result["proj_out"]
        assert "+zone=32" in result["proj_out"]

    def test_clea_picks_utm_zone_32(self, clea_gdf):
        result = utm_select(clea_gdf, return_list=True)
        assert "+proj=utm" in result["proj_out"]
        assert "+zone=32" in result["proj_out"]

    def test_wide_bbox_picks_albers(self):
        """A GeoDataFrame spanning many UTM zones should fall back to Albers."""
        from shapely.geometry import box
        # Span from -30 to 60 longitude (covers ~15 UTM zones)
        wide_poly = gpd.GeoDataFrame(
            geometry=[box(-30, 40, 60, 60)],
            crs="EPSG:4326",
        )
        result = utm_select(wide_poly, max_zones=5, return_list=True)
        assert "+proj=aea" in result["proj_out"]


# ── test: output properties ──────────────────────────────────────────
class TestOutputProperties:

    def test_returns_geodataframe(self, hex_gdf):
        result = utm_select(hex_gdf)
        assert isinstance(result, gpd.GeoDataFrame)

    def test_same_row_count(self, hex_gdf):
        result = utm_select(hex_gdf)
        assert len(result) == len(hex_gdf)

    def test_crs_is_projected(self, hex_gdf):
        """Output CRS should use metres, not degrees."""
        result = utm_select(hex_gdf)
        assert result.crs.is_projected

    def test_return_list_has_both_keys(self, hex_gdf):
        result = utm_select(hex_gdf, return_list=True)
        assert "x_out" in result
        assert "proj_out" in result
        assert isinstance(result["x_out"], gpd.GeoDataFrame)
        assert isinstance(result["proj_out"], str)

    def test_columns_preserved(self, hex_gdf):
        """Reprojection should not add or drop columns."""
        result = utm_select(hex_gdf)
        assert list(result.columns) == list(hex_gdf.columns)


# ── test: edge cases ─────────────────────────────────────────────────
class TestEdgeCases:

    def test_invalid_input_type(self):
        with pytest.raises(TypeError):
            utm_select("not_a_geodataframe")

    def test_max_zones_1_forces_albers(self, hex_gdf):
        """With max_zones=1, Germany (2 zones) should use Albers."""
        result = utm_select(hex_gdf, max_zones=1, return_list=True)
        assert "+proj=aea" in result["proj_out"]