"""Tests for sungeo.nesting against R reference output.

Reference values were generated in R using:
    nesting(poly_from=clea_deu2009, poly_to=hex_05_deu, metrix="all")
"""

import pathlib

import geopandas as gpd
import numpy as np
import pytest

from sungeo.nesting import nesting

# ── R reference values (clea_deu2009 → hex_05_deu) ──────────────────
EXPECTED = {
    "rs": 0.0252,
    "rn": 0.1596,
    "rs_sym": -0.9496,
    "rn_sym": -0.5107,
    "rs_alt": -19.2234,
    "rn_alt": 0.1987,
    "rs_nn": 0.0252,
    "rn_nn": 0.1596,
    "p_intact": 0,
    "full_nest": 0,
    "ro": -0.1752,
    "gmi": 0.8404,
}

# R reference values for additional coverage tests
R_REF_EXTRA = {
    "by_unit": {
        "n_keys": 13,
        "key_names": [
            "rs", "rn", "rs_sym", "rn_sym", "rs_alt", "rn_alt",
            "rs_nn", "rn_nn", "p_intact", "full_nest", "ro", "gmi", "by_unit",
        ],
        "has_by_unit_df": True,
        "rs_value": 0.02521,
        "rn_value": 0.159611,
        "p_intact_value": 0,
    },
    "specific_metrics": {
        "n_keys": 4,
        "key_names": ["rs_nn", "rn_nn", "gmi", "ro"],
        "rs_nn": 0.02521,
        "rn_nn": 0.159611,
        "gmi": 0.840389,
        "ro": -0.175176,
    },
}

# ── path to bundled sample data ──────────────────────────────────────
DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


# ── fixtures: loaded once per file, shared across all tests ──────────
@pytest.fixture(scope="module")
def poly_from():
    """Load German electoral districts (source layer)."""
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


@pytest.fixture(scope="module")
def poly_to():
    """Load hexagonal grid over Germany (destination layer)."""
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def result(poly_from, poly_to):
    """Run nesting() once with all metrics."""
    return nesting(poly_from, poly_to, metrix="all")


# ── main test: compare each metric against R reference ───────────────
class TestNestingMetrics:
    """Compare every metric against R reference values."""

    TOLERANCE = 0.01

    @pytest.mark.parametrize("metric", list(EXPECTED.keys()))
    def test_metric(self, result, metric):
        assert metric in result, f"Missing metric: {metric}"
        assert result[metric] == pytest.approx(
            EXPECTED[metric], abs=self.TOLERANCE
        ), f"{metric}: got {result[metric]}, expected {EXPECTED[metric]}"


# ── additional tests ─────────────────────────────────────────────────
class TestNestingBehavior:
    def test_returns_all_12_metrics(self, result):
        metrics_only = [k for k in result if k != "by_unit"]
        assert len(metrics_only) == 12

    def test_single_metric(self, poly_from, poly_to):
        out = nesting(poly_from, poly_to, metrix="rn")
        assert list(out.keys()) == ["rn"]
        assert out["rn"] == pytest.approx(EXPECTED["rn"], abs=0.01)

    def test_multiple_metrics(self, poly_from, poly_to):
        out = nesting(poly_from, poly_to, metrix=["rs", "rn"])
        assert set(out.keys()) == {"rs", "rn"}

    def test_by_unit_returns_dataframe(self, poly_from, poly_to):
        out = nesting(poly_from, poly_to, metrix="rn", by_unit=True)
        assert "by_unit" in out
        assert len(out["by_unit"]) == len(poly_from)

    def test_invalid_input_raises(self):
        with pytest.raises(ValueError):
            nesting(None, None)


# ── additional coverage tests ────────────────────────────────────────

class TestNestingByUnit:
    """by_unit=TRUE returns per-source-unit breakdown alongside global metrics.
    Covers nesting.py lines 205-209, 238-244, 260-266."""

    @pytest.fixture(scope="class")
    def by_unit_result(self, poly_from, poly_to):
        return nesting(poly_from, poly_to, metrix="all", by_unit=True)

    def test_n_keys(self, by_unit_result):
        ref = R_REF_EXTRA["by_unit"]
        assert len(by_unit_result) == ref["n_keys"]

    def test_key_names(self, by_unit_result):
        ref = R_REF_EXTRA["by_unit"]
        assert set(by_unit_result.keys()) == set(ref["key_names"])

    def test_has_by_unit_dataframe(self, by_unit_result):
        assert "by_unit" in by_unit_result
        import pandas as pd
        assert isinstance(by_unit_result["by_unit"], pd.DataFrame)
        assert len(by_unit_result["by_unit"]) > 0

    def test_rs_value(self, by_unit_result):
        ref = R_REF_EXTRA["by_unit"]
        assert by_unit_result["rs"] == pytest.approx(ref["rs_value"], abs=0.01)

    def test_rn_value(self, by_unit_result):
        ref = R_REF_EXTRA["by_unit"]
        assert by_unit_result["rn"] == pytest.approx(ref["rn_value"], abs=0.01)

    def test_p_intact_value(self, by_unit_result):
        ref = R_REF_EXTRA["by_unit"]
        assert by_unit_result["p_intact"] == pytest.approx(ref["p_intact_value"], abs=0.01)

    def test_global_metrics_unchanged(self, by_unit_result):
        """by_unit=True should not change the global metric values."""
        for metric, expected_val in EXPECTED.items():
            assert by_unit_result[metric] == pytest.approx(
                expected_val, abs=0.01
            ), f"{metric}: got {by_unit_result[metric]}, expected {expected_val}"


class TestNestingSpecificMetrics:
    """Request only specific metrics instead of 'all'.
    Covers nesting.py lines 149-153, 196, 216, 258, 273, 282."""

    @pytest.fixture(scope="class")
    def specific_result(self, poly_from, poly_to):
        return nesting(
            poly_from, poly_to,
            metrix=["rs_nn", "rn_nn", "gmi", "ro"],
        )

    def test_n_keys(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert len(specific_result) == ref["n_keys"]

    def test_only_requested_keys(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert set(specific_result.keys()) == set(ref["key_names"])

    def test_rs_nn(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert specific_result["rs_nn"] == pytest.approx(ref["rs_nn"], abs=0.01)

    def test_rn_nn(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert specific_result["rn_nn"] == pytest.approx(ref["rn_nn"], abs=0.01)

    def test_gmi(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert specific_result["gmi"] == pytest.approx(ref["gmi"], abs=0.01)

    def test_ro(self, specific_result):
        ref = R_REF_EXTRA["specific_metrics"]
        assert specific_result["ro"] == pytest.approx(ref["ro"], abs=0.01)

    def test_unrequested_metrics_absent(self, specific_result):
        """Metrics not requested should not be in the result."""
        assert "rs" not in specific_result
        assert "rn" not in specific_result
        assert "rs_sym" not in specific_result