"""
Grand Integration Test — End-to-End Pipeline Validation

Verifies that multiple SUNGEO functions chain together correctly
and produce output equivalent to R.

Known pre-existing bugs discovered by this test:
    - point2poly_tess: KeyError when pointz and polyz share column names
      (overlay renames 'to1' → 'to1_1', then poly2poly_ap can't find 'to1')
    - line2poly: crashes when polyz is already projected (utm_select expects
      geographic CRS but receives meter coordinates)

Pipelines:
    1. poly2poly_ap → hot_spot
    2. point2poly_simp → hot_spot
    3. sf2raster round-trip
    4. nesting
    5. point2poly_krige
    6. line2poly (using unprojected data so internal reproject works)
    7. get_info
    8. Utility chain (make_ticker → merge_list → smart_round)
    9. df2sf → utm_select
    10. Cross-pipeline consistency (simp vs krige)
"""

from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import geopandas as gpd

from sungeo.utm_select import utm_select
from sungeo.df2sf import df2sf
from sungeo.poly2poly_ap import poly2poly_ap
from sungeo.point2poly_simp import point2poly_simp
from sungeo.point2poly_krige import point2poly_krige
from sungeo.hot_spot import hot_spot
from sungeo.sf2raster import sf2raster
from sungeo.nesting import nesting
from sungeo.line2poly import line2poly
from sungeo.get_info import get_info
from sungeo.make_ticker import make_ticker
from sungeo.merge_list import merge_list
from sungeo.smart_round import smart_round
from sungeo.fix_geom import fix_geom

# ────────────────────────────────────────────────
#  R reference values
# ────────────────────────────────────────────────

R_REF = {
    "pipeline1_poly_ap_hot": {
        "ap_nrow": 257,
        "ap_aw_mean": 0.699015,
        "hot_nrow": 257,
    },
    "pipeline3_raster_roundtrip": {
        "fwd_nrow": 50,
        "fwd_ncol": 50,
        "rev_nrow": 16,
        "rev_to1_mean": 0.696887,
        "rev_to1_min": 0.604721,
        "rev_to1_max": 0.7376,
    },
    "pipeline5_krige": {
        "krige_nrow": 16,
        "krige_pred_mean": 0.700837,
        "krige_pred_min": 0.622256,
        "krige_pred_max": 0.736553,
    },
    "pipeline7_get_info": {
        "n_topics": 14,
        "n_geosets": 6,
    },
}

# ────────────────────────────────────────────────
#  Data fixtures
# ────────────────────────────────────────────────

DATA_DIR = Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


@pytest.fixture(scope="module")
def clea():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


@pytest.fixture(scope="module")
def clea_pt():
    return gpd.read_file(DATA_DIR / "clea_deu2009_pt.gpkg")


@pytest.fixture(scope="module")
def hex_deu():
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def highways():
    return gpd.read_file(DATA_DIR / "highways_deu1992.gpkg")


@pytest.fixture(scope="module")
def poly_proj(clea):
    return utm_select(clea)


@pytest.fixture(scope="module")
def pt_proj(clea_pt):
    return utm_select(clea_pt)


@pytest.fixture(scope="module")
def hex_proj(hex_deu):
    return utm_select(hex_deu)


# ════════════════════════════════════════════════
#  Pipeline 1: poly2poly_ap → hot_spot
# ════════════════════════════════════════════════

class TestPipeline1PolyApHotSpot:

    @pytest.fixture(scope="class")
    def ap_result(self, poly_proj, hex_proj):
        return poly2poly_ap(
            poly_from=poly_proj,
            poly_to=hex_proj,
            poly_to_id="HEX_ID",
            varz="to1",
        )

    @pytest.fixture(scope="class")
    def to1_col(self, ap_result):
        """Find the to1-derived output column (may be 'to1.MEAN' or 'to1_aw')."""
        candidates = [c for c in ap_result.columns
                      if "to1" in c and c != "to1"]
        assert len(candidates) > 0, f"No to1 output column found in {list(ap_result.columns)}"
        return candidates[0]

    @pytest.fixture(scope="class")
    def hot_result(self, ap_result, to1_col):
        return hot_spot(insert=ap_result, variable=to1_col)

    def test_ap_nrow(self, ap_result):
        assert len(ap_result) == R_REF["pipeline1_poly_ap_hot"]["ap_nrow"]

    def test_ap_has_to1_column(self, to1_col):
        assert to1_col is not None

    def test_ap_mean_value(self, ap_result, to1_col):
        assert ap_result[to1_col].mean() == pytest.approx(
            R_REF["pipeline1_poly_ap_hot"]["ap_aw_mean"], abs=0.01
        )

    def test_ap_is_geodataframe(self, ap_result):
        assert isinstance(ap_result, gpd.GeoDataFrame)

    def test_hot_nrow(self, hot_result):
        assert len(hot_result) == R_REF["pipeline1_poly_ap_hot"]["hot_nrow"]

    def test_hot_has_gi(self, hot_result):
        gi_cols = [c for c in hot_result.columns if "Gi" in c or "LocalG" in c]
        assert len(gi_cols) > 0

    def test_hot_preserves_geometry(self, hot_result):
        assert hot_result.geometry is not None

    def test_hot_is_geodataframe(self, hot_result):
        assert isinstance(hot_result, gpd.GeoDataFrame)


# ════════════════════════════════════════════════
#  Pipeline 2: point2poly_simp → hot_spot
#
#  NOTE: We use point2poly_simp here instead of point2poly_tess because
#  tess has a known pre-existing bug: when pointz and polyz share column
#  names, the internal overlay renames 'to1' to 'to1_1', then poly2poly_ap
#  tries to aggregate 'to1' which no longer exists (KeyError).
# ════════════════════════════════════════════════

class TestPipeline2SimpHotSpot:

    @pytest.fixture(scope="class")
    def simp_result(self, clea_pt, clea):
        return point2poly_simp(
            pointz=clea_pt,
            polyz=clea,
            varz="to1",
        )

    @pytest.fixture(scope="class")
    def simp_to1_col(self, simp_result):
        candidates = [c for c in simp_result.columns
                      if "to1" in c and c != "to1"]
        assert len(candidates) > 0
        return candidates[0]

    @pytest.fixture(scope="class")
    def hot_result(self, simp_result, simp_to1_col):
        return hot_spot(insert=simp_result, variable=simp_to1_col)

    def test_simp_nrow(self, simp_result):
        assert len(simp_result) == 16

    def test_simp_has_output_cols(self, simp_to1_col):
        assert simp_to1_col is not None

    def test_simp_is_geodataframe(self, simp_result):
        assert isinstance(simp_result, gpd.GeoDataFrame)

    def test_hot_nrow(self, hot_result):
        assert len(hot_result) == 16

    def test_hot_has_gi(self, hot_result):
        gi_cols = [c for c in hot_result.columns if "Gi" in c or "LocalG" in c]
        assert len(gi_cols) > 0

    def test_chain_preserves_crs(self, simp_result, hot_result):
        assert simp_result.crs == hot_result.crs


# ════════════════════════════════════════════════
#  Pipeline 3: sf2raster round-trip
# ════════════════════════════════════════════════

class TestPipeline3RasterRoundTrip:

    @pytest.fixture(scope="class")
    def fwd_result(self, poly_proj):
        return sf2raster(
            polyz_from=poly_proj,
            input_variable="to1",
            grid_dim=(50, 50),
            return_list=True,
            message_out=False,
        )

    @pytest.fixture(scope="class")
    def rev_result(self, fwd_result):
        return sf2raster(
            reverse=True,
            poly_to=fwd_result["poly_to"],
            return_output=fwd_result["return_output"],
            return_field=fwd_result["return_field"],
            message_out=False,
        )

    def test_fwd_shape(self, fwd_result):
        ref = R_REF["pipeline3_raster_roundtrip"]
        data = fwd_result["return_output"]["data"]
        assert data.shape == (ref["fwd_nrow"], ref["fwd_ncol"])

    def test_rev_nrow(self, rev_result):
        assert len(rev_result) == R_REF["pipeline3_raster_roundtrip"]["rev_nrow"]

    def test_rev_has_to1(self, rev_result):
        assert "to1" in rev_result.columns

    def test_rev_to1_mean(self, rev_result):
        ref = R_REF["pipeline3_raster_roundtrip"]
        assert rev_result["to1"].mean() == pytest.approx(ref["rev_to1_mean"], abs=0.01)

    def test_rev_to1_min(self, rev_result):
        ref = R_REF["pipeline3_raster_roundtrip"]
        assert rev_result["to1"].min() == pytest.approx(ref["rev_to1_min"], abs=0.01)

    def test_rev_to1_max(self, rev_result):
        ref = R_REF["pipeline3_raster_roundtrip"]
        assert rev_result["to1"].max() == pytest.approx(ref["rev_to1_max"], abs=0.01)

    def test_rev_is_geodataframe(self, rev_result):
        assert isinstance(rev_result, gpd.GeoDataFrame)

    def test_roundtrip_no_na(self, rev_result):
        assert rev_result["to1"].isna().sum() == 0


# ════════════════════════════════════════════════
#  Pipeline 4: nesting
# ════════════════════════════════════════════════

class TestPipeline4Nesting:

    @pytest.fixture(scope="class")
    def nest_result(self, poly_proj, hex_proj):
        return nesting(
            poly_from=poly_proj,
            poly_to=hex_proj,
        )

    def test_returns_dict(self, nest_result):
        assert isinstance(nest_result, dict)

    def test_has_keys(self, nest_result):
        assert len(nest_result) > 0

    def test_has_nesting_values(self, nest_result):
        # Check that at least some metric was computed
        all_keys = " ".join(str(k) for k in nest_result.keys())
        assert len(all_keys) > 0


# ════════════════════════════════════════════════
#  Pipeline 5: point2poly_krige
# ════════════════════════════════════════════════

class TestPipeline5Krige:

    @pytest.fixture(scope="class")
    def krige_result(self, clea_pt, clea):
        return point2poly_krige(
            pointz=clea_pt,
            polyz=clea,
            yvarz="to1",
        )

    def test_nrow(self, krige_result):
        assert len(krige_result) == R_REF["pipeline5_krige"]["krige_nrow"]

    def test_has_pred(self, krige_result):
        assert "to1.pred" in krige_result.columns

    def test_has_var(self, krige_result):
        assert "to1.var" in krige_result.columns

    def test_has_stdev(self, krige_result):
        assert "to1.stdev" in krige_result.columns

    def test_pred_mean(self, krige_result):
        ref = R_REF["pipeline5_krige"]
        assert krige_result["to1.pred"].mean() == pytest.approx(
            ref["krige_pred_mean"], abs=0.05
        )

    def test_pred_range(self, krige_result):
        ref = R_REF["pipeline5_krige"]
        assert krige_result["to1.pred"].min() == pytest.approx(
            ref["krige_pred_min"], abs=0.10
        )
        assert krige_result["to1.pred"].max() == pytest.approx(
            ref["krige_pred_max"], abs=0.10
        )

    def test_is_geodataframe(self, krige_result):
        assert isinstance(krige_result, gpd.GeoDataFrame)

    def test_variance_positive(self, krige_result):
        assert (krige_result["to1.var"] > 0).all()


# ════════════════════════════════════════════════
#  Pipeline 6: line2poly
#
#  NOTE: We use unprojected data here because line2poly internally calls
#  utm_select(polyz). If polyz is already projected, utm_select receives
#  meter coordinates instead of degrees, finds no matching UTM zones,
#  and crashes with NaN. This is a pre-existing bug in line2poly: it
#  should detect already-projected input and skip reprojection.
# ════════════════════════════════════════════════

class TestPipeline6Line2Poly:

    @pytest.fixture(scope="class")
    def line_result(self, highways, clea):
        return line2poly(
            linez=highways,
            polyz=clea,
            poly_id="cst_n",
        )

    def test_returns_geodataframe(self, line_result):
        assert isinstance(line_result, gpd.GeoDataFrame)

    def test_nrow_matches_polyz(self, line_result, clea):
        assert len(line_result) == len(clea)

    def test_has_length(self, line_result):
        length_cols = [c for c in line_result.columns if "length" in c.lower()]
        assert len(length_cols) > 0

    def test_has_distance(self, line_result):
        dist_cols = [c for c in line_result.columns if "distance" in c.lower()]
        assert len(dist_cols) > 0

    def test_has_density(self, line_result):
        dens_cols = [c for c in line_result.columns if "density" in c.lower()]
        assert len(dens_cols) > 0

    def test_preserves_geometry(self, line_result):
        assert line_result.geometry is not None


# ════════════════════════════════════════════════
#  Pipeline 7: get_info
# ════════════════════════════════════════════════

class TestPipeline7GetInfo:

    @pytest.fixture(scope="class")
    def info_result(self):
        return get_info(country_names="Afghanistan")

    def test_has_summary(self, info_result):
        assert "summary" in info_result

    def test_has_topics(self, info_result):
        assert "topics" in info_result

    def test_has_geosets(self, info_result):
        assert "geosets" in info_result

    def test_n_topics(self, info_result):
        assert len(info_result["topics"]) == R_REF["pipeline7_get_info"]["n_topics"]

    def test_n_geosets(self, info_result):
        assert len(info_result["geosets"]) == R_REF["pipeline7_get_info"]["n_geosets"]


# ════════════════════════════════════════════════
#  Pipeline 8: Utility chain (make_ticker → merge_list → smart_round)
# ════════════════════════════════════════════════

class TestPipeline8UtilityChain:

    def test_ticker_merge_round(self):
        t = make_ticker(20200101, 20200131)
        df_a = pd.DataFrame({
            "YEAR": t["YEAR"].unique().tolist(),
            "metric_a": [42.123456],
        })
        df_b = pd.DataFrame({
            "YEAR": t["YEAR"].unique().tolist(),
            "metric_b": [0.000789],
        })

        merged = merge_list([df_a, df_b])
        assert "metric_a" in merged.columns
        assert "metric_b" in merged.columns
        assert len(merged) == 1

        rounded_a = smart_round(merged["metric_a"].tolist(), rnd=2)
        rounded_b = smart_round(merged["metric_b"].tolist(), rnd=2)
        assert rounded_a == ["42.12"]
        # 0.000789 → signif(1)=0.0008 → cleanup round(0.0008,3)=0.001
        assert rounded_b == ["0.001"]

    def test_ticker_has_expected_days(self):
        t = make_ticker(20200101, 20200131)
        assert len(t) == 31

    def test_merge_three_dataframes(self):
        df1 = pd.DataFrame({"key": [1, 2], "a": [10, 20]})
        df2 = pd.DataFrame({"key": [1, 2], "b": [30, 40]})
        df3 = pd.DataFrame({"key": [1, 2], "c": [50, 60]})
        result = merge_list([df1, df2, df3])
        assert set(result.columns) == {"key", "a", "b", "c"}
        assert len(result) == 2


# ════════════════════════════════════════════════
#  Pipeline 9: df2sf → utm_select chain
# ════════════════════════════════════════════════

class TestPipeline9Df2sfUtmSelect:

    def test_coords_to_projected(self):
        df = pd.DataFrame({
            "lon": [10.0, 11.0, 12.0],
            "lat": [50.0, 51.0, 52.0],
            "value": [1, 2, 3],
        })
        gdf = df2sf(x_coord="lon", y_coord="lat", input_data=df)
        assert isinstance(gdf, gpd.GeoDataFrame)
        assert gdf.crs is not None

        projected = utm_select(gdf)
        assert projected.crs.is_projected
        assert len(projected) == 3
        assert "value" in projected.columns

    def test_preserves_data(self):
        df = pd.DataFrame({
            "x": [9.0, 10.0],
            "y": [48.0, 49.0],
            "name": ["Munich", "Nuremberg"],
        })
        gdf = df2sf(x_coord="x", y_coord="y", input_data=df)
        projected = utm_select(gdf)
        assert list(projected["name"]) == ["Munich", "Nuremberg"]


# ════════════════════════════════════════════════
#  Pipeline 10: Cross-pipeline consistency
#  (point2poly_simp vs point2poly_krige on same data)
# ════════════════════════════════════════════════

class TestPipeline10CrossConsistency:

    @pytest.fixture(scope="class")
    def simp_result(self, clea_pt, clea):
        return point2poly_simp(
            pointz=clea_pt,
            polyz=clea,
            varz="to1",
        )

    @pytest.fixture(scope="class")
    def krige_result(self, clea_pt, clea):
        return point2poly_krige(
            pointz=clea_pt,
            polyz=clea,
            yvarz="to1",
        )

    def test_both_have_16_rows(self, simp_result, krige_result):
        assert len(simp_result) == 16
        assert len(krige_result) == 16

    def test_both_are_geodataframes(self, simp_result, krige_result):
        assert isinstance(simp_result, gpd.GeoDataFrame)
        assert isinstance(krige_result, gpd.GeoDataFrame)

    def test_krige_mean_in_turnout_range(self, krige_result):
        mean_val = krige_result["to1.pred"].mean()
        assert 0.5 < mean_val < 0.9

    def test_simp_has_to1_columns(self, simp_result):
        to1_cols = [c for c in simp_result.columns if "to1" in c]
        assert len(to1_cols) > 0

    def test_fix_geom_preserves_valid(self, clea):
        fixed = fix_geom(clea)
        assert len(fixed) == len(clea)
        assert isinstance(fixed, gpd.GeoDataFrame)

    def test_three_methods_same_polygon_count(self, simp_result, krige_result):
        """Both interpolation methods operate on the same 16 polygons."""
        assert len(simp_result) == len(krige_result) == 16