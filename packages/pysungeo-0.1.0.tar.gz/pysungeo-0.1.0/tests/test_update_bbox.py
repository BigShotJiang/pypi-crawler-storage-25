"""Tests for sungeo.update_bbox."""

import pathlib

import geopandas as gpd
import numpy as np
import pytest

from sungeo.update_bbox import update_bbox

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


@pytest.fixture(scope="module")
def clea_gdf():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


class TestUpdateBbox:

    def test_subset_bounds_match_geometry(self, clea_gdf):
        """After subsetting to Berlin, bounds should shrink to Berlin's extent."""
        berlin = clea_gdf[clea_gdf["cst_n"].str.contains("Berlin", na=False)].copy()
        result = update_bbox(berlin)

        # total_bounds should match the actual geometry extent
        bounds = result.total_bounds  # [xmin, ymin, xmax, ymax]
        geom_bounds = result.geometry.total_bounds

        np.testing.assert_array_almost_equal(bounds, geom_bounds)

    def test_full_dataset_unchanged(self, clea_gdf):
        """Calling on the full dataset should return identical bounds."""
        original_bounds = clea_gdf.total_bounds
        result = update_bbox(clea_gdf)
        np.testing.assert_array_almost_equal(result.total_bounds, original_bounds)

    def test_columns_preserved(self, clea_gdf):
        result = update_bbox(clea_gdf)
        assert list(result.columns) == list(clea_gdf.columns)

    def test_row_count_preserved(self, clea_gdf):
        berlin = clea_gdf[clea_gdf["cst_n"].str.contains("Berlin", na=False)].copy()
        result = update_bbox(berlin)
        assert len(result) == len(berlin)

    def test_does_not_mutate_input(self, clea_gdf):
        original_bounds = clea_gdf.total_bounds.copy()
        update_bbox(clea_gdf)
        np.testing.assert_array_almost_equal(clea_gdf.total_bounds, original_bounds)