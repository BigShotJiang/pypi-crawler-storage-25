"""Tests for sungeo.df2sf."""

import pathlib
import tempfile

import geopandas as gpd
import numpy as np
import pandas as pd
import pytest

from sungeo.df2sf import df2sf

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"


@pytest.fixture(scope="module")
def clea_df():
    return pd.read_csv(DATA_DIR / "clea_deu2009_df.csv")


class TestDf2sfFromDataFrame:

    def test_column_names(self, clea_df):
        """Pass column names as strings with input_data."""
        result = df2sf("longitude", "latitude", input_data=clea_df)
        assert isinstance(result, gpd.GeoDataFrame)
        assert len(result) == len(clea_df)

    def test_crs_is_set(self, clea_df):
        result = df2sf("longitude", "latitude", input_data=clea_df)
        assert result.crs is not None
        assert result.crs.to_epsg() == 4326

    def test_columns_preserved(self, clea_df):
        result = df2sf("longitude", "latitude", input_data=clea_df)
        for col in clea_df.columns:
            assert col in result.columns

    def test_all_points(self, clea_df):
        result = df2sf("longitude", "latitude", input_data=clea_df)
        assert all(result.geom_type == "Point")


class TestDf2sfFromVectors:

    def test_raw_arrays(self):
        x = [10.0, 11.0, 12.0]
        y = [50.0, 51.0, 52.0]
        result = df2sf(x, y)
        assert isinstance(result, gpd.GeoDataFrame)
        assert len(result) == 3

    def test_numpy_arrays(self):
        x = np.array([10.0, 11.0])
        y = np.array([50.0, 51.0])
        result = df2sf(x, y)
        assert len(result) == 2


class TestDf2sfFromCSV:

    def test_load_csv(self, clea_df):
        """Write to temp CSV, then read back via df2sf."""
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as f:
            clea_df.to_csv(f.name, index=False)
            result = df2sf("longitude", "latitude", file=f.name)
        assert isinstance(result, gpd.GeoDataFrame)
        assert len(result) == len(clea_df)


class TestDf2sfCleaning:

    def test_na_rows_removed(self):
        x = [10.0, np.nan, 12.0]
        y = [50.0, 51.0, np.nan]
        result = df2sf(x, y)
        assert len(result) == 1  # only first row survives

    def test_zero_policy(self):
        x = [10.0, 0.0, 12.0]
        y = [50.0, 51.0, 0.0]
        result = df2sf(x, y, zero_policy=True)
        assert len(result) == 1  # rows with 0 removed

    def test_zero_policy_off(self):
        x = [10.0, 0.0, 12.0]
        y = [50.0, 51.0, 0.0]
        result = df2sf(x, y, zero_policy=False)
        assert len(result) == 3  # zeros kept

    def test_show_removed(self):
        x = [10.0, np.nan, 12.0]
        y = [50.0, 51.0, np.nan]
        result = df2sf(x, y, show_removed=True)
        assert isinstance(result, dict)
        assert "Spatial_Coordinates" in result
        assert "Removed_Rows" in result
        assert len(result["Removed_Rows"]) == 2
        assert len(result["Spatial_Coordinates"]) == 1