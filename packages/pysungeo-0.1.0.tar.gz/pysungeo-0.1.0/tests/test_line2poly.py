"""Tests for sungeo.line2poly against R reference output.

Reference values generated in R using:
    line2poly(linez=highways_deu1992, polyz=hex_05_deu, poly_id="HEX_ID")

This function depends on:
    - utm_select() — reprojection to planar CRS for accurate measurements
"""

import pathlib

import geopandas as gpd
import numpy as np
import pytest

from sungeo.line2poly import line2poly

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"

# ── R reference values ───────────────────────────────────────────────
R_REF = {
    "nrow": 257,
    "has_length": True,
    "has_density": True,
    "has_distance": True,
    "length_mean": 66.05142,
    "length_min": 0.4855035,
    "length_max": 352.6726,
    "length_na_count": 59,
    "density_mean": 0.03899074,
    "distance_mean": 3.377416,
    "distance_min": 0.0,
    "distance_max": 52.11812,
    "test2_has_road_length": True,
    "test2_length_na_count": 0,
}


@pytest.fixture(scope="module")
def linez():
    return gpd.read_file(DATA_DIR / "highways_deu1992.gpkg")


@pytest.fixture(scope="module")
def polyz():
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def result_default(linez, polyz):
    """Test case 1: all three measures, default settings."""
    return line2poly(linez=linez, polyz=polyz, poly_id="HEX_ID")


# ── R cross-check: structure ─────────────────────────────────────────
class TestStructure:

    def test_row_count(self, result_default):
        assert len(result_default) == R_REF["nrow"]

    def test_returns_geodataframe(self, result_default):
        assert isinstance(result_default, gpd.GeoDataFrame)

    def test_has_length_column(self, result_default):
        assert "line_length" in result_default.columns

    def test_has_density_column(self, result_default):
        assert "line_density" in result_default.columns

    def test_has_distance_column(self, result_default):
        assert "line_distance" in result_default.columns

    def test_destination_id_preserved(self, result_default):
        assert "HEX_ID" in result_default.columns


# ── R cross-check: length values ─────────────────────────────────────
class TestLength:

    def test_mean(self, result_default):
        mean_val = result_default["line_length"].dropna().mean()
        assert mean_val == pytest.approx(R_REF["length_mean"], rel=0.05)

    def test_min(self, result_default):
        min_val = result_default["line_length"].dropna().min()
        assert min_val == pytest.approx(R_REF["length_min"], rel=0.1)

    def test_max(self, result_default):
        max_val = result_default["line_length"].dropna().max()
        assert max_val == pytest.approx(R_REF["length_max"], rel=0.05)

    def test_na_count(self, result_default):
        """59 hex cells have no highways running through them."""
        assert result_default["line_length"].isna().sum() == R_REF["length_na_count"]

    def test_no_negative_lengths(self, result_default):
        valid = result_default["line_length"].dropna()
        assert (valid >= 0).all()


# ── R cross-check: density values ────────────────────────────────────
class TestDensity:

    def test_mean(self, result_default):
        mean_val = result_default["line_density"].dropna().mean()
        assert mean_val == pytest.approx(R_REF["density_mean"], rel=0.05)

    def test_no_negative_density(self, result_default):
        valid = result_default["line_density"].dropna()
        assert (valid >= 0).all()


# ── R cross-check: distance values ───────────────────────────────────
class TestDistance:

    def test_mean(self, result_default):
        mean_val = result_default["line_distance"].mean()
        assert mean_val == pytest.approx(R_REF["distance_mean"], rel=0.1)

    def test_min(self, result_default):
        min_val = result_default["line_distance"].min()
        assert min_val == pytest.approx(R_REF["distance_min"], abs=0.5)

    def test_max(self, result_default):
        max_val = result_default["line_distance"].max()
        assert max_val == pytest.approx(R_REF["distance_max"], rel=0.1)

    def test_no_negative_distances(self, result_default):
        assert (result_default["line_distance"] >= 0).all()


# ── custom outvar_name + na_val ──────────────────────────────────────
class TestCustomOptions:

    def test_renamed_columns(self, linez, polyz):
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            outvar_name="road", na_val=0,
        )
        assert "road_length" in result.columns
        assert "road_density" in result.columns
        assert "road_distance" in result.columns

    def test_na_replaced_with_zero(self, linez, polyz):
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            outvar_name="road", na_val=0,
        )
        assert result["road_length"].isna().sum() == R_REF["test2_length_na_count"]


# ── selective measures ───────────────────────────────────────────────
class TestSelectiveMeasures:

    def test_length_only(self, linez, polyz):
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            measurez="length",
        )
        assert "line_length" in result.columns
        assert "line_distance" not in result.columns
        assert "line_density" not in result.columns

    def test_distance_only(self, linez, polyz):
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            measurez="distance",
        )
        assert "line_distance" in result.columns
        assert "line_length" not in result.columns

    def test_density_only(self, linez, polyz):
        """Density requires length + area internally."""
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            measurez="density",
        )
        assert "line_density" in result.columns
        assert "line_length" in result.columns  # needed for density
        assert "line_area" in result.columns     # needed for density
        assert "line_distance" not in result.columns


# ── density = length / area consistency ──────────────────────────────
class TestDensityConsistency:

    def test_density_equals_length_over_area(self, result_default):
        """For every row with data, density must equal length / area."""
        df = result_default.dropna(subset=["line_length", "line_area", "line_density"])
        computed_density = df["line_length"] / df["line_area"]
        np.testing.assert_allclose(
            df["line_density"].values,
            computed_density.values,
            rtol=1e-6,
        )


# ── distance never NA ───────────────────────────────────────────────
class TestDistanceCompleteness:

    def test_distance_never_na(self, result_default):
        """Every polygon has a distance to the nearest line — no NAs."""
        assert result_default["line_distance"].isna().sum() == 0


# ── unit conversion ─────────────────────────────────────────────────
class TestUnitConversion:

    def test_metres_vs_km(self, linez, polyz):
        """Values in metres should be 1000x values in km."""
        result_km = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            measurez="length", verbose=False,
        )
        result_m = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            measurez="length", unitz="m", verbose=False,
        )
        km_vals = result_km["line_length"].dropna()
        m_vals = result_m["line_length"].dropna()
        np.testing.assert_allclose(
            m_vals.values,
            km_vals.values * 1000,
            rtol=1e-6,
        )


# ── reproject=False ──────────────────────────────────────────────────
class TestNoReproject:

    def test_runs_without_error(self, linez, polyz):
        result = line2poly(
            linez=linez, polyz=polyz, poly_id="HEX_ID",
            reproject=False, verbose=False,
        )
        assert isinstance(result, gpd.GeoDataFrame)
        assert "line_length" in result.columns


# ── synthetic data: controlled geometry ──────────────────────────────
class TestSynthetic:

    def test_known_length(self):
        """A 10km horizontal line inside a square polygon."""
        from shapely.geometry import LineString, box

        # Work in a projected CRS (UTM zone 32, metres)
        line_geom = LineString([(500000, 5600000), (510000, 5600000)])  # 10,000m = 10km
        poly_geom = box(490000, 5590000, 520000, 5610000)

        lines = gpd.GeoDataFrame(
            {"lid": [1]}, geometry=[line_geom],
            crs="EPSG:32632",
        )
        polys = gpd.GeoDataFrame(
            {"pid": ["A"]}, geometry=[poly_geom],
            crs="EPSG:32632",
        )

        result = line2poly(
            linez=lines, polyz=polys, poly_id="pid",
            measurez=["length", "distance"],
            reproject=False, verbose=False,
        )
        # Length should be ~10 km
        assert result["line_length"].iloc[0] == pytest.approx(10.0, rel=0.01)
        # Distance should be 0 (line is inside polygon)
        assert result["line_distance"].iloc[0] == pytest.approx(0.0, abs=0.01)

    def test_no_overlap(self):
        """Lines and polygons don't overlap — length should be NA."""
        from shapely.geometry import LineString, box

        line_geom = LineString([(0, 0), (100, 0)])
        poly_geom = box(1000, 1000, 2000, 2000)

        lines = gpd.GeoDataFrame(
            {"lid": [1]}, geometry=[line_geom],
            crs="EPSG:32632",
        )
        polys = gpd.GeoDataFrame(
            {"pid": ["A"]}, geometry=[poly_geom],
            crs="EPSG:32632",
        )

        result = line2poly(
            linez=lines, polyz=polys, poly_id="pid",
            measurez=["length", "distance"],
            reproject=False, verbose=False,
        )
        assert np.isnan(result["line_length"].iloc[0])
        # Distance should be > 0
        assert result["line_distance"].iloc[0] > 0


# ── integration: utm_select is working ───────────────────────────────
class TestIntegration:

    def test_output_crs_matches_input(self, linez, polyz):
        """After reprojection and back, CRS should match original."""
        result = line2poly(linez=linez, polyz=polyz, poly_id="HEX_ID")
        assert result.crs == polyz.crs


# ── input safety ─────────────────────────────────────────────────────
class TestInputSafety:

    def test_does_not_mutate_polyz(self, linez, polyz):
        orig_cols = list(polyz.columns)
        line2poly(linez=linez, polyz=polyz, poly_id="HEX_ID")
        assert list(polyz.columns) == orig_cols

    def test_does_not_mutate_linez(self, linez, polyz):
        orig_cols = list(linez.columns)
        line2poly(linez=linez, polyz=polyz, poly_id="HEX_ID")
        assert list(linez.columns) == orig_cols