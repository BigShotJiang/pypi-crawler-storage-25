"""
Tests for sungeo.get_info

Test categories:
    1. R cross-check (default, by country, by topic, by both)
    2. Structural tests (return type, keys, slot types)
    3. Input normalisation (string vs list)
    4. Edge cases (unknown country, unknown topic)
"""

import pytest
import pandas as pd

from sungeo.get_info import get_info

# ────────────────────────────────────────────────
#  R reference values (from RStudio)
# ────────────────────────────────────────────────

R_REF = {
    "test1_default": {
        "summary_length": 61,
        "n_topics": 33,
        "n_geosets": 9,
        "topic_names": [
            "Elections:LowerHouse:CLEA", "Terrain:Elevation:ETOPO1",
            "Demographics:Ethnicity:EPR", "Demographics:Ethnicity:GREG",
            "Events:PoliticalViolence:ABADarfur",
            "Events:PoliticalViolence:ACLED",
            "Events:PoliticalViolence:BeissingerProtest",
            "Events:PoliticalViolence:BeissingerRiot",
            "Events:PoliticalViolence:BeissingerUkraine",
            "Events:PoliticalViolence:COCACW",
            "Events:PoliticalViolence:ESOCAfghanistanWITS",
            "Events:PoliticalViolence:ESOCIraqSIGACT",
            "Events:PoliticalViolence:ESOCIraqWITS",
            "Events:PoliticalViolence:ESOCMexicoDrugRelatedMurders",
            "Events:PoliticalViolence:ESOCMexicoHomicide",
            "Events:PoliticalViolence:ESOCPakistanBFRS",
            "Events:PoliticalViolence:ESOCPakistanWITS",
            "Events:PoliticalViolence:GED",
            "Events:PoliticalViolence:Lankina",
            "Events:PoliticalViolence:NIRI",
            "Events:PoliticalViolence:NVMS",
            "Events:PoliticalViolence:PITF",
            "Events:PoliticalViolence:SCAD",
            "Events:PoliticalViolence:yzCaucasus2000",
            "Events:PoliticalViolence:yzChechnya",
            "Events:PoliticalViolence:yzLibya",
            "Events:PoliticalViolence:yzUkraine2014",
            "Terrain:LandCover:GLCC",
            "Infrastructure:NightLights:DMSP",
            "Demographics:Population:GHS",
            "PublicHealth:Covid19:JHUCSSEC19",
            "Infrastructure:Roads:gRoads",
            "Weather:AirTemperatureAndPrecipitation:NOAA",
        ],
        "geoset_names": [
            "Geoset:GADM", "Geoset:GAUL", "Geoset:geoBoundaries",
            "Geoset:GRED", "Geoset:HEXGRID", "Geoset:MPIDR",
            "Geoset:NHGIS", "Geoset:PRIOGRID", "Geoset:SHGIS",
        ],
    },
    "test2_country": {
        "n_topics": 14,
        "n_geosets": 6,
        "topic_names": [
            "Elections:LowerHouse:CLEA", "Terrain:Elevation:ETOPO1",
            "Demographics:Ethnicity:EPR", "Demographics:Ethnicity:GREG",
            "Events:PoliticalViolence:ACLED",
            "Events:PoliticalViolence:ESOCAfghanistanWITS",
            "Events:PoliticalViolence:GED",
            "Events:PoliticalViolence:PITF",
            "Terrain:LandCover:GLCC",
            "Infrastructure:NightLights:DMSP",
            "Demographics:Population:GHS",
            "PublicHealth:Covid19:JHUCSSEC19",
            "Infrastructure:Roads:gRoads",
            "Weather:AirTemperatureAndPrecipitation:NOAA",
        ],
        "geoset_names": [
            "Geoset:GADM", "Geoset:GAUL", "Geoset:geoBoundaries",
            "Geoset:GRED", "Geoset:HEXGRID", "Geoset:PRIOGRID",
        ],
    },
    "test3_topic": {
        "n_topics": 1,
        "n_geosets": 9,
        "topic_names": ["Elections:LowerHouse:CLEA"],
    },
    "test4_both": {
        "n_topics": 1,
        "n_geosets": 6,
        "topic_names": ["Elections:LowerHouse:CLEA"],
    },
}


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK: DEFAULT (no filters)
# ════════════════════════════════════════════════

class TestRCrossCheckDefault:
    @pytest.fixture(scope="class")
    def result(self):
        return get_info()

    def test_has_summary(self, result):
        assert "summary" in result

    def test_has_topics(self, result):
        assert "topics" in result

    def test_has_geosets(self, result):
        assert "geosets" in result

    def test_n_topics(self, result):
        assert len(result["topics"]) == R_REF["test1_default"]["n_topics"]

    def test_n_geosets(self, result):
        assert len(result["geosets"]) == R_REF["test1_default"]["n_geosets"]

    def test_topic_names_match_r(self, result):
        py_names = set(result["topics"].keys())
        r_names = set(R_REF["test1_default"]["topic_names"])
        assert py_names == r_names

    def test_geoset_names_match_r(self, result):
        py_names = set(result["geosets"].keys())
        r_names = set(R_REF["test1_default"]["geoset_names"])
        assert py_names == r_names

    def test_summary_is_list_of_strings(self, result):
        assert isinstance(result["summary"], list)
        assert all(isinstance(s, str) for s in result["summary"])


# ════════════════════════════════════════════════
#  2. R CROSS-CHECK: BY COUNTRY (Afghanistan)
# ════════════════════════════════════════════════

class TestRCrossCheckCountry:
    @pytest.fixture(scope="class")
    def result(self):
        return get_info(country_names="Afghanistan")

    def test_n_topics(self, result):
        assert len(result["topics"]) == R_REF["test2_country"]["n_topics"]

    def test_n_geosets(self, result):
        assert len(result["geosets"]) == R_REF["test2_country"]["n_geosets"]

    def test_topic_names_match_r(self, result):
        py_names = set(result["topics"].keys())
        r_names = set(R_REF["test2_country"]["topic_names"])
        assert py_names == r_names

    def test_geoset_names_match_r(self, result):
        py_names = set(result["geosets"].keys())
        r_names = set(R_REF["test2_country"]["geoset_names"])
        assert py_names == r_names

    def test_all_topics_contain_afg(self, result):
        for key, df in result["topics"].items():
            assert "AFG" in df["country_iso3"].values, f"{key} missing AFG"


# ════════════════════════════════════════════════
#  3. R CROSS-CHECK: BY TOPIC (Elections:LowerHouse:CLEA)
# ════════════════════════════════════════════════

class TestRCrossCheckTopic:
    @pytest.fixture(scope="class")
    def result(self):
        return get_info(topics="Elections:LowerHouse:CLEA")

    def test_n_topics(self, result):
        assert len(result["topics"]) == R_REF["test3_topic"]["n_topics"]

    def test_n_geosets(self, result):
        assert len(result["geosets"]) == R_REF["test3_topic"]["n_geosets"]

    def test_topic_names_match_r(self, result):
        assert list(result["topics"].keys()) == R_REF["test3_topic"]["topic_names"]

    def test_topic_dataframe_has_rows(self, result):
        df = result["topics"]["Elections:LowerHouse:CLEA"]
        assert len(df) > 0

    def test_topic_df_has_country_column(self, result):
        df = result["topics"]["Elections:LowerHouse:CLEA"]
        assert "country_iso3" in df.columns


# ════════════════════════════════════════════════
#  4. R CROSS-CHECK: BY BOTH (Afghanistan + CLEA)
# ════════════════════════════════════════════════

class TestRCrossCheckBoth:
    @pytest.fixture(scope="class")
    def result(self):
        return get_info(
            country_names="Afghanistan",
            topics="Elections:LowerHouse:CLEA",
        )

    def test_n_topics(self, result):
        assert len(result["topics"]) == R_REF["test4_both"]["n_topics"]

    def test_n_geosets(self, result):
        assert len(result["geosets"]) == R_REF["test4_both"]["n_geosets"]

    def test_topic_names_match_r(self, result):
        assert list(result["topics"].keys()) == R_REF["test4_both"]["topic_names"]

    def test_only_afg_in_results(self, result):
        df = result["topics"]["Elections:LowerHouse:CLEA"]
        assert list(df["country_iso3"].unique()) == ["AFG"]


# ════════════════════════════════════════════════
#  5. STRUCTURAL TESTS
# ════════════════════════════════════════════════

class TestStructural:
    def test_returns_dict(self):
        result = get_info()
        assert isinstance(result, dict)

    def test_three_keys(self):
        result = get_info()
        assert set(result.keys()) == {"summary", "topics", "geosets"}

    def test_topics_are_dicts_of_dataframes(self):
        result = get_info()
        assert isinstance(result["topics"], dict)
        for key, val in result["topics"].items():
            assert isinstance(val, pd.DataFrame), f"{key} not a DataFrame"

    def test_geosets_are_dicts_of_dataframes(self):
        result = get_info()
        assert isinstance(result["geosets"], dict)
        for key, val in result["geosets"].items():
            assert isinstance(val, pd.DataFrame), f"{key} not a DataFrame"


# ════════════════════════════════════════════════
#  6. INPUT NORMALISATION
# ════════════════════════════════════════════════

class TestInputNormalisation:
    def test_string_country_name(self):
        result = get_info(country_names="Afghanistan")
        assert "topics" in result
        assert len(result["topics"]) > 0

    def test_list_country_name(self):
        result = get_info(country_names=["Afghanistan"])
        assert len(result["topics"]) > 0

    def test_string_topic(self):
        result = get_info(topics="Elections:LowerHouse:CLEA")
        assert len(result["topics"]) == 1

    def test_list_topic(self):
        result = get_info(topics=["Elections:LowerHouse:CLEA"])
        assert len(result["topics"]) == 1

    def test_iso3_input(self):
        result = get_info(country_iso3s="AFG")
        assert len(result["topics"]) > 0

    def test_multiple_topics(self):
        result = get_info(
            topics=["Elections:LowerHouse:CLEA", "Demographics:Population:GHS"]
        )
        assert len(result["topics"]) == 2

    def test_multiple_countries(self):
        result = get_info(country_names=["Afghanistan", "Albania"])
        afg_only = get_info(country_names="Afghanistan")
        # More countries should give >= topics
        assert len(result["topics"]) >= len(afg_only["topics"])


# ════════════════════════════════════════════════
#  7. EDGE CASES
# ════════════════════════════════════════════════

class TestEdgeCases:
    def test_unknown_country_returns_empty_topics(self):
        result = get_info(country_names="Nonexistentland")
        # cc_dict won't resolve → empty iso3s → no filter applied or empty result
        assert isinstance(result, dict)

    def test_unknown_topic_returns_empty(self):
        result = get_info(topics="Nonexistent:Topic:Source")
        assert len(result["topics"]) == 0

    def test_summary_contains_sungeo(self):
        result = get_info()
        summary_text = " ".join(result["summary"])
        assert "SUNGEO" in summary_text

    def test_country_filter_reduces_topics(self):
        all_result = get_info()
        afg_result = get_info(country_names="Afghanistan")
        assert len(afg_result["topics"]) <= len(all_result["topics"])

    def test_topic_filter_reduces_topics(self):
        all_result = get_info()
        clea_result = get_info(topics="Elections:LowerHouse:CLEA")
        assert len(clea_result["topics"]) < len(all_result["topics"])