"""Tests for sungeo.poly2poly_ap against R reference output.

Reference values generated in R using:
    poly2poly_ap(poly_from=clea_deu2009, poly_to=hex_05_deu, ...)
"""

import pathlib

import geopandas as gpd
import numpy as np
import pandas as pd
import pytest

from sungeo.poly2poly_ap import poly2poly_ap

DATA_DIR = pathlib.Path(__file__).resolve().parent.parent / "src" / "sungeo" / "data"

# ── R reference values ───────────────────────────────────────────────
R_REF = {
    "test1_nrow": 257,
    "test1_to1_aw_mean": 0.699,
    "test1_to1_aw_min": 0.6047,
    "test1_to1_aw_max": 0.7376,
    "test1_to1_aw_na_count": 0,
    "test2_vv1_aw_sum": 43371190,
    "test2_vv1_original_sum": 43371190,
    "test2_to1_aw_mean": 0.6996,
    "test2_has_incumb": True,
    "test2_has_win1": True,
}


@pytest.fixture(scope="module")
def clea():
    return gpd.read_file(DATA_DIR / "clea_deu2009.gpkg")


@pytest.fixture(scope="module")
def hexgrid():
    return gpd.read_file(DATA_DIR / "hex_05_deu.gpkg")


@pytest.fixture(scope="module")
def result_single(clea, hexgrid):
    """Test case 1: single intensive variable, area weighting."""
    return poly2poly_ap(
        poly_from=clea, poly_to=hexgrid,
        poly_to_id="HEX_ID", varz="to1",
    )


@pytest.fixture(scope="module")
def result_multi(clea, hexgrid):
    """Test case 2: multiple variables, pycnophylactic, char vars."""
    return poly2poly_ap(
        poly_from=clea, poly_to=hexgrid,
        poly_to_id="HEX_ID",
        varz=[["to1", "pvs1_margin"], ["vv1"]],
        pycno_varz="vv1",
        funz=[
            lambda x, w: float(np.average(x[~np.isnan(x)], weights=w[~np.isnan(x)])),
            lambda x, w: float((x * w).sum()),
        ],
        char_varz=["incumb_pty_n", "win1_pty_n"],
    )


# ── test case 1: single variable, area weighting ────────────────────
class TestSingleVariable:

    def test_row_count(self, result_single):
        assert len(result_single) == R_REF["test1_nrow"]

    def test_output_column_exists(self, result_single):
        assert "to1_aw" in result_single.columns

    def test_mean(self, result_single):
        mean_val = result_single["to1_aw"].mean()
        assert mean_val == pytest.approx(R_REF["test1_to1_aw_mean"], abs=0.01)

    def test_min(self, result_single):
        min_val = result_single["to1_aw"].min()
        assert min_val == pytest.approx(R_REF["test1_to1_aw_min"], abs=0.01)

    def test_max(self, result_single):
        max_val = result_single["to1_aw"].max()
        assert max_val == pytest.approx(R_REF["test1_to1_aw_max"], abs=0.01)

    def test_no_na(self, result_single):
        assert result_single["to1_aw"].isna().sum() == R_REF["test1_to1_aw_na_count"]

    def test_destination_id_preserved(self, result_single):
        assert "HEX_ID" in result_single.columns


# ── test case 2: multi-variable with pycnophylactic + char vars ──────
class TestMultiVariable:

    def test_pycnophylactic_sum(self, result_multi):
        """Extensive variable total must be preserved (mass-preserving)."""
        result_sum = result_multi["vv1_aw"].sum()
        assert result_sum == pytest.approx(R_REF["test2_vv1_aw_sum"], rel=0.01)

    def test_to1_mean(self, result_multi):
        mean_val = result_multi["to1_aw"].mean()
        assert mean_val == pytest.approx(R_REF["test2_to1_aw_mean"], abs=0.01)

    def test_char_columns_exist(self, result_multi):
        assert "incumb_pty_n" in result_multi.columns
        assert "win1_pty_n" in result_multi.columns

    def test_intensive_in_range(self, result_multi):
        """Weighted mean of turnout should stay within plausible range."""
        valid = result_multi["to1_aw"].dropna()
        assert valid.min() >= 0
        assert valid.max() <= 1


# ── error handling ───────────────────────────────────────────────────
class TestErrors:

    def test_pw_without_raster_raises(self, clea, hexgrid):
        with pytest.raises(ValueError, match="population raster"):
            poly2poly_ap(
                poly_from=clea, poly_to=hexgrid,
                poly_to_id="HEX_ID", varz="to1",
                methodz="pw",
            )

    def test_mismatched_varz_funz_raises(self, clea, hexgrid):
        with pytest.raises(ValueError, match="Length"):
            poly2poly_ap(
                poly_from=clea, poly_to=hexgrid,
                poly_to_id="HEX_ID",
                varz=[["to1"], ["vv1"]],
                funz=[lambda x, w: x.mean()],
            )


# ── R cross-check: standalone char_varz ──────────────────────────────
# R ref: nrow=257, cols include "cst_n", has_cst_n=True, has_to1=True
class TestCharVarzStandalone:
    """char_varz without being mixed into multi-var funz.
    Covers poly2poly_ap.py lines 320-352 (char variable handling)."""

    @pytest.fixture(scope="class")
    def result_char(self, clea, hexgrid):
        return poly2poly_ap(
            poly_from=clea, poly_to=hexgrid,
            poly_to_id="HEX_ID",
            varz="to1",
            char_varz="cst_n",
        )

    def test_nrow(self, result_char):
        assert len(result_char) == 257

    def test_has_char_column(self, result_char):
        # R output shows column is "cst_n" (not "cst_n_aw")
        char_cols = [c for c in result_char.columns if "cst_n" in c]
        assert len(char_cols) > 0

    def test_has_numeric_column(self, result_char):
        to1_cols = [c for c in result_char.columns if "to1" in c]
        assert len(to1_cols) > 0

    def test_is_geodataframe(self, result_char):
        assert isinstance(result_char, gpd.GeoDataFrame)

    def test_hex_id_preserved(self, result_char):
        assert "HEX_ID" in result_char.columns


# ── R cross-check: standalone pycno_varz ─────────────────────────────
# R ref: nrow=257, pycno_sum=43371190=orig_sum (mass-preserving)
class TestPycnoVarzStandalone:
    """pycno_varz mass preservation without other variable groups.
    Covers poly2poly_ap.py lines 149-155, 182-188 (pycnophylactic rescaling)."""

    @pytest.fixture(scope="class")
    def result_pycno(self, clea, hexgrid):
        return poly2poly_ap(
            poly_from=clea, poly_to=hexgrid,
            poly_to_id="HEX_ID",
            varz="vv1",
            pycno_varz="vv1",
        )

    def test_nrow(self, result_pycno):
        assert len(result_pycno) == 257

    def test_has_vv1_column(self, result_pycno):
        vv1_cols = [c for c in result_pycno.columns if "vv1" in c]
        assert len(vv1_cols) > 0

    def test_pycno_sum_preserves_original(self, result_pycno, clea):
        """Pycnophylactic property: sum must equal original sum."""
        vv1_col = [c for c in result_pycno.columns if "vv1" in c][0]
        result_sum = result_pycno[vv1_col].sum()
        orig_sum = clea["vv1"].sum()
        assert result_sum == pytest.approx(orig_sum, rel=0.01)

    def test_pycno_sum_matches_r(self, result_pycno):
        """R reference: pycno_sum = 43371190."""
        vv1_col = [c for c in result_pycno.columns if "vv1" in c][0]
        assert result_pycno[vv1_col].sum() == pytest.approx(43371190, rel=0.01)

    def test_is_geodataframe(self, result_pycno):
        assert isinstance(result_pycno, gpd.GeoDataFrame)


# ── char_assign="all_overlap" ────────────────────────────────────────
class TestCharAssignAllOverlap:
    """Test char_assign='all_overlap' produces pipe-separated values.
    Covers poly2poly_ap.py lines related to all_overlap branch."""

    @pytest.fixture(scope="class")
    def result_all_overlap(self, clea, hexgrid):
        return poly2poly_ap(
            poly_from=clea, poly_to=hexgrid,
            poly_to_id="HEX_ID",
            varz="to1",
            char_varz="cst_n",
            char_assign="all_overlap",
        )

    def test_nrow(self, result_all_overlap):
        assert len(result_all_overlap) == 257

    def test_has_char_column(self, result_all_overlap):
        char_cols = [c for c in result_all_overlap.columns if "cst_n" in c]
        assert len(char_cols) > 0

    def test_is_geodataframe(self, result_all_overlap):
        assert isinstance(result_all_overlap, gpd.GeoDataFrame)