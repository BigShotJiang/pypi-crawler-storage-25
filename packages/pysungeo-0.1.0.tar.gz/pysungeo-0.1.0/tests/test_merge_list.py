"""
Tests for sungeo.merge_list

Test categories:
    1. Core behavior (two DFs, three DFs, five DFs)
    2. Join semantics (outer join, common columns, no common columns)
    3. Edge cases (single DF, odd count, duplicate columns)
    4. Error handling
"""

import numpy as np
import pandas as pd
import pytest

from sungeo.merge_list import merge_list


# ════════════════════════════════════════════════
#  1. CORE BEHAVIOR
# ════════════════════════════════════════════════

class TestCoreBehavior:
    def test_two_dfs_common_key(self):
        A = pd.DataFrame({"key": [1, 2, 3], "a": [10, 20, 30]})
        B = pd.DataFrame({"key": [2, 3, 4], "b": [200, 300, 400]})
        result = merge_list([A, B])
        assert len(result) == 4  # outer join: keys 1, 2, 3, 4
        assert set(result.columns) == {"key", "a", "b"}

    def test_three_dfs_different_keys(self):
        """R docstring example structure: A(month,year,A), B(year,B), C(month,C)."""
        A = pd.DataFrame({
            "month": ["Jan", "Feb"] * 2,
            "year": [1991, 1991, 1992, 1992],
            "A": [1, 2, 3, 4],
        })
        B = pd.DataFrame({"year": [1991, 1992], "B": [10, 20]})
        C = pd.DataFrame({"month": ["Jan", "Feb"], "C": [100, 200]})
        result = merge_list([A, B, C])
        assert len(result) == 4
        assert set(result.columns) == {"month", "year", "A", "B", "C"}

    def test_five_dfs_same_key(self):
        """Odd count exercises the pass-through branch."""
        dfs = [
            pd.DataFrame({"x": [1, 2], f"v{i}": [i * 10, i * 20]})
            for i in range(5)
        ]
        result = merge_list(dfs)
        assert len(result) == 2
        assert set(result.columns) == {"x", "v0", "v1", "v2", "v3", "v4"}

    def test_values_preserved(self):
        A = pd.DataFrame({"key": [1], "a": [42]})
        B = pd.DataFrame({"key": [1], "b": [99]})
        result = merge_list([A, B])
        assert result["a"].iloc[0] == 42
        assert result["b"].iloc[0] == 99


# ════════════════════════════════════════════════
#  2. JOIN SEMANTICS
# ════════════════════════════════════════════════

class TestJoinSemantics:
    def test_outer_join_fills_na(self):
        A = pd.DataFrame({"key": [1, 2], "a": [10, 20]})
        B = pd.DataFrame({"key": [2, 3], "b": [200, 300]})
        result = merge_list([A, B])
        # key=1 should have b=NaN, key=3 should have a=NaN
        row1 = result[result["key"] == 1].iloc[0]
        assert pd.isna(row1["b"])
        row3 = result[result["key"] == 3].iloc[0]
        assert pd.isna(row3["a"])

    def test_multiple_common_columns(self):
        A = pd.DataFrame({"x": [1, 1], "y": ["a", "b"], "val_a": [10, 20]})
        B = pd.DataFrame({"x": [1, 1], "y": ["a", "b"], "val_b": [30, 40]})
        result = merge_list([A, B])
        assert len(result) == 2
        assert set(result.columns) == {"x", "y", "val_a", "val_b"}

    def test_no_common_columns_cross_join(self):
        A = pd.DataFrame({"a": [1, 2]})
        B = pd.DataFrame({"b": [10, 20]})
        result = merge_list([A, B])
        assert len(result) == 4  # 2 × 2 cross join
        assert set(result.columns) == {"a", "b"}

    def test_cartesian_with_common_key(self):
        """Multiple matches on same key → cartesian product within that key."""
        A = pd.DataFrame({"key": [1, 1], "a": [10, 20]})
        B = pd.DataFrame({"key": [1, 1], "b": [30, 40]})
        result = merge_list([A, B])
        assert len(result) == 4  # 2 × 2 within key=1


# ════════════════════════════════════════════════
#  3. EDGE CASES
# ════════════════════════════════════════════════

class TestEdgeCases:
    def test_single_df(self):
        A = pd.DataFrame({"x": [1, 2, 3]})
        result = merge_list([A])
        assert result.equals(A)

    def test_odd_number_of_dfs(self):
        dfs = [pd.DataFrame({"x": [i], "v": [i * 10]}) for i in range(3)]
        result = merge_list(dfs)
        assert len(result) == 3

    def test_duplicate_columns_deduplicated(self):
        """If merge produces duplicate column names, keep only first."""
        A = pd.DataFrame({"key": [1], "val": [10]})
        B = pd.DataFrame({"key": [1], "val": [10]})
        result = merge_list([A, B])
        # "val" appears in both → after merge on "key", should be deduplicated
        assert "key" in result.columns

    def test_empty_rows_in_one_df(self):
        A = pd.DataFrame({"key": pd.Series([], dtype=int), "a": pd.Series([], dtype=int)})
        B = pd.DataFrame({"key": [1], "b": [10]})
        result = merge_list([A, B])
        assert len(result) == 1  # outer join keeps B's row

    def test_preserves_dtypes(self):
        A = pd.DataFrame({"key": [1, 2], "val": [1.5, 2.5]})
        B = pd.DataFrame({"key": [1, 2], "count": [10, 20]})
        result = merge_list([A, B])
        assert result["val"].dtype == np.float64
        assert result["count"].dtype in [np.int64, np.int32, int]


# ════════════════════════════════════════════════
#  4. ERROR HANDLING
# ════════════════════════════════════════════════

class TestErrorHandling:
    def test_empty_list_raises(self):
        with pytest.raises(ValueError, match="at least one"):
            merge_list([])

    def test_input_list_not_mutated(self):
        A = pd.DataFrame({"x": [1]})
        B = pd.DataFrame({"x": [2]})
        original = [A, B]
        merge_list(original)
        assert len(original) == 2
        assert original[0].equals(A)