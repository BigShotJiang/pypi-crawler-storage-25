"""
Tests for sungeo.geocode_osm

Test categories:
    1. R cross-check (column structure, approximate coordinates)
    2. Parsing tests with mocked API responses
    3. Details mode (details=True/False)
    4. Match selection (match_num, return_all)
    5. Empty / no-result handling
    6. Error handling (network failure, bad input)
    7. Live integration tests (skipped by default)

Because geocode_osm calls a live API, all unit tests mock the HTTP
response.  Live tests are gated and skipped by default.
"""

import warnings
from unittest.mock import patch, MagicMock

import numpy as np
import pandas as pd
import pytest

from sungeo.geocode_osm import geocode_osm

# ────────────────────────────────────────────────
#  R reference values (from RStudio)
# ────────────────────────────────────────────────

R_REF = {
    "basic_columns": ["query", "osm_id", "address", "longitude", "latitude"],
    "detail_columns": [
        "query", "osm_id", "osm_type", "importance", "address",
        "longitude", "latitude",
        "bbox_ymin", "bbox_ymax", "bbox_xmin", "bbox_xmax",
    ],
    "michigan_stadium": {
        "longitude": -83.74868,
        "latitude": 42.26587,
    },
    "return_all_nrow": 3,
}

# ────────────────────────────────────────────────
#  Sample mock API responses
# ────────────────────────────────────────────────

MOCK_RESPONSE_MICHIGAN = [
    {
        "place_id": 123456,
        "osm_type": "way",
        "osm_id": 27693275,
        "lat": "42.26587",
        "lon": "-83.74868",
        "display_name": "Michigan Stadium, South Main Street, Burns Park, Ann Arbor, Washtenaw County, Michigan, 48104, United States",
        "importance": 0.5,
        "boundingbox": ["42.2638", "42.2678", "-83.7510", "-83.7462"],
    },
    {
        "place_id": 789012,
        "osm_type": "relation",
        "osm_id": 99999999,
        "lat": "42.2660",
        "lon": "-83.7490",
        "display_name": "Michigan Stadium Area, Ann Arbor, Michigan, United States",
        "importance": 0.3,
        "boundingbox": ["42.2600", "42.2700", "-83.7550", "-83.7400"],
    },
    {
        "place_id": 345678,
        "osm_type": "node",
        "osm_id": 88888888,
        "lat": "42.2650",
        "lon": "-83.7480",
        "display_name": "Michigan Stadium Parking, Ann Arbor, Michigan, United States",
        "importance": 0.2,
        "boundingbox": ["42.2640", "42.2660", "-83.7500", "-83.7460"],
    },
]

MOCK_RESPONSE_EMPTY = []


def _mock_get(response_data, status_code=200):
    """Create a mock for requests.get that returns the given JSON data."""
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = response_data
    mock_resp.raise_for_status.return_value = None
    return mock_resp


# ════════════════════════════════════════════════
#  1. R CROSS-CHECK
# ════════════════════════════════════════════════

class TestRCrossCheck:
    """Verify output structure and values match R exactly."""

    @patch("sungeo.geocode_osm.requests.get")
    def test_basic_columns_match_r(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert list(result.columns) == R_REF["basic_columns"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_detail_columns_match_r(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", details=True)
        assert list(result.columns) == R_REF["detail_columns"]

    @patch("sungeo.geocode_osm.requests.get")
    def test_coordinates_match_r(self, mock_get):
        """Mock uses the exact coordinates from R output."""
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert result["longitude"].iloc[0] == pytest.approx(
            R_REF["michigan_stadium"]["longitude"], abs=0.001
        )
        assert result["latitude"].iloc[0] == pytest.approx(
            R_REF["michigan_stadium"]["latitude"], abs=0.001
        )

    @patch("sungeo.geocode_osm.requests.get")
    def test_return_all_nrow_matches_r(self, mock_get):
        """R returns 3 rows for return_all=TRUE on Michigan Stadium."""
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", return_all=True)
        assert len(result) == R_REF["return_all_nrow"]


# ════════════════════════════════════════════════
#  2. PARSING TESTS (mocked API)
# ════════════════════════════════════════════════

class TestParsing:
    @patch("sungeo.geocode_osm.requests.get")
    def test_single_row_default(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert len(result) == 1

    @patch("sungeo.geocode_osm.requests.get")
    def test_query_preserved(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert result["query"].iloc[0] == "Michigan Stadium"

    @patch("sungeo.geocode_osm.requests.get")
    def test_osm_id_is_string(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert isinstance(result["osm_id"].iloc[0], str)

    @patch("sungeo.geocode_osm.requests.get")
    def test_address_populated(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert "Michigan Stadium" in result["address"].iloc[0]

    @patch("sungeo.geocode_osm.requests.get")
    def test_longitude_is_float(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert isinstance(result["longitude"].iloc[0], float)

    @patch("sungeo.geocode_osm.requests.get")
    def test_latitude_is_float(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert isinstance(result["latitude"].iloc[0], float)


# ════════════════════════════════════════════════
#  3. DETAILS MODE
# ════════════════════════════════════════════════

class TestDetails:
    @patch("sungeo.geocode_osm.requests.get")
    def test_details_false_no_extras(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", details=False)
        assert "osm_type" not in result.columns
        assert "importance" not in result.columns
        assert "bbox_ymin" not in result.columns

    @patch("sungeo.geocode_osm.requests.get")
    def test_details_true_osm_type(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", details=True)
        assert result["osm_type"].iloc[0] == "way"

    @patch("sungeo.geocode_osm.requests.get")
    def test_details_true_importance(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", details=True)
        assert result["importance"].iloc[0] == pytest.approx(0.5)

    @patch("sungeo.geocode_osm.requests.get")
    def test_details_true_bbox(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", details=True)
        assert result["bbox_ymin"].iloc[0] == pytest.approx(42.2638, abs=0.01)
        assert result["bbox_ymax"].iloc[0] == pytest.approx(42.2678, abs=0.01)
        assert result["bbox_xmin"].iloc[0] == pytest.approx(-83.7510, abs=0.01)
        assert result["bbox_xmax"].iloc[0] == pytest.approx(-83.7462, abs=0.01)


# ════════════════════════════════════════════════
#  4. MATCH SELECTION
# ════════════════════════════════════════════════

class TestMatchSelection:
    @patch("sungeo.geocode_osm.requests.get")
    def test_match_num_1_default(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium")
        assert result["osm_id"].iloc[0] == "27693275"

    @patch("sungeo.geocode_osm.requests.get")
    def test_match_num_2(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", match_num=2)
        assert len(result) == 1
        assert result["osm_id"].iloc[0] == "99999999"

    @patch("sungeo.geocode_osm.requests.get")
    def test_match_num_3(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", match_num=3)
        assert len(result) == 1
        assert result["osm_id"].iloc[0] == "88888888"

    @patch("sungeo.geocode_osm.requests.get")
    def test_return_all(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", return_all=True)
        assert len(result) == 3
        assert result["osm_id"].iloc[0] == "27693275"
        assert result["osm_id"].iloc[2] == "88888888"

    @patch("sungeo.geocode_osm.requests.get")
    def test_return_all_with_details(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", return_all=True, details=True)
        assert len(result) == 3
        assert "osm_type" in result.columns
        assert result["importance"].iloc[0] >= result["importance"].iloc[2]

    @patch("sungeo.geocode_osm.requests.get")
    def test_return_all_query_column_same(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", return_all=True)
        assert (result["query"] == "Michigan Stadium").all()

    @patch("sungeo.geocode_osm.requests.get")
    def test_match_num_out_of_range(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
        result = geocode_osm("Michigan Stadium", match_num=99)
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])


# ════════════════════════════════════════════════
#  5. EMPTY / NO-RESULT HANDLING
# ════════════════════════════════════════════════

class TestEmptyResults:
    @patch("sungeo.geocode_osm.requests.get")
    def test_no_results_returns_nan(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_EMPTY)
        result = geocode_osm("xyznonexistentplace12345")
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])
        assert pd.isna(result["latitude"].iloc[0])
        assert result["query"].iloc[0] == "xyznonexistentplace12345"

    @patch("sungeo.geocode_osm.requests.get")
    def test_no_results_with_details(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_EMPTY)
        result = geocode_osm("xyznonexistent", details=True)
        assert list(result.columns) == R_REF["detail_columns"]
        assert pd.isna(result["bbox_ymin"].iloc[0])
        assert pd.isna(result["importance"].iloc[0])

    def test_empty_string_query(self):
        result = geocode_osm("")
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])
        assert result["query"].iloc[0] == ""

    @patch("sungeo.geocode_osm.requests.get")
    def test_no_results_columns_match_r(self, mock_get):
        mock_get.return_value = _mock_get(MOCK_RESPONSE_EMPTY)
        result = geocode_osm("xyznonexistent")
        assert list(result.columns) == R_REF["basic_columns"]


# ════════════════════════════════════════════════
#  6. ERROR HANDLING
# ════════════════════════════════════════════════

class TestErrorHandling:
    @patch("sungeo.geocode_osm.requests.get")
    def test_network_failure_returns_nan(self, mock_get):
        import requests as req
        mock_get.side_effect = req.ConnectionError("No internet")
        result = geocode_osm("Michigan Stadium")
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])
        assert result["query"].iloc[0] == "Michigan Stadium"

    @patch("sungeo.geocode_osm.requests.get")
    def test_http_500_returns_nan(self, mock_get):
        import requests as req
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.raise_for_status.side_effect = req.HTTPError("500 Server Error")
        mock_get.return_value = mock_resp
        result = geocode_osm("Michigan Stadium")
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])

    @patch("sungeo.geocode_osm.requests.get")
    def test_timeout_returns_nan(self, mock_get):
        import requests as req
        mock_get.side_effect = req.Timeout("Request timed out")
        result = geocode_osm("Michigan Stadium")
        assert len(result) == 1
        assert pd.isna(result["longitude"].iloc[0])

    def test_multiple_queries_warns(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            with patch("sungeo.geocode_osm.requests.get") as mock_get:
                mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
                geocode_osm(["Michigan Stadium", "Berlin"])
            batch_warns = [x for x in w if "geocode_osm_batch" in str(x.message)]
            assert len(batch_warns) >= 1

    def test_multiple_queries_uses_first(self):
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            with patch("sungeo.geocode_osm.requests.get") as mock_get:
                mock_get.return_value = _mock_get(MOCK_RESPONSE_MICHIGAN)
                result = geocode_osm(["Michigan Stadium", "Berlin"])
                assert result["query"].iloc[0] == "Michigan Stadium"

    @patch("sungeo.geocode_osm.requests.get")
    def test_network_failure_columns_match_r(self, mock_get):
        import requests as req
        mock_get.side_effect = req.ConnectionError("No internet")
        result = geocode_osm("test", details=True)
        assert list(result.columns) == R_REF["detail_columns"]


# ════════════════════════════════════════════════
#  7. LIVE INTEGRATION TESTS (skipped by default)
# ════════════════════════════════════════════════

# To enable: change the skipif condition to False
@pytest.mark.skipif(
    True,
    reason="Live API tests disabled by default. Set to False to enable.",
)
class TestLiveAPI:
    def test_michigan_stadium_coordinates(self):
        """R reference: lon=-83.74868, lat=42.26587."""
        result = geocode_osm("Michigan Stadium")
        assert result["longitude"].iloc[0] == pytest.approx(-83.75, abs=0.05)
        assert result["latitude"].iloc[0] == pytest.approx(42.27, abs=0.05)

    def test_michigan_stadium_columns(self):
        result = geocode_osm("Michigan Stadium")
        assert list(result.columns) == R_REF["basic_columns"]

    def test_michigan_stadium_details(self):
        result = geocode_osm("Michigan Stadium", details=True)
        assert list(result.columns) == R_REF["detail_columns"]
        assert result["osm_type"].iloc[0] in ("node", "way", "relation")
        assert result["importance"].iloc[0] > 0

    def test_michigan_stadium_return_all(self):
        result = geocode_osm("Michigan Stadium", return_all=True)
        assert len(result) >= R_REF["return_all_nrow"]