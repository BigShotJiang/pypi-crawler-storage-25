#!/usr/bin/env python3
"""
Sandflare CLI — manage sandboxes and databases from your terminal.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

PRIMARY_CONFIG_FILE = Path.home() / ".sandflare" / "config.json"
LEGACY_CONFIG_FILE = Path.home() / ".pandaagent" / "config.json"
DEFAULT_BASE = "https://api.sandflare.io"


def load_config() -> dict:
    for path in (PRIMARY_CONFIG_FILE, LEGACY_CONFIG_FILE):
        if path.exists():
            try:
                return json.loads(path.read_text())
            except Exception:
                pass
    return {}


def save_config(cfg: dict):
    PRIMARY_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    PRIMARY_CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def get_api_key() -> str:
    return (
        os.environ.get("SANDFLARE_API_KEY")
        or os.environ.get("PANDAAGENT_API_KEY")
        or os.environ.get("AGENTBOX_API_KEY")
        or load_config().get("api_key")
        or ""
    )


def get_base_url() -> str:
    return (
        os.environ.get("SANDFLARE_API_URL")
        or load_config().get("base_url")
        or DEFAULT_BASE
    )


def _headers() -> dict:
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "sandflare-cli/1.0",
    }
    key = get_api_key()
    if key:
        headers["X-API-Key"] = key
    return headers


def api(method: str, path: str, body: dict | None = None):
    url = get_base_url().rstrip("/") + path
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=_headers(), method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read())
            msg = err.get("error") or err.get("message") or str(e)
        except Exception:
            msg = str(e)
        die(f"API error ({e.code}): {msg}")
    except urllib.error.URLError as e:
        die(f"Connection error: {e.reason}\nIs the server reachable at {get_base_url()}?")


def die(msg: str):
    print(f"\033[31m✗\033[0m {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg: str):
    print(f"\033[32m✓\033[0m {msg}")


def info(msg: str):
    print(f"\033[90m  {msg}\033[0m")


def _col(s: str, w: int, color: str = "") -> str:
    s = str(s or "")
    truncated = s[: w - 1] + "…" if len(s) > w else s.ljust(w)
    return f"\033[{color}m{truncated}\033[0m" if color else truncated


def _status_color(status: str) -> str:
    mapping = {"running": "32", "ready": "32", "starting": "33", "stopped": "31", "error": "31"}
    return mapping.get(status.lower(), "37")


def print_table(headers: list[str], rows: list[list], widths: list[int]):
    header_line = "  ".join(_col(h, w, "1") for h, w in zip(headers, widths))
    print(f"\033[90m{header_line}\033[0m")
    print("\033[90m" + "─" * sum(w + 2 for w in widths) + "\033[0m")
    for row in rows:
        parts = []
        for index, (cell, width) in enumerate(zip(row, widths)):
            cell_str = str(cell or "")
            if headers[index].lower() == "status":
                parts.append(_col(cell_str, width, _status_color(cell_str)))
            else:
                parts.append(_col(cell_str, width))
        print("  ".join(parts))


def sandbox_create(args):
    body = {}
    if args.template:
        body["template"] = args.template
    if args.name:
        body["name"] = args.name
    if args.size:
        body["size"] = args.size
    result = api("POST", "/sandboxes", body)
    ok(f"Sandbox created: \033[1m{result['name']}\033[0m")
    info(f"Agent URL : {result.get('agent_url', 'starting...')}")
    info(f"Template  : {result.get('template', 'base')}")
    if result.get("ip"):
        info(f"IP        : {result['ip']}")


def sandbox_list(_args):
    result = api("GET", "/sandboxes")
    items = result if isinstance(result, list) else result.get("sandboxes", [])
    if not items:
        info("No sandboxes found.")
        return
    print_table(
        ["NAME", "STATUS", "TEMPLATE", "IP", "CREATED"],
        [
            [
                item.get("name"),
                item.get("status"),
                item.get("template", "base"),
                item.get("ip", ""),
                item.get("created_at", "")[:10] if item.get("created_at") else "",
            ]
            for item in items
        ],
        [18, 10, 14, 16, 12],
    )


def _resolve_sandbox_id(name_or_id: str) -> str:
    """Resolve a sandbox name/label to its ID (sb-xxxxxxxx).
    If name_or_id already looks like a sandbox ID, return it as-is.
    Otherwise fetch the list and find by label match."""
    if name_or_id.startswith("sb-"):
        return name_or_id
    sandboxes = api("GET", "/sandboxes") or []
    if isinstance(sandboxes, dict):
        sandboxes = sandboxes.get("sandboxes", [])
    for sb in sandboxes:
        if sb.get("label") == name_or_id or sb.get("name") == name_or_id:
            return sb.get("name") or sb.get("sandbox_id") or name_or_id
    return name_or_id  # best effort


def sandbox_exec(args):
    sandbox_id = _resolve_sandbox_id(args.name)
    result = api("POST", f"/sandboxes/{sandbox_id}/exec", {"cmd": " ".join(args.cmd)})
    stdout = result.get("stdout", "")
    stderr = result.get("stderr", "")
    if stdout:
        print(stdout, end="" if stdout.endswith("\n") else "\n")
    if stderr:
        print(stderr, end="" if stderr.endswith("\n") else "\n", file=sys.stderr)
    exit_code = result.get("exit_code", 0)
    if exit_code != 0:
        sys.exit(exit_code)


def sandbox_delete(args):
    api("DELETE", f"/sandboxes/{args.name}")
    ok(f"Sandbox \033[1m{args.name}\033[0m deleted.")


def sandbox_shell(args):
    result = api("GET", f"/sandboxes/{args.name}")
    ip = result.get("ip")
    if not ip:
        die(f"Sandbox {args.name} has no IP yet (status: {result.get('status')}). Try again shortly.")
    print(f"\033[90mConnecting to {args.name} ({ip})…\033[0m")
    os.execvp("ssh", ["ssh", "-o", "StrictHostKeyChecking=no", f"root@{ip}"])


def db_create(args):
    body = {}
    if args.name:
        body["name"] = args.name
    if args.ttl:
        body["ttl_hours"] = int(args.ttl)
    result = api("POST", "/instances", body)
    ok(f"Database created: \033[1m{result['name']}\033[0m")
    info(f"Host    : {result.get('ip', 'starting...')}")
    info(f"Port    : {result.get('pg_port', 5432)}")
    info(f"User    : {result.get('username', 'postgres')}")
    info(f"Pass    : {result.get('password', '(see dashboard)')}")
    if result.get("ip") and result.get("pg_port"):
        pg = (
            f"postgresql://{result.get('username', 'postgres')}:{result.get('password', '')}@"
            f"{result['ip']}:{result['pg_port']}/postgres"
        )
        info(f"DSN     : {pg}")


def db_list(_args):
    result = api("GET", "/instances")
    items = result if isinstance(result, list) else result.get("instances", [])
    if not items:
        info("No databases found.")
        return
    print_table(
        ["NAME", "STATUS", "IP", "PORT", "USER", "CREATED"],
        [
            [
                item.get("name"),
                item.get("status"),
                item.get("ip", ""),
                item.get("pg_port", ""),
                item.get("username", ""),
                item.get("created_at", "")[:10] if item.get("created_at") else "",
            ]
            for item in items
        ],
        [18, 10, 16, 6, 12, 12],
    )


def db_connect(args):
    result = api("GET", f"/instances/{args.name}")
    ip = result.get("ip")
    port = result.get("pg_port", 5432)
    user = result.get("username", "postgres")
    password = result.get("password", "")
    if not ip:
        die(f"Database {args.name} has no IP yet (status: {result.get('status')}). Try again shortly.")
    env = {**os.environ, "PGPASSWORD": password}
    print(f"\033[90mConnecting psql → {args.name} ({ip}:{port})…\033[0m")
    os.execvpe("psql", ["psql", "-h", ip, "-p", str(port), "-U", user, "-d", "postgres"], env)


def db_delete(args):
    api("DELETE", f"/instances/{args.name}")
    ok(f"Database \033[1m{args.name}\033[0m deleted.")


def keys_list(_args):
    result = api("GET", "/api-keys")
    items = result if isinstance(result, list) else result.get("keys", [])
    if not items:
        info("No API keys found.")
        return
    print_table(
        ["ID", "PREFIX", "LABEL", "CREATED"],
        [
            [
                item.get("id", ""),
                item.get("key_prefix", ""),
                item.get("label", ""),
                item.get("created_at", "")[:10] if item.get("created_at") else "",
            ]
            for item in items
        ],
        [36, 20, 24, 12],
    )


def keys_create(args):
    body = {}
    if args.label:
        body["label"] = args.label
    result = api("POST", "/api-keys", body)
    ok("API key created:")
    print(f"\n  \033[1;33m{result['key']}\033[0m\n")
    print("  \033[90mStore this securely — it won't be shown again.\033[0m")
    print(f"  Key ID: {result.get('id', '')}")


def keys_revoke(args):
    api("DELETE", f"/api-keys/{args.id}")
    ok(f"API key \033[1m{args.id}\033[0m revoked.")


def config_set_key(args):
    cfg = load_config()
    cfg["api_key"] = args.api_key
    save_config(cfg)
    ok(f"API key saved to {PRIMARY_CONFIG_FILE}")


def config_show(_args):
    cfg = load_config()
    key = cfg.get("api_key", "")
    masked = key[:12] + "…" if len(key) > 12 else key
    print(f"  base_url  : {cfg.get('base_url', DEFAULT_BASE)}")
    print(f"  api_key   : {masked or '(not set)'}")
    cfg_path = PRIMARY_CONFIG_FILE if PRIMARY_CONFIG_FILE.exists() else LEGACY_CONFIG_FILE
    print(f"  config    : {cfg_path}")


def main():
    prog_name = Path(sys.argv[0]).stem or "sandflare"
    parser = argparse.ArgumentParser(
        prog=prog_name,
        description="Sandflare CLI — manage sandboxes and databases",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="resource", metavar="<resource>")

    sandbox_parser = sub.add_parser("sandbox", aliases=["sb"], help="Manage sandboxes")
    sandbox_sub = sandbox_parser.add_subparsers(dest="action", metavar="<action>")

    sandbox_create_parser = sandbox_sub.add_parser("create", help="Create a sandbox")
    sandbox_create_parser.add_argument("--template", "-t", help="Template name (python, node, fullstack…)")
    sandbox_create_parser.add_argument("--name", "-n", help="Custom name")
    sandbox_create_parser.add_argument("--size", "-s", help="Sandbox tier (nano, small, medium, large, xl)", default=None)
    sandbox_create_parser.set_defaults(func=sandbox_create)

    sandbox_list_parser = sandbox_sub.add_parser("list", aliases=["ls"], help="List sandboxes")
    sandbox_list_parser.set_defaults(func=sandbox_list)

    sandbox_exec_parser = sandbox_sub.add_parser("exec", help="Run a command in a sandbox")
    sandbox_exec_parser.add_argument("name", help="Sandbox name")
    sandbox_exec_parser.add_argument("cmd", nargs=argparse.REMAINDER, help="Command to run")
    sandbox_exec_parser.set_defaults(func=sandbox_exec)

    sandbox_delete_parser = sandbox_sub.add_parser("delete", aliases=["rm", "del"], help="Delete a sandbox")
    sandbox_delete_parser.add_argument("name", help="Sandbox name")
    sandbox_delete_parser.set_defaults(func=sandbox_delete)

    sandbox_shell_parser = sandbox_sub.add_parser("shell", aliases=["ssh"], help="Open a shell in a sandbox")
    sandbox_shell_parser.add_argument("name", help="Sandbox name")
    sandbox_shell_parser.set_defaults(func=sandbox_shell)

    db_parser = sub.add_parser("db", help="Manage databases")
    db_sub = db_parser.add_subparsers(dest="action", metavar="<action>")

    db_create_parser = db_sub.add_parser("create", help="Create a PostgreSQL database")
    db_create_parser.add_argument("--name", "-n", help="Custom name")
    db_create_parser.add_argument("--ttl", help="TTL in hours (default 24)")
    db_create_parser.set_defaults(func=db_create)

    db_list_parser = db_sub.add_parser("list", aliases=["ls"], help="List databases")
    db_list_parser.set_defaults(func=db_list)

    db_connect_parser = db_sub.add_parser("connect", aliases=["psql"], help="Connect via psql")
    db_connect_parser.add_argument("name", help="Database name")
    db_connect_parser.set_defaults(func=db_connect)

    db_delete_parser = db_sub.add_parser("delete", aliases=["rm", "del"], help="Delete a database")
    db_delete_parser.add_argument("name", help="Database name")
    db_delete_parser.set_defaults(func=db_delete)

    keys_parser = sub.add_parser("keys", help="Manage API keys")
    keys_sub = keys_parser.add_subparsers(dest="action", metavar="<action>")

    keys_list_parser = keys_sub.add_parser("list", aliases=["ls"], help="List API keys")
    keys_list_parser.set_defaults(func=keys_list)

    keys_create_parser = keys_sub.add_parser("create", help="Create an API key")
    keys_create_parser.add_argument("--label", "-l", help="Key label/description")
    keys_create_parser.set_defaults(func=keys_create)

    keys_revoke_parser = keys_sub.add_parser("revoke", aliases=["delete", "rm"], help="Revoke an API key")
    keys_revoke_parser.add_argument("id", help="Key ID to revoke")
    keys_revoke_parser.set_defaults(func=keys_revoke)

    config_parser = sub.add_parser("config", help="CLI configuration")
    config_sub = config_parser.add_subparsers(dest="action", metavar="<action>")

    config_key_parser = config_sub.add_parser("set-key", help="Save API key to config")
    config_key_parser.add_argument("api_key", help="Your pa_live_... API key")
    config_key_parser.set_defaults(func=config_set_key)

    config_show_parser = config_sub.add_parser("show", help="Show current config")
    config_show_parser.set_defaults(func=config_show)

    args = parser.parse_args()
    if not hasattr(args, "func"):
        for subparser in [sandbox_parser, db_parser, keys_parser, config_parser]:
            if args.resource in (
                getattr(subparser, "prog", "").split()[-1:] + list(subparser._option_string_actions.get("aliases", []))
            ):
                subparser.print_help()
                sys.exit(0)
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
