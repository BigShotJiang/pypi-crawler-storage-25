# Sandflare CLI

Zero-dependency Python CLI for managing Sandflare sandboxes and databases.

## Install

```bash
pip install sandflare-cli
# or from source:
pip install -e sdk/cli/
```

## Quick Start

```bash
# Save your API key once
sandflare config set-key pa_live_your_key_here

# Sandboxes
sandflare sandbox create --template python
sandflare sandbox list
sandflare sandbox exec sb-1 python3 -c "print('hello')"
sandflare sandbox shell sb-1
sandflare sandbox delete sb-1

# Databases
sandflare db create
sandflare db list
sandflare db connect psql-1
sandflare db delete psql-1

# API Keys
sandflare keys list
sandflare keys create --label "CI/CD"
sandflare keys revoke <key-id>
```

## Environment Variables

| Variable | Description |
|---|---|
| `SANDFLARE_API_KEY` | API key (preferred) |
| `PANDAAGENT_API_KEY` | Legacy API key env alias |
| `SANDFLARE_API_URL` | API base URL (default: https://api.sandflare.io) |

## Aliases

Preferred commands:

```bash
sandflare sandbox create --template node
sf sb ls
sf db ls
```

Legacy `pandaagent` / `pa` aliases can remain during migration.
