from __future__ import annotations
from pathlib import Path
from typing import List, Optional, Tuple

from .schema import (
    AgentMeta,
    Failure,
    FailureType,
    FossilRecord,
    Resolution,
    ResolutionType,
    Severity,
    Situation,
    TaskDomain,
)
from .store import FossilStore, DEFAULT_DB_PATH
from .remote import RemoteStore
from .embedder import BaseEmbedder

AnyStore = FossilStore | RemoteStore


class Fossil:
    """
    Primary interface for FOSSIL.

    Local SQLite (default):
        fossil = Fossil()

    Remote API:
        fossil = Fossil(api_url="https://fossil-api.hello-76a.workers.dev")

    Custom store:
        fossil = Fossil(store=RemoteStore("https://..."))
    """

    def __init__(
        self,
        db_path: Path | str = DEFAULT_DB_PATH,
        embedder: Optional[BaseEmbedder] = None,
        api_url: Optional[str] = None,
        store: Optional[AnyStore] = None,
    ):
        if store is not None:
            self._store = store
        elif api_url is not None:
            self._store = RemoteStore(api_url)
        else:
            self._store = FossilStore(db_path=db_path, embedder=embedder)

    def record(
        self,
        situation: str,
        failure_type: FailureType,
        failure: str,
        severity: Severity,
        resolution_type: ResolutionType,
        resolution: str,
        framework: str,
        model: str,
        domain: TaskDomain = TaskDomain.OTHER,
        context_snapshot: Optional[str] = None,
        was_irreversible: bool = False,
        verified: bool = False,
        time_to_resolve_minutes: Optional[int] = None,
        shared: bool = False,
) -> FossilRecord:
        if shared and context_snapshot:
            import warnings
            warnings.warn(
                "context_snapshot will be shared publicly. Ensure it contains no secrets, credentials, or PII before sharing.",
                stacklevel=2,
            )

        record = FossilRecord(
            agent=AgentMeta(
                framework=framework,
                model=model,
                task_domain=domain,
            ),
            situation=Situation(
                description=situation,
                context_snapshot=context_snapshot,
            ),
            failure=Failure(
                type=failure_type,
                description=failure,
                severity=severity,
                was_irreversible=was_irreversible,
            ),
            resolution=Resolution(
                type=resolution_type,
                description=resolution,
                verified=verified,
                time_to_resolve_minutes=time_to_resolve_minutes,
            ),
            shared=shared,
        )
        return self._store.insert(record)

    def record_raw(self, record: FossilRecord) -> FossilRecord:
        return self._store.insert(record)

    def search(
        self,
        situation: str,
        top_k: int = 5,
        min_score: float = 0.5,
        domain: Optional[TaskDomain] = None,
        pool: Optional[str] = None,
    ) -> List[Tuple[FossilRecord, float]]:
        if isinstance(self._store, FossilStore):
            return self._store.search(
                situation_text=situation,
                top_k=top_k,
                min_score=min_score,
                domain=domain.value if domain else None,
            )
        return self._store.search(
            situation_text=situation,
            top_k=top_k,
            min_score=min_score,
            domain=domain.value if domain else None,
            pool=pool,
        )

    def get(self, fossil_id: str) -> Optional[FossilRecord]:
        return self._store.get(fossil_id)

    def delete(self, fossil_id: str) -> bool:
        return self._store.delete(fossil_id)

    def count(self) -> int:
        return self._store.count()

    def list(self, limit: int = 100, offset: int = 0) -> List[FossilRecord]:
        return self._store.list_all(limit=limit, offset=offset)

    def close(self) -> None:
        self._store.close()

    def __enter__(self) -> Fossil:
        return self

    def __exit__(self, *_) -> None:
        self.close()