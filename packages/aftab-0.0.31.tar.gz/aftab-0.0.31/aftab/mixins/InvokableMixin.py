class InvokableMixin:
    pass
