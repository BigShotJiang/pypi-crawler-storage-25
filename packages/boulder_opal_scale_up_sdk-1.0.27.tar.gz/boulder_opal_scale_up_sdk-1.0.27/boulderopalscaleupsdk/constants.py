# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

# Default values for gRPC channel options and other constants used across the application.
DEFAULT_GRPC_MAX_RECEIVE_MESSAGE_LENGTH = 1024 * 1024 * 50  # 50MB
DEFAULT_GRPC_MAX_SEND_MESSAGE_LENGTH = 1024 * 1024 * 50  # 50MB

# Base OpenTelemetry namespace and attribute prefixes for the application.
BASE_OTEL_NAMESPACE = "qctrl/boulderopalscaleup/"
BASE_OTEL_ATTRIBUTE = "qctrl.boulderopalscaleup."

# Default gRPC retry policy for handling transient errors in gRPC communication.
DEFAULT_GRPC_RETRY_POLICY = {
    "methodConfig": [
        {
            "name": [{}],
            "retryPolicy": {
                "maxAttempts": 5,
                "initialBackoff": "0.6s",
                "maxBackoff": "20s",
                "backoffMultiplier": 3.0,
                "retryableStatusCodes": [
                    "UNAVAILABLE",
                    "RESOURCE_EXHAUSTED",
                ],
            },
        }
    ]
}
