# Copyright 2026 Q-CTRL. All rights reserved.
# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.


from pydantic import PrivateAttr

from .common import Routine


class CZCalibrationFixedCoupler(Routine):
    """
    Parameters for running a CZ calibration routine for fixed couplers.

    Attributes
    ----------
    transmons : tuple[str, str]
        The reference for the transmons to target.
    force_rerun : bool, optional
        Whether to rerun the entire routine regardless transmon's current calibration status.
        Defaults to False.

    """

    _routine_name: str = PrivateAttr("cz_calibration_fixed_coupler")

    transmons: tuple[str, str]
    force_rerun: bool = False
