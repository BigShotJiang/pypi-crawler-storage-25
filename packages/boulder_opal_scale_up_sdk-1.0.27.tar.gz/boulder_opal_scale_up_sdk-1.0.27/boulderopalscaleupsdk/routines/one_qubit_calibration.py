# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from typing import Literal

from pydantic import PrivateAttr

from boulderopalscaleupsdk.common.dtypes import Duration

from .common import Routine


class OneQubitCalibration(Routine):
    """
    Parameters for running one qubit calibration routine.

    Attributes
    ----------
    transmon : str
        The reference for the transmon to target.
    gate : "sx" or "x"
        The gate to calibrate.
    repetitions : list[int] or None, optional
        List of repetition counts for the calibration experiment.
        If not provided, a set of repetitions will be chosen based on the gate.
    force_rerun : bool, optional
        Whether to rerun the entire routine regardless transmon's current calibration status.
        Defaults to False.
    duration : Duration or "optimize" or "default", optional
        Duration for the drive waveform.
        - When a ``Duration`` is provided, the routine starts with a Power Rabi
          experiment using a DragCosineWaveform with this exact duration (no
          further duration optimization is performed).
        - ``"optimize"`` lets the routine pick an initial duration based on the defcal and then
          attempt to shorten it after a successful Power Rabi, based on the
          estimated minimum pulse duration.
        - ``"default"`` lets the routine inherit an initial duration without
          attempting any subsequent optimization.
        Defaults to ``"optimize"``.
    run_rb : bool, optional
        Whether to run a one-qubit randomized benchmarking experiment at the end
        of the calibration routine. Defaults to True.
    """

    _routine_name: str = PrivateAttr("one_qubit_calibration")

    transmon: str
    gate: Literal["x", "sx"]
    repetitions: list[int] | None = None
    force_rerun: bool = False
    duration: Duration | Literal["optimize", "default"] = "optimize"
    run_rb: bool = True
