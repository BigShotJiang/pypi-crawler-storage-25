# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.


from typing import Literal

from pydantic import PrivateAttr

from boulderopalscaleupsdk.common.dtypes import Duration, TimeUnit
from boulderopalscaleupsdk.experiments.common import Experiment
from boulderopalscaleupsdk.experiments.waveforms import ConstantWaveform


class FeedlineDiscovery(Experiment):
    """
    Parameters for running a feedline discovery experiment.

    Attributes
    ----------
    feedline : str
        The feedline to target in the routine.
    measure_waveform : ConstantWaveform or None, optional
        The waveform to use for the measurement pulse.
        If not provided, a default one will be used.
    recycle_delay : Duration, optional
        The delay between consecutive shots. Defaults to 200 ns.
    shot_count : int, optional
        The number of shots to take. Defaults to 100.
    run_mixer_calibration : bool, optional
        Whether to run mixer calibrations before running a program. Defaults to True.
    update : "auto" or "off" or "prompt", optional
        How the device should be updated after an experiment run. Defaults to auto.
    """

    _experiment_name: str = PrivateAttr("feedline_discovery")

    feedline: str
    measure_waveform: ConstantWaveform | None = None
    recycle_delay: Duration = Duration(200, TimeUnit.NS)
    shot_count: int = 100
    run_mixer_calibration: bool = True
    update: Literal["auto", "off", "prompt"] = "auto"
