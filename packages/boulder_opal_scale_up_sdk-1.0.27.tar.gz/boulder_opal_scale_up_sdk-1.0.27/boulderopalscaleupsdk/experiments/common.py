# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from abc import ABC, abstractmethod
from typing import Generic, Literal, Self, TypeVar, overload

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator

EXPERIMENT_REGISTRY: dict[str, Literal["Experiment"]] = {}


class Experiment(BaseModel):
    model_config = ConfigDict(extra="forbid")
    _experiment_name: str

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        name = str(cls.__private_attributes__["_experiment_name"].default)
        EXPERIMENT_REGISTRY[name] = "Experiment"

    @property
    def experiment_name(self) -> str:
        return self._experiment_name


class _Iterable(ABC, BaseModel):
    """Abstract base class for iterables."""

    model_config = ConfigDict(extra="forbid")

    @abstractmethod
    def to_numpy(self) -> np.ndarray: ...

    @overload
    def to_list(self, dtype: Literal["int"]) -> list[int]: ...
    @overload
    def to_list(self, dtype: Literal["float"]) -> list[float]: ...
    def to_list(self, dtype: Literal["int", "float"]) -> list[int] | list[float]:
        """
        Convert the iterable to a list of int or float.

        Parameters
        ----------
        dtype : Literal["int", "float"]
            Element type of the returned list.

        Returns
        -------
        list[int] | list[float]
            The values in the iterable.
        """
        target_type: type
        match dtype:
            case "int":
                target_type = int
            case "float":
                target_type = float
            case _:
                msg = f"dtype must be 'int' or 'float', got {dtype!r}"
                raise ValueError(msg)
        return self.to_numpy().astype(target_type).tolist()


_ValidatedT = TypeVar("_ValidatedT", bound=_Iterable)


class _QuasiIterable(BaseModel, Generic[_ValidatedT]):
    """Base class for iterables that have incomplete information."""

    model_config = ConfigDict(extra="forbid")

    @abstractmethod
    def to_validated(self, center: float) -> _ValidatedT: ...


class LinspaceIterable(_Iterable):
    """
    A linear space of float values.

    Creates evenly spaced values over a specified interval, similar to numpy.linspace.

    Attributes
    ----------
    dtype : Literal["linspace"]
        Type discriminator for serialization.
    start : float
        The starting value of the sequence.
    stop : float
        The final value of the sequence.
    count : int
        The number of values to generate. Defaults to 101.
    """

    dtype: Literal["linspace"] = "linspace"

    start: float
    stop: float
    count: int = Field(default=101, ge=1)

    def to_numpy(self) -> np.ndarray:
        return np.linspace(start=self.start, stop=self.stop, num=self.count)


class RangeIterable(_Iterable):
    """
    A range of values with a specified step.

    Creates values starting from 'start', incrementing by 'step', up to but not including 'stop'.

    Attributes
    ----------
    dtype : Literal["range"]
        Type discriminator for serialization.
    start : float
        The starting value of the sequence.
    stop : float
        The final value (exclusive) of the sequence.
    step : float
        The step size between consecutive values.
    """

    dtype: Literal["range"] = "range"

    start: float
    stop: float
    step: float

    @model_validator(mode="after")
    def _validate_step(self) -> Self:
        if self.step == 0:
            raise ValueError("step must be non-zero.")
        if self.start != self.stop and (self.stop - self.start) / self.step <= 0:
            raise ValueError("step has the wrong sign.")
        return self

    def to_numpy(self) -> np.ndarray:
        return np.arange(start=self.start, stop=self.stop, step=self.step)


class GeomspaceIterable(_Iterable):
    """
    A range of values spaced evenly on a logarithmic scale.

    Creates values that are evenly spaced on a logarithmic scale, similar to numpy.geomspace.

    Attributes
    ----------
    dtype : Literal["geomspace"]
        Type discriminator for serialization.
    start : float
        The starting value.
    stop : float
        The final value.
    count : int
        The number of values to generate.
    """

    dtype: Literal["geomspace"] = "geomspace"

    start: float
    stop: float
    count: int = Field(ge=1)

    @model_validator(mode="after")
    def _validate_start_stop(self) -> Self:
        if self.start == 0 or self.stop == 0:
            raise ValueError("start and stop must be non-zero.")
        if (self.start > 0) != (self.stop > 0):
            raise ValueError("start and stop must have the same sign.")
        return self

    def to_numpy(self) -> np.ndarray:
        return np.geomspace(start=self.start, stop=self.stop, num=self.count)


class LogspaceIterable(_Iterable):
    """
    A range of values spaced evenly on a logarithmic scale.

    Creates values that are evenly spaced on a logarithmic scale, similar to numpy.logspace.
    The start/stop values indicate the exponents of the initial/final values.

    Attributes
    ----------
    dtype : Literal["logspace"]
        Type discriminator for serialization.
    start : float
        The starting exponent. The first value will be base^start.
    stop : float
        The final exponent. The last value will be base^stop.
    count : int
        The number of values to generate. Defaults to 101.
    base : float
        The base of the logarithm. Must be greater than 0. Defaults to 10.
    """

    dtype: Literal["logspace"] = "logspace"

    start: float
    stop: float
    count: int = Field(default=101, ge=1)
    base: float = Field(default=10, gt=0)

    def to_numpy(self) -> np.ndarray:
        return np.logspace(start=self.start, stop=self.stop, num=self.count, base=self.base)


class _ValidatedCWSIterable(_Iterable):
    dtype: Literal["validated_cws"] = "validated_cws"

    center: float
    width: float = Field(gt=0)
    step: float = Field(gt=0)

    def to_numpy(self) -> np.ndarray:
        start = self.center - self.width / 2
        stop = self.center + self.width / 2
        return np.arange(start=start, stop=stop, step=self.step)


class CWSIterable(_QuasiIterable[_ValidatedCWSIterable]):
    """
    A range of linearly spaced values in center ± width/2.

    Creates values distributed around a central value within a specified width.

    Attributes
    ----------
    dtype : Literal["cws"]
        Type discriminator for serialization.
    center : float
        The central value around which values are distributed.
    width : float
        The total width of the distribution (center ± width/2).
    step : float
        The step size between consecutive values.
    """

    dtype: Literal["cws"] = "cws"

    center: float | None
    width: float = Field(gt=0)
    step: float = Field(gt=0)

    def to_validated(self, center: float) -> _ValidatedCWSIterable:
        return _ValidatedCWSIterable(
            center=self.center if self.center is not None else center,
            width=self.width,
            step=self.step,
        )


class _ValidatedHypIterable(_Iterable):
    dtype: Literal["validated_hyp"] = "validated_hyp"

    center: float
    width: float = Field(gt=0)
    count: int = Field(ge=1)

    def to_numpy(self) -> np.ndarray:
        x = np.linspace(start=-np.pi, stop=np.pi, num=self.count)
        return 0.5 * self.width * np.sinh(x) / np.pi + self.center


class HypIterable(_QuasiIterable[_ValidatedHypIterable]):
    """
    A hyperbolic iterable of values in center ± width/2.

    Creates values distributed around a central value with hyperbolic spacing,
    where points are more concentrated around the center and become more
    sparse towards the edges of the range.

    Attributes
    ----------
    dtype : Literal["hyp"]
        Type discriminator for serialization.
    center : float or None
        The central value around which values are distributed.
        If None, defaults to the expected value.
    width : float
        The total width of the distribution (center ± width/2).
    count : int
        The number of values to generate. Defaults to 51.
    """

    dtype: Literal["hyp"] = "hyp"

    center: float | None
    width: float = Field(gt=0)
    count: int = Field(default=51, ge=1)

    def to_validated(self, center: float) -> _ValidatedHypIterable:
        return _ValidatedHypIterable(
            center=self.center if self.center is not None else center,
            width=self.width,
            count=self.count,
        )


@overload
def to_list(
    iterable: list[int] | list[float] | _Iterable | _QuasiIterable[_ValidatedT],
    center: float,
    dtype: Literal["int"],
) -> list[int]: ...
@overload
def to_list(
    iterable: list[int] | list[float] | _Iterable | _QuasiIterable[_ValidatedT],
    center: float,
    dtype: Literal["float"],
) -> list[float]: ...
def to_list(
    iterable: list[int] | list[float] | _Iterable | _QuasiIterable[_ValidatedT],
    center: float,
    dtype: Literal["int", "float"],
) -> list[int] | list[float]:
    """
    Convert an iterable or list to a list of int or float.

    Parameters
    ----------
    iterable : list[int] | list[float] | _Iterable | _QuasiIterable
        The value to convert.
    center : float
        Fallback center value in case the iterable's center is not defined.
    dtype : Literal["int", "float"]
        Element type of the returned list.

    Returns
    -------
    list[int] | list[float]
        The values in the iterable.
    """
    match iterable:
        case list():
            match dtype:
                case "int":
                    return [int(x) for x in iterable]
                case "float":
                    return [float(x) for x in iterable]
                case _:
                    raise ValueError(f"dtype must be 'int' or 'float', got {dtype!r}")
        case _Iterable():
            validated = iterable
        case _QuasiIterable():
            validated = iterable.to_validated(center)
        case _:
            raise TypeError(f"Unsupported iterable type: {type(iterable)!r}")

    return validated.to_list(dtype=dtype)
