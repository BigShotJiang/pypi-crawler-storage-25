from typing import Literal

from pydantic import Field, PrivateAttr

from boulderopalscaleupsdk.common.dtypes import Duration, TimeUnit
from boulderopalscaleupsdk.experiments.common import Experiment


def _default_clifford_depths() -> list[int]:
    return [0] + [2**i for i in range(10)]


class TwoQubitIRB(Experiment):
    """
    Parameters for running a two-qubit interleaved randomized benchmarking experiment.

    Attributes
    ----------
    transmons : tuple[str, str]
        The pair of transmon qubits to target for benchmarking.
    gate : "cz"
        The two-qubit gate to benchmark. Currently, only "cz" is supported.
    clifford_depths : list of int, optional
        The list of Clifford depths to use.
        Defaults to a list starting with a 0, followed by powers of two from 1 up to 512.
    sequence_count : int, optional
        The number of random sequences to generate. Defaults to 10.
    shot_count : int, optional
        The number of shots per sequence to take. Defaults to 500.
    recycle_delay : Duration, optional
        The delay between consecutive shots. Defaults to 200,000 ns.
    seed : int or None, optional
        The random seed for sequence generation. If not provided, a random seed will be used.
    update : "auto" or "off" or "prompt", optional
        How the device should be updated after an experiment run. Defaults to auto.
    """

    _experiment_name: str = PrivateAttr("two_qubit_irb")
    transmons: tuple[str, str]
    gate: Literal["cz"] = "cz"
    clifford_depths: list[int] = Field(default_factory=_default_clifford_depths)
    sequence_count: int = 10
    shot_count: int = 500
    recycle_delay: Duration = Duration(value=200_000, unit=TimeUnit.NS)
    seed: int | None = None
    update: Literal["auto", "off", "prompt"] = "auto"
