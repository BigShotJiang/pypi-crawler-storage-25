# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

"""
TWPA Calibration Experiment.
"""

from __future__ import annotations

from pydantic import PrivateAttr

from .common import CWSIterable, Experiment, HypIterable, LinspaceIterable, RangeIterable
from .waveforms import ConstantWaveform  # noqa: TC001


class TWPACalibration(Experiment):
    """
    Parameters for running a TWPA calibration experiment.

    Attributes
    ----------
    resonator : str
        The reference for the resonator to target.
    twpa : str
        The name of the TWPA element to use (e.g. 'twpa0', 'twpa1', 'twpa2').
    pump_frequencies : list[int] or LinspaceIterable or RangeIterable or CWSIterable \
                       or HypIterable
        The TWPA pump frequencies to sweep over, in Hz.
    pump_powers_dbm : list[float]
        The TWPA pump powers to sweep over, in dBm.
    probe_frequencies : list[int] or LinspaceIterable or RangeIterable or CWSIterable \
                        or HypIterable or None, optional
        The readout probe frequencies to sweep over, in Hz.
        Defaults to a scan around the readout frequency.
    measure_waveform : ConstantWaveform or None, optional
        The waveform to use for the measurement pulse.
        Defaults to the measurement defcal.
    duration_ns : int, optional
        Duration of the TWPA pump tone in nanoseconds. Defaults to 16,000 ns.
    recycle_delay_ns : int, optional
        The delay between consecutive shots, in nanoseconds. Defaults to 10,000 ns.
    shot_count : int, optional
        The number of shots to take. Defaults to 100.
    run_mixer_calibration : bool, optional
        Whether to run mixer calibrations before running a program. Defaults to False.
    """

    _experiment_name: str = PrivateAttr("twpa_calibration")

    resonator: str
    twpa: str
    pump_frequencies: list[int] | LinspaceIterable | RangeIterable | CWSIterable | HypIterable
    pump_powers_dbm: list[float]
    probe_frequencies: (
        list[int] | LinspaceIterable | RangeIterable | CWSIterable | HypIterable | None
    ) = None
    measure_waveform: ConstantWaveform | None = None
    duration_ns: int = 16_000
    recycle_delay_ns: int = 10_000
    shot_count: int = 100
    run_mixer_calibration: bool = False
