# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.


from pydantic import PrivateAttr

from .common import (
    LinspaceIterable,
)
from .transmon_spectroscopy import TransmonSpectroscopy


class TransmonFastFluxSpectroscopy(TransmonSpectroscopy):
    """
    Parameters for running a transmon fast-flux spectroscopy experiment.

    Attributes
    ----------
    transmon : str
        The reference for the transmon to target.
    frequencies : LinspaceIterable or RangeIterable or CWSIterable, optional
        The frequencies at which to scan, in Hz.
        Defaults to a scan around the transmon frequency.
    recycle_delay_ns : int, optional
        The delay between consecutive shots, in nanoseconds. Defaults to 50,000 ns.
    shot_count : int, optional
        The number of shots to take. Defaults to 400.
    spectroscopy_waveform : ConstantWaveform or None, optional
        The waveform to use in the spectroscopy pulse.
        Defaults to the transmon_spec defcal.
    measure_waveform : ConstantWaveform or None, optional
        The waveform to use for the measurement pulse.
        Defaults to the measurement defcal.
    vps : LinspaceIterable
        The flux pulse voltage amplitudes to sweep over.
    flux_pulse_extra_duration_ns : int, optional
        Additional duration for the flux pulse in nanoseconds.
        Defaults to 100 ns.
    polynomial_order : int, optional
        The polynomial order for data fitting analysis.
        Defaults to 6.
    run_mixer_calibration : bool, optional
        Whether to run mixer calibrations before running a program. Defaults to False.
    update : "auto" or "off" or "prompt", optional
        How the device should be updated after an experiment run. Defaults to auto.
    """

    _experiment_name: str = PrivateAttr("transmon_fast_flux_spectroscopy")

    # fast-flux specific
    vps: LinspaceIterable
    flux_pulse_extra_duration_ns: int = 100
    polynomial_order: int = 6
