# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.
from __future__ import annotations

from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, ParamSpec, TypeVar

from opentelemetry import trace
from opentelemetry.trace import get_current_span

tracer = trace.get_tracer(__name__)

P = ParamSpec("P")
T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Awaitable[Any]])


def traced(name: str | None = None) -> Callable[[Callable[P, T]], Callable[P, T]]:
    """Sync OpenTelemetry decorator. Use for normal (non-async) functions."""

    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        span_name = name or f"{func.__module__}.{func.__qualname__}"

        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            with tracer.start_as_current_span(span_name) as span:
                span.set_attribute("code.function.name", f"{func.__module__}.{func.__qualname__}")
                return func(*args, **kwargs)

        return wrapper

    return decorator


def traced_async(name: str | None = None) -> Callable[[F], F]:
    """Async OpenTelemetry decorator for async functions (async def)."""

    def decorator(func: F) -> F:
        span_name = name or f"{func.__module__}.{func.__qualname__}"

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            with tracer.start_as_current_span(span_name) as span:
                span.set_attribute("code.function.name", f"{func.__module__}.{func.__qualname__}")
                return await func(*args, **kwargs)

        return wrapper  # type: ignore[return-value]

    return decorator  # type: ignore[return-value]


__all__ = ["get_current_span", "traced", "traced_async", "tracer"]
