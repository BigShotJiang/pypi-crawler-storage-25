# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from typing import Literal

from pydantic import BaseModel


class DefCalData(BaseModel):
    gate: str
    addr: list[str]
    program: str
    status: Literal["calibrated", "uncalibrated"]


class IQSample(BaseModel):
    i: list[float]
    q: list[float]


class PulseInstruction(BaseModel):
    start_time_ns: int
    envelope: IQSample
    frequency: float
    phase: float


class ControlInstruction(BaseModel):
    pulse: PulseInstruction
    dtype: Literal["control"] = "control"


class ProbeInstruction(BaseModel):
    probe: PulseInstruction
    dtype: Literal["probe"] = "probe"


class KernelInstruction(BaseModel):
    pulse: PulseInstruction
    scale: float
    dtype: Literal["kernel"] = "kernel"


DefcalInstruction = ControlInstruction | ProbeInstruction | KernelInstruction

Port = str


class DefcalInformation(BaseModel):
    qubit_addr: tuple[str, ...]
    gate: str
    program: str
    schedule: dict[Port, list[DefcalInstruction]]  # schedule per port
