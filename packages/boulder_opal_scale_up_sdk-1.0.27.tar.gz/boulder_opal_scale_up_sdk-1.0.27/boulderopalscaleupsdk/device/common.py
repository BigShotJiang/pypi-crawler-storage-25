# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.
from collections.abc import Callable
from typing import Annotated, Any, Generic, TypeVar, Union, get_args, get_origin

from pydantic import BaseModel, TypeAdapter

from boulderopalscaleupsdk.device.processor import (
    ComponentParameter,
)

TraitT = TypeVar("TraitT", bound=str)
JsonDict = dict[str, Any]
ExtraType = JsonDict | Callable[[JsonDict], None] | None

ComponentRef = str


def _extract_component_parameter_data(parameter: ComponentParameter) -> dict[str, Any]:
    data = {
        "value": parameter.value,
        "err_minus": parameter.err_minus,
        "err_plus": parameter.err_plus,
        "calibration_status": parameter.calibration_status,
    }

    json_schema_extra = getattr(parameter, "json_schema_extra", None)
    if json_schema_extra is not None:
        if isinstance(json_schema_extra, dict):
            data["display"] = json_schema_extra.get("display", {})
        elif callable(json_schema_extra):
            data["display"] = json_schema_extra({"display": "value"})

    return data


class Component(BaseModel, Generic[TraitT]):
    traits: list[TraitT]

    def get_summary_dict(self) -> dict[str, dict[str, Any]]:
        summary_dict = {}
        for field_name, field_value in self:
            if field_name in ["dtype", "traits"]:
                continue

            tmp: dict[str, Any] = {}
            value: list | ComponentParameter | None = field_value
            match value:
                case ComponentParameter() as parameter:
                    tmp = _extract_component_parameter_data(parameter)
                case list() as parameter:
                    tmp["value"] = [
                        _extract_component_parameter_data(item)
                        if isinstance(item, ComponentParameter)
                        else item
                        for item in parameter
                    ]
                case None:
                    tmp["value"] = None

            summary_dict[field_name] = tmp
        return summary_dict


class ComponentUpdate(BaseModel): ...


class ProcessorUpdate(BaseModel): ...


ComponentT = TypeVar("ComponentT", bound=Component)


def coerce_component_params(
    component: ComponentT,
) -> ComponentT:
    annotations = component.__annotations__

    for field_name in component.model_fields:
        expected_type = annotations.get(field_name)
        value = getattr(component, field_name)

        if not isinstance(value, ComponentParameter):
            continue

        def _unwrap_annotated(tp):
            """Unwrap Annotated[...] -> original type."""
            if get_origin(tp) is Annotated:
                return get_args(tp)[0]
            return tp

        def _unwrap_optional(tp):
            """Unwrap Optional[T] -> T."""
            if get_origin(tp) is Union:
                args = [t for t in get_args(tp) if t is not type(None)]
                if len(args) == 1:
                    return args[0]
            return tp

        expected_type = _unwrap_optional(expected_type)
        expected_type = _unwrap_annotated(expected_type)

        if not isinstance(expected_type, type) or not issubclass(expected_type, ComponentParameter):
            continue

        try:
            dumped = TypeAdapter(type(value)).dump_python(value)
            coerced = expected_type(**dumped)
            setattr(component, field_name, coerced)
        except Exception as e:
            raise ValueError(
                f"Failed to coerce field '{field_name}' of type "
                "'{expected_type}' with value '{value}': {e}.",
            ) from e

    return component
