# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.


import enum


class ControllerType(str, enum.Enum):
    QUANTUM_MACHINES = "quantum_machines"
    QBLOX = "qblox"


class Backend(str, enum.Enum):
    QUA = "QUA"
    QBLOX = "QBLOX"
    OPENQASM = "OPENQASM"
    QBLOX_Q1ASM = "QBLOX_Q1ASM"
