# Copyright 2026 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from copy import deepcopy
from typing import Any, Literal

from pydantic import BaseModel, Field

from boulderopalscaleupsdk.common.dtypes import (
    Duration,
    TimeUnit,
)
from boulderopalscaleupsdk.device.common import Component, ComponentRef, coerce_component_params
from boulderopalscaleupsdk.device.processor import (
    ComponentParameter,
    FloatComponentParameter,
)


# Retrieval data models
class Transmon(Component[Literal["tunable"]]):
    """
    Transmon qubit component.

    Attributes
    ----------
    freq_01 : FloatComponentParameter
        Transmon frequency in MHz.
    anharm : FloatComponentParameter
        Transmon anharmonicity in MHz.
    thermal_population : FloatComponentParameter
        Thermal population as a unitless value.
    t1 : ComponentParameter[Duration]
        T1 parameter in microseconds.
    t2 : ComponentParameter[Duration]
        T2 parameter in microseconds.
    t2_echo : ComponentParameter[Duration]
        T2 echo parameter in microseconds.
    x_vp : FloatComponentParameter
        X gate amplitude in Volts.
    sx_vp : FloatComponentParameter
        SZ gate amplitude in Volts.
    x_ef_vp : FloatComponentParameter
        X ef gate amplitude in Volts.
    sx_ef_vp : FloatComponentParameter
        SX ef gate amplitude in Volts.
    dc_bias : FloatComponentParameter
        DC bias in Volts.
    bias_offset : FloatComponentParameter
        Bias offset in Volts.
    bias_period : FloatComponentParameter
        Bias period in Volts.
    gate_fidelity : FloatComponentParameter
        Gate fidelity as a unitless value.
    """

    dtype: Literal["transmon"] = "transmon"
    traits: list[Literal["tunable"]] = Field(default=["tunable"])

    freq_01: FloatComponentParameter = Field(
        default=ComponentParameter(value=(0.0)),
        json_schema_extra={
            "display": {"label": "freq_01", "title": "Frequency", "unit": "MHz", "scale": 1e-6},
        },
    )
    anharm: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "anharm", "title": "Anharmonicity", "unit": "MHz", "scale": 1e-6},
        },
    )
    thermal_population: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "thermal_population",
                "title": "Thermal population",
                "unit": "",
                "scale": 1,
            },
        },
    )
    t1: ComponentParameter[Duration] = Field(
        default=ComponentParameter(value=Duration(0, TimeUnit.NS)),
        json_schema_extra={"display": {"label": "t1", "title": "T1", "unit": "µs", "scale": 1e6}},
    )
    t2: ComponentParameter[Duration] = Field(
        default=ComponentParameter(value=Duration(0, TimeUnit.NS)),
        json_schema_extra={"display": {"label": "t2", "title": "T2", "unit": "µs", "scale": 1e6}},
    )
    t2_echo: ComponentParameter[Duration] = Field(
        default=ComponentParameter(value=Duration(0, TimeUnit.NS)),
        json_schema_extra={
            "display": {"label": "t2_echo", "title": "T2 echo", "unit": "µs", "scale": 1e6},
        },
    )
    x_vp: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "x_vp", "title": "X gate amplitude", "unit": "V", "scale": 1},
        },
    )
    sx_vp: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "sx_vp", "title": "SX gate amplitude", "unit": "V", "scale": 1},
        },
    )
    x_ef_vp: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "x_ef_vp",
                "title": "X EF gate amplitude",
                "unit": "V",
                "scale": 1,
            },
        },
    )
    sx_ef_vp: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "sx_ef_vp",
                "title": "SX EF gate amplitude",
                "unit": "V",
                "scale": 1,
            },
        },
    )

    # Tunable transmon parameters.
    dc_bias: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "dc_bias", "title": "DC bias", "unit": "V", "scale": 1},
        },
    )
    bias_offset: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "bias_offset", "title": "Bias offset", "unit": "V", "scale": 1},
        },
    )
    bias_period: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "bias_period", "title": "Bias period", "unit": "V", "scale": 1},
        },
    )

    gate_fidelity: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "gate_fidelity", "title": "Gate fidelity", "unit": "", "scale": 1},
        },
    )


class Resonator(Component[Literal["readout"]]):
    """
    Resonator qubit component.

    Attributes
    ----------
    frequency_high : FloatComponentParameter
        Resonator frequency in the high-voltage regime, in MHz.
    frequency_low : FloatComponentParameter
        Resonator frequency in the low-voltage regime, in MHz.
    kappa_high : FloatComponentParameter
        Kappa in the high-voltage regime, in MHz.
    kappa_low : FloatComponentParameter
        Kappa in the low-voltage regime, in MHz.
    vp_high: FloatComponentParameter
        VP in the high-voltage regime, in Volts.
    vp_low : FloatComponentParameter
        VP in the low-voltage regime, in Volts.
    purcell_coupling: FloatComponentParameter
        Purcell filter coupling, in MHz.
    purcell_frequency: FloatComponentParameter
        Purcell filter frequency, in MHz.
    """

    dtype: Literal["resonator"] = "resonator"
    traits: list[Literal["readout"]] = Field(default=["readout"])

    frequency_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "frequency_high",
                "title": "Frequency (high power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )
    frequency_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "frequency_low",
                "title": "Frequency (low power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )
    kappa_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "kappa_low",
                "title": "Kappa (low power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )
    kappa_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "kappa_high",
                "title": "Kappa (high power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )
    vp_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "vp_low",
                "title": "Voltage point (low power)",
                "unit": "V",
                "scale": 1,
            },
        },
    )
    vp_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "vp_high",
                "title": "Voltage point (high power)",
                "unit": "V",
                "scale": 1,
            },
        },
    )
    purcell_coupling: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "purcell_coupling",
                "title": "Purcell coupling",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )
    purcell_frequency: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "purcell_frequency",
                "title": "Purcell frequency",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )


class Coupler(Component[Literal["tunable"]]):
    dtype: Literal["coupler"] = "coupler"
    traits: list[Literal["tunable"]] = Field(default=["tunable"])

    # Tunable coupler parameters
    dc_bias: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "dc_bias", "title": "DC bias", "unit": "V", "scale": 1},
        },
    )
    bias_offset: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "bias_offset", "title": "Bias offset", "unit": "V", "scale": 1},
        },
    )
    bias_period: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "bias_period", "title": "Bias period", "unit": "V", "scale": 1},
        },
    )
    freq_01: FloatComponentParameter = Field(
        default=ComponentParameter(value=(0.0)),
        json_schema_extra={
            "display": {"label": "freq_01", "title": "Frequency", "unit": "MHz", "scale": 1e-6},
        },
    )
    anharm: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "anharm", "title": "Anharmonicity", "unit": "MHz", "scale": 1e-6},
        },
    )


class Port(Component[Literal["drive", "readout", "flux"]]):
    dtype: Literal["port"] = "port"
    traits: list[Literal["flux", "drive", "readout"]] = Field(
        default=["drive", "readout", "flux"],
    )


class PurcellFilter(Component[Literal["purcell_filter"]]):
    dtype: Literal["purcell_filter"] = "purcell_filter"
    traits: list = Field(default=[])

    frequency_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "frequency_low",
                "title": "Frequency (low)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )

    frequency_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "frequency_high",
                "title": "Frequency (high)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )

    kappa_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "kappa_low",
                "title": "Kappa (low power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )

    kappa_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "kappa_high",
                "title": "Kappa (high power)",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )

    vp_low: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "vp_low",
                "title": "Voltage point (low power)",
                "unit": "V",
                "scale": 1,
            },
        },
    )

    vp_high: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {
                "label": "vp_high",
                "title": "Voltage point (high power)",
                "unit": "V",
                "scale": 1,
            },
        },
    )


class ObservedResonance(BaseModel):
    frequency: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "frequency", "title": "Frequency", "unit": "MHz", "scale": 1e-6},
        },
    )
    kappa: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "kappa", "title": "Kappa", "unit": "MHz", "scale": 1e-6},
        },
    )


class Feedline(Component[Literal["feedline"]]):
    dtype: Literal["feedline"] = "feedline"
    traits: list = Field(default=[])
    phase_delay: ComponentParameter[Duration] = Field(
        default_factory=lambda: ComponentParameter(value=Duration(0, TimeUnit.NS)),
        description="Phase delay due to signal propagation through the feedline.",
        json_schema_extra={
            "display": {"label": "phase_delay", "title": "Phase delay", "unit": "s", "scale": 1e-9},
        },
    )
    observed_resonances: list[ObservedResonance] = Field(
        default_factory=list,
        description="List of observed resonances on the feedline. "
        "Each resonance is represented as an ObservedResonance object with frequency value "
        "and optional metadata such as quality factor.",
        json_schema_extra={
            "display": {"label": "observed_resonances", "title": "Observed resonances"},
        },
    )


class TWPA(Component[Literal["twpa"]]):
    dtype: Literal["twpa"] = "twpa"
    traits: list = Field(default=[])

    impedance: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "impedance", "title": "Impedance", "unit": "Ohm", "scale": 1},
        },
    )

    # Tunable TWPA parameters
    pump_power: FloatComponentParameter = Field(
        default=ComponentParameter(value=0.0),
        json_schema_extra={
            "display": {"label": "pump_power", "title": "Pump power", "unit": "dBm", "scale": 1},
        },
    )
    pump_freq: FloatComponentParameter = Field(
        default=ComponentParameter(value=(0.0)),
        json_schema_extra={
            "display": {
                "label": "pump_freq",
                "title": "Pump frequency",
                "unit": "MHz",
                "scale": 1e-6,
            },
        },
    )


SuperconductingComponentType = (
    Transmon | Resonator | Port | Feedline | PurcellFilter | Coupler | TWPA
)


class Edge(BaseModel):
    dtype: Literal["capacitive-coupling", "inductive-coupling"]
    u: str
    v: str


class TemplateParam(BaseModel):
    template: str
    vars: dict[int, list[str]]


class ProcessorTemplate(BaseModel):
    elements: dict[str, SuperconductingComponentType]
    edges: list[Edge]


class SuperconductingProcessorTemplate(BaseModel):
    qpu_model: str
    build: list[TemplateParam]
    templates: dict[str, ProcessorTemplate]
    device_parameters: dict[str, SuperconductingComponentType] = Field(
        default={},
    )


class SuperconductingProcessor(BaseModel):
    """
    Superconducting processor model.

    Attributes
    ----------
    qpu_model : str
        The model identifier for the superconducting QPU.
    nodes : dict[ComponentRef, SuperconductingComponentType]
        A dictionary mapping component references to their parameters.
    edges : list[Edge]
        A list of edges representing connections between components.
    """

    # TODO: Fast5, remove default after SCUP-2205
    qpu_model: str = Field(default="quantware-soprano-a")
    nodes: dict[ComponentRef, SuperconductingComponentType]
    edges: list[Edge]

    @staticmethod
    def from_template(template: SuperconductingProcessorTemplate) -> "SuperconductingProcessor":
        _qpu = SuperconductingProcessor(qpu_model=template.qpu_model, nodes={}, edges=[])
        for build in template.build:
            qpu_template = template.templates[build.template]
            for idx, subs in build.vars.items():
                for sub in subs:
                    for k, template_params in qpu_template.elements.items():
                        ref = k.replace(f"${idx}", sub)
                        params = template.device_parameters.get(ref)
                        p = deepcopy(params or template_params)
                        p.traits = template_params.traits  # type: ignore[reportAttributeAccessIssue]
                        p = coerce_component_params(p)
                        _qpu.nodes[ref] = p

                    for edge in qpu_template.edges:
                        _qpu.edges.append(
                            Edge(
                                u=edge.u.replace(f"${idx}", sub),
                                v=edge.v.replace(f"${idx}", sub),
                                dtype=edge.dtype,
                            ),
                        )
        return _qpu

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "SuperconductingProcessor":
        """
        Deserializes a SuperconductingProcessor instance from a dictionary.
        """
        return SuperconductingProcessor.model_validate(data)

    def to_dict(self) -> dict[str, Any]:
        """
        Serializes the SuperconductingProcessor instance into a dictionary.
        """
        return self.model_dump()

    def update_component(self, component_id: str, **params: Any) -> None:  # noqa: C901
        """
        Update the parameters of a specific component.

        Parameters
        ----------
        component_id : str
            The ID of the component to update.
        **params : Any
            The parameters to update, provided as keyword arguments.

        Raises
        ------
        KeyError
            If the component with the given ID does not exist.
        ValueError
            If the component does not support the provided parameters.
        ValidationError
            If the updated parameters do not conform to the expected schema.
        """
        if component_id not in self.nodes:
            raise KeyError(f"Component with ID '{component_id}' does not exist.")

        component = self.nodes[component_id]
        updated_component = deepcopy(component)

        for k, v in params.items():
            component_param = getattr(updated_component, k)

            # Stopgap solution to allow updating observed resonances on feedlines.
            if not isinstance(component_param, ComponentParameter) and (
                not isinstance(component_param, list)
                or not all(isinstance(item, ObservedResonance) for item in component_param)
            ):
                raise ValueError(f"Invalid or unexpected parameter for {type(component)}.")

            if k in ["dtype", "traits"]:
                raise ValueError("Invalid attempt to modify component type or traits.")

            if v is None:
                continue

            match v:
                case ComponentParameter():
                    setattr(updated_component, k, v)
                case list():
                    # observed resonances is the only list parameter currently.
                    resonances = []
                    for item in v:
                        match item:
                            case dict():
                                resonances.append(ObservedResonance.model_validate(item))
                            case ObservedResonance():
                                resonances.append(item)
                            case _:
                                raise ValueError(
                                    f"Invalid item type in list for parameter '{k}': {type(item)}",
                                )
                    setattr(updated_component, k, resonances)
                case _:
                    assert isinstance(component_param, ComponentParameter)
                    component_param.update(
                        value=v,
                        err_minus=None,
                        err_plus=None,
                        calibration_status="unmeasured",
                    )
                    setattr(updated_component, k, component_param)

        self.nodes[component_id] = type(component).model_validate(updated_component.model_dump())

    def get_component(self, component_id: str) -> SuperconductingComponentType:
        """
        Retrieve the parameters of a specific component.

        Parameters
        ----------
        component_id : str
            The ID of the component.

        Returns
        -------
        dict
            A dictionary of the component's parameters.
        """
        return self.nodes[component_id]
