import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import ParamSpec, Protocol, TypeVar

import grpc

from boulderopalscaleupsdk.errors import ScaleUpServerError

P = ParamSpec("P")
T = TypeVar("T")
LOG = logging.getLogger(__name__)


class GRPCReconnectionSpec(Protocol):
    async def channel_ready(self) -> None: ...

    async def reconnect(self) -> None: ...

    @staticmethod
    def create(
        channel_ready_fn: Callable[[], Awaitable[None]],
        reconnect_fn: Callable[[], Awaitable[None]],
    ) -> "GRPCReconnectionSpec":
        class _GRPCReconnector(GRPCReconnectionSpec):
            async def channel_ready(self) -> None:
                await channel_ready_fn()

            async def reconnect(self) -> None:
                await reconnect_fn()

        return _GRPCReconnector()


def grpc_reconnect(
    reconnector: GRPCReconnectionSpec,
    retryable_codes: list[grpc.StatusCode] | None = None,
    max_reconnection_attempts: int = 5,
    exponential_backoff_base: float = 2.0,
    initial_backoff: float = 1.0,
) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, Awaitable[T]]]:
    if retryable_codes is None:
        retryable_codes = [
            grpc.StatusCode.UNAVAILABLE,
            grpc.StatusCode.DEADLINE_EXCEEDED,
            grpc.StatusCode.UNKNOWN,
        ]

    def wrapper(fn: Callable[P, Awaitable[T]]) -> Callable[P, Awaitable[T]]:
        async def wrapped_fn(*args: P.args, **kwargs: P.kwargs) -> T:
            attempts = 0
            while True:
                attempts += 1
                try:
                    return await fn(*args, **kwargs)
                except grpc.aio.AioRpcError as err:
                    if err.code() not in retryable_codes:
                        raise

                    if attempts >= max_reconnection_attempts:
                        raise ScaleUpServerError(
                            f"Failed to reconnect after {max_reconnection_attempts} attempts.",
                        ) from err

                    LOG.warning(
                        "Call failed with code %s. Attempting to reconnect... (%d/%d)",
                        err.code(),
                        attempts,
                        max_reconnection_attempts,
                    )

                    try:
                        await asyncio.wait_for(reconnector.channel_ready(), timeout=5)
                    except TimeoutError:
                        await reconnector.reconnect()
                    _delay = initial_backoff * (exponential_backoff_base ** (attempts - 1))
                    await asyncio.sleep(_delay)

        return wrapped_fn

    return wrapper
