from __future__ import annotations

import logging

import httpx

from kabigon.domain.errors import LoaderContentError
from kabigon.domain.loader import Loader

from .html_extractors import extract_article_body_from_json_ld
from .html_extractors import extract_first_tag_subtree
from .url_match import ensure_domain_suffix
from .utils import html_to_markdown

logger = logging.getLogger(__name__)

BBC_DOMAIN_SUFFIX = "bbc.com"

_IGNORED_TAGS = {
    "script",
    "style",
    "noscript",
    "svg",
}


def check_bbc_url(url: str) -> None:
    ensure_domain_suffix(url, BBC_DOMAIN_SUFFIX, loader_name="BBCLoader", source_name="BBC")


def extract_bbc_main_html(html: str) -> str:
    return extract_first_tag_subtree(html, ("article", "main"), ignored_tags=_IGNORED_TAGS)


class BBCLoader(Loader):
    def __init__(self, headers: dict[str, str] | None = None) -> None:
        self.headers = headers or {
            "Accept": "text/html,application/xhtml+xml",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",  # noqa: E501
        }

    async def load(self, url: str) -> str:
        check_bbc_url(url)
        logger.debug("[BBCLoader] Fetching URL: %s", url)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, headers=self.headers, follow_redirects=True)
                response.raise_for_status()
        except httpx.HTTPError as e:
            logger.warning("[BBCLoader] HTTP error: %s", e)
            raise LoaderContentError("BBCLoader", url, f"HTTP request failed: {e}") from e

        content_type = response.headers.get("content-type", "").lower()
        if "html" not in content_type:
            raise LoaderContentError("BBCLoader", url, f"Expected HTML content, got: {content_type!r}")

        json_ld_body = extract_article_body_from_json_ld(response.text)
        if json_ld_body:
            logger.debug("[BBCLoader] Extracted articleBody from JSON-LD (%s chars)", len(json_ld_body))
            return json_ld_body

        main_html = extract_bbc_main_html(response.text)
        result = html_to_markdown(main_html)
        logger.debug("[BBCLoader] Extracted article HTML content (%s chars)", len(result))
        return result
