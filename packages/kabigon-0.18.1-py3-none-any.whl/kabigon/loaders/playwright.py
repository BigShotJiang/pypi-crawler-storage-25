import logging
from typing import Literal

from playwright.async_api import TimeoutError
from playwright.async_api import async_playwright

from kabigon.domain.errors import LoaderTimeoutError
from kabigon.domain.loader import Loader

from .utils import html_to_markdown

logger = logging.getLogger(__name__)


class PlaywrightLoader(Loader):
    def __init__(
        self,
        timeout: float | None = 0,
        wait_until: Literal["commit", "domcontentloaded", "load", "networkidle"] | None = None,
        browser_headless: bool = True,
    ) -> None:
        self.timeout = timeout
        self.wait_until: Literal["commit", "domcontentloaded", "load", "networkidle"] | None = wait_until
        self.browser_headless = browser_headless

    async def load(self, url: str) -> str:
        logger.debug(
            "[PlaywrightLoader] Loading URL: %s (timeout=%s, wait_until=%s)",
            url,
            self.timeout,
            self.wait_until,
        )

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.browser_headless)
            context = None
            content = ""

            try:
                context = await browser.new_context()
                page = await context.new_page()
                if self.wait_until is None:
                    await page.goto(url, timeout=self.timeout)
                else:
                    await page.goto(url, timeout=self.timeout, wait_until=self.wait_until)
                logger.debug("[PlaywrightLoader] Successfully loaded page")
            except TimeoutError as e:
                timeout_seconds = (self.timeout or 0) / 1000 if self.timeout else 30
                logger.warning("[PlaywrightLoader] Timeout after %ss: %s", timeout_seconds, url)
                raise LoaderTimeoutError(
                    "PlaywrightLoader",
                    url,
                    timeout_seconds,
                    "The page took too long to load. Try increasing the timeout or using a faster wait_until option.",
                ) from e
            else:
                content = await page.content()

            finally:
                if context is not None:
                    await context.close()
                await browser.close()

            result = html_to_markdown(content)
            logger.debug("[PlaywrightLoader] Successfully extracted content (%s chars)", len(result))
            return result
