"""
Story Sharing Service

Manages granular sharing of life story timelines. Supports full timeline,
period-based, event-based, theme-based, and person-based sharing scopes.
Enforces sensitive event exclusion.

CRITICAL: This is a framework capability — NO eldercare-specific logic.
The feature emits SharingPermission rows; the *host* decides who can view
based on its own permission model. We define a simple permission_level field
but don't enforce any specific hierarchy.
"""

import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import SharingPermission, Event, Timeline
from .exceptions import TimelineNotFoundError

logger = logging.getLogger(__name__)


class StorySharingService:
    """Service for managing story timeline sharing.

    Decoupled from eldercare — no permission hierarchy enforcement.
    The host determines who has access and at what level.
    """

    def __init__(self, session_factory):
        """Initialize sharing service.

        Args:
            session_factory: AsyncSessionFactory for database access
        """
        self._sf = session_factory

    # ------------------------------------------------------------------
    # Grant / revoke
    # ------------------------------------------------------------------

    async def grant_access(
        self,
        timeline_id: uuid.UUID,
        circle_member_id: uuid.UUID,
        granted_by: uuid.UUID,
        tenant_id: uuid.UUID,
        scope: str = "full_timeline",
        scope_filter: Optional[Dict[str, Any]] = None,
    ) -> SharingPermission:
        """Grant a circle member access to timeline content.

        Args:
            timeline_id: The timeline to share
            circle_member_id: Who receives access (UUID, not DID)
            granted_by: Who granted access (UUID, not DID)
            tenant_id: Tenant context for the operation
            scope: Sharing scope — full_timeline, period, event, theme, person
            scope_filter: Optional filter params (year ranges, event IDs, etc.)

        Returns:
            The created SharingPermission entity
        """
        with TenantContext.use(tenant_id):
            # Verify timeline exists
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = result.scalar_one_or_none()
                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

            # Create sharing permission
            async with self._sf.write_session() as session:
                permission = SharingPermission(
                    timeline_id=timeline_id,
                    tenant_id=tenant_id,
                    circle_member_id=circle_member_id,
                    granted_by=granted_by,
                    scope=scope,
                    scope_filter=scope_filter,
                )
                session.add(permission)
                await session.commit()
                await session.refresh(permission)

                logger.info(
                    f"Sharing granted: timeline={timeline_id} member={circle_member_id} scope={scope}"
                )
                return permission

    async def revoke_access(
        self,
        sharing_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> bool:
        """Revoke a sharing grant. Sets revoked_at, access is removed immediately.

        Args:
            sharing_id: The sharing permission to revoke
            tenant_id: Tenant context for the operation

        Returns:
            True if revoked, False if not found or already revoked
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(SharingPermission).where(SharingPermission.id == sharing_id)
                )
                sharing = result.scalar_one_or_none()

                if not sharing:
                    return False
                if sharing.revoked_at is not None:
                    logger.warning(f"Sharing {sharing_id} already revoked")
                    return False

                sharing.revoked_at = datetime.utcnow()
                await session.commit()

                logger.info(f"Sharing revoked: id={sharing_id}")
                return True

    # ------------------------------------------------------------------
    # Query grants
    # ------------------------------------------------------------------

    async def list_sharing_grants(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        active_only: bool = True,
    ) -> List[SharingPermission]:
        """List all sharing grants for a timeline.

        Args:
            timeline_id: The timeline to query
            tenant_id: Tenant context
            active_only: If True, only return non-revoked grants

        Returns:
            List of SharingPermission entities
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                stmt = select(SharingPermission).where(
                    SharingPermission.timeline_id == timeline_id
                )

                if active_only:
                    stmt = stmt.where(SharingPermission.revoked_at.is_(None))

                result = await session.execute(stmt)
                return list(result.scalars().all())

    async def check_access(
        self,
        timeline_id: uuid.UUID,
        circle_member_id: uuid.UUID,
        tenant_id: uuid.UUID,
        event_id: Optional[uuid.UUID] = None,
    ) -> bool:
        """Check whether a circle member can access a timeline (or specific event).

        Args:
            timeline_id: The timeline to check
            circle_member_id: The member requesting access
            tenant_id: Tenant context
            event_id: Optional specific event to check

        Returns:
            True if the member has at least one active grant that covers
            the requested content and the event is not sensitive
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                # Get active grants
                result = await session.execute(
                    select(SharingPermission).where(
                        and_(
                            SharingPermission.timeline_id == timeline_id,
                            SharingPermission.circle_member_id == circle_member_id,
                            SharingPermission.revoked_at.is_(None),
                        )
                    )
                )
                grants = list(result.scalars().all())

                if not grants:
                    return False

                # If no specific event requested, just confirm any active grant
                if event_id is None:
                    return True

                # Check the specific event
                event_result = await session.execute(
                    select(Event).where(Event.id == event_id)
                )
                event = event_result.scalar_one_or_none()

                if not event:
                    return False

                # Sensitive events are NEVER shared
                if event.is_sensitive:
                    return False

                # Check if any grant covers this event
                for grant in grants:
                    if self._event_matches_grant(event, grant):
                        # Record access
                        grant.access_count += 1
                        grant.last_accessed_at = datetime.utcnow()
                        await session.commit()
                        return True

                return False

    # ------------------------------------------------------------------
    # Shared timeline view
    # ------------------------------------------------------------------

    async def get_shared_events(
        self,
        timeline_id: uuid.UUID,
        circle_member_id: uuid.UUID,
        tenant_id: uuid.UUID,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Event]:
        """Get filtered events visible to a circle member.

        Excludes sensitive events and applies scope filtering.

        Args:
            timeline_id: The timeline to query
            circle_member_id: Who is viewing
            tenant_id: Tenant context
            limit: Max results to return
            offset: Result offset for pagination

        Returns:
            List of Event entities visible to the member
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                # Get active grants
                result = await session.execute(
                    select(SharingPermission).where(
                        and_(
                            SharingPermission.timeline_id == timeline_id,
                            SharingPermission.circle_member_id == circle_member_id,
                            SharingPermission.revoked_at.is_(None),
                        )
                    )
                )
                grants = list(result.scalars().all())

                if not grants:
                    return []

                # Get all non-sensitive events
                events_result = await session.execute(
                    select(Event)
                    .where(
                        and_(
                            Event.timeline_id == timeline_id,
                            Event.is_sensitive == False,
                        )
                    )
                    .order_by(Event.date_start.desc())
                    .limit(5000)  # Safety limit
                )
                all_events = list(events_result.scalars().all())

                # If any grant is full_timeline, return all non-sensitive events
                if any(g.scope == "full_timeline" for g in grants):
                    return all_events[offset:offset + limit]

                # Otherwise filter by all grants
                filtered = []
                for event in all_events:
                    for grant in grants:
                        if self._event_matches_grant(event, grant):
                            filtered.append(event)
                            break

                # Record access on each grant
                for grant in grants:
                    grant.access_count += 1
                    grant.last_accessed_at = datetime.utcnow()
                await session.commit()

                return filtered[offset:offset + limit]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _event_matches_grant(event: Event, grant: SharingPermission) -> bool:
        """Check if a single event falls within a sharing grant's scope."""
        if event.is_sensitive:
            return False

        scope = grant.scope
        sf = grant.scope_filter or {}

        if scope == "full_timeline":
            return True

        if scope == "period":
            start_year = sf.get("start_year")
            end_year = sf.get("end_year")
            if event.date_start is None:
                return False
            event_year = event.date_start.year
            if start_year is not None and event_year < int(start_year):
                return False
            if end_year is not None and event_year > int(end_year):
                return False
            return True

        if scope == "event":
            event_ids = sf.get("event_ids", [])
            return str(event.id) in event_ids

        if scope == "theme":
            shared_themes = set(sf.get("themes", []))
            event_themes = set(event.themes or [])
            return bool(shared_themes & event_themes)

        if scope == "person":
            shared_names = set(n.lower() for n in sf.get("person_names", []))
            for p in (event.people or []):
                name = p.get("name", "") if isinstance(p, dict) else ""
                if name.lower() in shared_names:
                    return True
            return False

        return False
