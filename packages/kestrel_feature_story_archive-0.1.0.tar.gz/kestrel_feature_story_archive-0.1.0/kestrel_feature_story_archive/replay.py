"""
Story Replay Service

Enables conversational replay of an elder's life stories — asking questions
and receiving answers grounded entirely in the archive's actual events.

NOT impersonation — speaks ABOUT the subject, not AS the subject.

Ethical guardrails:
1. No impersonation
2. Citation required — every claim linked to source event
3. No fabrication — missing info acknowledged, never invented
4. Sensitive exclusion — sensitive events never surfaced
5. Audit trail — all queries logged for transparency
"""

import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Callable, Awaitable

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import Timeline, Event, Session, ReplayQuery
from .exceptions import TimelineNotFoundError

logger = logging.getLogger(__name__)

# =============================================================================
# Replay System Prompt
# =============================================================================

REPLAY_SYSTEM_PROMPT = """You are helping a family member explore {subject_name}'s life stories.

CRITICAL RULES:
- ONLY use information from the provided timeline events
- NEVER fabricate, infer, or guess information not in the sources
- When you don't have information, say "I don't have a story about that"
- Cite which story session or event your information comes from
- Speak warmly about {subject_name} but do not impersonate them
- If asked something not covered by the sources, acknowledge the gap honestly
- When multiple events are relevant, weave them together naturally
- Include direct quotes from the subject when available (these are their actual words)

TIMELINE CONTEXT:
{retrieved_events}

FAMILY MEMBER'S QUESTION:
{question}

Respond in a warm, conversational tone. After your answer, suggest 2-3 follow-up
questions the family member might want to ask, based on the available timeline content.
Format your response as JSON:
{{
  "answer": "Your narrative answer here...",
  "cited_event_ids": ["event-id-1", "event-id-2"],
  "no_information": false,
  "suggested_followups": ["Follow-up question 1?", "Follow-up question 2?"]
}}"""

QUESTION_SUGGESTION_PROMPT = """Given this timeline of life events, suggest 5-8 interesting
questions a family member might want to ask to explore these stories.

Focus on:
- Major life transitions and milestones
- People who appear frequently
- Recurring themes
- Emotionally significant moments
- Historical context of their experiences

TIMELINE SUMMARY:
{timeline_summary}

Respond with ONLY a JSON object: {{"questions": ["question1", "question2", ...]}}"""


# Type alias for LLM callable
LLMCallable = Callable[[str], Awaitable[str]]


class StoryReplayService:
    """Service for conversational replay of life stories.

    Retrieves relevant timeline events using semantic + keyword search,
    synthesizes grounded responses, and enforces ethical guardrails.
    """

    def __init__(
        self,
        session_factory,
        vector_backend,
        llm: Optional[LLMCallable] = None,
        embedder: Optional[Callable[[str], Awaitable[List[float]]]] = None,
    ):
        """Initialize replay service.

        Args:
            session_factory: AsyncSessionFactory for database access
            vector_backend: VectorSearchBackend for semantic search
            llm: Optional LLM callable for response generation
            embedder: Optional embedder callable for question embedding
        """
        self._sf = session_factory
        self._vector_backend = vector_backend
        self._llm = llm
        self._embedder = embedder

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def ask(
        self,
        timeline_id: uuid.UUID,
        question: str,
        asker_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Ask a question about a subject's life stories.

        Args:
            timeline_id: The timeline to search
            question: The family member's question
            asker_id: Who is asking (for audit trail)
            tenant_id: Tenant context

        Returns:
            Dict with:
                - answer: str
                - sources: List[Dict] (event_id, title, date, quote)
                - media: List[Dict] (media attached to cited events)
                - no_information: bool
                - suggested_followups: List[str]
        """
        with TenantContext.use(tenant_id):
            # Get timeline
            async with self._sf.read_session() as session:
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

                subject_name = timeline.title or "the subject"

            # Retrieve relevant events
            events = await self._retrieve_events(timeline_id, question, tenant_id)

            # Build context and generate response
            if not events:
                response = {
                    "answer": f"I don't have any stories from {subject_name} that relate to that topic. "
                              "Perhaps you could try asking about a different period or theme in their life?",
                    "sources": [],
                    "media": [],
                    "no_information": True,
                    "suggested_followups": await self._get_fallback_suggestions(timeline_id, tenant_id),
                }
            else:
                response = await self._generate_response(
                    question, events, subject_name, timeline_id
                )

            # Log the query for audit trail
            await self._log_query(
                timeline_id=timeline_id,
                question=question,
                asker_id=asker_id,
                tenant_id=tenant_id,
                event_ids=[s["event_id"] for s in response.get("sources", [])],
                no_information=response.get("no_information", False),
            )

            return response

    async def get_suggested_questions(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> List[str]:
        """Generate suggested questions based on timeline content.

        Returns a list of interesting questions a family member might ask.
        """
        with TenantContext.use(tenant_id):
            # Get non-sensitive events
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Event)
                    .where(
                        and_(
                            Event.timeline_id == timeline_id,
                            Event.is_sensitive == False,
                        )
                    )
                    .order_by(Event.importance.desc())
                    .limit(200)
                )
                events = list(result.scalars().all())

            if not events:
                return ["What stories have been collected so far?"]

            # Build a summary for the LLM
            summary = self._build_timeline_summary(events)

            if self._llm:
                try:
                    prompt = QUESTION_SUGGESTION_PROMPT.format(timeline_summary=summary)
                    response = await self._llm(prompt)
                    data = json.loads(response)
                    return data.get("questions", [])[:8]
                except Exception as e:
                    logger.warning(f"Question suggestion generation failed: {e}")

            # Fallback: generate questions without LLM
            return self._generate_fallback_questions(events)

    async def get_highlights(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """Get key moments (highlights) from the timeline.

        Returns the most important non-sensitive events.
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Event)
                    .where(
                        and_(
                            Event.timeline_id == timeline_id,
                            Event.is_sensitive == False,
                        )
                    )
                    .order_by(Event.importance.desc())
                    .limit(limit)
                )
                events = list(result.scalars().all())

            highlights = []
            for event in events:
                people_names = []
                for p in (event.people or []):
                    name = p.get("name") if isinstance(p, dict) else None
                    if name:
                        people_names.append(name)

                highlights.append({
                    "event_id": str(event.id),
                    "title": event.title,
                    "description": event.description,
                    "date_display": event.date_display,
                    "emotional_tone": event.emotional_tone,
                    "importance": event.importance,
                    "people": people_names,
                    "themes": event.themes or [],
                })

            return highlights

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    async def _retrieve_events(
        self,
        timeline_id: uuid.UUID,
        question: str,
        tenant_id: uuid.UUID,
        max_results: int = 10,
    ) -> List[Dict[str, Any]]:
        """Retrieve relevant events using semantic + keyword search.

        Strategy:
        1. Keyword search for simple overlap
        2. Semantic search via vector_backend.knn() if embedder available
        3. Merge and rank results
        4. For each event, include session date if available
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Event)
                    .where(
                        and_(
                            Event.timeline_id == timeline_id,
                            Event.is_sensitive == False,
                        )
                    )
                    .limit(5000)
                )
                all_events = list(result.scalars().all())

        if not all_events:
            return []

        # Keyword search: simple word overlap scoring
        question_words = set(question.lower().split())
        keyword_scored = []
        for event in all_events:
            score = self._keyword_score(event, question_words)
            if score > 0:
                keyword_scored.append((event, score))

        # Semantic search: try to embed question and search vectors
        semantic_scored = []
        if self._embedder:
            try:
                question_embedding = await self._embedder(question)
                if question_embedding:
                    # Use vector_backend.knn() for semantic search
                    semantic_results = await self._vector_backend.knn(
                        timeline_id=timeline_id,
                        query_vector=question_embedding,
                        k=max_results * 2,
                        include_sensitive=False,
                    )
                    # Convert to (event, score) tuples
                    event_map = {e.id: e for e in all_events}
                    for event_id, distance in semantic_results:
                        if event_id in event_map:
                            # Convert distance to similarity score (1 - distance)
                            score = 1.0 - min(distance, 1.0)
                            semantic_scored.append((event_map[event_id], score))
            except Exception as e:
                logger.warning(f"Semantic search failed, falling back to keyword only: {e}")

        # Merge results: combine semantic and keyword scores
        event_scores: Dict[uuid.UUID, float] = {}
        event_map: Dict[uuid.UUID, Event] = {}

        for event, score in semantic_scored:
            event_scores[event.id] = score
            event_map[event.id] = event

        for event, score in keyword_scored:
            # Keyword score as bonus (0-0.3 range)
            normalized_keyword = min(score * 0.1, 0.3)
            event_scores[event.id] = event_scores.get(event.id, 0) + normalized_keyword
            event_map[event.id] = event

        if not event_scores:
            # Last resort: return the most important events
            sorted_by_importance = sorted(all_events, key=lambda e: e.importance, reverse=True)
            top_events = sorted_by_importance[:3]
            if not top_events:
                return []
            event_scores = {e.id: e.importance for e in top_events}
            event_map = {e.id: e for e in top_events}

        # Rank and take top results
        ranked = sorted(event_scores.items(), key=lambda x: x[1], reverse=True)
        results = []

        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                for event_id, score in ranked[:max_results]:
                    event = event_map[event_id]

                    # Get session date if available
                    session_date = None
                    if event.source_session_id:
                        try:
                            sess_result = await session.execute(
                                select(Session).where(Session.id == event.source_session_id)
                            )
                            sess = sess_result.scalar_one_or_none()
                            if sess and sess.started_at:
                                session_date = sess.started_at.strftime("%Y-%m-%d")
                        except Exception:
                            pass

                    results.append({
                        "event": event,
                        "score": score,
                        "session_date": session_date,
                    })

        return results

    def _keyword_score(self, event: Event, question_words: set) -> float:
        """Score an event by keyword overlap with the question."""
        text_parts = []
        if event.title:
            text_parts.append(event.title.lower())
        if event.description:
            text_parts.append(event.description.lower())
        if event.location:
            text_parts.append(event.location.lower())
        for theme in (event.themes or []):
            text_parts.append(theme.lower())
        for p in (event.people or []):
            name = p.get("name", "") if isinstance(p, dict) else ""
            if name:
                text_parts.append(name.lower())

        full_text = " ".join(text_parts)
        event_words = set(full_text.split())

        # Remove common stop words from scoring
        stop_words = {
            "the", "a", "an", "is", "was", "were", "are", "in", "on", "at",
            "to", "for", "of", "and", "or", "but", "it", "he", "she", "they",
            "his", "her", "my", "your", "what", "when", "where", "how", "who",
            "about", "like", "did", "do", "me", "tell", "that", "this", "with"
        }
        meaningful_q_words = question_words - stop_words

        if not meaningful_q_words:
            return 0.0

        overlap = meaningful_q_words & event_words
        return len(overlap) / len(meaningful_q_words) if meaningful_q_words else 0.0

    # ------------------------------------------------------------------
    # Response generation
    # ------------------------------------------------------------------

    async def _generate_response(
        self,
        question: str,
        retrieved: List[Dict[str, Any]],
        subject_name: str,
        timeline_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Generate a grounded response using retrieved events."""
        # Build context string from retrieved events
        context_parts = []
        for i, item in enumerate(retrieved, 1):
            event = item["event"]
            session_date = item.get("session_date", "unknown date")
            people_names = []
            for p in (event.people or []):
                name = p.get("name") if isinstance(p, dict) else None
                if name:
                    people_names.append(name)

            part = f"[Event {i}: {event.title}]\n"
            part += f"  ID: {event.id}\n"
            if event.date_display:
                part += f"  Date: {event.date_display}\n"
            elif event.date_start:
                part += f"  Date: {event.date_start}\n"
            if event.location:
                part += f"  Location: {event.location}\n"
            if event.description:
                part += f"  Description: {event.description}\n"
            if people_names:
                part += f"  People: {', '.join(people_names)}\n"
            if event.themes:
                part += f"  Themes: {', '.join(event.themes)}\n"
            part += f"  Emotional tone: {event.emotional_tone}\n"
            part += f"  Recorded: {session_date}\n"
            context_parts.append(part)

        context_text = "\n".join(context_parts)

        prompt = REPLAY_SYSTEM_PROMPT.format(
            subject_name=subject_name,
            retrieved_events=context_text,
            question=question,
        )

        if self._llm:
            try:
                response = await self._llm(prompt)

                # Parse JSON response
                try:
                    data = json.loads(response)
                except json.JSONDecodeError:
                    # If LLM didn't return valid JSON, wrap the text
                    data = {
                        "answer": response,
                        "cited_event_ids": [str(item["event"].id) for item in retrieved],
                        "no_information": False,
                        "suggested_followups": [],
                    }

                # Build sources from cited events
                cited_ids = set(data.get("cited_event_ids", []))
                # If no explicit citations, cite all retrieved events
                if not cited_ids:
                    cited_ids = {str(item["event"].id) for item in retrieved}

                sources = []
                for item in retrieved:
                    event = item["event"]
                    if str(event.id) in cited_ids:
                        sources.append({
                            "event_id": str(event.id),
                            "event_title": event.title,
                            "date_display": event.date_display or (str(event.date_start) if event.date_start else None),
                            "source_quote": event.description[:200] if event.description else None,
                            "session_date": item.get("session_date"),
                            "confidence": event.confidence,
                        })

                return {
                    "answer": data.get("answer", response),
                    "sources": sources,
                    "media": [],  # TODO: add media from cited events
                    "no_information": data.get("no_information", False),
                    "suggested_followups": data.get("suggested_followups", [])[:3],
                }

            except Exception as e:
                logger.error(f"Replay response generation failed: {e}")
                # Fallback: return a summary without LLM
                return self._build_fallback_response(retrieved, subject_name)
        else:
            # No LLM available, return fallback
            return self._build_fallback_response(retrieved, subject_name)

    def _build_fallback_response(
        self,
        retrieved: List[Dict[str, Any]],
        subject_name: str,
    ) -> Dict[str, Any]:
        """Build a response without LLM (fallback for API failures)."""
        if not retrieved:
            return {
                "answer": f"I don't have enough information to answer that question about {subject_name}.",
                "sources": [],
                "media": [],
                "no_information": True,
                "suggested_followups": [],
            }

        parts = [f"Here's what I found in {subject_name}'s stories:\n"]
        sources = []

        for item in retrieved[:5]:
            event = item["event"]
            date_str = event.date_display or (str(event.date_start) if event.date_start else "")
            parts.append(f"- **{event.title}**{f' ({date_str})' if date_str else ''}")
            if event.description:
                parts.append(f"  {event.description[:200]}")

            sources.append({
                "event_id": str(event.id),
                "event_title": event.title,
                "date_display": event.date_display,
                "source_quote": event.description[:200] if event.description else None,
                "session_date": item.get("session_date"),
                "confidence": event.confidence,
            })

        return {
            "answer": "\n".join(parts),
            "sources": sources,
            "media": [],
            "no_information": False,
            "suggested_followups": [],
        }

    # ------------------------------------------------------------------
    # Suggested questions helpers
    # ------------------------------------------------------------------

    def _build_timeline_summary(self, events: List[Event]) -> str:
        """Build a text summary of events for the question suggestion prompt."""
        lines = []
        for e in events[:50]:  # Limit to 50 events for prompt size
            date_str = e.date_display or (str(e.date_start) if e.date_start else "?")
            themes_str = ", ".join(e.themes[:3]) if e.themes else ""
            people_str = ""
            for p in (e.people or [])[:3]:
                name = p.get("name") if isinstance(p, dict) else None
                if name:
                    people_str += f", {name}"
            line = f"- {e.title} ({date_str})"
            if themes_str:
                line += f" [{themes_str}]"
            if people_str:
                line += f" with{people_str}"
            lines.append(line)
        return "\n".join(lines)

    def _generate_fallback_questions(self, events: List[Event]) -> List[str]:
        """Generate questions without LLM based on event metadata."""
        questions = []
        themes = set()
        people = set()
        locations = set()

        for e in events:
            for t in (e.themes or []):
                themes.add(t)
            for p in (e.people or []):
                name = p.get("name") if isinstance(p, dict) else None
                if name:
                    people.add(name)
            if e.location:
                locations.add(e.location)

        if themes:
            for theme in list(themes)[:2]:
                questions.append(f"What stories are there about {theme}?")
        if people:
            for person in list(people)[:2]:
                questions.append(f"Tell me about {person}")
        if locations:
            for loc in list(locations)[:1]:
                questions.append(f"What happened in {loc}?")

        # Generic fallback
        if not questions:
            questions = [
                "What are the most important moments in the timeline?",
                "Who were the most important people?",
            ]

        return questions[:5]

    async def _get_fallback_suggestions(
        self, timeline_id: uuid.UUID, tenant_id: uuid.UUID
    ) -> List[str]:
        """Get fallback question suggestions when no events match."""
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Event)
                    .where(
                        and_(
                            Event.timeline_id == timeline_id,
                            Event.is_sensitive == False,
                        )
                    )
                    .limit(50)
                )
                events = list(result.scalars().all())

        return self._generate_fallback_questions(events)

    # ------------------------------------------------------------------
    # Audit trail
    # ------------------------------------------------------------------

    async def _log_query(
        self,
        timeline_id: uuid.UUID,
        question: str,
        asker_id: uuid.UUID,
        tenant_id: uuid.UUID,
        event_ids: List[str],
        no_information: bool,
    ) -> None:
        """Log a replay query for transparency and auditing."""
        try:
            with TenantContext.use(tenant_id):
                async with self._sf.write_session() as session:
                    query = ReplayQuery(
                        timeline_id=timeline_id,
                        tenant_id=tenant_id,
                        question=question,
                        asker_circle_member_id=asker_id,
                        event_ids_cited=[uuid.UUID(eid) for eid in event_ids if eid],
                        no_information=no_information,
                    )
                    session.add(query)
                    await session.commit()
        except Exception as e:
            logger.warning(f"Failed to log replay query: {e}")
