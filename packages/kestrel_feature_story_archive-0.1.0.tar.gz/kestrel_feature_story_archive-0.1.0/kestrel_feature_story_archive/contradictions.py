"""
ContradictionService — Detection, tracking, and gentle resolution of
contradictions across story sessions.

Handles:
- Detecting contradictions when new events are extracted (temporal, sequential,
  factual, attribution, location)
- Confidence scoring and adjustment
- Repetition detection (same story told multiple times)
- Queuing contradictions for gentle resolution
- Generating gentle resolution prompts
- Resolving or accepting ambiguity
"""

import logging
import uuid
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Tuple

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import (
    Contradiction,
    ContradictionType,
    ContradictionStatus,
    Repetition,
    Event,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Confidence Adjustment Rules
# =============================================================================

# More recent telling gets slightly higher confidence
RECENCY_BOOST = 0.05

# More detailed telling gets higher confidence
DETAIL_BOOST = 0.1

# Consistent across sessions gets highest confidence
CONSISTENCY_BOOST = 0.15

# Contradicted details get lower confidence
CONTRADICTION_PENALTY = 0.1

# Resolved contradictions get boosted confidence
RESOLUTION_BOOST = 0.2

# Auto-resolve confidence delta threshold
AUTO_RESOLVE_CONFIDENCE_DELTA = 0.1

# Contradiction types where auto-resolve is safe
AUTO_RESOLVE_TYPES = frozenset({"temporal", "location"})


# =============================================================================
# Gentle Resolution Prompt Templates
# =============================================================================

GENTLE_PROMPTS = {
    "temporal": (
        "I was thinking about what you shared — you mentioned {description}. "
        "I have it noted as {value_a}, but it also sounded like it might have been {value_b}. "
        "Which feels right to you?"
    ),
    "sequential": (
        "I want to make sure I have the order right in your story. "
        "Did {value_a} happen before or after {value_b}? "
        "I want to get the timeline just right."
    ),
    "factual": (
        "I want to make sure I remember this correctly — "
        "was it {value_a} or {value_b}? "
        "I just want to have it right in your story."
    ),
    "attribution": (
        "I'm trying to remember — was it {value_a} or {value_b} "
        "who was part of that story? I want to make sure I give credit "
        "to the right person."
    ),
    "location": (
        "I want to picture the place correctly — "
        "was that at {value_a} or {value_b}? "
        "I love getting the details right."
    ),
}


# =============================================================================
# ContradictionService
# =============================================================================


class ContradictionService:
    """Detect and manage contradictions across story sessions."""

    def __init__(self, session_factory):
        """Initialize contradiction service.

        Args:
            session_factory: AsyncSessionFactory for database access
        """
        self._sf = session_factory

    # -------------------------------------------------------------------------
    # Detection
    # -------------------------------------------------------------------------

    async def detect_contradictions(
        self,
        timeline_id: uuid.UUID,
        new_events: List[Event],
        existing_events: List[Event],
        tenant_id: uuid.UUID,
        session_id: Optional[uuid.UUID] = None,
    ) -> List[Contradiction]:
        """Detect contradictions between new and existing events.

        Runs rule-based checks for each contradiction type. Does NOT use
        LLM — this is fast, deterministic comparison logic.

        Args:
            timeline_id: The timeline being checked
            new_events: Newly extracted events
            existing_events: Existing timeline events
            tenant_id: Tenant context
            session_id: Session that produced the new events

        Returns:
            List of persisted Contradiction entities
        """
        contradictions = []

        for new_event in new_events:
            new_title = (new_event.title or "").lower()
            new_date = new_event.date_start
            new_location = new_event.location
            new_people = new_event.people or []
            new_description = new_event.description or ""

            for existing in existing_events:
                existing_title = (existing.title or "").lower()

                # Only compare events that seem to refer to the same thing
                if not self._titles_match(new_title, existing_title):
                    continue

                existing_date = existing.date_start
                existing_location = existing.location
                existing_people = existing.people or []

                # Temporal contradiction
                if new_date and existing_date and new_date != existing_date:
                    contradictions.append({
                        "timeline_id": timeline_id,
                        "event_id_a": existing.id,
                        "event_id_b": new_event.id,
                        "contradiction_type": ContradictionType.temporal,
                        "field_name": "date_start",
                        "value_a": str(existing_date),
                        "value_b": str(new_date),
                        "description": (
                            f"Date conflict for '{existing.title}': "
                            f"previously {existing_date}, now {new_date}"
                        ),
                        "confidence_a": existing.confidence,
                        "confidence_b": new_event.confidence,
                        "session_id_a": existing.source_session_id,
                        "session_id_b": session_id,
                    })

                # Location contradiction
                if (
                    new_location and existing_location
                    and new_location.lower() != existing_location.lower()
                    and self._locations_conflict(new_location, existing_location)
                ):
                    contradictions.append({
                        "timeline_id": timeline_id,
                        "event_id_a": existing.id,
                        "event_id_b": new_event.id,
                        "contradiction_type": ContradictionType.location,
                        "field_name": "location",
                        "value_a": existing_location,
                        "value_b": new_location,
                        "description": (
                            f"Location conflict for '{existing.title}': "
                            f"previously '{existing_location}', now '{new_location}'"
                        ),
                        "confidence_a": existing.confidence,
                        "confidence_b": new_event.confidence,
                        "session_id_a": existing.source_session_id,
                        "session_id_b": session_id,
                    })

                # Attribution contradiction (different people for same event)
                if new_people and existing_people:
                    attr_conflict = self._attribution_conflicts(new_people, existing_people)
                    if attr_conflict:
                        contradictions.append({
                            "timeline_id": timeline_id,
                            "event_id_a": existing.id,
                            "event_id_b": new_event.id,
                            "contradiction_type": ContradictionType.attribution,
                            "field_name": "people",
                            "value_a": attr_conflict[0],
                            "value_b": attr_conflict[1],
                            "description": (
                                f"Attribution conflict for '{existing.title}': "
                                f"previously attributed to {attr_conflict[0]}, "
                                f"now {attr_conflict[1]}"
                            ),
                            "confidence_a": existing.confidence,
                            "confidence_b": new_event.confidence,
                            "session_id_a": existing.source_session_id,
                            "session_id_b": session_id,
                        })

                # Factual contradiction (description contains conflicting numbers/facts)
                factual = self._detect_factual_conflict(new_description, existing.description)
                if factual:
                    contradictions.append({
                        "timeline_id": timeline_id,
                        "event_id_a": existing.id,
                        "event_id_b": new_event.id,
                        "contradiction_type": ContradictionType.factual,
                        "field_name": "description",
                        "value_a": factual[0],
                        "value_b": factual[1],
                        "description": (
                            f"Factual conflict for '{existing.title}': "
                            f"'{factual[0]}' vs '{factual[1]}'"
                        ),
                        "confidence_a": existing.confidence,
                        "confidence_b": new_event.confidence,
                        "session_id_a": existing.source_session_id,
                        "session_id_b": session_id,
                    })

        # Persist contradictions
        return await self._persist_contradictions(contradictions, tenant_id)

    async def _persist_contradictions(
        self,
        contradictions: List[Dict[str, Any]],
        tenant_id: uuid.UUID,
    ) -> List[Contradiction]:
        """Persist detected contradictions to the database."""
        records = []

        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                for c in contradictions:
                    try:
                        contradiction = Contradiction(
                            timeline_id=c["timeline_id"],
                            tenant_id=tenant_id,
                            event_id_a=c["event_id_a"],
                            event_id_b=c["event_id_b"],
                            contradiction_type=c["contradiction_type"],
                            status=ContradictionStatus.detected,
                            field_name=c.get("field_name"),
                            value_a=c.get("value_a"),
                            value_b=c.get("value_b"),
                            description=c.get("description"),
                            detail=c.get("detail"),
                            confidence_a=c.get("confidence_a", 0.5),
                            confidence_b=c.get("confidence_b", 0.5),
                            session_id_a=c.get("session_id_a"),
                            session_id_b=c.get("session_id_b"),
                        )
                        session.add(contradiction)
                        records.append(contradiction)

                        logger.info(
                            f"Contradiction detected: {c['contradiction_type'].value} — "
                            f"{c.get('description', '')[:80]}"
                        )
                    except Exception as e:
                        logger.warning(f"Failed to persist contradiction: {e}")

                if records:
                    await session.commit()
                    for r in records:
                        await session.refresh(r)

        return records

    # -------------------------------------------------------------------------
    # Auto-resolve
    # -------------------------------------------------------------------------

    async def auto_resolve_clear_corrections(
        self,
        contradiction_records: List[Contradiction],
        tenant_id: uuid.UUID,
    ) -> List[Contradiction]:
        """Auto-resolve obviously-correctable contradictions.

        When a contradiction type is one of AUTO_RESOLVE_TYPES AND the new
        telling is meaningfully more confident than the existing one, pick
        version 'b' and patch the canonical event immediately.

        Args:
            contradiction_records: Newly persisted Contradictions
            tenant_id: Tenant context

        Returns:
            List of records that were auto-resolved
        """
        resolved_records: List[Contradiction] = []

        for record in contradiction_records:
            if record.contradiction_type not in AUTO_RESOLVE_TYPES:
                continue

            conf_a = float(record.confidence_a or 0.5)
            conf_b = float(record.confidence_b or 0.5)

            if conf_b - conf_a < AUTO_RESOLVE_CONFIDENCE_DELTA:
                continue

            try:
                await self.resolve(
                    contradiction_id=record.id,
                    resolved_version="b",
                    resolution_notes=(
                        f"Auto-resolved: new telling has higher confidence "
                        f"({conf_b:.2f} > {conf_a:.2f}) for {record.contradiction_type.value} field."
                    ),
                    resolved_by="auto",
                    tenant_id=tenant_id,
                )
                resolved_records.append(record)
            except Exception as e:
                logger.warning(f"Auto-resolve failed for contradiction {record.id}: {e}")

        if resolved_records:
            logger.info(f"Auto-resolved {len(resolved_records)} clear-cut contradictions")

        return resolved_records

    # -------------------------------------------------------------------------
    # Resolution
    # -------------------------------------------------------------------------

    async def resolve(
        self,
        contradiction_id: uuid.UUID,
        resolved_version: str,
        tenant_id: uuid.UUID,
        resolution_notes: Optional[str] = None,
        resolved_by: str = "user",
    ) -> bool:
        """Resolve a contradiction by choosing version a, b, or merged.

        Args:
            contradiction_id: The contradiction to resolve
            resolved_version: 'a' for first version, 'b' for second, 'merged' for both
            tenant_id: Tenant context
            resolution_notes: Optional notes about the resolution
            resolved_by: Who resolved it ('user', 'agent', 'auto')

        Returns:
            True if resolved successfully
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Contradiction).where(Contradiction.id == contradiction_id)
                )
                contradiction = result.scalar_one_or_none()

                if not contradiction:
                    return False

                # Update contradiction status
                contradiction.status = ContradictionStatus.resolved
                contradiction.resolved_version = resolved_version
                contradiction.resolution_notes = resolution_notes
                contradiction.resolved_by = resolved_by
                contradiction.resolved_at = datetime.utcnow()

                await session.commit()

                # Adjust confidence on events
                if resolved_version == "a":
                    await self._boost_confidence(contradiction.event_id_a, RESOLUTION_BOOST, tenant_id)
                    await self._penalize_confidence(contradiction.event_id_b, CONTRADICTION_PENALTY, tenant_id)
                elif resolved_version == "b":
                    # Patch the resolved value back onto event_id_a
                    await self._patch_resolved_value(contradiction, tenant_id)
                    await self._boost_confidence(contradiction.event_id_a, RESOLUTION_BOOST, tenant_id)
                    if contradiction.event_id_b and contradiction.event_id_b != contradiction.event_id_a:
                        await self._penalize_confidence(contradiction.event_id_b, CONTRADICTION_PENALTY, tenant_id)
                else:
                    # Merged — boost both slightly
                    await self._boost_confidence(contradiction.event_id_a, RESOLUTION_BOOST / 2, tenant_id)
                    if contradiction.event_id_b and contradiction.event_id_b != contradiction.event_id_a:
                        await self._boost_confidence(contradiction.event_id_b, RESOLUTION_BOOST / 2, tenant_id)

                return True

    async def _patch_resolved_value(
        self,
        contradiction: Contradiction,
        tenant_id: uuid.UUID,
    ) -> bool:
        """Write the resolved value back to the canonical event.

        Used by resolve() when version='b' is chosen — copies
        contradiction.value_b onto the indicated event's field_name field.

        Returns:
            True on success
        """
        field_name = contradiction.field_name
        new_value_raw = contradiction.value_b

        if not field_name or not new_value_raw:
            return False

        # Type round-trip: contradiction.value_b is stored as a string
        try:
            parsed = self._parse_value_for_field(field_name, new_value_raw)
        except Exception as e:
            logger.warning(f"Could not parse value for field={field_name}: {e}")
            return False

        if parsed is None:
            return False

        update_kwargs: Dict[str, Any] = {field_name: parsed}

        # Update date_display if patching date fields
        if field_name in {"date_start", "date_end"} and isinstance(parsed, date):
            # Simple year format for most life events
            update_kwargs["date_display"] = str(parsed.year)

        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                try:
                    result = await session.execute(
                        select(Event).where(Event.id == contradiction.event_id_a)
                    )
                    event = result.scalar_one_or_none()

                    if not event:
                        return False

                    for key, val in update_kwargs.items():
                        setattr(event, key, val)

                    await session.commit()

                    logger.info(
                        f"Patched event {contradiction.event_id_a}.{field_name} = {parsed!r} "
                        f"from contradiction resolution"
                    )
                    return True
                except Exception as e:
                    logger.warning(f"Patch failed: {e}")
                    return False

    @staticmethod
    def _parse_value_for_field(field_name: str, raw: str) -> Any:
        """Parse a contradiction value (string in DB) to the correct type."""
        if field_name in {"date_start", "date_end"}:
            try:
                return date.fromisoformat(raw[:10])
            except (ValueError, IndexError):
                return None
        if field_name in {"location", "title", "event_type", "date_precision",
                          "date_display", "emotional_tone", "privacy_mode"}:
            return raw
        if field_name in {"importance", "confidence"}:
            try:
                return float(raw)
            except (TypeError, ValueError):
                return None
        # People and description need special handling, skip
        return None

    async def accept_ambiguity(
        self,
        contradiction_id: uuid.UUID,
        tenant_id: uuid.UUID,
        notes: Optional[str] = None,
    ) -> bool:
        """Accept that a contradiction may never resolve — and that's OK.

        Both versions are kept. Neither confidence is penalized.
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Contradiction).where(Contradiction.id == contradiction_id)
                )
                contradiction = result.scalar_one_or_none()

                if not contradiction:
                    return False

                contradiction.status = ContradictionStatus.accepted_ambiguous
                contradiction.resolution_notes = notes or "Ambiguity accepted — both versions preserved"
                contradiction.resolved_at = datetime.utcnow()
                contradiction.resolved_by = "user"

                await session.commit()
                return True

    # -------------------------------------------------------------------------
    # Confidence Adjustment
    # -------------------------------------------------------------------------

    async def _boost_confidence(
        self,
        event_id: uuid.UUID,
        amount: float,
        tenant_id: uuid.UUID,
    ) -> None:
        """Boost an event's confidence score."""
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Event).where(Event.id == event_id)
                )
                event = result.scalar_one_or_none()

                if event:
                    event.confidence = min(1.0, event.confidence + amount)
                    await session.commit()

    async def _penalize_confidence(
        self,
        event_id: uuid.UUID,
        amount: float,
        tenant_id: uuid.UUID,
    ) -> None:
        """Reduce an event's confidence score."""
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Event).where(Event.id == event_id)
                )
                event = result.scalar_one_or_none()

                if event:
                    event.confidence = max(0.0, event.confidence - amount)
                    await session.commit()

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _titles_match(title_a: str, title_b: str) -> bool:
        """Check if two event titles refer to the same event."""
        if not title_a or not title_b:
            return False

        if title_a == title_b:
            return True

        if title_a in title_b or title_b in title_a:
            return True

        # Word overlap
        stop_words = {"the", "a", "an", "in", "to", "of", "and", "was", "is", "at", "on", "for"}
        words_a = set(title_a.split()) - stop_words
        words_b = set(title_b.split()) - stop_words

        if not words_a or not words_b:
            return False

        overlap = words_a & words_b
        smaller = min(len(words_a), len(words_b))

        return len(overlap) / smaller >= 0.5 if smaller else False

    @staticmethod
    def _locations_conflict(loc_a: str, loc_b: str) -> bool:
        """Check if two locations actually conflict."""
        a_lower = loc_a.lower().strip()
        b_lower = loc_b.lower().strip()

        # If one contains the other, it's a refinement not a conflict
        if a_lower in b_lower or b_lower in a_lower:
            return False

        return True

    @staticmethod
    def _attribution_conflicts(
        people_a: List[Dict], people_b: List[Dict]
    ) -> Optional[Tuple[str, str]]:
        """Check if people attribution differs for the same event."""
        if not people_a or not people_b:
            return None

        names_a = set()
        for p in people_a:
            name = p.get("name", "") if isinstance(p, dict) else str(p)
            if name:
                names_a.add(name.lower())

        names_b = set()
        for p in people_b:
            name = p.get("name", "") if isinstance(p, dict) else str(p)
            if name:
                names_b.add(name.lower())

        # If sets are identical or one is a subset, no conflict
        if names_a == names_b or names_a.issubset(names_b) or names_b.issubset(names_a):
            return None

        # Find names that are in one but not the other
        only_a = names_a - names_b
        only_b = names_b - names_a

        if only_a and only_b:
            return (", ".join(sorted(only_a)), ", ".join(sorted(only_b)))

        return None

    @staticmethod
    def _detect_factual_conflict(
        desc_a: Optional[str], desc_b: Optional[str]
    ) -> Optional[Tuple[str, str]]:
        """Detect factual conflicts between two descriptions."""
        if not desc_a or not desc_b:
            return None

        import re

        # Extract number-noun pairs
        pattern = r"(\w+)\s+(children|kids|siblings|brothers|sisters|years|months|houses|rooms|cars)"
        matches_a = re.findall(pattern, desc_a.lower())
        matches_b = re.findall(pattern, desc_b.lower())

        if not matches_a or not matches_b:
            return None

        # Build lookup: noun -> number word
        nums_a = {noun: num for num, noun in matches_a}
        nums_b = {noun: num for num, noun in matches_b}

        # Check for conflicts on same noun
        for noun in set(nums_a) & set(nums_b):
            if nums_a[noun] != nums_b[noun]:
                return (f"{nums_a[noun]} {noun}", f"{nums_b[noun]} {noun}")

        return None
