"""
Story Media Attachment Service

Handles photo uploads, document scans, and voice clip recordings
attached to timeline events. Includes EXIF extraction, thumbnail
generation, and event anchoring.

Storage is delegated to a pluggable storage_backend (constructor-injected).
No direct disk I/O or IPFS-specific code in this service.
"""

import base64
import hashlib
import io
import logging
import uuid
from datetime import date
from typing import Any, Dict, List, Optional, Tuple

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_

from .entities import Media, Event, Timeline
from .exceptions import TimelineNotFoundError
from .storage import StorageBackend, NoOpStorageBackend

logger = logging.getLogger(__name__)

# Max upload size: 20 MB
MAX_UPLOAD_SIZE = 20 * 1024 * 1024

# Supported MIME types by media category
ALLOWED_PHOTO_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif", "image/tiff"}
ALLOWED_DOCUMENT_TYPES = {"application/pdf", "image/jpeg", "image/png", "image/tiff"}
ALLOWED_VOICE_TYPES = {"audio/webm", "audio/mp3", "audio/mpeg", "audio/ogg", "audio/wav", "audio/mp4"}
ALLOWED_VIDEO_TYPES = {"video/mp4", "video/webm"}

ALL_ALLOWED_TYPES = ALLOWED_PHOTO_TYPES | ALLOWED_DOCUMENT_TYPES | ALLOWED_VOICE_TYPES | ALLOWED_VIDEO_TYPES

# Thumbnail size
THUMBNAIL_MAX_DIM = 400


def _detect_media_type(mime_type: str) -> str:
    """Infer media type from MIME type."""
    if mime_type in ALLOWED_PHOTO_TYPES:
        return "photo"
    if mime_type in ALLOWED_DOCUMENT_TYPES:
        return "document"
    if mime_type in ALLOWED_VOICE_TYPES:
        return "voice_clip"
    if mime_type in ALLOWED_VIDEO_TYPES:
        return "video"
    return "photo"


def _extract_exif(image_bytes: bytes) -> Dict[str, Any]:
    """Extract EXIF data from image bytes.

    Returns dict with date_taken, location, camera info.
    """
    exif_data: Dict[str, Any] = {}
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS

        img = Image.open(io.BytesIO(image_bytes))
        raw_exif = img.getexif()
        if not raw_exif:
            return exif_data

        for tag_id, value in raw_exif.items():
            tag_name = TAGS.get(tag_id, tag_id)

            if tag_name == "DateTimeOriginal" or tag_name == "DateTime":
                try:
                    # EXIF date format: "YYYY:MM:DD HH:MM:SS"
                    parts = str(value).split(" ")[0].replace(":", "-")
                    exif_data["date_taken"] = parts  # "YYYY-MM-DD"
                except Exception:
                    pass

            elif tag_name == "Make":
                exif_data["camera_make"] = str(value)
            elif tag_name == "Model":
                exif_data["camera_model"] = str(value)

        # GPS extraction
        gps_info = raw_exif.get_ifd(0x8825)  # GPSInfo IFD
        if gps_info:
            gps_data = {}
            for key, val in gps_info.items():
                gps_tag = GPSTAGS.get(key, key)
                gps_data[gps_tag] = val

            lat = _convert_gps_coords(
                gps_data.get("GPSLatitude"),
                gps_data.get("GPSLatitudeRef"),
            )
            lon = _convert_gps_coords(
                gps_data.get("GPSLongitude"),
                gps_data.get("GPSLongitudeRef"),
            )
            if lat is not None and lon is not None:
                exif_data["location"] = {"latitude": lat, "longitude": lon}

    except ImportError:
        logger.debug("Pillow not available — skipping EXIF extraction")
    except Exception as e:
        logger.debug(f"EXIF extraction failed: {e}")

    return exif_data


def _convert_gps_coords(coords, ref) -> Optional[float]:
    """Convert GPS coordinate tuple to decimal degrees."""
    if not coords or not ref:
        return None
    try:
        degrees = float(coords[0])
        minutes = float(coords[1])
        seconds = float(coords[2])
        result = degrees + minutes / 60 + seconds / 3600
        if ref in ("S", "W"):
            result = -result
        return round(result, 6)
    except (TypeError, IndexError, ValueError):
        return None


def _generate_thumbnail(image_bytes: bytes) -> Optional[bytes]:
    """Generate a thumbnail from image bytes. Returns JPEG bytes or None."""
    try:
        from PIL import Image

        img = Image.open(io.BytesIO(image_bytes))
        img.thumbnail((THUMBNAIL_MAX_DIM, THUMBNAIL_MAX_DIM), Image.LANCZOS)

        # Convert to RGB if needed (e.g., RGBA PNGs)
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGB")

        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=80)
        return buf.getvalue()
    except ImportError:
        logger.debug("Pillow not available — skipping thumbnail generation")
    except Exception as e:
        logger.debug(f"Thumbnail generation failed: {e}")
    return None


class StoryMediaService:
    """Service for uploading, anchoring, and managing story media.

    Storage is delegated to a pluggable storage_backend.
    """

    def __init__(
        self,
        session_factory,
        storage_backend: Optional[StorageBackend] = None,
    ):
        """Initialize media service.

        Args:
            session_factory: AsyncSessionFactory for database access
            storage_backend: Optional storage backend for file uploads.
                             Defaults to NoOpStorageBackend.
        """
        self._sf = session_factory
        self._storage = storage_backend or NoOpStorageBackend()

    # ------------------------------------------------------------------
    # Upload
    # ------------------------------------------------------------------

    async def upload_media(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        file_bytes: bytes,
        filename: str,
        mime_type: str,
        media_type: Optional[str] = None,
        title: Optional[str] = None,
        description: Optional[str] = None,
        event_id: Optional[uuid.UUID] = None,
        date_taken: Optional[date] = None,
        date_precision: Optional[str] = None,
        people: Optional[List[Dict[str, Any]]] = None,
    ) -> Media:
        """Upload a media file, extract metadata, and create a story_media record.

        Args:
            timeline_id: Timeline to attach to
            tenant_id: Tenant context
            file_bytes: The file content
            filename: Original filename
            mime_type: MIME type
            media_type: Optional media type override (photo, document, voice_clip, video)
            title: Optional title/caption
            description: Optional description
            event_id: Optional event to attach to
            date_taken: Optional date the media was created
            date_precision: Optional date precision (exact, approximate, year)
            people: Optional list of people in the media

        Returns:
            The created Media entity
        """
        # Validate size
        if len(file_bytes) > MAX_UPLOAD_SIZE:
            raise ValueError(
                f"File too large ({len(file_bytes)} bytes). Max is {MAX_UPLOAD_SIZE} bytes."
            )

        # Validate MIME type
        if mime_type not in ALL_ALLOWED_TYPES:
            raise ValueError(f"Unsupported MIME type: {mime_type}")

        # Infer media type if not provided
        if not media_type:
            media_type = _detect_media_type(mime_type)

        # Content hash for dedup
        content_hash = hashlib.sha256(file_bytes).hexdigest()[:32]

        # Extract EXIF for photos
        exif_metadata: Dict[str, Any] = {}
        if mime_type in ALLOWED_PHOTO_TYPES:
            exif_metadata = _extract_exif(file_bytes)
            if not date_taken and exif_metadata.get("date_taken"):
                try:
                    date_taken = date.fromisoformat(exif_metadata["date_taken"])
                    if not date_precision:
                        date_precision = "exact"
                except (ValueError, TypeError):
                    pass

        # Generate thumbnail for photos
        thumbnail_b64 = None
        if mime_type in ALLOWED_PHOTO_TYPES:
            thumb_bytes = _generate_thumbnail(file_bytes)
            if thumb_bytes:
                thumbnail_b64 = base64.b64encode(thumb_bytes).decode("ascii")

        # Upload to storage backend
        storage_result = await self._storage.upload(
            file_bytes=file_bytes,
            filename=filename,
            content_type=mime_type,
            metadata={"timeline_id": str(timeline_id), "media_type": media_type},
        )

        file_url = storage_result.get("url")
        ipfs_cid = storage_result.get("cid")

        # Build combined metadata
        media_metadata: Dict[str, Any] = {}
        if exif_metadata:
            media_metadata["exif"] = exif_metadata
        if thumbnail_b64:
            media_metadata["thumbnail_b64"] = thumbnail_b64
        media_metadata["original_filename"] = filename

        # Create DB record
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                media = Media(
                    timeline_id=timeline_id,
                    event_id=event_id,
                    tenant_id=tenant_id,
                    media_type=media_type,
                    title=title,
                    description=description,
                    file_url=file_url,
                    ipfs_cid=ipfs_cid,
                    content_hash=content_hash,
                    file_size=len(file_bytes),
                    mime_type=mime_type,
                    date_taken=date_taken,
                    date_precision=date_precision,
                    people=people or [],
                    metadata_=media_metadata,
                    upload_source="user_upload",
                )
                session.add(media)
                await session.commit()
                await session.refresh(media)

                logger.info(
                    f"Media uploaded: {media.id} ({media.media_type}, {len(file_bytes)} bytes)"
                )
                return media

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    async def get_media(
        self,
        media_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Optional[Media]:
        """Get a media record by ID.

        Args:
            media_id: The media ID
            tenant_id: Tenant context

        Returns:
            Media entity or None
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Media).where(Media.id == media_id)
                )
                return result.scalar_one_or_none()

    async def list_media(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        media_type: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Media]:
        """List media for a timeline.

        Args:
            timeline_id: The timeline to query
            tenant_id: Tenant context
            media_type: Optional filter by media type
            limit: Max results
            offset: Result offset

        Returns:
            List of Media entities
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                stmt = select(Media).where(Media.timeline_id == timeline_id)

                if media_type:
                    stmt = stmt.where(Media.media_type == media_type)

                stmt = stmt.order_by(Media.created_at.desc()).limit(limit).offset(offset)

                result = await session.execute(stmt)
                return list(result.scalars().all())

    async def list_media_for_event(
        self,
        event_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> List[Media]:
        """List media for a specific event.

        Args:
            event_id: The event ID
            tenant_id: Tenant context

        Returns:
            List of Media entities
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Media).where(Media.event_id == event_id)
                )
                return list(result.scalars().all())

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    async def update_media(
        self,
        media_id: uuid.UUID,
        tenant_id: uuid.UUID,
        **kwargs
    ) -> Optional[Media]:
        """Update media metadata.

        Args:
            media_id: The media ID
            tenant_id: Tenant context
            **kwargs: Fields to update

        Returns:
            Updated Media entity or None
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Media).where(Media.id == media_id)
                )
                media = result.scalar_one_or_none()

                if not media:
                    return None

                # Update fields
                for key, val in kwargs.items():
                    if val is not None and hasattr(media, key):
                        setattr(media, key, val)

                await session.commit()
                await session.refresh(media)
                return media

    async def delete_media(
        self,
        media_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> bool:
        """Delete a media record.

        Args:
            media_id: The media ID
            tenant_id: Tenant context

        Returns:
            True if deleted, False if not found
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Media).where(Media.id == media_id)
                )
                media = result.scalar_one_or_none()

                if not media:
                    return False

                # TODO: Delete from storage backend
                # await self._storage.delete(media.file_url)

                await session.delete(media)
                await session.commit()
                return True

    # ------------------------------------------------------------------
    # Event Anchoring
    # ------------------------------------------------------------------

    async def anchor_to_event(
        self,
        media_id: uuid.UUID,
        event_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Optional[Media]:
        """Attach media to a specific timeline event.

        Args:
            media_id: The media ID
            event_id: The event ID
            tenant_id: Tenant context

        Returns:
            Updated Media entity or None
        """
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                # Get media
                media_result = await session.execute(
                    select(Media).where(Media.id == media_id)
                )
                media = media_result.scalar_one_or_none()

                if not media:
                    return None

                # Verify event exists and belongs to same timeline
                event_result = await session.execute(
                    select(Event).where(Event.id == event_id)
                )
                event = event_result.scalar_one_or_none()

                if not event:
                    raise ValueError(f"Event {event_id} not found")

                if event.timeline_id != media.timeline_id:
                    raise ValueError("Event and media must belong to the same timeline")

                media.event_id = event_id
                await session.commit()
                await session.refresh(media)
                return media

    # ------------------------------------------------------------------
    # Suggested Event Matches
    # ------------------------------------------------------------------

    async def suggest_event_matches(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        date_taken: Optional[date] = None,
        people: Optional[List[Dict[str, Any]]] = None,
        description: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Suggest timeline events that might match uploaded media.

        Based on date, people, or description.

        Args:
            timeline_id: The timeline to search
            tenant_id: Tenant context
            date_taken: Optional date to match
            people: Optional people to match
            description: Optional description to match

        Returns:
            List of dicts with event_id, title, date_start, location, match_score
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .order_by(Event.date_start.desc())
                    .limit(200)
                )
                events = list(result.scalars().all())

        if not events:
            return []

        scored: List[Tuple[float, Event]] = []
        for event in events:
            score = 0.0

            # Date proximity scoring
            if date_taken and event.date_start:
                days_diff = abs((date_taken - event.date_start).days)
                if days_diff == 0:
                    score += 1.0
                elif days_diff <= 30:
                    score += 0.7
                elif days_diff <= 365:
                    score += 0.3
                elif days_diff <= 3650:  # ~10 years
                    score += 0.1

            # People overlap scoring
            if people and event.people:
                event_names = {
                    (p.get("name") or "").lower() for p in event.people
                }
                media_names = {
                    (p.get("name") or "").lower() for p in people
                }
                overlap = event_names & media_names
                if overlap:
                    score += 0.5 * len(overlap)

            # Simple description keyword matching
            if description and event.title:
                desc_words = set(description.lower().split())
                title_words = set(event.title.lower().split())
                common = desc_words & title_words - {"the", "a", "an", "in", "of", "and", "at", "to"}
                if common:
                    score += 0.2 * len(common)

            if score > 0:
                scored.append((score, event))

        # Return top 5 matches
        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {
                "event_id": str(e.id),
                "title": e.title,
                "date_start": str(e.date_start) if e.date_start else None,
                "location": e.location,
                "match_score": round(s, 2),
            }
            for s, e in scored[:5]
        ]
