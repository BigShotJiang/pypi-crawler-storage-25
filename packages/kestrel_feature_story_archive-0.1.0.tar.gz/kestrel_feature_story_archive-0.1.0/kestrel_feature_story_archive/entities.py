"""
Story Archive entities for kestrel-feature-entities ORM.

Schema-equivalent to frinz migrations 031-035. All entities inherit from EntityBase
and use appropriate mixins. Records are scoped to agent_did (VARCHAR(255), the
canonical agent identity per the Agent Identity Contract).

This module is registered via the kestrel_entities.models entry-point for
Alembic autogen discovery.

CRITICAL: This schema is column-by-column equivalent to frinz's existing
story_* tables. Any deviation will break FRINZ-1's adoption migration.
"""

import enum
import struct
import uuid
from datetime import date, datetime
from typing import Optional

from kestrel_feature_entities.base import EntityBase
from kestrel_feature_entities.mixins import TenantMixin, TimestampMixin
from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    desc,
)
from sqlalchemy.sql import text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.types import JSON, LargeBinary, TypeDecorator

try:
    from pgvector.sqlalchemy import Vector

    PGVECTOR_AVAILABLE = True
except ImportError:
    PGVECTOR_AVAILABLE = False


# =============================================================================
# TypeDecorators for portable column types
# =============================================================================


class PortableVector(TypeDecorator):
    """Vector(1536) on PostgreSQL, LargeBinary (packed float32) on SQLite.

    This type decorator allows the embedding column to work across both
    PostgreSQL (using pgvector's native vector type) and SQLite (using
    LargeBinary with packed float32 values).

    On PostgreSQL: Uses pgvector's Vector(1536) type natively
    On SQLite: Packs/unpacks list[float] to/from bytes using struct
    """

    impl = LargeBinary
    cache_ok = True

    def __init__(self, dim: int = 1536):
        super().__init__()
        self.dim = dim

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            if not PGVECTOR_AVAILABLE:
                raise ImportError(
                    "pgvector is required for PostgreSQL dialect. "
                    "Install with: pip install pgvector"
                )
            return dialect.type_descriptor(Vector(self.dim))
        return dialect.type_descriptor(LargeBinary())

    def process_bind_param(self, value, dialect):
        """Convert Python list[float] to database format."""
        if dialect.name == "postgresql" or value is None:
            # pgvector handles list[float] directly
            return value
        # SQLite: pack list[float] → bytes
        if not isinstance(value, (list, tuple)):
            raise ValueError(f"Expected list/tuple, got {type(value)}")
        if len(value) != self.dim:
            raise ValueError(f"Expected {self.dim} dimensions, got {len(value)}")
        return struct.pack(f"<{self.dim}f", *value)

    def process_result_value(self, value, dialect):
        """Convert database format to Python list[float]."""
        if dialect.name == "postgresql" or value is None:
            # pgvector returns list directly
            return value
        # SQLite: unpack bytes → list[float]
        return list(struct.unpack(f"<{self.dim}f", value))


class PortableJSON(TypeDecorator):
    """JSONB on PostgreSQL, JSON on SQLite.

    Use for ALL columns that are JSONB in frinz. This ensures proper
    dialect-specific handling while maintaining cross-database compatibility.
    """

    impl = JSON
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(JSONB())
        return dialect.type_descriptor(JSON())


# =============================================================================
# ENUMs for Contradiction table
# =============================================================================


class ContradictionType(enum.Enum):
    """Contradiction type enum matching frinz's contradiction_type."""

    temporal = "temporal"
    sequential = "sequential"
    factual = "factual"
    attribution = "attribution"
    location = "location"


class ContradictionStatus(enum.Enum):
    """Contradiction status enum matching frinz's contradiction_status."""

    detected = "detected"
    queued = "queued"
    resolved = "resolved"
    accepted_ambiguous = "accepted_ambiguous"


# =============================================================================
# Entity models (10 total)
# =============================================================================


class Timeline(EntityBase, TenantMixin, TimestampMixin):
    """Agent timeline - top-level container for story events.

    Frinz table: story_timelines
    Migration: 031
    """

    __tablename__ = "story_timelines"

    # Primary key (UUIDv4 to match frinz's gen_random_uuid())
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # TenantMixin override: nullable during FEAT-2, FRINZ-1 backfills + sets NOT NULL
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Agent owner (canonical identity from Agent Identity Contract)
    agent_did: Mapped[str] = mapped_column(String(255), nullable=False)

    # Timeline metadata
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Temporal bounds
    earliest_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    latest_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # Statistics
    event_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    session_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    coverage_score: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.0')

    # Privacy
    sharing_mode: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'private'"
    )

    # Metadata (JSONB in frinz) - use metadata_ to avoid SQLAlchemy reserved name
    metadata_: Mapped[dict] = mapped_column(
        "metadata", PortableJSON, nullable=False, default=dict, server_default="{}"
    )

    # TimestampMixin provides: created_at, updated_at (TIMESTAMPTZ)

    __table_args__ = (
        UniqueConstraint("agent_did", name="uq_story_timelines_agent"),
        Index("idx_story_timelines_tenant", "tenant_id"),
    )


class Session(EntityBase, TenantMixin):
    """Story session - a coherent interaction or activity period.

    Frinz table: story_sessions
    Migration: 031
    Note: NO TimestampMixin - frinz has only started_at/ended_at, not created/updated
    """

    __tablename__ = "story_sessions"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # Agent owner
    agent_did: Mapped[str] = mapped_column(String(255), nullable=False)

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Session metadata
    session_type: Mapped[str] = mapped_column(
        String(30), nullable=False, server_default="'initial_life_story'"
    )
    focus_period: Mapped[str | None] = mapped_column(Text, nullable=True)
    focus_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Statistics
    events_extracted: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')

    # People mentioned (JSONB in frinz)
    people_mentioned: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # Session metrics
    duration_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    mood_average: Mapped[float | None] = mapped_column(Float, nullable=True)

    # Temporal (frinz uses started_at/ended_at instead of created/updated)
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=text('NOW()')
    )
    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Metadata (JSONB in frinz) - use metadata_ to avoid SQLAlchemy reserved name
    metadata_: Mapped[dict] = mapped_column(
        "metadata", PortableJSON, nullable=False, default=dict, server_default="{}"
    )

    __table_args__ = (
        Index("idx_story_sessions_timeline", "timeline_id"),
        Index("idx_story_sessions_agent", "agent_did"),
    )


class Event(EntityBase, TenantMixin, TimestampMixin):
    """Story event - atomic interaction, observation, or reflection.

    Frinz table: story_events
    Migration: 031
    """

    __tablename__ = "story_events"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Event metadata
    title: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    event_type: Mapped[str] = mapped_column(String(30), nullable=False, server_default="'memory'")

    # Temporal
    date_start: Mapped[date | None] = mapped_column(Date, nullable=True)
    date_end: Mapped[date | None] = mapped_column(Date, nullable=True)
    date_precision: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'approximate'"
    )
    date_display: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Location
    location: Mapped[str | None] = mapped_column(Text, nullable=True)
    location_details: Mapped[dict | None] = mapped_column(PortableJSON, nullable=True)

    # Sentiment
    emotional_tone: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'neutral'"
    )
    importance: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.5')
    confidence: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.5')

    # Source session
    source_session_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_sessions.id", ondelete="SET NULL"), nullable=True
    )

    # Source messages (JSONB in frinz)
    source_message_ids: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # Entities and categorization (all JSONB in frinz)
    people: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )
    themes: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )
    tags: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # Privacy
    is_sensitive: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default='false')
    privacy_mode: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'normal'"
    )

    # Vector embedding for semantic search (1536 dims)
    embedding: Mapped[list[float] | None] = mapped_column(
        PortableVector(1536), nullable=True
    )

    # TimestampMixin provides: created_at, updated_at (TIMESTAMPTZ)

    __table_args__ = (
        Index("idx_story_events_timeline_date", "timeline_id", "date_start"),
        Index("idx_story_events_timeline_type", "timeline_id", "event_type"),
        # HNSW index for semantic search (PG-only)
        Index(
            "idx_story_events_embedding",
            "embedding",
            postgresql_using="hnsw",
            postgresql_ops={"embedding": "vector_cosine_ops"},
        ),
        # Partial index for non-sensitive events (works on both PG and SQLite)
        Index(
            "idx_story_events_not_sensitive",
            "timeline_id",
            postgresql_where=text("is_sensitive = false"),
        ),
    )


class Person(EntityBase, TenantMixin):
    """Person mentioned or involved in story events.

    Frinz table: story_people
    Migration: 031
    Note: NO TimestampMixin - frinz has no created_at/updated_at on this table
    """

    __tablename__ = "story_people"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Person identity
    name: Mapped[str] = mapped_column(Text, nullable=False)
    relationship: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Aliases (JSONB in frinz)
    aliases: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # First mention
    first_mentioned_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_events.id", ondelete="SET NULL"), nullable=True
    )

    # Statistics
    mention_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='1')

    # Person details
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    date_of_birth: Mapped[date | None] = mapped_column(Date, nullable=True)
    date_of_death: Mapped[date | None] = mapped_column(Date, nullable=True)
    is_alive: Mapped[bool | None] = mapped_column(Boolean, nullable=True)

    # Metadata (JSONB in frinz) - use metadata_ to avoid SQLAlchemy reserved name
    metadata_: Mapped[dict] = mapped_column(
        "metadata", PortableJSON, nullable=False, default=dict, server_default="{}"
    )

    __table_args__ = (
        UniqueConstraint("timeline_id", "name", name="uq_story_people_timeline_name"),
        Index("idx_story_people_timeline", "timeline_id"),
        # GIN index on aliases for pg_trgm search (PG-only)
        Index(
            "idx_story_people_aliases",
            "aliases",
            postgresql_using="gin",
            postgresql_ops={"aliases": "jsonb_path_ops"},
        ),
    )


class Media(EntityBase, TenantMixin):
    """Media attachments (images, audio, video, files) associated with events.

    Frinz table: story_media
    Migration: 031
    Note: NO TimestampMixin - frinz has only created_at, no updated_at
    """

    __tablename__ = "story_media"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign keys
    event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_events.id", ondelete="SET NULL"), nullable=True
    )
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Media metadata
    media_type: Mapped[str] = mapped_column(String(20), nullable=False, server_default="'photo'")
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Storage
    file_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    ipfs_cid: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    file_size: Mapped[int | None] = mapped_column(Integer, nullable=True)
    mime_type: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # Temporal
    date_taken: Mapped[date | None] = mapped_column(Date, nullable=True)
    date_precision: Mapped[str | None] = mapped_column(String(20), nullable=True)

    # People (JSONB in frinz)
    people: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # Metadata (JSONB in frinz) - use metadata_ to avoid SQLAlchemy reserved name
    metadata_: Mapped[dict] = mapped_column(
        "metadata", PortableJSON, nullable=False, default=dict, server_default="{}"
    )

    # Upload source
    upload_source: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'user_upload'"
    )

    # Timestamp (only created_at, no updated_at - manually added, not from mixin)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=text('NOW()')
    )

    __table_args__ = (
        Index("idx_story_media_event", "event_id"),
        Index("idx_story_media_timeline", "timeline_id"),
    )


class SharingPermission(EntityBase, TenantMixin):
    """Sharing permissions for story timelines and events.

    Frinz table: story_sharing
    Migrations: 031, 033
    Note: NO TimestampMixin - frinz uses granted_at/revoked_at instead
    """

    __tablename__ = "story_sharing"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Who has access (decoupled from frinz's trusted_circle_members FK)
    circle_member_id: Mapped[uuid.UUID] = mapped_column(nullable=False)

    # What is shared
    scope: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'full_timeline'"
    )
    scope_filter: Mapped[dict | None] = mapped_column(PortableJSON, nullable=True)

    # Granted by (decoupled from frinz's users FK)
    granted_by: Mapped[uuid.UUID] = mapped_column(nullable=False)
    granted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=text('NOW()')
    )

    # Revocation
    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Usage tracking
    access_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    last_accessed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        Index("idx_story_sharing_timeline", "timeline_id"),
        Index("idx_story_sharing_member", "circle_member_id"),
        # Partial index for active sharing permissions (migration 033)
        Index(
            "idx_story_sharing_active",
            "timeline_id",
            "circle_member_id",
            postgresql_where=text("revoked_at IS NULL"),
        ),
    )


class Contradiction(EntityBase, TenantMixin, TimestampMixin):
    """Detected contradictions between story events.

    Frinz table: story_contradictions
    Migration: 032
    Note: Uses TIMESTAMP (not TIMESTAMPTZ) - must override TimestampMixin columns
    """

    __tablename__ = "story_contradictions"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Conflicting events
    event_id_a: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_events.id", ondelete="CASCADE"), nullable=False
    )
    event_id_b: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_events.id", ondelete="CASCADE"), nullable=False
    )

    # Contradiction type (ENUM in frinz)
    contradiction_type: Mapped[ContradictionType] = mapped_column(
        Enum(ContradictionType, name="contradiction_type"),
        nullable=False,
        server_default='factual',
    )

    # Status (ENUM in frinz)
    status: Mapped[ContradictionStatus] = mapped_column(
        Enum(ContradictionStatus, name="contradiction_status"),
        nullable=False,
        server_default='detected',
    )

    # Contradiction details
    field_name: Mapped[str | None] = mapped_column(Text, nullable=True)
    value_a: Mapped[str | None] = mapped_column(Text, nullable=True)
    value_b: Mapped[str | None] = mapped_column(Text, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Confidence scores
    confidence_a: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.5')
    confidence_b: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.5')

    # Source sessions
    session_id_a: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_sessions.id", ondelete="SET NULL"), nullable=True
    )
    session_id_b: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_sessions.id", ondelete="SET NULL"), nullable=True
    )

    # Resolution
    resolved_version: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolved_event_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_events.id", ondelete="SET NULL"), nullable=True
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    resolved_by: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Metadata (JSONB in frinz) - use metadata_ to avoid SQLAlchemy reserved name
    metadata_: Mapped[dict] = mapped_column(
        "metadata", PortableJSON, nullable=False, default=dict, server_default="{}"
    )

    # Override TimestampMixin to use TIMESTAMP (not TIMESTAMPTZ) as in frinz migration 032
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), nullable=False, server_default=text('NOW()')
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), nullable=False, server_default=text('NOW()')
    )

    __table_args__ = (
        Index("idx_story_contradictions_timeline", "timeline_id"),
        Index("idx_story_contradictions_status", "timeline_id", "status"),
        Index("idx_story_contradictions_events", "event_id_a", "event_id_b"),
    )


class Repetition(EntityBase, TenantMixin):
    """Detected repetitions of story events across sessions.

    Frinz table: story_repetitions
    Migration: 034
    Note: NO TimestampMixin - frinz has only created_at (TIMESTAMP, not TIMESTAMPTZ)
    """

    __tablename__ = "story_repetitions"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Canonical and repeated events
    canonical_event_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_events.id", ondelete="CASCADE"), nullable=False
    )
    repeated_event_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_events.id", ondelete="CASCADE"), nullable=False
    )

    # Similarity score
    similarity_score: Mapped[float] = mapped_column(Float, nullable=False, server_default='0.0')

    # New details (JSONB in frinz)
    new_details: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # Telling count
    telling_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='2')

    # Notes
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Source sessions
    canonical_session_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_sessions.id", ondelete="SET NULL"), nullable=True
    )
    repeated_session_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("story_sessions.id", ondelete="SET NULL"), nullable=True
    )

    # Timestamp (only created_at, TIMESTAMP not TIMESTAMPTZ)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), nullable=False, server_default=text('NOW()')
    )

    __table_args__ = (
        Index("idx_story_repetitions_timeline", "timeline_id"),
        Index("idx_story_repetitions_canonical", "canonical_event_id"),
    )


class ReplayQuery(EntityBase, TenantMixin):
    """Saved replay queries for story archive retrieval.

    Frinz table: story_replay_queries
    Migration: 034
    Note: NO TimestampMixin - frinz has only created_at (TIMESTAMP, not TIMESTAMPTZ)
    """

    __tablename__ = "story_replay_queries"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Question
    question: Mapped[str] = mapped_column(Text, nullable=False)

    # Asker (decoupled from frinz's trusted_circle_members FK)
    asker_circle_member_id: Mapped[uuid.UUID] = mapped_column(nullable=False)

    # Event IDs cited (JSONB in frinz)
    event_ids_cited: Mapped[list] = mapped_column(
        PortableJSON, nullable=False, default=list, server_default="[]"
    )

    # No information flag
    no_information: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default='false')

    # Timestamp (only created_at, TIMESTAMP not TIMESTAMPTZ)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), nullable=True, server_default=text('NOW()')
    )

    __table_args__ = (
        Index(
            "idx_story_replay_queries_timeline",
            "timeline_id",
            desc("created_at"),
        ),
        Index(
            "idx_story_replay_queries_asker",
            "asker_circle_member_id",
            desc("created_at"),
        ),
    )


class Export(EntityBase, TenantMixin):
    """Story archive export jobs and artifacts.

    Frinz table: story_exports
    Migration: 035
    Note: NO TimestampMixin - frinz uses exported_at instead of created/updated
    """

    __tablename__ = "story_exports"

    # Primary key (UUIDv4 to match frinz)
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # Foreign key to timeline
    timeline_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("story_timelines.id", ondelete="CASCADE"), nullable=False
    )

    # Agent owner
    agent_did: Mapped[str] = mapped_column(String(255), nullable=False)

    # TenantMixin override: nullable during FEAT-2
    tenant_id: Mapped[uuid.UUID | None] = mapped_column(nullable=True)

    # Export metadata
    cid: Mapped[str] = mapped_column(String(255), nullable=False)
    tier: Mapped[str] = mapped_column(String(20), nullable=False, server_default="'ipfs'")
    schema_version: Mapped[str] = mapped_column(String(10), nullable=False, server_default="'1.0'")

    # Statistics
    event_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    person_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    session_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    media_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default='0')
    archive_size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, server_default='0')

    # Export parameters
    trigger: Mapped[str] = mapped_column(String(30), nullable=False, server_default="'manual'")
    status: Mapped[str] = mapped_column(String(20), nullable=False, server_default="'completed'")
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Timestamp (exported_at instead of created/updated)
    exported_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=text('NOW()')
    )

    __table_args__ = (
        Index("idx_story_exports_timeline", "timeline_id"),
        Index("idx_story_exports_agent", "agent_did"),
        Index("idx_story_exports_cid", "cid"),
    )


# Export all entity classes for entry-point registration
__all__ = [
    "Timeline",
    "Session",
    "Event",
    "Person",
    "Media",
    "SharingPermission",
    "Contradiction",
    "Repetition",
    "ReplayQuery",
    "Export",
    "PortableVector",
    "PortableJSON",
    "ContradictionType",
    "ContradictionStatus",
]
