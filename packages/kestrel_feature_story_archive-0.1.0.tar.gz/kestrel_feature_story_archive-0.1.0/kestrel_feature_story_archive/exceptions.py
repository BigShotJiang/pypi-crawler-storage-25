"""
Story Archive exceptions.

Service-layer exceptions for timeline building and story extraction.
These replace FastAPI HTTPException for reusable framework components.
"""


class TimelineNotFoundError(Exception):
    """Timeline was not found in the database."""

    def __init__(self, timeline_id: str, message: str = ""):
        self.timeline_id = timeline_id
        super().__init__(message or f"Timeline {timeline_id} not found")


class ExtractionError(Exception):
    """Story extraction pipeline failed."""

    def __init__(self, message: str, session_id: str = "", step: str = ""):
        self.session_id = session_id
        self.step = step
        super().__init__(message)


class SessionNotFoundError(Exception):
    """Story session was not found in the database."""

    def __init__(self, session_id: str, message: str = ""):
        self.session_id = session_id
        super().__init__(message or f"Session {session_id} not found")


class PersonNotFoundError(Exception):
    """Person record was not found in the database."""

    def __init__(self, person_id: str, message: str = ""):
        self.person_id = person_id
        super().__init__(message or f"Person {person_id} not found")


class VectorSearchError(Exception):
    """Vector search operation failed."""

    pass
