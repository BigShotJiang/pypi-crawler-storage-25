"""
Timeline Builder — Cross-session entity linking and timeline construction.

Weaves isolated story sessions into a coherent timeline by:
1. Person resolution (fuzzy matching + LLM disambiguation)
2. Place clustering
3. Temporal ordering (handling fuzzy dates)
4. Theme extraction and clustering
5. Relationship graph construction
6. Coverage analysis and gap detection

Ported from frinz/services/timeline_builder.py for kestrel-feature-story-archive.
"""

import json
import logging
import uuid
from collections import Counter, defaultdict
from datetime import date
from typing import Any, Callable, Dict, List, Optional, Tuple, Awaitable

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import Timeline, Session, Event, Person
from .exceptions import TimelineNotFoundError, SessionNotFoundError, PersonNotFoundError

logger = logging.getLogger(__name__)

# Life-period boundaries (approximate ages)
LIFE_PERIODS = [
    ("Childhood", 0, 12),
    ("Teenage Years", 13, 19),
    ("Young Adulthood", 20, 29),
    ("Thirties", 30, 39),
    ("Middle Age", 40, 59),
    ("Later Life", 60, 79),
    ("Elder Years", 80, 120),
]


class TimelineBuilder:
    """Cross-session entity linking and timeline construction service.

    Connects people, places, and themes across multiple story sessions
    into a coherent timeline graph.
    """

    def __init__(
        self,
        session_factory,
        llm: Optional[Callable[[str], Awaitable[str]]] = None,
    ):
        """Initialize the timeline builder.

        Args:
            session_factory: AsyncSessionFactory for database access
            llm: Optional async LLM callable for disambiguation (str -> str)
        """
        self._sf = session_factory
        self._llm = llm

    # -------------------------------------------------------------------------
    # Session Integration
    # -------------------------------------------------------------------------

    async def integrate_session(
        self,
        session_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Integrate a completed session into the timeline graph.

        Links extracted events and people to the broader timeline,
        resolves person references, and updates coherence metrics.

        Args:
            session_id: The session to integrate
            tenant_id: The tenant (user) ID

        Returns:
            Dict with integration stats
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Session).where(Session.id == session_id)
                )
                story_session = result.scalar_one_or_none()

                if not story_session:
                    raise SessionNotFoundError(str(session_id))

                timeline_id = story_session.timeline_id

                # Get all events from this session
                all_events_result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .limit(1000)
                )
                all_events = all_events_result.scalars().all()
                session_events = [
                    e for e in all_events if e.source_session_id == session_id
                ]

                # Get all people
                people_result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = people_result.scalars().all()

        # Resolve people mentioned in session events against existing people
        people_resolved = 0
        people_created = 0
        for event in session_events:
            for person_ref in (event.people or []):
                name = person_ref.get("name") if isinstance(person_ref, dict) else getattr(person_ref, "name", None)
                if not name:
                    continue
                resolution = await self.resolve_person(
                    timeline_id, name, context=event.description or "", tenant_id=tenant_id
                )
                if resolution["person_id"]:
                    people_resolved += 1
                else:
                    people_created += 1

        # Extract themes from session events
        themes_found = set()
        for event in session_events:
            for theme in (event.themes or []):
                themes_found.add(theme)

        # Calculate coherence
        coherence = await self._calculate_coherence(
            timeline_id, all_events, people, tenant_id
        )

        # Update timeline coverage score
        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = result.scalar_one_or_none()
                if timeline:
                    timeline.coverage_score = coherence
                    await session.commit()

        return {
            "session_id": str(session_id),
            "timeline_id": str(timeline_id),
            "people_resolved": people_resolved,
            "people_created": people_created,
            "events_linked": len(session_events),
            "themes_found": sorted(themes_found),
            "coherence_score": coherence,
        }

    # -------------------------------------------------------------------------
    # Person Resolution
    # -------------------------------------------------------------------------

    async def resolve_person(
        self,
        timeline_id: uuid.UUID,
        name: str,
        context: str = "",
        tenant_id: uuid.UUID = None,
    ) -> Dict[str, Any]:
        """Resolve a person name against existing story_people records.

        Resolution pipeline:
        1. Exact name match
        2. Alias match (case-insensitive)
        3. Fuzzy substring match
        4. LLM disambiguation (if multiple candidates)

        Returns a PersonResolution dict with match details.
        """
        if not tenant_id:
            raise ValueError("tenant_id is required")

        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = result.scalars().all()

        if not name or not name.strip():
            return {
                "person_id": None,
                "name": name,
                "matched_name": None,
                "confidence": 0.0,
                "match_type": None,
                "needs_confirmation": False,
                "candidates": [],
            }

        name_lower = name.strip().lower()

        # 1. Exact name match
        for person in people:
            if person.name.lower() == name_lower:
                return {
                    "person_id": str(person.id),
                    "name": name,
                    "matched_name": person.name,
                    "confidence": 1.0,
                    "match_type": "exact",
                    "needs_confirmation": False,
                    "candidates": [],
                }

        # 2. Alias match
        for person in people:
            for alias in (person.aliases or []):
                if alias.lower() == name_lower:
                    return {
                        "person_id": str(person.id),
                        "name": name,
                        "matched_name": person.name,
                        "confidence": 0.95,
                        "match_type": "alias",
                        "needs_confirmation": False,
                        "candidates": [],
                    }

        # 3. Fuzzy matching — check for common nickname/name patterns
        candidates = []
        for person in people:
            score = _fuzzy_name_score(name_lower, person.name.lower(), person.aliases or [])
            if score > 0.3:
                candidates.append({
                    "person_id": str(person.id),
                    "name": person.name,
                    "relationship": person.relationship,
                    "aliases": person.aliases or [],
                    "score": score,
                })

        # Sort candidates by score descending
        candidates.sort(key=lambda c: c["score"], reverse=True)

        if candidates:
            best = candidates[0]
            if best["score"] >= 0.8:
                return {
                    "person_id": best["person_id"],
                    "name": name,
                    "matched_name": best["name"],
                    "confidence": best["score"],
                    "match_type": "fuzzy",
                    "needs_confirmation": False,
                    "candidates": candidates[:3],
                }

            # Multiple ambiguous candidates — needs confirmation or LLM
            if len(candidates) >= 2 and context and self._llm:
                llm_result = await _llm_disambiguate(name, candidates[:5], context, self._llm)
                if llm_result:
                    return {
                        "person_id": llm_result["person_id"],
                        "name": name,
                        "matched_name": llm_result["name"],
                        "confidence": llm_result.get("confidence", 0.7),
                        "match_type": "llm",
                        "needs_confirmation": llm_result.get("confidence", 0.7) < 0.8,
                        "candidates": candidates[:3],
                    }

            # Single fuzzy candidate — flag for confirmation
            return {
                "person_id": best["person_id"],
                "name": name,
                "matched_name": best["name"],
                "confidence": best["score"],
                "match_type": "fuzzy",
                "needs_confirmation": True,
                "candidates": candidates[:3],
            }

        # No match found
        return {
            "person_id": None,
            "name": name,
            "matched_name": None,
            "confidence": 0.0,
            "match_type": None,
            "needs_confirmation": False,
            "candidates": [],
        }

    # -------------------------------------------------------------------------
    # Timeline Views
    # -------------------------------------------------------------------------

    async def get_timeline_view(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        view_type: str = "chronological",
    ) -> Dict[str, Any]:
        """Get a structured timeline view.

        view_type options:
        - "chronological": Events sorted by date with period grouping
        - "by_person": Events grouped by people involved
        - "by_theme": Events grouped by theme
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

                events_result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .limit(1000)
                )
                events = events_result.scalars().all()

                people_result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = people_result.scalars().all()

        # Sort events by date
        sorted_events = _sort_events_by_date(events)

        # Build period groupings
        periods = _build_periods(sorted_events, timeline)

        # Build event dicts
        event_dicts = []
        for e in sorted_events:
            period_name = _get_period_for_event(e, periods)
            event_dicts.append({
                "id": str(e.id),
                "title": e.title,
                "description": e.description,
                "event_type": e.event_type,
                "date_start": e.date_start.isoformat() if e.date_start else None,
                "date_end": e.date_end.isoformat() if e.date_end else None,
                "date_precision": e.date_precision,
                "date_display": getattr(e, "date_display", None),
                "location": e.location,
                "emotional_tone": e.emotional_tone,
                "importance": e.importance,
                "confidence": e.confidence,
                "people": e.people or [],
                "themes": e.themes or [],
                "period": period_name,
            })

        period_dicts = []
        for p in periods:
            period_dicts.append({
                "name": p["name"],
                "start_year": p.get("start_year"),
                "end_year": p.get("end_year"),
                "event_count": p["event_count"],
                "themes": p.get("themes", []),
                "key_people": p.get("key_people", []),
            })

        return {
            "timeline_id": str(timeline_id),
            "agent_did": timeline.agent_did,
            "view_type": view_type,
            "events": event_dicts,
            "periods": period_dicts,
            "people_count": len(people),
            "event_count": len(events),
            "earliest_date": timeline.earliest_date.isoformat() if timeline.earliest_date else None,
            "latest_date": timeline.latest_date.isoformat() if timeline.latest_date else None,
        }

    # -------------------------------------------------------------------------
    # People
    # -------------------------------------------------------------------------

    async def get_all_people(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Get all people in a timeline with relationship details."""
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

                people_result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = people_result.scalars().all()

                events_result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .limit(1000)
                )
                events = events_result.scalars().all()

        # Build person → events index
        person_events: Dict[str, List[str]] = defaultdict(list)
        for event in events:
            for person_ref in (event.people or []):
                pid = person_ref.get("person_id") if isinstance(person_ref, dict) else None
                pname = person_ref.get("name") if isinstance(person_ref, dict) else None
                if pid:
                    person_events[str(pid)].append(str(event.id))
                elif pname:
                    # Match by name
                    for p in people:
                        if p.name.lower() == pname.lower() or pname.lower() in [a.lower() for a in (p.aliases or [])]:
                            person_events[str(p.id)].append(str(event.id))
                            break

        people_dicts = []
        for p in people:
            people_dicts.append({
                "id": str(p.id),
                "name": p.name,
                "relationship": p.relationship,
                "aliases": p.aliases or [],
                "mention_count": p.mention_count,
                "description": p.description,
                "date_of_birth": p.date_of_birth.isoformat() if p.date_of_birth else None,
                "date_of_death": p.date_of_death.isoformat() if p.date_of_death else None,
                "is_alive": p.is_alive,
                "event_ids": person_events.get(str(p.id), []),
            })

        return {
            "timeline_id": str(timeline_id),
            "people": people_dicts,
            "count": len(people_dicts),
        }

    # -------------------------------------------------------------------------
    # Coverage & Gaps
    # -------------------------------------------------------------------------

    async def get_coverage_report(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> Dict[str, Any]:
        """Analyze timeline coverage and identify gaps.

        Calculates:
        - Period-by-period event density
        - Orphan names (mentioned but not in story_people)
        - Timeline coherence score
        - Suggestions for filling gaps
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

                events_result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .limit(1000)
                )
                events = events_result.scalars().all()

                people_result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = people_result.scalars().all()

                sessions_result = await session.execute(
                    select(Session).where(Session.timeline_id == timeline_id)
                )
                sessions = sessions_result.scalars().all()

        # Decade coverage
        decade_counts: Dict[int, int] = defaultdict(int)
        for e in events:
            if e.date_start:
                decade = (e.date_start.year // 10) * 10
                decade_counts[decade] += 1

        # Find gaps
        gaps = []
        if timeline.earliest_date and timeline.latest_date:
            start_decade = (timeline.earliest_date.year // 10) * 10
            end_decade = (timeline.latest_date.year // 10) * 10
            for decade in range(start_decade, end_decade + 10, 10):
                if decade_counts.get(decade, 0) == 0:
                    gaps.append({
                        "period": f"{decade}s",
                        "decade": decade,
                        "gap_type": "decade_gap",
                        "suggestion": f"Tell me about life in the {decade}s",
                    })

        # Period scores (events per decade, normalized)
        period_scores: Dict[str, float] = {}
        if decade_counts:
            max_count = max(decade_counts.values()) if decade_counts else 1
            for decade, count in sorted(decade_counts.items()):
                period_scores[f"{decade}s"] = round(count / max(max_count, 1), 2)

        # Orphan names: people mentioned in events but not in story_people
        known_names = {p.name.lower() for p in people}
        known_aliases = set()
        for p in people:
            for a in (p.aliases or []):
                known_aliases.add(a.lower())
        all_known = known_names | known_aliases

        orphan_names = set()
        for event in events:
            for ref in (event.people or []):
                pname = ref.get("name") if isinstance(ref, dict) else None
                if pname and pname.lower() not in all_known:
                    orphan_names.add(pname)

        # Coherence score
        coherence = await self._calculate_coherence(
            timeline_id, events, people, tenant_id
        )

        # Suggestions
        suggestions = []
        for gap in gaps[:3]:
            suggestions.append({
                "topic": gap["suggestion"],
                "reason": f"No events recorded for the {gap['period']}",
                "session_type": "deepening",
                "focus_period": gap["period"],
                "priority": "medium",
            })

        for orphan in list(orphan_names)[:3]:
            suggestions.append({
                "topic": f"Tell me more about {orphan}",
                "reason": f"{orphan} is mentioned in events but has no detailed record",
                "session_type": "prompted",
                "focus_prompt": f"Tell me about {orphan}",
                "priority": "low",
            })

        return {
            "timeline_id": str(timeline_id),
            "coverage_score": coherence,
            "total_events": len(events),
            "total_people": len(people),
            "total_sessions": len(sessions),
            "earliest_date": timeline.earliest_date.isoformat() if timeline.earliest_date else None,
            "latest_date": timeline.latest_date.isoformat() if timeline.latest_date else None,
            "gaps": gaps,
            "period_scores": period_scores,
            "orphan_names": sorted(orphan_names),
            "suggestions": suggestions,
        }

    # -------------------------------------------------------------------------
    # Coherence Scoring
    # -------------------------------------------------------------------------

    async def _calculate_coherence(
        self,
        timeline_id: uuid.UUID,
        events: List[Event],
        people: List[Person],
        tenant_id: uuid.UUID,
    ) -> float:
        """Calculate a timeline coherence score (0.0–1.0).

        Based on:
        - Temporal consistency (no contradictions) — 25%
        - Entity resolution completeness (no orphan names) — 25%
        - Coverage evenness (no decades-long gaps) — 25%
        - Cross-reference density (events connected to people/places) — 25%
        """
        if not events:
            return 0.0

        # 1. Temporal consistency: check date ordering makes sense
        dated_events = [e for e in events if e.date_start]
        temporal_score = 1.0
        if len(dated_events) >= 2:
            # Check what fraction of events have dates
            temporal_score = len(dated_events) / len(events)

        # 2. Entity resolution: what fraction of mentioned people are resolved?
        known_names = {p.name.lower() for p in people}
        for p in people:
            for a in (p.aliases or []):
                known_names.add(a.lower())

        total_mentions = 0
        resolved_mentions = 0
        for event in events:
            for ref in (event.people or []):
                pname = ref.get("name") if isinstance(ref, dict) else None
                if pname:
                    total_mentions += 1
                    if pname.lower() in known_names:
                        resolved_mentions += 1

        entity_score = (resolved_mentions / total_mentions) if total_mentions > 0 else 1.0

        # 3. Coverage evenness
        if dated_events:
            decade_counts: Dict[int, int] = defaultdict(int)
            for e in dated_events:
                decade = (e.date_start.year // 10) * 10
                decade_counts[decade] += 1

            if len(decade_counts) >= 2:
                min_year = min(e.date_start.year for e in dated_events)
                max_year = max(e.date_start.year for e in dated_events)
                start_decade = (min_year // 10) * 10
                end_decade = (max_year // 10) * 10
                total_decades = ((end_decade - start_decade) // 10) + 1
                covered_decades = len(decade_counts)
                coverage_score = covered_decades / total_decades if total_decades > 0 else 1.0
            else:
                coverage_score = 0.5  # Only one decade covered
        else:
            coverage_score = 0.0

        # 4. Cross-reference density: events with people + themes
        connected = 0
        for event in events:
            has_people = bool(event.people)
            has_themes = bool(event.themes)
            has_location = bool(event.location)
            if has_people and (has_themes or has_location):
                connected += 1
            elif has_people or has_themes:
                connected += 0.5

        density_score = (connected / len(events)) if events else 0.0

        # Weighted average
        coherence = (
            temporal_score * 0.25
            + entity_score * 0.25
            + coverage_score * 0.25
            + density_score * 0.25
        )

        return round(min(1.0, max(0.0, coherence)), 3)


# =============================================================================
# Helper Functions
# =============================================================================

def _fuzzy_name_score(query: str, name: str, aliases: List[str]) -> float:
    """Score how well a query matches a person name/aliases.

    Returns 0.0–1.0 with heuristics for:
    - Substring containment
    - Common nickname patterns
    - Prefix matching
    """
    query = query.strip().lower()
    name = name.strip().lower()

    if not query or not name:
        return 0.0

    # Check all names (primary + aliases)
    all_names = [name] + [a.lower() for a in aliases]

    best_score = 0.0
    for candidate in all_names:
        score = _score_pair(query, candidate)
        best_score = max(best_score, score)

    return best_score


def _score_pair(query: str, candidate: str) -> float:
    """Score a single query-candidate pair."""
    if query == candidate:
        return 1.0

    # One contains the other
    if query in candidate or candidate in query:
        shorter = min(len(query), len(candidate))
        longer = max(len(query), len(candidate))
        return 0.5 + 0.4 * (shorter / longer)

    # First/last name overlap (split on space)
    q_parts = set(query.split())
    c_parts = set(candidate.split())
    overlap = q_parts & c_parts
    if overlap:
        total = q_parts | c_parts
        return round(0.4 + 0.4 * (len(overlap) / len(total)), 6)

    # Shared prefix
    prefix_len = 0
    for a, b in zip(query, candidate):
        if a == b:
            prefix_len += 1
        else:
            break

    if prefix_len >= 3:
        return 0.3 + 0.3 * (prefix_len / max(len(query), len(candidate)))

    return 0.0


def _sort_events_by_date(events: List[Event]) -> List[Event]:
    """Sort events by date_start, handling None dates (put them at the end)."""
    dated = [e for e in events if e.date_start]
    undated = [e for e in events if not e.date_start]

    dated.sort(key=lambda e: e.date_start)
    return dated + undated


def _build_periods(
    sorted_events: List[Event],
    timeline: Timeline,
) -> List[Dict[str, Any]]:
    """Build period groupings from sorted events."""
    decade_events: Dict[int, List[Event]] = defaultdict(list)
    for e in sorted_events:
        if e.date_start:
            decade = (e.date_start.year // 10) * 10
            decade_events[decade].append(e)

    periods = []
    for decade in sorted(decade_events.keys()):
        d_events = decade_events[decade]

        # Collect themes and people
        themes: Counter = Counter()
        people_counter: Counter = Counter()
        for e in d_events:
            for t in (e.themes or []):
                themes[t] += 1
            for ref in (e.people or []):
                pname = ref.get("name") if isinstance(ref, dict) else None
                if pname:
                    people_counter[pname] += 1

        periods.append({
            "name": f"{decade}s",
            "start_year": decade,
            "end_year": decade + 9,
            "event_count": len(d_events),
            "themes": [t for t, _ in themes.most_common(5)],
            "key_people": [p for p, _ in people_counter.most_common(5)],
        })

    return periods


def _get_period_for_event(event: Event, periods: List[Dict[str, Any]]) -> Optional[str]:
    """Get the period name for an event based on its date."""
    if not event.date_start:
        return None
    decade = (event.date_start.year // 10) * 10
    for p in periods:
        if p.get("start_year") == decade:
            return p["name"]
    return f"{decade}s"


async def _llm_disambiguate(
    name: str,
    candidates: List[Dict[str, Any]],
    context: str,
    llm: Callable[[str], Awaitable[str]],
) -> Optional[Dict[str, Any]]:
    """Use LLM to disambiguate between person candidates.

    Returns the best match or None if uncertain.
    """
    try:
        candidates_text = "\n".join([
            f"- ID: {c['person_id']}, Name: {c['name']}, "
            f"Relationship: {c.get('relationship', 'unknown')}, "
            f"Aliases: {', '.join(c.get('aliases', []))}"
            for c in candidates
        ])

        prompt = f"""Given this context from a life story conversation:
"{context[:500]}"

The name "{name}" was mentioned. Which of these existing people is it most likely referring to?

{candidates_text}

If you can determine which person "{name}" refers to, respond with ONLY a JSON object:
{{"person_id": "...", "name": "...", "confidence": 0.0-1.0, "reasoning": "..."}}

If none match or it's too ambiguous, respond with:
{{"person_id": null, "confidence": 0.0, "reasoning": "..."}}"""

        response = await llm(prompt)

        # Expecting JSON response
        data = json.loads(response)

        if data.get("person_id"):
            return {
                "person_id": data["person_id"],
                "name": data.get("name", name),
                "confidence": float(data.get("confidence", 0.7)),
            }
        return None

    except Exception as e:
        logger.warning(f"LLM disambiguation failed for '{name}': {e}")
        return None
