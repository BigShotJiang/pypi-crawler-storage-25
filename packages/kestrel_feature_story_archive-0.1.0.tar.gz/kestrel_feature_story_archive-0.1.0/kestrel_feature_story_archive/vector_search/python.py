"""
PurePythonBackend — SQLite-friendly vector search using numpy cosine similarity.

Fetches all embedding BLOBs and computes cosine similarity in Python. Slow at scale
but works on any SQLAlchemy-supported database without pgvector.

Adapted from kestrel-sovereign/storage/async_rag_store.py for entity sessions.
"""

import logging
import struct
from typing import Any, Dict, List, Optional, Tuple

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from ..entities import Event
from ..exceptions import VectorSearchError

logger = logging.getLogger(__name__)


class PurePythonBackend:
    """Pure-Python cosine similarity over BLOB embeddings. SQLite-friendly. Slow at scale."""

    supports_filters = True

    def __init__(self, session_factory):
        """Initialize the backend with a session factory.

        Args:
            session_factory: AsyncSessionFactory for database access
        """
        self._sf = session_factory

    async def knn(
        self,
        query_embedding: bytes,
        k: int,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[str, float]]:
        """Find k nearest neighbors using pure-Python cosine similarity.

        Args:
            query_embedding: Query vector as packed bytes (little-endian float32)
            k: Number of neighbors to return
            filter: Optional filter dict with keys:
                - timeline_id: UUID (required)
                - tenant_id: UUID (required)
                - event_type: str
                - is_sensitive: bool

        Returns:
            List of (event_id, similarity) tuples sorted by similarity DESC
        """
        if not filter or "timeline_id" not in filter or "tenant_id" not in filter:
            raise VectorSearchError("PurePythonBackend.knn requires filter with timeline_id and tenant_id")

        try:
            import numpy as np
        except ImportError:
            raise VectorSearchError("numpy is required for PurePythonBackend")

        # Unpack query embedding
        query_vec = self._deserialize_embedding(query_embedding)
        query_np = np.array(query_vec, dtype=np.float32)
        query_norm = np.linalg.norm(query_np)

        if query_norm == 0:
            logger.warning("Query embedding has zero norm — returning empty results")
            return []

        timeline_id = filter["timeline_id"]
        tenant_id = filter["tenant_id"]

        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                # Build WHERE clause from filter
                stmt = select(Event.id, Event.embedding).where(
                    and_(
                        Event.timeline_id == timeline_id,
                        Event.embedding.isnot(None),
                    )
                )

                # Apply optional filters
                if "event_type" in filter:
                    stmt = stmt.where(Event.event_type == filter["event_type"])
                if "is_sensitive" in filter:
                    stmt = stmt.where(Event.is_sensitive == filter["is_sensitive"])

                result = await session.execute(stmt)
                rows = result.all()

                if not rows:
                    return []

                # Compute cosine similarity for each candidate
                scored = []
                for event_id, embedding_data in rows:
                    if not embedding_data:
                        continue

                    try:
                        # Deserialize event embedding
                        # The PortableVector type may have already deserialized it
                        if isinstance(embedding_data, (list, tuple)):
                            event_vec = embedding_data
                        else:
                            event_vec = self._deserialize_embedding(embedding_data)

                        event_np = np.array(event_vec, dtype=np.float32)
                        event_norm = np.linalg.norm(event_np)

                        if event_norm == 0:
                            continue

                        # Cosine similarity: dot product / (norm_q * norm_e)
                        similarity = float(np.dot(query_np, event_np) / (query_norm * event_norm))
                        scored.append((str(event_id), similarity))
                    except Exception as e:
                        logger.warning(f"Failed to score event {event_id}: {e}")
                        continue

                # Sort by similarity descending and return top-k
                scored.sort(key=lambda x: x[1], reverse=True)
                return scored[:k]

    def _deserialize_embedding(self, data: bytes) -> List[float]:
        """Deserialize embedding from bytes (little-endian float32).

        Args:
            data: Packed embedding bytes

        Returns:
            List of floats
        """
        count = len(data) // 4  # 4 bytes per float32
        return list(struct.unpack(f"<{count}f", data))
