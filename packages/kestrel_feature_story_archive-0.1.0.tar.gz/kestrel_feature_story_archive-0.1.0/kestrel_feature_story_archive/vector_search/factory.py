"""
Vector search backend factory.

Dispatches to the appropriate VectorSearchBackend implementation based on
the database engine dialect.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def get_vector_backend(session_factory) -> Any:
    """Pick the right vector backend based on engine dialect.

    Args:
        session_factory: AsyncSessionFactory instance

    Returns:
        VectorSearchBackend instance (PgVectorBackend or PurePythonBackend)
    """
    dialect = session_factory.engine.dialect.name

    if dialect == "postgresql":
        from .pg import PgVectorBackend
        logger.info("Using PgVectorBackend for PostgreSQL")
        return PgVectorBackend(session_factory)

    # Fallback to PurePython for SQLite and other dialects
    from .python import PurePythonBackend
    logger.info(f"Using PurePythonBackend for dialect={dialect}")
    return PurePythonBackend(session_factory)
