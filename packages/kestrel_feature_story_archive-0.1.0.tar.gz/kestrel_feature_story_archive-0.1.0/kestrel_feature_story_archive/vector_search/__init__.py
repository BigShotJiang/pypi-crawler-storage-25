"""
Vector search backends for story archive.

Provides two implementations of VectorSearchBackend:
- PgVectorBackend: Fast pgvector-based search for PostgreSQL
- PurePythonBackend: Pure-Python cosine similarity for SQLite

Use get_vector_backend() to automatically select the right backend.
"""

from .factory import get_vector_backend
from .pg import PgVectorBackend
from .python import PurePythonBackend

__all__ = [
    "get_vector_backend",
    "PgVectorBackend",
    "PurePythonBackend",
]
