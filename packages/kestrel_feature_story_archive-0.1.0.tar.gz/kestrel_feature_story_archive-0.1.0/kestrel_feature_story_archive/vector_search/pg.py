"""
PgVectorBackend — Fast vector search using pgvector's <=> operator.

Uses PostgreSQL's pgvector extension for HNSW index-accelerated similarity search.
Requires pgvector to be installed in the database.
"""

import logging
import struct
from typing import Any, Dict, List, Optional, Tuple

from kestrel_feature_entities import TenantContext
from pgvector.sqlalchemy import Vector
from sqlalchemy import String, and_, bindparam, cast, literal, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..entities import Event
from ..exceptions import VectorSearchError

logger = logging.getLogger(__name__)


class PgVectorBackend:
    """Fast vector search using pgvector's <=> operator."""

    supports_filters = True

    def __init__(self, session_factory):
        """Initialize the backend with a session factory.

        Args:
            session_factory: AsyncSessionFactory for database access
        """
        self._sf = session_factory

    async def knn(
        self,
        query_embedding: bytes,
        k: int,
        filter: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[str, float]]:
        """Find k nearest neighbors using pgvector's <=> operator.

        Args:
            query_embedding: Query vector as packed bytes (little-endian float32)
            k: Number of neighbors to return
            filter: Optional filter dict with keys:
                - timeline_id: UUID (required)
                - tenant_id: UUID (required)
                - event_type: str
                - is_sensitive: bool

        Returns:
            List of (event_id, similarity) tuples sorted by similarity DESC
        """
        if not filter or "timeline_id" not in filter or "tenant_id" not in filter:
            raise VectorSearchError("PgVectorBackend.knn requires filter with timeline_id and tenant_id")

        # Unpack bytes → list[float]
        query_vec = self._deserialize_embedding(query_embedding)

        # Zero-norm queries are undefined for cosine similarity (would yield
        # NaN). PurePythonBackend short-circuits the same way — keeping the
        # two backends in parity.
        if not any(v != 0.0 for v in query_vec):
            logger.warning("Query embedding has zero norm — returning empty results")
            return []

        timeline_id = filter["timeline_id"]
        tenant_id = filter["tenant_id"]

        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                # Build WHERE clause conditions
                conditions = [
                    Event.timeline_id == timeline_id,
                    Event.embedding.isnot(None),
                ]

                # Apply optional filters
                if "event_type" in filter:
                    conditions.append(Event.event_type == filter["event_type"])
                if "is_sensitive" in filter:
                    conditions.append(Event.is_sensitive == filter["is_sensitive"])

                # Build the cosine-distance expression with native SQLAlchemy
                # column elements so the result supports .label() and Python
                # arithmetic (we need `1 - distance` for similarity).
                #
                # Why not Event.embedding.cosine_distance(...)? The column's
                # type is PortableVector (a TypeDecorator). pgvector's
                # comparator methods (cosine_distance, l2_distance, etc.) live
                # on Vector's comparator_factory and are not proxied by the
                # TypeDecorator.
                #
                # Why not type_coerce(list, Vector(1536))? Round-trips the
                # value through Vector's bind processor twice (once via
                # TypeDecorator, once via Vector itself), wrapping the list
                # into a 0-D numpy array and triggering 'expected ndim to be
                # 1' from pgvector.
                #
                # Why not text(...) or literal_column(...)? TextClause doesn't
                # implement .label() and doesn't support Python arithmetic.
                # literal_column() supports .label() but is opaque — `:qvec`
                # inside its text is not recognized as a bindparam.
                #
                # Solution: cast a string bindparam (pgvector's `[v1,v2,...]`
                # text format) to Vector(dim) — a real SQLAlchemy expression
                # node — then use `.op('<=>')` (which is generic and lives on
                # ColumnOperators) for the cosine-distance operator.
                qvec_literal = "[" + ",".join(repr(float(v)) for v in query_vec) + "]"
                qvec_expr = cast(
                    bindparam("qvec", value=qvec_literal, type_=String),
                    Vector(1536),
                )
                distance = Event.embedding.op("<=>")(qvec_expr)
                similarity = (literal(1) - distance).label("similarity")

                stmt = (
                    select(Event.id, similarity)
                    .where(and_(*conditions))
                    .order_by(distance)
                    .limit(k)
                )

                result = await session.execute(stmt)
                rows = result.all()

                # Return as list of (event_id, similarity) tuples
                return [(str(row[0]), float(row[1])) for row in rows]

    def _deserialize_embedding(self, data: bytes) -> List[float]:
        """Deserialize embedding from bytes (little-endian float32).

        Args:
            data: Packed embedding bytes

        Returns:
            List of floats
        """
        count = len(data) // 4  # 4 bytes per float32
        return list(struct.unpack(f"<{count}f", data))
