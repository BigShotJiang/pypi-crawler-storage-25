"""
Kestrel Feature: Story Archive — schema-rich agent life-story archive.

A reusable feature package for Kestrel Sovereign. An agent maintains a
schema-rich, queryable archive of its life-story: interactions,
observations, and reflections, organized as a timeline with semantic
search and contradiction detection.

Registers ``StoryFeature`` via the ``kestrel_sovereign.features``
entry-point group; auto-discovered when installed alongside
kestrel-sovereign.

Records are scoped to ``agent_did`` (the canonical owner identity per
the Agent Identity Contract). No product-specific terminology — this is
a framework capability for any Kestrel host.
"""

from importlib.metadata import PackageNotFoundError, version as _version

from .feature import StoryFeature

try:
    __version__ = _version("kestrel-feature-story-archive")
except PackageNotFoundError:
    __version__ = "0.0.0+local"

__all__ = [
    "StoryFeature",
    "__version__",
]
