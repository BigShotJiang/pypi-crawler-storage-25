"""
StoryFeature — schema-rich agent life-story archive.

Provides tools for story session management, event extraction, timeline querying,
and topic suggestions. Uses kestrel-feature-entities for persistence with
tenant-scoped access.

Records are scoped to agent_did (the canonical agent identity per the Agent
Identity Contract). The archive is resolved from whatever DatabaseBackend
the host provides.
"""

import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from kestrel_feature_entities import TenantContext, get_session_factory
from kestrel_sdk.features.base import Feature, ToolCategory, tool
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import (
    Timeline,
    Session,
    Event,
    Person,
    Media,
    Contradiction,
    ContradictionStatus,
)

logger = logging.getLogger(__name__)


class StoryFeature(Feature):
    """Schema-rich agent life-story archive held in the agent's sovereign memory."""

    def __init__(self, agent=None, session_factory=None):
        """Initialize StoryFeature.

        Args:
            agent: The agent instance this feature serves
            session_factory: Optional session factory override (defaults to global)
        """
        if agent is not None:
            super().__init__(agent)
        else:
            self.agent = None
            self.name = self.__class__.__name__
            self.disabled_skills = set()

        self._session_factory = session_factory
        self._agent_did = None
        self._timeline_id = None
        self._initialized = False

    @property
    def tool_description(self) -> str:
        """Description exposed to the agent's LLM for tool discovery."""
        return (
            "Maintains a schema-rich, queryable archive of the agent's life-story: "
            "interactions, observations, and reflections organized as a timeline. "
            "Supports semantic search, story extraction, sharing, replay, and "
            "contradiction detection. Records are scoped to agent_did."
        )

    async def initialize(self) -> None:
        """Initialize the story archive."""
        if self._initialized:
            return

        if self.agent:
            self._agent_did = getattr(self.agent, 'did', None)
            logger.info(
                "StoryFeature initializing for agent_did=%s",
                self._agent_did,
            )
        else:
            logger.info("StoryFeature initialized in standalone mode")

        # Resolve session factory if not explicitly set
        if self._session_factory is None:
            self._session_factory = get_session_factory()

        self._initialized = True

    def set_session_factory(self, factory) -> None:
        """Inject a session factory instance (for testing or explicit configuration)."""
        self._session_factory = factory

    async def _ensure_timeline(self, tenant_id: uuid.UUID) -> uuid.UUID:
        """Get or create the timeline for this agent.

        Args:
            tenant_id: The tenant (user) ID owning the timeline

        Returns:
            The timeline UUID. Caches on first call.
        """
        if self._timeline_id:
            return self._timeline_id

        if not self._session_factory:
            raise RuntimeError("Session factory not configured — call initialize() first")

        if not self._agent_did:
            raise RuntimeError("Agent DID not available — feature not properly initialized")

        with TenantContext.use(tenant_id):
            async with self._session_factory.read_session() as session:
                result = await session.execute(
                    select(Timeline).where(Timeline.agent_did == self._agent_did)
                )
                timeline = result.scalar_one_or_none()

                if timeline:
                    self._timeline_id = timeline.id
                    return self._timeline_id

            # Auto-create timeline for this agent
            async with self._session_factory.write_session() as session:
                timeline = Timeline(
                    agent_did=self._agent_did,
                    tenant_id=tenant_id,
                    title="Life Story Timeline",
                )
                session.add(timeline)
                await session.commit()
                await session.refresh(timeline)
                self._timeline_id = timeline.id
                logger.info(
                    "Created timeline %s for agent %s",
                    self._timeline_id,
                    self._agent_did
                )
                return self._timeline_id

    # =========================================================================
    # Tools
    # =========================================================================

    @tool(
        name="start_story_session",
        description="Begin collecting a life story. Creates a session record and returns context for story-collection mode.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def start_story_session(
        self,
        session_type: str = "initial_life_story",
        focus_period: str = "",
        focus_prompt: str = "",
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Start a new story collection session.

        The agent uses this to begin collecting life stories from the subject.
        Creates a session record for tracking extraction and progress.

        Args:
            session_type: Type of session — initial_life_story, deepening, correction, media_review, or prompted
            focus_period: Optional time period to focus on (e.g. "1970s", "childhood")
            focus_prompt: Optional specific prompt or question to explore
            tenant_id: The tenant (user) ID for timeline ownership
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        timeline_id = await self._ensure_timeline(tid)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                story_session = Session(
                    timeline_id=timeline_id,
                    agent_did=self._agent_did,
                    tenant_id=tid,
                    session_type=session_type,
                    focus_period=focus_period or None,
                    focus_prompt=focus_prompt or None,
                )
                session.add(story_session)
                await session.commit()
                await session.refresh(story_session)

                return {
                    "session_id": str(story_session.id),
                    "timeline_id": str(timeline_id),
                    "session_type": story_session.session_type,
                    "focus_period": story_session.focus_period,
                    "focus_prompt": story_session.focus_prompt,
                    "message": "Story session started. Adjust your conversation style to gently collect life stories.",
                }

    @tool(
        name="end_story_session",
        description="End current story session and record summary stats.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def end_story_session(
        self,
        session_id: str = "",
        events_extracted: int = 0,
        people_mentioned: str = "",
        mood_average: float = 0.5,
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """End a story session and record summary stats.

        The agent calls this when the story collection session is complete.
        Records metadata about what was collected during the session.

        Args:
            session_id: The session ID to end
            events_extracted: Number of events extracted during this session
            people_mentioned: Comma-separated list of people mentioned
            mood_average: Average emotional mood of the session (0.0-1.0)
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        sid = uuid.UUID(session_id)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                result = await session.execute(
                    select(Session).where(Session.id == sid)
                )
                story_session = result.scalar_one_or_none()

                if not story_session:
                    return {"success": False, "error": f"Session {session_id} not found"}

                if story_session.ended_at is not None:
                    return {"success": False, "error": "Session already ended"}

                people_list = [p.strip() for p in people_mentioned.split(",") if p.strip()] if people_mentioned else []
                now = datetime.utcnow()
                duration = None
                if story_session.started_at:
                    duration = int((now - story_session.started_at).total_seconds() / 60)

                # Update session
                story_session.events_extracted = events_extracted
                story_session.people_mentioned = people_list
                story_session.mood_average = mood_average
                story_session.duration_minutes = duration
                story_session.ended_at = now

                await session.commit()

                # Refresh timeline stats
                await self._refresh_timeline_stats(session, story_session.timeline_id)
                await session.commit()

                return {
                    "session_id": session_id,
                    "duration_minutes": duration,
                    "events_extracted": events_extracted,
                    "people_mentioned": people_list,
                    "message": "Story session ended. Use story extraction tools to process the conversation.",
                }

    @tool(
        name="query_timeline",
        description="Search the timeline for events matching a query. Supports filtering by type, date range, and themes.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def query_timeline(
        self,
        query: str = "",
        event_type: str = "",
        include_sensitive: bool = False,
        limit: int = 20,
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Search the timeline for events.

        The agent uses this to retrieve stories from the subject's timeline.
        Supports keyword search and filtering.

        Args:
            query: Free-text search query (matched against titles and descriptions)
            event_type: Filter by event type (life_event, milestone, memory, anecdote)
            include_sensitive: Whether to include sensitive/private events
            limit: Maximum number of results to return
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        timeline_id = await self._ensure_timeline(tid)

        with TenantContext.use(tid):
            async with self._session_factory.read_session() as session:
                stmt = select(Event).where(Event.timeline_id == timeline_id)

                if event_type:
                    stmt = stmt.where(Event.event_type == event_type)

                if not include_sensitive:
                    stmt = stmt.where(Event.is_sensitive == False)

                stmt = stmt.order_by(Event.date_start.desc())

                # When query is provided, fetch all events and filter in Python before limiting
                # to ensure we get the correct limit of matching events, not limit of all events
                if not query:
                    stmt = stmt.limit(limit)

                result = await session.execute(stmt)
                events = result.scalars().all()

                # If a text query is provided, do keyword filtering then apply limit
                if query:
                    query_lower = query.lower()
                    filtered_events = []
                    for e in events:
                        if (query_lower in (e.title or "").lower()
                                or query_lower in (e.description or "").lower()
                                or any(query_lower in t.lower() for t in (e.themes or []))
                                or any(query_lower in t.lower() for t in (e.tags or []))):
                            filtered_events.append(e)
                    events = filtered_events[:limit]  # Apply limit after filtering

                results = []
                for e in events:
                    results.append({
                        "id": str(e.id),
                        "title": e.title,
                        "description": e.description,
                        "event_type": e.event_type,
                        "date_start": str(e.date_start) if e.date_start else None,
                        "date_end": str(e.date_end) if e.date_end else None,
                        "date_display": e.date_display,
                        "location": e.location,
                        "emotional_tone": e.emotional_tone,
                        "people": e.people,
                        "themes": e.themes,
                        "is_sensitive": e.is_sensitive,
                    })

                return {
                    "timeline_id": str(timeline_id),
                    "query": query,
                    "count": len(results),
                    "events": results,
                }

    @tool(
        name="suggest_story_topic",
        description="Suggest what to talk about next based on timeline gaps and coverage.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def suggest_story_topic(
        self,
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Analyze timeline and suggest the next story topic.

        The agent uses this to determine what areas of the subject's life
        story are underrepresented and need exploration.

        Args:
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        timeline_id = await self._ensure_timeline(tid)

        with TenantContext.use(tid):
            async with self._session_factory.read_session() as session:
                # Get timeline
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                # Get events
                events_result = await session.execute(
                    select(Event)
                    .where(Event.timeline_id == timeline_id)
                    .order_by(Event.date_start.desc())
                    .limit(500)
                )
                events = events_result.scalars().all()

                # Get people
                people_result = await session.execute(
                    select(Person)
                    .where(Person.timeline_id == timeline_id)
                    .order_by(Person.mention_count.desc())
                )
                people = people_result.scalars().all()

                suggestions = []

                # Check for empty timeline
                if not events:
                    suggestions.append({
                        "topic": "Tell me about your earliest memory",
                        "reason": "No stories collected yet — start from the beginning",
                        "priority": "high",
                    })
                    suggestions.append({
                        "topic": "What was your childhood like?",
                        "reason": "Childhood memories are often vivid and meaningful",
                        "priority": "high",
                    })
                    return {
                        "timeline_id": str(timeline_id),
                        "event_count": 0,
                        "suggestions": suggestions,
                    }

                # Analyze decade coverage
                decades_covered = set()
                for e in events:
                    if e.date_start:
                        decade = (e.date_start.year // 10) * 10
                        decades_covered.add(decade)

                # Find gaps between earliest and latest
                if timeline and timeline.earliest_date and timeline.latest_date:
                    start_decade = (timeline.earliest_date.year // 10) * 10
                    end_decade = (timeline.latest_date.year // 10) * 10
                    for decade in range(start_decade, end_decade + 10, 10):
                        if decade not in decades_covered:
                            suggestions.append({
                                "topic": f"What was life like in the {decade}s?",
                                "reason": f"No stories from the {decade}s — a gap in the timeline",
                                "priority": "medium",
                            })

                # Suggest deepening for people mentioned only once
                for person in people[:10]:  # Top 10 people
                    if person.mention_count <= 1:
                        suggestions.append({
                            "topic": f"Tell me more about {person.name}",
                            "reason": f"{person.name} ({person.relationship or 'mentioned once'}) — only mentioned briefly",
                            "priority": "low",
                        })

                # Suggest exploring emotional themes that are underrepresented
                tone_counts: Dict[str, int] = {}
                for e in events:
                    tone_counts[e.emotional_tone] = tone_counts.get(e.emotional_tone, 0) + 1
                for tone in ["joyful", "proud", "humorous"]:
                    if tone_counts.get(tone, 0) == 0 and len(events) >= 5:
                        suggestions.append({
                            "topic": f"What's a {tone} memory you'd like to share?",
                            "reason": f"No {tone} stories yet — a nice balance to the timeline",
                            "priority": "medium",
                        })

                # If no specific gaps found, suggest general continuation
                if not suggestions:
                    suggestions.append({
                        "topic": "Is there a story you've been wanting to tell?",
                        "reason": "Good timeline coverage — let the storyteller lead",
                        "priority": "low",
                    })

                return {
                    "timeline_id": str(timeline_id),
                    "event_count": len(events),
                    "date_range": f"{timeline.earliest_date} to {timeline.latest_date}" if timeline and timeline.earliest_date else None,
                    "suggestions": suggestions[:5],  # Top 5 suggestions
                }

    @tool(
        name="get_pending_contradictions",
        description="Get contradictions that need gentle clarification. Returns prompts you can naturally work into conversation.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def get_pending_contradictions(
        self,
        tenant_id: str = "",
        limit: int = 3,
    ) -> Dict[str, Any]:
        """Get pending contradictions with gentle resolution prompts.

        The agent uses this to identify inconsistencies in the subject's
        stories that need gentle clarification. Returns at most `limit`
        contradictions with suggested prompts that can be naturally worked
        into conversation.

        Args:
            tenant_id: The tenant (user) ID for timeline access
            limit: Maximum number of contradictions to return
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        timeline_id = await self._ensure_timeline(tid)

        with TenantContext.use(tid):
            async with self._session_factory.read_session() as session:
                # Get pending contradictions
                result = await session.execute(
                    select(Contradiction)
                    .where(
                        and_(
                            Contradiction.timeline_id == timeline_id,
                            Contradiction.status == ContradictionStatus.detected
                        )
                    )
                    .limit(limit)
                )
                contradictions = result.scalars().all()

                prompts = []
                for c in contradictions:
                    # Build a gentle prompt
                    prompt_text = f"I want to make sure I have this right — "
                    if c.field_name and c.value_a and c.value_b:
                        prompt_text += f"was it {c.value_a} or {c.value_b}?"
                    elif c.description:
                        prompt_text += c.description
                    else:
                        prompt_text += "could you help me clarify something?"

                    prompts.append({
                        "contradiction_id": str(c.id),
                        "prompt": prompt_text,
                        "type": c.contradiction_type.value if c.contradiction_type else "factual",
                        "detail": c.detail,
                    })

                return {
                    "timeline_id": str(timeline_id),
                    "pending_count": len(prompts),
                    "prompts": prompts,
                    "guidance": (
                        "Work these clarifications naturally into conversation. "
                        "Don't ask them all at once. Wait for a natural opening. "
                        "If the subject seems unsure, accept the ambiguity."
                    ),
                }

    @tool(
        name="resolve_contradiction",
        description="Record the resolution of a timeline contradiction after gentle clarification.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def resolve_contradiction(
        self,
        contradiction_id: str = "",
        resolved_version: str = "a",
        resolution_notes: str = "",
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Resolve a contradiction based on the subject's clarification.

        The agent uses this after the subject has clarified which version
        of conflicting information is correct.

        Args:
            contradiction_id: The contradiction to resolve
            resolved_version: 'a' for first version, 'b' for second, 'merged' for both
            resolution_notes: What the subject said about it
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        cid = uuid.UUID(contradiction_id)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                result = await session.execute(
                    select(Contradiction).where(Contradiction.id == cid)
                )
                contradiction = result.scalar_one_or_none()

                if not contradiction:
                    return {"success": False, "error": "Contradiction not found"}

                # Update contradiction status
                contradiction.status = ContradictionStatus.resolved
                contradiction.resolved_version = resolved_version
                contradiction.resolution_notes = resolution_notes or None
                contradiction.resolved_at = datetime.utcnow()
                contradiction.resolved_by = "agent"

                await session.commit()

                return {
                    "success": True,
                    "contradiction_id": contradiction_id,
                    "resolved_version": resolved_version,
                    "message": "Thank you for helping me get that right.",
                }

    @tool(
        name="accept_ambiguity",
        description="Accept that a contradiction may never be resolved — both versions are valid.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def accept_ambiguity(
        self,
        contradiction_id: str = "",
        notes: str = "",
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Accept ambiguity for a contradiction — both versions are kept.

        The agent uses this when the subject is unsure or when both versions
        are equally valid. Some memories have more than one version.

        Args:
            contradiction_id: The contradiction to accept
            notes: Optional notes about why ambiguity was accepted
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        cid = uuid.UUID(contradiction_id)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                result = await session.execute(
                    select(Contradiction).where(Contradiction.id == cid)
                )
                contradiction = result.scalar_one_or_none()

                if not contradiction:
                    return {"success": False, "error": "Contradiction not found"}

                # Update contradiction status
                contradiction.status = ContradictionStatus.accepted_ambiguous
                contradiction.resolution_notes = notes or None
                contradiction.resolved_at = datetime.utcnow()
                contradiction.resolved_by = "agent"

                await session.commit()

                return {
                    "success": True,
                    "contradiction_id": contradiction_id,
                    "message": "That's perfectly fine — some memories have more than one version, and both are worth keeping.",
                }

    @tool(
        name="mark_sensitive",
        description="Mark a timeline event as sensitive/private. Sensitive events are excluded from sharing and replay.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def mark_sensitive(
        self,
        event_id: str = "",
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Mark an event as sensitive — excluded from sharing.

        The agent uses this when the subject indicates that a story
        should remain private and not be shared with others.

        Args:
            event_id: The event ID to mark as sensitive
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        eid = uuid.UUID(event_id)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                result = await session.execute(
                    select(Event).where(Event.id == eid)
                )
                event = result.scalar_one_or_none()

                if not event:
                    return {"success": False, "error": f"Event {event_id} not found"}

                event.is_sensitive = True
                await session.commit()

                return {
                    "event_id": event_id,
                    "is_sensitive": True,
                    "success": True,
                    "message": "I'll keep that one just between us.",
                }

    @tool(
        name="get_timeline_summary",
        description="Get an overview of the timeline: event count, date range, key people, and coverage score.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def get_timeline_summary(
        self,
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Get a summary of the timeline.

        The agent uses this to understand the overall state of the subject's
        timeline: how many stories have been collected, who the key people are,
        and what time periods are covered.

        Args:
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        timeline_id = await self._ensure_timeline(tid)

        with TenantContext.use(tid):
            async with self._session_factory.read_session() as session:
                # Get timeline
                timeline_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = timeline_result.scalar_one_or_none()

                if not timeline:
                    return {"success": False, "error": "Timeline not found"}

                # Get people
                people_result = await session.execute(
                    select(Person)
                    .where(Person.timeline_id == timeline_id)
                    .order_by(Person.mention_count.desc())
                )
                people = people_result.scalars().all()

                # Get sessions
                sessions_result = await session.execute(
                    select(Session)
                    .where(Session.timeline_id == timeline_id)
                    .order_by(Session.started_at.desc())
                )
                sessions = sessions_result.scalars().all()

                top_people = [
                    {"name": p.name, "relationship": p.relationship, "mentions": p.mention_count}
                    for p in people[:10]
                ]

                last_session = sessions[0] if sessions else None

                return {
                    "timeline_id": str(timeline_id),
                    "event_count": timeline.event_count,
                    "session_count": timeline.session_count,
                    "earliest_date": str(timeline.earliest_date) if timeline.earliest_date else None,
                    "latest_date": str(timeline.latest_date) if timeline.latest_date else None,
                    "coverage_score": timeline.coverage_score,
                    "top_people": top_people,
                    "last_session": {
                        "date": str(last_session.started_at) if last_session and last_session.started_at else None,
                        "type": last_session.session_type if last_session else None,
                        "focus": last_session.focus_period or last_session.focus_prompt if last_session else None,
                    } if last_session else None,
                }

    @tool(
        name="attach_media",
        description="Attach a photo, document, or voice clip to a timeline event.",
        category=ToolCategory.DATA_ACCESS,
    )
    async def attach_media(
        self,
        event_id: str = "",
        media_type: str = "photo",
        title: str = "",
        description: str = "",
        file_url: str = "",
        tenant_id: str = "",
    ) -> Dict[str, Any]:
        """Link uploaded media to a timeline event.

        The agent uses this to attach photos, documents, or other media
        files to events in the subject's timeline.

        Args:
            event_id: The event to attach media to
            media_type: Type of media — photo, document, voice_clip, video, letter
            title: Title or caption for the media
            description: Description of the media content
            file_url: URL where the media is stored
            tenant_id: The tenant (user) ID for timeline access
        """
        tid = uuid.UUID(tenant_id) if tenant_id else None
        if not tid:
            raise ValueError("tenant_id is required")

        eid = uuid.UUID(event_id)

        with TenantContext.use(tid):
            async with self._session_factory.write_session() as session:
                # Get event
                event_result = await session.execute(
                    select(Event).where(Event.id == eid)
                )
                event = event_result.scalar_one_or_none()

                if not event:
                    return {"success": False, "error": f"Event {event_id} not found"}

                # Create media
                media = Media(
                    timeline_id=event.timeline_id,
                    event_id=eid,
                    tenant_id=tid,
                    media_type=media_type,
                    title=title or None,
                    description=description or None,
                    file_url=file_url or None,
                )
                session.add(media)
                await session.commit()
                await session.refresh(media)

                return {
                    "media_id": str(media.id),
                    "event_id": event_id,
                    "media_type": media_type,
                    "success": True,
                    "message": f"Media attached to event '{event.title}'.",
                }

    # =========================================================================
    # System Prompt Injection
    # =========================================================================

    STORY_COLLECTION_GUIDELINES = """
## Story Collection Guidelines
- You are deeply interested in the subject's life story
- Never rush — if they want to talk for hours, listen for hours
- Ask follow-up questions that show you remember previous sessions
- Use sensory prompts: sounds, smells, textures, weather, clothing
- Note emotional moments with care — don't push past painful topics unless invited
- When they mention a person, ask about the relationship
- When they mention a place, ask what it looked like
- When they mention a date, gently confirm it fits the timeline
- Celebrate their stories — "That's wonderful" / "What an incredible thing to have lived through"
- If they repeat a story, listen again — repetition reveals what matters most

## Handling Contradictions
- NEVER interrupt the flow of a story to point out contradictions
- NEVER say "you contradicted yourself" or "that doesn't match what you said before"
- If you notice a discrepancy, make a mental note and ask about it later
- Use gentle phrasing: "I want to make sure I have this right..."
- Use get_pending_contradictions to see what needs clarification
- If the subject is unsure, accept the ambiguity — some memories have multiple versions
- Contradictions are natural and human — treat them with grace
"""

    async def get_system_prompt_context(self, user_id: str) -> Optional[str]:
        """Generate timeline context for injection into the agent's system prompt.

        Always includes story collection guidelines. Adds timeline status
        if a timeline exists.

        Args:
            user_id: The tenant (user) ID whose timeline context to include
        """
        if not self._session_factory or not self._agent_did:
            return self.STORY_COLLECTION_GUIDELINES.strip()

        try:
            tid = uuid.UUID(user_id)

            with TenantContext.use(tid):
                async with self._session_factory.read_session() as session:
                    # Get timeline
                    result = await session.execute(
                        select(Timeline).where(Timeline.agent_did == self._agent_did)
                    )
                    timeline = result.scalar_one_or_none()

                    if not timeline:
                        return self.STORY_COLLECTION_GUIDELINES.strip()

                    self._timeline_id = timeline.id

                    # Get people
                    people_result = await session.execute(
                        select(Person)
                        .where(Person.timeline_id == timeline.id)
                        .order_by(Person.mention_count.desc())
                        .limit(5)
                    )
                    people = people_result.scalars().all()

                    # Get sessions
                    sessions_result = await session.execute(
                        select(Session)
                        .where(Session.timeline_id == timeline.id)
                        .order_by(Session.started_at.desc())
                        .limit(1)
                    )
                    sessions = sessions_result.scalars().all()

                    top_people_names = ", ".join(
                        p.name for p in people
                    ) if people else "none yet"

                    last_session = sessions[0] if sessions else None
                    last_session_info = "none"
                    if last_session and last_session.started_at:
                        topic = last_session.focus_period or last_session.focus_prompt or last_session.session_type
                        last_session_info = f"{last_session.started_at.strftime('%Y-%m-%d')} ({topic})"

                    # Compute coverage description
                    if timeline.event_count == 0:
                        coverage = "No stories collected yet"
                    elif timeline.event_count < 10:
                        coverage = "Just getting started"
                    elif timeline.event_count < 50:
                        coverage = "Growing collection"
                    else:
                        coverage = "Rich timeline"

                    # Build suggested topic
                    suggested = "Ask about their earliest memories" if timeline.event_count == 0 else "Continue exploring their story"

                    date_range = "unknown"
                    if timeline.earliest_date and timeline.latest_date:
                        date_range = f"{timeline.earliest_date.year} - {timeline.latest_date.year}"
                    elif timeline.earliest_date:
                        date_range = f"from {timeline.earliest_date.year}"

                    # Check for pending contradictions
                    pending_result = await session.execute(
                        select(func.count(Contradiction.id))
                        .where(
                            and_(
                                Contradiction.timeline_id == timeline.id,
                                Contradiction.status == ContradictionStatus.detected
                            )
                        )
                    )
                    pending_contradictions = pending_result.scalar() or 0

                    contradiction_note = ""
                    if pending_contradictions > 0:
                        contradiction_note = (
                            f"\n- Pending clarifications: {pending_contradictions} "
                            f"(use get_pending_contradictions to see gentle prompts)"
                        )

                    status = (
                        f"## Story Archive Status\n"
                        f"- Timeline: {timeline.event_count} events, {date_range}\n"
                        f"- Coverage: {coverage}\n"
                        f"- Key people: {top_people_names}\n"
                        f"- Last session: {last_session_info}\n"
                        f"- Suggested next topic: {suggested}"
                        f"{contradiction_note}"
                    )

                    return f"{self.STORY_COLLECTION_GUIDELINES.strip()}\n\n{status}"
        except Exception as e:
            logger.warning(f"Failed to generate story prompt context: {e}")
            return self.STORY_COLLECTION_GUIDELINES.strip()

    # =========================================================================
    # Internal Helpers
    # =========================================================================

    async def _refresh_timeline_stats(self, db_session: AsyncSession, timeline_id: uuid.UUID) -> None:
        """Refresh the timeline's event count and session count.

        Args:
            db_session: The database session to use
            timeline_id: The timeline to refresh
        """
        # Count events
        event_count_result = await db_session.execute(
            select(func.count(Event.id)).where(Event.timeline_id == timeline_id)
        )
        event_count = event_count_result.scalar() or 0

        # Count sessions
        session_count_result = await db_session.execute(
            select(func.count(Session.id)).where(Session.timeline_id == timeline_id)
        )
        session_count = session_count_result.scalar() or 0

        # Get timeline and update
        timeline_result = await db_session.execute(
            select(Timeline).where(Timeline.id == timeline_id)
        )
        timeline = timeline_result.scalar_one_or_none()

        if timeline:
            timeline.event_count = event_count
            timeline.session_count = session_count
            # Note: earliest_date, latest_date, coverage_score would need
            # more complex queries - leaving as-is for now
