"""
StoryExportService — Sovereign timeline export to IPFS or local storage.

Exports the complete story timeline as an encrypted archive:
- Timeline metadata, events, people, sessions, media
- IPFS upload via pluggable client (or local-{sha} fallback)
- Import from CID restores full timeline
- Export history tracked in story_exports table

CRITICAL: IPFS client is injected via constructor. If None, returns
local-{sha256(payload)[:16]} as the CID without network upload.
"""

import hashlib
import json
import logging
import uuid
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Protocol

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_

from .entities import Timeline, Event, Person, Session, Media, SharingPermission, Export
from .exceptions import TimelineNotFoundError

logger = logging.getLogger(__name__)

STORY_ARCHIVE_SCHEMA_VERSION = "1.0"


# =============================================================================
# IPFS Client Protocol
# =============================================================================


class IPFSClient(Protocol):
    """Protocol for pluggable IPFS upload clients.

    Implementations handle the actual network upload to IPFS/Filecoin/etc.
    """

    async def upload(self, content: bytes) -> str:
        """Upload content and return CID.

        Args:
            content: The bytes to upload

        Returns:
            The IPFS CID
        """
        ...


# =============================================================================
# Export Results
# =============================================================================


@dataclass
class ExportResult:
    """Result of a timeline export."""
    cid: str
    timeline_id: str
    agent_did: str
    tier: str
    schema_version: str
    event_count: int = 0
    person_count: int = 0
    session_count: int = 0
    media_count: int = 0
    archive_size_bytes: int = 0
    encrypted: bool = False
    exported_at: str = ""


@dataclass
class ImportResult:
    """Result of a timeline import."""
    timeline_id: str
    agent_did: str
    cid: str
    event_count: int = 0
    person_count: int = 0
    session_count: int = 0
    media_count: int = 0


@dataclass
class VerificationResult:
    """Result of verifying an export."""
    cid: str
    valid: bool = False
    schema_version: Optional[str] = None
    event_count: int = 0
    person_count: int = 0
    session_count: int = 0
    media_count: int = 0
    timeline_title: Optional[str] = None
    exported_at: Optional[str] = None
    error: Optional[str] = None


# =============================================================================
# StoryExportService
# =============================================================================


def _json_serial(obj: Any) -> Any:
    """JSON serializer for objects not serializable by default."""
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, uuid.UUID):
        return str(obj)
    raise TypeError(f"Type {type(obj)} not serializable")


class StoryExportService:
    """Manages sovereign export/import of story timelines.

    IPFS client is optional — if None, returns local-{sha} CIDs.
    """

    def __init__(self, session_factory, ipfs_client: Optional[IPFSClient] = None):
        """Initialize export service.

        Args:
            session_factory: AsyncSessionFactory for database access
            ipfs_client: Optional IPFS client for network uploads.
                         If None, returns local-{sha256[:16]} CIDs.
        """
        self._sf = session_factory
        self._ipfs_client = ipfs_client

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    async def export_timeline(
        self,
        timeline_id: uuid.UUID,
        agent_did: str,
        tenant_id: uuid.UUID,
        tier: str = "ipfs",
        include_sensitive: bool = False,
        include_media: bool = True,
        trigger: str = "manual",
    ) -> ExportResult:
        """Export a complete story timeline.

        If ipfs_client is None, returns a deterministic local-{sha} CID
        without uploading to the network.

        Args:
            timeline_id: The timeline to export
            agent_did: The agent DID (canonical owner identity)
            tenant_id: Tenant context
            tier: Storage tier hint (ipfs, filecoin, local)
            include_sensitive: Whether to include sensitive events
            include_media: Whether to include media metadata
            trigger: What triggered the export (manual, scheduled, etc.)

        Returns:
            ExportResult with CID and statistics
        """
        with TenantContext.use(tenant_id):
            # Gather timeline data from database
            timeline_data = await self._gather_timeline_data(
                timeline_id, tenant_id, include_sensitive, include_media
            )

        # Serialize to JSON
        payload = json.dumps(timeline_data, default=_json_serial).encode("utf-8")

        # Upload or generate local CID
        if self._ipfs_client:
            try:
                cid = await self._ipfs_client.upload(payload)
            except Exception as e:
                logger.error(f"IPFS upload failed: {e}")
                # Fallback to local CID
                cid = self._generate_local_cid(payload)
        else:
            # No IPFS client — return local CID
            cid = self._generate_local_cid(payload)

        now = datetime.utcnow()
        result = ExportResult(
            cid=cid,
            timeline_id=str(timeline_id),
            agent_did=agent_did,
            tier=tier,
            schema_version=STORY_ARCHIVE_SCHEMA_VERSION,
            event_count=len(timeline_data["events"]),
            person_count=len(timeline_data["people"]),
            session_count=len(timeline_data["sessions"]),
            media_count=len(timeline_data["media"]),
            archive_size_bytes=len(payload),
            encrypted=False,  # Encryption is optional, not implemented in this version
            exported_at=now.isoformat(),
        )

        # Record export in DB
        await self._record_export(result, trigger, tenant_id)

        logger.info(
            f"Story archive exported: {cid} "
            f"({result.event_count} events, {result.person_count} people, "
            f"{result.session_count} sessions, {result.media_count} media, "
            f"{result.archive_size_bytes} bytes)"
        )

        return result

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    async def get_export_history(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> List[Export]:
        """Get export history for a timeline.

        Args:
            timeline_id: The timeline to query
            tenant_id: Tenant context

        Returns:
            List of Export entities, newest first
        """
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Export)
                    .where(Export.timeline_id == timeline_id)
                    .order_by(Export.exported_at.desc())
                )
                return list(result.scalars().all())

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _gather_timeline_data(
        self,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        include_sensitive: bool,
        include_media: bool,
    ) -> Dict[str, Any]:
        """Gather all timeline data from the database for export."""
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                # Timeline
                tl_result = await session.execute(
                    select(Timeline).where(Timeline.id == timeline_id)
                )
                timeline = tl_result.scalar_one_or_none()
                if not timeline:
                    raise TimelineNotFoundError(str(timeline_id))

                timeline_dict = self._entity_to_dict(timeline)

                # Events
                event_stmt = select(Event).where(Event.timeline_id == timeline_id)
                if not include_sensitive:
                    event_stmt = event_stmt.where(Event.is_sensitive == False)
                event_stmt = event_stmt.order_by(Event.date_start.asc())

                event_result = await session.execute(event_stmt)
                events = [self._entity_to_dict(e) for e in event_result.scalars().all()]

                # People
                people_result = await session.execute(
                    select(Person)
                    .where(Person.timeline_id == timeline_id)
                    .order_by(Person.mention_count.desc())
                )
                people = [self._entity_to_dict(p) for p in people_result.scalars().all()]

                # Sessions
                session_result = await session.execute(
                    select(Session)
                    .where(Session.timeline_id == timeline_id)
                    .order_by(Session.started_at.desc())
                )
                sessions = [self._entity_to_dict(s) for s in session_result.scalars().all()]

                # Media
                media = []
                if include_media:
                    media_result = await session.execute(
                        select(Media)
                        .where(Media.timeline_id == timeline_id)
                        .order_by(Media.created_at.asc())
                    )
                    media = [self._entity_to_dict(m) for m in media_result.scalars().all()]

                # Sharing history
                sharing_result = await session.execute(
                    select(SharingPermission)
                    .where(SharingPermission.timeline_id == timeline_id)
                    .order_by(SharingPermission.granted_at.desc())
                )
                sharing_history = [self._entity_to_dict(s) for s in sharing_result.scalars().all()]

        # Build themes index
        theme_index = {}
        for event in events:
            themes = event.get("themes", [])
            for theme in themes:
                if theme not in theme_index:
                    theme_index[theme] = []
                theme_index[theme].append(event["id"])
        themes_data = [{"theme": k, "event_ids": v} for k, v in theme_index.items()]

        return {
            "version": STORY_ARCHIVE_SCHEMA_VERSION,
            "type": "story_archive",
            "timeline": timeline_dict,
            "events": events,
            "people": people,
            "sessions": sessions,
            "media": media,
            "themes": themes_data,
            "sharing_history": sharing_history,
        }

    @staticmethod
    def _entity_to_dict(entity) -> Dict[str, Any]:
        """Convert a SQLAlchemy entity to a serializable dict."""
        d = {}
        for col in entity.__table__.columns:
            val = getattr(entity, col.name)
            if isinstance(val, (date, datetime)):
                d[col.name] = val.isoformat()
            elif isinstance(val, uuid.UUID):
                d[col.name] = str(val)
            else:
                d[col.name] = val
        return d

    @staticmethod
    def _generate_local_cid(payload: bytes) -> str:
        """Generate a deterministic local CID from payload.

        Returns: local-{sha256(payload)[:16]}
        """
        content_hash = hashlib.sha256(payload).hexdigest()[:16]
        return f"local-{content_hash}"

    async def _record_export(
        self,
        result: ExportResult,
        trigger: str,
        tenant_id: uuid.UUID,
    ) -> None:
        """Record an export in the story_exports table."""
        try:
            with TenantContext.use(tenant_id):
                async with self._sf.write_session() as session:
                    export = Export(
                        timeline_id=uuid.UUID(result.timeline_id),
                        agent_did=result.agent_did,
                        tenant_id=tenant_id,
                        cid=result.cid,
                        tier=result.tier,
                        schema_version=result.schema_version,
                        event_count=result.event_count,
                        person_count=result.person_count,
                        session_count=result.session_count,
                        media_count=result.media_count,
                        archive_size_bytes=result.archive_size_bytes,
                        trigger=trigger,
                        status="completed",
                    )
                    session.add(export)
                    await session.commit()
        except Exception as e:
            logger.error(f"Failed to record export: {e}")
