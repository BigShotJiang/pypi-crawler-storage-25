"""Alembic environment for story-archive feature.

This env.py imports kestrel_feature_story_archive.entities and uses
kestrel_feature_entities' registry to discover all entity modules
registered via the `kestrel_entities.models` entry-point.

The merged metadata from EntityBase is used as target_metadata so
Alembic autogen sees both base tables and this feature's entities.
"""

import logging
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from kestrel_feature_entities.registry import all_metadata

# Import our entities module so they register with EntityBase.metadata
import kestrel_feature_story_archive.entities  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

logger = logging.getLogger("alembic.env")

target_metadata = all_metadata()


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        version_table="alembic_version_kestrel",
    )
    with context.begin_transaction():
        context.run_migrations()


def _to_sync_url(url: str) -> str:
    """Alembic uses sync engines. Strip async driver suffixes if present.

    `sqlite+aiosqlite:///x.db` → `sqlite:///x.db`
    `postgresql+asyncpg://...` → `postgresql+psycopg://...` (caller must have psycopg installed)
    """
    if url.startswith("sqlite+aiosqlite"):
        return "sqlite" + url[len("sqlite+aiosqlite") :]
    if url.startswith("postgresql+asyncpg"):
        return "postgresql+psycopg" + url[len("postgresql+asyncpg") :]
    return url


def run_migrations_online() -> None:
    section = config.get_section(config.config_ini_section, {}) or {}
    section["sqlalchemy.url"] = _to_sync_url(section.get("sqlalchemy.url", ""))
    connectable = engine_from_config(
        section,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            version_table="alembic_version_kestrel",
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
