"""
Storage backend protocol for media uploads.

Defines the interface for pluggable storage backends (local filesystem, GCS, S3, IPFS, etc.).
The media service accepts a storage_backend via constructor injection.
"""

from typing import Protocol, Optional, Dict, Any


class StorageBackend(Protocol):
    """Protocol for pluggable storage backends.

    Implementations provide upload/download for media files. The host determines
    where files are stored (local disk, cloud storage, IPFS, etc.).
    """

    async def upload(
        self,
        file_bytes: bytes,
        filename: str,
        content_type: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a file and return storage metadata.

        Args:
            file_bytes: The file content
            filename: Original filename
            content_type: MIME type
            metadata: Optional metadata to store with the file

        Returns:
            Dict with at least:
                - url: str — where the file can be accessed
                - cid: Optional[str] — content identifier (for IPFS/content-addressed storage)
                - storage_path: Optional[str] — backend-specific path/key
        """
        ...

    async def download(self, url: str) -> Optional[bytes]:
        """Download a file from storage.

        Args:
            url: The URL or storage identifier

        Returns:
            File bytes or None if not found
        """
        ...

    async def delete(self, url: str) -> bool:
        """Delete a file from storage.

        Args:
            url: The URL or storage identifier

        Returns:
            True if deleted, False if not found
        """
        ...


class NoOpStorageBackend:
    """No-op storage backend for testing or when storage is disabled.

    Returns local-{hash} URLs but doesn't actually store files.
    """

    async def upload(
        self,
        file_bytes: bytes,
        filename: str,
        content_type: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Return a deterministic local URL without storing."""
        import hashlib

        content_hash = hashlib.sha256(file_bytes).hexdigest()[:16]
        return {
            "url": f"local-{content_hash}/{filename}",
            "cid": None,
            "storage_path": None,
        }

    async def download(self, url: str) -> Optional[bytes]:
        """No-op download."""
        return None

    async def delete(self, url: str) -> bool:
        """No-op delete."""
        return False
