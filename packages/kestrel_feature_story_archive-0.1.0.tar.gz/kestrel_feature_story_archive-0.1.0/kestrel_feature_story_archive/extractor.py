"""
Story Extractor — Extract structured story events from conversation transcripts.

Three-stage LLM pipeline:
1. Rough extraction: Identify candidate events from raw transcript
2. Refinement: Clean up dates, people, locations, themes
3. Entity linking: Resolve people against existing Person records

Plus embedding generation for semantic search.

Ported from frinz/services/story_extractor.py for kestrel-feature-story-archive.
"""

import json
import logging
import uuid
from datetime import date, datetime
from typing import Any, Callable, Dict, List, Optional, Tuple, Awaitable

from kestrel_feature_entities import TenantContext
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from .entities import Timeline, Session, Event, Person
from .exceptions import ExtractionError, SessionNotFoundError
from .vector_search import get_vector_backend

logger = logging.getLogger(__name__)


class StoryExtractor:
    """Extract structured story events from conversation transcripts.

    Uses a 3-call LLM pipeline to transform raw conversation into structured
    Event records with semantic embeddings.
    """

    def __init__(
        self,
        session_factory,
        llm: Callable[[str], Awaitable[str]],
        embedder: Optional[Callable[[str], Awaitable[List[float]]]] = None,
        vector_backend=None,
    ):
        """Initialize the story extractor.

        Args:
            session_factory: AsyncSessionFactory for database access
            llm: Async LLM callable (str -> str) for extraction pipeline
            embedder: Optional async embedding callable (str -> list[float])
            vector_backend: Optional VectorSearchBackend (defaults to auto-detect)
        """
        self._sf = session_factory
        self._llm = llm
        self._embedder = embedder
        self._vector_backend = vector_backend or get_vector_backend(session_factory)

    # -------------------------------------------------------------------------
    # Main Extraction Pipeline
    # -------------------------------------------------------------------------

    async def extract_session(
        self,
        session_id: uuid.UUID,
        transcript: str,
        tenant_id: uuid.UUID,
        agent_did: str,
    ) -> Dict[str, Any]:
        """Extract story events from a session transcript.

        Three-stage pipeline:
        1. Rough extraction: Parse transcript into candidate events
        2. Refinement: Clean dates, people, locations, themes
        3. Entity linking: Resolve people against existing records

        Args:
            session_id: The session ID
            transcript: Raw conversation transcript
            tenant_id: The tenant (user) ID
            agent_did: The agent DID (canonical owner identity)

        Returns:
            Dict with extraction stats

        Raises:
            ExtractionError: If extraction fails at any stage
        """
        try:
            # Load session
            with TenantContext.use(tenant_id):
                async with self._sf.read_session() as session:
                    result = await session.execute(
                        select(Session).where(Session.id == session_id)
                    )
                    story_session = result.scalar_one_or_none()

                    if not story_session:
                        raise SessionNotFoundError(str(session_id))

                    timeline_id = story_session.timeline_id

            # Stage 1: Rough extraction
            logger.info(f"Stage 1: Rough extraction for session {session_id}")
            candidate_events = await self._rough_extraction(transcript)

            # Stage 2: Refinement
            logger.info(f"Stage 2: Refining {len(candidate_events)} candidates")
            refined_events = await self._refinement(candidate_events, transcript)

            # Stage 3: Entity linking
            logger.info(f"Stage 3: Entity linking for {len(refined_events)} events")
            linked_events = await self._entity_linking(
                refined_events, timeline_id, tenant_id
            )

            # Generate embeddings and persist events
            logger.info(f"Generating embeddings and persisting {len(linked_events)} events")
            persisted_count = await self._persist_events(
                linked_events, session_id, timeline_id, tenant_id, agent_did
            )

            # Update session statistics
            with TenantContext.use(tenant_id):
                async with self._sf.write_session() as session:
                    result = await session.execute(
                        select(Session).where(Session.id == session_id)
                    )
                    story_session = result.scalar_one_or_none()
                    if story_session:
                        story_session.events_extracted = persisted_count
                        story_session.ended_at = datetime.utcnow()
                        await session.commit()

            return {
                "session_id": str(session_id),
                "timeline_id": str(timeline_id),
                "events_extracted": persisted_count,
                "candidates_found": len(candidate_events),
                "refined": len(refined_events),
                "linked": len(linked_events),
            }

        except SessionNotFoundError:
            raise
        except Exception as e:
            logger.exception(f"Extraction failed for session {session_id}: {e}")
            raise ExtractionError(
                f"Extraction pipeline failed: {e}",
                session_id=str(session_id),
                step="unknown",
            )

    # -------------------------------------------------------------------------
    # Stage 1: Rough Extraction
    # -------------------------------------------------------------------------

    async def _rough_extraction(self, transcript: str) -> List[Dict[str, Any]]:
        """Stage 1: Extract candidate events from raw transcript.

        Returns a list of rough event dicts with minimal structure.
        """
        prompt = f"""Extract all significant life events from this conversation transcript.

For each event, identify:
- A brief title
- A description (1-3 sentences)
- Approximate date or time period
- Location (if mentioned)
- People involved
- Emotional tone (positive, negative, neutral, mixed)
- Importance (0.0-1.0)

Return ONLY a JSON array of events:
[
  {{
    "title": "...",
    "description": "...",
    "date_info": "...",
    "location": "...",
    "people": ["name1", "name2"],
    "emotional_tone": "...",
    "importance": 0.0-1.0
  }}
]

Transcript:
{transcript[:4000]}"""

        try:
            response = await self._llm(prompt)
            # Parse JSON response
            events = json.loads(response)
            if not isinstance(events, list):
                logger.warning("LLM returned non-list response, wrapping")
                events = [events] if isinstance(events, dict) else []
            return events
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse LLM response as JSON: {e}")
            return []
        except Exception as e:
            logger.error(f"Rough extraction failed: {e}")
            raise ExtractionError("Stage 1 (rough extraction) failed", step="rough_extraction")

    # -------------------------------------------------------------------------
    # Stage 2: Refinement
    # -------------------------------------------------------------------------

    async def _refinement(
        self, candidate_events: List[Dict[str, Any]], transcript: str
    ) -> List[Dict[str, Any]]:
        """Stage 2: Refine dates, people, locations, themes.

        Returns a list of refined event dicts with structured data.
        """
        if not candidate_events:
            return []

        prompt = f"""Given these candidate events extracted from a conversation, refine them:

Candidates:
{json.dumps(candidate_events, indent=2)[:3000]}

For each event:
1. Parse dates into ISO format (YYYY-MM-DD) if possible, or leave as descriptive text
2. Identify date precision (exact, year, month, decade, approximate)
3. Extract themes (e.g., "education", "family", "career", "health", "travel")
4. Normalize people names
5. Add any missing details from the original transcript

Original transcript (for context):
{transcript[:2000]}

Return ONLY a JSON array of refined events:
[
  {{
    "title": "...",
    "description": "...",
    "date_start": "YYYY-MM-DD or null",
    "date_end": "YYYY-MM-DD or null",
    "date_precision": "exact|year|month|decade|approximate",
    "date_display": "Human-readable date string",
    "location": "...",
    "people": [{{"name": "...", "relationship": "..."}}],
    "themes": ["theme1", "theme2"],
    "emotional_tone": "positive|negative|neutral|mixed",
    "importance": 0.0-1.0,
    "confidence": 0.0-1.0
  }}
]"""

        try:
            response = await self._llm(prompt)
            events = json.loads(response)
            if not isinstance(events, list):
                events = [events] if isinstance(events, dict) else []
            return events
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse refinement response: {e}")
            # Return candidates as-is if refinement fails
            return candidate_events
        except Exception as e:
            logger.error(f"Refinement failed: {e}")
            # Don't fail the whole pipeline, just return candidates
            return candidate_events

    # -------------------------------------------------------------------------
    # Stage 3: Entity Linking
    # -------------------------------------------------------------------------

    async def _entity_linking(
        self,
        refined_events: List[Dict[str, Any]],
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
    ) -> List[Dict[str, Any]]:
        """Stage 3: Resolve people against existing Person records.

        Returns events with person_id fields added to people references.
        """
        # Load existing people
        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                result = await session.execute(
                    select(Person).where(Person.timeline_id == timeline_id)
                )
                people = result.scalars().all()

        # Build name → person_id mapping
        name_map: Dict[str, str] = {}
        for person in people:
            name_map[person.name.lower()] = str(person.id)
            for alias in (person.aliases or []):
                name_map[alias.lower()] = str(person.id)

        # Link people in events
        for event in refined_events:
            people_refs = event.get("people", [])
            linked_people = []

            for person_ref in people_refs:
                if isinstance(person_ref, dict):
                    name = person_ref.get("name", "")
                elif isinstance(person_ref, str):
                    name = person_ref
                    person_ref = {"name": name}
                else:
                    continue

                name_lower = name.strip().lower()
                person_id = name_map.get(name_lower)

                linked_people.append({
                    "name": name,
                    "person_id": person_id,
                    "relationship": person_ref.get("relationship"),
                })

            event["people"] = linked_people

        return refined_events

    # -------------------------------------------------------------------------
    # Persistence & Embedding Generation
    # -------------------------------------------------------------------------

    async def _persist_events(
        self,
        events: List[Dict[str, Any]],
        session_id: uuid.UUID,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        agent_did: str,
    ) -> int:
        """Generate embeddings and persist events to database.

        Returns the count of successfully persisted events.
        """
        persisted = 0

        with TenantContext.use(tenant_id):
            async with self._sf.write_session() as session:
                for event_data in events:
                    try:
                        # Parse dates
                        date_start = self._parse_date(event_data.get("date_start"))
                        date_end = self._parse_date(event_data.get("date_end"))

                        # Generate embedding
                        embedding = None
                        if self._embedder:
                            embed_text = f"{event_data.get('title', '')} {event_data.get('description', '')}"
                            try:
                                embedding = await self._embedder(embed_text)
                            except Exception as e:
                                logger.warning(f"Failed to generate embedding: {e}")

                        # Create event record
                        event = Event(
                            timeline_id=timeline_id,
                            tenant_id=tenant_id,
                            source_session_id=session_id,
                            title=event_data.get("title", "Untitled Event"),
                            description=event_data.get("description"),
                            event_type=event_data.get("event_type", "memory"),
                            date_start=date_start,
                            date_end=date_end,
                            date_precision=event_data.get("date_precision", "approximate"),
                            date_display=event_data.get("date_display"),
                            location=event_data.get("location"),
                            emotional_tone=event_data.get("emotional_tone", "neutral"),
                            importance=float(event_data.get("importance", 0.5)),
                            confidence=float(event_data.get("confidence", 0.5)),
                            people=event_data.get("people", []),
                            themes=event_data.get("themes", []),
                            tags=event_data.get("tags", []),
                            is_sensitive=event_data.get("is_sensitive", False),
                            embedding=embedding,
                        )

                        session.add(event)
                        persisted += 1

                    except Exception as e:
                        logger.warning(f"Failed to persist event: {e}")
                        continue

                await session.commit()

        return persisted

    # -------------------------------------------------------------------------
    # Semantic Search via Vector Backend
    # -------------------------------------------------------------------------

    async def find_similar_events(
        self,
        query: str,
        timeline_id: uuid.UUID,
        tenant_id: uuid.UUID,
        k: int = 5,
        event_type: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Find similar events using semantic search.

        Args:
            query: Natural language query
            timeline_id: Timeline to search in
            tenant_id: Tenant ID
            k: Number of results to return
            event_type: Optional filter by event type

        Returns:
            List of event dicts with similarity scores
        """
        if not self._embedder:
            raise ExtractionError("Embedder is required for semantic search")

        # Generate query embedding
        query_embedding_vec = await self._embedder(query)

        # Serialize to bytes (little-endian float32)
        import struct
        query_embedding_bytes = struct.pack(f"<{len(query_embedding_vec)}f", *query_embedding_vec)

        # Build filter
        filter_dict = {
            "timeline_id": timeline_id,
            "tenant_id": tenant_id,
        }
        if event_type:
            filter_dict["event_type"] = event_type

        # Search via vector backend
        results = await self._vector_backend.knn(
            query_embedding=query_embedding_bytes,
            k=k,
            filter=filter_dict,
        )

        # Load full event records
        event_ids = [uuid.UUID(event_id) for event_id, _ in results]
        similarity_map = {event_id: sim for event_id, sim in results}

        with TenantContext.use(tenant_id):
            async with self._sf.read_session() as session:
                stmt = select(Event).where(Event.id.in_(event_ids))
                result = await session.execute(stmt)
                events = result.scalars().all()

        # Build result dicts
        event_dicts = []
        for event in events:
            event_dicts.append({
                "id": str(event.id),
                "title": event.title,
                "description": event.description,
                "date_start": event.date_start.isoformat() if event.date_start else None,
                "date_display": event.date_display,
                "location": event.location,
                "people": event.people,
                "themes": event.themes,
                "emotional_tone": event.emotional_tone,
                "importance": event.importance,
                "similarity": similarity_map.get(str(event.id), 0.0),
            })

        # Sort by similarity descending
        event_dicts.sort(key=lambda x: x["similarity"], reverse=True)

        return event_dicts

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _parse_date(self, date_str: Optional[str]) -> Optional[date]:
        """Parse a date string to a date object.

        Supports ISO format (YYYY-MM-DD) and returns None for invalid dates.
        """
        if not date_str:
            return None

        try:
            # Try ISO format
            if isinstance(date_str, str):
                parts = date_str.split("-")
                if len(parts) == 3:
                    return date(int(parts[0]), int(parts[1]), int(parts[2]))
                elif len(parts) == 2:
                    # Year-month only
                    return date(int(parts[0]), int(parts[1]), 1)
                elif len(parts) == 1:
                    # Year only
                    return date(int(parts[0]), 1, 1)
        except (ValueError, TypeError):
            pass

        return None
