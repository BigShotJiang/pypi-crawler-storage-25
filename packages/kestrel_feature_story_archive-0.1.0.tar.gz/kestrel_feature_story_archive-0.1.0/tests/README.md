# kestrel-feature-story-archive — Test Suite

This directory contains the test suite for kestrel-feature-story-archive, including **backend parity matrix tests** that ensure both `PurePythonBackend` (SQLite) and `PgVectorBackend` (PostgreSQL) produce consistent results.

## Test Organization

```
tests/
├── conftest.py                  # Shared fixtures, including parity_session_factory
├── test_backend_parity.py       # Backend parity matrix tests (FEAT-6.5)
├── test_vector_search.py        # Vector backend instantiation tests
├── test_services.py             # Service instantiation smoke tests
├── test_smoke.py                # Entry-point smoke tests
└── unit/
    ├── test_story_feature.py
    ├── test_story_extractor.py
    ├── test_timeline_builder.py
    ├── test_story_sharing_service.py
    ├── test_story_replay_service.py
    ├── test_story_export_service.py
    ├── test_contradiction_service.py
    └── ...
```

## Backend Parity Matrix (FEAT-6.5)

**Goal**: Every test that touches vector search runs **twice** — once with `PurePythonBackend` + SQLite, once with `PgVectorBackend` + Postgres. This catches dialect drift early and ensures both backends compute cosine similarity consistently.

### Running Parity Tests

#### 1. Run all parity tests against both backends (local)

```bash
# SQLite (default)
uv run --extra test pytest -m parity

# PostgreSQL (requires Docker)
BACKEND=postgres uv run --extra test pytest -m parity
```

#### 2. Run only SQLite tests

```bash
BACKEND=sqlite uv run --extra test pytest -m parity
```

#### 3. Run only Postgres tests

```bash
BACKEND=postgres uv run --extra test pytest -m parity
```

#### 4. Run all tests (parity + non-parity)

```bash
# SQLite
uv run --extra test pytest

# PostgreSQL
BACKEND=postgres uv run --extra test pytest -m parity
uv run --extra test pytest -m "not parity"
```

### CI Matrix

The CI workflow (`.github/workflows/ci.yml`) runs a **6-combination matrix**:

```yaml
strategy:
  matrix:
    python-version: ['3.11', '3.12', '3.13', '3.14']
    backend: ['sqlite', 'postgres']
```

This produces:
- 4 Python versions × 2 backends = **8 combinations** for parity tests
- Non-parity tests run once per Python version (SQLite only)

### PostgreSQL Test Container

#### Using testcontainers-python (automatic)

The `parity_session_factory` fixture in `conftest.py` automatically spins up a PostgreSQL container with pgvector when `backend_type == "postgres"`. No manual setup required.

```python
@pytest.mark.parametrize("backend_type", [
    pytest.param("sqlite", id="sqlite"),
    pytest.param("postgres", id="postgres"),
], indirect=True)
async def test_vector_search(parity_session_factory, backend_type):
    backend = get_vector_backend(parity_session_factory)
    # Test runs twice: once with SQLite, once with Postgres
```

The container:
- Uses image: `pgvector/pgvector:pg15`
- Enables extensions: `vector`, `uuid-ossp`, `pg_trgm`
- Runs migrations via `EntityBase.metadata.create_all()`
- Automatically stops and cleans up after tests

#### Using docker-compose (manual, for debugging)

Alternatively, start a persistent Postgres container for debugging:

```bash
# Start Postgres with pgvector
docker-compose -f docker-compose.test.yml up -d

# Run tests against the manual container
# (You'll need to configure a custom fixture to use this container)
BACKEND=postgres uv run --extra test pytest -m parity

# Stop and remove
docker-compose -f docker-compose.test.yml down -v
```

Connection details:
- Host: `localhost`
- Port: `15433`
- User: `postgres`
- Password: `postgres`
- Database: `kestrel_feature_story_archive_test`

## Test Fixtures

### `parity_session_factory`

Parametrized fixture that creates either a SQLite or Postgres session factory:

```python
async def test_my_vector_test(parity_session_factory):
    backend = get_vector_backend(parity_session_factory)
    # Works with both SQLite and Postgres
```

To parametrize your own test:

```python
import pytest

BACKEND_PARAMS = [
    pytest.param("sqlite", marks=pytest.mark.parity, id="sqlite"),
    pytest.param("postgres", marks=pytest.mark.parity, id="postgres"),
]

@pytest.mark.parametrize("backend_type", BACKEND_PARAMS, indirect=True)
async def test_my_test(parity_session_factory, backend_type):
    # Test runs twice
    pass
```

### `db_session_factory`

Legacy fixture for non-parametrized tests (SQLite only):

```python
async def test_non_vector_test(db_session_factory):
    # SQLite in-memory, no parity requirement
    pass
```

## Writing Parity Tests

### Guidelines

1. **Mark parity tests** with `@pytest.mark.parity`
2. **Use parametrized `backend_type`** fixture (indirect)
3. **Assert cosine similarity within tolerance**: `pytest.approx(expected, rel=1e-5)`
4. **Test filters**: `timeline_id`, `tenant_id`, `event_type`, `is_sensitive`
5. **Test edge cases**: zero norm, large k, empty timelines

### Example

```python
import pytest

BACKEND_PARAMS = [
    pytest.param("sqlite", marks=pytest.mark.parity, id="sqlite"),
    pytest.param("postgres", marks=pytest.mark.parity, id="postgres"),
]

@pytest.mark.parametrize("backend_type", BACKEND_PARAMS, indirect=True)
async def test_knn_topk(parity_session_factory, backend_type):
    from kestrel_feature_entities import TenantContext

    backend = get_vector_backend(parity_session_factory)

    timeline_id = uuid.uuid4()
    tenant_id = uuid.uuid4()

    # Create events with known embeddings
    with TenantContext.use(tenant_id):
        async with parity_session_factory.write_session() as session:
            # ... create timeline and events ...
            await session.commit()

    # Query
    results = await backend.knn(
        query_embedding,
        k=5,
        filter={"timeline_id": timeline_id, "tenant_id": tenant_id},
    )

    # Assert results match expected similarity scores
    assert len(results) == 5
    assert results[0][1] == pytest.approx(0.95, rel=1e-5)
```

## Test Count

As of FEAT-6.5, the parity test suite includes:

- **15 backend parity tests** in `test_backend_parity.py`
  - Backend factory tests (1)
  - Embedding serialization tests (2)
  - KNN search tests (11)
    - Empty timeline, basic top-k, k-limit, filters (event_type, is_sensitive, combined)
    - Tenant isolation, all filtered out, events without embeddings
    - Cosine similarity parity (the critical test!)
    - Edge cases (zero norm, large k)
- Each test runs **twice** (SQLite + Postgres) = **30 test executions**

The tests comprehensively cover all vector backend functionality, filters, edge cases, and most importantly, verify that both PurePythonBackend (numpy) and PgVectorBackend (pgvector) compute cosine similarity consistently within float32 precision tolerance.

## Running Tests in CI

CI automatically runs the full matrix. To debug CI failures locally:

```bash
# Reproduce the exact CI environment
uv python install 3.13
BACKEND=postgres uv run --extra test pytest -q -m parity
```

## Troubleshooting

### Docker not available

If you don't have Docker installed, parity tests will fail when `backend_type == "postgres"`. Run only SQLite tests:

```bash
uv run --extra test pytest -m parity -k sqlite
```

Or skip Postgres tests entirely:

```bash
uv run --extra test pytest -m "parity and not postgres"
```

### Testcontainer cleanup issues

If containers are not cleaned up properly:

```bash
docker ps -a | grep postgres
docker stop <container_id>
docker rm <container_id>
```

### Slow Postgres tests

Postgres tests are slower than SQLite (container startup overhead). To speed up local development:

1. Run only SQLite during development: `BACKEND=sqlite pytest -m parity`
2. Run Postgres tests before pushing: `BACKEND=postgres pytest -m parity`

## Dependencies

Required packages (installed via `uv run --extra test`):

- `pytest>=8.0.0`
- `pytest-asyncio>=1.1.0`
- `testcontainers[postgres]>=4.0.0`
- `aiosqlite>=0.19.0`
- `numpy>=1.26` (for PurePythonBackend cosine similarity)
- `pgvector>=0.2` (for PgVectorBackend)
- `psycopg[binary]>=3.0` (PostgreSQL driver)

## References

- [FEAT-6.5 Issue](https://github.com/KestrelSovereignAI/kestrel-feature-story-archive/issues/8)
- [VectorSearchBackend abstraction](../kestrel_feature_story_archive/vector_search/)
- [CI workflow](../.github/workflows/ci.yml)
