# Schema Verification Scripts

This directory contains scripts for verifying schema equivalence between the
kestrel-feature-story-archive entities and the frinz production database.

## verify_schema_equivalence.sh

**Purpose:** Verify that the entities defined in FEAT-2 produce a schema that
exactly matches the current frinz dev DB story tables.

**Exit Codes:**
- `0` - Schema matches (only whitelisted differences)
- `1` - Schema drift detected (non-whitelisted differences)
- `2` - Setup/dependency error

### Requirements

- **Docker** - for fresh PostgreSQL 15 with pgvector
- **PostgreSQL client tools** - psql, pg_dump
- **cloud-sql-proxy** - for frinz DB access (optional for local-only verification)
- **gcloud CLI** - for Secret Manager access (optional for local-only verification)

### Usage

```bash
# Full verification against frinz dev DB (requires GCP credentials)
./scripts/verify_schema_equivalence.sh

# Show help
./scripts/verify_schema_equivalence.sh --help
```

### Local-Only Verification

If you don't have access to frinz dev DB (no cloud-sql-proxy or gcloud), the
script will still:
1. Spin up a fresh PostgreSQL container
2. Run Alembic migrations
3. Dump the entity schema for manual review
4. Exit with code 0 (warning that frinz comparison was skipped)

This is useful for CI environments or local development where you just want
to verify that the migrations can run successfully.

### What It Does

1. **Starts PostgreSQL container** with pgvector, uuid-ossp, pg_trgm extensions
2. **Runs Alembic migrations** from kestrel_feature_story_archive/alembic
3. **Dumps entity schema** for all story_* tables (no owner, no ACL)
4. **Connects to frinz dev DB** via cloud-sql-proxy (if available)
5. **Dumps frinz schema** for all story_* tables
6. **Normalizes both schemas** (remove comments, whitespace, etc.)
7. **Applies whitelist transformations** to frinz schema:
   - `companion_id UUID` → `agent_did VARCHAR(255)`
   - Add `tenant_id UUID` column
8. **Diffs the schemas** and reports any non-whitelisted differences

### Whitelisted Differences

Only these two differences are allowed (see FEAT-2.5 issue #3):

1. **Column rename:** `companion_id UUID` (frinz) → `agent_did VARCHAR(255)` (entities)
2. **New column:** `tenant_id UUID NULL` (entities only, not in frinz)

Both differences are intentionally handled by the FRINZ-1 adoption migration.

### Troubleshooting

**Docker container already exists:**
```
Error: Conflict. The container name "/kestrel-feature-story-pg-test" is already in use
```
Solution: The script automatically removes existing containers. If it fails,
manually remove: `docker rm -f kestrel-feature-story-pg-test`

**PostgreSQL port conflict:**
```
Error: Bind for 0.0.0.0:15433 failed: port is already allocated
```
Solution: Another process is using port 15433. Change `FEATURE_DB_PORT` in
the script or stop the conflicting service.

**Alembic migration fails:**
```
ERROR: Alembic migration failed
```
Solution: Check that kestrel-feature-entities is installed and entity models
are importable. Run `uv sync` to ensure all dependencies are installed.

**cloud-sql-proxy not found:**
```
WARN: cloud-sql-proxy not found - frinz DB comparison will be skipped
```
Solution: Install cloud-sql-proxy:
- macOS: `brew install cloud-sql-proxy`
- Linux: Download from [Cloud SQL Proxy releases](https://cloud.google.com/sql/docs/postgres/sql-proxy#install)

**gcloud authentication error:**
```
ERROR: gcloud secrets versions access latest --secret=frinz-db-dev-password failed
```
Solution: Authenticate with gcloud:
```bash
gcloud auth login
gcloud auth application-default login
```

### CI Integration

The schema verification is automatically run in CI for every PR. See
`.github/workflows/ci.yml` for the CI configuration. The CI version:
- Spins up PostgreSQL using GitHub Actions services
- Runs Alembic migrations
- Verifies all 10 story_* tables are created
- Verifies vector(1536) and JSONB columns exist
- Does NOT compare against frinz (no credentials in CI)

### Output Example

```bash
$ ./scripts/verify_schema_equivalence.sh
[INFO] === Schema Equivalence Verification ===
[INFO] Project: kestrel-feature-story-archive
[INFO] Task: FEAT-2.5

[INFO] Checking dependencies...
[SUCCESS] All dependencies available
[INFO] Starting PostgreSQL container...
[INFO] Waiting for PostgreSQL to be ready...
[INFO] Enabling required PostgreSQL extensions...
[SUCCESS] PostgreSQL container started and configured
[INFO] Running Alembic migrations...
[SUCCESS] Alembic migrations completed
[INFO] Dumping entity schema from feature database...
[SUCCESS] Entity schema dumped to /tmp/tmp.XXXXXX/entities_schema.sql
[INFO] Starting cloud-sql-proxy for frinz dev DB...
[INFO] Waiting for cloud-sql-proxy to be ready...
[INFO] Retrieving frinz DB password from Secret Manager...
[INFO] Dumping frinz dev DB schema...
[SUCCESS] Frinz schema dumped to /tmp/tmp.XXXXXX/frinz_schema.sql
[INFO] Normalizing schemas for comparison...
[INFO] Applying whitelist transformations to frinz schema...
[INFO] Comparing normalized schemas...
[SUCCESS] ✓ Schema equivalence verified - no drift detected!
[INFO] Stopping PostgreSQL container...
[SUCCESS] === Verification Complete: PASS ===
```
