# kestrel-feature-story-archive

Schema-rich agent life-story archive for Kestrel Sovereign.

An agent maintains a queryable, semantic archive of its life-story:
interactions, observations, and reflections, organized as a timeline
with vector search and contradiction detection. This is a reusable
framework capability — a sibling package alongside
`kestrel-feature-healthcare` / `-visual` / `-reflection` / `-observability`
— not a host-product feature. Any Kestrel host can consume it.

## Status

Bootstrap skeleton (FEAT-1). Business logic lands in FEAT-2..5:

- **FEAT-2** — entity models (Story, StoryChunk, StoryEvent) + Alembic migrations
- **FEAT-3** — TimelineBuilder (session → Story/StoryEvent/StoryChunk extractor)
- **FEAT-4** — VectorSearch integration for semantic story retrieval
- **FEAT-5** — sharing, replay, export, contradiction detection services

This package migrates the 8,240-LOC Story Archive stack from Frinz into
a reusable feature package so other consumers (RemoteCares/RPM Azure
pilot) can leverage it. Records are scoped to `agent_did` (the canonical
owner identity per the Agent Identity Contract).

## Installation

```bash
uv pip install kestrel-feature-story-archive
```

The package registers `StoryFeature` through the
`kestrel_sovereign.features` entry-point group and registers its entity
models via the `kestrel_entities.models` entry-point for Alembic
autogen.

## Development

```bash
uv sync --extra test
uv run --extra test pytest
```

## Architecture

Records are `agent_did`-scoped and persisted via kestrel-feature-entities
ORM layer. The feature consumes the `DatabaseBackend` from the host and
leverages the Timeline and VectorSearch protocols (kestrel-sovereign-sdk
v0.16.0+).

No product-specific terminology anywhere in this package — vocabulary is
`agent` / `agent_did` / `owner` throughout. This is a framework capability.
