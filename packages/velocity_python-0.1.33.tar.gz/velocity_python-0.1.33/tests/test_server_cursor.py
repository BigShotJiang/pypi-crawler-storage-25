"""
Tests for ServerCursor / Transaction.stream() / Table.stream().
"""

import pytest
from unittest.mock import MagicMock, call, patch

from velocity.db.core.transaction import ServerCursor
from velocity.db.core.result import Result


# ── helpers ───────────────────────────────────────────────────────────────────

def _make_tx(execute_side_effects=None):
    """Return a mock Transaction whose execute() returns the given side effects."""
    tx = MagicMock()
    if execute_side_effects is not None:
        tx.execute.side_effect = execute_side_effects
    return tx


def _result(rows, headers=None):
    """Return a mock Result that iterates over rows and has the given headers."""
    r = MagicMock(spec=Result)
    r.__bool__ = MagicMock(return_value=bool(rows))
    r.headers = headers or [f"col{i}" for i in range(len(rows[0]) if rows else 0)]
    r.as_list.return_value.all.return_value = list(rows)
    return r


def _empty_result():
    """Return a falsy mock Result (no rows)."""
    r = MagicMock(spec=Result)
    r.__bool__ = MagicMock(return_value=False)
    return r


# ── ServerCursor unit tests ───────────────────────────────────────────────────

class TestServerCursorContextManager:
    def test_enter_issues_declare(self):
        tx = _make_tx()
        cursor = ServerCursor(tx, "SELECT 1", fetch_size=100)
        cursor.__enter__()
        declare_call = tx.execute.call_args_list[0]
        assert "DECLARE" in declare_call[0][0]
        assert "CURSOR FOR" in declare_call[0][0]
        assert "SELECT 1" in declare_call[0][0]

    def test_exit_issues_close(self):
        tx = _make_tx()
        cursor = ServerCursor(tx, "SELECT 1")
        cursor._open = True
        cursor._name = "vc_test1234"
        cursor.__exit__(None, None, None)
        close_call = tx.execute.call_args_list[-1]
        assert "CLOSE vc_test1234" in close_call[0][0]

    def test_exit_not_called_when_not_open(self):
        tx = _make_tx()
        cursor = ServerCursor(tx, "SELECT 1")
        cursor._open = False
        cursor.__exit__(None, None, None)
        tx.execute.assert_not_called()

    def test_exit_swallows_close_errors(self):
        tx = _make_tx()
        tx.execute.side_effect = Exception("connection lost")
        cursor = ServerCursor(tx, "SELECT 1")
        cursor._open = True
        # should not raise
        cursor.__exit__(None, None, None)

    def test_exit_returns_false(self):
        tx = _make_tx()
        cursor = ServerCursor(tx, "SELECT 1")
        assert cursor.__exit__(None, None, None) is False

    def test_unique_cursor_names(self):
        tx = _make_tx()
        names = {ServerCursor(tx, "SELECT 1")._name for _ in range(50)}
        assert len(names) == 50


class TestServerCursorIteration:
    def test_yields_result_per_batch(self):
        batch1 = _result([(1, "a"), (2, "b")])
        batch2 = _empty_result()
        tx = _make_tx(execute_side_effects=[MagicMock(), batch1, batch2])  # DECLARE, FETCH, FETCH

        results = []
        with ServerCursor(tx, "SELECT id, name FROM t", fetch_size=2) as cur:
            for result in cur:
                results.append(result)

        assert results == [batch1]

    def test_multiple_batches(self):
        b1 = _result([(i,) for i in range(5)])
        b2 = _result([(i,) for i in range(5, 10)])
        empty = _empty_result()
        tx = _make_tx(execute_side_effects=[MagicMock(), b1, b2, empty])

        results = []
        with ServerCursor(tx, "SELECT id FROM t", fetch_size=5) as cur:
            for result in cur:
                results.append(result)

        assert results == [b1, b2]

    def test_empty_table_yields_nothing(self):
        empty = _empty_result()
        tx = _make_tx(execute_side_effects=[MagicMock(), empty])

        results = []
        with ServerCursor(tx, "SELECT id FROM t") as cur:
            for result in cur:
                results.append(result)

        assert results == []

    def test_close_called_on_exception(self):
        batch = _result([(1,)])
        tx = _make_tx(execute_side_effects=[MagicMock(), batch])
        cursor_name = None

        try:
            with ServerCursor(tx, "SELECT 1") as cur:
                cursor_name = cur._name
                for _ in cur:
                    raise RuntimeError("mid-loop error")
        except RuntimeError:
            pass

        last_call = tx.execute.call_args_list[-1][0][0]
        assert f"CLOSE {cursor_name}" in last_call

    def test_fetch_uses_correct_size(self):
        empty = _empty_result()
        tx = _make_tx(execute_side_effects=[MagicMock(), empty])

        with ServerCursor(tx, "SELECT 1", fetch_size=1234) as cur:
            for _ in cur:
                pass

        fetch_call = tx.execute.call_args_list[1][0][0]
        assert "FETCH 1234" in fetch_call

    def test_vals_passed_to_declare(self):
        tx = _make_tx()
        cursor = ServerCursor(tx, "SELECT * FROM t WHERE id = %s", vals=(42,))
        cursor.__enter__()
        declare_call = tx.execute.call_args_list[0]
        assert declare_call[0][1] == (42,)


# ── Transaction.stream() ──────────────────────────────────────────────────────

class TestTransactionStream:
    def test_returns_server_cursor(self):
        from velocity.db.core.transaction import Transaction
        tx = MagicMock(spec=Transaction)
        # call the real stream() via unbound method
        sc = Transaction.stream(tx, "SELECT 1", (1, 2), fetch_size=100)
        assert isinstance(sc, ServerCursor)
        assert sc._sql == "SELECT 1"
        assert sc._vals == (1, 2)
        assert sc._fetch_size == 100
