def main():
    print("Hello from pyset!")


if __name__ == "__main__":
    main()
