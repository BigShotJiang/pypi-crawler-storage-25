"""PySET TokenBoundaryDetector - Main API.

The primary entry point for sentence boundary detection.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Union, Dict, Any
import time

from .config import Config
from .core import (
    RulesEngine, Context, BoundaryDecision, PySETException,
    ConfigurationError, LanguageError, ValidationError
)
from .core.rule import Verdict
from .preprocessing import TextNormalizer, TextCleaner, find_candidates
from .postprocessing import SentenceValidator, SentenceMerger, OutputFormatter
from .languages import LanguageRegistry, English
from .languages.base_language import BaseLanguage
from .utils import ProcessingStatistics, Timer
from .rules import get_all_rules, get_rule_by_id


@dataclass
class Span:
    """Sentence with position info."""
    text: str
    start: int
    end: int
    
    def length(self) -> int:
        return self.end - self.start


@dataclass 
class SentenceInfo:
    """Sentence with rule metadata."""
    text: str
    start: int
    end: int
    rules_applied: List[int] = field(default_factory=list)
    confidence: float = 0.0
    boundary_confidence: float = 0.0


@dataclass
class BoundaryInfo:
    """Detailed boundary decision info."""
    position: int
    character: str
    is_boundary: bool
    confidence: float
    primary_rule_id: int = 0
    primary_reason: str = ""
    all_rules: List[Dict[str, Any]] = field(default_factory=list)
    before_context: str = ""
    after_context: str = ""


class TokenBoundaryDetector:
    """Main API for sentence boundary detection.
    
    Example:
        detector = TokenBoundaryDetector()
        sentences = detector.split("Hello world. How are you?")
        # ['Hello world.', 'How are you?']
    """
    
    def __init__(
        self,
        language: str = 'en',
        include_rules: Optional[List[int]] = None,
        exclude_rules: Optional[List[int]] = None,
        aggressive_abbreviations: bool = False,
        min_sentence_length: int = 1,
        merge_short_sentences: bool = False,
        normalize_output: bool = True,
        debug: bool = False,
        timeout_seconds: float = 30.0,
        max_text_length: int = 10_000_000,
    ):
        """Initialize detector with configuration."""
        
        # Build config
        self.config = Config(
            language=language,
            min_sentence_length=min_sentence_length,
            aggressive_abbreviations=aggressive_abbreviations,
            merge_short_sentences=merge_short_sentences,
            normalize_output=normalize_output,
            debug=debug,
            timeout_seconds=timeout_seconds,
            max_text_length=max_text_length,
            rules_to_include=include_rules,
            rules_to_exclude=exclude_rules,
        )
        
        # Load language and rules
        self.language = LanguageRegistry.get(language)
        self.rules_engine = RulesEngine(language)
        
        # Custom abbreviations (must be before _load_rules)
        self._custom_abbrevs: set[str] = set()
        
        self._load_rules()
        
        # Initialize post-processing
        self.validator = SentenceValidator(min_sentence_length)
        self.merger = SentenceMerger(min_sentence_length)
        self.formatter = OutputFormatter(normalize_output)
        
        # Statistics
        self._statistics: Optional[ProcessingStatistics] = None
        
        # Debug mode
        self._debug = debug
    
    def _load_rules(self) -> None:
        """Load rules from language."""
        rules = self.language.get_rules()
        
        # Handle included/excluded rules
        if self.config.rules_to_include:
            rules = [r for r in rules if r.id in self.config.rules_to_include]
        
        if self.config.rules_to_exclude:
            rules = [r for r in rules if r.id not in self.config.rules_to_exclude]
        
        # Add abbreviations from language
        abbreviations = self.language.abbreviations.copy()
        abbreviations.update(self._custom_abbrevs)
        
        # Set abbreviations on context when evaluating (handled in split)
        self.rules_engine.load_rules(rules)
    
    def split(
        self,
        text: str,
        return_spans: bool = False,
        return_metadata: bool = False
    ) -> Union[List[str], List[Span], List[SentenceInfo]]:
        """Split text into sentences.
        
        Args:
            text: Input text to segment
            return_spans: Include character positions
            return_metadata: Include rule metadata
            
        Returns:
            List of sentences, Spans, or SentenceInfo objects
        """
        if not text:
            return []
        
        # Validate length
        if len(text) > self.config.max_text_length:
            raise ValueError(f"Text exceeds max length of {self.config.max_text_length}")
        
        timer = Timer()
        timer.__enter__()
        
        # Preprocess
        text = TextNormalizer.normalize(text)
        text = TextCleaner.clean(text)
        
        # Find boundaries
        boundaries = self._find_boundaries(text)
        
        # Split text
        sentences = self._split_at_boundaries(text, boundaries)
        
        # Post-process
        sentences = self.validator.validate(sentences)
        if self.config.merge_short_sentences:
            sentences = self.merger.merge(sentences)
        sentences = self.formatter.format(sentences)
        
        timer.__exit__(None, None, None)
        
        # Calculate statistics
        self._calculate_statistics(text, sentences, len(boundaries), timer)
        
        # Return format
        if return_spans:
            return self._to_spans(text, sentences, boundaries)
        elif return_metadata:
            return self._to_metadata(sentences, boundaries)
        else:
            return sentences
    
    def _find_boundaries(self, text: str) -> List[int]:
        """Find all sentence boundaries in text."""
        # Get candidate positions
        candidates = find_candidates(text)
        
        if not candidates:
            return []
        
        boundaries = []
        
        abbreviations = self.language.abbreviations.copy()
        abbreviations.update(self._custom_abbrevs)
        
        for pos in candidates:
            # Create context
            context = Context(text, pos, abbreviations)
            
            # Evaluate
            decision = self.rules_engine.evaluate_position(context)
            
            if decision.is_boundary:
                boundaries.append(pos)
        
        return boundaries
    
    def _split_at_boundaries(self, text: str, boundaries: List[int]) -> List[str]:
        """Split text at boundary positions."""
        if not boundaries:
            return [text] if text else []
        
        sentences = []
        prev = 0
        
        for pos in boundaries:
            sentences.append(text[prev:pos + 1])
            prev = pos + 1
        
        # Add remaining
        if prev < len(text):
            sentences.append(text[prev:])
        
        # Filter empty
        return [s.strip() for s in sentences if s.strip()]
    
    def _calculate_statistics(
        self, 
        text: str, 
        sentences: List[str], 
        boundaries_found: int,
        timer: Timer
    ) -> None:
        """Calculate processing statistics."""
        total_length = len(text)
        sentence_count = len(sentences)
        avg_length = total_length / sentence_count if sentence_count else 0
        
        self._statistics = ProcessingStatistics(
            text_length=total_length,
            sentence_count=sentence_count,
            avg_sentence_length=avg_length,
            processing_time_ms=timer.elapsed_ms,
            boundaries_evaluated=0,
            boundaries_found=boundaries_found,
            rules_used=len(self.rules_engine),
            confidence_avg=0.0,  # Could track from decisions
        )
    
    def _to_spans(self, text: str, sentences: List[str], boundaries: List[int]) -> List[Span]:
        """Convert sentences to Span objects."""
        spans = []
        pos = 0
        
        for sentence in sentences:
            start = text.find(sentence, pos)
            if start >= 0:
                end = start + len(sentence)
                spans.append(Span(sentence, start, end))
                pos = end
        
        return spans
    
    def _to_metadata(self, sentences: List[str], boundaries: List[int]) -> List[SentenceInfo]:
        """Convert sentences to SentenceInfo."""
        metadata = []
        pos = 0
        
        for sentence in sentences:
            start = pos
            # Find position in original boundaries (simplified)
            end = start + len(sentence)
            metadata.append(SentenceInfo(
                sentence,
                start,
                end,
                rules_applied=[],  # Could track from decisions
                confidence=0.95,
                boundary_confidence=0.95,
            ))
            pos = end
        
        return metadata
    
    def explain(self, text: str) -> List[BoundaryInfo]:
        """Return detailed boundary decisions.
        
        Args:
            text: Input text
            
        Returns:
            List of BoundaryInfo objects with decision details
        """
        if not text:
            return []
        
        # Preprocess
        text = TextNormalizer.normalize(text)
        text = TextCleaner.clean(text)
        
        # Get candidates
        candidates = find_candidates(text)
        
        abbreviations = self.language.abbreviations.copy()
        abbreviations.update(self._custom_abbrevs)
        
        explanations = []
        
        for pos in candidates:
            context = Context(text, pos, abbreviations)
            decision = self.rules_engine.evaluate_position(context)
            
            explanations.append(BoundaryInfo(
                position=pos,
                character=text[pos],
                is_boundary=decision.is_boundary,
                confidence=decision.confidence,
                primary_rule_id=decision.contributing_rules[0].rule_id if decision.contributing_rules else 0,
                primary_reason=decision.primary_reason,
                all_rules=[{"rule_id": r.rule_id, "verdict": r.verdict.value, 
                       "confidence": r.confidence, "reason": r.reason}
                      for r in decision.contributing_rules],
                before_context=context.window_before(20),
                after_context=context.window_after(20),
            ))
        
        return explanations
    
    def get_statistics(self) -> ProcessingStatistics:
        """Get processing statistics from last split."""
        return self._statistics or ProcessingStatistics()
    
    def add_rule(self, rule: Any) -> None:
        """Add custom rule."""
        self.rules_engine.add_rule(rule)
    
    def enable_rule(self, rule_id: int) -> bool:
        """Enable a rule."""
        return self.rules_engine.enable_rule(rule_id)
    
    def disable_rule(self, rule_id: int) -> bool:
        """Disable a rule."""
        return self.rules_engine.disable_rule(rule_id)
    
    def set_abbreviations(self, abbreviations: set) -> None:
        """Set custom abbreviations."""
        self._custom_abbrevs = abbreviations
        # Also set on custom rule if it exists
        rule = self.rules_engine.get_rule(25)
        if rule:
            rule.CUSTOM_ABBREVS = abbreviations
    
    @property
    def debug(self) -> bool:
        return self._debug
    
    @debug.setter
    def debug(self, value: bool) -> None:
        self._debug = value


def split(text: str, **kwargs) -> List[str]:
    """Convenience function for splitting text.
    
    Example:
        >>> split("Hello world. How are you?")
        ['Hello world.', 'How are you?']
    """
    detector = TokenBoundaryDetector(**kwargs)
    return detector.split(text)


__all__ = [
    "TokenBoundaryDetector",
    "Span", 
    "SentenceInfo",
    "BoundaryInfo",
    "split",
]