"""Output Formatter - Format and normalize output."""

from __future__ import annotations
import re
from typing import List


class OutputFormatter:
    """Format and normalize output sentences."""
    
    def __init__(self, normalize_whitespace: bool = True, strip_whitespace: bool = True):
        self.normalize_whitespace = normalize_whitespace
        self.strip_whitespace = strip_whitespace
    
    def format(self, sentences: List[str]) -> List[str]:
        """Format sentences for output."""
        result = []
        
        for sentence in sentences:
            if self.normalize_whitespace:
                sentence = self._normalize_whitespace(sentence)
            
            if self.strip_whitespace:
                sentence = sentence.strip()
            
            result.append(sentence)
        
        return [s for s in result if s]  # Remove empty
    
    @staticmethod
    def _normalize_whitespace(text: str) -> str:
        """Normalize whitespace in text."""
        # Multiple spaces to single
        text = re.sub(r' +', ' ', text)
        # Multiple newlines to single (but preserve paragraphs)
        text = re.sub(r'\n\n+', '\n\n', text)
        # Tabs to spaces
        text = re.sub(r'\t+', ' ', text)
        return text