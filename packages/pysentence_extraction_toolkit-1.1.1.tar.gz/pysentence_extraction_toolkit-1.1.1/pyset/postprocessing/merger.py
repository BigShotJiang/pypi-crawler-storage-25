"""Sentence Merger - Merges short fragments."""

from __future__ import annotations
from typing import List


class SentenceMerger:
    """Merge short fragments with previous sentence."""
    
    def __init__(self, min_length: int = 3):
        self.min_length = min_length
    
    def merge(self, sentences: List[str]) -> List[str]:
        """Merge very short sentences with previous."""
        if not sentences:
            return []
        
        merged = []
        current = ""
        
        for sentence in sentences:
            cleaned = sentence.strip()
            
            if current and len(cleaned) < self.min_length:
                # Merge short sentence with previous
                merged[-1] = merged[-1].rstrip() + " " + cleaned
            else:
                if current:
                    merged.append(current)
                current = cleaned
        
        # Add final sentence
        if current:
            merged.append(current)
        
        return merged