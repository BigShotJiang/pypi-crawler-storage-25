"""Sentence Validator - Validates output sentences."""

from __future__ import annotations
from typing import List


class SentenceValidator:
    """Validate output sentences."""
    
    def __init__(self, min_length: int = 1):
        self.min_length = min_length
    
    def validate(self, sentences: List[str]) -> List[str]:
        """Validate and filter sentences."""
        valid = []
        
        for sentence in sentences:
            if self._is_valid(sentence):
                valid.append(sentence)
        
        return valid
    
    def _is_valid(self, sentence: str) -> bool:
        """Check if sentence meets criteria."""
        # Minimum length
        if len(sentence.strip()) < self.min_length:
            return False
        
        # Valid Unicode (can encode)
        try:
            sentence.encode('utf-8')
        except UnicodeError:
            return False
        
        return True
    
    @staticmethod
    def has_balanced_quotes(text: str) -> bool:
        """Check if quotes are balanced."""
        double_count = text.count('"')
        single_count = text.count("'")
        
        return double_count % 2 == 0 and single_count % 2 == 0
    
    @staticmethod
    def has_balanced_brackets(text: str) -> bool:
        """Check if brackets are balanced."""
        pairs = {'(': ')', '[': ']', '{': '}', '<': '>'}
        
        for open_b, close_b in pairs.items():
            count_open = text.count(open_b)
            count_close = text.count(close_b)
            
            if count_open != count_close:
                return False
        
        return True