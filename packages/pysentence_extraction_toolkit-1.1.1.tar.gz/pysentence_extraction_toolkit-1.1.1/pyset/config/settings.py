"""PySET Configuration Settings."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List

from .defaults import DEFAULT_CONFIG
from ..core.exceptions import ConfigurationError


@dataclass
class Config:
    """Configuration for TokenBoundaryDetector."""
    
    language: str = 'en'
    min_sentence_length: int = 1
    aggressive_abbreviations: bool = False
    merge_short_sentences: bool = False
    rules_to_include: Optional[List[int]] = None
    rules_to_exclude: Optional[List[int]] = None
    debug: bool = False
    timeout_seconds: float = 30.0
    max_text_length: int = 10_000_000
    normalize_output: bool = True
    
    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        self._validate()
    
    def _validate(self) -> None:
        """Validate configuration values."""
        if self.min_sentence_length < 1:
            raise ConfigurationError("min_sentence_length must be >= 1")
        
        if self.max_text_length < 1:
            raise ConfigurationError("max_text_length must be >= 1")
        
        if self.timeout_seconds <= 0:
            raise ConfigurationError("timeout_seconds must be > 0")
        
        if self.language and not self.language.isalpha():
            raise ConfigurationError("language must be alphabetic")
    
    @classmethod
    def from_dict(cls, data: dict) -> Config:
        """Create Config from dictionary."""
        # Filter to only known fields
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'language': self.language,
            'min_sentence_length': self.min_sentence_length,
            'aggressive_abbreviations': self.aggressive_abbreviations,
            'merge_short_sentences': self.merge_short_sentences,
            'rules_to_include': self.rules_to_include,
            'rules_to_exclude': self.rules_to_exclude,
            'debug': self.debug,
            'timeout_seconds': self.timeout_seconds,
            'max_text_length': self.max_text_length,
            'normalize_output': self.normalize_output,
        }
    
    def merge(self, overrides: dict) -> Config:
        """Merge with overrides, returning new Config."""
        base = self.to_dict()
        base.update(overrides)
        return Config.from_dict(base)