"""Config module init."""
from .defaults import DEFAULT_CONFIG, DEFAULT_RULES_PRIORITY
from .settings import Config

__all__ = ["DEFAULT_CONFIG", "DEFAULT_RULES_PRIORITY", "Config"]