"""PySET Default Configuration."""

DEFAULT_CONFIG = {
    'language': 'en',
    'min_sentence_length': 1,
    'aggressive_abbreviations': False,
    'merge_short_sentences': False,
    'rules_to_include': None,
    'rules_to_exclude': None,
    'debug': False,
    'timeout_seconds': 30.0,
    'max_text_length': 10_000_000,
}

DEFAULT_RULES_PRIORITY = 50