"""Text Normalizer - Unicode and whitespace normalization."""

from __future__ import annotations
import unicodedata
from typing import List


class TextNormalizer:
    """Normalize text for processing."""
    
    @staticmethod
    def normalize(text: str) -> str:
        """Normalize text for processing.
        
        - Unicode NFC normalization
        - Standardize line endings
        - Remove zero-width characters
        """
        # Unicode NFC normalization
        text = unicodedata.normalize('NFC', text)
        
        # Fix line endings
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        # Remove zero-width characters (category Cf)
        result = []
        for char in text:
            if unicodedata.category(char) != 'Cf':
                result.append(char)
        
        return ''.join(result)
    
    @staticmethod
    def normalize_lines(text: str) -> str:
        """Normalize line endings to \n."""
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        return text
    
    @staticmethod
    def remove_zero_width(text: str) -> str:
        """Remove zero-width characters."""
        result = []
        for char in text:
            if unicodedata.category(char) != 'Cf':
                result.append(char)
        return ''.join(result)
    
    @staticmethod
    def normalize_unicode(text: str) -> str:
        """Full Unicode normalization."""
        return unicodedata.normalize('NFC', text)