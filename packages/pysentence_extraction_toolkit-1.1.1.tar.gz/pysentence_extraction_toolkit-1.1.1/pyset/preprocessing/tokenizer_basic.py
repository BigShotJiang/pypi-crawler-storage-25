"""Basic Tokenizer - Splits text into sentence candidates."""

from __future__ import annotations
import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Candidate:
    """Potential sentence boundary candidate."""
    position: int
    char: str
    before: str = ""
    after: str = ""
    evaluated: bool = False
    is_boundary: bool = False


class BasicTokenizer:
    """Split text into candidate sentence boundaries.
    
    Finds all potential sentence-ending punctuation
    (. ? !) without validating boundaries.
    """
    
    BOUNDARY_PATTERN = re.compile(r'[.!?]')
    
    def tokenize(self, text: str) -> List[Candidate]:
        """Find all potential sentence boundaries.
        
        Args:
            text: Input text
            
        Returns:
            List of Candidate objects with position info
        """
        candidates = []
        
        for match in self.BOUNDARY_PATTERN.finditer(text):
            position = match.start()
            char = match.group()
            
            # Get context (limited window for memory efficiency)
            before_start = max(0, position - 20)
            after_end = min(len(text), position + 21)
            
            candidates.append(Candidate(
                position=position,
                char=char,
                before=text[before_start:position],
                after=text[position + 1:after_end]
            ))
        
        return candidates
    
    def find_boundary_positions(self, text: str) -> List[int]:
        """Find positions of potential boundaries.
        
        Returns just positions (faster for simple cases).
        """
        return [m.start() for m in self.BOUNDARY_PATTERN.finditer(text)]
    
    def count_candidates(self, text: str) -> int:
        """Count potential boundaries."""
        return len(self.BOUNDARY_PATTERN.findall(text))


def find_candidates(text: str) -> List[int]:
    """Quick helper to find candidates."""
    return [m.start() for m in re.finditer(r'[.!?]', text)]