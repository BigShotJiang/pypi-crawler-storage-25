"""Text Cleaner - Clean text and remove noise."""

from __future__ import annotations
import unicodedata
import re


class TextCleaner:
    """Clean text of formatting artifacts."""
    
    # Smart quote mappings
    SMART_QUOTES = {
        '\u201c': '"',  # "
        '\u201d': '"',  # "
        '\u2018': "'",  # '
        '\u2019': "'",  # '
    }
    
    # Dash mappings
    DASHES = {
        '\u2013': '-',   # –
        '\u2014': '-',   # —
        '\u2015': '-',   # ‗
    }
    
    @staticmethod
    def clean(text: str) -> str:
        """Clean text of formatting artifacts.
        
        - Remove control characters
        - Handle BOM markers
        - Normalize quotes and dashes
        """
        # Remove control characters except newline, tab, carriage return
        result = []
        for char in text:
            cat = unicodedata.category(char)
            if cat[0] != 'C' or char in '\n\t\r':
                result.append(char)
        text = ''.join(result)
        
        # Remove BOM
        text = text.lstrip('\ufeff')
        
        # Normalize quotes
        for old, new in TextCleaner.SMART_QUOTES.items():
            text = text.replace(old, new)
        
        # Normalize dashes
        for old, new in TextCleaner.DASHES.items():
            text = text.replace(old, new)
        
        return text
    
    @staticmethod
    def remove_control_characters(text: str) -> str:
        """Remove control characters except whitespace."""
        result = []
        for char in text:
            cat = unicodedata.category(char)
            if cat[0] != 'C' or char in '\n\t\r':
                result.append(char)
        return ''.join(result)
    
    @staticmethod
    def remove_bom(text: str) -> str:
        """Remove BOM marker."""
        return text.lstrip('\ufeff')
    
    @staticmethod
    def normalize_quotes(text: str) -> str:
        """Normalize smart quotes to straight quotes."""
        for old, new in TextCleaner.SMART_QUOTES.items():
            text = text.replace(old, new)
        return text
    
    @staticmethod
    def normalize_dashes(text: str) -> str:
        """Standardize dash characters."""
        for old, new in TextCleaner.DASHES.items():
            text = text.replace(old, new)
        return text
    
    @staticmethod
    def clean_extra_spaces(text: str) -> str:
        """Clean extra whitespace."""
        # Multiple spaces to single
        text = re.sub(r'  +', ' ', text)
        # Tabs to spaces
        text = re.sub(r'\t+', ' ', text)
        return text