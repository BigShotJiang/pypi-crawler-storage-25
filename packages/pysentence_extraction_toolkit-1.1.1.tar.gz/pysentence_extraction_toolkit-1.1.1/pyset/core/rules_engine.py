"""PySET Rules Engine.

Central orchestrator for rule evaluation and boundary decision.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from .rule import Rule, RuleResult, BoundaryDecision, Verdict
from .context import Context


@dataclass
class RulesEngine:
    """Evaluates rules to determine sentence boundaries.
    
    Manages rule loading, evaluation order, and decision aggregation.
    """
    
    language: str = 'en'
    rules: List[Rule] = field(default_factory=list)
    _context: Optional[Context] = None
    
    def __init__(self, language: str = 'en'):
        self.language = language
        self.rules = []
    
    def load_rules(self, rules: List[Rule]) -> None:
        """Load rules and sort by priority."""
        self.rules = sorted(rules)
    
    def add_rule(self, rule: Rule) -> None:
        """Add a rule and resort."""
        self.rules.append(rule)
        self.rules.sort()
    
    def remove_rule(self, rule_id: int) -> bool:
        """Remove a rule by ID."""
        original_len = len(self.rules)
        self.rules = [r for r in self.rules if r.id != rule_id]
        return len(self.rules) < original_len
    
    def enable_rule(self, rule_id: int) -> bool:
        """Enable a rule by ID."""
        for rule in self.rules:
            if rule.id == rule_id:
                rule.enabled = True
                return True
        return False
    
    def disable_rule(self, rule_id: int) -> bool:
        """Disable a rule by ID."""
        for rule in self.rules:
            if rule.id == rule_id:
                rule.enabled = False
                return True
        return False
    
    def get_rule(self, rule_id: int) -> Optional[Rule]:
        """Get a rule by ID."""
        for rule in self.rules:
            if rule.id == rule_id:
                return rule
        return None
    
    def get_enabled_rules(self) -> List[Rule]:
        """Get list of enabled rules."""
        return [r for r in self.rules if r.enabled]
    
    def evaluate_position(self, context: Context) -> BoundaryDecision:
        """Evaluate if position is a boundary.
        
        Uses early exit when confidence is high enough.
        """
        results: List[RuleResult] = []
        
        for rule in self.rules:
            if not rule.enabled:
                continue
            
            try:
                result = rule.evaluate(context)
                results.append(result)
                
                # Early exit on confident rules: confidence >= 0.75 AND priority >= 85
                # Also accept BOUNDARY with confidence >= 0.90 regardless of priority
                if (result.confidence >= 0.75 and rule.priority >= 85) or \
                   (result.confidence >= 0.90 and result.verdict == Verdict.BOUNDARY):
                    return BoundaryDecision(
                        is_boundary=result.verdict == Verdict.BOUNDARY,
                        confidence=result.confidence,
                        contributing_rules=results,
                        primary_reason=result.reason,
                        all_reasons=[r.reason for r in results]
                    )
            except Exception:
                pass
        
        # Aggregate all results
        return self._finalize_decision(results)
    
    def _finalize_decision(self, results: List[RuleResult]) -> BoundaryDecision:
        """Combine rule results into final decision.
        
        Uses priority-weighted voting.
        """
        boundary_weight = 0.0
        not_boundary_weight = 0.0
        boundary_results: List[RuleResult] = []
        not_boundary_results: List[RuleResult] = []
        
        for result in results:
            if result.verdict == Verdict.BOUNDARY:
                boundary_weight += result.confidence
                boundary_results.append(result)
            elif result.verdict == Verdict.NOT_BOUNDARY:
                not_boundary_weight += result.confidence
                not_boundary_results.append(result)
        
        total = boundary_weight + not_boundary_weight + 0.001
        
        if boundary_weight > not_boundary_weight:
            is_boundary = True
            confidence = boundary_weight / total
            primary = boundary_results[-1] if boundary_results else None
            primary_reason = primary.reason if primary else "Uncertain boundary"
        elif not_boundary_weight > boundary_weight:
            is_boundary = False
            confidence = not_boundary_weight / total
            primary = not_boundary_results[-1] if not_boundary_results else None
            primary_reason = primary.reason if primary else "Uncertain boundary"
        else:
            # Default to BOUNDARY if uncertain
            is_boundary = True
            confidence = 0.5
            primary_reason = "Default boundary (no consensus)"
        
        all_reasons = [r.reason for r in results if r.reason]
        
        return BoundaryDecision(
            is_boundary=is_boundary,
            confidence=confidence,
            contributing_rules=results,
            primary_reason=primary_reason,
            all_reasons=all_reasons
        )
    
    def explain_decision(self, context: Context) -> Dict[str, Any]:
        """Return detailed explanation of decision.
        
        Returns dictionary with full audit trail.
        """
        results = []
        primary = None
        primary_reason = ""
        
        for rule in self.rules:
            if not rule.enabled:
                continue
            
            try:
                result = rule.evaluate(context)
                results.append(result)
                
                if result.confidence >= 0.9 and not primary:
                    primary = result
                    primary_reason = result.reason
            except Exception:
                pass
        
        if not primary and results:
            # Find highest confidence result
            confidents = [r for r in results if r.confidence >= 0.5]
            if confidents:
                primary = max(confidents, key=lambda r: (r.confidence, r.priority))
                primary_reason = primary.reason
        
        return {
            "position": context.position,
            "character": context.current_char(),
            "is_boundary": True,  # Will be determined by finalize
            "confidence": primary.confidence if primary else 0.5,
            "primary_rule_id": primary.rule_id if primary else None,
            "primary_reason": primary_reason,
            "all_rules": [{"rule_id": r.rule_id, "verdict": r.verdict.value, 
                        "confidence": r.confidence, "reason": r.reason} 
                       for r in results],
            "before_context": context.window_before(20),
            "after_context": context.window_after(20),
        }
    
    def __len__(self) -> int:
        return len(self.rules)
    
    def __repr__(self) -> str:
        enabled = len(self.get_enabled_rules())
        return f"RulesEngine(language={self.language}, rules={enabled} enabled)"