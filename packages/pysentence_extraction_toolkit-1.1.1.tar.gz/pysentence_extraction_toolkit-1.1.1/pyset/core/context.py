"""PySET Context.

Provides context and position information for rule evaluation.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, Any

if TYPE_CHECKING:
    from typing import Optional, List

WORD_RE = re.compile(r'\b\w+\b')
PUNCT_RE = re.compile(r'[.!?;:,)\]}>"\']')


@dataclass
class Context:
    """Provides context for rule evaluation at a text position."""
    
    text: str
    position: int
    abbreviations: set = field(default_factory=set)
    _cache: Dict = field(default_factory=dict, compare=False, hash=False)
    
    def current_char(self) -> "Optional[str]":
        if 0 <= self.position < len(self.text):
            return self.text[self.position]
        return None
    
    def next_char(self, offset: int = 1) -> "Optional[str]":
        pos = self.position + offset
        if 0 <= pos < len(self.text):
            return self.text[pos]
        return None
    
    def prev_char(self, offset: int = 1) -> "Optional[str]":
        pos = self.position - offset
        if 0 <= pos < len(self.text):
            return self.text[pos]
        return None
    
    def current_word(self) -> str:
        start = self.position
        end = self.position
        while start > 0 and re.match(r'\w', self.text[start - 1]):
            start -= 1
        while end < len(self.text) - 1 and re.match(r'\w', self.text[end + 1]):
            end += 1
        return self.text[start:end + 1]
    
    def next_word(self) -> "Optional[str]":
        if '_next_word' not in self._cache:
            remaining = self.text[self.position + 1:]
            match = WORD_RE.search(remaining)
            self._cache['_next_word'] = match.group() if match else None
        return self._cache['_next_word']
    
    def prev_word(self) -> "Optional[str]":
        if '_prev_word' not in self._cache:
            before = self.text[:self.position]
            matches = list(WORD_RE.finditer(before))
            self._cache['_prev_word'] = matches[-1].group() if matches else None
        return self._cache['_prev_word']
    
    def _peek_char(self, offset: int = 1) -> "Optional[str]":
        """Quick peek without caching."""
        pos = self.position + offset
        if 0 <= pos < len(self.text):
            return self.text[pos]
        return None
    
    def window_before(self, size: int = 30) -> str:
        start = max(0, self.position - size)
        return self.text[start:self.position]
    
    def window_after(self, size: int = 30) -> str:
        end = min(len(self.text), self.position + size + 1)
        return self.text[self.position + 1:end]
    
    def window_around(self, size: int = 30) -> str:
        start = max(0, self.position - size)
        end = min(len(self.text), self.position + size + 1)
        return self.text[start:end]
    
    def is_abbreviation(self, word: str) -> bool:
        clean = word.rstrip('.')
        return clean in self.abbreviations or word in self.abbreviations
    
    def has_matching_paren(self, open_char: str = '(', close_char: str = ')') -> bool:
        before = self.text[:self.position]
        count = 0
        for char in reversed(before):
            if char == close_char:
                count += 1
            elif char == open_char:
                if count > 0:
                    count -= 1
                else:
                    return True
            elif char in '([{<':
                break
        return False
    
    def line_number(self) -> int:
        return self.text[:self.position].count('\n') + 1
    
    def column_number(self) -> int:
        line_start = self.text.rfind('\n', 0, self.position)
        if line_start < 0:
            return self.position + 1
        return self.position - line_start
    
    def at_text_start(self) -> bool:
        return self.position == 0
    
    def at_text_end(self) -> bool:
        return self.position >= len(self.text) - 1
    
    def is_whitespace_after(self) -> bool:
        after = self.text[self.position + 1:]
        return len(after) > 0 and after[0].isspace()
    
    def is_uppercase_after(self, count: int = 1) -> bool:
        after = self.text[self.position + 1:].lstrip()
        if not after:
            return False
        return after[:count].isupper() if count == 1 else after[0].isupper()
    
    def is_digit_after(self) -> bool:
        next_c = self.next_char()
        return next_c is not None and next_c.isdigit()
    
    def is_letter_after(self) -> bool:
        next_c = self.next_char()
        return next_c is not None and next_c.isalpha()
    
    def get_remaining(self) -> str:
        return self.text[self.position + 1:]
    
    def get_preceding(self) -> str:
        return self.text[:self.position]