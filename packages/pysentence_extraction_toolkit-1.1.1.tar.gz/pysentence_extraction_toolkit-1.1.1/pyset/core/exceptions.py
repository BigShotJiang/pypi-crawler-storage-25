"""PySET Exceptions.

Custom exception hierarchy for PySET.
"""


class PySETException(Exception):
    """Base exception for all PySET errors."""
    
    def __init__(self, message: str = "PySET Error", **kwargs):
        self.message = message
        self.extra = kwargs
        super().__init__(self.message)


class ConfigurationError(PySETException):
    """Raised when configuration is invalid."""
    pass


class RuleError(PySETException):
    """Raised when a rule evaluation fails."""
    pass


class PreprocessingError(PySETException):
    """Raised when text preprocessing fails."""
    pass


class LanguageError(PySETException):
    """Raised when language is not supported or fails to load."""
    pass


class ValidationError(PySETException):
    """Raised when output validation fails."""
    pass


class PerformanceError(PySETException):
    """Raised when processing exceeds time/memory limits."""
    pass