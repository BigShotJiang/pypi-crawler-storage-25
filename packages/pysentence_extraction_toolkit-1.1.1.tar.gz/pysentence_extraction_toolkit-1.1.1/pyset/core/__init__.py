"""Core module init."""
from .exceptions import (
    PySETException,
    ConfigurationError,
    RuleError,
    PreprocessingError,
    LanguageError,
    ValidationError,
    PerformanceError,
)
from .rule import Rule, RuleResult, Verdict, BoundaryDecision
from .context import Context
from .rules_engine import RulesEngine

__all__ = [
    "PySETException",
    "ConfigurationError", 
    "RuleError",
    "PreprocessingError",
    "LanguageError",
    "ValidationError",
    "PerformanceError",
    "Rule",
    "RuleResult", 
    "Verdict",
    "BoundaryDecision",
    "Context",
    "RulesEngine",
]