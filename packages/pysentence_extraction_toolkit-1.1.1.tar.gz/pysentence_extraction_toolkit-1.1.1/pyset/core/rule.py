"""PySET Rule Base.

Abstract base class for all rules and result types.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Dict, Optional, Any

if TYPE_CHECKING:
    from .context import Context


class Verdict(Enum):
    """Possible rule verdicts for boundary decision."""
    BOUNDARY = "boundary"
    NOT_BOUNDARY = "not_boundary"
    UNCERTAIN = "uncertain"


@dataclass
class RuleResult:
    """Result of evaluating a single rule."""
    rule_id: int
    verdict: Verdict
    confidence: float  # 0.0 to 1.0
    reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __lt__(self, other: RuleResult) -> bool:
        """Sort by priority handled by rule, not result."""
        return False


@dataclass
class BoundaryDecision:
    """Final decision for a boundary position."""
    is_boundary: bool
    confidence: float
    contributing_rules: list[RuleResult] = field(default_factory=list)
    primary_reason: str = ""
    all_reasons: list[str] = field(default_factory=list)
    
    @property
    def rule_ids(self) -> list[int]:
        return [r.rule_id for r in self.contributing_rules]


class Rule(ABC):
    """Abstract base class for all sentence boundary rules.
    
    Each rule must implement evaluate() and return a RuleResult.
    Rules are sorted by priority (higher = evaluated first).
    """
    
    id: int = 0
    category: str = ""
    priority: int = 50  # 1-100, higher = more important
    enabled: bool = True
    
    @abstractmethod
    def evaluate(self, context: Context) -> RuleResult:
        """Evaluate if current position is a boundary.
        
        Args:
            context: Context object with text position info
            
        Returns:
            RuleResult with verdict, confidence, and reason
        """
        pass
    
    def __lt__(self, other: Rule) -> bool:
        """Sort by priority (higher priority first)."""
        if self.priority != other.priority:
            return self.priority > other.priority
        return self.id < other.id
    
    def __repr__(self) -> str:
        return f"Rule{self.id}({self.category}, priority={self.priority})"
    
    @property
    def name(self) -> str:
        return self.__class__.__name__