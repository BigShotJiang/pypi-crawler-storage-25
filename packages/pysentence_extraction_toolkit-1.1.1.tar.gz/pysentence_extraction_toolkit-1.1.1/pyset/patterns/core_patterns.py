"""Core Patterns - Basic punctuation patterns."""

import re

# Core punctuation patterns
PERIOD = re.compile(r'\.')
EXCLAMATION = re.compile(r'!')
QUESTION = re.compile(r'\?')
MULTI_PUNCT = re.compile(r'[.!?]{2,}')

# Ellipsis pattern
ELLIPSIS = re.compile(r'\.{3,}')

# Sentence boundary patterns
SENTENCE_END = re.compile(r'[.!?]')
SENTENCE_END_WITH_SPACE = re.compile(r'[.!?]\s+')

# Quote patterns
SINGLE_QUOTE = re.compile(r"'")
DOUBLE_QUOTE = re.compile(r'"')

# Newline patterns
NEWLINE = re.compile(r'\n')
MULTI_NEWLINE = re.compile(r'\n{2,}')

# Whitespace patterns
WHITESPACE = re.compile(r'\s+')
SPACE = re.compile(r' ')

# Unicode punctuation categories
UNICODE_PUNCT = re.compile(r'[\u2000-\u206F\u2E00-\u2E7F]')  # General punctuation


class CorePatterns:
    """Core punctuation patterns."""
    
    PERIOD = re.compile(r'\.')
    EXCLAMATION = re.compile(r'!')
    QUESTION = re.compile(r'\?')
    ELLIPSIS = re.compile(r'\.{3,}')
    SENTENCE_END = re.compile(r'[.!?]')
    SINGLE_QUOTE = re.compile(r"'")
    DOUBLE_QUOTE = re.compile(r'"')
    
    @staticmethod
    def is_sentence_ender(char: str) -> bool:
        return char in '.!?'