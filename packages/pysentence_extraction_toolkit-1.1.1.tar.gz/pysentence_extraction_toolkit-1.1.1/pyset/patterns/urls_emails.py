"""URL and Email Patterns."""

import re

# Email addresses
EMAIL_PATTERN = re.compile(
    r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
)

# HTTP/HTTPS URLs
HTTP_URL_PATTERN = re.compile(r'https?://[^\s]+')

# FTP URLs
FTP_URL_PATTERN = re.compile(r'ftps?://[^\s]+')

# URL with parameters
URL_WITH_PARAMS = re.compile(r'https?://[^\s?]+[?][^\s]+')

# URL fragments
URL_FRAGMENT = re.compile(r'#[a-zA-Z0-9_-]+')

# Domain pattern (for checking periods in domains)
DOMAIN_PATTERN = re.compile(r'[a-zA-Z0-9-]+\.[a-zA-Z]{2,}')

# Windows file path
WINDOWS_PATH_PATTERN = re.compile(r'[A-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*')

# Unix file path
UNIX_PATH_PATTERN = re.compile(r'(?:/[a-zA-Z0-9._-]+)+')

# Email in angle brackets <user@domain>
EMAIL_BRACKET_PATTERN = re.compile(r'<[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}>')

# Inline code (backticks)
INLINE_CODE_PATTERN = re.compile(r'`[^`]+`')


class URLEmailPatterns:
    """URL and email patterns."""
    
    EMAIL = EMAIL_PATTERN
    HTTP_URL = HTTP_URL_PATTERN
    FTP_URL = FTP_URL_PATTERN
    URL_WITH_PARAMS = URL_WITH_PARAMS
    URL_FRAGMENT = URL_FRAGMENT
    DOMAIN = DOMAIN_PATTERN
    WINDOWS_PATH = WINDOWS_PATH_PATTERN
    UNIX_PATH = UNIX_PATH_PATTERN
    EMAIL_BRACKET = EMAIL_BRACKET_PATTERN
    INLINE_CODE = INLINE_CODE_PATTERN
    
    @staticmethod
    def is_email(text: str) -> bool:
        return bool(EMAIL_PATTERN.fullmatch(text))
    
    @staticmethod
    def is_url(text: str) -> bool:
        return bool(HTTP_URL_PATTERN.match(text)) or bool(FTP_URL_PATTERN.match(text))