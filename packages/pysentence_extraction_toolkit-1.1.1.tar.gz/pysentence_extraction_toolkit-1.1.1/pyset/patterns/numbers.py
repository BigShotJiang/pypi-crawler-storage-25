"""Number Patterns."""

import re

# Decimal numbers
DECIMAL_PATTERN = re.compile(r'\d+\.\d+')

# Currency patterns
CURRENCY_PATTERN = re.compile(r'[$€£¥₹]\s*\d+(?:,\d{3})*(?:\.\d+)?')

# Version numbers
VERSION_PATTERN = re.compile(r'v?\d+\.\d+(?:\.\d+)?')

# IP addresses
IP_PATTERN = re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')

# Dates with periods (various formats)
DATE_PATTERN = re.compile(r'\d{1,2}\.\d{1,2}(?:\.\d{2,4})?|\d{4}\.\d{2}\.\d{2}')

# Times with periods
TIME_PATTERN = re.compile(r'\d{1,2}:\d{2}(?:\s*[AP]M)?')

# Percentages
PERCENT_PATTERN = re.compile(r'\d+(?:\.\d+)?%')

# Ratios and fractions
RATIO_PATTERN = re.compile(r'\d+:\d+')
FRACTION_PATTERN = re.compile(r'\d+/\d+')

# Large numbers formatting (1,234.56)
LARGE_NUMBER_PATTERN = re.compile(r'\d{1,3}(?:,\d{3})*(?:\.\d+)?')

# Single digit before period (like chapter numbers "1.2")
SINGLE_DIGIT_DECIMAL = re.compile(r'\b\d\.\d')

# Initials pattern (J. R. R. Tolkien)
INITIALS_PATTERN = re.compile(r'\b[A-Z]\.\s*[A-Z]\.')

# Phone numbers
PHONE_PATTERN = re.compile(r'\+?\d{1,3}[-.\s]?\d{2,4}[-.\s]?\d{2,4}')


class NumberPatterns:
    """Number patterns."""
    
    DECIMAL = DECIMAL_PATTERN
    CURRENCY = CURRENCY_PATTERN
    VERSION = VERSION_PATTERN
    IP = IP_PATTERN
    DATE = DATE_PATTERN
    TIME = TIME_PATTERN
    PERCENT = PERCENT_PATTERN
    RATIO = RATIO_PATTERN
    FRACTION = FRACTION_PATTERN
    LARGE_NUMBER = LARGE_NUMBER_PATTERN
    INITIALS = INITIALS_PATTERN
    PHONE = PHONE_PATTERN
    
    @staticmethod
    def is_decimal(text: str) -> bool:
        """Check if text is a decimal number."""
        return bool(DECIMAL_PATTERN.match(text))
    
    @staticmethod
    def is_ip_address(text: str) -> bool:
        """Check if text is an IP address."""
        return bool(IP_PATTERN.match(text))