"""Abbreviation Patterns."""

import re

# Title abbreviations
TITLE_PATTERN = re.compile(
    r'\b(Mr|Mrs|Ms|Dr|Prof|Rev|Sr|Jr|St|Ave|Blvd|Rd|Hon|Sen|Rep|Gov|Capt|Maj|Gen|Col|Lt|Cm|Sgt)\.',
    re.IGNORECASE
)

# Academic titles
ACADEMIC_PATTERN = re.compile(
    r'\b(Ph\.?D\.?|M\.?D\.?|D\.?D\.?S\.?|D\.?V\.?M\.?|J\.?D\.?|M\.?B\.?A\.?|M\.?S\.?|B\.?A\.?)\.?',
    re.IGNORECASE
)

# Business suffixes
BUSINESS_PATTERN = re.compile(
    r'\b(Inc|Ltd|Corp|Co|LLC|LLP|PLC|Holdings|Group|Partners|Corp\.)\.',
    re.IGNORECASE
)

# Place abbreviations
PLACE_PATTERN = re.compile(
    r'\b(St|Ave|Blvd|Rd|Dr|Ct|Pl|Way)\.?',
    re.IGNORECASE
)

# US states (two-letter abbreviations)
US_STATE_PATTERN = re.compile(
    r'\b(AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY)\b'
)

# Month abbreviations
MONTH_PATTERN = re.compile(
    r'\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?',
    re.IGNORECASE
)

# Day abbreviations
DAY_PATTERN = re.compile(
    r'\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\.?',
    re.IGNORECASE
)

# Common Latin phrases
LATIN_PATTERN = re.compile(
    r'\b(et al|i\.e|e\.g|etc|vs|viz|cf)\.',
    re.IGNORECASE
)

# Ordinal numbers
ORDINAL_PATTERN = re.compile(r'\b(\d+)(st|nd|rd|th)\b', re.IGNORECASE)

# Common acronyms (all caps, 2+ letters)
ACRONYM_PATTERN = re.compile(r'\b([A-Z]{2,})\b')


class AbbreviationPatterns:
    """Abbreviation patterns."""
    
    TITLE = TITLE_PATTERN
    ACADEMIC = ACADEMIC_PATTERN
    BUSINESS = BUSINESS_PATTERN
    PLACE = PLACE_PATTERN
    MONTH = MONTH_PATTERN
    DAY = DAY_PATTERN
    LATIN = LATIN_PATTERN
    ORDINAL = ORDINAL_PATTERN
    ACRONYM = ACRONYM_PATTERN
    
    # Known abbreviations set (for faster lookup)
    COMMON_ABBREVS = {
        'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Rev', 'Sr', 'Jr', 'St',
        'Inc', 'Ltd', 'Corp', 'Co', 'Ave', 'Blvd', 'Rd', 'Dr',
        'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun',
    }