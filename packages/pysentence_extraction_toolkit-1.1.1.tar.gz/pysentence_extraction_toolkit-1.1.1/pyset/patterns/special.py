"""Special Character Patterns."""

import re

# Em-dash
EM_DASH = re.compile(r'—')

# En-dash
EN_DASH = re.compile(r'–')

# All Unicode dashes
UNICODE_DASHES = re.compile(r'[–—―]')

# Bullet points (various)
BULLET_PATTERN = re.compile(r'^\s*[\u2022\u2023\u2043\u25E6\u25CF\u25CB\u2192\u2194\u27A4\u2794\u2795\u2796\u27A1\u27A2\u27A3]')

# Numbered list (1. 2. etc)
NUMBERED_LIST = re.compile(r'^\s*\d+\.\s')

# Hyphenated words
HYPHENATED = re.compile(r'\b\w+-\w+(?:-\w+)*\b')

# Footnote marker (superscript numbers)
FOOTNOTE = re.compile(r'\s[\u2070\u00B2\u00B3\u00B9\u2074-\u2079\u2080-\u2089]')

# Markdown emphasis (*text* **text**)
MARKDOWN_EMPHASIS = re.compile(r'\*[^*]+\*')

# Markdown bold (**text**)
MARKDOWN_BOLD = re.compile(r'\*\*[^*]+\*\*')

# Markdown headers (# ## etc)
MARKDOWN_HEADER = re.compile(r'^#{1,6}\s+.+$', re.MULTILINE)

# HTML tags
HTML_TAG = re.compile(r'<[/]?[a-zA-Z][^>]*>')

# XML tags
XML_TAG = re.compile(r'<[?][a-zA-Z][^>]*[?]?>')

# Chemical formulas
CHEMICAL_PATTERN = re.compile(r'\b[A-Z][a-z]?\d*[A-Z][a-z]?\d*\b')

# Mathematical operators
MATH_OPS = re.compile(r'[\+\-\*/=<>≤≥≠±∓×÷√∫∂∑∏π]')


class SpecialPatterns:
    """Special character patterns."""
    
    EM_DASH = EM_DASH
    EN_DASH = EN_DASH
    UNICODE_DASHES = UNICODE_DASHES
    BULLET = BULLET_PATTERN
    NUMBERED_LIST = NUMBERED_LIST
    HYPHENATED = HYPHENATED
    FOOTNOTE = FOOTNOTE
    MARKDOWN_EMPHASIS = MARKDOWN_EMPHASIS
    MARKDOWN_BOLD = MARKDOWN_BOLD
    MARKDOWN_HEADER = MARKDOWN_HEADER
    HTML_TAG = HTML_TAG
    CHEMICAL = CHEMICAL_PATTERN
    
    @staticmethod
    def is_ellipsis(text: str) -> bool:
        return bool(re.search(r'\.{3,}', text))
    
    @staticmethod
    def is_hyphenated(text: str) -> bool:
        return bool(HYPHENATED.search(text))