"""PySET - Python Sentence Boundary Tokenizer

A high-accuracy, zero-dependency Python library for sentence boundary detection.
"""

from .tokenizer import TokenBoundaryDetector, split
from .core.exceptions import (
    PySETException,
    ConfigurationError,
    RuleError,
    PreprocessingError,
    LanguageError,
    ValidationError,
    PerformanceError,
)
from .languages.language_registry import LanguageRegistry
from .version import __version__

__all__ = [
    "TokenBoundaryDetector",
    "split",
    "PySETException",
    "ConfigurationError", 
    "RuleError",
    "PreprocessingError",
    "LanguageError",
    "ValidationError",
    "PerformanceError",
    "LanguageRegistry",
    "__version__",
]