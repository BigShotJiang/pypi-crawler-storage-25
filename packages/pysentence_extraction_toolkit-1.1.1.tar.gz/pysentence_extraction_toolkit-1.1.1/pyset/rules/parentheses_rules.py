"""Rules 46-55: Parentheses and Brackets Rules.

Rules for handling brackets and parentheses boundaries.
"""

from __future__ import annotations

from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


# Rule 46: Closing Parenthesis
class Rule46CloseParen(Rule):
    """Rule 46: Closing parenthesis ) boundaries."""
    id = 46
    category = "PARENTHESES"
    priority = 80
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ')':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing paren")
        
        # Check if there's a matching opening paren
        if context.has_matching_paren('(', ')'):
            return RuleResult(self.id, Verdict.BOUNDARY, 0.85, "Closing paren - complete")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Unmatched closing paren")


# Rule 47: Closing Square Bracket
class Rule47CloseBracket(Rule):
    """Rule 47: Closing square bracket ]"""
    id = 47
    category = "PARENTHESES"
    priority = 80
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ']':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing bracket")
        
        if context.has_matching_paren('[', ']'):
            return RuleResult(self.id, Verdict.BOUNDARY, 0.85, "Closing bracket")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Unmatched bracket")


# Rule 48: Closing Curly Brace
class Rule48CloseBrace(Rule):
    """Rule 48: Closing curly brace }"""
    id = 48
    category = "PARENTHESES"
    priority = 80
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '}':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing brace")
        
        if context.has_matching_paren('{', '}'):
            return RuleResult(self.id, Verdict.BOUNDARY, 0.85, "Closing brace")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Unmatched brace")


# Rule 49: Closing Angle Bracket
class Rule49CloseAngle(Rule):
    """Rule 49: Closing angle bracket >"""
    id = 49
    category = "PARENTHESES"
    priority = 75
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '>':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing angle")
        
        if context.has_matching_paren('<', '>'):
            return RuleResult(self.id, Verdict.BOUNDARY, 0.80, "Closing angle bracket")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Unmatched angle")


# Rule 50: Nested Brackets
class Rule50NestedBracket(Rule):
    """Rule 50: Nested bracket handling."""
    id = 50
    category = "PARENTHESES"
    priority = 85
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        
        if char not in ')]}>':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No bracket")
        
        bracket_map = {')': '(', ']': '[', '}': '{', '>': '<'}
        close_char = char
        open_char = bracket_map[char]
        
        # Count brackets before to determine nesting depth
        before = context.window_before(size=50)
        open_count = before.count(open_char)
        close_count = before.count(close_char)
        
        if open_count > close_count:
            return RuleResult(
                self.id, Verdict.UNCERTAIN, 0.85,
                f"Nested bracket depth: {open_count - close_count}"
            )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not nested")


# Rule 51: Unmatched Closing Brackets
class Rule51UnmatchedClose(Rule):
    """Rule 51: Unmatched closing brackets."""
    id = 51
    category = "PARENTHESES"
    priority = 70
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        
        if char not in ')]}>':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No bracket")
        
        bracket_map = {')': '(', ']': '[', '}': '{', '>': '<'}
        open_char = bracket_map[char]
        
        before = context.window_before(size=30)
        
        if open_char not in before:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.6, "Unmatched closing bracket")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Matched bracket")


# Rule 52: Opening Bracket at End
class Rule52OpenAtEnd(Rule):
    """Rule 52: Opening brackets at sentence end."""
    id = 52
    category = "PARENTHESES"
    priority = 65
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        
        if char not in '([{<':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No opening bracket")
        
        after = context.window_after(size=30)
        
        # If nothing after the opening, it's a dangling bracket
        if not after.strip():
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Opening bracket at end")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Bracket mid-sentence")


# Rule 53: Citations in Brackets
class Rule53Citation(Rule):
    """Rule 53: Citations in brackets [1], [2]."""
    id = 53
    category = "PARENTHESES"
    priority = 75
    
    CITATION_PATTERN = npats = r'\[\d+\]'
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ']':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No bracket")
        
        # Check for citation pattern
        before = context.window_before(size=10)
        
        # Simple check for [digit]
        import re
        if '[' in before:
            # Check if it's a citation
            match = re.search(r'\[\d+\]', before)
            if match:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.75,
                    "Citation in brackets"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not citation")


# Rule 54: Footnotes in Brackets
class Rule54Footnote(Rule):
    """Rule 54: Footnotes in brackets."""
    id = 54
    category = "PARENTHESES"
    priority = 70
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ']':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No bracket")
        
        before = context.window_before(size=15)
        
        # Footnote patterns: [*], [**], [fn]
        import re
        if re.search(r'\[[*\w+]', before):
            return RuleResult(
                self.id, Verdict.NOT_BOUNDARY, 0.70,
                "Footnote marker"
            )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not footnote")


# Rule 55: Abbreviations in Brackets
class Rule55AbbrevBracket(Rule):
    """Rule 55: Abbreviations in brackets."""
    id = 55
    category = "PARENTHESES"
    priority = 75
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ']':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No bracket")
        
        before = context.window_before(size=20)
        
        # Check for abbreviation in brackets
        import re
        abbrev_pattern = r'\[(?:Mr|Mrs|Ms|Dr|Prof|Inc|Ltd|St|Ave)\]'
        
        if re.search(abbrev_pattern, before, re.IGNORECASE):
            return RuleResult(
                self.id, Verdict.NOT_BOUNDARY, 0.75,
                "Abbreviation in brackets"
            )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not abbreviation in brackets")


__all__ = [
    'Rule46CloseParen', 'Rule47CloseBracket', 'Rule48CloseBrace',
    'Rule49CloseAngle', 'Rule50NestedBracket', 'Rule51UnmatchedClose',
    'Rule52OpenAtEnd', 'Rule53Citation', 'Rule54Footnote',
    'Rule55AbbrevBracket',
]