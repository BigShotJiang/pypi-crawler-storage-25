"""Special Rules 66-75."""

from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


class Rule66EllipsisEnd(Rule):
    id = 66
    category = "SPECIAL"
    priority = 75
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        count = 0
        pos = context.position
        while pos < len(context.text) and context.text[pos] == '.':
            count += 1
            pos += 1
        if count >= 3:
            after = context.window_after(20).lstrip()
            if not after:
                return RuleResult(self.id, Verdict.BOUNDARY, 0.80, "Ellipsis end" + "")
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.75, "Ellipsis" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule67DashVariant(Rule):
    id = 67
    category = "SPECIAL"
    priority = 70
    
    def evaluate(self, context):
        c = context.current_char()
        if c == '—':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Em-dash" + "")
        if c == '–':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.65, "En-dash" + "")
        if c == '-':
            b = context.prev_char()
            a = context.next_char()
            if b == '-' and a == '-':
                return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Double dash" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No dash" + "")


class Rule68Hyphenated(Rule):
    id = 68
    category = "SPECIAL"
    priority = 85
    
    def evaluate(self, context):
        if context.current_char() != '-':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No hyphen" + "")
        before = context.window_before(10)
        after = context.window_after(10)
        if before and before[-1].isalnum() and after and after[0].isalnum():
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.85, "Hyphenated" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule69Footnote(Rule):
    id = 69
    category = "SPECIAL"
    priority = 65
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '\u2070\u00B2\u00B3\u00B9\u2074\u2075\u2076\u2077\u2078\u2079':
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.65, "Footnote" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No" + "")


class Rule70Superscript(Rule):
    id = 70
    category = "SPECIAL"
    priority = 60
    
    def evaluate(self, context):
        c = context.current_char()
        if '\u2070' <= c <= '\u2099':
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.60, "Superscript" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No" + "")


class Rule71LineStartAbbrev(Rule):
    id = 71
    category = "SPECIAL"
    priority = 70
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        before = context.window_before(10)
        if '\n' in before or context.position == 0:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.4, "Line start" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule72MultiplePeriods(Rule):
    id = 72
    category = "SPECIAL"
    priority = 80
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        count = 0
        pos = context.position
        while pos < len(context.text) and context.text[pos] == '.':
            count += 1
            pos += 1
        if count >= 3:
            return RuleResult(self.id, Verdict.BOUNDARY, 0.80, "Multiple" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule73UnicodeDash(Rule):
    id = 73
    category = "SPECIAL"
    priority = 75
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '-–—―':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.75, f"Unicode dash {ord(c)}" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No" + "")


class Rule74Bullet(Rule):
    id = 74
    category = "SPECIAL"
    priority = 70
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '\u2022\u2023\u2043\u25CF\u25CB*•':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Bullet" + "")
        if c == '*':
            before = context.window_before(5).lstrip()
            if '\n' in before or not before:
                return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Asterisk" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule75NumberedList(Rule):
    id = 75
    category = "SPECIAL"
    priority = 70
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        import re
        before = context.window_before(5)
        if re.match(r'\d+\.\s*$', before):
            return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Numbered list" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")