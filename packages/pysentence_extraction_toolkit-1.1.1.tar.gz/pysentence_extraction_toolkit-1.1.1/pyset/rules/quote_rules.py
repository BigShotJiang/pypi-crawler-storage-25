"""Quote Rules 36-45."""

from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


class Rule36SingleQuote(Rule):
    id = 36
    category = "QUOTE"
    priority = 70
    
    def evaluate(self, context):
        if context.current_char() != "'":
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No quote" + "")
        before = context.prev_char()
        if before and before.isalnum():
            after = context.window_after(3)
            if after and after[0] in ' .!?,':
                return RuleResult(self.id, Verdict.BOUNDARY, 0.75, "Closing" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Uncertain" + "")


class Rule37DoubleQuote(Rule):
    id = 37
    category = "QUOTE"
    priority = 70
    
    def evaluate(self, context):
        if context.current_char() != '"':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No quote" + "")
        before = context.prev_char()
        if before and before.isalnum():
            after = context.window_after(3)
            if after and after[0] in ' .!?,':
                return RuleResult(self.id, Verdict.BOUNDARY, 0.75, "Closing" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Uncertain" + "")


class Rule38SmartQuote(Rule):
    id = 38
    category = "QUOTE"
    priority = 75
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '\u2019\u201D':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.80, "Smart close" + "")
        if c in '\u2018\u201C':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Smart open" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No smart" + "")


class Rule39DialogueTag(Rule):
    id = 39
    category = "QUOTE"
    priority = 75
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        after = context.window_after(15)
        import re
        words = re.findall(r'\b\w+\b', after.lower())
        if words and words[0] in ('said', 'asked', 'replied', 'whispered', 'shouted'):
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.75, "Dialogue" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No dialogue" + "")


class Rule40NestedQuote(Rule):
    id = 40
    category = "QUOTE"
    priority = 60
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '"\'':
            before = context.window_before(50)
            after = context.window_after(50)
            qb = before.count('"') + before.count("'")
            qa = after.count('"') + after.count("'")
            if qb > qa:
                return RuleResult(self.id, Verdict.BOUNDARY, 0.70, "Nested close" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No nested" + "")


class Rule41UnclosedOpen(Rule):
    id = 41
    category = "QUOTE"
    priority = 50
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '"\'':
            after = context.window_after(30)
            if '"' not in after and "'" not in after:
                return RuleResult(self.id, Verdict.UNCERTAIN, 0.4, "Unclosed" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "OK" + "")


class Rule42UnclosedClose(Rule):
    id = 42
    category = "QUOTE"
    priority = 50
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '"\'':
            before = context.window_before(30)
            if '"' not in before and "'" not in before:
                return RuleResult(self.id, Verdict.UNCERTAIN, 0.4, "Orphan" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "OK" + "")


class Rule43EmDashDialogue(Rule):
    id = 43
    category = "QUOTE"
    priority = 65
    
    def evaluate(self, context):
        if context.current_char() == '—':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.65, "Em-dash" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No em-dash" + "")


class Rule44EllipsisQuote(Rule):
    id = 44
    category = "QUOTE"
    priority = 60
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        before = context.window_before(20)
        after = context.window_after(20)
        has_ell = '..' in before or '..' in after
        in_quotes = '"' in before or "'" in before
        if has_ell and in_quotes:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.6, "Ellipsis quote" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No" + "")


class Rule45QuotePunct(Rule):
    id = 45
    category = "QUOTE"
    priority = 70
    
    def evaluate(self, context):
        c = context.current_char()
        if c in '"\'':
            n = context.next_char()
            if n in '.!?':
                return RuleResult(self.id, Verdict.BOUNDARY, 0.85, "Quote before punct" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No" + "")