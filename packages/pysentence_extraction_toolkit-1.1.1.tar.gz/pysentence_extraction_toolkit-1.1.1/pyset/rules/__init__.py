"""Rules module - all 85 rules."""

from .base_rules import (
    Rule1Period, Rule2Exclamation, Rule3Question,
    Rule4MultiplePunct, Rule5Ellipsis, Rule6EmDash,
    Rule7Semicolon, Rule8Colon, Rule9Newline,
    Rule10MultiSpace, Rule11Tab, Rule12QuoteEnd,
    Rule13ParenClose, Rule14BracketClose, Rule15UnicodePunct,
)

from .abbreviation_rules import (
    Rule16TitleAbbrev, Rule17AcademicTitle, Rule18BusinessSuffix,
    Rule19PlaceAbbrev, Rule20MonthAbbrev, Rule21DayAbbrev,
    Rule22USState, Rule23Ordinal, Rule24Acronyms, Rule25CustomAbbrev,
)

from .number_rules import (
    Rule26Decimal, Rule27Currency, Rule28Percentage,
    Rule29RatioFraction, Rule30Version, Rule31IPAddress,
    Rule32Date, Rule33Time, Rule34LargeNumber, Rule35Initials,
)

from .quote_rules import (
    Rule36SingleQuote, Rule37DoubleQuote, Rule38SmartQuote,
    Rule39DialogueTag, Rule40NestedQuote, Rule41UnclosedOpen,
    Rule42UnclosedClose, Rule43EmDashDialogue, Rule44EllipsisQuote,
    Rule45QuotePunct,
)

from .parentheses_rules import (
    Rule46CloseParen, Rule47CloseBracket, Rule48CloseBrace,
    Rule49CloseAngle, Rule50NestedBracket, Rule51UnmatchedClose,
    Rule52OpenAtEnd, Rule53Citation, Rule54Footnote,
    Rule55AbbrevBracket,
)

from .email_url_rules import (
    Rule56Email, Rule57HTTPSURL, Rule58FTPUrl,
    Rule59URLParams, Rule60URLFragment, Rule61DomainPeriod,
    Rule62WindowsPath, Rule63UnixPath, Rule64EmailAngleBracket,
    Rule65InlineCode,
)

from .special_rules import (
    Rule66EllipsisEnd, Rule67DashVariant, Rule68Hyphenated,
    Rule69Footnote, Rule70Superscript, Rule71LineStartAbbrev,
    Rule72MultiplePeriods, Rule73UnicodeDash, Rule74Bullet,
    Rule75NumberedList,
)

from .language_rules import (
    Rule76LatinPhrase, Rule77CommonAbbrev, Rule78Honorific,
    Rule79Emphasis, Rule80Markdown, Rule81HTMLTag,
    Rule82XMLTag, Rule83MathNotation, Rule84Chemical,
    Rule85CustomPattern,
)


ALL_RULES = [
    Rule1Period,
    Rule2Exclamation,
    Rule3Question,
    Rule4MultiplePunct,
    Rule5Ellipsis,
    Rule6EmDash,
    Rule7Semicolon,
    Rule8Colon,
    Rule9Newline,
    Rule10MultiSpace,
    Rule11Tab,
    Rule12QuoteEnd,
    Rule13ParenClose,
    Rule14BracketClose,
    Rule15UnicodePunct,
    Rule16TitleAbbrev,
    Rule17AcademicTitle,
    Rule18BusinessSuffix,
    Rule19PlaceAbbrev,
    Rule20MonthAbbrev,
    Rule21DayAbbrev,
    Rule22USState,
    Rule23Ordinal,
    Rule24Acronyms,
    Rule25CustomAbbrev,
    Rule26Decimal,
    Rule27Currency,
    Rule28Percentage,
    Rule29RatioFraction,
    Rule30Version,
    Rule31IPAddress,
    Rule32Date,
    Rule33Time,
    Rule34LargeNumber,
    Rule35Initials,
    Rule36SingleQuote,
    Rule37DoubleQuote,
    Rule38SmartQuote,
    Rule39DialogueTag,
    Rule40NestedQuote,
    Rule41UnclosedOpen,
    Rule42UnclosedClose,
    Rule43EmDashDialogue,
    Rule44EllipsisQuote,
    Rule45QuotePunct,
    Rule46CloseParen,
    Rule47CloseBracket,
    Rule48CloseBrace,
    Rule49CloseAngle,
    Rule50NestedBracket,
    Rule51UnmatchedClose,
    Rule52OpenAtEnd,
    Rule53Citation,
    Rule54Footnote,
    Rule55AbbrevBracket,
    Rule56Email,
    Rule57HTTPSURL,
    Rule58FTPUrl,
    Rule59URLParams,
    Rule60URLFragment,
    Rule61DomainPeriod,
    Rule62WindowsPath,
    Rule63UnixPath,
    Rule64EmailAngleBracket,
    Rule65InlineCode,
    Rule66EllipsisEnd,
    Rule67DashVariant,
    Rule68Hyphenated,
    Rule69Footnote,
    Rule70Superscript,
    Rule71LineStartAbbrev,
    Rule72MultiplePeriods,
    Rule73UnicodeDash,
    Rule74Bullet,
    Rule75NumberedList,
    Rule76LatinPhrase,
    Rule77CommonAbbrev,
    Rule78Honorific,
    Rule79Emphasis,
    Rule80Markdown,
    Rule81HTMLTag,
    Rule82XMLTag,
    Rule83MathNotation,
    Rule84Chemical,
    Rule85CustomPattern,
]


def get_all_rules():
    return ALL_RULES


def get_rule_by_id(rule_id):
    for rule in ALL_RULES:
        if rule.id == rule_id:
            return rule
    return None


__all__ = [
    'get_all_rules', 'get_rule_by_id',
]