"""Rules 1-15: Basic Patterns.

Basic punctuation rules for sentence boundary detection.
"""

from __future__ import annotations
import re
from typing import Optional

from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context
from ..patterns import CorePatterns


# Rule 1: Standard Period
class Rule1Period(Rule):
    """Rule 1: Standard period boundary.
    
    A period followed by uppercase typically indicates sentence boundary.
    """
    id = 1
    category = "BASIC"
    priority = 90
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        next_char = context.next_char()
        if next_char is None:
            # End of text - it's a boundary
            return RuleResult(self.id, Verdict.BOUNDARY, 0.95, "Period at end of text")
        
        if next_char.isspace():
            after_text = context.window_after(20).lstrip()
            if after_text and after_text[0].isupper():
                return RuleResult(
                    self.id, Verdict.BOUNDARY, 0.95, 
                    f"Period followed by uppercase: '{after_text[0]}'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Period followed by lowercase or unknown")


# Rule 2: Exclamation Mark
class Rule2Exclamation(Rule):
    """Rule 2: Exclamation mark boundary."""
    id = 2
    category = "BASIC"
    priority = 90
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char != '!':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No exclamation")
        
        return RuleResult(self.id, Verdict.BOUNDARY, 0.95, "Exclamation mark")


# Rule 3: Question Mark
class Rule3Question(Rule):
    """Rule 3: Question mark boundary."""
    id = 3
    category = "BASIC"
    priority = 90
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char != '?':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No question mark")
        
        return RuleResult(self.id, Verdict.BOUNDARY, 0.95, "Question mark")


# Rule 4: Multiple Punctuation
class Rule4MultiplePunct(Rule):
    """Rule 4: Multiple punctuation marks (?!, !?, ?!, !!, etc.)
    
    Multiple consecutive sentence-ending punctuation is always a boundary.
    """
    id = 4
    category = "BASIC"
    priority = 95
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char not in '.!?':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No punctuation")
        
        # Check for multiple
        pos = context.position
        count = 0
        while pos < len(context.text) and context.text[pos] in '.!?':
            count += 1
            pos += 1
        
        if count >= 2:
            return RuleResult(
                self.id, Verdict.BOUNDARY, 0.98,
                f"Multiple punctuation ({count} chars)"
            )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Single punctuation")


# Rule 5: Ellipsis
class Rule5Ellipsis(Rule):
    """Rule 5: Ellipsis (three or more dots).
    
    Three or more consecutive dots often indicate thought trails,
    not sentence boundaries.
    """
    id = 5
    category = "BASIC"
    priority = 70
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        # Check ahead for more periods
        pos = context.position
        count = 0
        text = context.text
        
        while pos < len(text) and text[pos] == '.':
            count += 1
            pos += 1
        
        if count >= 3:
            # Check context - ellipsis in middle of text
            before = context.prev_char()
            after = context.next_char()
            
            if before and before.isalpha() and after and after.isalpha():
                return RuleResult(
                    self.id, Verdict.BOUNDARY, 0.75, 
                    "Ellipsis in text"
                )
            elif after and after.isspace():
                return RuleResult(
                    self.id, Verdict.UNCERTAIN, 0.5,
                    "Ellipsis at end"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not ellipsis")


# Rule 6: Em-dash
class Rule6EmDash(Rule):
    """Rule 6: Em-dash boundaries."""
    id = 6
    category = "BASIC"
    priority = 65
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char == '—':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.7, "Em-dash")
        if char == '–':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.65, "En-dash")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No dash")


# Rule 7: Semicolon
class Rule7Semicolon(Rule):
    """Rule 7: Semicolon handling."""
    id = 7
    category = "BASIC"
    priority = 60
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ';':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No semicolon")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.6, "Semicolon - context dependent")


# Rule 8: Colon
class Rule8Colon(Rule):
    """Rule 8: Colon handling."""
    id = 8
    category = "BASIC"
    priority = 55
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ':':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No colon")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Colon - context dependent")


# Rule 9: Newline as boundary
class Rule9Newline(Rule):
    """Rule 9: Newline as sentence boundary."""
    id = 9
    category = "BASIC"
    priority = 75
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '\n':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No newline")
        
        return RuleResult(self.id, Verdict.BOUNDARY, 0.8, "Newline boundary")


# Rule 10: Multiple spaces
class Rule10MultiSpace(Rule):
    """Rule 10: Multiple spaces as boundary marker."""
    id = 10
    category = "BASIC"
    priority = 50
    
    def evaluate(self, context: Context) -> RuleResult:
        # Check if preceded by single space
        char = context.current_char()
        if char != ' ':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No space")
        
        # Multiple spaces handled elsewhere as sentence start markers
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.3, "Multiple spaces")


# Rule 11: Tab as boundary
class Rule11Tab(Rule):
    """Rule 11: Tab as sentence boundary."""
    id = 11
    category = "BASIC"
    priority = 50
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '\t':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No tab")
        
        return RuleResult(self.id, Verdict.BOUNDARY, 0.5, "Tab boundary")


# Rule 12: Quotation mark endings
class Rule12QuoteEnd(Rule):
    """Rule 12: Quotation mark endings."""
    id = 12
    category = "BASIC"
    priority = 65
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char not in '"\')':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No quote")
        
        # Check if followed by sentence-ending punctuation
        next_c = context.next_char()
        if next_c in '.!?':
            return RuleResult(
                self.id, Verdict.BOUNDARY, 0.75,
                f"Quote followed by {next_c}"
            )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Quote boundary uncertain")


# Rule 13: Parenthesis closings
class Rule13ParenClose(Rule):
    """Rule 13: Closing parenthesis."""
    id = 13
    category = "BASIC"
    priority = 60
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != ')':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing paren")
        
        # If completed sentence in parens, boundary after
        return RuleResult(self.id, Verdict.BOUNDARY, 0.6, "Closing paren")


# Rule 14: Bracket closings
class Rule14BracketClose(Rule):
    """Rule 14: Closing bracket."""
    id = 14
    category = "BASIC"
    priority = 60
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char not in ']>':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No closing bracket")
        
        return RuleResult(self.id, Verdict.BOUNDARY, 0.6, "Closing bracket")


# Rule 15: Unicode punctuation
class Rule15UnicodePunct(Rule):
    """Rule 15: Special Unicode punctuation."""
    id = 15
    category = "BASIC"
    priority = 65
    
    UNICODE_ENDERS = set('\uFF1E\uFF1F\u3002')  # ; for Japanese, ?
    
    def evaluate(self, context: Context) -> RuleResult:
        char = context.current_char()
        if char in self.UNICODE_ENDERS:
            return RuleResult(self.id, Verdict.BOUNDARY, 0.7, f"Unicode: {char}")
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No special unicode")


# Export all basic rules
__all__ = [
    'Rule1Period', 'Rule2Exclamation', 'Rule3Question',
    'Rule4MultiplePunct', 'Rule5Ellipsis', 'Rule6EmDash',
    'Rule7Semicolon', 'Rule8Colon', 'Rule9Newline',
    'Rule10MultiSpace', 'Rule11Tab', 'Rule12QuoteEnd',
    'Rule13ParenClose', 'Rule14BracketClose', 'Rule15UnicodePunct',
]