"""Email/URL Rules 56-65."""

import re
from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


class Rule56Email(Rule):
    id = 56
    category = "EMAIL_URL"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(30)
        if re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "Email" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule57HTTPSURL(Rule):
    id = 57
    category = "EMAIL_URL"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(40)
        if re.search(r'https?://[^\s]+', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "HTTP" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule58FTPUrl(Rule):
    id = 58
    category = "EMAIL_URL"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(40)
        if re.search(r'ftps?://[^\s]+', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "FTP" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule59URLParams(Rule):
    id = 59
    category = "EMAIL_URL"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '?':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No ?" + "")
        before = context.window_before(30)
        if '://' in before or 'http' in before.lower():
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.95, "URL param" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule60URLFragment(Rule):
    id = 60
    category = "EMAIL_URL"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '#':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No #" + "")
        before = context.window_before(20)
        if '://' in before:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.95, "Fragment" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule61DomainPeriod(Rule):
    id = 61
    category = "EMAIL_URL"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(10)
        if re.search(r'\w\.\w\.\w', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.98, "Domain" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule62WindowsPath(Rule):
    id = 62
    category = "EMAIL_URL"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '\\':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No \\" + "")
        before = context.window_before(5)
        if re.search(r'[A-Z]:\\', before):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Windows path" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule63UnixPath(Rule):
    id = 63
    category = "EMAIL_URL"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '/':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No /" + "")
        before = context.window_before(5)
        after = context.window_after(10)
        if '/' in before or context.position == 0:
            if after and re.match(r'/[^/\s]+', after):
                return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Unix path" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule64EmailAngleBracket(Rule):
    id = 64
    category = "EMAIL_URL"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '>':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No >" + "")
        window = context.window_around(25)
        if re.search(r'<[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}>', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Email bracket" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule65InlineCode(Rule):
    id = 65
    category = "EMAIL_URL"
    priority = 90
    
    def evaluate(self, context):
        if context.current_char() != '`':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No `" + "")
        window = context.window_around(30)
        if window.lstrip().startswith('`'):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.90, "Inline code" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")