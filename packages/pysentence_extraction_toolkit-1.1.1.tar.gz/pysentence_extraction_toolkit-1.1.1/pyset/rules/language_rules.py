"""Language Rules 76-85."""

import re
from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


class Rule76LatinPhrase(Rule):
    id = 76
    category = "LANGUAGE"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').lower()
            if clean in ('et al', 'i.e', 'e.g', 'etc', 'vs', 'fig', 'cf', 'viz'):
                return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Latin" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not Latin" + "")


class Rule77CommonAbbrev(Rule):
    id = 77
    category = "LANGUAGE"
    priority = 90
    
    COMMON = {'etc', 'vs', 'fig', 'approx', 'tel', 'no', 'mr', 'mrs', 'ms', 'dr', 'prof', 'rev', 'hon', 'sr', 'jr'}
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').lower()
            if clean in self.COMMON:
                return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.90, "Common" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not common" + "")


class Rule78Honorific(Rule):
    id = 78
    category = "LANGUAGE"
    priority = 85
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        before = context.window_before(20)
        words = re.findall(r'\b\w+\b', before.lower())
        if words and words[-1] in ('his', 'her', 'your', 'their'):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.85, "Honorific" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule79Emphasis(Rule):
    id = 79
    category = "LANGUAGE"
    priority = 70
    
    def evaluate(self, context):
        if context.current_char() != '*':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No *" + "")
        after = context.window_after(10)
        if after.count('*') >= 2:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.70, "Emphasis" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule80Markdown(Rule):
    id = 80
    category = "LANGUAGE"
    priority = 75
    
    def evaluate(self, context):
        if context.current_char() != '#':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No #" + "")
        before = context.window_before(5).lstrip()
        if '\n' in before or before == '':
            return RuleResult(self.id, Verdict.BOUNDARY, 0.75, "Header" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule81HTMLTag(Rule):
    id = 81
    category = "LANGUAGE"
    priority = 80
    
    def evaluate(self, context):
        if context.current_char() != '<':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No <" + "")
        after = context.window_after(15)
        if re.match(r'[^>]+>', after):
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.80, "HTML" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule82XMLTag(Rule):
    id = 82
    category = "LANGUAGE"
    priority = 75
    
    def evaluate(self, context):
        if context.current_char() != '<':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No <" + "")
        after = context.window_after(10)
        if after.startswith('?') or after.startswith('!'):
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.75, "XML" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule83MathNotation(Rule):
    id = 83
    category = "LANGUAGE"
    priority = 70
    
    MATH_OPS = {'+', '-', '=', '×', '÷', '±', '≤', '≥', '≠', '√'}
    
    def evaluate(self, context):
        c = context.current_char()
        if c in self.MATH_OPS:
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.70, "Math" + "")
        if c == '=':
            before = context.window_before(5)
            after = context.window_after(5)
            if before.strip() and after.strip():
                return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.70, "Equation" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule84Chemical(Rule):
    id = 84
    category = "LANGUAGE"
    priority = 65
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(10)
        if re.search(r'\b[A-Z][a-z]?\d*[A-Z][a-z]?\d*\b', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.65, "Chemical" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not" + "")


class Rule85CustomPattern(Rule):
    id = 85
    category = "LANGUAGE"
    priority = 60
    
    def __init__(self, patterns=None):
        super().__init__()
        self.patterns = patterns or []
    
    def evaluate(self, context):
        if not self.patterns:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No patterns" + "")
        window = context.window_around(20)
        for pat in self.patterns:
            try:
                if re.search(pat, window):
                    return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.80, "Custom" + "")
            except:
                pass
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No match" + "")