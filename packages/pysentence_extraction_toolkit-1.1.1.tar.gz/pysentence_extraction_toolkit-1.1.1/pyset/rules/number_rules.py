"""Number Rules 26-35."""

import re
from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


class Rule26Decimal(Rule):
    id = 26
    category = "NUMBER"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(10)
        if re.search(r'\d+\.\d+', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "Decimal" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not decimal" + "")


class Rule27Currency(Rule):
    id = 27
    category = "NUMBER"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(15)
        if re.search(r'[$€£¥₹]\s*\d+(?:,\d{3})*(?:\.\d+)?', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "Currency" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not currency" + "")


class Rule28Percentage(Rule):
    id = 28
    category = "NUMBER"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '%':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No percent" + "")
        return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Percentage" + "")


class Rule29RatioFraction(Rule):
    id = 29
    category = "NUMBER"
    priority = 90
    
    def evaluate(self, context):
        char = context.current_char()
        if char == ':' or char == '/':
            before = context.window_before(5)
            after = context.window_after(5)
            if before and before[-1].isdigit() and after and after[0].isdigit():
                return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.90, "Ratio/fraction" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not ratio/fraction" + "")


class Rule30Version(Rule):
    id = 30
    category = "NUMBER"
    priority = 95
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(10)
        if re.search(r'v?\d+\.\d+(\.\d+)?', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.95, "Version" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not version" + "")


class Rule31IPAddress(Rule):
    id = 31
    category = "NUMBER"
    priority = 98
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(20)
        if re.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.99, "IP address" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not IP" + "")


class Rule32Date(Rule):
    id = 32
    category = "NUMBER"
    priority = 90
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        window = context.window_around(15)
        if re.search(r'\d{1,2}\.\d{1,2}(?:\.\d{2,4})?', window):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.90, "Date" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not date" + "")


class Rule33Time(Rule):
    id = 33
    category = "NUMBER"
    priority = 90
    
    def evaluate(self, context):
        if context.current_char() != ':':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No colon" + "")
        window = context.window_around(10)
        if re.search(r'\d{1,2}:\d{2}(?:\s*[AP]M)?', window):
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.90, "Time" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not time" + "")


class Rule34LargeNumber(Rule):
    id = 34
    category = "NUMBER"
    priority = 85
    
    def evaluate(self, context):
        if context.current_char() != ',':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No comma" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.5, "Large number" + "")


class Rule35Initials(Rule):
    id = 35
    category = "NUMBER"
    priority = 85
    
    def evaluate(self, context):
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period" + "")
        after = context.window_after(5)
        if after and re.match(r'\s+([A-Z])\.', after):
            return RuleResult(self.id, Verdict.NOT_BOUNDARY, 0.85, "Initial" + "")
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not initial" + "")