"""Rules 16-25: Abbreviation Rules.

Rules for preventing false boundaries on abbreviations.
"""

from __future__ import annotations

from ..core.rule import Rule, RuleResult, Verdict
from ..core.context import Context


# Rule 16: Title Abbreviations (Mr., Mrs., Ms., Dr., etc.)
class Rule16TitleAbbrev(Rule):
    """Rule 16: Title abbreviations (Mr., Mrs., Ms., Dr., Prof., etc.)
    
    These are almost never sentence boundaries.
    Priority 100 (CRITICAL) - overrides basic period rule.
    """
    id = 16
    category = "ABBREVIATION"
    priority = 100  # CRITICAL
    
    TITLES = {'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Rev', 'Sr', 'Jr', 'St'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        # Check word before period
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.')
            if clean in self.TITLES:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.99,
                    f"Title abbreviation '{clean}.'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not title abbreviation")


# Rule 17: Academic Titles
class Rule17AcademicTitle(Rule):
    """Rule 17: Academic titles (Ph.D., M.D., etc.)"""
    id = 17
    category = "ABBREVIATION"
    priority = 95
    
    ACADEMIC = {'Ph', 'PhD', 'MD', 'DDS', 'DVM', 'JD', 'MBA', 'MS', 'BA', 'MA'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').upper()
            if clean in self.ACADEMIC:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.95,
                    f"Academic title '{clean}'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not academic title")


# Rule 18: Business Suffixes
class Rule18BusinessSuffix(Rule):
    """Rule 18: Business suffixes (Inc., Ltd., Corp., Co.)"""
    id = 18
    category = "ABBREVIATION"
    priority = 95
    
    BUSINESS = {'Inc', 'Ltd', 'Corp', 'Co', 'LLC', 'LLP', 'PLC'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').title()
            if clean in self.BUSINESS:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.95,
                    f"Business suffix '{clean}.'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not business suffix")


# Rule 19: Place Abbreviations
class Rule19PlaceAbbrev(Rule):
    """Rule 19: Place abbreviations (St., Ave., Blvd., Rd.)"""
    id = 19
    category = "ABBREVIATION"
    priority = 95
    
    PLACES = {'St', 'Ave', 'Blvd', 'Rd', 'Dr', 'Ct', 'Pl', 'Way'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.')
            if clean in self.PLACES:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.95,
                    f"Place abbreviation '{clean}.'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not place abbreviation")


# Rule 20: Month Abbreviations
class Rule20MonthAbbrev(Rule):
    """Rule 20: Month abbreviations (Jan., Feb., etc.)"""
    id = 20
    category = "ABBREVIATION"
    priority = 95
    
    MONTHS = {'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.')
            if clean in self.MONTHS:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.95,
                    f"Month abbreviation '{clean}.'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not month abbreviation")


# Rule 21: Day Abbreviations
class Rule21DayAbbrev(Rule):
    """Rule 21: Day abbreviations (Mon., Tue., etc.)"""
    id = 21
    category = "ABBREVIATION"
    priority = 90
    
    DAYS = {'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'}
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.')
            if clean in self.DAYS:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.90,
                    f"Day abbreviation '{clean}.'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not day abbreviation")


# Rule 22: US State Abbreviations
class Rule22USState(Rule):
    """Rule 22: US state abbreviations (CA, NY, TX, etc.)"""
    id = 22
    category = "ABBREVIATION"
    priority = 90
    
    STATES = {
        'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
        'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
        'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
        'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
        'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
    }
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').upper()
            if clean in self.STATES:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.90,
                    f"US state abbreviation '{clean}'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not US state abbreviation")


# Rule 23: Ordinal Numbers
class Rule23Ordinal(Rule):
    """Rule 23: Ordinal numbers (1st, 2nd, 3rd, etc.)"""
    id = 23
    category = "ABBREVIATION"
    priority = 85
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        prev = context.prev_word()
        if prev:
            # Check if ends with ordinal suffix
            clean = prev.lower()
            if clean.endswith(('st', 'nd', 'rd', 'th')) and clean[:-2].isdigit():
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.85,
                    f"Ordinal number '{prev}'"
                )
            # Check digit followed by st/nd/rd/th after period
            if clean and clean[-1].isdigit():
                next_w = context.next_word()
                if next_w and next_w.lower() in ('st', 'nd', 'rd', 'th'):
                    return RuleResult(
                        self.id, Verdict.NOT_BOUNDARY, 0.85,
                        "Ordinal number pattern"
                    )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not ordinal")


# Rule 24: Common Acronyms
class Rule24Acronyms(Rule):
    """Rule 24: Common acronyms (USA, FBI, NASA, etc.)"""
    id = 24
    category = "ABBREVIATION"
    priority = 90
    
    ACRONYMS = {
        'USA', 'UK', 'UN', 'EU', 'NATO', 'FBI', 'CIA', 'NASA', 'IRS', 'FDA',
        'CDC', 'WHO', 'WWI', 'WWII', 'ABC', 'CBS', 'NBC', 'BBC', 'CEO', 'CFO',
        'COO', 'UFO', 'URL', 'HTTP', 'HTTPS', 'FTP', 'TCP', 'IP', 'FAQ',
    }
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        # Check prev word (full acronym) or next word (acronym)
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').upper()
            if clean in self.ACRONYMS and len(clean) >= 2:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.90,
                    f"Acronym '{clean}'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not acronym abbreviation")


# Rule 25: Custom Abbreviations (user-provided)
class Rule25CustomAbbrev(Rule):
    """Rule 25: Custom abbreviations dictionary.
    
    User-provided abbreviations take highest priority.
    """
    id = 25
    category = "ABBREVIATION"
    priority = 90  # Override if needed
    
    CUSTOM_ABBREVS: set = set()
    
    def __init__(self, custom_abbrevs: set = None):
        super().__init__()
        if custom_abbrevs:
            self.CUSTOM_ABBREVS = custom_abbrevs
    
    def evaluate(self, context: Context) -> RuleResult:
        if context.current_char() != '.':
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No period")
        
        if not self.CUSTOM_ABBREVS:
            return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "No custom abbreviations")
        
        prev = context.prev_word()
        if prev:
            clean = prev.rstrip('.').upper()
            if clean in self.CUSTOM_ABBREVS:
                return RuleResult(
                    self.id, Verdict.NOT_BOUNDARY, 0.95,
                    f"Custom abbreviation '{clean}'"
                )
        
        return RuleResult(self.id, Verdict.UNCERTAIN, 0.0, "Not custom abbreviation")


__all__ = [
    'Rule16TitleAbbrev', 'Rule17AcademicTitle', 'Rule18BusinessSuffix',
    'Rule19PlaceAbbrev', 'Rule20MonthAbbrev', 'Rule21DayAbbrev',
    'Rule22USState', 'Rule23Ordinal', 'Rule24Acronyms', 'Rule25CustomAbbrev',
]