"""PySET Version."""

__version__ = "0.1.0"
__version_info__ = (0, 1, 0)


def get_version() -> str:
    """Return the version string."""
    return __version__