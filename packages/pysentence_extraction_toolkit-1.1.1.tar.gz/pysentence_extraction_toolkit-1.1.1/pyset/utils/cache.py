"""PySET Cache Utilities."""

from __future__ import annotations
from collections import OrderedDict
from typing import Any, Dict, Optional, TypeVar, Generic
import re

T = TypeVar('T')


class LRUCache(Generic[T]):
    """Simple LRU cache for pattern/results caching."""
    
    def __init__(self, maxsize: int = 128):
        self.maxsize = maxsize
        self._cache: OrderedDict[str, T] = OrderedDict()
    
    def get(self, key: str) -> Optional[T]:
        """Get item from cache."""
        if key in self._cache:
            # Move to end (most recently used)
            self._cache.move_to_end(key)
            return self._cache[key]
        return None
    
    def set(self, key: str, value: T) -> None:
        """Set item in cache."""
        if key in self._cache:
            self._cache.move_to_end(key)
        else:
            if len(self._cache) >= self.maxsize:
                # Remove oldest (first) item
                self._cache.popitem(last=False)
        self._cache[key] = value
    
    def clear(self) -> None:
        """Clear cache."""
        self._cache.clear()
    
    def __len__(self) -> int:
        return len(self._cache)
    
    def __contains__(self, key: str) -> bool:
        return key in self._cache


class PatternCache:
    """Cache for compiled regex patterns."""
    
    _cache: Dict[str, re.Pattern] = {}
    
    @classmethod
    def get_pattern(cls, name: str) -> Optional[re.Pattern]:
        """Get compiled pattern."""
        return cls._cache.get(name)
    
    @classmethod
    def set_pattern(cls, name: str, pattern: re.Pattern) -> None:
        """Set compiled pattern."""
        cls._cache[name] = pattern
    
    @classmethod
    def has_pattern(cls, name: str) -> bool:
        """Check if pattern exists."""
        return name in cls._cache
    
    @classmethod
    def clear(cls) -> None:
        """Clear pattern cache."""
        cls._cache.clear()
    
    @classmethod
    def register(cls, name: str, regex: str, flags: int = 0) -> re.Pattern:
        """Compile and register a pattern."""
        pattern = re.compile(regex, flags)
        cls._cache[name] = pattern
        return pattern