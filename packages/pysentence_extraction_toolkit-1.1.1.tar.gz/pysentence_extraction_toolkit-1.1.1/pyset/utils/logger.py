"""PySET Logger."""

import logging
import sys
from typing import Optional

# Default logger configuration
DEFAULT_FORMAT = "%(levelname)s - %(name)s - %(message)s"


def get_logger(name: str = "pyset", level: int = logging.WARNING) -> logging.Logger:
    """Get or create a logger.
    
    Args:
        name: Logger name
        level: Logging level
        
    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stderr)
        formatter = logging.Formatter(DEFAULT_FORMAT)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(level)
    
    return logger


def set_debug(enabled: bool = True) -> None:
    """Enable or disable debug logging."""
    logger = logging.getLogger("pyset")
    logger.setLevel(logging.DEBUG if enabled else logging.WARNING)


# Default logger instance
logger = get_logger()