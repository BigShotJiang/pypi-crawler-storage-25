"""PySET Utility Functions."""

from __future__ import annotations
import re
import unicodedata
from typing import Optional, List


def normalize_text(text: str) -> str:
    """Normalize text for processing.
    
    - Unicode NFC normalization
    - Standardize line endings
    - Remove zero-width characters
    """
    # NFC normalization
    text = unicodedata.normalize('NFC', text)
    
    # Fix line endings
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    
    # Remove zero-width characters (category Cf)
    result = []
    for char in text:
        if unicodedata.category(char) != 'Cf':
            result.append(char)
    
    return ''.join(result)


def clean_text(text: str) -> str:
    """Clean text of formatting artifacts.
    
    - Remove control characters
    - Handle BOM
    - Normalize quotes and dashes
    """
    # Remove control characters except newline, tab
    result = []
    for char in text:
        cat = unicodedata.category(char)
        if cat[0] != 'C' or char in '\n\t\r':
            result.append(char)
    text = ''.join(result)
    
    # Remove BOM
    text = text.lstrip('\ufeff')
    
    # Normalize smart quotes
    text = text.replace('\u201c', '"').replace('\u201d', '"')  # " "
    text = text.replace('\u2018', "'").replace('\u2019', "'")  # ' '
    
    # Normalize dashes
    text = text.replace('\u2013', '-').replace('\u2014', '-')  # – —
    
    return text


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace in text."""
    # Replace multiple spaces with single
    text = re.sub(r' +', ' ', text)
    
    # Normalize tabs
    text = text.replace('\t', ' ')
    
    return text.strip()


def strip_punctuation(text: str) -> str:
    """Strip leading/trailing punctuation."""
    return text.strip('.,;:!?[](){}<>"\'-—')


def is_sentence_ender(text: str, position: int) -> bool:
    """Check if position is a sentence-ending punctuation."""
    if position >= len(text):
        return False
    char = text[position]
    return char in '.!?'


def find_sentence_candidates(text: str) -> List[int]:
    """Find all potential sentence boundaries (. ? !)."""
    candidates = []
    for i, char in enumerate(text):
        if char in '.!?':
            candidates.append(i)
    return candidates


def get_word_at(text: str, position: int) -> Optional[str]:
    """Extract word at or near position."""
    if position < 0 or position >= len(text):
        return None
    
    # Find word boundaries
    start = position
    end = position
    
    while start > 0 and re.match(r'\w', text[start - 1]):
        start -= 1
    
    while end < len(text) and re.match(r'\w', text[end]):
        end += 1
    
    if start < end:
        return text[start:end]
    return None


def get_words_before(text: str, position: int, max_words: int = 5) -> List[str]:
    """Get words before position."""
    before = text[:position]
    words = re.findall(r'\b\w+\b', before)
    return words[-max_words:] if len(words) > max_words else words


def get_words_after(text: str, position: int, max_words: int = 5) -> List[str]:
    """Get words after position."""
    after = text[position + 1:]
    words = re.findall(r'\b\w+\b', after)
    return words[:max_words]


def split_into_sentences(text: str) -> List[str]:
    """Split text into sentences (simple version without rules).
    
    Used for basic operations.
    """
    # Find sentence endings
    import re
    pattern = r'(?<=[.!?])\s+'
    parts = re.split(pattern, text)
    return [s.strip() for s in parts if s.strip()]