"""PySET Performance Monitoring."""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Dict, Any, Optional


@dataclass
class ProcessingStatistics:
    """Statistics from text processing."""
    
    text_length: int = 0
    sentence_count: int = 0
    avg_sentence_length: float = 0.0
    processing_time_ms: float = 0.0
    boundaries_evaluated: int = 0
    boundaries_found: int = 0
    rules_used: int = 0
    confidence_avg: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'text_length': self.text_length,
            'sentence_count': self.sentence_count,
            'avg_sentence_length': self.avg_sentence_length,
            'processing_time_ms': self.processing_time_ms,
            'boundaries_evaluated': self.boundaries_evaluated,
            'boundaries_found': self.boundaries_found,
            'rules_used': self.rules_used,
            'confidence_avg': self.confidence_avg,
        }


class Timer:
    """Simple timer for performance measurement."""
    
    def __init__(self):
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
    
    def __enter__(self):
        self.start_time = time.perf_counter()
        return self
    
    def __exit__(self, *args):
        self.end_time = time.perf_counter()
    
    @property
    def elapsed_ms(self) -> float:
        if self.start_time is None:
            return 0.0
        end = self.end_time if self.end_time else time.perf_counter()
        return (end - self.start_time) * 1000
    
    @property
    def elapsed_seconds(self) -> float:
        return self.elapsed_ms / 1000