"""English language implementation."""

from __future__ import annotations
from typing import List, Set

from .base_language import BaseLanguage
from ..core.rule import Rule
from ..rules import ALL_RULES, get_all_rules


class English(BaseLanguage):
    """English language with all 85 rules."""
    
    code = 'en'
    name = 'English'
    
    def _load_rules(self) -> None:
        """Load all 85 rules for English."""
        # Get all rule classes
        rule_classes = get_all_rules()
        
        # Instantiate all rules
        self.rules = [rule_class() for rule_class in rule_classes]
    
    def _load_abbreviations(self) -> None:
        """Load English abbreviations."""
        # Core abbreviations
        self.abbreviations = {
            # Titles
            'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Rev', 'Sr', 'Jr', 'St',
            # Business
            'Inc', 'Ltd', 'Corp', 'Co', 'LLC', 'LLP', 'PLC',
            # Places
            'Ave', 'Blvd', 'Rd', 'Dr', 'Ct', 'Pl', 'Way',
            # Months
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
            # Days
            'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun',
            # US States (common)
            'CA', 'NY', 'TX', 'FL', 'IL', 'PA', 'OH', 'GA', 'NC', 'MI',
            'NJ', 'VA', 'WA', 'AZ', 'MA', 'TN', 'IN', 'MO', 'MD', 'WI',
            'CO', 'MN', 'SC', 'AL', 'LA', 'KY', 'OR', 'OK', 'CT', 'UT',
            'IA', 'NV', 'AR', 'MS', 'KS', 'NM', 'WV', 'NE', 'ID', 'HI',
            'ME', 'NH', 'RI', 'MT', 'DE', 'SD', 'ND', 'AK', 'VT', 'WY',
            # Latin phrases
            'et al', 'i.e', 'e.g', 'etc', 'vs', 'fig', 'cf', 'viz',
            # Common
            'etc', 'vs', 'fig', 'approx', 'tel', 'no', 'mr', 'mrs', 'ms',
            'dr', 'prof', 'rev', 'hon', 'sr', 'jr',
            # Academic
            'PhD', 'MD', 'DDS', 'DVM', 'JD', 'MBA', 'MS', 'BA',
            # Acronyms
            'USA', 'UK', 'UN', 'EU', 'NATO', 'FBI', 'CIA', 'NASA', 'IRS', 'FDA',
            'CDC', 'WHO', 'WWI', 'WWII', 'ABC', 'CBS', 'NBC', 'BBC', 'CEO', 'CFO',
            'COO', 'UFO', 'URL', 'HTTP', 'HTTPS', 'FTP', 'TCP', 'IP', 'FAQ',
        }