"""Language Registry for managing available languages."""

from __future__ import annotations
from typing import Dict, List, Optional, Type

from .base_language import BaseLanguage
from .english import English
from ..core.exceptions import LanguageError


class LanguageRegistry:
    """Registry for managing available languages."""
    
    _languages: Dict[str, Type[BaseLanguage]] = {}
    
    @classmethod
    def register(cls, language_class: Type[BaseLanguage]) -> None:
        """Register a language class."""
        instance = language_class()
        cls._languages[instance.code] = language_class
    
    @classmethod
    def get(cls, code: str) -> BaseLanguage:
        """Get language by code."""
        if code not in cls._languages:
            raise LanguageError(f"Language '{code}' not supported")
        return cls._languages[code]()
    
    @classmethod
    def list_available(cls) -> List[str]:
        """List all available language codes."""
        return list(cls._languages.keys())
    
    @classmethod
    def has_language(cls, code: str) -> bool:
        """Check if language is available."""
        return code in cls._languages
    
    @classmethod
    def clear(cls) -> None:
        """Clear all registrations."""
        cls._languages.clear()


# Register default English
LanguageRegistry.register(English)