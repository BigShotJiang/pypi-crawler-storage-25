"""Base Language class for language implementations."""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Set, Type

from ..core.rule import Rule


class BaseLanguage(ABC):
    """Abstract base class for language-specific rules."""
    
    code: str = 'xx'
    name: str = 'Unknown'
    
    def __init__(self):
        self.rules: List[Rule] = []
        self.abbreviations: Set[str] = set()
        self._load_rules()
        self._load_abbreviations()
    
    @abstractmethod
    def _load_rules(self) -> None:
        """Load rules for this language."""
        pass
    
    @abstractmethod
    def _load_abbreviations(self) -> None:
        """Load abbreviations for this language."""
        pass
    
    def get_rules(self) -> List[Rule]:
        """Return all rules for this language."""
        return self.rules
    
    def is_abbreviation(self, word: str) -> bool:
        """Check if word is known abbreviation."""
        clean = word.rstrip('.')
        return clean in self.abbreviations or word in self.abbreviations
    
    def add_abbreviation(self, abbrev: str) -> None:
        """Add abbreviation to language."""
        self.abbreviations.add(abbrev)
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code='{self.code}', name='{self.name}', rules={len(self.rules)})"