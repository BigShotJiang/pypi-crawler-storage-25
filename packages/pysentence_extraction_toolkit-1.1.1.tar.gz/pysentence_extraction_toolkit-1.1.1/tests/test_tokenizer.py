"""Main API tests."""

import pytest
from pyset import TokenBoundaryDetector, split


class TestBasicSplitting:
    """Basic sentence splitting tests."""
    
    def test_simple_period(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Hello world.")
        assert len(result) == 1
        assert result[0] == "Hello world."
    
    def test_multiple_sentences(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Hello world. How are you?")
        assert len(result) == 2
    
    def test_question_mark(self):
        detector = TokenBoundaryDetector()
        result = detector.split("What is this?")
        assert len(result) == 1
    
    def test_exclamation(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Hello world!")
        assert len(result) == 1
    
    def test_empty_string(self):
        detector = TokenBoundaryDetector()
        result = detector.split("")
        assert result == []
    
    def test_no_punctuation(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Hello world")
        assert len(result) == 1


class TestAbbreviations:
    """Tests for abbreviations."""
    
    def test_dr_abbreviation(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Dr. Smith is here.")
        assert len(result) == 1
    
    def test_mr_abbreviation(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Mr. Johnson called.")
        assert len(result) == 1
    
    def test_inc_suffix(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Works at Inc. company.")
        assert len(result) == 1
    
    def test_period_at_end_vs_abbreviation(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Dr. Smith is here. He came.")
        assert len(result) == 2


class TestNumbers:
    """Tests for number handling."""
    
    def test_decimal_number(self):
        detector = TokenBoundaryDetector()
        result = detector.split("The value is 3.14 meters.")
        assert len(result) == 1
    
    def test_currency(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Price is $19.99.")
        assert len(result) == 1
    
    def test_ip_address(self):
        detector = TokenBoundaryDetector()
        result = detector.split("IP: 192.168.1.1 server.")
        assert len(result) == 1


class TestURLsAndEmails:
    """Tests for URLs and emails."""
    
    def test_url(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Visit https://example.com for info.")
        assert len(result) == 1
    
    def test_email(self):
        detector = TokenBoundaryDetector()
        result = detector.split("Email: test@example.com please.")
        assert len(result) == 1


class TestReturnSpans:
    """Tests for return_spans parameter."""
    
    def test_return_spans(self):
        detector = TokenBoundaryDetector()
        spans = detector.split("Hello. World.", return_spans=True)
        
        assert len(spans) == 2
        assert spans[0].text == "Hello."
        assert spans[0].start == 0
        assert spans[0].end == 6


class TestStatistics:
    """Tests for statistics."""
    
    def test_get_statistics(self):
        detector = TokenBoundaryDetector()
        detector.split("Hello world. How are you?")
        
        stats = detector.get_statistics()
        
        assert stats.text_length > 0
        assert stats.sentence_count == 2
        assert stats.processing_time_ms >= 0


class TestCustomAbbreviations:
    """Tests for custom abbreviations."""
    
    def test_custom_abbreviation(self):
        detector = TokenBoundaryDetector()
        detector.set_abbreviations({'ABC', 'XYZ'})
        
        result = detector.split("ABC Corp is here.")
        assert len(result) == 1


class TestConvenienceFunction:
    """Tests for split() convenience function."""
    
    def test_convenience_split(self):
        result = split("Hello. World.")
        assert len(result) == 2


class TestExplain:
    """Tests for explain method."""
    
    def test_explain(self):
        detector = TokenBoundaryDetector()
        explanations = detector.explain("Hello world.")
        
        assert len(explanations) >= 1
        assert hasattr(explanations[0], 'is_boundary')


if __name__ == '__main__':
    pytest.main([__file__, '-v'])