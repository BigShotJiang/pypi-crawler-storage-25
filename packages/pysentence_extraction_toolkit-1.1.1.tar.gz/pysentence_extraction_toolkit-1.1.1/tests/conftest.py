"""Test fixtures and configuration."""

import pytest
from pyset import TokenBoundaryDetector


@pytest.fixture
def detector():
    """Create a detector for testing."""
    return TokenBoundaryDetector()


@pytest.fixture
def sample_texts():
    """Sample texts for testing."""
    return {
        'simple': "Hello world. How are you?",
        'abbreviations': "Dr. Smith is here. He works at Inc.",
        'urls': "Visit https://example.com for info. It costs $19.99.",
        'quotes': 'He said, "Hello world." She nodded.',
        'numbers': "The ratio is 3.14 to 1. The IP is 192.168.1.1.",
    }


@pytest.fixture
def expected_sentences():
    """Expected sentence counts for various inputs."""
    return {
        "Hello world.": 1,
        "Hello. World.": 2,
        "Dr. Smith": 1,
        "Mr. and Mrs. Smith": 1,
        "Visit https://example.com.": 1,
        "The price is $19.99.": 1,
    }