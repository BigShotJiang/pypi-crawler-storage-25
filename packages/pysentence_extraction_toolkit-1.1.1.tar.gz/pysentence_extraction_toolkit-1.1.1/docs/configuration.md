# Configuration Guide

## Basic Configuration

```python
from pyset import TokenBoundaryDetector

detector = TokenBoundaryDetector()
```

## Language Support

PySET supports 50+ languages. Set language at initialization:

```python
detector = TokenBoundaryDetector(language='en')   # English (default)
detector = TokenBoundaryDetector(language='de')   # German
detector = TokenBoundaryDetector(language='fr')  # French
detector = TokenBoundaryDetector(language='es')   # Spanish
detector = TokenBoundaryDetector(language='it')  # Italian
detector = TokenBoundaryDetector(language='pt')  # Portuguese
detector = TokenBoundaryDetector(language='nl')  # Dutch
detector = TokenBoundaryDetector(language='ru')  # Russian
detector = TokenBoundaryDetector(language='zh')  # Chinese
detector = TokenBoundaryDetector(language='ja')  # Japanese
detector = TokenBoundaryDetector(language='ko')  # Korean
```

## Abbreviations

### Default Abbreviations

PySET includes common abbreviations: Dr, Mr, Mrs, Ms, Jr, Sr, Inc, Ltd, etc.

### Add Custom Abbreviations

```python
detector.set_abbreviations({'CEO', 'CFO', 'CTO', 'COO', 'ACME', 'NASA'})
```

### Aggressive Mode

```python
detector = TokenBoundaryDetector(aggressive_abbreviations=True)
```

This applies stricter rules for abbreviations to avoid false splits.

## Sentence Length

### Minimum Sentence Length

```python
detector = TokenBoundaryDetector(min_sentence_length=5)
```

Sentences shorter than 5 words will be merged with the next sentence.

### Merge Short Sentences

```python
detector = TokenBoundaryDetector(merge_short_sentences=True)
```

Automatically merges short sentences.

## Rule Configuration

### Include Specific Rules

```python
detector = TokenBoundaryDetector(include_rules=[1, 2, 3, 10, 15])
```

### Exclude Specific Rules

```python
detector = TokenBoundaryDetector(exclude_rules=[17, 18])
```

### Custom Rules

```python
from pyset.rules import Rule

class MyRule(Rule):
    priority = 95
    
    def evaluate(self, context):
        # Your logic
        return 1.0 if condition else 0.0

detector = TokenBoundaryDetector(custom_rules=[MyRule()])
```

## Debug Mode

```python
detector = TokenBoundaryDetector(debug=True)

explanations = detector.explain("Your text here.")
# Returns detailed rule-by-rule breakdown
```

## Performance Tuning

### Caching

PySET automatically caches Context calls for better performance. No configuration needed.

### Early Exit

PySET exits early when confidence is high:
- Exit if confidence >= 0.75 AND priority >= 85
- Exit if confidence >= 0.90 for BOUNDARY (1.0)

This provides ~3x speedup on average. Disable if needed:

```python
# No current way to disable - early exit is always on
```

## Recommended Configurations

### RAG/Document Chunking

```python
detector = TokenBoundaryDetector(
    min_sentence_length=10,
    merge_short_sentences=True,
    aggressive_abbreviations=True
)
```

### Legal Documents

```python
detector = TokenBoundaryDetector(
    aggressive_abbreviations=True,
    min_sentence_length=5
)
```

### High-Accuracy NLP Pipelines

```python
detector = TokenBoundaryDetector(
    language='en',
    aggressive_abbreviations=True,
    debug=False
)
```

### Debugging/Development

```python
detector = TokenBoundaryDetector(
    debug=True,
    min_sentence_length=1
)
```