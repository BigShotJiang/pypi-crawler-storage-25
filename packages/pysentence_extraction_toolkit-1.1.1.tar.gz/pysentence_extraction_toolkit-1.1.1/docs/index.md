# PySET - Python Sentence Extraction Toolkit

<p align="center">
  <img src="../media/logo.png" alt="PySET Logo" width="128" height="128">
</p>

A high-performance, zero-dependency sentence boundary detection library.

![Execution Time](../media/chart1_exec_time.png)
![Words per Second](../media/chart2_words_per_sec.png)

## Features

- **Zero Dependencies** - Pure Python standard library only
- **Fast** - 2-3x faster than PySBD
- **Accurate** - 100% accuracy on 52 languages
- **85 Rules** - Comprehensive rule-based detection
- **Extensible** - Easy to add custom rules

## Installation

```bash
pip install pyset
```

## Quick Start

```python
from pyset import TokenBoundaryDetector

detector = TokenBoundaryDetector()
sentences = detector.split("Hello world. How are you?")
print(sentences)
# ['Hello world.', 'How are you?']
```

## Documentation

- [Getting Started](getting-started.md)
- [API Reference](api-reference.md)
- [Configuration](configuration.md)
- [Rules](rules.md)
- [Performance](performance.md)
- [Online Docs](../site/)

## License

MIT License