from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .network import CloudCourier
from .parser import CISTParser, ValidationError

load_dotenv()

# On Windows, pip --user installs scripts to a folder not on PATH by default.
# Detect this and print a one-time actionable fix before the user hits a
# confusing "not recognized" error (they'd have to be running via python -m to
# even reach this point, so we can give them instructions to fix it properly).
def _warn_windows_path() -> None:
    if sys.platform != "win32":
        return
    scripts_dir = Path(os.environ.get("APPDATA", "")) / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts"
    if not scripts_dir.exists():
        return
    path_dirs = [Path(p) for p in os.environ.get("PATH", "").split(os.pathsep)]
    if scripts_dir not in path_dirs:
        _console = Console(stderr=True)
        _console.print(
            f"\n[yellow bold]Windows PATH notice:[/yellow bold] "
            f"[cyan]{scripts_dir}[/cyan] is not on your PATH.\n"
            f"Run this once in PowerShell to fix it permanently, then reopen your terminal:\n\n"
            f'  [bold][Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";{scripts_dir}", "User")[/bold]\n'
        )

_warn_windows_path()

_VSCODE_CANDIDATES: dict[str, list[str]] = {
    "darwin": [
        "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code",
        str(
            Path.home()
            / "Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"
        ),
    ],
    "win32": [
        str(
            Path(os.environ.get("LOCALAPPDATA", ""))
            / "Programs/Microsoft VS Code/bin/code.cmd"
        ),
        str(
            Path(os.environ.get("PROGRAMFILES", ""))
            / "Microsoft VS Code/bin/code.cmd"
        ),
    ],
    "linux": [
        "/usr/bin/code",
        "/snap/bin/code",
        "/usr/local/bin/code",
        str(Path.home() / ".local/bin/code"),
    ],
}


def _find_vscode() -> str | None:
    """Return the VS Code executable path, or None if VS Code is not found."""
    found = shutil.which("code") or shutil.which("code-insiders")
    if found:
        return found
    platform = sys.platform if sys.platform in _VSCODE_CANDIDATES else "linux"
    for candidate in _VSCODE_CANDIDATES[platform]:
        if candidate and Path(candidate).exists():
            return candidate
    return None


def _latest_bundled_vsix() -> Path | None:
    assets_dir = Path(__file__).parent / "assets"
    vsix_files = sorted(assets_dir.glob("*.vsix"))
    if not vsix_files:
        return None
    return vsix_files[-1]


def _install_vscode_extension(code_exe: str, vsix: Path) -> bool:
    """Install the bundled CIST VS Code extension. Returns True on success."""
    result = subprocess.run(
        [code_exe, "--install-extension", str(vsix), "--force"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _sync_vscode_extension() -> tuple[bool, str]:
    if os.environ.get("CIST_SKIP_VSCODE_INSTALL") == "1":
        return False, "[dim]VS Code install skipped (CIST_SKIP_VSCODE_INSTALL=1)[/dim]"

    code_exe = _find_vscode()
    if not code_exe:
        return False, "[yellow]![/yellow] VS Code not detected — extension not installed"

    vsix = _latest_bundled_vsix()
    if vsix is None:
        return False, "[yellow]![/yellow] Bundled VS Code extension not found in cist_cli/assets"

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Installing VS Code extension...", total=None)
        ok = _install_vscode_extension(code_exe, vsix)

    if ok:
        return True, f"[green]✓[/green] VS Code extension synced from [cyan]{vsix.name}[/cyan]"

    return (
        False,
        "[yellow]![/yellow] VS Code found but extension install failed — "
        "run: [bold]code --install-extension "
        + str(vsix)
        + " --force[/bold]",
    )

EXAMPLE_CONTRACT = """# Example CIST Contract
# Python-like syntax with trading-specific operations

use math
use compute
use risk

# Import market data
market_data := from data (source: "binance", symbols: ["BTC-USD"], resolution: "1h")

# Calculate indicators
sma_fast := math.sma(market_data.close, 10)
sma_slow := math.sma(market_data.close, 30)

# Trading logic
if sma_fast > sma_slow:
    size := risk.calculate_size(portfolio_value: 10000, risk_percent: 2.0)
    execute(market_buy(symbol: "BTC-USD", size: size))
elif sma_fast < sma_slow:
    execute(close_position())
"""

app = typer.Typer(
    name="cist",
    help="Contract Instruction Set",
    no_args_is_help=True,
)
console = Console()


def _resolve_cis_path(filepath: Path) -> Path:
    resolved = filepath.expanduser().resolve()
    if resolved.suffix.lower() != ".cis":
        console.print(f"[red]Error:[/red] Expected .cis file, got {resolved.suffix}")
        raise typer.Exit(1)
    return resolved


def _print_warnings(result: dict[str, Any]) -> None:
    warnings = result.get("warnings", [])
    for warning in warnings:
        console.print(
            f"[yellow]! Line {warning.line}:[/yellow] {warning.message}"
        )


@app.callback()
def callback() -> None:
    """CIST - Contract Instruction Set Toolkit."""


def _init_workspace(path: Path, install_vscode_extension: bool = False) -> None:
    target = path.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)

    # ── workspace skeleton ────────────────────────────────────────────────────
    contracts_dir = target / "contracts"
    contracts_dir.mkdir(exist_ok=True)

    example_file = contracts_dir / "example.cis"
    if not example_file.exists():
        example_file.write_text(EXAMPLE_CONTRACT, encoding="utf-8")

    env_file = target / ".env"
    if not env_file.exists():
        env_file.write_text(
            "# CIST Cloud API\nCIST_CLOUD_API_KEY=\nCIST_CLOUD_ENDPOINT=https://api.cist.io/v1\n",
            encoding="utf-8",
        )

    # ── optional VS Code extension install ────────────────────────────────────
    vscode_line: str
    if not install_vscode_extension:
        vscode_line = (
            "[dim]VS Code extension not installed by default — run "
            "[bold]python -m cist_cli sync-vscode-extension[/bold] to add syntax highlighting[/dim]"
        )
    else:
        _, vscode_line = _sync_vscode_extension()

    # ── summary ───────────────────────────────────────────────────────────────
    console.print(
        Panel.fit(
            f"[bold green]CIST Ready[/bold green]\n\n"
            f"Workspace:  [cyan]{target}[/cyan]\n"
            f"Contracts:  [cyan]{contracts_dir}[/cyan]\n"
            f"Example:    [cyan]{example_file}[/cyan]\n"
            f"Config:     [cyan]{env_file}[/cyan]\n\n"
            f"{vscode_line}\n\n"
            f"Next steps:\n"
            f"  1. Add your API key to [bold].env[/bold]\n"
            f"  2. Open [bold]{example_file.name}[/bold] and start writing\n"
            f"  3. Run [bold]cist compile <file.cis>[/bold] to build and deploy",
            title=f"cist-kernel v{__version__}",
        )
    )


@app.command()
def init(
    path: Path = typer.Option(
        Path("."),
        "--path",
        "-p",
        file_okay=False,
        help="Target directory",
    ),
    install_vscode_extension: bool = typer.Option(
        False,
        "--install-vscode-extension",
        help="Install the bundled VS Code extension after scaffolding the workspace",
    ),
) -> None:
    """Initialize a CIST workspace."""
    _init_workspace(path=path, install_vscode_extension=install_vscode_extension)


@app.command("sync-vscode-extension")
def sync_vscode_extension() -> None:
    """Install or update the bundled VS Code extension."""
    ok, message = _sync_vscode_extension()
    console.print(message)
    if not ok:
        raise typer.Exit(1)


@app.command()
def compile(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        "-d",
        help="Deploy to live execution",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Validate locally, then stream the CIST source to the cloud compiler."""
    resolved = _resolve_cis_path(filepath)
    parser = CISTParser()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = parser.validate_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )
    if verbose:
        console.print(f"[dim]  modules  : {ast['modules']}[/dim]")
        console.print(f"[dim]  streams  : {ast['data_streams']}[/dim]")

    console.print("[cyan]Connecting to CIST Cloud...[/cyan]")
    try:
        courier = CloudCourier()
        for event in courier.stream_compile(ast, deploy=deploy):
            event_type = event.get("type")
            if event_type == "log":
                console.print(f"[dim][Cloud][/dim] {event.get('message', '')}")
            elif event_type == "artifact":
                console.print(
                    f"[bold green]ok Compiled:[/bold green] {event.get('artifact_id', 'unknown')}"
                )
            elif event_type == "error":
                console.print(
                    f"[bold red]x Build Error:[/bold red] {event.get('message', '')}"
                )
                raise typer.Exit(1)
            elif event_type == "complete":
                console.print("[green]Compilation complete[/green]")
    except ValueError as exc:
        console.print(f"[bold red]Configuration Error:[/bold red] {exc}")
        raise typer.Exit(1) from exc
    except ConnectionError as exc:
        console.print(f"[bold red]Connection Failed:[/bold red] {exc}")
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    app()