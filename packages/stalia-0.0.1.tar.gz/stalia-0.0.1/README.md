# stalia

Reserved package name for [Stalia](https://stalia.io).

Stalia is a developer-first API that turns bank statement PDFs into structured JSON, CSV, and Excel data, with reconciliation as a typed schema field.

Public release coming soon. Watch [stalia.io](https://stalia.io) for the launch announcement.
