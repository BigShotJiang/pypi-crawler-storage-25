"""Reserved for Stalia (https://stalia.io). Public release coming soon."""

__version__ = "0.0.1"
