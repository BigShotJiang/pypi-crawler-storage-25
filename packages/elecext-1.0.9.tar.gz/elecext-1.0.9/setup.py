"""Thin setup.py alongside pyproject.toml.

Only purpose: print a post-install hint so the user knows how to
configure their shell after ``pip install elecext``.
"""
import atexit
import os
import sys

from setuptools import setup


def _post_install_hint():
    """Print shell setup instructions to stderr after install."""
    # Only print when we are actually installing
    # (setup.py is also invoked for egg_info, bdist_wheel, etc.)
    if not any(k in sys.argv for k in ('install', 'develop')):
        return

    shell = os.path.basename(os.environ.get('SHELL', '/bin/bash'))
    rc_map = {
        'bash': '~/.bashrc',
        'zsh':  '~/.zshrc',
        'fish': '~/.config/fish/config.fish',
    }
    rc_file = rc_map.get(shell, f'~/.{shell}rc')

    if shell == 'fish':
        cmd = f"echo 'elecext-env | source' >> {rc_file}"
    else:
        cmd = f"""echo 'eval "$(elecext-env)"' >> {rc_file}"""

    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        msg = f"""
{'=' * 60}
  elecext installed successfully!

  To set up the environment variables, run once:

    eval "$(elecext-env)"

  This will also auto-configure SLURM-safe env var exports for
  this conda env (via a conda activate.d hook).

  Then re-activate:  conda activate <envname>
{'=' * 60}
"""
    else:
        msg = f"""
{'=' * 60}
  elecext installed successfully!

  To set up the environment variables, run:

    {cmd}

  Then restart your shell or run:  source {rc_file}
{'=' * 60}
"""
    print(msg, file=sys.stderr)


atexit.register(_post_install_hint)
setup()
