#!/usr/bin/env python3
"""Print shell export statements for elecext environment variables.

Usage:
    eval $(elecext-env)

This sets PMOL, EMOL, PGAU, EGAU, PMRCC, EMRCC, PORCA, EORCA, EBAS
to point to the pip-installed data files.
"""
import os
import sys

from elecext import get_data_path, _ENV_VAR_MAP


def _detect_rc_file():
    """Detect the user's shell and return (shell_name, rc_file_path)."""
    shell = os.path.basename(os.environ.get('SHELL', '/bin/bash'))
    rc_map = {
        'bash': '~/.bashrc',
        'zsh':  '~/.zshrc',
        'fish': '~/.config/fish/config.fish',
    }
    return shell, rc_map.get(shell, f'~/.{shell}rc')


def _setup_command(shell, rc_file):
    """Return the one-liner to make elecext-env permanent."""
    if shell == 'fish':
        return f"echo 'elecext-env | source' >> {rc_file}"
    return f"""echo 'eval "$(elecext-env)"' >> {rc_file}"""


def _already_in_rc():
    """Check if elecext-env is already sourced in the user's rc file."""
    _, rc_file = _detect_rc_file()
    rc_path = os.path.expanduser(rc_file)
    try:
        with open(rc_path, 'r') as f:
            return 'elecext-env' in f.read()
    except FileNotFoundError:
        return False


def print_setup_hint(file=sys.stderr):
    """Print a copy-paste command to add elecext-env to the shell rc file."""
    if _already_in_rc():
        return
    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        hook_path = os.path.join(
            conda_prefix, "etc", "conda", "activate.d", "elecext_env.sh"
        )
        if os.path.exists(hook_path):
            return  # hook already in place, no hint needed
        # Hook was not installed (e.g. install_conda_activate_hook failed due
        # to permissions); fall through to suggest the manual command.
        print("\n  Could not auto-install the conda activate.d hook.",
              file=file)
        print("  For SLURM-safe setup, run manually:", file=file)
        print("      elecext-env --install-activate-d\n", file=file)
        return
    shell, rc_file = _detect_rc_file()
    cmd = _setup_command(shell, rc_file)
    print(f"\n  To make the environment permanent, run:\n", file=file)
    print(f"    {cmd}\n", file=file)


def install_conda_activate_hook():
    """Install a conda activate.d hook that runs `eval $(elecext-env)`
    on every activation of the current conda env. Idempotent: rewrites
    the hook only if contents differ. Noop (with stderr warning) if the
    caller is not inside a conda env."""
    conda_prefix = os.environ.get("CONDA_PREFIX")
    if not conda_prefix:
        print("elecext-env: CONDA_PREFIX not set; are you in a conda env?",
              file=sys.stderr)
        return False
    activate_dir = os.path.join(conda_prefix, "etc", "conda", "activate.d")
    os.makedirs(activate_dir, exist_ok=True)
    hook_path = os.path.join(activate_dir, "elecext_env.sh")
    body = (
        '# Auto-installed by `elecext-env --install-activate-d`.\n'
        '# Exports PMOL/EMOL/EBAS/... on every `conda activate`.\n'
        'eval "$(elecext-env)"\n'
    )
    try:
        with open(hook_path, "r") as f:
            if f.read() == body:
                print(f"elecext-env: hook already up to date at {hook_path}",
                      file=sys.stderr)
                return True
    except FileNotFoundError:
        pass
    with open(hook_path, "w") as f:
        f.write(body)
    print(f"elecext-env: installed activate.d hook at {hook_path}",
          file=sys.stderr)
    print("  Re-run `conda activate <envname>` once to pick it up.",
          file=sys.stderr)
    return True


def fix_data_files():
    """Replace $EBAS references in installed data files with the actual absolute path."""
    ebas_path = get_data_path("BasisSet")
    data_root = get_data_path()
    fixed = 0
    for dirpath, _, filenames in os.walk(data_root):
        for fname in filenames:
            fpath = os.path.join(dirpath, fname)
            try:
                with open(fpath, 'r') as f:
                    content = f.read()
            except (UnicodeDecodeError, PermissionError):
                continue
            if '$EBAS' not in content:
                continue
            new_content = content.replace('$EBAS', ebas_path)
            try:
                with open(fpath, 'w') as f:
                    f.write(new_content)
                fixed += 1
            except PermissionError:
                print(f"  Warning: cannot write {fpath} (permission denied)",
                      file=sys.stderr)
    if fixed:
        print(f"  Fixed {fixed} data file(s): $EBAS -> {ebas_path}",
              file=sys.stderr)


def main():
    argv = sys.argv[1:]
    if "--install-activate-d" in argv:
        install_conda_activate_hook()
        return
    if "-h" in argv or "--help" in argv:
        print("Usage: elecext-env [--install-activate-d]", file=sys.stderr)
        print("  (no args)            print `export VAR=...` statements to stdout", file=sys.stderr)
        print("                       (use with: eval \"$(elecext-env)\")", file=sys.stderr)
        print("  --install-activate-d install a conda activate.d hook in the current", file=sys.stderr)
        print("                       conda env so that every `conda activate` exports", file=sys.stderr)
        print("                       the elecext vars automatically (needed for", file=sys.stderr)
        print("                       non-interactive shells like SLURM job scripts)", file=sys.stderr)
        return
    fix_data_files()
    # Auto-install conda activate.d hook on first run inside a conda env,
    # so the user gets SLURM-safe behaviour without an extra manual step.
    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        hook_path = os.path.join(
            conda_prefix, "etc", "conda", "activate.d", "elecext_env.sh"
        )
        if not os.path.exists(hook_path):
            install_conda_activate_hook()
    for var, subdirs in _ENV_VAR_MAP.items():
        path = get_data_path(*subdirs)
        print(f'export {var}="{path}"')
    # Hint goes to stderr so it doesn't break eval $(elecext-env)
    print_setup_hint()


if __name__ == "__main__":
    main()
