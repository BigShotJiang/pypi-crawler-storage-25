#!/usr/bin/env python3
# The following python script should
# 0. Parse the gaussian informations given as input DONE
# 1. Take in input the gaussian geometry DONE
# 2. Compute the distance between reacting atoms DONE
# 3. Take from somewhere the polynomial coefficient to extrapolate the HF exchange value DONE
# 4. Compute the MC-PDFT with exchange extrapolated DONE
# 5. Write in output the output file in gaussian format DONE

import concurrent.futures
import sys
import os
import numpy as np
import glob
import shlex
import subprocess
import time

from elecext import GauInpParser, parse_coefficients, combine_gradients, write_output, Logger, resolve_path_with_env, resolve_content_env_vars
from elecext.guess_manager import GuessManager

def main():
    logger = Logger("external.log")
    global print
    print = logger.log
    # Check if the number of arguments is correct (including the script name)

#  PARSE THE GAUSSIAN INFORMATIONS GIVEN AS INPUT
    # Arguments are accessed by indexes in sys.argv
    preamble_file = resolve_path_with_env(sys.argv[1])
    end_file = resolve_path_with_env(sys.argv[2])
    nprocs = sys.argv[3]
    mem = sys.argv[4]
    readgradpy = sys.argv[5]
    layer = sys.argv[6]
    logger.header("MolproExt", nprocs, mem)
    # Check if a gaussian input is already present, if not read from
    # command line.
    files = glob.glob('Gau*EIn')
    if files:
        # Find the last created file by checking the creation time
        last_created_file = max(files, key=os.path.getctime)
        GauInput = last_created_file
    else:
        GauInput = sys.argv[7]
    GauOutput = sys.argv[8]

    



    geom,atoms,spin,charge,OptFlag = GauInpParser(GauInput, spin_offset=-1)

    # GUESS REUSE: Read environment variables set by CentralExt
    guess_reuse_mode = os.environ.get('GUESS_REUSE_MODE')
    guess_num_sections = os.environ.get('GUESS_NUM_SECTIONS')
    guess_iteration_num = os.environ.get('GUESS_ITERATION_NUM')
    guess_is_central = os.environ.get('GUESS_IS_CENTRAL_TASK') == '1'

    guess_mode_for_input = None
    guess_config_for_compute = None
    num_sections_int = 0

    if guess_reuse_mode and guess_reuse_mode != 'none':
        guess_mode_for_input = guess_reuse_mode
        num_sections_int = int(guess_num_sections) if guess_num_sections else 0

        guess_config_for_compute = {
            'enabled': True,
            'iteration_num': int(guess_iteration_num) if guess_iteration_num else 1,
            'num_sections': num_sections_int,
            'is_central_task': guess_is_central
        }

    create_input(preamble_file,end_file,nprocs,mem,spin,charge,geom,
                 guess_mode=guess_mode_for_input,num_sections=num_sections_int if guess_mode_for_input else None)
   
    enter_time = time.time()
    if OptFlag == 0:
        Energy,dipole = compute_energy(nprocs,mem,guess_config=guess_config_for_compute)
        logger.log_energy(Energy)
        write_output(GauOutput,Energy,dipole)
    elif OptFlag == 1:
        import shutil
        scratch_path = os.getenv('SCRATCH')
        if readgradpy.upper() == "READ":
            coefficients = parse_coefficients(preamble_file, "molpro")
            Energy,dipole,Gradient = compute_energy(nprocs,mem,True,"READ",coefficients,atoms,guess_config=guess_config_for_compute)
            logger.log_energy(Energy)
            logger.log_gradients(1, [Gradient])
            # Clean scratch directory
            if scratch_path and os.path.isdir(scratch_path):
                for filename in os.listdir(scratch_path):
                    file_path = os.path.join(scratch_path, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        print(f'Failed to delete {file_path}. Reason: {e}')
        else:
            Energy,dipole,Gradient = compute_energy(nprocs,mem,True,readgradpy.upper(),atoms=atoms,guess_config=guess_config_for_compute)
            logger.log_energy(Energy)
            logger.log_gradients(1, [Gradient])
            # Clean scratch directory
            if scratch_path and os.path.isdir(scratch_path):
                for filename in os.listdir(scratch_path):
                    file_path = os.path.join(scratch_path, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        print(f'Failed to delete {file_path}. Reason: {e}')

        write_output(GauOutput,Energy,dipole,Gradient)


def inject_guess_directives(ending_content, num_sections, mode):
    """
    Inject file directives after each !MethodN marker for guess reuse.

    Parameters
    ----------
    ending_content : str
        Original ending file content (where Molpro method definitions are)
    num_sections : int
        Total number of !MethodN markers expected
    mode : str
        'write' | 'read' | 'read_write' - controls how files are used

    Returns
    -------
    str
        Modified ending content with file directives injected

    Notes
    -----
    - Injects immediately after !MethodN marker
    - file,2 for wavefunction (orbitals + CI vectors)
    - file,1 for integrals (optional but recommended)
    - Case-insensitive matching of !Method markers
    - Molpro method definitions are in ending file, not preamble
    """
    import re

    lines = ending_content.split('\n')
    output_lines = []

    for line in lines:
        output_lines.append(line)

        # Check for !MethodN marker (case-insensitive)
        match = re.match(r'^\s*!Method(\d+)', line, re.IGNORECASE)
        if match:
            section_num = int(match.group(1))
            # Inject file directives immediately after marker
            output_lines.append(f"file,2,section_{section_num}.wfu")
            output_lines.append(f"file,1,section_{section_num}.int")

    injected_content = '\n'.join(output_lines)
    return injected_content


def create_input(preamble_file,end_file,nprocs,mem,spin,charge,geom,
                 guess_mode=None,num_sections=None):
     """
     Create Molpro input file with optional guess file directives.

     NEW PARAMETERS:
         guess_mode : str, optional
             None (no guess), 'write', 'read', or 'read_write'
         num_sections : int, optional
             Number of !MethodN markers in ending file (required if guess_mode set)
     """
     formatted_geom = "\n".join(geom)
     geom_string=f"""geomtyp=xyz
noorient
bohr
geometry={{
{len(geom)}
Title
{formatted_geom}
}}
Set,spin = {spin}
Set,charge = {charge}
      """
     with open(preamble_file,'r') as preamble:
      preamble_string =  preamble.read()

     with open(end_file,'r') as ending:
      ending_string =  ending.read()
     ending_string = resolve_content_env_vars(ending_string)

     # Inject guess directives if guess_mode is active (into ending, not preamble)
     if guess_mode and num_sections:
         ending_string = inject_guess_directives(ending_string, num_sections, guess_mode)

     with open('qmolpro.com','w') as molproinput:
      molproinput.write(preamble_string)
      molproinput.write(geom_string)
      molproinput.write(ending_string)


#  COMPUTE THE FINAL ENERGY
def compute_energy(nprocs,mem,OptFlag=False,readgradpy='NONE',coefficients=[],atoms=None,
                   guess_config=None):
    import os
    import sys
    import random
    import shutil
    test_mode = os.environ.get('EXT_TEST_MODE')

    def create_unique_molpro_dir():
        """Crea una directory molpro_tmp_randomNumber con un nome univoco."""
        base_name = "molpro_tmp_"
        while True:
            random_number = random.randint(10000, 99999) # Genera un numero a 5 cifre
            dir_name = f"{base_name}{random_number}"
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
                return dir_name


    last_gradients = []
    dipole = [0.0, 0.0, 0.0]
    nprocs=int(nprocs)
    mem=int(mem)
    # reserve some memory for the system (i.e. 2 GB for buffer I/O))
    mem=int(mem-0.1*mem)
        # Convert memory from GB to megawords (MW)
    mem_mb = int(mem * 1024)  # Convert GB to MB
    mem_mw = int(mem_mb // (8 * nprocs))  # Convert MB to MW, considering 8 bytes per word



    file_to_move="qmolpro.com"
    original_dir = os.getcwd()
    if test_mode:
        unique_dir = original_dir
    else:
        unique_dir = create_unique_molpro_dir()
        if os.path.exists(file_to_move):
            destination_path = os.path.join(unique_dir, os.path.basename(file_to_move))
            shutil.move(file_to_move, destination_path)
        else:
            exit()
        os.chdir(unique_dir)

    # GUESS REUSE: Setup symlinks for reading previous iteration guess
    if guess_config and guess_config.get('enabled', False):
        try:
            gm = GuessManager()
            iteration_num = guess_config['iteration_num']
            num_sections = guess_config['num_sections']

            # Create scratch directories for current iteration
            section_dirs = gm.create_iteration_scratch(iteration_num, num_sections)

            # Setup symlinks if not first iteration
            if iteration_num > 1:
                gm.setup_read_symlinks(
                    source_iteration=iteration_num - 1,
                    num_sections=num_sections,
                    target_dir=unique_dir
                )

        except Exception as e:
            print(f"GUESS REUSE WARNING: Failed to setup guess management: {e}")

    command = f"molpro -s -n {nprocs} -t 1 -m {mem_mw}m qmolpro.com --output qmolpro.out -W {os.getenv('SCRATCH')}  -D {os.getenv('SCRATCH')}"
    if not test_mode:
        subprocess.run(shlex.split(command))
    
    with open ('qmolpro.out','r') as molproout:
        for line in molproout:
        # Check if the line contains the target string
            if 'EXE_ENERGY' in line:
        # Split the line to extract the floating-point number
                parts = line.split('=')[1].split()

        # Convert the extracted part to a floating-point number and store it in a variable
                Energy = float(parts[0])
                break  # Exit the loop after finding the target line

    # GUESS REUSE: Organize output files and cleanup old iterations
    if guess_config and guess_config.get('enabled', False):
        is_central_task = guess_config.get('is_central_task', False)
        if is_central_task:
            try:
                gm = GuessManager()
                iteration_num = guess_config['iteration_num']
                num_sections = guess_config['num_sections']

                # Move output files to scratch directories
                moved_files = gm.organize_output_files(
                    source_dir=unique_dir,
                    iteration_num=iteration_num,
                    num_sections=num_sections
                )

                # Cleanup previous iteration if not first
                if iteration_num > 1:
                    cleanup_success = gm.cleanup_iteration(iteration_num - 1)
                    if not cleanup_success:
                        print(f"GUESS REUSE WARNING: Cleanup failed, manual cleanup may be needed")

            except Exception as e:
                print(f"GUESS REUSE WARNING: Failed to organize/cleanup guess files: {e}")

    if OptFlag:


# In questo caso devi settare il gradiente a 0 senza fare il calcolo delle forze
# serve per fare uno scan rigido 
        if readgradpy.upper() == 'SCAN': 
            grad = [[0.0, 0.0, 0.0] for _ in range(atoms)]
            return Energy,dipole,grad


#  optg,savegrd=gradient,maxit=2
        if readgradpy.upper() == 'NONE':


            with open('testgradient', 'r') as file:
                lines = file.readlines()

                grad_coord = lines[2:]
                grad = []
                # Print the gradients from the last block
                for line in grad_coord:
                    parts = line.split()
                    grad.append(parts[-3:])

                # Convert gradient units
                grad = [[float(element)*(-0.0194469) for element in sublist] for sublist in grad]
                os.chdir(original_dir)
                return Energy,dipole,grad

        elif readgradpy.upper() == 'READ':
            num_gradients = len(coefficients)
            gradients_sets = []
            with open('qmolpro.xml', 'r') as file:
                lines = file.readlines()

        # Extract gradient values from the XML file manually
            in_gradient_section = False
            current_gradient = []
            gradients_count = 0

            for line in lines:
                line = line.strip()
                if '<gradient' in line:
                    in_gradient_section = True
                    current_gradient = []
                    continue
                elif '</gradient>' in line:
                    in_gradient_section = False
                    gradients_sets.append(np.array(current_gradient))
                    gradients_count += 1
                    if gradients_count >= num_gradients:
                        break

                if in_gradient_section and line:
                    values = line.split()
                    if len(values) == 3:
                        current_gradient.append([float(values[0]), float(values[1]), float(values[2])])

            if len(gradients_sets) < num_gradients:
                print(f"WARNING: Requested {num_gradients} gradients, but only found {len(gradients_sets)} in the XML.")

            # Combine gradients based on coefficients
            grad = combine_gradients(coefficients, gradients_sets).tolist()


            ####
            os.chdir(original_dir)
            return Energy,dipole,grad
        else:
            # Read gradients from custom python module specified in readgradpy
            import sys
            import os
            sys.path.append(f'{os.getcwd()}')

            grad_mod = __import__(readgradpy)
            grad = grad_mod.molpro_table_values
            os.chdir(original_dir)
            return Energy,dipole,grad
    else:
        os.chdir(original_dir)
        return Energy,dipole

if __name__ == "__main__":
    main()


