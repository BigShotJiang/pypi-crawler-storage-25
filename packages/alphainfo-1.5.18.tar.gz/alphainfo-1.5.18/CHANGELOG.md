# Changelog

All notable changes to the alphainfo Python SDK.

## [1.5.18] - 2026-04-25

Documentation polish + version-drift safeguard.

  * **Sync stale README example.** External review caught that the
    `client.version()` example in the "Version and compatibility"
    section was showing `recommended_version="1.5.16"` while the
    current release was `1.5.17`. Fixed; now shows `1.5.18`.
  * **New: tests/test_version_consistency.py** — 3 guard tests that
    fail CI when any of these drift:
      - `pyproject.toml` `version` vs `__version__`
      - `__version__` vs `client._SDK_VERSION`
      - The README's `recommended_version` example vs `__version__`
    Prevents this class of regression from happening again — every
    bump now has to update the README example or CI breaks.

No code or contract changes from 1.5.17.

## [1.5.17] - 2026-04-25

Documentation polish — no code or contract changes from 1.5.16.

External eval pointed out two real issues for users coming from PyPI:

1. **Apex links 404'd.** All `https://alphainfo.io/<path>` references
   in the SDK README, module docstrings, error messages, and project
   URLs now use `https://www.alphainfo.io/<path>`. The `alphainfo.io`
   apex domain only redirects the bare `/` path; any other path
   returns 404 (a GoDaddy-Forwarding limitation we accept rather
   than fix). All link-clickable references now point straight to
   `www.alphainfo.io` so PyPI users land on a working page.
   - Updated 17 link references across README, __init__.py, client.py,
     exceptions.py, examples/quickstart.py, INSTALLATION.md,
     DEBUGGING_GUIDE.md, and pyproject.toml's [project.urls].

2. **Stale version examples in README.** The "version and compatibility"
   example showed `api_version="2.2.1"` and `recommended_version="1.5.0"`,
   which were correct months ago. Updated to `2.3.0` / `1.5.16` to
   match the current API + SDK release. Same fix in the module
   docstring and test fixtures.

## [1.5.16] - 2026-04-25

Documentation update only — no code or contract changes from 1.5.15.
The SDK itself is unchanged.

What's new in the alphainfo ecosystem:

  * **`encoding_guide`** — meta-recipe for the long-tail signals.
    `discover_encoding(signal)` profiles your 1-D array (range,
    kurtosis, periodicity, trend, categorical-likeness) and returns
    a ranked list of encoder recommendations *with reasoning*.
    `auto_encode(client, signal, baseline)` applies them via
    feature_ensemble end-to-end. For signals that don't fit the
    3 verticals (finance / biomedical / industrial) — weather,
    network telemetry, geophysics, custom sensors, anything custom.
    Validated across 4 unfamiliar signal types: 2-3 of the top-3
    responsible channels match the primary recommendations every
    time.
  * **docs/ENCODING_GUIDE.md** — didactic version. Explains what
    encoding is, the 5 encoder families, the 6-question decision
    tree, common pitfalls, and when to override.
  * `GET /v1/recipes` now lists 12 entries (was 11) and 5 walkthroughs
    (was 4).

The SDK README has a new entry in the Recipes table flagging
`encoding_guide` as the meta-recipe entry point — for users who
have a signal and don't know where to start.

## [1.5.15] - 2026-04-25

Documentation update only — no code or contract changes. The SDK
itself is unchanged from 1.5.14.

What's new in the alphainfo ecosystem (visible to SDK users via
`client.guide()` and the new HTTP endpoints):

  * `GET /v1/recipes` — manifest of higher-level patterns composed
    on top of the four primitives (analyze, batch, vector, fingerprint).
    11 entries: feature_ensemble, windowed, parameter_search,
    schema_drift, motif_search, auto_diagnose, event_grammar, intents,
    plus probe libraries for finance / biomedical / industrial.
    Embedded in the existing `client.guide()` response under the
    new `recipes` key — no follow-up call needed.
  * Public HTML overview at https://alphainfo.io/recipes.
  * 4 end-to-end walkthroughs in the public repo (no API key, in-process):
      - finance: detect COVID-19 crash on real SPY data via Yahoo Finance
      - ECG synthetic: localise + diagnose 3 known events
      - ECG real: same pipeline on PhysioNet MIT-BIH records 100 + 200
      - Industrial: 3 motor-condition snapshots vs commissioning baseline
  * Domain alias coverage now consistent across `analyze`,
    `analyze_batch`, `analyze_vector`, `analyze_matrix` — passing
    `domain="industrial"`, `"energy"`, `"mlops"`, `"biomed"`, `"fintech"`,
    etc. resolves correctly on every endpoint.

The SDK README has been updated with a "Recipes — higher-level patterns"
section pointing at the new manifest, walkthroughs, and prose docs.

## [1.5.14] - 2026-04-21

Fix: package's `alphainfo.__version__` attribute was stale in 1.5.13
(reported "1.5.10"). The published package METADATA was correct — pip
install / pip show always resolved 1.5.13 correctly — only the
in-Python introspection attribute was out of sync. Now matches the
package version.

No other changes.

## [1.5.13] - 2026-04-21

Response contract refinement and documentation improvements.

Server response shape has been neutralised — the following keys have
new names:
  • metrics.scale_entropy                       → metrics.complexity_index
  • metrics.multiscale.curvature                → metrics.multiscale.scale_profile
  • metrics.multiscale.summary.scale_curvature_score → metrics.multiscale.summary.profile_score

`AnalysisResult` keeps forwarding `metrics` as a raw dict, so callers
that consume `result.metrics[...]` by key name must update to the new
keys. The 5D fingerprint contract (`sim_local`, `sim_spectral`,
`sim_fractal`, `sim_transition`, `sim_trend`, `fingerprint_available`,
`fingerprint_reason`) is unchanged.

No functional API change otherwise.

## [1.5.12] - 2026-04-20

Added automatic domain inference; `domain` parameter now optional with
sensible default.

- `AnalysisResult.domain_applied` — new field, always populated by
  server 1.5.12+. Tells you which calibration the API actually used.
- `AnalysisResult.domain_inference` — new field, populated only when
  `domain="auto"`. Carries `{inferred, confidence, fallback_used,
  reasoning}` so the caller can see WHY the engine picked that domain.
- New sync + async helpers `client.analyze_auto(signal, sampling_rate)`
  — syntactic sugar for `analyze(..., domain="auto")`.
- Docstrings updated to explain `"auto"` and alias handling
  (`"fintech"` → `"finance"`, `"biomed"` → `"biomedical"`, …).

Backwards-compatible: passing an explicit domain continues to behave
identically. Existing callers that access `.warning` / `.metrics` /
`.semantic` via attribute access are unaffected — the new fields
default to `None` when the server omits them.

## [1.5.10] - 2026-04-20

### Changed
- Clearer ResourceWarning when an ``AsyncAlphaInfo`` instance is
  garbage-collected without being closed. The SDK now emits an
  actionable message pointing at ``async with AsyncAlphaInfo(...) as
  client:`` instead of letting httpx surface its internal warning.

### Note
- Fully backwards compatible. No API contract change. Always wrap
  ``AsyncAlphaInfo`` in ``async with`` (or call ``await client.close()``
  explicitly) when you're done.

## [1.5.9] - 2026-04-20

### Changed
- Fingerprint documentation and error messages improved. New
  ``MIN_FINGERPRINT_SAMPLES`` / ``MIN_FINGERPRINT_SAMPLES_WITH_BASELINE``
  constants; ``client.fingerprint()`` warns early when the input is
  too short for a complete decomposition. See README.

### Note
- Fully backwards compatible. No API contract change.

## [1.5.8] - 2026-04-20

### Changed
- Improved fingerprint reason reporting and error examples.
- Module docstring trimmed — ``help(alphainfo)`` is now concise and
  points to ``alphainfo.guide()`` for exploration.

### Added
- ``examples/fingerprint_handling.py`` — canonical pattern for checking
  ``is_complete`` before using ``.vector`` in ANN / similarity-search
  pipelines, with a fallback to the semantic layer when the
  fingerprint is unavailable.

### Note
- Fully backwards compatible.

## [1.5.7] - 2026-04-20

### Changed
- Improved fingerprint result handling and error messages.

### Note
- Fully backwards compatible at the call-site level. No API surface
  change. Callers that index on `.vector` should now check
  `is_complete` first — the SDK no longer fills missing dimensions
  with `0.0`. See `FingerprintResult` docstrings for details.

## [1.5.6] - 2026-04-20

### Fixed
- Import sort (ruff I001) in alphainfo/__init__.py. 1.5.5 was runtime-correct
  but failed `ruff check` in CI because the typing imports used by the new
  module-level `guide()` / `health()` helpers were placed after the re-exports
  block. Imports now all live at the top of the file, and the cast type names
  are no longer aliased.

### Note
- Functionally identical to 1.5.5. Users on 1.5.5 are unaffected — this is
  strictly a source-layout fix so the CI pipeline is green again.

## [1.5.5] - 2026-04-20

### Added
- Module-level `alphainfo.guide()` and `alphainfo.health()` helpers
  that do NOT require an API key. Lets new users poke at the API
  before signing up: `import alphainfo; alphainfo.guide()` works
  immediately after `pip install`.

### Improved
- SDK 401 errors now include the exact next step: "Get a free key at
  https://alphainfo.io/register and pass it as AlphaInfo(api_key='ai_...')".
  Replaces the old "Invalid or missing API key" terse message that
  left cold-start users guessing what to do.

### Note
- Fully backwards compatible. No API contract change.

## [1.5.4] - 2026-04-19

### Changed
- Documentation improvements, new examples, improved error messages.

### Added
- `examples/fintech.py` — SPY regime-change detection via yfinance.
- `examples/batch_analysis.py` — batch of synthetic signals against
  a shared baseline, showing per-signal success/error handling.
- `examples/observability.py` — Prometheus-style latency time series
  with an injected regime shift (pattern for monitoring pipelines).

### Improved
- `examples/quickstart.py` reduced to a minimal runnable "hello world"
  using a toy sine signal — full path from `pip install` to first
  visible result, no assumed context.
- README.md: new "30-second try" section above the fold, badges
  (PyPI version / Python 3.8+ / MIT), and clearer call to action
  pointing to the free-tier signup.
- Exception hierarchy: richer docstrings on every class describing
  typical causes and retry behavior. `RateLimitError.__str__` now
  includes `retry_after`. All exceptions have a `__repr__` that
  exposes message, status_code, and (for RateLimitError) retry_after.

### Note
- Fully backwards compatible. All existing code continues to work
  identically. No API changes.

## [1.5.3] - 2026-04-19

### Changed
- Documentation improvements and metadata updates.

### Note
- Fully backwards compatible. All existing code continues to work
  identically. No API changes.

## [1.5.2] - 2026-04-17

### Fixed
- **semantic.summary severity mismatch** — `_human_readable_summary()` now uses the
  5-tier severity label (none/low/moderate/high/critical) instead of the 3-tier
  `_determine_risk_level()` (low/medium/high). Previously, a signal with
  `severity=critical` (severity_score=89.4) would show "severity: high" in the
  summary text. Now summary and severity field are always consistent.
- **Latency claims updated across all docs** — PERFORMANCE_GUIDE.md, DEBUGGING_GUIDE.md,
  COMMON_MISTAKES.md, and `/v1/guide` endpoint now reflect actual measured latency:
  ~250-500ms for multiscale (was incorrectly documented as 20-30s pre-optimization).

## [1.5.1] - 2026-04-17

### Fixed
- README: removed dead `analyze_market()` references (endpoint removed in API v2.2.0)
- README: added `fingerprint()` and `version()` documentation with examples
- README async section: replaced `analyze_market` with `fingerprint` example

## [1.5.0] - 2026-04-17

### Added
- **`fingerprint()` method** on both `AlphaInfo` and `AsyncAlphaInfo` — fast-path
  extraction of the 5-dimensional structural vector (skips semantic + multiscale).
  Returns `FingerprintResult` with the 5 structural dimensions and a `.vector`
  property for ANN / nearest-neighbor indexing.
- **`FingerprintResult`** model with `.vector` property for easy integration
  with nearest-neighbor search libraries (pgvector, Qdrant, Faiss).
- **`version()` method** on both clients — calls new `/v1/version` endpoint
  returning API version, engine version, SDK compatibility level, and feature flags.
- **`/v1/version` endpoint** — API version and SDK compatibility negotiation.
  Returns `api_version`, `engine_version`, `sdk_compat` (min/recommended/compat_level),
  `features` dict, and `limits` dict.

### Performance
- Performance improvements in `fingerprint()` computation
  (~30-50% server-side latency reduction, larger gains under
  concurrent load).

### Note
- Fully backwards compatible. All tests passing.
- Server-side latency improvements concentrated under concurrent
  load: ~2.3x faster at 50 parallel calls.

## [1.4.3] - 2026-04-17

### Fixed
- Guide .md files now ship inside the wheel at `alphainfo/guides/` (were only in sdist).
  Users can find them at `site-packages/alphainfo/guides/` after `pip install`.
- README guide links replaced with `client.guide()` usage example — no more 404s
  from private GitHub repo URLs.

## [1.4.2] - 2026-04-17

### Added
- **`guide()` method** on both `AlphaInfo` and `AsyncAlphaInfo` — fetches the
  universal encoding guide from `/v1/guide` (no auth required). Returns a dict
  with all sections: endpoints, common_mistakes, performance_tips, debugging_tips,
  encoding_patterns, fingerprint_patterns, and more. Useful for programmatic
  discoverability and AI agent introspection.

## [1.4.1] - 2026-04-17

### Fixed
- Guide links in PyPI README now point to absolute GitHub URLs (were broken relative links).
- COMMON_MISTAKES.md, PERFORMANCE_GUIDE.md, DEBUGGING_GUIDE.md included in source distribution via MANIFEST.in.
- CHANGELOG.md also included in source distribution.

## [1.4.0] - 2026-04-17

### Added
- **HTTP/2 support** — auto-detected when `h2` package is installed.
  Install with `pip install alphainfo[http2]`. Connection multiplexing and header
  compression for better throughput, especially with `AsyncAlphaInfo`.
- **Configurable retry delays** — new constructor params `retry_base_delay` (default 1.0s)
  and `retry_max_delay` (default 32.0s) for fine-tuning exponential backoff behavior.
- **`http2` constructor param** — explicitly enable/disable HTTP/2 (`True`/`False`)
  or auto-detect (`None`, default).
- **COMMON_MISTAKES.md** — guide covering 10 common pitfalls (short signals, wrong
  sampling_rate, missing close, loop vs batch, etc.).
- **PERFORMANCE_GUIDE.md** — endpoint selection decision tree, latency expectations,
  async concurrency patterns, retry tuning, windowing strategies.
- **DEBUGGING_GUIDE.md** — step-by-step troubleshooting for every error type,
  verbose logging setup, raw response inspection.

### Changed
- Internal refactor: validation and payload construction extracted into shared
  module-level functions (`_build_analyze_payload`, `_build_batch_payload`,
  `_build_matrix_payload`, `_build_vector_payload`). Response parsing also
  consolidated (`_parse_matrix`, `_parse_health`, `_parse_plans`, `_parse_audit_list`).
  This eliminates ~300 lines of duplicated code between `AlphaInfo` and `AsyncAlphaInfo`.
- README updated with new config params and links to the 3 new guides.

### Note
- Fully backwards compatible. All 47 SDK tests passing.
- No changes to the frozen API (core/metrics/api/config untouched).

## [1.3.0] - 2026-04-10

### Added
- **`analyze_batch(baselines=...)`** — per-signal baselines for batch analysis.
  Each baseline is compared against its corresponding signal. Use `None` for
  signals that don't need a baseline. 10x speedup for pairwise workflows.
- **`analyze_matrix(signals)`** — pairwise structural similarity matrix.
  Returns NxN matrix of structural_scores. Consumes N*(N-1)/2 analyses.
  `MatrixResult` includes helper methods: `score(i,j)`, `most_similar(i)`, `most_different(i)`.
- **`MatrixResult`** model with `matrix`, `labels`, `n_signals`, `n_pairs`, `analyses_consumed`.
- **`structural_perception.py`** example — LLM tool_use wrapper with `perceive()`,
  `diagnose()`, and `compare_multi()`. Demonstrates "LLM reasons, alphainfo perceives" pattern.

## [1.2.0] - 2026-04-10

### Breaking Change
- **`SemanticResult.trend`**: value `"degrading"` renamed to `"diverging"`
  - "degrading" implied a value judgment (something getting worse)
  - "diverging" is mathematically neutral — structure diverged from baseline
  - The API perceives structural change, it does not judge whether the change is good or bad
  - **Migration**: replace `trend == "degrading"` with `trend == "diverging"` in your code

### Added
- `/v1/guide` endpoint — universal encoding guide with 5 patterns and 3 usage modes
- Updated positioning language across docs

## [1.1.4] - 2026-04-09

### Added
- `BatchResult` is now **iterable**: `for r in batch_result` yields each `BatchItemResult`
- `BatchResult` supports `len(batch)` and `batch[i]` indexing
- Migration note: `for r in client.analyze_batch(...)` now works directly

### Clarification
- `composite` was never a public API field. It is an internal engine function.
  Accessing `result.composite` raises `AttributeError`. Use `getattr(result, "composite", None)` if needed.

## [1.1.3] - 2026-04-09

### Fixed
- **P2 Bug**: `AuditReplay.sampling_rate` now correctly reads from `parameters.sampling_rate` (was returning 0.0)
- **P2 Bug**: `PlanInfo.monthly_limit = -1` for Enterprise plans now documented as "unlimited"

### Added
- `PlanInfo.is_unlimited` property — returns `True` when `monthly_limit == -1` (Enterprise plans)
- `SemanticResult.trend` docs: valid values `"stable"`, `"monitoring"`, `"diverging"`
- `SemanticResult.recommended_action` docs: valid values `"log_only"`, `"monitor"`, `"human_review"`, `"immediate_human_review"`
- Contract tests for `AuditReplay.sampling_rate` fallback and `PlanInfo.is_unlimited`
- `/v1/help` now documents semantic_fields (trend values, recommended_action values) and plan tiers

## [1.1.1] - 2026-04-09

### Added
- `SemanticResult.severity` — granular severity label: `"none"`, `"low"`, `"moderate"`, `"high"`, `"critical"`
- `SemanticResult.severity_score` — severity score 0-100 (formula: `(1 - structural_score) * 100`)
- `SemanticResult.summary` — human-readable summary text (e.g. "Structural divergence detected (severity: high)")
- `SemanticResult.trend` — trend direction: `"stable"`, `"diverging"`, `"monitoring"`
- `AnalysisResult.warning` — warning message for short signals or limited engine confidence
- 8 SDK-to-API contract tests ensuring every API field maps to an SDK attribute

### Fixed
- `SemanticResult.alert_level` default corrected from `"none"` to `"normal"` (matching actual API values)
- `alert_level` documentation corrected: valid values are `"normal"`, `"attention"`, `"alert"`, `"critical"`

## [1.1.0] - 2026-04-09

### Added
- `VectorResult.confidence_band` — aggregate confidence band for vector analysis
- `VectorResult.warning` — warning for channels with insufficient samples
- `analyze_vector(baselines=...)` — per-channel baseline support
- Baseline validation (key matching, proportion limits)

### Fixed
- `VectorResult.change_score` now accessible (was missing from parser)

## [1.0.0] - 2026-04-04

### Initial release
- `AlphaInfo` and `AsyncAlphaInfo` clients
- `analyze()`, `analyze_batch()`, `analyze_vector()` methods
- `audit_list()`, `audit_replay()` for audit trail
- `health()` endpoint
- Full type annotations with `py.typed`
- Automatic retry with exponential backoff
- Rate limit tracking via response headers
- Exception hierarchy: `AuthError`, `ValidationError`, `RateLimitError`, `NotFoundError`, `APIError`
