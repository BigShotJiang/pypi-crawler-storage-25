/*
 * The internal type definitions
 *
 * Copyright (C) 2013-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFWPS_INTERNAL_TYPES_H )
#define _LIBFWPS_INTERNAL_TYPES_H

#include <common.h>
#include <types.h>

/* Define HAVE_LOCAL_LIBFWPS for local use of libfwps
 * The definitions in <libfwps/types.h> are copied here
 * for local use of libfwps
 */
#if defined( HAVE_LOCAL_LIBFWPS )

/* The following type definitions hide internal data structures
 */
#if defined( HAVE_DEBUG_OUTPUT ) && !defined( WINAPI )
typedef struct libfwps_record {}	libfwps_record_t;
typedef struct libfwps_set {}		libfwps_set_t;
typedef struct libfwps_store {}		libfwps_store_t;

#else
typedef intptr_t libfwps_record_t;
typedef intptr_t libfwps_set_t;
typedef intptr_t libfwps_store_t;

#endif /* defined( HAVE_DEBUG_OUTPUT ) && !defined( WINAPI ) */

#endif /* defined( HAVE_LOCAL_LIBFWPS ) */

#endif /* !defined( _LIBFWPS_INTERNAL_TYPES_H ) */

