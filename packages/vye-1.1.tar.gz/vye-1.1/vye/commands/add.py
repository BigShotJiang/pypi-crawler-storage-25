from bs4 import BeautifulSoup
import subprocess
import shutil

FORMATTERS = [
    ["prettier", "--write"],
    ["npx", "prettier", "--write"],
    ["bunx", "prettier", "--write"],
    ["deno", "fmt"],
]


def format_html(path: str):
    for formatter in FORMATTERS:
        if shutil.which(formatter[0]):
            subprocess.run(formatter + [path])
            return


lib_db = {
    # legacy
    "jquery": "https://cdn.jsdelivr.net/npm/jquery/dist/jquery.min.js",
    "lodash": "https://cdn.jsdelivr.net/npm/lodash/lodash.min.js",
    "axios": "https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js",
    # modern
    "cash": "https://cdn.jsdelivr.net/npm/cash-dom/dist/cash.min.js",
    "twind": "https://cdn.twind.style",
    "swal2": "https://cdn.jsdelivr.net/npm/sweetalert2/dist/sweetalert2.all.min.js",
    "htmx": "https://cdn.jsdelivr.net/npm/htmx.org/dist/htmx.min.js",
    "alpine": "https://cdn.jsdelivr.net/npm/alpinejs/dist/cdn.min.js",
    "nutshell": "https://cdn.jsdelivr.net/gh/ncase/nutshell/nutshell.min.js",
}

tips = {
    "jquery": "vye add cash is a modern alternative (6kb vs 87kb)",
    "lodash": "most lodash methods are now available natively in JS",
    "axios": "fetch() is built into the browser, no library needed",
}


def run(req_lib: str):
    for lib_name, lib_url in lib_db.items():
        if req_lib == lib_name:
            # add required lib to index.html
            with open("index.html", "r", encoding="utf-8") as f:
                soup = BeautifulSoup(f, "lxml")

            script = soup.new_tag("script", src=lib_url)
            soup.body.append(script)

            with open("index.html", "w", encoding="utf-8") as f:
                f.write(str(soup))

            format_html("index.html")

            print(f" ☑️  {req_lib} added {lib_url}")

            if req_lib in tips:
                print(f" 💡 tip: {tips[req_lib]}")
