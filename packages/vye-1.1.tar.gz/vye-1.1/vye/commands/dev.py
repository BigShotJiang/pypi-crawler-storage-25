from livereload import Server


def run():
    server = Server()
    server.watch("*.html")
    server.watch("*.css")
    server.watch("*.js")
    server.serve(root=".", port=5500, open_url_delay=0)
