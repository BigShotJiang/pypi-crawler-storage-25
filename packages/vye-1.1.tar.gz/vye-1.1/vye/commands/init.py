def run():
    with open("index.html", "w") as f:
        f.write(
            """
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Document</title>
    <link rel="stylesheet" href="style.css"> 
  </head>
  <body>
    <h1>Hello, world!</h1> 
    <script src="script.js"></script>
  </body>
</html>
""".strip()
        )
    with open("style.css", "w") as f:
        f.write(
            """
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: system-ui, sans-serif;
  font-size: 16px;
  color: #333;
  background: #fff;
} 
        """.strip()
        )
        with open("script.js", "w") as f:
            f.write("")
