import sys
from vye.commands import init, add, dev

HELP_TEXT = """
Usage: vye <command> [arguments]

A CLI for Vanilla Web.

Commands:
  init        Scaffold a new Vanilla Web project (index.html, style.css, script.js)
  add <lib>   Add a library <script> tag to index.html
  dev         Start a live development server

Supported libraries:
  Modern: htmx, alpine, twind, nutshell, cash, swal2
  Legacy: jquery, axios, lodash

Examples:
  vye init
  vye add htmx
  vye dev
"""


def main():
    if len(sys.argv) > 1:
        if sys.argv[1] == "init":
            init.run()
        elif sys.argv[1] == "add":
            add.run(sys.argv[2])
        elif sys.argv[1] == "dev":
            dev.run()
        else:
            print(HELP_TEXT)
    else:
        print(HELP_TEXT)
