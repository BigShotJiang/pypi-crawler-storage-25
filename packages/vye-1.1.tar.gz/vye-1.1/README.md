# vye

A CLI for Vanilla Web.

```
uv tool install vye
```

or

```
pipx install vye
```


---

## Commands

### `vye init`
Scaffolds a new Vanilla Web project in the current directory.

```
index.html
style.css
script.js
```

### `vye add <lib>`
Adds a `<script>` tag to the end of your `index.html` body.

```
$ vye add htmx
index.html 14ms
 ☑️  htmx added https://cdn.jsdelivr.net/npm/htmx.org/dist/htmx.min.js
```

---

## Supported libraries

| Name | Type |
|------|------|
| `htmx` | Modern |
| `alpine` | Modern |
| `twind` | Modern |
| `nutshell` | Modern |
| `cash` | Modern |
| `swal2` | Modern |
| `jquery` | Legacy |
| `axios` | Legacy |
| `lodash` | Legacy |

---

## Why vye?

Named after Eustacia Vye from *The Return of the Native* — a character of exotic beauty, largely misunderstood and underestimated by those around her. Much like Vanilla Web itself.

---

## Requirements

- Python 3.14+
- A JS runtime for HTML formatting (prettier via `npx`, `bunx`, or `deno fmt`)