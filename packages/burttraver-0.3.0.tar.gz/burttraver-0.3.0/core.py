def 打印(内容,结尾符='\n',开始符='',间隔符=' '):
    try:
        print(开始符,end='')
        print(内容,end=结尾符,sep=间隔符)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 重复输出(内容='',限制次数=1,结尾符='\n',开始符='',间隔符=' '):
    try:
        cishu = 限制次数
        while True:
            cishu = cishu - 1
            if cishu == -1:
                break
            print(开始符,end='')
            print(内容,end=结尾符,sep=间隔符)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 阶乘(数字):
    try:
        for i in range(数字-1):
            数字 = 数字 * (i+1)
        print(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 次方算法(数字,次方数):
    try:
        原数字 = 数字
        for i in range(次方数-1):
            数字 = 数字 * 原数字
        print(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 开根号(次方根,数字):
    try:
        结果 = 数字 ** (1/次方根)
        打印(结果)
        return 结果
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 苏醒玩家(大小=(800,800),颜色=(0,0,0),名称=''):
    try:
        import pygame
        import random
        import math
        pygame.init()
        pygame.display.set_caption(名称)
        screen=pygame.display.set_mode(大小)
        screen.fill(颜色)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转八进制(数字):
    try:
        return oct(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转十六进制(数字):
    try:
        return hex(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 加密(原文, 密钥=123):
    try:
        密文 = []
        for 字符 in 原文:
            数字 = ord(字符)
            新数字 = (数字 * 密钥 + 7) % 65536
            密文.append(str(新数字))
        return "%".join(密文)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 解密(密文, 密钥=123):
    try:
        结果 = []
        for 段 in 密文.split("%"):
            if not 段:
                continue
            数字 = int(段)
            原数字 = (数字 - 7) * pow(密钥, -1, 65536) % 65536
            结果.append(chr(原数字))
        return "".join(结果)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 苏醒乌龟(别名='乌龟',颜色='白'):
    try:
        乌打初 = 'turtle'
        模块 = __import__(乌打初)
        screen = 模块.Screen()
        if 颜色 == '红':
            模块.bgcolor('red')
        if 颜色 == '橙':
            模块.bgcolor('orange')
        if 颜色 == '黄':
            模块.bgcolor('yellow')
        if 颜色 == '绿':
            模块.bgcolor('green')
        if 颜色 == '青':
            模块.bgcolor('cyan')
        if 颜色 == '蓝':
            模块.bgcolor('blue')
        if 颜色 == '紫':
            模块.bgcolor('purple')
        if 颜色 == '白':
            模块.bgcolor('white')
        if 颜色 == '灰':
            模块.bgcolor('grey')
        if 颜色 == '黑':
            模块.bgcolor('black')
        if 颜色 == '粉':
            模块.bgcolor('pink')
        class 我的乌龟:
            def __init__(self):
                self._y = 模块.Turtle()
                self._y.shape('turtle')
            def 前进(self,距离):
                try:
                    self._y.forward(距离)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 左转(self,角度):
                try:
                    self._y.lt(角度)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 右转(self,角度):
                try:
                    self._y.rt(角度)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 后退(self,距离):
                try:
                    self._y.bk(距离)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 粗细(self,粗细):
                try:
                    self._y.pensize(粗细)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 抬笔(self):
                try:
                    self._y.penup()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 落笔(self):
                try:
                    self._y.pendown()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 画圆(self,半径,度数=360,段数=None):
                try:
                    self._y.circle(半径,extent=度数,steps=段数)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 画点(self,大小,颜色):
                try:
                    if 颜色 == '红':
                        self._y.dot(大小,'red')
                    if 颜色 == '橙':
                        self._y.dot(大小,'orange')
                    if 颜色 == '黄':
                        self._y.dot(大小,'yellow')
                    if 颜色 == '绿':
                        self._y.dot(大小,'green')
                    if 颜色 == '青':
                        self._y.dot(大小,'cyan')
                    if 颜色 == '蓝':
                        self._y.dot(大小,'blue')
                    if 颜色 == '紫':
                        self._y.dot(大小,'purple')
                    if 颜色 == '白':
                        self._y.dot(大小,'white')
                    if 颜色 == '灰':
                        self._y.dot(大小,'grey')
                    if 颜色 == '黑':
                        self._y.dot(大小,'black')
                    if 颜色 == '粉':
                        self._y.dot(大小,'pink')
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 隐藏(self):
                try:
                    self._y.ht()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 显示(self):
                try:
                    self._y.st()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 方向设定(self,方向):
                try:
                    self._y.seth(方向)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 画板保持展示状态(self):
                try:
                    self._y.done()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 开始填充(self):
                try:
                    self._y.begin_fill()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 结束填充(self):
                try:
                    self._y.end_fill()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 变成初始状态(self):
                try:
                    self._y.home()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 移动到(self,横向,竖向):
                try:
                    self._y.goto(横向,竖向)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 背景颜色(颜色):
                try:
                    if 颜色 == '红':
                        self._y.bgcolor('red')
                    if 颜色 == '橙':
                        self._y.bgcolor('orange')
                    if 颜色 == '黄':
                        self._y.bgcolor('yellow')
                    if 颜色 == '绿':
                        self._y.bgcolor('green')
                    if 颜色 == '青':
                        self._y.bgcolor('cyan')
                    if 颜色 == '蓝':
                        self._y.bgcolor('blue')
                    if 颜色 == '紫':
                        self._y.bgcolor('purple')
                    if 颜色 == '白':
                        self._y.bgcolor('white')
                    if 颜色 == '灰':
                        self._y.bgcolor('grey')
                    if 颜色 == '黑':
                        self._y.bgcolor('black')
                    if 颜色 == '粉':
                        self._y.bgcolor('pink')
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 速度(self,强度):
                if 强度 < 10 and 强度 > 0:
                    self._y.speed(强度)
                elif 强度 == 10:
                    self._y.speed(0)
                else:
                    print('错误：强度只能在1～10区间，10为最快，也不能为小数。')
            def 颜色(self,颜色):
                try:
                    if 颜色 == '红':
                        self._y.color('red')
                    if 颜色 == '橙':
                        self._y.color('orange')
                    if 颜色 == '黄':
                        self._y.color('yellow')
                    if 颜色 == '绿':
                        self._y.color('green')
                    if 颜色 == '青':
                        self._y.color('cyan')
                    if 颜色 == '蓝':
                        self._y.color('blue')
                    if 颜色 == '紫':
                        self._y.color('purple')
                    if 颜色 == '白':
                        self._y.color('white')
                    if 颜色 == '灰':
                        self._y.color('grey')
                    if 颜色 == '黑':
                        self._y.color('black')
                    if 颜色 == '粉':
                        self._y.color('pink')
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 多边形(self,边数,边长):
                try:
                    for i in range(边数):
                        self._y.fd(边长)
                        self._y.lt(360/边数)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 写文字(self, 内容, 对齐方式='left', 字体=('Arial', 8, 'normal')):
                try:
                    self._y.write(内容, align=对齐方式, font=字体)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 印章(self):
                try:
                    return self._y.stamp()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 清除印章(self, 印章ID):
                try:
                    self._y.clearstamp(印章ID)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 清除所有印章(self):
                try:
                    self._y.clearstamps()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 撤销(self):
                try:
                    self._y.undo()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 重置(self):
                try:
                    self._y.reset()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 清除(self):
                try:
                    self._y.clear()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 获取X坐标(self):
                try:
                    return self._y.xcor()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 获取Y坐标(self):
                try:
                    return self._y.ycor()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 获取位置(self):
                try:
                    return self._y.pos()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 获取朝向(self):
                try:
                    return self._y.heading()
                except Exception as e:

                    print(f"BurtTRAVER 错误：{e}")
            def 朝向(self, x, y):
                try:
                    return self._y.towards(x, y)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 距离(self, x, y):
                try:
                    return self._y.distance(x, y)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 是否落笔(self):
                try:
                    return self._y.isdown()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 是否可见(self):
                try:
                    return self._y.isvisible()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 形状(self,形状名='turtle'):
                try:
                    self._y.shape(形状名)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 大小(self,拉伸宽度=1,拉伸长度=1,轮廓宽度=1):
                try:
                    self._y.shapesize(拉伸宽度,拉伸长度,轮廓宽度)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 填充中(self):
                try:
                    return self._y.filling()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 延迟(self, 毫秒数):
                try:
                    self._y.delay(毫秒数)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 追踪(self, n=1, 延迟=0):
                try:
                    self._y.tracer(n, 延迟)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 更新(self):
                try:
                    self._y.update()
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 屏幕大小(self, 宽, 高, 背景色=None):
                try:
                    self._y.screensize(宽, 高, 背景色)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
            def 标题(self, 标题名):
                try:
                    self._y.title(标题名)
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
        乌龟 = 我的乌龟()
        globals()[别名] = 乌龟
        globals()['乌龟'] = 乌龟
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 综合(可迭代对象):
    try:
        x=0
        for i in args:
            x+=i
        return x
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 重复数字(开始,结束,间隔=1):
    try:
        return range(开始,结束,间隔)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
篱笆 = '╳'
链条 = '┇'
左上角 = '╭'
右上角 = '╮'
横线 = '━'
左下角 = '╰' 
右下角 = '╯'
竖线 = '┃'
苹果图标 = ''
上 = '⬆'
下 = '⬇'
左 = '⬅'
右 = '➡'
def 求助():
    print("""BurtTRAVER 0.2.0 全部函数 & 变量一览表
打印(内容,结尾符='\n',开始符='',间隔符=' ')
重复输出(内容='',限制次数=1,结尾符='\n',开始符='',间隔符=' ')
除法(被除数,除数) --->输出列表，第一个是商，第二个是余数，如果没有余数就是能整除。
阶乘(数字)   说明：「5的阶乘：5✖4✖3✖2✖1」
次方算法(数字,次方数)
开根号(次方根,数字)
平方根(数字)
幂运算(数字,幂次)  说明：「3的2幂次就是3✖3，2的6幂次就是2✖2✖2✖2✖2✖2」
绝对值(数字=1)
综合(可迭代对象)
取模(被除数,除数) --->取到余数
重复数字(开始,结束,间隔=1)
长度(内容)
是否全部为真(可迭代对象=None)
是否全部为假(可迭代对象=None)
判断真假(对象)
最小值(可迭代对象)
最大值(可迭代对象)
转二进制(数字)
转八进制(数字)
转百分数(数字)
转十六进制(数字)
字节(内容)
加密(原文, 密钥=123)
解密(密文, 密钥=123)
提问(提问内容)
类型(字)      「type」
转字符串(字)   「str」
转数字(字)    「int」
转小数(字)    「float」
转列表(字)    「list」
转字典(字)    「dict」
转集合(字)    「set」
排序(可迭代对象)
反转(序列)   --->[1,2,3]变成[3,2,1]
拉链(*可迭代对象)
映射(类型,列表)
过滤(函数,可迭代对象)
四舍五入(数字)
对应类型(字,类型)
转编码(字符)
转字符(编码)
查看方法(对象)
下一个(针对的对象)
苏醒玩家(大小=(800,800),颜色=(0,0,0),名称='')
苏醒乌龟(别名='乌龟',颜色='白')
求助() --->给出所有功能
打开文件(文件名,类型)
翻译(代码文本)
枚举(可迭代对象, 起始=0)
运行(文件路径='我的代码.txt')
运行代码(代码)
切片(开始,结束,步长)   --->创建切片对象
复数(实部,虚部)   --->创建复数
可调用(对象)   --->判断对象是否可调用
子类检查(子类,父类)   --->判断是否为子类
设置属性(对象,属性名,值)   --->给对象设置属性
检查属性(对象,属性名)   --->判断对象是否有该属性
删除属性(对象,属性名)   --->删除对象的属性
表达式执行(表达式)   --->执行字符串表达式
迭代器(可迭代对象)   --->生成迭代器
全局变量列表()   --->获取当前全局变量字典
局部变量列表()   --->获取当前局部变量字典
哈希值(对象)   --->获取对象的哈希值
篱笆,链条,左上角,右上角,横线,左下角,右下角,竖线
苹果图标,上,下,左,右  「,⬆,⬇,⬅,➡」
关键字库 (中文→英文关键词)（详细信息如下）
「
       关键字：'针对':'for','在':'in',
       '定义函数':'def','返回':'return',
       '如果':'if','否则':'else','要不然':'elif',
       '试一试':'try','报错':'except',
       '没报错':'else','无论如何':'finally'
                                                 」
⚠提示⚠：关键字库只能在「运行代码(代码)」和「运行(文件路径='我的代码.txt')」里面运行，请见解！""")
关键字库 = {'针对':'for','在':'in','定义函数':'def',
        '返回':'return','如果':'if',
        '否则':'else','要不然':'elif',
        '试一试':'try','报错':'except',
        '没报错':'else','无论如何':'finally'
        }
def 平方根(数字):
    try:
        return pow(数字,0.5)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 幂运算(数字,幂次):
    try:
        return pow(数字,幂次)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 长度(内容):
    try:
        return len(内容)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 绝对值(数字=1):
    try:
        return abs(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 是否全部为真(可迭代对象=None):
    try:
        if 可迭代对象==None:
            return None
        return all(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 判断真假(对象):
    try:
        if bool(对象) == False:
            return '否'
        elif bool(对象) == True:
            return '是'
        else:
            return '不确定'
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转二进制(数字):
    try:
        return bin(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 是否全部为假(可迭代对象=None):
    if 可迭代对象==None:
        return None
    return not any(可迭代对象)
def 翻译(代码文本):
    try:
        for 中文, 英文 in 关键字库.items():
            代码文本 = 代码文本.replace(中文, 英文)
        return 代码文本
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 运行(文件路径="我的代码.txt"):
    try:
        with open(文件路径, "r", encoding="utf-8") as f:
            代码文本 = f.read()
        翻译后 = 翻译(代码文本)
        exec(翻译后)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 运行代码(代码):
    try:
        local_vars = {}
        exec(代码, globals(), local_vars)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 取模(被除数,除数):
    try:
        return 被除数%除数
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转百分数(数字):
    try:
        return str(int(数字*100))+'%'
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 除法(被除数,除数):
    try:
        if list(divmod(被除数,除数))[1]==0:
            return int(list(divmod(被除数,除数))[0])
        else:
            return list(divmod(被除数,除数))
    except ZeroDivisionError:
        print('BurTTRAVER错误：除数不能为0。')
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 最大值(可迭代对象):
    try:
        return max(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 最小值(可迭代对象):
    try:
        return min(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 提问(提问内容):
    try:
        return input(提问内容)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 类型(字):
    try:
        return type(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转字符串(字):
    try:
        return str(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转数字(字):
    try:
        return int(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转小数(字):
    try:
        return float(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转列表(字):
    try:
        return list(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转字典(字):
    try:
        return dict(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转集合(字):
    try:
        return set(字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 排序(可迭代对象):
    try:
        return sorted(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 反转(序列):
    try:
        return list(reversed(序列))
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 映射(类型,列表):
    try:
        return list(map(类型,列表))
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 过滤(函数,可迭代对象):
    try:
        return list(filter(函数,可迭代对象))
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 四舍五入(数字):
    try:
        return round(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 对应类型(字,类型):
    try:
        return isinstance(字,类型)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转编码(字符):
    try:
        return ord(字符)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转字符(编码):
    try:
        return chr(编码)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 查看方法(对象):
    try:
        return dir(对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 打开文件(文件名,类型):
    try:
        open(文件名,类型)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 字节(内容):
    try:
        return bytes(内容)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 下一个(针对的对象):
    try:
        next(针对的对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 枚举(可迭代对象, 起始=0):
    try:
        return enumerate(可迭代对象, 起始)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 拉链(*可迭代对象):
    try:
        return zip(*可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 切片(开始=None, 结束=None, 步长=None):
    try:
        return slice(开始, 结束, 步长)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 复数(实部=0, 虚部=0):
    try:
        return complex(实部, 虚部)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 可调用(对象):
    try:
        return callable(对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 子类检查(子类, 父类):
    try:
        return issubclass(子类, 父类)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 设置属性(对象, 属性名, 值):
    try:
        setattr(对象, 属性名, 值)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 检查属性(对象, 属性名):
    try:
        return hasattr(对象, 属性名)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 删除属性(对象, 属性名):
    try:
        delattr(对象, 属性名)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 表达式执行(表达式):
    try:
        return eval(表达式)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 迭代器(可迭代对象):
    try:
        return iter(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 全局变量列表():
    try:
        return globals()
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 局部变量列表():
    try:
        return locals()
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 哈希值(对象):
    try:
        return hash(对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
