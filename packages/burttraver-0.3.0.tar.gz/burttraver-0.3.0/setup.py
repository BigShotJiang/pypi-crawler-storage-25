from setuptools import setup
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()
setup(
    name="BurtTRAVER",
    version="0.3.0",
    py_modules=['core'],
    author="BURTTTRAVER",
    author_email="13149412996@163.com",
    description="中文Python内置函数封装库，让你用中文写代码",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://github.com/your-username/BurtTRAVER",
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
