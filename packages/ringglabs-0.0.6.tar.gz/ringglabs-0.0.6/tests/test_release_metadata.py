from pathlib import Path
import tomllib


ROOT = Path(__file__).resolve().parents[1]


def test_pyproject_declares_supported_python_and_os_matrix():
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")

    assert 'requires-python = ">=3.10"' in pyproject
    assert '"Programming Language :: Python :: 3.10"' in pyproject
    assert '"Programming Language :: Python :: 3.11"' in pyproject
    assert '"Programming Language :: Python :: 3.12"' in pyproject
    assert '"Programming Language :: Python :: 3.13"' in pyproject
    assert '"Operating System :: Microsoft :: Windows"' in pyproject
    assert '"Operating System :: MacOS :: MacOS X"' in pyproject
    assert '"Operating System :: POSIX :: Linux"' in pyproject


def test_pyproject_uses_readme_markdown_for_pypi_long_description():
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    readme = pyproject["project"]["readme"]

    assert isinstance(readme, dict)
    assert readme["file"] == "RELEASE_DOCUMENTATION.md"
    assert readme["content-type"] == "text/markdown"


def test_release_workflow_uses_testpypi_then_pypi():
    publish = (ROOT / ".github" / "workflows" / "publish.yml").read_text(encoding="utf-8")

    assert "workflow_dispatch" in publish
    assert "publish-testpypi" in publish
    assert "repository-url: https://test.pypi.org/legacy/" in publish
    assert "publish-pypi" in publish
    assert "environment: pypi" in publish


def test_ci_workflow_covers_supported_os_and_python_versions():
    ci = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")

    assert "ubuntu-latest" in ci
    assert "macos-latest" in ci
    assert "windows-latest" in ci
    assert '"3.10"' in ci
    assert '"3.11"' in ci
    assert '"3.12"' in ci
    assert '"3.13"' in ci
    assert "ubuntu-20.04" in ci
