from ringglabs.stt import StreamOptions


def test_stream_options_to_start_config_maps_fields():
    options = StreamOptions(
        sample_rate=16000,
        encoding="int16",
        language="en",
        mode="on_final",
        vad_tail_sil_ms=320,
        vad_confidence=0.72,
        enable_cap_punc=False,
        accept_client_vad_events=True,
    )
    start = options.to_start_config()
    assert start.accept_client_vad_events is True
    assert start.mode == "on_final"
    assert start.language == "en"
    assert start.vad_tail_sil_ms == 320
    assert start.vad_confidence == 0.72


def test_stream_options_allows_arbitrary_language_passthrough():
    cfg = StreamOptions(language="fr").to_start_config()
    payload = cfg.to_payload()
    assert payload["language"] == "fr"


def test_stream_options_allows_passthrough_values_for_proxy_validation():
    cfg = StreamOptions().to_start_config()
    cfg.mode = "custom_mode"
    cfg.vad_tail_sil_ms = 123
    cfg.vad_confidence = 9.9
    payload = cfg.to_payload()
    assert payload["mode"] == "custom_mode"
    assert payload["vad_tail_sil_ms"] == 123
    assert payload["vad_confidence"] == 9.9
