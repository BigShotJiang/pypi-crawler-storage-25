import pytest
import httpx

from ringglabs.stt import ApiError, AsyncClient, Client, ProtocolError


def test_rest_public_surface():
    client = Client(base_url="https://api.example.com")
    assert hasattr(client, "transcribe")
    assert hasattr(client, "health")
    assert hasattr(client, "_transcribe_file")
    assert hasattr(client, "_transcribe_bytes")
    assert hasattr(client, "_transcribe_fileobj")
    assert not hasattr(client, "transcribe_file")
    assert not hasattr(client, "transcribe_bytes")
    assert not hasattr(client, "transcribe_fileobj")


def test_sync_transcribe_uses_custom_endpoint(monkeypatch, tmp_path):
    audio_path = tmp_path / "sample.wav"
    audio_path.write_bytes(b"RIFF....WAVEfmt ")

    captured = {}

    def fake_post(self, url, **kwargs):
        captured["url"] = url
        captured["headers"] = kwargs.get("headers")
        payload = {
            "status": "success",
            "transcription": "hello",
            "is_final": True,
            "language": "en",
            "duration_seconds": 1.1,
            "processing_time_seconds": 0.2,
            "request_id": "req_1",
        }
        return httpx.Response(status_code=200, json=payload)

    monkeypatch.setattr(httpx.Client, "post", fake_post, raising=True)

    client = Client(
        base_url="https://api.example.com",
        api_key="rk_test",
    )
    result = client.transcribe(audio_path, language="en")
    assert captured["url"] == "http://api.example.com/parrot-stt/v1/transcriptions"
    assert captured["headers"]["x-api-key"] == "rk_test"
    assert result.transcription == "hello"
    assert result.raw["request_id"] == "req_1"


def test_sync_health_uses_health_endpoint(monkeypatch):
    captured = {}

    def fake_get(self, url, **kwargs):
        captured["url"] = url
        captured["headers"] = kwargs.get("headers")
        return httpx.Response(status_code=200, json={"status": "ok", "service": "proxy"})

    monkeypatch.setattr(httpx.Client, "get", fake_get, raising=True)

    client = Client(
        base_url="https://api.example.com",
        api_key="rk_test",
    )
    result = client.health()
    assert captured["url"] == "http://api.example.com/health"
    assert captured["headers"]["x-api-key"] == "rk_test"
    assert result["status"] == "ok"


def test_sync_health_raises_api_error(monkeypatch):
    def fake_get(self, url, **kwargs):
        return httpx.Response(
            status_code=500,
            json={"detail": "internal error", "code": "INTERNAL_ERROR"},
        )

    monkeypatch.setattr(httpx.Client, "get", fake_get, raising=True)

    client = Client(base_url="https://api.example.com")
    with pytest.raises(ApiError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 500


def test_sync_health_raises_protocol_error_on_non_object_json(monkeypatch):
    def fake_get(self, url, **kwargs):
        return httpx.Response(status_code=200, json=["ok"])

    monkeypatch.setattr(httpx.Client, "get", fake_get, raising=True)

    client = Client(base_url="https://api.example.com")
    with pytest.raises(ProtocolError):
        client.health()


@pytest.mark.asyncio
async def test_async_health_uses_health_endpoint(monkeypatch):
    captured = {}

    async def fake_get(self, url, **kwargs):
        captured["url"] = url
        captured["headers"] = kwargs.get("headers")
        return httpx.Response(status_code=200, json={"status": "ok"})

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get, raising=True)

    client = AsyncClient(
        base_url="https://api.example.com",
        api_key="rk_test",
    )
    result = await client.health()
    await client.close()
    assert captured["url"] == "http://api.example.com/health"
    assert captured["headers"]["x-api-key"] == "rk_test"
    assert result["status"] == "ok"


@pytest.mark.asyncio
async def test_async_health_raises_protocol_error_on_non_object_json(monkeypatch):
    async def fake_get(self, url, **kwargs):
        return httpx.Response(status_code=200, json=["ok"])

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get, raising=True)

    client = AsyncClient(base_url="https://api.example.com")
    with pytest.raises(ProtocolError):
        await client.health()
    await client.close()
