from ringglabs.stt.config import ClientConfig, DEFAULT_BASE_URL


def test_client_config_uses_default_base_url():
    cfg = ClientConfig()
    assert cfg.base_url == DEFAULT_BASE_URL
    assert cfg.rest_url == "http://prod-api.ringg.ai/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://prod-api.ringg.ai/parrot-stt/v1/stream"
    assert cfg.health_url == "http://prod-api.ringg.ai/health"


def test_client_config_builds_urls_from_base_with_scheme():
    cfg = ClientConfig(base_url="http://localhost:7860")
    assert cfg.base_url == "localhost:7860"
    assert cfg.rest_url == "http://localhost:7860/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://localhost:7860/parrot-stt/v1/stream"
    assert cfg.health_url == "http://localhost:7860/health"


def test_client_config_builds_urls_from_base_without_scheme():
    cfg = ClientConfig(base_url="api.example.com")
    assert cfg.base_url == "api.example.com"
    assert cfg.rest_url == "http://api.example.com/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://api.example.com/parrot-stt/v1/stream"
    assert cfg.health_url == "http://api.example.com/health"


def test_client_config_strips_https_scheme_and_path():
    cfg = ClientConfig(base_url="https://api.example.com/some/path?x=1")
    assert cfg.base_url == "api.example.com"
    assert cfg.rest_url == "http://api.example.com/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://api.example.com/parrot-stt/v1/stream"
    assert cfg.health_url == "http://api.example.com/health"


def test_client_config_strips_ws_scheme():
    cfg = ClientConfig(base_url="ws://example.com:9000")
    assert cfg.base_url == "example.com:9000"
    assert cfg.rest_url == "http://example.com:9000/parrot-stt/v1/transcriptions"
    assert cfg.ws_url == "ws://example.com:9000/parrot-stt/v1/stream"
    assert cfg.health_url == "http://example.com:9000/health"


def test_client_config_rejects_unsupported_scheme():
    try:
        ClientConfig(base_url="ftp://example.com")
        assert False, "Expected ValueError for unsupported scheme"
    except ValueError as exc:
        assert "Unsupported base_url scheme" in str(exc)


def test_client_config_rejects_empty_host():
    try:
        ClientConfig(base_url="https://")
        assert False, "Expected ValueError for empty host"
    except ValueError as exc:
        assert "base_url must include host" in str(exc)
