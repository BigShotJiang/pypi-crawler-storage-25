import pytest

from ringglabs.stt._serialization import parse_json_message, parse_ws_event
from ringglabs.stt.errors import ProtocolError
from ringglabs.stt.models import ErrorEvent, TranscriptEvent


def test_parse_ws_transcript_event():
    payload = {
        "type": "transcript",
        "transcription": "hello",
        "is_final": True,
        "language": "en",
        "request_id": "r1",
        "segment_idx": 1,
        "compute_latency_ms": 12.2,
    }
    event = parse_ws_event(payload)
    assert isinstance(event, TranscriptEvent)
    assert event.transcription == "hello"
    assert event.is_final is True


def test_parse_ws_error_event():
    payload = {"type": "error", "detail": "bad request", "code": "INVALID_PARAMS", "status_code": 400}
    event = parse_ws_event(payload)
    assert isinstance(event, ErrorEvent)
    assert event.code == "INVALID_PARAMS"
    assert event.status_code == 400


def test_parse_invalid_json_raises_protocol_error():
    with pytest.raises(ProtocolError):
        parse_json_message("{invalid")
