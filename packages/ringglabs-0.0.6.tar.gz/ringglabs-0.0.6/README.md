# RinggLabs SDK

Use these docs:
- [RELEASE_DOCUMENTATION.md](RELEASE_DOCUMENTATION.md): public SDK usage and API guide.
- [DEV_README.md](DEV_README.md): developer setup, testing, and release workflow.
