"""Configuration objects for SDK clients."""

from dataclasses import dataclass, field
from typing import Mapping
from urllib.parse import urljoin, urlparse

import httpx

DEFAULT_BASE_URL = "prod-api.ringg.ai"
DEFAULT_REST_PATH = "/parrot-stt/v1/transcriptions"
DEFAULT_WS_PATH = "/parrot-stt/v1/stream"
DEFAULT_HEALTH_PATH = "/health"


def _normalize_base_url(base_url: str) -> str:
    raw = (base_url or "").strip()
    if not raw:
        raise ValueError("base_url must include host, e.g. localhost:7860")

    if "://" in raw:
        scheme, remainder = raw.split("://", 1)
        normalized_scheme = scheme.lower()
        if normalized_scheme not in {"http", "https", "ws", "wss"}:
            raise ValueError(f"Unsupported base_url scheme: {scheme!r}")
        raw = remainder

    parsed = urlparse(f"//{raw}")
    host = parsed.netloc.strip()
    if not host:
        raise ValueError("base_url must include host, e.g. localhost:7860")
    if any(ch.isspace() for ch in host):
        raise ValueError("base_url must not contain whitespace")
    return host


@dataclass(slots=True)
class TimeoutConfig:
    """Timeouts used by REST and WebSocket operations."""

    connect: float = 10.0
    read: float = 10.0
    write: float = 10.0
    pool: float = 10.0
    ws_open: float = 10.0
    ws_recv: float = 30.0
    ws_close: float = 10.0

    def as_httpx_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(
            timeout=None,
            connect=self.connect,
            read=self.read,
            write=self.write,
            pool=self.pool,
        )


@dataclass(slots=True)
class ClientConfig:
    """Client-level configuration and defaults."""

    base_url: str | None = DEFAULT_BASE_URL
    api_key: str | None = None
    timeout: TimeoutConfig = field(default_factory=TimeoutConfig)
    default_headers: Mapping[str, str] | None = None

    def __post_init__(self) -> None:
        if self.base_url is None:
            self.base_url = DEFAULT_BASE_URL
        self.base_url = _normalize_base_url(self.base_url)

    @staticmethod
    def _join(base: str, path: str) -> str:
        root = base if base.endswith("/") else f"{base}/"
        rel = path[1:] if path.startswith("/") else path
        return urljoin(root, rel)

    @property
    def rest_url(self) -> str:
        assert self.base_url is not None
        return self._join(f"http://{self.base_url}", DEFAULT_REST_PATH)

    @property
    def ws_url(self) -> str:
        assert self.base_url is not None
        return self._join(f"ws://{self.base_url}", DEFAULT_WS_PATH)

    @property
    def health_url(self) -> str:
        assert self.base_url is not None
        return self._join(f"http://{self.base_url}", DEFAULT_HEALTH_PATH)

    def resolve_api_key(self, override: str | None = None) -> str | None:
        return override if override is not None else self.api_key
