"""Optional retry helpers (opt-in only)."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


async def async_retry(
    func: Callable[[], Awaitable[T]],
    *,
    attempts: int = 3,
    initial_backoff_sec: float = 0.25,
    max_backoff_sec: float = 2.0,
    retry_on: tuple[type[BaseException], ...] = (Exception,),
) -> T:
    """Retry helper for async operations.

    This helper is not used implicitly by the SDK.
    """
    if attempts < 1:
        raise ValueError("attempts must be >= 1")
    delay = initial_backoff_sec
    last_error: BaseException | None = None
    for _ in range(attempts):
        try:
            return await func()
        except retry_on as exc:  # pragma: no cover - branch depends on caller inputs.
            last_error = exc
            await asyncio.sleep(delay)
            delay = min(delay * 2.0, max_backoff_sec)
    assert last_error is not None
    raise last_error


def retry(
    func: Callable[[], T],
    *,
    attempts: int = 3,
    initial_backoff_sec: float = 0.25,
    max_backoff_sec: float = 2.0,
    retry_on: tuple[type[BaseException], ...] = (Exception,),
) -> T:
    """Retry helper for sync operations.

    This helper is not used implicitly by the SDK.
    """
    if attempts < 1:
        raise ValueError("attempts must be >= 1")
    delay = initial_backoff_sec
    last_error: BaseException | None = None
    for _ in range(attempts):
        try:
            return func()
        except retry_on as exc:  # pragma: no cover - branch depends on caller inputs.
            last_error = exc
            time.sleep(delay)
            delay = min(delay * 2.0, max_backoff_sec)
    assert last_error is not None
    raise last_error
