"""Async STT client."""

from __future__ import annotations

from pathlib import Path
from typing import BinaryIO

from ._http import AsyncHttpTransport
from ._io import read_audio_source
from ._ws_async import AsyncStreamSession
from .config import ClientConfig, TimeoutConfig, DEFAULT_BASE_URL
from .models import (
    FileSource,
    RestTranscriptionResult,
    StreamOptions,
    TranscriptionOptions,
)


class AsyncClient:
    """Async RinggLabs STT client."""

    def __init__(
        self,
        *,
        base_url: str | None = DEFAULT_BASE_URL,
        api_key: str | None = None,
        timeout: TimeoutConfig | None = None,
        default_headers: dict[str, str] | None = None,
    ):
        self.config = ClientConfig(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout or TimeoutConfig(),
            default_headers=default_headers,
        )
        self._http = AsyncHttpTransport(self.config)

    async def __aenter__(self) -> "AsyncClient":
        await self._http.open()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.close()

    async def health(self, *, api_key: str | None = None) -> dict:
        return await self._http.health_check(api_key_override=api_key)

    async def transcribe(
        self,
        source: FileSource,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        audio, detected_name = read_audio_source(source, fallback_filename=filename or "audio.wav")
        options = TranscriptionOptions(
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename or detected_name,
            content_type=content_type,
        )
        return await self._http.transcribe_bytes(audio, options, api_key_override=api_key)

    async def _transcribe_file(
        self,
        file_path: str | Path,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return await self.transcribe(
            file_path,
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            content_type=content_type,
        )

    async def _transcribe_bytes(
        self,
        audio: bytes | bytearray,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str = "audio.wav",
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return await self.transcribe(
            bytes(audio),
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename,
            content_type=content_type,
        )

    async def _transcribe_fileobj(
        self,
        fileobj: BinaryIO,
        *,
        language: str = "hi",
        enable_cap_punc: bool = True,
        api_key: str | None = None,
        filename: str | None = None,
        content_type: str = "audio/wav",
    ) -> RestTranscriptionResult:
        return await self.transcribe(
            fileobj,
            language=language,
            enable_cap_punc=enable_cap_punc,
            api_key=api_key,
            filename=filename,
            content_type=content_type,
        )

    def _open_stream(self, options: StreamOptions, *, api_key: str | None = None) -> AsyncStreamSession:
        start_config = options.to_start_config()
        return AsyncStreamSession(
            client_config=self.config,
            start_config=start_config,
            api_key_override=api_key,
        )

    def stream(
        self,
        *,
        sample_rate: int = 16000,
        encoding: str = "int16",
        language: str = "hi",
        mode: str = "stream",
        vad_tail_sil_ms: int = 200,
        vad_confidence: float = 0.55,
        enable_cap_punc: bool = True,
        accept_client_vad_events: bool = False,
        api_key: str | None = None,
    ) -> AsyncStreamSession:
        """Create a stream session with high-level options."""
        return self._open_stream(
            StreamOptions(
                sample_rate=sample_rate,
                encoding=encoding,
                language=language,
                mode=mode,
                vad_tail_sil_ms=vad_tail_sil_ms,
                vad_confidence=vad_confidence,
                enable_cap_punc=enable_cap_punc,
                accept_client_vad_events=accept_client_vad_events,
                api_key=api_key,
            ),
            api_key=api_key,
        )
