"""Typed request/response models for SDK users."""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import BinaryIO

from .enums import Encoding, Language, Mode


FileSource = str | Path | bytes | bytearray | BinaryIO


@dataclass(slots=True)
class StartConfig:
    """WebSocket start payload configuration."""

    sample_rate: int = 16000
    encoding: Encoding | str = Encoding.INT16
    language: Language | str = Language.HI
    mode: Mode | str = Mode.STREAM
    vad_tail_sil_ms: int = 200
    vad_confidence: float = 0.55
    enable_cap_punc: bool = True
    accept_client_vad_events: bool = False
    api_key: str | None = None

    def to_payload(self, resolved_api_key: str | None = None) -> dict:
        def _to_value(value):
            if isinstance(value, Enum):
                return value.value
            return value

        payload = {
            "type": "start",
            "sample_rate": self.sample_rate,
            "encoding": _to_value(self.encoding),
            "language": _to_value(self.language),
            "mode": _to_value(self.mode),
            "vad_tail_sil_ms": self.vad_tail_sil_ms,
            "vad_confidence": self.vad_confidence,
            "enable_cap_punc": self.enable_cap_punc,
            "accept_client_vad_events": self.accept_client_vad_events,
        }
        api_key = resolved_api_key if resolved_api_key is not None else self.api_key
        if api_key:
            payload["api_key"] = api_key
        return payload


@dataclass(slots=True)
class StreamOptions:
    """High-level streaming options (proxy internals hidden)."""

    sample_rate: int = 16000
    encoding: Encoding | str = Encoding.INT16
    language: Language | str = Language.HI
    mode: Mode | str = Mode.STREAM
    vad_tail_sil_ms: int = 200
    vad_confidence: float = 0.55
    enable_cap_punc: bool = True
    accept_client_vad_events: bool = False
    api_key: str | None = None

    def to_start_config(self) -> StartConfig:
        return StartConfig(
            sample_rate=self.sample_rate,
            encoding=self.encoding,
            language=self.language,
            mode=self.mode,
            vad_tail_sil_ms=self.vad_tail_sil_ms,
            vad_confidence=self.vad_confidence,
            enable_cap_punc=self.enable_cap_punc,
            accept_client_vad_events=self.accept_client_vad_events,
            api_key=self.api_key,
        )


@dataclass(slots=True)
class TranscriptionOptions:
    """REST transcription options."""

    language: Language | str = Language.HI
    enable_cap_punc: bool = True
    api_key: str | None = None
    filename: str = "audio.wav"
    content_type: str = "audio/wav"


@dataclass(slots=True)
class RestTranscriptionResult:
    status: str
    transcription: str
    is_final: bool
    language: str
    duration_seconds: float
    processing_time_seconds: float
    request_id: str
    raw: dict


@dataclass(slots=True)
class ReadyEvent:
    type: str
    request_id: str
    sample_rate: int
    language: str
    mode: str
    enable_cap_punc: bool
    vad_tail_sil_ms: int
    vad_confidence: float
    accept_client_vad_events: bool
    raw: dict


@dataclass(slots=True)
class TranscriptEvent:
    type: str
    transcription: str
    is_final: bool
    language: str
    request_id: str | None
    segment_idx: int | None
    segments: int | None
    compute_latency_ms: float | None
    audio_duration_sec: float | None
    transcribed_audio_duration_sec: float | None
    processing_time_ms: float | None
    raw: dict


@dataclass(slots=True)
class AckEvent:
    type: str
    ack_for: str
    state: str
    raw: dict


@dataclass(slots=True)
class PongEvent:
    type: str
    timestamp: float
    raw: dict


@dataclass(slots=True)
class ErrorEvent:
    type: str
    detail: str
    code: str | None
    status_code: int | None
    raw: dict


WsEvent = ReadyEvent | TranscriptEvent | AckEvent | PongEvent | ErrorEvent
