"""Sync WebSocket streaming session implementation."""

from __future__ import annotations

from builtins import TimeoutError as BuiltinTimeoutError
import json
from typing import Iterator

from websockets.exceptions import ConnectionClosed

try:
    from websockets.sync.client import connect as ws_connect
except ImportError:  # pragma: no cover
    ws_connect = None  # type: ignore[assignment]

from ._serialization import parse_json_message, parse_ws_event
from .config import ClientConfig
from .errors import ApiError, ProtocolError, TimeoutError, TransportError
from .models import ErrorEvent, ReadyEvent, StartConfig, WsEvent


class StreamSession:
    """Sync context-managed WebSocket stream session."""

    def __init__(
        self,
        client_config: ClientConfig,
        start_config: StartConfig,
        *,
        api_key_override: str | None = None,
    ):
        self._client_config = client_config
        self._start_config = start_config
        self._api_key_override = api_key_override
        self._ws = None
        self.ready_event: ReadyEvent | None = None

    def __enter__(self) -> "StreamSession":
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def open(self) -> ReadyEvent:
        if ws_connect is None:
            raise TransportError(
                "websockets sync client is unavailable; install websockets>=12"
            )
        if self._ws is not None:
            return self.ready_event if self.ready_event is not None else self._handshake()
        uri = self._client_config.ws_url
        try:
            self._ws = ws_connect(
                uri,
                open_timeout=self._client_config.timeout.ws_open,
                close_timeout=self._client_config.timeout.ws_close,
                max_size=None,
            )
        except BuiltinTimeoutError as exc:
            raise TimeoutError("WebSocket connection timed out") from exc
        except Exception as exc:
            raise TransportError(f"WebSocket connection failed: {exc}") from exc
        return self._handshake()

    def _handshake(self) -> ReadyEvent:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        resolved_key = self._client_config.resolve_api_key(self._api_key_override)
        payload = self._start_config.to_payload(resolved_api_key=resolved_key)
        self._ws.send(json.dumps(payload, ensure_ascii=False))
        try:
            raw = self._ws.recv(timeout=self._client_config.timeout.ws_recv)
        except BuiltinTimeoutError as exc:
            raise TimeoutError("Timed out waiting for server ready message") from exc
        except Exception as exc:
            raise TransportError(f"Failed during start handshake: {exc}") from exc

        event = self._parse_raw_event(raw)
        if isinstance(event, ErrorEvent):
            raise ApiError(
                message=event.detail,
                code=event.code,
                status_code=event.status_code,
                payload=event.raw,
            )
        if not isinstance(event, ReadyEvent):
            raise ProtocolError(
                f"Expected first server message to be 'ready', got {event.type!r}"
            )
        self.ready_event = event
        return event

    def send_audio(self, audio_chunk: bytes) -> None:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        if not isinstance(audio_chunk, (bytes, bytearray)):
            raise ProtocolError("audio_chunk must be bytes")
        self._ws.send(bytes(audio_chunk))

    def send_vad_event(self, state: str) -> None:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        self._ws.send(
            json.dumps({"type": "vad_event", "state": str(state)}, ensure_ascii=False)
        )

    def start_speaking(self) -> None:
        self.send_vad_event("user_start_speaking")

    def stop_speaking(self) -> None:
        self.send_vad_event("user_stop_speaking")

    def ping(self) -> None:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        self._ws.send(json.dumps({"type": "ping"}, ensure_ascii=False))

    def end(self, command: str = "end") -> None:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        if command not in {"end", "stop", "exit", "close"}:
            raise ProtocolError("command must be one of: end, stop, exit, close")
        self._ws.send(json.dumps({"type": command}, ensure_ascii=False))

    def recv_event(self) -> WsEvent:
        if self._ws is None:
            raise TransportError("WebSocket is not connected")
        try:
            raw = self._ws.recv(timeout=self._client_config.timeout.ws_recv)
        except BuiltinTimeoutError as exc:
            raise TimeoutError("Timed out waiting for WebSocket message") from exc
        except ConnectionClosed as exc:
            raise TransportError(f"WebSocket connection closed: {exc}") from exc
        return self._parse_raw_event(raw)

    def events(self) -> Iterator[WsEvent]:
        while True:
            try:
                event = self.recv_event()
            except TimeoutError:
                raise
            except TransportError:
                break
            yield event

    def _parse_raw_event(self, raw: str | bytes) -> WsEvent:
        if isinstance(raw, bytes):
            raise ProtocolError("Expected text JSON event from server, got binary frame")
        payload = parse_json_message(raw)
        return parse_ws_event(payload)

    def close(self) -> None:
        if self._ws is not None:
            self._ws.close()
            self._ws = None
