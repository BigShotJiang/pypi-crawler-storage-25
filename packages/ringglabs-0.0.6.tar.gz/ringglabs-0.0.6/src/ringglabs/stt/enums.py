"""Enum types for RinggLabs STT SDK."""

from enum import Enum


class Language(str, Enum):
    HI = "hi"
    EN = "en"


class Mode(str, Enum):
    STREAM = "stream"
    ON_FINAL = "on_final"


class Encoding(str, Enum):
    INT16 = "int16"
    LINEAR16 = "linear16"
    FLOAT32 = "float32"
    INT32 = "int32"


class VadState(str, Enum):
    USER_START_SPEAKING = "user_start_speaking"
    USER_STOP_SPEAKING = "user_stop_speaking"
