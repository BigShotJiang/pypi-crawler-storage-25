"""Payload parsing and model conversion."""

import json
from typing import Any

from .errors import ProtocolError
from .models import (
    AckEvent,
    ErrorEvent,
    PongEvent,
    ReadyEvent,
    RestTranscriptionResult,
    TranscriptEvent,
    WsEvent,
)


def _require_dict(payload: Any, *, label: str) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ProtocolError(f"{label} must be a JSON object")
    return payload


def _require_str(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str):
        raise ProtocolError(f"Expected string field {key!r}")
    return value


def _optional_str(payload: dict[str, Any], key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ProtocolError(f"Expected optional string field {key!r}")
    return value


def _require_bool(payload: dict[str, Any], key: str) -> bool:
    value = payload.get(key)
    if not isinstance(value, bool):
        raise ProtocolError(f"Expected boolean field {key!r}")
    return value


def _optional_float(payload: dict[str, Any], key: str) -> float | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ProtocolError(f"Expected optional float field {key!r}")
    return float(value)


def _optional_int(payload: dict[str, Any], key: str) -> int | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        raise ProtocolError(f"Expected optional integer field {key!r}")
    return value


def parse_json_message(raw_message: str) -> dict[str, Any]:
    try:
        parsed = json.loads(raw_message)
    except json.JSONDecodeError as exc:
        raise ProtocolError(f"Invalid JSON from server: {exc.msg}") from exc
    return _require_dict(parsed, label="message")


def parse_ws_event(payload: dict[str, Any]) -> WsEvent:
    payload = _require_dict(payload, label="ws payload")
    event_type = _require_str(payload, "type")

    if event_type == "ready":
        return ReadyEvent(
            type=event_type,
            request_id=_require_str(payload, "request_id"),
            sample_rate=int(payload.get("sample_rate", 0)),
            language=_require_str(payload, "language"),
            mode=_require_str(payload, "mode"),
            enable_cap_punc=_require_bool(payload, "enable_cap_punc"),
            vad_tail_sil_ms=int(payload.get("vad_tail_sil_ms", 0)),
            vad_confidence=float(payload.get("vad_confidence", 0.0)),
            accept_client_vad_events=_require_bool(payload, "accept_client_vad_events"),
            raw=payload,
        )

    if event_type == "transcript":
        return TranscriptEvent(
            type=event_type,
            transcription=_require_str(payload, "transcription"),
            is_final=_require_bool(payload, "is_final"),
            language=_require_str(payload, "language"),
            request_id=_optional_str(payload, "request_id"),
            segment_idx=_optional_int(payload, "segment_idx"),
            segments=_optional_int(payload, "segments"),
            compute_latency_ms=_optional_float(payload, "compute_latency_ms"),
            audio_duration_sec=_optional_float(payload, "audio_duration_sec"),
            transcribed_audio_duration_sec=_optional_float(
                payload, "transcribed_audio_duration_sec"
            ),
            processing_time_ms=_optional_float(payload, "processing_time_ms"),
            raw=payload,
        )

    if event_type == "ack":
        return AckEvent(
            type=event_type,
            ack_for=_require_str(payload, "ack_for"),
            state=_require_str(payload, "state"),
            raw=payload,
        )

    if event_type == "pong":
        ts = payload.get("timestamp")
        if not isinstance(ts, (int, float)) or isinstance(ts, bool):
            raise ProtocolError("Expected numeric field 'timestamp' in pong event")
        return PongEvent(type=event_type, timestamp=float(ts), raw=payload)

    if event_type == "error":
        status_code = payload.get("status_code")
        if status_code is not None and (
            not isinstance(status_code, int) or isinstance(status_code, bool)
        ):
            raise ProtocolError("Expected optional integer field 'status_code' in error event")
        return ErrorEvent(
            type=event_type,
            detail=_require_str(payload, "detail"),
            code=_optional_str(payload, "code"),
            status_code=status_code,
            raw=payload,
        )

    raise ProtocolError(f"Unknown event type from server: {event_type!r}")


def parse_rest_result(payload: dict[str, Any]) -> RestTranscriptionResult:
    payload = _require_dict(payload, label="REST response")
    return RestTranscriptionResult(
        status=_require_str(payload, "status"),
        transcription=_require_str(payload, "transcription"),
        is_final=_require_bool(payload, "is_final"),
        language=_require_str(payload, "language"),
        duration_seconds=float(payload.get("duration_seconds", 0.0)),
        processing_time_seconds=float(payload.get("processing_time_seconds", 0.0)),
        request_id=_require_str(payload, "request_id"),
        raw=payload,
    )
