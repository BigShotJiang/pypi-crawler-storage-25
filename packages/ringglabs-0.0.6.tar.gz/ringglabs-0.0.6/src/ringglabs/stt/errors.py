"""Error taxonomy for RinggLabs STT SDK."""

from dataclasses import dataclass
from typing import Any


class RinggLabsError(Exception):
    """Base exception for all SDK errors."""


class ValidationError(RinggLabsError):
    """Raised for invalid SDK input values or types."""


@dataclass(slots=True)
class ApiError(RinggLabsError):
    """Raised when server returns an error payload or non-2xx HTTP response."""

    message: str
    status_code: int | None = None
    code: str | None = None
    payload: dict[str, Any] | None = None

    def __str__(self) -> str:
        details = [self.message]
        if self.code:
            details.append(f"code={self.code}")
        if self.status_code is not None:
            details.append(f"status={self.status_code}")
        return " | ".join(details)


class TransportError(RinggLabsError):
    """Raised on network failures."""


class TimeoutError(TransportError):
    """Raised when a request or receive operation times out."""


class ProtocolError(RinggLabsError):
    """Raised for incompatible or malformed server messages."""


class AuthenticationError(ApiError):
    """Raised for authentication-related server responses."""
