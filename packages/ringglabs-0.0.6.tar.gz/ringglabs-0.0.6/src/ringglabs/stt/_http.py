"""REST transport implementations."""

from __future__ import annotations

from enum import Enum
from typing import Any

import httpx

from ._serialization import parse_rest_result
from .config import ClientConfig
from .errors import (
    ApiError,
    AuthenticationError,
    ProtocolError,
    TimeoutError,
    TransportError,
)
from .models import RestTranscriptionResult, TranscriptionOptions


def _to_wire(value: Any) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    return str(value)


def _make_headers(config: ClientConfig, api_key: str | None) -> dict[str, str]:
    headers = dict(config.default_headers or {})
    if api_key:
        headers["x-api-key"] = api_key
    return headers


def _build_api_error(response: httpx.Response, payload: dict[str, Any] | None) -> ApiError:
    detail = None
    code = None
    if payload is not None:
        detail = payload.get("detail")
        code = payload.get("code")
    message = str(detail) if detail else (response.text.strip() or "request failed")
    error_cls = AuthenticationError if response.status_code in {401, 402} else ApiError
    return error_cls(
        message=message,
        status_code=response.status_code,
        code=str(code) if code is not None else None,
        payload=payload,
    )


class AsyncHttpTransport:
    """Async HTTP transport for SDK REST methods."""

    def __init__(self, config: ClientConfig):
        self._config = config
        self._client: httpx.AsyncClient | None = None

    async def open(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self._config.timeout.as_httpx_timeout(),
            )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def transcribe_bytes(
        self,
        audio: bytes,
        options: TranscriptionOptions,
        *,
        api_key_override: str | None = None,
    ) -> RestTranscriptionResult:
        await self.open()
        assert self._client is not None
        language = _to_wire(options.language)
        resolved_api_key = (
            api_key_override if api_key_override is not None else options.api_key
        )
        headers = _make_headers(self._config, self._config.resolve_api_key(resolved_api_key))

        files = {"file": (options.filename, audio, options.content_type)}
        form = {
            "language": language,
            "enable_cap_punc": "true" if options.enable_cap_punc else "false",
        }

        try:
            response = await self._client.post(
                self._config.rest_url,
                headers=headers,
                data=form,
                files=files,
                timeout=self._config.timeout.as_httpx_timeout(),
            )
        except httpx.TimeoutException as exc:
            raise TimeoutError("REST transcription request timed out") from exc
        except httpx.RequestError as exc:
            raise TransportError(f"REST transcription request failed: {exc}") from exc

        payload: dict[str, Any] | None = None
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                payload = parsed
        except Exception:
            payload = None

        if response.status_code >= 400:
            raise _build_api_error(response, payload)
        if payload is None:
            raise ProtocolError("REST response is not a JSON object")
        return parse_rest_result(payload)

    async def health_check(self, *, api_key_override: str | None = None) -> dict[str, Any]:
        await self.open()
        assert self._client is not None
        headers = _make_headers(self._config, self._config.resolve_api_key(api_key_override))
        try:
            response = await self._client.get(
                self._config.health_url,
                headers=headers,
                timeout=self._config.timeout.as_httpx_timeout(),
            )
        except httpx.TimeoutException as exc:
            raise TimeoutError("Health check request timed out") from exc
        except httpx.RequestError as exc:
            raise TransportError(f"Health check request failed: {exc}") from exc

        payload: dict[str, Any] | None = None
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                payload = parsed
        except Exception:
            payload = None

        if response.status_code >= 400:
            raise _build_api_error(response, payload)
        if payload is None:
            raise ProtocolError("Health response is not a JSON object")
        return payload


class SyncHttpTransport:
    """Sync HTTP transport for SDK REST methods."""

    def __init__(self, config: ClientConfig):
        self._config = config
        self._client: httpx.Client | None = None

    def open(self) -> None:
        if self._client is None:
            self._client = httpx.Client(
                timeout=self._config.timeout.as_httpx_timeout(),
            )

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def transcribe_bytes(
        self,
        audio: bytes,
        options: TranscriptionOptions,
        *,
        api_key_override: str | None = None,
    ) -> RestTranscriptionResult:
        self.open()
        assert self._client is not None
        language = _to_wire(options.language)
        resolved_api_key = (
            api_key_override if api_key_override is not None else options.api_key
        )
        headers = _make_headers(self._config, self._config.resolve_api_key(resolved_api_key))
        files = {"file": (options.filename, audio, options.content_type)}
        form = {
            "language": language,
            "enable_cap_punc": "true" if options.enable_cap_punc else "false",
        }
        try:
            response = self._client.post(
                self._config.rest_url,
                headers=headers,
                data=form,
                files=files,
                timeout=self._config.timeout.as_httpx_timeout(),
            )
        except httpx.TimeoutException as exc:
            raise TimeoutError("REST transcription request timed out") from exc
        except httpx.RequestError as exc:
            raise TransportError(f"REST transcription request failed: {exc}") from exc

        payload: dict[str, Any] | None = None
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                payload = parsed
        except Exception:
            payload = None

        if response.status_code >= 400:
            raise _build_api_error(response, payload)
        if payload is None:
            raise ProtocolError("REST response is not a JSON object")
        return parse_rest_result(payload)

    def health_check(self, *, api_key_override: str | None = None) -> dict[str, Any]:
        self.open()
        assert self._client is not None
        headers = _make_headers(self._config, self._config.resolve_api_key(api_key_override))
        try:
            response = self._client.get(
                self._config.health_url,
                headers=headers,
                timeout=self._config.timeout.as_httpx_timeout(),
            )
        except httpx.TimeoutException as exc:
            raise TimeoutError("Health check request timed out") from exc
        except httpx.RequestError as exc:
            raise TransportError(f"Health check request failed: {exc}") from exc

        payload: dict[str, Any] | None = None
        try:
            parsed = response.json()
            if isinstance(parsed, dict):
                payload = parsed
        except Exception:
            payload = None

        if response.status_code >= 400:
            raise _build_api_error(response, payload)
        if payload is None:
            raise ProtocolError("Health response is not a JSON object")
        return payload
