"""IO helpers for REST transcription inputs."""

from pathlib import Path
from .errors import ValidationError
from .models import FileSource


def read_audio_source(source: FileSource, *, fallback_filename: str = "audio.wav") -> tuple[bytes, str]:
    if isinstance(source, (bytes, bytearray)):
        return bytes(source), fallback_filename

    if isinstance(source, (str, Path)):
        path = Path(source)
        if not path.exists():
            raise ValidationError(f"Audio file not found: {path}")
        if not path.is_file():
            raise ValidationError(f"Audio path is not a file: {path}")
        return path.read_bytes(), path.name

    if hasattr(source, "read"):
        content = source.read()  # type: ignore[call-arg]
        if not isinstance(content, (bytes, bytearray)):
            raise ValidationError("File-like source must return bytes from read()")
        filename = getattr(source, "name", fallback_filename)
        filename = Path(filename).name if isinstance(filename, str) else fallback_filename
        return bytes(content), filename

    raise ValidationError(
        "source must be a file path, bytes/bytearray, or binary file-like object"
    )
