# ABOUTME: Tests for the SyncService that discovers and compares forks.
# ABOUTME: Uses a StubGitProvider with canned fork data, no mock framework.

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import pytest

from forkhub.config import SyncSettings
from forkhub.models import (
    CommitInfo,
    CompareResult,
    FileChange,
    ForkInfo,
    ForkPage,
    ForkVitality,
    RateLimitInfo,
    Release,
    RepoInfo,
    SyncStatus,
    TrackedRepo,
    TrackingMode,
)
from forkhub.services.sync import SyncService

if TYPE_CHECKING:
    from forkhub.database import Database

# ---------------------------------------------------------------------------
# Time constants
# ---------------------------------------------------------------------------

_NOW = datetime(2025, 6, 1, tzinfo=UTC)
_ACTIVE_DATE = _NOW - timedelta(days=30)  # 30 days ago = active
_DORMANT_DATE = _NOW - timedelta(days=200)  # 200 days ago = dormant
_DEAD_DATE = _NOW - timedelta(days=400)  # 400 days ago = dead


# ---------------------------------------------------------------------------
# StubGitProvider with fork-related canned data
# ---------------------------------------------------------------------------


class SyncStubGitProvider:
    """Stub provider with rich fork data for sync testing."""

    def __init__(self) -> None:
        self._forks: dict[str, list[ForkInfo]] = {
            "owner/repo-a": [
                ForkInfo(
                    github_id=5001,
                    owner="forker1",
                    full_name="forker1/repo-a",
                    default_branch="main",
                    description="Forker 1's copy",
                    stars=15,
                    last_pushed_at=_ACTIVE_DATE,
                    has_diverged=True,
                    created_at=_NOW - timedelta(days=60),
                ),
                ForkInfo(
                    github_id=5002,
                    owner="forker2",
                    full_name="forker2/repo-a",
                    default_branch="main",
                    description="Forker 2's copy",
                    stars=3,
                    last_pushed_at=_DORMANT_DATE,
                    has_diverged=False,
                    created_at=_NOW - timedelta(days=300),
                ),
                ForkInfo(
                    github_id=5003,
                    owner="forker3",
                    full_name="forker3/repo-a",
                    default_branch="main",
                    description="Forker 3's dead fork",
                    stars=0,
                    last_pushed_at=_DEAD_DATE,
                    has_diverged=False,
                    created_at=_NOW - timedelta(days=500),
                ),
            ],
            "owner/repo-b": [
                ForkInfo(
                    github_id=6001,
                    owner="forker4",
                    full_name="forker4/repo-b",
                    default_branch="main",
                    description="Forker 4's copy",
                    stars=7,
                    last_pushed_at=_ACTIVE_DATE,
                    has_diverged=True,
                    created_at=_NOW - timedelta(days=10),
                ),
            ],
        }
        self._compare_results: dict[str, CompareResult] = {
            "forker1/repo-a": CompareResult(
                ahead_by=5,
                behind_by=2,
                files=[
                    FileChange(
                        filename="src/new_feature.py",
                        status="added",
                        additions=100,
                        deletions=0,
                        patch="+ new code",
                    ),
                ],
                commits=[
                    CommitInfo(
                        sha="abc123",
                        message="Add new feature",
                        author="forker1",
                        authored_at=_NOW,
                    ),
                ],
            ),
        }
        self._releases: dict[str, list[Release]] = {
            "owner/repo-a": [
                Release(
                    tag="v2.0.0",
                    name="Version 2.0",
                    body="Big release",
                    published_at=_NOW - timedelta(days=1),
                    is_prerelease=False,
                ),
                Release(
                    tag="v1.5.0",
                    name="Version 1.5",
                    body="Older release",
                    published_at=_NOW - timedelta(days=60),
                    is_prerelease=False,
                ),
            ],
        }
        # Track the HEAD SHAs that the provider reports
        self._head_shas: dict[str, str] = {
            "forker1/repo-a": "new-sha-forker1",
            "forker2/repo-a": "unchanged-sha-forker2",
            "forker3/repo-a": "new-sha-forker3",
            "forker4/repo-b": "new-sha-forker4",
        }
        # Flag to simulate errors for specific forks
        self._error_forks: set[str] = set()
        # Mapping of full_name -> HTTP status code for repos that should error
        self._error_repos: dict[str, int] = {}
        # Extra user repos for discovery testing
        self._user_repos: dict[str, list[RepoInfo]] = {}

    async def get_user_repos(self, username: str) -> list[RepoInfo]:
        return self._user_repos.get(username, [])

    async def get_repo(self, owner: str, repo: str) -> RepoInfo:
        full_name = f"{owner}/{repo}"
        if full_name in self._error_repos:
            exc = RuntimeError(f"HTTP {self._error_repos[full_name]} for {full_name}")
            exc.status_code = self._error_repos[full_name]  # type: ignore[attr-defined]
            raise exc
        return RepoInfo(
            github_id=hash(full_name) % 100000,
            owner=owner,
            name=repo,
            full_name=full_name,
            default_branch="main",
            description=None,
            is_fork=False,
            parent_full_name=None,
            stars=0,
            forks_count=0,
            last_pushed_at=_NOW,
        )

    async def get_forks(self, owner: str, repo: str, *, page: int = 1) -> ForkPage:
        full_name = f"{owner}/{repo}"
        if full_name in self._error_repos:
            exc = RuntimeError(f"HTTP {self._error_repos[full_name]} for {full_name}")
            exc.status_code = self._error_repos[full_name]  # type: ignore[attr-defined]
            raise exc
        forks = self._forks.get(full_name, [])
        return ForkPage(
            forks=forks,
            total_count=len(forks),
            page=1,
            has_next=False,
        )

    async def compare(self, owner: str, repo: str, base: str, head: str) -> CompareResult:
        # The head parameter encodes the fork owner: "forker1:main"
        fork_owner = head.split(":")[0]
        fork_full = f"{fork_owner}/{repo}"

        if fork_full in self._error_forks:
            raise RuntimeError(f"Simulated API error for {fork_full}")

        if fork_full in self._compare_results:
            return self._compare_results[fork_full]
        return CompareResult(ahead_by=0, behind_by=0, files=[], commits=[])

    async def get_releases(
        self, owner: str, repo: str, *, since: datetime | None = None
    ) -> list[Release]:
        full_name = f"{owner}/{repo}"
        releases = self._releases.get(full_name, [])
        if since is not None:
            releases = [r for r in releases if r.published_at > since]
        return releases

    async def get_commit_messages(
        self, owner: str, repo: str, *, since: str | None = None
    ) -> list[CommitInfo]:
        return []

    async def get_file_diff(self, owner: str, repo: str, base: str, head: str, path: str) -> str:
        return ""

    async def get_rate_limit(self) -> RateLimitInfo:
        return RateLimitInfo(limit=5000, remaining=4999, reset_at=_NOW)

    def get_head_sha(self, fork_full_name: str) -> str | None:
        """Helper for tests to look up the SHA a fork should have."""
        return self._head_shas.get(fork_full_name)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def provider() -> SyncStubGitProvider:
    return SyncStubGitProvider()


@pytest.fixture
def settings() -> SyncSettings:
    return SyncSettings(max_forks_per_repo=5000)


@pytest.fixture
def sync_service(
    db: Database, provider: SyncStubGitProvider, settings: SyncSettings
) -> SyncService:
    return SyncService(db=db, provider=provider, settings=settings, clock=_NOW)


async def _insert_tracked_repo(
    db: Database,
    owner: str = "owner",
    name: str = "repo-a",
    github_id: int = 1001,
    last_synced_at: datetime | None = None,
    sync_status: str = "ok",
    last_sync_error: str | None = None,
) -> TrackedRepo:
    """Helper to insert a tracked repo into the database."""
    repo = TrackedRepo(
        github_id=github_id,
        owner=owner,
        name=name,
        full_name=f"{owner}/{name}",
        tracking_mode=TrackingMode.WATCHED,
        default_branch="main",
        last_synced_at=last_synced_at,
        sync_status=SyncStatus(sync_status),
        last_sync_error=last_sync_error,
    )
    d = repo.model_dump()
    d["created_at"] = repo.created_at.isoformat()
    d["last_synced_at"] = repo.last_synced_at.isoformat() if repo.last_synced_at else None
    d["sync_status"] = str(repo.sync_status)
    await db.insert_tracked_repo(d)
    return repo


async def _insert_fork_in_db(
    db: Database,
    tracked_repo_id: str,
    github_id: int,
    owner: str,
    full_name: str,
    head_sha: str | None = None,
    stars: int = 0,
    last_pushed_at: datetime | None = None,
) -> dict:
    """Helper to insert a fork record directly into the database."""
    from forkhub.models import Fork

    fork = Fork(
        tracked_repo_id=tracked_repo_id,
        github_id=github_id,
        owner=owner,
        full_name=full_name,
        default_branch="main",
        head_sha=head_sha,
        stars=stars,
        last_pushed_at=last_pushed_at,
    )
    d = fork.model_dump()
    d["created_at"] = fork.created_at.isoformat()
    d["updated_at"] = fork.updated_at.isoformat()
    d["last_pushed_at"] = fork.last_pushed_at.isoformat() if fork.last_pushed_at else None
    await db.insert_fork(d)
    return d


# ---------------------------------------------------------------------------
# Vitality classification
# ---------------------------------------------------------------------------


class TestVitalityClassification:
    async def test_unknown_when_none(self, sync_service: SyncService):
        """A fork with no push date should be classified as unknown."""
        result = sync_service._classify_vitality(None)
        assert result == ForkVitality.UNKNOWN


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestSyncErrorHandling:
    async def test_individual_fork_error_doesnt_stop_sync(
        self, sync_service: SyncService, db: Database, provider: SyncStubGitProvider
    ):
        """An error on one fork's compare should not prevent other forks from syncing."""
        repo = await _insert_tracked_repo(db)
        # Pre-insert forker1 with old SHA to trigger compare, but mark it to error
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo.id,
            github_id=5001,
            owner="forker1",
            full_name="forker1/repo-a",
            head_sha="old-sha",
        )
        provider._error_forks.add("forker1/repo-a")
        result = await sync_service.sync_repo(repo.id)
        # Should have errors but still process other forks
        assert len(result.errors) > 0
        assert "forker1/repo-a" in result.errors[0]
        # forker2 and forker3 should still have been processed (they are new)
        assert result.new_forks == 2


# ---------------------------------------------------------------------------
# Inaccessible repo detection
# ---------------------------------------------------------------------------


class TestInaccessibleRepoDetection:
    async def test_inaccessible_repos_skipped_in_sync_all(
        self, sync_service: SyncService, db: Database, provider: SyncStubGitProvider
    ):
        """sync_all should skip repos with sync_status='inaccessible'."""
        await _insert_tracked_repo(
            db,
            owner="owner",
            name="repo-a",
            github_id=1001,
            sync_status="inaccessible",
            last_sync_error="404",
        )
        await _insert_tracked_repo(
            db,
            owner="owner",
            name="repo-b",
            github_id=1002,
        )
        result = await sync_service.sync_all()
        # Only repo-b should be synced
        assert result.repos_synced == 1
        assert result.results[0].repo_full_name == "owner/repo-b"


# ---------------------------------------------------------------------------
# Reconciliation
# ---------------------------------------------------------------------------


class TestReconciliation:
    async def test_reconcile_phase2_failure_preserves_phase1_results(
        self, sync_service: SyncService, db: Database, provider: SyncStubGitProvider
    ):
        """If Phase 2 (discovery) fails, Phase 1 results should still be returned."""
        repo = await _insert_tracked_repo(
            db,
            sync_status="inaccessible",
            last_sync_error="404",
        )
        # Provider succeeds for get_repo (Phase 1 recovers the repo)
        # but get_user_repos will fail for discovery

        class FailingTracker:
            async def discover_owned_repos(self, username):
                raise ConnectionError("API rate limited")

        result = await sync_service.reconcile(
            username="testuser",
            tracker_service=FailingTracker(),  # type: ignore[arg-type]
        )
        # Phase 1 should have succeeded
        assert repo.full_name in result.repos_recovered
        # Phase 2 failed, so no discovered repos
        assert result.new_repos_discovered == []


# ---------------------------------------------------------------------------
# Analyzer integration (forkhub-hgm)
# ---------------------------------------------------------------------------


class TestSyncAnalyzerIntegration:
    """SyncService must call the injected analyzer when forks change."""

    async def test_sync_invokes_analyzer_when_forks_change(
        self, db: Database, provider: SyncStubGitProvider, settings: SyncSettings
    ):
        """Analyzer.analyze is called once with the changed forks and its
        returned signal count is exposed on the result."""
        from forkhub.models import Signal, SignalCategory

        from .stubs import StubAnalyzer

        repo = await _insert_tracked_repo(db)
        # Pre-seed forker1 with a stale SHA so compare() fires
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo.id,
            github_id=5001,
            owner="forker1",
            full_name="forker1/repo-a",
            head_sha="stale-sha",
        )

        canned_signals = [
            Signal(
                tracked_repo_id=repo.id,
                fork_id=None,
                category=SignalCategory.FEATURE,
                summary="Added X",
                significance=7,
            ),
            Signal(
                tracked_repo_id=repo.id,
                fork_id=None,
                category=SignalCategory.FIX,
                summary="Fixed Y",
                significance=6,
            ),
        ]
        analyzer = StubAnalyzer(signals=canned_signals)

        sync_service = SyncService(
            db=db, provider=provider, settings=settings, clock=_NOW, analyzer=analyzer
        )
        result = await sync_service.sync_repo(repo.id)

        assert len(analyzer.calls) == 1
        call = analyzer.calls[0]
        assert call["repo_full_name"] == "owner/repo-a"
        assert "forker1/repo-a" in call["changed_fork_names"]
        # SyncStubGitProvider seeds two releases for owner/repo-a; both
        # must be passed through to the analyzer.
        assert call["release_count"] == 2
        # Two stub signals were returned → signals_generated == 2
        assert result.signals_generated == 2

    async def test_sync_skips_analyzer_when_no_changed_forks_or_releases(
        self, db: Database, settings: SyncSettings
    ):
        """If nothing diverged and there are no releases, analyzer is not called."""
        from .stubs import StubAnalyzer

        repo = await _insert_tracked_repo(db, owner="owner", name="repo-b", github_id=1002)

        # Pre-seed forker4 with the SHA the provider will report, so no
        # change is detected. repo-b has no releases in SyncStubGitProvider.
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo.id,
            github_id=6001,
            owner="forker4",
            full_name="forker4/repo-b",
            head_sha="new-sha-forker4",
        )

        analyzer = StubAnalyzer()
        sync_service = SyncService(
            db=db,
            provider=SyncStubGitProvider(),
            settings=settings,
            clock=_NOW,
            analyzer=analyzer,
        )
        result = await sync_service.sync_repo(repo.id)

        assert analyzer.calls == []
        assert result.signals_generated == 0

    async def test_sync_handles_analyzer_failure_gracefully(
        self, db: Database, provider: SyncStubGitProvider, settings: SyncSettings
    ):
        """Analyzer exceptions must not abort the sync — record an error."""
        from .stubs import StubAnalyzer

        repo = await _insert_tracked_repo(db)
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo.id,
            github_id=5001,
            owner="forker1",
            full_name="forker1/repo-a",
            head_sha="stale-sha",
        )

        analyzer = StubAnalyzer(raise_error=RuntimeError("LLM budget exhausted"))
        sync_service = SyncService(
            db=db, provider=provider, settings=settings, clock=_NOW, analyzer=analyzer
        )
        result = await sync_service.sync_repo(repo.id)

        assert result.signals_generated == 0
        assert any("Analyzer failed" in e for e in result.errors)
        assert any("LLM budget exhausted" in e for e in result.errors)

    async def test_sync_without_analyzer_is_noop_for_analysis(
        self, sync_service: SyncService, db: Database
    ):
        """SyncService constructed with analyzer=None (the default) must
        still complete normally — no signals generated, no errors."""
        repo = await _insert_tracked_repo(db)
        result = await sync_service.sync_repo(repo.id)

        assert result.signals_generated == 0

    async def test_sync_invokes_analyzer_for_releases_only_no_changed_forks(
        self, db: Database, settings: SyncSettings
    ):
        """When new releases exist but no forks diverged, the analyzer
        must still be called with an empty `changed_forks` list."""
        from forkhub.models import Signal, SignalCategory

        from .stubs import StubAnalyzer

        # Use owner/repo-a which has two canned releases in the stub.
        # Pre-seed forker1 with the provider's reported SHA so no fork
        # compare fires. Pre-seed forker2 and forker3 so they are not
        # new (would otherwise trigger new-fork compare on forker1
        # which would add it to changed_forks).
        provider = SyncStubGitProvider()
        repo = await _insert_tracked_repo(db)
        for github_id, owner, name, sha in [
            (5001, "forker1", "forker1/repo-a", "new-sha-forker1"),
            (5002, "forker2", "forker2/repo-a", "unchanged-sha-forker2"),
            (5003, "forker3", "forker3/repo-a", "new-sha-forker3"),
        ]:
            await _insert_fork_in_db(
                db,
                tracked_repo_id=repo.id,
                github_id=github_id,
                owner=owner,
                full_name=name,
                head_sha=sha,
            )

        analyzer = StubAnalyzer(
            signals=[
                Signal(
                    tracked_repo_id=repo.id,
                    category=SignalCategory.RELEASE,
                    summary="v2.0.0",
                    significance=8,
                )
            ]
        )
        sync_service = SyncService(
            db=db, provider=provider, settings=settings, clock=_NOW, analyzer=analyzer
        )
        result = await sync_service.sync_repo(repo.id)

        assert len(analyzer.calls) == 1
        call = analyzer.calls[0]
        assert call["changed_fork_names"] == []
        assert call["release_count"] == 2
        assert result.signals_generated == 1

    async def test_sync_passes_fully_hydrated_fork_models_to_analyzer(
        self, db: Database, provider: SyncStubGitProvider, settings: SyncSettings
    ):
        """`_fork_from_row` must return real Fork models with populated
        fields. A silent bug that dropped fields or mis-coerced the ISO
        datetime would slip past the name-only assertions in the happy-path
        test above."""
        from .stubs import StubAnalyzer

        repo = await _insert_tracked_repo(db)
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo.id,
            github_id=5001,
            owner="forker1",
            full_name="forker1/repo-a",
            head_sha="stale-sha",
            stars=15,
        )

        analyzer = StubAnalyzer()
        sync_service = SyncService(
            db=db, provider=provider, settings=settings, clock=_NOW, analyzer=analyzer
        )
        await sync_service.sync_repo(repo.id)

        assert len(analyzer.calls) == 1
        fork_models = analyzer.calls[0]["changed_forks"]
        assert len(fork_models) == 1
        f = fork_models[0]
        assert f.full_name == "forker1/repo-a"
        assert f.head_sha == "new-sha-forker1"  # updated by sync
        assert f.commits_ahead == 5  # from canned CompareResult
        assert f.stars == 15

    async def test_sync_all_aggregates_signals_generated(
        self, db: Database, settings: SyncSettings
    ):
        """`SyncResult.total_signals_generated` must be the sum of
        per-repo `signals_generated` across all repos in `sync_all`."""
        from forkhub.models import Signal, SignalCategory

        from .stubs import StubAnalyzer

        repo_a = await _insert_tracked_repo(db, owner="owner", name="repo-a", github_id=1001)
        repo_b = await _insert_tracked_repo(db, owner="owner", name="repo-b", github_id=1002)
        # Pre-seed both repos' forks with stale SHAs so compare fires.
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo_a.id,
            github_id=5001,
            owner="forker1",
            full_name="forker1/repo-a",
            head_sha="stale-sha-1",
        )
        await _insert_fork_in_db(
            db,
            tracked_repo_id=repo_b.id,
            github_id=6001,
            owner="forker4",
            full_name="forker4/repo-b",
            head_sha="stale-sha-2",
        )

        # Stub returns 3 signals per call (2 repos × 3 = 6 total).
        canned = [
            Signal(
                tracked_repo_id=repo_a.id,
                category=SignalCategory.FEATURE,
                summary=f"Signal {i}",
                significance=5,
            )
            for i in range(3)
        ]
        analyzer = StubAnalyzer(signals=canned)

        sync_service = SyncService(
            db=db,
            provider=SyncStubGitProvider(),
            settings=settings,
            clock=_NOW,
            analyzer=analyzer,
        )
        result = await sync_service.sync_all(reconcile=False)

        assert result.repos_synced == 2
        assert len(analyzer.calls) == 2
        # StubAnalyzer returns the same canned list on every call, so
        # each per-repo result has signals_generated == 3 → total == 6.
        assert result.total_signals_generated == 6
        per_repo = [r.signals_generated for r in result.results]
        assert per_repo == [3, 3]


# ---------------------------------------------------------------------------
# New-fork compare-on-first-discovery fix (forkhub-0tf root cause)
# ---------------------------------------------------------------------------


class TestSyncNewForkCompare:
    """First-sync discovery must compare active forks so `changed_forks`
    isn't always empty when a repo is freshly tracked."""

    async def test_new_active_fork_gets_compared_on_first_sync(
        self, sync_service: SyncService, db: Database
    ):
        """forker1 is brand-new + active + diverged (ahead_by=5) → must
        land in changed_forks and have commits_ahead persisted."""
        repo = await _insert_tracked_repo(db)
        result = await sync_service.sync_repo(repo.id)

        assert "forker1/repo-a" in result.changed_forks

        row = await db.get_fork_by_name("forker1/repo-a")
        assert row is not None
        assert row["commits_ahead"] == 5
        assert row["commits_behind"] == 2

    async def test_new_dormant_fork_not_compared(self, sync_service: SyncService, db: Database):
        """Dormant forks must skip compare() on first discovery to save
        API budget. forker2 is dormant, so commits_ahead stays 0."""
        repo = await _insert_tracked_repo(db)
        await sync_service.sync_repo(repo.id)

        row = await db.get_fork_by_name("forker2/repo-a")
        assert row is not None
        assert row["commits_ahead"] == 0
        assert row["vitality"] == "dormant"

    async def test_new_active_fork_with_zero_ahead_not_marked_changed(
        self, db: Database, settings: SyncSettings
    ):
        """An active fork whose compare returns ahead_by=0 must NOT be
        added to changed_forks — nothing diverged."""
        provider = SyncStubGitProvider()
        # forker4/repo-b is active but SyncStubGitProvider has no canned
        # CompareResult for it → defaults to ahead_by=0, behind_by=0.
        repo = await _insert_tracked_repo(db, owner="owner", name="repo-b", github_id=1002)
        sync_service = SyncService(db=db, provider=provider, settings=settings, clock=_NOW)
        result = await sync_service.sync_repo(repo.id)

        assert "forker4/repo-b" not in result.changed_forks
        row = await db.get_fork_by_name("forker4/repo-b")
        assert row is not None
        assert row["commits_ahead"] == 0

    async def test_new_fork_compare_failure_logged_not_raised(
        self, db: Database, provider: SyncStubGitProvider, settings: SyncSettings
    ):
        """If provider.compare() raises during first-sync discovery, the
        fork must still be inserted and changed_forks stays empty for it."""
        provider._error_forks.add("forker1/repo-a")
        sync_service = SyncService(db=db, provider=provider, settings=settings, clock=_NOW)
        repo = await _insert_tracked_repo(db)
        result = await sync_service.sync_repo(repo.id)

        # Fork should still have been inserted
        row = await db.get_fork_by_name("forker1/repo-a")
        assert row is not None
        # But not counted as changed (compare failed)
        assert "forker1/repo-a" not in result.changed_forks
