import vkdispatch.base.dtype as dtypes

from .base_variable import BaseVariable

from ..functions.base_functions import arithmetic
from ..functions.base_functions import bitwise
from ..functions.base_functions import arithmetic_comparisons
from ..functions.base_functions import base_utils
from ..global_builder import get_codegen_backend

from typing import List, Union, Optional

ENABLE_SCALED_AND_OFFSET_INT = True

def var_types_to_floating(var_type: dtypes.dtype) -> dtypes.dtype:
    return dtypes.make_floating_dtype(var_type)

class ShaderVariable(BaseVariable):
    _initilized: bool
    is_complex: bool
    is_conjugate: Optional[bool]
    buffer_root: Optional["ShaderVariable"]
    buffer_index_expr: Optional[str]

    def __init__(self,
                 var_type: dtypes.dtype, 
                 name: Optional[str] = None,
                 raw_name: Optional[str] = None,
                 lexical_unit: bool = False,
                 settable: bool = False,
                 register: bool = False,
                 parents: List["ShaderVariable"] = None,
                 is_conjugate: bool = False,
                 buffer_root: Optional["ShaderVariable"] = None,
                 buffer_index_expr: Optional[str] = None,
        ) -> None:
        super().__setattr__("_initilized", False)

        super().__init__(
            var_type,
            name if name is not None else base_utils.new_name(),
            raw_name,
            lexical_unit,
            settable,
            register,
            parents
        )

        self.is_complex = False
        self.is_conjugate = None
        self.buffer_root = buffer_root
        self.buffer_index_expr = buffer_index_expr

        if dtypes.is_complex(self.var_type):
            self.can_index = True
            self.is_complex = True
            self.is_conjugate = is_conjugate
            
            self.real = self.swizzle("x")
            self.imag = self.swizzle("y")

            if is_conjugate:
                self.imag = -self.imag
            
        elif dtypes.is_vector(self.var_type):
            self.can_index = True

            self.x = self.swizzle("x")
            if self.var_type.child_count >= 2: self.y = self.swizzle("y")
            if self.var_type.child_count >= 3: self.z = self.swizzle("z")
            if self.var_type.child_count == 4: self.w = self.swizzle("w")
        elif dtypes.is_matrix(self.var_type):
            self.can_index = True

        self._initilized = True
       
    def _buffer_component_expr(self, component_index_expr: str) -> Optional[str]:
        if self.buffer_root is None or self.buffer_index_expr is None:
            return None

        if not (dtypes.is_vector(self.var_type) or dtypes.is_complex(self.var_type)):
            return None

        scalar_expr = getattr(self.buffer_root, "scalar_expr", None)
        if scalar_expr is None:
            return None

        backend = getattr(self.buffer_root, "codegen_backend", None)
        if backend is None:
            backend = get_codegen_backend()

        return backend.buffer_component_expr(
            scalar_expr,
            self.var_type,
            self.buffer_index_expr,
            component_index_expr,
        )

    def __getitem__(self, index) -> "ShaderVariable":
        if not self.can_index:
            raise ValueError(f"Variable '{self.resolve()}' of type '{self.var_type.name}' cannot be indexed into!")

        return_type = self.var_type.child_type if self.use_child_type else self.var_type

        if isinstance(index, tuple):
            if len(index) != 1:
                raise ValueError("Only single index is supported, cannot use multi-dimentional indexing!")
            
            index = index[0]

        if base_utils.is_int_number(index):
            component_expr = self._buffer_component_expr(str(index))
            if component_expr is not None:
                return ShaderVariable(
                    return_type,
                    component_expr,
                    parents=[self],
                    settable=self.settable,
                    lexical_unit=True
                )

            return ShaderVariable(return_type, f"{self.resolve()}[{index}]", parents=[self], settable=self.settable, lexical_unit=True)
        
        if not isinstance(index, ShaderVariable):
            raise ValueError(f"Index must be a ShaderVariable or int type, not {type(index)}!")
        
        if not dtypes.is_scalar(index.var_type):
            raise ValueError(f"Indexing variable must be a scalar, but got variable '{index.resolve()}' of type '{index.var_type.name}'!")
        
        if not dtypes.is_integer_dtype(index.var_type):
            raise ValueError(f"Indexing variable must be an integer type, but got variable '{index.resolve()}' of type '{index.var_type.name}'!")

        component_expr = self._buffer_component_expr(index.resolve())
        if component_expr is not None:
            return ShaderVariable(
                return_type,
                component_expr,
                parents=[self, index],
                settable=self.settable,
                lexical_unit=True
            )
        
        return ShaderVariable(return_type, f"{self.resolve()}[{index.resolve()}]", parents=[self, index], settable=self.settable, lexical_unit=True)

    def swizzle(self, components: str) -> "ShaderVariable":
        if not (dtypes.is_vector(self.var_type) or dtypes.is_complex(self.var_type) or dtypes.is_scalar(self.var_type)):
            raise ValueError(f"Variable '{self.resolve()}' of type '{self.var_type.name}' does not support swizzling!")
        
        if not self.use_child_type:
            raise ValueError(f"Variable '{self.resolve()}' does not support swizzling!")
        
        if len(components) < 1 or len(components) > 4:
            raise ValueError(f"Swizzle must have between 1 and 4 components, got {len(components)}!")

        for c in components:
            if c not in ['x', 'y', 'z', 'w']:
                raise ValueError(f"Invalid swizzle component '{c}' in swizzle '{components}' for variable '{self.resolve()}'!")

        sample_type = self.var_type if dtypes.is_scalar(self.var_type) else self.var_type.child_type
        return_type = sample_type if len(components) == 1 else dtypes.to_vector(sample_type, len(components))
        backend = get_codegen_backend()
        base_expr = self.resolve()

        if dtypes.is_scalar(self.var_type):
            if any(c != 'x' for c in components):
                raise ValueError(f"Cannot swizzle scalar variable '{self.resolve()}' with components other than 'x'!")

            scalar_x_expr = backend.component_access_expr(base_expr, "x", self.var_type)
            swizzle_expr = scalar_x_expr
            if len(components) > 1:
                swizzle_expr = backend.constructor(
                    return_type,
                    [scalar_x_expr for _ in components]
                )

            return ShaderVariable(
                var_type=return_type,
                name=swizzle_expr,
                parents=[self],
                lexical_unit=True,
                settable=self.settable and len(components) == 1,
                register=self.register and len(components) == 1
            )

        if self.var_type.shape[0] < 4 and 'w' in components:
            raise ValueError(f"Cannot swizzle variable '{self.resolve()}' of type '{self.var_type.name}' with component 'w' because it only has {self.var_type.shape[0]} components!")

        if self.var_type.shape[0] < 3 and 'z' in components:
            raise ValueError(f"Cannot swizzle variable '{self.resolve()}' of type '{self.var_type.name}' with component 'z' because it only has {self.var_type.shape[0]} components!")
        
        if self.var_type.shape[0] < 2 and 'y' in components:
            raise ValueError(f"Cannot swizzle variable '{self.resolve()}' of type '{self.resolve()}' with component 'y' because it only has {self.var_type.shape[0]} components!")

        if len(components) == 1:
            component_index = "xyzw".index(components)
            component_expr = self._buffer_component_expr(str(component_index))
            if component_expr is not None:
                return ShaderVariable(
                    var_type=return_type,
                    name=component_expr,
                    parents=[self],
                    lexical_unit=True,
                    settable=self.settable,
                    register=self.register
                )

        swizzle_expr = backend.component_access_expr(base_expr, components, self.var_type)
        if len(components) > 1:
            swizzle_expr = backend.constructor(
                return_type,
                [backend.component_access_expr(base_expr, elem, self.var_type) for elem in components]
            )

        return ShaderVariable(
            var_type=return_type,
            name=swizzle_expr,
            parents=[self],
            lexical_unit=True,
            settable=self.settable and len(components) == 1,
            register=self.register and len(components) == 1
        )
    
    def conjugate(self) -> "ShaderVariable":
        if not self.is_complex:
            raise ValueError(f"Variable '{self.resolve()}' of type '{self.var_type.name}' is not a complex variable and cannot be conjugated!")

        return ShaderVariable(
            var_type=self.var_type,
            name=self.name,
            raw_name=self.raw_name,
            lexical_unit=self.lexical_unit,
            settable=False,
            register=False,
            parents=[self],
            is_conjugate=not self.is_conjugate
        )

    def set_value(self, value: "ShaderVariable") -> None:
        if not self.settable:
            raise ValueError(f"Cannot set value of '{self.resolve()}' because it is not a settable variable!")

        self.write_callback()
        self.read_callback()

        if base_utils.is_number(value):
            if dtypes.is_complex(self.var_type):
                complex_value = complex(value)
                complex_constructor = get_codegen_backend().constructor(
                    self.var_type,
                    [
                        base_utils.format_number_literal(complex_value.real),
                        base_utils.format_number_literal(complex_value.imag),
                    ]
                )
                base_utils.append_contents(f"{self.resolve()} = {complex_constructor};\n")
                return

            base_utils.append_contents(f"{self.resolve()} = {base_utils.format_number_literal(value)};\n")
            return

        if self.var_type != value.var_type:
            raise ValueError(f"Cannot set variable of type '{self.var_type.name}' to value of type '{value.var_type.name}'!")

        value.read_callback()

        if self.buffer_root is not None and self.buffer_index_expr is not None:
            scalar_expr = getattr(self.buffer_root, "scalar_expr", None)
            if scalar_expr is not None:
                backend = getattr(self.buffer_root, "codegen_backend", None)
                if backend is None:
                    backend = get_codegen_backend()

                packed_write = backend.packed_buffer_write_statements(
                    scalar_expr,
                    self.var_type,
                    self.buffer_index_expr,
                    value.resolve(),
                )

                if packed_write is not None:
                    base_utils.append_contents(packed_write)
                    return

        base_utils.append_contents(f"{self.resolve()} = {value.resolve()};\n")

    def __setitem__(self, index, value: "ShaderVariable") -> None:
        if not self.settable:
            raise ValueError(f"Cannot set value of '{self.resolve()}' because it is not a settable variable!")

        if isinstance(index, slice):
            if index.start is not None or index.stop is not None or index.step is not None:
                raise ValueError("Only full slice (:) is supported for setting variable values!")
            
            self.set_value(value)
            return
        
        # ignore if setting variable to itself (happens in some inplace operations)
        if f"{self.resolve()}[{index}]" == str(value):
            return

        self[index].set_value(value)

    def __setattr__(self, name: str, value: "ShaderVariable") -> "ShaderVariable":
        if not self._initilized:
            super().__setattr__(name, value)
            return
        
        if dtypes.is_complex(self.var_type) and (name == "real" or name == "imag"):
            if name == "real":
                self.real.set_value(value)
            else:
                self.imag.set_value(value)
            
            return

        if dtypes.is_complex(self.var_type) and (name == "x" or name == "y"):
            raise ValueError(f"Cannot set attribute '{name}' of complex variable '{self.resolve()}', use 'real' and 'imag' instead!")
        
        if dtypes.is_vector(self.var_type) and (name == "x" or name == "y" or name == "z" or name == "w"):
            if name == "x":
                self.x.set_value(value)
            elif name == "y":
                self.y.set_value(value)
            elif name == "z":
                if self.var_type.shape[0] < 3:
                    raise ValueError(f"Variable '{self.resolve()}' of type '{self.var_type.name}' does not have 'z' component!")
                
                self.z.set_value(value)
            elif name == "w":
                if self.var_type.shape[0] < 4:
                    raise ValueError(f"Variable '{self.resolve()}' of type '{self.var_type.name}' does not have 'w' component!")
                
                self.w.set_value(value)
            return

        super().__setattr__(name, value)

    def __bool__(self) -> bool:
        raise ValueError(f"Vkdispatch variables cannot be cast to a python boolean")

    def to_register(self, var_name: str = None) -> "ShaderVariable":
        new_var = base_utils.new_base_var(
            self.var_type,
            var_name,
            [],
            lexical_unit=True,
            settable=True,
            register=True
        )

        self.read_callback()
        base_utils.append_contents(f"{get_codegen_backend().type_name(new_var.var_type)} {new_var.name} = {self.resolve()};\n")
        return new_var

    def to_dtype(self, var_type: dtypes.dtype) -> "ShaderVariable":
        return base_utils.new_base_var(
            var_type,
            get_codegen_backend().constructor(var_type, [self.resolve()], arg_types=[self.var_type]),
            [self],
            lexical_unit=True
        )

    def __lt__(self, other) -> "ShaderVariable": return arithmetic_comparisons.less_than(self, other)
    def __le__(self, other) -> "ShaderVariable": return arithmetic_comparisons.less_or_equal(self, other)
    def __eq__(self, other) -> "ShaderVariable": return arithmetic_comparisons.equal_to(self, other)
    def __ne__(self, other) -> "ShaderVariable": return arithmetic_comparisons.not_equal_to(self, other)
    def __gt__(self, other) -> "ShaderVariable": return arithmetic_comparisons.greater_than(self, other)
    def __ge__(self, other) -> "ShaderVariable": return arithmetic_comparisons.greater_or_equal(self, other)

    def __add__(self, other) -> "ShaderVariable": return arithmetic.add(self, other)
    def __sub__(self, other) -> "ShaderVariable": return arithmetic.sub(self, other)
    def __mul__(self, other) -> "ShaderVariable": return arithmetic.mul(self, other)
    def __truediv__(self, other) -> "ShaderVariable": return arithmetic.truediv(self, other)
    def __floordiv__(self, other) -> 'ShaderVariable': return arithmetic.floordiv(self, other)
    def __mod__(self, other) -> "ShaderVariable": return arithmetic.mod(self, other)
    def __pow__(self, other) -> "ShaderVariable": return arithmetic.pow(self, other)
    def __neg__(self) -> "ShaderVariable": return arithmetic.neg(self)
    def __abs__(self) -> "ShaderVariable": return arithmetic.absolute(self)
    def __invert__(self) -> "ShaderVariable": return bitwise.invert(self)
    def __lshift__(self, other) -> "ShaderVariable": return bitwise.lshift(self, other)
    def __rshift__(self, other) -> "ShaderVariable": return bitwise.rshift(self, other)
    def __and__(self, other) -> "ShaderVariable": return bitwise.and_bits(self, other)
    def __xor__(self, other) -> "ShaderVariable": return bitwise.xor_bits(self, other)
    def __or__(self, other) -> "ShaderVariable": return bitwise.or_bits(self, other)

    def __radd__(self, other) -> "ShaderVariable": return arithmetic.add(self, other)
    def __rsub__(self, other) -> "ShaderVariable": return arithmetic.sub(self, other, reverse=True)
    def __rmul__(self, other) -> "ShaderVariable": return arithmetic.mul(self, other)
    def __rtruediv__(self, other) -> "ShaderVariable": return arithmetic.truediv(self, other, reverse=True)
    def __rfloordiv__(self, other) -> "ShaderVariable": return arithmetic.floordiv(self, other, reverse=True)
    def __rmod__(self, other) -> "ShaderVariable": return arithmetic.mod(self, other, reverse=True)
    def __rpow__(self, other) -> "ShaderVariable": return arithmetic.pow(self, other, reverse=True)
    def __rlshift__(self, other) -> "ShaderVariable": return bitwise.lshift(self, other, reverse=True)
    def __rrshift__(self, other) -> "ShaderVariable": return bitwise.rshift(self, other, reverse=True)
    def __rand__(self, other) -> "ShaderVariable": return bitwise.and_bits(self, other)
    def __rxor__(self, other) -> "ShaderVariable": return bitwise.xor_bits(self, other)
    def __ror__(self, other) -> "ShaderVariable": return bitwise.or_bits(self, other)

    def __iadd__(self, other) -> "ShaderVariable": return arithmetic.add(self, other, inplace=True)
    def __isub__(self, other) -> "ShaderVariable": return arithmetic.sub(self, other, inplace=True)
    def __imul__(self, other) -> "ShaderVariable": return arithmetic.mul(self, other, inplace=True)
    def __itruediv__(self, other) -> "ShaderVariable": return arithmetic.truediv(self, other, inplace=True)
    def __ifloordiv__(self, other) -> "ShaderVariable": return arithmetic.floordiv(self, other, inplace=True)
    def __imod__(self, other) -> "ShaderVariable": return arithmetic.mod(self, other, inplace=True)
    def __ipow__(self, other) -> "ShaderVariable": return arithmetic.pow(self, other, inplace=True)
    def __ilshift__(self, other) -> "ShaderVariable": return bitwise.lshift(self, other, inplace=True)
    def __irshift__(self, other) -> "ShaderVariable": return bitwise.rshift(self, other, inplace=True)
    def __iand__(self, other) -> "ShaderVariable": return bitwise.and_bits(self, other, inplace=True)
    def __ixor__(self, other) -> "ShaderVariable": return bitwise.xor_bits(self, other, inplace=True)
    def __ior__(self, other) -> "ShaderVariable": return bitwise.or_bits(self, other, inplace=True)

class ScaledAndOfftsetIntVariable(ShaderVariable):
    def __init__(self,
                 var_type: dtypes.dtype, 
                 name: str,
                 scale: int = 1,
                 offset: int = 0,
                 parents: List["ShaderVariable"] = None
        ) -> None:
        # ShaderVariable.__init__ eagerly creates vector swizzles (`x`, `y`, ...),
        # which call resolve() during construction. Pre-seed these fields so
        # ScaledAndOfftsetIntVariable.resolve() is safe before super().__init__ completes.
        object.__setattr__(self, "base_name", str(name))
        object.__setattr__(self, "scale", scale)
        object.__setattr__(self, "offset", offset)
        super().__init__(var_type, name, parents=parents)
        
    def new_from_self(self, scale: int = 1, offset: int = 0):
        child_vartype = self.var_type

        if base_utils.is_float_number(scale) or base_utils.is_float_number(offset):
            child_vartype = var_types_to_floating(self.var_type)

        return ScaledAndOfftsetIntVariable(
            child_vartype,
            f"{self.name}",
            scale=self.scale * scale,
            offset=offset + self.offset * scale,
            parents=self.parents
        )

    def resolve(self) -> str:        
        scale_str = (
            f" * {base_utils.format_number_literal(self.scale)}"
            if self.scale != 1 else ""
        )
        offset_str = (
            f" + {base_utils.format_number_literal(self.offset)}"
            if self.offset != 0 else ""
        )

        if scale_str == "" and offset_str == "":
            return self.base_name

        return f"({self.base_name}{scale_str}{offset_str})"

    def __add__(self, other) -> "Union[ShaderVariable, ScaledAndOfftsetIntVariable]":
        if base_utils.is_scalar_number(other):
            return self.new_from_self(offset=other)
        
        return super().__add__(other)

    def __sub__(self, other):
        if isinstance(other, ShaderVariable):
            return super().__sub__(other)

        return self.new_from_self(offset=-other)

    def __mul__(self, other):
        if isinstance(other, ShaderVariable):
            return super().__mul__(other)

        return self.new_from_self(scale=other)
    
    def __radd__(self, other):
        if isinstance(other, ShaderVariable):
            return super().__radd__(other)

        return self.new_from_self(offset=other)

    def __rsub__(self, other):
        if isinstance(other, ShaderVariable):
            return super().__rsub__(other)

        return self.new_from_self(offset=other, scale=-1)

    def __rmul__(self, other):
        if isinstance(other, ShaderVariable):
            return super().__rmul__(other)

        return self.new_from_self(scale=other)
