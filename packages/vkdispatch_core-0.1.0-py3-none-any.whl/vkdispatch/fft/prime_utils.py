from typing import List

import vkdispatch as vd
from ..compat import numpy_compat as npc

def default_register_limit():
    return 16

def default_max_prime():
    return 13

def prime_factors(n) -> List[int]:
    factors = []
    
    # Handle the factor 2 separately
    while n % 2 == 0:
        factors.append(2)
        n //= 2
        
    # Now handle odd factors
    factor = 3
    while factor * factor <= n:
        while n % factor == 0:
            factors.append(factor)
            n //= factor
        factor += 2
        
    # If at the end, n is greater than 1, it is a prime number itself
    if n > 1:
        factors.append(n)
        
    return factors

def group_primes(primes, register_count):
    groups: List[List] = []

    for prime in primes:
        if len(groups) == 0:
            groups.append([prime])
            continue

        if npc.prod(groups[-1]) * prime <= register_count:
            groups[-1].append(prime)
            continue

        groups.append([prime])

    return groups

def pad_dim(dim: int, max_register_count: int = None):
    if max_register_count is None:
        max_register_count = default_register_limit()

    if dim <= 0:
        raise ValueError('Dimension must be greater than 0')

    current_dim = dim
    current_primes = prime_factors(current_dim)

    while any([prime > max_register_count for prime in current_primes]):
        current_dim += 1
        current_primes = prime_factors(current_dim)

    return current_dim
