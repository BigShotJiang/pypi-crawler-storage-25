from typing import List
from typing import Tuple
from typing import Union
from typing import Dict
from typing import MutableMapping

import atexit
import weakref

import sys
import os, signal

from .errors import check_for_errors, set_running
from .init import DeviceInfo, is_cuda, is_opencl, is_dummy, get_devices, initialize, log_info, log_warning
from ..backends.backend_selection import native

VK_SHADER_STAGE_COMPUTE_BIT = 0x00000020

VK_SUBGROUP_FEATURE_ARITHMETIC_BIT = 0x00000004

class Handle:
    context: "Context"
    _handle: int
    destroyed: bool

    parents: Dict[int, "Handle"]
    children_dict: MutableMapping[int, "Handle"]

    def __init__(self):
        self.context = None
        self._handle = None
        self.destroyed = False
        self.parents = {}
        self.children_dict = weakref.WeakValueDictionary()

        self.canary = False
        self.context = get_context()

    def register_handle(self, handle: int) -> None:
        """
        Registers the handle in the context's handles dictionary.
        """
        self._handle = handle
        self.context.handles_dict[self._handle] = self

    def register_parent(self, parent: "Handle") -> None:
        """
        Registers the parent handle.
        """
        if parent._handle in self.parents.keys():
            return
        
        self.parents[parent._handle] = parent

        parent.add_child_handle(self)
    
    def clear_parents(self) -> None:
        """
        Clears the parent handles.
        """
        # children_dict uses weak references, so a child key may disappear
        # before teardown reaches this point.
        for parent in self.parents.values():
            parent.remove_child_handle(self)

        self.parents.clear()

    def add_child_handle(self, child: "Handle") -> None:
        """
        Adds a child handle to the current handle.
        """
        if child._handle in self.children_dict.keys():
            raise ValueError(f"Child handle {child._handle} already exists in parent handle!")
        
        self.children_dict[child._handle] = child

    def remove_child_handle(self, child: "Handle") -> None:
        """
        Removes a child handle from the current handle.
        """
        # Be idempotent to tolerate repeated teardown paths and weakref eviction.
        self.children_dict.pop(child._handle, None)

    def _destroy(self) -> None:
        raise NotImplementedError("destroy is an abstract method and must be implemented by subclasses.")
    
    def destroy(self) -> None:
        """
        Destroys the context handle and cleans up resources.
        """
        if getattr(self, "destroyed", True):
            return        

        self.destroyed = True
        self.clear_parents()

        child_keys = list(self.children_dict.keys())

        for child_handle in child_keys:
            if child_handle in self.children_dict:
                child = self.children_dict[child_handle]
                child.destroy()

        if len(self.children_dict) > 0:
            log_warning(f"Warning: Not all child handles were destroyed for handle {self._handle}!")
        
        if self.canary:
            raise RuntimeError("Handle was already destroyed!")

        if self._handle is not None:
            self._destroy()
            check_for_errors()

        self.canary = True

        if (
            self.context is not None
            and self._handle in self.context.handles_dict.keys()
        ):
            self.context.handles_dict.pop(self._handle)
        
        

class Signal:
    ptr_addr: int

    def __init__(self, ptr_addr: int = None):
        self.ptr_addr = ptr_addr

    def wait(self, wait_for_timestamp: bool, queue_index: int):
        done = False
        while not done:
            done = native.signal_wait(
                self.ptr_addr, wait_for_timestamp, queue_index
            )
            check_for_errors()

    def try_wait(self, wait_for_timestamp: bool, queue_index: int):
        done = native.signal_wait(
            self.ptr_addr, wait_for_timestamp, queue_index
        )
        check_for_errors()

        return done

    def free(self):
        native.signal_destroy(self.ptr_addr)

class Context:
    """
    A class for managing the context of the vkdispatch library.

    Attributes:
        _handle (`int`): The handle to the context.
        devices (`List[int]`): A list of device indicies to use for the context.
        device_infos (`List[DeviceInfo]`): A list of device info objects.
        queue_families (`List[List[int]]`): A list of queue family indicies to use for the context.
        queue_count (`int`): The number of queues in the context.
        subgroup_size (`int`): The subgroup size of the devices.
        max_workgroup_size (`Tuple[int]`): The maximum workgroup size of the devices.
        max_workgroup_invocations (`int`): The maximum number of workgroup invocations.
        max_workgroup_count (`Tuple[int, int, int]`): The maximum workgroup count of the devices.
        uniform_buffer_alignment (`int`): The uniform buffer alignment of the devices.
        max_shared_memory (`int`): The maximum shared memory size of the devices.
    """

    _handle: int
    device_ids: List[int]
    mapped_device_ids: List[int]
    device_infos: List[DeviceInfo]
    queue_families: List[List[int]]
    queue_count: int
    subgroup_size: int
    subgroup_enabled: bool
    subgroup_arithmetic: bool
    max_workgroup_size: Tuple[int]
    max_workgroup_invocations: int
    max_workgroup_count: Tuple[int, int, int]
    uniform_buffer_alignment: int
    max_shared_memory: int
    handles_dict: MutableMapping[int, Handle]

    def __init__(
        self,
        device_ids: List[int],
        queue_families: List[List[int]]
    ) -> None:
        self.device_ids = device_ids
        self.device_infos = [get_devices()[dev] for dev in device_ids]
        self.queue_families = queue_families
        self.queue_count = sum([len(i) for i in queue_families])
        self.handles_dict = weakref.WeakValueDictionary()
        self.mapped_device_ids = [dev.dev_index for dev in self.device_infos]
        self._handle = native.context_create(self.mapped_device_ids, queue_families)
        check_for_errors()

        self.refresh_limits_from_device_infos()

    def refresh_limits_from_device_infos(self) -> None:
        subgroup_sizes = []
        max_workgroup_sizes_x = []
        max_workgroup_sizes_y = []
        max_workgroup_sizes_z = []
        max_workgroup_invocations = []
        max_workgroup_counts_x = []
        max_workgroup_counts_y = []
        max_workgroup_counts_z = []
        uniform_buffer_alignments = []
        max_shared_memory = []

        subgroup_enabled = True
        subgroup_arithmetic = True

        for device in self.device_infos:
            subgroup_sizes.append(device.sub_group_size)
            
            max_workgroup_sizes_x.append(device.max_workgroup_size[0])
            max_workgroup_sizes_y.append(device.max_workgroup_size[1])
            max_workgroup_sizes_z.append(device.max_workgroup_size[2])

            max_workgroup_invocations.append(device.max_workgroup_invocations)

            max_workgroup_counts_x.append(device.max_workgroup_count[0])
            max_workgroup_counts_y.append(device.max_workgroup_count[1])
            max_workgroup_counts_z.append(device.max_workgroup_count[2])

            uniform_buffer_alignments.append(device.uniform_buffer_alignment)

            max_shared_memory.append(device.max_compute_shared_memory_size)

            if not device.supported_stages & VK_SHADER_STAGE_COMPUTE_BIT:
                subgroup_enabled = False

            if not device.supported_operations & VK_SUBGROUP_FEATURE_ARITHMETIC_BIT:
                subgroup_arithmetic = False

        self.subgroup_enabled = subgroup_enabled
        self.subgroup_arithmetic = subgroup_arithmetic
        self.subgroup_size = min(subgroup_sizes)
        self.max_workgroup_size = (
            min(max_workgroup_sizes_x),
            min(max_workgroup_sizes_y),
            min(max_workgroup_sizes_z)
        )
        
        self.max_workgroup_invocations = min(max_workgroup_invocations)
        self.max_workgroup_count = (
            min(max_workgroup_counts_x),
            min(max_workgroup_counts_y),
            min(max_workgroup_counts_z)
        )

        self.uniform_buffer_alignment = max(uniform_buffer_alignments)
        self.max_shared_memory = min(max_shared_memory)
    
    def is_apple(self) -> bool:
        return any([device.is_apple() for device in self.device_infos])

def get_compute_queue_family_index(device: DeviceInfo, device_index: int) -> int:
    # First check if we have a pure compute queue family with (sparse) transfer capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] == 6 or queue_family[1] == 14:
            return i

    # If not, check if we have a compute queue family without graphics capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] & 2 and not queue_family[1] & 1:
            return i
        
    # Finnally, return any queue with compute capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] & 2:
            return i

    raise ValueError(f"Device {device_index} does not have a compute queue family!")

def get_graphics_queue_family_index(device: DeviceInfo, device_index: int) -> int:
    # First check if we have a pure compute queue family with (sparse) transfer capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] == 7 or queue_family == 15:
            return i

    # If not, check if we have a compute queue family without graphics capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] & 2 and queue_family[1] & 1:
            return i
        
    # Finnally, return any queue with compute capabilities
    for i, queue_family in enumerate(device.queue_properties):
        if queue_family[1] & 2:
            return i

    raise ValueError(f"Device {device_index} does not have a compute queue family!")

def select_devices(use_cpu: bool, device_count) -> List[int]:
    device_infos = get_devices()

    if device_count is not None:
        if device_count < 0 or device_count > len(device_infos):
            raise ValueError(f"Device count must be between 0 and {len(device_infos)}")

    result = []

    # Check for Discrete GPU (Type 2)
    for i, device_info in enumerate(device_infos):
        if device_info.device_type == 2:
            result.append(i)
    
    # Check for Integrated GPU (Type 1)
    for i, device_info in enumerate(device_infos):
        if device_info.device_type == 1:
            result.append(i)
    
    # Check for Virtual GPU (Type 3)
    for i, device_info in enumerate(device_infos):
        if device_info.device_type == 3:
            result.append(i)

    # Check for CPU (Type 4)
    if use_cpu:
        for i, device_info in enumerate(device_infos):
            if device_info.device_type == 4:
                result.append(i)
    
    return result[:device_count] if device_count is not None else result

__context = None

def select_queue_families(device_index: int, queue_count: int = None) -> List[int]:
    device = get_devices()[device_index]

    compute_queue_family = get_compute_queue_family_index(device, device_index)
    graphics_queue_family = get_graphics_queue_family_index(device, device_index)

    if queue_count is None:
        queue_count = 2

        if device.is_nvidia():
            queue_count = 3

        if compute_queue_family == graphics_queue_family:
            queue_count = 1
    
    queue_families = []

    for i in range(queue_count):
        # For NVIDIA, it's better to just have one graphics queue family
        # and mulitple compute queues
        if device.is_nvidia() and i != 1:
            queue_families.append(compute_queue_family)
            continue

        if i % 2 == 0:
            queue_families.append(compute_queue_family)
        else:
            queue_families.append(graphics_queue_family)

    return queue_families

def make_context(
    device_ids: Union[int, List[int], None] = None,
    device_count: Union[int, None] = None,
    queue_counts: Union[int, List[int], None] = None,
    queue_families: Union[List[List[int]], None] = None,
    use_cpu: bool = False,
    multi_device: bool = False,
    multi_queue: bool = False,
) -> Context:
    global __context
    
    if __context is None:
        initialize()
        
        if device_ids is None:
            if device_count is None:
                device_count = None if multi_device else 1

            device_ids = select_devices(use_cpu, device_count)
            
            if not queue_families is None:
                raise ValueError("If queue_families is provided, devices must also be provided!")

        if isinstance(device_ids, int):
            device_ids = [device_ids]
        
        if queue_families is None:
            queue_families = []

            for ii, dev_index in enumerate(device_ids):
                queue_family_count = None if multi_queue else 1

                if queue_counts is not None:
                    if isinstance(queue_counts, int):
                        queue_family_count = queue_counts
                    else:
                        queue_family_count = queue_counts[ii]

                queue_families.append(
                    select_queue_families(dev_index, queue_family_count)
                )

        if is_cuda() or is_opencl():
            backend_name = "CUDA" if is_cuda() else "OpenCL"
            if len(device_ids) != 1:
                raise NotImplementedError(
                    f"The {backend_name} backend currently supports exactly one device."
                )

            if len(queue_families) != 1 or len(queue_families[0]) != 1:
                raise NotImplementedError(
                    f"The {backend_name} backend currently supports exactly one queue."
                )

        total_devices = len(get_devices())

        if len(device_ids) != len(queue_families):
            raise ValueError("Device and submission thread count lists must be the same length!")
        
        if not all([isinstance(dev, int) for dev in device_ids]):
            raise ValueError("Device list must be a list of integers!")
        
        if not all([dev >= 0 and dev < total_devices for dev in device_ids]):
            raise ValueError(f"All device indicies must between 0 and {total_devices}")

        __context = Context(device_ids, queue_families)

        queue_wait_idle(queue_index=None, context=__context)

    return __context

def is_context_initialized() -> bool:
    global __context
    return not __context is None

def get_context() -> Context:
    return make_context()

def get_context_handle() -> int:
    return get_context()._handle

def _as_positive_int(name: str, value) -> int:
    try:
        result = int(value)
    except Exception as exc:
        raise ValueError(f"{name} must be a positive integer") from exc

    if result <= 0:
        raise ValueError(f"{name} must be a positive integer")

    return result

def _as_positive_triplet(name: str, value) -> Tuple[int, int, int]:
    try:
        parts = list(value)
    except Exception as exc:
        raise ValueError(f"{name} must contain exactly 3 positive integers") from exc

    if len(parts) != 3:
        raise ValueError(f"{name} must contain exactly 3 positive integers")

    return (
        _as_positive_int(f"{name}[0]", parts[0]),
        _as_positive_int(f"{name}[1]", parts[1]),
        _as_positive_int(f"{name}[2]", parts[2]),
    )

def set_dummy_context_params(
    subgroup_size: int = None,
    subgroup_enabled: bool = None,
    max_workgroup_size: Tuple[int, int, int] = None,
    max_workgroup_invocations: int = None,
    max_workgroup_count: Tuple[int, int, int] = None,
    max_shared_memory: int = None,
) -> None:
    """
    Update cached context/device limit values for the active dummy backend context.

    This only works when a dummy context already exists.
    """
    global __context

    if not is_dummy():
        raise RuntimeError(
            "set_dummy_context_params() is only supported when running with backend='dummy'."
        )

    if __context is None:
        __context = get_context()

    validated_subgroup_size = None
    validated_subgroup_enabled = None
    validated_max_workgroup_size = None
    validated_max_workgroup_invocations = None
    validated_max_workgroup_count = None
    validated_max_shared_memory = None

    backend_kwargs = {}

    if subgroup_size is not None:
        validated_subgroup_size = _as_positive_int("subgroup_size", subgroup_size)
        backend_kwargs["subgroup_size"] = validated_subgroup_size

    if subgroup_enabled is not None:
        if not isinstance(subgroup_enabled, bool):
            raise ValueError("subgroup_enabled must be a boolean value")
        validated_subgroup_enabled = bool(subgroup_enabled)
        backend_kwargs["subgroup_enabled"] = subgroup_enabled

    if max_workgroup_size is not None:
        validated_max_workgroup_size = _as_positive_triplet("max_workgroup_size", max_workgroup_size)
        backend_kwargs["max_workgroup_size"] = validated_max_workgroup_size

    if max_workgroup_invocations is not None:
        validated_max_workgroup_invocations = _as_positive_int(
            "max_workgroup_invocations",
            max_workgroup_invocations,
        )
        backend_kwargs["max_workgroup_invocations"] = validated_max_workgroup_invocations

    if max_workgroup_count is not None:
        validated_max_workgroup_count = _as_positive_triplet("max_workgroup_count", max_workgroup_count)
        backend_kwargs["max_workgroup_count"] = validated_max_workgroup_count

    if max_shared_memory is not None:
        validated_max_shared_memory = _as_positive_int("max_shared_memory", max_shared_memory)
        backend_kwargs["max_compute_shared_memory_size"] = validated_max_shared_memory

    if backend_kwargs:
        native.set_device_options(**backend_kwargs)
        check_for_errors()

    for device in __context.device_infos:
        if validated_subgroup_size is not None:
            device.sub_group_size = validated_subgroup_size

        if validated_subgroup_enabled is not None:
            if validated_subgroup_enabled:
                device.supported_stages |= VK_SHADER_STAGE_COMPUTE_BIT
                device.supported_operations |= VK_SUBGROUP_FEATURE_ARITHMETIC_BIT
            else:
                device.supported_stages &= ~VK_SHADER_STAGE_COMPUTE_BIT
                device.supported_operations &= ~VK_SUBGROUP_FEATURE_ARITHMETIC_BIT

        if validated_max_workgroup_size is not None:
            device.max_workgroup_size = validated_max_workgroup_size

        if validated_max_workgroup_invocations is not None:
            device.max_workgroup_invocations = validated_max_workgroup_invocations

        if validated_max_workgroup_count is not None:
            device.max_workgroup_count = validated_max_workgroup_count

        if validated_max_shared_memory is not None:
            device.max_compute_shared_memory_size = validated_max_shared_memory

        device.uniform_buffer_alignment = 0

    __context.refresh_limits_from_device_infos()

def queue_wait_idle(queue_index: int = None, context: Context = None) -> None:
    """
    Wait for the specified queue to finish processing. For all queues, leave queue_index as None.
    
    Args:
        queue_index (int): The index of the queue.
    """

    if context is None:
        context = get_context()

    if queue_index is not None:
        if not isinstance(queue_index, int):
            raise ValueError("queue_index must be an integer or None!")
        
        if queue_index < 0 or queue_index >= context.queue_count:
            raise ValueError(f"queue_index must be between 0 and {context.queue_count - 1} (inclusive) or None for all queues!")

    if queue_index is None:
        for i in range(context.queue_count):
            queue_wait_idle(i, context)
        return

    signal_ptr = native.signal_insert(context._handle, queue_index)
    check_for_errors()
    
    signal = Signal(signal_ptr)
    signal.wait(True, queue_index)
    check_for_errors()

    signal.free()

def destroy_context() -> None:
    """
    Destroys the current context and cleans up resources.
    """
    global __context
    set_running(False)

    if __context is None:
        return

    log_info("Destroying context...")

    handles_list = list(__context.handles_dict.values())

    for handle in handles_list:
        log_info(f"Destroying handle {handle._handle}...")
        handle.destroy()

    if len(__context.handles_dict) > 0:
        log_warning(f"Warning: Not all handles were destroyed for context handle {__context._handle}!")

    log_info("Calling native context destroy...")
    native.context_destroy(__context._handle)
    __context = None

atexit.register(destroy_context)

def stop_threads() -> None:
    """
    Stops all threads in the context.
    """
    global __context

    if __context is None:
        return

    native.context_stop_threads(__context._handle)

_sigint_shutdown_once = False
_previous_signal_handlers = {}

def _call_previous_handler(signum, frame) -> None:
    previous_handler = _previous_signal_handlers.get(signum)

    if callable(previous_handler) and previous_handler is not _sig_handler:
        try:
            previous_handler(signum, frame)
        except Exception:
            pass

def _reraised_signal(signum: int, handler) -> None:
    signal.signal(signum, handler)
    os.kill(os.getpid(), signum)

def _sig_handler(signum, frame):
    global _sigint_shutdown_once
    set_running(False)

    if signum == signal.SIGINT:
        print("Ctrl-C received, stopping threads...")

        if not _sigint_shutdown_once:
            _sigint_shutdown_once = True
            stop_threads()
            return

        _reraised_signal(signum, signal.SIG_DFL)
        return

    if signum == signal.SIGTERM:
        try:
            destroy_context()
        except Exception:
            pass

        _call_previous_handler(signum, frame)
        _reraised_signal(signum, signal.SIG_DFL)
        return

    _call_previous_handler(signum, frame)
    _reraised_signal(signum, signal.SIG_DFL)

# No need to register signal handlers in Brython, since it runs in a browser
if not sys.implementation.name == "Brython":
    _previous_signal_handlers[signal.SIGINT] = signal.getsignal(signal.SIGINT)
    _previous_signal_handlers[signal.SIGTERM] = signal.getsignal(signal.SIGTERM)
    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)
