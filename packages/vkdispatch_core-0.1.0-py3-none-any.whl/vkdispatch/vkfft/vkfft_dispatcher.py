from typing import Tuple
from typing import Union, Optional
from typing import List

import vkdispatch as vd

from .vkfft_plan import VkFFTPlan

import dataclasses
from functools import lru_cache

from typing import Dict
from typing import Union

@dataclasses.dataclass(frozen=True)
class FFTConfig:
    buffer_handle: int
    shape: Tuple[int, ...]
    do_r2c: bool = False
    axes: Tuple[int] = None
    normalize: bool = False
    padding: Tuple[Tuple[int, int]] = None
    pad_freq_domain: bool = False
    kernel_count: int = 0
    input_shape: Tuple[int, ...] = None
    input_type: vd.dtype = None
    kernel_convolution: bool = False
    conjugate_convolution: bool = False
    convolution_features: int = 1
    num_batches: int = 1
    single_kernel_multiple_batches: bool = False
    keep_shader_code: bool = False

def sanitize_input_tuple(input: Tuple) -> Tuple:
    if input is None:
        return None

    return tuple(input)

@lru_cache(maxsize=None)
def get_fft_plan(
        shape: Tuple[int, ...],
        do_r2c: bool = False,
        axes: Tuple[int] = None,
        normalize: bool = False,
        padding: Tuple[Tuple[int, int]] = None,
        pad_frequency_domain: bool = False,
        kernel_count: int = 0,
        input_shape: Tuple[int, ...] = None,
        input_type: vd.dtype = None,
        kernel_convolution: bool = False,
        conjugate_convolution: bool = False,
        convolution_features: int = 1,
        num_batches: int = 1,
        keep_shader_code: bool = False) -> VkFFTPlan:
    
    return VkFFTPlan(
        shape=shape, 
        do_r2c=do_r2c, 
        axes=axes, 
        normalize=normalize, 
        padding=padding, 
        pad_frequency_domain=pad_frequency_domain, 
        kernel_count=kernel_count,
        input_shape=input_shape,
        input_type=input_type,
        kernel_convolution=kernel_convolution,
        conjugate_convolution=conjugate_convolution,
        convolution_features=convolution_features,
        num_batches=num_batches,
        keep_shader_code=keep_shader_code
    )

def clear_plan_cache():
    get_fft_plan.cache_clear()

def execute_fft_plan(
        buffer: vd.Buffer,
        inverse: bool,
        config: FFTConfig,
        kernel: vd.Buffer = None,
        input: vd.Buffer = None,
        graph: Optional[vd.CommandGraph] = None):
    if graph is None:
        graph = vd.global_graph()
    
    plan = get_fft_plan(
            shape=config.shape, 
            do_r2c=config.do_r2c, 
            axes=config.axes, 
            normalize=config.normalize, 
            padding=config.padding, 
            pad_frequency_domain=config.pad_freq_domain, 
            kernel_count=config.kernel_count,
            input_shape=config.input_shape,
            input_type=config.input_type,
            kernel_convolution=config.kernel_convolution,
            conjugate_convolution=config.conjugate_convolution,
            convolution_features=config.convolution_features,
            num_batches=config.num_batches,
            keep_shader_code=config.keep_shader_code
        )
    plan.record(graph, buffer, inverse, kernel, input)

    if isinstance(graph, vd.CommandGraph):
        if graph.submit_on_record:
            graph.submit()

def transpose_kernel2D(
        kernel: vd.Buffer,
        shape: Tuple[int, ...] = None,
        graph: Optional[vd.CommandGraph] = None,
        keep_shader_code: bool = False):
    if shape is None:
        shape = kernel.shape

    if len(shape) == 2:
        shape = (1,) + shape

    if len(shape) != 3:
        raise ValueError('Kernel shape must be 2D or 3D!')

    execute_fft_plan(
        kernel,
        False,
        graph = graph,
        config = FFTConfig(
            buffer_handle=kernel._handle,
            shape=shape[1:],
            kernel_convolution=True,
            convolution_features=1,
            num_batches=shape[0],
            keep_shader_code=keep_shader_code
        )
    )

def convolve2D(
        buffer: vd.Buffer,
        kernel: Union[vd.Buffer[vd.float32], vd.Buffer],
        normalize: bool = False,
        conjugate_kernel: bool = False,
        graph: Optional[vd.CommandGraph] = None,
        keep_shader_code: bool = False,
        padding: Tuple[Tuple[int, int]] = None):

    in_shape = sanitize_input_tuple(buffer.shape)

    if len(in_shape) == 2:
        in_shape = (1,) + in_shape

    execute_fft_plan(
        buffer,
        False,
        graph = graph,
        config = FFTConfig(
            buffer_handle=buffer._handle,
            shape=in_shape[1:],
            normalize=normalize,
            kernel_count=1,
            conjugate_convolution=conjugate_kernel,
            convolution_features=1,
            keep_shader_code=keep_shader_code,
            num_batches=buffer.shape[0],
            padding=padding
        ),
        kernel=kernel
    )

def fft(
        buffer: vd.Buffer,
        input_buffer: vd.Buffer = None,
        buffer_shape: Tuple = None,
        graph: vd.CommandGraph = None,
        print_shader: bool = False,
        axis: int = None,
        inverse: bool = False,
        normalize_inverse: bool = True,
        r2c: bool = False):
    
    if axis is None:
        axis = [len(buffer.shape) - 1]
    
    if isinstance(axis, int):
        axis = [axis]

    if buffer_shape is None:
        buffer_shape = buffer.shape

    config = FFTConfig(
        buffer_handle=buffer._handle,
        shape=sanitize_input_tuple(buffer_shape),
        axes=sanitize_input_tuple(axis),
        padding=None,
        pad_freq_domain=False,
        input_shape=sanitize_input_tuple(input_buffer.shape if input_buffer is not None else None),
        input_type=input_buffer.var_type if input_buffer is not None else None,
        keep_shader_code=print_shader,
        normalize=normalize_inverse,
        do_r2c=r2c
    )

    execute_fft_plan(
        buffer,
        inverse=inverse,
        graph=graph,
        input=input_buffer,
        config=config
    )

def fft2(buffer: vd.Buffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.shape) < 2:
        raise ValueError('Buffer must have at least 2 dimensions')

    axes = (len(buffer.shape) - 2, len(buffer.shape) - 1)

    fft(buffer, graph=graph, print_shader=print_shader, axis=axes)

def fft3(buffer: vd.Buffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.shape) < 3:
        raise ValueError('Buffer must have at least 3 dimensions')

    fft(buffer, graph=graph, print_shader=print_shader, axis=(0, 1, 2))

def ifft(
        buffer: vd.Buffer,
        graph: vd.CommandGraph = None,
        print_shader: bool = False,
        axis: int = None,
        normalize: bool = True):
    fft(buffer, graph=graph, print_shader=print_shader, axis=axis, inverse=True, normalize_inverse=normalize)

def ifft2(buffer: vd.Buffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.shape) < 2:
        raise ValueError('Buffer must have at least 2 dimensions')

    axes = (len(buffer.shape) - 2, len(buffer.shape) - 1)

    ifft(buffer, graph=graph, print_shader=print_shader, axis=axes)

def ifft3(buffer: vd.Buffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.shape) != 3:
        raise ValueError('Buffer must have 3 dimensions')

    ifft(buffer, graph=graph, print_shader=print_shader, axis=(0, 1, 2))


def rfft(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False, axis: int = None):
    fft(buffer, buffer_shape=buffer.real_shape, graph=graph, print_shader=print_shader, r2c=True, axis=axis)

def rfft2(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.real_shape) < 2:
        raise ValueError('Buffer must have at least 2 dimensions')

    axes = (len(buffer.shape) - 2, len(buffer.shape) - 1)
    rfft(buffer, graph=graph, print_shader=print_shader, axis=axes)

def rfft3(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.real_shape) != 3:
        raise ValueError('Buffer must have 3 dimensions')

    rfft(buffer, graph=graph, print_shader=print_shader, axis=(0, 1, 2))

def irfft(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False, normalize: bool = True, axis: int = None):
    fft(buffer, buffer_shape=buffer.real_shape, graph=graph, print_shader=print_shader, inverse=True, normalize_inverse=normalize, r2c=True, axis=axis)

def irfft2(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.real_shape) < 2:
        raise ValueError('Buffer must have at least 2 dimensions')

    axes = (len(buffer.shape) - 2, len(buffer.shape) - 1)
    irfft(buffer, graph=graph, print_shader=print_shader, axis=axes)

def irfft3(buffer: vd.RFFTBuffer, graph: vd.CommandGraph = None, print_shader: bool = False):
    if len(buffer.real_shape) != 3:
        raise ValueError('Buffer must have 3 dimensions')

    irfft(buffer, graph=graph, print_shader=print_shader, axis=(0, 1, 2))
