"""gflow-cli — unofficial CLI for Google Flow."""

__version__ = "0.8.0"
