import pytest
import fortrand
import random
import math

class TestFortRandState:
    def test_getstate_setstate(self):
        fortrand.seed(123)
        _ = [fortrand.random() for _ in range(10)]
        state = fortrand.getstate()
        val1 = fortrand.random()
        
        fortrand.setstate(state)
        val2 = fortrand.random()
        assert val1 == val2


class TestCoreGenerator:
    def test_random(self):
        for _ in range(100):
            val = fortrand.random()
            assert 0.0 <= val < 1.0

    def test_getrandbits(self):
        val = fortrand.getrandbits(16)
        assert 0 <= val < (1 << 16)
        
    def test_randbytes(self):
        b = fortrand.randbytes(10)
        assert isinstance(b, bytes)
        assert len(b) == 10

class TestIntegerSequence:
    def test_randint(self):
        for _ in range(100):
            val = fortrand.randint(5, 10)
            assert 5 <= val <= 10
            
    def test_randint_invalid(self):
        with pytest.raises(ValueError):
            fortrand.randint(10, 5)

    def test_randrange(self):
        val = fortrand.randrange(0, 10, 2)
        assert val in [0, 2, 4, 6, 8]
        
    def test_choice(self):
        seq = [10, 20, 30]
        for _ in range(50):
            assert fortrand.choice(seq) in seq

    def test_choices(self):
        seq = [10, 20, 30]
        res = fortrand.choices(seq, k=5)
        assert len(res) == 5
        assert all(x in seq for x in res)

    def test_shuffle(self):
        seq = [1, 2, 3, 4, 5]
        original = seq.copy()
        fortrand.shuffle(seq)
        assert set(seq) == set(original)
        assert len(seq) == len(original)

    def test_sample(self):
        seq = [1, 2, 3, 4, 5]
        res = fortrand.sample(seq, 3)
        assert len(res) == 3
        assert len(set(res)) == 3
        assert all(x in seq for x in res)

class TestContinuousDistributions:
    def test_uniform(self):
        for _ in range(100):
            val = fortrand.uniform(1.0, 5.0)
            assert 1.0 <= val <= 5.0

    def test_triangular(self):
        for _ in range(100):
            val = fortrand.triangular(1.0, 5.0, 3.0)
            assert 1.0 <= val <= 5.0
            
    def test_gauss(self):
        for _ in range(10):
            val = fortrand.gauss(0, 1)
            assert isinstance(val, float)
            
    def test_normalvariate(self):
        for _ in range(10):
            val = fortrand.normalvariate(0, 1)
            assert isinstance(val, float)
            
    def test_lognormvariate(self):
        for _ in range(10):
            val = fortrand.lognormvariate(0, 1)
            assert isinstance(val, float)
            assert val > 0
            
    def test_expovariate(self):
        for _ in range(10):
            val = fortrand.expovariate(1.5)
            assert isinstance(val, float)
            assert val >= 0
            
    def test_vonmisesvariate(self):
        for _ in range(10):
            val = fortrand.vonmisesvariate(math.pi, 0.5)
            assert isinstance(val, float)
            assert 0 <= val <= 2 * math.pi
            
    def test_gammavariate(self):
        for _ in range(10):
            val = fortrand.gammavariate(1.0, 2.0)
            assert isinstance(val, float)
            assert val >= 0
            
    def test_betavariate(self):
        for _ in range(10):
            val = fortrand.betavariate(1.0, 1.0)
            assert isinstance(val, float)
            assert 0.0 <= val <= 1.0
            
    def test_paretovariate(self):
        for _ in range(10):
            val = fortrand.paretovariate(2.0)
            assert isinstance(val, float)
            
    def test_weibullvariate(self):
        for _ in range(10):
            val = fortrand.weibullvariate(1.0, 1.5)
            assert isinstance(val, float)
            assert val >= 0

class TestDiscreteDistributions:
    def test_binomialvariate(self):
        # Binomial distribution: n independent trials with probability p
        n = 10
        p = 0.5
        for _ in range(100):
            val = fortrand.binomialvariate(n, p)
            assert isinstance(val, int)
            assert 0 <= val <= n

