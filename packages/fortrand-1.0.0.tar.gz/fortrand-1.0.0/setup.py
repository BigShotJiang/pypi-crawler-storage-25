from setuptools import setup, Extension, find_packages

module = Extension(
    '_fortrand',
    sources=['src/fortrand/_fortrandmodule.c'],

)

setup(
    ext_modules=[module],
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
)