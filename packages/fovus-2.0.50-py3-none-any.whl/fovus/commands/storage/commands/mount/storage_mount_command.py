import logging
import os
import secrets
import shutil
import subprocess  # nosec
import textwrap
import time
from datetime import datetime
from datetime import time as dt_time
from datetime import timedelta
from typing import Optional

import click
from typing_extensions import Union

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.cli.helpers import install_s3_mount_setup
from fovus.config.config import Config
from fovus.constants.cli_action_runner_constants import GENERIC_SUCCESS
from fovus.constants.cli_constants import AWS_REGION, PATH_TO_CONFIG_ROOT
from fovus.util.aws_credentials_util import (
    get_profiles_from_content,
    is_mount_credentials_exists,
    merge_fovus_profile,
)

from fovus.util.util import Util

logger = logging.getLogger(__name__)

MOUNT_STORAGE_EXPIRES_AT_FILENAME = "mount_storage.expires_at"


def _get_mount_storage_expires_at_path():
    return os.path.join(os.path.expanduser(PATH_TO_CONFIG_ROOT), MOUNT_STORAGE_EXPIRES_AT_FILENAME)


def _is_mount_creds_expired() -> bool:
    """Return True if stored expiry is missing or in the past (so we should refresh)."""
    path = _get_mount_storage_expires_at_path()
    if not os.path.exists(path):
        return True
    try:
        with open(path, encoding="utf-8") as expires_file:
            raw = expires_file.read().strip()
        if not raw:
            return True
        stored = datetime.fromisoformat(raw.replace("Z", "+00:00")).replace(tzinfo=None)
        return stored <= datetime.now()
    except (ValueError, OSError):
        return True


def _persist_expires_at(expires_at: datetime, config_dir: Optional[str] = None) -> None:
    """
    Write stored expiry so we can detect when to refresh on next run.

    If config_dir is set, write there (same dir as mount_storage.path); otherwise use PATH_TO_CONFIG_ROOT.
    """
    if config_dir:
        path = os.path.join(config_dir, MOUNT_STORAGE_EXPIRES_AT_FILENAME)
    else:
        path = _get_mount_storage_expires_at_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, "w", encoding="utf-8") as expires_file:
            expires_file.write(expires_at.isoformat())
    except OSError as err:
        logger.warning("Could not write %s: %s", path, err)


def _update_mount_credentials_file(credentials_content: str) -> None:
    """Update the AWS credentials file with the fovus-storage profile (WSL on Windows, local on Unix)."""
    if Util.is_windows():
        result = subprocess.run(
            [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                "cat ~/.aws/credentials 2>/dev/null || echo ''",
            ],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec
        existing_content = result.stdout
        updated_credentials = merge_fovus_profile(credentials_content, existing_content)
        escaped_credentials = updated_credentials.replace("'", "'\\''")
        subprocess.run(
            [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                f"echo '{escaped_credentials}' > ~/.aws/credentials",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )  # nosec
        logger.debug("AWS credentials updated successfully with [fovus-storage] profile (WSL)")
    else:
        credentials_file_path = os.path.expanduser("~/.aws/credentials")
        existing_content = ""
        if os.path.exists(credentials_file_path):
            with open(credentials_file_path, encoding="utf-8") as file:
                existing_content = file.read()
        updated_credentials = merge_fovus_profile(credentials_content, existing_content)
        with open(credentials_file_path, "w", encoding="utf-8") as file:
            file.write(updated_credentials)
        logger.debug("AWS credentials updated successfully with [fovus-storage] profile")


def _schedule_one_time_task_windows(schedule_at: datetime) -> None:
    """Schedule one-time FovusMountStorageRefresh task at the given time (same task name for refresh or retry)."""
    formatted_date = schedule_at.strftime("%d/%m/%Y")
    formatted_time = schedule_at.strftime("%H:%M")
    startup_folder = os.path.join(
        os.getenv("APPDATA", ""),
        "Microsoft",
        "Windows",
        "Start Menu",
        "Programs",
        "Startup",
    )
    mount_fovus_storage_script_path = os.path.join(startup_folder, "mount_fovus_storage.vbs")
    task_action = rf'C:\Windows\System32\cscript.exe "{mount_fovus_storage_script_path}"'
    result = subprocess.run(
        [
            "schtasks",
            "/create",
            "/tn",
            "FovusMountStorageRefresh",
            "/tr",
            task_action,
            "/sc",
            "once",
            "/st",
            formatted_time,
            "/sd",
            formatted_date,
            "/f",
        ],
        capture_output=True,
        text=True,
        check=False,
    )  # nosec
    if result.returncode != 0:
        logger.warning(
            "Could not create scheduled task: %s %s",
            result.stdout or "",
            result.stderr or "",
        )


def _schedule_refresh_windows(expires_at: datetime) -> None:
    """Schedule one-time refresh at midnight (day after expiry) + 0-60s random."""
    refresh_datetime = datetime.combine((expires_at + timedelta(days=1)).date(), dt_time(0, 0)) + timedelta(
        seconds=secrets.randbelow(61)
    )
    if refresh_datetime <= datetime.now():
        refresh_datetime = datetime.now() + timedelta(minutes=1)
    _schedule_one_time_task_windows(refresh_datetime)


def _schedule_refresh_retry_windows() -> None:
    """Schedule a one-time retry in 5 minutes (e.g. when unmount failed due to busy)."""
    _schedule_one_time_task_windows(datetime.now() + timedelta(minutes=5))


@click.command("mount")
@click.option(
    "--mount-storage-path",
    type=str,
    help="The path where Fovus Storage will be mounted. The default path is /fovus-storage/.",
)
@click.option(
    "--windows-drive",
    type=str,
    help='For Windows operating systems only. The drive where Fovus Storage will be mounted. The default drive is "M".',
)
def storage_mount_command(mount_storage_path: Union[str, None], windows_drive: Union[str, None]):
    r"""
    Mount Fovus Storage on your computer.

    Supported operating systems: Windows, Ubuntu, CentOS, and Redhat.

    Fovus Storage will be mounted as a network file system at /fovus-storage/ on Linux or
    <WindowsDrive>:\\fovus-storage\\ on Windows.

    Supported file operations: sequential & random read, sequential write, overwrite, delete

    Job files are read-only.

    The Fovus Storage network file system does not support modifying existing files directly.
    To modify a file, overwrite it instead. We recommend using Fovus Storage as a cloud archive
    instead of a working directory due to suboptimal performance and usability.
    """
    if Util.is_windows() or Util.is_unix():
        install_s3_mount_setup()
        _mount_storage(mount_storage_path, windows_drive)
    else:
        print(f"Fovus mount storage is not available for your OS ({os.name}).")


def _mount_storage(  # pylint: disable=too-many-branches,too-many-statements
    mount_storage_path: Union[str, None] = None,
    windows_drive: Union[str, None] = None,
):
    print("Mounting Fovus Storage...")
    fovus_api_adapter = FovusApiAdapter()
    user_id = fovus_api_adapter.get_user_id()
    workspace_id = fovus_api_adapter.get_workspace_id()
    workspace_region = Config.get(AWS_REGION)
    fovus_cli_path = Util.get_fovus_cli_path()

    if mount_storage_path:
        mount_storage_path = mount_storage_path.strip().replace("\\", "/")
        if not mount_storage_path.startswith("/"):
            mount_storage_path = "/" + mount_storage_path
        if not mount_storage_path.endswith("/"):
            mount_storage_path = mount_storage_path + "/"

    mounted_storage_script_path = os.path.join(os.path.expanduser(PATH_TO_CONFIG_ROOT), "mount_storage.path")
    if not mount_storage_path:
        if os.path.exists(mounted_storage_script_path):
            with open(mounted_storage_script_path, encoding="utf-8") as file:
                mount_storage_path = file.read().strip()
        else:
            mount_storage_path = "/fovus-storage/"

    print("Mount storage path:", mount_storage_path)
    validation_result = _validate_mount_path(mount_storage_path)
    if validation_result["isValid"]:
        if is_mount_credentials_exists() and _is_mount_creds_expired():
            # Refresh credentials only; mount will pick up new creds from file (no unmount/remount).
            credentials_content, expires_at = _get_mount_storage_credentials()
            _update_mount_credentials_file(credentials_content)
            _persist_expires_at(expires_at, config_dir=os.path.dirname(mounted_storage_script_path))
            if Util.is_windows():
                _schedule_refresh_windows(expires_at)
            print("Credentials refreshed. Mount will use new credentials automatically.")
            print(GENERIC_SUCCESS)
            return

        # Fovus Storage is already mounted but no credentials file found. This could be running on a Fovus EC2 instance.
        print(validation_result["message"])
        print(GENERIC_SUCCESS)
        return

    credentials_content, expires_at = _get_mount_storage_credentials()

    if Util.is_unix():
        for mount_dir in ["files", "jobs", "pipelines"]:
            path = f"{mount_storage_path}{mount_dir}"
            if os.path.exists(path) and any(os.scandir(path)):
                print(f"{mount_storage_path} is not empty. The specified path must be an empty folder.")
                return

    with open(mounted_storage_script_path, "w", encoding="utf-8") as script_file:
        script_file.write(mount_storage_path)
    # Write expires_at in same directory as mount_storage.path so it always lands next to it
    _persist_expires_at(expires_at, config_dir=os.path.dirname(mounted_storage_script_path))

    if workspace_region == "us-east-1":
        endpoint_url = "https://s3.amazonaws.com"
    else:
        endpoint_url = f"https://s3.{workspace_region}.amazonaws.com"

    mount_command = (
        f"mount-s3 fovus-{user_id}-{workspace_id}-{workspace_region} {mount_storage_path}files --prefix=files/ "
        f"--allow-delete --file-mode=0770 --dir-mode=0770 --endpoint-url {endpoint_url} "
        f"--profile fovus-storage > /dev/null 2>&1 && "
        f"mount-s3 fovus-{user_id}-{workspace_id}-{workspace_region} {mount_storage_path}jobs "
        "--prefix=jobs/ --allow-delete --file-mode=0550 --dir-mode=0550 "
        f"--endpoint-url {endpoint_url} --profile fovus-storage > /dev/null 2>&1 && "
        f"mount-s3 fovus-{user_id}-{workspace_id}-{workspace_region} {mount_storage_path}pipelines "
        f"--prefix=pipelines/ --allow-delete --file-mode=0770 --dir-mode=0770 "
        f"--endpoint-url {endpoint_url} --profile fovus-storage > /dev/null 2>&1"
    )

    for directory in [
        "~/.aws",
        "~/.fovus",
        f"{mount_storage_path}files",
        f"{mount_storage_path}jobs",
        f"{mount_storage_path}pipelines",
    ]:
        if Util.is_windows():
            check_directory_command = [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                f"[ -d {directory} ] && echo 'Exists' || echo 'Not Exists'",
            ]
            result = subprocess.run(check_directory_command, capture_output=True, text=True, check=False)  # nosec
            if result.stdout.strip() == "Not Exists":
                create_directory_command = [
                    "wsl",
                    "-d",
                    "Fovus-Ubuntu",
                    "-u",
                    "root",
                    "bash",
                    "-c",
                    f"mkdir -p {directory}",
                ]
                subprocess.run(  # nosec
                    create_directory_command,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
        elif Util.is_unix():
            if not os.path.exists(os.path.expanduser(f"{directory}")):
                os.system(f"sudo mkdir -p {directory}")  # nosec
                os.system(f"sudo chmod 777 {directory}")  # nosec

    if Util.is_windows():
        for file_name in [".credentials", ".device_information"]:
            with open(os.path.join(PATH_TO_CONFIG_ROOT, file_name), encoding="utf-8") as file:
                fovus_credentials_content = file.read()
            subprocess.run(  # nosec
                [
                    "wsl",
                    "-d",
                    "Fovus-Ubuntu",
                    "-u",
                    "root",
                    "bash",
                    "-c",
                    f"echo '{fovus_credentials_content.strip()}' > ~/.fovus/{file_name}",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )

        log_script_path = os.path.join(os.path.expanduser(PATH_TO_CONFIG_ROOT), "wsl_status.log")
        os.system(f"wsl --version > {log_script_path}")  # nosec
        os.system(f"wsl --status >> {log_script_path}")  # nosec
        os.system(f"wsl --list >> {log_script_path}")  # nosec

        # Update AWS credentials file with fovus-storage profile in WSL
        logger.debug("Updating AWS credentials with fovus-storage profile (WSL)")

        # First, read existing credentials from WSL
        result = subprocess.run(
            [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                "cat ~/.aws/credentials 2>/dev/null || echo ''",
            ],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec

        existing_wsl_content = result.stdout

        if existing_wsl_content.strip():
            # Count existing profiles
            existing_profiles = get_profiles_from_content(existing_wsl_content)
            logger.debug("Found %d existing AWS profile(s) in credentials file", len(existing_profiles))
            if existing_profiles:
                logger.debug("Existing profiles: %s", ", ".join(existing_profiles))
        else:
            logger.debug("No existing AWS credentials file found, creating new one")

        updated_credentials = merge_fovus_profile(credentials_content, existing_wsl_content)

        # Write updated credentials to WSL
        # Escape single quotes for bash
        escaped_credentials = updated_credentials.replace("'", "'\\''")
        subprocess.run(  # nosec
            [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                f"echo '{escaped_credentials}' > ~/.aws/credentials",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        logger.debug("AWS credentials updated successfully with [fovus-storage] profile")
        subprocess.run(  # nosec
            [
                "wsl",
                "-d",
                "Fovus-Ubuntu",
                "-u",
                "root",
                "bash",
                "-c",
                f"echo '{mount_command}' > /etc/profile.d/fovus-storage-init.sh",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        subprocess.run(  # nosec
            ["wsl", "-d", "Fovus-Ubuntu", "--shutdown"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        mounted_drive_script_path = os.path.join(os.path.expanduser(PATH_TO_CONFIG_ROOT), "mount_storage.drive")
        if not windows_drive:
            if os.path.exists(mounted_drive_script_path):
                with open(mounted_drive_script_path, encoding="utf-8") as file:
                    windows_drive = file.read().strip()
            else:
                windows_drive = "M"

        with open(mounted_drive_script_path, "w", encoding="utf-8") as script_file:
            script_file.write(windows_drive)

        launch_wsl_script_content = rf"""Set shell = CreateObject("WScript.Shell")
        shell.Run "wsl -d Fovus-Ubuntu", 0
        Set FSO = CreateObject("Scripting.FileSystemObject")

        If FSO.DriveExists("{windows_drive}:\") Then
            WScript.Echo "{windows_drive}: drive is already mapped."
        Else
            shell.Run "cmd /c net use {windows_drive}: \\wsl.localhost\Fovus-Ubuntu /persistent:yes", 0
            WScript.Echo "WSL directory mapped to {windows_drive}: drive."
        End If
        """
        launch_wsl_script_path = os.path.join(os.path.expanduser(PATH_TO_CONFIG_ROOT), "launch_wsl.vbs")

        with open(launch_wsl_script_path, "w", encoding="utf-8") as script_file:
            script_file.write(launch_wsl_script_content)

        subprocess.run(  # nosec
            f'cscript "{launch_wsl_script_path}"',
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        # https://superuser.com/questions/263545/how-can-i-make-a-vb-script-execute-every-time-windows-starts-up
        os.path.expanduser(PATH_TO_CONFIG_ROOT)
        mount_fovus_storage_script_content = rf"""Set shell = CreateObject("WScript.Shell")
        shell.Run "cmd /c {fovus_cli_path} storage mount", 0"""
        startup_folder = os.path.join(
            os.getenv("APPDATA", ""),
            "Microsoft",
            "Windows",
            "Start Menu",
            "Programs",
            "Startup",
        )  # Use Win + R -> shell:startup
        mount_fovus_storage_script_path = os.path.join(startup_folder, "mount_fovus_storage.vbs")

        with open(mount_fovus_storage_script_path, "w", encoding="utf-8") as script_file:
            script_file.write(mount_fovus_storage_script_content)

        _schedule_refresh_windows(expires_at)
        windows_path = mount_storage_path.replace("/", "\\")
        print(
            rf"Your Fovus Storage is successfully mounted under the path of {windows_drive}:{windows_path} as a "
            rf'network file system. The path to "My files" is {windows_drive}:{windows_path}files, '
            rf'and the path to "Job files" is {windows_drive}:{windows_path}jobs. Job files are read-only.'
            "\n\n"
            "The mounted network file system is optimized for high throughput read to large files by multiple "
            "clients in parallel and sequential write to new files by one client at a time subject to your network "
            "speed.\n"
            "NOTE: Job files under the mounted Fovus Storage are only synced upon job completion. While a job is "
            "running, an instant sync of job files to the mounted Fovus Storage can be triggered via Fovus web UI "
            'by clicking the refresh button on the job detail page over the "Files" tab.'
        )
        print(
            f"\033[93mA system reboot may be required. If you do not see a new {windows_drive}:\\ drive gets mounted "
            'under "This PC", please reboot your system for it to take effect.\033[0m'
        )
    elif Util.is_unix():
        # Update AWS credentials file with fovus-storage profile
        logger.debug("Updating AWS credentials with fovus-storage profile")
        credentials_file_path = os.path.expanduser("~/.aws/credentials")

        # Read existing credentials if file exists
        existing_content = ""
        if os.path.exists(credentials_file_path):
            with open(credentials_file_path, encoding="utf-8") as file:
                existing_content = file.read()

            # Count existing profiles
            existing_profiles = get_profiles_from_content(existing_content)
            logger.debug("Found %d existing AWS profile(s) in credentials file", len(existing_profiles))
            if existing_profiles:
                logger.debug("Existing profiles: %s", ", ".join(existing_profiles))
        else:
            logger.debug("No existing AWS credentials file found, creating new one")

        updated_credentials = merge_fovus_profile(credentials_content, existing_content)

        # Write updated credentials
        with open(credentials_file_path, "w", encoding="utf-8") as file:
            file.write(updated_credentials)

        logger.debug("AWS credentials updated successfully with [fovus-storage] profile")

        fovus_storage_init_path = "/etc/profile.d/fovus-storage-init.sh"
        fovus_storage_init_command = textwrap.dedent(
            f"""\
            export FOVUS_CLI_PATH="{fovus_cli_path}"
            "$FOVUS_CLI_PATH" storage mount || echo "Failed to mount Fovus Storage"
            """
        )
        if not os.path.exists(fovus_storage_init_path):
            os.system(
                f"echo '{fovus_storage_init_command}' | sudo tee {fovus_storage_init_path} > /dev/null 2>&1"
            )  # nosec
        if shutil.which("at"):
            # Same schedule as Windows: midnight (day after expiry) + 0-60s random
            refresh_datetime = datetime.combine((expires_at + timedelta(days=1)).date(), dt_time(0, 0)) + timedelta(
                seconds=secrets.randbelow(61)
            )
            if refresh_datetime <= datetime.now():
                refresh_datetime = datetime.now() + timedelta(minutes=1)
            at_time_arg = refresh_datetime.strftime("%Y%m%d%H%M") + "." + refresh_datetime.strftime("%S")
            # https://www.redhat.com/sysadmin/linux-at-command
            os.system("atq | cut -f 1 | xargs atrm > /dev/null 2>&1")  # nosec
            os.system(f"echo '{fovus_storage_init_command}' | at -t {at_time_arg} > /dev/null 2>&1")  # nosec

        time.sleep(10)  # wait for credentials to be active
        mount_exit_code = os.system(mount_command)  # nosec

        if mount_exit_code != 0:
            logger.warning("Mount failed (exit code %d), re-fetching credentials and retrying once", mount_exit_code)
            retry_credentials_content, _ = _get_mount_storage_credentials()
            retry_updated = merge_fovus_profile(retry_credentials_content, updated_credentials)
            with open(credentials_file_path, "w", encoding="utf-8") as file:
                file.write(retry_updated)
            time.sleep(10)
            mount_exit_code = os.system(mount_command)  # nosec

        if mount_exit_code != 0:
            print("Failed to mount Fovus Storage. Please check your credentials and try again.")
            return

        print(
            f"Your Fovus Storage is successfully mounted under the path of {mount_storage_path} as a network "
            f'file system (a system reboot may be needed). The path to "My files" is {mount_storage_path}files, '
            f'and the path to "Job files" is {mount_storage_path}jobs. Job files are read-only.'
            "\n\n"
            "The mounted network file system is optimized for high throughput read to large files by multiple "
            "clients in parallel and sequential write to new files by one client at a time subject to your network "
            "speed.\n"
            "NOTE: Job files under the mounted Fovus Storage are only synced upon job completion. While a job is "
            "running, an instant sync of job files to the mounted Fovus Storage can be triggered via Fovus web UI "
            'by clicking the refresh button on the job detail page over the "Files" tab.'
        )


def _get_mount_storage_credentials():
    fovus_api_adapter = FovusApiAdapter()
    user_id = fovus_api_adapter.get_user_id()
    workspace_id = fovus_api_adapter.get_workspace_id()

    mount_storage_credentials_body = fovus_api_adapter.get_mount_storage_credentials(
        FovusApiAdapter.get_mount_storage_credentials_request(user_id, workspace_id)
    )
    credentials_content = f"""[fovus-storage]
aws_access_key_id = {mount_storage_credentials_body["credentials"]["accessKeyId"]}
aws_secret_access_key = {mount_storage_credentials_body["credentials"]["secretAccessKey"]}
"""
    expires_at_str = mount_storage_credentials_body.get("expiresAt")
    if expires_at_str:
        expires_at = datetime.fromisoformat(expires_at_str.replace("Z", "+00:00")).replace(tzinfo=None)
    else:
        expires_at = datetime.now() + timedelta(days=28)

    return credentials_content, expires_at


def _validate_mount_path(mount_storage_path: str) -> dict:
    validation_result = {"isValid": False, "message": ""}

    if Util.is_windows():
        list_mounts_command = ["wsl", "-d", "Fovus-Ubuntu", "-u", "root", "bash", "-c", "mount"]
    else:
        list_mounts_command = ["mount"]

    try:
        mount_result = subprocess.run(list_mounts_command, capture_output=True, text=True, check=True)  # nosec B603
    except subprocess.CalledProcessError as err:
        logging.error("Failed to list system mounts: %s", err.stderr)
        raise RuntimeError("Failed to get system mounts") from err

    system_mounts = mount_result.stdout.split("\n")
    if len(system_mounts) == 0:
        validation_result["isValid"] = False
        validation_result["message"] = "No fovus storage mount was found in the system"
        return validation_result

    for mount in system_mounts:
        if not mount or not mount.startswith("mountpoint-s3"):
            continue
        mount_parts = mount.split(" ")
        if len(mount_parts) < 3:
            continue

        mount_path = mount_parts[2]
        if mount_path.startswith(mount_storage_path):
            validation_result["isValid"] = True
            validation_result["message"] = (
                f"Fovus Storage was already mounted at {mount_path}. If this was an error, "
                "please unmount the storage with 'fovus storage unmount' and try again."
            )
            return validation_result

    validation_result["isValid"] = False
    validation_result["message"] = "Fovus storage is not mounted"
    return validation_result
