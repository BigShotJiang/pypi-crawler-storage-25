import click

from fovus.commands.pipeline.commands.create.pipeline_create_command import (
    pipeline_create_command,
)
from fovus.commands.pipeline.commands.delete.pipeline_delete_command import (
    pipeline_delete_command,
)
from fovus.commands.pipeline.commands.get.pipeline_get_command import (
    pipeline_get_command,
)
from fovus.commands.pipeline.commands.pre_config_resources.pipeline_pre_config_resources_command import (
    pipeline_pre_config_resources_command,
)
from fovus.commands.pipeline.commands.resume.pipeline_resume_command import (
    pipeline_resume_command,
)
from fovus.commands.pipeline.commands.stop.pipeline_stop_command import (
    pipeline_stop_command,
)
from fovus.commands.pipeline.commands.update.pipeline_update_command import (
    pipeline_update_command,
)
from fovus.commands.pipeline.commands.upload.pipeline_upload_command import (
    pipeline_upload_command,
)


@click.group("pipeline")
def pipeline_command():
    """Contains commands related to pipeline."""


pipeline_command.add_command(pipeline_create_command)
pipeline_command.add_command(pipeline_resume_command)
pipeline_command.add_command(pipeline_stop_command)
pipeline_command.add_command(pipeline_delete_command)
pipeline_command.add_command(pipeline_update_command)
pipeline_command.add_command(pipeline_get_command)
pipeline_command.add_command(pipeline_pre_config_resources_command)
pipeline_command.add_command(pipeline_upload_command)
