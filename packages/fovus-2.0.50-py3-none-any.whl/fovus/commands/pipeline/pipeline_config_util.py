"""Shared utilities for pipeline create and resume commands."""

import json
import os
from typing_extensions import Optional

from http import HTTPStatus

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.adapter.fovus_s3_adapter import FovusS3Adapter, UploadType
from fovus.exception.user_exception import UserException
from fovus.util.file_util import FileUtil
from fovus.util.util import Util
from fovus.validator.pipeline_config_validator import (
    CONFIGURATION,
    RUN_COMMAND,
    SETUP_COMMAND,
    WORKFLOW_MANAGER,
    WorkflowManager,
)

NAME = "name"
PROJECT_NAME = "projectName"
AUTO_DELETE_DAYS = "autoDeleteDays"

WILDCARD_HELP = (
    " Relative paths inside PIPELINE_DIRECTORY. Use * and ? for wildcards. "
    "Only one of --include-paths or --exclude-paths."
)


def load_config(config_path: Optional[str]) -> dict:
    """Load pipeline config from JSON file. Returns empty dict if path is empty or None."""
    if not config_path or not str(config_path).strip():
        return {}
    expanded_path = os.path.expanduser(config_path)
    with FileUtil.open(expanded_path) as f:
        return json.load(f)


def merge_config_with_overrides(config: dict, overrides: dict) -> dict:
    """Merge config with CLI overrides. Overrides take precedence."""
    merged = dict(config)
    for key, value in overrides.items():
        if value is not None:
            if key == CONFIGURATION and isinstance(value, dict) and isinstance(merged.get(CONFIGURATION), dict):
                merged[CONFIGURATION] = {**merged[CONFIGURATION], **value}
            else:
                merged[key] = value
    return merged


def build_configuration_overrides(
    setup_command: Optional[str] = None,
    run_command: Optional[str] = None,
    workflow_manager: Optional[str] = None,
) -> dict:
    """Build configuration overrides from CLI args. Adds default workflowManager if needed."""
    overrides = {}
    if setup_command is not None:
        overrides[SETUP_COMMAND] = setup_command
    if run_command is not None:
        overrides[RUN_COMMAND] = run_command
    if workflow_manager is not None:
        overrides[WORKFLOW_MANAGER] = workflow_manager
    elif overrides and WORKFLOW_MANAGER not in overrides:
        overrides[WORKFLOW_MANAGER] = WorkflowManager.NEXTFLOW.value
    return overrides


def build_remote_overrides(
    name: Optional[str] = None,
    project_name: Optional[str] = None,
    auto_delete_days: Optional[int] = None,
    setup_command: Optional[str] = None,
    run_command: Optional[str] = None,
    workflow_manager: Optional[str] = None,
) -> dict:
    """Build overrides dict for remote pipeline (create or resume)."""
    overrides = {
        NAME: name,
        AUTO_DELETE_DAYS: auto_delete_days,
    }
    if project_name is not None:
        overrides[PROJECT_NAME] = project_name
    config_overrides = build_configuration_overrides(setup_command, run_command, workflow_manager)
    if config_overrides:
        overrides[CONFIGURATION] = config_overrides
    return overrides


def build_resume_overrides(
    setup_command: Optional[str] = None,
    run_command: Optional[str] = None,
) -> dict:
    """Build overrides for resume. Only setupCommand and runCommand are writable.
    """
    overrides = {}
    config_overrides = {}
    if setup_command is not None:
        config_overrides[SETUP_COMMAND] = setup_command
    if run_command is not None:
        config_overrides[RUN_COMMAND] = run_command
    if config_overrides:
        overrides[CONFIGURATION] = config_overrides
    return overrides


def normalize_configuration_for_api(configuration: dict) -> dict:
    """Normalize configuration for API: workflowManager to uppercase (e.g. NEXTFLOW)."""
    if not configuration:
        return configuration
    result = dict(configuration)
    if WORKFLOW_MANAGER in result and result[WORKFLOW_MANAGER] and isinstance(result[WORKFLOW_MANAGER], str):
        result[WORKFLOW_MANAGER] = result[WORKFLOW_MANAGER].upper()
    return result


def build_resume_api_payload(payload: dict) -> dict:
    """Extract resume API payload. Only configuration (setupCommand, runCommand) is sent."""
    api_payload = {}
    if CONFIGURATION in payload and payload[CONFIGURATION] is not None:
        configuration = payload[CONFIGURATION]
        if isinstance(configuration, dict):
            filtered_configuration = {}
            if SETUP_COMMAND in configuration and configuration[SETUP_COMMAND] is not None:
                filtered_configuration[SETUP_COMMAND] = configuration[SETUP_COMMAND]
            if RUN_COMMAND in configuration and configuration[RUN_COMMAND] is not None:
                filtered_configuration[RUN_COMMAND] = configuration[RUN_COMMAND]
            if filtered_configuration:
                api_payload["configuration"] = filtered_configuration
    return api_payload


def upload_pipeline_directory(
    fovus_api_adapter: FovusApiAdapter,
    pipeline_id: str,
    local_dir: str,
    include_paths_tuple: tuple,
    exclude_paths_tuple: tuple,
    message: str = "Uploading to pipeline storage...",
) -> None:
    """Upload a local directory to remote path ``pipelines/<pipeline_id>``.

    Raises UserException if local_dir does not exist, is not a directory,
    or is not readable/accessible (read and execute permissions required).
    """
    expanded_dir = os.path.expanduser(local_dir)
    if not os.path.exists(expanded_dir):
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            "Pipeline directory not found",
            f"Pipeline directory does not exist: {expanded_dir}. "
            "Remote runs expect files to be uploaded; provide a valid path.",
        )
    if not os.path.isdir(expanded_dir):
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            "Pipeline directory not a directory",
            f"Path is not a directory: {expanded_dir}.",
        )
    if not os.access(expanded_dir, os.R_OK | os.X_OK):
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            "Pipeline directory not accessible",
            f"Pipeline directory is not readable or not executable: {expanded_dir}. "
            "Ensure the directory has read and execute permissions.",
        )
    include_paths = Util.parse_include_exclude_paths(include_paths_tuple)
    exclude_paths = Util.parse_include_exclude_paths(exclude_paths_tuple)
    print(message)
    fovus_s3_adapter = FovusS3Adapter(
        fovus_api_adapter,
        root_directory_path=expanded_dir,
        fovus_path=pipeline_id,
        include_paths=include_paths,
        exclude_paths=exclude_paths,
    )
    fovus_s3_adapter.upload_storage_files(upload_type=UploadType.UPLOAD_TO_PIPELINES)
    Util.print_success_message("Files uploaded successfully.")
