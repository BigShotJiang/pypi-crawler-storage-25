from http import HTTPStatus

import click
from typing_extensions import Optional, Tuple

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.commands.pipeline.pipeline_config_util import (
    CONFIGURATION,
    WILDCARD_HELP,
    build_resume_api_payload,
    build_resume_overrides,
    load_config,
    merge_config_with_overrides,
    upload_pipeline_directory,
)
from fovus.constants.cli_action_runner_constants import GENERIC_SUCCESS
from fovus.exception.user_exception import UserException
from fovus.util.util import Util
from fovus.validator.pipeline_config_validator import (
    RUN_COMMAND,
    SETUP_COMMAND,
    WORKFLOW_HOST,
    WorkflowHost,
)


@click.command("resume")
@click.option(
    "--pipeline-id",
    type=str,
    required=True,
    help="The ID of the pipeline to resume.",
)
@click.option(
    "--pipeline-directory",
    "pipeline_directory",
    type=str,
    default=None,
    help="Local directory to upload to remote pipeline storage. If omitted, no files are uploaded.",
)
@click.option(
    "-c",
    "--config",
    "config_path",
    type=str,
    help=(
        "Path to pipeline config JSON for optional overrides. "
        "Only configuration.setupCommand and configuration.runCommand are writable."
    ),
)
@click.option(
    "--setup-command",
    type=str,
    help="Setup command for remote execution. Overrides config if provided.",
)
@click.option(
    "--run-command",
    type=str,
    help="Run command for remote execution. Overrides config if provided.",
)
@click.option(
    "--include-paths",
    "include_paths_tuple",
    metavar="include_paths",
    type=str,
    multiple=True,
    help="Include only these paths when uploading pipeline directory." + WILDCARD_HELP,
)
@click.option(
    "--exclude-paths",
    "exclude_paths_tuple",
    metavar="exclude_paths",
    type=str,
    multiple=True,
    help="Exclude these paths when uploading pipeline directory." + WILDCARD_HELP,
)
def pipeline_resume_command(
    pipeline_id: str,
    pipeline_directory: Optional[str],
    config_path: Optional[str],
    setup_command: Optional[str],
    run_command: Optional[str],
    include_paths_tuple: Tuple[str, ...],
    exclude_paths_tuple: Tuple[str, ...],
):
    """
    Resume a remote pipeline execution.

    Only writable fields are configuration.setupCommand and configuration.runCommand.
    Any other fields are ignored by backend.
    """
    config = load_config(config_path)
    configuration = config.get(CONFIGURATION)

    ignored_top_level_keys = sorted([key for key in config.keys() if key != CONFIGURATION])
    for key in ignored_top_level_keys:
        Util.print_warning_message(f"Ignoring '{key}' from resume config. This field cannot be changed by resume.")

    if isinstance(configuration, dict):
        ignored_configuration_keys = sorted(
            [key for key in configuration.keys() if key not in (SETUP_COMMAND, RUN_COMMAND)]
        )
        for key in ignored_configuration_keys:
            Util.print_warning_message(
                f"Ignoring '{CONFIGURATION}.{key}' from resume config. Only '{CONFIGURATION}.{SETUP_COMMAND}' and "
                f"'{CONFIGURATION}.{RUN_COMMAND}' are applied."
            )

    overrides = build_resume_overrides(
        setup_command=setup_command,
        run_command=run_command,
    )

    filtered_config = {}
    if isinstance(configuration, dict):
        filtered_configuration = {}
        if configuration.get(SETUP_COMMAND) is not None:
            filtered_configuration[SETUP_COMMAND] = configuration[SETUP_COMMAND]
        if configuration.get(RUN_COMMAND) is not None:
            filtered_configuration[RUN_COMMAND] = configuration[RUN_COMMAND]
        if filtered_configuration:
            filtered_config[CONFIGURATION] = filtered_configuration

    payload = merge_config_with_overrides(filtered_config, overrides)
    if CONFIGURATION in payload and payload[CONFIGURATION]:
        configuration_to_resume = payload[CONFIGURATION]
        if not isinstance(configuration_to_resume, dict):
            raise UserException(
                HTTPStatus.BAD_REQUEST,
                "Invalid resume config",
                f"'{CONFIGURATION}' must be an object.",
            )
        if not configuration_to_resume.get(SETUP_COMMAND):
            raise UserException(
                HTTPStatus.BAD_REQUEST,
                "Invalid resume config",
                f"Missing required field '{CONFIGURATION}.{SETUP_COMMAND}'.",
            )
        if not configuration_to_resume.get(RUN_COMMAND):
            raise UserException(
                HTTPStatus.BAD_REQUEST,
                "Invalid resume config",
                f"Missing required field '{CONFIGURATION}.{RUN_COMMAND}'.",
            )

    print("Authenticating...")
    fovus_api_adapter = FovusApiAdapter()

    # Check if pipeline exists before uploading files
    print("Fetching pipeline info...")
    pipeline_info = fovus_api_adapter.get_pipeline(pipeline_id)
    if pipeline_info.get(WORKFLOW_HOST, WorkflowHost.LOCAL.value).lower() == WorkflowHost.LOCAL.value.lower():
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            "Invalid pipeline ID",
            f"Pipeline {pipeline_id} is not resumeable because it was not previously run with remote Fovus Host.",
        )

    if pipeline_directory:
        upload_pipeline_directory(
            fovus_api_adapter,
            pipeline_id,
            pipeline_directory,
            include_paths_tuple,
            exclude_paths_tuple,
            message="Uploading pipeline directory to remote storage...",
        )

    api_payload = build_resume_api_payload(payload)
    print("Resuming pipeline...")
    response = fovus_api_adapter.resume_pipeline(pipeline_id, api_payload)
    Util.print_success_message(GENERIC_SUCCESS)
    print(response)
