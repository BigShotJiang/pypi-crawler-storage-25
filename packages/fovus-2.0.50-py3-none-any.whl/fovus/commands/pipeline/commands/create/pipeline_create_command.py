from http import HTTPStatus

import click
from typing_extensions import Optional, Tuple

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.commands.pipeline.pipeline_config_util import (
    AUTO_DELETE_DAYS,
    CONFIGURATION,
    NAME,
    PROJECT_NAME,
    WILDCARD_HELP,
    build_remote_overrides,
    load_config,
    merge_config_with_overrides,
    normalize_configuration_for_api,
    upload_pipeline_directory,
)
from fovus.constants.cli_action_runner_constants import GENERIC_SUCCESS
from fovus.exception.user_exception import UserException
from fovus.util.fovus_api_util import FovusApiUtil
from fovus.util.project_util import find_project_id_from_name
from fovus.util.util import Util
from fovus.validator.pipeline_config_validator import (
    WORKFLOW_HOST,
    PipelineConfigValidator,
    WorkflowHost,
    WorkflowManager,
)


def _resolve_workflow_host(config: dict, cli_workflow_host: Optional[str]) -> WorkflowHost:
    """Resolve workflow host: CLI overrides config; default is remote."""
    if cli_workflow_host is not None:
        try:
            return WorkflowHost.parse(cli_workflow_host)
        except ValueError as error:
            raise UserException(
                HTTPStatus.BAD_REQUEST,
                "Invalid workflow host",
                str(error),
            ) from error

    workflow_host_from_config = config.get(WORKFLOW_HOST)
    if isinstance(workflow_host_from_config, str) and workflow_host_from_config.strip():
        try:
            return WorkflowHost.parse(workflow_host_from_config)
        except ValueError as error:
            raise UserException(
                HTTPStatus.BAD_REQUEST,
                "Invalid workflow host",
                str(error),
            ) from error

    return WorkflowHost.REMOTE


def _normalize_cli_workflow_manager(cli_value: Optional[str]) -> Optional[str]:
    """Map CLI workflow-manager choice to configuration workflowManager API value."""
    if cli_value is None:
        return None
    try:
        return WorkflowManager.parse(cli_value).value
    except ValueError as error:
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            "Invalid workflow manager",
            str(error),
        ) from error


@click.command("create")
@click.option(
    "--pipeline-directory",
    "pipeline_directory",
    type=str,
    default=None,
    help="Local directory to upload to remote pipeline storage. If omitted, no files are uploaded.",
)
@click.option(
    "-c",
    "--config",
    "config_path",
    type=str,
    help=(
        "Path to pipeline config JSON. Can specify workflowHost and all create arguments; CLI options override config."
    ),
)
@click.option(
    "--workflow-host",
    "workflow_host",
    type=click.Choice([member.value for member in WorkflowHost], case_sensitive=False),
    default=None,
    help=(
        "Where the workflow runs: local (on your workstation) or remote (on Fovus-hosted compute). "
        "Default: remote, or from config workflowHost if -c is used."
    ),
)
@click.option(
    "--workflow-manager",
    "workflow_manager",
    type=click.Choice([member.value.lower() for member in WorkflowManager], case_sensitive=False),
    default=None,
    help="Workflow engine. Only Nextflow is supported (maps to configuration.workflowManager NEXTFLOW).",
)
@click.option(
    "--name",
    type=str,
    help="The pipeline name. Overrides config if provided.",
)
@click.option(
    "--project-name",
    type=str,
    help=(
        "The project name associated with your pipeline. If omitted, the default project will be used. Use 'None' to"
        " specify no project."
    ),
)
@click.option(
    "--auto-delete-days",
    type=int,
    default=None,
    help=(
        "Number of days after which the pipeline will be permanently deleted. Only applicable when workflow host is"
        " remote."
    ),
)
@click.option(
    "--setup-command",
    type=str,
    help="Setup command for remote execution (e.g. git clone). Overrides config if provided.",
)
@click.option(
    "--run-command",
    type=str,
    help="Run command for remote execution (e.g. nextflow run nf-core/rnaseq). Overrides config if provided.",
)
@click.option(
    "--include-paths",
    "include_paths_tuple",
    metavar="include_paths",
    type=str,
    multiple=True,
    help="Include only these paths when uploading pipeline directory (remote workflow host)." + WILDCARD_HELP,
)
@click.option(
    "--exclude-paths",
    "exclude_paths_tuple",
    metavar="exclude_paths",
    type=str,
    multiple=True,
    help="Exclude these paths when uploading pipeline directory (remote workflow host)." + WILDCARD_HELP,
)
def pipeline_create_command(
    pipeline_directory: Optional[str],
    config_path: Optional[str],
    workflow_host: Optional[str],
    workflow_manager: Optional[str],
    name: Optional[str],
    project_name: Optional[str],
    auto_delete_days: Optional[int],
    setup_command: Optional[str],
    run_command: Optional[str],
    include_paths_tuple: Tuple[str, ...],
    exclude_paths_tuple: Tuple[str, ...],
):
    """
    Create pipeline.

    For local workflow host: creates a pipeline record; you run Nextflow manually on your workstation.

    For remote workflow host: creates and starts pipeline execution on EC2 (requires configuration).
    When PIPELINE_DIRECTORY is provided for remote, uploads files to pipelines/<pipeline-id>
    (similar to job create).

    PIPELINE_DIRECTORY is the local Nextflow project dir (default: current directory). Used for upload when workflow host is remote.

    Use -c/--config to pass a pipeline config JSON. CLI options override config values.
    """
    config = load_config(config_path)
    resolved_host = _resolve_workflow_host(config, workflow_host)

    workflow_manager_override = _normalize_cli_workflow_manager(workflow_manager)

    overrides = build_remote_overrides(
        name=name,
        project_name=project_name,
        auto_delete_days=auto_delete_days,
        setup_command=setup_command,
        run_command=run_command,
        workflow_manager=workflow_manager_override,
    )

    payload = merge_config_with_overrides(config, overrides)
    payload[WORKFLOW_HOST] = resolved_host.value

    validator = PipelineConfigValidator(payload, resolved_host)
    validator.validate()

    print("Authenticating...")
    fovus_api_adapter = FovusApiAdapter()
    user_id = fovus_api_adapter.get_user_id()
    timestamp = FovusApiUtil.generate_timestamp()
    pipeline_id = FovusApiUtil.generate_pipeline_id(timestamp, user_id)

    if resolved_host == WorkflowHost.REMOTE and pipeline_directory:
        upload_pipeline_directory(
            fovus_api_adapter,
            pipeline_id,
            pipeline_directory,
            include_paths_tuple,
            exclude_paths_tuple,
            message="Uploading pipeline directory to remote storage...",
        )

    api_payload = _build_api_payload(fovus_api_adapter, payload, resolved_host, pipeline_id)
    print("Creating pipeline...")
    response = fovus_api_adapter.create_pipeline(api_payload)
    Util.print_success_message(GENERIC_SUCCESS)
    print(response)


def _build_api_payload(
    fovus_api_adapter: FovusApiAdapter, payload: dict, workflow_host: WorkflowHost, pipeline_id: str
) -> dict:
    """Build the API request payload. workspaceId is added by the adapter. projectId resolved from projectName."""
    project_name = payload.get(PROJECT_NAME)
    project_id = find_project_id_from_name(fovus_api_adapter, project_name)
    api_payload = {
        "pipelineId": pipeline_id,
        "name": payload.get(NAME),
        "projectId": project_id,
        "workflowHost": workflow_host.api_value(),
    }
    if workflow_host == WorkflowHost.REMOTE:
        api_payload["autoDeleteDays"] = payload.get(AUTO_DELETE_DAYS)
        config = payload.get(CONFIGURATION)
        if config:
            api_payload["configuration"] = normalize_configuration_for_api(config)
    for key in list(api_payload.keys()):
        if api_payload[key] is None:
            del api_payload[key]
    return api_payload
