import click

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.constants.cli_action_runner_constants import GENERIC_SUCCESS
from fovus.util.util import Util


@click.command("delete")
@click.option(
    "--pipeline-id",
    type=str,
    required=True,
    help="The ID of the pipeline to delete.",
)
def pipeline_delete_command(pipeline_id: str):
    """
    Delete a pipeline and all related resources (jobs, files, etc.).

    This action cannot be undone.
    """
    if not Util.confirm_action(
        message=f"Are you sure you want to permanently delete pipeline {pipeline_id} and all related resources (jobs, files, etc.)? (y/n):"
    ):
        return

    print("Authenticating...")
    fovus_api_adapter = FovusApiAdapter()
    print("Deleting pipeline...")
    fovus_api_adapter.delete_pipeline(pipeline_id)
    Util.print_success_message(GENERIC_SUCCESS)
    print(f"Pipeline {pipeline_id} has been deleted successfully.")
