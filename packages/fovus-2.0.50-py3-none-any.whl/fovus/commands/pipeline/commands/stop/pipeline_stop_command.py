import click

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.constants.cli_action_runner_constants import GENERIC_SUCCESS
from fovus.util.util import Util


@click.command("stop")
@click.option(
    "--pipeline-id",
    type=str,
    required=True,
    help="The ID of the pipeline to stop.",
)
def pipeline_stop_command(pipeline_id: str):
    """
    Stop a remote pipeline and release its EC2 compute resources.
    """
    print("Authenticating...")
    fovus_api_adapter = FovusApiAdapter()
    print("Stopping pipeline...")
    fovus_api_adapter.stop_pipeline(pipeline_id)
    Util.print_success_message(GENERIC_SUCCESS)
    print(f"Pipeline {pipeline_id} has been stopped successfully.")
