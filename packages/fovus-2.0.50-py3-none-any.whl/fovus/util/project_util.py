"""Shared utilities for resolving project name to project ID."""

from http import HTTPStatus
from typing_extensions import Optional

from fovus.adapter.fovus_api_adapter import FovusApiAdapter
from fovus.constants.fovus_api_constants import UserSettings
from fovus.exception.user_exception import UserException
from fovus.util.logger import get_fovus_logger

logger = get_fovus_logger()


def find_project_id_from_name(
    fovus_api_adapter: FovusApiAdapter, project_name: Optional[str] = None
) -> Optional[str]:
    """
    Resolve project name to project ID. Uses default project if project_name is None.
    Returns None if project_name is 'None' (no project).
    """
    active_projects = fovus_api_adapter.list_active_projects()

    if project_name is None:
        project_setting = fovus_api_adapter.get_user_setting(
            {"workspaceId": fovus_api_adapter.workspace_id, "key": UserSettings.DEFAULT_PROJECT_ID.value}
        )
        default_project_id = project_setting.get("value", None)
        if default_project_id is not None:
            logger.info("Project name is not provided. Attempting to use your default project...")
            matched_projects = [p for p in active_projects if p["projectId"] == default_project_id]
            if len(matched_projects) == 0:
                raise UserException(
                    HTTPStatus.BAD_REQUEST,
                    find_project_id_from_name.__name__,
                    "Your configured default project was archived and is no longer available. "
                    + "Please update it on Fovus website or specify a different project name. "
                    + "To see valid project names, run 'fovus projects list'.",
                )
            logger.info(f"Project '{matched_projects[0]['name']}' will be used.")
        return default_project_id

    logger.info(f"Found project name: {project_name}. Validating project name...")
    if project_name.lower() == "none":
        logger.info("Project name is 'None'. This will not be associated with any project.")
        return None
    if len(active_projects) == 0:
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            find_project_id_from_name.__name__,
            "No projects are available. Please contact your cost center admin to create a new project.",
        )
    matched_projects = [p for p in active_projects if p["name"] == project_name]
    if len(matched_projects) == 0:
        raise UserException(
            HTTPStatus.BAD_REQUEST,
            find_project_id_from_name.__name__,
            f"Project name '{project_name}' is not found. "
            + "Please provide a valid project name. To see valid project names, run 'fovus projects list'.",
        )
    return matched_projects[0]["projectId"]
