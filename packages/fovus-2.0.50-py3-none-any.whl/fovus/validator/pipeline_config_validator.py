"""Validator for pipeline create/resume configuration based on workflow host."""

from enum import Enum
from http import HTTPStatus

from fovus.exception.user_exception import UserException

CONFIGURATION = "configuration"
WORKFLOW_MANAGER = "workflowManager"
SETUP_COMMAND = "setupCommand"
RUN_COMMAND = "runCommand"
NAME = "name"
WORKFLOW_HOST = "workflowHost"


class WorkflowHost(str, Enum):
    """Where the workflow runs: CLI/config use lowercase; API uses uppercase (WorkflowHostSchema)."""

    LOCAL = "local"
    REMOTE = "remote"

    def api_value(self) -> str:
        return self.value.upper()

    @classmethod
    def parse(cls, raw: str) -> "WorkflowHost":
        key = raw.strip().lower()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(
            f"Unsupported workflow host {raw!r}; expected one of: {', '.join(m.value for m in cls)}"
        )


class WorkflowManager(str, Enum):
    """configuration.workflowManager values (WorkflowManagerSchema)."""

    NEXTFLOW = "NEXTFLOW"

    @classmethod
    def parse(cls, raw: str) -> "WorkflowManager":
        key = raw.strip().upper()
        for member in cls:
            if member.value == key:
                return member
        raise ValueError(
            f"Unsupported workflow manager {raw!r}; expected one of: {', '.join(m.value for m in cls)}"
        )


class PipelineConfigValidator:
    """Validates pipeline create/resume configuration based on workflow host (local vs remote)."""

    def __init__(self, payload: dict, workflow_host: WorkflowHost):
        self.payload = payload
        self.workflow_host = workflow_host

    def validate(self) -> None:
        """Validate payload for the given workflow host."""
        if self.workflow_host == WorkflowHost.LOCAL:
            self._validate_local()
        elif self.workflow_host == WorkflowHost.REMOTE:
            self._validate_remote()
        else:
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"Unsupported workflow host: {self.workflow_host!r}.",
            )

    def _validate_local(self) -> None:
        """Validate local host: require name only."""
        if not self.payload.get(NAME):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{NAME}' is required when workflow host is local.",
            )

    def _validate_remote(self) -> None:
        """Validate remote host: require name and configuration."""
        if not self.payload.get(NAME):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{NAME}' is required when workflow host is remote.",
            )

        configuration = self.payload.get(CONFIGURATION)
        if not configuration or not isinstance(configuration, dict):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{CONFIGURATION}' with workflowManager, setupCommand, and runCommand is required when workflow host is remote.",
            )

        workflow_manager_value = configuration.get(WORKFLOW_MANAGER)
        if not workflow_manager_value or not isinstance(workflow_manager_value, str):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{CONFIGURATION}.{WORKFLOW_MANAGER}' is required when workflow host is remote.",
            )
        try:
            WorkflowManager.parse(workflow_manager_value)
        except ValueError as error:
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                str(error),
            ) from error

        if not configuration.get(SETUP_COMMAND):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{CONFIGURATION}.{SETUP_COMMAND}' is required when workflow host is remote.",
            )

        if not configuration.get(RUN_COMMAND):
            raise UserException(
                HTTPStatus.BAD_REQUEST.value,
                self.__class__.__name__,
                f"'{CONFIGURATION}.{RUN_COMMAND}' is required when workflow host is remote.",
            )

