from .common import *
import copy
if not php_ims_config_arr:
    if os.name == 'nt':
        system_start.insert_Boot_up(cmd='start /b kwebsp /index/index/mysocket/servers',types='kwebsp',name='内置sockets服务',icon='/index/index/pub/icon?text=sockets')
    elif 'Linux' in get_sysinfo()['platform']:
        system_start.insert_Boot_up(cmd='nohup kwebsp /index/index/mysocket/servers > app/runtime/log/mysocket.log 2>&1 &',types='kwebsp',name='内置sockets服务',icon='/index/index/pub/icon?text=sockets')
    else:
        raise Exception('不支持该操作系统')
class sockets(kcwebssocket):
    async def onConnect(self,clientid,params):
        "#当客户端发来连接时触发的回调函数"
        adminsign=kcwsign.getsign({'admintoken':sockets_admin_authkey,'time':params['time']})
        if is_index(params,'adminsign') and adminsign==params['adminsign'] and abs(times()-int(params['time']))<30:
            pass
        else:
            params1=copy.deepcopy(params)
            params1['token']=get_cache("token")
            del params1['sign']
            sign=kcwsign.getsign(params1)
            if params['sign']==sign and abs(times()-int(params['time']))<30:
                pass
            else:
                await self.CloseSocket(clientid)
                return False
        if is_index(params,'GroupName') and params['GroupName']:
            GroupName=json_decode(params['GroupName'])
            if GroupName and isinstance(GroupName, list):
                for GroupNames in GroupName:
                    self.joinGroup(clientid,GroupNames)
            else:
                self.joinGroup(clientid,params['GroupName'])
        if is_index(params,'unionid') and params['unionid']:
            self.bindUid(clientid,params['unionid'])
        
    async def onMessage(self,clientid,recv_text):
        "当客户端发来数据时触发的回调函数"
        try:
            messagearr=json_decode(recv_text)
            if messagearr['type'] in ['sendToAll','sendToGroup','sendToClient','sendToUid']:
                adminsign=''
                if is_index(messagearr,'time') and messagearr['time'] and abs(times()-int(messagearr['time']))<30 and is_index(messagearr,'adminsign'):
                    adminsign=kcwsign.getsign({'admintoken':sockets_admin_authkey,'time':messagearr['time']})
                if adminsign and adminsign==messagearr['adminsign']:
                    del messagearr['adminsign']
                    message=json_encode(messagearr)
                    if messagearr['type']=='sendToAll':
                        await self.send_all(message)
                    elif messagearr['type']=='sendToGroup':
                        exclude_clientid=[clientid]
                        await self.sendToGroup(messagearr['GroupName'],message,exclude_clientid=exclude_clientid)
                    elif messagearr['type']=='sendToClient':
                        await self.send_client(messagearr['client_id'],message)
                    elif messagearr['type']=='sendToUid':
                        await self.sendToUid(messagearr['unionid'],message)
                else:
                    # await self.send_client(clientid,'权限不足')
                    await self.CloseSocket(clientid)
            elif messagearr['type'] == 'get_my_clientid':
                message['client_id']=clientid
                await self.send_client(clientid,message)
            else:
                # await self.send_client(clientid,'信息格式错误')
                await self.CloseSocket(clientid)
        except:
            # await self.send_client(clientid,'信息格式错误')
            await self.CloseSocket(clientid)
    async def onClose(self,clientid):
        "客户端与websocket的连接断开时触发"
        pass

class mysocket:
    # def mysend():
    #     " 测试发送 "
    #     kwebsp_news_push(content='测试信息',percentage=90)
    #     return successjson()
    def servers():
        if config.app['cli']: #cli模式下运行
            kwebspdomain.banddomain(proxyitem={'notes':'通知服务代理','types':'websocket','rule':'/index/index/ws','url':'http://127.0.0.1:39030'}) #绑定代理域名
            socket=sockets()
            socket.start(ip='0.0.0.0',port='39030')
    # def restart():
    #     "重启通讯服务"
    #     G.setadminlog="重启通讯服务"
    #     kill_route_cli("/index/index/mysocket/servers")
    #     if os.name == 'nt':
    #         cmd="start /b kwebsp /index/index/mysocket/servers --cli"
    #     elif 'Linux' in get_sysinfo()['platform']:
    #         cmd="nohup kwebsp /index/index/mysocket/servers --cli > app/runtime/log/mysocket.log 2>&1 &"
    #     else:
    #         return errorjson(msg="不支持该系统")
    #     os.system(cmd)
    #     return successjson()
    def getseradd():
        GroupName=request.args.get('GroupName')
        unionid=request.args.get('unionid')
        if not GroupName:GroupName='kwebsp'
        if not unionid:unionid=G.userinfo['id']
        return successjson(get_kwebsp_websocket_url(GroupName=GroupName,unionid=unionid))