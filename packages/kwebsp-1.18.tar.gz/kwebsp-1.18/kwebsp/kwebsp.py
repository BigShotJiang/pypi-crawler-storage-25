try:
    from .common import *
except Exception as e:
    if 'unable to open database file' in str(e):
        print('该命令仅支持运行kwebsp项目',e)
        exit()
    else:
        print('e',e)
from kwebs import kwebs
def grgrshbtrdjnyjtdjtrhdtrdhtrshythreghedhrdhresr_update_kwebsp(taskid):
    import pip
    Queues.setfield(taskid=taskid,key="code",value=3)
    time.sleep(10)
    Queues.setstart(taskid=taskid,start=0.3)
    t=time.time()
    res=requests.get('https://pypi.org/pypi/kwebsp/json')
    if res.status_code==200:
        if res.json()['info']['version']==config.kwebsp['version']:
            print('无需更新',config.kwebsp['version'])
        else:
            if 0 != pip.main(['install','kwebsp=='+res.json()['info']['version'],'-i','https://pypi.org/simple']):
                raise Exception('更新失败')
            else:
                if os.name == 'nt':
                    from kunapi.Events import Events
                    cmd=sys.argv
                    if 'kwebsp' in cmd[0]: #基于新版本4.13.32之后 kwebsp server运行
                        cmd[0]='kwebsp'
                    elif 'kwebs' in cmd[0]: #基于新版本4.13.32之后 kwebs server运行
                        cmd[0]='kwebs'
                    elif 'kunapi' in cmd[0]:
                        cmd[0]='kunapi'
                    print('kwebsp更新成功')
                    Events(cmd)
                else:
                    time.sleep(60)
                    # os.system('bash server.sh')
                    requests.get('http://127.0.0.1:39001/index/index/index/reboot/app')
    else:
        print('更新kwebsp异常',res.text)
    
    Queues.setstart(taskid=taskid,start=(time.time()-t)*0.03,describes='更新任务执行完成，延迟3600秒进入下一个')
    time.sleep(3600)

def cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr='kwebsp'):
        "脚本入口"
        cmd_par=kwebs.kunapi.get_cmd_par(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        if cmd_par and not cmd_par['project']:
            cmd_par['project']='kwebsp'
        if cmd_par and cmd_par['server'] and not cmd_par['help']:#启动web服务
            #执行kwebsp自启项
            import ksqlite
            startdata=ksqlite.sqlite.connect(model_app_path).where("types='kwebsp'").table("start").order("id asc").select()
            for teml in startdata:
                os.system(teml['value'])

            if os.name == 'nt':
                pass
            elif 'Linux' in get_sysinfo()['platform']:
                system_start.insert_Boot_up(cmd='cd /kwebsp && bash server.sh',name='kwebsp自启',icon='/index/index/pub/icon?text=kwebsp')
            else:
                raise Exception('不支持该操作系统')
            
            tempcmd=sys.argv
            if os.name == 'nt':
                if 'server' in tempcmd and 'eventlog' in tempcmd:
                    taskid=md5('grgrshbtrdjnyjtdjtrhdtrdhtrshythreghedhrdhresr_update_kwebsp')
                    Queues.inserttask(target=grgrshbtrdjnyjtdjtrhdtrdhtrshythreghedhrdhresr_update_kwebsp,args=(taskid,),code=4,title='kwebsp更新任务',start=1,updtime=times()+1,taskid=taskid)
            else:
                if 'server' in tempcmd:
                    taskid=md5('grgrshbtrdjnyjtdjtrhdtrdhtrshythreghedhrdhresr_update_kwebsp')
                    Queues.inserttask(target=grgrshbtrdjnyjtdjtrhdtrdhtrshythreghedhrdhresr_update_kwebsp,args=(taskid,),code=4,title='kwebsp更新任务',start=1,updtime=times()+1,taskid=taskid)
        if cmd_par and cmd_par['install'] and not cmd_par['help']:#插入 应用、模块、插件
            if cmd_par['appname']:
                remppath=os.path.split(os.path.realpath(__file__))[0]
                if not os.path.exists(cmd_par['project']+'/'+cmd_par['appname']) and not os.path.exists(cmd_par['appname']):
                    shutil.copytree(remppath+'/tempfile/kwebsp',cmd_par['project'])
                    if get_sysinfo()['uname'][0]=='Linux':
                        try:
                            os.remove(cmd_par['project']+"/server.bat")
                        except:pass
                    elif get_sysinfo()['uname'][0]=='Windows':
                        try:
                            os.remove(cmd_par['project']+"/server.sh")
                        except:pass
                    print('kwebsp项目创建成功')
                else:
                    t=kwebs.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
            else:
                t=kwebs.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        elif cmd_par:
            t=kwebs.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)

