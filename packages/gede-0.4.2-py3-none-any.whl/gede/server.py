# coding=utf-8
#
# server.py
# LLM GUI client API server
#
# Built with FastAPI. Authentication via X-API-Key header.
# Startup args: --port (default 9127), --base-path, --log-level
#

import os
import sys
import json
import base64
import logging
import argparse
import asyncio
import mimetypes
import re
from typing import Any, Literal, Optional

from fastapi import (
    FastAPI,
    Request,
    HTTPException,
    APIRouter,
    Query,
    Depends,
    UploadFile,
    File,
    Form,
)
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from pydantic import BaseModel

from . import config  # noqa: F401 — load .env config
from .version import get_app_version

logger = logging.getLogger(__name__)

_CHAT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
_FILE_REF_RE = re.compile(r"^[a-f0-9]{64}$")

_IMAGE_MEDIA_TYPES = {
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/webp",
}
_PDF_MEDIA_TYPES = {"application/pdf"}
_VIDEO_MEDIA_TYPES = {
    "video/mp4",
    "video/quicktime",
    "video/webm",
}
_SUPPORTED_UPLOAD_MEDIA_TYPES = (
    _IMAGE_MEDIA_TYPES | _PDF_MEDIA_TYPES | _VIDEO_MEDIA_TYPES
)


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------


def setup_logging(level: str | None = None):
    """Configure logging for all relevant loggers (gede, my_llmkit, uvicorn).

    All output goes to stderr with a unified format.
    Defaults to INFO when level is None.
    """
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    log_level = (level or "INFO").upper()

    logger_names = (
        "gede",
        "my_llmkit",
        "uvicorn",
        "uvicorn.access",
        "uvicorn.error",
    )
    for name in logger_names:
        lgr = logging.getLogger(name)
        lgr.setLevel(log_level)
        lgr.propagate = False
        # Replace any existing handlers with the stream handler
        lgr.handlers.clear()
        lgr.addHandler(stream_handler)

    # Only configure SDK loggers when an explicit level is given (these are silent by default)
    if level:
        for name in ("openai", "anthropic", "httpx", "httpcore"):
            lgr = logging.getLogger(name)
            lgr.setLevel(log_level)
            lgr.propagate = False
            if not lgr.handlers:
                lgr.addHandler(stream_handler)


# ---------------------------------------------------------------------------
# Standard response structure
# ---------------------------------------------------------------------------


class ApiResponse(BaseModel):
    code: int = 0
    msg: str = "ok"
    data: Any = None

    @classmethod
    def ok(cls, data: Any = None) -> "ApiResponse":
        return cls(code=0, msg="ok", data=data)

    @classmethod
    def error(cls, code: int, msg: str) -> "ApiResponse":
        return cls(code=code, msg=msg, data=None)


def ok_response(data: Any = None) -> JSONResponse:
    return JSONResponse(content=ApiResponse.ok(data).model_dump())


def error_response(code: int, msg: str, http_status: int = 400) -> JSONResponse:
    return JSONResponse(
        status_code=http_status,
        content=ApiResponse.error(code, msg).model_dump(),
    )


def _is_valid_chat_id(chat_id: str) -> bool:
    return bool(_CHAT_ID_RE.fullmatch(chat_id))


def _is_valid_file_ref(file_ref: str) -> bool:
    return bool(_FILE_REF_RE.fullmatch(file_ref))


def _normalize_media_type(media_type: str | None) -> str | None:
    if not media_type:
        return None
    return media_type.split(";", maxsplit=1)[0].strip().lower() or None


def _detect_media_type(data: bytes, filename: str | None, declared: str | None) -> str:
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith(b"%PDF-"):
        return "application/pdf"
    if len(data) >= 12 and data[4:8] == b"ftyp":
        major_brand = data[8:12]
        if major_brand in {b"qt  "}:
            return "video/quicktime"
        return "video/mp4"
    if data.startswith(b"\x1a\x45\xdf\xa3"):
        return "video/webm"
    if data.startswith(b"RIFF") and data[8:12] == b"AVI ":
        return "video/x-msvideo"

    media_type = _normalize_media_type(declared)
    if media_type and media_type != "application/octet-stream":
        return media_type

    if filename:
        guessed, _ = mimetypes.guess_type(filename)
        guessed = _normalize_media_type(guessed)
        if guessed:
            return guessed

    return "application/octet-stream"


# ---------------------------------------------------------------------------
# Authentication dependency
# ---------------------------------------------------------------------------


async def verify_api_key(request: Request):
    """Validate the X-API-Key header. All requests are allowed when GEDE_SERVER_API_KEY is not set."""
    api_key = os.environ.get("GEDE_SERVER_API_KEY", "").strip()
    if not api_key:
        return
    incoming = request.headers.get("X-API-Key", "")
    if incoming != api_key:
        raise HTTPException(status_code=401, detail="Unauthorized")


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

# Public routes (no auth required)
health_router = APIRouter()


@health_router.get("/health")
async def health():
    """Health check endpoint."""
    logger.info("health")
    return ok_response({"status": "ok", "version": get_app_version()})


# Protected routes (require X-API-Key)
api_router = APIRouter()


@api_router.get("/chats")
async def list_chats(
    is_private: bool = Query(
        default=False, description="true=encrypted chats, false=public chats"
    ),
    page: int = Query(default=1, ge=1, description="Page number (starting from 1)"),
    page_size: int = Query(
        default=20, ge=1, le=100, description="Items per page (max 100)"
    ),
):
    """List chats, paginated and sorted by created_at descending."""
    from .db import db_conn

    offset = (page - 1) * page_size
    is_private_int = 1 if is_private else 0

    try:
        with db_conn() as conn:
            total_row = conn.execute(
                "SELECT COUNT(*) AS cnt FROM chats WHERE is_private = ?",
                (is_private_int,),
            ).fetchone()
            total = total_row["cnt"] if total_row else 0

            rows = conn.execute(
                """
                SELECT chat_id, title, model_path, is_private,
                       message_num_in_context, forked_from_message_id,
                       created_at, updated_at
                FROM chats
                WHERE is_private = ?
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
                """,
                (is_private_int, page_size, offset),
            ).fetchall()

        items = [
            {
                "chat_id": row["chat_id"],
                "title": row["title"],
                "model_path": row["model_path"],
                "is_private": bool(row["is_private"]),
                "message_num_in_context": row["message_num_in_context"],
                "forked_from_message_id": row["forked_from_message_id"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

        return ok_response(
            {
                "total": total,
                "page": page,
                "page_size": page_size,
                "items": items,
            }
        )
    except Exception as e:
        logger.error("Failed to list chats: %s", e)
        return error_response(500, "Internal server error", http_status=500)


@api_router.get("/chats/{chat_id}")
async def get_chat(chat_id: str):
    """Get chat detail: returns chat metadata and the full message list (sorted by position ascending).

    For private chats the text field contains ciphertext; decryption is the client's responsibility.
    """
    from .db import db_conn

    try:
        with db_conn() as conn:
            chat_row = conn.execute(
                """
                SELECT chat_id, title, model_path, is_private, instruction,
                       model_settings, message_num_in_context,
                       forked_from_message_id, created_at, updated_at
                FROM chats
                WHERE chat_id = ?
                """,
                (chat_id,),
            ).fetchone()

            if not chat_row:
                return error_response(404, "Chat not found", http_status=404)

            msg_rows = conn.execute(
                """
                SELECT message_id, role, text, attachments, position, created_at
                FROM messages
                WHERE chat_id = ?
                ORDER BY position ASC
                """,
                (chat_id,),
            ).fetchall()

        try:
            model_settings = json.loads(chat_row["model_settings"] or "{}")
        except Exception:
            model_settings = {}

        chat_data = {
            "chat_id": chat_row["chat_id"],
            "title": chat_row["title"],
            "model_path": chat_row["model_path"],
            "is_private": bool(chat_row["is_private"]),
            "instruction": chat_row["instruction"],
            "model_settings": model_settings,
            "message_num_in_context": chat_row["message_num_in_context"],
            "forked_from_message_id": chat_row["forked_from_message_id"],
            "created_at": chat_row["created_at"],
            "updated_at": chat_row["updated_at"],
        }

        messages = [
            {
                "message_id": row["message_id"],
                "role": row["role"],
                "text": row["text"],
                "attachments": (
                    json.loads(row["attachments"]) if row["attachments"] else None
                ),
                "position": row["position"],
                "created_at": row["created_at"],
            }
            for row in msg_rows
        ]

        return ok_response({"chat": chat_data, "messages": messages})
    except Exception as e:
        logger.error("Failed to get chat %s: %s", chat_id, e)
        return error_response(500, "Internal server error", http_status=500)


@api_router.post("/chat/upload")
async def upload_chat_file(
    chat_id: str = Form(..., description="Chat ID"),
    file: UploadFile = File(..., description="Attachment file to upload"),
):
    """Upload a chat attachment; returns the on-disk file_ref and detected media_type.

    Currently used mainly for image input. MIME detection also handles PDF and
    video formats for future extensibility.
    """
    from .chatcore import save_attachment_file

    if not _is_valid_chat_id(chat_id):
        return error_response(400, "Invalid chat_id", http_status=400)

    try:
        data = await file.read()
        if not data:
            return error_response(400, "File is empty", http_status=400)

        media_type = _detect_media_type(data, file.filename, file.content_type)
        if media_type not in _SUPPORTED_UPLOAD_MEDIA_TYPES:
            return error_response(
                415,
                f"Unsupported media type: {media_type}",
                http_status=415,
            )

        file_ref = save_attachment_file(chat_id, data)
        return ok_response({"file_ref": file_ref, "media_type": media_type})
    except Exception as e:
        logger.error("Failed to upload file for chat %s: %s", chat_id, e)
        return error_response(500, "Internal server error", http_status=500)
    finally:
        await file.close()


@api_router.get("/chat/uploads/{chat_id}/{file_ref}")
async def get_chat_upload(chat_id: str, file_ref: str):
    """Retrieve a chat attachment for inline preview."""
    from .chatcore import get_attachment_path

    if not _is_valid_chat_id(chat_id) or not _is_valid_file_ref(file_ref):
        return error_response(400, "Invalid attachment reference", http_status=400)

    filepath = get_attachment_path(chat_id, file_ref)
    if filepath is None:
        return error_response(404, "Attachment not found", http_status=404)

    try:
        with open(filepath, "rb") as f:
            head = f.read(64)
        media_type = _detect_media_type(head, file_ref, None)
        return FileResponse(
            filepath,
            media_type=media_type,
            filename=file_ref,
            headers={"Content-Disposition": f'inline; filename="{file_ref}"'},
        )
    except Exception as e:
        logger.error("Failed to read attachment %s/%s: %s", chat_id, file_ref, e)
        return error_response(500, "Internal server error", http_status=500)


@api_router.get("/models")
async def list_models():
    """List available models grouped by provider."""
    from .llm.providers.providers import MODEL_DATA, prepare_models

    try:
        await prepare_models()
        groups: list[dict[str, Any]] = []

        for one_provider in MODEL_DATA:
            group_items: list[dict[str, Any]] = []
            for one_model in one_provider.models:
                if one_model.deleted:
                    continue

                item = {
                    "title": f"{one_provider.name}:{one_model.name}",
                    "model_path": one_model.model_path,
                    "provider_id": one_provider.provider_id,
                    "provider_name": one_provider.name,
                    "model_id": one_model.model_id,
                    "model_name": one_model.name,
                }
                group_items.append(item)

            if group_items:
                groups.append(
                    {
                        "provider_id": one_provider.provider_id,
                        "provider_name": one_provider.name,
                        "items": group_items,
                    }
                )

        return ok_response(groups)
    except Exception as e:
        logger.error("Failed to list models: %s", e)
        return error_response(500, "Internal server error", http_status=500)


@api_router.get("/tools")
async def list_tools():
    """List available built-in tools."""
    from .llm.tools.tools import AVAILABLE_INNER_TOOL_DESC, AVAILABLE_INNER_TOOL_NAMES

    try:
        items = [
            {
                "name": tool_name,
                "description": AVAILABLE_INNER_TOOL_DESC.get(tool_name, ""),
            }
            for tool_name in AVAILABLE_INNER_TOOL_NAMES
        ]
        return ok_response(items)
    except Exception as e:
        logger.error("Failed to list tools: %s", e)
        return error_response(500, "Internal server error", http_status=500)


# ---------------------------------------------------------------------------
# POST /chat — SSE streaming chat endpoint
# ---------------------------------------------------------------------------


class ChatAttachment(BaseModel):
    type: Literal["image"]
    file_ref: str
    media_type: str


class ChatRequest(BaseModel):
    model: str
    prompt: str
    tools: list[str] = []
    chat_id: str
    instruction: Optional[str] = None
    attachments: list[ChatAttachment] = []
    is_private: bool = False
    private_password: Optional[str] = None


def _sse_event(data: dict) -> str:
    """Serialize a dict as a standard SSE line: data: <json>\\n\\n"""
    return "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"


@api_router.post("/chat")
async def chat_endpoint(body: ChatRequest):
    """Chat with an LLM and stream the response as SSE events.

    Does not follow the {code, msg, data} envelope — each event is an independent JSON object:
    - {"type": "content", "delta": "..."}           — incremental text chunk, clients must concatenate
    - {"type": "reasoning_content", "delta": "..."}  — incremental reasoning chunk, clients must concatenate
    - {"type": "tool_call_start", "function_name": "...", "function_args": "..."}
    - {"type": "tool_call_result", "function_name": "...", "function_result": "..."}
    - {"type": "usage", "usage": {...}}
    - {"type": "done", "chat_id": "..."}
    - {"type": "error", "message": "..."}
    """

    async def _generate():
        from .chatcore import ChatModel, get_attachment_path
        from .llm.providers.providers import (
            get_provider_from_model_path,
            prepare_models,
        )
        from .llm.tools.tools import get_tools
        from .db import db_conn
        from my_llmkit.chat.types import ImageContent

        # ------------------------------------------------------------------
        # Validate request parameters
        # ------------------------------------------------------------------
        if not _is_valid_chat_id(body.chat_id):
            yield _sse_event({"type": "error", "message": "Invalid chat_id"})
            return

        if not body.model or ":" not in body.model:
            yield _sse_event(
                {
                    "type": "error",
                    "message": "Invalid model path, expected format provider_id:model_id",
                }
            )
            return

        if body.is_private and not body.private_password:
            yield _sse_event(
                {
                    "type": "error",
                    "message": "private_password is required for private chat",
                }
            )
            return

        for att in body.attachments:
            if not _is_valid_file_ref(att.file_ref):
                yield _sse_event(
                    {"type": "error", "message": f"Invalid file_ref: {att.file_ref}"}
                )
                return

        # ------------------------------------------------------------------
        # Determine whether this is a new or existing chat
        # ------------------------------------------------------------------
        try:
            with db_conn() as conn:
                row = conn.execute(
                    "SELECT chat_id FROM chats WHERE chat_id = ?", (body.chat_id,)
                ).fetchone()
            chat_exists = row is not None
        except Exception as e:
            logger.error("DB error checking chat_id: %s", e)
            yield _sse_event({"type": "error", "message": "Database error"})
            return

        current_chat: Optional["ChatModel"] = None

        if chat_exists:
            current_chat = ChatModel.load_from_db(
                body.chat_id,
                is_private=body.is_private,
                private_password=body.private_password,
            )
            if current_chat is None:
                yield _sse_event(
                    {
                        "type": "error",
                        "message": "Failed to load chat. Check is_private flag and private_password.",
                    }
                )
                return
            current_chat.model_path = body.model
        else:
            current_chat = ChatModel(is_private=body.is_private)
            current_chat.chat_id = body.chat_id
            current_chat.model_path = body.model
            if body.is_private:
                current_chat.private_password = body.private_password
            instruction = body.instruction or "You are a helpful assistant."
            current_chat.set_instruction(instruction)
            current_chat.auto_persist = True  # server 模式对所有对话自动持久化

        # ------------------------------------------------------------------
        # Load image attachments
        # ------------------------------------------------------------------
        images: list[ImageContent] = []
        for att in body.attachments:
            if att.type != "image":
                continue
            filepath = get_attachment_path(body.chat_id, att.file_ref)
            if filepath is None:
                yield _sse_event(
                    {
                        "type": "error",
                        "message": f"Attachment not found: {att.file_ref}",
                    }
                )
                return
            try:
                with open(filepath, "rb") as f:
                    raw = f.read()
                b64 = base64.b64encode(raw).decode("ascii")
                img = ImageContent.from_base64(
                    base64_data=b64,
                    media_type=att.media_type,  # type: ignore[arg-type]
                )
                images.append(img)
            except Exception as e:
                logger.error("Failed to load attachment %s: %s", att.file_ref, e)
                yield _sse_event(
                    {
                        "type": "error",
                        "message": f"Failed to load attachment: {att.file_ref}",
                    }
                )
                return

        # ------------------------------------------------------------------
        # Append user message
        # ------------------------------------------------------------------
        current_chat.append_user_message(body.prompt, images=images)

        # ------------------------------------------------------------------
        # Prepare provider and tools
        # ------------------------------------------------------------------
        try:
            await prepare_models()
        except Exception as e:
            logger.error("Failed to prepare models: %s", e)
            yield _sse_event({"type": "error", "message": "Failed to prepare models"})
            return

        provider = get_provider_from_model_path(body.model)
        if not provider:
            yield _sse_event(
                {
                    "type": "error",
                    "message": f"Provider not found for model: {body.model}",
                }
            )
            return

        try:
            model_info = await current_chat.model
        except Exception as e:
            logger.error("Failed to get model info: %s", e)
            yield _sse_event(
                {"type": "error", "message": f"Model not found: {body.model}"}
            )
            return

        chat_client = provider.get_chat_client(
            model_info.model_id, current_chat.model_settings
        )

        tools = get_tools(*body.tools) if body.tools else None

        # ------------------------------------------------------------------
        # Stream LLM output, yielding one SSE event per chunk
        # ------------------------------------------------------------------
        input_messages = current_chat.get_messages_to_talk()
        runner = chat_client.run_stream(messages=input_messages, tools=tools)

        answer = ""
        try:
            async for event in runner.stream_event():
                if event.type == "content":
                    answer += event.content
                    yield _sse_event({"type": "content", "delta": event.content})
                elif event.type == "reasoning_content":
                    yield _sse_event(
                        {"type": "reasoning_content", "delta": event.content}
                    )
                elif event.type == "tool_call_start":
                    yield _sse_event(
                        {
                            "type": "tool_call_start",
                            "function_name": event.function_name,
                            "function_args": event.function_args,
                        }
                    )
                elif event.type == "tool_call_result":
                    yield _sse_event(
                        {
                            "type": "tool_call_result",
                            "function_name": event.function_name,
                            "function_result": event.function_result,
                        }
                    )
                elif event.type == "usage":
                    usage_dict: dict[str, Any] = {
                        "completion_tokens": event.usage.completion_tokens,
                        "prompt_tokens": event.usage.prompt_tokens,
                        "total_tokens": event.usage.total_tokens,
                    }
                    if event.usage.reasoning_tokens is not None:
                        usage_dict["reasoning_tokens"] = event.usage.reasoning_tokens
                    if event.usage.cached_tokens is not None:
                        usage_dict["cached_tokens"] = event.usage.cached_tokens
                    if event.usage.model is not None:
                        usage_dict["model"] = event.usage.model
                    yield _sse_event({"type": "usage", "usage": usage_dict})
        except Exception as e:
            logger.error("Error during chat streaming for %s: %s", body.chat_id, e)
            yield _sse_event({"type": "error", "message": f"Streaming error: {e}"})
            return

        # ------------------------------------------------------------------
        # Persist assistant reply
        # ------------------------------------------------------------------
        if answer:
            current_chat.append_assistant_message(answer)

        # ------------------------------------------------------------------
        # Generate title asynchronously (public chats without a title only)
        # ------------------------------------------------------------------
        if not body.is_private and current_chat.title in ("", "New Chat", "Untitled"):

            async def _generate_and_save_title():
                await current_chat.geneate_title()
                current_chat.save_to_db()

            asyncio.create_task(_generate_and_save_title())

        yield _sse_event({"type": "done", "chat_id": body.chat_id})

    return StreamingResponse(
        _generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# FastAPI application factory
# ---------------------------------------------------------------------------


def create_app(base_path: str = "") -> FastAPI:
    """Create and configure the FastAPI application instance."""
    prefix = base_path.rstrip("/")

    app = FastAPI(
        title="Gede Server",
        version=get_app_version(),
    )

    # ------------------------------------------------------------------
    # Global exception handlers
    # ------------------------------------------------------------------

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"code": exc.status_code, "msg": exc.detail, "data": None},
        )

    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception):
        logger.error("Unhandled exception: %s", exc, exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"code": 500, "msg": "Internal server error", "data": None},
        )

    # ------------------------------------------------------------------
    # Routes (public router needs no auth; protected router injects verify_api_key)
    # ------------------------------------------------------------------

    app.include_router(health_router, prefix=prefix)
    app.include_router(
        api_router,
        prefix=prefix,
        dependencies=[Depends(verify_api_key)],
    )

    return app


# Module-level app instance for uvicorn reload mode (loaded via string import path).
# base_path / log_level are read from environment variables set by main() before startup,
# so that reload worker processes pick up the correct config on re-import.
setup_logging(os.environ.get("GEDE_SERVER_LOG_LEVEL"))
app = create_app(base_path=os.environ.get("GEDE_SERVER_BASE_PATH", ""))


# ---------------------------------------------------------------------------
# Startup entry point
# ---------------------------------------------------------------------------


def parse_args():
    parser = argparse.ArgumentParser(description="Gede LLM Server")
    parser.add_argument(
        "--port",
        type=int,
        default=9127,
        help="Listening port (default: 9127)",
    )
    parser.add_argument(
        "--base-path",
        type=str,
        default="",
        help="API route prefix, e.g. /api/v1",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Log level (default: INFO)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        default=False,
        help="Enable hot-reload (development only)",
    )
    return parser.parse_args()


def main():
    import uvicorn

    args = parse_args()
    setup_logging(args.log_level)

    # Initialize database
    from .db import init_db

    init_db()

    logger.info(f"Gede Server v{get_app_version()} starting on port {args.port}")
    if args.base_path:
        logger.info(f"Base path: {args.base_path}")

    if args.reload:
        # Reload mode requires a string import path.
        # Pass runtime config via environment variables so that reload worker
        # processes read the correct settings on re-import.
        os.environ["GEDE_SERVER_BASE_PATH"] = args.base_path
        os.environ["GEDE_SERVER_LOG_LEVEL"] = args.log_level or "INFO"
        uvicorn.run(
            "gede.server:app",
            host="0.0.0.0",
            port=args.port,
            reload=True,
            log_config=None,
        )
    else:
        uvicorn.run(
            create_app(base_path=args.base_path),
            host="0.0.0.0",
            port=args.port,
            log_config=None,
        )


if __name__ == "__main__":
    main()
