from multiprocessing.managers import DictProxy
from typing import Any, Callable, Dict, List, Optional, Type

from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import ClassType, InPacket, OutPacket

from .generic import GenericPipe, _PicklableCallable


class ClassInstancePipe(GenericPipe[InPacket, OutPacket]):
    """Pipe that instantiates a class inside the worker process.

    The constructor is called *inside* the child process (in ``run()``), never
    in the parent.  This is critical for classes that allocate GPU memory (e.g.
    Transformers pipelines): CUDA handles are process-local and must not be
    created before the fork/spawn boundary.
    """

    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        class_constructor: Type[ClassType],
        class_method: Callable[[ClassType, InPacket], OutPacket],
        target: "ShuttableQueue[OutPacket]",
        close_method: Optional[Callable[[ClassType], Any]] = None,
        class_args: Optional[List[Any]] = None,
        class_kwargs: Optional[Dict[str, Any]] = None,
        auto_start: bool = True,
    ):
        # Store constructor + method names only – no instantiation here so that
        # no GPU memory is allocated before the process boundary.
        self._class_constructor = _PicklableCallable(class_constructor)
        self._class_method_name: str = class_method.__name__
        self._close_method_name: Optional[str] = (
            close_method.__name__ if close_method is not None else None
        )
        self._class_args = class_args or []
        self._class_kwargs = class_kwargs or {}
        self._task: Optional[_PicklableCallable] = None
        self._bound_close: Optional[_PicklableCallable] = None
        super().__init__(father_process_dag, source, target, auto_start)

    @property
    def shortname(self) -> str:
        return f"{self._class_constructor.__name__}:{self._class_method_name}"

    def run(self) -> None:
        # Instance is created here, inside the worker process.
        instance = self._class_constructor(*self._class_args, **self._class_kwargs)
        self._task = _PicklableCallable(getattr(instance, self._class_method_name))
        if self._close_method_name is not None:
            self._bound_close = _PicklableCallable(
                getattr(instance, self._close_method_name)
            )
        super().run()

    def _perform_task(self, data: InPacket) -> OutPacket:
        assert self._task is not None
        return self._task(data)

    def _kill(self) -> None:
        if self._bound_close is not None:
            try:
                self._bound_close()
            except Exception:
                pass
        super()._kill()
