from multiprocessing.managers import DictProxy
from typing import Callable, List, Optional

from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import InPacket, OutPacket

from .generic import _SKIP, GenericPipe, _PicklableCallable


class TaskPipe(GenericPipe[InPacket, OutPacket]):
    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        task: Callable[[InPacket], OutPacket],
        target: "ShuttableQueue[OutPacket]",
        on_error: Optional[Callable[[InPacket, Exception], Optional[OutPacket]]] = None,
        auto_start: bool = True,
    ):
        self._task = _PicklableCallable(task)
        self._on_error = _PicklableCallable(on_error) if on_error is not None else None
        super().__init__(father_process_dag, source, target, auto_start)

    @property
    def shortname(self) -> str:
        return self._task.__name__

    def _perform_task(self, data: InPacket) -> OutPacket:
        on_error = getattr(self, "_on_error", None)
        if on_error is None:
            return self._task(data)
        try:
            return self._task(data)
        except Exception as exc:
            result = on_error(data, exc)
            if result is None:
                return _SKIP  # type: ignore[return-value]
            return result
