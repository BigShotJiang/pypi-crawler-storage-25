from olympipe.types import InPacket

from .generic import GenericPipe


class GatherPipe(GenericPipe[InPacket, InPacket]):
    """Identity pipe: reads from a source and writes to the shared aggregated queue."""

    @property
    def shortname(self) -> str:
        return "gather"

    def can_quit(self) -> bool:
        """GatherPipe relies solely on is_closed because the source may belong
        to an external pipeline (different DAG)."""
        if self.should_quit():
            return True
        if self._source_queue.is_closed:
            return self._source_queue.empty()
        return False

    def _perform_task(self, data: InPacket) -> InPacket:
        return data
