from multiprocessing.managers import DictProxy
from typing import Callable, Iterable, List, Optional, cast

from olympipe.pipes.generic import GenericPipe, _PicklableCallable
from olympipe.pipes.task import TaskPipe
from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import InPacket, OutPacket


class ExplodePipe(TaskPipe[InPacket, OutPacket]):
    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        explode_function: Optional[Callable[[InPacket], Iterable[OutPacket]]],
        target: "ShuttableQueue[OutPacket]",
        auto_start: bool = True,
    ):
        fn: Callable[[InPacket], Iterable[OutPacket]] = (
            ExplodePipe._passthrough if explode_function is None else explode_function
        )
        self._task = _PicklableCallable(fn)
        GenericPipe.__init__(self, father_process_dag, source, target, auto_start)

    @staticmethod
    def _passthrough(x: InPacket) -> Iterable[OutPacket]:
        return cast(Iterable[OutPacket], x)

    @property
    def shortname(self) -> str:
        return f"explode:{self._task.__name__}"

    def _send_to_next(self, processed: Iterable[OutPacket]):  # type: ignore
        for p in processed:
            super()._send_to_next(p)
