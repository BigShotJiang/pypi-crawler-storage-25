import os
import sys
from multiprocessing import get_context
from multiprocessing.context import BaseContext


def _resolve_mp_context() -> BaseContext:
    """Choose the multiprocessing context for worker processes.

    Priority:
    1. OLYMPIPE_FORCE_FORK=1  — always use fork
    2. OLYMPIPE_FORCE_SPAWN=1 — always use spawn
    3. torch detected          — spawn (avoids CUDA/DataLoader fork deadlocks)
    4. Python >= 3.12          — spawn (fork deprecated in multi-threaded processes;
                                  olympipe always creates threads via Manager + tqdm)
    5. otherwise               — fork (fastest on older Python)

    olympipe handles the spawn re-import of the main module internally: Pipeline
    becomes a no-op stub in worker processes, so no ``if __name__ == '__main__'``
    guard is needed in user scripts.
    """
    if os.environ.get("OLYMPIPE_FORCE_FORK", "0") == "1":
        return get_context("fork")
    if os.environ.get("OLYMPIPE_FORCE_SPAWN", "0") == "1":
        return get_context("spawn")
    try:
        import torch  # type: ignore[import-untyped, import-not-found]  # noqa: F401

        return get_context("spawn")
    except ImportError:
        pass
    # Python 3.12 deprecated fork() in multi-threaded processes and will raise
    # in 3.14. olympipe always creates threads (Manager, tqdm), so fork is unsafe.
    if sys.version_info >= (3, 12):
        return get_context("spawn")
    return get_context("fork")


mp_ctx: BaseContext = _resolve_mp_context()
