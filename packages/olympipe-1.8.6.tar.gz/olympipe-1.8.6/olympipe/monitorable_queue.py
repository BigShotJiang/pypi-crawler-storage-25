from multiprocessing.managers import SyncManager
from queue import Empty
from typing import Any, Dict, List, TypeVar

from olympipe.shuttable_queue import ShuttableQueue

R = TypeVar("R")


class MonitorableQueue(ShuttableQueue[R]):
    """ShuttableQueue extended with a shared mirror for peek, drain, clear, pause and throughput."""

    def __init__(self, manager: SyncManager) -> None:
        super().__init__()
        self._mirror = manager.list()
        self._paused = manager.Value("b", 0)
        self._put_count = manager.Value("L", 0)
        self._get_count = manager.Value("L", 0)
        self._errors = manager.list()

    def __getstate__(self):  # type: ignore[override]
        return (
            *super().__getstate__(),
            self._mirror,
            self._paused,
            self._put_count,
            self._get_count,
            self._errors,
        )

    def __setstate__(self, state):  # type: ignore[override]
        (
            *parent_state,
            self._mirror,
            self._paused,
            self._put_count,
            self._get_count,
            self._errors,
        ) = state
        super().__setstate__(tuple(parent_state))

    def put(self, item: R, block: bool = True, timeout: "float | None" = None) -> None:  # type: ignore[override]
        super().put(item, block=block, timeout=timeout)
        # Mirror operations are best-effort; the underlying queue item is already delivered.
        # Manager proxy calls can fail under fork() with multi-threaded processes.
        try:
            self._mirror.append(item)
            self._put_count.value += 1
        except Exception:
            pass

    def get(self, block: bool = True, timeout: "float | None" = None) -> R:  # type: ignore[override]
        try:
            if self._paused.value:
                raise Empty()
        except Empty:
            raise
        except Exception:
            pass
        item = super().get(block=block, timeout=timeout)
        try:
            self._mirror.pop(0)
            self._get_count.value += 1
        except Exception:
            pass
        return item  # type: ignore[return-value]

    # ── Inspection ────────────────────────────────────────────────────────────

    def peek_all(self) -> List[R]:
        """Returns a copy of the queue contents without consuming messages."""
        return list(self._mirror)

    def peek_at(self, i: int) -> R:
        """Reads the message at index i without consuming it."""
        try:
            return self._mirror[i]  # type: ignore[return-value]
        except IndexError:
            raise IndexError(f"No message at index {i} (size={len(self._mirror)})")

    # ── Control ───────────────────────────────────────────────────────────────

    def pause(self) -> None:
        """Blocks get() calls until the next resume()."""
        self._paused.value = 1

    def resume(self) -> None:
        self._paused.value = 0

    @property
    def is_paused(self) -> bool:
        return bool(self._paused.value)

    def clear(self) -> None:
        """Empties the queue and the mirror."""
        while True:
            try:
                super().get(block=False)
            except Exception:
                break
        try:
            del self._mirror[:]
        except Exception:
            pass

    def drain(self) -> List[R]:
        """Consumes and returns all pending messages."""
        items = list(self._mirror)
        self.clear()
        return items

    # ── Worker errors ─────────────────────────────────────────────────────────

    def add_error(self, msg: str) -> None:
        """Records a worker error and pauses the queue."""
        try:
            self._errors.append(msg[:1000])
            while len(self._errors) > 10:
                del self._errors[0]
            self._paused.value = 1
        except Exception:
            pass

    def get_errors(self) -> List[str]:
        return list(self._errors)

    def clear_errors(self) -> None:
        try:
            del self._errors[:]
        except Exception:
            pass
        self._paused.value = 0

    # ── Snapshot ──────────────────────────────────────────────────────────────

    def snapshot(self) -> Dict[str, Any]:
        """Instant state snapshot for monitoring."""
        try:
            return {
                "pid": self.pid,
                "size": len(self._mirror),
                "max_size": self._maxsize,  # type: ignore[attr-defined]
                "paused": self.is_paused,
                "put_count": self._put_count.value,
                "get_count": self._get_count.value,
                "errors": list(self._errors),
            }
        except Exception:
            return {"pid": self.pid}
