import inspect
import typing
from typing import Any, Callable, Optional, TypeVar

import olympipe.registry as _reg

F = TypeVar("F", bound=Callable[..., Any])
C = TypeVar("C", bound=type)


def source(fn: F) -> F:
    """Marks a generator function as a pipeline source."""
    _reg.register_source(fn)
    return fn


def source_from(iterable: Any, name: Optional[str] = None) -> Any:
    """Registers any iterable (list, range, generator…) as a pipeline source.

    Usage::

        my_list = source_from([1, 2, 3], name="my_list")
        my_range = source_from(range(100), name="my_range")
    """
    _name = name or getattr(iterable, "__name__", None) or f"source_{id(iterable)}"

    def _wrapper():
        yield from iterable

    _wrapper.__name__ = _name
    _wrapper.__qualname__ = _name
    _reg.register_source(_wrapper)
    return iterable


def task(fn: F) -> F:
    """Marks a transformation function."""
    _reg.register_task(fn)
    return fn


def filter(fn: F) -> F:  # noqa: A001
    """Marks a filter function (must return bool)."""
    try:
        hints = typing.get_type_hints(fn)
        ret = hints.get("return", inspect.Parameter.empty)
        if ret is not inspect.Parameter.empty and ret is not bool:
            raise TypeError(
                f"@filter: '{fn.__name__}' must return bool, "
                f"not {getattr(ret, '__name__', ret)}"
            )
    except TypeError:
        raise
    except Exception:
        pass
    _reg.register_filter(fn)
    return fn


def splitter(fn: F) -> F:
    """Marks a packet routing function towards N outputs.

    The function must return a tuple/list of size N where each non-None element
    is sent to the corresponding output queue.

    Example::

        @splitter
        def route(packet) -> Tuple[Optional[int], Optional[int]]:
            if packet % 2 == 0:
                return (packet, None)
            return (None, packet)

        evens, odds = pipeline.split(route)
    """
    _reg.register_splitter(fn)
    return fn


def class_task(
    method: str,
    close: Optional[str] = None,
    name: Optional[str] = None,
) -> Callable[[C], C]:
    """Decorates a class for use as a class_task step in a pipeline."""

    def decorator(cls: C) -> C:
        _reg.register_class_task(cls, method=method, close=close, name=name)
        return cls

    return decorator
