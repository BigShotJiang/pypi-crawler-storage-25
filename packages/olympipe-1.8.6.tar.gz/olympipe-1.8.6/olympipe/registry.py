from typing import Any, Callable, Dict, Optional, Type

_sources: Dict[str, Callable[..., Any]] = {}
_tasks: Dict[str, Callable[..., Any]] = {}
_filters: Dict[str, Callable[..., Any]] = {}
_class_tasks: Dict[str, Dict[str, Any]] = {}
_splitters: Dict[str, Callable[..., Any]] = {}


def register_source(fn: Callable[..., Any], name: Optional[str] = None) -> None:
    _sources[name or fn.__name__] = fn


def register_task(fn: Callable[..., Any], name: Optional[str] = None) -> None:
    _tasks[name or fn.__name__] = fn


def register_filter(fn: Callable[..., Any], name: Optional[str] = None) -> None:
    _filters[name or fn.__name__] = fn


def register_class_task(
    cls: Type[Any],
    method: str,
    close: Optional[str] = None,
    name: Optional[str] = None,
) -> None:
    _class_tasks[name or cls.__name__] = {
        "class": cls,
        "method": method,
        "close": close,
    }


def register_splitter(fn: Callable[..., Any], name: Optional[str] = None) -> None:
    _splitters[name or fn.__name__] = fn


def clear_registry() -> None:
    _sources.clear()
    _tasks.clear()
    _filters.clear()
    _class_tasks.clear()
    _splitters.clear()
