"""Tests for auto-fix functionality (F-1 through F-8)."""

from __future__ import annotations

import ast
from pathlib import Path

from minport._fixer import fix_file, fix_files
from minport._models import Violation


class TestFixer:
    """Test fix_file() and fix_files() functions."""

    def test_f1_single_import_line_shortened(self, tmp_path: Path) -> None:
        """F-1: Single import line is shortened."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        result = fix_file(test_file, [violation])
        assert result > 0

        content = test_file.read_text()
        assert "from x.y import Name" in content

    def test_f2_alias_preserved_in_fix(self, tmp_path: Path) -> None:
        """F-2: Alias is preserved when shortening."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name as MyAlias\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias="MyAlias",
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()
        assert "from x.y import Name as MyAlias" in content

    def test_f3_multiple_violations_in_file(self, tmp_path: Path) -> None:
        """F-3: Multiple violations in same file are all fixed."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A\nfrom x.y.z import B\n")

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=2,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="B",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        result = fix_file(test_file, violations)
        assert result > 0

        content = test_file.read_text()
        assert "from x.y import A" in content
        assert "from x.y import B" in content

    def test_f4_fixed_file_is_syntactically_valid(self, tmp_path: Path) -> None:
        """F-4: Fixed file is syntactically valid (ast.parse succeeds)."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\nprint(Name)\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()
        # Should not raise
        ast.parse(content)

    def test_f5_no_fix_without_flag(self, tmp_path: Path) -> None:
        """F-5: Without --fix flag, file is not modified (tested in CLI)."""
        # This is tested in CLI tests, but we can verify fix_file behavior
        test_file = tmp_path / "test.py"
        original = "from x.y.z import Name\n"
        test_file.write_text(original)

        # Only test fix_file returns False when given empty violations
        result = fix_file(test_file, [])
        assert result == 0

    def test_f6_no_violations_no_modification(self, tmp_path: Path) -> None:
        """F-6: File with no violations is not modified."""
        test_file = tmp_path / "test.py"
        original = "from x.y import Name\n"
        test_file.write_text(original)

        result = fix_file(test_file, [])
        assert result == 0
        assert test_file.read_text() == original

    def test_f7_name_conflict_not_fixed(self, tmp_path: Path) -> None:
        """F-7: Name conflicts are not fixed (checker responsibility)."""
        # This is actually handled by the checker not creating violations
        # in the first place, but we test the fixer behavior anyway
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\n")

        # If a violation is passed with a None shorter_path, don't fix
        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y.z",  # Same as original
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        result = fix_file(test_file, [violation])
        # Should not modify since the paths are the same
        assert result == 0

    def test_f8_fix_result_counts(self, tmp_path: Path) -> None:
        """F-8: FixResult reports correct files_modified and fixes_applied."""
        file1 = tmp_path / "test1.py"
        file1.write_text("from x.y.z import Name\n")

        file2 = tmp_path / "test2.py"
        file2.write_text("from a.b.c import Other\n")

        violations = {
            file1: [
                Violation(
                    file_path=file1,
                    line=1,
                    col=1,
                    original_path="x.y.z",
                    shorter_path="x.y",
                    name="Name",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
            ],
            file2: [
                Violation(
                    file_path=file2,
                    line=1,
                    col=1,
                    original_path="a.b.c",
                    shorter_path="a.b",
                    name="Other",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
            ],
        }

        result = fix_files(violations)
        assert result.files_modified == 2
        assert result.fixes_applied == 2

    def test_fix_file_with_unreadable_file(self, tmp_path: Path) -> None:
        """Test: fix_file returns False for unreadable files."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\n")
        test_file.chmod(0o000)  # Make unreadable

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        result = fix_file(test_file, [violation])
        assert result == 0

        # Clean up
        test_file.chmod(0o644)

    def test_fix_preserves_line_endings(self, tmp_path: Path) -> None:
        """Test: Line endings are preserved."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\nprint('hello')\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()
        # Should still have proper line endings
        assert content.count("\n") == 2

    def test_fix_with_out_of_bounds_line(self, tmp_path: Path) -> None:
        """Test: Violations with out-of-bounds line numbers are skipped."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name\n")

        violation = Violation(
            file_path=test_file,
            line=999,  # Out of bounds
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        result = fix_file(test_file, [violation])
        assert result == 0

    def test_fix_multiple_violations_reverse_order(self, tmp_path: Path) -> None:
        """Test: Violations processed in reverse line order to preserve line numbers."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A\nfrom x.y.z import B\nfrom x.y.z import C\n")

        violations = [
            Violation(
                file_path=test_file,
                line=3,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="C",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=2,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="B",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        result = fix_file(test_file, violations)
        assert result > 0

        content = test_file.read_text()
        assert "from x.y import A" in content
        assert "from x.y import B" in content
        assert "from x.y import C" in content

    def test_multi_name_partial_move_splits_line(self, tmp_path: Path) -> None:
        """Regression for issue #2.

        ``from x.y.z import A, B`` where only ``A`` can be shortened to
        ``x.y`` must not move ``B`` along with it. The fixer has to split
        the statement so that ``B`` remains importable from ``x.y.z``.
        """
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A, B\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="A",
            alias=None,
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()

        assert "from x.y import A" in content
        assert "from x.y.z import B" in content
        assert "from x.y import A, B" not in content
        ast.parse(content)

    def test_multi_name_all_moved_to_same_shorter_path(self, tmp_path: Path) -> None:
        """All names on a line move to the same shorter path → single rewrite."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A, B\n")

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="B",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        fix_file(test_file, violations)
        content = test_file.read_text()

        assert "from x.y import A, B" in content
        assert "from x.y.z" not in content
        ast.parse(content)

    def test_multi_name_split_to_different_shorter_paths(
        self,
        tmp_path: Path,
    ) -> None:
        """Names moving to different shorter paths produce one line each."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A, B, C\n")

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="B",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        fix_file(test_file, violations)
        content = test_file.read_text()

        assert "from x import A" in content
        assert "from x.y import B" in content
        assert "from x.y.z import C" in content
        ast.parse(content)

    def test_multi_name_partial_move_preserves_alias(self, tmp_path: Path) -> None:
        """Alias on the moved name is preserved; untouched name keeps its alias too."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A as AA, B as BB\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="A",
            alias="AA",
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()

        assert "from x.y import A as AA" in content
        assert "from x.y.z import B as BB" in content
        ast.parse(content)

    def test_fix_syntax_error_file_skipped(self, tmp_path: Path) -> None:
        """Fixer returns False for files that cannot be parsed."""
        test_file = tmp_path / "broken.py"
        test_file.write_text("from x.y.z import (\n")  # unterminated

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) == 0

    def test_fix_rewrites_import_with_inline_comment(self, tmp_path: Path) -> None:
        """Inline comments on the import line are preserved after rewrite."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name  # keep this\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) == 1
        assert test_file.read_text() == "from x.y import Name  # keep this\n"

    def test_fix_skips_import_after_semicolon(self, tmp_path: Path) -> None:
        """An import preceded by another statement on the same line is left alone."""
        test_file = tmp_path / "test.py"
        original = "a = 1; from x.y.z import Name\n"
        test_file.write_text(original)

        violation = Violation(
            file_path=test_file,
            line=1,
            col=7,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) == 0
        assert test_file.read_text() == original

    def test_fix_skips_stale_violation_mismatched_module(
        self,
        tmp_path: Path,
    ) -> None:
        """A violation whose original_path does not match the node is skipped."""
        test_file = tmp_path / "test.py"
        original = "from x.y.z import Name\n"
        test_file.write_text(original)

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="totally.different",
            shorter_path="totally",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) == 0
        assert test_file.read_text() == original

    def test_fix_preserves_tab_indentation(self, tmp_path: Path) -> None:
        """Tab-indented imports keep their tab prefix so the result still parses."""
        test_file = tmp_path / "test.py"
        test_file.write_text("if True:\n\tfrom x.y.z import A, B\n\tprint(A, B)\n")

        violation = Violation(
            file_path=test_file,
            line=2,
            col=2,
            original_path="x.y.z",
            shorter_path="x.y",
            name="A",
            alias=None,
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        content = test_file.read_text()

        assert "\tfrom x.y import A" in content
        assert "\tfrom x.y.z import B" in content
        ast.parse(content)  # no TabError

    def test_fix_skips_import_with_trailing_semicolon_code(
        self,
        tmp_path: Path,
    ) -> None:
        """Code after an import on the same line blocks the rewrite."""
        test_file = tmp_path / "test.py"
        original = "from x.y.z import A; y = 1\n"
        test_file.write_text(original)

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="A",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) == 0
        assert test_file.read_text() == original

    def test_fix_file_without_trailing_newline(self, tmp_path: Path) -> None:
        """A final import line without a trailing newline is handled."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import Name")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        assert fix_file(test_file, [violation]) > 0
        assert test_file.read_text() == "from x.y import Name"

    def test_fixes_applied_counts_comment_preserving_rewrites(
        self,
        tmp_path: Path,
    ) -> None:
        """Both commented and uncommented import lines are rewritten.

        Since inline comments are now preserved, both violations are
        applied and ``fixes_applied`` reflects the total count.
        """
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from pkg.sub.module import A  # keep this comment\nfrom other.deep.module import B\n",
        )

        violations = {
            test_file: [
                Violation(
                    file_path=test_file,
                    line=1,
                    col=1,
                    original_path="pkg.sub.module",
                    shorter_path="pkg.sub",
                    name="A",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
                Violation(
                    file_path=test_file,
                    line=2,
                    col=1,
                    original_path="other.deep.module",
                    shorter_path="other.deep",
                    name="B",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
            ],
        }

        result = fix_files(violations)

        assert result.files_modified == 1
        assert result.fixes_applied == 2

        content = test_file.read_text()
        assert "from pkg.sub import A  # keep this comment" in content
        assert "from other.deep import B" in content

    def test_fixes_applied_excludes_stale_violations(self, tmp_path: Path) -> None:
        """Regression for #16.

        A violation whose ``original_path`` no longer matches the import
        on its line (e.g. the source was edited between check and fix)
        must not be counted in ``fixes_applied``, even when other valid
        violations in the same file cause ``fix_file`` to modify something.
        """
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import A\nfrom a.b.c import B\n",
        )

        violations = {
            test_file: [
                Violation(
                    file_path=test_file,
                    line=1,
                    col=1,
                    original_path="totally.different",
                    shorter_path="totally",
                    name="A",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
                Violation(
                    file_path=test_file,
                    line=2,
                    col=1,
                    original_path="a.b.c",
                    shorter_path="a.b",
                    name="B",
                    alias=None,
                    code="MP001",
                    message="test",
                ),
            ],
        }

        result = fix_files(violations)

        assert result.files_modified == 1
        assert result.fixes_applied == 1

    def test_fix_preserves_inline_comment(self, tmp_path: Path) -> None:
        """Issue #29: --fix rewrites import while preserving inline comment."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import Name  # noqa: E402\n",
        )

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        applied = fix_file(test_file, [violation])
        assert applied == 1
        content = test_file.read_text()
        assert content == "from x.y import Name  # noqa: E402\n"

    def test_fix_preserves_multiline_import_with_comment(self, tmp_path: Path) -> None:
        """Issue #29: Multi-line import with comment on first line is fixed."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import (  # noqa: E402\n    Name,\n)\n",
        )

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        applied = fix_file(test_file, [violation])
        assert applied == 1
        content = test_file.read_text()
        assert "from x.y import Name" in content
        assert "# noqa: E402" in content

    def test_fix_comment_on_all_split_lines(self, tmp_path: Path) -> None:
        """When names split to different shorter paths, comment goes on all lines."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import A, B  # noqa: E402\n")

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x.y",
                name="B",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        applied = fix_file(test_file, violations)
        assert applied == 2
        content = test_file.read_text()
        lines = content.splitlines()
        assert len(lines) == 2
        assert lines[0] == "from x import A  # noqa: E402"
        assert lines[1] == "from x.y import B  # noqa: E402"

    def test_fix_standalone_comment_not_inlined(self, tmp_path: Path) -> None:
        """Standalone comment lines in multi-line import are not converted to inline."""
        test_file = tmp_path / "test.py"
        test_file.write_text("from x.y.z import (\n    # section header\n    Name,\n)\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        applied = fix_file(test_file, [violation])
        assert applied == 1
        content = test_file.read_text()
        assert content == "from x.y import Name\n"
        assert "# section header" not in content

    def test_fix_strips_suppress_from_combined_comment(self, tmp_path: Path) -> None:
        """Combined comment like '# noqa: F401 # minport: ignore' strips suppress part."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import (\n    A,\n    B,  # noqa: F401 # minport: ignore\n)\n",
        )

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        applied = fix_file(test_file, violations)
        assert applied == 1
        content = test_file.read_text()
        # A gets the noqa part only, without minport: ignore
        assert "from x import A  # noqa: F401" in content
        assert "minport: ignore" not in content.split("\n")[0]
        # B keeps its suppress directive
        assert "from x.y.z import B  # minport: ignore" in content

    def test_fix_strips_suppress_prefix_from_combined_comment(self, tmp_path: Path) -> None:
        """'# minport: ignore # noqa' strips suppress and keeps noqa."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import A  # minport: ignore # noqa: E402\n",
        )

        # minport: ignore is on the whole line, so checker would skip this.
        # But if somehow a violation is generated, the fixer should handle it.
        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x",
            name="A",
            alias=None,
            code="MP001",
            message="test",
        )

        applied = fix_file(test_file, [violation])
        assert applied == 1
        content = test_file.read_text()
        assert "from x import A  # noqa: E402" in content
        assert "minport: ignore" not in content

    def test_fix_suppress_with_trailing_text_discarded(self, tmp_path: Path) -> None:
        """'# minport: ignore because reasons' does not produce bare text suffix."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import (\n    A,\n    B,  # minport: ignore because reasons\n)\n",
        )

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x",
            name="A",
            alias=None,
            code="MP001",
            message="test",
        )

        applied = fix_file(test_file, [violation])
        assert applied == 1
        content = test_file.read_text()
        # No bare text appended — only valid comments allowed
        assert "because reasons" not in content.split("\n")[0]
        assert "from x import A\n" in content

    def test_fix_no_doubled_comment_with_suppress(self, tmp_path: Path) -> None:
        """Comment is not doubled when _format_remaining already adds # minport: ignore."""
        test_file = tmp_path / "test.py"
        test_file.write_text(
            "from x.y.z import (  # noqa\n    A,\n    B,  # minport: ignore\n)\n",
        )

        violations = [
            Violation(
                file_path=test_file,
                line=1,
                col=1,
                original_path="x.y.z",
                shorter_path="x",
                name="A",
                alias=None,
                code="MP001",
                message="test",
            ),
        ]

        applied = fix_file(test_file, violations)
        assert applied == 1
        content = test_file.read_text()
        # A's line gets the noqa comment
        assert "from x import A  # noqa" in content
        # B's line keeps its suppress directive, no doubled comment
        assert "from x.y.z import B  # minport: ignore" in content
        assert "# minport: ignore  # noqa" not in content

    def test_fix_with_import_not_matching_pattern(self, tmp_path: Path) -> None:
        """Test: When import pattern doesn't match, line is left unchanged."""
        test_file = tmp_path / "test.py"
        # Use a relative import which won't have the expected pattern
        test_file.write_text("from .module import Name\n")

        violation = Violation(
            file_path=test_file,
            line=1,
            col=1,
            original_path="x.y.z",
            shorter_path="x.y",
            name="Name",
            alias=None,
            code="MP001",
            message="test",
        )

        fix_file(test_file, [violation])
        # Pattern won't match, so file is unchanged
        content = test_file.read_text()
        assert "from .module import Name" in content
