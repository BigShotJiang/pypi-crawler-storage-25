"""CLI entry point for minport."""

from __future__ import annotations

import argparse
import os
import sys
import tomllib
from pathlib import Path
from typing import TYPE_CHECKING

from minport._persistent_cache import open_origin_cache
from minport._progress import ProgressReporter
from minport.checker import check

if TYPE_CHECKING:
    from minport._models import CheckResult, FixResult


def main(argv: list[str] | None = None) -> int:
    """Entry point for ``minport check``."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "handler"):
        parser.print_help()
        return 0

    return args.handler(args)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="minport",
        description="Find unnecessarily long import paths and suggest shorter alternatives",
    )
    sub = parser.add_subparsers()

    check_parser = sub.add_parser("check", help="Run the checker")
    check_parser.add_argument(
        "paths",
        nargs="*",
        type=Path,
        help="Files or directories to check",
    )
    check_parser.add_argument(
        "--fix",
        action="store_true",
        default=False,
        help="Auto-fix import paths in place",
    )
    check_parser.add_argument(
        "--src",
        dest="src_roots",
        action="append",
        type=Path,
        default=None,
        help="Source root(s) for import resolution",
    )
    check_parser.add_argument(
        "--exclude",
        action="append",
        default=None,
        help="Glob patterns to exclude (overrides defaults)",
    )
    check_parser.add_argument(
        "--extend-exclude",
        action="append",
        default=None,
        help="Glob patterns to add to the exclude list",
    )
    check_parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Path to pyproject.toml",
    )
    check_parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        default=False,
        help="Suppress the summary line",
    )
    check_parser.add_argument(
        "--output-format",
        choices=["text", "github"],
        default="text",
        help="Output format (default: text)",
    )
    check_parser.add_argument(
        "--no-cache",
        action="store_true",
        default=False,
        help=(
            "Disable the persistent find_spec cache for this run. "
            "Equivalent to setting MINPORT_NO_CACHE=1."
        ),
    )
    check_parser.set_defaults(handler=_handle_check)
    return parser


def _handle_check(args: argparse.Namespace) -> int:
    config = _load_config(args.config)

    paths: list[Path] = args.paths or [Path(p) for p in _config_str_list(config, "src", ["."])]
    if not paths:
        paths = [Path()]

    src_roots: list[Path] | None = args.src_roots or None
    exclude: list[str] | None = args.exclude or _config_str_list_or_none(config, "exclude")
    extend_exclude = args.extend_exclude or _config_str_list(config, "extend-exclude", [])

    for p in paths:
        if not p.exists():
            sys.stderr.write(f"Error: path does not exist: {p}\n")
            return 2

    reporter = ProgressReporter(
        stream=sys.stderr,
        enabled=(not args.quiet and args.output_format != "github" and sys.stderr.isatty()),
    )
    try:
        with open_origin_cache(_resolve_cache_root(no_cache=args.no_cache)) as cache:
            check_result, fix_result = check(
                paths,
                src_roots=src_roots,
                exclude=exclude,
                extend_exclude=extend_exclude,
                fix=args.fix,
                progress=reporter.update,
                installed_origin_cache=cache,
            )
    finally:
        reporter.close()

    if args.output_format == "github":
        _output_github(check_result)
    else:
        _output_text(check_result, fix_result, quiet=args.quiet)

    return 1 if check_result.violations else 0


def _resolve_cache_root(*, no_cache: bool = False) -> Path | None:
    """Return the persistent cache root, or None if persistence is disabled.

    Resolution order:
    1. ``no_cache=True`` (from ``--no-cache``) or ``MINPORT_NO_CACHE`` set
       → ``None`` (disabled).
    2. ``MINPORT_CACHE_DIR`` → explicit override path.
    3. ``XDG_CACHE_HOME/minport`` per the XDG Base Directory spec.
    4. ``~/.cache/minport`` (XDG default).

    SQLite on NFS is roughly 1000x slower per operation than on local
    disk due to file-locking overhead. Users with NFS-mounted home
    directories should set ``MINPORT_CACHE_DIR`` to a local-disk path,
    or ``MINPORT_NO_CACHE=1`` / ``--no-cache`` to skip persistence.
    """
    if no_cache or os.environ.get("MINPORT_NO_CACHE"):
        return None
    env = os.environ.get("MINPORT_CACHE_DIR")
    if env:
        return Path(env)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "minport"
    return Path.home() / ".cache" / "minport"


def _load_config(config_path: Path | None) -> dict[str, object]:
    """Load [tool.minport] from pyproject.toml."""
    if config_path is None:
        config_path = Path("pyproject.toml")
    if not config_path.is_file():
        return {}
    try:
        with config_path.open("rb") as f:
            data = tomllib.load(f)
    except (tomllib.TOMLDecodeError, OSError):
        return {}
    tool = data.get("tool", {})
    if isinstance(tool, dict):
        section = tool.get("minport", {})
        if isinstance(section, dict):
            return section
    return {}


def _config_str_list(config: dict[str, object], key: str, default: list[str]) -> list[str]:
    """Extract a list-of-strings value from config with type safety."""
    value = config.get(key)
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return [str(v) for v in value]
    return default


def _config_str_list_or_none(config: dict[str, object], key: str) -> list[str] | None:
    """Extract a list-of-strings value from config, returning ``None`` if absent."""
    value = config.get(key)
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return [str(v) for v in value]
    return None


def _output_text(
    result: CheckResult,
    fix_result: FixResult | None = None,
    *,
    quiet: bool = False,
) -> None:
    for v in result.violations:
        sys.stdout.write(f"{v.file_path}:{v.line}:{v.col}: {v.code} {v.message}\n")
    if quiet:
        return
    sys.stdout.write(_summary_line(result, fix_result))


def _output_github(result: CheckResult) -> None:
    cwd = Path.cwd()
    for v in result.violations:
        title = f"minport ({v.code})"
        try:
            file: Path = v.file_path.relative_to(cwd)
        except ValueError:
            file = v.file_path
        msg = _escape_github_message(v.message)
        sys.stdout.write(f"::error file={file},line={v.line},col={v.col},title={title}::{msg}\n")


_GITHUB_ESCAPES = str.maketrans({"%": "%25", "\r": "%0D", "\n": "%0A"})


def _escape_github_message(s: str) -> str:
    return s.translate(_GITHUB_ESCAPES)


def _summary_line(result: CheckResult, fix_result: FixResult | None) -> str:
    count = len(result.violations)
    errors = f"Found {count} error{'s' if count != 1 else ''}"
    checked = f"checked {result.files_checked} file{'s' if result.files_checked != 1 else ''}"
    if count == 0:
        return f"{errors} ({checked}).\n"
    if fix_result is not None:
        files_word = "file" if fix_result.files_modified == 1 else "files"
        fixed = f"fixed {fix_result.fixes_applied} in {fix_result.files_modified} {files_word}"
        return f"{errors} ({checked}, {fixed}).\n"
    return f"{errors} ({checked}, {result.fixable_count} fixable with `minport check --fix`).\n"


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
