"""Tests for the deterministic query structural fingerprint."""

from __future__ import annotations

import pytest

from nare.query_fingerprint import (
    average_pairwise_jaccard,
    query_fingerprint,
    query_jaccard,
)


def test_empty_query_returns_empty_fingerprint():
    assert query_fingerprint("") == {}
    assert query_fingerprint("   ") == {}
    assert query_fingerprint(None) == {}  # type: ignore[arg-type]


def test_number_count_bucketed():
    fp0 = query_fingerprint("Hello there")
    fp1 = query_fingerprint("There are 5 apples")
    fp2 = query_fingerprint("U Pet has 5 apples and gave 2 away")
    fp_many = query_fingerprint("1 2 3 4 5 6 7 numbers")
    assert fp0.get("NUMS.0") == 1
    assert fp1.get("NUMS.1") == 1
    assert fp2.get("NUMS.2") == 1
    assert fp_many.get("NUMS.MANY") == 1


def test_arithmetic_operation_tags_detected():
    fp_add = query_fingerprint("How much is 5 plus 3?")
    fp_sub = query_fingerprint("Subtract 2 from 10")
    fp_mul = query_fingerprint("Multiply 4 times 6")
    assert "OP.ADD" in fp_add
    assert "OP.SUB" in fp_sub
    assert "OP.MUL" in fp_mul


def test_minus_and_times_as_word_tokens():
    """Single-word op tokens 'minus' and 'times' must use word-boundary
    matching, not bare substring match.
    Regression: 'Sometimes' contains substring 'times', 'minuscule'
    contains 'minus' — naive 'in' matching produced spurious OP.MUL /
    OP.SUB tags."""
    # True positives: word-boundary tokens fire.
    fp_minus = query_fingerprint("10 minus 2")
    fp_times = query_fingerprint("Multiply 4 times 6")
    assert "OP.SUB" in fp_minus
    assert "OP.MUL" in fp_times

    # False positives that the buggy substring match would have caught.
    fp_sometimes = query_fingerprint("Sometimes I sleep 7 hours")
    fp_minuscule = query_fingerprint("A minuscule difference of 1 unit")
    fp_timestamp = query_fingerprint("Process the timestamp 5 times slower")
    assert "OP.MUL" not in fp_sometimes
    assert "OP.SUB" not in fp_minuscule
    # 'timestamp' should NOT alone fire OP.MUL; '5 times' (separate word)
    # should still fire it. Net: OP.MUL=1 from the second occurrence.
    assert fp_timestamp.get("OP.MUL", 0) == 1


def test_arithmetic_invariant_under_noun_substitution():
    """Two arithmetic queries with different surface nouns should have
    high fingerprint overlap (the original 'переобучение на словах'
    failure mode)."""
    a = query_fingerprint("У Пети 5 яблок, он отдал 2")
    b = query_fingerprint("У NASA 5 шаттлов, 2 сгорели")
    assert query_jaccard(a, b) >= 0.40, (a, b, query_jaccard(a, b))


def test_arithmetic_separated_from_string_extraction():
    """Arithmetic and email-extraction tasks must NOT alias structurally."""
    arithmetic = query_fingerprint("Sum the values 3 and 4")
    extract = query_fingerprint(
        "Extract emails from this text: alice@example.com, bob@example.org"
    )
    assert query_jaccard(arithmetic, extract) < 0.30


def test_question_mark_and_currency_markers():
    fp = query_fingerprint("How much does 12 USD convert to in $ and €?")
    assert fp.get("HAS.QUESTION") == 1
    assert fp.get("HAS.CURRENCY") == 1


def test_email_marker():
    fp = query_fingerprint("Send to alice@example.com")
    assert fp.get("HAS.EMAIL") == 1


def test_jaccard_on_self_is_one():
    fp = query_fingerprint("Sum the values 3 and 4")
    assert query_jaccard(fp, fp) == pytest.approx(1.0)


def test_jaccard_on_empty_is_zero():
    fp = query_fingerprint("Sum the values 3 and 4")
    assert query_jaccard(fp, {}) == 0.0
    assert query_jaccard({}, fp) == 0.0
    assert query_jaccard(None, fp) == 0.0  # type: ignore[arg-type]


def test_average_pairwise_jaccard_homogeneous_cluster():
    fps = [
        query_fingerprint("У Пети 5 яблок, он отдал 2"),
        query_fingerprint("У NASA 5 шаттлов, 2 сгорели"),
        query_fingerprint("У Маши 5 конфет, она отдала 2 подруге"),
    ]
    assert average_pairwise_jaccard(fps) >= 0.50


def test_average_pairwise_jaccard_heterogeneous_cluster():
    fps = [
        query_fingerprint("Sum the values 3 and 4"),
        query_fingerprint("Extract emails from text"),
        query_fingerprint("Translate this to French"),
    ]
    assert average_pairwise_jaccard(fps) < 0.50


def test_average_pairwise_jaccard_too_few_returns_zero():
    assert average_pairwise_jaccard([]) == 0.0
    assert average_pairwise_jaccard([query_fingerprint("only one")]) == 0.0


def test_length_buckets():
    short = query_fingerprint("hi")
    medium = query_fingerprint("a" * 100)
    long_ = query_fingerprint("a" * 500)
    assert short.get("LEN.SHORT") == 1
    assert medium.get("LEN.MED") == 1
    assert long_.get("LEN.LONG") == 1
