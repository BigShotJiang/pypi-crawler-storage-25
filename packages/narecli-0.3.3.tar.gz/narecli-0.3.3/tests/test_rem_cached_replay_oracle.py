"""Regression tests for the ``oracle_spec`` plumbing inside
``NAREProductionAgent._rem_cached_replay``.

After PR #10 wired ``oracle_spec`` per task into the benchmark, induced
HumanEval skills got a real validation signal during ``solve()`` and
during NREM skill induction (peak validation rose from 0.10 → 0.45). But
REM cached-replay still graded the skill's *output value*
(``execute_fn(query)`` — typically ``True`` / ``-1`` / ``"olleh"``)
against a structural ``python_assert`` oracle that expects *code*
(``def is_prime``, ``return``, …). The result was a guaranteed 0/N
score on every code skill — REM penalised them, confidence collapsed,
amortization stayed stuck.

This module covers the targeted fix: when the episode's oracle_spec is
``python_assert`` (a code-shape oracle) the cached-replay path grades
the skill's source code, not the execute_fn output. Other spec types
(``numeric_set`` / ``string_contains``) keep grading the execute_fn
output as before."""

from __future__ import annotations

import tempfile

import pytest

from nare.agent import NAREProductionAgent
from nare.config import DEFAULT_CONFIG
from nare.memory import MemorySystem


@pytest.fixture
def isolated_agent():
    tmp = tempfile.TemporaryDirectory()
    agent = NAREProductionAgent(config=DEFAULT_CONFIG)
    agent.memory = MemorySystem(
        embedding_dim=agent.memory.embedding_dim,
        persist_dir=tmp.name,
        config=DEFAULT_CONFIG,
    )
    try:
        yield agent
    finally:
        tmp.cleanup()


def _add_episode(agent, query: str, solution: str, oracle_spec=None):
    """Push an episode into memory bypassing the score gate / dedupe so
    every test starts from a known cache state."""
    ep = {
        "query": query,
        "context": "",
        "solution": solution,
        "reasoning_trace": "N/A",
        "abstract_signature": query,
        "score": 0.9,
        "embedding": [0.0] * agent.memory.embedding_dim,
    }
    if oracle_spec is not None:
        ep["oracle_spec"] = oracle_spec
    with agent.memory._lock:
        agent.memory.episodes.append(ep)


# Skill source code: a minimal "is_prime" rule. trigger() always fires,
# execute(query) returns True for "is 7 prime?" — i.e. it returns a
# bool, NOT a code string. This is the precise mismatch the fix targets.
_PRIME_RULE_CODE = (
    "def trigger(query):\n"
    "    return 'prime' in query.lower()\n"
    "\n"
    "def execute(query):\n"
    "    import re\n"
    "    nums = [int(m) for m in re.findall(r'\\d+', query)]\n"
    "    if not nums:\n"
    "        return False\n"
    "    n = nums[0]\n"
    "    if n < 2:\n"
    "        return False\n"
    "    for i in range(2, n):\n"
    "        if n % i == 0:\n"
    "            return False\n"
    "    return True\n"
)

_PRIME_RULE = {
    "pattern": "IsPrime",
    "python_code": _PRIME_RULE_CODE,
    "confidence": 0.5,
}

# A python_assert oracle that checks the candidate code uses modulo
# and returns something. Same shape as real_100_benchmark.py harnesses
# but relaxed (the real benchmark harness expects a `def *prime*(`
# function name; induced rules name their entry point ``execute``,
# so for skill-code grading we drop the name check).
_PRIME_HARNESS_SPEC = {
    "type": "python_assert",
    "code": (
        "import re\n"
        "assert \"%\" in answer, \"no modulo operation\"\n"
        "assert \"return\" in answer, \"no return statement\"\n"
    ),
}


def test_python_assert_spec_grades_skill_code_not_execute_output(isolated_agent):
    """Before the fix: replay graded ``True`` (execute_fn output) against
    the structural harness → False, score=0/N.
    After the fix: replay grades the skill's source against the harness
    → passes."""
    agent = isolated_agent
    _add_episode(
        agent,
        "Is 7 prime?",
        "Yes, 7 is prime.",
        oracle_spec=_PRIME_HARNESS_SPEC,
    )

    scores, failing, n_triggered = agent._rem_cached_replay(_PRIME_RULE)

    assert n_triggered == 1
    assert scores is not None
    assert scores["replay_n_correct"] == 1
    assert scores["execute_accuracy"] == 1.0
    assert scores["overall"] == 1.0
    assert failing == []


def test_python_assert_spec_correctly_rejects_bogus_skill(isolated_agent):
    """The harness must still reject a skill whose code does NOT contain
    a *prime* function (e.g. someone induced an `add` rule by mistake)."""
    agent = isolated_agent
    _add_episode(
        agent,
        "Is 7 prime?",
        "Yes, 7 is prime.",
        oracle_spec=_PRIME_HARNESS_SPEC,
    )

    bogus = {
        "pattern": "AddNumbers",
        "python_code": (
            "def trigger(query):\n"
            "    return 'prime' in query.lower()\n"
            "\n"
            "def execute(query):\n"
            "    return 1 + 2\n"
        ),
        "confidence": 0.5,
    }
    scores, failing, n_triggered = agent._rem_cached_replay(bogus)
    assert n_triggered == 1
    assert scores["replay_n_correct"] == 0
    assert scores["execute_accuracy"] == 0.0
    assert len(failing) == 1


def test_numeric_set_spec_still_grades_execute_output(isolated_agent):
    """Sanity check: non-code oracles (``numeric_set``) must keep
    grading the execute_fn output, not the source code. Otherwise we'd
    regress GSM8K skill validation."""
    agent = isolated_agent
    _add_episode(
        agent,
        "What is 3 + 4?",
        "7",
        oracle_spec={"type": "numeric_set", "expected": [7]},
    )

    add_rule = {
        "pattern": "Add",
        "python_code": (
            "def trigger(query):\n"
            "    return '+' in query or 'plus' in query.lower()\n"
            "\n"
            "def execute(query):\n"
            "    import re\n"
            "    nums = [int(m) for m in re.findall(r'\\d+', query)]\n"
            "    return sum(nums)\n"
        ),
        "confidence": 0.5,
    }
    scores, _failing, n_triggered = agent._rem_cached_replay(add_rule)
    assert n_triggered == 1
    assert scores["replay_n_correct"] == 1
    assert scores["execute_accuracy"] == 1.0


def test_numeric_set_spec_rejects_wrong_answer(isolated_agent):
    """And an Add rule that returns the wrong number must still fail."""
    agent = isolated_agent
    _add_episode(
        agent,
        "What is 3 + 4?",
        "7",
        oracle_spec={"type": "numeric_set", "expected": [7]},
    )

    wrong_rule = {
        "pattern": "AddOne",
        "python_code": (
            "def trigger(query):\n"
            "    return '+' in query\n"
            "\n"
            "def execute(query):\n"
            "    return 1\n"
        ),
        "confidence": 0.5,
    }
    scores, failing, n_triggered = agent._rem_cached_replay(wrong_rule)
    assert n_triggered == 1
    assert scores["replay_n_correct"] == 0
    assert scores["execute_accuracy"] == 0.0
    assert len(failing) == 1
    # Failing diagnostic should mention what was expected.
    assert "missing" in failing[0]["info"].lower()


def test_string_contains_spec_grades_execute_output(isolated_agent):
    """``string_contains`` is a value-shape oracle: still graded against
    the execute_fn output."""
    agent = isolated_agent
    _add_episode(
        agent,
        "Capital of France?",
        "Paris is the capital.",
        oracle_spec={"type": "string_contains", "must_contain": ["paris"]},
    )

    capital_rule = {
        "pattern": "Capital",
        "python_code": (
            "def trigger(query):\n"
            "    return 'capital' in query.lower()\n"
            "\n"
            "def execute(query):\n"
            "    return 'paris'\n"
        ),
        "confidence": 0.5,
    }
    scores, _failing, n_triggered = agent._rem_cached_replay(capital_rule)
    assert n_triggered == 1
    assert scores["replay_n_correct"] == 1


def test_no_oracle_spec_falls_back_to_cached_episode_oracle(isolated_agent):
    """An episode with no oracle_spec must keep using the legacy
    cached_episode_oracle (string equality with stored solution)."""
    agent = isolated_agent
    _add_episode(agent, "Echo hello", "hello")

    echo_rule = {
        "pattern": "Echo",
        "python_code": (
            "def trigger(query):\n"
            "    return 'echo' in query.lower()\n"
            "\n"
            "def execute(query):\n"
            "    return 'hello'\n"
        ),
        "confidence": 0.5,
    }
    scores, _failing, n_triggered = agent._rem_cached_replay(echo_rule)
    assert n_triggered == 1
    assert scores["replay_n_correct"] == 1


def test_bad_python_assert_spec_falls_back_gracefully(isolated_agent):
    """Malformed python_assert spec must not crash replay — fall back
    to cached_episode_oracle on the value, not raise."""
    agent = isolated_agent
    _add_episode(
        agent,
        "Is 7 prime?",
        "True",
        oracle_spec={
            "type": "python_assert",
            "code": "this is not valid python code (((",
        },
    )

    scores, _failing, n_triggered = agent._rem_cached_replay(_PRIME_RULE)
    # Replay must complete without raising. The fallback oracle compares
    # execute() output ("True") to stored solution ("True") → passes.
    assert n_triggered == 1
    assert scores is not None


def test_zero_episodes_returns_none(isolated_agent):
    """No episodes triggered → (None, [], 0). Caller must fall back to
    LLM-stress mode in that case."""
    agent = isolated_agent
    # No episodes in memory at all.
    scores, failing, n_triggered = agent._rem_cached_replay(_PRIME_RULE)
    assert (scores, failing, n_triggered) == (None, [], 0)
