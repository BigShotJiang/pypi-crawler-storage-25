"""Sleep trigger secondary gate via query structural fingerprint.

When ``SleepConfig.use_query_fingerprint_gate`` is ON, dense embedding
clusters must ALSO show high pairwise multiset Jaccard over their
query fingerprints to fire sleep. When OFF (default), behaviour is
unchanged.
"""

from __future__ import annotations

import threading
from dataclasses import replace

import numpy as np
import pytest

from nare.agent import NAREProductionAgent
from nare.config import DEFAULT_CONFIG, NareConfig, SleepConfig
from nare.query_fingerprint import query_fingerprint


class _FakeMemory:
    def __init__(self, episodes):
        self.episodes = list(episodes)
        self._lock = threading.RLock()


class _FakeAgent:
    def __init__(self, episodes, config):
        self.memory = _FakeMemory(episodes)
        self.config = config

    _check_sleep_trigger = NAREProductionAgent._check_sleep_trigger
    _normalize_embeddings = NAREProductionAgent._normalize_embeddings


def _ep(query: str, vec):
    arr = np.array(vec, dtype=np.float32)
    arr = arr / (np.linalg.norm(arr) + 1e-12)
    return {
        "query": query,
        "solution": "x",
        "embedding": arr.tolist(),
        "signature_embedding": arr.tolist(),
        "query_fingerprint": query_fingerprint(query),
    }


def _config_with_gate(gate: bool, threshold: float = 0.50) -> NareConfig:
    sleep = replace(
        DEFAULT_CONFIG.sleep,
        cluster_density_threshold=3,
        cluster_similarity_threshold=0.50,
        use_query_fingerprint_gate=gate,
        query_fingerprint_threshold=threshold,
    )
    return replace(DEFAULT_CONFIG, sleep=sleep)


def test_dense_homogeneous_arithmetic_fires_with_gate():
    """Three arithmetic queries with similar embeddings AND high
    fingerprint Jaccard fire the trigger when the gate is on."""
    eps = [
        _ep("У Пети 5 яблок, отдал 2", [1.0, 0.0]),
        _ep("У NASA 5 шаттлов, 2 сгорели", [1.0, 0.01]),
        _ep("У Маши 5 конфет, отдала 2", [1.0, 0.02]),
    ]
    agent = _FakeAgent(eps, _config_with_gate(gate=True, threshold=0.40))
    assert agent._check_sleep_trigger() is True


def test_dense_heterogeneous_cluster_rejected_by_gate():
    """Three queries with similar embeddings (we force this) but
    structurally heterogeneous fingerprints are REJECTED when the gate
    is on."""
    eps = [
        _ep("Sum 3 and 4", [1.0, 0.0]),
        _ep("Translate the document to French", [1.0, 0.01]),
        _ep("Extract emails from text alice@example.com", [1.0, 0.02]),
    ]
    agent = _FakeAgent(eps, _config_with_gate(gate=True, threshold=0.50))
    assert agent._check_sleep_trigger() is False


def test_gate_off_lets_heterogeneous_cluster_fire():
    """Same heterogeneous cluster as above; with the gate OFF,
    behaviour is identical to the old embedding-only trigger."""
    eps = [
        _ep("Sum 3 and 4", [1.0, 0.0]),
        _ep("Translate the document to French", [1.0, 0.01]),
        _ep("Extract emails from text alice@example.com", [1.0, 0.02]),
    ]
    agent = _FakeAgent(eps, _config_with_gate(gate=False))
    assert agent._check_sleep_trigger() is True


def test_too_few_episodes_no_trigger():
    eps = [_ep("a", [1.0, 0.0])]
    agent = _FakeAgent(eps, _config_with_gate(gate=True))
    assert agent._check_sleep_trigger() is False


def test_legacy_episodes_without_fingerprint_pass_gate():
    """Episodes loaded from a pre-Tier-B store have no
    ``query_fingerprint`` field. The gate must NOT silently reject
    every cluster — it must skip evaluation and fall back to
    embedding-only behaviour."""
    eps = [
        _ep("Sum 3 and 4", [1.0, 0.0]),
        _ep("Translate to French", [1.0, 0.01]),
        _ep("Extract emails alice@example.com", [1.0, 0.02]),
    ]
    # Strip fingerprint data to simulate legacy episodes.
    for e in eps:
        e.pop("query_fingerprint", None)
    agent = _FakeAgent(eps, _config_with_gate(gate=True, threshold=0.50))
    # Without fingerprint data the gate cannot meaningfully veto, so the
    # dense embedding cluster must still fire (i.e. the same outcome
    # as gate=False).
    assert agent._check_sleep_trigger() is True


def test_partial_fingerprint_coverage_gate_evaluable():
    """If at least two cluster members have fingerprint data, the gate
    is evaluated normally over those members and ignores the legacy
    ones."""
    eps = [
        _ep("Sum 3 and 4", [1.0, 0.0]),
        _ep("Sum 5 and 6", [1.0, 0.01]),
        _ep("Sum 7 and 8", [1.0, 0.02]),
    ]
    # Strip one — still 2 of 3 have fingerprint data.
    eps[2].pop("query_fingerprint", None)
    agent = _FakeAgent(eps, _config_with_gate(gate=True, threshold=0.50))
    assert agent._check_sleep_trigger() is True


def test_sparse_cluster_no_trigger_either_way():
    """Three orthogonal embeddings: no dense cluster regardless of
    fingerprint gate."""
    eps = [
        _ep("Sum 3 and 4", [1.0, 0.0]),
        _ep("Sum 5 and 6", [0.0, 1.0]),
        _ep("Sum 7 and 8", [0.0, 0.0]),
    ]
    # Last vec is the zero-vector, _normalize divides by max(eps,
    # norm); to keep this deterministic, give it its own axis.
    eps[2]["embedding"] = (np.array([0.0, 0.0, 1.0]) / 1.0).tolist()
    eps[2]["signature_embedding"] = eps[2]["embedding"]
    eps[0]["embedding"] = [1.0, 0.0, 0.0]
    eps[0]["signature_embedding"] = eps[0]["embedding"]
    eps[1]["embedding"] = [0.0, 1.0, 0.0]
    eps[1]["signature_embedding"] = eps[1]["embedding"]
    agent_off = _FakeAgent(eps, _config_with_gate(gate=False))
    agent_on = _FakeAgent(eps, _config_with_gate(gate=True))
    assert agent_off._check_sleep_trigger() is False
    assert agent_on._check_sleep_trigger() is False
