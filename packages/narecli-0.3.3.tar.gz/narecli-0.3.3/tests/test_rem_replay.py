"""Tests for the REM cached-replay path (Tier A2).

These tests do not call any LLM. They construct a rule with hand-written
Python code and a fake ``MemorySystem`` populated with cached episodes
that have verified solutions, then call ``_rem_cached_replay`` directly
to confirm:

1. Replay only counts episodes where ``trigger()`` fires.
2. Score is computed via the strict cached-episode oracle.
3. Crashes (in trigger() or execute()) are counted as failures.
4. ``oracle_spec`` on an individual episode overrides the default.
5. When no episode fires, the function returns ``(None, [], 0)``.
"""

from __future__ import annotations

import threading
from types import SimpleNamespace

import pytest

from nare.agent import NAREProductionAgent
from nare.config import DEFAULT_CONFIG


# ---------------------------------------------------------------------------
# Helpers: build a no-LLM agent fixture by stubbing MemorySystem.
# ---------------------------------------------------------------------------


class _FakeMemory:
    """Minimal MemorySystem stand-in: just an ``episodes`` list and lock."""

    def __init__(self, episodes):
        self.episodes = list(episodes)
        self._lock = threading.RLock()


class _FakeAgent:
    """Bind only the methods we actually exercise so we don't need a
    real Gemini-backed agent."""

    def __init__(self, episodes, oracle=None, config=DEFAULT_CONFIG):
        self.memory = _FakeMemory(episodes)
        self.oracle = oracle
        self.config = config

    _rem_cached_replay = NAREProductionAgent._rem_cached_replay


# ---------------------------------------------------------------------------
# Skill code fixtures
# ---------------------------------------------------------------------------


SUM_SKILL = """
def trigger(query: str) -> bool:
    return '+' in query

def execute(query: str) -> str:
    nums = []
    cur = ''
    for c in query + ' ':
        if c.isdigit():
            cur += c
        elif cur:
            nums.append(int(cur))
            cur = ''
    if len(nums) < 2:
        return 'Error: not enough numbers'
    return str(sum(nums))
"""


WRONG_SKILL = """
def trigger(query: str) -> bool:
    return '+' in query

def execute(query: str) -> str:
    return '999'  # always wrong
"""


CRASH_SKILL = """
def trigger(query: str) -> bool:
    return '+' in query

def execute(query: str) -> str:
    raise ValueError('boom')
"""


def _ep(query, solution, **extra):
    ep = {"query": query, "solution": solution, "embedding": [0.0]}
    ep.update(extra)
    return ep


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_replay_perfect_score():
    """Skill that reproduces every cached solution -> 1.0 / all triggered."""
    agent = _FakeAgent([
        _ep("2 + 5", "7"),
        _ep("3 + 4", "7"),
        _ep("1 + 6", "7"),
        _ep("what is the weather?", "sunny"),  # trigger() should NOT fire
    ])
    rule = {"pattern": "Sum", "python_code": SUM_SKILL}
    scores, failing, n_triggered = agent._rem_cached_replay(rule)

    assert n_triggered == 3
    assert scores["execute_accuracy"] == pytest.approx(1.0)
    assert scores["overall"] == pytest.approx(1.0)
    assert failing == []
    assert scores["replay_n_correct"] == 3
    assert scores["replay_n_triggered"] == 3


def test_replay_fails_when_skill_wrong():
    agent = _FakeAgent([
        _ep("2 + 5", "7"),
        _ep("3 + 4", "7"),
    ])
    rule = {"pattern": "BadSum", "python_code": WRONG_SKILL}
    scores, failing, n_triggered = agent._rem_cached_replay(rule)

    assert n_triggered == 2
    assert scores["execute_accuracy"] == 0.0
    assert len(failing) == 2
    assert all(f["type"] == "POSITIVE" for f in failing)


def test_replay_handles_execute_crash():
    agent = _FakeAgent([
        _ep("2 + 5", "7"),
        _ep("3 + 4", "7"),
    ])
    rule = {"pattern": "Crashy", "python_code": CRASH_SKILL}
    scores, failing, n_triggered = agent._rem_cached_replay(rule)

    assert n_triggered == 2
    assert scores["execute_accuracy"] == 0.0
    assert len(failing) == 2
    assert all("execute" in f["info"].lower() or "boom" in f["info"].lower()
               for f in failing)


def test_replay_returns_none_when_no_trigger_hits():
    """Skill that never fires on the cache => caller falls back to LLM-stress."""
    agent = _FakeAgent([
        _ep("what is the weather?", "sunny"),
        _ep("define photosynthesis", "..."),
    ])
    rule = {"pattern": "Sum", "python_code": SUM_SKILL}
    result = agent._rem_cached_replay(rule)
    assert result == (None, [], 0)


def test_replay_respects_per_episode_oracle_spec():
    """An episode with an oracle_spec uses its own ground-truth, not
    the global cached-episode oracle."""
    agent = _FakeAgent([
        _ep(
            "2 + 5",
            "7",
            oracle_spec={"type": "numeric_set", "expected": [999]},
        ),
        _ep("3 + 4", "7"),  # uses default cached oracle
    ])
    rule = {"pattern": "Sum", "python_code": SUM_SKILL}
    scores, failing, n_triggered = agent._rem_cached_replay(rule)

    assert n_triggered == 2
    # First episode rejects (oracle wants 999, skill returns 7); second accepts.
    assert scores["replay_n_correct"] == 1
    assert scores["execute_accuracy"] == pytest.approx(0.5)


def test_replay_invalid_code_returns_none():
    agent = _FakeAgent([_ep("2 + 5", "7")])
    # Code that fails AST validation (uses forbidden ``open``).
    bad_rule = {
        "pattern": "Bad",
        "python_code": "def trigger(q): open('x')\ndef execute(q): return 'x'",
    }
    result = agent._rem_cached_replay(bad_rule)
    assert result == (None, [], 0)


def test_replay_empty_code_returns_none():
    agent = _FakeAgent([_ep("2 + 5", "7")])
    result = agent._rem_cached_replay({"pattern": "Empty", "python_code": ""})
    assert result == (None, [], 0)
