"""Replay-driven tau_fast calibration tests.

These tests exercise the offline calibration sweep against synthetic
episode stores constructed so that the right answer is known in advance.
No LLM calls.
"""

from __future__ import annotations

import math
from typing import Dict, List

import numpy as np
import pytest

from nare.tau_calibration import calibrate_tau_fast, format_roc_table


def _episode(query: str, solution: str, vec: List[float]) -> Dict:
    arr = np.array(vec, dtype=np.float32)
    arr = arr / (np.linalg.norm(arr) + 1e-12)
    return {
        "query": query,
        "solution": solution,
        "embedding": arr.tolist(),
    }


def test_empty_store_returns_zero_pairs():
    out = calibrate_tau_fast([])
    assert out["n_pairs"] == 0
    assert out["roc"] == []
    assert out["recommended_tau"] is None


def test_single_episode_returns_zero_pairs():
    out = calibrate_tau_fast([_episode("q", "5", [1.0, 0.0])])
    assert out["n_episodes"] == 1
    assert out["n_pairs"] == 0


def test_perfect_alignment_recommends_low_tau():
    """All embeddings identical, all solutions identical -> any tau
    has 100% precision."""
    eps = [_episode(f"q{i}", "42", [1.0, 0.0]) for i in range(4)]
    out = calibrate_tau_fast(eps, target_precision=0.95)
    # With identical embeddings, every pair has sim=1.0, so every tau
    # in the sweep activates fast and every activation is correct.
    assert out["recommended_tau"] is not None
    assert out["recommended_tau"] <= 0.91  # tau_min default 0.90
    for row in out["roc"]:
        if row["coverage"] > 0:
            assert row["precision"] == pytest.approx(1.0)


def test_orthogonal_pair_never_activates():
    """Two orthogonal embeddings never trigger FAST; precision is
    vacuously 1.0 with 0 coverage."""
    eps = [
        _episode("q1", "42", [1.0, 0.0]),
        _episode("q2", "42", [0.0, 1.0]),
    ]
    out = calibrate_tau_fast(eps, target_precision=0.95, tau_min=0.50, tau_max=0.99)
    for row in out["roc"]:
        assert row["coverage"] == 0.0
    assert out["recommended_tau"] is None  # vacuous tau is rejected


def test_high_sim_wrong_solution_rejected():
    """Two near-identical embeddings but DIFFERENT verified solutions:
    FAST would copy the wrong solution, precision must drop below
    target."""
    eps = [
        _episode("q1", "42", [1.0, 0.001]),
        _episode("q2", "99", [1.0, -0.001]),  # different solution
    ]
    out = calibrate_tau_fast(eps, target_precision=0.95, tau_min=0.50, tau_max=0.99)
    high_tau_rows = [r for r in out["roc"] if r["coverage"] > 0]
    assert all(r["precision"] < 0.95 for r in high_tau_rows)
    assert out["recommended_tau"] is None


def test_mixed_population_recommends_threshold_above_collision_band():
    """Construct two clusters: cluster A has identical solutions
    (correct under any threshold), cluster B has *different* solutions
    but moderately similar embeddings. The recommended tau should sit
    above cluster B's similarity band so that precision >= target.
    """
    # Cluster A: solution "A", three near-identical vectors (sim ~ 1.0).
    cluster_a = [
        _episode(f"qa{i}", "A", [1.0, 0.0, 0.0])
        for i in range(3)
    ]
    # Cluster B: vectors with sim ~ 0.8 to each other but DIFFERENT
    # verified solutions.
    cluster_b = [
        _episode("qb1", "X", [0.6, 0.8, 0.0]),
        _episode("qb2", "Y", [0.8, 0.6, 0.0]),
    ]
    out = calibrate_tau_fast(
        cluster_a + cluster_b,
        target_precision=0.95,
        tau_min=0.70,
        tau_max=0.99,
        tau_step=0.01,
    )
    rec = out["recommended_tau"]
    assert rec is not None
    # Cluster B's pair sim is 0.96 (they're orthogonal'ish but in
    # 2D normalized space the cos similarity is 0.96), so the
    # recommendation must be ABOVE that.
    sim_b = 0.6 * 0.8 + 0.8 * 0.6 + 0  # = 0.96
    assert rec > sim_b - 1e-6, f"rec={rec} not above noisy-pair sim {sim_b}"


def test_format_roc_table_runs():
    eps = [_episode(f"q{i}", "42", [1.0, 0.001 * i]) for i in range(4)]
    out = calibrate_tau_fast(eps, target_precision=0.99)
    text = format_roc_table(out)
    assert "tau_fast calibration" in text
    assert "precision" in text
    assert "coverage" in text


def test_invalid_step_raises():
    with pytest.raises(ValueError):
        calibrate_tau_fast([], tau_step=0.0)


def test_invalid_range_raises():
    with pytest.raises(ValueError):
        calibrate_tau_fast([], tau_min=0.99, tau_max=0.50)
