# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_cms20240330 import models as main_models
from darabonba.model import DaraModel

class MaintainWindowForModify(DaraModel):
    def __init__(
        self,
        description: str = None,
        effect_time_range: main_models.MaintainWindowForModifyEffectTimeRange = None,
        effective: str = None,
        end_time: str = None,
        filter_setting: main_models.FilterSetting = None,
        maintain_window_name: str = None,
        start_time: str = None,
    ):
        # Description.
        self.description = description
        # Effective time range.
        self.effect_time_range = effect_time_range
        # Crontab expression.
        self.effective = effective
        # Effective end time.
        self.end_time = end_time
        # Filtering conditions.
        self.filter_setting = filter_setting
        # Name.
        # 
        # This parameter is required.
        self.maintain_window_name = maintain_window_name
        # Effective start time.
        self.start_time = start_time

    def validate(self):
        if self.effect_time_range:
            self.effect_time_range.validate()
        if self.filter_setting:
            self.filter_setting.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.description is not None:
            result['description'] = self.description

        if self.effect_time_range is not None:
            result['effectTimeRange'] = self.effect_time_range.to_map()

        if self.effective is not None:
            result['effective'] = self.effective

        if self.end_time is not None:
            result['endTime'] = self.end_time

        if self.filter_setting is not None:
            result['filterSetting'] = self.filter_setting.to_map()

        if self.maintain_window_name is not None:
            result['maintainWindowName'] = self.maintain_window_name

        if self.start_time is not None:
            result['startTime'] = self.start_time

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('description') is not None:
            self.description = m.get('description')

        if m.get('effectTimeRange') is not None:
            temp_model = main_models.MaintainWindowForModifyEffectTimeRange()
            self.effect_time_range = temp_model.from_map(m.get('effectTimeRange'))

        if m.get('effective') is not None:
            self.effective = m.get('effective')

        if m.get('endTime') is not None:
            self.end_time = m.get('endTime')

        if m.get('filterSetting') is not None:
            temp_model = main_models.FilterSetting()
            self.filter_setting = temp_model.from_map(m.get('filterSetting'))

        if m.get('maintainWindowName') is not None:
            self.maintain_window_name = m.get('maintainWindowName')

        if m.get('startTime') is not None:
            self.start_time = m.get('startTime')

        return self

class MaintainWindowForModifyEffectTimeRange(DaraModel):
    def __init__(
        self,
        day_in_week: List[int] = None,
        end_time_in_minute: int = None,
        start_time_in_minute: int = None,
        time_zone: str = None,
    ):
        # Effective days (Monday to Sunday).
        self.day_in_week = day_in_week
        # End time (in minutes).
        self.end_time_in_minute = end_time_in_minute
        # Start time (in minutes).
        self.start_time_in_minute = start_time_in_minute
        # Time zone.
        self.time_zone = time_zone

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.day_in_week is not None:
            result['dayInWeek'] = self.day_in_week

        if self.end_time_in_minute is not None:
            result['endTimeInMinute'] = self.end_time_in_minute

        if self.start_time_in_minute is not None:
            result['startTimeInMinute'] = self.start_time_in_minute

        if self.time_zone is not None:
            result['timeZone'] = self.time_zone

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('dayInWeek') is not None:
            self.day_in_week = m.get('dayInWeek')

        if m.get('endTimeInMinute') is not None:
            self.end_time_in_minute = m.get('endTimeInMinute')

        if m.get('startTimeInMinute') is not None:
            self.start_time_in_minute = m.get('startTimeInMinute')

        if m.get('timeZone') is not None:
            self.time_zone = m.get('timeZone')

        return self

