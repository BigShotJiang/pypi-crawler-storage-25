from ..modules import MetadataPart
from ..exceptions import ErrorMetadata, ErrorMetadataAttacher

class MetadataBuilder(object):
    def __init__(self):
        self.__metadata_parts: list[MetadataPart] = []

    def attach(self, attacher: list[MetadataPart] = []):
        if not isinstance(attacher, list):
            raise ErrorMetadataAttacher("invalid input to attach")
        
        for _ in attacher:
            if not isinstance(_, MetadataPart):
                raise ErrorMetadataAttacher("invalid attacher`s structure")
        
        self.__metadata_parts = attacher
    
    def add(
        self,
        *args: MetadataPart,
    ) -> None:
        for arg in args:
            if not isinstance(arg, MetadataPart):
                raise ErrorMetadata("invalid metadata input")
            
            if (arg.type != "Link" and arg.link_url):
                raise ErrorMetadata(f"metadata type `{arg.type}` does not support `link_url`")
            
            if (arg.type != "MentionText" and arg.mention_text_user_id):
                raise ErrorMetadata(f"metadata type `{arg.type}` does not support `mention_text_user_id`")
            
            if (arg.type == "Link" and not arg.link_url):
                raise ErrorMetadata(f"metadata type `{arg.type}` requires `link_url`")

            if (arg.type == "MentionText" and not arg.mention_text_user_id):
                raise ErrorMetadata(f"metadata type `{arg.type}` requires `mention_text_user_id`")
            
            self.__metadata_parts.append(arg)

    def getMetadataParts(self) -> list[MetadataPart]:
        return self.__metadata_parts
