from httpx import Client, AsyncClient, TimeoutException
from ..exceptions import InternetConnectionError, ServerResponseError, ClientInputError, StatusError
from ..modules import When
from typing import Any, Dict, Literal, List, Union
import asyncio, json

class MainNetwork(object):
    def __init__(self, token: str, whens: Dict[Literal[
            'started_polling', 'stopped_polling',
            'started_schedule', 'stopped_schedule',
            'internet_connection_error', 'timeout_error',
            'server_response_error', 'client_input_error',
            'status_error', 'json_decode_error',
            'session_or_token_not_found', 'polling_exception'
        ], List[When]] = {}):
        self.token = token
        self.__whens = whens
        self.__url = "https://botapi.rubika.ir/v3/" + self.token + "/"
        self.__pypi = "https://pypi.org/pypi/"
        self.synchttp  = Client()
        self.asynchttp = AsyncClient()

    def join(self, method: str):
        return self.__url + method
    
    def createChild(self, child_token: str, method: str):
        return "https://botapi.rubika.ir/v3/" + child_token + method
    
    def seeModuleVersions(self, module_name: str) -> list:
        url = self.__pypi + module_name + "/json"
        try:
            return list(self.synchttp.get(url).json()['releases'].keys())
        except:
            return []
    
    def seeLastVersionOfModule(self, module_name: str) -> Union[str, None]:
        url = self.__pypi + module_name + "/json"
        try:
            return self.synchttp.get(url).json()['info']['version']
        except:
            return None
        
    async def seeModuleVersionsAsync(self, module_name: str) -> list:
        url = self.__pypi + module_name + "/json"
        try:
            dt = await self.asynchttp.get(url)
            return list(dt.json()['releases'].keys())
        except:
            return []
    
    async def seeLastVersionOfModuleAsync(self, module_name: str) -> Union[str, None]:
        url = self.__pypi + module_name + "/json"
        try:
            dt = await self.asynchttp.get(url)
            return dt.json()['info']['version']
        except:
            return None

    def makeSyncRequest(
        self,
        method: str,
        input_data: dict = {}
    ) -> Any:
        try:
            res = self.synchttp.post(
                self.join(method),
                json=input_data
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError(f"check your internet connection then try again - caused by {method}")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError(f"invalid json to decode - caused by {method}", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError(f"invalid json to decode - caused by {method}", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)
        return __

    async def makeAsyncRequest(
        self,
        method: str,
        input_data: dict = {}
    ) -> Any:
        try:
            url = self.join(method)
            res = await self.asynchttp.post(url, json=input_data)
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError(f"check your internet connection then try again - caused by {method}")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError(f"invalid json to decode - caused by {method}", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError(f"invalid json to decode - caused by {method}", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)
        return __
