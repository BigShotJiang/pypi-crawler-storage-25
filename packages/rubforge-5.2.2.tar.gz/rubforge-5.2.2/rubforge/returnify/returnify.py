from dataclasses import dataclass
import sys

dataclass_items = {}

if sys.version_info >= (3, 10):
    dataclass_items['slots'] = True

@dataclass(**dataclass_items)
class ReturnStop(object):...

