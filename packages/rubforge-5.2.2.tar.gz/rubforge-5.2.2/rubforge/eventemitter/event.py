from dataclasses import dataclass, field
from typing import Optional, Callable, List, Any, Literal, Tuple, Union
from functools import wraps
from ..filters import *

import asyncio
import sys

dataclass_items = {'frozen': True}
if sys.version_info >= (3, 10):
    dataclass_items['slots'] = True


@dataclass(**dataclass_items)
class Event(object):
    event_name: Optional[str] = None
    listener_func: Optional[Callable] = None
    args: Optional[List[Any]] = field(default_factory=list)
    plugins: Optional[Union[Command, Contains, BeforeTimestamp, AfterTimestamp, Equals, isPrivate, isGroup, isChannel, isUnknown, isReply, isForwarded, isNumber, isEmoji, hasBold, hasItalic, hasMono, hasUnderline, hasStrike, hasSpoiler, hasLink, hasMentionText, hasPre, hasQuote, hasEmoji, hasLang, Tuple[Command, Contains, BeforeTimestamp, AfterTimestamp, Equals, isPrivate, isGroup, isChannel, isUnknown, isReply, isForwarded, isEmoji, isNumber, hasBold, hasItalic, hasMono, hasUnderline, hasStrike, hasSpoiler, hasLink, hasMentionText, hasPre, hasQuote, hasEmoji, hasLang], None]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Event":
        return cls(
            event_name=data.get("event_name"),
            listener_func=data.get("listener_func"),
            args=data.get("args"),
            plugins=data.get("plugins")
        )
    
    def to_dict(self) -> dict:
        return {
            "event_name": self.event_name,
            "listener_func": self.listener_func,
            "args": self.args,
            "plugins": self.plugins
        }

class EventEmitter(object):
    def __init__(self):
        self.dict_events: dict[Union[Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot'], str], List[Event]] = {}
        for _ in ['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot']:
            self.dict_events[_] = []

    def on(self, event_name: Union[Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot'], str], *plugins: Optional[Union[Command, Contains, BeforeTimestamp, AfterTimestamp, Equals, isPrivate, isGroup, isChannel, isUnknown, isReply, isForwarded, hasBold, hasItalic, hasMono, hasUnderline, hasStrike, hasSpoiler, hasLink, hasMentionText, hasPre, hasQuote, None]]):
        def decorator(listener_func: Callable):
            if event_name in self.dict_events:
                if plugins is None:
                    opt = Event.from_dict({
                        "event_name": event_name,
                        "listener_func": listener_func,
                        "args": [],
                        "plugins": None
                    })
                    self.dict_events[event_name].append(opt)
                elif isinstance(plugins, tuple):
                    if len(plugins) != 0:
                        opt = Event.from_dict({
                            "event_name": event_name,
                            "listener_func": listener_func,
                            "args": [],
                            "plugins": plugins
                        })
                        self.dict_events[event_name].append(opt)
                    else:
                        opt = Event.from_dict({
                            "event_name": event_name,
                            "listener_func": listener_func,
                            "args": [],
                            "plugins": None
                        })
                        self.dict_events[event_name].append(opt)
                elif (isinstance(plugins, Command) or isinstance(plugins, Contains) or isinstance(plugins, BeforeTimestamp) or isinstance(plugins, AfterTimestamp) or isinstance(plugins, Equals) or isinstance(plugins, isPrivate) or isinstance(plugins, isGroup) or isinstance(plugins, isChannel) or isinstance(plugins, isUnknown) or isinstance(plugins, isReply) or isinstance(plugins, isForwarded) or isinstance(plugins, isNumber) or isinstance(plugins, isEmoji) or isinstance(plugins, hasBold) or isinstance(plugins, hasItalic) or isinstance(plugins, hasMono) or isinstance(plugins, hasUnderline) or isinstance(plugins, hasSpoiler) or isinstance(plugins, hasStrike) or isinstance(plugins, hasLink) or isinstance(plugins, hasMentionText) or isinstance(plugins, hasPre) or isinstance(plugins, hasQuote) or isinstance(plugins, hasEmoji) or isinstance(plugins, hasLang)):
                    opt = Event.from_dict({
                        "event_name": event_name,
                        "listener_func": listener_func,
                        "args": [],
                        "plugins": (plugins[0],)
                    })
                    self.dict_events[event_name].append(opt)
            @wraps(listener_func)
            def wrapper(*args, **kwargs):
                return listener_func(*args, **kwargs)
            return wrapper
        
        return decorator

    def emit(self, event_name: str, *args, **kwargs):
        if event_name in self.dict_events:
            for ev in self.dict_events[event_name]:
                if ev.listener_func:
                    ev.listener_func(*args, **kwargs)

    def get_event(self, event_name: Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot']) -> List[Event]:
        if event_name in self.dict_events:
            return self.dict_events[event_name]
        else:return []

class AsyncEventEmitter(object):
    def __init__(self):
        self.dict_events: dict[Union[Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot'], str], List[Event]] = {}
        for _ in ['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot']:
            self.dict_events[_] = []

    def on(self, event_name: Union[Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot'], str], *plugins: Optional[Union[Command, Contains, BeforeTimestamp, AfterTimestamp, Equals, isPrivate, isGroup, isChannel, isUnknown, isReply, isForwarded, isNumber, isEmoji, hasBold, hasItalic, hasMono, hasUnderline, hasStrike, hasSpoiler, hasLink, hasMentionText, hasPre, hasQuote, hasEmoji, hasLang, None]]):
        def decorator(listener_func: Callable):
            if event_name in self.dict_events:
                if plugins is None:
                    opt = Event.from_dict({
                        "event_name": event_name,
                        "listener_func": listener_func,
                        "args": [],
                        "plugins": None
                    })
                    self.dict_events[event_name].append(opt)
                elif isinstance(plugins, tuple):
                    if len(plugins) != 0:
                        opt = Event.from_dict({
                            "event_name": event_name,
                            "listener_func": listener_func,
                            "args": [],
                            "plugins": plugins
                        })
                        self.dict_events[event_name].append(opt)
                    else:
                        opt = Event.from_dict({
                            "event_name": event_name,
                            "listener_func": listener_func,
                            "args": [],
                            "plugins": None
                        })
                        self.dict_events[event_name].append(opt)
                elif (isinstance(plugins, Command) or isinstance(plugins, Contains) or isinstance(plugins, BeforeTimestamp) or isinstance(plugins, AfterTimestamp) or isinstance(plugins, Equals) or isinstance(plugins, isPrivate) or isinstance(plugins, isGroup) or isinstance(plugins, isChannel) or isinstance(plugins, isUnknown) or isinstance(plugins, isReply) or isinstance(plugins, isForwarded) or isinstance(plugins, isNumber) or isinstance(plugins, isEmoji) or isinstance(plugins, hasBold) or isinstance(plugins, hasItalic) or isinstance(plugins, hasMono) or isinstance(plugins, hasUnderline) or isinstance(plugins, hasSpoiler) or isinstance(plugins, hasStrike) or isinstance(plugins, hasLink) or isinstance(plugins, hasMentionText) or isinstance(plugins, hasPre) or isinstance(plugins, hasQuote) or isinstance(plugins, hasEmoji) or isinstance(plugins, hasLang)):
                    opt = Event.from_dict({
                        "event_name": event_name,
                        "listener_func": listener_func,
                        "args": [],
                        "plugins": (plugins[0],)
                    })
                    self.dict_events[event_name].append(opt)
            @wraps(listener_func)
            async def wrapper(*args, **kwargs):
                return await listener_func(*args, **kwargs)
            return wrapper
        return decorator

    async def emit(self, event_name: str, *args, **kwargs):
        if event_name in self.dict_events:
            for ev in self.dict_events[event_name]:
                if ev.listener_func:
                    if asyncio.iscoroutinefunction(ev.listener_func):
                        await ev.listener_func(*args, **kwargs)

    async def get_event(self, event_name: Literal['UpdatedMessage', 'NewMessage', 'RemovedMessage', 'StartedBot', 'StoppedBot']) -> List[Event]:
        if event_name in self.dict_events:
            return self.dict_events[event_name]
        else:return []

