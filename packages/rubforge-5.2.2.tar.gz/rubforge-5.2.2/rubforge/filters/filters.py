from dataclasses import dataclass
from typing import Union, Literal
import sys

dataclass_items = {}

if sys.version_info >= (3, 10):
    dataclass_items['slots'] = True

@dataclass(**dataclass_items)
class Command(object):
    text: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Command":
        return cls(text=data.get("text"))
    
    def to_dict(self) -> dict:
        return { "text": self.text }

@dataclass(**dataclass_items)
class Contains(object):
    text: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Contains":
        return cls(text=data.get("text"))
    
    def to_dict(self) -> dict:
        return { "text": self.text }

    def isContains(self, container: str) -> bool:
        if self.text:
            return self.text in container
        else:
            return False

@dataclass(**dataclass_items)
class BeforeTimestamp(object):
    timestamp: Union[float, int, None] = None
    is_equal: Union[bool, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "BeforeTimestamp":
        return cls(timestamp=data.get("timestamp"), is_equal=data.get("is_equal"))
    
    def to_dict(self) -> dict:
        return { "timestamp": self.timestamp, "is_equal": self.is_equal }
    
    def isBefore(self, timestamp: Union[float, int]) -> bool:
        if self.timestamp:
            if not self.is_equal:
                return self.timestamp < timestamp
            else:
                return self.timestamp <= timestamp
        else:
            return False

@dataclass(**dataclass_items)
class AfterTimestamp(object):
    timestamp: Union[float, int, None] = None
    is_equal: Union[bool, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AfterTimestamp":
        return cls(timestamp=data.get("timestamp"), is_equal=data.get("is_equal"))
    
    def to_dict(self) -> dict:
        return { "timestamp": self.timestamp, "is_equal": self.is_equal }
    
    def isAfter(self, timestamp: Union[float, int]) -> bool:
        if self.timestamp:
            if not self.is_equal:
                return self.timestamp > timestamp
            else:
                return self.timestamp >= timestamp
        else:
            return False

@dataclass(**dataclass_items)
class Equals(object):
    text: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Equals":
        return cls(text=data.get("text"))
    
    def to_dict(self) -> dict:
        return { "text": self.text }
    
    def is_equal(self, new_text: str):
        if self.text:
            return self.text == new_text
        else:
            return False

@dataclass(**dataclass_items)
class isPrivate(object):...

@dataclass(**dataclass_items)
class isGroup(object):...

@dataclass(**dataclass_items)
class isChannel(object):...

@dataclass(**dataclass_items)
class isUnknown(object):...

@dataclass(**dataclass_items)
class isReply(object):...

@dataclass(**dataclass_items)
class isForwarded(object):...

@dataclass(**dataclass_items)
class isEmoji(object):...

@dataclass(**dataclass_items)
class isNumber(object):...

@dataclass(**dataclass_items)
class hasBold(object):...

@dataclass(**dataclass_items)
class hasItalic(object):...

@dataclass(**dataclass_items)
class hasMono(object):...

@dataclass(**dataclass_items)
class hasUnderline(object):...

@dataclass(**dataclass_items)
class hasStrike(object):...

@dataclass(**dataclass_items)
class hasSpoiler(object):...

@dataclass(**dataclass_items)
class hasLink(object):...

@dataclass(**dataclass_items)
class hasMentionText(object):...

@dataclass(**dataclass_items)
class hasPre(object):...

@dataclass(**dataclass_items)
class hasQuote(object):...

@dataclass(**dataclass_items)
class hasEmoji(object):...

@dataclass(**dataclass_items)
class hasLang(object):
    want_languages: Union[tuple[str, ...], None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "hasLang":
        return cls(
            want_languages=data.get("want_languages")
        )
    
    def to_dict(self) -> dict:
        return {
            "want_languages": self.want_languages
        }

class filters(object):
    GROUP = Literal['group']
    CHANNEL = Literal['channel']
    PRIVATE = Literal['private']
    UNKNOWN = Literal['unknown']

    @classmethod
    def command(cls, pre: str) -> Command:
        return Command(pre)

    @classmethod
    def contains(cls, text: str) -> Contains:
        return Contains(text)

    @classmethod
    def before_timestamp(cls, timestamp: Union[float, int], is_equal: bool = False) -> BeforeTimestamp:
        return BeforeTimestamp(timestamp, is_equal)

    @classmethod
    def after_timestamp(cls, timestamp: Union[float, int], is_equal: bool = False) -> AfterTimestamp:
        return AfterTimestamp(timestamp, is_equal)
    
    @classmethod
    def equals(cls, text: str):
        return Equals(text)

    @classmethod
    def is_private(cls):
        return isPrivate()
    
    @classmethod
    def is_group(cls):
        return isGroup()
    
    @classmethod
    def is_channel(cls):
        return isChannel()

    @classmethod
    def is_unknown(cls):
        return isUnknown()

    @classmethod
    def is_reply(cls):
        return isReply()
    
    @classmethod
    def is_forwarded(cls):
        return isForwarded()
    
    @classmethod
    def is_emoji(cls):
        return isEmoji()
    
    @classmethod
    def is_number(cls):
        return isNumber()

    @classmethod
    def has_bold(cls):
        return hasBold()
    
    @classmethod
    def has_italic(cls):
        return hasItalic()
    
    @classmethod
    def has_mono(cls):
        return hasMono()
    
    @classmethod
    def has_underline(cls):
        return hasUnderline()
    
    @classmethod
    def has_strike(cls):
        return hasStrike()
    
    @classmethod
    def has_spoiler(cls):
        return hasSpoiler()
    
    @classmethod
    def has_link(cls):
        return hasLink()
    
    @classmethod
    def has_mention_text(cls):
        return hasMentionText()
    
    @classmethod
    def has_pre(cls):
        return hasPre()
    
    @classmethod
    def has_quote(cls):
        return hasQuote()

    @classmethod
    def has_emoji(cls):
        return hasEmoji()

    @classmethod
    def has_lang(cls, *want_languages: str):
        return hasLang(want_languages)
