#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for b4 threading and series detection."""

import pytest

from bitbake_project.commands.b4 import (
    LoreResult,
    group_into_threads,
    _thread_key,
    _parse_series_tag,
    _detect_branch_hint,
    _extract_subject_tokens,
    detect_mail_reader,
)


def _lr(subject, msgid="test@example.com", author="Test", date="2025-01-01",
         url="https://lore.kernel.org/all/test@example.com/"):
    """Helper to create a LoreResult with defaults."""
    return LoreResult(msgid=msgid, subject=subject, author=author,
                      date=date, url=url)


class TestThreadKey:
    """Tests for _thread_key() normalization."""

    def test_plain_subject(self):
        assert _thread_key("Fix memory leak") == "fix memory leak"

    def test_strip_re(self):
        assert _thread_key("Re: Fix memory leak") == "fix memory leak"

    def test_strip_double_re(self):
        assert _thread_key("Re: Re: Fix memory leak") == "fix memory leak"

    def test_strip_fwd(self):
        assert _thread_key("Fwd: Fix memory leak") == "fix memory leak"

    def test_strip_patch_bracket(self):
        assert _thread_key("[PATCH] Fix memory leak") == "fix memory leak"

    def test_strip_patch_series_bracket(self):
        assert _thread_key("[PATCH v2 3/5] Fix memory leak") == "fix memory leak"

    def test_strip_multiple_brackets(self):
        assert _thread_key("[PATCH 2/3][OE-core] Fix build") == "fix build"

    def test_strip_re_and_bracket(self):
        assert _thread_key("Re: [PATCH] Fix memory leak") == "fix memory leak"

    def test_case_insensitive(self):
        assert _thread_key("RE: Fix Leak") == "fix leak"


class TestParseSeriesTag:
    """Tests for _parse_series_tag()."""

    def test_no_tag(self):
        assert _parse_series_tag("Fix memory leak") == {}

    def test_simple_patch(self):
        result = _parse_series_tag("[PATCH] Fix memory leak")
        assert result["tag"] == "[PATCH]"
        assert "version" not in result
        assert "part" not in result

    def test_versioned(self):
        result = _parse_series_tag("[PATCH v2] Fix memory leak")
        assert result["version"] == 2
        assert "part" not in result

    def test_series_part(self):
        result = _parse_series_tag("[PATCH 3/5] Fix memory leak")
        assert result["part"] == 3
        assert result["total"] == 5

    def test_versioned_series(self):
        result = _parse_series_tag("[PATCH v3 2/7] Fix memory leak")
        assert result["version"] == 3
        assert result["part"] == 2
        assert result["total"] == 7

    def test_cover_letter(self):
        result = _parse_series_tag("[PATCH v2 0/3] Series title")
        assert result["version"] == 2
        assert result["part"] == 0
        assert result["total"] == 3

    def test_rfc_patch(self):
        result = _parse_series_tag("[RFC PATCH v1 1/2] Experimental change")
        assert result["version"] == 1
        assert result["part"] == 1
        assert result["total"] == 2

    def test_rfc_patch_no_version(self):
        result = _parse_series_tag("[RFC PATCH 0/2] Cover letter")
        assert result["part"] == 0
        assert result["total"] == 2


class TestGroupIntoThreads:
    """Tests for group_into_threads()."""

    def test_empty_input(self):
        assert group_into_threads([]) == []

    def test_single_message(self):
        results = [_lr("Fix memory leak")]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["root"].subject == "Fix memory leak"
        assert groups[0]["children"] == []
        assert groups[0]["series_tag"] is None

    def test_two_unrelated_messages(self):
        results = [
            _lr("Fix memory leak", msgid="1@ex"),
            _lr("Add new feature", msgid="2@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 2

    def test_reply_grouped_under_root(self):
        results = [
            _lr("[PATCH] Fix memory leak", msgid="1@ex"),
            _lr("Re: [PATCH] Fix memory leak", msgid="2@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["root"].msgid == "1@ex"
        assert len(groups[0]["children"]) == 1
        assert groups[0]["children"][0].msgid == "2@ex"

    def test_multi_part_series_different_subjects(self):
        """Real-world series: each patch has a different subject."""
        results = [
            _lr("[PATCH 0/3] Improve performance", msgid="cover@ex"),
            _lr("[PATCH 1/3] Fix memory leak in parser", msgid="1@ex"),
            _lr("[PATCH 2/3] Add bounds checking to allocator", msgid="2@ex"),
            _lr("[PATCH 3/3] Update tests for memory handling", msgid="3@ex"),
        ]
        groups = group_into_threads(results)
        # All 4 should be merged into one series group via Phase B
        assert len(groups) == 1
        assert groups[0]["total_parts"] == 3
        assert groups[0]["received_parts"] == 3
        assert groups[0]["root"].msgid == "cover@ex"
        assert len(groups[0]["children"]) == 3

    def test_series_same_base_subject(self):
        """Multi-part series with identical base subject after stripping."""
        results = [
            _lr("[PATCH v2 0/3] Fix build issues", msgid="cover@ex"),
            _lr("[PATCH v2 1/3] Fix build issues", msgid="1@ex"),
            _lr("[PATCH v2 2/3] Fix build issues", msgid="2@ex"),
            _lr("[PATCH v2 3/3] Fix build issues", msgid="3@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["version"] == 2
        assert groups[0]["total_parts"] == 3
        assert groups[0]["received_parts"] == 3
        # Cover letter (0/3) should be root
        assert groups[0]["root"].msgid == "cover@ex"

    def test_partial_series(self):
        """Incomplete series should be detected."""
        results = [
            _lr("[PATCH v1 1/4] Fix build issues", msgid="1@ex"),
            _lr("[PATCH v1 3/4] Fix build issues", msgid="3@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["total_parts"] == 4
        assert groups[0]["received_parts"] == 2

    def test_partial_series_different_subjects(self):
        """Incomplete series with different subjects should merge."""
        results = [
            _lr("[PATCH v1 1/4] Fix parser", msgid="1@ex"),
            _lr("[PATCH v1 3/4] Fix allocator", msgid="3@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["total_parts"] == 4
        assert groups[0]["received_parts"] == 2

    def test_two_series_different_authors_not_merged(self):
        """Series from different authors should stay separate."""
        results = [
            _lr("[PATCH 1/2] Fix A", msgid="1@ex", author="Alice"),
            _lr("[PATCH 2/2] Fix B", msgid="2@ex", author="Alice"),
            _lr("[PATCH 1/2] Fix X", msgid="3@ex", author="Bob"),
            _lr("[PATCH 2/2] Fix Y", msgid="4@ex", author="Bob"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 2
        authors = {g["root"].author for g in groups}
        assert authors == {"Alice", "Bob"}

    def test_two_series_different_versions_same_subject(self):
        """v1 and v2 with same subject all group together."""
        results = [
            _lr("[PATCH v1 1/2] Fix build", msgid="1@ex"),
            _lr("[PATCH v1 2/2] Fix test", msgid="2@ex"),
            _lr("[PATCH v2 1/2] Fix build", msgid="3@ex"),
            _lr("[PATCH v2 2/2] Fix test", msgid="4@ex"),
        ]
        groups = group_into_threads(results)
        # All related patches group together: same subjects and same series
        assert len(groups) == 1
        assert len(groups[0]["children"]) == 3

    def test_series_children_sorted_by_part(self):
        """Children should be sorted by patch number."""
        results = [
            _lr("[PATCH 3/3] Third", msgid="3@ex"),
            _lr("[PATCH 1/3] First", msgid="1@ex"),
            _lr("[PATCH 2/3] Second", msgid="2@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        # Root should be the lowest part (1/3 since no cover letter)
        assert groups[0]["root"].msgid == "1@ex"
        assert [c.msgid for c in groups[0]["children"]] == ["2@ex", "3@ex"]

    def test_versioned_series_detection(self):
        results = [_lr("[PATCH v3 1/2] Add feature", msgid="1@ex")]
        groups = group_into_threads(results)
        assert groups[0]["version"] == 3
        assert groups[0]["series_tag"] == "[PATCH v3 1/2]"

    def test_mixed_threads(self):
        """Different threads don't get merged."""
        results = [
            _lr("[PATCH] Fix memory leak", msgid="1@ex"),
            _lr("[PATCH] Add new feature", msgid="2@ex"),
            _lr("Re: [PATCH] Fix memory leak", msgid="3@ex"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 2
        # First group: Fix memory leak + its reply
        fix_group = [g for g in groups if "memory" in g["root"].subject.lower()][0]
        assert len(fix_group["children"]) == 1
        # Second group: Add new feature (standalone)
        add_group = [g for g in groups if "feature" in g["root"].subject.lower()][0]
        assert len(add_group["children"]) == 0

    def test_series_badge_info(self):
        """Complete series should have all badge info."""
        results = [
            _lr("[PATCH v2 0/2] Refactor parser", msgid="0@ex"),
            _lr("[PATCH v2 1/2] Refactor parser", msgid="1@ex"),
            _lr("[PATCH v2 2/2] Refactor parser", msgid="2@ex"),
        ]
        groups = group_into_threads(results)
        g = groups[0]
        assert g["version"] == 2
        assert g["total_parts"] == 2
        assert g["received_parts"] == 2
        assert g["series_tag"] is not None


    def test_replies_not_treated_as_series_patches(self):
        """Review replies should not be merged as series patches."""
        results = [
            _lr("[PATCH 1/3] Fix parser", msgid="1@ex", author="Alice"),
            _lr("Re: [PATCH 1/3] Fix parser", msgid="r1@ex", author="Bob"),
            _lr("[PATCH 2/3] Fix allocator", msgid="2@ex", author="Alice"),
            _lr("[PATCH 3/3] Fix tests", msgid="3@ex", author="Alice"),
        ]
        groups = group_into_threads(results)
        # All Alice's patches should be in one group, Bob's reply included
        assert len(groups) == 1
        assert groups[0]["root"].author == "Alice"
        assert groups[0]["received_parts"] == 3

    def test_reply_not_chosen_as_root(self):
        """A reply with [PATCH 0/N] tag should not become root."""
        results = [
            _lr("Re: [PATCH 0/2] Series cover", msgid="r1@ex", author="Bob"),
            _lr("[PATCH 0/2] Series cover", msgid="cover@ex", author="Alice"),
            _lr("[PATCH 1/2] Fix thing", msgid="1@ex", author="Alice"),
        ]
        groups = group_into_threads(results)
        assert len(groups) == 1
        assert groups[0]["root"].msgid == "cover@ex"


class TestExtractSubjectTokens:
    """Tests for _extract_subject_tokens()."""

    def test_no_brackets(self):
        assert _extract_subject_tokens("Fix memory leak") == []

    def test_single_tag(self):
        assert _extract_subject_tokens("[PATCH] Fix") == ["PATCH"]

    def test_multiple_tags(self):
        tokens = _extract_subject_tokens("[PATCH v2][scarthgap][OE-core] Fix")
        assert "PATCH" in tokens
        assert "v2" in tokens
        assert "scarthgap" in tokens
        assert "OE-core" in tokens

    def test_series_tag(self):
        tokens = _extract_subject_tokens("[PATCH v2 1/3] Fix")
        assert "PATCH" in tokens
        assert "v2" in tokens
        assert "1/3" in tokens


class TestDetectBranchHint:
    """Tests for _detect_branch_hint() with real branch matching."""

    BRANCHES = ["master", "scarthgap", "kirkstone", "dunfell", "styhead"]

    def test_no_brackets(self):
        assert _detect_branch_hint("Fix memory leak", self.BRANCHES) is None

    def test_patch_only(self):
        assert _detect_branch_hint("[PATCH] Fix memory leak", self.BRANCHES) is None

    def test_patch_versioned(self):
        assert _detect_branch_hint("[PATCH v2 1/3] Fix memory leak", self.BRANCHES) is None

    def test_scarthgap(self):
        assert _detect_branch_hint("[PATCH][scarthgap] Fix build", self.BRANCHES) == "scarthgap"

    def test_kirkstone(self):
        assert _detect_branch_hint("[PATCH v2 1/3][kirkstone] Fix", self.BRANCHES) == "kirkstone"

    def test_branch_before_patch(self):
        assert _detect_branch_hint("[styhead][PATCH] Fix build", self.BRANCHES) == "styhead"

    def test_oe_core_and_branch(self):
        assert _detect_branch_hint("[OE-core][styhead][PATCH] Fix", self.BRANCHES) == "styhead"

    def test_rfc_patch_with_branch(self):
        assert _detect_branch_hint("[RFC PATCH][dunfell] Experimental", self.BRANCHES) == "dunfell"

    def test_master_branch(self):
        assert _detect_branch_hint("[PATCH][master] Fix build", self.BRANCHES) == "master"

    def test_case_insensitive(self):
        assert _detect_branch_hint("[PATCH][Scarthgap] Fix", self.BRANCHES) == "scarthgap"

    def test_no_match_without_branches(self):
        assert _detect_branch_hint("[PATCH][scarthgap] Fix", []) is None

    def test_no_match_wrong_branches(self):
        assert _detect_branch_hint("[PATCH][scarthgap] Fix", ["main", "develop"]) is None

    def test_custom_branch(self):
        """Works with any repo — not hardcoded to Yocto branches."""
        assert _detect_branch_hint("[PATCH][feature-xyz] Fix", ["main", "feature-xyz"]) == "feature-xyz"

    def test_subject_tags_in_group_data(self):
        """Subject tags should appear in group_into_threads output."""
        results = [_lr("[PATCH][scarthgap] Fix build")]
        groups = group_into_threads(results)
        assert "scarthgap" in groups[0]["subject_tags"]

    def test_no_extra_tags_in_group_data(self):
        results = [_lr("[PATCH] Fix build")]
        groups = group_into_threads(results)
        assert "PATCH" in groups[0]["subject_tags"]


class TestDetectMailReader:
    """Tests for detect_mail_reader()."""

    def test_returns_string_or_none(self):
        result = detect_mail_reader()
        assert result is None or isinstance(result, str)
