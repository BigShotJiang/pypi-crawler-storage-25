#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for shared tmux helpers (bitbake_project.tmux)."""

import json

import pytest

from bitbake_project.tmux import (
    tmux_session_name,
    get_tmux_prefix,
    set_tmux_prefix,
    tmux_attach_cmd,
)


class TestTmuxSessionName:
    """Tests for tmux_session_name."""

    def test_simple_path(self):
        assert tmux_session_name("/home/bruce/yocto-build") == "bit-yocto-build"

    def test_trailing_slash(self):
        assert tmux_session_name("/opt/poky/") == "bit-poky"

    def test_special_chars(self):
        assert tmux_session_name("/opt/my project.v2") == "bit-my-project-v2"

    def test_underscores_preserved(self):
        assert tmux_session_name("/opt/my_build") == "bit-my_build"

    def test_hyphens_preserved(self):
        assert tmux_session_name("/opt/yocto-kirkstone") == "bit-yocto-kirkstone"


class TestTmuxPrefixConfig:
    """Tests for get_tmux_prefix / set_tmux_prefix."""

    def test_default_prefix(self, tmp_path, monkeypatch):
        monkeypatch.setattr("bitbake_project.tmux._BIT_CONFIG_DIR", str(tmp_path))
        assert get_tmux_prefix() == "C-a"

    def test_set_and_get(self, tmp_path, monkeypatch):
        monkeypatch.setattr("bitbake_project.tmux._BIT_CONFIG_DIR", str(tmp_path))
        set_tmux_prefix("C-s")
        assert get_tmux_prefix() == "C-s"

    def test_preserves_other_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr("bitbake_project.tmux._BIT_CONFIG_DIR", str(tmp_path))
        config_file = tmp_path / "projects.json"
        config_file.write_text(json.dumps({"__other_key__": "value"}))
        set_tmux_prefix("C-a")
        data = json.loads(config_file.read_text())
        assert data["__other_key__"] == "value"
        assert data["__tmux_prefix__"] == "C-a"

    def test_reads_from_existing_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr("bitbake_project.tmux._BIT_CONFIG_DIR", str(tmp_path))
        config_file = tmp_path / "projects.json"
        config_file.write_text(json.dumps({"__tmux_prefix__": "C-q"}))
        assert get_tmux_prefix() == "C-q"


class TestTmuxAttachCmd:
    """Tests for tmux_attach_cmd."""

    def test_returns_list(self):
        cmd = tmux_attach_cmd("bit-poky")
        assert isinstance(cmd, list)
        assert cmd[0] == "bash"
        assert cmd[1] == "-c"

    def test_contains_attach_and_new(self):
        cmd = tmux_attach_cmd("bit-poky")
        shell = cmd[2]
        assert "tmux attach-session -t" in shell
        assert "tmux new-session -s" in shell
        assert "bit-poky" in shell

    def test_has_session_check(self):
        cmd = tmux_attach_cmd("bit-poky")
        shell = cmd[2]
        assert "tmux has-session -t" in shell

    def test_cwd_in_new_session(self):
        cmd = tmux_attach_cmd("bit-poky", cwd="/opt/poky")
        shell = cmd[2]
        assert "-c" in shell
        assert "/opt/poky" in shell

    def test_no_cwd_without_arg(self):
        cmd = tmux_attach_cmd("bit-poky")
        shell = cmd[2]
        # The -c flag for cwd should not appear when no cwd given
        # (the new-session part should not have -c)
        new_part = shell.split("else")[1]
        assert " -c " not in new_part

    def test_prefix_sets_option(self):
        cmd = tmux_attach_cmd("bit-poky", prefix="C-a")
        shell = cmd[2]
        assert "set-option" in shell
        assert "C-a" in shell
        # With prefix: new session should be detached
        assert "new-session -d" in shell

    def test_no_prefix_no_set_option(self):
        cmd = tmux_attach_cmd("bit-poky")
        shell = cmd[2]
        assert "set-option" not in shell
