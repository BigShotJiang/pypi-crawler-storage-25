#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for tags and pane helpers."""

import json
import os

import pytest

from bitbake_project.tags import (
    get_effective_tags,
    matches_pane,
    all_tags,
    load_panes,
    save_panes,
    get_active_pane,
    set_active_pane,
    find_pane,
    create_or_update_pane,
    rename_pane,
    delete_pane,
    set_project_tags,
    get_project_tags,
    set_project_hidden_tags,
    get_project_hidden_tags,
    get_project_remote_tags,
    _DEFAULT_PANES,
)


# ---------------------------------------------------------------------------
# get_effective_tags
# ---------------------------------------------------------------------------

class TestGetEffectiveTags:
    def test_persona_only(self):
        info = {"persona": "yocto"}
        assert get_effective_tags(info) == {"yocto"}

    def test_default_persona(self):
        """No persona key defaults to 'yocto'."""
        assert get_effective_tags({}) == {"yocto"}

    def test_explicit_tags_plus_persona(self):
        info = {"persona": "generic", "tags": ["bsp", "ci"]}
        assert get_effective_tags(info) == {"generic", "bsp", "ci"}

    def test_explicit_tags_without_persona(self):
        info = {"tags": ["test"]}
        assert get_effective_tags(info) == {"yocto", "test"}

    def test_empty_tags_list(self):
        info = {"persona": "yocto", "tags": []}
        assert get_effective_tags(info) == {"yocto"}

    def test_remote_tags_included(self):
        info = {"remote_tags": ["bsp", "ci"], "persona": "yocto"}
        assert get_effective_tags(info) == {"yocto", "bsp", "ci"}

    def test_hidden_tags_excluded(self):
        info = {"remote_tags": ["bsp", "ci", "stable"],
                "hidden_tags": ["stable"],
                "persona": "yocto"}
        assert get_effective_tags(info) == {"yocto", "bsp", "ci"}

    def test_hidden_does_not_affect_local(self):
        """Hiding a tag that also exists in local tags doesn't remove it."""
        info = {"remote_tags": ["bsp"], "tags": ["bsp"],
                "hidden_tags": ["bsp"], "persona": "yocto"}
        assert "bsp" in get_effective_tags(info)

    def test_remote_persona_fallback(self):
        info = {"remote_persona": "generic"}
        assert "generic" in get_effective_tags(info)
        assert "yocto" not in get_effective_tags(info)

    def test_local_persona_overrides_remote(self):
        info = {"persona": "yocto", "remote_persona": "generic"}
        assert "yocto" in get_effective_tags(info)
        assert "generic" not in get_effective_tags(info)

    def test_backward_compat_no_remote_fields(self):
        """Projects without remote fields still work as before."""
        info = {"persona": "generic", "tags": ["ci"]}
        assert get_effective_tags(info) == {"generic", "ci"}


# ---------------------------------------------------------------------------
# matches_pane
# ---------------------------------------------------------------------------

class TestMatchesPane:
    def test_all_pane_matches_everything(self):
        assert matches_pane({"persona": "yocto"}, {"name": "All", "tags": []})
        assert matches_pane({"persona": "generic"}, {"name": "All", "tags": []})

    def test_persona_pane(self):
        assert matches_pane({"persona": "yocto"}, {"name": "Yocto", "tags": ["yocto"]})
        assert not matches_pane({"persona": "generic"}, {"name": "Yocto", "tags": ["yocto"]})

    def test_tag_intersection(self):
        info = {"persona": "yocto", "tags": ["bsp"]}
        assert matches_pane(info, {"name": "BSP", "tags": ["bsp"]})
        assert not matches_pane(info, {"name": "CI", "tags": ["ci"]})

    def test_or_logic(self):
        """Project matches if ANY pane tag matches."""
        info = {"persona": "yocto", "tags": ["bsp"]}
        assert matches_pane(info, {"name": "Mix", "tags": ["ci", "bsp"]})


# ---------------------------------------------------------------------------
# all_tags
# ---------------------------------------------------------------------------

class TestAllTags:
    def test_collects_all(self):
        projects = {
            "/a": {"persona": "yocto", "tags": ["bsp"]},
            "/b": {"persona": "generic", "tags": ["ci"]},
            "/c": {"persona": "yocto"},
        }
        assert all_tags(projects) == {"yocto", "generic", "bsp", "ci"}

    def test_includes_remote_tags(self):
        projects = {
            "/a": {"persona": "yocto", "remote_tags": ["hw", "stable"]},
        }
        tags = all_tags(projects)
        assert "hw" in tags
        assert "stable" in tags

    def test_includes_hidden_remote_tags(self):
        """Hidden remote tags still appear in the pool for autocomplete."""
        projects = {
            "/a": {"persona": "yocto",
                   "remote_tags": ["hw", "stable"],
                   "hidden_tags": ["stable"]},
        }
        tags = all_tags(projects)
        assert "stable" in tags


# ---------------------------------------------------------------------------
# Pane storage (uses tmp file)
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _patch_projects_file(tmp_path, monkeypatch):
    """Redirect projects.json to a temp dir for all tests in this module."""
    pf = str(tmp_path / "projects.json")
    monkeypatch.setattr("bitbake_project.tags._get_projects_file", lambda: pf)
    return pf


class TestPaneStorage:
    def test_defaults_when_empty(self):
        panes = load_panes()
        assert len(panes) == 3
        assert panes[0]["name"] == "All"

    def test_save_and_load(self):
        custom = [{"name": "X", "tags": ["x"]}]
        save_panes(custom)
        assert load_panes() == custom

    def test_active_pane_default(self):
        assert get_active_pane() == "All"

    def test_set_active_pane(self):
        set_active_pane("Yocto")
        assert get_active_pane() == "Yocto"

    def test_find_pane(self):
        save_panes(list(_DEFAULT_PANES))
        assert find_pane("Yocto")["tags"] == ["yocto"]
        assert find_pane("Nonexistent") is None


class TestPaneCRUD:
    def test_create(self):
        panes = create_or_update_pane("BSP", ["bsp"])
        assert any(p["name"] == "BSP" for p in panes)
        assert load_panes()[-1]["name"] == "BSP"

    def test_update_existing(self):
        create_or_update_pane("BSP", ["bsp"])
        panes = create_or_update_pane("BSP", ["bsp", "hw"])
        bsp = [p for p in panes if p["name"] == "BSP"][0]
        assert bsp["tags"] == ["bsp", "hw"]

    def test_delete(self):
        create_or_update_pane("Temp", ["temp"])
        panes = delete_pane("Temp")
        assert not any(p["name"] == "Temp" for p in panes)

    def test_delete_builtin_raises(self):
        save_panes(list(_DEFAULT_PANES))
        with pytest.raises(ValueError, match="built-in"):
            delete_pane("All")

    def test_delete_not_found_raises(self):
        with pytest.raises(ValueError, match="not found"):
            delete_pane("Nope")

    def test_delete_active_resets(self, _patch_projects_file):
        create_or_update_pane("Temp", ["temp"])
        set_active_pane("Temp")
        delete_pane("Temp")
        assert get_active_pane() == "All"

    def test_rename(self):
        create_or_update_pane("Old", ["x"])
        panes = rename_pane("Old", "New")
        assert any(p["name"] == "New" for p in panes)
        assert not any(p["name"] == "Old" for p in panes)

    def test_rename_updates_active(self):
        create_or_update_pane("Mine", ["m"])
        set_active_pane("Mine")
        rename_pane("Mine", "Yours")
        assert get_active_pane() == "Yours"

    def test_rename_builtin_raises(self):
        save_panes(list(_DEFAULT_PANES))
        with pytest.raises(ValueError, match="built-in"):
            rename_pane("All", "Everything")

    def test_rename_collision_raises(self):
        save_panes(list(_DEFAULT_PANES))
        create_or_update_pane("Custom", ["c"])
        with pytest.raises(ValueError, match="already exists"):
            rename_pane("Custom", "All")

    def test_rename_not_found_raises(self):
        with pytest.raises(ValueError, match="not found"):
            rename_pane("Ghost", "Real")


# ---------------------------------------------------------------------------
# Project tag CRUD
# ---------------------------------------------------------------------------

class TestProjectTags:
    def test_set_and_get(self, _patch_projects_file):
        pf = _patch_projects_file
        # Seed a project entry
        with open(pf, "w") as f:
            json.dump({"/proj": {"name": "proj", "persona": "yocto"}}, f)
        set_project_tags("/proj", ["bsp", "ci"])
        assert get_project_tags("/proj") == ["bsp", "ci"]

    def test_get_empty(self, _patch_projects_file):
        assert get_project_tags("/missing") == []

    def test_set_missing_project_raises(self):
        with pytest.raises(KeyError):
            set_project_tags("/no-such", ["x"])

    def test_set_and_get_hidden_tags(self, _patch_projects_file):
        pf = _patch_projects_file
        with open(pf, "w") as f:
            json.dump({"/proj": {"name": "proj", "remote_tags": ["bsp", "ci"]}}, f)
        set_project_hidden_tags("/proj", ["ci"])
        assert get_project_hidden_tags("/proj") == ["ci"]

    def test_get_hidden_tags_empty(self):
        assert get_project_hidden_tags("/missing") == []

    def test_set_hidden_tags_missing_raises(self):
        with pytest.raises(KeyError):
            set_project_hidden_tags("/no-such", ["x"])

    def test_get_remote_tags(self, _patch_projects_file):
        pf = _patch_projects_file
        with open(pf, "w") as f:
            json.dump({"/proj": {"name": "proj", "remote_tags": ["bsp", "ci"]}}, f)
        assert get_project_remote_tags("/proj") == ["bsp", "ci"]

    def test_get_remote_tags_empty(self):
        assert get_project_remote_tags("/missing") == []
