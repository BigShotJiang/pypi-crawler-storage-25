#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Auto-update daemon — background thread for periodic fetch/update of projects.

Runs inside ``bit serve`` as a daemon thread.  Provides:
- ``RepoLock``: per-repo file locking (fcntl.flock + mkdir fallback)
- ``AutoUpdateDaemon``: periodic fetch/update thread
- Heartbeat and state file management
"""

import contextlib
import fcntl
import io
import json
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _config_dir() -> str:
    d = os.path.expanduser("~/.config/bit")
    os.makedirs(d, exist_ok=True)
    return d


def _locks_dir() -> str:
    d = os.path.join(_config_dir(), "locks")
    os.makedirs(d, exist_ok=True)
    return d


def heartbeat_path() -> str:
    return os.path.join(_config_dir(), "daemon.heartbeat")


def state_path() -> str:
    return os.path.join(_config_dir(), "daemon.state.json")


# ---------------------------------------------------------------------------
# RepoLock — per-repo file locking
# ---------------------------------------------------------------------------

def _sanitize_path(repo_path: str) -> str:
    """Convert a repo path to a safe filename for lock files."""
    return repo_path.strip("/").replace("/", "_").replace(" ", "_")


class RepoLock:
    """Per-repo file lock using fcntl.flock() with mkdir fallback.

    Usage::

        lock = RepoLock("/path/to/repo")
        with lock:
            # exclusive access to repo
            ...

    Or non-blocking::

        if lock.acquire(blocking=False):
            try:
                ...
            finally:
                lock.release()
    """

    def __init__(self, repo_path: str, actor: str = "cli"):
        self.repo_path = repo_path
        self.actor = actor
        self._lock_file = os.path.join(_locks_dir(), _sanitize_path(repo_path) + ".lock")
        self._fd: Optional[int] = None
        self._acquired = False

    def acquire(self, blocking: bool = True, timeout: float = 10.0) -> bool:
        """Acquire the lock.  Returns True on success.

        *blocking=False*: try once, return False if locked.
        *blocking=True*: retry until *timeout* seconds elapse.
        """
        # Stale lock recovery: check if PID in lock file is dead
        self._recover_stale()

        try:
            self._fd = os.open(self._lock_file, os.O_CREAT | os.O_RDWR, 0o644)
        except OSError:
            return False

        if not blocking:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._write_lock_info()
                self._acquired = True
                return True
            except (OSError, BlockingIOError):
                os.close(self._fd)
                self._fd = None
                return False

        # Blocking with timeout
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._write_lock_info()
                self._acquired = True
                return True
            except (OSError, BlockingIOError):
                if time.monotonic() >= deadline:
                    os.close(self._fd)
                    self._fd = None
                    return False
                time.sleep(0.2)

    def release(self) -> None:
        """Release the lock."""
        if self._fd is not None:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_UN)
            except OSError:
                pass
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None
            self._acquired = False

    def _write_lock_info(self) -> None:
        """Write PID/actor info into the lock file."""
        if self._fd is None:
            return
        try:
            os.ftruncate(self._fd, 0)
            os.lseek(self._fd, 0, os.SEEK_SET)
            info = json.dumps({
                "pid": os.getpid(),
                "started": time.time(),
                "actor": self.actor,
            })
            os.write(self._fd, info.encode("utf-8"))
        except OSError:
            pass

    def _recover_stale(self) -> None:
        """If the lock file exists and the owning PID is dead, remove it."""
        try:
            with open(self._lock_file, "r") as f:
                data = json.load(f)
            pid = data.get("pid")
            if pid and not _pid_alive(pid):
                try:
                    os.unlink(self._lock_file)
                except OSError:
                    pass
        except (OSError, json.JSONDecodeError, KeyError):
            pass

    def __enter__(self):
        if not self.acquire():
            raise TimeoutError(f"Could not acquire lock for {self.repo_path}")
        return self

    def __exit__(self, *exc):
        self.release()
        return False

    @property
    def is_locked(self) -> bool:
        return self._acquired


def _pid_alive(pid: int) -> bool:
    """Check if a PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def get_lock_holder(repo_path: str) -> Optional[dict]:
    """Read lock info for a repo, or None if not locked / stale."""
    lock_file = os.path.join(_locks_dir(), _sanitize_path(repo_path) + ".lock")
    try:
        with open(lock_file, "r") as f:
            data = json.load(f)
        if data.get("pid") and _pid_alive(data["pid"]):
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return None


# ---------------------------------------------------------------------------
# Heartbeat
# ---------------------------------------------------------------------------

def write_heartbeat(projects_checked: int = 0, errors: int = 0) -> None:
    """Write daemon heartbeat file."""
    try:
        data = {
            "pid": os.getpid(),
            "timestamp": time.time(),
            "projects_checked": projects_checked,
            "errors": errors,
        }
        tmp = heartbeat_path() + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, heartbeat_path())
    except OSError:
        pass


def read_heartbeat() -> Optional[dict]:
    """Read daemon heartbeat.  Returns None if missing."""
    try:
        with open(heartbeat_path(), "r") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def check_daemon_health() -> dict:
    """Check daemon health from heartbeat file.

    Returns dict with keys:
    - status: "running" | "paused" | "stale" | "dead" | "not_configured"
    - detail: human-readable message
    - heartbeat: raw heartbeat data (if available)
    """
    hb = read_heartbeat()
    if hb is None:
        # Check if any projects are tagged for auto-update
        try:
            from .commands.projects import load_projects
            from .tags import get_effective_tags
            projects = load_projects()
            has_auto = any("auto-update" in get_effective_tags(info)
                           for info in projects.values())
        except Exception:
            has_auto = False
        if has_auto:
            return {"status": "stopped", "detail": "Server not running (auto-update projects exist)"}
        return {"status": "not_configured", "detail": "No projects tagged with auto-update"}

    pid = hb.get("pid")
    ts = hb.get("timestamp", 0)
    age = time.time() - ts

    if not pid or not _pid_alive(pid):
        return {
            "status": "dead",
            "detail": f"Daemon process (pid {pid}) is not running",
            "heartbeat": hb,
        }

    # Check if paused via state file
    st = load_state()
    if st.get("paused"):
        return {
            "status": "paused",
            "detail": "Daemon is paused",
            "heartbeat": hb,
        }

    if age > 120:  # >2 minutes stale
        return {
            "status": "stale",
            "detail": f"Heartbeat is {int(age)}s old — daemon thread may be stuck",
            "heartbeat": hb,
        }

    return {
        "status": "running",
        "detail": f"Daemon active (checked {hb.get('projects_checked', 0)} projects)",
        "heartbeat": hb,
    }


def remove_heartbeat() -> None:
    """Remove heartbeat file (on clean shutdown)."""
    try:
        os.unlink(heartbeat_path())
    except OSError:
        pass


# ---------------------------------------------------------------------------
# State file
# ---------------------------------------------------------------------------

def load_state() -> dict:
    """Load daemon state from disk."""
    try:
        with open(state_path(), "r") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def save_state(state: dict) -> None:
    """Write daemon state to disk (atomic replace)."""
    try:
        tmp = state_path() + ".tmp"
        with open(tmp, "w") as f:
            json.dump(state, f, indent=2)
        os.replace(tmp, state_path())
    except OSError:
        pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# AutoUpdateDaemon
# ---------------------------------------------------------------------------

_LOG_CAP = 500


class AutoUpdateDaemon(threading.Thread):
    """Background daemon thread that periodically fetches/updates projects.

    Starts as a daemon thread inside ``bit serve``.  Reads the
    ``auto-update`` tag from projects.json to decide which projects
    to process.
    """

    daemon = True

    def __init__(self, sse_manager=None):
        super().__init__(name="auto-update-daemon")
        self._stop_event = threading.Event()
        self._paused = False
        self._sse = sse_manager
        self._projects_checked = 0
        self._errors = 0

    # -- lifecycle -----------------------------------------------------------

    def run(self) -> None:
        # Initialise state file
        state = load_state()
        state.setdefault("started", _now_iso())
        state.setdefault("paused", False)
        state.setdefault("interval_minutes", self._global_interval())
        state.setdefault("projects", {})
        state.setdefault("log", [])
        self._paused = state.get("paused", False)
        save_state(state)

        first_tick = True
        while not self._stop_event.is_set():
            write_heartbeat(self._projects_checked, self._errors)
            if not self._paused:
                try:
                    self._tick(force=first_tick)
                    first_tick = False
                except Exception:
                    self._errors += 1
            self._stop_event.wait(30)

        # Clean shutdown
        remove_heartbeat()

    def stop(self) -> None:
        self._stop_event.set()

    def pause(self) -> None:
        self._paused = True
        state = load_state()
        state["paused"] = True
        save_state(state)
        self._broadcast("daemon_status", {"running": True, "paused": True})

    def resume(self) -> None:
        self._paused = False
        state = load_state()
        state["paused"] = False
        save_state(state)
        self._broadcast("daemon_status", {"running": True, "paused": False})

    # -- main loop -----------------------------------------------------------

    def _tick(self, force: bool = False) -> None:
        from .commands.projects import load_projects
        from .commands.ssh_remote import is_remote_project
        from .tags import get_effective_tags

        projects = load_projects()
        state = load_state()
        interval = state.get("interval_minutes", self._global_interval())

        active_count = 0
        for path, info in projects.items():
            if is_remote_project(info):
                continue
            if "auto-update" not in get_effective_tags(info):
                continue
            if not os.path.isdir(path):
                continue

            active_count += 1
            proj_state = state.get("projects", {}).get(path, {})
            proj_config = info.get("auto_update", {})
            proj_interval = proj_config.get("interval_minutes", interval)

            # Check if interval has elapsed since last daemon check OR
            # last actual git update (HEAD reflog) — whichever is more recent.
            # This avoids redundant updates if someone did a manual git pull.
            most_recent = 0.0
            last_check = proj_state.get("last_check")
            if last_check:
                try:
                    last_dt = datetime.fromisoformat(last_check)
                    most_recent = last_dt.timestamp()
                except (ValueError, TypeError):
                    pass
            # Also check HEAD reflog mtime across repos
            try:
                from .commands.projects import _get_project_git_repos
                for repo in _get_project_git_repos(path):
                    reflog = os.path.join(repo, ".git", "logs", "HEAD")
                    if os.path.isfile(reflog):
                        mt = os.path.getmtime(reflog)
                        if mt > most_recent:
                            most_recent = mt
            except Exception:
                pass
            if not force and most_recent > 0:
                elapsed = time.time() - most_recent
                if elapsed < proj_interval * 60:
                    continue

            self._update_project(path, info, state)
            self._projects_checked += 1

        # Broadcast daemon status
        self._broadcast("daemon_status", {
            "running": True,
            "paused": False,
            "projects_active": active_count,
        })

        save_state(state)

    def _update_project(self, path: str, info: dict, state: dict) -> None:
        """Fetch/update all repos in a project."""
        from .commands.common import collect_repos
        from .commands.projects import load_projects
        from .commands.update import fetch_repo, run_single_repo_update
        from .core import current_branch, load_defaults
        from .persona import get_persona

        proj_config = info.get("auto_update", {})
        fetch_only = proj_config.get("fetch_only", False)

        # Discover repos using the project's persona
        persona_name = info.get("persona", "yocto")
        try:
            persona = get_persona(persona_name)
        except Exception:
            persona = None

        defaults_file = os.path.join(path, ".bit.defaults")
        defaults = load_defaults(defaults_file) if os.path.isfile(defaults_file) else {}

        try:
            if persona and persona.name != "yocto":
                repos_list, _ = persona.collect_repos(None, defaults, include_external=False)
            else:
                # For yocto persona, we need a bblayers path
                bblayers = None
                for candidate in [
                    os.path.join(path, "conf", "bblayers.conf"),
                    os.path.join(path, "build", "conf", "bblayers.conf"),
                ]:
                    if os.path.isfile(candidate):
                        bblayers = candidate
                        break
                if not bblayers:
                    self._log_entry(state, path, None, "skip", "No bblayers.conf found")
                    return
                repos_list, _ = collect_repos(bblayers, defaults, include_external=False)
        except Exception as e:
            self._log_entry(state, path, None, "error", str(e))
            self._errors += 1
            return

        proj_state = state.setdefault("projects", {}).setdefault(path, {})
        repo_states = proj_state.setdefault("repos", {})

        for repo in repos_list:
            if defaults.get(repo, "rebase") == "skip":
                continue

            repo_name = os.path.basename(repo)
            lock = RepoLock(repo, actor="daemon")
            if not lock.acquire(blocking=False):
                self._log_entry(state, path, repo_name, "skipped", "Locked by another process")
                continue

            try:
                # Fetch
                ok = fetch_repo(repo)
                if not ok:
                    repo_states[repo_name] = {
                        "last_fetch": _now_iso(),
                        "result": "fetch_failed",
                        "commits": 0,
                    }
                    self._log_entry(state, path, repo_name, "error", "Fetch failed")
                    self._broadcast("daemon_error", {
                        "project": path, "repo": repo_name, "error": "Fetch failed",
                    })
                    self._errors += 1
                    continue

                # Check for upstream commits
                branch = current_branch(repo)
                if not branch:
                    repo_states[repo_name] = {
                        "last_fetch": _now_iso(),
                        "result": "no_branch",
                        "commits": 0,
                    }
                    continue

                from .commands.update import get_upstream_commits
                upstream = get_upstream_commits(repo, branch)
                commit_count = len(upstream)

                if commit_count == 0:
                    repo_states[repo_name] = {
                        "last_fetch": _now_iso(),
                        "result": "up-to-date",
                        "commits": 0,
                    }
                    continue

                if fetch_only:
                    repo_states[repo_name] = {
                        "last_fetch": _now_iso(),
                        "result": "pending",
                        "commits": commit_count,
                    }
                    self._log_entry(state, path, repo_name, "fetched",
                                    f"{commit_count} upstream commits (fetch_only)")
                    self._broadcast("daemon_update", {
                        "project": path, "repo": repo_name,
                        "action": "fetch", "result": "pending",
                        "commits": commit_count,
                    })
                    continue

                # Apply update using default action
                action = defaults.get(repo, "rebase")
                if action in ("skip", "custom") or action.startswith("custom:"):
                    action = "rebase"  # safe default for daemon

                with contextlib.redirect_stdout(io.StringIO()):
                    success = run_single_repo_update(repo, branch, action)

                result = "updated" if success else "update_failed"
                repo_states[repo_name] = {
                    "last_fetch": _now_iso(),
                    "result": result,
                    "commits": commit_count,
                }

                if success:
                    self._log_entry(state, path, repo_name, "updated",
                                    f"{action} {commit_count} commits")
                    self._broadcast("daemon_update", {
                        "project": path, "repo": repo_name,
                        "action": action, "result": "updated",
                        "commits": commit_count,
                    })
                else:
                    self._log_entry(state, path, repo_name, "error",
                                    f"{action} failed")
                    self._broadcast("daemon_error", {
                        "project": path, "repo": repo_name,
                        "error": f"{action} failed",
                    })
                    self._errors += 1

            finally:
                lock.release()

        # Update project-level state
        proj_state["last_check"] = _now_iso()
        interval = state.get("interval_minutes", self._global_interval())
        proj_interval = info.get("auto_update", {}).get("interval_minutes", interval)
        try:
            next_dt = datetime.now(timezone.utc).timestamp() + proj_interval * 60
            proj_state["next_check"] = datetime.fromtimestamp(
                next_dt, tz=timezone.utc
            ).isoformat(timespec="seconds")
        except Exception:
            pass

    # -- helpers -------------------------------------------------------------

    def _global_interval(self) -> int:
        """Read global default interval from projects.json __daemon__ key."""
        try:
            from .commands.projects import _get_projects_file
            pf = _get_projects_file()
            with open(pf, "r") as f:
                data = json.load(f)
            daemon_cfg = data.get("__daemon__", {})
            return daemon_cfg.get("interval_minutes", 60)
        except Exception:
            return 60

    def _log_entry(self, state: dict, project: str, repo: Optional[str],
                   action: str, detail: str) -> None:
        """Append a capped log entry to state."""
        log = state.setdefault("log", [])
        log.append({
            "timestamp": _now_iso(),
            "project": project,
            "repo": repo,
            "action": action,
            "detail": detail,
        })
        if len(log) > _LOG_CAP:
            state["log"] = log[-_LOG_CAP:]

    def _broadcast(self, event_type: str, data: dict) -> None:
        """Broadcast SSE event if manager is available."""
        if self._sse:
            try:
                self._sse.broadcast(event_type, data)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Daemon global interval config  (stored in projects.json __daemon__)
# ---------------------------------------------------------------------------

def get_daemon_interval() -> int:
    """Read global daemon interval from projects.json."""
    try:
        from .commands.projects import _get_projects_file
        pf = _get_projects_file()
        with open(pf, "r") as f:
            data = json.load(f)
        return data.get("__daemon__", {}).get("interval_minutes", 60)
    except Exception:
        return 60


def set_daemon_interval(minutes: int) -> None:
    """Write global daemon interval to projects.json."""
    from .commands.projects import _get_projects_file
    pf = _get_projects_file()
    try:
        with open(pf, "r") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        data = {}
    daemon_cfg = data.setdefault("__daemon__", {})
    daemon_cfg["interval_minutes"] = minutes
    with open(pf, "w") as f:
        json.dump(data, f, indent=2)
