#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""SSH remote project support — all SSH transport logic for remote projects."""

import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import textwrap
import time
from typing import Dict, List, Optional, Tuple


# --- URI parsing ---

_REMOTE_URI_RE = re.compile(r'^(?:([^@]+)@)?([^:]+):(.+)$')


def parse_remote_uri(uri: str) -> Optional[Tuple[str, str, str]]:
    """Parse ``user@host:/path`` into ``(user, host, path)`` or ``None``.

    The user part is optional; defaults to the current login user.
    """
    m = _REMOTE_URI_RE.match(uri.strip())
    if not m:
        return None
    user = m.group(1) or os.environ.get("USER", "")
    host = m.group(2)
    path = m.group(3)
    if not host or not path:
        return None
    return (user, host, path)


def format_remote_uri(user: str, host: str, path: str) -> str:
    """Build a ``user@host:/path`` URI string."""
    return f"{user}@{host}:{path}"


# --- SSH connection multiplexing ---
#
# ControlMaster=auto makes the first SSH connection the "master" and
# subsequent connections multiplex over the same TCP socket.  This means
# passphrase/password is only needed once per host.

def _ssh_mux_opts() -> List[str]:
    """Return SSH options for connection multiplexing.

    The first connection to a host becomes the master (may prompt for
    passphrase).  All later connections reuse it — no extra auth needed.
    The master stays alive for 10 minutes after the last client exits
    so it survives long interactive sessions (explore, dashboard).
    ServerAliveInterval detects dead connections within ~15 seconds.
    """
    ssh_dir = os.path.expanduser("~/.ssh")
    os.makedirs(ssh_dir, mode=0o700, exist_ok=True)
    return [
        "-o", f"ControlPath={ssh_dir}/bit-mux-%r@%h-%p",
        "-o", "ControlMaster=auto",
        "-o", "ControlPersist=600",
        "-o", "ServerAliveInterval=5",
        "-o", "ServerAliveCountMax=3",
    ]


def _ssh_no_prompt_env() -> dict:
    """Return env dict that suppresses interactive SSH password prompts.

    Prevents ssh-askpass / SSH_ASKPASS GUI dialogs from stealing focus
    when the agent key is unavailable or the mux socket is stale.
    """
    env = os.environ.copy()
    env["SSH_ASKPASS_REQUIRE"] = "never"
    env.pop("SSH_ASKPASS", None)
    return env


def _log_ssh_stderr(stderr):
    """Filter SSH mux noise from stderr; log anything else via log_message."""
    if not stderr:
        return
    if isinstance(stderr, bytes):
        stderr = stderr.decode("utf-8", errors="replace")
    from .common import log_message
    for line in stderr.splitlines():
        line = line.strip()
        if not line:
            continue
        # Suppress SSH connection-multiplexing teardown messages
        if line.startswith("Shared connection to ") and line.endswith(" closed."):
            continue
        log_message(line)


def _check_mux_alive(user: str, host: str, port: int = 22) -> bool:
    """Return True if the control-master socket is alive, False otherwise.

    If the socket file exists but the master is dead, remove the stale
    socket so a fresh connection can be established.
    """
    target = f"{user}@{host}" if user else host
    ssh_dir = os.path.expanduser("~/.ssh")
    # Must match _ssh_mux_opts ControlPath pattern
    socket_path = os.path.join(ssh_dir, f"bit-mux-{user}@{host}-{port}")
    try:
        r = subprocess.run(
            ["ssh",
             "-o", f"ControlPath={socket_path}",
             "-o", "BatchMode=yes",
             "-O", "check", target],
            capture_output=True, text=True, timeout=5,
            env=_ssh_no_prompt_env(),
        )
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        # Stale socket — remove it
        try:
            os.unlink(socket_path)
        except OSError:
            pass
        return False


# --- Core SSH runner ---

def ssh_run(user: str, host: str, cmd: str, timeout: int = 30,
            interactive: bool = False,
            port: int = 22) -> subprocess.CompletedProcess:
    """Run a command on a remote host via SSH.

    Uses ``BatchMode=yes`` and ``ConnectTimeout=5`` for non-interactive
    calls. When *interactive* is True the command gets a pseudo-tty and
    replaces the current process (exec).

    Returns a ``CompletedProcess`` (non-interactive) or does not return
    (interactive — uses ``os.execvp``).
    """
    target = f"{user}@{host}" if user else host
    mux = _ssh_mux_opts()
    port_args = ["-p", str(port)] if port != 22 else []
    if interactive:
        ssh_argv = [
            "ssh", "-t",
            *port_args,
            *mux,
            "-o", "ConnectTimeout=5",
            target,
            cmd,
        ]
        os.execvp("ssh", ssh_argv)
        # Does not return

    ssh_argv = [
        "ssh",
        *port_args,
        *mux,
        "-o", "BatchMode=yes",
        "-o", "ConnectTimeout=5",
        "-o", "StrictHostKeyChecking=accept-new",
        target,
        cmd,
    ]
    return subprocess.run(
        ssh_argv,
        capture_output=True,
        text=True,
        timeout=timeout,
        stdin=subprocess.DEVNULL,
        env=_ssh_no_prompt_env(),
    )


# --- Connection & path checks ---

_ssh_connection_cache: Dict[str, Tuple[float, bool]] = {}
_SSH_CONN_CACHE_TTL = 300.0  # 5 minutes


def _make_askpass_script() -> str:
    """Create a temporary SSH_ASKPASS script that prompts on /dev/tty.

    The script opens /dev/tty directly (bypassing stdin/stdout which SSH
    has redirected), displays the prompt with input masking, and prints the
    password to stdout for SSH to read.

    Returns the path to the temporary script.
    """
    import tempfile
    script = textwrap.dedent("""\
        #!/bin/sh
        # SSH_ASKPASS helper — prompt on the real terminal
        exec < /dev/tty 2>/dev/tty
        trap 'stty echo 2>/dev/null' EXIT INT TERM HUP
        printf '[bit] %s ' "$1" > /dev/tty
        stty -echo 2>/dev/null
        IFS= read -r pw || pw=""
        stty echo 2>/dev/null
        printf '\\n' > /dev/tty
        printf '%s\\n' "$pw"
    """)
    fd, path = tempfile.mkstemp(prefix="bit-askpass-", suffix=".sh")
    os.write(fd, script.encode())
    os.close(fd)
    os.chmod(path, 0o700)
    return path


def ssh_check_connection(user: str, host: str, port: int = 22) -> bool:
    """Test SSH connectivity, prompting for password if needed.

    First tries BatchMode (keys / existing mux socket).  If that fails,
    uses SSH_ASKPASS with a helper script that prompts on /dev/tty with
    masked input — this establishes the ControlMaster mux socket so all
    subsequent BatchMode calls reuse it without further prompts.

    Results are cached for 5 minutes.
    """
    key = f"{user}@{host}:{port}"
    now = time.monotonic()
    if key in _ssh_connection_cache:
        ts, ok = _ssh_connection_cache[key]
        if now - ts < _SSH_CONN_CACHE_TTL:
            return ok

    # Fast path: try BatchMode (keys or live mux socket)
    try:
        r = ssh_run(user, host, "true", timeout=10, port=port)
        if r.returncode == 0:
            _ssh_connection_cache[key] = (now, True)
            return True
    except (subprocess.TimeoutExpired, OSError):
        pass

    # Batch failed — use SSH_ASKPASS to prompt for password.
    # SSH only invokes ASKPASS when it has no TTY, so we pipe stdin
    # from /dev/null and set SSH_ASKPASS_REQUIRE=force.  Our askpass
    # script opens /dev/tty directly for the masked prompt.
    target = f"{user}@{host}" if user else host
    mux = _ssh_mux_opts()
    port_args = ["-p", str(port)] if port != 22 else []
    askpass = _make_askpass_script()
    try:
        env = os.environ.copy()
        env["SSH_ASKPASS"] = askpass
        env["SSH_ASKPASS_REQUIRE"] = "force"
        env.pop("DISPLAY", None)  # not needed with force
        r = subprocess.run(
            ["ssh", *port_args, *mux,
             "-o", "ConnectTimeout=10",
             "-o", "StrictHostKeyChecking=accept-new",
             target, "true"],
            stdin=subprocess.DEVNULL,
            timeout=60,
            env=env,
        )
        ok = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        ok = False
    finally:
        # Restore terminal in case askpass was killed mid-prompt
        try:
            os.system("stty echo 2>/dev/null")
        except OSError:
            pass
        try:
            os.unlink(askpass)
        except OSError:
            pass

    _ssh_connection_cache[key] = (now, ok)
    return ok


def ssh_path_exists(user: str, host: str, path: str,
                    port: int = 22) -> bool:
    """Check whether a remote directory exists."""
    try:
        r = ssh_run(user, host, f"test -d {shlex.quote(path)}", timeout=10,
                    port=port)
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def ssh_path_is_empty(user: str, host: str, path: str,
                      port: int = 22) -> bool:
    """Check whether a remote directory is empty or non-existent."""
    try:
        r = ssh_run(user, host,
                    f'test -d {shlex.quote(path)} && '
                    f'[ -z "$(ls -A {shlex.quote(path)})" ] && echo empty',
                    timeout=10, port=port)
        return "empty" in r.stdout
    except (subprocess.TimeoutExpired, OSError):
        return False


# --- Per-host alternate addresses ---

def get_host_addresses(host: str) -> list:
    """Get alternate addresses for a host from ``__hosts__`` in projects.json.

    Returns list of ``{"address": str, "port": int}`` dicts.
    Empty list means use primary host:22 only.
    """
    config_dir = os.path.expanduser("~/.config/bit")
    projects_file = os.path.join(config_dir, "projects.json")
    if not os.path.isfile(projects_file):
        return []
    try:
        with open(projects_file, "r") as f:
            data = json.load(f)
        hosts = data.get("__hosts__", {})
        entry = hosts.get(host, {})
        return entry.get("addresses", [])
    except (json.JSONDecodeError, OSError):
        return []


def set_host_addresses(host: str, addresses: list) -> None:
    """Save alternate addresses for a host to ``__hosts__`` in projects.json."""
    _update_host_entry(host, "addresses", addresses if addresses else None)


def get_host_tmux_session(host: str) -> str:
    """Get custom tmux session name for a host.

    Returns the session name to attach to, or ``""`` for default
    ``bit-*`` behaviour.
    """
    config_dir = os.path.expanduser("~/.config/bit")
    projects_file = os.path.join(config_dir, "projects.json")
    if not os.path.isfile(projects_file):
        return ""
    try:
        with open(projects_file, "r") as f:
            data = json.load(f)
        hosts = data.get("__hosts__", {})
        entry = hosts.get(host, {})
        return entry.get("tmux_session", "")
    except (json.JSONDecodeError, OSError):
        return ""


def set_host_tmux_session(host: str, session: str) -> None:
    """Set custom tmux session name for a host.

    Empty string clears the setting (reverts to default ``bit-*``).
    """
    _update_host_entry(host, "tmux_session", session if session else None)


def _update_host_entry(host: str, key: str, value) -> None:
    """Update a single field in the ``__hosts__.<host>`` config."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    projects_file = os.path.join(config_dir, "projects.json")
    data = {}
    if os.path.isfile(projects_file):
        try:
            with open(projects_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    hosts = data.setdefault("__hosts__", {})
    entry = hosts.setdefault(host, {})
    if value is not None:
        entry[key] = value
    else:
        entry.pop(key, None)
    # Clean up empty entries
    if not entry:
        hosts.pop(host, None)
    try:
        with open(projects_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def ssh_resolve_address(user: str, host: str) -> Tuple[str, int]:
    """Try primary host, then alternates. Returns ``(address, port)`` that connects.

    Checks the connection cache first.  On cache miss, tries each address
    in order with ``ssh_check_connection()``.  Returns first that succeeds.
    Falls back to primary ``(host, 22)`` if all fail.
    """
    addresses = get_host_addresses(host)
    if not addresses:
        return (host, 22)

    # Check cache for a known-good address
    for addr in addresses:
        a, p = addr["address"], addr.get("port", 22)
        key = f"{user}@{a}:{p}"
        if key in _ssh_connection_cache:
            ts, ok = _ssh_connection_cache[key]
            if time.monotonic() - ts < _SSH_CONN_CACHE_TTL and ok:
                return (a, p)

    # No cached success — probe each
    for addr in addresses:
        a, p = addr["address"], addr.get("port", 22)
        if ssh_check_connection(user, a, port=p):
            return (a, p)

    # All failed — return primary so caller gets the normal error
    return (addresses[0]["address"], addresses[0].get("port", 22))


def fetch_remote_projects(user: str, host: str,
                          port: int = 22) -> list:
    """Read remote bit instance's local projects via SSH.

    Returns list of dicts with path, name, description, tags, and persona.
    Only returns projects that are local on the remote (no host key).
    """
    if not ssh_check_connection(user, host, port=port):
        return []

    r = ssh_run(user, host,
                "cat ~/.config/bit/projects.json 2>/dev/null",
                timeout=15, port=port)
    if r.returncode != 0 or not r.stdout.strip():
        return []

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError):
        return []

    results = []
    for key, info in data.items():
        if key.startswith("__"):
            continue
        if not isinstance(info, dict):
            continue
        if "host" in info:
            continue  # skip — this is already a remote project on that machine
        results.append({
            "path": key,
            "name": info.get("name", os.path.basename(key)),
            "description": info.get("description", ""),
            "tags": list(info.get("tags") or []),
            "persona": info.get("persona", "yocto"),
        })
    return results


# --- Remote git helpers ---

_GET_REPOS_SCRIPT = r'''
cd {path} || exit 1
seen=""
found=""

# Check bblayers.conf for layer repos (Yocto projects)
# Try both conf/ (build-as-project-root) and build/conf/ (standard layout)
bblayers=""
if [ -f conf/bblayers.conf ]; then
    bblayers=conf/bblayers.conf
elif [ -f build/conf/bblayers.conf ]; then
    bblayers=build/conf/bblayers.conf
fi
if [ -n "$bblayers" ]; then
    for layer in $(grep -oE '/[^ "\\]+' "$bblayers"); do
        [ -d "$layer" ] || continue
        repo=$(git -C "$layer" rev-parse --show-toplevel 2>/dev/null)
        [ -z "$repo" ] && continue
        case " $seen " in *" $repo "*) continue ;; esac
        seen="$seen $repo"
        found="y"
        echo "$repo"
    done
fi

# Add extra repos from .bit.defaults (e.g. bitbake)
if [ -f .bit.defaults ] && command -v python3 >/dev/null 2>&1; then
    extras=$(python3 -c "
import json,sys
try:
    d=json.load(open('.bit.defaults'))
    hidden=set(d.get('__hidden_repos__',[]))
    for r in d.get('__extra_repos__',[]):
        if r not in hidden: print(r)
except: pass
" 2>/dev/null)
    for repo in $extras; do
        [ -d "$repo/.git" ] || continue
        case " $seen " in *" $repo "*) continue ;; esac
        seen="$seen $repo"
        found="y"
        echo "$repo"
    done
fi

# Fallback: scan for .git dirs if no tracked repos found
if [ -z "$found" ]; then
    for d in . */ */*/; do
        d="${{d%/}}"
        [ -d "$d/.git" ] && echo "$d"
    done
fi
'''


def ssh_get_git_repos(user: str, host: str, path: str,
                      port: int = 22) -> List[str]:
    """Find tracked git repos for a remote project (single SSH call).

    Prefers tracked repos (bblayers.conf layers + .bit.defaults extra repos)
    over blind scanning.  Falls back to scanning for ``.git`` dirs up to
    2 levels deep when no project metadata exists.
    """
    script = _GET_REPOS_SCRIPT.format(path=shlex.quote(path))
    try:
        r = ssh_run(user, host, script, timeout=30, port=port)
        if r.returncode != 0:
            return []
        repos = []
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            if line == ".":
                repos.append(path)
            elif line.startswith("/"):
                # Absolute path (from bblayers.conf fallback)
                repos.append(line)
            else:
                repos.append(os.path.join(path, line))
        return repos
    except (subprocess.TimeoutExpired, OSError):
        return []


def ssh_current_branch(user: str, host: str, repo: str,
                       port: int = 22) -> Optional[str]:
    """Get the current branch of a remote git repo."""
    cmd = f"git -C {shlex.quote(repo)} rev-parse --abbrev-ref HEAD"
    try:
        r = ssh_run(user, host, cmd, timeout=10, port=port)
        if r.returncode == 0:
            return r.stdout.strip() or None
        return None
    except (subprocess.TimeoutExpired, OSError):
        return None


# --- Batched dashboard summary ---

_SUMMARY_SCRIPT = r'''
if [ -d {path} ] && [ -n "$(ls -A {path} 2>/dev/null)" ]; then
    path_exists="true"
    cd {path}
else
    path_exists="false"
fi

total=0
dirty=0
ahead=0
behind=0
branches=""

# Collect repo directories to scan.
# Prefer tracked repos (bblayers.conf + .bit.defaults) over blind scanning.
repo_dirs=""
seen=""
if [ "$path_exists" = "true" ]; then
    # Check bblayers.conf for layer repos (Yocto projects)
    bblayers=""
    if [ -f conf/bblayers.conf ]; then
        bblayers=conf/bblayers.conf
    elif [ -f build/conf/bblayers.conf ]; then
        bblayers=build/conf/bblayers.conf
    fi
    if [ -n "$bblayers" ]; then
        for layer in $(grep -oE '/[^ "\\]+' "$bblayers"); do
            [ -d "$layer" ] || continue
            repo=$(git -C "$layer" rev-parse --show-toplevel 2>/dev/null)
            [ -z "$repo" ] && continue
            case " $seen " in *" $repo "*) continue ;; esac
            seen="$seen $repo"
            repo_dirs="$repo_dirs $repo"
        done
    fi

    # Add extra repos from .bit.defaults (e.g. bitbake)
    bit_defaults=""
    if [ -f .bit.defaults ]; then
        bit_defaults=.bit.defaults
    elif [ -f build/.bit.defaults ]; then
        bit_defaults=build/.bit.defaults
    fi
    if [ -n "$bit_defaults" ] && command -v python3 >/dev/null 2>&1; then
        extras=$(python3 -c "
import json,sys
try:
    d=json.load(open('$bit_defaults'))
    hidden=set(d.get('__hidden_repos__',[]))
    for r in d.get('__extra_repos__',[]):
        if r not in hidden: print(r)
except: pass
" 2>/dev/null)
        for repo in $extras; do
            [ -d "$repo/.git" ] || continue
            case " $seen " in *" $repo "*) continue ;; esac
            seen="$seen $repo"
            repo_dirs="$repo_dirs $repo"
        done
    fi

    # Auto-detect bitbake as a peer of known layer repos
    if [ -n "$repo_dirs" ]; then
        for d in $repo_dirs; do
            parent=$(dirname "$d")
            bb="$parent/bitbake"
            [ -d "$bb/.git" ] || continue
            case " $seen " in *" $bb "*) continue ;; esac
            seen="$seen $bb"
            repo_dirs="$repo_dirs $bb"
            break
        done
    fi

    # Fallback: if no tracked repos found, scan for .git dirs
    if [ -z "$repo_dirs" ]; then
        for d in . */ */*/; do
            d="${{d%/}}"
            [ -d "$d/.git" ] || continue
            repo_dirs="$repo_dirs $d"
        done
    fi
fi

for d in $repo_dirs; do
    total=$((total + 1))

    b=$(git -C "$d" rev-parse --abbrev-ref HEAD 2>/dev/null)
    [ -n "$b" ] && branches="$branches $b"

    s=$(git -C "$d" status --porcelain -uno --no-renames 2>/dev/null)
    [ -n "$s" ] && dirty=$((dirty + 1))

    # Determine upstream ref: @{{u}} -> origin/<branch> -> origin/HEAD
    uref=""
    if [ -n "$b" ]; then
        uref=$(git -C "$d" rev-parse --abbrev-ref "$b@{{u}}" 2>/dev/null) || uref=""
        if [ -z "$uref" ] && git -C "$d" rev-parse --verify "origin/$b" >/dev/null 2>&1; then
            uref="origin/$b"
        fi
        if [ -z "$uref" ]; then
            uref=$(git -C "$d" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null) || uref=""
        fi
    fi
    if [ -n "$uref" ]; then
        a=$(git -C "$d" rev-list --count "$uref..HEAD" 2>/dev/null) || a=0
        b2=$(git -C "$d" rev-list --count "HEAD..$uref" 2>/dev/null) || b2=0
        ahead=$((ahead + a))
        behind=$((behind + b2))
    fi
done

# Most common branch
best=""
best_n=0
for b in $branches; do
    n=$(echo "$branches" | tr ' ' '\n' | grep -cx "$b")
    if [ "$n" -gt "$best_n" ]; then
        best_n=$n
        best=$b
    fi
done

echo "REPO_COUNT=$total"
echo "DIRTY_COUNT=$dirty"
echo "AHEAD=$ahead"
echo "BEHIND=$behind"
echo "BRANCH=$best"

# Last updated — newest HEAD reflog mtime (epoch) across repos
last_updated=0
for d in $repo_dirs; do
    reflog="$d/.git/logs/HEAD"
    if [ -f "$reflog" ]; then
        mt=$(stat -c %Y "$reflog" 2>/dev/null || stat -f %m "$reflog" 2>/dev/null)
        if [ -n "$mt" ] && [ "$mt" -gt "$last_updated" ] 2>/dev/null; then
            last_updated=$mt
        fi
    fi
done
echo "LAST_UPDATED=$last_updated"

# Check needs_setup: .bit.defaults with applied=false
needs_setup="false"
if [ "$path_exists" = "true" ] && [ -f .bit.defaults ]; then
    if command -v python3 >/dev/null 2>&1; then
        needs_setup=$(python3 -c "
import json,sys
try:
    d=json.load(open('.bit.defaults'))
    m=d.get('__conf_json__',{{}})
    print('true' if m and not m.get('applied',True) else 'false')
except: print('false')
" 2>/dev/null)
    else
        if grep -q '"applied".*false' .bit.defaults 2>/dev/null; then
            needs_setup="true"
        fi
    fi
fi
echo "NEEDS_SETUP=$needs_setup"
echo "PATH_EXISTS=$path_exists"
'''


def _parse_summary_output(output: str) -> dict:
    """Parse KEY=VALUE lines from batched summary script output."""
    summary = {
        "repo_count": 0,
        "dirty_count": 0,
        "ahead": 0,
        "behind": 0,
        "branch": "",
        "needs_setup": False,
        "exists": True,
    }
    for line in output.strip().splitlines():
        line = line.strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip().lower()
        value = value.strip()
        if key == "repo_count":
            summary["repo_count"] = int(value)
        elif key == "dirty_count":
            summary["dirty_count"] = int(value)
        elif key == "ahead":
            summary["ahead"] = int(value)
        elif key == "behind":
            summary["behind"] = int(value)
        elif key == "branch":
            summary["branch"] = value
        elif key == "needs_setup":
            summary["needs_setup"] = value == "true"
        elif key == "last_updated":
            try:
                ts = int(value)
                if ts > 0:
                    summary["last_updated"] = float(ts)
            except (ValueError, TypeError):
                pass
        elif key == "path_exists":
            summary["exists"] = value == "true"
    return summary


def ssh_get_dashboard_summary(user: str, host: str, path: str,
                              timeout: int = 60,
                              port: int = 22) -> dict:
    """Gather repo-level summary for a remote project (single SSH call).

    Returns the same dict shape as ``_get_dashboard_summary()``:
    ``{repo_count, dirty_count, ahead, behind, branch, needs_setup}``.
    """
    empty = {"repo_count": 0, "dirty_count": 0, "ahead": 0,
             "behind": 0, "branch": "", "needs_setup": False,
             "exists": True}
    script = _SUMMARY_SCRIPT.format(path=shlex.quote(path))
    try:
        r = ssh_run(user, host, f"bash -c {shlex.quote(script)}", timeout=timeout,
                    port=port)
        if r.returncode != 0:
            return dict(empty)
        return _parse_summary_output(r.stdout)
    except (subprocess.TimeoutExpired, OSError, ValueError):
        return dict(empty)


def ssh_get_repos_explore(user: str, host: str, path: str,
                         timeout: int = 30,
                         port: int = 22) -> list:
    """Gather per-repo explore data for a remote project (single SSH call).

    Returns a list of dicts with keys matching ``gather_repo_status()`` output:
    ``{display_name, branch, is_dirty, local_count, upstream_count, path, layers}``.
    """
    script = r'''
cd {path} 2>/dev/null || exit 1

# Discover repos and emit LAYER| lines for layer→repo mapping
seen=""
repos=""
bblayers=""
if [ -f conf/bblayers.conf ]; then
    bblayers=conf/bblayers.conf
elif [ -f build/conf/bblayers.conf ]; then
    bblayers=build/conf/bblayers.conf
fi
if [ -n "$bblayers" ]; then
    for layer in $(grep -oE '/[^ "\\]+' "$bblayers"); do
        [ -d "$layer" ] || continue
        repo=$(git -C "$layer" rev-parse --show-toplevel 2>/dev/null)
        [ -z "$repo" ] && continue
        case " $seen " in *" $repo "*) ;; *)
            seen="$seen $repo"
            repos="$repos $repo"
        ;; esac
        echo "LAYER|$repo|$layer"
    done
fi
bit_defaults=""
if [ -f .bit.defaults ]; then
    bit_defaults=.bit.defaults
elif [ -f build/.bit.defaults ]; then
    bit_defaults=build/.bit.defaults
fi
if [ -n "$bit_defaults" ] && command -v python3 >/dev/null 2>&1; then
    extras=$(python3 -c "
import json
try:
    d=json.load(open('$bit_defaults'))
    hidden=set(d.get('__hidden_repos__',[]))
    for r in d.get('__extra_repos__',[]):
        if r not in hidden: print(r)
except: pass
" 2>/dev/null)
    for repo in $extras; do
        [ -d "$repo/.git" ] || continue
        case " $seen " in *" $repo "*) continue ;; esac
        seen="$seen $repo"
        repos="$repos $repo"
    done
fi
# Auto-detect bitbake as a peer of known layer repos
if [ -n "$repos" ]; then
    for d in $repos; do
        parent=$(dirname "$d")
        bb="$parent/bitbake"
        [ -d "$bb/.git" ] || continue
        case " $seen " in *" $bb "*) continue ;; esac
        seen="$seen $bb"
        repos="$repos $bb"
        break
    done
fi
if [ -z "$repos" ]; then
    for d in . */ */*/; do
        d="${{d%/}}"
        [ -d "$d/.git" ] && repos="$repos $d"
    done
fi

for d in $repos; do
    [ -d "$d/.git" ] || [ -d "$d" ] || continue
    branch=$(git -C "$d" rev-parse --abbrev-ref HEAD 2>/dev/null)
    [ -z "$branch" ] && continue

    # Display name: git config, then origin URL basename, then dir basename
    dname=$(git -C "$d" config bit.display-name 2>/dev/null)
    if [ -z "$dname" ]; then
        origin_url=$(git -C "$d" config --get remote.origin.url 2>/dev/null)
        if [ -n "$origin_url" ]; then
            # Strip trailing slashes, .git suffix, and extract final component
            dname=$(echo "$origin_url" | sed 's|/*$||;s|\.git$||;s|.*/||')
        fi
    fi
    if [ -z "$dname" ] || [ "$dname" = "." ]; then
        if [ "$d" = "." ]; then
            dname=$(basename "$(pwd)")
        else
            dname=$(basename "$d")
        fi
    fi

    # Dirty check
    s=$(git -C "$d" status --porcelain -uno --no-renames 2>/dev/null)
    dirty="false"
    [ -n "$s" ] && dirty="true"

    # Ahead/behind — mirror Python get_upstream_ref() fallback logic
    uref=""
    uref=$(git -C "$d" rev-parse --abbrev-ref "$branch@{{u}}" 2>/dev/null) || uref=""
    if [ -z "$uref" ] && git -C "$d" rev-parse --verify "origin/$branch" >/dev/null 2>&1; then
        uref="origin/$branch"
    fi
    if [ -z "$uref" ]; then
        uref=$(git -C "$d" symbolic-ref --short refs/remotes/origin/HEAD 2>/dev/null) || uref=""
    fi
    local_n=0
    upstream_n=0
    if [ -n "$uref" ]; then
        local_n=$(git -C "$d" rev-list --count "$uref..HEAD" 2>/dev/null) || local_n=0
        upstream_n=$(git -C "$d" rev-list --count "HEAD..$uref" 2>/dev/null) || upstream_n=0
    fi

    echo "REPO|$d|$dname|$branch|$dirty|$local_n|$upstream_n"
done
'''.format(path=shlex.quote(path))
    try:
        r = ssh_run(user, host, f"bash -c {shlex.quote(script)}", timeout=timeout,
                    port=port)
        if r.returncode != 0:
            return []
        # First pass: collect LAYER| lines into a repo→layers map
        layers_map: dict = {}
        for line in r.stdout.strip().splitlines():
            if line.startswith("LAYER|"):
                lparts = line.split("|", 2)
                if len(lparts) == 3:
                    layers_map.setdefault(lparts[1], []).append(lparts[2])

        # Second pass: collect REPO| lines and attach layers
        result = []
        for line in r.stdout.strip().splitlines():
            if not line.startswith("REPO|"):
                continue
            parts = line.split("|", 6)
            if len(parts) < 7:
                continue
            _, repo_path, display_name, branch, dirty, local_n, upstream_n = parts[:7]
            result.append({
                "path": repo_path,
                "display_name": display_name,
                "branch": branch,
                "is_dirty": dirty == "true",
                "local_count": int(local_n) if local_n.isdigit() else 0,
                "upstream_count": int(upstream_n) if upstream_n.lstrip('-').isdigit() else 0,
                "head_commit": None,
                "layers": layers_map.get(repo_path, []),
                "default_action": "rebase",
            })
        return result
    except (subprocess.TimeoutExpired, OSError, ValueError):
        return []


# --- Update helpers ---

def ssh_run_single_repo_update(user: str, host: str, repo: str,
                               branch: str, action: str,
                               port: int = 22) -> bool:
    """Run ``git pull --rebase`` or ``git pull`` on a remote repo over SSH.

    Returns True on success.
    """
    if action not in ("rebase", "merge"):
        return False
    if not branch:
        return False

    pull_cmd = "git pull --rebase" if action == "rebase" else "git pull"
    cmd = f"cd {shlex.quote(repo)} && {pull_cmd}"
    try:
        r = ssh_run(user, host, cmd, timeout=120, port=port)
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


# --- Remote bit detection (cached) ---

_bit_cache: Dict[str, Tuple[float, bool]] = {}
_BIT_CACHE_TTL = 300.0  # 5 minutes

_tmux_cache: Dict[str, Tuple[float, bool]] = {}
_TMUX_CACHE_TTL = 300.0  # 5 minutes

from ..tmux import (
    _BIT_CONFIG_DIR,
    get_tmux_prefix,
    set_tmux_prefix,
    tmux_session_name as _tmux_session_name_impl,
)

_DEFAULT_TMUX_PREFIX = "C-a"


_EXTRA_PATH = "$HOME/.cache/bit:$HOME/bin:$HOME/.local/bin"


def _remote_has_tmux(user: str, host: str, port: int = 22) -> bool:
    """Check whether tmux is available on the remote host (5min cache)."""
    key = f"{user}@{host}:{port}"
    now = time.monotonic()
    if key in _tmux_cache:
        ts, has_tmux = _tmux_cache[key]
        if now - ts < _TMUX_CACHE_TTL:
            return has_tmux

    try:
        r = ssh_run(user, host, "command -v tmux >/dev/null 2>&1", timeout=10,
                    port=port)
        has_tmux = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        has_tmux = False

    _tmux_cache[f"{user}@{host}:{port}"] = (now, has_tmux)
    return has_tmux


def _tmux_session_name(path: str) -> str:
    """Derive a tmux session name from a project path.

    Delegates to :func:`bitbake_project.tmux.tmux_session_name`.
    """
    return _tmux_session_name_impl(path)


def tmux_wrap_remote(session_name: str, window_name: str, inner_cmd: str,
                     prefix: Optional[str] = None) -> str:
    """Build a shell snippet that runs inner_cmd inside a named tmux session.

    If the session already exists, adds a new window and attaches.
    Otherwise creates a new session, sets the prefix key, and attaches.
    """
    q_session = shlex.quote(session_name)
    q_window = shlex.quote(window_name)
    q_cmd = shlex.quote(inner_cmd)

    if prefix:
        q_prefix = shlex.quote(prefix)
        # Create detached so we can set prefix before attaching
        new_session = (
            f"tmux new-session -d -s {q_session} -n {q_window} {q_cmd}; "
            f"tmux set-option -t {q_session} prefix {q_prefix}; "
            f"exec tmux attach-session -t {q_session}"
        )
    else:
        new_session = (
            f"exec tmux new-session -s {q_session} -n {q_window} {q_cmd}"
        )

    # Always enforce the configured prefix, even on existing sessions
    set_prefix = (f"tmux set-option -t {q_session} prefix {shlex.quote(prefix)}; "
                  if prefix else "")
    return (
        f"if tmux has-session -t {q_session} 2>/dev/null; then "
        f"tmux new-window -t {q_session} -n {q_window} {q_cmd}; "
        f"{set_prefix}"
        f"exec tmux attach-session -t {q_session}; "
        f"else "
        f"{new_session}; "
        f"fi"
    )


def _find_local_bit() -> Optional[str]:
    """Find the path to the local bit zipapp binary."""
    # sys.argv[0] is the script/zipapp path when invoked directly
    candidate = os.path.abspath(sys.argv[0])
    if os.path.isfile(candidate):
        return candidate
    # Fallback: search PATH
    which = shutil.which("bit")
    if which:
        return which
    return None


def _deploy_bit_to_remote(user: str, host: str,
                          port: int = 22) -> bool:
    """Auto-deploy the local bit binary to ``~/.cache/bit/bit`` on the remote.

    Pipes the zipapp over a single SSH call.  Returns True on success.
    """
    local_bit = _find_local_bit()
    if not local_bit:
        return False

    local_size = os.path.getsize(local_bit)
    target = f"{user}@{host}" if user else host

    # Check if remote already has the same version (by file size)
    try:
        r = ssh_run(user, host,
                    'stat -c%s "$HOME/.cache/bit/bit" 2>/dev/null || echo 0',
                    timeout=10, port=port)
        if r.returncode == 0:
            remote_size = int(r.stdout.strip())
            if remote_size == local_size:
                return True  # Already deployed and up to date
    except (subprocess.TimeoutExpired, OSError, ValueError):
        pass

    # Deploy
    port_args = ["-p", str(port)] if port != 22 else []
    try:
        with open(local_bit, "rb") as f:
            r = subprocess.run(
                ["ssh", *port_args, *_ssh_mux_opts(),
                 "-o", "BatchMode=yes",
                 "-o", "ConnectTimeout=5",
                 "-o", "StrictHostKeyChecking=accept-new",
                 target,
                 'mkdir -p "$HOME/.cache/bit" && '
                 'cat > "$HOME/.cache/bit/bit" && '
                 'chmod +x "$HOME/.cache/bit/bit"'],
                stdin=f,
                capture_output=True,
                timeout=60,
                env=_ssh_no_prompt_env(),
            )
            return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError, IOError):
        return False


def remote_has_bit_cached(user: str, host: str,
                          port: int = 22) -> bool:
    """Check whether ``bit`` is installed on the remote host (5min cache).

    Extends PATH with common user-local directories so that standalone
    installs in ``~/bin`` are found.
    """
    key = f"{user}@{host}:{port}"
    now = time.monotonic()
    if key in _bit_cache:
        ts, has_bit = _bit_cache[key]
        if now - ts < _BIT_CACHE_TTL:
            return has_bit

    try:
        r = ssh_run(user, host,
                    f'PATH="{_EXTRA_PATH}:$PATH" command -v bit '
                    '>/dev/null 2>&1',
                    timeout=10, port=port)
        has_bit = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        has_bit = False

    _bit_cache[f"{user}@{host}:{port}"] = (now, has_bit)
    return has_bit


# --- Action dispatch with fallback ---

def remote_run_action(user: str, host: str, path: str, cmd: str,
                      port: int = 22) -> int:
    """Run a bit command on a remote project with fallback chain.

    1. Try ``bit <cmd>`` on remote (if bit is installed)
    2. For git operations (update): dispatch raw git commands
    3. Ultimate fallback: open a shell at the project directory

    Returns exit code (0 = success).  Always returns (never replaces
    the process) so the dashboard loop can continue.
    """
    from ..core import Colors
    from .common import log_message

    # Pre-check: verify SSH auth works before launching interactive session.
    # This prevents password/askpass prompts from hijacking the terminal.
    if not ssh_check_connection(user, host, port=port):
        log_message(f"{Colors.red('✗')} SSH connection to {host} failed — check agent/key")
        # Invalidate connection cache so next attempt retries
        _ssh_connection_cache.pop(f"{user}@{host}:{port}", None)
        return 1

    # Stage 1: ensure remote has current bit version.
    # Always deploy so the streamed copy stays current; PATH puts
    # ~/.cache/bit first so it wins over stale installs in ~/bin.
    if _deploy_bit_to_remote(user, host, port=port):
        has_bit = True
        _bit_cache[f"{user}@{host}:{port}"] = (time.monotonic(), True)
    else:
        has_bit = remote_has_bit_cached(user, host, port=port)

    port_args = ["-p", str(port)] if port != 22 else []
    if has_bit:
        # Extend PATH inline so bit is found; no bash -l -c wrapper
        # so that fzf gets direct PTY access for proper terminal handling.
        # Set BIT_REMOTE_HOST so remote bit menus show ⇄ indicator.
        inner_cmd = (f'export PATH="{_EXTRA_PATH}:$PATH" '
                     f'BIT_REMOTE_HOST={shlex.quote(host)} && '
                     f"cd {shlex.quote(path)} && bit {cmd}")
        if _remote_has_tmux(user, host, port=port):
            session = _tmux_session_name(path)
            window = cmd.split()[0]
            prefix = get_tmux_prefix()
            full_cmd = tmux_wrap_remote(session, window, inner_cmd, prefix)
        else:
            full_cmd = inner_cmd
        target = f"{user}@{host}" if user else host
        try:
            r = subprocess.run(
                ["ssh", "-t", *port_args, *_ssh_mux_opts(),
                 "-o", "ConnectTimeout=5", target, full_cmd],
                stderr=subprocess.PIPE,
                timeout=300,
                env=_ssh_no_prompt_env(),
            )
            _log_ssh_stderr(r.stderr)
            return r.returncode
        except (subprocess.TimeoutExpired, OSError):
            pass

    # Stage 2: for update commands, try raw git
    if cmd.strip() in ("update", "update -y"):
        repos = ssh_get_git_repos(user, host, path, port=port)
        if repos:
            ok = True
            for repo in repos:
                branch = ssh_current_branch(user, host, repo, port=port)
                if branch:
                    if not ssh_run_single_repo_update(user, host, repo,
                                                      branch, "rebase",
                                                      port=port):
                        ok = False
            return 0 if ok else 1

    # Stage 3: fallback to interactive shell (subprocess, not exec)
    log_message(f"{Colors.yellow('Note:')} bit not available on {host}, opening shell at {path}")
    remote_shell(user, host, path, port=port)
    return 0


def oe_remote_shell_snippet(remote_path: str) -> str:
    """Shell script that finds/sources oe-init-build-env on a remote host.

    Searches the project tree for ``oe-init-build-env`` (up to 3 levels
    deep inside a ``layers`` subdirectory, or in the project root), creates
    a temp rcfile, and starts ``bash --rcfile``.  Falls back to a login
    shell if no init script is found.

    If *remote_path* is empty, returns a simple login shell command.
    """
    if not remote_path:
        return "exec $SHELL -l"

    qpath = shlex.quote(remote_path)
    return f'''\
cd {qpath} || exit 1
_proj="$PWD"
_oe_init=""
[ -f oe-init-build-env ] && _oe_init="$_proj/oe-init-build-env"
if [ -z "$_oe_init" ] && [ -d layers ]; then
    _found=$(find layers -maxdepth 3 -name oe-init-build-env -type f 2>/dev/null | head -1)
    [ -n "$_found" ] && _oe_init="$_proj/$_found"
fi
if [ -n "$_oe_init" ]; then
    _tpl=""
    _d=$(dirname "$_oe_init")
    for _t in "$_d"/../*/conf/templates/default; do
        [ -d "$_t" ] || continue
        case "$_t" in *meta-poky*) _tpl=$(cd "$_t" && pwd); break;; esac
        [ -z "$_tpl" ] && _tpl=$(cd "$_t" && pwd)
    done
    _rc=$(mktemp /tmp/bit-oe-XXXXXX)
    [ -f ~/.bashrc ] && printf '. ~/.bashrc\\n' >> "$_rc"
    printf 'cd "%s"\\n' "$_proj" >> "$_rc"
    [ -n "$_tpl" ] && printf 'export TEMPLATECONF="%s"\\n' "$_tpl" >> "$_rc"
    printf '. "%s"\\n' "$_oe_init" >> "$_rc"
    printf 'PS1="(oe) $PS1"\\n' >> "$_rc"
    printf 'rm -f "%s"\\n' "$_rc" >> "$_rc"
    exec bash --rcfile "$_rc"
else
    exec $SHELL -l
fi\
'''


def remote_shell(user: str, host: str, path: str,
                 replace_process: bool = False,
                 port: int = 22) -> None:
    """Open an interactive SSH shell at the remote project directory.

    If the host has a custom ``tmux_session`` configured, attaches to
    that session directly (no bit-specific wrapping).  Otherwise looks
    for ``oe-init-build-env`` in the project tree (up to 3 levels deep
    inside a ``layers`` subdirectory, or in the project root) and
    sources it — mirroring the local ``run_init_shell`` behaviour.
    Falls back to a plain login shell if no init script is found.

    When *replace_process* is True, replaces the current process via
    ``os.execvp`` (used for standalone shell action).  Otherwise runs
    as a subprocess and returns when the user exits the shell.
    """
    target = f"{user}@{host}" if user else host
    port_args = ["-p", str(port)] if port != 22 else []

    # Host-level shell (no project path): use custom tmux session if configured
    # Project shell (has path): always use default bit-* session with OE env
    custom_session = get_host_tmux_session(host) if not path else ""
    if custom_session:
        # Attach to the user's existing tmux session directly
        # "auto" = attach to most recent session (no -t flag)
        if custom_session == "auto":
            shell_cmd = "tmux attach-session 2>/dev/null || tmux new-session"
        else:
            shell_cmd = (
                f"tmux attach-session -t {shlex.quote(custom_session)} "
                f"2>/dev/null || tmux new-session -s {shlex.quote(custom_session)}"
            )
    else:
        shell_cmd = oe_remote_shell_snippet(path)
        if _remote_has_tmux(user, host, port=port):
            session = _tmux_session_name(path) if path else f"bit-{host}"
            prefix = get_tmux_prefix()
            shell_cmd = tmux_wrap_remote(session, "shell", shell_cmd, prefix)
    ssh_argv = [
        "ssh", "-t",
        *port_args,
        *_ssh_mux_opts(),
        "-o", "ConnectTimeout=5",
        target,
        shell_cmd,
    ]
    env = _ssh_no_prompt_env()
    if replace_process:
        os.environ.update(env)
        os.execvp("ssh", ssh_argv)
        # Does not return
    else:
        r = subprocess.run(ssh_argv, stderr=subprocess.PIPE, env=env)
        _log_ssh_stderr(r.stderr)
        return r.returncode


# --- Remote commit helpers ---

def ssh_get_commit_log(user: str, host: str, repo: str,
                       count: int = 200,
                       since: str = "",
                       port: int = 22) -> List[Tuple[str, str]]:
    """Fetch recent commits from a remote repo.

    Args:
        since: If set, only return commits reachable from HEAD but not
            from *since* (i.e. ``since..HEAD``).  Typically the local
            HEAD hash so only "new" remote commits are shown.

    Returns ``[(full_hash, subject), ...]`` in oldest-first order,
    matching the format ``fzf_explore_commits()`` uses for *local_commits*.
    """
    qrepo = shlex.quote(repo)
    if since:
        # Commits on remote that are not in local — git log since..HEAD
        cmd = (f"git -C {qrepo} log "
               f"--format='%H %s' --reverse {shlex.quote(since)}..HEAD")
    else:
        cmd = (f"git -C {qrepo} log "
               f"--format='%H %s' --reverse -{count}")
    try:
        r = ssh_run(user, host, cmd, timeout=30, port=port)
        if r.returncode != 0:
            return []
        results = []
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(" ", 1)
            if len(parts) == 2:
                results.append((parts[0], parts[1]))
            elif parts:
                results.append((parts[0], ""))
        return results
    except (subprocess.TimeoutExpired, OSError):
        return []


def ssh_get_branch_info(user: str, host: str,
                        repo: str,
                        port: int = 22) -> Tuple[str, str]:
    """Fetch branch name and upstream ref in a single SSH call.

    Returns ``(branch, upstream_ref)``.  *upstream_ref* is empty when
    the branch has no tracking configuration.
    """
    script = (
        f'cd {shlex.quote(repo)} && '
        f'b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) && echo "BRANCH=$b"; '
        f'u=$(git rev-parse --abbrev-ref "@{{u}}" 2>/dev/null) && echo "UPSTREAM=$u"'
    )
    branch = ""
    upstream = ""
    try:
        r = ssh_run(user, host, script, timeout=15, port=port)
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if line.startswith("BRANCH="):
                branch = line[7:]
            elif line.startswith("UPSTREAM="):
                upstream = line[9:]
    except (subprocess.TimeoutExpired, OSError):
        pass
    return (branch, upstream)


def ssh_format_patch_stdout(user: str, host: str, repo: str,
                            commits: List[str],
                            timeout: int = 120,
                            port: int = 22) -> str:
    """Run ``git format-patch --stdout`` on the remote for selected commits.

    Returns the raw mbox text as a string (all patches concatenated).
    For a contiguous range, uses a range spec; otherwise generates
    individual ``-1 <hash>`` patches.
    """
    if not commits:
        return ""

    # Build the format-patch command — individual -1 for each commit
    parts = []
    for h in commits:
        parts.append(
            f"git -C {shlex.quote(repo)} format-patch --stdout -1 {shlex.quote(h)}"
        )
    cmd = " && ".join(parts)

    try:
        r = ssh_run(user, host, cmd, timeout=timeout, port=port)
        if r.returncode != 0:
            return ""
        return r.stdout
    except (subprocess.TimeoutExpired, OSError):
        return ""


def ssh_commit_show(user: str, host: str, repo: str,
                    commit_hash: str, port: int = 22) -> dict:
    """Show commit metadata + stat + diff from a remote repo over SSH.

    Returns a dict with the same shape as ``query_commit_show()``::

        {"sha", "author", "email", "date", "subject", "body", "stat", "diff"}

    On failure returns ``{"error": "..."}``.
    """
    qrepo = shlex.quote(repo)
    qhash = shlex.quote(commit_hash)

    # Metadata + stat in one call
    meta_cmd = (f"git -C {qrepo} show "
                f"--format=%H%n%an%n%ae%n%ai%n%s%n%b {qhash} --stat")
    try:
        r = ssh_run(user, host, meta_cmd, timeout=30, port=port)
        if r.returncode != 0:
            return {"error": f"Failed to show commit {commit_hash} on {host}"}
    except (subprocess.TimeoutExpired, OSError) as e:
        return {"error": str(e)}

    # Parse: first 5 lines are format fields, 6th is body (may be multi-line),
    # then a blank line separates body from --stat output.
    # git show with --stat appends stat after the format output + a blank line.
    lines = r.stdout.split("\n")
    sha = lines[0] if len(lines) > 0 else ""
    author = lines[1] if len(lines) > 1 else ""
    email = lines[2] if len(lines) > 2 else ""
    date = lines[3] if len(lines) > 3 else ""
    subject = lines[4] if len(lines) > 4 else ""

    # Body runs from line 5 until we hit the stat separator.
    # --stat output starts after a blank line following the body.
    # We look for the typical "N files changed" summary line to split.
    body_lines = []
    stat_lines = []
    in_stat = False
    for line in lines[5:]:
        if not in_stat:
            # Stat section starts after blank line, and lines contain ' | '
            # or the summary "N file(s) changed"
            if (line.strip() == "" and body_lines and
                    body_lines[-1].strip() == ""):
                in_stat = True
                body_lines.pop()  # remove trailing blank
                continue
            body_lines.append(line)
        else:
            stat_lines.append(line)
    body = "\n".join(body_lines).strip()
    stat = "\n".join(stat_lines).strip()

    # Full diff in a separate call
    diff_cmd = (f"git -C {qrepo} show --format= --patch {qhash}")
    diff = ""
    try:
        r2 = ssh_run(user, host, diff_cmd, timeout=60, port=port)
        if r2.returncode == 0:
            diff = r2.stdout
    except (subprocess.TimeoutExpired, OSError):
        pass

    return {
        "sha": sha,
        "author": author,
        "email": email,
        "date": date,
        "subject": subject,
        "body": body,
        "stat": stat,
        "diff": diff,
    }


# --- Convenience helpers for project detection ---

def is_remote_project(project_info: dict) -> bool:
    """Return True if a project dict represents a remote (SSH) project.

    The single authoritative test: the dict contains a ``"host"`` key.
    """
    return bool(project_info.get("host"))


# --- Host metrics collection ---

_METRICS_SCRIPT = r'''
hostname=$(hostname)
os_name=$(. /etc/os-release 2>/dev/null && echo "$NAME $VERSION" || echo "unknown")
kernel=$(uname -r)
uptime_sec=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 0)
load=$(cat /proc/loadavg 2>/dev/null | cut -d' ' -f1-3 || echo "0 0 0")
cpu_count=$(nproc 2>/dev/null || grep -c ^processor /proc/cpuinfo 2>/dev/null || echo 1)
mem_total=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || echo 0)
mem_avail=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null || echo 0)
echo "HOSTNAME=$hostname"
echo "OS=$os_name"
echo "KERNEL=$kernel"
echo "UPTIME=$uptime_sec"
echo "LOAD=$load"
echo "CPUS=$cpu_count"
echo "MEM_TOTAL=$mem_total"
echo "MEM_AVAIL=$mem_avail"
df -BG --output=target,size,used,avail,pcent -x tmpfs -x devtmpfs -x squashfs 2>/dev/null | tail -n+2 | while read mnt sz used avail pct; do
  echo "DISK=$mnt $sz $used $avail $pct"
done
'''

_host_metrics_cache: Dict[str, Tuple[float, dict]] = {}
_HOST_METRICS_CACHE_TTL = 120.0  # 2 minutes


def _parse_metrics_output(output: str) -> dict:
    """Parse KEY=VALUE lines from host metrics script output."""
    metrics: dict = {
        "hostname": "",
        "os": "",
        "kernel": "",
        "uptime_sec": 0,
        "load_1": 0.0,
        "load_5": 0.0,
        "load_15": 0.0,
        "cpus": 1,
        "mem_total_kb": 0,
        "mem_avail_kb": 0,
        "mem_pct": 0,
        "disks": [],
    }
    for line in output.strip().splitlines():
        line = line.strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if key == "HOSTNAME":
            metrics["hostname"] = value
        elif key == "OS":
            metrics["os"] = value
        elif key == "KERNEL":
            metrics["kernel"] = value
        elif key == "UPTIME":
            try:
                metrics["uptime_sec"] = int(value)
            except ValueError:
                pass
        elif key == "LOAD":
            parts = value.split()
            try:
                if len(parts) >= 1:
                    metrics["load_1"] = float(parts[0])
                if len(parts) >= 2:
                    metrics["load_5"] = float(parts[1])
                if len(parts) >= 3:
                    metrics["load_15"] = float(parts[2])
            except ValueError:
                pass
        elif key == "CPUS":
            try:
                metrics["cpus"] = max(1, int(value))
            except ValueError:
                pass
        elif key == "MEM_TOTAL":
            try:
                metrics["mem_total_kb"] = int(value)
            except ValueError:
                pass
        elif key == "MEM_AVAIL":
            try:
                metrics["mem_avail_kb"] = int(value)
            except ValueError:
                pass
        elif key == "DISK":
            parts = value.split()
            if len(parts) >= 5:
                metrics["disks"].append({
                    "mount": parts[0],
                    "size": parts[1],
                    "used": parts[2],
                    "avail": parts[3],
                    "pct": parts[4].rstrip("%"),
                })
    # Compute memory percentage
    total = metrics["mem_total_kb"]
    avail = metrics["mem_avail_kb"]
    if total > 0:
        metrics["mem_pct"] = round((total - avail) / total * 100)
    return metrics


def ssh_get_host_metrics(user: str, host: str, port: int = 22,
                         timeout: int = 10) -> dict:
    """Gather system metrics from a remote host (single SSH call).

    Returns a dict with hostname, OS, kernel, uptime, load, memory, disk info.
    Returns an error dict on failure.
    """
    cache_key = f"{user}@{host}:{port}"
    now = time.monotonic()
    if cache_key in _host_metrics_cache:
        ts, cached = _host_metrics_cache[cache_key]
        if now - ts < _HOST_METRICS_CACHE_TTL:
            return cached

    empty: dict = {"error": True, "hostname": host}
    try:
        r = ssh_run(user, host, f"bash -c {shlex.quote(_METRICS_SCRIPT)}",
                    timeout=timeout, port=port)
        if r.returncode != 0:
            _host_metrics_cache[cache_key] = (now, empty)
            return empty
        metrics = _parse_metrics_output(r.stdout)
        _host_metrics_cache[cache_key] = (now, metrics)
        return metrics
    except (subprocess.TimeoutExpired, OSError, ValueError):
        _host_metrics_cache[cache_key] = (now, empty)
        return empty


def invalidate_host_metrics_cache(host: str = "") -> None:
    """Clear cached host metrics.  If *host* is given, clear only that host."""
    if host:
        keys = [k for k in _host_metrics_cache if host in k]
        for k in keys:
            del _host_metrics_cache[k]
    else:
        _host_metrics_cache.clear()


def get_all_host_metrics(projects: dict) -> dict:
    """Gather metrics for all unique remote hosts referenced by *projects*.

    Returns ``{host: metrics_dict}`` from cache or fresh fetch.
    """
    hosts: Dict[str, Tuple[str, int]] = {}  # host -> (user, port)
    for _path, pinfo in projects.items():
        if not is_remote_project(pinfo):
            continue
        host = pinfo.get("host", "")
        if not host or host in hosts:
            continue
        user = pinfo.get("user", "")
        try:
            addr, port = ssh_resolve_address(user, host)
        except Exception:
            addr, port = host, 22
        hosts[host] = (user, addr, port)

    result: dict = {}
    for host, (user, addr, port) in hosts.items():
        result[host] = ssh_get_host_metrics(user, addr, port=port)
    return result
