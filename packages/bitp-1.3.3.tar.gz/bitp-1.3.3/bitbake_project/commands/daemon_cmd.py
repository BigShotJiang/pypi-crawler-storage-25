#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""CLI commands for the auto-update daemon.

These read heartbeat/state files directly — they work even when
``bit serve`` is running on a different terminal.
"""

import sys

from ..daemon import (
    check_daemon_health,
    get_daemon_interval,
    load_state,
    save_state,
    set_daemon_interval,
)


def run_daemon_command(args) -> int:
    """Dispatch ``bit serve/daemon <subcommand>``."""
    sub = getattr(args, "serve_command", None)
    if sub == "status":
        return run_daemon_status(args)
    if sub == "log":
        return run_daemon_log(args)
    if sub == "pause":
        return run_daemon_pause(args)
    if sub == "resume":
        return run_daemon_resume(args)
    if sub == "interval":
        return run_daemon_interval(args)
    # No subcommand — show status
    return run_daemon_status(args)


def run_daemon_status(args) -> int:
    """Show daemon health and per-project status."""
    health = check_daemon_health()
    status = health["status"]
    detail = health["detail"]

    # Status line
    indicators = {
        "running": "\033[32m●\033[0m",   # green
        "paused": "\033[33m●\033[0m",    # amber
        "stale": "\033[33m●\033[0m",     # amber
        "dead": "\033[31m●\033[0m",      # red
        "stopped": "\033[31m○\033[0m",   # red hollow
        "not_configured": "\033[90m○\033[0m",  # grey
    }
    indicator = indicators.get(status, "?")
    print(f"Daemon: {indicator} {status} — {detail}")

    if status == "not_configured":
        print("\nTo enable: tag a project with 'auto-update' and run 'bit serve'")
        return 0

    if status == "stopped":
        print("\nRun 'bit serve' to start the server and auto-update daemon")
        return 0

    # Global interval
    interval = get_daemon_interval()
    print(f"Default interval: {interval} minutes")

    # Per-project state
    state = load_state()
    projects = state.get("projects", {})
    if projects:
        print(f"\nProjects ({len(projects)}):")
        for path, pstate in projects.items():
            last = pstate.get("last_check", "never")
            next_c = pstate.get("next_check", "—")
            repos = pstate.get("repos", {})
            updated = sum(1 for r in repos.values() if r.get("result") == "updated")
            pending = sum(1 for r in repos.values() if r.get("commits", 0) > 0
                         and r.get("result") != "updated")
            name = os.path.basename(path)
            print(f"  {name}: last={last}  next={next_c}  "
                  f"updated={updated}  pending={pending}")
    else:
        print("\nNo projects checked yet.")

    return 0


def run_daemon_log(args) -> int:
    """Show recent daemon log entries."""
    state = load_state()
    log = state.get("log", [])
    count = getattr(args, "count", 20) or 20

    if not log:
        print("No daemon log entries.")
        return 0

    entries = log[-count:]
    for entry in entries:
        ts = entry.get("timestamp", "?")
        project = os.path.basename(entry.get("project", "?"))
        repo = entry.get("repo") or "—"
        action = entry.get("action", "?")
        detail = entry.get("detail", "")
        print(f"  {ts}  {project}/{repo}  {action}: {detail}")

    total = len(log)
    if total > count:
        print(f"\n  (showing {count} of {total} entries)")
    return 0


def run_daemon_pause(args) -> int:
    """Pause auto-updates."""
    state = load_state()
    if state.get("paused"):
        print("Daemon is already paused.")
        return 0
    state["paused"] = True
    save_state(state)
    print("Daemon paused. Use 'bit serve resume' to resume.")
    return 0


def run_daemon_resume(args) -> int:
    """Resume auto-updates."""
    state = load_state()
    if not state.get("paused"):
        print("Daemon is not paused.")
        return 0
    state["paused"] = False
    save_state(state)
    print("Daemon resumed.")
    return 0


def run_daemon_interval(args) -> int:
    """Set or show the global default interval."""
    minutes = getattr(args, "minutes", None)
    if minutes is None:
        current = get_daemon_interval()
        print(f"Current daemon interval: {current} minutes")
        return 0
    if minutes < 1:
        print("Interval must be at least 1 minute.", file=sys.stderr)
        return 1
    set_daemon_interval(minutes)
    print(f"Daemon interval set to {minutes} minutes.")
    return 0


# Need os for basename calls
import os
