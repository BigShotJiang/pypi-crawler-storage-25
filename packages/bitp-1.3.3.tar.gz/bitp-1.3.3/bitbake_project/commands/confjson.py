#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Parser for bitbake-setup .conf.json configuration files.

Parses Configuration Template files used by bitbake-setup to describe
which repos to clone, which layers to enable, and which OE fragments to apply.
"""

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class ConfSource:
    """A source repository from a .conf.json file."""
    name: str                            # e.g., "openembedded-core"
    path: str                            # relative dest in layers/ dir
    git_url: str                         # primary URI (first remote or "uri" field)
    remotes: Dict[str, str] = field(default_factory=dict)  # name -> URI
    branch: str = ""                     # branch name
    rev: str = ""                        # branch name or commit hash
    is_local: bool = False               # local path source (symlink)
    local_path: str = ""                 # expanded local path


@dataclass
class ConfOneOfOption:
    """A single option in an oe-fragments-one-of category."""
    name: str                            # fragment path, e.g., "machine/qemux86-64"
    description: str = ""


@dataclass
class ConfOneOfCategory:
    """A category of one-of fragment options (e.g., machine, distro)."""
    description: str
    options: List[ConfOneOfOption] = field(default_factory=list)


@dataclass
class ConfConfig:
    """A flattened leaf configuration from the configurations tree."""
    name: str                            # e.g., "qemux86-64-poky"
    description: str = ""
    bb_layers: List[str] = field(default_factory=list)        # paths relative to layers/
    oe_fragments: List[str] = field(default_factory=list)     # e.g., ["core/yocto/sstate-mirror-cdn"]
    oe_fragments_one_of: Dict[str, ConfOneOfCategory] = field(default_factory=dict)


@dataclass
class ConfJson:
    """Parsed representation of a .conf.json file."""
    version: str = ""
    description: str = ""
    sources: List[ConfSource] = field(default_factory=list)
    configurations: List[ConfConfig] = field(default_factory=list)


# =============================================================================
# Parsing
# =============================================================================

def _parse_source(name: str, src: dict) -> ConfSource:
    """Parse a single source entry from the sources dict."""
    # Check for local source
    local = src.get("local")
    if local:
        local_path = os.path.expanduser(local.get("path", ""))
        return ConfSource(
            name=name,
            path=src.get("path", name),
            git_url="",
            is_local=True,
            local_path=local_path,
        )

    # Git remote source
    git_remote = src.get("git-remote", {})
    git_url = ""
    remotes: Dict[str, str] = {}

    # Two formats: direct "uri" or nested "remotes"
    if "uri" in git_remote:
        git_url = git_remote["uri"]
    elif "remotes" in git_remote:
        for remote_name, remote_info in git_remote["remotes"].items():
            uri = remote_info.get("uri", "")
            remotes[remote_name] = uri
            if not git_url:
                git_url = uri  # Use first remote as primary URL

    branch = git_remote.get("branch", "")
    rev = git_remote.get("rev", "")

    return ConfSource(
        name=name,
        path=src.get("path", name),
        git_url=git_url,
        remotes=remotes,
        branch=branch,
        rev=rev,
    )


def _parse_one_of(raw: dict) -> Dict[str, ConfOneOfCategory]:
    """Parse oe-fragments-one-of into category dict."""
    result: Dict[str, ConfOneOfCategory] = {}
    for cat_name, cat_data in raw.items():
        desc = cat_data.get("description", "")
        options = []
        for opt in cat_data.get("options", []):
            if isinstance(opt, str):
                # Simple string format: "machine/qemux86-64"
                options.append(ConfOneOfOption(name=opt))
            elif isinstance(opt, dict):
                # Named format: {"name": "machine/qemux86-64", "description": "..."}
                options.append(ConfOneOfOption(
                    name=opt.get("name", ""),
                    description=opt.get("description", ""),
                ))
        result[cat_name] = ConfOneOfCategory(description=desc, options=options)
    return result


def flatten_configurations(
    configs: list,
    parent_layers: Optional[List[str]] = None,
    parent_fragments: Optional[List[str]] = None,
    parent_one_of: Optional[Dict[str, ConfOneOfCategory]] = None,
) -> List[ConfConfig]:
    """
    Recursively flatten the configurations tree.

    Child configurations inherit parent's bb-layers, oe-fragments (concatenated),
    and oe-fragments-one-of (merged). Only leaf configs (those with a name and
    no further nested children, or named children) become entries in the flat list.

    If a config has name AND nested configurations, it's treated as a non-leaf parent
    unless none of the children have names (in which case it IS the leaf).
    """
    if parent_layers is None:
        parent_layers = []
    if parent_fragments is None:
        parent_fragments = []
    if parent_one_of is None:
        parent_one_of = {}

    result: List[ConfConfig] = []

    for cfg in configs:
        # Accumulate layers, fragments, one-of from this level
        current_layers = parent_layers + cfg.get("bb-layers", [])
        current_fragments = parent_fragments + cfg.get("oe-fragments", [])

        # Merge one-of: parent categories + this level's categories
        current_one_of = dict(parent_one_of)
        raw_one_of = cfg.get("oe-fragments-one-of", {})
        if raw_one_of:
            parsed = _parse_one_of(raw_one_of)
            current_one_of.update(parsed)

        children = cfg.get("configurations", [])
        name = cfg.get("name", "")
        description = cfg.get("description", "")

        if children:
            # Has children - always recurse to find leaf nodes
            result.extend(flatten_configurations(
                children, current_layers, current_fragments, current_one_of,
            ))

            # If this node has a name but none of the children do, treat this as a leaf too
            named_children = [c for c in children if c.get("name")]
            if name and not named_children:
                result.append(ConfConfig(
                    name=name,
                    description=description,
                    bb_layers=current_layers,
                    oe_fragments=current_fragments,
                    oe_fragments_one_of=current_one_of,
                ))
        elif name:
            # Leaf node with a name
            result.append(ConfConfig(
                name=name,
                description=description,
                bb_layers=current_layers,
                oe_fragments=current_fragments,
                oe_fragments_one_of=current_one_of,
            ))

    return result


def parse_conf_json_data(data: dict) -> ConfJson:
    """
    Parse a .conf.json dict into a ConfJson object.

    Args:
        data: Parsed JSON dict from a .conf.json file.

    Returns:
        Parsed ConfJson with sources and flattened configurations.

    Raises:
        KeyError: If required fields are missing.
    """
    version = data.get("version", "")
    description = data.get("description", "")

    sources = []
    raw_sources = data.get("sources", {})
    for name, src in raw_sources.items():
        sources.append(_parse_source(name, src))

    bitbake_setup = data.get("bitbake-setup", {})
    raw_configs = bitbake_setup.get("configurations", [])
    configurations = flatten_configurations(raw_configs)

    return ConfJson(
        version=version,
        description=description,
        sources=sources,
        configurations=configurations,
    )


def parse_conf_json(path: str) -> ConfJson:
    """
    Parse a .conf.json file into a ConfJson object.

    Args:
        path: Path to the .conf.json file.

    Returns:
        Parsed ConfJson with sources and flattened configurations.

    Raises:
        FileNotFoundError: If file doesn't exist.
        json.JSONDecodeError: If file is not valid JSON.
        KeyError: If required fields are missing.
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return parse_conf_json_data(data)


# =============================================================================
# Registry Discovery
# =============================================================================

_BUILTIN_REGISTRY_CACHE = os.path.expanduser(
    os.path.join("~", ".config", "bit", "builtin-registry")
)
_BITBAKE_URL = "https://git.openembedded.org/bitbake"
# Re-fetch if cache is older than 7 days
_CACHE_MAX_AGE_SECS = 7 * 24 * 60 * 60


def _builtin_registry_cache_path() -> str:
    """Return the path to the cached built-in registry."""
    return _BUILTIN_REGISTRY_CACHE


def _cache_is_stale() -> bool:
    """Check if the cached registry needs refreshing.

    Uses a two-tier check:
      1. Fast path: skip if cache was checked less than 1 day ago.
      2. Slow path: compare remote HEAD SHA against cached SHA via git ls-remote.
    """
    stamp = os.path.join(_BUILTIN_REGISTRY_CACHE, ".last-update")
    if not os.path.isfile(stamp):
        return True
    try:
        import time
        with open(stamp) as f:
            data = f.read().strip().splitlines()
        ts = float(data[0]) if data else 0
        cached_sha = data[1].strip() if len(data) > 1 else ""

        # Fast path: don't bother checking remote if checked recently
        age = time.time() - ts
        if age < _CACHE_MAX_AGE_SECS:
            return False

        # Slow path: check if remote HEAD has changed
        if cached_sha:
            import subprocess
            result = subprocess.run(
                ["git", "ls-remote", "--heads", _BITBAKE_URL, "master"],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0 and result.stdout.strip():
                remote_sha = result.stdout.strip().split()[0]
                if remote_sha == cached_sha:
                    # Remote unchanged — update timestamp, skip re-clone
                    with open(stamp, "w") as f:
                        f.write(f"{time.time()}\n{cached_sha}\n")
                    return False
        return True
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return True


def update_builtin_registry(branch: str = "master", quiet: bool = False) -> bool:
    """Fetch the built-in registry from bitbake into the local cache.

    Shallow-clones bitbake into a temp directory, copies default-registry/
    into ~/.config/bit/builtin-registry/, and cleans up.  Records the
    HEAD SHA so subsequent staleness checks can use git ls-remote
    instead of re-cloning.

    Returns True on success.
    """
    import shutil
    import subprocess
    import tempfile
    import time

    if not quiet:
        print("Updating built-in registry cache...", end=" ", flush=True)

    tmpdir = tempfile.mkdtemp(prefix="bit-registry-")
    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", "-b", branch,
             _BITBAKE_URL, tmpdir],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            if not quiet:
                print("failed")
                logger.warning("git clone failed: %s", result.stderr.strip())
            return False

        src = os.path.join(tmpdir, "default-registry")
        if not os.path.isdir(src):
            if not quiet:
                print("no registry found in bitbake")
            return False

        # Get the HEAD SHA for future staleness checks
        head_sha = ""
        rev_result = subprocess.run(
            ["git", "-C", tmpdir, "rev-parse", "HEAD"],
            capture_output=True, text=True,
        )
        if rev_result.returncode == 0:
            head_sha = rev_result.stdout.strip()

        # Replace cache atomically
        if os.path.isdir(_BUILTIN_REGISTRY_CACHE):
            shutil.rmtree(_BUILTIN_REGISTRY_CACHE)
        shutil.copytree(src, _BUILTIN_REGISTRY_CACHE)

        # Write timestamp + SHA
        with open(os.path.join(_BUILTIN_REGISTRY_CACHE, ".last-update"), "w") as f:
            f.write(f"{time.time()}\n{head_sha}\n")

        if not quiet:
            count = sum(1 for _r, _d, files in os.walk(_BUILTIN_REGISTRY_CACHE)
                        for fn in files if fn.endswith(".conf.json"))
            print(f"done ({count} configs)")
        return True
    except (subprocess.TimeoutExpired, OSError) as e:
        if not quiet:
            print("failed")
            logger.warning("Registry update error: %s", e)
        return False
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


_OE_CORE_URL = "https://git.openembedded.org/openembedded-core"
_META_YOCTO_URL = "https://git.yoctoproject.org/meta-yocto"

# Bitbake uses numeric version branches, not OE release codenames.
# Map OE release → bitbake branch.  "master" maps to itself.
_BITBAKE_BRANCH_MAP = {
    "master": "master",
    "dunfell": "1.46",
    "gatesgarth": "1.48",
    "hardknott": "1.50",
    "honister": "1.52",
    "kirkstone": "2.0",
    "langdale": "2.2",
    "mickledore": "2.4",
    "nanbield": "2.6",
    "scarthgap": "2.8",
    "styhead": "2.10",
    "walneal": "2.12",
}

# Branches to exclude from synthetic config generation
_BRANCH_EXCLUDES = frozenset({
    "master-next", "master-uninative", "1.0_M1", "1.0_M2", "1.0_M3",
    "1.0_M4", "1.0_M5",
})

# Cache file for discovered branches
_BRANCHES_CACHE = os.path.expanduser(
    os.path.join("~", ".config", "bit", "branches.json")
)
_BRANCHES_CACHE_MAX_AGE = 7 * 24 * 60 * 60  # 7 days


def discover_oe_branches(quiet: bool = False) -> List[str]:
    """Discover available OpenEmbedded release branches via git ls-remote.

    Returns branch names from openembedded-core, cached for 7 days.
    Excludes internal/test branches and numeric-only bitbake version branches.
    """
    import time

    # Check cache
    if os.path.isfile(_BRANCHES_CACHE):
        try:
            with open(_BRANCHES_CACHE) as f:
                cache = json.load(f)
            if time.time() - cache.get("timestamp", 0) < _BRANCHES_CACHE_MAX_AGE:
                return cache.get("branches", [])
        except (json.JSONDecodeError, OSError):
            pass

    # Fetch from remote
    if not quiet:
        print("Discovering available branches...", end=" ", flush=True)
    import subprocess
    try:
        result = subprocess.run(
            ["git", "ls-remote", "--heads", _OE_CORE_URL],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            if not quiet:
                print("failed")
            return []
    except (subprocess.TimeoutExpired, OSError):
        if not quiet:
            print("failed")
        return []

    branches = []
    for line in result.stdout.strip().splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        ref = parts[1]
        if ref.startswith("refs/heads/"):
            name = ref[len("refs/heads/"):]
            # Skip excluded branches and numeric-only (bitbake versions)
            if name in _BRANCH_EXCLUDES:
                continue
            if name.replace(".", "").replace("-", "").isdigit():
                continue
            branches.append(name)

    # Sort: master first, then alphabetical
    branches.sort(key=lambda b: ("" if b == "master" else b))

    # Cache
    try:
        os.makedirs(os.path.dirname(_BRANCHES_CACHE), exist_ok=True)
        with open(_BRANCHES_CACHE, "w") as f:
            json.dump({"timestamp": time.time(), "branches": branches}, f)
    except OSError:
        pass

    if not quiet:
        print(f"done ({len(branches)} branches)")
    return branches


def synthesize_basic_configs(branches: Optional[List[str]] = None,
                             ) -> List[Tuple[str, str, str, "ConfJson", str]]:
    """Generate synthetic 'basic' ConfJson entries for each known branch.

    Returns entries in the same format as discover_registry():
        (filename, full_path, relative_path, parsed_config, source_label)

    The full_path is a synthetic marker (not a real file) used to identify
    these entries during clone.
    """
    if branches is None:
        branches = discover_oe_branches(quiet=True)
    if not branches:
        branches = ["master"]

    results = []
    for branch in branches:
        bb_branch = _BITBAKE_BRANCH_MAP.get(branch)
        if bb_branch is None:
            # Unknown release — skip (no reliable bitbake branch mapping)
            continue
        conf = ConfJson(
            description=f"Basic OE setup ({branch})",
            sources=[
                ConfSource(
                    name="bitbake",
                    path="bitbake",
                    git_url=_BITBAKE_URL,
                    branch=bb_branch,
                    rev=bb_branch,
                ),
                ConfSource(
                    name="openembedded-core",
                    path="openembedded-core",
                    git_url=_OE_CORE_URL,
                    branch=branch,
                    rev=branch,
                ),
                ConfSource(
                    name="meta-yocto",
                    path="meta-yocto",
                    git_url=_META_YOCTO_URL,
                    branch=branch,
                    rev=branch,
                ),
            ],
            configurations=[
                ConfConfig(
                    name="basic",
                    description=f"Clone bitbake + oe-core + meta-yocto ({branch})",
                    bb_layers=["openembedded-core/meta"],
                ),
            ],
        )
        fname = f"basic-{branch}.conf.json"
        # Synthetic marker path — not a real file
        synth_path = f"__synthetic__/{fname}"
        results.append((fname, synth_path, fname, conf, "Basic"))

    return results


def find_registry_dirs() -> List[Tuple[str, str]]:
    """
    Return list of (directory_path, source_label) tuples for registry scanning.

    Priority order:
      1. layers/bitbake/default-registry/ in CWD (project-local)
      2. ~/.config/bit/builtin-registry/ (cached from bitbake)
      3. ~/.config/bit/registry/ (user-configured)
    """
    dirs: List[Tuple[str, str]] = []

    # Project-local bitbake registry
    builtin = os.path.join("layers", "bitbake", "default-registry")
    if os.path.isdir(builtin):
        dirs.append((os.path.abspath(builtin), "Built-in"))
    elif os.path.isdir(_BUILTIN_REGISTRY_CACHE):
        dirs.append((_BUILTIN_REGISTRY_CACHE, "Built-in"))

    # User-configured registry
    user_registry = os.path.expanduser(os.path.join("~", ".config", "bit", "registry"))
    if os.path.isdir(user_registry):
        dirs.append((user_registry, "User"))

    return dirs


def discover_registry(registry_dir: str, source_label: str = "") -> List[Tuple[str, str, str, ConfJson, str]]:
    """
    Recursively find all .conf.json files in a directory.

    Args:
        registry_dir: Directory to scan.
        source_label: Label indicating the source (e.g. "Built-in", "User").

    Returns:
        List of (filename, full_path, relative_path, parsed_config, source_label) tuples.
        Files that fail to parse are skipped with a warning.
    """
    results: List[Tuple[str, str, str, ConfJson, str]] = []

    if not os.path.isdir(registry_dir):
        return results

    for root, _dirs, files in os.walk(registry_dir):
        for fname in sorted(files):
            if not fname.endswith(".conf.json"):
                continue

            full_path = os.path.join(root, fname)
            rel_path = os.path.relpath(full_path, registry_dir)

            try:
                parsed = parse_conf_json(full_path)
                results.append((fname, full_path, rel_path, parsed, source_label))
            except (json.JSONDecodeError, KeyError, OSError) as e:
                logger.warning("Failed to parse %s: %s", full_path, e)

    return results
