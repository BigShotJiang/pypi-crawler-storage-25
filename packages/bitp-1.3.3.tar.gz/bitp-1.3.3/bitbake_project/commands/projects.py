#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Projects command - manage multiple bit working directories."""

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import threading
import time
from typing import Dict, List, Optional, Tuple

from ..core import (
    Colors, get_fzf_color_args, get_fzf_preview_resize_bindings, fzf_available,
    terminal_color, TERMINAL_COLOR_ELEMENTS, ANSI_COLORS,
    get_terminal_color, set_terminal_color, _get_global_colors_file,
    get_color_mode, current_branch, load_defaults,
)
from ..fzf_bindings import get_exit_bindings, get_preview_scroll_bindings, get_action_binding, get_position_binding
from ..tui import ExploreMenuState, DialogType, update_repo_dialog, confirm_action_dialog, text_input_dialog, select_action_dialog
from ..tui.inline_options import InlineOptionsState, build_dashboard_search_menu
from .update import run_single_repo_update
from .common import repo_display_name, log_message, consume_header_message, fzf_message_viewer, build_inline_dialog_lines
from .ssh_remote import (
    parse_remote_uri,
    format_remote_uri,
    is_remote_project,
    ssh_check_connection,
    ssh_path_exists,
    ssh_path_is_empty,
    ssh_run,
    ssh_get_dashboard_summary,
    ssh_get_git_repos,
    ssh_current_branch,
    ssh_run_single_repo_update,
    remote_run_action,
    remote_shell,
    fetch_remote_projects,
    ssh_resolve_address,
    get_host_addresses,
    set_host_addresses,
    get_host_tmux_session,
    set_host_tmux_session,
    ssh_get_host_metrics,
    get_all_host_metrics,
    invalidate_host_metrics_cache,
    _host_metrics_cache,
)


def _input_with_path_complete(prompt: str) -> str:
    """Like input() but with filesystem tab completion."""
    import readline

    def _path_completer(text, state):
        expanded = os.path.expanduser(text)
        if os.path.isdir(expanded) and not expanded.endswith(os.sep):
            expanded += os.sep
        import glob as _glob
        matches = _glob.glob(expanded + "*")
        # Append / to directories
        matches = [m + os.sep if os.path.isdir(m) else m for m in matches]
        return matches[state] if state < len(matches) else None

    old_completer = readline.get_completer()
    old_delims = readline.get_completer_delims()
    try:
        readline.set_completer(_path_completer)
        readline.set_completer_delims(" \t\n")
        readline.parse_and_bind("tab: complete")
        return input(prompt)
    finally:
        readline.set_completer(old_completer)
        readline.set_completer_delims(old_delims)


def _get_projects_file() -> str:
    """Get path to global projects config file."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "projects.json")


def load_projects() -> Dict[str, dict]:
    """
    Load projects from config file.

    Returns dict mapping path -> {name, description, last_used}.
    Excludes internal keys like __current_project__, __directory_browser__, etc.
    """
    projects_file = _get_projects_file()
    if not os.path.isfile(projects_file):
        return {}
    try:
        with open(projects_file, "r") as f:
            data = json.load(f)
            # Filter out internal keys (start with __)
            return {k: v for k, v in data.items() if not k.startswith("__")}
    except (json.JSONDecodeError, OSError):
        return {}


def get_current_project(persona_name: Optional[str] = None) -> Optional[str]:
    """Get the currently active project path, or None if not set.

    Args:
        persona_name: Persona to look up (e.g. "yocto", "generic").
            If None, uses the global default persona.
    """
    config_file = _get_projects_file()
    if not os.path.isfile(config_file):
        return None
    try:
        with open(config_file, "r") as f:
            data = json.load(f)

            # Resolve which persona key to read
            if not persona_name:
                from ..persona import get_global_default_persona
                persona_name = get_global_default_persona()
            per_persona_key = f"__current_project_{persona_name}__"

            # Try per-persona key first, fall back to legacy key for migration
            path = data.get(per_persona_key) or data.get("__current_project__")
            if not path:
                return None
            # Remote projects: check registration instead of filesystem
            projects = {k: v for k, v in data.items() if not k.startswith("__")}
            info = projects.get(path, {})
            if is_remote_project(info):
                return path
            # Local: verify it still exists
            if os.path.isdir(path):
                return path
            return None
    except (json.JSONDecodeError, OSError):
        return None


def find_project_for_directory(directory: Optional[str] = None) -> Optional[str]:
    """Return the registered project path that contains or is contained by `directory`.

    Matching priority (first match wins):
      1. ``directory`` is inside (or equal to) a registered project — deepest wins.
      2. A registered project is inside ``directory`` — shallowest (closest child) wins.

    Case 2 handles the common situation where a project is registered at
    ``.../poky/build`` but the user (or a remote delegate) is at ``.../poky``.

    Resolves symlinks so that a project registered via a symlink path
    still matches when CWD reports the real (resolved) path.
    """
    raw_cwd = directory or os.getcwd()
    cwd = os.path.abspath(raw_cwd)
    cwd_real = os.path.realpath(raw_cwd)
    projects = load_projects()

    # Pass 1: CWD is inside a registered project (deepest match wins)
    best_match: Optional[str] = None
    best_len = 0
    for proj_path in projects:
        proj = os.path.abspath(proj_path)
        proj_real = os.path.realpath(proj_path)
        for c in (cwd, cwd_real):
            for p in (proj, proj_real):
                if c == p or c.startswith(p + os.sep):
                    if len(p) > best_len:
                        best_match = proj_path
                        best_len = len(p)
    if best_match:
        return best_match

    # Pass 2: a registered project is a child of CWD (shallowest wins)
    child_match: Optional[str] = None
    child_len = float("inf")
    for proj_path in projects:
        proj = os.path.abspath(proj_path)
        proj_real = os.path.realpath(proj_path)
        for c in (cwd, cwd_real):
            for p in (proj, proj_real):
                if p.startswith(c + os.sep):
                    if len(p) < child_len:
                        child_match = proj_path
                        child_len = len(p)
    return child_match


def resolve_project_by_name(name: str) -> Optional[str]:
    """Resolve a project short name to its path.

    Matches case-insensitively against registered project names.
    Also accepts a direct path if it matches a registered project.
    Returns the project path or None.
    """
    projects = load_projects()

    # Direct path match
    if name in projects:
        return name

    # Name match (case-insensitive)
    for proj_path, info in projects.items():
        if info.get("name", "").lower() == name.lower():
            return proj_path

    return None


def set_current_project(path: Optional[str], persona_name: Optional[str] = None) -> None:
    """Set the currently active project path (or None to clear).

    Args:
        path: Project path to activate, or None to clear.
        persona_name: Persona key to store under.  If None, looks up the
            project's persona from the registry (falls back to global default).
    """
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # Resolve persona from the project's registry entry if not given
    if not persona_name:
        if path:
            projects = {k: v for k, v in data.items() if not k.startswith("__")}
            info = projects.get(path, {})
            if not info and not parse_remote_uri(path):
                abs_path = os.path.abspath(path)
                info = projects.get(abs_path, {})
            persona_name = info.get("persona") or "yocto"
        else:
            from ..persona import get_global_default_persona
            persona_name = get_global_default_persona()

    per_persona_key = f"__current_project_{persona_name}__"

    if path:
        # Remote URIs keep their format; local paths get normalized
        if parse_remote_uri(path):
            data[per_persona_key] = path
        else:
            data[per_persona_key] = os.path.abspath(path)
    elif per_persona_key in data:
        del data[per_persona_key]

    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def save_projects(projects: Dict[str, dict]) -> None:
    """Save projects to config file, preserving internal __ keys."""
    projects_file = _get_projects_file()
    # Read existing data to preserve internal keys (__preview_layout__, etc.)
    existing: dict = {}
    if os.path.isfile(projects_file):
        try:
            with open(projects_file, "r") as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    # Keep internal keys, replace project entries
    merged = {k: v for k, v in existing.items() if k.startswith("__")}
    merged.update(projects)
    try:
        with open(projects_file, "w") as f:
            json.dump(merged, f, indent=2)
    except OSError as e:
        print(f"Warning: Could not save projects: {e}", file=sys.stderr)


def _find_overlapping_project(
    projects: Dict[str, dict],
    user: str,
    host: str,
    path: str,
) -> Optional[str]:
    """Check if a project overlaps with an existing one on the same host.

    Two projects overlap when one path is a parent or child of the other
    (e.g. ``/home/user/poky`` and ``/home/user/poky/build``).

    Args:
        projects: Current projects dict.
        user: Remote user (empty string for local projects).
        host: Remote host (empty string for local projects).
        path: The path to check.

    Returns:
        The key of the overlapping project, or None.
    """
    norm = os.path.normpath(path)
    for key, entry in projects.items():
        if host:
            # Remote project — must be same user@host
            e_host = entry.get("host", "")
            e_user = entry.get("user", "")
            if e_host != host or e_user != user:
                continue
            existing = os.path.normpath(entry.get("remote_path", ""))
        else:
            # Local project — only compare against other local projects
            if entry.get("host"):
                continue
            existing = os.path.normpath(key)

        # Check parent/child relationship
        if norm == existing:
            continue  # exact match handled separately by callers
        if norm.startswith(existing + "/") or existing.startswith(norm + "/"):
            return key

    return None


def filter_overlapping_projects(projects: Dict[str, dict]) -> Dict[str, dict]:
    """Remove overlapping projects at display time.

    When two projects on the same host have a parent/child path
    relationship (e.g. ``/path/poky`` and ``/path/poky/build``),
    keep the one with the shorter (parent) path.
    """
    # Build a list sorted by path length (shorter first) so parents win
    items = sorted(projects.items(),
                   key=lambda kv: len(kv[1].get("remote_path", kv[0])))
    kept: Dict[str, dict] = {}
    for key, entry in items:
        host = entry.get("host", "")
        user = entry.get("user", "")
        path = os.path.normpath(entry.get("remote_path", key))
        # Check against already-kept projects on same host
        dominated = False
        for kk, kv in kept.items():
            k_host = kv.get("host", "")
            k_user = kv.get("user", "")
            if k_host != host or k_user != user:
                continue
            k_path = os.path.normpath(kv.get("remote_path", kk))
            if path.startswith(k_path + "/") or k_path.startswith(path + "/"):
                dominated = True
                break
        if not dominated:
            kept[key] = entry
    return kept


def load_projects_for_display() -> Dict[str, dict]:
    """Load projects with overlapping entries filtered out.

    Use this for any UI listing (TUI dashboard, web API, project picker).
    Mutation callers that need the full set should use ``load_projects()``
    directly.
    """
    return filter_overlapping_projects(load_projects())


def add_project(path: str, name: Optional[str] = None, description: str = "",
                 persona: Optional[str] = None) -> bool:
    """
    Add a project to the list.

    Args:
        path: Absolute path to the project directory
        name: Display name (defaults to directory basename)
        description: Optional description
        persona: Persona name (None = use default)

    Returns:
        True if added, False if already exists or invalid
    """
    path = os.path.abspath(path)
    if not os.path.isdir(path):
        print(f"Error: Not a directory: {path}", file=sys.stderr)
        return False

    projects = load_projects()
    if path in projects:
        print(f"Project already registered: {path}")
        return False

    if not name:
        name = os.path.basename(path)

    # Auto-detect persona if not explicitly provided
    if not persona:
        from ..persona import detect_persona
        persona = detect_persona(path)

    entry = {
        "name": name,
        "description": description,
        "last_used": None,
    }
    if persona:
        entry["persona"] = persona
    projects[path] = entry
    save_projects(projects)
    print(f"Added project: {name} ({path})")

    # Write .ignore so ripgrep/fd/etc skip build directories
    from .common import write_ignore_file
    if write_ignore_file(path):
        print(f"Wrote {os.path.join(path, '.ignore')} (excludes build*/ from searches)")

    return True


def remove_project(path: str) -> bool:
    """Remove a project from the list."""
    projects = load_projects()
    # Try as-is first (covers remote URIs), then try abspath for local
    if path not in projects:
        path = os.path.abspath(path)
    if path not in projects:
        print(f"Project not found: {path}", file=sys.stderr)
        return False

    name = projects[path].get("name", path)
    is_local = not is_remote_project(projects[path])
    del projects[path]
    save_projects(projects)
    print(f"Removed project: {name}")
    if is_local and os.path.isdir(path):
        print(f"Directory remains at: {path}")
    return True


def _project_key_valid(key: str, projects: dict) -> bool:
    """Check if a project key is valid (exists on disk for local, registered for remote)."""
    if key not in projects:
        return False
    info = projects[key]
    if is_remote_project(info):
        return True  # Remote projects validated at add time
    return os.path.isdir(key)


def add_remote_project(uri: str, name: Optional[str] = None,
                       description: str = "",
                       skip_path_check: bool = False) -> bool:
    """Add a remote SSH project after validating connectivity.

    Args:
        uri: Remote URI in ``user@host:/path`` format
        name: Display name (defaults to basename of remote path)
        description: Optional description
        skip_path_check: Skip SSH path validation (caller already verified/created)

    Returns:
        True if added, False on error
    """
    parsed = parse_remote_uri(uri)
    if not parsed:
        log_message(f"{Colors.red('✗')} Invalid remote URI: {uri} (expected user@host:/path)")
        return False

    user, host, remote_path = parsed
    key = format_remote_uri(user, host, remote_path)

    projects = load_projects()
    if key in projects:
        log_message(f"{Colors.yellow('!')} Already registered: {key}")
        return False

    overlap = _find_overlapping_project(projects, user, host, remote_path)
    if overlap:
        log_message(f"{Colors.yellow('!')} Skipping {key} — overlaps with existing project {overlap}")
        return False

    if not skip_path_check:
        # Validate SSH connectivity (try alternates if configured)
        addr, port = ssh_resolve_address(user, host)
        log_message(f"Checking SSH connection to {host}...")
        if not ssh_check_connection(user, addr, port=port):
            log_message(f"{Colors.red('✗')} Cannot connect to {user}@{host} via SSH")
            return False

        # Validate remote path
        if not ssh_path_exists(user, addr, remote_path, port=port):
            log_message(f"{Colors.red('✗')} Remote path does not exist: {remote_path}")
            return False

    if not name:
        name = os.path.basename(remote_path.rstrip("/"))

    projects[key] = {
        "name": name,
        "description": description,
        "last_used": None,
        "host": host,
        "user": user,
        "remote_path": remote_path,
    }
    save_projects(projects)
    log_message(f"{Colors.green('✓')} Added remote: {name} ({key})")
    return True


def classify_project_path(path: str) -> str:
    """Classify a local path: 'empty' (non-existent or empty dir), 'existing', or 'invalid'."""
    path = os.path.abspath(path)
    if not os.path.exists(path):
        return "empty"
    if not os.path.isdir(path):
        return "invalid"
    if not os.listdir(path):
        return "empty"
    return "existing"


def classify_remote_path(user: str, host: str, rpath: str) -> str:
    """Classify a remote path: 'empty', 'existing', or 'unreachable'."""
    addr, port = ssh_resolve_address(user, host)
    if not ssh_check_connection(user, addr, port=port):
        return "unreachable"
    if not ssh_path_exists(user, addr, rpath, port=port):
        return "empty"
    if ssh_path_is_empty(user, addr, rpath, port=port):
        return "empty"
    return "existing"


def sync_from_remote(host_spec: str) -> int:
    """Pull projects from a remote bit instance and refresh remote metadata.

    New projects are added; existing projects get their remote_tags and
    remote_persona refreshed (local tags and hidden_tags are preserved).

    Args:
        host_spec: "user@host" or just "host" (user defaults to current)

    Returns number of projects added, or -1 on SSH connection failure.
    """
    if "@" in host_spec:
        user, host = host_spec.split("@", 1)
    else:
        user = os.environ.get("USER", "")
        host = host_spec

    addr, port = ssh_resolve_address(user, host)
    if not ssh_check_connection(user, addr, port=port):
        return -1

    remote_list = fetch_remote_projects(user, addr, port=port)
    if not remote_list:
        return 0

    projects = load_projects()
    added = 0
    refreshed = False
    for rp in remote_list:
        uri = format_remote_uri(user, host, rp["path"])
        if uri in projects:
            # Refresh remote-sourced fields; preserve local tags/hidden_tags
            projects[uri]["remote_tags"] = rp.get("tags", [])
            projects[uri]["remote_persona"] = rp.get("persona", "yocto")
            projects[uri]["description"] = rp.get("description", "")
            projects[uri]["name"] = rp["name"]
            refreshed = True
            continue
        if _find_overlapping_project(projects, user, host, rp["path"]):
            continue  # parent/child of an existing project
        projects[uri] = {
            "name": rp["name"],
            "description": rp.get("description", ""),
            "last_used": None,
            "host": host,
            "user": user,
            "remote_path": rp["path"],
            "remote_tags": rp.get("tags", []),
            "remote_persona": rp.get("persona", "yocto"),
        }
        added += 1

    if added or refreshed:
        save_projects(projects)

    return added


def _detect_project_info(path: str) -> dict:
    """Detect info about a potential project directory."""
    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
    }

    # Check for bblayers.conf in build/conf or any conf directory
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 3:
            dirs[:] = []
            continue
        if "bblayers.conf" in files:
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Count layers
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 4:
            dirs[:] = []
            continue
        if "layer.conf" in files and "conf" in root:
            info["layer_count"] += 1

    # Get git branch if in a git repo
    try:
        result = subprocess.run(
            ["git", "-C", path, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
    except Exception:
        pass

    return info


_project_info_cache: Dict[str, Tuple[float, dict]] = {}
_CACHE_TTL = 30.0


def _detect_project_info_fast(path: str) -> dict:
    """Detect project info with caching and fast checks.

    Uses a 30s TTL cache. Checks only standard bblayers.conf locations
    (conf/ and build/conf/) instead of walking the tree. Falls back to
    full _detect_project_info() for layer count on first load.
    """
    now = time.monotonic()
    if path in _project_info_cache:
        ts, cached = _project_info_cache[path]
        if now - ts < _CACHE_TTL:
            return cached

    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
        "is_dirty": False,
        "ahead": 0,
        "behind": 0,
    }

    if not os.path.isdir(path):
        _project_info_cache[path] = (now, info)
        return info

    # Fast check: bblayers.conf in standard locations only
    for subdir in ("conf", "build/conf"):
        if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Find primary git repo — project root first, then common Yocto subdirs
    git_dir = None
    if os.path.isdir(os.path.join(path, ".git")):
        git_dir = path
    else:
        for subdir in ("poky", "oe-core", "openembedded-core"):
            candidate = os.path.join(path, subdir)
            if os.path.isdir(os.path.join(candidate, ".git")):
                git_dir = candidate
                break
        # Fallback: first git repo in immediate subdirectories
        if not git_dir:
            try:
                for entry in os.scandir(path):
                    if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                        if os.path.isdir(os.path.join(entry.path, ".git")):
                            git_dir = entry.path
                            break
            except OSError:
                pass

    # Git checks on primary repo
    if git_dir:
        try:
            result = subprocess.run(
                ["git", "-C", git_dir, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0:
                info["branch"] = result.stdout.strip()
        except Exception:
            pass

        if info["branch"]:
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "status", "--porcelain", "-uno", "--no-renames"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0 and r.stdout.strip():
                    info["is_dirty"] = True
            except Exception:
                pass
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0:
                    parts = r.stdout.strip().split()
                    if len(parts) == 2:
                        info["ahead"] = int(parts[0])
                        info["behind"] = int(parts[1])
            except Exception:
                pass

    # Layer count: reuse from previous cache if available, else full walk
    if path in _project_info_cache:
        _, old = _project_info_cache[path]
        if old.get("layer_count", 0) > 0:
            info["layer_count"] = old["layer_count"]
        else:
            full = _detect_project_info(path)
            info["layer_count"] = full.get("layer_count", 0)
    else:
        full = _detect_project_info(path)
        info["layer_count"] = full.get("layer_count", 0)

    # Merge in persona-specific project info (e.g. type detection)
    try:
        from ..persona import get_persona
        projects_data = load_projects()
        proj_entry = projects_data.get(path, {})
        persona = get_persona(project=proj_entry)
        persona_info = persona.detect_project_info(path)
        info.update(persona_info)
    except Exception:
        pass

    _project_info_cache[path] = (now, info)
    return info


_dashboard_summary_cache: Dict[str, Tuple[float, dict]] = {}

# Background remote summary fetching
_remote_fetch_lock = threading.Lock()
_remote_fetch_pending: set = set()  # paths currently being fetched in background

# Web server state
_web_server_port: int = 0
_web_server_host: str = ""


def _web_pid_file() -> str:
    """Return path to the web server PID file."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "web.pid")


def _read_web_pid_file() -> Optional[dict]:
    """Read PID file, return {pid, host, port} or None."""
    path = _web_pid_file()
    try:
        with open(path) as f:
            data = json.load(f)
        if "pid" in data and "host" in data and "port" in data:
            return data
    except (OSError, json.JSONDecodeError, KeyError):
        pass
    return None


def _find_web_server() -> Optional[dict]:
    """Check if web server PID is alive. Returns {pid, host, port} or None.

    Cleans stale PID files automatically.
    """
    import signal as _sig
    data = _read_web_pid_file()
    if data is None:
        return None
    try:
        os.kill(data["pid"], 0)
        return data
    except (OSError, ProcessLookupError):
        # Stale PID file — clean up
        try:
            os.unlink(_web_pid_file())
        except OSError:
            pass
        return None


def _stop_web_server() -> None:
    """Send SIGTERM to web server and wait up to 3s for exit."""
    import signal as _sig
    data = _read_web_pid_file()
    if data is None:
        return
    pid = data["pid"]
    try:
        os.kill(pid, _sig.SIGTERM)
    except (OSError, ProcessLookupError):
        pass
    # Wait up to 3s for process to exit
    for _ in range(30):
        try:
            os.kill(pid, 0)
            time.sleep(0.1)
        except (OSError, ProcessLookupError):
            break
    # Clean PID file
    try:
        os.unlink(_web_pid_file())
    except OSError:
        pass


def _launch_web_server(port: int = 8123, host: str = "127.0.0.1") -> str:
    """Launch web server as detached subprocess if not already running.

    Returns a status message string for the dashboard header.
    """
    global _web_server_port, _web_server_host

    url = f"http://{host}:{port}"

    # Already running?
    existing = _find_web_server()
    if existing:
        _web_server_port = existing["port"]
        _web_server_host = existing["host"]
        existing_url = f"http://{existing['host']}:{existing['port']}"
        # Open browser if configured
        if get_web_open_browser():
            threading.Thread(
                target=lambda: __import__("webbrowser").open(existing_url),
                daemon=True,
            ).start()
        return f"bit server already running at {existing_url}"

    # Spawn detached subprocess: bit serve --foreground --port PORT --host HOST --no-browser
    # Use sys.argv[0] when it's a real file (zipapp, script) so the child
    # runs the same entry-point; fall back to ``python -m`` for dev installs.
    argv0 = sys.argv[0] if sys.argv else ""
    if argv0 and os.path.isfile(argv0):
        cmd = [sys.executable, argv0, "serve", "--foreground",
               "--port", str(port), "--host", host, "--no-browser"]
    else:
        cmd = [sys.executable, "-m", "bitbake_project", "serve", "--foreground",
               "--port", str(port), "--host", host, "--no-browser"]

    log_path = os.path.join(os.path.expanduser("~/.config/bit"), "web.log")
    try:
        log_file = open(log_path, "a")
    except OSError:
        log_file = subprocess.DEVNULL

    proc = subprocess.Popen(
        cmd,
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=log_file,
        stderr=log_file,
    )
    if hasattr(log_file, "close"):
        log_file.close()

    # Write PID file from parent (server will overwrite after successful bind)
    try:
        with open(_web_pid_file(), "w") as f:
            json.dump({"pid": proc.pid, "host": host, "port": port}, f)
    except OSError:
        pass

    # Brief check — catch immediate failures (port in use, etc.)
    time.sleep(0.3)
    try:
        os.kill(proc.pid, 0)
    except (OSError, ProcessLookupError):
        # Process died immediately
        try:
            os.unlink(_web_pid_file())
        except OSError:
            pass
        return f"Failed to start bit server on {url} — check ~/.config/bit/web.log"

    _web_server_port = port
    _web_server_host = host

    # Open browser in background if configured
    if get_web_open_browser():
        threading.Thread(
            target=lambda: __import__("webbrowser").open(url),
            daemon=True,
        ).start()

    return f"bit server started at {url}"


def check_daemon_status_line() -> str:
    """Return a short daemon status string for dashboard headers."""
    try:
        from ..daemon import check_daemon_health
        health = check_daemon_health()
        status = health["status"]
        if status == "not_configured":
            return ""
        if status == "running":
            count = health.get("heartbeat", {}).get("projects_checked", 0)
            return f"Daemon: active ({count} checked)"
        if status == "paused":
            return "Daemon: paused"
        if status == "stale":
            return "Daemon: stale (check logs)"
        if status == "dead":
            return "Daemon: crashed"
        if status == "stopped":
            return "Daemon: server not running"
        return ""
    except Exception:
        return ""


def _relative_time(epoch: float) -> str:
    """Format an epoch timestamp as a relative time string."""
    secs = int(time.time() - epoch)
    if secs < 0:
        return "just now"
    if secs < 60:
        return "just now"
    if secs < 3600:
        return f"{secs // 60}m ago"
    if secs < 86400:
        return f"{secs // 3600}h ago"
    return f"{secs // 86400}d ago"


def _get_last_updated(project_path: str) -> str:
    """Most recent HEAD change across a project's repos, as relative time.

    Looks at the HEAD reflog timestamp — updated on pull, rebase, merge,
    commit, checkout, but *not* on bare fetch.  This answers "when did
    the git history last change?" rather than "when did we last check?".
    Falls back to HEAD symref mtime if reflog is unavailable.
    Returns '' if no signal found.
    """
    try:
        git_repos = _get_project_git_repos(project_path)
        latest = 0.0
        for repo in git_repos:
            # Try reflog first — most accurate
            reflog = os.path.join(repo, ".git", "logs", "HEAD")
            if os.path.isfile(reflog):
                mt = os.path.getmtime(reflog)
                if mt > latest:
                    latest = mt
                continue
            # Fallback: packed-refs or HEAD file mtime
            head = os.path.join(repo, ".git", "HEAD")
            if os.path.isfile(head):
                mt = os.path.getmtime(head)
                if mt > latest:
                    latest = mt
        if latest == 0.0:
            return ""
        return _relative_time(latest)
    except Exception:
        return ""


def _get_daemon_last_checked(project_path: str) -> str:
    """Return relative time since daemon last checked this project, or ''."""
    try:
        from ..daemon import load_state
        from datetime import datetime, timezone
        state = load_state()
        proj = state.get("projects", {}).get(project_path, {})
        last_check = proj.get("last_check")
        if not last_check:
            return ""
        last_dt = datetime.fromisoformat(last_check)
        return _relative_time(last_dt.timestamp())
    except Exception:
        return ""


def _get_daemon_next_check(project_path: str) -> str:
    """Return relative time until next daemon check, or ''."""
    try:
        from ..daemon import load_state
        from datetime import datetime, timezone
        state = load_state()
        proj = state.get("projects", {}).get(project_path, {})
        next_check = proj.get("next_check")
        if not next_check:
            return ""
        next_dt = datetime.fromisoformat(next_check)
        remaining = int((next_dt - datetime.now(timezone.utc)).total_seconds())
        if remaining <= 0:
            return "soon"
        if remaining < 3600:
            return f"{remaining // 60}m"
        return f"{remaining // 3600}h"
    except Exception:
        return ""


def _prompt_web_server_exit() -> None:
    """Prompt user to keep or stop the web server on dashboard exit.

    Uses a standalone fzf one-shot. Default (Esc) keeps running.
    """
    server = _find_web_server()
    if not server:
        return

    url = f"http://{server['host']}:{server['port']}"
    header = f"bit server running at {url}"
    choices = f"Keep running  ({url})\nStop server"

    try:
        result = subprocess.run(
            ["fzf", "--height=6", "--layout=reverse",
             "--header", header, "--no-info",
             "--header-first",
             "--bind", "esc:abort"],
            input=choices, stdout=subprocess.PIPE, text=True,
        )
        selection = result.stdout.strip()
        if selection.startswith("Stop"):
            _stop_web_server()
    except (OSError, FileNotFoundError):
        pass


def _background_fetch_host_projects(host_projects: list) -> None:
    """Fetch dashboard summaries for all projects on one host (sequential)."""
    # Fetch host-level metrics first (while _remote_fetch_pending is non-empty
    # so the dashboard watcher doesn't prematurely refresh).
    if host_projects:
        pinfo0 = host_projects[0][1]
        try:
            user0 = pinfo0.get("user", "")
            host0 = pinfo0["host"]
            addr0, port0 = ssh_resolve_address(user0, host0)
            ssh_get_host_metrics(user0, addr0, port=port0)
        except Exception:
            pass

    for path, pinfo in host_projects:
        try:
            user = pinfo.get("user", "")
            host = pinfo["host"]
            remote_path = pinfo.get("remote_path", "")
            addr, port = ssh_resolve_address(user, host)
            summary = ssh_get_dashboard_summary(user, addr, remote_path, port=port)
            _dashboard_summary_cache[path] = (time.monotonic(), summary)
        except Exception:
            pass
        finally:
            with _remote_fetch_lock:
                _remote_fetch_pending.discard(path)


def _background_fetch_remote_summaries(remote_projects: list) -> None:
    """Fetch dashboard summaries for remote projects (parallel per host)."""
    hosts = {pinfo.get("host", "?") for _, pinfo in remote_projects}
    log_message(f"Fetching remote status ({', '.join(sorted(hosts))})...")
    # Group by host so each host gets one thread with sequential SSH calls
    by_host: dict = {}
    for path, pinfo in remote_projects:
        h = pinfo.get("host", "")
        by_host.setdefault(h, []).append((path, pinfo))
    threads = []
    for host_group in by_host.values():
        t = threading.Thread(target=_background_fetch_host_projects,
                             args=(host_group,), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    log_message(f"Remote status updated ({', '.join(sorted(hosts))})")


def _count_subdirs(repo: str) -> int:
    """Count immediate subdirectories in a repo (quick layer-count heuristic)."""
    try:
        return sum(1 for e in os.scandir(repo)
                   if e.is_dir(follow_symlinks=False) and not e.name.startswith("."))
    except OSError:
        return 0


def _get_project_git_repos(path: str) -> List[str]:
    """Find all git repos in a project directory, up to 2 levels deep."""
    git_repos: list = []
    if not os.path.isdir(path):
        return git_repos
    if os.path.isdir(os.path.join(path, ".git")):
        git_repos.append(path)
    try:
        for entry in os.scandir(path):
            if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                if os.path.isdir(os.path.join(entry.path, ".git")):
                    git_repos.append(entry.path)
                else:
                    try:
                        for sub in os.scandir(entry.path):
                            if sub.is_dir(follow_symlinks=False) and not sub.name.startswith("."):
                                if os.path.isdir(os.path.join(sub.path, ".git")):
                                    git_repos.append(sub.path)
                    except OSError:
                        pass
    except OSError:
        pass
    return git_repos


_REMOTE_CACHE_TTL = 120.0  # 2 minutes for remote projects


def _get_dashboard_summary(path: str, project_info: Optional[dict] = None) -> dict:
    """Get repo-level summary for a project directory.

    Scans for git repos up to 2 levels deep and gathers aggregate stats:
    repo_count, dirty_count, ahead (local commits), behind (upstream), branch.
    Uses 30s TTL cache (120s for remote projects).

    If *project_info* indicates a remote project, delegates to
    ``ssh_get_dashboard_summary()``.
    """
    now = time.monotonic()
    ttl = _REMOTE_CACHE_TTL if (project_info and is_remote_project(project_info)) else _CACHE_TTL
    if path in _dashboard_summary_cache:
        ts, cached = _dashboard_summary_cache[path]
        if now - ts < ttl:
            return cached

    empty_summary: dict = {
        "repo_count": 0,
        "dirty_count": 0,
        "ahead": 0,
        "behind": 0,
        "tracked_behind": None,  # None = no layer info, int = filtered count
        "branch": "",
        "needs_setup": False,
    }

    # Remote project — single SSH call
    if project_info and is_remote_project(project_info):
        user = project_info.get("user", "")
        host = project_info["host"]
        remote_path = project_info.get("remote_path", "")
        addr, port = ssh_resolve_address(user, host)
        summary = ssh_get_dashboard_summary(user, addr, remote_path, port=port)
        _dashboard_summary_cache[path] = (now, summary)
        return summary

    if not os.path.isdir(path):
        _dashboard_summary_cache[path] = (now, empty_summary)
        return empty_summary

    summary = dict(empty_summary)
    git_repos = _get_project_git_repos(path)
    summary["repo_count"] = len(git_repos)

    # Gather per-repo stats
    branches: dict = {}  # branch_name -> count
    repos_behind: dict = {}  # repo_path -> (behind_count, branch)

    for repo in git_repos:
        # Branch
        repo_branch = ""
        try:
            r = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                repo_branch = r.stdout.strip()
                if repo_branch:
                    branches[repo_branch] = branches.get(repo_branch, 0) + 1
        except Exception:
            pass

        # Dirty check
        try:
            r = subprocess.run(
                ["git", "-C", repo, "status", "--porcelain", "-uno", "--no-renames"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0 and r.stdout.strip():
                summary["dirty_count"] += 1
        except Exception:
            pass

        # Ahead/behind upstream
        try:
            # Use get_upstream_ref for better fallback chain:
            # @{u} -> origin/<branch> -> origin/HEAD
            from .branch import get_upstream_ref
            upstream_ref = get_upstream_ref(repo, repo_branch) if repo_branch else None
            if upstream_ref:
                r = subprocess.run(
                    ["git", "-C", repo, "rev-list", "--left-right", "--count", f"HEAD...{upstream_ref}"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0:
                    parts = r.stdout.strip().split()
                    if len(parts) == 2:
                        ahead = int(parts[0])
                        behind = int(parts[1])
                        summary["ahead"] += ahead
                        summary["behind"] += behind
                        if behind > 0:
                            repos_behind[repo] = (behind, repo_branch)
        except Exception:
            pass

    # Most common branch across repos
    if branches:
        summary["branch"] = max(branches, key=branches.get)

    # Compute tracked-layer behind count for multi-layer repos
    if repos_behind:
        try:
            from ..personas.yocto.bblayers import extract_layer_paths
            from ..personas.yocto.layers import git_toplevel
            # Find bblayers.conf
            bblayers_path = None
            for cand in ["conf/bblayers.conf", "build/conf/bblayers.conf"]:
                full = os.path.join(path, cand)
                if os.path.isfile(full):
                    bblayers_path = full
                    break
            if bblayers_path:
                layers = extract_layer_paths(bblayers_path)
                # Map repo -> list of tracked layer paths
                repo_layers: dict = {}
                for layer in layers:
                    layer = os.path.realpath(layer)
                    repo = git_toplevel(layer)
                    if repo:
                        repo_layers.setdefault(repo, []).append(layer)
                # For repos that are behind and have tracked layers,
                # compute per-layer filtered counts
                tracked_total = 0
                has_layer_info = False
                for repo, (behind, rbranch) in repos_behind.items():
                    tracked = repo_layers.get(repo)
                    if tracked and len(tracked) < _count_subdirs(repo):
                        # Multi-layer repo with partial tracking
                        has_layer_info = True
                        from ..personas.yocto.layers import get_upstream_layer_counts
                        lcounts = get_upstream_layer_counts(repo, rbranch, tracked)
                        tracked_total += sum(lcounts.values())
                    else:
                        # Single-layer or all layers tracked — full count applies
                        tracked_total += behind
                if has_layer_info:
                    summary["tracked_behind"] = tracked_total
        except Exception:
            pass

    # Last updated — most recent HEAD reflog mtime across repos
    latest_reflog = 0.0
    for repo in git_repos:
        reflog = os.path.join(repo, ".git", "logs", "HEAD")
        if os.path.isfile(reflog):
            try:
                mt = os.path.getmtime(reflog)
                if mt > latest_reflog:
                    latest_reflog = mt
            except OSError:
                pass
    if latest_reflog > 0:
        summary["last_updated"] = latest_reflog

    # Daemon last_checked timestamp (from state file)
    try:
        from ..daemon import load_state as _load_daemon_state
        from datetime import datetime as _dt
        _ds = _load_daemon_state()
        _lc = _ds.get("projects", {}).get(path, {}).get("last_check")
        if _lc:
            summary["last_checked"] = _dt.fromisoformat(_lc).timestamp()
    except Exception:
        pass

    # Check if project needs setup (config cloned but not applied)
    defaults_path = os.path.join(path, ".bit.defaults")
    if os.path.isfile(defaults_path):
        try:
            with open(defaults_path) as f:
                proj_defaults = json.load(f)
            conf_meta = proj_defaults.get("__conf_json__", {})
            if conf_meta and not conf_meta.get("applied", True):
                summary["needs_setup"] = True
        except (json.JSONDecodeError, OSError):
            pass

    _dashboard_summary_cache[path] = (now, summary)
    return summary


def gather_all_project_summaries(projects: dict) -> dict:
    """Gather dashboard summaries for all projects.

    Applies caching logic. Remote projects may receive placeholder data with
    ``loading=True``; call ``_background_fetch_remote_summaries()`` separately
    for async update. Returns ``{path: summary_dict}``.
    """
    summaries = {}
    _remote_to_fetch = []
    for path, pinfo in projects.items():
        if not _project_key_valid(path, projects):
            summaries[path] = {}
        elif is_remote_project(pinfo):
            now = time.monotonic()
            if path in _dashboard_summary_cache:
                ts, cached = _dashboard_summary_cache[path]
                if now - ts < _REMOTE_CACHE_TTL:
                    summaries[path] = cached
                    continue
            summaries[path] = {"repo_count": 0, "dirty_count": 0,
                               "ahead": 0, "behind": 0, "branch": "",
                               "needs_setup": False, "loading": True}
            with _remote_fetch_lock:
                if path not in _remote_fetch_pending:
                    _remote_fetch_pending.add(path)
                    _remote_to_fetch.append((path, pinfo))
        else:
            summaries[path] = _get_dashboard_summary(path, project_info=pinfo)
    if _remote_to_fetch:
        threading.Thread(
            target=_background_fetch_remote_summaries,
            args=(_remote_to_fetch,),
            daemon=True,
        ).start()
    return summaries


def _remove_project_interactive() -> bool:
    """Show picker to select a project to stop tracking."""
    if not fzf_available():
        return False

    projects = load_projects()
    if not projects:
        print("No projects to remove.")
        return False

    menu_lines = []
    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        if is_remote_project(info):
            indicator = terminal_color("project_remote", "⇄ ")
        elif os.path.isdir(path):
            indicator = "  "
        else:
            indicator = Colors.red("! ")
        menu_lines.append(f"{path}\t{indicator}{name:<20} {Colors.dim(path)}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~40%",
        "--layout", "reverse",
        "--header", "Select project to stop tracking (Enter=remove, ←/q=cancel)",
        "--prompt", "Remove: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return False

    if result.returncode != 0 or not result.stdout.strip():
        return False

    selected = result.stdout.strip().split("\t")[0]
    if selected in projects:
        return remove_project(selected)

    return False


def fzf_project_picker(include_browse: bool = True, show_exit_hint: bool = False) -> Optional[str]:
    """
    Show fzf menu to select a project.

    Args:
        include_browse: Include option to browse for new project
        show_exit_hint: Show hint about Enter exiting to command menu

    Returns:
        Selected project path, or special commands like:
        - "SELECT:<path>" - Space was pressed, set as active but stay in picker
        - "EXIT:<path>" - Enter was pressed, exit and optionally chain to command menu
        - Other special values for menu options
        - None if cancelled
    """
    if not fzf_available():
        return None

    projects = load_projects_for_display()
    current_project = get_current_project()

    if not projects and not include_browse:
        print("No projects registered. Use 'bit projects add' to add one.")
        return None

    # Build menu
    menu_lines = []

    # Compute max path length for column alignment
    max_path_len = max((len(p) for p in projects), default=20)
    path_col = max_path_len + 3  # 3 spaces after longest path

    # Column header and separator (first lines = top of screen with reverse-list)
    header_line = f"HEADER\t  {'Name':<20} {'Path':<{path_col}} Info"
    sep_len = 2 + 20 + 1 + path_col + 4
    separator = f"SEPARATOR_HEADER\t{'─' * sep_len}"
    menu_lines.append(header_line)
    menu_lines.append(separator)

    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        desc = info.get("description", "")

        # Check if path still exists and if it's current
        is_current = (path == current_project)
        is_remote = is_remote_project(info)
        exists = is_remote or os.path.isdir(path)
        if exists:
            if is_remote:
                status = terminal_color("project_remote", "⇄") if not is_current else terminal_color("project_active", "●")
            elif is_current:
                status = terminal_color("project_active", "●")
            else:
                status = terminal_color("project_name", "○")
        else:
            status = terminal_color("project_missing", "!")

        # Detect current state (skip for remote — no local filesystem)
        proj_info = _detect_project_info(path) if (not is_remote and os.path.isdir(path)) else {}
        layers = proj_info.get("layer_count", 0)
        branch = proj_info.get("branch", "")

        extra = []
        if is_current:
            extra.append("ACTIVE")
        if layers:
            extra.append(f"{layers} layers")
        if branch:
            extra.append(branch)
        extra_str = f"({', '.join(extra)})" if extra else ""

        # Pad path to align info column (Colors.dim adds ANSI codes, so pad the raw path first)
        padded_path = f"{path:<{path_col}}"
        display = f"{status} {name:<20} {Colors.dim(padded_path)}{terminal_color('project_active', extra_str)}"
        if desc:
            display += f" - {desc}"

        menu_lines.append(f"{path}\t{display}")

    # Add browse/add/remove options
    if include_browse:
        menu_lines.append("---\t" + "─" * 50)
        menu_lines.append("ADD_CWD\t+ Add current directory")
        menu_lines.append("ADD_PATH\t+ Enter path manually...")
        menu_lines.append("BROWSE\t+ Browse for directory...")
        if projects:
            menu_lines.append("REMOVE\t- Remove project tracking...")
        if current_project:
            menu_lines.append("CLEAR\t✖ Clear active project")
        # Settings
        browser = get_directory_browser()
        browser_desc = {"auto": "auto (broot>ranger>nnn>fzf)", "nnn": "nnn", "fzf": "fzf", "broot": "broot", "ranger": "ranger"}.get(browser, browser)
        menu_lines.append(f"SETTINGS\t⚙ Settings: browser={browser_desc}")

    menu_input = "\n".join(menu_lines)

    # Build header based on context
    if show_exit_hint:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done (→menu) | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")
    else:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--layout=reverse-list",
        "--height", "~50%",
        "--header", header,
        "--prompt", "Project: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
        "--expect", "space,+,-,c,s,i,S",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    # Parse output - with --expect, first line is key (or empty if Enter), second is selection
    # Don't strip() first as it removes the leading newline when Enter is pressed
    lines = result.stdout.split("\n")
    key = lines[0].strip() if lines else ""
    selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

    # Items that are not projects (actions, separators, header)
    action_items = ("---", "ADD_CWD", "ADD_PATH", "BROWSE", "REMOVE", "CLEAR", "SETTINGS",
                    "HEADER", "SEPARATOR_HEADER")

    # Handle key shortcuts
    if key == "+":
        return "BROWSE"
    elif key == "space" and selected and selected not in action_items:
        # Space = select/activate the project but stay in picker
        return f"SELECT:{selected}"
    elif key == "-" and selected and selected not in action_items:
        # Remove the highlighted project directly
        return f"REMOVE:{selected}"
    elif key == "c":
        return "CLEAR"
    elif key == "s":
        return "SETTINGS"
    elif key == "S" and selected and selected not in action_items:
        return f"SHELL:{selected}"
    elif key == "i" and selected and selected not in action_items:
        return f"INIT:{selected}"

    # No special key (Enter) - return the selected item
    if not selected or selected in ("---", "HEADER", "SEPARATOR_HEADER"):
        return fzf_project_picker(include_browse, show_exit_hint)

    # Enter on a project - signal to exit
    if selected not in action_items:
        return f"EXIT:{selected}"

    return selected


def _write_hosts_reload_script(
    script_path: str,
    preview_dir: str,
    hosts_info: dict,
    projects: dict,
) -> None:
    """Write a standalone Python script that fzf can invoke to reload host data.

    The script re-fetches metrics, outputs fzf-formatted lines to stdout,
    and updates preview files in *preview_dir*.
    """
    # Serialize only the fields get_all_host_metrics() needs from projects
    minimal_projects = {}
    for path, pinfo in projects.items():
        if pinfo.get("host"):
            minimal_projects[path] = {
                "host": pinfo["host"],
                "user": pinfo.get("user", ""),
            }

    data_path = os.path.join(preview_dir, "reload_data.json")
    with open(data_path, "w") as f:
        json.dump({"hosts_info": hosts_info, "projects": minimal_projects}, f)

    # Resolve the project root so the reload script can import bitbake_project
    import bitbake_project as _bp
    _project_root = os.path.dirname(os.path.dirname(os.path.abspath(_bp.__file__)))

    script = f'''\
#!/usr/bin/env python3
"""Auto-generated reload script for bit hosts view."""
import json, os, sys
from datetime import datetime

sys.path.insert(0, {_project_root!r})

data_path = {data_path!r}
preview_dir = {preview_dir!r}

with open(data_path) as _f:
    _data = json.load(_f)
hosts_info = _data["hosts_info"]
projects = _data["projects"]

from bitbake_project.commands.ssh_remote import (
    invalidate_host_metrics_cache, get_all_host_metrics,
)

BOLD = "\\033[1m"
DIM = "\\033[2m"
RESET = "\\033[0m"

invalidate_host_metrics_cache()
all_metrics = get_all_host_metrics(projects)

col_header = f"{{'Host':<20}} {{'OS':<22}} {{'Kernel':<14}} {{'Load':>6}} {{'Mem%':>6}} {{'Disk%':>6}} {{'Proj':>5}}"
now_str = datetime.now().strftime("%H:%M:%S")
print(f"__HDR__\\t{{BOLD}}{{col_header}}{{RESET}}  {{DIM}}Updated {{now_str}}{{RESET}}")
print(f"__SEP__\\t{{DIM}}{{"\\u2500" * 85}}{{RESET}}")

for host in sorted(hosts_info.keys()):
    info = hosts_info[host]
    count = info.get("count", 0)
    m = all_metrics.get(host, {{}})
    if m.get("error"):
        line = f"{{host:<20}} {{'(unreachable)':<22}} {{'':<14}} {{'':>6}} {{'':>6}} {{'':>6}} {{count:>5}}"
        line = f"{{DIM}}{{line}}{{RESET}}"
        preview_text = f"{{host}}\\n\\n  Unreachable — SSH connection failed"
    else:
        os_name = (m.get("os") or "")[:22]
        kernel = (m.get("kernel") or "").split("-")[0][:14]
        load_s = f'{{m.get("load_1", 0):.1f}}'
        mem_s = f'{{m.get("mem_pct", 0)}}%'
        disk_pct = ""
        if m.get("disks"):
            max_d = max(int(d.get("pct", 0)) for d in m["disks"])
            disk_pct = f"{{max_d}}%"
        line = f"{{host:<20}} {{os_name:<22}} {{kernel:<14}} {{load_s:>6}} {{mem_s:>6}} {{disk_pct:>6}} {{count:>5}}"

        uptime_sec = m.get("uptime_sec", 0)
        days = uptime_sec // 86400
        hours = (uptime_sec % 86400) // 3600
        uptime_str = f"{{days}}d {{hours}}h" if days else f"{{hours}}h"
        mem_total = m.get("mem_total_kb", 0)
        mem_avail = m.get("mem_avail_kb", 0)
        mem_used = mem_total - mem_avail
        mem_total_gb = f"{{mem_total / 1048576:.1f}}"
        mem_used_gb = f"{{mem_used / 1048576:.1f}}"
        cpus = m.get("cpus", 1)

        plines = [
            f"  {{m.get('hostname', host)}}",
            f"  {{m.get('os', '')}}  \\u00b7  kernel {{m.get('kernel', '')}}",
            f"  uptime: {{uptime_str}}",
            "",
            f"  Load:   {{m.get('load_1', 0):.2f}} / {{m.get('load_5', 0):.2f}} / {{m.get('load_15', 0):.2f}}  ({{cpus}} cores)",
            f"  Memory: {{mem_used_gb}} / {{mem_total_gb}} GB  ({{m.get('mem_pct', 0)}}%)",
            "",
            "  Disks:",
        ]
        for d in m.get("disks", []):
            pct = int(d.get("pct", 0))
            bar_len = 20
            filled = round(pct / 100 * bar_len)
            bar = "\\u2588" * filled + "\\u2591" * (bar_len - filled)
            plines.append(f"    {{d['mount']:<16}} {{bar}} {{pct:>3}}%  ({{d.get('avail', '?')}} / {{d.get('size', '?')}} free)")
        plines.append("")
        plines.append(f"  {{count}} project{{'s' if count != 1 else ''}} on this host")
        preview_text = "\\n".join(plines)

    print(f"HOST:{{host}}\\t{{line}}")
    pf = os.path.join(preview_dir, f"HOST:{{host}}".replace("/", "_"))
    try:
        with open(pf, "w") as f:
            f.write(preview_text)
    except OSError:
        pass
'''
    with open(script_path, "w") as f:
        f.write(script)
    os.chmod(script_path, 0o755)


def _show_hosts_view(projects: dict) -> None:
    """Show a full-screen fzf view of all remote hosts with system metrics."""
    from ..fzf_bindings import get_action_binding

    # Collect unique hosts
    hosts_info: dict = {}  # host -> {user, project_count}
    for _p, pinfo in projects.items():
        if not is_remote_project(pinfo):
            continue
        host = pinfo.get("host", "")
        if host not in hosts_info:
            hosts_info[host] = {"user": pinfo.get("user", ""), "count": 0}
        hosts_info[host]["count"] += 1

    if not hosts_info:
        log_message("No remote hosts configured")
        return

    import tempfile
    from datetime import datetime
    preview_dir = tempfile.mkdtemp(prefix="bit-hosts-")

    def _build_hosts_data():
        """Fetch metrics and build fzf menu lines + preview files."""
        invalidate_host_metrics_cache()
        all_metrics = get_all_host_metrics(projects)

        lines = []
        col_header = f"{'Host':<20} {'OS':<22} {'Kernel':<14} {'Load':>6} {'Mem%':>6} {'Disk%':>6} {'Proj':>5}"
        now_str = datetime.now().strftime("%H:%M:%S")
        lines.append(f"__HDR__\t{Colors.bold(col_header)}  {Colors.dim('Updated ' + now_str)}")
        lines.append(f"__SEP__\t{Colors.dim('─' * 85)}")

        for host in sorted(hosts_info.keys()):
            info = hosts_info[host]
            m = all_metrics.get(host, {})
            if m.get("error"):
                line = f"{host:<20} {'(unreachable)':<22} {'':<14} {'':>6} {'':>6} {'':>6} {info['count']:>5}"
                line = Colors.dim(line)
                preview_text = f"{host}\n\n  Unreachable — SSH connection failed"
            else:
                os_name = (m.get("os") or "")[:22]
                kernel = (m.get("kernel") or "").split("-")[0][:14]
                load_s = f'{m.get("load_1", 0):.1f}'
                mem_s = f'{m.get("mem_pct", 0)}%'
                disk_pct = ""
                if m.get("disks"):
                    max_d = max(int(d.get("pct", 0)) for d in m["disks"])
                    disk_pct = f"{max_d}%"
                line = f"{host:<20} {os_name:<22} {kernel:<14} {load_s:>6} {mem_s:>6} {disk_pct:>6} {info['count']:>5}"

                uptime_sec = m.get("uptime_sec", 0)
                days = uptime_sec // 86400
                hours = (uptime_sec % 86400) // 3600
                uptime_str = f"{days}d {hours}h" if days else f"{hours}h"
                mem_total = m.get("mem_total_kb", 0)
                mem_avail = m.get("mem_avail_kb", 0)
                mem_used = mem_total - mem_avail
                mem_total_gb = f"{mem_total / 1048576:.1f}"
                mem_used_gb = f"{mem_used / 1048576:.1f}"
                cpus = m.get("cpus", 1)

                plines = [
                    f"  {m.get('hostname', host)}",
                    f"  {m.get('os', '')}  ·  kernel {m.get('kernel', '')}",
                    f"  uptime: {uptime_str}",
                    "",
                    f"  Load:   {m.get('load_1', 0):.2f} / {m.get('load_5', 0):.2f} / {m.get('load_15', 0):.2f}  ({cpus} cores)",
                    f"  Memory: {mem_used_gb} / {mem_total_gb} GB  ({m.get('mem_pct', 0)}%)",
                    "",
                    "  Disks:",
                ]
                for d in m.get("disks", []):
                    pct = int(d.get("pct", 0))
                    bar_len = 20
                    filled = round(pct / 100 * bar_len)
                    bar = "█" * filled + "░" * (bar_len - filled)
                    plines.append(f"    {d['mount']:<16} {bar} {pct:>3}%  ({d.get('avail', '?')} / {d.get('size', '?')} free)")
                plines.append("")
                plines.append(f"  {info['count']} project{'s' if info['count'] != 1 else ''} on this host")
                preview_text = "\n".join(plines)

            lines.append(f"HOST:{host}\t{line}")
            pf = os.path.join(preview_dir, f"HOST:{host}".replace("/", "_"))
            try:
                with open(pf, "w") as f:
                    f.write(preview_text)
            except OSError:
                pass

        return "\n".join(lines)

    # Write a reload script that regenerates host data for fzf
    reload_script = os.path.join(preview_dir, "reload.py")
    # The script re-fetches metrics and outputs fzf-formatted lines
    _write_hosts_reload_script(reload_script, preview_dir, hosts_info, projects)

    try:
      while True:
        menu_input = _build_hosts_data()

        fzf_header = "Auto-refreshes every 30s · r: refresh · Enter/→/S: terminal · ←/q/Esc: back"

        reload_cmd = f"{shlex.quote(sys.executable)} {shlex.quote(reload_script)}"

        fzf_args = [
            "fzf",
            "--ansi",
            "--no-multi",
            "--delimiter", "\t",
            "--with-nth", "2..",
            "--header", fzf_header,
            "--prompt", "Hosts: ",
            "--layout", "reverse-list",
            "--preview", f"cat {shlex.quote(preview_dir)}/{{1}} 2>/dev/null || echo 'No data'",
            "--preview-window", "right:50%:wrap",
        ]
        fzf_args.extend(get_fzf_color_args())
        fzf_args.extend(["--bind", "enter:become(echo CONNECT {1})"])
        from ..fzf_bindings import get_exit_bindings, get_accept_binding, get_preview_scroll_bindings, get_action_binding
        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_accept_binding("become(echo CONNECT {1})"))
        fzf_args.extend(get_action_binding("S", "CONNECT {1}"))
        fzf_args.extend(get_preview_scroll_bindings())
        # r key: manual reload
        fzf_args.extend(["--bind", f"r:reload({reload_cmd})"])
        # Auto-reload every 30 seconds using background sleep loop
        fzf_args.extend(["--listen", "0"])
        fzf_args.extend(["--bind", f"start:reload({reload_cmd})+execute-silent(sh -c 'while sleep 30; do curl -s -XPOST localhost:$FZF_PORT -d \"reload({reload_cmd})\" >/dev/null 2>&1 || break; done &')"])

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except (OSError, FileNotFoundError):
            return

        output = result.stdout.strip()
        if not output or result.returncode != 0:
            return

        if output.startswith("CONNECT HOST:"):
            host = output[len("CONNECT HOST:"):]
            info = hosts_info.get(host, {})
            user = info.get("user", "")
            addr, port = ssh_resolve_address(user, host)
            remote_shell(user, addr, "", port=port)
            continue

        return
    finally:
        import shutil as _shutil
        _shutil.rmtree(preview_dir, ignore_errors=True)


def _invalidate_summary_cache(path: str) -> None:
    """Remove a project's cached dashboard summary so it refreshes."""
    _dashboard_summary_cache.pop(path, None)


def _dashboard_run_setup(project_path: str) -> None:
    """Run setup apply for a project from the dashboard."""
    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        apply_args = argparse.Namespace(
            defaults_file=".bit.defaults",
            bblayers=None,
            config=None,
            layers_dir="layers",
        )
        from .setup import run_setup_apply
        rc = run_setup_apply(apply_args)
        if rc != 0:
            log_message(f"{Colors.yellow('!')} Setup incomplete")
        else:
            log_message(f"{Colors.green('✓')} Setup complete")
        input("\nPress Enter to continue...")
    except (EOFError, KeyboardInterrupt):
        pass
    finally:
        try:
            os.chdir(saved_cwd)
        except OSError:
            pass


def _dashboard_run_command(project_path: str, argv: list,
                           project_info: Optional[dict] = None) -> int:
    """Run a bit command in the context of a project directory.

    For remote projects, delegates to ``remote_run_action()`` with fallback
    chain. For local projects, changes to the project directory, sets it as
    active, runs the command via cli.main(), then restores the original
    directory.
    """
    if project_info and is_remote_project(project_info):
        user = project_info.get("user", "")
        host = project_info["host"]
        rpath = project_info.get("remote_path", "")
        addr, port = ssh_resolve_address(user, host)
        cmd = " ".join(argv)
        return remote_run_action(user, addr, rpath, cmd, port=port)

    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        from ..cli import main as cli_main
        return cli_main(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 1
    finally:
        try:
            os.chdir(saved_cwd)
        except OSError:
            pass


def _parse_action_key(key: str) -> Tuple[str, Optional[str]]:
    """Parse ``ACTION:<path>:<cmd>`` → ``(path, cmd)``.

    Remote project paths contain ``:`` (e.g. ``user@host:/dir``), so we
    split on the *last* colon — command names never contain ``:``.
    For non-ACTION keys returns ``(key, None)``.
    """
    if not key.startswith("ACTION:"):
        return (key, None)
    rest = key[7:]  # strip "ACTION:" prefix
    last_colon = rest.rfind(":")
    if last_colon > 0:
        return (rest[:last_colon], rest[last_colon + 1:])
    return (rest, None)


# Action submenus for expanded projects — split by persona
_GENERIC_DASHBOARD_ACTIONS = [
    ("explore", "Browse commits and repos"),
    ("update", "Update git repos"),
    ("config", "Repo and layer settings"),
    ("pull request", "Prepare commits for upstream"),
    ("properties", "Name, description, tags"),
]

_YOCTO_DASHBOARD_ACTIONS = [
    ("export", "Export config to .conf.json"),
    ("shell", "Build environment shell"),
]


def _get_dashboard_actions(project_info: dict) -> list:
    """Return dashboard actions appropriate for a project's persona."""
    persona_name = project_info.get("persona") or "yocto"
    actions = list(_GENERIC_DASHBOARD_ACTIONS)
    if persona_name == "yocto":
        actions.extend(_YOCTO_DASHBOARD_ACTIONS)
    return actions


def _show_properties_dialog(proj_path, projects, dialog_state):
    """Show properties dialog for a project. Delegates to fzf_project_properties()."""
    from .config import fzf_project_properties
    fzf_project_properties(proj_path, projects)


def _show_tag_picker(proj_path, projects, dialog_state):
    """Show an inline tag picker dialog for a project.

    Lists current local tags (select to remove), available tags (select to
    add), and a 'New tag...' option for free-form input.  For remote projects
    also shows remote tags with hide/unhide actions.  Re-shows itself after
    each action so the user can make multiple changes.
    """
    from ..tags import (get_project_tags, set_project_tags, all_tags,
                        load_panes, get_project_hidden_tags,
                        set_project_hidden_tags, get_project_remote_tags)

    pinfo = projects.get(proj_path, {})
    is_remote = is_remote_project(pinfo)
    cur_tags = get_project_tags(proj_path)
    remote_tags = get_project_remote_tags(proj_path) if is_remote else []
    hidden_tags = get_project_hidden_tags(proj_path) if is_remote else []

    # Collect tags from both projects and pane definitions, plus well-known tags
    known = all_tags(projects)
    for pane in load_panes():
        known.update(pane.get("tags") or [])
    # Well-known tags that should always be discoverable
    known.add("auto-update")
    known = sorted(known)
    # Available = known tags not already on this project (local or remote)
    all_on_project = set(cur_tags) | set(remote_tags)
    available = [t for t in known if t not in all_on_project]
    # Exclude implicit persona tag from "available"
    persona = pinfo.get("persona") or pinfo.get("remote_persona") or "yocto"
    available = [t for t in available if t != persona]

    options = []

    # Remote tags section (hide/unhide)
    if remote_tags:
        options.append(("---hdr-remote", "── Remote tags ──", ""))
        for t in remote_tags:
            is_hidden = t in hidden_tags
            if is_hidden:
                options.append((f"__UNHIDE__{t}",
                                f"  {Colors.dim(t)} {Colors.dim('(hidden)')}", "unhide"))
            else:
                options.append((f"__HIDE__{t}",
                                f"  {t}", "hide"))

    # Local tags section
    if remote_tags:
        options.append(("---hdr-local", "── Local tags ──", ""))
    for t in cur_tags:
        options.append((f"__REMOVE__{t}", f"\u2717 {t}", "remove"))
    if cur_tags and available:
        options.append(("---", "───", ""))
    for t in available:
        options.append((f"__ADD__{t}", f"+ {t}", "add"))
    options.append(("__NEW__", "+ New tag...", "enter custom tag"))

    def _on_pick(chosen):
        if not chosen:
            return
        if chosen == "__NEW__":
            def _on_new_tag(tag_name):
                if tag_name and tag_name.strip():
                    tag_name = tag_name.strip()
                    updated = list(get_project_tags(proj_path))
                    if tag_name not in updated:
                        updated.append(tag_name)
                        set_project_tags(proj_path, updated)
                        log_message(f"{Colors.green('✓')} Added tag: {tag_name}")
                    _show_tag_picker(proj_path, projects, dialog_state)
                else:
                    _show_tag_picker(proj_path, projects, dialog_state)

            dialog_state.show_dialog(
                text_input_dialog("New tag", on_confirm=_on_new_tag)
            )
        elif chosen.startswith("__REMOVE__"):
            tag = chosen[len("__REMOVE__"):]
            updated = [t for t in get_project_tags(proj_path) if t != tag]
            set_project_tags(proj_path, updated)
            log_message(f"{Colors.green('✓')} Removed tag: {tag}")
            _show_tag_picker(proj_path, projects, dialog_state)
        elif chosen.startswith("__ADD__"):
            tag = chosen[len("__ADD__"):]
            updated = list(get_project_tags(proj_path))
            if tag not in updated:
                updated.append(tag)
                set_project_tags(proj_path, updated)
                log_message(f"{Colors.green('✓')} Added tag: {tag}")
            _show_tag_picker(proj_path, projects, dialog_state)
        elif chosen.startswith("__HIDE__"):
            tag = chosen[len("__HIDE__"):]
            cur_hidden = get_project_hidden_tags(proj_path)
            if tag not in cur_hidden:
                cur_hidden.append(tag)
                set_project_hidden_tags(proj_path, cur_hidden)
                log_message(f"{Colors.green('✓')} Hidden remote tag: {tag}")
            _show_tag_picker(proj_path, projects, dialog_state)
        elif chosen.startswith("__UNHIDE__"):
            tag = chosen[len("__UNHIDE__"):]
            cur_hidden = [t for t in get_project_hidden_tags(proj_path) if t != tag]
            set_project_hidden_tags(proj_path, cur_hidden)
            log_message(f"{Colors.green('✓')} Unhidden remote tag: {tag}")
            _show_tag_picker(proj_path, projects, dialog_state)

    proj_name = pinfo.get("name", os.path.basename(proj_path))
    tag_summary = ", ".join(cur_tags) if cur_tags else "(none)"
    if remote_tags:
        visible_remote = [t for t in remote_tags if t not in hidden_tags]
        if visible_remote:
            tag_summary += f" | remote: {', '.join(visible_remote)}"
    dialog_state.show_dialog(
        select_action_dialog(
            f"Tags: {proj_name} [{tag_summary}]",
            options,
            on_confirm=_on_pick,
            done_label="Done",
        )
    )


def _show_host_addresses_dialog(host: str, dialog_state) -> None:
    """Show inline dialog for managing per-host SSH config (addresses, tmux)."""
    addresses = get_host_addresses(host)
    tmux_session = get_host_tmux_session(host)

    def _format_addr(a):
        port = a.get("port", 22)
        return f"{a['address']}:{port}" if port != 22 else a["address"]

    def _on_action(action):
        if action == "__ADD__":
            def _on_add(value):
                if not value or not value.strip():
                    return
                value = value.strip()
                # Parse address:port
                if ":" in value:
                    parts = value.rsplit(":", 1)
                    try:
                        port = int(parts[1])
                        addr = parts[0]
                    except ValueError:
                        addr, port = value, 22
                else:
                    addr, port = value, 22
                addrs = get_host_addresses(host)
                addrs.append({"address": addr, "port": port})
                set_host_addresses(host, addrs)
                log_message(f"{Colors.green('+')} Added address: {addr}:{port}")
                # Re-show the dialog with updated list
                _show_host_addresses_dialog(host, dialog_state)

            dialog_state.show_dialog(
                text_input_dialog(
                    f"Add address for {host}",
                    message="Format: hostname or hostname:port",
                    placeholder="10.8.0.2:22",
                    on_confirm=_on_add,
                )
            )
        elif action and action.startswith("__REMOVE__"):
            idx = int(action[len("__REMOVE__"):])
            addrs = get_host_addresses(host)
            if 0 <= idx < len(addrs):
                removed = addrs.pop(idx)
                set_host_addresses(host, addrs)
                log_message(
                    f"{Colors.yellow('-')} Removed: "
                    f"{removed['address']}:{removed.get('port', 22)}"
                )
            # Re-show the dialog with updated list
            _show_host_addresses_dialog(host, dialog_state)
        elif action == "__TMUX__":
            def _on_tmux(value):
                value = (value or "").strip()
                set_host_tmux_session(host, value)
                if value:
                    log_message(f"Tmux session for {host}: {value}")
                else:
                    log_message(f"Tmux session for {host}: default (bit-*)")
                _show_host_addresses_dialog(host, dialog_state)

            dialog_state.show_dialog(
                text_input_dialog(
                    f"Tmux session for {host}",
                    message="Session name, 'auto' = attach to any running session, empty = bit-*",
                    default=tmux_session,
                    on_confirm=_on_tmux,
                )
            )

    options = []
    for i, a in enumerate(addresses):
        label = _format_addr(a)
        tag = "primary" if i == 0 else f"alt {i}"
        options.append((f"__REMOVE__{i}", f"[{tag}] {label}", f"Select to remove"))
    options.append(("__ADD__", "+ Add address...", f"Add alternate address for {host}"))
    tmux_label = tmux_session if tmux_session else "default (bit-*)"
    options.append(("__TMUX__", f"Tmux session: {Colors.dim(tmux_label)}", "Attach to existing tmux session"))

    # Default to first option so cursor lands on a dialog item
    default = options[0][0] if options else "__ADD__"
    dialog_state.show_dialog(
        select_action_dialog(
            f"Host config: {host}",
            options=options,
            on_confirm=_on_action,
            default_value=default,
        )
    )


def fzf_dashboard() -> int:
    """Project dashboard with status summaries and quick actions.

    Shows all configured projects with status columns (branch, layer count,
    sync/dirty status), expandable action submenus per project, and an inline
    manage dialog. Direct action keybindings also available.
    Returns to dashboard after each action completes.
    """
    if not fzf_available():
        return 1

    GROUP_COLLAPSE_THRESHOLD = 6  # auto-collapse groups with more than this many projects
    expanded_projects: set = set()
    collapsed_groups: set = set()  # group keys: "local" or "remote:<host>"
    _groups_initialized: bool = False
    last_selection: Optional[str] = get_current_project()
    show_manage: bool = False
    show_configure: bool = False
    conf_cursor: Optional[str] = None  # key to position cursor on after cycling
    conf_picker: Optional[str] = None  # active inline sub-picker within configure
    show_pane_selector: bool = False
    from ..tags import load_panes, get_active_pane, matches_pane as _matches_pane, find_pane
    active_pane: dict = find_pane(get_active_pane()) or {"name": "All", "tags": [], "builtin": True}
    show_export: bool = False
    export_context: dict = {}  # project_name, sources, relative_layers, fragments
    export_enabled: Dict[str, bool] = {}  # fragment -> enabled
    export_cursor: Optional[str] = None  # key to position cursor on after toggle
    export_description: str = ""
    export_desc_input: bool = False  # True = text-input mode for description
    dialog_state = ExploreMenuState()
    show_verbose = False
    show_search = False
    search_cursor: Optional[str] = None  # OPT: key to restore cursor after toggle
    search_term = ""
    search_fields = set()       # which "Search In" toggles were active
    status_filters = set()      # e.g. {"dirty", "ahead"}
    options_state = InlineOptionsState(build_dashboard_search_menu())

    # Auto-start web server if configured (or adopt existing)
    global _web_server_port, _web_server_host
    _existing_web = _find_web_server()
    if _existing_web:
        _web_server_port = _existing_web["port"]
        _web_server_host = _existing_web["host"]
        log_message(f"Server running at http://{_existing_web['host']}:{_existing_web['port']}")
    else:
        _web_autostart = get_web_autostart()
        if _web_autostart in ("localhost", "all"):
            _autostart_host = "127.0.0.1" if _web_autostart == "localhost" else "0.0.0.0"
            _launch_web_server(port=8123, host=_autostart_host)

    while True:
        projects = load_projects_for_display()
        # Collect active project(s): when pane filtered, just matching persona;
        # when showing all, gather active project for each persona.
        _pane_tags = active_pane.get("tags") or []
        if len(_pane_tags) == 1 and _pane_tags[0] in ("yocto", "generic"):
            current_project = get_current_project(_pane_tags[0])
        else:
            current_project = get_current_project()
        _active_projects: set = set()
        if current_project:
            _active_projects.add(current_project)
        if not _pane_tags or len(_pane_tags) != 1:
            # Also gather active projects for other personas
            from ..persona import list_personas, get_global_default_persona
            for _pn in list_personas():
                _ap = get_current_project(_pn)
                if _ap:
                    _active_projects.add(_ap)

        # Build menu lines
        menu_lines = []

        if not projects:
            # No projects yet - just show manage entry
            menu_lines.append("MANAGE\t  ⚙  Manage projects...")
        else:
            summaries = gather_all_project_summaries(projects)

            # Compute column widths from raw (pre-ANSI) data
            names_raw = []
            branches_raw = []
            status_raw = []
            paths_raw = []
            for path, info in projects.items():
                names_raw.append(info.get("name", os.path.basename(path)))
                paths_raw.append(path)
                s = summaries.get(path, {})
                branches_raw.append(s.get("branch") or "")
                # Build raw status text for width computation
                rc = s.get("repo_count", 0)
                if s.get("loading"):
                    status_raw.append("loading...")
                elif rc == 0:
                    status_raw.append("")
                else:
                    sp = [f"{rc:2} repos"]
                    if s.get("dirty_count", 0):
                        sp.append(f"\u270e{s['dirty_count']}")
                    if s.get("ahead", 0):
                        sp.append(f"\u2191{s['ahead']}")
                    if s.get("behind", 0):
                        sp.append(f"\u2193{s['behind']}")
                    if not s.get("dirty_count") and not s.get("ahead") and not s.get("behind"):
                        sp.append("\u2713")
                    status_raw.append(" ".join(sp))

            max_name = max((len(n) for n in names_raw), default=10)
            name_col = min(max(max_name + 2, 10), 25)

            max_branch = max((len(b) for b in branches_raw), default=8)
            branch_col = min(max(max_branch + 2, 8), 20)

            max_status = max((len(s) for s in status_raw), default=8)
            status_col = min(max(max_status + 2, 8), 30)

            max_path = max((len(p) for p in paths_raw), default=20)
            path_col = min(max(max_path + 2, 20), 55)

            total_width = name_col + branch_col + status_col + path_col + 16

            # Banner header (non-selectable, at bottom of input = top of screen with reverse-list)
            _pane_label = active_pane["name"] if active_pane.get("tags") else ""
            if _pane_label:
                banner_text = Colors.bold(Colors.cyan(f"── bit dashboard: {_pane_label} ──"))
                _banner_raw_len = len(f"── bit dashboard: {_pane_label} ──")
            else:
                banner_text = Colors.bold(Colors.cyan("── bit dashboard ──"))
                _banner_raw_len = len("── bit dashboard ──")
            menu_lines.append(f"HEADER\t  {banner_text}{'─' * max(total_width - _banner_raw_len + 3, 10)}")

            # Column headers — prefix is 6 visual chars: indent(2) + expand(1) + space(1) + dot(1) + space(1)
            col_header = (
                f"      {'Name':<{name_col}} "
                f"{'Branch':<{branch_col}} "
                f"{'Status':<{status_col}} "
                f"Path"
            )
            if show_verbose:
                col_header_full = (
                    f"      {'Name':<{name_col}} "
                    f"{'Branch':<{branch_col}} "
                    f"{'Status':<{status_col}} "
                    f"{'Path':<{path_col}} "
                )
                col_meta = f"{Colors.dim('(type)')} {Colors.cyan('[tags]')} {Colors.dim(Colors.italic('description'))}"
                menu_lines.append(f"SEP_COL\t{Colors.dim(col_header_full)}{col_meta}")
            else:
                menu_lines.append(f"SEP_COL\t{Colors.dim(col_header)}")
            menu_lines.append(f"SEP_LINE\t  {'─' * total_width}")

            # Group projects: local first, then per-host remote
            local_projects = []
            remote_by_host = {}  # host -> [(path, info), ...]
            for path, info in projects.items():
                if is_remote_project(info):
                    h = info.get("host", "unknown")
                    remote_by_host.setdefault(h, []).append((path, info))
                else:
                    local_projects.append((path, info))

            # Sort within each group
            local_projects.sort(key=lambda x: x[1].get("name", x[0]).lower())
            for h in remote_by_host:
                remote_by_host[h].sort(key=lambda x: x[1].get("name", x[0]).lower())
            sorted_hosts = sorted(remote_by_host.keys())

            # Apply search/filter if active
            if search_term or status_filters:
                def _match_project(path, info, summary):
                    """Return True if project matches active search/filters."""
                    # Status filters (AND: all enabled must match)
                    s = summary
                    for sf in status_filters:
                        if sf == "dirty" and not s.get("dirty_count", 0):
                            return False
                        if sf == "ahead" and not s.get("ahead", 0):
                            return False
                        if sf == "behind" and not s.get("behind", 0):
                            return False
                        if sf == "needs_setup" and not s.get("needs_setup"):
                            return False

                    # Text search (OR across enabled fields)
                    if search_term:
                        term = search_term.lower()
                        fields_to_search = search_fields or {"name"}
                        matched = False
                        for field in fields_to_search:
                            if field == "name":
                                val = info.get("name", os.path.basename(path))
                            elif field == "description":
                                val = info.get("description", "")
                            elif field == "branch":
                                val = s.get("branch", "")
                            elif field == "path":
                                val = path
                            elif field == "host":
                                val = info.get("host", "")
                            else:
                                continue
                            if term in val.lower():
                                matched = True
                                break
                        if not matched:
                            return False

                    return True

                local_projects = [
                    (p, i) for p, i in local_projects
                    if _match_project(p, i, summaries.get(p, {}))
                ]
                for h in list(remote_by_host.keys()):
                    remote_by_host[h] = [
                        (p, i) for p, i in remote_by_host[h]
                        if _match_project(p, i, summaries.get(p, {}))
                    ]
                    if not remote_by_host[h]:
                        del remote_by_host[h]
                sorted_hosts = sorted(remote_by_host.keys())

            # Pane filter
            if active_pane.get("tags"):
                local_projects = [
                    (p, i) for p, i in local_projects if _matches_pane(i, active_pane)
                ]
                for h in list(remote_by_host.keys()):
                    remote_by_host[h] = [
                        (p, i) for p, i in remote_by_host[h] if _matches_pane(i, active_pane)
                    ]
                    if not remote_by_host[h]:
                        del remote_by_host[h]
                sorted_hosts = sorted(remote_by_host.keys())

            # One-time auto-collapse for groups exceeding threshold
            if not _groups_initialized:
                _groups_initialized = True
                if len(local_projects) > GROUP_COLLAPSE_THRESHOLD:
                    collapsed_groups.add("local")
                for h, items in remote_by_host.items():
                    if len(items) > GROUP_COLLAPSE_THRESHOLD:
                        collapsed_groups.add(f"remote:{h}")
                # Placeholder remote starts collapsed
                if not remote_by_host:
                    collapsed_groups.add("remote:__placeholder")

            def _render_project_entry(path, info):
                """Render a single project entry into menu_lines."""
                name = info.get("name", os.path.basename(path))
                is_current = (path in _active_projects)
                is_expanded = (path in expanded_projects)
                is_remote = is_remote_project(info)
                if is_remote:
                    exists = summaries.get(path, {}).get("exists", True)
                else:
                    exists = os.path.isdir(path)

                s = summaries.get(path, {})
                branch = s.get("branch") or ""
                rc = s.get("repo_count", 0)
                dirty = s.get("dirty_count", 0)
                ahead = s.get("ahead", 0)
                behind = s.get("behind", 0)

                # Dot indicator — color-coded by persona
                proj_persona = info.get("persona") or "yocto"
                if exists:
                    if is_current:
                        dot = terminal_color("project_active", "●")
                    elif proj_persona != "yocto":
                        dot = Colors.magenta("○")
                    else:
                        dot = terminal_color("project_name", "○")
                else:
                    dot = terminal_color("project_missing", "!")

                # Expand marker
                expand = "-" if is_expanded else "+"

                # Build status text (raw for padding, colored for display)
                if s.get("loading"):
                    raw_parts = ["loading..."]
                    col_parts = [Colors.dim("loading...")]
                elif rc == 0:
                    raw_parts = []
                    col_parts = []
                else:
                    raw_parts = [f"{rc:2} repos"]
                    col_parts = [f"{rc:2} repos"]
                    if dirty:
                        raw_parts.append(f"\u270e{dirty}")
                        col_parts.append(terminal_color("dirty", f"\u270e{dirty}"))
                    if ahead:
                        raw_parts.append(f"\u2191{ahead}")
                        col_parts.append(terminal_color("project_ahead", f"\u2191{ahead}"))
                    if behind:
                        raw_parts.append(f"\u2193{behind}")
                        col_parts.append(terminal_color("project_behind", f"\u2193{behind}"))
                    if not dirty and not ahead and not behind:
                        raw_parts.append("\u2713")
                        col_parts.append(terminal_color("clean", "\u2713"))
                if s.get("needs_setup"):
                    raw_parts.append("\u26a0 setup")
                    col_parts.append(Colors.yellow("\u26a0 setup"))
                raw_st = " ".join(raw_parts)
                colored_st = " ".join(col_parts)

                # Pad raw text BEFORE applying ANSI colors
                padded_name = f"{name:<{name_col}}"
                padded_branch = f"{branch:<{branch_col}}"
                # Status: pad with spaces after colored text
                st_padding = max(status_col - len(raw_st), 0)
                padded_status = colored_st + " " * st_padding

                # Apply colors after padding
                if is_current:
                    colored_name = Colors.bold(terminal_color("project_active", padded_name))
                elif not exists:
                    colored_name = terminal_color("project_missing", padded_name)
                else:
                    colored_name = Colors.bold(terminal_color("project_name", padded_name))

                colored_branch = terminal_color("project_branch", padded_branch) if branch else padded_branch
                colored_path = Colors.dim(path)

                # Build metadata parts for verbose / expander display
                meta_parts = []
                if proj_persona != "yocto":
                    meta_parts.append(Colors.dim(f"({proj_persona})"))
                explicit_tags = info.get("tags") or []
                if explicit_tags:
                    tag_str = " ".join(f"[{t}]" for t in explicit_tags)
                    meta_parts.append(Colors.cyan(tag_str))
                desc = info.get("description", "")
                if desc:
                    meta_parts.append(Colors.dim(Colors.italic(desc)))

                indent = "  " if _grouped[0] else ""
                if show_verbose and meta_parts:
                    padded_path_v = f"{path:<{path_col}}"
                    colored_path_v = Colors.dim(padded_path_v)
                    meta_suffix = f"  {' '.join(meta_parts)}"
                    display = f"{indent}{expand} {dot} {colored_name} {colored_branch} {padded_status} {colored_path_v}{meta_suffix}"
                else:
                    display = f"{indent}{expand} {dot} {colored_name} {colored_branch} {padded_status} {colored_path}"
                menu_lines.append(f"{path}\t{display}")

                # Action sub-items if expanded
                if is_expanded:
                    actions = _get_dashboard_actions(info)
                    if summaries.get(path, {}).get("needs_setup"):
                        actions.insert(0, ("setup", "Complete project setup (apply config)"))

                    # Build detail rows to append after actions
                    detail_rows = []

                    # Traits: persona + tags + description in one line
                    trait_parts = []
                    if proj_persona != "yocto":
                        trait_parts.append(proj_persona)
                    if explicit_tags:
                        trait_parts.extend(explicit_tags)
                    if desc:
                        trait_parts.append(desc)
                    if trait_parts:
                        detail_rows.append(("traits", " · ".join(trait_parts)))

                    # Last updated — prefer summary (works for local + remote),
                    # fall back to filesystem check for local repos
                    _summary_ts = summaries.get(path, {}).get("last_updated")
                    _updated_ts = (_relative_time(_summary_ts) if _summary_ts
                                   else _get_last_updated(path))
                    if _updated_ts:
                        _updated_display = _updated_ts
                        # For auto-update projects, show checked + next
                        if "auto-update" in (explicit_tags or []):
                            _checked = _get_daemon_last_checked(path)
                            _next = _get_daemon_next_check(path)
                            parts = []
                            if _checked:
                                parts.append(f"checked {_checked}")
                            if _next:
                                parts.append(f"next: {_next}")
                            if parts:
                                _updated_display += f" ({' · '.join(parts)})"
                        detail_rows.append(("last updated", _updated_display))

                    total_rows = len(actions) + len(detail_rows)
                    for idx, (cmd, action_desc) in enumerate(actions):
                        is_last = (idx == total_rows - 1)
                        tree_char = "└─" if is_last else "├─"
                        action_line = f"{indent}  {tree_char} {Colors.cyan(f'{cmd:<14}')}{Colors.dim(action_desc)}"
                        menu_lines.append(f"ACTION:{path}:{cmd}\t{action_line}")
                    for idx, (label, value) in enumerate(detail_rows):
                        is_last = (len(actions) + idx == total_rows - 1)
                        tree_char = "└─" if is_last else "├─"
                        detail_line = f"{indent}  {tree_char} {Colors.dim(f'{label:<14}')}{Colors.dim(value)}"
                        menu_lines.append(f"DETAIL:{path}\t{detail_line}")

            _group_index = [0]  # track group count for separator logic
            _grouped = [False]  # whether group headers are being rendered

            def _render_group(group_key, label, items):
                """Render a group header and its project entries."""
                count = len(items)
                is_collapsed = group_key in collapsed_groups

                # Dotted separator line before every group except the first
                if _group_index[0] > 0:
                    menu_lines.append(f"SEP_GROUP_{group_key}\t  {Colors.dim('╌' * total_width)}")
                _group_index[0] += 1

                # Group header line (selectable — toggles collapse)
                marker = "+" if is_collapsed else "-"
                group_display = f"{marker} {label}"
                if is_collapsed:
                    group_display += f"  {Colors.dim(f'({count})')}"
                menu_lines.append(f"GROUP:{group_key}\t{group_display}")

                if is_collapsed:
                    return

                # Render each project
                for path, info in items:
                    _render_project_entry(path, info)

                # Sync action after projects for remote host groups
                if group_key.startswith("remote:") and items:
                    host = group_key[7:]  # strip "remote:" prefix
                    user = items[0][1].get("user", "")
                    host_spec = f"{user}@{host}" if user else host
                    sync_line = f"  └─ {Colors.cyan(f'{'sync':<14}')}{Colors.dim('Sync projects from this host')}"
                    menu_lines.append(f"ACTION_SYNC:{host_spec}\t{sync_line}")
                    # Inline host metrics summary
                    _m = _host_metrics_cache.get(f"{user}@{host}:22") or \
                         next((v for k, v in _host_metrics_cache.items() if host in k), None)
                    if _m:
                        _ts, _md = _m
                        if not _md.get("error"):
                            _os = _md.get("os", "")
                            _kern = _md.get("kernel", "").split("-")[0] if _md.get("kernel") else ""
                            _load = f'{_md.get("load_1", 0):.1f}'
                            _mem = f'{_md.get("mem_pct", 0)}%'
                            _dpct = ""
                            if _md.get("disks"):
                                _max_d = max(int(d.get("pct", 0)) for d in _md["disks"])
                                _dpct = f"{_max_d}%"
                            parts = [p for p in [_os, _kern, f"load {_load}", f"mem {_mem}",
                                                 f"disk {_dpct}" if _dpct else ""] if p]
                            metrics_str = Colors.dim(f"  ↳ {' · '.join(parts)}")
                            menu_lines.append(f"SEP_METRICS_{group_key}\t{metrics_str}")

            has_remotes = bool(remote_by_host)

            # Always render with group headers
            _grouped[0] = True

            # Render local group
            if local_projects:
                local_label = f"{terminal_color('project_name', '⌂')} {Colors.bold('Local')}"
                _render_group("local", local_label, local_projects)

            if has_remotes:
                # Render real remote groups (one per host)
                for host in sorted_hosts:
                    items = remote_by_host[host]
                    host_label = f"{terminal_color('project_remote', '⇄')} {Colors.bold('Remote')} {Colors.dim('──')} {Colors.bold(host)}"
                    _render_group(f"remote:{host}", host_label, items)
            else:
                # Placeholder remote section with sync action
                placeholder_collapsed = "remote:__placeholder" in collapsed_groups
                marker = "+" if placeholder_collapsed else "-"
                remote_label = f"{marker} {terminal_color('project_remote', '⇄')} {Colors.bold('Remote')}"
                if local_projects:
                    menu_lines.append(f"SEP_GROUP_remote:__placeholder\t  {Colors.dim('╌' * total_width)}")
                menu_lines.append(f"GROUP:remote:__placeholder\t{remote_label}")
                if not placeholder_collapsed:
                    sync_line = f"  └─ {Colors.cyan(f'{'sync from remote...':<14}')}"
                    menu_lines.append(f"SYNC_DISCOVER\t{sync_line}")

            # Separator and manage entry
            menu_lines.append(f"SEP_BOTTOM\t  {'─' * total_width}")
            menu_lines.append(f"MANAGE\t  {Colors.dim('⚙')}  Manage projects...")
            menu_lines.append(f"CONFIGURE\t  {Colors.dim('⚙')}  Configure...")

        # Inline manage dialog: append items (reverse-list puts end of list near prompt)
        if show_manage:
            manage_actions = [
                ("MANAGE_ADD_CWD", f"{Colors.green('+')} Add current directory"),
                ("MANAGE_ADD_PATH", f"{Colors.green('+')} Enter path manually..."),
                ("MANAGE_BROWSE", f"{Colors.green('+')} Browse for directory..."),
                ("MANAGE_ADD_REMOTE", f"{Colors.cyan('⇄')} Add remote (SSH)..."),
                ("MANAGE_SYNC_REMOTE", f"{Colors.cyan('⇄')} Sync from remote..."),
            ]
            if current_project:
                manage_actions.append(("MANAGE_CLEAR", f"{Colors.red('✖')}  Clear active project"))
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Add Project", manage_actions, reverse_list=True,
            )

        # Inline configure dialog
        picker_idx = 0
        if show_configure:
            from .config import fzf_global_settings
            browser = get_directory_browser()
            browser_desc = {"auto": "auto-detect", "broot": "broot", "ranger": "ranger",
                            "nnn": "nnn", "fzf": "fzf built-in"}.get(browser, browser)
            git_viewer = get_git_viewer()
            viewer_desc = {"auto": "auto-detect", "tig": "tig", "lazygit": "lazygit",
                           "gitui": "gitui", "gitk": "gitk"}.get(git_viewer, git_viewer)
            preview_layout = get_preview_layout()
            layout_desc = {"down": "bottom", "right": "side-by-side", "up": "top"}.get(preview_layout, preview_layout)
            recipe_scan = "bitbake-layers" if get_recipe_use_bitbake_layers() else "file scan"
            default_cmd = get_default_dashboard_command()
            prune_age = get_backup_prune_age()
            prune_desc = "never" if prune_age == "never" else f"{prune_age} days"

            web_auto = get_web_autostart()
            web_auto_desc = {"off": "off", "localhost": "localhost", "all": "all interfaces"}.get(web_auto, web_auto)
            web_browser = "on" if get_web_open_browser() else "off"
            metrics_refresh = get_host_metrics_refresh()
            metrics_desc = {0: "off", 60: "1 min", 120: "2 min", 300: "5 min", 600: "10 min"}.get(metrics_refresh, f"{metrics_refresh}s")

            editor_pref = get_editor()
            editor_desc = {"auto": f"auto ({resolve_editor()})", "vim": "vim", "nvim": "neovim",
                           "nano": "nano", "emacs": "emacs", "code": "VS Code"}.get(editor_pref, editor_pref)
            nnn_colors = get_nnn_colors()
            nnn_color_names = {"0": "black", "1": "red", "2": "green", "3": "yellow",
                               "4": "blue", "5": "magenta", "6": "cyan", "7": "white"}
            nnn_desc = f"{nnn_color_names.get(nnn_colors[0:1], '?')} dirs ({nnn_colors})"
            from .ssh_remote import get_tmux_prefix
            tmux_prefix = get_tmux_prefix()
            graph_renderer = get_graph_renderer()
            graph_desc = {"auto": "auto-detect", "graph-easy": "Graph::Easy", "ascii": "ASCII"}.get(graph_renderer, graph_renderer)
            explore_load_size = get_explore_load_size()
            explore_desc = f"{explore_load_size} commits"

            conf_actions = [
                ("CONF_COLORS", "Colors and themes..."),
                ("CONF_BROWSER", f"Dir browser           {Colors.dim(browser_desc)}"),
                ("CONF_VIEWER", f"Git viewer            {Colors.dim(viewer_desc)}"),
                ("CONF_PREVIEW", f"Preview layout        {Colors.dim(layout_desc)}"),
                ("CONF_RECIPE", f"Recipe scan           {Colors.dim(recipe_scan)}"),
                ("CONF_DEFAULT_CMD", f"Default \u2192action       {Colors.dim(default_cmd)}"),
                ("CONF_BACKUP_PRUNE", f"Backup prune age      {Colors.dim(prune_desc)}"),
                ("CONF_EDITOR", f"Editor                {Colors.dim(editor_desc)}"),
                ("CONF_NNN_COLORS", f"NNN colors            {Colors.dim(nnn_desc)}"),
                ("CONF_TMUX", f"Tmux prefix           {Colors.dim(tmux_prefix)}"),
                ("CONF_WEB_AUTOSTART", f"Web autostart         {Colors.dim(web_auto_desc)}"),
                ("CONF_WEB_OPEN_BROWSER", f"Web open browser      {Colors.dim(web_browser)}"),
                ("CONF_METRICS_REFRESH", f"Metrics refresh       {Colors.dim(metrics_desc)}"),
                ("CONF_GRAPH_RENDERER", f"Graph renderer        {Colors.dim(graph_desc)}"),
                ("CONF_EXPLORE_LOAD_SIZE", f"Explore load size     {Colors.dim(explore_desc)}"),
                ("---", ""),
                ("CONF_ALL_SETTINGS", "All settings..."),
            ]
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Configure", conf_actions, reverse_list=True,
            )

            # Inline sub-picker within configure dialog
            if conf_picker:
                from .config import _build_setting_picker_lines
                picker_lines, picker_idx = _build_setting_picker_lines(conf_picker)
                menu_lines = menu_lines + picker_lines

        # Inline pane selector dialog
        if show_pane_selector:
            from ..tags import load_panes as _load_panes
            from ..persona import get_global_default_persona
            default_persona = get_global_default_persona()
            _all_panes = _load_panes()
            pane_actions = []
            for _p in _all_panes:
                _sel = "●" if _p["name"] == active_pane["name"] else "○"
                _tag_hint = ", ".join(_p["tags"]) if _p["tags"] else "all"
                pane_actions.append((f"PANE_{_p['name']}", f"{_sel} {_p['name']}  {Colors.dim(f'({_tag_hint})')}"))
            pane_actions.append(("---", ""))
            pane_actions.append(("PANE_NEW", f"  + New pane..."))
            pane_actions.append(("PANE_MANAGE", f"  ⚙  Manage panes..."))
            pane_actions.append(("---", ""))
            pane_actions.append(("PANE_DEFAULT_yocto", f"{'●' if default_persona == 'yocto' else '○'} Default: Yocto"))
            pane_actions.append(("PANE_DEFAULT_generic", f"{'●' if default_persona == 'generic' else '○'} Default: Generic"))
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Panes", pane_actions, reverse_list=True,
            )

        # Inline export dialog with fragment toggles
        if show_export and export_context:
            pname = export_context["project_name"]
            n_src = len(export_context["sources"])
            n_lay = len(export_context["relative_layers"])
            frags = export_context["fragments"]
            export_actions: List[Tuple[str, str]] = []
            if frags:
                export_actions.append(("---", ""))  # separator
                for frag in frags:
                    chk = "[x]" if export_enabled.get(frag, True) else "[ ]"
                    export_actions.append((f"EXPORT_TOGGLE:{frag}", f"  {chk} {frag}"))
            desc_display = export_description if export_description else Colors.dim("(none — click to set)")
            export_actions.append(("EXPORT_DESC", f"  Description: {desc_display}"))
            export_actions.append(("---", ""))  # separator
            export_actions.append(("EXPORT_FILE", f"  > Export to file      {Colors.dim(f'{pname}.conf.json')}"))
            export_actions.append(("EXPORT_REGISTRY", f"  > Export to registry  {Colors.dim('~/.config/bit/registry/')}"))
            annotation = Colors.dim(f"{n_src} repos, {n_lay} layers, {len(frags)} fragments")
            menu_lines = menu_lines + build_inline_dialog_lines(
                "Export", export_actions, reverse_list=True, annotation=annotation,
            )

        # Inline search options panel
        if show_search:
            options_lines = options_state.build_menu_lines()
            for line in options_lines:
                menu_lines.append(line)

        # Inline update dialog: append dialog items (reverse-list puts end near prompt)
        has_dialog = dialog_state.has_dialog()
        dialog_needs_text = (has_dialog and dialog_state.active_dialog
                             and dialog_state.active_dialog.dialog_type == DialogType.TEXT_PROMPT)
        if has_dialog:
            dialog_lines = dialog_state.get_dialog_menu_lines()
            for value, display in dialog_lines:
                menu_lines.append(f"{value}\t{display}")

        menu_input = "\n".join(menu_lines)

        # Header
        if has_dialog:
            if (dialog_state.active_dialog
                    and dialog_state.active_dialog.done_label):
                header = "Enter/Space/→=select | Esc/←=done"
            else:
                header = "Enter/Space/→=select | Esc/←=cancel"
        elif show_search:
            header = options_state.menu.header
        else:
            # All keybinding hints — order matters for grouping
            _hints = [
                "Space=activate", "Enter/\u2192=open", "\\=fold",
                "?/m=commands", "+/-=add/remove", "q=quit",
                "x=explore", "r/R=refresh", "u=update",
                "c=config", "S=shell",
                "M=messages", "P=panes,^P=cycle", "v=verbose",
                "w=web", "h=hosts", "/,ctrl-s=search",
            ]
            # Wrap hints into lines matching menu content width
            wrap_width = total_width + 4  # +4 for leading indent
            header_lines = []
            cur = ""
            for hint in _hints:
                candidate = f"{cur} | {hint}" if cur else hint
                if cur and len(candidate) > wrap_width:
                    header_lines.append(cur)
                    cur = hint
                else:
                    cur = candidate
            if cur:
                header_lines.append(cur)
            # Add search hint and filter indicator
            filter_parts = []
            if search_term:
                filter_parts.append(f'"{search_term}"')
            if status_filters:
                filter_parts.append("+".join(sorted(status_filters)))
            if active_pane.get("tags"):
                filter_parts.append(f"pane:{active_pane['name']}")
            if filter_parts:
                filter_indicator = f"\U0001f50d {' '.join(filter_parts)}  (/=search  ctrl-r=reset)"
                header_lines.append(filter_indicator)
            header = "\n".join(header_lines)

        # Prepend most-recent status message (shown for one fzf iteration)
        status_msg = consume_header_message()
        if status_msg:
            header = f"{terminal_color('status_message', status_msg)}\n{header}"

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--layout=reverse-list",
            "--height", "~80%",
            "--header", header,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        if dialog_needs_text:
            prompt = dialog_state.get_prompt_text() or "Input: "
            default = dialog_state.active_dialog.default or ""
            fzf_args.extend(["--disabled", "--print-query", "--prompt", prompt])
            if default:
                fzf_args.extend(["--query", default])
        elif has_dialog:
            prompt = dialog_state.get_prompt_text() or "Select: "
            fzf_args.extend(["--disabled", "--prompt", prompt])
        elif show_manage:
            fzf_args.extend(["--disabled", "--prompt", "Manage: "])
        elif show_configure:
            _picker_prompts = {
                "BROWSER": "Browser: ",
                "GITVIEWER": "Viewer: ",
                "PREVIEW": "Layout: ",
                "RECIPE": "Scan: ",
                "BACKUP_PRUNE": "Prune age: ",
                "DEFAULT_CMD": "Action: ",
            }
            prompt = _picker_prompts.get(conf_picker, "Configure: ") if conf_picker else "Configure: "
            fzf_args.extend(["--disabled", "--prompt", prompt])
        elif show_pane_selector:
            fzf_args.extend(["--disabled", "--prompt", "Panes: "])
        elif show_export and export_desc_input:
            fzf_args.extend([
                "--print-query", "--disabled",
                "--query", export_description,
                "--header", "Type description, Enter=confirm  (Esc=cancel)",
                "--prompt", "Desc: ",
            ])
        elif show_export:
            fzf_args.extend(["--disabled", "--prompt", "Export: "])
        elif show_search:
            fzf_args.extend(options_state.get_fzf_args())
            fzf_args.extend(["--prompt", "Query: "])
        else:
            fzf_args.extend(["--prompt", "Dashboard: "])

        # Bindings: search panel and text-input dialogs need typed characters,
        # so skip become(echo ...) action bindings that would intercept keys.
        # When any dialog is active (including SELECT_ONE), skip letter
        # keybindings to avoid accidental actions — navigation keys still work.
        if not show_search and not dialog_needs_text:
            fzf_args.extend(["--bind", "enter:become(echo ENTER {1})"])
            fzf_args.extend(get_action_binding("right", "RIGHT {1}"))
            fzf_args.extend(get_action_binding("left", "LEFT {1}"))
            fzf_args.extend(get_action_binding("\\", "EXPAND {1}"))
            fzf_args.extend(get_action_binding("space", "ACTIVATE {1}"))
            if not has_dialog:
                # Letter keybindings — only when no dialog is active
                fzf_args.extend(get_action_binding("?", "MENU {1}"))
                fzf_args.extend(get_action_binding("m", "MENU {1}"))
                fzf_args.extend(get_action_binding("+", "MANAGE"))
                fzf_args.extend(get_action_binding("-", "REMOVE {1}"))
                fzf_args.extend(get_action_binding("q", "QUIT"))
                # Direct action keybindings on highlighted project
                fzf_args.extend(get_action_binding("x", "EXPLORE {1}"))
                fzf_args.extend(get_action_binding("u", "UPDATE {1}"))
                fzf_args.extend(get_action_binding("c", "CONFIG {1}"))
                fzf_args.extend(get_action_binding("S", "SHELL {1}"))
                fzf_args.extend(get_action_binding("R", "REFRESH {1}"))
                fzf_args.extend(get_action_binding("r", "REFRESH {1}"))
                fzf_args.extend(get_action_binding("n", "RENAME {1}"))
                fzf_args.extend(get_action_binding("M", "MESSAGES"))
                fzf_args.extend(get_action_binding("P", "PANES"))
                fzf_args.extend(get_action_binding("ctrl-p", "PANE_CYCLE"))
                fzf_args.extend(get_action_binding("tab", "PANE_CYCLE"))
                fzf_args.extend(get_action_binding("w", "WEBSERVER"))
                fzf_args.extend(get_action_binding("h", "HOSTS"))
                fzf_args.extend(get_action_binding("v", "VERBOSE"))
                fzf_args.extend(get_action_binding("/", "SEARCH"))
                fzf_args.extend(get_action_binding("ctrl-s", "SEARCH"))
                fzf_args.extend(get_action_binding("ctrl-r", "RESET_FILTER"))
        fzf_args.extend(["--bind", "esc:abort"])

        # Override bindings when inline dialog is active (last-wins in fzf)
        if show_manage or show_configure or show_export or show_pane_selector:
            fzf_args.extend(["--bind", "right:become(echo ENTER {1})"])
        if show_export and not export_desc_input:
            fzf_args.extend(["--bind", "space:become(echo ENTER {1})"])
        # SELECT_ONE dialogs (tag picker, update, etc.): space/right also select,
        # left arrow dismisses (go back)
        if (has_dialog and not dialog_needs_text
                and dialog_state.active_dialog
                and dialog_state.active_dialog.dialog_type == DialogType.SELECT_ONE):
            fzf_args.extend(["--bind", "space:become(echo ENTER {1})"])
            fzf_args.extend(["--bind", "right:become(echo ENTER {1})"])
            fzf_args.extend(["--bind", "left:abort"])
        if export_desc_input:
            fzf_args.extend(["--bind", "enter:accept"])
        if dialog_needs_text:
            fzf_args.extend(["--bind", "enter:accept"])

        # Cursor positioning
        if dialog_needs_text:
            # Position on Confirm button so Enter works after typing
            key_list = [line.split("\t")[0] for line in menu_lines]
            for idx, k in enumerate(key_list):
                if k == "__DLG_CONFIRM__":
                    fzf_args.extend(get_position_binding(idx + 1))
                    break
        elif has_dialog:
            # Position on default dialog option
            default_line = dialog_state.get_default_cursor_line()
            if default_line:
                # Offset by number of non-dialog lines (dialog items are appended at end)
                non_dialog_count = len(menu_lines) - len(dialog_state.get_dialog_menu_lines())
                fzf_args.extend(get_position_binding(non_dialog_count + default_line))
        elif show_search:
            key_list = [line.split("\t")[0] for line in menu_lines]
            if search_cursor and search_cursor in key_list:
                pos = key_list.index(search_cursor) + 1
                fzf_args.extend(get_position_binding(pos))
                search_cursor = None
            else:
                # Default: first search panel item
                for idx, k in enumerate(key_list):
                    if k.startswith("OPT:"):
                        fzf_args.extend(get_position_binding(idx + 1))
                        break
        elif show_manage or show_configure or show_export or show_pane_selector:
            # Position cursor in the inline dialog
            key_list = [line.split("\t")[0] for line in menu_lines]
            if conf_picker:
                # Position cursor on current option in the sub-picker
                for idx, k in enumerate(key_list):
                    if k.startswith("OPT:"):
                        # offset by current_idx from picker
                        fzf_args.extend(get_position_binding(idx + 1 + picker_idx))
                        break
            else:
                target_key = (export_cursor if (show_export and export_cursor) else
                             conf_cursor if (show_configure and conf_cursor) else None)
                if target_key and target_key in key_list:
                    pos = key_list.index(target_key) + 1
                    fzf_args.extend(get_position_binding(pos))
                    export_cursor = None
                    conf_cursor = None
                else:
                    first_prefix = ("MANAGE_" if show_manage else
                                    "CONF_" if show_configure else
                                    "PANE_" if show_pane_selector else "EXPORT_")
                    for idx, k in enumerate(key_list):
                        if k.startswith(first_prefix):
                            fzf_args.extend(get_position_binding(idx + 1))
                            break
        elif last_selection and projects:
            key_list = [line.split("\t")[0] for line in menu_lines]
            if last_selection in key_list:
                pos = key_list.index(last_selection) + 1  # 1-indexed
                fzf_args.extend(get_position_binding(pos))

        fzf_args.extend(get_fzf_color_args())

        # Use Popen so we can terminate fzf when background fetch completes
        _refresh_triggered = [False]
        try:
            proc = subprocess.Popen(
                fzf_args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return 1

        # Watcher: terminate fzf when pending remote fetches finish
        with _remote_fetch_lock:
            has_pending = bool(_remote_fetch_pending)
        if has_pending:
            def _watch_remote(p, flag):
                while p.poll() is None:
                    with _remote_fetch_lock:
                        if not _remote_fetch_pending:
                            flag[0] = True
                            p.terminate()
                            return
                    time.sleep(0.5)
            threading.Thread(
                target=_watch_remote, args=(proc, _refresh_triggered),
                daemon=True,
            ).start()

        stdout, _ = proc.communicate(input=menu_input)
        result = subprocess.CompletedProcess(
            args=fzf_args, returncode=proc.returncode, stdout=stdout or "",
        )

        if export_desc_input:
            export_desc_input = False
            if result.returncode != 0:
                continue  # Esc = cancel
            lines = result.stdout.splitlines()
            query = lines[0].strip() if lines else ""
            if query:
                export_description = query
            continue

        # Parse text-input dialog (--print-query format: query\nselected)
        if dialog_needs_text:
            if result.returncode != 0:
                dialog_state.clear_dialog()
                continue
            lines = result.stdout.split("\n")
            query = lines[0].strip() if lines else ""
            selected_value = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""
            if dialog_state.is_dialog_selection(selected_value):
                result_dlg = dialog_state.handle_dialog_selection(selected_value, query)
                old_dialog = dialog_state.active_dialog
                if result_dlg.confirmed:
                    if old_dialog and old_dialog.on_confirm:
                        old_dialog.on_confirm(result_dlg.value)
                    if dialog_state.active_dialog is old_dialog:
                        dialog_state.clear_dialog()
                else:
                    dialog_state.clear_dialog()
            else:
                dialog_state.clear_dialog()
            continue

        # Parse search options panel (--print-query format: query\nkey\nselection)
        # Enter on ANY item triggers search; Space toggles.
        if show_search:
            if result.returncode != 0:
                show_search = False
                continue
            lines = result.stdout.split("\n")
            query = lines[0].strip() if lines else ""
            key_pressed = lines[1].strip() if len(lines) > 1 else ""
            selected = lines[2].split("\t")[0].strip() if len(lines) > 2 else ""
            item_key = selected[len("OPT:"):] if selected.startswith("OPT:") else ""

            # Tab on a toggle → toggle and re-render, stay on same item
            if key_pressed == "tab" and item_key in options_state.get_all_states():
                options_state.toggle(item_key)
                search_cursor = f"OPT:{item_key}"
                continue

            # Enter on Reset action → clear everything
            if not key_pressed and item_key == "reset":
                show_search = False
                search_term = ""
                search_fields = set()
                status_filters = set()
                active_pane = {"name": "All", "tags": [], "builtin": True}
                for k in ("dirty", "ahead", "behind", "needs_setup"):
                    options_state.set_state(k, False)
                continue

            # Enter on anything else → apply search
            if not key_pressed:
                show_search = False
                states = options_state.get_all_states()
                search_fields = {
                    k for k in ("name", "description", "branch", "path", "host")
                    if states.get(k)
                }
                status_filters = {
                    k for k in ("dirty", "ahead", "behind", "needs_setup")
                    if states.get(k)
                }
                search_term = query.strip()
                continue

            continue

        if result.returncode != 0 or not result.stdout.strip():
            # Background fetch completed — re-render with fresh data
            if _refresh_triggered[0]:
                continue
            # Esc/abort: dismiss dialog if open, else quit
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            if show_manage:
                show_manage = False
                continue
            if show_configure:
                if conf_picker:
                    conf_picker = None
                else:
                    show_configure = False
                continue
            if show_pane_selector:
                show_pane_selector = False
                continue
            if show_export:
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
                continue
            _prompt_web_server_exit()
            return 0

        output = result.stdout.strip()

        # --- Parse output ---

        # Non-selectable keys
        non_selectable = {"HEADER", "MANAGE_SEP", "CONF_SEP", "---"}

        # Handle dialog selections (Enter on a __DLG_ item)
        if has_dialog and output.startswith("ENTER __DLG_"):
            selected_value = output[6:]  # Strip "ENTER " prefix
            if dialog_state.is_dialog_selection(selected_value):
                result_dlg = dialog_state.handle_dialog_selection(selected_value, "")
                old_dialog = dialog_state.active_dialog
                if result_dlg.confirmed:
                    if old_dialog and old_dialog.on_confirm:
                        old_dialog.on_confirm(result_dlg.value)
                    # Only clear if callback didn't chain a new dialog
                    if dialog_state.active_dialog is old_dialog:
                        dialog_state.clear_dialog()
                else:
                    dialog_state.clear_dialog()
            else:
                dialog_state.clear_dialog()
            continue

        # Dismiss dialog on any other action
        if has_dialog:
            dialog_state.clear_dialog()
            continue

        if output == "QUIT":
            _prompt_web_server_exit()
            return 0

        if output == "SEARCH":
            show_search = True
            continue

        if output == "RESET_FILTER":
            search_term = ""
            search_fields = set()
            status_filters = set()
            active_pane = {"name": "All", "tags": [], "builtin": True}
            for k in ("dirty", "ahead", "behind", "needs_setup"):
                options_state.set_state(k, False)
            continue

        if output == "VERBOSE":
            show_verbose = not show_verbose
            continue

        if output == "MESSAGES":
            fzf_message_viewer()
            continue

        if output == "PANES":
            show_pane_selector = True
            show_manage = False
            show_configure = False
            conf_picker = None
            continue

        if output == "PANE_CYCLE":
            # Tab key cycles to next pane
            from ..tags import load_panes as _load_panes_cycle
            _cycle_panes = _load_panes_cycle()
            if _cycle_panes:
                _cur_idx = next((i for i, p in enumerate(_cycle_panes) if p["name"] == active_pane["name"]), -1)
                _next_idx = (_cur_idx + 1) % len(_cycle_panes)
                active_pane = _cycle_panes[_next_idx]
                from ..tags import set_active_pane as _set_active
                _set_active(active_pane["name"])
                log_message(f"{Colors.green('✓')} Pane: {active_pane['name']}")
            continue

        # Pane dialog item selections
        if output.startswith("ENTER PANE_") or output.startswith("RIGHT PANE_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected not in non_selectable:
                if selected == "PANE_NEW":
                    show_pane_selector = False
                    from ..tags import create_or_update_pane as _create_pane

                    def _on_pane_name(pane_name):
                        if not pane_name or not pane_name.strip():
                            return
                        pane_name = pane_name.strip()

                        def _on_pane_tags(tags_str, _pn=pane_name):
                            nonlocal active_pane
                            pane_tags = [t.strip() for t in (tags_str or "").split(",") if t.strip()]
                            _create_pane(_pn, pane_tags)
                            active_pane = {"name": _pn, "tags": pane_tags}
                            from ..tags import set_active_pane as _set_active_new
                            _set_active_new(_pn)
                            log_message(f"{Colors.green('✓')} Created pane: {_pn}")

                        dialog_state.show_dialog(
                            text_input_dialog("Tags (comma-separated)", on_confirm=_on_pane_tags)
                        )

                    dialog_state.show_dialog(
                        text_input_dialog("Pane name", on_confirm=_on_pane_name)
                    )
                    continue
                elif selected == "PANE_MANAGE":
                    show_pane_selector = False
                    from ..tags import (load_panes as _load_panes_mgmt,
                                        delete_pane as _delete_pane,
                                        rename_pane as _rename_pane,
                                        create_or_update_pane as _update_pane)
                    _mgmt_panes = _load_panes_mgmt()
                    _user_panes = [p for p in _mgmt_panes if not p.get("builtin")]
                    if _user_panes:
                        _options = [
                            (p["name"], p["name"], ", ".join(p["tags"]) or "(no tags)")
                            for p in _user_panes
                        ]

                        def _on_pane_chosen(chosen):
                            if not chosen:
                                return
                            _actions = [
                                ("rename", "Rename", f"Rename '{chosen}'"),
                                ("retag", "Edit tags", "Change pane tag filters"),
                                ("delete", "Delete", f"Delete '{chosen}'"),
                            ]

                            def _on_action(action, _pname=chosen):
                                nonlocal active_pane
                                if action == "rename":
                                    def _on_new_name(new_name, _old=_pname):
                                        nonlocal active_pane
                                        if not new_name or new_name == _old:
                                            return
                                        try:
                                            _rename_pane(_old, new_name)
                                            if active_pane["name"] == _old:
                                                active_pane["name"] = new_name
                                            log_message(f"{Colors.green('✓')} Renamed: {_old} → {new_name}")
                                        except ValueError as e:
                                            log_message(f"{Colors.red('✗')} {e}")
                                    dialog_state.show_dialog(
                                        text_input_dialog("Rename pane", default=_pname, on_confirm=_on_new_name)
                                    )
                                elif action == "retag":
                                    _cur = find_pane(_pname)
                                    _cur_tags = ", ".join(_cur["tags"]) if _cur else ""

                                    def _on_new_tags(tags_str, _pn=_pname):
                                        nonlocal active_pane
                                        new_tags = [t.strip() for t in (tags_str or "").split(",") if t.strip()]
                                        _update_pane(_pn, new_tags)
                                        if active_pane["name"] == _pn:
                                            active_pane["tags"] = new_tags
                                        log_message(f"{Colors.green('✓')} Tags for {_pn}: {', '.join(new_tags) if new_tags else '(none)'}")
                                    dialog_state.show_dialog(
                                        text_input_dialog("Tags (comma-separated)", default=_cur_tags, on_confirm=_on_new_tags)
                                    )
                                elif action == "delete":
                                    def _on_delete_confirm(confirmed, _pn=_pname):
                                        nonlocal active_pane
                                        if confirmed:
                                            try:
                                                _delete_pane(_pn)
                                                if active_pane["name"] == _pn:
                                                    active_pane = {"name": "All", "tags": [], "builtin": True}
                                                log_message(f"{Colors.green('✓')} Deleted pane: {_pn}")
                                            except ValueError as e:
                                                log_message(f"{Colors.red('✗')} {e}")
                                    dialog_state.show_dialog(
                                        confirm_action_dialog(f"Delete '{_pname}'?", on_confirm=_on_delete_confirm)
                                    )

                            dialog_state.show_dialog(
                                select_action_dialog(
                                    f"Manage: {chosen}",
                                    _actions,
                                    on_confirm=_on_action,
                                )
                            )

                        dialog_state.show_dialog(
                            select_action_dialog(
                                "Manage panes",
                                _options,
                                on_confirm=_on_pane_chosen,
                            )
                        )
                    else:
                        log_message("No user panes to manage")
                    continue
                elif selected.startswith("PANE_DEFAULT_"):
                    new_default = selected[len("PANE_DEFAULT_"):]
                    from ..persona import set_global_default_persona
                    set_global_default_persona(new_default)
                    log_message(f"{Colors.green('✓')} Default persona: {new_default}")
                else:
                    # Switch to selected pane
                    pane_name = selected[len("PANE_"):]
                    from ..tags import load_panes as _load_panes_sel, set_active_pane as _set_active_sel
                    for _p in _load_panes_sel():
                        if _p["name"] == pane_name:
                            active_pane = _p
                            _set_active_sel(pane_name)
                            break
            show_pane_selector = False
            continue

        # Group header toggle (Enter/Expand/Right on GROUP: items)
        _group_prefix = None
        for _gp in ("ENTER GROUP:", "EXPAND GROUP:", "RIGHT GROUP:"):
            if output.startswith(_gp):
                _group_prefix = _gp
                break
        if _group_prefix:
            group_key = output[len(_group_prefix):]
            # Enter on remote group header → open shell to host
            if _group_prefix == "ENTER GROUP:" and group_key.startswith("remote:"):
                host = group_key[len("remote:"):]
                user = ""
                for _p, _info in projects.items():
                    if is_remote_project(_info) and _info.get("host") == host:
                        user = _info.get("user", "")
                        break
                addr, _port = ssh_resolve_address(user, host)
                remote_shell(user, addr, "", port=_port)
                last_selection = f"GROUP:{group_key}"
                continue
            if group_key in collapsed_groups:
                collapsed_groups.discard(group_key)
            else:
                collapsed_groups.add(group_key)
            last_selection = f"GROUP:{group_key}"
            continue

        # Enter/S on host metrics summary line → open shell to that host
        _metrics_host = None
        for _mp in ("ENTER SEP_METRICS_remote:", "SHELL SEP_METRICS_remote:",
                     "RIGHT SEP_METRICS_remote:"):
            if output.startswith(_mp):
                _metrics_host = output[len(_mp):]
                break
        if _metrics_host:
            user = ""
            for _p, _info in projects.items():
                if is_remote_project(_info) and _info.get("host") == _metrics_host:
                    user = _info.get("user", "")
                    break
            addr, _port = ssh_resolve_address(user, _metrics_host)
            remote_shell(user, addr, "", port=_port)
            continue

        # Manage dialog activation (+ key or Enter on manage entry)
        if output in ("MANAGE", "ENTER MANAGE", "RIGHT MANAGE"):
            show_manage = True
            show_configure = False
            conf_picker = None
            continue

        # Configure dialog activation (Enter/Right on configure entry)
        if output in ("CONFIGURE", "ENTER CONFIGURE", "RIGHT CONFIGURE"):
            show_configure = True
            show_manage = False
            continue

        # Manage dialog item selections
        if output.startswith("ENTER MANAGE_") or output.startswith("RIGHT MANAGE_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected not in non_selectable:
                _dashboard_handle_manage(selected, projects, dialog_state,
                                         persona=active_pane.get("tags", [None])[0] if len(active_pane.get("tags", [])) == 1 else None)
            show_manage = False
            continue

        # Configure sub-picker selections (OPT: items within conf_picker)
        if conf_picker and (output.startswith("ENTER OPT:") or output.startswith("RIGHT OPT:")):
            opt_value = output.split(" ", 1)[1] if " " in output else ""
            if opt_value.startswith("OPT:"):
                from .config import _apply_setting
                _apply_setting(conf_picker, opt_value[4:])
            conf_picker = None
            continue

        # Configure dialog item selections
        if output.startswith("ENTER CONF_") or output.startswith("RIGHT CONF_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected not in non_selectable:
                # Map CONF_ actions to inline picker names
                _conf_to_picker = {
                    "CONF_BROWSER": "BROWSER",
                    "CONF_VIEWER": "GITVIEWER",
                    "CONF_PREVIEW": "PREVIEW",
                    "CONF_RECIPE": "RECIPE",
                    "CONF_BACKUP_PRUNE": "BACKUP_PRUNE",
                    "CONF_DEFAULT_CMD": "DEFAULT_CMD",
                    "CONF_EDITOR": "EDITOR",
                    "CONF_NNN_COLORS": "NNN_COLORS",
                    "CONF_WEB_AUTOSTART": "WEB_AUTOSTART",
                    "CONF_WEB_OPEN_BROWSER": "WEB_OPEN_BROWSER",
                    "CONF_METRICS_REFRESH": "METRICS_REFRESH",
                    "CONF_GRAPH_RENDERER": "GRAPH_RENDERER",
                    "CONF_EXPLORE_LOAD_SIZE": "EXPLORE_LOAD_SIZE",
                }
                if selected in _conf_to_picker:
                    conf_picker = _conf_to_picker[selected]
                else:
                    _dashboard_handle_configure(selected)
            continue

        # Export dialog item selections
        if output.startswith("ENTER EXPORT_") or output.startswith("RIGHT EXPORT_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected == "EXPORT_DESC":
                export_desc_input = True
            elif selected.startswith("EXPORT_TOGGLE:"):
                frag_key = selected[len("EXPORT_TOGGLE:"):]
                export_enabled[frag_key] = not export_enabled.get(frag_key, True)
                export_cursor = selected  # stay on this item
            elif selected == "EXPORT_FILE" and export_context:
                from .setup import _write_export
                pname = export_context["project_name"]
                sel_frags = [f for f in export_context["fragments"]
                             if export_enabled.get(f, True)]
                _write_export(pname, export_context["sources"],
                              export_context["relative_layers"],
                              sel_frags, f"{pname}.conf.json",
                              description=export_description)
                log_message(f"{Colors.green('Exported')} {pname}.conf.json")
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
            elif selected == "EXPORT_REGISTRY" and export_context:
                from .setup import _write_export
                pname = export_context["project_name"]
                sel_frags = [f for f in export_context["fragments"]
                             if export_enabled.get(f, True)]
                _write_export(pname, export_context["sources"],
                              export_context["relative_layers"],
                              sel_frags, f"{pname}.conf.json", to_registry=True,
                              description=export_description)
                log_message(f"{Colors.green('Exported')} to registry: {pname}.conf.json")
                show_export = False
                export_context = {}
                export_enabled = {}
                export_cursor = None
                export_description = ""
            continue

        # LEFT while in dialog mode → dismiss
        if show_manage and output.startswith("LEFT "):
            show_manage = False
            continue
        if show_configure and output.startswith("LEFT "):
            if conf_picker:
                conf_picker = None
            else:
                show_configure = False
            continue
        if show_export and output.startswith("LEFT "):
            show_export = False
            export_context = {}
            export_enabled = {}
            export_description = ""
            continue
        if show_pane_selector and output.startswith("LEFT "):
            show_pane_selector = False
            continue

        # Activate/deactivate project (toggle)
        if output.startswith("ACTIVATE "):
            selected = output[9:].strip()
            if selected.startswith("ACTION:") or selected.startswith("ACTION_SYNC:") or selected == "SYNC_DISCOVER" or selected.startswith("GROUP:") or selected in non_selectable or selected.startswith("SEP_") or selected.startswith("DETAIL:") or selected == "MANAGE":
                continue
            if selected and _project_key_valid(selected, projects):
                sel_persona = projects.get(selected, {}).get("persona") or "yocto"
                if selected in _active_projects:
                    # Already active → deactivate
                    set_current_project(None, persona_name=sel_persona)
                    name = projects.get(selected, {}).get("name", os.path.basename(selected))
                    log_message(f"{Colors.yellow('○')} Deactivated: {name}")
                else:
                    set_current_project(selected, persona_name=sel_persona)
                    name = projects.get(selected, {}).get("name", os.path.basename(selected))
                    log_message(f"{Colors.green('✓')} Activated: {Colors.bold(name)}")
            last_selection = selected
            continue

        # Remove project (- key) — show confirm dialog
        if output.startswith("REMOVE "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and selected in projects:
                name = projects[selected].get("name", os.path.basename(selected))
                target_path = selected  # capture for closure

                def _on_remove_confirm(confirmed):
                    if confirmed:
                        remove_project(target_path)
                        log_message(f"{Colors.yellow('✓')} Removed: {name}")
                        nonlocal last_selection
                        if last_selection == target_path:
                            last_selection = None

                dialog_state.show_dialog(
                    confirm_action_dialog(
                        f"Remove '{name}'?",
                        message=target_path,
                        on_confirm=_on_remove_confirm,
                    )
                )
            continue

        # Rename project (n key) — show text input dialog
        if output.startswith("RENAME "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and selected in projects:
                current_name = projects[selected].get("name", os.path.basename(selected))
                target_path = selected  # capture for closure

                def _on_rename(new_name):
                    if new_name and new_name != current_name:
                        projects[target_path]["name"] = new_name
                        save_projects(projects)
                        log_message(f"{Colors.green('✓')} Renamed: {current_name} → {new_name}")

                dialog_state.show_dialog(
                    text_input_dialog(
                        "Rename project",
                        message=selected,
                        default=current_name,
                        on_confirm=_on_rename,
                    )
                )
                last_selection = selected
            continue

        # Command menu (? or m)
        if output.startswith("MENU "):
            selected = output[5:].strip()
            target = None
            if selected.startswith("ACTION:"):
                target, _ = _parse_action_key(selected)
            elif selected and not selected.startswith("SEP_") and not selected.startswith("DETAIL:") and not selected.startswith("GROUP:") and selected not in non_selectable and selected != "MANAGE":
                target = selected
            if not target or not _project_key_valid(target, projects):
                target = current_project
            if target and _project_key_valid(target, projects):
                target_info = projects.get(target, {})
                last_selection = target
                if is_remote_project(target_info):
                    # Remote: fall back to shell (no local command menu)
                    user = target_info.get("user", "")
                    host = target_info["host"]
                    rpath = target_info.get("remote_path", "")
                    addr, _port = ssh_resolve_address(user, host)
                    remote_shell(user, addr, rpath, port=_port)
                else:
                    saved_cwd = os.getcwd()
                    try:
                        os.chdir(target)
                        from ..cli import fzf_command_menu, main as cli_main
                        cmd = fzf_command_menu()
                        if cmd:
                            cli_main(cmd.split())
                    finally:
                        try:
                            os.chdir(saved_cwd)
                        except OSError:
                            pass
            else:
                # No valid project context — show command menu in cwd
                from ..cli import fzf_command_menu, main as cli_main
                cmd = fzf_command_menu()
                if cmd:
                    cli_main(cmd.split())
            continue

        # Expand/collapse toggle
        if output.startswith("EXPAND "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:") or selected.startswith("ACTION_SYNC:") or selected == "SYNC_DISCOVER" or selected in non_selectable or selected.startswith("SEP_") or selected.startswith("DETAIL:") or selected == "MANAGE":
                continue
            # Group header: toggle group collapse
            if selected.startswith("GROUP:"):
                group_key = selected[6:]
                if group_key in collapsed_groups:
                    collapsed_groups.discard(group_key)
                else:
                    collapsed_groups.add(group_key)
                last_selection = selected
                continue
            if selected:
                if selected in expanded_projects:
                    expanded_projects.discard(selected)
                else:
                    expanded_projects.add(selected)
                last_selection = selected
            continue

        # Update action — inline update dialog (same pattern as explore)
        if output.startswith("UPDATE "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and _project_key_valid(selected, projects):
                last_selection = selected
                sel_info = projects.get(selected, {})
                _start_update_dialogs(selected, dialog_state, project_info=sel_info)
            continue

        # Config action (c key — special handling for remote)
        if output.startswith("CONFIG "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and selected.startswith("GROUP:remote:"):
                # Group header → host addresses config
                host = selected[len("GROUP:remote:"):]
                last_selection = selected
                _show_host_addresses_dialog(host, dialog_state)
            elif selected and not selected.startswith("SEP_") and not selected.startswith("DETAIL:") and selected not in non_selectable and selected != "MANAGE" and not selected.startswith("GROUP:"):
                if _project_key_valid(selected, projects):
                    sel_info = projects.get(selected, {})
                    last_selection = selected
                    if is_remote_project(sel_info):
                        # Remote: open local project properties (name, desc are local)
                        _show_properties_dialog(selected, projects, dialog_state)
                    else:
                        _dashboard_run_command(selected, ["config"], project_info=sel_info)
            else:
                # Non-project line — preserve cursor position
                last_selection = selected
            continue

        # Direct action keybinding: explore (x)
        if output.startswith("EXPLORE "):
            selected = output[8:].strip()
            # Resolve ACTION: entries to their parent project
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected and not selected.startswith("SEP_") and not selected.startswith("DETAIL:") and selected not in non_selectable and selected != "MANAGE":
                if _project_key_valid(selected, projects):
                    sel_info = projects.get(selected, {})
                    _dashboard_run_command(selected, ["explore"], project_info=sel_info)
                    last_selection = selected
            continue

        # Web server action (w key)
        if output.startswith("WEBSERVER"):
            if _find_web_server():
                # Already running — offer status/stop/open
                server = _find_web_server()
                srv_url = f"http://{server['host']}:{server['port']}"

                def _on_web_running_selected(value):
                    if value == "__STOP__":
                        _stop_web_server()
                        log_message("Server stopped")
                    elif value == "__OPEN__":
                        import webbrowser
                        webbrowser.open(srv_url)
                        log_message(f"Opened {srv_url}")

                dialog_state.show_dialog(
                    select_action_dialog(
                        f"Server — {srv_url}",
                        options=[
                            ("__OPEN__", "Open in browser",
                             f"Open {srv_url}"),
                            ("__STOP__", "Stop server",
                             "Shut down the server"),
                        ],
                        on_confirm=_on_web_running_selected,
                    )
                )
            else:
                def _on_web_host_selected(value):
                    if value == "__CUSTOM__":
                        def _on_custom_addr(addr):
                            if not addr:
                                return
                            if ":" in addr:
                                h, _, p = addr.rpartition(":")
                                try:
                                    port = int(p)
                                except ValueError:
                                    log_message(f"Invalid port: {p}")
                                    return
                                msg = _launch_web_server(port=port, host=h or "127.0.0.1")
                            else:
                                msg = _launch_web_server(host=addr)
                            log_message(msg)
                        dialog_state.show_dialog(
                            text_input_dialog(
                                "Server address",
                                message="host:port",
                                default="127.0.0.1:8123",
                                placeholder="host:port",
                                on_confirm=_on_custom_addr,
                            )
                        )
                    elif value:
                        host, _, port_s = value.rpartition(":")
                        msg = _launch_web_server(
                            port=int(port_s), host=host,
                        )
                        log_message(msg)

                dialog_state.show_dialog(
                    select_action_dialog(
                        "Start Server",
                        options=[
                            ("127.0.0.1:8123", "Localhost only",
                             "127.0.0.1:8123 — local access only"),
                            ("0.0.0.0:8123", "All interfaces",
                             "0.0.0.0:8123 — accessible from network"),
                            ("__CUSTOM__", "Custom address...",
                             "Enter host:port manually"),
                        ],
                        on_confirm=_on_web_host_selected,
                        default_value="127.0.0.1:8123",
                    )
                )
            continue

        # Hosts view (h key) — full-screen host metrics table
        if output.startswith("HOSTS"):
            _show_hosts_view(projects)
            continue

        # Shell action (S key — special handling)
        if output.startswith("SHELL "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected == "GROUP:local":
                shell = os.environ.get("SHELL", "/bin/bash")
                subprocess.run([shell, "-l"])
            elif selected.startswith("GROUP:remote:"):
                # Shell on remote host group header → ssh to home dir
                host = selected[len("GROUP:remote:"):]
                # Get user from any project in this host group
                user = ""
                for _p, _info in projects.items():
                    if is_remote_project(_info) and _info.get("host") == host:
                        user = _info.get("user", "")
                        break
                addr, _port = ssh_resolve_address(user, host)
                remote_shell(user, addr, "", port=_port)
            elif selected and _project_key_valid(selected, projects):
                last_selection = selected
                sel_info = projects.get(selected, {})
                if is_remote_project(sel_info):
                    user = sel_info.get("user", "")
                    host = sel_info["host"]
                    rpath = sel_info.get("remote_path", "")
                    addr, _port = ssh_resolve_address(user, host)
                    remote_shell(user, addr, rpath, port=_port)
                else:
                    os.chdir(selected)
                    ns = argparse.Namespace(layers_dir="layers")
                    from .setup import run_init_shell
                    run_init_shell(ns)
            continue

        # Refresh status (R key) — invalidate cache for project or whole host group
        if output.startswith("REFRESH "):
            selected = output[8:].strip()
            if selected.startswith("ACTION:"):
                selected, _ = _parse_action_key(selected)
            if selected.startswith("GROUP:remote:"):
                host = selected[len("GROUP:remote:"):]
                count = 0
                for p, info in projects.items():
                    if is_remote_project(info) and info.get("host") == host:
                        _invalidate_summary_cache(p)
                        count += 1
                log_message(f"Refreshing {count} project(s) on {host}...")
            elif selected and _project_key_valid(selected, projects):
                _invalidate_summary_cache(selected)
                name = projects[selected].get("name", os.path.basename(selected))
                log_message(f"Refreshing {name}...")
                last_selection = selected
            continue

        # RIGHT arrow: expand project or run action
        if output.startswith("RIGHT "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                proj_path, cmd = _parse_action_key(selected)
                if cmd:
                    last_selection = proj_path
                    proj_info = projects.get(proj_path, {})
                    if cmd == "pull request":
                        if _project_key_valid(proj_path, projects):
                            _dashboard_run_command(proj_path, ["export", "prep"],
                                                   project_info=proj_info)
                    elif cmd == "update":
                        if _project_key_valid(proj_path, projects):
                            _start_update_dialogs(proj_path, dialog_state, project_info=proj_info)
                    elif cmd == "setup":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                _u = proj_info.get("user", "")
                                _a, _p = ssh_resolve_address(_u, proj_info["host"])
                                remote_run_action(
                                    _u, _a,
                                    proj_info.get("remote_path", ""),
                                    "setup apply", port=_p,
                                )
                            else:
                                _dashboard_run_setup(proj_path)
                            _invalidate_summary_cache(proj_path)
                    elif cmd == "shell":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                _u = proj_info.get("user", "")
                                _a, _p = ssh_resolve_address(_u, proj_info["host"])
                                remote_shell(_u, _a, proj_info.get("remote_path", ""), port=_p)
                            else:
                                os.chdir(proj_path)
                                ns = argparse.Namespace(layers_dir="layers")
                                from .setup import run_init_shell
                                run_init_shell(ns)
                    elif cmd == "export":
                        if _project_key_valid(proj_path, projects):
                            if proj_info and is_remote_project(proj_info):
                                log_message(f"{Colors.yellow('!')} Export not supported for remote projects")
                            else:
                                saved = os.getcwd()
                                try:
                                    os.chdir(proj_path)
                                    from .setup import gather_export_data
                                    edata = gather_export_data(layers_dir="layers")
                                    if edata:
                                        export_context = edata
                                        export_enabled = {f: True for f in edata["fragments"]}
                                        show_export = True
                                    else:
                                        log_message(f"{Colors.yellow('!')} No exportable config found")
                                finally:
                                    try:
                                        os.chdir(saved)
                                    except OSError:
                                        pass
                    elif cmd == "properties":
                        _show_properties_dialog(proj_path, projects, dialog_state)
                        last_selection = proj_path
                    elif _project_key_valid(proj_path, projects):
                        _dashboard_run_command(proj_path, [cmd], project_info=proj_info)
            elif selected == "SYNC_DISCOVER":
                _dashboard_handle_manage("SYNC_REMOTE", projects, dialog_state,
                                         persona=active_pane.get("tags", [None])[0] if len(active_pane.get("tags", [])) == 1 else None)
            elif selected.startswith("ACTION_SYNC:"):
                host_spec = selected[len("ACTION_SYNC:"):]
                if host_spec:
                    added = sync_from_remote(host_spec)
                    if added == -1:
                        log_message(f"{Colors.red('✗')} Cannot connect to {host_spec} via SSH")
                    elif added:
                        log_message(f"{Colors.green('✓')} Synced {added} project(s) from {host_spec}")
                    else:
                        log_message(f"No new projects found on {host_spec}")
            elif selected.startswith("GROUP:"):
                # RIGHT on group header: expand the group
                group_key = selected[6:]
                collapsed_groups.discard(group_key)
            elif selected and not selected.startswith("SEP_") and not selected.startswith("DETAIL:") and selected not in non_selectable and selected != "MANAGE":
                if selected in expanded_projects:
                    # Already expanded — run default command
                    proj_info = projects.get(selected, {})
                    if _project_key_valid(selected, projects):
                        default_cmd = get_default_dashboard_command()
                        _dashboard_run_command(selected, [default_cmd], project_info=proj_info)
                else:
                    expanded_projects.add(selected)
                last_selection = selected
            continue

        # LEFT arrow: collapse or quit
        if output.startswith("LEFT "):
            selected = output[5:].strip()
            if selected.startswith("ACTION:"):
                parent, _ = _parse_action_key(selected)
                expanded_projects.discard(parent)
                last_selection = parent
            elif selected == "SYNC_DISCOVER":
                collapsed_groups.add("remote:__placeholder")
                last_selection = "GROUP:remote:__placeholder"
            elif selected.startswith("ACTION_SYNC:"):
                # LEFT on sync action: collapse the parent remote group
                host_spec = selected[len("ACTION_SYNC:"):]
                host = host_spec.split("@", 1)[1] if "@" in host_spec else host_spec
                group_key = f"remote:{host}"
                collapsed_groups.add(group_key)
                last_selection = f"GROUP:{group_key}"
            elif selected.startswith("GROUP:"):
                # LEFT on group header: collapse the group
                group_key = selected[6:]
                collapsed_groups.add(group_key)
                last_selection = selected
            elif selected in expanded_projects:
                expanded_projects.discard(selected)
                last_selection = selected
            else:
                _prompt_web_server_exit()
                return 0
            continue

        # ENTER: toggle expand on project, run action on sub-item
        if output.startswith("ENTER "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                proj_path, cmd = _parse_action_key(selected)
                if cmd:
                    last_selection = proj_path
                    proj_info = projects.get(proj_path, {})
                    if cmd == "pull request":
                        if _project_key_valid(proj_path, projects):
                            _dashboard_run_command(proj_path, ["export", "prep"],
                                                   project_info=proj_info)
                    elif cmd == "explore":
                        if _project_key_valid(proj_path, projects):
                            _dashboard_run_command(proj_path, [cmd], project_info=proj_info)
                    elif cmd == "update":
                        if _project_key_valid(proj_path, projects):
                            _start_update_dialogs(proj_path, dialog_state, project_info=proj_info)
                    elif cmd == "setup":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                _u = proj_info.get("user", "")
                                _a, _p = ssh_resolve_address(_u, proj_info["host"])
                                remote_run_action(
                                    _u, _a,
                                    proj_info.get("remote_path", ""),
                                    "setup apply", port=_p,
                                )
                            else:
                                _dashboard_run_setup(proj_path)
                            _invalidate_summary_cache(proj_path)
                    elif cmd == "shell":
                        if _project_key_valid(proj_path, projects):
                            if is_remote_project(proj_info):
                                _u = proj_info.get("user", "")
                                _a, _p = ssh_resolve_address(_u, proj_info["host"])
                                remote_shell(_u, _a, proj_info.get("remote_path", ""), port=_p)
                            else:
                                os.chdir(proj_path)
                                ns = argparse.Namespace(layers_dir="layers")
                                from .setup import run_init_shell
                                run_init_shell(ns)
                    elif cmd == "export":
                        if _project_key_valid(proj_path, projects):
                            if proj_info and is_remote_project(proj_info):
                                log_message(f"{Colors.yellow('!')} Export not supported for remote projects")
                            else:
                                saved = os.getcwd()
                                try:
                                    os.chdir(proj_path)
                                    from .setup import gather_export_data
                                    edata = gather_export_data(layers_dir="layers")
                                    if edata:
                                        export_context = edata
                                        export_enabled = {f: True for f in edata["fragments"]}
                                        show_export = True
                                    else:
                                        log_message(f"{Colors.yellow('!')} No exportable config found")
                                finally:
                                    try:
                                        os.chdir(saved)
                                    except OSError:
                                        pass
                    elif cmd == "properties":
                        _show_properties_dialog(proj_path, projects, dialog_state)
                        last_selection = proj_path
                    elif _project_key_valid(proj_path, projects):
                        _dashboard_run_command(proj_path, [cmd], project_info=proj_info)
            elif selected == "SYNC_DISCOVER":
                _dashboard_handle_manage("SYNC_REMOTE", projects, dialog_state,
                                         persona=active_pane.get("tags", [None])[0] if len(active_pane.get("tags", [])) == 1 else None)
            elif selected.startswith("ACTION_SYNC:"):
                host_spec = selected[len("ACTION_SYNC:"):]
                if host_spec:
                    added = sync_from_remote(host_spec)
                    if added == -1:
                        log_message(f"{Colors.red('✗')} Cannot connect to {host_spec} via SSH")
                    elif added:
                        log_message(f"{Colors.green('✓')} Synced {added} project(s) from {host_spec}")
                    else:
                        log_message(f"No new projects found on {host_spec}")
            elif selected == "MANAGE":
                show_manage = True
            elif selected and not selected.startswith("SEP_") and not selected.startswith("DETAIL:") and selected not in non_selectable:
                if selected not in expanded_projects:
                    expanded_projects.add(selected)
                else:
                    expanded_projects.discard(selected)
                last_selection = selected
            continue

    _prompt_web_server_exit()
    return 0


def _dashboard_handle_manage(action: str, projects: dict,
                             dialog_state: ExploreMenuState = None,
                             persona: Optional[str] = None) -> None:
    """Handle a manage submenu action.

    Args:
        persona: If set, auto-assign this persona to newly added projects.
    """
    # Strip MANAGE_ prefix if present
    if action.startswith("MANAGE_"):
        action = action[7:]

    def _add_or_create(path):
        """Add existing project, or create new from config if empty/missing."""
        status = classify_project_path(path)
        if status == "existing":
            # Auto-detect persona — override filter if detection finds a match
            effective_persona = persona
            from ..persona import detect_persona
            detected = detect_persona(path)
            if detected:
                effective_persona = detected

            # Existing project with content — just add it
            if dialog_state:
                def _on_confirm(confirmed):
                    if confirmed:
                        add_project(path, persona=effective_persona)
                        name = os.path.basename(path)
                        log_message(f"{Colors.green('✓')} Added: {name}")
                dialog_state.show_dialog(
                    confirm_action_dialog(
                        f"Add '{os.path.basename(path)}'?",
                        message=path,
                        on_confirm=_on_confirm,
                    )
                )
            else:
                add_project(path, persona=effective_persona)
            return

        elif status == "empty":
            # Empty or non-existent — offer to set up from config
            _create_project_at(path)

    def _add_or_create_remote(uri, ds=None):
        """Add existing remote project, or create from registry config if empty/missing."""
        parsed = parse_remote_uri(uri)
        if not parsed:
            log_message(f"{Colors.red('✗')} Invalid remote URI: {uri} (expected user@host:/path)")
            return

        user, host, rpath = parsed
        display_uri = format_remote_uri(user, host, rpath)
        name = os.path.basename(rpath.rstrip("/"))

        status = classify_remote_path(user, host, rpath)
        if status == "unreachable":
            log_message(f"{Colors.red('✗')} Cannot connect to {user}@{host} via SSH")
            return

        if status == "existing":
            # Path exists with content — just register it
            if ds:
                def _on_confirm(confirmed):
                    if confirmed:
                        add_remote_project(display_uri, skip_path_check=True)
                ds.show_dialog(
                    confirm_action_dialog(
                        f"Add remote '{name}'?",
                        message=f"{display_uri}",
                        on_confirm=_on_confirm,
                    )
                )
            else:
                add_remote_project(display_uri, skip_path_check=True)
            return

        # Empty or missing — offer to create from registry config
        addr, _port = ssh_resolve_address(user, host)
        _create_remote_project_at(user, addr, rpath, port=_port)

    if action == "ADD_CWD":
        _add_or_create(os.getcwd())

    elif action == "ADD_PATH":
        try:
            path = _input_with_path_complete("Enter project path: ").strip()
            if path:
                # Auto-detect remote URI format
                if parse_remote_uri(path):
                    _add_or_create_remote(path, dialog_state)
                else:
                    path = os.path.expanduser(path)
                    path = os.path.abspath(path)
                    _add_or_create(path)
        except (EOFError, KeyboardInterrupt):
            print()

    elif action == "BROWSE":
        path = browse_for_directory()
        if path:
            _add_or_create(path)

    elif action == "ADD_REMOTE":
        if dialog_state:
            def _on_add_remote(uri):
                if uri:
                    _add_or_create_remote(uri, dialog_state)
            dialog_state.show_dialog(
                text_input_dialog(
                    "Add remote project",
                    message="Enter remote URI",
                    placeholder="user@host:/path",
                    on_confirm=_on_add_remote,
                )
            )

    elif action == "SYNC_REMOTE":
        if dialog_state:
            def _do_sync(host_spec):
                if host_spec:
                    added = sync_from_remote(host_spec)
                    if added == -1:
                        log_message(f"{Colors.red('✗')} Cannot connect to {host_spec} via SSH")
                    elif added:
                        log_message(f"{Colors.green('✓')} Synced {added} project(s) from {host_spec}")
                    else:
                        log_message(f"No new projects found on {host_spec}")

            # Collect known hosts from existing remote projects
            host_counts: Dict[str, int] = {}
            for _path, info in projects.items():
                if is_remote_project(info):
                    user = info.get("user", "")
                    host = info.get("host", "")
                    spec = f"{user}@{host}" if user else host
                    host_counts[spec] = host_counts.get(spec, 0) + 1

            if host_counts:
                # Show known hosts as selectable options
                def _on_host_selected(value):
                    if value == "__MANUAL__":
                        # Chain to text input for manual entry
                        dialog_state.show_dialog(
                            text_input_dialog(
                                "Sync from remote",
                                message="Enter remote host",
                                placeholder="user@host",
                                on_confirm=_do_sync,
                            )
                        )
                    elif value:
                        _do_sync(value)

                options = []
                for spec in sorted(host_counts):
                    count = host_counts[spec]
                    options.append((spec, spec, f"{count} projects"))
                options.append(("__MANUAL__", "Enter manually...", ""))
                dialog_state.show_dialog(
                    select_action_dialog(
                        "Sync from remote",
                        options=options,
                        on_confirm=_on_host_selected,
                    )
                )
            else:
                # No known hosts — direct to text input
                dialog_state.show_dialog(
                    text_input_dialog(
                        "Sync from remote",
                        message="Enter remote host",
                        placeholder="user@host",
                        on_confirm=_do_sync,
                    )
                )

    elif action == "CLEAR":
        # Clear the active project for the relevant persona
        if persona:
            set_current_project(None, persona_name=persona)
        else:
            set_current_project(None)
        print(f"{Colors.yellow('Cleared')} active project.")

    elif action == "SETTINGS":
        from .config import fzf_global_settings
        fzf_global_settings()


def _create_project_at(target_dir: str) -> None:
    """Create a new project at target_dir from a registry config.

    Called when a user adds a directory that is empty or doesn't exist yet.
    Opens the registry browser to pick a config, then clones into it.
    """
    from .confjson import find_registry_dirs, discover_registry, synthesize_basic_configs
    from .setup import _fzf_registry_pick, _clone_from_config

    target_dir = os.path.abspath(target_dir)
    name = os.path.basename(target_dir)

    print()
    print(f"{Colors.bold(name)}: empty or new directory")
    print(f"  {target_dir}")
    print()

    # Browse registry for a config (including synthetic basic entries)
    registry_dirs = find_registry_dirs()
    all_entries = []
    for d, label in registry_dirs:
        entries = discover_registry(d, source_label=label)
        all_entries.extend(entries)
    all_entries.extend(synthesize_basic_configs())

    if not all_entries:
        print("No configurations found.")
        os.makedirs(target_dir, exist_ok=True)
        add_project(target_dir, name)
        print(f"\n{Colors.green('Added')} empty project: {name}")
        return

    print("Select a configuration to clone, or Esc to add as empty project:")
    print()

    result = _fzf_registry_pick(all_entries)
    if result is None:
        # Esc — just add as empty project
        os.makedirs(target_dir, exist_ok=True)
        add_project(target_dir, name)
        print(f"{Colors.green('Added')} empty project: {name}")
        return

    conf_file_path, conf, selected_config = result

    # Create directory and clone
    saved_cwd = os.getcwd()
    os.makedirs(target_dir, exist_ok=True)
    os.chdir(target_dir)

    try:
        layers_dir = "layers"
        defaults_file = ".bit.defaults"

        rc = _clone_from_config(conf, selected_config, layers_dir, do_clone=True,
                                defaults_file=defaults_file)
        if rc == 0:
            # Save config metadata
            defaults = load_defaults(defaults_file)
            conf_meta = defaults.get("__conf_json__", {})
            conf_meta["file"] = conf_file_path
            defaults["__conf_json__"] = conf_meta
            from ..core import save_defaults
            save_defaults(defaults_file, defaults)

        if rc != 0:
            os.chdir(saved_cwd)
            return

        # Register as tracked project
        add_project(target_dir, name)
        set_current_project(target_dir)
        print()
        print(f"{Colors.green('Created')} project: {name}")
        print(f"  Path: {target_dir}")

        # Auto-run apply if we have a config that hasn't been applied
        defaults = load_defaults(defaults_file)
        conf_meta = defaults.get("__conf_json__", {})
        if conf_meta and not conf_meta.get("applied", True):
            print()
            print(Colors.bold("Setting up build environment..."))
            apply_args = argparse.Namespace(
                defaults_file=defaults_file,
                bblayers=None,
                config=None,
                layers_dir=layers_dir,
            )
            from .setup import run_setup_apply
            rc = run_setup_apply(apply_args)
            if rc != 0:
                print()
                print("To complete setup later:")
                print(f"  {Colors.cyan('bit setup apply')}  (from project directory)")
                print(f"  or use the {Colors.cyan('setup')} action in the dashboard")
    finally:
        os.chdir(saved_cwd)


def _fetch_remote_registry(user: str, host: str, registry_path: str,
                           source_label: str = "Built-in",
                           port: int = 22) -> list:
    """Fetch .conf.json files from a remote directory via SSH.

    Returns a list of registry entry tuples matching the discover_registry()
    format: (filename, virtual_path, relative_path, parsed_conf, source_label).
    """
    import json as _json
    from .confjson import parse_conf_json_data

    # List .conf.json files on remote
    qpath = shlex.quote(registry_path)
    r = ssh_run(user, host,
                f'find {qpath} -name "*.conf.json" -type f 2>/dev/null',
                timeout=15, port=port)
    if r.returncode != 0 or not r.stdout.strip():
        return []

    remote_files = [line.strip() for line in r.stdout.strip().splitlines()
                    if line.strip()]
    if not remote_files:
        return []

    entries = []
    for remote_file in remote_files:
        # Read file content via SSH
        r = ssh_run(user, host, f'cat {shlex.quote(remote_file)}', timeout=10,
                    port=port)
        if r.returncode != 0 or not r.stdout.strip():
            continue
        try:
            data = _json.loads(r.stdout)
            parsed = parse_conf_json_data(data)
            fname = os.path.basename(remote_file)
            rel_path = os.path.relpath(remote_file, registry_path)
            # Use a virtual path (remote:path) so it's distinguishable
            virtual_path = f"{user}@{host}:{remote_file}"
            entries.append((fname, virtual_path, rel_path, parsed, source_label))
        except (_json.JSONDecodeError, KeyError, OSError):
            continue

    return entries


def _create_remote_project_at(user: str, host: str, remote_path: str,
                              port: int = 22) -> None:
    """Create a new project on a remote host from a registry config.

    Mirrors _create_project_at() but executes clones on the remote via SSH.
    Clones bitbake first to make its built-in registry available for the
    config picker, just like the local flow.
    """
    from .confjson import find_registry_dirs, discover_registry, synthesize_basic_configs
    from .setup import _fzf_registry_pick

    name = os.path.basename(remote_path.rstrip("/"))
    uri = format_remote_uri(user, host, remote_path)

    print()
    print(f"{Colors.bold(name)}: empty or new remote directory")
    print(f"  {uri}")
    print()

    # Step 1: Clone bitbake on the remote first to get its built-in registry
    layers_dir = f"{remote_path}/layers"
    bitbake_dir = f"{layers_dir}/bitbake"
    bitbake_url = "https://git.openembedded.org/bitbake"
    bitbake_registry = f"{bitbake_dir}/default-registry"

    print(Colors.bold("Cloning bitbake on remote (for built-in registry)..."))
    clone_script = (
        f'mkdir -p {shlex.quote(layers_dir)} && '
        f'if [ ! -d {shlex.quote(bitbake_dir)} ]; then '
        f'git clone -b master {shlex.quote(bitbake_url)} {shlex.quote(bitbake_dir)} || exit 1; '
        f'echo "cloned bitbake"; '
        f'else echo "skip bitbake"; fi'
    )
    r = ssh_run(user, host, clone_script, timeout=120, port=port)
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        log_message(f"{Colors.red('✗')} Failed to clone bitbake on {host}")
        return
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    print()

    # Step 2: Gather registry entries — remote built-in + local user
    all_entries = []

    # Fetch built-in registry from the remote bitbake clone
    builtin_entries = _fetch_remote_registry(user, host, bitbake_registry,
                                             source_label="Built-in",
                                             port=port)
    all_entries.extend(builtin_entries)

    # Local user registry (configs on this machine)
    registry_dirs = find_registry_dirs()
    for d, label in registry_dirs:
        if label == "Built-in":
            continue  # Skip local built-in — we already have the remote's
        entries = discover_registry(d, source_label=label)
        all_entries.extend(entries)

    # Synthetic basic configs for all known OE branches
    all_entries.extend(synthesize_basic_configs())

    if not all_entries:
        log_message("No configurations found in registry.")
        add_remote_project(uri, name, skip_path_check=True)
        log_message(f"{Colors.green('✓')} Added remote project: {name}")
        return

    print("Select a configuration to clone on remote, or Esc to add as-is:")
    print()

    result = _fzf_registry_pick(all_entries)
    if result is None:
        # Esc — register with just the bitbake clone already done
        add_remote_project(uri, name, skip_path_check=True)
        log_message(f"{Colors.green('✓')} Added remote project: {name}")
        return

    conf_file_path, conf, selected_config = result

    # Clone all repos on remote (bitbake already present, will be skipped)
    rc = _remote_clone_from_config(user, host, remote_path, conf,
                                   selected_config, port=port)

    if rc != 0:
        log_message(f"{Colors.red('✗')} Clone failed on {host}")
        return

    add_remote_project(uri, name, skip_path_check=True)
    log_message(f"{Colors.green('✓')} Created remote project: {name}")

    # Write defaults + conf.json on remote, then run setup apply
    ok = _write_remote_defaults(user, host, remote_path,
                                conf_file_path, conf, selected_config,
                                port=port)
    if ok:
        print()
        print(Colors.bold("Setting up build environment on remote..."))
        apply_rc = remote_run_action(user, host, remote_path, "setup apply", port=port)
        if apply_rc == 0:
            print()
            print(Colors.bold("Additional fragments available (Esc to finish):"))
            remote_run_action(user, host, remote_path, "frags", port=port)


def _write_remote_defaults(user: str, host: str, remote_path: str,
                           conf_file_path: str, conf, selected_config,
                           port: int = 22) -> bool:
    """Write .bit.defaults and .bit.conf.json on the remote after cloning.

    Reads the raw .conf.json content (from local file or remote path),
    writes it to ``<remote_path>/.bit.conf.json``, then builds a
    ``.bit.defaults`` with ``__conf_json__`` metadata and ``__extra_repos__``.

    Returns True on success.
    """
    # Read raw .conf.json content
    conf_json_content = None
    if conf_file_path.startswith("__synthetic__/"):
        # Synthetic config — serialize the in-memory ConfJson
        import dataclasses as _dc
        conf_json_content = json.dumps(_dc.asdict(conf), indent=2)
    else:
        parsed = parse_remote_uri(conf_file_path)
        if parsed:
            # Remote virtual path (user@host:path) — fetch via SSH
            r_user, r_host, r_path = parsed
            r_addr, r_port = ssh_resolve_address(r_user, r_host)
            r = ssh_run(r_user, r_addr, f"cat {shlex.quote(r_path)}", timeout=15,
                        port=r_port)
            if r.returncode == 0 and r.stdout.strip():
                conf_json_content = r.stdout
        elif os.path.isfile(conf_file_path):
            # Local file
            try:
                with open(conf_file_path, "r") as f:
                    conf_json_content = f.read()
            except OSError:
                pass

    if not conf_json_content:
        log_message(f"{Colors.yellow('!')} Could not read .conf.json — skipping remote setup")
        return False

    # Write .bit.conf.json on remote
    remote_conf = f"{remote_path}/.bit.conf.json"
    from .ssh_remote import _ssh_mux_opts, _ssh_no_prompt_env
    target = f"{user}@{host}" if user else host
    port_args = ["-p", str(port)] if port != 22 else []
    try:
        r = subprocess.run(
            ["ssh", *port_args, *_ssh_mux_opts(),
             "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
             "-o", "StrictHostKeyChecking=accept-new",
             target,
             f"cat > {shlex.quote(remote_conf)}"],
            input=conf_json_content.encode(),
            capture_output=True, timeout=15,
            env=_ssh_no_prompt_env(),
        )
        if r.returncode != 0:
            log_message(f"{Colors.yellow('!')} Failed to write .bit.conf.json on remote")
            return False
    except (subprocess.TimeoutExpired, OSError):
        log_message(f"{Colors.yellow('!')} Failed to write .bit.conf.json on remote")
        return False

    # Identify non-layer repos (no conf/layer.conf) on the remote
    layers_dir = f"{remote_path}/layers"
    extra_repos = []
    for src in conf.sources:
        if src.is_local:
            continue
        repo_rel = f"layers/{src.path}"
        layer_conf = f"{layers_dir}/{src.path}/conf/layer.conf"
        r = ssh_run(user, host, f"test -f {shlex.quote(layer_conf)}", timeout=10,
                    port=port)
        if r.returncode != 0:
            extra_repos.append(repo_rel)

    # Build .bit.defaults
    defaults = {
        "__conf_json__": {
            "file": ".bit.conf.json",
            "selected": selected_config.name,
            "applied": False,
        },
    }
    if extra_repos:
        defaults["__extra_repos__"] = extra_repos

    defaults_json = json.dumps(defaults, indent=2, sort_keys=True)
    remote_defaults = f"{remote_path}/.bit.defaults"
    try:
        r = subprocess.run(
            ["ssh", *port_args, *_ssh_mux_opts(),
             "-o", "BatchMode=yes", "-o", "ConnectTimeout=5",
             "-o", "StrictHostKeyChecking=accept-new",
             target,
             f"cat > {shlex.quote(remote_defaults)}"],
            input=defaults_json.encode(),
            capture_output=True, timeout=15,
            env=_ssh_no_prompt_env(),
        )
        if r.returncode != 0:
            log_message(f"{Colors.yellow('!')} Failed to write .bit.defaults on remote")
            return False
    except (subprocess.TimeoutExpired, OSError):
        log_message(f"{Colors.yellow('!')} Failed to write .bit.defaults on remote")
        return False

    return True


def _remote_basic_clone(user: str, host: str, remote_path: str,
                        branch: str = "master",
                        skip_bitbake: bool = False,
                        port: int = 22) -> int:
    """Clone the 3 core Yocto repos on the remote host."""
    repos = [
        ("bitbake", "https://git.openembedded.org/bitbake"),
        ("openembedded-core", "https://git.openembedded.org/openembedded-core"),
        ("meta-yocto", "https://git.yoctoproject.org/meta-yocto"),
    ]
    if skip_bitbake:
        repos = [(n, u) for n, u in repos if n != "bitbake"]
    layers_dir = f"{remote_path}/layers"
    script_parts = [f"mkdir -p {shlex.quote(layers_dir)}"]
    for name, url in repos:
        target = f"{layers_dir}/{name}"
        script_parts.append(
            f'if [ ! -d {shlex.quote(target)} ]; then '
            f'git clone -b {shlex.quote(branch)} {shlex.quote(url)} {shlex.quote(target)} || exit 1; '
            f'echo "cloned {name}"; '
            f'else echo "skip {name}"; fi'
        )
    script = " && ".join(script_parts)

    print(Colors.bold("Cloning repositories on remote..."))
    r = ssh_run(user, host, script, timeout=300, port=port)
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        return 1
    print(Colors.green("Clone complete!"))
    return 0


def _remote_clone_from_config(user: str, host: str, remote_path: str,
                              conf, selected_config,
                              port: int = 22) -> int:
    """Clone repos from a .conf.json config on the remote host."""
    sources = conf.sources
    layers_dir = f"{remote_path}/layers"

    print()
    print(Colors.bold(f"Configuration: {selected_config.name}"))
    if selected_config.description:
        print(f"  {selected_config.description}")
    print()

    # Build a single SSH script that clones all repos
    script_parts = [f"mkdir -p {shlex.quote(layers_dir)}"]
    for src in sources:
        if src.is_local:
            continue  # Skip local symlinks — they don't make sense on remote
        branch = src.branch or src.rev or "master"
        target = f"{layers_dir}/{src.path}"
        script_parts.append(
            f'if [ ! -d {shlex.quote(target)} ]; then '
            f'git clone -b {shlex.quote(branch)} {shlex.quote(src.git_url)} {shlex.quote(target)} || exit 1; '
            f'echo "cloned {src.name}"; '
            f'else echo "skip {src.name}"; fi'
        )
        # Add extra remotes
        if len(src.remotes) > 1:
            for remote_name, remote_uri in src.remotes.items():
                if remote_name == "origin":
                    continue
                script_parts.append(
                    f'git -C {shlex.quote(target)} remote add {shlex.quote(remote_name)} {shlex.quote(remote_uri)} 2>/dev/null'
                )

    script = " && ".join(script_parts)

    print(Colors.bold(f"Cloning {len(sources)} repos on remote..."))
    r = ssh_run(user, host, script, timeout=300, port=port)
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if line.startswith("cloned "):
            print(f"  {Colors.green('clone')} {line[7:]}")
        elif line.startswith("skip "):
            print(f"  {Colors.yellow('skip')} {line[5:]}")
    if r.returncode != 0:
        if r.stderr:
            log_message(r.stderr.strip().splitlines()[-1])
        return 1
    print(Colors.green("Clone complete!"))
    return 0


def _start_update_dialogs(project_path: str, dialog_state: ExploreMenuState,
                          project_info: Optional[dict] = None) -> None:
    """Start chained inline update dialogs for all repos in a project.

    Discovers git repos in the project directory and shows a per-repo
    update dialog (same pattern as explore's update_all flow).
    For remote projects, uses SSH to discover repos and run updates.
    """
    if project_info and is_remote_project(project_info):
        _start_remote_update_dialogs(project_path, dialog_state, project_info)
        return

    repos = _get_project_git_repos(project_path)
    if not repos:
        return

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)
    update_idx = [0]  # mutable for closures

    def _show_next():
        """Show dialog for the next repo that needs updating."""
        while update_idx[0] < len(repos):
            repo = repos[update_idx[0]]
            branch = current_branch(repo)
            if not branch:
                update_idx[0] += 1
                continue
            default_action = defaults.get(repo, "rebase")
            display_name = repo_display_name(repo)

            dialog_state.show_dialog(
                update_repo_dialog(
                    repo_name=display_name,
                    branch=branch,
                    default_action=default_action,
                    index=update_idx[0] + 1,
                    total=len(repos),
                    on_confirm=_handle_selection,
                )
            )
            return
        # All repos processed

    def _handle_selection(selected):
        """Handle user's choice for one repo, then chain the next."""
        repo = repos[update_idx[0]]
        branch = current_branch(repo)
        default_action = defaults.get(repo, "rebase")
        display_name = repo_display_name(repo)

        if selected == "stop":
            return

        action = selected
        if action == "use_default":
            action = default_action

        if action == "skip":
            update_idx[0] += 1
            _show_next()
            return

        if action in ("rebase", "merge"):
            log_message(f"Updating {display_name}...")
            run_single_repo_update(repo, branch, action)
            # Invalidate cache so dashboard refreshes status
            _dashboard_summary_cache.pop(project_path, None)
            log_message(f"Updated {display_name}")

        update_idx[0] += 1
        _show_next()

    _show_next()


def _start_remote_update_dialogs(project_path: str, dialog_state: ExploreMenuState,
                                  project_info: dict) -> None:
    """Start chained update dialogs for a remote project via SSH."""
    user = project_info.get("user", "")
    host = project_info["host"]
    remote_path = project_info.get("remote_path", "")
    addr, port = ssh_resolve_address(user, host)

    if not ssh_check_connection(user, addr, port=port):
        log_message(f"{Colors.red('✗')} Cannot connect to {host} via SSH")
        return

    log_message(f"Discovering repos on {host}...")
    repos = ssh_get_git_repos(user, addr, remote_path, port=port)
    if not repos:
        log_message("No git repos found on remote.")
        return

    update_idx = [0]

    def _show_next():
        while update_idx[0] < len(repos):
            repo = repos[update_idx[0]]
            branch = ssh_current_branch(user, addr, repo, port=port)
            if not branch:
                update_idx[0] += 1
                continue
            display_name = os.path.basename(repo)

            dialog_state.show_dialog(
                update_repo_dialog(
                    repo_name=f"{display_name} ({host})",
                    branch=branch,
                    default_action="rebase",
                    index=update_idx[0] + 1,
                    total=len(repos),
                    on_confirm=_handle_selection,
                )
            )
            return

    def _handle_selection(selected):
        repo = repos[update_idx[0]]
        branch = ssh_current_branch(user, addr, repo, port=port)
        display_name = os.path.basename(repo)

        if selected == "stop":
            return

        action = selected
        if action == "use_default":
            action = "rebase"

        if action == "skip":
            update_idx[0] += 1
            _show_next()
            return

        if action in ("rebase", "merge"):
            log_message(f"Updating {display_name} on {host}...")
            ok = ssh_run_single_repo_update(user, addr, repo, branch, action,
                                            port=port)
            if ok:
                log_message(f"Updated {display_name} on {host}")
            else:
                log_message(f"Failed to update {display_name} on {host}")
            _dashboard_summary_cache.pop(project_path, None)

        update_idx[0] += 1
        _show_next()

    _show_next()


def _dashboard_handle_configure(action: str) -> None:
    """Handle a configure dialog action (non-picker items only)."""
    if action.startswith("CONF_"):
        action = action[5:]

    if action == "DASH_COLORS":
        _pick_dashboard_colors()
    elif action == "TMUX":
        from .config import _pick_tmux_prefix
        _pick_tmux_prefix()
    elif action in ("COLORS", "ALL_SETTINGS"):
        from .config import fzf_global_settings
        fzf_global_settings()



def _pick_dashboard_colors() -> None:
    """Pick colors for all terminal display elements."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding

    # Resolve which color file to write to
    color_mode = get_color_mode()
    if color_mode == "global":
        color_file = _get_global_colors_file()
    elif color_mode == "custom":
        color_file = ".bit.defaults"
    else:
        color_file = None

    while True:
        menu_lines = []
        for elem, (default_color, desc) in TERMINAL_COLOR_ELEMENTS.items():
            current = get_terminal_color(elem)
            is_default = (current == default_color)
            ansi_code = ANSI_COLORS.get(current, "\033[33m")
            sample = f"{ansi_code}\u25a0\u25a0\u25a0\033[0m"
            status = f"{current}" if not is_default else f"{current} (default)"
            menu_lines.append(f"{elem}\t{sample}  {desc:<45} {status}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~15",
                    "--header", "Display Colors (\u2190/q=back)",
                    "--prompt", "Element: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        elem = output.split("\t")[0] if "\t" in output else output
        if elem in TERMINAL_COLOR_ELEMENTS and color_file:
            _pick_single_color(elem, color_file)
        elif not color_file:
            print("Set color mode to 'global' or 'custom' first (Colors and themes → Color Mode)")


def _pick_single_color(element: str, color_file: str) -> None:
    """Pick a color for a single terminal element."""
    from ..fzf_bindings import get_exit_bindings

    default_color = TERMINAL_COLOR_ELEMENTS[element][0]
    current = get_terminal_color(element)
    desc = TERMINAL_COLOR_ELEMENTS[element][1]

    menu_lines = []
    default_marker = "\u25cf " if current == default_color else "  "
    default_ansi = ANSI_COLORS.get(default_color, "\033[33m")
    menu_lines.append(f"(default)\t{default_marker}{default_ansi}\u25a0\u25a0\u25a0\033[0m (default: {default_color})")

    for name, ansi in sorted(ANSI_COLORS.items()):
        if name == default_color:
            continue
        marker = "\u25cf " if name == current else "  "
        menu_lines.append(f"{name}\t{marker}{ansi}\u25a0\u25a0\u25a0\033[0m {name}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~20",
                "--header", f"Pick color for: {desc} (\u2190/q=back)",
                "--prompt", "Color: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    output = result.stdout.strip()
    if output == "BACK":
        return

    selected = output.split("\t")[0] if "\t" in output else output
    if selected == "(default)":
        set_terminal_color(element, "(default)", color_file)
    elif selected in ANSI_COLORS:
        set_terminal_color(element, selected, color_file)


def run_dashboard(args) -> int:
    """Entry point for 'bit dashboard' command."""
    return fzf_dashboard()


def get_directory_browser() -> str:
    """Get configured directory browser preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__directory_browser__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_directory_browser(browser: str) -> None:
    """Set directory browser preference (auto, nnn, fzf)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__directory_browser__"] = browser
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_backup_prune_age() -> str:
    """Get configured backup branch prune age (days or 'never')."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__backup_prune_age__", "7")
        except (json.JSONDecodeError, OSError):
            pass
    return "7"


def set_backup_prune_age(age: str) -> None:
    """Set backup branch prune age (days or 'never')."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__backup_prune_age__"] = age
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass



def get_git_viewer() -> str:
    """Get configured git history viewer preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__git_viewer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_git_viewer(viewer: str) -> None:
    """Set git history viewer preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__git_viewer__"] = viewer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_editor() -> str:
    """Get configured editor preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__editor__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_editor(editor: str) -> None:
    """Set editor preference (auto, vim, nvim, nano, emacs, code)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__editor__"] = editor
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def resolve_editor() -> str:
    """Resolve the editor to use: bit setting > $EDITOR > $VISUAL > vi."""
    preference = get_editor()
    if preference != "auto":
        if shutil.which(preference):
            return preference
        # Configured editor not found, fall through to env vars
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    return editor


def get_graph_renderer() -> str:
    """Get configured graph renderer preference for dependency visualization."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__graph_renderer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_graph_renderer(renderer: str) -> None:
    """Set graph renderer preference (auto, graph-easy, ascii)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__graph_renderer__"] = renderer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_default_dashboard_command() -> str:
    """Get configured default command for right-arrow on expanded project."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__default_dashboard_command__", "explore")
        except (json.JSONDecodeError, OSError):
            pass
    return "explore"


def set_default_dashboard_command(command: str) -> None:
    """Set default command for right-arrow on expanded project."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__default_dashboard_command__"] = command
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_web_autostart() -> str:
    """Get web server autostart setting.

    Returns one of: "off", "localhost", "all".
    - "off": do not start web server on dashboard launch
    - "localhost": start bound to 127.0.0.1:8123
    - "all": start bound to 0.0.0.0:8123 (accessible from network)
    """
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__web_autostart__", "off")
        except (json.JSONDecodeError, OSError):
            pass
    return "off"


def set_web_autostart(value: str) -> None:
    """Set web server autostart setting (off, localhost, all)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__web_autostart__"] = value
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_web_open_browser() -> bool:
    """Whether starting the web server should open a browser tab. Default: False."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return bool(data.get("__web_open_browser__", False))
        except (json.JSONDecodeError, OSError):
            pass
    return False


def set_web_open_browser(value) -> None:
    """Set whether starting the web server should open a browser tab."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    # Accept bool, string "true"/"false", etc.
    data["__web_open_browser__"] = str(value).lower() in ("true", "1", "yes", "on")
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_web_terminal_mode() -> str:
    """Get default terminal mode for the web UI.

    Returns one of: "panel", "maximized", "popout".
    - "panel": inline terminal panel (default)
    - "maximized": full-screen tab alongside pinned views
    - "popout": open in a new browser window
    """
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__web_terminal_mode__", "panel")
        except (json.JSONDecodeError, OSError):
            pass
    return "panel"


def set_web_terminal_mode(value: str) -> None:
    """Set default terminal mode for the web UI (panel, maximized, popout)."""
    if value not in ("panel", "maximized", "popout"):
        value = "panel"
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__web_terminal_mode__"] = value
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_host_metrics_refresh() -> int:
    """Get host metrics auto-refresh interval in seconds.

    Returns one of: 0 (off), 60, 120, 300, 600.
    """
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                val = data.get("__host_metrics_refresh__", 0)
                try:
                    return int(val)
                except (ValueError, TypeError):
                    return 0
        except (json.JSONDecodeError, OSError):
            pass
    return 0


def set_host_metrics_refresh(value) -> None:
    """Set host metrics auto-refresh interval in seconds (0=off, 60, 120, 300, 600)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    try:
        data["__host_metrics_refresh__"] = int(value)
    except (ValueError, TypeError):
        data["__host_metrics_refresh__"] = 0
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preferred_graph_renderer() -> str:
    """
    Get the preferred graph renderer that's actually available.

    Returns: 'graph-easy', 'ascii', or the configured preference.
    """
    preference = get_graph_renderer()

    if preference == "auto":
        # Prefer graph-easy if available
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"
    elif preference == "graph-easy":
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"  # Fall back if not available
    else:
        return preference


def get_preferred_git_viewer() -> Optional[str]:
    """
    Get the preferred git viewer that's actually available.

    Returns the command name (tig, lazygit, gitk) or None if none available.
    """
    preference = get_git_viewer()

    # Define viewer priority
    viewers = ["tig", "lazygit", "gitui", "gitk"]

    if preference == "auto":
        # Return first available
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None
    elif preference in viewers and shutil.which(preference):
        return preference
    else:
        # Configured viewer not available, fall back to auto
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None


def _pick_git_viewer() -> None:
    """Pick git history viewer."""
    if not fzf_available():
        return

    current = get_git_viewer()

    options = [
        ("auto", "Auto-detect (tig > lazygit > gitui > gitk)"),
        ("tig", "tig - ncurses git interface"),
        ("lazygit", "lazygit - terminal UI for git"),
        ("gitui", "gitui - blazing fast terminal git UI (Rust)"),
        ("gitk", "gitk - graphical git browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("tig", "lazygit", "gitui", "gitk") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select git history viewer (Enter=select, ←/q=back)",
        "--prompt", "Viewer: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "tig", "lazygit", "gitk"):
        set_git_viewer(selected)


def get_preview_layout() -> str:
    """Get configured preview pane layout preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__preview_layout__", "down")
        except (json.JSONDecodeError, OSError):
            pass
    return "down"


def set_preview_layout(layout: str) -> None:
    """Set preview pane layout preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__preview_layout__"] = layout
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_explore_load_size() -> int:
    """Get configured number of commits to load per page in explore."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return int(data.get("__explore_load_size__", 200))
        except (json.JSONDecodeError, OSError, ValueError):
            pass
    return 200


def set_explore_load_size(size: int) -> None:
    """Set number of commits to load per page in explore."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__explore_load_size__"] = size
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preview_window_arg(size: str = "50%") -> str:
    """Get the fzf --preview-window argument based on configured layout."""
    layout = get_preview_layout()
    if layout == "right":
        return f"right:{size}:wrap"
    elif layout == "up":
        return f"up,{size},wrap"
    else:  # down (default)
        return f"down,{size},wrap"


def get_fzf_preview_args(
    preview_cmd: str,
    size: str = "50%",
    toggle_key: str = "?",
) -> list:
    """
    Get standard fzf arguments for preview pane.

    This provides a consistent preview experience across all commands, including:
    - Preview window with configured layout
    - Resize bindings (F3/F4 cross-platform, alt-left/right on Linux)
    - Color scheme
    - Toggle preview visibility
    - Preview scrolling (multiple key options for compatibility)

    Main list navigation:
    - pgup/pgdn: Page through the list (fzf default, not overridden)
    - up/down: Move one item at a time

    Preview scrolling:
    - alt-up/alt-down: Scroll preview by full pages
    - alt-u/alt-d: Scroll preview by half-pages (vim style)
    - shift-up/shift-down: Scroll preview by lines
    - alt-k/alt-j: Scroll preview by lines (vim-style alternative)

    Preview resize:
    - F3: Grow preview (cross-platform, Mac-friendly)
    - F4: Shrink preview (cross-platform, Mac-friendly)
    - alt-left: Grow preview (Linux)
    - alt-right: Shrink preview (Linux)

    Args:
        preview_cmd: The preview command to run
        size: Preview window size (default "50%")
        toggle_key: Key to toggle preview visibility (default "?")

    Returns:
        List of fzf arguments to extend your fzf_args with
    """
    preview_window = get_preview_window_arg(size)

    args = [
        "--preview", preview_cmd,
        "--preview-window", preview_window,
        "--bind", f"{toggle_key}:toggle-preview",
        # Preview scrolling - don't override pgup/pgdn so main list paging works
        "--bind", "shift-up:preview-up",
        "--bind", "shift-down:preview-down",
        "--bind", "alt-k:preview-up",
        "--bind", "alt-j:preview-down",
        "--bind", "alt-u:preview-half-page-up",
        "--bind", "alt-d:preview-half-page-down",
        "--bind", "alt-up:preview-page-up",
        "--bind", "alt-down:preview-page-down",
    ]

    # Add resize bindings and color scheme
    args.extend(get_fzf_preview_resize_bindings())
    args.extend(get_fzf_color_args())

    return args


def _pick_preview_layout() -> None:
    """Pick preview pane layout."""
    if not fzf_available():
        return

    current = get_preview_layout()

    options = [
        ("down", "Bottom - preview below commit list"),
        ("right", "Right - preview beside commit list (side-by-side)"),
        ("up", "Top - preview above commit list"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        menu_lines.append(f"{value}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select preview pane layout (Enter=select, ←/q=back)",
        "--prompt", "Layout: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("down", "right", "up"):
        set_preview_layout(selected)


def get_recipe_use_bitbake_layers() -> bool:
    """Get whether to use bitbake-layers for recipe scanning (default: True)."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                value = data.get("__recipe_use_bitbake_layers__", True)
                # Handle string values from config
                if isinstance(value, str):
                    return value.lower() not in ("false", "no", "0")
                return bool(value)
        except (json.JSONDecodeError, OSError):
            pass
    return True


def set_recipe_use_bitbake_layers(value: bool) -> None:
    """Set whether to use bitbake-layers for recipe scanning."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__recipe_use_bitbake_layers__"] = value
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _pick_recipe_use_bitbake_layers() -> None:
    """Pick whether to use bitbake-layers for recipe scanning."""
    if not fzf_available():
        return

    current = get_recipe_use_bitbake_layers()

    options = [
        (True, "bitbake-layers - Use bitbake-layers show-recipes (more accurate, slower)"),
        (False, "File scan - Scan .bb files directly (faster, no bitbake env needed)"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        key = "true" if value else "false"
        menu_lines.append(f"{key}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Recipe scan method (Enter=select, ←/q=back)",
        "--prompt", "Method: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected == "true":
        set_recipe_use_bitbake_layers(True)
    elif selected == "false":
        set_recipe_use_bitbake_layers(False)


def _pick_directory_browser() -> None:
    """Show settings menu for directory browser preferences."""
    if not fzf_available():
        return

    while True:
        current_browser = get_directory_browser()
        current_colors = get_nnn_colors()

        # Color descriptions
        color_names = {
            "0": "black", "1": "red", "2": "green", "3": "yellow",
            "4": "blue", "5": "magenta", "6": "cyan", "7": "white"
        }
        color_desc = f"dirs={color_names.get(current_colors[0:1], '?')}" if current_colors else "default"

        menu_lines = [
            f"BROWSER\tBrowser: {current_browser}",
            f"NNN_COLORS\tnnn colors: {color_desc} ({current_colors})",
        ]

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~20%",
            "--layout", "reverse",
            "--header", "Projects settings (Enter=edit, ←/q=back)",
            "--prompt", "Setting: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        selected = result.stdout.strip().split("\t")[0]

        if selected == "BROWSER":
            _pick_browser_option()
        elif selected == "NNN_COLORS":
            _pick_nnn_colors()


def _pick_browser_option() -> None:
    """Pick directory browser."""
    current = get_directory_browser()

    options = [
        ("auto", "Auto-detect (broot > ranger > nnn > fzf)"),
        ("broot", "broot - fuzzy search, type paths directly"),
        ("ranger", "ranger - vim-like file manager"),
        ("nnn", "nnn - fast, minimal file manager"),
        ("fzf", "fzf built-in browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("broot", "ranger", "nnn") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select directory browser (Enter=select, ←/q=back)",
        "--prompt", "Browser: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "fzf", "nnn", "broot", "ranger"):
        set_directory_browser(selected)


def _pick_nnn_colors() -> None:
    """Pick nnn color scheme."""
    # NNN_COLORS format: up to 8 chars, each is a color 0-7
    # We'll focus on the directory color (3rd char) which is usually the issue
    current = get_nnn_colors()

    presets = [
        ("6234", "cyan dirs (default)"),
        ("2234", "green dirs"),
        ("3234", "yellow dirs"),
        ("7234", "white dirs"),
        ("5234", "magenta dirs"),
        ("1234", "red dirs"),
        ("4234", "blue dirs (nnn default)"),
    ]

    menu_lines = []
    for value, desc in presets:
        marker = "● " if value == current else "  "
        # Show color sample
        color_code = {"1": "31", "2": "32", "3": "33", "4": "34", "5": "35", "6": "36", "7": "37"}.get(value[0], "0")
        sample = f"\033[{color_code}m■■■\033[0m"
        menu_lines.append(f"{value}\t{marker}{sample} {desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~25%",
        "--layout", "reverse",
        "--header", "Select nnn directory color (Enter=select, ←/q=back)",
        "--prompt", "Color: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected:
        set_nnn_colors(selected)


def browse_for_directory() -> Optional[str]:
    """
    Browse filesystem to select a directory.

    Uses configured browser preference, or auto-detects.
    Priority: broot > ranger > nnn > fzf
    """
    browser = get_directory_browser()

    if browser == "auto":
        # Auto-detect best available
        if shutil.which("broot"):
            return _browse_with_broot()
        elif shutil.which("ranger"):
            return _browse_with_ranger()
        elif shutil.which("nnn"):
            return _browse_with_nnn()
    elif browser == "broot" and shutil.which("broot"):
        return _browse_with_broot()
    elif browser == "ranger" and shutil.which("ranger"):
        return _browse_with_ranger()
    elif browser == "nnn" and shutil.which("nnn"):
        return _browse_with_nnn()

    # Fall back to fzf
    if fzf_available():
        return _browse_with_fzf_walker()

    return None


def _browse_with_broot() -> Optional[str]:
    """Browse for directory using broot."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.broot') as f:
        out_file = f.name

    try:
        print()
        print(f"{Colors.bold('broot directory browser')}")
        print(f"  Type to fuzzy search     /path : jump to absolute path")
        print(f"  Enter    : enter dir     Alt+Enter : {Colors.cyan('SELECT and quit')}")
        print(f"  Esc/q    : cancel        ?     : help")
        print()
        input("Press Enter to open broot...")

        # --only-folders: show only directories
        # --cmd: initial command (none)
        # We use :print_path verb bound to alt-enter
        result = subprocess.run(
            ["broot", "--only-folders", "--print-path", "-o", out_file, start_dir],
        )

        if os.path.isfile(out_file):
            with open(out_file, "r") as f:
                selected = f.read().strip()
            if selected:
                # broot might output a file, get its directory
                if os.path.isfile(selected):
                    return os.path.dirname(selected)
                elif os.path.isdir(selected):
                    return selected

        return None
    finally:
        try:
            os.unlink(out_file)
        except OSError:
            pass


def _browse_with_ranger() -> Optional[str]:
    """Browse for directory using ranger with fzf integration."""
    import tempfile

    start_dir = os.path.expanduser("~")

    # Create temp directory for our ranger config
    temp_dir = tempfile.mkdtemp(prefix='ranger_bbp_')
    choosedir_file = os.path.join(temp_dir, 'choosedir')
    commands_file = os.path.join(temp_dir, 'commands.py')
    rc_file = os.path.join(temp_dir, 'rc.conf')

    try:
        # Write custom commands.py with fzf_select
        commands_content = '''
import subprocess
import os.path
from ranger.api.commands import Command

class fzf_select(Command):
    """Find a file or directory using fzf and jump to it."""
    def execute(self):
        # Use fd if available, otherwise find
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = "fd --type d --hidden --exclude .git 2>/dev/null | fzf +m"
        else:
            command = "find . -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
            else:
                self.fm.select_file(fzf_file)

class fzf_cd(Command):
    """fzf to any directory from root."""
    def execute(self):
        start = self.arg(1) or os.path.expanduser("~")
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = f"fd --type d --hidden --exclude .git . {start} 2>/dev/null | fzf +m"
        else:
            command = f"find {start} -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
'''
        with open(commands_file, 'w') as f:
            f.write(commands_content)

        # Write rc.conf with our mappings
        # Source user's rc.conf first if it exists
        user_rc = os.path.expanduser("~/.config/ranger/rc.conf")
        rc_content = f'''
# Source user config if exists
{"source " + user_rc if os.path.isfile(user_rc) else "# no user rc.conf"}

# bit mappings
map <C-f> fzf_select
map <C-g> fzf_cd ~
map g console cd%space
'''
        with open(rc_file, 'w') as f:
            f.write(rc_content)

        print()
        print(f"{Colors.bold('ranger directory browser')} (with fzf)")
        print(f"  {Colors.bold('Ctrl+f')}    : fzf search from current dir")
        print(f"  {Colors.bold('Ctrl+g')}    : fzf search from home")
        print(f"  {Colors.bold('g')}         : type path directly (tab completes)")
        print(f"  :cd /path : jump to path")
        print(f"  q         : {Colors.cyan('SELECT current dir and quit')}")
        print()
        input("Press Enter to open ranger...")

        env = os.environ.copy()
        env['RANGER_LOAD_DEFAULT_RC'] = 'FALSE'

        result = subprocess.run(
            ["ranger",
             f"--choosedir={choosedir_file}",
             f"--cmd=source {rc_file}",
             f"--cmd=source {commands_file}",
             start_dir],
            env=env,
        )

        if os.path.isfile(choosedir_file):
            with open(choosedir_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected

        return None
    finally:
        # Cleanup temp files
        try:
            os.unlink(choosedir_file)
        except OSError:
            pass
        try:
            os.unlink(commands_file)
        except OSError:
            pass
        try:
            os.unlink(rc_file)
        except OSError:
            pass
        try:
            os.rmdir(temp_dir)
        except OSError:
            pass


def get_nnn_colors() -> str:
    """Get configured nnn color scheme."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__nnn_colors__", "6234")
        except (json.JSONDecodeError, OSError):
            pass
    # Default: cyan dirs (6), green sel (2), yellow ctx (3), blue files (4)
    return "6234"


def set_nnn_colors(colors: str) -> None:
    """Set nnn color scheme."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__nnn_colors__"] = colors
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _browse_with_nnn() -> Optional[str]:
    """Browse for directory using nnn file manager."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.nnn') as f:
        picker_file = f.name

    try:
        env = os.environ.copy()
        # Set colors - default avoids hard-to-read blue for directories
        # Format: 4 chars for contexts (cursor line, selection, dir, file)
        # 1=red, 2=green, 3=yellow, 4=blue, 5=magenta, 6=cyan, 7=white
        env["NNN_COLORS"] = get_nnn_colors()

        print()
        print(f"{Colors.bold('nnn directory browser')} (type-to-nav enabled)")
        print(f"  hjkl/arrows : navigate        {Colors.bold('/')} : filter current dir")
        print(f"  Enter/l     : enter dir       {Colors.bold('~')} : jump to home")
        print(f"  Backspace/h : go up           Just type: jump to path (e.g. /opt)")
        print(f"  {Colors.bold('p')}           : {Colors.cyan('SELECT and quit')}")
        print(f"  q           : cancel          {Colors.bold('?')} : full help")
        print()
        input("Press Enter to open nnn...")

        result = subprocess.run(
            ["nnn", "-n", "-p", picker_file, start_dir],
            env=env,
        )

        # Read selected path (written when user presses 'p')
        if os.path.isfile(picker_file):
            with open(picker_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected
            elif selected and os.path.isfile(selected):
                # If a file was selected, use its directory
                return os.path.dirname(selected)

        return None
    finally:
        try:
            os.unlink(picker_file)
        except OSError:
            pass


def _browse_with_fzf_walker() -> Optional[str]:
    """Browse for directory using fzf with manual directory navigation."""
    start_dir = os.path.expanduser("~")
    current_dir = start_dir

    while True:
        # List directories in current location
        try:
            entries = sorted(os.listdir(current_dir))
        except OSError:
            entries = []

        dirs = [d for d in entries if os.path.isdir(os.path.join(current_dir, d)) and not d.startswith(".")]

        menu_lines = []
        menu_lines.append(f".\t{Colors.green('● Select this directory')}: {current_dir}")
        if current_dir != "/":
            menu_lines.append(f"..\t{Colors.cyan('↑ Go up to')}: {os.path.dirname(current_dir)}")

        for d in dirs:
            full_path = os.path.join(current_dir, d)
            # Check for indicators this might be a Yocto project
            has_layers = os.path.isdir(os.path.join(full_path, "layers"))
            has_build = os.path.isdir(os.path.join(full_path, "build"))
            has_poky = os.path.isdir(os.path.join(full_path, "poky"))
            has_bblayers = any(
                os.path.isfile(os.path.join(full_path, sub, "conf", "bblayers.conf"))
                for sub in ["", "build"]
            )

            indicator = ""
            if has_layers or has_build or has_poky or has_bblayers:
                indicator = Colors.green(" [yocto?]")

            menu_lines.append(f"{d}\t  {d}/{indicator}")

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~60%",
            "--layout", "reverse",
            "--header", f"Browse: {current_dir}\nEnter=enter dir, Tab=select, ←/q=cancel",
            "--prompt", "Dir: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--expect", "tab",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None

        if result.returncode != 0 or not result.stdout.strip():
            return None

        # Split BEFORE stripping to preserve empty key line
        lines = result.stdout.split("\n")
        key = lines[0] if lines else ""
        selected = lines[1].split("\t")[0] if len(lines) > 1 else ""

        # Tab means select current highlighted item as the project
        if key == "tab" and selected and selected not in (".", ".."):
            return os.path.join(current_dir, selected)

        if selected == ".":
            return current_dir
        elif selected == "..":
            current_dir = os.path.dirname(current_dir)
        elif selected:
            new_dir = os.path.join(current_dir, selected)
            if os.path.isdir(new_dir):
                current_dir = new_dir


def run_projects(args, from_auto_prompt: bool = False) -> int:
    """
    Main entry point for projects command.

    Args:
        args: Parsed command line arguments
        from_auto_prompt: True if invoked automatically because no project context was found.
                          In this case, after selecting a project with Enter, show command menu.

    Returns:
        0 for success, 1 for error, 2 to signal "chain to command menu"
    """
    subcommand = getattr(args, "projects_command", None)

    if subcommand == "add":
        path = getattr(args, "path", None) or os.getcwd()
        name = getattr(args, "name", None)
        desc = getattr(args, "description", "") or ""
        persona = getattr(args, "persona", None)

        # Detect remote URI (user@host:/path)
        parsed = parse_remote_uri(path)
        if parsed:
            user, host, rpath = parsed
            display_uri = format_remote_uri(user, host, rpath)
            status = classify_remote_path(user, host, rpath)
            if status == "unreachable":
                print(f"Error: Cannot connect to {user}@{host} via SSH", file=sys.stderr)
                return 1
            if status == "existing":
                if add_remote_project(display_uri, name, skip_path_check=True):
                    return 0
                return 1
            # Empty or missing — create from registry config
            addr, _port = ssh_resolve_address(user, host)
            _create_remote_project_at(user, addr, rpath, port=_port)
            return 0

        if add_project(path, name, desc, persona=persona):
            return 0
        return 1

    elif subcommand == "remove":
        path = getattr(args, "path", None)
        if not path:
            # Interactive selection
            selected = fzf_project_picker(include_browse=False)
            if not selected:
                return 1
            # Strip special prefixes from picker
            for prefix in ("SELECT:", "EXIT:"):
                if selected.startswith(prefix):
                    selected = selected[len(prefix):]
            path = selected
        projects = load_projects()
        # Resolve path for display
        lookup = path if path in projects else os.path.abspath(path)
        if lookup in projects:
            name = projects[lookup].get("name", lookup)
            print(f"Remove project: {Colors.bold(name)}")
            print(f"  {lookup}")
            try:
                resp = input("Confirm? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                return 1
            if resp != "y":
                return 1
        if remove_project(path):
            return 0
        return 1

    elif subcommand == "shell":
        # Alias for 'init shell' - change to current project first
        current_project = get_current_project()
        if current_project and os.path.isdir(current_project):
            os.chdir(current_project)
        from .setup import run_init_shell
        return run_init_shell(args)

    elif subcommand == "sync":
        sync_direction = getattr(args, "sync_direction", None)
        if sync_direction == "from":
            added = sync_from_remote(args.host)
            if added == -1:
                print(f"{Colors.red('✗')} Cannot connect to {args.host} via SSH")
                return 1
            elif added:
                print(f"{Colors.green('✓')} Synced {added} project(s) from {args.host}")
            else:
                print(f"No new projects found on {args.host}")
            return 0
        elif sync_direction == "to":
            print("Push sync not yet implemented.")
            return 1
        else:
            # No direction given — print help
            # Re-parse to get the sync subparser for help
            print("Usage: bit projects sync {from,to} <host>")
            print("\nSync project lists between local and remote bit instances.")
            print("Additive only — never removes existing entries.")
            print("\nDirections:")
            print("  from  Pull remote's projects into local list")
            print("  to    Push local projects to remote's list (future)")
            return 0

    elif subcommand == "list":
        projects = load_projects()
        current = get_current_project()

        if not projects:
            print("No projects registered.")
            print("Use 'bit projects add' to add one.")
            return 0

        print(f"\n{Colors.bold('Registered projects:')}\n")
        for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
            name = info.get("name", os.path.basename(path))
            desc = info.get("description", "")
            is_remote = is_remote_project(info)
            if is_remote:
                user = info.get("user", "")
                host = info.get("host", "")
                remote_path = info.get("remote_path", "")
                if user and host and remote_path:
                    _a, _p = ssh_resolve_address(user, host)
                    exists = ssh_path_exists(user, _a, remote_path, port=_p)
                else:
                    exists = False
            else:
                exists = os.path.isdir(path)
            is_current = (path == current)

            if is_current:
                status = terminal_color("project_active", "●")
                label = f" {terminal_color('project_active', '(ACTIVE)')}"
            elif exists:
                status = terminal_color("project_name", "○")
                label = ""
            else:
                status = terminal_color("project_missing", "!")
                label = ""

            print(f"  {status} {terminal_color('project_active' if is_current else 'project_name', name)}{label}")
            print(f"    {path}")
            if desc:
                print(f"    {Colors.dim(desc)}")
            if not exists:
                print(f"    {Colors.red('(directory not found)')}")
            print()
        return 0

    else:
        # Default: launch dashboard
        return fzf_dashboard()
