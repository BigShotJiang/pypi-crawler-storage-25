#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Pure Python WebSocket server (RFC 6455).

Minimal implementation — enough for xterm.js terminal sessions.
No external dependencies.
"""

import base64
import hashlib
import socket
import struct

# RFC 6455 magic GUID
_WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

# Opcodes
OP_CONT = 0x0
OP_TEXT = 0x1
OP_BINARY = 0x2
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA


def ws_accept_key(client_key: str) -> str:
    """Compute the Sec-WebSocket-Accept value for a client key."""
    digest = hashlib.sha1((client_key + _WS_GUID).encode()).digest()
    return base64.b64encode(digest).decode()


def do_websocket_handshake(handler) -> bool:
    """Perform the WebSocket upgrade handshake.

    Writes the 101 response directly to the raw socket, bypassing
    BaseHTTPRequestHandler's send_response/send_header/end_headers
    to avoid any buffering or header-manipulation quirks.

    Returns True on success, False if the request is not a valid WS upgrade.
    """
    from . import web_log

    key = handler.headers.get("Sec-WebSocket-Key")
    if not key:
        web_log("[ws] handshake FAILED: missing Sec-WebSocket-Key")
        handler.send_error(400, "Missing Sec-WebSocket-Key")
        return False

    accept = ws_accept_key(key.strip())

    peer = handler.request.getpeername()
    web_log(f"[ws] handshake from {peer[0]}:{peer[1]}  "
            f"key={key.strip()[:16]}...  accept={accept[:16]}...")

    # Disable Nagle's algorithm — the 101 response is small and can be
    # delayed by Nagle, causing browsers to abort with close code 1006.
    handler.request.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

    # Write directly to the raw socket — avoids BaseHTTPRequestHandler
    # adding Server/Date headers or any buffering issues with wfile.
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n"
        "\r\n"
    )
    handler.request.sendall(response.encode("ascii"))
    web_log(f"[ws] 101 sent ({len(response)} bytes)")

    # Prevent the keep-alive loop from trying to read another HTTP
    # request after handle_terminal_websocket() returns.
    handler.close_connection = True
    return True


def read_frame(rfile):
    """Read one WebSocket frame.

    Returns (opcode, payload_bytes) or (None, None) on connection close.
    """
    # First 2 bytes: FIN/opcode + MASK/payload_len
    header = rfile.read(2)
    if not header or len(header) < 2:
        return None, None

    b0, b1 = header[0], header[1]
    opcode = b0 & 0x0F
    masked = b1 & 0x80
    length = b1 & 0x7F

    # Extended payload length
    if length == 126:
        raw = rfile.read(2)
        if not raw or len(raw) < 2:
            return None, None
        length = struct.unpack("!H", raw)[0]
    elif length == 127:
        raw = rfile.read(8)
        if not raw or len(raw) < 8:
            return None, None
        length = struct.unpack("!Q", raw)[0]

    # Masking key (client frames are always masked)
    mask_key = None
    if masked:
        mask_key = rfile.read(4)
        if not mask_key or len(mask_key) < 4:
            return None, None

    # Payload
    payload = b""
    remaining = length
    while remaining > 0:
        chunk = rfile.read(remaining)
        if not chunk:
            return None, None
        payload += chunk
        remaining -= len(chunk)

    # Unmask
    if mask_key:
        payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

    return opcode, payload


def write_frame(wfile, opcode: int, payload: bytes = b"") -> None:
    """Write a WebSocket frame (server side — unmasked)."""
    frame = bytearray()

    # FIN + opcode
    frame.append(0x80 | opcode)

    # Payload length
    length = len(payload)
    if length < 126:
        frame.append(length)
    elif length < 65536:
        frame.append(126)
        frame.extend(struct.pack("!H", length))
    else:
        frame.append(127)
        frame.extend(struct.pack("!Q", length))

    frame.extend(payload)
    wfile.write(bytes(frame))
    wfile.flush()


def send_text(wfile, text: str) -> None:
    """Send a text frame."""
    write_frame(wfile, OP_TEXT, text.encode("utf-8"))


def send_binary(wfile, data: bytes) -> None:
    """Send a binary frame."""
    write_frame(wfile, OP_BINARY, data)


def send_close(wfile, code: int = 1000, reason: str = "") -> None:
    """Send a close frame."""
    payload = struct.pack("!H", code) + reason.encode("utf-8")
    write_frame(wfile, OP_CLOSE, payload)
