#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Command-area APIs — config, patches, b4, recipes, fragments, deps, info, export, remote, file, filesystem."""

import json
import os
import re
import shlex
import subprocess
import threading

from .server import route
from .api import _resolve_current_repos, _get_defaults_file, _project_param, _ssh_query, _ssh_query_post

_ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def _strip_ansi(text: str) -> str:
    """Remove ANSI color escape sequences from text."""
    return _ANSI_RE.sub('', text)


def _resolve_git_repo(project: str, list_name: str = "") -> str:
    """Find the best git repo in a project for a given lore list name.

    Thin wrapper around get_candidate_repos() — returns the top-scored
    repo path, or falls back to the project directory itself.
    """
    from ..commands.b4 import get_candidate_repos
    candidates = get_candidate_repos(project, list_name)
    if not candidates:
        return project
    return candidates[0]["path"]


def _validate_file_path(path):
    """Validate and normalize a file path for read/write.

    Security: ensures path is within a registered project directory.
    Returns normalized absolute path, or None if invalid.
    """
    if not path:
        return None
    normalized = os.path.normpath(os.path.abspath(path))
    # Check against project directories
    from ..commands.projects import load_projects, get_current_project
    allowed_dirs = []
    current = get_current_project()
    if current:
        allowed_dirs.append(os.path.normpath(os.path.abspath(current)))
    try:
        projects = load_projects()
        for p in projects:
            allowed_dirs.append(os.path.normpath(os.path.abspath(p)))
    except Exception:
        pass
    for d in allowed_dirs:
        if normalized.startswith(d + os.sep) or normalized == d:
            return normalized
    return None


# ---------- config ----------

@route("GET", "/api/config")
def api_config(handler):
    """All settings for current project."""
    from ..core import load_defaults
    defaults = load_defaults(_get_defaults_file())
    handler._send_json(defaults)


@route("POST", "/api/config")
def api_config_update(handler):
    """Update settings."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    from ..core import load_defaults, save_defaults
    df = _get_defaults_file()
    defaults = load_defaults(df)
    defaults.update(body)
    save_defaults(df, defaults)
    handler._send_json({"ok": True})


@route("GET", "/api/config/repo/([^/]+)")
def api_config_repo(handler, repo_name):
    """Per-repo config."""
    from ..commands.common import find_repo_by_identifier

    repos, defaults, *_ = _resolve_current_repos()
    repo = find_repo_by_identifier(repos, repo_name, defaults)
    if not repo:
        handler._send_error_json(404, f"Repo not found: {repo_name}")
        return

    action = defaults.get(repo, "rebase")
    handler._send_json({"path": repo, "default_action": action})


@route("POST", "/api/config/repo/([^/]+)")
def api_config_repo_update(handler, repo_name):
    """Update per-repo config."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    from ..core import load_defaults, save_defaults
    from ..commands.common import find_repo_by_identifier

    repos, defaults, *_ = _resolve_current_repos()
    repo = find_repo_by_identifier(repos, repo_name, defaults)
    if not repo:
        handler._send_error_json(404, f"Repo not found: {repo_name}")
        return

    df = _get_defaults_file()
    defaults = load_defaults(df)
    if "default_action" in body:
        defaults[repo] = body["default_action"]
    save_defaults(df, defaults)
    handler._send_json({"ok": True})


# ---------- patches ----------

@route("GET", "/api/patches")
def api_patches(handler):
    """All patches with metadata."""
    try:
        from ..commands.patches import (
            _scan_patches_from_layers, _search_patches_by_name,
            _search_patches_by_body, _filter_by_status,
        )
    except ImportError:
        handler._send_json([])
        return

    search = handler._query_param("search")
    status = handler._query_param("status")
    body = handler._query_param("body")

    repos, defaults, repo_layers, *_ = _resolve_current_repos()
    all_layers = []
    for layers in repo_layers.values():
        all_layers.extend(layers)

    try:
        from dataclasses import asdict
        patches = _scan_patches_from_layers(all_layers, progress=False)
        if search:
            if body == "1":
                patches = _search_patches_by_body(patches, search)
            else:
                patches = _search_patches_by_name(patches, search)
        if status:
            # Support comma-separated multi-status (union filter)
            statuses = [s.strip() for s in status.split(",") if s.strip()]
            if len(statuses) == 1:
                patches = _filter_by_status(patches, statuses[0])
            else:
                merged = []
                seen = set()
                for s in statuses:
                    for p in _filter_by_status(patches, s):
                        pid = id(p)
                        if pid not in seen:
                            seen.add(pid)
                            merged.append(p)
                patches = merged
        # Convert Patch dataclass objects to JSON-serializable dicts
        result = []
        for p in patches:
            if isinstance(p, dict):
                result.append(p)
            else:
                try:
                    result.append(asdict(p))
                except TypeError:
                    result.append({"path": str(p)})
        handler._send_json(result)
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("GET", "/api/patches/([^/]+)/content")
def api_patch_content(handler, patch_id):
    """Patch file content."""
    # patch_id is URL-encoded path
    from urllib.parse import unquote
    patch_path = unquote(patch_id)
    if not os.path.isfile(patch_path):
        handler._send_error_json(404, "Patch not found")
        return
    try:
        with open(patch_path, "r", errors="replace") as f:
            content = f.read()
        handler._send_json({"path": patch_path, "content": content})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("GET", "/api/patches/status-values")
def api_patch_status_values(handler):
    """Valid upstream-status values and inappropriate reasons."""
    try:
        from ..commands.patches import UPSTREAM_STATUS_VALUES, INAPPROPRIATE_REASONS
    except ImportError:
        handler._send_json({"statuses": {}, "inappropriate_reasons": []})
        return
    statuses = {}
    for name, (requires_detail, description) in UPSTREAM_STATUS_VALUES.items():
        statuses[name] = {"requires_detail": requires_detail, "description": description}
    handler._send_json({
        "statuses": statuses,
        "inappropriate_reasons": INAPPROPRIATE_REASONS,
    })


@route("POST", "/api/patches/status")
def api_patch_status_update(handler):
    """Update upstream-status of a patch file."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    status = body.get("status", "")
    detail = body.get("detail", "")
    if not path or not status:
        handler._send_error_json(400, "Missing 'path' or 'status'")
        return
    validated = _validate_file_path(path)
    if not validated:
        handler._send_error_json(403, "Path not allowed")
        return
    try:
        from ..commands.patches import _update_upstream_status, UPSTREAM_STATUS_VALUES
        if status not in UPSTREAM_STATUS_VALUES:
            handler._send_error_json(400, f"Invalid status: {status}")
            return
        ok = _update_upstream_status(validated, status, detail)
        handler._send_json({"ok": ok})
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- b4 / lore ----------


def _send_lore_results(handler, results, grouped: bool):
    """Serialize and send lore results, optionally grouped into threads."""
    from dataclasses import asdict
    if not results:
        handler._send_json({"threads": [], "flat": []} if grouped else [])
        return
    flat = [asdict(r) for r in results]
    if grouped:
        from ..commands.b4 import group_into_threads
        thread_groups = group_into_threads(results)
        handler._send_json({
            "threads": [{
                "root": asdict(g["root"]),
                "children": [asdict(c) for c in g["children"]],
                "series_tag": g.get("series_tag"),
                "version": g.get("version"),
                "total_parts": g.get("total_parts"),
                "received_parts": g.get("received_parts"),
                "subject_tags": g.get("subject_tags", []),
            } for g in thread_groups],
            "flat": flat,
        })
    else:
        handler._send_json(flat)


@route("GET", "/api/b4/search")
def api_b4_search(handler):
    """Search lore.kernel.org with optional filters."""
    q = handler._query_param("q")
    if not q:
        handler._send_error_json(400, "Missing 'q' parameter")
        return
    try:
        from ..commands.b4 import lore_search, get_list_base_url
        list_name = handler._query_param("list") or None
        search_type = handler._query_param("type") or "subject"
        time_range = handler._query_param("range") or "2.years.ago.."
        threads = handler._query_param("threads") == "1"
        grouped = handler._query_param("grouped") == "1"
        base_url = get_list_base_url(list_name) if list_name else ""
        results = lore_search(q, list_name=list_name, search_type=search_type,
                              time_range=time_range, threads=threads,
                              base_url=base_url)
        _send_lore_results(handler, results, grouped)
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("POST", "/api/b4/apply")
def api_b4_apply(handler):
    """Apply patch series — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    repo = body.get("repo", "")
    branch = body.get("branch", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return

    # Resolve repo: explicit > match by list name > first git repo in project
    if not repo:
        from ..commands.projects import get_current_project
        project = _project_param(handler) or get_current_project() or "."
        list_name = body.get("list", "")
        repo = _resolve_git_repo(project, list_name)

    from ..commands.b4 import _normalize_msgid
    msgid = _normalize_msgid(msgid)

    def _apply():
        try:
            # Checkout target branch if specified and different from current
            if branch:
                try:
                    current = subprocess.check_output(
                        ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                    if current != branch:
                        handler.sse.broadcast("command_output", {"stream": "stdout", "line": f"Switching to branch: {branch}"})
                        co = subprocess.run(
                            ["git", "-C", repo, "checkout", branch],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                        )
                        if co.returncode != 0:
                            handler.sse.broadcast("command_output", {"stream": "stderr", "line": f"Failed to checkout {branch}: {co.stdout.strip()}", "done": True, "exitcode": co.returncode})
                            return
                except Exception as e:
                    handler.sse.broadcast("command_output", {"stream": "stderr", "line": f"Branch checkout error: {e}", "done": True})
                    return

            # Count commits before apply for reporting
            try:
                before_count = subprocess.check_output(
                    ["git", "-C", repo, "rev-list", "--count", "HEAD"],
                    text=True, stderr=subprocess.DEVNULL,
                ).strip()
            except Exception:
                before_count = "0"

            # Use b4 shazam for non-interactive apply (no confirmation prompt)
            proc = subprocess.Popen(
                ["b4", "shazam", msgid],
                cwd=repo,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()

            # Count commits after to determine how many were applied
            commits_applied = 0
            repo_name = os.path.basename(repo)
            applied_branch = branch
            if proc.returncode == 0:
                try:
                    after_count = subprocess.check_output(
                        ["git", "-C", repo, "rev-list", "--count", "HEAD"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                    commits_applied = int(after_count) - int(before_count)
                except Exception:
                    pass
                if not applied_branch:
                    try:
                        applied_branch = subprocess.check_output(
                            ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                            text=True, stderr=subprocess.DEVNULL,
                        ).strip()
                    except Exception:
                        applied_branch = ""

            handler.sse.broadcast("command_output", {
                "stream": "stdout", "line": "", "done": True,
                "exitcode": proc.returncode,
                "repo": repo_name,
                "branch": applied_branch,
                "commits_applied": commits_applied,
            })
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_apply, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("GET", "/api/b4/lists")
def api_b4_lists(handler):
    """Return known mailing lists + custom lists + full lore manifest."""
    try:
        from ..commands.b4 import KNOWN_MAILING_LISTS, get_lore_manifest, get_custom_lists
        # Custom lists first (user-defined, may have custom base_url)
        custom = get_custom_lists()
        lists = [{"address": e.get("address", ""), "lore_name": e["lore_name"],
                  "description": e.get("description", ""),
                  "base_url": e.get("base_url", ""), "custom": True}
                 for e in custom]
        seen = {e["lore_name"] for e in lists}
        # Known curated lists
        for addr, lore, desc in KNOWN_MAILING_LISTS:
            if lore not in seen:
                lists.append({"address": addr, "lore_name": lore, "description": desc})
                seen.add(lore)
        # Lore manifest (all public lists)
        manifest = get_lore_manifest()
        for name, desc in manifest.items():
            if name not in seen:
                lists.append({"address": "", "lore_name": name, "description": desc})
        handler._send_json(lists)
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/b4/lists/custom")
def api_b4_custom_list_save(handler):
    """Add or update a custom mailing list."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    lore_name = body.get("lore_name", "").strip()
    if not lore_name:
        handler._send_error_json(400, "Missing 'lore_name'")
        return
    from ..commands.b4 import save_custom_list
    save_custom_list(
        lore_name=lore_name,
        address=body.get("address", "").strip(),
        description=body.get("description", "").strip(),
        base_url=body.get("base_url", "").strip(),
    )
    handler._send_json({"ok": True})


@route("POST", "/api/b4/lists/custom/delete")
def api_b4_custom_list_delete(handler):
    """Remove a custom mailing list."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    lore_name = body.get("lore_name", "").strip()
    if not lore_name:
        handler._send_error_json(400, "Missing 'lore_name'")
        return
    from ..commands.b4 import remove_custom_list
    remove_custom_list(lore_name)
    handler._send_json({"ok": True})


@route("GET", "/api/b4/browse")
def api_b4_browse(handler):
    """Browse recent activity on a mailing list."""
    list_name = handler._query_param("list")
    if not list_name:
        handler._send_error_json(400, "Missing 'list' parameter")
        return
    try:
        from ..commands.b4 import lore_browse_list, get_list_base_url
        days = int(handler._query_param("days") or "14")
        grouped = handler._query_param("grouped") == "1"
        base_url = get_list_base_url(list_name)
        results = lore_browse_list(list_name, days=days, base_url=base_url)
        _send_lore_results(handler, results, grouped)
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/b4/diff")
def api_b4_diff(handler):
    """Compare patch series versions — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return
    msgid2 = body.get("msgid2") or None

    from ..commands.b4 import _normalize_msgid
    msgid = _normalize_msgid(msgid)

    def _diff():
        try:
            cmd = ["b4", "diff"]
            if msgid2:
                cmd.extend([_normalize_msgid(msgid2), msgid])
            else:
                cmd.append(msgid)
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()
            handler.sse.broadcast("command_output", {"stream": "stdout", "line": "", "done": True, "exitcode": proc.returncode})
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_diff, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("POST", "/api/b4/trailers")
def api_b4_trailers(handler):
    """Collect trailers (Reviewed-by, Acked-by, etc.) — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return

    repo = body.get("repo", "")
    if not repo:
        from ..commands.projects import get_current_project
        project = _project_param(handler) or get_current_project() or "."
        list_name = body.get("list", "")
        repo = _resolve_git_repo(project, list_name)

    from ..commands.b4 import _normalize_msgid
    msgid = _normalize_msgid(msgid)

    def _trailers():
        try:
            proc = subprocess.Popen(
                ["b4", "trailers", msgid],
                cwd=repo,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()
            handler.sse.broadcast("command_output", {"stream": "stdout", "line": "", "done": True, "exitcode": proc.returncode})
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_trailers, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("POST", "/api/b4/check-newer")
def api_b4_check_newer(handler):
    """Check for newer revision of a patch series — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return

    repo = body.get("repo", "")
    if not repo:
        from ..commands.projects import get_current_project
        project = _project_param(handler) or get_current_project() or "."
        repo = _resolve_git_repo(project, "")

    from ..commands.b4 import _normalize_msgid
    msgid = _normalize_msgid(msgid)

    def _check():
        import tempfile, shutil as _shutil
        tmpdir = tempfile.mkdtemp(prefix="b4-check-")
        try:
            proc = subprocess.Popen(
                ["b4", "am", "--check-newer-revisions", "-o", tmpdir, msgid],
                cwd=tmpdir,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()
            handler.sse.broadcast("command_output", {"stream": "stdout", "line": "", "done": True, "exitcode": proc.returncode})
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})
        finally:
            _shutil.rmtree(tmpdir, ignore_errors=True)

    t = threading.Thread(target=_check, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("POST", "/api/b4/pr")
def api_b4_pr(handler):
    """Fetch a pull request via b4 pr — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return

    repo = body.get("repo", "")
    if not repo:
        from ..commands.projects import get_current_project
        project = _project_param(handler) or get_current_project() or "."
        list_name = body.get("list", "")
        repo = _resolve_git_repo(project, list_name)

    from ..commands.b4 import _normalize_msgid
    msgid = _normalize_msgid(msgid)

    def _pr():
        try:
            proc = subprocess.Popen(
                ["b4", "pr", msgid],
                cwd=repo,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()
            handler.sse.broadcast("command_output", {"stream": "stdout", "line": "", "done": True, "exitcode": proc.returncode})
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_pr, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("POST", "/api/b4/mbox")
def api_b4_mbox(handler):
    """Download thread as mbox — streams output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    msgid = body.get("msgid", "")
    repo = body.get("repo", "")
    if not msgid:
        handler._send_error_json(400, "Missing 'msgid'")
        return

    if not repo:
        from ..commands.projects import get_current_project
        project = _project_param(handler) or get_current_project() or "."
        list_name = body.get("list", "")
        repo = _resolve_git_repo(project, list_name)

    from ..commands.b4 import _normalize_msgid
    import tempfile, socket
    msgid = _normalize_msgid(msgid)
    hostname = socket.gethostname()

    def _mbox():
        try:
            tmpdir = tempfile.mkdtemp(prefix="b4-mbox-")
            proc = subprocess.Popen(
                ["b4", "mbox", "-o", tmpdir, msgid],
                cwd=repo,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
                env={**os.environ, "NO_COLOR": "1"},
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": _strip_ansi(line.rstrip("\n"))})
            proc.wait()
            if proc.returncode == 0:
                # Find the actual mbox file for mutt integration
                mbox_path = tmpdir
                for f in os.listdir(tmpdir):
                    if f.endswith((".mbx", ".mbox")):
                        mbox_path = os.path.join(tmpdir, f)
                        break
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": f"Mbox saved to {tmpdir} on {hostname}", "done": True, "exitcode": 0, "path": tmpdir, "mbox_path": mbox_path})
            else:
                handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 mbox failed", "done": True, "exitcode": proc.returncode})
        except FileNotFoundError:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": "b4 is not installed. Install with: pip install b4", "done": True})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_mbox, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


@route("GET", "/api/b4/message")
def api_b4_message(handler):
    """Fetch and decode a raw email from lore by URL or msgid."""
    import email
    import email.policy
    import urllib.request

    url = handler._query_param("url")
    msgid = handler._query_param("msgid")
    if not url and not msgid:
        handler._send_error_json(400, "Missing 'url' or 'msgid'")
        return

    if not url:
        # Build URL from msgid
        from ..commands.b4 import _normalize_msgid
        msgid = _normalize_msgid(msgid)
        url = f"https://lore.kernel.org/all/{msgid.strip('<>')}/raw"
    elif not url.endswith("/raw"):
        url = url.rstrip("/") + "/raw"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "bit/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read()
    except Exception as e:
        handler._send_error_json(502, f"Failed to fetch: {e}")
        return

    keep = ("From", "To", "Cc", "Subject", "Date", "Message-Id",
            "In-Reply-To", "List-Id")
    try:
        msg = email.message_from_bytes(raw, policy=email.policy.default)
        headers = {}
        for name in keep:
            val = msg.get(name)
            if val:
                headers[name] = str(val)
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    payload = part.get_content()
                    if isinstance(payload, str):
                        body = payload
                        break
        else:
            payload = msg.get_content()
            if isinstance(payload, str):
                body = payload
        handler._send_json({"headers": headers, "body": body})
    except Exception as e:
        handler._send_error_json(500, f"Failed to parse email: {e}")


@route("GET", "/api/b4/repos")
def api_b4_repos(handler):
    """Return candidate git repos for a mailing list, scored by match."""
    from ..commands.projects import get_current_project
    project = _project_param(handler) or get_current_project() or "."
    list_name = handler._query_param("list") or ""
    try:
        from ..commands.b4 import get_candidate_repos
        candidates = get_candidate_repos(project, list_name)
        # Strip score from response, determine auto-selected
        repos = [{k: v for k, v in c.items() if k != "score"} for c in candidates]
        auto_selected = candidates[0]["path"] if candidates and candidates[0]["score"] > 0 else ""
        handler._send_json({"repos": repos, "auto_selected": auto_selected})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("GET", "/api/b4/mail-reader")
def api_b4_mail_reader(handler):
    """Check if mutt/neomutt is available."""
    try:
        from ..commands.b4 import detect_mail_reader
        cmd = detect_mail_reader()
        handler._send_json({"available": cmd is not None, "command": cmd or ""})
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- recipes ----------

@route("GET", "/api/recipes")
def api_recipes(handler):
    """All recipes or search."""
    search = handler._query_param("search")
    try:
        from ..commands.recipe import _scan_recipes_from_layers, _scan_configured_recipes
    except ImportError:
        handler._send_json([])
        return

    repos, defaults, repo_layers, *_ = _resolve_current_repos()
    all_layers = []
    for layers in repo_layers.values():
        all_layers.extend(layers)

    try:
        recipes = _scan_recipes_from_layers(all_layers, progress=False)
        if search:
            q = search.lower()
            recipes = [r for r in recipes if q in (
                r.get("pn", "") + r.get("filename", "") +
                r.get("SUMMARY", "") + r.get("DESCRIPTION", "")
            ).lower()]
        handler._send_json(recipes)
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("GET", "/api/recipes/([^/]+)")
def api_recipe_detail(handler, recipe_name):
    """Recipe details."""
    try:
        from ..commands.recipe import _scan_recipes_from_layers, _parse_recipe_metadata
    except ImportError:
        handler._send_error_json(404, "Not found")
        return

    repos, defaults, repo_layers, *_ = _resolve_current_repos()
    all_layers = []
    for layers in repo_layers.values():
        all_layers.extend(layers)

    try:
        recipes = _scan_recipes_from_layers(all_layers)
        for r in recipes:
            if r.get("name") == recipe_name or r.get("filename", "").startswith(recipe_name):
                handler._send_json(r)
                return
        handler._send_error_json(404, f"Recipe not found: {recipe_name}")
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- fragments ----------

def _get_fragment_context(handler):
    """Resolve layer paths and toolcfg path for fragment operations."""
    from ..commands.fragment import _get_toolcfg_path
    from ..personas.yocto.bblayers import resolve_bblayers_path, extract_layer_paths

    project_override = _project_param(handler)
    repos, defaults, repo_layers, *_ = _resolve_current_repos(project_override)
    all_layers = []
    for layers in repo_layers.values():
        all_layers.extend(layers)

    bblayers_path = resolve_bblayers_path(None)
    toolcfg_path = _get_toolcfg_path(bblayers_path)
    return all_layers, toolcfg_path


@route("GET", "/api/fragments")
def api_fragments(handler):
    """All fragments."""
    project_override = _project_param(handler)

    # Remote project — proxy via SSH
    remote_result = _ssh_query(project_override, "fragments")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    try:
        from ..commands.fragment import (
            _discover_fragments, _parse_enabled_fragments,
            DEFAULT_BUILTIN_PREFIXES, _get_enabled_builtin_values,
        )
    except ImportError:
        handler._send_json([])
        return
    try:
        all_layers, toolcfg_path = _get_fragment_context(handler)
        fragments = _discover_fragments(all_layers, progress=False)
        enabled_list = _parse_enabled_fragments(toolcfg_path) if os.path.exists(toolcfg_path) else []
        enabled_builtins = _get_enabled_builtin_values(enabled_list, DEFAULT_BUILTIN_PREFIXES)

        result = []
        for f in fragments:
            result.append({
                "name": f.name,
                "path": f.path,
                "layer": f.layer,
                "domain": f.domain,
                "summary": f.summary,
                "description": f.description,
                "enabled": f.name in enabled_list,
                "is_builtin": f.is_builtin,
            })

        # Add builtin prefix entries (machine/distro)
        for prefix in DEFAULT_BUILTIN_PREFIXES:
            val = enabled_builtins.get(prefix.prefix, "")
            result.append({
                "name": f"{prefix.prefix}:{prefix.variable}",
                "layer": "",
                "domain": "builtin",
                "summary": f"Current {prefix.variable}: {val}" if val else f"No {prefix.variable} set",
                "description": "",
                "enabled": bool(val),
                "is_builtin": True,
                "builtin_prefix": prefix.prefix,
                "builtin_value": val,
            })

        handler._send_json(result)
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("POST", "/api/fragments/enable")
def api_fragment_enable(handler):
    """Enable fragment.  Body: {"name": "..."}."""
    body = handler._read_json()
    if not body or not body.get("name"):
        handler._send_error_json(400, "Missing 'name'")
        return

    project_override = _project_param(handler)
    remote_result = _ssh_query_post(project_override, "fragments/enable", body)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    try:
        from ..commands.fragment import (
            _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES,
        )
        from ..personas.yocto.bblayers import resolve_bblayers_path
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        _update_oe_fragments(toolcfg_path, [body["name"]], [], DEFAULT_BUILTIN_PREFIXES)
        handler._send_json({"ok": True})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/fragments/disable")
def api_fragment_disable(handler):
    """Disable fragment.  Body: {"name": "..."}."""
    body = handler._read_json()
    if not body or not body.get("name"):
        handler._send_error_json(400, "Missing 'name'")
        return

    project_override = _project_param(handler)
    remote_result = _ssh_query_post(project_override, "fragments/disable", body)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    try:
        from ..commands.fragment import (
            _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES,
        )
        from ..personas.yocto.bblayers import resolve_bblayers_path
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        _update_oe_fragments(toolcfg_path, [], [body["name"]], DEFAULT_BUILTIN_PREFIXES)
        handler._send_json({"ok": True})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/fragments/builtin")
def api_fragment_builtin(handler):
    """Set a builtin prefix value (machine/distro)."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    prefix = body.get("prefix", "")
    value = body.get("value", "")
    if not prefix or not value:
        handler._send_error_json(400, "Missing 'prefix' or 'value'")
        return

    project_override = _project_param(handler)
    remote_result = _ssh_query_post(project_override, "fragments/builtin", body)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    try:
        from ..commands.fragment import (
            _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES,
        )
        from ..personas.yocto.bblayers import resolve_bblayers_path
        bblayers_path = resolve_bblayers_path(None)
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        frag_name = f"{prefix}/{value}"
        _update_oe_fragments(toolcfg_path, [frag_name], [], DEFAULT_BUILTIN_PREFIXES)
        handler._send_json({"ok": True})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("GET", "/api/fragments/toolcfg")
def api_fragment_toolcfg(handler):
    """Get toolcfg.conf path."""
    try:
        _, toolcfg_path = _get_fragment_context(handler)
        handler._send_json({"path": toolcfg_path})
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- deps ----------

@route("GET", "/api/deps/layers")
def api_deps_layers(handler):
    """Layer dependency tree."""
    try:
        from ..commands.deps import build_layer_dependency_graph
    except ImportError:
        handler._send_json({})
        return
    try:
        project_override = _project_param(handler)
        repos, defaults, repo_layers, *_ = _resolve_current_repos(project_override)
        all_layers = []
        for layers in repo_layers.values():
            all_layers.extend(layers)

        graph = build_layer_dependency_graph(all_layers)
        # Serialize LayerInfo objects to dicts
        result = {}
        for name, info in graph.items():
            result[name] = {
                "name": info.name,
                "path": info.path,
                "depends": list(info.depends),
                "recommends": list(info.recommends),
                "priority": info.priority,
            }
        handler._send_json({"graph": result})
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("GET", "/api/deps/layers/([^/]+)")
def api_deps_layer(handler, layer_name):
    """Single layer deps."""
    try:
        from ..commands.deps import build_layer_dependency_graph, get_forward_deps, get_reverse_deps
    except ImportError:
        handler._send_json({})
        return
    try:
        from urllib.parse import unquote
        layer_name = unquote(layer_name)
        project_override = _project_param(handler)
        repos, defaults, repo_layers, *_ = _resolve_current_repos(project_override)
        all_layers = []
        for layers in repo_layers.values():
            all_layers.extend(layers)

        graph = build_layer_dependency_graph(all_layers)
        forward = get_forward_deps(graph, layer_name)
        reverse = get_reverse_deps(graph, layer_name)
        handler._send_json({
            "layer": layer_name,
            "depends_on": sorted(forward),
            "depended_by": sorted(reverse),
        })
    except Exception as e:
        handler._send_json({"error": str(e)})


# ---------- info ----------

@route("GET", "/api/info/vars")
def api_info_vars(handler):
    """Build variables."""
    try:
        from ..commands.info import get_all_variables_cached
        variables = get_all_variables_cached()
        handler._send_json(variables if variables else {})
    except Exception as e:
        handler._send_json({"error": str(e)})


@route("GET", "/api/info/layers")
def api_info_layers(handler):
    """Layer branch/commit info."""
    try:
        from ..commands.info import get_layer_info
        raw = get_layer_info()
        info = [
            {"name": name, "branch": branch, "commit": commit, "path": repo_path}
            for name, branch, commit, repo_path in raw
        ] if raw else []
        handler._send_json(info)
    except Exception as e:
        handler._send_json({"error": str(e)})


# ---------- setup ----------

@route("GET", "/api/setup/registry")
def api_setup_registry(handler):
    """List all available configurations from registries."""
    from ..commands.confjson import (find_registry_dirs, discover_registry,
                                     synthesize_basic_configs)
    from ..commands.projects import get_current_project

    project_override = _project_param(handler)
    project_path = project_override or get_current_project() or os.getcwd()

    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        registry_dirs = find_registry_dirs()
    finally:
        os.chdir(saved_cwd)

    all_entries = []
    for d, label in registry_dirs:
        entries = discover_registry(d, source_label=label)
        all_entries.extend(entries)
    all_entries.extend(synthesize_basic_configs())

    result = []
    for fname, full_path, rel_path, conf, source_label in all_entries:
        configs = []
        for c in conf.configurations:
            one_of = {}
            for cat_name, cat in c.oe_fragments_one_of.items():
                one_of[cat_name] = {
                    "description": cat.description,
                    "options": [{"name": o.name, "description": o.description} for o in cat.options],
                }
            configs.append({
                "name": c.name,
                "description": c.description,
                "bb_layers": c.bb_layers,
                "oe_fragments": c.oe_fragments,
                "oe_fragments_one_of": one_of,
            })
        sources = []
        for s in conf.sources:
            sources.append({
                "name": s.name,
                "path": s.path,
                "git_url": s.git_url,
                "branch": s.branch or s.rev or "",
                "is_local": s.is_local,
            })
        result.append({
            "filename": fname,
            "path": full_path,
            "rel_path": rel_path,
            "source": source_label,
            "description": conf.description,
            "sources": sources,
            "configurations": configs,
        })
    handler._send_json(result)


@route("POST", "/api/setup/clone")
def api_setup_clone(handler):
    """Clone repos from a .conf.json configuration."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    basic_mode = body.get("basic", False)
    register_project = body.get("register_project", False)
    project_name = body.get("name", "")
    project_dir = body.get("project_dir", "")
    layers_dir = body.get("layers_dir", "layers")
    branch = body.get("branch", "")

    conf = None
    config_name = ""

    if basic_mode:
        # Legacy basic_mode flag — synthesize a basic config for the branch
        from ..commands.confjson import synthesize_basic_configs
        synth = synthesize_basic_configs(branches=[branch or "master"])
        if synth:
            _fname, _path, _rel, conf, _label = synth[0]
            selected = conf.configurations[0]
            config_name = selected.name
        else:
            handler._send_error_json(500, "Failed to synthesize basic config")
            return
    else:
        config_file = body.get("config_file", "")
        config_name = body.get("config_name", "")

        if not config_file or not config_name:
            handler._send_error_json(400, "Missing 'config_file' or 'config_name'")
            return

        # Synthetic configs (generated, not backed by a file)
        if config_file.startswith("__synthetic__/"):
            from ..commands.confjson import synthesize_basic_configs
            # Extract branch from filename: basic-<branch>.conf.json
            _base = os.path.basename(config_file)
            _branch = _base.replace("basic-", "").replace(".conf.json", "")
            synth = synthesize_basic_configs(branches=[_branch])
            if not synth:
                handler._send_error_json(400, f"Cannot synthesize config for branch '{_branch}'")
                return
            _fname, _path, _rel, conf, _label = synth[0]
        else:
            from ..commands.confjson import parse_conf_json
            try:
                conf = parse_conf_json(config_file)
            except Exception as e:
                handler._send_error_json(400, f"Failed to parse config: {e}")
                return

        selected = None
        for c in conf.configurations:
            if c.name == config_name:
                selected = c
                break
        if not selected:
            handler._send_error_json(404, f"Configuration '{config_name}' not found")
            return

    # Check if project_dir is a remote URI (user@host:/path)
    from ..commands.ssh_remote import parse_remote_uri
    parsed_remote = parse_remote_uri(project_dir) if project_dir else None

    # Normalize and pre-flight validate local paths
    if project_dir and not parsed_remote:
        project_dir = os.path.expanduser(project_dir)
        project_dir = os.path.abspath(project_dir)
        try:
            os.makedirs(project_dir, exist_ok=True)
        except OSError as e:
            handler._send_error_json(400, f"Cannot create directory: {e}")
            return

    # Run clone in background thread so UI isn't blocked
    import threading

    def _do_remote_clone():
        try:
            user, host, remote_path = parsed_remote
            total = len(conf.sources) if conf else 0
            handler.sse.broadcast("setup_clone_progress", {
                "repo": "remote clone",
                "current": 1,
                "total": total,
            })
            from ..commands.projects import _remote_clone_from_config
            rc = _remote_clone_from_config(user, host, remote_path,
                                           conf, selected)
            if register_project:
                from ..commands.projects import add_remote_project
                from ..commands.ssh_remote import format_remote_uri
                uri = format_remote_uri(user, host, remote_path)
                add_remote_project(uri,
                                   project_name or os.path.basename(remote_path),
                                   skip_path_check=True)
                handler.sse.broadcast("projects_list_changed", {})
            handler.sse.broadcast("setup_clone_done", {
                "project_dir": project_dir,
                "config_name": config_name,
                "remote": True,
            })
        except Exception as e:
            handler.sse.broadcast("setup_clone_error", {"error": str(e)})

    def _do_clone():
        from ..commands.setup import clone_sources
        from ..commands.common import write_ignore_file, add_extra_repo
        from ..core import load_defaults, save_defaults

        saved = os.getcwd()
        try:
            target = project_dir or saved
            os.chdir(target)
            full_layers = os.path.join(target, layers_dir)

            clone_src_list = list(conf.sources)

            def _sse_progress(event, data):
                if event == "progress":
                    handler.sse.broadcast("setup_clone_progress", data)
                elif event == "error":
                    handler.sse.broadcast("setup_clone_error",
                                          {"error": data["message"]})

            success, non_layer_repos = clone_sources(
                clone_src_list, full_layers,
                fallback_branch=branch or "master",
                progress_cb=_sse_progress,
            )
            if not success:
                return

            # Post-clone housekeeping
            defaults_file = os.path.join(target, ".bit.defaults")
            defaults = load_defaults(defaults_file)
            write_ignore_file(target)

            for repo_path in non_layer_repos:
                add_extra_repo(defaults_file, defaults, repo_path)

            defaults = load_defaults(defaults_file)
            defaults["__conf_json__"] = {
                "file": body.get("config_file", ""),
                "selected": config_name,
                "applied": False,
            }
            save_defaults(defaults_file, defaults)

            # Register as tracked project if requested
            if register_project:
                from ..commands.projects import add_project
                ok = add_project(target, project_name or os.path.basename(target))
                if not ok:
                    handler.sse.broadcast("setup_clone_error", {
                        "error": f"Failed to register project: {target}"})
                handler.sse.broadcast("projects_list_changed", {})

            handler.sse.broadcast("setup_clone_done", {
                "project_dir": project_dir or saved,
                "config_name": config_name,
            })
        except Exception as e:
            import traceback
            handler.sse.broadcast("setup_clone_error", {
                "error": f"{e}\n{traceback.format_exc()}"})
        finally:
            os.chdir(saved)

    if parsed_remote:
        t = threading.Thread(target=_do_remote_clone, daemon=True)
    else:
        t = threading.Thread(target=_do_clone, daemon=True)
    t.start()
    repo_count = len(conf.sources) if conf else 0
    handler._send_json({"ok": True, "message": f"Cloning {repo_count} repos in background"})


@route("POST", "/api/setup/apply")
def api_setup_apply(handler):
    """Apply layers and fragments from a saved .conf.json config."""
    from ..commands.projects import get_current_project
    from ..commands.query import query_setup_apply_layers
    from ..core import load_defaults

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No project selected")
        return

    config_file = body.get("config_file", "")
    config_name = body.get("config_name", "")
    one_of_choices = body.get("one_of_choices", {})

    if not config_file or not config_name:
        defaults_file = os.path.join(project_path, ".bit.defaults")
        defaults = load_defaults(defaults_file)
        conf_meta = defaults.get("__conf_json__", {})
        config_file = conf_meta.get("file", "")
        config_name = conf_meta.get("selected", "")

    if not config_file or not config_name:
        handler._send_error_json(400, "No configuration specified and none saved")
        return

    result = query_setup_apply_layers(project_path, config_file, config_name,
                                       one_of_choices=one_of_choices or None)
    if "error" in result:
        handler._send_error_json(500, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/setup/registry-copy")
def api_setup_registry_copy(handler):
    """Copy a .conf.json file to the user registry."""
    import shutil

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    source_path = body.get("source_path", "")
    target_name = body.get("target_name", "")

    if not source_path:
        handler._send_error_json(400, "Missing 'source_path'")
        return

    if not os.path.isfile(source_path):
        handler._send_error_json(404, f"File not found: {source_path}")
        return

    # Validate it's a valid .conf.json
    from ..commands.confjson import parse_conf_json
    try:
        parse_conf_json(source_path)
    except Exception as e:
        handler._send_error_json(400, f"Invalid .conf.json: {e}")
        return

    # Determine target filename
    if target_name:
        basename = target_name
        if not basename.endswith(".conf.json"):
            basename += ".conf.json"
    else:
        basename = os.path.basename(source_path)
        if not basename.endswith(".conf.json"):
            basename += ".conf.json"

    registry_dir = os.path.expanduser("~/.config/bit/registry")
    os.makedirs(registry_dir, exist_ok=True)
    target = os.path.join(registry_dir, basename)

    shutil.copy2(source_path, target)
    handler._send_json({"ok": True, "target": target, "basename": basename})


@route("POST", "/api/setup/config/describe")
def api_setup_config_describe(handler):
    """Set description on a user registry .conf.json file."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    path = body.get("path", "")
    description = body.get("description", "")

    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return

    # Safety: only allow user registry files
    registry_dir = os.path.normpath(os.path.expanduser("~/.config/bit/registry"))
    normalized = os.path.normpath(os.path.abspath(path))
    if not normalized.startswith(registry_dir + os.sep) and normalized != registry_dir:
        handler._send_error_json(403, "Only user registry configs can be modified")
        return

    if not os.path.isfile(normalized):
        handler._send_error_json(404, "Config file not found")
        return

    try:
        with open(normalized, "r", encoding="utf-8") as f:
            data = json.load(f)
        data["description"] = description
        for cfg_entry in data.get("bitbake-setup", {}).get("configurations", []):
            cfg_entry["description"] = description
        with open(normalized, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
        handler._send_json({"ok": True})
    except (json.JSONDecodeError, OSError) as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/setup/config/rename")
def api_setup_config_rename(handler):
    """Rename a user registry .conf.json file."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    path = body.get("path", "")
    new_name = body.get("new_name", "")

    if not path or not new_name:
        handler._send_error_json(400, "Missing 'path' or 'new_name'")
        return

    # Safety: only allow user registry files
    registry_dir = os.path.normpath(os.path.expanduser("~/.config/bit/registry"))
    normalized = os.path.normpath(os.path.abspath(path))
    if not normalized.startswith(registry_dir + os.sep) and normalized != registry_dir:
        handler._send_error_json(403, "Only user registry configs can be modified")
        return

    if not os.path.isfile(normalized):
        handler._send_error_json(404, "Config file not found")
        return

    if not new_name.endswith(".conf.json"):
        new_name += ".conf.json"
    new_path = os.path.join(os.path.dirname(normalized), new_name)

    if os.path.exists(new_path) and new_path != normalized:
        handler._send_error_json(409, f"Target already exists: {new_name}")
        return

    try:
        os.rename(normalized, new_path)
        handler._send_json({"ok": True, "new_path": new_path})
    except OSError as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/setup/config/delete")
def api_setup_config_delete(handler):
    """Delete a user registry .conf.json file."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    path = body.get("path", "")
    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return

    # Safety: only allow user registry files
    registry_dir = os.path.normpath(os.path.expanduser("~/.config/bit/registry"))
    normalized = os.path.normpath(os.path.abspath(path))
    if not normalized.startswith(registry_dir + os.sep) and normalized != registry_dir:
        handler._send_error_json(403, "Only user registry configs can be deleted")
        return

    if not os.path.isfile(normalized):
        handler._send_error_json(404, "Config file not found")
        return

    try:
        os.unlink(normalized)
        handler._send_json({"ok": True})
    except OSError as e:
        handler._send_error_json(500, str(e))


@route("GET", "/api/setup/export/preview")
def api_setup_export_preview(handler):
    """Return export preview data (sources, layers, fragments) for the UI."""
    from ..commands.projects import get_current_project
    from ..commands.query import query_setup_export_preview

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No project selected")
        return

    result = query_setup_export_preview(project_path)
    if "error" in result:
        handler._send_error_json(400, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/setup/export")
def api_setup_export(handler):
    """Export current build state as .conf.json using proper export functions."""
    from ..commands.projects import get_current_project
    from ..commands.query import query_setup_export_execute

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No project selected")
        return

    body = handler._read_json() or {}
    name = body.get("name", "exported")
    description = body.get("description", "")
    fragments = body.get("fragments", [])
    registry = body.get("registry", False)

    result = query_setup_export_execute(project_path, name, description,
                                        fragments, registry)
    if "error" in result:
        handler._send_error_json(500, result["error"])
        return
    handler._send_json(result)


# ---------- export ----------

@route("GET", "/api/export/preview")
def api_export_preview(handler):
    """Exportable commits per repo."""
    from ..commands.query import query_export_preview

    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "export/preview")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    handler._send_json(query_export_preview(project_override))


@route("POST", "/api/export")
def api_export(handler):
    """Export patches."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    try:
        from ..commands.common import commit_files
        repo = body.get("repo", "")
        commits = body.get("commits", [])
        if not repo or not commits:
            handler._send_error_json(400, "Missing 'repo' or 'commits'")
            return
        result = commit_files(repo, commits)
        handler._send_json({"ok": True, "result": str(result)})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/export/prepare")
def api_export_prepare(handler):
    """Prepare repos for export — reorder commits, create branch."""
    from ..commands.query import query_export_prepare
    from .api import _ssh_query_post

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)

    # Remote project: pipe POST body over stdin via SSH
    remote_result = _ssh_query_post(
        project_override, "export/prepare", body, timeout=120)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    result = query_export_prepare(
        project_override,
        repo_configs=body.get("repos", []),
        branch_name=body.get("branch_name", ""),
        force_replace=body.get("force_replace", False),
        backup=body.get("backup", True),
    )
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("POST", "/api/export/patches")
def api_export_patches(handler):
    """Export commits as patches with subject rewriting, optional save.

    Save happens on the machine that holds the project repos (runs inside
    query_export_patches, which executes on the remote host for remote
    projects via SSH).
    """
    from ..commands.query import query_export_patches
    from .api import _ssh_query_post

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)

    query_body = {
        "repos": body.get("repos", []),
        "numbering": body.get("numbering", "global"),
        "subject_prefix": body.get("subject_prefix", ""),
        "series_version": body.get("series_version", 0),
        "cover_letter": body.get("cover_letter", True),
        "target_dir": body.get("target_dir", ""),
        "layout": body.get("layout", "flat"),
        "keep_content": body.get("keep_content", False),
    }

    # Try remote first — query_export_patches handles save on remote host
    remote_result = _ssh_query_post(
        project_override, "export/patches", query_body, timeout=120)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        result = remote_result
    else:
        result = query_export_patches(
            project_override,
            repo_requests=query_body["repos"],
            numbering=query_body["numbering"],
            subject_prefix=query_body["subject_prefix"],
            series_version=query_body["series_version"],
            cover_letter=query_body["cover_letter"],
            target_dir=query_body["target_dir"],
            layout=query_body["layout"],
            keep_content=query_body["keep_content"],
        )

    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(500, result["error"])
        return

    handler._send_json(result)


@route("GET", "/api/export/prep-state")
def api_export_prep_state(handler):
    """Load prep state for a project."""
    from ..commands.query import query_prep_state

    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "export/prep-state")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    handler._send_json(query_prep_state(project_override))


# ---------- remote operations ----------

@route("POST", "/api/remote/sync")
def api_remote_sync(handler):
    """Sync projects from remote host — discovers and registers locally."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    host = body.get("host", "")
    if not host:
        handler._send_error_json(400, "Missing 'host'")
        return
    try:
        from ..commands.projects import sync_from_remote
        added = sync_from_remote(host)
        if added == -1:
            handler._send_error_json(502, f"SSH connection to '{host}' failed")
            return
        handler._send_json({"ok": True, "added": added})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("GET", "/api/remote/([^/]+)/status")
def api_remote_status(handler, host):
    """Remote project status."""
    try:
        from ..commands.ssh_remote import ssh_get_dashboard_summary
        summary = ssh_get_dashboard_summary("", host, "")
        handler._send_json(summary)
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- terminal/command streaming ----------

@route("POST", "/api/run")
def api_run_command(handler):
    """Run a bit command and stream output via SSE."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    command = body.get("command", "")
    if not command:
        handler._send_error_json(400, "Missing 'command'")
        return

    # Only allow known safe bit subcommands
    allowed = {"status", "update", "branch", "explore", "config", "info", "deps", "recipes", "fragments", "patches", "export", "repos"}
    parts = command.split()
    if not parts or parts[0] not in allowed:
        handler._send_error_json(403, f"Command not allowed: {command}")
        return

    def _run():
        try:
            import sys
            proc = subprocess.Popen(
                [sys.executable, "-m", "bitbake_project.cli"] + parts,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, stdin=subprocess.DEVNULL,
            )
            for line in proc.stdout:
                handler.sse.broadcast("command_output", {"stream": "stdout", "line": line.rstrip("\n")})
            proc.wait()
            handler.sse.broadcast("command_output", {"stream": "stdout", "line": "", "done": True, "exitcode": proc.returncode})
        except Exception as e:
            handler.sse.broadcast("command_output", {"stream": "stderr", "line": str(e), "done": True})

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    handler._send_json({"ok": True, "status": "started"})


# ---------- file read/write ----------

@route("GET", "/api/file/read")
def api_file_read(handler):
    """Read a file from a project directory."""
    path = handler._query_param("path")
    validated = _validate_file_path(path)
    if not validated:
        handler._send_error_json(403, "Path not allowed")
        return
    if not os.path.isfile(validated):
        handler._send_error_json(404, "File not found")
        return
    try:
        with open(validated, "r", errors="replace") as f:
            content = f.read()
        handler._send_json({"path": validated, "content": content})
    except Exception as e:
        handler._send_error_json(500, str(e))


@route("POST", "/api/file/write")
def api_file_write(handler):
    """Write to an existing file in a project directory."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    content = body.get("content", "")
    validated = _validate_file_path(path)
    if not validated:
        handler._send_error_json(403, "Path not allowed")
        return
    if not os.path.isfile(validated):
        handler._send_error_json(404, "File must already exist")
        return
    try:
        with open(validated, "w") as f:
            f.write(content)
        handler._send_json({"ok": True})
    except Exception as e:
        handler._send_error_json(500, str(e))


# ---------- themes ----------

@route("GET", "/api/config/themes")
def api_config_themes(handler):
    """Return available themes."""
    from ..core import FZF_THEMES
    result = []
    for name, (colors, description) in FZF_THEMES.items():
        result.append({"name": name, "description": description})
    handler._send_json(result)


# ---------- filesystem ----------

@route("GET", "/api/filesystem/ls")
def api_filesystem_ls(handler):
    """List directories in a path (local or remote via SSH)."""
    path = handler._query_param("path", "~")
    host = handler._query_param("host", "")

    if host:
        # Remote listing via SSH
        from ..commands.ssh_remote import parse_remote_uri, ssh_run
        # host is user@host or just hostname
        if "@" not in host:
            host = os.environ.get("USER", "") + "@" + host
        user_part, _, host_part = host.partition("@")
        if not host_part:
            handler._send_error_json(400, "Invalid host format")
            return
        # Expand ~ on remote
        if path == "~" or path.startswith("~/"):
            expand_cmd = f"echo {shlex.quote(path)}"
            try:
                r = ssh_run(user_part, host_part, expand_cmd, timeout=10)
                if r.returncode == 0 and r.stdout.strip():
                    path = r.stdout.strip()
            except Exception:
                pass
        cmd = (f"cd {shlex.quote(path)} 2>/dev/null && pwd && "
               f"ls -1pA 2>/dev/null | head -200")
        try:
            r = ssh_run(user_part, host_part, cmd, timeout=10)
        except Exception as e:
            handler._send_error_json(500, f"SSH error: {e}")
            return
        if r.returncode != 0:
            handler._send_error_json(400, f"Cannot list: {path}")
            return
        lines = r.stdout.strip().splitlines()
        if not lines:
            handler._send_error_json(400, f"Cannot list: {path}")
            return
        resolved = lines[0]  # pwd output
        entries = []
        for line in lines[1:]:
            if line.endswith("/"):
                name = line.rstrip("/")
                if name and not name.startswith("."):
                    entries.append({"name": name, "type": "dir"})
        parent = os.path.dirname(resolved) if resolved != "/" else "/"
        handler._send_json({"path": resolved, "entries": entries, "parent": parent})
    else:
        # Local listing
        path = os.path.expanduser(path)
        if not os.path.isdir(path):
            handler._send_error_json(400, f"Not a directory: {path}")
            return
        resolved = os.path.abspath(path)
        entries = []
        try:
            names = sorted(os.listdir(resolved))[:200]
        except PermissionError:
            handler._send_error_json(403, f"Permission denied: {resolved}")
            return
        for name in names:
            full = os.path.join(resolved, name)
            if os.path.isdir(full) and not name.startswith("."):
                entries.append({"name": name, "type": "dir"})
        parent = os.path.dirname(resolved) if resolved != "/" else "/"
        handler._send_json({"path": resolved, "entries": entries, "parent": parent})


# ---------- terminal / tmux ----------

@route("POST", "/api/terminal/killall")
def api_terminal_killall(handler):
    """Kill all bit-* tmux sessions."""
    killed = []
    try:
        r = subprocess.run(
            ["tmux", "list-sessions", "-F", "#{session_name}"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            for name in r.stdout.strip().splitlines():
                name = name.strip()
                if name.startswith("bit-"):
                    subprocess.run(
                        ["tmux", "kill-session", "-t", name],
                        capture_output=True, timeout=5,
                    )
                    killed.append(name)
    except (subprocess.TimeoutExpired, OSError):
        pass
    handler._send_json({"killed": killed})


# ---------- explore keybinding actions ----------

@route("POST", "/api/repos/([^/]+)/track")
def api_repo_track(handler, repo_name):
    """Track a repo (add to extra repos, unhide)."""
    from ..commands.query import query_track_repo

    handler._read_json()  # consume POST body
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/track")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_track_repo(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/hide")
def api_repo_hide(handler, repo_name):
    """Hide a repo."""
    from ..commands.query import query_hide_repo

    handler._read_json()  # consume POST body
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/hide")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_hide_repo(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/prune-backups")
def api_repo_prune_backups(handler, repo_name):
    """Prune backup branches for a repo."""
    from ..commands.query import query_prune_backups

    handler._read_json()  # consume POST body
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/prune-backups")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_prune_backups(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/layers/add")
def api_layers_add(handler):
    """Add a layer to bblayers.conf (direct file edit, no bitbake server)."""
    from ..commands.query import query_add_layer
    from urllib.parse import quote

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    layer_path = body.get("layer", "")
    if not layer_path:
        handler._send_error_json(400, "Missing 'layer'")
        return

    project_override = _project_param(handler)

    remote_result = _ssh_query(
        project_override,
        f"layers/add/{quote(layer_path, safe='')}")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_add_layer(layer_path, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(500, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/layers/clone")
def api_layers_clone(handler):
    """Clone a layer repo from the OE Layer Index (async, with SSE progress)."""
    from ..commands.projects import get_current_project

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    url = body.get("url", "")
    branch = body.get("branch", "")
    target = body.get("target", "")
    layer_name = body.get("layer_name", "")

    if not url or not target:
        handler._send_error_json(400, "Missing 'url' or 'target'")
        return

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()

    # Resolve target relative to project directory
    if project_path and not os.path.isabs(target):
        target = os.path.join(project_path, target)
    target = os.path.abspath(target)

    if os.path.exists(target):
        handler._send_error_json(409, f"Target already exists: {target}")
        return

    def _do_clone():
        try:
            cmd = ["git", "clone"]
            if branch:
                cmd += ["-b", branch]
            cmd += [url, target]
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            handler.sse.broadcast("layer_clone_done", {
                "layer_name": layer_name,
                "target": target,
            })
        except subprocess.CalledProcessError as e:
            handler.sse.broadcast("layer_clone_error", {
                "layer_name": layer_name,
                "error": e.stderr.strip() or str(e),
            })
        except Exception as e:
            handler.sse.broadcast("layer_clone_error", {
                "layer_name": layer_name,
                "error": str(e),
            })

    threading.Thread(target=_do_clone, daemon=True).start()
    handler._send_json({"ok": True})


@route("POST", "/api/layers/remove")
def api_layers_remove(handler):
    """Remove a layer from bblayers.conf (direct file edit, no bitbake server)."""
    from ..commands.query import query_remove_layer
    from urllib.parse import quote

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    layer_path = body.get("layer", "")
    if not layer_path:
        handler._send_error_json(400, "Missing 'layer'")
        return

    project_override = _project_param(handler)

    remote_result = _ssh_query(
        project_override,
        f"layers/remove/{quote(layer_path, safe='')}")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_remove_layer(layer_path, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(500, result["error"])
        return
    handler._send_json(result)


# ---------- layer index ----------

@route("GET", "/api/layer-index")
def api_layer_index(handler):
    """Browse the OpenEmbedded Layer Index."""
    from ..commands.setup import _fetch_layer_index
    from ..commands.search import _build_local_layer_status
    from ..commands.projects import get_current_project

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    branch = handler._query_param("branch", "scarthgap")

    data = _fetch_layer_index(force=False)
    if data is None:
        handler._send_error_json(502, "Failed to fetch layer index")
        return

    # Filter by branch and deduplicate (same logic as search.py:run_search)
    seen = set()
    layers = []
    for entry in data:
        entry_branch = entry.get("branch", {}).get("name", "")
        if entry_branch != branch:
            continue
        layer_info = entry.get("layer", {})
        name = layer_info.get("name", "")
        if name in seen:
            continue
        seen.add(name)
        layers.append({
            "name": name,
            "summary": layer_info.get("summary", ""),
            "description": layer_info.get("description", ""),
            "vcs_url": layer_info.get("vcs_url", ""),
            "vcs_subdir": entry.get("vcs_subdir", ""),
        })

    # Enrich with local status
    saved_cwd = os.getcwd()
    try:
        if project_path and os.path.isdir(project_path):
            os.chdir(project_path)
        status_map = _build_local_layer_status(layers)
    finally:
        os.chdir(saved_cwd)

    result = []
    for layer in layers:
        st, local_path = status_map.get(layer["name"], (None, None))
        result.append({
            **layer,
            "status": st,
            "local_path": local_path,
        })

    handler._send_json({"layers": result, "branch": branch})


@route("GET", "/api/layer-index/([^/]+)/deps")
def api_layer_index_deps(handler, layer_name):
    """Dependencies for a layer from the OE Layer Index."""
    from urllib.parse import unquote
    from ..commands.setup import _fetch_layer_index, _fetch_layer_deps_bulk

    layer_name = unquote(layer_name)
    branch = handler._query_param("branch", "scarthgap")

    data = _fetch_layer_index(force=False)
    if data is None:
        handler._send_error_json(502, "Failed to fetch layer index")
        return

    # Filter to target branch
    branch_data = [e for e in data if e.get("branch", {}).get("name") == branch]

    deps_map = _fetch_layer_deps_bulk(branch, branch_data)
    deps = deps_map.get(layer_name, [])
    handler._send_json({"deps": deps, "layer": layer_name})


# ---------- HTTPS ----------

@route("GET", "/api/https/status")
def api_https_status(handler):
    """Return HTTPS status and certificate availability."""
    from .server import _web_cert_paths, _web_ca_cert_path
    cert_file, key_file = _web_cert_paths()
    handler._send_json({
        "ssl_enabled": getattr(handler.server, "ssl_enabled", False),
        "ca_available": getattr(handler.server, "ca_cert_path", None) is not None,
        "cert_exists": os.path.isfile(cert_file),
        "key_exists": os.path.isfile(key_file),
    })


@route("GET", "/api/https/ca\\.crt")
def api_https_ca_download(handler):
    """Serve rootCA.pem as a downloadable file."""
    ca_path = getattr(handler.server, "ca_cert_path", None)
    if not ca_path:
        handler._send_error_json(404, "CA certificate not available")
        return
    try:
        with open(ca_path, "rb") as f:
            data = f.read()
        handler.send_response(200)
        handler.send_header("Content-Type", "application/x-pem-file")
        handler.send_header("Content-Disposition",
                            'attachment; filename="bit-ca.crt"')
        handler.send_header("Content-Length", str(len(data)))
        handler.end_headers()
        handler.wfile.write(data)
    except OSError:
        handler._send_error_json(500, "Error reading CA certificate")
