#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Web interface for bit — browser-based dashboard and management."""

import logging
import os

from .server import run_serve

__all__ = ["run_serve"]

# ---------- Shared web-server logger ----------
# Writes to ~/.config/bit/web.log instead of stderr so the
# in-process fzf TUI isn't corrupted by WebSocket/terminal messages.

_web_logger = logging.getLogger("bit.web")
_web_logger.propagate = False  # never bubble up to root/stderr

if not _web_logger.handlers:
    _log_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(_log_dir, exist_ok=True)
    _fh = logging.FileHandler(os.path.join(_log_dir, "web.log"))
    _fh.setFormatter(logging.Formatter("%(asctime)s %(message)s",
                                       datefmt="%H:%M:%S"))
    _web_logger.addHandler(_fh)
    _web_logger.setLevel(logging.DEBUG)


def web_log(msg: str) -> None:
    """Log a web-server message to the log file (not stderr)."""
    _web_logger.info(msg)
