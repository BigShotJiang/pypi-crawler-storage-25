/* Branch view — expand/collapse tree matching TUI semantics
 * Repos as parent rows; expand to show branch children as tree rows.
 * Arrow keys expand/collapse, Enter on branch child → checkout with confirm.
 *
 * Reads App.state.selectedProject for project context (set by dashboard).
 * Passes ?project= to API so no project activation is needed.
 */
const BranchView = {
  _activeRow: -1,
  _rows: [],
  _repos: [],
  _expandedRepos: new Set(),
  _branchCache: {},    // repoName → [{name, current, remote}, ...]

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: '\u2192/Enter', desc: 'Expand branches'},
    {key: '\u2190', desc: 'Collapse'},
    {key: '\\', desc: 'Expand/collapse all'},
    {key: 'Home/End', desc: 'First/last row'},
    {sep: true},
    {key: 'B', desc: 'Switch all repos', action: 'B'},
  ],

  _project() { return App.state.selectedProject || ''; },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>Branches</h2>
        <div class="btn-group">
          <button class="btn" id="branch-switch-all">Switch All \u25be</button>
          <button class="btn" id="branch-fetch-all">Fetch All</button>
        </div>
      </div>
      <div id="branch-repos" class="loading">Loading repos</div>
    `;

    document.getElementById('branch-switch-all').addEventListener('click', () => this._switchAllModal());
    document.getElementById('branch-fetch-all').addEventListener('click', async () => {
      const btn = document.getElementById('branch-fetch-all');
      btn.classList.add('loading');
      try { await API.refreshAll(); App.showToast('Fetching all repos...'); } catch (e) { App.showToast(e.message, 'error'); }
      btn.classList.remove('loading');
    });

    try {
      const repos = await API.getRepos(this._project());
      this._repos = repos;
      this._renderRepos(repos);
    } catch (e) {
      document.getElementById('branch-repos').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderRepos(repos) {
    const el = document.getElementById('branch-repos');
    if (!repos.length) {
      el.innerHTML = '<div class="empty-state"><h3>No repos found</h3></div>';
      return;
    }

    el.className = '';
    el.innerHTML = `<table class="data-table" id="branch-table" role="grid" aria-label="Branches">
      <thead><tr>
        <th style="width:2ch"></th><th>Repo</th><th>Branch</th><th>Status</th><th></th>
      </tr></thead>
      <tbody id="branch-tbody"></tbody>
    </table>`;

    const tbody = document.getElementById('branch-tbody');

    repos.forEach((repo) => {
      const name = repo.display_name || repo.path;
      const isExpanded = this._expandedRepos.has(name);
      const status = repo.is_dirty
        ? '<span style="color:var(--red)">\u270e dirty</span>'
        : '<span style="color:var(--green)">\u2713 clean</span>';

      // Repo parent row
      const tr = document.createElement('tr');
      tr.dataset.repo = name;
      tr.dataset.type = 'repo';
      tr.setAttribute('role', 'row');
      tr.setAttribute('tabindex', '-1');
      tr.innerHTML = `
        <td><span class="drag-handle">&#9776;</span></td>
        <td class="explore-repo-name">${esc(name)}</td>
        <td style="color:var(--accent)">${esc(repo.branch)}</td>
        <td>${status}</td>
        <td><button class="btn" data-repo="${esc(name)}" data-action="fetch">Fetch</button></td>
      `;
      tbody.appendChild(tr);

      // Fetch button handler
      const fetchBtn = tr.querySelector('button[data-action="fetch"]');
      if (fetchBtn) {
        fetchBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          fetchBtn.classList.add('loading');
          fetchBtn.disabled = true;
          try {
            await API.fetchRepo(name, this._project());
            App.showToast(`Fetched: ${name}`, 'success');
          } catch (err) {
            App.showToast(err.message, 'error');
          }
          fetchBtn.classList.remove('loading');
          fetchBtn.disabled = false;
        });
      }

      // Click repo row to toggle expansion
      tr.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON') return;
        this._toggleExpand(name);
      });

      // Branch children (if expanded and cached)
      if (isExpanded && this._branchCache[name]) {
        this._renderBranchChildren(tbody, name, repo.branch);
      }
    });

    // Preload branches for expanded repos
    repos.forEach(repo => {
      const name = repo.display_name || repo.path;
      if (this._expandedRepos.has(name) && !this._branchCache[name]) {
        this._loadBranches(name, repo.branch);
      }
    });

    // Collect all visible navigable rows (repo + branch children)
    this._rows = Array.from(tbody.querySelectorAll('tr[data-type]'));
    this._activeRow = -1;

    // Column resizer
    const table = document.getElementById('branch-table');
    if (table) initColumnResizer(table, 'branch');

    // Drag-and-drop reordering
    if (tbody) initViewSortable(tbody, 'bit-branch-order', 'tr[data-repo]');

    // Reset order button
    let resetBtn = document.getElementById('view-reset-order');
    if (!resetBtn) {
      resetBtn = document.createElement('button');
      resetBtn.id = 'view-reset-order';
      resetBtn.className = 'btn dash-reset-order-fixed';
      resetBtn.title = 'Reset row order to default';
      resetBtn.textContent = 'Reset Order';
      document.body.appendChild(resetBtn);
    }
    resetBtn.style.display = '';
    resetBtn.onclick = () => {
      resetViewOrder('bit-branch-order');
      this._renderRepos(this._repos);
    };
  },

  _renderBranchChildren(tbody, repoName, currentBranch) {
    const branches = this._branchCache[repoName] || [];
    branches.forEach((b, i) => {
      const isLast = i === branches.length - 1;
      const isCurrent = b.name === currentBranch || b.current;
      const isRemote = b.remote || (b.name && b.name.includes('/'));

      const childTr = document.createElement('tr');
      childTr.className = 'branch-child-row' + (isLast ? ' tree-last' : '');
      childTr.dataset.type = 'branch';
      childTr.dataset.branch = b.name;
      childTr.dataset.parentRepo = repoName;
      childTr.setAttribute('role', 'row');
      childTr.setAttribute('tabindex', '-1');

      const marker = isCurrent ? '\u25cf' : ' ';
      const markerClass = isCurrent ? ' class="branch-current-marker"' : '';
      const nameClass = isRemote ? ' class="branch-remote"' : '';

      childTr.innerHTML = `
        <td class="tree-line"></td>
        <td><span${markerClass}>${marker}</span> <span${nameClass}>${esc(b.name)}</span></td>
        <td></td><td></td><td></td>
      `;
      tbody.appendChild(childTr);

      // Click branch child to checkout
      childTr.addEventListener('click', () => {
        if (!isCurrent) this._checkoutBranch(repoName, b.name);
      });
    });
  },

  async _loadBranches(repoName, currentBranch) {
    try {
      const branches = await API.getRepoBranches(repoName, this._project());
      // Sort: current first, then local alpha, then remote alpha
      branches.sort((a, b) => {
        if (a.current) return -1;
        if (b.current) return 1;
        const aRemote = a.remote || (a.name && a.name.includes('/'));
        const bRemote = b.remote || (b.name && b.name.includes('/'));
        if (aRemote !== bRemote) return aRemote ? 1 : -1;
        return (a.name || '').localeCompare(b.name || '');
      });
      this._branchCache[repoName] = branches;
      // Re-render to show branch children
      this._renderRepos(this._repos);
    } catch (e) {
      // Silently fail — repo row remains expanded but no children shown
    }
  },

  _toggleExpand(repoName) {
    if (this._expandedRepos.has(repoName)) {
      this._expandedRepos.delete(repoName);
      this._renderRepos(this._repos);
    } else {
      this._expandedRepos.add(repoName);
      if (this._branchCache[repoName]) {
        this._renderRepos(this._repos);
      } else {
        const repo = this._repos.find(r => (r.display_name || r.path) === repoName);
        this._loadBranches(repoName, repo ? repo.branch : '');
      }
    }
  },

  _toggleExpandAll() {
    if (this._expandedRepos.size > 0) {
      this._expandedRepos.clear();
      this._renderRepos(this._repos);
    } else {
      // Expand all — load branches for those not cached
      this._repos.forEach(repo => {
        const name = repo.display_name || repo.path;
        this._expandedRepos.add(name);
        if (!this._branchCache[name]) {
          this._loadBranches(name, repo.branch);
        }
      });
      this._renderRepos(this._repos);
    }
  },

  async _checkoutBranch(repoName, branchName) {
    const ok = await confirmModal(`Switch ${repoName} to branch "${branchName}"?`);
    if (!ok) return;
    try {
      await API.checkoutBranch(repoName, branchName, this._project());
      App.showToast(`Switched to ${branchName}`, 'success');
      // Update repo data and re-render
      const repos = await API.getRepos(this._project());
      this._repos = repos;
      this._renderRepos(repos);
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _switchAllModal() {
    try {
      const union = await API.getUnionBranches(this._project());
      if (!union.length) {
        App.showToast('No branches found', 'error');
        return;
      }

      const listHtml = union.map(b => {
        return `<div class="dash-action-item" data-branch="${esc(b.name)}" style="padding:6px 8px;cursor:pointer">
          <span style="flex:1">${esc(b.name)}</span>
          <span class="dash-act-desc">${b.count}/${b.total} repos</span>
        </div>`;
      }).join('');

      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">
        <div class="modal-header">
          <span>Switch All Repos</span>
          <button class="modal-close">\u00d7</button>
        </div>
        <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">
          ${listHtml}
        </div>
        <div class="modal-footer">
          <button class="btn modal-cancel-btn">Cancel</button>
        </div>
      </div>`;
      document.body.appendChild(overlay);

      const close = () => overlay.remove();
      overlay.querySelector('.modal-close').addEventListener('click', close);
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

      overlay.querySelectorAll('[data-branch]').forEach(item => {
        item.addEventListener('click', async () => {
          const branch = item.dataset.branch;
          close();
          const ok = await confirmModal(`Switch ALL repos to "${branch}"?`);
          if (!ok) return;
          try {
            const result = await API.branchAll(branch, this._project());
            const okCount = result.results.filter(r => r.status === 'ok' || r.status === 'already').length;
            const errCount = result.results.filter(r => r.status === 'error').length;
            App.showToast(`Switched: ${okCount} repos${errCount ? `, ${errCount} failed` : ''}`, errCount ? 'error' : 'success');
            const repos = await API.getRepos(this._project());
            this._repos = repos;
            this._renderRepos(repos);
          } catch (e) {
            App.showToast(e.message, 'error');
          }
        });
      });
    } catch (e) {
      App.showToast('Error loading branches: ' + e.message, 'error');
    }
  },

  handleKeyboard(e) {
    if (e.key === 'B') {
      e.preventDefault();
      this._switchAllModal();
      return;
    }

    if (e.key === '\\') {
      e.preventDefault();
      this._toggleExpandAll();
      return;
    }

    if (!this._rows.length) return;

    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      this._moveActive(1);
    } else if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      this._moveActive(-1);
    } else if (e.key === 'Home') {
      e.preventDefault();
      this._moveToIndex(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      this._moveToIndex(this._rows.length - 1);
    } else if (e.key === 'ArrowRight' || e.key === 'Enter') {
      e.preventDefault();
      if (this._activeRow >= 0) {
        const row = this._rows[this._activeRow];
        if (row.dataset.type === 'repo') {
          // Expand repo
          const name = row.dataset.repo;
          if (name && !this._expandedRepos.has(name)) {
            this._toggleExpand(name);
          }
        } else if (row.dataset.type === 'branch') {
          // Checkout this branch
          const repoName = row.dataset.parentRepo;
          const branchName = row.dataset.branch;
          if (repoName && branchName) {
            this._checkoutBranch(repoName, branchName);
          }
        }
      }
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      if (this._activeRow >= 0) {
        const row = this._rows[this._activeRow];
        if (row.dataset.type === 'branch') {
          // Collapse parent repo
          const parentName = row.dataset.parentRepo;
          if (parentName) {
            this._expandedRepos.delete(parentName);
            this._renderRepos(this._repos);
          }
        } else if (row.dataset.type === 'repo') {
          const name = row.dataset.repo;
          if (name && this._expandedRepos.has(name)) {
            this._expandedRepos.delete(name);
            this._renderRepos(this._repos);
          }
        }
      }
    }
  },

  _moveToIndex(idx) {
    if (idx < 0 || idx >= this._rows.length) return;
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    this._activeRow = idx;
    const row = this._rows[idx];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },

  _moveActive(delta) {
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    let next = this._activeRow + delta;
    if (next < 0) next = this._rows.length - 1;
    if (next >= this._rows.length) next = 0;
    this._activeRow = next;
    const row = this._rows[this._activeRow];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },
};
