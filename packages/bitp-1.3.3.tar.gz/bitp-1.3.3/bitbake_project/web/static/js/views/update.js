/* Update view — per-repo update controls with progress and smart skip
 *
 * Reads App.state.selectedProject for project context (set by dashboard).
 * Passes ?project= to API so no project activation is needed.
 */
const UpdateView = {
  _nav: KeyboardNav(),
  _project() { return App.state.selectedProject || ''; },

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Update repo', action: 'Enter'},
    {key: 'f', desc: 'Fetch repo', action: 'f'},
    {key: 'U', desc: 'Update all', action: 'U'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    var row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      var btn = row.querySelector('button[data-action="update"]');
      if (btn) btn.click();
    } else if (e.key === 'f' && row) {
      e.preventDefault();
      var btn = row.querySelector('button[data-action="fetch"]');
      if (btn) btn.click();
    } else if (e.key === 'U') {
      e.preventDefault();
      var btn = document.getElementById('update-all');
      if (btn) btn.click();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>Update</h2>
        <div class="btn-group">
          <button class="btn btn-primary" id="update-all">Update All</button>
          <button class="btn" id="update-fetch-all">Fetch All</button>
        </div>
      </div>
      <div id="update-progress" style="display:none">
        <div class="progress-bar"><div class="progress-bar-fill" id="update-progress-fill" style="width:0%"></div></div>
        <div id="update-progress-text" style="font-size:11px;color:var(--text-muted);margin-bottom:12px"></div>
      </div>
      <div id="update-repos" class="loading">Loading repos</div>
    `;

    document.getElementById('update-all').addEventListener('click', () => this._updateAll());

    document.getElementById('update-fetch-all').addEventListener('click', async () => {
      const btn = document.getElementById('update-fetch-all');
      btn.classList.add('loading');
      try { await API.refreshAll(); App.showToast('Fetching all repos...'); } catch (e) { App.showToast(e.message, 'error'); }
      btn.classList.remove('loading');
    });

    try {
      const repos = await API.getRepos(this._project());
      this._repos = repos;
      this._renderRepos(repos);
    } catch (e) {
      document.getElementById('update-repos').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  async _updateAll() {
    if (!this._repos) return;
    const updateBtn = document.getElementById('update-all');
    updateBtn.classList.add('loading');
    updateBtn.disabled = true;

    const progressEl = document.getElementById('update-progress');
    const progressFill = document.getElementById('update-progress-fill');
    const progressText = document.getElementById('update-progress-text');
    progressEl.style.display = 'block';

    // Filter: skip repos with skip action or already up-to-date
    const toUpdate = this._repos.filter(repo => {
      if (repo.default_action === 'skip') return false;
      // Include all non-skip repos (even if upstream_count == 0, fetch might reveal updates)
      return true;
    });

    let done = 0;
    const results = [];

    for (const repo of toUpdate) {
      const name = repo.display_name || repo.path;
      const sel = document.querySelector(`select[data-repo="${CSS.escape(name)}"]`);
      const action = sel ? sel.value : (repo.default_action || 'rebase');

      if (action === 'skip') {
        done++;
        continue;
      }

      progressText.textContent = `Updating ${name} (${done + 1}/${toUpdate.length})...`;
      progressFill.style.width = ((done / toUpdate.length) * 100) + '%';

      // Update status cell
      const statusCell = document.querySelector(`tr[data-repo="${CSS.escape(name)}"] .update-status`);
      if (statusCell) statusCell.innerHTML = '<span class="badge badge-loading">updating...</span>';

      try {
        await API.updateRepo(name, action, this._project());
        results.push({ name, status: 'ok' });
        if (statusCell) statusCell.innerHTML = '<span class="badge badge-clean">done</span>';
      } catch (e) {
        results.push({ name, status: 'error', error: e.message });
        if (statusCell) statusCell.innerHTML = `<span class="badge badge-dirty">error</span>`;
      }
      done++;
    }

    progressFill.style.width = '100%';
    const ok = results.filter(r => r.status === 'ok').length;
    const errors = results.filter(r => r.status === 'error').length;
    progressText.textContent = `Done: ${ok} updated${errors ? `, ${errors} failed` : ''}`;

    updateBtn.classList.remove('loading');
    updateBtn.disabled = false;
    App.showToast(`Update complete: ${ok} repos updated`, errors ? 'error' : 'success');
  },

  _renderRepos(repos) {
    const el = document.getElementById('update-repos');
    if (!repos.length) {
      el.innerHTML = '<div class="empty-state"><h3>No repos found</h3></div>';
      return;
    }

    el.innerHTML = `<table class="data-table" id="update-table">
      <thead><tr><th style="width:2ch"></th><th>Repo</th><th>Branch</th><th>Local</th><th>Upstream</th><th>Action</th><th>Status</th><th></th></tr></thead>
      <tbody>${repos.map(repo => {
        const name = repo.display_name || repo.path;
        const skip = repo.default_action === 'skip';
        const upToDate = !skip && repo.upstream_count === 0;
        return `<tr data-repo="${esc(name)}"${skip ? ' style="opacity:0.5"' : ''}>
          <td><span class="drag-handle">&#9776;</span></td>
          <td>${esc(name)}</td>
          <td>${esc(repo.branch)}</td>
          <td>${repo.local_count > 0 ? `<span class="badge badge-ahead">${repo.local_count}</span>` : '0'}</td>
          <td>${repo.upstream_count > 0 ? `<span class="badge badge-behind">${repo.upstream_count}</span>` : repo.upstream_count === -1 ? '<span class="badge badge-behind">?</span>' : '0'}</td>
          <td>
            <select class="form-select" data-repo="${esc(name)}" style="width:auto;padding:4px 8px">
              <option value="rebase"${repo.default_action === 'rebase' ? ' selected' : ''}>Rebase</option>
              <option value="merge"${repo.default_action === 'merge' ? ' selected' : ''}>Merge</option>
              <option value="skip"${repo.default_action === 'skip' ? ' selected' : ''}>Skip</option>
            </select>
          </td>
          <td class="update-status">${upToDate ? '<span style="color:var(--green)">\u2713 up to date</span>' : ''}</td>
          <td>
            <button class="btn" data-repo="${esc(name)}" data-action="fetch">Fetch</button>
            <button class="btn btn-primary" data-repo="${esc(name)}" data-action="update"${skip ? ' disabled' : ''}>Update</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;

    // Column resizer
    const table = document.getElementById('update-table');
    if (table) initColumnResizer(table, 'update');

    // Drag-and-drop reordering
    const tbody = table && table.querySelector('tbody');
    if (tbody) initViewSortable(tbody, 'bit-update-order', 'tr[data-repo]');

    // Reset order button
    let resetBtn = document.getElementById('view-reset-order');
    if (!resetBtn) {
      resetBtn = document.createElement('button');
      resetBtn.id = 'view-reset-order';
      resetBtn.className = 'btn dash-reset-order-fixed';
      resetBtn.title = 'Reset row order to default';
      resetBtn.textContent = 'Reset Order';
      document.body.appendChild(resetBtn);
    }
    resetBtn.style.display = '';
    resetBtn.onclick = () => {
      resetViewOrder('bit-update-order');
      this._renderRepos(this._repos);
    };

    // Keyboard nav
    this._nav.setRows(el.querySelectorAll('tr[data-repo]'));

    el.querySelectorAll('button[data-action]').forEach(btn => {
      btn.addEventListener('click', async () => {
        btn.classList.add('loading');
        btn.disabled = true;
        const statusCell = btn.closest('tr').querySelector('.update-status');
        try {
          if (btn.dataset.action === 'fetch') {
            await API.fetchRepo(btn.dataset.repo, this._project());
          } else {
            const sel = el.querySelector(`select[data-repo="${CSS.escape(btn.dataset.repo)}"]`);
            const action = sel ? sel.value : 'rebase';
            if (statusCell) statusCell.innerHTML = '<span class="badge badge-loading">updating...</span>';
            await API.updateRepo(btn.dataset.repo, action, this._project());
            if (statusCell) statusCell.innerHTML = '<span class="badge badge-clean">done</span>';
          }
          App.showToast(`Done: ${btn.dataset.repo}`, 'success');
        } catch (e) {
          App.showToast(e.message, 'error');
          if (statusCell) statusCell.innerHTML = `<span class="badge badge-dirty">error</span>`;
        }
        btn.classList.remove('loading');
        btn.disabled = false;
      });
    });
  },
};
