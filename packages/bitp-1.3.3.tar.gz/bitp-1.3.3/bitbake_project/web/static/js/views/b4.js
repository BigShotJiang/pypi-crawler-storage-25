/* B4/Lore view — unified search/browse with thread grouping, repo picker, mutt integration */
const B4View = {
  _nav: KeyboardNav(),
  _lists: null,
  _activeList: '',
  _mailReaderCache: null,  // {available, command} or null
  _threads: null,          // current thread-grouped results
  _lastResults: null,      // raw flat results from last query

  keyBindings: [
    {key: 'j/k', desc: 'Navigate threads'},
    {key: 'o/Enter', desc: 'Expand/collapse thread'},
    {key: 'v', desc: 'View message body'},
    {key: 'a', desc: 'Apply patch'},
    {key: 'm', desc: 'Download mbox'},
    {key: 't', desc: 'Trailers'},
    {key: 'c', desc: 'Check newer'},
    {key: 'd', desc: 'Diff versions'},
    {key: 'p', desc: 'Fetch PR'},
    {key: 'y', desc: 'Copy message-id'},
    {key: '/', desc: 'Search'},
    {key: 'l', desc: 'Focus list picker'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    var row = this._nav.activeRow();
    if ((e.key === 'o' || e.key === 'Enter' || e.key === 'ArrowRight') && row) {
      e.preventDefault();
      if (row.classList.contains('thread-root')) {
        this._toggleThread(row, true);
      } else {
        this._toggleDetail(row);
      }
    } else if (e.key === 'ArrowLeft' && row) {
      e.preventDefault();
      if (row.classList.contains('thread-root')) {
        this._toggleThread(row, false);
      }
    } else if (e.key === 'v' && row) {
      e.preventDefault();
      this._toggleDetail(row);
    } else if (e.key === 'a' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-apply');
      if (btn) btn.click();
    } else if (e.key === 'd' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-diff');
      if (btn) btn.click();
    } else if (e.key === 'm' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-mbox');
      if (btn) btn.click();
    } else if (e.key === 't' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-trailers');
      if (btn) btn.click();
    } else if (e.key === 'c' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-check-newer');
      if (btn) btn.click();
    } else if (e.key === 'p' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-pr');
      if (btn) btn.click();
    } else if (e.key === 'y' && row) {
      e.preventDefault();
      var btn = row.querySelector('.b4-copy-msgid');
      if (btn) btn.click();
    } else if (e.key === '/') {
      e.preventDefault();
      var input = document.getElementById('b4-search');
      if (input) input.focus();
    } else if (e.key === 'l') {
      e.preventDefault();
      var sel = document.getElementById('b4-list');
      if (sel) sel.focus();
    }
  },

  async render(container, state) {
    var favLists = loadPreference('b4-favorites', []);

    container.innerHTML = `
      <div class="view-header">
        <h2>B4 / Lore</h2>
        <div id="b4-favorites" class="b4-pills" style="display:flex;gap:6px;flex-wrap:wrap"></div>
      </div>
      <div id="b4-status-banner" style="display:none"></div>
      <div id="b4-results" class="empty-state" style="flex:1;overflow:auto"><h3>Enter a search term or select a list to browse</h3></div>
      <div class="recipes-footer">
        <div class="recipes-footer-left">
          <input type="text" id="b4-search" placeholder="Search lore.kernel.org..." style="max-width:300px">
          <div id="b4-list-wrap" style="position:relative;flex-shrink:0">
            <input type="text" id="b4-list-filter" class="input" placeholder="Filter lists..." style="width:100%;display:none">
            <select id="b4-list" class="input" style="max-width:220px"><option value="">All lists</option></select>
          </div>
          <button class="btn btn-primary" id="b4-go">Go</button>
          <button class="btn btn-sm" id="b4-add-list" title="Add custom mailing list" style="padding:2px 6px">+</button>
        </div>
        <div class="recipes-footer-right">
          <span style="display:flex;gap:2px">
            <button class="btn btn-sm b4-range-btn" data-range="1.week.ago..">1w</button>
            <button class="btn btn-sm b4-range-btn" data-range="1.month.ago..">1m</button>
            <button class="btn btn-sm b4-range-btn" data-range="3.months.ago..">3m</button>
            <button class="btn btn-sm b4-range-btn" data-range="1.year.ago..">1y</button>
            <button class="btn btn-sm b4-range-btn active" data-range="2.years.ago..">2y</button>
          </span>
          <label style="display:flex;align-items:center;gap:4px;color:var(--text-muted);font-size:var(--font-size-sm)">
            <input type="checkbox" id="b4-threads"> Threads
          </label>
          <select id="b4-type" class="input" style="max-width:100px;font-size:var(--font-size-sm)">
            <option value="subject">Subject</option>
            <option value="body">Body</option>
            <option value="all">All</option>
          </select>
          <span style="display:flex;gap:1px;margin-left:4px">
            <button class="btn btn-sm b4-font-btn" id="b4-font-down" title="Decrease font size">A-</button>
            <button class="btn btn-sm b4-font-btn" id="b4-font-up" title="Increase font size">A+</button>
          </span>
        </div>
      </div>
    `;

    // Font size control
    var b4FontSize = loadPreference('b4-font-size', 11);
    this._applyFontSize(b4FontSize);
    document.getElementById('b4-font-down').addEventListener('click', () => {
      b4FontSize = Math.max(9, b4FontSize - 1);
      savePreference('b4-font-size', b4FontSize);
      this._applyFontSize(b4FontSize);
    });
    document.getElementById('b4-font-up').addEventListener('click', () => {
      b4FontSize = Math.min(16, b4FontSize + 1);
      savePreference('b4-font-size', b4FontSize);
      this._applyFontSize(b4FontSize);
    });

    // Range toggle buttons
    container.querySelectorAll('.b4-range-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.b4-range-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // Go button / Enter
    var doQuery = () => this._doQuery();
    document.getElementById('b4-go').addEventListener('click', doQuery);
    document.getElementById('b4-search').addEventListener('keydown', e => { if (e.key === 'Enter') doQuery(); });

    // List change → browse if no search query
    document.getElementById('b4-list').addEventListener('change', () => {
      var q = document.getElementById('b4-search').value.trim();
      if (!q) this._doQuery();
    });

    this._loadLists();
    this._renderFavorites(favLists);
    this._detectMailReader();

    // Add custom list button
    document.getElementById('b4-add-list').addEventListener('click', () => this._showAddListDialog());

    // Cross-view lore search: pre-fill from patches view
    if (App.state.b4SearchQuery) {
      document.getElementById('b4-search').value = App.state.b4SearchQuery;
      App.state.b4SearchQuery = null;
      this._doQuery();
    }
  },

  async _loadLists() {
    try {
      this._lists = await API.b4Lists();
      var opts = this._lists.map(l => {
        var prefix = l.custom ? '\u2605 ' : '';
        return `<option value="${esc(l.lore_name)}">${prefix}${esc(l.lore_name)}${l.description ? ' \u2014 ' + esc(l.description) : ''}</option>`;
      }).join('');
      document.getElementById('b4-list').innerHTML = '<option value="">All lists</option>' + opts;

      // Set up list filter
      var sel = document.getElementById('b4-list');
      var filterInput = document.getElementById('b4-list-filter');
      sel.addEventListener('focus', () => {
        if (this._lists && this._lists.length > 20) {
          filterInput.style.display = '';
          filterInput.value = '';
          filterInput.focus();
        }
      });
      filterInput.addEventListener('input', () => {
        var term = filterInput.value.toLowerCase();
        var filtered = this._lists.filter(l =>
          l.lore_name.toLowerCase().includes(term) ||
          (l.description && l.description.toLowerCase().includes(term))
        );
        sel.innerHTML = '<option value="">All lists</option>' + filtered.map(l =>
          `<option value="${esc(l.lore_name)}">${esc(l.lore_name)}${l.description ? ' \u2014 ' + esc(l.description) : ''}</option>`
        ).join('');
      });
      filterInput.addEventListener('blur', () => {
        setTimeout(() => { filterInput.style.display = 'none'; }, 200);
      });
      filterInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          filterInput.style.display = 'none';
          sel.focus();
        } else if (e.key === 'Enter') {
          filterInput.style.display = 'none';
          if (sel.options.length > 1) sel.selectedIndex = 1;
          sel.dispatchEvent(new Event('change'));
        }
      });

      // Default favorites if none saved
      var favs = loadPreference('b4-favorites', []);
      if (!favs.length && this._lists.length) {
        var knownNames = this._lists.filter(l => l.address).slice(0, 3).map(l => l.lore_name);
        if (knownNames.length) {
          savePreference('b4-favorites', knownNames);
          this._renderFavorites(knownNames);
        }
      }
    } catch (e) {
      // Non-critical
    }
  },

  _renderFavorites(favs) {
    var el = document.getElementById('b4-favorites');
    if (!el) return;
    if (!favs || !favs.length) { el.style.display = 'none'; return; }
    el.style.display = '';
    el.innerHTML = favs.map(name =>
      `<button class="btn btn-sm b4-fav-pill" data-list="${esc(name)}" title="Browse ${esc(name)}">${esc(name)}</button>`
    ).join('') + ' <button class="btn btn-sm b4-fav-manage" title="Manage favorites" style="opacity:0.5">+</button>';

    el.querySelectorAll('.b4-fav-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        var sel = document.getElementById('b4-list');
        if (sel) {
          sel.value = btn.dataset.list;
          document.getElementById('b4-search').value = '';
          this._doQuery();
        }
      });
    });

    var manageBtn = el.querySelector('.b4-fav-manage');
    if (manageBtn) {
      manageBtn.addEventListener('click', () => this._manageFavorites());
    }
  },

  _manageFavorites() {
    var favs = loadPreference('b4-favorites', []);
    var sel = document.getElementById('b4-list');
    var currentList = sel ? sel.value : '';
    if (currentList && !favs.includes(currentList)) {
      favs.push(currentList);
      savePreference('b4-favorites', favs);
      this._renderFavorites(favs);
      App.showToast('Added ' + currentList + ' to favorites', 'success');
    } else if (currentList && favs.includes(currentList)) {
      favs = favs.filter(f => f !== currentList);
      savePreference('b4-favorites', favs);
      this._renderFavorites(favs);
      App.showToast('Removed ' + currentList + ' from favorites', 'success');
    } else {
      App.showToast('Select a list first', 'info');
    }
  },

  _showAddListDialog() {
    // Show existing custom lists + add form
    var customLists = (this._lists || []).filter(l => l.custom);

    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:1000';

    var modal = document.createElement('div');
    modal.style.cssText = 'background:var(--bg-primary);border:1px solid var(--border);border-radius:8px;padding:20px;min-width:450px;max-width:600px;max-height:80vh;overflow:auto';

    var existingRows = customLists.map(l =>
      `<div class="b4-custom-row" style="display:flex;align-items:center;gap:8px;padding:4px 0;border-bottom:1px solid var(--border)">
        <span style="flex:1"><strong>${esc(l.lore_name)}</strong>
          <span style="color:var(--text-muted);font-size:var(--font-size-sm)">${l.base_url ? ' @ ' + esc(l.base_url) : ''}</span>
          ${l.description ? '<br><span style="color:var(--text-muted);font-size:var(--font-size-sm)">' + esc(l.description) + '</span>' : ''}
        </span>
        <button class="btn btn-sm b4-del-custom" data-name="${esc(l.lore_name)}" style="color:var(--error)" title="Remove">×</button>
      </div>`
    ).join('');

    modal.innerHTML = `
      <h3 style="margin-top:0">Custom Mailing Lists</h3>
      ${existingRows ? '<div style="margin-bottom:12px">' + existingRows + '</div>' : ''}
      <div style="display:flex;flex-direction:column;gap:8px">
        <label style="font-size:var(--font-size-sm);font-weight:600">Add new list</label>
        <input type="text" class="input" id="b4-custom-name" placeholder="Archive name (e.g. my-project-devel)" style="width:100%">
        <input type="text" class="input" id="b4-custom-desc" placeholder="Description (optional)" style="width:100%">
        <input type="text" class="input" id="b4-custom-url" placeholder="Server URL (default: https://lore.kernel.org)" style="width:100%">
        <input type="text" class="input" id="b4-custom-addr" placeholder="Email address (optional)" style="width:100%">
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
        <button class="btn" id="b4-custom-cancel">Cancel</button>
        <button class="btn btn-primary" id="b4-custom-save">Add</button>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    modal.querySelector('#b4-custom-cancel').addEventListener('click', () => overlay.remove());

    // Delete existing custom lists
    modal.querySelectorAll('.b4-del-custom').forEach(btn => {
      btn.addEventListener('click', async () => {
        try {
          await API.b4DeleteCustomList(btn.dataset.name);
          btn.closest('.b4-custom-row').remove();
          await this._loadLists();
          App.showToast('Removed ' + btn.dataset.name, 'success');
        } catch (e) { App.showToast(e.message, 'error'); }
      });
    });

    // Save new custom list
    modal.querySelector('#b4-custom-save').addEventListener('click', async () => {
      var name = modal.querySelector('#b4-custom-name').value.trim();
      if (!name) { App.showToast('Archive name is required', 'error'); return; }
      try {
        await API.b4SaveCustomList({
          lore_name: name,
          description: modal.querySelector('#b4-custom-desc').value.trim(),
          base_url: modal.querySelector('#b4-custom-url').value.trim(),
          address: modal.querySelector('#b4-custom-addr').value.trim(),
        });
        overlay.remove();
        await this._loadLists();
        // Select the new list
        var sel = document.getElementById('b4-list');
        if (sel) sel.value = name;
        App.showToast('Added ' + name, 'success');
      } catch (e) { App.showToast(e.message, 'error'); }
    });

    // Escape to close
    var handleEsc = (e) => { if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', handleEsc); } };
    document.addEventListener('keydown', handleEsc);

    // Focus the name input
    setTimeout(() => modal.querySelector('#b4-custom-name').focus(), 50);
  },

  async _detectMailReader() {
    if (this._mailReaderCache !== null) return;
    try {
      this._mailReaderCache = await API.b4MailReader();
    } catch (e) {
      this._mailReaderCache = {available: false, command: ''};
    }
  },

  async _doQuery() {
    var q = document.getElementById('b4-search').value.trim();
    var list = document.getElementById('b4-list').value;
    var el = document.getElementById('b4-results');
    this._activeList = list || '';

    if (!q && !list) return;

    el.className = 'loading';
    el.textContent = q ? 'Searching lore...' : 'Loading recent messages...';

    try {
      var data;
      if (q) {
        // Search mode
        var opts = {grouped: true};
        if (list) opts.list = list;
        var type = document.getElementById('b4-type').value;
        if (type && type !== 'subject') opts.type = type;
        var rangeBtn = document.querySelector('.b4-range-btn.active');
        var range = rangeBtn ? rangeBtn.dataset.range : '2.years.ago..';
        if (range !== '2.years.ago..') opts.range = range;
        if (document.getElementById('b4-threads').checked) opts.threads = true;
        data = await API.b4Search(q, opts);
      } else {
        // Browse mode — list selected, no query
        var rangeBtn = document.querySelector('.b4-range-btn.active');
        var rangeDays = {'1.week.ago..': 7, '1.month.ago..': 30, '3.months.ago..': 90, '1.year.ago..': 365, '2.years.ago..': 14};
        var days = rangeDays[rangeBtn ? rangeBtn.dataset.range : '2.years.ago..'] || 14;
        data = await API.b4Browse(list, days, true);
      }

      if (data && data.threads) {
        this._threads = data.threads;
        this._lastResults = data.flat;
        this._renderThreadedResults(data.threads);
      } else if (Array.isArray(data)) {
        this._threads = null;
        this._lastResults = data;
        this._renderFlatResults(data);
      } else {
        el.className = '';
        el.innerHTML = '<div class="empty-state"><h3>No results</h3></div>';
      }
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _applyFontSize(px) {
    var el = document.getElementById('b4-results');
    if (el) el.style.setProperty('--b4-font-size', px + 'px');
  },

  _detailRow(forKey, content) {
    var text = content ? esc(content) : 'Click to load message body...';
    return `<tr class="b4-detail" data-for="${esc(forKey)}" style="display:none">
      <td colspan="4" style="padding:0">
        <pre class="b4-body" style="margin:0;padding:12px 16px;background:var(--bg-secondary);border-top:1px solid var(--border);white-space:pre-wrap;word-break:break-word;font-size:var(--font-size-sm);max-height:400px;overflow:auto">${text}</pre>
      </td>
    </tr>`;
  },

  _renderThreadedResults(threads) {
    var el = document.getElementById('b4-results');
    if (!threads || !threads.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No results</h3></div>';
      return;
    }

    el.className = '';
    var rows = [];
    threads.forEach((t, ti) => {
      var root = t.root;
      var hasChildren = t.children && t.children.length > 0;
      // Thread with children: expand triangle; standalone message: envelope icon (click for body)
      var toggle = hasChildren
        ? '<span class="thread-toggle" style="cursor:pointer;margin-right:12px;padding:2px 4px;font-family:var(--font-mono);font-size:var(--font-size-sm)">&#9654;</span>'
        : '<span class="b4-body-icon" style="cursor:pointer;margin-right:12px;padding:2px 4px;opacity:0.5" title="View message body">&#9776;</span>';
      var badge = this._seriesBadge(t);
      var msgid = root.msgid || '';
      var url = root.url || '';

      var subjectTags = JSON.stringify(t.subject_tags || []).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
      rows.push(`<tr class="thread-root" data-thread="${ti}" data-msgid="${esc(msgid)}" data-url="${esc(url)}" data-subject-tags="${subjectTags}" style="cursor:pointer">
        <td>${toggle}${badge}${esc(root.subject || '')}</td>
        <td style="color:var(--text-muted)">${esc(root.author || '')}</td>
        <td style="color:var(--text-muted);white-space:nowrap">${esc(root.date || '')}</td>
        <td style="white-space:nowrap">${this._actionButtons(msgid)}</td>
      </tr>`);
      rows.push(this._detailRow('root-' + ti));

      if (hasChildren) {
        var childCount = t.children.length;
        t.children.forEach((c, ci) => {
          var cmsgid = c.msgid || '';
          var curl = c.url || '';
          var isLast = ci === childCount - 1;
          var connector = isLast ? '\u2514\u2500 ' : '\u251c\u2500 ';
          var isReply = /^(Re|Fwd):/i.test(c.subject || '');
          var subjectColor = isReply ? 'color:var(--text-muted)' : 'color:var(--accent, #60a5fa)';
          rows.push(`<tr class="thread-child" data-thread="${ti}" data-child="${ci}" data-msgid="${esc(cmsgid)}" data-url="${esc(curl)}" style="display:none;cursor:pointer">
            <td><span style="color:var(--text-muted);margin-left:16px;font-family:var(--font-mono)">${connector}</span><span style="${subjectColor}">${esc(c.subject || '')}</span></td>
            <td style="color:var(--text-muted)">${esc(c.author || '')}</td>
            <td style="color:var(--text-muted);white-space:nowrap">${esc(c.date || '')}</td>
            <td style="white-space:nowrap">${this._actionButtons(cmsgid)}</td>
          </tr>`);
          rows.push(this._detailRow('child-' + ti + '-' + ci));
        });
      }
    });

    el.innerHTML = `<table class="data-table">
      <thead><tr><th>Subject</th><th>From</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>${rows.join('')}</tbody>
    </table>`;

    // Keyboard nav — thread roots + visible children, skip detail rows
    this._updateNavRows(el);

    // Thread root click → expand/collapse
    el.querySelectorAll('.thread-root').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        if (e.target.closest('.thread-toggle')) {
          this._toggleThread(row);
          return;
        }
        this._toggleDetail(row);
      });
    });

    // Child row click → detail
    el.querySelectorAll('.thread-child').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        this._toggleDetail(row);
      });
    });

    this._bindActionButtons(el);
  },

  _renderFlatResults(results) {
    var el = document.getElementById('b4-results');
    if (!results || !results.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No results</h3></div>';
      return;
    }

    el.className = '';
    el.innerHTML = `<table class="data-table">
      <thead><tr><th>Subject</th><th>From</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>${results.map((r, i) => {
        var msgid = r.msgid || '';
        var url = r.url || '';
        return `<tr data-idx="${i}" data-msgid="${esc(msgid)}" data-url="${esc(url)}" style="cursor:pointer">
          <td>${esc(r.subject || '')}</td>
          <td style="color:var(--text-muted)">${esc(r.author || '')}</td>
          <td style="color:var(--text-muted);white-space:nowrap">${esc(r.date || '')}</td>
          <td style="white-space:nowrap">${this._actionButtons(msgid)}</td>
        </tr>
        ${this._detailRow('flat-' + i, r.content)}`;
      }).join('')}</tbody>
    </table>`;

    this._nav.setRows(el.querySelectorAll('tbody tr:not(.b4-detail)'));

    el.querySelectorAll('tr[data-idx]').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target.closest('button')) return;
        this._toggleDetail(row);
      });
    });

    this._bindActionButtons(el);
  },

  _actionButtons(msgid) {
    return `<button class="btn btn-primary b4-apply" data-msgid="${esc(msgid)}" title="Apply patch series (b4 shazam)">Apply</button>`
      + `<button class="btn b4-mbox" data-msgid="${esc(msgid)}" title="Download thread as mbox">Mbox</button>`
      + `<button class="btn b4-more-toggle" data-msgid="${esc(msgid)}" title="More actions..." style="padding:2px 6px;min-width:0">\u22ef</button>`
      + `<span class="b4-more-actions" style="display:none">`
      + `<button class="btn b4-pr" data-msgid="${esc(msgid)}" title="Fetch pull request (b4 pr)">PR</button>`
      + `<button class="btn b4-trailers" data-msgid="${esc(msgid)}" title="Show collected trailers (Reviewed-by, Acked-by)">Trailers</button>`
      + `<button class="btn b4-check-newer" data-msgid="${esc(msgid)}" title="Check for newer version of this series">Check</button>`
      + `<button class="btn b4-diff" data-msgid="${esc(msgid)}" title="Compare with another series version">Diff</button>`
      + `<button class="btn b4-copy-msgid" data-msgid="${esc(msgid)}" title="Copy message-id to clipboard">Copy</button>`
      + `</span>`;
  },

  _seriesBadge(thread) {
    if (!thread.series_tag) return '';
    var complete = thread.total_parts && thread.received_parts >= thread.total_parts;
    var color = complete ? 'var(--success, #22c55e)' : 'var(--warning, #eab308)';
    var label = '';
    if (thread.version) label += 'v' + thread.version + ' ';
    if (thread.total_parts) {
      label += 'series ' + (thread.received_parts || 0) + '/' + thread.total_parts;
    }
    if (!label) return '';
    return `<span class="b4-series-badge" style="display:inline-block;padding:1px 6px;border-radius:9px;font-size:11px;font-weight:600;background:${color};color:#000;margin-right:6px">${esc(label.trim())}</span>`;
  },

  _updateNavRows(el) {
    // Only include visible non-detail rows
    var visibleRows = el.querySelectorAll('tbody tr.thread-root, tbody tr.thread-child:not([style*="display:none"]):not([style*="display: none"]), tbody tr[data-idx]');
    this._nav.setRows(visibleRows);
  },

  _toggleThread(row, forceExpand) {
    var ti = row.dataset.thread;
    var el = document.getElementById('b4-results');
    var children = el.querySelectorAll(`.thread-child[data-thread="${ti}"]`);
    if (!children.length) return;

    var isExpanded = row.classList.contains('thread-expanded');
    var expand = forceExpand !== undefined ? forceExpand : !isExpanded;

    var toggle = row.querySelector('.thread-toggle');
    if (expand) {
      row.classList.add('thread-expanded');
      if (toggle) toggle.innerHTML = '&#9660;';
      children.forEach(c => { c.style.display = ''; });
    } else {
      row.classList.remove('thread-expanded');
      if (toggle) toggle.innerHTML = '&#9654;';
      children.forEach(c => {
        c.style.display = 'none';
        // Also hide any open detail rows for children
        var detailFor = c.dataset.thread + '-' + c.dataset.child;
        var detail = el.querySelector(`.b4-detail[data-for="child-${detailFor}"]`);
        if (detail) detail.style.display = 'none';
      });
    }

    this._updateNavRows(el);
  },

  _getSubjectTags(el, btn) {
    // Get subject_tags from the thread root row for this button
    var row = btn.closest('tr');
    if (!row) return [];
    var tagsStr = row.dataset.subjectTags;
    if (!tagsStr) {
      // Child row — look up the thread root
      var ti = row.dataset.thread;
      if (ti != null) {
        var rootRow = el.querySelector('.thread-root[data-thread="' + ti + '"]');
        if (rootRow) tagsStr = rootRow.dataset.subjectTags;
      }
    }
    try { return tagsStr ? JSON.parse(tagsStr) : []; } catch (_) { return []; }
  },

  _matchBranch(subjectTags, branches) {
    // Match subject tags against repo branches (case-insensitive)
    if (!subjectTags || !subjectTags.length || !branches || !branches.length) return '';
    var branchMap = {};
    branches.forEach(b => { branchMap[b.toLowerCase()] = b; });
    for (var i = 0; i < subjectTags.length; i++) {
      var match = branchMap[subjectTags[i].toLowerCase()];
      if (match) return match;
    }
    return '';
  },

  _bindActionButtons(el) {
    // More toggle buttons (show/hide extra actions)
    el.querySelectorAll('.b4-more-toggle').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        var moreSpan = btn.nextElementSibling;
        if (moreSpan && moreSpan.classList.contains('b4-more-actions')) {
          var show = moreSpan.style.display === 'none';
          moreSpan.style.display = show ? 'inline' : 'none';
          btn.style.opacity = show ? '0.5' : '';
        }
      });
    });

    // Apply buttons
    el.querySelectorAll('.b4-apply').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        var subjectTags = this._getSubjectTags(el, btn);
        await this._applyWithRepoPicker(btn.dataset.msgid, subjectTags);
      });
    });

    // Diff buttons
    el.querySelectorAll('.b4-diff').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Diffing: ${btn.dataset.msgid}`);
        try {
          await API.b4Diff(btn.dataset.msgid);
          App.showToast('Diff started \u2014 see terminal', 'success');
        } catch (err) {
          App.showToast(err.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Mbox buttons
    el.querySelectorAll('.b4-mbox').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Downloading mbox: ${btn.dataset.msgid}`);

        var subjectTags = this._getSubjectTags(el, btn);

        try {
          // Pre-resolve the target repo so mutt shell drops into it
          var repoPath = '';
          var matchedBranch = '';
          try {
            var repoData = await API.b4Repos(this._activeList);
            if (repoData.repos && repoData.repos.length > 0) {
              var saved = loadPreference('b4-last-repo-' + this._activeList);
              var matchRepo = saved && repoData.repos.find(r => r.path === saved);
              var selectedRepo = matchRepo
                || (repoData.auto_selected && repoData.repos.find(r => r.path === repoData.auto_selected))
                || repoData.repos[0];
              if (selectedRepo) {
                repoPath = selectedRepo.path;
                matchedBranch = this._matchBranch(subjectTags, selectedRepo.branches);
              }
            }
          } catch (_) {}

          // Register callback to detect mbox completion + offer mutt
          App.onNextCommandDone((data) => {
            if (data.exitcode === 0 && data.mbox_path && this._mailReaderCache && this._mailReaderCache.available) {
              App.showToast('Open in ' + this._mailReaderCache.command, 'success', {
                action: 'Open',
                onAction: () => {
                  var msgid = btn.dataset.msgid || '';
                  var cdCmd = repoPath ? 'cd ' + repoPath.replace(/'/g, "'\\''") + ' ; ' : '';
                  var branchNote = matchedBranch ? ' (on branch ' + matchedBranch + ')' : '';
                  var checkoutCmd = matchedBranch
                    ? 'echo "Switching to branch ' + matchedBranch + '..." ; git checkout ' + matchedBranch.replace(/'/g, "'\\''") + ' 2>/dev/null || git checkout --track origin/' + matchedBranch.replace(/'/g, "'\\''") + ' ; '
                    : '';
                  var shellCmd = this._mailReaderCache.command + ' -f ' + data.mbox_path
                    + ' ; echo "" ; echo "To apply this series to a git tree' + branchNote + ':" ;'
                    + ' echo "  b4 shazam ' + msgid.replace(/'/g, "'\\''") + '" ;'
                    + ' echo "" ; ' + cdCmd + checkoutCmd + 'exec $SHELL';
                  TerminalManager.show({
                    cmd: shellCmd,
                    title: 'Mail: ' + msgid.substring(0, 30),
                  });
                }
              });
            }
          });
          await API.b4Mbox(btn.dataset.msgid, '', this._activeList);
          App.showToast('Mbox download started \u2014 see terminal', 'success');
        } catch (err) {
          App.showToast(err.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // PR buttons (fetch pull request)
    el.querySelectorAll('.b4-pr').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Fetching PR: ${btn.dataset.msgid}`);
        try {
          await API.b4Pr(btn.dataset.msgid, '', this._activeList);
          App.showToast('PR fetch started \u2014 see terminal', 'success');
        } catch (err) {
          App.showToast(err.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Trailers buttons
    el.querySelectorAll('.b4-trailers').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Collecting trailers: ${btn.dataset.msgid}`);
        try {
          await API.b4Trailers(btn.dataset.msgid, '', this._activeList);
          App.showToast('Trailers started \u2014 see terminal', 'success');
        } catch (err) {
          App.showToast(err.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Check newer version buttons
    el.querySelectorAll('.b4-check-newer').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Checking for newer version: ${btn.dataset.msgid}`);
        try {
          await API.b4CheckNewer(btn.dataset.msgid);
          App.showToast('Check started \u2014 see terminal', 'success');
        } catch (err) {
          App.showToast(err.message, 'error');
        }
        btn.disabled = false;
      });
    });

    // Copy message-id buttons
    el.querySelectorAll('.b4-copy-msgid').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        var msgid = btn.dataset.msgid || '';
        try {
          await navigator.clipboard.writeText(msgid);
          App.showToast('Copied: ' + msgid, 'success');
        } catch (_) {
          // Fallback for non-HTTPS contexts
          var ta = document.createElement('textarea');
          ta.value = msgid;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
          App.showToast('Copied: ' + msgid, 'success');
        }
      });
    });
  },

  async _applyWithRepoPicker(msgid, subjectTags) {
    subjectTags = subjectTags || [];
    // Check if there are multiple repos; if so, show picker
    try {
      var repoData = await API.b4Repos(this._activeList);
      if (!repoData.repos || repoData.repos.length === 0) {
        this._doApply(msgid, '', '');
        return;
      }
      if (repoData.repos.length === 1) {
        var repo = repoData.repos[0];
        var branch = this._matchBranch(subjectTags, repo.branches);
        this._doApply(msgid, repo.path, branch);
        return;
      }
      // Multiple repos — show picker modal
      this._showRepoPicker(msgid, repoData.repos, repoData.auto_selected, subjectTags);
    } catch (e) {
      this._doApply(msgid, '', '');
    }
  },

  _showRepoPicker(msgid, repos, autoSelected, subjectTags) {
    subjectTags = subjectTags || [];
    // Remember last used repo per list
    var lastRepo = loadPreference('b4-last-repo-' + this._activeList, '');
    var defaultRepo = lastRepo || autoSelected || (repos[0] ? repos[0].path : '');

    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;z-index:1000';

    var modal = document.createElement('div');
    modal.style.cssText = 'background:var(--bg-primary);border:1px solid var(--border);border-radius:8px;padding:20px;min-width:400px;max-width:600px;max-height:80vh;overflow:auto';

    var self = this;
    var repoRows = repos.map((r, i) => {
      var checked = r.path === defaultRepo ? 'checked' : '';
      // Match subject tags against this repo's branches
      var matchedBranch = self._matchBranch(subjectTags, r.branches);
      var branchOpts = (r.branches || []).map(b => {
        var sel = matchedBranch && b === matchedBranch ? 'selected'
          : (!matchedBranch && b === r.current_branch ? 'selected' : '');
        return `<option value="${esc(b)}" ${sel}>${esc(b)}</option>`;
      }).join('');
      return `<label style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border)">
        <input type="radio" name="b4-repo" value="${esc(r.path)}" ${checked}>
        <span style="flex:1">
          <strong>${esc(r.name)}</strong>
          <span style="color:var(--text-muted);font-size:var(--font-size-sm)"> (${esc(r.current_branch || 'no branch')})</span>
        </span>
        <select class="input b4-branch-sel" data-repo="${esc(r.path)}" style="max-width:160px;font-size:var(--font-size-sm)">${branchOpts}</select>
      </label>`;
    }).join('');

    modal.innerHTML = `
      <h3 style="margin-top:0">Select Repository</h3>
      <div style="margin:12px 0">${repoRows}</div>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button class="btn" id="b4-repo-cancel">Cancel</button>
        <button class="btn btn-primary" id="b4-repo-confirm">Apply</button>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });
    modal.querySelector('#b4-repo-cancel').addEventListener('click', () => overlay.remove());
    modal.querySelector('#b4-repo-confirm').addEventListener('click', () => {
      var selected = modal.querySelector('input[name="b4-repo"]:checked');
      if (!selected) return;
      var repo = selected.value;
      var branchSel = modal.querySelector(`.b4-branch-sel[data-repo="${CSS.escape(repo)}"]`);
      var branch = branchSel ? branchSel.value : '';
      savePreference('b4-last-repo-' + this._activeList, repo);
      overlay.remove();
      this._doApply(msgid, repo, branch);
    });

    // Escape to close
    var handleEsc = (e) => {
      if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', handleEsc); }
    };
    document.addEventListener('keydown', handleEsc);
  },

  async _doApply(msgid, repo, branch) {
    App.clearTerminal();
    App.showTerminal(`Applying: ${msgid}`);

    // Register callback for apply result banner
    App.onNextCommandDone((data) => {
      this._showApplyBanner(data);
    });

    try {
      await API.b4Apply(msgid, repo, this._activeList, branch);
      App.showToast('Apply started \u2014 see terminal', 'success');
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  _showApplyBanner(data) {
    var banner = document.getElementById('b4-status-banner');
    if (!banner) return;
    banner.style.display = '';
    if (data.exitcode === 0) {
      var msg = 'Applied';
      if (data.commits_applied) msg += ' ' + data.commits_applied + ' patch' + (data.commits_applied > 1 ? 'es' : '');
      if (data.repo) msg += ' to ' + data.repo;
      if (data.branch) msg += '/' + data.branch;
      banner.style.cssText = 'display:block;padding:8px 16px;margin-top:8px;border-radius:6px;background:var(--success-bg, #dcfce7);color:var(--success, #166534);border:1px solid var(--success, #22c55e)';
      banner.textContent = msg;
    } else {
      banner.style.cssText = 'display:block;padding:8px 16px;margin-top:8px;border-radius:6px;background:var(--error-bg, #fef2f2);color:var(--error, #991b1b);border:1px solid var(--error, #ef4444)';
      banner.textContent = 'Apply failed \u2014 see terminal output';
    }
    setTimeout(() => { banner.style.display = 'none'; }, 10000);
  },

  async _toggleDetail(row) {
    // Determine the detail row's data-for key
    var forKey;
    if (row.classList.contains('thread-root')) {
      forKey = 'root-' + row.dataset.thread;
    } else if (row.classList.contains('thread-child')) {
      forKey = 'child-' + row.dataset.thread + '-' + row.dataset.child;
    } else if (row.dataset.idx !== undefined) {
      forKey = 'flat-' + row.dataset.idx;
    } else {
      return;
    }

    var detailRow = row.parentElement.querySelector(`.b4-detail[data-for="${forKey}"]`);
    if (!detailRow) return;

    var isVisible = detailRow.style.display !== 'none';
    if (isVisible) {
      detailRow.style.display = 'none';
      return;
    }

    detailRow.style.display = '';
    var body = detailRow.querySelector('.b4-body');
    if (body.dataset.loaded) return;

    var msgid = row.dataset.msgid;
    var url = row.dataset.url;
    body.textContent = 'Loading message...';
    try {
      var msg = await API.b4Message(msgid, url);
      var text = '';
      if (msg.headers) {
        var hdrOrder = ['From', 'To', 'Cc', 'Subject', 'Date', 'Message-Id', 'In-Reply-To', 'List-Id'];
        hdrOrder.forEach(h => {
          if (msg.headers[h]) text += h + ': ' + msg.headers[h] + '\n';
        });
        text += '\n';
      }
      text += msg.body || '(no body)';
      body.textContent = text;
      body.dataset.loaded = '1';
    } catch (e) {
      body.textContent = 'Failed to load message: ' + e.message;
    }
  },

};
