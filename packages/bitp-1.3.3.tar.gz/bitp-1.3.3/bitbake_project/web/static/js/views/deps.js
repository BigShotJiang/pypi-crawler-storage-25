/* Dependencies view — layer dependency tree */
const DepsView = {
  _nav: KeyboardNav(),
  _expandedLayers: {},

  keyBindings: [
    {key: 'j/k', desc: 'Navigate layers'},
    {key: 'Enter', desc: 'Toggle layer', action: 'Enter'},
    {key: 'e', desc: 'Expand/collapse all', action: 'e'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    const row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      if (row.classList.contains('expandable')) {
        this._toggleLayer(row.dataset.layer);
      }
    } else if (e.key === 'e') {
      e.preventDefault();
      this._toggleAll();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>Layer Dependencies</h2>
      </div>
      <div id="deps-content" class="loading">Loading dependency graph</div>
    `;

    try {
      const data = await API.getLayerDeps();
      if (data && data.error) {
        document.getElementById('deps-content').innerHTML =
          `<div class="empty-state"><h3>Error</h3><p>${data.error}</p></div>`;
        return;
      }
      this._data = data;
      this._renderDeps(data);
    } catch (e) {
      document.getElementById('deps-content').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderDeps(data) {
    const el = document.getElementById('deps-content');
    const graph = data.graph || data;

    if (!graph || typeof graph !== 'object' || !Object.keys(graph).length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No dependency data</h3></div>';
      return;
    }

    // Build reverse deps map
    const reverseDeps = {};
    for (const [name, info] of Object.entries(graph)) {
      const deps = info.depends || [];
      for (const dep of deps) {
        if (!reverseDeps[dep]) reverseDeps[dep] = [];
        reverseDeps[dep].push(name);
      }
    }

    const layers = Object.keys(graph).sort();
    el.className = '';

    let html = `<table class="data-table" id="deps-table">
      <thead><tr><th style="width:2ch"></th><th>Layer</th><th>Priority</th><th>Dependencies</th><th>Used by</th></tr></thead>
      <tbody>`;

    for (const layer of layers) {
      const info = graph[layer];
      const deps = info.depends || [];
      const recommends = info.recommends || [];
      const revDeps = reverseDeps[layer] || [];
      const hasDeps = deps.length > 0 || recommends.length > 0;
      const isExpanded = this._expandedLayers[layer] === true;
      const chevron = hasDeps ? (isExpanded ? '\u25be' : '\u25b8') : ' ';

      html += `<tr class="${hasDeps ? 'expandable' : ''}" data-layer="${esc(layer)}" role="row" tabindex="-1">
        <td><span class="dash-row-toggle">${chevron}</span></td>
        <td style="color:var(--accent);font-weight:600">${esc(layer)}</td>
        <td style="color:var(--text-muted)">${info.priority || ''}</td>
        <td>${deps.length ? `<span style="color:var(--cyan)">${deps.length} deps</span>` : ''}</td>
        <td>${revDeps.length ? `<span style="color:var(--yellow)">${revDeps.length} users</span>` : ''}</td>
      </tr>`;

      if (isExpanded && hasDeps) {
        const allDeps = [];
        for (const d of deps) allDeps.push({name: d, type: 'depends'});
        for (const d of recommends) allDeps.push({name: d, type: 'recommends'});

        for (let i = 0; i < allDeps.length; i++) {
          const d = allDeps[i];
          const isLast = i === allDeps.length - 1;
          const typeLabel = d.type === 'recommends' ? ' (optional)' : '';
          const color = d.type === 'recommends' ? 'var(--text-muted)' : 'var(--text-secondary)';
          html += `<tr class="explore-layer-row${isLast ? ' tree-last' : ''}" role="row" tabindex="-1">
            <td class="tree-line"></td>
            <td colspan="4"><span style="color:${color}">${esc(d.name)}</span><span style="color:var(--text-muted)">${typeLabel}</span></td>
          </tr>`;
        }
      }
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Click layer header to toggle
    el.querySelectorAll('tr.expandable').forEach(row => {
      row.addEventListener('click', () => this._toggleLayer(row.dataset.layer));
    });

    // Keyboard nav
    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
  },

  _toggleLayer(layer) {
    this._expandedLayers[layer] = !this._expandedLayers[layer];
    if (this._data) this._renderDeps(this._data);
  },

  _toggleAll() {
    const anyExpanded = Object.values(this._expandedLayers).some(v => v);
    const layers = document.querySelectorAll('tr.expandable[data-layer]');
    layers.forEach(r => {
      this._expandedLayers[r.dataset.layer] = !anyExpanded;
    });
    if (this._data) this._renderDeps(this._data);
  },
};
