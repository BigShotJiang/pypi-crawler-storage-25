/* Recipes view — recipe browser with split-pane preview, search, grouping, keybindings */
const RecipesView = {
  _nav: KeyboardNav(),
  _expandedGroups: {},
  _allExpanded: true,
  _previewRecipe: null,
  _lastRecipes: null,
  _searchTerm: '',
  _groupMode: 'layer',  // 'layer' | 'section' | 'flat'

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Preview / toggle group', action: 'Enter'},
    {key: 'v', desc: 'View recipe file', action: 'v'},
    {key: 'e', desc: 'Edit recipe', action: 'e'},
    {key: 'y', desc: 'Copy path', action: 'y'},
    {key: 'g', desc: 'Cycle grouping', action: 'g'},
    {key: '/', desc: 'Search', action: '/'},
    {key: 'x', desc: 'Expand/collapse all', action: 'x'},
  ],

  handleKeyboard(e) {
    if (e.key === 'Escape') {
      const panel = document.getElementById('recipes-preview-panel');
      if (panel && panel.style.display !== 'none') {
        e.preventDefault();
        this._hidePreview();
        return;
      }
    }
    if (this._nav.handleBasicKeys(e)) return;
    const row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      if (row.classList.contains('expandable')) {
        this._toggleGroup(row.dataset.group);
      } else {
        this._showPreviewForRow(row);
      }
    } else if (e.key === 'v' && row) {
      e.preventDefault();
      this._viewRecipeFile(row);
    } else if (e.key === 'e' && row) {
      e.preventDefault();
      this._editRecipeFile(row);
    } else if (e.key === 'y' && row) {
      e.preventDefault();
      this._copyPath(row);
    } else if (e.key === 'g') {
      e.preventDefault();
      this._cycleGroupMode();
    } else if (e.key === '/') {
      e.preventDefault();
      const input = document.getElementById('recipe-search');
      if (input) input.focus();
    } else if (e.key === 'x') {
      e.preventDefault();
      this._toggleAll();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="recipes-split">
        <div class="recipes-left" id="recipes-left">
          <div class="recipes-left-header">
            <h2>Recipes</h2>
          </div>
          <div id="recipes-list" class="loading">Loading recipes</div>
        </div>
        <div class="recipes-resizer" id="recipes-resizer" style="display:none"></div>
        <div id="recipes-preview-panel" class="recipes-preview-panel" style="display:none">
          <div class="recipes-preview-header">
            <span id="recipes-preview-title"></span>
            <div class="btn-group">
              <button class="btn" id="recipes-preview-popout" title="Open in modal (v)">\u2197</button>
              <button class="btn" id="recipes-preview-close" title="Close preview">\u00d7</button>
            </div>
          </div>
          <div id="recipes-preview-body">
            <div class="recipes-preview-placeholder">Select a recipe to preview</div>
          </div>
        </div>
      </div>
      <div class="recipes-footer">
        <div class="recipes-footer-left">
          <input type="text" id="recipe-search" placeholder="Search recipes...">
          <button class="btn" id="recipe-reset" style="display:none" title="Clear search">Reset</button>
        </div>
        <div class="recipes-footer-right">
          <button class="btn recipes-group-btn" id="recipes-group-btn" title="Cycle grouping (g)">Group: layer</button>
          <button class="btn" id="recipes-toggle-all" title="Expand/collapse all groups (x)">Collapse all</button>
        </div>
      </div>
    `;

    // Search handlers
    const searchInput = document.getElementById('recipe-search');
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this._search();
      } else if (e.key === 'Escape') {
        searchInput.blur();
        e.preventDefault();
      }
    });
    document.getElementById('recipe-reset').addEventListener('click', () => {
      searchInput.value = '';
      this._searchTerm = '';
      document.getElementById('recipe-reset').style.display = 'none';
      this._search();
    });
    document.getElementById('recipes-group-btn').addEventListener('click', () => this._cycleGroupMode());
    document.getElementById('recipes-toggle-all').addEventListener('click', () => this._toggleAll());
    document.getElementById('recipes-preview-close').addEventListener('click', () => this._hidePreview());
    document.getElementById('recipes-preview-popout').addEventListener('click', async () => {
      if (this._previewRecipe && this._previewRecipe.path) {
        await fileEditor(this._previewRecipe.path, {readOnly: true});
      }
    });

    // Resizable divider
    const resizer = document.getElementById('recipes-resizer');
    const leftPanel = document.getElementById('recipes-left');
    if (resizer && leftPanel) {
      const saved = localStorage.getItem('bit-recipes-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';

      let startX, startW;
      const onMouseMove = (e) => {
        const newW = startW + (e.clientX - startX);
        const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = leftPanel.getBoundingClientRect().width;
        localStorage.setItem('bit-recipes-left-width', Math.round(w));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    this._search();
  },

  async _search() {
    const input = document.getElementById('recipe-search');
    const search = input ? input.value : '';
    this._searchTerm = search;
    const resetBtn = document.getElementById('recipe-reset');
    if (resetBtn) resetBtn.style.display = search ? '' : 'none';

    const el = document.getElementById('recipes-list');
    el.className = 'loading';
    el.textContent = 'Loading...';

    try {
      const recipes = await API.getRecipes(search);
      this._lastRecipes = recipes;
      this._renderGrouped(recipes);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _groupKeyFn(r) {
    if (this._groupMode === 'section') return r.SECTION || r.section || 'other';
    if (this._groupMode === 'flat') return null;
    return r.layer_name || r.layer || 'unknown';
  },

  _renderGrouped(recipes) {
    const el = document.getElementById('recipes-list');
    if (!recipes || !recipes.length) {
      el.className = '';
      el.innerHTML = this._searchTerm
        ? '<div class="empty-state"><h3>No matching recipes</h3></div>'
        : '<div class="empty-state"><h3>No recipes found</h3></div>';
      this._nav.setRows([]);
      return;
    }

    if (this._groupMode === 'flat') {
      this._renderFlat(recipes, el);
    } else {
      this._renderGroupedTable(recipes, el);
    }

    // Update toggle-all button text
    const toggleBtn = document.getElementById('recipes-toggle-all');
    if (toggleBtn) {
      toggleBtn.textContent = this._allExpanded ? 'Collapse all' : 'Expand all';
      toggleBtn.style.display = this._groupMode === 'flat' ? 'none' : '';
    }
  },

  _renderFlat(recipes, el) {
    el.className = '';
    const sorted = [...recipes].sort((a, b) => {
      const na = (a.pn || a.name || a.filename || '').toLowerCase();
      const nb = (b.pn || b.name || b.filename || '').toLowerCase();
      return na < nb ? -1 : na > nb ? 1 : 0;
    });

    let html = `<table class="data-table" id="recipes-table">
      <thead><tr><th>Name</th><th>Version</th><th>Layer</th><th>Summary</th><th>Section</th><th class="row-actions-col"></th></tr></thead>
      <tbody>`;

    for (const r of sorted) {
      const name = r.pn || r.name || r.filename || '';
      const isAppend = name.endsWith('.bbappend') || (r.path || '').endsWith('.bbappend');
      const nameColor = isAppend ? 'var(--yellow)' : 'var(--green)';
      const path = r.path || '';
      html += `<tr class="explore-layer-row" data-recipe-path="${esc(path)}" data-recipe-name="${esc(name)}" role="row" tabindex="-1">
        <td><span style="color:${nameColor}">${esc(name)}</span></td>
        <td style="color:var(--cyan)">${esc(r.pv || r.version || '')}</td>
        <td style="color:var(--text-muted)">${esc(r.layer_name || r.layer || '')}</td>
        <td style="color:var(--text-muted)">${esc((r.SUMMARY || '').substring(0, 60))}</td>
        <td style="color:var(--text-muted)">${esc(r.SECTION || r.section || '')}</td>
        <td class="row-actions">
          <button class="btn-icon" data-action="preview" title="Preview (Enter)">\u2299</button>
          <button class="btn-icon" data-action="view" title="View file (v)">\u2630</button>
          <button class="btn-icon" data-action="edit" title="Edit (e)">\u270e</button>
          <button class="btn-icon" data-action="copy" title="Copy path (y)">\u29c9</button>
        </td>
      </tr>`;
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Click row to select + preview
    el.querySelectorAll('tr.explore-layer-row').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showPreviewForRow(row);
      });
    });

    // Icon button handlers
    el.querySelectorAll('.row-actions .btn-icon').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const row = btn.closest('tr');
        const act = btn.dataset.action;
        if (act === 'preview') { this._nav.activateElement(row); this._showPreviewForRow(row); }
        else if (act === 'view') this._viewRecipeFile(row);
        else if (act === 'edit') this._editRecipeFile(row);
        else if (act === 'copy') this._copyPath(row);
      });
    });

    // Right-click context menu
    el.querySelectorAll('tr.explore-layer-row').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showContextMenu(e, row);
      });
    });

    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
  },

  _renderGroupedTable(recipes, el) {
    // Group recipes
    const byGroup = {};
    for (const r of recipes) {
      const key = this._groupKeyFn(r);
      if (!byGroup[key]) byGroup[key] = [];
      byGroup[key].push(r);
    }
    const groups = Object.keys(byGroup).sort();

    el.className = '';
    let html = `<table class="data-table" id="recipes-table">
      <thead><tr><th style="width:2ch"></th><th>Name</th><th>Version</th><th>Summary</th><th>Section</th><th class="row-actions-col"></th></tr></thead>
      <tbody>`;

    for (const group of groups) {
      const recs = byGroup[group];
      const isExpanded = this._expandedGroups[group] !== false;
      const chevron = isExpanded ? '\u25be' : '\u25b8';
      html += `<tr class="expandable" data-group="${esc(group)}" role="row" tabindex="-1">
        <td><span class="dash-row-toggle">${chevron}</span></td>
        <td colspan="5" style="font-weight:600;color:var(--text-primary)">
          ${esc(group)} <span style="color:var(--text-muted);font-weight:400">(${recs.length})</span>
        </td>
      </tr>`;

      if (isExpanded) {
        for (let i = 0; i < recs.length; i++) {
          const r = recs[i];
          const name = r.pn || r.name || r.filename || '';
          const isAppend = name.endsWith('.bbappend') || (r.path || '').endsWith('.bbappend');
          const nameColor = isAppend ? 'var(--yellow)' : 'var(--green)';
          const isLast = i === recs.length - 1;
          const path = r.path || '';
          html += `<tr class="explore-layer-row${isLast ? ' tree-last' : ''}" data-group="${esc(group)}" data-recipe-path="${esc(path)}" data-recipe-name="${esc(name)}" role="row" tabindex="-1">
            <td class="tree-line"></td>
            <td><span style="color:${nameColor}">${esc(name)}</span></td>
            <td style="color:var(--cyan)">${esc(r.pv || r.version || '')}</td>
            <td style="color:var(--text-muted)">${esc((r.SUMMARY || '').substring(0, 60))}</td>
            <td style="color:var(--text-muted)">${esc(r.SECTION || r.section || '')}</td>
            <td class="row-actions">
              <button class="btn-icon" data-action="preview" title="Preview (Enter)">\u2299</button>
              <button class="btn-icon" data-action="view" title="View file (v)">\u2630</button>
              <button class="btn-icon" data-action="edit" title="Edit (e)">\u270e</button>
              <button class="btn-icon" data-action="copy" title="Copy path (y)">\u29c9</button>
            </td>
          </tr>`;
        }
      }
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Click group header to select + toggle
    el.querySelectorAll('tr.expandable').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._toggleGroup(row.dataset.group);
      });
    });

    // Click recipe row to select + preview
    el.querySelectorAll('tr.explore-layer-row').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showPreviewForRow(row);
      });
    });

    // Icon button handlers
    el.querySelectorAll('.row-actions .btn-icon').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const row = btn.closest('tr');
        const act = btn.dataset.action;
        if (act === 'preview') { this._nav.activateElement(row); this._showPreviewForRow(row); }
        else if (act === 'view') this._viewRecipeFile(row);
        else if (act === 'edit') this._editRecipeFile(row);
        else if (act === 'copy') this._copyPath(row);
      });
    });

    // Right-click context menu
    el.querySelectorAll('tr.explore-layer-row').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showContextMenu(e, row);
      });
    });

    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
  },

  _findRecipeByName(name) {
    if (!this._lastRecipes) return null;
    return this._lastRecipes.find(r => (r.pn || r.name || r.filename || '') === name) || null;
  },

  _showPreviewForRow(row) {
    if (row.classList.contains('expandable')) return;
    const name = row.dataset.recipeName;
    if (!name) return;
    const recipe = this._findRecipeByName(name);
    if (recipe) this._showPreview(recipe);
  },

  async _showPreview(recipe) {
    const panel = document.getElementById('recipes-preview-panel');
    const resizer = document.getElementById('recipes-resizer');
    const title = document.getElementById('recipes-preview-title');
    const body = document.getElementById('recipes-preview-body');
    const leftPanel = document.getElementById('recipes-left');
    if (!panel || !body) return;

    this._previewRecipe = recipe;

    // Show panel and resizer
    panel.style.display = '';
    if (resizer) resizer.style.display = '';

    // Apply saved width
    if (leftPanel && !leftPanel.style.flex) {
      const saved = localStorage.getItem('bit-recipes-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
    }

    const name = recipe.pn || recipe.name || recipe.filename || '';
    if (title) title.textContent = name;

    // Build metadata section
    let metaHTML = '<div class="recipes-preview-meta">';
    metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Name</span><span class="recipes-detail-value" style="font-weight:600">${esc(name)}</span></div>`;
    const version = recipe.pv || recipe.version || '';
    if (version) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Version</span><span class="recipes-detail-value" style="color:var(--cyan)">${esc(version)}</span></div>`;
    }
    const layer = recipe.layer_name || recipe.layer || '';
    if (layer) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Layer</span><span class="recipes-detail-value" style="color:var(--cyan)">${esc(layer)}</span></div>`;
    }
    const section = recipe.SECTION || recipe.section || '';
    if (section) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Section</span><span class="recipes-detail-value">${esc(section)}</span></div>`;
    }
    const summary = recipe.SUMMARY || '';
    if (summary) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Summary</span><span class="recipes-detail-value">${esc(summary)}</span></div>`;
    }
    const description = recipe.DESCRIPTION || '';
    if (description) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Description</span><span class="recipes-detail-value" style="white-space:pre-wrap">${esc(description)}</span></div>`;
    }
    const license = recipe.LICENSE || '';
    if (license) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">License</span><span class="recipes-detail-value">${esc(license)}</span></div>`;
    }
    const homepage = recipe.HOMEPAGE || '';
    if (homepage) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Homepage</span><span class="recipes-detail-value"><a href="${esc(homepage)}" target="_blank" rel="noopener" style="color:var(--accent)">${esc(homepage)}</a></span></div>`;
    }
    const depends = recipe.DEPENDS || '';
    if (depends) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Depends</span><span class="recipes-detail-value" style="white-space:pre-wrap">${esc(depends)}</span></div>`;
    }
    if (recipe.path) {
      metaHTML += `<div class="recipes-detail-field"><span class="recipes-detail-label">Path</span><span class="recipes-detail-value" style="color:var(--text-muted);font-size:var(--font-size-xs)">${esc(recipe.path)}</span></div>`;
    }
    metaHTML += '</div>';

    // Load recipe file content
    if (recipe.path) {
      body.innerHTML = metaHTML + '<div class="loading" style="padding:12px">Loading file</div>';
      try {
        const data = await API.readFile(recipe.path);
        const content = data.content || '';
        const lines = content.split('\n');
        const gutterHTML = lines.map((_, i) => (i + 1)).join('\n');

        body.innerHTML = metaHTML +
          '<div class="recipes-preview-content">' +
          '<pre class="recipes-preview-gutter">' + esc(gutterHTML) + '</pre>' +
          '<pre class="recipes-preview-code">' + esc(content) + '</pre>' +
          '</div>';
      } catch (e) {
        body.innerHTML = metaHTML +
          `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
      }
    } else {
      body.innerHTML = metaHTML;
    }
  },

  _hidePreview() {
    const panel = document.getElementById('recipes-preview-panel');
    const resizer = document.getElementById('recipes-resizer');
    const leftPanel = document.getElementById('recipes-left');
    this._previewRecipe = null;
    if (panel) panel.style.display = 'none';
    if (resizer) resizer.style.display = 'none';
    if (leftPanel) leftPanel.style.flex = '';
  },

  _viewRecipeFile(row) {
    if (row.classList.contains('expandable')) return;
    const path = row.dataset.recipePath;
    if (path) fileEditor(path, {readOnly: true});
  },

  async _editRecipeFile(row) {
    if (row.classList.contains('expandable')) return;
    const path = row.dataset.recipePath;
    if (!path) return;
    await fileEditor(path, {readOnly: false});
    // Refresh after editing
    this._search();
  },

  _copyPath(row) {
    if (row.classList.contains('expandable')) return;
    const path = row.dataset.recipePath;
    if (!path) return;
    navigator.clipboard.writeText(path).then(() => {
      App.showToast('Path copied', 'success');
    }).catch(() => {
      App.showToast('Copy failed', 'error');
    });
  },

  async _showContextMenu(e, row) {
    this._nav.activateElement(row);
    const action = await contextMenu(e.clientX, e.clientY, [
      { label: 'Preview', icon: '\u2299', key: 'Enter', action: 'preview' },
      { label: 'View file', icon: '\u2630', key: 'v', action: 'view' },
      { label: 'Edit', icon: '\u270e', key: 'e', action: 'edit' },
      { sep: true },
      { label: 'Copy path', icon: '\u29c9', key: 'y', action: 'copy' },
    ]);
    if (!action) return;
    if (action === 'preview') this._showPreviewForRow(row);
    else if (action === 'view') this._viewRecipeFile(row);
    else if (action === 'edit') this._editRecipeFile(row);
    else if (action === 'copy') this._copyPath(row);
  },

  _cycleGroupMode() {
    const modes = ['layer', 'section', 'flat'];
    const idx = modes.indexOf(this._groupMode);
    this._groupMode = modes[(idx + 1) % modes.length];
    // Reset expand state when switching modes
    this._expandedGroups = {};
    this._allExpanded = true;
    // Update button label
    const btn = document.getElementById('recipes-group-btn');
    if (btn) btn.textContent = 'Group: ' + this._groupMode;
    // Re-render from cache
    if (this._lastRecipes) this._renderGrouped(this._lastRecipes);
  },

  _toggleGroup(group) {
    this._expandedGroups[group] = this._expandedGroups[group] === false;
    if (this._lastRecipes) this._renderGrouped(this._lastRecipes);
  },

  _toggleAll() {
    if (this._groupMode === 'flat') return;
    this._allExpanded = !this._allExpanded;
    this._expandedGroups = {};
    if (!this._allExpanded) {
      // Collapse all — mark all current groups as collapsed
      if (this._lastRecipes) {
        for (const r of this._lastRecipes) {
          const key = this._groupKeyFn(r);
          if (key != null) this._expandedGroups[key] = false;
        }
      }
    }
    if (this._lastRecipes) this._renderGrouped(this._lastRecipes);
  },
};
