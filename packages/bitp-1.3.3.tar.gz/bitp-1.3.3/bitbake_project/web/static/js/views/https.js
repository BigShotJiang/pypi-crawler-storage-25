/* HTTPS view — certificate status and CA download */
const HttpsView = {
  async render(container) {
    container.innerHTML = `
      <div class="view-header"><h2>HTTPS</h2></div>
      <div id="https-content" class="loading">Loading</div>
    `;
    this._load();
  },

  async _load() {
    const el = document.getElementById('https-content');
    if (!el) return;
    try {
      const status = await API.getHttpsStatus();
      this._render(el, status);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _render(el, s) {
    el.className = '';

    if (s.ssl_enabled) {
      // SSL is active
      const statusHtml = '<span style="color:var(--green)">&#x2714; HTTPS is active</span>';
      let body;
      if (s.ca_available) {
        body = `
          <p>${statusHtml}</p>
          <p>Both HTTP and HTTPS work on the same port. To get a trusted connection
             in your browser, download the CA certificate and import it.</p>
          <p><a href="/api/https/ca.crt" download class="btn">Download CA Certificate</a></p>
          <h3>Browser Import</h3>
          <ul>
            <li><strong>Chrome / Edge:</strong> Settings &rarr; Privacy &amp; Security &rarr; Security &rarr;
                Manage certificates &rarr; Authorities &rarr; Import &rarr; select <code>bit-ca.crt</code> &rarr;
                check "Trust this certificate for identifying websites"</li>
            <li><strong>Firefox:</strong> Settings &rarr; Privacy &amp; Security &rarr; Certificates &rarr;
                View Certificates &rarr; Authorities &rarr; Import &rarr; select <code>bit-ca.crt</code> &rarr;
                check "Trust this CA to identify websites"</li>
            <li><strong>System (Linux):</strong> Copy to <code>/usr/local/share/ca-certificates/bit-ca.crt</code>
                and run <code>sudo update-ca-certificates</code></li>
          </ul>
        `;
      } else {
        body = `
          <p>${statusHtml}</p>
          <p>The CA certificate (<code>rootCA.pem</code>) is not available in
             <code>~/.config/bit/</code>. Copy it there so browsers can download it
             from this page.</p>
          <p>Run <code>bit help certs</code> for setup instructions.</p>
        `;
      }
      el.innerHTML = body;
    } else {
      // No SSL
      el.innerHTML = `
        <p><span style="color:var(--yellow)">&#x26A0; HTTPS is not active</span></p>
        <p>To enable HTTPS, generate certificates with <a href="https://github.com/FiloSottile/mkcert" target="_blank">mkcert</a>
           and place them in <code>~/.config/bit/</code>.</p>
        <h3>Quick Setup</h3>
        <ol>
          <li>Install mkcert: <code>sudo apt install mkcert</code> (or see mkcert docs)</li>
          <li>Run <code>bit help certs</code> &mdash; prints instructions and writes a setup script to <code>/tmp/bit-setup-certs.sh</code></li>
          <li>Run <code>bash /tmp/bit-setup-certs.sh</code></li>
          <li>Restart the server: <code>bit serve restart</code></li>
        </ol>
        <p>After setup, this page will show a green status and a CA certificate download button.</p>
      `;
    }
  },
};
