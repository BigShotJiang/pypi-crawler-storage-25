#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Shared tmux helpers — session naming, prefix config, attach commands."""

import json
import os
import re
import shlex


_BIT_CONFIG_DIR = os.path.expanduser("~/.config/bit")
_DEFAULT_TMUX_PREFIX = "C-a"


def tmux_session_name(path: str) -> str:
    """Derive a tmux session name from a project path.

    >>> tmux_session_name("/opt/bruce/poky")
    'bit-poky'
    >>> tmux_session_name("/home/bruce/yocto-build")
    'bit-yocto-build'
    """
    basename = os.path.basename(path.rstrip("/"))
    sanitized = re.sub(r'[^a-zA-Z0-9_-]', '-', basename)
    return f"bit-{sanitized}"


def get_tmux_prefix() -> str:
    """Get configured tmux prefix key from global config.

    Defaults to ``C-a`` so it doesn't collide with an outer tmux using
    the default ``C-b``.
    """
    config_file = os.path.join(_BIT_CONFIG_DIR, "projects.json")
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__tmux_prefix__", _DEFAULT_TMUX_PREFIX)
        except (json.JSONDecodeError, OSError):
            pass
    return _DEFAULT_TMUX_PREFIX


def set_tmux_prefix(prefix: str) -> None:
    """Set tmux prefix key in global config."""
    os.makedirs(_BIT_CONFIG_DIR, exist_ok=True)
    config_file = os.path.join(_BIT_CONFIG_DIR, "projects.json")
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__tmux_prefix__"] = prefix
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
    except OSError:
        pass


def tmux_attach_cmd(session: str, cwd: str = "", prefix: str = "",
                    shell_cmd: str = "") -> list:
    """Build command list to attach to (or create) a tmux session.

    Returns a command list suitable for ``subprocess.Popen`` that attaches
    to an existing tmux session or creates a new one if it doesn't exist.

    Args:
        session: tmux session name (e.g. ``bit-poky``).
        cwd: Working directory for new sessions (ignored if session exists).
        prefix: tmux prefix key to set on new sessions (e.g. ``C-a``).
        shell_cmd: Path to a rcfile — new sessions run
            ``bash --rcfile <shell_cmd>`` instead of the default shell.
            Ignored when attaching to an existing session.
    """
    # Build the new-session part
    new_parts = ["tmux", "new-session", "-s", session]
    if cwd:
        new_parts.extend(["-c", cwd])

    # Shell override for new sessions (e.g. bash --rcfile with OE env)
    shell_suffix = ""
    if shell_cmd:
        shell_suffix = f" 'bash --rcfile {shlex.quote(shell_cmd)}'"

    if prefix:
        # Create detached, set prefix, then attach
        new_cmd = (
            f"tmux new-session -d -s {shlex.quote(session)}"
            + (f" -c {shlex.quote(cwd)}" if cwd else "")
            + shell_suffix
            + f"; tmux set-option -t {shlex.quote(session)} prefix {shlex.quote(prefix)}"
            + f"; exec tmux attach-session -t {shlex.quote(session)}"
        )
    else:
        new_cmd = (
            "exec tmux new-session -s " + shlex.quote(session)
            + (f" -c {shlex.quote(cwd)}" if cwd else "")
            + shell_suffix
        )

    # Always enforce the configured prefix, even on existing sessions
    set_prefix = (f"tmux set-option -t {shlex.quote(session)} prefix {shlex.quote(prefix)}; "
                  if prefix else "")
    attach_cmd = f"{set_prefix}exec tmux attach-session -t {shlex.quote(session)}"

    # Shell snippet: attach if exists, else create
    shell = (
        f"if tmux has-session -t {shlex.quote(session)} 2>/dev/null; then "
        f"{attach_cmd}; "
        f"else "
        f"{new_cmd}; "
        f"fi"
    )
    return ["bash", "-c", shell]
