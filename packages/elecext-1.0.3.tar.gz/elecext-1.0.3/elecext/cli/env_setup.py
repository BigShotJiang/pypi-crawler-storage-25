#!/usr/bin/env python3
"""Print shell export statements for elecext environment variables.

Usage:
    eval $(elecext-env)

This sets PMOL, EMOL, PGAU, EGAU, PMRCC, EMRCC, PORCA, EORCA, EBAS
to point to the pip-installed data files.
"""
from elecext import get_data_path, _ENV_VAR_MAP


def main():
    for var, subdirs in _ENV_VAR_MAP.items():
        path = get_data_path(*subdirs)
        print(f'export {var}="{path}"')


if __name__ == "__main__":
    main()
