"""Synthetic drift test fixtures."""
