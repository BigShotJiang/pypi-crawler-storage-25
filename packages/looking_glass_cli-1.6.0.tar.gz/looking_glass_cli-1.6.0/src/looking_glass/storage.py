"""Photo and outfit file management for Looking Glass."""

from __future__ import annotations

import shutil
from pathlib import Path

from looking_glass.config import OUTFITS_DIR, PHOTOS_DIR, ensure_dirs

SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


def _validate_image(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
        raise ValueError(
            f"Unsupported image format '{path.suffix}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_IMAGE_EXTENSIONS))}"
        )


def add_photo(source: Path, name: str | None = None) -> Path:
    """Copy a photo into the photos directory. Returns the destination path."""
    ensure_dirs()
    _validate_image(source)
    dest_name = f"{name}{source.suffix.lower()}" if name else source.name
    dest = PHOTOS_DIR / dest_name
    shutil.copy2(source, dest)
    return dest


def add_outfit(source: Path, name: str | None = None) -> Path:
    """Copy an outfit file into the outfits directory. Returns the destination path."""
    ensure_dirs()
    if not source.exists():
        raise FileNotFoundError(f"File not found: {source}")
    dest_name = f"{name}.txt" if name else source.name
    if not dest_name.endswith(".txt"):
        dest_name += ".txt"
    dest = OUTFITS_DIR / dest_name
    shutil.copy2(source, dest)
    return dest


def create_outfit(name: str, description: str) -> Path:
    """Write an outfit description directly to the outfits directory. Returns the destination path."""
    ensure_dirs()
    dest = OUTFITS_DIR / f"{name}.txt"
    dest.write_text(description)
    return dest


def list_photos() -> list[dict]:
    """Return a list of photo dicts with 'name' and 'path' keys."""
    ensure_dirs()
    photos = []
    for f in sorted(PHOTOS_DIR.iterdir()):
        if f.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            photos.append({"name": f.stem, "path": f})
    return photos


def list_outfits() -> list[dict]:
    """Return a list of outfit dicts with 'name', 'path', and 'description' keys."""
    ensure_dirs()
    outfits = []
    for f in sorted(OUTFITS_DIR.iterdir()):
        if f.suffix.lower() == ".txt":
            outfits.append({
                "name": f.stem,
                "path": f,
                "description": f.read_text().strip(),
            })
    return outfits


def remove_photo(name: str) -> bool:
    """Remove a photo by name (stem). Returns True if found and removed."""
    for f in PHOTOS_DIR.iterdir():
        if f.stem == name and f.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            f.unlink()
            return True
    return False


def remove_outfit(name: str) -> bool:
    """Remove an outfit by name (stem). Returns True if found and removed."""
    path = OUTFITS_DIR / f"{name}.txt"
    if path.exists():
        path.unlink()
        return True
    return False


def get_photo_path(name: str) -> Path | None:
    """Get the path to a photo by name."""
    for f in PHOTOS_DIR.iterdir():
        if f.stem == name and f.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            return f
    return None


def get_outfit(name: str) -> dict | None:
    """Get an outfit dict by name."""
    path = OUTFITS_DIR / f"{name}.txt"
    if path.exists():
        return {
            "name": path.stem,
            "path": path,
            "description": path.read_text().strip(),
        }
    return None
