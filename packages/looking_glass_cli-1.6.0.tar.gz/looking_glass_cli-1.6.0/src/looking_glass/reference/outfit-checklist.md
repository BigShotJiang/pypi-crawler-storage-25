# Outfit Observation Checklist

## Omission Guard
- [ ] Do not stop after naming the main garment.
- [ ] Do not merge separate visible garments into one item.
- [ ] Do not skip small visible details.
- [ ] Do not overlook accessories, add-ons, or visible underlayers.
- [ ] Do not infer hidden details that are not visible.
- [ ] Treat each visible item as a separate inspection target.
- [ ] Mark uncertain details as ambiguous / partially visible / occluded / not visible.

## Image Conditions
- [ ] Note crop extent affecting outfit visibility.
- [ ] Note pose affecting garment shape or coverage.
- [ ] Note viewpoint / angle affecting silhouette or proportions.
- [ ] Note lighting cast affecting color reading.
- [ ] Note shadows hiding details.
- [ ] Note blur reducing detail visibility.
- [ ] Note motion blur affecting edges or texture.
- [ ] Note reflections affecting color / material reading.
- [ ] Note mirror-selfie reversal if applicable.
- [ ] Note perspective distortion affecting length / width cues.
- [ ] Note folds caused by pose rather than garment design.
- [ ] Note obstructions from hair, hands, arms, props, furniture, or other people.

## Overall Outfit Pass
- [ ] Count distinct visible clothing layers before item-by-item inspection.
- [ ] Count distinct visible accessories before item-by-item inspection.
- [ ] Identify overall outfit category mix visible (casual / formal / athletic / uniform-like / etc. only if visually evident).
- [ ] Check overall silhouette before local details.
- [ ] Check overall fit impression before local details.
- [ ] Check dominant colors before local details.
- [ ] Check overall color blocking across the outfit.
- [ ] Check visible pattern presence across the outfit.
- [ ] Check overall material mix across the outfit.
- [ ] Check overall structure vs drape across the outfit.
- [ ] Check visible styling relationships among layers.

## Head to Toe Scan

### Head / Hair Area
#### Hair Accessories
- [ ] Item present or not visible.
- [ ] Visibility status: clearly visible / partially visible / occluded / ambiguous / not visible.
- [ ] Item category / type.
- [ ] Shape / silhouette.
- [ ] Size / scale.
- [ ] Placement.
- [ ] Color.
- [ ] Pattern.
- [ ] Material / texture.
- [ ] Shine / reflectivity.
- [ ] Hardware / ornament / embellishment.
- [ ] Branding / logo.
- [ ] Condition / wear.

#### Hats / Headwear
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Crown / brim / hood / wrap shape.
- [ ] Fit / placement on head.
- [ ] Coverage.
- [ ] Layering relation with hair / hood / eyewear.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Structure / drape.
- [ ] Closures / ties / straps.
- [ ] Seams / paneling.
- [ ] Edge finishes.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / condition.
- [ ] Asymmetry.

#### Eyewear
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Frame shape / silhouette.
- [ ] Frame size / fit on face.
- [ ] Lens tint / opacity / transparency.
- [ ] Color of frame / lens.
- [ ] Material cues.
- [ ] Shine / reflectivity.
- [ ] Hardware / hinges.
- [ ] Branding / logos.
- [ ] Embellishments.
- [ ] Condition / scratches / wear if visible.
- [ ] Asymmetry / tilt.

#### Jewelry at Head / Face / Neck Entry
- [ ] Separate each visible item rather than merging.
- [ ] Visibility status for each item.
- [ ] Item category / type.
- [ ] Size / scale.
- [ ] Shape.
- [ ] Placement.
- [ ] Color / metal tone.
- [ ] Material cues.
- [ ] Texture / stone / bead / chain cues.
- [ ] Shine / reflectivity.
- [ ] Closures / settings / links if visible.
- [ ] Branding / logos if visible.
- [ ] Embellishments.
- [ ] Condition / wear.

### Neck / Shoulders / Upper Torso
#### Scarves / Neckwear / Ties / Bow Ties
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Shape / knot / wrap / drape.
- [ ] Fit / placement.
- [ ] Length / coverage.
- [ ] Layering relation with collar / lapel / neckline / outerwear.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Edge finishes / fringe.
- [ ] Seams / paneling.
- [ ] Hardware / clips / tie bars.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Condition / wear.
- [ ] Asymmetry.

#### Outerwear
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Fit.
- [ ] Length / coverage.
- [ ] Layering relation to garments above and below.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Stretch / compression cues.
- [ ] Neckline / collar / lapel shape.
- [ ] Hood presence / shape.
- [ ] Shoulder shape / padding if visible.
- [ ] Sleeves / sleeve length / sleeve shape.
- [ ] Cuffs.
- [ ] Hem shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pleats / gathers / darts.
- [ ] Pockets.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

#### Tops
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Fit.
- [ ] Length / coverage.
- [ ] Layering relation to outerwear / underlayers / bottoms.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Stretch / compression cues.
- [ ] Neckline / collar shape.
- [ ] Lapel shape if applicable.
- [ ] Sleeves / straps.
- [ ] Cuffs.
- [ ] Hem shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pleats / gathers / darts.
- [ ] Pockets.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

#### Visible Underlayers
- [ ] Separate each visible underlayer from the outer visible top layer.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Visible extent only; do not infer hidden portion.
- [ ] Layering relation.
- [ ] Color.
- [ ] Pattern type / scale / placement.
- [ ] Material / texture cues.
- [ ] Thickness / transparency / sheen cues.
- [ ] Neckline / collar / trim visibility.
- [ ] Sleeve / strap visibility.
- [ ] Hem / edge visibility.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Condition / wear.

#### Suits / Tailoring
- [ ] Check separately for tailored jacket, vest / waistcoat, trousers / skirt.
- [ ] Visibility status for each tailored piece.
- [ ] Item category / type.
- [ ] Silhouette / cut.
- [ ] Fit.
- [ ] Length / coverage.
- [ ] Layering relation among suit pieces.
- [ ] Color.
- [ ] Color blocking / contrast details.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Sheen / reflectivity.
- [ ] Structure / drape.
- [ ] Lapel shape / width.
- [ ] Collar / neckline.
- [ ] Shoulder construction.
- [ ] Sleeves / cuffs.
- [ ] Waist shaping.
- [ ] Hem shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Darts / pleats.
- [ ] Pockets.
- [ ] Hardware / buttons.
- [ ] Logos / branding if visible.
- [ ] Embellishments.
- [ ] Distressing / condition.
- [ ] Asymmetry.
- [ ] Edge finishes.

### Midsection / Waist / Hips
#### Belts / Waist Accessories
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Width / shape.
- [ ] Fit / placement.
- [ ] Coverage / visible extent.
- [ ] Layering relation with top / dress / outerwear / bottoms.
- [ ] Color.
- [ ] Pattern / texture.
- [ ] Material cues.
- [ ] Thickness / structure cues.
- [ ] Sheen / reflectivity.
- [ ] Buckle / closures.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Condition / wear.
- [ ] Asymmetry.

#### Dresses / One-Piece Garments / Jumpsuits / Rompers
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Fit.
- [ ] Length / coverage.
- [ ] Layering relation with outerwear / tops / underlayers.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Stretch / compression cues.
- [ ] Neckline / collar / lapel shape.
- [ ] Sleeves / straps.
- [ ] Cuffs.
- [ ] Waistline / waistband.
- [ ] Hem shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pleats / gathers / darts.
- [ ] Pockets.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

### Lower Body
#### Bottoms
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Fit.
- [ ] Length / coverage.
- [ ] Rise if visible.
- [ ] Layering relation with tops / outerwear / hosiery.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity if applicable.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Stretch / compression cues.
- [ ] Waistband.
- [ ] Hem shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pleats / gathers / darts.
- [ ] Pockets.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

#### Socks / Hosiery / Legwear
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Coverage / height / length.
- [ ] Fit / compression cues.
- [ ] Layering relation with bottoms / shoes.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / opacity / transparency.
- [ ] Sheen / reflectivity.
- [ ] Edge / top band / finish.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / condition.
- [ ] Asymmetry.

### Feet
#### Footwear
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Fit / volume cues.
- [ ] Height / shaft / coverage.
- [ ] Layering relation with socks / hosiery / pants hem.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / weight cues.
- [ ] Transparency / opacity if applicable.
- [ ] Sheen / reflectivity.
- [ ] Structure / softness cues.
- [ ] Toe shape.
- [ ] Heel / sole shape.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pockets / utility attachments if any.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

## Hands / Arms
#### Gloves
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Shape / fit.
- [ ] Coverage / length.
- [ ] Layering relation with sleeves / cuffs.
- [ ] Color.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / opacity / sheen cues.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / condition.
- [ ] Asymmetry.
- [ ] Edge finishes.

#### Jewelry on Hands / Wrists / Arms
- [ ] Separate each visible item.
- [ ] Visibility status for each item.
- [ ] Item category / type.
- [ ] Shape / size / scale.
- [ ] Placement.
- [ ] Color / metal tone.
- [ ] Material cues.
- [ ] Texture / stone / chain / bead cues.
- [ ] Shine / reflectivity.
- [ ] Closures / settings if visible.
- [ ] Branding / logos.
- [ ] Embellishments.
- [ ] Condition / wear.

## Carried / Worn Accessories
#### Bags
- [ ] Item present or not visible.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Overall silhouette / shape.
- [ ] Size / scale.
- [ ] Placement / carrying method.
- [ ] Coverage / visible extent.
- [ ] Layering relation with body / garments.
- [ ] Color.
- [ ] Color blocking.
- [ ] Pattern type / scale / placement.
- [ ] Material cues.
- [ ] Texture.
- [ ] Thickness / structure cues.
- [ ] Transparency / opacity.
- [ ] Sheen / reflectivity.
- [ ] Drape / structure.
- [ ] Straps / handles.
- [ ] Closures.
- [ ] Seams / paneling.
- [ ] Pockets / compartments if visible.
- [ ] Hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / wear.
- [ ] Condition cues.
- [ ] Asymmetry.
- [ ] Edge finishes.

#### Additional Accessories
- [ ] Check for visible items not yet covered.
- [ ] Treat each as separate item.
- [ ] Visibility status.
- [ ] Item category / type.
- [ ] Shape / size / placement.
- [ ] Layering relation.
- [ ] Color / pattern / material / texture.
- [ ] Thickness / transparency / sheen / structure cues.
- [ ] Closures / seams / hardware.
- [ ] Logos / branding.
- [ ] Embellishments.
- [ ] Distressing / condition.
- [ ] Asymmetry / edge finishes.

## Outermost to Innermost Layer Confirmation
- [ ] Confirm outermost visible layer(s) identified.
- [ ] Confirm mid-layers identified separately.
- [ ] Confirm innermost visible layer(s) identified separately.
- [ ] Confirm no visible underlayer was absorbed into another garment.
- [ ] Confirm no accessory was absorbed into a garment description.
- [ ] Confirm overlaps at collar, cuff, hem, waistband, and neckline were checked.

## Global Detail Sweep Before Local Tiny Details
- [ ] Recheck silhouette across all items.
- [ ] Recheck fit across all items.
- [ ] Recheck lengths / coverage across all items.
- [ ] Recheck color distribution across all items.
- [ ] Recheck pattern distribution across all items.
- [ ] Recheck material / texture distribution across all items.
- [ ] Recheck structure vs drape across all items.
- [ ] Recheck layering relationships across all items.

## Small Detail Sweep
- [ ] Recheck collars / lapels.
- [ ] Recheck necklines.
- [ ] Recheck sleeves / straps.
- [ ] Recheck cuffs.
- [ ] Recheck waistbands.
- [ ] Recheck hems.
- [ ] Recheck closures.
- [ ] Recheck seams / paneling.
- [ ] Recheck pleats / gathers / darts.
- [ ] Recheck pockets.
- [ ] Recheck hardware.
- [ ] Recheck logos / branding.
- [ ] Recheck embellishments.
- [ ] Recheck distressing / wear.
- [ ] Recheck edge finishes.
- [ ] Recheck asymmetry.
- [ ] Recheck condition cues.

## Final Omission Check
- [ ] Every visible garment region was inspected.
- [ ] Every visible accessory was inspected.
- [ ] Every visible underlayer was inspected.
- [ ] Separate garments remain separate in notes.
- [ ] Small visible details were not skipped.
- [ ] Hidden details were not invented.
- [ ] All uncertain details are marked with visibility status.
- [ ] Nothing visible was left unexamined due to crop, pose, or obstruction without noting that limitation.
