"""Provider registry and discovery for Looking Glass."""

from __future__ import annotations

from looking_glass import config
from looking_glass.providers.base import Provider
from looking_glass.providers.gemini import GeminiProvider
from looking_glass.providers.openai import OpenAIProvider

# Registered providers in display order.
ALL_PROVIDERS: list[type[Provider]] = [OpenAIProvider, GeminiProvider]


def get_available_providers() -> list[Provider]:
    """Return instantiated providers that have an API key configured."""
    available: list[Provider] = []
    for cls in ALL_PROVIDERS:
        if config.get(cls.config_key):
            available.append(cls())
    return available


def get_all_provider_classes() -> list[type[Provider]]:
    """Return all registered provider classes."""
    return list(ALL_PROVIDERS)


def get_describe_provider() -> Provider | None:
    """Return the first available provider that supports outfit description.

    Prefers Gemini over OpenAI for capture since it has stronger vision.
    """
    # Prefer Gemini for vision-based capture.
    describe_order: list[type[Provider]] = [GeminiProvider, OpenAIProvider]
    available_keys = {cls.config_key for cls in ALL_PROVIDERS if config.get(cls.config_key)}
    for cls in describe_order:
        if cls.config_key not in available_keys:
            continue
        provider = cls()
        if type(provider).describe_outfit is not Provider.describe_outfit:
            return provider
    return None


__all__ = [
    "Provider",
    "OpenAIProvider",
    "GeminiProvider",
    "ALL_PROVIDERS",
    "get_available_providers",
    "get_all_provider_classes",
    "get_describe_provider",
]
