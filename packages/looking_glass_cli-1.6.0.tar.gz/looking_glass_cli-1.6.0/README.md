# Looking Glass

Use your photos to design and try on outfits — powered by AI image generation.

Supports **OpenAI** and **Google Gemini** as image generation providers.

## Installation

Requires [uv](https://docs.astral.sh/uv/getting-started/installation/).

```bash
uv tool install looking-glass-cli
```

## Quick Start

```bash
# 1. Set at least one API key (OpenAI, Gemini, or both)
glass config set openai_api_key sk-your-key-here
glass config set gemini_api_key your-gemini-key-here

# 2. Add a photo of yourself
glass photo add ~/selfie.jpg --name me

# 3. Add outfit descriptions (plain text files)
echo "Elegant navy suit, white dress shirt, silk tie" > formal.txt
glass outfit add formal.txt

echo "Hawaiian shirt, cargo shorts, flip-flops" > beach.txt
glass outfit add beach.txt --name beach-vibes

# 4a. Run interactive mode — pick a photo, pick outfits, pick a provider, generate!
glass

# 4b. OR: Batch capture outfit descriptions from a folder of photos
glass outfit capturefolder ~/photos --overwrite
```

## Commands

| Command | Description |
|---|---|
| `glass` | Interactive mode — select a photo, outfits, and provider, then generate images |
| `glass photo add <file> [--name NAME]` | Add a photo |
| `glass photo list` | List stored photos |
| `glass photo remove <name>` | Remove a photo |
| `glass outfit add <file> [--name NAME]` | Add an outfit description |
| `glass outfit capture <file> [--name NAME]` | Capture an outfit description from a photo using AI vision |
| `glass outfit capturefolder [FOLDER] [--overwrite]` | Batch capture outfit descriptions from all images in a folder (uses filenames as outfit names) |
| `glass outfit create --name NAME` | Create an outfit description in your default editor |
| `glass outfit list` | List stored outfits |
| `glass outfit remove <name>` | Remove an outfit |
| `glass config set <key> <value>` | Set a config value |
| `glass config show` | Show all available config options and their current values |

### Options

- `--output, -o PATH` — Directory for generated images (default: current directory)
- `--version` — Show version

### Configuration

Run `glass config show` to see all available options with descriptions and defaults.

| Key | Description | Default |
|---|---|---|
| `openai_api_key` | OpenAI API key for image generation | — |
| `gemini_api_key` | Google Gemini API key for image generation | — |
| `max_workers` | Max parallel image generations | `4` |

At least one API key is required. If both are configured, you'll be prompted to choose a provider during interactive mode.

**Note:** The `glass outfit capture` and `glass outfit capturefolder` commands require a vision-capable provider (OpenAI supports this via API key).

> **Migrating from an older version?** The `api_key` config key has been replaced by `openai_api_key`. Your existing key will be migrated automatically on first run.

## How It Works

1. Photos and outfit files are stored in `~/.looking-glass/`
2. Outfits are plain `.txt` files — the filename is the name, the content is the description
3. In interactive mode, select a photo, one or more outfits, and a provider
4. For each outfit, the app sends your photo + a prompt to the selected provider's API
5. Generated images are saved as `{photo}_{outfit}.png`
