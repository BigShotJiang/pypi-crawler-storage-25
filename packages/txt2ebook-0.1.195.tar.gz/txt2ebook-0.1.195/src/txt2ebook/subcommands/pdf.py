# Copyright (c) 2021,2022,2023,2024,2025,2026 Kian-Meng Ang
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""pdf subcommand — delegates to TypWriter under the hood."""

from __future__ import annotations

import argparse
import logging
import sys
from typing import Any

from txt2ebook.exceptions import InputError
from txt2ebook.formats.typ import TypWriter
from txt2ebook.subcommands.parse import run as parse_txt
from txt2ebook.subcommands.typ import _build_subparser

logger = logging.getLogger(__name__)


def build_subparser(subparsers: argparse._SubParsersAction[Any]) -> None:
    """Build the subparser — reuses typ's shared builder."""
    _build_subparser(subparsers, "pdf", "generate ebook in PDF format", None, run)


def run(args: argparse.Namespace) -> None:
    """Run pdf subcommand."""
    input_sources: list[Any] = []

    if args.input_file:
        input_sources.append(args.input_file)
    elif not sys.stdin.isatty():
        input_sources.append(sys.stdin)
    else:
        msg = "No input files provided."
        logger.error(msg)
        raise InputError(msg)

    for current_input_stream in input_sources:
        current_file_args = argparse.Namespace(**vars(args))
        current_file_args.input_file = current_input_stream

        book = parse_txt(current_file_args)
        writer = TypWriter(book, current_file_args)
        writer.write()

        if current_input_stream is not sys.stdin:
            current_input_stream.close()
