# Copyright (c) 2021,2022,2023,2024,2025,2026 Kian-Meng Ang
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Common shared functions."""

import argparse
import logging
import sys
from importlib import metadata

logger = logging.getLogger(__name__)

__version__ = metadata.version("txt2ebook")


def setup_logger(config: argparse.Namespace) -> None:
    """Configures logging based on command-line arguments.

    Args:
        config: Namespace containing parsed arguments.
    """
    if config.quiet:
        logging.disable(logging.NOTSET)
        return

    log_level = logging.DEBUG if config.debug else logging.INFO
    log_format = (
        "%(levelname)5s: %(message)s" if config.debug else "%(message)s"
    )

    logging.basicConfig(
        level=log_level,
        format=log_format,
        stream=sys.stdout,
        datefmt="%Y-%m-%d %H:%M:%S",
        force=True,
    )


def log_or_raise_on_warning(
    message: str,
    *,
    raise_on_warning: bool = False,
) -> None:
    """Logs a warning message or raises an exception.

    Args:
        message: The warning message to log or raise.
        raise_on_warning: If True, raises a RuntimeError instead of logging.
    """
    if raise_on_warning:
        raise RuntimeError(message)

    logger.warning(message)



