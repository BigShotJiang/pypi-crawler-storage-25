from collections.abc import Sequence

from pydtnn.abstract.layerable import Layerable
from pydtnn.activations.relu import Relu
from pydtnn.activations.softmax import Softmax
from pydtnn.layers.conv_2d import Conv2D
from pydtnn.layers.dropout import Dropout
from pydtnn.layers.fc import FC
from pydtnn.layers.flatten import Flatten
from pydtnn.layers.input import Input
from pydtnn.layers.max_pool_2d import MaxPool2D
from pydtnn.utils.constants import ArrayShape
from pydtnn.utils.initializers import he_uniform


def vgg3do(input_shape: ArrayShape, output_shape: ArrayShape) -> Sequence[Layerable]:
    model = list[Layerable]()
    _ = model.append

    _(Input(shape=input_shape))
    _(Conv2D(nfilters=32, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(Conv2D(nfilters=32, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(MaxPool2D(pool_shape=(2, 2), stride=2))
    _(Dropout(rate=0.2))
    _(Conv2D(nfilters=64, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(Conv2D(nfilters=64, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(MaxPool2D(pool_shape=(2, 2), stride=2))
    _(Dropout(rate=0.2))
    _(Conv2D(nfilters=128, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(Conv2D(nfilters=128, filter_shape=(3, 3), padding=1, activation=Relu, weights_initializer=he_uniform))
    _(MaxPool2D(pool_shape=(2, 2), stride=2))
    _(Dropout(rate=0.2))
    _(Flatten())
    _(FC(shape=(128,), activation=Relu, weights_initializer=he_uniform))
    _(Dropout(rate=0.2))
    _(FC(shape=output_shape, activation=Softmax))

    return model
