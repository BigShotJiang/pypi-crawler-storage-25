import logging

from pydtnn.layers.abstract.conv_2d import AbstractConv2D
from pydtnn.utils.constants import Array

logger = logging.getLogger(__name__)


class Conv2DPointwise[T: Array](AbstractConv2D[T]):
    pass
