import logging

from pycuda.driver import Function  # type: ignore

from pydtnn.backends.pycuda.abstract.base import BasePycuda
from pydtnn.backends.pycuda.utils.tensor_array import TensorArray
from pydtnn.metrics.metric import Metric
from pydtnn.utils.constants import DTYPE2CTYPE

logger = logging.getLogger(__name__)


class MetricPycuda(Metric[TensorArray], BasePycuda):
    """
    Extends a Metric class with the attributes and methods required by GPU Metrics.
    """

    def __init__(self, eps=1e-8):
        super().__init__(eps)
        # NOTE: The following attributes will be initializated later.
        self.grid = None
        self.block = None

    def _model_init(self) -> None:
        super()._model_init()
        self.grid = self.model.cuda_grid
        self.block = self.model.cuda_block

    def _kernel_init(self) -> Function:
        self.defines_replaces = {"\"TYPE\"": DTYPE2CTYPE[self.model.dtype]}
        self.kernel = self._get_kernel()
