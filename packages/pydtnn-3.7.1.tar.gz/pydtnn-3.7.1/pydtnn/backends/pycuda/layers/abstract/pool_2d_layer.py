import logging

from pycuda import gpuarray  # type: ignore

from pydtnn.backends.pycuda.layers.layer import LayerPycuda
from pydtnn.backends.pycuda.utils.tensor_array import TensorArray
from pydtnn.layers.abstract.pool_2d_layer import AbstractPool2DLayer
from pydtnn.layers.layer import ParameterException
from pydtnn.libs import cudnn as cudnn
from pydtnn.tracers.events import (PYDTNN_EVENT_FINISHED, PYDTNN_OPS_EVENT,
                                   PYDTNN_OPS_EVENTS, PYDTNN_OPS_EVENT_enum)
from pydtnn.utils.constants import ArrayShape
from pydtnn.utils.performance_models import col2im_time, im2col_time

logger = logging.getLogger(__name__)


class AbstractPool2DLayerPycuda(AbstractPool2DLayer[TensorArray], LayerPycuda):
    """
    Provides common methods to Pool2DPycuda classes.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # The following attributes will be initalized later.
        self.pool_desc = None  # TODO: set CDNN descripor type
        self.ci: int = None  # type: ignore
        self.hi: int = None  # type: ignore
        self.wi: int = None  # type: ignore
        self.kh: int = None  # type: ignore
        self.kw: int = None  # type: ignore
        self.co: int = None  # type: ignore
        self.ci: int = None  # type: ignore
        self.ho: int = None  # type: ignore
        self.wo: int = None  # type: ignore

    def initialize_pool_2d_gpu(self, prev_shape: ArrayShape, x: TensorArray, pool_mode: int) -> None:
        # pool_mode comes from cudnn.CudnnPoolingMode

        if not (self.hdilation == 1 and self.wdilation == 1):
            raise ParameterException(f"cuDNN does not support dilated pooling. vdilation: {self.hdilation}, hdilation: {self.wdilation}")

        nan_prop = cudnn.cudnnNanPropagation['CUDNN_NOT_PROPAGATE_NAN']

        self.pool_desc = cudnn.cudnnCreatePoolingDescriptor()
        cudnn.cudnnSetPooling2dDescriptor(self.pool_desc, pool_mode, nan_prop,
                                          self.kh, self.kw, self.hpadding, self.wpadding,
                                          self.hstride, self.wstride)
        # Get output dimensions
        _, _, self.ho, self.wo = cudnn.cudnnGetPooling2dForwardOutputDim(self.pool_desc, x.desc)
        self.shape = self.model.encode_shape((self.co, self.ho, self.wo))

        # Activations y
        y_gpu = gpuarray.zeros((self.model.batch_size, *self.shape), self.model.dtype)
        self.y = TensorArray(y_gpu, self.model.tensor_format, self.model.cudnn_dtype)
        self.memory_used += self.y.nbytes

        # Derivative dx
        dx_gpu = gpuarray.zeros(self.x.shape, self.model.dtype)
        self.dx = TensorArray(dx_gpu, self.model.tensor_format, self.model.cudnn_dtype)
        self.memory_used += self.dx.nbytes

        self.fwd_time = \
            im2col_time(m=(self.kh * self.kw), n=(self.model.batch_size * self.ho * self.wo * self.ci),
                        cpu_speed=self.model.cpu_speed, memory_bw=self.model.memory_bw,
                        dtype=self.model.dtype)  # type: ignore (it's fine)
        self.bwd_time = \
            col2im_time(m=(self.kh * self.kw), n=(self.model.batch_size * self.ho * self.wo * self.ci),
                        cpu_speed=self.model.cpu_speed, memory_bw=self.model.memory_bw,
                        dtype=self.model.dtype)  # type: ignore (it's fine)

    def forward(self, x: TensorArray) -> TensorArray:
        alpha, beta = 1.0, 0.0
        self.model.tracer.emit_event(PYDTNN_OPS_EVENT, self.id * PYDTNN_OPS_EVENTS + PYDTNN_OPS_EVENT_enum.FORWARD_CUDNN)
        cudnn.cudnnPoolingForward(self.model.cudnn_handle, self.pool_desc, alpha,
                                  x.desc, x.ptr_voidp, beta,
                                  self.y.desc, self.y.ptr_voidp)
        self.model.tracer.emit_event(PYDTNN_OPS_EVENT, PYDTNN_EVENT_FINISHED)
        return self.y

    def backward(self, dy: TensorArray) -> TensorArray:
        alpha, beta = 1.0, 0.0
        self.model.tracer.emit_event(PYDTNN_OPS_EVENT, self.id * PYDTNN_OPS_EVENTS + PYDTNN_OPS_EVENT_enum.BACKWARD_CUDNN_DX)
        # Compute dx
        cudnn.cudnnPoolingBackward(self.model.cudnn_handle, self.pool_desc, alpha,
                                   self.y.desc, self.y.ptr_voidp,
                                   dy.desc, dy.ptr_voidp,
                                   self.x.desc, self.x.ptr_voidp,
                                   beta, self.dx.desc, self.dx.ptr_voidp)
        self.model.tracer.emit_event(PYDTNN_OPS_EVENT, PYDTNN_EVENT_FINISHED)
        return self.dx
