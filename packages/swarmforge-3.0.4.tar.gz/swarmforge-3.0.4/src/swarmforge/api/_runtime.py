"""Shared FastAPI transport helpers for session and runtime management."""

from __future__ import annotations

import copy
import json
import uuid
from typing import Any, AsyncGenerator, Callable, Dict, List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from ..evaluation.provider import ModelConfig
from ..evaluation.swarm import serialize_checkpoints
from ..swarm import (
    SessionStateManager,
    SessionStore,
    SwarmDefinition,
    SwarmSession,
    build_turn_runner as _build_turn_runner,
    process_swarm_stream,
)
from ..swarm.orchestrator import AgentTurnRunner, RequiredVariableExtractor
from ..swarm.tools import ToolRegistry
from ._schemas import SessionVariableUpdateRequest


def _node_runtime_payload(session: SwarmSession, node: Any) -> Dict[str, Any]:
    context = session.agent_contexts.get(str(node.id))
    context_payload = context.to_dict() if context is not None else {}
    payload = {
        "id": node.id,
        "node_key": node.node_key,
        "name": node.name,
        "is_entry_node": node.is_entry_node,
        "history": copy.deepcopy((session.agent_histories or {}).get(str(node.id), [])),
        "scratchpad": copy.deepcopy((context_payload or {}).get("scratchpad") or {}),
        "context": context_payload,
    }
    if str(node.intent or "").strip():
        payload["intent"] = node.intent
    if list(node.capabilities or []):
        payload["capabilities"] = list(node.capabilities or [])
    return payload


def _runtime_payload(session: SwarmSession, state_manager: SessionStateManager) -> Dict[str, Any]:
    nodes = [_node_runtime_payload(session, node) for node in session.swarm.nodes]
    entry_node = session.swarm.entry_node()
    current_node = session.current_node
    state_snapshot = state_manager.snapshot(session, current_node=current_node)
    return {
        "state": state_snapshot,
        "global_state": copy.deepcopy(state_snapshot),
        "nodes": nodes,
        "entry_node": _node_runtime_payload(session, entry_node) if entry_node is not None else None,
        "current_node": _node_runtime_payload(session, current_node) if current_node is not None else None,
    }


def _runtime_response(session: SwarmSession, state_manager: SessionStateManager) -> Dict[str, Any]:
    return {"runtime": _runtime_payload(session, state_manager)}


def _session_payload(session: SwarmSession, state_manager: SessionStateManager) -> Dict[str, Any]:
    del state_manager
    return {
        "id": session.id,
        "swarm_id": session.swarm.id,
        "swarm_name": session.swarm.name,
        "graph_version": session.swarm.graph_version,
        "current_node_id": session.current_node_id,
        "current_node_key": session.current_node.node_key if session.current_node else None,
        "current_agent": session.current_node.name if session.current_node else None,
        "state": copy.deepcopy(session.state),
        "snapshot": session.snapshot(),
    }


def state_response(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "state": payload,
        "variables": copy.deepcopy(payload),
    }


def _sse_event(event: str, payload: Dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


def build_fastapi_app(*, title: str, version: str, cors_allow_origins: List[str] | None) -> FastAPI:
    app = FastAPI(title=title, version=version)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_allow_origins or ["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app


def default_turn_runner_factory(model_config: ModelConfig) -> AgentTurnRunner:
    return _build_turn_runner(model_config)


class FastApiSessionService:
    def __init__(
        self,
        *,
        store: SessionStore,
        default_model_config: ModelConfig | None = None,
        turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
        extract_required_variables: RequiredVariableExtractor | None = None,
        state_manager_factory: Callable[[SwarmDefinition], SessionStateManager] | None = None,
        global_variable_manager_factory: Callable[[SwarmDefinition], SessionStateManager] | None = None,
        tool_registry: ToolRegistry | None = None,
        tool_state: Any = None,
    ) -> None:
        if state_manager_factory is not None and global_variable_manager_factory is not None:
            raise ValueError("Pass either state_manager_factory or global_variable_manager_factory, not both.")
        self.store = store
        self.default_model_config = default_model_config
        self.turn_runner_factory = turn_runner_factory or default_turn_runner_factory
        self.extract_required_variables = extract_required_variables
        self.state_manager_factory = (
            state_manager_factory or global_variable_manager_factory or SessionStateManager.from_swarm
        )
        self.tool_registry = tool_registry
        self.tool_state = tool_state

    def state_manager_for(self, swarm: SwarmDefinition) -> SessionStateManager:
        return self.state_manager_factory(swarm)

    def variable_manager_for(self, swarm: SwarmDefinition) -> SessionStateManager:
        return self.state_manager_for(swarm)

    def session_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return _session_payload(session, self.variable_manager_for(session.swarm))

    def variable_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return self.state_payload(session)

    def state_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return self.state_manager_for(session.swarm).snapshot(session, current_node=session.current_node)

    def runtime_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return _runtime_response(session, self.state_manager_for(session.swarm))

    def initialize_session_variables(self, session: SwarmSession, values: Dict[str, Any] | None) -> None:
        self.initialize_session_state(session, values)

    def initialize_session_state(self, session: SwarmSession, values: Dict[str, Any] | None) -> None:
        self.state_manager_for(session.swarm).update_state(session, values, current_node=session.current_node)

    def update_session_variables(self, session: SwarmSession, request: SessionVariableUpdateRequest) -> None:
        self.update_session_state(session, request)

    def update_session_state(self, session: SwarmSession, request: SessionVariableUpdateRequest) -> None:
        manager = self.state_manager_for(session.swarm)
        mode = str(request.mode or "merge").strip().lower() or "merge"
        if mode == "replace":
            manager.replace_state(session, request.state, current_node=session.current_node)
        else:
            manager.update_state(session, request.state, current_node=session.current_node)
        session.touch()

    def apply_turn_variables(self, session: SwarmSession, values: Dict[str, Any] | None) -> None:
        self.apply_turn_state(session, values)

    def apply_turn_state(self, session: SwarmSession, values: Dict[str, Any] | None) -> None:
        manager = self.state_manager_for(session.swarm)
        manager.update_state(session, values or {}, current_node=session.current_node)
        session.touch()

    def resolve_model_config(self) -> ModelConfig:
        return self.default_model_config or ModelConfig()

    async def run_turn(
        self,
        session: SwarmSession,
        *,
        user_input: str,
    ) -> Dict[str, Any]:
        turn_runner = self.turn_runner_factory(self.resolve_model_config())
        state_manager = self.state_manager_for(session.swarm)
        events: List[Dict[str, Any]] = []
        async for event in process_swarm_stream(
            session,
            user_input,
            store=self.store,
            turn_runner=turn_runner,
            extract_required_variables=self.extract_required_variables,
            state_manager=state_manager,
            tool_registry=self.tool_registry,
            tool_state=self.tool_state,
        ):
            events.append(event)
        checkpoints = await self.store.list_checkpoints(session.id)
        return {
            "events": events,
            "session": _session_payload(session, state_manager),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    def stream_turn(
        self,
        session: SwarmSession,
        *,
        user_input: str,
    ) -> StreamingResponse:
        async def event_generator() -> AsyncGenerator[str, None]:
            try:
                turn_runner = self.turn_runner_factory(self.resolve_model_config())
                state_manager = self.state_manager_for(session.swarm)
                async for event in process_swarm_stream(
                    session,
                    user_input,
                    store=self.store,
                    turn_runner=turn_runner,
                    extract_required_variables=self.extract_required_variables,
                    state_manager=state_manager,
                    tool_registry=self.tool_registry,
                    tool_state=self.tool_state,
                ):
                    yield _sse_event(event["event"], event["data"])
                checkpoints = await self.store.list_checkpoints(session.id)
                yield _sse_event("session", _session_payload(session, state_manager))
                yield _sse_event("checkpoints", {"items": serialize_checkpoints(checkpoints)})
            except Exception as exc:
                yield _sse_event("error", {"message": str(exc)})

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )


class SwarmApiRuntime:
    def __init__(self, store: SessionStore) -> None:
        self.store = store

    async def create_session(self, *, swarm: SwarmDefinition, session_id: str | None, state: Dict[str, Any]) -> SwarmSession:
        resolved_session_id = session_id or uuid.uuid4().hex
        existing = await self.store.get_session(resolved_session_id)
        if existing is not None:
            raise ValueError(f"Session '{resolved_session_id}' already exists")
        session = SwarmSession.from_state(
            id=resolved_session_id,
            swarm=swarm,
            state=state,
        )
        await self.store.save_session(session)
        return session

    async def get_session(self, session_id: str) -> SwarmSession:
        session = await self.store.get_session(session_id)
        if session is None:
            raise KeyError(session_id)
        return session
