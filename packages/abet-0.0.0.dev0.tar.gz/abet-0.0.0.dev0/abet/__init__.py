print('z')
