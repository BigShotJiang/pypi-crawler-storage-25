import * as React from "react";
import { createRoot } from "react-dom/client";
import { JsonViewer, defineEasyType } from "@textea/json-viewer";
import createCache from "@emotion/cache";
import { CacheProvider } from "@emotion/react";

// JavaScript has a single Number type, so a Python float that happens to be a
// whole number (1.0, 0.0, -2.0) is indistinguishable from a Python int once
// JSON-parsed. The Python encoder tags such values; we wrap them in this
// marker class so the library's built-in `intType` (which matches by
// `typeof === "number"`) doesn't pick them up, and our custom `pyFloatType`
// below renders them with the "float" label.
class PyFloat {
  constructor(value) {
    this.value = value;
  }
}

const pyFloatType = defineEasyType({
  is: (v) => v instanceof PyFloat,
  type: "float",
  colorKey: "base0B",
  serialize: (v) => v.value.toString(),
  deserialize: (s) => new PyFloat(parseFloat(s)),
  Renderer: ({ value }) => {
    // Show whole-number floats as "1.0" rather than "1" so they read as
    // floats at a glance, matching how Python's repr() formats them.
    const display = Number.isInteger(value.value)
      ? value.value.toFixed(1)
      : value.value.toString();
    return <>{display}</>;
  },
});

const VALUE_TYPES = [pyFloatType];

// Mirrors src/anyjsonviewer/__init__.py:_TAG. Tagged dicts coming from Python
// represent values that don't survive a JSON round-trip and need to be
// rehydrated into real JS objects so @textea/json-viewer's built-in type
// handlers (dateType, the Set renderer, etc.) can display them properly.
const TAG = "__jsonview_type__";

function encodeValue(node) {
  if (node === null || node === undefined) return node;
  if (node instanceof PyFloat) {
    return { [TAG]: "float", value: node.value };
  }
  if (node instanceof Date) {
    return { [TAG]: "datetime", iso: node.toISOString() };
  }
  if (node instanceof Set) {
    return { [TAG]: "set", items: [...node].map(encodeValue) };
  }
  if (node instanceof Uint8Array) {
    let bin = "";
    for (let i = 0; i < node.length; i++) bin += String.fromCharCode(node[i]);
    return { [TAG]: "bytes", b64: btoa(bin) };
  }
  if (Array.isArray(node)) return node.map(encodeValue);
  if (typeof node === "object") {
    const out = {};
    for (const [k, v] of Object.entries(node)) out[k] = encodeValue(v);
    return out;
  }
  return node;
}

function decodeValue(node) {
  if (node === null || typeof node !== "object") return node;
  if (Array.isArray(node)) return node.map(decodeValue);
  if (typeof node[TAG] === "string") {
    switch (node[TAG]) {
      case "datetime":
      case "date":
        return new Date(node.iso);
      case "set":
        return new Set(node.items.map(decodeValue));
      case "bytes": {
        const bin = atob(node.b64);
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        return arr;
      }
      case "float":
        return new PyFloat(node.value);
    }
  }
  const out = {};
  for (const [k, v] of Object.entries(node)) out[k] = decodeValue(v);
  return out;
}

const PROPS = [
  "data",
  "root_name",
  "theme",
  "class_name",
  "style",
  "indent_width",
  "default_inspect_depth",
  "max_display_length",
  "group_arrays_after_length",
  "collapse_strings_after_length",
  "object_sort_keys",
  "quotes_on_keys",
  "display_data_types",
  "display_size",
  "display_comma",
  "highlight_updates",
  "enable_clipboard",
  "enable_add",
  "enable_delete",
  "editable",
];

// Apply an edit/add/delete operation to a JSON value at the given path.
function applyChange(root, path, newValue, op) {
  // Clone along the path so React/traitlets sees a new object identity.
  if (path.length === 0) return newValue;
  const cloneStep = (node) => (Array.isArray(node) ? [...node] : { ...node });
  const newRoot = cloneStep(root);
  let parent = newRoot;
  for (let i = 0; i < path.length - 1; i++) {
    const key = path[i];
    parent[key] = cloneStep(parent[key]);
    parent = parent[key];
  }
  const lastKey = path[path.length - 1];
  if (op === "delete") {
    if (Array.isArray(parent)) parent.splice(lastKey, 1);
    else delete parent[lastKey];
  } else {
    parent[lastKey] = newValue;
  }
  return newRoot;
}

// Props that @textea/json-viewer bakes into its internal Zustand store on
// first mount and never re-reads (see createJsonViewerStore in
// node_modules/@textea/json-viewer/dist/index.mjs — the useMemo there has an
// empty deps array). Changing any of these requires remounting the component
// via a different React `key`. The remaining props (data, theme, class_name,
// style) are read directly from props on every render and update live.
const STORE_BAKED_PROPS = [
  "root_name",
  "indent_width",
  "default_inspect_depth",
  "max_display_length",
  "group_arrays_after_length",
  "collapse_strings_after_length",
  "object_sort_keys",
  "quotes_on_keys",
  "display_data_types",
  "display_size",
  "display_comma",
  "highlight_updates",
  "enable_clipboard",
  "enable_add",
  "enable_delete",
  "editable",
];

function Widget({ model }) {
  const [, force] = React.useReducer((x) => x + 1, 0);

  React.useEffect(() => {
    for (const p of PROPS) model.on(`change:${p}`, force);
    return () => {
      for (const p of PROPS) model.off(`change:${p}`, force);
    };
  }, [model]);

  const remountKey = STORE_BAKED_PROPS.map((p) => JSON.stringify(model.get(p))).join("|");
  const decodedData = React.useMemo(() => decodeValue(model.get("data")), [model.get("data")]);

  const handleChange = React.useCallback(
    (path, _oldVal, newVal) => {
      const current = decodeValue(model.get("data"));
      const next = applyChange(current, path, newVal, "set");
      model.set("data", encodeValue(next));
      model.save_changes();
    },
    [model],
  );

  const handleDelete = React.useCallback(
    (path) => {
      const current = decodeValue(model.get("data"));
      const next = applyChange(current, path, undefined, "delete");
      model.set("data", encodeValue(next));
      model.save_changes();
    },
    [model],
  );

  return (
    <JsonViewer
      key={remountKey}
      value={decodedData}
      rootName={model.get("root_name") ?? false}
      theme={model.get("theme")}
      className={model.get("class_name") ?? undefined}
      style={model.get("style") ?? undefined}
      indentWidth={model.get("indent_width")}
      defaultInspectDepth={model.get("default_inspect_depth")}
      maxDisplayLength={model.get("max_display_length")}
      groupArraysAfterLength={model.get("group_arrays_after_length")}
      collapseStringsAfterLength={model.get("collapse_strings_after_length")}
      objectSortKeys={model.get("object_sort_keys")}
      quotesOnKeys={model.get("quotes_on_keys")}
      displayDataTypes={model.get("display_data_types")}
      displaySize={model.get("display_size")}
      displayComma={model.get("display_comma")}
      highlightUpdates={model.get("highlight_updates")}
      enableClipboard={model.get("enable_clipboard")}
      enableAdd={model.get("enable_add")}
      enableDelete={model.get("enable_delete")}
      editable={model.get("editable")}
      valueTypes={VALUE_TYPES}
      onChange={handleChange}
      onDelete={handleDelete}
    />
  );
}

// Marimo (and some other anywidget hosts) render widgets inside a Shadow DOM.
// MUI's emotion CSS-in-JS injects its <style> tags into document.head by
// default, but Shadow DOM is style-isolated, so those rules never reach the
// MUI components inside the widget — every flex container collapses to
// display:block and the layout falls apart. Fix: build an emotion cache
// pointing at the shadow root (or document.head when not in a shadow root)
// and wrap the tree in a CacheProvider so emotion injects styles where they
// can actually be seen by the components.
function getStyleContainer(node) {
  const root = node.getRootNode();
  if (typeof ShadowRoot !== "undefined" && root instanceof ShadowRoot) {
    return root;
  }
  return document.head;
}

function render({ model, el }) {
  const container = document.createElement("div");
  container.className = "anyjsonviewer-root";
  el.appendChild(container);

  const cache = createCache({
    key: "anyjv",
    container: getStyleContainer(container),
    prepend: true,
  });

  const root = createRoot(container);
  root.render(
    <CacheProvider value={cache}>
      <Widget model={model} />
    </CacheProvider>,
  );
  return () => root.unmount();
}

export default { render };
