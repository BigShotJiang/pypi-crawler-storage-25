import base64
import datetime as _dt
import pathlib

import anywidget
import traitlets

_STATIC = pathlib.Path(__file__).parent / "static"

# Sentinel key used to mark non-JSON-native Python values so the JS side can
# reconstruct them as the appropriate JS object (e.g. Date, Set, Uint8Array).
# `@textea/json-viewer` then renders them with its built-in type handlers.
_TAG = "__jsonview_type__"


def _encode(value):
    # bool is a subclass of int in Python — keep it as-is so the JS side
    # classifies it as boolean, not as a number.
    if isinstance(value, bool):
        return value
    if isinstance(value, _dt.datetime):
        return {_TAG: "datetime", "iso": value.isoformat()}
    if isinstance(value, _dt.date):
        return {_TAG: "date", "iso": value.isoformat()}
    if isinstance(value, (set, frozenset)):
        return {_TAG: "set", "items": [_encode(v) for v in value]}
    if isinstance(value, bytes):
        return {_TAG: "bytes", "b64": base64.b64encode(value).decode("ascii")}
    # Whole-number floats (0.0, 1.0, -2.0, …) need tagging because JS has a
    # single Number type and can't tell them apart from ints once parsed.
    # Fractional floats (0.5, 1e-5, …) survive the round-trip because
    # Number.isInteger returns false for them.
    if isinstance(value, float) and value.is_integer():
        return {_TAG: "float", "value": value}
    if isinstance(value, dict):
        return {k: _encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(v) for v in value]
    return value


def _decode(value):
    if isinstance(value, dict):
        tag = value.get(_TAG)
        if tag == "datetime":
            return _dt.datetime.fromisoformat(value["iso"])
        if tag == "date":
            return _dt.date.fromisoformat(value["iso"])
        if tag == "set":
            return {_decode(v) for v in value["items"]}
        if tag == "bytes":
            return base64.b64decode(value["b64"])
        if tag == "float":
            return float(value["value"])
        return {k: _decode(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_decode(v) for v in value]
    return value


def _data_to_json(value, _widget):
    return _encode(value)


def _data_from_json(value, _widget):
    return _decode(value)


class JsonViewer(anywidget.AnyWidget):
    _esm = _STATIC / "widget.js"
    _css = _STATIC / "widget.css"

    # Data
    data = traitlets.Any(default_value=None).tag(
        sync=True, to_json=_data_to_json, from_json=_data_from_json
    )

    # Display
    root_name = traitlets.Unicode(default_value="root", allow_none=True).tag(sync=True)
    theme = traitlets.Unicode("light").tag(sync=True)  # "light" | "dark" | "auto"
    class_name = traitlets.Unicode(default_value=None, allow_none=True).tag(sync=True)
    style = traitlets.Dict(default_value=None, allow_none=True).tag(sync=True)

    # Layout
    indent_width = traitlets.Int(3).tag(sync=True)
    default_inspect_depth = traitlets.Int(5).tag(sync=True)
    max_display_length = traitlets.Int(30).tag(sync=True)
    group_arrays_after_length = traitlets.Int(100).tag(sync=True)
    collapse_strings_after_length = traitlets.Int(50).tag(sync=True)

    # Formatting
    object_sort_keys = traitlets.Bool(False).tag(sync=True)
    quotes_on_keys = traitlets.Bool(True).tag(sync=True)
    display_data_types = traitlets.Bool(True).tag(sync=True)
    display_size = traitlets.Bool(True).tag(sync=True)
    display_comma = traitlets.Bool(True).tag(sync=True)
    highlight_updates = traitlets.Bool(True).tag(sync=True)

    # Interaction
    enable_clipboard = traitlets.Bool(False).tag(sync=True)
    enable_add = traitlets.Bool(False).tag(sync=True)
    enable_delete = traitlets.Bool(False).tag(sync=True)
    editable = traitlets.Bool(False).tag(sync=True)
