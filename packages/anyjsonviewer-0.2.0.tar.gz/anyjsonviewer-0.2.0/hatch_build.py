import os
import shutil
import subprocess
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

ROOT = Path(__file__).parent
BUNDLE = ROOT / "src" / "anyjsonviewer" / "static" / "widget.js"


class JsBuildHook(BuildHookInterface):
    PLUGIN_NAME = "anyjsonviewer-js"

    def initialize(self, version, build_data):
        if os.environ.get("ANYJSONVIEWER_SKIP_JS_BUILD"):
            return
        if shutil.which("npm") is None:
            if BUNDLE.exists():
                self.app.display_warning(
                    "npm not found; using existing bundled widget.js"
                )
                return
            raise RuntimeError(
                "npm is required to build the JS bundle and no prebuilt "
                "widget.js was found. Install Node.js or set "
                "ANYJSONVIEWER_SKIP_JS_BUILD=1 if you know what you're doing."
            )
        if not (ROOT / "node_modules").exists():
            subprocess.run(["npm", "install"], cwd=ROOT, check=True)
        subprocess.run(["npm", "run", "build"], cwd=ROOT, check=True)
        if not BUNDLE.exists():
            raise RuntimeError(f"JS build did not produce {BUNDLE}")
