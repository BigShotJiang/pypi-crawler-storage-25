# wall-paper

## installation:
```pip install wall-paper```

## Change wallpaper:
```python
import wall_paper

wall_paper.ChangeWallpaper("C:/path/to/image/")
```
## Remove wallpaper
```python
import wall_paper

wall_paper.RemoveWallpaper()
```
