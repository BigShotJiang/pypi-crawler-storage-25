import ctypes

class ChangeWallpaper:
    def __init__(self, image_path):
        self.image_path = image_path

        ctypes.windll.user32.SystemParametersInfoW(0x0014, 0, image_path, 0x0001 | 0x0002)

class RemoveWallpaper:
    def __init__(self):
        ctypes.windll.user32.SystemParametersInfoW(0x0014, 0, "", 0x0001 | 0x0002)
