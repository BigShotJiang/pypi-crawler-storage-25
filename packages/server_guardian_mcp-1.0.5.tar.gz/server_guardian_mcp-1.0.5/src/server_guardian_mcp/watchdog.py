"""
Server Guardian MCP — Background Watchdog Daemon

Runs 24/7 independently of the MCP server. No AI, no API cost.
Periodically checks server health, failed services, and endpoints.
Sends email or webhook alerts when thresholds are breached.

Usage:
    python -m server_guardian_mcp.watchdog           # run forever
    python -m server_guardian_mcp.watchdog --once     # run one cycle and exit

Writes to the same SQLite DB as the MCP server, so Claude can query
the history via get_monitoring_history and get_active_alerts.
"""

import json
import logging
import os
import smtplib
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

# Import shared infrastructure
from . import db as _db
from .server import (
    _ENV_FILE,
    _HEALTH_SCRIPT,
    _do_http_check,
    _do_ssl_check,
    _env,
    _env_int,
    _load_env,
    _parse_sections,
    _ssh_exec,
    _ssh_exec_script,
    SERVER_PROFILES,
)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [watchdog] %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("watchdog")

# ---------------------------------------------------------------------------
# Watchdog configuration from .env
# ---------------------------------------------------------------------------
WATCHDOG_INTERVAL = _env_int("WATCHDOG_INTERVAL", 300)  # seconds between cycles
WATCHDOG_HEALTH_ENABLED = _env("WATCHDOG_HEALTH_ENABLED", "true").lower() == "true"
WATCHDOG_SERVICES_ENABLED = _env("WATCHDOG_SERVICES_ENABLED", "true").lower() == "true"
WATCHDOG_ENDPOINTS_ENABLED = _env("WATCHDOG_ENDPOINTS_ENABLED", "true").lower() == "true"
WATCHDOG_AUTO_RESTART = _env("WATCHDOG_AUTO_RESTART", "false").lower() == "true"

# Endpoints to monitor (comma-separated URLs and/or domains)
WATCHDOG_ENDPOINTS = [
    e.strip() for e in _env("WATCHDOG_ENDPOINTS", "").split(",") if e.strip()
]

# Alert delivery
ALERT_EMAIL = _env("ALERT_EMAIL", "")
SMTP_HOST = _env("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = _env_int("SMTP_PORT", 587)
SMTP_USER = _env("SMTP_USER", "")
SMTP_PASSWORD = _env("SMTP_PASSWORD", "")
SMTP_FROM = _env("SMTP_FROM", "") or SMTP_USER

ALERT_WEBHOOK = _env("ALERT_WEBHOOK", "")  # Slack, Discord, or any webhook URL
ALERT_DISCORD_WEBHOOK = _env("ALERT_DISCORD_WEBHOOK", "")

# SSH settings (reused from server.py module-level globals)
SSH_CONNECT_TIMEOUT = _env_int("SSH_CONNECT_TIMEOUT", 10)
DEFAULT_CMD_TIMEOUT = _env_int("DEFAULT_CMD_TIMEOUT", 30)
DEFAULT_SCRIPT_TIMEOUT = _env_int("DEFAULT_SCRIPT_TIMEOUT", 120)


# ---------------------------------------------------------------------------
# Alert delivery
# ---------------------------------------------------------------------------
def _send_email(subject: str, body_html: str) -> bool:
    """Send an HTML alert email via SMTP. Returns True on success."""
    if not ALERT_EMAIL or not SMTP_USER or not SMTP_PASSWORD:
        return False
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[Server Guardian] {subject}"
        msg["From"] = SMTP_FROM
        msg["To"] = ALERT_EMAIL

        # Plain text fallback (strip HTML tags roughly)
        import re as _re
        plain = _re.sub(r"<[^>]+>", "", body_html).strip()
        msg.attach(MIMEText(plain, "plain", "utf-8"))
        msg.attach(MIMEText(body_html, "html", "utf-8"))

        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        log.info(f"Email sent: {subject}")
        return True
    except Exception as e:
        log.error(f"Email failed: {e}")
        return False


def _send_webhook(subject: str, body: str) -> bool:
    """Send an alert to a Slack/generic webhook. Returns True on success."""
    if not ALERT_WEBHOOK:
        return False
    try:
        payload = json.dumps({"text": f"*{subject}*\n```{body}```"}).encode("utf-8")
        req = urllib.request.Request(
            ALERT_WEBHOOK,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
        log.info(f"Webhook sent: {subject}")
        return True
    except Exception as e:
        log.error(f"Webhook failed: {e}")
        return False


def _send_discord(subject: str, body: str) -> bool:
    """Send an alert to a Discord webhook. Returns True on success."""
    if not ALERT_DISCORD_WEBHOOK:
        return False
    try:
        payload = json.dumps({
            "content": f"**{subject}**\n```\n{body}\n```",
        }).encode("utf-8")
        req = urllib.request.Request(
            ALERT_DISCORD_WEBHOOK,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
        log.info(f"Discord sent: {subject}")
        return True
    except Exception as e:
        log.error(f"Discord failed: {e}")
        return False


def send_alert(subject: str, plain_body: str, html_body: str = "") -> None:
    """Send alert via all configured channels.
    plain_body is used for Slack/Discord/log. html_body is used for email."""
    if not html_body:
        html_body = f"<pre>{plain_body}</pre>"
    sent = False
    if ALERT_EMAIL:
        sent = _send_email(subject, html_body) or sent
    if ALERT_WEBHOOK:
        sent = _send_webhook(subject, plain_body) or sent
    if ALERT_DISCORD_WEBHOOK:
        sent = _send_discord(subject, plain_body) or sent
    if not sent:
        log.warning(f"ALERT (no delivery configured): {subject}\n{plain_body}")


# ---------------------------------------------------------------------------
# Rich email templates
# ---------------------------------------------------------------------------
def _severity_color(severity: str) -> str:
    return {"critical": "#dc3545", "warning": "#fd7e14", "info": "#0d6efd"}.get(severity, "#6c757d")


def _email_wrapper(title: str, severity: str, content_html: str) -> str:
    """Wrap alert content in a styled HTML email template."""
    color = _severity_color(severity)
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; padding: 20px; margin: 0;">
  <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
    <div style="background: {color}; color: white; padding: 16px 24px;">
      <h2 style="margin: 0; font-size: 18px;">{severity.upper()} &mdash; {title}</h2>
      <p style="margin: 4px 0 0; font-size: 12px; opacity: 0.85;">{timestamp}</p>
    </div>
    <div style="padding: 24px;">
      {content_html}
    </div>
    <div style="padding: 12px 24px; background: #f8f9fa; border-top: 1px solid #e9ecef; font-size: 11px; color: #6c757d;">
      Server Guardian MCP &mdash; Watchdog Alert
    </div>
  </div>
</body>
</html>"""


def _build_service_alert(server_name: str, host: str, failed_services: list[str]) -> tuple[str, str, str]:
    """Build subject, plain text, and HTML for a failed services alert.
    Returns (subject, plain_body, html_body)."""
    subject = f"WARNING: {len(failed_services)} failed service{'s' if len(failed_services) != 1 else ''} on {server_name}"

    plain_lines = [
        f"Server: {server_name} ({host})",
        f"Failed services: {len(failed_services)}",
        "",
    ]
    for svc in failed_services:
        plain_lines.append(f"  - {svc}")
    plain_lines += [
        "",
        "Action needed:",
        "  Check logs:  journalctl -u <service> -n 50",
        "  Restart:     systemctl restart <service>",
        "  Or ask Claude: 'restart failed services on " + server_name + "'",
    ]
    plain_body = "\n".join(plain_lines)

    rows = ""
    for svc in failed_services:
        svc_short = svc.replace(".service", "")
        rows += f"""<tr>
          <td style="padding: 8px 12px; border-bottom: 1px solid #eee; font-family: monospace;">{svc}</td>
          <td style="padding: 8px 12px; border-bottom: 1px solid #eee; color: #dc3545; font-weight: bold;">FAILED</td>
          <td style="padding: 8px 12px; border-bottom: 1px solid #eee; font-family: monospace; font-size: 12px;">journalctl -u {svc_short} -n 50</td>
        </tr>"""

    content = f"""
      <p style="margin: 0 0 12px;"><strong>Server:</strong> {server_name} &nbsp;|&nbsp; <strong>Host:</strong> <code>{host}</code></p>
      <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
        <thead>
          <tr style="background: #f8f9fa;">
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #dee2e6;">Service</th>
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #dee2e6;">Status</th>
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #dee2e6;">Check Logs</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
      <div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; padding: 12px; margin-top: 16px;">
        <strong>What to do:</strong>
        <ol style="margin: 8px 0 0; padding-left: 20px;">
          <li>Check the logs for each service using the commands above</li>
          <li>Restart manually: <code>systemctl restart &lt;service&gt;</code></li>
          <li>Or tell Claude: <em>"restart failed services on {server_name}"</em></li>
        </ol>
      </div>"""

    html_body = _email_wrapper(f"Failed services on {server_name}", "warning", content)
    return subject, plain_body, html_body


def _build_health_alert(server_name: str, host: str, alert_msg: str,
                        severity: str, category: str, metrics: dict = None) -> tuple[str, str, str]:
    """Build subject, plain text, and HTML for a health threshold alert."""
    subject = f"{severity.upper()}: {category.replace('_', ' ').title()} on {server_name}"

    plain_body = f"Server: {server_name} ({host})\n{alert_msg}"

    metrics_html = ""
    if metrics:
        metrics_html = """<table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
          <thead><tr style="background: #f8f9fa;">
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #dee2e6;">Metric</th>
            <th style="padding: 8px 12px; text-align: left; border-bottom: 2px solid #dee2e6;">Value</th>
          </tr></thead><tbody>"""
        metric_labels = {
            "cpu_load": "CPU Load", "cpu_cores": "CPU Cores",
            "memory_used_pct": "Memory Used", "disk_used_pct": "Disk Used",
            "temperature_c": "Temperature", "uptime_seconds": "Uptime",
        }
        for key, label in metric_labels.items():
            val = metrics.get(key)
            if val is not None:
                display = f"{val}%" if "pct" in key else f"{val}°C" if "temp" in key else str(val)
                if key == "uptime_seconds":
                    days = val // 86400
                    hours = (val % 86400) // 3600
                    display = f"{days}d {hours}h"
                color = ""
                if key == "disk_used_pct" and val > 80:
                    color = ' style="color: #dc3545; font-weight: bold;"'
                elif key == "cpu_load" and metrics.get("cpu_cores") and val > metrics["cpu_cores"] * 2:
                    color = ' style="color: #dc3545; font-weight: bold;"'
                metrics_html += f'<tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;">{label}</td><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"{color}>{display}</td></tr>'
        metrics_html += "</tbody></table>"

    content = f"""
      <p style="margin: 0 0 12px;"><strong>Server:</strong> {server_name} &nbsp;|&nbsp; <strong>Host:</strong> <code>{host}</code></p>
      <div style="background: {'#f8d7da' if severity == 'critical' else '#fff3cd'}; border: 1px solid {'#f5c6cb' if severity == 'critical' else '#ffc107'}; border-radius: 4px; padding: 12px; margin: 12px 0;">
        <strong>{alert_msg}</strong>
      </div>
      {metrics_html}
      <p style="color: #6c757d; font-size: 13px; margin-top: 16px;">
        Ask Claude: <em>"check health of {server_name}"</em> or <em>"analyze disk usage on {server_name}"</em>
      </p>"""

    html_body = _email_wrapper(f"{category.replace('_', ' ').title()} on {server_name}", severity, content)
    return subject, plain_body, html_body


def _build_unreachable_alert(server_name: str, host: str, error: str) -> tuple[str, str, str]:
    """Build alert for an unreachable server."""
    subject = f"CRITICAL: Server {server_name} unreachable"
    plain_body = f"Server: {server_name} ({host})\nCannot connect: {error}"

    content = f"""
      <p style="margin: 0 0 12px;"><strong>Server:</strong> {server_name} &nbsp;|&nbsp; <strong>Host:</strong> <code>{host}</code></p>
      <div style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; padding: 12px; margin: 12px 0;">
        <strong>Cannot connect to server via SSH</strong><br>
        <code style="font-size: 12px; color: #721c24;">{error}</code>
      </div>
      <div style="margin-top: 16px;">
        <strong>Possible causes:</strong>
        <ul style="margin: 8px 0; padding-left: 20px;">
          <li>Server is powered off or rebooting</li>
          <li>Network issue between you and the server</li>
          <li>SSH service (sshd) crashed on the server</li>
          <li>Firewall blocking port {host.split(':')[-1] if ':' in host else '22'}</li>
          <li>Wrong IP address or credentials in .env</li>
        </ul>
      </div>"""

    html_body = _email_wrapper(f"Server {server_name} unreachable", "critical", content)
    return subject, plain_body, html_body


def _build_endpoint_alert(target: str, check_type: str, status: str,
                          details: dict) -> tuple[str, str, str]:
    """Build alert for endpoint failures."""
    severity = "critical" if status in ("FAIL", "EXPIRED", "CRITICAL", "INVALID") else "warning"
    subject = f"{severity.upper()}: {check_type.upper()} check — {target}"

    if check_type == "ssl":
        days = details.get("days_until_expiry", "?")
        plain_body = f"SSL certificate for {target}: {status}\nDays until expiry: {days}"
        content = f"""
          <p><strong>Domain:</strong> <code>{target}</code></p>
          <table style="width: 100%; border-collapse: collapse; margin: 12px 0;">
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Status</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee; color: {_severity_color(severity)}; font-weight: bold;">{status}</td></tr>
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Days Left</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee;">{days}</td></tr>
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Issuer</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee;">{details.get('issuer', 'N/A')}</td></tr>
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Valid Until</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee;">{details.get('valid_until', 'N/A')}</td></tr>
          </table>
          <p style="color: #6c757d; font-size: 13px;">Renew the certificate before it expires to avoid downtime.</p>"""
    else:
        error = details.get("error", "Non-200 response")
        status_code = details.get("status_code", "N/A")
        plain_body = f"HTTP check failed for {target}\nStatus: {status_code}\nError: {error}"
        content = f"""
          <p><strong>URL:</strong> <code>{target}</code></p>
          <table style="width: 100%; border-collapse: collapse; margin: 12px 0;">
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Result</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee; color: #dc3545; font-weight: bold;">FAIL</td></tr>
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Status Code</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee;">{status_code}</td></tr>
            <tr><td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><strong>Error</strong></td>
                <td style="padding: 6px 12px; border-bottom: 1px solid #eee;"><code>{error}</code></td></tr>
          </table>
          <p style="color: #6c757d; font-size: 13px;">Check if the service is running and responding correctly.</p>"""

    html_body = _email_wrapper(f"{check_type.upper()} check — {target}", severity, content)
    return subject, plain_body, html_body


# ---------------------------------------------------------------------------
# Health check cycle
# ---------------------------------------------------------------------------
def check_all_health() -> list[dict]:
    """Run health checks on all configured servers. Store in DB. Alert on issues."""
    results = []
    for name, profile in sorted(SERVER_PROFILES.items()):
        info = {**profile, "name": name}
        log.info(f"Checking health: {name} ({profile['host']})")

        try:
            result = _ssh_exec_script(info, _HEALTH_SCRIPT, timeout=30)
            sections = _parse_sections(result.get("stdout", ""))

            row_id, alerts = _db.record_health(name, sections)

            if alerts > 0:
                # Get parsed metrics for rich email
                metrics = _db._parse_health_metrics(sections)
                recent_alerts = _db.get_alerts(server_name=name, resolved=False)
                for alert in recent_alerts:
                    subj, plain, html = _build_health_alert(
                        name, profile["host"], alert["message"],
                        alert["severity"], alert["category"], metrics,
                    )
                    send_alert(subj, plain, html)

            results.append({"server": name, "status": "ok", "alerts": alerts})
            log.info(f"  {name}: health stored (id={row_id}), {alerts} alerts")

        except Exception as e:
            log.error(f"  {name}: health check failed: {e}")
            try:
                _db.record_alert(name, "critical", "unreachable",
                                 f"Server {name} ({profile['host']}) is unreachable: {e}")
                subj, plain, html = _build_unreachable_alert(name, profile["host"], str(e))
                send_alert(subj, plain, html)
            except Exception:
                pass
            results.append({"server": name, "status": "unreachable", "error": str(e)})

    return results


# ---------------------------------------------------------------------------
# Failed services check cycle
# ---------------------------------------------------------------------------
def check_all_services() -> list[dict]:
    """Check for failed services on all servers. Alert on failures."""
    results = []
    for name, profile in sorted(SERVER_PROFILES.items()):
        info = {**profile, "name": name}
        log.info(f"Checking services: {name}")

        try:
            cmd = "systemctl --failed --no-pager --no-legend 2>&1"
            ssh_results = _ssh_exec(info, [cmd], per_cmd_timeout=15)
            raw = ssh_results[0].get("stdout", "") if ssh_results else ""

            failed = []
            for line in raw.splitlines():
                line = line.strip()
                if not line or "0 loaded" in line.lower():
                    continue
                if line and line[0] in ("●", "*", "\u25cf"):
                    line = line[1:].strip()
                parts = line.split(None, 1)
                if parts:
                    failed.append(parts[0])

            if failed:
                msg = f"{len(failed)} failed services on {name}: {', '.join(failed)}"
                log.warning(f"  {msg}")
                _db.record_alert(name, "warning", "service_down", msg)
                subj, plain, html = _build_service_alert(name, profile["host"], failed)
                send_alert(subj, plain, html)

                # Auto-restart if enabled
                if WATCHDOG_AUTO_RESTART:
                    log.info(f"  Auto-restarting {len(failed)} services on {name}...")
                    for svc in failed:
                        try:
                            restart_cmd = f"systemctl restart {svc} 2>&1; systemctl is-active {svc} 2>&1"
                            r = _ssh_exec(info, [restart_cmd], per_cmd_timeout=30)
                            output = r[0].get("stdout", "") if r else ""
                            new_status = output.strip().split("\n")[-1].strip()
                            _db.record_service_event(name, svc, "failed", new_status, "auto-restarted")
                            log.info(f"    {svc}: {new_status}")
                        except Exception as e:
                            log.error(f"    {svc}: restart failed: {e}")

                for svc in failed:
                    _db.record_service_event(name, svc, "unknown", "failed", "detected")

            results.append({"server": name, "failed_count": len(failed), "failed": failed})

        except Exception as e:
            log.error(f"  {name}: service check failed: {e}")
            results.append({"server": name, "error": str(e)})

    return results


# ---------------------------------------------------------------------------
# Endpoint check cycle
# ---------------------------------------------------------------------------
def check_all_endpoints() -> list[dict]:
    """Check all configured endpoints. Store in DB. Alert on failures."""
    results = []
    for target in WATCHDOG_ENDPOINTS:
        target = target.strip()
        if not target:
            continue

        log.info(f"Checking endpoint: {target}")

        try:
            if target.startswith("http://") or target.startswith("https://"):
                check = _do_http_check(target)
                check_type = "http"
                status = check.get("result", "FAIL")
                response_time = check.get("response_time_ms")
            else:
                domain = target.split(":")[0]
                port = 443
                if ":" in target:
                    try:
                        port = int(target.split(":")[1])
                    except ValueError:
                        pass
                check = _do_ssl_check(domain, port)
                check_type = "ssl"
                status = check.get("status", "ERROR")
                response_time = None

            _db.record_endpoint_check(target, check_type, status, response_time, check)

            # Alert on failures
            if check_type == "http" and status == "FAIL":
                msg = f"HTTP check failed for {target}: {check.get('error', 'non-200')}"
                _db.record_alert(target, "critical", "endpoint_down", msg)
                subj, plain, html = _build_endpoint_alert(target, check_type, status, check)
                send_alert(subj, plain, html)
            elif check_type == "ssl" and status in ("EXPIRED", "CRITICAL", "INVALID"):
                msg = f"SSL cert issue for {target}: {status} ({check.get('days_until_expiry', '?')} days left)"
                _db.record_alert(target, "critical", "ssl_expiring", msg)
                subj, plain, html = _build_endpoint_alert(target, check_type, status, check)
                send_alert(subj, plain, html)
            elif check_type == "ssl" and status == "WARNING":
                msg = f"SSL cert expiring soon for {target}: {check.get('days_until_expiry', '?')} days left"
                _db.record_alert(target, "warning", "ssl_expiring", msg)
                subj, plain, html = _build_endpoint_alert(target, check_type, status, check)
                send_alert(subj, plain, html)

            log.info(f"  {target}: {check_type}={status}")
            results.append({"target": target, "type": check_type, "status": status})

        except Exception as e:
            log.error(f"  {target}: check failed: {e}")
            results.append({"target": target, "error": str(e)})

    return results


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
def run_cycle() -> dict:
    """Run one full monitoring cycle. Returns summary."""
    log.info("=" * 60)
    log.info(f"Monitoring cycle started at {datetime.now(timezone.utc).isoformat()}")
    log.info(f"Servers: {len(SERVER_PROFILES)}, Endpoints: {len(WATCHDOG_ENDPOINTS)}")

    summary = {"timestamp": datetime.now(timezone.utc).isoformat()}

    if WATCHDOG_HEALTH_ENABLED:
        summary["health"] = check_all_health()
    if WATCHDOG_SERVICES_ENABLED:
        summary["services"] = check_all_services()
    if WATCHDOG_ENDPOINTS_ENABLED and WATCHDOG_ENDPOINTS:
        summary["endpoints"] = check_all_endpoints()

    log.info("Cycle complete.")
    return summary


def main() -> None:
    """Entry point for the watchdog daemon."""
    _db.init_db()

    log.info("Server Guardian Watchdog starting...")
    log.info(f"Interval: {WATCHDOG_INTERVAL}s")
    log.info(f"Health checks: {'ON' if WATCHDOG_HEALTH_ENABLED else 'OFF'}")
    log.info(f"Service checks: {'ON' if WATCHDOG_SERVICES_ENABLED else 'OFF'}")
    log.info(f"Endpoint checks: {'ON' if WATCHDOG_ENDPOINTS_ENABLED else 'OFF'} ({len(WATCHDOG_ENDPOINTS)} targets)")
    log.info(f"Auto-restart: {'ON' if WATCHDOG_AUTO_RESTART else 'OFF'}")
    log.info(f"Email alerts: {'ON' if ALERT_EMAIL else 'OFF'}")
    log.info(f"Webhook alerts: {'ON' if ALERT_WEBHOOK else 'OFF'}")
    log.info(f"Discord alerts: {'ON' if ALERT_DISCORD_WEBHOOK else 'OFF'}")
    log.info(f"Servers configured: {', '.join(sorted(SERVER_PROFILES.keys())) or 'none'}")

    if not SERVER_PROFILES:
        log.error("No servers configured in .env. Add SERVER_<NAME>=... entries.")
        sys.exit(1)

    # --once flag: run one cycle and exit
    if "--once" in sys.argv:
        log.info("Running single cycle (--once mode)")
        run_cycle()
        return

    # Main loop
    while True:
        try:
            run_cycle()
        except KeyboardInterrupt:
            log.info("Shutting down (Ctrl+C)")
            break
        except Exception as e:
            log.error(f"Cycle error: {e}")

        log.info(f"Sleeping {WATCHDOG_INTERVAL}s until next cycle...")
        try:
            time.sleep(WATCHDOG_INTERVAL)
        except KeyboardInterrupt:
            log.info("Shutting down (Ctrl+C)")
            break


if __name__ == "__main__":
    main()
