"""
Server Guardian MCP — External Integrations

Alert routing to PagerDuty, Telegram, OpsGenie, and GitHub webhook
for deploy-on-push via git_deploy.
"""

import json
import logging
import os
import urllib.error
import urllib.request

log = logging.getLogger("integrations")


# ---------------------------------------------------------------------------
# Configuration from env
# ---------------------------------------------------------------------------
def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


# PagerDuty
PAGERDUTY_ROUTING_KEY = _env("PAGERDUTY_ROUTING_KEY")

# Telegram
TELEGRAM_BOT_TOKEN = _env("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = _env("TELEGRAM_CHAT_ID")

# OpsGenie
OPSGENIE_API_KEY = _env("OPSGENIE_API_KEY")

# GitHub Webhooks
GITHUB_WEBHOOK_SECRET = _env("GITHUB_WEBHOOK_SECRET")


# ---------------------------------------------------------------------------
# HTTP helper
# ---------------------------------------------------------------------------
def _post_json(url: str, payload: dict, headers: dict | None = None,
               timeout: int = 15) -> dict:
    """POST JSON to a URL. Returns {success, status_code, body} or {success, error}."""
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(4096).decode("utf-8", errors="replace")
            return {"success": True, "status_code": resp.status, "body": body}
    except urllib.error.HTTPError as e:
        return {"success": False, "status_code": e.code, "error": str(e.reason)}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------------------------------------------------------
# PagerDuty
# ---------------------------------------------------------------------------
def send_pagerduty_alert(summary: str, severity: str = "warning",
                         source: str = "server-guardian-mcp",
                         details: dict | None = None) -> dict:
    """Send an alert to PagerDuty via Events API v2.

    severity: critical, warning, error, info
    """
    if not PAGERDUTY_ROUTING_KEY:
        return {"success": False, "error": "PAGERDUTY_ROUTING_KEY not configured"}

    # Map our severities to PagerDuty's
    pd_severity = {
        "critical": "critical",
        "warning": "warning",
        "info": "info",
    }.get(severity, "warning")

    payload = {
        "routing_key": PAGERDUTY_ROUTING_KEY,
        "event_action": "trigger",
        "payload": {
            "summary": summary[:1024],
            "severity": pd_severity,
            "source": source,
            "component": "server-guardian-mcp",
            "custom_details": details or {},
        },
    }

    result = _post_json("https://events.pagerduty.com/v2/enqueue", payload)
    if result.get("success"):
        log.info(f"PagerDuty alert sent: {summary[:80]}")
    else:
        log.error(f"PagerDuty failed: {result.get('error')}")
    return result


def resolve_pagerduty_alert(dedup_key: str) -> dict:
    """Resolve a PagerDuty alert by dedup key."""
    if not PAGERDUTY_ROUTING_KEY:
        return {"success": False, "error": "PAGERDUTY_ROUTING_KEY not configured"}

    payload = {
        "routing_key": PAGERDUTY_ROUTING_KEY,
        "event_action": "resolve",
        "dedup_key": dedup_key,
    }
    return _post_json("https://events.pagerduty.com/v2/enqueue", payload)


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------
def send_telegram_alert(message: str, parse_mode: str = "HTML") -> dict:
    """Send an alert message via Telegram bot.

    Supports HTML formatting: <b>bold</b>, <code>code</code>, etc.
    """
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return {"success": False, "error": "TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not configured"}

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message[:4096],
        "parse_mode": parse_mode,
        "disable_web_page_preview": True,
    }

    result = _post_json(url, payload)
    if result.get("success"):
        log.info(f"Telegram alert sent: {message[:80]}")
    else:
        log.error(f"Telegram failed: {result.get('error')}")
    return result


def format_telegram_alert(subject: str, body: str, severity: str = "warning") -> str:
    """Format an alert for Telegram with HTML markup."""
    icon = {"critical": "\u26a0\ufe0f", "warning": "\u26a0\ufe0f", "info": "\u2139\ufe0f"}.get(severity, "\u2139\ufe0f")
    return (
        f"{icon} <b>{severity.upper()}: {subject}</b>\n\n"
        f"<code>{body[:3000]}</code>\n\n"
        f"<i>Server Guardian MCP</i>"
    )


# ---------------------------------------------------------------------------
# OpsGenie
# ---------------------------------------------------------------------------
def send_opsgenie_alert(message: str, priority: str = "P3",
                        description: str = "",
                        tags: list[str] | None = None) -> dict:
    """Send an alert to OpsGenie.

    priority: P1 (critical) through P5 (informational)
    """
    if not OPSGENIE_API_KEY:
        return {"success": False, "error": "OPSGENIE_API_KEY not configured"}

    # Map our severity to OpsGenie priority
    payload = {
        "message": message[:130],
        "priority": priority,
        "description": description[:15000],
        "tags": tags or ["server-guardian"],
        "source": "server-guardian-mcp",
    }

    result = _post_json(
        "https://api.opsgenie.com/v2/alerts",
        payload,
        headers={"Authorization": f"GenieKey {OPSGENIE_API_KEY}"},
    )
    if result.get("success"):
        log.info(f"OpsGenie alert sent: {message[:80]}")
    else:
        log.error(f"OpsGenie failed: {result.get('error')}")
    return result


def severity_to_opsgenie_priority(severity: str) -> str:
    """Map our severity levels to OpsGenie priority."""
    return {"critical": "P1", "warning": "P3", "info": "P5"}.get(severity, "P3")


# ---------------------------------------------------------------------------
# GitHub Webhook receiver (for deploy-on-push)
# ---------------------------------------------------------------------------
def parse_github_push_event(payload: dict) -> dict | None:
    """Parse a GitHub push webhook payload.
    Returns {repo, branch, commits, pusher} or None if not a push event."""
    ref = payload.get("ref", "")
    if not ref.startswith("refs/heads/"):
        return None

    branch = ref.replace("refs/heads/", "")
    repo = payload.get("repository", {}).get("full_name", "")
    commits = [
        {
            "id": c.get("id", "")[:8],
            "message": c.get("message", "")[:100],
            "author": c.get("author", {}).get("name", ""),
        }
        for c in payload.get("commits", [])
    ]
    pusher = payload.get("pusher", {}).get("name", "")

    return {
        "repo": repo,
        "branch": branch,
        "commits": commits,
        "commit_count": len(commits),
        "pusher": pusher,
    }


# ---------------------------------------------------------------------------
# Unified alert dispatcher
# ---------------------------------------------------------------------------
def dispatch_alert(subject: str, body: str, severity: str = "warning",
                   details: dict | None = None) -> dict:
    """Send an alert to all configured external integrations.
    Returns {channels: {channel: result, ...}}.
    """
    results = {}

    if PAGERDUTY_ROUTING_KEY:
        results["pagerduty"] = send_pagerduty_alert(
            subject, severity=severity, details=details,
        )

    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        msg = format_telegram_alert(subject, body, severity)
        results["telegram"] = send_telegram_alert(msg)

    if OPSGENIE_API_KEY:
        priority = severity_to_opsgenie_priority(severity)
        results["opsgenie"] = send_opsgenie_alert(
            subject, priority=priority, description=body,
        )

    if not results:
        results["none"] = {"note": "No external integrations configured"}

    return {"channels": results}


def get_configured_integrations() -> list[dict]:
    """List which integrations are configured."""
    integrations = []
    if PAGERDUTY_ROUTING_KEY:
        integrations.append({"name": "PagerDuty", "status": "configured"})
    else:
        integrations.append({"name": "PagerDuty", "status": "not configured", "env": "PAGERDUTY_ROUTING_KEY"})

    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        integrations.append({"name": "Telegram", "status": "configured"})
    else:
        integrations.append({"name": "Telegram", "status": "not configured", "env": "TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID"})

    if OPSGENIE_API_KEY:
        integrations.append({"name": "OpsGenie", "status": "configured"})
    else:
        integrations.append({"name": "OpsGenie", "status": "not configured", "env": "OPSGENIE_API_KEY"})

    if GITHUB_WEBHOOK_SECRET:
        integrations.append({"name": "GitHub Webhooks", "status": "configured"})
    else:
        integrations.append({"name": "GitHub Webhooks", "status": "not configured", "env": "GITHUB_WEBHOOK_SECRET"})

    return integrations
