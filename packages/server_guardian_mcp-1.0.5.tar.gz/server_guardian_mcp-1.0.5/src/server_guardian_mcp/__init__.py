"""Server Guardian MCP — Monitor and manage remote Linux servers via SSH."""
__version__ = "1.0.5"
