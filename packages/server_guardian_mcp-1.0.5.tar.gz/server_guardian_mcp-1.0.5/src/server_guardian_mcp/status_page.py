"""
Server Guardian MCP — Public Status Page + Postmortem + Scheduled Reports

- Status page: self-hosted uptime page for customers (replaces Better Stack $29/mo)
- Postmortem: AI-friendly incident report generation from timeline data
- Scheduled reports: weekly health summary
"""

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import db as _db


def generate_status_page(output_path: str = "", company_name: str = "",
                         services: list[dict] | None = None) -> dict:
    """Generate a public-facing status page HTML file.

    services: optional list of {name, endpoint_or_server, type: "endpoint"|"server"}
    If not provided, auto-generates from all monitored servers and endpoints.
    """
    if not company_name:
        company_name = "Service Status"
    if not output_path:
        output_path = str(Path.home() / ".server-guardian-mcp" / "status-page.html")

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    # Gather server health
    servers = _db.get_latest_health_all_servers()
    # Gather endpoint checks
    endpoints = _db.get_all_endpoint_history(hours=24)
    # Gather recent alerts
    alerts = _db.get_alerts(resolved=False)
    resolved_24h = _db.get_alerts(resolved=True)

    # Build service items
    items_html = ""
    all_operational = True

    for s in servers:
        name = s.get("server_name", "Unknown")
        cpu = s.get("cpu_load")
        disk = s.get("disk_used_pct")
        status = "operational"
        status_color = "#22c55e"
        status_text = "Operational"
        if cpu is not None and s.get("cpu_cores") and cpu > s["cpu_cores"] * 2:
            status = "degraded"
            status_color = "#eab308"
            status_text = "Degraded Performance"
            all_operational = False
        if disk is not None and disk > 90:
            status = "degraded"
            status_color = "#eab308"
            status_text = "Degraded Performance"
            all_operational = False

        items_html += f"""
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #e5e7eb;">
          <span style="font-weight:500;">{name}</span>
          <span style="color:{status_color};font-weight:600;font-size:14px;">{status_text}</span>
        </div>"""

    # Endpoints
    ep_seen = set()
    for ep in endpoints:
        url = ep.get("url_or_domain", "")
        if url in ep_seen:
            continue
        ep_seen.add(url)
        status = ep.get("status", "")
        if status in ("PASS", "OK"):
            status_text = "Operational"
            status_color = "#22c55e"
        elif status == "WARNING":
            status_text = "Degraded"
            status_color = "#eab308"
            all_operational = False
        else:
            status_text = "Down"
            status_color = "#ef4444"
            all_operational = False

        items_html += f"""
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #e5e7eb;">
          <span style="font-weight:500;">{url}</span>
          <span style="color:{status_color};font-weight:600;font-size:14px;">{status_text}</span>
        </div>"""

    overall_status = "All Systems Operational" if all_operational else "Some Systems Experiencing Issues"
    overall_color = "#22c55e" if all_operational else "#eab308"

    # Recent incidents
    incidents_html = ""
    if alerts:
        for a in alerts[:5]:
            incidents_html += f"""
            <div style="padding:12px;border-left:3px solid #ef4444;background:#fef2f2;border-radius:4px;margin-bottom:8px;">
              <strong>{a.get('server_name', '')}</strong> — {a.get('message', '')[:120]}
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">{a.get('timestamp', '')[:19]}</div>
            </div>"""
    else:
        incidents_html = '<p style="color:#6b7280;">No incidents reported.</p>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="refresh" content="60">
  <title>{company_name} — Status</title>
</head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f9fafb;margin:0;color:#111827;">
  <div style="max-width:700px;margin:0 auto;padding:40px 20px;">
    <h1 style="font-size:22px;margin-bottom:24px;">{company_name}</h1>
    <div style="background:{overall_color};color:white;padding:16px 24px;border-radius:8px;font-size:16px;font-weight:600;margin-bottom:32px;">
      {overall_status}
    </div>
    <div style="background:white;border-radius:8px;padding:20px 24px;box-shadow:0 1px 3px rgba(0,0,0,0.1);margin-bottom:32px;">
      {items_html}
    </div>
    <h2 style="font-size:18px;margin-bottom:12px;">Recent Incidents</h2>
    <div style="margin-bottom:32px;">{incidents_html}</div>
    <div style="text-align:center;color:#9ca3af;font-size:12px;">
      Updated: {timestamp} | Powered by Server Guardian MCP
    </div>
  </div>
</body>
</html>"""

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return {
        "path": output_path,
        "servers": len(servers),
        "endpoints": len(ep_seen),
        "all_operational": all_operational,
        "active_incidents": len(alerts),
    }


def generate_postmortem(server: str = "", hours: int = 24) -> dict:
    """Generate a structured postmortem report from incident data.

    Returns a structured document that Claude can present or the user can export.
    """
    # Gather all data
    alerts = _db.get_alerts(server_name=server if server else None, resolved=False)
    resolved = _db.get_alerts(server_name=server if server else None, resolved=True)
    all_alerts = alerts + resolved
    svc_events = _db.get_service_events(server_name=server if server else None, hours=hours)
    pb_runs = _db.get_playbook_runs(server_name=server if server else None, hours=hours)

    if not all_alerts and not svc_events:
        return {"status": "no incidents", "note": "No incidents found in this period."}

    # Build timeline
    timeline = []
    for a in all_alerts:
        timeline.append({
            "time": a["timestamp"],
            "type": "alert",
            "detail": f"[{a['severity'].upper()}] {a.get('server_name', '')}: {a['message']}",
            "resolved": bool(a.get("resolved")),
        })
    for e in svc_events:
        timeline.append({
            "time": e["timestamp"],
            "type": "service_change",
            "detail": f"{e.get('server_name', '')}: {e['service_name']} {e['old_status']} -> {e['new_status']} ({e['action']})",
        })
    for r in pb_runs:
        timeline.append({
            "time": r["timestamp"],
            "type": "remediation",
            "detail": f"Playbook '{r['playbook_name']}' on {r.get('server_name', '')}: {'succeeded' if r.get('success') else 'FAILED'}",
        })
    timeline.sort(key=lambda x: x["time"])

    # Determine severity
    severities = [a["severity"] for a in all_alerts]
    max_severity = "critical" if "critical" in severities else "warning" if "warning" in severities else "info"

    # Determine duration
    if timeline:
        start = timeline[0]["time"][:19]
        end = timeline[-1]["time"][:19]
    else:
        start = end = "unknown"

    # Impacted services
    impacted = set()
    for e in svc_events:
        impacted.add(e["service_name"])
    for a in all_alerts:
        impacted.add(a.get("server_name", ""))

    return {
        "title": f"Incident Report — {server or 'All Servers'} — {start[:10]}",
        "severity": max_severity,
        "duration": {"start": start, "end": end},
        "impacted": sorted(impacted),
        "timeline": timeline,
        "summary": {
            "total_alerts": len(all_alerts),
            "service_events": len(svc_events),
            "auto_remediations": len(pb_runs),
            "resolved": sum(1 for a in all_alerts if a.get("resolved")),
            "unresolved": sum(1 for a in all_alerts if not a.get("resolved")),
        },
        "sections": {
            "impact": f"{len(impacted)} services/servers affected. Max severity: {max_severity}.",
            "timeline_summary": f"{len(timeline)} events over the incident period.",
            "remediation": f"{len(pb_runs)} automated remediations executed." if pb_runs else "No automated remediations triggered.",
            "action_items": [
                "Review root cause of each unresolved alert",
                "Verify all services are healthy",
                "Update monitoring thresholds if needed",
                "Consider adding playbooks for recurring issues",
            ],
        },
    }


def generate_weekly_report(hours: int = 168) -> dict:
    """Generate a weekly health summary suitable for email.

    Returns structured data for the watchdog to format and send.
    """
    servers = _db.get_latest_health_all_servers()
    alerts_active = _db.get_alerts(resolved=False)
    alerts_resolved = _db.get_alerts(resolved=True)
    svc_events = _db.get_service_events(hours=hours)
    pb_runs = _db.get_playbook_runs(hours=hours)
    alert_counts = _db.get_alert_counts()

    server_summaries = []
    for s in servers:
        server_summaries.append({
            "name": s["server_name"],
            "cpu_load": s.get("cpu_load"),
            "memory_pct": s.get("memory_used_pct"),
            "disk_pct": s.get("disk_used_pct"),
            "uptime_days": round(s["uptime_seconds"] / 86400, 1) if s.get("uptime_seconds") else None,
        })

    return {
        "period_hours": hours,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "servers": server_summaries,
        "alerts": {
            "active": len(alerts_active),
            "resolved_this_period": len(alerts_resolved),
            "by_severity": alert_counts,
        },
        "service_events": len(svc_events),
        "playbook_runs": len(pb_runs),
        "highlights": {
            "servers_monitored": len(servers),
            "critical_alerts": alert_counts.get("critical", 0),
            "warnings": alert_counts.get("warning", 0),
        },
    }
