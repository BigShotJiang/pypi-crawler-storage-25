"""
Server Guardian MCP — Smart Anomaly Detection

Builds rolling baselines from historical health_snapshots data and detects
anomalies using statistical analysis (mean + standard deviation).

No ML dependencies — pure statistics from SQLite data.
"""

import math
from datetime import datetime, timezone

from . import db as _db


# Metrics we track for anomaly detection
TRACKED_METRICS = ("cpu_load", "memory_used_pct", "disk_used_pct", "temperature_c")

# How many standard deviations from the mean to flag as anomalous
ANOMALY_THRESHOLD = 2.5

# Minimum samples needed before we trust a baseline
MIN_SAMPLES = 5


def _compute_stats(values: list[float]) -> tuple[float, float]:
    """Compute mean and standard deviation for a list of values."""
    if not values:
        return 0.0, 0.0
    n = len(values)
    mean = sum(values) / n
    if n < 2:
        return mean, 0.0
    variance = sum((x - mean) ** 2 for x in values) / (n - 1)
    return mean, math.sqrt(variance)


def rebuild_baselines(server_name: str, hours: int = 168) -> dict:
    """Rebuild anomaly baselines from the last N hours of health data.
    Default: 168 hours (7 days) to capture weekly patterns.

    Groups data by (metric, hour_of_day, day_of_week) and computes
    mean + stddev for each bucket.

    Returns {baselines_updated: int, metrics_processed: list}.
    """
    snapshots = _db.get_health_history(server_name, hours=hours)
    if not snapshots:
        return {"baselines_updated": 0, "metrics_processed": [], "note": "no data"}

    # Group values by (metric, hour, dow)
    buckets: dict[tuple[str, int, int], list[float]] = {}
    for snap in snapshots:
        try:
            ts = datetime.fromisoformat(snap["timestamp"])
        except (ValueError, TypeError):
            continue
        hour = ts.hour
        dow = ts.weekday()  # 0=Monday
        for metric in TRACKED_METRICS:
            val = snap.get(metric)
            if val is not None:
                key = (metric, hour, dow)
                buckets.setdefault(key, []).append(float(val))

    updated = 0
    for (metric, hour, dow), values in buckets.items():
        mean, stddev = _compute_stats(values)
        _db.upsert_baseline(server_name, metric, hour, dow, mean, stddev, len(values))
        updated += 1

    metrics_seen = sorted(set(k[0] for k in buckets.keys()))
    return {
        "baselines_updated": updated,
        "metrics_processed": metrics_seen,
        "data_points": len(snapshots),
    }


def detect_anomalies(server_name: str, current_metrics: dict) -> list[dict]:
    """Check current metrics against stored baselines.
    Returns a list of anomaly dicts for any metric that deviates
    beyond ANOMALY_THRESHOLD standard deviations from the baseline.

    current_metrics should have keys like cpu_load, memory_used_pct, etc.
    """
    now = datetime.now(timezone.utc)
    hour = now.hour
    dow = now.weekday()

    anomalies = []
    for metric in TRACKED_METRICS:
        current_val = current_metrics.get(metric)
        if current_val is None:
            continue

        baseline = _db.get_baseline(server_name, metric, hour, dow)
        if not baseline or baseline["sample_count"] < MIN_SAMPLES:
            continue

        mean = baseline["mean"]
        stddev = baseline["stddev"]

        # If stddev is 0 (all historical values identical), use 5% of mean as fallback
        if stddev < 0.001:
            stddev = max(abs(mean) * 0.05, 0.1)

        deviation = abs(current_val - mean) / stddev

        if deviation >= ANOMALY_THRESHOLD:
            direction = "above" if current_val > mean else "below"
            pct_diff = round(((current_val - mean) / mean) * 100, 1) if mean else 0

            anomalies.append({
                "metric": metric,
                "current_value": round(current_val, 2),
                "baseline_mean": round(mean, 2),
                "baseline_stddev": round(stddev, 2),
                "deviation_sigmas": round(deviation, 2),
                "direction": direction,
                "pct_difference": pct_diff,
                "severity": "critical" if deviation >= 4.0 else "warning",
                "message": (
                    f"{metric} is {round(current_val, 1)} ({direction} normal). "
                    f"Baseline: {round(mean, 1)} +/- {round(stddev, 1)} "
                    f"({round(deviation, 1)} sigma deviation, {pct_diff}% {'higher' if direction == 'above' else 'lower'})"
                ),
            })

    return anomalies


def get_server_baselines_summary(server_name: str) -> dict:
    """Get a human-readable summary of baselines for a server."""
    baselines = _db.get_all_baselines(server_name)
    if not baselines:
        return {"server": server_name, "status": "no baselines", "note": "run rebuild_baselines first"}

    # Group by metric
    by_metric: dict[str, list[dict]] = {}
    for b in baselines:
        by_metric.setdefault(b["metric"], []).append(b)

    summary = {"server": server_name, "metrics": {}}
    for metric, entries in by_metric.items():
        means = [e["mean"] for e in entries]
        total_samples = sum(e["sample_count"] for e in entries)
        summary["metrics"][metric] = {
            "time_slots": len(entries),
            "total_samples": total_samples,
            "overall_mean": round(sum(means) / len(means), 2) if means else 0,
            "range": [round(min(means), 2), round(max(means), 2)] if means else [0, 0],
        }

    return summary
