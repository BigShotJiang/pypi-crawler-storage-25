"""
Server Guardian MCP — Log Search, Pattern Detection & Log-to-Metrics

Fetches logs via SSH, indexes them in SQLite, enables search,
clusters similar log lines into patterns, and extracts metrics from logs.
"""

import hashlib
import re
from collections import Counter
from datetime import datetime, timezone

from . import db as _db


def _normalize_log_line(line: str) -> str:
    """Normalize a log line for pattern matching by replacing variable parts."""
    s = line.strip()
    s = re.sub(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[.\d]*\S*", "<TIMESTAMP>", s)
    s = re.sub(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "<IP>", s)
    s = re.sub(r"\b[0-9a-f]{8,}\b", "<HEX>", s)
    s = re.sub(r"\b\d{4,}\b", "<NUM>", s)
    s = re.sub(r"\bpid[= ]\d+", "pid=<PID>", s)
    s = re.sub(r"\bport[= ]\d+", "port=<PORT>", s)
    return s


def _pattern_hash(normalized: str) -> str:
    """Generate a short hash for a normalized pattern."""
    return hashlib.md5(normalized.encode()).hexdigest()[:12]


def _detect_level(line: str) -> str:
    """Detect log level from a line."""
    upper = line[:200].upper()
    if "ERROR" in upper or "FATAL" in upper or "CRIT" in upper:
        return "error"
    if "WARN" in upper:
        return "warning"
    if "DEBUG" in upper or "TRACE" in upper:
        return "debug"
    return "info"


def index_logs(server_name: str, raw_output: str, source: str = "journal") -> dict:
    """Parse raw log output and store in SQLite for searching.

    Returns {indexed: count, patterns: count, errors: count}.
    """
    lines = raw_output.strip().splitlines()
    if not lines:
        return {"indexed": 0, "patterns": 0, "errors": 0}

    entries = []
    error_count = 0
    pattern_counts = Counter()
    now_iso = datetime.now(timezone.utc).isoformat()

    for line in lines:
        line = line.strip()
        if not line:
            continue

        level = _detect_level(line)
        if level == "error":
            error_count += 1

        normalized = _normalize_log_line(line)
        phash = _pattern_hash(normalized)
        pattern_counts[phash] += 1

        entries.append({
            "server_name": server_name,
            "source": source,
            "timestamp": now_iso,
            "level": level,
            "message": line,
            "pattern_hash": phash,
        })

    if entries:
        _db.store_log_entries(entries)

    return {
        "indexed": len(entries),
        "unique_patterns": len(pattern_counts),
        "errors": error_count,
        "top_patterns": pattern_counts.most_common(5),
    }


def search(server_name: str = "", query: str = "", source: str = "",
           level: str = "", hours: int = 24, limit: int = 100) -> list[dict]:
    """Search indexed logs."""
    return _db.search_logs(server_name, query, source, level, hours, limit)


def get_patterns(server_name: str, hours: int = 24) -> list[dict]:
    """Get most frequent log patterns for noise reduction."""
    return _db.get_log_patterns(server_name, hours)


def extract_error_rate(server_name: str, hours: int = 1) -> dict:
    """Extract error rate from indexed logs (log-to-metrics)."""
    all_logs = _db.search_logs(server_name=server_name, hours=hours, limit=10000)
    total = len(all_logs)
    errors = sum(1 for l in all_logs if l.get("level") == "error")
    warnings = sum(1 for l in all_logs if l.get("level") == "warning")

    return {
        "server": server_name,
        "period_hours": hours,
        "total_entries": total,
        "errors": errors,
        "warnings": warnings,
        "error_rate_pct": round((errors / total) * 100, 2) if total else 0,
        "warning_rate_pct": round((warnings / total) * 100, 2) if total else 0,
    }
