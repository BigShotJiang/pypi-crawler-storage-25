"""
Server Guardian MCP — Access Log APM (Application Performance Monitoring)

Parse nginx/Apache access logs to extract per-endpoint metrics:
- Latency percentiles (p50, p95, p99)
- Error rates (4xx, 5xx)
- Throughput (requests/sec)
- Slowest endpoints

No agent needed — works from access log files via SSH.
"""

import re
from collections import defaultdict

# ---------------------------------------------------------------------------
# Nginx combined log format parser
# ---------------------------------------------------------------------------
# 10.0.0.1 - - [14/Apr/2026:10:00:00 +0000] "GET /api/users HTTP/1.1" 200 1234 "-" "curl" 0.045
_NGINX_COMBINED_RE = re.compile(
    r'(?P<ip>\S+)\s+\S+\s+\S+\s+\[(?P<time>[^\]]+)\]\s+'
    r'"(?P<method>\S+)\s+(?P<path>\S+)\s+\S+"\s+'
    r'(?P<status>\d{3})\s+(?P<bytes>\d+)\s+'
    r'"[^"]*"\s+"[^"]*"'
    r'(?:\s+(?P<duration>[\d.]+))?'
)

# Apache common log format
_APACHE_RE = re.compile(
    r'(?P<ip>\S+)\s+\S+\s+\S+\s+\[(?P<time>[^\]]+)\]\s+'
    r'"(?P<method>\S+)\s+(?P<path>\S+)\s+\S+"\s+'
    r'(?P<status>\d{3})\s+(?P<bytes>\d+)'
)


def _normalize_path(path: str) -> str:
    """Normalize URL path by replacing IDs/UUIDs with placeholders."""
    # /api/users/123 -> /api/users/:id
    path = re.sub(r'/\d+', '/:id', path)
    # /api/items/550e8400-... -> /api/items/:uuid
    path = re.sub(r'/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', '/:uuid', path)
    # Strip query string
    path = path.split('?')[0]
    return path


def _percentile(sorted_values: list[float], p: float) -> float:
    """Calculate percentile from sorted values."""
    if not sorted_values:
        return 0.0
    k = (len(sorted_values) - 1) * (p / 100.0)
    f = int(k)
    c = f + 1
    if c >= len(sorted_values):
        return sorted_values[-1]
    return sorted_values[f] + (k - f) * (sorted_values[c] - sorted_values[f])


def parse_access_log(raw_log: str) -> list[dict]:
    """Parse raw access log text into structured entries."""
    entries = []
    for line in raw_log.splitlines():
        line = line.strip()
        if not line:
            continue
        m = _NGINX_COMBINED_RE.match(line)
        if not m:
            m = _APACHE_RE.match(line)
        if not m:
            continue
        d = m.groupdict()
        entry = {
            "ip": d.get("ip", ""),
            "method": d.get("method", "GET"),
            "path": d.get("path", "/"),
            "status": int(d.get("status", 0)),
            "bytes": int(d.get("bytes", 0)),
        }
        duration = d.get("duration")
        if duration:
            try:
                entry["duration_ms"] = round(float(duration) * 1000, 2)
            except ValueError:
                entry["duration_ms"] = None
        else:
            entry["duration_ms"] = None
        entries.append(entry)
    return entries


def analyze_endpoints(entries: list[dict]) -> dict:
    """Analyze parsed access log entries for per-endpoint metrics.

    Returns {
        endpoints: [{path, method, count, error_rate, p50, p95, p99, avg, max}],
        summary: {total_requests, error_rate, avg_latency, ...}
    }
    """
    by_endpoint: dict[str, list[dict]] = defaultdict(list)
    for e in entries:
        key = f"{e['method']} {_normalize_path(e['path'])}"
        by_endpoint[key].append(e)

    endpoints = []
    total_requests = len(entries)
    total_errors = 0
    all_durations = []

    for key, reqs in sorted(by_endpoint.items(), key=lambda x: -len(x[1])):
        count = len(reqs)
        errors_4xx = sum(1 for r in reqs if 400 <= r["status"] < 500)
        errors_5xx = sum(1 for r in reqs if r["status"] >= 500)
        total_errors += errors_5xx

        durations = sorted([r["duration_ms"] for r in reqs if r.get("duration_ms") is not None])
        all_durations.extend(durations)

        ep = {
            "endpoint": key,
            "requests": count,
            "4xx": errors_4xx,
            "5xx": errors_5xx,
            "error_rate_pct": round(((errors_4xx + errors_5xx) / count) * 100, 1),
        }

        if durations:
            ep["p50_ms"] = round(_percentile(durations, 50), 1)
            ep["p95_ms"] = round(_percentile(durations, 95), 1)
            ep["p99_ms"] = round(_percentile(durations, 99), 1)
            ep["avg_ms"] = round(sum(durations) / len(durations), 1)
            ep["max_ms"] = round(max(durations), 1)
        else:
            ep["p50_ms"] = ep["p95_ms"] = ep["p99_ms"] = ep["avg_ms"] = ep["max_ms"] = None

        total_bytes = sum(r["bytes"] for r in reqs)
        ep["total_bytes"] = total_bytes
        endpoints.append(ep)

    all_durations.sort()
    summary = {
        "total_requests": total_requests,
        "total_endpoints": len(endpoints),
        "total_errors_5xx": total_errors,
        "error_rate_pct": round((total_errors / total_requests) * 100, 2) if total_requests else 0,
    }
    if all_durations:
        summary["overall_p50_ms"] = round(_percentile(all_durations, 50), 1)
        summary["overall_p95_ms"] = round(_percentile(all_durations, 95), 1)
        summary["overall_p99_ms"] = round(_percentile(all_durations, 99), 1)

    # Top 5 slowest
    slowest = sorted(
        [e for e in endpoints if e.get("p95_ms") is not None],
        key=lambda x: x["p95_ms"], reverse=True
    )[:5]

    return {
        "endpoints": endpoints[:30],
        "summary": summary,
        "slowest_endpoints": slowest,
    }


def analyze_status_codes(entries: list[dict]) -> dict:
    """Breakdown of HTTP status codes."""
    by_status = defaultdict(int)
    for e in entries:
        status_group = f"{e['status'] // 100}xx"
        by_status[status_group] += 1
    total = len(entries)
    return {
        "total": total,
        "breakdown": dict(sorted(by_status.items())),
        "percentages": {k: round((v / total) * 100, 1) for k, v in sorted(by_status.items())} if total else {},
    }


def analyze_traffic_by_ip(entries: list[dict], top_n: int = 10) -> list[dict]:
    """Top IP addresses by request count."""
    by_ip = defaultdict(lambda: {"count": 0, "errors": 0, "bytes": 0})
    for e in entries:
        ip = e["ip"]
        by_ip[ip]["count"] += 1
        by_ip[ip]["bytes"] += e["bytes"]
        if e["status"] >= 400:
            by_ip[ip]["errors"] += 1

    result = [{"ip": ip, **stats} for ip, stats in by_ip.items()]
    result.sort(key=lambda x: -x["count"])
    return result[:top_n]
