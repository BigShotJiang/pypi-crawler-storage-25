"""
Server Guardian MCP — SQLite persistence layer.
Stores health snapshots, service events, endpoint checks, and alerts.

Database location: ~/.server-guardian-mcp/guardian.db
"""

import json
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Database path
# ---------------------------------------------------------------------------
_DB_DIR = Path.home() / ".server-guardian-mcp"
_DB_PATH = _DB_DIR / "guardian.db"

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------
_SCHEMA = """
CREATE TABLE IF NOT EXISTS health_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    cpu_cores INTEGER,
    cpu_load REAL,
    memory_used_pct REAL,
    disk_used_pct REAL,
    uptime_seconds INTEGER,
    temperature_c REAL,
    raw_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_health_server_ts ON health_snapshots(server_name, timestamp);

CREATE TABLE IF NOT EXISTS service_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    service_name TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT,
    action TEXT
);
CREATE INDEX IF NOT EXISTS idx_svc_server_ts ON service_events(server_name, timestamp);

CREATE TABLE IF NOT EXISTS endpoint_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url_or_domain TEXT NOT NULL,
    check_type TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    status TEXT,
    response_time_ms INTEGER,
    details TEXT
);
CREATE INDEX IF NOT EXISTS idx_ep_url_ts ON endpoint_checks(url_or_domain, timestamp);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    severity TEXT NOT NULL,
    category TEXT NOT NULL,
    message TEXT NOT NULL,
    resolved INTEGER DEFAULT 0,
    resolved_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_alerts_server_resolved ON alerts(server_name, resolved);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    server_name TEXT,
    params TEXT,
    result_summary TEXT,
    success INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_tool ON audit_log(tool_name);

CREATE TABLE IF NOT EXISTS anomaly_baselines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    metric TEXT NOT NULL,
    hour_of_day INTEGER NOT NULL,
    day_of_week INTEGER NOT NULL,
    mean REAL NOT NULL,
    stddev REAL NOT NULL,
    sample_count INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    UNIQUE(server_name, metric, hour_of_day, day_of_week)
);
CREATE INDEX IF NOT EXISTS idx_baseline_server ON anomaly_baselines(server_name, metric);

CREATE TABLE IF NOT EXISTS playbook_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    playbook_name TEXT NOT NULL,
    trigger_condition TEXT NOT NULL,
    actions_taken TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    success INTEGER DEFAULT 1,
    output TEXT
);
CREATE INDEX IF NOT EXISTS idx_playbook_server_ts ON playbook_runs(server_name, timestamp);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    api_key TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'viewer',
    created_at TEXT NOT NULL,
    last_seen TEXT,
    active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_users_apikey ON users(api_key);

CREATE TABLE IF NOT EXISTS log_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    source TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    level TEXT,
    message TEXT NOT NULL,
    pattern_hash TEXT
);
CREATE INDEX IF NOT EXISTS idx_log_server_ts ON log_entries(server_name, timestamp);
CREATE INDEX IF NOT EXISTS idx_log_pattern ON log_entries(pattern_hash);

CREATE TABLE IF NOT EXISTS slos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    target_type TEXT NOT NULL,
    target_value REAL NOT NULL,
    server_name TEXT,
    endpoint TEXT,
    window_days INTEGER NOT NULL DEFAULT 30,
    created_at TEXT NOT NULL,
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS slo_measurements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slo_id INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    good INTEGER NOT NULL DEFAULT 0,
    total INTEGER NOT NULL DEFAULT 0,
    value REAL,
    FOREIGN KEY (slo_id) REFERENCES slos(id)
);
CREATE INDEX IF NOT EXISTS idx_slo_meas ON slo_measurements(slo_id, timestamp);

CREATE TABLE IF NOT EXISTS file_hashes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    hash_sha256 TEXT NOT NULL,
    permissions TEXT,
    owner TEXT,
    size_bytes INTEGER,
    last_checked TEXT NOT NULL,
    last_changed TEXT,
    UNIQUE(server_name, file_path)
);
CREATE INDEX IF NOT EXISTS idx_fh_server ON file_hashes(server_name);

CREATE TABLE IF NOT EXISTS network_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    interface TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    rx_bytes INTEGER,
    tx_bytes INTEGER,
    rx_packets INTEGER,
    tx_packets INTEGER,
    rx_errors INTEGER,
    tx_errors INTEGER,
    connections_established INTEGER,
    connections_time_wait INTEGER
);
CREATE INDEX IF NOT EXISTS idx_net_server_ts ON network_metrics(server_name, timestamp);

CREATE TABLE IF NOT EXISTS maintenance_windows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    reason TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    created_by TEXT
);
CREATE INDEX IF NOT EXISTS idx_maint_server ON maintenance_windows(server_name, start_time);

CREATE TABLE IF NOT EXISTS api_tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    steps TEXT NOT NULL,
    schedule_minutes INTEGER DEFAULT 0,
    last_run TEXT,
    last_result TEXT,
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS service_dependencies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_name TEXT NOT NULL,
    source_process TEXT NOT NULL,
    source_port INTEGER,
    dest_host TEXT NOT NULL,
    dest_port INTEGER NOT NULL,
    protocol TEXT DEFAULT 'tcp',
    discovered_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_svc_dep_server ON service_dependencies(server_name);

CREATE TABLE IF NOT EXISTS organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    logo_url TEXT,
    brand_color TEXT DEFAULT '#3b82f6',
    contact_email TEXT,
    plan TEXT DEFAULT 'free',
    max_servers INTEGER DEFAULT 5,
    created_at TEXT NOT NULL,
    active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS org_servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL,
    server_name TEXT NOT NULL,
    added_at TEXT NOT NULL,
    UNIQUE(org_id, server_name),
    FOREIGN KEY (org_id) REFERENCES organizations(id)
);
CREATE INDEX IF NOT EXISTS idx_org_servers ON org_servers(org_id);

CREATE TABLE IF NOT EXISTS org_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL DEFAULT 'viewer',
    added_at TEXT NOT NULL,
    UNIQUE(org_id, user_id),
    FOREIGN KEY (org_id) REFERENCES organizations(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_org_users ON org_users(org_id);

CREATE TABLE IF NOT EXISTS org_billing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL,
    month TEXT NOT NULL,
    servers_count INTEGER NOT NULL DEFAULT 0,
    checks_count INTEGER NOT NULL DEFAULT 0,
    alerts_count INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    UNIQUE(org_id, month),
    FOREIGN KEY (org_id) REFERENCES organizations(id)
);
"""

# ---------------------------------------------------------------------------
# Connection helper
# ---------------------------------------------------------------------------
def _get_conn() -> sqlite3.Connection:
    """Open a new SQLite connection with row factory."""
    conn = sqlite3.connect(str(_DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _now_iso() -> str:
    """Current UTC timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Init and cleanup
# ---------------------------------------------------------------------------
def init_db() -> None:
    """Create tables if they don't exist. Clean up records older than 90 days."""
    _DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = _get_conn()
    try:
        conn.executescript(_SCHEMA)
        # Auto-cleanup old records
        cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        for table in ("health_snapshots", "service_events", "endpoint_checks", "audit_log"):
            conn.execute(f"DELETE FROM {table} WHERE timestamp < ?", (cutoff,))
        conn.execute(
            "DELETE FROM alerts WHERE resolved = 1 AND resolved_at < ?", (cutoff,)
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Health metric parsing
# ---------------------------------------------------------------------------
def _parse_health_metrics(sections: dict) -> dict:
    """Extract numeric metrics from health section text.
    Returns dict with keys: cpu_cores, cpu_load, memory_used_pct,
    disk_used_pct, uptime_seconds, temperature_c. Any can be None."""
    metrics = {
        "cpu_cores": None,
        "cpu_load": None,
        "memory_used_pct": None,
        "disk_used_pct": None,
        "uptime_seconds": None,
        "temperature_c": None,
    }

    # CPU cores
    cpu_raw = sections.get("CPU", "")
    m = re.search(r"cores:\s*(\d+)", cpu_raw)
    if m:
        metrics["cpu_cores"] = int(m.group(1))

    # CPU load (first value from /proc/loadavg)
    load_raw = sections.get("LOAD", "")
    m = re.match(r"([\d.]+)", load_raw.strip())
    if m:
        try:
            metrics["cpu_load"] = float(m.group(1))
        except ValueError:
            pass

    # Memory used percentage from free -h output
    mem_raw = sections.get("MEMORY", "")
    for line in mem_raw.splitlines():
        if line.strip().startswith("Mem:"):
            parts = line.split()
            # free -h format: Mem: total used free shared buff/cache available
            if len(parts) >= 3:
                try:
                    total = _parse_size_to_mb(parts[1])
                    used = _parse_size_to_mb(parts[2])
                    if total and total > 0:
                        metrics["memory_used_pct"] = round((used / total) * 100, 1)
                except (ValueError, IndexError):
                    pass
            break

    # Disk used percentage from df -h output
    disk_raw = sections.get("DISK", "")
    for line in disk_raw.splitlines():
        # Look for the root filesystem line
        if "%" in line and ("/" in line):
            m = re.search(r"(\d+)%", line)
            if m:
                metrics["disk_used_pct"] = float(m.group(1))
                break

    # Uptime in seconds — parse from uptime output
    uptime_raw = sections.get("UPTIME", "")
    total_secs = 0
    found_uptime = False
    m = re.search(r"up\s+(\d+)\s+days?", uptime_raw)
    if m:
        total_secs += int(m.group(1)) * 86400
        found_uptime = True
    m = re.search(r"up\s+.*?(\d+):(\d+)", uptime_raw)
    if m:
        total_secs += int(m.group(1)) * 3600 + int(m.group(2)) * 60
        found_uptime = True
    if found_uptime:
        metrics["uptime_seconds"] = total_secs

    # Temperature — first thermal zone
    temp_raw = sections.get("TEMPERATURE", "")
    m = re.search(r"(\d+)C", temp_raw)
    if m:
        try:
            metrics["temperature_c"] = float(m.group(1))
        except ValueError:
            pass

    return metrics


def _parse_size_to_mb(size_str: str) -> float | None:
    """Parse a human-readable size like '31Gi', '2.4Gi', '500Mi' to MB."""
    size_str = size_str.strip()
    m = re.match(r"([\d.]+)\s*([KMGTP]i?)", size_str, re.IGNORECASE)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2).upper().rstrip("I")
    multipliers = {"K": 1 / 1024, "M": 1, "G": 1024, "T": 1024 * 1024, "P": 1024 * 1024 * 1024}
    return val * multipliers.get(unit, 1)


# ---------------------------------------------------------------------------
# Threshold alerting
# ---------------------------------------------------------------------------
def _check_health_thresholds(server_name: str, metrics: dict) -> int:
    """Check health metrics against thresholds and create alerts.
    Returns number of alerts generated."""
    alerts_generated = 0

    disk = metrics.get("disk_used_pct")
    if disk is not None:
        if disk > 90:
            record_alert(server_name, "critical", "disk_full",
                         f"Disk usage at {disk}% (critical threshold: 90%)")
            alerts_generated += 1
        elif disk > 80:
            record_alert(server_name, "warning", "disk_full",
                         f"Disk usage at {disk}% (warning threshold: 80%)")
            alerts_generated += 1

    cpu_load = metrics.get("cpu_load")
    cpu_cores = metrics.get("cpu_cores")
    if cpu_load is not None and cpu_cores is not None and cpu_cores > 0:
        if cpu_load > cpu_cores * 2:
            record_alert(server_name, "warning", "high_cpu",
                         f"CPU load {cpu_load} exceeds {cpu_cores * 2} (cores * 2)")
            alerts_generated += 1

    temp = metrics.get("temperature_c")
    if temp is not None and temp > 85:
        record_alert(server_name, "warning", "high_temp",
                     f"Temperature at {temp}°C (threshold: 85°C)")
        alerts_generated += 1

    return alerts_generated


# ---------------------------------------------------------------------------
# CRUD functions
# ---------------------------------------------------------------------------
def record_health(server_name: str, sections: dict) -> tuple[int, int]:
    """Parse health sections, store snapshot, check thresholds.
    Returns (row_id, alerts_generated)."""
    metrics = _parse_health_metrics(sections)
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO health_snapshots
               (server_name, timestamp, cpu_cores, cpu_load, memory_used_pct,
                disk_used_pct, uptime_seconds, temperature_c, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (server_name, _now_iso(), metrics["cpu_cores"], metrics["cpu_load"],
             metrics["memory_used_pct"], metrics["disk_used_pct"],
             metrics["uptime_seconds"], metrics["temperature_c"],
             json.dumps(sections)),
        )
        conn.commit()
        row_id = cur.lastrowid
    finally:
        conn.close()

    alerts = _check_health_thresholds(server_name, metrics)
    return row_id, alerts


def record_service_event(server_name: str, service_name: str,
                         old_status: str, new_status: str, action: str) -> int:
    """Record a service status change. Returns row_id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO service_events
               (server_name, service_name, timestamp, old_status, new_status, action)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (server_name, service_name, _now_iso(), old_status, new_status, action),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def record_endpoint_check(url_or_domain: str, check_type: str, status: str,
                          response_time_ms: int | None, details: dict) -> int:
    """Record an HTTP or SSL check result. Returns row_id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO endpoint_checks
               (url_or_domain, check_type, timestamp, status, response_time_ms, details)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (url_or_domain, check_type, _now_iso(), status,
             response_time_ms, json.dumps(details)),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def record_alert(server_name: str, severity: str, category: str, message: str) -> int:
    """Record a new alert. Returns row_id.
    Skips if an identical unresolved alert already exists (dedup)."""
    conn = _get_conn()
    try:
        # Dedup: don't create duplicate unresolved alerts for same server+category
        existing = conn.execute(
            """SELECT id FROM alerts
               WHERE server_name = ? AND category = ? AND resolved = 0""",
            (server_name, category),
        ).fetchone()
        if existing:
            return existing["id"]

        cur = conn.execute(
            """INSERT INTO alerts
               (server_name, timestamp, severity, category, message)
               VALUES (?, ?, ?, ?, ?)""",
            (server_name, _now_iso(), severity, category, message),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def resolve_alert(alert_id: int) -> bool:
    """Mark an alert as resolved. Returns True if found and updated."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE alerts SET resolved = 1, resolved_at = ? WHERE id = ? AND resolved = 0",
            (_now_iso(), alert_id),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------
def record_audit(tool_name: str, server_name: str | None, params: dict,
                 result_summary: str, success: bool = True) -> int:
    """Record a tool invocation in the audit log. Returns row_id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO audit_log
               (timestamp, tool_name, server_name, params, result_summary, success)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (_now_iso(), tool_name, server_name, json.dumps(params),
             result_summary[:2000] if result_summary else "", 1 if success else 0),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_audit_log(tool_name: str | None = None, server_name: str | None = None,
                  hours: int = 24, limit: int = 100) -> list[dict]:
    """Query the audit log with optional filters."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        query = "SELECT * FROM audit_log WHERE timestamp > ?"
        params: list = [cutoff]
        if tool_name:
            query += " AND tool_name = ?"
            params.append(tool_name)
        if server_name:
            query += " AND server_name = ?"
            params.append(server_name)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Query functions
# ---------------------------------------------------------------------------
def get_health_history(server_name: str, hours: int = 24) -> list[dict]:
    """Get health snapshots for a server within the last N hours."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT id, server_name, timestamp, cpu_cores, cpu_load,
                      memory_used_pct, disk_used_pct, uptime_seconds, temperature_c
               FROM health_snapshots
               WHERE server_name = ? AND timestamp > ?
               ORDER BY timestamp DESC LIMIT 100""",
            (server_name, cutoff),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_service_events(server_name: str | None = None, hours: int = 24) -> list[dict]:
    """Get service events, optionally filtered by server."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        if server_name:
            rows = conn.execute(
                """SELECT * FROM service_events
                   WHERE server_name = ? AND timestamp > ?
                   ORDER BY timestamp DESC LIMIT 100""",
                (server_name, cutoff),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT * FROM service_events
                   WHERE timestamp > ?
                   ORDER BY timestamp DESC LIMIT 100""",
                (cutoff,),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_alerts(server_name: str | None = None, resolved: bool = False) -> list[dict]:
    """Get alerts, optionally filtered by server. Default: unresolved only."""
    conn = _get_conn()
    try:
        resolved_val = 1 if resolved else 0
        if server_name:
            rows = conn.execute(
                """SELECT * FROM alerts
                   WHERE server_name = ? AND resolved = ?
                   ORDER BY
                     CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END,
                     timestamp DESC
                   LIMIT 100""",
                (server_name, resolved_val),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT * FROM alerts
                   WHERE resolved = ?
                   ORDER BY
                     CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END,
                     timestamp DESC
                   LIMIT 100""",
                (resolved_val,),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_endpoint_history(url_or_domain: str, hours: int = 24) -> list[dict]:
    """Get endpoint check history for a URL or domain."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT * FROM endpoint_checks
               WHERE url_or_domain = ? AND timestamp > ?
               ORDER BY timestamp DESC LIMIT 100""",
            (url_or_domain, cutoff),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_all_endpoint_history(hours: int = 24) -> list[dict]:
    """Get all endpoint checks within the last N hours."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT * FROM endpoint_checks
               WHERE timestamp > ?
               ORDER BY timestamp DESC LIMIT 200""",
            (cutoff,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Anomaly baselines
# ---------------------------------------------------------------------------
def upsert_baseline(server_name: str, metric: str, hour_of_day: int,
                    day_of_week: int, mean: float, stddev: float,
                    sample_count: int) -> None:
    """Insert or update an anomaly baseline entry."""
    conn = _get_conn()
    try:
        conn.execute(
            """INSERT INTO anomaly_baselines
               (server_name, metric, hour_of_day, day_of_week, mean, stddev, sample_count, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(server_name, metric, hour_of_day, day_of_week)
               DO UPDATE SET mean=?, stddev=?, sample_count=?, updated_at=?""",
            (server_name, metric, hour_of_day, day_of_week, mean, stddev,
             sample_count, _now_iso(), mean, stddev, sample_count, _now_iso()),
        )
        conn.commit()
    finally:
        conn.close()


def get_baseline(server_name: str, metric: str, hour_of_day: int,
                 day_of_week: int) -> dict | None:
    """Get the baseline for a specific server/metric/time slot."""
    conn = _get_conn()
    try:
        row = conn.execute(
            """SELECT * FROM anomaly_baselines
               WHERE server_name = ? AND metric = ? AND hour_of_day = ? AND day_of_week = ?""",
            (server_name, metric, hour_of_day, day_of_week),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_all_baselines(server_name: str) -> list[dict]:
    """Get all baselines for a server."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM anomaly_baselines WHERE server_name = ? ORDER BY metric, hour_of_day",
            (server_name,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Playbook runs
# ---------------------------------------------------------------------------
def record_playbook_run(server_name: str, playbook_name: str,
                        trigger_condition: str, actions_taken: str,
                        success: bool = True, output: str = "") -> int:
    """Record a playbook execution. Returns row_id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO playbook_runs
               (server_name, playbook_name, trigger_condition, actions_taken,
                timestamp, success, output)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (server_name, playbook_name, trigger_condition, actions_taken,
             _now_iso(), 1 if success else 0, output[:5000]),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_playbook_runs(server_name: str | None = None, hours: int = 24) -> list[dict]:
    """Get playbook run history."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        if server_name:
            rows = conn.execute(
                """SELECT * FROM playbook_runs
                   WHERE server_name = ? AND timestamp > ?
                   ORDER BY timestamp DESC LIMIT 100""",
                (server_name, cutoff),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT * FROM playbook_runs WHERE timestamp > ?
                   ORDER BY timestamp DESC LIMIT 100""",
                (cutoff,),
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# User management (team/multi-tenant)
# ---------------------------------------------------------------------------
def create_user(username: str, api_key: str, role: str = "viewer") -> int:
    """Create a new user. Returns row_id."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO users (username, api_key, role, created_at) VALUES (?, ?, ?, ?)",
            (username, api_key, role, _now_iso()),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_user_by_api_key(api_key: str) -> dict | None:
    """Look up a user by API key."""
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM users WHERE api_key = ? AND active = 1", (api_key,)
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE users SET last_seen = ? WHERE id = ?", (_now_iso(), row["id"])
            )
            conn.commit()
        return dict(row) if row else None
    finally:
        conn.close()


def list_users() -> list[dict]:
    """List all active users."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT id, username, role, created_at, last_seen FROM users WHERE active = 1"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def update_user_role(username: str, role: str) -> bool:
    """Update a user's role. Returns True if updated."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE users SET role = ? WHERE username = ? AND active = 1",
            (role, username),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def delete_user(username: str) -> bool:
    """Soft-delete a user. Returns True if found."""
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE users SET active = 0 WHERE username = ? AND active = 1", (username,)
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Dashboard queries
# ---------------------------------------------------------------------------
def get_latest_health_all_servers() -> list[dict]:
    """Get the most recent health snapshot for each server."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT h.* FROM health_snapshots h
               INNER JOIN (
                   SELECT server_name, MAX(timestamp) as max_ts
                   FROM health_snapshots GROUP BY server_name
               ) latest ON h.server_name = latest.server_name
               AND h.timestamp = latest.max_ts
               ORDER BY h.server_name"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_alert_counts() -> dict:
    """Get count of unresolved alerts by severity."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT severity, COUNT(*) as cnt FROM alerts
               WHERE resolved = 0 GROUP BY severity"""
        ).fetchall()
        return {r["severity"]: r["cnt"] for r in rows}
    finally:
        conn.close()


def get_recent_events(hours: int = 24, limit: int = 50) -> list[dict]:
    """Get recent events across all types for the dashboard timeline."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        events = []
        # Health alerts
        for row in conn.execute(
            """SELECT timestamp, server_name, severity, category, message
               FROM alerts WHERE timestamp > ? ORDER BY timestamp DESC LIMIT ?""",
            (cutoff, limit),
        ).fetchall():
            events.append({**dict(row), "event_type": "alert"})
        # Service events
        for row in conn.execute(
            """SELECT timestamp, server_name, service_name, old_status, new_status, action
               FROM service_events WHERE timestamp > ? ORDER BY timestamp DESC LIMIT ?""",
            (cutoff, limit),
        ).fetchall():
            events.append({**dict(row), "event_type": "service"})
        # Playbook runs
        for row in conn.execute(
            """SELECT timestamp, server_name, playbook_name, trigger_condition, success
               FROM playbook_runs WHERE timestamp > ? ORDER BY timestamp DESC LIMIT ?""",
            (cutoff, limit),
        ).fetchall():
            events.append({**dict(row), "event_type": "playbook"})
        events.sort(key=lambda e: e["timestamp"], reverse=True)
        return events[:limit]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Log entries
# ---------------------------------------------------------------------------
def store_log_entries(entries: list[dict]) -> int:
    """Bulk insert log entries. Returns count inserted."""
    conn = _get_conn()
    try:
        conn.executemany(
            """INSERT INTO log_entries (server_name, source, timestamp, level, message, pattern_hash)
               VALUES (?, ?, ?, ?, ?, ?)""",
            [(e["server_name"], e["source"], e["timestamp"], e.get("level"),
              e["message"][:2000], e.get("pattern_hash")) for e in entries],
        )
        conn.commit()
        return len(entries)
    finally:
        conn.close()


def search_logs(server_name: str = "", query: str = "", source: str = "",
                level: str = "", hours: int = 24, limit: int = 100) -> list[dict]:
    """Search log entries with filters."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        sql = "SELECT * FROM log_entries WHERE timestamp > ?"
        params: list = [cutoff]
        if server_name:
            sql += " AND server_name = ?"
            params.append(server_name)
        if source:
            sql += " AND source = ?"
            params.append(source)
        if level:
            sql += " AND level = ?"
            params.append(level)
        if query:
            sql += " AND message LIKE ?"
            params.append(f"%{query}%")
        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_log_patterns(server_name: str, hours: int = 24, limit: int = 20) -> list[dict]:
    """Get most frequent log patterns."""
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT pattern_hash, COUNT(*) as count, MIN(message) as sample,
                      MIN(timestamp) as first_seen, MAX(timestamp) as last_seen
               FROM log_entries
               WHERE server_name = ? AND timestamp > ? AND pattern_hash IS NOT NULL
               GROUP BY pattern_hash ORDER BY count DESC LIMIT ?""",
            (server_name, cutoff, limit),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# SLOs
# ---------------------------------------------------------------------------
def create_slo(name: str, target_type: str, target_value: float,
               server_name: str = "", endpoint: str = "", window_days: int = 30) -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO slos (name, target_type, target_value, server_name, endpoint, window_days, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (name, target_type, target_value, server_name, endpoint, window_days, _now_iso()),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_slos(active_only: bool = True) -> list[dict]:
    conn = _get_conn()
    try:
        sql = "SELECT * FROM slos"
        if active_only:
            sql += " WHERE active = 1"
        rows = conn.execute(sql).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def record_slo_measurement(slo_id: int, good: int, total: int, value: float = None) -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO slo_measurements (slo_id, timestamp, good, total, value) VALUES (?, ?, ?, ?, ?)",
            (slo_id, _now_iso(), good, total, value),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_slo_measurements(slo_id: int, days: int = 30) -> list[dict]:
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM slo_measurements WHERE slo_id = ? AND timestamp > ? ORDER BY timestamp",
            (slo_id, cutoff),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_slo(name: str) -> bool:
    conn = _get_conn()
    try:
        cur = conn.execute("UPDATE slos SET active = 0 WHERE name = ? AND active = 1", (name,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# File integrity
# ---------------------------------------------------------------------------
def upsert_file_hash(server_name: str, file_path: str, hash_sha256: str,
                     permissions: str = "", owner: str = "", size_bytes: int = 0) -> bool:
    """Store/update a file hash. Returns True if the hash CHANGED (potential tampering)."""
    conn = _get_conn()
    try:
        existing = conn.execute(
            "SELECT hash_sha256 FROM file_hashes WHERE server_name = ? AND file_path = ?",
            (server_name, file_path),
        ).fetchone()
        now = _now_iso()
        changed = False
        if existing:
            if existing["hash_sha256"] != hash_sha256:
                changed = True
                conn.execute(
                    """UPDATE file_hashes SET hash_sha256=?, permissions=?, owner=?, size_bytes=?,
                       last_checked=?, last_changed=? WHERE server_name=? AND file_path=?""",
                    (hash_sha256, permissions, owner, size_bytes, now, now, server_name, file_path),
                )
            else:
                conn.execute(
                    "UPDATE file_hashes SET last_checked=?, permissions=?, owner=?, size_bytes=? WHERE server_name=? AND file_path=?",
                    (now, permissions, owner, size_bytes, server_name, file_path),
                )
        else:
            conn.execute(
                """INSERT INTO file_hashes (server_name, file_path, hash_sha256, permissions, owner, size_bytes, last_checked, last_changed)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (server_name, file_path, hash_sha256, permissions, owner, size_bytes, now, now),
            )
        conn.commit()
        return changed
    finally:
        conn.close()


def get_file_hashes(server_name: str) -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM file_hashes WHERE server_name = ? ORDER BY file_path", (server_name,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Network metrics
# ---------------------------------------------------------------------------
def record_network_metrics(server_name: str, interface: str, rx_bytes: int, tx_bytes: int,
                           rx_packets: int, tx_packets: int, rx_errors: int, tx_errors: int,
                           conns_established: int = 0, conns_time_wait: int = 0) -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO network_metrics (server_name, interface, timestamp, rx_bytes, tx_bytes,
               rx_packets, tx_packets, rx_errors, tx_errors, connections_established, connections_time_wait)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (server_name, interface, _now_iso(), rx_bytes, tx_bytes, rx_packets, tx_packets,
             rx_errors, tx_errors, conns_established, conns_time_wait),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_network_history(server_name: str, hours: int = 24) -> list[dict]:
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT * FROM network_metrics WHERE server_name = ? AND timestamp > ?
               ORDER BY timestamp DESC LIMIT 500""",
            (server_name, cutoff),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Maintenance windows
# ---------------------------------------------------------------------------
def create_maintenance_window(server_name: str, reason: str,
                              start_time: str, end_time: str, created_by: str = "") -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            "INSERT INTO maintenance_windows (server_name, reason, start_time, end_time, created_by) VALUES (?,?,?,?,?)",
            (server_name, reason, start_time, end_time, created_by),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def is_in_maintenance(server_name: str) -> dict | None:
    """Check if server is currently in a maintenance window."""
    now = _now_iso()
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM maintenance_windows WHERE server_name = ? AND start_time <= ? AND end_time >= ?",
            (server_name, now, now),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_maintenance_windows(server_name: str = "") -> list[dict]:
    conn = _get_conn()
    try:
        if server_name:
            rows = conn.execute(
                "SELECT * FROM maintenance_windows WHERE server_name = ? ORDER BY start_time DESC LIMIT 50",
                (server_name,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM maintenance_windows ORDER BY start_time DESC LIMIT 50"
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_maintenance_window(window_id: int) -> bool:
    conn = _get_conn()
    try:
        cur = conn.execute("DELETE FROM maintenance_windows WHERE id = ?", (window_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# API tests
# ---------------------------------------------------------------------------
def save_api_test(name: str, steps: str, schedule_minutes: int = 0) -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO api_tests (name, steps, schedule_minutes) VALUES (?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET steps=?, schedule_minutes=?""",
            (name, steps, schedule_minutes, steps, schedule_minutes),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_api_tests() -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute("SELECT * FROM api_tests WHERE active = 1").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def update_api_test_result(name: str, result: str) -> None:
    conn = _get_conn()
    try:
        conn.execute(
            "UPDATE api_tests SET last_run = ?, last_result = ? WHERE name = ?",
            (_now_iso(), result[:5000], name),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Service dependencies
# ---------------------------------------------------------------------------
def store_service_dependencies(server_name: str, deps: list[dict]) -> int:
    conn = _get_conn()
    try:
        conn.execute("DELETE FROM service_dependencies WHERE server_name = ?", (server_name,))
        now = _now_iso()
        conn.executemany(
            """INSERT INTO service_dependencies
               (server_name, source_process, source_port, dest_host, dest_port, protocol, discovered_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [(server_name, d["source_process"], d.get("source_port"), d["dest_host"],
              d["dest_port"], d.get("protocol", "tcp"), now) for d in deps],
        )
        conn.commit()
        return len(deps)
    finally:
        conn.close()


def get_service_dependencies(server_name: str) -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM service_dependencies WHERE server_name = ? ORDER BY source_process",
            (server_name,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Organizations (MSP / Multi-Tenant)
# ---------------------------------------------------------------------------
def create_organization(name: str, display_name: str, contact_email: str = "",
                        logo_url: str = "", brand_color: str = "#3b82f6",
                        plan: str = "free", max_servers: int = 5) -> int:
    conn = _get_conn()
    try:
        cur = conn.execute(
            """INSERT INTO organizations
               (name, display_name, logo_url, brand_color, contact_email, plan, max_servers, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (name, display_name, logo_url, brand_color, contact_email, plan, max_servers, _now_iso()),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_organization(name: str) -> dict | None:
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM organizations WHERE name = ? AND active = 1", (name,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_organization_by_id(org_id: int) -> dict | None:
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM organizations WHERE id = ? AND active = 1", (org_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def list_organizations() -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM organizations WHERE active = 1 ORDER BY name"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def update_organization(name: str, **kwargs) -> bool:
    conn = _get_conn()
    try:
        allowed = {"display_name", "logo_url", "brand_color", "contact_email", "plan", "max_servers"}
        updates = {k: v for k, v in kwargs.items() if k in allowed and v is not None}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [name]
        cur = conn.execute(
            f"UPDATE organizations SET {set_clause} WHERE name = ? AND active = 1", values
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def delete_organization(name: str) -> bool:
    conn = _get_conn()
    try:
        cur = conn.execute(
            "UPDATE organizations SET active = 0 WHERE name = ? AND active = 1", (name,)
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Org ↔ Server mapping
# ---------------------------------------------------------------------------
def assign_server_to_org(org_id: int, server_name: str) -> bool:
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO org_servers (org_id, server_name, added_at) VALUES (?, ?, ?)",
            (org_id, server_name, _now_iso()),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def remove_server_from_org(org_id: int, server_name: str) -> bool:
    conn = _get_conn()
    try:
        cur = conn.execute(
            "DELETE FROM org_servers WHERE org_id = ? AND server_name = ?",
            (org_id, server_name),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def get_org_servers(org_id: int) -> list[str]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT server_name FROM org_servers WHERE org_id = ? ORDER BY server_name",
            (org_id,),
        ).fetchall()
        return [r["server_name"] for r in rows]
    finally:
        conn.close()


def get_server_org(server_name: str) -> dict | None:
    """Get the organization a server belongs to."""
    conn = _get_conn()
    try:
        row = conn.execute(
            """SELECT o.* FROM organizations o
               JOIN org_servers os ON o.id = os.org_id
               WHERE os.server_name = ? AND o.active = 1""",
            (server_name,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Org ↔ User mapping
# ---------------------------------------------------------------------------
def assign_user_to_org(org_id: int, user_id: int, role: str = "viewer") -> bool:
    conn = _get_conn()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO org_users (org_id, user_id, role, added_at) VALUES (?, ?, ?, ?)",
            (org_id, user_id, role, _now_iso()),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def get_org_users(org_id: int) -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT u.id, u.username, u.role as global_role, ou.role as org_role, u.last_seen
               FROM users u JOIN org_users ou ON u.id = ou.user_id
               WHERE ou.org_id = ? AND u.active = 1""",
            (org_id,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Org billing
# ---------------------------------------------------------------------------
def record_org_billing(org_id: int, month: str, servers: int,
                       checks: int, alerts: int, notes: str = "") -> None:
    conn = _get_conn()
    try:
        conn.execute(
            """INSERT INTO org_billing (org_id, month, servers_count, checks_count, alerts_count, notes)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(org_id, month) DO UPDATE SET
               servers_count=?, checks_count=?, alerts_count=?, notes=?""",
            (org_id, month, servers, checks, alerts, notes,
             servers, checks, alerts, notes),
        )
        conn.commit()
    finally:
        conn.close()


def get_org_billing(org_id: int, months: int = 12) -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT * FROM org_billing WHERE org_id = ? ORDER BY month DESC LIMIT ?",
            (org_id, months),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Org-scoped queries (filter existing data by org's servers)
# ---------------------------------------------------------------------------
def get_org_health(org_id: int) -> list[dict]:
    """Get latest health for all servers in an org."""
    servers = get_org_servers(org_id)
    if not servers:
        return []
    all_health = get_latest_health_all_servers()
    return [h for h in all_health if h["server_name"] in servers]


def get_org_alerts(org_id: int) -> list[dict]:
    """Get active alerts for all servers in an org."""
    servers = get_org_servers(org_id)
    if not servers:
        return []
    all_alerts = get_alerts(resolved=False)
    return [a for a in all_alerts if a["server_name"] in servers]


def get_org_service_events(org_id: int, hours: int = 24) -> list[dict]:
    """Get service events for all servers in an org."""
    servers = get_org_servers(org_id)
    if not servers:
        return []
    all_events = get_service_events(hours=hours)
    return [e for e in all_events if e["server_name"] in servers]
