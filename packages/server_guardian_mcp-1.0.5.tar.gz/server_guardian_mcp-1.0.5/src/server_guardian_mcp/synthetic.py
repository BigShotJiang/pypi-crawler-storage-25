"""
Server Guardian MCP — Synthetic Monitoring, Composite Alerts, Maintenance Windows,
Resource Rightsizing, Service Dependency Mapping, Root Cause Correlation

Multi-feature module for Tier 2-3 capabilities.
"""

import json
import re
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from . import db as _db


# ---------------------------------------------------------------------------
# Multi-Step API Tests
# ---------------------------------------------------------------------------
def run_api_test(steps: list[dict]) -> dict:
    """Execute a multi-step API test with variable extraction and assertions.

    Each step: {url, method, headers, body, extract: {var: jsonpath}, assert: {status: 200, body_contains: "ok"}}
    Variables from previous steps can be used as {{var_name}}.
    """
    variables = {}
    results = []
    all_passed = True

    for i, step in enumerate(steps):
        url = _interpolate(step.get("url", ""), variables)
        method = step.get("method", "GET")
        headers = {k: _interpolate(v, variables) for k, v in step.get("headers", {}).items()}
        body = step.get("body")
        if body and isinstance(body, str):
            body = _interpolate(body, variables)

        try:
            req = urllib.request.Request(url, method=method)
            req.add_header("User-Agent", "ServerGuardianMCP/0.5")
            for k, v in headers.items():
                req.add_header(k, v)

            if body:
                req.data = body.encode("utf-8")
                if "Content-Type" not in headers:
                    req.add_header("Content-Type", "application/json")

            t0 = time.time()
            with urllib.request.urlopen(req, timeout=15) as resp:
                elapsed = round((time.time() - t0) * 1000)
                status = resp.status
                resp_body = resp.read(8192).decode("utf-8", errors="replace")
                resp_headers = dict(resp.headers)

            step_result = {
                "step": i + 1,
                "url": url,
                "method": method,
                "status_code": status,
                "response_time_ms": elapsed,
                "passed": True,
                "assertions": [],
            }

            # Extract variables
            for var_name, path in step.get("extract", {}).items():
                try:
                    data = json.loads(resp_body)
                    val = _json_extract(data, path)
                    variables[var_name] = str(val) if val is not None else ""
                    step_result.setdefault("extracted", {})[var_name] = variables[var_name]
                except Exception:
                    variables[var_name] = ""

            # Assertions
            assertions = step.get("assert", {})
            if "status" in assertions:
                ok = status == assertions["status"]
                step_result["assertions"].append({"check": f"status == {assertions['status']}", "passed": ok})
                if not ok:
                    step_result["passed"] = False
                    all_passed = False

            if "body_contains" in assertions:
                ok = assertions["body_contains"] in resp_body
                step_result["assertions"].append({"check": f"body contains '{assertions['body_contains']}'", "passed": ok})
                if not ok:
                    step_result["passed"] = False
                    all_passed = False

            if "max_time_ms" in assertions:
                ok = elapsed <= assertions["max_time_ms"]
                step_result["assertions"].append({"check": f"time <= {assertions['max_time_ms']}ms", "passed": ok})
                if not ok:
                    step_result["passed"] = False
                    all_passed = False

        except urllib.error.HTTPError as e:
            step_result = {
                "step": i + 1, "url": url, "method": method,
                "status_code": e.code, "error": str(e.reason), "passed": False,
            }
            all_passed = False
        except Exception as e:
            step_result = {
                "step": i + 1, "url": url, "method": method,
                "error": str(e), "passed": False,
            }
            all_passed = False

        results.append(step_result)

    return {"steps": results, "all_passed": all_passed, "variables": variables}


def _interpolate(s: str, variables: dict) -> str:
    """Replace {{var}} placeholders with variable values."""
    for k, v in variables.items():
        s = s.replace("{{" + k + "}}", v)
    return s


def _json_extract(data, path: str):
    """Simple JSONPath-like extraction. Supports dot notation: data.items.0.id"""
    parts = path.split(".")
    current = data
    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return None
        else:
            return None
    return current


# ---------------------------------------------------------------------------
# Composite Alert Rules
# ---------------------------------------------------------------------------
def evaluate_composite_alert(rule: dict, metrics: dict) -> dict | None:
    """Evaluate a composite alert rule against current metrics.

    rule: {
        name: "High load",
        operator: "AND"|"OR",
        conditions: [{metric: "cpu_load_ratio", op: ">", value: 2}, {metric: "memory_used_pct", op: ">", value: 80}],
        severity: "critical"
    }

    Returns alert dict if triggered, None otherwise.
    """
    conditions = rule.get("conditions", [])
    operator = rule.get("operator", "AND").upper()
    results = []

    for cond in conditions:
        metric = cond.get("metric", "")
        op = cond.get("op", ">")
        threshold = cond.get("value", 0)

        if metric == "cpu_load_ratio":
            load = metrics.get("cpu_load")
            cores = metrics.get("cpu_cores")
            val = (load / cores) if load and cores and cores > 0 else 0
        else:
            val = metrics.get(metric)

        if val is None:
            results.append(False)
            continue

        if op == ">":
            results.append(val > threshold)
        elif op == ">=":
            results.append(val >= threshold)
        elif op == "<":
            results.append(val < threshold)
        elif op == "<=":
            results.append(val <= threshold)
        elif op == "==":
            results.append(val == threshold)
        else:
            results.append(False)

    triggered = all(results) if operator == "AND" else any(results)

    if triggered:
        return {
            "rule": rule.get("name", "unnamed"),
            "severity": rule.get("severity", "warning"),
            "conditions_met": sum(results),
            "conditions_total": len(results),
        }
    return None


# ---------------------------------------------------------------------------
# Resource Rightsizing
# ---------------------------------------------------------------------------
def analyze_rightsizing(health_history: list[dict]) -> dict:
    """Analyze health history for rightsizing recommendations.

    Returns recommendations based on actual usage vs capacity.
    """
    if not health_history:
        return {"recommendations": [], "note": "No health data available"}

    cpu_loads = [h["cpu_load"] for h in health_history if h.get("cpu_load") is not None]
    cpu_cores = health_history[0].get("cpu_cores") if health_history else None
    mem_pcts = [h["memory_used_pct"] for h in health_history if h.get("memory_used_pct") is not None]
    disk_pcts = [h["disk_used_pct"] for h in health_history if h.get("disk_used_pct") is not None]

    recommendations = []

    if cpu_loads and cpu_cores:
        avg_cpu = sum(cpu_loads) / len(cpu_loads)
        max_cpu = max(cpu_loads)
        avg_pct = (avg_cpu / cpu_cores) * 100

        if avg_pct < 10 and max_cpu < cpu_cores * 0.3:
            recommendations.append({
                "resource": "CPU",
                "finding": f"Average CPU usage {avg_pct:.1f}% ({avg_cpu:.1f}/{cpu_cores} cores). Peak: {max_cpu:.1f}",
                "recommendation": f"Server is heavily over-provisioned. Consider downsizing from {cpu_cores} to {max(1, cpu_cores // 2)} cores.",
                "potential_savings": "50% CPU cost reduction",
                "severity": "high",
            })
        elif avg_pct < 25:
            recommendations.append({
                "resource": "CPU",
                "finding": f"Average CPU usage {avg_pct:.1f}%",
                "recommendation": "CPU is underutilized. Consider downsizing if costs are a concern.",
                "severity": "medium",
            })

    if mem_pcts:
        avg_mem = sum(mem_pcts) / len(mem_pcts)
        max_mem = max(mem_pcts)

        if avg_mem < 20 and max_mem < 40:
            recommendations.append({
                "resource": "Memory",
                "finding": f"Average memory usage {avg_mem:.1f}%. Peak: {max_mem:.1f}%",
                "recommendation": "Memory significantly underutilized. Consider halving RAM allocation.",
                "potential_savings": "50% memory cost reduction",
                "severity": "high",
            })
        elif avg_mem > 90:
            recommendations.append({
                "resource": "Memory",
                "finding": f"Average memory usage {avg_mem:.1f}%. Peak: {max_mem:.1f}%",
                "recommendation": "Memory consistently near capacity. Consider upgrading RAM.",
                "severity": "high",
            })

    if disk_pcts:
        avg_disk = sum(disk_pcts) / len(disk_pcts)
        if avg_disk < 30:
            recommendations.append({
                "resource": "Disk",
                "finding": f"Average disk usage {avg_disk:.1f}%",
                "recommendation": "Disk significantly underutilized. Consider smaller volume.",
                "severity": "low",
            })
        elif avg_disk > 85:
            recommendations.append({
                "resource": "Disk",
                "finding": f"Average disk usage {avg_disk:.1f}%",
                "recommendation": "Disk nearing capacity. Expand volume or clean up.",
                "severity": "high",
            })

    if not recommendations:
        recommendations.append({
            "resource": "Overall",
            "finding": "Resource allocation appears well-matched to usage.",
            "recommendation": "No rightsizing changes recommended at this time.",
            "severity": "info",
        })

    return {
        "recommendations": recommendations,
        "data_points": len(health_history),
        "analysis_period": f"{len(health_history)} snapshots",
    }


# ---------------------------------------------------------------------------
# Service Dependency Mapping
# ---------------------------------------------------------------------------
def parse_connections_for_deps(raw_ss: str, server_name: str) -> list[dict]:
    """Parse `ss -tnap` output to discover service dependencies.

    Looks for ESTAB connections and maps source process -> dest host:port.
    """
    deps = []
    seen = set()

    for line in raw_ss.splitlines():
        if "ESTAB" not in line:
            continue

        parts = line.split()
        if len(parts) < 6:
            continue

        local = parts[3] if len(parts) > 3 else ""
        peer = parts[4] if len(parts) > 4 else ""
        process_info = parts[5] if len(parts) > 5 else ""

        # Extract process name
        proc_match = re.search(r'users:\(\("([^"]+)"', process_info)
        proc_name = proc_match.group(1) if proc_match else "unknown"

        # Parse peer address
        if ":" in peer:
            peer_parts = peer.rsplit(":", 1)
            dest_host = peer_parts[0]
            try:
                dest_port = int(peer_parts[1])
            except ValueError:
                continue
        else:
            continue

        # Skip localhost connections and duplicates
        if dest_host in ("127.0.0.1", "::1", "[::1]"):
            continue

        key = f"{proc_name}:{dest_host}:{dest_port}"
        if key in seen:
            continue
        seen.add(key)

        # Extract source port
        source_port = None
        if ":" in local:
            try:
                source_port = int(local.rsplit(":", 1)[1])
            except ValueError:
                pass

        deps.append({
            "source_process": proc_name,
            "source_port": source_port,
            "dest_host": dest_host,
            "dest_port": dest_port,
            "protocol": "tcp",
        })

    return deps


# ---------------------------------------------------------------------------
# Root Cause Correlation
# ---------------------------------------------------------------------------
def correlate_root_cause(server_name: str, hours: int = 6) -> dict:
    """Correlate anomalies across metrics, logs, services, and alerts to suggest root cause.

    Looks at temporal correlation: what happened around the same time as alerts?
    """
    alerts = _db.get_alerts(server_name=server_name, resolved=False)
    svc_events = _db.get_service_events(server_name=server_name, hours=hours)
    health = _db.get_health_history(server_name, hours=hours)
    pb_runs = _db.get_playbook_runs(server_name=server_name, hours=hours)

    correlations = []

    # Check if health degradation coincides with service failures
    if svc_events and health:
        for event in svc_events:
            if event.get("new_status") == "failed":
                # Find health snapshot closest to this event
                event_time = event["timestamp"]
                closest = min(health, key=lambda h: abs(
                    datetime.fromisoformat(h["timestamp"]).timestamp() -
                    datetime.fromisoformat(event_time).timestamp()
                )) if health else None

                if closest:
                    findings = []
                    if closest.get("cpu_load") and closest.get("cpu_cores"):
                        ratio = closest["cpu_load"] / closest["cpu_cores"]
                        if ratio > 1.5:
                            findings.append(f"CPU load was high ({ratio:.1f}x cores)")
                    if closest.get("memory_used_pct") and closest["memory_used_pct"] > 85:
                        findings.append(f"Memory was at {closest['memory_used_pct']:.1f}%")
                    if closest.get("disk_used_pct") and closest["disk_used_pct"] > 90:
                        findings.append(f"Disk was at {closest['disk_used_pct']:.1f}%")

                    if findings:
                        correlations.append({
                            "event": f"Service {event['service_name']} failed",
                            "time": event_time,
                            "correlated_metrics": findings,
                            "possible_cause": "Resource exhaustion may have caused service failure",
                        })

    # Check for cascading failures
    if len(svc_events) > 2:
        failed_times = [e["timestamp"] for e in svc_events if e.get("new_status") == "failed"]
        if len(failed_times) > 2:
            correlations.append({
                "event": "Multiple service failures",
                "count": len(failed_times),
                "possible_cause": "Cascading failure pattern detected — check shared dependencies",
            })

    # Disk-related correlations
    for h in health:
        if h.get("disk_used_pct") and h["disk_used_pct"] > 95:
            correlations.append({
                "event": f"Disk at {h['disk_used_pct']:.1f}%",
                "time": h["timestamp"],
                "possible_cause": "Full disk can cause service crashes, log write failures, and database issues",
            })
            break

    return {
        "server": server_name,
        "period_hours": hours,
        "correlations": correlations,
        "data": {
            "alerts": len(alerts),
            "service_events": len(svc_events),
            "health_snapshots": len(health),
            "playbook_runs": len(pb_runs),
        },
        "summary": correlations[0]["possible_cause"] if correlations else "No correlations found — system appears healthy",
    }
