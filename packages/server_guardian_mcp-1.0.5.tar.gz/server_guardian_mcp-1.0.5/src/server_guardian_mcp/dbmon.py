"""
Server Guardian MCP — Database Monitoring

Parse slow query logs, pg_stat_statements, replication lag,
connection counts, table sizes — all via SSH.
"""

import re


def parse_mysql_slow_log(raw: str) -> list[dict]:
    """Parse MySQL slow query log output."""
    queries = []
    current = {}
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("# Time:"):
            if current.get("query"):
                queries.append(current)
            current = {"time": line.replace("# Time:", "").strip()}
        elif line.startswith("# User@Host:"):
            current["user_host"] = line.replace("# User@Host:", "").strip()
        elif line.startswith("# Query_time:"):
            m = re.search(r"Query_time:\s*([\d.]+)\s+Lock_time:\s*([\d.]+)\s+Rows_sent:\s*(\d+)\s+Rows_examined:\s*(\d+)", line)
            if m:
                current["query_time_s"] = float(m.group(1))
                current["lock_time_s"] = float(m.group(2))
                current["rows_sent"] = int(m.group(3))
                current["rows_examined"] = int(m.group(4))
        elif not line.startswith("#") and line:
            current.setdefault("query", "")
            current["query"] += " " + line

    if current.get("query"):
        queries.append(current)

    for q in queries:
        if "query" in q:
            q["query"] = q["query"].strip()[:500]

    return sorted(queries, key=lambda x: x.get("query_time_s", 0), reverse=True)


def parse_pg_stat_statements(raw: str) -> list[dict]:
    """Parse pg_stat_statements output (tab-separated from psql)."""
    lines = raw.strip().splitlines()
    if len(lines) < 2:
        return []

    results = []
    for line in lines[2:]:  # Skip header and separator
        parts = [p.strip() for p in line.split("|")]
        if len(parts) >= 5:
            try:
                results.append({
                    "query": parts[0][:300],
                    "calls": int(parts[1]) if parts[1].strip().isdigit() else 0,
                    "total_time_ms": float(parts[2]) if parts[2].strip() else 0,
                    "mean_time_ms": float(parts[3]) if parts[3].strip() else 0,
                    "rows": int(parts[4]) if parts[4].strip().isdigit() else 0,
                })
            except (ValueError, IndexError):
                continue

    return sorted(results, key=lambda x: x.get("total_time_ms", 0), reverse=True)


def parse_replication_status(raw: str, db_type: str = "mysql") -> dict:
    """Parse replication status output."""
    if db_type == "mysql":
        result = {"type": "mysql"}
        for line in raw.splitlines():
            if "Seconds_Behind_Master" in line:
                m = re.search(r"Seconds_Behind_Master:\s*(\S+)", line)
                if m and m.group(1) != "NULL":
                    result["lag_seconds"] = int(m.group(1))
                else:
                    result["lag_seconds"] = None
            if "Slave_IO_Running" in line:
                result["io_running"] = "Yes" in line
            if "Slave_SQL_Running" in line:
                result["sql_running"] = "Yes" in line
        return result
    elif db_type == "postgresql":
        result = {"type": "postgresql", "replicas": []}
        for line in raw.splitlines():
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 3 and parts[0] and not parts[0].startswith("-"):
                result["replicas"].append({
                    "client": parts[0],
                    "state": parts[1] if len(parts) > 1 else "",
                    "lag": parts[2] if len(parts) > 2 else "",
                })
        return result
    return {"type": db_type, "raw": raw[:500]}


def parse_connection_stats(raw: str) -> dict:
    """Parse database connection statistics."""
    result = {"active": 0, "idle": 0, "total": 0, "max": 0}
    for line in raw.splitlines():
        line_lower = line.lower().strip()
        if "active" in line_lower:
            m = re.search(r"(\d+)", line)
            if m:
                result["active"] = int(m.group(1))
        elif "idle" in line_lower:
            m = re.search(r"(\d+)", line)
            if m:
                result["idle"] = int(m.group(1))
        elif "max_connections" in line_lower:
            m = re.search(r"(\d+)", line)
            if m:
                result["max"] = int(m.group(1))

    # Also try parsing a simple count
    for line in raw.splitlines():
        m = re.match(r"\s*(\d+)\s*$", line.strip())
        if m:
            result["total"] = int(m.group(1))
            break

    if result["active"] or result["idle"]:
        result["total"] = result["active"] + result["idle"]

    return result


def parse_table_sizes(raw: str) -> list[dict]:
    """Parse table size output from pg_total_relation_size or MySQL."""
    tables = []
    for line in raw.splitlines():
        parts = [p.strip() for p in line.split("|")]
        if len(parts) >= 2 and parts[0] and not parts[0].startswith("-"):
            try:
                tables.append({
                    "table": parts[0],
                    "size": parts[1],
                })
            except (ValueError, IndexError):
                continue
    return tables


# ---------------------------------------------------------------------------
# SSH command generators for database monitoring
# ---------------------------------------------------------------------------
def get_mysql_commands() -> dict:
    """Return SSH commands for MySQL monitoring."""
    return {
        "slow_queries": "mysql -e \"SELECT * FROM mysql.slow_log ORDER BY query_time DESC LIMIT 20\" 2>/dev/null || tail -100 /var/log/mysql/mysql-slow.log 2>/dev/null || echo 'no slow log'",
        "connections": "mysql -e \"SHOW STATUS WHERE Variable_name IN ('Threads_connected','Threads_running','Max_used_connections'); SHOW VARIABLES LIKE 'max_connections'\" 2>/dev/null || echo 'mysql not available'",
        "replication": "mysql -e \"SHOW SLAVE STATUS\\G\" 2>/dev/null || echo 'no replication'",
        "table_sizes": "mysql -e \"SELECT table_schema, table_name, ROUND((data_length + index_length) / 1024 / 1024, 2) AS size_mb FROM information_schema.tables ORDER BY (data_length + index_length) DESC LIMIT 20\" 2>/dev/null || echo 'mysql not available'",
        "processlist": "mysql -e \"SHOW FULL PROCESSLIST\" 2>/dev/null || echo 'mysql not available'",
    }


def get_postgresql_commands() -> dict:
    """Return SSH commands for PostgreSQL monitoring."""
    return {
        "slow_queries": "sudo -u postgres psql -c \"SELECT query, calls, total_exec_time, mean_exec_time, rows FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 20\" 2>/dev/null || echo 'pg_stat_statements not available'",
        "connections": "sudo -u postgres psql -c \"SELECT state, count(*) FROM pg_stat_activity GROUP BY state\" 2>/dev/null || echo 'postgresql not available'",
        "replication": "sudo -u postgres psql -c \"SELECT client_addr, state, sent_lsn, write_lsn, replay_lsn, replay_lag FROM pg_stat_replication\" 2>/dev/null || echo 'no replication'",
        "table_sizes": "sudo -u postgres psql -c \"SELECT schemaname||'.'||relname AS table, pg_size_pretty(pg_total_relation_size(relid)) AS size FROM pg_catalog.pg_statio_user_tables ORDER BY pg_total_relation_size(relid) DESC LIMIT 20\" 2>/dev/null || echo 'postgresql not available'",
        "locks": "sudo -u postgres psql -c \"SELECT pid, usename, query, state, wait_event_type, wait_event FROM pg_stat_activity WHERE state != 'idle' AND wait_event IS NOT NULL LIMIT 20\" 2>/dev/null || echo 'no locks'",
        "cache_hit_ratio": "sudo -u postgres psql -c \"SELECT round(100.0 * sum(blks_hit) / (sum(blks_hit) + sum(blks_read)), 2) AS cache_hit_ratio FROM pg_stat_database\" 2>/dev/null || echo 'not available'",
    }
