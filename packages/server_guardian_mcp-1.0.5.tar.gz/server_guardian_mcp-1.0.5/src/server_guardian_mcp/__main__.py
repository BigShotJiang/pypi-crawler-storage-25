"""Entry point for running as: python -m server_guardian_mcp

Usage:
    python -m server_guardian_mcp                        # start MCP server (stdio)
    python -m server_guardian_mcp --transport sse         # start MCP server (SSE, port 8000)
    python -m server_guardian_mcp --transport sse --port 3333  # SSE on custom port
    python -m server_guardian_mcp watchdog                # start background watchdog
    python -m server_guardian_mcp watchdog --once         # run one watchdog cycle
    python -m server_guardian_mcp dashboard               # start live web dashboard (port 8080)
    python -m server_guardian_mcp dashboard --port 9090   # dashboard on custom port
"""
import os
import sys


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "watchdog":
        # Remove "watchdog" from argv so --once flag works
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        from .watchdog import main as watchdog_main
        watchdog_main()

    elif len(sys.argv) > 1 and sys.argv[1] == "dashboard":
        # Parse dashboard args
        port = 8080
        host = "0.0.0.0"
        args = sys.argv[2:]
        i = 0
        while i < len(args):
            if args[i] == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
                i += 2
            elif args[i] == "--host" and i + 1 < len(args):
                host = args[i + 1]
                i += 2
            else:
                i += 1

        from .dashboard import run_dashboard
        run_dashboard(host=host, port=port)

    else:
        transport = "stdio"
        port = 8000
        args = sys.argv[1:]
        i = 0
        while i < len(args):
            if args[i] == "--transport" and i + 1 < len(args):
                transport = args[i + 1]
                i += 2
            elif args[i] == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
                i += 2
            else:
                i += 1

        from .server import mcp
        if transport == "sse":
            mcp.settings.host = "0.0.0.0"
            mcp.settings.port = port
            mcp.run(transport="sse")
        else:
            mcp.run()


if __name__ == "__main__":
    main()
