"""
Server Guardian MCP — Auto-Remediation Playbooks

YAML-based playbook engine that defines conditions and actions.
When a condition is met (disk full, service failed, high CPU, etc.),
the corresponding actions are executed automatically.

Playbooks are loaded from ~/.server-guardian-mcp/playbooks/ directory
or from the built-in defaults.
"""

import json
import logging
import os
import re
from pathlib import Path

from . import db as _db

log = logging.getLogger("playbooks")

# ---------------------------------------------------------------------------
# Playbook directory
# ---------------------------------------------------------------------------
PLAYBOOK_DIR = Path.home() / ".server-guardian-mcp" / "playbooks"

# ---------------------------------------------------------------------------
# Built-in playbooks (no YAML dependency needed)
# ---------------------------------------------------------------------------
BUILTIN_PLAYBOOKS = [
    {
        "name": "disk_cleanup",
        "description": "Clean up disk when usage exceeds threshold",
        "trigger": {"metric": "disk_used_pct", "operator": ">", "value": 90},
        "actions": [
            {"type": "command", "run": "journalctl --vacuum-size=100M 2>&1 || true"},
            {"type": "command", "run": "find /tmp -type f -atime +7 -delete 2>&1 || true"},
            {"type": "command", "run": "find /var/log -name '*.gz' -mtime +30 -delete 2>&1 || true"},
            {"type": "command", "run": "apt-get clean 2>/dev/null; yum clean all 2>/dev/null; true"},
            {"type": "command", "run": "df -h / | tail -1"},
        ],
        "cooldown_minutes": 60,
    },
    {
        "name": "restart_failed_services",
        "description": "Auto-restart any failed systemd services",
        "trigger": {"type": "failed_services"},
        "actions": [
            {"type": "restart_service"},
        ],
        "cooldown_minutes": 15,
    },
    {
        "name": "high_memory_cleanup",
        "description": "Clear caches when memory usage is critical",
        "trigger": {"metric": "memory_used_pct", "operator": ">", "value": 95},
        "actions": [
            {"type": "command", "run": "sync; echo 3 > /proc/sys/vm/drop_caches 2>&1 || true"},
            {"type": "command", "run": "free -h | head -2"},
        ],
        "cooldown_minutes": 30,
    },
    {
        "name": "high_cpu_investigation",
        "description": "Log top CPU consumers when load is excessive",
        "trigger": {"metric": "cpu_load_ratio", "operator": ">", "value": 3.0},
        "actions": [
            {"type": "command", "run": "ps aux --sort=-%cpu | head -10"},
            {"type": "command", "run": "top -bn1 | head -20"},
        ],
        "cooldown_minutes": 15,
    },
    {
        "name": "ssl_renewal",
        "description": "Attempt SSL cert renewal when expiry is near",
        "trigger": {"type": "ssl_expiring", "days": 7},
        "actions": [
            {"type": "command", "run": "certbot renew --non-interactive 2>&1 || true"},
            {"type": "command", "run": "systemctl reload nginx 2>&1 || systemctl reload apache2 2>&1 || true"},
        ],
        "cooldown_minutes": 1440,
    },
]


def _load_custom_playbooks() -> list[dict]:
    """Load custom playbooks from JSON files in the playbook directory."""
    if not PLAYBOOK_DIR.exists():
        return []
    playbooks = []
    for f in sorted(PLAYBOOK_DIR.glob("*.json")):
        try:
            with open(f) as fh:
                pb = json.load(fh)
                if isinstance(pb, dict) and "name" in pb and "trigger" in pb and "actions" in pb:
                    pb.setdefault("cooldown_minutes", 30)
                    playbooks.append(pb)
                elif isinstance(pb, list):
                    for item in pb:
                        if isinstance(item, dict) and "name" in item:
                            item.setdefault("cooldown_minutes", 30)
                            playbooks.append(item)
        except Exception as e:
            log.warning(f"Failed to load playbook {f}: {e}")
    return playbooks


def get_all_playbooks() -> list[dict]:
    """Get all playbooks (built-in + custom)."""
    custom = _load_custom_playbooks()
    # Custom playbooks override built-ins with same name
    custom_names = {p["name"] for p in custom}
    result = [p for p in BUILTIN_PLAYBOOKS if p["name"] not in custom_names]
    result.extend(custom)
    return result


def _check_cooldown(server_name: str, playbook_name: str, cooldown_minutes: int) -> bool:
    """Check if a playbook has run recently (within cooldown period).
    Returns True if on cooldown (should NOT run), False if clear to run."""
    recent = _db.get_playbook_runs(server_name=server_name, hours=max(cooldown_minutes // 60 + 1, 1))
    for run in recent:
        if run["playbook_name"] == playbook_name:
            return True
    return False


def evaluate_metric_trigger(trigger: dict, metrics: dict) -> bool:
    """Check if a metric-based trigger condition is met."""
    metric = trigger.get("metric", "")
    operator = trigger.get("operator", ">")
    threshold = trigger.get("value", 0)

    # Handle cpu_load_ratio (load / cores)
    if metric == "cpu_load_ratio":
        load = metrics.get("cpu_load")
        cores = metrics.get("cpu_cores")
        if load is None or cores is None or cores == 0:
            return False
        value = load / cores
    else:
        value = metrics.get(metric)

    if value is None:
        return False

    if operator == ">":
        return value > threshold
    elif operator == ">=":
        return value >= threshold
    elif operator == "<":
        return value < threshold
    elif operator == "<=":
        return value <= threshold
    elif operator == "==":
        return value == threshold
    return False


def execute_playbook(playbook: dict, server_info: dict, context: dict,
                     exec_fn=None) -> dict:
    """Execute a playbook's actions on a server.

    Args:
        playbook: The playbook definition
        server_info: Resolved server connection info
        context: Trigger context (metrics, failed_services, etc.)
        exec_fn: Function to execute commands (defaults to _ssh_exec from server module)

    Returns:
        {playbook, server, actions_taken, outputs, success}
    """
    if exec_fn is None:
        from .server import _ssh_exec
        exec_fn = _ssh_exec

    server_name = server_info.get("name", "unknown")
    playbook_name = playbook["name"]
    cooldown = playbook.get("cooldown_minutes", 30)

    # Check cooldown
    if _check_cooldown(server_name, playbook_name, cooldown):
        return {
            "playbook": playbook_name,
            "server": server_name,
            "skipped": True,
            "reason": f"On cooldown ({cooldown} min)",
        }

    actions_taken = []
    outputs = []
    all_success = True

    for action in playbook.get("actions", []):
        action_type = action.get("type", "command")

        if action_type == "command":
            cmd = action.get("run", "")
            if not cmd:
                continue
            try:
                results = exec_fn(server_info, [cmd], per_cmd_timeout=30)
                output = results[0].get("stdout", "") if results else ""
                exit_code = results[0].get("exit_code", -1) if results else -1
                actions_taken.append(f"command: {cmd}")
                outputs.append({"command": cmd, "output": output[:2000], "exit_code": exit_code})
                if exit_code != 0:
                    all_success = False
            except Exception as e:
                actions_taken.append(f"command (FAILED): {cmd}")
                outputs.append({"command": cmd, "error": str(e)})
                all_success = False

        elif action_type == "restart_service":
            failed_services = context.get("failed_services", [])
            for svc in failed_services:
                try:
                    cmd = f"systemctl restart {svc} 2>&1; systemctl is-active {svc} 2>&1"
                    results = exec_fn(server_info, [cmd], per_cmd_timeout=30)
                    output = results[0].get("stdout", "") if results else ""
                    new_status = output.strip().split("\n")[-1].strip()
                    _db.record_service_event(server_name, svc, "failed", new_status, "playbook-restart")
                    actions_taken.append(f"restart: {svc} → {new_status}")
                    outputs.append({"service": svc, "new_status": new_status})
                except Exception as e:
                    actions_taken.append(f"restart (FAILED): {svc}")
                    outputs.append({"service": svc, "error": str(e)})
                    all_success = False

    # Record the run
    trigger_desc = json.dumps(playbook.get("trigger", {}))
    actions_desc = "; ".join(actions_taken)
    _db.record_playbook_run(
        server_name, playbook_name, trigger_desc, actions_desc,
        success=all_success, output=json.dumps(outputs)[:5000],
    )

    return {
        "playbook": playbook_name,
        "server": server_name,
        "actions_taken": actions_taken,
        "outputs": outputs,
        "success": all_success,
    }


def evaluate_and_run(server_info: dict, metrics: dict,
                     failed_services: list[str] | None = None,
                     ssl_issues: list[dict] | None = None,
                     exec_fn=None) -> list[dict]:
    """Evaluate all playbook triggers against current state and run matching ones.

    Args:
        server_info: Resolved server connection info
        metrics: Current health metrics dict
        failed_services: List of failed service names (if known)
        ssl_issues: List of SSL check results with issues
        exec_fn: Command execution function

    Returns:
        List of execution results for each triggered playbook.
    """
    results = []
    playbooks = get_all_playbooks()
    enabled = os.environ.get("GUARDIAN_PLAYBOOKS", "true").lower() == "true"
    if not enabled:
        return []

    for pb in playbooks:
        trigger = pb.get("trigger", {})
        trigger_type = trigger.get("type", "metric")
        context = {"metrics": metrics}

        triggered = False

        if trigger_type == "failed_services":
            if failed_services:
                triggered = True
                context["failed_services"] = failed_services

        elif trigger_type == "ssl_expiring":
            days_threshold = trigger.get("days", 7)
            if ssl_issues:
                for issue in ssl_issues:
                    if issue.get("days_until_expiry", 999) <= days_threshold:
                        triggered = True
                        context["ssl_issues"] = ssl_issues
                        break

        elif "metric" in trigger:
            triggered = evaluate_metric_trigger(trigger, metrics)

        if triggered:
            log.info(f"Playbook '{pb['name']}' triggered for {server_info.get('name', '?')}")
            result = execute_playbook(pb, server_info, context, exec_fn=exec_fn)
            results.append(result)

    return results


def save_custom_playbook(playbook: dict) -> str:
    """Save a custom playbook to disk. Returns the file path."""
    PLAYBOOK_DIR.mkdir(parents=True, exist_ok=True)
    name = re.sub(r"[^a-zA-Z0-9_-]", "_", playbook.get("name", "custom"))
    path = PLAYBOOK_DIR / f"{name}.json"
    with open(path, "w") as f:
        json.dump(playbook, f, indent=2)
    return str(path)


def list_playbook_files() -> list[str]:
    """List all custom playbook files."""
    if not PLAYBOOK_DIR.exists():
        return []
    return [str(f) for f in sorted(PLAYBOOK_DIR.glob("*.json"))]
