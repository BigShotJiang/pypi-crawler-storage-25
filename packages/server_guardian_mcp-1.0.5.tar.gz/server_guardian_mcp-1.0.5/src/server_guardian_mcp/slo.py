"""
Server Guardian MCP — SLO Tracking & Error Budgets

Define Service Level Objectives, track compliance from stored data,
calculate error budgets and burn rates.

SLO types:
- uptime: % of health checks where server was reachable
- latency: % of endpoint checks under a threshold (ms)
- error_rate: % of requests that are not errors
"""

from datetime import datetime, timedelta, timezone

from . import db as _db


def create(name: str, target_type: str, target_value: float,
           server_name: str = "", endpoint: str = "", window_days: int = 30) -> dict:
    """Create a new SLO.

    target_type: uptime | latency | error_rate
    target_value: the target percentage (e.g. 99.9 for 99.9%)
    """
    if target_type not in ("uptime", "latency", "error_rate"):
        return {"error": f"Invalid target_type '{target_type}'. Use: uptime, latency, error_rate"}
    if target_value <= 0 or target_value > 100:
        return {"error": "target_value must be between 0 and 100"}

    try:
        slo_id = _db.create_slo(name, target_type, target_value, server_name, endpoint, window_days)
        return {"id": slo_id, "name": name, "type": target_type, "target": target_value,
                "window_days": window_days, "created": True}
    except Exception as e:
        if "UNIQUE" in str(e):
            return {"error": f"SLO '{name}' already exists"}
        return {"error": str(e)}


def list_slos() -> list[dict]:
    """List all active SLOs."""
    return _db.get_slos()


def delete(name: str) -> dict:
    if _db.delete_slo(name):
        return {"deleted": True, "name": name}
    return {"error": f"SLO '{name}' not found"}


def calculate_status(slo: dict) -> dict:
    """Calculate current SLO compliance and error budget.

    Returns {slo_name, target, current_value, compliant, error_budget_remaining_pct, ...}
    """
    slo_id = slo["id"]
    name = slo["name"]
    target_type = slo["target_type"]
    target = slo["target_value"]
    window = slo["window_days"]
    server = slo.get("server_name", "")
    endpoint = slo.get("endpoint", "")

    if target_type == "uptime":
        return _calc_uptime_slo(name, target, window, server)
    elif target_type == "latency":
        return _calc_latency_slo(name, target, window, endpoint)
    elif target_type == "error_rate":
        return _calc_error_rate_slo(name, target, window, endpoint)

    return {"slo": name, "error": f"Unknown type '{target_type}'"}


def _calc_uptime_slo(name: str, target: float, window_days: int, server: str) -> dict:
    """Calculate uptime SLO from health snapshots."""
    if not server:
        return {"slo": name, "error": "server_name required for uptime SLO"}

    snapshots = _db.get_health_history(server, hours=window_days * 24)
    total = len(snapshots)
    if total == 0:
        return {"slo": name, "status": "no data", "measurements": 0}

    good = sum(1 for s in snapshots if s.get("cpu_load") is not None)
    current = round((good / total) * 100, 4)
    error_budget_total = 100 - target
    error_budget_used = 100 - current
    error_budget_remaining = max(0, error_budget_total - error_budget_used)

    return {
        "slo": name,
        "type": "uptime",
        "target_pct": target,
        "current_pct": current,
        "compliant": current >= target,
        "measurements": total,
        "good": good,
        "bad": total - good,
        "window_days": window_days,
        "error_budget_total_pct": round(error_budget_total, 4),
        "error_budget_used_pct": round(error_budget_used, 4),
        "error_budget_remaining_pct": round(error_budget_remaining, 4),
    }


def _calc_latency_slo(name: str, target: float, window_days: int, endpoint: str) -> dict:
    """Calculate latency SLO from endpoint checks."""
    if not endpoint:
        return {"slo": name, "error": "endpoint required for latency SLO"}

    checks = _db.get_endpoint_history(endpoint, hours=window_days * 24)
    total = len(checks)
    if total == 0:
        return {"slo": name, "status": "no data", "measurements": 0}

    good = sum(1 for c in checks if c.get("status") in ("PASS", "OK"))
    current = round((good / total) * 100, 4)
    error_budget_total = 100 - target
    error_budget_used = 100 - current
    error_budget_remaining = max(0, error_budget_total - error_budget_used)

    latencies = [c["response_time_ms"] for c in checks if c.get("response_time_ms")]

    result = {
        "slo": name,
        "type": "latency",
        "target_pct": target,
        "current_pct": current,
        "compliant": current >= target,
        "measurements": total,
        "good": good,
        "bad": total - good,
        "window_days": window_days,
        "error_budget_total_pct": round(error_budget_total, 4),
        "error_budget_used_pct": round(error_budget_used, 4),
        "error_budget_remaining_pct": round(error_budget_remaining, 4),
    }

    if latencies:
        latencies.sort()
        result["avg_latency_ms"] = round(sum(latencies) / len(latencies), 1)
        result["p95_latency_ms"] = round(latencies[int(len(latencies) * 0.95)], 1) if len(latencies) > 1 else latencies[0]

    return result


def _calc_error_rate_slo(name: str, target: float, window_days: int, endpoint: str) -> dict:
    """Calculate error rate SLO from endpoint checks."""
    if not endpoint:
        return {"slo": name, "error": "endpoint required for error_rate SLO"}

    checks = _db.get_endpoint_history(endpoint, hours=window_days * 24)
    total = len(checks)
    if total == 0:
        return {"slo": name, "status": "no data", "measurements": 0}

    good = sum(1 for c in checks if c.get("status") in ("PASS", "OK"))
    current = round((good / total) * 100, 4)
    error_budget_total = 100 - target
    error_budget_used = 100 - current
    error_budget_remaining = max(0, error_budget_total - error_budget_used)

    return {
        "slo": name,
        "type": "error_rate",
        "target_pct": target,
        "current_pct": current,
        "compliant": current >= target,
        "measurements": total,
        "good": good,
        "bad": total - good,
        "window_days": window_days,
        "error_budget_total_pct": round(error_budget_total, 4),
        "error_budget_used_pct": round(error_budget_used, 4),
        "error_budget_remaining_pct": round(error_budget_remaining, 4),
    }


def get_all_slo_statuses() -> list[dict]:
    """Get status for all active SLOs."""
    slos = _db.get_slos()
    return [calculate_status(s) for s in slos]
