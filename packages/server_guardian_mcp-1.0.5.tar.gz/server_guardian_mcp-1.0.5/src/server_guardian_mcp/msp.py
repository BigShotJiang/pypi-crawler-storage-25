"""
Server Guardian MCP — Multi-Tenant / MSP Mode

Manage multiple client organizations, each with their own:
- Server groups
- Users with org-scoped roles
- Dashboards and health views
- White-label compliance reports (custom logo, colors, branding)
- Billing tracking (server count, checks, alerts per month)
"""

import json
from datetime import datetime, timezone
from pathlib import Path

from . import db as _db
from .compliance import generate_compliance_report


def create_org(name: str, display_name: str, contact_email: str = "",
               logo_url: str = "", brand_color: str = "#3b82f6",
               plan: str = "free", max_servers: int = 5) -> dict:
    """Create a new client organization."""
    try:
        org_id = _db.create_organization(
            name=name, display_name=display_name, contact_email=contact_email,
            logo_url=logo_url, brand_color=brand_color, plan=plan, max_servers=max_servers,
        )
        return {
            "id": org_id, "name": name, "display_name": display_name,
            "plan": plan, "max_servers": max_servers, "created": True,
        }
    except Exception as e:
        if "UNIQUE" in str(e):
            return {"error": f"Organization '{name}' already exists"}
        return {"error": str(e)}


def list_orgs() -> list[dict]:
    """List all active organizations with server counts."""
    orgs = _db.list_organizations()
    for org in orgs:
        servers = _db.get_org_servers(org["id"])
        org["servers_count"] = len(servers)
        org["servers"] = servers
    return orgs


def get_org_detail(name: str) -> dict | None:
    """Get full organization details including servers, users, and recent billing."""
    org = _db.get_organization(name)
    if not org:
        return None

    org["servers"] = _db.get_org_servers(org["id"])
    org["users"] = _db.get_org_users(org["id"])
    org["billing"] = _db.get_org_billing(org["id"], months=6)
    org["active_alerts"] = len(_db.get_org_alerts(org["id"]))
    return org


def update_org(name: str, **kwargs) -> dict:
    """Update organization settings."""
    if _db.update_organization(name, **kwargs):
        return {"name": name, "updated": True, "fields": list(kwargs.keys())}
    return {"error": f"Organization '{name}' not found"}


def delete_org(name: str) -> dict:
    """Deactivate an organization."""
    if _db.delete_organization(name):
        return {"name": name, "deleted": True}
    return {"error": f"Organization '{name}' not found"}


def assign_server(org_name: str, server_name: str) -> dict:
    """Assign a server to an organization."""
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    current_servers = _db.get_org_servers(org["id"])
    if len(current_servers) >= org["max_servers"]:
        return {"error": f"Organization '{org_name}' has reached its server limit ({org['max_servers']}). Upgrade plan to add more."}

    _db.assign_server_to_org(org["id"], server_name.upper())
    return {"org": org_name, "server": server_name.upper(), "assigned": True}


def remove_server(org_name: str, server_name: str) -> dict:
    """Remove a server from an organization."""
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    if _db.remove_server_from_org(org["id"], server_name.upper()):
        return {"org": org_name, "server": server_name.upper(), "removed": True}
    return {"error": f"Server '{server_name}' not found in org '{org_name}'"}


def get_org_dashboard(org_name: str) -> dict:
    """Get a per-org dashboard view — health, alerts, events for their servers only."""
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    org_id = org["id"]
    servers = _db.get_org_servers(org_id)
    health = _db.get_org_health(org_id)
    alerts = _db.get_org_alerts(org_id)
    events = _db.get_org_service_events(org_id, hours=24)

    # Server status summary
    healthy = 0
    warning = 0
    critical = 0
    for h in health:
        disk = h.get("disk_used_pct", 0)
        cpu = h.get("cpu_load", 0)
        cores = h.get("cpu_cores", 1) or 1
        if disk and disk > 90 or (cpu and cpu > cores * 2):
            critical += 1
        elif disk and disk > 80:
            warning += 1
        else:
            healthy += 1

    return {
        "organization": org["display_name"],
        "plan": org["plan"],
        "servers": {
            "total": len(servers),
            "max": org["max_servers"],
            "healthy": healthy,
            "warning": warning,
            "critical": critical,
            "names": servers,
        },
        "health": health,
        "alerts": {
            "active": len(alerts),
            "items": alerts[:10],
        },
        "recent_events": events[:20],
    }


def generate_org_report(org_name: str, audit_results: list[dict],
                        output_path: str = "") -> dict:
    """Generate a white-label compliance report for an organization.

    Uses the org's branding (display name, logo, colors).
    """
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    if not output_path:
        output_path = str(
            Path.home() / ".server-guardian-mcp" / f"report-{org['name']}.html"
        )

    result = generate_compliance_report(
        audit_results=audit_results,
        server_name=", ".join(_db.get_org_servers(org["id"])),
        company_name=org["display_name"],
        output_path=output_path,
    )

    return result


def generate_org_status_page(org_name: str, output_path: str = "") -> dict:
    """Generate a white-label status page for an organization's servers."""
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    if not output_path:
        output_path = str(
            Path.home() / ".server-guardian-mcp" / f"status-{org['name']}.html"
        )

    org_id = org["id"]
    servers = _db.get_org_servers(org_id)
    health = _db.get_org_health(org_id)
    alerts = _db.get_org_alerts(org_id)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    brand = org.get("brand_color", "#3b82f6")
    display = org["display_name"]
    logo = org.get("logo_url", "")

    all_ok = True
    items_html = ""
    for h in health:
        name = h.get("server_name", "")
        disk = h.get("disk_used_pct", 0)
        cpu = h.get("cpu_load", 0)
        cores = h.get("cpu_cores", 1) or 1

        if disk and disk > 90 or (cpu and cpu > cores * 2):
            status_text, status_color = "Degraded", "#ef4444"
            all_ok = False
        elif disk and disk > 80:
            status_text, status_color = "Warning", "#eab308"
            all_ok = False
        else:
            status_text, status_color = "Operational", "#22c55e"

        items_html += f"""
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #e5e7eb;">
          <span style="font-weight:500;">{name}</span>
          <span style="color:{status_color};font-weight:600;font-size:14px;">{status_text}</span>
        </div>"""

    # Servers with no health data
    for s in servers:
        if not any(h.get("server_name") == s for h in health):
            items_html += f"""
            <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #e5e7eb;">
              <span style="font-weight:500;">{s}</span>
              <span style="color:#6b7280;font-weight:600;font-size:14px;">No Data</span>
            </div>"""

    overall = "All Systems Operational" if all_ok else "Some Systems Experiencing Issues"
    overall_color = "#22c55e" if all_ok else "#eab308"

    incidents_html = ""
    if alerts:
        for a in alerts[:5]:
            incidents_html += f"""
            <div style="padding:12px;border-left:3px solid #ef4444;background:#fef2f2;border-radius:4px;margin-bottom:8px;">
              <strong>{a.get('server_name','')}</strong> — {a.get('message','')[:120]}
              <div style="font-size:12px;color:#6b7280;margin-top:4px;">{a.get('timestamp','')[:19]}</div>
            </div>"""
    else:
        incidents_html = '<p style="color:#6b7280;">No incidents reported.</p>'

    logo_html = f'<img src="{logo}" alt="" style="height:32px;margin-right:12px;">' if logo else ""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="refresh" content="60">
  <title>{display} — Status</title>
</head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f9fafb;margin:0;color:#111827;">
  <div style="max-width:700px;margin:0 auto;padding:40px 20px;">
    <div style="display:flex;align-items:center;margin-bottom:24px;">
      {logo_html}
      <h1 style="font-size:22px;margin:0;">{display}</h1>
    </div>
    <div style="background:{overall_color};color:white;padding:16px 24px;border-radius:8px;font-size:16px;font-weight:600;margin-bottom:32px;">
      {overall}
    </div>
    <div style="background:white;border-radius:8px;padding:20px 24px;box-shadow:0 1px 3px rgba(0,0,0,0.1);margin-bottom:32px;">
      {items_html if items_html else '<p style="color:#6b7280;">No servers configured.</p>'}
    </div>
    <h2 style="font-size:18px;margin-bottom:12px;">Recent Incidents</h2>
    <div style="margin-bottom:32px;">{incidents_html}</div>
    <div style="text-align:center;color:#9ca3af;font-size:12px;">
      Updated: {timestamp}
    </div>
  </div>
</body>
</html>"""

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return {
        "path": output_path,
        "organization": display,
        "servers": len(servers),
        "all_operational": all_ok,
        "active_incidents": len(alerts),
    }


def update_billing(org_name: str) -> dict:
    """Calculate and record current month's billing metrics for an org."""
    org = _db.get_organization(org_name)
    if not org:
        return {"error": f"Organization '{org_name}' not found"}

    org_id = org["id"]
    month = datetime.now(timezone.utc).strftime("%Y-%m")
    servers = _db.get_org_servers(org_id)
    alerts = _db.get_org_alerts(org_id)

    # Count health checks this month
    all_health = []
    for s in servers:
        all_health.extend(_db.get_health_history(s, hours=720))

    _db.record_org_billing(org_id, month, len(servers), len(all_health), len(alerts))

    return {
        "organization": org["display_name"],
        "month": month,
        "servers": len(servers),
        "health_checks": len(all_health),
        "active_alerts": len(alerts),
        "plan": org["plan"],
    }


# ---------------------------------------------------------------------------
# Pricing plans
# ---------------------------------------------------------------------------
PLANS = {
    "free": {"max_servers": 5, "price": "$0/mo", "features": ["5 servers", "Basic monitoring", "Email alerts"]},
    "pro": {"max_servers": 25, "price": "$49/mo", "features": ["25 servers", "All monitoring", "All integrations", "Compliance reports", "Priority support"]},
    "business": {"max_servers": 100, "price": "$149/mo", "features": ["100 servers", "Everything in Pro", "White-label reports", "Custom branding", "API access"]},
    "enterprise": {"max_servers": 9999, "price": "Custom", "features": ["Unlimited servers", "Everything in Business", "Dedicated support", "Custom integrations", "SLA guarantee"]},
}
