"""
Server Guardian MCP — Team / Multi-Tenant Authentication

RBAC system with three roles:
- admin: full access to all tools
- operator: can use mutating tools but not manage users/config
- viewer: read-only access

Authentication is via API keys passed in the GUARDIAN_API_KEY env var
or via the X-API-Key header in SSE mode.
"""

import hashlib
import json
import os
import secrets

from . import db as _db

# ---------------------------------------------------------------------------
# Role definitions
# ---------------------------------------------------------------------------
ROLES = {
    "admin": {
        "description": "Full access — all tools, user management, config changes",
        "can_mutate": True,
        "can_manage_users": True,
        "can_manage_playbooks": True,
    },
    "operator": {
        "description": "Operational access — can run commands, restart services, deploy",
        "can_mutate": True,
        "can_manage_users": False,
        "can_manage_playbooks": True,
    },
    "viewer": {
        "description": "Read-only access — can view health, logs, alerts, dashboards",
        "can_mutate": False,
        "can_manage_users": False,
        "can_manage_playbooks": False,
    },
}

# Tools restricted to admin only
ADMIN_ONLY_TOOLS = {
    "team_create_user", "team_delete_user", "team_update_role",
}

# Tools that viewers cannot use (mutating tools)
MUTATING_TOOLS = {
    "manage_systemd_service", "manage_packages", "manage_firewall",
    "run_shell_commands", "run_shell_script", "manage_cron_jobs",
    "manage_users", "manage_nginx", "git_deploy", "upload_file_to_server",
    "query_database", "restart_failed_services", "run_on_all_servers",
    "resolve_alert", "manage_playbooks",
}


def _hash_key(api_key: str) -> str:
    """Hash an API key for storage (we store the hash, not the raw key)."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def generate_api_key() -> str:
    """Generate a secure random API key."""
    return f"sg_{secrets.token_urlsafe(32)}"


def is_team_mode_enabled() -> bool:
    """Check if team mode is active. Disabled by default for solo users."""
    return os.environ.get("GUARDIAN_TEAM_MODE", "").lower() == "true"


def get_current_user() -> dict | None:
    """Get the current authenticated user from GUARDIAN_API_KEY env var.
    Returns None if team mode is disabled (solo mode — full access)."""
    if not is_team_mode_enabled():
        return None  # Solo mode — no restrictions

    api_key = os.environ.get("GUARDIAN_API_KEY", "")
    if not api_key:
        return None

    return _db.get_user_by_api_key(api_key)


def check_permission(tool_name: str, user: dict | None = None) -> str | None:
    """Check if the current user has permission to use a tool.
    Returns an error string if denied, None if allowed."""
    if not is_team_mode_enabled():
        return None  # Solo mode — everything allowed

    if user is None:
        user = get_current_user()

    if user is None:
        api_key = os.environ.get("GUARDIAN_API_KEY", "")
        if api_key:
            return "Invalid API key. Check your GUARDIAN_API_KEY setting."
        return "Team mode is enabled but no API key provided. Set GUARDIAN_API_KEY."

    role = user.get("role", "viewer")
    role_perms = ROLES.get(role, ROLES["viewer"])

    if tool_name in ADMIN_ONLY_TOOLS and role != "admin":
        return f"Permission denied: '{tool_name}' requires admin role (you are {role})."

    if tool_name in MUTATING_TOOLS and not role_perms["can_mutate"]:
        return f"Permission denied: '{tool_name}' requires operator or admin role (you are {role})."

    return None


def create_team_user(username: str, role: str = "viewer") -> dict:
    """Create a new team user with a generated API key.
    Returns {username, role, api_key} — the api_key is shown ONCE."""
    if role not in ROLES:
        return {"error": f"Invalid role '{role}'. Valid: {', '.join(ROLES.keys())}"}

    api_key = generate_api_key()
    try:
        user_id = _db.create_user(username, api_key, role)
        return {
            "user_id": user_id,
            "username": username,
            "role": role,
            "api_key": api_key,
            "note": "Save this API key — it cannot be retrieved later.",
        }
    except Exception as e:
        if "UNIQUE" in str(e):
            return {"error": f"Username '{username}' already exists."}
        return {"error": str(e)}


def list_team_users() -> list[dict]:
    """List all team users (without API keys)."""
    return _db.list_users()


def update_team_user_role(username: str, role: str) -> dict:
    """Update a user's role."""
    if role not in ROLES:
        return {"error": f"Invalid role '{role}'. Valid: {', '.join(ROLES.keys())}"}
    if _db.update_user_role(username, role):
        return {"username": username, "new_role": role, "updated": True}
    return {"error": f"User '{username}' not found."}


def delete_team_user(username: str) -> dict:
    """Deactivate a team user."""
    if _db.delete_user(username):
        return {"username": username, "deleted": True}
    return {"error": f"User '{username}' not found."}


def get_role_info() -> list[dict]:
    """Get info about all available roles."""
    return [
        {"role": name, **info}
        for name, info in ROLES.items()
    ]
