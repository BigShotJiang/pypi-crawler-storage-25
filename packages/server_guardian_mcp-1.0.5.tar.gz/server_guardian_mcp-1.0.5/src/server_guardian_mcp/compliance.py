"""
Server Guardian MCP — Compliance Report Generator

Generates branded HTML security reports from run_security_audit data.
Suitable for SOC2/ISO prep, client deliverables, and internal review.
"""

import json
from datetime import datetime, timezone
from pathlib import Path

from . import db as _db


def _severity_badge(status: str) -> str:
    """Generate an HTML badge for a check status."""
    colors = {
        "PASS": ("#28a745", "#fff"),
        "FAIL": ("#dc3545", "#fff"),
        "WARNING": ("#fd7e14", "#fff"),
        "INFO": ("#17a2b8", "#fff"),
        "CRITICAL": ("#dc3545", "#fff"),
        "N/A": ("#6c757d", "#fff"),
    }
    bg, fg = colors.get(status.upper(), ("#6c757d", "#fff"))
    return f'<span style="background:{bg};color:{fg};padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;">{status.upper()}</span>'


def _score_color(score: int) -> str:
    """Color for security score."""
    if score >= 90:
        return "#28a745"
    elif score >= 70:
        return "#fd7e14"
    else:
        return "#dc3545"


def generate_compliance_report(audit_results: list[dict],
                               server_name: str = "",
                               company_name: str = "",
                               output_path: str = "") -> dict:
    """Generate a comprehensive HTML compliance report.

    Args:
        audit_results: List of audit check results, each with:
            {check, status, details, recommendation}
        server_name: Name of the audited server
        company_name: Company name for branding
        output_path: Where to save the HTML file

    Returns:
        {path, checks_total, checks_passed, score, grade}
    """
    if not company_name:
        company_name = "Server Guardian"
    if not output_path:
        output_path = str(Path.home() / ".server-guardian-mcp" / f"compliance-report-{server_name or 'all'}.html")

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    total = len(audit_results)
    passed = sum(1 for r in audit_results if r.get("status", "").upper() == "PASS")
    warnings = sum(1 for r in audit_results if r.get("status", "").upper() == "WARNING")
    failed = sum(1 for r in audit_results if r.get("status", "").upper() in ("FAIL", "CRITICAL"))
    score = round((passed / total) * 100) if total > 0 else 0

    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"

    # Build check rows
    check_rows = ""
    for i, check in enumerate(audit_results, 1):
        name = check.get("check", f"Check {i}")
        status = check.get("status", "N/A")
        details = check.get("details", "")
        recommendation = check.get("recommendation", "")

        check_rows += f"""
        <tr>
          <td style="padding:12px;border-bottom:1px solid #e9ecef;font-weight:500;">{name}</td>
          <td style="padding:12px;border-bottom:1px solid #e9ecef;text-align:center;">{_severity_badge(status)}</td>
          <td style="padding:12px;border-bottom:1px solid #e9ecef;font-size:13px;">{details}</td>
          <td style="padding:12px;border-bottom:1px solid #e9ecef;font-size:13px;color:#6c757d;">{recommendation}</td>
        </tr>"""

    # Recent alerts from DB
    alerts_html = ""
    try:
        alerts = _db.get_alerts(server_name=server_name, resolved=False) if server_name else _db.get_alerts(resolved=False)
        if alerts:
            alert_rows = ""
            for a in alerts[:10]:
                sev = a.get("severity", "info")
                alert_rows += f"""
                <tr>
                  <td style="padding:8px;border-bottom:1px solid #e9ecef;">{a.get('timestamp', '')[:19]}</td>
                  <td style="padding:8px;border-bottom:1px solid #e9ecef;">{_severity_badge(sev)}</td>
                  <td style="padding:8px;border-bottom:1px solid #e9ecef;">{a.get('category', '')}</td>
                  <td style="padding:8px;border-bottom:1px solid #e9ecef;">{a.get('message', '')[:100]}</td>
                </tr>"""
            alerts_html = f"""
            <div style="margin-top:40px;">
              <h2 style="color:#343a40;border-bottom:2px solid #dc3545;padding-bottom:8px;">Active Alerts</h2>
              <table style="width:100%;border-collapse:collapse;">
                <thead><tr style="background:#f8f9fa;">
                  <th style="padding:8px;text-align:left;border-bottom:2px solid #dee2e6;">Time</th>
                  <th style="padding:8px;text-align:left;border-bottom:2px solid #dee2e6;">Severity</th>
                  <th style="padding:8px;text-align:left;border-bottom:2px solid #dee2e6;">Category</th>
                  <th style="padding:8px;text-align:left;border-bottom:2px solid #dee2e6;">Message</th>
                </tr></thead>
                <tbody>{alert_rows}</tbody>
              </table>
            </div>"""
    except Exception:
        pass

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Security Compliance Report — {server_name or 'All Servers'}</title>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; color: #333; }}
    .container {{ max-width: 900px; margin: 0 auto; padding: 40px 20px; }}
    .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 40px; border-radius: 12px 12px 0 0; }}
    .content {{ background: white; padding: 40px; border-radius: 0 0 12px 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.08); }}
    .score-circle {{ width: 120px; height: 120px; border-radius: 50%; background: {_score_color(score)}; color: white; display: flex; flex-direction: column; align-items: center; justify-content: center; float: right; margin-top: -10px; }}
    .score-number {{ font-size: 36px; font-weight: 700; line-height: 1; }}
    .score-label {{ font-size: 12px; opacity: 0.9; margin-top: 4px; }}
    .summary-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 30px 0; }}
    .summary-card {{ background: #f8f9fa; border-radius: 8px; padding: 16px; text-align: center; }}
    .summary-value {{ font-size: 28px; font-weight: 700; }}
    .summary-label {{ font-size: 12px; color: #6c757d; margin-top: 4px; }}
    table {{ width: 100%; border-collapse: collapse; }}
    th {{ background: #f8f9fa; padding: 12px; text-align: left; border-bottom: 2px solid #dee2e6; font-size: 13px; text-transform: uppercase; color: #6c757d; }}
    .footer {{ text-align: center; padding: 20px; color: #adb5bd; font-size: 12px; margin-top: 20px; }}
    @media print {{
      body {{ background: white; }}
      .container {{ max-width: 100%; padding: 0; }}
      .content {{ box-shadow: none; }}
    }}
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="score-circle">
        <div class="score-number">{score}</div>
        <div class="score-label">Grade {grade}</div>
      </div>
      <h1 style="font-size:24px;margin-bottom:8px;">Security Compliance Report</h1>
      <p style="opacity:0.85;margin-bottom:4px;">{server_name or 'All Servers'} — {company_name}</p>
      <p style="opacity:0.7;font-size:13px;">Generated: {timestamp}</p>
    </div>

    <div class="content">
      <div class="summary-grid">
        <div class="summary-card">
          <div class="summary-value" style="color:#343a40;">{total}</div>
          <div class="summary-label">Total Checks</div>
        </div>
        <div class="summary-card">
          <div class="summary-value" style="color:#28a745;">{passed}</div>
          <div class="summary-label">Passed</div>
        </div>
        <div class="summary-card">
          <div class="summary-value" style="color:#fd7e14;">{warnings}</div>
          <div class="summary-label">Warnings</div>
        </div>
        <div class="summary-card">
          <div class="summary-value" style="color:#dc3545;">{failed}</div>
          <div class="summary-label">Failed</div>
        </div>
      </div>

      <h2 style="color:#343a40;border-bottom:2px solid #007bff;padding-bottom:8px;margin-bottom:16px;">Detailed Results</h2>
      <table>
        <thead>
          <tr>
            <th style="width:22%;">Check</th>
            <th style="width:10%;text-align:center;">Status</th>
            <th style="width:38%;">Details</th>
            <th style="width:30%;">Recommendation</th>
          </tr>
        </thead>
        <tbody>{check_rows}</tbody>
      </table>

      {alerts_html}

      <div style="margin-top:40px;padding:20px;background:#f0f7ff;border-radius:8px;border-left:4px solid #007bff;">
        <h3 style="margin-bottom:8px;color:#343a40;">About This Report</h3>
        <p style="font-size:14px;color:#6c757d;line-height:1.6;">
          This report was generated by Server Guardian MCP's automated security audit.
          It checks SSH configuration, firewall status, authentication logs, system updates,
          and other security-relevant settings. Results should be reviewed by qualified
          security personnel. This report is a point-in-time snapshot and does not replace
          a full penetration test or compliance audit.
        </p>
      </div>
    </div>

    <div class="footer">
      <p>Generated by Server Guardian MCP — {timestamp}</p>
      <p style="margin-top:4px;">Confidential — {company_name}</p>
    </div>
  </div>
</body>
</html>"""

    # Ensure output directory exists
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return {
        "path": output_path,
        "checks_total": total,
        "checks_passed": passed,
        "checks_warnings": warnings,
        "checks_failed": failed,
        "score": score,
        "grade": grade,
        "server": server_name,
        "timestamp": timestamp,
    }
