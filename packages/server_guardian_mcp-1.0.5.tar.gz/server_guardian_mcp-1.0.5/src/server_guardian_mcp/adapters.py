"""
Server Guardian MCP — Connection Adapters

Pluggable execution layer supporting multiple connection types:
- SSH (paramiko) — remote Linux/Mac servers
- Local (subprocess) — the machine running this MCP
- Docker (docker exec) — containers on local or remote Docker host
- WinRM (pywinrm) — Windows servers
- Kubernetes (kubectl exec) — pods in a K8s cluster

All adapters implement the same interface so tools don't need to know
which connection type is being used.
"""

import json
import os
import shutil
import subprocess
from abc import ABC, abstractmethod

import paramiko


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
_MAX_OUTPUT_BYTES = 512 * 1024  # 512KB cap per command output
_DEFAULT_CMD_TIMEOUT = int(os.environ.get("DEFAULT_CMD_TIMEOUT", "30"))
_DEFAULT_SCRIPT_TIMEOUT = int(os.environ.get("DEFAULT_SCRIPT_TIMEOUT", "120"))
_SSH_CONNECT_TIMEOUT = int(os.environ.get("SSH_CONNECT_TIMEOUT", "10"))
_DEFAULT_SSH_PASSWORD = os.environ.get("DEFAULT_SSH_PASSWORD", "")
_DEFAULT_SSH_KEY_PATH = os.environ.get("DEFAULT_SSH_KEY_PATH", "~/.ssh/id_rsa")


# ---------------------------------------------------------------------------
# Base adapter
# ---------------------------------------------------------------------------
class BaseAdapter(ABC):
    """Abstract base class for connection adapters."""

    @abstractmethod
    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        """Execute commands sequentially. Returns list of
        {command, stdout, stderr, exit_code, truncated}."""

    @abstractmethod
    def execute_script(self, script: str, timeout: int = 0) -> dict:
        """Execute a multi-line bash/shell script.
        Returns {stdout, stderr, exit_code}."""

    @abstractmethod
    def push_file(self, local_path: str, remote_path: str) -> dict:
        """Upload a file. Returns {success, ...} or {success, error}."""

    @abstractmethod
    def pull_file(self, remote_path: str, local_path: str) -> dict:
        """Download a file. Returns {success, ...} or {success, error}."""

    def check_reachable(self) -> tuple[bool, float]:
        """Check if the target is reachable. Returns (reachable, latency_ms)."""
        return True, 0.0


# ---------------------------------------------------------------------------
# SSH Adapter (paramiko)
# ---------------------------------------------------------------------------
class SSHAdapter(BaseAdapter):
    """Connect to remote servers via SSH using paramiko."""

    def __init__(self, info: dict):
        self.host = info["host"]
        self.port = info.get("port", 22)
        self.user = info.get("user", "root")
        self.auth = info.get("auth", "password")
        self.credential = info.get("credential", "")

    def _connect(self) -> paramiko.SSHClient:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = {
            "hostname": self.host,
            "port": self.port,
            "username": self.user,
            "timeout": _SSH_CONNECT_TIMEOUT,
            "allow_agent": False,
            "look_for_keys": False,
        }
        if self.auth == "key":
            key_path = os.path.expanduser(
                self.credential if self.credential else _DEFAULT_SSH_KEY_PATH
            )
            kwargs["key_filename"] = key_path
        else:
            kwargs["password"] = self.credential if self.credential else _DEFAULT_SSH_PASSWORD
        client.connect(**kwargs)
        return client

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        try:
            client = self._connect()
        except Exception as e:
            results.append({
                "command": commands[0] if commands else "",
                "stdout": "", "stderr": f"SSH connection failed: {e}",
                "exit_code": -1, "truncated": False,
            })
            return results
        try:
            for cmd in commands:
                try:
                    stdin, stdout, stderr = client.exec_command(cmd, timeout=per_cmd_timeout)
                    exit_code = stdout.channel.recv_exit_status()
                    out = stdout.read()
                    err = stderr.read()
                    results.append({
                        "command": cmd,
                        "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                        "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                        "exit_code": exit_code,
                        "truncated": len(out) > _MAX_OUTPUT_BYTES or len(err) > _MAX_OUTPUT_BYTES,
                    })
                except Exception as e:
                    results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                    "exit_code": -1, "truncated": False})
        finally:
            client.close()
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        try:
            client = self._connect()
        except Exception as e:
            return {"stdout": "", "stderr": f"SSH failed: {e}", "exit_code": -1}
        try:
            stdin, stdout, stderr = client.exec_command("bash -s", timeout=timeout)
            stdin.write(script.encode("utf-8") if isinstance(script, str) else script)
            stdin.channel.shutdown_write()
            exit_code = stdout.channel.recv_exit_status()
            out = stdout.read()
            err = stderr.read()
            return {
                "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "exit_code": exit_code,
            }
        except Exception as e:
            return {"stdout": "", "stderr": f"SSH failed: {e}", "exit_code": -1}
        finally:
            client.close()

    def push_file(self, local_path: str, remote_path: str) -> dict:
        try:
            client = self._connect()
        except Exception as e:
            return {"success": False, "error": str(e)}
        sftp = None
        try:
            sftp = client.open_sftp()
            file_size = os.path.getsize(local_path)
            sftp.put(local_path, remote_path)
            remote_stat = sftp.stat(remote_path)
            return {
                "success": True, "local_path": local_path,
                "remote_path": remote_path, "bytes_transferred": file_size,
                "remote_size": remote_stat.st_size,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            if sftp:
                sftp.close()
            client.close()

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        try:
            client = self._connect()
        except Exception as e:
            return {"success": False, "error": str(e)}
        sftp = None
        try:
            sftp = client.open_sftp()
            sftp.get(remote_path, local_path)
            local_size = os.path.getsize(local_path)
            return {
                "success": True, "remote_path": remote_path,
                "local_path": local_path, "bytes_transferred": local_size,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            if sftp:
                sftp.close()
            client.close()

    def check_reachable(self) -> tuple[bool, float]:
        import socket
        import time
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(5)
                t0 = time.time()
                sock.connect((self.host, self.port))
                return True, round((time.time() - t0) * 1000, 1)
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# Local Adapter (subprocess)
# ---------------------------------------------------------------------------
class LocalAdapter(BaseAdapter):
    """Execute commands on the local machine via subprocess."""

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                proc = subprocess.run(
                    cmd, shell=True, capture_output=True,
                    timeout=per_cmd_timeout, text=False,
                )
                out = proc.stdout or b""
                err = proc.stderr or b""
                results.append({
                    "command": cmd,
                    "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "exit_code": proc.returncode,
                    "truncated": len(out) > _MAX_OUTPUT_BYTES or len(err) > _MAX_OUTPUT_BYTES,
                })
            except subprocess.TimeoutExpired:
                results.append({"command": cmd, "stdout": "", "stderr": f"Timeout after {per_cmd_timeout}s",
                                "exit_code": -1, "truncated": False})
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        try:
            proc = subprocess.run(
                ["bash", "-s"], input=script.encode("utf-8"),
                capture_output=True, timeout=timeout,
            )
            out = proc.stdout or b""
            err = proc.stderr or b""
            return {
                "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "exit_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        try:
            file_size = os.path.getsize(local_path)
            shutil.copy2(local_path, remote_path)
            return {
                "success": True, "local_path": local_path,
                "remote_path": remote_path, "bytes_transferred": file_size,
                "remote_size": os.path.getsize(remote_path),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        try:
            shutil.copy2(remote_path, local_path)
            return {
                "success": True, "remote_path": remote_path,
                "local_path": local_path, "bytes_transferred": os.path.getsize(local_path),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


# ---------------------------------------------------------------------------
# Docker Adapter (docker exec / docker cp)
# ---------------------------------------------------------------------------
class DockerAdapter(BaseAdapter):
    """Execute commands inside a Docker container via docker exec."""

    def __init__(self, info: dict):
        self.container = info.get("host", "")
        if not self.container:
            raise ValueError("Docker adapter requires container name in 'host' field")

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                proc = subprocess.run(
                    ["docker", "exec", self.container, "bash", "-c", cmd],
                    capture_output=True, timeout=per_cmd_timeout,
                )
                out = proc.stdout or b""
                err = proc.stderr or b""
                results.append({
                    "command": cmd,
                    "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "exit_code": proc.returncode,
                    "truncated": len(out) > _MAX_OUTPUT_BYTES,
                })
            except subprocess.TimeoutExpired:
                results.append({"command": cmd, "stdout": "", "stderr": f"Timeout after {per_cmd_timeout}s",
                                "exit_code": -1, "truncated": False})
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        try:
            proc = subprocess.run(
                ["docker", "exec", "-i", self.container, "bash", "-s"],
                input=script.encode("utf-8"), capture_output=True, timeout=timeout,
            )
            out = proc.stdout or b""
            err = proc.stderr or b""
            return {
                "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "exit_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        try:
            file_size = os.path.getsize(local_path)
            proc = subprocess.run(
                ["docker", "cp", local_path, f"{self.container}:{remote_path}"],
                capture_output=True, timeout=60,
            )
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {
                "success": True, "local_path": local_path,
                "remote_path": remote_path, "bytes_transferred": file_size,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        try:
            proc = subprocess.run(
                ["docker", "cp", f"{self.container}:{remote_path}", local_path],
                capture_output=True, timeout=60,
            )
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {
                "success": True, "remote_path": remote_path,
                "local_path": local_path, "bytes_transferred": os.path.getsize(local_path),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def check_reachable(self) -> tuple[bool, float]:
        import time
        try:
            t0 = time.time()
            proc = subprocess.run(
                ["docker", "inspect", "--format", "{{.State.Running}}", self.container],
                capture_output=True, timeout=5,
            )
            latency = round((time.time() - t0) * 1000, 1)
            running = proc.stdout.decode().strip() == "true"
            return running, latency
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# WinRM Adapter (optional pywinrm)
# ---------------------------------------------------------------------------
class WinRMAdapter(BaseAdapter):
    """Execute commands on Windows servers via WinRM.
    Requires pywinrm: pip install pywinrm"""

    def __init__(self, info: dict):
        self.host = info.get("host", "")
        self.port = info.get("port", 5985)
        self.user = info.get("user", "")
        self.credential = info.get("credential", "")
        self._session = None

    def _get_session(self):
        if self._session:
            return self._session
        try:
            import winrm
        except ImportError:
            raise RuntimeError(
                "WinRM adapter requires pywinrm. Install it: pip install pywinrm"
            )
        url = f"http://{self.host}:{self.port}/wsman"
        self._session = winrm.Session(
            url, auth=(self.user, self.credential),
            transport="ntlm",
        )
        return self._session

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        results = []
        try:
            session = self._get_session()
        except Exception as e:
            results.append({"command": commands[0] if commands else "", "stdout": "",
                            "stderr": str(e), "exit_code": -1, "truncated": False})
            return results
        for cmd in commands:
            try:
                r = session.run_ps(cmd)
                results.append({
                    "command": cmd,
                    "stdout": r.std_out.decode("utf-8", errors="replace").strip()[:_MAX_OUTPUT_BYTES],
                    "stderr": r.std_err.decode("utf-8", errors="replace").strip()[:_MAX_OUTPUT_BYTES],
                    "exit_code": r.status_code,
                    "truncated": False,
                })
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        try:
            session = self._get_session()
            r = session.run_ps(script)
            return {
                "stdout": r.std_out.decode("utf-8", errors="replace").strip()[:_MAX_OUTPUT_BYTES],
                "stderr": r.std_err.decode("utf-8", errors="replace").strip()[:_MAX_OUTPUT_BYTES],
                "exit_code": r.status_code,
            }
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        return {"success": False, "error": "WinRM does not support file transfer. Use SMB share or upload via PowerShell."}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        return {"success": False, "error": "WinRM does not support file transfer. Use SMB share or download via PowerShell."}


# ---------------------------------------------------------------------------
# Kubernetes Adapter (kubectl exec / kubectl cp)
# ---------------------------------------------------------------------------
class KubernetesAdapter(BaseAdapter):
    """Execute commands inside a Kubernetes pod via kubectl.
    Host format: pod-name/namespace (namespace defaults to 'default')."""

    def __init__(self, info: dict):
        raw = info.get("host", "")
        if "/" in raw:
            self.pod, self.namespace = raw.split("/", 1)
        else:
            self.pod = raw
            self.namespace = "default"
        if not self.pod:
            raise ValueError("Kubernetes adapter requires pod name in 'host' field (format: pod-name/namespace)")

    def _kubectl_exec(self, args: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["kubectl", "exec", self.pod, "-n", self.namespace, "--"] + args,
            capture_output=True, timeout=timeout,
        )

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                proc = self._kubectl_exec(["bash", "-c", cmd], timeout=per_cmd_timeout)
                out = proc.stdout or b""
                err = proc.stderr or b""
                results.append({
                    "command": cmd,
                    "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "exit_code": proc.returncode,
                    "truncated": len(out) > _MAX_OUTPUT_BYTES,
                })
            except subprocess.TimeoutExpired:
                results.append({"command": cmd, "stdout": "", "stderr": f"Timeout after {per_cmd_timeout}s",
                                "exit_code": -1, "truncated": False})
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        try:
            proc = subprocess.run(
                ["kubectl", "exec", "-i", self.pod, "-n", self.namespace, "--", "bash", "-s"],
                input=script.encode("utf-8"), capture_output=True, timeout=timeout,
            )
            out = proc.stdout or b""
            err = proc.stderr or b""
            return {
                "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "exit_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        try:
            file_size = os.path.getsize(local_path)
            proc = subprocess.run(
                ["kubectl", "cp", local_path, f"{self.namespace}/{self.pod}:{remote_path}"],
                capture_output=True, timeout=120,
            )
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {"success": True, "local_path": local_path,
                    "remote_path": remote_path, "bytes_transferred": file_size}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        try:
            proc = subprocess.run(
                ["kubectl", "cp", f"{self.namespace}/{self.pod}:{remote_path}", local_path],
                capture_output=True, timeout=120,
            )
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {"success": True, "remote_path": remote_path,
                    "local_path": local_path, "bytes_transferred": os.path.getsize(local_path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def check_reachable(self) -> tuple[bool, float]:
        import time
        try:
            t0 = time.time()
            proc = subprocess.run(
                ["kubectl", "get", "pod", self.pod, "-n", self.namespace,
                 "-o", "jsonpath={.status.phase}"],
                capture_output=True, timeout=10,
            )
            latency = round((time.time() - t0) * 1000, 1)
            phase = proc.stdout.decode().strip()
            return phase == "Running", latency
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# AWS SSM Adapter (aws ssm send-command / start-session)
# ---------------------------------------------------------------------------
class AWSSSMAdapter(BaseAdapter):
    """Execute commands on AWS EC2 instances via SSM (Systems Manager).
    No SSH needed — uses the AWS SSM agent installed on the instance.
    Requires: aws CLI configured with credentials + instance must have SSM agent running.

    Host format: instance-id (e.g. i-0abc123def456)
    Credential field: AWS profile name (optional, uses default if empty)
    User field: used as region (e.g. us-east-1, optional)"""

    def __init__(self, info: dict):
        self.instance_id = info.get("host", "")
        if not self.instance_id:
            raise ValueError("AWS SSM adapter requires EC2 instance ID in 'host' field (e.g. i-0abc123def)")
        self.region = info.get("user", "") or None
        self.profile = info.get("credential", "") or None

    def _aws_base(self) -> list[str]:
        cmd = ["aws"]
        if self.profile:
            cmd += ["--profile", self.profile]
        if self.region:
            cmd += ["--region", self.region]
        return cmd

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                # Use aws ssm send-command for non-interactive execution
                aws_cmd = self._aws_base() + [
                    "ssm", "send-command",
                    "--instance-ids", self.instance_id,
                    "--document-name", "AWS-RunShellScript",
                    "--parameters", f"commands=[{json.dumps(cmd)}]",
                    "--output", "json",
                ]
                proc = subprocess.run(aws_cmd, capture_output=True, timeout=15)
                if proc.returncode != 0:
                    results.append({"command": cmd, "stdout": "",
                                    "stderr": proc.stderr.decode("utf-8", errors="replace").strip(),
                                    "exit_code": -1, "truncated": False})
                    continue

                # Get command ID from response
                response = json.loads(proc.stdout)
                command_id = response["Command"]["CommandId"]

                # Wait for command to complete
                import time as _time
                deadline = _time.time() + per_cmd_timeout
                while _time.time() < deadline:
                    _time.sleep(2)
                    get_cmd = self._aws_base() + [
                        "ssm", "get-command-invocation",
                        "--command-id", command_id,
                        "--instance-id", self.instance_id,
                        "--output", "json",
                    ]
                    get_proc = subprocess.run(get_cmd, capture_output=True, timeout=10)
                    if get_proc.returncode != 0:
                        continue
                    inv = json.loads(get_proc.stdout)
                    status = inv.get("Status", "")
                    if status in ("Success", "Failed", "TimedOut", "Cancelled"):
                        out = inv.get("StandardOutputContent", "")
                        err = inv.get("StandardErrorContent", "")
                        exit_code = 0 if status == "Success" else inv.get("ResponseCode", -1)
                        results.append({
                            "command": cmd,
                            "stdout": out[:_MAX_OUTPUT_BYTES].strip(),
                            "stderr": err[:_MAX_OUTPUT_BYTES].strip(),
                            "exit_code": exit_code,
                            "truncated": len(out) > _MAX_OUTPUT_BYTES,
                        })
                        break
                else:
                    results.append({"command": cmd, "stdout": "",
                                    "stderr": f"SSM command timed out after {per_cmd_timeout}s",
                                    "exit_code": -1, "truncated": False})

            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        # Send entire script as a single command
        results = self.execute_commands([script], per_cmd_timeout=timeout)
        if results:
            r = results[0]
            return {"stdout": r["stdout"], "stderr": r["stderr"], "exit_code": r["exit_code"]}
        return {"stdout": "", "stderr": "No result from SSM", "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        return {"success": False, "error": (
            "SSM does not support direct file transfer. "
            "Use S3 as intermediary: upload to S3, then use SSM to download from S3 on the instance."
        )}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        return {"success": False, "error": (
            "SSM does not support direct file transfer. "
            "Use SSM to upload file to S3 on the instance, then download from S3 locally."
        )}

    def check_reachable(self) -> tuple[bool, float]:
        import time
        try:
            t0 = time.time()
            cmd = self._aws_base() + [
                "ssm", "describe-instance-information",
                "--filters", f"Key=InstanceIds,Values={self.instance_id}",
                "--output", "json",
            ]
            proc = subprocess.run(cmd, capture_output=True, timeout=10)
            latency = round((time.time() - t0) * 1000, 1)
            if proc.returncode == 0:
                data = json.loads(proc.stdout)
                instances = data.get("InstanceInformationList", [])
                if instances and instances[0].get("PingStatus") == "Online":
                    return True, latency
            return False, latency
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# GCP Adapter (gcloud compute ssh)
# ---------------------------------------------------------------------------
class GCloudAdapter(BaseAdapter):
    """Execute commands on GCP Compute Engine VMs via gcloud CLI.
    Uses gcloud compute ssh which handles IAP tunneling, OS Login, etc.
    Requires: gcloud CLI installed and authenticated.

    Host format: instance-name
    User field: zone (e.g. us-central1-a)
    Credential field: GCP project ID (optional, uses default if empty)"""

    def __init__(self, info: dict):
        self.instance = info.get("host", "")
        if not self.instance:
            raise ValueError("GCloud adapter requires instance name in 'host' field")
        self.zone = info.get("user", "") or None
        self.project = info.get("credential", "") or None

    def _gcloud_ssh_base(self) -> list[str]:
        cmd = ["gcloud", "compute", "ssh", self.instance, "--command"]
        if self.zone:
            cmd += ["--zone", self.zone]
        if self.project:
            cmd += ["--project", self.project]
        cmd += ["--quiet"]  # suppress prompts
        return cmd

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                gcloud_cmd = self._gcloud_ssh_base()
                # Insert the command right after --command
                idx = gcloud_cmd.index("--command") + 1
                gcloud_cmd.insert(idx, cmd)
                proc = subprocess.run(gcloud_cmd, capture_output=True, timeout=per_cmd_timeout)
                out = proc.stdout or b""
                err = proc.stderr or b""
                results.append({
                    "command": cmd,
                    "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                    "exit_code": proc.returncode,
                    "truncated": len(out) > _MAX_OUTPUT_BYTES,
                })
            except subprocess.TimeoutExpired:
                results.append({"command": cmd, "stdout": "",
                                "stderr": f"Timeout after {per_cmd_timeout}s",
                                "exit_code": -1, "truncated": False})
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        # Use -- bash -s and pipe script via stdin
        try:
            gcloud_cmd = ["gcloud", "compute", "ssh", self.instance]
            if self.zone:
                gcloud_cmd += ["--zone", self.zone]
            if self.project:
                gcloud_cmd += ["--project", self.project]
            gcloud_cmd += ["--quiet", "--command", "bash -s"]
            proc = subprocess.run(gcloud_cmd, input=script.encode("utf-8"),
                                  capture_output=True, timeout=timeout)
            out = proc.stdout or b""
            err = proc.stderr or b""
            return {
                "stdout": out[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "stderr": err[:_MAX_OUTPUT_BYTES].decode("utf-8", errors="replace").strip(),
                "exit_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        try:
            file_size = os.path.getsize(local_path)
            cmd = ["gcloud", "compute", "scp", local_path,
                   f"{self.instance}:{remote_path}"]
            if self.zone:
                cmd += ["--zone", self.zone]
            if self.project:
                cmd += ["--project", self.project]
            cmd += ["--quiet"]
            proc = subprocess.run(cmd, capture_output=True, timeout=120)
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {"success": True, "local_path": local_path,
                    "remote_path": remote_path, "bytes_transferred": file_size}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        try:
            cmd = ["gcloud", "compute", "scp",
                   f"{self.instance}:{remote_path}", local_path]
            if self.zone:
                cmd += ["--zone", self.zone]
            if self.project:
                cmd += ["--project", self.project]
            cmd += ["--quiet"]
            proc = subprocess.run(cmd, capture_output=True, timeout=120)
            if proc.returncode != 0:
                return {"success": False, "error": proc.stderr.decode("utf-8", errors="replace").strip()}
            return {"success": True, "remote_path": remote_path,
                    "local_path": local_path, "bytes_transferred": os.path.getsize(local_path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def check_reachable(self) -> tuple[bool, float]:
        import time
        try:
            t0 = time.time()
            cmd = ["gcloud", "compute", "instances", "describe", self.instance,
                   "--format", "value(status)"]
            if self.zone:
                cmd += ["--zone", self.zone]
            if self.project:
                cmd += ["--project", self.project]
            proc = subprocess.run(cmd, capture_output=True, timeout=10)
            latency = round((time.time() - t0) * 1000, 1)
            status = proc.stdout.decode().strip()
            return status == "RUNNING", latency
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# Azure Adapter (az ssh vm / az vm run-command)
# ---------------------------------------------------------------------------
class AzureAdapter(BaseAdapter):
    """Execute commands on Azure VMs via Azure CLI.
    Requires: az CLI installed and logged in.

    Host format: vm-name
    User field: resource-group
    Credential field: subscription ID (optional, uses default if empty)"""

    def __init__(self, info: dict):
        self.vm_name = info.get("host", "")
        if not self.vm_name:
            raise ValueError("Azure adapter requires VM name in 'host' field")
        self.resource_group = info.get("user", "")
        if not self.resource_group:
            raise ValueError("Azure adapter requires resource group in 'user' field")
        self.subscription = info.get("credential", "") or None

    def _az_base(self) -> list[str]:
        cmd = ["az"]
        if self.subscription:
            cmd += ["--subscription", self.subscription]
        return cmd

    def execute_commands(self, commands: list[str],
                         per_cmd_timeout: int = 0) -> list[dict]:
        per_cmd_timeout = per_cmd_timeout or _DEFAULT_CMD_TIMEOUT
        results = []
        for cmd in commands:
            try:
                az_cmd = self._az_base() + [
                    "vm", "run-command", "invoke",
                    "--resource-group", self.resource_group,
                    "--name", self.vm_name,
                    "--command-id", "RunShellScript",
                    "--scripts", cmd,
                    "--output", "json",
                ]
                proc = subprocess.run(az_cmd, capture_output=True, timeout=per_cmd_timeout + 30)
                if proc.returncode != 0:
                    results.append({"command": cmd, "stdout": "",
                                    "stderr": proc.stderr.decode("utf-8", errors="replace").strip(),
                                    "exit_code": -1, "truncated": False})
                    continue
                response = json.loads(proc.stdout)
                # az vm run-command returns {value: [{code, displayStatus, message}]}
                values = response.get("value", [])
                stdout_msg = ""
                stderr_msg = ""
                for v in values:
                    code = v.get("code", "")
                    msg = v.get("message", "")
                    if "StdOut" in code:
                        stdout_msg = msg
                    elif "StdErr" in code:
                        stderr_msg = msg
                exit_code = 0 if not stderr_msg else 1
                results.append({
                    "command": cmd,
                    "stdout": stdout_msg[:_MAX_OUTPUT_BYTES].strip(),
                    "stderr": stderr_msg[:_MAX_OUTPUT_BYTES].strip(),
                    "exit_code": exit_code,
                    "truncated": len(stdout_msg) > _MAX_OUTPUT_BYTES,
                })
            except subprocess.TimeoutExpired:
                results.append({"command": cmd, "stdout": "",
                                "stderr": f"Timeout after {per_cmd_timeout}s",
                                "exit_code": -1, "truncated": False})
            except Exception as e:
                results.append({"command": cmd, "stdout": "", "stderr": str(e),
                                "exit_code": -1, "truncated": False})
        return results

    def execute_script(self, script: str, timeout: int = 0) -> dict:
        timeout = timeout or _DEFAULT_SCRIPT_TIMEOUT
        results = self.execute_commands([script], per_cmd_timeout=timeout)
        if results:
            r = results[0]
            return {"stdout": r["stdout"], "stderr": r["stderr"], "exit_code": r["exit_code"]}
        return {"stdout": "", "stderr": "No result from Azure", "exit_code": -1}

    def push_file(self, local_path: str, remote_path: str) -> dict:
        return {"success": False, "error": (
            "Azure run-command does not support direct file transfer. "
            "Use Azure Blob Storage as intermediary, or use SSH adapter with the VM's public IP."
        )}

    def pull_file(self, remote_path: str, local_path: str) -> dict:
        return {"success": False, "error": (
            "Azure run-command does not support direct file transfer. "
            "Use Azure Blob Storage as intermediary, or use SSH adapter with the VM's public IP."
        )}

    def check_reachable(self) -> tuple[bool, float]:
        import time
        try:
            t0 = time.time()
            cmd = self._az_base() + [
                "vm", "get-instance-view",
                "--resource-group", self.resource_group,
                "--name", self.vm_name,
                "--query", "instanceView.statuses[1].displayStatus",
                "--output", "tsv",
            ]
            proc = subprocess.run(cmd, capture_output=True, timeout=15)
            latency = round((time.time() - t0) * 1000, 1)
            status = proc.stdout.decode().strip()
            return status == "VM running", latency
        except Exception:
            return False, 0.0


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------
_ADAPTER_TYPES = {"ssh", "local", "docker", "winrm", "k8s", "aws-ssm", "gcloud", "azure"}


def get_adapter(info: dict) -> BaseAdapter:
    """Create the appropriate adapter based on server info 'type' field.
    Defaults to SSH if type is not specified."""
    server_type = info.get("type", "ssh").lower()

    if server_type == "ssh":
        return SSHAdapter(info)
    elif server_type == "local":
        return LocalAdapter()
    elif server_type == "docker":
        return DockerAdapter(info)
    elif server_type == "winrm":
        return WinRMAdapter(info)
    elif server_type == "k8s":
        return KubernetesAdapter(info)
    elif server_type == "aws-ssm":
        return AWSSSMAdapter(info)
    elif server_type == "gcloud":
        return GCloudAdapter(info)
    elif server_type == "azure":
        return AzureAdapter(info)
    else:
        raise ValueError(
            f"Unknown server type: '{server_type}'. "
            f"Supported: {', '.join(sorted(_ADAPTER_TYPES))}"
        )
