"""
Server Guardian MCP — Network Monitoring

Track bandwidth per interface, connection states, TCP retransmissions,
and latency to key endpoints — all via SSH.
"""

import re
from . import db as _db


def parse_interface_stats(raw: str) -> list[dict]:
    """Parse output of `ip -s link` or `/proc/net/dev`."""
    interfaces = []

    # Try /proc/net/dev format first
    for line in raw.splitlines():
        line = line.strip()
        if ":" in line and not line.startswith("Inter") and not line.startswith("face"):
            parts = line.split(":")
            if len(parts) == 2:
                iface = parts[0].strip()
                nums = parts[1].split()
                if len(nums) >= 10:
                    try:
                        interfaces.append({
                            "interface": iface,
                            "rx_bytes": int(nums[0]),
                            "rx_packets": int(nums[1]),
                            "rx_errors": int(nums[2]),
                            "tx_bytes": int(nums[8]),
                            "tx_packets": int(nums[9]),
                            "tx_errors": int(nums[10]),
                        })
                    except (ValueError, IndexError):
                        continue

    return interfaces


def parse_connection_states(raw: str) -> dict:
    """Parse `ss -s` or `netstat -s` output for connection state counts."""
    states = {}
    for line in raw.splitlines():
        line = line.strip()
        # ss -tan state output
        for state in ("ESTAB", "TIME-WAIT", "CLOSE-WAIT", "FIN-WAIT", "SYN-SENT",
                       "SYN-RECV", "LISTEN", "CLOSING", "LAST-ACK"):
            if state in line.upper():
                m = re.search(r"(\d+)", line)
                if m:
                    states[state] = int(m.group(1))

    # Also try parsing ss -s summary
    for line in raw.splitlines():
        m = re.match(r"TCP:\s+(\d+)\s+\(estab\s+(\d+),\s+closed\s+(\d+),\s+orphaned\s+(\d+),\s+timewait\s+(\d+)\)", line.strip())
        if m:
            states["total"] = int(m.group(1))
            states["ESTAB"] = int(m.group(2))
            states["closed"] = int(m.group(3))
            states["orphaned"] = int(m.group(4))
            states["TIME-WAIT"] = int(m.group(5))

    return states


def parse_tcp_retransmissions(raw: str) -> dict:
    """Parse TCP retransmission stats from `netstat -s` or `/proc/net/snmp`."""
    result = {"segments_sent": 0, "segments_retransmitted": 0, "retransmit_pct": 0}
    for line in raw.splitlines():
        line = line.strip().lower()
        if "segments sent" in line:
            m = re.search(r"(\d+)", line)
            if m:
                result["segments_sent"] = int(m.group(1))
        if "retransmitted" in line or "retransmits" in line:
            m = re.search(r"(\d+)", line)
            if m:
                result["segments_retransmitted"] = int(m.group(1))

    if result["segments_sent"] > 0:
        result["retransmit_pct"] = round(
            (result["segments_retransmitted"] / result["segments_sent"]) * 100, 4
        )

    return result


def record_stats(server_name: str, interfaces: list[dict], conn_states: dict) -> int:
    """Store network metrics in DB. Returns count stored."""
    stored = 0
    established = conn_states.get("ESTAB", 0)
    time_wait = conn_states.get("TIME-WAIT", 0)

    for iface in interfaces:
        if iface["interface"] == "lo":
            continue
        _db.record_network_metrics(
            server_name=server_name,
            interface=iface["interface"],
            rx_bytes=iface["rx_bytes"],
            tx_bytes=iface["tx_bytes"],
            rx_packets=iface["rx_packets"],
            tx_packets=iface["tx_packets"],
            rx_errors=iface["rx_errors"],
            tx_errors=iface["tx_errors"],
            conns_established=established,
            conns_time_wait=time_wait,
        )
        stored += 1
    return stored


def calculate_bandwidth(server_name: str, hours: int = 1) -> list[dict]:
    """Calculate bandwidth rates from stored network metrics."""
    history = _db.get_network_history(server_name, hours=hours)
    if len(history) < 2:
        return []

    # Group by interface
    by_iface: dict[str, list[dict]] = {}
    for h in history:
        by_iface.setdefault(h["interface"], []).append(h)

    results = []
    for iface, points in by_iface.items():
        points.sort(key=lambda x: x["timestamp"])
        if len(points) < 2:
            continue
        first = points[0]
        last = points[-1]
        try:
            from datetime import datetime
            t1 = datetime.fromisoformat(first["timestamp"])
            t2 = datetime.fromisoformat(last["timestamp"])
            secs = (t2 - t1).total_seconds()
        except (ValueError, TypeError):
            continue
        if secs < 1:
            continue

        rx_diff = last["rx_bytes"] - first["rx_bytes"]
        tx_diff = last["tx_bytes"] - first["tx_bytes"]
        # Handle counter wraps
        if rx_diff < 0:
            rx_diff = last["rx_bytes"]
        if tx_diff < 0:
            tx_diff = last["tx_bytes"]

        results.append({
            "interface": iface,
            "period_seconds": round(secs),
            "rx_bytes_per_sec": round(rx_diff / secs),
            "tx_bytes_per_sec": round(tx_diff / secs),
            "rx_mbps": round((rx_diff / secs) * 8 / 1_000_000, 2),
            "tx_mbps": round((tx_diff / secs) * 8 / 1_000_000, 2),
            "total_rx_mb": round(rx_diff / 1_000_000, 2),
            "total_tx_mb": round(tx_diff / 1_000_000, 2),
        })

    return results


# SSH commands for network monitoring
NETWORK_COMMANDS = {
    "interfaces": "cat /proc/net/dev",
    "connections": "ss -s 2>/dev/null || netstat -s 2>/dev/null | head -20",
    "retransmissions": "netstat -s 2>/dev/null | grep -i retransmit || cat /proc/net/snmp | grep Tcp",
    "top_connections": "ss -tnap 2>/dev/null | head -30",
}
