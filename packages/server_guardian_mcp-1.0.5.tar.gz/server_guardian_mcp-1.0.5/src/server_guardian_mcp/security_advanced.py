"""
Server Guardian MCP — Advanced Security

File Integrity Monitoring (FIM), CIS Benchmark expansion (50+ checks),
CVE scanning, rootkit detection, suspicious process detection.
"""

import re
from . import db as _db


# ---------------------------------------------------------------------------
# File Integrity Monitoring
# ---------------------------------------------------------------------------
CRITICAL_FILES = [
    "/etc/passwd", "/etc/shadow", "/etc/group", "/etc/sudoers",
    "/etc/ssh/sshd_config", "/etc/crontab", "/etc/hosts",
    "/etc/resolv.conf", "/etc/fstab", "/etc/hostname",
    "/root/.bashrc", "/root/.ssh/authorized_keys",
]


def get_fim_script(files: list[str] | None = None) -> str:
    """Generate a shell script to hash critical files."""
    targets = files or CRITICAL_FILES
    lines = ['echo "===FIM_START==="']
    for f in targets:
        lines.append(
            f'if [ -f "{f}" ]; then '
            f'echo "{f}|$(sha256sum "{f}" 2>/dev/null | cut -d" " -f1)|$(stat -c "%a|%U|%s" "{f}" 2>/dev/null)"; '
            f'fi'
        )
    lines.append('echo "===FIM_END==="')
    return "\n".join(lines)


def parse_fim_output(raw: str) -> list[dict]:
    """Parse FIM script output into structured results."""
    results = []
    in_fim = False
    for line in raw.splitlines():
        if "===FIM_START===" in line:
            in_fim = True
            continue
        if "===FIM_END===" in line:
            break
        if in_fim and "|" in line:
            parts = line.strip().split("|")
            if len(parts) >= 2:
                entry = {"file": parts[0], "hash": parts[1]}
                if len(parts) >= 3:
                    entry["permissions"] = parts[2]
                if len(parts) >= 4:
                    entry["owner"] = parts[3]
                if len(parts) >= 5:
                    try:
                        entry["size"] = int(parts[4])
                    except ValueError:
                        entry["size"] = 0
                results.append(entry)
    return results


def check_integrity(server_name: str, fim_results: list[dict]) -> dict:
    """Compare current hashes against stored baselines. Returns changes."""
    changes = []
    new_files = []

    for entry in fim_results:
        changed = _db.upsert_file_hash(
            server_name=server_name,
            file_path=entry["file"],
            hash_sha256=entry["hash"],
            permissions=entry.get("permissions", ""),
            owner=entry.get("owner", ""),
            size_bytes=entry.get("size", 0),
        )
        if changed:
            changes.append(entry["file"])
        # Check if this is a first-time scan
        stored = _db.get_file_hashes(server_name)
        if len(stored) <= len(fim_results):
            new_files.append(entry["file"])

    return {
        "server": server_name,
        "files_checked": len(fim_results),
        "changes_detected": len(changes),
        "changed_files": changes,
        "alert": len(changes) > 0,
    }


# ---------------------------------------------------------------------------
# CIS Benchmark Checks (expanded to 50+)
# ---------------------------------------------------------------------------
CIS_SCRIPT = r"""
echo "===CIS_START==="

# 1. Filesystem Configuration
echo "CHECK|1.1|Ensure /tmp is separate partition|$(mount | grep -c ' /tmp ' 2>/dev/null || echo 0)"
echo "CHECK|1.2|Ensure /var is separate partition|$(mount | grep -c ' /var ' 2>/dev/null || echo 0)"
echo "CHECK|1.3|Ensure /home is separate partition|$(mount | grep -c ' /home ' 2>/dev/null || echo 0)"
echo "CHECK|1.4|Ensure noexec on /tmp|$(mount | grep '/tmp' | grep -c 'noexec' 2>/dev/null || echo 0)"
echo "CHECK|1.5|Ensure sticky bit on world-writable dirs|$(find / -xdev -type d -perm -0002 ! -perm -1000 2>/dev/null | wc -l)"

# 2. Software Updates
echo "CHECK|2.1|Ensure package manager configured|$(which apt-get yum dnf 2>/dev/null | head -1 || echo none)"
echo "CHECK|2.2|Ensure GPG keys configured|$(apt-key list 2>/dev/null | grep -c 'pub' || rpm -qa gpg-pubkey 2>/dev/null | wc -l || echo 0)"
echo "CHECK|2.3|Pending security updates|$(apt list --upgradable 2>/dev/null | grep -ci security || yum check-update --security 2>/dev/null | tail -1 || echo 0)"

# 3. Filesystem Integrity
echo "CHECK|3.1|AIDE installed|$(which aide 2>/dev/null && echo 1 || echo 0)"
echo "CHECK|3.2|Filesystem integrity tool|$(which tripwire aide 2>/dev/null | head -1 || echo none)"

# 4. Secure Boot
echo "CHECK|4.1|Bootloader permissions|$(stat -c '%a' /boot/grub/grub.cfg 2>/dev/null || stat -c '%a' /boot/grub2/grub.cfg 2>/dev/null || echo unknown)"
echo "CHECK|4.2|Authentication for single-user mode|$(grep -c 'sulogin' /usr/lib/systemd/system/rescue.service 2>/dev/null || echo 0)"

# 5. Process Hardening
echo "CHECK|5.1|Core dumps restricted|$(sysctl fs.suid_dumpable 2>/dev/null | awk '{print $3}')"
echo "CHECK|5.2|ASLR enabled|$(sysctl kernel.randomize_va_space 2>/dev/null | awk '{print $3}')"
echo "CHECK|5.3|Prelink disabled|$(dpkg -s prelink 2>/dev/null | grep -c 'Status: install' || rpm -q prelink 2>/dev/null | grep -c 'not installed' || echo 1)"

# 6. Network Configuration
echo "CHECK|6.1|IP forwarding disabled|$(sysctl net.ipv4.ip_forward 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.2|Send redirects disabled|$(sysctl net.ipv4.conf.all.send_redirects 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.3|Source routed packets disabled|$(sysctl net.ipv4.conf.all.accept_source_route 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.4|ICMP redirects disabled|$(sysctl net.ipv4.conf.all.accept_redirects 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.5|Secure ICMP redirects|$(sysctl net.ipv4.conf.all.secure_redirects 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.6|Log suspicious packets|$(sysctl net.ipv4.conf.all.log_martians 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.7|Ignore ICMP broadcasts|$(sysctl net.ipv4.icmp_echo_ignore_broadcasts 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.8|Ignore bogus ICMP responses|$(sysctl net.ipv4.icmp_ignore_bogus_error_responses 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.9|TCP SYN Cookies|$(sysctl net.ipv4.tcp_syncookies 2>/dev/null | awk '{print $3}')"
echo "CHECK|6.10|IPv6 router advertisements|$(sysctl net.ipv6.conf.all.accept_ra 2>/dev/null | awk '{print $3}')"

# 7. Network Services
echo "CHECK|7.1|Ensure X Window not installed|$(dpkg -l xserver-xorg 2>/dev/null | grep -c '^ii' || echo 0)"
echo "CHECK|7.2|Avahi server disabled|$(systemctl is-active avahi-daemon 2>/dev/null || echo inactive)"
echo "CHECK|7.3|CUPS disabled|$(systemctl is-active cups 2>/dev/null || echo inactive)"
echo "CHECK|7.4|DHCP server disabled|$(systemctl is-active isc-dhcp-server 2>/dev/null || echo inactive)"
echo "CHECK|7.5|NFS disabled|$(systemctl is-active nfs-server 2>/dev/null || echo inactive)"
echo "CHECK|7.6|rpcbind disabled|$(systemctl is-active rpcbind 2>/dev/null || echo inactive)"

# 8. SSH Configuration
echo "CHECK|8.1|SSH Protocol 2|$(grep -c '^Protocol 2' /etc/ssh/sshd_config 2>/dev/null || echo 0)"
echo "CHECK|8.2|SSH LogLevel|$(grep '^LogLevel' /etc/ssh/sshd_config 2>/dev/null || echo 'not set')"
echo "CHECK|8.3|SSH MaxAuthTries|$(grep '^MaxAuthTries' /etc/ssh/sshd_config 2>/dev/null || echo 'not set')"
echo "CHECK|8.4|SSH IgnoreRhosts|$(grep -c 'IgnoreRhosts yes' /etc/ssh/sshd_config 2>/dev/null || echo 0)"
echo "CHECK|8.5|SSH HostbasedAuth disabled|$(grep -c 'HostbasedAuthentication no' /etc/ssh/sshd_config 2>/dev/null || echo 0)"
echo "CHECK|8.6|SSH PermitRootLogin|$(grep '^PermitRootLogin' /etc/ssh/sshd_config 2>/dev/null || echo 'not set')"
echo "CHECK|8.7|SSH PermitEmptyPasswords|$(grep -c 'PermitEmptyPasswords no' /etc/ssh/sshd_config 2>/dev/null || echo 0)"
echo "CHECK|8.8|SSH Idle Timeout|$(grep '^ClientAliveInterval' /etc/ssh/sshd_config 2>/dev/null || echo 'not set')"
echo "CHECK|8.9|SSH LoginGraceTime|$(grep '^LoginGraceTime' /etc/ssh/sshd_config 2>/dev/null || echo 'not set')"
echo "CHECK|8.10|SSH Banner configured|$(grep -c '^Banner' /etc/ssh/sshd_config 2>/dev/null || echo 0)"

# 9. PAM & Auth
echo "CHECK|9.1|Password quality (pam_pwquality)|$(dpkg -l libpam-pwquality 2>/dev/null | grep -c '^ii' || rpm -q pam_pwquality 2>/dev/null | grep -vc 'not installed' || echo 0)"
echo "CHECK|9.2|Password lockout (pam_tally/faillock)|$(grep -c 'pam_tally\|pam_faillock' /etc/pam.d/common-auth 2>/dev/null || echo 0)"
echo "CHECK|9.3|Password max days|$(grep '^PASS_MAX_DAYS' /etc/login.defs 2>/dev/null | awk '{print $2}' || echo unknown)"
echo "CHECK|9.4|Password min days|$(grep '^PASS_MIN_DAYS' /etc/login.defs 2>/dev/null | awk '{print $2}' || echo unknown)"
echo "CHECK|9.5|Password min length|$(grep '^PASS_MIN_LEN' /etc/login.defs 2>/dev/null | awk '{print $2}' || echo unknown)"
echo "CHECK|9.6|Inactive password lock|$(useradd -D | grep INACTIVE 2>/dev/null || echo unknown)"

# 10. User & Group
echo "CHECK|10.1|Root is only UID 0|$(awk -F: '($3 == 0) { print $1 }' /etc/passwd | wc -l)"
echo "CHECK|10.2|No empty password fields|$(awk -F: '($2 == \"\") { print $1 }' /etc/shadow 2>/dev/null | wc -l)"
echo "CHECK|10.3|No legacy + entries in passwd|$(grep -c '^\+:' /etc/passwd || echo 0)"
echo "CHECK|10.4|Root PATH integrity|$(echo $PATH | grep -c '::' || echo 0)"
echo "CHECK|10.5|Home dir permissions|$(find /home -maxdepth 1 -type d -perm /027 2>/dev/null | wc -l)"

# 11. Warning Banners
echo "CHECK|11.1|/etc/motd permissions|$(stat -c '%a' /etc/motd 2>/dev/null || echo missing)"
echo "CHECK|11.2|/etc/issue permissions|$(stat -c '%a' /etc/issue 2>/dev/null || echo missing)"

# 12. Logging
echo "CHECK|12.1|rsyslog installed|$(dpkg -l rsyslog 2>/dev/null | grep -c '^ii' || rpm -q rsyslog 2>/dev/null | grep -vc 'not installed' || echo 0)"
echo "CHECK|12.2|rsyslog running|$(systemctl is-active rsyslog 2>/dev/null || echo inactive)"
echo "CHECK|12.3|journald configured|$(systemctl is-active systemd-journald 2>/dev/null || echo inactive)"
echo "CHECK|12.4|Log file permissions|$(find /var/log -type f -perm /037 2>/dev/null | wc -l)"

# 13. Cron
echo "CHECK|13.1|Cron daemon running|$(systemctl is-active cron 2>/dev/null || systemctl is-active crond 2>/dev/null || echo inactive)"
echo "CHECK|13.2|Crontab permissions|$(stat -c '%a' /etc/crontab 2>/dev/null || echo missing)"
echo "CHECK|13.3|At/cron restricted|$([ -f /etc/cron.allow ] && echo 'cron.allow exists' || echo 'no cron.allow')"

echo "===CIS_END==="
"""


def parse_cis_results(raw: str) -> list[dict]:
    """Parse CIS benchmark check results."""
    checks = []
    in_cis = False

    for line in raw.splitlines():
        if "===CIS_START===" in line:
            in_cis = True
            continue
        if "===CIS_END===" in line:
            break
        if in_cis and line.startswith("CHECK|"):
            parts = line.split("|", 3)
            if len(parts) >= 4:
                check_id = parts[1]
                description = parts[2]
                value = parts[3].strip()
                status, recommendation = _evaluate_cis_check(check_id, value)
                checks.append({
                    "id": check_id,
                    "check": description,
                    "value": value,
                    "status": status,
                    "recommendation": recommendation,
                })

    return checks


def _evaluate_cis_check(check_id: str, value: str) -> tuple[str, str]:
    """Evaluate a CIS check result. Returns (status, recommendation)."""
    v = value.strip().lower()

    # Filesystem partitions (1.x)
    if check_id in ("1.1", "1.2", "1.3"):
        return ("PASS", "") if v != "0" else ("WARNING", "Consider using separate partition")
    if check_id == "1.4":
        return ("PASS", "") if v != "0" else ("WARNING", "Add noexec to /tmp mount")
    if check_id == "1.5":
        return ("PASS", "") if v == "0" else ("FAIL", f"{value} dirs without sticky bit")

    # Network hardening (6.x)
    if check_id == "6.1":
        return ("PASS", "") if v == "0" else ("WARNING", "Disable IP forwarding unless needed")
    if check_id in ("6.2", "6.3", "6.4"):
        return ("PASS", "") if v == "0" else ("FAIL", "Should be disabled (0)")
    if check_id in ("6.5",):
        return ("PASS", "") if v == "1" else ("WARNING", "Enable secure redirects")
    if check_id in ("6.6", "6.7", "6.8", "6.9"):
        return ("PASS", "") if v == "1" else ("WARNING", "Should be enabled (1)")
    if check_id == "6.10":
        return ("PASS", "") if v == "0" else ("WARNING", "Disable IPv6 RA if not needed")

    # Services (7.x)
    if check_id in ("7.1",):
        return ("PASS", "") if v == "0" else ("WARNING", "Remove X Window on servers")
    if check_id in ("7.2", "7.3", "7.4", "7.5", "7.6"):
        return ("PASS", "") if "inactive" in v or "not" in v else ("WARNING", f"Disable unused service")

    # SSH (8.x)
    if check_id == "8.6":
        return ("PASS", "") if "no" in v else ("FAIL", "Set PermitRootLogin no")
    if check_id in ("8.4", "8.5", "8.7"):
        return ("PASS", "") if v != "0" else ("WARNING", "Enable this SSH hardening option")

    # PAM (9.x)
    if check_id == "9.3":
        try:
            if int(v) <= 365:
                return ("PASS", "")
        except ValueError:
            pass
        return ("WARNING", "Set PASS_MAX_DAYS to 365 or less")

    # Users (10.x)
    if check_id == "10.1":
        return ("PASS", "") if v == "1" else ("FAIL", f"{value} accounts with UID 0")
    if check_id in ("10.2", "10.3"):
        return ("PASS", "") if v == "0" else ("FAIL", "Security issue detected")

    # Logging (12.x)
    if check_id in ("12.1",):
        return ("PASS", "") if v != "0" else ("WARNING", "Install rsyslog")
    if check_id in ("12.2", "12.3", "13.1"):
        return ("PASS", "") if "active" in v else ("WARNING", "Service should be running")

    # Process hardening (5.x)
    if check_id == "5.1":
        return ("PASS", "") if v == "0" else ("WARNING", "Set fs.suid_dumpable = 0")
    if check_id == "5.2":
        return ("PASS", "") if v == "2" else ("WARNING", "Enable full ASLR (set to 2)")

    # Default
    return ("INFO", "")


# ---------------------------------------------------------------------------
# CVE Scanning
# ---------------------------------------------------------------------------
CVE_SCAN_SCRIPT = r"""
echo "===CVE_START==="
# List installed packages with versions
if command -v dpkg-query &>/dev/null; then
    dpkg-query -W -f='${Package}|${Version}\n' 2>/dev/null | head -500
elif command -v rpm &>/dev/null; then
    rpm -qa --qf='%{NAME}|%{VERSION}-%{RELEASE}\n' 2>/dev/null | head -500
elif command -v apk &>/dev/null; then
    apk list -I 2>/dev/null | sed 's/ .*//;s/-\([0-9]\)/|\1/' | head -500
fi
echo "===CVE_END==="
# Check for known vulnerable packages
echo "===VULN_CHECK==="
if command -v apt-get &>/dev/null; then
    apt list --upgradable 2>/dev/null | grep -i secur | head -20
fi
echo "===VULN_END==="
"""


def parse_cve_scan(raw: str) -> dict:
    """Parse CVE scan output."""
    packages = []
    vulns = []

    in_cve = False
    in_vuln = False

    for line in raw.splitlines():
        if "===CVE_START===" in line:
            in_cve = True
            continue
        if "===CVE_END===" in line:
            in_cve = False
            continue
        if "===VULN_CHECK===" in line:
            in_vuln = True
            continue
        if "===VULN_END===" in line:
            break
        if in_cve and "|" in line:
            parts = line.strip().split("|", 1)
            if len(parts) == 2:
                packages.append({"package": parts[0], "version": parts[1]})
        if in_vuln and line.strip():
            vulns.append(line.strip())

    return {
        "total_packages": len(packages),
        "security_updates_available": len(vulns),
        "vulnerable_packages": vulns[:20],
        "packages_sample": packages[:10],
    }


# ---------------------------------------------------------------------------
# Rootkit / Suspicious Process Detection
# ---------------------------------------------------------------------------
ROOTKIT_SCRIPT = r"""
echo "===ROOTKIT_START==="
# Hidden processes (compare ps and /proc)
echo "HIDDEN_PROCS|$(ps aux | wc -l)|$(ls /proc/[0-9]* -d 2>/dev/null | wc -l)"
# Suspicious kernel modules
echo "SUSPECT_MODULES|$(lsmod 2>/dev/null | grep -icE 'hide|hook|stealth|rootkit' || echo 0)"
# World-writable SUID files
echo "SUID_WRITABLE|$(find / -xdev -type f -perm -4002 2>/dev/null | wc -l)"
# Unusual SUID binaries
echo "SUID_COUNT|$(find / -xdev -type f -perm -4000 2>/dev/null | wc -l)"
# Unusual listening ports
echo "UNUSUAL_PORTS|$(ss -tlnp 2>/dev/null | grep -vcE ':22 |:80 |:443 |:3306|:5432|:6379|:8080|:8443|State' || echo 0)"
# Processes running as root with network connections
echo "ROOT_NET|$(ss -tnp 2>/dev/null | grep -c 'pid=[0-9]' || echo 0)"
# Check for common crypto miners
echo "MINERS|$(ps aux 2>/dev/null | grep -icE 'xmrig|minerd|cpuminer|ccminer|ethminer|cgminer|bfgminer|stratum' || echo 0)"
# Suspicious cron jobs
echo "CRON_SUSPECT|$(find /var/spool/cron /etc/cron* -type f 2>/dev/null | xargs grep -lcE 'curl.*\|.*bash|wget.*\|.*sh|/dev/tcp' 2>/dev/null | wc -l)"
echo "===ROOTKIT_END==="
"""


def parse_rootkit_scan(raw: str) -> list[dict]:
    """Parse rootkit/suspicious activity scan results."""
    findings = []
    in_scan = False

    for line in raw.splitlines():
        if "===ROOTKIT_START===" in line:
            in_scan = True
            continue
        if "===ROOTKIT_END===" in line:
            break
        if in_scan and "|" in line:
            parts = line.strip().split("|")
            check = parts[0]

            if check == "HIDDEN_PROCS" and len(parts) >= 3:
                ps_count = int(parts[1]) if parts[1].isdigit() else 0
                proc_count = int(parts[2]) if parts[2].isdigit() else 0
                diff = abs(ps_count - proc_count)
                findings.append({
                    "check": "Hidden processes",
                    "status": "FAIL" if diff > 10 else "PASS",
                    "detail": f"ps reports {ps_count}, /proc has {proc_count} (diff: {diff})",
                })
            elif check == "SUSPECT_MODULES":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                findings.append({
                    "check": "Suspicious kernel modules",
                    "status": "FAIL" if count > 0 else "PASS",
                    "detail": f"{count} suspicious modules found",
                })
            elif check == "SUID_WRITABLE":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                findings.append({
                    "check": "World-writable SUID files",
                    "status": "FAIL" if count > 0 else "PASS",
                    "detail": f"{count} files found",
                })
            elif check == "SUID_COUNT":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                findings.append({
                    "check": "SUID binaries count",
                    "status": "WARNING" if count > 30 else "PASS",
                    "detail": f"{count} SUID binaries",
                })
            elif check == "MINERS":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                findings.append({
                    "check": "Crypto miner processes",
                    "status": "FAIL" if count > 0 else "PASS",
                    "detail": f"{count} potential miners detected",
                })
            elif check == "CRON_SUSPECT":
                count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
                findings.append({
                    "check": "Suspicious cron jobs",
                    "status": "FAIL" if count > 0 else "PASS",
                    "detail": f"{count} suspicious cron entries",
                })

    return findings
