"""
Server Guardian MCP — Live Web Dashboard

Real-time web UI served via Starlette. Shows:
- All servers with health status
- CPU / RAM / Disk charts over time (Chart.js)
- Active alerts feed
- Incident timeline
- Auto-refreshes every 30 seconds

Usage:
    python -m server_guardian_mcp dashboard              # port 8080
    python -m server_guardian_mcp dashboard --port 9090  # custom port
"""

import json
from datetime import datetime, timezone

from starlette.applications import Starlette
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route

from . import db as _db


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------
async def api_health_latest(request):
    """Get latest health snapshot for all servers."""
    data = _db.get_latest_health_all_servers()
    return JSONResponse(data)


async def api_health_history(request):
    """Get health history for a specific server."""
    server = request.query_params.get("server", "")
    hours = int(request.query_params.get("hours", "24"))
    data = _db.get_health_history(server, hours=hours)
    return JSONResponse(data)


async def api_alerts(request):
    """Get active alerts."""
    server = request.query_params.get("server", "")
    data = _db.get_alerts(server_name=server if server else None, resolved=False)
    return JSONResponse(data)


async def api_alert_counts(request):
    """Get alert counts by severity."""
    data = _db.get_alert_counts()
    return JSONResponse(data)


async def api_events(request):
    """Get recent events (alerts, service events, playbook runs)."""
    hours = int(request.query_params.get("hours", "24"))
    data = _db.get_recent_events(hours=hours)
    return JSONResponse(data)


async def api_endpoints(request):
    """Get recent endpoint checks."""
    hours = int(request.query_params.get("hours", "24"))
    data = _db.get_all_endpoint_history(hours=hours)
    return JSONResponse(data)


async def api_service_events(request):
    """Get recent service events."""
    server = request.query_params.get("server", "")
    hours = int(request.query_params.get("hours", "24"))
    data = _db.get_service_events(server_name=server if server else None, hours=hours)
    return JSONResponse(data)


async def api_playbook_runs(request):
    """Get recent playbook runs."""
    server = request.query_params.get("server", "")
    hours = int(request.query_params.get("hours", "24"))
    data = _db.get_playbook_runs(server_name=server if server else None, hours=hours)
    return JSONResponse(data)


# ---------------------------------------------------------------------------
# Dashboard HTML (self-contained, no external CDN)
# ---------------------------------------------------------------------------
_DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Server Guardian — Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    :root {
      --bg: #0f1117; --card: #1a1d28; --border: #2a2d3a;
      --text: #e4e4e7; --muted: #71717a; --accent: #3b82f6;
      --green: #22c55e; --yellow: #eab308; --red: #ef4444; --orange: #f97316;
    }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif; background:var(--bg); color:var(--text); }
    .top-bar { background:var(--card); border-bottom:1px solid var(--border); padding:12px 24px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:100; }
    .top-bar h1 { font-size:18px; font-weight:600; }
    .top-bar h1 span { color:var(--accent); }
    .status-dot { width:8px; height:8px; border-radius:50%; display:inline-block; margin-right:6px; }
    .status-dot.ok { background:var(--green); box-shadow:0 0 6px var(--green); }
    .status-dot.warn { background:var(--yellow); }
    .status-dot.crit { background:var(--red); box-shadow:0 0 6px var(--red); }
    .container { max-width:1400px; margin:0 auto; padding:20px; }
    .grid-4 { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:20px; }
    .grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:20px; }
    .grid-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:20px; }
    .card { background:var(--card); border:1px solid var(--border); border-radius:10px; padding:20px; }
    .card h3 { font-size:13px; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:12px; }
    .stat-value { font-size:32px; font-weight:700; line-height:1; }
    .stat-label { font-size:12px; color:var(--muted); margin-top:4px; }
    .server-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px; margin-bottom:20px; }
    .server-card { background:var(--card); border:1px solid var(--border); border-radius:10px; padding:16px; transition:border-color 0.2s; }
    .server-card:hover { border-color:var(--accent); }
    .server-name { font-size:15px; font-weight:600; margin-bottom:8px; display:flex; align-items:center; gap:8px; }
    .metric-bar { height:6px; border-radius:3px; background:#2a2d3a; margin:6px 0; overflow:hidden; }
    .metric-bar .fill { height:100%; border-radius:3px; transition:width 0.6s ease; }
    .metric-row { display:flex; justify-content:space-between; font-size:12px; color:var(--muted); margin-bottom:2px; }
    .metric-val { color:var(--text); font-weight:500; }
    .badge { padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; }
    .badge-crit { background:rgba(239,68,68,0.15); color:var(--red); }
    .badge-warn { background:rgba(234,179,8,0.15); color:var(--yellow); }
    .badge-ok { background:rgba(34,197,94,0.15); color:var(--green); }
    .timeline { max-height:400px; overflow-y:auto; }
    .timeline-item { padding:10px 0; border-bottom:1px solid var(--border); font-size:13px; }
    .timeline-time { color:var(--muted); font-size:11px; font-family:monospace; }
    .chart-container { position:relative; height:220px; }
    #refresh-timer { font-size:12px; color:var(--muted); }
    .empty { color:var(--muted); font-style:italic; padding:20px; text-align:center; }
    @media (max-width:768px) {
      .grid-4 { grid-template-columns:repeat(2,1fr); }
      .grid-2, .grid-3 { grid-template-columns:1fr; }
    }
  </style>
</head>
<body>
  <div class="top-bar">
    <h1><span>&#9632;</span> Server Guardian</h1>
    <div><span class="status-dot ok"></span> Live <span id="refresh-timer">30s</span></div>
  </div>
  <div class="container">
    <div class="grid-4" id="stat-cards">
      <div class="card"><h3>Servers</h3><div class="stat-value" id="stat-servers">-</div><div class="stat-label">monitored</div></div>
      <div class="card"><h3>Critical Alerts</h3><div class="stat-value" style="color:var(--red)" id="stat-critical">-</div><div class="stat-label">unresolved</div></div>
      <div class="card"><h3>Warnings</h3><div class="stat-value" style="color:var(--yellow)" id="stat-warnings">-</div><div class="stat-label">unresolved</div></div>
      <div class="card"><h3>Avg Uptime</h3><div class="stat-value" style="color:var(--green)" id="stat-uptime">-</div><div class="stat-label">days</div></div>
    </div>

    <div id="server-grid" class="server-grid"></div>

    <div class="grid-2">
      <div class="card">
        <h3>CPU &amp; Memory Trends (24h)</h3>
        <div class="chart-container"><canvas id="chart-cpu-mem"></canvas></div>
      </div>
      <div class="card">
        <h3>Disk Usage Trends (24h)</h3>
        <div class="chart-container"><canvas id="chart-disk"></canvas></div>
      </div>
    </div>

    <div class="grid-2">
      <div class="card">
        <h3>Active Alerts</h3>
        <div id="alerts-list" class="timeline"></div>
      </div>
      <div class="card">
        <h3>Recent Events</h3>
        <div id="events-list" class="timeline"></div>
      </div>
    </div>
  </div>

<script>
const API = '';
let cpuMemChart, diskChart;
let countdown = 30;

function barColor(pct) {
  if (pct > 90) return 'var(--red)';
  if (pct > 80) return 'var(--orange)';
  if (pct > 60) return 'var(--yellow)';
  return 'var(--green)';
}

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
}

function fmtUptime(secs) {
  if (!secs) return '-';
  return Math.floor(secs / 86400);
}

function renderServers(servers) {
  const el = document.getElementById('server-grid');
  if (!servers.length) { el.innerHTML = '<div class="empty">No health data yet. Run monitor_server_health to collect data.</div>'; return; }

  document.getElementById('stat-servers').textContent = servers.length;
  const uptimes = servers.filter(s => s.uptime_seconds).map(s => s.uptime_seconds / 86400);
  document.getElementById('stat-uptime').textContent = uptimes.length ? Math.round(uptimes.reduce((a,b)=>a+b,0)/uptimes.length) : '-';

  el.innerHTML = servers.map(s => {
    const cpu = s.cpu_load && s.cpu_cores ? Math.round((s.cpu_load/s.cpu_cores)*100) : null;
    const mem = s.memory_used_pct ? Math.round(s.memory_used_pct) : null;
    const disk = s.disk_used_pct ? Math.round(s.disk_used_pct) : null;
    return `<div class="server-card">
      <div class="server-name"><span class="status-dot ok"></span>${s.server_name}</div>
      ${cpu !== null ? `<div class="metric-row"><span>CPU Load</span><span class="metric-val">${cpu}%</span></div><div class="metric-bar"><div class="fill" style="width:${Math.min(cpu,100)}%;background:${barColor(cpu)}"></div></div>` : ''}
      ${mem !== null ? `<div class="metric-row"><span>Memory</span><span class="metric-val">${mem}%</span></div><div class="metric-bar"><div class="fill" style="width:${mem}%;background:${barColor(mem)}"></div></div>` : ''}
      ${disk !== null ? `<div class="metric-row"><span>Disk</span><span class="metric-val">${disk}%</span></div><div class="metric-bar"><div class="fill" style="width:${disk}%;background:${barColor(disk)}"></div></div>` : ''}
      <div style="font-size:11px;color:var(--muted);margin-top:8px;">Updated: ${fmtTime(s.timestamp)} | Uptime: ${fmtUptime(s.uptime_seconds)}d</div>
    </div>`;
  }).join('');
}

function renderAlerts(alerts) {
  const el = document.getElementById('alerts-list');
  const counts = {critical:0, warning:0};
  alerts.forEach(a => { if (counts[a.severity] !== undefined) counts[a.severity]++; });
  document.getElementById('stat-critical').textContent = counts.critical;
  document.getElementById('stat-warnings').textContent = counts.warning;

  if (!alerts.length) { el.innerHTML = '<div class="empty">No active alerts</div>'; return; }
  el.innerHTML = alerts.slice(0,20).map(a => {
    const cls = a.severity === 'critical' ? 'badge-crit' : 'badge-warn';
    return `<div class="timeline-item">
      <span class="badge ${cls}">${a.severity}</span>
      <strong>${a.server_name}</strong> — ${a.message || a.category}
      <div class="timeline-time">${fmtTime(a.timestamp)}</div>
    </div>`;
  }).join('');
}

function renderEvents(events) {
  const el = document.getElementById('events-list');
  if (!events.length) { el.innerHTML = '<div class="empty">No recent events</div>'; return; }
  el.innerHTML = events.slice(0,20).map(e => {
    let icon = '&#8226;', text = '';
    if (e.event_type === 'alert') {
      icon = e.severity === 'critical' ? '&#128308;' : '&#128992;';
      text = `${e.server_name}: ${e.message || e.category}`;
    } else if (e.event_type === 'service') {
      icon = '&#9881;';
      text = `${e.server_name}: ${e.service_name} ${e.old_status} &rarr; ${e.new_status} (${e.action})`;
    } else if (e.event_type === 'playbook') {
      icon = '&#9889;';
      text = `${e.server_name}: playbook "${e.playbook_name}" — ${e.success ? 'OK' : 'FAILED'}`;
    }
    return `<div class="timeline-item">${icon} ${text}<div class="timeline-time">${fmtTime(e.timestamp)}</div></div>`;
  }).join('');
}

function updateCharts(servers) {
  // Fetch history for the first server to show trends
  if (!servers.length) return;
  const serverName = servers[0].server_name;
  fetch(API + '/api/health/history?server=' + encodeURIComponent(serverName) + '&hours=24')
    .then(r => r.json()).then(data => {
      const sorted = data.reverse();
      const labels = sorted.map(d => fmtTime(d.timestamp));
      const cpuData = sorted.map(d => d.cpu_load && d.cpu_cores ? Math.round((d.cpu_load/d.cpu_cores)*100) : null);
      const memData = sorted.map(d => d.memory_used_pct ? Math.round(d.memory_used_pct) : null);
      const diskData = sorted.map(d => d.disk_used_pct ? Math.round(d.disk_used_pct) : null);

      if (cpuMemChart) cpuMemChart.destroy();
      cpuMemChart = new Chart(document.getElementById('chart-cpu-mem'), {
        type: 'line',
        data: {
          labels,
          datasets: [
            { label: 'CPU %', data: cpuData, borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.1)', fill: true, tension: 0.3, pointRadius: 0 },
            { label: 'Memory %', data: memData, borderColor: '#a855f7', backgroundColor: 'rgba(168,85,247,0.1)', fill: true, tension: 0.3, pointRadius: 0 },
          ]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 0, max: 100, ticks:{color:'#71717a'}, grid:{color:'#2a2d3a'} }, x: { ticks:{color:'#71717a',maxTicksLimit:8}, grid:{display:false} } }, plugins: { legend: { labels:{color:'#e4e4e7'} } } }
      });

      if (diskChart) diskChart.destroy();
      diskChart = new Chart(document.getElementById('chart-disk'), {
        type: 'line',
        data: {
          labels,
          datasets: [
            { label: 'Disk %', data: diskData, borderColor: '#f97316', backgroundColor: 'rgba(249,115,22,0.1)', fill: true, tension: 0.3, pointRadius: 0 },
          ]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 0, max: 100, ticks:{color:'#71717a'}, grid:{color:'#2a2d3a'} }, x: { ticks:{color:'#71717a',maxTicksLimit:8}, grid:{display:false} } }, plugins: { legend: { labels:{color:'#e4e4e7'} } } }
      });
    });
}

async function refresh() {
  try {
    const [servers, alerts, events] = await Promise.all([
      fetch(API + '/api/health/latest').then(r => r.json()),
      fetch(API + '/api/alerts').then(r => r.json()),
      fetch(API + '/api/events?hours=24').then(r => r.json()),
    ]);
    renderServers(servers);
    renderAlerts(alerts);
    renderEvents(events);
    updateCharts(servers);
  } catch(e) { console.error('Refresh failed:', e); }
  countdown = 30;
}

refresh();
setInterval(() => { countdown--; document.getElementById('refresh-timer').textContent = countdown + 's'; if (countdown <= 0) refresh(); }, 1000);
</script>
</body>
</html>"""


async def dashboard_page(request):
    """Serve the dashboard HTML page."""
    return HTMLResponse(_DASHBOARD_HTML)


# ---------------------------------------------------------------------------
# Starlette app
# ---------------------------------------------------------------------------
routes = [
    Route("/", dashboard_page),
    Route("/api/health/latest", api_health_latest),
    Route("/api/health/history", api_health_history),
    Route("/api/alerts", api_alerts),
    Route("/api/alerts/counts", api_alert_counts),
    Route("/api/events", api_events),
    Route("/api/endpoints", api_endpoints),
    Route("/api/services/events", api_service_events),
    Route("/api/playbooks/runs", api_playbook_runs),
]

app = Starlette(routes=routes)


def run_dashboard(host: str = "0.0.0.0", port: int = 8080):
    """Start the dashboard web server."""
    import uvicorn
    _db.init_db()
    print(f"\n  Server Guardian Dashboard running at http://localhost:{port}\n")
    uvicorn.run(app, host=host, port=port, log_level="info")
