"""Vibe-Trading core package."""
