"""Core module: Runner + RunStateStore."""
