"""Word filtering settings panel."""

import logging
from pathlib import Path

from PyQt6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QWidget,
)

from anki_miner.gui.widgets.base import FormPanel
from anki_miner.gui.widgets.enhanced import FileSelector

logger = logging.getLogger(__name__)

# Built-in regex presets for common subtitle noise. Buttons append these to the
# user's pattern with `|` so multiple presets can be stacked. Patterns target
# both half-width and full-width punctuation common in JP subtitle files.
SUBTITLE_REGEX_PRESETS: tuple[tuple[str, str], ...] = (
    ("Parens (Tanaka)", r"\([^)]*\)|（[^）]*）"),
    ("Brackets [SFX]", r"\[[^\]]*\]|［[^］]*］"),
    ("Music ♪♬", r"[♪♬♫#～〜]+"),
    ("Speaker: prefix", r"^[^「『:：]+[:：]\s*"),
)


class FilteringSettingsPanel(FormPanel):
    """Panel for word filtering settings.

    Provides:
    - Word frequency filtering options
    """

    def __init__(self, parent=None):
        """Initialize the filtering settings panel."""
        super().__init__("Word Filtering", parent=parent)
        self._setup_fields()
        self._connect_validation()

    def _setup_fields(self) -> None:
        """Set up the panel fields."""
        # Word Frequency section
        self.add_section("Word Frequency")

        # Frequency file path
        self.frequency_selector = FileSelector(
            label="", file_mode=True, placeholder="Select frequency list CSV..."
        )
        self.frequency_selector.setToolTip("Path to word frequency list CSV")
        self.add_field(
            "Frequency List File",
            self.frequency_selector,
            helper="Path to a Japanese word frequency list (CSV format: word, rank)",
        )

        # Use frequency data checkbox
        self.use_frequency_checkbox = QCheckBox("Enable Frequency Data")
        self.use_frequency_checkbox.setToolTip("Attach word frequency ranks to cards")
        self.add_field(
            "",
            self.use_frequency_checkbox,
            helper="Enable to display word frequency rank on cards",
        )

        # Max frequency rank
        self.max_frequency_spinbox = QSpinBox()
        self.max_frequency_spinbox.setRange(0, 100000)
        self.max_frequency_spinbox.setSpecialValueText("No limit")
        self.max_frequency_spinbox.setToolTip(
            "Only mine words within the top N most frequent (0 = no limit)"
        )
        self.add_field(
            "Max Frequency Rank",
            self.max_frequency_spinbox,
            helper="Set to 0 for no limit, or e.g. 10000 to only mine top 10,000 words",
        )

        # Known Words Database section
        self.add_section("Known Words Database")

        self.use_known_words_db_checkbox = QCheckBox("Use Local Known Words Database")
        self.use_known_words_db_checkbox.setToolTip("Cache known words locally for faster startup")
        self.add_field(
            "",
            self.use_known_words_db_checkbox,
            helper="Caches known words in a local SQLite database to avoid querying Anki on every run",
        )

        # Word Lists section
        self.add_section("Word Lists")

        self.blacklist_selector = FileSelector(
            label="", file_mode=True, placeholder="Select blacklist file..."
        )
        self.add_field(
            "Blacklist File",
            self.blacklist_selector,
            helper="Text file with one word per line to always skip",
        )

        self.use_blacklist_checkbox = QCheckBox("Enable Blacklist")
        self.add_field(
            "",
            self.use_blacklist_checkbox,
            helper="Skip words found in the blacklist file",
        )

        self.whitelist_selector = FileSelector(
            label="", file_mode=True, placeholder="Select whitelist file..."
        )
        self.add_field(
            "Whitelist File",
            self.whitelist_selector,
            helper="Text file with one word per line to always include",
        )

        self.use_whitelist_checkbox = QCheckBox("Enable Whitelist")
        self.add_field(
            "",
            self.use_whitelist_checkbox,
            helper="Always include words found in the whitelist file",
        )

        # Subtitle Text Filtering section (Issue #8)
        self.add_section("Subtitle Text Filtering")

        self.subtitle_regex_edit = QLineEdit()
        self.subtitle_regex_edit.setPlaceholderText(r"e.g. \([^)]*\)|\[[^\]]*\]")
        self.subtitle_regex_edit.setToolTip(
            "Python regex applied to each subtitle line before tokenization. "
            "Combine alternatives with |. Test patterns at https://regex101.com."
        )
        self.add_field(
            "Regex Filter",
            self.subtitle_regex_edit,
            helper="Patterns matched in subtitle text are removed (or replaced) before mining. "
            "Useful for stripping speaker names like (Tanaka) or sound descriptions like [door].",
        )

        self.subtitle_replacement_edit = QLineEdit()
        self.subtitle_replacement_edit.setPlaceholderText("(empty = delete match)")
        self.subtitle_replacement_edit.setToolTip(
            "Text inserted in place of each match. Empty deletes the match."
        )
        self.add_field(
            "Replacement",
            self.subtitle_replacement_edit,
            helper="Use Python backreferences (\\1 \\2) for capture groups. "
            "Note: NOT $1 $2 syntax like asbplayer; translate when copying patterns.",
        )

        self.use_subtitle_regex_checkbox = QCheckBox("Enable Subtitle Regex Filter")
        self.add_field(
            "",
            self.use_subtitle_regex_checkbox,
            helper="Apply the filter to all parsed subtitle lines (mining and preview).",
        )

        # Preset buttons row: each click appends its pattern to the regex field
        # joined with `|`. Lets a GUI-only user discover useful patterns without
        # learning regex syntax up front.
        preset_container = QWidget()
        preset_layout = QHBoxLayout()
        preset_layout.setContentsMargins(0, 0, 0, 0)
        for label, pattern in SUBTITLE_REGEX_PRESETS:
            btn = QPushButton(label)
            btn.setToolTip(pattern)
            btn.clicked.connect(lambda _checked=False, p=pattern: self._append_preset(p))
            preset_layout.addWidget(btn)
        preset_layout.addStretch()
        preset_container.setLayout(preset_layout)
        self.add_field(
            "Presets",
            preset_container,
            helper="Click to append a built-in pattern to the regex field above.",
        )

        # Deduplication section
        self.add_section("Deduplication")

        self.deduplicate_sentences_checkbox = QCheckBox("Deduplicate by Sentence")
        self.deduplicate_sentences_checkbox.setToolTip(
            "Skip words that share an identical sentence with an already-selected word"
        )
        self.add_field(
            "",
            self.deduplicate_sentences_checkbox,
            helper="Skip words that share an identical sentence with an already-selected word",
        )

        self.add_stretch()

    def _append_preset(self, pattern: str) -> None:
        """Append a preset regex pattern to the filter field with `|` join."""
        current = self.subtitle_regex_edit.text().strip()
        if not current:
            self.subtitle_regex_edit.setText(pattern)
        elif pattern in current:
            # Avoid duplicate alternations from double-clicking a preset.
            return
        else:
            self.subtitle_regex_edit.setText(f"{current}|{pattern}")

    def _connect_validation(self) -> None:
        """Connect file selector signals to validation handlers."""
        self.frequency_selector.path_validated.connect(self._validate_frequency_file)

    def _validate_frequency_file(self, is_valid: bool, path_str: str) -> None:
        """Validate frequency file and show entry count."""
        if not is_valid or not path_str:
            return

        try:
            from anki_miner.services.frequency_service import FrequencyService

            service = FrequencyService(Path(path_str))
            service.load()
            count = service.entry_count
            self.frequency_selector.status_label.setText(
                f"{Path(path_str).name} ({count:,} entries)"
            )
        except Exception as e:
            self.frequency_selector.status_label.setText(f"Could not parse file: {e}")
