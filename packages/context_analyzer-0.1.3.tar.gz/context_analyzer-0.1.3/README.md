# context-analyzer

CLI инструмент для экспорта структуры проекта и файлов в JSON и TXT.
Подходит для передачи контекста в LLM и анализа кода.

---

## Установка

```bash
pip install context-analyzer
```

или

```bash
uv pip install context-analyzer
```

---

## Использование

```bash
context-analyzer <path>
```

Пример:

```bash
context-analyzer .
```

---

## Опции

```
-o, --output        имя выходного файла (без расширения)
--format            json | txt | both (по умолчанию both)
--no-content        не включать содержимое файлов
```

---

## Примеры

```bash
# JSON + TXT
context-analyzer . -o result

# только JSON
context-analyzer . --format json

# быстро (без содержимого)
context-analyzer . --no-content
```

---

## Игнорирование файлов

Поддерживаются:

* `.gitignore`
* `.ignorecontext` ⭐ (кастомный файл для управления экспортом)
* директория `.git`

### Пример `.ignorecontext`

```
node_modules/
*.log
.env
dist/
```

👉 Полезно, когда нужно исключить файлы **только для экспорта контекста**, не трогая `.gitignore`.

---

## Выходные файлы

Создаются:

```
result.json
result.txt
```

---

## Возможности

* обход директорий
* фильтрация через `.gitignore` и `.ignorecontext`
* игнор бинарных файлов
* ограничение размера файлов
* прогресс-бар

---

## Использование в Python

```python
from pathlib import Path
from context_analyzer.ignore import IgnoreParser
from context_analyzer.core import create_json

path = Path(".")
ignore = IgnoreParser(path)

data = create_json(path, ignore)
```
---

## Лицензия

MIT
