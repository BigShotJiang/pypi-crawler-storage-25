class DatabaseError(Exception):
    """Base exception for database operations."""


class DatabaseConnectionError(DatabaseError):
    """Raised when a database connection cannot be established."""


class DatabaseQueryError(DatabaseError):
    """Raised when a query fails."""

    def __init__(self, query: str, message: str):
        self.query = query
        self.message = message
        super().__init__(f"Query failed: {message}")
