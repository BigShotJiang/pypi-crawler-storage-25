"""Lightweight synchronous database wrapper around psycopg2."""

from __future__ import annotations

import re
from typing import Any

from ._errors import DatabaseConnectionError, DatabaseQueryError


def _rewrite_query(query: str) -> str:
    """Convert ``:param`` placeholders to psycopg2's ``%(param)s`` style."""
    return re.sub(r":(\w+)", r"%(\1)s", query)


class Database:
    """Synchronous database wrapper with a clean query interface.

    Queries use ``:param`` named placeholders::

        db.fetch_all("SELECT * FROM t WHERE id = :id", {"id": 1})

    Connections are lazy — the database is not contacted until the first
    query or an explicit call to :meth:`connect`.
    """

    def __init__(
        self,
        dsn: str | None = None,
        *,
        host: str | None = None,
        port: int | str = 5432,
        dbname: str | None = None,
        user: str | None = None,
        password: str | None = None,
    ):
        self._dsn = dsn
        self._host = host
        self._port = int(port)
        self._dbname = dbname
        self._user = user
        self._password = password
        self._conn: Any = None

    # -- connection lifecycle -----------------------------------------------

    def connect(self) -> None:
        """Open the database connection (called automatically on first query)."""
        if self._conn is not None:
            return

        try:
            import psycopg2
        except ImportError:
            raise DatabaseConnectionError(
                "psycopg2 is required for Database. "
                "Install it with: pip install psycopg2-binary"
            )

        try:
            if self._dsn:
                self._conn = psycopg2.connect(self._dsn)
            else:
                self._conn = psycopg2.connect(
                    host=self._host,
                    port=self._port,
                    dbname=self._dbname,
                    user=self._user,
                    password=self._password,
                )
            self._conn.autocommit = True
        except psycopg2.Error as exc:
            raise DatabaseConnectionError(str(exc)) from exc

    def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal helpers ---------------------------------------------------

    def _ensure_connected(self) -> None:
        if self._conn is None:
            self.connect()

    def _execute(self, query: str, params: dict | None = None):
        """Execute a query and return the cursor."""
        from psycopg2.extras import RealDictCursor

        self._ensure_connected()
        sql = _rewrite_query(query)
        cur = self._conn.cursor(cursor_factory=RealDictCursor)
        try:
            cur.execute(sql, params)
        except Exception as exc:
            cur.close()
            raise DatabaseQueryError(query, str(exc)) from exc
        return cur

    # -- public query interface ---------------------------------------------

    def fetch_all(self, query: str, params: dict | None = None) -> list[dict]:
        """Execute a query and return all rows as a list of dicts."""
        cur = self._execute(query, params)
        try:
            return [dict(row) for row in cur.fetchall()]
        finally:
            cur.close()

    def fetch_one(self, query: str, params: dict | None = None) -> dict | None:
        """Execute a query and return the first row, or None."""
        cur = self._execute(query, params)
        try:
            row = cur.fetchone()
            return dict(row) if row is not None else None
        finally:
            cur.close()

    def fetch_val(self, query: str, params: dict | None = None) -> Any | None:
        """Execute a query and return the first column of the first row, or None."""
        row = self.fetch_one(query, params)
        if row is None:
            return None
        return next(iter(row.values()))

    def execute(self, query: str, params: dict | None = None) -> int:
        """Execute a query and return the number of affected rows."""
        cur = self._execute(query, params)
        try:
            return cur.rowcount
        finally:
            cur.close()


def get_db(
    dsn: str | None = None,
    *,
    section: str = "goliath_db",
    secrets_client: Any = None,
) -> Database:
    """Create a :class:`Database` from Goliath secrets or a DSN string.

    With no arguments, fetches credentials from the ``goliath_db`` section
    of the Goliath secrets API (requires ``GOLIATH_API_URL`` and
    ``GOLIATH_API_KEY`` environment variables).

    Pass *dsn* to skip the secrets lookup entirely::

        db = get_db("postgresql://user:pass@host/dbname")
    """
    if dsn is not None:
        return Database(dsn=dsn)

    from goliath_utils.secrets import SecretsClient

    client = secrets_client or SecretsClient()
    creds = client.get_section(section)

    return Database(
        host=creds["host"],
        port=creds["port"],
        dbname=creds["db_name"],
        user=creds["db_username"],
        password=creds["db_password"],
    )
