"""Lightweight S3 client using httpx and AWS SigV4."""

from __future__ import annotations

import os
import xml.etree.ElementTree as ET
from pathlib import Path

import httpx
from dotenv import load_dotenv

from ._auth import sign_request
from ._errors import S3AuthError, S3RequestError

S3_NS = "http://s3.amazonaws.com/doc/2006-03-01/"


class S3Client:
    """Minimal S3 client — no boto3 required.

    Reads credentials from constructor args or environment variables:
    AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION.
    """

    def __init__(
        self,
        *,
        access_key: str | None = None,
        secret_key: str | None = None,
        region: str | None = None,
        timeout: float = 30.0,
    ):
        dotenv_loaded = load_dotenv()

        self.access_key = access_key or os.environ.get("AWS_ACCESS_KEY_ID", "")
        self.secret_key = secret_key or os.environ.get("AWS_SECRET_ACCESS_KEY", "")
        self.region = region or os.environ.get("AWS_REGION", "us-east-1")

        if not self.access_key or not self.secret_key:
            missing = [
                name
                for name, val in [("AWS_ACCESS_KEY_ID", self.access_key), ("AWS_SECRET_ACCESS_KEY", self.secret_key)]
                if not val
            ]
            env_hint = (
                " No .env file was found — create one with these variables"
                " or export them in your shell."
                if not dotenv_loaded
                else " A .env file was loaded but these variables were not set in it."
            )
            raise S3AuthError(
                f"Missing required environment variable(s): {', '.join(missing)}.{env_hint}"
            )

        self._http = httpx.Client(timeout=timeout)

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal helpers --------------------------------------------------

    def _endpoint(self, bucket: str, key: str = "") -> str:
        path = f"/{key}" if key else "/"
        return f"https://{bucket}.s3.{self.region}.amazonaws.com{path}"

    def _signed_request(
        self,
        method: str,
        url: str,
        payload: bytes = b"",
        extra_headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        headers = dict(extra_headers or {})
        signed = sign_request(
            method,
            url,
            headers,
            payload,
            access_key=self.access_key,
            secret_key=self.secret_key,
            region=self.region,
        )
        resp = self._http.request(method, url, headers=signed, content=payload)
        if resp.status_code >= 300:
            self._raise_error(resp)
        return resp

    @staticmethod
    def _raise_error(resp: httpx.Response) -> None:
        code = "Unknown"
        message = resp.text
        try:
            root = ET.fromstring(resp.text)
            code_el = root.find("Code")
            msg_el = root.find("Message")
            if code_el is not None and code_el.text:
                code = code_el.text
            if msg_el is not None and msg_el.text:
                message = msg_el.text
        except ET.ParseError:
            pass
        raise S3RequestError(resp.status_code, code, message)

    # -- public API --------------------------------------------------------

    def get_object(self, bucket: str, key: str) -> bytes:
        """Download an S3 object and return its raw bytes."""
        url = self._endpoint(bucket, key)
        resp = self._signed_request("GET", url)
        return resp.content

    def put_object(self, bucket: str, key: str, data: bytes) -> None:
        """Upload raw bytes to an S3 key."""
        url = self._endpoint(bucket, key)
        self._signed_request("PUT", url, payload=data)

    def create_bucket(self, bucket: str) -> None:
        url = self._endpoint(bucket)
        if self.region == "us-east-1":
            self._signed_request("PUT", url)
        else:
            body = (
                f'<CreateBucketConfiguration xmlns="{S3_NS}">'
                f"<LocationConstraint>{self.region}</LocationConstraint>"
                f"</CreateBucketConfiguration>"
            ).encode()
            self._signed_request("PUT", url, payload=body)

    def delete_bucket(self, bucket: str) -> None:
        url = self._endpoint(bucket)
        self._signed_request("DELETE", url)

    def delete_object(self, bucket: str, key: str) -> None:
        url = self._endpoint(bucket, key)
        self._signed_request("DELETE", url)

    def copy_object(
        self,
        src_bucket: str,
        src_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> None:
        url = self._endpoint(dest_bucket, dest_key)
        copy_source = f"/{src_bucket}/{src_key}"
        self._signed_request(
            "PUT", url, extra_headers={"x-amz-copy-source": copy_source}
        )

    def move_object(
        self,
        src_bucket: str,
        src_key: str,
        dest_bucket: str,
        dest_key: str,
    ) -> None:
        self.copy_object(src_bucket, src_key, dest_bucket, dest_key)
        self.delete_object(src_bucket, src_key)

    def upload_file(
        self, bucket: str, key: str, file_path: Path | str
    ) -> None:
        file_path = Path(file_path)
        data = file_path.read_bytes()
        url = self._endpoint(bucket, key)
        self._signed_request("PUT", url, payload=data)

    def download_file(
        self, bucket: str, key: str, dest_path: Path | str
    ) -> None:
        dest_path = Path(dest_path)
        url = self._endpoint(bucket, key)
        resp = self._signed_request("GET", url)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        dest_path.write_bytes(resp.content)

    def list_objects(self, bucket: str, prefix: str = "") -> list[str]:
        url = self._endpoint(bucket)
        keys: list[str] = []
        continuation_token = ""

        while True:
            qs = f"list-type=2&prefix={prefix}"
            if continuation_token:
                qs += f"&continuation-token={continuation_token}"
            resp = self._signed_request("GET", f"{url}?{qs}")

            root = ET.fromstring(resp.text)
            for contents in root.findall(f"{{{S3_NS}}}Contents"):
                key_el = contents.find(f"{{{S3_NS}}}Key")
                if key_el is not None and key_el.text:
                    keys.append(key_el.text)

            is_truncated = root.find(f"{{{S3_NS}}}IsTruncated")
            if is_truncated is not None and is_truncated.text == "true":
                token_el = root.find(f"{{{S3_NS}}}NextContinuationToken")
                if token_el is not None and token_el.text:
                    continuation_token = token_el.text
                    continue
            break

        return keys
