from setuptools import setup, find_packages

setup(
    name="recel-sdk",
    version="0.1.2",
    packages=find_packages(),
    install_requires=["requests>=2.25.0"],
    author="Michelangelo Di Nicola",
    author_email="michelangelodinicola@gmail.com",
    description="SDK per integrare ReCEL, un modello di linguaggio empatico, in applicazioni Python.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/itsThings-AI/recel-sdk",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)