# ReCEL SDK

SDK per integrare ReCEL, un modello di linguaggio progettato per l'ascolto profondo e la connessione umana.

## Installazione

```bash
pip install recel-sdk