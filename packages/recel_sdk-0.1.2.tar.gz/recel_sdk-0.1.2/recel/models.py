from typing import Literal

StyleType = Literal["emphatic", "deep", "concise"]