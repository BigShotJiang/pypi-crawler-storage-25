import requests
from typing import Optional, Literal

class ReCEL:
    """
    Client SDK per l'API di ReCEL (versione 1).
    Punto di accesso: https://things-ai.org/api/v1/chat
    """

    def __init__(self, api_base_url: str = "https://things-ai.org", api_key: Optional[str] = None):
        """
        Inizializza il client.

        :param api_base_url: URL base dell'API (default: https://things-ai.org)
        :param api_key: Chiave API opzionale (se il backend richiede autenticazione)
        """
        self.api_base_url = api_base_url.rstrip('/')
        self.api_key = api_key

    def chat(
        self,
        message: str,
        max_tokens: int = 256,
        style: Literal["emphatic", "deep", "concise"] = "emphatic",
        temperature: float = 0.3
    ) -> str:
        """
        Invia un messaggio a ReCEL e restituisce la risposta.

        :param message: Testo dell'utente.
        :param max_tokens: Lunghezza massima della risposta (default 256, range 10-2048).
        :param style: Stile della risposta ("emphatic", "deep", "concise").
        :param temperature: Controlla la casualità (0.0 = deterministico, 1.0 = più creativo).
        :return: Risposta testuale di ReCEL.
        """
        url = f"{self.api_base_url}/api/v1/chat"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "message": message,
            "max_tokens": max_tokens,
            "style": style,
            "temperature": temperature
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data["reply"]
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Errore di comunicazione con l'API ReCEL: {e}")
        except (KeyError, ValueError) as e:
            raise RuntimeError(f"Risposta API non valida: {e}")

    # Metodo asincrono (opzionale, richiede aiohttp)
    # async def achat(self, ...):
    #     pass