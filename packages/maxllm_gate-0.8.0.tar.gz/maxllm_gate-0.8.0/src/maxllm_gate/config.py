"""maxllm_gate Configuration handling."""

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv


@dataclass(frozen=True)
class ModelRateLimit:
    """Required TPM/RPM limits for a single model."""

    tpm_limit: int
    rpm_limit: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ModelRateLimit":
        """Create from dictionary and fail fast on missing limits."""
        if "tpm_limit" not in data or "rpm_limit" not in data:
            raise ValueError(
                "Each model config must define both 'tpm_limit' and 'rpm_limit'."
            )
        return cls(
            tpm_limit=int(data["tpm_limit"]),
            rpm_limit=int(data["rpm_limit"]),
        )


@dataclass
class KeyConfig:
    """Configuration for a single API key."""

    api_key: str
    provider: str
    # Accepts dict or ModelRateLimit at init; normalized to ModelRateLimit in __post_init__
    models: dict[str, ModelRateLimit | dict[str, Any]]
    key_id: str | None = None
    base_url: str | None = None  # Custom endpoint (e.g., OpenRouter, local LLM)

    def __post_init__(self) -> None:
        if self.key_id is None:
            # Generate key_id from provider and hash
            self.key_id = f"{self.provider}-{hash(self.api_key) % 10000:04d}"
        normalized_models: dict[str, ModelRateLimit] = {}
        for model_name, limits in self.models.items():
            cleaned_name = model_name.strip()
            if not cleaned_name:
                raise ValueError("Model names cannot be empty")
            if isinstance(limits, ModelRateLimit):
                normalized_models[cleaned_name] = limits
            else:
                normalized_models[cleaned_name] = ModelRateLimit.from_dict(limits)
        if not normalized_models:
            raise ValueError("At least one model must be configured per key")
        # After normalization, all values are ModelRateLimit
        object.__setattr__(self, "models", normalized_models)

    def get_model_limit(self, model: str) -> ModelRateLimit:
        """Get limits for a model, accepting provider-prefixed model names."""
        limits = self.models.get(model)
        if limits is not None:
            if isinstance(limits, ModelRateLimit):
                return limits
            return ModelRateLimit.from_dict(limits)
        if "/" in model:
            base_model = model.split("/", 1)[1]
            base_limits = self.models.get(base_model)
            if base_limits is not None:
                if isinstance(base_limits, ModelRateLimit):
                    return base_limits
                return ModelRateLimit.from_dict(base_limits)
        raise KeyError(f"Model '{model}' is not configured for key '{self.key_id}'")

    @classmethod
    def from_dict(cls, data: dict[str, Any], key_id: str | None = None) -> "KeyConfig":
        """Create from dictionary."""
        models = data.get("models", {})
        if not isinstance(models, dict):
            raise ValueError(
                "Key config 'models' must be an object mapping model name to "
                "{tpm_limit, rpm_limit}."
            )
        return cls(
            key_id=key_id or data.get("key_id"),
            api_key=data["api_key"],
            provider=data["provider"],
            models=models,
            base_url=data.get("base_url"),
        )


@dataclass
class maxllm_gate_config:
    """Main configuration for maxllm_gate."""

    keys: list[KeyConfig] = field(default_factory=list)

    # Scheduling
    strategy: str = "least_utilized"

    # Defaults
    default_max_tokens: int = 1024
    default_temperature: float = 0.7
    token_buffer: float = 1.2  # Increased buffer for safety

    # Retry
    max_retries: int = 3
    retry_base_delay: float = 1.0
    retry_max_delay: float = 60.0

    # Queue
    max_queue_size: int = 10000

    # Concurrency
    max_concurrent_requests: int = 100  # Max parallel LLM requests

    # Timeout & Limits (NEW - for edge cases)
    max_wait_time: float = 60.0   # Max seconds to wait for capacity
    request_timeout: float = 120.0  # Total request timeout

    # Circuit Breaker (NEW)
    circuit_breaker_threshold: int = 5  # Consecutive failures to open circuit
    circuit_breaker_timeout: float = 60.0  # Seconds before retry after circuit opens

    # Server (for API mode)
    host: str = "0.0.0.0"
    port: int = 8000

    @classmethod
    def from_file(cls, path: str | Path) -> "maxllm_gate_config":
        """File-based configuration has been removed in favor of env-only config."""
        raise ValueError(
            "File-based config is no longer supported. "
            "Copy .env.example to .env, set API_KEYS_CONFIG, and use maxllm_gate.from_env()."
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "maxllm_gate_config":
        """Create from dictionary."""
        keys = []

        # Handle keys as list or dict
        keys_data = data.get("keys", [])
        if isinstance(keys_data, dict):
            for key_id, key_config in keys_data.items():
                keys.append(KeyConfig.from_dict(key_config, key_id=key_id))
        elif isinstance(keys_data, list):
            for key_config in keys_data:
                keys.append(KeyConfig.from_dict(key_config))

        return cls(
            keys=keys,
            strategy=data.get("strategy", "least_utilized"),
            default_max_tokens=data.get("default_max_tokens", 1024),
            default_temperature=data.get("default_temperature", 0.7),
            token_buffer=data.get("token_buffer", 1.2),
            max_retries=data.get("max_retries", 3),
            retry_base_delay=data.get("retry_base_delay", 1.0),
            retry_max_delay=data.get("retry_max_delay", 60.0),
            max_queue_size=data.get("max_queue_size", 10000),
            max_concurrent_requests=data.get("max_concurrent_requests", 100),
            max_wait_time=data.get("max_wait_time", 60.0),
            request_timeout=data.get("request_timeout", 120.0),
            circuit_breaker_threshold=data.get("circuit_breaker_threshold", 5),
            circuit_breaker_timeout=data.get("circuit_breaker_timeout", 60.0),
            host=data.get("host", "0.0.0.0"),
            port=data.get("port", 8000),
        )

    @classmethod
    def from_env(cls) -> "maxllm_gate_config":
        """Load configuration from environment variables."""
        load_dotenv()
        keys_json = os.environ.get("API_KEYS_CONFIG")
        if not keys_json:
            raise ValueError(
                "API_KEYS_CONFIG environment variable is required. "
                "Copy .env.example to .env and set your provider keys there."
            )

        try:
            keys_data = json.loads(keys_json)
        except json.JSONDecodeError as exc:
            raise ValueError("API_KEYS_CONFIG must contain valid JSON.") from exc

        keys = []
        for key_id, key_config in keys_data.items():
            keys.append(KeyConfig.from_dict(key_config, key_id=key_id))

        if not keys:
            raise ValueError("API_KEYS_CONFIG must define at least one API key.")

        return cls(
            keys=keys,
            strategy=(
                os.environ.get("DEFAULT_STRATEGY")
                or os.environ.get("maxllm_gate_STRATEGY")
                or "least_utilized"
            ),
            default_max_tokens=int(
                os.environ.get("DEFAULT_MAX_TOKENS")
                or os.environ.get("maxllm_gate_MAX_TOKENS")
                or "1024"
            ),
            default_temperature=float(os.environ.get("DEFAULT_TEMPERATURE", "0.7")),
            token_buffer=float(os.environ.get("TOKEN_ESTIMATION_BUFFER", "1.2")),
            max_retries=int(
                os.environ.get("MAX_RETRIES")
                or os.environ.get("maxllm_gate_MAX_RETRIES")
                or "3"
            ),
            retry_base_delay=float(os.environ.get("RETRY_BASE_DELAY", "1.0")),
            retry_max_delay=float(os.environ.get("RETRY_MAX_DELAY", "60.0")),
            max_queue_size=int(os.environ.get("MAX_QUEUE_SIZE", "10000")),
            host=os.environ.get("HOST", "0.0.0.0"),
            port=int(os.environ.get("PORT", "8000")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        def model_limits_to_dict(limits: ModelRateLimit | dict[str, Any]) -> dict[str, Any]:
            if isinstance(limits, ModelRateLimit):
                return asdict(limits)
            return limits
        
        return {
            "keys": {
                k.key_id: {
                    "api_key": k.api_key,
                    "provider": k.provider,
                    "models": {
                        model_name: model_limits_to_dict(limits)
                        for model_name, limits in k.models.items()
                    },
                    **({"base_url": k.base_url} if k.base_url else {}),
                }
                for k in self.keys
            },
            "strategy": self.strategy,
            "default_max_tokens": self.default_max_tokens,
            "default_temperature": self.default_temperature,
            "token_buffer": self.token_buffer,
            "max_retries": self.max_retries,
            "max_queue_size": self.max_queue_size,
            "max_concurrent_requests": self.max_concurrent_requests,
        }
