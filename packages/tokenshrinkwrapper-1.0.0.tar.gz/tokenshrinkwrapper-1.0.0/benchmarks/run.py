#!/usr/bin/env python3
"""Compare legacy (uniform pipeline) vs current segmented compressor on sample corpora.

Run from repo root after ``pip install -e .``:

    python benchmarks/run.py
"""

from __future__ import annotations

import statistics
import sys
import time
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from tokenshrinkwrapper.compressor import (  # noqa: E402
    _caveman_pass,
    _drop_markdown_headers,
    _extractive_pass,
    _normalize_whitespace,
    _pipeline_local,
    estimate_tokens,
)

MODEL = "gpt-4o-mini"


def pipeline_legacy_uniform(text: str, mode: str) -> str:
    """Pre-segmentation behavior: same rules applied to entire blob."""

    mode = mode.strip().lower()
    current = text
    if mode in {"light", "balanced", "aggressive"}:
        current = _drop_markdown_headers(current)
        current = _normalize_whitespace(current)
    if mode in {"balanced", "aggressive"}:
        current = _caveman_pass(current)
    if mode == "aggressive":
        current = _extractive_pass(current, keep_ratio=0.4)
    return current


def make_prose_chunks(n: int) -> str:
    para = (
        "## Notes\n\n"
        "This is explanatory narrative about the architecture and repeated reasoning. "
        "The repository includes modules that handle ingestion and normalization. "
        "See also /srv/app/config.toml and UUID 0192b3fc-89b1-7c3f-9dfe-xxxxxxxxxxxx.\n\n"
    )
    return para * n


def make_mixed_md() -> str:
    block = """# Design doc excerpt

Intro paragraph with filler and the quick brown fox story repeated for length.
We discuss tradeoffs and dependencies between services.

```python
# debug helper
import json

def handle_payload(raw: str) -> dict:
    # parse then validate
    for chunk in raw.splitlines():
        if not chunk.strip():
            continue
        return json.loads(chunk)
    return {}
```

Closing narrative that restates the same ideas in different words for redundancy.
"""
    return block * 8


def make_plain_py() -> str:
    return '''import math

def bump(x: int) -> int:
    # increment
    return x + 1

class Box:
    def __init__(self, v: int) -> None:
        self.v = v
''' * 10


def make_c_header() -> str:
    return """#include <stdio.h>
#define MAGIC 0x41
// file scope
extern int errno_proxy;

static inline int add(int a, int b) {
    return a + b;
}
""" * 5


CORPORA: list[tuple[str, str]] = [
    ("prose_only", make_prose_chunks(25)),
    ("mixed_md_fenced_python", make_mixed_md()),
    ("plain_python_no_fence", make_plain_py()),
    ("c_like_header", make_c_header()),
]


def median_time(fn, warmup: int = 3, runs: int = 25) -> float:
    for _ in range(warmup):
        fn()
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    return statistics.median(times)


def main() -> None:
    print(f"Token model: {MODEL}\n")
    print("legacy = uniform markdown headers + whitespace + caveman + extractive (0.4)")
    print("now    = segmented code vs prose (fenced ``` blocks + heuristic source blobs)")
    print()

    for name, text in CORPORA:
        before = estimate_tokens(text, MODEL)
        print(f"=== {name} === input tokens={before:,}")

        for mode in ("light", "balanced", "aggressive"):
            leg = pipeline_legacy_uniform(text, mode)
            cur = _pipeline_local(text, mode)
            lt, nt = estimate_tokens(leg, MODEL), estimate_tokens(cur, MODEL)
            lr = lt / before if before else 0.0
            nr = nt / before if before else 0.0
            delta = lt - nt
            print(
                f"  {mode:10} legacy {lt:>5} ({lr:.3f}) | now {nt:>5} ({nr:.3f}) | Δtokens {delta:+d}"
            )

        def bench_legacy():
            pipeline_legacy_uniform(text, "aggressive")

        def bench_current():
            _pipeline_local(text, "aggressive")

        tls, tns = median_time(bench_legacy), median_time(bench_current)
        pct = (tns / tls - 1) * 100 if tls else 0.0
        print(f"  time aggressive median: legacy {tls * 1000:.3f} ms | now {tns * 1000:.3f} ms ({pct:+.1f}%)")

        agg_new = _pipeline_local(text, "aggressive")
        if name == "mixed_md_fenced_python":
            ok = "for chunk" in agg_new
            print(f"  integrity: fenced loop keyword 'for chunk' preserved: {ok}")
        if name == "c_like_header":
            ok = "#include" in agg_new and "#define MAGIC" in agg_new
            print(f"  integrity: C preprocessor lines preserved: {ok}")
        print()


if __name__ == "__main__":
    main()
