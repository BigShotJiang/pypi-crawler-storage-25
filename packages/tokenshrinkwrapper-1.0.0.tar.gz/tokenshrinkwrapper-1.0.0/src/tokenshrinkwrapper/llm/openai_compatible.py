from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Sequence

from tokenshrinkwrapper.config import LLMSection
from tokenshrinkwrapper.llm.base import ChatMessage


class LLMCompletionError(RuntimeError):
    pass


class OpenAICompatibleClient:
    """Minimal OpenAI-compatible chat completions client (stdlib only)."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        default_temperature: float = 0.0,
        default_max_tokens: int = 4096,
        timeout_s: float = 120.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model
        self._default_temperature = default_temperature
        self._default_max_tokens = default_max_tokens
        self._timeout_s = timeout_s

    @classmethod
    def from_env(cls, section: LLMSection) -> OpenAICompatibleClient:
        key = os.environ.get(section.api_key_env, "")
        if not key:
            raise LLMCompletionError(
                f"Missing API key env var {section.api_key_env!r}. "
                "Set it before using semantic distillation."
            )
        return cls(
            base_url=section.base_url,
            api_key=key,
            model=section.model,
            default_temperature=section.temperature,
            default_max_tokens=section.max_completion_tokens,
        )

    def complete(
        self,
        messages: Sequence[ChatMessage],
        *,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> str:
        url = f"{self._base_url}/chat/completions"
        payload: dict[str, object] = {
            "model": self._model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": self._default_temperature
            if temperature is None
            else temperature,
        }

        mt = self._default_max_tokens if max_tokens is None else max_tokens
        # Prefer max_completion_tokens; many providers accept both.
        payload["max_completion_tokens"] = mt

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout_s) as resp:
                raw = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")
            raise LLMCompletionError(f"HTTP {e.code}: {detail}") from e

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise LLMCompletionError("Non-JSON response from LLM") from exc

        try:
            choice0 = data["choices"][0]
            message = choice0["message"]
            content = message["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMCompletionError(f"Unexpected LLM response shape: {raw[:500]}") from exc

        if not isinstance(content, str):
            raise LLMCompletionError("LLM returned non-string content")
        return content.strip()
