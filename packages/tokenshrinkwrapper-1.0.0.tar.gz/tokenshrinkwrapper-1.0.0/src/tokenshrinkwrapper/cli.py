from __future__ import annotations

from pathlib import Path

import typer

from tokenshrinkwrapper.compressor import benchmark_modes, estimate_tokens, shrink_text
from tokenshrinkwrapper.config import AppConfig, resolve_config
from tokenshrinkwrapper.llm import LLMCompletionError, OpenAICompatibleClient

app = typer.Typer(help="TokenShrinkWrapper CLI")


def _default_app_config() -> AppConfig:
    from tokenshrinkwrapper.config import DefaultSection, LLMSection

    return AppConfig(default=DefaultSection(), llm=LLMSection())


@app.command()
def shrink(
    input_file: Path = typer.Argument(..., exists=True, readable=True),
    output: Path | None = typer.Option(None, "--output", "-o"),
    mode: str | None = typer.Option(None, help="light | balanced | aggressive"),
    distill: bool = typer.Option(False, "--distill", help="Run LLM semantic distillation"),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        readable=True,
        help="Path to tokenshrink.toml",
    ),
) -> None:
    cfg = resolve_config(config) or _default_app_config()
    eff_mode = mode or cfg.default.mode
    source = input_file.read_text(encoding="utf-8")

    llm = None
    if distill:
        try:
            llm = OpenAICompatibleClient.from_env(cfg.llm)
        except LLMCompletionError as e:
            raise typer.BadParameter(str(e)) from e

    result = shrink_text(
        source,
        eff_mode,
        distill=distill,
        distill_prepass=cfg.default.distill_prepass,
        llm=llm,
        token_count_model=cfg.default.token_count_model,
        distill_max_completion_tokens=cfg.llm.max_completion_tokens,
        distill_temperature=cfg.llm.temperature,
    )

    if output:
        output.write_text(result.compressed_text, encoding="utf-8")
        typer.echo(f"Wrote compressed text to {output}")
    else:
        typer.echo(result.compressed_text)

    saved = result.token_count_before - result.token_count_after
    typer.echo(
        f"Tokens: {result.token_count_before} -> {result.token_count_after} "
        f"({saved} saved)"
    )


@app.command()
def stats(
    input_file: Path = typer.Argument(..., exists=True, readable=True),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        readable=True,
    ),
) -> None:
    cfg = resolve_config(config) or _default_app_config()
    source = input_file.read_text(encoding="utf-8")
    typer.echo(
        f"Estimated tokens ({cfg.default.token_count_model}): "
        f"{estimate_tokens(source, cfg.default.token_count_model)}"
    )


@app.command("benchmark")
def benchmark_cmd(
    input_file: Path = typer.Argument(..., exists=True, readable=True),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        readable=True,
    ),
) -> None:
    cfg = resolve_config(config) or _default_app_config()
    source = input_file.read_text(encoding="utf-8")
    rows = benchmark_modes(source, token_count_model=cfg.default.token_count_model)
    typer.echo(f"File: {input_file}")
    typer.echo(f"Token model for counting: {cfg.default.token_count_model}")
    typer.echo("mode\tbefore\tafter\tsaved\tratio")
    for mode_name, before, after, ratio in rows:
        saved = before - after
        typer.echo(f"{mode_name}\t{before}\t{after}\t{saved}\t{ratio:.3f}")


if __name__ == "__main__":
    app()
