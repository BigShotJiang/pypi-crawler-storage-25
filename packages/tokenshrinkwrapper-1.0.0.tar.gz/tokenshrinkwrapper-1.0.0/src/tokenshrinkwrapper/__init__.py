from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _distribution_version

from tokenshrinkwrapper.compressor import (
    CompressionResult,
    benchmark_modes,
    estimate_tokens,
    shrink_text,
)
from tokenshrinkwrapper.config import AppConfig, load_config_file, merge_app_config, resolve_config

try:
    __version__ = _distribution_version("tokenshrinkwrapper")
except PackageNotFoundError:
    __version__ = "0+unknown"

__all__ = [
    "AppConfig",
    "CompressionResult",
    "__version__",
    "benchmark_modes",
    "estimate_tokens",
    "load_config_file",
    "merge_app_config",
    "resolve_config",
    "shrink_text",
]
