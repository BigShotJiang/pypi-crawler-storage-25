from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

DEFAULT_CONFIG_FILENAMES = ("tokenshrink.toml",)


@dataclass(slots=True)
class DefaultSection:
    mode: str = "balanced"
    token_count_model: str = "gpt-4o-mini"
    distill_prepass: str = "light"  # none | light | caveman


@dataclass(slots=True)
class LLMSection:
    provider: str = "openai_compatible"
    model: str = "gpt-4o-mini"
    base_url: str = "https://api.openai.com/v1"
    api_key_env: str = "OPENAI_API_KEY"
    temperature: float = 0.0
    max_completion_tokens: int = 4096


@dataclass(slots=True)
class AppConfig:
    default: DefaultSection
    llm: LLMSection

    @staticmethod
    def llm_defaults() -> LLMSection:
        return LLMSection()


def _as_dict(section: dict[str, Any] | None) -> dict[str, Any]:
    return dict(section or {})


def merge_app_config(raw: dict[str, Any]) -> AppConfig:
    dd = DefaultSection()
    d = _as_dict(raw.get("default"))
    l = _as_dict(raw.get("llm"))
    return AppConfig(
        default=DefaultSection(
            mode=str(d.get("mode", dd.mode)),
            token_count_model=str(d.get("token_count_model", dd.token_count_model)),
            distill_prepass=str(d.get("distill_prepass", dd.distill_prepass)),
        ),
        llm=LLMSection(
            provider=str(l.get("provider", "openai_compatible")),
            model=str(l.get("model", "gpt-4o-mini")),
            base_url=str(l.get("base_url", "https://api.openai.com/v1")),
            api_key_env=str(l.get("api_key_env", "OPENAI_API_KEY")),
            temperature=float(l.get("temperature", 0)),
            max_completion_tokens=int(l.get("max_completion_tokens", 4096)),
        ),
    )


def load_config_file(path: Path) -> AppConfig:
    import tomllib

    data = tomllib.loads(path.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    return merge_app_config(data)


def resolve_config(
    explicit: Path | None,
    search_from: Path | None = None,
) -> AppConfig | None:
    """Locate tokenshrink.toml walking up from search_from/cwd if explicit unset."""

    paths: list[Path] = []
    if explicit is not None:
        paths.append(explicit)
    else:
        start = (search_from or Path.cwd()).resolve()
        for parent in [start] + list(start.parents):
            for name in DEFAULT_CONFIG_FILENAMES:
                cand = parent / name
                if cand.is_file():
                    return load_config_file(cand)
        return None

    for p in paths:
        if p.is_file():
            return load_config_file(p)
    raise FileNotFoundError(str(paths[0]))
