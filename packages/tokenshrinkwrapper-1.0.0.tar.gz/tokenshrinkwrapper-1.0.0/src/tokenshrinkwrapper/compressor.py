from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Sequence

import tiktoken

from tokenshrinkwrapper.llm.base import ChatMessage

if TYPE_CHECKING:
    from tokenshrinkwrapper.llm.base import LLMClient

# Prose aggressive line sampling keeps at most this fraction (lower = denser extraction).
_AGGRESSIVE_EXTRACT_RATIO = 0.25

_STOP_WORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "that",
    "the",
    "this",
    "to",
    "was",
    "were",
    "with",
}

SEMANTIC_DISTILL_SYSTEM = """You are a context compressor for LLM inputs.
Rewrite the user's text to use fewer tokens while preserving meaning and utility.

Rules:
- Keep facts, decisions, constraints, names, numbers, file paths, and APIs.
- For code-like content: remove comments and optional type noise when safe; keep control flow, function/class names, signatures, and important literals.
- Prefer short imperatives over narrative; drop filler and redundancy.
- Do not prepend explanations; output ONLY the distilled text.
""".strip()


@dataclass(slots=True)
class CompressionResult:
    original_text: str
    compressed_text: str
    token_count_before: int
    token_count_after: int


def estimate_tokens(text: str, model: str = "gpt-4o-mini") -> int:
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        encoding = tiktoken.get_encoding("cl100k_base")
    return len(encoding.encode(text))


def _normalize_whitespace(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _drop_markdown_headers(text: str) -> str:
    lines = text.splitlines()
    kept = [line for line in lines if not line.lstrip().startswith("#")]
    return "\n".join(kept)


def _caveman_pass(text: str) -> str:
    words = re.findall(r"[A-Za-z0-9_']+|[^\w\s]", text)
    reduced = [w for w in words if w.lower() not in _STOP_WORDS]
    merged = " ".join(reduced)
    merged = re.sub(r"\s+([.,!?;:])", r"\1", merged)
    return _normalize_whitespace(merged)


def _extractive_pass(text: str, keep_ratio: float = 0.5) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        return ""

    keep_count = max(1, int(len(lines) * keep_ratio))
    scored = sorted(lines, key=len, reverse=True)
    kept = scored[:keep_count]
    return "\n".join(kept)


_FENCE_OPEN = re.compile(r"^[ \t]*```")

# ``#`` lines that must not be stripped (directives / tooling headers). Non-VERBOSE
# avoids ``#`` in patterns being parsed as regex comments (``re.VERBOSE``).
_HASH_LINE_KEEP_RE = re.compile(
    r"^#\s*("
    r"(?:!\s*)?include\b|define\b|ifdef\b|ifndef\b|elifdef\b|elifndef\b|elif\b|else\b|endif\b|if\b|"
    r"pragma\b|undef\b|error\b|warning\b|line\b|"
    r"-\*-\s*.+coding:|\s*coding\s*[=:]|"
    r"frozen_string_literal\b|type\s*:"
    r")",
    re.IGNORECASE,
)


def _split_fenced_segments(text: str) -> list[tuple[bool, str]]:
    """Split into alternating (is_code, segment) excluding ``` fence lines."""

    lines = text.splitlines(keepends=True)
    parts: list[tuple[bool, str]] = []
    buf: list[str] = []
    in_code = False

    def flush() -> None:
        if buf:
            parts.append((in_code, "".join(buf)))
            buf.clear()

    for line in lines:
        if _FENCE_OPEN.match(line):
            flush()
            in_code = not in_code
            continue
        buf.append(line)
    flush()
    return parts


def _looks_like_plain_source(text: str) -> bool:
    """Heuristic: undelimited blobs that resemble source modules (avoid mangling naked .py, etc.)."""

    if "```" in text:
        return False
    tail = text.lstrip()
    if tail.startswith("#!"):
        return True

    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) < 3:
        return False

    first = lines[0].lstrip()
    cpp_or_tool_header = (
        first.startswith("#include")
        or (first.startswith("#") and _HASH_LINE_KEEP_RE.match(first) is not None)
    )
    if not (
        cpp_or_tool_header
        or first.startswith(
            (
                "def ",
                "class ",
                "import ",
                "from ",
                "use ",
                "pub ",
                "fn ",
                "const ",
                "let ",
                "interface ",
                "enum ",
                "package ",
                "module ",
            )
        )
    ):
        return False

    sample = lines[:120]
    codeish = sum(
        1
        for ln in sample
        if ln.strip().endswith(":") or re.search(r"[():={}\[\],;]", ln)
    )
    directive_lines = sum(
        1
        for ln in sample
        if ln.strip() and ln.lstrip().startswith("#") and _HASH_LINE_KEEP_RE.match(ln.lstrip())
    )
    codeish += directive_lines

    threshold = max(3, len(sample) // 5)
    if cpp_or_tool_header and len(lines) <= 120:
        threshold = max(2, threshold - 2)

    return codeish >= threshold


def _segment_document(text: str) -> list[tuple[str, str]]:
    """Return (segment_kind, chunk) pairs: ``code`` or ``prose``."""

    if not text:
        return []
    parts = _split_fenced_segments(text)
    if (
        len(parts) == 1
        and not parts[0][0]
        and _looks_like_plain_source(parts[0][1])
    ):
        return [("code", parts[0][1])]
    out: list[tuple[str, str]] = []
    for is_code, chunk in parts:
        out.append(("code", chunk) if is_code else ("prose", chunk))
    return out


def _full_line_inline_block_comment(line: str) -> bool:
    s = line.strip()
    return bool(s.startswith("/*") and s.endswith("*/") and len(s) > 4)


def _is_skippable_code_comment(line: str, lineno: int) -> bool:
    if lineno == 0 and line.lstrip().startswith("#!"):
        return False
    if _full_line_inline_block_comment(line):
        return True
    s = line.lstrip()
    if s.startswith("//"):
        return True
    if s.startswith("#"):
        return _HASH_LINE_KEEP_RE.match(s) is None
    return False


def _collapse_code_blank_runs(lines: list[str], max_consecutive_blank: int) -> list[str]:
    out: list[str] = []
    blanks = 0
    for line in lines:
        if not line.strip():
            blanks += 1
            if blanks <= max_consecutive_blank:
                out.append("")
            continue
        blanks = 0
        out.append(line.rstrip())
    return out


def _process_code(text: str, mode: str) -> str:
    if not text:
        return ""
    mode = mode.strip().lower()
    keepends_nl = text.endswith("\n") or text.endswith("\r\n")
    raw = text.splitlines()

    if mode == "light":
        max_blank = 3
    elif mode == "balanced":
        max_blank = 2
    else:
        max_blank = 1

    kept: list[str] = []
    for i, line in enumerate(raw):
        if line.strip() == "":
            kept.append("")
            continue
        if _is_skippable_code_comment(line, i):
            continue
        kept.append(line.rstrip())

    trimmed = _collapse_code_blank_runs(kept, max_blank)
    joiner = "\r\n" if "\r\n" in text else "\n"
    body = joiner.join(trimmed).strip("\r\n")
    if keepends_nl and body:
        body += joiner
    return body


def _prose_light(text: str) -> str:
    if not text:
        return ""
    return _normalize_whitespace(_drop_markdown_headers(text))


def _process_prose(text: str, mode: str) -> str:
    if not text:
        return ""
    mode = mode.strip().lower()
    current = text
    if mode in {"light", "balanced", "aggressive"}:
        current = _drop_markdown_headers(current)
        current = _normalize_whitespace(current)

    if mode in {"balanced", "aggressive"}:
        current = _caveman_pass(current)

    if mode == "aggressive":
        current = _extractive_pass(current, keep_ratio=_AGGRESSIVE_EXTRACT_RATIO)

    return current


def _apply_distill_prepass(text: str, prepass: str) -> str:
    """Cheap token reduction before an LLM distillation step."""

    prepass = prepass.strip().lower()
    if prepass in {"none", ""}:
        return text
    if prepass == "light":
        segs = _segment_document(text)
        chunks: list[str] = []
        for kind, chunk in segs:
            chunks.append(_process_code(chunk, "light") if kind == "code" else _prose_light(chunk))
        return "".join(chunks)
    if prepass == "caveman":
        segs = _segment_document(text)
        chunks = []
        for kind, chunk in segs:
            if kind == "code":
                chunks.append(_process_code(chunk, "balanced"))
                continue
            pl = _prose_light(chunk)
            chunks.append(_caveman_pass(pl) if pl else "")
        return "".join(chunks)
    raise ValueError(f"Unknown distill_prepass: {prepass!r} (expected none|light|caveman)")


def _pipeline_local(text: str, mode: str) -> str:
    mode = mode.strip().lower()
    if mode not in {"light", "balanced", "aggressive"}:
        raise ValueError(f"Unknown shrink mode: {mode!r} (expected light|balanced|aggressive)")
    chunks: list[str] = []
    for kind, segment in _segment_document(text):
        if kind == "code":
            chunks.append(_process_code(segment, mode))
        else:
            chunks.append(_process_prose(segment, mode))
    return "".join(chunks)


def semantic_distill(
    text: str,
    llm: LLMClient,
    *,
    max_completion_tokens: int | None = None,
    temperature: float | None = None,
) -> str:
    messages: list[ChatMessage] = [
        ChatMessage("system", SEMANTIC_DISTILL_SYSTEM),
        ChatMessage("user", text),
    ]
    return llm.complete(messages, max_tokens=max_completion_tokens, temperature=temperature)


def shrink_text(
    text: str,
    mode: str = "balanced",
    *,
    distill: bool = False,
    distill_prepass: str = "light",
    llm: LLMClient | None = None,
    token_count_model: str = "gpt-4o-mini",
    distill_max_completion_tokens: int | None = None,
    distill_temperature: float | None = None,
) -> CompressionResult:
    """Shrink context text locally and/or via LLM semantic distillation.

    Local compression separates Markdown fenced code blocks (triple-backtick fences) and
    heuristic stand-alone source blobs from surrounding prose so code keeps syntax while prose
    is compressed harder.

    When ``distill`` is True, ``llm`` must be provided. Pipeline:

    1. Optional prepass on the original (none/light/caveman) to shrink LLM input cost.
    2. LLM semantic distill on the prepass output.
    3. Token counts compare the original ``text`` vs final compressed output.
    """

    original = text

    if distill:
        if llm is None:
            raise ValueError("distill=True requires an llm client")
        prepped = _apply_distill_prepass(original, distill_prepass)
        compressed = semantic_distill(
            prepped,
            llm,
            max_completion_tokens=distill_max_completion_tokens,
            temperature=distill_temperature,
        )
    else:
        compressed = _pipeline_local(original, mode)

    return CompressionResult(
        original_text=original,
        compressed_text=compressed,
        token_count_before=estimate_tokens(original, token_count_model),
        token_count_after=estimate_tokens(compressed, token_count_model),
    )


def benchmark_modes(
    text: str,
    *,
    modes: Sequence[str] = ("light", "balanced", "aggressive"),
    token_count_model: str = "gpt-4o-mini",
) -> list[tuple[str, int, int, float]]:
    """Return rows: (mode, before, after, ratio_after_per_before)."""

    before = estimate_tokens(text, token_count_model)
    rows: list[tuple[str, int, int, float]] = []
    for m in modes:
        out = _pipeline_local(text, m)
        after = estimate_tokens(out, token_count_model)
        ratio = (after / before) if before else 0.0
        rows.append((m, before, after, ratio))
    return rows
