from tokenshrinkwrapper import benchmark_modes, estimate_tokens, shrink_text


def test_estimate_tokens_returns_int() -> None:
    value = estimate_tokens("hello world")
    assert isinstance(value, int)
    assert value > 0


def test_shrink_text_reduces_or_keeps_tokens() -> None:
    source = """
    # Header
    This is a simple context file with some repeated wording.
    This is a simple context file with some repeated wording.
    """
    result = shrink_text(source, mode="balanced")
    assert result.token_count_after <= result.token_count_before
    assert len(result.compressed_text) > 0


def test_benchmark_modes_rows() -> None:
    source = "# H\na\nb\nc\n"
    rows = benchmark_modes(source)
    assert len(rows) == 3
    assert {r[0] for r in rows} == {"light", "balanced", "aggressive"}


def test_fenced_code_keeps_syntax() -> None:
    source = """Narrative text with repetitive filler sentences about the fox.
```python
# setup note
for i in range(2):
    total = total + i
```
"""
    out = shrink_text(source, mode="aggressive").compressed_text
    assert "for i in range" in out
    assert "total" in out


def test_plain_python_without_fences_keeps_syntax() -> None:
    source = '''import math

def bump(x):
    return x + 1
'''

    compressed = shrink_text(source, mode="aggressive").compressed_text
    assert "import math" in compressed
    assert "def bump" in compressed
    assert "return x + 1" in compressed


def test_plain_comment_removed_define_kept() -> None:
    source = "#include<stdio.h>\n#define XY 41\nextern int xy;\nint main(void);\n"
    compressed = shrink_text(source, mode="balanced").compressed_text
    assert "#define XY" in compressed
    assert "extern int xy" in compressed
