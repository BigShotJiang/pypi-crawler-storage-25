from tokenshrinkwrapper.compressor import shrink_text


class FakeLLM:
    def complete(
        self,
        messages: list,
        *,
        max_tokens=None,
        temperature=None,
    ) -> str:
        user = next(m.content for m in messages if m.role == "user")
        return f"DISTILLED::{user[:200]}"


def test_shrink_with_distill_uses_llm() -> None:
    source = (
        "# Long context\n\n"
        + "The quick brown fox jumps over the lazy dog. " * 80
        + "\n"
    )
    result = shrink_text(
        source,
        mode="balanced",
        distill=True,
        distill_prepass="light",
        llm=FakeLLM(),
    )
    assert result.compressed_text.startswith("DISTILLED::")
    assert result.token_count_after < result.token_count_before


def test_distill_requires_llm() -> None:
    try:
        shrink_text("hello", distill=True, llm=None)
        raise AssertionError("expected ValueError")
    except ValueError:
        pass
