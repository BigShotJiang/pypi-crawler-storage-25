from pathlib import Path

from typer.testing import CliRunner

from tokenshrinkwrapper.cli import app


def test_stats_command(tmp_path: Path) -> None:
    runner = CliRunner()
    target = tmp_path / "sample.txt"
    target.write_text("hello world", encoding="utf-8")

    result = runner.invoke(app, ["stats", str(target)])

    assert result.exit_code == 0
    assert "Estimated tokens" in result.output


def test_benchmark_command(tmp_path: Path) -> None:
    runner = CliRunner()
    target = tmp_path / "ctx.txt"
    target.write_text("# T\nhello world\n", encoding="utf-8")
    result = runner.invoke(app, ["benchmark", str(target)])
    assert result.exit_code == 0
    assert "light" in result.output
