from pathlib import Path

from tokenshrinkwrapper.config import load_config_file, merge_app_config, resolve_config


def test_merge_app_defaults() -> None:
    cfg = merge_app_config({})
    assert cfg.default.mode == "balanced"
    assert cfg.llm.model == "gpt-4o-mini"


def test_load_example_config(tmp_path: Path) -> None:
    p = tmp_path / "tokenshrink.toml"
    p.write_text(
        '[default]\nmode = "aggressive"\ntoken_count_model = "gpt-4o-mini"\n'
        '[llm]\nmodel = "gpt-4.1-mini"\n',
        encoding="utf-8",
    )
    cfg = load_config_file(p)
    assert cfg.default.mode == "aggressive"
    assert cfg.llm.model == "gpt-4.1-mini"


def test_resolve_explicit(tmp_path: Path) -> None:
    p = tmp_path / "tokenshrink.toml"
    p.write_text('[default]\nmode = "light"\n', encoding="utf-8")
    cfg = resolve_config(p)
    assert cfg is not None
    assert cfg.default.mode == "light"
