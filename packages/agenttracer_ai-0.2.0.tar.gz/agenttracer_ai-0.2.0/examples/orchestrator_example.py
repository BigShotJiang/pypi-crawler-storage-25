"""Example: Orchestrator pattern with fork/merge subagent branches.

Demonstrates how to trace a multi-agent orchestrator that:
1. Receives a user query
2. Forks into parallel subagents (search, analysis, writing)
3. Each subagent does its own work with LLM calls and tool calls
4. Results merge back into a final response

Run:
    pip install agenttracer-ai
    python orchestrator_example.py
    # Then visit http://127.0.0.1:8484 and click the trace to see the graph view
"""

import time
import random
import agenttracer as at

tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def simulate_delay(low=0.1, high=0.5):
    """Simulate work with a random delay."""
    time.sleep(random.uniform(low, high))


def run_search_agent(trace, fork_span):
    """Simulates a search subagent that queries multiple sources."""
    sub = tracer.log_subagent(
        trace,
        subagent_name="search-agent",
        fork_span=fork_span,
        input_data={"query": "latest AI benchmarks 2026"},
    )

    # The search agent makes an LLM call to plan queries
    tracer.log_model_call(
        trace,
        model="gpt-4o-mini",
        input_data="Generate 3 search queries for: latest AI benchmarks 2026",
        output_data="1. 'AI benchmark results 2026'\n2. 'LLM leaderboard 2026'\n3. 'MMLU scores 2026'",
        parent=sub,
    )
    simulate_delay()

    # It calls a search tool
    tracer.log_tool_call(
        trace,
        tool_name="web_search",
        tool_args={"query": "AI benchmark results 2026"},
        tool_result={"results": ["Result 1: GPT-5 tops ...", "Result 2: Claude 4 ..."]},
        parent=sub,
    )
    simulate_delay()

    tracer.log_tool_call(
        trace,
        tool_name="web_search",
        tool_args={"query": "LLM leaderboard 2026"},
        tool_result={"results": ["Leaderboard shows ...", "Top models include ..."]},
        parent=sub,
    )
    simulate_delay()

    tracer.end_span(sub, output_data={
        "sources": 4,
        "summary": "Found 4 relevant sources on 2026 AI benchmarks.",
    })
    return sub


def run_analysis_agent(trace, fork_span):
    """Simulates an analysis subagent that processes data."""
    sub = tracer.log_subagent(
        trace,
        subagent_name="analysis-agent",
        fork_span=fork_span,
        input_data={"task": "Compare model performance across benchmarks"},
    )

    # Calls an LLM to analyze data
    tracer.log_model_call(
        trace,
        model="claude-sonnet-4-20250514",
        input_data="Analyze the following benchmark data and identify trends...",
        output_data="Key findings: 1) Reasoning tasks improved 23%...",
        parent=sub,
    )
    simulate_delay(0.2, 0.7)

    # Uses a code execution tool
    tracer.log_tool_call(
        trace,
        tool_name="code_interpreter",
        tool_args={"code": "import pandas as pd\n# Generate comparison chart..."},
        tool_result={"chart_url": "/charts/benchmark_comparison.png"},
        parent=sub,
    )
    simulate_delay()

    tracer.end_span(sub, output_data={
        "insights": 3,
        "summary": "Identified 3 key trends in 2026 AI benchmarks.",
    })
    return sub


def run_writing_agent(trace, fork_span):
    """Simulates a writing subagent that drafts the response."""
    sub = tracer.log_subagent(
        trace,
        subagent_name="writing-agent",
        fork_span=fork_span,
        input_data={"task": "Draft a comprehensive summary"},
    )

    # Planning step
    step = tracer.log_step(
        trace,
        name="outline",
        input_data="Create outline for benchmark summary",
        output_data="1. Introduction\n2. Key Results\n3. Trends\n4. Conclusion",
        parent=sub,
    )
    tracer.end_span(step)
    simulate_delay()

    # Drafting with an LLM
    tracer.log_model_call(
        trace,
        model="gpt-4o",
        input_data="Write a comprehensive summary of 2026 AI benchmarks...",
        output_data="# 2026 AI Benchmark Report\n\nThe AI landscape in 2026...",
        parent=sub,
    )
    simulate_delay(0.3, 0.8)

    tracer.end_span(sub, output_data={
        "word_count": 450,
        "summary": "Drafted 450-word benchmark report.",
    })
    return sub


def main():
    """Run the orchestrator example."""
    print("Running orchestrator example...\n")

    # Start the main trace
    trace = tracer.start_trace(
        agent_name="orchestrator",
        input_data={"user_query": "Give me a comprehensive summary of the latest AI benchmarks"},
        tags=["demo", "multi-agent"],
    )

    # Step 1: Orchestrator plans the approach
    plan_step = tracer.log_step(
        trace,
        name="planning",
        input_data="User wants AI benchmark summary",
        output_data="Will fork into: search, analysis, writing agents",
    )
    tracer.end_span(plan_step)
    simulate_delay()

    # Step 2: Decision on strategy
    tracer.log_decision(
        trace,
        name="execution_strategy",
        options=["sequential", "parallel", "hierarchical"],
        chosen="parallel",
        reasoning="Subagents can work independently; parallel is fastest.",
    )

    # Step 3: Fork into parallel branches
    fork = tracer.log_fork(
        trace,
        name="parallel_research",
        branches=["search-agent", "analysis-agent", "writing-agent"],
    )

    print("  Forked into 3 parallel subagents...")

    # Step 4: Run subagents (in a real system these would be concurrent)
    search_sub = run_search_agent(trace, fork)
    print("  search-agent complete")

    analysis_sub = run_analysis_agent(trace, fork)
    print("  analysis-agent complete")

    writing_sub = run_writing_agent(trace, fork)
    print("  writing-agent complete")

    # Step 5: Merge results back
    merge = tracer.log_merge(
        trace,
        name="combine_results",
        fork_span=fork,
        source_spans=[search_sub, analysis_sub, writing_sub],
        output_data={
            "search_sources": 4,
            "insights": 3,
            "draft_words": 450,
            "status": "all branches completed successfully",
        },
    )
    print("  Merged results from all subagents")

    # Step 6: Final LLM call to polish
    tracer.log_model_call(
        trace,
        model="gpt-4o",
        input_data="Polish and finalize the benchmark report using all gathered data...",
        output_data="# 2026 AI Benchmark Report (Final)\n\nThis comprehensive report...",
    )
    simulate_delay()

    # End the trace
    tracer.end_trace(
        trace,
        output_data="Final polished benchmark report delivered.",
    )

    print(f"\n  Trace ID: {trace.trace_id}")
    print(f"  Duration: {trace.duration_ms:.0f}ms")
    print(f"  Total tokens: {trace.total_tokens}")
    print(f"  Total cost: ${trace.total_cost:.6f}")
    print(f"  Steps: {trace.total_steps}")

    # Launch dashboard
    print("\n  Launching dashboard — open http://127.0.0.1:8484")
    print("  Click the trace, then switch to the 'Graph' tab to see the DAG view.\n")
    at.dashboard(storage_dir="./agenttracer_data")


if __name__ == "__main__":
    main()
