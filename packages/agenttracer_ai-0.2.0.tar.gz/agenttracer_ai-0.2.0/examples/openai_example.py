"""Example: Tracing real OpenAI API calls.

Requires: pip install openai
Set OPENAI_API_KEY environment variable.

Run:
    export OPENAI_API_KEY=sk-...
    python examples/openai_example.py
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at
from agenttracer.integrations.openai_wrapper import patch_openai

tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def run():
    try:
        import openai
    except ImportError:
        print("Install openai: pip install openai")
        return

    if not os.environ.get("OPENAI_API_KEY"):
        print("Set OPENAI_API_KEY environment variable")
        return

    trace = tracer.start_trace("openai-agent", tags=["openai", "demo"])

    # Patch the client — all calls are now auto-traced
    client = patch_openai(openai.OpenAI(), tracer, trace)

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant. Be concise."},
                {"role": "user", "content": "Explain quantum entanglement in one sentence."},
            ],
            temperature=0.7,
        )

        output = response.choices[0].message.content
        print(f"Response: {output}")

        tracer.end_trace(trace, output_data=output)
        print(f"\nTrace: {trace.trace_id}")
        print(f"Tokens: {trace.total_tokens} | Cost: ${trace.total_cost:.6f}")

    except Exception as e:
        tracer.end_trace(trace, error=str(e))
        print(f"Error: {e}")


if __name__ == "__main__":
    print("🤖 AgentTracer — OpenAI Integration Example\n")
    run()
