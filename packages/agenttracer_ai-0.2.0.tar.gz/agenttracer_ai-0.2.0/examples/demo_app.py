"""Demo app: Generates sample traces and launches the dashboard.

This is the easiest way to see AgentTracer in action.

Run:
    python examples/demo_app.py
"""

import time
import random
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at

tracer = at.AgentTracer(storage_dir="./agenttracer_data")

MODELS = ["gpt-4o", "gpt-4o-mini", "claude-3.5-sonnet", "claude-3.5-haiku", "gemini-2.0-flash"]
TOOLS = ["web_search", "calculator", "weather_api", "database_query", "file_reader", "code_executor"]
AGENTS = ["research-bot", "coding-assistant", "data-analyst", "customer-support", "planner-agent"]
TOPICS = [
    "Explain quantum computing",
    "Write a Python function to sort a list",
    "What's the weather in Tokyo?",
    "Analyze Q3 revenue data",
    "Plan a trip to Iceland",
    "Debug this SQL query",
    "Summarize this research paper",
    "Find competitors in the AI space",
    "Create a marketing plan",
    "Optimize database performance",
]


def generate_trace():
    """Generate a realistic-looking trace with varied spans."""
    agent = random.choice(AGENTS)
    topic = random.choice(TOPICS)
    has_error = random.random() < 0.15  # 15% error rate
    num_steps = random.randint(2, 6)

    trace = tracer.start_trace(
        agent_name=agent,
        input_data=topic,
        tags=random.sample(["production", "staging", "v2", "experiment", "demo"], k=random.randint(1, 3)),
        metadata={"version": f"1.{random.randint(0, 5)}", "user_id": f"user_{random.randint(1, 100)}"},
    )

    parent_span = None

    for i in range(num_steps):
        step_type = random.choice(["model", "tool", "decision", "step"])

        if step_type == "model":
            model = random.choice(MODELS)
            prompt_len = random.randint(50, 2000)
            completion_len = random.randint(20, 1500)

            span = tracer.log_model_call(
                trace,
                model=model,
                input_data=[{"role": "user", "content": "x" * prompt_len}],
                output_data="y" * completion_len,
                token_usage={
                    "prompt_tokens": prompt_len // 4,
                    "completion_tokens": completion_len // 4,
                    "total_tokens": (prompt_len + completion_len) // 4,
                },
                temperature=random.choice([0.0, 0.3, 0.7, 1.0]),
                parent=parent_span,
            )
            time.sleep(random.uniform(0.01, 0.05))
            parent_span = span if random.random() < 0.3 else None

        elif step_type == "tool":
            tool = random.choice(TOOLS)
            span = tracer.log_tool_call(
                trace,
                tool_name=tool,
                tool_args={"query": topic, "limit": random.randint(5, 50)},
                tool_result={"status": "ok", "results": random.randint(1, 20)},
                parent=parent_span,
                error="Connection timeout" if (has_error and i == num_steps - 1) else None,
            )
            time.sleep(random.uniform(0.01, 0.03))

        elif step_type == "decision":
            options = random.sample(["continue", "stop", "retry", "escalate", "branch_a", "branch_b"], k=3)
            tracer.log_decision(
                trace,
                name=random.choice(["routing", "tool_selection", "response_style", "retry_check"]),
                options=options,
                chosen=random.choice(options),
                reasoning=f"Based on previous step results (step {i})",
                parent=parent_span,
            )

        else:
            span = tracer.log_step(
                trace,
                name=random.choice(["preprocessing", "validation", "formatting", "caching", "logging"]),
                input_data={"step": i, "context": "..."},
                output_data={"processed": True},
                parent=parent_span,
            )
            tracer.end_span(span)

    # End trace
    if has_error:
        tracer.end_trace(trace, error="Agent encountered an unrecoverable error")
    else:
        tracer.end_trace(trace, output_data=f"Completed task: {topic}")

    return trace


def main():
    print("🎯 AgentTracer Demo — Generating sample traces...\n")

    num_traces = 25
    for i in range(num_traces):
        t = generate_trace()
        status = "✅" if t.status.value == "success" else "❌"
        print(f"  {status} {t.agent_name:20s} | {t.duration_ms:6.0f}ms | "
              f"{t.total_tokens:5d} tokens | ${t.total_cost:.4f} | {t.trace_id}")

    print(f"\n  Generated {num_traces} traces in ./agenttracer_data/")
    print(f"\n  Launching dashboard...\n")

    at.dashboard(storage_dir="./agenttracer_data", port=8484)


if __name__ == "__main__":
    main()
