"""Basic example: A simple agent traced with AgentTracer.

Run:
    python examples/basic_agent.py
    python -m agenttracer.dashboard  # then open http://localhost:8484
"""

import time
import random
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at

# Create a tracer
tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def fake_llm_call(prompt: str, model: str = "gpt-4o") -> str:
    """Simulate an LLM call with realistic latency."""
    time.sleep(random.uniform(0.1, 0.5))
    responses = {
        "What's the weather?": "I'll check the weather for you using the weather tool.",
        "search": "Based on the search results, here's what I found...",
        "summarize": "Here's a concise summary of the information gathered.",
    }
    for key, response in responses.items():
        if key.lower() in prompt.lower():
            return response
    return f"I've processed your request: {prompt[:50]}..."


def fake_tool_call(name: str, args: dict) -> str:
    """Simulate a tool call."""
    time.sleep(random.uniform(0.05, 0.2))
    if name == "weather":
        return '{"temp": 72, "condition": "sunny", "location": "San Francisco"}'
    if name == "search":
        return '{"results": [{"title": "Result 1", "url": "https://example.com"}]}'
    return f'{{"result": "Executed {name} successfully"}}'


def run_agent(user_input: str):
    """Run a simple agent loop with tracing."""

    # Start a trace
    trace = tracer.start_trace(
        agent_name="weather-assistant",
        input_data=user_input,
        tags=["demo", "weather"],
        metadata={"version": "1.0", "environment": "development"},
    )

    try:
        # Step 1: Understand the user's request
        step1 = tracer.log_step(trace, "understand_request", input_data=user_input)

        # Model call to understand intent
        response = fake_llm_call(user_input)
        tracer.log_model_call(
            trace,
            model="gpt-4o",
            input_data=[{"role": "user", "content": user_input}],
            output_data=response,
            temperature=0.7,
            parent=step1,
        )
        tracer.end_span(step1, output_data={"intent": "weather_query"})

        # Step 2: Decide which tool to use
        tracer.log_decision(
            trace,
            name="tool_selection",
            options=["weather", "search", "calculator", "none"],
            chosen="weather",
            reasoning="User is asking about weather conditions",
        )

        # Step 3: Call the tool
        tool_result = fake_tool_call("weather", {"location": "San Francisco"})
        tracer.log_tool_call(
            trace,
            tool_name="weather",
            tool_args={"location": "San Francisco"},
            tool_result=tool_result,
        )

        # Step 4: Generate final response
        step4 = tracer.log_step(trace, "generate_response", input_data=tool_result)
        final_response = fake_llm_call("summarize the weather data")
        tracer.log_model_call(
            trace,
            model="gpt-4o",
            input_data=[
                {"role": "system", "content": "Summarize this weather data for the user."},
                {"role": "user", "content": tool_result},
            ],
            output_data=final_response,
            temperature=0.3,
            parent=step4,
        )
        tracer.end_span(step4, output_data=final_response)

        # End trace successfully
        tracer.end_trace(trace, output_data=final_response)
        print(f"✅ Agent completed: {final_response}")
        print(f"   Trace ID: {trace.trace_id}")
        print(f"   Duration: {trace.duration_ms:.0f}ms")
        print(f"   Tokens: {trace.total_tokens}")
        print(f"   Cost: ${trace.total_cost:.6f}")

    except Exception as e:
        tracer.end_trace(trace, error=str(e))
        print(f"❌ Agent failed: {e}")


if __name__ == "__main__":
    print("🔍 AgentTracer — Basic Example\n")
    run_agent("What's the weather in San Francisco?")
    print()
    run_agent("Search for the latest AI news")
    print()
    print("Run the dashboard to inspect traces:")
    print("  python -m agenttracer.dashboard")
