"""Multi-step agent example with nested spans, branching, and error handling.

Simulates a research agent that:
1. Plans a research strategy
2. Searches multiple sources in parallel
3. Synthesizes findings
4. Handles errors gracefully

Run:
    python examples/multi_step_agent.py
"""

import time
import random
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at

tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def simulate_llm(prompt: str, model: str = "gpt-4o") -> str:
    time.sleep(random.uniform(0.1, 0.3))
    return f"[LLM response to: {prompt[:60]}...]"


def simulate_search(query: str) -> list[dict]:
    time.sleep(random.uniform(0.1, 0.4))
    if "error" in query.lower():
        raise RuntimeError(f"Search API error for query: {query}")
    return [
        {"title": f"Result for '{query}' #{i}", "url": f"https://example.com/{i}"}
        for i in range(3)
    ]


def run_research_agent(topic: str):
    """Run a multi-step research agent."""

    with tracer.trace("research-agent", input_data=topic, tags=["research", "demo"]) as trace:

        # Step 1: Plan research strategy
        with tracer.span(trace, "planning") as plan_span:
            plan_response = simulate_llm(f"Create a research plan for: {topic}")
            tracer.log_model_call(
                trace,
                model="gpt-4o",
                input_data=[{"role": "user", "content": f"Plan research for: {topic}"}],
                output_data=plan_response,
                parent=plan_span,
            )

            # Decide on search strategy
            tracer.log_decision(
                trace,
                name="search_strategy",
                options=["broad_search", "targeted_search", "academic_search"],
                chosen="targeted_search",
                reasoning="Topic is specific enough for targeted queries",
                parent=plan_span,
            )
            plan_span.output_data = {"strategy": "targeted_search", "queries": 3}

        # Step 2: Execute searches
        with tracer.span(trace, "search_phase") as search_span:
            queries = [
                f"{topic} latest developments",
                f"{topic} research papers 2024",
                f"{topic} expert opinions",
            ]
            all_results = []

            for query in queries:
                try:
                    results = simulate_search(query)
                    tracer.log_tool_call(
                        trace,
                        tool_name="web_search",
                        tool_args={"query": query},
                        tool_result=results,
                        parent=search_span,
                    )
                    all_results.extend(results)
                except Exception as e:
                    tracer.log_tool_call(
                        trace,
                        tool_name="web_search",
                        tool_args={"query": query},
                        error=str(e),
                        parent=search_span,
                    )

            search_span.output_data = {"total_results": len(all_results)}

        # Step 3: Decide if we need more research
        needs_more = random.choice([True, False])
        tracer.log_decision(
            trace,
            name="sufficiency_check",
            options=["sufficient", "need_more_data", "need_expert_review"],
            chosen="sufficient" if not needs_more else "need_more_data",
            reasoning=f"Found {len(all_results)} results, "
                     + ("which is enough" if not needs_more else "but need deeper analysis"),
        )

        # Step 4: Optional deep-dive
        if needs_more:
            with tracer.span(trace, "deep_dive") as deep_span:
                deep_response = simulate_llm(f"Analyze these results about {topic} in depth")
                tracer.log_model_call(
                    trace,
                    model="claude-3.5-sonnet",
                    provider="anthropic",
                    input_data=[{"role": "user", "content": f"Deep analysis of {topic}"}],
                    output_data=deep_response,
                    parent=deep_span,
                )
                deep_span.output_data = deep_response

        # Step 5: Synthesize
        with tracer.span(trace, "synthesis") as synth_span:
            synthesis = simulate_llm(f"Synthesize all findings about {topic}")
            tracer.log_model_call(
                trace,
                model="gpt-4o",
                input_data=[{
                    "role": "user",
                    "content": f"Synthesize {len(all_results)} results about {topic}",
                }],
                output_data=synthesis,
                parent=synth_span,
            )
            synth_span.output_data = synthesis

        trace.output_data = synthesis
        print(f"✅ Research complete: {trace.trace_id}")
        print(f"   Steps: {trace.total_steps} | "
              f"Models: {trace.total_model_calls} | "
              f"Tools: {trace.total_tool_calls}")


if __name__ == "__main__":
    print("🔬 AgentTracer — Multi-Step Research Agent\n")
    run_research_agent("Quantum computing applications in drug discovery")
    print()
    run_research_agent("AI alignment approaches 2025")
    print()
    print("Run the dashboard: python -m agenttracer.dashboard")
