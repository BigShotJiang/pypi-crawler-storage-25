"""Example: Tracing LangChain / LangGraph agents.

Requires: pip install langchain langchain-openai
Set OPENAI_API_KEY environment variable.

Run:
    export OPENAI_API_KEY=sk-...
    python examples/langchain_example.py
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at
from agenttracer.integrations.langchain_callback import AgentTracerCallback

tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def run():
    try:
        from langchain_openai import ChatOpenAI
        from langchain_core.prompts import ChatPromptTemplate
        from langchain_core.output_parsers import StrOutputParser
    except ImportError:
        print("Install: pip install langchain langchain-openai")
        return

    if not os.environ.get("OPENAI_API_KEY"):
        print("Set OPENAI_API_KEY environment variable")
        return

    trace = tracer.start_trace("langchain-agent", tags=["langchain", "demo"])
    callback = AgentTracerCallback(tracer, trace)

    try:
        # Build a simple chain
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a helpful assistant. Be concise."),
            ("human", "{input}"),
        ])
        model = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)
        chain = prompt | model | StrOutputParser()

        # Run with tracing callback
        result = chain.invoke(
            {"input": "What are the three laws of thermodynamics?"},
            config={"callbacks": [callback]},
        )

        print(f"Result: {result}")
        tracer.end_trace(trace, output_data=result)
        print(f"\nTrace: {trace.trace_id}")
        print(f"Tokens: {trace.total_tokens} | Cost: ${trace.total_cost:.6f}")

    except Exception as e:
        tracer.end_trace(trace, error=str(e))
        print(f"Error: {e}")


if __name__ == "__main__":
    print("🦜 AgentTracer — LangChain Integration Example\n")
    run()
