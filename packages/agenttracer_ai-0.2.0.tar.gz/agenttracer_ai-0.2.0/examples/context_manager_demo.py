"""Demonstrates the context manager API for concise tracing.

This is the simplest way to use AgentTracer.

Run:
    python examples/context_manager_demo.py
"""

import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import agenttracer as at

tracer = at.AgentTracer(storage_dir="./agenttracer_data")


def run():
    """Minimal traced agent using context managers."""

    with tracer.trace("quickstart-agent", input_data="What is 2+2?", tags=["demo"]) as t:

        # Log a model call
        tracer.log_model_call(
            t,
            model="gpt-4o-mini",
            input_data=[{"role": "user", "content": "What is 2+2?"}],
            output_data="2 + 2 = 4",
            token_usage={"prompt_tokens": 12, "completion_tokens": 8, "total_tokens": 20},
        )

        # Log a tool call
        tracer.log_tool_call(
            t,
            tool_name="calculator",
            tool_args={"expression": "2+2"},
            tool_result="4",
        )

        # Log a decision
        tracer.log_decision(
            t,
            name="response_style",
            options=["brief", "detailed", "educational"],
            chosen="brief",
            reasoning="Simple math question, no need for explanation",
        )

        t.output_data = "The answer is 4."

    print(f"Trace: {t.trace_id}")
    print(f"Duration: {t.duration_ms:.0f}ms | Tokens: {t.total_tokens} | Cost: ${t.total_cost:.6f}")

    # Export as markdown
    report = at.export_markdown(t)
    print(f"\n--- Markdown Report ---\n{report}")


if __name__ == "__main__":
    print("📝 AgentTracer — Context Manager Demo\n")
    run()
