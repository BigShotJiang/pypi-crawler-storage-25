"""Tests for the core AgentTracer SDK."""

import os
import tempfile
import pytest

from agenttracer import AgentTracer, TraceStatus, SpanStatus, SpanKind, TokenUsage
from agenttracer.models import Trace, Span
from agenttracer.pricing import estimate_cost, estimate_tokens


@pytest.fixture
def tmp_storage(tmp_path):
    """Create a temporary storage directory."""
    return str(tmp_path / "test_traces")


@pytest.fixture
def tracer(tmp_storage):
    """Create a tracer with temporary storage."""
    t = AgentTracer(storage_dir=tmp_storage, auto_flush=False)
    yield t
    t.close()


class TestTraceLifecycle:
    def test_start_and_end_trace(self, tracer):
        trace = tracer.start_trace("test-agent", input_data="hello")
        assert trace.agent_name == "test-agent"
        assert trace.status == TraceStatus.RUNNING
        assert trace.input_data == "hello"

        tracer.end_trace(trace, output_data="world")
        assert trace.status == TraceStatus.SUCCESS
        assert trace.output_data == "world"
        assert trace.duration_ms is not None
        assert trace.duration_ms >= 0

    def test_trace_error(self, tracer):
        trace = tracer.start_trace("test-agent")
        tracer.end_trace(trace, error="something broke")
        assert trace.status == TraceStatus.ERROR
        assert trace.error == "something broke"

    def test_context_manager(self, tracer):
        with tracer.trace("ctx-agent", input_data="test") as t:
            t.output_data = "done"
        assert t.status == TraceStatus.SUCCESS
        assert t.output_data == "done"

    def test_context_manager_error(self, tracer):
        with pytest.raises(ValueError):
            with tracer.trace("ctx-agent") as t:
                raise ValueError("test error")
        assert t.status == TraceStatus.ERROR
        assert t.error == "test error"


class TestSpans:
    def test_log_step(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_step(trace, "my-step", input_data="in")
        assert span.kind == SpanKind.STEP
        assert span.name == "my-step"
        assert span.input_data == "in"
        assert len(trace.spans) == 1

    def test_log_tool_call(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_tool_call(
            trace,
            tool_name="search",
            tool_args={"q": "test"},
            tool_result="found it",
        )
        assert span.kind == SpanKind.TOOL_CALL
        assert span.tool_name == "search"
        assert span.tool_args == {"q": "test"}
        assert span.tool_result == "found it"
        assert span.status == SpanStatus.SUCCESS

    def test_log_tool_call_error(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_tool_call(
            trace,
            tool_name="broken_tool",
            tool_args={},
            error="connection failed",
        )
        assert span.status == SpanStatus.ERROR
        assert span.error == "connection failed"

    def test_log_model_call(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_model_call(
            trace,
            model="gpt-4o",
            input_data=[{"role": "user", "content": "hello"}],
            output_data="hi there!",
            temperature=0.7,
        )
        assert span.kind == SpanKind.MODEL_CALL
        assert span.model == "gpt-4o"
        assert span.provider == "openai"
        assert span.temperature == 0.7
        assert span.token_usage is not None
        assert span.token_usage.estimated is True
        assert span.cost is not None

    def test_log_model_call_with_usage(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_model_call(
            trace,
            model="claude-3.5-sonnet",
            input_data="test",
            output_data="response",
            token_usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
        )
        assert span.token_usage.prompt_tokens == 100
        assert span.token_usage.completion_tokens == 50
        assert span.token_usage.estimated is False
        assert span.provider == "anthropic"

    def test_log_decision(self, tracer):
        trace = tracer.start_trace("test")
        span = tracer.log_decision(
            trace,
            name="routing",
            options=["A", "B", "C"],
            chosen="B",
            reasoning="B is better because...",
        )
        assert span.kind == SpanKind.DECISION
        assert span.options == ["A", "B", "C"]
        assert span.chosen == "B"
        assert span.reasoning == "B is better because..."
        assert span.status == SpanStatus.SUCCESS

    def test_nested_spans(self, tracer):
        trace = tracer.start_trace("test")
        parent = tracer.log_step(trace, "parent")
        child = tracer.log_step(trace, "child", parent=parent)
        assert child.parent_span_id == parent.span_id
        assert len(parent.children) == 1
        assert parent.children[0].span_id == child.span_id


class TestAggregates:
    def test_trace_aggregates(self, tracer):
        trace = tracer.start_trace("test")
        tracer.log_model_call(
            trace, model="gpt-4o", input_data="a" * 400, output_data="b" * 200
        )
        tracer.log_model_call(
            trace, model="gpt-4o", input_data="c" * 400, output_data="d" * 200
        )
        tracer.log_tool_call(trace, tool_name="search", tool_result="ok")
        tracer.log_step(trace, "step1")
        tracer.end_trace(trace)

        assert trace.total_model_calls == 2
        assert trace.total_tool_calls == 1
        assert trace.total_steps == 4  # 2 model + 1 tool + 1 step
        assert trace.total_tokens > 0
        assert trace.total_cost > 0


class TestStorage:
    def test_sqlite_roundtrip(self, tracer):
        trace = tracer.start_trace("storage-test", input_data="hello", tags=["test"])
        tracer.log_model_call(trace, model="gpt-4o", output_data="world")
        tracer.end_trace(trace, output_data="done")

        # Load it back
        loaded = tracer.get_trace(trace.trace_id)
        assert loaded is not None
        assert loaded.trace_id == trace.trace_id
        assert loaded.agent_name == "storage-test"
        assert loaded.status == TraceStatus.SUCCESS
        assert len(loaded.spans) == 1

    def test_list_traces(self, tracer):
        for i in range(5):
            t = tracer.start_trace(f"agent-{i}")
            tracer.end_trace(t)

        traces = tracer.list_traces(limit=10)
        assert len(traces) == 5

    def test_search_traces(self, tracer):
        t1 = tracer.start_trace("agent-a", tags=["prod"])
        tracer.end_trace(t1)
        t2 = tracer.start_trace("agent-b", tags=["staging"])
        tracer.end_trace(t2, error="fail")

        results = tracer.search_traces(agent_name="agent-a")
        assert len(results) == 1
        assert results[0].agent_name == "agent-a"

        results = tracer.search_traces(status="error")
        assert len(results) == 1
        assert results[0].agent_name == "agent-b"


class TestPricing:
    def test_estimate_tokens(self):
        assert estimate_tokens("hello world") > 0
        assert estimate_tokens("") == 0

    def test_estimate_cost_known_model(self):
        usage = TokenUsage(prompt_tokens=1000, completion_tokens=500, total_tokens=1500)
        cost = estimate_cost("gpt-4o", token_usage=usage)
        assert cost.total_cost > 0
        assert cost.prompt_cost > 0
        assert cost.completion_cost > 0

    def test_estimate_cost_unknown_model(self):
        usage = TokenUsage(prompt_tokens=1000, completion_tokens=500, total_tokens=1500)
        cost = estimate_cost("unknown-model-xyz", token_usage=usage)
        assert cost.total_cost == 0

    def test_estimate_cost_anthropic(self):
        usage = TokenUsage(prompt_tokens=1000, completion_tokens=500, total_tokens=1500)
        cost = estimate_cost("claude-3.5-sonnet", token_usage=usage)
        assert cost.total_cost > 0


class TestExport:
    def test_export_json(self, tracer):
        from agenttracer.exporters import export_json
        trace = tracer.start_trace("export-test", input_data="hello")
        tracer.log_step(trace, "step1")
        tracer.end_trace(trace, output_data="world")

        json_str = export_json(trace)
        assert '"trace_id"' in json_str
        assert '"export-test"' in json_str

    def test_export_markdown(self, tracer):
        from agenttracer.exporters import export_markdown
        trace = tracer.start_trace("md-test", input_data="hello")
        tracer.log_model_call(trace, model="gpt-4o", output_data="response")
        tracer.log_tool_call(trace, tool_name="search", tool_result="found")
        tracer.end_trace(trace, output_data="done")

        md = export_markdown(trace)
        assert "# Agent Trace: md-test" in md
        assert "gpt-4o" in md
        assert "search" in md


class TestSerialization:
    def test_span_roundtrip(self):
        span = Span(
            name="test",
            kind=SpanKind.MODEL_CALL,
            model="gpt-4o",
            token_usage=TokenUsage(prompt_tokens=100, completion_tokens=50, total_tokens=150),
        )
        d = span.to_dict()
        loaded = Span.from_dict(d)
        assert loaded.name == "test"
        assert loaded.model == "gpt-4o"
        assert loaded.token_usage.prompt_tokens == 100

    def test_trace_roundtrip(self):
        trace = Trace(agent_name="test", input_data="hello")
        trace.spans.append(Span(name="s1", kind=SpanKind.STEP, trace_id=trace.trace_id))
        d = trace.to_dict()
        loaded = Trace.from_dict(d)
        assert loaded.agent_name == "test"
        assert len(loaded.spans) == 1
