"""Export traces as JSON files."""

from __future__ import annotations

import json
from pathlib import Path

from ..models import Trace


def export_json(trace: Trace, path: str | Path | None = None) -> str:
    """Export a trace to a JSON string or file.

    Args:
        trace: The trace to export.
        path: Optional file path. If provided, writes to file.

    Returns:
        JSON string representation.
    """
    data = trace.to_dict()
    json_str = json.dumps(data, indent=2, default=str)

    if path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json_str, encoding="utf-8")

    return json_str


def export_json_batch(traces: list[Trace], path: str | Path) -> None:
    """Export multiple traces to a JSON array file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = [t.to_dict() for t in traces]
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
