"""Export traces as Markdown reports."""

from __future__ import annotations

import datetime
from pathlib import Path

from ..models import Trace, Span, SpanKind


def export_markdown(trace: Trace, path: str | Path | None = None) -> str:
    """Export a trace to a Markdown report.

    Args:
        trace: The trace to export.
        path: Optional file path. If provided, writes to file.

    Returns:
        Markdown string.
    """
    lines: list[str] = []

    # Header
    lines.append(f"# Agent Trace: {trace.agent_name}")
    lines.append("")
    lines.append(f"**Trace ID:** `{trace.trace_id}`  ")
    lines.append(f"**Status:** {_status_emoji(trace.status.value)} {trace.status.value.upper()}  ")

    start = datetime.datetime.fromtimestamp(trace.start_time)
    lines.append(f"**Started:** {start.strftime('%Y-%m-%d %H:%M:%S')}  ")
    if trace.duration_ms is not None:
        lines.append(f"**Duration:** {_format_duration(trace.duration_ms)}  ")
    lines.append("")

    # Summary table
    lines.append("## Summary")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Total Steps | {trace.total_steps} |")
    lines.append(f"| Model Calls | {trace.total_model_calls} |")
    lines.append(f"| Tool Calls | {trace.total_tool_calls} |")
    lines.append(f"| Total Tokens | {trace.total_tokens:,} |")
    lines.append(f"| Estimated Cost | ${trace.total_cost:.6f} |")
    lines.append(f"| Errors | {trace.total_errors} |")
    if trace.tags:
        lines.append(f"| Tags | {', '.join(trace.tags)} |")
    lines.append("")

    # Input/Output
    if trace.input_data:
        lines.append("## Input")
        lines.append("")
        lines.append("```")
        lines.append(str(trace.input_data)[:2000])
        lines.append("```")
        lines.append("")

    if trace.output_data:
        lines.append("## Output")
        lines.append("")
        lines.append("```")
        lines.append(str(trace.output_data)[:2000])
        lines.append("```")
        lines.append("")

    # Error
    if trace.error:
        lines.append("## Error")
        lines.append("")
        lines.append(f"> {trace.error}")
        lines.append("")

    # Timeline
    lines.append("## Timeline")
    lines.append("")
    _render_spans(trace.spans, lines, depth=0)

    md = "\n".join(lines)
    if path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(md, encoding="utf-8")

    return md


def _render_spans(spans: list[Span], lines: list[str], depth: int = 0):
    """Render spans as a nested Markdown list."""
    indent = "  " * depth
    for span in spans:
        emoji = _kind_emoji(span.kind)
        dur = f" ({_format_duration(span.duration_ms)})" if span.duration_ms else ""
        status_icon = _status_emoji(span.status.value)

        header = f"{indent}- {emoji} **{span.name}** {status_icon}{dur}"

        # Add details
        details = []
        if span.model:
            details.append(f"Model: `{span.model}`")
        if span.tool_name:
            details.append(f"Tool: `{span.tool_name}`")
        if span.token_usage:
            details.append(
                f"Tokens: {span.token_usage.total_tokens:,}"
                f"{'~' if span.token_usage.estimated else ''}"
            )
        if span.cost and span.cost.total_cost > 0:
            details.append(f"Cost: ${span.cost.total_cost:.6f}")
        if span.chosen:
            details.append(f"Chose: {span.chosen}")
        if span.error:
            details.append(f"Error: {span.error[:200]}")

        if details:
            header += " — " + " | ".join(details)

        lines.append(header)

        # Input/output as sub-items
        if span.input_data and span.kind == SpanKind.MODEL_CALL:
            input_str = _truncate(str(span.input_data), 200)
            lines.append(f"{indent}  - Input: `{input_str}`")
        if span.output_data and span.kind == SpanKind.MODEL_CALL:
            output_str = _truncate(str(span.output_data), 200)
            lines.append(f"{indent}  - Output: `{output_str}`")
        if span.tool_args:
            lines.append(f"{indent}  - Args: `{_truncate(str(span.tool_args), 200)}`")
        if span.tool_result:
            lines.append(f"{indent}  - Result: `{_truncate(str(span.tool_result), 200)}`")
        if span.reasoning:
            lines.append(f"{indent}  - Reasoning: {span.reasoning}")

        # Recurse into children
        if span.children:
            _render_spans(span.children, lines, depth + 1)


def _kind_emoji(kind: SpanKind) -> str:
    return {
        SpanKind.STEP: "📋",
        SpanKind.TOOL_CALL: "🔧",
        SpanKind.MODEL_CALL: "🤖",
        SpanKind.DECISION: "🔀",
        SpanKind.ERROR: "❌",
        SpanKind.CUSTOM: "📌",
    }.get(kind, "•")


def _status_emoji(status: str) -> str:
    return {
        "success": "✅",
        "error": "❌",
        "running": "⏳",
        "cancelled": "🚫",
    }.get(status, "")


def _format_duration(ms: float | None) -> str:
    if ms is None:
        return "?"
    if ms < 1000:
        return f"{ms:.0f}ms"
    if ms < 60_000:
        return f"{ms / 1000:.1f}s"
    return f"{ms / 60_000:.1f}min"


def _truncate(s: str, max_len: int) -> str:
    s = s.replace("\n", " ").strip()
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s
