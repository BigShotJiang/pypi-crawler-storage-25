"""Core tracer — the main SDK entry point."""

from __future__ import annotations

import atexit
import logging
import time
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Optional

from .models import (
    Trace, Span, SpanKind, SpanStatus, TraceStatus,
    TokenUsage, CostEstimate,
)
from .pricing import estimate_tokens, estimate_tokens_messages, estimate_cost
from .storage.jsonl import JSONLStorage
from .storage.sqlite import SQLiteStorage

logger = logging.getLogger("agenttracer")


class AgentTracer:
    """Main tracer instance. Create one per application.

    Usage:
        tracer = AgentTracer(storage_dir="./traces")
        trace = tracer.start_trace("my-agent", input_data="Hello")
        span = tracer.log_step(trace, "process", input_data="Hello")
        tracer.end_span(span)
        tracer.end_trace(trace, output_data="World")
    """

    def __init__(
        self,
        storage_dir: str | Path = "./agenttracer_data",
        enable_jsonl: bool = True,
        enable_sqlite: bool = True,
        auto_flush: bool = True,
    ):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self._jsonl: Optional[JSONLStorage] = None
        self._sqlite: Optional[SQLiteStorage] = None

        if enable_jsonl:
            self._jsonl = JSONLStorage(self.storage_dir / "traces.jsonl")
        if enable_sqlite:
            self._sqlite = SQLiteStorage(self.storage_dir / "traces.db")

        self._active_traces: dict[str, Trace] = {}
        self._lock = threading.Lock()

        if auto_flush:
            atexit.register(self._flush_all)

    # ── Trace lifecycle ────────────────────────────────────────────

    def start_trace(
        self,
        agent_name: str = "default",
        input_data: Any = None,
        tags: list[str] | None = None,
        metadata: dict | None = None,
    ) -> Trace:
        """Start a new trace for an agent run."""
        trace = Trace(
            agent_name=agent_name,
            input_data=input_data,
            tags=tags or [],
            metadata=metadata or {},
        )
        with self._lock:
            self._active_traces[trace.trace_id] = trace
        logger.info(f"Started trace {trace.trace_id} for agent '{agent_name}'")
        return trace

    def end_trace(
        self,
        trace: Trace,
        status: TraceStatus = TraceStatus.SUCCESS,
        output_data: Any = None,
        error: str | None = None,
    ) -> Trace:
        """End a trace and persist it."""
        # End any running spans
        self._end_running_spans(trace.spans)
        trace.end(status=status, output=output_data, error=error)

        # Persist
        self._save_trace(trace)

        with self._lock:
            self._active_traces.pop(trace.trace_id, None)

        logger.info(
            f"Ended trace {trace.trace_id}: {trace.status.value} "
            f"({trace.duration_ms:.0f}ms, {trace.total_tokens} tokens, "
            f"${trace.total_cost:.6f})"
        )
        return trace

    # ── Span creation helpers ──────────────────────────────────────

    def log_step(
        self,
        trace: Trace,
        name: str,
        input_data: Any = None,
        output_data: Any = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
        metadata: dict | None = None,
    ) -> Span:
        """Log a generic step/span."""
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.STEP,
            name=name,
            input_data=input_data,
            output_data=output_data,
            tags=tags or [],
            metadata=metadata or {},
        )
        self._attach_span(trace, span, parent)
        return span

    def log_tool_call(
        self,
        trace: Trace,
        tool_name: str,
        tool_args: Any = None,
        tool_result: Any = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
        error: str | None = None,
    ) -> Span:
        """Log a tool/function call."""
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.TOOL_CALL,
            name=f"tool:{tool_name}",
            tool_name=tool_name,
            tool_args=tool_args,
            tool_result=tool_result,
            input_data=tool_args,
            output_data=tool_result,
            tags=tags or [],
            error=error,
        )
        if tool_result is not None or error:
            span.end(
                status=SpanStatus.ERROR if error else SpanStatus.SUCCESS,
                output=tool_result,
                error=error,
            )
        self._attach_span(trace, span, parent)
        return span

    def log_model_call(
        self,
        trace: Trace,
        model: str,
        provider: str | None = None,
        input_data: Any = None,
        output_data: Any = None,
        token_usage: TokenUsage | dict | None = None,
        temperature: float | None = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
        error: str | None = None,
    ) -> Span:
        """Log an LLM/model call with token and cost tracking."""
        # Normalize token_usage
        if isinstance(token_usage, dict):
            token_usage = TokenUsage.from_dict(token_usage)

        # Auto-estimate tokens if not provided
        if token_usage is None and input_data is not None:
            prompt_tokens = 0
            if isinstance(input_data, str):
                prompt_tokens = estimate_tokens(input_data)
            elif isinstance(input_data, list):
                prompt_tokens = estimate_tokens_messages(input_data)

            completion_tokens = 0
            if output_data:
                if isinstance(output_data, str):
                    completion_tokens = estimate_tokens(output_data)
                elif isinstance(output_data, dict):
                    content = output_data.get("content", "")
                    if isinstance(content, str):
                        completion_tokens = estimate_tokens(content)

            token_usage = TokenUsage(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
                estimated=True,
            )

        # Auto-estimate cost
        cost = None
        if token_usage and model:
            cost = estimate_cost(model, token_usage=token_usage)

        # Detect provider
        if provider is None:
            provider = _detect_provider(model)

        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.MODEL_CALL,
            name=f"llm:{model}",
            model=model,
            provider=provider,
            input_data=input_data,
            output_data=output_data,
            token_usage=token_usage,
            cost=cost,
            temperature=temperature,
            tags=tags or [],
            error=error,
        )
        if output_data is not None or error:
            span.end(
                status=SpanStatus.ERROR if error else SpanStatus.SUCCESS,
                output=output_data,
                error=error,
            )
        self._attach_span(trace, span, parent)
        return span

    def log_decision(
        self,
        trace: Trace,
        name: str,
        options: list[str],
        chosen: str,
        reasoning: str | None = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
    ) -> Span:
        """Log a branching decision."""
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.DECISION,
            name=f"decision:{name}",
            options=options,
            chosen=chosen,
            reasoning=reasoning,
            input_data={"options": options},
            output_data={"chosen": chosen, "reasoning": reasoning},
            tags=tags or [],
        )
        span.end(status=SpanStatus.SUCCESS)
        self._attach_span(trace, span, parent)
        return span

    def log_error(
        self,
        trace: Trace,
        name: str,
        error: str,
        parent: Span | None = None,
        tags: list[str] | None = None,
    ) -> Span:
        """Log an error event."""
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.ERROR,
            name=f"error:{name}",
            error=error,
            tags=tags or [],
        )
        span.end(status=SpanStatus.ERROR, error=error)
        self._attach_span(trace, span, parent)
        return span

    # ── Fork / Merge / Subagent ────────────────────────────────────

    def log_fork(
        self,
        trace: Trace,
        name: str,
        branches: list[str],
        parent: Span | None = None,
        tags: list[str] | None = None,
    ) -> Span:
        """Log a fork point where execution splits into parallel branches.

        Args:
            trace: Active trace.
            name: Name of the fork (e.g. "parallel_research").
            branches: Names of the branches being spawned.
            parent: Optional parent span.

        Returns:
            The fork span. Use its span_id as the fork_id when
            logging subagents and the corresponding merge.
        """
        import uuid as _uuid
        fork_id = _uuid.uuid4().hex[:10]
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.FORK,
            name=f"fork:{name}",
            fork_id=fork_id,
            input_data={"branches": branches},
            tags=tags or [],
        )
        span.end(status=SpanStatus.SUCCESS)
        self._attach_span(trace, span, parent)
        return span

    def log_subagent(
        self,
        trace: Trace,
        subagent_name: str,
        fork_span: Span | None = None,
        input_data: Any = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
    ) -> Span:
        """Log a subagent branch. Returns a span to use as parent for
        all work done inside this branch.

        Args:
            trace: Active trace.
            subagent_name: Name of the sub-agent (e.g. "search-agent").
            fork_span: The fork span that spawned this branch.
            input_data: Input passed to the subagent.

        Returns:
            A SUBAGENT span. Pass it as `parent` for all work in this branch,
            then call `end_span()` when the subagent finishes.
        """
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.SUBAGENT,
            name=f"subagent:{subagent_name}",
            subagent_name=subagent_name,
            fork_id=fork_span.fork_id if fork_span else None,
            input_data=input_data,
            tags=tags or [],
        )
        self._attach_span(trace, span, parent)
        return span

    def log_merge(
        self,
        trace: Trace,
        name: str,
        fork_span: Span,
        source_spans: list[Span],
        output_data: Any = None,
        parent: Span | None = None,
        tags: list[str] | None = None,
    ) -> Span:
        """Log a merge point where parallel branches rejoin.

        Args:
            trace: Active trace.
            name: Name of the merge (e.g. "combine_results").
            fork_span: The original fork span.
            source_spans: The subagent/branch spans being merged.
            output_data: Combined result.
        """
        span = Span(
            trace_id=trace.trace_id,
            kind=SpanKind.MERGE,
            name=f"merge:{name}",
            fork_id=fork_span.fork_id,
            merge_sources=[s.span_id for s in source_spans],
            output_data=output_data,
            tags=tags or [],
        )
        span.end(status=SpanStatus.SUCCESS, output=output_data)
        self._attach_span(trace, span, parent)
        return span

    # ── Span lifecycle ─────────────────────────────────────────────

    def end_span(
        self,
        span: Span,
        status: SpanStatus = SpanStatus.SUCCESS,
        output_data: Any = None,
        error: str | None = None,
    ) -> Span:
        """Explicitly end a span."""
        span.end(status=status, output=output_data, error=error)
        return span

    # ── Context managers ───────────────────────────────────────────

    @contextmanager
    def trace(
        self,
        agent_name: str = "default",
        input_data: Any = None,
        tags: list[str] | None = None,
        metadata: dict | None = None,
    ):
        """Context manager for traces.

        Usage:
            with tracer.trace("my-agent", input_data="Hello") as t:
                # ... do work ...
                t.output_data = "Result"
        """
        t = self.start_trace(agent_name, input_data, tags, metadata)
        try:
            yield t
            if t.status == TraceStatus.RUNNING:
                self.end_trace(t, status=TraceStatus.SUCCESS)
        except Exception as e:
            self.end_trace(t, status=TraceStatus.ERROR, error=str(e))
            raise

    @contextmanager
    def span(
        self,
        trace: Trace,
        name: str,
        kind: SpanKind = SpanKind.STEP,
        parent: Span | None = None,
        **kwargs,
    ):
        """Context manager for spans.

        Usage:
            with tracer.span(trace, "my-step") as s:
                result = do_something()
                s.output_data = result
        """
        s = Span(
            trace_id=trace.trace_id,
            kind=kind,
            name=name,
            **kwargs,
        )
        self._attach_span(trace, s, parent)
        try:
            yield s
            if s.status == SpanStatus.RUNNING:
                s.end(status=SpanStatus.SUCCESS)
        except Exception as e:
            s.end(status=SpanStatus.ERROR, error=str(e))
            raise

    # ── Query ──────────────────────────────────────────────────────

    def get_trace(self, trace_id: str) -> Optional[Trace]:
        """Load a trace by ID."""
        if self._sqlite:
            return self._sqlite.load_trace(trace_id)
        if self._jsonl:
            return self._jsonl.load_trace(trace_id)
        return None

    def list_traces(self, limit: int = 100, offset: int = 0) -> list[Trace]:
        """List recent traces."""
        if self._sqlite:
            return self._sqlite.load_all(limit=limit, offset=offset)
        if self._jsonl:
            return self._jsonl.load_all()[-limit:]
        return []

    def search_traces(self, **kwargs) -> list[Trace]:
        """Search traces with filters."""
        if self._sqlite:
            return self._sqlite.search(**kwargs)
        if self._jsonl:
            return self._jsonl.search(**{
                k: v for k, v in kwargs.items()
                if k in ("agent_name", "status", "tags", "limit")
            })
        return []

    def get_stats(self) -> dict:
        """Get aggregate stats."""
        if self._sqlite:
            return self._sqlite.get_stats()
        return {}

    def get_agent_names(self) -> list[str]:
        """Get all agent names."""
        if self._sqlite:
            return self._sqlite.get_agent_names()
        return []

    # ── Internal ───────────────────────────────────────────────────

    def _attach_span(self, trace: Trace, span: Span, parent: Span | None):
        """Attach a span to a trace or parent span."""
        span.trace_id = trace.trace_id
        if parent:
            parent.add_child(span)
        else:
            trace.spans.append(span)

    def _end_running_spans(self, spans: list[Span]):
        """Recursively end any running spans."""
        for span in spans:
            if span.status == SpanStatus.RUNNING:
                span.end(status=SpanStatus.SUCCESS)
            self._end_running_spans(span.children)

    def _save_trace(self, trace: Trace):
        """Save trace to all enabled backends."""
        if self._jsonl:
            try:
                self._jsonl.save(trace)
            except Exception as e:
                logger.error(f"Failed to save to JSONL: {e}")
        if self._sqlite:
            try:
                self._sqlite.save(trace)
            except Exception as e:
                logger.error(f"Failed to save to SQLite: {e}")

    def _flush_all(self):
        """End any active traces on shutdown."""
        with self._lock:
            traces_to_flush = list(self._active_traces.values())
            self._active_traces.clear()

        # End traces outside the lock to avoid deadlock
        # (end_trace also acquires self._lock)
        for trace in traces_to_flush:
            try:
                self._end_running_spans(trace.spans)
                trace.end(status=TraceStatus.CANCELLED)
                self._save_trace(trace)
            except Exception:
                pass

    def close(self):
        """Close storage connections."""
        self._flush_all()
        if self._sqlite:
            self._sqlite.close()


def _detect_provider(model: str) -> str:
    """Auto-detect provider from model name."""
    model_lower = model.lower()
    if any(n in model_lower for n in ("gpt", "o1", "o3", "o4", "davinci", "text-")):
        return "openai"
    if any(n in model_lower for n in ("claude", "sonnet", "haiku", "opus")):
        return "anthropic"
    if any(n in model_lower for n in ("gemini", "palm")):
        return "google"
    if "llama" in model_lower:
        return "meta"
    if "mistral" in model_lower or "mixtral" in model_lower:
        return "mistral"
    if "deepseek" in model_lower:
        return "deepseek"
    return "unknown"


# ── Module-level convenience ──────────────────────────────────────

_default_tracer: Optional[AgentTracer] = None


def get_tracer(**kwargs) -> AgentTracer:
    """Get or create the default global tracer."""
    global _default_tracer
    if _default_tracer is None:
        _default_tracer = AgentTracer(**kwargs)
    return _default_tracer


def start_trace(agent_name: str = "default", **kwargs) -> Trace:
    """Start a trace using the default tracer."""
    return get_tracer().start_trace(agent_name, **kwargs)


def end_trace(trace: Trace, **kwargs) -> Trace:
    """End a trace using the default tracer."""
    return get_tracer().end_trace(trace, **kwargs)


def log_step(trace: Trace, name: str, **kwargs) -> Span:
    """Log a step using the default tracer."""
    return get_tracer().log_step(trace, name, **kwargs)


def log_tool_call(trace: Trace, tool_name: str, **kwargs) -> Span:
    """Log a tool call using the default tracer."""
    return get_tracer().log_tool_call(trace, tool_name, **kwargs)


def log_model_call(trace: Trace, model: str, **kwargs) -> Span:
    """Log a model call using the default tracer."""
    return get_tracer().log_model_call(trace, model, **kwargs)


def log_decision(trace: Trace, name: str, **kwargs) -> Span:
    """Log a decision using the default tracer."""
    return get_tracer().log_decision(trace, name, **kwargs)


def log_fork(trace: Trace, name: str, **kwargs) -> Span:
    """Log a fork using the default tracer."""
    return get_tracer().log_fork(trace, name, **kwargs)


def log_subagent(trace: Trace, subagent_name: str, **kwargs) -> Span:
    """Log a subagent using the default tracer."""
    return get_tracer().log_subagent(trace, subagent_name, **kwargs)


def log_merge(trace: Trace, name: str, fork_span: Span, source_spans: list[Span], **kwargs) -> Span:
    """Log a merge using the default tracer."""
    return get_tracer().log_merge(trace, name, fork_span, source_spans, **kwargs)
