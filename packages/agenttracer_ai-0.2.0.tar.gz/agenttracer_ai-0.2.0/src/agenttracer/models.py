"""Core data models for AgentTracer."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


class SpanKind(str, Enum):
    """Type of span in a trace."""
    STEP = "step"
    TOOL_CALL = "tool_call"
    MODEL_CALL = "model_call"
    DECISION = "decision"
    ERROR = "error"
    FORK = "fork"
    MERGE = "merge"
    SUBAGENT = "subagent"
    CUSTOM = "custom"


class SpanStatus(str, Enum):
    """Status of a span."""
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    CANCELLED = "cancelled"


class TraceStatus(str, Enum):
    """Status of a trace."""
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    CANCELLED = "cancelled"


@dataclass
class TokenUsage:
    """Token usage for a model call."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    estimated: bool = False

    def to_dict(self) -> dict:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "estimated": self.estimated,
        }

    @classmethod
    def from_dict(cls, d: dict) -> TokenUsage:
        if not d:
            return cls()
        return cls(
            prompt_tokens=d.get("prompt_tokens", 0),
            completion_tokens=d.get("completion_tokens", 0),
            total_tokens=d.get("total_tokens", 0),
            estimated=d.get("estimated", False),
        )

    @classmethod
    def estimate(cls, text: str) -> TokenUsage:
        """Rough token estimate: ~4 chars per token for English."""
        count = max(1, len(text) // 4)
        return cls(prompt_tokens=count, total_tokens=count, estimated=True)


@dataclass
class CostEstimate:
    """Cost estimate for a model call."""
    prompt_cost: float = 0.0
    completion_cost: float = 0.0
    total_cost: float = 0.0
    currency: str = "USD"
    model: str = ""

    def to_dict(self) -> dict:
        return {
            "prompt_cost": self.prompt_cost,
            "completion_cost": self.completion_cost,
            "total_cost": self.total_cost,
            "currency": self.currency,
            "model": self.model,
        }

    @classmethod
    def from_dict(cls, d: dict) -> CostEstimate:
        if not d:
            return cls()
        return cls(
            prompt_cost=d.get("prompt_cost", 0.0),
            completion_cost=d.get("completion_cost", 0.0),
            total_cost=d.get("total_cost", 0.0),
            currency=d.get("currency", "USD"),
            model=d.get("model", ""),
        )


@dataclass
class Span:
    """A single span (step) within a trace."""
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    parent_span_id: Optional[str] = None
    trace_id: str = ""
    kind: SpanKind = SpanKind.STEP
    name: str = ""
    status: SpanStatus = SpanStatus.RUNNING
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None

    # Content
    input_data: Any = None
    output_data: Any = None
    metadata: dict = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    error: Optional[str] = None

    # Model-call specific
    model: Optional[str] = None
    provider: Optional[str] = None
    token_usage: Optional[TokenUsage] = None
    cost: Optional[CostEstimate] = None
    temperature: Optional[float] = None

    # Tool-call specific
    tool_name: Optional[str] = None
    tool_args: Any = None
    tool_result: Any = None

    # Decision specific
    options: Optional[list[str]] = None
    chosen: Optional[str] = None
    reasoning: Optional[str] = None

    # Fork/merge specific
    fork_id: Optional[str] = None          # links fork → merge pairs
    merge_sources: list[str] = field(default_factory=list)  # span_ids merging in
    subagent_name: Optional[str] = None    # name of the subagent branch

    # Children
    children: list[Span] = field(default_factory=list)

    def end(self, status: SpanStatus = SpanStatus.SUCCESS, output: Any = None, error: str | None = None):
        """End this span."""
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        self.status = status
        if output is not None:
            self.output_data = output
        if error is not None:
            self.error = error
            self.status = SpanStatus.ERROR

    def add_child(self, span: Span) -> Span:
        """Add a child span."""
        span.parent_span_id = self.span_id
        span.trace_id = self.trace_id
        self.children.append(span)
        return span

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        d = {
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "trace_id": self.trace_id,
            "kind": self.kind.value,
            "name": self.name,
            "status": self.status.value,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "tags": self.tags,
        }
        if self.input_data is not None:
            d["input_data"] = _safe_serialize(self.input_data)
        if self.output_data is not None:
            d["output_data"] = _safe_serialize(self.output_data)
        if self.metadata:
            d["metadata"] = self.metadata
        if self.error:
            d["error"] = self.error
        if self.model:
            d["model"] = self.model
        if self.provider:
            d["provider"] = self.provider
        if self.token_usage:
            d["token_usage"] = self.token_usage.to_dict()
        if self.cost:
            d["cost"] = self.cost.to_dict()
        if self.temperature is not None:
            d["temperature"] = self.temperature
        if self.tool_name:
            d["tool_name"] = self.tool_name
        if self.tool_args is not None:
            d["tool_args"] = _safe_serialize(self.tool_args)
        if self.tool_result is not None:
            d["tool_result"] = _safe_serialize(self.tool_result)
        if self.options:
            d["options"] = self.options
        if self.chosen:
            d["chosen"] = self.chosen
        if self.reasoning:
            d["reasoning"] = self.reasoning
        if self.fork_id:
            d["fork_id"] = self.fork_id
        if self.merge_sources:
            d["merge_sources"] = self.merge_sources
        if self.subagent_name:
            d["subagent_name"] = self.subagent_name
        if self.children:
            d["children"] = [c.to_dict() for c in self.children]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> Span:
        """Deserialize from dictionary."""
        span = cls(
            span_id=d.get("span_id", uuid.uuid4().hex[:12]),
            parent_span_id=d.get("parent_span_id"),
            trace_id=d.get("trace_id", ""),
            kind=SpanKind(d.get("kind", "step")),
            name=d.get("name", ""),
            status=SpanStatus(d.get("status", "running")),
            start_time=d.get("start_time", time.time()),
            end_time=d.get("end_time"),
            duration_ms=d.get("duration_ms"),
            input_data=d.get("input_data"),
            output_data=d.get("output_data"),
            metadata=d.get("metadata", {}),
            tags=d.get("tags", []),
            error=d.get("error"),
            model=d.get("model"),
            provider=d.get("provider"),
            token_usage=TokenUsage.from_dict(d["token_usage"]) if d.get("token_usage") else None,
            cost=CostEstimate.from_dict(d["cost"]) if d.get("cost") else None,
            temperature=d.get("temperature"),
            tool_name=d.get("tool_name"),
            tool_args=d.get("tool_args"),
            tool_result=d.get("tool_result"),
            options=d.get("options"),
            chosen=d.get("chosen"),
            reasoning=d.get("reasoning"),
            fork_id=d.get("fork_id"),
            merge_sources=d.get("merge_sources", []),
            subagent_name=d.get("subagent_name"),
        )
        for child_dict in d.get("children", []):
            span.children.append(Span.from_dict(child_dict))
        return span


@dataclass
class Trace:
    """A complete trace representing one agent run."""
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    agent_name: str = "default"
    status: TraceStatus = TraceStatus.RUNNING
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None

    # Aggregates
    total_tokens: int = 0
    total_cost: float = 0.0
    total_steps: int = 0
    total_model_calls: int = 0
    total_tool_calls: int = 0
    total_errors: int = 0

    # Content
    input_data: Any = None
    output_data: Any = None
    metadata: dict = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    error: Optional[str] = None

    # Spans
    spans: list[Span] = field(default_factory=list)

    def end(self, status: TraceStatus = TraceStatus.SUCCESS, output: Any = None, error: str | None = None):
        """End this trace and compute aggregates."""
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        self.status = status
        if output is not None:
            self.output_data = output
        if error is not None:
            self.error = error
            self.status = TraceStatus.ERROR
        self._compute_aggregates()

    def _compute_aggregates(self):
        """Walk all spans and compute totals."""
        def walk(spans: list[Span]):
            for span in spans:
                self.total_steps += 1
                if span.kind == SpanKind.MODEL_CALL:
                    self.total_model_calls += 1
                    if span.token_usage:
                        self.total_tokens += span.token_usage.total_tokens
                    if span.cost:
                        self.total_cost += span.cost.total_cost
                if span.kind == SpanKind.TOOL_CALL:
                    self.total_tool_calls += 1
                if span.status == SpanStatus.ERROR:
                    self.total_errors += 1
                walk(span.children)

        # Reset before computing
        self.total_tokens = 0
        self.total_cost = 0.0
        self.total_steps = 0
        self.total_model_calls = 0
        self.total_tool_calls = 0
        self.total_errors = 0
        walk(self.spans)

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        d = {
            "trace_id": self.trace_id,
            "agent_name": self.agent_name,
            "status": self.status.value,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "total_tokens": self.total_tokens,
            "total_cost": self.total_cost,
            "total_steps": self.total_steps,
            "total_model_calls": self.total_model_calls,
            "total_tool_calls": self.total_tool_calls,
            "total_errors": self.total_errors,
            "tags": self.tags,
            "spans": [s.to_dict() for s in self.spans],
        }
        if self.input_data is not None:
            d["input_data"] = _safe_serialize(self.input_data)
        if self.output_data is not None:
            d["output_data"] = _safe_serialize(self.output_data)
        if self.metadata:
            d["metadata"] = self.metadata
        if self.error:
            d["error"] = self.error
        return d

    @classmethod
    def from_dict(cls, d: dict) -> Trace:
        """Deserialize from dictionary."""
        trace = cls(
            trace_id=d.get("trace_id", uuid.uuid4().hex[:16]),
            agent_name=d.get("agent_name", "default"),
            status=TraceStatus(d.get("status", "running")),
            start_time=d.get("start_time", time.time()),
            end_time=d.get("end_time"),
            duration_ms=d.get("duration_ms"),
            total_tokens=d.get("total_tokens", 0),
            total_cost=d.get("total_cost", 0.0),
            total_steps=d.get("total_steps", 0),
            total_model_calls=d.get("total_model_calls", 0),
            total_tool_calls=d.get("total_tool_calls", 0),
            total_errors=d.get("total_errors", 0),
            input_data=d.get("input_data"),
            output_data=d.get("output_data"),
            metadata=d.get("metadata", {}),
            tags=d.get("tags", []),
            error=d.get("error"),
        )
        for span_dict in d.get("spans", []):
            trace.spans.append(Span.from_dict(span_dict))
        return trace


def _safe_serialize(obj: Any) -> Any:
    """Safely serialize an object for JSON storage."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(item) for item in obj]
    if isinstance(obj, dict):
        return {str(k): _safe_serialize(v) for k, v in obj.items()}
    try:
        return str(obj)
    except Exception:
        return "<unserializable>"
