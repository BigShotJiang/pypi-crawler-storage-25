"""Framework integrations for AgentTracer.

Each integration is imported lazily to avoid requiring
framework dependencies when not in use.
"""


def patch_openai(client, tracer, trace):
    """Wrap an OpenAI client for automatic tracing."""
    from .openai_wrapper import patch_openai as _patch
    return _patch(client, tracer, trace)


def patch_anthropic(client, tracer, trace):
    """Wrap an Anthropic client for automatic tracing."""
    from .anthropic_wrapper import patch_anthropic as _patch
    return _patch(client, tracer, trace)


def langchain_callback(tracer, trace):
    """Create a LangChain/LangGraph callback handler."""
    from .langchain_callback import AgentTracerCallback
    return AgentTracerCallback(tracer, trace)


def trace_autogen_chat(tracer, trace, **kwargs):
    """Run an AutoGen chat with tracing."""
    from .autogen_wrapper import trace_autogen_chat as _trace
    return _trace(tracer, trace, **kwargs)
