"""LangChain / LangGraph callback handler for automatic tracing.

Works as a LangChain callback handler that captures LLM calls,
tool invocations, chain starts/ends, and errors.

Usage:
    from agenttracer.integrations.langchain_callback import AgentTracerCallback

    tracer = AgentTracer()
    trace = tracer.start_trace("langchain-agent")
    callback = AgentTracerCallback(tracer, trace)

    # LangChain
    chain.invoke(input, config={"callbacks": [callback]})

    # LangGraph
    graph.invoke(input, config={"callbacks": [callback]})
"""

from __future__ import annotations

import time
from typing import Any, Optional
from uuid import UUID

from ..models import TokenUsage, Span, SpanKind, SpanStatus
from ..tracer import AgentTracer
from ..models import Trace

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:
    # Fallback: define a minimal base class if langchain isn't installed
    class BaseCallbackHandler:  # type: ignore
        """Minimal stub when langchain is not installed."""
        pass


class AgentTracerCallback(BaseCallbackHandler):
    """LangChain/LangGraph callback handler that logs to AgentTracer."""

    def __init__(self, tracer: AgentTracer, trace: Trace):
        self.tracer = tracer
        self.trace = trace
        self._span_map: dict[str, Span] = {}
        self._start_times: dict[str, float] = {}

    def _run_key(self, run_id: UUID) -> str:
        return str(run_id)

    # ── LLM Callbacks ──────────────────────────────────────────────

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        self._start_times[key] = time.time()

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        self._start_times[key] = time.time()

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        start = self._start_times.pop(key, time.time())
        duration_ms = (time.time() - start) * 1000

        # Extract model info
        model = "unknown"
        token_usage = None

        llm_output = getattr(response, "llm_output", None) or {}
        if isinstance(llm_output, dict):
            model = llm_output.get("model_name", model)
            usage = llm_output.get("token_usage", {})
            if usage:
                token_usage = TokenUsage(
                    prompt_tokens=usage.get("prompt_tokens", 0),
                    completion_tokens=usage.get("completion_tokens", 0),
                    total_tokens=usage.get("total_tokens", 0),
                    estimated=False,
                )

        # Extract output text
        output = None
        generations = getattr(response, "generations", [])
        if generations and generations[0]:
            gen = generations[0][0]
            output = getattr(gen, "text", None)
            if output is None:
                msg = getattr(gen, "message", None)
                if msg:
                    output = getattr(msg, "content", None)

        parent = self._span_map.get(self._run_key(parent_run_id)) if parent_run_id else None

        span = self.tracer.log_model_call(
            self.trace,
            model=model,
            input_data=None,
            output_data=output,
            token_usage=token_usage,
            parent=parent,
        )
        span.duration_ms = duration_ms
        self._span_map[key] = span

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        self.tracer.log_error(self.trace, "llm_error", str(error))

    # ── Tool Callbacks ─────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        self._start_times[key] = time.time()

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        start = self._start_times.pop(key, time.time())
        duration_ms = (time.time() - start) * 1000

        tool_name = kwargs.get("name", "unknown_tool")
        parent = self._span_map.get(self._run_key(parent_run_id)) if parent_run_id else None

        span = self.tracer.log_tool_call(
            self.trace,
            tool_name=tool_name,
            tool_result=str(output)[:2000],
            parent=parent,
        )
        span.duration_ms = duration_ms
        self._span_map[key] = span

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        self.tracer.log_error(self.trace, "tool_error", str(error))

    # ── Chain Callbacks ────────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        self._start_times[key] = time.time()
        chain_name = serialized.get("name", serialized.get("id", ["chain"])[-1])
        parent = self._span_map.get(self._run_key(parent_run_id)) if parent_run_id else None

        span = self.tracer.log_step(
            self.trace,
            name=f"chain:{chain_name}",
            input_data=inputs,
            parent=parent,
        )
        self._span_map[key] = span

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        span = self._span_map.get(key)
        if span:
            self.tracer.end_span(span, output_data=outputs)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        key = self._run_key(run_id)
        span = self._span_map.get(key)
        if span:
            self.tracer.end_span(span, status=SpanStatus.ERROR, error=str(error))
        else:
            self.tracer.log_error(self.trace, "chain_error", str(error))
