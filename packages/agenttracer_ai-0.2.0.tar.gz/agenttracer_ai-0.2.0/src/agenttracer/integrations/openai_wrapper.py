"""OpenAI-style API wrapper for automatic tracing.

Works with the `openai` Python SDK. Wraps `chat.completions.create`
to automatically log model calls, token usage, tool calls, and costs.

Usage:
    from agenttracer.integrations.openai_wrapper import patch_openai

    tracer = AgentTracer()
    trace = tracer.start_trace("my-agent")
    client = patch_openai(openai.OpenAI(), tracer, trace)
    response = client.chat.completions.create(model="gpt-4o", messages=[...])
"""

from __future__ import annotations

import time
import functools
from typing import Any, TYPE_CHECKING

from ..models import TokenUsage, SpanKind, SpanStatus
from ..tracer import AgentTracer
from ..models import Trace, Span

if TYPE_CHECKING:
    pass


def patch_openai(client: Any, tracer: AgentTracer, trace: Trace) -> Any:
    """Wrap an OpenAI client to auto-trace all chat completions.

    Args:
        client: An openai.OpenAI() instance.
        tracer: AgentTracer instance.
        trace: Active trace to log into.

    Returns:
        The same client, with patched methods.
    """
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        model = kwargs.get("model", args[0] if args else "unknown")
        messages = kwargs.get("messages", args[1] if len(args) > 1 else [])
        temperature = kwargs.get("temperature")
        tools = kwargs.get("tools")

        start = time.time()
        error_str = None
        response = None

        try:
            response = original_create(*args, **kwargs)
        except Exception as e:
            error_str = str(e)
            tracer.log_model_call(
                trace,
                model=model,
                provider="openai",
                input_data=messages,
                error=error_str,
                temperature=temperature,
            )
            raise

        duration_ms = (time.time() - start) * 1000

        # Extract token usage from response
        usage = getattr(response, "usage", None)
        token_usage = None
        if usage:
            token_usage = TokenUsage(
                prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
                total_tokens=getattr(usage, "total_tokens", 0) or 0,
                estimated=False,
            )

        # Extract response content
        output = None
        choice = None
        if hasattr(response, "choices") and response.choices:
            choice = response.choices[0]
            msg = getattr(choice, "message", None)
            if msg:
                output = getattr(msg, "content", None)

        # Log the model call
        span = tracer.log_model_call(
            trace,
            model=model,
            provider="openai",
            input_data=messages,
            output_data=output,
            token_usage=token_usage,
            temperature=temperature,
        )
        span.duration_ms = duration_ms

        # Log any tool calls in the response
        if choice and hasattr(choice, "message"):
            tool_calls = getattr(choice.message, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    fn = getattr(tc, "function", None)
                    if fn:
                        tracer.log_tool_call(
                            trace,
                            tool_name=getattr(fn, "name", "unknown"),
                            tool_args=getattr(fn, "arguments", None),
                            parent=span,
                        )

        return response

    client.chat.completions.create = traced_create
    return client


class TracedOpenAI:
    """Convenience wrapper that creates a traced OpenAI client.

    Usage:
        traced = TracedOpenAI(tracer, trace)
        response = traced.chat("gpt-4o", messages=[...])
    """

    def __init__(self, tracer: AgentTracer, trace: Trace):
        self.tracer = tracer
        self.trace = trace

    def chat(
        self,
        model: str,
        messages: list[dict],
        temperature: float | None = None,
        **kwargs,
    ) -> dict:
        """Make a traced chat completion call (no SDK dependency)."""
        start = time.time()

        try:
            import openai
            client = openai.OpenAI()
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                **kwargs,
            )
            duration_ms = (time.time() - start) * 1000

            usage = getattr(response, "usage", None)
            token_usage = None
            if usage:
                token_usage = TokenUsage(
                    prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                    completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
                    total_tokens=getattr(usage, "total_tokens", 0) or 0,
                    estimated=False,
                )

            output = None
            if hasattr(response, "choices") and response.choices:
                msg = response.choices[0].message
                output = getattr(msg, "content", None)

            span = self.tracer.log_model_call(
                self.trace,
                model=model,
                provider="openai",
                input_data=messages,
                output_data=output,
                token_usage=token_usage,
                temperature=temperature,
            )
            span.duration_ms = duration_ms
            return {"content": output, "usage": token_usage, "span": span}

        except Exception as e:
            duration_ms = (time.time() - start) * 1000
            span = self.tracer.log_model_call(
                self.trace,
                model=model,
                provider="openai",
                input_data=messages,
                error=str(e),
                temperature=temperature,
            )
            span.duration_ms = duration_ms
            raise
