"""AutoGen integration for automatic tracing.

Provides a hook/wrapper for Microsoft AutoGen agents to capture
messages, model calls, and tool invocations.

Usage:
    from agenttracer.integrations.autogen_wrapper import trace_autogen_chat

    tracer = AgentTracer()
    trace = tracer.start_trace("autogen-agent")

    # Wrap an AutoGen chat and capture all messages
    result = trace_autogen_chat(
        tracer, trace,
        initiator=user_proxy,
        recipient=assistant,
        message="Solve this problem...",
    )
"""

from __future__ import annotations

import time
from typing import Any, TYPE_CHECKING

from ..models import TokenUsage, SpanKind
from ..tracer import AgentTracer
from ..models import Trace

if TYPE_CHECKING:
    pass


def trace_autogen_chat(
    tracer: AgentTracer,
    trace: Trace,
    initiator: Any,
    recipient: Any,
    message: str,
    **kwargs,
) -> Any:
    """Run an AutoGen chat with tracing.

    Wraps the reply functions to intercept messages and model calls.

    Args:
        tracer: AgentTracer instance.
        trace: Active trace.
        initiator: AutoGen agent initiating the chat.
        recipient: AutoGen agent receiving the chat.
        message: Initial message.
        **kwargs: Additional kwargs for initiate_chat.

    Returns:
        The chat result.
    """
    # Log the initial message
    tracer.log_step(
        trace,
        name="chat_initiate",
        input_data={"message": message, "sender": getattr(initiator, "name", "user")},
    )

    # Patch the recipient's generate_reply to capture model calls
    original_reply = getattr(recipient, "generate_reply", None)
    if original_reply:
        def traced_reply(messages=None, sender=None, **kw):
            start = time.time()
            step = tracer.log_step(
                trace,
                name=f"reply:{getattr(recipient, 'name', 'agent')}",
                input_data=messages[-1] if messages else None,
            )

            try:
                result = original_reply(messages=messages, sender=sender, **kw)
                duration_ms = (time.time() - start) * 1000
                tracer.end_span(step, output_data=result)
                step.duration_ms = duration_ms

                # Try to capture model usage if available
                if hasattr(recipient, "client") and hasattr(recipient.client, "total_usage_summary"):
                    usage = recipient.client.total_usage_summary
                    if usage:
                        tracer.log_model_call(
                            trace,
                            model=getattr(recipient, "llm_config", {}).get("model", "unknown"),
                            output_data=result,
                            parent=step,
                        )

                return result
            except Exception as e:
                tracer.end_span(step, error=str(e))
                raise

        recipient.generate_reply = traced_reply

    try:
        result = initiator.initiate_chat(recipient, message=message, **kwargs)

        # Log the final result
        tracer.log_step(
            trace,
            name="chat_complete",
            output_data=str(result) if result else None,
        )
        return result

    except Exception as e:
        tracer.log_error(trace, "autogen_chat_error", str(e))
        raise
    finally:
        # Restore original
        if original_reply:
            recipient.generate_reply = original_reply
