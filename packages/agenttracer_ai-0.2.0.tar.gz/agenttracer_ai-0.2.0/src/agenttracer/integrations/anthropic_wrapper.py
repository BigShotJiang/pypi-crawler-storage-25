"""Anthropic-style API wrapper for automatic tracing.

Works with the `anthropic` Python SDK. Wraps `messages.create`
to automatically log model calls, token usage, tool use, and costs.

Usage:
    from agenttracer.integrations.anthropic_wrapper import patch_anthropic

    tracer = AgentTracer()
    trace = tracer.start_trace("my-agent")
    client = patch_anthropic(anthropic.Anthropic(), tracer, trace)
    response = client.messages.create(model="claude-3.5-sonnet", ...)
"""

from __future__ import annotations

import time
import functools
from typing import Any, TYPE_CHECKING

from ..models import TokenUsage, SpanKind, SpanStatus
from ..tracer import AgentTracer
from ..models import Trace, Span

if TYPE_CHECKING:
    pass


def patch_anthropic(client: Any, tracer: AgentTracer, trace: Trace) -> Any:
    """Wrap an Anthropic client to auto-trace all message calls.

    Args:
        client: An anthropic.Anthropic() instance.
        tracer: AgentTracer instance.
        trace: Active trace to log into.

    Returns:
        The same client, with patched methods.
    """
    original_create = client.messages.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        model = kwargs.get("model", args[0] if args else "unknown")
        messages = kwargs.get("messages", [])
        system = kwargs.get("system")
        temperature = kwargs.get("temperature")

        # Build input representation
        input_data = []
        if system:
            input_data.append({"role": "system", "content": system})
        input_data.extend(messages)

        start = time.time()
        error_str = None
        response = None

        try:
            response = original_create(*args, **kwargs)
        except Exception as e:
            error_str = str(e)
            tracer.log_model_call(
                trace,
                model=model,
                provider="anthropic",
                input_data=input_data,
                error=error_str,
                temperature=temperature,
            )
            raise

        duration_ms = (time.time() - start) * 1000

        # Extract token usage
        usage = getattr(response, "usage", None)
        token_usage = None
        if usage:
            token_usage = TokenUsage(
                prompt_tokens=getattr(usage, "input_tokens", 0) or 0,
                completion_tokens=getattr(usage, "output_tokens", 0) or 0,
                total_tokens=(
                    (getattr(usage, "input_tokens", 0) or 0) +
                    (getattr(usage, "output_tokens", 0) or 0)
                ),
                estimated=False,
            )

        # Extract output content
        output = None
        content_blocks = getattr(response, "content", [])
        text_parts = []
        tool_uses = []

        for block in content_blocks:
            block_type = getattr(block, "type", "")
            if block_type == "text":
                text_parts.append(getattr(block, "text", ""))
            elif block_type == "tool_use":
                tool_uses.append(block)

        output = "\n".join(text_parts) if text_parts else None

        # Log the model call
        span = tracer.log_model_call(
            trace,
            model=model,
            provider="anthropic",
            input_data=input_data,
            output_data=output,
            token_usage=token_usage,
            temperature=temperature,
        )
        span.duration_ms = duration_ms

        # Log any tool use blocks
        for tu in tool_uses:
            tracer.log_tool_call(
                trace,
                tool_name=getattr(tu, "name", "unknown"),
                tool_args=getattr(tu, "input", None),
                parent=span,
            )

        return response

    client.messages.create = traced_create
    return client
