/* AgentTracer Dashboard — Client-side application */

const state = {
  traces: [],
  selectedTrace: null,
  agents: [],
  stats: {},
  filters: {},
};

// ── API Helpers ──────────────────────────────────────────────────

async function api(path, params = {}) {
  const url = new URL(path, window.location.origin);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== null && v !== undefined && v !== '') url.searchParams.set(k, v);
  });
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// ── Data Loading ─────────────────────────────────────────────────

async function loadTraces() {
  const params = { ...state.filters, limit: 200 };
  state.traces = await api('/api/traces', params);
  renderTraceList();
}

async function loadTrace(traceId) {
  state.selectedTrace = await api(`/api/traces/${traceId}`);
  renderDetail();
}

async function loadStats() {
  state.stats = await api('/api/stats');
  renderStats();
}

async function loadAgents() {
  state.agents = await api('/api/agents');
  renderAgentFilter();
}

async function init() {
  await Promise.all([loadStats(), loadAgents()]);
  await loadTraces();
  setInterval(() => {
    loadStats();
    loadTraces();
  }, 10000);
}

// ── Rendering ────────────────────────────────────────────────────

function renderStats() {
  const s = state.stats;
  document.getElementById('stat-traces').textContent = s.total_traces ?? 0;
  document.getElementById('stat-tokens').textContent = formatNumber(s.total_tokens ?? 0);
  document.getElementById('stat-cost').textContent = '$' + (s.total_cost ?? 0).toFixed(4);
  document.getElementById('stat-agents').textContent = s.unique_agents ?? 0;
}

function renderAgentFilter() {
  const sel = document.getElementById('filter-agent');
  sel.innerHTML = '<option value="">All Agents</option>';
  state.agents.forEach(name => {
    sel.innerHTML += `<option value="${esc(name)}">${esc(name)}</option>`;
  });
}

function renderTraceList() {
  const container = document.getElementById('trace-list-body');

  if (state.traces.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M12 20V10M18 20V4M6 20v-4"/>
        </svg>
        <h3>No traces yet</h3>
        <p>Run an agent with AgentTracer to see traces here. Check the quickstart guide to get started.</p>
      </div>`;
    return;
  }

  container.innerHTML = state.traces.map(t => `
    <div class="trace-row ${state.selectedTrace?.trace_id === t.trace_id ? 'active' : ''}"
         onclick="loadTrace('${t.trace_id}')">
      <div>
        <div class="trace-agent">${esc(t.agent_name)}</div>
        <div class="trace-id">${t.trace_id}</div>
      </div>
      <div class="trace-time">${formatTime(t.start_time)}</div>
      <div><span class="badge badge-${t.status}">${t.status}</span></div>
      <div class="trace-duration">${formatDuration(t.duration_ms)}</div>
      <div class="trace-tokens">${formatNumber(t.total_tokens)}</div>
      <div class="trace-cost">${t.total_cost > 0 ? '$' + t.total_cost.toFixed(4) : '—'}</div>
      <div>${t.total_errors > 0 ? `<span class="badge badge-error">${t.total_errors}</span>` : '—'}</div>
    </div>
  `).join('');
}

function renderDetail() {
  const panel = document.getElementById('detail-panel');
  const t = state.selectedTrace;
  if (!t) { panel.classList.remove('open'); return; }
  panel.classList.add('open');

  document.getElementById('detail-agent').textContent = t.agent_name;
  document.getElementById('detail-id').textContent = t.trace_id;
  document.getElementById('detail-status').innerHTML =
    `<span class="badge badge-${t.status}">${t.status}</span>`;

  // Meta cards
  document.getElementById('meta-duration').textContent = formatDuration(t.duration_ms);
  document.getElementById('meta-tokens').textContent = formatNumber(t.total_tokens);
  document.getElementById('meta-cost').textContent = '$' + (t.total_cost ?? 0).toFixed(6);
  document.getElementById('meta-steps').textContent = t.total_steps;
  document.getElementById('meta-models').textContent = t.total_model_calls;
  document.getElementById('meta-tools').textContent = t.total_tool_calls;

  // Timeline
  renderTimeline(t.spans || []);

  // Diff viewer
  renderDiff(t);

  // Graph view
  const hasGraphSpans = traceHasGraphData(t.spans || []);
  const graphTab = document.querySelector('[data-tab="graph"]');
  if (graphTab) {
    graphTab.style.display = hasGraphSpans ? '' : 'none';
  }
  if (hasGraphSpans) {
    renderGraph('graph-container', t.spans || []);
  } else {
    const gc = document.getElementById('graph-container');
    if (gc) gc.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-muted); font-size: 13px;">
      No fork/merge data. Use <code>log_fork()</code>, <code>log_subagent()</code>,
      and <code>log_merge()</code> to visualize the execution graph.
    </div>`;
  }

  // Re-render list to update active state
  renderTraceList();
}

function renderTimeline(spans, container = null) {
  if (!container) container = document.getElementById('timeline-body');
  container.innerHTML = '';

  spans.forEach(span => {
    const el = document.createElement('div');
    el.className = 'span-item';
    el.innerHTML = `
      <div class="span-node" onclick="toggleSpanDetails(this, event)">
        <div class="span-header">
          <span class="badge badge-${kindToBadge(span.kind)}">${span.kind}</span>
          <span class="span-name">${esc(span.name)}</span>
          ${span.status === 'error' ? '<span class="badge badge-error">error</span>' : ''}
          <span class="span-duration">${formatDuration(span.duration_ms)}</span>
        </div>
        <div class="span-details">
          ${renderSpanDetails(span)}
        </div>
      </div>
      ${span.children?.length ? '<div class="span-children"></div>' : ''}
    `;
    container.appendChild(el);

    if (span.children?.length) {
      renderTimeline(span.children, el.querySelector('.span-children'));
    }
  });
}

function renderSpanDetails(span) {
  let rows = '';

  const add = (key, val) => {
    if (val !== null && val !== undefined && val !== '') {
      let display = typeof val === 'object' ? JSON.stringify(val, null, 2) : String(val);
      if (display.length > 500) display = display.slice(0, 500) + '…';
      rows += `<div class="span-detail-row">
        <span class="span-detail-key">${key}</span>
        <span class="span-detail-value">${esc(display)}</span>
      </div>`;
    }
  };

  add('Model', span.model);
  add('Provider', span.provider);
  add('Tool', span.tool_name);
  if (span.token_usage) {
    add('Tokens', `${span.token_usage.prompt_tokens} → ${span.token_usage.completion_tokens} (${span.token_usage.total_tokens} total${span.token_usage.estimated ? ', est.' : ''})`);
  }
  if (span.cost?.total_cost) {
    add('Cost', '$' + span.cost.total_cost.toFixed(6));
  }
  add('Temperature', span.temperature);
  add('Chosen', span.chosen);
  add('Options', span.options?.join(', '));
  add('Reasoning', span.reasoning);
  add('Input', span.input_data);
  add('Output', span.output_data);
  add('Tool Args', span.tool_args);
  add('Tool Result', span.tool_result);
  add('Error', span.error);
  if (span.tags?.length) add('Tags', span.tags.join(', '));

  return rows;
}

function renderDiff(trace) {
  const container = document.getElementById('diff-viewer');
  if (!trace.input_data && !trace.output_data) {
    container.style.display = 'none';
    return;
  }
  container.style.display = 'block';

  const inputStr = trace.input_data
    ? (typeof trace.input_data === 'object' ? JSON.stringify(trace.input_data, null, 2) : String(trace.input_data))
    : '(no input)';
  const outputStr = trace.output_data
    ? (typeof trace.output_data === 'object' ? JSON.stringify(trace.output_data, null, 2) : String(trace.output_data))
    : '(no output)';

  document.getElementById('diff-input').textContent = inputStr;
  document.getElementById('diff-output').textContent = outputStr;
}

// ── Interactions ──────────────────────────────────────────────────

function toggleSpanDetails(node, event) {
  event.stopPropagation();
  const details = node.querySelector('.span-details');
  details.classList.toggle('open');
}

function closeDetail() {
  state.selectedTrace = null;
  document.getElementById('detail-panel').classList.remove('open');
  renderTraceList();
}

function applyFilters() {
  state.filters = {
    agent_name: document.getElementById('filter-agent').value,
    status: document.getElementById('filter-status').value,
    has_errors: document.getElementById('filter-errors').value,
    tags: document.getElementById('filter-tags').value,
  };
  loadTraces();
}

function clearFilters() {
  document.getElementById('filter-agent').value = '';
  document.getElementById('filter-status').value = '';
  document.getElementById('filter-errors').value = '';
  document.getElementById('filter-tags').value = '';
  state.filters = {};
  loadTraces();
}

function exportTrace(format) {
  if (!state.selectedTrace) return;
  const id = state.selectedTrace.trace_id;
  window.open(`/api/traces/${id}/export/${format}`, '_blank');
}

// ── Utilities ────────────────────────────────────────────────────

function formatTime(ts) {
  if (!ts) return '—';
  const d = new Date(ts * 1000);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDuration(ms) {
  if (ms == null) return '—';
  if (ms < 1000) return Math.round(ms) + 'ms';
  if (ms < 60000) return (ms / 1000).toFixed(1) + 's';
  return (ms / 60000).toFixed(1) + 'min';
}

function formatNumber(n) {
  if (n == null) return '0';
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return String(n);
}

function kindToBadge(kind) {
  const map = {
    step: 'step', tool_call: 'tool', model_call: 'model', decision: 'decision',
    error: 'error-kind', custom: 'step',
    fork: 'fork', merge: 'merge', subagent: 'subagent',
  };
  return map[kind] || 'step';
}

function esc(str) {
  if (!str) return '';
  const d = document.createElement('div');
  d.textContent = String(str);
  return d.innerHTML;
}

// ── Tab switching ────────────────────────────────────────────────

function switchTab(tabName) {
  // Update tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
  });
  // Update panels
  document.querySelectorAll('.tab-panel').forEach(panel => {
    panel.classList.toggle('active', panel.id === `tab-${tabName}`);
  });
}

// ── Graph helpers ────────────────────────────────────────────────

function traceHasGraphData(spans) {
  for (const span of spans) {
    if (span.kind === 'fork' || span.kind === 'merge' || span.kind === 'subagent') {
      return true;
    }
    if (span.children && traceHasGraphData(span.children)) {
      return true;
    }
  }
  return false;
}

// ── Boot ─────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', init);
