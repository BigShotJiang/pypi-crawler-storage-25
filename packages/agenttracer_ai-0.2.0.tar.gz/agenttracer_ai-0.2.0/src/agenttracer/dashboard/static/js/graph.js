/* AgentTracer — DAG Graph View
 *
 * Converts a span tree into a directed acyclic graph (DAG) that
 * visualizes fork/merge points, subagent branches, and sequential steps.
 *
 * Layout algorithm:
 * 1. Flatten the span tree into graph nodes
 * 2. Build edges (parent→child, fork→subagents, subagents→merge)
 * 3. Assign columns (lane per parallel branch)
 * 4. Assign rows (topological order)
 * 5. Render as SVG with curved edges
 */

const GRAPH = {
  // Layout constants
  NODE_W: 200,
  NODE_H: 44,
  COL_GAP: 60,
  ROW_GAP: 24,
  PAD_X: 40,
  PAD_Y: 30,
  CORNER_R: 8,

  // Colors by span kind
  COLORS: {
    step:       { bg: '#1c2f4a', border: '#58a6ff', text: '#58a6ff' },
    tool_call:  { bg: '#2d2418', border: '#f0883e', text: '#f0883e' },
    model_call: { bg: '#2a1f3d', border: '#bc8cff', text: '#bc8cff' },
    decision:   { bg: '#1a2e2b', border: '#39d2c0', text: '#39d2c0' },
    error:      { bg: '#3b1d1d', border: '#f85149', text: '#f85149' },
    fork:       { bg: '#1a2e2b', border: '#3fb950', text: '#3fb950' },
    merge:      { bg: '#1a2e2b', border: '#3fb950', text: '#3fb950' },
    subagent:   { bg: '#1f2937', border: '#d29922', text: '#d29922' },
    custom:     { bg: '#21262d', border: '#8b949e', text: '#8b949e' },
  },

  STATUS_COLORS: {
    success: '#3fb950',
    error: '#f85149',
    running: '#58a6ff',
    cancelled: '#8b949e',
  },
};

/**
 * Build the graph data structure from a list of spans.
 * Returns { nodes: [...], edges: [...] }
 */
function buildGraph(spans) {
  const nodes = [];
  const edges = [];
  const nodeMap = {};  // span_id → node
  let nodeIdx = 0;

  // Phase 1: Flatten spans recursively into nodes
  function flattenSpans(spanList, parentId) {
    for (const span of spanList) {
      const node = {
        id: span.span_id,
        idx: nodeIdx++,
        kind: span.kind,
        name: span.name,
        status: span.status,
        duration_ms: span.duration_ms,
        model: span.model,
        tool_name: span.tool_name,
        subagent_name: span.subagent_name,
        fork_id: span.fork_id,
        merge_sources: span.merge_sources || [],
        parentId: parentId,
        col: 0,
        row: 0,
        // For subagent grouping
        children_ids: (span.children || []).map(c => c.span_id),
      };
      nodes.push(node);
      nodeMap[node.id] = node;

      // Edge from parent
      if (parentId && nodeMap[parentId]) {
        edges.push({ from: parentId, to: node.id, type: 'child' });
      }

      // Recurse into children
      if (span.children && span.children.length > 0) {
        flattenSpans(span.children, span.span_id);
      }
    }
  }

  flattenSpans(spans, null);

  // Phase 2: Add sequential edges between siblings at each level
  function addSiblingEdges(spanList, parentId) {
    for (let i = 1; i < spanList.length; i++) {
      const prev = spanList[i - 1];
      const curr = spanList[i];
      // Only add if not already connected via fork/merge
      if (prev.kind !== 'fork' && curr.kind !== 'merge') {
        const exists = edges.some(e => e.from === prev.span_id && e.to === curr.span_id);
        if (!exists) {
          edges.push({ from: prev.span_id, to: curr.span_id, type: 'sequence' });
        }
      }
    }
    for (const span of spanList) {
      if (span.children && span.children.length > 0) {
        addSiblingEdges(span.children, span.span_id);
      }
    }
  }

  addSiblingEdges(spans, null);

  // Phase 3: Add fork → subagent and subagent → merge edges
  const forkMap = {};  // fork_id → fork node
  const mergeMap = {};  // fork_id → merge node
  const subagentsByFork = {};  // fork_id → [subagent nodes]

  for (const node of nodes) {
    if (node.kind === 'fork' && node.fork_id) {
      forkMap[node.fork_id] = node;
    }
    if (node.kind === 'merge' && node.fork_id) {
      mergeMap[node.fork_id] = node;
    }
    if (node.kind === 'subagent' && node.fork_id) {
      if (!subagentsByFork[node.fork_id]) subagentsByFork[node.fork_id] = [];
      subagentsByFork[node.fork_id].push(node);
    }
  }

  for (const [forkId, forkNode] of Object.entries(forkMap)) {
    const subs = subagentsByFork[forkId] || [];
    for (const sub of subs) {
      const exists = edges.some(e => e.from === forkNode.id && e.to === sub.id);
      if (!exists) {
        edges.push({ from: forkNode.id, to: sub.id, type: 'fork' });
      }
    }
    const mergeNode = mergeMap[forkId];
    if (mergeNode) {
      for (const sub of subs) {
        // Find the last child of each subagent branch, or the subagent itself
        let lastInBranch = sub.id;
        if (sub.children_ids.length > 0) {
          lastInBranch = sub.children_ids[sub.children_ids.length - 1];
        }
        const exists = edges.some(e => e.from === lastInBranch && e.to === mergeNode.id);
        if (!exists) {
          edges.push({ from: lastInBranch, to: mergeNode.id, type: 'merge' });
        }
      }
    }
  }

  return { nodes, edges, nodeMap, forkMap, mergeMap, subagentsByFork };
}

/**
 * Assign column (x lane) and row (y position) to each node.
 * Fork branches fan out horizontally; merge brings them back to center.
 */
function layoutGraph(graph) {
  const { nodes, edges, forkMap, subagentsByFork, mergeMap } = graph;
  if (nodes.length === 0) return;

  const visited = new Set();

  // Lay out a subagent branch and its children vertically in one column
  function layoutBranch(subNode, col, startRow) {
    if (visited.has(subNode.id)) return startRow;
    visited.add(subNode.id);
    subNode.col = col;
    subNode.row = startRow;

    let currentRow = startRow;
    for (const childId of subNode.children_ids) {
      const child = graph.nodeMap[childId];
      if (child && !visited.has(childId)) {
        visited.add(childId);
        currentRow++;
        child.col = col;
        child.row = currentRow;
      }
    }
    return currentRow;
  }

  // Lay out a fork: fan subagents out into separate columns, then place merge below
  function layoutFork(forkNode, centerCol, startRow) {
    const subs = subagentsByFork[forkNode.fork_id] || [];
    if (subs.length === 0) return startRow;

    // Center the branches around the fork column
    const startCol = centerCol - Math.floor((subs.length - 1) / 2);
    const branchStartRow = startRow + 1;

    let maxRow = startRow;
    for (let i = 0; i < subs.length; i++) {
      const branchCol = startCol + i;
      const endRow = layoutBranch(subs[i], branchCol, branchStartRow);
      maxRow = Math.max(maxRow, endRow);
    }

    // Place merge node centered below all branches
    const mergeNode = mergeMap[forkNode.fork_id];
    if (mergeNode && !visited.has(mergeNode.id)) {
      visited.add(mergeNode.id);
      mergeNode.col = centerCol;
      mergeNode.row = maxRow + 1;
      return mergeNode.row;
    }
    return maxRow;
  }

  // Main pass: walk top-level (root) nodes sequentially
  let currentRow = 0;
  const mainCol = 0;  // will be shifted during normalization
  const topLevel = nodes.filter(n => !n.parentId);
  const rootNodes = topLevel.length > 0 ? topLevel : nodes;

  for (const node of rootNodes) {
    if (visited.has(node.id)) continue;

    if (node.kind === 'fork' && node.fork_id) {
      // Place the fork node
      visited.add(node.id);
      node.col = mainCol;
      node.row = currentRow;
      // Fan out branches and get the row after merge
      currentRow = layoutFork(node, mainCol, currentRow) + 1;
    } else if (node.kind === 'merge' || node.kind === 'subagent') {
      // Should already be placed by layoutFork; skip if so
      if (!visited.has(node.id)) {
        visited.add(node.id);
        node.col = mainCol;
        node.row = currentRow;
        currentRow++;
      }
    } else {
      visited.add(node.id);
      node.col = mainCol;
      node.row = currentRow;
      currentRow++;
    }
  }

  // Catch any orphans not reached above
  for (const node of nodes) {
    if (!visited.has(node.id)) {
      visited.add(node.id);
      node.col = mainCol;
      node.row = currentRow;
      currentRow++;
    }
  }

  // Normalize columns so minimum is 0
  const minCol = Math.min(...nodes.map(n => n.col));
  if (minCol < 0) {
    for (const node of nodes) {
      node.col -= minCol;
    }
  }
}

/**
 * Render the graph as SVG inside a container element.
 */
function renderGraph(containerId, spans) {
  const container = document.getElementById(containerId);
  if (!container || !spans || spans.length === 0) {
    if (container) {
      container.innerHTML = `
        <div style="padding: 40px; text-align: center; color: var(--text-muted); font-size: 13px;">
          No graph data. Use <code>log_fork()</code>, <code>log_subagent()</code>,
          and <code>log_merge()</code> to see the execution graph.
        </div>`;
    }
    return;
  }

  const graph = buildGraph(spans);
  layoutGraph(graph);

  const { nodes, edges, nodeMap } = graph;
  const maxCol = Math.max(...nodes.map(n => n.col), 0);
  const maxRow = Math.max(...nodes.map(n => n.row), 0);

  const svgW = GRAPH.PAD_X * 2 + (maxCol + 1) * (GRAPH.NODE_W + GRAPH.COL_GAP);
  const svgH = GRAPH.PAD_Y * 2 + (maxRow + 1) * (GRAPH.NODE_H + GRAPH.ROW_GAP);

  function nodeX(col) { return GRAPH.PAD_X + col * (GRAPH.NODE_W + GRAPH.COL_GAP); }
  function nodeY(row) { return GRAPH.PAD_Y + row * (GRAPH.NODE_H + GRAPH.ROW_GAP); }
  function nodeCX(col) { return nodeX(col) + GRAPH.NODE_W / 2; }
  function nodeCY(row) { return nodeY(row) + GRAPH.NODE_H / 2; }

  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${svgW}" height="${svgH}" viewBox="0 0 ${svgW} ${svgH}">`;

  // Defs: arrowhead marker
  svg += `<defs>
    <marker id="arrow" viewBox="0 0 10 7" refX="10" refY="3.5"
            markerWidth="8" markerHeight="6" orient="auto-start-reverse">
      <polygon points="0 0, 10 3.5, 0 7" fill="#6e7681"/>
    </marker>
    <marker id="arrow-fork" viewBox="0 0 10 7" refX="10" refY="3.5"
            markerWidth="8" markerHeight="6" orient="auto-start-reverse">
      <polygon points="0 0, 10 3.5, 0 7" fill="#3fb950"/>
    </marker>
    <marker id="arrow-merge" viewBox="0 0 10 7" refX="10" refY="3.5"
            markerWidth="8" markerHeight="6" orient="auto-start-reverse">
      <polygon points="0 0, 10 3.5, 0 7" fill="#3fb950"/>
    </marker>
  </defs>`;

  // Render edges
  for (const edge of edges) {
    const fromNode = nodeMap[edge.from];
    const toNode = nodeMap[edge.to];
    if (!fromNode || !toNode) continue;

    const x1 = nodeCX(fromNode.col);
    const y1 = nodeY(fromNode.row) + GRAPH.NODE_H;
    const x2 = nodeCX(toNode.col);
    const y2 = nodeY(toNode.row);

    const isForkEdge = edge.type === 'fork' || edge.type === 'merge';
    const strokeColor = isForkEdge ? '#3fb950' : '#30363d';
    const strokeWidth = isForkEdge ? 2 : 1.5;
    const marker = isForkEdge ? `url(#arrow-${edge.type === 'fork' ? 'fork' : 'merge'})` : 'url(#arrow)';
    const dashArray = edge.type === 'merge' ? 'stroke-dasharray="4 3"' : '';

    if (fromNode.col === toNode.col) {
      // Straight vertical line
      svg += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"
              stroke="${strokeColor}" stroke-width="${strokeWidth}" ${dashArray}
              marker-end="${marker}"/>`;
    } else {
      // Curved path for cross-column edges
      const midY = (y1 + y2) / 2;
      svg += `<path d="M${x1},${y1} C${x1},${midY} ${x2},${midY} ${x2},${y2}"
              fill="none" stroke="${strokeColor}" stroke-width="${strokeWidth}" ${dashArray}
              marker-end="${marker}"/>`;
    }
  }

  // Render nodes
  for (const node of nodes) {
    const x = nodeX(node.col);
    const y = nodeY(node.row);
    const colors = GRAPH.COLORS[node.kind] || GRAPH.COLORS.custom;
    const statusColor = GRAPH.STATUS_COLORS[node.status] || '#8b949e';

    // Node background
    svg += `<rect x="${x}" y="${y}" width="${GRAPH.NODE_W}" height="${GRAPH.NODE_H}"
            rx="${GRAPH.CORNER_R}" fill="${colors.bg}"
            stroke="${colors.border}" stroke-width="1.5"
            class="graph-node" data-span-id="${node.id}"
            style="cursor: pointer;"/>`;

    // Status indicator dot
    svg += `<circle cx="${x + 12}" cy="${y + GRAPH.NODE_H / 2}" r="4" fill="${statusColor}"/>`;

    // Kind badge
    const kindLabel = node.kind.replace('_', ' ');
    svg += `<text x="${x + 22}" y="${y + 15}" fill="${colors.text}"
            font-size="9" font-family="var(--mono)" font-weight="600"
            text-transform="uppercase" letter-spacing="0.5">${escSvg(kindLabel)}</text>`;

    // Name (truncated)
    let displayName = node.name;
    if (node.subagent_name) displayName = node.subagent_name;
    else if (node.model) displayName = node.model;
    else if (node.tool_name) displayName = node.tool_name;
    displayName = displayName.replace(/^(fork|merge|subagent|decision|tool|llm|error):/, '');
    if (displayName.length > 22) displayName = displayName.slice(0, 20) + '…';

    svg += `<text x="${x + 22}" y="${y + 32}" fill="#e6edf3"
            font-size="12" font-family="var(--sans)" font-weight="500">${escSvg(displayName)}</text>`;

    // Duration label (right side)
    if (node.duration_ms != null) {
      const dur = node.duration_ms < 1000
        ? Math.round(node.duration_ms) + 'ms'
        : (node.duration_ms / 1000).toFixed(1) + 's';
      svg += `<text x="${x + GRAPH.NODE_W - 10}" y="${y + 28}" fill="#6e7681"
              font-size="10" font-family="var(--mono)" text-anchor="end">${dur}</text>`;
    }

    // Fork/merge icon
    if (node.kind === 'fork') {
      svg += `<text x="${x + GRAPH.NODE_W - 14}" y="${y + 16}" fill="${colors.text}"
              font-size="14" text-anchor="end">⑂</text>`;
    } else if (node.kind === 'merge') {
      svg += `<text x="${x + GRAPH.NODE_W - 14}" y="${y + 16}" fill="${colors.text}"
              font-size="14" text-anchor="end">⑃</text>`;
    }
  }

  svg += '</svg>';

  container.innerHTML = `<div style="overflow: auto; max-height: 600px; border: 1px solid var(--border); border-radius: var(--radius); background: var(--bg-primary);">${svg}</div>`;

  // Add click handlers for nodes
  container.querySelectorAll('.graph-node').forEach(el => {
    el.addEventListener('click', () => {
      const spanId = el.getAttribute('data-span-id');
      // Highlight the span in the timeline
      const timelineDetails = document.querySelectorAll('.span-node');
      timelineDetails.forEach(td => {
        td.style.outline = '';
      });
      // Find and scroll to the matching span in timeline
      const allNodes = document.querySelectorAll('.span-node');
      for (const sn of allNodes) {
        const nameEl = sn.querySelector('.span-name');
        if (nameEl) {
          // Toggle details open
          const details = sn.querySelector('.span-details');
          if (details) details.classList.add('open');
        }
      }
    });
  });
}

function escSvg(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
