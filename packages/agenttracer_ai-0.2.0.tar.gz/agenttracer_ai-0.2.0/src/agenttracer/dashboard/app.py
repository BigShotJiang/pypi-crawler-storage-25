"""Flask web dashboard for AgentTracer."""

from __future__ import annotations

import json
import os
from pathlib import Path

from flask import Flask, render_template, jsonify, request

from ..storage.sqlite import SQLiteStorage
from ..exporters.json_export import export_json
from ..exporters.markdown_export import export_markdown


def create_app(storage_dir: str = "./agenttracer_data") -> Flask:
    """Create the Flask dashboard app."""
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    static_dir = os.path.join(os.path.dirname(__file__), "static")

    app = Flask(
        __name__,
        template_folder=template_dir,
        static_folder=static_dir,
    )

    db = SQLiteStorage(Path(storage_dir) / "traces.db")

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/api/traces")
    def api_traces():
        """List traces with filtering."""
        agent_name = request.args.get("agent_name")
        status = request.args.get("status")
        has_errors = request.args.get("has_errors")
        min_cost = request.args.get("min_cost", type=float)
        max_cost = request.args.get("max_cost", type=float)
        min_duration = request.args.get("min_duration", type=float)
        max_duration = request.args.get("max_duration", type=float)
        tags = request.args.get("tags", "").split(",") if request.args.get("tags") else None
        limit = request.args.get("limit", 100, type=int)
        offset = request.args.get("offset", 0, type=int)

        kwargs = {
            "limit": limit,
            "offset": offset,
        }
        if agent_name:
            kwargs["agent_name"] = agent_name
        if status:
            kwargs["status"] = status
        if has_errors is not None:
            kwargs["has_errors"] = has_errors.lower() == "true"
        if min_cost is not None:
            kwargs["min_cost"] = min_cost
        if max_cost is not None:
            kwargs["max_cost"] = max_cost
        if min_duration is not None:
            kwargs["min_duration_ms"] = min_duration
        if max_duration is not None:
            kwargs["max_duration_ms"] = max_duration
        if tags:
            kwargs["tags"] = tags

        traces = db.search(**kwargs)

        # Return summary view (without full span trees)
        result = []
        for t in traces:
            result.append({
                "trace_id": t.trace_id,
                "agent_name": t.agent_name,
                "status": t.status.value,
                "start_time": t.start_time,
                "duration_ms": t.duration_ms,
                "total_tokens": t.total_tokens,
                "total_cost": t.total_cost,
                "total_steps": t.total_steps,
                "total_model_calls": t.total_model_calls,
                "total_tool_calls": t.total_tool_calls,
                "total_errors": t.total_errors,
                "tags": t.tags,
                "error": t.error,
            })

        return jsonify(result)

    @app.route("/api/traces/<trace_id>")
    def api_trace_detail(trace_id):
        """Get full trace with spans."""
        trace = db.load_trace(trace_id)
        if not trace:
            return jsonify({"error": "Trace not found"}), 404
        return jsonify(trace.to_dict())

    @app.route("/api/traces/<trace_id>/export/json")
    def api_export_json(trace_id):
        """Export trace as JSON."""
        trace = db.load_trace(trace_id)
        if not trace:
            return jsonify({"error": "Trace not found"}), 404
        return app.response_class(
            export_json(trace),
            mimetype="application/json",
            headers={"Content-Disposition": f"attachment; filename=trace-{trace_id}.json"},
        )

    @app.route("/api/traces/<trace_id>/export/markdown")
    def api_export_markdown(trace_id):
        """Export trace as Markdown."""
        trace = db.load_trace(trace_id)
        if not trace:
            return jsonify({"error": "Trace not found"}), 404
        return app.response_class(
            export_markdown(trace),
            mimetype="text/markdown",
            headers={"Content-Disposition": f"attachment; filename=trace-{trace_id}.md"},
        )

    @app.route("/api/stats")
    def api_stats():
        """Get aggregate stats."""
        return jsonify(db.get_stats())

    @app.route("/api/agents")
    def api_agents():
        """Get list of agent names."""
        return jsonify(db.get_agent_names())

    return app
