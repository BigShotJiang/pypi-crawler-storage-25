"""SQLite storage backend for traces with indexed queries."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Optional

from ..models import Trace, TraceStatus


class SQLiteStorage:
    """SQLite storage with indexed columns for fast filtering."""

    def __init__(self, path: str | Path = "traces.db"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        return self._conn

    def _init_db(self):
        """Create tables and indexes."""
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS traces (
                trace_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                status TEXT NOT NULL,
                start_time REAL NOT NULL,
                end_time REAL,
                duration_ms REAL,
                total_tokens INTEGER DEFAULT 0,
                total_cost REAL DEFAULT 0.0,
                total_steps INTEGER DEFAULT 0,
                total_model_calls INTEGER DEFAULT 0,
                total_tool_calls INTEGER DEFAULT 0,
                total_errors INTEGER DEFAULT 0,
                tags TEXT DEFAULT '[]',
                error TEXT,
                data TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_traces_agent ON traces(agent_name);
            CREATE INDEX IF NOT EXISTS idx_traces_status ON traces(status);
            CREATE INDEX IF NOT EXISTS idx_traces_start ON traces(start_time);
            CREATE INDEX IF NOT EXISTS idx_traces_duration ON traces(duration_ms);
            CREATE INDEX IF NOT EXISTS idx_traces_cost ON traces(total_cost);
            CREATE INDEX IF NOT EXISTS idx_traces_errors ON traces(total_errors);
        """)
        self.conn.commit()

    def save(self, trace: Trace) -> None:
        """Insert or replace a trace."""
        data = json.dumps(trace.to_dict(), default=str)
        self.conn.execute(
            """INSERT OR REPLACE INTO traces
               (trace_id, agent_name, status, start_time, end_time,
                duration_ms, total_tokens, total_cost, total_steps,
                total_model_calls, total_tool_calls, total_errors,
                tags, error, data)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                trace.trace_id,
                trace.agent_name,
                trace.status.value,
                trace.start_time,
                trace.end_time,
                trace.duration_ms,
                trace.total_tokens,
                trace.total_cost,
                trace.total_steps,
                trace.total_model_calls,
                trace.total_tool_calls,
                trace.total_errors,
                json.dumps(trace.tags),
                trace.error,
                data,
            ),
        )
        self.conn.commit()

    def load_trace(self, trace_id: str) -> Optional[Trace]:
        """Load a single trace by ID."""
        row = self.conn.execute(
            "SELECT data FROM traces WHERE trace_id = ?", (trace_id,)
        ).fetchone()
        if row:
            return Trace.from_dict(json.loads(row["data"]))
        return None

    def load_all(self, limit: int = 200, offset: int = 0) -> list[Trace]:
        """Load traces ordered by most recent."""
        rows = self.conn.execute(
            "SELECT data FROM traces ORDER BY start_time DESC LIMIT ? OFFSET ?",
            (limit, offset),
        ).fetchall()
        return [Trace.from_dict(json.loads(r["data"])) for r in rows]

    def search(
        self,
        agent_name: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        min_duration_ms: float | None = None,
        max_duration_ms: float | None = None,
        min_cost: float | None = None,
        max_cost: float | None = None,
        has_errors: bool | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Trace]:
        """Search traces with indexed filters."""
        conditions = []
        params: list = []

        if agent_name:
            conditions.append("agent_name = ?")
            params.append(agent_name)
        if status:
            conditions.append("status = ?")
            params.append(status)
        if min_duration_ms is not None:
            conditions.append("duration_ms >= ?")
            params.append(min_duration_ms)
        if max_duration_ms is not None:
            conditions.append("duration_ms <= ?")
            params.append(max_duration_ms)
        if min_cost is not None:
            conditions.append("total_cost >= ?")
            params.append(min_cost)
        if max_cost is not None:
            conditions.append("total_cost <= ?")
            params.append(max_cost)
        if has_errors is True:
            conditions.append("total_errors > 0")
        elif has_errors is False:
            conditions.append("total_errors = 0")
        if tags:
            for tag in tags:
                conditions.append("tags LIKE ?")
                params.append(f"%{tag}%")

        where = " AND ".join(conditions) if conditions else "1=1"
        query = f"SELECT data FROM traces WHERE {where} ORDER BY start_time DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        rows = self.conn.execute(query, params).fetchall()
        return [Trace.from_dict(json.loads(r["data"])) for r in rows]

    def count(self, agent_name: str | None = None, status: str | None = None) -> int:
        """Count traces matching filters."""
        conditions = []
        params: list = []
        if agent_name:
            conditions.append("agent_name = ?")
            params.append(agent_name)
        if status:
            conditions.append("status = ?")
            params.append(status)
        where = " AND ".join(conditions) if conditions else "1=1"
        row = self.conn.execute(
            f"SELECT COUNT(*) as cnt FROM traces WHERE {where}", params
        ).fetchone()
        return row["cnt"] if row else 0

    def get_agent_names(self) -> list[str]:
        """Get all distinct agent names."""
        rows = self.conn.execute(
            "SELECT DISTINCT agent_name FROM traces ORDER BY agent_name"
        ).fetchall()
        return [r["agent_name"] for r in rows]

    def get_stats(self) -> dict:
        """Get aggregate stats across all traces."""
        row = self.conn.execute("""
            SELECT
                COUNT(*) as total_traces,
                COALESCE(SUM(total_tokens), 0) as total_tokens,
                COALESCE(SUM(total_cost), 0.0) as total_cost,
                COALESCE(AVG(duration_ms), 0.0) as avg_duration_ms,
                COALESCE(SUM(total_errors), 0) as total_errors,
                COUNT(DISTINCT agent_name) as unique_agents
            FROM traces
        """).fetchone()
        return dict(row) if row else {}

    def clear(self) -> None:
        """Delete all traces."""
        self.conn.execute("DELETE FROM traces")
        self.conn.commit()

    def close(self):
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
