"""JSONL file storage backend for traces."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

from ..models import Trace


class JSONLStorage:
    """Append-only JSONL storage for traces."""

    def __init__(self, path: str | Path = "traces.jsonl"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def save(self, trace: Trace) -> None:
        """Append a trace to the JSONL file."""
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(trace.to_dict(), default=str) + "\n")

    def load_all(self) -> list[Trace]:
        """Load all traces from the JSONL file."""
        if not self.path.exists():
            return []
        traces = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        traces.append(Trace.from_dict(json.loads(line)))
                    except (json.JSONDecodeError, KeyError):
                        continue
        return traces

    def load_trace(self, trace_id: str) -> Optional[Trace]:
        """Load a single trace by ID."""
        for trace in self.load_all():
            if trace.trace_id == trace_id:
                return trace
        return None

    def search(
        self,
        agent_name: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
        limit: int = 100,
    ) -> list[Trace]:
        """Search traces with filters."""
        traces = self.load_all()
        results = []
        for trace in traces:
            if agent_name and trace.agent_name != agent_name:
                continue
            if status and trace.status.value != status:
                continue
            if tags and not all(t in trace.tags for t in tags):
                continue
            results.append(trace)
        return results[-limit:]

    def clear(self) -> None:
        """Clear all stored traces."""
        if self.path.exists():
            self.path.unlink()
