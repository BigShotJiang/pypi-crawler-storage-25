"""CLI entry point: python -m agenttracer [command]"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="agenttracer",
        description="AgentTracer — Observability for AI agents",
    )
    sub = parser.add_subparsers(dest="command")

    # Dashboard
    dash = sub.add_parser("dashboard", help="Launch the web dashboard")
    dash.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    dash.add_argument("--port", type=int, default=8484, help="Port to bind to")
    dash.add_argument("--storage-dir", default="./agenttracer_data", help="Storage directory")
    dash.add_argument("--debug", action="store_true", help="Enable debug mode")

    # Export
    exp = sub.add_parser("export", help="Export a trace")
    exp.add_argument("trace_id", help="Trace ID to export")
    exp.add_argument("--format", choices=["json", "markdown"], default="json")
    exp.add_argument("--output", "-o", help="Output file path")
    exp.add_argument("--storage-dir", default="./agenttracer_data")

    # List
    lst = sub.add_parser("list", help="List recent traces")
    lst.add_argument("--agent", help="Filter by agent name")
    lst.add_argument("--status", help="Filter by status")
    lst.add_argument("--limit", type=int, default=20)
    lst.add_argument("--storage-dir", default="./agenttracer_data")

    args = parser.parse_args()

    if args.command == "dashboard" or args.command is None:
        from . import dashboard
        dashboard(
            storage_dir=getattr(args, "storage_dir", "./agenttracer_data"),
            host=getattr(args, "host", "127.0.0.1"),
            port=getattr(args, "port", 8484),
            debug=getattr(args, "debug", False),
        )

    elif args.command == "export":
        from .storage.sqlite import SQLiteStorage
        from .exporters import export_json, export_markdown
        from pathlib import Path

        db = SQLiteStorage(Path(args.storage_dir) / "traces.db")
        trace = db.load_trace(args.trace_id)
        if not trace:
            print(f"Trace {args.trace_id} not found")
            sys.exit(1)

        if args.format == "json":
            result = export_json(trace, args.output)
        else:
            result = export_markdown(trace, args.output)

        if not args.output:
            print(result)
        else:
            print(f"Exported to {args.output}")

    elif args.command == "list":
        from .storage.sqlite import SQLiteStorage
        from pathlib import Path
        import datetime

        db = SQLiteStorage(Path(args.storage_dir) / "traces.db")
        kwargs = {"limit": args.limit}
        if args.agent:
            kwargs["agent_name"] = args.agent
        if args.status:
            kwargs["status"] = args.status

        traces = db.search(**kwargs)
        if not traces:
            print("No traces found.")
            return

        # Table header
        print(f"{'ID':<18} {'Agent':<22} {'Status':<10} {'Duration':<10} "
              f"{'Tokens':<8} {'Cost':<10} {'Time'}")
        print("─" * 100)

        for t in traces:
            ts = datetime.datetime.fromtimestamp(t.start_time).strftime("%m/%d %H:%M")
            dur = f"{t.duration_ms:.0f}ms" if t.duration_ms else "—"
            cost = f"${t.total_cost:.4f}" if t.total_cost else "—"
            print(f"{t.trace_id:<18} {t.agent_name:<22} {t.status.value:<10} "
                  f"{dur:<10} {t.total_tokens:<8} {cost:<10} {ts}")


if __name__ == "__main__":
    main()
