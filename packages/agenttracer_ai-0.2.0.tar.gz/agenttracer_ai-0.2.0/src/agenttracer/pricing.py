"""Token counting and cost estimation for common LLM providers."""

from __future__ import annotations

from .models import TokenUsage, CostEstimate


# Pricing per 1M tokens: (prompt, completion)
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # OpenAI
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4": (30.00, 60.00),
    "gpt-3.5-turbo": (0.50, 1.50),
    "o1": (15.00, 60.00),
    "o1-mini": (3.00, 12.00),
    "o1-pro": (150.00, 600.00),
    "o3": (10.00, 40.00),
    "o3-mini": (1.10, 4.40),
    "o4-mini": (1.10, 4.40),
    # Anthropic
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-3.5-sonnet": (3.00, 15.00),
    "claude-sonnet-4-20250514": (3.00, 15.00),
    "claude-4-sonnet": (3.00, 15.00),
    "claude-3-5-haiku-20241022": (0.80, 4.00),
    "claude-3.5-haiku": (0.80, 4.00),
    "claude-3-opus-20240229": (15.00, 75.00),
    "claude-3-opus": (15.00, 75.00),
    "claude-opus-4-20250514": (15.00, 75.00),
    "claude-4-opus": (15.00, 75.00),
    # Google
    "gemini-2.0-flash": (0.10, 0.40),
    "gemini-2.5-pro": (1.25, 10.00),
    "gemini-2.5-flash": (0.15, 0.60),
    # Open-source / others
    "llama-3.1-70b": (0.70, 0.80),
    "llama-3.1-8b": (0.10, 0.10),
    "mixtral-8x7b": (0.50, 0.50),
    "deepseek-v3": (0.27, 1.10),
    "deepseek-r1": (0.55, 2.19),
}

# Aliases: map common short names to canonical names
_ALIASES: dict[str, str] = {
    "gpt4o": "gpt-4o",
    "gpt4": "gpt-4",
    "gpt-4o-2024-11-20": "gpt-4o",
    "gpt-4o-2024-08-06": "gpt-4o",
    "sonnet": "claude-3.5-sonnet",
    "haiku": "claude-3.5-haiku",
    "opus": "claude-3-opus",
    "claude-sonnet": "claude-3.5-sonnet",
    "claude-haiku": "claude-3.5-haiku",
    "claude-opus": "claude-3-opus",
}


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token for English text."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def estimate_tokens_messages(messages: list[dict]) -> int:
    """Estimate tokens from a list of chat messages."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict):
                    total += estimate_tokens(part.get("text", ""))
                else:
                    total += estimate_tokens(str(part))
        # Role and message overhead
        total += 4
    return total


def resolve_model_name(model: str) -> str:
    """Resolve aliases and normalize model name for pricing lookup."""
    model = model.strip().lower()
    if model in _ALIASES:
        return _ALIASES[model]
    return model


def estimate_cost(
    model: str,
    token_usage: TokenUsage | None = None,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
) -> CostEstimate:
    """Estimate cost for a model call."""
    model_key = resolve_model_name(model)

    if token_usage:
        prompt_tokens = token_usage.prompt_tokens
        completion_tokens = token_usage.completion_tokens

    pricing = MODEL_PRICING.get(model_key)
    if not pricing:
        # Try prefix matching
        for key, val in MODEL_PRICING.items():
            if model_key.startswith(key) or key.startswith(model_key):
                pricing = val
                break

    if not pricing:
        return CostEstimate(model=model)

    prompt_price, completion_price = pricing
    prompt_cost = (prompt_tokens / 1_000_000) * prompt_price
    completion_cost = (completion_tokens / 1_000_000) * completion_price

    return CostEstimate(
        prompt_cost=round(prompt_cost, 8),
        completion_cost=round(completion_cost, 8),
        total_cost=round(prompt_cost + completion_cost, 8),
        currency="USD",
        model=model,
    )
