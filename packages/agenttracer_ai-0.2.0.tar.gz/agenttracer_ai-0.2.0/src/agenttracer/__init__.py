"""AgentTracer — Framework-agnostic observability for AI agents.

Quick start:
    import agenttracer as at

    tracer = at.AgentTracer()

    with tracer.trace("my-agent", input_data="Hello") as t:
        tracer.log_model_call(t, model="gpt-4o", input_data="Hello", output_data="Hi!")
        tracer.log_tool_call(t, tool_name="search", tool_args={"q": "test"}, tool_result="result")
        tracer.log_decision(t, "route", options=["A", "B"], chosen="A", reasoning="faster")

    # Launch the dashboard
    at.dashboard(port=8484)
"""

__version__ = "0.2.0"

from .models import (
    Trace,
    Span,
    SpanKind,
    SpanStatus,
    TraceStatus,
    TokenUsage,
    CostEstimate,
)
from .tracer import (
    AgentTracer,
    get_tracer,
    start_trace,
    end_trace,
    log_step,
    log_tool_call,
    log_model_call,
    log_decision,
    log_fork,
    log_subagent,
    log_merge,
)
from .exporters import export_json, export_markdown
from .pricing import estimate_cost, estimate_tokens, MODEL_PRICING


def dashboard(
    storage_dir: str = "./agenttracer_data",
    host: str = "127.0.0.1",
    port: int = 8484,
    debug: bool = False,
):
    """Launch the AgentTracer web dashboard."""
    from .dashboard.app import create_app
    app = create_app(storage_dir=storage_dir)
    print(f"\n  AgentTracer Dashboard → http://{host}:{port}\n")
    app.run(host=host, port=port, debug=debug)


__all__ = [
    # Core
    "AgentTracer",
    "Trace",
    "Span",
    "SpanKind",
    "SpanStatus",
    "TraceStatus",
    "TokenUsage",
    "CostEstimate",
    # Functions
    "get_tracer",
    "start_trace",
    "end_trace",
    "log_step",
    "log_tool_call",
    "log_model_call",
    "log_decision",
    # Fork/merge
    "log_fork",
    "log_subagent",
    "log_merge",
    # Export
    "export_json",
    "export_markdown",
    # Pricing
    "estimate_cost",
    "estimate_tokens",
    "MODEL_PRICING",
    # Dashboard
    "dashboard",
]
