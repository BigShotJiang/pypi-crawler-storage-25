from setuptools import setup, find_packages

setup(
    name="fcalibration_gpu",
    version="0.0.1",
    description="fcalibration_gpu: fuzzy probability calibration, GPU version",
    author="famulan",
    author_email="olga.a.filimonova@gmail.com",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    license="MIT",
    classifiers=[
        "Development Status :: 1 - Planning",
    ],
)