"""
HTTP Client - Base HTTP functionality for Compresr SDK.

Internal module providing HTTP methods for API calls.
Do not use directly - use CompressionClient or FilterClient.
"""

import json
import ssl
from typing import Any, Dict, Generator, NoReturn, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

try:
    import httpx

    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

from ..config import API_CONFIG, HEADERS, STATUS_CODES
from ..exceptions import (
    ApiKeyBudgetError,
    AuthenticationError,
    BudgetLimitError,
    CompresrError,
)
from ..exceptions import ConnectionError as CompresrConnectionError
from ..exceptions import (
    ContentPolicyError,
    ContextWindowExceededError,
    DailyLimitError,
    InsufficientCreditsError,
    ModelNotFoundError,
    RateLimitError,
    ScopeError,
    ServerError,
    ServiceUnavailableError,
    TargetAuthenticationError,
    ValidationError,
)

# Get version dynamically
try:
    from importlib.metadata import version as get_version

    SDK_VERSION = get_version("compresr")
except Exception:
    SDK_VERSION = "0.0.0-dev"


class HTTPClient:
    """Internal HTTP client for Compresr API."""

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
    ):
        if not api_key:
            raise AuthenticationError("API key is required")
        if not api_key.startswith(API_CONFIG.API_KEY_PREFIX):
            raise AuthenticationError(
                f"Invalid API key format. Keys must start with '{API_CONFIG.API_KEY_PREFIX}'"
            )

        self._api_key = api_key
        self._base_url = (base_url or API_CONFIG.BASE_URL).rstrip("/")
        self._timeout = timeout or API_CONFIG.DEFAULT_TIMEOUT
        self._async_client: Optional["httpx.AsyncClient"] = None

    @property
    def _headers(self) -> Dict[str, str]:
        return {
            HEADERS.API_KEY: self._api_key,
            HEADERS.CONTENT_TYPE: HEADERS.JSON,
            HEADERS.ACCEPT: HEADERS.JSON,
            "User-Agent": f"compresr-python-sdk/{SDK_VERSION}",
        }

    def _url(self, endpoint: str) -> str:
        # Ensure proper URL joining (no double slashes)
        return f"{self._base_url}{endpoint}"

    def _extract_error_message(self, body: Dict[str, Any]) -> str:
        """Extract user-friendly error message from backend response."""
        # Try common error fields
        if "error" in body:
            return str(body["error"])
        if "detail" in body:
            detail = body["detail"]
            # Pydantic validation errors come as list of dicts
            if isinstance(detail, list):
                errors = []
                for err in detail:
                    if isinstance(err, dict):
                        loc = err.get("loc", [])
                        msg = err.get("msg", "")
                        field = ".".join(str(x) for x in loc) if loc else ""
                        errors.append(f"{field}: {msg}" if field else msg)
                    else:
                        errors.append(str(err))
                return "; ".join(errors) if errors else "Validation error"
            return str(detail)
        if "message" in body:
            return str(body["message"])
        return "Unknown error"

    def _handle_error(self, status_code: int, body: Dict[str, Any]) -> NoReturn:
        """Handle error response with user-friendly messages."""
        msg = self._extract_error_message(body)
        code = body.get("code", "")

        # Check error code first for specific error types
        if code == "insufficient_credits":
            raise InsufficientCreditsError(
                f"Insufficient credits: {msg}",
                credits_required=body.get("credits_required"),
                credits_remaining=body.get("credits_remaining"),
                response_data=body,
            )
        elif code == "budget_limit_reached":
            raise BudgetLimitError(
                f"Budget limit reached: {msg}",
                current_budget=body.get("current_budget"),
                budget_used=body.get("budget_used"),
                response_data=body,
            )
        elif code == "api_key_budget_exceeded":
            raise ApiKeyBudgetError(
                f"API key budget exceeded: {msg}",
                api_key_budget=body.get("api_key_budget"),
                api_key_used=body.get("api_key_used"),
                response_data=body,
            )
        elif code == "daily_limit_exceeded":
            raise DailyLimitError(
                f"Daily limit exceeded: {msg}",
                daily_limit=body.get("daily_limit"),
                requests_used=body.get("requests_used"),
                response_data=body,
            )
        elif code == "model_not_found":
            raise ModelNotFoundError(
                f"Model not found: {msg}",
                model_name=body.get("model_name"),
                available_models=body.get(
                    "available_models", body.get("details", {}).get("available_models")
                ),
                response_data=body,
            )
        elif code == "context_window_exceeded":
            raise ContextWindowExceededError(
                f"Context window exceeded: {msg}",
                max_tokens=body.get("max_tokens"),
                actual_tokens=body.get("actual_tokens"),
                response_data=body,
            )
        elif code == "content_policy_violation":
            raise ContentPolicyError(
                f"Content policy violation: {msg}",
                provider=body.get("provider"),
                response_data=body,
            )
        elif code == "target_authentication_error":
            raise TargetAuthenticationError(
                f"Target API key invalid: {msg}",
                provider=body.get("provider"),
                response_data=body,
            )
        elif code == "service_unavailable":
            raise ServiceUnavailableError(
                f"Service unavailable: {msg}",
                service=body.get("service"),
                retry_after=body.get("retry_after"),
                response_data=body,
            )

        # Fall back to HTTP status code handling
        if status_code == STATUS_CODES.UNAUTHORIZED:
            raise AuthenticationError(
                f"Authentication failed: {msg}. Check your API key is valid.", response_data=body
            )
        elif status_code == STATUS_CODES.FORBIDDEN:
            raise ScopeError(
                f"Permission denied: {msg}. Your API key may lack the required scope.",
                response_data=body,
            )
        elif status_code == STATUS_CODES.VALIDATION_ERROR:
            field = body.get("field")
            raise ValidationError(
                f"Invalid request: {msg}",
                field=field if isinstance(field, str) else None,
                response_data=body,
            )
        elif status_code == STATUS_CODES.RATE_LIMITED:
            retry = body.get("retry_after")
            retry_msg = f" Retry after {retry} seconds." if retry else ""
            raise RateLimitError(
                f"Rate limit exceeded: {msg}.{retry_msg}",
                retry_after=retry if isinstance(retry, int) else None,
                response_data=body,
            )
        elif status_code == 402:  # Payment Required
            raise InsufficientCreditsError(
                f"Payment required: {msg}",
                response_data=body,
            )
        elif status_code == 503:  # Service Unavailable
            raise ServiceUnavailableError(
                f"Service temporarily unavailable: {msg}",
                retry_after=body.get("retry_after"),
                response_data=body,
            )
        elif status_code >= 500:
            raise ServerError(
                f"Server error: {msg}. Please try again later or contact support.",
                response_data=body,
            )
        else:
            raise CompresrError(f"Request failed ({status_code}): {msg}", response_data=body)

    # ==================== Sync ====================

    def post(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Sync POST request."""
        url = self._url(endpoint)
        body = json.dumps(data).encode("utf-8")
        req = Request(url, data=body, headers=self._headers, method="POST")

        try:
            ctx = ssl.create_default_context()
            with urlopen(req, timeout=self._timeout, context=ctx) as resp:
                result: Dict[str, Any] = json.loads(resp.read().decode("utf-8"))
                return result
        except HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8"))
            except Exception:
                err = {"error": str(e), "detail": e.reason}
            self._handle_error(e.code, err)
        except URLError as e:
            raise CompresrConnectionError(f"Connection failed: {e.reason}")
        except TimeoutError:
            raise CompresrConnectionError("Request timed out")
        except Exception as e:
            raise CompresrError(f"Request failed: {str(e)}")

    def get(self, endpoint: str) -> Dict[str, Any]:
        """Sync GET request."""
        url = self._url(endpoint)
        req = Request(url, headers=self._headers, method="GET")

        try:
            ctx = ssl.create_default_context()
            with urlopen(req, timeout=self._timeout, context=ctx) as resp:
                result: Dict[str, Any] = json.loads(resp.read().decode("utf-8"))
                return result
        except HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8"))
            except Exception:
                err = {"error": str(e), "detail": e.reason}
            self._handle_error(e.code, err)
        except URLError as e:
            raise CompresrConnectionError(f"Connection failed: {e.reason}")
        except TimeoutError:
            raise CompresrConnectionError("Request timed out")
        except Exception as e:
            raise CompresrError(f"Request failed: {str(e)}")

    def delete(self, endpoint: str) -> Dict[str, Any]:
        """Sync DELETE request."""
        url = self._url(endpoint)
        req = Request(url, headers=self._headers, method="DELETE")

        try:
            ctx = ssl.create_default_context()
            with urlopen(req, timeout=self._timeout, context=ctx) as resp:
                result: Dict[str, Any] = json.loads(resp.read().decode("utf-8"))
                return result
        except HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8"))
            except Exception:
                err = {"error": str(e), "detail": e.reason}
            self._handle_error(e.code, err)
        except URLError as e:
            raise CompresrConnectionError(f"Connection failed: {e.reason}")
        except TimeoutError:
            raise CompresrConnectionError("Request timed out")
        except Exception as e:
            raise CompresrError(f"Request failed: {str(e)}")

    def post_multipart(self, endpoint: str, files: Dict[str, Any]) -> Dict[str, Any]:
        """Sync multipart POST request (requires httpx)."""
        if not HTTPX_AVAILABLE:
            raise ImportError("Multipart upload requires httpx: pip install httpx")

        url = self._url(endpoint)
        # Use only auth + user-agent headers; httpx sets Content-Type for multipart
        mp_headers = {
            "X-API-Key": self._api_key,
            "User-Agent": f"compresr-python-sdk/{SDK_VERSION}",
        }

        try:
            with httpx.Client(timeout=self._timeout) as client:
                resp = client.post(url, files=files, headers=mp_headers)
                body: Dict[str, Any] = resp.json()
                if resp.status_code >= 400:
                    self._handle_error(resp.status_code, body)
                return body
        except httpx.TimeoutException:
            raise CompresrConnectionError("Request timed out")
        except httpx.ConnectError as e:
            raise CompresrConnectionError(f"Connection failed: {str(e)}")

    def stream(self, endpoint: str, data: Dict[str, Any]) -> Generator[str, None, None]:
        """Sync streaming POST request."""
        if not HTTPX_AVAILABLE:
            raise ImportError("Streaming requires httpx: pip install httpx")

        url = self._url(endpoint)
        # Add Accept header for SSE
        headers = {**self._headers, "Accept": "text/event-stream"}

        with httpx.Client(timeout=self._timeout) as client:
            with client.stream("POST", url, json=data, headers=headers) as resp:
                if resp.status_code >= 400:
                    try:
                        err = resp.json()
                    except Exception:
                        err = {"error": f"HTTP {resp.status_code}"}
                    self._handle_error(resp.status_code, err)

                # Use iter_lines() for proper SSE line-by-line parsing
                for line in resp.iter_lines():
                    if line.startswith("data: "):
                        chunk = line[6:]
                        if chunk == "[DONE]":
                            return
                        try:
                            parsed = json.loads(chunk)
                            if "content" in parsed:
                                yield parsed["content"]
                        except json.JSONDecodeError:
                            # Yield raw content if not JSON
                            if chunk:
                                yield chunk

    # ==================== Async ====================

    async def post_async(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Async POST request."""
        if not HTTPX_AVAILABLE:
            raise ImportError("Async requires httpx: pip install httpx")

        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self._timeout, headers=self._headers)

        url = self._url(endpoint)
        try:
            resp = await self._async_client.post(url, json=data)
            body: Dict[str, Any] = resp.json()
            if resp.status_code >= 400:
                self._handle_error(resp.status_code, body)
            return body
        except httpx.TimeoutException:
            raise CompresrConnectionError("Request timed out")
        except httpx.ConnectError as e:
            raise CompresrConnectionError(f"Connection failed: {str(e)}")

    async def get_async(self, endpoint: str) -> Dict[str, Any]:
        """Async GET request."""
        if not HTTPX_AVAILABLE:
            raise ImportError("Async requires httpx: pip install httpx")

        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self._timeout, headers=self._headers)

        url = self._url(endpoint)
        try:
            resp = await self._async_client.get(url)
            body: Dict[str, Any] = resp.json()
            if resp.status_code >= 400:
                self._handle_error(resp.status_code, body)
            return body
        except httpx.TimeoutException:
            raise CompresrConnectionError("Request timed out")
        except httpx.ConnectError as e:
            raise CompresrConnectionError(f"Connection failed: {str(e)}")

    async def delete_async(self, endpoint: str) -> Dict[str, Any]:
        """Async DELETE request."""
        if not HTTPX_AVAILABLE:
            raise ImportError("Async requires httpx: pip install httpx")

        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self._timeout, headers=self._headers)

        url = self._url(endpoint)
        try:
            resp = await self._async_client.delete(url)
            body: Dict[str, Any] = resp.json()
            if resp.status_code >= 400:
                self._handle_error(resp.status_code, body)
            return body
        except httpx.TimeoutException:
            raise CompresrConnectionError("Request timed out")
        except httpx.ConnectError as e:
            raise CompresrConnectionError(f"Connection failed: {str(e)}")

    async def close(self) -> None:
        """Close async client."""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None
