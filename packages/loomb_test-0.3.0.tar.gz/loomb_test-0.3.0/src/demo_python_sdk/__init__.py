__version__ = "0.3.0"
MAGIC_NUMBER = 21


def get_magic_number() -> int:
    return MAGIC_NUMBER
