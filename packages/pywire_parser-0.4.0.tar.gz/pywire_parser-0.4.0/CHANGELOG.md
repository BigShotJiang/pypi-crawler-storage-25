# Changelog

## [0.4.0](https://github.com/pywire/pywire/compare/pywire-parser-v0.3.0...pywire-parser-v0.4.0) (2026-04-20)


### Features

* **pywire-parser:** AuthAttribute AST node for {\$auth} blocks ([1670cdf](https://github.com/pywire/pywire/commit/1670cdf726e66cda4b0c1930f701aabc691f5b2a))

## [0.3.0](https://github.com/pywire/pywire/compare/pywire-parser-v0.2.1...pywire-parser-v0.3.0) (2026-04-20)


### Features

* render regions (snippets, $render, $head) — retire slots ([#127](https://github.com/pywire/pywire/issues/127)) ([d2b48b6](https://github.com/pywire/pywire/commit/d2b48b635a4263b1568b0302e09875a5557c8004))

## [0.2.1](https://github.com/pywire/pywire/compare/pywire-parser-v0.2.0...pywire-parser-v0.2.1) (2026-04-13)


### Bug Fixes

* **pywire-parser:** initial PyPI publish — update package description ([490c880](https://github.com/pywire/pywire/commit/490c880b2634b5852994ae9f01575e4b71d79fd4))

## [0.2.0](https://github.com/pywire/pywire/compare/pywire-parser-v0.1.0...pywire-parser-v0.2.0) (2026-04-13)


### Features

* pure Python build — pywire-parser, Pyodide adapter, Cloudflare Workers deploy ([#87](https://github.com/pywire/pywire/issues/87)) ([3c713d2](https://github.com/pywire/pywire/commit/3c713d2c68b6098c51780f3a9820e8bd7536f898))


### Bug Fixes

* **prettier-plugin-pywire:** bump for consistency ([33fc161](https://github.com/pywire/pywire/commit/33fc1613c5a70dfc4e8b00d1da3d99f2dc849925))
* **pywire-language-server:** bump for release ([88aa449](https://github.com/pywire/pywire/commit/88aa449a1a55ece6145f1f21bc7b1ca807e394ca))
* **pywire-language-server:** fix PyPI publish by using explicit build output dir ([8dec973](https://github.com/pywire/pywire/commit/8dec97382276ce0f139cc5abd89b0bd54806bc7d))
* **pywire-language-server:** trigger release PR update ([77491d0](https://github.com/pywire/pywire/commit/77491d02b5f51957b83b1ae3a320cbab53fb56a8))
* **tree-sitter-pywire:** bump for consistency ([42b40bd](https://github.com/pywire/pywire/commit/42b40bd3ec2711445865c772573b52774857bbc0))
* **vscode-pywire:** fix CI publish with --no-dependencies flag ([1ef1d72](https://github.com/pywire/pywire/commit/1ef1d72018f4c02bf29a923dd33e4f96bdf813ac))
