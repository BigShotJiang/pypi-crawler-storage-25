from httplint.field.list_field import HttpListField
from httplint.field.tests import FieldTest
from httplint.note import Note, categories, levels
from httplint.syntax import rfc9110
from httplint.types import AddNoteMethodType
from httplint.util import f_num


class vary(HttpListField):
    canonical_name = "Vary"
    description = """\
The `Vary` response header indicates the set of request headers that determines whether a cache is
permitted to use the response to reply to a subsequent request without validation.

In uncacheable or stale responses, the Vary field value advises the user agent about the criteria
that were used to select the representation."""
    reference = f"{rfc9110.SPEC_URL}#field.vary"
    syntax = rfc9110.Vary
    category = categories.CACHING
    deprecated = False
    valid_in_requests = False
    valid_in_responses = True

    def parse(self, field_value: str, add_note: AddNoteMethodType) -> str:
        return field_value.lower()

    def evaluate(self, add_note: AddNoteMethodType) -> None:
        if len(self.value) != len(set(self.value)):
            add_note(VARY_DUPLICATE)
        self.value = list(dict.fromkeys(self.value))
        if "*" in self.value:
            add_note(VARY_ASTERISK)
        if len(self.value) > 3:
            add_note(VARY_COMPLEX, vary_count=f_num(len(self.value)))
        if "user-agent" in self.value:
            add_note(VARY_USER_AGENT)
        if "host" in self.value:
            add_note(VARY_HOST)
        if "negotiate" in self.value:
            add_note(VARY_NEGOTIATE)


class VARY_ASTERISK(Note):
    category = categories.CACHING
    level = levels.WARN
    _summary = "Vary: * effectively makes this response uncacheable."
    _text = """\
`Vary *` indicates that responses for this resource vary by some aspect that can't (or won't) be
described by the server. This makes this response effectively uncacheable."""


class VARY_USER_AGENT(Note):
    category = categories.CACHING
    level = levels.WARN
    _summary = "Vary: User-Agent can cause cache inefficiency."
    _text = """\
Sending `Vary: User-Agent` requires caches to store a separate copy of the response for every
`User-Agent` request header they see.

Since there are so many different `User-Agent`s, this can "bloat" caches with many copies of the
same thing, or cause them to give up on storing these responses at all.

Consider having different URIs for the various versions of your content instead; this will give
finer control over caching without sacrificing efficiency."""


class VARY_HOST(Note):
    category = categories.CACHING
    level = levels.WARN
    _summary = "Vary: Host is not necessary."
    _text = """\
Some servers (e.g., [Apache](http://httpd.apache.org/) with
[mod_rewrite](http://httpd.apache.org/docs/2.4/mod/mod_rewrite.html)) will send `Host` in the
`Vary` header, in the belief that this is necessary.

This is not the case; HTTP specifies that the URI is the basis of the cache key, and the URI
incorporates the `Host` header.

The presence of `Vary: Host` may make some caches not store an otherwise cacheable response (since
some cache implementations will not store anything that has a `Vary` header)."""


class VARY_NEGOTIATE(Note):
    category = categories.CONNEG
    level = levels.INFO
    _summary = "Transparent Content Negotiation is not widely supported."
    _text = """\
The `Vary: Negotiate` header value is not necessary, as 
[Transparent Content Negotiation](https://www.rfc-editor.org/rfc/rfc2295.html)
is not widely supported.

Consider removing it."""


class VARY_DUPLICATE(Note):
    category = categories.CACHING
    level = levels.WARN
    _summary = "The Vary header contains duplicate values."
    _text = """\
The `Vary` header allows you to list the parts of the request that effectively change the response
representation.

Listing the same header more than once is redundant and can be confusing."""


class VARY_COMPLEX(Note):
    category = categories.CACHING
    level = levels.WARN
    _summary = "This resource varies in %(vary_count)s ways."
    _text = """\
The `Vary` mechanism allows a resource to describe the dimensions that its responses vary, or
change, over; each listed header is another dimension.

Varying by too many dimensions makes using this information impractical."""


class VaryTest(FieldTest):
    name = "Vary"
    inputs = [b"Accept-Encoding", b"*, User-Agent", b"Host"]
    expected_out = ["accept-encoding", "*", "user-agent", "host"]
    expected_notes = [VARY_ASTERISK, VARY_USER_AGENT, VARY_HOST, VARY_COMPLEX]


class VaryNegotiateTest(FieldTest):
    name = "Vary"
    inputs = [b"Negotiate"]
    expected_out = ["negotiate"]
    expected_notes = [VARY_NEGOTIATE]


class VaryDuplicateTest(FieldTest):
    name = "Vary"
    inputs = [b"a, b", b"a, c"]
    expected_out = ["a", "b", "c"]
    expected_notes = [VARY_DUPLICATE]
