# !/usr/bin/python
# coding=utf-8
try:
    import pymel.core as pm
except ImportError as error:
    print(__file__, error)
import pythontk as ptk

# from this package:
from mayatk.core_utils._core_utils import CoreUtils
from mayatk.ui_utils._ui_utils import UiUtils


class CamUtils(ptk.HelpMixin):
    """ """

    # Maya's built-in startup cameras plus common orthographic views
    # created on-demand by CamUtils helpers.
    DEFAULT_CAMERAS = frozenset(
        {
            "persp",
            "top",
            "front",
            "side",
            "back",
            "bottom",
            "left",
            "right",
            "alignToPoly",
        }
    )

    @staticmethod
    @CoreUtils.undoable
    def group_cameras(
        name="cameras", non_default=True, root_only=False, hide_group=False
    ):
        """Group cameras in the scene based on the provided parameters.

        Parameters:
                name (str): The name of the group that will contain the cameras. Default is 'cameras'.
                non_default (bool, optional): If True, only non-default cameras will be grouped. Default is True.
                root_only (bool, optional): If True, only root-level cameras (not parented to other objects) will be grouped. Default is False.
                hide_group (bool, optional): If True, the newly created group will be hidden. Default is False.

        Returns:
                PyNode: The created group node containing the cameras.
        """
        if pm.objExists(name):  # Check if the group already exists
            pm.error(f"Group '{name}' already exists.")
            return

        # Create the group and set it's visibility
        group = pm.group(empty=True, name=name)
        group.visibility.set(not hide_group)

        all_cameras = pm.ls(type="camera")  # Get all cameras in the scene
        all_camera_transforms = [
            cam.getParent() for cam in all_cameras
        ]  # Get the parent transform nodes of the cameras

        if root_only:  # Filter cameras based on the root_only flag
            all_camera_transforms = [
                cam for cam in all_camera_transforms if cam.getParent() is None
            ]

        # Parent cameras to the group based on the non_default flag
        for cam in all_camera_transforms:
            if non_default:
                if not any(
                    [
                        cam.name().endswith(def_cam)
                        for def_cam in CamUtils.DEFAULT_CAMERAS
                    ]
                ):
                    pm.parent(cam, group)
            else:
                pm.parent(cam, group)

        return group

    @classmethod
    def toggle_safe_frames(cls):
        """Toggle display of the film gate for the current camera."""
        camera = cls.get_current_cam()

        state = pm.camera(camera, q=True, displayResolution=1)
        if state:
            pm.camera(
                camera,
                edit=1,
                displayFilmGate=False,
                displayResolution=False,
                overscan=1.0,
            )
        else:
            pm.camera(
                camera,
                edit=1,
                displayFilmGate=False,
                displayResolution=True,
                overscan=1.3,
            )

    @staticmethod
    def get_current_cam():
        """Get the currently active camera."""
        from maya.OpenMaya import MDagPath
        from maya.OpenMayaUI import M3dView

        view = M3dView.active3dView()
        cam = MDagPath()
        view.getCamera(cam)
        camPath = cam.fullPathName()
        return camPath

    @staticmethod
    @CoreUtils.undoable
    def create_camera_from_view(name="camera#"):
        """Create a new camera based on the current view."""
        # Find the current modelPanel (viewport)
        current_panel = None
        panels = UiUtils.get_panel(all=True)
        if panels:
            for panel in panels:
                if UiUtils.get_panel(typeOf=panel) == "modelPanel":
                    current_panel = panel
                    break

        if current_panel:
            if UiUtils.get_panel(typeOf=current_panel) == "modelPanel":
                camera = pm.modelPanel(current_panel, q=1, cam=1)
                new_camera = pm.duplicate(camera)[0]
                pm.showHidden(new_camera)
                new_camera = pm.rename(new_camera, name)
                print(f"# Result: {new_camera} #")
                return new_camera
        else:
            print("No modelPanel found")

    @classmethod
    @CoreUtils.undoable
    def adjust_camera_clipping(cls, camera=None, near_clip=None, far_clip=None):
        """Adjusts the near and far clipping planes of one or multiple cameras.

        Parameters:
            camera (str/list/optional): The camera or list of cameras to adjust. If None, adjusts the current viewport camera.
            near_clip (float/str/optional): The value for the near clipping plane.
                - If None (default): Do not change.
                - If 'auto': Automatically calculated based on scene geometry.
                - If 'reset': Resets to default (0.1).
                - If float: Sets to the specific value.
            far_clip (float/str/optional): The value for the far clipping plane.
                - If None (default): Do not change.
                - If 'auto': Automatically calculated based on scene geometry.
                - If 'reset': Resets to default (10000).
                - If float: Sets to the specific value.
        """
        # Resolve camera shapes
        target_cameras = []
        if camera:
            raw_cameras = pm.ls(camera)
            for cam in raw_cameras:
                if hasattr(cam, "getShape"):  # Transform
                    shape = cam.getShape()
                    if shape and shape.nodeType() == "camera":
                        target_cameras.append(shape)
                elif cam.nodeType() == "camera":  # Shape
                    target_cameras.append(cam)
        else:
            # If no camera specified, use the current viewport camera
            current_cam = cls.get_current_cam()
            if current_cam:
                cam_node = pm.PyNode(current_cam)
                if cam_node.nodeType() == "camera":
                    target_cameras.append(cam_node)
                elif hasattr(cam_node, "getShape"):
                    shape = cam_node.getShape()
                    if shape and shape.nodeType() == "camera":
                        target_cameras.append(shape)

        if not target_cameras:
            return

        # Check if we need auto calculation
        needs_auto = (near_clip == "auto") or (far_clip == "auto")

        # Pre-calculate scene bbox if needed for auto mode
        bbox = None
        bbox_points = None

        if needs_auto:
            all_geo = pm.ls(dag=True, geometry=True, visible=True)
            if not all_geo:
                all_geo = pm.ls(dag=True, geometry=True)

            if all_geo:
                bbox = pm.exactWorldBoundingBox(all_geo)
                # bbox is [xmin, ymin, zmin, xmax, ymax, zmax]
                min_pt = pm.dt.Vector(bbox[0], bbox[1], bbox[2])
                max_pt = pm.dt.Vector(bbox[3], bbox[4], bbox[5])

                # Calculate 8 corners for far clip calculation
                bbox_points = [
                    pm.dt.Vector(x, y, z)
                    for x in (min_pt.x, max_pt.x)
                    for y in (min_pt.y, max_pt.y)
                    for z in (min_pt.z, max_pt.z)
                ]

        for cam in target_cameras:
            # Only get camera position if we are doing auto calculations
            cam_pos = None
            max_dist = 0  # Distance to furthest point of bbox

            if needs_auto:
                cam_transform = cam.getParent()
                cam_pos = pm.dt.Vector(pm.xform(cam_transform, q=True, ws=True, t=True))

                if bbox_points:
                    for pt in bbox_points:
                        d = (pt - cam_pos).length()
                        if d > max_dist:
                            max_dist = d

            # Determine Near Clip
            if near_clip is not None:
                new_near = None
                if near_clip == "reset":
                    new_near = 0.1
                elif near_clip == "auto":
                    if bbox and cam_pos:
                        # Use a safe ratio of the far distance to maintain Z-buffer precision
                        # while ensuring we don't clip foreground objects excessively.
                        # Ratio of 3000 is conservative (e.g. Far=3000 -> Near=1.0)
                        # We also ensure a minimum of 0.1 (standard Maya default)
                        estimated_far = max_dist * 1.2
                        new_near = estimated_far / 3000.0
                        new_near = max(new_near, 0.1)
                    else:
                        new_near = 0.1
                elif isinstance(near_clip, (int, float)):
                    new_near = near_clip

                if new_near is not None:
                    cam.nearClipPlane.set(new_near)

            # Determine Far Clip
            if far_clip is not None:
                new_far = None
                if far_clip == "reset":
                    new_far = 10000.0
                elif far_clip == "auto":
                    if bbox_points and cam_pos:
                        new_far = max_dist * 1.2
                    else:
                        new_far = 10000.0
                elif isinstance(far_clip, (int, float)):
                    new_far = far_clip

                if new_far is not None:
                    cam.farClipPlane.set(new_far)

    @staticmethod
    def _get_default_camera(camera_name):
        """Get the default Maya camera by name, regardless of grouping or naming.

        Parameters:
            camera_name (str): The base name of the camera ('top', 'front', 'side', 'persp')

        Returns:
            str or None: The actual camera name to use with lookThru, or None if not found
        """
        # Get all startup cameras in the scene
        try:
            all_cameras = pm.ls(type="camera")
            startup_cameras = []

            for cam in all_cameras:
                try:
                    # Check if this is a startup camera
                    if pm.camera(cam, q=True, startupCamera=True):
                        startup_cameras.append(cam)
                except:
                    continue

            # Find the camera that matches our desired view
            camera_map = {
                "top": ["top", "topShape"],
                "front": ["front", "frontShape"],
                "side": ["side", "sideShape"],
                "persp": ["persp", "perspShape"],
            }

            search_names = camera_map.get(camera_name, [camera_name])

            # Look for matching startup camera
            for cam in startup_cameras:
                cam_name = str(cam)
                transform = cam.getParent() if hasattr(cam, "getParent") else None
                transform_name = str(transform) if transform else ""

                # Check if camera shape or transform matches our search names
                for search_name in search_names:
                    if (
                        search_name in cam_name.lower()
                        or search_name in transform_name.lower()
                        or cam_name.endswith(search_name)
                        or transform_name.endswith(search_name)
                    ):
                        # Return the shape name for lookThru (preferred)
                        return str(cam)

            # If no startup camera found, try by name existence
            for search_name in search_names:
                if pm.objExists(search_name):
                    return search_name

        except Exception as e:
            print(f"Error finding default camera {camera_name}: {e}")

        return None

    @classmethod
    def switch_viewport_camera(cls, camera_name):
        """Unified method to switch to a camera, creating custom ones if needed.

        Parameters:
            camera_name (str): Name of the camera to switch to

        Returns:
            str or None: The camera that was switched to, or None if switching failed
        """
        # Store initial selection to restore later
        initial_selection = pm.ls(selection=True)

        # Camera configuration - simplified approach
        camera_config = {
            # Custom cameras (create if missing)
            "back": {"default": False, "view_set": "back"},
            "left": {"default": False, "view_set": "leftSide"},
            "bottom": {"default": False, "view_set": "bottom"},
        }

        # Check if it's a custom camera
        config = camera_config.get(camera_name)
        camera_used = None

        if config and not config["default"]:
            # Handle custom cameras (create if missing)
            if pm.objExists(camera_name):
                pm.lookThru(camera_name)
                camera_used = camera_name
            else:
                # Create the custom camera
                cam, camShape = pm.camera()
                pm.rename(cam, camera_name)
                pm.lookThru(camera_name)
                pm.hide(camera_name)
                camera_used = camera_name

                # Apply view setting if specified
                view_set = config.get("view_set")
                if view_set:
                    pm.viewSet(**{view_set: 1})
        else:
            # Handle default Maya cameras
            default_cam = cls._get_default_camera(camera_name)
            if default_cam:
                pm.lookThru(default_cam)
                camera_used = default_cam
            else:
                print(f"Warning: Default camera '{camera_name}' not found in scene")

        # Restore initial selection
        if initial_selection:
            pm.select(initial_selection)
        else:
            pm.select(clear=True)

        return camera_used


# --------------------------------------------------------------------------------------------

if __name__ == "__main__":
    pass

# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
