//! Wire protocol `aggregate` command handler.
use std::collections::HashMap;

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

use crate::wire_context::ConnectionContext;
use crate::wire_dispatch::inc_counter;
use crate::wire_errors::make_error;

use super::{dict_get_i64, dict_get_str, get_collection, get_collection_typed, HandlerFn};

fn cmd_aggregate(
    py: Python<'_>,
    ctx: &Bound<'_, ConnectionContext>,
    cmd: &Bound<'_, PyDict>,
    _seqs: &Bound<'_, PyAny>,
) -> PyResult<Py<PyAny>> {
    inc_counter("query");
    let db_name = dict_get_str(cmd, "$db", "test")?;
    let coll_name_val = cmd
        .get_item("aggregate")?
        .ok_or_else(|| PyValueError::new_err("missing required field 'aggregate'"))?;

    let is_db_agg = coll_name_val
        .extract::<i64>()
        .map(|v| v == 1)
        .unwrap_or(false)
        || coll_name_val
            .extract::<String>()
            .map(|v| v == "1")
            .unwrap_or(false);

    let raw_pipeline = cmd
        .get_item("pipeline")?
        .unwrap_or_else(|| PyList::empty(py).into_any());
    let pipeline_list = raw_pipeline.cast::<PyList>()?;

    let pipeline = pipeline_list;

    let batch_size = {
        let cursor_opt = cmd.get_item("cursor")?;
        if let Some(c) = cursor_opt {
            if let Ok(d) = c.cast::<PyDict>() {
                dict_get_i64(d, "batchSize", 101)?
            } else {
                101
            }
        } else {
            101
        }
    };

    if is_db_agg {
        if !pipeline.is_empty() {
            let first = pipeline.get_item(0)?;
            if let Ok(d) = first.cast::<PyDict>() {
                if d.get_item("$currentOp")?.is_some() {
                    let ns = format!("{db_name}.$cmd.aggregate");
                    let cursor_dict = PyDict::new(py);
                    cursor_dict.set_item("id", 0)?;
                    cursor_dict.set_item("ns", &ns)?;
                    cursor_dict.set_item("firstBatch", PyList::empty(py))?;
                    let resp = PyDict::new(py);
                    resp.set_item("cursor", cursor_dict)?;
                    resp.set_item("ok", 1.0)?;
                    return Ok(resp.into_any().unbind());
                }
            }
        }
        let ns = format!("{db_name}.$cmd.aggregate");
        let cursor_dict = PyDict::new(py);
        cursor_dict.set_item("id", 0)?;
        cursor_dict.set_item("ns", &ns)?;
        cursor_dict.set_item("firstBatch", PyList::empty(py))?;
        let resp = PyDict::new(py);
        resp.set_item("cursor", cursor_dict)?;
        resp.set_item("ok", 1.0)?;
        return Ok(resp.into_any().unbind());
    }

    let coll_name: String = coll_name_val.extract()?;
    let coll = get_collection(ctx, &db_name, &coll_name)?;
    let ns = format!("{db_name}.{coll_name}");

    if !pipeline.is_empty() {
        let first = pipeline.get_item(0)?;
        if let Ok(d) = first.cast::<PyDict>() {
            if d.get_item("$changeStream")?.is_some() {
                let change_pipeline = if pipeline.len() > 1 {
                    let rest = PyList::empty(py);
                    for i in 1..pipeline.len() {
                        rest.append(pipeline.get_item(i)?)?;
                    }
                    rest.into_any()
                } else {
                    py.None().into_bound(py)
                };
                let stream = if change_pipeline.is_none() {
                    coll.call_method1("watch", (py.None(),))?
                } else {
                    coll.call_method1("watch", (&change_pipeline,))?
                };
                let cr = ctx.borrow().cursor_registry.clone_ref(py);
                let cr_reg = cr.bind(py).cast::<crate::wire_cursors::CursorRegistry>()?;
                let cursor_id =
                    cr_reg.borrow().create_change_stream(py, &ns, stream.unbind(), Some(batch_size as usize))?;
                let cursor_dict = PyDict::new(py);
                cursor_dict.set_item("id", cursor_id)?;
                cursor_dict.set_item("ns", &ns)?;
                cursor_dict.set_item("firstBatch", PyList::empty(py))?;
                let resp = PyDict::new(py);
                resp.set_item("cursor", cursor_dict)?;
                resp.set_item("ok", 1.0)?;
                return Ok(resp.into_any().unbind());
            }
        }
    }

    let coll_typed = get_collection_typed(ctx, &db_name, &coll_name)?;
    let docs = coll_typed.bind(py).borrow().get_all_typed(py)?;

    let db_py = ctx.borrow().get_db_typed(py, &db_name)?;
    let coll_getter_fn = db_py.bind(py).getattr("get_collection")?;

    let constants_mod = crate::cached_modules::smongo_agg_constants(py)?;
    let max_docs: usize = constants_mod
        .getattr("DEFAULT_MAX_PIPELINE_DOCS")?
        .extract()
        .unwrap_or(500_000);
    let mem_limit: usize = constants_mod
        .getattr("DEFAULT_MEMORY_LIMIT_BYTES")?
        .extract()
        .unwrap_or(104_857_600);

    let result = crate::aggregation::aggregate_pipeline(
        py,
        docs.bind(py),
        &pipeline,
        Some(&coll_getter_fn),
        max_docs,
        false,
        mem_limit,
    )?;
    let result_bound = &result;

    let cr = ctx.borrow().cursor_registry.clone_ref(py);
    let cr_reg = cr.bind(py).cast::<crate::wire_cursors::CursorRegistry>()?;
    let (cursor_id, first_batch) =
        cr_reg.borrow()
            .create(py, &ns, result_bound, Some(batch_size as usize))?;

    let cursor_dict = PyDict::new(py);
    cursor_dict.set_item("id", cursor_id)?;
    cursor_dict.set_item("ns", &ns)?;
    cursor_dict.set_item("firstBatch", first_batch.bind(py))?;
    let resp = PyDict::new(py);
    resp.set_item("cursor", cursor_dict)?;
    resp.set_item("ok", 1.0)?;
    Ok(resp.into_any().unbind())
}

fn cmd_map_reduce(
    py: Python<'_>,
    _ctx: &Bound<'_, ConnectionContext>,
    _cmd: &Bound<'_, PyDict>,
    _seqs: &Bound<'_, PyAny>,
) -> PyResult<Py<PyAny>> {
    let r = make_error(
        py,
        "CommandNotSupported",
        "mapReduce is deprecated and not supported by smongo. Use aggregation instead.",
    )?;
    Ok(r.into_any().unbind())
}

pub(crate) fn register(m: &mut HashMap<&'static str, HandlerFn>) {
    m.insert("aggregate", cmd_aggregate);
    m.insert("mapReduce", cmd_map_reduce);
    m.insert("mapreduce", cmd_map_reduce);
}
