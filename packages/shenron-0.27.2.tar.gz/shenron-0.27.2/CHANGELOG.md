# Changelog

## [0.27.2](https://github.com/doublewordai/shenron/compare/v0.27.1...v0.27.2) (2026-04-10)


### Bug Fixes

* upgrade reliability — chart persistence, self-update, error visibility ([#160](https://github.com/doublewordai/shenron/issues/160)) ([f026c6e](https://github.com/doublewordai/shenron/commit/f026c6eba3e183fa7811a3246f5370260d7d0dad))

## [0.27.1](https://github.com/doublewordai/shenron/compare/v0.27.0...v0.27.1) (2026-04-10)


### Bug Fixes

* pin replica-manager image to versioned tag ([#158](https://github.com/doublewordai/shenron/issues/158)) ([6122ef1](https://github.com/doublewordai/shenron/commit/6122ef1fed764fb3fc0a6aab6182a0a4fa1ee533))

## [0.27.0](https://github.com/doublewordai/shenron/compare/v0.26.1...v0.27.0) (2026-04-10)


### Features

* upgrade endpoint applies node values with replica preservation ([#156](https://github.com/doublewordai/shenron/issues/156)) ([91b6a52](https://github.com/doublewordai/shenron/commit/91b6a5287eafafe0001574858a52d9fd37a104f8))

## [0.26.1](https://github.com/doublewordai/shenron/compare/v0.26.0...v0.26.1) (2026-04-10)


### Bug Fixes

* download charts from public shenron-configs repo ([3613da0](https://github.com/doublewordai/shenron/commit/3613da006be29a95a0c4817e59888d6fde12f71b))
* support authenticated chart downloads from private repos ([#153](https://github.com/doublewordai/shenron/issues/153)) ([3d47d61](https://github.com/doublewordai/shenron/commit/3d47d61e6bc6c948aa52c289a11ecd31f97514a9))

## [0.26.0](https://github.com/doublewordai/shenron/compare/v0.25.0...v0.26.0) (2026-04-10)


### Features

* **35b:** tune mamba memory ratio and SSM dtype ([#151](https://github.com/doublewordai/shenron/issues/151)) ([0ffb53c](https://github.com/doublewordai/shenron/commit/0ffb53cb9cc85d7cb5116fd37be6cf57bb5b004f))

## [0.25.0](https://github.com/doublewordai/shenron/compare/v0.24.0...v0.25.0) (2026-04-10)


### Features

* add chart upgrade endpoint and deploy workflow ([#148](https://github.com/doublewordai/shenron/issues/148)) ([1900356](https://github.com/doublewordai/shenron/commit/1900356a9af148066effa0a6a5855a7cd0a078dc))
* add replica-manager to CI build matrix ([#150](https://github.com/doublewordai/shenron/issues/150)) ([2e06888](https://github.com/doublewordai/shenron/commit/2e06888ead0c93d9bbcc590845afa5212133855a))

## [0.24.0](https://github.com/doublewordai/shenron/compare/v0.23.3...v0.24.0) (2026-04-09)


### Features

* **gemma4:** enable multimodal, reasoning, and tool parsing ([b419c39](https://github.com/doublewordai/shenron/commit/b419c396b586db9ebc1bc5f31627f5a5ec1b734f))
* **gemma4:** enable multimodal, reasoning, and tool parsing ([#146](https://github.com/doublewordai/shenron/issues/146)) ([ef5a906](https://github.com/doublewordai/shenron/commit/ef5a9069520a5585dfa07bf7812ec4420168f2d8))

## [0.23.3](https://github.com/doublewordai/shenron/compare/v0.23.2...v0.23.3) (2026-04-09)


### Bug Fixes

* **gemma4:** add HF_TOKEN for chiaotzu and piccolo deployments ([2c3be0a](https://github.com/doublewordai/shenron/commit/2c3be0abe84ecb989903b241277817004ec4bf43))
* **gemma4:** add HF_TOKEN for chiaotzu and piccolo deployments ([#143](https://github.com/doublewordai/shenron/issues/143)) ([a98eee3](https://github.com/doublewordai/shenron/commit/a98eee3284937712c91b40e331fb78305942604c))
* use hermes tool-call-parser for base Qwen3 models ([3bb7e7d](https://github.com/doublewordai/shenron/commit/3bb7e7d00768d43a44d41da77e4a9daf1aa5a672))

## [0.23.2](https://github.com/doublewordai/shenron/compare/v0.23.1...v0.23.2) (2026-04-09)


### Bug Fixes

* apply qwen3 tool-call-parser correction ([92952fc](https://github.com/doublewordai/shenron/commit/92952fcc6b10141bbb5d947bb9328036357fa66e))

## [0.23.1](https://github.com/doublewordai/shenron/compare/v0.23.0...v0.23.1) (2026-04-09)


### Bug Fixes

* use NVIDIA frontend image as EPP source ([#139](https://github.com/doublewordai/shenron/issues/139)) ([aeda797](https://github.com/doublewordai/shenron/commit/aeda7973bf789c7c50bd16d5ab205d5ae36225dd))

## [0.23.0](https://github.com/doublewordai/shenron/compare/v0.22.0...v0.23.0) (2026-04-09)


### Features

* switch dynamo source to doublewordai fork ([#137](https://github.com/doublewordai/shenron/issues/137)) ([3296137](https://github.com/doublewordai/shenron/commit/3296137d93c0081bd3c36131f2e8f73c69261d39))

## [0.22.0](https://github.com/doublewordai/shenron/compare/v0.21.1...v0.22.0) (2026-04-09)


### Features

* add custom frontend image build to CI ([#136](https://github.com/doublewordai/shenron/issues/136)) ([2156089](https://github.com/doublewordai/shenron/commit/2156089b2f64bb047ead97a3745e115cb40c45df))
* **gemma4:** pin Dynamo CI, update vLLM image, and add model configs ([dd042e0](https://github.com/doublewordai/shenron/commit/dd042e0b10193d6045e9983024c9717183fbdba7))

## [0.21.1](https://github.com/doublewordai/shenron/compare/v0.21.0...v0.21.1) (2026-04-09)


### Bug Fixes

* **test:** update helm chart test for caddy-disabled node config ([43d997a](https://github.com/doublewordai/shenron/commit/43d997a032b976b2e1647bd4966d008ff7517fec))
* **test:** update helm chart test for caddy-disabled node config ([2be30b2](https://github.com/doublewordai/shenron/commit/2be30b212c8b8ae71c71212626456beef0ff7730))

## [0.21.0](https://github.com/doublewordai/shenron/compare/v0.20.16...v0.21.0) (2026-04-08)


### Features

* **helm:** add standalone caddy chart ([c157574](https://github.com/doublewordai/shenron/commit/c1575749826d6b9d2970980c4361aa7eacb96e56))
* **helm:** add standalone caddy chart ([5aed221](https://github.com/doublewordai/shenron/commit/5aed221f727c36b3d8392f1b7d2dc04dc6c2788d))

## [0.20.16](https://github.com/doublewordai/shenron/compare/v0.20.15...v0.20.16) (2026-04-08)


### Bug Fixes

* set Qwen3.5 preferred max_new_tokens to 262144 ([67d7811](https://github.com/doublewordai/shenron/commit/67d7811d4b1e892373c1f07aa50eb4c19046b981))
* set Qwen3.5 preferred max_new_tokens to 262144 ([e3f085f](https://github.com/doublewordai/shenron/commit/e3f085f5145447c93fcd4aa69ccdb2c7e87691b4))

## [0.20.15](https://github.com/doublewordai/shenron/compare/v0.20.14...v0.20.15) (2026-04-03)


### Bug Fixes

* **helm:** wire caddy tls values into generated caddyfile ([df8dad7](https://github.com/doublewordai/shenron/commit/df8dad7cb5b17259204bec246853beb758d49de2))
* **helm:** wire caddy tls values into generated caddyfile ([d5b107a](https://github.com/doublewordai/shenron/commit/d5b107ac6b592f878033b3211b539d6603523d9a))

## [0.20.14](https://github.com/doublewordai/shenron/compare/v0.20.13...v0.20.14) (2026-04-03)


### Bug Fixes

* **helm:** enforce Dynamo combined name length limit ([ce2750b](https://github.com/doublewordai/shenron/commit/ce2750b99da3bb77fd971714615bf939b8467cb2))
* **helm:** enforce Dynamo combined name length limit ([0f1a2d0](https://github.com/doublewordai/shenron/commit/0f1a2d033798be5c5f92c5d25c1a09f86d6fa51d))

## [0.20.13](https://github.com/doublewordai/shenron/compare/v0.20.12...v0.20.13) (2026-04-03)


### Bug Fixes

* **helm:** support multiple huggingface cache mount paths ([3770479](https://github.com/doublewordai/shenron/commit/377047988608dc0547af89607243119e3a38f379))
* **helm:** support multiple huggingface cache mount paths ([3f74cad](https://github.com/doublewordai/shenron/commit/3f74cad3655dbefb237ad365cc16470988303019))

## [0.20.12](https://github.com/doublewordai/shenron/compare/v0.20.11...v0.20.12) (2026-04-03)


### Bug Fixes

* **helm:** update chiaotzu huggingface cache paths ([37754fd](https://github.com/doublewordai/shenron/commit/37754fd0f79d26b52d5dc18da378429049bf5749))
* **helm:** update chiaotzu huggingface cache paths ([27314cf](https://github.com/doublewordai/shenron/commit/27314cf3d111df3770047e1446b370951df6efba))

## [0.20.11](https://github.com/doublewordai/shenron/compare/v0.20.10...v0.20.11) (2026-04-03)


### Bug Fixes

* **helm:** remove HF_HOME env from vllm node configs ([f0e72d3](https://github.com/doublewordai/shenron/commit/f0e72d39409354162705edce5307bc4ec87f1fde))
* **helm:** remove HF_HOME env from vllm node configs ([53bdca3](https://github.com/doublewordai/shenron/commit/53bdca3a26a6932322042e5941505782b88f20da))

## [0.20.10](https://github.com/doublewordai/shenron/compare/v0.20.9...v0.20.10) (2026-04-03)


### Bug Fixes

* **helm:** use recreate strategy for node model deployments ([38f8331](https://github.com/doublewordai/shenron/commit/38f833136315c41aafac735607723205750ea433))
* **helm:** use recreate strategy for node model deployments ([5b6303a](https://github.com/doublewordai/shenron/commit/5b6303a50b92c15590c84c6c65f8dccf8ed7529f))

## [0.20.9](https://github.com/doublewordai/shenron/compare/v0.20.8...v0.20.9) (2026-04-03)


### Bug Fixes

* **helm:** remove auto-tool-choice flag and cap Dynamo names ([03c820f](https://github.com/doublewordai/shenron/commit/03c820f1b2eef58e13a9c7fc8cdb9664fa98ee21))
* **helm:** remove auto-tool-choice flag and cap Dynamo names ([17b465a](https://github.com/doublewordai/shenron/commit/17b465ac616128b5e20f2a00959b9a0a71bedec6))

## [0.20.8](https://github.com/doublewordai/shenron/compare/v0.20.7...v0.20.8) (2026-04-03)


### Bug Fixes

* **helm:** adjust model replica allocations ([ea5d542](https://github.com/doublewordai/shenron/commit/ea5d54282a48aceec799399b8201823860c94ee5))
* **helm:** adjust model replica allocations ([61f794a](https://github.com/doublewordai/shenron/commit/61f794a517c075eb62b38be95b5f7686366ab469))

## [0.20.7](https://github.com/doublewordai/shenron/compare/v0.20.6...v0.20.7) (2026-04-03)


### Bug Fixes

* **helm:** include model name in Dynamo worker component naming ([8e92ba0](https://github.com/doublewordai/shenron/commit/8e92ba0050240edfb98ba077e9d0f5ffdcc3f645))
* **helm:** update model parser flags and adjust cache paths in configuration ([3593d9c](https://github.com/doublewordai/shenron/commit/3593d9c9a64caed6b15b00d7f6b4bc48195a7f1e))

## [0.20.6](https://github.com/doublewordai/shenron/compare/v0.20.5...v0.20.6) (2026-04-02)


### Bug Fixes

* **helm:** rename LightOn OCR model in node configs ([395ed7c](https://github.com/doublewordai/shenron/commit/395ed7c147674dc3c313b2227f7c110a040aa535))

## [0.20.5](https://github.com/doublewordai/shenron/compare/v0.20.4...v0.20.5) (2026-04-01)


### Bug Fixes

* **helm:** bump node image tags to 0.20.5 ([31c4e7c](https://github.com/doublewordai/shenron/commit/31c4e7cbac1576505e14b548cd08efb1b0341f1c))
* **helm:** bump node image tags to 0.20.5 ([0f3b112](https://github.com/doublewordai/shenron/commit/0f3b112190189150f843847602f4827f10bde2c3))

## [0.20.3](https://github.com/doublewordai/shenron/compare/v0.20.2...v0.20.3) (2026-03-24)


### Bug Fixes

* update cu130 sglang cudnn and add picsum batch generator ([#101](https://github.com/doublewordai/shenron/issues/101)) ([64fea39](https://github.com/doublewordai/shenron/commit/64fea39adcc7debdeccadde665a83720897eb0d0))

## [0.20.2](https://github.com/doublewordai/shenron/compare/v0.20.1...v0.20.2) (2026-03-23)


### Performance Improvements

* **helm:** improve Qwen 4B/9B throughput ([495f0ae](https://github.com/doublewordai/shenron/commit/495f0aef77a60a48fd5f718f5b25bc31235204e1))
* **helm:** switch Qwen 4B/9B to TRTLLM attention and remove duplicate 4B config ([e3db5cc](https://github.com/doublewordai/shenron/commit/e3db5cc28ee4627d4fb144345bbe17c3bd89509d))

## [0.20.1](https://github.com/doublewordai/shenron/compare/v0.20.0...v0.20.1) (2026-03-18)


### Bug Fixes

* **helm:** add OCR models to node-chiaotzu ([0dafe5e](https://github.com/doublewordai/shenron/commit/0dafe5e82e4982f42aba18b8d857042e03d0bd92))
* **helm:** add OCR models to node-chiaotzu ([aea7400](https://github.com/doublewordai/shenron/commit/aea740069057d66c31bc3b8dbcbe65e34c104603))

## [0.20.0](https://github.com/doublewordai/shenron/compare/v0.19.3...v0.20.0) (2026-03-18)


### Features

* **helm:** add qwen3.5-4b model config ([4fa48d3](https://github.com/doublewordai/shenron/commit/4fa48d399114f9fd57375d2ec0db5b2dbb0c3b03))
* **helm:** add qwen3.5-4b model config ([c01d7e5](https://github.com/doublewordai/shenron/commit/c01d7e53fa94bc356fcbfba7a8498013a4f15d86))
* **helm:** per-model telemetry toggle and auto-detect sglang vs vllm ([317363e](https://github.com/doublewordai/shenron/commit/317363e22205838faf843b9af8455e50655fb97c))


### Bug Fixes

* **helm:** add shm mounts for vl models ([5ee1635](https://github.com/doublewordai/shenron/commit/5ee16359e1d9fb93a6e5e3e53e0cafdd55a443b4))
* **helm:** add shm mounts for vl models ([aca5fa2](https://github.com/doublewordai/shenron/commit/aca5fa2e46c40af0fcc65a6ac581feed9c737ab0))
* **helm:** use explicit node config and tracing ([#94](https://github.com/doublewordai/shenron/issues/94)) ([b4f9109](https://github.com/doublewordai/shenron/commit/b4f91094da73db7e0aa28c1560d6741c1d46b502))

## [0.19.3](https://github.com/doublewordai/shenron/compare/v0.19.2...v0.19.3) (2026-03-13)


### Bug Fixes

* install cudnn after sglang in sglang images ([6e943dd](https://github.com/doublewordai/shenron/commit/6e943dd422987c14ff85177620c810b4e6272710))
* install cudnn after sglang in sglang images ([b653050](https://github.com/doublewordai/shenron/commit/b653050e818664405744c2f08e9bf39645811d0d))

## [0.19.2](https://github.com/doublewordai/shenron/compare/v0.19.1...v0.19.2) (2026-03-12)


### Bug Fixes

* install OCR dependencies in cu130 sglang image ([#88](https://github.com/doublewordai/shenron/issues/88)) ([1d00540](https://github.com/doublewordai/shenron/commit/1d00540cc623d577ae7e43436b4142f66893a22d))

## [0.19.1](https://github.com/doublewordai/shenron/compare/v0.19.0...v0.19.1) (2026-03-12)


### Bug Fixes

* restore sglang image and release path ([#86](https://github.com/doublewordai/shenron/issues/86)) ([b42c0f0](https://github.com/doublewordai/shenron/commit/b42c0f0830ce609a308e67e5bbf0ef9ef225fff5))

## [0.19.0](https://github.com/doublewordai/shenron/compare/v0.18.5...v0.19.0) (2026-03-10)


### Features

* add distributed tracing support to Helm charts ([#84](https://github.com/doublewordai/shenron/issues/84)) ([1e4a82c](https://github.com/doublewordai/shenron/commit/1e4a82c8c11e3dc765fe7a48c6838cde2c2c533c))

## [0.18.5](https://github.com/doublewordai/shenron/compare/v0.18.4...v0.18.5) (2026-03-10)


### Bug Fixes

* increase Qwen 397 /dev/shm to 16Gi ([#82](https://github.com/doublewordai/shenron/issues/82)) ([43ea000](https://github.com/doublewordai/shenron/commit/43ea0003693531313d82854b64dc5c937a4cfbc7))

## [0.18.4](https://github.com/doublewordai/shenron/compare/v0.18.3...v0.18.4) (2026-03-10)


### Bug Fixes

* default model /dev/shm to 8Gi ([#80](https://github.com/doublewordai/shenron/issues/80)) ([9b29008](https://github.com/doublewordai/shenron/commit/9b29008e9239dd32dd457187720a3cb3e87db84d))

## [0.18.2](https://github.com/doublewordai/shenron/compare/v0.18.1...v0.18.2) (2026-03-05)


### Bug Fixes

* microk8s config ([052e34c](https://github.com/doublewordai/shenron/commit/052e34c5679d6f97942c1716edf32b3f16355ec6))

## [0.18.1](https://github.com/doublewordai/shenron/compare/v0.18.0...v0.18.1) (2026-03-05)


### Bug Fixes

* doublewordai/fix/apply-fixes-models-yaml ([744896e](https://github.com/doublewordai/shenron/commit/744896e4ff6c1e18ba058675b42dbb6b137d1fc5))

## [0.18.0](https://github.com/doublewordai/shenron/compare/v0.17.0...v0.18.0) (2026-03-04)


### Features

* endpoint setup ([#67](https://github.com/doublewordai/shenron/issues/67)) ([c98aeca](https://github.com/doublewordai/shenron/commit/c98aecaa98acadbe441683aeef213da99d83bb6e))

## [0.17.0](https://github.com/doublewordai/shenron/compare/v0.16.1...v0.17.0) (2026-03-02)


### Features

* **helm:** add router, replica manager, and scouter reporter support ([f06b839](https://github.com/doublewordai/shenron/commit/f06b8396719c38ca911f75c7c2c7276e37ab12ad))
* **helm:** add router, replica manager, and scouter reporter support ([12fb798](https://github.com/doublewordai/shenron/commit/12fb7987526ae945cbfc90e8de8d2789517e3e36))

## [0.16.1](https://github.com/doublewordai/shenron/compare/v0.16.0...v0.16.1) (2026-02-27)


### Bug Fixes

* **helm:** tune model sampling defaults and correct memory unit ([103daca](https://github.com/doublewordai/shenron/commit/103dacab61db5866db957ebd65168dfb0fec925e))
* **helm:** tune model sampling defaults and correct memory unit ([d03e4a1](https://github.com/doublewordai/shenron/commit/d03e4a11cad7ca732d2d616ee3b80e2b53eac626))

## [0.16.0](https://github.com/doublewordai/shenron/compare/v0.15.0...v0.16.0) (2026-02-26)


### Features

* **helm:** add per-model /dev/shm sizing support ([443b17f](https://github.com/doublewordai/shenron/commit/443b17f0bab14770fbe6bf1af07b9e53a9bfac84))
* **helm:** add per-model /dev/shm sizing support ([3eb1dd7](https://github.com/doublewordai/shenron/commit/3eb1dd7c650bce48f74ecec1c61f6da51172d72a))

## [0.15.0](https://github.com/doublewordai/shenron/compare/v0.14.0...v0.15.0) (2026-02-26)


### Features

* **helm:** add Prometheus scraping and sglang cu130 docker build ([b47cdaa](https://github.com/doublewordai/shenron/commit/b47cdaa24064cfec6bf877ee6f8238d80e83400b))
* **helm:** add prometheus scraping and sglang cu130 image CI build ([8332074](https://github.com/doublewordai/shenron/commit/8332074a130aca68bf1c89a5084f8fb5f6711348))

## [0.14.0](https://github.com/doublewordai/shenron/compare/v0.13.0...v0.14.0) (2026-02-26)


### Features

* add GPT-OSS-20B ([6efece1](https://github.com/doublewordai/shenron/commit/6efece18a8bd6bd47b2b50d418879df751e72503))
* add GPT-OSS-20B configs for cu126 and cu129 ([f87ba2d](https://github.com/doublewordai/shenron/commit/f87ba2de95fd7d4792f5a0b77063be326262e401))

## [0.13.0](https://github.com/doublewordai/shenron/compare/v0.12.0...v0.13.0) (2026-02-23)


### Features

* migrate to engine_* schema and models-first configs ([#57](https://github.com/doublewordai/shenron/issues/57)) ([b58cf6f](https://github.com/doublewordai/shenron/commit/b58cf6f5b93da488efe239e802665da98bf2a84a))

## [0.12.0](https://github.com/doublewordai/shenron/compare/v0.11.1...v0.12.0) (2026-02-23)


### Features

* add sglangmux generation and writable compose mounts ([e7facb4](https://github.com/doublewordai/shenron/commit/e7facb47f8e15dde589b6e7963f69b9229ed3281))

## [0.11.1](https://github.com/doublewordai/shenron/compare/v0.11.0...v0.11.1) (2026-02-18)


### Bug Fixes

* mirror release configs to public shenron-configs repo ([1ab706a](https://github.com/doublewordai/shenron/commit/1ab706a))

## [0.11.0](https://github.com/doublewordai/shenron/compare/v0.10.1...v0.11.0) (2026-02-17)


### Features

* add disable_responses_api_store option to configuration ([094da28](https://github.com/doublewordai/shenron/commit/094da28f12ab4bcdff5126e7b8a39ae90ef11673))
* add disable_responses_api_store option to configuration ([436e188](https://github.com/doublewordai/shenron/commit/436e18874d20bff485e34cb60630f29dd24b6a2a))

## [0.10.1](https://github.com/doublewordai/shenron/compare/v0.10.0...v0.10.1) (2026-02-17)


### Bug Fixes

* use qwen 30b fp8 model in configs ([73147d7](https://github.com/doublewordai/shenron/commit/73147d78fe6f62fbd3b06a4b5afc6716bb16e604))

## [0.10.0](https://github.com/doublewordai/shenron/compare/v0.9.0...v0.10.0) (2026-02-12)


### Features

* add shenron get overrides ([b3c4a8c](https://github.com/doublewordai/shenron/commit/b3c4a8ceb7a9695469b85fc2ef4c9606827717f0))

## [0.9.0](https://github.com/doublewordai/shenron/compare/v0.8.2...v0.9.0) (2026-02-12)


### Features

* keep latest tag for shenron_version ([b1c1d26](https://github.com/doublewordai/shenron/commit/b1c1d267b5d92d9ca19a2609abc16b620bb76648))
* keep latest tag for shenron_version ([5e37979](https://github.com/doublewordai/shenron/commit/5e37979a89810897c4372625323febbffa8fa411))
* set cu126 torch backend ([ef91a12](https://github.com/doublewordai/shenron/commit/ef91a12a35d2d5ab36a6ff766db481dd7ebc4c0d))
* set cu126 torch backend ([cbb4c45](https://github.com/doublewordai/shenron/commit/cbb4c452ad5c2254d835b8d079943b9f954ed24c))
* update CUDA 13 image for B300 ([80a56e9](https://github.com/doublewordai/shenron/commit/80a56e9a42e525a16580f8b8c29865a4cd50b770))


### Bug Fixes

* CUDA 13 image for B300 ([67f47b1](https://github.com/doublewordai/shenron/commit/67f47b1d306156bb78c74c7b4a1dd44b9507c21a))

## [0.8.2](https://github.com/doublewordai/shenron/compare/v0.8.1...v0.8.2) (2026-02-12)


### Bug Fixes

* tag latest on main pushes ([d8edec3](https://github.com/doublewordai/shenron/commit/d8edec34acd6db8517852ca61b6c6ef9f00b7df5))
* trigger release ([bac5310](https://github.com/doublewordai/shenron/commit/bac5310d2673b870ffa53121c40d06a70609d2b1))

## [0.8.1](https://github.com/doublewordai/shenron/compare/v0.8.0...v0.8.1) (2026-02-12)


### Bug Fixes

* note release-please triggers ([#37](https://github.com/doublewordai/shenron/issues/37)) ([b25fcf9](https://github.com/doublewordai/shenron/commit/b25fcf9bf72459d331be91fd1eefd518216551b3))

## [0.8.0](https://github.com/doublewordai/shenron/compare/v0.7.0...v0.8.0) (2026-02-12)


### Features

* add enable_expert_parallel config flag ([bb83726](https://github.com/doublewordai/shenron/commit/bb83726aad45f9cd303b1f445d73626bf53242b5))
* add enable_expert_parallel flag ([05f7748](https://github.com/doublewordai/shenron/commit/05f7748c401261425b1221e3658e39f06d227a3e))
* add interactive shenron get command for release configs ([315b7a9](https://github.com/doublewordai/shenron/commit/315b7a92d5170230bc97571cb37c764ca9c9c862))
* add Qwen235 TP2 config for cu129 ([eb88e90](https://github.com/doublewordai/shenron/commit/eb88e905c22b70c4d7be7c1f8e482a70d2271d7f))
* add Qwen235 TP2 cu129 production config ([462bdf0](https://github.com/doublewordai/shenron/commit/462bdf0ecc3e07a41c3d4100cb01353ca8becfc0))
* add Qwen30B A3B TP1 configs for cu126/cu129 ([5a79524](https://github.com/doublewordai/shenron/commit/5a795242fb09510b8ea05ac3fc887022d3bc7dfa))
* add Qwen30B A3B TP1 configs for cu126/cu129 ([e14ed3d](https://github.com/doublewordai/shenron/commit/e14ed3d1098a8fae71b14d327f4d5a56420d198f))
* add shenron get for release config selection ([fbda3d7](https://github.com/doublewordai/shenron/commit/fbda3d73c5b6a4e23f5c532cef781f14a3228351))


### Bug Fixes

* let release-please create GitHub releases ([263c89b](https://github.com/doublewordai/shenron/commit/263c89bc105ebd9308cefe78017bb6b5d0675109))
* let release-please create GitHub releases ([472f34d](https://github.com/doublewordai/shenron/commit/472f34d0e1927ad4b6069c95d2ee2d7f27ae6863))
* normalize TTY line endings in get picker ([528bd4a](https://github.com/doublewordai/shenron/commit/528bd4a14ba7242de64812835bac59646fff0c9a))
* render shenron get picker lines correctly ([ca3eeb6](https://github.com/doublewordai/shenron/commit/ca3eeb67f3c8b6230c5d1a4a7830a79ac1684c73))

## [0.7.0](https://github.com/doublewordai/shenron/compare/v0.6.3...v0.7.0) (2026-02-11)


### Features

* add CUDA 12.9/13 presets for Qwen model configs ([9c00382](https://github.com/doublewordai/shenron/commit/9c0038237dc5a92f4f2a7ac9feb7b77e13ed993c))
* add qwen config presets for cu129 and cu130 ([25df0c3](https://github.com/doublewordai/shenron/commit/25df0c3525b14cce2a9bbe3c26800872f5960db4))

## [0.6.3](https://github.com/doublewordai/shenron/compare/v0.6.2...v0.6.3) (2026-02-11)


### Bug Fixes

* make release creation deterministic from VERSION ([4818b7b](https://github.com/doublewordai/shenron/commit/4818b7bbdec77d455e2d2d9680200b41407bc498))
* mark merged release PR as tagged after release ([e448182](https://github.com/doublewordai/shenron/commit/e4481823c9a2ec2f906b260594798e019d01a889))

## [0.6.2](https://github.com/doublewordai/shenron/compare/v0.6.1...v0.6.2) (2026-02-11)


### Bug Fixes

* re-enable Depot cache for cu129 builds ([45e31fe](https://github.com/doublewordai/shenron/commit/45e31fe77339d5a60a9fe2e14c656b7b4464ee4a))

## [0.6.1](https://github.com/doublewordai/shenron/compare/v0.6.0...v0.6.1) (2026-02-11)


### Bug Fixes

* align quickstart and default config with v0.6.0 ([f99ce5c](https://github.com/doublewordai/shenron/commit/f99ce5c54b036584b12672a21be28e4db33c5bd2))

## [0.6.0](https://github.com/doublewordai/shenron/compare/v0.5.2...v0.6.0) (2026-02-11)


### Features

* config-driven shenron generator and release automation ([1f4c4a4](https://github.com/doublewordai/shenron/commit/1f4c4a44942976ad706cde7ea39037b656ee2c88))

## [0.5.2](https://github.com/doublewordai/shenron/compare/v0.5.1...v0.5.2) (2026-02-09)


### Bug Fixes

* add depy auth ([4fa847a](https://github.com/doublewordai/shenron/commit/4fa847a73ee0fe5dd19e728489ac4eda7b296353))
* add verification for DEPOT_PROJECT_ID in CI workflow and update build steps ([223c256](https://github.com/doublewordai/shenron/commit/223c256f4334513e22c68b368960c9f8ab4461b4))
* add verification for DEPOT_PROJECT_ID in CI workflow and update build steps ([b5111df](https://github.com/doublewordai/shenron/commit/b5111dfc91a5cc441d5617d50e596cfe7bce9c76))

## [0.5.1](https://github.com/doublewordai/shenron/compare/v0.5.0...v0.5.1) (2026-02-09)


### Bug Fixes

* add Depot CLI setup step to CI workflow for release events ([87e7ef8](https://github.com/doublewordai/shenron/commit/87e7ef8654f149f2f5721626cb87ed94e8dd3248))
* add Depot CLI setup step to CI workflow for release events ([cc642c1](https://github.com/doublewordai/shenron/commit/cc642c1da8919e54f15657d91cf7e5c28f6a62c0))

## [0.5.0](https://github.com/doublewordai/shenron/compare/v0.4.0...v0.5.0) (2026-02-09)


### Features

* add Copilot instructions and enhance CI workflow with build space maximization ([b632cea](https://github.com/doublewordai/shenron/commit/b632ceaf851a3f6efad59ae340c303c809b1a88d))


### Bug Fixes

* add Copilot instructions and enhance CI workflow with build space maximization ([d15d018](https://github.com/doublewordai/shenron/commit/d15d018a71b445b528c15ef5f9e3ccd2ff49dbfb))

## [0.4.0](https://github.com/doublewordai/shenron/compare/v0.3.0...v0.4.0) (2026-02-06)


### Features

* update Docker image references to use ghcr.io for consistency ([7797780](https://github.com/doublewordai/shenron/commit/7797780b06b42bdcc67ac34142b5fb6a54ec7a3f))


### Bug Fixes

* update Docker image references to use ghcr.io for consistency ([c3d755a](https://github.com/doublewordai/shenron/commit/c3d755af94ee52d35c2ca88570de483626521792))

## [0.3.0](https://github.com/doublewordai/shenron/compare/v0.2.0...v0.3.0) (2026-02-06)


### Features

* update SHENRON_VERSION handling in docker-compose and related tests ([333db7f](https://github.com/doublewordai/shenron/commit/333db7f90ca2074ca898c59c18bec5f40985f954))


### Bug Fixes

* update SHENRON_VERSION handling in docker-compose and related t… ([77cd3bd](https://github.com/doublewordai/shenron/commit/77cd3bd34e1cb241f090ac1b2d4f57e1053f8f84))

## [0.2.0](https://github.com/doublewordai/shenron/compare/v0.1.0...v0.2.0) (2026-02-06)


### Features

* add ci ([f2c245e](https://github.com/doublewordai/shenron/commit/f2c245e6ab6c844a6aba6f26159842e3b8706ebd))
* add GitHub Actions workflow for automated releases ([05b8ad4](https://github.com/doublewordai/shenron/commit/05b8ad4505867be33eadd4cf258e825d2c5253c5))
* add GitHub Actions workflow for releasing assets and enhance run_docker_compose.sh for auto-downloading compose files ([c470d11](https://github.com/doublewordai/shenron/commit/c470d113fc2d00695a61c8910084b8b8a40b1c6a))
* add pull-requests permission to docker-build job in CI workflow ([08b02f8](https://github.com/doublewordai/shenron/commit/08b02f889f396aee878a8482e40466ea23811e73))
* remove branch protection workflow for main ([a23b950](https://github.com/doublewordai/shenron/commit/a23b950eebe51f4943e127c18db3a8692f860e12))
* remove branch protection workflow for main ([cd17472](https://github.com/doublewordai/shenron/commit/cd17472029b3f98c5ac493e277e4a56f1434cfad))
* remove redundant hadolint and Rust formatting steps from CI workflow ([cb07f9f](https://github.com/doublewordai/shenron/commit/cb07f9f9bd5998b961364f2f315f45e5268e1813))
* update CI workflow to specify ShellCheck target and enhance run_docker_compose.sh for version handling and vLLM config ([773e931](https://github.com/doublewordai/shenron/commit/773e931bd4d14237debfd12c254641653ef552f8))
* update docker-build job permissions and conditions in CI workflow ([dcf13ad](https://github.com/doublewordai/shenron/commit/dcf13ad81cf45fd90a0b45a975f3638e1d83e4e0))
* update release-please workflow to use GITHUB_TOKEN instead of RELEASE_TOKEN ([ca24a0c](https://github.com/doublewordai/shenron/commit/ca24a0c5639cdf70f31d0b3dda3724f0d630324f))
* update release-please workflow to use GITHUB_TOKEN instead of RELEASE_TOKEN ([dadf699](https://github.com/doublewordai/shenron/commit/dadf6996ccc0c405a785618b8feeb2bd152ffbfb))

## Changelog
