import os
import threading
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QPushButton, QTreeWidget, QTreeWidgetItem, QHeaderView,
    QFileDialog, QMessageBox, QStatusBar, QProgressBar, QComboBox,
    QCheckBox, QSplitter, QGroupBox, QLabel, QApplication,
)
from PySide6.QtCore import Qt, Signal, QObject, QSize
from PySide6.QtGui import QIcon, QFont, QColor, QPalette
from s3client import S3Client, S3Object, AwsProfile, load_aws_profiles
from botocore.exceptions import ClientError, NoCredentialsError, EndpointConnectionError


def human_size(nbytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(nbytes) < 1024:
            return f"{nbytes:.1f} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} PB"


def format_client_error(e: ClientError) -> str:
    """Extract a human-readable message from a ClientError, never returning empty."""
    try:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        msg = e.response.get("Error", {}).get("Message", "")
    except Exception:
        code, msg = "Unknown", ""
    if not msg:
        msg = str(e)
    if not msg:
        msg = "An unknown S3 error occurred."
    return f"[{code}] {msg}"


def is_access_denied(e: ClientError) -> bool:
    """Check if a ClientError represents an access denied / forbidden response."""
    try:
        code = str(e.response.get("Error", {}).get("Code", ""))
        msg = str(e.response.get("Error", {}).get("Message", ""))
    except Exception:
        return False
    text = f"{code} {msg}".lower()
    return any(k in text for k in ("accessdenied", "access denied", "forbidden", "403"))


class WorkerSignals(QObject):
    finished = Signal(object)
    error = Signal(str)
    progress = Signal(str)


class S3Explorer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.client: S3Client | None = None
        self.current_bucket: str = ""
        self.prefix_stack: list[str] = []
        self.aws_profiles: list[AwsProfile] = []
        self._setup_ui()
        self._apply_style()
        self._load_profiles()

    # ── UI Setup ──────────────────────────────────────────────────────
    def _setup_ui(self):
        self.setWindowTitle("S3 Explorer")
        self.setMinimumSize(900, 600)
        self.resize(1050, 700)

        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(12, 12, 12, 12)
        root_layout.setSpacing(10)

        # ── Connection panel ──
        conn_group = QGroupBox("Connection")
        conn_layout = QFormLayout(conn_group)
        conn_layout.setSpacing(6)

        self.combo_profile = QComboBox()
        self.combo_profile.addItem("— Manual —")
        self.combo_profile.currentIndexChanged.connect(self._on_profile_changed)

        self.input_endpoint = QLineEdit()
        self.input_endpoint.setPlaceholderText("https://s3.amazonaws.com (leave empty for AWS default)")
        self.input_access_key = QLineEdit()
        self.input_access_key.setPlaceholderText("Access Key ID")
        self.input_secret_key = QLineEdit()
        self.input_secret_key.setPlaceholderText("Secret Access Key")
        self.input_secret_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.input_region = QComboBox()
        self.input_region.setEditable(True)
        self.input_region.addItems([
            "us-east-1", "us-east-2", "us-west-1", "us-west-2",
            "eu-west-1", "eu-west-2", "eu-central-1",
            "ap-southeast-1", "ap-northeast-1", "sa-east-1",
        ])
        self.check_ssl = QCheckBox("Use SSL")
        self.check_ssl.setChecked(True)

        conn_layout.addRow("AWS Profile:", self.combo_profile)
        conn_layout.addRow("Endpoint:", self.input_endpoint)
        conn_layout.addRow("Access Key:", self.input_access_key)
        conn_layout.addRow("Secret Key:", self.input_secret_key)
        row_region = QHBoxLayout()
        row_region.addWidget(self.input_region, 1)
        row_region.addWidget(self.check_ssl)
        conn_layout.addRow("Region:", row_region)

        self.btn_connect = QPushButton("Connect")
        self.btn_connect.setObjectName("connectBtn")
        self.btn_connect.clicked.connect(self._on_connect)
        conn_layout.addRow("", self.btn_connect)

        root_layout.addWidget(conn_group)

        # ── Browser area ──
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Bucket list
        bucket_box = QGroupBox("Buckets")
        bucket_layout = QVBoxLayout(bucket_box)
        self.bucket_list = QTreeWidget()
        self.bucket_list.setHeaderHidden(True)
        self.bucket_list.setRootIsDecorated(False)
        self.bucket_list.itemClicked.connect(self._on_bucket_click)
        bucket_layout.addWidget(self.bucket_list)
        splitter.addWidget(bucket_box)

        # Object browser
        browser_box = QGroupBox("Objects")
        browser_layout = QVBoxLayout(browser_box)

        nav_bar = QHBoxLayout()
        self.btn_back = QPushButton("← Back")
        self.btn_back.setEnabled(False)
        self.btn_back.clicked.connect(self._on_back)
        self.lbl_path = QLabel("/")
        self.lbl_path.setFont(QFont("monospace", 11))
        nav_bar.addWidget(self.btn_back)
        nav_bar.addWidget(self.lbl_path, 1)

        self.btn_download = QPushButton("Download")
        self.btn_download.setObjectName("downloadBtn")
        self.btn_download.setEnabled(False)
        self.btn_download.clicked.connect(self._on_download)
        nav_bar.addWidget(self.btn_download)
        browser_layout.addLayout(nav_bar)

        self.object_tree = QTreeWidget()
        self.object_tree.setColumnCount(3)
        self.object_tree.setHeaderLabels(["Name", "Size", "Last Modified"])
        self.object_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.object_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.object_tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.object_tree.setRootIsDecorated(False)
        self.object_tree.setAlternatingRowColors(True)
        self.object_tree.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection)
        self.object_tree.itemDoubleClicked.connect(self._on_item_double_click)
        self.object_tree.itemSelectionChanged.connect(self._on_selection_changed)
        browser_layout.addWidget(self.object_tree)

        splitter.addWidget(browser_box)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        root_layout.addWidget(splitter, 1)

        # ── Status bar ──
        self.status_bar = QStatusBar()
        self.progress = QProgressBar()
        self.progress.setMaximumWidth(200)
        self.progress.setVisible(False)
        self.status_bar.addPermanentWidget(self.progress)
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Not connected")

    # ── Styling ───────────────────────────────────────────────────────
    def _apply_style(self):
        self.setStyleSheet("""
            QMainWindow { background: #1e1e2e; }
            QGroupBox {
                color: #cdd6f4; font-weight: bold; border: 1px solid #45475a;
                border-radius: 8px; margin-top: 10px; padding: 14px 8px 8px 8px;
            }
            QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; }
            QLabel { color: #cdd6f4; }
            QLineEdit, QComboBox {
                background: #313244; color: #cdd6f4; border: 1px solid #45475a;
                border-radius: 4px; padding: 5px 8px;
            }
            QLineEdit:focus, QComboBox:focus { border-color: #89b4fa; }
            QCheckBox { color: #cdd6f4; spacing: 6px; }
            QPushButton {
                background: #45475a; color: #cdd6f4; border: none;
                border-radius: 4px; padding: 6px 16px; font-weight: bold;
            }
            QPushButton:hover { background: #585b70; }
            QPushButton:disabled { background: #313244; color: #6c7086; }
            QPushButton#connectBtn { background: #89b4fa; color: #1e1e2e; }
            QPushButton#connectBtn:hover { background: #74c7ec; }
            QPushButton#downloadBtn { background: #a6e3a1; color: #1e1e2e; }
            QPushButton#downloadBtn:hover { background: #94e2d5; }
            QTreeWidget {
                background: #181825; color: #cdd6f4; border: 1px solid #45475a;
                border-radius: 4px; outline: none;
            }
            QTreeWidget::item { padding: 4px 0; }
            QTreeWidget::item:selected { background: #313244; }
            QTreeWidget::item:hover { background: #28283d; }
            QHeaderView::section {
                background: #313244; color: #a6adc8; border: none;
                padding: 4px 8px; font-weight: bold;
            }
            QStatusBar { background: #181825; color: #a6adc8; }
            QProgressBar {
                background: #313244; border: none; border-radius: 4px;
                text-align: center; color: #cdd6f4;
            }
            QProgressBar::chunk { background: #89b4fa; border-radius: 4px; }
            QSplitter::handle { background: #45475a; width: 2px; }
            QScrollBar:vertical {
                background: #181825; width: 8px; border: none;
            }
            QScrollBar::handle:vertical { background: #45475a; border-radius: 4px; min-height: 20px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)

    # ── AWS Profiles ──────────────────────────────────────────────────
    def _load_profiles(self):
        try:
            self.aws_profiles = load_aws_profiles()
        except Exception:
            self.aws_profiles = []
        for p in self.aws_profiles:
            label = f"🔑 {p.name}"
            self.combo_profile.addItem(label)
        if self.aws_profiles:
            self.status_bar.showMessage(f"Found {len(self.aws_profiles)} AWS profile(s)")

    def _on_profile_changed(self, index: int):
        if index <= 0:
            # Manual mode — clear fields
            self.input_access_key.setReadOnly(False)
            self.input_secret_key.setReadOnly(False)
            self.input_access_key.clear()
            self.input_secret_key.clear()
            self.input_access_key.setPlaceholderText("Access Key ID")
            self.input_secret_key.setPlaceholderText("Secret Access Key")
            self.input_endpoint.clear()
            return

        profile = self.aws_profiles[index - 1]
        if profile.access_key:
            self.input_access_key.setText(profile.access_key)
            self.input_access_key.setReadOnly(False)
        else:
            self.input_access_key.clear()
            self.input_access_key.setPlaceholderText(f"(resolved from profile '{profile.name}')")
            self.input_access_key.setReadOnly(True)
        if profile.secret_key:
            self.input_secret_key.setText(profile.secret_key)
            self.input_secret_key.setReadOnly(False)
        else:
            self.input_secret_key.clear()
            self.input_secret_key.setPlaceholderText(f"(resolved from profile '{profile.name}')")
            self.input_secret_key.setReadOnly(True)
        if profile.region:
            idx = self.input_region.findText(profile.region)
            if idx >= 0:
                self.input_region.setCurrentIndex(idx)
            else:
                self.input_region.setCurrentText(profile.region)
        if profile.endpoint_url:
            self.input_endpoint.setText(profile.endpoint_url)

    # ── Connection ────────────────────────────────────────────────────
    def _on_connect(self):
        profile_idx = self.combo_profile.currentIndex()
        ak = self.input_access_key.text().strip()
        sk = self.input_secret_key.text().strip()
        profile_name = ""

        if profile_idx > 0:
            profile = self.aws_profiles[profile_idx - 1]
            profile_name = profile.name
            # If profile doesn't expose keys, boto3 will resolve them via the profile
            if not ak and not sk and not profile_name:
                QMessageBox.warning(self, "Missing Credentials", "Access Key and Secret Key are required.")
                return
        else:
            if not ak or not sk:
                QMessageBox.warning(self, "Missing Credentials", "Access Key and Secret Key are required.")
                return

        try:
            self.client = S3Client(
                access_key=ak,
                secret_key=sk,
                region=self.input_region.currentText().strip(),
                endpoint_url=self.input_endpoint.text().strip(),
                use_ssl=self.check_ssl.isChecked(),
                profile_name=profile_name,
            )
            buckets = self.client.list_buckets()
        except EndpointConnectionError:
            QMessageBox.critical(self, "Connection Error",
                                 "Could not connect to the endpoint.\nCheck the URL and network settings.")
            return
        except NoCredentialsError:
            QMessageBox.critical(self, "Auth Error",
                                 "Invalid or missing credentials.\nPlease check your Access Key and Secret Key.")
            return
        except ClientError as e:
            QMessageBox.critical(self, "S3 Error", format_client_error(e))
            return
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e) or "An unexpected error occurred.")
            return

        self.bucket_list.clear()
        for name in buckets:
            item = QTreeWidgetItem([name])
            item.setIcon(0, self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
            self.bucket_list.addTopLevelItem(item)
        self.status_bar.showMessage(f"Connected — {len(buckets)} bucket(s)")

    # ── Bucket click ──────────────────────────────────────────────────
    def _on_bucket_click(self, item: QTreeWidgetItem):
        self.current_bucket = item.text(0)
        self.prefix_stack = [""]
        self._load_objects()

    # ── Navigation ────────────────────────────────────────────────────
    def _on_back(self):
        if len(self.prefix_stack) > 1:
            self.prefix_stack.pop()
            self._load_objects()

    def _on_item_double_click(self, item: QTreeWidgetItem):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if data and data.is_folder:
            self.prefix_stack.append(data.key)
            self._load_objects()

    def _on_selection_changed(self):
        items = self.object_tree.selectedItems()
        if items:
            self.btn_download.setEnabled(True)
        else:
            self.btn_download.setEnabled(False)

    # ── Load objects ──────────────────────────────────────────────────
    def _load_objects(self):
        prefix = self.prefix_stack[-1] if self.prefix_stack else ""
        self.lbl_path.setText(f"/{self.current_bucket}/{prefix}")
        self.btn_back.setEnabled(len(self.prefix_stack) > 1)
        self.object_tree.clear()
        self.btn_download.setEnabled(False)
        self.status_bar.showMessage("Loading…")
        QApplication.processEvents()

        signals = WorkerSignals()
        signals.finished.connect(self._on_objects_loaded)
        signals.error.connect(self._on_load_error)

        def work():
            try:
                objects = self.client.list_objects(self.current_bucket, prefix)
                signals.finished.emit(objects)
            except ClientError as e:
                if is_access_denied(e):
                    signals.error.emit(f"⛔ Access Denied\n\nYou don't have permission to list objects in this path.\n\n{format_client_error(e)}")
                else:
                    signals.error.emit(format_client_error(e))
            except Exception as e:
                signals.error.emit(str(e) or "An unexpected error occurred.")

        threading.Thread(target=work, daemon=True).start()

    def _on_objects_loaded(self, objects: list[S3Object]):
        self.object_tree.clear()
        prefix = self.prefix_stack[-1] if self.prefix_stack else ""
        for obj in objects:
            display_name = obj.key[len(prefix):]
            if obj.is_folder:
                item = QTreeWidgetItem([f"📁 {display_name}", "", ""])
            else:
                item = QTreeWidgetItem([f"  {display_name}", human_size(obj.size), obj.last_modified or ""])
            item.setData(0, Qt.ItemDataRole.UserRole, obj)
            self.object_tree.addTopLevelItem(item)
        self.status_bar.showMessage(f"{len(objects)} item(s)")

    def _on_load_error(self, msg: str):
        self.status_bar.showMessage("Error")
        QMessageBox.critical(self, "Error", msg)

    # ── Download ──────────────────────────────────────────────────────
    def _on_download(self):
        items = self.object_tree.selectedItems()
        if not items:
            return

        selected: list[S3Object] = []
        for item in items:
            data = item.data(0, Qt.ItemDataRole.UserRole)
            if data:
                selected.append(data)
        if not selected:
            return

        # Pick a destination folder for all downloads
        dest_dir = QFileDialog.getExistingDirectory(self, "Select Download Folder")
        if not dest_dir:
            return

        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.btn_download.setEnabled(False)
        self.status_bar.showMessage("Preparing download…")

        signals = WorkerSignals()
        signals.finished.connect(self._on_batch_download_done)
        signals.error.connect(self._on_download_error)
        signals.progress.connect(lambda msg: self.status_bar.showMessage(msg))

        def work():
            errors: list[str] = []
            count = 0
            try:
                file_list = self._resolve_download_list(selected)
                total = len(file_list)
                for i, obj in enumerate(file_list, 1):
                    signals.progress.emit(f"Downloading {i}/{total}: {obj.key.rsplit('/', 1)[-1]}")
                    rel = obj.key
                    prefix = self.prefix_stack[-1] if self.prefix_stack else ""
                    if rel.startswith(prefix):
                        rel = rel[len(prefix):]
                    file_dest = os.path.join(dest_dir, rel.replace("/", os.sep))
                    os.makedirs(os.path.dirname(file_dest) or dest_dir, exist_ok=True)
                    try:
                        self.client.download_file(self.current_bucket, obj.key, file_dest)
                        count += 1
                    except ClientError as e:
                        if is_access_denied(e):
                            errors.append(f"⛔ {obj.key}: Access Denied")
                        else:
                            errors.append(f"{obj.key}: {format_client_error(e)}")
                    except Exception as e:
                        errors.append(f"{obj.key}: {e or 'Unknown error'}")
                signals.finished.emit({"count": count, "errors": errors, "dest": dest_dir})
            except Exception as e:
                signals.error.emit(str(e))

        threading.Thread(target=work, daemon=True).start()

    def _resolve_download_list(self, selected: list[S3Object]) -> list[S3Object]:
        """Expand folders recursively into individual file objects."""
        files: list[S3Object] = []
        for obj in selected:
            if obj.is_folder:
                self._collect_folder_files(obj.key, files)
            else:
                files.append(obj)
        return files

    def _collect_folder_files(self, prefix: str, out: list[S3Object]):
        """Recursively list all files under a prefix."""
        paginator = self.client._client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.current_bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                out.append(S3Object(
                    key=obj["Key"],
                    size=obj["Size"],
                    last_modified=obj["LastModified"].strftime("%Y-%m-%d %H:%M:%S"),
                    is_folder=False,
                ))

    def _on_batch_download_done(self, result: dict):
        self.progress.setVisible(False)
        self.btn_download.setEnabled(True)
        count = result["count"]
        errors = result["errors"]
        dest = result["dest"]

        if errors:
            error_text = "\n".join(errors[:20])
            if len(errors) > 20:
                error_text += f"\n… and {len(errors) - 20} more"
            QMessageBox.warning(
                self, "Download Completed with Errors",
                f"Downloaded {count} file(s) to:\n{dest}\n\n"
                f"Failed ({len(errors)}):\n{error_text}"
            )
        else:
            QMessageBox.information(self, "Download Complete",
                                    f"Downloaded {count} file(s) to:\n{dest}")
        self.status_bar.showMessage(f"Downloaded {count} file(s)")

    def _on_download_error(self, msg: str):
        self.progress.setVisible(False)
        self.btn_download.setEnabled(True)
        self.status_bar.showMessage("Download failed")
        QMessageBox.critical(self, "Download Error", msg)
