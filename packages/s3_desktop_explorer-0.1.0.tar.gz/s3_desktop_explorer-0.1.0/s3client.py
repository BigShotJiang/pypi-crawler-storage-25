import configparser
import os
from pathlib import Path

import boto3
from botocore.exceptions import ClientError, NoCredentialsError, EndpointConnectionError
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AwsProfile:
    name: str
    access_key: str = ""
    secret_key: str = ""
    region: str = ""
    endpoint_url: str = ""


def load_aws_profiles() -> list[AwsProfile]:
    """Read profiles from ~/.aws/credentials and ~/.aws/config."""
    aws_dir = Path.home() / ".aws"
    creds_file = aws_dir / "credentials"
    config_file = aws_dir / "config"

    profiles: dict[str, AwsProfile] = {}

    # Parse credentials
    if creds_file.is_file():
        cp = configparser.ConfigParser()
        cp.read(str(creds_file))
        for section in cp.sections():
            name = section
            profiles[name] = AwsProfile(
                name=name,
                access_key=cp.get(section, "aws_access_key_id", fallback=""),
                secret_key=cp.get(section, "aws_secret_access_key", fallback=""),
            )

    # Parse config (sections are "profile xxx" except default)
    if config_file.is_file():
        cp = configparser.ConfigParser()
        cp.read(str(config_file))
        for section in cp.sections():
            name = section.replace("profile ", "") if section.startswith("profile ") else section
            if name not in profiles:
                profiles[name] = AwsProfile(name=name)
            profiles[name].region = cp.get(section, "region", fallback=profiles[name].region)
            profiles[name].endpoint_url = cp.get(section, "endpoint_url", fallback=profiles[name].endpoint_url)
            # Some configs also store keys
            if not profiles[name].access_key:
                profiles[name].access_key = cp.get(section, "aws_access_key_id", fallback="")
            if not profiles[name].secret_key:
                profiles[name].secret_key = cp.get(section, "aws_secret_access_key", fallback="")

    return sorted(profiles.values(), key=lambda p: (p.name != "default", p.name))


@dataclass
class S3Object:
    key: str
    size: int
    last_modified: Optional[str]
    is_folder: bool


class S3Client:
    def __init__(self, access_key: str = "", secret_key: str = "",
                 region: str = "us-east-1", endpoint_url: str = "",
                 use_ssl: bool = True, profile_name: str = ""):
        if profile_name:
            session = boto3.Session(profile_name=profile_name)
            kwargs = {"region_name": region} if region else {}
            if endpoint_url.strip():
                kwargs["endpoint_url"] = endpoint_url.strip()
                kwargs["config"] = boto3.session.Config(
                    s3={"addressing_style": "path"}, signature_version="s3v4"
                )
            self._client = session.client("s3", use_ssl=use_ssl, **kwargs)
        else:
            kwargs = {
                "aws_access_key_id": access_key,
                "aws_secret_access_key": secret_key,
                "region_name": region,
            }
            if endpoint_url.strip():
                kwargs["endpoint_url"] = endpoint_url.strip()
                kwargs["config"] = boto3.session.Config(
                    s3={"addressing_style": "path"}, signature_version="s3v4"
                )
            self._client = boto3.client("s3", use_ssl=use_ssl, **kwargs)

    def list_buckets(self) -> list[str]:
        resp = self._client.list_buckets()
        return sorted(b["Name"] for b in resp.get("Buckets", []))

    def list_objects(self, bucket: str, prefix: str = "") -> list[S3Object]:
        paginator = self._client.get_paginator("list_objects_v2")
        items: list[S3Object] = []
        folders_seen: set[str] = set()

        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]
                if folder not in folders_seen:
                    folders_seen.add(folder)
                    name = folder[len(prefix):]
                    items.append(S3Object(key=folder, size=0, last_modified=None, is_folder=True))
            for obj in page.get("Contents", []):
                if obj["Key"] == prefix:
                    continue
                items.append(S3Object(
                    key=obj["Key"],
                    size=obj["Size"],
                    last_modified=obj["LastModified"].strftime("%Y-%m-%d %H:%M:%S"),
                    is_folder=False,
                ))
        items.sort(key=lambda x: (not x.is_folder, x.key.lower()))
        return items

    def download_file(self, bucket: str, key: str, dest: str):
        self._client.download_file(bucket, key, dest)

    def get_object_size(self, bucket: str, key: str) -> int:
        resp = self._client.head_object(Bucket=bucket, Key=key)
        return resp["ContentLength"]
