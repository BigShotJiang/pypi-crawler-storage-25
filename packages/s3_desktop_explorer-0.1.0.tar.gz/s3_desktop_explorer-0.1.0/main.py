import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from app import S3Explorer


def main():
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    app = QApplication(sys.argv)
    app.setApplicationName("S3 Explorer")
    window = S3Explorer()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
