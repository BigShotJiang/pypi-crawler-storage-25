from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="s3-desktop-explorer",
    version="0.1.0",
    description="A fast, compact, cross-platform S3 desktop explorer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Yiğit Can Başalma",
    author_email="yigit.basalma@warewave.tech",
    url="https://github.com/yigitbasalma/s3explorer",
    py_modules=["main", "app", "s3client"],
    python_requires=">=3.10",
    install_requires=[
        "PySide6>=6.6.0",
        "boto3>=1.34.0",
    ],
    entry_points={
        "console_scripts": [
            "s3-desktop-explorer=main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Desktop Environment :: File Managers",
        "Environment :: X11 Applications :: Qt",
    ],
)
