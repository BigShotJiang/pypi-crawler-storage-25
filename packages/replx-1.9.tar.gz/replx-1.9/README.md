# replx

[![PyPI version](https://badge.fury.io/py/replx.svg)](https://badge.fury.io/py/replx)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

`replx` is a CLI tool for MicroPython development. It uses a single local agent process to manage multiple CLI sessions and multiple boards in a consistent workflow.

## What replx provides

- Shared connection management across terminal sessions
- Single local agent process per PC with home-scoped port persistence
- Foreground and background board handling per session
- Workspace-level default device configuration
- File operations on device storage
- Script execution, REPL access, and utility commands

## Installation

```sh
pip install replx
```

## Command summary

### Connection and session

- `setup`: Initialize workspace settings and register a default device.
- `scan`: List available serial devices.
- `status`: Show session and connection state.
- `fg`: Change the foreground device for the current session.
- `whoami`: Show the current foreground device.
- `disconnect`: Close a device connection.
- `shutdown`: Stop the agent and clear active sessions.

### Execution and interaction

- `exec` (`-c`): Execute inline Python code on the device.
- `run`: Run a local or device-side script.
- `repl`: Open an interactive REPL session.
- `shell`: Open a device file-system shell.

### File operations

- `ls`: List files and directories.
- `cat`: Print file content.
- `get`: Download files from device to local.
- `put`: Upload files from local to device.
- `cp`: Copy files or directories on device.
- `mv`: Move or rename files or directories on device.
- `rm`: Remove files or directories on device.
- `mkdir`: Create directories on device.
- `touch`: Create an empty file or update timestamps.

### Device management

- `usage`: Show device storage usage.
- `reset`: Perform a soft reset.
- `format`: Format the device file system.
- `init`: Run initialization scripts on device.
- `wifi`: Manage Wi-Fi configuration and status.
- `firmware`: Check, download, or update firmware.

### Package and build

- `pkg`: Search, download, and update packages.
- `mpy`: Compile `.py` files to `.mpy`.

### Hardware

- `gpio`: Read, write, and run GPIO sequences.
- `pwm`: Generate and monitor PWM signals.
- `adc`: Read ADC pins and run a board-side scope UI.
- `uart`: Open, write, read, and monitor UART.
- `spi`: Open, write, read, and transfer SPI data.
- `i2c`: Scan, read, write, and dump I2C devices.

## Notes

- `scan`, `status`, `whoami`, and `shutdown` are special commands and do not accept `--port`.
- Most device commands can omit the port when a foreground or workspace default device is available.
- The agent listens on a UDP port from `49152-65535` and stores the selected port in `~/.replx/.config` as `AGENT_PORT=...`.

## License

MIT
