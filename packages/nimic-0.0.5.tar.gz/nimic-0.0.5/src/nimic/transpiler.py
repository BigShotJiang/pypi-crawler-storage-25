"""
nimic transpiler
Copyright (c) 2026 Dmytro Makogon, see LICENSE (MIT).

Transpiles a subset of Python (nimic DSL) into Nim source code.
This module is a modified copy of CPython's ``ast.py``, where the
``_Unparser`` visitor has been extended to emit Nim syntax instead of
Python syntax.  The transformation is driven by the rules listed below.

Transformation Rules
--------------------

Formatting:
  rule:doublespace -> change four spaces to double spaces for indentation
  rule:quote -> replace quotes to double quotes
  rule:slice -> slice [a:], [a:b] -> [a..^1], [a..<b]
  rule:discard -> assign to "_" is replaced by "discard"
  rule:pass -> replace "pass" by "discard"

Scope qualifiers:
  rule:dropwith -> drop "with" for "const", "let", "var", "export", "block"
  rule:writeexport -> write no parentheses for "export" by assigning low priority
  feature:subscriptrename -> subscript can be renamed if in keywords_no_with context ("const", "let", "var", "export")

Type system:
  rule:classdef -> interpret class definition as type (object or tuple, depending on base class)
  rule:classdefseq -> combine consecutive class definitions into one type def.
    Move method definitions outside type definitions
  rule:typealias -> type alias (also register as alias for dispatch): class Time(float64) -> type Time* = float64
  rule:typedistinct -> distinct type (decorated with "distinct"): class Time(float64) -> type Time* = distinct float64
  rule:annotateself -> if self is not annotated, it will be derived from the class name (as immutable)
  rule:instantiation -> call with capitalized name and named arguments is interpreted as instantiation ("=" -> ":").
    Classes instantiated with keywords should be named starting with a capital letter (preceeding by _ or local_)
  rule:enum -> "NIntEnum", "NStrEnum" rename to "Enum", drop "auto"

Function definitions:
  rule:funcdef -> adjust function definition according to Nim syntax as "proc" (or "func")
  rule:funcdefdecorated -> interpret decorators as definitions for "template", "iterator", "converter", "method".
    Other decorators are skipped
  rule:block -> function definition named "_block" is inserted as "block:" where called
  rule:templateinline -> "with template_inline" is replaced by template definition
  rule:funcdefyield -> definitions with yield or decorated with "iterator" are converted to iterators
  rule:funcdefmut -> arguments denoted as "mut@" are mutable in function definition -> "var "
  rule:funcdefbody -> no body is written for function definition with "borrow" in pragma or only "pass"
  rule:funcdefinplace -> remove return ... from dunder defs for binary in-place operators __i...__, first argument is
    annotated as mutable if not done already
  rule:funcdefargswap -> arguments are swapped for binary operators "__radd__", "__rmul__", etc
  rule:funcdefrenamedunder -> rename binary operators __add__ -> "+", __sub__ -> "-", __getitem__ -> `[]`, etc
  rule:funcdefpackedtuple -> unpack tuples with "packed_tuple" in name
  rule:typedtemplate -> drop return from typed template or converter definition
  rule:pragma -> docstring with {.x.} is written as pragma {.x.}, if pragma contains "noSideEffect" func is defined
  rule:calltype -> def decorated with "calltype" emit as type alias: Name* = proc(...): T {.pragma.}

Control flow:
  rule:matchcase -> adjust match case according to Nim syntax, also for variant types
  rule:inlineif -> write inline if according to Nim syntax
  rule:comptime -> the expression "if comptime(x)" is written as "when x" ("if" directly followed by "comptime"
    should be resolvable at comptime (is interpreted as "when")
  rule:main -> replace __name__ == "__main__" by isMainModule

Operators & renaming:
  rule:assign -> operator <<= is defined as value assignment to a mutable variable, i.e. a <<= b transpiles as a = b,
    for attributes and array elements not needed, can be just c.x = b or c[0] = b
  rule:bitwiserename -> bitwise operations get precedence adjusted and are renamed << -> shl, >> -> shr, & -> and,
    | -> or, ^ -> xor
  rule:lowercasebool -> True -> true, False -> false, "None" -> "nil"
  rule:funcrename -> rename functions "print" to "echo", "str" to "$"
  rule:stringjoin -> replace "f" by "&"
  rule:literaltypes -> write as type suffix u64(0x9e3779b97f4a7c15) -> 0x9e3779b97f4a7c15'u64
  rule:char -> chars written as ch("#") transpile as char literals '#'
  rule:array -> add array type to the first array element
  rule:isnot -> write isnot according to Nim syntax
  rule:notin -> write notin according to Nim syntax

Imports:
  rule:import -> write import from as import, drop from __future__ import ...
  rule:nodoubleimport -> do not write import module if already imported

Memory & variables:
  rule:dropbrackets -> remove brackets from what follows after "ptr" and "ref"
  rule:localname -> rename identifiers that starts with _ to local_, otherwise add "*" when definition,
    except for "result"
  rule:deref -> pointer dereference: ".contents" -> "[]"
  rule:copy -> value types are copied, drop .copy()
  rule:varini -> var initialization call without arguments with the same name as annotation is interpreted as
    declaration ("with var: a: Rng = Rng()" transpiles as "var a: Rng"), e.g. if the type is tuple. Also holds
    without annotation for registered classes or native types as array, openArray, etc.

The docstring for the original ``ast`` module is given below:

    ast
    ~~~

    The `ast` module helps Python applications to process trees of the Python
    abstract syntax grammar.  The abstract syntax itself might change with
    each Python release; this module helps to find out programmatically what
    the current grammar looks like and allows modifications of it.

    An abstract syntax tree can be generated by passing `ast.PyCF_ONLY_AST` as
    a flag to the `compile()` builtin function or by using the `parse()`
    function from this module.  The result will be a tree of objects whose
    classes all inherit from `ast.AST`.

    A modified abstract syntax tree can be compiled into a Python code object
    using the built-in `compile()` function.

    Additionally various helper functions are provided that make working with
    the trees simpler.  The main intention of the helper functions and this
    module in general is to provide an easy to use interface for libraries
    that work tightly with the python syntax (template engines for example).


    :copyright: Copyright 2008 by Armin Ronacher.
    :license: Python License.
"""
import re
import sys
from _ast import *
from contextlib import contextmanager, nullcontext
from enum import IntEnum, _simple_enum, auto


def parse(source, filename='<unknown>', mode='exec', *,
          type_comments=False, feature_version=None):
    """
    Parse the source into an AST node.
    Equivalent to compile(source, filename, mode, PyCF_ONLY_AST).
    Pass type_comments=True to get back type comments where the syntax allows.
    """
    flags = PyCF_ONLY_AST
    if type_comments:
        flags |= PyCF_TYPE_COMMENTS
    if feature_version is None:
        feature_version = -1
    elif isinstance(feature_version, tuple):
        major, minor = feature_version  # Should be a 2-tuple.
        if major != 3:
            raise ValueError(f"Unsupported major version: {major}")
        feature_version = minor
    # Else it should be an int giving the minor version for 3.x.
    return compile(source, filename, mode, flags,
                   _feature_version=feature_version)


def literal_eval(node_or_string):
    """
    Evaluate an expression node or a string containing only a Python
    expression.  The string or node provided may only consist of the following
    Python literal structures: strings, bytes, numbers, tuples, lists, dicts,
    sets, booleans, and None.

    Caution: A complex expression can overflow the C stack and cause a crash.
    """
    if isinstance(node_or_string, str):
        node_or_string = parse(node_or_string.lstrip(" \t"), mode='eval')
    if isinstance(node_or_string, Expression):
        node_or_string = node_or_string.body
    def _raise_malformed_node(node):
        msg = "malformed node or string"
        if lno := getattr(node, 'lineno', None):
            msg += f' on line {lno}'
        raise ValueError(msg + f': {node!r}')
    def _convert_num(node):
        if not isinstance(node, Constant) or type(node.value) not in (int, float, complex):
            _raise_malformed_node(node)
        return node.value
    def _convert_signed_num(node):
        if isinstance(node, UnaryOp) and isinstance(node.op, (UAdd, USub)):
            operand = _convert_num(node.operand)
            if isinstance(node.op, UAdd):
                return + operand
            else:
                return - operand
        return _convert_num(node)
    def _convert(node):
        if isinstance(node, Constant):
            return node.value
        elif isinstance(node, Tuple):
            return tuple(map(_convert, node.elts))
        elif isinstance(node, List):
            return list(map(_convert, node.elts))
        elif isinstance(node, Set):
            return set(map(_convert, node.elts))
        elif (isinstance(node, Call) and isinstance(node.func, Name) and
              node.func.id == 'set' and node.args == node.keywords == []):
            return set()
        elif isinstance(node, Dict):
            if len(node.keys) != len(node.values):
                _raise_malformed_node(node)
            return dict(zip(map(_convert, node.keys),
                            map(_convert, node.values)))
        elif isinstance(node, BinOp) and isinstance(node.op, (Add, Sub)):
            left = _convert_signed_num(node.left)
            right = _convert_num(node.right)
            if isinstance(left, (int, float)) and isinstance(right, complex):
                if isinstance(node.op, Add):
                    return left + right
                else:
                    return left - right
        return _convert_signed_num(node)
    return _convert(node_or_string)


def dump(node, annotate_fields=True, include_attributes=False, *, indent=None):
    """
    Return a formatted dump of the tree in node.  This is mainly useful for
    debugging purposes.  If annotate_fields is true (by default),
    the returned string will show the names and the values for fields.
    If annotate_fields is false, the result string will be more compact by
    omitting unambiguous field names.  Attributes such as line
    numbers and column offsets are not dumped by default.  If this is wanted,
    include_attributes can be set to true.  If indent is a non-negative
    integer or string, then the tree will be pretty-printed with that indent
    level. None (the default) selects the single line representation.
    """
    def _format(node, level=0):
        if indent is not None:
            level += 1
            prefix = '\n' + indent * level
            sep = ',\n' + indent * level
        else:
            prefix = ''
            sep = ', '
        if isinstance(node, AST):
            cls = type(node)
            args = []
            allsimple = True
            keywords = annotate_fields
            for name in node._fields:
                try:
                    value = getattr(node, name)
                except AttributeError:
                    keywords = True
                    continue
                if value is None and getattr(cls, name, ...) is None:
                    keywords = True
                    continue
                value, simple = _format(value, level)
                allsimple = allsimple and simple
                if keywords:
                    args.append('%s=%s' % (name, value))
                else:
                    args.append(value)
            if include_attributes and node._attributes:
                for name in node._attributes:
                    try:
                        value = getattr(node, name)
                    except AttributeError:
                        continue
                    if value is None and getattr(cls, name, ...) is None:
                        continue
                    value, simple = _format(value, level)
                    allsimple = allsimple and simple
                    args.append('%s=%s' % (name, value))
            if allsimple and len(args) <= 3:
                return '%s(%s)' % (node.__class__.__name__, ', '.join(args)), not args
            return '%s(%s%s)' % (node.__class__.__name__, prefix, sep.join(args)), False
        elif isinstance(node, list):
            if not node:
                return '[]', True
            return '[%s%s]' % (prefix, sep.join(_format(x, level)[0] for x in node)), False
        return repr(node), True

    if not isinstance(node, AST):
        raise TypeError('expected AST, got %r' % node.__class__.__name__)
    if indent is not None and not isinstance(indent, str):
        indent = ' ' * indent
    return _format(node)[0]


def copy_location(new_node, old_node):
    """
    Copy source location (`lineno`, `col_offset`, `end_lineno`, and `end_col_offset`
    attributes) from *old_node* to *new_node* if possible, and return *new_node*.
    """
    for attr in 'lineno', 'col_offset', 'end_lineno', 'end_col_offset':
        if attr in old_node._attributes and attr in new_node._attributes:
            value = getattr(old_node, attr, None)
            # end_lineno and end_col_offset are optional attributes, and they
            # should be copied whether the value is None or not.
            if value is not None or (
                hasattr(old_node, attr) and attr.startswith("end_")
            ):
                setattr(new_node, attr, value)
    return new_node


def fix_missing_locations(node):
    """
    When you compile a node tree with compile(), the compiler expects lineno and
    col_offset attributes for every node that supports them.  This is rather
    tedious to fill in for generated nodes, so this helper adds these attributes
    recursively where not already set, by setting them to the values of the
    parent node.  It works recursively starting at *node*.
    """
    def _fix(node, lineno, col_offset, end_lineno, end_col_offset):
        if 'lineno' in node._attributes:
            if not hasattr(node, 'lineno'):
                node.lineno = lineno
            else:
                lineno = node.lineno
        if 'end_lineno' in node._attributes:
            if getattr(node, 'end_lineno', None) is None:
                node.end_lineno = end_lineno
            else:
                end_lineno = node.end_lineno
        if 'col_offset' in node._attributes:
            if not hasattr(node, 'col_offset'):
                node.col_offset = col_offset
            else:
                col_offset = node.col_offset
        if 'end_col_offset' in node._attributes:
            if getattr(node, 'end_col_offset', None) is None:
                node.end_col_offset = end_col_offset
            else:
                end_col_offset = node.end_col_offset
        for child in iter_child_nodes(node):
            _fix(child, lineno, col_offset, end_lineno, end_col_offset)
    _fix(node, 1, 0, 1, 0)
    return node


def increment_lineno(node, n=1):
    """
    Increment the line number and end line number of each node in the tree
    starting at *node* by *n*. This is useful to "move code" to a different
    location in a file.
    """
    for child in walk(node):
        # TypeIgnore is a special case where lineno is not an attribute
        # but rather a field of the node itself.
        if isinstance(child, TypeIgnore):
            child.lineno = getattr(child, 'lineno', 0) + n
            continue

        if 'lineno' in child._attributes:
            child.lineno = getattr(child, 'lineno', 0) + n
        if (
            "end_lineno" in child._attributes
            and (end_lineno := getattr(child, "end_lineno", 0)) is not None
        ):
            child.end_lineno = end_lineno + n
    return node


def iter_fields(node):
    """
    Yield a tuple of ``(fieldname, value)`` for each field in ``node._fields``
    that is present on *node*.
    """
    for field in node._fields:
        try:
            yield field, getattr(node, field)
        except AttributeError:
            pass


def iter_child_nodes(node):
    """
    Yield all direct child nodes of *node*, that is, all fields that are nodes
    and all items of fields that are lists of nodes.
    """
    for name, field in iter_fields(node):
        if isinstance(field, AST):
            yield field
        elif isinstance(field, list):
            for item in field:
                if isinstance(item, AST):
                    yield item


def get_docstring(node, clean=True):
    """
    Return the docstring for the given node or None if no docstring can
    be found.  If the node provided does not have docstrings a TypeError
    will be raised.

    If *clean* is `True`, all tabs are expanded to spaces and any whitespace
    that can be uniformly removed from the second line onwards is removed.
    """
    if not isinstance(node, (AsyncFunctionDef, FunctionDef, ClassDef, Module)):
        raise TypeError("%r can't have docstrings" % node.__class__.__name__)
    if not(node.body and isinstance(node.body[0], Expr)):
        return None
    node = node.body[0].value
    if isinstance(node, Constant) and isinstance(node.value, str):
        text = node.value
    else:
        return None
    if clean:
        import inspect
        text = inspect.cleandoc(text)
    return text


_line_pattern = re.compile(r"(.*?(?:\r\n|\n|\r|$))")
def _splitlines_no_ff(source, maxlines=None):
    """Split a string into lines ignoring form feed and other chars.

    This mimics how the Python parser splits source code.
    """
    lines = []
    for lineno, match in enumerate(_line_pattern.finditer(source), 1):
        if maxlines is not None and lineno > maxlines:
            break
        lines.append(match[0])
    return lines


def _pad_whitespace(source):
    r"""Replace all chars except '\f\t' in a line with spaces."""
    result = ''
    for c in source:
        if c in '\f\t':
            result += c
        else:
            result += ' '
    return result


def get_source_segment(source, node, *, padded=False):
    """Get source code segment of the *source* that generated *node*.

    If some location information (`lineno`, `end_lineno`, `col_offset`,
    or `end_col_offset`) is missing, return None.

    If *padded* is `True`, the first line of a multi-line statement will
    be padded with spaces to match its original position.
    """
    try:
        if node.end_lineno is None or node.end_col_offset is None:
            return None
        lineno = node.lineno - 1
        end_lineno = node.end_lineno - 1
        col_offset = node.col_offset
        end_col_offset = node.end_col_offset
    except AttributeError:
        return None

    lines = _splitlines_no_ff(source, maxlines=end_lineno+1)
    if end_lineno == lineno:
        return lines[lineno].encode()[col_offset:end_col_offset].decode()

    if padded:
        padding = _pad_whitespace(lines[lineno].encode()[:col_offset].decode())
    else:
        padding = ''

    first = padding + lines[lineno].encode()[col_offset:].decode()
    last = lines[end_lineno].encode()[:end_col_offset].decode()
    lines = lines[lineno+1:end_lineno]

    lines.insert(0, first)
    lines.append(last)
    return ''.join(lines)


def walk(node):
    """
    Recursively yield all descendant nodes in the tree starting at *node*
    (including *node* itself), in no specified order.  This is useful if you
    only want to modify nodes in place and don't care about the context.
    """
    from collections import deque
    todo = deque([node])
    while todo:
        node = todo.popleft()
        todo.extend(iter_child_nodes(node))
        yield node


class NodeVisitor(object):
    """
    A node visitor base class that walks the abstract syntax tree and calls a
    visitor function for every node found.  This function may return a value
    which is forwarded by the `visit` method.

    This class is meant to be subclassed, with the subclass adding visitor
    methods.

    Per default the visitor functions for the nodes are ``'visit_'`` +
    class name of the node.  So a `TryFinally` node visit function would
    be `visit_TryFinally`.  This behavior can be changed by overriding
    the `visit` method.  If no visitor function exists for a node
    (return value `None`) the `generic_visit` visitor is used instead.

    Don't use the `NodeVisitor` if you want to apply changes to nodes during
    traversing.  For this a special visitor exists (`NodeTransformer`) that
    allows modifications.
    """

    def visit(self, node):
        """Visit a node."""
        method = 'visit_' + node.__class__.__name__
        visitor = getattr(self, method, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        """Called if no explicit visitor function exists for a node."""
        for field, value in iter_fields(node):
            if isinstance(value, list):
                for item in value:
                    if isinstance(item, AST):
                        self.visit(item)
            elif isinstance(value, AST):
                self.visit(value)

    def visit_Constant(self, node):
        value = node.value
        type_name = _const_node_type_names.get(type(value))
        if type_name is None:
            for cls, name in _const_node_type_names.items():
                if isinstance(value, cls):
                    type_name = name
                    break
        if type_name is not None:
            method = 'visit_' + type_name
            try:
                visitor = getattr(self, method)
            except AttributeError:
                pass
            else:
                import warnings
                warnings.warn(f"{method} is deprecated; add visit_Constant",
                              DeprecationWarning, 2)
                return visitor(node)
        return self.generic_visit(node)


class NodeTransformer(NodeVisitor):
    """
    A :class:`NodeVisitor` subclass that walks the abstract syntax tree and
    allows modification of nodes.

    The `NodeTransformer` will walk the AST and use the return value of the
    visitor methods to replace or remove the old node.  If the return value of
    the visitor method is ``None``, the node will be removed from its location,
    otherwise it is replaced with the return value.  The return value may be the
    original node in which case no replacement takes place.

    Here is an example transformer that rewrites all occurrences of name lookups
    (``foo``) to ``data['foo']``::

       class RewriteName(NodeTransformer):

           def visit_Name(self, node):
               return Subscript(
                   value=Name(id='data', ctx=Load()),
                   slice=Constant(value=node.id),
                   ctx=node.ctx
               )

    Keep in mind that if the node you're operating on has child nodes you must
    either transform the child nodes yourself or call the :meth:`generic_visit`
    method for the node first.

    For nodes that were part of a collection of statements (that applies to all
    statement nodes), the visitor may also return a list of nodes rather than
    just a single node.

    Usually you use the transformer like this::

       node = YourTransformer().visit(node)
    """

    def generic_visit(self, node):
        for field, old_value in iter_fields(node):
            if isinstance(old_value, list):
                new_values = []
                for value in old_value:
                    if isinstance(value, AST):
                        value = self.visit(value)
                        if value is None:
                            continue
                        elif not isinstance(value, AST):
                            new_values.extend(value)
                            continue
                    new_values.append(value)
                old_value[:] = new_values
            elif isinstance(old_value, AST):
                new_node = self.visit(old_value)
                if new_node is None:
                    delattr(node, field)
                else:
                    setattr(node, field, new_node)
        return node


_DEPRECATED_VALUE_ALIAS_MESSAGE = (
    "{name} is deprecated and will be removed in Python {remove}; use value instead"
)
_DEPRECATED_CLASS_MESSAGE = (
    "{name} is deprecated and will be removed in Python {remove}; "
    "use ast.Constant instead"
)


# If the ast module is loaded more than once, only add deprecated methods once
if not hasattr(Constant, 'n'):
    # The following code is for backward compatibility.
    # It will be removed in future.

    def _n_getter(self):
        """Deprecated. Use value instead."""
        import warnings
        warnings._deprecated(
            "Attribute n", message=_DEPRECATED_VALUE_ALIAS_MESSAGE, remove=(3, 14)
        )
        return self.value

    def _n_setter(self, value):
        import warnings
        warnings._deprecated(
            "Attribute n", message=_DEPRECATED_VALUE_ALIAS_MESSAGE, remove=(3, 14)
        )
        self.value = value

    def _s_getter(self):
        """Deprecated. Use value instead."""
        import warnings
        warnings._deprecated(
            "Attribute s", message=_DEPRECATED_VALUE_ALIAS_MESSAGE, remove=(3, 14)
        )
        return self.value

    def _s_setter(self, value):
        import warnings
        warnings._deprecated(
            "Attribute s", message=_DEPRECATED_VALUE_ALIAS_MESSAGE, remove=(3, 14)
        )
        self.value = value

    Constant.n = property(_n_getter, _n_setter)
    Constant.s = property(_s_getter, _s_setter)

class _ABC(type):

    def __init__(cls, *args):
        cls.__doc__ = """Deprecated AST node class. Use ast.Constant instead"""

    def __instancecheck__(cls, inst):
        if cls in _const_types:
            import warnings
            warnings._deprecated(
                f"ast.{cls.__qualname__}",
                message=_DEPRECATED_CLASS_MESSAGE,
                remove=(3, 14)
            )
        if not isinstance(inst, Constant):
            return False
        if cls in _const_types:
            try:
                value = inst.value
            except AttributeError:
                return False
            else:
                return (
                    isinstance(value, _const_types[cls]) and
                    not isinstance(value, _const_types_not.get(cls, ()))
                )
        return type.__instancecheck__(cls, inst)

def _new(cls, *args, **kwargs):
    for key in kwargs:
        if key not in cls._fields:
            # arbitrary keyword arguments are accepted
            continue
        pos = cls._fields.index(key)
        if pos < len(args):
            raise TypeError(f"{cls.__name__} got multiple values for argument {key!r}")
    if cls in _const_types:
        import warnings
        warnings._deprecated(
            f"ast.{cls.__qualname__}", message=_DEPRECATED_CLASS_MESSAGE, remove=(3, 14)
        )
        return Constant(*args, **kwargs)
    return Constant.__new__(cls, *args, **kwargs)

class Num(Constant, metaclass=_ABC):
    _fields = ('n',)
    __new__ = _new

class Str(Constant, metaclass=_ABC):
    _fields = ('s',)
    __new__ = _new

class Bytes(Constant, metaclass=_ABC):
    _fields = ('s',)
    __new__ = _new

class NameConstant(Constant, metaclass=_ABC):
    __new__ = _new

class Ellipsis(Constant, metaclass=_ABC):
    _fields = ()

    def __new__(cls, *args, **kwargs):
        if cls is _ast_Ellipsis:
            import warnings
            warnings._deprecated(
                "ast.Ellipsis", message=_DEPRECATED_CLASS_MESSAGE, remove=(3, 14)
            )
            return Constant(..., *args, **kwargs)
        return Constant.__new__(cls, *args, **kwargs)

# Keep another reference to Ellipsis in the global namespace
# so it can be referenced in Ellipsis.__new__
# (The original "Ellipsis" name is removed from the global namespace later on)
_ast_Ellipsis = Ellipsis

_const_types = {
    Num: (int, float, complex),
    Str: (str,),
    Bytes: (bytes,),
    NameConstant: (type(None), bool),
    Ellipsis: (type(...),),
}
_const_types_not = {
    Num: (bool,),
}

_const_node_type_names = {
    bool: 'NameConstant',  # should be before int
    type(None): 'NameConstant',
    int: 'Num',
    float: 'Num',
    complex: 'Num',
    str: 'Str',
    bytes: 'Bytes',
    type(...): 'Ellipsis',
}

class slice(AST):
    """Deprecated AST node class."""

class Index(slice):
    """Deprecated AST node class. Use the index value directly instead."""
    def __new__(cls, value, **kwargs):
        return value

class ExtSlice(slice):
    """Deprecated AST node class. Use ast.Tuple instead."""
    def __new__(cls, dims=(), **kwargs):
        return Tuple(list(dims), Load(), **kwargs)

# If the ast module is loaded more than once, only add deprecated methods once
if not hasattr(Tuple, 'dims'):
    # The following code is for backward compatibility.
    # It will be removed in future.

    def _dims_getter(self):
        """Deprecated. Use elts instead."""
        return self.elts

    def _dims_setter(self, value):
        self.elts = value

    Tuple.dims = property(_dims_getter, _dims_setter)

class Suite(mod):
    """Deprecated AST node class.  Unused in Python 3."""

class AugLoad(expr_context):
    """Deprecated AST node class.  Unused in Python 3."""

class AugStore(expr_context):
    """Deprecated AST node class.  Unused in Python 3."""

class Param(expr_context):
    """Deprecated AST node class.  Unused in Python 3."""


# Large float and imaginary literals get turned into infinities in the AST.
# We unparse those infinities to INFSTR.
_INFSTR = "1e" + repr(sys.float_info.max_10_exp + 1)

@_simple_enum(IntEnum)
class _Precedence:
    """Precedence table that originated from python grammar."""

    NAMED_EXPR = auto()      # <target> := <expr1>
    TUPLE = auto()           # <expr1>, <expr2>
    YIELD = auto()           # 'yield', 'yield from'
    TEST = auto()            # 'if'-'else', 'lambda'
    OR = auto()              # 'or'
    AND = auto()             # 'and'
    NOT = auto()             # 'not'
    CMP = auto()             # '<', '>', '==', '>=', '<=', '!=',
                             # 'in', 'not in', 'is', 'is not'
    EXPR = auto()
    BOR = EXPR               # '|'
    BXOR = auto()            # '^'
    BAND = auto()            # '&'
    SHIFT = auto()           # '<<', '>>'
    ARITH = auto()           # '+', '-'
    TERM = auto()            # '*', '@', '/', '%', '//'
    FACTOR = auto()          # unary '+', '-', '~'
    POWER = auto()           # '**'
    AWAIT = auto()           # 'await'
    ATOM = auto()

    def next(self):
        try:
            return self.__class__(self + 1)
        except ValueError:
            return self


_SINGLE_QUOTES = ('"',)  # rule:quote — Nim uses double quotes only
_MULTI_QUOTES = ('"""',)
_ALL_QUOTES = (*_SINGLE_QUOTES, *_MULTI_QUOTES)

class _Unparser(NodeVisitor):
    """Methods in this class recursively traverse an AST and
    output source code for the abstract syntax; original formatting
    is disregarded."""

    def __init__(self, *, type_registry: dict[str, ] | None = None, _avoid_backslashes=False):
        self._scope_depth = 0
        self._source = []
        self._precedences = {}
        self._type_ignores = {}
        self._indent = 0
        self._avoid_backslashes = _avoid_backslashes
        self._in_try_star = False
        self._aliases = {"Object": "object", "NTuple": "tuple"}
        self._native_type_subscript = ["array", "openArray", "seq"]
        self.renamed_keywords = {}
        self.module_names = []
        self._module_rename = {"ntypes": "ncode/pydefs", "nimpy": "ncode/nimpy"}
        self._module_std = ["math"]
        self._type_registry = type_registry
        self._no_bracket_subscript = ["ptr", "ref"]  # rule:dropbrackets
        self._keywords_no_with = ["const", "let", "var", "export"]  # rule:dropwith
        self._keywords_rename = {}
        self._keywords_no_with_colon = ["block"]  # rule:dropwith
        self._context_stack = []
        self._attribute_replace = {"copy": "", "contents": "[]"}
        self._set_low_precedence = ["export"]
        self._class_def_methods = []
        self._type_suffixes = ["i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64", "f32", "f64"] #, "u", "f", "d"]
        self._func_rename = {"print": "echo", "str": "$"}
        self._subscript_rename = {} # if var or let context
        self._const_rename = {"True": "true", "False": "false", "None": "nil"}  # rule:lowercasebool
        self._enums = ["NIntEnum", "NStrEnum"]
        self._def_decorators = ["template", "iterator", "converter", "method", "calltype"]

    def interleave(self, inter, f, seq):
        """Call f on each item in seq, calling inter() in between."""
        seq = iter(seq)
        try:
            f(next(seq))
        except StopIteration:
            pass
        else:
            for x in seq:
                inter()
                f(x)

    def items_view(self, traverser, items):
        """Traverse and separate the given *items* with a comma and append it to
        the buffer. If *items* is a single item sequence, a trailing comma
        will be added."""
        if len(items) == 1:
            traverser(items[0])
            self.write(",")
        else:
            self.interleave(lambda: self.write(", "), traverser, items)

    def maybe_newline(self):
        """Adds a newline if it isn't the start of generated source"""
        if self._source:
            self.write("\n")

    def fill(self, text=""):
        """Indent a piece of text and append it, according to the current
        indentation level"""
        self.maybe_newline()
        # rule:doublespace
        self.write("  " * self._indent + text)

    def write(self, *text):
        """Add new source parts"""
        self._source.extend(text)

    @contextmanager
    def buffered(self, buffer = None):
        if buffer is None:
            buffer = []

        original_source = self._source
        self._source = buffer
        yield buffer
        self._source = original_source

    @contextmanager
    def block(self, *, extra = None, start = ":"):
        """A context manager for preparing the source for blocks. It adds
        the character':', increases the indentation on enter and decreases
        the indentation on exit. If *extra* is given, it will be directly
        appended after the colon character.
        """
        self.write(start)  # rule:dropwith
        if extra:
            self.write(extra)
        self._indent += 1
        yield
        self._indent -= 1

    @contextmanager
    def delimit(self, start, end):
        """A context manager for preparing the source for expressions. It adds
        *start* to the buffer and enters, after exit it adds *end*."""

        self.write(start)
        yield
        self.write(end)

    def delimit_if(self, start, end, condition):
        if condition:
            return self.delimit(start, end)
        else:
            return nullcontext()

    def require_parens(self, precedence, node):
        """Shortcut to adding precedence related parens"""
        return self.delimit_if("(", ")", self.get_precedence(node) > precedence)

    def get_precedence(self, node):
        return self._precedences.get(node, _Precedence.TEST)

    def set_precedence(self, precedence, *nodes):
        for node in nodes:
            self._precedences[node] = precedence

    def get_raw_docstring(self, node):
        """If a docstring node is found in the body of the *node* parameter,
        return that docstring node, None otherwise.

        Logic mirrored from ``_PyAST_GetDocString``."""
        if not isinstance(
            node, (AsyncFunctionDef, FunctionDef, ClassDef, Module)
        ) or len(node.body) < 1:
            return None
        node = node.body[0]
        if not isinstance(node, Expr):
            return None
        node = node.value
        if isinstance(node, Constant) and isinstance(node.value, str):
            return node

    def get_type_comment(self, node):
        comment = self._type_ignores.get(node.lineno) or node.type_comment
        if comment is not None:
            return f" # type: {comment}"

    def traverse(self, node):
        # rule:classdefseq
        _prev_class_def = False
        if isinstance(node, list):
            for item in node:
                class_def = isinstance(item, ClassDef)
                if class_def and not _prev_class_def:
                    # start type def
                    self.fill("type")
                    self._indent += 1
                if not class_def and _prev_class_def:
                    # end type def
                    self._indent -= 1
                    if len(self._class_def_methods) > 0:
                        self.traverse(self._class_def_methods)
                        # assume for now no nested class defs
                        self._class_def_methods = []
                self.traverse(item)
                _prev_class_def = class_def
            if len(node) > 0 and _prev_class_def: # if the last item was a class def
                # end type def
                self._indent -= 1
                if len(self._class_def_methods) > 0:
                    self.traverse(self._class_def_methods)
                    # assume for now no nested class defs
                    self._class_def_methods = []
        else:
            super().visit(node)

    # Note: as visit() resets the output text, do NOT rely on
    # NodeVisitor.generic_visit to handle any nodes (as it calls back in to
    # the subclass visit() method, which resets self._source to an empty list)
    def visit(self, node):
        """Outputs a source code string that, if converted back to an ast
        (using ast.parse) will generate an AST equivalent to *node*"""
        self._source = []
        self.traverse(node)
        return "".join(self._source)

    def _write_docstring_and_traverse_body(self, node):
        if (docstring := self.get_raw_docstring(node)):
            self._write_docstring(docstring)
            self.traverse(node.body[1:])
        else:
            self.traverse(node.body)

    def visit_Module(self, node):
        self._type_ignores = {
            ignore.lineno: f"ignore{ignore.tag}"
            for ignore in node.type_ignores
        }
        self._write_docstring_and_traverse_body(node)
        self._type_ignores.clear()

    def visit_FunctionType(self, node):
        with self.delimit("(", ")"):
            self.interleave(
                lambda: self.write(", "), self.traverse, node.argtypes
            )

        self.write(" -> ")
        self.traverse(node.returns)

    def visit_Expr(self, node):
        self.fill()
        # rule:writeexport
        if self._context_stack and self._context_stack[-1] in self._set_low_precedence:
            self.set_precedence(_Precedence.NAMED_EXPR, node.value)
        else:
            self.set_precedence(_Precedence.YIELD, node.value)
        self.traverse(node.value)

    def visit_NamedExpr(self, node):
        with self.require_parens(_Precedence.NAMED_EXPR, node):
            self.set_precedence(_Precedence.ATOM, node.target, node.value)
            self.traverse(node.target)
            self.write(" := ")
            self.traverse(node.value)

    def visit_Import(self, node):
        # rule:nodoubleimport
        refined_list = [n for n in node.names if n.name not in self.module_names]
        if refined_list:
            self.fill("import ")
            self.interleave(lambda: self.write(", "), self.traverse, refined_list)
            self.module_names += [n.name for n in refined_list]

    def visit_ImportFrom(self, node):
        # rule:import
        # self.fill("from ")
        # self.write("." * (node.level or 0))
        if node.module and not node.module in ["__future__"]:
            self.fill("import ")
            module_name = node.module
            module_name_split = module_name.split(".")
            # if module_name in self._module_rename:
            #     self.write(self._module_rename[module_name])
            if module_name in self._module_std:
                self.write("ncode/pystd/" + module_name)
            elif module_name_split[0] == "nimic":
                if module_name_split[1] in self._module_rename:
                   module_name_split[1] = self._module_rename[module_name_split[1]]
                self.write("/".join(module_name_split[1:]))
            else:
                self.module_names.append(module_name)
                self.write(node.module)
        # self.write("import ")
        # self.interleave(lambda: self.write(", "), self.traverse, node.names)

    def visit_Assign(self, node):
        self.fill()
        if len(node.targets) == 1 and isinstance(node.targets[0], Name) and getattr(node.targets[0], "id", "") == "_":
            # rule:discard
            self.write("discard ")
            self.traverse(node.value)
            return
        for target in node.targets:
            if isinstance(target, Name):
                is_module_level = (self._scope_depth == 0)
                in_declaration = any(x in self._context_stack for x in ("var", "let", "const"))
                if is_module_level and in_declaration:
                    target._is_definition = True
            # self.set_precedence(_Precedence.TUPLE, target)
            self.traverse(target)
            target._is_definition = False
        if (
            isinstance(node.value, Call)
            and isinstance(node.value.func, Name)
            and not node.value.args and not node.value.keywords
        ):
            if node.value.func.id == "_block":
                # rule:block
                self.write(" = block:")
                func_node = self._context_stack.pop()
                body = func_node.body
                with self.block(start=""):
                    if isinstance(body, list) and isinstance(body[-1], Return):
                        if body[:-1]:
                            self.traverse(body[:-1])
                        if body[-1].value:
                            # do not print "return"
                            self.fill()
                            self.traverse(body[-1].value)
            elif "var" in self._context_stack and node.value.func.id in self._type_registry.types:
                type_name = self._adjust_name(node.value.func.id, definition=False)
                self.write(": " + type_name) # needed for tuple declaration
            else:
                self.write(" = ")
                self.traverse(node.value)
        elif (
            isinstance(node.value, Call)
            and isinstance(node.value.func, Subscript)
            and not node.value.args and not node.value.keywords
        ):
            if "var" in self._context_stack and node.value.func.value.id in self._native_type_subscript:
                self.write(": ") # needed for array/openArray declaration
                self.traverse(node.value.func)
            else:
                self.write(" = ")
                self.traverse(node.value)
        else:
            self.write(" = ")
            self.traverse(node.value)
        if type_comment := self.get_type_comment(node):
            self.write(type_comment)

    def visit_AugAssign(self, node):
        self.fill()
        self.traverse(node.target)
        self.write(" " + self.ibinop[node.op.__class__.__name__] + "= ")  # rule:assign
        self.traverse(node.value)

    def visit_AnnAssign(self, node):
        self.fill()
        set_annotation = isinstance(node.annotation, Set)
        if node.simple and isinstance(node.target, Name) and not set_annotation:
            target_name = node.target.id
            if (not self._context_stack or self._context_stack[-1] != "tuple") and target_name != "result":
                is_module_level = (self._scope_depth == 0)
                in_declaration = True
                # class def or any(x in self._context_stack for x in ("var", "let", "const"))
                # rule:localname
                node.target.id = self._adjust_name(target_name, definition=(is_module_level and in_declaration))
        with self.delimit_if("(", ")", not node.simple and isinstance(node.target, Name)):
            self.traverse(node.target)
        self.write(": ")
        self.traverse(node.annotation)
        var_declaration = False # rule:varini
        if "var" in self._context_stack:
            # check this is a default class init that should be declared
            # if value is a empty call with the same name as annotation then this is a declaration
            if isinstance(node.value, Call) and len(node.value.args) == 0:
                var_declaration = isinstance(node.value.func, Name) and node.value.func.id == node.annotation.id
        if node.value and not var_declaration:
            self.write(" = ")
            self.traverse(node.value)

    def visit_Return(self, node):
        self.fill("return")
        if node.value:
            self.write(" ")
            self.traverse(node.value)

    def visit_Pass(self, node):
        # rule:pass
        self.fill("discard")

    def visit_Break(self, node):
        self.fill("break")

    def visit_Continue(self, node):
        self.fill("continue")

    def visit_Delete(self, node):
        self.fill("del ")
        self.interleave(lambda: self.write(", "), self.traverse, node.targets)

    def visit_Assert(self, node):
        self.fill("assert ")
        self.traverse(node.test)
        if node.msg:
            self.write(", ")
            self.traverse(node.msg)

    def visit_Global(self, node):
        self.fill("global ")
        self.interleave(lambda: self.write(", "), self.write, node.names)

    def visit_Nonlocal(self, node):
        self.fill("nonlocal ")
        self.interleave(lambda: self.write(", "), self.write, node.names)

    def visit_Await(self, node):
        with self.require_parens(_Precedence.AWAIT, node):
            self.write("await")
            if node.value:
                self.write(" ")
                self.set_precedence(_Precedence.ATOM, node.value)
                self.traverse(node.value)

    def visit_Yield(self, node):
        with self.require_parens(_Precedence.YIELD, node):
            self.write("yield")
            if node.value:
                self.write(" ")
                self.set_precedence(_Precedence.ATOM, node.value)
                self.traverse(node.value)

    def visit_YieldFrom(self, node):
        with self.require_parens(_Precedence.YIELD, node):
            self.write("yield from ")
            if not node.value:
                raise ValueError("Node can't be used without a value attribute.")
            self.set_precedence(_Precedence.ATOM, node.value)
            self.traverse(node.value)

    def visit_Raise(self, node):
        self.fill("raise")
        if not node.exc:
            if node.cause:
                raise ValueError(f"Node can't use cause without an exception.")
            return
        self.write(" ")
        self.traverse(node.exc)
        if node.cause:
            self.write(" from ")
            self.traverse(node.cause)

    def do_visit_try(self, node):
        self.fill("try")
        with self.block():
            self.traverse(node.body)
        for ex in node.handlers:
            self.traverse(ex)
        if node.orelse:
            self.fill("else")
            with self.block():
                self.traverse(node.orelse)
        if node.finalbody:
            self.fill("finally")
            with self.block():
                self.traverse(node.finalbody)

    def visit_Try(self, node):
        prev_in_try_star = self._in_try_star
        try:
            self._in_try_star = False
            self.do_visit_try(node)
        finally:
            self._in_try_star = prev_in_try_star

    def visit_TryStar(self, node):
        prev_in_try_star = self._in_try_star
        try:
            self._in_try_star = True
            self.do_visit_try(node)
        finally:
            self._in_try_star = prev_in_try_star

    def visit_ExceptHandler(self, node):
        self.fill("except*" if self._in_try_star else "except")
        if node.type:
            self.write(" ")
            self.traverse(node.type)
        if node.name:
            self.write(" as ")
            self.write(node.name)
        with self.block():
            self.traverse(node.body)

    def _adjust_name(self, name, definition=True):
        # rule:localname
        if len(name)>1 and name[0] == "_":
            _str = "local" + name
        elif definition and not name[0].startswith("local_"):
            _str = name + "*"
        else:
            _str = name
        return _str

    def visit_ClassDef(self, node):
        # rule:classdef
        if node.decorator_list:
            deco = node.decorator_list[0].id
        else:
            deco = ""
        # for deco in node.decorator_list:
        #     self.fill("@")
        #     self.traverse(deco)
        # rule:pragma
        body, pragma = self._get_body_and_pragma(node)
        type_str = self._adjust_name(node.name) # rule:localname
        _pass = isinstance(body[0], Pass) if body else False
        no_attr = _pass # no attributes, i.e. pass or only methods
        # deco in ["ref", "ptr", "distinct"]
        no_object = no_attr or deco
        enum = False # rule:enum
        if hasattr(node.bases[0], "id"):
            if node.bases[0].id[0] == "_":
                base = node.bases[0].id[1:]
            else:
                base = node.bases[0].id
        # else:
        #     base = ast.unparse(node.bases[0]).replace("[", " ").replace("]", "")
        if base in self._aliases:
            from_object = self._aliases[base]
        elif base in self._enums:
            from_object = "enum "
            enum = True
        elif no_object:
            # rule:typealias or rule:typedistinct
            from_object = base
        else:
            from_object = "object of " + base
        self.fill(type_str)
        if hasattr(node, "type_params"):
            self._type_params_helper(node.type_params)
        if pragma:
            self.write(" {." + pragma + ".}")
        self.write(" =")
        if deco:
            self.write(" " + deco)
        self.write(" " + from_object)
        # with self.delimit_if("(", ")", condition = node.bases or node.keywords):
        #     comma = False
        #     for e in node.bases:
        #         if comma:
        #             self.write(", ")
        #         else:
        #             comma = True
        #         self.traverse(e)
        #     for e in node.keywords:
        #         if comma:
        #             self.write(", ")
        #         else:
        #             comma = True
        #         self.traverse(e)
        if not _pass:
            with self.block(start=""):
                # rule:classdefseq, split body into attributes and methods
                body_rest = []
                if not isinstance(body, list):
                    body = [body]
                for b in body:
                    if isinstance(b, FunctionDef) or isinstance(b, AsyncFunctionDef):
                        # check if self is annotated
                        if b.args.args and b.args.args[0].arg == "self" and b.args.args[0].annotation is None:
                            # rule:annotateself
                            type_name = self._adjust_name(node.name, definition=False)
                            b.args.args[0].annotation = Name(id=type_name, ctx=Load())
                        self._class_def_methods.append(b)
                    else:
                        if enum and isinstance(b, Assign) and isinstance(b.value, Call) and \
                            isinstance(b.value.func, Name) and b.value.func.id == "auto":
                            body_rest.append(b.targets[0])
                        else:
                            body_rest.append(b)
                if body_rest:
                    # rule:matchcase, check for variant types
                    if (len(body_rest) > 1) and isinstance(body_rest[0], AnnAssign) and isinstance(body_rest[1], Match):
                        discriminator_name = self._adjust_name(body_rest[0].target.id) # rule:localname
                        discriminator_type = body_rest[0].annotation.id
                        self.fill(f"case {discriminator_name}: {discriminator_type}")
                        with self.block(start=""):
                            for case in body_rest[1].cases:
                                self.traverse(case)
                        if (len(body_rest) > 2):
                            self.traverse(body_rest[2:])
                    else:
                        if enum:
                            self.fill()
                            self.interleave(lambda: self.write(", "), self.traverse, body_rest)
                        else:
                            self._context_stack.append(from_object)
                            self.traverse(body_rest)
                            self._context_stack.pop()
        self.maybe_newline()

    def visit_FunctionDef(self, node):
        self._scope_depth += 1
        self._function_helper(node, "")
        self._scope_depth -= 1

    def visit_AsyncFunctionDef(self, node):
        self._scope_depth += 1
        self._function_helper(node, "async ")
        self._scope_depth -= 1

    def _check_packed_tuple(self, node_arg_args, body):
        # rule:funcdefpackedtuple
        for i, arg in enumerate(node_arg_args):
            if isinstance(arg.annotation, Subscript) and isinstance(arg.annotation.slice, Tuple) and\
                arg.arg.startswith("packed_tuple"):
                ast_name = arg.annotation.value
                if isinstance(ast_name, Name) and ast_name.id == "tuple":
                    tuple_name = arg.arg
                    types = arg.annotation.slice.elts
                    drop_j = -1
                    for j, item in enumerate(body):
                        if isinstance(item, Assign) and isinstance(item.value, Name) and item.value.id == tuple_name:
                            if isinstance(item.targets[0], Tuple):
                                defs = [elt.id + ": " + tp.id for elt, tp in zip(item.targets[0].elts, types)]
                                ast_name.id = ", ".join(defs)
                                node_arg_args[i] = ast_name
                                drop_j = j
                    if drop_j > -1:
                        body.pop(drop_j)

    def _has_yield(self, node):
        for x in node:
            if isinstance(x, Expr) and isinstance(x.value, Yield):
                return True
            if (isinstance(x, For) or isinstance(x, While)) and self._has_yield(x.body):
                return True
        return False

    def _function_helper(self, node, fill_suffix):
        if node.name == "_block":
            self._context_stack.append(node)
            return
        # rule:funcdef
        self.maybe_newline()
        decl_str = "proc"
        # rule:funcdefdecorated
        for deco in node.decorator_list:
            if isinstance(deco, Name) and deco.id in self._def_decorators:
                decl_str = deco.id
        # rule:pragma
        body, pragma = self._get_body_and_pragma(node)
        # rule:funcdefbody
        write_body = not isinstance(body[0], Pass)
        if pragma:
            parsed_pragma = pragma.replace(" ", "").split(",")
            write_body = write_body and "borrow" not in parsed_pragma
            if "noSideEffect" in parsed_pragma and decl_str == "proc":
                decl_str = "func"
                pragma = ",".join([x for x in parsed_pragma if x != "noSideEffect"])
        func_name = node.name
        do_arg_swap = False  # rule:funcdefargswap
        inplace = False  # rule:funcdefinplace
        no_return = False  # rule:typedtemplate
        if func_name[0:2] == "__" and func_name in self.dunder_ops:
            do_arg_swap = func_name in self.binpops_with_arg_swap
            inplace = func_name[2] == "i"
            func_name = self.dunder_ops[func_name]   # rule:funcdefrenamedunder
        # rule:funcdefyield
        if decl_str != "iterator" and self._has_yield(body):
           decl_str = "iterator"
        name_str = self._adjust_name(func_name)  # rule:localname
        # rule:calltype — emit as type alias: Name* = proc(...): T {.pragma.}
        if decl_str == "calltype":
            self.fill("type")
            self.fill("  " + name_str + " = proc")
            with self.delimit("(", ")"):
                self.traverse(node.args)
            if node.returns and not isinstance(node.returns, Constant):
                self.write(": ")
                self.traverse(node.returns)
            if pragma:
                self.write(" {." + pragma + ".}")
            return
        def_str = fill_suffix + decl_str + " " + name_str
        if inplace and isinstance(node.args.args[0].annotation, Name):
            node.args.args[0].annotation.id = "var " + node.args.args[0].annotation.id
        if do_arg_swap:
            node.args.args[0], node.args.args[1] = node.args.args[1], node.args.args[0]
        self._check_packed_tuple(node.args.args, body) # rule:funcdefpackedtuple
        self.fill(def_str)
        if hasattr(node, "type_params"):
            self._type_params_helper(node.type_params)
        with self.delimit("(", ")"):
            self.traverse(node.args)
        if node.returns and not isinstance(node.returns, Constant) and not inplace:
            self.write(": ")
            self.traverse(node.returns)
            typed_template = decl_str == "template" and isinstance(node.returns, Name) \
                and not node.returns.id == "untyped"
            no_return = typed_template or decl_str == "converter"
        if pragma:
            self.write(" {." + pragma + ".}")
        if write_body:
            with self.block(extra=self.get_type_comment(node), start=" ="):
                if isinstance(body, list) and isinstance(body[-1], Return):
                    if body[:-1]:
                        self.traverse(body[:-1])
                    if no_return:
                        if body[-1].value:
                            # do not print "return"
                            self.fill()
                            self.traverse(body[-1].value)
                    elif not inplace:
                        self.traverse(body[-1])
                else:
                    self.traverse(body)

    def _get_pragma(self, docstring_value):
        doc = docstring_value
        if "{." in doc:
            pragma = doc.split("{.")[1].split(".}")[0]
        else:
            pragma = ""
        return pragma

    def _get_body_and_pragma(self, node):
        if (docstring := self.get_raw_docstring(node)):
            # check if pragma {. .} is present
            pragma = self._get_pragma(docstring.value)
            body = node.body[1:]
        else:
            pragma = ""
            body = node.body
        return body, pragma

    def _type_params_helper(self, type_params):
        if type_params is not None and len(type_params) > 0:
            with self.delimit("[", "]"):
                self.interleave(lambda: self.write(", "), self.traverse, type_params)

    def visit_TypeVar(self, node):
        self.write(node.name)
        if node.bound:
            self.write(": ")
            self.traverse(node.bound)

    def visit_TypeVarTuple(self, node):
        self.write("*" + node.name)

    def visit_ParamSpec(self, node):
        self.write("**" + node.name)

    def visit_TypeAlias(self, node):
        self.fill("type ")
        self.traverse(node.name)
        self._type_params_helper(node.type_params)
        self.write(" = ")
        self.traverse(node.value)

    def visit_For(self, node):
        self._for_helper("for ", node)

    def visit_AsyncFor(self, node):
        self._for_helper("async for ", node)

    def _for_helper(self, fill, node):
        self.fill(fill)
        self.set_precedence(_Precedence.TUPLE, node.target)
        self.traverse(node.target)
        self.write(" in ")
        self.traverse(node.iter)
        with self.block(extra=self.get_type_comment(node)):
            self.traverse(node.body)
        if node.orelse:
            self.fill("else")
            with self.block():
                self.traverse(node.orelse)

    def visit_If(self, node):
        # rule:comptime
        comptime = isinstance(node.test, Call) and isinstance(node.test.func, Name) and node.test.func.id == "comptime"
        if comptime:
            self.fill("when ")
            self.traverse(node.test.args[0])
        else:
            self.fill("if ")
            self.traverse(node.test)
        with self.block():
            self._scope_depth += 1
            self.traverse(node.body)
            self._scope_depth -= 1
        # collapse nested ifs into equivalent elifs.
        while node.orelse and len(node.orelse) == 1 and isinstance(node.orelse[0], If):
            node = node.orelse[0]
            self.fill("elif ")
            self.traverse(node.test)
            with self.block():
                self._scope_depth += 1
                self.traverse(node.body)
                self._scope_depth -= 1
        # final else
        if node.orelse:
            self.fill("else")
            with self.block():
                self._scope_depth += 1
                self.traverse(node.orelse)
                self._scope_depth -= 1

    def visit_While(self, node):
        self.fill("while ")
        self.traverse(node.test)
        with self.block():
            self.traverse(node.body)
        if node.orelse:
            self.fill("else")
            with self.block():
                self.traverse(node.orelse)

    def write_template_inline(self, node):
        if isinstance(node.body[0], Assign):
            assign = node.body[0]
            pragma_str = ""
        else:
            assign = node.body[1]
            pragma = self._get_pragma(node.body[0].value.value)
            pragma_str = "{." + pragma + ".} "
        tname = assign.targets[0].id
        # apply rule:localname
        self.fill(f"template {self._adjust_name(tname)}(): untyped {pragma_str}=")
        with self.block(start=""):
            self.fill()
            self.traverse(assign.value)

    def visit_With(self, node):
        # rule:dropwith
        if isinstance(node.items[0].context_expr, Name):
            name = node.items[0].context_expr.id
            start = ":"
            if name in self._keywords_no_with:
                self.fill()
                self._context_stack.append(name)
                cont_pop = True
                start = ""
            elif name in self._keywords_no_with_colon:
                self.fill()
                self._context_stack.append(name)
                cont_pop = True
            if name in self._keywords_rename:
                node.items[0].context_expr.id = self._keywords_rename[name]
        else:
            self.fill("with ")
            cont_pop = False
        if name == "template_inline":
            # rule:templateinline
            self.write_template_inline(node)
        else:
            self.interleave(lambda: self.write(", "), self.traverse, node.items)
            with self.block(extra=self.get_type_comment(node), start=start):
                self.traverse(node.body)
            if cont_pop:
                self._context_stack.pop()

    def visit_AsyncWith(self, node):
        self.fill("async with ")
        self.interleave(lambda: self.write(", "), self.traverse, node.items)
        with self.block(extra=self.get_type_comment(node)):
            self.traverse(node.body)

    def _str_literal_helper(
        self, string, *, quote_types=_ALL_QUOTES, escape_special_whitespace=False
    ):
        """Helper for writing string literals, minimizing escapes.
        Returns the tuple (string literal to write, possible quote types).
        """
        def escape_char(c):
            # \n and \t are non-printable, but we only escape them if
            # escape_special_whitespace is True
            if not escape_special_whitespace and c in "\n\t":
                return c
            # Always escape backslashes and other non-printable characters
            if c == "\\" or not c.isprintable():
                return c.encode("unicode_escape").decode("ascii")
            return c

        escaped_string = "".join(map(escape_char, string))
        possible_quotes = quote_types
        if "\n" in escaped_string:
            possible_quotes = [q for q in possible_quotes if q in _MULTI_QUOTES]
        possible_quotes = [q for q in possible_quotes if q not in escaped_string]
        if not possible_quotes:
            # If there aren't any possible_quotes, fallback to using repr
            # on the original string. Try to use a quote from quote_types,
            # e.g., so that we use triple quotes for docstrings.
            string = repr(string)
            quote = next((q for q in quote_types if string[0] in q), string[0])
            return string[1:-1], [quote]
        if escaped_string:
            # Sort so that the trailing-quote escape uses the less common option
            possible_quotes.sort(key=lambda q: q[0] == escaped_string[-1])
            # If we're using triple quotes and we'd need to escape a final
            # quote, escape it
            if possible_quotes[0][0] == escaped_string[-1]:
                assert len(possible_quotes[0]) == 3
                escaped_string = escaped_string[:-1] + "\\" + escaped_string[-1]
        return escaped_string, possible_quotes

    def _write_str_avoiding_backslashes(self, string, *, quote_types=_ALL_QUOTES):
        """Write string literal value with a best effort attempt to avoid backslashes."""
        string, quote_types = self._str_literal_helper(string, quote_types=quote_types)
        quote_type = quote_types[0]
        self.write(f"{quote_type}{string}{quote_type}")

    def visit_JoinedStr(self, node):
        self.write("&")  # rule:stringjoin

        fstring_parts = []
        for value in node.values:
            with self.buffered() as buffer:
                self._write_fstring_inner(value)
            fstring_parts.append(
                ("".join(buffer), isinstance(value, Constant))
            )

        new_fstring_parts = []
        quote_types = list(_ALL_QUOTES)
        fallback_to_repr = False
        for value, is_constant in fstring_parts:
            if is_constant:
                value, new_quote_types = self._str_literal_helper(
                    value,
                    quote_types=quote_types,
                    escape_special_whitespace=True,
                )
                if set(new_quote_types).isdisjoint(quote_types):
                    fallback_to_repr = True
                    break
                quote_types = new_quote_types
            elif "\n" in value:  # rule:quote
                quote_types = [q for q in quote_types if q in _MULTI_QUOTES]
                assert quote_types
            new_fstring_parts.append(value)

        if fallback_to_repr:
            # If we weren't able to find a quote type that works for all parts
            # of the JoinedStr, fallback to triple double quotes.
            quote_types = ['"""']
            new_fstring_parts.clear()
            for value, is_constant in fstring_parts:
                if is_constant:
                    # Escape inner double quotes for triple-double-quoted string
                    value = value.replace("\\", "\\\\")
                    value = value.replace('"', '\\"')
                new_fstring_parts.append(value)

        value = "".join(new_fstring_parts)
        quote_type = quote_types[0]
        self.write(f"{quote_type}{value}{quote_type}")

    def _write_fstring_inner(self, node, is_format_spec=False):
        if isinstance(node, JoinedStr):
            # for both the f-string itself, and format_spec
            for value in node.values:
                self._write_fstring_inner(value, is_format_spec=is_format_spec)
        elif isinstance(node, Constant) and isinstance(node.value, str):
            value = node.value.replace("{", "{{").replace("}", "}}")

            if is_format_spec:
                value = value.replace("\\", "\\\\")
                value = value.replace("'", "\\'")
                value = value.replace('"', '\\"')
                value = value.replace("\n", "\\n")
            self.write(value)
        elif isinstance(node, FormattedValue):
            self.visit_FormattedValue(node)
        else:
            raise ValueError(f"Unexpected node inside JoinedStr, {node!r}")

    def visit_FormattedValue(self, node):
        def unparse_inner(inner):
            unparser = type(self)()
            unparser.set_precedence(_Precedence.TEST.next(), inner)
            return unparser.visit(inner)

        with self.delimit("{", "}"):
            expr = unparse_inner(node.value)
            if expr.startswith("{"):
                # Separate pair of opening brackets as "{ {"
                self.write(" ")
            self.write(expr)
            if node.conversion != -1:
                self.write(f"!{chr(node.conversion)}")
            if node.format_spec:
                self.write(":")
                self._write_fstring_inner(node.format_spec, is_format_spec=True)

    def visit_Name(self, node):
        name = self._adjust_name(node.id, definition=getattr(node, "_is_definition", False)) # rule:localname
        self.write(name)

    def _write_docstring(self, node):
        self.fill()
        if node.kind == "u":
            self.write("u")
        self._write_str_avoiding_backslashes(node.value, quote_types=_MULTI_QUOTES)

    def _write_constant(self, value):
        if isinstance(value, (float, complex)):
            # Substitute overflowing decimal literal for AST infinities,
            # and inf - inf for NaNs.
            self.write(
                repr(value)
                .replace("inf", _INFSTR)
                .replace("nan", f"({_INFSTR}-{_INFSTR})")
            )
        elif self._avoid_backslashes and isinstance(value, str):
            self._write_str_avoiding_backslashes(value)
        else:
            # rule:quote
            if isinstance(value, str):
                # Escape inner double quotes and special chars, wrap in double quotes
                escaped = value.replace("\\", "\\\\")
                escaped = escaped.replace('"', '\\"')
                escaped = escaped.replace("\n", "\\n")
                escaped = escaped.replace("\t", "\\t")
                escaped = escaped.replace("\r", "\\r")
                repr_value = f'"{escaped}"'
            else:
                repr_value = repr(value)
            if repr_value in self._const_rename:
                # rule:lowercasebool
                self.write(self._const_rename[repr_value])
            else:
                self.write(repr_value)

    def visit_Constant(self, node):
        value = node.value
        if isinstance(value, tuple):
            with self.delimit("(", ")"):
                self.items_view(self._write_constant, value)
        elif value is ...:
            self.write("...")
        else:
            if node.kind == "u":
                self.write("u")
            self._write_constant(node.value)

    def visit_List(self, node):
        with self.delimit("[", "]"):
            self.interleave(lambda: self.write(", "), self.traverse, node.elts)

    def visit_ListComp(self, node):
        with self.delimit("[", "]"):
            self.traverse(node.elt)
            for gen in node.generators:
                self.traverse(gen)

    def visit_GeneratorExp(self, node):
        with self.delimit("(", ")"):
            self.traverse(node.elt)
            for gen in node.generators:
                self.traverse(gen)

    def visit_SetComp(self, node):
        with self.delimit("{", "}"):
            self.traverse(node.elt)
            for gen in node.generators:
                self.traverse(gen)

    def visit_DictComp(self, node):
        with self.delimit("{", "}"):
            self.traverse(node.key)
            self.write(": ")
            self.traverse(node.value)
            for gen in node.generators:
                self.traverse(gen)

    def visit_comprehension(self, node):
        if node.is_async:
            self.write(" async for ")
        else:
            self.write(" for ")
        self.set_precedence(_Precedence.TUPLE, node.target)
        self.traverse(node.target)
        self.write(" in ")
        self.set_precedence(_Precedence.TEST.next(), node.iter, *node.ifs)
        self.traverse(node.iter)
        for if_clause in node.ifs:
            self.write(" if ")
            self.traverse(if_clause)

    def visit_IfExp(self, node):
        with self.require_parens(_Precedence.TEST, node):
            self.set_precedence(_Precedence.TEST.next(), node.body, node.test)
            # rule:inlineif
            self.write("if ")
            self.traverse(node.test)
            self.write(": ")
            self.traverse(node.body)
            self.write(" else: ")
            self.set_precedence(_Precedence.TEST, node.orelse)
            self.traverse(node.orelse)

    def visit_Set(self, node):
        if node.elts:
            with self.delimit("{", "}"):
                self.interleave(lambda: self.write(", "), self.traverse, node.elts)
        else:
            # `{}` would be interpreted as a dictionary literal, and
            # `set` might be shadowed. Thus:
            self.write('{*()}')

    def visit_Dict(self, node):
        def write_key_value_pair(k, v):
            self.traverse(k)
            self.write(": ")
            self.traverse(v)

        def write_item(item):
            k, v = item
            if k is None:
                # for dictionary unpacking operator in dicts {**{'y': 2}}
                # see PEP 448 for details
                self.write("**")
                self.set_precedence(_Precedence.EXPR, v)
                self.traverse(v)
            else:
                write_key_value_pair(k, v)

        with self.delimit("{", "}"):
            self.interleave(
                lambda: self.write(", "), write_item, zip(node.keys, node.values)
            )

    def visit_Tuple(self, node):
        with self.delimit_if(
            "(",
            ")",
            len(node.elts) == 0 or self.get_precedence(node) > _Precedence.TUPLE
        ):
            self.items_view(self.traverse, node.elts)

    unop = {"Invert": "~", "Not": "not", "UAdd": "+", "USub": "-"}
    unop_precedence = {
        "not": _Precedence.NOT,
        "~": _Precedence.FACTOR,
        "+": _Precedence.FACTOR,
        "-": _Precedence.FACTOR,
    }

    def visit_UnaryOp(self, node):
        operator = self.unop[node.op.__class__.__name__]
        operator_precedence = self.unop_precedence[operator]
        with self.require_parens(operator_precedence, node):
            self.write(operator)
            # factor prefixes (+, -, ~) shouldn't be separated
            # from the value they belong, (e.g: +1 instead of + 1)
            if operator_precedence is not _Precedence.FACTOR:
                self.write(" ")
            self.set_precedence(operator_precedence, node.operand)
            self.traverse(node.operand)
    # rule:assign
    ibinop = {
        "Add": "+",
        "Sub": "-",
        "Mult": "*",
        "MatMult": "@",
        "Div": "/",
        "Mod": "%",
        "LShift": "", # "<<",
        "RShift": ">>",
        "BitOr": "|",
        "BitXor": "^",
        "BitAnd": "&",
        "FloorDiv": "//",
        "Pow": "**",
    }
    # rule:bitwiserename
    binop = {
        "Add": "+",
        "Sub": "-",
        "Mult": "*",
        "MatMult": "@",
        "Div": "/",
        "Mod": "mod",
        "LShift": "shl",
        "RShift": "shr",
        "BitOr": "or",
        "BitXor": "xor",
        "BitAnd": "and",
        "FloorDiv": "div",
        "Pow": "^",
    }
    # rule:funcdefargswap
    binpops_with_arg_swap = ["__radd__", "__rmul__", "__rmatmul__", "__rdiv__", "__rfloordiv__"]
    # rule:funcdefrenamedunder
    dunder_ops = {
        # unops
        "__str__": "`$`",
        "__getitem__": "`[]`",
        "__setitem__": "`[]=`",
        # "__invert__": "`~`",
        "__not__": "`not`",
        "__pos__": "`+`",
        "__neg__": "`-`",
        # binops
        "__eq__": "`==`",
        "__add__": "`+`",
        "__radd__": "`+`",
        "__sub__": "`-`",
        "__mul__": "`*`",
        "__rmul__": "`*`",
        "__matmul__": "`@`",
        "__truediv__": "`/`",
        "__floordiv__": "`div`",
        "__mod__": "`mod`",
        "__pow__": "`^`",
        "__lshift__": "`shl`",
        "__rshift__": "`shr`",
        "__and__": "`and`",
        "__xor__": "`xor`",
        "__or__": "`|`",
        "__iadd__": "`+=`",
        "__isub__": "`-=`",
        "__imul__": "`*=`",
        "__imatmul__": "`@=`",
        "__itruediv__": "`/=`",
        "__ifloordiv__": "`//=`",
        "__imod__": "`%=`",
        "__ipow__": "`**=`",
        "__ilshift__": "`<<=`",
        "__irshift__": "`>>=`",
        "__iand__": "`&=`",
        "__ixor__": "`^=`",
        "__ior__": "`|=`",
        "__lt__": "`<`",
        "__le__": "`<=`",
        "__gt__": "`>`",
        "__ge__": "`>=`",
        "__ne__": "`!=`",
    }
# rule:bitwiserename
    binop_precedence = {
        "+": _Precedence.ARITH,
        "-": _Precedence.ARITH,
        "*": _Precedence.TERM,
        "@": _Precedence.TERM,
        "/": _Precedence.TERM,
        "mod": _Precedence.TERM,
        "shl": _Precedence.TERM, #_Precedence.SHIFT,
        "shr": _Precedence.TERM, #_Precedence.SHIFT,
        "or": _Precedence.BOR,
        "xor": _Precedence.BXOR,
        "and": _Precedence.BAND,
        "div": _Precedence.TERM,
        "^": _Precedence.POWER,
    }

    binop_rassoc = frozenset(("**",))
    def visit_BinOp(self, node):
        operator = self.binop[node.op.__class__.__name__]
        operator_precedence = self.binop_precedence[operator]
        with self.require_parens(operator_precedence, node):
            if operator in self.binop_rassoc:
                left_precedence = operator_precedence.next()
                right_precedence = operator_precedence
            else:
                left_precedence = operator_precedence
                right_precedence = operator_precedence.next()

            self.set_precedence(left_precedence, node.left)
            self.traverse(node.left)
            self.write(f" {operator} ")
            self.set_precedence(right_precedence, node.right)
            self.traverse(node.right)

    cmpops = {
        "Eq": "==",
        "NotEq": "!=",
        "Lt": "<",
        "LtE": "<=",
        "Gt": ">",
        "GtE": ">=",
        "Is": "is",
        "IsNot": "isnot",  # rule:isnot
        "In": "in",
        "NotIn": "notin",  # rule:notin
    }

    def visit_Compare(self, node):
        with self.require_parens(_Precedence.CMP, node):
            self.set_precedence(_Precedence.CMP.next(), node.left, *node.comparators)
            # rule:main, check for "__name__ == __main__"
            if isinstance(node.left, Name) and node.left.id == "__name__" and isinstance(node.ops[0], Eq) and \
                isinstance(node.comparators[0], Constant) and node.comparators[0].value == "__main__":
                self.write("isMainModule")
            else:
                self.traverse(node.left)
                for o, e in zip(node.ops, node.comparators):
                    self.write(" " + self.cmpops[o.__class__.__name__] + " ")
                    self.traverse(e)

    boolops = {"And": "and", "Or": "or"}
    boolop_precedence = {"and": _Precedence.AND, "or": _Precedence.OR}

    def visit_BoolOp(self, node):
        operator = self.boolops[node.op.__class__.__name__]
        operator_precedence = self.boolop_precedence[operator]

        def increasing_level_traverse(node):
            nonlocal operator_precedence
            operator_precedence = operator_precedence.next()
            self.set_precedence(operator_precedence, node)
            self.traverse(node)

        with self.require_parens(operator_precedence, node):
            s = f" {operator} "
            self.interleave(lambda: self.write(s), increasing_level_traverse, node.values)

    def visit_Attribute(self, node):
        self.set_precedence(_Precedence.ATOM, node.value)
        self.traverse(node.value)
        # Special case: 3.__abs__() is a syntax error, so if node.value
        # is an integer literal then we need to either parenthesize
        # it or add an extra space to get 3 .__abs__().
        if isinstance(node.value, Constant) and isinstance(node.value.value, int):
            self.write(" ")
        if node.attr in self._attribute_replace:
            # rule:deref and rule:copy
            self.write(self._attribute_replace[node.attr])
        else:
            self.write(".")
            attr = self._adjust_name(node.attr, definition=False) # rule:localname
            self.write(attr)

    def visit_Call(self, node):
        self.set_precedence(_Precedence.ATOM, node.func)
        if isinstance(node.func, Name) and node.func.id in self._type_suffixes:
            # rule:literaltypes
            self.traverse(node.args[0]) # should be only one argument
            self.write("'")
            self.traverse(node.func)
        elif isinstance(node.func, Name) and node.func.id == "ch":
            # rule:char
            val = node.args[0].value
            if val.isascii():
                self.write(f"'{val}'")
            else:
                st = val.encode("Latin-1").hex()
                self.write(f"'\\x{st}'")
        elif isinstance(node.func, Attribute) and node.func.attr in self._attribute_replace and not node.args:
            # rule:deref and rule:copy
            self.traverse(node.func.value)
            self.write(self._attribute_replace[node.func.attr])
        else:
            pop = False
            if isinstance(node.func, Name):
                _name = node.func.id
                is_local_class = _name.startswith("_") and _name[1].isupper() or \
                    _name.startswith("local_") and _name[6].isupper()
                if _name[0].isupper() or is_local_class:
                    # rule:instantiation, classes instantiated with keywords should be named starting with a capital letter
                    self._context_stack.append("instance")
                else:
                    self._context_stack.append("call")
                pop = True
                # rule:funcrename
                if _name in self._func_rename:
                    node.func.id = self._func_rename[_name]
            elif (
                isinstance(node.func, Subscript)
                and node.args
                and isinstance(node.args[0], List)
                and node.func.value.id in self._native_type_subscript
                and len(node.func.slice.elts) == 2
                and isinstance(node.args[0].elts[0], Constant)
            ):
                # rule:array
                array_type = node.func.slice.elts[1].id
                call_node = Call(func=Name(id=array_type), args=[Constant(value=node.args[0].elts[0].value)], keywords=[])
                node.args[0].elts[0] = call_node
            self.traverse(node.func)
            with self.delimit("(", ")"):
                comma = False
                for e in node.args:
                    if comma:
                        self.write(", ")
                    else:
                        comma = True
                    self.traverse(e)
                for e in node.keywords:
                    if comma:
                        self.write(", ")
                    else:
                        comma = True
                    self.traverse(e)
            if pop:
                self._context_stack.pop()

    def visit_Subscript(self, node):
        def is_non_empty_tuple(slice_value):
            return (
                isinstance(slice_value, Tuple)
                and slice_value.elts
            )

        self.set_precedence(_Precedence.ATOM, node.value)
        # feature:subscriptrename
        if isinstance(node.value, Name) and node.value.id in self._subscript_rename and self._context_stack:
            if self._context_stack[-1] in self._keywords_no_with:
                node.value.id = self._subscript_rename[node.value.id]
        self.traverse(node.value)
        # rule:dropbrackets, ptr[] -> ptr
        if isinstance(node.value, Name) and node.value.id in self._no_bracket_subscript:
            self.write(" ")
            self.traverse(node.slice)
        else:
            with self.delimit("[", "]"):
                if is_non_empty_tuple(node.slice):
                    # parentheses can be omitted if the tuple isn't empty
                    self.items_view(self.traverse, node.slice.elts)
                else:
                    self.traverse(node.slice)

    def visit_Starred(self, node):
        self.write("*")
        self.set_precedence(_Precedence.EXPR, node.value)
        self.traverse(node.value)

    def visit_Ellipsis(self, node):
        self.write("...")

    def visit_Slice(self, node):
        # rule:slice
        if node.lower:
            self.traverse(node.lower)
        else:
            self.write("0")
        if node.upper:
            self.write("..<")
            self.traverse(node.upper)
            # negative upper bound is not allowed, also not literals
        else:
            self.write("..^1")
        if node.step:
            self.write(":")
            self.traverse(node.step)

    def visit_Match(self, node):
        # rule:matchcase
        self.fill("case ")
        self.traverse(node.subject)
        with self.block():
            for case in node.cases:
                self.traverse(case)

    def visit_arg(self, node):
        _name = self._adjust_name(node.arg, definition=False) # rule:localname
        self.write(_name)
        if node.annotation:
            self.write(": ")
            ann = node.annotation
            # rule:funcdefmut, check if annotated as mutable "mut @"
            if isinstance(ann, BinOp) and isinstance(ann.op, MatMult) and \
                isinstance(ann.left, Name) and ann.left.id == "mut":
                self.write("var ")
                self.traverse(ann.right)
            else:
                self.traverse(node.annotation)

    def visit_arguments(self, node):
        first = True
        # normal arguments
        all_args = node.posonlyargs + node.args
        defaults = [None] * (len(all_args) - len(node.defaults)) + node.defaults
        for index, elements in enumerate(zip(all_args, defaults), 1):
            a, d = elements
            if first:
                first = False
            else:
                self.write(", ")
            self.traverse(a)
            if d:
                self.write("=")
                self.traverse(d)
            if index == len(node.posonlyargs):
                self.write(", /")

        # varargs, or bare '*' if no varargs but keyword-only arguments present
        if node.vararg or node.kwonlyargs:
            if first:
                first = False
            else:
                self.write(", ")
            self.write("*")
            if node.vararg:
                self.write(node.vararg.arg)
                if node.vararg.annotation:
                    self.write(": ")
                    self.traverse(node.vararg.annotation)

        # keyword-only arguments
        if node.kwonlyargs:
            for a, d in zip(node.kwonlyargs, node.kw_defaults):
                self.write(", ")
                self.traverse(a)
                if d:
                    self.write("=")
                    self.traverse(d)

        # kwargs
        if node.kwarg:
            if first:
                first = False
            else:
                self.write(", ")
            self.write("**" + node.kwarg.arg)
            if node.kwarg.annotation:
                self.write(": ")
                self.traverse(node.kwarg.annotation)

    def visit_keyword(self, node):
        if node.arg is None:
            self.write("**")
        else:
            self.write(node.arg)
            # rule:instantiation
            if self._context_stack and self._context_stack[-1] == "instance":
                self.write(":")
            else:
                self.write("=")
        self.traverse(node.value)

    def visit_Lambda(self, node):
        with self.require_parens(_Precedence.TEST, node):
            self.write("lambda")
            with self.buffered() as buffer:
                self.traverse(node.args)
            if buffer:
                self.write(" ", *buffer)
            self.write(": ")
            self.set_precedence(_Precedence.TEST, node.body)
            self.traverse(node.body)

    def visit_alias(self, node):
        self.write(node.name)
        if node.asname:
            self.write(" as " + node.asname)

    def visit_withitem(self, node):
        self.traverse(node.context_expr)
        if node.optional_vars:
            self.write(" as ")
            self.traverse(node.optional_vars)

    def visit_match_case(self, node):
        # rule:matchcase
        if isinstance(node.pattern, MatchAs) and node.pattern.name is None and node.pattern.pattern is None:
            self.fill("else")
        else:
            self.fill("of ")
            self.traverse(node.pattern)

        if node.guard:
            self.write(" if ")
            self.traverse(node.guard)
        with self.block():
            self.traverse(node.body)

    def visit_MatchValue(self, node):
        self.traverse(node.value)

    def visit_MatchSingleton(self, node):
        self._write_constant(node.value)

    def visit_MatchSequence(self, node):
        with self.delimit("[", "]"):
            self.interleave(
                lambda: self.write(", "), self.traverse, node.patterns
            )

    def visit_MatchStar(self, node):
        name = node.name
        if name is None:
            name = "_"
        self.write(f"*{name}")

    def visit_MatchMapping(self, node):
        def write_key_pattern_pair(pair):
            k, p = pair
            self.traverse(k)
            self.write(": ")
            self.traverse(p)

        with self.delimit("{", "}"):
            keys = node.keys
            self.interleave(
                lambda: self.write(", "),
                write_key_pattern_pair,
                zip(keys, node.patterns, strict=True),
            )
            rest = node.rest
            if rest is not None:
                if keys:
                    self.write(", ")
                self.write(f"**{rest}")

    def visit_MatchClass(self, node):
        self.set_precedence(_Precedence.ATOM, node.cls)
        self.traverse(node.cls)
        with self.delimit("(", ")"):
            patterns = node.patterns
            self.interleave(
                lambda: self.write(", "), self.traverse, patterns
            )
            attrs = node.kwd_attrs
            if attrs:
                def write_attr_pattern(pair):
                    attr, pattern = pair
                    self.write(f"{attr}=")
                    self.traverse(pattern)

                if patterns:
                    self.write(", ")
                self.interleave(
                    lambda: self.write(", "),
                    write_attr_pattern,
                    zip(attrs, node.kwd_patterns, strict=True),
                )

    def visit_MatchAs(self, node):
        name = node.name
        pattern = node.pattern
        if name is None:
            self.write("_")
        elif pattern is None:
            self.write(node.name)
        else:
            with self.require_parens(_Precedence.TEST, node):
                self.set_precedence(_Precedence.BOR, node.pattern)
                self.traverse(node.pattern)
                self.write(f" as {node.name}")

    def visit_MatchOr(self, node):
        with self.require_parens(_Precedence.BOR, node):
            self.set_precedence(_Precedence.BOR.next(), *node.patterns)
            self.interleave(lambda: self.write(", "), self.traverse, node.patterns)

def unparse(ast_obj, type_registry: dict[str, ] | None = None):
    unparser = _Unparser(type_registry=type_registry)
    return unparser.visit(ast_obj), unparser.module_names


_deprecated_globals = {
    name: globals().pop(name)
    for name in ('Num', 'Str', 'Bytes', 'NameConstant', 'Ellipsis')
}

def __getattr__(name):
    if name in _deprecated_globals:
        globals()[name] = value = _deprecated_globals[name]
        import warnings
        warnings._deprecated(
            f"ast.{name}", message=_DEPRECATED_CLASS_MESSAGE, remove=(3, 14)
        )
        return value
    raise AttributeError(f"module 'ast' has no attribute '{name}'")


def main():
    import argparse

    parser = argparse.ArgumentParser(prog='python -m ast')
    parser.add_argument('infile', type=argparse.FileType(mode='rb'), nargs='?',
                        default='-',
                        help='the file to parse; defaults to stdin')
    parser.add_argument('-m', '--mode', default='exec',
                        choices=('exec', 'single', 'eval', 'func_type'),
                        help='specify what kind of code must be parsed')
    parser.add_argument('--no-type-comments', default=True, action='store_false',
                        help="don't add information about type comments")
    parser.add_argument('-a', '--include-attributes', action='store_true',
                        help='include attributes such as line numbers and '
                             'column offsets')
    parser.add_argument('-i', '--indent', type=int, default=3,
                        help='indentation of nodes (number of spaces)')
    args = parser.parse_args()

    with args.infile as infile:
        source = infile.read()
    tree = parse(source, args.infile.name, args.mode, type_comments=args.no_type_comments)
    print(dump(tree, include_attributes=args.include_attributes, indent=args.indent))

if __name__ == '__main__':
    main()
