"""Upload Python scripts and wheels to Databricks."""

from __future__ import annotations

import subprocess
from pathlib import Path

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import DatabricksError, ResourceAlreadyExists
from databricks.sdk.service.workspace import ImportFormat

from databricks_job_runner.errors import RunnerError


def _ensure_volumes_prefix(path: str) -> str:
    """Prepend ``/Volumes`` if the path doesn't already start with it."""
    return path if path.startswith("/Volumes") else f"/Volumes{path}"


def upload_file(ws: WorkspaceClient, local_path: Path, remote_path: str) -> None:
    """Upload a single file to the Databricks workspace.

    Handles FILE-vs-NOTEBOOK type mismatches by deleting the existing
    object and re-uploading, since the workspace API cannot overwrite
    across object types.
    """
    print(f"Uploading: {local_path.name} -> {remote_path}")
    content = local_path.read_bytes()
    try:
        ws.workspace.upload(
            path=remote_path,
            content=content,
            format=ImportFormat.AUTO,
            overwrite=True,
        )
    except DatabricksError as exc:
        if "type mismatch" in str(exc).lower():
            ws.workspace.delete(path=remote_path)
            ws.workspace.upload(
                path=remote_path,
                content=content,
                format=ImportFormat.AUTO,
                overwrite=True,
            )
        else:
            raise
    print("  Done.")


def ensure_remote_dirs(ws: WorkspaceClient, workspace_dir: str) -> None:
    """Create the workspace and agent_modules directories if needed."""
    ws.workspace.mkdirs(workspace_dir)
    ws.workspace.mkdirs(f"{workspace_dir}/agent_modules")


def upload_agent_modules(
    ws: WorkspaceClient,
    agent_modules_dir: Path,
    workspace_dir: str,
) -> None:
    """Upload all .py files from the agent_modules directory."""
    ensure_remote_dirs(ws, workspace_dir)
    remote_dir = f"{workspace_dir}/agent_modules"
    for f in sorted(agent_modules_dir.glob("*.py")):
        upload_file(ws, f, f"{remote_dir}/{f.name}")


def find_latest_wheel(dist_dir: Path, wheel_package: str) -> Path | None:
    """Return the most recently built wheel for *wheel_package* in *dist_dir*.

    Uses PEP 625 name normalisation (hyphens become underscores) and sorts
    by mtime descending so the newest build wins.
    """
    glob_name = wheel_package.replace("-", "_")
    wheels = sorted(
        dist_dir.glob(f"{glob_name}-*.whl"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return wheels[0] if wheels else None


def build_and_upload_wheel(
    ws: WorkspaceClient,
    project_dir: Path,
    wheel_volume_dir: str,
    wheel_package: str,
) -> None:
    """Build a Python wheel with ``uv build`` and upload it to a UC Volume."""
    if not wheel_volume_dir:
        raise RunnerError(
            "volume path not set in .env — cannot determine wheel upload path."
        )

    dist_dir = project_dir / "dist"

    print(f"Building {wheel_package} wheel...")
    # ``--out-dir dist`` forces output into project_dir/dist even when the
    # project is a uv workspace member (where the default is the workspace
    # root's dist/).  Matches what find_latest_wheel() looks for below.
    subprocess.run(
        ["uv", "build", "--wheel", "--quiet", "--out-dir", "dist"],
        cwd=project_dir,
        check=True,
    )

    whl = find_latest_wheel(dist_dir, wheel_package)
    if whl is None:
        glob_name = wheel_package.replace("-", "_")
        raise RunnerError(f"wheel build failed — no {glob_name}-*.whl found in dist/")

    # Ensure the path starts with /Volumes for the Files API
    volume_path = _ensure_volumes_prefix(wheel_volume_dir)
    dest = f"{volume_path}/{whl.name}"

    print(f"Uploading: {whl.name} -> {dest}")
    try:
        ws.files.create_directory(volume_path)
    except ResourceAlreadyExists:
        pass

    with whl.open("rb") as fh:
        ws.files.upload(file_path=dest, contents=fh, overwrite=True)
    print("  Done.")


def upload_data_to_volume(
    ws: WorkspaceClient,
    local_dir: Path,
    volume_path: str,
) -> None:
    """Upload a local directory tree to a UC Volume, preserving structure.

    Walks *local_dir* recursively and uploads every file to
    ``{volume_path}/{relative_path}``.  Creates subdirectories as needed
    via the Files API.
    """
    volume_path = _ensure_volumes_prefix(volume_path)

    # Collect all files and the set of directories to create
    dirs_created: set[str] = set()

    for local_file in sorted(local_dir.rglob("*")):
        if not local_file.is_file():
            continue

        rel = local_file.relative_to(local_dir)
        remote_file = f"{volume_path}/{rel}"

        # Ensure parent directory exists
        remote_parent = (
            f"{volume_path}/{rel.parent}" if str(rel.parent) != "." else volume_path
        )
        if remote_parent not in dirs_created:
            try:
                ws.files.create_directory(remote_parent)
            except ResourceAlreadyExists:
                pass
            dirs_created.add(remote_parent)

        print(f"  {rel} -> {remote_file}")
        with local_file.open("rb") as fh:
            ws.files.upload(file_path=remote_file, contents=fh, overwrite=True)
