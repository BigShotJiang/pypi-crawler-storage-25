"""Parameter injection for scripts submitted via Runner.

When Runner.submit() sends a script to a Databricks cluster, it passes
all .env extras as ``KEY=VALUE`` positional parameters.  Scripts call
:func:`inject_params` at startup to parse those into ``os.environ``
before constructing a pydantic ``BaseSettings`` instance.

Usage in a submitted script::

    from databricks_job_runner import inject_params
    inject_params()

    from my_module import Settings
    settings = Settings()  # reads from os.environ
"""

from __future__ import annotations

import os
import sys


def inject_params() -> None:
    """Parse ``KEY=VALUE`` parameters from ``sys.argv`` into ``os.environ``.

    Strips consumed arguments from ``sys.argv`` so they don't interfere
    with any downstream argument parsing.  Uses ``setdefault`` so that
    pre-existing environment variables take precedence (matching standard
    12-factor semantics).

    After loading parameters, checks for ``DATABRICKS_SECRET_SCOPE`` and
    ``DATABRICKS_SECRET_KEYS``.  If both are set, fetches the listed keys
    from the Databricks secret scope and injects them into ``os.environ``.
    """
    remaining: list[str] = []
    for arg in sys.argv[1:]:
        if "=" in arg and not arg.startswith("-"):
            key, _, value = arg.partition("=")
            os.environ.setdefault(key, value)
        else:
            remaining.append(arg)
    sys.argv[1:] = remaining
    _load_secrets()


def _load_secrets() -> None:
    """Fetch secrets from a Databricks secret scope into ``os.environ``.

    Reads ``DATABRICKS_SECRET_SCOPE`` and ``DATABRICKS_SECRET_KEYS``
    from the environment.  For each listed key, fetches the value via
    ``WorkspaceClient().dbutils.secrets.get()`` and injects it with
    ``setdefault`` (pre-existing env vars still win).

    Warns and continues on per-key failures so that downstream config
    validation can report clearer "missing variable" errors.
    """
    scope = os.environ.get("DATABRICKS_SECRET_SCOPE")
    raw_keys = os.environ.get("DATABRICKS_SECRET_KEYS")
    if not scope or not raw_keys:
        return
    keys = [k.strip() for k in raw_keys.split(",") if k.strip()]
    if not keys:
        return

    from databricks.sdk import WorkspaceClient

    ws = WorkspaceClient()
    for key in keys:
        try:
            value = ws.dbutils.secrets.get(scope=scope, key=key)
            os.environ.setdefault(key, value)
        except Exception as exc:
            print(
                f"WARNING: failed to load secret '{key}' "
                f"from scope '{scope}': {exc}"
            )
