"""Submit Python scripts as one-time Databricks job runs."""

from __future__ import annotations

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import (
    RunResultState,
    SparkPythonTask,
    SubmitTask,
)

from databricks_job_runner.compute import Compute
from databricks_job_runner.errors import RunnerError


def submit_job(
    ws: WorkspaceClient,
    *,
    compute: Compute,
    workspace_dir: str,
    script_name: str,
    run_name: str,
    params: list[str] | None = None,
    wheel_path: str | None = None,
    no_wait: bool = False,
) -> int:
    """Submit a script as a one-shot Databricks job and optionally wait.

    *compute* is the backend strategy (classic cluster or serverless).  It
    validates its own readiness, decorates the :class:`SubmitTask` with
    the right fields, and provides the top-level ``environments`` list
    (``None`` on classic, a single-entry list on serverless).

    *wheel_path* is either a UC Volume path to a ``.whl`` (passed through
    as a ``Library`` on classic, or as an ``Environment.dependencies``
    entry on serverless) or ``None`` when the submitted script has no
    wheel dependency.

    Returns the run ID.
    """
    compute.validate(ws)

    remote_path = f"{workspace_dir}/agent_modules/{script_name}"

    print("Submitting job")
    print(f"  Script:   {remote_path}")
    print(f"  Run name: {run_name}")
    print("---")

    task = SubmitTask(
        task_key="run_script",
        spark_python_task=SparkPythonTask(
            python_file=remote_path,
            parameters=params if params else None,
        ),
    )
    task = compute.decorate_task(task, wheel_path)

    waiter = ws.jobs.submit(
        run_name=run_name,
        tasks=[task],
        environments=compute.environments(wheel_path),
    )

    run_id: int | None = waiter.run_id
    if run_id is None:
        raise RunnerError("Databricks did not return a run_id for the submitted job.")
    print(f"  Run ID:   {run_id}")

    if no_wait:
        print("\nJob submitted (--no-wait). Check status in the Databricks UI.")
        return run_id

    print("  Waiting for completion...")
    run = waiter.result()
    result_state = run.state.result_state if run.state else None
    state_name = result_state.value if result_state else "UNKNOWN"
    page_url = run.run_page_url or ""

    print(f"\n  Result:   {state_name}")
    if page_url:
        print(f"  URL:      {page_url}")

    if result_state != RunResultState.SUCCESS:
        raise RunnerError(f"Job finished with non-success state: {state_name}")

    print("\nJob complete.")
    return run_id
