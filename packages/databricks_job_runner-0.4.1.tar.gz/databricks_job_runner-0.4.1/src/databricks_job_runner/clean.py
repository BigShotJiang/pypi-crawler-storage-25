"""Clean up remote workspace directories and job runs."""

from __future__ import annotations

from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound
from databricks.sdk.service.jobs import RunType


def clean_workspace(ws: WorkspaceClient, workspace_dir: str) -> None:
    """Delete the remote workspace directory recursively."""
    print(f"Deleting remote workspace: {workspace_dir}")
    try:
        ws.workspace.delete(path=workspace_dir, recursive=True)
        print("  Done.")
    except NotFound:
        print("  Directory does not exist or already deleted.")


def clean_runs(ws: WorkspaceClient, run_name_prefix: str) -> None:
    """Find and delete all one-time job runs whose name starts with *prefix*."""
    print(f"Finding job runs matching '{run_name_prefix}*'...")

    deleted = 0
    for run in ws.jobs.list_runs(run_type=RunType.SUBMIT_RUN, expand_tasks=False):
        run_name = run.run_name or ""
        run_id = run.run_id
        if run_id is None or not run_name.startswith(run_name_prefix):
            continue
        print(f"  Deleting run {run_id} ({run_name})")
        try:
            ws.jobs.delete_run(run_id)
            deleted += 1
        except NotFound:
            print(f"    Run {run_id} already deleted.")

    if deleted:
        print(f"  Deleted {deleted} run(s).")
    else:
        print("  No matching runs found.")
