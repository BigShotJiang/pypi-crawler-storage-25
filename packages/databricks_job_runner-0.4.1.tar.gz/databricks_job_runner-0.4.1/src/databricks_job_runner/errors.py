"""Exceptions raised by databricks-job-runner."""

from __future__ import annotations


class RunnerError(Exception):
    """Raised when a runner operation cannot proceed.

    Indicates a user-fixable problem: missing configuration, a file not
    found, a stopped cluster, a failed job, etc.  The CLI layer catches
    these and formats them as friendly messages before exiting; library
    callers can catch them and handle as they see fit.
    """
