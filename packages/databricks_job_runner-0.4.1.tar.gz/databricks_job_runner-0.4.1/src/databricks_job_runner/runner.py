"""Runner: orchestration for upload, submit, validate, logs, and clean operations.

Each project creates a :class:`Runner` instance with its config, then
calls :meth:`Runner.main` to dispatch CLI subcommands.  The Runner's
orchestration methods (``upload_file``, ``submit``, ``validate``,
``logs``, ``clean``, etc.) are also callable directly as a library API.

All non-core ``.env`` keys are automatically passed to submitted jobs as
``KEY=VALUE`` parameters.  Scripts call :func:`inject_params` at startup
to load them into ``os.environ``, then use pydantic ``BaseSettings`` to
read configuration.

Example usage in a consuming project::

    # cli/__init__.py
    from databricks_job_runner import Runner

    runner = Runner(
        run_name_prefix="graph_validation",
        wheel_package="augmentation_agent",  # optional
    )

    # cli/__main__.py
    from . import runner
    runner.main()

Then invoke as::

    python -m cli upload --all
    python -m cli submit test_hello.py
    python -m cli clean --yes
"""

from __future__ import annotations

from pathlib import Path

from databricks.sdk import WorkspaceClient

from databricks_job_runner import catalog
from databricks_job_runner.clean import clean_runs, clean_workspace
from databricks_job_runner.compute import ClassicCluster, Compute, Serverless
from databricks_job_runner.config import RunnerConfig, make_client
from databricks_job_runner.download import download_file, list_volume_files
from databricks_job_runner.errors import RunnerError
from databricks_job_runner.logs import find_latest_run, get_run_logs
from databricks_job_runner.submit import submit_job
from databricks_job_runner.upload import (
    build_and_upload_wheel,
    ensure_remote_dirs,
    find_latest_wheel,
    upload_agent_modules,
    upload_data_to_volume,
    upload_file,
)
from databricks_job_runner.validate import check_file_exists, list_workspace


class Runner:
    """Reusable Databricks job runner configured per-project.

    All non-core ``.env`` keys are automatically passed to submitted jobs
    as ``KEY=VALUE`` parameters.  No callback needed.

    Args:
        run_name_prefix: Prefix for job run names (e.g. ``"graph_validation"``).
            Also used to filter runs during cleanup (matches ``"prefix:"``).
        project_dir: Root directory of the consuming project (where ``.env``
            and ``agent_modules/`` live).  Defaults to the caller's working
            directory.
        wheel_package: Optional package name for wheel building (e.g.
            ``"augmentation_agent"``).  Enables the ``upload --wheel``
            subcommand.  Wheels are uploaded to ``<DATABRICKS_VOLUME_PATH>/wheels/``.
        secret_keys: Optional list of ``.env`` key names whose values should
            be stored in a Databricks secret scope instead of being passed as
            plaintext job parameters.  Requires ``DATABRICKS_SECRET_SCOPE``
            in ``.env``.  At runtime, :func:`inject_params` fetches them
            from the scope into ``os.environ``.
    """

    DEFAULT_DATA_DIR = "data"

    def __init__(
        self,
        run_name_prefix: str,
        project_dir: Path | str | None = None,
        wheel_package: str | None = None,
        secret_keys: list[str] | None = None,
    ) -> None:
        self.run_name_prefix = run_name_prefix
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.wheel_package = wheel_package
        self.secret_keys = secret_keys

        # Lazy-initialized
        self._config: RunnerConfig | None = None
        self._ws: WorkspaceClient | None = None

    # -- Properties (lazy) ---------------------------------------------------

    @property
    def config(self) -> RunnerConfig:
        """Parsed ``.env`` values as a typed :class:`RunnerConfig`."""
        if self._config is None:
            self._config = RunnerConfig.from_env_file(self.project_dir / ".env")
        return self._config

    @property
    def ws(self) -> WorkspaceClient:
        """Databricks workspace client.  Created once on first access.

        Uses ``DATABRICKS_PROFILE`` when set; otherwise falls back to the
        SDK's unified auth (env vars, Azure CLI, etc.).
        """
        if self._ws is None:
            self._ws = make_client(self.config.databricks_profile)
        return self._ws

    @property
    def agent_modules_dir(self) -> Path:
        return self.project_dir / "agent_modules"

    @property
    def wheel_volume_dir(self) -> str:
        vol = self.config.databricks_volume_path
        return f"{vol}/wheels" if vol else ""

    # -- Public helpers ------------------------------------------------------

    def find_wheel(self) -> str | None:
        """Find the latest built wheel in ``dist/``.  Returns the filename."""
        if not self.wheel_package:
            return None
        whl = find_latest_wheel(self.project_dir / "dist", self.wheel_package)
        return whl.name if whl else None

    def _compute(self, mode_override: str | None = None) -> Compute:
        """Build the :class:`Compute` strategy from config.

        Args:
            mode_override: When set (``"cluster"`` or ``"serverless"``),
                overrides ``DATABRICKS_COMPUTE_MODE`` from ``.env``.
        """
        mode = mode_override or self.config.databricks_compute_mode
        if mode == "serverless":
            return Serverless(
                environment_version=self.config.databricks_serverless_env_version,
            )
        if not self.config.databricks_cluster_id:
            raise RunnerError(
                "DATABRICKS_CLUSTER_ID must be set in .env to use cluster compute."
            )
        return ClassicCluster(cluster_id=self.config.databricks_cluster_id)

    # -- Orchestration methods ----------------------------------------------

    def upload_file(self, filename: str) -> None:
        """Upload a single file from ``agent_modules/`` to the workspace."""
        local_path = self.agent_modules_dir / filename
        if not local_path.exists():
            raise RunnerError(f"{local_path} not found")
        workspace_dir = self.config.databricks_workspace_dir
        ensure_remote_dirs(self.ws, workspace_dir)
        print(f"Uploading to {workspace_dir}/agent_modules")
        print("---")
        upload_file(
            self.ws,
            local_path,
            f"{workspace_dir}/agent_modules/{local_path.name}",
        )
        print()
        print("Upload complete.")

    def upload_all(self) -> None:
        """Upload all ``agent_modules/*.py`` files to the workspace."""
        workspace_dir = self.config.databricks_workspace_dir
        print(f"Uploading all agent_modules/ to {workspace_dir}/agent_modules")
        print("---")
        upload_agent_modules(self.ws, self.agent_modules_dir, workspace_dir)
        print()
        print("Upload complete.")

    def upload_wheel(self) -> None:
        """Build a wheel with ``uv build`` and upload to the UC Volume."""
        if not self.wheel_package:
            raise RunnerError("wheel_package not configured for this runner.")
        print(f"Building and uploading wheel to {self.wheel_volume_dir}")
        print("---")
        build_and_upload_wheel(
            self.ws, self.project_dir, self.wheel_volume_dir, self.wheel_package
        )
        print()
        print("Upload complete.")

    def upload_data(self, source_dir: str = DEFAULT_DATA_DIR) -> None:
        """Upload a local data directory to the UC Volume.

        Uploads ``{project_dir}/{source_dir}/`` to
        ``{DATABRICKS_VOLUME_PATH}/``, preserving the subdirectory
        structure.
        """
        vol = self.config.databricks_volume_path
        if not vol:
            raise RunnerError(
                "volume path not set in .env — cannot determine upload path."
            )

        local_dir = self.project_dir / source_dir
        if not local_dir.is_dir():
            raise RunnerError(f"{local_dir} not found or is not a directory.")

        print(f"Uploading {source_dir}/ to {vol}")
        print("---")
        upload_data_to_volume(self.ws, local_dir, vol)
        print()
        print("Upload complete.")

    def download(self, remote_path: str, dest: str | None = None) -> None:
        """Download a file from the UC Volume to a local path.

        *remote_path* is relative to ``DATABRICKS_VOLUME_PATH`` unless it
        starts with ``/Volumes``.  When *dest* is ``None`` the file is
        saved to the current directory using the remote filename.
        """
        if not remote_path.startswith("/Volumes"):
            vol = self.config.databricks_volume_path
            if not vol:
                raise RunnerError(
                    "volume path not set in .env — cannot resolve relative path.\n"
                    "Use an absolute path starting with /Volumes or set "
                    "DATABRICKS_VOLUME_PATH in .env."
                )
            remote_path = f"{vol}/{remote_path}"

        filename = remote_path.rsplit("/", 1)[-1]
        local = Path(dest) if dest else Path.cwd() / filename

        print(f"Downloading from volume")
        print("---")
        download_file(self.ws, remote_path, local)
        print()
        print("Download complete.")

    def list_volume(self, subdir: str | None = None) -> None:
        """List files at the configured volume path (or a subdirectory)."""
        vol = self.config.databricks_volume_path
        if not vol:
            raise RunnerError(
                "volume path not set in .env — cannot list volume contents."
            )
        path = f"{vol}/{subdir}" if subdir else vol

        print(f"Listing: {path}")
        print("---")
        files = list_volume_files(self.ws, path)
        if not files:
            print("  (empty)")
        for f in files:
            print(f"  {f}")
        print()

    def submit(
        self, script: str, *, no_wait: bool = False, compute_mode: str | None = None,
    ) -> None:
        """Submit a script as a one-time Databricks job.

        Builds the compute strategy from ``DATABRICKS_COMPUTE_MODE`` (or
        the *compute_mode* override) and delegates readiness checks to it
        (classic starts the cluster if terminated; serverless is a no-op).
        When a built wheel exists in ``dist/``, it is attached
        automatically — as a :class:`Library` on classic, or as an
        ``Environment.dependencies`` entry on serverless.

        Args:
            script: Script name in ``agent_modules/``.
            no_wait: Submit without waiting for completion.
            compute_mode: Override the project-level compute mode
                (``"cluster"`` or ``"serverless"``).  When ``None``,
                uses ``DATABRICKS_COMPUTE_MODE`` from ``.env``.
        """
        params = self.config.env_params(secret_keys=self.secret_keys)
        run_name = f"{self.run_name_prefix}: {script}"

        if params:
            print(f"  Params:   {len(params)} env values from .env")

        # Attach the wheel when one is available
        wheel_path: str | None = None
        if self.wheel_package:
            whl_name = self.find_wheel()
            if whl_name:
                wheel_path = f"{self.wheel_volume_dir}/{whl_name}"
                print(f"  Wheel:    {wheel_path}")

        compute = self._compute(compute_mode)
        run_id = submit_job(
            self.ws,
            compute=compute,
            workspace_dir=self.config.databricks_workspace_dir,
            script_name=script,
            run_name=run_name,
            params=params,
            wheel_path=wheel_path,
            no_wait=no_wait,
        )

        print()
        print("Next steps:")
        print(f"  View logs:          uv run python -m cli logs {run_id}")
        if self.config.databricks_volume_path:
            print(f"  List results:       uv run python -m cli download --list results")
            print(f"  Download results:   uv run python -m cli download results/<filename>")

    def logs(self, run_id: int | None = None) -> None:
        """Print stdout/stderr and error trace for a submitted run.

        When *run_id* is ``None``, finds the most recent SUBMIT_RUN whose
        name starts with ``{run_name_prefix}:`` (matches the same filter
        used by ``clean --runs``).  Output comes from the Jobs API's
        ``get_run_output`` endpoint, which returns the tail 5 MB of
        stdout/stderr captured by Databricks.
        """
        if run_id is None:
            prefix = f"{self.run_name_prefix}:"
            print(f"Finding latest run matching '{prefix}*'...")
            run_id = find_latest_run(self.ws, prefix)
            print(f"  Found run {run_id}")
            print()
        get_run_logs(self.ws, run_id)

    def validate(self, file: str | None = None) -> None:
        """Check compute readiness, list remote workspace, verify a file.

        Runs the compute strategy's ``validate`` — on classic that
        auto-starts the cluster if it is not already RUNNING; on
        serverless it is a no-op.  If *file* is given, verifies it exists
        under ``agent_modules/`` and raises :class:`RunnerError` otherwise.
        """
        self._compute().validate(self.ws)
        print()
        list_workspace(self.ws, self.config.databricks_workspace_dir)
        if file:
            check_file_exists(self.ws, self.config.databricks_workspace_dir, file)
        print()
        print("Validation complete.")

    def clean(
        self,
        *,
        workspace: bool = True,
        runs: bool = True,
        confirm: bool = True,
    ) -> None:
        """Delete the remote workspace directory and/or matching job runs."""
        print(f"{self.run_name_prefix}: cleanup")
        print("---")
        if workspace:
            print(
                f"  Workspace:  {self.config.databricks_workspace_dir} "
                f"(will be deleted recursively)"
            )
        if runs:
            print(
                f"  Job runs:   all one-time runs matching '{self.run_name_prefix}:*'"
            )
        print()

        if confirm:
            answer = input("Proceed? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
            print()

        if workspace:
            clean_workspace(self.ws, self.config.databricks_workspace_dir)
            print()
        if runs:
            clean_runs(self.ws, f"{self.run_name_prefix}:")
            print()

        print("Cleanup complete.")

    # -- Catalog management --------------------------------------------------

    def catalog_list(self) -> None:
        """List all catalogs."""
        catalog.list_catalogs(self.ws)

    def catalog_get(self, name: str) -> None:
        """Show details for a catalog."""
        catalog.get_catalog(self.ws, name)

    def catalog_create(
        self,
        name: str,
        *,
        storage_root: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Create a catalog."""
        catalog.create_catalog(
            self.ws, name, storage_root=storage_root, comment=comment
        )

    def catalog_delete(
        self,
        name: str,
        *,
        force: bool = False,
        confirm: bool = True,
    ) -> None:
        """Delete a catalog.  *force* cascades to all contents."""
        if confirm:
            msg = f"Delete catalog '{name}'"
            if force:
                msg += " and ALL contents (schemas, tables, volumes)"
            answer = input(f"{msg}? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
        catalog.delete_catalog(self.ws, name, force=force)

    # -- Schema management ---------------------------------------------------

    def schema_list(self, catalog_name: str) -> None:
        """List schemas in a catalog."""
        catalog.list_schemas(self.ws, catalog_name)

    def schema_get(self, full_name: str) -> None:
        """Show details for a schema (``catalog.schema``)."""
        catalog.get_schema(self.ws, full_name)

    def schema_create(self, full_name: str, *, comment: str | None = None) -> None:
        """Create a schema (``catalog.schema``)."""
        catalog.create_schema(self.ws, full_name, comment=comment)

    def schema_delete(self, full_name: str, *, confirm: bool = True) -> None:
        """Delete a schema (``catalog.schema``)."""
        if confirm:
            answer = input(f"Delete schema '{full_name}'? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
        catalog.delete_schema(self.ws, full_name)

    # -- Volume management ---------------------------------------------------

    def volume_list(self, parent: str) -> None:
        """List volumes in a schema (``catalog.schema``)."""
        catalog.list_volumes(self.ws, parent)

    def volume_get(self, full_name: str) -> None:
        """Show details for a volume (``catalog.schema.volume``)."""
        catalog.get_volume(self.ws, full_name)

    def volume_create(
        self,
        full_name: str,
        *,
        volume_type: str = "MANAGED",
        storage_location: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Create a volume (``catalog.schema.volume``)."""
        catalog.create_volume(
            self.ws,
            full_name,
            volume_type=volume_type,
            storage_location=storage_location,
            comment=comment,
        )

    def volume_delete(self, full_name: str, *, confirm: bool = True) -> None:
        """Delete a volume (``catalog.schema.volume``)."""
        if confirm:
            answer = input(f"Delete volume '{full_name}'? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return
        catalog.delete_volume(self.ws, full_name)

    # -- Main CLI entry point ------------------------------------------------

    def main(self, argv: list[str] | None = None) -> None:
        """Parse args and dispatch to the appropriate orchestration method."""
        from databricks_job_runner.cli import run_cli

        run_cli(self, argv)
