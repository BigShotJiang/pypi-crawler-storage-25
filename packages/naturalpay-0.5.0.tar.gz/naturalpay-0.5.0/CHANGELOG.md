# Changelog

## 0.5.0 (2026-05-20)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/naturalpay/naturalpay-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([f7c02d4](https://github.com/naturalpay/naturalpay-python/commit/f7c02d458295442cfe1d1fb0edbc558824241386))
* **api:** api update ([91c9727](https://github.com/naturalpay/naturalpay-python/commit/91c9727beb4d21fab7e0fa4c904b543bf9194fee))

## 0.4.0 (2026-05-20)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/naturalpay/naturalpay-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([27379fe](https://github.com/naturalpay/naturalpay-python/commit/27379fe1297a0744b6a908210f9f44cfa87b0922))
* **api:** api update ([826755f](https://github.com/naturalpay/naturalpay-python/commit/826755fb2824024afb1609897b0b4fe23b754fe6))
* **api:** api update ([e9241ca](https://github.com/naturalpay/naturalpay-python/commit/e9241ca6cc579f86fdf80d90333920820d00d836))
* **api:** api update ([7456164](https://github.com/naturalpay/naturalpay-python/commit/745616415c62592c563708c796ba901c6f0aae34))
* **api:** api update ([49342f8](https://github.com/naturalpay/naturalpay-python/commit/49342f82d0a61da824a853e1b615257510367038))
* **api:** api update ([7f3e7cd](https://github.com/naturalpay/naturalpay-python/commit/7f3e7cdf101380622327b4e7eeb19e8892849d8f))

## 0.3.0 (2026-05-19)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/naturalpay/naturalpay-python/compare/v0.2.1...v0.3.0)

### Features

* **api:** api update ([b15bff5](https://github.com/naturalpay/naturalpay-python/commit/b15bff56ccbdbd8e1ecff8f1a7e5fa4ce4032258))
* **api:** api update ([5b2f9bf](https://github.com/naturalpay/naturalpay-python/commit/5b2f9bf1406d7aaadd17fc9be2f33721a2499c67))
* **api:** api update ([3022e6e](https://github.com/naturalpay/naturalpay-python/commit/3022e6ebd2753a0d29607eec6f1d33b3abf95c23))
* **api:** api update ([5da0778](https://github.com/naturalpay/naturalpay-python/commit/5da0778600d94d0f411752a1b1311135bb2f1a58))
* **api:** api update ([6a85a10](https://github.com/naturalpay/naturalpay-python/commit/6a85a101aad0c812afc08a954639198ff2a92549))
* **api:** api update ([6fbf4c9](https://github.com/naturalpay/naturalpay-python/commit/6fbf4c9acfdd47ed6ea2a2123ebf44c4505b0490))
* **api:** api update ([8283476](https://github.com/naturalpay/naturalpay-python/commit/8283476c2416c72c40b3325039e115cbb8ded279))
* **api:** api update ([9dd37fc](https://github.com/naturalpay/naturalpay-python/commit/9dd37fccc74b6a72340e6b13992aa704b31d1027))
* **api:** api update ([ef8837d](https://github.com/naturalpay/naturalpay-python/commit/ef8837dd239948da26cedaef8b3b28893cf2bb2c))
* **api:** api update ([d271006](https://github.com/naturalpay/naturalpay-python/commit/d2710066cb97bb7ea218ca9a77456690e2849cca))
* **api:** api update ([abe8106](https://github.com/naturalpay/naturalpay-python/commit/abe810647fc876694268c4e0ea0c25ab5e746613))
* **api:** api update ([7e663f8](https://github.com/naturalpay/naturalpay-python/commit/7e663f8a7466ed08a6b2cafffccb1f97a16a2384))

## 0.2.1 (2026-05-16)

Full Changelog: [v0.0.1...v0.2.1](https://github.com/naturalpay/naturalpay-python/compare/v0.0.1...v0.2.1)

### ⚠ BREAKING CHANGES

* **sdk:** align implemented endpoints with public OpenAPI ([#47](https://github.com/naturalpay/naturalpay-python/issues/47))

### Features

* add context param and fill instance_id gaps across all methods ([#14](https://github.com/naturalpay/naturalpay-python/issues/14)) ([2fb6d30](https://github.com/naturalpay/naturalpay-python/commit/2fb6d30e7bf6e323f396370935d9dfff46eb3437))
* add instance_id for agent observability ([#13](https://github.com/naturalpay/naturalpay-python/issues/13)) ([984084b](https://github.com/naturalpay/naturalpay-python/commit/984084ba0b7940f94d0d9a31bf6c9dd83b0143b7))
* add ModelContext and ModelUsage for observability ([#27](https://github.com/naturalpay/naturalpay-python/issues/27)) ([e0ee5b8](https://github.com/naturalpay/naturalpay-python/commit/e0ee5b87cc75aed56ac9651e847c3c129c2dca67))
* add observability tracking for agent instances and tool calls ([a5aed77](https://github.com/naturalpay/naturalpay-python/commit/a5aed772e1c9fae954a9d6620969279fee43b26d))
* add trace_id parameter for distributed tracing ([#35](https://github.com/naturalpay/naturalpay-python/issues/35)) ([6cb4d69](https://github.com/naturalpay/naturalpay-python/commit/6cb4d69d9154093eabf5dbbc7b67133afe1b4d8a))
* add type filter to transactions, remove wallet.transfers() ([a3f8a65](https://github.com/naturalpay/naturalpay-python/commit/a3f8a6501b2134f3029582caa161b7ca0f6df4c8))
* align SDK endpoints with public API ([#16](https://github.com/naturalpay/naturalpay-python/issues/16)) ([cf9fdbd](https://github.com/naturalpay/naturalpay-python/commit/cf9fdbd67136e6acf30e983ef2e018493dd25037))
* **api:** api update ([b6d771e](https://github.com/naturalpay/naturalpay-python/commit/b6d771ed93c35f0e7430b41acb12697278b2e5a1))
* **api:** api update ([616630c](https://github.com/naturalpay/naturalpay-python/commit/616630c42dc761272b377305e30e701cf9414f39))
* **api:** api update ([9879968](https://github.com/naturalpay/naturalpay-python/commit/9879968ebe70f3a3348b1a0481cf476ff391e20f))
* **api:** api update ([8f925db](https://github.com/naturalpay/naturalpay-python/commit/8f925db1bdcea101b6de46920b47f8ded3198510))
* **api:** api update ([2ac51ec](https://github.com/naturalpay/naturalpay-python/commit/2ac51ecb48166ac795a10c6bad8458e85cb6b4bc))
* **api:** api update ([885e12e](https://github.com/naturalpay/naturalpay-python/commit/885e12e446e66e5a9cb411631c39a77a25ba9bff))
* **api:** api update ([d1f7a42](https://github.com/naturalpay/naturalpay-python/commit/d1f7a420c43cbac6e3566dab07e1d0d8a1e11c2f))
* **api:** api update ([00a1aa8](https://github.com/naturalpay/naturalpay-python/commit/00a1aa83a4ff68db3a84c60043adaf600f3e34cd))
* **api:** api update ([6c84869](https://github.com/naturalpay/naturalpay-python/commit/6c8486940033e282c9cf6fb1101ddef2674fbce5))
* **api:** api update ([036ad9a](https://github.com/naturalpay/naturalpay-python/commit/036ad9ab02a434c84e80049a52af48d7007bde25))
* **api:** api update ([373d476](https://github.com/naturalpay/naturalpay-python/commit/373d4769fef63c9b23d0a6fd9639556319a93358))
* **api:** api update ([5a0aec1](https://github.com/naturalpay/naturalpay-python/commit/5a0aec1ffad12625666b14dc477d174f529507f0))
* **api:** api update ([d9b252a](https://github.com/naturalpay/naturalpay-python/commit/d9b252a4fe3179ce9ab695a85ed656fdf482a588))
* **api:** api update ([22446b6](https://github.com/naturalpay/naturalpay-python/commit/22446b62325d725f956e4c220fb0aa29c3909915))
* **api:** api update ([f1e6be1](https://github.com/naturalpay/naturalpay-python/commit/f1e6be187e05d54f6f3e481242b98c45e4aab9d6))
* **api:** api update ([10397ab](https://github.com/naturalpay/naturalpay-python/commit/10397abc0b29e7cdf174c69ee11658aa44150281))
* **api:** api update ([e3f04a0](https://github.com/naturalpay/naturalpay-python/commit/e3f04a0136ed93f98ae7f01bd14fe761c3a1ab47))
* **api:** api update ([fe326c6](https://github.com/naturalpay/naturalpay-python/commit/fe326c6f8fdb4492af37e170dbed1bf62219def8))
* **api:** api update ([aa5ef1d](https://github.com/naturalpay/naturalpay-python/commit/aa5ef1df17e21b3864425b6a0a3e3439cbb346ba))
* **api:** api update ([6887759](https://github.com/naturalpay/naturalpay-python/commit/688775913bf3f29f07bae7f10e011fc676ed3829))
* **api:** api update ([89a0179](https://github.com/naturalpay/naturalpay-python/commit/89a017985c456ed187ed4a65d0a352fb43ad6207))
* **api:** api update ([7fe0693](https://github.com/naturalpay/naturalpay-python/commit/7fe06933736493c687c325afcdf7b5fe3641ebe5))
* **api:** Require Instance ID ([#31](https://github.com/naturalpay/naturalpay-python/issues/31)) ([cb039e6](https://github.com/naturalpay/naturalpay-python/commit/cb039e663fbd729298ae7d1966c7d508ccc3013f))
* **envelope:** replace per-operation list with generic plain-object wrap ([#59](https://github.com/naturalpay/naturalpay-python/issues/59)) ([1c87f9c](https://github.com/naturalpay/naturalpay-python/commit/1c87f9caf90aab8181c7eaa8963a298be5f950e2))
* improve create_payment MCP tool ([#5](https://github.com/naturalpay/naturalpay-python/issues/5)) ([ce8f966](https://github.com/naturalpay/naturalpay-python/commit/ce8f9660cd112e81965f01b6d2c0d8fd20fcf6d7))
* make customer_party_id optional in payments SDK ([#38](https://github.com/naturalpay/naturalpay-python/issues/38)) ([1b6344c](https://github.com/naturalpay/naturalpay-python/commit/1b6344c50d10faf195de220115ed9580b1e24668))
* **mcp:** Move to Proxy ([#29](https://github.com/naturalpay/naturalpay-python/issues/29)) ([71bdfe1](https://github.com/naturalpay/naturalpay-python/commit/71bdfe10b9405af5a0e5011bb1a8b7c2b065dce0))
* payments.create() returns Transaction, remove Payment model ([#21](https://github.com/naturalpay/naturalpay-python/issues/21)) ([6e9670b](https://github.com/naturalpay/naturalpay-python/commit/6e9670b3746c79e154df4fa44a56968278961a4e))
* per-agent invitation SDK (0.2.0) ([#45](https://github.com/naturalpay/naturalpay-python/issues/45)) ([cb396d0](https://github.com/naturalpay/naturalpay-python/commit/cb396d0b53d688d3ea4abf5c4aa1aef1c9d38a67))
* rename counterparties to customers in Python SDK ([#20](https://github.com/naturalpay/naturalpay-python/issues/20)) ([014518c](https://github.com/naturalpay/naturalpay-python/commit/014518c68f7b006744a20bd35f5f6cedfafaa409))
* **sdk:** Achieve SDK Parity ([#33](https://github.com/naturalpay/naturalpay-python/issues/33)) ([dd508a7](https://github.com/naturalpay/naturalpay-python/commit/dd508a76d009902e0e1f2fbf48d5f9f6eac276cc))
* **sdk:** Query Txn by Party ([#32](https://github.com/naturalpay/naturalpay-python/issues/32)) ([56f553c](https://github.com/naturalpay/naturalpay-python/commit/56f553c273745c12e02fee728e3389303706ad5b))
* **sdk:** typed tool-call context with tc_ id parity with TS SDK ([#40](https://github.com/naturalpay/naturalpay-python/issues/40)) ([4c0f21b](https://github.com/naturalpay/naturalpay-python/commit/4c0f21beb01189117b172ffa5ea4564ca853fcef))
* **sdk:** Webhook Signatures and Add Retries ([#36](https://github.com/naturalpay/naturalpay-python/issues/36)) ([f183e24](https://github.com/naturalpay/naturalpay-python/commit/f183e24afab77919101054db44771646bd827d4b))
* update SDK to match camelCase API shapes ([#26](https://github.com/naturalpay/naturalpay-python/issues/26)) ([942902f](https://github.com/naturalpay/naturalpay-python/commit/942902fddbde9e48f4d774820dd85719a6dfe694))


### Bug Fixes

* address codex review feedback ([4146f57](https://github.com/naturalpay/naturalpay-python/commit/4146f57e98624ba72bcde9787cc82692641bb50b))
* align AgentListResponse with server's cursor-based pagination ([f43236a](https://github.com/naturalpay/naturalpay-python/commit/f43236afd6e35a693231205174abecfe614cd6ab))
* **api:** Conform to new API Shape ([bbe0063](https://github.com/naturalpay/naturalpay-python/commit/bbe00639afa48ea49cfec447fc34b043f4164085))
* **api:** Fix API Key Prefixes ([4bd8928](https://github.com/naturalpay/naturalpay-python/commit/4bd8928e541cf1c510023888cdc3561d37610a12))
* **mcp:** bump fastmcp to v3 to match remote MCP server ([#37](https://github.com/naturalpay/naturalpay-python/issues/37)) ([98e5121](https://github.com/naturalpay/naturalpay-python/commit/98e5121f1869b2fe9a67e36c9f3a9467434643a1))
* only run release-drafter on push to main ([6feb31c](https://github.com/naturalpay/naturalpay-python/commit/6feb31cc2dc9c7b88ac794f6d1500908a23ffa40))
* remove /v1 prefix from API paths ([67ca604](https://github.com/naturalpay/naturalpay-python/commit/67ca604461d1a4101e6bcb962286aaf9d51b90e9))
* remove hardcoded API key from docker-compose.yml ([52315bc](https://github.com/naturalpay/naturalpay-python/commit/52315bcca47e84291d03b13b8c7c01d24dc985f6))
* remove stale parse_intent test (tool doesn't exist) ([f8063a5](https://github.com/naturalpay/naturalpay-python/commit/f8063a5e309067f500a9aa14eb371148344d1271))
* rename type param to transaction_type to avoid shadowing built-in ([4c1a264](https://github.com/naturalpay/naturalpay-python/commit/4c1a264c0bd0b08b0caf78d53a104efee316463d))
* restore agent_id to payments.create(), pass as X-Agent-ID header ([#12](https://github.com/naturalpay/naturalpay-python/issues/12)) ([e322563](https://github.com/naturalpay/naturalpay-python/commit/e322563ad5d7e75b6d4bc78c24b2efeeeec62df4))
* **routes:** Cover SDK Gaps ([#23](https://github.com/naturalpay/naturalpay-python/issues/23)) ([f9f3e55](https://github.com/naturalpay/naturalpay-python/commit/f9f3e556c5662fa270a03357e125ebaab9020bed))
* **sdk:** align implemented endpoints with public OpenAPI ([#47](https://github.com/naturalpay/naturalpay-python/issues/47)) ([ddbd1e8](https://github.com/naturalpay/naturalpay-python/commit/ddbd1e8db6e2c51afedccff207cf7ecbfcc4c4ae))
* unwrap error envelope so MCP surfaces actual error messages ([#28](https://github.com/naturalpay/naturalpay-python/issues/28)) ([3bc10e4](https://github.com/naturalpay/naturalpay-python/commit/3bc10e41588e2066b82bedc7441873fa1a462da3))
* update docs and fix conftest auth path mismatch ([0492665](https://github.com/naturalpay/naturalpay-python/commit/04926655dc57cfaafd58b71cfeb22020acd25b4c))
* use integer minor units for amounts ([#25](https://github.com/naturalpay/naturalpay-python/issues/25)) ([cabaff4](https://github.com/naturalpay/naturalpay-python/commit/cabaff472e121412d9cf5f17c0840dc752d30b13))


### Chores

* baseline main to Stainless next ([034bbed](https://github.com/naturalpay/naturalpay-python/commit/034bbed42e7a94aed004cca8f8f09cad223239ae))
* Bump Version ([0db7925](https://github.com/naturalpay/naturalpay-python/commit/0db7925789217921a7c1585a45b463df90119a03))
* **deps:** update dependency pytest to v9.0.3 [security] ([#52](https://github.com/naturalpay/naturalpay-python/issues/52)) ([83cf325](https://github.com/naturalpay/naturalpay-python/commit/83cf32521db3e235c412fcb880d952750b4355b6))
* **docs:** Update README ([aad1e0d](https://github.com/naturalpay/naturalpay-python/commit/aad1e0d8cfa757e7ccf40a6230abd76ee07e71c9))
* rename BFF → server-ts in SDK docstrings and audit doc ([#46](https://github.com/naturalpay/naturalpay-python/issues/46)) ([8dc7047](https://github.com/naturalpay/naturalpay-python/commit/8dc7047c653a303bfe6e4b0c5694c48978f0ca73))
* **sdk:** Reset Version to 0.1.0 ([2f96f4c](https://github.com/naturalpay/naturalpay-python/commit/2f96f4c8763726c4eead5abf501c1d9716147435))
* sync repo ([1f67783](https://github.com/naturalpay/naturalpay-python/commit/1f67783da26b917c3637829681b890f99761c70f))
* **tests:** remove client-coupled envelope canary ([b6414c6](https://github.com/naturalpay/naturalpay-python/commit/b6414c632cd4dc0940808d94198148dc6e230ab9))
* update SDK settings ([68b6038](https://github.com/naturalpay/naturalpay-python/commit/68b6038d11454d75cee8220c5c6122e3e30ed8d2))
* update SDK settings ([d21169b](https://github.com/naturalpay/naturalpay-python/commit/d21169b08221412710f4de87b6a177f96d6ec3d0))
* update SDK settings ([f4c67ba](https://github.com/naturalpay/naturalpay-python/commit/f4c67ba56802ebcf26424583d8bf40296f698c96))
* **version:** Keep in Sync with TS ([4a0c6e0](https://github.com/naturalpay/naturalpay-python/commit/4a0c6e08da75e50eb272a5e3d84785469316f4e9))


### Documentation

* **README:** Pare Down README ([#34](https://github.com/naturalpay/naturalpay-python/issues/34)) ([f102b05](https://github.com/naturalpay/naturalpay-python/commit/f102b050bab4d141c23d64c8e85c8152064eb3c8))
* refresh SDK README ([#15](https://github.com/naturalpay/naturalpay-python/issues/15)) ([5eb326a](https://github.com/naturalpay/naturalpay-python/commit/5eb326a6cadd6ec9a9c20b234eb6ab792095d506))


### Refactors

* **models:** consolidate wallet balance to breakdown + available ([#22](https://github.com/naturalpay/naturalpay-python/issues/22)) ([c052a51](https://github.com/naturalpay/naturalpay-python/commit/c052a51ec4e1560f9e512b033066d7d28791280a))
* remove X-On-Behalf-Of header, use body/query params ([#19](https://github.com/naturalpay/naturalpay-python/issues/19)) ([e981284](https://github.com/naturalpay/naturalpay-python/commit/e9812840ab7317cdd3867cb3cbd3198fb4ba7646))
* **sdk:** drop developer_context — header-only v2 ([#42](https://github.com/naturalpay/naturalpay-python/issues/42)) ([c6f5865](https://github.com/naturalpay/naturalpay-python/commit/c6f5865a0b2fd4e5c98ef6b66656a1ba7e470831))
* standardize ID prefixes to 3-letter format ([#18](https://github.com/naturalpay/naturalpay-python/issues/18)) ([cb47a86](https://github.com/naturalpay/naturalpay-python/commit/cb47a86115f4a4872412646bf99b56dfd4711fa0))
