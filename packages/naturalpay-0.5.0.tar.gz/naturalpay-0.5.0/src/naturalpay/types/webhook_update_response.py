# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "WebhookUpdateResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Creation timestamp (ISO 8601)"""

    description: str
    """Human-readable description"""

    enabled_events: List[
        Literal[
            "*",
            "party.updated",
            "party.delegation_granted",
            "wallet.created",
            "external_account.connected",
            "agent_delegation_invitation.created",
            "agent_delegation_invitation.accepted",
            "agent_delegation_invitation.declined",
            "agent_delegation_invitation.cancelled",
            "agent_delegation.revoked",
            "delegation.activated",
            "delegation.revoked",
            "deposit.created",
            "deposit.completed",
            "deposit.failed",
            "deposit.returned",
            "withdrawal.created",
            "withdrawal.completed",
            "withdrawal.failed",
            "withdrawal.returned",
            "payment.created",
            "payment.completed",
            "payment.failed",
            "payment_request.created",
            "payment_request.completed",
            "payment_request.failed",
            "payment_request.returned",
            "payment_request.incoming",
        ]
    ] = FieldInfo(alias="enabledEvents")
    """Event types this webhook listens to"""

    status: Literal["ENABLED", "DISABLED"]
    """Webhook status"""

    tags: Dict[str, str]
    """Custom metadata tags"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """Last update timestamp (ISO 8601)"""

    url: str
    """Webhook endpoint URL"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the webhook"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the webhook"""


class Data(BaseModel):
    id: str
    """Resource ID (whk_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class WebhookUpdateResponse(BaseModel):
    data: Data
