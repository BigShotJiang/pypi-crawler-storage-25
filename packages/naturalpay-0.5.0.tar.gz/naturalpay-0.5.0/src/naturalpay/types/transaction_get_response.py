# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "TransactionGetResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsDestinationParty",
    "DataRelationshipsDestinationPartyData",
    "DataRelationshipsSourceParty",
    "DataRelationshipsSourcePartyData",
    "DataRelationshipsPayment",
    "DataRelationshipsPaymentData",
    "DataRelationshipsTransfer",
    "DataRelationshipsTransferData",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in cents"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this transaction was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Payment description"""

    direction: Literal["INBOUND", "OUTBOUND"]
    """Direction: INBOUND | OUTBOUND"""

    expected_available_at: Optional[str] = FieldInfo(alias="expectedAvailableAt", default=None)
    """Projected funds-available time for transfers.

    Null when no projection exists and null for payments.
    """

    status: str
    """Transaction status"""

    transaction_type: Literal["payment", "transfer"] = FieldInfo(alias="transactionType")
    """Transaction type: payment | transfer"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this transaction was last updated"""


class DataRelationshipsDestinationPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsDestinationParty(BaseModel):
    """Destination party"""

    data: Optional[DataRelationshipsDestinationPartyData] = None
    """Related resource identifier"""


class DataRelationshipsSourcePartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsSourceParty(BaseModel):
    """Source party"""

    data: Optional[DataRelationshipsSourcePartyData] = None
    """Related resource identifier"""


class DataRelationshipsPaymentData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsPayment(BaseModel):
    """Payment that produced this transaction.

    Present only when the authenticated caller can access the payment resource.
    """

    data: DataRelationshipsPaymentData
    """Related resource identifier"""


class DataRelationshipsTransferData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsTransfer(BaseModel):
    """Transfer that produced this transaction.

    Present only when the authenticated caller can access the transfer resource.
    """

    data: DataRelationshipsTransferData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    destination_party: DataRelationshipsDestinationParty = FieldInfo(alias="destinationParty")
    """Destination party"""

    source_party: DataRelationshipsSourceParty = FieldInfo(alias="sourceParty")
    """Source party"""

    payment: Optional[DataRelationshipsPayment] = None
    """Payment that produced this transaction.

    Present only when the authenticated caller can access the payment resource.
    """

    transfer: Optional[DataRelationshipsTransfer] = None
    """Transfer that produced this transaction.

    Present only when the authenticated caller can access the transfer resource.
    """


class Data(BaseModel):
    id: str
    """Transaction handle (txn_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str


class TransactionGetResponse(BaseModel):
    data: Data
