# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "AgentListCustomersResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsAccess",
    "DataRelationshipsAccessData",
    "DataRelationshipsAccessDataAttributes",
    "DataRelationshipsAccessDataAttributesLimits",
    "DataRelationshipsAgent",
    "DataRelationshipsAgentData",
    "DataRelationshipsAgentDataAttributes",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Customer party attributes"""

    email: Optional[str] = None
    """Customer email, when known"""

    name: Optional[str] = None
    """Customer party display name, when known"""

    type: str
    """The customer is represented by a party"""


class DataRelationshipsAccessDataAttributesLimits(BaseModel):
    """Per-agent customer transaction limits"""

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Per-transaction cap, integer cents (USD)."""


class DataRelationshipsAccessDataAttributes(BaseModel):
    """Access attributes"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this agent-customer relationship was created"""

    limits: Optional[DataRelationshipsAccessDataAttributesLimits] = None
    """Per-agent customer transaction limits"""

    permissions: List[str]
    """Permissions granted or requested for this agent"""

    status: Literal["ACTIVE", "PENDING", "ACCEPTED", "DECLINED", "EXPIRED", "CANCELLED", "REVOKED"]
    """Current agent-customer relationship status"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this agent-customer relationship was last updated"""


class DataRelationshipsAccessData(BaseModel):
    id: str
    """Underlying access record ID"""

    attributes: DataRelationshipsAccessDataAttributes
    """Access attributes"""

    type: str
    """Resource type"""


class DataRelationshipsAccess(BaseModel):
    """This agent's access state for the customer"""

    data: DataRelationshipsAccessData


class DataRelationshipsAgentDataAttributes(BaseModel):
    """Agent attributes"""

    name: Optional[str] = None
    """Agent display name"""


class DataRelationshipsAgentData(BaseModel):
    id: str
    """Agent ID (agt\\__\\**)"""

    attributes: DataRelationshipsAgentDataAttributes
    """Agent attributes"""

    type: str
    """Resource type"""


class DataRelationshipsAgent(BaseModel):
    """Agent attached to this customer"""

    data: DataRelationshipsAgentData


class DataRelationships(BaseModel):
    """Related agent and access details"""

    access: DataRelationshipsAccess
    """This agent's access state for the customer"""

    agent: DataRelationshipsAgent
    """Agent attached to this customer"""


class Data(BaseModel):
    id: str
    """Customer party ID when known; otherwise the lowercased customer email"""

    attributes: DataAttributes
    """Customer party attributes"""

    relationships: DataRelationships
    """Related agent and access details"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class AgentListCustomersResponse(BaseModel):
    data: List[Data]

    meta: Meta
