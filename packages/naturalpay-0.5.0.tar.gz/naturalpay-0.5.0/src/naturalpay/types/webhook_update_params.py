# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WebhookUpdateParams"]


class WebhookUpdateParams(TypedDict, total=False):
    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    description: str
    """New description"""

    enabled_events: Annotated[
        List[
            Literal[
                "*",
                "party.updated",
                "party.delegation_granted",
                "wallet.created",
                "external_account.connected",
                "agent_delegation_invitation.created",
                "agent_delegation_invitation.accepted",
                "agent_delegation_invitation.declined",
                "agent_delegation_invitation.cancelled",
                "agent_delegation.revoked",
                "delegation.activated",
                "delegation.revoked",
                "deposit.created",
                "deposit.completed",
                "deposit.failed",
                "deposit.returned",
                "withdrawal.created",
                "withdrawal.completed",
                "withdrawal.failed",
                "withdrawal.returned",
                "payment.created",
                "payment.completed",
                "payment.failed",
                "payment_request.created",
                "payment_request.completed",
                "payment_request.failed",
                "payment_request.returned",
                "payment_request.incoming",
            ]
        ],
        PropertyInfo(alias="enabledEvents"),
    ]
    """Event types to subscribe to"""

    status: Literal["ENABLED", "DISABLED"]
    """New status"""

    tags: Dict[str, str]
    """Tag updates (set value to empty string to remove key)"""

    url: str
    """New webhook endpoint URL"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
