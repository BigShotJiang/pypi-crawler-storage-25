# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["WebhookRotateSecretParams"]


class WebhookRotateSecretParams(TypedDict, total=False):
    expires_in_seconds: Required[Annotated[int, PropertyInfo(alias="expiresInSeconds")]]
    """
    Grace period in seconds for the previous secret (0 = immediate cutover,
    max 86400)
    """

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
