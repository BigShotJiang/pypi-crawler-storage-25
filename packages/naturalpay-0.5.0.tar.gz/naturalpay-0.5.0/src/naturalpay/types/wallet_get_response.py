# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "WalletGetResponse",
    "Data",
    "DataAttributes",
    "DataAttributesBalance",
    "DataAttributesClaims",
    "DataAttributesDepositInstructions",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributesBalance(BaseModel):
    """Wallet ledger balance"""

    available: int
    """Amount currently available to spend or withdraw (cents)"""

    currency: Literal["USD"]
    """Currency code"""

    total: int
    """Total wallet ledger balance (cents)"""


class DataAttributesClaims(BaseModel):
    """Claimable payment totals"""

    amount: int
    """Total unclaimed product-payment amount (cents)"""

    count: int
    """Number of unclaimed product payments"""


class DataAttributesDepositInstructions(BaseModel):
    """ACH deposit instructions for this wallet, when available"""

    account_number: str = FieldInfo(alias="accountNumber")
    """Account number for ACH deposits"""

    bank_name: str = FieldInfo(alias="bankName")
    """Name of the receiving bank"""

    routing_number: str = FieldInfo(alias="routingNumber")
    """Bank routing number for ACH deposits"""


class DataAttributes(BaseModel):
    """Resource attributes"""

    balance: DataAttributesBalance
    """Wallet ledger balance"""

    claims: DataAttributesClaims
    """Claimable payment totals"""

    deposit_instructions: Optional[DataAttributesDepositInstructions] = FieldInfo(
        alias="depositInstructions", default=None
    )
    """ACH deposit instructions for this wallet, when available"""

    status: Literal["active"]
    """Wallet readiness status"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the wallet"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the wallet"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class WalletGetResponse(BaseModel):
    data: Data
