# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "AgentCreateCustomerResponse",
    "Data",
    "DataAttributes",
    "DataAttributesLimits",
    "DataAttributesRecipient",
    "DataAttributesRecipientUnionMember0",
    "DataAttributesRecipientUnionMember1",
    "DataAttributesRecipientUnionMember2",
    "DataRelationships",
    "DataRelationshipsAgent",
    "DataRelationshipsAgentData",
    "DataRelationshipsAgentDataAttributes",
    "DataRelationshipsCustomerParty",
    "DataRelationshipsCustomerPartyData",
    "Meta",
]


class DataAttributesLimits(BaseModel):
    """Requested per-agent customer limits"""

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Per-transaction cap, integer cents (USD)."""


class DataAttributesRecipientUnionMember0(BaseModel):
    type: str

    value: str
    """Email address"""


class DataAttributesRecipientUnionMember1(BaseModel):
    type: str

    value: str
    """Phone number in E.164 format"""


class DataAttributesRecipientUnionMember2(BaseModel):
    type: str

    value: str
    """Natural party ID (pty\\__\\**)"""


DataAttributesRecipient: TypeAlias = Union[
    DataAttributesRecipientUnionMember0, DataAttributesRecipientUnionMember1, DataAttributesRecipientUnionMember2
]


class DataAttributes(BaseModel):
    """Invitation attributes"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this invitation was created"""

    expires_at: str = FieldInfo(alias="expiresAt")
    """When this invitation expires"""

    limits: Optional[DataAttributesLimits] = None
    """Requested per-agent customer limits"""

    permissions: List[str]
    """Permissions requested for this agent invitation"""

    recipient: DataAttributesRecipient
    """Recipient identifier used to create the invitation"""

    status: Literal["ACTIVE", "PENDING", "ACCEPTED", "DECLINED", "EXPIRED", "CANCELLED", "REVOKED"]
    """Current invitation status"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this invitation was last updated"""


class DataRelationshipsAgentDataAttributes(BaseModel):
    """Agent attributes"""

    description: Optional[str] = None
    """Agent description"""

    name: Optional[str] = None
    """Agent display name"""

    status: Literal["ACTIVE", "REVOKED"]
    """Agent status"""


class DataRelationshipsAgentData(BaseModel):
    id: str
    """Agent ID (agt\\__\\**)"""

    attributes: DataRelationshipsAgentDataAttributes
    """Agent attributes"""

    type: str
    """Resource type"""


class DataRelationshipsAgent(BaseModel):
    """Agent attached to this invitation"""

    data: DataRelationshipsAgentData


class DataRelationshipsCustomerPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsCustomerParty(BaseModel):
    """
    Customer party when the recipient is an existing party or once the invitation is accepted
    """

    data: Optional[DataRelationshipsCustomerPartyData] = None
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Related agent and customer party"""

    agent: DataRelationshipsAgent
    """Agent attached to this invitation"""

    customer_party: DataRelationshipsCustomerParty = FieldInfo(alias="customerParty")
    """
    Customer party when the recipient is an existing party or once the invitation is
    accepted
    """


class Data(BaseModel):
    id: str
    """Customer invitation ID (adi\\__\\**)"""

    attributes: DataAttributes
    """Invitation attributes"""

    relationships: DataRelationships
    """Related agent and customer party"""

    type: str
    """Resource type"""


class Meta(BaseModel):
    """Batch invitation metadata"""

    email_failures: List[str] = FieldInfo(alias="emailFailures")
    """Invitation IDs whose welcome-email send failed.

    Invitations are still persisted; use the resend-email flow to retry.
    """


class AgentCreateCustomerResponse(BaseModel):
    data: List[Data]
    """Created customer invitation resources"""

    meta: Meta
    """Batch invitation metadata"""
