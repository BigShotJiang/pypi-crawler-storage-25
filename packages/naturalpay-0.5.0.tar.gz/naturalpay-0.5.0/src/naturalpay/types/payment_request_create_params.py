# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentRequestCreateParams", "Payer", "PayerUnionMember0", "PayerUnionMember1", "SendLink"]


class PaymentRequestCreateParams(TypedDict, total=False):
    amount: Required[int]
    """Amount in minor units (cents for USD)"""

    payer: Required[Payer]
    """Who pays — exactly one typed email, phone, party ID, or agent ID value."""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    currency: Literal["USD"]
    """Currency code (currently only USD)"""

    customer_party_id: Annotated[str, PropertyInfo(alias="customerPartyId")]
    """Requester party ID (pty\\__\\**).

    Omit to request into your own wallet; provide for delegated payment requests on
    behalf of a customer.
    """

    description: str
    """Free-form description shown to the payer. Maximum 500 characters."""

    payer_name: Annotated[str, PropertyInfo(alias="payerName")]
    """Display name of the payer"""

    send_link: Annotated[SendLink, PropertyInfo(alias="sendLink")]
    """
    If provided, immediately deliver the payment link to the payer via the named
    channel
    """

    wallet_id: Annotated[str, PropertyInfo(alias="walletId")]
    """Wallet that should receive the funds.

    Omit to use the requester party's default wallet.
    """

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class PayerUnionMember0(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Email address"""


class PayerUnionMember1(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Phone number in E.164 format"""


Payer: TypeAlias = Union[PayerUnionMember0, PayerUnionMember1]


class SendLink(TypedDict, total=False):
    """
    If provided, immediately deliver the payment link to the payer via the named channel
    """

    channel: Required[Literal["EMAIL", "SMS"]]
    """Channel to deliver the payment link"""
