# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "ExternalAccountRemoveResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
    "Meta",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    account_name: Optional[str] = FieldInfo(alias="accountName", default=None)
    """Account display name"""

    account_type: Optional[Literal["checking", "savings", "unknown"]] = FieldInfo(alias="accountType", default=None)
    """Account type (checking, savings)"""

    bank_name: Optional[str] = FieldInfo(alias="bankName", default=None)
    """Bank institution name"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the external account was linked"""

    last_four: str = FieldInfo(alias="lastFour")
    """Last 4 digits of account"""

    status: Literal["pending", "new", "active", "disabled", "deleted", "unknown"]
    """Status (pending, active, disabled)"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the external account"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the external account"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class Meta(BaseModel):
    deleted: Literal[True]
    """Indicates the resource was deleted"""


class ExternalAccountRemoveResponse(BaseModel):
    data: Data

    meta: Meta
