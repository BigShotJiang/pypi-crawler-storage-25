# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["PartyRemoveMemberResponse", "Data", "Meta"]


class Data(BaseModel):
    id: str
    """ID of the removed user"""

    type: str
    """Resource type"""


class Meta(BaseModel):
    deleted: Literal[True]
    """Indicates the resource was deleted"""


class PartyRemoveMemberResponse(BaseModel):
    data: Data

    meta: Meta
