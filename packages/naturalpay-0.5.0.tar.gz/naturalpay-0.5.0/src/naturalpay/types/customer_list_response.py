# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "CustomerListResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsAgents",
    "DataRelationshipsAgentsData",
    "DataRelationshipsAgentsDataAttributes",
    "DataRelationshipsAgentsDataAttributesLimits",
    "DataRelationshipsDelegation",
    "DataRelationshipsDelegationData",
    "DataRelationshipsDelegationDataAttributes",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)
    """When the customer party was created"""

    email: Optional[str] = None
    """Primary email"""

    name: str
    """Display name, falling back to legal name when display name is unset"""


class DataRelationshipsAgentsDataAttributesLimits(BaseModel):
    """Per-agent limits for this customer relationship"""

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Positive per-transaction limit in cents. null means no per-payment limit."""


class DataRelationshipsAgentsDataAttributes(BaseModel):
    """Agent access attributes"""

    limits: Optional[DataRelationshipsAgentsDataAttributesLimits] = None
    """Per-agent limits for this customer relationship"""

    name: Optional[str] = None
    """Agent display name"""

    permissions: List[str]
    """Permissions this agent has for the customer"""

    status: str
    """Agent-customer relationship status"""


class DataRelationshipsAgentsData(BaseModel):
    """Embedded agent access details"""

    id: str
    """Agent handle (agt_xxx)"""

    attributes: DataRelationshipsAgentsDataAttributes
    """Agent access attributes"""

    type: str
    """Resource type"""


class DataRelationshipsAgents(BaseModel):
    """Per-agent access for this customer relationship"""

    data: List[DataRelationshipsAgentsData]
    """Agents attached to this customer relationship"""


class DataRelationshipsDelegationDataAttributes(BaseModel):
    """Delegation attributes"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """When the customer relationship was created"""

    permissions: List[str]
    """Permissions available across this customer"""

    status: str
    """Customer relationship status"""


class DataRelationshipsDelegationData(BaseModel):
    """Embedded customer delegation details"""

    id: str
    """Delegation handle (dlg_xxx)"""

    attributes: DataRelationshipsDelegationDataAttributes
    """Delegation attributes"""

    type: str
    """Resource type"""


class DataRelationshipsDelegation(BaseModel):
    """Delegation state for this customer relationship"""

    data: DataRelationshipsDelegationData
    """Embedded customer delegation details"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    agents: DataRelationshipsAgents
    """Per-agent access for this customer relationship"""

    delegation: DataRelationshipsDelegation
    """Delegation state for this customer relationship"""


class Data(BaseModel):
    """Customer resource for an active customer (type='customer', id=pty_xxx)."""

    id: str
    """Customer party handle (pty_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class CustomerListResponse(BaseModel):
    data: List[Data]

    meta: Meta
