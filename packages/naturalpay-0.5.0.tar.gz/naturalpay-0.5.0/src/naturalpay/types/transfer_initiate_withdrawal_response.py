# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "TransferInitiateWithdrawalResponse",
    "Data",
    "DataAttributes",
    "DataAttributesFailure",
    "DataAttributesReturn",
    "DataRelationships",
    "DataRelationshipsExternalAccount",
    "DataRelationshipsExternalAccountData",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
    "DataRelationshipsTransaction",
    "DataRelationshipsTransactionData",
    "DataRelationshipsWallet",
    "DataRelationshipsWalletData",
]


class DataAttributesFailure(BaseModel):
    """Failure details when this transfer failed."""

    code: Optional[str] = None
    """Failure code, when available"""

    reason: Optional[str] = None
    """Failure reason, when available"""


class DataAttributesReturn(BaseModel):
    """Return details when this transfer was returned."""

    code: Optional[str] = None
    """Return code, when available"""

    reason: Optional[str] = None
    """Return reason, when available"""

    returned_at: Optional[str] = FieldInfo(alias="returnedAt", default=None)
    """When this transfer returned"""


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in cents"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this transfer was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Transfer description"""

    expected_available_at: Optional[str] = FieldInfo(alias="expectedAvailableAt", default=None)
    """Expected availability time, when known"""

    external_account_display_mask: Optional[str] = FieldInfo(alias="externalAccountDisplayMask", default=None)
    """Masked external account display"""

    failure: Optional[DataAttributesFailure] = None
    """Failure details when this transfer failed."""

    return_: Optional[DataAttributesReturn] = FieldInfo(alias="return", default=None)
    """Return details when this transfer was returned."""

    settled_at: Optional[str] = FieldInfo(alias="settledAt", default=None)
    """When this transfer settled"""

    status: Literal[
        "CREATED", "APPROVAL_DENIED", "PROCESSING", "IN_REVIEW", "COMPLETED", "FAILED", "RETURNED", "CANCELLED"
    ]
    """Transfer status"""

    submitted_at: Optional[str] = FieldInfo(alias="submittedAt", default=None)
    """When this transfer was submitted"""

    type: Literal["deposit", "withdrawal"]
    """Transfer type"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this transfer was last updated"""


class DataRelationshipsExternalAccountData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsExternalAccount(BaseModel):
    """External account used for this transfer, when available."""

    data: Optional[DataRelationshipsExternalAccountData] = None
    """Related resource identifier"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the transfer"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationshipsTransactionData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsTransaction(BaseModel):
    """Primary transaction row for this transfer, when available."""

    data: Optional[DataRelationshipsTransactionData] = None
    """Related resource identifier"""


class DataRelationshipsWalletData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsWallet(BaseModel):
    """Wallet for this transfer"""

    data: DataRelationshipsWalletData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    external_account: DataRelationshipsExternalAccount = FieldInfo(alias="externalAccount")
    """External account used for this transfer, when available."""

    party: DataRelationshipsParty
    """Party that owns the transfer"""

    transaction: DataRelationshipsTransaction
    """Primary transaction row for this transfer, when available."""

    wallet: DataRelationshipsWallet
    """Wallet for this transfer"""


class Data(BaseModel):
    id: str

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str


class TransferInitiateWithdrawalResponse(BaseModel):
    data: Data
