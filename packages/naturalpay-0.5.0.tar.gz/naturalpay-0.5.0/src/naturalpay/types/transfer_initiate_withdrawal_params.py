# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["TransferInitiateWithdrawalParams"]


class TransferInitiateWithdrawalParams(TypedDict, total=False):
    amount: Required[int]
    """Amount in cents"""

    external_account_id: Required[Annotated[str, PropertyInfo(alias="externalAccountId")]]
    """External account ID (eac\\__\\**)"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    currency: str
    """Currency code"""

    description: str
    """Withdrawal description"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
