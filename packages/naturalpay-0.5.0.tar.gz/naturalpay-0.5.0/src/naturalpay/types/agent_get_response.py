# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "AgentGetResponse",
    "Data",
    "DataAttributes",
    "DataAttributesLimits",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributesLimits(BaseModel):
    """Per-transaction spend cap for actions this agent initiates on its owner's party.

    null = no limit. Stored as Policy(scope=Agent(id)) in the policy service.
    """

    per_transaction: Optional[int] = FieldInfo(alias="perTransaction", default=None)
    """Positive per-transaction limit in cents. null means no per-payment limit."""


class DataAttributes(BaseModel):
    """Resource attributes"""

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)
    """When this agent was created"""

    created_by: Optional[str] = FieldInfo(alias="createdBy", default=None)
    """User who created this agent (usr\\__\\**)"""

    description: Optional[str] = None
    """Agent description"""

    limits: Optional[DataAttributesLimits] = None
    """Per-transaction spend cap for actions this agent initiates on its owner's party.

    null = no limit. Stored as Policy(scope=Agent(id)) in the policy service.
    """

    name: str
    """Agent display name"""

    status: Literal["ACTIVE", "REVOKED"]
    """Agent status"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the agent"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the agent"""


class Data(BaseModel):
    id: str
    """Resource ID"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class AgentGetResponse(BaseModel):
    data: Data
