# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentRequestFulfillParams", "PaymentSource", "PaymentSourceUnionMember0", "PaymentSourceUnionMember1"]


class PaymentRequestFulfillParams(TypedDict, total=False):
    payment_source: Required[Annotated[PaymentSource, PropertyInfo(alias="paymentSource")]]

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class PaymentSourceUnionMember0(TypedDict, total=False):
    type: Required[str]

    wallet_id: Required[Annotated[str, PropertyInfo(alias="walletId")]]


class PaymentSourceUnionMember1(TypedDict, total=False):
    external_account_id: Required[Annotated[str, PropertyInfo(alias="externalAccountId")]]

    type: Required[str]


PaymentSource: TypeAlias = Union[PaymentSourceUnionMember0, PaymentSourceUnionMember1]
