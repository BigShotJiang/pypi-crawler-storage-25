# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "PaymentRequestListResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsPayerParty",
    "DataRelationshipsPayerPartyData",
    "DataRelationshipsRequesterParty",
    "DataRelationshipsRequesterPartyData",
    "DataRelationshipsWallet",
    "DataRelationshipsWalletData",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in cents"""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the payment request was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Free-form description provided at creation. Maximum 500 characters."""

    payer_email: Optional[str] = FieldInfo(alias="payerEmail", default=None)
    """Email of the payer if addressed by email"""

    payer_identifier: str = FieldInfo(alias="payerIdentifier")
    """The identifier value used to address the payer"""

    payer_identifier_type: Literal["email", "phone", "party_id", "agent_id"] = FieldInfo(alias="payerIdentifierType")
    """Which identifier type was used to address the payer"""

    payer_name: Optional[str] = FieldInfo(alias="payerName", default=None)
    """Display name of the payer"""

    payer_party_id: Optional[str] = FieldInfo(alias="payerPartyId", default=None)
    """
    Natural party ID (pty\\__\\**) resolved for the payer, including agent owner parties
    """

    payer_phone: Optional[str] = FieldInfo(alias="payerPhone", default=None)
    """Phone of the payer in E.164 format if addressed by phone"""

    payment_link_url: str = FieldInfo(alias="paymentLinkUrl")
    """URL the payer visits to complete payment"""

    requester_email: Optional[str] = FieldInfo(alias="requesterEmail", default=None)
    """Email of the party requesting payment"""

    requester_name: Optional[str] = FieldInfo(alias="requesterName", default=None)
    """Display name of the party requesting payment"""

    status: Literal["OPEN", "PROCESSING", "COMPLETED", "CANCELLED", "DECLINED", "EXPIRED"]
    """Current status of the payment request"""

    transaction_id: Optional[str] = FieldInfo(alias="transactionId", default=None)
    """
    ID of the transaction created by the most recent payment attempt, or null if no
    attempt yet
    """

    updated_at: str = FieldInfo(alias="updatedAt")
    """ISO 8601 timestamp when the payment request was last updated"""


class DataRelationshipsPayerPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsPayerParty(BaseModel):
    """Resolved payer party, if the payer is known to Natural"""

    data: Optional[DataRelationshipsPayerPartyData] = None
    """Related resource identifier"""


class DataRelationshipsRequesterPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsRequesterParty(BaseModel):
    """Party requesting the payment"""

    data: DataRelationshipsRequesterPartyData
    """Related resource identifier"""


class DataRelationshipsWalletData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsWallet(BaseModel):
    """Wallet that receives the funds"""

    data: DataRelationshipsWalletData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    payer_party: DataRelationshipsPayerParty = FieldInfo(alias="payerParty")
    """Resolved payer party, if the payer is known to Natural"""

    requester_party: DataRelationshipsRequesterParty = FieldInfo(alias="requesterParty")
    """Party requesting the payment"""

    wallet: DataRelationshipsWallet
    """Wallet that receives the funds"""


class Data(BaseModel):
    id: str
    """Resource ID (prq\\__\\**)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class PaymentRequestListResponse(BaseModel):
    data: List[Data]

    meta: Meta
