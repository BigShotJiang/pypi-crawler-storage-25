# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "PaymentListResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsRecipient",
    "DataRelationshipsRecipientData",
    "DataRelationshipsSender",
    "DataRelationshipsSenderData",
    "DataRelationshipsTransaction",
    "DataRelationshipsTransactionData",
    "Meta",
    "MetaPagination",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    amount: int
    """Amount in cents"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this payment was created"""

    currency: str
    """Currency code"""

    description: Optional[str] = None
    """Payment description"""

    status: Literal[
        "CREATED", "PROCESSING", "PENDING_CLAIM", "IN_REVIEW", "COMPLETED", "FAILED", "APPROVAL_DENIED", "CANCELLED"
    ]
    """Payment status"""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """When this payment was last updated"""


class DataRelationshipsRecipientData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsRecipient(BaseModel):
    """Recipient party for this payment, when known."""

    data: Optional[DataRelationshipsRecipientData] = None
    """Related resource identifier"""


class DataRelationshipsSenderData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsSender(BaseModel):
    """Party that initiated the payment"""

    data: DataRelationshipsSenderData
    """Related resource identifier"""


class DataRelationshipsTransactionData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsTransaction(BaseModel):
    """Sender-side transaction row for this payment, when available."""

    data: Optional[DataRelationshipsTransactionData] = None
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    recipient: DataRelationshipsRecipient
    """Recipient party for this payment, when known."""

    sender: DataRelationshipsSender
    """Party that initiated the payment"""

    transaction: DataRelationshipsTransaction
    """Sender-side transaction row for this payment, when available."""


class Data(BaseModel):
    id: str

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class PaymentListResponse(BaseModel):
    data: List[Data]

    meta: Meta
