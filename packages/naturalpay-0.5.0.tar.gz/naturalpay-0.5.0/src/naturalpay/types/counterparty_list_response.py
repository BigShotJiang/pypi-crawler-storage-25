# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CounterpartyListResponse", "Data", "DataAttributes", "Meta", "MetaPagination"]


class DataAttributes(BaseModel):
    """Counterparty attributes"""

    email: Optional[str] = None
    """Counterparty primary email"""

    name: Optional[str] = None
    """Counterparty display name"""

    status: Optional[Literal["PROVISIONAL", "ACTIVE", "SUSPENDED", "INACTIVE"]] = None
    """Counterparty status"""


class Data(BaseModel):
    id: str
    """Counterparty ID: a party id (pty_xxx), or unknown_xxx for unclaimed payments"""

    attributes: DataAttributes
    """Counterparty attributes"""

    type: str
    """Resource type"""


class MetaPagination(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)


class Meta(BaseModel):
    pagination: MetaPagination


class CounterpartyListResponse(BaseModel):
    data: List[Data]

    meta: Meta
