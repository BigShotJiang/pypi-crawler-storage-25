# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["InvitationRevokeResponse", "Data", "DataAttributes", "Meta"]


class DataAttributes(BaseModel):
    """Resource attributes"""

    accepted_at: Optional[str] = FieldInfo(alias="acceptedAt", default=None)
    """When this invitation was accepted"""

    created_at: str = FieldInfo(alias="createdAt")
    """When this invitation was created"""

    email: str
    """Invitee email address"""

    expires_at: str = FieldInfo(alias="expiresAt")
    """When this invitation expires"""

    role: Literal["OWNER", "ADMIN", "MEMBER", "VIEWER"]
    """Role assigned on acceptance"""

    status: Literal["PENDING", "ACCEPTED", "REVOKED"]
    """Invitation status"""


class Data(BaseModel):
    id: str
    """Invitation ID (inv_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    type: str
    """Resource type"""


class Meta(BaseModel):
    deleted: Literal[True]
    """Indicates the resource was deleted"""


class InvitationRevokeResponse(BaseModel):
    data: Data

    meta: Meta
