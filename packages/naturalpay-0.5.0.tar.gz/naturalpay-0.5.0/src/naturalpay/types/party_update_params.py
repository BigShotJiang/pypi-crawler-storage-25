# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PartyUpdateParams"]


class PartyUpdateParams(TypedDict, total=False):
    display_name: Annotated[Optional[str], PropertyInfo(alias="displayName")]
    """Updated display name.

    Pass null to clear; empty string is rejected (use null to clear instead).
    """

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]
