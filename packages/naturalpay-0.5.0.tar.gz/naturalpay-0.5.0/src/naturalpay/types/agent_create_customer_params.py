# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["AgentCreateCustomerParams", "Recipient", "RecipientUnionMember0", "RecipientUnionMember1", "Limits"]


class AgentCreateCustomerParams(TypedDict, total=False):
    permissions: Required[SequenceNotStr[str]]
    """Permissions to request"""

    recipients: Required[Iterable[Recipient]]
    """Customer recipients to invite (1-50)"""

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    expires_at: Annotated[Union[str, datetime], PropertyInfo(alias="expiresAt", format="iso8601")]
    """Optional explicit expiry timestamp; server defaults to 7 days"""

    limits: Limits
    """Optional per-transaction limit"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class RecipientUnionMember0(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Email address"""


class RecipientUnionMember1(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Phone number in E.164 format"""


Recipient: TypeAlias = Union[RecipientUnionMember0, RecipientUnionMember1]


class Limits(TypedDict, total=False):
    """Optional per-transaction limit"""

    per_transaction: Annotated[Optional[int], PropertyInfo(alias="perTransaction")]
    """Per-transaction cap, integer cents (USD)."""
