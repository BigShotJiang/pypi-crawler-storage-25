# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "WebhookRotateSecretResponse",
    "Data",
    "DataAttributes",
    "DataRelationships",
    "DataRelationshipsParty",
    "DataRelationshipsPartyData",
]


class DataAttributes(BaseModel):
    """Resource attributes"""

    previous_secret_expires_at: Optional[datetime] = FieldInfo(alias="previousSecretExpiresAt", default=None)
    """When the previous secret expires (null if immediate cutover)"""

    signing_secret: str = FieldInfo(alias="signingSecret")
    """New webhook signing secret (shown only once — store securely!)"""


class DataRelationshipsPartyData(BaseModel):
    """Related resource identifier"""

    id: str

    type: str
    """Resource type"""


class DataRelationshipsParty(BaseModel):
    """Party that owns the webhook"""

    data: DataRelationshipsPartyData
    """Related resource identifier"""


class DataRelationships(BaseModel):
    """Resource relationships"""

    party: DataRelationshipsParty
    """Party that owns the webhook"""


class Data(BaseModel):
    id: str
    """Resource ID (whk_xxx)"""

    attributes: DataAttributes
    """Resource attributes"""

    relationships: DataRelationships
    """Resource relationships"""

    type: str
    """Resource type"""


class WebhookRotateSecretResponse(BaseModel):
    data: Data
