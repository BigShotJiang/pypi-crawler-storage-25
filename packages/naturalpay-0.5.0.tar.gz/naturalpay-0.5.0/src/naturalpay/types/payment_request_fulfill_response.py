# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["PaymentRequestFulfillResponse", "Data", "DataAttributes"]


class DataAttributes(BaseModel):
    outcome: Literal["processing", "failed", "completed", "in_review"]


class Data(BaseModel):
    id: str

    attributes: DataAttributes

    type: str


class PaymentRequestFulfillResponse(BaseModel):
    data: Data
