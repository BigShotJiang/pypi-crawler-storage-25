# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentCreateParams", "Counterparty", "CounterpartyUnionMember0", "CounterpartyUnionMember1"]


class PaymentCreateParams(TypedDict, total=False):
    amount: Required[int]
    """Amount in cents"""

    counterparty: Required[Counterparty]
    """Recipient identifier.

    Provide exactly one typed email, phone, party ID, or agent ID value.
    """

    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    currency: Literal["USD"]
    """Currency code"""

    customer_party_id: Annotated[str, PropertyInfo(alias="customerPartyId")]
    """Sender party ID (pty\\__\\**).

    Omit to send from your own wallet; provide for delegated payments on behalf of a
    customer.
    """

    description: str
    """Payment description. Maximum 500 characters."""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class CounterpartyUnionMember0(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Email address"""


class CounterpartyUnionMember1(TypedDict, total=False):
    type: Required[str]

    value: Required[str]
    """Phone number in E.164 format"""


Counterparty: TypeAlias = Union[CounterpartyUnionMember0, CounterpartyUnionMember1]
