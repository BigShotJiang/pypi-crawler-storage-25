# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["AgentUpdateParams", "Limits"]


class AgentUpdateParams(TypedDict, total=False):
    idempotency_key: Required[Annotated[str, PropertyInfo(alias="Idempotency-Key")]]

    description: Optional[str]
    """Updated description"""

    limits: Optional[Limits]
    """Per-transaction spend cap. null clears the limit; omitted leaves it unchanged."""

    name: Optional[str]
    """Updated name for the agent"""

    x_agent_id: Annotated[str, PropertyInfo(alias="X-Agent-ID")]

    x_instance_id: Annotated[str, PropertyInfo(alias="X-Instance-ID")]


class Limits(TypedDict, total=False):
    """Per-transaction spend cap. null clears the limit; omitted leaves it unchanged."""

    per_transaction: Annotated[Optional[int], PropertyInfo(alias="perTransaction")]
    """Positive per-transaction limit in cents. null means no per-payment limit."""
