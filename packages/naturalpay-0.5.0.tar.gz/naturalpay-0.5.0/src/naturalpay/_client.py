# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Dict, Mapping, cast
from typing_extensions import Self, Literal, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import (
    is_given,
    is_mapping_t,
    get_async_library,
)
from ._compat import cached_property
from ._models import SecurityOptions
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import NaturalError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import (
        agents,
        wallet,
        parties,
        api_keys,
        payments,
        webhooks,
        customers,
        transfers,
        invitations,
        transactions,
        counterparties,
        payment_requests,
        external_accounts,
    )
    from .resources.agents import AgentsResource, AsyncAgentsResource
    from .resources.wallet import WalletResource, AsyncWalletResource
    from .resources.parties import PartiesResource, AsyncPartiesResource
    from .resources.api_keys import APIKeysResource, AsyncAPIKeysResource
    from .resources.payments import PaymentsResource, AsyncPaymentsResource
    from .resources.webhooks import WebhooksResource, AsyncWebhooksResource
    from .resources.customers import CustomersResource, AsyncCustomersResource
    from .resources.transfers import TransfersResource, AsyncTransfersResource
    from .resources.invitations import InvitationsResource, AsyncInvitationsResource
    from .resources.transactions import TransactionsResource, AsyncTransactionsResource
    from .resources.counterparties import CounterpartiesResource, AsyncCounterpartiesResource
    from .resources.payment_requests import PaymentRequestsResource, AsyncPaymentRequestsResource
    from .resources.external_accounts import ExternalAccountsResource, AsyncExternalAccountsResource

__all__ = [
    "ENVIRONMENTS",
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "Natural",
    "AsyncNatural",
    "Client",
    "AsyncClient",
]

ENVIRONMENTS: Dict[str, str] = {
    "production": "https://api.natural.co",
    "dev": "https://api.dev.natural.co",
}


class Natural(SyncAPIClient):
    # client options
    api_key: str

    _environment: Literal["production", "dev"] | NotGiven

    def __init__(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "dev"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Natural client instance.

        This automatically infers the `api_key` argument from the `NATURAL_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("NATURAL_API_KEY")
        if api_key is None:
            raise NaturalError(
                "The api_key client option must be set either by passing api_key to the client or by setting the NATURAL_API_KEY environment variable"
            )
        self.api_key = api_key

        self._environment = environment

        base_url_env = os.environ.get("NATURALPAY_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `NATURALPAY_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "production"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        custom_headers_env = os.environ.get("NATURALPAY_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def agents(self) -> AgentsResource:
        """Agent management"""
        from .resources.agents import AgentsResource

        return AgentsResource(self)

    @cached_property
    def api_keys(self) -> APIKeysResource:
        """API key management"""
        from .resources.api_keys import APIKeysResource

        return APIKeysResource(self)

    @cached_property
    def counterparties(self) -> CounterpartiesResource:
        """Counterparty management"""
        from .resources.counterparties import CounterpartiesResource

        return CounterpartiesResource(self)

    @cached_property
    def customers(self) -> CustomersResource:
        """Customer management"""
        from .resources.customers import CustomersResource

        return CustomersResource(self)

    @cached_property
    def invitations(self) -> InvitationsResource:
        """Party invitation management"""
        from .resources.invitations import InvitationsResource

        return InvitationsResource(self)

    @cached_property
    def parties(self) -> PartiesResource:
        """Party and organization management"""
        from .resources.parties import PartiesResource

        return PartiesResource(self)

    @cached_property
    def payment_requests(self) -> PaymentRequestsResource:
        """Payment-request management"""
        from .resources.payment_requests import PaymentRequestsResource

        return PaymentRequestsResource(self)

    @cached_property
    def payments(self) -> PaymentsResource:
        """Payment operations"""
        from .resources.payments import PaymentsResource

        return PaymentsResource(self)

    @cached_property
    def transactions(self) -> TransactionsResource:
        """Transaction activity and history operations"""
        from .resources.transactions import TransactionsResource

        return TransactionsResource(self)

    @cached_property
    def transfers(self) -> TransfersResource:
        """Deposit and withdrawal operations"""
        from .resources.transfers import TransfersResource

        return TransfersResource(self)

    @cached_property
    def webhooks(self) -> WebhooksResource:
        """Webhook endpoint management"""
        from .resources.webhooks import WebhooksResource

        return WebhooksResource(self)

    @cached_property
    def wallet(self) -> WalletResource:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import WalletResource

        return WalletResource(self)

    @cached_property
    def external_accounts(self) -> ExternalAccountsResource:
        """Linked external bank accounts"""
        from .resources.external_accounts import ExternalAccountsResource

        return ExternalAccountsResource(self)

    @cached_property
    def with_raw_response(self) -> NaturalWithRawResponse:
        return NaturalWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> NaturalWithStreamedResponse:
        return NaturalWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._http_bearer if security.get("http_bearer", False) else {}),
        }

    @property
    def _http_bearer(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "dev"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncNatural(AsyncAPIClient):
    # client options
    api_key: str

    _environment: Literal["production", "dev"] | NotGiven

    def __init__(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "dev"] | NotGiven = not_given,
        base_url: str | httpx.URL | None | NotGiven = not_given,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncNatural client instance.

        This automatically infers the `api_key` argument from the `NATURAL_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("NATURAL_API_KEY")
        if api_key is None:
            raise NaturalError(
                "The api_key client option must be set either by passing api_key to the client or by setting the NATURAL_API_KEY environment variable"
            )
        self.api_key = api_key

        self._environment = environment

        base_url_env = os.environ.get("NATURALPAY_BASE_URL")
        if is_given(base_url) and base_url is not None:
            # cast required because mypy doesn't understand the type narrowing
            base_url = cast("str | httpx.URL", base_url)  # pyright: ignore[reportUnnecessaryCast]
        elif is_given(environment):
            if base_url_env and base_url is not None:
                raise ValueError(
                    "Ambiguous URL; The `NATURALPAY_BASE_URL` env var and the `environment` argument are given. If you want to use the environment, you must pass base_url=None",
                )

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc
        elif base_url_env is not None:
            base_url = base_url_env
        else:
            self._environment = environment = "production"

            try:
                base_url = ENVIRONMENTS[environment]
            except KeyError as exc:
                raise ValueError(f"Unknown environment: {environment}") from exc

        custom_headers_env = os.environ.get("NATURALPAY_CUSTOM_HEADERS")
        if custom_headers_env is not None:
            parsed: dict[str, str] = {}
            for line in custom_headers_env.split("\n"):
                colon = line.find(":")
                if colon >= 0:
                    parsed[line[:colon].strip()] = line[colon + 1 :].strip()
            default_headers = {**parsed, **(default_headers if is_mapping_t(default_headers) else {})}

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def agents(self) -> AsyncAgentsResource:
        """Agent management"""
        from .resources.agents import AsyncAgentsResource

        return AsyncAgentsResource(self)

    @cached_property
    def api_keys(self) -> AsyncAPIKeysResource:
        """API key management"""
        from .resources.api_keys import AsyncAPIKeysResource

        return AsyncAPIKeysResource(self)

    @cached_property
    def counterparties(self) -> AsyncCounterpartiesResource:
        """Counterparty management"""
        from .resources.counterparties import AsyncCounterpartiesResource

        return AsyncCounterpartiesResource(self)

    @cached_property
    def customers(self) -> AsyncCustomersResource:
        """Customer management"""
        from .resources.customers import AsyncCustomersResource

        return AsyncCustomersResource(self)

    @cached_property
    def invitations(self) -> AsyncInvitationsResource:
        """Party invitation management"""
        from .resources.invitations import AsyncInvitationsResource

        return AsyncInvitationsResource(self)

    @cached_property
    def parties(self) -> AsyncPartiesResource:
        """Party and organization management"""
        from .resources.parties import AsyncPartiesResource

        return AsyncPartiesResource(self)

    @cached_property
    def payment_requests(self) -> AsyncPaymentRequestsResource:
        """Payment-request management"""
        from .resources.payment_requests import AsyncPaymentRequestsResource

        return AsyncPaymentRequestsResource(self)

    @cached_property
    def payments(self) -> AsyncPaymentsResource:
        """Payment operations"""
        from .resources.payments import AsyncPaymentsResource

        return AsyncPaymentsResource(self)

    @cached_property
    def transactions(self) -> AsyncTransactionsResource:
        """Transaction activity and history operations"""
        from .resources.transactions import AsyncTransactionsResource

        return AsyncTransactionsResource(self)

    @cached_property
    def transfers(self) -> AsyncTransfersResource:
        """Deposit and withdrawal operations"""
        from .resources.transfers import AsyncTransfersResource

        return AsyncTransfersResource(self)

    @cached_property
    def webhooks(self) -> AsyncWebhooksResource:
        """Webhook endpoint management"""
        from .resources.webhooks import AsyncWebhooksResource

        return AsyncWebhooksResource(self)

    @cached_property
    def wallet(self) -> AsyncWalletResource:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import AsyncWalletResource

        return AsyncWalletResource(self)

    @cached_property
    def external_accounts(self) -> AsyncExternalAccountsResource:
        """Linked external bank accounts"""
        from .resources.external_accounts import AsyncExternalAccountsResource

        return AsyncExternalAccountsResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncNaturalWithRawResponse:
        return AsyncNaturalWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncNaturalWithStreamedResponse:
        return AsyncNaturalWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._http_bearer if security.get("http_bearer", False) else {}),
        }

    @property
    def _http_bearer(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        environment: Literal["production", "dev"] | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            base_url=base_url or self.base_url,
            environment=environment or self._environment,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class NaturalWithRawResponse:
    _client: Natural

    def __init__(self, client: Natural) -> None:
        self._client = client

    @cached_property
    def agents(self) -> agents.AgentsResourceWithRawResponse:
        """Agent management"""
        from .resources.agents import AgentsResourceWithRawResponse

        return AgentsResourceWithRawResponse(self._client.agents)

    @cached_property
    def api_keys(self) -> api_keys.APIKeysResourceWithRawResponse:
        """API key management"""
        from .resources.api_keys import APIKeysResourceWithRawResponse

        return APIKeysResourceWithRawResponse(self._client.api_keys)

    @cached_property
    def counterparties(self) -> counterparties.CounterpartiesResourceWithRawResponse:
        """Counterparty management"""
        from .resources.counterparties import CounterpartiesResourceWithRawResponse

        return CounterpartiesResourceWithRawResponse(self._client.counterparties)

    @cached_property
    def customers(self) -> customers.CustomersResourceWithRawResponse:
        """Customer management"""
        from .resources.customers import CustomersResourceWithRawResponse

        return CustomersResourceWithRawResponse(self._client.customers)

    @cached_property
    def invitations(self) -> invitations.InvitationsResourceWithRawResponse:
        """Party invitation management"""
        from .resources.invitations import InvitationsResourceWithRawResponse

        return InvitationsResourceWithRawResponse(self._client.invitations)

    @cached_property
    def parties(self) -> parties.PartiesResourceWithRawResponse:
        """Party and organization management"""
        from .resources.parties import PartiesResourceWithRawResponse

        return PartiesResourceWithRawResponse(self._client.parties)

    @cached_property
    def payment_requests(self) -> payment_requests.PaymentRequestsResourceWithRawResponse:
        """Payment-request management"""
        from .resources.payment_requests import PaymentRequestsResourceWithRawResponse

        return PaymentRequestsResourceWithRawResponse(self._client.payment_requests)

    @cached_property
    def payments(self) -> payments.PaymentsResourceWithRawResponse:
        """Payment operations"""
        from .resources.payments import PaymentsResourceWithRawResponse

        return PaymentsResourceWithRawResponse(self._client.payments)

    @cached_property
    def transactions(self) -> transactions.TransactionsResourceWithRawResponse:
        """Transaction activity and history operations"""
        from .resources.transactions import TransactionsResourceWithRawResponse

        return TransactionsResourceWithRawResponse(self._client.transactions)

    @cached_property
    def transfers(self) -> transfers.TransfersResourceWithRawResponse:
        """Deposit and withdrawal operations"""
        from .resources.transfers import TransfersResourceWithRawResponse

        return TransfersResourceWithRawResponse(self._client.transfers)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithRawResponse:
        """Webhook endpoint management"""
        from .resources.webhooks import WebhooksResourceWithRawResponse

        return WebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def wallet(self) -> wallet.WalletResourceWithRawResponse:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import WalletResourceWithRawResponse

        return WalletResourceWithRawResponse(self._client.wallet)

    @cached_property
    def external_accounts(self) -> external_accounts.ExternalAccountsResourceWithRawResponse:
        """Linked external bank accounts"""
        from .resources.external_accounts import ExternalAccountsResourceWithRawResponse

        return ExternalAccountsResourceWithRawResponse(self._client.external_accounts)


class AsyncNaturalWithRawResponse:
    _client: AsyncNatural

    def __init__(self, client: AsyncNatural) -> None:
        self._client = client

    @cached_property
    def agents(self) -> agents.AsyncAgentsResourceWithRawResponse:
        """Agent management"""
        from .resources.agents import AsyncAgentsResourceWithRawResponse

        return AsyncAgentsResourceWithRawResponse(self._client.agents)

    @cached_property
    def api_keys(self) -> api_keys.AsyncAPIKeysResourceWithRawResponse:
        """API key management"""
        from .resources.api_keys import AsyncAPIKeysResourceWithRawResponse

        return AsyncAPIKeysResourceWithRawResponse(self._client.api_keys)

    @cached_property
    def counterparties(self) -> counterparties.AsyncCounterpartiesResourceWithRawResponse:
        """Counterparty management"""
        from .resources.counterparties import AsyncCounterpartiesResourceWithRawResponse

        return AsyncCounterpartiesResourceWithRawResponse(self._client.counterparties)

    @cached_property
    def customers(self) -> customers.AsyncCustomersResourceWithRawResponse:
        """Customer management"""
        from .resources.customers import AsyncCustomersResourceWithRawResponse

        return AsyncCustomersResourceWithRawResponse(self._client.customers)

    @cached_property
    def invitations(self) -> invitations.AsyncInvitationsResourceWithRawResponse:
        """Party invitation management"""
        from .resources.invitations import AsyncInvitationsResourceWithRawResponse

        return AsyncInvitationsResourceWithRawResponse(self._client.invitations)

    @cached_property
    def parties(self) -> parties.AsyncPartiesResourceWithRawResponse:
        """Party and organization management"""
        from .resources.parties import AsyncPartiesResourceWithRawResponse

        return AsyncPartiesResourceWithRawResponse(self._client.parties)

    @cached_property
    def payment_requests(self) -> payment_requests.AsyncPaymentRequestsResourceWithRawResponse:
        """Payment-request management"""
        from .resources.payment_requests import AsyncPaymentRequestsResourceWithRawResponse

        return AsyncPaymentRequestsResourceWithRawResponse(self._client.payment_requests)

    @cached_property
    def payments(self) -> payments.AsyncPaymentsResourceWithRawResponse:
        """Payment operations"""
        from .resources.payments import AsyncPaymentsResourceWithRawResponse

        return AsyncPaymentsResourceWithRawResponse(self._client.payments)

    @cached_property
    def transactions(self) -> transactions.AsyncTransactionsResourceWithRawResponse:
        """Transaction activity and history operations"""
        from .resources.transactions import AsyncTransactionsResourceWithRawResponse

        return AsyncTransactionsResourceWithRawResponse(self._client.transactions)

    @cached_property
    def transfers(self) -> transfers.AsyncTransfersResourceWithRawResponse:
        """Deposit and withdrawal operations"""
        from .resources.transfers import AsyncTransfersResourceWithRawResponse

        return AsyncTransfersResourceWithRawResponse(self._client.transfers)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithRawResponse:
        """Webhook endpoint management"""
        from .resources.webhooks import AsyncWebhooksResourceWithRawResponse

        return AsyncWebhooksResourceWithRawResponse(self._client.webhooks)

    @cached_property
    def wallet(self) -> wallet.AsyncWalletResourceWithRawResponse:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import AsyncWalletResourceWithRawResponse

        return AsyncWalletResourceWithRawResponse(self._client.wallet)

    @cached_property
    def external_accounts(self) -> external_accounts.AsyncExternalAccountsResourceWithRawResponse:
        """Linked external bank accounts"""
        from .resources.external_accounts import AsyncExternalAccountsResourceWithRawResponse

        return AsyncExternalAccountsResourceWithRawResponse(self._client.external_accounts)


class NaturalWithStreamedResponse:
    _client: Natural

    def __init__(self, client: Natural) -> None:
        self._client = client

    @cached_property
    def agents(self) -> agents.AgentsResourceWithStreamingResponse:
        """Agent management"""
        from .resources.agents import AgentsResourceWithStreamingResponse

        return AgentsResourceWithStreamingResponse(self._client.agents)

    @cached_property
    def api_keys(self) -> api_keys.APIKeysResourceWithStreamingResponse:
        """API key management"""
        from .resources.api_keys import APIKeysResourceWithStreamingResponse

        return APIKeysResourceWithStreamingResponse(self._client.api_keys)

    @cached_property
    def counterparties(self) -> counterparties.CounterpartiesResourceWithStreamingResponse:
        """Counterparty management"""
        from .resources.counterparties import CounterpartiesResourceWithStreamingResponse

        return CounterpartiesResourceWithStreamingResponse(self._client.counterparties)

    @cached_property
    def customers(self) -> customers.CustomersResourceWithStreamingResponse:
        """Customer management"""
        from .resources.customers import CustomersResourceWithStreamingResponse

        return CustomersResourceWithStreamingResponse(self._client.customers)

    @cached_property
    def invitations(self) -> invitations.InvitationsResourceWithStreamingResponse:
        """Party invitation management"""
        from .resources.invitations import InvitationsResourceWithStreamingResponse

        return InvitationsResourceWithStreamingResponse(self._client.invitations)

    @cached_property
    def parties(self) -> parties.PartiesResourceWithStreamingResponse:
        """Party and organization management"""
        from .resources.parties import PartiesResourceWithStreamingResponse

        return PartiesResourceWithStreamingResponse(self._client.parties)

    @cached_property
    def payment_requests(self) -> payment_requests.PaymentRequestsResourceWithStreamingResponse:
        """Payment-request management"""
        from .resources.payment_requests import PaymentRequestsResourceWithStreamingResponse

        return PaymentRequestsResourceWithStreamingResponse(self._client.payment_requests)

    @cached_property
    def payments(self) -> payments.PaymentsResourceWithStreamingResponse:
        """Payment operations"""
        from .resources.payments import PaymentsResourceWithStreamingResponse

        return PaymentsResourceWithStreamingResponse(self._client.payments)

    @cached_property
    def transactions(self) -> transactions.TransactionsResourceWithStreamingResponse:
        """Transaction activity and history operations"""
        from .resources.transactions import TransactionsResourceWithStreamingResponse

        return TransactionsResourceWithStreamingResponse(self._client.transactions)

    @cached_property
    def transfers(self) -> transfers.TransfersResourceWithStreamingResponse:
        """Deposit and withdrawal operations"""
        from .resources.transfers import TransfersResourceWithStreamingResponse

        return TransfersResourceWithStreamingResponse(self._client.transfers)

    @cached_property
    def webhooks(self) -> webhooks.WebhooksResourceWithStreamingResponse:
        """Webhook endpoint management"""
        from .resources.webhooks import WebhooksResourceWithStreamingResponse

        return WebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def wallet(self) -> wallet.WalletResourceWithStreamingResponse:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import WalletResourceWithStreamingResponse

        return WalletResourceWithStreamingResponse(self._client.wallet)

    @cached_property
    def external_accounts(self) -> external_accounts.ExternalAccountsResourceWithStreamingResponse:
        """Linked external bank accounts"""
        from .resources.external_accounts import ExternalAccountsResourceWithStreamingResponse

        return ExternalAccountsResourceWithStreamingResponse(self._client.external_accounts)


class AsyncNaturalWithStreamedResponse:
    _client: AsyncNatural

    def __init__(self, client: AsyncNatural) -> None:
        self._client = client

    @cached_property
    def agents(self) -> agents.AsyncAgentsResourceWithStreamingResponse:
        """Agent management"""
        from .resources.agents import AsyncAgentsResourceWithStreamingResponse

        return AsyncAgentsResourceWithStreamingResponse(self._client.agents)

    @cached_property
    def api_keys(self) -> api_keys.AsyncAPIKeysResourceWithStreamingResponse:
        """API key management"""
        from .resources.api_keys import AsyncAPIKeysResourceWithStreamingResponse

        return AsyncAPIKeysResourceWithStreamingResponse(self._client.api_keys)

    @cached_property
    def counterparties(self) -> counterparties.AsyncCounterpartiesResourceWithStreamingResponse:
        """Counterparty management"""
        from .resources.counterparties import AsyncCounterpartiesResourceWithStreamingResponse

        return AsyncCounterpartiesResourceWithStreamingResponse(self._client.counterparties)

    @cached_property
    def customers(self) -> customers.AsyncCustomersResourceWithStreamingResponse:
        """Customer management"""
        from .resources.customers import AsyncCustomersResourceWithStreamingResponse

        return AsyncCustomersResourceWithStreamingResponse(self._client.customers)

    @cached_property
    def invitations(self) -> invitations.AsyncInvitationsResourceWithStreamingResponse:
        """Party invitation management"""
        from .resources.invitations import AsyncInvitationsResourceWithStreamingResponse

        return AsyncInvitationsResourceWithStreamingResponse(self._client.invitations)

    @cached_property
    def parties(self) -> parties.AsyncPartiesResourceWithStreamingResponse:
        """Party and organization management"""
        from .resources.parties import AsyncPartiesResourceWithStreamingResponse

        return AsyncPartiesResourceWithStreamingResponse(self._client.parties)

    @cached_property
    def payment_requests(self) -> payment_requests.AsyncPaymentRequestsResourceWithStreamingResponse:
        """Payment-request management"""
        from .resources.payment_requests import AsyncPaymentRequestsResourceWithStreamingResponse

        return AsyncPaymentRequestsResourceWithStreamingResponse(self._client.payment_requests)

    @cached_property
    def payments(self) -> payments.AsyncPaymentsResourceWithStreamingResponse:
        """Payment operations"""
        from .resources.payments import AsyncPaymentsResourceWithStreamingResponse

        return AsyncPaymentsResourceWithStreamingResponse(self._client.payments)

    @cached_property
    def transactions(self) -> transactions.AsyncTransactionsResourceWithStreamingResponse:
        """Transaction activity and history operations"""
        from .resources.transactions import AsyncTransactionsResourceWithStreamingResponse

        return AsyncTransactionsResourceWithStreamingResponse(self._client.transactions)

    @cached_property
    def transfers(self) -> transfers.AsyncTransfersResourceWithStreamingResponse:
        """Deposit and withdrawal operations"""
        from .resources.transfers import AsyncTransfersResourceWithStreamingResponse

        return AsyncTransfersResourceWithStreamingResponse(self._client.transfers)

    @cached_property
    def webhooks(self) -> webhooks.AsyncWebhooksResourceWithStreamingResponse:
        """Webhook endpoint management"""
        from .resources.webhooks import AsyncWebhooksResourceWithStreamingResponse

        return AsyncWebhooksResourceWithStreamingResponse(self._client.webhooks)

    @cached_property
    def wallet(self) -> wallet.AsyncWalletResourceWithStreamingResponse:
        """Wallet balance, deposits, withdrawals, and external accounts"""
        from .resources.wallet import AsyncWalletResourceWithStreamingResponse

        return AsyncWalletResourceWithStreamingResponse(self._client.wallet)

    @cached_property
    def external_accounts(self) -> external_accounts.AsyncExternalAccountsResourceWithStreamingResponse:
        """Linked external bank accounts"""
        from .resources.external_accounts import AsyncExternalAccountsResourceWithStreamingResponse

        return AsyncExternalAccountsResourceWithStreamingResponse(self._client.external_accounts)


Client = Natural

AsyncClient = AsyncNatural
