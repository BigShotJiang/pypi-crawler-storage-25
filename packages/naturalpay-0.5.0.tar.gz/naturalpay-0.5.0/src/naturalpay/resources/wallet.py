# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, strip_not_given
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.wallet_get_response import WalletGetResponse
from ..types.wallet_list_response import WalletListResponse

__all__ = ["WalletResource", "AsyncWalletResource"]


class WalletResource(SyncAPIResource):
    """Wallet balance, deposits, withdrawals, and external accounts"""

    @cached_property
    def with_raw_response(self) -> WalletResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return WalletResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WalletResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return WalletResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletListResponse:
        """
        List wallets for the authenticated party, including balance and ACH deposit
        instructions when available. Currently returns at most one wallet.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/wallets",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletListResponse,
        )

    def get(
        self,
        wallet_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetResponse:
        """
        Get a wallet visible to the authenticated party, including balance and ACH
        deposit instructions when available.

        Args:
          wallet_id: Wallet ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not wallet_id:
            raise ValueError(f"Expected a non-empty value for `wallet_id` but received {wallet_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/wallets/{wallet_id}", wallet_id=wallet_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletGetResponse,
        )


class AsyncWalletResource(AsyncAPIResource):
    """Wallet balance, deposits, withdrawals, and external accounts"""

    @cached_property
    def with_raw_response(self) -> AsyncWalletResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWalletResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWalletResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncWalletResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletListResponse:
        """
        List wallets for the authenticated party, including balance and ACH deposit
        instructions when available. Currently returns at most one wallet.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/wallets",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletListResponse,
        )

    async def get(
        self,
        wallet_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WalletGetResponse:
        """
        Get a wallet visible to the authenticated party, including balance and ACH
        deposit instructions when available.

        Args:
          wallet_id: Wallet ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not wallet_id:
            raise ValueError(f"Expected a non-empty value for `wallet_id` but received {wallet_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/wallets/{wallet_id}", wallet_id=wallet_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WalletGetResponse,
        )


class WalletResourceWithRawResponse:
    def __init__(self, wallet: WalletResource) -> None:
        self._wallet = wallet

        self.list = to_raw_response_wrapper(
            wallet.list,
        )
        self.get = to_raw_response_wrapper(
            wallet.get,
        )


class AsyncWalletResourceWithRawResponse:
    def __init__(self, wallet: AsyncWalletResource) -> None:
        self._wallet = wallet

        self.list = async_to_raw_response_wrapper(
            wallet.list,
        )
        self.get = async_to_raw_response_wrapper(
            wallet.get,
        )


class WalletResourceWithStreamingResponse:
    def __init__(self, wallet: WalletResource) -> None:
        self._wallet = wallet

        self.list = to_streamed_response_wrapper(
            wallet.list,
        )
        self.get = to_streamed_response_wrapper(
            wallet.get,
        )


class AsyncWalletResourceWithStreamingResponse:
    def __init__(self, wallet: AsyncWalletResource) -> None:
        self._wallet = wallet

        self.list = async_to_streamed_response_wrapper(
            wallet.list,
        )
        self.get = async_to_streamed_response_wrapper(
            wallet.get,
        )
