# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import (
    transfer_get_params,
    transfer_list_params,
    transfer_initiate_deposit_params,
    transfer_initiate_withdrawal_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.transfer_get_response import TransferGetResponse
from ..types.transfer_list_response import TransferListResponse
from ..types.transfer_initiate_deposit_response import TransferInitiateDepositResponse
from ..types.transfer_initiate_withdrawal_response import TransferInitiateWithdrawalResponse

__all__ = ["TransfersResource", "AsyncTransfersResource"]


class TransfersResource(SyncAPIResource):
    """Deposit and withdrawal operations"""

    @cached_property
    def with_raw_response(self) -> TransfersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return TransfersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TransfersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return TransfersResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferListResponse:
        """
        List deposits and withdrawals for the authenticated party.

        Args:
          cursor: Pagination cursor from previous response

          limit: Results per page

          party_id: Party ID for delegated transfer lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/transfers",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "party_id": party_id,
                    },
                    transfer_list_params.TransferListParams,
                ),
            ),
            cast_to=TransferListResponse,
        )

    def get(
        self,
        transfer_id: str,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferGetResponse:
        """
        Get a deposit or withdrawal by ID.

        Args:
          party_id: Party ID for delegated transfer lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not transfer_id:
            raise ValueError(f"Expected a non-empty value for `transfer_id` but received {transfer_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/transfers/{transfer_id}", transfer_id=transfer_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"party_id": party_id}, transfer_get_params.TransferGetParams),
            ),
            cast_to=TransferGetResponse,
        )

    def initiate_deposit(
        self,
        *,
        amount: int,
        external_account_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferInitiateDepositResponse:
        """
        Initiate a wallet deposit.

        Args:
          amount: Amount in cents

          external_account_id: External account ID (eac\\__\\**)

          currency: Currency code

          description: Deposit description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/transfers/deposit",
            body=maybe_transform(
                {
                    "amount": amount,
                    "external_account_id": external_account_id,
                    "currency": currency,
                    "description": description,
                },
                transfer_initiate_deposit_params.TransferInitiateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransferInitiateDepositResponse,
        )

    def initiate_withdrawal(
        self,
        *,
        amount: int,
        external_account_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferInitiateWithdrawalResponse:
        """
        Initiate a wallet withdrawal.

        Args:
          amount: Amount in cents

          external_account_id: External account ID (eac\\__\\**)

          currency: Currency code

          description: Withdrawal description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/transfers/withdraw",
            body=maybe_transform(
                {
                    "amount": amount,
                    "external_account_id": external_account_id,
                    "currency": currency,
                    "description": description,
                },
                transfer_initiate_withdrawal_params.TransferInitiateWithdrawalParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransferInitiateWithdrawalResponse,
        )


class AsyncTransfersResource(AsyncAPIResource):
    """Deposit and withdrawal operations"""

    @cached_property
    def with_raw_response(self) -> AsyncTransfersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncTransfersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTransfersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncTransfersResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferListResponse:
        """
        List deposits and withdrawals for the authenticated party.

        Args:
          cursor: Pagination cursor from previous response

          limit: Results per page

          party_id: Party ID for delegated transfer lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/transfers",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "party_id": party_id,
                    },
                    transfer_list_params.TransferListParams,
                ),
            ),
            cast_to=TransferListResponse,
        )

    async def get(
        self,
        transfer_id: str,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferGetResponse:
        """
        Get a deposit or withdrawal by ID.

        Args:
          party_id: Party ID for delegated transfer lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not transfer_id:
            raise ValueError(f"Expected a non-empty value for `transfer_id` but received {transfer_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/transfers/{transfer_id}", transfer_id=transfer_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"party_id": party_id}, transfer_get_params.TransferGetParams),
            ),
            cast_to=TransferGetResponse,
        )

    async def initiate_deposit(
        self,
        *,
        amount: int,
        external_account_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferInitiateDepositResponse:
        """
        Initiate a wallet deposit.

        Args:
          amount: Amount in cents

          external_account_id: External account ID (eac\\__\\**)

          currency: Currency code

          description: Deposit description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/transfers/deposit",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "external_account_id": external_account_id,
                    "currency": currency,
                    "description": description,
                },
                transfer_initiate_deposit_params.TransferInitiateDepositParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransferInitiateDepositResponse,
        )

    async def initiate_withdrawal(
        self,
        *,
        amount: int,
        external_account_id: str,
        idempotency_key: str,
        currency: str | Omit = omit,
        description: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransferInitiateWithdrawalResponse:
        """
        Initiate a wallet withdrawal.

        Args:
          amount: Amount in cents

          external_account_id: External account ID (eac\\__\\**)

          currency: Currency code

          description: Withdrawal description

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/transfers/withdraw",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "external_account_id": external_account_id,
                    "currency": currency,
                    "description": description,
                },
                transfer_initiate_withdrawal_params.TransferInitiateWithdrawalParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransferInitiateWithdrawalResponse,
        )


class TransfersResourceWithRawResponse:
    def __init__(self, transfers: TransfersResource) -> None:
        self._transfers = transfers

        self.list = to_raw_response_wrapper(
            transfers.list,
        )
        self.get = to_raw_response_wrapper(
            transfers.get,
        )
        self.initiate_deposit = to_raw_response_wrapper(
            transfers.initiate_deposit,
        )
        self.initiate_withdrawal = to_raw_response_wrapper(
            transfers.initiate_withdrawal,
        )


class AsyncTransfersResourceWithRawResponse:
    def __init__(self, transfers: AsyncTransfersResource) -> None:
        self._transfers = transfers

        self.list = async_to_raw_response_wrapper(
            transfers.list,
        )
        self.get = async_to_raw_response_wrapper(
            transfers.get,
        )
        self.initiate_deposit = async_to_raw_response_wrapper(
            transfers.initiate_deposit,
        )
        self.initiate_withdrawal = async_to_raw_response_wrapper(
            transfers.initiate_withdrawal,
        )


class TransfersResourceWithStreamingResponse:
    def __init__(self, transfers: TransfersResource) -> None:
        self._transfers = transfers

        self.list = to_streamed_response_wrapper(
            transfers.list,
        )
        self.get = to_streamed_response_wrapper(
            transfers.get,
        )
        self.initiate_deposit = to_streamed_response_wrapper(
            transfers.initiate_deposit,
        )
        self.initiate_withdrawal = to_streamed_response_wrapper(
            transfers.initiate_withdrawal,
        )


class AsyncTransfersResourceWithStreamingResponse:
    def __init__(self, transfers: AsyncTransfersResource) -> None:
        self._transfers = transfers

        self.list = async_to_streamed_response_wrapper(
            transfers.list,
        )
        self.get = async_to_streamed_response_wrapper(
            transfers.get,
        )
        self.initiate_deposit = async_to_streamed_response_wrapper(
            transfers.initiate_deposit,
        )
        self.initiate_withdrawal = async_to_streamed_response_wrapper(
            transfers.initiate_withdrawal,
        )
