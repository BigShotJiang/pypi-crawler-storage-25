# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List
from typing_extensions import Literal

import httpx

from ..types import webhook_list_params, webhook_create_params, webhook_update_params, webhook_rotate_secret_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.webhook_get_response import WebhookGetResponse
from ..types.webhook_list_response import WebhookListResponse
from ..types.webhook_create_response import WebhookCreateResponse
from ..types.webhook_remove_response import WebhookRemoveResponse
from ..types.webhook_update_response import WebhookUpdateResponse
from ..types.webhook_rotate_secret_response import WebhookRotateSecretResponse

__all__ = ["WebhooksResource", "AsyncWebhooksResource"]


class WebhooksResource(SyncAPIResource):
    """Webhook endpoint management"""

    @cached_property
    def with_raw_response(self) -> WebhooksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return WebhooksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WebhooksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return WebhooksResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        enabled_events: List[
            Literal[
                "*",
                "party.updated",
                "party.delegation_granted",
                "wallet.created",
                "external_account.connected",
                "agent_delegation_invitation.created",
                "agent_delegation_invitation.accepted",
                "agent_delegation_invitation.declined",
                "agent_delegation_invitation.cancelled",
                "agent_delegation.revoked",
                "delegation.activated",
                "delegation.revoked",
                "deposit.created",
                "deposit.completed",
                "deposit.failed",
                "deposit.returned",
                "withdrawal.created",
                "withdrawal.completed",
                "withdrawal.failed",
                "withdrawal.returned",
                "payment.created",
                "payment.completed",
                "payment.failed",
                "payment_request.created",
                "payment_request.completed",
                "payment_request.failed",
                "payment_request.returned",
                "payment_request.incoming",
            ]
        ],
        url: str,
        idempotency_key: str,
        description: str | Omit = omit,
        tags: Dict[str, str] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookCreateResponse:
        """Create a new webhook endpoint.

        The signing secret is returned only once.

        Args:
          enabled_events: Event types to subscribe to

          url: Webhook endpoint URL

          description: Human-readable description

          tags: Custom metadata tags

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/webhooks",
            body=maybe_transform(
                {
                    "enabled_events": enabled_events,
                    "url": url,
                    "description": description,
                    "tags": tags,
                },
                webhook_create_params.WebhookCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookCreateResponse,
        )

    def update(
        self,
        webhook_id: str,
        *,
        idempotency_key: str,
        description: str | Omit = omit,
        enabled_events: List[
            Literal[
                "*",
                "party.updated",
                "party.delegation_granted",
                "wallet.created",
                "external_account.connected",
                "agent_delegation_invitation.created",
                "agent_delegation_invitation.accepted",
                "agent_delegation_invitation.declined",
                "agent_delegation_invitation.cancelled",
                "agent_delegation.revoked",
                "delegation.activated",
                "delegation.revoked",
                "deposit.created",
                "deposit.completed",
                "deposit.failed",
                "deposit.returned",
                "withdrawal.created",
                "withdrawal.completed",
                "withdrawal.failed",
                "withdrawal.returned",
                "payment.created",
                "payment.completed",
                "payment.failed",
                "payment_request.created",
                "payment_request.completed",
                "payment_request.failed",
                "payment_request.returned",
                "payment_request.incoming",
            ]
        ]
        | Omit = omit,
        status: Literal["ENABLED", "DISABLED"] | Omit = omit,
        tags: Dict[str, str] | Omit = omit,
        url: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookUpdateResponse:
        """
        Partially update a webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          description: New description

          enabled_events: Event types to subscribe to

          status: New status

          tags: Tag updates (set value to empty string to remove key)

          url: New webhook endpoint URL

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._put(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            body=maybe_transform(
                {
                    "description": description,
                    "enabled_events": enabled_events,
                    "status": status,
                    "tags": tags,
                    "url": url,
                },
                webhook_update_params.WebhookUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookUpdateResponse,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        status: Literal["ENABLED", "DISABLED"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookListResponse:
        """
        List webhook endpoints for the authenticated party.

        Args:
          cursor: Cursor for keyset pagination

          limit: Max items per page (1-100)

          status: Filter by status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/webhooks",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "status": status,
                    },
                    webhook_list_params.WebhookListParams,
                ),
            ),
            cast_to=WebhookListResponse,
        )

    def get(
        self,
        webhook_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookGetResponse:
        """
        Get details of a specific webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookGetResponse,
        )

    def remove(
        self,
        webhook_id: str,
        *,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookRemoveResponse:
        """
        Soft-delete a webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._delete(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookRemoveResponse,
        )

    def rotate_secret(
        self,
        webhook_id: str,
        *,
        expires_in_seconds: int,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookRotateSecretResponse:
        """Generate a new signing secret.

        The previous secret remains valid for the
        specified grace period. Requires Idempotency-Key header.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          expires_in_seconds: Grace period in seconds for the previous secret (0 = immediate cutover,
              max 86400)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            path_template("/webhooks/{webhook_id}/rotate-secret", webhook_id=webhook_id),
            body=maybe_transform(
                {"expires_in_seconds": expires_in_seconds}, webhook_rotate_secret_params.WebhookRotateSecretParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookRotateSecretResponse,
        )


class AsyncWebhooksResource(AsyncAPIResource):
    """Webhook endpoint management"""

    @cached_property
    def with_raw_response(self) -> AsyncWebhooksResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWebhooksResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWebhooksResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncWebhooksResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        enabled_events: List[
            Literal[
                "*",
                "party.updated",
                "party.delegation_granted",
                "wallet.created",
                "external_account.connected",
                "agent_delegation_invitation.created",
                "agent_delegation_invitation.accepted",
                "agent_delegation_invitation.declined",
                "agent_delegation_invitation.cancelled",
                "agent_delegation.revoked",
                "delegation.activated",
                "delegation.revoked",
                "deposit.created",
                "deposit.completed",
                "deposit.failed",
                "deposit.returned",
                "withdrawal.created",
                "withdrawal.completed",
                "withdrawal.failed",
                "withdrawal.returned",
                "payment.created",
                "payment.completed",
                "payment.failed",
                "payment_request.created",
                "payment_request.completed",
                "payment_request.failed",
                "payment_request.returned",
                "payment_request.incoming",
            ]
        ],
        url: str,
        idempotency_key: str,
        description: str | Omit = omit,
        tags: Dict[str, str] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookCreateResponse:
        """Create a new webhook endpoint.

        The signing secret is returned only once.

        Args:
          enabled_events: Event types to subscribe to

          url: Webhook endpoint URL

          description: Human-readable description

          tags: Custom metadata tags

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/webhooks",
            body=await async_maybe_transform(
                {
                    "enabled_events": enabled_events,
                    "url": url,
                    "description": description,
                    "tags": tags,
                },
                webhook_create_params.WebhookCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookCreateResponse,
        )

    async def update(
        self,
        webhook_id: str,
        *,
        idempotency_key: str,
        description: str | Omit = omit,
        enabled_events: List[
            Literal[
                "*",
                "party.updated",
                "party.delegation_granted",
                "wallet.created",
                "external_account.connected",
                "agent_delegation_invitation.created",
                "agent_delegation_invitation.accepted",
                "agent_delegation_invitation.declined",
                "agent_delegation_invitation.cancelled",
                "agent_delegation.revoked",
                "delegation.activated",
                "delegation.revoked",
                "deposit.created",
                "deposit.completed",
                "deposit.failed",
                "deposit.returned",
                "withdrawal.created",
                "withdrawal.completed",
                "withdrawal.failed",
                "withdrawal.returned",
                "payment.created",
                "payment.completed",
                "payment.failed",
                "payment_request.created",
                "payment_request.completed",
                "payment_request.failed",
                "payment_request.returned",
                "payment_request.incoming",
            ]
        ]
        | Omit = omit,
        status: Literal["ENABLED", "DISABLED"] | Omit = omit,
        tags: Dict[str, str] | Omit = omit,
        url: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookUpdateResponse:
        """
        Partially update a webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          description: New description

          enabled_events: Event types to subscribe to

          status: New status

          tags: Tag updates (set value to empty string to remove key)

          url: New webhook endpoint URL

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._put(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            body=await async_maybe_transform(
                {
                    "description": description,
                    "enabled_events": enabled_events,
                    "status": status,
                    "tags": tags,
                    "url": url,
                },
                webhook_update_params.WebhookUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookUpdateResponse,
        )

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        status: Literal["ENABLED", "DISABLED"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookListResponse:
        """
        List webhook endpoints for the authenticated party.

        Args:
          cursor: Cursor for keyset pagination

          limit: Max items per page (1-100)

          status: Filter by status

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/webhooks",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "status": status,
                    },
                    webhook_list_params.WebhookListParams,
                ),
            ),
            cast_to=WebhookListResponse,
        )

    async def get(
        self,
        webhook_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookGetResponse:
        """
        Get details of a specific webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookGetResponse,
        )

    async def remove(
        self,
        webhook_id: str,
        *,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookRemoveResponse:
        """
        Soft-delete a webhook endpoint.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._delete(
            path_template("/webhooks/{webhook_id}", webhook_id=webhook_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookRemoveResponse,
        )

    async def rotate_secret(
        self,
        webhook_id: str,
        *,
        expires_in_seconds: int,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WebhookRotateSecretResponse:
        """Generate a new signing secret.

        The previous secret remains valid for the
        specified grace period. Requires Idempotency-Key header.

        Args:
          webhook_id: Webhook ID (whk_xxx)

          expires_in_seconds: Grace period in seconds for the previous secret (0 = immediate cutover,
              max 86400)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not webhook_id:
            raise ValueError(f"Expected a non-empty value for `webhook_id` but received {webhook_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            path_template("/webhooks/{webhook_id}/rotate-secret", webhook_id=webhook_id),
            body=await async_maybe_transform(
                {"expires_in_seconds": expires_in_seconds}, webhook_rotate_secret_params.WebhookRotateSecretParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WebhookRotateSecretResponse,
        )


class WebhooksResourceWithRawResponse:
    def __init__(self, webhooks: WebhooksResource) -> None:
        self._webhooks = webhooks

        self.create = to_raw_response_wrapper(
            webhooks.create,
        )
        self.update = to_raw_response_wrapper(
            webhooks.update,
        )
        self.list = to_raw_response_wrapper(
            webhooks.list,
        )
        self.get = to_raw_response_wrapper(
            webhooks.get,
        )
        self.remove = to_raw_response_wrapper(
            webhooks.remove,
        )
        self.rotate_secret = to_raw_response_wrapper(
            webhooks.rotate_secret,
        )


class AsyncWebhooksResourceWithRawResponse:
    def __init__(self, webhooks: AsyncWebhooksResource) -> None:
        self._webhooks = webhooks

        self.create = async_to_raw_response_wrapper(
            webhooks.create,
        )
        self.update = async_to_raw_response_wrapper(
            webhooks.update,
        )
        self.list = async_to_raw_response_wrapper(
            webhooks.list,
        )
        self.get = async_to_raw_response_wrapper(
            webhooks.get,
        )
        self.remove = async_to_raw_response_wrapper(
            webhooks.remove,
        )
        self.rotate_secret = async_to_raw_response_wrapper(
            webhooks.rotate_secret,
        )


class WebhooksResourceWithStreamingResponse:
    def __init__(self, webhooks: WebhooksResource) -> None:
        self._webhooks = webhooks

        self.create = to_streamed_response_wrapper(
            webhooks.create,
        )
        self.update = to_streamed_response_wrapper(
            webhooks.update,
        )
        self.list = to_streamed_response_wrapper(
            webhooks.list,
        )
        self.get = to_streamed_response_wrapper(
            webhooks.get,
        )
        self.remove = to_streamed_response_wrapper(
            webhooks.remove,
        )
        self.rotate_secret = to_streamed_response_wrapper(
            webhooks.rotate_secret,
        )


class AsyncWebhooksResourceWithStreamingResponse:
    def __init__(self, webhooks: AsyncWebhooksResource) -> None:
        self._webhooks = webhooks

        self.create = async_to_streamed_response_wrapper(
            webhooks.create,
        )
        self.update = async_to_streamed_response_wrapper(
            webhooks.update,
        )
        self.list = async_to_streamed_response_wrapper(
            webhooks.list,
        )
        self.get = async_to_streamed_response_wrapper(
            webhooks.get,
        )
        self.remove = async_to_streamed_response_wrapper(
            webhooks.remove,
        )
        self.rotate_secret = async_to_streamed_response_wrapper(
            webhooks.rotate_secret,
        )
