# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import transaction_get_params, transaction_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.transaction_get_response import TransactionGetResponse
from ..types.transaction_list_response import TransactionListResponse

__all__ = ["TransactionsResource", "AsyncTransactionsResource"]


class TransactionsResource(SyncAPIResource):
    """Transaction activity and history operations"""

    @cached_property
    def with_raw_response(self) -> TransactionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return TransactionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TransactionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return TransactionsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        type: Literal["payment", "transfer", "all"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionListResponse:
        """
        List transactions visible to your party.

        Args:
          cursor: Pagination cursor from previous response

          limit: Results per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/transactions",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "type": type,
                    },
                    transaction_list_params.TransactionListParams,
                ),
            ),
            cast_to=TransactionListResponse,
        )

    def get(
        self,
        transaction_id: str,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionGetResponse:
        """
        Get a single transaction visible to your party.

        Args:
          transaction_id: Transaction handle (txn_xxx)

          party_id: Party ID for delegated transaction lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not transaction_id:
            raise ValueError(f"Expected a non-empty value for `transaction_id` but received {transaction_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/transactions/{transaction_id}", transaction_id=transaction_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"party_id": party_id}, transaction_get_params.TransactionGetParams),
            ),
            cast_to=TransactionGetResponse,
        )


class AsyncTransactionsResource(AsyncAPIResource):
    """Transaction activity and history operations"""

    @cached_property
    def with_raw_response(self) -> AsyncTransactionsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncTransactionsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTransactionsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncTransactionsResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        type: Literal["payment", "transfer", "all"] | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionListResponse:
        """
        List transactions visible to your party.

        Args:
          cursor: Pagination cursor from previous response

          limit: Results per page

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/transactions",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                        "type": type,
                    },
                    transaction_list_params.TransactionListParams,
                ),
            ),
            cast_to=TransactionListResponse,
        )

    async def get(
        self,
        transaction_id: str,
        *,
        party_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionGetResponse:
        """
        Get a single transaction visible to your party.

        Args:
          transaction_id: Transaction handle (txn_xxx)

          party_id: Party ID for delegated transaction lookup

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not transaction_id:
            raise ValueError(f"Expected a non-empty value for `transaction_id` but received {transaction_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/transactions/{transaction_id}", transaction_id=transaction_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform({"party_id": party_id}, transaction_get_params.TransactionGetParams),
            ),
            cast_to=TransactionGetResponse,
        )


class TransactionsResourceWithRawResponse:
    def __init__(self, transactions: TransactionsResource) -> None:
        self._transactions = transactions

        self.list = to_raw_response_wrapper(
            transactions.list,
        )
        self.get = to_raw_response_wrapper(
            transactions.get,
        )


class AsyncTransactionsResourceWithRawResponse:
    def __init__(self, transactions: AsyncTransactionsResource) -> None:
        self._transactions = transactions

        self.list = async_to_raw_response_wrapper(
            transactions.list,
        )
        self.get = async_to_raw_response_wrapper(
            transactions.get,
        )


class TransactionsResourceWithStreamingResponse:
    def __init__(self, transactions: TransactionsResource) -> None:
        self._transactions = transactions

        self.list = to_streamed_response_wrapper(
            transactions.list,
        )
        self.get = to_streamed_response_wrapper(
            transactions.get,
        )


class AsyncTransactionsResourceWithStreamingResponse:
    def __init__(self, transactions: AsyncTransactionsResource) -> None:
        self._transactions = transactions

        self.list = async_to_streamed_response_wrapper(
            transactions.list,
        )
        self.get = async_to_streamed_response_wrapper(
            transactions.get,
        )
