# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import external_account_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.external_account_list_response import ExternalAccountListResponse
from ..types.external_account_remove_response import ExternalAccountRemoveResponse

__all__ = ["ExternalAccountsResource", "AsyncExternalAccountsResource"]


class ExternalAccountsResource(SyncAPIResource):
    """Linked external bank accounts"""

    @cached_property
    def with_raw_response(self) -> ExternalAccountsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return ExternalAccountsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ExternalAccountsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return ExternalAccountsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExternalAccountListResponse:
        """
        List linked external accounts with cursor pagination.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/external-accounts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    external_account_list_params.ExternalAccountListParams,
                ),
            ),
            cast_to=ExternalAccountListResponse,
        )

    def remove(
        self,
        external_account_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExternalAccountRemoveResponse:
        """
        Remove (unlink) a bank account.

        Args:
          external_account_id: External account ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_account_id:
            raise ValueError(
                f"Expected a non-empty value for `external_account_id` but received {external_account_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._delete(
            path_template("/external-accounts/{external_account_id}", external_account_id=external_account_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExternalAccountRemoveResponse,
        )


class AsyncExternalAccountsResource(AsyncAPIResource):
    """Linked external bank accounts"""

    @cached_property
    def with_raw_response(self) -> AsyncExternalAccountsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncExternalAccountsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncExternalAccountsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncExternalAccountsResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExternalAccountListResponse:
        """
        List linked external accounts with cursor pagination.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/external-accounts",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    external_account_list_params.ExternalAccountListParams,
                ),
            ),
            cast_to=ExternalAccountListResponse,
        )

    async def remove(
        self,
        external_account_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ExternalAccountRemoveResponse:
        """
        Remove (unlink) a bank account.

        Args:
          external_account_id: External account ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not external_account_id:
            raise ValueError(
                f"Expected a non-empty value for `external_account_id` but received {external_account_id!r}"
            )
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._delete(
            path_template("/external-accounts/{external_account_id}", external_account_id=external_account_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ExternalAccountRemoveResponse,
        )


class ExternalAccountsResourceWithRawResponse:
    def __init__(self, external_accounts: ExternalAccountsResource) -> None:
        self._external_accounts = external_accounts

        self.list = to_raw_response_wrapper(
            external_accounts.list,
        )
        self.remove = to_raw_response_wrapper(
            external_accounts.remove,
        )


class AsyncExternalAccountsResourceWithRawResponse:
    def __init__(self, external_accounts: AsyncExternalAccountsResource) -> None:
        self._external_accounts = external_accounts

        self.list = async_to_raw_response_wrapper(
            external_accounts.list,
        )
        self.remove = async_to_raw_response_wrapper(
            external_accounts.remove,
        )


class ExternalAccountsResourceWithStreamingResponse:
    def __init__(self, external_accounts: ExternalAccountsResource) -> None:
        self._external_accounts = external_accounts

        self.list = to_streamed_response_wrapper(
            external_accounts.list,
        )
        self.remove = to_streamed_response_wrapper(
            external_accounts.remove,
        )


class AsyncExternalAccountsResourceWithStreamingResponse:
    def __init__(self, external_accounts: AsyncExternalAccountsResource) -> None:
        self._external_accounts = external_accounts

        self.list = async_to_streamed_response_wrapper(
            external_accounts.list,
        )
        self.remove = async_to_streamed_response_wrapper(
            external_accounts.remove,
        )
