# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    payment_request_list_params,
    payment_request_create_params,
    payment_request_fulfill_params,
    payment_request_list_incoming_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.payment_request_get_response import PaymentRequestGetResponse
from ..types.payment_request_list_response import PaymentRequestListResponse
from ..types.payment_request_create_response import PaymentRequestCreateResponse
from ..types.payment_request_decline_response import PaymentRequestDeclineResponse
from ..types.payment_request_fulfill_response import PaymentRequestFulfillResponse
from ..types.payment_request_list_incoming_response import PaymentRequestListIncomingResponse

__all__ = ["PaymentRequestsResource", "AsyncPaymentRequestsResource"]


class PaymentRequestsResource(SyncAPIResource):
    """Payment-request management"""

    @cached_property
    def with_raw_response(self) -> PaymentRequestsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return PaymentRequestsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaymentRequestsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return PaymentRequestsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        amount: int,
        payer: payment_request_create_params.Payer,
        idempotency_key: str,
        currency: Literal["USD"] | Omit = omit,
        customer_party_id: str | Omit = omit,
        description: str | Omit = omit,
        payer_name: str | Omit = omit,
        send_link: payment_request_create_params.SendLink | Omit = omit,
        wallet_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestCreateResponse:
        """
        Create a payment request and optionally send the link immediately.

        Args:
          amount: Amount in minor units (cents for USD)

          payer: Who pays — exactly one typed email, phone, party ID, or agent ID value.

          currency: Currency code (currently only USD)

          customer_party_id: Requester party ID (pty\\__\\**). Omit to request into your own wallet; provide for
              delegated payment requests on behalf of a customer.

          description: Free-form description shown to the payer. Maximum 500 characters.

          payer_name: Display name of the payer

          send_link: If provided, immediately deliver the payment link to the payer via the named
              channel

          wallet_id: Wallet that should receive the funds. Omit to use the requester party's default
              wallet.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            "/payment-requests",
            body=maybe_transform(
                {
                    "amount": amount,
                    "payer": payer,
                    "currency": currency,
                    "customer_party_id": customer_party_id,
                    "description": description,
                    "payer_name": payer_name,
                    "send_link": send_link,
                    "wallet_id": wallet_id,
                },
                payment_request_create_params.PaymentRequestCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestCreateResponse,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestListResponse:
        """
        List payment requests visible to the authenticated requester party.

        Args:
          cursor: Pagination cursor returned by the previous response

          limit: Results per page (1-100)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/payment-requests",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    payment_request_list_params.PaymentRequestListParams,
                ),
            ),
            cast_to=PaymentRequestListResponse,
        )

    def decline(
        self,
        payment_request_id: str,
        *,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestDeclineResponse:
        """
        Decline an open payment request where the authenticated party is expected to
        pay.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            path_template("/payment-requests/{payment_request_id}/decline", payment_request_id=payment_request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestDeclineResponse,
        )

    def fulfill(
        self,
        payment_request_id: str,
        *,
        payment_source: payment_request_fulfill_params.PaymentSource,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestFulfillResponse:
        """
        Fulfill an open payment request from inside the authenticated app.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._post(
            path_template("/payment-requests/{payment_request_id}/fulfill", payment_request_id=payment_request_id),
            body=maybe_transform(
                {"payment_source": payment_source}, payment_request_fulfill_params.PaymentRequestFulfillParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestFulfillResponse,
        )

    def get(
        self,
        payment_request_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestGetResponse:
        """
        Get a single payment request visible to the authenticated requester party.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            path_template("/payment-requests/{payment_request_id}", payment_request_id=payment_request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestGetResponse,
        )

    def list_incoming(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestListIncomingResponse:
        """
        List open payment requests where the authenticated party is expected to pay.

        Args:
          cursor: Pagination cursor returned by the previous response

          limit: Results per page (1-100)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return self._get(
            "/payment-requests/incoming",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    payment_request_list_incoming_params.PaymentRequestListIncomingParams,
                ),
            ),
            cast_to=PaymentRequestListIncomingResponse,
        )


class AsyncPaymentRequestsResource(AsyncAPIResource):
    """Payment-request management"""

    @cached_property
    def with_raw_response(self) -> AsyncPaymentRequestsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPaymentRequestsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaymentRequestsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/naturalpay/naturalpay-python#with_streaming_response
        """
        return AsyncPaymentRequestsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        amount: int,
        payer: payment_request_create_params.Payer,
        idempotency_key: str,
        currency: Literal["USD"] | Omit = omit,
        customer_party_id: str | Omit = omit,
        description: str | Omit = omit,
        payer_name: str | Omit = omit,
        send_link: payment_request_create_params.SendLink | Omit = omit,
        wallet_id: str | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestCreateResponse:
        """
        Create a payment request and optionally send the link immediately.

        Args:
          amount: Amount in minor units (cents for USD)

          payer: Who pays — exactly one typed email, phone, party ID, or agent ID value.

          currency: Currency code (currently only USD)

          customer_party_id: Requester party ID (pty\\__\\**). Omit to request into your own wallet; provide for
              delegated payment requests on behalf of a customer.

          description: Free-form description shown to the payer. Maximum 500 characters.

          payer_name: Display name of the payer

          send_link: If provided, immediately deliver the payment link to the payer via the named
              channel

          wallet_id: Wallet that should receive the funds. Omit to use the requester party's default
              wallet.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            "/payment-requests",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "payer": payer,
                    "currency": currency,
                    "customer_party_id": customer_party_id,
                    "description": description,
                    "payer_name": payer_name,
                    "send_link": send_link,
                    "wallet_id": wallet_id,
                },
                payment_request_create_params.PaymentRequestCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestCreateResponse,
        )

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestListResponse:
        """
        List payment requests visible to the authenticated requester party.

        Args:
          cursor: Pagination cursor returned by the previous response

          limit: Results per page (1-100)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/payment-requests",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    payment_request_list_params.PaymentRequestListParams,
                ),
            ),
            cast_to=PaymentRequestListResponse,
        )

    async def decline(
        self,
        payment_request_id: str,
        *,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestDeclineResponse:
        """
        Decline an open payment request where the authenticated party is expected to
        pay.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            path_template("/payment-requests/{payment_request_id}/decline", payment_request_id=payment_request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestDeclineResponse,
        )

    async def fulfill(
        self,
        payment_request_id: str,
        *,
        payment_source: payment_request_fulfill_params.PaymentSource,
        idempotency_key: str,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestFulfillResponse:
        """
        Fulfill an open payment request from inside the authenticated app.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "Idempotency-Key": idempotency_key,
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._post(
            path_template("/payment-requests/{payment_request_id}/fulfill", payment_request_id=payment_request_id),
            body=await async_maybe_transform(
                {"payment_source": payment_source}, payment_request_fulfill_params.PaymentRequestFulfillParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestFulfillResponse,
        )

    async def get(
        self,
        payment_request_id: str,
        *,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestGetResponse:
        """
        Get a single payment request visible to the authenticated requester party.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not payment_request_id:
            raise ValueError(f"Expected a non-empty value for `payment_request_id` but received {payment_request_id!r}")
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            path_template("/payment-requests/{payment_request_id}", payment_request_id=payment_request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRequestGetResponse,
        )

    async def list_incoming(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        x_agent_id: str | Omit = omit,
        x_instance_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRequestListIncomingResponse:
        """
        List open payment requests where the authenticated party is expected to pay.

        Args:
          cursor: Pagination cursor returned by the previous response

          limit: Results per page (1-100)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {
            **strip_not_given(
                {
                    "X-Agent-ID": x_agent_id,
                    "X-Instance-ID": x_instance_id,
                }
            ),
            **(extra_headers or {}),
        }
        return await self._get(
            "/payment-requests/incoming",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    payment_request_list_incoming_params.PaymentRequestListIncomingParams,
                ),
            ),
            cast_to=PaymentRequestListIncomingResponse,
        )


class PaymentRequestsResourceWithRawResponse:
    def __init__(self, payment_requests: PaymentRequestsResource) -> None:
        self._payment_requests = payment_requests

        self.create = to_raw_response_wrapper(
            payment_requests.create,
        )
        self.list = to_raw_response_wrapper(
            payment_requests.list,
        )
        self.decline = to_raw_response_wrapper(
            payment_requests.decline,
        )
        self.fulfill = to_raw_response_wrapper(
            payment_requests.fulfill,
        )
        self.get = to_raw_response_wrapper(
            payment_requests.get,
        )
        self.list_incoming = to_raw_response_wrapper(
            payment_requests.list_incoming,
        )


class AsyncPaymentRequestsResourceWithRawResponse:
    def __init__(self, payment_requests: AsyncPaymentRequestsResource) -> None:
        self._payment_requests = payment_requests

        self.create = async_to_raw_response_wrapper(
            payment_requests.create,
        )
        self.list = async_to_raw_response_wrapper(
            payment_requests.list,
        )
        self.decline = async_to_raw_response_wrapper(
            payment_requests.decline,
        )
        self.fulfill = async_to_raw_response_wrapper(
            payment_requests.fulfill,
        )
        self.get = async_to_raw_response_wrapper(
            payment_requests.get,
        )
        self.list_incoming = async_to_raw_response_wrapper(
            payment_requests.list_incoming,
        )


class PaymentRequestsResourceWithStreamingResponse:
    def __init__(self, payment_requests: PaymentRequestsResource) -> None:
        self._payment_requests = payment_requests

        self.create = to_streamed_response_wrapper(
            payment_requests.create,
        )
        self.list = to_streamed_response_wrapper(
            payment_requests.list,
        )
        self.decline = to_streamed_response_wrapper(
            payment_requests.decline,
        )
        self.fulfill = to_streamed_response_wrapper(
            payment_requests.fulfill,
        )
        self.get = to_streamed_response_wrapper(
            payment_requests.get,
        )
        self.list_incoming = to_streamed_response_wrapper(
            payment_requests.list_incoming,
        )


class AsyncPaymentRequestsResourceWithStreamingResponse:
    def __init__(self, payment_requests: AsyncPaymentRequestsResource) -> None:
        self._payment_requests = payment_requests

        self.create = async_to_streamed_response_wrapper(
            payment_requests.create,
        )
        self.list = async_to_streamed_response_wrapper(
            payment_requests.list,
        )
        self.decline = async_to_streamed_response_wrapper(
            payment_requests.decline,
        )
        self.fulfill = async_to_streamed_response_wrapper(
            payment_requests.fulfill,
        )
        self.get = async_to_streamed_response_wrapper(
            payment_requests.get,
        )
        self.list_incoming = async_to_streamed_response_wrapper(
            payment_requests.list_incoming,
        )
