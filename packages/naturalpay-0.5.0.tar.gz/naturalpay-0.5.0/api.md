# Agents

Types:

```python
from naturalpay.types import (
    AgentCreateResponse,
    AgentUpdateResponse,
    AgentListResponse,
    AgentCreateCustomerResponse,
    AgentGetResponse,
    AgentGetCustomerResponse,
    AgentListCustomersResponse,
    AgentRemoveResponse,
    AgentRemoveCustomerResponse,
)
```

Methods:

- <code title="post /agents">client.agents.<a href="./src/naturalpay/resources/agents.py">create</a>(\*\*<a href="src/naturalpay/types/agent_create_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_create_response.py">AgentCreateResponse</a></code>
- <code title="patch /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">update</a>(agent_id, \*\*<a href="src/naturalpay/types/agent_update_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_update_response.py">AgentUpdateResponse</a></code>
- <code title="get /agents">client.agents.<a href="./src/naturalpay/resources/agents.py">list</a>(\*\*<a href="src/naturalpay/types/agent_list_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_list_response.py">AgentListResponse</a></code>
- <code title="post /agents/{agentId}/customers">client.agents.<a href="./src/naturalpay/resources/agents.py">create_customer</a>(agent_id, \*\*<a href="src/naturalpay/types/agent_create_customer_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_create_customer_response.py">AgentCreateCustomerResponse</a></code>
- <code title="get /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">get</a>(agent_id) -> <a href="./src/naturalpay/types/agent_get_response.py">AgentGetResponse</a></code>
- <code title="get /agents/{agentId}/customers/{customerId}">client.agents.<a href="./src/naturalpay/resources/agents.py">get_customer</a>(customer_id, \*, agent_id) -> <a href="./src/naturalpay/types/agent_get_customer_response.py">AgentGetCustomerResponse</a></code>
- <code title="get /agents/{agentId}/customers">client.agents.<a href="./src/naturalpay/resources/agents.py">list_customers</a>(agent_id, \*\*<a href="src/naturalpay/types/agent_list_customers_params.py">params</a>) -> <a href="./src/naturalpay/types/agent_list_customers_response.py">AgentListCustomersResponse</a></code>
- <code title="delete /agents/{agentId}">client.agents.<a href="./src/naturalpay/resources/agents.py">remove</a>(agent_id) -> <a href="./src/naturalpay/types/agent_remove_response.py">AgentRemoveResponse</a></code>
- <code title="delete /agents/{agentId}/customers/{customerId}">client.agents.<a href="./src/naturalpay/resources/agents.py">remove_customer</a>(customer_id, \*, agent_id) -> <a href="./src/naturalpay/types/agent_remove_customer_response.py">AgentRemoveCustomerResponse</a></code>

# APIKeys

Types:

```python
from naturalpay.types import (
    APIKeyCreateResponse,
    APIKeyListResponse,
    APIKeyGetResponse,
    APIKeyRevokeResponse,
)
```

Methods:

- <code title="post /api-keys">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">create</a>(\*\*<a href="src/naturalpay/types/api_key_create_params.py">params</a>) -> <a href="./src/naturalpay/types/api_key_create_response.py">APIKeyCreateResponse</a></code>
- <code title="get /api-keys">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">list</a>(\*\*<a href="src/naturalpay/types/api_key_list_params.py">params</a>) -> <a href="./src/naturalpay/types/api_key_list_response.py">APIKeyListResponse</a></code>
- <code title="get /api-keys/{keyId}">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">get</a>(key_id) -> <a href="./src/naturalpay/types/api_key_get_response.py">APIKeyGetResponse</a></code>
- <code title="delete /api-keys/{keyId}">client.api_keys.<a href="./src/naturalpay/resources/api_keys.py">revoke</a>(key_id) -> <a href="./src/naturalpay/types/api_key_revoke_response.py">APIKeyRevokeResponse</a></code>

# Counterparties

Types:

```python
from naturalpay.types import CounterpartyListResponse
```

Methods:

- <code title="get /counterparties">client.counterparties.<a href="./src/naturalpay/resources/counterparties.py">list</a>(\*\*<a href="src/naturalpay/types/counterparty_list_params.py">params</a>) -> <a href="./src/naturalpay/types/counterparty_list_response.py">CounterpartyListResponse</a></code>

# Customers

Types:

```python
from naturalpay.types import CustomerListResponse, CustomerGetResponse
```

Methods:

- <code title="get /customers">client.customers.<a href="./src/naturalpay/resources/customers.py">list</a>(\*\*<a href="src/naturalpay/types/customer_list_params.py">params</a>) -> <a href="./src/naturalpay/types/customer_list_response.py">CustomerListResponse</a></code>
- <code title="get /customers/{customerId}">client.customers.<a href="./src/naturalpay/resources/customers.py">get</a>(customer_id) -> <a href="./src/naturalpay/types/customer_get_response.py">CustomerGetResponse</a></code>

# Invitations

Types:

```python
from naturalpay.types import (
    InvitationCreateResponse,
    InvitationListResponse,
    InvitationRevokeResponse,
)
```

Methods:

- <code title="post /party-invitations">client.invitations.<a href="./src/naturalpay/resources/invitations.py">create</a>(\*\*<a href="src/naturalpay/types/invitation_create_params.py">params</a>) -> <a href="./src/naturalpay/types/invitation_create_response.py">InvitationCreateResponse</a></code>
- <code title="get /party-invitations">client.invitations.<a href="./src/naturalpay/resources/invitations.py">list</a>(\*\*<a href="src/naturalpay/types/invitation_list_params.py">params</a>) -> <a href="./src/naturalpay/types/invitation_list_response.py">InvitationListResponse</a></code>
- <code title="delete /party-invitations/{invitationId}">client.invitations.<a href="./src/naturalpay/resources/invitations.py">revoke</a>(invitation_id) -> <a href="./src/naturalpay/types/invitation_revoke_response.py">InvitationRevokeResponse</a></code>

# Parties

Types:

```python
from naturalpay.types import (
    PartyUpdateResponse,
    PartyGetResponse,
    PartyListMembersResponse,
    PartyRemoveMemberResponse,
)
```

Methods:

- <code title="patch /parties/me">client.parties.<a href="./src/naturalpay/resources/parties.py">update</a>(\*\*<a href="src/naturalpay/types/party_update_params.py">params</a>) -> <a href="./src/naturalpay/types/party_update_response.py">PartyUpdateResponse</a></code>
- <code title="get /parties/me">client.parties.<a href="./src/naturalpay/resources/parties.py">get</a>() -> <a href="./src/naturalpay/types/party_get_response.py">PartyGetResponse</a></code>
- <code title="get /parties/me/members">client.parties.<a href="./src/naturalpay/resources/parties.py">list_members</a>(\*\*<a href="src/naturalpay/types/party_list_members_params.py">params</a>) -> <a href="./src/naturalpay/types/party_list_members_response.py">PartyListMembersResponse</a></code>
- <code title="delete /parties/me/members/{userId}">client.parties.<a href="./src/naturalpay/resources/parties.py">remove_member</a>(user_id) -> <a href="./src/naturalpay/types/party_remove_member_response.py">PartyRemoveMemberResponse</a></code>

# PaymentRequests

Types:

```python
from naturalpay.types import (
    PaymentRequestCreateResponse,
    PaymentRequestListResponse,
    PaymentRequestDeclineResponse,
    PaymentRequestFulfillResponse,
    PaymentRequestGetResponse,
    PaymentRequestListIncomingResponse,
)
```

Methods:

- <code title="post /payment-requests">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">create</a>(\*\*<a href="src/naturalpay/types/payment_request_create_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_create_response.py">PaymentRequestCreateResponse</a></code>
- <code title="get /payment-requests">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">list</a>(\*\*<a href="src/naturalpay/types/payment_request_list_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_list_response.py">PaymentRequestListResponse</a></code>
- <code title="post /payment-requests/{paymentRequestId}/decline">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">decline</a>(payment_request_id) -> <a href="./src/naturalpay/types/payment_request_decline_response.py">PaymentRequestDeclineResponse</a></code>
- <code title="post /payment-requests/{paymentRequestId}/fulfill">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">fulfill</a>(payment_request_id, \*\*<a href="src/naturalpay/types/payment_request_fulfill_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_fulfill_response.py">PaymentRequestFulfillResponse</a></code>
- <code title="get /payment-requests/{paymentRequestId}">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">get</a>(payment_request_id) -> <a href="./src/naturalpay/types/payment_request_get_response.py">PaymentRequestGetResponse</a></code>
- <code title="get /payment-requests/incoming">client.payment_requests.<a href="./src/naturalpay/resources/payment_requests.py">list_incoming</a>(\*\*<a href="src/naturalpay/types/payment_request_list_incoming_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_request_list_incoming_response.py">PaymentRequestListIncomingResponse</a></code>

# Payments

Types:

```python
from naturalpay.types import PaymentCreateResponse, PaymentListResponse, PaymentGetResponse
```

Methods:

- <code title="post /payments">client.payments.<a href="./src/naturalpay/resources/payments.py">create</a>(\*\*<a href="src/naturalpay/types/payment_create_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_create_response.py">PaymentCreateResponse</a></code>
- <code title="get /payments">client.payments.<a href="./src/naturalpay/resources/payments.py">list</a>(\*\*<a href="src/naturalpay/types/payment_list_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_list_response.py">PaymentListResponse</a></code>
- <code title="get /payments/{paymentId}">client.payments.<a href="./src/naturalpay/resources/payments.py">get</a>(payment_id, \*\*<a href="src/naturalpay/types/payment_get_params.py">params</a>) -> <a href="./src/naturalpay/types/payment_get_response.py">PaymentGetResponse</a></code>

# Transactions

Types:

```python
from naturalpay.types import TransactionListResponse, TransactionGetResponse
```

Methods:

- <code title="get /transactions">client.transactions.<a href="./src/naturalpay/resources/transactions.py">list</a>(\*\*<a href="src/naturalpay/types/transaction_list_params.py">params</a>) -> <a href="./src/naturalpay/types/transaction_list_response.py">TransactionListResponse</a></code>
- <code title="get /transactions/{transactionId}">client.transactions.<a href="./src/naturalpay/resources/transactions.py">get</a>(transaction_id, \*\*<a href="src/naturalpay/types/transaction_get_params.py">params</a>) -> <a href="./src/naturalpay/types/transaction_get_response.py">TransactionGetResponse</a></code>

# Transfers

Types:

```python
from naturalpay.types import (
    TransferListResponse,
    TransferGetResponse,
    TransferInitiateDepositResponse,
    TransferInitiateWithdrawalResponse,
)
```

Methods:

- <code title="get /transfers">client.transfers.<a href="./src/naturalpay/resources/transfers.py">list</a>(\*\*<a href="src/naturalpay/types/transfer_list_params.py">params</a>) -> <a href="./src/naturalpay/types/transfer_list_response.py">TransferListResponse</a></code>
- <code title="get /transfers/{transferId}">client.transfers.<a href="./src/naturalpay/resources/transfers.py">get</a>(transfer_id, \*\*<a href="src/naturalpay/types/transfer_get_params.py">params</a>) -> <a href="./src/naturalpay/types/transfer_get_response.py">TransferGetResponse</a></code>
- <code title="post /transfers/deposit">client.transfers.<a href="./src/naturalpay/resources/transfers.py">initiate_deposit</a>(\*\*<a href="src/naturalpay/types/transfer_initiate_deposit_params.py">params</a>) -> <a href="./src/naturalpay/types/transfer_initiate_deposit_response.py">TransferInitiateDepositResponse</a></code>
- <code title="post /transfers/withdraw">client.transfers.<a href="./src/naturalpay/resources/transfers.py">initiate_withdrawal</a>(\*\*<a href="src/naturalpay/types/transfer_initiate_withdrawal_params.py">params</a>) -> <a href="./src/naturalpay/types/transfer_initiate_withdrawal_response.py">TransferInitiateWithdrawalResponse</a></code>

# Webhooks

Types:

```python
from naturalpay.types import (
    WebhookCreateResponse,
    WebhookUpdateResponse,
    WebhookListResponse,
    WebhookGetResponse,
    WebhookRemoveResponse,
    WebhookRotateSecretResponse,
)
```

Methods:

- <code title="post /webhooks">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">create</a>(\*\*<a href="src/naturalpay/types/webhook_create_params.py">params</a>) -> <a href="./src/naturalpay/types/webhook_create_response.py">WebhookCreateResponse</a></code>
- <code title="put /webhooks/{webhookId}">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">update</a>(webhook_id, \*\*<a href="src/naturalpay/types/webhook_update_params.py">params</a>) -> <a href="./src/naturalpay/types/webhook_update_response.py">WebhookUpdateResponse</a></code>
- <code title="get /webhooks">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">list</a>(\*\*<a href="src/naturalpay/types/webhook_list_params.py">params</a>) -> <a href="./src/naturalpay/types/webhook_list_response.py">WebhookListResponse</a></code>
- <code title="get /webhooks/{webhookId}">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">get</a>(webhook_id) -> <a href="./src/naturalpay/types/webhook_get_response.py">WebhookGetResponse</a></code>
- <code title="delete /webhooks/{webhookId}">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">remove</a>(webhook_id) -> <a href="./src/naturalpay/types/webhook_remove_response.py">WebhookRemoveResponse</a></code>
- <code title="post /webhooks/{webhookId}/rotate-secret">client.webhooks.<a href="./src/naturalpay/resources/webhooks.py">rotate_secret</a>(webhook_id, \*\*<a href="src/naturalpay/types/webhook_rotate_secret_params.py">params</a>) -> <a href="./src/naturalpay/types/webhook_rotate_secret_response.py">WebhookRotateSecretResponse</a></code>

# Wallet

Types:

```python
from naturalpay.types import WalletListResponse, WalletGetResponse
```

Methods:

- <code title="get /wallets">client.wallet.<a href="./src/naturalpay/resources/wallet.py">list</a>() -> <a href="./src/naturalpay/types/wallet_list_response.py">WalletListResponse</a></code>
- <code title="get /wallets/{walletId}">client.wallet.<a href="./src/naturalpay/resources/wallet.py">get</a>(wallet_id) -> <a href="./src/naturalpay/types/wallet_get_response.py">WalletGetResponse</a></code>

# ExternalAccounts

Types:

```python
from naturalpay.types import ExternalAccountListResponse, ExternalAccountRemoveResponse
```

Methods:

- <code title="get /external-accounts">client.external_accounts.<a href="./src/naturalpay/resources/external_accounts.py">list</a>(\*\*<a href="src/naturalpay/types/external_account_list_params.py">params</a>) -> <a href="./src/naturalpay/types/external_account_list_response.py">ExternalAccountListResponse</a></code>
- <code title="delete /external-accounts/{externalAccountId}">client.external_accounts.<a href="./src/naturalpay/resources/external_accounts.py">remove</a>(external_account_id) -> <a href="./src/naturalpay/types/external_account_remove_response.py">ExternalAccountRemoveResponse</a></code>
