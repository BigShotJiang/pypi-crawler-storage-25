# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import (
    TransferGetResponse,
    TransferListResponse,
    TransferInitiateDepositResponse,
    TransferInitiateWithdrawalResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTransfers:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Natural) -> None:
        transfer = client.transfers.list()
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Natural) -> None:
        transfer = client.transfers.list(
            cursor="cursor",
            limit=1,
            party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Natural) -> None:
        response = client.transfers.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = response.parse()
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Natural) -> None:
        with client.transfers.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = response.parse()
            assert_matches_type(TransferListResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get(self, client: Natural) -> None:
        transfer = client.transfers.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_with_all_params(self, client: Natural) -> None:
        transfer = client.transfers.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
            party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: Natural) -> None:
        response = client.transfers.with_raw_response.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = response.parse()
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: Natural) -> None:
        with client.transfers.with_streaming_response.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = response.parse()
            assert_matches_type(TransferGetResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_get(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `transfer_id` but received ''"):
            client.transfers.with_raw_response.get(
                transfer_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_deposit(self, client: Natural) -> None:
        transfer = client.transfers.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_deposit_with_all_params(self, client: Natural) -> None:
        transfer = client.transfers.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_initiate_deposit(self, client: Natural) -> None:
        response = client.transfers.with_raw_response.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = response.parse()
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_initiate_deposit(self, client: Natural) -> None:
        with client.transfers.with_streaming_response.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = response.parse()
            assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_withdrawal(self, client: Natural) -> None:
        transfer = client.transfers.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_initiate_withdrawal_with_all_params(self, client: Natural) -> None:
        transfer = client.transfers.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_initiate_withdrawal(self, client: Natural) -> None:
        response = client.transfers.with_raw_response.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = response.parse()
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_initiate_withdrawal(self, client: Natural) -> None:
        with client.transfers.with_streaming_response.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = response.parse()
            assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncTransfers:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.list()
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.list(
            cursor="cursor",
            limit=1,
            party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNatural) -> None:
        response = await async_client.transfers.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = await response.parse()
        assert_matches_type(TransferListResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNatural) -> None:
        async with async_client.transfers.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = await response.parse()
            assert_matches_type(TransferListResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_with_all_params(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
            party_id="pty_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncNatural) -> None:
        response = await async_client.transfers.with_raw_response.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = await response.parse()
        assert_matches_type(TransferGetResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncNatural) -> None:
        async with async_client.transfers.with_streaming_response.get(
            transfer_id="trf_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = await response.parse()
            assert_matches_type(TransferGetResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_get(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `transfer_id` but received ''"):
            await async_client.transfers.with_raw_response.get(
                transfer_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_deposit(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_deposit_with_all_params(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_initiate_deposit(self, async_client: AsyncNatural) -> None:
        response = await async_client.transfers.with_raw_response.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = await response.parse()
        assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_initiate_deposit(self, async_client: AsyncNatural) -> None:
        async with async_client.transfers.with_streaming_response.initiate_deposit(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = await response.parse()
            assert_matches_type(TransferInitiateDepositResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_initiate_withdrawal_with_all_params(self, async_client: AsyncNatural) -> None:
        transfer = await async_client.transfers.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
            currency="currency",
            description="description",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        response = await async_client.transfers.with_raw_response.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        transfer = await response.parse()
        assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_initiate_withdrawal(self, async_client: AsyncNatural) -> None:
        async with async_client.transfers.with_streaming_response.initiate_withdrawal(
            amount=1,
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            idempotency_key="Idempotency-Key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            transfer = await response.parse()
            assert_matches_type(TransferInitiateWithdrawalResponse, transfer, path=["response"])

        assert cast(Any, response.is_closed) is True
