# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from naturalpay import Natural, AsyncNatural
from tests.utils import assert_matches_type
from naturalpay.types import ExternalAccountListResponse, ExternalAccountRemoveResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestExternalAccounts:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Natural) -> None:
        external_account = client.external_accounts.list()
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Natural) -> None:
        external_account = client.external_accounts.list(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Natural) -> None:
        response = client.external_accounts.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        external_account = response.parse()
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Natural) -> None:
        with client.external_accounts.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            external_account = response.parse()
            assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove(self, client: Natural) -> None:
        external_account = client.external_accounts.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_remove_with_all_params(self, client: Natural) -> None:
        external_account = client.external_accounts.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_remove(self, client: Natural) -> None:
        response = client.external_accounts.with_raw_response.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        external_account = response.parse()
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_remove(self, client: Natural) -> None:
        with client.external_accounts.with_streaming_response.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            external_account = response.parse()
            assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_remove(self, client: Natural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `external_account_id` but received ''"):
            client.external_accounts.with_raw_response.remove(
                external_account_id="",
            )


class TestAsyncExternalAccounts:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncNatural) -> None:
        external_account = await async_client.external_accounts.list()
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncNatural) -> None:
        external_account = await async_client.external_accounts.list(
            cursor="cursor",
            limit=1,
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncNatural) -> None:
        response = await async_client.external_accounts.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        external_account = await response.parse()
        assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncNatural) -> None:
        async with async_client.external_accounts.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            external_account = await response.parse()
            assert_matches_type(ExternalAccountListResponse, external_account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove(self, async_client: AsyncNatural) -> None:
        external_account = await async_client.external_accounts.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_remove_with_all_params(self, async_client: AsyncNatural) -> None:
        external_account = await async_client.external_accounts.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
            x_agent_id="X-Agent-ID",
            x_instance_id="X-Instance-ID",
        )
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_remove(self, async_client: AsyncNatural) -> None:
        response = await async_client.external_accounts.with_raw_response.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        external_account = await response.parse()
        assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_remove(self, async_client: AsyncNatural) -> None:
        async with async_client.external_accounts.with_streaming_response.remove(
            external_account_id="eac_ecc2efdd09bd231a9ad9bd2aada37aa7",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            external_account = await response.parse()
            assert_matches_type(ExternalAccountRemoveResponse, external_account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_remove(self, async_client: AsyncNatural) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `external_account_id` but received ''"):
            await async_client.external_accounts.with_raw_response.remove(
                external_account_id="",
            )
