"""
Abstract base class for all solvers.

.. autosummary::

    ~SolverBase
"""

import logging
from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import List
from typing import Optional
from typing import Union

from deprecated.sphinx import versionadded

from pyRestTable import Table

from ..utils import IDENTITY_MATRIX_3X3
from ..utils import INTERNAL_ANGLE_UNITS
from ..utils import INTERNAL_LENGTH_UNITS
from ..utils import istype
from ..utils import validate_and_canonical_unit
from ..typing import KeyValueMap
from ..typing import Matrix3x3
from ..typing import NamedFloatDict
from .typing import GeometryDescriptor
from .typing import ReflectionDict
from .typing import SampleDict
from .typing import SolverMetadataDict

logger = logging.getLogger(__name__)


class SolverBase(ABC):
    """
    Base class for all |hklpy2| |solver| classes.

    PARAMETERS

    geometry : str
        Name of geometry.
    mode: str
        Name of operating mode.  (default: current mode)

    Example::

        import hklpy2

        class MySolver(hklpy2.SolverBase):
            ...

    .. note:: :class:`~SolverBase`, an `abstract base
        class <https://docs.python.org/3/library/abc.html#abc.ABC>`_,
        cannot not be used directly by |hklpy2| users.

    As the parent class for all custom :index:`Solver` classes,
    :class:`~SolverBase` defines the methods and attributes to be written
    that will connect |hklpy2| with the support library that defines
    specific diffractometer geometries and the computations for
    using them.  Subclasses should implement each of these methods
    as best fits the underlying support library.

    .. seealso:: :mod:`~hklpy2.backends.hkl_soleil` & :mod:`~hklpy2.backends.no_op`

    .. rubric:: Python Abstract Methods

    Subclasses must override each of these methods.

    .. autosummary::

        ~addReflection
        ~calculate_UB
        ~extra_axis_names
        ~forward
        ~geometries
        ~inverse
        ~modes
        ~pseudo_axis_names
        ~real_axis_names
        ~refineLattice
        ~removeAllReflections

    .. rubric:: Python Methods (concrete, overridable)

    .. autosummary::

        ~set_reals

    .. rubric:: Python Properties (concrete, overridable)

    .. autosummary::

        ~U
        ~UB

    .. rubric:: Geometry Registry

    .. autosummary::

        ~_geometry_registry
        ~register_geometry

    .. rubric:: Python Properties

    .. autosummary::

        ~all_extra_axis_names
        ~extra_axis_names
        ~extras
        ~geometry
        ~lattice
        ~mode
        ~sample
    """

    from .. import __version__

    name: str = "base"
    """Name of this Solver."""

    version: str = __version__
    """Version of this Solver."""

    ANGLE_UNITS: str = "degrees"
    """
    Angle units used by this solver for unit cell and real axis rotations.

    Solver can override this **constant**.  Must be convertible to
    ``INTERNAL_ANGLE_UNITS``.
    """

    LENGTH_UNITS: str = "angstrom"
    """
    Length units used by this solver for unit cell and wavelength.

    Solver can override this **constant**.  Must be convertible to
    ``INTERNAL_LENGTH_UNITS``.
    """

    _geometry_registry: Dict[str, GeometryDescriptor] = {}
    """
    Per-class registry of :class:`~hklpy2.backends.typing.GeometryDescriptor`
    objects, keyed by geometry name.

    Each concrete solver subclass owns an **independent** registry — populated
    either at class-definition time (via :meth:`register_geometry`) or
    dynamically at runtime.  The base-class dict is intentionally empty; do
    not write to it directly.

    .. note::
        Subclasses must define their own ``_geometry_registry = {}`` class
        variable to avoid sharing the base-class dict across siblings.

    .. versionadded:: 0.5.0
    """

    @versionadded(version="0.5.0", reason="Dynamic geometry registration support.")
    @classmethod
    def register_geometry(cls, descriptor: GeometryDescriptor) -> None:
        """
        Add or replace a geometry in this solver's registry.

        Registers *descriptor* under ``descriptor.name`` in
        :attr:`_geometry_registry`.  Calling this method on a subclass
        affects only that subclass's registry, not the base class or any
        sibling solver.

        Parameters
        ----------
        descriptor : GeometryDescriptor
            The geometry to register.  The :attr:`~GeometryDescriptor.name`
            attribute is used as the registry key.

        Raises
        ------
        TypeError
            If *descriptor* is not a :class:`~hklpy2.backends.typing.GeometryDescriptor`.

        Examples
        --------
        >>> from hklpy2.backends.typing import GeometryDescriptor
        >>> from hklpy2.backends.th_tth_q import ThTthSolver
        >>> geo = GeometryDescriptor(
        ...     name="MY GEO",
        ...     pseudo_axis_names=["h", "k", "l"],
        ...     real_axis_names=["mu", "delta", "nu", "eta", "chi", "phi"],
        ...     modes=["lifting detector"],
        ... )
        >>> ThTthSolver.register_geometry(geo)
        >>> "MY GEO" in ThTthSolver.geometries()
        True
        """
        if not isinstance(descriptor, GeometryDescriptor):
            raise TypeError(
                f"Expected GeometryDescriptor, received {type(descriptor)!r}."
            )
        cls._geometry_registry[descriptor.name] = descriptor
        logger.debug("Registered geometry %r on %s", descriptor.name, cls.__name__)

    def __init__(
        self,
        geometry: str,
        *,
        mode: str = "",  # "": accept solver's default mode
        **kwargs: Any,
    ) -> None:
        self._gname: str = geometry
        self.mode = mode
        self._all_extra_axis_names: Optional[List[str]] = None
        self._sample: Optional[SampleDict] = None
        self._U: Matrix3x3 = IDENTITY_MATRIX_3X3
        self._UB: Matrix3x3 = IDENTITY_MATRIX_3X3

        validate_and_canonical_unit(self.ANGLE_UNITS, INTERNAL_ANGLE_UNITS)
        validate_and_canonical_unit(self.LENGTH_UNITS, INTERNAL_LENGTH_UNITS)

        logger.debug("geometry=%s, kwargs=%s", repr(geometry), repr(kwargs))

    def __repr__(self) -> str:
        # fmt: off
        args = [
            f"{s}={getattr(self, s)!r}"
            for s in "name version geometry".split()
        ]
        # fmt: on
        return f"{self.__class__.__name__}({', '.join(args)})"

    @property
    def _metadata(self) -> SolverMetadataDict:
        """Dictionary with this solver's summary metadata."""
        return {
            "name": self.name,
            "description": repr(self),
            "geometry": self.geometry,
            "real_axes": self.real_axis_names,
            "version": self.version,
        }

    @abstractmethod
    def addReflection(self, reflection: ReflectionDict) -> None:
        """Add coordinates of a diffraction condition (a reflection)."""

    @property
    def all_extra_axis_names(self) -> List[str]:
        """Unique, sorted list of extra axis names in all modes for chosen engine."""
        if self._all_extra_axis_names is None:
            # Only collect this once.
            original = self.mode
            names: List[str] = []
            for mode in self.modes:
                self.mode = mode
                names += self.extra_axis_names
            self.mode = original  # put it back
            self._all_extra_axis_names = sorted(list(set(names)))
        return self._all_extra_axis_names

    @abstractmethod
    def calculate_UB(
        self,
        r1: ReflectionDict,
        r2: ReflectionDict,
    ) -> Matrix3x3:
        """
        Calculate the UB (orientation) matrix with two reflections.

        The method of Busing & Levy, Acta Cryst 22 (1967) 457.
        """
        # return self.UB

    @property
    @abstractmethod
    def extra_axis_names(self) -> List[str]:
        """Ordered list of any extra axis names (such as x, y, z)."""
        # Do NOT sort.
        # return []

    @property
    def extras(self) -> KeyValueMap:
        """
        Ordered dictionary of any extra parameters.
        """
        return {}

    @abstractmethod
    def forward(self, pseudos: NamedFloatDict) -> List[NamedFloatDict]:
        """
        Compute list of solutions(reals) from pseudos (hkl -> [angles]).

        Returns all valid real-axis solutions that the backend engine can
        find for the given pseudo-axis values, geometry, and mode.  The
        number of solutions depends on the backend library's capabilities:
        some engines enumerate all mathematically valid solutions while
        others return only one.  A single-element list is a valid return
        value.

        The :class:`~hklpy2.ops.Core` layer iterates over the returned
        list, applies constraint filtering, and passes the survivors to a
        solution picker (see :func:`~hklpy2.utils.pick_first_solution`,
        :func:`~hklpy2.utils.pick_closest_solution`).

        Parameters
        ----------
        pseudos : NamedFloatDict
            Pseudo-axis values keyed by name
            (e.g. ``{"h": 1.0, "k": 0.0, "l": 0.0}``).

        Returns
        -------
        list[NamedFloatDict]
            Each element is a dictionary of real-axis values keyed by name
            (e.g. ``{"omega": 10.0, "chi": 0.0, "phi": 0.0, "tth": 20.0}``).
            An empty list signals no solutions; a single-element list is
            acceptable.

        Raises
        ------
        NoForwardSolutions
            If the backend cannot find any solution.
        """
        # based on geometry and mode
        # return [{}]

    @classmethod
    @abstractmethod
    def geometries(cls) -> List[str]:
        """
        Ordered list of the geometry names supported by this solver.

        Implementations that use the :attr:`_geometry_registry` should return
        ``sorted(cls._geometry_registry.keys())``.  Solvers backed by an
        external library (e.g. :class:`~hklpy2.backends.hkl_soleil.HklSolver`)
        may query that library's own registry instead.

        EXAMPLES::

            >>> from hklpy2 import get_solver
            >>> Solver = get_solver("no_op")
            >>> Solver.geometries()
            []
            >>> solver = Solver("TH TTH Q")
            >>> solver.geometries()
            []
        """
        # return []

    @property
    def geometry(self) -> str:
        """
        Name of selected diffractometer geometry.

        Cannot be changed once solver is created.  Instead, make a new solver
        for each geometry.
        """
        return self._gname

    @geometry.setter
    def geometry(self, value: str) -> None:
        raise AttributeError(
            "Cannot change 'geometry' after solver is created."
            "  Make a new solver for each geometry."
        )

    @abstractmethod
    def inverse(self, reals: NamedFloatDict) -> NamedFloatDict:
        """Compute dict of pseudos from reals (angles -> hkl)."""
        # return {}

    @property
    def lattice(self) -> NamedFloatDict:
        """
        Crystal lattice parameters.  (Not used by this |solver|.)
        """
        return self._lattice

    @lattice.setter
    def lattice(self, value: NamedFloatDict) -> None:
        if not istype(value, NamedFloatDict):
            raise TypeError(f"Must supply {NamedFloatDict} object, received {value!r}")
        self._lattice = value

    @property
    def mode(self) -> str:
        """
        Diffractometer geometry operation mode for :meth:`forward()`.

        A mode defines which axes will be modified by the
        :meth:`forward` computation.
        """
        try:
            self._mode
        except AttributeError:
            self._mode = ""
        return self._mode

    @mode.setter
    def mode(self, value: str) -> None:
        from ..utils import check_value_in_list  # avoid circular import here

        check_value_in_list("Mode", value, self.modes, blank_ok=True)
        self._mode = value

    @property
    @abstractmethod
    def modes(self) -> List[str]:
        """List of the geometry operating modes."""
        # return []

    @property
    @abstractmethod
    def pseudo_axis_names(self) -> List[str]:
        """Ordered list of the pseudo axis names (such as h, k, l)."""
        # Do NOT sort.
        # return []

    @property
    @abstractmethod
    def real_axis_names(self) -> List[str]:
        """Ordered list of the real axis names (such as th, tth)."""
        # Do NOT sort.
        # return []

    @abstractmethod
    def refineLattice(self, reflections: List[ReflectionDict]) -> NamedFloatDict | None:
        """Refine the lattice parameters from a list of reflections."""

    @abstractmethod
    def removeAllReflections(self) -> None:
        """Remove all reflections."""

    def set_reals(self, reals: NamedFloatDict) -> None:
        """
        Set current real-axis values in the solver's internal geometry object.

        This method is called by :meth:`~hklpy2.ops.Core.forward` to push
        the current motor positions (or preset values for constant axes) into
        the solver before computing forward-calculation solutions.  Solvers
        that maintain an internal geometry object with real-axis state (such
        as ``hkl_soleil``, which calls ``axis_values_set`` on its libhkl
        geometry) **must** override this method.

        The default implementation is a deliberate no-op so that solvers
        which do not require real-axis state (e.g. pure function-based
        backends) can inherit from :class:`SolverBase` without needing to
        define this method.

        Parameters
        ----------
        reals : NamedFloatDict
            Dictionary mapping solver real-axis names to their current values
            (in the solver's internal angle units).
        """

    @property
    def sample(self) -> Union[SampleDict, None]:
        """
        Crystalline sample.
        """
        return self._sample

    @sample.setter
    def sample(self, value: SampleDict) -> None:
        if not isinstance(value, dict):
            raise TypeError(f"Must supply dictionary, received {value!r}")
        self._sample = value

    @property
    def _summary_dict(self) -> KeyValueMap:
        """Return a summary of the geometry (modes, axes)"""
        geometry_name = self.geometry
        description: KeyValueMap = {
            "name": geometry_name,
            "pseudos": self.pseudo_axis_names,
            "reals": self.real_axis_names,
            "modes": {},
        }

        for mode in self.modes:
            self.mode = mode
            desc: KeyValueMap = {
                "extras": [],
                # the reals to be written in this mode (solver should override)
                "reals": self.real_axis_names,
            }
            description["modes"][mode] = desc

        return description

    # NOTE: _summary_dict intentionally keeps KeyValueMap because its nested
    # structure varies by engine and subclasses override it freely.

    @property
    def summary(self) -> Table:
        """
        Table of this geometry (modes, axes).

        .. seealso:: :ref:`geometries.summary_tables`,
            :func:`hklpy2.user.solver_summary()`
        """
        table = Table()
        table.labels = "mode pseudo(s) real(s) writable(s) extra(s)".split()
        sdict = self._summary_dict
        for mode_name, mode in sdict["modes"].items():
            self.mode = mode_name
            row = [
                mode_name,
                ", ".join(sdict["pseudos"]),
                ", ".join(sdict["reals"]),
                ", ".join(mode["reals"]),
                ", ".join(mode["extras"]),
            ]
            table.addRow(row)
        return table

    @property
    def U(self) -> Matrix3x3:
        """
        Relative orientation of the crystal on the diffractometer (3x3 rotation matrix).

        The default implementation stores and returns the value set via the
        setter, initialised to the identity matrix.  Subclasses that maintain
        an internal backend object (e.g. ``hkl_soleil``) should override both
        getter and setter to read/write the backend state directly.
        """
        return self._U

    @U.setter
    def U(self, value: Matrix3x3) -> None:
        self._U = value

    @property
    def UB(self) -> Matrix3x3:
        """
        Orientation matrix (3x3).

        The default implementation stores and returns the value set via the
        setter, initialised to the identity matrix.  Subclasses that maintain
        an internal backend object (e.g. ``hkl_soleil``) should override both
        getter and setter to read/write the backend state directly.
        """
        return self._UB

    @UB.setter
    def UB(self, value: Matrix3x3) -> None:
        self._UB = value
