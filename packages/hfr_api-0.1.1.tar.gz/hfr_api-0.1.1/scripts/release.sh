#!/bin/sh
# Pushes a new version to PyPi

set -e

cd "$(dirname "$0")/.."

rm -rf dist
python3 setup.py sdist
python3 -m twine upload dist/* --skip-existing