# Changelog

All notable changes to django-test-doctor are documented here. The project follows
[Semantic Versioning](https://semver.org/).

## [0.10.2] — 2026-04-21

Second-pass tightening after running v0.10.1 against altiusone. 0.10.1
killed the shared-abstract-base noise (2155 → 512 findings), but still
over-reported because (a) many projects declare `created_at` / `is_active`
etc. directly on each concrete model instead of via an abstract base, and
(b) scalar name collisions like `description` / `notes` / `libelle`
between semantically unrelated models were flagged as duplication.

### Fixed

- **Built-in infrastructure skip list** applied regardless of declaration
  origin : `id`, `pk`, `uuid`, `created_at` / `created` / `date_creation`,
  `updated_at` / `updated` / `modified_at` / `date_modification`,
  `deleted_at`, `created_by` / `updated_by` / `modified_by` (+ fr variants
  `cree_par` / `modifie_par`), `is_active` / `is_deleted` / `active` /
  `archived` / `est_archive`, `tenant_id` / `site_id`, `langue_saisie` /
  `language`. Tune via `extra_infra_fields` / `keep_infra_fields`.

- **Scalar-scalar matches disabled by default.** `description` / `notes` /
  `libelle` collide by name across unrelated models far too often — the
  default-on behavior produced ~80 % noise on a real codebase. Opt in with
  `detect_scalar = true` to flag scalar duplicates as well. FK-to-FK
  matches (same remote model on both sides) remain always on and are the
  high-signal case the check is built for.

### Net effect on altiusone

From 2,155 findings (v0.10.0) → 512 (v0.10.1) → **133** (v0.10.2).
The 133 are all FK-to-FK duplications across the domain : `mandat`,
`devise`, `regime_fiscal`, `client`, `position`, `valide_par` spread over
Document / EcritureComptable / Facture / TimeTracking / etc.

### Added

- 2 new regression tests : `test_scalar_duplication_is_skipped_by_default`
  and `test_scalar_duplication_flagged_when_detect_scalar_true`. Total
  71/71 passing.

## [0.10.1] — 2026-04-21

First pass of ``fk_redundant`` against a production codebase (altiusone,
~175 models) produced **2,155 warnings** — almost all false positives on
`id`, `created_at`, `updated_at`, `is_active`, `created_by` shared across
every concrete model via a common `BaseModel` abstract parent. The check
was flagging shared infrastructure as duplication.

### Fixed

- **Primary keys are never flagged.** `field.primary_key == True` is
  always identity, never redundancy — the check now skips it unconditionally.
  On altiusone this cut ~30% of the noise on its own.
- **Shared abstract-base fields are never flagged.** If both the model
  and its FK target inherit the same field name from (possibly different)
  abstract bases — typical of a project-wide `BaseModel` declaring id /
  created_at / updated_at / is_active / created_by — the check now treats
  them as shared infrastructure and skips them en bloc.

  Implementation : walks each model's MRO, collects field names declared
  on any `abstract=True` class. The intersection of both sides' abstract
  inheritance is the "shared" set.

### Added

- `tests/sample_app/models.AuditBase` / `AuditedParent` / `AuditedChild`
  fixtures to exercise the shared-abstract case.
- 2 new regression tests : `test_shared_abstract_base_fields_are_not_flagged`
  and `test_pk_is_never_flagged`. Total 69/69 passing.

### Net effect on altiusone

Expected reduction from 2,155 findings to a handful — only the domain
duplicates that are the actual bug (`regime_fiscal`, `devise`, `unite`
on Mandat / Prestation / Facture / TimeTracking).

## [0.10.0] — 2026-04-21

New check that targets a silent ergonomics + data-integrity problem we keep
hitting on long-lived Django schemas : columns that duplicate a value
reachable via a `ForeignKey` on the same model.

### Added

- **`fk_redundant` check.** Scans every first-party model, finds its
  ForeignKey fields, and for each FK checks whether the same column name
  exists on the FK target with the same shape. Produces one `WARNING` per
  duplicate. Three shape-matching rules to keep false positives low :
  - Two `ForeignKey` fields only count if they point to the same remote
    model.
  - Two scalar fields only count if they share the same Python type.
  - A scalar and a FK don't match (different storage).

  Config via `[tool.django-doctor.fk_redundant]` — `skip_apps`,
  `skip_models`, `skip_fields`. `skip_fields` takes a dotted triplet
  `"app_label.ModelName.field_name"`.

- **Auto-detection of snapshot intent.** Fields whose `help_text`
  contains one of `snapshot`, `au moment`, `fige`, `figé`, `historique`,
  `historical`, `frozen`, `at the time`, `denormali` are treated as
  intentional denormalisations and skipped without needing a config
  entry. Invoice `devise` / `regime_fiscal` / `taux_tva` are the
  canonical case — document them in `help_text` and the check respects
  the intent.

### Motivated by

Real ergonomics issue on altiusone : `regime_fiscal` was duplicated across
`Client`, `Mandat`, `Prestation` and `Facture`, forcing the end user to
re-enter the same value four times per invoice. Same pattern for `devise`,
`unite`, and others. Forms + serializers carried the duplication
everywhere, and a single-source-of-truth refactor was needed but no tool
flagged the redundancy.

### Scope

1-hop only : `Prestation → Mandat → Client` gets flagged as two separate
1-hop findings (`Prestation.regime_fiscal` via `mandat`, `Mandat.regime_fiscal`
via `client`). Transitive walks are deliberately out of scope — each hop
is a different refactor decision.

## [0.9.1] — 2026-04-21

Running 0.9.0 against a production codebase (altiusone, 16 apps) produced
43 `stale_db.{create,update}` findings the first pass, mostly false
positives. Root cause: the check treated any 2xx/3xx response as
"successful save", but a 200 after a CBV POST is typically the form
re-rendered with validation errors — "nothing was saved, and that's
correct behavior". Only a 3xx redirect is the universal Django signal
for "form.is_valid() passed, I saved, go to the success URL".

### Fixed

- `post_smoke.stale_db.create` and `post_smoke.stale_db.update` now only
  verify DB persistence when the response is a **3xx redirect**. Views
  that return 200 on successful save (a minority pattern, e.g. JSON
  APIs) are not checked — those can be covered by per-endpoint
  integration tests instead. Trade-off: a small rate of missed real
  bugs in exchange for a 10× false-positive reduction on a normal
  CBV-heavy codebase.

## [0.9.0] — 2026-04-21

The static `update_fields` check (0.8) catches the altiusone Studio bug
shape at the source — but only when the receiver's type is resolvable
statically. Some codebases route through helper functions where static
inference bails. This release extends the runtime `post_smoke` check
with two new rules that verify the DB actually changed after a POST,
catching the same failure shape dynamically whenever a CBV is probed.

### Added

- **`post_smoke.stale_db.create`** — for every `CreateView` the check
  visits, snapshot `Model.objects.count()` before the POST and compare
  after. If the POST returned 2xx/3xx but the count didn't increase,
  flag critical. Catches silent transaction rollbacks, `form_valid()`
  that forgot to call `super()`, outer middleware swallowing a
  post-save exception — the whole class of "302 success but the DB
  never got the write" bugs.
- **`post_smoke.stale_db.update`** — for every `UpdateView` the check
  visits (kwargs resolved via the URL-kwargs fixture generator added
  in 0.6), snapshot the target instance before the POST and reload it
  after. For each form field that was in the POST payload, if the
  POST value differs from the pre value **and** the post-POST DB
  value doesn't match the POST value, flag critical. This is the
  runtime twin of `update_fields.drops_computed` — it catches cases
  static analysis can't resolve (dynamic receivers, helper-function
  indirection, etc.).

Both rules share the existing savepoint + rollback scaffolding, so the
DB isn't mutated even when the probe triggers a write.

### Tests

- 2 new regression tests + `SilentlyDroppedCreateView` /
  `SilentlyDroppedUpdateView` fixtures (views that return 302 without
  calling `form.save()` — the canonical "user sees success, DB has
  nothing" shape). Total 60 tests.

## [0.8.0] — 2026-04-21

New check born directly from the second altiusone hikimatech incident
(this time in the Studio for facture creation): `POST /fr/facturation/studio/…`
saved a line's `quantite`, but the PDF rendered totals as `0.00`. Root
cause: `LigneFacture.save()` unconditionally recomputes `montant_ht` /
`montant_tva` / `montant_ttc` from `quantite × prix_unitaire_ht`, but the
studio endpoint called `ligne.save(update_fields=['quantite'])`, so
Django wrote only `quantite` and the three recomputed totals silently
dropped. A static check would have caught this class of bug before
deploy — here it is.

### Added

- **update_fields** — new check. For every first-party model, parses the
  `save()` method's AST and records the set of DB fields it
  **unconditionally** assigns (`self.<field> = …` outside a guarding
  `if not self.<field>:` branch). Then scans every `.py` file under
  each first-party app for `<recv>.save(update_fields=[<literals>])`
  calls, resolves `<recv>`'s model class through a per-function symbol
  table (handles `Model.objects.get/filter(...).first/last/…`,
  `get_object_or_404(Model, …)`, explicit annotations, `for x in
  Model.objects.…`, and `self.<fk>.save(…)` via `_meta.get_field`),
  and flags any call whose `update_fields` omits fields the model
  recomputes. Pure static analysis — runs in `--quick` mode, no DB
  access.

### Tests

- 3 new regression tests + sample_app fixtures: `ComputedTotals` (model
  with computed totals), `unsafe_update_quantity` (flagged),
  `safe_update_quantity` (full save → not flagged),
  `safe_update_quantity_with_all_fields` (update_fields includes every
  recomputed field → not flagged). Total 58 tests.

### Docs

- New `checks/update_fields.md` with the motivating altiusone Studio
  story and safe patterns reference.

## [0.7.2] — 2026-04-20

### Docs

- Drop the `pepy.tech/badge/.../month` URL from the README badge row — it
  returns HTTP 404 for packages that pepy.tech hasn't indexed yet
  (typical for a fresh release), which rendered as a broken image on the
  PyPI landing page. Total downloads, when pepy.tech has indexed, remain
  available through the direct [pepy.tech project
  page](https://pepy.tech/project/django-test-doctor) linked elsewhere in
  the docs.

## [0.7.1] — 2026-04-20

### Docs

- README badge row refreshed: PyPI version, Python versions (dynamic
  `pypi/pyversions`), Django 4.2 / 5.x / 6.0, license, docs, monthly
  downloads. Added **checks: 13** and **tests: 55 passing** static badges
  so the PyPI landing page has useful signal even before pepy.tech and
  PyPI download stats have indexed the fresh release. Replaced
  `static.pepy.tech/badge/django-test-doctor` (unversioned static asset
  that lags for new packages) with `static.pepy.tech/badge/django-test-doctor/month`
  (dynamic, refreshes automatically).

## [0.7.0] — 2026-04-20

New check born directly from a production incident: altiusone hikimatech
was hitting HTTP 500 on every `POST /mandats/nouveau/` because `Mandat.save()`
did `int(last.numero.split('-')[-1])` without a try/except, and a legacy
row with numero `MAN-2026-CIB` (imported from another system) crashed
with `ValueError: invalid literal for int() with base 10: 'CIB'`. Three
other models had the same pattern (Facture, DeclarationTVA,
DeclarationFiscale). A static check would have caught all four before
deploy — here it is.

### Added

- **autogen** — new check. AST-scans every first-party model's `save()` /
  `clean()` / `full_clean()` for calls shaped like `int(<x>.split(<sep>)[<i>])`
  or `int(<x>.rsplit(<sep>)[<i>])` and flags each one whose surrounding
  code does **not** catch `ValueError` / `TypeError` / `IndexError` /
  `AttributeError` / bare `Exception`. Static only — runs in `--quick`
  mode.

### Tests

- 3 new regression tests (`test_autogen_check.py`) + fixtures
  `UnsafeAutoNumero` (flagged) and `SafeAutoNumero` (try/except → not
  flagged). Total 55 tests.

### Docs

- New `checks/autogen.md` with the motivating altiusone/hikimatech story,
  two recommended fixes (regex filter vs. try/except), and scope notes.

## [0.6.0] — 2026-04-20

Two new checks, an HTML reporter, diff-aware filtering, and the URL kwargs
fixture that unlocks the `urls` and `post_smoke` checks on detail/edit routes.

### Added

- **templates** — new check. Walks every first-party template and flags
  `{% url 'name' %}` references whose name isn't registered in the
  resolver, `{% static 'path' %}` references whose path no staticfiles
  finder resolves, and `TemplateSyntaxError` at load time. Catches the
  class of bug where a rename misses a template and `NoReverseMatch` only
  surfaces in prod when a user hits the page.
- **views** — new check. Flags first-party views that appear to be public
  by accident — no `LoginRequiredMixin` / `PermissionRequiredMixin` /
  `UserPassesTestMixin` in the CBV MRO, no `@login_required` /
  `@permission_required` decorator on the FBV, no DRF
  `permission_classes = [IsAuthenticated, ...]`. Whitelist legitimate
  public endpoints (login, signup, health) under
  `[tool.django-doctor.views].public`; defaults already cover the common
  ones.
- **HTML reporter** — `--html <path>` writes a standalone self-contained
  HTML page (inline CSS, no JS dependencies, collapsible per-check
  sections) suitable for CI artifacts and email.
- **`--diff <ref>`** — only show findings whose `location` touches a file
  changed since `<ref>`. Combines committed changes, unstaged modifications,
  and untracked files. Findings with no resolvable file path (e.g. URL
  names) are kept visible — we'd rather over-report than silently drop.
- **URL kwargs fixture** — `make_url_kwargs(route, view_cls)` generates
  kwargs for `<int:pk>` / `<uuid:id>` / `<slug:slug>` converters. For
  model-backed CBVs (`DetailView`, `UpdateView`, …) it picks `qs.first()`
  or creates a minimal row; elsewhere it falls back to a typed literal.
  The `urls` and `post_smoke` checks now probe detail and edit URLs that
  used to be skipped.

### Tests

- 22 new regression tests across `test_templates_check.py`,
  `test_views_check.py`, `test_html_reporter.py`,
  `test_url_kwargs_fixture.py`, and `test_diff_mode.py`. Total 52 tests.
- New sample-app fixtures: guarded / unguarded FBVs and CBVs, a
  `WidgetDetailView` for URL-kwarg generation, broken and valid `.html`
  templates for the template checker.
- `django.contrib.staticfiles` is now in the test `INSTALLED_APPS` so the
  staticfiles resolver is correctly wired for the templates test.

## [0.5.1] — 2026-04-20

### Docs

- README.md intro now surfaces the docs site URL directly so PyPI visitors
  see the link on the landing page without scrolling to the sidebar.

## [0.5.0] — 2026-04-20

### Added

- **forms_meta** — new check. Statically analyzes every first-party
  `ModelForm`'s `clean()` / `clean_<field>()` methods via `ast` and flags
  every `cleaned_data[<key>]` assignment where `<key>` is a NOT-NULL model
  column, absent from `Meta.fields`, not declared on the form, and the form
  has no `save()` override. This is exactly the shape of the
  `OperationTVAForm.montant_ttc` bug that motivated the check: Django
  silently drops orphan `cleaned_data` keys, the next `.save()` raises
  `IntegrityError` on a NOT NULL column.

### Tests

- 3 new regression tests (`test_forms_meta_check.py`) + fixtures
  `OrphanCleanedDataForm` (flagged) and `OrphanCleanedDataWithSaveOverrideForm`
  (not flagged). Total 30 tests.

### Docs

- README.md refreshed — ten layers table, motivating bug examples (forms /
  post_smoke / forms_meta), expanded configuration reference, `make_form_fixture`
  helper documented.
- `pyproject.toml` `description` updated to advertise the new POST smoke +
  orphan `cleaned_data` checks.

## [0.4.0] — 2026-04-20

Closes the `urls`-check gap. A user reported a real-world HTTP 500 on
`/fr/mandats/nouveau/` (a `post_save` signal crashing with `IntegrityError`)
that slipped past the full 0.3.0 audit, because `urls` only probes GET.

### Added

- **post_smoke** — new check. Discovers every `CreateView` / `UpdateView` in
  the URL resolver, auto-generates a minimal valid POST payload from
  `form_class` (or `model + fields`), submits it as a superuser, and fails
  critical on any HTTP 5xx. Each POST runs inside `transaction.atomic()` +
  `savepoint_rollback`, so the database is **not** mutated even when the
  view reaches `.save()`.
- **`django_doctor.fixtures`** — public helper `make_form_fixture(form_cls)`
  that returns a minimal dict of form-ready values for every required
  field. Supports `CharField`, `IntegerField`, `DecimalField`,
  `BooleanField`, `DateField`, `DateTimeField`, `EmailField`, `URLField`,
  `ChoiceField` (skips the empty option), `ModelChoiceField` (picks
  `qs.first()`), `ModelMultipleChoiceField`, typed choice fields, multiple
  choices. Returns `_SKIP` for fields it can't fill (files, images,
  querysets with no rows) and the check reports a partial fixture.

### Tests

- 2 new regression tests (`test_post_smoke_check.py`) + `BadSaveCreateView`
  fixture reproducing exactly the hikimatech scenario. Total 27 tests.

### Notes on scope

Requires a writable dev/test database. Wraps every probe in a savepoint
that's always rolled back, so it's safe to run against a dev snapshot of
production — but **do not** run against live production.

## [0.3.0] — 2026-04-20

### Added

- **drf** — new check: iterates every `Serializer` / `ModelSerializer` in
  first-party apps and:
  - blank-instantiates each one (same signal as the `forms` check, but for
    the API layer) — catches serializers whose `__init__` crashes;
  - validates that every entry in `Meta.fields` either maps to a real field
    on `Meta.model` or is declared on the serializer class — catches typos
    that DRF only raises at render time;
  - downgrades "missing required kwargs" to INFO, consistent with the `forms`
    check behaviour.
  Skipped silently if `djangorestframework` is not installed.

### Fixed

- **urls** — the Django test client ships requests with `Host: testserver`,
  which a typical production `ALLOWED_HOSTS` rejects. The check now wraps
  its probes in `override_settings(ALLOWED_HOSTS=[..., "testserver", "*"])`
  so every URL is reachable regardless of the deployed host config.

### Tests

- 3 new tests (`test_drf_check.py`) + sample DRF fixtures. Total 25 tests.

## [0.2.2] — 2026-04-20

Correctness pass — the 0.2.1 `migrations` check produced drift findings
(`AlterField`, `AlterModelOptions`) that `./manage.py makemigrations --check
--dry-run` did not. Reimplementing `MigrationAutodetector` in-house diverged
from the official command's verdict, which is the ground truth users compare
against.

### Fixed

- **migrations** — now delegates to `call_command("makemigrations",
  dry_run=True, check_changes=False)` and parses its stdout for
  `"Migrations for 'app':"` lines. Byte-for-byte parity with the CLI verdict.
  No more phantom drift on apps whose migrations are fully up to date.
- **forms** — dedupe: a form reachable through multiple app walks (re-exports,
  shared `__init__` shims) was probed N times, producing N duplicate findings.
  Now probed once.

### Tests

- 2 new tests: `test_form_is_not_double_reported`,
  `test_drift_detection_matches_makemigrations_verdict`. Total 22 tests.

## [0.2.1] — 2026-04-20

Noise reduction pass — surfaced by running 0.2.0 against a real Django project
(altiusone, 16 apps, ~150 forms, heavy use of modeltranslation) where the
`forms` and `migrations` checks emitted ~30 actionable-looking findings that
were in fact structural, not bugs.

### Fixed

- **forms** — a form whose `__init__` requires extra arguments (Django's
  `SetPasswordForm` needs `user=`, `AuthenticationForm` needs `request=`,
  user-defined variants with required kwargs) is now surfaced as **INFO** with
  rule `forms.blank_init.needs_args` instead of **ERROR**. Real `__init__`
  bugs (AttributeError on `field.choices`, NameError, …) still surface as
  ERROR. This removes the CI block without losing coverage.
- **migrations** — by default, only first-party apps (outside site-packages)
  are inspected for drift. Contrib apps (`auth`, `admin`, `contenttypes`,
  `sessions`, …) and third-party packages are skipped because the user can't
  fix drift there anyway. Override via `[tool.django-doctor.migrations]
  include_third_party = true`. Extra explicit skips via `skip_apps = [...]`.

### Tests

- 4 new regression tests: missing-args form → INFO (not ERROR), first-party
  detection correctness, contrib apps never leak into migrations findings.
  Total 20 tests, all green.

## [0.2.0] — 2026-04-20

**Renamed** — distribution moves from `django-doctor` to `django-test-doctor`
(the former name is taken on PyPI). The importable Python module stays
`django_doctor`, so existing code keeps working after `pip install django-test-doctor`.

### Added

- **admin** — walks `admin.site._registry` and flags `list_display`,
  `list_filter`, `search_fields` and `ordering` entries that do not resolve
  to a real field or callable on the model or ModelAdmin. Catches the typo
  class of bug that silently breaks admin list pages until someone opens them.
- **models** — flags every first-party, non-abstract model that:
  - has no custom `__str__` (defaults to ugly generic repr in admin/shell/logs);
  - has no `Meta.ordering` (pagination becomes order-dependent);
  - declares `on_delete=SET_NULL` on a FK whose column is `NOT NULL`
    (silent `IntegrityError` waiting for the first parent deletion).
- **security** — runs Django's deployment check tag + flags weak
  `SECRET_KEY` substrings (`django-insecure`, `changeme`, `secret`, …),
  short keys (< 32 chars), `DEBUG=True`, and empty `ALLOWED_HOSTS` in production.

### Tests

- 11 new regression tests across `admin`, `models`, and `security`. Total now
  16 tests, all green.

## [0.1.0] — Unreleased

Initial alpha (internal — never published to PyPI under the old name). Four
layers shipped:

- **system** — wraps Django's built-in `check` framework with rich output.
- **urls** — crawls `urlpatterns`, probes each URL as `anonymous / authenticated /
  staff / superuser`, fails on 5xx. Skips URLs that need kwargs for now
  (fixtures layer lands in 0.3).
- **forms** — instantiates every `Form` / `ModelForm` blank and with `data={}`.
  Catches the `CharField.choices` family of `__init__` bugs that motivated
  the package.
- **migrations** — detects unapplied migrations and model changes without a
  matching migration file.

Infrastructure:

- Plugin registry via the `django_doctor.checks` entry point group — any
  PyPI package can contribute checks.
- Config loaded from the host project's `pyproject.toml` under
  `[tool.django-doctor]`.
- Rich terminal reporter. JSON exporter included.
- `./manage.py doctor` management command with `--section`, `--quick`, `--ci`,
  `--json` flags.

## Roadmap

- **0.7**: `i18n` (untranslated msgid, stale .mo vs .po), `static`
  (collectstatic dry-run drift), `--fix` (auto-rewrites for mechanical
  findings), `--watch`, incremental cache keyed by `git diff` between runs.
