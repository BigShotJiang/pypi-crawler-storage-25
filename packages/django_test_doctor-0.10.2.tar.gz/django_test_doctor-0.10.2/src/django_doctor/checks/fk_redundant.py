"""Detect columns that duplicate a value reachable via a ForeignKey.

Pattern that regularly leaks into Django models as projects grow :

    class Mandat(models.Model):
        client = models.ForeignKey(Client, on_delete=models.CASCADE)
        regime_fiscal = models.ForeignKey(RegimeFiscal, on_delete=models.PROTECT)

    class Client(models.Model):
        regime_fiscal = models.ForeignKey(RegimeFiscal, on_delete=models.PROTECT)

``Mandat.regime_fiscal`` is redundant with ``Mandat.client.regime_fiscal`` —
the form forces the user to re-enter a value that's already knowable from
the FK. Worse, the two can desynchronize (Client changes regime → Mandat
still points at the old one until manually updated).

Legitimate exceptions exist :

- **Snapshots.** A ``Facture.devise`` frozen at emission date even if
  ``Client.devise`` later changes. Usually signalled by help_text keywords
  like "snapshot", "au moment", "fige".
- **Performance.** Denormalisation to avoid a join on hot paths. Rare in
  practice and should be documented.
- **Nullable + different semantics.** A child that legitimately overrides
  the parent's value.

So : this check emits **WARNING**, never ERROR — a human decides. The
``skip_fields`` config lets you silence legitimate cases permanently.
"""

from __future__ import annotations

from typing import Iterable, Iterator

from django.apps import apps
from django.db import models as dj_models

from ..finding import Finding, Severity
from ..registry import Check, Project


# Field types we treat as "same shape" when comparing parent vs child.
# Two ForeignKey fields to the same remote model = redundant candidate.
# Two CharField with the same max_length + same name = redundant candidate.
# A CharField vs a ForeignKey = NOT redundant (different storage).
_SCALAR_TYPES = (
    dj_models.CharField,
    dj_models.TextField,
    dj_models.IntegerField,
    dj_models.BigIntegerField,
    dj_models.SmallIntegerField,
    dj_models.DecimalField,
    dj_models.FloatField,
    dj_models.BooleanField,
    dj_models.DateField,
    dj_models.DateTimeField,
    dj_models.UUIDField,
)

# help_text keywords that signal intentional snapshot / denormalisation.
# Matching is case-insensitive, substring.
_SNAPSHOT_KEYWORDS = (
    "snapshot",
    "au moment",
    "fige",
    "figé",
    "historique",
    "historical",
    "frozen",
    "at the time",
    "denormali",  # denormalised / denormalized
)

# Field names that are ALMOST ALWAYS shared infrastructure — audit
# timestamps, identity, soft-delete flags, multi-tenancy markers. When
# two models both have a column with one of these names, they aren't
# duplicating domain data — they independently wear the same audit coat.
#
# The check skips these unconditionally unless the user overrides via
# `keep_infra_fields = True` in config.
_DEFAULT_INFRA_FIELDS = frozenset({
    # identity
    "id", "pk", "uuid",
    # audit timestamps (en + fr variants that real projects use)
    "created_at", "created", "date_creation", "date_created",
    "updated_at", "updated", "modified_at", "modified",
    "date_modification", "date_updated", "date_modified",
    "deleted_at", "date_suppression",
    # audit actors
    "created_by", "updated_by", "modified_by",
    "cree_par", "modifie_par",
    # soft delete / activation
    "is_active", "is_deleted", "active", "archived", "est_archive",
    # multi-tenancy / project-level
    "tenant_id", "site_id",
    # i18n metadata
    "langue_saisie", "language",
})


def _abstract_inherited_names(model) -> set[str]:
    """Return the set of field names ``model`` inherited from abstract bases.

    Django copies abstract-parent fields into the concrete model's ``_meta``
    at class-build time, so we can't distinguish them via ``field.model``.
    Walking the MRO and collecting fields declared on any ``abstract=True``
    class gives us the shared-infrastructure set (typical BaseModel : id,
    created_at, updated_at, created_by, is_active, etc.).
    """
    names: set[str] = set()
    for base in model.__mro__:
        meta = getattr(base, "_meta", None)
        if meta is None or not getattr(meta, "abstract", False):
            continue
        for f in meta.get_fields():
            if hasattr(f, "name"):
                names.add(f.name)
    return names


def _shared_abstract_fields(a, b) -> set[str]:
    """Names of fields that BOTH models inherit from (possibly different)
    abstract bases. Those are shared infrastructure — never flagged.
    """
    return _abstract_inherited_names(a) & _abstract_inherited_names(b)


class FkRedundantColumnCheck(Check):
    id = "fk_redundant"
    description = (
        "Flag columns duplicating a value reachable via a ForeignKey on the same model."
    )
    order = 30

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_apps: set[str] = set(config.get("skip_apps", []))
        # Per-field allowlist : "<app_label>.<ModelName>.<field_name>"
        skip_fields: set[str] = set(config.get("skip_fields", []))
        # Per-model allowlist : "<app_label>.<ModelName>" — skip whole model
        skip_models: set[str] = set(config.get("skip_models", []))
        # Infrastructure field names to skip unconditionally (audit, PK,
        # soft-delete, tenant, i18n metadata). Defaults to a built-in list
        # — override with `extra_infra_fields` to add, `keep_infra_fields`
        # to disable the built-in list entirely.
        infra_fields: set[str] = set(_DEFAULT_INFRA_FIELDS)
        if config.get("keep_infra_fields", False):
            infra_fields = set()
        infra_fields |= set(config.get("extra_infra_fields", []))
        # Scalar-scalar matches (two CharField/TextField/… with the same name
        # and type on model and FK target) produce too many name-collision
        # false positives in practice : every model has its own `description`,
        # they aren't duplicating anything. Off by default. Turn on with
        # `detect_scalar = true` to also flag scalar duplications.
        detect_scalar: bool = bool(config.get("detect_scalar", False))

        for model in apps.get_models():
            if model._meta.app_label in skip_apps:
                continue
            if model._meta.abstract or model._meta.proxy:
                continue
            if not _is_first_party(model):
                continue
            model_key = f"{model._meta.app_label}.{model.__name__}"
            if model_key in skip_models:
                continue
            yield from self._check_model(
                model, skip_fields, infra_fields, detect_scalar
            )

    # ------------------------------------------------------------------
    def _check_model(
        self,
        model,
        skip_fields: set[str],
        infra_fields: set[str],
        detect_scalar: bool,
    ) -> Iterator[Finding]:
        fks = self._collect_fks(model)
        if not fks:
            return

        own_fields = {f.name: f for f in model._meta.get_fields() if hasattr(f, "name")}

        for fk_name, fk_field in fks.items():
            related = fk_field.related_model
            if related is None or related is model:
                continue
            # Fields on the related model that could be duplicated on us.
            related_fields = {
                f.name: f
                for f in related._meta.get_fields()
                if hasattr(f, "name") and not f.auto_created
            }
            # Fields both sides inherit from a common abstract base (id,
            # created_at, is_active, etc.). Those are shared infrastructure,
            # not redundancy — skip them en bloc.
            shared_abstract = _shared_abstract_fields(model, related)

            for field_name, own_field in own_fields.items():
                if field_name == fk_name:
                    continue
                if field_name not in related_fields:
                    continue
                # Primary key fields are the row's identity — never
                # meaningfully redundant with a FK target's PK.
                if getattr(own_field, "primary_key", False):
                    continue
                # Shared BaseModel / audit infrastructure (via abstract base).
                if field_name in shared_abstract:
                    continue
                # Well-known infrastructure names (audit timestamps, tenant
                # markers, etc.) — skipped even when not inherited from an
                # abstract base (many projects declare these directly on each
                # concrete model rather than factoring into a BaseModel).
                if field_name in infra_fields:
                    continue
                if not self._shapes_match(
                    own_field, related_fields[field_name], detect_scalar
                ):
                    continue
                if self._is_snapshot_field(own_field):
                    continue
                key = (
                    f"{model._meta.app_label}.{model.__name__}.{field_name}"
                )
                if key in skip_fields:
                    continue
                yield self._make_finding(
                    model=model,
                    fk_name=fk_name,
                    fk_field=fk_field,
                    field_name=field_name,
                    related_model=related,
                )

    # ------------------------------------------------------------------
    def _collect_fks(self, model) -> dict[str, dj_models.ForeignKey]:
        fks = {}
        for field in model._meta.get_fields():
            if isinstance(field, dj_models.ForeignKey):
                fks[field.name] = field
        return fks

    def _shapes_match(self, a, b, detect_scalar: bool) -> bool:
        """Return True if two fields are "the same shape" and the match is
        worth flagging. Used to decide whether duplication is meaningful.

        FK-to-FK : matches only when both point to the same remote model.
        This is the high-signal case the check is built for — domain
        references (regime fiscal, currency, unit) duplicated across models
        that already hold a FK chain to the source of truth.

        Scalar-scalar : disabled by default because `description` / `notes` /
        `libelle` frequently collide by name across semantically unrelated
        models, producing noise >> signal. Opt-in via `detect_scalar = True`.
        """
        # Both ForeignKey to the same remote model = redundant candidate.
        if isinstance(a, dj_models.ForeignKey) and isinstance(
            b, dj_models.ForeignKey
        ):
            return a.related_model is b.related_model
        # Scalar duplication is opt-in — see docstring above.
        if detect_scalar and isinstance(a, _SCALAR_TYPES) and isinstance(
            b, _SCALAR_TYPES
        ):
            return type(a) is type(b)
        return False

    def _is_snapshot_field(self, field) -> bool:
        """Heuristic : field looks like an intentional snapshot (NOT a bug)."""
        help_text = str(getattr(field, "help_text", "") or "").lower()
        if not help_text:
            return False
        return any(kw in help_text for kw in _SNAPSHOT_KEYWORDS)

    def _make_finding(
        self, *, model, fk_name, fk_field, field_name, related_model
    ) -> Finding:
        model_label = f"{model._meta.app_label}.{model.__name__}"
        related_label = (
            f"{related_model._meta.app_label}.{related_model.__name__}"
        )
        return Finding(
            severity=Severity.WARNING,
            check_id=self.id,
            rule="fk_redundant.duplicate_via_fk",
            location=f"{model.__module__}.{model.__qualname__}.{field_name}",
            message=(
                f"{model_label}.{field_name} duplicates "
                f"{model_label}.{fk_name}.{field_name} "
                f"(via FK to {related_label}). "
                "Forms force the user to re-enter a value knowable from the FK, "
                "and the two can desynchronize."
            ),
            fix_hint=(
                f"If this is NOT a snapshot: drop the column and expose "
                f"{field_name} as a @property reading {fk_name}.{field_name}. "
                f"If it IS a snapshot (e.g. invoice emission): document it in "
                f"help_text (keywords: 'snapshot', 'au moment', 'fige') — "
                f"the check will then skip it. To silence permanently: add "
                f"'{model._meta.app_label}.{model.__name__}.{field_name}' to "
                f"[tool.django-doctor.fk_redundant].skip_fields."
            ),
            extra={
                "model": model_label,
                "fk": fk_name,
                "duplicated_field": field_name,
                "related_model": related_label,
            },
        )


# ---------------------------------------------------------------------------


def _is_first_party(model) -> bool:
    module = model.__module__
    import sys

    mod_obj = sys.modules.get(module)
    file_ = getattr(mod_obj, "__file__", "") if mod_obj else ""
    return "site-packages" not in (file_ or "") and "dist-packages" not in (
        file_ or ""
    )
