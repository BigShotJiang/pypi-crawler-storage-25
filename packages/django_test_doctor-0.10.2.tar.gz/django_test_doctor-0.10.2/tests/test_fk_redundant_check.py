"""Regression tests for the fk_redundant check.

Scenario : a model duplicates a column that already exists on a model it
holds a ForeignKey to. Forms then force users to re-enter a value that's
already knowable from the FK, and the two can desynchronize. Classic
leak in long-lived Django projects.
"""

from django_doctor import Severity
from django_doctor.checks.fk_redundant import FkRedundantColumnCheck
from django_doctor.registry import Project


def _run(config=None):
    project = Project(config={"fk_redundant": config or {}})
    return list(FkRedundantColumnCheck().run(project))


def test_duplicate_fk_column_is_flagged():
    """RegimeMandat.regime_fiscal duplicates RegimeMandat.client.regime_fiscal."""
    findings = _run()
    matching = [
        f
        for f in findings
        if "RegimeMandat" in f.location and "regime_fiscal" in f.location
    ]
    assert matching, "RegimeMandat.regime_fiscal should have been flagged as redundant"
    f = matching[0]
    assert f.severity is Severity.WARNING
    assert f.rule == "fk_redundant.duplicate_via_fk"
    assert "client" in f.message  # the FK path
    assert "RegimeClient" in f.message  # the FK target model
    assert f.extra["fk"] == "client"
    assert f.extra["duplicated_field"] == "regime_fiscal"
    assert f.extra["related_model"] == "sample_app.RegimeClient"


def test_snapshot_field_is_not_flagged():
    """RegimeFactureSnapshot.regime_fiscal has help_text 'snapshot' → skip."""
    findings = _run()
    matching = [f for f in findings if "RegimeFactureSnapshot" in f.location]
    assert not matching, (
        f"Snapshot fields (help_text keyword) must not be flagged; got {matching}"
    )


def test_transitive_redundancy_flagged_via_direct_fk():
    """RegimePrestation.regime_fiscal duplicates RegimePrestation.mandat.regime_fiscal.
    (Transitive : Prestation → Mandat → regime. The check catches each 1-hop
    independently, so RegimePrestation.regime_fiscal is flagged because
    RegimeMandat.regime_fiscal exists.)"""
    findings = _run()
    matching = [
        f
        for f in findings
        if "RegimePrestation" in f.location and "regime_fiscal" in f.location
    ]
    assert matching, "RegimePrestation.regime_fiscal should have been flagged"


def test_column_with_no_matching_name_in_related_is_not_flagged():
    """RegimePrestation.notes has no counterpart on RegimeMandat → no finding."""
    findings = _run()
    matching = [
        f
        for f in findings
        if "RegimePrestation" in f.location and f.extra.get("duplicated_field") == "notes"
    ]
    assert not matching, f"notes should not be flagged; got {matching}"


def test_skip_fields_silences_specific_column():
    """Config ``skip_fields`` with explicit triplet must silence that finding."""
    findings = _run(
        {"skip_fields": ["sample_app.RegimeMandat.regime_fiscal"]}
    )
    matching = [
        f for f in findings if "RegimeMandat" in f.location and "regime_fiscal" in f.location
    ]
    assert not matching, (
        "skip_fields should silence RegimeMandat.regime_fiscal; "
        f"got {matching}"
    )


def test_skip_models_silences_whole_model():
    """Config ``skip_models`` drops the model entirely from the scan."""
    findings = _run({"skip_models": ["sample_app.RegimePrestation"]})
    matching = [f for f in findings if "RegimePrestation" in f.location]
    assert not matching


def test_non_duplicate_models_are_clean():
    """Widget and SilentWidget have no FKs with duplicated columns → quiet."""
    findings = _run()
    assert not any("Widget" in f.location for f in findings)
    assert not any("SilentWidget" in f.location for f in findings)


def test_shared_abstract_base_fields_are_not_flagged():
    """Fields inherited from a common abstract base (BaseModel / AuditBase)
    must NEVER be flagged — they're shared infrastructure, not duplication.
    """
    findings = _run()
    # AuditedChild has FK to AuditedParent; both inherit id/created_at/
    # updated_at/is_active from AuditBase. libelle is local on both but they
    # ARE locally duplicated (same type).
    shared_infra_fields = {"id", "created_at", "updated_at", "is_active"}
    for f in findings:
        if "Audited" in f.location:
            field = f.extra.get("duplicated_field", "")
            assert field not in shared_infra_fields, (
                f"shared infrastructure field {field!r} must not be flagged; "
                f"got {f}"
            )


def test_pk_is_never_flagged():
    """The primary key is identity, never redundancy — must be skipped
    even when an FK target has the same-named PK."""
    findings = _run()
    for f in findings:
        assert f.extra.get("duplicated_field") != "id", (
            f"PK must never be flagged; got {f}"
        )
        assert f.extra.get("duplicated_field") != "pk", (
            f"PK alias must never be flagged; got {f}"
        )


def test_scalar_duplication_is_skipped_by_default():
    """Two same-type scalars with the same name on model and FK target
    don't match by default (too many name-collision false positives on
    `description`, `notes`, etc.)."""
    findings = _run()
    # RegimePrestation has `libelle: CharField` ; RegimeMandat also has a
    # CharField named `numero`. Neither should be flagged in default mode.
    scalar_names = {"libelle", "numero", "notes"}
    for f in findings:
        dup = f.extra.get("duplicated_field", "")
        if "RegimePrestation" in f.location and dup in scalar_names:
            raise AssertionError(
                f"Scalar duplication flagged in default mode (shouldn't): {f}"
            )


def test_scalar_duplication_flagged_when_detect_scalar_true():
    """Opting in via `detect_scalar = True` brings back the scalar matches."""
    findings = _run({"detect_scalar": True})
    # Now at least some scalar duplicates should appear.
    scalar_duplicates = [
        f for f in findings
        if f.extra.get("duplicated_field") in {"libelle", "notes"}
    ]
    # We don't assert exact counts since it depends on other fixtures, but
    # the set must be strictly larger than the default-mode set.
    assert scalar_duplicates, (
        "detect_scalar = True should surface scalar duplicates that are "
        "hidden by default"
    )
