"""
Tests for prodsys models.
"""

