"""Prompt assembly utilities for agent system instructions.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PromptBuildContext:
    """Typed context for deterministic system prompt assembly.

    The field order encodes the canonical layer order. Empty or None values are
    skipped during rendering.
    """

    base_instruction: str
    date_time_context: str | None = None
    runtime_platform_hints: str | None = None
    durable_memory_guidance: str | None = None
    session_recall_guidance: str | None = None
    project_context: str | None = None
    compaction_summary: str | None = None
    model_steering: str | None = None
    middleware_prompts: tuple[str, ...] = ()


def build_system_prompt(context: PromptBuildContext) -> str:
    """Build a system prompt from ordered context layers.

    Args:
        context: Prompt context containing ordered optional layers.

    Returns:
        Combined system prompt with non-empty layers joined by double newlines.
    """
    parts: list[str] = []

    for layer in (
        context.date_time_context,
        context.base_instruction,
        context.runtime_platform_hints,
        context.durable_memory_guidance,
        context.session_recall_guidance,
        context.project_context,
        context.compaction_summary,
        context.model_steering,
    ):
        normalized = layer.strip() if isinstance(layer, str) else layer
        if normalized:
            parts.append(normalized)

    for middleware_prompt in context.middleware_prompts:
        normalized = middleware_prompt.strip() if isinstance(middleware_prompt, str) else middleware_prompt
        if normalized:
            parts.append(normalized)

    return "\n\n".join(parts)