"""Baseline smoke tests that run before full module tests exist."""

import subprocess
import sys

import meshtastic_gateway


def test_package_has_version():
    assert meshtastic_gateway.__version__
    assert meshtastic_gateway.__version__ != "0.0.0+unknown"


def test_cli_module_invocable():
    result = subprocess.run(
        [sys.executable, "-m", "meshtastic_gateway"],
        capture_output=True,
        text=True,
        check=True,
    )
    assert "meshtastic-gateway" in result.stdout
