"""CLI entry points for the meshtastic-gateway package."""

from __future__ import annotations

import sys

from . import __version__


def main() -> int:
    """Daemon entry point. Full implementation arrives in a later task."""
    print(f"meshtastic-gateway {__version__} (stub — not yet implemented)")
    return 0


def mesh_send_main() -> int:
    """HTTP client entry point. Full implementation arrives in a later task."""
    print(f"mesh-send {__version__} (stub — not yet implemented)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
