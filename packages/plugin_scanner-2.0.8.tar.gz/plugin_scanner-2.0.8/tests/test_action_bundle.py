"""Regression checks for the GitHub Action bundle and Marketplace packaging."""

from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent


def test_action_metadata_includes_marketplace_branding_and_fallback_install() -> None:
    action_text = (ROOT / "action" / "action.yml").read_text(encoding="utf-8")

    assert 'name: "HOL AI Plugin Scanner"' in action_text
    assert "branding:" in action_text
    assert 'icon: "check-circle"' in action_text
    assert 'color: "blue"' in action_text
    assert "actions/setup-python@a309ff8b426b58ec0e2a45f0f869d46889d02405" in action_text
    assert 'python3 -m pip install "pypi-attestations==' in action_text
    assert "install_source:" in action_text
    assert 'default: "pypi"' in action_text
    assert "INSTALL_SOURCE: ${{ inputs.install_source }}" in action_text
    assert "INSTALL_CISCO: ${{ inputs.install_cisco }}" in action_text
    assert 'if [ "$INSTALL_SOURCE" = "local" ]; then' in action_text
    assert "install_source=local requires the source repository checkout" in action_text
    assert 'python3 -m pip install "$LOCAL_SOURCE"' in action_text
    assert 'python3 -m pip install "$LOCAL_SOURCE[cisco]"' in action_text
    assert 'elif [ "$INSTALL_SOURCE" = "pypi" ]; then' in action_text
    assert (
        'python3 -m pip download --only-binary=:all: --no-deps --dest "$DIST_DIR" "plugin-scanner==${SCANNER_VERSION}"'
    ) in action_text
    assert "python3 -m pypi_attestations verify pypi \\" in action_text
    assert 'python3 -m pip install "$DIST_DIR/$DIST_BASENAME"' in action_text
    assert 'python3 -m pip install "cisco-ai-skill-scanner==${CISCO_VERSION}"' in action_text
    assert "scanner-version.txt" in action_text
    assert "cisco-version.txt" in action_text
    assert "pypi-attestations-version.txt" in action_text
    assert 'SCANNER_REPOSITORY="https://github.com/hashgraph-online/ai-plugin-scanner"' in action_text
    assert "write_step_summary:" in action_text
    assert "profile:" in action_text
    assert "config:" in action_text
    assert "baseline:" in action_text
    assert "online:" in action_text
    assert "upload_sarif:" in action_text
    assert "sarif_category:" in action_text
    assert "registry_payload_output:" in action_text
    assert "submission_enabled:" in action_text
    assert "policy_pass:" in action_text
    assert "verify_pass:" in action_text
    assert "grade_label:" in action_text
    assert "max_severity:" in action_text
    assert "findings_total:" in action_text
    assert "report_path:" in action_text
    assert "registry_payload_path:" in action_text
    assert "submission_issue_urls:" in action_text
    assert "pr_comment:" in action_text
    assert "pr_comment_style:" in action_text
    assert "pr_comment_max_findings:" in action_text
    assert "python3 -m codex_plugin_scanner.action_runner" in action_text
    assert "MODE: ${{ inputs.mode }}" in action_text
    assert "PROFILE: ${{ inputs.profile }}" in action_text
    assert "CONFIG: ${{ inputs.config }}" in action_text
    assert "BASELINE: ${{ inputs.baseline }}" in action_text
    assert "ONLINE: ${{ inputs.online }}" in action_text
    assert "value: ${{ steps.scan.outputs.score }}" in action_text
    assert "value: ${{ steps.scan.outputs.grade }}" in action_text
    assert "value: ${{ steps.scan.outputs.policy_pass }}" in action_text
    assert "value: ${{ steps.scan.outputs.verify_pass }}" in action_text
    assert "value: ${{ steps.scan.outputs.grade_label }}" in action_text
    assert "value: ${{ steps.scan.outputs.max_severity }}" in action_text
    assert "value: ${{ steps.scan.outputs.findings_total }}" in action_text
    assert "value: ${{ steps.scan.outputs.report_path }}" in action_text
    assert "value: ${{ steps.scan.outputs.registry_payload_path }}" in action_text
    assert "value: ${{ steps.scan.outputs.submission_eligible }}" in action_text
    assert "value: ${{ steps.scan.outputs.submission_performed }}" in action_text
    assert "value: ${{ steps.scan.outputs.submission_issue_urls }}" in action_text
    assert "value: ${{ steps.scan.outputs.submission_issue_numbers }}" in action_text
    assert "value: ${{ steps.scan.outputs.action_exit_code }}" in action_text
    assert "value: ${{ steps.scan.outputs.pr_comment_status }}" in action_text
    assert "value: ${{ steps.scan.outputs.pr_comment_id }}" in action_text
    assert "value: ${{ steps.scan.outputs.pr_comment_url }}" in action_text
    assert "Normalize action outputs" not in action_text
    assert "GITHUB_STEP_SUMMARY" in action_text
    assert "github/codeql-action/upload-sarif@" in action_text


def test_publish_workflow_attaches_marketplace_action_bundle() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "publish.yml").read_text(encoding="utf-8")

    assert "Build GitHub Action bundle" in workflow_text
    assert "ai-plugin-scanner-action-v${VERSION}.zip" in workflow_text
    assert "Attest GitHub release assets" in workflow_text
    assert "actions/attest-build-provenance@a2bbfa25375fe432b6a289bc6b6cd05ecd0c4c32" in workflow_text
    assert "attestations: write" in workflow_text
    assert "id-token: write" in workflow_text
    assert 'cp action/action.yml "${BUNDLE_ROOT}/action.yml"' in workflow_text
    assert """printf '%s\\n' "${VERSION}" > "${BUNDLE_ROOT}/scanner-version.txt" """[:-1] in workflow_text
    assert 'cp action/cisco-version.txt "${BUNDLE_ROOT}/cisco-version.txt"' in workflow_text
    assert 'cp action/pypi-attestations-version.txt "${BUNDLE_ROOT}/pypi-attestations-version.txt"' in workflow_text
    assert "dist/plugin-scanner-v${VERSION}.intoto.jsonl" in workflow_text
    assert "Collect release asset files" in workflow_text
    assert "find dist -maxdepth 1 -type f -print0 | sort -z" in workflow_text
    assert "mapfile -t RELEASE_ASSETS <<'EOF'" in workflow_text
    assert '"${RELEASE_ASSETS[@]}"' in workflow_text
    assert "subject-path: |" in workflow_text
    assert "dist/*" in workflow_text
    assert "Build Guard package (hol-guard)" in workflow_text
    assert "Build scanner package (plugin-scanner)" in workflow_text
    assert "Build codex compatibility alias (codex-plugin-scanner)" in workflow_text
    assert 'name = "plugin-scanner"' in workflow_text
    assert 'plugin-ecosystem-scanner = "codex_plugin_scanner.cli:main"' in workflow_text
    assert 'hol-guard = "codex_plugin_scanner.cli:main"' in workflow_text
    assert "codex-plugin-scanner" in workflow_text
    assert "cp pyproject.toml pyproject.toml.bak" in workflow_text
    assert "mv pyproject.toml.bak pyproject.toml" in workflow_text
    assert "uv tool install hol-guard==${VERSION}" in workflow_text
    assert "uv tool install plugin-scanner==${VERSION}" in workflow_text
    assert "uv tool install codex-plugin-scanner==${VERSION}" in workflow_text
    assert "docker pull ghcr.io/hashgraph-online/ai-plugin-scanner:${VERSION}" in workflow_text
    assert "dist/plugin-scanner-v${VERSION}.intoto.jsonl" in workflow_text
    assert "publish-container:" in workflow_text
    assert "packages: write" in workflow_text
    assert "docker/setup-buildx-action@b5ca514318bd6ebac0fb2aedd5d36ec1b5c232a2" in workflow_text
    assert "docker/login-action@9780b0c442fbb1117ed29e0efdff1e18412f7567" in workflow_text
    assert "docker/build-push-action@263435318d21b8e681c14492fe198d362a7d2c83" in workflow_text
    assert "ghcr.io/${{ github.repository }}" in workflow_text
    assert "${IMAGE_NAME}:latest" not in workflow_text
    assert "org.opencontainers.image.version=${{ needs.build.outputs.version }}" in workflow_text
    e2e_workflow_text = (ROOT / ".github" / "workflows" / "e2e-test.yml").read_text(encoding="utf-8")
    assert e2e_workflow_text.count("install_source: local") == 5


def test_ci_workflow_covers_cross_platform_runtime() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")

    assert "windows-latest" in workflow_text
    assert "macos-latest" in workflow_text


def test_scorecard_workflow_matches_official_install_pattern() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "scorecard.yml").read_text(encoding="utf-8")
    workflow = yaml.safe_load(workflow_text)

    assert "name: OpenSSF Scorecard" in workflow_text
    assert "permissions: read-all" in workflow_text
    assert "branches: [main]" in workflow_text
    assert workflow["jobs"]["scorecard"]["permissions"]["actions"] == "read"
    assert workflow["jobs"]["scorecard"]["permissions"]["contents"] == "read"
    assert "id-token: write" in workflow_text
    assert "security-events: write" in workflow_text
    assert 'uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd' in workflow_text
    assert 'uses: ossf/scorecard-action@4eaacf0543bb3f2c246792bd56e8cdeffafb205a' in workflow_text
    assert "results_file: results.sarif" in workflow_text
    assert "results_format: sarif" in workflow_text
    assert "publish_results: true" in workflow_text
    assert 'uses: actions/upload-artifact@bbbca2ddaa5d8feaa63e36b76fdaad77386f024f' in workflow_text
    assert "persist-credentials: false" in workflow_text
    assert "path: results.sarif" in workflow_text
    assert "retention-days: 5" in workflow_text
    assert workflow_text.count("if: always()") == 2
    assert 'uses: github/codeql-action/upload-sarif@c10b8064de6f491fea524254123dbe5e09572f13' in workflow_text
    assert "sarif_file: results.sarif" in workflow_text
    assert "if: always()" in workflow_text


def test_harness_smoke_workflow_covers_nightly_self_hosted_release_gate() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "harness-smoke.yml").read_text(encoding="utf-8")

    assert "name: Guard Harness Smoke" in workflow_text
    assert "schedule:" in workflow_text
    assert "workflow_dispatch:" in workflow_text
    assert "self-hosted" in workflow_text
    assert "linux" in workflow_text
    assert "macOS" in workflow_text
    assert "windows" in workflow_text
    assert "hol-guard detect codex" in workflow_text
    assert "hol-guard run codex" in workflow_text
    assert "--dry-run --default-action allow --json" in workflow_text
    assert "codex mcp list" in workflow_text
    assert "cursor-agent mcp list" in workflow_text
    assert "gemini --help" in workflow_text
    assert "opencode --help" in workflow_text
    assert "Codex release gate" in workflow_text
    assert "Claude or Cursor release gate" in workflow_text
    assert "Gemini or OpenCode release gate" in workflow_text


def test_codeql_workflow_has_stable_workspace_alias_and_source_root() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "codeql.yml").read_text(encoding="utf-8")

    assert "Provide legacy workspace alias for CodeQL default setup state" in workflow_text
    assert 'ln -sfn "$GITHUB_WORKSPACE" "$LEGACY_ROOT/codex-plugin-scanner"' in workflow_text
    assert "source-root: ." in workflow_text


def test_publish_action_repo_workflow_syncs_action_repository() -> None:
    workflow_text = (ROOT / ".github" / "workflows" / "publish-action-repo.yml").read_text(encoding="utf-8")

    assert "Publish GitHub Action Repository" in workflow_text
    assert "ACTION_REPO_TOKEN" in workflow_text
    assert "hashgraph-online/ai-plugin-scanner-action" in workflow_text
    assert "hashgraph-online/hol-codex-plugin-scanner-action" in workflow_text
    assert "Validate publication credentials" in workflow_text
    assert "Compute scanner package version" in workflow_text
    assert "paths:" not in workflow_text
    assert "if: secrets.ACTION_REPO_TOKEN != ''" not in workflow_text
    assert "ACTION_CANONICAL_REPOSITORY" in workflow_text
    assert "ACTION_COMPAT_REPOSITORY" in workflow_text
    assert "latest_release_tag() {" in workflow_text
    assert "latest_remote_tag() {" in workflow_text
    assert (
        'git ls-remote --tags --refs "https://x-access-token:${GH_TOKEN}@github.com/${target_repo}.git" "refs/tags/v*"'
    ) in workflow_text
    assert "awk -F" in workflow_text
    assert ("for candidate in ") in workflow_text
    assert '"$(latest_release_tag "$ACTION_CANONICAL_REPOSITORY")" \\' in workflow_text
    assert '"$(latest_release_tag "$ACTION_COMPAT_REPOSITORY")" \\' in workflow_text
    assert '"$(latest_remote_tag "$ACTION_CANONICAL_REPOSITORY")" \\' in workflow_text
    assert '"$(latest_remote_tag "$ACTION_COMPAT_REPOSITORY")"; do' in workflow_text
    assert """printf '%s\\n%s\\n' "$LAST_TAG" "$candidate" | sort -V | tail -n1""" in workflow_text
    assert (
        'git -C "$repo_dir" status --short -- action.yml README.md scanner-version.txt '
        "cisco-version.txt pypi-attestations-version.txt LICENSE SECURITY.md CONTRIBUTING.md"
    ) in workflow_text
    assert "SOURCE_REF" in workflow_text
    assert "fetch-depth: 0" in workflow_text
    assert 'gh repo create "$target_repo" --public --description "$repo_description" --clone' in workflow_text
    assert 'gh repo edit "$target_repo" --description "$repo_description"' in workflow_text
    assert 'gh repo clone "$target_repo" "$repo_dir" -- --depth 1' in workflow_text
    assert (
        'git -C "$repo_dir" remote set-url origin "https://x-access-token:${ACTION_REPO_TOKEN}@github.com/${target_repo}.git"'
    ) in workflow_text
    assert 'cp "${GITHUB_WORKSPACE}/action/action.yml" "${repo_dir}/action.yml"' in workflow_text
    assert """printf '%s\\n' "$SCANNER_VERSION" > "${repo_dir}/scanner-version.txt" """[:-1] in workflow_text
    assert 'cp "${GITHUB_WORKSPACE}/action/cisco-version.txt" "${repo_dir}/cisco-version.txt"' in workflow_text
    assert (
        'cp "${GITHUB_WORKSPACE}/action/pypi-attestations-version.txt" "${repo_dir}/pypi-attestations-version.txt"'
    ) in workflow_text
    assert 'git -C "$repo_dir" push origin HEAD:main' in workflow_text
    assert 'any_repo_changed="false"' in workflow_text
    assert 'repo_changed="false"' in workflow_text
    assert 'repo_changed="true"' in workflow_text
    assert (
        'printf \'%s\\t%s\\n\' "$target_repo" "$repo_dir" >> "$GITHUB_WORKSPACE/action-repos/publish-targets.tsv"'
    ) in workflow_text
    assert ': > "$GITHUB_WORKSPACE/action-repos/publish-targets.tsv"' in workflow_text
    assert 'if [ "$any_repo_changed" != "true" ]; then' in workflow_text
    assert "publish_action_release() {" in workflow_text
    assert "while IFS=$'\\t' read -r target_repo repo_dir; do" in workflow_text
    assert 'publish_action_release "$target_repo" "$repo_dir"' in workflow_text
    assert 'gh release view "${TAG}" --repo "$target_repo"' in workflow_text
    assert 'git -C "$repo_dir" ls-remote --tags origin "refs/tags/${TAG}"' in workflow_text
    assert "Refusing to publish action bundle with colliding existing tag ${TAG} in ${target_repo}." in workflow_text
    assert 'git -C "$repo_dir" push origin refs/tags/v1 --force' in workflow_text
    assert 'gh release create "${TAG}"' in workflow_text
    assert "--generate-notes" in workflow_text
    assert "Published automatically from ${SOURCE_SERVER_URL}/${SOURCE_REPOSITORY}/tree/${SOURCE_REF}" in workflow_text
    assert '"${GITHUB_WORKSPACE}/action/README.md"' in workflow_text
    assert '"${GITHUB_WORKSPACE}/action/README.legacy.md"' in workflow_text


def test_action_bundle_docs_live_in_action_readme() -> None:
    action_readme = (ROOT / "action" / "README.md").read_text(encoding="utf-8")

    assert "https://hol.org/brand/Logo_Whole_Dark.png" in action_readme
    assert "Latest Release" in action_readme
    assert "Marketplace-facing wrapper" in action_readme
    assert "root `action.yml` layout" in action_readme
    assert "published action bundle" in action_readme
    assert "Source of Truth" in action_readme
    assert "source-ai--plugin--scanner-111827" in action_readme
    assert "https://github.com/hashgraph-online/ai-plugin-scanner/tree/main/action" in action_readme
    assert "verifies its PyPI provenance" in action_readme
    assert "install_source: local" in action_readme
    assert "uses: ./action" in action_readme
    assert "ghcr.io/hashgraph-online/ai-plugin-scanner:<version>" in action_readme
    assert "online`, `submission_enabled`, and `upload_sarif`" in action_readme
    assert "registry_payload_output" in action_readme
    assert "grade_label" in action_readme
    assert "max_severity" in action_readme
    assert "submission issue" in action_readme
    assert "awesome-codex-plugins" in action_readme
    assert "publish-action-repo.yml" in action_readme
    assert "hashgraph-online/ai-plugin-scanner-action@v1" in action_readme
    assert "hashgraph-online/hol-codex-plugin-scanner-action@v1" in action_readme
    assert "actions/checkout@v4" in action_readme
    assert "actions/github-script@v7" in action_readme
    assert "opt-in Cisco skill-scanner dependency used by this repo" in action_readme


def test_legacy_action_readme_marks_compatibility_alias() -> None:
    legacy_readme = (ROOT / "action" / "README.legacy.md").read_text(encoding="utf-8")

    assert "compatibility alias" in legacy_readme
    assert "hashgraph-online/hol-codex-plugin-scanner-action@v1" in legacy_readme
    assert "hashgraph-online/ai-plugin-scanner-action@v1" in legacy_readme
    assert "same reviewed root bundle" in legacy_readme


def test_readme_uses_stable_apache_license_badge() -> None:
    readme = (ROOT / "README.md").read_text(encoding="utf-8")

    assert "https://img.shields.io/badge/license-Apache--2.0-blue.svg" in readme
    assert "https://img.shields.io/github/license/hashgraph-online/codex-plugin-scanner" not in readme
    assert "https://img.shields.io/pypi/v/hol-guard" in readme
    assert "https://img.shields.io/pypi/v/plugin-scanner" in readme
    assert "https://img.shields.io/pypi/dm/hol-guard" in readme
    assert "https://img.shields.io/pypi/dm/plugin-scanner" in readme
    assert "https://img.shields.io/badge/python-3.10%2B-" in readme
    assert "publish-action-repo.yml" in readme
    assert "docs/github-action-marketplace.md" not in readme
    assert "ghcr.io/hashgraph-online/ai-plugin-scanner:<version>" in readme
    assert "https://pypi.org/project/hol-guard/" in readme
    assert "https://pypi.org/project/plugin-scanner/" in readme
    assert "pip install codex-plugin-scanner" not in readme
    assert "codex-plugin-scanner verify" not in readme
    assert "Container Image" in readme
    assert "hashgraph-online/ai-plugin-scanner-action@v1" in readme
    assert readme.count("<details>") >= 3


def test_container_files_exist_for_enterprise_distribution() -> None:
    dockerfile_text = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    dockerignore_text = (ROOT / ".dockerignore").read_text(encoding="utf-8")
    docker_requirements_text = (ROOT / "docker-requirements.txt").read_text(encoding="utf-8")

    assert "FROM python:3.12-slim@sha256:" in dockerfile_text
    assert "cat <<'EOF' >/usr/local/bin/codex-plugin-scanner" in dockerfile_text
    assert 'ENTRYPOINT ["codex-plugin-scanner"]' in dockerfile_text
    assert "COPY docker-requirements.txt LICENSE README.md /app/" in dockerfile_text
    assert "python3 -m pip install --require-hashes -r /app/docker-requirements.txt" in dockerfile_text
    assert dockerfile_text.index("COPY docker-requirements.txt LICENSE README.md /app/") < dockerfile_text.index(
        "RUN python3 -m pip install --require-hashes -r /app/docker-requirements.txt"
    )
    assert dockerfile_text.index("RUN python3 -m pip install --require-hashes -r /app/docker-requirements.txt") < (
        dockerfile_text.index("COPY src /app/src")
    )
    assert 'SOURCE_ROOT = "/app/src"' in dockerfile_text
    assert 'WORKSPACE = "/workspace"' in dockerfile_text
    assert "from codex_plugin_scanner.cli import main" in dockerfile_text
    assert "USER scanner" in dockerfile_text
    assert "rich==14.2.0" in docker_requirements_text
    assert "--hash=sha256:" in docker_requirements_text
    assert ".git" in dockerignore_text
    assert "tests" in dockerignore_text


def test_license_declares_spdx_identifier() -> None:
    license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")

    assert license_text.startswith("SPDX-License-Identifier: Apache-2.0")
