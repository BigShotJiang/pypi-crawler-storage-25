"""Error hierarchy for the PYRX Synapse Python SDK.

Matches the Node SDK error classes exactly:
- SynapseError (base)
- SynapseAuthError (401, 403 scope)
- SynapseRateLimitError (429)
- SynapsePlanLimitError (403 plan_limit_reached)
- SynapseValidationError (422)
"""

from __future__ import annotations


class SynapseError(Exception):
    """Base error for all Synapse API errors."""

    def __init__(
        self,
        message: str,
        status: int,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code
        self.request_id = request_id


class SynapseAuthError(SynapseError):
    """Raised on 401 Unauthorized or 403 Forbidden (scope mismatch)."""


class SynapseRateLimitError(SynapseError):
    """Raised on 429 Too Many Requests."""

    def __init__(
        self,
        message: str,
        status: int,
        code: str | None = None,
        request_id: str | None = None,
        retry_after: float = 60.0,
    ) -> None:
        super().__init__(message, status, code, request_id)
        self.retry_after = retry_after


class SynapsePlanLimitError(SynapseError):
    """Raised on 403 with code 'plan_limit_reached'."""

    def __init__(
        self,
        message: str,
        status: int,
        code: str | None = None,
        request_id: str | None = None,
        limit_type: str = "",
        current: int = 0,
        maximum: int = 0,
        plan: str = "",
    ) -> None:
        super().__init__(message, status, code, request_id)
        self.limit_type = limit_type
        self.current = current
        self.maximum = maximum
        self.plan = plan


class SynapseValidationError(SynapseError):
    """Raised on 422 Unprocessable Entity (validation failures)."""

    def __init__(
        self,
        message: str,
        status: int,
        code: str | None = None,
        request_id: str | None = None,
        errors: list[dict[str, str]] | None = None,
    ) -> None:
        super().__init__(message, status, code, request_id)
        self.errors: list[dict[str, str]] = errors or []


def _to_int(value: object) -> int:
    """Safely convert an object to int, defaulting to 0."""
    if isinstance(value, int):
        return value
    if isinstance(value, (str, float)):
        return int(value)
    return 0


def map_error(
    status: int,
    body: dict[str, object],
    retry_after: float | None = None,
) -> SynapseError:
    """Map an HTTP status and response body to the appropriate SynapseError subclass."""
    detail = body.get("detail")
    msg_field = body.get("message")
    message = str(detail) if detail else (str(msg_field) if msg_field else f"HTTP {status}")
    code = str(body["code"]) if "code" in body else None
    request_id = str(body["request_id"]) if "request_id" in body else None

    if status == 429:
        return SynapseRateLimitError(
            message, status, code, request_id, retry_after=retry_after or 60.0
        )

    if status == 403 and code == "plan_limit_reached":
        return SynapsePlanLimitError(
            message,
            status,
            code,
            request_id,
            limit_type=str(body.get("limit_type", "")),
            current=_to_int(body.get("current")),
            maximum=_to_int(body.get("maximum")),
            plan=str(body.get("plan", "")),
        )

    if status in (401, 403):
        return SynapseAuthError(message, status, code, request_id)

    if status == 422:
        raw_errors = body.get("errors")
        errors: list[dict[str, str]] = []
        if isinstance(raw_errors, list):
            for entry in raw_errors:
                if isinstance(entry, dict):
                    errors.append(
                        {
                            "field": str(entry.get("field", "")),
                            "message": str(entry.get("message") or entry.get("msg", "")),
                        }
                    )
        return SynapseValidationError(message, status, code, request_id, errors=errors)

    return SynapseError(message, status, code, request_id)
