"""Svix webhook signature verification.

Matches the Node SDK's verifyWebhook() implementation exactly:
- HMAC-SHA256 signature verification
- Timestamp tolerance (5 minutes)
- Support for multiple signatures (key rotation)
- whsec_ prefix stripping and base64 decoding
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import time

TOLERANCE_SECONDS = 300  # 5 minutes


def verify_webhook(
    payload: str,
    headers: dict[str, str],
    secret: str,
    *,
    disable_timestamp_check: bool = False,
) -> dict[str, object]:
    """Verify a webhook signature from Synapse (Svix format).

    Args:
        payload: The raw request body as a string.
        headers: Dict containing 'svix-id', 'svix-timestamp', and 'svix-signature'.
        secret: The webhook signing secret (starts with "whsec_").
        disable_timestamp_check: If True, skip timestamp tolerance check (testing only).

    Returns:
        The parsed webhook event payload as a dict.

    Raises:
        ValueError: If the signature is invalid, timestamp is expired, or headers are missing.
    """
    svix_id = headers.get("svix-id")
    svix_timestamp = headers.get("svix-timestamp")
    svix_signature = headers.get("svix-signature")

    if not svix_id or not svix_timestamp or not svix_signature:
        raise ValueError(
            "Missing required webhook headers: svix-id, svix-timestamp, svix-signature"
        )

    # Validate timestamp (prevent replay attacks)
    if not disable_timestamp_check:
        try:
            timestamp_sec = int(svix_timestamp)
        except ValueError:
            raise ValueError("Invalid svix-timestamp header")  # noqa: B904

        now_sec = math.floor(time.time())
        diff = abs(now_sec - timestamp_sec)
        if diff > TOLERANCE_SECONDS:
            raise ValueError(
                f"Webhook timestamp too old ({diff}s > {TOLERANCE_SECONDS}s tolerance)"
            )

    # Decode secret: strip "whsec_" prefix and base64-decode
    if secret.startswith("whsec_"):
        secret_bytes = base64.b64decode(secret[6:])
    else:
        secret_bytes = base64.b64decode(secret)

    # Compute expected signature
    signed_content = f"{svix_id}.{svix_timestamp}.{payload}"
    expected_signature = base64.b64encode(
        hmac.new(secret_bytes, signed_content.encode(), hashlib.sha256).digest()
    ).decode()

    # Compare against all provided signatures (svix sends multiple for key rotation)
    signatures = svix_signature.split(" ")
    verified = False

    for sig in signatures:
        parts = sig.split(",", 1)
        if len(parts) < 2:
            continue

        sig_value = parts[1]
        try:
            sig_bytes = base64.b64decode(sig_value)
            expected_bytes = base64.b64decode(expected_signature)

            if len(sig_bytes) == len(expected_bytes) and hmac.compare_digest(
                sig_bytes, expected_bytes
            ):
                verified = True
                break
        except Exception:
            # Skip malformed signatures
            continue

    if not verified:
        raise ValueError("Webhook signature verification failed")

    # Parse and return the event
    try:
        result: dict[str, object] = json.loads(payload)
        return result
    except json.JSONDecodeError:
        raise ValueError("Failed to parse webhook payload as JSON")  # noqa: B904
