"""Synchronous Synapse client using httpx.Client."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx

from ._base import BaseSynapseClient, sync_request_with_retry

if TYPE_CHECKING:
    from types import TracebackType

    from ._types import (
        ContactUpdateParams,
        IdentifyParams,
        TemplateCreateParams,
        TemplatePreviewParams,
        TemplateUpdateParams,
        TrackParams,
    )

from ._types import (
    BatchTrackResponse,
    BulkContactResponse,
    ContactListMeta,
    ContactListResponse,
    ContactResponse,
    SendResponse,
    TemplatePreviewResponse,
    TemplateResponse,
    TrackResponse,
)


class _ContactsClient:
    """Contact management sub-client (sync)."""

    def __init__(self, synapse: Synapse) -> None:
        self._synapse = synapse

    def list(
        self,
        search: str | None = None,
        page: int | None = None,
        per_page: int | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
    ) -> ContactListResponse:
        """List contacts with optional search, pagination, and sorting."""
        params: dict[str, str] = {}
        if search is not None:
            params["search"] = search
        if page is not None:
            params["page"] = str(page)
        if per_page is not None:
            params["per_page"] = str(per_page)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order

        raw = self._synapse._request("GET", "/v1/contacts", params=params)
        return _parse_contact_list(raw)

    def get(self, contact_id: str) -> ContactResponse:
        """Get a single contact by ID."""
        raw = self._synapse._request("GET", f"/v1/contacts/{contact_id}")
        return _parse_contact(raw)

    def update(self, external_id: str, data: ContactUpdateParams) -> ContactResponse:
        """Update a contact by external ID."""
        raw = self._synapse._request("PATCH", f"/v1/contacts/{external_id}", body=dict(data))
        return _parse_contact(raw)

    def delete(self, external_id: str) -> None:
        """Delete a contact by external ID."""
        self._synapse._request("DELETE", f"/v1/contacts/{external_id}")


class _TemplatesClient:
    """Template management sub-client (sync)."""

    def __init__(self, synapse: Synapse) -> None:
        self._synapse = synapse

    def list(self) -> list[TemplateResponse]:
        """List all email templates."""
        raw = self._synapse._request("GET", "/v1/templates")
        if isinstance(raw, list):
            return [_parse_template(t) for t in raw]
        return []

    def get(self, slug: str) -> TemplateResponse:
        """Get a single template by slug."""
        raw = self._synapse._request("GET", f"/v1/templates/{slug}")
        return _parse_template(raw)

    def create(self, params: TemplateCreateParams) -> TemplateResponse:
        """Create a new email template."""
        raw = self._synapse._request("POST", "/v1/templates", body=dict(params))
        return _parse_template(raw)

    def update(self, slug: str, params: TemplateUpdateParams) -> TemplateResponse:
        """Update an existing template by slug."""
        raw = self._synapse._request("PUT", f"/v1/templates/{slug}", body=dict(params))
        return _parse_template(raw)

    def delete(self, slug: str) -> None:
        """Delete a template by slug."""
        self._synapse._request("DELETE", f"/v1/templates/{slug}")

    def preview(self, slug: str, params: TemplatePreviewParams) -> TemplatePreviewResponse:
        """Preview a rendered template with sample data."""
        raw = self._synapse._request("POST", f"/v1/templates/{slug}/preview", body=dict(params))
        return _parse_template_preview(raw)


class Synapse(BaseSynapseClient):
    """Synchronous PYRX Synapse client.

    Usage::

        with Synapse(api_key="gck_live_xxx", workspace_id="ws_xxx") as client:
            result = client.track(external_id="user_123", event_name="purchase")
    """

    def __init__(
        self,
        api_key: str,
        *,
        workspace_id: str,
        base_url: str = "https://synapse-api.pyrx.tech",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        super().__init__(
            api_key,
            workspace_id=workspace_id,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.Client(timeout=timeout)
        self.contacts = _ContactsClient(self)
        self.templates = _TemplatesClient(self)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Synapse:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Internal request dispatcher
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        body: dict[str, object] | None = None,
        params: dict[str, str] | None = None,
    ) -> Any:
        return sync_request_with_retry(
            self._http,
            method,
            self._url(path),
            self._headers(),
            self.max_retries,
            body=body,
            params=params,
        )

    # ------------------------------------------------------------------
    # Data-in: track
    # ------------------------------------------------------------------

    def track(
        self,
        *,
        external_id: str,
        event_name: str,
        attributes: dict[str, object] | None = None,
        contact: dict[str, object] | None = None,
        idempotency_key: str | None = None,
        occurred_at: str | None = None,
    ) -> TrackResponse:
        """Track a single event."""
        body: dict[str, object] = {
            "external_id": external_id,
            "event_name": event_name,
        }
        if attributes is not None:
            body["attributes"] = attributes
        if contact is not None:
            body["contact"] = contact
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        if occurred_at is not None:
            body["occurred_at"] = occurred_at

        raw = self._request("POST", "/v1/events", body=body)
        return _parse_track(raw)

    def track_batch(self, *, events: list[TrackParams]) -> BatchTrackResponse:
        """Track a batch of events (max 50)."""
        body: dict[str, object] = {"events": events}
        raw = self._request("POST", "/v1/events/batch", body=body)
        return _parse_batch_track(raw)

    # ------------------------------------------------------------------
    # Data-in: identify
    # ------------------------------------------------------------------

    def identify(
        self,
        *,
        external_id: str,
        email: str | None = None,
        phone: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        timezone: str | None = None,
        locale: str | None = None,
        properties: dict[str, object] | None = None,
        tags: list[str] | None = None,
    ) -> ContactResponse:
        """Identify (create or update) a single contact."""
        body: dict[str, object] = {"external_id": external_id}
        if email is not None:
            body["email"] = email
        if phone is not None:
            body["phone"] = phone
        if first_name is not None:
            body["first_name"] = first_name
        if last_name is not None:
            body["last_name"] = last_name
        if timezone is not None:
            body["timezone"] = timezone
        if locale is not None:
            body["locale"] = locale
        if properties is not None:
            body["properties"] = properties
        if tags is not None:
            body["tags"] = tags

        raw = self._request("POST", "/v1/contacts", body=body)
        return _parse_contact(raw)

    def identify_batch(
        self,
        *,
        contacts: list[IdentifyParams],
        on_conflict: str | None = None,
    ) -> BulkContactResponse:
        """Identify a batch of contacts (max 1000)."""
        body: dict[str, object] = {"contacts": contacts}
        if on_conflict is not None:
            body["on_conflict"] = on_conflict

        raw = self._request("POST", "/v1/contacts/bulk", body=body)
        return _parse_bulk_contact(raw)

    # ------------------------------------------------------------------
    # Data-in: send
    # ------------------------------------------------------------------

    def send(
        self,
        *,
        template_slug: str,
        to: dict[str, str],
        attributes: dict[str, object] | None = None,
        idempotency_key: str | None = None,
    ) -> SendResponse:
        """Send a transactional email using a template."""
        body: dict[str, object] = {
            "template_slug": template_slug,
            "to": to,
        }
        if attributes is not None:
            body["attributes"] = attributes
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key

        raw = self._request("POST", "/v1/send", body=body)
        return _parse_send(raw)


# ---------------------------------------------------------------------------
# Response parsers
# ---------------------------------------------------------------------------


def _parse_track(raw: object) -> TrackResponse:
    d = raw if isinstance(raw, dict) else {}
    return TrackResponse(
        event_id=str(d.get("event_id", "")),
        status=str(d.get("status", "")),
    )


def _parse_batch_track(raw: object) -> BatchTrackResponse:
    d = raw if isinstance(raw, dict) else {}
    return BatchTrackResponse(
        accepted=int(d.get("accepted", 0)),
        rejected=int(d.get("rejected", 0)),
    )


def _parse_contact(raw: object) -> ContactResponse:
    d = raw if isinstance(raw, dict) else {}
    return ContactResponse(
        id=str(d.get("id", "")),
        external_id=str(d.get("external_id", "")),
        email=d.get("email"),
        phone=d.get("phone"),
        first_name=d.get("first_name"),
        last_name=d.get("last_name"),
        timezone=d.get("timezone"),
        locale=d.get("locale"),
        properties=d.get("properties") or {},
        tags=d.get("tags") or [],
        created_at=str(d.get("created_at", "")),
        updated_at=str(d.get("updated_at", "")),
    )


def _parse_contact_list(raw: object) -> ContactListResponse:
    d = raw if isinstance(raw, dict) else {}
    data_raw = d.get("data", [])
    contacts = [_parse_contact(c) for c in data_raw] if isinstance(data_raw, list) else []
    meta_raw = d.get("meta", {})
    m = meta_raw if isinstance(meta_raw, dict) else {}
    meta = ContactListMeta(
        total=int(m.get("total", 0)),
        page=int(m.get("page", 0)),
        per_page=int(m.get("per_page", 0)),
        total_pages=int(m.get("total_pages", 0)),
    )
    return ContactListResponse(data=contacts, meta=meta)


def _parse_bulk_contact(raw: object) -> BulkContactResponse:
    d = raw if isinstance(raw, dict) else {}
    return BulkContactResponse(
        total=int(d.get("total", 0)),
        created=int(d.get("created", 0)),
        updated=int(d.get("updated", 0)),
        skipped=int(d.get("skipped", 0)),
        errors=d.get("errors") or [],
    )


def _parse_send(raw: object) -> SendResponse:
    d = raw if isinstance(raw, dict) else {}
    return SendResponse(
        email_log_id=str(d.get("email_log_id", "")),
        status=str(d.get("status", "")),
    )


def _parse_template(raw: object) -> TemplateResponse:
    d = raw if isinstance(raw, dict) else {}
    return TemplateResponse(
        id=str(d.get("id", "")),
        name=str(d.get("name", "")),
        slug=str(d.get("slug", "")),
        subject=str(d.get("subject", "")),
        body_html=str(d.get("body_html", "")),
        sender_name=d.get("sender_name"),
        from_email=d.get("from_email"),
        reply_to=d.get("reply_to"),
        content_type=d.get("content_type"),
        created_at=str(d.get("created_at", "")),
        updated_at=str(d.get("updated_at", "")),
    )


def _parse_template_preview(raw: object) -> TemplatePreviewResponse:
    d = raw if isinstance(raw, dict) else {}
    return TemplatePreviewResponse(
        subject=d.get("subject"),
        html=d.get("html"),
        suppressed=bool(d.get("suppressed", False)),
        suppressed_reason=d.get("suppressed_reason"),
    )
