"""Type definitions for the PYRX Synapse Python SDK.

Uses TypedDict for request params and frozen dataclasses for responses,
matching the Node SDK's type surface exactly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, TypedDict

from typing_extensions import NotRequired

# ---------------------------------------------------------------------------
# Data-in: track
# ---------------------------------------------------------------------------


class TrackParams(TypedDict):
    external_id: str
    event_name: str
    attributes: NotRequired[dict[str, object]]
    contact: NotRequired[dict[str, object]]
    idempotency_key: NotRequired[str]
    occurred_at: NotRequired[str]


class TrackBatchParams(TypedDict):
    events: list[TrackParams]


@dataclass(frozen=True)
class TrackResponse:
    event_id: str
    status: str


@dataclass(frozen=True)
class BatchTrackResponse:
    accepted: int
    rejected: int


# ---------------------------------------------------------------------------
# Data-in: identify
# ---------------------------------------------------------------------------


class IdentifyParams(TypedDict):
    external_id: str
    email: NotRequired[str]
    phone: NotRequired[str]
    first_name: NotRequired[str]
    last_name: NotRequired[str]
    timezone: NotRequired[str]
    locale: NotRequired[str]
    properties: NotRequired[dict[str, object]]
    tags: NotRequired[list[str]]


class IdentifyBatchParams(TypedDict):
    contacts: list[IdentifyParams]
    on_conflict: NotRequired[Literal["merge", "skip", "replace"]]


@dataclass(frozen=True)
class ContactResponse:
    id: str
    external_id: str
    email: str | None = None
    phone: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    timezone: str | None = None
    locale: str | None = None
    properties: dict[str, object] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""


@dataclass(frozen=True)
class BulkContactResponse:
    total: int
    created: int
    updated: int
    skipped: int
    errors: list[dict[str, object]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Data-in: send
# ---------------------------------------------------------------------------


class SendToParams(TypedDict):
    user_id: str
    email: str
    first_name: NotRequired[str]
    last_name: NotRequired[str]


class SendParams(TypedDict):
    template_slug: str
    to: SendToParams
    attributes: NotRequired[dict[str, object]]
    idempotency_key: NotRequired[str]


@dataclass(frozen=True)
class SendResponse:
    email_log_id: str
    status: str


# ---------------------------------------------------------------------------
# Contacts management
# ---------------------------------------------------------------------------


class ContactListParams(TypedDict, total=False):
    search: str
    page: int
    per_page: int
    sort_by: str
    sort_order: Literal["asc", "desc"]


@dataclass(frozen=True)
class ContactListMeta:
    total: int
    page: int
    per_page: int
    total_pages: int


@dataclass(frozen=True)
class ContactListResponse:
    data: list[ContactResponse]
    meta: ContactListMeta


class ContactUpdateParams(TypedDict, total=False):
    email: str
    properties: dict[str, object]
    tags: list[str]
    add_tags: list[str]
    remove_tags: list[str]


# ---------------------------------------------------------------------------
# Templates management
# ---------------------------------------------------------------------------


class TemplateCreateParams(TypedDict):
    name: str
    slug: str
    subject: str
    body_html: str
    sender_name: str
    from_email: str
    reply_to: NotRequired[str]
    content_type: NotRequired[str]


class TemplateUpdateParams(TypedDict, total=False):
    name: str
    subject: str
    body_html: str
    sender_name: str
    from_email: str


@dataclass(frozen=True)
class TemplateResponse:
    id: str
    name: str
    slug: str
    subject: str
    body_html: str
    sender_name: str | None = None
    from_email: str | None = None
    reply_to: str | None = None
    content_type: str | None = None
    created_at: str = ""
    updated_at: str = ""


class TemplatePreviewParams(TypedDict, total=False):
    contact: dict[str, object]
    event: dict[str, object]


@dataclass(frozen=True)
class TemplatePreviewResponse:
    subject: str | None
    html: str | None
    suppressed: bool
    suppressed_reason: str | None
