"""Asynchronous Synapse client using httpx.AsyncClient."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx

from ._base import BaseSynapseClient, async_request_with_retry
from ._client import (
    _parse_batch_track,
    _parse_bulk_contact,
    _parse_contact,
    _parse_contact_list,
    _parse_send,
    _parse_template,
    _parse_template_preview,
    _parse_track,
)

if TYPE_CHECKING:
    from types import TracebackType

    from ._types import (
        BatchTrackResponse,
        BulkContactResponse,
        ContactListResponse,
        ContactResponse,
        ContactUpdateParams,
        IdentifyParams,
        SendResponse,
        TemplateCreateParams,
        TemplatePreviewParams,
        TemplatePreviewResponse,
        TemplateResponse,
        TemplateUpdateParams,
        TrackParams,
        TrackResponse,
    )


class _AsyncContactsClient:
    """Contact management sub-client (async)."""

    def __init__(self, synapse: AsyncSynapse) -> None:
        self._synapse = synapse

    async def list(
        self,
        search: str | None = None,
        page: int | None = None,
        per_page: int | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
    ) -> ContactListResponse:
        """List contacts with optional search, pagination, and sorting."""
        params: dict[str, str] = {}
        if search is not None:
            params["search"] = search
        if page is not None:
            params["page"] = str(page)
        if per_page is not None:
            params["per_page"] = str(per_page)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order

        raw = await self._synapse._request("GET", "/v1/contacts", params=params)
        return _parse_contact_list(raw)

    async def get(self, contact_id: str) -> ContactResponse:
        """Get a single contact by ID."""
        raw = await self._synapse._request("GET", f"/v1/contacts/{contact_id}")
        return _parse_contact(raw)

    async def update(self, external_id: str, data: ContactUpdateParams) -> ContactResponse:
        """Update a contact by external ID."""
        raw = await self._synapse._request("PATCH", f"/v1/contacts/{external_id}", body=dict(data))
        return _parse_contact(raw)

    async def delete(self, external_id: str) -> None:
        """Delete a contact by external ID."""
        await self._synapse._request("DELETE", f"/v1/contacts/{external_id}")


class _AsyncTemplatesClient:
    """Template management sub-client (async)."""

    def __init__(self, synapse: AsyncSynapse) -> None:
        self._synapse = synapse

    async def list(self) -> list[TemplateResponse]:
        """List all email templates."""
        raw = await self._synapse._request("GET", "/v1/templates")
        if isinstance(raw, list):
            return [_parse_template(t) for t in raw]
        return []

    async def get(self, slug: str) -> TemplateResponse:
        """Get a single template by slug."""
        raw = await self._synapse._request("GET", f"/v1/templates/{slug}")
        return _parse_template(raw)

    async def create(self, params: TemplateCreateParams) -> TemplateResponse:
        """Create a new email template."""
        raw = await self._synapse._request("POST", "/v1/templates", body=dict(params))
        return _parse_template(raw)

    async def update(self, slug: str, params: TemplateUpdateParams) -> TemplateResponse:
        """Update an existing template by slug."""
        raw = await self._synapse._request("PUT", f"/v1/templates/{slug}", body=dict(params))
        return _parse_template(raw)

    async def delete(self, slug: str) -> None:
        """Delete a template by slug."""
        await self._synapse._request("DELETE", f"/v1/templates/{slug}")

    async def preview(self, slug: str, params: TemplatePreviewParams) -> TemplatePreviewResponse:
        """Preview a rendered template with sample data."""
        raw = await self._synapse._request(
            "POST", f"/v1/templates/{slug}/preview", body=dict(params)
        )
        return _parse_template_preview(raw)


class AsyncSynapse(BaseSynapseClient):
    """Asynchronous PYRX Synapse client.

    Usage::

        async with AsyncSynapse(api_key="gck_live_xxx", workspace_id="ws_xxx") as client:
            result = await client.track(external_id="user_123", event_name="purchase")
    """

    def __init__(
        self,
        api_key: str,
        *,
        workspace_id: str,
        base_url: str = "https://synapse-api.pyrx.tech",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        super().__init__(
            api_key,
            workspace_id=workspace_id,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.AsyncClient(timeout=timeout)
        self.contacts = _AsyncContactsClient(self)
        self.templates = _AsyncTemplatesClient(self)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncSynapse:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Internal request dispatcher
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        body: dict[str, object] | None = None,
        params: dict[str, str] | None = None,
    ) -> Any:
        return await async_request_with_retry(
            self._http,
            method,
            self._url(path),
            self._headers(),
            self.max_retries,
            body=body,
            params=params,
        )

    # ------------------------------------------------------------------
    # Data-in: track
    # ------------------------------------------------------------------

    async def track(
        self,
        *,
        external_id: str,
        event_name: str,
        attributes: dict[str, object] | None = None,
        contact: dict[str, object] | None = None,
        idempotency_key: str | None = None,
        occurred_at: str | None = None,
    ) -> TrackResponse:
        """Track a single event."""
        body: dict[str, object] = {
            "external_id": external_id,
            "event_name": event_name,
        }
        if attributes is not None:
            body["attributes"] = attributes
        if contact is not None:
            body["contact"] = contact
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        if occurred_at is not None:
            body["occurred_at"] = occurred_at

        raw = await self._request("POST", "/v1/events", body=body)
        return _parse_track(raw)

    async def track_batch(self, *, events: list[TrackParams]) -> BatchTrackResponse:
        """Track a batch of events (max 50)."""
        body: dict[str, object] = {"events": events}
        raw = await self._request("POST", "/v1/events/batch", body=body)
        return _parse_batch_track(raw)

    # ------------------------------------------------------------------
    # Data-in: identify
    # ------------------------------------------------------------------

    async def identify(
        self,
        *,
        external_id: str,
        email: str | None = None,
        phone: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        timezone: str | None = None,
        locale: str | None = None,
        properties: dict[str, object] | None = None,
        tags: list[str] | None = None,
    ) -> ContactResponse:
        """Identify (create or update) a single contact."""
        body: dict[str, object] = {"external_id": external_id}
        if email is not None:
            body["email"] = email
        if phone is not None:
            body["phone"] = phone
        if first_name is not None:
            body["first_name"] = first_name
        if last_name is not None:
            body["last_name"] = last_name
        if timezone is not None:
            body["timezone"] = timezone
        if locale is not None:
            body["locale"] = locale
        if properties is not None:
            body["properties"] = properties
        if tags is not None:
            body["tags"] = tags

        raw = await self._request("POST", "/v1/contacts", body=body)
        return _parse_contact(raw)

    async def identify_batch(
        self,
        *,
        contacts: list[IdentifyParams],
        on_conflict: str | None = None,
    ) -> BulkContactResponse:
        """Identify a batch of contacts (max 1000)."""
        body: dict[str, object] = {"contacts": contacts}
        if on_conflict is not None:
            body["on_conflict"] = on_conflict

        raw = await self._request("POST", "/v1/contacts/bulk", body=body)
        return _parse_bulk_contact(raw)

    # ------------------------------------------------------------------
    # Data-in: send
    # ------------------------------------------------------------------

    async def send(
        self,
        *,
        template_slug: str,
        to: dict[str, str],
        attributes: dict[str, object] | None = None,
        idempotency_key: str | None = None,
    ) -> SendResponse:
        """Send a transactional email using a template."""
        body: dict[str, object] = {
            "template_slug": template_slug,
            "to": to,
        }
        if attributes is not None:
            body["attributes"] = attributes
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key

        raw = await self._request("POST", "/v1/send", body=body)
        return _parse_send(raw)
