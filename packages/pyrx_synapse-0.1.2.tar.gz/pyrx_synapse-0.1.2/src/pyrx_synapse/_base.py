"""Shared base logic for sync and async Synapse clients.

Handles: config, URL building, headers, error mapping, retry.
"""

from __future__ import annotations

import random
import time
from typing import Literal

import httpx

from ._errors import SynapseError, SynapseRateLimitError, map_error

VERSION = "0.1.0"

RETRYABLE_STATUSES = frozenset({429, 500, 502, 503, 504})
MAX_BACKOFF_SEC = 30.0
JITTER_MAX_SEC = 0.5

Environment = Literal["test", "live", "unknown"]


def _detect_environment(api_key: str) -> Environment:
    if api_key.startswith("gck_test_"):
        return "test"
    if api_key.startswith("gck_live_"):
        return "live"
    return "unknown"


def _is_retryable(error: Exception) -> bool:
    if isinstance(error, SynapseError):
        return error.status in RETRYABLE_STATUSES
    # Network-level errors (timeouts, connection refused)
    return isinstance(error, (httpx.TimeoutException, httpx.ConnectError))


def _backoff_delay(attempt: int, error: Exception | None = None) -> float:
    """Calculate backoff delay in seconds for the given attempt."""
    if isinstance(error, SynapseRateLimitError) and error.retry_after > 0:
        return error.retry_after + random.random() * JITTER_MAX_SEC  # noqa: S311

    exponential = 1.0 * (2**attempt)
    capped: float = min(exponential, MAX_BACKOFF_SEC)
    jitter = random.random() * JITTER_MAX_SEC  # noqa: S311
    return capped + jitter


def _build_headers(api_key: str, workspace_id: str) -> dict[str, str]:
    return {
        "X-Workspace-Id": workspace_id,
        "X-Api-Key": api_key,
        "Content-Type": "application/json",
        "User-Agent": f"pyrx-synapse-python/{VERSION}",
    }


def _handle_response(response: httpx.Response) -> object:
    """Parse response, raise mapped error on non-2xx."""
    if response.status_code == 204:
        return None

    try:
        body: dict[str, object] = response.json()
    except Exception:
        body = {}

    if response.is_error:
        retry_after_header = response.headers.get("retry-after")
        retry_after = float(retry_after_header) if retry_after_header else None
        raise map_error(response.status_code, body, retry_after)

    return body


class BaseSynapseClient:
    """Configuration and shared logic for Synapse clients."""

    def __init__(
        self,
        api_key: str,
        *,
        workspace_id: str,
        base_url: str = "https://synapse-api.pyrx.tech",
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        if not api_key:
            raise ValueError("Synapse: api_key is required")
        if not workspace_id:
            raise ValueError("Synapse: workspace_id is required")

        self.api_key = api_key
        self.workspace_id = workspace_id
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.environment: Environment = _detect_environment(api_key)

    def _headers(self) -> dict[str, str]:
        return _build_headers(self.api_key, self.workspace_id)

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"


def sync_request_with_retry(
    client: httpx.Client,
    method: str,
    url: str,
    headers: dict[str, str],
    max_retries: int,
    body: dict[str, object] | None = None,
    params: dict[str, str] | None = None,
) -> object:
    """Perform an HTTP request with retry logic (sync)."""
    last_error: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            response = client.request(
                method,
                url,
                headers=headers,
                json=body,
                params=params,
            )
            return _handle_response(response)
        except SynapseError as exc:
            last_error = exc
            if not _is_retryable(exc) or attempt >= max_retries:
                raise
            delay = _backoff_delay(attempt, exc)
            time.sleep(delay)
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            last_error = exc
            if attempt >= max_retries:
                raise
            delay = _backoff_delay(attempt)
            time.sleep(delay)

    # Should never reach here
    if last_error is not None:
        raise last_error
    raise RuntimeError("Unexpected retry loop exit")  # pragma: no cover


async def async_request_with_retry(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    headers: dict[str, str],
    max_retries: int,
    body: dict[str, object] | None = None,
    params: dict[str, str] | None = None,
) -> object:
    """Perform an HTTP request with retry logic (async)."""
    import asyncio

    last_error: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            response = await client.request(
                method,
                url,
                headers=headers,
                json=body,
                params=params,
            )
            return _handle_response(response)
        except SynapseError as exc:
            last_error = exc
            if not _is_retryable(exc) or attempt >= max_retries:
                raise
            delay = _backoff_delay(attempt, exc)
            await asyncio.sleep(delay)
        except (httpx.TimeoutException, httpx.ConnectError) as exc:
            last_error = exc
            if attempt >= max_retries:
                raise
            delay = _backoff_delay(attempt)
            await asyncio.sleep(delay)

    # Should never reach here
    if last_error is not None:
        raise last_error
    raise RuntimeError("Unexpected retry loop exit")  # pragma: no cover
