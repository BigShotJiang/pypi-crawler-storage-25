"""PYRX Synapse Python SDK — async + sync client for event tracking, contacts, and email."""

from ._async_client import AsyncSynapse
from ._client import Synapse
from ._errors import (
    SynapseAuthError,
    SynapseError,
    SynapsePlanLimitError,
    SynapseRateLimitError,
    SynapseValidationError,
)
from ._webhooks import verify_webhook

__all__ = [
    "AsyncSynapse",
    "Synapse",
    "SynapseAuthError",
    "SynapseError",
    "SynapsePlanLimitError",
    "SynapseRateLimitError",
    "SynapseValidationError",
    "verify_webhook",
]
