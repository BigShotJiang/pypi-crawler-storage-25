# Changelog

## [0.1.0] - 2026-04-30

- Initial release as standalone repository
- Extracted from pyrx.crm monorepo with full git history
- Synchronous and asynchronous clients
- Event tracking, contact management, template management, transactional email
- Webhook signature verification
- Automatic retry with exponential backoff
- Typed error classes for all API error types
- Python 3.10+ support
