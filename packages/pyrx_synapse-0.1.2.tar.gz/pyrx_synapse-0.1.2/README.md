# pyrx-synapse

[![PyPI version](https://img.shields.io/pypi/v/pyrx-synapse.svg)](https://pypi.org/project/pyrx-synapse/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](./LICENSE)

Python SDK for the [PYRX Synapse](https://crm.pyrx.tech) customer engagement platform. Provides both synchronous and asynchronous clients.

Requires Python 3.10+.

## Installation

```bash
pip install pyrx-synapse
```

## Quick Start

### Sync

```python
from pyrx_synapse import Synapse

with Synapse(api_key="gck_live_xxx", workspace_id="ws_xxx") as client:
    # Track an event
    client.track(external_id="user_123", event_name="purchase", attributes={"amount": 99.99})

    # Identify a contact
    client.identify(external_id="user_123", email="jane@example.com", properties={"tier": "pro"})

    # Send a transactional email
    client.send(
        template_slug="welcome",
        to={"user_id": "user_123", "email": "jane@example.com"},
        attributes={"first_name": "Jane"},
    )
```

### Async

```python
from pyrx_synapse import AsyncSynapse

async with AsyncSynapse(api_key="gck_live_xxx", workspace_id="ws_xxx") as client:
    await client.track(external_id="user_123", event_name="purchase")
    await client.identify(external_id="user_123", email="jane@example.com")
```

## Features

- Synchronous and asynchronous clients
- Event tracking, contact management, template management, transactional email
- Webhook signature verification
- Automatic retry with exponential backoff
- Typed error classes for all API error types

## Documentation

Full API reference and guides: [synapse.pyrx.tech/developers/sdks/python](https://synapse.pyrx.tech/developers/sdks/python)

## License

[MIT](./LICENSE)
