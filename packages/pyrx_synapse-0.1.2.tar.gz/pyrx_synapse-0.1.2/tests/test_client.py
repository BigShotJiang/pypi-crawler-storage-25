"""Tests for the synchronous Synapse client."""

from __future__ import annotations

import httpx
import pytest
import respx

from pyrx_synapse import (
    Synapse,
    SynapseAuthError,
    SynapseError,
    SynapsePlanLimitError,
    SynapseValidationError,
)

API_KEY = "gck_test_abc123def456"
WORKSPACE_ID = "ws_test_workspace"
BASE_URL = "https://synapse-api.pyrx.tech"


@pytest.fixture()
def client() -> Synapse:
    return Synapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=0)


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestConstructor:
    def test_missing_api_key(self) -> None:
        with pytest.raises(ValueError, match="api_key is required"):
            Synapse(api_key="", workspace_id=WORKSPACE_ID)

    def test_missing_workspace_id(self) -> None:
        with pytest.raises(ValueError, match="workspace_id is required"):
            Synapse(api_key=API_KEY, workspace_id="")

    def test_environment_detection_test(self) -> None:
        c = Synapse(api_key="gck_test_abc", workspace_id="ws")
        assert c.environment == "test"
        c.close()

    def test_environment_detection_live(self) -> None:
        c = Synapse(api_key="gck_live_abc", workspace_id="ws")
        assert c.environment == "live"
        c.close()

    def test_environment_detection_unknown(self) -> None:
        c = Synapse(api_key="some_other_key", workspace_id="ws")
        assert c.environment == "unknown"
        c.close()

    def test_context_manager(self) -> None:
        with Synapse(api_key=API_KEY, workspace_id=WORKSPACE_ID) as c:
            assert c.environment == "test"


# ---------------------------------------------------------------------------
# track
# ---------------------------------------------------------------------------


class TestTrack:
    @respx.mock
    def test_track_sends_correct_post(self, client: Synapse) -> None:
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(200, json={"event_id": "evt_123", "status": "accepted"})
        )
        result = client.track(external_id="user_1", event_name="purchase")
        assert result.event_id == "evt_123"
        assert result.status == "accepted"
        assert route.called
        req = route.calls[0].request
        assert req.headers["X-Workspace-Id"] == WORKSPACE_ID
        assert req.headers["X-Api-Key"] == API_KEY

    @respx.mock
    def test_track_with_attributes(self, client: Synapse) -> None:
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(200, json={"event_id": "evt_1", "status": "accepted"})
        )
        client.track(
            external_id="u1",
            event_name="purchase",
            attributes={"amount": 99.99},
            idempotency_key="idem_1",
        )
        import json

        body = json.loads(route.calls[0].request.content)
        assert body["external_id"] == "u1"
        assert body["event_name"] == "purchase"
        assert body["attributes"]["amount"] == 99.99
        assert body["idempotency_key"] == "idem_1"

    @respx.mock
    def test_track_batch(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/events/batch").mock(
            return_value=httpx.Response(200, json={"accepted": 3, "rejected": 0})
        )
        result = client.track_batch(
            events=[
                {"external_id": "u1", "event_name": "e1"},
                {"external_id": "u2", "event_name": "e2"},
                {"external_id": "u3", "event_name": "e3"},
            ]
        )
        assert result.accepted == 3
        assert result.rejected == 0


# ---------------------------------------------------------------------------
# identify
# ---------------------------------------------------------------------------


class TestIdentify:
    @respx.mock
    def test_identify_sends_correct_post(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/contacts").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c_123",
                    "external_id": "user_1",
                    "email": "j@ex.com",
                    "properties": {},
                    "tags": [],
                    "created_at": "2024-01-01T00:00:00Z",
                    "updated_at": "2024-01-01T00:00:00Z",
                },
            )
        )
        result = client.identify(external_id="user_1", email="j@ex.com")
        assert result.id == "c_123"
        assert result.external_id == "user_1"
        assert result.email == "j@ex.com"

    @respx.mock
    def test_identify_batch(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/contacts/bulk").mock(
            return_value=httpx.Response(
                200, json={"total": 2, "created": 1, "updated": 1, "skipped": 0}
            )
        )
        result = client.identify_batch(
            contacts=[
                {"external_id": "u1", "email": "a@b.com"},
                {"external_id": "u2", "email": "c@d.com"},
            ],
            on_conflict="merge",
        )
        assert result.total == 2
        assert result.created == 1
        assert result.updated == 1


# ---------------------------------------------------------------------------
# send
# ---------------------------------------------------------------------------


class TestSend:
    @respx.mock
    def test_send_sends_correct_post(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/send").mock(
            return_value=httpx.Response(200, json={"email_log_id": "el_123", "status": "queued"})
        )
        result = client.send(
            template_slug="welcome",
            to={"user_id": "u1", "email": "j@ex.com"},
            attributes={"name": "Jane"},
        )
        assert result.email_log_id == "el_123"
        assert result.status == "queued"


# ---------------------------------------------------------------------------
# contacts sub-client
# ---------------------------------------------------------------------------


class TestContacts:
    @respx.mock
    def test_list(self, client: Synapse) -> None:
        respx.get(f"{BASE_URL}/v1/contacts").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": [
                        {
                            "id": "c1",
                            "external_id": "u1",
                            "email": "a@b.com",
                            "properties": {},
                            "tags": [],
                            "created_at": "2024-01-01T00:00:00Z",
                            "updated_at": "2024-01-01T00:00:00Z",
                        }
                    ],
                    "meta": {"total": 1, "page": 1, "per_page": 50, "total_pages": 1},
                },
            )
        )
        result = client.contacts.list(search="a@b", page=1, per_page=50)
        assert len(result.data) == 1
        assert result.data[0].email == "a@b.com"
        assert result.meta.total == 1

    @respx.mock
    def test_get(self, client: Synapse) -> None:
        respx.get(f"{BASE_URL}/v1/contacts/c1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c1",
                    "external_id": "u1",
                    "properties": {},
                    "tags": [],
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = client.contacts.get("c1")
        assert result.id == "c1"

    @respx.mock
    def test_update(self, client: Synapse) -> None:
        respx.patch(f"{BASE_URL}/v1/contacts/u1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c1",
                    "external_id": "u1",
                    "email": "new@b.com",
                    "properties": {"tier": "pro"},
                    "tags": [],
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = client.contacts.update("u1", {"properties": {"tier": "pro"}})
        assert result.email == "new@b.com"

    @respx.mock
    def test_delete(self, client: Synapse) -> None:
        route = respx.delete(f"{BASE_URL}/v1/contacts/u1").mock(return_value=httpx.Response(204))
        client.contacts.delete("u1")
        assert route.called


# ---------------------------------------------------------------------------
# templates sub-client
# ---------------------------------------------------------------------------


class TestTemplates:
    @respx.mock
    def test_list(self, client: Synapse) -> None:
        respx.get(f"{BASE_URL}/v1/templates").mock(
            return_value=httpx.Response(
                200,
                json=[
                    {
                        "id": "t1",
                        "name": "Welcome",
                        "slug": "welcome",
                        "subject": "Hi",
                        "body_html": "<p>Hi</p>",
                        "created_at": "",
                        "updated_at": "",
                    }
                ],
            )
        )
        result = client.templates.list()
        assert len(result) == 1
        assert result[0].slug == "welcome"

    @respx.mock
    def test_get(self, client: Synapse) -> None:
        respx.get(f"{BASE_URL}/v1/templates/welcome").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "t1",
                    "name": "Welcome",
                    "slug": "welcome",
                    "subject": "Hi",
                    "body_html": "<p>Hi</p>",
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = client.templates.get("welcome")
        assert result.name == "Welcome"

    @respx.mock
    def test_create(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/templates").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "t2",
                    "name": "Onboard",
                    "slug": "onboard",
                    "subject": "Welcome aboard",
                    "body_html": "<p>Welcome</p>",
                    "sender_name": "Acme",
                    "from_email": "hi@acme.com",
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = client.templates.create(
            {
                "name": "Onboard",
                "slug": "onboard",
                "subject": "Welcome aboard",
                "body_html": "<p>Welcome</p>",
                "sender_name": "Acme",
                "from_email": "hi@acme.com",
            }
        )
        assert result.slug == "onboard"
        assert result.sender_name == "Acme"

    @respx.mock
    def test_update(self, client: Synapse) -> None:
        respx.put(f"{BASE_URL}/v1/templates/welcome").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "t1",
                    "name": "Welcome",
                    "slug": "welcome",
                    "subject": "Updated subject",
                    "body_html": "<p>Hi</p>",
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = client.templates.update("welcome", {"subject": "Updated subject"})
        assert result.subject == "Updated subject"

    @respx.mock
    def test_delete(self, client: Synapse) -> None:
        route = respx.delete(f"{BASE_URL}/v1/templates/welcome").mock(
            return_value=httpx.Response(204)
        )
        client.templates.delete("welcome")
        assert route.called

    @respx.mock
    def test_preview(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/templates/welcome/preview").mock(
            return_value=httpx.Response(
                200,
                json={
                    "subject": "Hi Jane",
                    "html": "<p>Hi Jane</p>",
                    "suppressed": False,
                    "suppressed_reason": None,
                },
            )
        )
        result = client.templates.preview(
            "welcome", {"contact": {"first_name": "Jane"}, "event": {}}
        )
        assert result.subject == "Hi Jane"
        assert result.suppressed is False


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------


class TestErrorMapping:
    @respx.mock
    def test_401_raises_auth_error(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(401, json={"detail": "Unauthorized"})
        )
        with pytest.raises(SynapseAuthError) as exc_info:
            client.track(external_id="u1", event_name="e1")
        assert exc_info.value.status == 401

    @respx.mock
    def test_403_plan_limit(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(
                403,
                json={
                    "detail": "Plan limit reached",
                    "code": "plan_limit_reached",
                    "limit_type": "events",
                    "current": 10000,
                    "maximum": 10000,
                    "plan": "free",
                },
            )
        )
        with pytest.raises(SynapsePlanLimitError) as exc_info:
            client.track(external_id="u1", event_name="e1")
        assert exc_info.value.limit_type == "events"

    @respx.mock
    def test_422_validation_error(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(
                422,
                json={
                    "detail": "Validation failed",
                    "errors": [{"field": "event_name", "message": "required"}],
                },
            )
        )
        with pytest.raises(SynapseValidationError) as exc_info:
            client.track(external_id="u1", event_name="")
        assert len(exc_info.value.errors) == 1

    @respx.mock
    def test_500_raises_synapse_error(self, client: Synapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(500, json={"detail": "Internal server error"})
        )
        with pytest.raises(SynapseError):
            client.track(external_id="u1", event_name="e1")


# ---------------------------------------------------------------------------
# Retry
# ---------------------------------------------------------------------------


class TestRetry:
    @respx.mock
    def test_retry_on_500(self) -> None:
        """Client retries on 500 and succeeds on second attempt."""
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            side_effect=[
                httpx.Response(500, json={"detail": "error"}),
                httpx.Response(200, json={"event_id": "evt_1", "status": "accepted"}),
            ]
        )
        c = Synapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=1)
        result = c.track(external_id="u1", event_name="e1")
        assert result.event_id == "evt_1"
        assert route.call_count == 2
        c.close()

    @respx.mock
    def test_no_retry_on_400(self) -> None:
        """Client does NOT retry on 400."""
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(400, json={"detail": "Bad request"})
        )
        c = Synapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=2)
        with pytest.raises(SynapseError):
            c.track(external_id="u1", event_name="e1")
        assert route.call_count == 1
        c.close()

    @respx.mock
    def test_no_retry_on_401(self) -> None:
        """Client does NOT retry on 401."""
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(401, json={"detail": "Unauthorized"})
        )
        c = Synapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=2)
        with pytest.raises(SynapseAuthError):
            c.track(external_id="u1", event_name="e1")
        assert route.call_count == 1
        c.close()
