"""Tests for the error hierarchy."""

from __future__ import annotations

from pyrx_synapse._errors import (
    SynapseAuthError,
    SynapseError,
    SynapsePlanLimitError,
    SynapseRateLimitError,
    SynapseValidationError,
    map_error,
)


class TestSynapseError:
    def test_instantiation(self) -> None:
        err = SynapseError("Something went wrong", 500, code="internal_error")
        assert str(err) == "Something went wrong"
        assert err.message == "Something went wrong"
        assert err.status == 500
        assert err.code == "internal_error"
        assert err.request_id is None

    def test_with_request_id(self) -> None:
        err = SynapseError("fail", 500, request_id="req_123")
        assert err.request_id == "req_123"

    def test_is_exception(self) -> None:
        assert issubclass(SynapseError, Exception)


class TestSynapseAuthError:
    def test_isinstance(self) -> None:
        err = SynapseAuthError("Unauthorized", 401)
        assert isinstance(err, SynapseError)
        assert isinstance(err, SynapseAuthError)
        assert err.status == 401

    def test_403_scope(self) -> None:
        err = SynapseAuthError("Insufficient scope", 403, code="insufficient_scope")
        assert err.status == 403
        assert err.code == "insufficient_scope"


class TestSynapseRateLimitError:
    def test_default_retry_after(self) -> None:
        err = SynapseRateLimitError("Rate limited", 429)
        assert isinstance(err, SynapseError)
        assert err.retry_after == 60.0

    def test_custom_retry_after(self) -> None:
        err = SynapseRateLimitError("Rate limited", 429, retry_after=120.0)
        assert err.retry_after == 120.0


class TestSynapsePlanLimitError:
    def test_properties(self) -> None:
        err = SynapsePlanLimitError(
            "Plan limit reached",
            403,
            code="plan_limit_reached",
            limit_type="contacts",
            current=1000,
            maximum=1000,
            plan="starter",
        )
        assert isinstance(err, SynapseError)
        assert err.limit_type == "contacts"
        assert err.current == 1000
        assert err.maximum == 1000
        assert err.plan == "starter"

    def test_defaults(self) -> None:
        err = SynapsePlanLimitError("limit", 403)
        assert err.limit_type == ""
        assert err.current == 0
        assert err.maximum == 0
        assert err.plan == ""


class TestSynapseValidationError:
    def test_with_errors(self) -> None:
        err = SynapseValidationError(
            "Validation failed",
            422,
            errors=[{"field": "email", "message": "Invalid email"}],
        )
        assert isinstance(err, SynapseError)
        assert len(err.errors) == 1
        assert err.errors[0]["field"] == "email"

    def test_empty_errors(self) -> None:
        err = SynapseValidationError("Validation failed", 422)
        assert err.errors == []


class TestMapError:
    def test_429_maps_to_rate_limit(self) -> None:
        err = map_error(429, {"detail": "Too many requests"}, retry_after=30.0)
        assert isinstance(err, SynapseRateLimitError)
        assert err.retry_after == 30.0

    def test_403_plan_limit(self) -> None:
        err = map_error(
            403,
            {
                "detail": "Plan limit reached",
                "code": "plan_limit_reached",
                "limit_type": "contacts",
                "current": 500,
                "maximum": 500,
                "plan": "free",
            },
        )
        assert isinstance(err, SynapsePlanLimitError)
        assert err.limit_type == "contacts"
        assert err.plan == "free"

    def test_403_auth(self) -> None:
        err = map_error(403, {"detail": "Forbidden"})
        assert isinstance(err, SynapseAuthError)
        assert not isinstance(err, SynapsePlanLimitError)

    def test_401_auth(self) -> None:
        err = map_error(401, {"detail": "Unauthorized"})
        assert isinstance(err, SynapseAuthError)

    def test_422_validation(self) -> None:
        err = map_error(
            422,
            {
                "detail": "Validation failed",
                "errors": [{"field": "email", "message": "required"}],
            },
        )
        assert isinstance(err, SynapseValidationError)
        assert len(err.errors) == 1

    def test_500_generic(self) -> None:
        err = map_error(500, {"detail": "Internal server error"})
        assert type(err) is SynapseError
        assert err.status == 500

    def test_fallback_message(self) -> None:
        err = map_error(418, {})
        assert err.message == "HTTP 418"

    def test_message_from_message_field(self) -> None:
        err = map_error(400, {"message": "Bad request"})
        assert err.message == "Bad request"
