"""Tests for the asynchronous Synapse client."""

from __future__ import annotations

import httpx
import pytest
import respx

from pyrx_synapse import (
    AsyncSynapse,
    SynapseAuthError,
    SynapseError,
    SynapsePlanLimitError,
    SynapseValidationError,
)

API_KEY = "gck_test_abc123def456"
WORKSPACE_ID = "ws_test_workspace"
BASE_URL = "https://synapse-api.pyrx.tech"


@pytest.fixture()
def client() -> AsyncSynapse:
    return AsyncSynapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=0)


# ---------------------------------------------------------------------------
# Constructor & context manager
# ---------------------------------------------------------------------------


class TestAsyncConstructor:
    @pytest.mark.asyncio
    async def test_context_manager(self) -> None:
        async with AsyncSynapse(api_key=API_KEY, workspace_id=WORKSPACE_ID) as c:
            assert c.environment == "test"


# ---------------------------------------------------------------------------
# track
# ---------------------------------------------------------------------------


class TestAsyncTrack:
    @respx.mock
    @pytest.mark.asyncio
    async def test_track(self, client: AsyncSynapse) -> None:
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(200, json={"event_id": "evt_123", "status": "accepted"})
        )
        result = await client.track(external_id="user_1", event_name="purchase")
        assert result.event_id == "evt_123"
        assert route.called

    @respx.mock
    @pytest.mark.asyncio
    async def test_track_batch(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/events/batch").mock(
            return_value=httpx.Response(200, json={"accepted": 2, "rejected": 0})
        )
        result = await client.track_batch(
            events=[
                {"external_id": "u1", "event_name": "e1"},
                {"external_id": "u2", "event_name": "e2"},
            ]
        )
        assert result.accepted == 2


# ---------------------------------------------------------------------------
# identify
# ---------------------------------------------------------------------------


class TestAsyncIdentify:
    @respx.mock
    @pytest.mark.asyncio
    async def test_identify(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/contacts").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c1",
                    "external_id": "u1",
                    "email": "j@ex.com",
                    "properties": {},
                    "tags": [],
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = await client.identify(external_id="u1", email="j@ex.com")
        assert result.external_id == "u1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_identify_batch(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/contacts/bulk").mock(
            return_value=httpx.Response(
                200, json={"total": 1, "created": 1, "updated": 0, "skipped": 0}
            )
        )
        result = await client.identify_batch(contacts=[{"external_id": "u1"}], on_conflict="merge")
        assert result.total == 1


# ---------------------------------------------------------------------------
# send
# ---------------------------------------------------------------------------


class TestAsyncSend:
    @respx.mock
    @pytest.mark.asyncio
    async def test_send(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/send").mock(
            return_value=httpx.Response(200, json={"email_log_id": "el_1", "status": "queued"})
        )
        result = await client.send(
            template_slug="welcome",
            to={"user_id": "u1", "email": "j@ex.com"},
        )
        assert result.email_log_id == "el_1"


# ---------------------------------------------------------------------------
# contacts sub-client
# ---------------------------------------------------------------------------


class TestAsyncContacts:
    @respx.mock
    @pytest.mark.asyncio
    async def test_list(self, client: AsyncSynapse) -> None:
        respx.get(f"{BASE_URL}/v1/contacts").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": [
                        {
                            "id": "c1",
                            "external_id": "u1",
                            "properties": {},
                            "tags": [],
                            "created_at": "",
                            "updated_at": "",
                        }
                    ],
                    "meta": {"total": 1, "page": 1, "per_page": 50, "total_pages": 1},
                },
            )
        )
        result = await client.contacts.list(search="u1")
        assert len(result.data) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_get(self, client: AsyncSynapse) -> None:
        respx.get(f"{BASE_URL}/v1/contacts/c1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c1",
                    "external_id": "u1",
                    "properties": {},
                    "tags": [],
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = await client.contacts.get("c1")
        assert result.id == "c1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_update(self, client: AsyncSynapse) -> None:
        respx.patch(f"{BASE_URL}/v1/contacts/u1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "c1",
                    "external_id": "u1",
                    "properties": {"tier": "pro"},
                    "tags": [],
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = await client.contacts.update("u1", {"properties": {"tier": "pro"}})
        assert result.external_id == "u1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_delete(self, client: AsyncSynapse) -> None:
        route = respx.delete(f"{BASE_URL}/v1/contacts/u1").mock(return_value=httpx.Response(204))
        await client.contacts.delete("u1")
        assert route.called


# ---------------------------------------------------------------------------
# templates sub-client
# ---------------------------------------------------------------------------


class TestAsyncTemplates:
    @respx.mock
    @pytest.mark.asyncio
    async def test_list(self, client: AsyncSynapse) -> None:
        respx.get(f"{BASE_URL}/v1/templates").mock(
            return_value=httpx.Response(
                200,
                json=[
                    {
                        "id": "t1",
                        "name": "Welcome",
                        "slug": "welcome",
                        "subject": "Hi",
                        "body_html": "<p>Hi</p>",
                        "created_at": "",
                        "updated_at": "",
                    }
                ],
            )
        )
        result = await client.templates.list()
        assert len(result) == 1

    @respx.mock
    @pytest.mark.asyncio
    async def test_create(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/templates").mock(
            return_value=httpx.Response(
                201,
                json={
                    "id": "t2",
                    "name": "Onboard",
                    "slug": "onboard",
                    "subject": "Welcome",
                    "body_html": "<p>W</p>",
                    "created_at": "",
                    "updated_at": "",
                },
            )
        )
        result = await client.templates.create(
            {
                "name": "Onboard",
                "slug": "onboard",
                "subject": "Welcome",
                "body_html": "<p>W</p>",
                "sender_name": "Acme",
                "from_email": "hi@acme.com",
            }
        )
        assert result.slug == "onboard"

    @respx.mock
    @pytest.mark.asyncio
    async def test_preview(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/templates/welcome/preview").mock(
            return_value=httpx.Response(
                200,
                json={
                    "subject": "Hi Jane",
                    "html": "<p>Hi</p>",
                    "suppressed": False,
                    "suppressed_reason": None,
                },
            )
        )
        result = await client.templates.preview("welcome", {"contact": {}, "event": {}})
        assert result.subject == "Hi Jane"


# ---------------------------------------------------------------------------
# Error mapping (async)
# ---------------------------------------------------------------------------


class TestAsyncErrorMapping:
    @respx.mock
    @pytest.mark.asyncio
    async def test_401(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(401, json={"detail": "Unauthorized"})
        )
        with pytest.raises(SynapseAuthError):
            await client.track(external_id="u1", event_name="e1")

    @respx.mock
    @pytest.mark.asyncio
    async def test_403_plan_limit(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(
                403,
                json={
                    "detail": "Limit",
                    "code": "plan_limit_reached",
                    "limit_type": "events",
                    "current": 100,
                    "maximum": 100,
                    "plan": "free",
                },
            )
        )
        with pytest.raises(SynapsePlanLimitError):
            await client.track(external_id="u1", event_name="e1")

    @respx.mock
    @pytest.mark.asyncio
    async def test_422(self, client: AsyncSynapse) -> None:
        respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(
                422,
                json={"detail": "Validation", "errors": [{"field": "x", "message": "bad"}]},
            )
        )
        with pytest.raises(SynapseValidationError):
            await client.track(external_id="u1", event_name="e1")


# ---------------------------------------------------------------------------
# Retry (async)
# ---------------------------------------------------------------------------


class TestAsyncRetry:
    @respx.mock
    @pytest.mark.asyncio
    async def test_retry_on_500(self) -> None:
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            side_effect=[
                httpx.Response(500, json={"detail": "error"}),
                httpx.Response(200, json={"event_id": "evt_1", "status": "ok"}),
            ]
        )
        c = AsyncSynapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=1)
        result = await c.track(external_id="u1", event_name="e1")
        assert result.event_id == "evt_1"
        assert route.call_count == 2
        await c.close()

    @respx.mock
    @pytest.mark.asyncio
    async def test_no_retry_on_400(self) -> None:
        route = respx.post(f"{BASE_URL}/v1/events").mock(
            return_value=httpx.Response(400, json={"detail": "Bad"})
        )
        c = AsyncSynapse(api_key=API_KEY, workspace_id=WORKSPACE_ID, max_retries=2)
        with pytest.raises(SynapseError):
            await c.track(external_id="u1", event_name="e1")
        assert route.call_count == 1
        await c.close()
