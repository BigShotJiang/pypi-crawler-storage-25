"""Tests for webhook signature verification."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import time

import pytest

from pyrx_synapse import verify_webhook

# Generate a test secret
SECRET_RAW = b"test_webhook_secret_key_1234567890"
SECRET_B64 = base64.b64encode(SECRET_RAW).decode()
SECRET_WITH_PREFIX = f"whsec_{SECRET_B64}"


def _sign(
    payload: str,
    svix_id: str,
    svix_timestamp: str,
    secret_bytes: bytes = SECRET_RAW,
) -> str:
    """Create a valid svix signature for testing."""
    signed_content = f"{svix_id}.{svix_timestamp}.{payload}"
    sig = hmac.new(secret_bytes, signed_content.encode(), hashlib.sha256).digest()
    return f"v1,{base64.b64encode(sig).decode()}"


class TestVerifyWebhook:
    def test_valid_signature(self) -> None:
        payload = json.dumps({"type": "contact.created", "data": {"id": "c1"}})
        ts = str(math.floor(time.time()))
        svix_id = "msg_test123"
        sig = _sign(payload, svix_id, ts)

        result = verify_webhook(
            payload,
            {"svix-id": svix_id, "svix-timestamp": ts, "svix-signature": sig},
            SECRET_WITH_PREFIX,
        )
        assert result["type"] == "contact.created"

    def test_valid_signature_without_prefix(self) -> None:
        payload = json.dumps({"type": "event.ingested"})
        ts = str(math.floor(time.time()))
        svix_id = "msg_abc"
        sig = _sign(payload, svix_id, ts)

        result = verify_webhook(
            payload,
            {"svix-id": svix_id, "svix-timestamp": ts, "svix-signature": sig},
            SECRET_B64,  # no whsec_ prefix
        )
        assert result["type"] == "event.ingested"

    def test_invalid_signature(self) -> None:
        payload = json.dumps({"type": "test"})
        ts = str(math.floor(time.time()))
        svix_id = "msg_xyz"

        with pytest.raises(ValueError, match="verification failed"):
            verify_webhook(
                payload,
                {
                    "svix-id": svix_id,
                    "svix-timestamp": ts,
                    "svix-signature": "v1,aW52YWxpZA==",  # invalid
                },
                SECRET_WITH_PREFIX,
            )

    def test_expired_timestamp(self) -> None:
        payload = json.dumps({"type": "test"})
        old_ts = str(math.floor(time.time()) - 600)  # 10 minutes ago
        svix_id = "msg_old"
        sig = _sign(payload, svix_id, old_ts)

        with pytest.raises(ValueError, match="too old"):
            verify_webhook(
                payload,
                {"svix-id": svix_id, "svix-timestamp": old_ts, "svix-signature": sig},
                SECRET_WITH_PREFIX,
            )

    def test_disable_timestamp_check(self) -> None:
        payload = json.dumps({"type": "test"})
        old_ts = str(math.floor(time.time()) - 600)
        svix_id = "msg_old"
        sig = _sign(payload, svix_id, old_ts)

        result = verify_webhook(
            payload,
            {"svix-id": svix_id, "svix-timestamp": old_ts, "svix-signature": sig},
            SECRET_WITH_PREFIX,
            disable_timestamp_check=True,
        )
        assert result["type"] == "test"

    def test_missing_svix_id(self) -> None:
        with pytest.raises(ValueError, match="Missing required"):
            verify_webhook(
                "{}",
                {"svix-id": "", "svix-timestamp": "123", "svix-signature": "v1,abc"},
                SECRET_WITH_PREFIX,
            )

    def test_missing_svix_timestamp(self) -> None:
        with pytest.raises(ValueError, match="Missing required"):
            verify_webhook(
                "{}",
                {"svix-id": "msg_1", "svix-timestamp": "", "svix-signature": "v1,abc"},
                SECRET_WITH_PREFIX,
            )

    def test_missing_svix_signature(self) -> None:
        with pytest.raises(ValueError, match="Missing required"):
            verify_webhook(
                "{}",
                {"svix-id": "msg_1", "svix-timestamp": "123", "svix-signature": ""},
                SECRET_WITH_PREFIX,
            )

    def test_invalid_timestamp_format(self) -> None:
        with pytest.raises(ValueError, match="Invalid svix-timestamp"):
            verify_webhook(
                "{}",
                {"svix-id": "msg_1", "svix-timestamp": "not_a_number", "svix-signature": "v1,x"},
                SECRET_WITH_PREFIX,
            )

    def test_invalid_json_payload(self) -> None:
        ts = str(math.floor(time.time()))
        svix_id = "msg_bad"
        payload = "not json"
        sig = _sign(payload, svix_id, ts)

        with pytest.raises(ValueError, match="Failed to parse"):
            verify_webhook(
                payload,
                {"svix-id": svix_id, "svix-timestamp": ts, "svix-signature": sig},
                SECRET_WITH_PREFIX,
            )

    def test_multiple_signatures_key_rotation(self) -> None:
        """When svix sends multiple signatures, one valid should pass."""
        payload = json.dumps({"type": "rotated"})
        ts = str(math.floor(time.time()))
        svix_id = "msg_rot"
        valid_sig = _sign(payload, svix_id, ts)
        combined = f"v1,aW52YWxpZA== {valid_sig}"

        result = verify_webhook(
            payload,
            {"svix-id": svix_id, "svix-timestamp": ts, "svix-signature": combined},
            SECRET_WITH_PREFIX,
        )
        assert result["type"] == "rotated"
