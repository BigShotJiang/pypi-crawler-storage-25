"""Shared fixtures for pyrx-synapse tests."""

from __future__ import annotations

import pytest

API_KEY = "gck_test_abc123def456"
WORKSPACE_ID = "ws_test_workspace"
BASE_URL = "https://synapse-api.pyrx.tech"


@pytest.fixture()
def api_key() -> str:
    return API_KEY


@pytest.fixture()
def workspace_id() -> str:
    return WORKSPACE_ID


@pytest.fixture()
def base_url() -> str:
    return BASE_URL
