==============
``config``
==============

.. automodule:: fabric.config
