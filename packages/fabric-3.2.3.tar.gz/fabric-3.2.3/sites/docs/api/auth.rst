========
``auth``
========

.. automodule:: fabric.auth
