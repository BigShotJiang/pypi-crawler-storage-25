"""CTF stego helpers."""
