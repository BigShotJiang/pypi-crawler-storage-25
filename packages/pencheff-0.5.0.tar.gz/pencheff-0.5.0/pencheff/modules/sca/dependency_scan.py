"""Scan dependency manifests for known CVEs via OSV.dev + EPSS + KEV enrichment."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from pencheff.config import Severity
from pencheff.core.cve_feed import DepVuln, get_feed
from pencheff.core.findings import Evidence, Finding
from pencheff.core.http_client import PencheffHTTPClient
from pencheff.core.session import PentestSession
from pencheff.modules.base import BaseTestModule
from pencheff.modules.sca.manifest_parsers import Dep, discover_and_parse


class DependencyScanModule(BaseTestModule):
    name = "dependency_scan"
    category = "components"
    owasp_categories = ["A06"]
    description = "Software Composition Analysis against OSV.dev with EPSS/KEV enrichment"

    def get_techniques(self) -> list[str]:
        return ["manifest-parse", "osv-query", "kev-flag", "epss-enrich"]

    async def run(
        self,
        session: PentestSession,
        http: PencheffHTTPClient,
        targets: list[str] | None = None,
        config: dict[str, Any] | None = None,
    ) -> list[Finding]:
        cfg = config or {}
        path = Path(cfg.get("path", "."))
        if not path.exists():
            return []
        deps = discover_and_parse(path)
        findings = await scan_deps(deps, session, scan_root=path)
        return findings


async def scan_deps(
    deps: list[Dep],
    session: PentestSession | None = None,
    scan_root: Path | None = None,
) -> list[Finding]:
    """Query OSV for each (ecosystem, name, version) and build Findings."""
    feed = get_feed()
    sem = asyncio.Semaphore(8)

    async def q(d: Dep) -> tuple[Dep, list[DepVuln]]:
        async with sem:
            if not d.name or not d.version or not d.ecosystem:
                return d, []
            return d, await feed.osv_query(d.ecosystem, d.name, d.version)

    results = await asyncio.gather(*(q(d) for d in deps))
    findings: list[Finding] = []
    root = scan_root.resolve() if scan_root else None
    for dep, vulns in results:
        rel = _rel_manifest(dep.source_file, root)
        for v in vulns:
            findings.append(_vuln_to_finding(dep, v, manifest_rel=rel))
    return findings


def _rel_manifest(source_file: str, scan_root: Path | None) -> str:
    """Best-effort: compute the manifest path relative to the scan root.

    Falls back to the basename when the path lies outside the root or the
    root is unknown — that still gives the patcher a chance to find the
    file by walking the materialised repo on the API side.
    """
    if not source_file:
        return ""
    p = Path(source_file)
    if scan_root:
        try:
            return str(p.resolve().relative_to(scan_root))
        except (ValueError, OSError):
            pass
    return p.name


def _vuln_to_finding(dep: Dep, v: DepVuln, manifest_rel: str = "") -> Finding:
    sev_label = v.severity.lower() if v.severity else "medium"
    sev = {
        "critical": Severity.CRITICAL, "high": Severity.HIGH,
        "medium": Severity.MEDIUM, "low": Severity.LOW, "info": Severity.INFO,
    }.get(sev_label, Severity.MEDIUM)

    fixed = ", ".join(v.fixed_versions) if v.fixed_versions else "no fixed version published"
    # Pick the lowest fixed version we know about — that's the smallest
    # safe bump. Sorting lexicographically is good enough for OSV's already-
    # filtered list; PEP-440 / SemVer-perfect ordering would require pulling
    # in a parser per ecosystem, which is overkill here.
    fix_version = sorted(v.fixed_versions)[0] if v.fixed_versions else None
    autofix_payload: dict[str, Any] | None = None
    epss = v.cve_info.epss if v.cve_info else None
    kev = bool(v.cve_info.kev) if v.cve_info else False
    if fix_version and dep.name:
        autofix_payload = {
            "tool": "osv",
            "ecosystem": dep.ecosystem,
            "package": dep.name,
            "current_version": dep.version,
            "fix_version": fix_version,
            "manifest_path": manifest_rel or dep.source_file,
            "advisory_id": v.id,
            # Prioritisation inputs travel alongside the autofix payload so
            # the API side can compute risk_score / SSVC without re-querying
            # the EPSS / KEV feeds.
            "epss": epss,
            "kev": kev,
        }
    kev_note = ""
    epss_note = ""
    if v.cve_info and v.cve_info.kev:
        kev_note = (
            f"\n\n⚠️  This CVE appears on the CISA Known Exploited Vulnerabilities catalog "
            f"({v.cve_info.kev_short_desc or 'actively exploited'}). "
            f"Federal deadline: {v.cve_info.kev_due_date or 'n/a'}."
        )
    if v.cve_info and v.cve_info.epss is not None:
        epss_note = f"\nEPSS score: {v.cve_info.epss:.4f} (higher = more likely to be exploited)."

    return Finding(
        title=f"{dep.name} {dep.version} — {v.id}",
        severity=sev,
        category="components",
        owasp_category="A06",
        description=(
            f"The {dep.ecosystem} package '{dep.name}' version {dep.version} is "
            f"vulnerable to {v.id}: {v.summary}{epss_note}{kev_note}"
        ),
        remediation=(
            f"Upgrade {dep.name} to {fixed}. "
            f"Source manifest: {dep.source_file}. "
            f"If upgrade is impossible, apply the mitigations listed in the advisory, "
            f"remove the dependency if unused, or pin a patched fork."
        ),
        endpoint=manifest_rel or dep.source_file or dep.name,
        parameter=f"{dep.ecosystem}:{dep.name}@{dep.version}",
        cvss_vector=v.cvss_vector,
        cvss_score=v.cvss_score,
        evidence=[
            Evidence(
                request_method="OSV",
                request_url=f"osv://{dep.ecosystem}/{dep.name}/{dep.version}",
                response_status=200,
                description=(
                    f"{v.id} affects versions: {', '.join(v.affected_versions) or 'unknown range'}. "
                    f"Fixed in: {fixed}."
                ),
                autofix=autofix_payload,
            )
        ],
        references=v.references,
        cwe_id=None,
    )
