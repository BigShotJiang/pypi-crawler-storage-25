"""CVE / EPSS / CISA KEV feed cache and lookup.

Uses a local SQLite database for fast lookups; refreshes from:
- OSV.dev (https://api.osv.dev/v1/query) — per-package vuln query
- EPSS (https://epss.cyentia.com/epss_scores-current.csv.gz) — daily exploit prediction
- CISA KEV (https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json)

All feed fetches are opt-in (guarded behind refresh_cve_feed); offline scans
degrade gracefully — modules emit findings with empty EPSS / unknown KEV fields.
"""

from __future__ import annotations

import csv
import gzip
import io
import json
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

CACHE_DIR = Path.home() / ".pencheff"
CACHE_DB = CACHE_DIR / "cve_cache.db"

OSV_QUERY_URL = "https://api.osv.dev/v1/query"
EPSS_URL = "https://epss.cyentia.com/epss_scores-current.csv.gz"
KEV_URL = (
    "https://www.cisa.gov/sites/default/files/feeds/"
    "known_exploited_vulnerabilities.json"
)


def _connect() -> sqlite3.Connection:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(CACHE_DB)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS epss ("
        "cve TEXT PRIMARY KEY, epss REAL, percentile REAL, updated_at TEXT)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS kev ("
        "cve TEXT PRIMARY KEY, vendor TEXT, product TEXT, "
        "short_desc TEXT, required_action TEXT, due_date TEXT)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS osv_cache ("
        "ecosystem TEXT, package TEXT, version TEXT, "
        "vulns_json TEXT, cached_at TEXT, "
        "PRIMARY KEY (ecosystem, package, version))"
    )
    conn.commit()
    return conn


@dataclass
class CveInfo:
    cve: str
    epss: float | None = None
    epss_percentile: float | None = None
    kev: bool = False
    kev_short_desc: str | None = None
    kev_due_date: str | None = None

    def risk_multiplier(self) -> float:
        """EPSS × KEV multiplier for risk-ranking."""
        m = 1.0
        if self.epss is not None:
            m *= 1.0 + self.epss
        if self.kev:
            m *= 2.0
        return m


@dataclass
class DepVuln:
    """A vulnerability affecting a dependency."""

    id: str  # CVE-YYYY-NNNN or GHSA-...
    summary: str
    severity: str = "unknown"  # critical/high/medium/low/info
    cvss_score: float = 0.0
    cvss_vector: str = ""
    affected_versions: list[str] = field(default_factory=list)
    fixed_versions: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    cve_info: CveInfo | None = None


class CveFeed:
    """Local CVE/EPSS/KEV lookup with network fallback for OSV queries."""

    def __init__(self):
        self.conn = _connect()

    def close(self):
        self.conn.close()

    # ─── Refresh ──────────────────────────────────────────────────────

    async def refresh(self, force: bool = False) -> dict[str, Any]:
        """Refresh EPSS and KEV feeds. Returns a summary."""
        result: dict[str, Any] = {"epss": 0, "kev": 0, "errors": []}
        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                r = await client.get(EPSS_URL)
                r.raise_for_status()
                buf = gzip.decompress(r.content).decode()
                reader = csv.DictReader(io.StringIO(buf), skipinitialspace=True)
                # CSV has a comment first line; reader may need to skip it
                rows = []
                for row in reader:
                    if "cve" in row and row.get("cve", "").startswith("CVE-"):
                        rows.append((
                            row["cve"],
                            float(row.get("epss", 0)),
                            float(row.get("percentile", 0)),
                            "",
                        ))
                self.conn.executemany(
                    "INSERT OR REPLACE INTO epss VALUES (?, ?, ?, ?)", rows
                )
                self.conn.commit()
                result["epss"] = len(rows)
            except Exception as e:  # noqa: BLE001
                result["errors"].append(f"epss: {e}")

            try:
                r = await client.get(KEV_URL)
                r.raise_for_status()
                data = r.json()
                rows = [
                    (
                        v.get("cveID", ""),
                        v.get("vendorProject", ""),
                        v.get("product", ""),
                        v.get("shortDescription", ""),
                        v.get("requiredAction", ""),
                        v.get("dueDate", ""),
                    )
                    for v in data.get("vulnerabilities", [])
                ]
                self.conn.execute("DELETE FROM kev")
                self.conn.executemany(
                    "INSERT INTO kev VALUES (?, ?, ?, ?, ?, ?)", rows
                )
                self.conn.commit()
                result["kev"] = len(rows)
            except Exception as e:  # noqa: BLE001
                result["errors"].append(f"kev: {e}")
        return result

    # ─── Lookups ──────────────────────────────────────────────────────

    def enrich(self, cve: str) -> CveInfo:
        info = CveInfo(cve=cve)
        row = self.conn.execute(
            "SELECT epss, percentile FROM epss WHERE cve = ?", (cve,)
        ).fetchone()
        if row:
            info.epss, info.epss_percentile = row[0], row[1]
        row = self.conn.execute(
            "SELECT short_desc, due_date FROM kev WHERE cve = ?", (cve,)
        ).fetchone()
        if row:
            info.kev = True
            info.kev_short_desc, info.kev_due_date = row[0], row[1]
        return info

    async def osv_query(
        self,
        ecosystem: str,
        package: str,
        version: str,
    ) -> list[DepVuln]:
        """Query OSV.dev for a single package@version. Caches results."""
        row = self.conn.execute(
            "SELECT vulns_json FROM osv_cache "
            "WHERE ecosystem=? AND package=? AND version=?",
            (ecosystem, package, version),
        ).fetchone()
        if row:
            return [DepVuln(**v) for v in _decode_cached(row[0], self)]

        body = {
            "version": version,
            "package": {"name": package, "ecosystem": ecosystem},
        }
        vulns: list[DepVuln] = []
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                r = await client.post(OSV_QUERY_URL, json=body)
                r.raise_for_status()
                data = r.json()
            for v in data.get("vulns", []):
                sev = _osv_severity(v)
                cve_id = _primary_id(v)
                info = self.enrich(cve_id) if cve_id.startswith("CVE-") else None
                vulns.append(DepVuln(
                    id=cve_id,
                    summary=v.get("summary", "")[:500],
                    severity=sev[0],
                    cvss_score=sev[1],
                    cvss_vector=sev[2],
                    affected_versions=_affected_versions(v),
                    fixed_versions=_fixed_versions(v),
                    references=[r.get("url", "") for r in v.get("references", [])][:5],
                    cve_info=info,
                ))
        except Exception:  # noqa: BLE001
            return []

        self.conn.execute(
            "INSERT OR REPLACE INTO osv_cache VALUES (?, ?, ?, ?, datetime('now'))",
            (ecosystem, package, version, _encode_for_cache(vulns)),
        )
        self.conn.commit()
        return vulns


def _encode_for_cache(vulns: list[DepVuln]) -> str:
    out = []
    for v in vulns:
        d = {k: getattr(v, k) for k in (
            "id", "summary", "severity", "cvss_score", "cvss_vector",
            "affected_versions", "fixed_versions", "references",
        )}
        out.append(d)
    return json.dumps(out)


def _decode_cached(raw: str, feed: CveFeed) -> list[dict[str, Any]]:
    out = []
    for d in json.loads(raw):
        if d.get("id", "").startswith("CVE-"):
            d["cve_info"] = feed.enrich(d["id"])
        out.append(d)
    return out


def _primary_id(v: dict[str, Any]) -> str:
    for a in v.get("aliases", []):
        if a.startswith("CVE-"):
            return a
    return v.get("id", "")


def _osv_severity(v: dict[str, Any]) -> tuple[str, float, str]:
    """Extract (severity_label, cvss_score, cvss_vector)."""
    for s in v.get("severity", []):
        if s.get("type", "").startswith("CVSS_V"):
            vec = s.get("score", "")
            score = _cvss_score_from_vector(vec)
            label = _label_for_score(score)
            return label, score, vec
    # Fallback to database_specific.severity
    for aff in v.get("affected", []):
        db = aff.get("database_specific", {})
        sev = (db.get("severity") or "").lower()
        if sev in {"critical", "high", "medium", "low"}:
            return sev, _score_for_label(sev), ""
    return "medium", 5.0, ""


def _cvss_score_from_vector(vec: str) -> float:
    """Best-effort parse — real CVSS calc lives in reporting/cvss.py."""
    # OSV often embeds the numeric score at the end, e.g. "CVSS:3.1/... " or pure "8.8"
    parts = vec.strip().split("/")
    for p in parts:
        try:
            return float(p)
        except ValueError:
            continue
    try:
        return float(vec)
    except (ValueError, TypeError):
        return 5.0


def _label_for_score(score: float) -> str:
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    if score >= 0.1:
        return "low"
    return "info"


def _score_for_label(label: str) -> float:
    return {"critical": 9.5, "high": 7.5, "medium": 5.0, "low": 2.5}.get(label, 5.0)


def _affected_versions(v: dict[str, Any]) -> list[str]:
    out = []
    for aff in v.get("affected", []):
        for r in aff.get("ranges", []):
            for ev in r.get("events", []):
                if "introduced" in ev:
                    out.append(f">={ev['introduced']}")
                if "fixed" in ev:
                    out.append(f"<{ev['fixed']}")
    return out


def _fixed_versions(v: dict[str, Any]) -> list[str]:
    out = []
    for aff in v.get("affected", []):
        for r in aff.get("ranges", []):
            for ev in r.get("events", []):
                if "fixed" in ev:
                    out.append(ev["fixed"])
    return list(dict.fromkeys(out))


# ─── Singleton helpers ────────────────────────────────────────────────

_feed: CveFeed | None = None


def get_feed() -> CveFeed:
    global _feed
    if _feed is None:
        _feed = CveFeed()
    return _feed
