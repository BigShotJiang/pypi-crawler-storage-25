"""
hooks/base.py — Agent detection and hook writing logic.
Detects which AI agents are present in the current project.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List

# Hook template that gets appended to agent config files.
# Written as natural language so agents (which read markdown) can follow it.
HOOK_TEMPLATE = """
# watchdog-ai hook — do not edit manually

You are being monitored by watchdog-ai. You MUST follow these rules every session:

1. **At the start of each session**, create a short random run ID (e.g. `run_a3f9b2c1`) and append this JSON line to `.watchdog/runs.jsonl`:
   `{"run_id":"<run_id>","event_type":"run_start","agent":"<your agent name>","timestamp":"<ISO8601 UTC>","model":"<model>","tool_name":"","input_hash":"","cost_usd":0.0,"duration_ms":0,"is_loop":false,"loop_count":0,"run_status":"running","message":""}`

2. **After every tool call you make**, append this JSON line to `.watchdog/runs.jsonl`:
   `{"run_id":"<same run_id>","event_type":"tool_call","agent":"<your agent name>","timestamp":"<ISO8601 UTC>","model":"<model>","tool_name":"<tool name>","input_hash":"<md5(input)[:8]>","cost_usd":0.0,"duration_ms":0,"is_loop":false,"loop_count":0,"run_status":"running","message":""}`

3. **At the end of the session**, append a `run_end` event with `run_status` set to `"success"` or `"failed"`.

Create `.watchdog/` directory if it does not exist. If writing fails for any reason, skip silently.
"""


def detect_agents() -> List[str]:
    """
    Detect which AI agents are present in the current project.
    Returns a list of agent names.
    """
    agents = []
    cwd = Path.cwd()
    
    # Check for Windsurf
    if (cwd / ".windsurfrules").exists() or (cwd / ".windsurf").exists():
        agents.append("windsurf")
    
    # Check for Cursor
    if (cwd / ".cursorrules").exists() or (cwd / ".cursor").exists():
        agents.append("cursor")
    
    # Check for Claude Code
    if (cwd / "CLAUDE.md").exists():
        agents.append("claude-code")
    
    # Check for Copilot
    if (cwd / ".github" / "copilot-instructions.md").exists():
        agents.append("copilot")
    
    # Check for Codex CLI
    if (cwd / "AGENTS.md").exists():
        agents.append("codex")
    
    # Check for Zed
    if (cwd / ".zedrules").exists() or (cwd / ".zed" / "rules.md").exists():
        agents.append("zed")
    
    return agents


def write_hook(agent: str, target_dir: Path | None = None) -> None:
    """
    Write the watchdog hook to the appropriate config file for the given agent.
    """
    cwd = target_dir if target_dir else Path.cwd()
    
    if agent == "windsurf":
        hook_file = cwd / ".windsurfrules"
        if not hook_file.exists():
            hook_file = cwd / ".windsurf" / "rules.md"
            hook_file.parent.mkdir(exist_ok=True)
    
    elif agent == "cursor":
        hook_file = cwd / ".cursorrules"
        if not hook_file.exists():
            hook_file = cwd / ".cursor" / "rules.md"
            hook_file.parent.mkdir(exist_ok=True)
    
    elif agent == "claude-code":
        hook_file = cwd / "CLAUDE.md"
    
    elif agent == "copilot":
        hook_file = cwd / ".github" / "copilot-instructions.md"
        hook_file.parent.mkdir(parents=True, exist_ok=True)
    
    elif agent == "codex":
        hook_file = cwd / "AGENTS.md"
    
    elif agent == "zed":
        hook_file = cwd / ".zedrules"
        if not hook_file.exists():
            hook_file = cwd / ".zed" / "rules.md"
            hook_file.parent.mkdir(exist_ok=True)
    
    else:
        raise ValueError(f"Unknown agent: {agent}")
    
    # Check if hook already exists
    if hook_file.exists():
        existing_content = hook_file.read_text()
        if "# watchdog-ai hook — do not edit manually" in existing_content:
            return  # Hook already exists
    
    # Append the hook
    with hook_file.open("a") as f:
        f.write(HOOK_TEMPLATE)
    
    print(f"Added watchdog hook to {hook_file}")


def get_hook_file_path(agent: str) -> Path:
    """Get the path to the hook file for a given agent."""
    cwd = Path.cwd()
    
    if agent == "windsurf":
        return cwd / ".windsurfrules"
    elif agent == "cursor":
        return cwd / ".cursorrules"
    elif agent == "claude-code":
        return cwd / "CLAUDE.md"
    elif agent == "copilot":
        return cwd / ".github" / "copilot-instructions.md"
    elif agent == "codex":
        return cwd / "AGENTS.md"
    elif agent == "zed":
        return cwd / ".zedrules"
    else:
        raise ValueError(f"Unknown agent: {agent}")
