"""
hooks package for watchdog-ai agent integrations.
"""
from .base import detect_agents, write_hook
from .windsurf import install_windsurf_hook, detect_windsurf
from .cursor import install_cursor_hook, detect_cursor
from .claude import install_claude_hook, detect_claude
from .copilot import install_copilot_hook, detect_copilot
from .codex import install_codex_hook, detect_codex

__all__ = [
    "detect_agents",
    "write_hook",
    "install_windsurf_hook",
    "detect_windsurf",
    "install_cursor_hook", 
    "detect_cursor",
    "install_claude_hook",
    "detect_claude",
    "install_copilot_hook",
    "detect_copilot",
    "install_codex_hook",
    "detect_codex",
]
