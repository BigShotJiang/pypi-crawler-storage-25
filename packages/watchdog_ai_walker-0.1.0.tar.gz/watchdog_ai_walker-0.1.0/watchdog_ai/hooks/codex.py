"""
hooks/codex.py — Codex CLI-specific hook implementation.
"""
from __future__ import annotations

from pathlib import Path
from .base import write_hook, get_hook_file_path


def install_codex_hook() -> None:
    """Install the watchdog hook for Codex CLI."""
    hook_file = get_hook_file_path("codex")
    
    # Codex-specific hook content
    codex_hook = """
# watchdog-ai hook — do not edit manually
# This block enables watchdog-ai to monitor Codex CLI tool calls
import json
import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path

def _watchdog_log_event(event_type, tool_name="", input_data="", cost_usd=0.0, duration_ms=0, message=""):
    try:
        run_id = os.environ.get("WATCHDOG_RUN_ID", f"run_{hashlib.md5(datetime.now().isoformat().encode()).hexdigest()[:8]}")
        agent = "codex"
        model = os.environ.get("WATCHDOG_MODEL", "claude-sonnet-4-6")
        
        input_hash = hashlib.md5(str(input_data).encode()).hexdigest()[:8]
        
        event = {
            "run_id": run_id,
            "event_type": event_type,
            "agent": agent,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "model": model,
            "tool_name": tool_name,
            "input_hash": input_hash,
            "output_size_tokens": 0,
            "cost_usd": cost_usd,
            "duration_ms": duration_ms,
            "is_loop": False,
            "loop_count": 0,
            "run_status": "running" if event_type == "tool_call" else "success",
            "message": message
        }
        
        watchdog_dir = Path(".watchdog")
        watchdog_dir.mkdir(exist_ok=True)
        runs_file = watchdog_dir / "runs.jsonl"
        
        with runs_file.open("a") as f:
            f.write(json.dumps(event) + "\\n")
    except Exception:
        pass  # Silently fail to avoid breaking Codex CLI workflows

# Hook into Codex CLI's tool system
# This will be called by Codex CLI when tools are executed
"""
    
    # Check if hook already exists
    if hook_file.exists():
        existing_content = hook_file.read_text()
        if "# watchdog-ai hook — do not edit manually" in existing_content:
            return
    
    # Append the hook
    with hook_file.open("a") as f:
        f.write(codex_hook)


def detect_codex() -> bool:
    """Check if Codex CLI is present in the current project."""
    cwd = Path.cwd()
    return (cwd / "AGENTS.md").exists()
