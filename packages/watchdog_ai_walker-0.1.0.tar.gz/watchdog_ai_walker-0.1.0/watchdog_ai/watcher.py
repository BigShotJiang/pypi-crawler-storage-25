"""
watcher.py — Autonomic Shadow.
Detects AI agents, auto-injects tracking hooks, and monitors project files as a backup.
"""
from __future__ import annotations

import time
import uuid
import threading
from pathlib import Path

import psutil
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from .storage import append
from .tracer import TraceEvent
from .hooks.base import write_hook

KNOWN_AGENTS: dict[str, str] = {
    "windsurf": "windsurf",
    "cursor": "cursor",
    "claude": "claude-code",
    "codex": "codex",
    "gemini": "gemini",
    "aider": "aider",
    "zed": "zed",
    "code": "vscode-copilot",
}

def _make_run_id() -> str:
    return f"run_{uuid.uuid4().hex[:8]}"

class ShadowProjectEventHandler(FileSystemEventHandler):
    """Watches a project folder and logs file changes as shadow events."""
    def __init__(self, run_id: str, agent: str, on_event=None):
        super().__init__()
        self.run_id = run_id
        self.agent = agent
        self.on_event = on_event
        self.last_event_time = 0.0

    def on_modified(self, event):
        if event.is_directory:
            return
            
        path = str(event.src_path)
        if ".watchdog" in path or ".git" in path:
            return
            
        # Debounce events (watchdog fires multiple modified events per save)
        now = time.time()
        if now - self.last_event_time < 1.0:
            return
        self.last_event_time = now

        trace = TraceEvent(
            run_id=self.run_id,
            event_type="shadow_edit",
            agent=self.agent,
            tool_name="os_file_modified",
            input_hash=Path(path).name, # Use filename as "input_hash" for display
            message=f"Shadow detection: {Path(path).name} modified"
        )
        append(trace)
        if self.on_event:
            self.on_event(trace, None)

def _is_valid_project_dir(path: Path) -> bool:
    """Check if a path is safe and looks like a real code project."""
    path_str = str(path).lower()
    
    # 1. Block system paths to prevent accidental hooking of internal files
    blocked = ["appdata", "program files", "windows", "system32", "node_modules"]
    if any(b in path_str for b in blocked):
        return False
        
    # 2. Require a project marker (prevents hooking random user folders)
    markers = [".git", "package.json", "pyproject.toml", "requirements.txt", "CLAUDE.md", "Cargo.toml"]
    if not any((path / m).exists() for m in markers):
        return False
        
    return True

def _get_active_agents() -> dict[int, tuple[str, Path | None]]:
    """Return {pid: (agent_name, cwd)} for all running known agent processes."""
    active: dict[int, tuple[str, Path | None]] = {}
    for proc in psutil.process_iter(["pid", "name", "exe"]):
        try:
            name = proc.info["name"].lower().replace(".exe", "").strip()
            if name in KNOWN_AGENTS:
                agent = KNOWN_AGENTS[name]
                cwd = None
                
                # Check process executable path for false positives
                exe_path = proc.info.get("exe") or ""
                blocked = ["appdata", "program files", "windows", "system32", "node_modules"]
                if any(b in str(exe_path).lower() for b in blocked) and name == "codex":
                    continue # Ignore "codex" if it's just an internal tool inside AppData
                    
                try:
                    cwd_str = proc.cwd()
                    if cwd_str:
                        potential_cwd = Path(cwd_str)
                        if _is_valid_project_dir(potential_cwd):
                            cwd = potential_cwd
                except (psutil.AccessDenied, psutil.NoSuchProcess):
                    pass
                    
                active[proc.info["pid"]] = (agent, cwd)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return active

def watch_loop(poll_seconds: float = 2.0, on_event=None) -> None:
    """
    The Autonomic Shadow Loop.
    1. Detects agent processes.
    2. Auto-injects rules into their CWD.
    3. Starts a file watcher on the CWD as backup.
    """
    # agent_name -> (set_of_pids, run_id, observer_instance)
    active: dict[str, tuple[set[int], str, Observer | None]] = {}

    while True:
        current = _get_active_agents()  # {pid: (agent, cwd)}

        # Group current pids by agent name, and grab the first valid cwd we find
        current_by_agent: dict[str, tuple[set[int], Path | None]] = {}
        for pid, (agent, cwd) in current.items():
            if agent not in current_by_agent:
                current_by_agent[agent] = (set(), cwd)
            else:
                existing_pids, existing_cwd = current_by_agent[agent]
                current_by_agent[agent] = (existing_pids | {pid}, existing_cwd or cwd)
            # Add pid to the set (workaround for tuple mutability above)
            current_by_agent[agent][0].add(pid)

        # New agents (first time we see this agent name)
        for agent, (pids, cwd) in current_by_agent.items():
            if agent not in active:
                run_id = _make_run_id()
                observer = None
                
                # SHADOW INIT: Auto-inject rules and start file watcher
                if cwd and cwd.exists():
                    try:
                        # 1. Inject rules
                        write_hook(agent, target_dir=cwd)
                        
                        # 2. Start OS File Watcher
                        handler = ShadowProjectEventHandler(run_id, agent, on_event)
                        observer = Observer()
                        observer.schedule(handler, str(cwd), recursive=True)
                        observer.start()
                    except Exception as e:
                        pass # Fail silently, keep process detection alive

                active[agent] = (pids, run_id, observer)
                event = TraceEvent(run_id=run_id, event_type="run_start", agent=agent, message=f"Project: {cwd.name if cwd else 'Unknown'}")
                append(event)
                if on_event:
                    on_event(event, min(pids))
            else:
                # Update pid set for existing agent
                old_pids, run_id, observer = active[agent]
                active[agent] = (pids, run_id, observer)

        # Agents that have fully exited (all their PIDs are gone)
        for agent in list(active):
            if agent not in current_by_agent:
                pids, run_id, observer = active.pop(agent)
                
                # Stop the file watcher
                if observer:
                    observer.stop()
                    observer.join()
                
                event = TraceEvent(run_id=run_id, event_type="run_end", agent=agent, run_status="success")
                append(event)
                if on_event:
                    on_event(event, None)

        time.sleep(poll_seconds)
