"""
cli.py — All Typer commands for watchdog-ai.
Thin wrappers that call into tracer, storage, renderer, telemetry.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from . import __version__
from .hooks.base import detect_agents, write_hook
from .renderer import (
    render_live_tail,
    render_runs_list,
    render_run_detail,
    render_stats,
    render_version,
    render_clear_confirm,
    render_event,
    render_tail_live,
)
from .storage import list_runs, get_run, aggregate_stats, clear_all, RUNS_FILE
from .telemetry import ping_init, ping_command, should_telemetry
from .watcher import watch_loop
from .tracer import TraceEvent

app = typer.Typer(help="watchdog-ai — CLI observability for AI coding agents")
console = Console()


@app.command()
def init() -> None:
    """Detect agents in project and write hook config."""
    agents = detect_agents()
    
    if not agents:
        console.print("[yellow]No known AI agents detected. Writing hooks for all supported agents.[/yellow]")
        agents = ["windsurf", "cursor", "claude-code", "copilot", "codex"]
    
    for agent in agents:
        try:
            write_hook(agent)
            console.print(f"[green]✓[/green] Added hook to {agent}")
        except Exception as e:
            console.print(f"[red]✗[/red] Failed to add hook to {agent}: {e}")
    
    if should_telemetry():
        ping_init(agents)
    
    console.print("[green]watchdog-ai initialized successfully![/green]")


@app.command()
def tail() -> None:
    """Live stream of .watchdog/runs.jsonl as events arrive. Ctrl+C to stop."""
    try:
        render_tail_live(RUNS_FILE)
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped.[/yellow]")

    if should_telemetry():
        ping_command("tail")


@app.command()
def runs() -> None:
    """List of all past runs with status, cost, duration."""
    runs = list_runs()
    
    if not runs:
        console.print("[yellow]No runs found.[/yellow]")
        return
    
    render_runs_list(runs)
    
    if should_telemetry():
        ping_command("runs")


@app.command()
def show(run_id: str) -> None:
    """Full trace for a specific run."""
    events = get_run(run_id)
    
    if not events:
        console.print(f"[red]No run found with ID: {run_id}[/red]")
        return
    
    render_run_detail(events)
    
    if should_telemetry():
        ping_command("show")


@app.command()
def stats() -> None:
    """Aggregate: total cost, failure rate, avg steps, loops caught."""
    stats_data = aggregate_stats()
    
    if stats_data["total_runs"] == 0:
        console.print("[yellow]No runs found.[/yellow]")
        return
    
    render_stats(stats_data)
    
    if should_telemetry():
        ping_command("stats")


@app.command()
def clear(force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation")) -> None:
    """Delete all local run logs."""
    if not force:
        if not render_clear_confirm():
            console.print("[yellow]Clear cancelled.[/yellow]")
            return
    
    lines_deleted = clear_all()
    console.print(f"[green]Deleted {lines_deleted} log lines.[/green]")
    
    if should_telemetry():
        ping_command("clear")


@app.command()
def watch() -> None:
    """Auto-detect AI agent processes and log run_start/run_end. Ctrl+C to stop."""
    from .watcher import KNOWN_AGENTS
    agent_list = ", ".join(KNOWN_AGENTS.keys())
    console.print("[green]watchdog-ai is watching for AI agents...[/green] [dim]Ctrl+C to stop[/dim]")
    console.print(f"[dim]Detecting: {agent_list}[/dim]")
    console.print("[dim]Note: browser-based tools (Gemini web, ChatGPT, DeepSeek) cannot be detected — they run in a browser tab.[/dim]\n")

    def on_event(event, pid):
        render_event(event, pid)

    try:
        watch_loop(on_event=on_event)
    except KeyboardInterrupt:
        console.print("\n[yellow]watchdog stopped.[/yellow]")

    if should_telemetry():
        ping_command("watch")


@app.command()
def version() -> None:
    """Show version."""
    render_version(__version__)


def main() -> None:
    """Entry point for the CLI."""
    try:
        app()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user.[/yellow]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
