"""
renderer.py — Rich terminal output for watchdog-ai.
Stateless functions that take data and return Rich renderables.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import List

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich.live import Live
from rich.layout import Layout
from rich.align import Align

from .tracer import TraceEvent

console = Console()


def render_live_tail(events: List[TraceEvent]) -> None:
    """Render a live tail of the run events."""
    if not events:
        console.print("[yellow]No events to display.[/yellow]")
        return
    
    # Create a table for events
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Time", style="dim", width=12)
    table.add_column("Type", style="bold", width=12)
    table.add_column("Tool", width=20)
    table.add_column("Cost", justify="right", width=8)
    table.add_column("Duration", justify="right", width=10)
    table.add_column("Loop", width=6)
    
    for event in events:
        time_str = datetime.fromisoformat(event.timestamp).strftime("%H:%M:%S")
        
        # Color coding for event types
        event_color = {
            "run_start": "green",
            "tool_call": "blue",
            "loop_detected": "red",
            "run_end": "yellow" if event.run_status == "success" else "red"
        }.get(event.event_type, "white")
        
        event_text = Text(event.event_type, style=event_color)
        
        # Loop indicator
        loop_text = "∞" if event.is_loop else ""
        if event.is_loop:
            loop_text = Text(loop_text, style="bold red")
        
        # Cost formatting
        cost_str = f"${event.cost_usd:.4f}" if event.cost_usd > 0 else ""
        
        # Duration formatting
        duration_str = f"{event.duration_ms}ms" if event.duration_ms > 0 else ""
        
        table.add_row(
            time_str,
            event_text,
            event.tool_name,
            cost_str,
            duration_str,
            loop_text
        )
    
    console.print(Panel(table, title=f"Run: {events[0].run_id}", border_style="blue"))


def render_runs_list(runs: List[dict]) -> None:
    """Render a list of all runs."""
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Run ID", width=12)
    table.add_column("Agent", width=12)
    table.add_column("Status", width=10)
    table.add_column("Tool Calls", justify="right", width=10)
    table.add_column("Cost", justify="right", width=10)
    table.add_column("Loops", justify="right", width=8)
    table.add_column("Started", width=20)
    
    for run in runs:
        # Status color coding
        status_color = {
            "success": "green",
            "failed": "red",
            "running": "yellow",
            "killed": "red"
        }.get(run["status"], "white")
        
        status_text = Text(run["status"], style=status_color)
        
        # Started time formatting
        started_dt = datetime.fromisoformat(run["started_at"])
        started_str = started_dt.strftime("%Y-%m-%d %H:%M:%S")
        
        table.add_row(
            run["run_id"][:8] + "...",
            run["agent"],
            status_text,
            str(run["tool_calls"]),
            f"${run['total_cost_usd']:.4f}",
            str(run["loops_caught"]),
            started_str
        )
    
    console.print(Panel(table, title="All Runs", border_style="blue"))


def render_run_detail(events: List[TraceEvent]) -> None:
    """Render detailed information for a specific run."""
    if not events:
        return
    
    run_id = events[0].run_id
    
    # Summary panel
    tool_calls = [e for e in events if e.event_type == "tool_call"]
    loops = [e for e in events if e.event_type == "loop_detected"]
    total_cost = sum(e.cost_usd for e in tool_calls)
    
    summary_text = f"""
Run ID: {run_id}
Agent: {events[0].agent}
Model: {events[0].model}
Tool Calls: {len(tool_calls)}
Loops Detected: {len(loops)}
Total Cost: ${total_cost:.4f}
Status: {events[-1].run_status}
"""
    
    console.print(Panel(summary_text.strip(), title="Run Summary", border_style="blue"))
    
    # Detailed events tree
    tree = Tree(f"Events for {run_id}")
    
    for event in events:
        event_color = {
            "run_start": "green",
            "tool_call": "blue", 
            "loop_detected": "red",
            "run_end": "yellow" if event.run_status == "success" else "red"
        }.get(event.event_type, "white")
        
        branch = tree.add(f"[{event_color}]{event.event_type}[/{event_color}] - {event.timestamp}")
        
        if event.event_type == "tool_call":
            branch.add(f"Tool: {event.tool_name}")
            branch.add(f"Cost: ${event.cost_usd:.4f}")
            branch.add(f"Duration: {event.duration_ms}ms")
            branch.add(f"Input Hash: {event.input_hash}")
            if event.is_loop:
                branch.add("[red]LOOP DETECTED[/red]")
        elif event.event_type == "loop_detected":
            branch.add(f"[red]Loop Count: {event.loop_count}[/red]")
            branch.add(f"[red]Message: {event.message}[/red]")
        elif event.event_type == "run_end":
            branch.add(f"Status: {event.run_status}")
            if event.message:
                branch.add(f"Message: {event.message}")
    
    console.print(tree)


def render_stats(stats: dict) -> None:
    """Render aggregate statistics."""
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Metric", width=25)
    table.add_column("Value", justify="right", width=15)
    
    table.add_row("Total Runs", str(stats["total_runs"]))
    table.add_row("Total Cost", f"${stats['total_cost_usd']:.4f}")
    table.add_row("Total Tool Calls", str(stats["total_tool_calls"]))
    table.add_row("Loops Caught", str(stats["loops_caught"]))
    table.add_row("Failures", str(stats["failures"]))
    table.add_row("Avg Cost per Run", f"${stats['avg_cost_per_run']:.4f}")
    
    # Calculate success rate
    success_rate = ((stats["total_runs"] - stats["failures"]) / stats["total_runs"] * 100) if stats["total_runs"] > 0 else 0
    table.add_row("Success Rate", f"{success_rate:.1f}%")
    
    console.print(Panel(table, title="Statistics", border_style="blue"))


def render_version(version: str) -> None:
    """Render version information."""
    console.print(f"watchdog-ai version [bold green]{version}[/bold green]")


def render_clear_confirm() -> bool:
    """Render confirmation prompt for clearing data."""
    console.print("[red]This will delete all local run logs. This action cannot be undone.[/red]")
    response = console.input("[yellow]Are you sure you want to continue? (y/N): [/yellow]")
    return response.lower() in ['y', 'yes']


def render_event(event: TraceEvent, pid: int | None = None) -> None:
    """Print a single event line to the terminal (used by watch and tail live)."""
    import time as _time
    time_str = datetime.fromisoformat(event.timestamp).strftime("%H:%M:%S")
    color = {
        "run_start": "green",
        "run_end": "yellow",
        "tool_call": "blue",
        "loop_detected": "red",
        "shadow_edit": "magenta",
    }.get(event.event_type, "white")

    pid_str = f"[dim](pid {pid})[/dim] " if pid else ""
    
    if event.event_type == "shadow_edit":
        tool_str = f"  [dim]OS Watcher: {event.input_hash}[/dim]"
    else:
        tool_str = f"  [dim]{event.tool_name}[/dim]" if event.tool_name else ""
        
    console.print(f"[dim]{time_str}[/dim] {pid_str}[{color}]{event.event_type}[/{color}] [bold]{event.agent}[/bold]{tool_str}")


def render_tail_live(runs_file) -> None:
    """Stream new events from runs.jsonl as they appear. Blocks until Ctrl+C."""
    import time as _time
    from pathlib import Path

    console.print("[dim]Watching .watchdog/runs.jsonl — Ctrl+C to stop[/dim]")
    last_size = runs_file.stat().st_size if runs_file.exists() else 0

    while True:
        if not runs_file.exists():
            _time.sleep(0.5)
            continue
        current_size = runs_file.stat().st_size
        if current_size > last_size:
            with runs_file.open("r") as f:
                f.seek(last_size)
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            event = TraceEvent.from_json(line)
                            render_event(event)
                        except Exception:
                            pass
            last_size = current_size
        _time.sleep(0.5)

