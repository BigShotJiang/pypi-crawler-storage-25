"""
storage.py — append-only JSONL storage for .watchdog/runs.jsonl
Never rewrites the whole file. Never loads everything into memory unless aggregating.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterator

from .tracer import TraceEvent

WATCHDOG_DIR = Path(".watchdog")
RUNS_FILE = WATCHDOG_DIR / "runs.jsonl"


def ensure_dir() -> None:
    WATCHDOG_DIR.mkdir(exist_ok=True)


def append(event: TraceEvent) -> None:
    ensure_dir()
    with RUNS_FILE.open("a") as f:
        f.write(event.to_json() + "\n")


def iter_events() -> Iterator[TraceEvent]:
    """Lazily yield all events from the log file."""
    if not RUNS_FILE.exists():
        return
    with RUNS_FILE.open("r") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    yield TraceEvent.from_json(line)
                except Exception:
                    continue  # skip malformed lines silently


def get_run(run_id: str) -> list[TraceEvent]:
    return [e for e in iter_events() if e.run_id == run_id]


def list_runs() -> list[dict]:
    """
    Return one summary dict per run_id, in reverse chronological order.
    Only reads the file once.
    """
    runs: dict[str, dict] = {}

    for e in iter_events():
        if e.run_id not in runs:
            runs[e.run_id] = {
                "run_id": e.run_id,
                "agent": e.agent,
                "model": e.model,
                "started_at": e.timestamp,
                "status": e.run_status,
                "total_cost_usd": 0.0,
                "tool_calls": 0,
                "loops_caught": 0,
                "last_event": e.timestamp,
            }
        r = runs[e.run_id]
        r["last_event"] = e.timestamp
        r["status"] = e.run_status
        if e.event_type == "tool_call":
            r["tool_calls"] += 1
            r["total_cost_usd"] = round(r["total_cost_usd"] + e.cost_usd, 4)
        if e.event_type == "loop_detected":
            r["loops_caught"] += 1

    # reverse chron — last started first
    return sorted(runs.values(), key=lambda x: x["started_at"], reverse=True)


def aggregate_stats() -> dict:
    """Single-pass aggregation for `watchdog stats`."""
    total_runs = 0
    total_cost = 0.0
    total_tool_calls = 0
    total_loops = 0
    failures = 0
    seen_runs: set[str] = set()

    for e in iter_events():
        if e.run_id not in seen_runs:
            seen_runs.add(e.run_id)
            total_runs += 1
        if e.event_type == "tool_call":
            total_tool_calls += 1
            total_cost += e.cost_usd
        if e.event_type == "loop_detected":
            total_loops += 1
        if e.event_type == "run_end" and e.run_status == "failed":
            failures += 1

    return {
        "total_runs": total_runs,
        "total_cost_usd": round(total_cost, 4),
        "total_tool_calls": total_tool_calls,
        "loops_caught": total_loops,
        "failures": failures,
        "avg_cost_per_run": round(total_cost / total_runs, 4) if total_runs else 0.0,
    }


def clear_all() -> int:
    """Delete the runs file. Returns number of lines deleted."""
    if not RUNS_FILE.exists():
        return 0
    lines = sum(1 for _ in RUNS_FILE.open())
    RUNS_FILE.unlink()
    return lines
