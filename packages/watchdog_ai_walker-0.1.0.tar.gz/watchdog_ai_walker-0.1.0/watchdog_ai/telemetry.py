"""
telemetry.py — PostHog anonymous telemetry for watchdog-ai.
All telemetry calls are fire-and-forget and never block.
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

# Try to import posthog, but don't fail if it's not available
try:
    import posthog
except ImportError:
    posthog = None

TELEMETRY_ENABLED = True
POSTHOG_API_KEY = "phc_..."  # This would be a real PostHog API key in production


def _get_or_create_user_id() -> str:
    """Get or create a unique user ID for telemetry."""
    watchdog_home = Path.home() / ".watchdog"
    id_file = watchdog_home / "id"
    
    if not id_file.exists():
        watchdog_home.mkdir(exist_ok=True)
        import uuid
        user_id = str(uuid.uuid4())
        id_file.write_text(user_id)
        return user_id
    
    return id_file.read_text().strip()


def _get_system_info() -> dict:
    """Get basic system information for telemetry."""
    return {
        "os": platform.system().lower(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "version": "0.1.0",  # This should match the package version
    }


def should_telemetry() -> bool:
    """Check if telemetry is enabled."""
    # Check environment variable
    if os.environ.get("WATCHDOG_NO_TELEMETRY", "0") == "1":
        return False
    
    # Check if posthog is available
    if posthog is None:
        return False
    
    return TELEMETRY_ENABLED


def _send_telemetry(event_name: str, properties: dict) -> None:
    """Send a telemetry event. This function is fire-and-forget."""
    if not should_telemetry():
        return
    
    try:
        user_id = _get_or_create_user_id()
        system_info = _get_system_info()
        
        # Merge user properties with event properties
        all_properties = {**system_info, **properties}
        
        # Initialize posthog if not already done
        if not posthog._initialized:
            posthog.api_key = POSTHOG_API_KEY
            posthog.host = "https://app.posthog.com"
        
        # Send the event
        posthog.capture(user_id, event_name, all_properties)
        
    except Exception:
        # Silently fail - telemetry should never break the CLI
        pass


def ping_init(agents: list[str]) -> None:
    """Send telemetry when watchdog is initialized."""
    _send_telemetry("watchdog_init", {
        "agent_count": len(agents),
        "agents": agents,
    })


def ping_command(command: str) -> None:
    """Send telemetry when a watchdog command is run."""
    _send_telemetry("watchdog_command", {
        "command": command,
    })


def ping_loop_detected(agent: str, loop_count: int, wasted_cost: float) -> None:
    """Send telemetry when a loop is detected."""
    _send_telemetry("watchdog_loop_detected", {
        "agent": agent,
        "loop_count": loop_count,
        "wasted_cost_usd": wasted_cost,
    })


def disable_telemetry() -> None:
    """Disable telemetry for future runs."""
    watchdog_home = Path.home() / ".watchdog"
    watchdog_home.mkdir(exist_ok=True)
    
    disable_file = watchdog_home / "no_telemetry"
    disable_file.write_text("1")


def enable_telemetry() -> None:
    """Enable telemetry for future runs."""
    watchdog_home = Path.home() / ".watchdog"
    disable_file = watchdog_home / "no_telemetry"
    
    if disable_file.exists():
        disable_file.unlink()
