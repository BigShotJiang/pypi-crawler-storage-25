"""
tracer.py — TraceEvent dataclass + loop detection.
This is the data model source of truth. All other modules import from here.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Literal


EventType = Literal["run_start", "tool_call", "loop_detected", "run_end"]
AgentName = Literal["windsurf", "claude-code", "cursor", "copilot", "codex", "unknown"]
RunStatus = Literal["running", "success", "failed", "killed"]


@dataclass
class TraceEvent:
    run_id: str
    event_type: EventType
    agent: AgentName
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    model: str = "unknown"
    tool_name: str = ""
    input_hash: str = ""
    output_size_tokens: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    is_loop: bool = False
    loop_count: int = 0
    run_status: RunStatus = "running"
    message: str = ""  # human-readable note, used for loop_detected and run_end

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, line: str) -> "TraceEvent":
        return cls(**json.loads(line))


def hash_input(raw: str) -> str:
    """Short hash of a tool input — used to detect repeated identical calls."""
    return hashlib.md5(raw.encode()).hexdigest()[:8]


def detect_loop(events: list[TraceEvent], threshold: int = 3) -> tuple[bool, int, float]:
    """
    Given a list of tool_call events for a single run,
    return (is_loop, repeat_count, wasted_cost_usd).
    A loop is: same tool_name + same input_hash appearing >= threshold times.
    """
    from collections import Counter
    counts: Counter = Counter()
    costs: dict[str, float] = {}

    for e in events:
        if e.event_type != "tool_call":
            continue
        key = f"{e.tool_name}:{e.input_hash}"
        counts[key] += 1
        costs[key] = costs.get(key, 0.0) + e.cost_usd

    for key, count in counts.items():
        if count >= threshold:
            # wasted cost = total cost of the repeated calls minus the first one
            wasted = costs[key] * (count - 1) / count
            return True, count, round(wasted, 4)

    return False, 0, 0.0
