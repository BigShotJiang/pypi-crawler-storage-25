"""
watchdog-ai — CLI observability for AI coding agents.
"""

__version__ = "0.1.0"
__author__ = "watchdog-ai team"
__description__ = "CLI observability for AI coding agents — Claude Code, Windsurf, Cursor, Copilot, Codex"
