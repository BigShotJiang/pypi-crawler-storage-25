# outerproduct-sdk
Python SDK for training and explaining tabular ML models with the OuterProduct API.

## Installation

```bash
pip install outerproduct
```

## Quick Start

```python
import outerproduct as op

# 1. Initialize the SDK
op.init(api_key="op_live_...")

# 2. Upload data
connector = op.FileUploadConnector()
dataset = connector.upload("credit.csv", label_column="default")

# 3. Train a reasoning model
rm = op.reasoning.fit(dataset)

# 4. Predict
predictions = rm.predict(X_new)

# 5. Explain
reasoning = rm.explain(X_new)
print(reasoning.feature_names[:3])
print(reasoning.attributions)
```

You can also set `OUTERPRODUCT_API_KEY` as an environment variable and call `op.init()` with no arguments.

## Usage

### Build a Dataset from Code

```python
import pandas as pd
import outerproduct as op

df = pd.read_csv("credit.csv")
dataset = op.Dataset.from_pandas(df, label_column="default")
```

### Train a Plain Model (No Explanations)

```python
trainer = op.Trainer.configure(dataset, model_types=["tabm", "xgboost"])
model = trainer.run(strategy="random")
predictions = model.predict(X_new)
```

### Distill a Black-Box Model

```python
# Wrap an external prediction endpoint
teacher = op.model.Predictor(
    "https://your-model-server.com/predict",
    headers={"Authorization": "Bearer ..."},
)

# Distill into a reasoning model
rm = op.reasoning.fit(dataset, teacher=teacher)
```

You can also distill an existing OuterProduct-trained model:

```python
trained = op.Trainer.configure(dataset).run()
rm = op.reasoning.fit(dataset, teacher=trained)
```

### Reasoning Model Operations

```python
# Per-sample explanations
reasoning = rm.explain(X)

# Predict + explain in one call
predictions, reasoning = rm.predict_and_explain(X)

# Global feature importance
reasoning = rm.interpret()

# Counterfactual scenario search
trace = rm.scenario(X, target_class=1, max_steps=10)

# Model-aware segmentation
trace = rm.segment(X, n_clusters=3)
```

### Non-Blocking Jobs

`reasoning.fit()` blocks until training completes by default. To return immediately:

```python
rm = op.reasoning.fit(dataset, non_blocking=True)
```

### Configuration

```python
import outerproduct as op

# Reads OUTERPRODUCT_API_KEY from environment
op.init()

# All options
op.init(
    api_key="op_live_...",
    base_url="https://api.outerproduct.com",
    hardware=op.ModalHardware(),
)
```

