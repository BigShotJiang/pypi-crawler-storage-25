"""OuterProduct — a Python SDK for training and explaining tabular ML models.

The package exposes a small, flat surface organised around the following
core concepts:

- :class:`~outerproduct.dataset.Dataset` — a tabular dataset with an optional label column and
  per-column schema (:class:`~outerproduct.dataset.Column`).
- :class:`~outerproduct.connector.Connector` — a source of data (:class:`~outerproduct.connector.FileUploadConnector`,
  :class:`~outerproduct.connector.S3Connector`, …) that produces a :class:`~outerproduct.dataset.Dataset`.
- :class:`~outerproduct.trainer.Trainer` — orchestrates general-purpose training and
  returns a :class:`~outerproduct.model.Model` via :meth:`~outerproduct.trainer.Trainer.configure` and
  :meth:`~outerproduct.trainer.Trainer.run`.
- :class:`~outerproduct.model.Model` — a trained predictor with :meth:`~outerproduct.model.Model.predict`.
- :class:`~outerproduct.model.Predictor` — a duck-typed wrapper around an external
  prediction endpoint, used to hand black-box models into
  :func:`~outerproduct.reasoning.fit` for distillation.
- :class:`~outerproduct.model.ReasoningModel` — a :class:`~outerproduct.model.Model` that also supports
  :meth:`~outerproduct.model.ReasoningModel.explain`, :meth:`~outerproduct.model.ReasoningModel.interpret`,
  :meth:`~outerproduct.model.ReasoningModel.scenario`, and :meth:`~outerproduct.model.ReasoningModel.segment`.
  Produced by :func:`~outerproduct.reasoning.fit`.
- :class:`~outerproduct.reasoning.Reasoning` / :class:`~outerproduct.reasoning.ReasoningTrace` — the typed results of
  reasoning calls.

Quickstart
----------
.. code-block:: python

    import outerproduct as op

    op.init(api_key="...")
    connector = op.FileUploadConnector()
    dataset = connector.upload("customers.csv", label_column="churn")
    reasoning_model = op.reasoning.fit(dataset)
    predictions = reasoning_model.predict(X_new)
    reasoning = reasoning_model.explain(X_new)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from importlib.metadata import version as _pkg_version

from outerproduct_http_types import ConnectorType

from outerproduct import agentic
from outerproduct.connector import (
    Connector,
    DatabricksConnector,
    FileUploadConnector,
    S3Connector,
    SnowflakeConnector,
)
from outerproduct.dataset import Column, Dataset
from outerproduct.job import Job, ReasoningJob, TrainerJob
from outerproduct.model import Model, ReasoningModel, predict
from outerproduct.reasoning import Reasoning, ReasoningTrace
from outerproduct.trainer import (
    Hardware,
    Metric,
    ModalHardware,
    Trainer,
)

try:
    __version__ = _pkg_version("outerproduct")
except Exception:
    __version__ = "unknown"


@dataclass
class _GlobalState:
    """Module-level state populated by :func:`~outerproduct.init`. Internal."""

    api_key: str | None = None
    base_url: str | None = None
    hardware: Hardware | None = None
    extra: dict[str, object] = field(default_factory=dict)


_state = _GlobalState()


def init(
    api_key: str | None = None,
    *,
    base_url: str | None = None,
    hardware: Hardware | None = None,
) -> None:
    """Configure the OuterProduct SDK for the current Python process.

    Call once near the top of your program. Subsequent operations
    (training, prediction, uploads) read credentials, the API base URL,
    and the default execution backend from the state recorded here.

    Examples
    --------
    .. code-block:: python

        import outerproduct as op
        op.init(api_key="op_live_...", hardware=op.ModalHardware())

    Parameters
    ----------
    api_key : str, optional
        Bearer token used to authenticate against the OuterProduct API.
        If omitted, the ``OUTERPRODUCT_API_KEY`` environment variable is
        consulted at use time.
    base_url : str, optional
        Override for the API base URL. If omitted, the SDK uses the
        production endpoint.
    hardware : Hardware, optional
        Default execution backend used by :class:`~outerproduct.trainer.Trainer`
        and :func:`~outerproduct.reasoning.fit`. If omitted, the API
        server falls back to a managed Modal worker.
    """
    _state.api_key = api_key
    _state.base_url = base_url
    _state.hardware = hardware


__all__ = [
    # Bootstrap
    "init",
    "__version__",
    # Dataset
    "Dataset",
    "Column",
    # Jobs
    "Job",
    "TrainerJob",
    "ReasoningJob",
    # Model
    "Model",
    "ReasoningModel",
    "predict",
    # Reasoning
    "Reasoning",
    "ReasoningTrace",
    # Trainer
    "Trainer",
    "Hardware",
    "ModalHardware",
    "Metric",
    # Connector
    "Connector",
    "ConnectorType",
    "FileUploadConnector",
    "S3Connector",
    "SnowflakeConnector",
    "DatabricksConnector",
    # Agentic feature sourcing (submodule, accessed as op.agentic.*)
    "agentic",
]
