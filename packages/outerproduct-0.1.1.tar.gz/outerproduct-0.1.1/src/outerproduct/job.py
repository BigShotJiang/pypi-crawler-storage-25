"""Non-blocking job handles for long-running OuterProduct operations.

Every async server operation (training, reasoning fit, segmentation)
can be started with ``non_blocking=True``. When it is, the
SDK returns a :class:`~outerproduct.job.Job` subclass immediately.
The handle exposes:

- :meth:`~outerproduct.job.Job.status` — check current progress without blocking.
- :meth:`~outerproduct.job.Job.wait` — block until the job completes and return the result.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from outerproduct.utils import _client

if TYPE_CHECKING:
    from outerproduct.model import Model
    from outerproduct.reasoning import ReasoningTrace


class Job:
    """Base class for non-blocking job handles.

    Not instantiated directly — use one of the subclasses returned by
    SDK methods when ``non_blocking=True``.
    """

    def __init__(self, model_id: str) -> None:
        self._model_id = model_id

    @property
    def model_id(self) -> str:
        """The server-side model / job identifier."""
        return self._model_id

    def status(self) -> str:
        """Check the current job status.

        Returns
        -------
        str
            One of ``"pending"``, ``"running"``, ``"completed"``,
            ``"failed"``.
        """
        with _client() as c:
            resp = c.status(self._model_id)
        return resp.status

    def wait(
        self,
        *,
        poll_interval: float = 2.0,
        poll_timeout: float = 3600.0,
    ) -> Any:
        """Block until the job completes and return the result.

        Subclasses override this to return the appropriate type
        (:class:`~outerproduct.model.Model` for training,
        :class:`~outerproduct.reasoning.ReasoningTrace` for segment).

        Parameters
        ----------
        poll_interval : float, default 2.0
            Seconds between status polls.
        poll_timeout : float, default 3600.0
            Maximum seconds to wait before raising a timeout error.
        """
        raise NotImplementedError

    def __repr__(self) -> str:
        return f"{type(self).__name__}(model_id={self._model_id!r})"


class TrainerJob(Job):
    """Handle for a non-blocking training or reasoning-fit operation.

    Returned by :meth:`~outerproduct.trainer.Trainer.run` and
    :func:`~outerproduct.reasoning.fit` when called with
    ``non_blocking=True``.
    """

    def __init__(
        self,
        model_id: str,
        *,
        feature_names: list[str] | None = None,
        model_cls: type[Model] | None = None,
    ) -> None:
        super().__init__(model_id)
        self._feature_names = feature_names
        self._model_cls = model_cls

    def wait(
        self,
        *,
        poll_interval: float = 2.0,
        poll_timeout: float = 3600.0,
    ) -> Model:
        """Block until training completes, then return the trained model.

        Parameters
        ----------
        poll_interval : float, default 2.0
            Seconds between status polls.
        poll_timeout : float, default 3600.0
            Maximum seconds to wait before raising a timeout error.

        Returns
        -------
        :class:`~outerproduct.model.Model` or :class:`~outerproduct.model.ReasoningModel`
            :class:`~outerproduct.model.Model` for trainer jobs,
            :class:`~outerproduct.model.ReasoningModel` for reasoning-fit jobs.
        """
        from outerproduct.model import Model

        cls = self._model_cls or Model
        with _client() as c:
            c.wait_for(
                self._model_id,
                poll_interval=poll_interval,
                poll_timeout=poll_timeout,
            )
        return cls(id=self._model_id, feature_names=self._feature_names)


class ReasoningJob(Job):
    """Handle for a non-blocking segment operation.

    Returned by :meth:`~outerproduct.model.ReasoningModel.segment` when called
    with ``non_blocking=True``.
    """

    def __init__(self, model_id: str, *, kind: str = "segment") -> None:
        super().__init__(model_id)
        self._kind = kind

    def wait(
        self,
        *,
        poll_interval: float = 2.0,
        poll_timeout: float = 3600.0,
    ) -> ReasoningTrace:
        """Block until the job completes, then return the result.

        Parameters
        ----------
        poll_interval : float, default 2.0
            Seconds between status polls.
        poll_timeout : float, default 3600.0
            Maximum seconds to wait before raising a timeout error.

        Returns
        -------
        :class:`~outerproduct.reasoning.ReasoningTrace`
            The completed segment trace.
        """
        from outerproduct.model import _segment_result_to_trace

        with _client() as c:
            c.wait_for(
                self._model_id,
                poll_interval=poll_interval,
                poll_timeout=poll_timeout,
            )
            result = c.segment_api.get_result(self._model_id)
            return _segment_result_to_trace(result)

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(model_id={self._model_id!r}, kind={self._kind!r})"
        )
