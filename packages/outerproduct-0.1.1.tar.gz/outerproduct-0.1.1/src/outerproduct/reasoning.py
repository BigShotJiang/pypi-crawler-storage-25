"""Reasoning — the SDK's interface to the OuterProduct explanation stack.

This module is the single entry point for producing a
:class:`~outerproduct.model.ReasoningModel`. Use :func:`~outerproduct.reasoning.fit`
to train one from a :class:`~outerproduct.dataset.Dataset`, optionally distilling
from a teacher :class:`~outerproduct.model.Model` or :class:`~outerproduct.model.Predictor`.

The module also defines the two result types returned by reasoning calls:

- :class:`~outerproduct.reasoning.Reasoning` — a *single* explanation for a row or a model-wide
  view (feature attributions, decision rules, provenance metadata).
- :class:`~outerproduct.reasoning.ReasoningTrace` — a *sequence* of explanations representing a
  multi-step process: counterfactual scenarios or segmentation summaries.

Examples
--------
.. code-block:: python

    import outerproduct as op

    connector = op.FileUploadConnector()
    dataset = connector.upload("data.csv", label_column="churn")
    rm = op.reasoning.fit(dataset)
    reasoning = rm.explain(X)
    reasoning.feature_names[:3]
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np

    from outerproduct.dataset import Dataset
    from outerproduct.job import TrainerJob
    from outerproduct.model import Model, Predictor, ReasoningModel
    from outerproduct.trainer import Metric


@dataclass
class Reasoning:
    """A single explanation: feature attributions plus optional rules.

    Returned by :meth:`~outerproduct.model.ReasoningModel.explain` and
    :meth:`~outerproduct.model.ReasoningModel.interpret`.

    Parameters
    ----------
    feature_names : list of str
        Names of the features being attributed, in the order they appear
        in ``attributions``.
    attributions : numpy.ndarray
        Per-feature contribution values. Shape ``(n_samples, n_features)``
        for local explanations, or ``(n_features,)`` for global / model-wide
        views.
    rules : list of str, optional
        Human-readable decision rules associated with the prediction
        (for example, ``"age > 50 AND tenure < 2"``).
    metadata : dict, optional
        Free-form provenance fields — engine name, version, timing, etc.
        Not part of the API contract.
    """

    feature_names: list[str]
    attributions: np.ndarray
    rules: list[str] | None = None
    metadata: dict[str, Any] | None = None


@dataclass
class ReasoningTrace:
    """A sequence of :class:`~outerproduct.reasoning.Reasoning` steps.

    Returned by :meth:`~outerproduct.model.ReasoningModel.scenario` and
    :meth:`~outerproduct.model.ReasoningModel.segment`. Each step captures one
    point along the trace — for a counterfactual search, the steps are
    successive candidate states; for segmentation, each step is a
    cluster summary.

    Parameters
    ----------
    steps : list of :class:`Reasoning`
        The ordered explanations that make up the trace.
    summary : str, optional
        A short, human-readable summary of the whole trace.
    metadata : dict, optional
        Free-form provenance fields.
    """

    steps: list[Reasoning] = field(default_factory=list)
    summary: str | None = None
    metadata: dict[str, Any] | None = None

    def __len__(self) -> int:
        return len(self.steps)

    def __getitem__(self, index: int) -> Reasoning:
        return self.steps[index]


def fit(
    dataset: Dataset,
    *,
    teacher: Model | Predictor | None = None,
    task_type: str | None = None,
    model_types: list[str] | None = None,
    metric: Metric | list[Metric] | None = None,
    non_blocking: bool = False,
    n_hyperopt_steps: int = 5,
    device: str | None = None,
    random_state: int = 42,
    poll_interval: float = 2.0,
    poll_timeout: float = 3600.0,
) -> ReasoningModel | TrainerJob:
    """Fit a :class:`~outerproduct.model.ReasoningModel` via the OuterProduct API.

    Two modes, selected by ``teacher``:

    - ``teacher=None`` — supervised training on ``dataset.label_column``.
      Routes to the fit endpoint.
    - ``teacher: Model | Predictor`` — *distillation*. The teacher is used
      to generate target predictions on ``dataset``'s features; the
      reasoning model learns to mimic the teacher *and* explain its
      behavior. Dataset labels are optional in this mode and used only
      for evaluation. Routes to the fit-distill endpoint.

    Trainer-style hyperparameters (``model_types``, ``metric``) are
    mirrored here so a reasoning fit is a single self-contained call —
    no need to construct a separate :class:`~outerproduct.trainer.Trainer`.
    The execution hardware is taken from :func:`~outerproduct.init`;
    there is no per-call override.

    Examples
    --------
    .. code-block:: python

        import outerproduct as op

        op.init(api_key="...")
        connector = op.FileUploadConnector()
        dataset = connector.upload("customers.csv", label_column="churn")

        # Supervised: train against labels.
        rm = op.reasoning.fit(dataset)

        # Distill an external prediction API.
        teacher = op.model.Predictor(
            "https://api.example.com/predict",
            headers={"Authorization": "Bearer ..."},
        )
        rm_distilled = op.reasoning.fit(dataset, teacher=teacher)

        # Distill an existing OuterProduct-trained model.
        trained = op.Trainer.configure(dataset).run()
        rm_wrapped = op.reasoning.fit(dataset, teacher=trained)

    Parameters
    ----------
    dataset : :class:`~outerproduct.dataset.Dataset`
        Training data.
    teacher : :class:`~outerproduct.model.Model` or :class:`~outerproduct.model.Predictor`, optional
        If provided, the resulting reasoning model distills this teacher
        on ``dataset``'s features. If ``None``, training is supervised on
        ``dataset.label_column``.
    model_types : list of str, optional
        Candidate model-family identifiers (e.g. ``["tabm", "xgboost"]``).
        Resolved server-side. Defaults to a curated set chosen from the
        dataset's size and schema.
    metric : :class:`~outerproduct.trainer.Metric` or list of :class:`~outerproduct.trainer.Metric`, optional
        One or more evaluation metrics. The first is the primary
        objective; additional metrics are reported alongside.
    non_blocking : bool, default False
        If ``True``, return a :class:`~outerproduct.job.TrainerJob`
        immediately. If ``False`` (default), block until training
        completes and return the trained reasoning model.
    n_hyperopt_steps : int, default 5
        Number of hyperparameter-optimisation trials to run.
    device : str, optional
        Device override (e.g. ``"cpu"``, ``"cuda:0"``).
    random_state : int, default 42
        Random seed for reproducibility.
    poll_interval : float, default 2.0
        Seconds between status polls while blocking.
    poll_timeout : float, default 3600.0
        Maximum seconds to wait before raising a timeout error.

    Returns
    -------
    :class:`~outerproduct.model.ReasoningModel` or :class:`~outerproduct.job.TrainerJob`
        A reasoning model when blocking (default). A
        :class:`~outerproduct.job.TrainerJob` when ``non_blocking=True``.
        The reasoning model supports
        :meth:`~outerproduct.model.ReasoningModel.explain`,
        :meth:`~outerproduct.model.ReasoningModel.interpret`,
        :meth:`~outerproduct.model.ReasoningModel.scenario`, and
        :meth:`~outerproduct.model.ReasoningModel.segment`.
    """
    from outerproduct_http_types import ReasoningFitRequest

    from outerproduct import _state
    from outerproduct.client import OuterProductClient
    from outerproduct.model import ReasoningModel
    from outerproduct.trainer import Metric as _Metric
    from outerproduct.trainer import _extract_teacher_request

    inline = dataset._to_inline_payload()
    feature_names = inline.get("feature_names")
    payload: dict[str, Any] = {
        "n_hyperopt_steps": n_hyperopt_steps,
        "random_state": random_state,
    }

    if inline.get("data_connector"):
        payload["data_connector"] = True
        payload["connector_id"] = inline["connector_id"]
        payload["table_name"] = inline["table_name"]
    elif inline.get("data_uploaded"):
        payload["data_uploaded"] = True
        payload["model_id"] = inline["model_id"]
        payload["feature_names"] = feature_names
    else:
        payload["data_uploaded"] = False
        payload["data"] = inline["data"]
        payload["feature_names"] = feature_names
        payload["labels"] = inline.get("labels")

    if inline.get("label_column") is not None:
        payload["label_column"] = inline["label_column"]
    if model_types is not None:
        payload["model_types"] = list(model_types)
    if device is not None:
        payload["device"] = device
    if teacher is not None:
        url, headers = _extract_teacher_request(teacher)
        payload["teacher_predict_url"] = url
        if headers:
            payload["teacher_predict_headers"] = headers
    if task_type is not None:
        payload["task_type"] = task_type
    # Forward hardware from op.init(...) when set; omit otherwise so the API
    # server picks its default (currently Modal).
    if _state.hardware is not None:
        payload["hardware"] = _state.hardware.to_http_hardware_spec()

    # Validate Metric.fn early; the wire schema has no `metrics` field for
    # reasoning.fit yet, so we discard the names but still surface the
    # callable-unsupported error.
    if metric is not None:
        for m in [metric] if isinstance(metric, _Metric) else list(metric):
            if m.fn is not None:
                raise NotImplementedError(
                    "Metric.fn (custom Python callable) is not supported in v1."
                )

    request = ReasoningFitRequest.model_validate(payload)

    # Connector-backed datasets don't have local feature names;
    # the backend discovers them from the remote source.
    ds_feature_names = None if dataset.is_connector_backed else dataset.feature_names

    with OuterProductClient.from_credentials(_state.base_url, _state.api_key) as client:
        resp = client.reasoning_api.fit(request)
        model_id = resp.model_id

        if non_blocking:
            from outerproduct.job import TrainerJob

            return TrainerJob(
                model_id,
                feature_names=ds_feature_names,
                model_cls=ReasoningModel,
            )

        client.wait_for(
            model_id,
            poll_interval=poll_interval,
            poll_timeout=poll_timeout,
        )

    return ReasoningModel(id=model_id, feature_names=ds_feature_names)
