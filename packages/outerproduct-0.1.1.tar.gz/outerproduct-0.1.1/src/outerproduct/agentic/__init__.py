"""Agent-driven feature sourcing.

Everything under :mod:`outerproduct.agentic` is part of an agent-driven flow
that turns unstructured or semi-structured sources into typed tabular
features. The boundary is the *flow*, not whether each individual function
makes an LLM call — deterministic helpers (PDF parsing, batching, schema
persistence) live here too because they support the same contract.

Submodules
----------
- :mod:`outerproduct.agentic.documents` — files (PDF, image, text).
"""

from outerproduct.agentic import documents

__all__ = ["documents"]
