"""Data connectors — produce :class:`~outerproduct.dataset.Dataset` handles.

A :class:`~outerproduct.connector.Connector` knows how to *register* a source of data with the
OuterProduct backend and return a :class:`~outerproduct.dataset.Dataset` ready to
hand to a :class:`~outerproduct.trainer.Trainer`.

:class:`~outerproduct.connector.FileUploadConnector` uploads local files via presigned URLs.
:class:`~outerproduct.connector.S3Connector`, :class:`~outerproduct.connector.SnowflakeConnector`,
and :class:`~outerproduct.connector.DatabricksConnector` register external data sources
with the API and support table discovery and validation.

Examples
--------
.. code-block:: python

    import outerproduct as op

    # File upload (local files):
    connector = op.FileUploadConnector()
    dataset = connector.upload("data.csv", label_column="churn")

    # S3 connector (registered with backend):
    s3 = op.S3Connector("my-s3", root_dir="s3://bucket/prefix")
    dataset = s3.table("customers.csv", label_column="churn")

    # Snowflake connector:
    sf = op.SnowflakeConnector(
        "my-snowflake",
        account="xy12345",
        warehouse="COMPUTE_WH",
        database="MYDB",
        schema_name="PUBLIC",
        credentials={"user": "admin", "password": "secret"},
    )
    dataset = sf.table("customers", label_column="churn")
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any

from outerproduct_http_types import ConnectorType

if TYPE_CHECKING:
    from outerproduct.dataset import Dataset


# ---------------------------------------------------------------------------
# Environment variable names for credential fallback
# ---------------------------------------------------------------------------

_ENV_SNOWFLAKE_USER = "SNOWFLAKE_USER"
_ENV_SNOWFLAKE_PASSWORD = "SNOWFLAKE_PASSWORD"
_ENV_SNOWFLAKE_ACCOUNT = "SNOWFLAKE_ACCOUNT"
_ENV_SNOWFLAKE_WAREHOUSE = "SNOWFLAKE_WAREHOUSE"
_ENV_SNOWFLAKE_DATABASE = "SNOWFLAKE_DATABASE"
_ENV_SNOWFLAKE_SCHEMA = "SNOWFLAKE_SCHEMA"

_ENV_DATABRICKS_TOKEN = "DATABRICKS_TOKEN"
_ENV_DATABRICKS_HOST = "DATABRICKS_HOST"
_ENV_DATABRICKS_HTTP_PATH = "DATABRICKS_HTTP_PATH"


# ---------------------------------------------------------------------------
# Connector ABC
# ---------------------------------------------------------------------------


class Connector(ABC):
    """Base class for OuterProduct data connectors.

    A connector represents a *registered* reference to an external data source
    (an S3 bucket, a Snowflake warehouse, etc.) persisted server-side. Its
    :meth:`table` method returns a :class:`~outerproduct.dataset.Dataset` handle
    that downstream training and inference operate on.

    Subclass this to add new sources. Most users instantiate one of the concrete
    subclasses (:class:`~outerproduct.connector.S3Connector`,
    :class:`~outerproduct.connector.SnowflakeConnector`, etc.).
    """

    _connector_id: str | None = None

    @property
    @abstractmethod
    def source_type(self) -> ConnectorType:
        """The type of external data source."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """User-facing name for this connector."""
        ...

    @property
    def connector_id(self) -> str | None:
        """Server-generated identifier, set after registration."""
        return self._connector_id

    # -- Table discovery & access -------------------------------------------

    def table_names(self) -> list[str]:
        """List available tables or paths in this connector.

        Returns
        -------
        list of str
            Table names (database connectors) or object paths (file connectors).
        """
        from outerproduct import _state
        from outerproduct.client import OuterProductClient

        if self._connector_id is None:
            raise RuntimeError("Connector is not registered with the API.")

        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            resp = client.connectors_api.list_tables(self._connector_id)
        return resp.tables

    def has_table(self, name: str) -> bool:
        """Return ``True`` if *name* exists in this connector.

        Parameters
        ----------
        name : str
            Table name or object path to check.
        """
        return name in self.table_names()

    def table(self, name: str, *, label_column: str | None = None) -> Dataset:
        """Return a :class:`~outerproduct.dataset.Dataset` referencing a table in this connector.

        The returned dataset is *lazy* — it holds a connector reference rather
        than local data. The backend reads the actual data at training time.

        Parameters
        ----------
        name : str
            Table name or object path within the connector.
        label_column : str, optional
            Name of the target column for supervised training.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A connector-backed dataset ready for :class:`~outerproduct.trainer.Trainer`
            or :func:`~outerproduct.reasoning.fit`.
        """
        from outerproduct.dataset import Dataset

        if self._connector_id is None:
            raise RuntimeError("Connector is not registered with the API.")

        return Dataset._from_connector_ref(
            connector_id=self._connector_id,
            table_name=name,
            label_column=label_column,
        )

    def validate(self) -> bool:
        """Test connectivity to the external data source.

        Returns
        -------
        bool
            ``True`` if the connection succeeded.

        Raises
        ------
        RuntimeError
            If validation fails, with the error message from the server.
        """
        from outerproduct import _state
        from outerproduct.client import OuterProductClient

        if self._connector_id is None:
            raise RuntimeError("Connector is not registered with the API.")

        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            resp = client.connectors_api.validate(self._connector_id)
        if not resp.valid:
            raise RuntimeError(
                f"Connector validation failed: {resp.error or 'unknown error'}"
            )
        return True

    def __getitem__(self, name: str) -> Dataset:
        return self.table(name)

    def __contains__(self, name: str) -> bool:
        return self.has_table(name)

    # -- Registration -------------------------------------------------------

    def _create_connector(
        self,
        connection_params: dict[str, Any],
        credentials: dict[str, str] | None = None,
    ) -> str:
        """Register this connector with the backend. Returns the connector_id."""
        from outerproduct_http_types import CreateConnectorRequest

        from outerproduct import _state
        from outerproduct.client import OuterProductClient

        request = CreateConnectorRequest(
            name=self.name,
            connector_type=self.source_type,
            connection_params=connection_params,
            credentials=credentials,
        )
        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            resp = client.connectors_api.create(request)
        self._connector_id = resp.connector_id
        return resp.connector_id

    @classmethod
    def _get_by_name_impl(cls, name: str) -> dict[str, Any]:
        """Retrieve connector metadata from the API by name."""
        from outerproduct import _state
        from outerproduct.client import OuterProductClient

        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            resp = client.connectors_api.get_by_name(name)
        return {
            "connector_id": resp.connector_id,
            "name": resp.name,
            "connector_type": resp.connector_type,
            "connection_params": resp.connection_params,
        }

    def _delete_connector(self) -> None:
        """Remove this connector from the backend."""
        from outerproduct import _state
        from outerproduct.client import OuterProductClient

        if self._connector_id is None:
            raise RuntimeError("Connector is not registered with the API.")

        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            client.connectors_api.delete(self._connector_id)

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r})"


# ---------------------------------------------------------------------------
# File upload connector (stateless, unchanged)
# ---------------------------------------------------------------------------


class FileUploadConnector:
    """Upload local CSV / Parquet / pickle files to OuterProduct.

    Wraps the presigned-URL upload flow:

    1. Request a presigned upload URL from the server.
    2. ``PUT`` the raw file bytes to that URL.
    3. Return a :class:`~outerproduct.dataset.Dataset` referring to the uploaded data.

    This connector does *not* register with the backend — it is a stateless
    upload helper. Use the other connectors for registered external data sources.

    Examples
    --------
    .. code-block:: python

        import outerproduct as op
        connector = op.FileUploadConnector()
        dataset = connector.upload("data.csv", label_column="churn")
    """

    _FORMAT_MAP: dict[str, str] = {
        ".csv": "csv",
        ".parquet": "parquet",
        ".pq": "parquet",
        ".pkl": "pkl",
        ".pickle": "pkl",
    }

    def upload(
        self,
        path: str | Path,
        *,
        label_column: str | None = None,
        name: str | None = None,
    ) -> Dataset:
        """Upload a local data file and return a :class:`~outerproduct.dataset.Dataset`.

        Parameters
        ----------
        path : str or pathlib.Path
            Path to a local file. Supported formats: ``.csv``,
            ``.parquet``, ``.pkl``.
        label_column : str, optional
            Name of the target column, if any.
        name : str, optional
            Caller-supplied label, retained for display.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A dataset handle referring to the uploaded data.
        """
        import io
        from typing import Literal, cast

        import httpx
        import pandas as pd

        from outerproduct_http_types import CreateUploadRequest

        from outerproduct import _state
        from outerproduct.client import OuterProductClient
        from outerproduct.dataset import Dataset

        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Data file not found: {file_path}")

        suffix = file_path.suffix.lower()
        fmt = self._FORMAT_MAP.get(suffix)
        if fmt is None:
            raise ValueError(
                f"Unsupported file extension {suffix!r}; "
                f"expected one of {sorted(self._FORMAT_MAP.keys())}"
            )
        file_format = cast(Literal["pkl", "csv", "parquet"], fmt)

        # 1. Read the file once — used for both the upload and the local Dataset.
        file_bytes = file_path.read_bytes()

        # 2. Request a presigned upload URL.
        create_req = CreateUploadRequest(file_format=file_format)
        with OuterProductClient.from_credentials(
            _state.base_url, _state.api_key
        ) as client:
            upload_resp = client.uploads_api.create(create_req)

        # 3. PUT the raw bytes to the presigned URL.
        with httpx.Client() as http:
            put_resp = http.put(
                upload_resp.upload_url,
                content=file_bytes,
                headers={"Content-Type": upload_resp.content_type},
            )
            put_resp.raise_for_status()

        # 4. Parse the same bytes into a DataFrame for the local Dataset.
        if file_format == "csv":
            df = pd.read_csv(io.BytesIO(file_bytes))
        elif file_format == "parquet":
            df = pd.read_parquet(io.BytesIO(file_bytes))
        else:
            raw = pd.read_pickle(io.BytesIO(file_bytes))
            df = pd.DataFrame(raw) if not isinstance(raw, pd.DataFrame) else raw

        dataset = Dataset(df, label_column=label_column)
        dataset._upload_id = upload_resp.model_id
        return dataset


# ---------------------------------------------------------------------------
# URI helpers
# ---------------------------------------------------------------------------


def _validate_s3_uri(uri: str) -> str:
    """Validate and normalise an S3 URI."""
    if not uri.startswith("s3://"):
        raise ValueError(f"Invalid S3 URI: {uri!r}. Must start with 's3://'.")
    return uri.rstrip("/")


# ---------------------------------------------------------------------------
# File connectors (S3, GCS)
# ---------------------------------------------------------------------------


class S3Connector(Connector):
    """Reference data stored in Amazon S3.

    Registers the S3 location with the OuterProduct backend on creation.
    No credentials are required — the backend uses its own IAM role to
    access the bucket.

    .. code-block:: python

        import outerproduct as op
        connector = op.S3Connector("my-s3", root_dir="s3://bucket/prefix")
        print(connector.table_names())
        dataset = connector.table("customers.csv", label_column="churn")

    Parameters
    ----------
    name : str
        User-facing name for this connector.
    root_dir : str
        ``s3://bucket/prefix/`` URI under which datasets live.
    _bypass_creation : bool
        Internal. If ``True``, skip API registration (used by :meth:`get_by_name`).
    """

    def __init__(
        self,
        name: str,
        *,
        root_dir: str,
        _bypass_creation: bool = False,
        _connector_id: str | None = None,
    ) -> None:
        self._name = name
        self._root_dir = _validate_s3_uri(root_dir)
        self._connector_id = _connector_id

        if not _bypass_creation:
            self._create_connector(
                connection_params={"root_dir": self._root_dir},
            )

    @property
    def source_type(self) -> ConnectorType:
        return ConnectorType.S3

    @property
    def name(self) -> str:
        return self._name

    @property
    def root_dir(self) -> str:
        """The S3 URI prefix for this connector."""
        return self._root_dir

    @classmethod
    def get_by_name(cls, name: str) -> S3Connector:
        """Retrieve an existing S3 connector by name.

        Parameters
        ----------
        name : str
            The name used when the connector was created.

        Returns
        -------
        :class:`~outerproduct.connector.S3Connector`
            A connector instance bound to the existing registration.
        """
        data = cls._get_by_name_impl(name)
        return cls(
            name=data["name"],
            root_dir=data["connection_params"]["root_dir"],
            _bypass_creation=True,
            _connector_id=data["connector_id"],
        )

    def __repr__(self) -> str:
        return f"S3Connector(name={self._name!r}, root_dir={self._root_dir!r})"


# ---------------------------------------------------------------------------
# Database connectors (Snowflake, Databricks)
# ---------------------------------------------------------------------------


class SnowflakeConnector(Connector):
    """Reference data stored in Snowflake.

    Credentials are resolved from the ``credentials`` dict, then from
    environment variables (``SNOWFLAKE_USER``, ``SNOWFLAKE_PASSWORD``).

    .. code-block:: python

        import outerproduct as op
        connector = op.SnowflakeConnector(
            "my-snowflake",
            account="xy12345",
            warehouse="COMPUTE_WH",
            database="MYDB",
            schema_name="PUBLIC",
            credentials={"user": "admin", "password": "secret"},
        )
        print(connector.table_names())
        dataset = connector.table("customers", label_column="churn")

    Parameters
    ----------
    name : str
        User-facing name for this connector.
    account : str
        Snowflake account identifier.
    warehouse : str
        Warehouse name.
    database : str
        Database name.
    schema_name : str
        Schema name.
    credentials : dict, optional
        Keys ``user`` and ``password``. Falls back to ``SNOWFLAKE_USER``
        and ``SNOWFLAKE_PASSWORD`` environment variables.
    _bypass_creation : bool
        Internal. If ``True``, skip API registration.
    """

    def __init__(
        self,
        name: str,
        *,
        account: str | None = None,
        warehouse: str | None = None,
        database: str | None = None,
        schema_name: str | None = None,
        credentials: dict[str, str] | None = None,
        _bypass_creation: bool = False,
        _connector_id: str | None = None,
    ) -> None:
        self._name = name
        self._account = account or os.environ.get(_ENV_SNOWFLAKE_ACCOUNT, "")
        self._warehouse = warehouse or os.environ.get(_ENV_SNOWFLAKE_WAREHOUSE, "")
        self._database = (
            database or os.environ.get(_ENV_SNOWFLAKE_DATABASE, "")
        ).upper()
        self._schema_name = (
            schema_name or os.environ.get(_ENV_SNOWFLAKE_SCHEMA, "")
        ).upper()
        self._connector_id = _connector_id

        if _bypass_creation:
            return

        # Resolve credentials from args → env vars.
        creds = credentials or {}
        resolved_creds: dict[str, str] = {}
        user = creds.get("user") or os.environ.get(_ENV_SNOWFLAKE_USER)
        password = creds.get("password") or os.environ.get(_ENV_SNOWFLAKE_PASSWORD)
        if user:
            resolved_creds["user"] = user
        if password:
            resolved_creds["password"] = password

        self._create_connector(
            connection_params={
                "account": self._account,
                "warehouse": self._warehouse,
                "database": self._database,
                "schema_name": self._schema_name,
            },
            credentials=resolved_creds or None,
        )

    @property
    def source_type(self) -> ConnectorType:
        return ConnectorType.SNOWFLAKE

    @property
    def name(self) -> str:
        return self._name

    @classmethod
    def get_by_name(cls, name: str) -> SnowflakeConnector:
        """Retrieve an existing Snowflake connector by name.

        Parameters
        ----------
        name : str
            The name used when the connector was created.

        Returns
        -------
        :class:`~outerproduct.connector.SnowflakeConnector`
            A connector instance bound to the existing registration.
        """
        data = cls._get_by_name_impl(name)
        params = data["connection_params"]
        return cls(
            name=data["name"],
            account=params.get("account"),
            warehouse=params.get("warehouse"),
            database=params.get("database"),
            schema_name=params.get("schema_name"),
            _bypass_creation=True,
            _connector_id=data["connector_id"],
        )

    def __repr__(self) -> str:
        return (
            f"SnowflakeConnector(name={self._name!r}, "
            f'account="{self._account}", database="{self._database}", '
            f'schema="{self._schema_name}")'
        )


class DatabricksConnector(Connector):
    """Reference data stored in Databricks.

    Credentials are resolved from the ``credentials`` dict, then from
    the ``DATABRICKS_TOKEN`` environment variable.

    .. code-block:: python

        import outerproduct as op
        connector = op.DatabricksConnector(
            "my-databricks",
            server_hostname="adb-123.azuredatabricks.net",
            http_path="/sql/1.0/warehouses/abc",
            credentials={"access_token": "dapi..."},
        )
        dataset = connector.table("customers", label_column="churn")

    Parameters
    ----------
    name : str
        User-facing name for this connector.
    server_hostname : str
        Databricks workspace hostname.
    http_path : str
        SQL warehouse or cluster HTTP path.
    catalog : str, optional
        Unity Catalog name.
    schema : str, optional
        Schema name within the catalog.
    credentials : dict, optional
        Key ``access_token``. Falls back to ``DATABRICKS_TOKEN``.
    _bypass_creation : bool
        Internal. If ``True``, skip API registration.
    """

    def __init__(
        self,
        name: str,
        *,
        server_hostname: str | None = None,
        http_path: str | None = None,
        catalog: str | None = None,
        schema: str | None = None,
        credentials: dict[str, str] | None = None,
        _bypass_creation: bool = False,
        _connector_id: str | None = None,
    ) -> None:
        self._name = name
        self._server_hostname = server_hostname or os.environ.get(
            _ENV_DATABRICKS_HOST, ""
        )
        self._http_path = http_path or os.environ.get(_ENV_DATABRICKS_HTTP_PATH, "")
        self._catalog = catalog
        self._schema = schema
        self._connector_id = _connector_id

        if _bypass_creation:
            return

        creds = credentials or {}
        resolved_creds: dict[str, str] = {}
        token = creds.get("access_token") or os.environ.get(_ENV_DATABRICKS_TOKEN)
        if token:
            resolved_creds["access_token"] = token

        self._create_connector(
            connection_params={
                "server_hostname": self._server_hostname,
                "http_path": self._http_path,
                "catalog": self._catalog,
                "schema": self._schema,
            },
            credentials=resolved_creds or None,
        )

    @property
    def source_type(self) -> ConnectorType:
        return ConnectorType.DATABRICKS

    @property
    def name(self) -> str:
        return self._name

    @classmethod
    def get_by_name(cls, name: str) -> DatabricksConnector:
        """Retrieve an existing Databricks connector by name.

        Parameters
        ----------
        name : str
            The name used when the connector was created.

        Returns
        -------
        :class:`~outerproduct.connector.DatabricksConnector`
            A connector instance bound to the existing registration.
        """
        data = cls._get_by_name_impl(name)
        params = data["connection_params"]
        return cls(
            name=data["name"],
            server_hostname=params.get("server_hostname"),
            http_path=params.get("http_path"),
            catalog=params.get("catalog"),
            schema=params.get("schema"),
            _bypass_creation=True,
            _connector_id=data["connector_id"],
        )

    def __repr__(self) -> str:
        return (
            f'DatabricksConnector(name={self._name!r}, host="{self._server_hostname}")'
        )
