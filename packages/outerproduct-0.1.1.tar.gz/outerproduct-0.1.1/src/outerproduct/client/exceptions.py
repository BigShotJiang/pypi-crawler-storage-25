"""Exceptions raised by :class:`outerproduct.client.OuterProductClient`."""

from __future__ import annotations

import httpx


class APIError(RuntimeError):
    """Raised when the OuterProduct API returns a non-2xx response.

    Pulls the most informative error string out of the response body
    (JSON ``detail`` / ``error`` field, falling back to ``.text``) so
    callers see structured server errors verbatim.
    """

    def __init__(self, response: httpx.Response) -> None:
        self.status_code = response.status_code
        self.detail = self._best_detail(response)
        super().__init__(f"OuterProduct API error {self.status_code}: {self.detail}")

    @staticmethod
    def _best_detail(response: httpx.Response) -> str:
        try:
            body = response.json()
            if isinstance(body, dict):
                return str(body.get("detail") or body.get("error") or response.text)
        except Exception:
            pass
        return response.text


class JobFailedError(RuntimeError):
    """Raised by :meth:`OuterProductClient.wait_for` when a polled job fails."""

    def __init__(self, model_id: str, error_message: str | None) -> None:
        super().__init__(
            f"Job for model_id={model_id!r} failed: "
            f"{error_message or '<no error message>'}"
        )
        self.model_id = model_id
        self.error_message = error_message


class PollTimeoutError(RuntimeError):
    """Raised when a job has not finished by the time ``poll_timeout`` elapses."""


__all__ = ["APIError", "JobFailedError", "PollTimeoutError"]
