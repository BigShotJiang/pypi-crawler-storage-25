"""The OuterProduct service object — typed HTTP wrapper around the API."""

from __future__ import annotations

import os
import time
from types import TracebackType
from typing import TYPE_CHECKING

import httpx
from outerproduct_http_types import JobStatus, StatusResponse

from outerproduct.client._http import HttpClient
from outerproduct.client.endpoints import (
    STATUS,
    DeleteEndpoint,
    GetEndpoint,
    PostEndpoint,
    ReqT,
    RespT,
)
from outerproduct.client.exceptions import (
    APIError,
    JobFailedError,
    PollTimeoutError,
)

if TYPE_CHECKING:
    from outerproduct.client.apis import (
        AgenticDocumentsAPI,
        ConnectorsAPI,
        InferenceAPI,
        ReasoningAPI,
        SegmentAPI,
        TrainerAPI,
        UploadsAPI,
    )

API_VERSION = "v1"
DEFAULT_BASE_URL = "https://api.outerproduct.com"
DEFAULT_TIMEOUT_SECONDS = 60.0
DEFAULT_POLL_INTERVAL = 2.0
DEFAULT_POLL_TIMEOUT = 3600.0


def resolve_base_url(base_url: str | None = None) -> str:
    """Resolve the API base URL: argument → ``$OUTERPRODUCT_BASE_URL`` → default."""
    return (
        base_url or os.environ.get("OUTERPRODUCT_BASE_URL") or DEFAULT_BASE_URL
    ).rstrip("/")


def resolve_api_key(api_key: str | None = None) -> str:
    """Resolve the API key: argument → ``$OUTERPRODUCT_API_KEY`` → raise."""
    key = api_key or os.environ.get("OUTERPRODUCT_API_KEY")
    if not key:
        raise RuntimeError(
            "No API key configured. Pass api_key=... or set OUTERPRODUCT_API_KEY."
        )
    return key


class OuterProductClient:
    """Typed wrapper around the OuterProduct HTTP API.

    Construct with :meth:`from_credentials` for the standard wiring
    (``/v1`` base URL, Bearer auth, env-var fallbacks). Pass any
    :class:`HttpClient`-conforming transport to ``__init__`` directly
    when you need a custom configuration — e.g. retries, alternate
    auth, in-process fakes, or test stubs.
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    @classmethod
    def from_credentials(
        cls,
        base_url: str | None = None,
        api_key: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> OuterProductClient:
        """Build a client backed by an :class:`httpx.Client`.

        Resolution order:

        - ``base_url``: argument → ``$OUTERPRODUCT_BASE_URL`` →
          ``"https://api.outerproduct.com"``
        - ``api_key``: argument → ``$OUTERPRODUCT_API_KEY`` → raises
          :class:`RuntimeError` if neither is set.
        """
        base = resolve_base_url(base_url)
        key = resolve_api_key(api_key)
        http = httpx.Client(
            base_url=f"{base}/{API_VERSION}",
            headers={"Authorization": f"Bearer {key}"},
            timeout=timeout,
        )
        return cls(http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> OuterProductClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def status(self, model_id: str) -> StatusResponse:
        """``GET /v1/models/{model_id}/status`` — universal job status."""
        return self._get(STATUS, model_id=model_id)

    def wait_for(
        self,
        model_id: str,
        *,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
    ) -> StatusResponse:
        """Poll :meth:`status` until the job reaches a terminal state.

        Raises :class:`JobFailedError` on ``status="failed"`` and
        :class:`PollTimeoutError` if the deadline elapses first.
        """
        deadline = time.monotonic() + poll_timeout
        while True:
            result = self.status(model_id)
            if result.status == JobStatus.COMPLETED:
                return result
            if result.status == JobStatus.FAILED:
                raise JobFailedError(model_id, result.error_message)
            if time.monotonic() > deadline:
                raise PollTimeoutError(
                    f"Job for model_id={model_id!r} did not complete "
                    f"within {poll_timeout}s (last status: {result.status!r})"
                )
            time.sleep(poll_interval)

    @property
    def uploads_api(self) -> UploadsAPI:
        from outerproduct.client.apis import UploadsAPI

        return UploadsAPI(self)

    @property
    def trainer_api(self) -> TrainerAPI:
        from outerproduct.client.apis import TrainerAPI

        return TrainerAPI(self)

    @property
    def reasoning_api(self) -> ReasoningAPI:
        from outerproduct.client.apis import ReasoningAPI

        return ReasoningAPI(self)

    @property
    def inference_api(self) -> InferenceAPI:
        from outerproduct.client.apis import InferenceAPI

        return InferenceAPI(self)

    @property
    def segment_api(self) -> SegmentAPI:
        from outerproduct.client.apis import SegmentAPI

        return SegmentAPI(self)

    @property
    def connectors_api(self) -> ConnectorsAPI:
        from outerproduct.client.apis import ConnectorsAPI

        return ConnectorsAPI(self)

    @property
    def agentic_documents_api(self) -> AgenticDocumentsAPI:
        from outerproduct.client.apis import AgenticDocumentsAPI

        return AgenticDocumentsAPI(self)

    def _get(self, endpoint: GetEndpoint[RespT], **path_params: str) -> RespT:
        """Dispatch a typed ``GET`` and parse the response."""
        response = self._http.get(endpoint.path.format(**path_params))
        if not response.is_success:
            raise APIError(response)
        return endpoint.response_type.model_validate_json(response.content)

    def _post(
        self,
        endpoint: PostEndpoint[ReqT, RespT],
        request: ReqT,
        **path_params: str,
    ) -> RespT:
        """Dispatch a typed ``POST`` and parse the response."""
        response = self._http.post(
            endpoint.path.format(**path_params),
            content=request.model_dump_json(),
            headers={"Content-Type": "application/json"},
        )
        if not response.is_success:
            raise APIError(response)
        return endpoint.response_type.model_validate_json(response.content)

    def _delete(
        self,
        endpoint: DeleteEndpoint[RespT],
        **path_params: str,
    ) -> RespT:
        """Dispatch a typed ``DELETE`` and parse the response."""
        response = self._http.delete(endpoint.path.format(**path_params))
        if not response.is_success:
            raise APIError(response)
        return endpoint.response_type.model_validate_json(response.content)


__all__ = [
    "API_VERSION",
    "DEFAULT_BASE_URL",
    "DEFAULT_POLL_INTERVAL",
    "DEFAULT_POLL_TIMEOUT",
    "DEFAULT_TIMEOUT_SECONDS",
    "OuterProductClient",
    "resolve_api_key",
    "resolve_base_url",
]
