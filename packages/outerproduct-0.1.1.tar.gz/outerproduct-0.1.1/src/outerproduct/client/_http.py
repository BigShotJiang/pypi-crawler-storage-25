"""Minimal HTTP-client protocol used by :class:`OuterProductClient`.

The Protocol decouples the service object from any specific HTTP
library: anything exposing ``get``, ``post``, and ``close`` with the
shapes below is a valid backend. :class:`httpx.Client` satisfies it
natively; tests can pass a hand-rolled stub.

Example
-------

A minimal in-memory stub usable as ``OuterProductClient(stub)``::

    class StubHttp:
        def __init__(self, get_response, post_response):
            self._get = get_response
            self._post = post_response

        def get(self, url):
            return self._get

        def post(self, url, *, content=None, json=None, headers=None):
            return self._post

        def close(self):
            pass

The stub still produces :class:`httpx.Response` instances because the
parsers downstream call ``.is_success``, ``.content``, ``.json()`` and
``.status_code`` on them — for in-process tests, ``respx`` (which
patches httpx at the transport layer) is usually a better fit than a
hand-rolled stub.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol

import httpx


class HttpClient(Protocol):
    """The subset of :class:`httpx.Client` consumed by this package."""

    def get(self, url: str) -> httpx.Response: ...

    def post(
        self,
        url: str,
        *,
        content: bytes | str | None = ...,
        json: Any | None = ...,
        headers: Mapping[str, str] | None = ...,
    ) -> httpx.Response: ...

    def delete(self, url: str) -> httpx.Response: ...

    def close(self) -> None: ...


__all__ = ["HttpClient"]
