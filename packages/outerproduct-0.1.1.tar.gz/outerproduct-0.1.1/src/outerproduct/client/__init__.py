"""HTTP service-object module for the OuterProduct API.

This subpackage owns *all* network I/O between the SDK and the
OuterProduct backend. Layering:

- :class:`OuterProductClient` — wraps an :class:`HttpClient`
  (typically :class:`httpx.Client`); exposes the cross-cutting
  ``status`` route directly and namespaces the rest under typed
  sub-APIs.
- :mod:`endpoints` — every route declared as a typed
  :class:`GetEndpoint` / :class:`PostEndpoint` constant, carrying its
  request and response models. The single source of truth for the
  wire contract.
- :mod:`apis` — ergonomic sub-API namespaces (``uploads_api``,
  ``fit_api``, ``inference_api``, ``segment_api``).
- :mod:`_http` — :class:`HttpClient` :class:`typing.Protocol` defining
  what the client requires of its transport.

Examples
--------
.. code-block:: python

    from outerproduct.client import OuterProductClient
    from outerproduct_http_types import CreateUploadRequest

    with OuterProductClient.from_credentials(
        "https://api.outerproduct.com", api_key="op_live_..."
    ) as client:
        resp = client.uploads_api.create(CreateUploadRequest(file_format="csv"))
        job_status = client.status(resp.model_id)
"""

from outerproduct.client._http import HttpClient
from outerproduct.client.apis import (
    AgenticDocumentsAPI,
    InferenceAPI,
    ReasoningAPI,
    SegmentAPI,
    TrainerAPI,
    UploadsAPI,
)
from outerproduct.client.client import (
    API_VERSION,
    OuterProductClient,
    resolve_api_key,
    resolve_base_url,
)
from outerproduct.client.endpoints import GetEndpoint, PostEndpoint
from outerproduct.client.exceptions import (
    APIError,
    JobFailedError,
    PollTimeoutError,
)

__all__ = [
    "API_VERSION",
    "APIError",
    "AgenticDocumentsAPI",
    "GetEndpoint",
    "HttpClient",
    "InferenceAPI",
    "JobFailedError",
    "OuterProductClient",
    "PollTimeoutError",
    "PostEndpoint",
    "ReasoningAPI",
    "SegmentAPI",
    "TrainerAPI",
    "UploadsAPI",
    "resolve_api_key",
    "resolve_base_url",
]
