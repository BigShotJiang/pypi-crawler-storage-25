"""Shared utilities for the OuterProduct SDK."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd

    from outerproduct.client import OuterProductClient


@contextmanager
def _client() -> Generator[OuterProductClient, None, None]:
    """Open a short-lived :class:`OuterProductClient` from global state."""
    from outerproduct import _state
    from outerproduct.client import OuterProductClient

    with OuterProductClient.from_credentials(_state.base_url, _state.api_key) as c:
        yield c


def _prepare_samples(
    X: pd.DataFrame | np.ndarray | list[list[Any]],
    feature_names: list[str] | None = None,
) -> tuple[list[list[Any]], list[str]]:
    """Normalise user input into ``(samples, feature_names)`` for wire requests.

    Parameters
    ----------
    X : pandas.DataFrame, numpy.ndarray, or list of lists
        Input features in any of the SDK's accepted formats.
    feature_names : list of str, optional
        Explicit feature names. When *X* is a DataFrame the column names
        are used instead, and this argument is ignored.

    Returns
    -------
    samples : list of lists
        Row-major nested list suitable for the JSON wire format.
    feature_names : list of str
        Column names matching *samples*.
    """
    import numpy as np
    import pandas as pd

    if isinstance(X, pd.DataFrame):
        return X.values.tolist(), list(X.columns)

    if isinstance(X, np.ndarray):
        arr = np.atleast_2d(X)
        names = feature_names or [f"x{i}" for i in range(arr.shape[1])]
        return arr.tolist(), names

    if isinstance(X, list):
        n_cols = len(X[0]) if X else 0
        names = feature_names or [f"x{i}" for i in range(n_cols)]
        return X, names

    raise TypeError(
        f"Unsupported input type {type(X).__name__}; "
        "expected pandas.DataFrame, numpy.ndarray, or list of lists"
    )
