"""Transaction context managers for sync and async clients."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .sync_db import Database
    from .async_db import AsyncDatabase


@dataclass(slots=True)
class Transaction:
    """Synchronous transaction context manager with savepoint nesting support."""

    database: "Database"

    def __enter__(self) -> "Database":
        self.database._enter_transaction()
        return self.database

    def __exit__(self, exc_type, exc, tb) -> None:
        self.database._exit_transaction(exc is None)


@dataclass(slots=True)
class AsyncTransaction:
    """Asynchronous transaction context manager with savepoint nesting support."""

    database: "AsyncDatabase"

    async def __aenter__(self) -> "AsyncDatabase":
        await self.database._enter_transaction()
        return self.database

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.database._exit_transaction(exc is None)
