"""Result primitives for pydbo."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True, frozen=True)
class StatementResult:
    """Structured metadata about a write statement.

    Attributes:
        rowcount: Number of affected rows reported by sqlite3.
        lastrowid: Last inserted row id, when available.
    """

    rowcount: int
    lastrowid: int | None = None


RowDict = dict[str, Any]
