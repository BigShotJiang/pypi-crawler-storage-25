"""pydbo: A lightweight SQLite-first database toolkit for Python.

The package provides a synchronous and asynchronous API built entirely on top of
Python's built-in ``sqlite3`` module.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from .async_db import AsyncDatabase, AsyncTable
from .exc import (
    ConfigurationError,
    ConnectionClosedError,
    DataError,
    DatabaseError,
    Error,
    IntegrityError,
    InterfaceError,
    InternalError,
    InvalidIdentifierError,
    NotSupportedError,
    OperationalError,
    ProgrammingError,
    PyDBOError,
    ValidationError,
    Warning,
)
from .result import RowDict, StatementResult
from .sync_db import Database, Table

__all__ = [
    "AsyncDatabase",
    "AsyncTable",
    "ConfigurationError",
    "ConnectionClosedError",
    "DataError",
    "Database",
    "DatabaseError",
    "Error",
    "IntegrityError",
    "InterfaceError",
    "InternalError",
    "InvalidIdentifierError",
    "NotSupportedError",
    "OperationalError",
    "ProgrammingError",
    "RowDict",
    "PyDBOError",
    "StatementResult",
    "Table",
    "ValidationError",
    "Warning",
    "open_async",
    "open_db",
    "connect",
    "connect_async",
    "Binary",
    "Row",
    "PARSE_COLNAMES",
    "PARSE_DECLTYPES",
    "register_adapter",
    "register_converter",
    "complete_statement",
]

Binary = sqlite3.Binary
Row = sqlite3.Row
PARSE_DECLTYPES = sqlite3.PARSE_DECLTYPES
PARSE_COLNAMES = sqlite3.PARSE_COLNAMES
register_adapter = sqlite3.register_adapter
register_converter = sqlite3.register_converter
complete_statement = sqlite3.complete_statement


def open_db(path: str | Path, **kwargs: Any) -> Database:
    """Open a synchronous SQLite client.

    Args:
        path: Database path or ``":memory:"``.
        **kwargs: Extra :class:`pydbo.sync_db.Database` options.

    Returns:
        A ready-to-use synchronous client.
    """

    return Database(path, **kwargs)


connect = open_db


async def open_async(path: str | Path, **kwargs: Any) -> AsyncDatabase:
    """Open an asynchronous SQLite client.

    This function is asynchronous for ergonomic symmetry with regular async
    factories, even though connection setup itself happens immediately.
    """

    return AsyncDatabase(path, **kwargs)


connect_async = open_async
