"""Internal helper functions used across pydbo."""

from __future__ import annotations

import re
import sqlite3
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from . import exc

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def validate_identifier(identifier: str, *, kind: str = "identifier") -> str:
    """Validate that a SQL identifier is safe to interpolate.

    Args:
        identifier: Raw identifier name.
        kind: Human-readable identifier type for error messages.

    Returns:
        The original identifier when valid.

    Raises:
        InvalidIdentifierError: If the identifier is empty or unsafe.
    """

    if not isinstance(identifier, str) or not identifier:
        raise exc.InvalidIdentifierError(f"{kind} must be a non-empty string")
    if not _IDENTIFIER_RE.fullmatch(identifier):
        raise exc.InvalidIdentifierError(
            f"Unsafe {kind}: {identifier!r}. Only letters, digits, and underscores are allowed, "
            "and the first character must not be a digit."
        )
    return identifier


def quote_identifier(identifier: str) -> str:
    """Return a safely quoted SQLite identifier.

    Args:
        identifier: Untrusted identifier.

    Returns:
        Identifier wrapped in double quotes.
    """

    validate_identifier(identifier)
    return f'"{identifier}"'


def normalize_params(params: Sequence[Any] | None) -> Sequence[Any]:
    """Normalize SQL parameters.

    Args:
        params: Positional SQL parameters for ``?`` placeholders.

    Returns:
        A value suitable for sqlite3 execution methods.

    Raises:
        ValidationError: If named parameters are provided.
    """

    if params is None:
        return ()
    if isinstance(params, Mapping):
        raise exc.ValidationError(
            "Named SQL parameters are no longer supported. Use '?' placeholders with a positional sequence instead."
        )
    return params


def ensure_mapping_row(row: Any, *, index: int) -> Mapping[str, Any]:
    """Validate a helper row payload.

    Args:
        row: Candidate row value.
        index: Zero-based row position for clearer errors.

    Returns:
        Mapping row.

    Raises:
        ValidationError: If the row is not a mapping or is empty.
    """

    if not isinstance(row, Mapping):
        raise exc.ValidationError(
            f"rows[{index}] must be a mapping of column names to values; got {type(row).__name__}"
        )
    if not row:
        raise exc.ValidationError(f"rows[{index}] must not be empty")
    for key in row.keys():
        validate_identifier(str(key), kind="column name")
    return row


def ensure_consistent_rows(rows: Iterable[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    """Validate that all rows share the same ordered keys.

    Args:
        rows: Iterable of row mappings.

    Returns:
        Materialized row list.

    Raises:
        ValidationError: If rows are empty or keys differ.
    """

    materialized = [ensure_mapping_row(row, index=index) for index, row in enumerate(rows)]
    if not materialized:
        raise exc.ValidationError("rows must contain at least one item")
    first_keys = list(materialized[0].keys())
    for index, row in enumerate(materialized[1:], start=1):
        row_keys = list(row.keys())
        if row_keys != first_keys:
            raise exc.ValidationError(
                f"rows[{index}] has different keys. Expected {first_keys!r}, got {row_keys!r}"
            )
    return materialized


def build_assignment_list(columns: Sequence[str]) -> str:
    """Build a SQL SET clause assignment list.

    Args:
        columns: Column names.

    Returns:
        SQL fragment such as '"name" = ?, "age" = ?'.
    """

    return ", ".join(f"{quote_identifier(column)} = ?" for column in columns)


def build_placeholders(count: int) -> str:
    """Build a comma-separated placeholder list."""

    return ", ".join("?" for _ in range(count))


def map_sqlite_exception(error: sqlite3.Error) -> exc.Error:
    """Translate a sqlite3 exception into a package-defined exception.

    Args:
        error: Original sqlite3 exception.

    Returns:
        A package-defined exception instance.
    """

    details = exc.SQLiteErrorDetails(
        errorcode=getattr(error, "sqlite_errorcode", None),
        errorname=getattr(error, "sqlite_errorname", None),
    )
    message = str(error) or error.__class__.__name__
    mapping: list[tuple[type[BaseException], type[exc.Error]]] = [
        (sqlite3.IntegrityError, exc.IntegrityError),
        (sqlite3.ProgrammingError, exc.ProgrammingError),
        (sqlite3.OperationalError, exc.OperationalError),
        (sqlite3.DataError, exc.DataError),
        (sqlite3.InternalError, exc.InternalError),
        (sqlite3.NotSupportedError, exc.NotSupportedError),
        (sqlite3.InterfaceError, exc.InterfaceError),
        (sqlite3.DatabaseError, exc.DatabaseError),
        (sqlite3.Error, exc.Error),
    ]
    for source_type, target_type in mapping:
        if isinstance(error, source_type):
            return target_type(message, original=error, details=details)
    return exc.Error(message, original=error, details=details)
