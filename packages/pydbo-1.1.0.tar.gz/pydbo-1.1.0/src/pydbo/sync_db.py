"""Synchronous SQLite client for pydbo."""

from __future__ import annotations

import contextlib
import sqlite3
from collections.abc import Iterable, Iterator, Mapping, Sequence
from pathlib import Path
from typing import Any, Callable

from . import exc
from .dialect import insert_keyword
from .helpers import (
    build_assignment_list,
    build_placeholders,
    ensure_consistent_rows,
    map_sqlite_exception,
    normalize_params,
    quote_identifier,
    validate_identifier,
)
from .result import RowDict, StatementResult
from .transaction import Transaction

RowFactory = Callable[[sqlite3.Cursor, tuple[Any, ...]], Any]


class Database:
    """User-friendly synchronous SQLite client.

    This class wraps Python's built-in :mod:`sqlite3` module with a cleaner,
    safer API focused exclusively on SQLite.

    Args:
        path: SQLite database path. Use ``":memory:"`` for an in-memory database.
        timeout: Busy timeout in seconds.
        detect_types: sqlite3 type parsing flags.
        isolation_level: sqlite3 isolation level. ``None`` enables autocommit.
        pragmas: Optional pragma key-value pairs applied on connect.
        row_factory: Optional sqlite3-compatible row factory.
        uri: Whether ``path`` should be interpreted as a SQLite URI.
        check_same_thread: Forwarded to sqlite3.

    Example:
        >>> from pydbo import open_db
        >>> with open_db("app.db") as db:
        ...     db.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)")
        ...     db.insert("users", {"name": "Ada"})
        ...     db.fetch_all("SELECT * FROM users")
        [{'id': 1, 'name': 'Ada'}]
    """

    def __init__(
        self,
        path: str | Path,
        *,
        timeout: float = 30.0,
        detect_types: int = 0,
        isolation_level: str | None = None,
        pragmas: Mapping[str, Any] | None = None,
        row_factory: RowFactory | None = None,
        uri: bool = False,
        check_same_thread: bool = False,
    ) -> None:
        self.path = str(path)
        self.timeout = timeout
        self.detect_types = detect_types
        self.isolation_level = isolation_level
        self.pragmas = dict(pragmas or {})
        self._row_factory = row_factory
        self.uri = uri
        self.check_same_thread = check_same_thread
        self._connection: sqlite3.Connection | None = None
        self._transaction_depth = 0
        self._savepoint_index = 0
        self._connect()

    def _connect(self) -> None:
        """Open the underlying sqlite3 connection and apply defaults."""

        if self._connection is not None:
            return
        try:
            connection = sqlite3.connect(
                self.path,
                timeout=self.timeout,
                detect_types=self.detect_types,
                isolation_level=self.isolation_level,
                uri=self.uri,
                check_same_thread=self.check_same_thread,
            )
            connection.row_factory = self._dict_row_factory
            if self._row_factory is not None:
                connection.row_factory = self._row_factory
            self._connection = connection
            self._apply_default_pragmas()
            self._apply_user_pragmas()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    @staticmethod
    def _dict_row_factory(cursor: sqlite3.Cursor, row: tuple[Any, ...]) -> RowDict:
        """Convert sqlite3 row tuples into dictionaries."""

        return {description[0]: row[index] for index, description in enumerate(cursor.description)}

    @property
    def connection(self) -> sqlite3.Connection:
        """Return the underlying sqlite3 connection.

        Raises:
            ConnectionClosedError: If the client has already been closed.
        """

        if self._connection is None:
            raise exc.ConnectionClosedError("The database connection is closed")
        return self._connection

    def close(self) -> None:
        """Close the database connection."""

        if self._connection is None:
            return
        try:
            self._connection.close()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error
        finally:
            self._connection = None

    def __enter__(self) -> "Database":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _apply_default_pragmas(self) -> None:
        """Apply tuned defaults for safety and performance."""

        defaults = {
            "foreign_keys": "ON",
            "journal_mode": "WAL",
            "busy_timeout": int(self.timeout * 1000),
            "synchronous": "NORMAL",
            "temp_store": "MEMORY",
            "cache_size": -8000,
        }
        for key, value in defaults.items():
            self._set_pragma(key, value)
        with contextlib.suppress(Exception):
            self.execute("PRAGMA optimize")

    def _apply_user_pragmas(self) -> None:
        for key, value in self.pragmas.items():
            self._set_pragma(key, value)

    def _set_pragma(self, key: str, value: Any) -> None:
        validate_identifier(key, kind="pragma name")
        rendered = f"'{value}'" if isinstance(value, str) and not value.isupper() else value
        self.execute(f"PRAGMA {key} = {rendered}")

    def execute(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Execute a SQL statement.

        Args:
            sql: SQL statement text.
            params: Positional SQL parameters for ``?`` placeholders.

        Returns:
            Metadata describing the executed statement.
        """

        try:
            cursor = self.connection.execute(sql, normalize_params(params))
            return StatementResult(rowcount=cursor.rowcount, lastrowid=cursor.lastrowid)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def executemany(
        self,
        sql: str,
        seq_of_params: Iterable[Sequence[Any]],
    ) -> StatementResult:
        """Execute a parameterized SQL statement against many parameter sets."""

        normalized_params = [tuple(normalize_params(params)) for params in seq_of_params]
        try:
            cursor = self.connection.executemany(sql, normalized_params)
            return StatementResult(rowcount=cursor.rowcount, lastrowid=cursor.lastrowid)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def script(self, sql_script: str) -> None:
        """Execute a SQL script containing one or more statements."""

        try:
            self.connection.executescript(sql_script)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def fetch_all(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> list[RowDict]:
        """Return all rows for a query as dictionaries."""

        try:
            cursor = self.connection.execute(sql, normalize_params(params))
            rows = cursor.fetchall()
            return list(rows)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def fetch_one(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> RowDict | None:
        """Return the first row for a query as a dictionary, or ``None``."""

        try:
            cursor = self.connection.execute(sql, normalize_params(params))
            return cursor.fetchone()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def fetch_value(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
        *,
        default: Any = None,
    ) -> Any:
        """Return the first column of the first row, or ``default``."""

        row = self.fetch_one(sql, params)
        if row is None:
            return default
        return next(iter(row.values()))

    def select(
        self,
        table: str,
        *,
        columns: Sequence[str] | None = None,
        where: str | None = None,
        params: Sequence[Any] | None = None,
        order_by: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[RowDict]:
        """Build and run a user-friendly ``SELECT`` query."""

        table_sql = quote_identifier(table)
        if columns:
            column_sql = ", ".join(quote_identifier(column) for column in columns)
        else:
            column_sql = "*"
        sql = f"SELECT {column_sql} FROM {table_sql}"
        if where:
            sql += f" WHERE {where}"
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += f" LIMIT {int(limit)}"
        if offset is not None:
            sql += f" OFFSET {int(offset)}"
        return self.fetch_all(sql, params)

    def insert(
        self,
        table: str,
        values: Mapping[str, Any],
        *,
        on_conflict: str = "abort",
    ) -> StatementResult:
        """Insert one row using a mapping of column names to values."""

        rows = ensure_consistent_rows([values])
        return self.insert_many(table, rows, on_conflict=on_conflict)

    def insert_many(
        self,
        table: str,
        rows: Iterable[Mapping[str, Any]],
        *,
        on_conflict: str = "abort",
        chunk_size: int = 500,
    ) -> StatementResult:
        """Insert multiple rows with SQLite-native conflict handling.

        Args:
            table: Target table name.
            rows: Iterable of dictionaries that all share the same keys.
            on_conflict: SQLite conflict policy such as ``"ignore"``.
            chunk_size: Number of rows per executemany call.

        Returns:
            Aggregate statement result.
        """

        materialized = ensure_consistent_rows(rows)
        table_sql = quote_identifier(table)
        columns = list(materialized[0].keys())
        column_sql = ", ".join(quote_identifier(column) for column in columns)
        placeholders = build_placeholders(len(columns))
        sql = f"{insert_keyword(on_conflict)} INTO {table_sql} ({column_sql}) VALUES ({placeholders})"

        total_rowcount = 0
        lastrowid: int | None = None
        for start in range(0, len(materialized), max(int(chunk_size), 1)):
            chunk = materialized[start : start + max(int(chunk_size), 1)]
            params = [tuple(row[column] for column in columns) for row in chunk]
            result = self.executemany(sql, params)
            total_rowcount += max(result.rowcount, 0)
            if result.lastrowid is not None:
                lastrowid = result.lastrowid
        return StatementResult(rowcount=total_rowcount, lastrowid=lastrowid)

    def update(
        self,
        table: str,
        values: Mapping[str, Any],
        *,
        where: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Update rows with a mapping-based ``SET`` clause."""

        if not values:
            raise exc.ValidationError("values must not be empty")
        columns = [validate_identifier(str(column), kind="column name") for column in values.keys()]
        assignments = build_assignment_list(columns)
        sql = f"UPDATE {quote_identifier(table)} SET {assignments} WHERE {where}"
        final_params = [values[column] for column in columns]
        if params:
            final_params.extend(params)
        return self.execute(sql, tuple(final_params))

    def delete(
        self,
        table: str,
        *,
        where: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Delete rows from a table."""

        sql = f"DELETE FROM {quote_identifier(table)} WHERE {where}"
        return self.execute(sql, params)

    def upsert(
        self,
        table: str,
        values: Mapping[str, Any],
        *,
        conflict_columns: Sequence[str],
        update_columns: Sequence[str] | None = None,
    ) -> StatementResult:
        """Insert or update a row using SQLite ``ON CONFLICT``.

        Args:
            table: Target table name.
            values: Inserted row data.
            conflict_columns: Columns that define the conflict target.
            update_columns: Columns to update on conflict. Defaults to all
                columns except the conflict target.
        """

        row = ensure_consistent_rows([values])[0]
        columns = list(row.keys())
        target_columns = [validate_identifier(column, kind="conflict column") for column in conflict_columns]
        mutable_columns = list(update_columns) if update_columns is not None else [
            column for column in columns if column not in target_columns
        ]
        for column in mutable_columns:
            validate_identifier(column, kind="update column")

        table_sql = quote_identifier(table)
        column_sql = ", ".join(quote_identifier(column) for column in columns)
        placeholders = build_placeholders(len(columns))
        conflict_sql = ", ".join(quote_identifier(column) for column in target_columns)
        if mutable_columns:
            assignments = ", ".join(
                f'{quote_identifier(column)} = excluded.{quote_identifier(column)}' for column in mutable_columns
            )
            action = f"DO UPDATE SET {assignments}"
        else:
            action = "DO NOTHING"
        sql = (
            f"INSERT INTO {table_sql} ({column_sql}) VALUES ({placeholders}) "
            f"ON CONFLICT ({conflict_sql}) {action}"
        )
        params = tuple(row[column] for column in columns)
        return self.execute(sql, params)

    def table(self, name: str) -> "Table":
        """Return a lightweight table helper bound to this client."""

        return Table(self, name)

    def transaction(self) -> Transaction:
        """Return a transaction context manager."""

        return Transaction(self)

    def _enter_transaction(self) -> None:
        try:
            if self._transaction_depth == 0:
                self.connection.execute("BEGIN")
            else:
                savepoint = self._next_savepoint_name()
                self.connection.execute(f"SAVEPOINT {savepoint}")
            self._transaction_depth += 1
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def _exit_transaction(self, committed: bool) -> None:
        try:
            if self._transaction_depth <= 0:
                return
            if self._transaction_depth == 1:
                self.connection.execute("COMMIT" if committed else "ROLLBACK")
            else:
                savepoint = self._current_savepoint_name()
                if committed:
                    self.connection.execute(f"RELEASE SAVEPOINT {savepoint}")
                else:
                    self.connection.execute(f"ROLLBACK TO SAVEPOINT {savepoint}")
                    self.connection.execute(f"RELEASE SAVEPOINT {savepoint}")
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error
        finally:
            self._transaction_depth = max(self._transaction_depth - 1, 0)

    def _next_savepoint_name(self) -> str:
        self._savepoint_index += 1
        return f"sp_{self._savepoint_index}"

    def _current_savepoint_name(self) -> str:
        return f"sp_{self._savepoint_index}"

    def commit(self) -> None:
        """Commit the current transaction."""

        try:
            self.connection.commit()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def rollback(self) -> None:
        """Rollback the current transaction."""

        try:
            self.connection.rollback()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def backup(self, target: sqlite3.Connection | "Database", *, pages: int = -1) -> None:
        """Copy this database into another SQLite connection or client."""

        destination = target.connection if isinstance(target, Database) else target
        try:
            self.connection.backup(destination, pages=pages)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def iterdump(self) -> Iterator[str]:
        """Yield SQL statements that recreate the database."""

        try:
            return self.connection.iterdump()
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def create_function(self, name: str, narg: int, func: Callable[..., Any], *, deterministic: bool = False) -> None:
        """Register a custom SQLite scalar function."""

        try:
            self.connection.create_function(name, narg, func, deterministic=deterministic)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def create_aggregate(self, name: str, n_arg: int, aggregate_class: type) -> None:
        """Register a custom SQLite aggregate."""

        try:
            self.connection.create_aggregate(name, n_arg, aggregate_class)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    def create_collation(self, name: str, callable_: Callable[[str, str], int]) -> None:
        """Register a custom SQLite collation."""

        try:
            self.connection.create_collation(name, callable_)
        except sqlite3.Error as error:
            raise map_sqlite_exception(error) from error

    @property
    def total_changes(self) -> int:
        """Return SQLite's total change count for the connection."""

        return self.connection.total_changes

    @property
    def in_transaction(self) -> bool:
        """Return whether the connection is currently inside a transaction."""

        return self.connection.in_transaction


class Table:
    """A small, user-friendly helper bound to a specific table."""

    def __init__(self, database: Database, name: str) -> None:
        self.database = database
        self.name = validate_identifier(name, kind="table name")

    def all(self, *, order_by: str | None = None, limit: int | None = None) -> list[RowDict]:
        """Return rows from the table."""

        return self.database.select(self.name, order_by=order_by, limit=limit)

    def get(self, where: str, params: Sequence[Any] | None = None) -> RowDict | None:
        """Return one row from the table."""

        rows = self.database.select(self.name, where=where, params=params, limit=1)
        return rows[0] if rows else None

    def insert(self, values: Mapping[str, Any], *, on_conflict: str = "abort") -> StatementResult:
        """Insert one row into the bound table."""

        return self.database.insert(self.name, values, on_conflict=on_conflict)

    def insert_many(
        self,
        rows: Iterable[Mapping[str, Any]],
        *,
        on_conflict: str = "abort",
        chunk_size: int = 500,
    ) -> StatementResult:
        """Insert multiple rows into the bound table."""

        return self.database.insert_many(self.name, rows, on_conflict=on_conflict, chunk_size=chunk_size)

    def update(self, values: Mapping[str, Any], *, where: str, params: Sequence[Any] | None = None) -> StatementResult:
        """Update rows in the bound table."""

        return self.database.update(self.name, values, where=where, params=params)

    def delete(self, *, where: str, params: Sequence[Any] | None = None) -> StatementResult:
        """Delete rows from the bound table."""

        return self.database.delete(self.name, where=where, params=params)
