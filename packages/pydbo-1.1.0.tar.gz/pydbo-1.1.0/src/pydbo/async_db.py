"""Asynchronous SQLite client for pydbo.

The async client uses ``asyncio.to_thread`` on top of the built-in ``sqlite3`` module.
"""

from __future__ import annotations

import asyncio
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .result import RowDict, StatementResult
from .sync_db import Database, Table
from .transaction import AsyncTransaction


class AsyncDatabase:
    """Asynchronous wrapper around :class:`pydbo.sync_db.Database`."""

    def __init__(self, path: str | Path, **kwargs: Any) -> None:
        self._sync = Database(path, **kwargs)

    async def close(self) -> None:
        """Close the database connection."""

        await asyncio.to_thread(self._sync.close)

    async def __aenter__(self) -> "AsyncDatabase":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def execute(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Execute a SQL statement asynchronously."""

        return await asyncio.to_thread(self._sync.execute, sql, params)

    async def executemany(
        self,
        sql: str,
        seq_of_params: Iterable[Sequence[Any]],
    ) -> StatementResult:
        """Execute many parameter sets asynchronously."""

        return await asyncio.to_thread(self._sync.executemany, sql, seq_of_params)

    async def script(self, sql_script: str) -> None:
        """Execute a SQL script asynchronously."""

        await asyncio.to_thread(self._sync.script, sql_script)

    async def fetch_all(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> list[RowDict]:
        """Fetch all rows asynchronously."""

        return await asyncio.to_thread(self._sync.fetch_all, sql, params)

    async def fetch_one(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> RowDict | None:
        """Fetch one row asynchronously."""

        return await asyncio.to_thread(self._sync.fetch_one, sql, params)

    async def fetch_value(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
        *,
        default: Any = None,
    ) -> Any:
        """Fetch a scalar value asynchronously."""

        return await asyncio.to_thread(self._sync.fetch_value, sql, params, default=default)

    async def select(self, table: str, **kwargs: Any) -> list[RowDict]:
        """Run a friendly SELECT helper asynchronously."""

        return await asyncio.to_thread(self._sync.select, table, **kwargs)

    async def insert(self, table: str, values: Mapping[str, Any], *, on_conflict: str = "abort") -> StatementResult:
        """Insert one row asynchronously."""

        return await asyncio.to_thread(self._sync.insert, table, values, on_conflict=on_conflict)

    async def insert_many(
        self,
        table: str,
        rows: Iterable[Mapping[str, Any]],
        *,
        on_conflict: str = "abort",
        chunk_size: int = 500,
    ) -> StatementResult:
        """Insert multiple rows asynchronously."""

        return await asyncio.to_thread(
            self._sync.insert_many,
            table,
            rows,
            on_conflict=on_conflict,
            chunk_size=chunk_size,
        )

    async def update(
        self,
        table: str,
        values: Mapping[str, Any],
        *,
        where: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Update rows asynchronously."""

        return await asyncio.to_thread(self._sync.update, table, values, where=where, params=params)

    async def delete(
        self,
        table: str,
        *,
        where: str,
        params: Sequence[Any] | None = None,
    ) -> StatementResult:
        """Delete rows asynchronously."""

        return await asyncio.to_thread(self._sync.delete, table, where=where, params=params)

    async def upsert(
        self,
        table: str,
        values: Mapping[str, Any],
        *,
        conflict_columns: Sequence[str],
        update_columns: Sequence[str] | None = None,
    ) -> StatementResult:
        """Run an upsert asynchronously."""

        return await asyncio.to_thread(
            self._sync.upsert,
            table,
            values,
            conflict_columns=conflict_columns,
            update_columns=update_columns,
        )

    def table(self, name: str) -> "AsyncTable":
        """Return a lightweight async table helper."""

        return AsyncTable(self, name)

    def transaction(self) -> AsyncTransaction:
        """Return an async transaction context manager."""

        return AsyncTransaction(self)

    async def _enter_transaction(self) -> None:
        await asyncio.to_thread(self._sync._enter_transaction)

    async def _exit_transaction(self, committed: bool) -> None:
        await asyncio.to_thread(self._sync._exit_transaction, committed)

    @property
    def total_changes(self) -> int:
        """Return SQLite's total change count."""

        return self._sync.total_changes

    @property
    def in_transaction(self) -> bool:
        """Return whether the connection is in a transaction."""

        return self._sync.in_transaction


class AsyncTable:
    """Async table-bound convenience helper."""

    def __init__(self, database: AsyncDatabase, name: str) -> None:
        self.database = database
        self.name = name

    async def all(self, *, order_by: str | None = None, limit: int | None = None) -> list[RowDict]:
        """Return rows from the bound table asynchronously."""

        return await self.database.select(self.name, order_by=order_by, limit=limit)

    async def get(self, where: str, params: Sequence[Any] | None = None) -> RowDict | None:
        """Return one row from the bound table asynchronously."""

        rows = await self.database.select(self.name, where=where, params=params, limit=1)
        return rows[0] if rows else None

    async def insert(self, values: Mapping[str, Any], *, on_conflict: str = "abort") -> StatementResult:
        """Insert one row into the bound table asynchronously."""

        return await self.database.insert(self.name, values, on_conflict=on_conflict)

    async def insert_many(
        self,
        rows: Iterable[Mapping[str, Any]],
        *,
        on_conflict: str = "abort",
        chunk_size: int = 500,
    ) -> StatementResult:
        """Insert many rows into the bound table asynchronously."""

        return await self.database.insert_many(self.name, rows, on_conflict=on_conflict, chunk_size=chunk_size)

    async def update(self, values: Mapping[str, Any], *, where: str, params: Sequence[Any] | None = None) -> StatementResult:
        """Update rows in the bound table asynchronously."""

        return await self.database.update(self.name, values, where=where, params=params)

    async def delete(self, *, where: str, params: Sequence[Any] | None = None) -> StatementResult:
        """Delete rows from the bound table asynchronously."""

        return await self.database.delete(self.name, where=where, params=params)
