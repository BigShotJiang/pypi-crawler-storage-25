# pydbo

A lightweight, SQLite-first database toolkit for Python built on top of the standard library’s `sqlite3` module.

## Installation

```bash
pip install pydbo
```

**Requires:** Python 3.11+

## Quick Example

### Synchronous

```python
from pydbo import open_db

with open_db(":memory:") as db:
    db.script(
        '''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL
        );
        '''
    )

    db.insert("users", {"email": "ada@example.com", "name": "Ada"})
    rows = db.select("users", order_by="id ASC")
    print(rows)
```

### Asynchronous

```python
import asyncio
from pydbo import open_async

async def main() -> None:
    db = await open_async(":memory:")
    try:
        await db.script(
            '''
            CREATE TABLE events (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE
            );
            '''
        )

        await db.insert("events", {"name": "Launch"})
        rows = await db.select("events", order_by="id ASC")
        print(rows)
    finally:
        await db.close()

asyncio.run(main())
```

## License

MIT License
