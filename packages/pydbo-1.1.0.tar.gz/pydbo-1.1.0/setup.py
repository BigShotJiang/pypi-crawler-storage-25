from setuptools import setup


def readme():
    with open('README.md') as f:
        return f.read()


setup(
    name="pydbo",
    version="1.1.0",
    author="Joumaico Maulas",
    description="A lightweight SQLite-first database toolkit for Python.",
    long_description=readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/joumaico/pydbo",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
    ],
    packages=[
        "pydbo",
    ],
    package_dir={
        "pydbo": "src/pydbo",
    },
    python_requires=">=3.11",
)
