// test_203_shuttle_rack_convergence.rs
//
// 203 — Shuttle rack second-order convergence regression test
//
// Validates that the solver converges on rack configurations that
// previously failed with "non-descent at αmin; flip-left failed;
// max substepping reached" on horizontal/seismic load combinations.
//
// Background: Configs with lateral loads (LC 6, 7, 8, 13, 15) on
// heavily compressed uprights push the tangent K_e + K_g toward
// indefiniteness, causing NR line-search failures.
//
// To add a failing model:
//   1. Export the JSON from the server for a failing config
//   2. Save as tests/shuttle_rack_convergence.json
//   3. Run: cargo test test_203 -- --nocapture

use fers_calculations::analysis::calculate_from_json_internal_with_tier;
use fers_calculations::limits::LicenseTier;

fn load_convergence_model() -> Option<String> {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("shuttle_rack_convergence.json");
    std::fs::read_to_string(&path).ok()
}

/// Run the model and return (ok_count, fail_count, failures, elapsed_secs)
fn run_model(json: &str) -> (u32, u32, Vec<String>, f64) {
    let t0 = std::time::Instant::now();
    let result = calculate_from_json_internal_with_tier(json, LicenseTier::Premium);
    let elapsed = t0.elapsed().as_secs_f64();

    let res_json = match &result {
        Ok(res_json) => res_json.clone(),
        Err(e) => {
            return (0, 1, vec![format!("Top-level error: {e}")], elapsed);
        }
    };

    let v: serde_json::Value = serde_json::from_str(&res_json).unwrap();
    let mut n_ok = 0u32;
    let mut n_fail = 0u32;
    let mut failures: Vec<String> = Vec::new();

    if let Some(cases) = v["results"]["loadcases"].as_object() {
        for (name, data) in cases {
            if let Some(err) = data.get("error") {
                n_fail += 1;
                failures.push(format!("LC '{}': {}", name, err));
            } else {
                n_ok += 1;
            }
        }
    }
    if let Some(combos) = v["results"]["loadcombinations"].as_object() {
        for (name, data) in combos {
            if let Some(err) = data.get("error") {
                n_fail += 1;
                failures.push(format!("Combo '{}': {}", name, err));
            } else {
                n_ok += 1;
            }
        }
    }

    (n_ok, n_fail, failures, elapsed)
}

#[test]
fn test_203a_all_combos_converge() {
    let json = match load_convergence_model() {
        Some(j) => j,
        None => {
            eprintln!("⚠ shuttle_rack_convergence.json not found — skipping test_203a");
            eprintln!("  To enable: export a failing config JSON and save to tests/shuttle_rack_convergence.json");
            return;
        }
    };

    let (n_ok, n_fail, failures, elapsed) = run_model(&json);
    eprintln!(
        "203a (convergence): {} OK, {} FAIL in {:.1}s",
        n_ok, n_fail, elapsed
    );
    if !failures.is_empty() {
        for f in &failures {
            eprintln!("  ❌ {f}");
        }
    }
    assert_eq!(
        n_fail, 0,
        "Expected all combos to converge, but {n_fail} failed:\n{}",
        failures.join("\n")
    );
}

/// Test specifically the lateral/seismic combos (6, 7, 8, 13, 15)
/// that are most prone to convergence issues.
#[test]
fn test_203b_lateral_combos_converge() {
    let json = match load_convergence_model() {
        Some(j) => j,
        None => {
            eprintln!("⚠ shuttle_rack_convergence.json not found — skipping test_203b");
            return;
        }
    };

    let t0 = std::time::Instant::now();
    let result = calculate_from_json_internal_with_tier(&json, LicenseTier::Premium);
    let elapsed = t0.elapsed().as_secs_f64();

    let res_json = result.expect("Solver should succeed");
    let v: serde_json::Value = serde_json::from_str(&res_json).unwrap();

    // Check the specific lateral/seismic combos
    let lateral_combo_ids = [6, 7, 8, 13, 15];
    let mut failures: Vec<String> = Vec::new();

    if let Some(combos) = v["results"]["loadcombinations"].as_object() {
        for (name, data) in combos {
            if let Some(err) = data.get("error") {
                // Check if this combo ID is in our lateral set
                if let Ok(id) = name.parse::<u32>() {
                    if lateral_combo_ids.contains(&id) {
                        failures.push(format!("Combo {name}: {err}"));
                    }
                }
            }
        }
    }

    eprintln!(
        "203b (lateral combos 6,7,8,13,15): {:.1}s, {} failures",
        elapsed,
        failures.len()
    );
    assert!(
        failures.is_empty(),
        "Lateral combos failed:\n{}",
        failures.join("\n")
    );
}
