use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, ToSchema, Debug, Clone)]
pub struct Section {
    pub id: u32,
    pub name: String,
    pub material: u32,
    pub h: Option<f64>,
    pub b: Option<f64>,
    pub i_y: f64,
    pub i_z: f64,
    pub j: f64,
    pub area: f64,
    pub shape_path: Option<u32>,
    /// Warping constant (m⁶). None = no warping (pure St. Venant torsion).
    #[serde(default)]
    pub i_w: Option<f64>,
    /// Shear center Y-coordinate relative to centroid (m).
    #[serde(default)]
    pub y_s: Option<f64>,
    /// Shear center Z-coordinate relative to centroid (m).
    #[serde(default)]
    pub z_s: Option<f64>,
    /// Wagner coefficient for lateral-torsional buckling.
    #[serde(default)]
    pub wagner_coeff: Option<f64>,
    /// Effective shear area in Y-direction (m²). None = no shear deformation (Euler-Bernoulli).
    #[serde(default)]
    pub a_sy: Option<f64>,
    /// Effective shear area in Z-direction (m²). None = no shear deformation (Euler-Bernoulli).
    #[serde(default)]
    pub a_sz: Option<f64>,
    /// Product of inertia about centroidal axes (mm⁴ in JSON, scaled to m⁴ by solver).
    /// Non-zero for asymmetric sections (e.g. angle, C-channel with unequal flanges).
    /// When present and non-zero, the solver auto-detects whether `i_y`/`i_z`
    /// are centroidal or principal values (by checking angle consistency) and
    /// applies or skips the principal-axis rotation accordingly.
    #[serde(default)]
    pub i_yz: Option<f64>,
    /// Angle (degrees) from centroidal to principal axes.
    /// When `i_yz` is absent or zero, this angle is used to rotate the
    /// stiffness matrix from principal to centroidal frame.  When `i_yz`
    /// is present, the solver checks whether `i_y`/`i_z` are centroidal
    /// (angle matches formula) or principal (rotation applied).
    /// Positive = counter-clockwise.  Default 0.
    #[serde(default)]
    pub principal_axis_angle: Option<f64>,
    /// Centroid Y-coordinate within the shape path coordinate system (mm).
    /// Used by the viewer to offset shape-path extrusions so the centroid
    /// aligns with the member node.  Not used by the solver.
    #[serde(default)]
    pub centroid_y: Option<f64>,
    /// Centroid Z-coordinate within the shape path coordinate system (mm).
    #[serde(default)]
    pub centroid_z: Option<f64>,
}
