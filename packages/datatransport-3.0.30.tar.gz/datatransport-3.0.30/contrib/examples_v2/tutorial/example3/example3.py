#!/usr/bin/env python

##########################################################
#
#   Example 3 - poll a news group
#
#   Print any messages from the news group to the log
#
#   2010-08-16  Todd Valentic
#               Initial implementation
#
##########################################################

from Transport import ProcessClient
from Transport import NewsPollMixin

import sys

class PollExample(ProcessClient,NewsPollMixin):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)
        NewsPollMixin.__init__(self,callback=self.process)

    def process(self,message):

        body = message.get_payload()

        self.log.info('Received: %s' % body)

if __name__ == '__main__':
    PollExample(sys.argv).run()

