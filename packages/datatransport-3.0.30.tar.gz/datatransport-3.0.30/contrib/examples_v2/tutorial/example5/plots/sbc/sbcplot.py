#!/usr/bin/env python

#####################################################
#
#   SBC Plotter
#
#   Example of writing a data format helper
#
#   2010-08-21  Todd Valentic
#               Initial implementation
#
#####################################################

from Transport.Components   import PlotTool

import sys
import ConfigParser

class PlotSBC(PlotTool):

    def parse(self,message):

        # body is one line long, format:
        #
        #   [fan] 0

        body = message.get_payload()

        self.data = ConfigParser.ConfigParser()
        self.data.add_section('State')

        body = body.split('\n')
        unit,state = body[0].split()

        # [fan] -> fan

        unit = unit[1:-1]

        self.data.set('State',unit,state)

        return True

if __name__ == '__main__':
    PlotSBC(sys.argv).run()
