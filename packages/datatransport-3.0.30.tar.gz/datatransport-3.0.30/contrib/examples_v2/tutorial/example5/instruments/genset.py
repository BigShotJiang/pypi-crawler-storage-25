#!/usr/bin/env python

###########################################################
#
#   Simulated genset data producer
#
#   Write out data records to be picked up by another
#   process.
#
#   2010-08-21  Todd Valentic
#               Initial implementation.
#
###########################################################

from Transport      import ProcessClient

import sys
import random
import ConfigParser
import StringIO

class Genset(ProcessClient):

    def __init__(self,argv):
        ProcessClient.__init__(self,argv)

        self.outputPath = self.get('output.path')
        self.rate       = self.getRate('rate')

    def run(self):

        while self.wait(self.rate):
            try:
                self.process()
            except:
                self.log.exception('Problem processing')

    def process(self):

        data = self.createData()

        output = self.currentTime().strftime(self.outputPath)

        open(output,'w').write(data)

        self.log.info('Created: %s' % output)

    def createData(self):

        data = ConfigParser.ConfigParser()

        data.set('DEFAULT','timestamp',str(self.currentTime()))

        data.add_section('E1')
        data.add_section('E2')
        data.add_section('E3')

        data.set('E1','temperature',str(random.uniform(60,90)))
        data.set('E2','temperature',str(random.uniform(60,90)))
        data.set('E3','temperature',str(random.uniform(60,90)))

        buffer = StringIO.StringIO()
        data.write(buffer)

        return buffer.getvalue()

if __name__ == '__main__':
    Genset(sys.argv).run()

