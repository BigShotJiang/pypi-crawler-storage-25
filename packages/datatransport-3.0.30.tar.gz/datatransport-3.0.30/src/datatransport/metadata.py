"""Package metadata"""

__version__ = "3.0.30"
