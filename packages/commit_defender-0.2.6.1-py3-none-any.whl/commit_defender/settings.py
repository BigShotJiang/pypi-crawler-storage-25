"""Runtime settings loaded via pydantic-settings.

All values come from environment variables (CD_* prefix) set by the VS Code
extension or the CLI hook.  No .env files are read.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # Azure OpenAI credentials
    azure_openai_api_key: str = ""
    azure_openai_endpoint: str = ""
    azure_openai_deployment: str = ""
    azure_openai_api_version: str = "2024-08-01-preview"

    # Anthropic credentials
    anthropic_api_key: str = ""

    # Google Gemini credentials
    gemini_api_key: str = ""

    # Operational flags (non-secret, passed as -e by the hook)
    cd_skip_ai: str = "0"
    cd_dry_run: str = "0"
    cd_json: str = "0"
    cd_staged_files: str = ""
    # Explicit file list (newline-separated, repo-relative).
    # When set, skips git staging detection — used by "analyze file/directory" commands.
    cd_target_files: str = ""
    # Default to cwd when not running inside a Docker container
    cd_repo_path: str = ""

    # AI connection settings — set by VS Code extension; empty = fall back to env file / defaults
    cd_ai_provider: str = ""   # azure-openai | anthropic | openai
    cd_model: str = ""         # model or deployment name
    cd_endpoint: str = ""      # API endpoint URL (required for azure-openai)
    cd_api_version: str = ""   # Azure API version
    cd_api_key: str = ""       # API key (overrides provider-specific key from env file)
    cd_max_tokens: str = ""    # output token limit override

    # Review behavior — set by VS Code extension or hook; empty = fall back to
    # .commit-defender/settings.json, then built-in defaults.
    cd_analysis_mode: str = ""   # hybrid | ai-powered | rule-based
    cd_severity_level: str = ""
    cd_richness_level: str = ""
    cd_locale: str = ""
    # Newline-separated gitignore-style patterns from VS Code settings.
    # Merged with patterns in .commit-defender/settings.json.
    cd_exclude_patterns: str = ""

    @property
    def repo_path(self) -> str:
        """Resolved repo path: explicit value, else current working directory."""
        return self.cd_repo_path or str(Path.cwd())

    @field_validator("azure_openai_endpoint")
    @classmethod
    def strip_trailing_slash(cls, v: str) -> str:
        return v.rstrip("/")

    @property
    def skip_ai(self) -> bool:
        return self.cd_skip_ai.strip() == "1"

    @property
    def dry_run(self) -> bool:
        return self.cd_dry_run.strip() == "1"

    @property
    def json_mode(self) -> bool:
        return self.cd_json.strip() == "1"

    def missing_azure_fields(self) -> list[str]:
        missing = []
        if not self.azure_openai_api_key:
            missing.append("AZURE_OPENAI_API_KEY")
        if not self.azure_openai_endpoint:
            missing.append("AZURE_OPENAI_ENDPOINT")
        if not self.azure_openai_deployment:
            missing.append("AZURE_OPENAI_DEPLOYMENT")
        return missing

    def missing_anthropic_fields(self) -> list[str]:
        if not self.anthropic_api_key:
            return ["ANTHROPIC_API_KEY"]
        return []

    def missing_gemini_fields(self) -> list[str]:
        if not self.gemini_api_key:
            return ["GEMINI_API_KEY"]
        return []


def load_settings() -> Settings:
    """Instantiate Settings from environment variables only."""
    return Settings()
