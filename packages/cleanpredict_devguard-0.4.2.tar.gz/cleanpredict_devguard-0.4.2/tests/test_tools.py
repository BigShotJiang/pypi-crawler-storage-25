import os
import tempfile
from devguard.tools import execute_tool, TOOLS_SCHEMA, to_openai_schema


def test_tools_schema_has_five_tools():
    assert len(TOOLS_SCHEMA) == 5
    names = {t["name"] for t in TOOLS_SCHEMA}
    assert names == {"run_command", "read_file", "list_dir", "http_request", "write_file"}


def test_to_openai_schema_format():
    result = to_openai_schema(TOOLS_SCHEMA)
    assert len(result) == 5
    for item in result:
        assert item["type"] == "function"
        assert "name" in item["function"]
        assert "parameters" in item["function"]


def test_run_command():
    result = execute_tool("run_command", {"command": "echo hello"}, ".")
    assert "hello" in result


def test_read_file():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("test content")
        f.flush()
        result = execute_tool("read_file", {"path": f.name}, ".")
    assert "test content" in result
    os.unlink(f.name)


def test_list_dir():
    result = execute_tool("list_dir", {"path": "."}, ".")
    assert "/" in result


def test_write_file():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "out.txt")
        result = execute_tool("write_file", {"path": path, "content": "hello"}, td)
        assert "Salvo" in result
        with open(path) as f:
            assert f.read() == "hello"


def test_unknown_tool():
    result = execute_tool("nonexistent", {}, ".")
    assert "desconhecida" in result


def test_run_command_truncation():
    result = execute_tool(
        "run_command",
        {"command": "python -c \"print('x' * 20000)\"" if os.name != "nt"
         else 'python -c "print(\'x\' * 20000)"'},
        ".",
    )
    assert "[... truncado ...]" in result or len(result) <= 12000
