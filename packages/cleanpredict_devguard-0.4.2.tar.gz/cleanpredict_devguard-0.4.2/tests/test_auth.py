import pytest
from devguard.auth import AuthError


def test_auth_error_is_exception():
    with pytest.raises(AuthError):
        raise AuthError("test error")


def test_auth_error_message():
    err = AuthError("key invalid")
    assert str(err) == "key invalid"
