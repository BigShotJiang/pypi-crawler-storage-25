from devguard.adapter import ToolCall, ModelResponse


def test_tool_call_dataclass():
    tc = ToolCall(id="123", name="run_command", inputs={"command": "ls"})
    assert tc.id == "123"
    assert tc.name == "run_command"


def test_model_response_done():
    resp = ModelResponse(tool_calls=[], text="done", done=True)
    assert resp.done is True
    assert resp.text == "done"


def test_model_response_with_tools():
    tc = ToolCall(id="1", name="list_dir", inputs={"path": "."})
    resp = ModelResponse(tool_calls=[tc], text=None, done=False)
    assert len(resp.tool_calls) == 1
    assert resp.done is False
