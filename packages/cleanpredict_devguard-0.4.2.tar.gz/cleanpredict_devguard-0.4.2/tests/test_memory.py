import tempfile
import os
from devguard.memory import (
    init_db, save_run, load_previous_context,
    mark_fixed_since, get_stats, make_run_id, finding_hash,
)


def test_init_db_creates_tables():
    with tempfile.TemporaryDirectory() as td:
        init_db(td)
        assert os.path.exists(os.path.join(td, ".devguard", "devguard.db"))
        assert os.path.exists(os.path.join(td, ".devguard", ".gitignore"))


def test_save_and_load_run():
    with tempfile.TemporaryDirectory() as td:
        run_id = make_run_id()
        findings = [
            {"title": "SQL Injection", "severity": "critical", "cvss": 9.8,
             "cwe": "CWE-89", "file_path": "app.py", "line_number": 42, "tool": "semgrep"},
        ]
        save_run(td, run_id, "gpt-4o", "python", findings)

        ctx = load_previous_context(td)
        assert "SQL Injection" in ctx
        assert "critical" in ctx


def test_mark_fixed_since():
    with tempfile.TemporaryDirectory() as td:
        run1 = make_run_id()
        save_run(td, run1, "gpt-4o", "python", [
            {"title": "Bug A", "severity": "high", "file_path": "a.py", "line_number": 1},
        ])

        run2 = make_run_id()
        save_run(td, run2, "gpt-4o", "python", [])
        mark_fixed_since(td, run2)

        stats = get_stats(td)
        assert stats["fixed_total"] == 1


def test_get_stats_empty():
    with tempfile.TemporaryDirectory() as td:
        stats = get_stats(td)
        assert stats["total_runs"] == 0
        assert stats["open_critical"] == 0


def test_finding_hash_deterministic():
    h1 = finding_hash("SQL Injection", "app.py", 42)
    h2 = finding_hash("SQL Injection", "app.py", 42)
    assert h1 == h2
    h3 = finding_hash("XSS", "app.py", 42)
    assert h1 != h3


def test_first_analysis_returns_empty_context():
    with tempfile.TemporaryDirectory() as td:
        ctx = load_previous_context(td)
        assert ctx == ""
