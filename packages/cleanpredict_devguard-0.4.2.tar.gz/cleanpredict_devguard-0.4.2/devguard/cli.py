import click
from pathlib import Path
from rich.console import Console

from .config import load_config
from .auth import validate_license, AuthError
from .agent import run_agent
from . import __version__

console = Console()


@click.group()
def main():
    """DevGuard -- autonomous AI security agent for your codebase."""
    pass


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option(
    "--model",
    default=None,
    help="Override do modelo. Ex: gpt-4o, claude-sonnet-4-20250514",
)
@click.option("--no-save", is_flag=True, help="Nao salvar relatorio em arquivo")
@click.option(
    "--no-memory", is_flag=True, help="Ignorar historico de runs anteriores"
)
def security(path, model, no_save, no_memory):
    """Executa analise de seguranca completa no projeto."""
    project_path = str(Path(path).resolve())

    try:
        config = load_config(model_override=model)
        validate_license(config)
    except AuthError as e:
        console.print(f"[red]Erro de autenticacao:[/red] {e}")
        raise SystemExit(1)

    run_agent(
        agent="security",
        project_path=project_path,
        config=config,
        save_report=not no_save,
    )


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
def history(path):
    """Exibe historico de analises do projeto."""
    from .memory import get_stats, init_db

    project_path = str(Path(path).resolve())
    init_db(project_path)
    stats = get_stats(project_path)

    console.print(f"[bold]Historico:[/bold] {project_path}")
    console.print(f"  Analises realizadas: {stats['total_runs']}")
    console.print(f"  Criticos abertos:    {stats['open_critical']}")
    console.print(f"  Altos abertos:       {stats['open_high']}")
    console.print(f"  Corrigidos total:    {stats['fixed_total']}")


@main.command(name="version")
def show_version():
    """Exibe a versao instalada."""
    console.print(f"devguard {__version__}")
