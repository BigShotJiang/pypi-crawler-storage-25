import sqlite3
import uuid
import hashlib
from datetime import datetime, timezone
from pathlib import Path


def _db_path(project_path: str) -> str:
    db_dir = Path(project_path) / ".devguard"
    db_dir.mkdir(exist_ok=True)
    gitignore = db_dir / ".gitignore"
    if not gitignore.exists():
        gitignore.write_text("*\n")
    return str(db_dir / "devguard.db")


def _connect(project_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(project_path))
    conn.row_factory = sqlite3.Row
    return conn


def init_db(project_path: str):
    conn = _connect(project_path)
    try:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS runs (
                id          TEXT PRIMARY KEY,
                project     TEXT NOT NULL,
                ran_at      TEXT NOT NULL,
                model       TEXT,
                stack       TEXT
            );
            CREATE TABLE IF NOT EXISTS findings (
                id          TEXT PRIMARY KEY,
                run_id      TEXT NOT NULL REFERENCES runs(id),
                title       TEXT NOT NULL,
                severity    TEXT,
                cvss        REAL,
                cwe         TEXT,
                file_path   TEXT,
                line_number INTEGER,
                tool        TEXT,
                status      TEXT DEFAULT 'open',
                first_seen  TEXT NOT NULL,
                last_seen   TEXT NOT NULL
            );
        """)
    finally:
        conn.close()


def make_run_id() -> str:
    return str(uuid.uuid4())


def finding_hash(title: str, file_path: str, line_number: int | None) -> str:
    key = f"{title}|{file_path or ''}|{line_number or 0}"
    return hashlib.sha256(key.encode()).hexdigest()[:16]


def save_run(
    project_path: str,
    run_id: str,
    model: str,
    stack: str,
    findings: list[dict],
):
    init_db(project_path)
    now = datetime.now(timezone.utc).isoformat()

    conn = _connect(project_path)
    try:
        conn.execute(
            "INSERT INTO runs (id, project, ran_at, model, stack) VALUES (?,?,?,?,?)",
            (run_id, project_path, now, model, stack),
        )

        for f in findings:
            fid = finding_hash(f["title"], f.get("file_path"), f.get("line_number"))
            existing = conn.execute(
                "SELECT first_seen FROM findings WHERE id = ?", (fid,)
            ).fetchone()
            first_seen = existing["first_seen"] if existing else now

            conn.execute(
                """
                INSERT INTO findings
                    (id, run_id, title, severity, cvss, cwe,
                     file_path, line_number, tool, status, first_seen, last_seen)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    run_id=excluded.run_id, status='open',
                    last_seen=excluded.last_seen
                """,
                (
                    fid, run_id, f["title"], f.get("severity"), f.get("cvss"),
                    f.get("cwe"), f.get("file_path"), f.get("line_number"),
                    f.get("tool"), "open", first_seen, now,
                ),
            )
        conn.commit()
    finally:
        conn.close()


def mark_fixed_since(project_path: str, current_run_id: str):
    conn = _connect(project_path)
    try:
        conn.execute(
            """
            UPDATE findings SET status = 'fixed'
            WHERE status = 'open' AND run_id != ?
            """,
            (current_run_id,),
        )
        conn.commit()
    finally:
        conn.close()


def load_previous_context(project_path: str) -> str:
    init_db(project_path)

    conn = _connect(project_path)
    try:
        last_run = conn.execute(
            "SELECT id, ran_at FROM runs ORDER BY ran_at DESC LIMIT 1"
        ).fetchone()

        if not last_run:
            return ""

        open_findings = conn.execute(
            """
            SELECT title, severity, file_path, line_number,
                   tool, first_seen
            FROM findings
            WHERE status = 'open'
            ORDER BY cvss DESC NULLS LAST
            """
        ).fetchall()

        if not open_findings:
            return (
                f"\n## Contexto: analise anterior ({last_run['ran_at'][:10]})\n"
                "Nenhum finding aberto da analise anterior. Excelente!\n"
                "Verifique se novos problemas foram introduzidos desde entao.\n"
            )

        lines = [
            f"## Contexto: analise anterior ({last_run['ran_at'][:10]})",
            "Os findings abaixo estavam abertos na ultima analise.",
            "Verifique se cada um foi corrigido ou ainda existe:",
            "",
        ]

        for f in open_findings:
            loc = (
                f"{f['file_path']}:{f['line_number']}"
                if f["file_path"]
                else "desconhecido"
            )
            days = (
                datetime.now(timezone.utc)
                - datetime.fromisoformat(f["first_seen"])
            ).days
            lines.append(
                f"- [{f['severity'] or 'INFO'}] {f['title']} | {loc} | "
                f"aberto ha {days} dia(s) | ferramenta: {f['tool'] or 'manual'}"
            )

        lines.append("")
        return "\n".join(lines)
    finally:
        conn.close()


def get_stats(project_path: str) -> dict:
    init_db(project_path)

    conn = _connect(project_path)
    try:
        total_runs = conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
        open_critical = conn.execute(
            "SELECT COUNT(*) FROM findings WHERE status='open' AND severity='critical'"
        ).fetchone()[0]
        open_high = conn.execute(
            "SELECT COUNT(*) FROM findings WHERE status='open' AND severity='high'"
        ).fetchone()[0]
        fixed_total = conn.execute(
            "SELECT COUNT(*) FROM findings WHERE status='fixed'"
        ).fetchone()[0]
    finally:
        conn.close()

    return {
        "total_runs": total_runs,
        "open_critical": open_critical,
        "open_high": open_high,
        "fixed_total": fixed_total,
    }
