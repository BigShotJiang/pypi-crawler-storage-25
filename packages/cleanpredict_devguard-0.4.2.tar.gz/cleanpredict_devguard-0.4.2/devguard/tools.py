import subprocess
import os
import json
import urllib.request
import urllib.error
from pathlib import Path

IGNORE_DIRS = {
    "node_modules", ".git", "__pycache__", "venv", ".venv",
    "env", "dist", "build", ".next", ".nuxt", "coverage",
    ".pytest_cache", ".devguard",
}

TOOLS_SCHEMA = [
    {
        "name": "run_command",
        "description": (
            "Executa um comando shell na maquina do usuario e retorna stdout+stderr. "
            "Use para rodar ferramentas de seguranca (nmap, trivy, semgrep, gitleaks, "
            "docker), inspecionar o projeto, subir servicos. "
            "Verifique disponibilidade da ferramenta antes de usar. "
            "Prefira flags --json quando disponiveis. Timeout default 120s."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "cwd":     {"type": "string"},
                "timeout": {"type": "integer"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Le o conteudo de um arquivo do projeto.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_dir",
        "description": (
            "Lista estrutura de arquivos ate 3 niveis. "
            "Ignora node_modules, .git, __pycache__, venv, .devguard. "
            "Use como PRIMEIRO passo obrigatorio em toda analise."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "http_request",
        "description": (
            "Faz requisicao HTTP para testar endpoints. "
            "Use para verificar headers de seguranca, autenticacao, CORS, "
            "endpoints expostos, e se o servico esta publico."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url":     {"type": "string"},
                "method":  {"type": "string",
                            "enum": ["GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS"]},
                "headers": {"type": "object"},
                "body":    {"type": "string"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "write_file",
        "description": (
            "Escreve um arquivo. Use APENAS para salvar o relatorio final "
            "em devguard-report.md. NUNCA modifique codigo do usuario."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path":    {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
]


def to_openai_schema(tools: list) -> list:
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["input_schema"],
            },
        }
        for t in tools
    ]


def execute_tool(name: str, inputs: dict, project_path: str) -> str:
    try:
        match name:
            case "run_command":  return _run(inputs, project_path)
            case "read_file":    return _read(inputs, project_path)
            case "list_dir":     return _ls(inputs, project_path)
            case "http_request": return _http(inputs)
            case "write_file":   return _write(inputs, project_path)
            case _:              return f"Tool desconhecida: {name}"
    except Exception as e:
        return f"ERRO em {name}: {type(e).__name__}: {e}"


SEMGREP_EXCLUDES = [
    "node_modules", "venv", ".venv", "env", ".git", "__pycache__",
    "dist", "build", ".next", ".nuxt", "coverage", ".pytest_cache",
    ".devguard", "*.min.js", "*.bundle.js",
]


def _inject_semgrep_excludes(cmd: str) -> str:
    """Add --exclude flags to semgrep commands to avoid scanning vendored dirs."""
    if "semgrep" not in cmd:
        return cmd
    existing = cmd.lower()
    excludes = [f"--exclude '{d}'" for d in SEMGREP_EXCLUDES if f"--exclude '{d}'" not in existing]
    if not excludes:
        return cmd
    # Insert excludes before the target path (last token) or at the end
    return cmd.rstrip() + " " + " ".join(excludes)


def _run(inputs: dict, project_path: str) -> str:
    cmd = _inject_semgrep_excludes(inputs["command"])
    cwd = inputs.get("cwd") or project_path

    result = subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=inputs.get("timeout", 120),
    )
    out = result.stdout + result.stderr

    # Detect tool not found / Docker not running and return actionable message
    not_found_signals = ["not recognized", "not found", "is not installed", "No such file"]
    docker_stopped_signals = [
        "docker daemon is not running",
        "error during connect",
        "Cannot connect to the Docker",
        "the docker desktop app is not running",
    ]

    if result.returncode != 0:
        for sig in docker_stopped_signals:
            if sig.lower() in out.lower():
                # Try to start Docker Desktop on Windows
                start_result = subprocess.run(
                    'powershell -Command "Start-Process \\"Docker Desktop\\" -ErrorAction SilentlyContinue"',
                    shell=True, capture_output=True, text=True, timeout=10,
                )
                if start_result.returncode == 0:
                    return (
                        "[AVISO] Docker nao estava em execucao. Tentei iniciar o Docker Desktop. "
                        "Aguarde ~15s e tente novamente. "
                        "Se nao funcionar, PULE esta verificacao e continue a analise sem Docker. "
                        "A analise sera parcial para ferramentas que dependem de container."
                    )
                return (
                    "[AVISO] Docker nao esta em execucao e nao foi possivel inicia-lo. "
                    "PULE esta verificacao e continue a analise sem Docker. "
                    "A analise sera parcial para: gitleaks, trivy, semgrep (via container)."
                )

        for sig in not_found_signals:
            if sig.lower() in out.lower():
                tool_name = cmd.split()[0] if cmd.split() else cmd
                return (
                    f"[AVISO] Ferramenta '{tool_name}' nao esta instalada neste ambiente. "
                    f"PULE e continue a analise usando verificacao manual via leitura de codigo. "
                    f"Nao tente instalar — analise o codigo-fonte diretamente."
                )

    if len(out) > 12000:
        out = out[:6000] + "\n\n[... truncado ...]\n\n" + out[-3000:]
    return out or "(sem output)"


def _read(inputs: dict, project_path: str) -> str:
    path = inputs["path"]
    if not os.path.isabs(path):
        path = os.path.join(project_path, path)
    with open(path, encoding="utf-8", errors="replace") as f:
        content = f.read()
    if len(content) > 15000:
        content = content[:15000] + "\n\n[... truncado ...]"
    return content


def _ls(inputs: dict, project_path: str) -> str:
    base = inputs.get("path") or project_path
    if not os.path.isabs(base):
        base = os.path.join(project_path, base)
    lines = []
    for root, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if d not in IGNORE_DIRS)
        depth = len(Path(root).relative_to(base).parts)
        if depth > 3:
            continue
        lines.append("  " * depth + os.path.basename(root) + "/")
        for f in sorted(files):
            lines.append("  " * depth + "  " + f)
    return "\n".join(lines)


def _http(inputs: dict) -> str:
    url = inputs["url"]
    method = inputs.get("method", "GET").upper()
    headers = inputs.get("headers") or {}
    body = inputs.get("body", "").encode() if inputs.get("body") else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.dumps(
                {
                    "status": r.status,
                    "headers": dict(r.headers),
                    "body": r.read(4000).decode("utf-8", errors="replace"),
                },
                indent=2,
            )
    except urllib.error.HTTPError as e:
        return f"HTTP {e.code}: {e.reason}"
    except Exception as e:
        return f"Erro: {e}"


def _write(inputs: dict, project_path: str) -> str:
    path = inputs["path"]
    if not os.path.isabs(path):
        path = os.path.join(project_path, path)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(inputs["content"])
    return f"Salvo em: {path}"
