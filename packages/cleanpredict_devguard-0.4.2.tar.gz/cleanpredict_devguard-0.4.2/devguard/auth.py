import httpx
from .config import Config


class AuthError(Exception):
    pass


def validate_license(config: Config) -> dict:
    """
    Validates DEVGUARD_API_KEY against the GuardionAI backend.
    The backend uses prefix(8 chars) + SHA-256 hash lookup on cp_api_keys.
    Headers: Authorization Bearer or X-API-Key.
    """
    url = config.validate_url
    headers = {
        "Authorization": f"Bearer {config.devguard_key}",
        "Content-Type": "application/json",
    }
    body = {"service": "devguard"}

    try:
        resp = httpx.post(url, headers=headers, json=body, timeout=10.0)
    except httpx.ConnectError:
        raise AuthError(
            "Nao foi possivel conectar ao servidor de licencas.\n"
            "Verifique sua conexao com a internet."
        )
    except httpx.TimeoutException:
        raise AuthError("Timeout ao validar licenca. Tente novamente.")

    if resp.status_code == 200:
        data = resp.json()
        if data.get("valid"):
            return data
        reason = data.get("reason", "unknown")
        raise AuthError(f"Licenca invalida: {reason}")

    if resp.status_code in (401, 403):
        raise AuthError(
            "DEVGUARD_API_KEY invalida ou expirada.\n"
            "Renove em: https://cleanpredict.com"
        )

    raise AuthError(f"Erro inesperado: HTTP {resp.status_code}")
