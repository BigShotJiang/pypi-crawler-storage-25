import os
from dataclasses import dataclass, field

VALIDATE_URL_DEFAULT = "https://api.cleanpredict.com/api/v1/validate-key"

# Best model first, fallback to cheaper/older ones
MODEL_FALLBACKS = {
    "anthropic": [
        "claude-sonnet-4-20250514",
        "claude-3-5-sonnet-20241022",
        "claude-3-haiku-20240307",
    ],
    "openai": [
        "gpt-4.1",
        "gpt-4o",
        "gpt-4o-mini",
    ],
    "azure": [
        "gpt-4.1",
        "gpt-4o",
        "gpt-4o-mini",
    ],
    "vertex": [
        "gemini-2.5-pro",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
    ],
    "groq": [
        "llama-3.1-70b-versatile",
        "llama-3.1-8b-instant",
    ],
}


@dataclass
class Config:
    devguard_key: str
    provider: str        # "anthropic" | "openai" | "groq" | "azure" | "vertex"
    llm_key: str
    model: str
    validate_url: str
    model_fallbacks: list[str] = field(default_factory=list)
    # Azure-specific
    azure_endpoint: str | None = None
    azure_api_version: str = "2023-05-15"
    # Vertex AI-specific
    vertex_project: str | None = None
    vertex_location: str = "us-central1"


def load_config(model_override: str | None = None) -> Config:
    devguard_key = os.getenv("DEVGUARD_API_KEY")
    if not devguard_key:
        raise SystemExit(
            "DEVGUARD_API_KEY nao encontrada.\n"
            "Configure: export DEVGUARD_API_KEY=dg_...\n"
            "Obtenha em: https://cleanpredict.com"
        )

    provider = llm_key = None
    azure_endpoint = vertex_project = None

    if key := os.getenv("ANTHROPIC_API_KEY"):
        provider, llm_key = "anthropic", key

    elif (key := os.getenv("AZURE_OPENAI_API_KEY")) and os.getenv("AZURE_OPENAI_ENDPOINT"):
        provider, llm_key = "azure", key
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")

    elif key := os.getenv("OPENAI_API_KEY"):
        provider, llm_key = "openai", key

    elif os.getenv("GOOGLE_APPLICATION_CREDENTIALS") or os.getenv("VERTEX_PROJECT"):
        provider = "vertex"
        llm_key = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "")
        vertex_project = os.getenv("VERTEX_PROJECT")

    elif key := os.getenv("GROQ_API_KEY"):
        provider, llm_key = "groq", key

    else:
        raise SystemExit(
            "Nenhuma API key de LLM encontrada.\n"
            "Configure uma das variaveis:\n"
            "  ANTHROPIC_API_KEY                            -> Claude (recomendado)\n"
            "  AZURE_OPENAI_API_KEY + AZURE_OPENAI_ENDPOINT -> Azure OpenAI\n"
            "  OPENAI_API_KEY                               -> OpenAI\n"
            "  GOOGLE_APPLICATION_CREDENTIALS + VERTEX_PROJECT -> GCP Vertex AI\n"
            "  GROQ_API_KEY                                 -> Groq (mais barato)"
        )

    fallbacks = MODEL_FALLBACKS.get(provider, [])

    # Azure: user pode definir deployment via env var
    if provider == "azure":
        azure_deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
        if azure_deployment:
            fallbacks = [azure_deployment] + [m for m in fallbacks if m != azure_deployment]

    # Vertex: user pode definir modelo via env var
    if provider == "vertex":
        vertex_model = os.getenv("VERTEX_MODEL")
        if vertex_model:
            fallbacks = [vertex_model] + [m for m in fallbacks if m != vertex_model]

    default_model = fallbacks[0] if fallbacks else "gpt-4o"

    return Config(
        devguard_key=devguard_key,
        provider=provider,
        llm_key=llm_key,
        model=model_override or default_model,
        model_fallbacks=fallbacks,
        validate_url=os.getenv("DEVGUARD_VALIDATE_URL", VALIDATE_URL_DEFAULT),
        azure_endpoint=azure_endpoint,
        azure_api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        vertex_project=vertex_project,
        vertex_location=os.getenv("VERTEX_LOCATION", "us-central1"),
    )
