import time
import re

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from .adapter import ModelAdapter
from .tools import execute_tool
from .prompts import AGENT_PROMPTS
from .memory import (
    load_previous_context,
    save_run,
    mark_fixed_since,
    get_stats,
    make_run_id,
)
from .config import Config

console = Console()

# Maps tool calls to analysis phases for UX
PHASE_DETECT = {
    "list_dir": "Reconhecimento",
    "read_file": None,  # detected by context
    "run_command": None,  # detected by command content
    "http_request": "Analise Dinamica",
    "write_file": "Relatorio",
}

COMMAND_PHASES = [
    (r"gitleaks|grep.*(password|secret|api_key|token)", "SAST — Secrets"),
    (r"semgrep", "SAST — Semgrep"),
    (r"pip.audit|safety check", "SAST — Deps Python"),
    (r"npm audit|yarn audit", "SAST — Deps Node"),
    (r"trivy", "SAST — Trivy"),
    (r"nmap", "Analise Dinamica — Nmap"),
    (r"zap", "Analise Dinamica — OWASP ZAP"),
    (r"nuclei", "Analise Dinamica — Nuclei"),
    (r"docker compose up|docker.compose.up", "Analise Dinamica — Subindo servico"),
    (r"docker stop|docker rm|docker.compose.down", "Cleanup"),
    (r"git log|git diff", "Reconhecimento — Git"),
    (r"find \.|ls |cat |head ", "Reconhecimento"),
    (r"which |command -v", "Verificando ferramentas"),
]

READ_PHASES = [
    (r"package\.json|requirements\.txt|go\.mod|pom\.xml|Cargo\.toml|Gemfile", "Reconhecimento — Dependencias"),
    (r"\.env|config|settings", "Reconhecimento — Configs"),
    (r"auth|login|session|jwt|token", "Autenticacao e Autorizacao"),
    (r"docker|compose|Dockerfile", "Reconhecimento — Docker"),
]


def _detect_phase(tc) -> str:
    if tc.name == "list_dir":
        return "Reconhecimento"
    if tc.name == "http_request":
        return "Analise Dinamica"
    if tc.name == "write_file":
        path = tc.inputs.get("path", "")
        if "report" in path.lower():
            return "Gerando Relatorio"
        return "Escrevendo arquivo"

    if tc.name == "run_command":
        cmd = tc.inputs.get("command", "")
        for pattern, phase in COMMAND_PHASES:
            if re.search(pattern, cmd, re.IGNORECASE):
                return phase
        return "Executando comando"

    if tc.name == "read_file":
        path = tc.inputs.get("path", "")
        for pattern, phase in READ_PHASES:
            if re.search(pattern, path, re.IGNORECASE):
                return phase
        return "Lendo codigo"

    return "Analisando"


def _detect_stack(tool_calls_log: list[dict]) -> str:
    """Infer project stack from tool calls seen so far."""
    hints = set()
    for entry in tool_calls_log:
        text = entry.get("command", "") + entry.get("path", "")
        if re.search(r"package\.json|node_modules|npm|yarn|next|react|vue", text, re.IGNORECASE):
            hints.add("Node.js")
        if re.search(r"requirements\.txt|pip|python|django|flask|fastapi|\.py", text, re.IGNORECASE):
            hints.add("Python")
        if re.search(r"Cargo\.toml|\.rs|rust", text, re.IGNORECASE):
            hints.add("Rust")
        if re.search(r"go\.mod|\.go|golang", text, re.IGNORECASE):
            hints.add("Go")
        if re.search(r"pom\.xml|\.java|gradle|spring", text, re.IGNORECASE):
            hints.add("Java")
        if re.search(r"Dockerfile|docker-compose|\.yml", text, re.IGNORECASE):
            hints.add("Docker")
    return " + ".join(sorted(hints)) if hints else "detecting..."


def _print_banner(agent: str, project_path: str, config: Config, stats: dict):
    table = Table.grid(padding=(0, 2))
    table.add_column(style="bold")
    table.add_column()
    table.add_row("Projeto", project_path)
    table.add_row("Modelo", f"cleanpredict-devguard + {config.provider}/{config.model}")
    if stats["total_runs"] > 0:
        table.add_row(
            "Historico",
            f"{stats['total_runs']} analises | "
            f"{stats['open_critical']} criticos abertos | "
            f"{stats['fixed_total']} corrigidos",
        )
    console.print()
    console.print(Panel(table, title=f"[bold]DevGuard[/bold] · Agent {agent.title()}", border_style="cyan"))
    console.print()


def _print_phase_header(phase: str, seen_phases: set):
    if phase not in seen_phases:
        seen_phases.add(phase)
        # Group sub-phases under main phase
        main = phase.split(" — ")[0]
        if main not in seen_phases:
            seen_phases.add(main)
            icon = {
                "Reconhecimento": "1",
                "SAST": "2",
                "Analise Dinamica": "3",
                "Autenticacao e Autorizacao": "4",
                "Gerando Relatorio": "5",
            }.get(main, "*")
            console.print(f"\n  [bold yellow]Fase {icon}[/bold yellow] [bold]{main}[/bold]")


def run_agent(
    agent: str,
    project_path: str,
    config: Config,
    save_report: bool = True,
):
    run_id = make_run_id()
    start_time = time.time()

    stats = get_stats(project_path)
    _print_banner(agent, project_path, config, stats)

    prev_ctx = load_previous_context(project_path)
    base_prompt = AGENT_PROMPTS[agent]
    system_prompt = base_prompt + ("\n\n" + prev_ctx if prev_ctx else "")

    adapter = ModelAdapter(config, system_prompt)

    messages = [
        {
            "role": "user",
            "content": (
                f"Analise o projeto em: {project_path}\n"
                "Execute todas as fases de forma autonoma e completa.\n"
                f"Salve o relatorio em: {project_path}/devguard-report.md"
            ),
        }
    ]

    tool_calls_log: list[dict] = []
    findings_extracted: list[dict] = []
    final_response = None
    iteration = 0
    seen_phases: set[str] = set()
    detected_stack = ""

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Iniciando analise...", total=None)

        while iteration < 50:
            iteration += 1
            progress.update(task, description="[dim]Pensando...[/dim]")

            resp = adapter.call(messages)
            messages.append(adapter.assistant_msg(resp))
            final_response = resp

            # Print intermediate text from LLM (analysis insights)
            if resp.text and not resp.done:
                progress.stop()
                console.print(f"\n  [dim italic]{resp.text[:200]}[/dim italic]")
                progress.start()

            if resp.done:
                break

            results = []
            for tc in resp.tool_calls:
                phase = _detect_phase(tc)
                preview = tc.inputs.get("command", tc.inputs.get("path", ""))[:80]

                # Log for stack detection
                tool_calls_log.append({
                    "command": tc.inputs.get("command", ""),
                    "path": tc.inputs.get("path", ""),
                })
                detected_stack = _detect_stack(tool_calls_log)

                # Show phase transition
                progress.stop()
                _print_phase_header(phase, seen_phases)

                # Show tool execution
                tool_icon = {
                    "run_command": ">>",
                    "read_file": "<<",
                    "list_dir": "[]",
                    "http_request": "<>",
                    "write_file": ">>",
                }.get(tc.name, "  ")
                console.print(f"    [cyan]{tool_icon}[/cyan] [dim]{preview}[/dim]")
                progress.start()

                progress.update(task, description=f"[cyan]{phase}[/cyan] {preview[:40]}")
                result = execute_tool(tc.name, tc.inputs, project_path)
                results.append(result)

            messages.extend(
                adapter.tool_results_msg(resp.tool_calls, results)
            )

    elapsed = time.time() - start_time

    # Persist
    save_run(
        project_path=project_path,
        run_id=run_id,
        model=config.model,
        stack=detected_stack,
        findings=findings_extracted,
    )
    mark_fixed_since(project_path, run_id)

    # Final output
    console.print()
    if final_response and final_response.text:
        console.print(Markdown(final_response.text))

    # Summary
    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)
    time_str = f"{minutes}m {seconds}s" if minutes else f"{seconds}s"

    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="bold")
    summary.add_column()
    summary.add_row("Status", "[green]Analise concluida[/green]")
    summary.add_row("Tempo", time_str)
    summary.add_row("Stack detectada", detected_stack or "desconhecida")
    summary.add_row("Iteracoes LLM", str(iteration))
    summary.add_row("Tool calls", str(len(tool_calls_log)))
    if save_report:
        summary.add_row("Relatorio", f"{project_path}/devguard-report.md")
    summary.add_row("Historico", f"{project_path}/.devguard/devguard.db")

    console.print()
    console.print(Panel(summary, title="[bold green]Resultado[/bold green]", border_style="green"))
