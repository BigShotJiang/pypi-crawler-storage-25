import json
from dataclasses import dataclass, field

from .config import Config
from .tools import TOOLS_SCHEMA, to_openai_schema


@dataclass
class ToolCall:
    id: str
    name: str
    inputs: dict


@dataclass
class ModelResponse:
    tool_calls: list
    text: str | None
    done: bool
    _raw: object = field(default=None, repr=False)


class ModelAdapter:
    def __init__(self, config: Config, system_prompt: str):
        self.config = config
        self.system_prompt = system_prompt

        match config.provider:
            case "anthropic":
                import anthropic
                self._client = anthropic.Anthropic(api_key=config.llm_key)

            case "azure":
                from openai import AzureOpenAI
                self._client = AzureOpenAI(
                    api_key=config.llm_key,
                    azure_endpoint=config.azure_endpoint,
                    api_version=config.azure_api_version,
                )

            case "vertex":
                # Client is created per-call in _vertex_gemini()
                self._client = None

            case "groq":
                from openai import OpenAI
                self._client = OpenAI(
                    api_key=config.llm_key,
                    base_url="https://api.groq.com/openai/v1",
                )

            case _:  # "openai"
                from openai import OpenAI
                self._client = OpenAI(api_key=config.llm_key)

    def call(self, messages: list) -> ModelResponse:
        return self._call_with_fallback(messages)

    def _call_with_fallback(self, messages: list) -> ModelResponse:
        fallbacks = self.config.model_fallbacks
        models_to_try = [self.config.model]
        for m in fallbacks:
            if m != self.config.model:
                models_to_try.append(m)

        last_error = None
        for model in models_to_try:
            self.config.model = model
            try:
                if self.config.provider == "anthropic":
                    return self._anthropic(messages)
                if self.config.provider == "vertex" and self._is_gemini():
                    return self._vertex_gemini(messages)
                return self._openai(messages)
            except Exception as e:
                err_str = str(e).lower()
                is_model_error = any(k in err_str for k in [
                    "model_not_found", "model not found",
                    "does not exist", "not available",
                    "deployment", "invalid_model",
                    "404", "decommissioned",
                ])
                if is_model_error and model != models_to_try[-1]:
                    from rich.console import Console
                    Console().print(
                        f"  [yellow]cleanpredict-devguard: modelo {model} indisponivel, tentando proximo...[/yellow]"
                    )
                    last_error = e
                    continue
                raise
        raise last_error

    def _is_gemini(self) -> bool:
        return "gemini" in self.config.model.lower()

    def _anthropic(self, messages: list) -> ModelResponse:
        raw = self._client.messages.create(
            model=self.config.model,
            max_tokens=8096,
            system=self.system_prompt,
            tools=TOOLS_SCHEMA,
            messages=messages,
        )
        tcs, text = [], None
        for b in raw.content:
            if b.type == "tool_use":
                tcs.append(ToolCall(id=b.id, name=b.name, inputs=b.input))
            elif b.type == "text":
                text = b.text
        return ModelResponse(tcs, text, raw.stop_reason == "end_turn", raw)

    def _openai(self, messages: list) -> ModelResponse:
        sys_msg = [{"role": "system", "content": self.system_prompt}]
        raw = self._client.chat.completions.create(
            model=self.config.model,
            max_tokens=8096,
            tools=to_openai_schema(TOOLS_SCHEMA),
            messages=sys_msg + messages,
        )
        ch = raw.choices[0]
        tcs = []
        if ch.message.tool_calls:
            for tc in ch.message.tool_calls:
                tcs.append(
                    ToolCall(
                        id=tc.id,
                        name=tc.function.name,
                        inputs=json.loads(tc.function.arguments),
                    )
                )
        return ModelResponse(tcs, ch.message.content, ch.finish_reason == "stop", raw)

    def _vertex_gemini(self, messages: list) -> ModelResponse:
        """Vertex AI with Gemini models via google-genai SDK."""
        from google import genai
        from google.genai.types import Tool, FunctionDeclaration

        client = genai.Client(
            vertexai=True,
            project=self.config.vertex_project,
            location=self.config.vertex_location,
        )

        tools = [
            Tool(function_declarations=[
                FunctionDeclaration(
                    name=t["name"],
                    description=t["description"],
                    parameters=t["input_schema"],
                )
                for t in TOOLS_SCHEMA
            ])
        ]

        contents = [{"role": "user", "parts": [{"text": self.system_prompt}]}]
        for msg in messages:
            role = "user" if msg["role"] in ("user", "tool") else "model"

            # Messages already in Gemini format (from assistant_msg / tool_results_msg)
            if "parts" in msg:
                contents.append({"role": role, "parts": msg["parts"]})
            elif isinstance(msg.get("content"), str):
                contents.append({"role": role, "parts": [{"text": msg["content"]}]})
            elif isinstance(msg.get("content"), list):
                parts = []
                for item in msg["content"]:
                    if isinstance(item, dict) and item.get("type") == "tool_result":
                        parts.append({
                            "function_response": {
                                "name": item.get("tool_use_id", "tool"),
                                "response": {"result": item.get("content", "")},
                            }
                        })
                    else:
                        parts.append({"text": str(item)})
                contents.append({"role": role, "parts": parts})

        raw = client.models.generate_content(
            model=self.config.model,
            contents=contents,
            config={"tools": tools},
        )

        tcs, text = [], None

        if not raw.candidates or not raw.candidates[0].content or not raw.candidates[0].content.parts:
            block_reason = getattr(raw, "prompt_feedback", None)
            if not hasattr(self, "_gemini_retries"):
                self._gemini_retries = 0
            self._gemini_retries += 1
            if self._gemini_retries <= 3:
                import time as _time
                wait = self._gemini_retries * 2
                from rich.console import Console as _C
                _C().print(
                    f"  [yellow]cleanpredict-devguard: resposta vazia do Gemini "
                    f"(tentativa {self._gemini_retries}/3, aguardando {wait}s)...[/yellow]"
                )
                _time.sleep(wait)
                return self._vertex_gemini(messages)
            self._gemini_retries = 0
            raise RuntimeError(
                f"cleanpredict-devguard: Gemini retornou resposta vazia apos 3 tentativas "
                f"(possivel content filter). Feedback: {block_reason}"
            )

        self._gemini_retries = 0
        for part in raw.candidates[0].content.parts:
            if hasattr(part, "function_call") and part.function_call:
                fc = part.function_call
                tcs.append(ToolCall(
                    id=fc.name + "_" + str(id(fc)),
                    name=fc.name,
                    inputs=dict(fc.args) if fc.args else {},
                ))
            elif hasattr(part, "text") and part.text:
                text = part.text

        done = len(tcs) == 0 and text is not None
        return ModelResponse(tcs, text, done, raw)

    def assistant_msg(self, resp: ModelResponse) -> dict:
        if self.config.provider == "anthropic":
            return {"role": "assistant", "content": resp._raw.content}
        if self.config.provider == "vertex" and self._is_gemini():
            # Convert SDK Part objects to dicts so they survive re-serialization
            raw_parts = resp._raw.candidates[0].content.parts
            parts = []
            for p in raw_parts:
                if hasattr(p, "function_call") and p.function_call:
                    fc = p.function_call
                    parts.append({
                        "function_call": {
                            "name": fc.name,
                            "args": dict(fc.args) if fc.args else {},
                        }
                    })
                elif hasattr(p, "text") and p.text:
                    parts.append({"text": p.text})
            return {"role": "model", "parts": parts}
        # OpenAI/Azure/Groq: return the message object as-is (SDK expects it)
        msg = resp._raw.choices[0].message
        result = {"role": "assistant", "content": msg.content}
        if msg.tool_calls:
            result["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in msg.tool_calls
            ]
        return result

    def tool_results_msg(self, tcs: list, results: list) -> list:
        if self.config.provider == "anthropic":
            return [
                {
                    "role": "user",
                    "content": [
                        {"type": "tool_result", "tool_use_id": tc.id, "content": r}
                        for tc, r in zip(tcs, results)
                    ],
                }
            ]
        if self.config.provider == "vertex" and self._is_gemini():
            return [
                {
                    "role": "user",
                    "parts": [
                        {
                            "function_response": {
                                "name": tc.name,
                                "response": {"result": r or "(sem output)"},
                            }
                        }
                        for tc, r in zip(tcs, results)
                    ],
                }
            ]
        return [
            {"role": "tool", "tool_call_id": tc.id, "content": r}
            for tc, r in zip(tcs, results)
        ]
