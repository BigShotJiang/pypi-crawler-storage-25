# DevGuard

Autonomous AI security agent for your codebase. Runs offensive and defensive analysis — SAST, secrets detection, dependency audit, dynamic testing, auth review — and delivers a structured report with findings, CVSS scores, and ready-to-apply remediations.

## Install

```bash
pip install cleanpredict-devguard
```

For GCP Vertex AI support:
```bash
pip install cleanpredict-devguard[vertex]
```

## Configuration

DevGuard needs two things: a **license key** and an **LLM provider key**.

### 1. License key

```bash
export DEVGUARD_API_KEY=your-api-key    # get yours at https://cleanpredict.com
```

### 2. LLM provider (choose one)

DevGuard auto-selects the best available model per provider and falls back to cheaper alternatives if unavailable.

**Anthropic (recommended)**
```bash
export ANTHROPIC_API_KEY=sk-ant-...
# Models: claude-sonnet-4 -> claude-3.5-sonnet -> claude-3-haiku
```

**OpenAI**
```bash
export OPENAI_API_KEY=sk-...
# Models: gpt-4.1 -> gpt-4o -> gpt-4o-mini
```

**Azure OpenAI**
```bash
export AZURE_OPENAI_API_KEY=your-key
export AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com
# Optional:
export AZURE_OPENAI_DEPLOYMENT=gpt-4o     # your deployment name
export AZURE_OPENAI_API_VERSION=2023-05-15
# Models: gpt-4.1 -> gpt-4o -> gpt-4o-mini (or your deployment)
```

**GCP Vertex AI**
```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
export VERTEX_PROJECT=my-gcp-project
# Optional:
export VERTEX_LOCATION=us-central1
export VERTEX_MODEL=gemini-2.5-pro
# Models: gemini-2.5-pro -> gemini-2.5-flash -> gemini-2.0-flash
```

**Groq (cheapest)**
```bash
export GROQ_API_KEY=gsk_...
# Models: llama-3.1-70b -> llama-3.1-8b
```

## Usage

```bash
devguard security ./my-project          # full security analysis
devguard security .                     # current directory
devguard security . --model gpt-4o     # force specific model
devguard security . --no-save           # don't save report file
devguard history ./my-project           # view analysis history
devguard version
```

## What it does

DevGuard runs 5 phases autonomously:

| Phase | What runs | Tools used |
|---|---|---|
| 1. Recon | Detect stack, deps, configs, secrets, git history | list_dir, read_file, find, git log |
| 2. SAST | Static analysis, secrets scan, dependency audit | gitleaks, semgrep, pip-audit, npm audit, trivy |
| 3. Dynamic | Port scan, header analysis, vuln scanning | nmap, OWASP ZAP, nuclei, http requests |
| 4. Auth | JWT, cookies, OAuth, RBAC review | Code reading + analysis |
| 5. Report | Structured markdown with CVSS, CWE, remediations | write_file |

Tools are auto-detected. If not installed locally, DevGuard tries Docker. If neither is available, it documents the skipped check.

## Output

Generates `devguard-report.md` in the project root:

```
# DevGuard Security Report
**Project:** my-app | **Date:** 2025-05-18 | **Stack:** Python + Docker

## Executive summary
The project has 2 critical and 3 medium vulnerabilities...

## Critical findings — CVSS >= 7.0
### [CRITICAL] SQL Injection in /api/users
**CVSS:** 9.8 | **CWE:** CWE-89 | **Tool:** semgrep
**Location:** src/routes/users.py:42
**Remediation:** <ready-to-copy fix>

## Medium findings — CVSS 4.0-6.9
...
```

## Memory between runs

DevGuard remembers findings across analyses. On the second run:
- Shows what was **fixed** since last analysis
- Shows what's still **open** (and for how many days)
- Highlights **new** findings

History is stored in `.devguard/devguard.db` (add `.devguard/` to your `.gitignore`).

## Model fallback

If the best model isn't available on your account, DevGuard automatically tries the next one:

```
anthropic:  claude-sonnet-4 → claude-3.5-sonnet → claude-3-haiku
openai:     gpt-4.1 → gpt-4o → gpt-4o-mini
azure:      your-deployment → gpt-4.1 → gpt-4o → gpt-4o-mini
vertex:     gemini-2.5-pro → gemini-2.5-flash → gemini-2.0-flash
groq:       llama-3.1-70b → llama-3.1-8b
```

Override with `--model`:
```bash
devguard security . --model claude-3-haiku-20240307
```
