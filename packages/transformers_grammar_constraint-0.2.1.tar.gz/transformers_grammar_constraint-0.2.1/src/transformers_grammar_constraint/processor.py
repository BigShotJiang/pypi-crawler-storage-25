# src/grammar_constrain/processor.py
"""
GrammarConstrainedLogitsProcessor: enforces grammar constraints during LLM generation.

Integrates with HuggingFace Transformers model.generate() as a LogitsProcessor.
Supports:
    - Any Grammar subclass (or raw Lark grammar string)
    - Batch generation (per-sequence independent parser state)
    - Think-token detection (constraints paused inside <think>...</think>)
    - EOS masking until grammar is complete
    - Dead-end recovery (warns + allows all tokens)
"""

import logging
import warnings
from dataclasses import dataclass
from typing import Any

import torch
import transformers

from transformers_grammar_constraint.grammar import Grammar, LarkGrammar

logger = logging.getLogger(__name__)


def _resolve_token_ids(tokenizer: Any, token_str: str) -> list[int] | None:
    """Resolve a string like '<think>' to a list of token IDs.

    Returns None if the string cannot be encoded (disables think detection).
    """
    try:
        ids = tokenizer.encode(token_str, add_special_tokens=False)
        if not ids:
            return None
        return list(ids)
    except Exception:
        return None


@dataclass
class _SequenceState:
    """Per-sequence mutable state for one beam/batch element."""

    parser_state: Any
    accumulated_text: str = ""
    is_thinking: bool = False


class _InlineGrammar(LarkGrammar):
    """Wraps a raw Lark grammar string as a Grammar instance."""

    def __init__(self, grammar_str: str) -> None:
        self._grammar_str = grammar_str
        super().__init__()

    @property
    def grammar_string(self) -> str:
        return self._grammar_str


class GrammarConstrainedLogitsProcessor(transformers.LogitsProcessor):
    """Constrains token generation to a Lark grammar.

    Pass to model.generate() via logits_processor parameter::

        processor = GrammarConstrainedLogitsProcessor(
            grammar=JsonGrammar(),
            tokenizer=tokenizer,
        )
        output = model.generate(input_ids, logits_processor=[processor])

    Args:
        grammar: A Grammar subclass instance, or a raw Lark grammar string.
        tokenizer: HuggingFace tokenizer.
        think_start_token: Token string marking start of thinking block.
            Constraints are suspended inside thinking blocks.
            Set to None to disable think detection.
        think_end_token: Token string marking end of thinking block.
    """

    def __init__(
        self,
        grammar: Grammar[Any] | str,
        tokenizer: Any,
        think_start_token: str | None = "<think>",
        think_end_token: str | None = "</think>",
    ) -> None:
        if isinstance(grammar, str):
            grammar = _InlineGrammar(grammar)
        self._grammar = grammar
        self._tokenizer = tokenizer

        # Resolve think-token IDs (may be multi-token sequences)
        self._think_start_ids: list[int] | None = None
        self._think_end_ids: list[int] | None = None

        if think_start_token is not None and think_end_token is not None:
            start_ids = _resolve_token_ids(tokenizer, think_start_token)
            end_ids = _resolve_token_ids(tokenizer, think_end_token)
            if start_ids is None or end_ids is None:
                warnings.warn(
                    f"Could not resolve think tokens {think_start_token!r} or "
                    f"{think_end_token!r} via tokenizer. Think detection disabled.",
                    UserWarning,
                    stacklevel=2,
                )
            else:
                self._think_start_ids = start_ids
                self._think_end_ids = end_ids

        # Precompute vocab maps once so get_valid_token_ids never calls decode per token.
        self._vocab: dict[str, int] = tokenizer.get_vocab()
        self._decoded_vocab: dict[int, str] = {
            token_id: tokenizer.decode([token_id]) for token_id in self._vocab.values()
        }

        # Per-sequence state: initialized lazily on first __call__
        self._seq_states: list[_SequenceState] | None = None
        self._prev_input_len: int = 0

    def _init_states(self, batch_size: int) -> None:
        self._seq_states = [
            _SequenceState(parser_state=self._grammar.fresh_state())
            for _ in range(batch_size)
        ]

    def _check_think_tokens(
        self, new_token_ids: list[int], state: _SequenceState
    ) -> None:
        """Update state.is_thinking based on new tokens, using sliding window match."""
        if self._think_start_ids is None:
            return
        assert self._think_end_ids is not None

        # Slide over new_token_ids looking for think delimiters
        window_size = max(len(self._think_start_ids), len(self._think_end_ids))
        for i in range(len(new_token_ids)):
            window = new_token_ids[max(0, i - window_size + 1) : i + 1]

            if not state.is_thinking:
                # Check for <think> start
                if len(window) >= len(self._think_start_ids):
                    tail = window[-len(self._think_start_ids) :]
                    if tail == self._think_start_ids:
                        state.is_thinking = True
            else:
                # Check for </think> end
                if len(window) >= len(self._think_end_ids):
                    tail = window[-len(self._think_end_ids) :]
                    if tail == self._think_end_ids:
                        state.is_thinking = False

    def __call__(
        self,
        input_ids: torch.Tensor,
        scores: torch.Tensor,
    ) -> torch.Tensor:
        batch_size = input_ids.shape[0]

        # Lazy initialization on first call
        if self._seq_states is None:
            self._init_states(batch_size)
            assert self._seq_states is not None
            self._prev_input_len = input_ids.shape[1]
            # Check all existing tokens for think-token state (prompt may contain think tokens)
            for seq_idx in range(batch_size):
                state = self._seq_states[seq_idx]
                all_token_ids = input_ids[seq_idx].tolist()
                self._check_think_tokens(all_token_ids, state)
            return self._apply_constraints(input_ids, scores)

        # Determine newly generated tokens since last call
        current_len = input_ids.shape[1]
        new_tokens_start = self._prev_input_len
        self._prev_input_len = current_len

        for seq_idx in range(batch_size):
            state = self._seq_states[seq_idx]
            new_token_ids = input_ids[seq_idx, new_tokens_start:].tolist()

            # Update think-token state
            self._check_think_tokens(new_token_ids, state)

            if state.is_thinking:
                continue

            # Advance grammar state with newly generated text
            new_text = self._tokenizer.decode(new_token_ids, skip_special_tokens=False)
            if new_text:
                new_state = self._grammar._make_state(state.accumulated_text + new_text)
                if new_state is not None:
                    state.accumulated_text += new_text
                    state.parser_state = new_state
                elif self._grammar._is_partial_terminal_extension(
                    state.parser_state, new_text
                ):
                    # Token is only part of a multi-char string terminal.
                    # Advance accumulated text but keep the LALR parser state;
                    # update the partial prefix so the next constraint call knows
                    # how far into the terminal we are.
                    state.accumulated_text += new_text
                    state.parser_state.partial_prefix = (
                        state.parser_state.partial_prefix + new_text
                    )
                else:
                    logger.warning(
                        "Token %r (decoded: %r) did not match grammar at accumulated text %r. "
                        "Grammar state not advanced — subsequent constraints may be incorrect.",
                        new_token_ids,
                        new_text,
                        state.accumulated_text,
                    )

        return self._apply_constraints(input_ids, scores)

    def _apply_constraints(
        self,
        input_ids: torch.Tensor,
        scores: torch.Tensor,
    ) -> torch.Tensor:
        batch_size = scores.shape[0]
        result = scores.clone()
        assert self._seq_states is not None

        for seq_idx in range(batch_size):
            state = self._seq_states[seq_idx]

            if state.is_thinking:
                continue  # No constraints during thinking

            valid_ids = self._grammar.get_valid_token_ids(
                state.parser_state,
                self._tokenizer,
                vocab=self._vocab,
                decoded_vocab=self._decoded_vocab,
            )

            if not valid_ids:
                # Dead end — already logged by Grammar; allow all tokens
                continue

            # Mask all tokens not in valid_ids (vectorized)
            mask = torch.ones(scores.shape[1], dtype=torch.bool, device=scores.device)
            valid_list = [tid for tid in valid_ids if tid < mask.shape[0]]
            if valid_list:
                mask[
                    torch.tensor(valid_list, dtype=torch.long, device=scores.device)
                ] = False
            result[seq_idx][mask] = float("-inf")

        return result
