# src/grammar_constrain/__init__.py
from transformers_grammar_constraint import (
    compat as _compat,  # noqa: F401 — applies shim at import time
)
from transformers_grammar_constraint.grammar import Grammar, LarkGrammar
from transformers_grammar_constraint.grammars import JsonGrammar, PgnGrammar, SanGrammar
from transformers_grammar_constraint.processor import GrammarConstrainedLogitsProcessor

__all__ = [
    "Grammar",
    "LarkGrammar",
    "GrammarConstrainedLogitsProcessor",
    "JsonGrammar",
    "SanGrammar",
    "PgnGrammar",
]
