# src/grammar_constrain/compat.py
"""
Compatibility shim for transformers 4.x/5.x.

In transformers 4.x, LogitsWarper was a separate base class.
In 5.x it was removed; warper-style processors now subclass LogitsProcessor directly.
This module patches the missing name so user code importing LogitsWarper still works.
"""

import transformers

if not hasattr(transformers, "LogitsWarper"):
    setattr(transformers, "LogitsWarper", transformers.LogitsProcessor)
