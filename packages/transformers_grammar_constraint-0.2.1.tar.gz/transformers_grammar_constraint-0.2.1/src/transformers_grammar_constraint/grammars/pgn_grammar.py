# src/grammar_constrain/grammars/pgn_grammar.py
"""
PgnGrammar: constrain LLM output to a PGN-style chess move list
(e.g., "1. e4 e5 2. Nf3 Nc6 1-0").

Implemented as a hand-crafted character-level DFA.  Reuses the SAN DFA
(from san_grammar) for move bodies — white moves keep the original SAN
state IDs, black moves reuse them offset by _PGN_BLACK — and adds
structural states for move numbers, dots, spaces, and game results.
"""

from transformers_grammar_constraint.grammars.san_grammar import (
    _S_CASTLE_O1,
    _S_PAWN_FILE,
    _S_PIECE_START,
    DEAD,
    SAN_ACCEPTING,
    SAN_START,
    _DfaGrammarBase,
    _DfaMachine,
    san_transitions,
)

# PGN black-context offset: black SAN state = white SAN state + _PGN_BLACK
_PGN_BLACK = 50

# PGN structural states
_P_INIT = 100
_P_MOVE_BODY = 101
_P_DOT = 102
_P_AFTER_WHITE = 103
_P_AFTER_BLACK = 104

_P_R1 = 110
_P_R1D = 111
_P_R10 = 112  # accepting
_P_R0 = 113
_P_R0D = 114
_P_R01 = 115  # accepting
_P_HALF1 = 116
_P_HALF2 = 117
_P_HALFD = 118
_P_HALF1A = 119
_P_HALF1S = 120
_P_HALF = 121  # accepting
_P_STAR = 122  # accepting

_PGN_STRUCTURAL_ACCEPTING: frozenset[int] = frozenset(
    {
        _P_R10,
        _P_R01,
        _P_HALF,
        _P_STAR,
    }
)

_FILES = frozenset("abcdefgh")
_PIECES = frozenset("KQRBN")


def _pgn_transitions(
    san_t: dict[int, dict[str, int]],
) -> dict[int, dict[str, int]]:
    """Build the PGN DFA transition table.

    Reuses SAN state IDs 0–21 for white-context moves; black-context moves
    use the same state IDs offset by _PGN_BLACK (50).  PGN structural states
    (100–122) handle move numbers, dots, spaces, and result strings.
    """
    t: dict[int, dict[str, int]] = {}

    # ── White SAN states (IDs 0–21) ──────────────────────────────────────────
    # Same transitions as SAN, but accepting states also accept " " → _P_AFTER_WHITE.
    for sid, trans in san_t.items():
        t[sid] = dict(trans)
        if sid in SAN_ACCEPTING:
            t[sid][" "] = _P_AFTER_WHITE

    # ── Black SAN states (IDs 50–71) ─────────────────────────────────────────
    # Identical structure, offset by _PGN_BLACK.  Accepting states accept " " → _P_AFTER_BLACK.
    for sid, trans in san_t.items():
        bsid = sid + _PGN_BLACK
        t[bsid] = {
            ch: (dest + _PGN_BLACK if dest >= 0 else DEAD) for ch, dest in trans.items()
        }
        if sid in SAN_ACCEPTING:
            t[bsid][" "] = _P_AFTER_BLACK

    # ── PGN structural states ─────────────────────────────────────────────────

    # _P_INIT: start of PGN — expects first digit of move number
    # "1" is special: could be move number "1." or result "1-0" / "1/2-1/2"
    t[_P_INIT] = {
        "1": _P_R1,
        **{c: _P_MOVE_BODY for c in "23456789"},
    }

    # _P_MOVE_BODY: reading move-number digits (multi-digit numbers like 10, 11, ...)
    t[_P_MOVE_BODY] = {
        **{c: _P_MOVE_BODY for c in "0123456789"},
        ".": _P_DOT,
    }

    # _P_DOT: seen "." — a space leads to white SAN start (SAN_START = 0)
    t[_P_DOT] = {" ": SAN_START}

    # _P_AFTER_WHITE: space after white move consumed
    # Expect: black SAN start chars, or result prefix
    t[_P_AFTER_WHITE] = {
        **{c: _S_PAWN_FILE + _PGN_BLACK for c in _FILES},
        **{c: _S_PIECE_START + _PGN_BLACK for c in _PIECES},
        "O": _S_CASTLE_O1 + _PGN_BLACK,
        "1": _P_R1,
        "0": _P_R0,
        "*": _P_STAR,
    }

    # _P_AFTER_BLACK: space after black move consumed
    # Expect: next move number or result prefix (no SAN here)
    t[_P_AFTER_BLACK] = {
        "1": _P_R1,
        **{c: _P_MOVE_BODY for c in "23456789"},
        "0": _P_R0,
        "*": _P_STAR,
    }

    # ── Result disambiguation states ──────────────────────────────────────────

    # _P_R1: seen "1" — could be move "1." or "10." / "11." or result "1-0" / "1/2-1/2"
    t[_P_R1] = {
        ".": _P_DOT,
        **{c: _P_MOVE_BODY for c in "0123456789"},
        "-": _P_R1D,
        "/": _P_HALF1,
    }
    t[_P_R1D] = {"0": _P_R10}
    t[_P_R10] = {}  # "1-0" — accepting, no further transitions

    t[_P_R0] = {"-": _P_R0D}
    t[_P_R0D] = {"1": _P_R01}
    t[_P_R01] = {}  # "0-1" — accepting

    # "1/2-1/2" path
    t[_P_HALF1] = {"2": _P_HALF2}  # "1/"  → "1/2"
    t[_P_HALF2] = {"-": _P_HALFD}  # "1/2" → "1/2-"
    t[_P_HALFD] = {"1": _P_HALF1A}  # "1/2-"→ "1/2-1"
    t[_P_HALF1A] = {"/": _P_HALF1S}  # "1/2-1" → "1/2-1/"
    t[_P_HALF1S] = {"2": _P_HALF}  # "1/2-1/" → "1/2-1/2"
    t[_P_HALF] = {}  # accepting

    t[_P_STAR] = {}  # "*" — accepting

    return t


_PGN_REFERENCE_GRAMMAR = r"""
// Reference Lark grammar — not used at runtime (lark_parser = "none").
// PgnGrammar is driven by a hand-crafted character-level DFA that embeds
// the SAN DFA for white and black move bodies.
start: move_pair+ result?

move_pair: MOVE_NUMBER "." move move?

move: castling
    | piece_move
    | pawn_move

castling: "O-O-O" check?
        | "O-O" check?

piece_move: PIECE file? rank? capture? square promotion? check?

pawn_move: file capture square promotion? check?
         | square promotion? check?

capture: "x"
promotion: "=" PROMOTE_PIECE
check: "+" | "#"
result: "1-0" | "0-1" | "1/2-1/2" | "*"

PIECE: "K" | "Q" | "R" | "B" | "N"
PROMOTE_PIECE: "Q" | "R" | "B" | "N"
square: /[a-h]/ /[1-8]/
file: /[a-h]/
rank: /[1-8]/
MOVE_NUMBER: /[1-9][0-9]*/

%import common.WS
%ignore WS
"""


class PgnGrammar(_DfaGrammarBase):
    """Constrain generation to a PGN-style chess move list.

    Uses a hand-coded character-level DFA that embeds the SAN DFA for
    individual move bodies and layers structural states for move numbers,
    spacing, and game results.

    Example::

        grammar = PgnGrammar()
        # Valid: "1. e4 e5 2. Nf3 Nc6 1-0"
    """

    _grammar_string = _PGN_REFERENCE_GRAMMAR

    def __init__(self) -> None:
        san_t = san_transitions()
        accepting = (
            SAN_ACCEPTING
            | frozenset(s + _PGN_BLACK for s in SAN_ACCEPTING)
            | _PGN_STRUCTURAL_ACCEPTING
        )
        self._machine = _DfaMachine(
            transitions=_pgn_transitions(san_t),
            accepting=accepting,
            initial_state=_P_INIT,
        )
        super().__init__()
