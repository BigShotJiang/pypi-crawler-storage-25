# src/grammar_constrain/grammars/json_grammar.py
"""
JsonGrammar: constrain LLM output to valid JSON, optionally tightened by a JSON Schema.

Supported JSON Schema keywords: type, properties, items, enum, additionalProperties,
required (enforced via fixed alphabetical key order), nested schemas.

Unsupported (warns and ignores): oneOf, anyOf, allOf, $ref, pattern,
minLength, maxLength, minimum, maximum.
"""

import warnings
from typing import Any

from transformers_grammar_constraint.grammar import LarkGrammar as Grammar

_UNSUPPORTED_KEYWORDS = {
    "oneOf",
    "anyOf",
    "allOf",
    "$ref",
    "pattern",
    "minLength",
    "maxLength",
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "minItems",
}

_BASE_JSON_GRAMMAR = r"""
start: value

value: object
     | array
     | string
     | number
     | "true"
     | "false"
     | "null"

object: "{" [pair ("," pair)*] "}"
pair: string ":" value

array: "[" [value ("," value)*] "]"

string: ESCAPED_STRING
number: SIGNED_NUMBER

%import common.ESCAPED_STRING
%import common.SIGNED_NUMBER
%import common.WS
%ignore WS
"""


def _warn_unsupported(schema: dict) -> None:
    for key in _UNSUPPORTED_KEYWORDS:
        if key in schema:
            warnings.warn(
                f"JSON Schema keyword {key!r} is not supported by JsonGrammar v1 and will be ignored.",
                UserWarning,
                stacklevel=3,
            )


def _sanitize_rule_name(name: str, depth: int) -> str:
    """Convert a property name to a safe Lark rule name component.

    Replaces non-alphanumeric characters with underscores and appends depth
    to prevent collisions between names like 'foo_bar' and nested 'foo' -> 'bar'.
    """
    safe = "".join(c if c.isalnum() else "_" for c in name)
    return f"{safe}_d{depth}"


def _schema_to_value_rule(
    schema: dict, rule_name: str, rules: list[str], depth: int = 0
) -> str:
    """Recursively convert a JSON Schema dict into a Lark rule reference.

    Appends new rules to `rules` list. Returns the rule name to use as a reference.
    """
    _warn_unsupported(schema)
    schema_type = schema.get("type")

    if "enum" in schema:
        # JSON string enum values must be JSON-quoted in the grammar.
        # In Lark, a literal double-quote inside a string terminal is written as \"
        # Python f-string: f'"\\"{v}\\""' produces the Lark terminal "\"value\""
        def _enum_literal(v) -> str:
            if isinstance(v, str):
                return f'"\\"{v}\\""'  # JSON-quoted string: matches "red" in input
            elif isinstance(v, bool):
                return f'"{str(v).lower()}"'  # "true" or "false"
            else:
                return f'"{v}"'  # number: matches bare digits

        literals = " | ".join(_enum_literal(v) for v in schema["enum"])
        rules.append(f"{rule_name}: {literals}")
        return rule_name

    if schema_type == "object":
        return _object_schema_to_rule(schema, rule_name, rules, depth)
    elif schema_type == "array":
        return _array_schema_to_rule(schema, rule_name, rules, depth)
    elif schema_type == "string":
        rules.append(f"{rule_name}: ESCAPED_STRING")
        return rule_name
    elif schema_type == "number" or schema_type == "integer":
        rules.append(f"{rule_name}: JSON_NUMBER")
        return rule_name
    elif schema_type == "boolean":
        rules.append(f'{rule_name}: "true" | "false"')
        return rule_name
    elif schema_type == "null":
        rules.append(f'{rule_name}: "null"')
        return rule_name
    else:
        # Unknown/no type — fall back to any JSON value
        rules.append(f"{rule_name}: value")
        return rule_name


def _object_schema_to_rule(
    schema: dict, rule_name: str, rules: list[str], depth: int = 0
) -> str:
    properties: dict = schema.get("properties", {})
    required: list[str] = sorted(schema.get("required", []))  # alphabetical
    # additionalProperties: False means no keys beyond declared properties
    additional_props_val = schema.get("additionalProperties", True)
    allow_additional = additional_props_val is not False

    if not properties:
        # No properties defined — any object
        rules.append(f'{rule_name}: "{{" [pair ("," pair)*] "}}"')
        return rule_name

    # Build per-property value rules.
    # Key quoting: JSON keys are quoted strings. In Lark, to match the literal
    # text `"name"` (with double quotes) use the single terminal `"\"name\""`.
    # Python f-string: f'"\\"{prop_name}\\""' produces the correct Lark terminal.
    pair_rules = []
    for prop_name, prop_schema in properties.items():
        safe_name = _sanitize_rule_name(prop_name, depth)
        prop_rule_name = f"{rule_name}_{safe_name}_val"
        _schema_to_value_rule(prop_schema, prop_rule_name, rules, depth + 1)
        # Lark terminal for the JSON key: "\"prop_name\""
        key_terminal = f'"\\"{prop_name}\\""'
        pair_rules.append((prop_name, prop_rule_name, key_terminal))

    # required is already sorted alphabetically. Build required_pairs in that
    # order by looking up from the pair_rules dict — NOT by filtering pair_rules
    # (which follows `properties` declaration order, not alphabetical order).
    required_set = set(required)
    pair_rules_by_name = {n: (r, k) for n, r, k in pair_rules}
    required_pairs = [
        (n, *pair_rules_by_name[n]) for n in required if n in pair_rules_by_name
    ]
    optional_pairs = [(n, r, k) for n, r, k in pair_rules if n not in required_set]

    def pair_fragment(key_terminal: str, prop_rule: str) -> str:
        return f'{key_terminal} ":" {prop_rule}'

    parts = [pair_fragment(k, r) for _, r, k in required_pairs]

    if not parts and not optional_pairs:
        rules.append(f'{rule_name}: "{{" "}}"')
    elif allow_additional:
        if optional_pairs:
            opt_alternatives = " | ".join(
                f"({pair_fragment(k, r)})" for _, r, k in optional_pairs
            )
            opt_group = f"({opt_alternatives})"
            if parts:
                inner = ' "," '.join(f"({p})" for p in parts)
                full = f'"{{" {inner} ("," {opt_group})* "}}"'
            else:
                full = f'"{{" ({opt_group} ("," {opt_group})*)? "}}"'
            rules.append(f"{rule_name}: {full}")
        else:
            inner = ' "," '.join(f"({p})" for p in parts)
            rules.append(f'{rule_name}: "{{" {inner} "}}"')
    else:
        # not allow_additional: only declared properties permitted
        if parts:
            if optional_pairs:
                opt_alternatives = " | ".join(
                    f"({pair_fragment(k, r)})" for _, r, k in optional_pairs
                )
                opt_group = f"({opt_alternatives})"
                inner = ' "," '.join(f"({p})" for p in parts)
                full = f'"{{" {inner} ("," {opt_group})* "}}"'
                rules.append(f"{rule_name}: {full}")
            else:
                inner = ' "," '.join(f"({p})" for p in parts)
                rules.append(f'{rule_name}: "{{" {inner} "}}"')
        else:
            # Only optional declared props; no additional allowed
            opt_alternatives = " | ".join(
                f"({pair_fragment(k, r)})" for _, r, k in optional_pairs
            )
            opt_group = f"({opt_alternatives})"
            rules.append(f'{rule_name}: "{{" ({opt_group} ("," {opt_group})*)? "}}"')

    return rule_name


def _array_schema_to_rule(
    schema: dict, rule_name: str, rules: list[str], depth: int = 0
) -> str:
    items_schema = schema.get("items")
    max_items = schema.get("maxItems")

    if items_schema is None:
        if max_items is None:
            rules.append(f'{rule_name}: "[" [value ("," value)*] "]"')
        else:
            extra = f' ("," value) ~ 0..{max_items - 1}' if max_items > 1 else ""
            rules.append(f'{rule_name}: "[" [value{extra}] "]"')
        return rule_name

    item_rule_name = f"{rule_name}_item_d{depth}"
    _schema_to_value_rule(items_schema, item_rule_name, rules, depth + 1)
    if max_items is None:
        rules.append(f'{rule_name}: "[" [{item_rule_name} ("," {item_rule_name})*] "]"')
    else:
        extra = f' ("," {item_rule_name}) ~ 0..{max_items - 1}' if max_items > 1 else ""
        rules.append(f'{rule_name}: "[" [{item_rule_name}{extra}] "]"')
    return rule_name


class JsonGrammar(Grammar):
    """Constrain generation to valid JSON, optionally tightened by a JSON Schema.

    Args:
        schema: Optional JSON Schema dict. Supported keywords: type, properties,
                items, enum, additionalProperties, required (alphabetical order),
                nested schemas. Unknown keywords produce a UserWarning.

    Example::

        # Any JSON
        g = JsonGrammar()

        # JSON matching a schema
        g = JsonGrammar(schema={
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        })
    """

    def __init__(self, schema: dict[str, Any] | None = None) -> None:
        self._schema = schema
        super().__init__()

    @property
    def grammar_string(self) -> str:
        if self._schema is None:
            return _BASE_JSON_GRAMMAR

        rules: list[str] = []
        top_rule = "schema_value"
        _schema_to_value_rule(self._schema, top_rule, rules, depth=0)

        extra = "\n".join(rules)
        return f"""
start: {top_rule}

{extra}

object: "{{" [pair ("," pair)*] "}}"
pair: string ":" value

array: "[" [value ("," value)*] "]"
value: object | array | string | number | "true" | "false" | "null"
string: ESCAPED_STRING
number: JSON_NUMBER

%import common.ESCAPED_STRING
%import common.WS
%ignore WS
JSON_NUMBER: /-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+\\-]?[0-9]+)?/
"""
