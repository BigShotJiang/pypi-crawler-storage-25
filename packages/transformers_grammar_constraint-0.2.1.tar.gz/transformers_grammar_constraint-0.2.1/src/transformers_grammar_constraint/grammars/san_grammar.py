# src/grammar_constrain/grammars/san_grammar.py
"""
SanGrammar: constrain LLM output to a single Standard Algebraic Notation
(SAN) chess move (e.g., "Nf3", "e4", "O-O", "Rxe5+", "Nbd2").

Implemented as a hand-crafted character-level DFA rather than a Lark grammar:
SAN disambiguation (e.g. Nbd2, R1e2) is ambiguous for LALR(1) because the
optional file/rank before the destination square starts with the same
characters as the square itself.
"""

from dataclasses import dataclass
from typing import Any

from transformers_grammar_constraint.grammar import Grammar

# ── DFA state constants ────────────────────────────────────────────────────────

DEAD = -1

_S_START = 0
_S_CASTLE_O1 = 1
_S_CASTLE_O_DASH = 2
_S_CASTLE_OO = 3  # accepting
_S_CASTLE_OO_DASH = 4
_S_CASTLE_OOO = 5  # accepting
_S_PAWN_FILE = 6
_S_PAWN_DEST_RANK = 7  # accepting
_S_PAWN_CAP_X = 8
_S_PAWN_CAP_DEST_FILE = 9
_S_PROMO_EQ = 10
_S_PROMO_DONE = 11  # accepting
_S_PIECE_START = 12
_S_PIECE_SEEN_FILE = 13
_S_PIECE_SEEN_RANK = 14
_S_PIECE_SEEN_X = 15
_S_PIECE_SEEN_FILE_RANK = 16  # accepting
_S_PIECE_SEEN_FILE_X = 17
_S_PIECE_SEEN_FILE_RANK_X = 18
_S_PIECE_DEST_FILE = 19
_S_PIECE_DONE = 20  # accepting
_S_CHECK = 21  # accepting

SAN_ACCEPTING: frozenset[int] = frozenset(
    {
        _S_CASTLE_OO,
        _S_CASTLE_OOO,
        _S_PAWN_DEST_RANK,
        _S_PROMO_DONE,
        _S_PIECE_SEEN_FILE_RANK,
        _S_PIECE_DONE,
        _S_CHECK,
    }
)

SAN_START = _S_START

_FILES = frozenset("abcdefgh")
_RANKS = frozenset("12345678")
_PIECES = frozenset("KQRBN")
_PROMO = frozenset("QRBN")
_CHECK_CHARS = frozenset("+#")


def san_transitions() -> dict[int, dict[str, int]]:
    """Build the SAN DFA transition table.

    Returns a dict mapping state_id → {char: next_state_id}.
    Missing entries are implicitly DEAD.
    """
    t: dict[int, dict[str, int]] = {}

    t[_S_START] = {
        "O": _S_CASTLE_O1,
        **{c: _S_PAWN_FILE for c in _FILES},
        **{c: _S_PIECE_START for c in _PIECES},
    }

    # Castling
    t[_S_CASTLE_O1] = {"-": _S_CASTLE_O_DASH}
    t[_S_CASTLE_O_DASH] = {"O": _S_CASTLE_OO}
    t[_S_CASTLE_OO] = {"-": _S_CASTLE_OO_DASH, **{c: _S_CHECK for c in _CHECK_CHARS}}
    t[_S_CASTLE_OO_DASH] = {"O": _S_CASTLE_OOO}
    t[_S_CASTLE_OOO] = {c: _S_CHECK for c in _CHECK_CHARS}

    # Pawn push / capture / promotion
    t[_S_PAWN_FILE] = {"x": _S_PAWN_CAP_X, **{c: _S_PAWN_DEST_RANK for c in _RANKS}}
    t[_S_PAWN_DEST_RANK] = {"=": _S_PROMO_EQ, **{c: _S_CHECK for c in _CHECK_CHARS}}
    t[_S_PAWN_CAP_X] = {c: _S_PAWN_CAP_DEST_FILE for c in _FILES}
    t[_S_PAWN_CAP_DEST_FILE] = {c: _S_PAWN_DEST_RANK for c in _RANKS}
    t[_S_PROMO_EQ] = {c: _S_PROMO_DONE for c in _PROMO}
    t[_S_PROMO_DONE] = {c: _S_CHECK for c in _CHECK_CHARS}

    # Piece moves (with optional file/rank/both disambiguation)
    t[_S_PIECE_START] = {
        **{c: _S_PIECE_SEEN_FILE for c in _FILES},
        **{c: _S_PIECE_SEEN_RANK for c in _RANKS},
        "x": _S_PIECE_SEEN_X,
    }
    t[_S_PIECE_SEEN_FILE] = {
        **{c: _S_PIECE_SEEN_FILE_RANK for c in _RANKS},
        **{c: _S_PIECE_DEST_FILE for c in _FILES},
        "x": _S_PIECE_SEEN_FILE_X,
    }
    t[_S_PIECE_SEEN_RANK] = {
        **{c: _S_PIECE_DEST_FILE for c in _FILES},
        "x": _S_PIECE_SEEN_X,
    }
    t[_S_PIECE_SEEN_X] = {c: _S_PIECE_DEST_FILE for c in _FILES}
    t[_S_PIECE_SEEN_FILE_RANK] = {
        **{c: _S_PIECE_DEST_FILE for c in _FILES},
        "x": _S_PIECE_SEEN_FILE_RANK_X,
        **{c: _S_CHECK for c in _CHECK_CHARS},
    }
    t[_S_PIECE_SEEN_FILE_X] = {c: _S_PIECE_DEST_FILE for c in _FILES}
    t[_S_PIECE_SEEN_FILE_RANK_X] = {c: _S_PIECE_DEST_FILE for c in _FILES}
    t[_S_PIECE_DEST_FILE] = {c: _S_PIECE_DONE for c in _RANKS}
    t[_S_PIECE_DONE] = {c: _S_CHECK for c in _CHECK_CHARS}
    t[_S_CHECK] = {}

    return t


@dataclass
class _DfaState:
    """DFA parser state for SAN/PGN grammars."""

    state_id: int
    text: str = ""


class _DfaMachine:
    """Character-level DFA runtime shared by SAN and PGN grammars."""

    def __init__(
        self,
        transitions: dict[int, dict[str, int]],
        accepting: frozenset[int],
        initial_state: int,
    ) -> None:
        self._transitions = transitions
        self._accepting = accepting
        self.initial_state = initial_state
        self._valid_next: dict[int, frozenset[str]] = {
            sid: frozenset(trans.keys()) for sid, trans in transitions.items()
        }

    def advance(self, state_id: int, char: str) -> int:
        trans = self._transitions.get(state_id)
        if trans is None:
            return DEAD
        return trans.get(char, DEAD)

    def is_accepting(self, state_id: int) -> bool:
        return state_id in self._accepting

    def valid_next_chars(self, state_id: int) -> frozenset[str]:
        return self._valid_next.get(state_id, frozenset())


class _DfaGrammarBase(Grammar[_DfaState]):
    """Shared Grammar machinery for DFA-backed grammars."""

    lark_parser = "none"
    _machine: _DfaMachine
    _grammar_string: str = ""

    def __init__(self) -> None:
        super().__init__()  # returns early — no Lark construction
        self._cache: dict[tuple, frozenset[int]] = {}

    @property
    def grammar_string(self) -> str:
        return self._grammar_string

    def fresh_state(self) -> _DfaState:
        return _DfaState(state_id=self._machine.initial_state)

    def advance_state(self, state: _DfaState, text: str) -> _DfaState:
        cur = state.state_id
        for ch in text:
            cur = self._machine.advance(cur, ch)
            if cur == DEAD:
                raise ValueError(
                    f"Text {text!r} is not a valid continuation for this grammar state"
                )
        return _DfaState(state_id=cur, text=state.text + text)

    def _state_key(self, state: _DfaState) -> tuple:
        return (state.state_id,)

    def _make_state(self, text: str) -> _DfaState | None:
        cur = self._machine.initial_state
        for ch in text:
            cur = self._machine.advance(cur, ch)
            if cur == DEAD:
                return None
        return _DfaState(state_id=cur, text=text)

    def _is_accepting(self, state: _DfaState) -> bool:
        return self._machine.is_accepting(state.state_id)

    def _is_partial_terminal_extension(self, state: _DfaState, new_text: str) -> bool:
        return False  # DFA handles partial tokens natively

    def get_valid_token_ids(
        self,
        state: _DfaState,
        tokenizer: Any,
        *,
        vocab: dict[str, int] | None = None,
        decoded_vocab: dict[int, str] | None = None,
    ) -> frozenset[int]:
        state_key = self._state_key(state)
        if state_key in self._cache:
            return self._cache[state_key]

        valid_first = self._machine.valid_next_chars(state.state_id)
        _vocab: dict[str, int] = vocab if vocab is not None else tokenizer.get_vocab()
        valid_ids: set[int] = set()

        for token_str, token_id in _vocab.items():
            if not token_str:
                continue
            decoded = (
                decoded_vocab[token_id]
                if decoded_vocab is not None
                else tokenizer.decode([token_id])
            )
            if not decoded:
                continue
            if decoded[0] not in valid_first:
                continue
            cur = state.state_id
            for ch in decoded:
                cur = self._machine.advance(cur, ch)
                if cur == DEAD:
                    break
            else:
                valid_ids.add(token_id)

        if self._is_accepting(state) and hasattr(tokenizer, "eos_token_id"):
            eos_id = tokenizer.eos_token_id
            if eos_id is not None:
                valid_ids.add(eos_id)

        if not valid_ids:
            import logging

            logging.getLogger(__name__).warning(
                "Grammar reached a dead end: no valid tokens. "
                "Allowing all tokens to prevent hanging generation."
            )
            result = frozenset(_vocab.values())
        else:
            result = frozenset(valid_ids)

        self._cache[state_key] = result
        return result

    def is_valid_complete(self, text: str) -> bool:
        cur = self._machine.initial_state
        for ch in text:
            cur = self._machine.advance(cur, ch)
            if cur == DEAD:
                return False
        return self._machine.is_accepting(cur)


_SAN_REFERENCE_GRAMMAR = r"""
// Reference Lark grammar — not used at runtime (lark_parser = "none").
// SanGrammar is driven by a hand-crafted character-level DFA because
// SAN disambiguation (Nbd2, R1e2) is ambiguous for LALR(1).
start: move

move: castling
    | piece_move
    | pawn_move

castling: "O-O-O" check?
        | "O-O" check?

piece_move: PIECE file? rank? capture? square promotion? check?

pawn_move: file capture square promotion? check?
         | square promotion? check?

capture: "x"
promotion: "=" PROMOTE_PIECE
check: "+" | "#"

PIECE: "K" | "Q" | "R" | "B" | "N"
PROMOTE_PIECE: "Q" | "R" | "B" | "N"
square: /[a-h]/ /[1-8]/
file: /[a-h]/
rank: /[1-8]/
"""


class SanGrammar(_DfaGrammarBase):
    """Constrain generation to a single SAN chess move.

    Uses a hand-coded character-level DFA instead of Lark/Earley.
    SAN disambiguation (e.g. Nbd2, R1e2) is handled natively by the DFA.

    Example::

        grammar = SanGrammar()
        # Valid: "e4", "Nf3", "Rxe5+", "O-O", "e8=Q#", "Nbd2"
    """

    _grammar_string = _SAN_REFERENCE_GRAMMAR

    def __init__(self) -> None:
        self._machine = _DfaMachine(
            transitions=san_transitions(),
            accepting=SAN_ACCEPTING,
            initial_state=SAN_START,
        )
        super().__init__()
