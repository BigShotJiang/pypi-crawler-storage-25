"""PredaCore shared utilities."""
