from __future__ import annotations

from collections.abc import Callable
from enum import StrEnum
from enum import auto as _auto
from typing import cast

auto = cast(Callable[[], str], _auto)


class StrEnumUpper(StrEnum):
    """ """

    @staticmethod
    def _generate_next_value_(name: str, start, count, last_values) -> str:  # type: ignore
        return name

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}.{self.name}"
