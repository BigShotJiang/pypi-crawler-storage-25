from __future__ import annotations

from collections.abc import Callable, Hashable, Iterable, Sequence
from functools import reduce
from operator import and_, or_
from typing import TypeVar, cast, overload

__all__ = (
    "dfilter",
    "dmap",
    "endofilter",
    "endomap",
    "fold_dictionaries",
    "identity",
    "kfilter",
    "kmap",
    "kvfilter",
    "kvmap",
    "lfilter",
    "lmap",
    # "negate",
    "sfilter",
    "smap",
    "split_head",
    "tail",
    "tfilter",
    "tmap",
    "vfilter",
    "vmap",
)

T = TypeVar("T")
Tup = TypeVar("Tup", bound=tuple[object, ...])
Seq = TypeVar("Seq", bound=list | tuple)
KPre = TypeVar("KPre")
VPre = TypeVar("VPre")
KPost = TypeVar("KPost")
VPost = TypeVar("VPost")
TPost = TypeVar("TPost")
TPre = TypeVar("TPre")
K = TypeVar("K", bound=Hashable)
V = TypeVar("V")
type Filterer[T] = Callable[[T], bool]
type DictLike[K, V] = dict[K, V] | Iterable[tuple[K, V]]

# HELPERS


def _handle_dictlike[K, V](d: DictLike[K, V]) -> Iterable[tuple[K, V]]:
    if isinstance(d, dict):
        tmp = tuple(d.items())
        return tmp  # type: ignore
    return d


# MISCELLANEOUS


def negate[T: object](f: Callable[[T], object]) -> Callable[[T], bool]:
    def inner(ob: T) -> bool:
        return not f(ob)

    return inner


def identity[T](x: T) -> T:
    return x


def split_head[T](seq: Sequence[T]) -> tuple[T, Sequence[T]]:
    if not seq:
        raise ValueError(f"List {seq} is invalid because it cannot be properly split.")
    return seq[0], seq[1:]


def tail[T](seq: Sequence[T]) -> Sequence[T]:  # noqa: FURB118
    return seq[1:]


# SPECIAL ENDOFUNCTIONS (T -> T)


@overload
def endomap[TPre, TPost](
    callable_: Callable[[TPre], TPost], sequence: list[TPre]
) -> list[TPost]: ...  # pragma: no cover
@overload
def endomap[TPre, TPost](
    callable_: Callable[[TPre], TPost], sequence: set[TPre]
) -> set[TPost]: ...  # pragma: no cover
@overload
def endomap[TPre, TPost](
    callable_: Callable[[TPre], TPost], sequence: tuple[TPre, ...]
) -> tuple[TPost, ...]: ...  # pragma: no cover
def endomap(callable_, sequence):
    return type(sequence)(map(callable_, sequence))


@overload
def endofilter[T](
    callable_: Callable[[T], bool], sequence: list[T]
) -> list[T]: ...  # pragma: no cover
@overload
def endofilter[T](
    callable_: Callable[[T], bool], sequence: set[T]
) -> set[T]: ...  # pragma: no cover
@overload
def endofilter[T](
    callable_: Callable[[T], bool], sequence: tuple[T, ...]
) -> tuple[T, ...]: ...  # pragma: no cover
def endofilter(callable_, sequence):
    return type(sequence)(filter(callable_, sequence))


# MAPS


def lmap[TPre, TPost](callable_: Callable[[TPre], TPost], iterable: Iterable[TPre]) -> list[TPost]:
    return list(map(callable_, iterable))


def smap[TPre, TPost](callable_: Callable[[TPre], TPost], iterable: Iterable[TPre]) -> set[TPost]:
    return set(map(callable_, iterable))


def tmap[TPre, TPost](
    callable_: Callable[[TPre], TPost], iterable: Iterable[TPre]
) -> tuple[TPost, ...]:
    return tuple(map(callable_, iterable))


def vmap[TPre, TPost, K: Hashable](
    callable_: Callable[[TPre], TPost], dictionary: DictLike[K, TPre]
) -> dict[K, TPost]:
    return {k: callable_(v) for k, v in _handle_dictlike(dictionary)}


def kmap[TPre, TPost, V](
    callable_: Callable[[TPre], TPost], dictionary: DictLike[TPre, V]
) -> dict[TPost, V]:
    return {callable_(k): v for k, v in _handle_dictlike(dictionary)}


def dmap[TPre, TPost](
    callable_: Callable[[TPre], TPost], dictionary: DictLike[TPre, TPre]
) -> dict[TPost, TPost]:
    return {callable_(k): callable_(v) for k, v in _handle_dictlike(dictionary)}


def kvmap[KPre, VPre, KPost, VPost](
    callable_: Callable[[tuple[KPre, VPre]], tuple[KPost, VPost]], d: DictLike[KPre, VPre]
) -> dict[KPost, VPost]:
    return dict(map(callable_, _handle_dictlike(d)))


# FOLDERS


def fold_dictionaries[K, V](dicts: Iterable[dict[K, V]]) -> dict[K, V]:
    def _or(dict1: dict[K, V], dict2: dict[K, V]) -> dict[K, V]:  # noqa: FURB118
        return dict1 | dict2

    return reduce(_or, dicts)


# FILTERS


@overload
def lfilter[T](filterer: Filterer[T], iterable: Iterable[T]) -> list[T]: ...
@overload
def lfilter[T](iterable: Iterable[T]) -> list[T]: ...


@overload
def sfilter[T](filterer: Filterer[T], iterable: Iterable[T]) -> set[T]: ...
@overload
def sfilter[T](iterable: Iterable[T]) -> set[T]: ...


@overload
def tfilter[T](filterer: Filterer[T], iterable: Iterable[T]) -> tuple[T, ...]: ...
@overload
def tfilter[T](iterable: Iterable[T]) -> tuple[T, ...]: ...


@overload
def vfilter[K, V](filterer: Filterer[V], dictionary: dict[K, V]) -> dict[K, V]: ...
@overload
def vfilter[K, V](dictionary: dict[K, V]) -> dict[K, V]: ...


@overload
def kfilter[K, V](filterer: Filterer[K], dictionary: dict[K, V]) -> dict[K, V]: ...
@overload
def kfilter[K, V](dictionary: dict[K, V]) -> dict[K, V]: ...


@overload
def dfilter[K, V](
    filterer: Filterer[K | V],
    dictionary: DictLike[K, V],
    disjoint: bool = False,
) -> dict[K, V]: ...
@overload
def dfilter[K, V](
    dictionary: DictLike[K, V],
    disjoint: bool = False,
) -> dict[K, V]: ...


@overload
def kvfilter[K, V](d: DictLike[K, V]) -> dict[K, V]: ...
@overload
def kvfilter[K, V](
    callable_: Callable[[tuple[K, V]], bool],
    d: DictLike[K, V],
) -> dict[K, V]: ...


# INTERNAL FILTER HELPERS


def _resolve_args[F: Filterer, I: Iterable | DictLike](
    filterer_or_iterable: F | I,
    iterable_or_none: I | None,
    fallback: F = cast(Filterer[object], bool),
) -> tuple[F, I]:
    if iterable_or_none is None and not (
        hasattr(filterer_or_iterable, "__iter__")  # or isinstance(filterer_or_iterable, dict)
    ):
        raise ValueError
    filterer = cast(F, fallback if (iterable_or_none is None) else filterer_or_iterable)
    iterable = cast(I, filterer_or_iterable if (iterable_or_none is None) else iterable_or_none)

    return filterer, iterable


def _kvbool[K, V](kv: tuple[K, V]) -> bool:
    return bool(kv[0]) and bool(kv[1])


# UGLY ACTUAL IMPLEMENTATIONS


def lfilter[T](  # type: ignore
    filterer_or_iterable: Filterer[T] | Iterable[T],
    iterable_or_none: Iterable[T] | None = None,
) -> list[T]:
    filterer, iterable = _resolve_args(filterer_or_iterable, iterable_or_none)
    return list(filter(filterer, iterable))


def sfilter[T](  # type: ignore
    filterer_or_iterable: Filterer[T] | Iterable[T],
    iterable_or_none: Iterable[T] | None = None,
) -> set[T]:
    filterer, iterable = _resolve_args(filterer_or_iterable, iterable_or_none)
    return set(filter(filterer, iterable))


def tfilter[T](  # type: ignore
    filterer_or_iterable: Filterer[T] | Iterable[T],
    iterable_or_none: Iterable[T] | None = None,
) -> tuple[T, ...]:
    filterer, iterable = _resolve_args(filterer_or_iterable, iterable_or_none)
    return tuple(filter(filterer, iterable))


def vfilter[K, V](  # type: ignore
    filterer_or_iterable: Filterer[V] | DictLike[K, V],
    dictlike_or_none: DictLike[K, V] | None = None,
) -> dict[K, V]:
    filterer, dictlike = _resolve_args(filterer_or_iterable, dictlike_or_none)
    return {k: v for k, v in _handle_dictlike(dictlike) if filterer(v)}


def kfilter[K, V](  # type: ignore
    filterer_or_iterable: Filterer[K] | dict[K, V],
    dictlike_or_none: dict[K, V] | None = None,
) -> dict[K, V]:
    filterer, dictlike = _resolve_args(filterer_or_iterable, dictlike_or_none)
    return {k: v for k, v in _handle_dictlike(dictlike) if filterer(k)}


def dfilter[K, V](  # type: ignore
    filterer_or_iterable: Filterer[K | V] | DictLike[K, V],
    dictlike_or_none: DictLike[K, V] | None = None,
    disjoint: bool = False,
) -> dict[K, V]:
    op = or_ if disjoint else and_
    filterer, dictlike = _resolve_args(filterer_or_iterable, dictlike_or_none)
    return {k: v for k, v in _handle_dictlike(dictlike) if op(filterer(k), filterer(v))}


def kvfilter[K, V](  # type: ignore
    filterer_or_iterable: Filterer[tuple[K, V]] | DictLike[K, V],
    dictlike_or_none: DictLike[K, V] | None = None,
) -> dict[K, V]:
    filterer, dictlike = _resolve_args(filterer_or_iterable, dictlike_or_none, _kvbool)
    return dict(filter(filterer, _handle_dictlike(dictlike)))
