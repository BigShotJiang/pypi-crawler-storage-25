def assert_xor(first: object, second: object) -> None:
    if bool(first) == bool(second):
        msg = f"Exactly one of the given values must be true; both {first!s}."
        raise ValueError(msg)
