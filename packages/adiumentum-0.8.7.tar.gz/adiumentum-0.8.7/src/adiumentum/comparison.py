from __future__ import annotations

from collections.abc import Callable
from operator import not_ as negate

__all__ = (
    "as_bool",
    "equal_within",
    "make_maybe_not",
    "match_empty",
    "nearly_equal",
    "trivial_condition",
)


def nearly_equal(a: int | float, b: int | float) -> bool:
    return abs(a - b) < 0.00001


def equal_within(a: int | float, b: int | float, epsilon: float | int) -> bool:
    return abs(a - b) < epsilon


def match_empty(item: str | bool | set[str] | float | None) -> bool:
    return not bool(item)


def trivial_condition(n: object) -> bool:
    return True


def as_bool(object_: object) -> bool:
    if isinstance(object_, bool):
        return object_
    if isinstance(object_, int | float):
        return True
    return bool(object_)


def make_maybe_not(*, negated: bool) -> Callable[[object], bool]:
    return negate if negated else as_bool
