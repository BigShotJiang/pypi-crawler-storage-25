# adiumentum


With Nix installed, you can enter a development environment with all dependencies installed:

```sh
nix develop
```

## Roadmap
