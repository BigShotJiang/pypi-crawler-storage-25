Changelog
=========


1.1 (2026-03-31)
----------------

- pa.discussion is now an core-addon.
  [jensens]


1.0 (2026-03-31)
----------------

- Do not autoinclude ZCML.
  [jensens]

- add profile for Plone 6 and fix controlpanel icons.
  [petschki]

- Use tox for testing, ensure tests are passing for Plone 5.0.x, 5.1.x and 5.2.x.
  [thomasmassmann]


1.0a1 (2016-10-06)
------------------

- Initial release.
  [thet]
