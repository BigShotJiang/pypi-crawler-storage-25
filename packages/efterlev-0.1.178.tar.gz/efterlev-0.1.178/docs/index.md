# Efterlev

**Compliance automation for SaaS companies pursuing their first FedRAMP Moderate authorization via the FedRAMP 20x pilot.**

Scans your Terraform for KSI-level evidence. Drafts FRMR-compatible validation data for your 3PAO. Proposes code-level remediations you can apply today. Runs locally — no SaaS, no telemetry, no procurement cycle.

[:material-rocket-launch: Get started](quickstart.md){ .md-button .md-button--primary }
[:material-map-marker-path: The ISV journey](isv-journey.md){ .md-button }
[:material-book-open: Read the concepts](concepts/ksis-for-engineers.md){ .md-button }
[:material-github: View on GitHub](https://github.com/efterlev/efterlev){ .md-button }

New to FedRAMP 20x? [The ISV journey](isv-journey.md) maps the seven stages from "should we do this?" to continuous monitoring, and says plainly where Efterlev helps and where it doesn't.

```bash
pipx install efterlev
cd path/to/your-repo
efterlev init --baseline fedramp-20x-moderate
efterlev report run                          # init → scan → gap → document → poam, one command
```

Pronounced "EF-ter-lev." From Swedish *efterlevnad* (compliance).

---

## What it does

- **Scans** Terraform source for evidence of FedRAMP 20x Key Security Indicators (KSIs), backed by NIST 800-53 Rev 5 controls.
- **Drafts** FRMR-compatible attestation JSON grounded in that evidence, with every assertion citing its source line.
- **Proposes** code-level remediation diffs for detected gaps.
- **Emits** machine-readable validation data ready for 3PAO review and the FedRAMP 20x automated validation pipeline.
- **Traces** every generated claim back to the source line that produced it.

Everything runs locally. The only outbound network call is to your configured LLM endpoint (Anthropic direct or AWS Bedrock for GovCloud) for reasoning tasks. Scanner output is deterministic and offline.

## What it doesn't do

- It does not produce an Authorization to Operate. Humans and 3PAOs do that.
- It does not certify compliance. It produces drafts that accelerate the human review cycle.
- It does not guarantee generated narratives are correct. Every LLM-generated artifact is marked `DRAFT — requires human review`.
- It does not cover SOC 2, ISO 27001, HIPAA, or GDPR. Other tools serve those well.
- It does not scan live cloud infrastructure yet. v1.5+.

[Full accounting in LIMITATIONS.md](https://github.com/efterlev/efterlev/blob/main/LIMITATIONS.md)

---

## Why Efterlev

A 100-person SaaS company just got told by its biggest prospect: *"we'll buy, but only if you're FedRAMP Moderate by next year."*

The team looks at each other. Nobody's done this before. They google it and find:

- Consulting engagements starting at $250K
- SaaS compliance platforms that cover SOC 2 beautifully but treat FedRAMP as a footnote
- Enterprise GRC tooling priced for the wrong scale
- Spreadsheets, Word templates, and a NIST document family that runs to thousands of pages

What they actually need is something that reads their infrastructure-as-code — whatever flavor they use — and tells them, in their own language, what's wrong and how to fix it. Something a single engineer can install on a Tuesday and show results at Wednesday's standup. Something whose output is concrete enough that their 3PAO can use it — and whose claims are honest enough that the 3PAO won't throw it out.

Efterlev is that tool.

[Read the full ICP](https://github.com/efterlev/efterlev/blob/main/docs/icp.md)

---

## How it's built

Three layers, each with a clear job.

- **Detectors** — small deterministic Python rules that read Terraform (or `.github/workflows/`) and emit evidence. 51 ship today (v0.1.35) covering 36 of 60 KSIs across 9 themes; the long-term plan is hundreds, contributed by the community.
- **Primitives** — typed functions that wrap the things agents need to do: load a catalog, validate output, render a report. Stable interface layer.
- **Agents** — reasoning loops that compose primitives. Three: Gap (classify each KSI), Documentation (draft FRMR attestations), Remediation (propose code-level fixes).

[Read the architecture overview](architecture.md)

---

## Status

- **v0.1.178 current** (2026-05-21): one hundred and sixty-seven patch releases since v0.1.0 (2026-04-29), each addressing real-world first-run issues caught by deep-dive shakedowns or — at v0.1.11 — by an external 3PAO blinded review. PyPI + container + GitHub Action + AWS GovCloud Bedrock backend + 66 detectors + full provenance graph + token-usage telemetry + ConMon Lite v0/v1 PR-delta sticky comments + `efterlev detectors new <id>` contributor scaffolder + `efterlev boundary set --interactive` helper + `efterlev detectors show <id>` + `efterlev manifests validate <path>` + `efterlev scan` hard-errors on subdir-below-workflows-ancestor (closes a documented funnel-killer; `--allow-subdir-target` opts back in for the monorepo case) + `github.branch_protection` detector + wheel/sdist CycloneDX SBOMs on every GitHub Release + ALL third-party Actions SHA-pinned (no exceptions) + `pip-audit` + `bandit` lockfile-pinned in `[dev]` extra + eval-harness Phase 2 lite operational on Terraform inputs (3 vendored real-shape fixtures from `terraform-aws-modules/{vpc, s3-bucket, lambda}` with 67 maintainer-validated labels at 100% precision + 100% recall) + CFN/CDK synth-mode arc shipped through v0.1.86 (DECISIONS 2026-05-12: PR alpha=design v0.1.70, PR beta=parser+adapter+scan v0.1.72, PR gamma=property-mapping table v0.1.73 with the architecture-validation slice, PR gamma.2 batches 1-4 expanding to 18 CFN types across 13 AWS namespaces v0.1.74-v0.1.77, CFN eval-harness Phase 2 lite scaffolding with first labeled CFN fixture `csp-starter-cfn` v0.1.78, **CFN maintainer-validation pass landed at 23/23 = 100% precision + 100% recall on Bedrock Haiku 4.5 v0.1.81 — matching the v0.1.69 Terraform-side baseline; the strategic bet-pays-off measurement is closed**, plus README polish v0.1.79/0.1.82 and accuracy patches v0.1.80/0.1.83) + GitHub Actions minute-budget reduction at v0.1.87 (release-smoke matrix slim 7→4 cells + dropped ci.yml `push:` trigger to stop double-firing + e2e-smoke version-bump-only filter) + cosign-installer pin to v3.0.6 in release-smoke signature-verify at v0.1.88 (default cosign v2.5.2 can't verify SLSA v1 attestations) + cosign-installer action bump v3 → v4.1.2 at v0.1.89 (the v0.1.88 pin failed because v3-action's installer can only fetch cosign v2.x; v4.1.2 defaults to cosign v3.0.6) + CFN PR gamma.2 batch 5 at v0.1.90 covering the WAF family (5 CFN types: WAFv2::WebACL/WebACLAssociation/RuleGroup, WAF::WebACL legacy v1, Shield::Protection — unlocks 8 detectors, the highest-impact batch in the gamma.2 series) + CFN PR gamma.2 batch 6 at v0.1.91 covering RDS Cluster + EC2 NetworkAcl pair + EC2 Instance (4 CFN types unlocking 7 detectors) + CFN PR gamma.2 batch 7 at v0.1.92 covering IAM Group + API Gateway v1/v2 Stage + v1 Method + v2 Route (5 CFN types unlocking ~7 detectors) + CFN PR gamma.2 batch 8 (finishing batch) at v0.1.93 covering the remaining 30 detector-referenced CFN types in one PR — every detector is now reachable from CloudFormation; CFN type-coverage CLOSED + repo-content cleanup at v0.1.94 (removed COMPETITIVE_LANDSCAPE.md + docs/comparisons/* + docs/dual_horizon_plan.md; scrubbed all "hackathon" references from prose and historical decision records) + CFN graduation arc step 1 at v0.1.95: detector parity audit shipped as docs/cfn-detector-parity.csv + .md, generated by scripts/build_cfn_parity_table.py (92% effective CFN coverage with 5 detectors having real gaps; honest correction from v0.1.93 "CLOSED" claim) + CFN graduation arc step 1.5 at v0.1.96: closed all 8 missing CFN mappings (AWS::IAM::AccessKey, AWS::Logs::Destination, AWS::Logs::SubscriptionFilter, AWS::OpenSearchService::Domain, AWS::Elasticsearch::Domain, AWS::KinesisFirehose::DeliveryStream, AWS::SecurityHub::Hub, AWS::SecurityHub::FindingAggregator) — CFN coverage is now 100% (60/60 detectors reachable) + CFN graduation arc step 2 at v0.1.97: 2nd labeled CFN fixture (aws-vpc-cfn — vendored AWS Quick Start VPC, draft labels mirroring aws-vpc-tfm) + CFN graduation arc step 2 (validation) at v0.1.98: aws-vpc-cfn maintainer-validation dispatch on Anthropic API + Haiku 4.5 hit **21/21 = 100% precision + 100% recall**. Combined CFN validation: 44/44 across 2 fixtures = 100% (matches TF baseline shape) + CFN graduation arc step 3 at v0.1.99: **CFN scanning is now default-on**. Removed "experimental" framing from README/LIMITATIONS/doctor; deprecated `--allow-cfn` flag (still functional with deprecation warning, removed in v0.2.0) + post-graduation doc cleanup at v0.1.100: fixed stale "Terraform/OpenTofu only" claim in docs/faq.md, "CloudFormation in v1.5+" in docs/architecture.md, "next arc release" pointer in PHASE_2_LITE_CFN_VALIDATION.md, and dropped the now-deprecated --allow-cfn append from evals/harness.py (removed _fixture_has_cfn_templates as dead code) + verify-release.sh ghcr-propagation retry-and-wait at v0.1.101 (5min retry on cosign sig + SLSA attestation; closes the recurring release-smoke timing race that hit v0.1.87 and v0.1.99) + CFN graduation arc step 4 at v0.1.102: removed the `--allow-cfn` flag entirely. CFN now scans unconditionally. Shipped as v0.1.102 (not v0.2.0) per DECISIONS commitments reserving v0.2.0 for the eval-harness-as-user-feature substantive arc + QA-surfaced bundle at v0.1.103: scanned aws-quickstart/quickstart-aws-aurora-postgresql for internal QA, surfaced 3 real bugs — (a) parser crashed on Rules-section intrinsics (!ValueOf etc.) silently dropping a 1091-line template; (b) parse failures not surfaced in scan summary; (c) nested-stack references not visible to user. All 3 fixed; same-fixture re-scan went from 1 template / 3 resources / 1 evidence record to 2 templates / 24 resources / 19 evidence records + SAM transparency note at v0.1.104: documented in LIMITATIONS that AWS::Serverless::* types fall through the unmapped-fallback path; real SAM property mappings deferred until first customer hits the gap (better to use customer's template as validation fixture than guess SAM-app shape) + OSCAL output arc step 1 at v0.1.105: shipped `efterlev oscal export --kind poam` emitting OSCAL 1.0.4 POA&M JSON conforming to the FedRAMP-current schema + OSCAL output arc step 2 at v0.1.106: vendored NIST OSCAL 1.0.4 POA&M JSON schema under `catalogs/oscal/` + new `validate_oscal_poam` primitive that gates emit against the schema in CI on every PR + first labeled OSCAL fixture under `evals/fixtures/csp-starter-cfn/oscal/labeled-poam-v0.1.106.json` (3PAO-inspectable artifact, 6 KSIs / 12 risks / 6 observations). The schema gate caught two real bugs in v0.1.105 within minutes of being wired up — `findings` → `risks` (OSCAL POA&M has no `findings` property; per-control deficiencies live in `risks`) and `related-observations` empty-array elision. GSA Schematron rule layer planned for v0.1.107 + OSCAL output arc step 3 at v0.1.107: layered Python-native FedRAMP rule set on top of the schema gate (5 rules ported from GSA fedramp-automation: severity / risk-status / evidence-link / baseline / oscal-version enumerations). Hand-port instead of vendored Schematron + Saxon to avoid adding ~50 MB Java runtime to CI; trade-off becomes worth flipping at ~30 rules. Caught a real v0.1.106 bug — generator emitted `medium` severity instead of FedRAMP-canonical `moderate`; fixed in v0.1.107 (generator primitive bumped 0.2.0 → 0.3.0) + OSCAL output arc step 4 at v0.1.108: shipped `efterlev oscal export --kind component-definition` emitting OSCAL 1.0.4 Component-Definition JSON. New `generate_component_definition_oscal` primitive + `validate_oscal_component_definition` schema gate + first labeled CD fixture under `evals/fixtures/csp-starter-cfn/oscal/labeled-component-definition-v0.1.108.json` (1 component, 12 implemented-requirements). Documentation Agent narrative integration deferred to v0.1.109+ + OSCAL output arc step 5 at v0.1.109: Documentation Agent narratives → CD `implemented-requirement.statements[]`. New `--narratives-from <attestation-path>` CLI option loads the `attestation-*.json` artifact and populates per-control statements. Generator primitive bumped 0.1.0 → 0.2.0 (additive output-shape extension; v0.1.108 callers without narratives produce byte-identical output) + OSCAL output arc step 6 at v0.1.110: NIST oscal-cli round-trip CI gate. New `.github/workflows/oscal-cli-conformance.yml` runs NIST's canonical Java validator against both labeled fixtures (POA&M + CD) on every PR — second-opinion check beyond our Python schema/rule layers + OSCAL output arc step 7 at v0.1.111 (arc closed): doc graduation. OSCAL POA&M + Component-Definition emit by default from `efterlev report run` (pipeline now reads `init → scan → agent gap → agent document → poam → oscal`); `--skip-oscal` available for opt-out + M2 time-to-FRMR benchmark harness at v0.1.112: shipped `scripts/benchmark.py` + `.github/workflows/benchmark-dispatch.yml` + `docs/benchmark-2026-05.md`. Captures wall-clock + LLM cost + token usage + KSI counts for the full `report run` pipeline against any fixture; mean / median / p95 / max aggregation across N runs. Maintainer-dispatched workflow (real Anthropic spend, not a per-PR gate); first published numbers in v0.1.112.x + M1 Stage 1 — AWS Security Hub ASFF ingestion at v0.1.113: shipped `efterlev import-security-hub <findings.json> --allow-import`. New `src/efterlev/imports/` package + `parse_asff_document()` + `ingest_security_hub` primitive + 5 initial generator-id → KSI mappings (EC2.2, IAM.6, S3.1, CloudTrail.1, KMS.1) + synthetic ASFF sample fixture (zero AWS spend). File-based ingestion only — no AWS API calls (local-first posture intact). Behind `--allow-import` opt-in flag; graduates to default-on at end of M1 arc + M1 Stage 3 — AWS Config evaluations ingestion at v0.1.114: shipped `efterlev import-config <evaluations.json> --allow-import`. Sibling to import-security-hub; same architecture (parser → mapping → ingest), same opt-in posture. Initial 5 mappings: encrypted-volumes, s3-bucket-public-read/write-prohibited, iam-root-access-key-check, cloudtrail-enabled + benchmark bug fixes + Bedrock backend wiring + NVIDIA Nemotron pricing at v0.1.115: fixed 4 bugs surfaced by the v0.1.114 dispatch (--llm-model was a no-op causing $60/run instead of $0.30; estimated cost was always $0; poam_md detection used wrong glob; artifact upload missed files). Added support for non-Claude Bedrock models with NVIDIA Nemotron Super 120B as the GovCloud-aligned cheap-model story (~50× cheaper than Opus 4.7). M1 arc continued and closed: agents-honor-workspace-config Bedrock fix (v0.1.116) + Bedrock Haiku validated 100/100 / GPT-OSS-120B failed (v0.1.117) + Bedrock Haiku validated across all 5 fixtures at 99.1% / 100% (v0.1.118) + extended labeled ASFF fixture (v0.1.119) + extended labeled Config fixture (v0.1.120) + Security Hub mapping batch 5→13 (v0.1.121) + AWS Config mapping batch 5→13 (v0.1.122) + M1 Stage 5 Prowler native ingestion with 8 mappings + 13 tests (v0.1.123) + **M1 Stage 6 graduation: `--allow-import` flag removed from all three import commands; runtime-evidence ingestion is now default-on (v0.1.124)** + post-M1 polish bundle (v0.1.125): in-agent retry on Haiku validator-rejection (#327, absorbs ~1% transient flake before customers see it), GitHub Release notes now prepend the matching CHANGELOG section above the deterministic triage output (#328), README "Status" off-by-one fix, LIMITATIONS doc note for Haiku users + CDK source-mode arc Stage 1 (v0.1.126): shipped `efterlev scan --allow-cdk-py` to parse Python CDK source files directly with file:line citations preserved (the source-mode VALUE vs the existing `cdk synth → CFN → scan` synth-mode that loses traceability). Stage 1 covers `aws_cdk.aws_s3.Bucket` only; **Stage 2 (v0.1.127) added 4 more constructs (`aws_kms.Key`, `aws_ec2.SecurityGroup`, `aws_iam.Role`, `aws_cloudtrail.Trail`); Stage 3 (v0.1.128) added 4 more (`aws_lambda.Function`, `aws_rds.DatabaseInstance`, `aws_dynamodb.Table`, `aws_logs.LogGroup`); **Stage 4 (v0.1.129) finisher batch added 18 more covering remaining service families (SNS/SQS/EFS/EKS/VPC/SecretsManager/ApiGateway×2/AutoScaling/ELBv2/CloudWatch/Events/Backup×2/IAM User+Group/Kinesis/OpenSearch) for 27 supported constructs total**; **Stage 5 (v0.1.130) doc graduation positions source-mode as INTENTIONALLY narrow (presence + file:line; L2 property translation deliberately not pursued — composes with synth-mode for property depth); Stage 6 (v0.1.131) graduates `--allow-cdk-py` to default-on — Python CDK source-mode arc CLOSED** + **`efterlev shell` interactive REPL at v0.1.132**: compresses the 36-command CLI surface into a persistent session with always-visible workspace status, state-aware next-step hint, tab completion, command history, and subtle styling. Banner inspired by the efterlev.org logotype**; construct expansion continues in subsequent batches mirroring the v0.1.74-93 CFN arc. Why Python first: stdlib `ast` keeps the architecture-validation parser trivial; TS (~70% of CDK usage) follows in Stage N+3 reusing all downstream wiring. banner-fix at v0.1.133 (figlet "standard" font replaces fragmented box-drawing; new /tour walkthrough; README positioning rewrite — Why this exists / Built for 20x / Compliance falls out of your security program) + /setup wizard and /ai Q&A at v0.1.134 (interactive LLM API config with real-test-query validation; single-shot AI grounded in workspace state; persists to ~/.efterlev/credentials.toml mode 0600) + `efterlev readiness` + `efterlev submission package` at v0.1.137 (single-page scorecard with progress bar + top-3 blockers + suggested next commands, plus one-command zip bundling FRMR + POA&M + OSCAL POA&M+CD + HTML reports + manifests with README + SHA-256 per artifact for 3PAO handoff — both pure deterministic, zero LLM spend). Full E2E pipeline smoke runs on every PR. See the [CHANGELOG](https://github.com/efterlev/efterlev/blob/main/CHANGELOG.md).
- **Open source:** Apache 2.0. Pure OSS — no commercial tier, no paid layer, no managed SaaS at this time. [Why](https://github.com/efterlev/efterlev/blob/main/DECISIONS.md).
- **Governance:** BDFL today, technical steering committee at 10 sustained contributors. [Details](https://github.com/efterlev/efterlev/blob/main/GOVERNANCE.md).

## External context — what AWS recommends

For AWS-native CSPs, AWS published two FedRAMP 20x guidance pieces:

- [Prepare for FedRAMP 20x with AWS automation and validation (2026-02-18)](https://aws.amazon.com/blogs/publicsector/prepare-for-fedramp-20x-with-aws-automation-and-validation/) — the primer.
- [Deep dive into FedRAMP 20x KSIs: Decoding the 63 KSIs (2026-04-27)](https://aws.amazon.com/blogs/publicsector/deep-dive-into-fedramp-20x-key-security-indicators-decoding-the-63-ksis/) — the per-KSI mapping to AWS-native services (Config, Security Hub, CloudTrail, Inspector, KMS, etc.).

Efterlev's positioning relative to the AWS-native pattern is **complementary**:
AWS Config / Security Hub evaluate *runtime* state on a 3-day cadence; Efterlev evaluates
*pre-deploy* IaC during the dev loop. Customers pursuing FedRAMP need both. The AWS posts
also frame the FRMR catalog as 63 KSIs (counting 3 cross-cutting CSX KSIs); Efterlev counts
the same catalog as 60 thematic KSIs. See
[csx-mapping.md](https://github.com/efterlev/efterlev/blob/main/docs/csx-mapping.md) for
how Efterlev's existing artifacts already satisfy the CSX KSIs.

---

*Efterlev is built for the VP Eng or DevSecOps lead whose CEO just said "we need FedRAMP" and who needs to know, by Monday, where they actually stand.*
