"""Strategy framework data models.

Separate from auspicium/models.py (DaaS data models).
These models represent trading primitives: orders, fills, positions, portfolio.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, model_validator

# Canonical order-type identifiers. Strings (not Enum) to keep the wire
# format stable and to avoid import-order issues in user code.
ORDER_TYPE_MARKET = "MARKET"
ORDER_TYPE_LIMIT = "LIMIT"
ORDER_TYPE_STOP_LOSS = "STOP_LOSS"
ORDER_TYPE_STOP_LOSS_LIMIT = "STOP_LOSS_LIMIT"
ORDER_TYPE_TAKE_PROFIT = "TAKE_PROFIT"
ORDER_TYPE_TAKE_PROFIT_LIMIT = "TAKE_PROFIT_LIMIT"
ORDER_TYPE_TRAILING_STOP = "TRAILING_STOP"
ORDER_TYPE_OCO = "OCO"

_VALID_ORDER_TYPES = frozenset({
    ORDER_TYPE_MARKET, ORDER_TYPE_LIMIT,
    ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT,
    ORDER_TYPE_TRAILING_STOP, ORDER_TYPE_OCO,
})

# Order types that require a stop_price trigger.
_STOP_TRIGGER_TYPES = frozenset({
    ORDER_TYPE_STOP_LOSS, ORDER_TYPE_STOP_LOSS_LIMIT,
    ORDER_TYPE_TAKE_PROFIT, ORDER_TYPE_TAKE_PROFIT_LIMIT,
})


class Order(BaseModel):
    """An order to submit to the exchange (paper or real)."""

    market: str                 # condition_id (Polymarket) or symbol (Binance, e.g. BTC-USDT)
    side: str                   # "BUY" or "SELL"
    outcome: str = "YES"        # "YES" or "NO" (Polymarket only, ignored for Binance)
    size: float                 # Number of shares/units
    price: float                # Limit price (used for LIMIT and *_LIMIT types; ignored for pure MARKET/stop-market)
    order_type: str = "LIMIT"   # see ORDER_TYPE_* constants
    id: str = ""                # Auto-generated if empty

    # Stop / conditional fields — None for plain LIMIT/MARKET orders.
    stop_price: float | None = None      # trigger price for STOP_LOSS/TAKE_PROFIT (+_LIMIT)
    trail_percent: float | None = None   # e.g. 0.02 = 2% trailing distance
    trail_amount: float | None = None    # absolute trailing distance in quote currency

    # OCO (one-cancels-other) fields — bracket a position with TP + SL.
    oco_stop_price: float | None = None   # stop-loss trigger
    oco_limit_price: float | None = None  # take-profit limit price

    @model_validator(mode="after")
    def _generate_id(self) -> Order:
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        return self

    @model_validator(mode="after")
    def _validate_order_type(self) -> Order:
        ot = self.order_type.upper()
        if ot not in _VALID_ORDER_TYPES:
            raise ValueError(
                f"Invalid order_type {self.order_type!r}. "
                f"Expected one of: {sorted(_VALID_ORDER_TYPES)}"
            )
        # Normalise case so downstream code can do string comparison without .upper()
        object.__setattr__(self, "order_type", ot)

        if ot in _STOP_TRIGGER_TYPES and self.stop_price is None:
            raise ValueError(f"{ot} requires stop_price")
        if ot == ORDER_TYPE_TRAILING_STOP and self.trail_percent is None and self.trail_amount is None:
            raise ValueError("TRAILING_STOP requires trail_percent or trail_amount")
        if ot == ORDER_TYPE_OCO:
            if self.oco_stop_price is None or self.oco_limit_price is None:
                raise ValueError("OCO requires both oco_stop_price and oco_limit_price")
        return self

    @property
    def is_conditional(self) -> bool:
        """True for any order whose submission is gated on a trigger price."""
        return self.order_type in _STOP_TRIGGER_TYPES or self.order_type in {
            ORDER_TYPE_TRAILING_STOP, ORDER_TYPE_OCO,
        }


class Fill(BaseModel):
    """A completed order fill (from paper or real exchange)."""

    order_id: str
    market: str
    side: str
    outcome: str
    price: float
    size: float
    fee: float = 0.0
    timestamp: datetime
    status: str = "CONFIRMED"   # "MATCHED" | "CONFIRMED" | "FAILED"

    @classmethod
    def now(cls, **kwargs: Any) -> Fill:
        """Convenience constructor that sets timestamp to now (UTC)."""
        return cls(timestamp=datetime.now(timezone.utc), **kwargs)


class Position(BaseModel):
    """A current position in a market."""

    market: str
    side: str                   # "LONG" or "SHORT"
    outcome: str = "YES"        # Polymarket outcome ("YES" / "NO")
    size: float
    entry_price: float
    current_price: float = 0.0
    unrealized_pnl: float = 0.0

    def update_price(self, price: float) -> None:
        """Update current_price and recompute unrealized PnL."""
        self.current_price = price
        direction = 1.0 if self.side == "LONG" else -1.0
        self.unrealized_pnl = direction * self.size * (price - self.entry_price)


class Portfolio(BaseModel):
    """Full portfolio state."""

    cash: float
    positions: dict[str, Position] = {}   # keyed by market (condition_id or symbol)
    total_value: float = 0.0
    realized_pnl: float = 0.0
    unrealized_pnl: float = 0.0
    daily_pnl: float = 0.0

    def recompute(self) -> None:
        """Recompute total_value and unrealized_pnl from current positions."""
        self.unrealized_pnl = sum(p.unrealized_pnl for p in self.positions.values())
        positions_value = sum(p.size * p.current_price for p in self.positions.values())
        self.total_value = self.cash + positions_value
