"""Abstract base class for all Auspicium trading strategies.

Quants subclass Strategy, implement configure() and on_data(), and use the
framework-provided helpers (submit, cancel, close_position, kelly_size, etc.).
The runner injects the exchange adapter, state manager, and risk guardian —
the strategy never references them directly.

Design principle: zero if/elif env logic inside strategy code.
The runner controls which exchange adapter is injected.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from auspicium.strategy.models import (
    ORDER_TYPE_OCO,
    ORDER_TYPE_STOP_LOSS,
    ORDER_TYPE_TAKE_PROFIT,
    ORDER_TYPE_TRAILING_STOP,
    Fill,
    Order,
    Portfolio,
    Position,
)
from auspicium.strategy.risk import RiskGuardian
from auspicium.strategy.state import StateManager


class Strategy(ABC):
    """Base class for all Auspicium trading strategies.

    Lifecycle:
        1. Runner instantiates the Strategy subclass
        2. Runner calls configure() — declare subscriptions, load params
        3. Runner enters event loop — on_data(tick) for each tick
        4. Strategy calls self.submit(order) — routed to exchange adapter
        5. Exchange adapter calls on_fill(fill) when order executes
        6. On SIGTERM: runner calls on_shutdown()

    The quant implements:
        configure()        — REQUIRED: declare subscriptions and parameters
        on_data(tick)      — REQUIRED: react to each data tick
        on_fill(fill)      — OPTIONAL: react to order fills (base logs it)
        on_shutdown()      — OPTIONAL: cleanup (base cancels all open orders)

    The framework provides:
        self.submit(order)           — submit an order (risk-checked)
        self.cancel(order_id)        — cancel a pending order
        self.close_position(market)  — close all positions in a market
        self.close_all_positions()   — close everything
        self.subscribe(channel, ...) — declare a data subscription
        self.kelly_size(p, c)        — Kelly criterion sizing helper
        self.find_active_market(pat) — search active Polymarket markets
        self.position                — first open position (or None)
        self.positions               — dict of all open positions
        self.portfolio               — full portfolio state
        self.open_orders             — list of pending orders
        self.log                     — logger for this strategy
        self.config                  — dict from config.yaml
    """

    def __init__(
        self,
        config: dict,
        exchange: Any,
        state: StateManager,
        risk: RiskGuardian,
    ) -> None:
        """Called by the runner — do not override. Use configure() instead."""
        self._config = config
        self._exchange = exchange
        self._state = state
        self._risk = risk
        self._subscriptions: list[dict] = []
        self._open_orders: dict[str, Order] = {}
        self._portfolio = Portfolio(cash=config.get("initial_cash", 10_000.0))
        self.log = logging.getLogger(f"auspicium.strategy.{self.__class__.__name__}")
        self._indicator_log: dict[str, list[dict]] = {}
        self._indicator_meta: dict[str, dict] = {}
        self._last_tick_ts: int = 0  # Unix seconds — set by runner/engine before each on_data()

    # ------------------------------------------------------------------ #
    # Abstract methods — must be implemented by the quant                  #
    # ------------------------------------------------------------------ #

    @abstractmethod
    def configure(self) -> None:
        """Declare data subscriptions and load strategy parameters.

        Call self.subscribe() once per data channel you want to receive.
        Set any instance variables you'll use in on_data() here.

        Example::

            def configure(self):
                self.subscribe("ohlcv", source="binance", symbol="BTC-USDT")
                self.fast_period = self.config.get("fast_period", 12)
        """

    @abstractmethod
    async def on_data(self, tick: Any) -> None:
        """Called for every incoming StreamMessage from the WebSocket.

        Args:
            tick: A StreamMessage with .channel, .source, .symbol, .payload, .timestamp_ms
        """

    # ------------------------------------------------------------------ #
    # Optional lifecycle hooks                                             #
    # ------------------------------------------------------------------ #

    async def on_fill(self, fill: Fill) -> None:
        """Called when an order is filled. Default implementation logs the fill.

        Override to update internal state, track PnL, or react to executions.
        """
        self.log.info(
            "Fill: %s %s %s %.4f @ %.4f (fee %.4f, status=%s)",
            fill.side, fill.outcome, fill.market,
            fill.size, fill.price, fill.fee, fill.status,
        )

    async def on_shutdown(self) -> None:
        """Called when the runner receives SIGTERM. Default cancels all open orders."""
        self.log.info("Shutting down — cancelling %d open orders", len(self._open_orders))
        for order_id in list(self._open_orders.keys()):
            await self.cancel(order_id)

    # ------------------------------------------------------------------ #
    # Framework helpers                                                    #
    # ------------------------------------------------------------------ #

    def subscribe(
        self,
        channel: str,
        source: str | None = None,
        symbol: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Declare a WebSocket data subscription.

        Call this during configure(). The runner reads self._subscriptions
        after configure() returns and sets up the actual WS subscriptions.

        Multi-timeframe: call subscribe() once per interval you need. Ticks
        from each subscription carry the matching ``tick.interval`` so
        ``on_data()`` can dispatch:

            def configure(self):
                self.subscribe("ohlcv", source="binance", symbol="BTC-USDT", interval="5m")
                self.subscribe("ohlcv", source="binance", symbol="BTC-USDT", interval="1h")

            async def on_data(self, tick):
                if tick.interval == "1h":
                    self._update_trend_filter(tick)
                else:
                    self._on_bar(tick)

        Args:
            channel:  "ohlcv" | "trades" | "orderbook" | "polymarket"
            source:   "binance" | "polymarket"
            symbol:   trading pair (e.g. "BTC-USDT") or base asset ("BTC")
            interval: ohlcv bar interval ("1m" | "5m" | "1h" | "1d"). Only
                      meaningful for ohlcv — ignored on other channels.
        """
        sub: dict = {"channel": channel}
        if source is not None:
            sub["source"] = source
        if symbol is not None:
            sub["symbol"] = symbol
        sub.update(kwargs)
        self._subscriptions.append(sub)
        self.log.debug("Subscribed: %s", sub)

    async def submit(self, order: Order) -> None:
        """Submit an order through the risk guardian to the exchange adapter.

        Args:
            order: The order to submit.

        Raises:
            RiskLimitError: If any risk limit would be breached.
        """
        self._risk.check(order, self._portfolio, open_order_count=len(self._open_orders))
        self._open_orders[order.id] = order
        await self._exchange.submit(order)
        self.log.info(
            "Order submitted: %s %s %s %.4f @ %.4f [%s]",
            order.side, order.outcome, order.market, order.size, order.price, order.id,
        )

    async def cancel(self, order_id: str) -> bool:
        """Cancel a pending order.

        Args:
            order_id: The order ID to cancel.

        Returns:
            True if the order was found and cancelled, False otherwise.
        """
        cancelled = await self._exchange.cancel(order_id)
        if cancelled:
            self._open_orders.pop(order_id, None)
        return cancelled

    async def close_position(self, market: str) -> None:
        """Close all positions in a market by submitting an opposing order.

        Args:
            market: The market identifier (condition_id or symbol).
        """
        pos = self._portfolio.positions.get(market)
        if pos is None:
            self.log.warning("close_position: no position in %s", market)
            return
        close_side = "SELL" if pos.side == "LONG" else "BUY"
        close_price = pos.current_price if pos.current_price > 0 else pos.entry_price
        order = Order(
            market=market,
            side=close_side,
            outcome=pos.outcome,
            size=pos.size,
            price=close_price,
            order_type="MARKET",
        )
        await self.submit(order)

    async def close_all_positions(self) -> None:
        """Close every open position."""
        for market in list(self._portfolio.positions.keys()):
            await self.close_position(market)

    # ------------------------------------------------------------------ #
    # Conditional-order helpers                                            #
    # ------------------------------------------------------------------ #

    def _closing_side(self, position: Position) -> str:
        return "SELL" if position.side == "LONG" else "BUY"

    async def stop_loss(
        self,
        market: str,
        stop_price: float,
        size: float | None = None,
        limit_price: float | None = None,
    ) -> str:
        """Place a stop-loss on an existing position.

        Args:
            market:      Market identifier (same as :class:`Position.market`).
            stop_price:  Trigger price. For a LONG position this is below the
                         current price; for a SHORT it is above.
            size:        Size to close. Defaults to the full position.
            limit_price: If provided, submits STOP_LOSS_LIMIT at this price
                         once triggered. Otherwise STOP_LOSS (market) is used.

        Returns:
            The order id.
        """
        pos = self._portfolio.positions.get(market)
        if pos is None:
            raise ValueError(f"No position in {market}")
        order = Order(
            market=market,
            side=self._closing_side(pos),
            outcome=pos.outcome,
            size=size if size is not None else pos.size,
            price=limit_price if limit_price is not None else stop_price,
            stop_price=stop_price,
            order_type="STOP_LOSS_LIMIT" if limit_price is not None else ORDER_TYPE_STOP_LOSS,
        )
        await self.submit(order)
        return order.id

    async def take_profit(
        self,
        market: str,
        target_price: float,
        size: float | None = None,
        limit_price: float | None = None,
    ) -> str:
        """Place a take-profit on an existing position. Mirrors :meth:`stop_loss`."""
        pos = self._portfolio.positions.get(market)
        if pos is None:
            raise ValueError(f"No position in {market}")
        order = Order(
            market=market,
            side=self._closing_side(pos),
            outcome=pos.outcome,
            size=size if size is not None else pos.size,
            price=limit_price if limit_price is not None else target_price,
            stop_price=target_price,
            order_type="TAKE_PROFIT_LIMIT" if limit_price is not None else ORDER_TYPE_TAKE_PROFIT,
        )
        await self.submit(order)
        return order.id

    async def bracket(
        self,
        market: str,
        stop_price: float,
        take_profit_price: float,
        size: float | None = None,
    ) -> str:
        """Place an OCO bracket (stop-loss + take-profit) on an existing position.

        On Binance this uses the native OCO endpoint (both legs live on the
        exchange and are auto-cancelled when one fills). On Paper/Backtest the
        OCO is simulated client-side.
        """
        pos = self._portfolio.positions.get(market)
        if pos is None:
            raise ValueError(f"No position in {market}")
        order = Order(
            market=market,
            side=self._closing_side(pos),
            outcome=pos.outcome,
            size=size if size is not None else pos.size,
            # For Binance OCO: order.price is the stop-limit leg price — default
            # to stop_price; callers wanting a different stop-limit price can
            # submit the Order directly.
            price=stop_price,
            oco_stop_price=stop_price,
            oco_limit_price=take_profit_price,
            order_type=ORDER_TYPE_OCO,
        )
        await self.submit(order)
        return order.id

    async def trailing_stop(
        self,
        market: str,
        trail_percent: float | None = None,
        trail_amount: float | None = None,
        size: float | None = None,
    ) -> str:
        """Place a trailing stop on an existing position.

        Exactly one of ``trail_percent`` (fraction, e.g. 0.02 = 2%) or
        ``trail_amount`` (absolute quote-currency distance) must be supplied.
        Simulated client-side on Paper, Backtest, and Binance spot.
        """
        if trail_percent is None and trail_amount is None:
            raise ValueError("trailing_stop requires trail_percent or trail_amount")
        pos = self._portfolio.positions.get(market)
        if pos is None:
            raise ValueError(f"No position in {market}")
        order = Order(
            market=market,
            side=self._closing_side(pos),
            outcome=pos.outcome,
            size=size if size is not None else pos.size,
            price=pos.current_price or pos.entry_price,  # unused but required by pydantic
            trail_percent=trail_percent,
            trail_amount=trail_amount,
            order_type=ORDER_TYPE_TRAILING_STOP,
        )
        await self.submit(order)
        return order.id

    def kelly_size(self, p: float, c: float, fraction: float = 0.5) -> float:
        """Kelly criterion position sizing.

        Computes the optimal fraction of cash to risk based on edge and cost.

        Args:
            p:        Estimated probability of winning (e.g. 0.65).
            c:        Current cost / price of the contract (e.g. 0.50).
            fraction: Kelly fraction — use <1 for fractional Kelly (default 0.5).

        Returns:
            Dollar amount to risk (capped at available cash).

        Formula: f* = (p - c) / (1 - c)
        """
        if c >= 1.0 or p <= c:
            return 0.0
        f_star = (p - c) / (1.0 - c)
        dollar_size = f_star * fraction * self._portfolio.cash
        return max(0.0, dollar_size)

    def emit_indicator(
        self,
        name: str,
        value: float,
        pane: str = "primary",
        color: str | None = None,
        line_width: int = 1,
        levels: list[float] | None = None,
    ) -> None:
        """Log an indicator value for chart visualization.

        Call this inside on_data() to record indicator time series. Values are
        captured by the backtest engine (stored on BacktestResult.indicators) and
        by the live runner (persisted to SQLite via StateManager).

        Args:
            name:       Display name, e.g. "SMA(12)", "RSI(14)"
            value:      Numeric value at the current tick
            pane:       "primary" = overlay on price chart, "separate" = own pane below
            color:      Hex color, e.g. "#2196F3". Auto-assigned from palette if None.
            line_width: Line thickness in pixels (default 1)
            levels:     Horizontal reference lines, e.g. [30, 70] for RSI

        Example::

            async def on_data(self, tick):
                close = tick.payload["close"]
                fast_sma = sum(self.closes[-12:]) / 12
                self.emit_indicator("SMA(12)", fast_sma, pane="primary", color="#2196F3")

                rsi = self._compute_rsi(14)
                self.emit_indicator("RSI(14)", rsi, pane="separate", levels=[30, 70])
        """
        if name not in self._indicator_meta:
            if color is None:
                _palette = [
                    "#2196F3", "#FF9800", "#4CAF50", "#E91E63",
                    "#9C27B0", "#00BCD4", "#FFEB3B", "#795548",
                ]
                color = _palette[len(self._indicator_meta) % len(_palette)]
            self._indicator_meta[name] = {
                "pane": pane,
                "color": color,
                "line_width": line_width,
                "levels": levels,
            }
        self._indicator_log.setdefault(name, []).append(
            {"time": self._last_tick_ts, "value": value}
        )

    def find_active_market(self, slug_pattern: str) -> dict | None:
        """Search active Polymarket markets matching a pattern.

        Args:
            slug_pattern: Case-insensitive substring to match against
                          the market question or condition_id.

        Returns:
            A dict of market fields for the first match, or None.
            Fields: condition_id, question, base_asset, interval,
                    candle_open, candle_close, active, closed, resolution.
            Note: no live price fields (yes_price, best_ask, etc.) —
                  use tick.payload from on_data() for current prices.
        """
        try:
            from auspicium.connectors.rest import RestConnector
            df = RestConnector.markets(status="active")
            if df.empty:
                return None
            pattern = slug_pattern.lower()
            mask = (
                df["question"].str.lower().str.contains(pattern, na=False)
                | df["condition_id"].str.lower().str.contains(pattern, na=False)
            )
            matches = df[mask]
            if matches.empty:
                return None
            row = matches.iloc[0].to_dict()
            # Convert Timestamp objects to ISO strings for JSON-friendliness
            for k, v in row.items():
                try:
                    if hasattr(v, "isoformat"):
                        row[k] = v.isoformat()
                except Exception:
                    pass
            return row
        except Exception as exc:
            self.log.warning("find_active_market(%r) failed: %s", slug_pattern, exc)
            return None

    # ------------------------------------------------------------------ #
    # Properties                                                           #
    # ------------------------------------------------------------------ #

    @property
    def config(self) -> dict:
        """Strategy config dict loaded from config.yaml."""
        return self._config

    @property
    def portfolio(self) -> Portfolio:
        """Current portfolio state (cash, positions, PnL)."""
        return self._portfolio

    @property
    def positions(self) -> dict[str, Position]:
        """All open positions, keyed by market."""
        return self._portfolio.positions

    @property
    def position(self) -> Position | None:
        """The first open position, or None if flat."""
        return next(iter(self._portfolio.positions.values()), None)

    @property
    def open_orders(self) -> list[Order]:
        """List of currently pending orders."""
        return list(self._open_orders.values())

    @property
    def indicators(self) -> dict:
        """Current indicator log with metadata, keyed by indicator name.

        Returns a dict ready for the chart data contract:
        {
            "SMA(12)": {
                "name": "SMA(12)", "type": "line", "pane": "primary",
                "color": "#2196F3", "line_width": 1, "levels": None,
                "data": [{"time": 1704067200, "value": 42150.0}, ...]
            }, ...
        }
        """
        result = {}
        for name, data_points in self._indicator_log.items():
            meta = self._indicator_meta.get(name, {})
            result[name] = {
                "name": name,
                "type": "line",
                "pane": meta.get("pane", "primary"),
                "color": meta.get("color", "#2196F3"),
                "line_width": meta.get("line_width", 1),
                "levels": meta.get("levels"),
                "data": data_points,
            }
        return result
