"""WebSocket streaming connector — connects to Kong → FastAPI /v1/ws.

The API key is passed as a query parameter (?apikey=) because Kong's key-auth
plugin supports key_in_query=true for WebSocket upgrades (HTTP headers are not
accessible after the upgrade handshake in all proxies).

Usage (async)::

    from auspicium import stream

    async with stream.connect() as ws:
        await ws.subscribe("ohlcv", source="binance", symbol="BTC-USDT")
        await ws.subscribe("polymarket", source="polymarket", symbol="BTC")
        async for msg in ws:
            print(msg.channel, msg.payload)

Usage (sync helper)::

    stream.tail("ohlcv", source="binance", symbol="BTC-USDT", n=10)
"""
from __future__ import annotations

import asyncio
import json
import time
from contextlib import asynccontextmanager
from typing import AsyncIterator

import websockets
from websockets.exceptions import ConnectionClosed, InvalidStatus

from auspicium._version import __version__
from auspicium.config import get_config
from auspicium.errors import AuthError, ConnectionError
from auspicium.models import StreamMessage

_PING_INTERVAL = 15   # seconds between keepalive pings


class AuspiciumWebSocket:
    """Active WebSocket session returned by ``stream.connect()``."""

    def __init__(self, ws) -> None:
        self._ws = ws
        self._subscriptions: list[dict] = []

    async def subscribe(
        self,
        channel: str,
        source: str,
        symbol: str,
        interval: str = "1m",
        **kwargs,
    ) -> None:
        """Subscribe to a data channel.

        Args:
            channel:  ``"ohlcv"`` | ``"trades"`` | ``"orderbook"`` | ``"polymarket"``
            source:   ``"binance"`` | ``"polymarket"``
            symbol:   trading pair (e.g. ``"BTC-USDT"``) or base asset (``"BTC"`` for polymarket)
            interval: bar interval for ohlcv: ``"1m"`` | ``"5m"`` | ``"1h"`` | ``"1d"``.
                      Only sent when ``channel == "ohlcv"``.
        """
        msg = {
            "action": "subscribe",
            "channel": channel,
            "source": source,
            "symbol": symbol,
        }
        if channel == "ohlcv":
            msg["interval"] = interval
        self._subscriptions.append(msg)
        await self._ws.send(json.dumps(msg))

    async def unsubscribe(self, channel: str, source: str, symbol: str) -> None:
        """Unsubscribe from a data channel."""
        await self._ws.send(json.dumps(
            {"action": "unsubscribe", "channel": channel, "source": source, "symbol": symbol}
        ))

    def __aiter__(self) -> AsyncIterator[StreamMessage]:
        return self._message_iter()

    async def _message_iter(self) -> AsyncIterator[StreamMessage]:
        async for raw in self._ws:
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            msg_type = data.get("type")
            if msg_type in ("connected", "subscribed", "unsubscribed", "ping"):
                continue   # control frame — skip
            if msg_type == "error":
                detail = data.get("detail", "Unknown error")
                if "Unauthenticated" in detail or "401" in detail:
                    raise AuthError(detail)
                raise ConnectionError(f"Server error: {detail}")

            yield StreamMessage(
                channel=data.get("channel", ""),
                source=data.get("source", ""),
                symbol=data.get("symbol"),
                payload=data.get("payload", {}),
                timestamp_ms=data.get("timestamp_ms", int(time.time() * 1000)),
                interval=data.get("interval"),
            )


class StreamConnector:
    """WebSocket streaming connector.  Use as a module-level singleton via ``auspicium.stream``.

    Example::

        from auspicium import stream

        async with stream.connect() as ws:
            await ws.subscribe("ohlcv", source="binance", symbol="BTC-USDT")
            async for msg in ws:
                print(msg)
    """

    @staticmethod
    @asynccontextmanager
    async def connect() -> AsyncIterator[AuspiciumWebSocket]:
        """Async context manager that opens an authenticated WebSocket connection.

        Yields:
            :class:`AuspiciumWebSocket` — use to subscribe and iterate messages.
        """
        cfg = get_config()
        # Build URL with API key as query param (required for Kong key-auth on WS)
        url = f"{cfg.ws_url}?apikey={cfg.api_key}"

        try:
            async with websockets.connect(
                url,
                additional_headers={"User-Agent": f"auspicium-sdk/{__version__}"},
                ping_interval=_PING_INTERVAL,
                ping_timeout=10,
            ) as ws:
                yield AuspiciumWebSocket(ws)
        except InvalidStatus as exc:
            if exc.response.status_code == 401:
                raise AuthError("WebSocket rejected: invalid API key (HTTP 401)") from exc
            raise ConnectionError(f"WebSocket handshake failed: HTTP {exc.response.status_code}") from exc
        except ConnectionClosed as exc:
            if exc.rcvd and exc.rcvd.code == 4401:
                raise AuthError("WebSocket rejected: invalid API key (4401)") from exc
            raise ConnectionError(f"WebSocket connection closed unexpectedly: {exc}") from exc
        except OSError as exc:
            raise ConnectionError(f"Could not connect to {cfg.ws_url}: {exc}") from exc

    @staticmethod
    def tail(
        channel: str,
        source: str,
        symbol: str,
        n: int = 10,
    ) -> list[StreamMessage]:
        """Synchronous helper — collect ``n`` messages then return.

        Useful for quick inspection in scripts or notebooks without ``await``.

        Example::

            msgs = stream.tail("ohlcv", source="binance", symbol="BTC-USDT", n=5)
        """
        messages: list[StreamMessage] = []

        async def _collect():
            async with StreamConnector.connect() as ws:
                await ws.subscribe(channel, source=source, symbol=symbol)
                async for msg in ws:
                    messages.append(msg)
                    if len(messages) >= n:
                        break

        asyncio.run(_collect())
        return messages