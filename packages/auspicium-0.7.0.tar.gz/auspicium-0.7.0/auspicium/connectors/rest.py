"""REST connector — httpx against Kong → FastAPI (/v1/*).

All requests carry:
  X-API-Key: <key>
  User-Agent: auspicium-sdk/<version>

On HTTP 429 the connector waits Retry-After seconds and retries up to 3 times.
Kong rate-limit headers are parsed and exposed via RestConnector.last_rate_limit.
"""
from __future__ import annotations

import time
import warnings
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
import pandas as pd

from auspicium._version import __version__
from auspicium.config import get_config
from auspicium.errors import (
    AuthError,
    ConnectionError,
    QueryTimeoutError,
    RateLimitError,
    TierRestrictionError,
)

_MAX_RETRIES = 3


def _to_df(rows: list[dict], time_col: str = "time") -> pd.DataFrame:
    """Convert a list of row dicts to a DataFrame with a UTC DatetimeIndex."""
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    if time_col in df.columns:
        df[time_col] = pd.to_datetime(df[time_col], utc=True)
        df = df.set_index(time_col).sort_index()
    return df


class RestConnector:
    """Synchronous REST connector.  Use as a module-level singleton via ``auspicium.rest``.

    Example::

        from auspicium import rest
        df = rest.ohlcv("binance", "BTC-USDT", interval="5m", days=1)
    """

    _client: httpx.Client | None = None

    # Parsed from the last response — useful for quota monitoring
    last_rate_limit: dict = {}

    # ------------------------------------------------------------------ #
    # Internal                                                             #
    # ------------------------------------------------------------------ #

    @classmethod
    def _get_client(cls) -> httpx.Client:
        if cls._client is None or cls._client.is_closed:
            cfg = get_config()
            cls._client = httpx.Client(
                base_url=cfg.gateway_url,
                headers={
                    "X-API-Key": cfg.api_key,
                    "User-Agent": f"auspicium-sdk/{__version__}",
                },
                timeout=60.0,
            )
        return cls._client

    @classmethod
    def _request(cls, method: str, path: str, **kwargs) -> Any:
        client = cls._get_client()
        for attempt in range(_MAX_RETRIES):
            try:
                resp = client.request(method, path, **kwargs)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {path}: {exc}") from exc
            except httpx.TimeoutException as exc:
                raise QueryTimeoutError(
                    f"Request to {path} timed out. Try narrowing your time range."
                ) from exc

            # Parse rate-limit headers regardless of status (Kong 3.x uses -Minute suffix)
            cls.last_rate_limit = {
                k: resp.headers.get(k)
                for k in (
                    "x-ratelimit-limit-minute", "x-ratelimit-remaining-minute",
                    "ratelimit-limit", "ratelimit-remaining", "ratelimit-reset",
                )
                if resp.headers.get(k)
            }

            if resp.status_code == 401:
                raise AuthError("Invalid or missing API key (HTTP 401). Check AUSP_API_KEY.")
            if resp.status_code == 403:
                raise TierRestrictionError(
                    f"{resp.json().get('detail', 'Forbidden')} — upgrade your tier to access this."
                )
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("retry-after", 60))
                if attempt == 0:
                    warnings.warn(
                        f"Rate limited. Retrying in {retry_after}s "
                        f"({_MAX_RETRIES - 1 - attempt} attempt(s) left).",
                        stacklevel=3,
                    )
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(retry_after)
                    continue
                raise RateLimitError(
                    f"Rate limit exceeded after {_MAX_RETRIES} attempts. "
                    "Wait or upgrade your tier."
                )
            if resp.status_code == 504:
                raise QueryTimeoutError(
                    "Gateway timeout — query likely exceeded statement_timeout for your tier. "
                    "Narrow your time range or upgrade."
                )
            resp.raise_for_status()
            return resp.json()

        raise RateLimitError("Exhausted retries.")  # unreachable but satisfies type checkers

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    @classmethod
    def ohlcv(
        cls,
        source: str,
        symbol: str,
        interval: str = "1m",
        days: int = 1,
        from_ts: datetime | None = None,
        to_ts: datetime | None = None,
        limit: int = 500,
    ) -> pd.DataFrame:
        """OHLCV candlestick data.

        Args:
            source:   ``"binance"``
            symbol:   e.g. ``"BTC-USDT"``
            interval: ``"1m"`` | ``"5m"`` | ``"1h"`` | ``"1d"``
            days:     lookback in days (ignored when ``from_ts`` is set)
            from_ts:  explicit start (UTC-aware datetime)
            to_ts:    explicit end   (UTC-aware datetime, defaults to now)
            limit:    max rows (capped by tier)

        Returns:
            DataFrame with DatetimeIndex (UTC), columns: symbol, exchange, open, high, low, close, volume
        """
        params: dict = {"interval": interval, "limit": limit}
        if from_ts:
            params["from"] = from_ts.isoformat()
        else:
            params["from"] = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        if to_ts:
            params["to"] = to_ts.isoformat()

        data = cls._request("GET", f"/v1/ohlcv/{source}/{symbol.upper()}", params=params)
        return _to_df(data.get("data", []))

    @classmethod
    def trades(
        cls,
        source: str,
        symbol: str,
        hours: int = 1,
        limit: int = 500,
    ) -> pd.DataFrame:
        """Recent trades.

        Args:
            source: ``"binance"`` | ``"polymarket"``
            symbol: trading pair (e.g. ``"BTC-USDT"``) or Polymarket symbol
            hours:  lookback window
            limit:  max rows (capped by tier)

        Returns:
            DataFrame with DatetimeIndex (UTC).
        """
        params: dict = {
            "limit": limit,
            "from": (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(),
        }
        data = cls._request("GET", f"/v1/trades/{source}/{symbol.upper()}", params=params)
        return _to_df(data.get("data", []))

    @classmethod
    def orderbook(
        cls,
        source: str,
        symbol: str,
        depth: int = 20,
    ) -> dict:
        """Current order book snapshot.

        Returns:
            Dict with keys: time, symbol, exchange, bids, asks, spread, mid_price.
        """
        data = cls._request(
            "GET", f"/v1/orderbook/{source}/{symbol.upper()}",
            params={"depth": depth},
        )
        return data

    @classmethod
    def markets(
        cls,
        status: str = "active",
        base_asset: str | None = None,
    ) -> pd.DataFrame:
        """Polymarket prediction markets.

        Args:
            status:     ``"active"`` | ``"closed"`` | ``"all"``
            base_asset: filter by ``"BTC"`` | ``"ETH"`` | ``"SOL"``

        Returns:
            DataFrame with one row per market.
        """
        params: dict = {"status": status}
        if base_asset:
            params["base_asset"] = base_asset.upper()
        data = cls._request("GET", "/v1/markets", params=params)
        return _to_df(data.get("data", []), time_col="candle_open")

    @classmethod
    def cross_market(
        cls,
        granularity: str = "5m",
        base_asset: str | None = None,
        hours: int = 2,
        confirmed_only: bool = True,
    ) -> pd.DataFrame:
        """Joined Binance OHLCV × Polymarket implied-probability OHLCV.

        Args:
            granularity:    ``"1m"`` | ``"5m"``
            base_asset:     filter by ``"BTC"`` | ``"ETH"`` | ``"SOL"``
            hours:          lookback window
            confirmed_only: exclude ``is_provisional=True`` buckets

        Returns:
            DataFrame with DatetimeIndex (UTC) and all cross-OHLCV columns.
        """
        params: dict = {"granularity": granularity, "hours": hours}
        if base_asset:
            params["base_asset"] = base_asset.upper()
        if confirmed_only:
            params["confirmed_only"] = "true"
        data = cls._request("GET", "/v1/cross-market", params=params)
        return _to_df(data.get("data", []))

    @classmethod
    def me(cls) -> dict:
        """Return current user info: tier, limits, 30-day usage."""
        return cls._request("GET", "/v1/user/me")

    @classmethod
    def pairs(cls, source: str = "binance") -> list[str]:
        """List available trading pairs for a source."""
        data = cls._request("GET", "/v1/pairs", params={"source": source})
        return data.get("pairs", [])

    @classmethod
    def close(cls) -> None:
        """Close the underlying HTTP client (call when done in scripts)."""
        if cls._client and not cls._client.is_closed:
            cls._client.close()
            cls._client = None