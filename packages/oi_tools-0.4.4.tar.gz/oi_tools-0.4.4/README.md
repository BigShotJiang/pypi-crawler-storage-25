# oi-tools

[![PyPI version](https://img.shields.io/pypi/v/oi-tools)](https://pypi.org/project/oi-tools/)
[![docs](https://img.shields.io/badge/docs-latest-blue)](https://opportunityinsights.github.io/oi-tools)
[![Lint, type check, and test](https://github.com/OpportunityInsights/oi-tools/actions/workflows/tests.yml/badge.svg)](https://github.com/OpportunityInsights/oi-tools/actions/workflows/tests.yml)

## Installation

To install the most recent version of the package from PyPI:

```bash
# using uv (recommended)
uv add oi-tools

# using pip
pip install oi-tools
```
To install the most-recent development version from git:

```bash
uv add git+https://github.com/OpportunityInsights/oi-tools
pip install git+https://github.com/OpportunityInsights/oi-tools
```

At the moment, we support Python 3.9 and newer.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md).

