"""Helper functions related to disclosure.

- See `the procedures handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Procedures-Handbook.pdf>`_
  for information about the logistics/procedure of release.

- See `the methods handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf>`_
  for resources on disclosure avoidance methods (e.g. rounding, noise, local-area
  estimates).
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal, Mapping

import polars as pl

from oi_tools.polars_helpers import (
    IntoPolarsExpression,
    IntoPolarsSelector,
    to_expr,
    to_selector,
)

GeographicLevel = Literal["national", "state", "substate", "zip"]

MINIMUM_CELL_SIZES: Mapping[GeographicLevel, int] = {
    "national": 3,
    "state": 10,
    "substate": 20,
    "zip": 100,
}
"""The minimum number of observations for a valid cell,
taken from section V.A of the procedures handbook.
"""


def create_drb_folders(
    df: pl.DataFrame,
    output_folder: Path | str,
    output_filename: str,
    *,
    count_columns: IntoPolarsSelector = [],
    proportion_columns: IntoPolarsSelector = [],
    other_columns: IntoPolarsSelector = [],
    allow_nulls: bool = False,
    sample_size_column: IntoPolarsExpression = "n",
    overwrite: bool = False,
) -> int:
    """Round the specified columns and save both raw and rounded CSVs for release.

    Takes an input data frame and creates the following folder structure under
    ``output_folder``:

    .. code-block:: text

        {output_folder}/
          raw/{output_filename}.csv          # unmodified data
          to_disclose/{output_filename}.csv  # rounded/masked data

    Columns are rounded according to the rules described in
    :func:`round_and_mask_columns`.

    Parameters
    ----------
    df
        Input DataFrame. Should contain no null values unless ``allow_nulls=True``.
    output_folder
        Root directory for output (e.g. ``drb/2026_01_01/data``).
        Sub-directories ``raw/`` and ``to_disclose/`` are created automatically.
    output_filename
        Base name (without extension) for the output CSV files.
    count_columns
        Columns containing unweighted counts to be rounded per section V.B.3 of the
        handbook (see :func:`round_count_column`).
    proportion_columns
        Columns containing proportions or ratios to be rounded per section V.B.4 of
        the handbook (see :func:`round_proportion_column`).
    other_columns
        All other estimate columns (e.g. weighted means, regression
        coefficients) to be rounded to 4 significant figures per section V.B.1 of
        the handbook.
    sample_size_column
        Column containing the sample size.
    overwrite
        If ``False`` (default), raise :class:`FileExistsError` when either
        output file already exists.
    allow_nulls
        If ``False`` (default), assert that neither the input nor the rounded
        DataFrame contains null values.

    Returns
    -------
    int
        Total number of non-null estimates in the output DataFrame.

    Raises
    ------
    AssertionError
        If ``allow_nulls=False`` and nulls are found in the input or output
        DataFrame.
    FileExistsError
        If ``overwrite=False`` and an output file already exists.
    """
    if not allow_nulls:
        assert df.drop_nulls().height == df.height, (
            "found null values in input dataframe"
        )

    # create and check rounded df
    df_rounded = df.pipe(
        round_and_mask_columns,
        count_columns=count_columns,
        proportion_columns=proportion_columns,
        other_columns=other_columns,
        n=sample_size_column,
    )

    # TODO: print how many estimates were suppressed

    if not allow_nulls:
        assert df_rounded.drop_nulls().height == df_rounded.height, (
            "found null values in output dataframe"
        )

    # set up output paths/folders
    raw_file = Path(output_folder) / "raw" / f"{output_filename}.csv"
    rounded_file = Path(output_folder) / "to_disclose" / f"{output_filename}.csv"

    if not overwrite and (raw_file.exists() or rounded_file.exists()):
        raise FileExistsError(f"{output_filename} already exists in {output_folder}")

    raw_file.parent.mkdir(exist_ok=True, parents=True)
    rounded_file.parent.mkdir(exist_ok=True, parents=True)

    df.write_csv(raw_file)
    df_rounded.write_csv(rounded_file)

    # return number of non-null estimates
    estimate_cols = (
        to_selector(count_columns)
        | to_selector(proportion_columns)
        | to_selector(other_columns)
    )
    return df.select(pl.sum_horizontal(estimate_cols.is_not_null().sum())).item()


def round_and_mask_columns(
    df: pl.DataFrame,
    *,
    count_columns: IntoPolarsSelector = [],
    proportion_columns: IntoPolarsSelector = [],
    other_columns: IntoPolarsSelector = [],
    n: IntoPolarsExpression = "n",
    geographic_level: GeographicLevel = "national",
) -> pl.DataFrame:
    """Mask small cells and round the columns of a DataFrame for disclosure.

    Adheres to the rules defined in sections V.A and V.B of
    `the disclosure methods handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf>`_:

    - Small cells are censored according to Section V.A (see :func:`mask_small_cells`).
    - Counts are rounded according to section V.B.3 (see :func:`round_count_column`).
    - Ratio/proportions are rounded according to section V.B.4
      (see :func:`round_proportion_column`).
    - Other estimates (including regression output and weighted means/variances)
      are rounded to four significant figures (see section V.B.1).

    Parameters
    ----------
    df
        Input DataFrame to round and mask.
    count_columns
        Columns containing unweighted counts (rounded per section V.B.3).
    proportion_columns
        Columns containing proportions or ratios (rounded per section V.B.4).
    other_columns
        All other estimate columns (rounded to 4 significant figures).
    n
        The sample size used to determine the rounding rule.
    geographic_level
        Geographic level of the estimates, used to determine the minimum cell
        size threshold (see :data:`MINIMUM_CELL_SIZES`).

    Returns
    -------
    pl.DataFrame
        A copy of ``df`` with the specified columns masked and rounded.
    """
    n = to_expr(n)

    return df.with_columns(
        # counts
        to_selector(count_columns)
        .pipe(mask_small_cells, n, geographic_level)
        .pipe(round_count_column, n),
        # proportions
        to_selector(proportion_columns)
        .pipe(mask_small_cells, n, geographic_level)
        .pipe(round_proportion_column, n),
        # other
        to_selector(other_columns)
        .pipe(mask_small_cells, n, geographic_level)
        .round_sig_figs(4),
    )


def mask_small_cells(
    x: pl.Expr,
    n: pl.Expr,
    geographic_level: GeographicLevel,
) -> pl.Expr:
    """Mask cells that fail the cell-size cutoffs.

    From section V.A of `the disclosure methods handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf>`_:

      For Title 26 counts and estimates from Internal Revenue Service (IRS) data and
      commingled data (from the Census Bureau and the IRS), we enforce the following
      thresholds based on IRS requirements:

      - At least 3 entities (unique firms, persons, or households) for national estimates
      - At least 10 entities for state-level estimates
      - At least 20 entities for substate-level estimates, except for zip codes
      - At least 100 entities for ZIP code-level estimates

    Parameters
    ----------
    x
        The expression to mask.
    n
        The sample size used to determine the suppression rule.
    geographic_level
        Geographic level used to look up the minimum cell size in
        :data:`MINIMUM_CELL_SIZES`.

    Returns
    -------
    pl.Expr
        ``x`` where ``n`` meets the threshold, ``null`` otherwise.
    """
    return pl.when(n >= MINIMUM_CELL_SIZES[geographic_level]).then(x).otherwise(None)


def round_count_column(col: pl.Expr, n: pl.Expr) -> pl.Expr:
    """Round a count column to the appropriate precision.

    From section V.B.3 of `the disclosure methods handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf>`_:

      The rounding rule for unweighted counts is as follows:

      - If N is less than 15, report N < 15
      - If N is between 15 and 99, round to the nearest 10
      - If N is between 100-999, round to the nearest 50
      - If N is between 1,000-9,999, round to the nearest 100
      - If N is between 10,000-99,999, round to the nearest 500
      - If N is between 100,000-999,999, round to the nearest 1,000
      - If N is 1,000,000 or more, round to four significant digits as described earlier.

    Parameters
    ----------
    col
        The count expression to round.
    n
        The sample size used to determine the rounding rule.

    Returns
    -------
    pl.Expr
        A Polars expression with rounded values. Returns null when n < 15.
    """
    x = (
        pl.when(n < 15)
        .then(None)  # NOTE: do we want to differentiate "N <= 15" from null?
        .when(n < 100)
        .then((col / 10).round(0) * 10)
        .when(n < 1_000)
        .then((col / 50).round(0) * 50)
        .when(n < 10_000)
        .then((col / 100).round(0) * 100)
        .when(n < 100_000)
        .then((col / 500).round(0) * 500)
        .when(n < 1_000_000)
        .then((col / 1_000).round(0) * 1_000)
        .otherwise(col.round_sig_figs(4))
    )

    try:
        return x.alias(col.meta.output_name())
    except pl.exceptions.ComputeError:
        return x


def round_proportion_column(col: pl.Expr, n: pl.Expr) -> pl.Expr:
    """Round a non-count column to the appropriate number of significant figures.

    From section V.B.4 of `the disclosure methods handbook <https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf>`_:

      For thresholds based on an unweighted denominator (D) and an unrounded unweighted
      proportion (P):

      - If 15 <= D < 100 then P should be rounded to 1 significant digit
      - Else if D < 1,000 then P should be rounded to no more than 2 significant digits
      - Else if D < 10,000 then P should be rounded to no more than 3 significant digits
      - Else if D >= 10,000 then P should be rounded to no more than 4 significant digits.

    Parameters
    ----------
    col
        The proportion/ratio expression to round.
    n
        Denominator used to determine the number of significant digits.

    Returns
    -------
    pl.Expr
        A Polars expression with rounded values. Returns null when n < 15.
    """
    x = (
        pl.when(n < 15)
        .then(None)
        .when(n < 100)
        .then(col.round_sig_figs(1))
        .when(n < 1_000)
        .then(col.round_sig_figs(2))
        .when(n < 10_000)
        .then(col.round_sig_figs(3))
        .otherwise(col.round_sig_figs(4))
    )

    try:
        return x.alias(col.meta.output_name())
    except pl.exceptions.ComputeError:
        return x
