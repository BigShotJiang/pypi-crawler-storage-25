"""Client for the U.S. Census Bureau API.

The three main entry points are:

- :func:`get_variables`: fetch any Census variables from any dataset and
  year(s), returning a long-format DataFrame with one row per
  (year, geography, variable).
- :func:`get_acs`: a convenience wrapper around :func:`get_variables` for the
  American Community Survey; automatically fetches both estimates and margins
  of error and optionally computes standard errors.
- :func:`get_metadata`: retrieve variable metadata (concept names and labels)
  for a given dataset and year(s).

To find variable codes, search by topic at https://data.census.gov or browse
the available variables for a specific dataset and year via the Census API
explorer at https://api.census.gov/data.html.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.parse
from collections.abc import Sequence
from functools import reduce
from pathlib import Path
from typing import Any, get_args

import httpx
import joblib
import polars as pl
import us
from polars import selectors as cs

from oi_tools.census_api.types import AcsVersion, Dataset, Geography, State

BASE_API_URL = "https://api.census.gov/data/{year}/{dataset}"

MOST_RECENT_ACS_YEAR = 2023

# deal with odd values
# see: https://www.census.gov/data/developers/data-sets/
#  ... acs-1year/notes-on-acs-estimate-and-annotation-values.html
ACS_EXCEPTION_VALUES = {str(-111_111_111 * d) for d in range(1, 10)}


def get_variables(
    dataset: Dataset,
    *,
    years: int | Sequence[int],
    variables: str | Sequence[str],
    geography: Geography = "us",
    state: State | None = None,
    include_metadata: bool = True,
    handle_exception_values: bool = True,
    api_key: str | None = None,
) -> pl.DataFrame:
    """Fetch variables from the Census API.

    Parameters
    ----------
    dataset
        Dataset identifier, e.g. ``"acs/acs5"`` or ``"dec/sf3"``.
        See :attr:`Dataset` for more info.
    years
        One or more survey years.
    variables
        Variable codes to retrieve. Accepts ``"group(CODE)"`` syntax to
        fetch entire variable groups.
    geography
        Geographic level of aggregation.
    state
        Two-letter state abbreviation. Required for ``"tract"`` and
        ``"block group"`` geographies.
    include_metadata
        If ``True``, join variable metadata (concept, label) onto the
        result.
    handle_exception_values
        If ``True``, replace Census exception sentinel values with null.
    api_key
        Census API key. Falls back to the ``CENSUS_API_KEY`` environment
        variable if not provided.

    Returns
    -------
    pl.DataFrame
        DataFrame with one row per (year, geography, variable).

    Examples
    --------
    Fetch county-level total population from the 2010 Decennial Census:

    >>> import oi_tools.census_api as census
    >>> df = census.get_variables(
    ...     "dec/sf1",
    ...     years=2010,
    ...     variables="P001001",
    ...     geography="county",
    ...     include_metadata=True,
    ... )
    >>> df.columns
    ['year', 'county', 'concept', 'label', 'variable', 'value']
    >>> print(df)
    shape: (3_221, 6)
    ┌──────┬────────┬──────────────────┬───────────┬──────────┬──────────┐
    │ year ┆ county ┆ concept          ┆ label     ┆ variable ┆ value    │
    │ ---  ┆ ---    ┆ ---              ┆ ---       ┆ ---      ┆ ---      │
    │ i32  ┆ cat    ┆ str              ┆ list[str] ┆ str      ┆ f32      │
    ╞══════╪════════╪══════════════════╪═══════════╪══════════╪══════════╡
    │ 2010 ┆ 01001  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 54571.0  │
    │ 2010 ┆ 01003  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 182265.0 │
    │ 2010 ┆ 01005  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 27457.0  │
    │ 2010 ┆ 01007  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 22915.0  │
    │ 2010 ┆ 01009  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 57322.0  │
    │ …    ┆ …      ┆ …                ┆ …         ┆ …        ┆ …        │
    │ 2010 ┆ 72145  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 59662.0  │
    │ 2010 ┆ 72147  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 9301.0   │
    │ 2010 ┆ 72149  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 26073.0  │
    │ 2010 ┆ 72151  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 37941.0  │
    │ 2010 ┆ 72153  ┆ TOTAL POPULATIO… ┆ ["Total"] ┆ P001001  ┆ 42043.0  │
    └──────┴────────┴──────────────────┴───────────┴──────────┴──────────┘

    Multiple years and variables are supported:

    >>> df = census.get_variables(
    ...     "dec/sf1",
    ...     years=[2000, 2010],
    ...     variables=["P001001", "P002001"],
    ...     geography="county",
    ...     include_metadata=False,
    ... )
    >>> df.get_column("year").unique().sort().to_list()
    [2000, 2010]
    >>> df.get_column("variable").unique().sort().to_list()
    ['P001001', 'P002001']

    Use ``group(CODE)`` syntax to fetch all variables in a group at once:

    >>> df = census.get_variables(
    ...     "dec/sf3",
    ...     years=2000,
    ...     variables="group(P148A)",
    ...     geography="county",
    ... )
    >>> print(df)
    shape: (54_723, 6)
    ┌──────┬────────┬──────────────────┬──────────────────┬──────────┬─────────┐
    │ year ┆ county ┆ concept          ┆ label            ┆ variable ┆ value   │
    │ ---  ┆ ---    ┆ ---              ┆ ---              ┆ ---      ┆ ---     │
    │ i32  ┆ cat    ┆ str              ┆ list[str]        ┆ str      ┆ f32     │
    ╞══════╪════════╪══════════════════╪══════════════════╪══════════╪═════════╡
    │ 2000 ┆ 01001  ┆ SEX BY EDUCATIO… ┆ ["Total"]        ┆ P148A001 ┆ 22790.0 │
    │ 2000 ┆ 01001  ┆ SEX BY EDUCATIO… ┆ ["Total", "Male… ┆ P148A002 ┆ 10954.0 │
    │ 2000 ┆ 01001  ┆ SEX BY EDUCATIO… ┆ ["Total", "Male… ┆ P148A003 ┆ 424.0   │
    │ 2000 ┆ 01001  ┆ SEX BY EDUCATIO… ┆ ["Total", "Male… ┆ P148A004 ┆ 1503.0  │
    │ 2000 ┆ 01001  ┆ SEX BY EDUCATIO… ┆ ["Total", "Male… ┆ P148A005 ┆ 3461.0  │
    │ …    ┆ …      ┆ …                ┆ …                ┆ …        ┆ …       │
    │ 2000 ┆ 72153  ┆ SEX BY EDUCATIO… ┆ ["Total", "Fema… ┆ P148A013 ┆ 2747.0  │
    │ 2000 ┆ 72153  ┆ SEX BY EDUCATIO… ┆ ["Total", "Fema… ┆ P148A014 ┆ 1255.0  │
    │ 2000 ┆ 72153  ┆ SEX BY EDUCATIO… ┆ ["Total", "Fema… ┆ P148A015 ┆ 1107.0  │
    │ 2000 ┆ 72153  ┆ SEX BY EDUCATIO… ┆ ["Total", "Fema… ┆ P148A016 ┆ 2104.0  │
    │ 2000 ┆ 72153  ┆ SEX BY EDUCATIO… ┆ ["Total", "Fema… ┆ P148A017 ┆ 368.0   │
    └──────┴────────┴──────────────────┴──────────────────┴──────────┴─────────┘
    >>> for label in df.get_column("label").unique().sort().to_list():
    ...     print(label)
    ['Total']
    ['Total', 'Female']
    ['Total', 'Female', '9th to 12th grade, no diploma']
    ['Total', 'Female', 'Associate degree']
    ['Total', 'Female', "Bachelor's degree"]
    ['Total', 'Female', 'Graduate or professional degree']
    ['Total', 'Female', 'High school graduate (includes equivalency)']
    ['Total', 'Female', 'Less than 9th grade']
    ['Total', 'Female', 'Some college, no degree']
    ['Total', 'Male']
    ['Total', 'Male', '9th to 12th grade, no diploma']
    ['Total', 'Male', 'Associate degree']
    ['Total', 'Male', "Bachelor's degree"]
    ['Total', 'Male', 'Graduate or professional degree']
    ['Total', 'Male', 'High school graduate (includes equivalency)']
    ['Total', 'Male', 'Less than 9th grade']
    ['Total', 'Male', 'Some college, no degree']
    """
    api_key = _get_api_key(api_key)

    if geography in ("tract", "block group") and state is None:
        raise ValueError("a state filter is required for areas smaller than county")

    if isinstance(years, int):
        years = [years]

    if isinstance(variables, str):
        variables = [variables]

    params = {
        "get": ",".join(variables),
        "for": f"{geography}:*",
    }

    if state:
        state_fips = us.states.mapping("abbr", "fips").get(state)
        params |= {
            # block group required county:* for some reason
            "in": f"state:{state_fips} county:*"
            if geography == "block group"
            else f"state:{state_fips}"
        }

    # get base name for all the groups
    is_variable = reduce(
        lambda x, y: x | y,
        [
            cs.starts_with(v.removeprefix("group(").removesuffix(")"))
            if v.startswith("group(")
            else cs.matches(v)
            for v in variables
        ],
    )

    # construct endpoint urls
    urls = [BASE_API_URL.format(year=year, dataset=dataset) for year in years]

    # fetch api responses
    responses = [_api_req(url, api_key, params) for url in urls]

    # convert to dataframe
    estimates = (
        pl.concat(
            _df_from_api_response(response).with_columns(year=year)
            for year, response in zip(years, responses)
        )
        .with_columns(
            reduce(
                lambda x, y: x + y,
                (pl.col(g) for g in _geo_dependencies(geography)),
            ).alias(geography)
        )
        .unpivot(on=is_variable, index=["year", geography])
        .with_columns(
            pl.col(geography).cast(pl.Categorical()),
            # deal with exception values if requested
            pl.when(
                pl.col("value").is_in(ACS_EXCEPTION_VALUES).not_()
                if handle_exception_values
                else True
            )
            .then("value")
            .cast(pl.Float32),
        )
        .sort("year", geography, "variable")
    )

    # add metadata if requested
    if not include_metadata:
        return estimates.pipe(_arrange_columns)

    metadata = get_metadata(dataset, years, api_key=api_key)

    return estimates.join(
        metadata,
        on=["year", "variable"],
        how="left",
        validate="m:1",
    ).pipe(_arrange_columns)


def get_acs(
    variables: Sequence[str] | str,
    *,
    years: Sequence[int] | int | None = None,
    acs_version: AcsVersion = "acs5",
    geography: Geography = "us",
    state: State | None = None,
    include_metadata: bool = True,
    include_ses: bool = True,
    handle_exception_values: bool = True,
    api_key: str | None = None,
) -> pl.DataFrame:
    """Retrieve American Community Survey data.

    This function is a thin wrapper around :func:`get_variables` that
    offers a convenient way to get ACS survey data.

    Parameters
    ----------
    variables
        ACS variable codes. Trailing ``E`` or ``M`` suffixes are
        stripped; both estimates and margins of error are fetched
        automatically when ``include_ses=True``.
    years
        Survey years to retrieve. Defaults to all available years for
        the given ``acs_version``.
    acs_version
        ACS product: ``"acs1"``, ``"acs3"``, or ``"acs5"``.
    geography
        Geographic level of aggregation.
    state
        Two-letter state abbreviation. Required for ``"tract"`` and
        ``"block group"`` geographies.
    include_metadata
        If ``True``, join variable metadata (concept, label) onto the
        result.
    include_ses
        If ``True``, include a ``se`` column with standard errors
        derived from the margin of error.
    handle_exception_values
        If ``True``, replace Census exception sentinel values with null.
    api_key
        Census API key. Falls back to the ``CENSUS_API_KEY`` environment
        variable if not provided.

    Returns
    -------
    pl.DataFrame
        DataFrame with one row per (year, geography, variable).

    Examples
    --------
    Fetch median household income at the county level, without standard errors
    or metadata:

    >>> import oi_tools.census_api as census
    >>> df = census.get_acs(
    ...     "B19013_001",
    ...     years=2021,
    ...     geography="county",
    ...     include_ses=False,
    ...     include_metadata=False,
    ... )
    >>> df.columns
    ['year', 'county', 'variable', 'value']
    >>> print(df)
    shape: (3_221, 4)
    ┌──────┬────────┬────────────┬─────────┐
    │ year ┆ county ┆ variable   ┆ value   │
    │ ---  ┆ ---    ┆ ---        ┆ ---     │
    │ i32  ┆ cat    ┆ str        ┆ f32     │
    ╞══════╪════════╪════════════╪═════════╡
    │ 2021 ┆ 01001  ┆ B19013_001 ┆ 62660.0 │
    │ 2021 ┆ 01003  ┆ B19013_001 ┆ 64346.0 │
    │ 2021 ┆ 01005  ┆ B19013_001 ┆ 36422.0 │
    │ 2021 ┆ 01007  ┆ B19013_001 ┆ 54277.0 │
    │ 2021 ┆ 01009  ┆ B19013_001 ┆ 52830.0 │
    │ …    ┆ …      ┆ …          ┆ …       │
    │ 2021 ┆ 72145  ┆ B19013_001 ┆ 21507.0 │
    │ 2021 ┆ 72147  ┆ B19013_001 ┆ 14942.0 │
    │ 2021 ┆ 72149  ┆ B19013_001 ┆ 20722.0 │
    │ 2021 ┆ 72151  ┆ B19013_001 ┆ 17267.0 │
    │ 2021 ┆ 72153  ┆ B19013_001 ┆ 16444.0 │
    └──────┴────────┴────────────┴─────────┘

    Include standard errors and metadata (default):

    >>> df = census.get_acs(
    ...     "B19013_001",
    ...     years=2021,
    ...     geography="county",
    ... )
    >>> df.columns
    ['year', 'county', 'concept', 'label', 'variable', 'value', 'se']

    Multiple years and variables are supported:

    >>> df = census.get_acs(
    ...     ["B19013_001", "B01003_001"],
    ...     years=[2019, 2021],
    ...     geography="county",
    ...     include_ses=False,
    ...     include_metadata=True,
    ... )
    >>> print(df)
    shape: (12_882, 6)
    ┌──────┬────────┬──────────────────┬──────────────────┬────────────┬──────────┐
    │ year ┆ county ┆ concept          ┆ label            ┆ variable   ┆ value    │
    │ ---  ┆ ---    ┆ ---              ┆ ---              ┆ ---        ┆ ---      │
    │ i32  ┆ cat    ┆ str              ┆ list[str]        ┆ str        ┆ f32      │
    ╞══════╪════════╪══════════════════╪══════════════════╪════════════╪══════════╡
    │ 2019 ┆ 01001  ┆ TOTAL POPULATIO… ┆ ["Estimate", "T… ┆ B01003_001 ┆ 55380.0  │
    │ 2019 ┆ 01001  ┆ MEDIAN HOUSEHOL… ┆ ["Estimate", "M… ┆ B19013_001 ┆ 58731.0  │
    │ 2019 ┆ 01003  ┆ TOTAL POPULATIO… ┆ ["Estimate", "T… ┆ B01003_001 ┆ 212830.0 │
    │ 2019 ┆ 01003  ┆ MEDIAN HOUSEHOL… ┆ ["Estimate", "M… ┆ B19013_001 ┆ 58320.0  │
    │ 2019 ┆ 01005  ┆ TOTAL POPULATIO… ┆ ["Estimate", "T… ┆ B01003_001 ┆ 25361.0  │
    │ …    ┆ …      ┆ …                ┆ …                ┆ …          ┆ …        │
    │ 2021 ┆ 72149  ┆ MEDIAN HOUSEHOL… ┆ ["Estimate", "M… ┆ B19013_001 ┆ 20722.0  │
    │ 2021 ┆ 72151  ┆ TOTAL POPULATIO… ┆ ["Estimate", "T… ┆ B01003_001 ┆ 31047.0  │
    │ 2021 ┆ 72151  ┆ MEDIAN HOUSEHOL… ┆ ["Estimate", "M… ┆ B19013_001 ┆ 17267.0  │
    │ 2021 ┆ 72153  ┆ TOTAL POPULATIO… ┆ ["Estimate", "T… ┆ B01003_001 ┆ 34704.0  │
    │ 2021 ┆ 72153  ┆ MEDIAN HOUSEHOL… ┆ ["Estimate", "M… ┆ B19013_001 ┆ 16444.0  │
    └──────┴────────┴──────────────────┴──────────────────┴────────────┴──────────┘
    """
    api_key = _get_api_key(api_key)

    if isinstance(variables, str):
        variables = [variables]

    dataset = f"acs/{acs_version}"

    # if years isn't passed, use all available years
    years = years or range(2004 + int(acs_version[-1]), MOST_RECENT_ACS_YEAR + 1)

    # standardize acs variable names (make sure they all end in E)
    base_variable_names = {v.strip("EM") for v in variables}
    variables = [f"{v}E" for v in base_variable_names]

    # include margins of error
    if include_ses:
        variables += [f"{v}M" for v in base_variable_names]

    # call to API
    response = get_variables(
        dataset=dataset,
        variables=variables,
        years=years,
        geography=geography,
        state=state,
        include_metadata=False,
        handle_exception_values=handle_exception_values,
        api_key=api_key,
    )

    # reshape so moes and estimates are the same row
    df = (
        response.with_columns(
            pl.col("variable").str.strip_chars_end("EM"),
            pl.col("variable").str.extract("(E|M)$").alias("type"),
        )
        .pivot(
            on="type",
            values="value",
            index=["year", geography, "variable"],
            maintain_order=True,
        )
        .rename({"E": "value"})
    )

    if include_ses:
        df = df.with_columns(pl.col("M").mul(1 / 1.645).alias("se")).drop("M")

    if not include_metadata:
        return df.pipe(_arrange_columns)

    return df.join(
        get_metadata(dataset, years, api_key=api_key),
        how="left",
        left_on=["year", pl.col("variable") + "E"],
        right_on=["year", "variable"],
        validate="m:1",
    ).pipe(_arrange_columns)


def get_metadata(
    dataset: Dataset,
    years: int | Sequence[int],
    *,
    api_key: str | None = None,
) -> pl.DataFrame:
    """Retrieve variable metadata for a Census dataset.

    Parameters
    ----------
    dataset
        Dataset identifier, e.g. ``"acs/acs5"``, ``"dec/sf3"``, or ``geoinfo``.
        See :attr:`Dataset` for more info.
    years
        One or more survey years.
    api_key
        Census API key. Falls back to the ``CENSUS_API_KEY`` environment
        variable if not provided.

    Returns
    -------
    pl.DataFrame
        DataFrame with columns ``year``, ``variable``, ``group``, ``row``,
        ``concept``, and ``label``.

    Examples
    --------
    Retrieve variable metadata for the ACS 5-year survey:

    >>> import oi_tools.census_api as census
    >>> df = census.get_metadata("acs/acs5", 2021)
    >>> df.columns
    ['year', 'variable', 'group', 'row', 'concept', 'label']
    """
    api_key = _get_api_key(api_key)

    if not isinstance(years, int):
        return pl.concat(get_metadata(dataset, year, api_key=api_key) for year in years)

    url = BASE_API_URL.format(year=years, dataset=dataset) + "/variables.json"
    response = _api_req(url, api_key).get("variables")

    return (
        pl.from_records(
            [{"variable": k} | v for k, v in response.items()],
            orient="row",
        )
        .filter(pl.col("predicateOnly").is_null())
        .select(
            pl.lit(years).alias("year"),
            "variable",
            pl.col("variable")
            .str.extract_groups("(?P<group>.*+)_(?<row>.*+E)")
            .struct.unnest(),
            "concept",
            pl.col("label").str.split("!!"),
        )
        .sort(pl.col("variable"))
    )


def _geo_dependencies(geo: Geography) -> tuple[Geography, ...]:
    """Get the higher-levels of nested geographies that are needed for an API request.

    For example, ``"tract" -> ("state", "county", "tract")``.
    """
    if geo == "county":
        return ("state", "county")

    if geo == "tract":
        return ("state", "county", "tract")

    if geo == "block group":
        return ("state", "county", "tract", "block group")

    return (geo,)


def _df_from_api_response(response: list[list[Any]]) -> pl.DataFrame:
    return pl.from_records(response[1:], schema=response[0], orient="row")


def _arrange_columns(df: pl.DataFrame) -> pl.DataFrame:
    all_columns = [
        "year",
        *get_args(Geography),
        "concept",
        "label",
        "variable",
        "value",
        "se",
    ]

    return df.select(c for c in all_columns if c in df.columns)


def _get_api_key(api_key: str | None) -> str | None:
    resolved = api_key or os.environ.get("CENSUS_API_KEY")
    if not resolved:
        logging.warning(
            "Unable to find Census API key in the environment. Falling back to no API key."
        )
    return resolved


API_CACHE = joblib.Memory(Path.home() / ".cache/oi-tools/census", verbose=False)


@API_CACHE.cache()
def _api_req(
    url: str, api_key: str | None, params: dict[str, Any] | None = None
) -> Any:
    """Make a cached GET request to the Census API."""
    if params is None:
        params = {}
    if api_key:
        params = params | {"key": api_key}

    logging.info("request: %s %s", url, params)
    response = httpx.get(url, params=params)

    if not response.is_success:
        raise RuntimeError(
            f"unexpected response from Census API\n{response.url}\n\n{response.text}"
        )

    try:
        return json.loads(response.content)
    except Exception:
        raise RuntimeError(
            "unable to decode response from Census API:"
            + "\n"
            + urllib.parse.unquote(str(response.url))
            + "\n\n"
            + ("\n".join(response.text.splitlines()[:5]))
        )
