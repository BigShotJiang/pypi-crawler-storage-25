"""Type definitions for the Census Bureau API."""

from __future__ import annotations

from typing import Literal, Union

# TODO: add more surveys
Dataset = Union[Literal["acs/acs5", "dec/sf3", "geoinfo"], str]
"""A census dataset identifier string.

See https://www.census.gov/data/developers/data-sets.html for all possible options.
"""

Geography = Literal[
    "us", "region", "division", "state", "county", "tract", "block group"
]

AcsVersion = Literal["acs1", "acs3", "acs5"]

# TODO: combine this with the geo submodule at some point
State = Literal[
    # states
    "AL",
    "AK",
    "AZ",
    "AR",
    "CA",
    "CO",
    "CT",
    "DE",
    "FL",
    "GA",
    "HI",
    "ID",
    "IL",
    "IN",
    "IA",
    "KS",
    "KY",
    "LA",
    "ME",
    "MD",
    "MA",
    "MI",
    "MN",
    "MS",
    "MO",
    "MT",
    "NE",
    "NV",
    "NH",
    "NJ",
    "NM",
    "NY",
    "NC",
    "ND",
    "OH",
    "OK",
    "OR",
    "PA",
    "RI",
    "SC",
    "SD",
    "TN",
    "TX",
    "UT",
    "VT",
    "VA",
    "WA",
    "WV",
    "WI",
    "WY",
    # dc
    "DC",
    # territories
    # "AS",
    # "GU",
    # "MP",
    # "PR",
    # "VI",
]
