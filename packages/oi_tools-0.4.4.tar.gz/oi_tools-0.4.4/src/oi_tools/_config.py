from __future__ import annotations

import os
from pathlib import Path
from typing import get_type_hints


class Config:
    PBS_POLL_DELAY: float = 5.0
    """Seconds between status polls when waiting for a job to finish."""
    PBS_DEFAULT_CPUS: int = 4
    """Default number of CPU cores to request when submitting a job."""
    PBS_DEFAULT_MEM: str = "8G"
    """Default memory to request when submitting a job."""
    PBS_LOG_FOLDER: Path = Path("logs")
    """Default directory for job log files."""
    PBS_MAX_CONCURRENT_JOBS: int = 7
    """Maximum number of jobs to run simultaneously via :func:`~oi_tools.pbs.submit_many_jobs`."""

    @classmethod
    def from_env(cls, *, prefix: str = "") -> Config:
        # create config object with default values
        config = cls()

        # if the appropriate env var is set, overwrite the
        # default with the value from the environment
        for name, type_ in get_type_hints(cls).items():
            val = os.environ.get(prefix + name)

            if val is not None:
                val = type_(val)  # cast to the appropriate type
                setattr(config, name, val)

        return config


CONFIG = Config.from_env(prefix="OI_TOOLS_")
