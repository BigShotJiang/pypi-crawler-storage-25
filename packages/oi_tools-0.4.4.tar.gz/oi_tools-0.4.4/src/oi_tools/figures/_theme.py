from __future__ import annotations

import plotnine as pn

from oi_tools.figures._colors import scale_color_oi


def theme_oi(
    base_size: int = 11,
    base_family: str = "Helvetica",
    width: int | float = 7,
    height: int | float = 5,
) -> pn.theme:
    """Create the standard Opportunity Insights plotnine theme.

    Parameters
    ----------
    base_size
        Base font size in points. Default is 11.
    base_family
        Base font family. Default is ``"Helvetica"``.
    width
        Figure width in inches. Default is 7.
    height
        Figure height in inches. Default is 5.

    Returns
    -------
    pn.theme
        A plotnine theme object.
    """
    theme = pn.theme_classic(
        base_size=base_size,
        base_family=base_family,
    )

    theme += pn.theme(
        # legend
        legend_position="bottom",
        legend_direction="horizontal",
        # titles/subtitles
        plot_title=pn.element_text(ha="left"),
        plot_subtitle=pn.element_text(ha="left"),
        # captions (i.e. notes)
        plot_caption=pn.element_text(ha="right", style="italic"),
        # figure size
        figure_size=(width, height),
        # point size
        # TODO: facet theming
    )

    return theme


def example_figures() -> tuple[pn.ggplot, ...]:
    """Create one scatterplot and one line plot (i.e. time series) to demonstrate the theme."""
    from plotnine.data import economics, mpg

    scatter = (
        pn.ggplot(mpg, pn.aes(x="displ", y="hwy", color="class"))
        + pn.geom_point()
        + pn.labs(
            title="Engine Displacement vs Highway MPG",
            subtitle="Grouped by vehicle class",
            x="Displacement (L)",
            y="Highway MPG",
            color="Class",
            caption="Source: mpg dataset",
        )
        + theme_oi()
        + scale_color_oi()
    )

    line = (
        pn.ggplot(economics, pn.aes(x="date", y="unemploy"))
        + pn.geom_line()
        + pn.labs(
            title="US Unemployment Over Time",
            subtitle="Number of unemployed (thousands)",
            x="Date",
            y="Unemployed (thousands)",
            caption="Source: economics dataset",
        )
        + theme_oi()
    )

    return scatter, line
