from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Mapping, Sequence

if TYPE_CHECKING:
    import plotnine as pn


class OIColors(str, Enum):
    """Main Opportunity Insights color scheme."""

    TEAL = "#29B6A4"
    ORANGE = "#FAA523"
    BLUE = "#0073A2"
    RED = "#E54060"
    DARK_GREEN = "#2B8F43"
    PURPLE = "#7F4892"
    NAVY = "#003A4F"
    LIME_GREEN = "#A4CE4E"  # ugly lime green -- don't use
    YELLOW = "#FFD400"
    LIGHT_GREEN = "#6BBD45"

    @classmethod
    def primary(cls) -> str:
        """Return the primary OI color.

        Returns
        -------
        str
            Hex color code for the primary color (teal).

        Examples
        --------
        >>> OIColors.primary()
        '#29B6A4'
        """  # noqa
        return cls.TEAL.value

    @classmethod
    def secondary(cls) -> str:
        """Return the secondary OI color.

        Returns
        -------
        str
            Hex color code for the secondary color (orange).

        Examples
        --------
        >>> OIColors.secondary()
        '#FAA523'
        """  # noqa
        return cls.ORANGE.value

    @classmethod
    def list(cls) -> Sequence[str]:
        """Return all OI colors as an ordered list.

        Returns
        -------
        Sequence[str]
            Hex color codes in order.

        Examples
        --------
        >>> OIColors.list()[:2]
        ['#29B6A4', '#FAA523']
        """
        return [c.value for c in OIColors]

    @classmethod
    def dict(cls, lowercase: bool = False) -> Mapping[str, str]:
        """Return all OI colors as a mapping of name to hex code.

        Parameters
        ----------
        lowercase
            If ``True``, return lowercase color names. Default is ``False``.

        Returns
        -------
        Mapping[str, str]
            Mapping of color name to hex code.

        Examples
        --------
        >>> OIColors.dict()["TEAL"]
        '#29B6A4'
        >>> OIColors.dict(lowercase=True)["teal"]
        '#29B6A4'
        """
        return {c.name.lower() if lowercase else c.name: c.value for c in OIColors}


def scale_color_oi(**kwargs) -> pn.scale_color_manual:
    """Create a custom OI color scale for plotnine.

    Parameters
    ----------
    **kwargs
        Additional keyword arguments passed to ``pn.scale_color_manual``.

    Returns
    -------
    pn.scale_color_manual
        A plotnine color scale using the OI color palette.
    """  # noqa
    import plotnine as pn

    return pn.scale_color_manual(OIColors.list(), **kwargs)


def scale_fill_oi(**kwargs) -> pn.scale_fill_manual:
    """Create a custom OI fill scale for plotnine.

    Parameters
    ----------
    **kwargs
        Additional keyword arguments passed to ``pn.scale_fill_manual``.

    Returns
    -------
    pn.scale_fill_manual
        A plotnine fill scale using the OI color palette.
    """  # noqa
    import plotnine as pn

    return pn.scale_fill_manual(OIColors.list(), **kwargs)


def view_colors(
    colors: Sequence[str] | Mapping[str, str] = OIColors.dict(),
    show: bool = False,
) -> pn.ggplot:
    """Create a plotnine figure showing the specified colors.

    Parameters
    ----------
    colors
        Colors to display. Can be a sequence of hex codes or a name-to-hex
        mapping. Defaults to the full OI color palette.
    show
        If ``True``, display the figure immediately. Default is ``False``.

    Returns
    -------
    pn.ggplot
        A plotnine figure with one tile per color.

    Examples
    --------
    >>> type(view_colors(["#29B6A4", "#FAA523"])).__name__
    'ggplot'
    """
    import plotnine as pn
    import polars as pl

    if not isinstance(colors, Mapping):
        colors = dict(zip(colors, colors))

    df = pl.from_records(
        list(colors.items()), orient="row", schema=["name", "color"]
    ).with_columns(x=0, y=0)
    plot = (
        pn.ggplot(df, pn.aes("x", "y", fill="color"))
        + pn.geom_tile(width=0.9, height=0.9)
        + pn.scale_fill_identity()
        + pn.facet_wrap("name")
        + pn.theme_void()
        + pn.theme(plot_margin=1)
    )

    if show:
        plot.show()

    return plot
