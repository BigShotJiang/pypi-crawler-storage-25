from __future__ import annotations

from pathlib import Path
from typing import Collection, Iterable, Mapping

import plotnine as pn

from oi_tools.figures._theme import theme_oi

DEFAULT_FILETYPES = [".pdf", ".svg", ".png"]


def set_default_filetypes(filetypes: Collection[str]) -> None:
    """Set the default file types used when saving figures.

    Parameters
    ----------
    filetypes
        File extensions to use by default (e.g. ``[".pdf", ".png"]``).

    Examples
    --------
    >>> set_default_filetypes([".png"])
    >>> DEFAULT_FILETYPES
    ['.png']
    """
    DEFAULT_FILETYPES[:] = filetypes


def save_figures_to_pdf(
    figures: Iterable[pn.ggplot],
    path: Path | str,
    *,
    width: int | float = 11,  # in inches
    height: int | float = 8.5,
    apply_theme: bool | pn.theme = True,
    **kwargs,
) -> None:
    """Save multiple figures to a single PDF file.

    Parameters
    ----------
    figures
        The figures to save.
    path
        Destination file path.
    width
        Page width in inches. Default is 11.
    height
        Page height in inches. Default is 8.5.
    apply_theme
        Theme to apply to all figures. Pass ``True`` to use ``theme_oi``,
        ``False`` for no theme, or a custom theme object. Default is ``True``.
    **kwargs
        Additional keyword arguments passed to ``pn.save_as_pdf_pages``.

    Examples
    --------
    >>> fig1 = pn.ggplot() + pn.geom_blank()
    >>> fig2 = pn.ggplot() + pn.geom_blank()
    >>> save_figures_to_pdf([fig1, fig2], "output/figures.pdf")  # doctest: +SKIP
    """
    path = Path(path)
    path.parent.mkdir(exist_ok=True, parents=True)

    theme = (
        apply_theme
        if isinstance(apply_theme, pn.theme)
        else theme_oi()
        if apply_theme is True
        else pn.theme()  # no theme
    )

    theme += pn.theme(figure_size=(width, height))

    pn.save_as_pdf_pages(
        [fig + theme for fig in figures],
        filename=str(path),
        verbose=False,
        **kwargs,
    )


def save_figure(
    figure: pn.ggplot,
    path: Path,
    *,
    filetype: str | Collection[str] = DEFAULT_FILETYPES,
    **kwargs,
) -> None:
    """Save a single figure to one or more file formats.

    Parameters
    ----------
    figure
        The figure to save.
    path
        Destination path without extension.
    filetype
        File extension(s) to save. Defaults to ``DEFAULT_FILETYPES``.
    **kwargs
        Additional keyword arguments passed to ``figure.save``.

    Examples
    --------
    >>> fig = pn.ggplot() + pn.geom_blank()
    >>> save_figure(fig, "output/my_figure")  # doctest: +SKIP
    """
    if isinstance(filetype, str):
        filetype = [filetype]

    paths_to_save = [path.with_suffix(suffix) for suffix in filetype]

    for path in paths_to_save:
        path.parent.mkdir(exist_ok=True, parents=True)
        figure.save(filename=str(path), verbose=False, **kwargs)


def save_figures_to_folder(
    figures: Mapping[str | Path, pn.ggplot],
    *,
    folder: Path | None = None,
    filetype: str | Collection[str] = DEFAULT_FILETYPES,
    use_subfolders: bool = False,  # if true, save each set of figures to its own subfolder
    **kwargs,
) -> None:
    """Save multiple named figures to a folder.

    Parameters
    ----------
    figures
        A mapping of file names to figures.
    folder
        Destination folder. Defaults to the current working directory.
    filetype
        File extension(s) to save. Defaults to ``DEFAULT_FILETYPES``.
    use_subfolders
        If ``True``, save each figure to its own subfolder. Default is ``False``.
    **kwargs
        Additional keyword arguments passed to ``save_figure``.

    Examples
    --------
    >>> fig1 = pn.ggplot() + pn.geom_blank()
    >>> fig2 = pn.ggplot() + pn.geom_blank()
    >>> save_figures_to_folder(
    ...     {"fig1": fig1, "fig2": fig2}, folder="output/"
    ... )  # doctest: +SKIP
    """
    folder = folder or Path.cwd()

    for name, figure in figures.items():
        path = folder / name / name if use_subfolders else folder / name

        save_figure(figure, path=path, filetype=filetype, **kwargs)
