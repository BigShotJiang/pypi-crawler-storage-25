from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Callable

from typing_extensions import ParamSpec

if TYPE_CHECKING:
    import polars as pl


DEFAULT_BATCH_SIZE = 50_000

P = ParamSpec("P")


def _make_eager(
    lazy_function: Callable[P, pl.LazyFrame],
) -> Callable[P, pl.DataFrame]:
    @functools.wraps(lazy_function)
    def f(*args: P.args, **kwargs: P.kwargs) -> pl.DataFrame:
        return lazy_function(*args, **kwargs).collect()  # type: ignore[return-value]

    f.__doc__ = f"""An eager version of :func:`{__package__}.{getattr(lazy_function, "__name__")}`. See that function for documentation."""

    return f
