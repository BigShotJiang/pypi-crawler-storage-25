from __future__ import annotations

from collections.abc import Iterator, Mapping, Sequence
from io import BytesIO
from itertools import accumulate
from pathlib import Path
from typing import Any, Collection, Union, cast

import polars as pl
import polars.selectors as cs
from polars.io.plugins import register_io_source

from oi_tools.io._helpers import DEFAULT_BATCH_SIZE
from oi_tools.io._lines import SCAN_LINE_KWARGS

# ways to specify column locations
NameStartEnd = Mapping[str, tuple[int, int]]
NameLength = Sequence[tuple[Union[str, None], int]]  # none as name => discard

ColLocations = Union[NameStartEnd, NameLength]


def _standardize_col_locations(col_locations: ColLocations) -> NameStartEnd:
    if (
        isinstance(col_locations, Mapping)  # mapping of ...
        and isinstance(next(iter(col_locations.keys())), str)  # ... string keys to ...
        and isinstance(next(iter(col_locations.values())), tuple)  # ... tuple values
    ):
        return cast(NameStartEnd, col_locations)

    if (
        isinstance(col_locations, Sequence)  # sequence of ...
        and isinstance(col_locations[0], tuple)  # ... tuples
    ):
        names: tuple[str | None, ...]
        lengths: tuple[int, ...]

        names, lengths = zip(*col_locations)

        start_end_pairs = [
            (end - length, end) for end, length in zip(accumulate(lengths), lengths)
        ]

        return {
            name: loc for name, loc in zip(names, start_end_pairs) if name is not None
        }

    raise TypeError(
        "col_locations be either a mapping col_name -> (start, end) OR a sequence of (name, length) pairs"
    )


def _extract_columns(
    df: pl.DataFrame,
    col_locations: NameStartEnd,
    *,
    schema: Mapping | None = None,
    col_subset: Collection[str] | None = None,
    predicate: pl.Expr | None = None,
    column: pl.Expr | cs.Selector = cs.first(),
) -> pl.DataFrame:
    return (
        df.select(
            column.str.slice(start, end - start).alias(name)
            for name, (start, end) in col_locations.items()
        )
        .cast(schema or {})
        .select(col_subset or pl.all())
        .filter(*[predicate] if predicate is not None else [])
    )


def scan_fwf(
    file: str | Path,
    cols: ColLocations,
    *,
    infer_schema: bool = True,
    infer_schema_length: int = 100,
    **kwargs,
) -> pl.LazyFrame:
    """
    Lazily read a fixed-width file.

    Parameters
    ----------
    file
        The file to read.

    cols
        The locations of the relevant columns in the fixed-width file.
        Either a mapping from column names to ``(start, end)`` pairs or a
        sequence of ``(name, width)`` pairs.

    infer_schema
        Whether to infer column data types from the first ``infer_schema_length``
        rows. If ``False``, all columns are returned as ``pl.String``.

    infer_schema_length
        Number of rows to use for schema inference. Only used when
        ``infer_schema=True``.

    kwargs
        Other kwargs to pass to
        `pl.read_csv_batched <https://docs.pola.rs/api/python/stable/reference/api/polars.read_csv_batched.html>`_.

    Returns
    -------
    polars.LazyFrame
        A LazyFrame with one column per entry in ``cols``.

    Examples
    --------
    Read the file based on column start/end positions:

    >>> lf = scan_fwf(
    ...     "data.txt", cols={"name": (0, 20), "age": (20, 23)}
    ... )  # doctest: +SKIP

    If the columns are packed densely, can also specify their locations using ``(name, width)`` pairs:

    >>> lf = scan_fwf("data.txt", cols=[("name", 20), ("age", 3)])  # doctest: +SKIP
    """
    if "batch_size" in kwargs:
        raise KeyError(
            "Batch size is controlled by Polars. "
            "See https://docs.pola.rs/api/python/stable/reference/api/polars.Config.set_streaming_chunk_size.html"
        )

    # convert col location spec to mapping of name -> (start, end)
    col_locations: NameStartEnd = _standardize_col_locations(cols)

    read_csv_kwargs: dict[str, Any] = (
        SCAN_LINE_KWARGS | kwargs | dict(new_columns=["raw"])
    )

    if infer_schema:
        # HACK:
        # write a small number of rows to csv and then reread to infer schema
        # hacky, but it works and there doesn't seem to be a better way
        # see: https://github.com/pola-rs/polars/issues/2043
        buffer = BytesIO()

        (
            pl.read_csv(
                file,
                **read_csv_kwargs | dict(n_rows=infer_schema_length),
            )
            .pipe(_extract_columns, col_locations)
            .write_csv(buffer)
        )

        schema = pl.read_csv(buffer).schema
    else:
        schema = pl.Schema({col: pl.String for col in col_locations})

    def source_generator(
        with_columns: list[str] | None,
        predicate: pl.Expr | None,
        n_rows: int | None,
        batch_size: int | None,
    ) -> Iterator[pl.DataFrame]:
        n_rows = min(
            (x for x in (n_rows, kwargs.get("n_rows")) if x is not None),
            default=None,
        )

        reader = pl.read_csv_batched(
            file,
            **read_csv_kwargs
            | dict(
                batch_size=batch_size or DEFAULT_BATCH_SIZE,
                n_rows=n_rows,
            ),
        )

        while chunks := reader.next_batches(100):
            yield from (
                chunk.pipe(
                    _extract_columns,
                    col_locations,
                    predicate=predicate,
                    col_subset=with_columns,
                    schema=schema,
                )
                for chunk in chunks
            )

    return register_io_source(io_source=source_generator, schema=schema)
