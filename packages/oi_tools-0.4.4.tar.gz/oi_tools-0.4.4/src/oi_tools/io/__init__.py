"""
IO utilities for reading fixed-width, line-based, and HTML files.

For reading Stata (``.dta``) and SAS (``.sas7bdat``, ``.xpt``) files, see the excellent
`polars_readstat <https://jrothbaum.github.io/polars_readstat/read/>`_
package written by Jon Rothbaum at Census.
"""

from oi_tools.io._fixed_width import scan_fwf
from oi_tools.io._helpers import _make_eager
from oi_tools.io._html import read_html
from oi_tools.io._lines import scan_lines

read_fwf = _make_eager(scan_fwf)
read_lines = _make_eager(scan_lines)

__all__ = [
    "read_fwf",
    "read_lines",
    "read_html",
    "scan_lines",
    "scan_fwf",
]
