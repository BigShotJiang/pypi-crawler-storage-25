from __future__ import annotations

import io
from typing import BinaryIO, Sequence, TextIO, Union

import httpx
import parsel
import polars as pl
from parsel.utils import flatten

HeaderType = Union[str, Sequence[str], None]

DEFAULT_CELL_XPATH = ".//td"
DEFAULT_HEADER_XPATH = ".//thead[1]"
DEFAULT_ROW_XPATH = ".//tbody//tr"
DEFAULT_TABLE_XPATH = "descendant-or-self::table"


def read_html(
    source: str | TextIO | BinaryIO,
    *,
    header: str | Sequence[str] | None = DEFAULT_HEADER_XPATH,
    table_index: int | None = None,
    table_xpath: str | None = None,
    table_css: str | None = None,
    encoding: str = "utf-8",
) -> pl.DataFrame:
    """
    Read an HTML table into a DataFrame.

    Parameters
    ----------
    source
        A URL string (fetched with ``httpx``), or a file-like object (text or
        binary) containing HTML.

    header
        Controls how column names are determined.

        - ``str`` (default ``".//thead[1]"``): an XPath expression whose text
          nodes are joined to form column names.
        - ``Sequence[str]``: explicit column names supplied by the caller.
        - ``None``: no header; columns are numbered ``column_0``, ``column_1``, …

    table_index
        Zero-based index of the table to parse when the selector matches
        multiple tables. Mutually exclusive with ``table_xpath``/``table_css``
        uniquely identifying a single table.

    table_xpath
        XPath expression used to locate the table element. Defaults to
        ``"descendant-or-self::table"``. Mutually exclusive with
        ``table_css``.

    table_css
        CSS selector used to locate the table element (converted to XPath
        internally). Mutually exclusive with ``table_xpath``.

    encoding
        Character encoding used to decode a binary source. Ignored when
        ``source`` is already a text stream or URL (decoded by ``httpx``).

    Returns
    -------
    polars.DataFrame
        A DataFrame with one column per table column and one row per ``<tr>``
        in the ``<tbody>``.

    Raises
    ------
    ValueError
        If no table matches the selector, if multiple tables match and
        ``table_index`` is not provided, or if both ``table_xpath`` and
        ``table_css`` are specified.
    TypeError
        If ``source`` is not a URL string or a file-like object.

    Examples
    --------
    Read the only table from a URL:

    >>> df = read_html("https://example.com/table.html")  # doctest: +SKIP

    Read the second table from a local HTML file:

    >>> with open("report.html") as f:
    ...     df = read_html(f, table_index=1)  # doctest: +SKIP

    Select a table by CSS selector and supply column names explicitly:

    >>> with open("report.html", "rb") as f:
    ...     df = read_html(
    ...         f,
    ...         table_css="#summary-table",
    ...         header=["name", "value", "unit"],
    ...     )  # doctest: +SKIP
    """
    if table_xpath and table_css:
        raise ValueError("cannot specify both table_xpath and table_css")

    content: bytes | str

    if isinstance(source, str):
        response = httpx.get(source)
        content = response.text

    elif isinstance(source, (io.RawIOBase, io.BufferedIOBase, io.TextIOBase)):
        content = source.read()

    else:
        raise TypeError(f"unsupported source type: {type(source)!r}")

    if isinstance(content, bytes):
        content = content.decode(encoding)

    document = parsel.Selector(content)

    table_xpath = (
        table_xpath or parsel.css2xpath(table_css) if table_css else DEFAULT_TABLE_XPATH
    )

    tables = document.xpath(table_xpath)

    if len(tables) == 0:
        raise ValueError("no table found matching selector")

    table = (
        # take specified table
        tables[table_index]
        if table_index is not None
        # take the only matching table
        else tables[0]
        if len(tables) == 1
        # otherwise don't take anything
        else None
    )

    if table is None:
        raise ValueError(
            f"multiple tables ({len(tables)}) found; specify table_index to select one"
        )

    return parse_table(table, header=header)


def parse_table(t: parsel.Selector, *, header: HeaderType) -> pl.DataFrame:
    if isinstance(header, str):
        columns = [
            c.strip()
            for c in t.xpath(
                f"{header}//*[self::th or self::td]//text()[normalize-space()]"
            ).extract()
        ]

    elif isinstance(header, Sequence):
        columns = header

    elif header is None:
        columns = None

    else:
        raise TypeError(
            f"header must be a string, sequence, or None; got {type(header)!r}"
        )

    rows = t.xpath(DEFAULT_ROW_XPATH)

    return pl.from_records(
        [parsed_row for r in rows if (parsed_row := parse_row(r))],
        schema=columns,
        orient="row",
        strict=False,
    )


def parse_row(
    row: parsel.Selector, cell_selector: str = DEFAULT_CELL_XPATH
) -> Sequence[str | None]:
    """Parse the table row into a list of cells."""
    return flatten(map(parse_cell, row.xpath(cell_selector)))


def parse_cell(cell: parsel.Selector) -> list[str | None]:
    """Parse the table cell into one (or more in the case of col span) items."""
    contents = " ".join(cell.xpath(".//text()[normalize-space()]").extract())
    colspan = int(cell.xpath("@colspan").extract_first() or "1")

    return [contents] + (colspan - 1) * [None]
