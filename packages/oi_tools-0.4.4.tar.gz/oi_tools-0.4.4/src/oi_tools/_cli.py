from __future__ import annotations

import importlib.resources
import subprocess
import webbrowser
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler

from cyclopts import App
from rich import print as rprint

from oi_tools import __version__
from oi_tools.pbs import print_jobs, submit_job

app = App(
    name="oi",
    help="Command line app for the [cyan]oi-tools[/cyan] package.",
    help_format="rich",
    version=__version__,
)


@app.command(name="docs")
def serve_documentation(
    *,
    build: bool = False,
    serve: bool = True,
    host: str = "localhost",
    port: int = 8000,
    open: bool = True,
) -> None:
    """Serve the [cyan]oi-tools[/cyan] HTML documentation.

    Parameters
    ----------
    build
        Rebuild the documentation before serving.
    serve
        Serve the documentation on ``host:port``.
    host
        Hostname to serve on.
    port
        Port to serve on.
    open
        Open the documentation in the default browser. Requires ``serve``.
    """
    docs_path = importlib.resources.files("oi_tools") / "_docs" / "html"

    with importlib.resources.as_file(docs_path) as docs_dir:
        if build:
            rprint(f"Building documentation to [cyan]{docs_dir}[/cyan]")
            subprocess.check_call(
                ["sphinx-build", "docs", str(docs_dir)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
            )

        if not docs_dir.exists():
            rprint(
                "Documentation not found. "
                "Include the [cyan]--build[/cyan] flag to build the documentation."
            )
            raise SystemExit(1)

        if serve:
            rprint(f"Serving documentation from [cyan]{docs_dir}[/cyan]")
            rprint(f"Serving documentation on [cyan]{host}:{port}[/cyan]")
            rprint("[dim](Use ctrl+c to stop)[/dim]")

            if open:
                webbrowser.open(f"http://{host}:{port}")

            HTTPServer(
                (host, port),
                partial(SimpleHTTPRequestHandler, directory=docs_dir),
            ).serve_forever()


app.command(submit_job, name="sub")
app.command(print_jobs, name="list")


def main() -> None:
    """Basic driver function for the CLI."""  # noqa: D401
    app()
