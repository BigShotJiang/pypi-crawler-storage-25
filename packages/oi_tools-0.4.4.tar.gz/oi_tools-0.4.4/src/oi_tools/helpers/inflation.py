"""Inflation adjustment using the Consumer Price Index from the BLS."""

from __future__ import annotations

import os
import warnings
from datetime import date
from pprint import pformat

import inflection
import joblib
import polars as pl
import requests
from requests.exceptions import JSONDecodeError

from oi_tools.polars_helpers import IntoPolarsExpression, to_expr

CACHE_LOCATION = "~/.cache/oi-tools/bls-api/"
CACHE = joblib.Memory(CACHE_LOCATION, verbose=False)

THIS_YEAR = date.today().year


def inflation_adjust(
    col: IntoPolarsExpression,
    *,
    from_year: IntoPolarsExpression,
    to_year: IntoPolarsExpression,
    series: str = "CUUR0000SA0",
) -> pl.Expr:
    """Adjust for inflation using the Consumer Price Index.

    Useful references:

    - https://www.bls.gov/cpi/factsheets/cpi-series-ids.htm
    - https://www.bls.gov/data/inflation_calculator.htm

    Parameters
    ----------
    col
        The column (or columns) to adjust.
    from_year
        The year in which the dollar value is currently measured.
    to_year
        The year to which you would like to inflation adjust.
    series
        The CPI series used for inflation adjustment, ``CUUR0000SA0`` by default.

    Examples
    --------
    >>> df = pl.DataFrame({"income": [50000, 75000], "year": [2010, 2015]})
    >>> df.with_columns(
    ...     income_2023=inflation_adjust("income", from_year="year", to_year=2023)
    ... )
    shape: (2, 3)
    ┌────────┬──────┬──────────────┐
    │ income ┆ year ┆ income_2023  │
    │ ---    ┆ ---  ┆ ---          │
    │ i64    ┆ i64  ┆ f64          │
    ╞════════╪══════╪══════════════╡
    │ 50000  ┆ 2010 ┆ 69867.832117 │
    │ 75000  ┆ 2015 ┆ 96417.767502 │
    └────────┴──────┴──────────────┘

    """
    year_to_cpi = (
        get_bls_series(series)
        .filter(period_name="Annual")
        .select("year", pl.col("value").cast(pl.Float64))
        .get_columns()
    )

    return (
        col
        * to_expr(to_year).replace_strict(*year_to_cpi, default=None)
        / to_expr(from_year).replace_strict(*year_to_cpi, default=None)
    )


def get_bls_series(series: str, start_year: int = 1950) -> pl.DataFrame:
    """Get a Polars DataFrame of a specified BLS series.

    Parameters
    ----------
    series
        The BLS series identifier.
    start_year
        The year from which to start retrieving data. Default is 1950.

    Returns
    -------
    pl.DataFrame
        A DataFrame with the series data sorted by year and period.
    """
    decade_dfs = [
        get_bls_series_for_decade(series, decade)
        for decade in range(start_year, THIS_YEAR + 1, 10)
    ]

    return (
        pl.concat(decade_dfs, how="diagonal_relaxed")
        .sort("year", "period")
        .rename(inflection.underscore)
    )


@CACHE.cache()
def get_bls_series_for_decade(
    series: str,
    start_year: int,
    *,
    base_url: str = "https://api.bls.gov/publicAPI/v2/timeseries/data/",
    api_key: str | None = None,
) -> pl.DataFrame:
    """Get a Polars DataFrame of a specified BLS series for a single decade.

    Parameters
    ----------
    series
        The BLS series identifier.
    start_year
        The starting year of the decade.
    base_url
        The BLS API base URL.
    api_key
        BLS API registration key. Falls back to the ``BLS_API_KEY``
        environment variable if not provided.

    Returns
    -------
    pl.DataFrame
        A DataFrame with the series data for the specified decade.

    Raises
    ------
    RuntimeError
        If the BLS API response cannot be parsed.
    """
    payload = {
        "seriesid": [series],
        "startyear": start_year,
        "endyear": min(THIS_YEAR, start_year + 9),
        "annualaverage": True,
        "registrationkey": api_key or os.environ.get("BLS_API_KEY"),
    }

    response = requests.post(base_url, json=payload)

    response.raise_for_status()

    if messages := response.json().get("message"):
        warnings.warn("Message from the BLS API:\n" + pformat(messages))

    try:
        data = response.json().get("Results").get("series").pop().get("data")
    except (JSONDecodeError, KeyError):
        raise RuntimeError(
            "Unable to parse response from the BLS API when getting CPI-U data:"
            + response.text
        )

    return pl.DataFrame(data)
