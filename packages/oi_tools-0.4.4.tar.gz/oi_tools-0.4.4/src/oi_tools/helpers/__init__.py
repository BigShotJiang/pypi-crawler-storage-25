"""Various helper/utility functions."""

from oi_tools.helpers.inflation import inflation_adjust

__all__ = ["inflation_adjust"]
