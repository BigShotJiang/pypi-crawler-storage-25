from __future__ import annotations

import datetime
import json
from typing import Literal, Union

import humanfriendly as hf
import polars as pl
import rich
import rich.box
import rich.table

from oi_tools.pbs._helpers import format_disc_size, sh
from oi_tools.polars_helpers import clean_col_name

JOB_STATES = {
    "B": "Running subjob",
    "E": "Exiting",
    "F": "Finished",
    "H": "Held",
    "M": "Moved",
    "Q": "[yellow]Queued",
    "R": "[green]Running",
    "S": "Suspended",
    "T": "In transit",
    "U": "Suspended",
    "W": "Waiting",
    "X": "Completed or canceled",
}

TIME_FORMAT = r"%a %b %d %H:%M:%S %Y"
"""The time format used for parsing timestamps from `qstat` output."""


def print_jobs(
    users: Union[Literal["me", "all"], list[str]] = "me",
    *,
    limit: int = 20,
    completed: bool = False,
) -> None:
    """Print active, queued, and (optionally) completed PBS jobs in a formatted table.

    Parameters
    ----------
    users
        Whose jobs to show. ``"me"`` shows only the current user's jobs,
        ``"all"`` shows all users, and passing a list of usernames filters
        to only those users.
    limit
        Maximum number of jobs to display.
    completed
        If ``True``, include finished/completed jobs alongside active ones.
    """
    name = pl.format("{}\n  [dim]{}", "job_name", "id").alias("Job")

    owner = pl.col("owner").alias("Owner")

    elapsed = (
        pl.col("etime")
        .str.strptime(pl.Datetime, TIME_FORMAT)
        .pipe(lambda x: datetime.datetime.now() - x)
        .map_elements(
            lambda x: hf.format_timespan(x, max_units=1), return_dtype=pl.String
        )
    )
    status = pl.format(
        "{}\n[dim]{}", pl.col("job_state").replace_strict(JOB_STATES), elapsed
    ).alias("Status")

    mem_used = (
        pl.col("resources_used_mem")
        .map_elements(format_disc_size, return_dtype=pl.String)
        .fill_null(pl.lit("--"))
    )

    mem_limit = pl.col("resource_list_mem").map_elements(
        format_disc_size, return_dtype=pl.String
    )

    cpu_pct = (
        pl.col("resources_used_cpupercent")
        .cast(pl.String)
        .add(pl.lit("%"))
        .fill_null(pl.lit("--"))
    )

    usage = pl.format(
        "{} of {}\n{} ({} CPUs)", mem_used, mem_limit, cpu_pct, "resource_list_ncpus"
    ).alias("Usage")

    cols = [owner, name, status, usage] if users != "me" else [name, status, usage]

    job_df = get_job_df(users=users, completed=completed, limit=limit).select(cols)

    rich.print(_df_to_rich_table(job_df))


def get_job_df(
    *,
    users: Union[Literal["me", "all"], list[str]] = "me",
    completed: bool = False,
    limit: int | None = None,
) -> pl.DataFrame:
    """Retrieve a Polars DataFrame of PBS jobs.

    Parameters
    ----------
    users
        Who to return jobs for. ``"me"`` returns only the current user's jobs,
        ``"all"`` returns all users, or a list of usernames to filter by.
    completed
        If ``True``, include finished/completed jobs alongside active ones.
    limit
        Maximum number of jobs to return. If ``None``, returns all jobs.

    Returns
    -------
    pl.DataFrame
        A DataFrame containing job metadata with standardized column names.
    """
    # TODO: filter users here instead of in the df?
    qstat_result = (
        sh("qstat", "-xf", "-Fjson") if completed else sh("qstat", "-f", "-Fjson")
    )

    jobs = json.loads(qstat_result)["Jobs"]

    df = (
        pl.json_normalize(jobs.values(), infer_schema_length=None)
        .with_columns(
            id=pl.Series(jobs.keys()),
            owner=pl.col("Job_Owner").str.extract(r"(.*)@.*"),
        )
        .rename(clean_col_name)
    )

    # ensure required columns are present
    qstat_cols = [
        "job_name",
        "job_state",
        "etime",
        "resources_used_mem",
        "resources_used_cpupercent",
        "resource_list_mem",
        "resource_list_ncpus",
    ]
    df = df.with_columns(
        pl.lit(None, dtype=pl.String).alias(col)
        for col in qstat_cols
        if col not in df.columns
    ).sort("job_state", "job_owner", "job_name")

    if users == "me":
        df = df.filter(pl.col("owner") == sh("whoami"))

    elif isinstance(users, list):
        df = df.filter(pl.col("owner").is_in(users))

    if limit is not None:
        df = df.head(limit)

    return df


def _df_to_rich_table(df: pl.DataFrame) -> rich.table.Table:
    t = rich.table.Table()

    t.box = rich.box.HORIZONTALS

    for c in df.columns:
        t.add_column(c)

    for r in df.iter_rows():
        t.add_row(*r)

    return t
