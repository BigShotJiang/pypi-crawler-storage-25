from __future__ import annotations

import json
import shlex
import shutil
import subprocess
import time
from collections.abc import Collection
from pathlib import Path
from typing import TYPE_CHECKING

import humanfriendly as hf

if TYPE_CHECKING:
    from oi_tools.pbs._sub import ArgumentType

from oi_tools._config import CONFIG


class BatchJobError(Exception):
    """PBS batch job exited with non-zero status."""

    pass


class JobSubmissionError(Exception):
    """Failed to submit PBS job."""

    pass


def sh(*args: str) -> str:
    """Run the arguments as a shell subprocess and return its output.

    Parameters
    ----------
    *args
        Command and arguments to execute.

    Returns
    -------
    str
        The stripped stdout of the subprocess.
    """
    return subprocess.check_output(args, text=True).strip()


def wait_for_job(
    job_ids: str | Collection[str],
    *,
    stop_on_error: bool = True,
    wait_for_all: bool = False,
    polling_delay: int | float = CONFIG.PBS_POLL_DELAY,
) -> str:
    """Watch the specified job(s) and return when one (or all) finish.

    Parameters
    ----------
    job_ids
        PBS job ID(s) to monitor.
    stop_on_error
        If ``True``, raise ``BatchJobError`` when a job exits with non-zero
        status.
    wait_for_all
        If ``True``, block until every job finishes and return the last job ID.
        If ``False`` (default), return as soon as the first job finishes.
    polling_delay
        Seconds to wait between status checks.

    Returns
    -------
    str
        The job ID of the last job to finish (if ``wait_for_all=True``) or the
        first job to finish (if ``wait_for_all=False``).

    Raises
    ------
    ValueError
        If ``job_ids`` is empty.
    BatchJobError
        If a job exits with non-zero status and ``stop_on_error`` is ``True``.
    """
    # convert job_ids to list
    job_ids = [job_ids] if isinstance(job_ids, str) else list(job_ids)

    if not job_ids:
        raise ValueError("job_ids must not be empty")

    while job_ids:
        finished_jobs = job_exit_status(*job_ids)

        if not finished_jobs:
            # everything still running
            time.sleep(polling_delay)
            continue

        job_id, status = finished_jobs.popitem()

        if status > 0 and stop_on_error:
            raise BatchJobError(f"Job {job_id} failed with status {status}")

        if not wait_for_all:
            return job_id

        job_ids.remove(job_id)

    # SAFETY: job_ids is non-empty (checked above), so the loop runs
    # at least once and jobid is always assigned before this line is reached
    return job_id  # type: ignore


def job_exit_status(*jobids: str | int, retries: int = 5) -> dict[str, int]:
    """Retrieve the exit status for a set of PBS jobs.

    Parameters
    ----------
    *jobids
        PBS job IDs to query.
    retries
        Number of times to retry on failure. Default is 5.

    Returns
    -------
    dict[str, int]
        Mapping of job ID to exit status, for jobs that have completed.

    Raises
    ------
    RuntimeError
        If status cannot be retrieved after all retries.
    """
    for _ in range(retries):
        try:
            jobs = json.loads(sh("qstat", *map(str, jobids), "-fxFjson"))["Jobs"]
            return {
                name: job.get("Exit_status")
                for name, job in jobs.items()
                if "Exit_status" in job
            }
        except Exception:
            print("Failed to get job status. Trying again in a few seconds...")
            time.sleep(CONFIG.PBS_POLL_DELAY)
    else:
        raise RuntimeError(f"Unable to get status of PBS jobs in {retries} tries")


def get_python() -> Path:
    """Get the current Python executable.

    Returns
    -------
    Path
        Absolute path to the Python executable.

    Raises
    ------
    ValueError
        If no Python executable is found.
    """
    python = shutil.which("python3") or shutil.which("python")

    if python is None:
        raise ValueError("no python executable found")

    return Path(python).absolute()


def get_stata() -> Path:
    """Get the current Stata executable, preferring faster versions.

    Returns
    -------
    Path
        Absolute path to the Stata executable.

    Raises
    ------
    ValueError
        If no Stata executable is found.
    """
    stata = (
        shutil.which("stata-mp")
        or shutil.which("stata-se")
        or shutil.which("stata-be")
        or shutil.which("stata")
    )

    if stata is None:
        raise ValueError("no stata executable found")

    return Path(stata).absolute()


def get_rscript() -> Path:
    """Get the current Rscript executable.

    Returns
    -------
    Path
        Absolute path to the Rscript executable.

    Raises
    ------
    ValueError
        If no Rscript executable is found.
    """
    r = shutil.which("Rscript")

    if r is None:
        raise ValueError("no Rscript executable found")

    return Path(r).absolute()


def format_disc_size(size: str) -> str:
    """Format a disk size string for user-facing display.

    Parameters
    ----------
    size
        A size string (e.g. ``"4gb"``).

    Returns
    -------
    str
        A human-readable size string (e.g. ``"4 GB"``).
    """
    return hf.format_size(hf.parse_size(size))


def format_path(path: Path | str) -> str:
    """Format a path for user-facing display.

    Returns the shorter of the absolute path and the path relative to the
    current working directory.

    Parameters
    ----------
    path
        The path to format.

    Returns
    -------
    str
        A string representation of the path.
    """
    if not isinstance(path, Path):
        path = Path(path)

    path = path.absolute()

    try:
        relative = path.relative_to(Path.cwd())
        if len(str(relative)) < len(str(path)):
            path = relative

    except ValueError:
        pass

    return str(path)


def quote_argument(s: ArgumentType) -> str:
    """Quote a command line argument.

    This ensures quotes are properly escaped and strings with
    spaces are interpreted as single arguments.
    """
    return shlex.quote(str(s))
