"""Warp-specific install helpers for the MCP adapter.

Warp's MCP-server registration moves around between versions and is mostly
configured through the in-app UI. Rather than guessing at a config file
that might be wrong tomorrow, we:

  1. Generate a JSON snippet describing how Warp should invoke
     ``relay mcp serve``.
  2. Write that snippet to ``~/.relay/warp-mcp.json`` as a reference.
  3. Print the snippet plus copy-paste instructions for Warp's MCP UI.

This is intentionally lightweight; the strongest contract we make is "the
snippet you paste into Warp's MCP UI will work" — not "we auto-modified
Warp's preferences."

If a stable Warp config-file path emerges in a future version, this is the
seam where we'd write to it directly.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from agent_relay.daemon.paths import relay_home


@dataclass(frozen=True, slots=True)
class WarpInstallResult:
    snippet_path: Path
    snippet: dict
    command: str
    args: list[str]


def detect_warp() -> bool:
    """Best-effort: True if Warp appears installed on the host."""
    if sys.platform == "darwin":
        return Path("/Applications/Warp.app").is_dir()
    if sys.platform.startswith("linux"):
        candidates = [
            Path.home() / ".local" / "share" / "warp-terminal",
            Path("/usr/bin/warp-terminal"),
        ]
        return any(p.exists() for p in candidates)
    return False


def build_snippet() -> WarpInstallResult:
    """Construct the MCP-server registration snippet.

    Returns the snippet dict (under both ``mcpServers`` and ``servers`` keys
    so it's compatible with both the older Claude-Desktop schema and the
    newer common form), plus the command + args broken out for users who
    have to type them manually.
    """
    command, args = _relay_mcp_command()
    server_entry = {
        "command": command,
        "args": args,
        "env": {},
    }
    snippet = {
        # Keep both top-level shapes — Warp has accepted either across
        # versions, and pasting a redundant key never hurts.
        "mcpServers": {"agent-relay": server_entry},
        "servers": {"agent-relay": server_entry},
    }
    snippet_path = relay_home() / "warp-mcp.json"
    snippet_path.parent.mkdir(parents=True, exist_ok=True)
    snippet_path.write_text(json.dumps(snippet, indent=2) + "\n", encoding="utf-8")
    return WarpInstallResult(
        snippet_path=snippet_path,
        snippet=snippet,
        command=command,
        args=args,
    )


def installation_steps(result: WarpInstallResult) -> list[str]:
    """Human-readable steps to surface from ``relay install --warp`` output."""
    pretty_cmd = " ".join([result.command, *result.args])
    return [
        f"Wrote MCP server snippet to {result.snippet_path}.",
        "",
        "To register Agent Relay as an MCP server in Warp:",
        "  1. Open Warp → Settings → AI → Manage MCP Servers.",
        "  2. Click 'Add MCP Server' → choose 'Command' type.",
        "  3. Name: agent-relay",
        f"     Command: {result.command}",
        f"     Arguments: {' '.join(result.args)}",
        "  4. Save and toggle the server on.",
        "",
        "Equivalent shell invocation (for verification):",
        f"  {pretty_cmd}",
    ]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _relay_mcp_command() -> tuple[str, list[str]]:
    """The argv Warp should run. Prefer a real binary; fall back to python -m.

    Mirrors the strategy in :mod:`agent_relay.daemon.platform` so the launch
    agent and the MCP server start the same binary.
    """
    for name in ("relay", "agent-relay"):
        which = shutil.which(name)
        if which:
            return which, ["mcp", "serve"]
    return os.fsdecode(sys.executable), ["-m", "agent_relay.cli", "mcp", "serve"]
