"""Run a CLI agent through a PTY, capturing rate-limit signals into the log.

The contract from the user's side is: ``relay run aider …`` should be
indistinguishable from ``aider …`` — colours, prompts, ^C handling,
terminal-resize behaviour. Underneath, we own the child's stdout long
enough to scan it for events the daemon should act on.

Architecture:

  user terminal ──(stdin)──▶ parent ──(write)──▶ master_fd ──▶ child (PTY)
       ▲                       │
       │                       ▼
       └──(write)── parent ◀──(read)── master_fd ◀── child stdout
                              │
                              └── OutputClassifier ──▶ event log

POSIX only. Windows ConPTY support lands in Phase 7 alongside the binary
distribution. On Windows ``run()`` raises NotImplementedError up front
so the user sees a clear message instead of a confusing crash.

Test strategy: the high-level :func:`run` is hard to test (real TTY, real
child process). We keep the testable bits — session-id construction,
agent-slug derivation, exit-reason logic — as pure helpers in this module.
The PTY plumbing itself is covered by a smoke test that runs ``echo hi``
through the wrapper and asserts on events written to the log.
"""

from __future__ import annotations

import contextlib
import errno
import logging
import os
import re
import select
import shutil
import signal
import struct
import sys
import termios
import time
import tty
import uuid
from pathlib import Path

from agent_relay.adapters.output_classifier import OutputClassifier
from agent_relay.daemon import events as ev
from agent_relay.daemon.paths import is_valid_session_id

log = logging.getLogger("agent_relay.adapters.pty")

# Slugs we know — argv[0]'s basename maps to one of these for the StartedEvent.
_KNOWN_AGENT_SLUGS = {
    "aider": "aider",
    "codex": "codex",
    "gemini": "gemini-cli",
    "sgpt": "sgpt",
    "llm": "llm",
    "claude": "claude-code",
    "cline": "cline",
    "cursor-agent": "cursor-agent",
}


def run(argv: list[str], *, session_id: str | None = None, agent: str | None = None) -> int:
    """Spawn ``argv`` through a PTY, mirror it to the user's terminal, and
    emit events for things worth recording. Returns the child exit code.

    ``session_id`` and ``agent`` are auto-derived if not provided. The
    ``agent`` slug comes from ``argv[0]`` (e.g. ``aider`` → ``aider``);
    unknown commands get ``cli:<basename>``.
    """
    if not argv:
        raise ValueError("argv must contain at least one element")
    if sys.platform == "win32":
        raise NotImplementedError(
            "relay run is POSIX-only in Phase 4; Windows ConPTY support lands in Phase 7"
        )

    program = argv[0]
    resolved = shutil.which(program) or program
    agent_slug = agent or agent_slug_for(program)
    sid = session_id or generate_session_id(agent_slug)
    if not is_valid_session_id(sid):
        raise ValueError(f"invalid session id: {sid!r}")

    # Started event happens regardless of whether the spawn succeeds — if
    # the program doesn't exist, the user gets a clear errno from execvp
    # AND the daemon sees a session that immediately stopped.
    ev.append(
        ev.StartedEvent(
            session=sid,
            agent=agent_slug,
            cwd=os.getcwd(),
            pid=os.getpid(),
        )
    )

    classifier = OutputClassifier(session_id=sid, agent=agent_slug, on_event=ev.append)
    crashed = False
    exit_code = 1
    try:
        exit_code = _spawn_and_mirror([resolved, *argv[1:]], on_output=classifier.feed)
    except FileNotFoundError as exc:
        # `which` may have missed (e.g. command embedded in a $PATH entry
        # that isn't readable). Bubble up after recording the crash.
        crashed = True
        log.error("command not found: %s (%s)", program, exc)
    except Exception:  # noqa: BLE001 — record then re-raise
        crashed = True
        log.exception("pty wrapper failed")
        classifier.flush()
        ev.append(ev.StoppedEvent(session=sid, reason="crashed"))
        raise
    finally:
        classifier.flush()

    reason = exit_reason(
        exit_code,
        rate_limited=classifier.last_seen_rate_limit_provider is not None,
        crashed=crashed,
    )
    ev.append(ev.StoppedEvent(session=sid, reason=reason))
    if crashed and exit_code == 1:
        # Make "command not found" obvious — match shells' convention.
        return 127
    return exit_code


# ---------------------------------------------------------------------------
# Pure helpers — tested directly
# ---------------------------------------------------------------------------


def agent_slug_for(program: str) -> str:
    """Map argv[0] (or its basename) to a stable agent slug."""
    base = Path(program).name.lower()
    # Strip a single trailing version suffix like ``aider-1.2.3`` so we
    # match the binary regardless of how it was installed.
    base = re.sub(r"[-_]\d+(?:\.\d+){0,3}$", "", base)
    if base in _KNOWN_AGENT_SLUGS:
        return _KNOWN_AGENT_SLUGS[base]
    return f"cli:{base}" if base else "cli:unknown"


def generate_session_id(agent_slug: str) -> str:
    """Construct a short, log-friendly, sortable session id."""
    stamp = time.strftime("%Y%m%d%H%M%S", time.gmtime())
    safe_agent = re.sub(r"[^A-Za-z0-9]", "", agent_slug.split(":")[-1])[:12] or "cli"
    rand = uuid.uuid4().hex[:8]
    return f"{safe_agent}-{stamp}-{rand}"


def exit_reason(exit_code: int, *, rate_limited: bool, crashed: bool) -> str:
    """One-word stop reason for the StoppedEvent. Order matters."""
    if rate_limited:
        return "rate_limited"
    if crashed:
        return "crashed"
    if exit_code == 0:
        return "done"
    # Negative codes happen when the child was killed by a signal.
    return "user_quit" if exit_code in (130, -2) else "error"


# ---------------------------------------------------------------------------
# PTY plumbing — POSIX only
# ---------------------------------------------------------------------------


def _spawn_and_mirror(argv: list[str], *, on_output) -> int:
    """Fork through a PTY, mirror master_fd ↔ stdio, return the exit code."""
    import pty  # local import: pty is POSIX-only

    pid, master_fd = pty.fork()
    if pid == 0:
        # Child: replace ourselves with the target program.
        try:
            os.execvp(argv[0], argv)
        except FileNotFoundError:
            os.write(2, f"relay run: {argv[0]}: command not found\n".encode())
            os._exit(127)
        except OSError as exc:
            os.write(2, f"relay run: {argv[0]}: {exc}\n".encode())
            os._exit(126)

    # Parent: bridge master_fd to the user's terminal.
    stdin_fd = sys.stdin.fileno() if sys.stdin.isatty() else -1
    old_settings = None
    old_sigwinch = None
    try:
        if stdin_fd != -1:
            old_settings = termios.tcgetattr(stdin_fd)
            tty.setraw(stdin_fd)
            _propagate_window_size(stdin_fd, master_fd)
            old_sigwinch = signal.signal(
                signal.SIGWINCH,
                lambda _s, _f: _propagate_window_size(stdin_fd, master_fd),
            )

        _bridge_loop(stdin_fd, master_fd, on_output)
    finally:
        if old_settings is not None and stdin_fd != -1:
            with contextlib.suppress(OSError):
                termios.tcsetattr(stdin_fd, termios.TCSADRAIN, old_settings)
        if old_sigwinch is not None:
            with contextlib.suppress(OSError, ValueError):
                signal.signal(signal.SIGWINCH, old_sigwinch)
        with contextlib.suppress(OSError):
            os.close(master_fd)

    _, status = os.waitpid(pid, 0)
    if os.WIFEXITED(status):
        return os.WEXITSTATUS(status)
    if os.WIFSIGNALED(status):
        return 128 + os.WTERMSIG(status)
    return 1


def _bridge_loop(stdin_fd: int, master_fd: int, on_output) -> None:
    """Multiplex stdin → master_fd and master_fd → stdout + classifier."""
    rlist_targets = [master_fd]
    if stdin_fd != -1:
        rlist_targets.append(stdin_fd)
    out = sys.stdout.buffer
    while True:
        try:
            rlist, _, _ = select.select(rlist_targets, [], [], 0.5)
        except OSError as exc:
            if exc.errno == errno.EINTR:
                continue
            break
        if master_fd in rlist:
            try:
                data = os.read(master_fd, 8192)
            except OSError as exc:
                if exc.errno == errno.EIO:
                    # PTY closed on the child side — normal exit path.
                    break
                raise
            if not data:
                break
            try:
                out.write(data)
                out.flush()
            except OSError:
                # User's terminal went away; keep ingesting events for the log.
                pass
            on_output(data)
        if stdin_fd != -1 and stdin_fd in rlist:
            try:
                data = os.read(stdin_fd, 4096)
            except OSError:
                continue
            if not data:
                # User pressed Ctrl-D on our end. Pass it on by closing
                # the slave write side — but on PTY-fork there's no clean
                # way, so we leave stdin out of the select set and let the
                # child finish naturally.
                rlist_targets = [master_fd]
                continue
            try:
                os.write(master_fd, data)
            except OSError:
                break


def _propagate_window_size(stdin_fd: int, master_fd: int) -> None:
    try:
        size = struct.pack("HHHH", *_get_winsize(stdin_fd))
    except OSError:
        return
    with contextlib.suppress(OSError):
        import fcntl

        fcntl.ioctl(master_fd, termios.TIOCSWINSZ, size)


def _get_winsize(fd: int) -> tuple[int, int, int, int]:
    import fcntl

    buf = b"\x00" * 8
    raw = fcntl.ioctl(fd, termios.TIOCGWINSZ, buf)
    rows, cols, xpix, ypix = struct.unpack("HHHH", raw)
    return rows, cols, xpix, ypix
