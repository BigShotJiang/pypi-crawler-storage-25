"""Proxy-mode parser — lossless rate-limit detection from HTTP headers.

The Phase 5b proxy intercepts the agent's outgoing LLM API calls and reads
the provider's own rate-limit headers (``anthropic-ratelimit-*``,
``x-ratelimit-*``, Google's quota error bodies). That is *much* more
reliable than line-scanning stdout: we get the exact provider, the exact
retry-after seconds, and the remaining-quota signal before we even hit a
hard 429.

This module is **pure**: it never opens a socket or imports mitmproxy.
Tests cover it directly. The mitmproxy-aware wrapper lives in
:mod:`agent_relay.adapters.proxy_addon` and just routes flow objects
through these functions.

Header sources we currently understand:

* **Anthropic** — ``anthropic-ratelimit-{requests,input-tokens,output-tokens,tokens}-{limit,remaining,reset}``
  and the 429 ``retry-after`` header.
* **OpenAI** — ``x-ratelimit-{limit,remaining,reset}-{requests,tokens}``
  plus the 429 ``retry-after``.
* **Google Gemini** — quota errors arrive as an error body with
  ``RESOURCE_EXHAUSTED`` plus a ``retryDelay`` field. We detect the body,
  not headers, because Google doesn't currently expose per-key remaining
  counters.

We deliberately don't capture chat-message bodies in Phase 5b. The proxy
sees them, but storing transcripts on disk is sensitive and out of scope
for the first ship — the rate-limit signal is the high-value, low-risk
subset.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal

from agent_relay.daemon import events as ev

Provider = Literal["anthropic", "openai", "google", "unknown"]

# Hosts the addon will inspect. Anything else passes through untouched.
_PROVIDER_BY_HOST: dict[str, Provider] = {
    "api.anthropic.com": "anthropic",
    "api.openai.com": "openai",
    "generativelanguage.googleapis.com": "google",
}

# Below this remaining-fraction we emit a near-limit warning (decision event).
# The proxy is the only place we have hard numbers, so it's the right layer
# to surface the warning even before a real 429.
_NEAR_LIMIT_FRACTION = 0.05

_MAX_DETAIL_CHARS = 240


@dataclass(frozen=True, slots=True)
class RateLimitSignal:
    """Normalised view of one rate-limit observation."""

    provider: Provider
    status_code: int
    retry_after: float | None
    requests_remaining: int | None = None
    tokens_remaining: int | None = None
    requests_limit: int | None = None
    tokens_limit: int | None = None
    detail: str = ""

    @property
    def is_blocked(self) -> bool:
        return self.status_code == 429

    @property
    def fraction_remaining(self) -> float | None:
        """Smaller of requests-remaining / tokens-remaining (whichever lower)."""
        candidates: list[float] = []
        if self.requests_limit and self.requests_remaining is not None:
            candidates.append(self.requests_remaining / max(self.requests_limit, 1))
        if self.tokens_limit and self.tokens_remaining is not None:
            candidates.append(self.tokens_remaining / max(self.tokens_limit, 1))
        return min(candidates) if candidates else None


# ---------------------------------------------------------------------------
# Host classification
# ---------------------------------------------------------------------------


def classify_host(host: str) -> Provider:
    """Map an HTTP host string to a provider slug."""
    host = (host or "").strip().lower()
    # mitmproxy sometimes hands us host:port — drop the port for matching.
    host = host.split(":", 1)[0]
    return _PROVIDER_BY_HOST.get(host, "unknown")


def is_target(host: str) -> bool:
    return classify_host(host) != "unknown"


# ---------------------------------------------------------------------------
# Header parsing per provider
# ---------------------------------------------------------------------------


def parse_signal(
    *,
    provider: Provider,
    status_code: int,
    headers: dict[str, str],
    body_text: str = "",
) -> RateLimitSignal:
    """Build a :class:`RateLimitSignal` from a normalised response.

    ``headers`` must be a case-insensitive-lookup dict. The mitmproxy
    addon lower-cases keys before calling us; tests pass lower-cased keys
    directly. Unknown providers return a minimal signal with no quota
    counters — the status code still matters.
    """
    lc = {k.lower(): v for k, v in headers.items()}
    retry_after = _parse_retry_after(lc.get("retry-after"))
    if provider == "anthropic":
        return _parse_anthropic(status_code, lc, retry_after)
    if provider == "openai":
        return _parse_openai(status_code, lc, retry_after)
    if provider == "google":
        return _parse_google(status_code, lc, body_text, retry_after)
    return RateLimitSignal(
        provider=provider,
        status_code=status_code,
        retry_after=retry_after,
        detail="",
    )


def _parse_anthropic(status: int, lc: dict[str, str], retry_after: float | None) -> RateLimitSignal:
    return RateLimitSignal(
        provider="anthropic",
        status_code=status,
        retry_after=retry_after,
        requests_remaining=_int(lc.get("anthropic-ratelimit-requests-remaining")),
        requests_limit=_int(lc.get("anthropic-ratelimit-requests-limit")),
        tokens_remaining=_int(lc.get("anthropic-ratelimit-tokens-remaining")),
        tokens_limit=_int(lc.get("anthropic-ratelimit-tokens-limit")),
        detail=_detail_from_anthropic(lc),
    )


def _parse_openai(status: int, lc: dict[str, str], retry_after: float | None) -> RateLimitSignal:
    return RateLimitSignal(
        provider="openai",
        status_code=status,
        retry_after=retry_after,
        requests_remaining=_int(lc.get("x-ratelimit-remaining-requests")),
        requests_limit=_int(lc.get("x-ratelimit-limit-requests")),
        tokens_remaining=_int(lc.get("x-ratelimit-remaining-tokens")),
        tokens_limit=_int(lc.get("x-ratelimit-limit-tokens")),
        detail=_detail_from_openai(lc),
    )


def _parse_google(
    status: int, lc: dict[str, str], body_text: str, retry_after: float | None
) -> RateLimitSignal:
    detail = ""
    # Google packs quota info into the JSON body. Parse defensively — bodies
    # we can't parse fall back to the status code alone.
    body_retry = None
    if status == 429 or "RESOURCE_EXHAUSTED" in body_text:
        try:
            obj = json.loads(body_text)
        except (json.JSONDecodeError, ValueError):
            obj = None
        if isinstance(obj, dict):
            err = obj.get("error", obj)
            if isinstance(err, dict):
                detail = str(err.get("message", ""))[:_MAX_DETAIL_CHARS]
                body_retry = _google_retry_delay(err)
    return RateLimitSignal(
        provider="google",
        status_code=status,
        retry_after=retry_after if retry_after is not None else body_retry,
        detail=detail,
    )


# ---------------------------------------------------------------------------
# Event construction
# ---------------------------------------------------------------------------


def signal_to_event(signal: RateLimitSignal, *, session: str) -> ev.Event | None:
    """Return a daemon event for this signal, or ``None`` if not noteworthy.

    Three cases:
      * ``status_code == 429`` → :class:`ev.RateLimitedEvent`.
      * Fraction-remaining at or below the near-limit threshold →
        :class:`ev.DecisionEvent` with summary ``"approaching rate limit"``.
        Decision events are cheap; the handoff engine ignores them, so they
        don't trigger a snapshot but they do show in the activity tail.
      * Otherwise → ``None``.
    """
    if signal.is_blocked:
        return ev.RateLimitedEvent(
            session=session,
            provider=signal.provider,
            retry_after=signal.retry_after,
            detail=signal.detail[:_MAX_DETAIL_CHARS],
        )
    frac = signal.fraction_remaining
    if frac is not None and frac <= _NEAR_LIMIT_FRACTION:
        return ev.DecisionEvent(
            session=session,
            summary="approaching rate limit",
            reasoning=(
                f"{signal.provider}: "
                f"requests_remaining={signal.requests_remaining}/"
                f"{signal.requests_limit}, "
                f"tokens_remaining={signal.tokens_remaining}/"
                f"{signal.tokens_limit}"
            ),
        )
    return None


def session_id_for(provider: Provider, started_at: str) -> str:
    """Construct a stable per-provider session id for proxy events.

    The proxy doesn't know which agent owns a request, so each provider
    gets its own session id keyed off the proxy's startup time. The handoff
    engine still fires on rate-limited events; snapshots will name the
    provider in the primer.
    """
    # ``started_at`` is the proxy-process start timestamp (YYYYMMDDhhmmss);
    # using it keeps every event from one mitmdump run in the same session.
    return f"proxy-{provider}-{started_at}"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _parse_retry_after(value: str | None) -> float | None:
    """``Retry-After`` is either seconds or an HTTP-date. We only accept seconds.

    HTTP-date parsing is rarely useful here — providers consistently return
    seconds — and dragging email.utils into a hot path isn't worth it.
    """
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _detail_from_anthropic(lc: dict[str, str]) -> str:
    parts = []
    rem = lc.get("anthropic-ratelimit-requests-remaining")
    lim = lc.get("anthropic-ratelimit-requests-limit")
    if rem is not None and lim is not None:
        parts.append(f"requests {rem}/{lim}")
    rem_tok = lc.get("anthropic-ratelimit-tokens-remaining")
    lim_tok = lc.get("anthropic-ratelimit-tokens-limit")
    if rem_tok is not None and lim_tok is not None:
        parts.append(f"tokens {rem_tok}/{lim_tok}")
    return ", ".join(parts)


def _detail_from_openai(lc: dict[str, str]) -> str:
    parts = []
    rem = lc.get("x-ratelimit-remaining-requests")
    lim = lc.get("x-ratelimit-limit-requests")
    if rem is not None and lim is not None:
        parts.append(f"requests {rem}/{lim}")
    rem_tok = lc.get("x-ratelimit-remaining-tokens")
    lim_tok = lc.get("x-ratelimit-limit-tokens")
    if rem_tok is not None and lim_tok is not None:
        parts.append(f"tokens {rem_tok}/{lim_tok}")
    return ", ".join(parts)


def _google_retry_delay(err: dict) -> float | None:
    """Walk Google's structured error envelope for ``retryDelay``."""
    details = err.get("details")
    if not isinstance(details, list):
        return None
    for entry in details:
        if not isinstance(entry, dict):
            continue
        delay = entry.get("retryDelay")
        if isinstance(delay, str) and delay.endswith("s"):
            try:
                return float(delay[:-1])
            except ValueError:
                continue
    return None
