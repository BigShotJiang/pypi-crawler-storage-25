"""Scan CLI-agent stdout for events worth recording.

Used by the PTY wrapper (:mod:`agent_relay.adapters.pty_wrapper`) to turn a
byte stream of agent output into a small set of structured events the
daemon can act on. The most important detection is rate limits: when an
agent prints a 429 or a "rate limit exceeded" line, we want a
:class:`RateLimitedEvent` in the log so the handoff engine can fire.

Why so simple?
  - CLI agents are wildly different. aider prints colourful prose; codex
    streams JSON-flavoured logs; gemini-cli wraps Google's quota errors in
    its own envelope. The one thing they all surface clearly is the
    underlying provider error string.
  - More structural signals (tool calls, decisions) tend to be very
    agent-specific. We leave those off by default and let per-agent
    "profiles" extend the classifier in later phases.

Patterns are matched per **line** (after ANSI stripping) so a partial chunk
boundary never produces a false positive. Each rate-limit pattern fires at
most once per classifier instance to prevent spam from agents that retry
in-process and re-print the error every attempt.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable
from dataclasses import dataclass, field

from agent_relay.daemon import events as ev

log = logging.getLogger("agent_relay.adapters.classifier")

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# Each entry is (regex, provider-slug). Order matters for the first-match
# heuristic but we try to keep patterns disjoint per provider.
_RATE_LIMIT_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Anthropic — official message strings and header names.
    (re.compile(r"\banthropic[-_]ratelimit\b", re.IGNORECASE), "anthropic"),
    (re.compile(r"\brate[_-]?limit_error\b", re.IGNORECASE), "anthropic"),
    (re.compile(r"\bRateLimitError\b"), "anthropic"),
    # OpenAI — official error code + header.
    (re.compile(r"\brate_limit_exceeded\b", re.IGNORECASE), "openai"),
    (re.compile(r"\bx-ratelimit\b", re.IGNORECASE), "openai"),
    # Google / Gemini — quota envelope.
    (re.compile(r"\bRESOURCE_EXHAUSTED\b"), "google"),
    (re.compile(r"\bquota\s+exceeded\b", re.IGNORECASE), "google"),
    # Generic — last-resort. We keep this very specific to a real HTTP
    # status to minimise false positives on prose containing "429" in
    # unrelated contexts.
    (
        re.compile(
            r"\bHTTP[/ ]?\s*429\b|\b429\s*(?:Too Many Requests|rate limit)\b", re.IGNORECASE
        ),
        "generic",
    ),
]

# Strip terminal escape sequences so ANSI colours don't break our matchers.
# Covers CSI sequences (most colours / cursor moves) and OSC sequences.
_ANSI_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]|\][^\x07\x1B]*(?:\x07|\x1B\\))")

# Cap detail strings stored on events to keep the JSONL log readable.
_MAX_DETAIL_CHARS = 200


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------


@dataclass
class OutputClassifier:
    """Line-buffered scanner that emits events for things it recognises.

    Feed it bytes with :meth:`feed` as you read from the child PTY. The
    classifier holds a small mutable buffer for partial lines; events are
    delivered to ``on_event`` (typically :func:`agent_relay.daemon.events.append`).
    """

    session_id: str
    agent: str
    on_event: Callable[[ev.Event], object]
    _buf: bytearray = field(default_factory=bytearray, init=False, repr=False)
    _rate_limit_fired: bool = field(default=False, init=False)
    last_seen_rate_limit_provider: str | None = field(default=None, init=False)

    def feed(self, chunk: bytes) -> None:
        """Ingest a byte chunk. Splits at newlines and scans each line."""
        if not chunk:
            return
        self._buf.extend(chunk)
        while True:
            try:
                nl = self._buf.index(0x0A)  # b'\n'
            except ValueError:
                break
            line = bytes(self._buf[:nl])
            del self._buf[: nl + 1]
            self._scan(line)

    def flush(self) -> None:
        """Scan the trailing partial line (no newline) on shutdown."""
        if not self._buf:
            return
        line = bytes(self._buf)
        self._buf.clear()
        self._scan(line)

    # -- internals -------------------------------------------------------

    def _scan(self, line: bytes) -> None:
        if self._rate_limit_fired:
            return
        try:
            text = line.decode("utf-8", errors="replace")
        except (UnicodeDecodeError, UnicodeError):
            return
        text = strip_ansi(text).strip()
        if not text:
            return
        provider = detect_rate_limit(text)
        if provider is None:
            return
        self._rate_limit_fired = True
        self.last_seen_rate_limit_provider = provider
        detail = text[:_MAX_DETAIL_CHARS]
        try:
            self.on_event(
                ev.RateLimitedEvent(
                    session=self.session_id,
                    provider=provider,
                    detail=detail,
                )
            )
        except Exception:  # noqa: BLE001 — never let a bad sink kill the wrapper
            log.exception("on_event raised")


# ---------------------------------------------------------------------------
# Pure helpers — useful in tests and to other adapters
# ---------------------------------------------------------------------------


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def detect_rate_limit(text: str) -> str | None:
    """Return the provider slug if ``text`` matches a known pattern."""
    for pattern, provider in _RATE_LIMIT_PATTERNS:
        if pattern.search(text):
            return provider
    return None
