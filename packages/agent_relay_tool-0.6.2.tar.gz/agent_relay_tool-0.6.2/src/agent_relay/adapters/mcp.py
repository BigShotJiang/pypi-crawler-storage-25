"""MCP server — lets Warp's native agent feed events into the relay log.

This module implements the
`Model Context Protocol <https://spec.modelcontextprotocol.io>`_ over stdio
with line-delimited JSON-RPC 2.0 framing (the standard MCP transport).
Warp Agent Mode (and any other MCP-aware client) registers
``relay mcp serve`` as a tool source; the agent then calls our tools each
turn and we translate those calls into :mod:`agent_relay.daemon.events`.

Three tools are exposed:

* ``relay_log_event`` — the agent reports a discrete event (decision,
  tool use, file change, rate-limit) and we persist it.
* ``relay_snapshot`` — the agent (or the user, via a Warp prompt) asks the
  relay to materialise a handoff snapshot of the current session.
* ``relay_session_status`` — a read-only query for the current session
  state, mainly useful for agents that want to know "did I already log
  this?" or "am I near the rate limit?".

Design notes:

* Pure dispatcher. :class:`MCPServer.handle` takes a JSON-RPC envelope and
  returns the response envelope (or ``None`` for notifications). The stdio
  loop is a thin shell around that — easy to test the protocol without
  spawning a subprocess.
* No daemon coupling. Tools call :func:`agent_relay.daemon.events.append`
  directly. If the daemon's running it picks the lines up via its tailer;
  if not, they wait on disk.
* Session lifecycle bound to the server's lifetime — one ``relay mcp
  serve`` invocation is one Warp session. The session id is generated at
  ``serve`` time and included in every event so the daemon's registry can
  fold them together.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any

from agent_relay.daemon import events as ev
from agent_relay.daemon.paths import is_valid_session_id

log = logging.getLogger("agent_relay.adapters.mcp")

MCP_PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "agent-relay"
SERVER_VERSION = "0.1.0"

# Surface a stable client slug independent of the actual ``clientInfo`` —
# we don't trust the client to identify itself accurately for the agent
# slug, so we always tag events as warp-agent.
DEFAULT_AGENT_SLUG = "warp-agent"


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Tool:
    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable[[MCPServer, dict[str, Any]], dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


@dataclass
class MCPServer:
    """Stateful MCP server. Holds the session id + initialization state."""

    session_id: str = ""
    agent_slug: str = DEFAULT_AGENT_SLUG
    cwd: str = field(default_factory=os.getcwd)
    initialized: bool = False
    _started_emitted: bool = False
    _tools: dict[str, Tool] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        if not self.session_id:
            self.session_id = generate_session_id(self.agent_slug)
        if not is_valid_session_id(self.session_id):
            raise ValueError(f"invalid session id: {self.session_id!r}")
        self._register_default_tools()

    # -- protocol entry point -------------------------------------------

    def handle(self, request: dict[str, Any]) -> dict[str, Any] | None:
        """Dispatch a JSON-RPC envelope. Returns the response, or ``None``
        for notifications (which by spec have no ``id``)."""
        method = request.get("method")
        if not isinstance(method, str):
            return _error(request.get("id"), -32600, "missing method")
        params = request.get("params") or {}
        if not isinstance(params, dict):
            return _error(request.get("id"), -32602, "params must be an object")
        # Notifications: no id field → no response.
        is_notification = "id" not in request
        if method == "notifications/initialized":
            self._on_initialized_notification()
            return None
        if is_notification:
            # Unknown notifications are silently accepted per spec.
            return None
        rid = request["id"]
        try:
            if method == "initialize":
                return self._h_initialize(rid, params)
            if method == "tools/list":
                return self._h_tools_list(rid)
            if method == "tools/call":
                return self._h_tools_call(rid, params)
            if method == "ping":
                # Some clients ping; reply with empty result.
                return _ok(rid, {})
            return _error(rid, -32601, f"unknown method: {method}")
        except Exception as exc:  # noqa: BLE001 — never crash the server
            log.exception("handler raised for method %s", method)
            return _error(rid, -32603, str(exc))

    # -- stdio loop ------------------------------------------------------

    def serve_stdio(
        self,
        stdin=None,
        stdout=None,
    ) -> None:
        """Run the MCP loop until stdin closes. Synchronous, single-threaded."""
        stdin = stdin if stdin is not None else sys.stdin
        stdout = stdout if stdout is not None else sys.stdout
        try:
            while True:
                line = stdin.readline()
                if not line:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    request = json.loads(line)
                except json.JSONDecodeError:
                    _write(stdout, _error(None, -32700, "parse error"))
                    continue
                if not isinstance(request, dict):
                    _write(stdout, _error(None, -32600, "request must be a JSON object"))
                    continue
                response = self.handle(request)
                if response is not None:
                    _write(stdout, response)
        finally:
            self._on_shutdown(reason="user_quit")

    # -- handlers --------------------------------------------------------

    def _h_initialize(self, rid: Any, params: dict[str, Any]) -> dict[str, Any]:
        # Try to honour the client's protocol version when we know it; fall
        # back to ours otherwise. Clients are expected to tolerate this.
        client_proto = params.get("protocolVersion")
        proto = client_proto if isinstance(client_proto, str) else MCP_PROTOCOL_VERSION
        client_info = params.get("clientInfo") or {}
        if isinstance(client_info, dict):
            name = str(client_info.get("name", "")).lower()
            if "warp" in name:
                self.agent_slug = "warp-agent"
        return _ok(
            rid,
            {
                "protocolVersion": proto,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            },
        )

    def _on_initialized_notification(self) -> None:
        self.initialized = True
        self._emit_started_once()

    def _h_tools_list(self, rid: Any) -> dict[str, Any]:
        return _ok(rid, {"tools": [t.to_dict() for t in self._tools.values()]})

    def _h_tools_call(self, rid: Any, params: dict[str, Any]) -> dict[str, Any]:
        name = params.get("name")
        if not isinstance(name, str) or name not in self._tools:
            return _ok(
                rid,
                {
                    "content": [{"type": "text", "text": f"unknown tool: {name}"}],
                    "isError": True,
                },
            )
        args = params.get("arguments") or {}
        if not isinstance(args, dict):
            return _ok(
                rid,
                {
                    "content": [{"type": "text", "text": "arguments must be an object"}],
                    "isError": True,
                },
            )
        # Treat any tool call as evidence the agent is live — Warp may skip
        # the ``notifications/initialized`` step in some versions.
        self._emit_started_once()
        tool = self._tools[name]
        try:
            result = tool.handler(self, args)
            return _ok(rid, result)
        except Exception as exc:  # noqa: BLE001 — return as MCP tool error
            log.exception("tool %s failed", name)
            return _ok(
                rid,
                {
                    "content": [{"type": "text", "text": f"error: {exc}"}],
                    "isError": True,
                },
            )

    # -- lifecycle helpers ----------------------------------------------

    def _emit_started_once(self) -> None:
        if self._started_emitted:
            return
        self._started_emitted = True
        ev.append(
            ev.StartedEvent(
                session=self.session_id,
                agent=self.agent_slug,
                cwd=self.cwd,
                pid=os.getpid(),
            )
        )

    def _on_shutdown(self, *, reason: str) -> None:
        if not self._started_emitted:
            return
        ev.append(ev.StoppedEvent(session=self.session_id, reason=reason))

    # -- tools -----------------------------------------------------------

    def _register_default_tools(self) -> None:
        self._tools = {t.name: t for t in default_tools()}


# ---------------------------------------------------------------------------
# Tool handlers (pure-ish — emit events and return text responses)
# ---------------------------------------------------------------------------


def _tool_log_event(server: MCPServer, args: dict[str, Any]) -> dict[str, Any]:
    """Persist a discrete event reported by the agent.

    ``event_type`` selects the shape; we accept the same set documented in
    docs/spec/event-protocol.md plus a synthetic "decision" alias for
    agents that don't want to distinguish.
    """
    et = str(args.get("event_type") or "decision").strip().lower()
    event: ev.Event
    if et == "tool_used":
        event = ev.ToolUsedEvent(
            session=server.session_id,
            tool=str(args.get("tool") or "unknown"),
            args_redacted=_safe_dict(args.get("args_redacted")),
            ok=_bool_or_none(args.get("ok")),
        )
    elif et == "file_changed":
        event = ev.FileChangedEvent(
            session=server.session_id,
            path=str(args.get("path") or ""),
            hunks=_int_or_zero(args.get("hunks")),
            op=_op(args.get("op")),
        )
    elif et == "rate_limited":
        event = ev.RateLimitedEvent(
            session=server.session_id,
            provider=str(args.get("provider") or "unknown"),
            retry_after=_float_or_none(args.get("retry_after")),
            detail=str(args.get("detail") or "")[:240],
        )
    elif et == "stopped":
        event = ev.StoppedEvent(
            session=server.session_id,
            reason=str(args.get("reason") or "done"),
        )
    else:
        event = ev.DecisionEvent(
            session=server.session_id,
            summary=str(args.get("summary") or args.get("text") or "")[:240],
            reasoning=str(args.get("reasoning") or "")[:1024],
        )
    ev.append(event)
    return _text_result(f"logged {et}")


def _tool_snapshot(server: MCPServer, args: dict[str, Any]) -> dict[str, Any]:
    """Trigger an immediate handoff snapshot for the current session.

    Reuses the Phase 3 pipeline by emitting a synthetic rate_limited event
    with provider="user-initiated" so the daemon's handoff engine fires.
    """
    detail = str(args.get("reason") or "agent-requested snapshot")[:240]
    ev.append(
        ev.RateLimitedEvent(
            session=server.session_id,
            provider="user-initiated",
            detail=detail,
        )
    )
    return _text_result(f"snapshot requested for session {server.session_id}")


def _tool_session_status(server: MCPServer, _args: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "session": server.session_id,
        "agent": server.agent_slug,
        "cwd": server.cwd,
    }
    return _text_result(json.dumps(payload))


def default_tools() -> Iterable[Tool]:
    yield Tool(
        name="relay_log_event",
        description=(
            "Record a discrete event about the current session. "
            "Use event_type=decision for reasoning steps, tool_used when "
            "you invoke a tool, file_changed when you edit a file, "
            "rate_limited when the provider rate-limits you."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "event_type": {
                    "type": "string",
                    "enum": ["decision", "tool_used", "file_changed", "rate_limited", "stopped"],
                },
                "summary": {"type": "string"},
                "reasoning": {"type": "string"},
                "tool": {"type": "string"},
                "args_redacted": {"type": "object"},
                "ok": {"type": "boolean"},
                "path": {"type": "string"},
                "hunks": {"type": "integer"},
                "op": {"type": "string", "enum": ["create", "modify", "delete"]},
                "provider": {"type": "string"},
                "retry_after": {"type": "number"},
                "detail": {"type": "string"},
                "reason": {"type": "string"},
            },
        },
        handler=_tool_log_event,
    )
    yield Tool(
        name="relay_snapshot",
        description=(
            "Materialise a handoff snapshot for the current session right now. "
            "Use when the agent is about to stop or hand off."
        ),
        input_schema={
            "type": "object",
            "properties": {"reason": {"type": "string"}},
        },
        handler=_tool_snapshot,
    )
    yield Tool(
        name="relay_session_status",
        description="Return the current session id, agent slug, and cwd as JSON text.",
        input_schema={"type": "object", "properties": {}},
        handler=_tool_session_status,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def generate_session_id(agent_slug: str) -> str:
    stamp = time.strftime("%Y%m%d%H%M%S", time.gmtime())
    safe = "".join(c for c in agent_slug if c.isalnum() or c in "-_")[:16] or "warp"
    rand = uuid.uuid4().hex[:8]
    return f"{safe}-{stamp}-{rand}"


def _ok(rid: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def _error(rid: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": rid,
        "error": {"code": code, "message": message},
    }


def _text_result(text: str, is_error: bool = False) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": text}], "isError": is_error}


def _write(stream, message: dict[str, Any]) -> None:
    stream.write(json.dumps(message, separators=(",", ":"), ensure_ascii=False) + "\n")
    stream.flush()


def _safe_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _int_or_zero(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _float_or_none(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _bool_or_none(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    return None


def _op(value: Any) -> str:
    v = str(value or "modify").lower()
    return v if v in ("create", "modify", "delete") else "modify"
