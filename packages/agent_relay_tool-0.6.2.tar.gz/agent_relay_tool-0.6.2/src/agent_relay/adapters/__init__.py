"""Adapters — per-tool integrations that emit events into the daemon log.

See ``docs/spec/event-protocol.md`` for the contract every adapter writes
against. Phase 1 ships ``claude_code``; Phases 4–6 add the PTY wrapper,
VS Code extension, and Warp MCP server.
"""

from agent_relay.adapters import claude_code

__all__ = ["claude_code"]
