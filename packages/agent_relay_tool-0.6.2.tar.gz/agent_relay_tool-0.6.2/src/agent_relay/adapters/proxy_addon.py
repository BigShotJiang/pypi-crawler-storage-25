"""mitmproxy addon — loads pure proxy logic into a real HTTPS intercept.

Wire-up::

    mitmdump -p 9089 \\
        --set confdir=~/.relay/proxy \\
        -s "$(python -m agent_relay.adapters.proxy_addon --print-script-path)"

The CLI subcommand ``relay proxy start`` does that for the user.

We try-import mitmproxy lazily so the rest of the codebase (and the CLI)
keeps working when ``mitmproxy`` isn't installed — it's an optional dep
declared in ``pyproject.toml`` as ``agent-relay-tool[proxy]``.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from agent_relay.adapters import proxy as proxy_lib
from agent_relay.daemon import events as ev
from agent_relay.daemon.paths import is_valid_session_id

log = logging.getLogger("agent_relay.adapters.proxy_addon")

# Stamp the proxy's startup time once at import — every signal from this
# process shares it so the daemon's session registry sees one session per
# provider per ``relay proxy start`` invocation.
_PROXY_START_STAMP = time.strftime("%Y%m%d%H%M%S", time.gmtime())


class RelayProxyAddon:
    """mitmproxy addon. Method signature follows mitmproxy's contract.

    We only care about ``response`` — anything else flows through untouched.
    """

    def __init__(self) -> None:
        self._announced: set[str] = set()

    def response(self, flow: Any) -> None:  # noqa: ANN401 — mitmproxy.http.HTTPFlow
        try:
            req = flow.request
            resp = flow.response
            if resp is None:
                return
            host = req.host or req.headers.get("host", "") or ""
            if not proxy_lib.is_target(host):
                return
            provider = proxy_lib.classify_host(host)

            session = proxy_lib.session_id_for(provider, _PROXY_START_STAMP)
            if not is_valid_session_id(session):
                log.warning("proxy: bad session id %r", session)
                return

            # mitmproxy headers are case-insensitive but we pass a dict to the
            # pure parser; lower-casing the keys keeps the contract clean.
            headers = {k.lower(): v for k, v in resp.headers.items()}

            # mitmproxy lets us call .text for decoded bodies; on failure
            # (binary / unknown encoding) we just send "" so the Google
            # parser falls back to status code only.
            try:
                body_text = resp.get_text() or ""
            except Exception:  # noqa: BLE001 — defensive against codec bugs
                body_text = ""

            signal = proxy_lib.parse_signal(
                provider=provider,
                status_code=resp.status_code,
                headers=headers,
                body_text=body_text,
            )

            self._ensure_session_started(session, provider, req)
            event = proxy_lib.signal_to_event(signal, session=session)
            if event is None:
                return
            ev.append(event)
        except Exception:  # noqa: BLE001 — never crash mitmproxy from our addon
            log.exception("proxy addon raised")

    # -- helpers --------------------------------------------------------

    def _ensure_session_started(self, session: str, provider: str, req: Any) -> None:
        if session in self._announced:
            return
        self._announced.add(session)
        ev.append(
            ev.StartedEvent(
                session=session,
                agent=f"proxy:{provider}",
                cwd=os.getcwd(),
                pid=os.getpid(),
            )
        )


# mitmproxy auto-loads a module-level ``addons`` list. Keeping the symbol
# named ``addons`` is part of mitmproxy's loader contract.
addons = [RelayProxyAddon()]


# ---------------------------------------------------------------------------
# Tiny CLI: `python -m agent_relay.adapters.proxy_addon --print-script-path`
# ---------------------------------------------------------------------------


def _main() -> int:
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--print-script-path":
        print(os.path.abspath(__file__))
        return 0
    sys.stderr.write(
        "agent_relay.adapters.proxy_addon is a mitmproxy script; "
        "load it via `mitmdump -s <path>` or `relay proxy start`.\n"
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(_main())
