"""Detect which agents the user already has installed.

Used by ``relay install`` to decide what to prompt about. Each detector is a
best-effort, no-network check that returns either a :class:`Detection` with
an absolute path/identifier, or ``None`` if the agent isn't present.

Detectors are deliberately conservative: we only prompt about something if
we found it, and we'd rather false-negative (user runs install again) than
false-positive (user gets prompted for a tool they don't have).
"""

from __future__ import annotations

import shutil
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Detection:
    """An agent we believe the user has installed."""

    slug: str  # stable identifier — used by the install flow and config
    name: str  # human-friendly label
    location: str  # path or descriptor shown to the user
    adapter_phase: int  # which phase ships the adapter; >1 means "later"


def detect_claude_code() -> Detection | None:
    # Two signals: the ``claude`` CLI on PATH, or the well-known config dir.
    which = shutil.which("claude")
    if which:
        return Detection("claude-code", "Claude Code", which, adapter_phase=1)
    config_dir = Path.home() / ".claude"
    if config_dir.is_dir():
        return Detection("claude-code", "Claude Code", str(config_dir), adapter_phase=1)
    return None


def detect_cursor() -> Detection | None:
    # macOS app bundle, Linux/Windows binary on PATH, or `cursor` CLI.
    candidates = [
        ("/Applications/Cursor.app", sys.platform == "darwin"),
    ]
    for path, gate in candidates:
        if gate and Path(path).exists():
            return Detection("cursor", "Cursor", path, adapter_phase=5)
    which = shutil.which("cursor")
    if which:
        return Detection("cursor", "Cursor", which, adapter_phase=5)
    return None


def detect_antigravity() -> Detection | None:
    candidates = [
        ("/Applications/Antigravity.app", sys.platform == "darwin"),
    ]
    for path, gate in candidates:
        if gate and Path(path).exists():
            return Detection("antigravity", "Antigravity", path, adapter_phase=5)
    which = shutil.which("antigravity")
    if which:
        return Detection("antigravity", "Antigravity", which, adapter_phase=5)
    return None


def detect_windsurf() -> Detection | None:
    candidates = [
        ("/Applications/Windsurf.app", sys.platform == "darwin"),
    ]
    for path, gate in candidates:
        if gate and Path(path).exists():
            return Detection("windsurf", "Windsurf", path, adapter_phase=5)
    which = shutil.which("windsurf")
    if which:
        return Detection("windsurf", "Windsurf", which, adapter_phase=5)
    return None


def detect_vscode() -> Detection | None:
    """VS Code proper. Cursor / Antigravity / Windsurf are checked separately
    because they're forks with their own marketplaces."""
    candidates = [
        ("/Applications/Visual Studio Code.app", sys.platform == "darwin"),
    ]
    for path, gate in candidates:
        if gate and Path(path).exists():
            return Detection("vscode", "VS Code", path, adapter_phase=5)
    which = shutil.which("code")
    if which:
        return Detection("vscode", "VS Code", which, adapter_phase=5)
    return None


def detect_warp() -> Detection | None:
    candidates = [
        ("/Applications/Warp.app", sys.platform == "darwin"),
        (str(Path.home() / ".local" / "share" / "warp-terminal"), sys.platform == "linux"),
    ]
    for path, gate in candidates:
        if gate and Path(path).exists():
            return Detection("warp", "Warp", path, adapter_phase=6)
    return None


def detect_codex_cli() -> Detection | None:
    which = shutil.which("codex")
    if which:
        return Detection("codex", "Codex CLI", which, adapter_phase=4)
    return None


def detect_aider() -> Detection | None:
    which = shutil.which("aider")
    if which:
        return Detection("aider", "aider", which, adapter_phase=4)
    return None


def detect_gemini_cli() -> Detection | None:
    which = shutil.which("gemini")
    if which:
        return Detection("gemini-cli", "Gemini CLI", which, adapter_phase=4)
    return None


def detect_all() -> list[Detection]:
    """Run every detector and return the ones that fired, in display order.

    The order here is the order shown by ``relay install``; we put the
    primary supported adapter (Claude Code) first, then editors, then CLI
    agents, then terminal-native agents.
    """
    detectors = (
        detect_claude_code,
        detect_cursor,
        detect_antigravity,
        detect_vscode,
        detect_windsurf,
        detect_codex_cli,
        detect_aider,
        detect_gemini_cli,
        detect_warp,
    )
    found: list[Detection] = []
    for fn in detectors:
        result = fn()
        if result is not None:
            found.append(result)
    return found
