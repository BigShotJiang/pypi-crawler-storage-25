"""Claude Code adapter — installs hooks into ``~/.claude/settings.json``.

CC fires named hooks at well-defined moments (``PreToolUse``,
``PostToolUse``, ``Stop``, ``Notification``, ``UserPromptSubmit``). Each
hook is a shell command CC runs synchronously. We register a small shell
one-liner that appends a JSON event line to the per-session log file —
literally the "B / direct file append" delivery path from
``docs/spec/event-protocol.md``.

Design notes:

* **No daemon required at capture time.** The shell hook only writes to
  ``~/.relay/events/$SESSION.jsonl``. If the daemon is running it picks
  the lines up via its tailer; if not, they sit on disk waiting.
* **Idempotent.** ``install()`` is safe to run repeatedly; it only adds
  hooks that aren't already there. ``uninstall()`` removes only the
  entries this adapter wrote (matched by command prefix).
* **Settings file is preserved.** We read the user's existing
  ``settings.json``, merge our hooks, and write it back. Unknown keys are
  passed through untouched. Indentation is normalised to 2 spaces, which
  matches what CC itself writes.

The hook command is a portable POSIX shell line. Windows support is added
when the Phase 2 install flow lands — CC on Windows runs hooks through
``cmd.exe``, so we'll need a parallel ``.cmd`` variant.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path

from agent_relay.daemon.paths import event_log_path, events_dir

# Marker the adapter writes into each hook command so ``uninstall()`` can
# recognise its own entries even if the file is hand-edited.
HOOK_MARKER = "# agent-relay"

# Hook events we install — kept tight in Phase 1. More can be added later
# (UserPromptSubmit, SubagentStop, PreCompact) without changing this list's
# shape.
DEFAULT_HOOKS: tuple[str, ...] = (
    "PreToolUse",
    "PostToolUse",
    "Notification",
    "Stop",
)

DEFAULT_SETTINGS_PATH = Path.home() / ".claude" / "settings.json"


@dataclass(frozen=True, slots=True)
class InstallResult:
    """What ``install()`` actually did. Used by the CLI for a useful summary."""

    path: Path
    installed: tuple[str, ...]
    skipped: tuple[str, ...]


def install(settings_path: Path | None = None) -> InstallResult:
    """Add agent-relay hooks to a CC settings file.

    Returns the list of hook events newly installed and those skipped
    (already present). Creates the parent directory and the file itself if
    they don't exist.
    """
    target = settings_path or DEFAULT_SETTINGS_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    data = _load(target)
    hooks_block = data.setdefault("hooks", {})

    installed: list[str] = []
    skipped: list[str] = []
    for event_name in DEFAULT_HOOKS:
        command = _hook_command(event_name)
        entry_list = hooks_block.setdefault(event_name, [])
        if not isinstance(entry_list, list):
            # User has the older single-object form. Promote it to a list
            # so we can append cleanly without clobbering their config.
            entry_list = [entry_list]
            hooks_block[event_name] = entry_list
        if _has_our_hook(entry_list):
            skipped.append(event_name)
            continue
        entry_list.append({"matcher": "*", "hooks": [{"type": "command", "command": command}]})
        installed.append(event_name)

    _save(target, data)
    return InstallResult(
        path=target,
        installed=tuple(installed),
        skipped=tuple(skipped),
    )


def uninstall(settings_path: Path | None = None) -> tuple[Path, int]:
    """Remove every hook entry this adapter installed. Returns (path, removed)."""
    target = settings_path or DEFAULT_SETTINGS_PATH
    if not target.exists():
        return target, 0
    data = _load(target)
    hooks_block = data.get("hooks") or {}
    removed = 0
    empty_event_names: list[str] = []
    for event_name, entry_list in list(hooks_block.items()):
        if not isinstance(entry_list, list):
            continue
        survivors = [e for e in entry_list if not _entry_is_ours(e)]
        removed += len(entry_list) - len(survivors)
        if survivors:
            hooks_block[event_name] = survivors
        else:
            empty_event_names.append(event_name)
    for name in empty_event_names:
        hooks_block.pop(name, None)
    if not hooks_block:
        data.pop("hooks", None)
    _save(target, data)
    return target, removed


def is_installed(settings_path: Path | None = None) -> bool:
    target = settings_path or DEFAULT_SETTINGS_PATH
    if not target.exists():
        return False
    data = _load(target)
    hooks_block = data.get("hooks") or {}
    return any(
        isinstance(entry_list, list) and _has_our_hook(entry_list)
        for entry_list in hooks_block.values()
    )


def detect_claude_code() -> bool:
    """Best-effort check that the user has Claude Code installed.

    Used by the install flow to decide whether to prompt. Two cheap
    signals: the ``claude`` CLI on PATH, or an existing ``~/.claude/``
    directory (CC creates it on first run even before the user opens
    settings).
    """
    if shutil.which("claude"):
        return True
    return (Path.home() / ".claude").is_dir()


# ---------------------------------------------------------------------------
# Hook command construction
# ---------------------------------------------------------------------------


def _hook_command(event_name: str) -> str:
    """Render the shell one-liner that fires inside CC.

    CC passes hook payloads on stdin as JSON, including the session id and
    the tool/notification details. Our line:

    1. Reads stdin into a variable.
    2. Pulls out ``session_id`` with a small Python one-liner (avoids
       requiring ``jq`` on the user's machine — Python is guaranteed since
       CC itself is a Python-distributable tool).
    3. Appends a JSONL event to the relay log file. The event type maps
       1:1 with the hook name via ``HOOK_TO_EVENT``.

    The whole thing is wrapped in ``sh -c '…'`` so it can be embedded as a
    single command string in CC's JSON settings.
    """
    # Use a literal $HOME-style expansion inside the shell command rather
    # than baking the user's absolute home path in — keeps settings.json
    # portable between machines if a user syncs dotfiles.
    log_target = "$HOME/.relay/events/$AR_SESSION.jsonl"
    event_type = _HOOK_TO_EVENT[event_name]
    # Single quotes in the outer wrapper keep the shell literal; we escape
    # the inner single quotes by closing-then-reopening them.
    py = (
        "import sys,json,os,time;"
        "p=sys.stdin.read();"
        "d=json.loads(p) if p.strip() else {};"
        "sid=d.get('session_id') or os.environ.get('AR_SESSION') or 'unknown';"
        "ts=time.strftime('%Y-%m-%dT%H:%M:%S',time.gmtime())+'.'+'{:03d}'.format(int((time.time()%1)*1000))+'Z';"
        f"ev={{'t':'{event_type}','session':sid,'ts':ts,'agent':'claude-code','cwd':os.getcwd()}};"
        # tool_used carries the tool name when CC provides it.
        "tool=d.get('tool_name') or d.get('tool');"
        "ev['tool']=tool if tool else None;"
        # Strip None entries to keep lines compact.
        "ev={k:v for k,v in ev.items() if v is not None};"
        "os.makedirs(os.path.expanduser('~/.relay/events'),exist_ok=True);"
        "open(os.path.expanduser('~/.relay/events/'+sid+'.jsonl'),'a').write(json.dumps(ev,separators=(',', ':'))+'\\n')"
    )
    # Keep marker at the *end* so the command's effective behavior isn't
    # affected, but our uninstaller can spot it.
    return f'AR_SESSION=${{AR_SESSION:-$CLAUDE_SESSION_ID}} python3 -c "{py}"  {HOOK_MARKER} {event_name}  # log:{log_target}'


# Maps CC hook event names to relay event tags. ``Notification`` is mapped
# to ``rate_limited`` because that's the CC channel a 429 surfaces on; the
# Python one-liner above sets ``t`` literally, so when we eventually want
# both we'll either branch in the hook script or split the hook by matcher.
_HOOK_TO_EVENT = {
    "PreToolUse": "tool_used",
    "PostToolUse": "tool_used",
    "Notification": "rate_limited",
    "Stop": "stopped",
}


def _has_our_hook(entry_list: list) -> bool:
    return any(_entry_is_ours(entry) for entry in entry_list)


def _entry_is_ours(entry) -> bool:
    if not isinstance(entry, dict):
        return False
    hooks = entry.get("hooks") or []
    if not isinstance(hooks, list):
        return False
    for hook in hooks:
        if isinstance(hook, dict) and HOOK_MARKER in str(hook.get("command", "")):
            return True
    return False


# ---------------------------------------------------------------------------
# settings.json I/O
# ---------------------------------------------------------------------------


def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    if not text.strip():
        return {}
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        # CC's settings file is hand-editable; if it's malformed we leave
        # it alone rather than overwriting the user's work.
        raise
    if not isinstance(obj, dict):
        raise ValueError("settings.json must contain a JSON object at the top level")
    return obj


def _save(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(str(tmp), str(path))


# ---------------------------------------------------------------------------
# Direct helpers (for tests, and for other adapters that want to inject
# events using the same on-disk path as the CC hook)
# ---------------------------------------------------------------------------


def emit_event_line(session_id: str, line: str) -> Path:
    """Append a pre-encoded JSON line to a session's log. Returns the path."""
    events_dir().mkdir(parents=True, exist_ok=True)
    target = event_log_path(session_id)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(line.rstrip("\n") + "\n")
    return target
