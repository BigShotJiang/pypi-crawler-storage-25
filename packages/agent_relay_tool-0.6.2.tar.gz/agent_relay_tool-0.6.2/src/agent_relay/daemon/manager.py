"""Start / stop / status for the daemon process.

Three execution modes:

* ``start_foreground()`` — runs the server in this process. Used by
  launchd/systemd in Phase 2 and by tests that need the daemon under a
  process supervisor.
* ``start_background()`` — double-forks (POSIX) so the daemon survives the
  parent shell. Writes the new pid to ``~/.relay/relay.pid``.
* ``stop()`` — reads the pid file, sends ``SIGTERM``, optionally waits.

``status()`` returns a lightweight tuple ``(running, pid, responsive)`` so
the CLI can print a useful one-liner without holding a socket connection
open longer than needed.
"""

from __future__ import annotations

import contextlib
import errno
import logging
import os
import signal
import socket
import sys
import time
from dataclasses import dataclass

from agent_relay.daemon import ipc
from agent_relay.daemon.paths import (
    daemon_log_path,
    ensure_layout,
    logs_dir,
    pid_file,
    socket_path,
)
from agent_relay.daemon.server import Server

log = logging.getLogger("agent_relay.daemon.manager")


@dataclass(frozen=True, slots=True)
class DaemonStatus:
    running: bool
    pid: int | None
    responsive: bool


# ---------------------------------------------------------------------------
# Foreground
# ---------------------------------------------------------------------------


def start_foreground() -> int:
    """Run the server in the current process. Returns the exit code.

    Installs ``SIGTERM`` / ``SIGINT`` handlers that ask the server to shut
    down cleanly, then waits for the loop to exit.
    """
    ensure_layout()
    _write_pid(os.getpid())
    server = Server()

    def _on_signal(signum, _frame):
        log.info("received signal %d, shutting down", signum)
        server.shutdown()

    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT, _on_signal)

    try:
        server.serve_forever()
        return 0
    finally:
        _clear_pid()


# ---------------------------------------------------------------------------
# Background
# ---------------------------------------------------------------------------


def start_background() -> int:
    """Double-fork into a detached daemon process. Returns the child pid.

    POSIX-only. Phase 2 adds the Windows path (a separate hidden process
    started by the install flow).
    """
    if sys.platform == "win32":
        raise NotImplementedError("background start is POSIX-only; Phase 2 adds Windows")
    existing = status()
    if existing.running and existing.responsive:
        return existing.pid or 0

    # First fork — parent returns to the caller, child continues.
    pid = os.fork()
    if pid > 0:
        # Wait briefly for the grandchild to come up and write its pid.
        for _ in range(50):
            time.sleep(0.05)
            st = status()
            if st.running:
                os.waitpid(pid, 0)
                return st.pid or 0
        os.waitpid(pid, 0)
        raise RuntimeError("daemon failed to start within timeout")

    # First child — detach from controlling terminal and fork again.
    os.setsid()
    pid = os.fork()
    if pid > 0:
        os._exit(0)

    # Grandchild — the actual daemon. Reopen std streams to a log file so
    # nothing escapes back to the user's shell.
    _redirect_std_streams()
    try:
        start_foreground()
    finally:
        os._exit(0)


# ---------------------------------------------------------------------------
# Stop
# ---------------------------------------------------------------------------


def stop(timeout_secs: float = 5.0) -> bool:
    """Ask the daemon to exit. Returns True if it did within the timeout."""
    st = status()
    if not st.running or st.pid is None:
        return True
    try:
        os.kill(st.pid, signal.SIGTERM)
    except ProcessLookupError:
        _clear_pid()
        return True
    deadline = time.monotonic() + timeout_secs
    while time.monotonic() < deadline:
        if not _is_alive(st.pid):
            _clear_pid()
            return True
        time.sleep(0.05)
    return False


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------


def status() -> DaemonStatus:
    """Combine pid-file liveness with a socket ping for an accurate read."""
    pid = _read_pid()
    if pid is None or not _is_alive(pid):
        if pid is not None:
            # Stale pid file; clean it up so subsequent calls are accurate.
            _clear_pid()
        return DaemonStatus(running=False, pid=None, responsive=False)
    return DaemonStatus(running=True, pid=pid, responsive=ping())


def ping(timeout_secs: float = 0.5) -> bool:
    """Open a transient connection and round-trip a ``ping`` request."""
    addr = socket_path()
    if isinstance(addr, str):
        # Windows path not wired in Phase 1.
        return False
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(timeout_secs)
        sock.connect(str(addr))
        sock.sendall(ipc.encode_request(ipc.Request(id=1, method="ping", params={})))
        data = sock.recv(4096)
        sock.close()
        if not data:
            return False
        resp = ipc.decode_response(data.splitlines()[0])
        return bool(resp.result and resp.result.get("ok"))
    except (OSError, ipc.IpcError):
        return False


# ---------------------------------------------------------------------------
# pid file helpers
# ---------------------------------------------------------------------------


def _write_pid(pid: int) -> None:
    ensure_layout()
    pid_file().write_text(str(pid), encoding="utf-8")


def _read_pid() -> int | None:
    path = pid_file()
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _clear_pid() -> None:
    with contextlib.suppress(FileNotFoundError):
        pid_file().unlink()


def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError as exc:
        return exc.errno == errno.EPERM  # EPERM => exists, owned by another user
    return True


def _redirect_std_streams() -> None:
    logs_dir().mkdir(parents=True, exist_ok=True)
    log_path = daemon_log_path()
    devnull = os.open(os.devnull, os.O_RDONLY)
    out = os.open(str(log_path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    os.dup2(devnull, 0)
    os.dup2(out, 1)
    os.dup2(out, 2)
    os.close(devnull)
    os.close(out)
