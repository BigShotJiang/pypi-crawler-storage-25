"""``relay self-update`` — pull the latest binary and replace ourselves.

This command only does something useful when the user is running the
PyInstaller binary. For PyPI/pip installs we point the user back at ``pip``
/ ``uv tool upgrade`` and exit cleanly.

POSIX implementation: write the new binary alongside the current
executable, ``rename(2)`` the old one to ``<name>.bak`` (POSIX lets you
rename a running executable; the kernel keeps the inode alive until our
process exits), then rename the new one into place. Atomic on the same
filesystem.

Windows implementation: queue a replacer ``.cmd`` and re-launch — Windows
won't let us overwrite a running executable. We document that constraint
and ask the user to re-run a one-liner instead of trying to fight it.
"""

from __future__ import annotations

import contextlib
import json
import os
import platform
import stat
import sys
import tempfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from agent_relay import __version__

GITHUB_REPO = "bethvourc/agent--relay"
LATEST_RELEASE_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
RELEASE_TAG_URL_FMT = f"https://api.github.com/repos/{GITHUB_REPO}/releases/tags/{{tag}}"


# ---------------------------------------------------------------------------
# Asset selection
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class AssetSelection:
    """Which release asset matches the current host."""

    name: str  # e.g. "relay-darwin-arm64"
    is_windows: bool


def asset_name_for_host(
    *,
    sys_platform: str | None = None,
    machine: str | None = None,
) -> AssetSelection | None:
    """Return the asset we'd pull for the current host, or ``None`` if the
    host isn't covered by our release matrix."""
    p = (sys_platform or sys.platform).lower()
    m = (machine or platform.machine()).lower()
    if p.startswith("darwin"):
        if m in ("arm64", "aarch64"):
            return AssetSelection("relay-darwin-arm64", is_windows=False)
        # Intel macOS has no published binary — GitHub deprecated macos-13.
        # Returning None routes the user to the friendly "no release asset"
        # message; they reinstall via the curl one-liner (uv fallback) for
        # an updated source-based install.
    elif p.startswith("linux"):
        if m in ("x86_64", "amd64"):
            return AssetSelection("relay-linux-x64", is_windows=False)
        if m in ("arm64", "aarch64"):
            return AssetSelection("relay-linux-arm64", is_windows=False)
    elif p.startswith("win"):
        if m in ("x86_64", "amd64"):
            return AssetSelection("relay-windows-x64.exe", is_windows=True)
    return None


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------


def parse_version(tag: str) -> tuple[int, ...]:
    """Parse a tag like ``v0.5.6`` or ``0.5.6.dev1`` into a tuple.

    Non-numeric trailers (``dev``, ``rc``) are dropped — we treat them as
    "same numeric version" for comparison purposes, which is conservative
    (a dev build won't trigger a self-update when it shouldn't).
    """
    s = tag.strip().lstrip("v")
    parts: list[int] = []
    for chunk in s.replace("-", ".").split("."):
        try:
            parts.append(int(chunk))
        except ValueError:
            break
    return tuple(parts)


def is_newer(remote: str, local: str) -> bool:
    """Strictly newer? Equal-or-older returns False."""
    return parse_version(remote) > parse_version(local)


# ---------------------------------------------------------------------------
# GitHub API
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Release:
    tag: str
    assets: dict[str, str]  # asset name → browser_download_url


def fetch_release(tag: str | None = None, *, timeout: float = 8.0) -> Release:
    url = LATEST_RELEASE_URL if tag is None else RELEASE_TAG_URL_FMT.format(tag=tag)
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    tag_name = str(data.get("tag_name") or "")
    assets = {
        str(a.get("name") or ""): str(a.get("browser_download_url") or "")
        for a in data.get("assets") or []
        if isinstance(a, dict)
    }
    return Release(tag=tag_name, assets=assets)


def fetch_release_safe(tag: str | None = None) -> Release | None:
    """Like :func:`fetch_release` but swallows network errors and returns
    ``None`` so the caller can degrade gracefully."""
    try:
        return fetch_release(tag)
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
        return None


# ---------------------------------------------------------------------------
# Self-update flow
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class UpdateOutcome:
    upgraded: bool
    message: str
    new_version: str | None = None


def run_self_update(
    *,
    tag: str | None = None,
    dry_run: bool = False,
) -> UpdateOutcome:
    """Top-level orchestrator. Pure-ish: I/O routed through small helpers
    so tests can monkey-patch them.

    Returns an :class:`UpdateOutcome`. The CLI handler converts that into
    user output + exit code.
    """
    if not _running_from_binary():
        return UpdateOutcome(
            upgraded=False,
            message=(
                "self-update only applies to the native binary install. "
                "Upgrade your pip/uv install with `pip install -U agent-relay-tool` "
                "or `uv tool upgrade agent-relay-tool`."
            ),
        )

    asset = asset_name_for_host()
    if asset is None:
        return UpdateOutcome(
            upgraded=False,
            message=(
                f"no release asset for this platform ({sys.platform} / {platform.machine()}). "
                "Use the install script to bootstrap, or fall back to `pip install -U agent-relay-tool`."
            ),
        )

    release = fetch_release_safe(tag)
    if release is None or not release.tag:
        return UpdateOutcome(
            upgraded=False,
            message="could not reach GitHub to check for updates",
        )

    if not is_newer(release.tag, __version__):
        return UpdateOutcome(
            upgraded=False,
            message=f"already on the latest version ({__version__})",
        )

    asset_url = release.assets.get(asset.name)
    if not asset_url:
        return UpdateOutcome(
            upgraded=False,
            message=f"release {release.tag} has no asset named {asset.name}",
        )
    sha_url = release.assets.get(f"{asset.name}.sha256")

    if dry_run:
        return UpdateOutcome(
            upgraded=False,
            message=f"would download {asset.name} from {asset_url}",
            new_version=release.tag,
        )

    if asset.is_windows:
        return _windows_replacer_recipe(release.tag, asset_url)

    return _posix_replace(asset_url, sha_url, release.tag)


# ---------------------------------------------------------------------------
# POSIX path
# ---------------------------------------------------------------------------


def _posix_replace(asset_url: str, sha_url: str | None, new_tag: str) -> UpdateOutcome:
    target = Path(sys.executable).resolve()
    if not _writable(target):
        return UpdateOutcome(
            upgraded=False,
            message=(
                f"cannot replace {target} (not writable). "
                "Re-run with sudo or reinstall via the install script."
            ),
        )

    tmp_fd, tmp_path = tempfile.mkstemp(prefix=".relay-update-", dir=str(target.parent))
    os.close(tmp_fd)
    try:
        _download(asset_url, tmp_path)
        if sha_url:
            try:
                _verify_sha(tmp_path, sha_url)
            except UpdateError as exc:
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(tmp_path)
                return UpdateOutcome(upgraded=False, message=str(exc))
        # Preserve executable bit.
        os.chmod(tmp_path, os.stat(target).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        # Atomic swap. The OS lets us rename the running executable on
        # POSIX — the inode stays alive until our process exits.
        backup = target.with_suffix(target.suffix + ".bak")
        with contextlib.suppress(FileNotFoundError):
            os.replace(target, backup)
        os.replace(tmp_path, target)
        return UpdateOutcome(
            upgraded=True,
            message=f"updated to {new_tag} (old binary saved as {backup.name})",
            new_version=new_tag,
        )
    except UpdateError as exc:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp_path)
        return UpdateOutcome(upgraded=False, message=str(exc))


def _windows_replacer_recipe(new_tag: str, asset_url: str) -> UpdateOutcome:
    return UpdateOutcome(
        upgraded=False,
        message=(
            f"Windows self-update is not yet automated. Run the installer to upgrade to {new_tag}:\n"
            "  powershell -ExecutionPolicy ByPass -c "
            '"irm https://agent-relay.dev/install.ps1 | iex"\n'
            f"  (asset: {asset_url})"
        ),
    )


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


class UpdateError(RuntimeError):
    """Recoverable failure mid-update. Surfaced as the outcome message."""


def _running_from_binary() -> bool:
    """True when we're inside a PyInstaller bundle.

    Heuristic but reliable: PyInstaller sets ``sys.frozen`` and the entry
    module in :mod:`relay_entry` sets ``AGENT_RELAY_BINARY=1``. Either
    signal is sufficient.
    """
    if getattr(sys, "frozen", False):
        return True
    return os.environ.get("AGENT_RELAY_BINARY") == "1"


def _writable(path: Path) -> bool:
    return os.access(path.parent, os.W_OK)


def _download(url: str, target: str) -> None:
    try:
        urllib.request.urlretrieve(url, target)  # noqa: S310 — controlled URL list
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise UpdateError(f"download failed: {exc}") from exc


def _verify_sha(path: str, sha_url: str) -> None:
    import hashlib

    try:
        with urllib.request.urlopen(sha_url, timeout=8) as resp:
            line = resp.read().decode("utf-8").strip()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise UpdateError(f"checksum fetch failed: {exc}") from exc
    expected = line.split()[0] if line else ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    actual = h.hexdigest()
    if not expected:
        raise UpdateError("empty checksum file")
    if expected != actual:
        raise UpdateError(f"checksum mismatch (expected {expected}, got {actual})")
