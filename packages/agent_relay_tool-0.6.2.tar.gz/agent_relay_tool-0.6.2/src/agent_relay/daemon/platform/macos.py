"""macOS launchd integration — writes a LaunchAgent plist and asks
``launchctl`` to load it.

LaunchAgents (vs LaunchDaemons) are per-user and run only while the user is
logged in — exactly what we want for a developer-tool daemon that talks to
the user's editors. We do **not** require sudo.

The plist lives at ``~/Library/LaunchAgents/dev.agent-relay.plist`` by
default; ``AGENT_RELAY_LAUNCH_AGENT_DIR`` overrides this for tests.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
from collections.abc import Sequence
from pathlib import Path
from xml.sax.saxutils import escape

from agent_relay.daemon.paths import daemon_log_path
from agent_relay.daemon.platform import LAUNCH_LABEL, LaunchAgent

PLIST_FILENAME = f"{LAUNCH_LABEL}.plist"


def launch_agents_dir() -> Path:
    override = os.environ.get("AGENT_RELAY_LAUNCH_AGENT_DIR")
    if override:
        return Path(override).expanduser()
    return Path.home() / "Library" / "LaunchAgents"


def plist_path() -> Path:
    return launch_agents_dir() / PLIST_FILENAME


def render_plist(argv: Sequence[str]) -> str:
    """Render the plist XML. Pure function — easy to snapshot-test."""
    log = daemon_log_path()
    program_arguments = "\n".join(f"    <string>{escape(arg)}</string>" for arg in argv)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n'
        "<dict>\n"
        "  <key>Label</key>\n"
        f"  <string>{LAUNCH_LABEL}</string>\n"
        "  <key>ProgramArguments</key>\n"
        "  <array>\n"
        f"{program_arguments}\n"
        "  </array>\n"
        "  <key>RunAtLoad</key>\n"
        "  <true/>\n"
        "  <key>KeepAlive</key>\n"
        "  <true/>\n"
        "  <key>ProcessType</key>\n"
        "  <string>Background</string>\n"
        "  <key>StandardOutPath</key>\n"
        f"  <string>{escape(str(log))}</string>\n"
        "  <key>StandardErrorPath</key>\n"
        f"  <string>{escape(str(log))}</string>\n"
        "</dict>\n"
        "</plist>\n"
    )


def register(argv: Sequence[str]) -> LaunchAgent:
    target = plist_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_plist(argv), encoding="utf-8")
    loaded = _launchctl_load(target)
    return LaunchAgent(path=target, loaded=loaded)


def unregister() -> Path | None:
    target = plist_path()
    if not target.exists():
        return None
    _launchctl_unload(target)
    with contextlib.suppress(FileNotFoundError):
        target.unlink()
    return target


def is_registered() -> bool:
    return plist_path().exists()


# ---------------------------------------------------------------------------
# launchctl wrappers — best-effort. We don't fail the install if launchctl
# isn't on PATH (test environments, container builds); the user can run
# `launchctl load` themselves later. The plist on disk is the durable
# contract.
# ---------------------------------------------------------------------------


def _launchctl_load(target: Path) -> bool:
    try:
        subprocess.run(
            ["launchctl", "unload", str(target)],
            check=False,
            capture_output=True,
            timeout=5,
        )
        result = subprocess.run(
            ["launchctl", "load", "-w", str(target)],
            check=False,
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        return False


def _launchctl_unload(target: Path) -> None:
    try:
        subprocess.run(
            ["launchctl", "unload", "-w", str(target)],
            check=False,
            capture_output=True,
            timeout=5,
        )
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        pass
