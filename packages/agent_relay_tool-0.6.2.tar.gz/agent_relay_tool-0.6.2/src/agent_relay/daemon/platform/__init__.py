"""Per-platform launch-agent registration.

Three things every implementation provides:

* ``register(executable)`` — write the platform unit and ask the OS to load
  it. Returns the absolute path to the unit file (plist / service file /
  shortcut).
* ``unregister()`` — unload, then delete the unit file. Idempotent.
* ``is_registered()`` — does the unit file exist on disk?

The unit launches the daemon in **foreground** mode (``relay daemon start
--foreground``) because launchd and systemd both already supervise the
process and want a child that doesn't fork.

Path overrides exist for tests — ``AGENT_RELAY_LAUNCH_AGENT_DIR`` redirects
the macOS LaunchAgents dir and ``AGENT_RELAY_SYSTEMD_USER_DIR`` redirects
the Linux user-systemd dir. Production code never sets these.
"""

from __future__ import annotations

import shutil
import sys
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

LAUNCH_LABEL = "dev.agent-relay"


@dataclass(frozen=True, slots=True)
class LaunchAgent:
    """Where the unit file ended up + whether the OS loaded it."""

    path: Path
    loaded: bool


def relay_executable_argv() -> Sequence[str]:
    """The command line a service supervisor should run to start the daemon.

    Strategy:
      1. Prefer a real ``relay`` / ``agent-relay`` binary on ``PATH`` — once
         Phase 7 ships the PyInstaller bundles, this is what users will have.
      2. Otherwise fall back to ``<python> -m agent_relay.cli``. The
         interpreter is captured by absolute path so launchd / systemd don't
         depend on the user's shell ``PATH`` being inherited.

    Always followed by ``daemon start --foreground``.
    """
    for name in ("relay", "agent-relay"):
        which = shutil.which(name)
        if which:
            return [which, "daemon", "start", "--foreground"]
    return [sys.executable, "-m", "agent_relay.cli", "daemon", "start", "--foreground"]


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------


def current_platform() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("linux"):
        return "linux"
    if sys.platform == "win32":
        return "windows"
    return "unknown"


def register() -> LaunchAgent:
    plat = current_platform()
    if plat == "macos":
        from agent_relay.daemon.platform import macos

        return macos.register(relay_executable_argv())
    if plat == "linux":
        from agent_relay.daemon.platform import linux

        return linux.register(relay_executable_argv())
    if plat == "windows":
        from agent_relay.daemon.platform import windows

        return windows.register(relay_executable_argv())
    raise NotImplementedError(f"unsupported platform: {sys.platform}")


def unregister() -> Path | None:
    plat = current_platform()
    if plat == "macos":
        from agent_relay.daemon.platform import macos

        return macos.unregister()
    if plat == "linux":
        from agent_relay.daemon.platform import linux

        return linux.unregister()
    if plat == "windows":
        from agent_relay.daemon.platform import windows

        return windows.unregister()
    return None


def is_registered() -> bool:
    plat = current_platform()
    if plat == "macos":
        from agent_relay.daemon.platform import macos

        return macos.is_registered()
    if plat == "linux":
        from agent_relay.daemon.platform import linux

        return linux.is_registered()
    if plat == "windows":
        from agent_relay.daemon.platform import windows

        return windows.is_registered()
    return False
