"""Windows Startup-folder shortcut registration.

The robust path on Windows would be a real Windows service (via ``sc.exe``)
or a Task Scheduler entry, but both involve UAC elevation. For Phase 2 we
take the lighter approach: drop a ``.cmd`` launcher into the user's Startup
folder. It runs on login under the user account — no elevation required —
and is trivially user-removable from the Start menu.

The richer Task-Scheduler path lands in Phase 7 alongside the PyInstaller
binary build, so the auto-start gets a single point-of-failure to harden.

``AGENT_RELAY_STARTUP_DIR`` overrides the Startup folder for tests.
"""

from __future__ import annotations

import contextlib
import os
from collections.abc import Sequence
from pathlib import Path

from agent_relay.daemon.platform import LaunchAgent

SHORTCUT_FILENAME = "agent-relay-daemon.cmd"


def startup_dir() -> Path:
    override = os.environ.get("AGENT_RELAY_STARTUP_DIR")
    if override:
        return Path(override).expanduser()
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    # Last resort — Path.home() resolution for environments without APPDATA.
    return (
        Path.home()
        / "AppData"
        / "Roaming"
        / "Microsoft"
        / "Windows"
        / "Start Menu"
        / "Programs"
        / "Startup"
    )


def shortcut_path() -> Path:
    return startup_dir() / SHORTCUT_FILENAME


def render_cmd(argv: Sequence[str]) -> str:
    """Quote each argument; ``cmd.exe`` is fussier than POSIX shells."""
    quoted = " ".join(f'"{a}"' for a in argv)
    return (
        "@echo off\r\n"
        "rem agent-relay always-on daemon launcher\r\n"
        "rem Auto-generated. Edits will be overwritten on next `relay install`.\r\n"
        f"start /b {quoted}\r\n"
    )


def register(argv: Sequence[str]) -> LaunchAgent:
    target = shortcut_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_cmd(argv), encoding="utf-8")
    # We don't launch it here — the user will sign out / sign in to trigger
    # the Startup folder. The install flow may also call `relay daemon start`
    # afterwards for an immediate-now boot.
    return LaunchAgent(path=target, loaded=False)


def unregister() -> Path | None:
    target = shortcut_path()
    if not target.exists():
        return None
    with contextlib.suppress(FileNotFoundError):
        target.unlink()
    return target


def is_registered() -> bool:
    return shortcut_path().exists()
