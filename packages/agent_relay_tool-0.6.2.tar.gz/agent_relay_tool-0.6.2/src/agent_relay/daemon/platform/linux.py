"""systemd user-service integration.

User units live at ``~/.config/systemd/user/agent-relay.service`` and are
loaded with ``systemctl --user``. They run only while the user has an
active session (with ``loginctl enable-linger`` users can keep it alive
across logouts; we don't enable linger automatically — that's a deliberate
opt-in via ``relay install --linger`` in a future phase).

``AGENT_RELAY_SYSTEMD_USER_DIR`` overrides the unit directory for tests.
"""

from __future__ import annotations

import contextlib
import os
import shutil
import subprocess
from collections.abc import Sequence
from pathlib import Path

from agent_relay.daemon.platform import LAUNCH_LABEL, LaunchAgent

UNIT_NAME = "agent-relay.service"


def systemd_user_dir() -> Path:
    override = os.environ.get("AGENT_RELAY_SYSTEMD_USER_DIR")
    if override:
        return Path(override).expanduser()
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return base / "systemd" / "user"


def unit_path() -> Path:
    return systemd_user_dir() / UNIT_NAME


def render_unit(argv: Sequence[str]) -> str:
    """Pure function. Quoted-string ExecStart matches systemd conventions."""
    # systemd's ExecStart parser supports a simple shell-like quote syntax.
    # We quote each argument so paths with spaces survive.
    exec_start = " ".join(_q(arg) for arg in argv)
    return (
        "[Unit]\n"
        "Description=Agent Relay always-on daemon\n"
        f"# Label: {LAUNCH_LABEL}\n"
        "After=default.target\n"
        "\n"
        "[Service]\n"
        "Type=simple\n"
        f"ExecStart={exec_start}\n"
        "Restart=on-failure\n"
        "RestartSec=5\n"
        "# Keep the daemon out of the user's shell environment.\n"
        "Environment=PYTHONUNBUFFERED=1\n"
        "\n"
        "[Install]\n"
        "WantedBy=default.target\n"
    )


def _q(arg: str) -> str:
    # systemd treats embedded double quotes specially; the safer wrap is to
    # escape any backslashes / quotes and surround with double quotes.
    escaped = arg.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def register(argv: Sequence[str]) -> LaunchAgent:
    target = unit_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(render_unit(argv), encoding="utf-8")
    loaded = _systemctl_enable_and_start()
    return LaunchAgent(path=target, loaded=loaded)


def unregister() -> Path | None:
    target = unit_path()
    if not target.exists():
        return None
    _systemctl_disable_and_stop()
    with contextlib.suppress(FileNotFoundError):
        target.unlink()
    return target


def is_registered() -> bool:
    return unit_path().exists()


# ---------------------------------------------------------------------------
# systemctl wrappers
# ---------------------------------------------------------------------------


def _systemctl_enable_and_start() -> bool:
    if not shutil.which("systemctl"):
        return False
    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=False,
            capture_output=True,
            timeout=5,
        )
        enable = subprocess.run(
            ["systemctl", "--user", "enable", "--now", UNIT_NAME],
            check=False,
            capture_output=True,
            timeout=10,
        )
        return enable.returncode == 0
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        return False


def _systemctl_disable_and_stop() -> None:
    if not shutil.which("systemctl"):
        return
    try:
        subprocess.run(
            ["systemctl", "--user", "disable", "--now", UNIT_NAME],
            check=False,
            capture_output=True,
            timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=False,
            capture_output=True,
            timeout=5,
        )
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        pass
