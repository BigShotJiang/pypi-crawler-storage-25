"""Always-on layer for agent-relay.

This package houses the global daemon, the event log, the cross-repo
configuration, and the adapter-facing protocol that sits underneath the
existing CLI. The repo-local state at ``<repo>/.agent-relay/`` is unaffected;
the daemon lives at the user-global ``~/.relay/`` root (see
``agent_relay.daemon.paths``).
"""

from agent_relay.daemon import config, events, paths

__all__ = ["config", "events", "paths"]
