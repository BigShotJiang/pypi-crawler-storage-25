"""Polls the events/ directory and surfaces new events to subscribers.

Implemented with stat-and-read polling, not inotify/watchdog. Three reasons:

1. **Cross-platform parity.** inotify/FSEvents/ReadDirectoryChangesW each
   need separate code paths; polling works the same on macOS, Linux, and
   Windows with no native dependencies.
2. **The interesting volume is tiny.** A heavy coding session produces a
   few events per second. A 250 ms poll is human-scale latency at a
   negligible CPU cost.
3. **Append-only files are friendly to byte-offset tailing.** We remember
   the last read offset per file; new bytes are just ``read()`` from there.

The tailer is a passive object: callers (the server) drive ``poll_once()``
from their main loop. We deliberately do not spawn threads here — keeps
shutdown simple and tests deterministic.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from agent_relay.daemon import events as ev
from agent_relay.daemon.paths import event_log_path, events_dir

EventCallback = Callable[[ev.Event], None]


class EventTailer:
    """Watches ``~/.relay/events/*.jsonl`` and emits decoded events.

    Usage::

        tailer = EventTailer(on_event=registry.ingest)
        tailer.replay_all()        # catch up on existing files at startup
        while running:
            tailer.poll_once()     # call from main loop
            time.sleep(poll_secs)
    """

    __slots__ = ("_offsets", "_on_event", "_seen_sessions")

    def __init__(self, on_event: EventCallback) -> None:
        self._on_event = on_event
        # Per-session byte offsets into the JSONL file.
        self._offsets: dict[str, int] = {}
        # Sessions we've ever observed (so disappeared files don't re-fire).
        self._seen_sessions: set[str] = set()

    # -- public API -------------------------------------------------------

    def replay_all(self) -> int:
        """Read every existing event from scratch. Returns total count.

        Called once at daemon startup to rebuild in-memory state. After
        this, ``poll_once()`` only sees new appends.
        """
        events_dir().mkdir(parents=True, exist_ok=True)
        total = 0
        for session_id in self._discover_sessions():
            total += self._drain(session_id, start=0)
        return total

    def poll_once(self) -> int:
        """Read any new lines appended since the last call. Returns count.

        Cheap to call frequently; the only filesystem work is one stat per
        known session plus a directory listing.
        """
        events_dir().mkdir(parents=True, exist_ok=True)
        total = 0
        for session_id in self._discover_sessions():
            offset = self._offsets.get(session_id, 0)
            total += self._drain(session_id, start=offset)
        return total

    def known_sessions(self) -> list[str]:
        return sorted(self._seen_sessions)

    # -- internals --------------------------------------------------------

    def _discover_sessions(self) -> list[str]:
        """List session ids that have a log file right now.

        We intentionally don't cache the directory listing — sessions are
        created without prior notice (a CC hook just appends to a new
        file), and the cost of one ``iterdir()`` per poll is negligible.
        """
        root = events_dir()
        if not root.is_dir():
            return []
        ids = []
        for path in root.iterdir():
            if path.suffix != ".jsonl":
                continue
            session_id = path.stem
            ids.append(session_id)
            self._seen_sessions.add(session_id)
        return ids

    def _drain(self, session_id: str, start: int) -> int:
        """Read new bytes for one session, decode, dispatch, update offset.

        Lines that fail to decode are silently skipped — a single bad line
        must not stall the tailer.
        """
        path = event_log_path(session_id)
        try:
            size = path.stat().st_size
        except FileNotFoundError:
            return 0
        if size <= start:
            return 0
        count = 0
        with path.open("rb") as handle:
            handle.seek(start)
            buf = handle.read(size - start)
        # Track the offset of the last *complete* line. A partial final line
        # (writer mid-append) is left for the next poll.
        text = buf.decode("utf-8", errors="replace")
        nl = text.rfind("\n")
        if nl < 0:
            # No complete line yet; leave offset alone.
            return 0
        complete, _partial = text[: nl + 1], text[nl + 1 :]
        for line in complete.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                event = ev.decode(line)
            except ev.EventDecodeError:
                continue
            try:
                self._on_event(event)
            except Exception:
                # Subscriber bugs must not break the tailer.
                continue
            count += 1
        self._offsets[session_id] = start + len(complete.encode("utf-8"))
        return count


def replay_session(session_id: str, on_event: EventCallback) -> int:
    """One-shot helper: decode every event for ``session_id`` once.

    Used by tests and by ``relay daemon status`` when the daemon isn't
    running but the user still wants to see what's in the log.
    """
    count = 0
    for event in ev.read(session_id):
        on_event(event)
        count += 1
    return count


def list_session_files() -> list[Path]:
    root = events_dir()
    if not root.is_dir():
        return []
    return sorted(p for p in root.iterdir() if p.suffix == ".jsonl")
