"""Line-delimited JSON request/response codec.

Used by the daemon's unix socket server and by short-lived CLI clients
(``relay daemon status``, ``relay daemon tail``). Shape mirrors JSON-RPC
loosely — request with ``id`` + ``method`` + ``params``; response with
``id`` + ``result`` or ``id`` + ``error``.

Notifications (server → client streaming events on ``tail.subscribe``)
share the same envelope but with ``id`` set to ``null``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Request:
    id: int
    method: str
    params: dict[str, Any]


@dataclass(frozen=True, slots=True)
class Response:
    id: int | None
    result: Any = None
    error: dict[str, Any] | None = None


class IpcError(Exception):
    """Server-side dispatch error. Encodes into the ``error`` envelope."""

    def __init__(self, message: str, code: str = "request_error") -> None:
        super().__init__(message)
        self.code = code
        self.message = message

    def to_payload(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message}


def encode_request(req: Request) -> bytes:
    payload = {"id": req.id, "method": req.method, "params": req.params}
    return _dump_line(payload)


def encode_response(resp: Response) -> bytes:
    payload: dict[str, Any] = {"id": resp.id}
    if resp.error is not None:
        payload["error"] = resp.error
    else:
        payload["result"] = resp.result
    return _dump_line(payload)


def encode_notification(method: str, params: dict[str, Any]) -> bytes:
    """Server → client streaming envelope. Notifications have ``id == null``."""
    return _dump_line({"id": None, "method": method, "params": params})


def decode_request(line: bytes | str) -> Request:
    obj = _parse(line)
    if "method" not in obj:
        raise IpcError("missing 'method'", code="bad_request")
    if "id" not in obj:
        raise IpcError("missing 'id'", code="bad_request")
    params = obj.get("params") or {}
    if not isinstance(params, dict):
        raise IpcError("'params' must be an object", code="bad_request")
    return Request(id=int(obj["id"]), method=str(obj["method"]), params=params)


def decode_response(line: bytes | str) -> Response:
    obj = _parse(line)
    if "id" not in obj:
        raise IpcError("missing 'id'", code="bad_response")
    rid = obj["id"]
    if obj.get("error") is not None:
        return Response(id=rid, error=obj["error"])
    return Response(id=rid, result=obj.get("result"))


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _dump_line(obj: dict[str, Any]) -> bytes:
    return (json.dumps(obj, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def _parse(line: bytes | str) -> dict[str, Any]:
    if isinstance(line, bytes):
        line = line.decode("utf-8", errors="replace")
    line = line.strip()
    if not line:
        raise IpcError("empty payload", code="bad_request")
    try:
        obj = json.loads(line)
    except json.JSONDecodeError as exc:
        raise IpcError(f"invalid JSON: {exc}", code="bad_request") from exc
    if not isinstance(obj, dict):
        raise IpcError("payload must be a JSON object", code="bad_request")
    return obj
