"""Events → existing per-repo handoff record.

The seam between the global event store (``~/.relay/``) and the per-repo
object model the existing CLI writes (``<repo>/.agent-relay/handoffs/``).

This translator is intentionally minimal: it materialises a small JSON
manifest pointing at the global snapshot, so the existing repo state
acknowledges that "a handoff arrived from the daemon" without forcing the
event log into the heavyweight content-addressed object format used for
manual handoffs. Existing ``relay handoff`` behaviour is unaffected.

We only run the translator at **resume time** (``relay resume`` inside a
repo). The global snapshot remains the durable source; the repo-local
record is a breadcrumb.
"""

from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass
from pathlib import Path

from agent_relay.daemon.paths import snapshot_path

RECORD_DIRNAME = "handoffs"
DAEMON_HANDOFF_FILENAME = "daemon-handoff.json"


@dataclass(frozen=True, slots=True)
class TranslationResult:
    """Where the breadcrumb landed, plus the source snapshot path."""

    record_path: Path
    snapshot_path: Path
    snapshot_id: str


def materialize(
    repo_root: Path, snapshot_id: str, *, target_agent: str | None = None
) -> TranslationResult:
    """Write a small JSON record into ``<repo>/.agent-relay/handoffs/<id>/``.

    The on-disk format is deliberately small and forward-compatible. It
    points at the global snapshot file; agents (and the existing CLI) can
    read the markdown directly from there.
    """
    snap = snapshot_path(snapshot_id)
    if not snap.exists():
        raise FileNotFoundError(f"snapshot {snapshot_id} not found at {snap}")
    record_dir = repo_root / ".agent-relay" / RECORD_DIRNAME / snapshot_id
    record_dir.mkdir(parents=True, exist_ok=True)
    record_path = record_dir / DAEMON_HANDOFF_FILENAME
    payload = {
        "schema": "agent-relay.daemon-handoff/v1",
        "snapshot_id": snapshot_id,
        "snapshot_path": str(snap),
        "target_agent": target_agent,
        "materialized_at": _dt.datetime.now(_dt.UTC).isoformat(timespec="seconds") + "Z",
    }
    record_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return TranslationResult(record_path=record_path, snapshot_path=snap, snapshot_id=snapshot_id)


def find_repo_root(start: Path) -> Path | None:
    """Walk up from ``start`` looking for the first ``.agent-relay`` /
    ``.git`` directory. Returns the directory containing it, or ``None``.

    We accept either signal so users without a git repo (raw directories)
    still get a translator output, but we prefer ``.agent-relay/`` because
    that's where the breadcrumb actually lives.
    """
    current = start.resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".agent-relay").is_dir() or (candidate / ".git").exists():
            return candidate
    return None
