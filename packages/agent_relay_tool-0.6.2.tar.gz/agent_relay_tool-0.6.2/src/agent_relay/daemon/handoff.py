"""Handoff engine — react to ``rate_limited`` events.

Plugs into the daemon's event pipeline. Each time the tailer ingests a new
event, the server calls :meth:`HandoffEngine.observe`. When it sees a
``RateLimitedEvent`` for a session that hasn't already been snapshotted in
the last few seconds, it:

1. Reads the session's full event history.
2. Generates a Markdown snapshot via :mod:`daemon.snapshot`.
3. Fires a desktop notification with the snapshot id + a hint about how to
   resume (``relay resume <id>``).

Debouncing matters: providers often emit multiple 429s in rapid succession
(retries that all fail), and we want one snapshot per rate-limit storm, not
ten.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field

from agent_relay.daemon import events as ev
from agent_relay.daemon import notify, snapshot
from agent_relay.daemon.session import SessionRegistry, SessionState

log = logging.getLogger("agent_relay.daemon.handoff")

DEBOUNCE_SECS = 30.0
"""Minimum gap between snapshots for the same session. Rate-limit retries
sometimes emit a flurry of identical 429s — we don't want a snapshot per
retry."""


@dataclass(frozen=True, slots=True)
class HandoffEvent:
    """What the engine produced. Returned to callers for testability and
    surfaced to tail subscribers so a live UI can render a "handoff fired"
    badge in real time."""

    snapshot_id: str
    snapshot_path_str: str
    session_id: str
    agent: str
    provider: str
    notified: bool


# A callable that returns the full event list for a session, in write
# order. Injected so tests can use synthetic data without touching disk.
EventLoader = Callable[[str], list[ev.Event]]


@dataclass
class HandoffEngine:
    """Stateful — tracks last-handoff timestamps for debouncing."""

    registry: SessionRegistry
    load_events: EventLoader = field(default_factory=lambda: _default_loader)
    notifier: Callable[[str, str], bool] = field(default_factory=lambda: _default_notifier)
    _last_fired: dict[str, float] = field(default_factory=dict)

    def observe(self, event: ev.Event) -> HandoffEvent | None:
        if not isinstance(event, ev.RateLimitedEvent):
            return None
        if not self._should_fire(event.session):
            return None
        state = self.registry.get(event.session)
        if state is None:
            # Tailer ingests events before calling observe(); a missing
            # state means the session is gone (shouldn't happen). Don't
            # crash; just skip.
            log.warning("rate_limited event for unknown session %s", event.session)
            return None
        return self._fire(state, event)

    # -- internals --------------------------------------------------------

    def _should_fire(self, session_id: str) -> bool:
        last = self._last_fired.get(session_id)
        now = time.monotonic()
        if last is not None and (now - last) < DEBOUNCE_SECS:
            return False
        self._last_fired[session_id] = now
        return True

    def _fire(self, state: SessionState, event: ev.RateLimitedEvent) -> HandoffEvent:
        history = list(self.load_events(state.id))
        snap = snapshot.generate(state, history)
        title = "Agent Relay — handoff ready"
        body = (
            f"{state.agent or 'agent'} hit a {event.provider or 'provider'} rate limit. "
            f"Run `relay resume {snap.id}` to continue."
        )
        notified = self._safe_notify(title, body)
        result = HandoffEvent(
            snapshot_id=snap.id,
            snapshot_path_str=str(snap.path),
            session_id=state.id,
            agent=state.agent,
            provider=event.provider,
            notified=notified,
        )
        log.info(
            "handoff: session=%s provider=%s snapshot=%s notified=%s",
            state.id,
            event.provider,
            snap.id,
            notified,
        )
        return result

    def _safe_notify(self, title: str, body: str) -> bool:
        try:
            return bool(self.notifier(title, body))
        except Exception:
            # Notifier issues never abort handoff — the snapshot on disk
            # is the durable thing.
            log.exception("notifier raised")
            return False


# ---------------------------------------------------------------------------
# Default wiring
# ---------------------------------------------------------------------------


def _default_loader(session_id: str) -> list[ev.Event]:
    return list(ev.read(session_id))


def _default_notifier(title: str, body: str) -> bool:
    return notify.notify(title, body)
