"""In-memory aggregate of a global session, built from its event stream.

The event log is the source of truth; this module produces a small derived
view for the daemon and for ``relay daemon status`` / ``tail``. Cheap to
recompute from scratch, so we keep the implementation deliberately
straightforward — fold events left-to-right.

Lives at the daemon layer, not the repo store. For per-repo session views
(checkpoints, journals, replay), use :mod:`agent_relay.storage`.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Literal

from agent_relay.daemon import events as ev

SessionStatus = Literal["active", "rate_limited", "stopped"]


@dataclass(frozen=True, slots=True)
class SessionState:
    """Derived view of one session.

    Frozen so the daemon can hand it back to callers without aliasing
    concerns — every mutation produces a new instance via :meth:`apply`.
    """

    id: str
    agent: str = ""
    cwd: str = ""
    status: SessionStatus = "active"
    started_at: str = ""
    last_event_at: str = ""
    last_event_type: str = ""
    tool_count: int = 0
    file_change_count: int = 0
    decision_count: int = 0
    rate_limit_provider: str | None = None
    rate_limit_retry_after: float | None = None
    stop_reason: str | None = None
    files_touched: tuple[str, ...] = field(default_factory=tuple)

    def apply(self, event: ev.Event) -> SessionState:
        """Return a new state with ``event`` folded in.

        Unknown event types are tolerated (returned state is unchanged but
        with timestamps refreshed) so a stale daemon survives newer logs.
        """
        base = replace(
            self,
            last_event_at=event.ts,
            last_event_type=event.t,
        )
        if isinstance(event, ev.StartedEvent):
            return replace(
                base,
                agent=event.agent or self.agent,
                cwd=event.cwd or self.cwd,
                started_at=event.ts if not self.started_at else self.started_at,
                status="active",
            )
        if isinstance(event, ev.ToolUsedEvent):
            return replace(base, tool_count=self.tool_count + 1)
        if isinstance(event, ev.FileChangedEvent):
            touched = self.files_touched
            if event.path and event.path not in touched:
                touched = (*touched, event.path)
            return replace(
                base,
                file_change_count=self.file_change_count + 1,
                files_touched=touched,
            )
        if isinstance(event, ev.DecisionEvent):
            return replace(base, decision_count=self.decision_count + 1)
        if isinstance(event, ev.RateLimitedEvent):
            return replace(
                base,
                status="rate_limited",
                rate_limit_provider=event.provider or None,
                rate_limit_retry_after=event.retry_after,
            )
        if isinstance(event, ev.StoppedEvent):
            return replace(
                base,
                status="stopped",
                stop_reason=event.reason or None,
            )
        return base

    def to_dict(self) -> dict:
        """JSON-serializable representation for IPC responses."""
        return {
            "id": self.id,
            "agent": self.agent,
            "cwd": self.cwd,
            "status": self.status,
            "started_at": self.started_at,
            "last_event_at": self.last_event_at,
            "last_event_type": self.last_event_type,
            "tool_count": self.tool_count,
            "file_change_count": self.file_change_count,
            "decision_count": self.decision_count,
            "rate_limit_provider": self.rate_limit_provider,
            "rate_limit_retry_after": self.rate_limit_retry_after,
            "stop_reason": self.stop_reason,
            "files_touched": list(self.files_touched),
        }


class SessionRegistry:
    """Mutable map of session id → :class:`SessionState`.

    Not thread-safe. The daemon serializes access through its IPC loop, so a
    lock would just add ceremony. Tests use it from a single thread too.
    """

    __slots__ = ("_states",)

    def __init__(self) -> None:
        self._states: dict[str, SessionState] = {}

    def __contains__(self, session_id: str) -> bool:
        return session_id in self._states

    def __len__(self) -> int:
        return len(self._states)

    def ingest(self, event: ev.Event) -> SessionState:
        """Fold ``event`` into the corresponding session, creating it if new."""
        current = self._states.get(event.session) or SessionState(id=event.session)
        updated = current.apply(event)
        self._states[event.session] = updated
        return updated

    def get(self, session_id: str) -> SessionState | None:
        return self._states.get(session_id)

    def list(self) -> list[SessionState]:
        """All sessions, sorted by most recent activity first."""
        return sorted(
            self._states.values(),
            key=lambda s: s.last_event_at,
            reverse=True,
        )
