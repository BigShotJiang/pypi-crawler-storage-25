"""Event schema + append-only JSONL log for the always-on daemon.

Adapters (Claude Code hook, PTY wrapper, VS Code extension, Warp MCP) emit a
stream of small structured events describing what an agent did and why.
Everything downstream — automatic handoff, dashboards, the existing CLI's
view of "what happened in this session" — derives from this log.

Two design decisions worth knowing about:

1. **Append-only JSONL, one file per session.** Adapters that can't speak
   the unix-socket protocol (ephemeral hook commands, Windows PowerShell
   one-liners) write directly to the file with ``O_APPEND``. POSIX
   guarantees ``write(2)`` calls smaller than ``PIPE_BUF`` are atomic, and
   our JSON lines are comfortably under that. The daemon tails these files
   instead of being a write bottleneck.

2. **Discriminated union by ``"t"``.** Every event has a one-letter-friendly
   ``t`` field (short enough to stay readable in raw logs) plus a stable set
   of typed payload fields. Unknown ``t`` values are tolerated on read so
   older daemons can read newer adapters' logs without crashing.
"""

from __future__ import annotations

import datetime as _dt
import json
from collections.abc import Iterable, Iterator
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, ClassVar, Literal

from agent_relay.daemon.paths import event_log_path, events_dir, is_valid_session_id

EVENT_SCHEMA_VERSION = 1
"""Bumped when an event type changes shape incompatibly. New optional fields
do not require a bump."""


def _utcnow_iso() -> str:
    """ISO-8601 UTC timestamp with millisecond precision, ``Z`` suffix.

    Matches what the existing CLI writes in journal entries (see
    ``agent_relay.models``), so logs are visually consistent.
    """
    now = _dt.datetime.now(_dt.UTC)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


# ---------------------------------------------------------------------------
# Event dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class _BaseEvent:
    """Fields common to every event. Subclasses set ``t`` via a class var."""

    t: ClassVar[str] = ""
    session: str = ""
    ts: str = field(default_factory=_utcnow_iso)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["t"] = self.t
        return payload


@dataclass(frozen=True, slots=True)
class StartedEvent(_BaseEvent):
    """An agent attached to the daemon and announced itself."""

    t: ClassVar[Literal["started"]] = "started"
    agent: str = ""  # "claude-code", "cursor-composer", "aider", ...
    cwd: str = ""
    pid: int | None = None


@dataclass(frozen=True, slots=True)
class ToolUsedEvent(_BaseEvent):
    """The agent invoked a tool. ``args_redacted`` is already secrets-scrubbed."""

    t: ClassVar[Literal["tool_used"]] = "tool_used"
    tool: str = ""
    args_redacted: dict[str, Any] = field(default_factory=dict)
    ok: bool | None = None


@dataclass(frozen=True, slots=True)
class FileChangedEvent(_BaseEvent):
    """A file was created, modified, or deleted as part of the session.

    ``hunks`` is the diff-hunk count rather than full content — we want a
    cheap activity signal, not a duplicate of the user's git history.
    """

    t: ClassVar[Literal["file_changed"]] = "file_changed"
    path: str = ""
    hunks: int = 0
    op: Literal["create", "modify", "delete"] = "modify"


@dataclass(frozen=True, slots=True)
class DecisionEvent(_BaseEvent):
    """A reasoning step worth preserving for handoff context.

    Adapters that don't have explicit decision signals (e.g. the PTY wrapper)
    leave this stream empty; the handoff primer falls back to transcript
    tailing in that case.
    """

    t: ClassVar[Literal["decision"]] = "decision"
    summary: str = ""
    reasoning: str = ""


@dataclass(frozen=True, slots=True)
class RateLimitedEvent(_BaseEvent):
    """The agent hit a provider rate limit and cannot continue right now."""

    t: ClassVar[Literal["rate_limited"]] = "rate_limited"
    provider: str = ""  # "anthropic", "openai", "google", ...
    retry_after: float | None = None  # seconds, when the provider tells us
    detail: str = ""  # free-form message for logs


@dataclass(frozen=True, slots=True)
class StoppedEvent(_BaseEvent):
    """Session ended. ``reason`` is short and grep-friendly ("done",
    "rate_limited", "user_quit", "crashed")."""

    t: ClassVar[Literal["stopped"]] = "stopped"
    reason: str = ""


Event = (
    StartedEvent
    | ToolUsedEvent
    | FileChangedEvent
    | DecisionEvent
    | RateLimitedEvent
    | StoppedEvent
)


_EVENT_BY_TAG: dict[str, type[_BaseEvent]] = {
    cls.t: cls
    for cls in (
        StartedEvent,
        ToolUsedEvent,
        FileChangedEvent,
        DecisionEvent,
        RateLimitedEvent,
        StoppedEvent,
    )
}


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


class EventDecodeError(ValueError):
    """Raised when a JSONL line can't be parsed into a known event.

    The caller (the daemon's tail loop) is expected to log-and-skip — a
    single bad line should never take the daemon down.
    """


def encode(event: Event) -> str:
    """Serialise to a single JSON line (no trailing newline)."""
    return json.dumps(event.to_dict(), separators=(",", ":"), ensure_ascii=False)


def decode(line: str) -> Event:
    """Parse one JSONL line back into a typed event."""
    line = line.strip()
    if not line:
        raise EventDecodeError("empty line")
    try:
        raw = json.loads(line)
    except json.JSONDecodeError as exc:
        raise EventDecodeError(f"invalid JSON: {exc}") from exc
    if not isinstance(raw, dict):
        raise EventDecodeError("event must be a JSON object")
    tag = raw.pop("t", None)
    if not isinstance(tag, str):
        raise EventDecodeError("missing 't' tag")
    cls = _EVENT_BY_TAG.get(tag)
    if cls is None:
        raise EventDecodeError(f"unknown event type: {tag!r}")
    valid = {f for f in cls.__dataclass_fields__}
    payload = {k: v for k, v in raw.items() if k in valid}
    try:
        return cls(**payload)  # type: ignore[arg-type]
    except TypeError as exc:
        raise EventDecodeError(f"invalid payload for {tag}: {exc}") from exc


# ---------------------------------------------------------------------------
# Append-only log
# ---------------------------------------------------------------------------


def append(event: Event) -> Path:
    """Append a single event to its session's log.

    Uses ``O_APPEND`` so concurrent writers (the daemon plus ephemeral hook
    commands) don't race. Returns the path that was written to so callers
    can verify in tests.
    """
    if not is_valid_session_id(event.session):
        raise ValueError(f"invalid session id: {event.session!r}")
    events_dir().mkdir(parents=True, exist_ok=True)
    path = event_log_path(event.session)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(encode(event))
        handle.write("\n")
    return path


def read(session_id: str) -> Iterator[Event]:
    """Yield every event for ``session_id`` in write order.

    Bad lines are skipped silently here — readers that care (the dashboard,
    debug commands) wrap this with logging. The default path is "I just want
    the well-formed events," which is the daemon's case.
    """
    path = event_log_path(session_id)
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                yield decode(line)
            except EventDecodeError:
                continue


def append_many(events: Iterable[Event]) -> None:
    """Batch helper for tests and replay tooling. Order is preserved."""
    for event in events:
        append(event)
