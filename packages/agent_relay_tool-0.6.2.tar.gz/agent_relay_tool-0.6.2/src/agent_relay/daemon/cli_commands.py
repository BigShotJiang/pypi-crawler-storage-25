"""CLI handlers for ``relay daemon …`` and ``relay install``.

Kept separate from ``agent_relay.cli`` so the existing 1.8k-line CLI file
isn't forced to grow further. ``cli.build_parser`` calls :func:`register`
to attach these subcommands.
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
import time

from agent_relay.daemon import doctor as _doctor
from agent_relay.daemon import install as _install
from agent_relay.daemon import ipc, manager
from agent_relay.daemon import snapshot as _snapshot
from agent_relay.daemon import translator as _translator
from agent_relay.daemon.paths import snapshot_path, socket_path
from agent_relay.daemon.server import snapshot_from_disk


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach ``daemon`` and ``install`` subcommands to the existing parser."""
    daemon = subparsers.add_parser("daemon", help="Manage the agent-relay daemon")
    daemon_subs = daemon.add_subparsers(dest="daemon_command", required=True)

    start = daemon_subs.add_parser("start", help="Start the daemon")
    start.add_argument(
        "--foreground",
        action="store_true",
        help="Run in the current process (used by launchd/systemd; default is background)",
    )
    start.set_defaults(func=_cmd_daemon_start)

    stop = daemon_subs.add_parser("stop", help="Stop the daemon")
    stop.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="Seconds to wait for graceful shutdown",
    )
    stop.set_defaults(func=_cmd_daemon_stop)

    status = daemon_subs.add_parser("status", help="Show daemon + session status")
    status.set_defaults(func=_cmd_daemon_status)

    tail = daemon_subs.add_parser("tail", help="Stream live events from the daemon")
    tail.add_argument(
        "--session",
        default=None,
        help="Only stream events for this session (default: all)",
    )
    tail.set_defaults(func=_cmd_daemon_tail)

    install = subparsers.add_parser(
        "install", help="Install adapters + register the always-on daemon"
    )
    install.add_argument(
        "--cc-only",
        action="store_true",
        help="Only install the Claude Code hook (skip launch-agent setup)",
    )
    install.add_argument(
        "--no-launch-agent",
        action="store_true",
        help="Don't register the daemon for auto-start on login",
    )
    install.add_argument(
        "--no-start",
        action="store_true",
        help="Don't start the daemon now; only wire things up",
    )
    install.add_argument(
        "--warp",
        action="store_true",
        help="Also write the Warp MCP-server snippet (and print paste instructions)",
    )
    install.set_defaults(func=_cmd_install)

    uninstall = subparsers.add_parser(
        "uninstall", help="Remove adapters + auto-start (leaves ~/.relay data intact)"
    )
    uninstall.set_defaults(func=_cmd_uninstall)

    doctor = subparsers.add_parser("doctor", help="Diagnose the always-on layer")
    doctor.set_defaults(func=_cmd_doctor)

    resume = subparsers.add_parser("resume", help="Resume a session from a handoff snapshot")
    resume.add_argument("snapshot_id", help="Snapshot id (e.g. snap-20260518...)")
    resume.add_argument(
        "--to",
        dest="target_agent",
        default=None,
        help="Target agent slug to record in the repo handoff (informational)",
    )
    resume.add_argument(
        "--print",
        dest="print_only",
        action="store_true",
        help="Print the primer to stdout (default if no repo is detected)",
    )
    resume.set_defaults(func=_cmd_resume)

    snapshots = subparsers.add_parser(
        "snapshots", help="List the snapshots the daemon has captured"
    )
    snapshots.set_defaults(func=_cmd_snapshots)

    # The existing CLI already owns `relay run` (manual single-agent session).
    # The PTY wrapper is a different operation — wraps an arbitrary child
    # command and instruments its output — so it gets a separate verb.
    wrap = subparsers.add_parser(
        "wrap",
        help="Wrap a CLI agent so its rate-limits and lifecycle are captured",
    )
    wrap.add_argument(
        "argv",
        nargs=argparse.REMAINDER,
        help="The command to wrap, e.g. `relay wrap aider --model gpt-4`",
    )
    wrap.set_defaults(func=_cmd_wrap)

    proxy = subparsers.add_parser(
        "proxy",
        help="Opt-in HTTPS proxy for lossless rate-limit capture (Phase 5b)",
    )
    proxy_subs = proxy.add_subparsers(dest="proxy_command", required=True)
    proxy_start = proxy_subs.add_parser("start", help="Start the proxy (foreground)")
    proxy_start.add_argument(
        "--port",
        type=int,
        default=None,
        help="Override the listen port (default: config.proxy.listen_port or 9089)",
    )
    proxy_start.set_defaults(func=_cmd_proxy_start)
    proxy_subs.add_parser("status", help="Show whether the proxy is running").set_defaults(
        func=_cmd_proxy_status,
    )
    proxy_subs.add_parser("cert", help="Print the path to mitmproxy's CA cert").set_defaults(
        func=_cmd_proxy_cert,
    )

    dashboard = subparsers.add_parser(
        "dashboard",
        help="Open a local web UI showing sessions, snapshots, and handoffs",
    )
    dashboard.add_argument("--port", type=int, default=0, help="Listen port (default: random)")
    dashboard.add_argument(
        "--no-open",
        action="store_true",
        help="Don't open a browser window — just print the URL",
    )
    dashboard.set_defaults(func=_cmd_dashboard)

    self_update = subparsers.add_parser(
        "self-update",
        help="Update the agent-relay binary to the latest release",
    )
    self_update.add_argument(
        "--tag",
        default=None,
        help="Install a specific release tag instead of the latest (e.g. v0.6.0)",
    )
    self_update.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would happen without downloading or replacing the binary",
    )
    self_update.set_defaults(func=_cmd_self_update)

    mcp = subparsers.add_parser(
        "mcp",
        help="MCP server commands (Phase 6 — Warp agent integration)",
    )
    mcp_subs = mcp.add_subparsers(dest="mcp_command", required=True)
    mcp_subs.add_parser(
        "serve",
        help="Run the MCP server on stdio (invoked by Warp; not interactive)",
    ).set_defaults(func=_cmd_mcp_serve)


# ---------------------------------------------------------------------------
# daemon start / stop / status / tail
# ---------------------------------------------------------------------------


def _cmd_daemon_start(args: argparse.Namespace) -> int:
    if args.foreground:
        return manager.start_foreground()
    try:
        pid = manager.start_background()
    except NotImplementedError as exc:
        _err(args, str(exc))
        return 2
    except RuntimeError as exc:
        _err(args, str(exc))
        return 1
    _ok(args, {"running": True, "pid": pid})
    if not getattr(args, "json", False):
        print(f"agent-relay daemon running (pid {pid})")
    return 0


def _cmd_daemon_stop(args: argparse.Namespace) -> int:
    stopped = manager.stop(timeout_secs=args.timeout)
    _ok(args, {"stopped": stopped})
    if not getattr(args, "json", False):
        print("daemon stopped" if stopped else "daemon did not stop in time")
    return 0 if stopped else 1


def _cmd_daemon_status(args: argparse.Namespace) -> int:
    st = manager.status()
    sessions = (
        _fetch_sessions_via_socket()
        if st.responsive
        else [s.to_dict() for s in snapshot_from_disk()]
    )
    payload = {
        "running": st.running,
        "responsive": st.responsive,
        "pid": st.pid,
        "sessions": sessions,
    }
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
        return 0
    if st.running and st.responsive:
        print(f"daemon: running (pid {st.pid})")
    elif st.running:
        print(f"daemon: running but unresponsive (pid {st.pid})")
    else:
        print("daemon: not running")
    if not sessions:
        print("sessions: (none)")
    else:
        print(f"sessions: {len(sessions)}")
        for s in sessions[:10]:
            print(
                f"  {s['id'][:24]:24}  {s['agent']:14}  "
                f"{s['status']:13}  tools={s['tool_count']}  files={s['file_change_count']}"
            )
    return 0


def _cmd_daemon_tail(args: argparse.Namespace) -> int:
    addr = socket_path()
    if isinstance(addr, str):
        _err(args, "tail is POSIX-only in Phase 1 (Windows lands in Phase 2)")
        return 2
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(str(addr))
    except OSError as exc:
        _err(args, f"can't connect to daemon: {exc}. Is it running?")
        return 1
    sock.sendall(
        ipc.encode_request(
            ipc.Request(id=1, method="tail.subscribe", params={"session": args.session})
        )
    )
    buf = b""
    try:
        while True:
            chunk = sock.recv(65536)
            if not chunk:
                return 0
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                if not line.strip():
                    continue
                if getattr(args, "json", False):
                    print(line.decode("utf-8"))
                    continue
                _render_tail_line(line)
    except KeyboardInterrupt:
        return 0
    finally:
        sock.close()


def _render_tail_line(line: bytes) -> None:
    try:
        obj = json.loads(line.decode("utf-8"))
    except json.JSONDecodeError:
        return
    if obj.get("method") == "tail.event":
        event = obj.get("params", {}).get("event", {})
        sid = event.get("session", "?")[:12]
        t = event.get("t", "?")
        extras = []
        if "agent" in event:
            extras.append(f"agent={event['agent']}")
        if "tool" in event:
            extras.append(f"tool={event['tool']}")
        if "path" in event:
            extras.append(f"path={event['path']}")
        if "provider" in event:
            extras.append(f"provider={event['provider']}")
        if "reason" in event:
            extras.append(f"reason={event['reason']}")
        print(f"{event.get('ts', '')[:19]}  {sid:12}  {t:14}  " + " ".join(extras))


# ---------------------------------------------------------------------------
# install / uninstall / doctor
# ---------------------------------------------------------------------------


def _cmd_install(args: argparse.Namespace) -> int:
    plan = _install.InstallPlan(
        install_claude_code=True,
        register_launch_agent=not args.cc_only and not args.no_launch_agent,
        start_daemon=not args.no_start,
    )
    result = _install.run_install(plan)

    if getattr(args, "json", False):
        print(json.dumps(_install_result_dict(result), indent=2))
        return 1 if result.errors else 0

    print("Agent Relay setup")
    print("─────────────────")
    print()
    print("Detected on this machine:")
    if result.detected:
        for d in result.detected:
            tag = "" if d.adapter_phase <= 2 else "  (adapter ships in a later phase)"
            print(f"  ✓ {d.name:<14} {d.location}{tag}")
    else:
        print("  – nothing recognised yet")
    print()

    cc = result.claude_code
    if cc is None:
        print("Claude Code: not detected — skipped.")
    else:
        installed = ", ".join(cc.installed) or "(already up to date)"
        print(f"Claude Code hook: {installed}")
        print(f"  → {cc.path}")
    print()

    if result.launch_agent_skipped:
        print("Launch agent: skipped (--cc-only or --no-launch-agent).")
    elif result.launch_agent is not None:
        loaded = "loaded" if result.launch_agent.loaded else "written (not loaded — start manually)"
        print(f"Auto-start: {loaded}")
        print(f"  → {result.launch_agent.path}")
    else:
        print("Auto-start: not registered.")
    print()

    if result.daemon_pid:
        print(f"Daemon: running (pid {result.daemon_pid}).")
    else:
        print("Daemon: not started (run `relay daemon start`).")

    if getattr(args, "warp", False):
        from agent_relay.adapters import warp as _warp

        print()
        warp_result = _warp.build_snippet()
        for line in _warp.installation_steps(warp_result):
            print(line)

    if result.errors:
        print()
        print("Warnings:")
        for err in result.errors:
            print(f"  ! {err}")
        return 1
    return 0


def _cmd_dashboard(args: argparse.Namespace) -> int:
    from agent_relay.daemon import dashboard as _dashboard

    cfg = _dashboard.DashboardConfig(
        port=args.port,
        open_browser=not args.no_open,
    )
    try:
        _dashboard.serve(cfg)
    except OSError as exc:
        _err(args, f"relay dashboard: {exc}")
        return 1
    return 0


def _cmd_self_update(args: argparse.Namespace) -> int:
    from agent_relay.daemon import self_update as _su

    outcome = _su.run_self_update(tag=args.tag, dry_run=args.dry_run)
    if getattr(args, "json", False):
        print(
            json.dumps(
                {
                    "upgraded": outcome.upgraded,
                    "message": outcome.message,
                    "new_version": outcome.new_version,
                },
                indent=2,
            )
        )
        return 0 if outcome.upgraded or args.dry_run else 1
    print(outcome.message)
    if outcome.upgraded:
        return 0
    # Treat "already up to date" as success; everything else is a soft fail.
    if "already on the latest" in outcome.message or args.dry_run:
        return 0
    return 1


def _cmd_mcp_serve(args: argparse.Namespace) -> int:
    """Run the MCP server on stdio. Warp invokes this as a subprocess.

    The command is intentionally blocking — Warp expects stdio to stay
    open for the lifetime of the agent session. Use Ctrl-C / SIGTERM to
    end. We never write to stdout outside the JSON-RPC framing, so the
    server output stays parseable.
    """
    from agent_relay.adapters import mcp as _mcp

    if getattr(args, "json", False):
        # Forbid JSON mode here — it would interleave our human chatter
        # with the MCP wire protocol on stdout. Better to fail loud.
        _err(args, "relay mcp serve does not support --json (stdout is the MCP transport)")
        return 2
    server = _mcp.MCPServer()
    server.serve_stdio()
    return 0


def _cmd_uninstall(args: argparse.Namespace) -> int:
    result = _install.run_uninstall()
    if getattr(args, "json", False):
        print(
            json.dumps(
                {
                    "cc_hooks_removed": result.cc_hooks_removed,
                    "launch_agent_path": str(result.launch_agent_path)
                    if result.launch_agent_path
                    else None,
                    "daemon_stopped": result.daemon_stopped,
                    "errors": result.errors,
                },
                indent=2,
            )
        )
        return 1 if result.errors else 0
    print(f"Daemon stopped: {'yes' if result.daemon_stopped else 'no (was already off)'}")
    if result.launch_agent_path:
        print(f"Launch agent removed: {result.launch_agent_path}")
    else:
        print("Launch agent: nothing to remove.")
    print(f"Claude Code hook entries removed: {result.cc_hooks_removed}")
    if result.errors:
        print()
        print("Warnings:")
        for err in result.errors:
            print(f"  ! {err}")
        return 1
    print()
    print(
        "`~/.relay/` (events, sessions, snapshots) is left intact. Remove it manually if desired."
    )
    return 0


def _cmd_doctor(args: argparse.Namespace) -> int:
    checks = _doctor.run_doctor()
    if getattr(args, "json", False):
        print(
            json.dumps(
                [{"name": c.name, "severity": c.severity, "message": c.message} for c in checks],
                indent=2,
            )
        )
        return _doctor.overall_exit_code(checks)
    glyphs = {"ok": "✓", "warn": "⚠", "fail": "✗"}
    width = max(len(c.name) for c in checks)
    for c in checks:
        print(f"  {glyphs[c.severity]} {c.name:<{width}}  {c.message}")
    return _doctor.overall_exit_code(checks)


def _cmd_wrap(args: argparse.Namespace) -> int:
    """`relay wrap <cmd> [args...]` — PTY-wrap a CLI agent."""
    argv = list(args.argv or [])
    if not argv:
        _err(args, "usage: relay wrap <command> [args...]")
        return 2
    from agent_relay.adapters import pty_wrapper

    try:
        return pty_wrapper.run(argv)
    except NotImplementedError as exc:
        _err(args, str(exc))
        return 2
    except (ValueError, OSError) as exc:
        _err(args, f"relay wrap: {exc}")
        return 1


# ---------------------------------------------------------------------------
# proxy (Phase 5b)
# ---------------------------------------------------------------------------


def _cmd_proxy_start(args: argparse.Namespace) -> int:
    """Spawn mitmdump with the relay addon loaded.

    We exec mitmdump in the foreground rather than daemonising — the user
    keeps the proxy in a dedicated terminal (or runs it under
    launchd/systemd) and can ^C to stop it. Daemonising a proxy is the
    kind of thing that turns into a debug nightmare; foreground keeps the
    operator in control.
    """
    import os as _os
    import shutil as _shutil
    from pathlib import Path

    from agent_relay.daemon import config as _cfg

    mitmdump = _shutil.which("mitmdump")
    if mitmdump is None:
        _err(
            args,
            "mitmdump not found on PATH. Install with `pip install agent-relay-tool[proxy]`.",
        )
        return 2

    cfg = _cfg.load()
    port = args.port if args.port is not None else cfg.proxy.listen_port
    confdir = Path(cfg.proxy.confdir).expanduser()
    confdir.mkdir(parents=True, exist_ok=True)

    addon_path = _proxy_addon_path()
    cmd = [
        mitmdump,
        "-p",
        str(port),
        "--set",
        f"confdir={confdir}",
        "-s",
        addon_path,
    ]
    if not getattr(args, "json", False):
        print(f"relay proxy: listening on 127.0.0.1:{port}")
        print(f"             confdir={confdir}")
        print(f"             addon={addon_path}")
        print(f"             cert={confdir / 'mitmproxy-ca-cert.pem'}")
        print()
    # execvp so signals and exit codes pass through cleanly.
    _os.execvp(cmd[0], cmd)
    return 0  # unreachable


def _cmd_proxy_status(args: argparse.Namespace) -> int:
    """Best-effort check — we don't write a pid file (mitmdump owns its
    lifecycle). Surface the configured listen port + whether something is
    bound."""
    import socket as _socket

    from agent_relay.daemon import config as _cfg

    cfg = _cfg.load()
    port = cfg.proxy.listen_port
    listening = False
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
        s.settimeout(0.5)
        s.connect(("127.0.0.1", port))
        s.close()
        listening = True
    except OSError:
        listening = False
    payload = {
        "configured_enabled": cfg.proxy.enabled,
        "listen_port": port,
        "confdir": cfg.proxy.confdir,
        "port_in_use": listening,
    }
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
        return 0
    state = "active" if listening else "not running"
    print(f"proxy: {state} (port {port})")
    print(f"       confdir={cfg.proxy.confdir}")
    print(f"       config-enabled={cfg.proxy.enabled}")
    return 0


def _cmd_proxy_cert(args: argparse.Namespace) -> int:
    """Print the path to mitmproxy's CA cert + a short trust-store recipe."""
    from pathlib import Path

    from agent_relay.daemon import config as _cfg

    cfg = _cfg.load()
    confdir = Path(cfg.proxy.confdir).expanduser()
    cert = confdir / "mitmproxy-ca-cert.pem"
    payload = {
        "cert_path": str(cert),
        "exists": cert.exists(),
        "confdir": str(confdir),
    }
    if getattr(args, "json", False):
        print(json.dumps(payload, indent=2))
        return 0 if cert.exists() else 1
    print(f"CA cert: {cert}")
    if not cert.exists():
        print()
        print("(not yet generated — run `relay proxy start` once to create it.)")
        return 1
    print()
    print("Install steps:")
    print(
        "  macOS:  sudo security add-trusted-cert -d -r trustRoot "
        "-k /Library/Keychains/System.keychain "
        f'"{cert}"'
    )
    print(
        '  Linux:  sudo cp "'
        f'{cert}" /usr/local/share/ca-certificates/agent-relay.crt && sudo update-ca-certificates'
    )
    print("  Windows: import via certmgr.msc into Trusted Root Certification Authorities")
    return 0


def _proxy_addon_path() -> str:
    """Resolve the absolute path to ``proxy_addon.py``.

    We import it (cheap — no mitmproxy import inside the module-level code
    that runs at import time) and read ``__file__``. This avoids a
    Python-internals dance when frozen by PyInstaller in Phase 7.
    """
    import os as _os

    from agent_relay.adapters import proxy_addon

    return _os.path.abspath(proxy_addon.__file__)


def _cmd_resume(args: argparse.Namespace) -> int:
    """Resume from a snapshot. Always prints the primer; if we detect a repo
    context, also writes a per-repo handoff breadcrumb via the translator."""
    snap_path = snapshot_path(args.snapshot_id)
    if not snap_path.exists():
        _err(args, f"snapshot not found: {args.snapshot_id}")
        return 1
    try:
        primer = _snapshot.load(args.snapshot_id)
    except OSError as exc:
        _err(args, f"can't read snapshot: {exc}")
        return 1

    from pathlib import Path

    repo_root = _translator.find_repo_root(Path.cwd())
    materialized = None
    if repo_root is not None and not args.print_only:
        try:
            materialized = _translator.materialize(
                repo_root,
                args.snapshot_id,
                target_agent=args.target_agent,
            )
        except (OSError, FileNotFoundError) as exc:
            _err(args, f"translator: {exc}")
            return 1

    if getattr(args, "json", False):
        print(
            json.dumps(
                {
                    "snapshot_id": args.snapshot_id,
                    "snapshot_path": str(snap_path),
                    "repo_root": str(repo_root) if repo_root else None,
                    "record_path": str(materialized.record_path) if materialized else None,
                    "target_agent": args.target_agent,
                    "primer": primer,
                },
                indent=2,
            )
        )
        return 0

    if repo_root is not None and not args.print_only:
        assert materialized is not None
        print(f"Snapshot: {args.snapshot_id}")
        print(f"Repo:     {repo_root}")
        print(f"Record:   {materialized.record_path}")
        if args.target_agent:
            print(f"Target:   {args.target_agent}")
        print()
    print(primer)
    return 0


def _cmd_snapshots(args: argparse.Namespace) -> int:
    paths = _snapshot.list_all()
    if getattr(args, "json", False):
        print(json.dumps([{"id": p.stem, "path": str(p)} for p in paths], indent=2))
        return 0
    if not paths:
        print("No snapshots yet. They are captured automatically on rate-limit events.")
        return 0
    for p in paths:
        size = p.stat().st_size
        print(f"  {p.stem}  ({size:>5} bytes)")
    return 0


def _install_result_dict(result: _install.InstallResult) -> dict:
    return {
        "config_path": str(result.config_path) if result.config_path else None,
        "claude_code": (
            None
            if result.claude_code is None
            else {
                "path": str(result.claude_code.path),
                "installed": list(result.claude_code.installed),
                "skipped": list(result.claude_code.skipped),
            }
        ),
        "launch_agent": (
            None
            if result.launch_agent is None
            else {
                "path": str(result.launch_agent.path),
                "loaded": result.launch_agent.loaded,
            }
        ),
        "launch_agent_skipped": result.launch_agent_skipped,
        "daemon_pid": result.daemon_pid,
        "detected": [
            {"slug": d.slug, "name": d.name, "location": d.location, "phase": d.adapter_phase}
            for d in result.detected
        ],
        "deferred_adapters": [d.slug for d in result.deferred_adapters],
        "errors": result.errors,
    }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _fetch_sessions_via_socket() -> list[dict]:
    addr = socket_path()
    if isinstance(addr, str):
        return []
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(1.0)
        sock.connect(str(addr))
        sock.sendall(ipc.encode_request(ipc.Request(id=1, method="sessions.list", params={})))
        data = b""
        deadline = time.monotonic() + 1.0
        while time.monotonic() < deadline:
            chunk = sock.recv(65536)
            if not chunk:
                break
            data += chunk
            if b"\n" in data:
                break
        sock.close()
        if not data:
            return []
        resp = ipc.decode_response(data.splitlines()[0])
        if resp.error or not isinstance(resp.result, list):
            return []
        return resp.result
    except (OSError, ipc.IpcError):
        return []


def _ok(args: argparse.Namespace, payload: dict) -> None:
    if getattr(args, "json", False):
        print(json.dumps(payload))


def _err(args: argparse.Namespace, message: str) -> None:
    if getattr(args, "json", False):
        print(json.dumps({"error": message}), file=sys.stderr)
    else:
        print(message, file=sys.stderr)
