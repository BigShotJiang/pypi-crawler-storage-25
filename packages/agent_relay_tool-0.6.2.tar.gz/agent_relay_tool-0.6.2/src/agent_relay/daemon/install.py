"""``relay install`` — orchestrate the always-on setup.

The flow:

1. Make sure ``~/.relay/`` exists and a default ``config.toml`` is written.
2. Detect installed agents on the host and surface what we found.
3. Wire up adapters whose phase is already shipped (Phase 1 — Claude Code).
   For agents whose adapter ships in a later phase, we record a note in the
   result so the CLI can tell the user what's coming.
4. Register the launch agent (unless ``--cc-only`` was passed) so the
   daemon auto-starts on login.
5. Optionally start the daemon now so users see it running immediately.

Everything is **idempotent** — re-running the install repeats safe writes
and skips work that's already done. ``relay uninstall`` performs the
reverse in :func:`run_uninstall`.

The orchestrator is interactive-free: it accepts a settled ``InstallPlan``
and executes it. The CLI builds the plan (prompting where necessary); tests
build the plan directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from agent_relay.adapters import claude_code, detection
from agent_relay.daemon import config as cfg
from agent_relay.daemon import manager, paths
from agent_relay.daemon import platform as platform_dispatch


@dataclass(frozen=True, slots=True)
class InstallPlan:
    install_claude_code: bool = True
    register_launch_agent: bool = True
    start_daemon: bool = True


@dataclass
class InstallResult:
    """What happened during ``relay install``. Used by the CLI for output
    and by tests for assertions."""

    config_path: Path | None = None
    claude_code: claude_code.InstallResult | None = None
    launch_agent: platform_dispatch.LaunchAgent | None = None
    launch_agent_skipped: bool = False
    daemon_pid: int | None = None
    detected: list[detection.Detection] = field(default_factory=list)
    deferred_adapters: list[detection.Detection] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


def detect() -> list[detection.Detection]:
    """Pass-through to :mod:`agent_relay.adapters.detection`."""
    return detection.detect_all()


def deferred_from(detections: list[detection.Detection]) -> list[detection.Detection]:
    """Detected agents whose adapter ships in a phase later than Phase 2.

    Used by the CLI to surface "we see you have Cursor — its adapter ships
    in v1.1" lines so the user knows what to expect.
    """
    return [d for d in detections if d.adapter_phase > 2]


def run_install(plan: InstallPlan) -> InstallResult:
    """Execute a settled plan. Never prompts; safe to call from tests."""
    result = InstallResult()

    # (1) Layout + config.
    paths.ensure_layout()
    result.config_path = cfg.ensure_default()

    # (2) Detection (informational; doesn't change behaviour).
    result.detected = detect()
    result.deferred_adapters = deferred_from(result.detected)

    # (3) Claude Code adapter.
    if plan.install_claude_code:
        if claude_code.detect_claude_code():
            try:
                result.claude_code = claude_code.install()
            except (OSError, ValueError) as exc:
                result.errors.append(f"claude-code: {exc}")
        else:
            # Not present — that's not an error, just a no-op.
            result.claude_code = None

    # (4) Launch agent.
    if plan.register_launch_agent:
        try:
            result.launch_agent = platform_dispatch.register()
        except NotImplementedError as exc:
            result.errors.append(f"launch-agent: {exc}")
        except OSError as exc:
            result.errors.append(f"launch-agent: {exc}")
    else:
        result.launch_agent_skipped = True

    # (5) Start daemon immediately so the user sees it running.
    if plan.start_daemon:
        try:
            existing = manager.status()
            if existing.running and existing.responsive:
                result.daemon_pid = existing.pid
            else:
                result.daemon_pid = manager.start_background()
        except (NotImplementedError, RuntimeError) as exc:
            # Windows hits the NotImplementedError today; that's expected
            # and not a hard failure for the install.
            result.errors.append(f"daemon-start: {exc}")

    return result


# ---------------------------------------------------------------------------
# Uninstall
# ---------------------------------------------------------------------------


@dataclass
class UninstallResult:
    cc_hooks_removed: int = 0
    launch_agent_path: Path | None = None
    daemon_stopped: bool = False
    errors: list[str] = field(default_factory=list)


def run_uninstall() -> UninstallResult:
    """Reverse of :func:`run_install`. Idempotent.

    Does **not** delete ``~/.relay/`` or any logs/events — user data is
    sacred. ``rm -rf ~/.relay`` is left as an explicit choice.
    """
    result = UninstallResult()

    # Stop the daemon first so unloading the launch agent doesn't race.
    try:
        result.daemon_stopped = manager.stop(timeout_secs=3.0)
    except OSError as exc:
        result.errors.append(f"daemon-stop: {exc}")

    # Unload + delete the platform unit.
    try:
        result.launch_agent_path = platform_dispatch.unregister()
    except (NotImplementedError, OSError) as exc:
        result.errors.append(f"launch-agent: {exc}")

    # Remove Claude Code hook entries.
    try:
        _, removed = claude_code.uninstall()
        result.cc_hooks_removed = removed
    except (OSError, ValueError) as exc:
        result.errors.append(f"claude-code: {exc}")

    return result
