"""Cross-platform desktop notifications.

Three native paths:

* **macOS** — ``osascript -e 'display notification …'``. Free, no
  permissions prompt for plain text-only notifications.
* **Linux** — ``notify-send`` (libnotify). Standard on every desktop
  environment that ships GNOME/KDE/XFCE; the daemon degrades silently
  on headless boxes.
* **Windows** — PowerShell BurntToast or a simpler ``msg`` fallback. We
  ship a minimal PowerShell one-liner because BurntToast isn't a default
  install; the user can swap it for a richer toast in Phase 7.

Every backend is **best-effort**. A missing binary is not an error: the
daemon's mission is to capture context, not block on UI affordances.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys

log = logging.getLogger("agent_relay.daemon.notify")


def notify(title: str, body: str, *, action_label: str | None = None) -> bool:
    """Show a desktop notification. Returns True if a backend accepted it.

    ``action_label`` is currently unused at the OS layer — none of our
    three backends supports interactive buttons without elevated install
    (BurntToast on Windows, custom Service on macOS). We accept it as part
    of the signature so callers can pass intent and we can wire interactive
    actions later without changing every call site.
    """
    del action_label  # reserved for future use
    if sys.platform == "darwin":
        return _notify_macos(title, body)
    if sys.platform.startswith("linux"):
        return _notify_linux(title, body)
    if sys.platform == "win32":
        return _notify_windows(title, body)
    return False


# ---------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------


def _notify_macos(title: str, body: str) -> bool:
    if not shutil.which("osascript"):
        return False
    # AppleScript needs double quotes escaped; we just sanitise the strings.
    safe_title = _escape_applescript(title)
    safe_body = _escape_applescript(body)
    script = f'display notification "{safe_body}" with title "{safe_title}"'
    return _run(["osascript", "-e", script])


def _notify_linux(title: str, body: str) -> bool:
    if not shutil.which("notify-send"):
        return False
    # `notify-send` reads args verbatim; no quoting required.
    return _run(
        [
            "notify-send",
            "--app-name=agent-relay",
            "--urgency=normal",
            title,
            body,
        ]
    )


def _notify_windows(title: str, body: str) -> bool:
    if not shutil.which("powershell"):
        return False
    # Minimal toast — no extra modules. Uses Windows 10+ XML toast template.
    safe_title = title.replace('"', "''")
    safe_body = body.replace('"', "''")
    script = (
        "[Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,"
        "ContentType=WindowsRuntime]>$null;"
        '$template = \'<toast><visual><binding template="ToastGeneric">'
        f"<text>{safe_title}</text><text>{safe_body}</text>"
        "</binding></visual></toast>';"
        "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        "$xml.LoadXml($template);"
        "$toast = New-Object Windows.UI.Notifications.ToastNotification $xml;"
        "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
        "'agent-relay').Show($toast);"
    )
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script])


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _escape_applescript(s: str) -> str:
    # AppleScript string literal escapes: backslash and double-quote.
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _run(argv: list[str]) -> bool:
    try:
        result = subprocess.run(
            argv,
            check=False,
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired) as exc:
        log.debug("notify backend failed: %s", exc)
        return False
