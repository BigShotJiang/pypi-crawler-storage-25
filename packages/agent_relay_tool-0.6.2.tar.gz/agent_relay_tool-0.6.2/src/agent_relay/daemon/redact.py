"""Pure redaction helpers for events.

Adapters that build :class:`agent_relay.daemon.events.Event` payloads
should call :func:`redact_event` before writing, especially for
``ToolUsedEvent.args_redacted`` and :class:`DecisionEvent` text. This
module is the single source of truth for "what counts as a secret" in the
daemon layer.

Same rules as the VS Code extension's `redact.ts` so behaviour is
consistent across adapters:

* Keys whose name matches ``(secret|key|token|password|credential|bearer|api[_-]?key)``
  have their values replaced with ``[redacted]``.
* Free-form text values are scanned for high-entropy tokens
  (``sk-…``, ``ghp_…``, ``xox[abp]-…``) and those substrings are replaced
  inline.

Anything more elaborate (full-blown PII detection, file-content secret
scanning) is out of scope here — this module is the safety net, not a
DLP system.
"""

from __future__ import annotations

import re
from dataclasses import replace
from typing import Any

from agent_relay.daemon import events as ev
from agent_relay.daemon.config import PrivacyConfig

REDACTED = "[redacted]"

_KEY_PATTERN = re.compile(
    r"(secret|key|token|password|credential|bearer|api[_-]?key)", re.IGNORECASE
)
_VALUE_PATTERN = re.compile(
    r"\b(sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}|xox[abp]-[A-Za-z0-9-]{10,})\b"
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def redact_string(value: str) -> str:
    """Replace high-entropy token substrings inline."""
    return _VALUE_PATTERN.sub(REDACTED, value)


def redact_mapping(payload: dict[str, Any]) -> dict[str, Any]:
    """Shallow-redact an object: secret-shaped keys get values blanked,
    string values are scanned for inline tokens."""
    out: dict[str, Any] = {}
    for k, v in payload.items():
        if _KEY_PATTERN.search(k):
            out[k] = REDACTED
            continue
        if isinstance(v, str):
            out[k] = redact_string(v)
        else:
            out[k] = v
    return out


def redact_event(event: ev.Event, config: PrivacyConfig | None = None) -> ev.Event:
    """Return a redacted copy of ``event`` according to ``config``.

    If ``config`` is ``None`` we apply the conservative defaults (secrets
    redaction on, raw tool args off). Frozen dataclasses are copied via
    :func:`dataclasses.replace` so the original is untouched.
    """
    cfg = config or PrivacyConfig()

    if not cfg.redact_secrets:
        # User explicitly opted out — pass through unchanged.
        return event

    if isinstance(event, ev.ToolUsedEvent):
        new_args = redact_mapping(event.args_redacted) if event.args_redacted else {}
        if not cfg.capture_tool_args:
            # Default policy: drop everything except structural metadata
            # (key names only). The shape stays so snapshots can still
            # describe "the agent called Edit with paths=…" without the
            # paths themselves.
            new_args = {k: "<value>" for k in new_args}
        return replace(event, args_redacted=new_args)

    if isinstance(event, ev.DecisionEvent):
        return replace(
            event,
            summary=redact_string(event.summary),
            reasoning=redact_string(event.reasoning),
        )

    if isinstance(event, ev.FileChangedEvent):
        # Paths almost never contain secrets, but trailing query strings
        # or tokens in URLs do — scan the path string the same way.
        return replace(event, path=redact_string(event.path))

    if isinstance(event, ev.RateLimitedEvent):
        return replace(event, detail=redact_string(event.detail))

    # StartedEvent / StoppedEvent carry only structural fields.
    return event
