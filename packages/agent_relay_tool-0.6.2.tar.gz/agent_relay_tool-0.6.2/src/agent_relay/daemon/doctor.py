"""``relay doctor`` — health checks for the always-on layer.

Returns a list of :class:`Check` results, each tagged ``ok`` / ``warn`` /
``fail``. The CLI renders them; programmatic callers (the eventual
``relay dashboard`` health pill) can use the exit code:

* 0 — every check is ``ok``
* 1 — at least one ``warn``
* 2 — at least one ``fail``
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from agent_relay.adapters import claude_code
from agent_relay.daemon import manager, paths
from agent_relay.daemon import platform as platform_dispatch

Severity = Literal["ok", "warn", "fail"]


@dataclass(frozen=True, slots=True)
class Check:
    name: str
    severity: Severity
    message: str


def run_doctor() -> list[Check]:
    return [
        _check_layout(),
        _check_config(),
        _check_event_log_writable(),
        _check_daemon(),
        _check_launch_agent(),
        _check_claude_code_hook(),
    ]


def overall_exit_code(checks: list[Check]) -> int:
    if any(c.severity == "fail" for c in checks):
        return 2
    if any(c.severity == "warn" for c in checks):
        return 1
    return 0


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def _check_layout() -> Check:
    root = paths.relay_home()
    if not root.exists():
        return Check("layout", "fail", f"missing {root}; run `relay install`")
    needed = (paths.events_dir(), paths.sessions_dir(), paths.snapshots_dir(), paths.logs_dir())
    for d in needed:
        if not d.exists():
            return Check("layout", "warn", f"missing {d}")
    return Check("layout", "ok", str(root))


def _check_config() -> Check:
    path = paths.config_path()
    if not path.exists():
        return Check("config", "warn", "no config.toml; defaults in effect")
    return Check("config", "ok", str(path))


def _check_event_log_writable() -> Check:
    paths.ensure_layout()
    probe = paths.events_dir() / ".doctor-probe"
    try:
        probe.write_text("x")
        probe.unlink()
    except OSError as exc:
        return Check("event-log", "fail", f"events/ not writable: {exc}")
    return Check("event-log", "ok", str(paths.events_dir()))


def _check_daemon() -> Check:
    st = manager.status()
    if not st.running:
        return Check("daemon", "warn", "not running — run `relay daemon start`")
    if not st.responsive:
        return Check("daemon", "warn", f"pid {st.pid} alive but socket unresponsive")
    return Check("daemon", "ok", f"pid {st.pid}")


def _check_launch_agent() -> Check:
    if platform_dispatch.is_registered():
        return Check("launch-agent", "ok", "registered for auto-start")
    return Check("launch-agent", "warn", "not registered — daemon will not auto-start on login")


def _check_claude_code_hook() -> Check:
    if not claude_code.detect_claude_code():
        return Check("claude-code-hook", "ok", "claude code not installed; nothing to wire")
    if claude_code.is_installed():
        return Check("claude-code-hook", "ok", "installed")
    return Check(
        "claude-code-hook",
        "warn",
        "claude code found but no hook installed — run `relay install`",
    )
