"""User-global daemon configuration at ``~/.relay/config.toml``.

The CLI's existing per-repo configuration is unaffected. This file controls
machine-wide behaviour: which adapters are enabled, the fallback chain used
for automatic handoff, and the privacy/telemetry toggles.

We use :mod:`tomllib` for reads (stdlib since 3.11) and a tiny hand-rolled
writer for round-trips. We deliberately avoid pulling in ``tomli-w`` to keep
the daemon's runtime dependency surface as small as the rest of the CLI.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field, replace
from pathlib import Path

from agent_relay.daemon.paths import config_path, relay_home

CONFIG_SCHEMA_VERSION = 1


@dataclass(frozen=True, slots=True)
class AdapterToggles:
    """Which adapters the daemon should attempt to talk to."""

    claude_code: bool = True
    vscode: bool = True
    warp: bool = True
    pty: bool = True


@dataclass(frozen=True, slots=True)
class HandoffConfig:
    """How automatic handoff behaves.

    ``fallback_chain`` is the ordered list of agents the daemon will offer
    when an active agent rate-limits. Empty by default — ``relay install``
    prompts the user to pick during onboarding so we never surprise them
    with a launched process they didn't ask for.
    """

    auto: bool = True
    fallback_chain: tuple[str, ...] = ()
    notify: bool = True


@dataclass(frozen=True, slots=True)
class PrivacyConfig:
    """Redaction defaults for events written to the log.

    ``capture_tool_args`` is off by default; adapters strip args to a small
    keep-list before emitting. Users who want the full picture flip this on
    knowing what it costs in disk + leak surface.
    """

    redact_secrets: bool = True
    capture_tool_args: bool = False
    capture_file_diffs: bool = False


@dataclass(frozen=True, slots=True)
class TelemetryConfig:
    """Off by default; anonymous aggregate-only when on."""

    enabled: bool = False
    endpoint: str = "https://telemetry.agent-relay.dev/v1/ingest"


@dataclass(frozen=True, slots=True)
class ProxyConfig:
    """Phase 5b proxy-mode settings.

    Off by default — turning this on requires the user to also install
    ``mitmproxy`` and trust the generated CA. We never auto-enable it.
    """

    enabled: bool = False
    listen_port: int = 9089
    # mitmproxy's confdir — where the local CA + state live.
    confdir: str = "~/.relay/proxy"


@dataclass(frozen=True, slots=True)
class Config:
    """Top-level config object the daemon and CLI both read."""

    version: int = CONFIG_SCHEMA_VERSION
    adapters: AdapterToggles = field(default_factory=AdapterToggles)
    handoff: HandoffConfig = field(default_factory=HandoffConfig)
    privacy: PrivacyConfig = field(default_factory=PrivacyConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)
    proxy: ProxyConfig = field(default_factory=ProxyConfig)

    def with_fallback_chain(self, chain: tuple[str, ...]) -> Config:
        return replace(self, handoff=replace(self.handoff, fallback_chain=chain))


# ---------------------------------------------------------------------------
# I/O
# ---------------------------------------------------------------------------


def load(path: Path | None = None) -> Config:
    """Load config from disk, returning defaults if the file is absent.

    Missing sections fall back to their dataclass defaults; unknown keys are
    ignored so an older daemon can still boot against a newer config file
    (forward-compat is cheap and avoids upgrade traps).
    """
    target = path or config_path()
    if not target.exists():
        return Config()
    with target.open("rb") as handle:
        raw = tomllib.load(handle)

    adapters_raw = raw.get("adapters", {}) or {}
    handoff_raw = raw.get("handoff", {}) or {}
    privacy_raw = raw.get("privacy", {}) or {}
    telemetry_raw = raw.get("telemetry", {}) or {}
    proxy_raw = raw.get("proxy", {}) or {}

    return Config(
        version=int(raw.get("version", CONFIG_SCHEMA_VERSION)),
        adapters=AdapterToggles(
            claude_code=bool(adapters_raw.get("claude_code", True)),
            vscode=bool(adapters_raw.get("vscode", True)),
            warp=bool(adapters_raw.get("warp", True)),
            pty=bool(adapters_raw.get("pty", True)),
        ),
        handoff=HandoffConfig(
            auto=bool(handoff_raw.get("auto", True)),
            fallback_chain=tuple(handoff_raw.get("fallback_chain", []) or ()),
            notify=bool(handoff_raw.get("notify", True)),
        ),
        privacy=PrivacyConfig(
            redact_secrets=bool(privacy_raw.get("redact_secrets", True)),
            capture_tool_args=bool(privacy_raw.get("capture_tool_args", False)),
            capture_file_diffs=bool(privacy_raw.get("capture_file_diffs", False)),
        ),
        telemetry=TelemetryConfig(
            enabled=bool(telemetry_raw.get("enabled", False)),
            endpoint=str(
                telemetry_raw.get("endpoint", "https://telemetry.agent-relay.dev/v1/ingest")
            ),
        ),
        proxy=ProxyConfig(
            enabled=bool(proxy_raw.get("enabled", False)),
            listen_port=int(proxy_raw.get("listen_port", 9089)),
            confdir=str(proxy_raw.get("confdir", "~/.relay/proxy")),
        ),
    )


def save(config: Config, path: Path | None = None) -> Path:
    """Persist config atomically. Creates ``~/.relay/`` if it doesn't exist."""
    target = path or config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    text = _render(config)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(target)
    return target


def ensure_default() -> Path:
    """Write a default config file if none exists. Used by ``relay install``."""
    relay_home().mkdir(parents=True, exist_ok=True)
    target = config_path()
    if not target.exists():
        save(Config(), target)
    return target


# ---------------------------------------------------------------------------
# Minimal TOML writer
# ---------------------------------------------------------------------------


def _render(config: Config) -> str:
    """Render Config to a deterministic, human-friendly TOML string.

    Hand-rolled so we don't need ``tomli-w``. The schema is closed and small,
    so this trades flexibility for zero dependencies.
    """
    lines: list[str] = [
        "# agent-relay daemon configuration",
        "# Docs: https://agent-relay.dev/configuration",
        "",
        f"version = {config.version}",
        "",
        "[adapters]",
        f"claude_code = {_b(config.adapters.claude_code)}",
        f"vscode = {_b(config.adapters.vscode)}",
        f"warp = {_b(config.adapters.warp)}",
        f"pty = {_b(config.adapters.pty)}",
        "",
        "[handoff]",
        f"auto = {_b(config.handoff.auto)}",
        f"notify = {_b(config.handoff.notify)}",
        f"fallback_chain = {_str_array(config.handoff.fallback_chain)}",
        "",
        "[privacy]",
        f"redact_secrets = {_b(config.privacy.redact_secrets)}",
        f"capture_tool_args = {_b(config.privacy.capture_tool_args)}",
        f"capture_file_diffs = {_b(config.privacy.capture_file_diffs)}",
        "",
        "[telemetry]",
        f"enabled = {_b(config.telemetry.enabled)}",
        f'endpoint = "{config.telemetry.endpoint}"',
        "",
        "[proxy]",
        f"enabled = {_b(config.proxy.enabled)}",
        f"listen_port = {config.proxy.listen_port}",
        f'confdir = "{config.proxy.confdir}"',
        "",
    ]
    return "\n".join(lines)


def _b(value: bool) -> str:
    return "true" if value else "false"


def _str_array(values: tuple[str, ...]) -> str:
    if not values:
        return "[]"
    quoted = ", ".join(f'"{v}"' for v in values)
    return f"[{quoted}]"
