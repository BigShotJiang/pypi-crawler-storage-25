"""``relay dashboard`` — local web UI served from the binary.

A single HTML page lives embedded in this module. The dashboard renders:
  * The live session list (folded from the event log).
  * Recent snapshots with their ids.
  * A "Trigger handoff" button that emits a user-initiated rate-limit
    event for a selected session.

We deliberately don't pull in Flask / FastAPI / a JS framework — this is
a few hundred bytes of HTML and a polling fetch loop, served from the
stdlib :mod:`http.server`. No build step, no external runtime deps.

The server binds to ``127.0.0.1:0`` so the kernel picks a free port; we
print and (optionally) open the resulting URL.

CORS is wide-open on purpose — every endpoint binds to the loopback
interface only, so cross-origin requests would have to come from a
browser running on the same machine. We accept that risk to keep the
embedded JS simple.
"""

from __future__ import annotations

import json
import logging
import threading
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

from agent_relay.daemon import events as ev
from agent_relay.daemon import snapshot as _snapshot
from agent_relay.daemon.paths import is_valid_session_id
from agent_relay.daemon.server import snapshot_from_disk

log = logging.getLogger("agent_relay.daemon.dashboard")


@dataclass(frozen=True, slots=True)
class DashboardConfig:
    host: str = "127.0.0.1"
    port: int = 0
    open_browser: bool = True


# ---------------------------------------------------------------------------
# HTTP handlers
# ---------------------------------------------------------------------------


def make_handler() -> type[BaseHTTPRequestHandler]:
    """Construct the handler class. We use a class so :func:`http.server`
    can instantiate it per-request without us juggling closures."""

    class Handler(BaseHTTPRequestHandler):
        # Avoid HTTP/1.0 keep-alive footguns; one request per connection.
        protocol_version = "HTTP/1.1"

        def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
            # Default handler writes to stderr; we route to logging instead
            # so users running `relay dashboard` don't see request spam.
            log.debug("%s - %s", self.address_string(), format % args)

        # -- GET ------------------------------------------------------

        def do_GET(self) -> None:  # noqa: N802
            path = self.path.split("?", 1)[0]
            if path == "/" or path == "/index.html":
                self._send(200, "text/html; charset=utf-8", INDEX_HTML.encode("utf-8"))
                return
            if path == "/api/sessions":
                self._send_json(list_sessions())
                return
            if path == "/api/snapshots":
                self._send_json(list_snapshots())
                return
            self._send(404, "text/plain", b"not found")

        # -- POST -----------------------------------------------------

        def do_POST(self) -> None:  # noqa: N802
            length = int(self.headers.get("content-length", "0") or "0")
            body = self.rfile.read(length) if length > 0 else b""
            try:
                payload = json.loads(body) if body else {}
            except json.JSONDecodeError:
                self._send_json({"ok": False, "error": "bad json"}, status=400)
                return
            if self.path == "/api/handoff":
                ok, msg = trigger_handoff(payload)
                self._send_json({"ok": ok, "message": msg}, status=200 if ok else 400)
                return
            self._send(404, "text/plain", b"not found")

        # -- helpers --------------------------------------------------

        def _send(self, status: int, content_type: str, body: bytes) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _send_json(self, payload: Any, *, status: int = 200) -> None:
            body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
            self._send(status, "application/json", body)

    return Handler


# ---------------------------------------------------------------------------
# Data sources — pure-ish helpers we can unit-test
# ---------------------------------------------------------------------------


def list_sessions() -> list[dict[str, Any]]:
    return [s.to_dict() for s in snapshot_from_disk()]


def list_snapshots() -> list[dict[str, Any]]:
    return [
        {
            "id": p.stem,
            "path": str(p),
            "size": p.stat().st_size,
        }
        for p in _snapshot.list_all()
    ]


def trigger_handoff(payload: dict[str, Any]) -> tuple[bool, str]:
    """Emit a user-initiated rate-limit event for the named session."""
    session = payload.get("session")
    if not isinstance(session, str) or not is_valid_session_id(session):
        return False, "missing or invalid 'session'"
    try:
        ev.append(
            ev.RateLimitedEvent(
                session=session,
                provider="user-initiated",
                detail="Handoff requested from the dashboard",
            )
        )
    except (OSError, ValueError) as exc:
        return False, str(exc)
    return True, "handoff event queued"


# ---------------------------------------------------------------------------
# Server lifecycle
# ---------------------------------------------------------------------------


def serve(config: DashboardConfig | None = None) -> None:
    """Block in the dashboard HTTP loop until Ctrl-C / SIGTERM."""
    cfg = config or DashboardConfig()
    httpd = HTTPServer((cfg.host, cfg.port), make_handler())
    bound_port = httpd.server_address[1]
    url = f"http://{cfg.host}:{bound_port}"
    print(f"relay dashboard: {url}")
    if cfg.open_browser:
        try:
            webbrowser.open(url, new=2)
        except Exception:  # noqa: BLE001 — never block on a missing browser
            log.debug("webbrowser.open failed", exc_info=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


def start_background(config: DashboardConfig | None = None) -> tuple[HTTPServer, threading.Thread]:
    """Launch the dashboard on a daemon thread. Used by tests to assert
    against the handlers without blocking the main thread."""
    cfg = config or DashboardConfig(open_browser=False)
    httpd = HTTPServer((cfg.host, cfg.port), make_handler())
    thread = threading.Thread(target=httpd.serve_forever, daemon=True, name="dashboard")
    thread.start()
    return httpd, thread


# ---------------------------------------------------------------------------
# Embedded UI — single HTML file with inline JS
# ---------------------------------------------------------------------------


INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Agent Relay</title>
<style>
  :root {
    color-scheme: light dark;
    --fg: #111;
    --fg-muted: #555;
    --fg-subtle: #888;
    --bg: #fafafa;
    --surface: #fff;
    --border: #e5e5e5;
    --accent: #3f3f46;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --fg: #f4f4f5;
      --fg-muted: #c4c4c7;
      --fg-subtle: #8a8a8e;
      --bg: #0a0a0a;
      --surface: #141414;
      --border: #262626;
      --accent: #fbf0df;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font: 14px/1.55 -apple-system, BlinkMacSystemFont, "Inter", system-ui, sans-serif;
    color: var(--fg);
    background: var(--bg);
  }
  main { max-width: 56rem; margin: 0 auto; padding: 2.5rem 1.5rem 4rem; }
  h1 { font-size: 22px; margin: 0 0 1.5rem; font-weight: 600; letter-spacing: -0.02em; }
  h2 { font-size: 13.5px; margin: 2rem 0 0.75rem; text-transform: uppercase;
       letter-spacing: 0.08em; color: var(--fg-subtle); font-weight: 600; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th, td {
    text-align: left; padding: 0.55rem 0.75rem;
    border-bottom: 1px solid var(--border);
  }
  th {
    font-weight: 500; color: var(--fg-subtle);
    text-transform: uppercase; letter-spacing: 0.06em; font-size: 11px;
  }
  td.id, td.path { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12px; }
  .status { display: inline-block; padding: 1px 8px; border-radius: 999px; font-size: 11px;
            border: 1px solid var(--border); color: var(--fg-muted); }
  .status.rate_limited { color: #b91c1c; border-color: #fecaca; background: #fef2f2; }
  .status.stopped     { color: var(--fg-subtle); }
  .status.active      { color: #15803d; border-color: #bbf7d0; background: #f0fdf4; }
  button {
    font: inherit; padding: 4px 10px; border-radius: 6px;
    border: 1px solid var(--border); background: var(--surface);
    color: var(--fg); cursor: pointer;
  }
  button:hover { background: var(--bg); }
  .muted { color: var(--fg-subtle); }
  .empty { padding: 1.25rem; color: var(--fg-subtle); text-align: center;
           border: 1px dashed var(--border); border-radius: 8px; }
</style>
</head>
<body>
<main>
  <h1>Agent Relay</h1>

  <h2>Sessions</h2>
  <div id="sessions"><div class="empty">No sessions yet.</div></div>

  <h2>Snapshots</h2>
  <div id="snapshots"><div class="empty">No snapshots yet.</div></div>
</main>

<script>
  async function refresh() {
    const [sessions, snapshots] = await Promise.all([
      fetch("/api/sessions").then(r => r.json()).catch(() => []),
      fetch("/api/snapshots").then(r => r.json()).catch(() => []),
    ]);
    renderSessions(sessions);
    renderSnapshots(snapshots);
  }

  function renderSessions(rows) {
    const target = document.getElementById("sessions");
    if (!rows.length) {
      target.innerHTML = '<div class="empty">No sessions yet.</div>';
      return;
    }
    const head = `<table>
      <thead><tr>
        <th>Session</th><th>Agent</th><th>Status</th><th>Tools</th><th>Files</th><th></th>
      </tr></thead><tbody>`;
    const body = rows.map(s => `
      <tr>
        <td class="id">${escapeHtml(s.id)}</td>
        <td>${escapeHtml(s.agent || "")}</td>
        <td><span class="status ${escapeHtml(s.status || "active")}">${escapeHtml(s.status || "active")}</span></td>
        <td>${s.tool_count ?? 0}</td>
        <td>${s.file_change_count ?? 0}</td>
        <td><button data-session="${escapeAttr(s.id)}">Hand off</button></td>
      </tr>`).join("");
    target.innerHTML = head + body + "</tbody></table>";
    target.querySelectorAll("button[data-session]").forEach(btn => {
      btn.addEventListener("click", () => handoff(btn.dataset.session));
    });
  }

  function renderSnapshots(rows) {
    const target = document.getElementById("snapshots");
    if (!rows.length) {
      target.innerHTML = '<div class="empty">No snapshots yet.</div>';
      return;
    }
    const head = '<table><thead><tr><th>Snapshot</th><th>Size</th></tr></thead><tbody>';
    const body = rows.map(s => `
      <tr>
        <td class="id">${escapeHtml(s.id)}</td>
        <td>${(s.size || 0).toLocaleString()} B</td>
      </tr>`).join("");
    target.innerHTML = head + body + "</tbody></table>";
  }

  async function handoff(session) {
    const r = await fetch("/api/handoff", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({session}),
    });
    const out = await r.json();
    if (!out.ok) alert("Handoff failed: " + out.message);
    refresh();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c =>
      ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
  }
  function escapeAttr(s) { return escapeHtml(s); }

  refresh();
  setInterval(refresh, 2000);
</script>
</body>
</html>
"""
