"""Opt-in anonymous telemetry.

Off by default. Users enable by flipping ``telemetry.enabled = true`` in
``~/.relay/config.toml``. When enabled we send a tiny payload to
``telemetry.agent-relay.dev`` describing *which* adapters are in use and
the *count* of handoffs — nothing more.

What we never send:
  - Source code, prompts, file paths, environment variables.
  - User-identifiable strings: the install id is a random UUID we
    generate at first opt-in and store in ``~/.relay/telemetry-id``.
  - Per-session event content. Only aggregate counters.

Why so paranoid? Because telemetry that's been correlated to identifiable
data is the single fastest way to lose user trust, and the value of
"detailed" telemetry rarely outweighs the risk.

Implementation:
  - All sends are background-threaded so they never block the daemon.
  - A failed send is silently dropped — we never retry, never queue to
    disk.
  - One transient install id, never rotated unless the user runs
    ``relay uninstall``.
"""

from __future__ import annotations

import json
import logging
import threading
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from typing import Any

from agent_relay.daemon import config as _cfg
from agent_relay.daemon.paths import relay_home

log = logging.getLogger("agent_relay.daemon.telemetry")

ID_FILENAME = "telemetry-id"
SDK_VERSION = "0.1.0"


@dataclass(frozen=True, slots=True)
class TelemetryEvent:
    """What we actually post. Closed schema."""

    event: str  # e.g. "handoff.fired", "install.completed"
    properties: dict[str, Any]


# ---------------------------------------------------------------------------
# Install id
# ---------------------------------------------------------------------------


def install_id() -> str:
    """Read or create the stable install id.

    Stored unencrypted under ``~/.relay/telemetry-id``. Removing the file
    rotates the id; uninstalling agent-relay should remove it as part of
    its cleanup.
    """
    relay_home().mkdir(parents=True, exist_ok=True)
    target = relay_home() / ID_FILENAME
    if target.exists():
        existing = target.read_text(encoding="utf-8").strip()
        if existing:
            return existing
    new = str(uuid.uuid4())
    target.write_text(new, encoding="utf-8")
    return new


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def record(event: str, properties: dict[str, Any] | None = None) -> None:
    """Fire-and-forget. Returns immediately whether or not we sent."""
    cfg = _cfg.load().telemetry
    if not cfg.enabled:
        return
    payload = _build_payload(event, properties or {})
    threading.Thread(
        target=_send_safe,
        args=(cfg.endpoint, payload),
        daemon=True,
        name="agent-relay-telemetry",
    ).start()


def is_enabled() -> bool:
    return _cfg.load().telemetry.enabled


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _build_payload(event: str, properties: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema": "agent-relay.telemetry/v1",
        "event": event,
        "install_id": install_id(),
        "sdk_version": SDK_VERSION,
        "properties": properties,
    }


def _send_safe(endpoint: str, payload: dict[str, Any]) -> None:
    try:
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        req = urllib.request.Request(
            endpoint,
            data=data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3.0):
            pass
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        # Never crash the daemon for telemetry. Logged at debug only —
        # info-level would create noise in production logs every time a
        # firewall blocks the endpoint.
        log.debug("telemetry send failed: %s", exc)
