"""Unix socket server for the always-on daemon.

Single-threaded ``selectors``-based loop. Each connection is a stream of
newline-delimited JSON requests (see :mod:`daemon.ipc`). Long-running tail
subscriptions stream notifications over the same connection until the
client disconnects.

Design notes:

* The tailer runs in the same loop, polled on a fixed interval. We avoid
  threads + locks; everything mutates :class:`SessionRegistry` from one
  goroutine-equivalent. This is good enough until we get into thousands of
  events/second territory, which is well beyond v1 needs.
* Windows is not supported here (named pipes need a different transport).
  ``Server.serve_forever`` raises :class:`NotImplementedError` on Windows;
  the Phase 1 daemon is POSIX-only. Windows ships in Phase 2.
* The server is shutdown-safe via :meth:`shutdown` from any thread (a
  self-pipe wakes the selector).
"""

from __future__ import annotations

import contextlib
import logging
import os
import socket
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from selectors import EVENT_READ, DefaultSelector
from typing import Any

from agent_relay.daemon import events as ev
from agent_relay.daemon import ipc
from agent_relay.daemon.handoff import HandoffEngine
from agent_relay.daemon.paths import (
    ensure_layout,
    socket_path,
)
from agent_relay.daemon.session import SessionRegistry, SessionState
from agent_relay.daemon.tailer import EventTailer

log = logging.getLogger("agent_relay.daemon")

POLL_INTERVAL_SECS = 0.25
"""How often the tailer polls. See :mod:`daemon.tailer` for rationale."""


# ---------------------------------------------------------------------------
# Connection state
# ---------------------------------------------------------------------------


@dataclass
class _Connection:
    sock: socket.socket
    addr: str
    buf: bytearray
    subscribed: bool = False
    subscription_filter: str | None = None  # session id filter, or None


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------


class Server:
    """Owns the listening socket, the registry, the tailer, and the loop."""

    def __init__(self, *, handoff_engine: HandoffEngine | None = None) -> None:
        self.registry = SessionRegistry()
        self.tailer = EventTailer(on_event=self._on_event)
        # Default engine wires up the real snapshot + notify pipeline.
        # Tests pass a synthetic engine to assert dispatch behaviour without
        # touching the user's desktop or filesystem.
        self.handoff = handoff_engine or HandoffEngine(registry=self.registry)
        self._sel = DefaultSelector()
        self._listener: socket.socket | None = None
        self._wakeup_r: int | None = None
        self._wakeup_w: int | None = None
        self._connections: dict[int, _Connection] = {}
        self._stopping = False
        self._handlers: dict[str, Callable[[dict[str, Any]], Any]] = {
            "ping": self._h_ping,
            "shutdown": self._h_shutdown,
            "sessions.list": self._h_sessions_list,
            "sessions.get": self._h_sessions_get,
            "events.append": self._h_events_append,
            "tail.subscribe": self._h_tail_subscribe,
        }

    # -- lifecycle --------------------------------------------------------

    def serve_forever(self) -> None:
        if sys.platform == "win32":
            raise NotImplementedError(
                "Windows transport (named pipes) lands in Phase 2; "
                "the POSIX socket server is unavailable here."
            )
        ensure_layout()
        addr = socket_path()
        assert not isinstance(addr, str), "POSIX path expected"
        # Remove a stale socket left behind by a crashed daemon.
        with contextlib.suppress(FileNotFoundError):
            addr.unlink()
        self._listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._listener.bind(str(addr))
        self._listener.listen(64)
        self._listener.setblocking(False)
        # Restrict access to the user; the socket lives under ~/.relay/ but
        # macOS doesn't always inherit the parent's mode.
        with contextlib.suppress(OSError):
            os.chmod(str(addr), 0o600)
        self._sel.register(self._listener, EVENT_READ)

        # Self-pipe so shutdown() can wake the selector from another thread.
        self._wakeup_r, self._wakeup_w = os.pipe()
        os.set_blocking(self._wakeup_r, False)
        self._sel.register(self._wakeup_r, EVENT_READ)

        self.tailer.replay_all()
        log.info("daemon listening on %s (sessions=%d)", addr, len(self.registry))

        last_poll = 0.0
        try:
            while not self._stopping:
                # We always wake at least every POLL_INTERVAL so the tailer runs.
                timeout = max(0.0, POLL_INTERVAL_SECS - (time.monotonic() - last_poll))
                for key, _ in self._sel.select(timeout=timeout):
                    if key.fileobj is self._listener:
                        self._accept()
                    elif key.fd == self._wakeup_r:
                        with contextlib.suppress(BlockingIOError):
                            os.read(self._wakeup_r, 4096)
                    else:
                        self._on_readable(key.fd)
                now = time.monotonic()
                if now - last_poll >= POLL_INTERVAL_SECS:
                    self.tailer.poll_once()
                    last_poll = now
        finally:
            self._cleanup()

    def shutdown(self) -> None:
        """Signal the loop to exit. Safe to call from a signal handler."""
        self._stopping = True
        if self._wakeup_w is not None:
            with contextlib.suppress(OSError):
                os.write(self._wakeup_w, b"x")

    # -- connection plumbing ---------------------------------------------

    def _accept(self) -> None:
        assert self._listener is not None
        try:
            client, _ = self._listener.accept()
        except BlockingIOError:
            return
        client.setblocking(False)
        fd = client.fileno()
        self._connections[fd] = _Connection(sock=client, addr=str(fd), buf=bytearray())
        self._sel.register(client, EVENT_READ)

    def _on_readable(self, fd: int) -> None:
        conn = self._connections.get(fd)
        if conn is None:
            return
        try:
            chunk = conn.sock.recv(65536)
        except BlockingIOError:
            return
        except OSError:
            self._drop(fd)
            return
        if not chunk:
            self._drop(fd)
            return
        conn.buf.extend(chunk)
        while True:
            nl = conn.buf.find(b"\n")
            if nl < 0:
                break
            line = bytes(conn.buf[:nl])
            del conn.buf[: nl + 1]
            self._dispatch(conn, line)

    def _drop(self, fd: int) -> None:
        conn = self._connections.pop(fd, None)
        if conn is None:
            return
        with contextlib.suppress(KeyError, ValueError):
            self._sel.unregister(conn.sock)
        with contextlib.suppress(OSError):
            conn.sock.close()

    # -- dispatch ---------------------------------------------------------

    def _dispatch(self, conn: _Connection, line: bytes) -> None:
        try:
            req = ipc.decode_request(line)
        except ipc.IpcError as exc:
            self._send(conn, ipc.Response(id=None, error=exc.to_payload()))
            return
        handler = self._handlers.get(req.method)
        if handler is None:
            self._send(
                conn,
                ipc.Response(
                    id=req.id,
                    error={"code": "unknown_method", "message": req.method},
                ),
            )
            return
        try:
            result = handler(req.params)
        except ipc.IpcError as exc:
            self._send(conn, ipc.Response(id=req.id, error=exc.to_payload()))
            return
        except Exception as exc:  # noqa: BLE001 — last resort, never break the loop
            log.exception("handler %s failed", req.method)
            self._send(
                conn,
                ipc.Response(
                    id=req.id,
                    error={"code": "internal_error", "message": str(exc)},
                ),
            )
            return
        # Tail subscriptions hold the connection open; the handler returned
        # an ack already, so don't send a duplicate.
        if req.method == "tail.subscribe":
            conn.subscribed = True
            conn.subscription_filter = result.get("session") if isinstance(result, dict) else None
            self._send(conn, ipc.Response(id=req.id, result={"ok": True}))
            return
        self._send(conn, ipc.Response(id=req.id, result=result))

    def _send(self, conn: _Connection, resp: ipc.Response) -> None:
        try:
            conn.sock.sendall(ipc.encode_response(resp))
        except OSError:
            self._drop(conn.sock.fileno())

    def _send_notification(self, conn: _Connection, method: str, params: dict[str, Any]) -> None:
        try:
            conn.sock.sendall(ipc.encode_notification(method, params))
        except OSError:
            self._drop(conn.sock.fileno())

    # -- tailer subscriber -----------------------------------------------

    def _on_event(self, event: ev.Event) -> None:
        state = self.registry.ingest(event)
        # Hand the event to the handoff engine. Most events are no-ops;
        # rate_limited events trigger snapshot + notification. The engine
        # debounces internally, so a flurry of 429s yields one handoff.
        handoff_result = self.handoff.observe(event)
        for conn in list(self._connections.values()):
            if not conn.subscribed:
                continue
            if conn.subscription_filter and conn.subscription_filter != event.session:
                continue
            self._send_notification(
                conn,
                "tail.event",
                {"event": event.to_dict(), "session": state.to_dict()},
            )
            if handoff_result is not None:
                self._send_notification(
                    conn,
                    "tail.handoff",
                    {
                        "snapshot_id": handoff_result.snapshot_id,
                        "snapshot_path": handoff_result.snapshot_path_str,
                        "session": handoff_result.session_id,
                        "agent": handoff_result.agent,
                        "provider": handoff_result.provider,
                    },
                )

    # -- handlers --------------------------------------------------------

    def _h_ping(self, _params: dict[str, Any]) -> dict[str, Any]:
        return {"ok": True, "sessions": len(self.registry)}

    def _h_shutdown(self, _params: dict[str, Any]) -> dict[str, Any]:
        self.shutdown()
        return {"ok": True}

    def _h_sessions_list(self, _params: dict[str, Any]) -> list[dict[str, Any]]:
        return [s.to_dict() for s in self.registry.list()]

    def _h_sessions_get(self, params: dict[str, Any]) -> dict[str, Any]:
        sid = params.get("session")
        if not isinstance(sid, str):
            raise ipc.IpcError("'session' is required", code="bad_request")
        state = self.registry.get(sid)
        if state is None:
            raise ipc.IpcError(f"unknown session: {sid}", code="not_found")
        return state.to_dict()

    def _h_events_append(self, params: dict[str, Any]) -> dict[str, Any]:
        """Accept an event over the socket and persist it to the log.

        Adapters that maintain a long-lived connection (the VS Code
        extension, the future PTY wrapper) use this path. Hook-shaped
        adapters write directly to the file instead — both paths converge
        on the same log.
        """
        line = params.get("event")
        if not isinstance(line, dict):
            raise ipc.IpcError("'event' must be an object", code="bad_request")
        try:
            event = ev.decode(
                __import__("json").dumps(line, separators=(",", ":"), ensure_ascii=False)
            )
        except ev.EventDecodeError as exc:
            raise ipc.IpcError(str(exc), code="bad_event") from exc
        try:
            ev.append(event)
        except ValueError as exc:
            raise ipc.IpcError(str(exc), code="bad_event") from exc
        # We don't fold it into the registry here; the tailer will pick it
        # up on its next poll, so all writes go through the same path.
        return {"ok": True}

    def _h_tail_subscribe(self, params: dict[str, Any]) -> dict[str, Any]:
        sid = params.get("session")
        if sid is not None and not isinstance(sid, str):
            raise ipc.IpcError("'session' must be a string", code="bad_request")
        return {"session": sid}

    # -- cleanup ---------------------------------------------------------

    def _cleanup(self) -> None:
        for fd in list(self._connections):
            self._drop(fd)
        if self._listener is not None:
            with contextlib.suppress(OSError):
                self._listener.close()
            self._listener = None
        if self._wakeup_r is not None:
            with contextlib.suppress(OSError):
                os.close(self._wakeup_r)
            self._wakeup_r = None
        if self._wakeup_w is not None:
            with contextlib.suppress(OSError):
                os.close(self._wakeup_w)
            self._wakeup_w = None
        addr = socket_path()
        if not isinstance(addr, str):
            with contextlib.suppress(FileNotFoundError):
                addr.unlink()
        log.info("daemon stopped")


# ---------------------------------------------------------------------------
# Convenience snapshot — used by `relay daemon status` when daemon is dead
# ---------------------------------------------------------------------------


def snapshot_from_disk() -> list[SessionState]:
    """Replay every event file once and return the resulting session states.

    Used by ``relay daemon status`` / ``relay handoff`` when the daemon is
    not running but the user still wants to see what's in the log. Same
    fold logic as the live daemon, just one-shot.
    """
    registry = SessionRegistry()
    tailer = EventTailer(on_event=registry.ingest)
    tailer.replay_all()
    return registry.list()
