"""Snapshot generator — turn a session's event log into a primer document.

A snapshot is a single Markdown file at ``~/.relay/snapshots/<snapshot-id>.md``
that the next agent can be prompted with. The content is deliberately
agent-agnostic: a context block any LLM coding agent can pick up and
continue from. No JSON, no proprietary fields, just prose + lists.

Snapshot ids are stable, sortable, and human-friendly: ``snap-<YYYYMMDDhhmmss>-<sid8>``
where the trailing 8 chars come from the source session id (truncated, then
sanitised to fit our session-id charset). Easy to grep in a terminal,
sorts chronologically by name.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from pathlib import Path

from agent_relay.daemon import events as ev
from agent_relay.daemon.paths import snapshot_path, snapshots_dir
from agent_relay.daemon.session import SessionState

MAX_FILES_LISTED = 25
MAX_RECENT_EVENTS = 25
MAX_DECISIONS = 5


@dataclass(frozen=True, slots=True)
class Snapshot:
    id: str
    path: Path
    session_id: str
    primer: str


def generate(session: SessionState, history: list[ev.Event]) -> Snapshot:
    """Render and persist a snapshot for ``session``. Returns the artifact.

    ``history`` is the full event list for the session in write order, as
    returned by :func:`agent_relay.daemon.events.read`. The caller (the
    handoff engine) is responsible for sourcing it — we want this function
    pure-ish so tests can hand it a synthetic list.
    """
    snap_id = _make_id(session.id)
    primer = _render(session, history)
    target = snapshot_path(snap_id)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(primer, encoding="utf-8")
    return Snapshot(id=snap_id, path=target, session_id=session.id, primer=primer)


def load(snapshot_id: str) -> str:
    """Return the primer text for ``snapshot_id`` or raise FileNotFoundError."""
    return snapshot_path(snapshot_id).read_text(encoding="utf-8")


def list_all() -> list[Path]:
    root = snapshots_dir()
    if not root.is_dir():
        return []
    return sorted(p for p in root.iterdir() if p.suffix == ".md")


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def _render(session: SessionState, history: list[ev.Event]) -> str:
    """Pure rendering. Output is a Markdown document about ~30–60 lines."""
    parts: list[str] = []

    parts.append(f"# Session handoff: {session.agent or 'unknown agent'}")
    parts.append("")
    parts.append(
        "The previous agent stopped before completing the work. The context "
        "below is a compact summary of what it did and where it left off. "
        "Continue from this point.",
    )
    parts.append("")
    parts.append("## Context")
    parts.append("")
    parts.append(f"- **Agent**: {session.agent or 'unknown'}")
    parts.append(f"- **Working directory**: `{session.cwd or 'unknown'}`")
    if session.started_at:
        parts.append(f"- **Started**: {session.started_at}")
    parts.append(f"- **Status**: {session.status}")
    if session.status == "rate_limited" and session.rate_limit_provider:
        retry = (
            f" (retry after {session.rate_limit_retry_after}s)"
            if session.rate_limit_retry_after
            else ""
        )
        parts.append(f"- **Rate-limited by**: {session.rate_limit_provider}{retry}")
    if session.stop_reason:
        parts.append(f"- **Stop reason**: {session.stop_reason}")

    # Files touched — bounded list, dedup already done in SessionState.
    if session.files_touched:
        parts.append("")
        parts.append(f"## Files touched ({len(session.files_touched)})")
        parts.append("")
        for path in session.files_touched[:MAX_FILES_LISTED]:
            parts.append(f"- `{path}`")
        remaining = len(session.files_touched) - MAX_FILES_LISTED
        if remaining > 0:
            parts.append(f"- _… and {remaining} more_")

    # Decisions — newest first, capped to keep the prompt compact.
    decisions = [e for e in history if isinstance(e, ev.DecisionEvent)]
    if decisions:
        parts.append("")
        parts.append("## Recent decisions")
        parts.append("")
        for i, decision in enumerate(reversed(decisions[-MAX_DECISIONS:]), start=1):
            parts.append(f"{i}. **{decision.summary}**")
            if decision.reasoning:
                parts.append(f"   _Why_: {decision.reasoning}")

    # Recent activity tail — every event in write order, truncated.
    parts.append("")
    parts.append(f"## Recent activity (last {min(MAX_RECENT_EVENTS, len(history))} events)")
    parts.append("")
    for event in history[-MAX_RECENT_EVENTS:]:
        parts.append(f"- {_event_to_line(event)}")

    parts.append("")
    parts.append("## How to continue")
    parts.append("")
    parts.append(
        "Pick up the work above. If a decision is mid-flight, finish it. "
        "If a file is partially edited, complete the edit. If a tool call "
        "was about to be retried after the rate limit cleared, retry it now."
    )
    parts.append("")

    return "\n".join(parts)


def _event_to_line(event: ev.Event) -> str:
    """One-line summary of an event for the activity tail."""
    ts = event.ts[:19] if event.ts else "         "
    if isinstance(event, ev.StartedEvent):
        return f"`{ts}` started · agent={event.agent} cwd={event.cwd}"
    if isinstance(event, ev.ToolUsedEvent):
        ok = "" if event.ok is None else f" ok={event.ok}"
        return f"`{ts}` tool_used · {event.tool}{ok}"
    if isinstance(event, ev.FileChangedEvent):
        return f"`{ts}` file_changed · {event.op} `{event.path}` ({event.hunks} hunks)"
    if isinstance(event, ev.DecisionEvent):
        return f"`{ts}` decision · {event.summary}"
    if isinstance(event, ev.RateLimitedEvent):
        return f"`{ts}` rate_limited · {event.provider}"
    if isinstance(event, ev.StoppedEvent):
        return f"`{ts}` stopped · {event.reason}"
    return f"`{ts}` {event.t}"


# ---------------------------------------------------------------------------
# id construction
# ---------------------------------------------------------------------------


def _make_id(session_id: str) -> str:
    now = _dt.datetime.now(_dt.UTC)
    stamp = now.strftime("%Y%m%d%H%M%S") + f"{now.microsecond // 1000:03d}"
    suffix = "".join(c for c in session_id if c.isalnum() or c in ("-", "_"))[-8:] or "session"
    candidate = f"snap-{stamp}-{suffix}"
    # Same-millisecond collisions are theoretically possible; if the file
    # already exists, salt with a tiny counter so we never overwrite.
    if not snapshot_path(candidate).exists():
        return candidate
    for n in range(1, 1000):
        bumped = f"{candidate}-{n}"
        if not snapshot_path(bumped).exists():
            return bumped
    raise RuntimeError("could not allocate a unique snapshot id")
