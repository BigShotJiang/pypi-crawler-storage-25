from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
from pathlib import Path

import requests

from mact import __version__

from mact.cli.config import (
    get_developer_id,
    get_frp_config,
    get_room,
    get_rooms,
    save_room,
    set_developer_id,
    set_frp_config,
)


_DEFAULT_BACKEND = "https://m-act.live"
_DEFAULT_FRP_SERVER = "m-act.live"
_DEFAULT_FRP_PORT = 7000
_DEFAULT_FRP_TOKEN = "B2EktNRxpzmxyqostCUEkDpIkz3oeHdFVCuPXwRv"
_DEFAULT_VHOST_DOMAIN = "tunnel.m-act.live"
_DEFAULT_VHOST_HTTP_PORT = 80

_HOOK_SCRIPT_TEMPLATE = """\
#!/bin/sh
# MACT post-commit hook — reports commits to the server.
# Installed by: mact hook install --room {room_id}
HASH=$(git rev-parse HEAD)
BRANCH=$(git rev-parse --abbrev-ref HEAD)
MESSAGE=$(git log -1 --format=%s HEAD)
mact commit-report --room {room_id} --hash "$HASH" --branch "$BRANCH" --message "$MESSAGE"
"""

# Shared by all subcommands (backend URL for API calls).
_COMMON = argparse.ArgumentParser(add_help=False)
_COMMON.add_argument(
    "--backend-url",
    default=None,
    metavar="URL",
    help=(
        "MACT API base URL (overrides MACT_BACKEND_URL; "
        f"default env or {_DEFAULT_BACKEND})"
    ),
)
_COMMON.add_argument(
    "--secure",
    action="store_true",
    help="Verify TLS certificates to the API (default: no verification)",
)


def _find_git_dir():
    from pathlib import Path

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip()).resolve()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _backend_url(args: argparse.Namespace | None = None) -> str:
    if args is not None:
        override = getattr(args, "backend_url", None)
        if override:
            return str(override).rstrip("/")
    return os.getenv("MACT_BACKEND_URL", _DEFAULT_BACKEND).rstrip("/")


def _tls_verify(args: argparse.Namespace | None) -> bool | str:
    """Argument for ``requests`` ``verify=``. Default is **no** verification (``False``)."""
    ca = os.environ.get("MACT_CA_BUNDLE", "").strip()
    if ca:
        p = Path(ca)
        if p.is_file():
            return str(p)
    env = os.environ.get("MACT_SSL_VERIFY", "").strip().lower()
    if env in ("1", "true", "yes", "on"):
        return True
    if env in ("0", "false", "no", "off"):
        return False
    if args is not None and getattr(args, "secure", False):
        return True
    return False


def _ensure_git_worktree() -> bool:
    if _find_git_dir() is None:
        print(
            "Not inside a git repository. Run `git init` in your project directory first.",
            file=sys.stderr,
        )
        return False
    return True


def _install_post_commit_hook(room_id: str) -> bool:
    """Write `.git/hooks/post-commit` for this room. Caller must be inside a git worktree."""
    git_dir = _find_git_dir()
    if git_dir is None:
        print("Not inside a git repository.", file=sys.stderr)
        return False

    hook_path = git_dir / "hooks" / "post-commit"
    hook_path.parent.mkdir(parents=True, exist_ok=True)
    hook_path.write_text(
        _HOOK_SCRIPT_TEMPLATE.format(room_id=room_id), encoding="utf-8"
    )
    hook_path.chmod(0o755)
    print(f"Installed git post-commit hook → {hook_path}")
    return True


def _ensure_frpc_for_tunnel(args: argparse.Namespace) -> None:
    """Download/cache frpc when a tunnel will be used (same as first `frpc` use)."""
    if args.no_tunnel or args.no_live:
        return
    try:
        from mact.tunnel.frpc_download import ensure_frpc_executable

        path = ensure_frpc_executable()
        print(f"frpc ready ({path})")
    except Exception as exc:
        print(
            f"Warning: could not install or find frpc ({exc}). "
            "Fix your network or install `frpc` on PATH before using the tunnel.",
            file=sys.stderr,
        )


def _after_room_saved_setup(args: argparse.Namespace) -> None:
    """After a successful create/join: ensure frpc, then install post-commit hook."""
    _ensure_frpc_for_tunnel(args)
    if not args.no_hook:
        _install_post_commit_hook(args.room)


def _api_unreachable_message(backend: str) -> str:
    return (
        f"Could not reach the MACT API at {backend}.\n"
        "\n"
        "The --port you pass to create/join is your local app port (e.g. Vite/Next.js), "
        "not the API server.\n"
        "\n"
        "To use the hosted API: unset MACT_BACKEND_URL, or set it to "
        f"{_DEFAULT_BACKEND}, or pass --backend-url {_DEFAULT_BACKEND}\n"
        "\n"
        "To use a self-hosted API on this machine: start the MACT server (e.g. "
        "uvicorn on port 8000), then set MACT_BACKEND_URL=http://127.0.0.1:8000 "
        "or pass --backend-url http://127.0.0.1:8000"
        "\n\n"
        "TLS verification is off by default. To verify the server certificate, pass "
        "`--secure` or set MACT_SSL_VERIFY=true, or set MACT_CA_BUNDLE to a PEM file "
        "(or REQUESTS_CA_BUNDLE) for a custom CA bundle."
    )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_init(args: argparse.Namespace) -> int:
    set_developer_id(args.developer)
    print(f"Initialized developer identity: {args.developer}")
    return 0


def cmd_configure_frp(args: argparse.Namespace) -> int:
    set_frp_config(
        server_addr=args.server_addr,
        server_port=args.server_port,
        auth_token=args.auth_token,
        vhost_domain=args.vhost_domain,
        vhost_http_port=args.vhost_http_port,
    )
    print(f"FRP config saved (server={args.server_addr}:{args.server_port})")
    return 0


def cmd_create(args: argparse.Namespace) -> int:
    developer_id = get_developer_id()
    if not developer_id:
        print("Run `mact init --developer <id>` first.", file=sys.stderr)
        return 1

    if not _ensure_git_worktree():
        return 1

    upstream_url = f"http://127.0.0.1:{args.port}"
    payload = {
        "room_id": args.room,
        "developer_id": developer_id,
        "upstream_url": upstream_url,
    }
    backend = _backend_url(args)
    verify = _tls_verify(args)
    try:
        resp = requests.post(
            f"{backend}/rooms", json=payload, timeout=10, verify=verify
        )
    except requests.RequestException as exc:
        print(f"{exc}\n", file=sys.stderr)
        print(_api_unreachable_message(backend), file=sys.stderr)
        return 1
    if resp.status_code >= 400:
        print(f"Create failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1

    data = resp.json()
    save_room(
        args.room,
        {
            "developer_id": developer_id,
            "local_port": args.port,
            "upstream_url": upstream_url,
            "join_secret": data["join_secret"],
            "admin_token": data["admin_token"],
            "member_token": data["member_token"],
        },
    )
    print(f"Created room `{args.room}`")
    print(f"  Mirror URL  : https://{args.room}.m-act.live/")
    print(f"  Dashboard   : https://{args.room}.m-act.live/dashboard")
    print(f"  Join secret : {data['join_secret']}")
    print(f"  Admin token : {data['admin_token']}")
    print(f"  Member token: {data['member_token']}")
    print("Share the join secret with collaborators.")
    _after_room_saved_setup(args)
    if args.no_live:
        return 0
    print("Starting tunnel and heartbeat (Ctrl+C to stop).")
    return _run_tunnel_and_heartbeat(args)


def cmd_join(args: argparse.Namespace) -> int:
    developer_id = get_developer_id()
    if not developer_id:
        print("Run `mact init --developer <id>` first.", file=sys.stderr)
        return 1

    if not _ensure_git_worktree():
        return 1

    upstream_url = f"http://127.0.0.1:{args.port}"
    payload = {
        "developer_id": developer_id,
        "upstream_url": upstream_url,
        "join_secret": args.secret,
    }
    backend = _backend_url(args)
    verify = _tls_verify(args)
    try:
        resp = requests.post(
            f"{backend}/rooms/{args.room}/join",
            json=payload,
            timeout=10,
            verify=verify,
        )
    except requests.RequestException as exc:
        print(f"{exc}\n", file=sys.stderr)
        print(_api_unreachable_message(backend), file=sys.stderr)
        return 1
    if resp.status_code >= 400:
        print(f"Join failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1

    data = resp.json()
    save_room(
        args.room,
        {
            "developer_id": developer_id,
            "local_port": args.port,
            "upstream_url": upstream_url,
            "member_token": data["member_token"],
        },
    )
    print(f"Joined room `{args.room}` — member token stored locally.")
    print(f"  Mirror URL: https://{args.room}.m-act.live/")
    _after_room_saved_setup(args)
    if args.no_live:
        return 0
    print("Starting tunnel and heartbeat (Ctrl+C to stop).")
    return _run_tunnel_and_heartbeat(args)


def cmd_status(args: argparse.Namespace) -> int:
    backend = _backend_url(args)
    verify = _tls_verify(args)
    try:
        resp = requests.get(
            f"{backend}/rooms/{args.room}/status", timeout=10, verify=verify
        )
    except requests.RequestException as exc:
        print(f"{exc}\n", file=sys.stderr)
        print(_api_unreachable_message(backend), file=sys.stderr)
        return 1
    if resp.status_code >= 400:
        print(f"Status failed: {resp.status_code} {resp.text}", file=sys.stderr)
        return 1
    data = resp.json()
    print(f"Room: {data['room_id']}")
    print(f"Active upstream: {data['active_upstream']}")
    latest = data.get("latest_commit")
    if latest:
        print(
            f"Latest commit: {latest['commit_hash']} "
            f"({latest['developer_id']}) — {latest['message']}"
        )
    else:
        print("Latest commit: none")
    print(f"Participants: {len(data['participants'])}")
    for p in data["participants"]:
        live = "live" if p["connected"] else "offline"
        print(f"  {p['developer_id']}: {p['upstream_url']} [{live}]")
    return 0


def cmd_leave(args: argparse.Namespace) -> int:
    room_data = get_room(args.room)
    if not room_data:
        print(f"Room `{args.room}` not found locally.", file=sys.stderr)
        return 1

    developer_id = room_data.get("developer_id") or get_developer_id()
    member_token = room_data.get("member_token")
    if not member_token or not developer_id:
        print("Missing credentials for this room.", file=sys.stderr)
        return 1

    backend = _backend_url(args)
    verify = _tls_verify(args)
    headers = {"Authorization": f"Bearer {member_token}"}
    try:
        resp = requests.post(
            f"{backend}/rooms/{args.room}/presence/disconnect",
            json={"developer_id": developer_id},
            headers=headers,
            timeout=10,
            verify=verify,
        )
        if resp.status_code >= 400:
            print(f"Disconnect failed: {resp.status_code} {resp.text}", file=sys.stderr)
            return 1
    except requests.RequestException as exc:
        print(f"Disconnect failed: {exc}", file=sys.stderr)
        return 1

    print(f"Disconnected from room `{args.room}`.")
    return 0


def cmd_rooms(_args: argparse.Namespace) -> int:
    rooms = get_rooms()
    if not rooms:
        print("No local room metadata yet.")
        return 0
    for room_id, data in rooms.items():
        port = data.get("local_port", "?")
        print(f"  {room_id}  (port {port})")
    return 0


# ---------------------------------------------------------------------------
# Tunnel + heartbeat (after create/join)
# ---------------------------------------------------------------------------

def _run_tunnel_and_heartbeat(args: argparse.Namespace) -> int:
    room_data = get_room(args.room)
    if not room_data:
        print(f"Room `{args.room}` not found locally. Create or join first.", file=sys.stderr)
        return 1

    developer_id = room_data.get("developer_id") or get_developer_id()
    member_token = room_data.get("member_token")
    if not member_token:
        print("No member token stored for this room.", file=sys.stderr)
        return 1

    port = args.port or room_data.get("local_port")
    if not port:
        print("Specify --port or create/join with a port first.", file=sys.stderr)
        return 1

    tunnel = None
    upstream_url = f"http://127.0.0.1:{port}"

    if not args.no_tunnel:
        frp_cfg = get_frp_config()
        try:
            from mact.tunnel.frpc import FrpcTunnel

            tunnel = FrpcTunnel(
                local_port=int(port),
                room_id=args.room,
                developer_id=developer_id,
                server_addr=frp_cfg.get("server_addr", _DEFAULT_FRP_SERVER),
                server_port=int(frp_cfg.get("server_port", _DEFAULT_FRP_PORT)),
                auth_token=frp_cfg.get("auth_token", _DEFAULT_FRP_TOKEN),
                vhost_domain=frp_cfg.get("vhost_domain", _DEFAULT_VHOST_DOMAIN),
                vhost_http_port=int(frp_cfg.get("vhost_http_port", _DEFAULT_VHOST_HTTP_PORT)),
            )
            tunnel.start()
            upstream_url = tunnel.public_url
            print(f"Tunnel started → {upstream_url}")
        except RuntimeError as exc:
            print(f"Tunnel failed: {exc}", file=sys.stderr)
            print("Falling back to local URL.", file=sys.stderr)
    else:
        print(f"Heartbeat-only mode (upstream={upstream_url})")

    backend = _backend_url(args)
    verify = _tls_verify(args)
    headers = {"Authorization": f"Bearer {member_token}"}
    stop_event = threading.Event()

    def _cleanup() -> None:
        stop_event.set()
        try:
            requests.post(
                f"{backend}/rooms/{args.room}/presence/disconnect",
                json={"developer_id": developer_id},
                headers=headers,
                timeout=5,
                verify=verify,
            )
        except Exception:
            pass
        if tunnel:
            tunnel.stop()

    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())
    signal.signal(signal.SIGINT, lambda *_: stop_event.set())

    print(f"Room `{args.room}` is live. Press Ctrl+C to stop.")

    try:
        while not stop_event.is_set():
            try:
                requests.post(
                    f"{backend}/rooms/{args.room}/presence/heartbeat",
                    json={
                        "developer_id": developer_id,
                        "upstream_url": upstream_url,
                    },
                    headers=headers,
                    timeout=10,
                    verify=verify,
                )
            except requests.RequestException as exc:
                print(f"Heartbeat failed: {exc}", file=sys.stderr)
            stop_event.wait(30)
    finally:
        _cleanup()
        print("\nDisconnected.")
    return 0


# ---------------------------------------------------------------------------
# `mact hook install` — git post-commit hook (same file as create/join auto-install)
# ---------------------------------------------------------------------------


def cmd_hook_install(args: argparse.Namespace) -> int:
    return 0 if _install_post_commit_hook(args.room) else 1


# ---------------------------------------------------------------------------
# `mact commit-report` — called from the post-commit hook
# ---------------------------------------------------------------------------

def cmd_commit_report(args: argparse.Namespace) -> int:
    room_data = get_room(args.room)
    if not room_data:
        print(f"Room `{args.room}` not found locally.", file=sys.stderr)
        return 1

    developer_id = room_data.get("developer_id") or get_developer_id()
    member_token = room_data.get("member_token")
    if not member_token or not developer_id:
        print("Missing credentials for this room.", file=sys.stderr)
        return 1

    commit_hash = args.hash
    branch = args.branch
    message = args.message

    if not commit_hash:
        try:
            commit_hash = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], text=True
            ).strip()
        except Exception:
            print("Could not determine commit hash.", file=sys.stderr)
            return 1
    if not branch:
        try:
            branch = subprocess.check_output(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"], text=True
            ).strip()
        except Exception:
            branch = "unknown"
    if not message:
        try:
            message = subprocess.check_output(
                ["git", "log", "-1", "--format=%s", "HEAD"], text=True
            ).strip()
        except Exception:
            message = "(no message)"

    resp = requests.post(
        f"{_backend_url(args)}/rooms/{args.room}/commits",
        json={
            "developer_id": developer_id,
            "commit_hash": commit_hash[:40],
            "branch": branch[:80],
            "message": message[:250],
        },
        headers={"Authorization": f"Bearer {member_token}"},
        timeout=10,
        verify=_tls_verify(args),
    )
    if resp.status_code >= 400:
        print(
            f"Commit report failed: {resp.status_code} {resp.text}",
            file=sys.stderr,
        )
        return 1
    result = resp.json()
    if result.get("inserted"):
        print(f"Reported commit {commit_hash[:7]}")
    else:
        print(f"Commit {commit_hash[:7]} already reported (duplicate)")
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mact")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", parents=[_COMMON], help="Set developer identity")
    p_init.add_argument("--developer", required=True)
    p_init.set_defaults(func=cmd_init)

    p_frp = sub.add_parser("configure-frp", parents=[_COMMON], help="Set FRP tunnel configuration")
    p_frp.add_argument("--server-addr", default=_DEFAULT_FRP_SERVER)
    p_frp.add_argument("--server-port", type=int, default=_DEFAULT_FRP_PORT)
    p_frp.add_argument("--auth-token", default=_DEFAULT_FRP_TOKEN)
    p_frp.add_argument("--vhost-domain", default=_DEFAULT_VHOST_DOMAIN)
    p_frp.add_argument("--vhost-http-port", type=int, default=_DEFAULT_VHOST_HTTP_PORT,
                        help="frps vhostHTTPPort (default 80)")
    p_frp.set_defaults(func=cmd_configure_frp)

    p_create = sub.add_parser("create", parents=[_COMMON], help="Create room and register first member")
    p_create.add_argument("--room", required=True)
    p_create.add_argument(
        "--port",
        required=True,
        type=int,
        metavar="N",
        help="Port your local HTTP server listens on (mirrored upstream; not the MACT API port)",
    )
    p_create.add_argument(
        "--no-tunnel",
        action="store_true",
        help="Send heartbeats only (no frpc tunnel to public vhost)",
    )
    p_create.add_argument(
        "--no-live",
        action="store_true",
        help="Create the room only; do not start tunnel and heartbeat",
    )
    p_create.add_argument(
        "--no-hook",
        action="store_true",
        help="Do not install the git post-commit hook",
    )
    p_create.set_defaults(func=cmd_create)

    p_join = sub.add_parser("join", parents=[_COMMON], help="Join existing room")
    p_join.add_argument("--room", required=True)
    p_join.add_argument(
        "--port",
        required=True,
        type=int,
        metavar="N",
        help="Port your local HTTP server listens on (mirrored upstream; not the MACT API port)",
    )
    p_join.add_argument("--secret", required=True, help="Join secret from room creator")
    p_join.add_argument(
        "--no-tunnel",
        action="store_true",
        help="Send heartbeats only (no frpc tunnel to public vhost)",
    )
    p_join.add_argument(
        "--no-live",
        action="store_true",
        help="Join only; do not start tunnel and heartbeat",
    )
    p_join.add_argument(
        "--no-hook",
        action="store_true",
        help="Do not install the git post-commit hook",
    )
    p_join.set_defaults(func=cmd_join)

    p_leave = sub.add_parser("leave", parents=[_COMMON], help="Disconnect from a room")
    p_leave.add_argument("--room", required=True)
    p_leave.set_defaults(func=cmd_leave)

    p_status = sub.add_parser("status", parents=[_COMMON], help="Fetch room status")
    p_status.add_argument("--room", required=True)
    p_status.set_defaults(func=cmd_status)

    p_rooms = sub.add_parser("rooms", parents=[_COMMON], help="Show locally saved room metadata")
    p_rooms.set_defaults(func=cmd_rooms)

    p_hook = sub.add_parser("hook", help="Install git post-commit hook")
    p_hook_sub = p_hook.add_subparsers(dest="hook_command", required=True)
    p_hook_install = p_hook_sub.add_parser("install", parents=[_COMMON])
    p_hook_install.add_argument("--room", required=True)
    p_hook_install.set_defaults(func=cmd_hook_install)

    p_commit = sub.add_parser(
        "commit-report",
        parents=[_COMMON],
        help="Report a commit (used by git hook)",
    )
    p_commit.add_argument("--room", required=True)
    p_commit.add_argument("--hash", default=None)
    p_commit.add_argument("--branch", default=None)
    p_commit.add_argument("--message", default=None)
    p_commit.set_defaults(func=cmd_commit_report)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    rc = args.func(args)
    raise SystemExit(rc)
