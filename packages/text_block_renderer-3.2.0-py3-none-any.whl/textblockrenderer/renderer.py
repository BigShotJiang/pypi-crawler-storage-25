"""兼容重导出模块

原 renderer.py 的功能已迁移至 render.py (Render 层)。
此文件保留以向后兼容外部 `from textblockrenderer.renderer import ...` 的导入。
"""

from .render import (
    optimize_polygon_x_alignment,
    round_polygon_corners,
    ImageRenderer,
    StyleResolver,
    WebRenderer,
)
from .layout import LayoutEngine

# 保留原有函数接口
from .models import ColoredSubtitleBlock, RenderStyle, TextLayout
from .splitter import TextMeasurer
from typing import Tuple
from PIL import Image


def render_colored_block(
    block: ColoredSubtitleBlock,
    measurer: TextMeasurer,
    background_color: Tuple[int, int, int, int] = (0, 0, 0, 0),
    default_color: str | Tuple[int, int, int, int] = "white",
    align: str = "left",
    padding: Tuple[int, int] = (4, 4),
    mask_offset: Tuple[int, int] = (0, 0),
    mask_mode: int = 0,
    mask_color: Tuple[int, int, int, int] = (0, 0, 0, 180),
    mask_radius: int = 8,
    stroke_size: int = 0,
    stroke_color: Tuple[int, int, int, int] = (0, 0, 0, 255),
    vertical_align: str = "top",
    target_height: int = 0,
    target_width: int = 0,
) -> Image.Image:
    """渲染带颜色和字号的字幕块为图片（兼容包装）

    内部委托给 LayoutEngine + ImageRenderer。
    保留原始函数签名以向后兼容。
    """
    from .models import RenderConstraint

    # 构建 RenderStyle
    style = RenderStyle(
        text_color=default_color,
        bg_color=None,  # background_color 直接作为参数传入
        alignment=align,
        padding=(padding[1], padding[0]),  # 原调用传入格式为 (水平, 垂直)，RenderStyle 为 (水平, 垂直)
        mask_mode=mask_mode,
        mask_color=mask_color,
        mask_offset=mask_offset,
        corner_radius=mask_radius,
        stroke_size=stroke_size,
        stroke_color=stroke_color,
    )

    # 使用 Layout 层计算布局
    # 构建一个足够大的约束（因为 block 已经分割完成）
    constraint = RenderConstraint(max_width=9999, max_height=0)
    layout_engine = LayoutEngine(constraint, style, measurer)
    text_layout = layout_engine.compute_text_layout(
        block,
        align=align,
        vertical_align=vertical_align,
        target_width=target_width,
        target_height=target_height,
    )

    # 使用 Render 层渲染
    # 需要临时覆盖 style 的 bg_color 为传入的 background_color
    style_for_render = RenderStyle(
        text_color=default_color,
        bg_color=background_color,  # 直接传入 RGBA 元组
        alignment=align,
        padding=(padding[1], padding[0]),
        mask_mode=mask_mode,
        mask_color=mask_color,
        mask_offset=mask_offset,
        corner_radius=mask_radius,
        stroke_size=stroke_size,
        stroke_color=stroke_color,
    )
    renderer = ImageRenderer(measurer, style_for_render)

    # ImageRenderer.render_block 内部会使用 StyleResolver.resolve_background 解析背景色
    # 但我们传入的是 RGBA 元组，需要确保 resolve_background 能处理
    # 实际上 render_block 使用 StyleResolver.resolve_background(self.style)
    # 而 style_for_render.bg_color = background_color (tuple)
    # StyleResolver.parse_color 已能处理 tuple 类型

    return renderer.render_block(block, text_layout)


__all__ = [
    "optimize_polygon_x_alignment",
    "round_polygon_corners",
    "render_colored_block",
    "ImageRenderer",
    "StyleResolver",
    "WebRenderer",
]
