"""Render layer for text block rendering.

负责：
- 显示（PNG 图片渲染 / Web 输出预留）
- 字体 / 样式解析

Render 层不自行计算坐标。它接收 TextLayout 并按指示绘制。
"""

from typing import List, Tuple, Optional

from PIL import Image, ImageDraw
import math

from .models import (
    ColoredSubtitleBlock,
    RenderStyle,
    TextLayout,
)
from .splitter import TextMeasurer


class StyleResolver:
    """样式解析器"""

    @staticmethod
    def parse_color(color_str: str) -> Tuple[int, int, int, int]:
        """将颜色字符串解析为 RGBA 元组

        原 pipeline._parse_color() 移至此处。
        """
        if isinstance(color_str, tuple):
            return color_str
        if color_str.startswith("#"):
            color_str = color_str[1:]
        if len(color_str) == 6:
            r = int(color_str[0:2], 16)
            g = int(color_str[2:4], 16)
            b = int(color_str[4:6], 16)
            return (r, g, b, 255)
        elif len(color_str) == 8:
            r = int(color_str[0:2], 16)
            g = int(color_str[2:4], 16)
            b = int(color_str[4:6], 16)
            a = int(color_str[6:8], 16)
            return (r, g, b, a)
        else:
            return (255, 255, 255, 255)  # 默认白色

    @staticmethod
    def resolve_background(style: RenderStyle) -> Tuple[int, int, int, int]:
        """解析背景色"""
        if style.bg_color is None:
            return (0, 0, 0, 0)
        return StyleResolver.parse_color(style.bg_color)


def optimize_polygon_x_alignment(
    points: List[Tuple[int, int]], threshold: int = 5, side: str = "right"
) -> List[Tuple[int, int]]:
    """优化多边形顶点的 x 坐标对齐

    对于相邻的两个点，如果它们的 x 坐标差值在阈值范围内，
    根据边的位置进行对齐：
    - 右侧边界 (side="right")：合并到较大的 x 值（向右扩展）
    - 左侧边界 (side="left")：合并到较小的 x 值（向左扩展）

    使用多轮迭代确保级联合并：当 x1 合并到 x0 后，x2 会按照新的 x1 计算。

    Args:
        points: 多边形顶点列表 [(x, y), ...]
        threshold: x 坐标对齐的阈值（像素），默认为 5
        side: 边的位置，"left" 或 "right"

    Returns:
        优化后的顶点列表
    """
    if len(points) <= 4:
        return points

    optimized = list(points)

    changed = True
    while changed:
        changed = False
        for i in range(len(optimized) - 1):
            curr_x, curr_y = optimized[i]
            next_x, next_y = optimized[i + 1]

            x_diff = abs(next_x - curr_x)

            if x_diff <= threshold and x_diff > 0:
                if side == "right":
                    target_x = max(curr_x, next_x)
                else:
                    target_x = min(curr_x, next_x)

                if optimized[i][0] != target_x or optimized[i + 1][0] != target_x:
                    optimized[i] = (target_x, curr_y)
                    optimized[i + 1] = (target_x, next_y)
                    changed = True

    return optimized


def round_polygon_corners(
    points: List[Tuple[int, int]], radius: int = 12, segments: int = 8
) -> List[Tuple[int, int]]:
    """对多边形的外凸角进行圆角处理

    使用向量叉积判断角的凸凹性：
    - 对于顺时针绑线的多边形，叉积 < 0 表示外凸角
    - 仅对外凸角生成圆弧，凹角保持尖锐

    Args:
        points: 多边形顶点列表 [(x, y), ...]，顺时针方向
        radius: 圆角半径
        segments: 圆弧采样点数量

    Returns:
        带圆角的顶点列表
    """
    if len(points) < 3 or radius <= 0:
        return points

    n = len(points)
    result = []

    for i in range(n):
        p0 = points[(i - 1) % n]
        p1 = points[i]
        p2 = points[(i + 1) % n]

        v1 = (p1[0] - p0[0], p1[1] - p0[1])
        v2 = (p2[0] - p1[0], p2[1] - p1[1])
        cross = v1[0] * v2[1] - v1[1] * v2[0]
        len1 = math.sqrt(v1[0] ** 2 + v1[1] ** 2)
        len2 = math.sqrt(v2[0] ** 2 + v2[1] ** 2)

        if len1 == 0 or len2 == 0 or cross <= 0:
            result.append(p1)
            continue

        u1 = (-v1[0] / len1, -v1[1] / len1)
        u2 = (v2[0] / len2, v2[1] / len2)
        max_radius = min(len1 / 2, len2 / 2, radius)

        if max_radius < 1:
            result.append(p1)
            continue

        t1 = (p1[0] + u1[0] * max_radius, p1[1] + u1[1] * max_radius)
        t2 = (p1[0] + u2[0] * max_radius, p1[1] + u2[1] * max_radius)
        for j in range(segments + 1):
            t = j / segments
            one_minus_t = 1 - t
            bx = (
                one_minus_t * one_minus_t * t1[0]
                + 2 * one_minus_t * t * p1[0]
                + t * t * t2[0]
            )
            by = (
                one_minus_t * one_minus_t * t1[1]
                + 2 * one_minus_t * t * p1[1]
                + t * t * t2[1]
            )
            result.append((int(round(bx)), int(round(by))))

    return result


class ImageRenderer:
    """PNG 图片渲染器

    根据 TextLayout 提供的坐标信息渲染字幕块为 PNG 图片。
    """

    def __init__(self, measurer: TextMeasurer, style: RenderStyle):
        self.measurer = measurer
        self.style = style

    def render_block(
        self,
        block: ColoredSubtitleBlock,
        layout: TextLayout,
    ) -> Image.Image:
        """根据布局信息渲染 block 为 PNG

        坐标计算由 layout 提供，此方法只负责绘制。

        Args:
            block: 字幕块数据
            layout: 由 Layout 层计算的文本布局

        Returns:
            PIL Image 对象
        """
        padding_x, padding_y = self.style.padding
        mask_offset_x, mask_offset_y = self.style.mask_offset
        stroke_size = self.style.stroke_size
        default_font_size = self.measurer.font_spec.font_size

        background_color = StyleResolver.resolve_background(self.style)
        default_color = self.style.text_color
        mask_mode = self.style.mask_mode
        mask_color = self.style.mask_color
        mask_radius = self.style.corner_radius
        stroke_color = self.style.stroke_color

        img_width = layout.image_width
        img_height = layout.image_height
        line_positions = layout.line_positions

        img = Image.new("RGBA", (img_width, img_height), background_color)
        draw = ImageDraw.Draw(img)

        # 绘制底框
        if mask_mode == 1:
            mask_x0 = padding_x
            mask_y0 = padding_y
            mask_x1 = img_width - padding_x - 1
            mask_y1 = img_height - padding_y - 1
            draw.rounded_rectangle(
                [(mask_x0, mask_y0), (mask_x1, mask_y1)],
                radius=mask_radius,
                fill=mask_color,
            )
        elif mask_mode == 2:
            if line_positions:
                line_boxes = []
                line_padding_x = mask_offset_x
                line_padding_y = mask_offset_y + stroke_size

                for i, pos in enumerate(line_positions):
                    x0 = pos["x"] - line_padding_x
                    x1 = pos["x"] + pos["width"] + line_padding_x - 1

                    if i == 0:
                        y0 = padding_y
                    else:
                        prev_pos = line_positions[i - 1]
                        prev_bottom = prev_pos["y"] + prev_pos["height"]
                        curr_top = pos["y"]
                        y0 = (prev_bottom + curr_top) // 2

                    if i == len(line_positions) - 1:
                        y1 = img_height - padding_y - 1
                    else:
                        next_pos = line_positions[i + 1]
                        curr_bottom = pos["y"] + pos["height"]
                        next_top = next_pos["y"]
                        y1 = (curr_bottom + next_top) // 2

                    line_boxes.append((x0, y0, x1, y1))

                # 顺时针收集多边形顶点：右侧边界（从上到下）
                right_points = []
                right_points.append(
                    (line_boxes[0][2], line_boxes[0][1])
                )  # 第一行右上

                for i in range(len(line_boxes)):
                    curr_box = line_boxes[i]
                    if i == len(line_boxes) - 1:
                        right_points.append(
                            (curr_box[2], curr_box[3])
                        )  # 最后一行右下
                    else:
                        next_box = line_boxes[i + 1]
                        curr_x1 = curr_box[2]
                        next_x1 = next_box[2]

                        if next_x1 > curr_x1:
                            turn_y = next_box[1]
                            right_points.append((curr_x1, turn_y))
                            right_points.append((next_x1, turn_y))
                        elif next_x1 < curr_x1:
                            turn_y = curr_box[3]
                            right_points.append((curr_x1, turn_y))
                            right_points.append((next_x1, turn_y))

                # 左侧边界（从下到上）
                left_points = []
                left_points.append((line_boxes[-1][0], line_boxes[-1][3]))

                for i in range(len(line_boxes) - 1, -1, -1):
                    curr_box = line_boxes[i]
                    if i == 0:
                        left_points.append((curr_box[0], curr_box[1]))
                    else:
                        prev_box = line_boxes[i - 1]
                        curr_x0 = curr_box[0]
                        prev_x0 = prev_box[0]

                        if prev_x0 < curr_x0:
                            turn_y = curr_box[1]
                            left_points.append((curr_x0, turn_y))
                            left_points.append((prev_x0, turn_y))
                        elif prev_x0 > curr_x0:
                            turn_y = prev_box[3]
                            left_points.append((curr_x0, turn_y))
                            left_points.append((prev_x0, turn_y))

                # 优化边界对齐并圆角处理
                right_points = optimize_polygon_x_alignment(
                    right_points, threshold=20, side="right"
                )
                left_points = optimize_polygon_x_alignment(
                    left_points, threshold=20, side="left"
                )
                polygon_points = right_points + left_points
                if len(polygon_points) >= 3:
                    polygon_points = round_polygon_corners(
                        polygon_points, radius=mask_radius, segments=8
                    )
                    draw.polygon(polygon_points, fill=mask_color)

        # 绘制文本
        for line_idx, line in enumerate(block.lines):
            pos = line_positions[line_idx]
            x = pos["x"]
            baseline_y = pos["y"] + pos["ascent"]

            draw_line = list(reversed(line)) if block.rtl_mode else line

            for i, cword in enumerate(draw_line):
                color = cword.color or default_color
                word_font_size = cword.font_size or default_font_size
                ascent, descent = self.measurer.get_metrics(word_font_size, cword.word)

                for text, is_emoji in self.measurer.split_text_runs(cword.word):
                    font = self.measurer.get_font_for_run(cword.font_size, is_emoji)
                    run_ascent, _ = font.getmetrics()
                    draw_y = baseline_y - ascent + (ascent - run_ascent)

                    if stroke_size > 0 and not is_emoji:
                        draw.text(
                            (x, draw_y),
                            text,
                            font=font,
                            fill=stroke_color,
                            stroke_width=stroke_size,
                            stroke_fill=stroke_color,
                        )

                    draw.text(
                        (x, draw_y),
                        text,
                        font=font,
                        fill=color,
                        embedded_color=is_emoji,
                    )
                    x += self.measurer.measure_text_run(
                        text, cword.font_size, is_emoji
                    )
                if i < len(draw_line) - 1:
                    space_width = self.measurer.measure_word(" ", cword.font_size)
                    x += space_width

        return img

    def render_block_to_file(
        self,
        block: ColoredSubtitleBlock,
        layout: TextLayout,
        save_path: str,
    ) -> Tuple[int, int]:
        """渲染并保存到文件

        Args:
            block: 字幕块数据
            layout: 文本布局
            save_path: 保存路径

        Returns:
            (width, height) 元组
        """
        img = self.render_block(block, layout)
        img.save(save_path)
        return img.size


class WebRenderer:
    """Web/CSS 输出渲染器 (预留接口)

    未来可用于生成 Web 端字幕显示所需的 CSS/HTML 数据。
    """

    def render_to_css(
        self,
        block: ColoredSubtitleBlock,
        layout: TextLayout,
    ) -> dict:
        """输出 CSS 样式字典，用于 Web 端字幕显示

        当前版本为预留接口，返回空字典。
        """
        return {}
