"""RTL (Right-to-Left) text processing utilities for Arabic and Hebrew.

This module implements the RTL text processing pipeline:
1. Tag Protection - Replace HTML tags with invisible Arabic markers
2. Arabic Reshaping - Convert isolated Arabic characters to connected forms
3. Bidi Reordering - Convert logical order to visual display order
4. Tag Restoration - Restore original HTML tags after processing
"""

import re
from typing import List, Tuple, Dict, Optional

# Try to import RTL libraries, provide fallback if not available
try:
    import arabic_reshaper
    from bidi.algorithm import get_display

    RTL_AVAILABLE = True
except ImportError:
    RTL_AVAILABLE = False

# Invisible markers for protecting tags during Arabic reshaping
AR_INVISIBLE_LTR = "\u200e"  # Left-to-Right Mark
AR_INVISIBLE_RTL = "\u200f"  # Right-to-Left Mark
AR_INVISIBLE_LETTER = "\u061c"  # Arabic Letter Mark - used as newline replacement

# RTL language codes
RTL_LANGUAGES = {"AR", "HE", "FA", "UR"}

# Regex pattern for HTML-like tags (e.g., <w color="...">)
TAG_PATTERN = re.compile(r"<[^>]+>|</[^>]+>")


def is_rtl_language(language: str) -> bool:
    """Check if the language code represents an RTL language.

    Args:
        language: Two-letter language code (e.g., "AR", "HE")

    Returns:
        True if the language is RTL, False otherwise
    """
    return language.upper() in RTL_LANGUAGES


def is_rtl_text(text: str) -> bool:
    """Check if text contains RTL characters.

    Args:
        text: Text to check

    Returns:
        True if text contains Arabic or Hebrew characters
    """
    # Check for Arabic characters (U+0600 to U+06FF) or Hebrew (U+0590 to U+05FF)
    for char in text:
        code = ord(char)
        if 0x0600 <= code <= 0x06FF or 0x0590 <= code <= 0x05FF:
            return True
    return False


def protect_tags_with_arabic_marker(text: str) -> Tuple[str, List[Dict]]:
    """Replace HTML tags with invisible Arabic markers before reshaping.

    This prevents arabic_reshaper and bidi algorithms from scrambling HTML tags.
    Each tag is replaced with a unique invisible "Arabic word" that won't affect reshaping.

    Args:
        text: Text containing HTML tags

    Returns:
        Tuple of (processed_text, tags_info_list)
        - processed_text: Text with tags replaced by invisible markers
        - tags_info_list: List of dicts with 'marker' and 'original' keys
    """
    if not RTL_AVAILABLE:
        return text, []

    # Replace newlines with invisible letter marker
    text = text.replace("\n", AR_INVISIBLE_LETTER)

    # Find all tags
    tags = TAG_PATTERN.findall(text)
    tags_info = []

    for i, tag in enumerate(tags):
        # Create unique invisible marker: RTL + (i+2)*LTR + RTL
        # The varying length makes each marker unique
        marker = AR_INVISIBLE_RTL + AR_INVISIBLE_LTR * (i + 2) + AR_INVISIBLE_RTL
        tags_info.append({"marker": marker, "original": tag})
        text = text.replace(tag, marker, 1)

    return text, tags_info


def restore_tags_from_arabic_marker(text: str, tags_info: List[Dict]) -> str:
    """Restore original HTML tags from invisible markers.

    Args:
        text: Text with invisible markers
        tags_info: List of dicts with 'marker' and 'original' keys

    Returns:
        Text with original tags restored
    """
    # Restore in reverse order to handle nested replacements
    for info in reversed(tags_info):
        text = text.replace(info["marker"], info["original"])

    # Restore newlines
    text = text.replace(AR_INVISIBLE_LETTER, "\n")

    return text


def empty_tags_arabic_marker(text: str) -> str:
    """Remove invisible markers from text for measurement.

    Args:
        text: Text potentially containing invisible markers

    Returns:
        Text with invisible markers stripped
    """
    return (
        text.replace(AR_INVISIBLE_LTR, "")
        .replace(AR_INVISIBLE_RTL, "")
        .replace(AR_INVISIBLE_LETTER, "")
    )


def reshape_arabic(text: str) -> str:
    """Apply Arabic reshaping to connect letters properly.

    Arabic letters have different forms (initial, medial, final, isolated)
    depending on their position in a word. This function converts isolated
    forms to their proper connected forms.

    Args:
        text: Arabic text in logical order

    Returns:
        Text with properly connected Arabic letters
    """
    if not RTL_AVAILABLE:
        return text

    return arabic_reshaper.reshape(text)


def apply_bidi(text: str) -> str:
    """Apply bidirectional algorithm to convert logical to visual order.

    After this transformation, the string is in "Visual Order" -
    the first character should be drawn on the far left.

    Args:
        text: Text in logical order

    Returns:
        Text in visual display order
    """
    if not RTL_AVAILABLE:
        return text

    return get_display(text)


def process_rtl_text(text: str, protect_tags: bool = True) -> Tuple[str, List[Dict]]:
    """Full RTL text processing pipeline.

    This applies the complete transformation needed for RTL text:
    1. Protect HTML tags (optional)
    2. Reshape Arabic characters
    3. Apply bidi algorithm
    4. Return processed text and tag info for later restoration

    Args:
        text: RTL text to process
        protect_tags: Whether to protect HTML tags before processing

    Returns:
        Tuple of (processed_text, tags_info)
        - processed_text: Text ready for visual display
        - tags_info: Tag information for restoration (empty if protect_tags=False)
    """
    if not RTL_AVAILABLE:
        return text, []

    tags_info = []

    if protect_tags:
        text, tags_info = protect_tags_with_arabic_marker(text)

    # Step 1: Reshape Arabic letters (connect them)
    text = reshape_arabic(text)

    # Step 2: Apply bidi algorithm (convert to visual order)
    text = apply_bidi(text)

    return text, tags_info


def process_rtl_word(word: str) -> str:
    """Process a single RTL word (no tag protection needed).

    Args:
        word: Single word to process

    Returns:
        Word with Arabic reshaping and bidi applied
    """
    if not RTL_AVAILABLE:
        return word

    return apply_bidi(reshape_arabic(word))


def batch_process_rtl_words(words: List[str]) -> List[str]:
    """批量处理 RTL 单词（高效版本）。

    将所有单词用特殊分隔符连接后一次性处理，大幅减少函数调用开销。

    Args:
        words: 需要处理的单词列表

    Returns:
        处理后的单词列表（顺序保持不变）
    """
    if not RTL_AVAILABLE or not words:
        return words

    # 过滤出非空单词，记录原始索引
    non_empty_indices = []
    non_empty_words = []
    for i, w in enumerate(words):
        if w:
            non_empty_indices.append(i)
            non_empty_words.append(w)

    if not non_empty_words:
        return words

    # 批量处理：连接 -> reshape -> bidi -> 拆分
    combined = AR_INVISIBLE_LETTER.join(non_empty_words)
    reshaped = arabic_reshaper.reshape(combined)
    visual = get_display(reshaped)
    processed_words = visual.split(AR_INVISIBLE_LETTER)

    # bidi 处理后顺序会反转，需要反转回来
    processed_words = list(reversed(processed_words))

    # 构建结果列表
    result = list(words)  # 复制原始列表
    for i, idx in enumerate(non_empty_indices):
        if i < len(processed_words):
            result[idx] = processed_words[i]

    return result


def split_rtl_for_lines(
    text: str, tags_info: List[Dict]
) -> Tuple[List[str], List[Dict]]:
    """Split RTL text by paragraph markers.

    Args:
        text: RTL text with invisible newline markers
        tags_info: Tag information from protect_tags

    Returns:
        Tuple of (paragraphs, tags_info)
    """
    # Split by newline marker
    paragraphs = text.split(AR_INVISIBLE_LETTER)
    # Note: The guide mentions reversing paragraphs, but this may depend on use case
    # For now, we keep original order
    return paragraphs, tags_info
