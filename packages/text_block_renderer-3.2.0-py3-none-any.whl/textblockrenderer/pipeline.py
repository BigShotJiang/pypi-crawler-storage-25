"""Pipeline utilities for end-to-end text to timeline subtitle conversion.

编排层 - 协调 Timeline、Layout、Render 三层 API 完成端到端流程。

提供从文本到时间轴字幕的整合API，包括:
1. HTML文本解析
2. 分段处理
3. 字幕块分割
4. 图片渲染 (Render 层)
5. 布局计算 (Layout 层)
6. 阅读时间计算 (Timeline 层)
"""

import os
from typing import List, Optional, Tuple, Callable
from pathlib import Path

from .models import (
    ColoredSubtitleBlock,
    ColoredWord,
    FontSpec,
    RenderConstraint,
    SplitConfig,
    FrameSubtitle,
    RenderStyle,
    BlockTiming,
    OverlappingFrameSubtitle,
    AdjustMode,
    VerticalAlignment,
    TrackMode,
)
from .htmlparser import split_html_paragraphs
from .splitter import TextMeasurer, split_html_to_colored_blocks

# 三层架构导入
from .layout import LayoutEngine, AutoArrange
from .render import ImageRenderer, StyleResolver
from .models import FrameLayout, BlockPlacement
from .timeline import (
    DEFAULT_WPM,
    TimeCalculator,
    TimelineTrack,
    FrameAssembler,
    calculate_read_time,
    create_frame_subtitles,
    create_overlapping_frame_subtitles,
)

# 兼容：保留 renderer 导入路径
from .renderer import render_colored_block


def _parse_color(color_str: str) -> Tuple[int, int, int, int]:
    """将颜色字符串解析为RGBA元组（兼容包装）

    委托给 StyleResolver.parse_color()。
    """
    return StyleResolver.parse_color(color_str)


def text_to_timeline_subtitles(
    html_text: str,
    font_spec: FontSpec,
    constraint: RenderConstraint,
    output_dir: str,
    *,
    split_config: Optional[SplitConfig] = None,
    wpm: float = DEFAULT_WPM,
    style: Optional[RenderStyle] = None,
    base_font_size: int = 18,
    filename_prefix: str = "subtitle",
    render: bool = True,
) -> List[FrameSubtitle]:
    """从HTML文本生成时间轴字幕帧列表 (完整流水线)

    编排三层 API:
    - Layout 层: 计算安全区域、有效约束、文本布局
    - Render 层: 渲染 PNG 图片
    - Timeline 层: 计算阅读时间

    Args:
        html_text: HTML格式的文本内容（支持<font color="...">标签）
        font_spec: 字体配置（路径、大小、行距）
        constraint: 渲染约束（最大宽度、最大高度）
        output_dir: 输出目录路径，用于保存PNG图片

        split_config: 分割配置，默认 SplitConfig()
        wpm: 阅读速度（每分钟单词数），默认150
        style: 渲染样式配置 (RenderStyle)
        base_font_size: HTML字号基准
        filename_prefix: 输出文件名前缀
        render: 是否渲染PNG图片，False则只生成字幕块和路径

    Returns:
        List[FrameSubtitle]: 时间轴字幕帧列表
    """
    # 确保输出目录存在
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # 使用默认配置
    if split_config is None:
        split_config = SplitConfig()
    if style is None:
        style = RenderStyle()

    # 创建文本测量器
    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)

    # Layout: 计算有效约束
    layout_engine = LayoutEngine(constraint, style, measurer)
    effective_constraint = layout_engine.compute_effective_constraint()

    # 分割HTML为段落
    paragraphs = split_html_paragraphs(html_text)

    # 存储所有字幕块
    all_blocks: List[ColoredSubtitleBlock] = []
    all_paths: List[str] = []

    # 处理每个段落
    for paragraph in paragraphs:
        if not paragraph.strip():
            continue

        blocks = split_html_to_colored_blocks(
            html_paragraph=paragraph,
            measurer=measurer,
            constraint=effective_constraint,
            config=split_config,
            base_font_size=base_font_size,
        )
        all_blocks.extend(blocks)

    # Layout: 预计算每个 block 的尺寸（不渲染像素）
    text_layouts = []
    for block in all_blocks:
        text_layout = layout_engine.compute_text_layout(block, align=style.alignment)
        block.image_width = text_layout.image_width
        block.image_height = text_layout.image_height
        text_layouts.append(text_layout)

    # 生成文件路径，按需渲染
    renderer = ImageRenderer(measurer, style)

    for i, block in enumerate(all_blocks):
        filename = f"{filename_prefix}_{i:04d}.png"
        save_path = os.path.join(output_dir, filename)
        all_paths.append(save_path)

        if render:
            renderer.render_block_to_file(block, text_layouts[i], save_path)

    # Timeline: 创建时间轴字幕帧
    return create_frame_subtitles(all_blocks, all_paths, wpm)


def blocks_to_timeline_subtitles(
    blocks: List[ColoredSubtitleBlock],
    font_spec: FontSpec,
    output_dir: str,
    *,
    wpm: float = DEFAULT_WPM,
    style: Optional[RenderStyle] = None,
    filename_prefix: str = "subtitle",
    render: bool = True,
) -> List[FrameSubtitle]:
    """从已有的字幕块列表生成时间轴字幕帧

    Args:
        blocks: 字幕块列表
        font_spec: 字体配置
        output_dir: 输出目录路径

        wpm: 阅读速度
        style: 渲染样式配置
        filename_prefix: 输出文件名前缀
        render: 是否渲染PNG图片

    Returns:
        List[FrameSubtitle]: 时间轴字幕帧列表
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    if style is None:
        style = RenderStyle()

    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    constraint = RenderConstraint(max_width=9999, max_height=0)
    layout_engine = LayoutEngine(constraint, style, measurer)
    renderer = ImageRenderer(measurer, style)

    all_paths: List[str] = []

    for i, block in enumerate(blocks):
        filename = f"{filename_prefix}_{i:04d}.png"
        save_path = os.path.join(output_dir, filename)
        all_paths.append(save_path)

        if render:
            text_layout = layout_engine.compute_text_layout(
                block, align=style.alignment
            )
            w, h = renderer.render_block_to_file(block, text_layout, save_path)
            block.image_width, block.image_height = w, h

    return create_frame_subtitles(blocks, all_paths, wpm)


def calculate_total_duration(frames: List[FrameSubtitle]) -> float:
    """计算所有字幕帧的总时长

    Args:
        frames: 时间轴字幕帧列表

    Returns:
        float: 总时长（秒）
    """
    return sum(frame.read_time for frame in frames)


def get_timestamps(frames: List[FrameSubtitle]) -> List[Tuple[float, float]]:
    """获取每个字幕帧的开始和结束时间戳

    Args:
        frames: 时间轴字幕帧列表

    Returns:
        List[Tuple[float, float]]: (开始时间, 结束时间) 列表
    """
    timestamps = []
    current_time = 0.0

    for frame in frames:
        start_time = current_time
        end_time = current_time + frame.read_time
        timestamps.append((round(start_time, 2), round(end_time, 2)))
        current_time = end_time

    return timestamps


def export_to_srt(frames: List[FrameSubtitle], output_path: str) -> None:
    """将时间轴字幕帧导出为SRT字幕文件"""
    timestamps = get_timestamps(frames)

    def format_time(seconds: float) -> str:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

    with open(output_path, "w", encoding="utf-8") as f:
        for i, (frame, (start, end)) in enumerate(zip(frames, timestamps), 1):
            f.write(f"{i}\n")
            f.write(f"{format_time(start)} --> {format_time(end)}\n")
            f.write(f"{frame.block.plain_text}\n")
            f.write("\n")


def build_overlapping_timeline(
    html_text: str,
    font_spec: FontSpec,
    constraint: RenderConstraint,
    *,
    split_config: Optional[SplitConfig] = None,
    wpm: float = DEFAULT_WPM,
    style: Optional[RenderStyle] = None,
    base_font_size: int = 18,
    spacing: int = 10,
    max_blocks_per_frame: int = 0,
    track_mode: TrackMode = TrackMode.SEQUENTIAL,
) -> List[OverlappingFrameSubtitle]:
    """Step 1: 从 HTML 文本生成时间轴字幕帧（纯数据，不渲染）

    1. HTML → 段落 → 字幕块
    2. Layout 层预计算每个 block 的 image_width / image_height
    3. Timeline 层: 阅读时间 → 帧合并

    Args:
        html_text: HTML格式的文本内容
        font_spec: 字体配置
        constraint: 渲染约束（max_width, max_height）

        split_config: 分割配置
        wpm: 阅读速度
        style: 渲染样式配置（用于计算尺寸）
        base_font_size: HTML字号基准
        spacing: 字幕块之间的间距（像素）
        max_blocks_per_frame: 每帧最多可展示的 block 数量，0 = 无限制
        track_mode: 帧内轨道时间模式
                    SEQUENTIAL: 每个轨道按自己的时间轴依次显示（默认）
                    SYNCHRONIZED: 所有轨道使用同一开始时间和最长结束时间

    Returns:
        List[OverlappingFrameSubtitle]: 时间轴字幕帧列表（block 已有尺寸，无 PNG）
    """
    if split_config is None:
        split_config = SplitConfig(min_words_per_block=3)
    if style is None:
        style = RenderStyle()

    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)

    # Layout: 计算有效约束
    layout_engine = LayoutEngine(constraint, style, measurer)
    effective_constraint = layout_engine.compute_effective_constraint()

    # 分割HTML为段落
    paragraphs = split_html_paragraphs(html_text)

    all_blocks: List[ColoredSubtitleBlock] = []

    for paragraph in paragraphs:
        if not paragraph.strip():
            continue

        blocks = split_html_to_colored_blocks(
            html_paragraph=paragraph,
            measurer=measurer,
            constraint=effective_constraint,
            config=split_config,
            base_font_size=base_font_size,
        )
        all_blocks.extend(blocks)

    # Layout: 预计算每个 block 的尺寸（不渲染像素）
    for block in all_blocks:
        text_layout = layout_engine.compute_text_layout(block, align=style.alignment)
        block.image_width = text_layout.image_width
        block.image_height = text_layout.image_height

    # 生成占位路径
    all_paths = [f"block_{i:04d}.png" for i in range(len(all_blocks))]

    # Timeline: 创建重叠时间轴字幕帧
    frames = create_overlapping_frame_subtitles(
        all_blocks,
        all_paths,
        constraint.max_height,
        wpm,
        spacing,
        max_blocks_per_frame,
        preferred_height=constraint.preferred_height,
    )

    # 应用轨道模式
    if track_mode == TrackMode.SYNCHRONIZED:
        for frame in frames:
            if frame.block_timings:
                min_start = min(t.start_time for t in frame.block_timings)
                max_end = max(t.end_time for t in frame.block_timings)
                for timing in frame.block_timings:
                    timing.start_time = min_start
                    timing.end_time = max_end

    return frames


def text_to_overlapping_subtitles(
    html_text: str,
    font_spec: FontSpec,
    constraint: RenderConstraint,
    output_dir: str,
    *,
    split_config: Optional[SplitConfig] = None,
    wpm: float = DEFAULT_WPM,
    style: Optional[RenderStyle] = None,
    base_font_size: int = 18,
    filename_prefix: str = "subtitle",
    render: bool = True,
    spacing: int = 10,
    max_blocks_per_frame: int = 0,
) -> List[OverlappingFrameSubtitle]:
    """从HTML文本生成支持重叠的时间轴字幕帧列表（兼容接口）

    内部调用 build_overlapping_timeline 生成时间轴，
    然后按需渲染 PNG 图片并更新路径。

    Args:
        html_text: HTML格式的文本内容
        font_spec: 字体配置
        constraint: 渲染约束
        output_dir: 输出目录路径

        split_config: 分割配置
        wpm: 阅读速度
        style: 渲染样式配置
        base_font_size: HTML字号基准
        filename_prefix: 输出文件名前缀
        render: 是否渲染PNG图片
        spacing: 字幕块之间的间距（像素）
        max_blocks_per_frame: 每帧最多可展示的 block 数量，0 = 无限制

    Returns:
        List[OverlappingFrameSubtitle]: 支持重叠的字幕帧列表
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    if style is None:
        style = RenderStyle()

    # Step 1: 生成时间轴
    frames = build_overlapping_timeline(
        html_text=html_text,
        font_spec=font_spec,
        constraint=constraint,
        split_config=split_config,
        wpm=wpm,
        style=style,
        base_font_size=base_font_size,
        spacing=spacing,
        max_blocks_per_frame=max_blocks_per_frame,
    )

    # 更新路径并按需渲染
    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    layout_engine = LayoutEngine(constraint, style, measurer)
    renderer = ImageRenderer(measurer, style)

    block_idx = 0
    rendered_ids: set = set()

    for frame in frames:
        for timing in frame.block_timings:
            block = timing.block
            bid = id(block)

            if bid not in rendered_ids:
                filename = f"{filename_prefix}_{block_idx:04d}.png"
                save_path = os.path.join(output_dir, filename)
                timing.save_path = save_path

                if render:
                    text_layout = layout_engine.compute_text_layout(
                        block, align=style.alignment
                    )
                    renderer.render_block_to_file(block, text_layout, save_path)

                rendered_ids.add(bid)
                block_idx += 1

    return frames


def render_and_layout_frames(
    frames: List[OverlappingFrameSubtitle],
    font_spec: FontSpec,
    constraint: RenderConstraint,
    output_dir: str,
    *,
    style: Optional[RenderStyle] = None,
    filename_prefix: str = "subtitle",
    spacing: int = 10,
    align: str = "center",
    scale_to_fit: bool = False,
) -> List[FrameLayout]:
    """对字幕帧列表进行渲染和自动布局

    接收 build_overlapping_timeline 或 text_to_overlapping_subtitles 的输出，
    执行 Step 2（渲染 PNG）和 Step 3（自动布局计算坐标）。

    Args:
        frames: 字幕帧列表
        font_spec: 字体配置
        constraint: 渲染约束（max_height 用于缩放判断）
        output_dir: PNG 输出目录

        style: 渲染样式配置
        filename_prefix: 文件名前缀
        spacing: 块间距（像素）
        align: 水平对齐方式 - "left", "center", "right"
        scale_to_fit: 路线 B — 超出 max_height 时是否自动缩放。
                      True: 缩放坐标和尺寸，返回 scale < 1.0
                      False: 原始布局，不缩放（调用方可选路线 A 重新分割）

    Returns:
        List[FrameLayout]: 每帧的布局信息，包含每个 block 的 (x, y) 坐标和缩放因子
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    if style is None:
        style = RenderStyle()

    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    layout_constraint = RenderConstraint(max_width=constraint.max_width, max_height=0)
    layout_engine = LayoutEngine(layout_constraint, style, measurer)
    renderer = ImageRenderer(measurer, style)

    # 收集所有唯一的 block（按 id 去重，避免重复渲染）
    rendered_blocks: dict = {}

    for frame in frames:
        for timing in frame.block_timings:
            block = timing.block
            block_id = id(block)

            if block_id not in rendered_blocks:
                # Layout: 计算文本布局
                text_layout = layout_engine.compute_text_layout(
                    block, align=style.alignment
                )
                block.image_width = text_layout.image_width
                block.image_height = text_layout.image_height

                # Render: 渲染 PNG
                save_path = timing.save_path
                if not save_path or not os.path.dirname(save_path):
                    idx = len(rendered_blocks)
                    save_path = os.path.join(
                        output_dir, f"{filename_prefix}_{idx:04d}.png"
                    )
                    timing.save_path = save_path

                renderer.render_block_to_file(block, text_layout, save_path)
                rendered_blocks[block_id] = text_layout

                # 更新 timing 中的尺寸
                timing.image_width = block.image_width
                timing.image_height = block.image_height

    # Step 3: 自动布局
    # scale_to_fit=True  → 路线 B: 超出 max_height 自动缩放
    # scale_to_fit=False → 原始布局，不缩放
    layout_max_height = constraint.max_height if scale_to_fit else 0
    auto_arrange = AutoArrange(layout_engine)
    frame_layouts: List[FrameLayout] = []

    for frame in frames:
        frame_blocks = [timing.block for timing in frame.block_timings]
        layout = auto_arrange.arrange_vertical(
            frame_blocks,
            spacing=spacing,
            align=align,
            max_height=layout_max_height,
        )
        frame_layouts.append(layout)

    return frame_layouts


# ========== 路线 B 工具函数：block ↔ HTML 互转 ==========


def block_to_html(colored_words: List[ColoredWord]) -> str:
    """将带样式的单词列表重建为 HTML 字符串

    用于路线 B：先拆分时间轴，再逐块翻译。
    将带样式单词列表还原为可翻译的 HTML 片段，
    保留 <font color="..."> 和 font-size 标签。

    Args:
        colored_words: 带样式的单词列表

    Returns:
        str: HTML 字符串，如 '<span style="color: rgb(231, 95, 51);">Rania</span> ran for her life.'
    """
    if not colored_words:
        return ""

    parts = []
    current_color = None
    current_font_size = None
    span_open = False
    need_space = False  # 下一个单词前是否需要空格

    for cw in colored_words:
        # 检查样式是否变化
        color_changed = cw.color != current_color
        size_changed = cw.font_size != current_font_size

        if color_changed or size_changed:
            # 关闭之前的 span
            if span_open:
                parts.append("</span>")
                span_open = False

            # 样式切换边界：根据 leading_space 还原原始空格
            if cw.leading_space:
                parts.append(" ")
            need_space = False

            # 如果有样式，开新 span
            if cw.color is not None or cw.font_size is not None:
                style_parts = []
                if cw.color is not None:
                    style_parts.append(f"color: {cw.color}")
                if cw.font_size is not None:
                    style_parts.append(f"font-size: {cw.font_size}px")
                parts.append(f'<span style="{"; ".join(style_parts)};">')
                span_open = True

            current_color = cw.color
            current_font_size = cw.font_size

        # 添加单词
        if cw.word == "" and cw.force_newline:
            parts.append("\n")
            need_space = False
        else:
            if need_space:
                parts.append(" ")
            parts.append(cw.word)
            need_space = True

    # 关闭最后一个 span
    if span_open:
        parts.append("</span>")

    return "<p>" + "".join(parts) + "</p>"


def rebuild_block_from_html(
    block: ColoredSubtitleBlock,
    translated_html: str,
    measurer: "TextMeasurer",
    constraint: RenderConstraint,
    style: RenderStyle,
    base_font_size: int = 18,
) -> ColoredSubtitleBlock:
    """用翻译后的 HTML 重建字幕块

    用于路线 B：保持帧结构不变，仅替换 block 内容。
    解析翻译后的 HTML，重建 colored_words 和行分布，
    并重新计算 image_width / image_height。

    Args:
        block: 原字幕块（将被就地更新）
        translated_html: 翻译后的 HTML 文本
        measurer: 文本测量器
        constraint: 渲染约束
        style: 渲染样式
        base_font_size: HTML 字号基准

    Returns:
        ColoredSubtitleBlock: 更新后的字幕块（同一对象）
    """
    from .htmlparser import parse_html_text
    from .splitter import split_html_to_colored_blocks

    # 解析翻译后的 HTML 为 colored_words
    plain_text, colored_words = parse_html_text(
        translated_html,
        base_font_size=base_font_size,
        target_font_size=measurer.font_size,
    )

    # 用新的 colored_words 重建 block 的行分布
    # 使用 splitter 重新按宽度分行
    layout_engine = LayoutEngine(constraint, style, measurer)
    effective = layout_engine.compute_effective_constraint()

    temp_blocks = split_html_to_colored_blocks(
        html_paragraph=translated_html,
        measurer=measurer,
        constraint=effective,
        config=SplitConfig(min_words_per_block=len(colored_words), language="EN"),
        base_font_size=base_font_size,
    )

    if temp_blocks:
        new_block = temp_blocks[0]
        # 就地更新原 block 的内容
        block.plain_text = new_block.plain_text
        block.colored_words = new_block.colored_words
        block.lines = new_block.lines
        block.line_heights = new_block.line_heights
        block.width = new_block.width
        block.height = new_block.height
        block.area_used = new_block.area_used
        block.area_remaining = new_block.area_remaining

    # 重新计算图片尺寸
    text_layout = layout_engine.compute_text_layout(block, align=style.alignment)
    block.image_width = text_layout.image_width
    block.image_height = text_layout.image_height

    return block


def get_overlapping_total_duration(frames: List[OverlappingFrameSubtitle]) -> float:
    """计算重叠字幕帧的总时长"""
    if not frames:
        return 0.0
    return frames[-1].frame_end_time


def export_overlapping_to_srt(
    frames: List[OverlappingFrameSubtitle], output_path: str
) -> None:
    """将重叠字幕帧导出为SRT字幕文件"""

    def format_time(seconds: float) -> str:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        millis = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

    with open(output_path, "w", encoding="utf-8") as f:
        seq = 1
        for frame in frames:
            for timing in frame.block_timings:
                f.write(f"{seq}\n")
                f.write(
                    f"{format_time(timing.start_time)} --> {format_time(timing.end_time)}\n"
                )
                f.write(f"{timing.block.plain_text}\n")
                f.write("\n")
                seq += 1


def text_to_long_image(
    html_text: str,
    font_spec: FontSpec,
    constraint: RenderConstraint,
    output_path: str,
    *,
    split_config: Optional[SplitConfig] = None,
    style: Optional[RenderStyle] = None,
    base_font_size: int = 18,
) -> ColoredSubtitleBlock:
    """从HTML文本生成滚屏长图

    Args:
        html_text: HTML格式的文本内容
        font_spec: 字体配置
        constraint: 渲染约束 (仅使用 max_width)
        output_path: 输出PNG图片路径

        split_config: 分割配置
        style: 渲染样式配置
        base_font_size: HTML字号基准

    Returns:
        ColoredSubtitleBlock: 生成的字幕块数据
    """
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    if split_config is None:
        split_config = SplitConfig()
    if style is None:
        style = RenderStyle()

    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)

    # 分割HTML为段落
    paragraphs = split_html_paragraphs(html_text, combine=True)

    # Layout: 计算有效宽度约束
    extra_width = (style.padding[0] * 2) + (style.mask_offset[0] * 2)
    unlimited_constraint = RenderConstraint(
        max_width=max(1, constraint.max_width - extra_width), max_height=0
    )

    paragraph = paragraphs[0] if paragraphs else ""
    if not paragraph.strip():
        raise ValueError("输入文本为空")

    blocks = split_html_to_colored_blocks(
        html_paragraph=paragraph,
        measurer=measurer,
        constraint=unlimited_constraint,
        config=split_config,
        base_font_size=base_font_size,
    )

    if not blocks:
        raise ValueError("无法生成字幕块")

    block = blocks[0]

    # Layout + Render
    layout_constraint = RenderConstraint(max_width=constraint.max_width, max_height=0)
    layout_engine = LayoutEngine(layout_constraint, style, measurer)
    text_layout = layout_engine.compute_text_layout(block, align=style.alignment)

    renderer = ImageRenderer(measurer, style)
    w, h = renderer.render_block_to_file(block, text_layout, output_path)
    block.image_width, block.image_height = w, h

    return block


def render_text_image(
    html_text: str,
    font_spec: FontSpec,
    constraint: RenderConstraint,
    output_path: str,
    *,
    adjust: str = "WIDTH",
    vertical_align: str = "top",
    split_config: Optional[SplitConfig] = None,
    style: Optional[RenderStyle] = None,
    base_font_size: int = 18,
) -> ColoredSubtitleBlock:
    """根据HTML文本内容、FontSpec、RenderStyle绘制文本图片

    支持三种 adjust 模式:
    - WIDTH: 固定宽度，高度自适应
    - HEIGHT_EXTEND: 固定高度绘制，宽度可增加到上限；仍放不下则延伸高度
    - ADAPT: 固定区域内绘制，超出则二分缩小字号→缩小行距→截断
    """
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    adjust = AdjustMode(adjust)

    if split_config is None:
        split_config = SplitConfig()
    if style is None:
        style = RenderStyle()

    # 计算样式占用的额外尺寸
    extra_width = (style.padding[0] * 2) + (style.mask_offset[0] * 2)
    extra_height = (
        (style.padding[1] * 2) + (style.mask_offset[1] * 2) + (style.stroke_size * 2)
    )

    content_max_width = max(1, constraint.max_width - extra_width)
    content_max_height = (
        0
        if constraint.max_height == 0
        else max(1, constraint.max_height - extra_height)
    )

    # 分割HTML为段落
    paragraphs = split_html_paragraphs(html_text, combine=True)
    paragraph = paragraphs[0] if paragraphs else ""
    if not paragraph.strip():
        raise ValueError("输入文本为空")

    if adjust == AdjustMode.WIDTH:
        block = _render_width_mode(
            paragraph,
            font_spec,
            content_max_width,
            split_config,
            style,
            base_font_size,
        )
    elif adjust == AdjustMode.HEIGHT_EXTEND:
        block = _render_height_extend_mode(
            paragraph,
            font_spec,
            content_max_width,
            content_max_height,
            constraint.min_width,
            extra_width,
            split_config,
            style,
            base_font_size,
        )
    elif adjust == AdjustMode.ADAPT:
        block = _render_adapt_mode(
            paragraph,
            font_spec,
            content_max_width,
            content_max_height,
            split_config,
            style,
            base_font_size,
        )
    else:
        raise ValueError(f"不支持的 adjust 模式: {adjust}")

    # 计算目标尺寸
    target_height = constraint.max_height if adjust != AdjustMode.WIDTH else 0
    target_width = constraint.max_width if adjust == AdjustMode.WIDTH else 0

    # Layout + Render
    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    layout_engine = LayoutEngine(constraint, style, measurer)
    text_layout = layout_engine.compute_text_layout(
        block,
        align=style.alignment,
        vertical_align=vertical_align,
        target_width=target_width,
        target_height=target_height,
    )

    renderer = ImageRenderer(measurer, style)
    w, h = renderer.render_block_to_file(block, text_layout, output_path)
    block.image_width, block.image_height = w, h

    return block


def _render_width_mode(
    paragraph: str,
    font_spec: FontSpec,
    content_max_width: int,
    split_config: SplitConfig,
    style: RenderStyle,
    base_font_size: int,
) -> ColoredSubtitleBlock:
    """WIDTH 模式: 固定宽度，高度不限制"""
    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    unlimited_constraint = RenderConstraint(max_width=content_max_width, max_height=0)

    blocks = split_html_to_colored_blocks(
        html_paragraph=paragraph,
        measurer=measurer,
        constraint=unlimited_constraint,
        config=split_config,
        base_font_size=base_font_size,
    )

    if not blocks:
        raise ValueError("无法生成字幕块")

    return blocks[0]


def _render_height_extend_mode(
    paragraph: str,
    font_spec: FontSpec,
    content_max_width: int,
    content_max_height: int,
    min_width: int,
    extra_width: int,
    split_config: SplitConfig,
    style: RenderStyle,
    base_font_size: int,
) -> ColoredSubtitleBlock:
    """HEIGHT_EXTEND 模式"""
    if content_max_height <= 0:
        return _render_width_mode(
            paragraph,
            font_spec,
            content_max_width,
            split_config,
            style,
            base_font_size,
        )

    if min_width > 0:
        start_width = max(1, min_width - extra_width)
    else:
        start_width = max(1, content_max_width // 2)

    start_width = min(start_width, content_max_width)
    width_step = 20

    current_width = start_width
    while current_width <= content_max_width:
        measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
        trial_constraint = RenderConstraint(
            max_width=current_width, max_height=content_max_height
        )

        blocks = split_html_to_colored_blocks(
            html_paragraph=paragraph,
            measurer=measurer,
            constraint=trial_constraint,
            config=split_config,
            base_font_size=base_font_size,
        )

        if blocks and len(blocks) == 1:
            return blocks[0]

        current_width += width_step

    measurer = TextMeasurer(font_spec, stroke_size=style.stroke_size)
    unlimited_constraint = RenderConstraint(max_width=content_max_width, max_height=0)

    blocks = split_html_to_colored_blocks(
        html_paragraph=paragraph,
        measurer=measurer,
        constraint=unlimited_constraint,
        config=split_config,
        base_font_size=base_font_size,
    )

    if not blocks:
        raise ValueError("无法生成字幕块")

    return blocks[0]


def _render_adapt_mode(
    paragraph: str,
    font_spec: FontSpec,
    content_max_width: int,
    content_max_height: int,
    split_config: SplitConfig,
    style: RenderStyle,
    base_font_size: int,
) -> ColoredSubtitleBlock:
    """ADAPT 模式（三级降级）"""
    if content_max_height <= 0:
        return _render_width_mode(
            paragraph,
            font_spec,
            content_max_width,
            split_config,
            style,
            base_font_size,
        )

    original_font_size = font_spec.font_size
    original_line_spacing = font_spec.line_spacing
    min_font_size = 16

    def try_fit(trial_font_size: int, trial_line_spacing: int) -> bool:
        trial_font = FontSpec(
            font_path=font_spec.font_path,
            font_size=trial_font_size,
            line_spacing=trial_line_spacing,
        )
        measurer = TextMeasurer(trial_font, stroke_size=style.stroke_size)
        trial_constraint = RenderConstraint(
            max_width=content_max_width, max_height=content_max_height
        )
        blocks = split_html_to_colored_blocks(
            html_paragraph=paragraph,
            measurer=measurer,
            constraint=trial_constraint,
            config=split_config,
            base_font_size=base_font_size,
        )
        return blocks is not None and len(blocks) == 1

    def get_block(
        trial_font_size: int, trial_line_spacing: int
    ) -> ColoredSubtitleBlock:
        trial_font = FontSpec(
            font_path=font_spec.font_path,
            font_size=trial_font_size,
            line_spacing=trial_line_spacing,
        )
        measurer = TextMeasurer(trial_font, stroke_size=style.stroke_size)
        trial_constraint = RenderConstraint(
            max_width=content_max_width, max_height=content_max_height
        )
        blocks = split_html_to_colored_blocks(
            html_paragraph=paragraph,
            measurer=measurer,
            constraint=trial_constraint,
            config=split_config,
            base_font_size=base_font_size,
        )
        return blocks[0] if blocks else None

    if try_fit(original_font_size, original_line_spacing):
        font_spec.font_size = original_font_size
        font_spec.line_spacing = original_line_spacing
        return get_block(original_font_size, original_line_spacing)

    lo, hi = min_font_size, original_font_size - 1
    best_font_size = None

    while lo <= hi:
        mid = (lo + hi) // 2
        if try_fit(mid, original_line_spacing):
            best_font_size = mid
            lo = mid + 1
        else:
            hi = mid - 1

    if best_font_size is not None:
        font_spec.font_size = best_font_size
        font_spec.line_spacing = original_line_spacing
        return get_block(best_font_size, original_line_spacing)

    current_line_spacing = original_line_spacing
    min_line_spacing = min(-4, original_line_spacing - 8)

    while current_line_spacing >= min_line_spacing:
        current_line_spacing -= 1
        if try_fit(min_font_size, current_line_spacing):
            font_spec.font_size = min_font_size
            font_spec.line_spacing = current_line_spacing
            return get_block(min_font_size, current_line_spacing)

    font_spec.font_size = min_font_size
    font_spec.line_spacing = min_line_spacing
    truncated_block = get_block(min_font_size, min_line_spacing)
    if truncated_block:
        return truncated_block

    raise ValueError("无法在指定区域内绘制文本")
