"""Layout layer for text block rendering.

负责：
- 坐标计算
- 对齐方式
- 安全区域
- 自动排布

Layout 层不渲染任何像素，只输出数据结构描述"每个元素放在哪里、多大"。
"""

from typing import List, Optional, Tuple

from .models import (
    ColoredSubtitleBlock,
    RenderConstraint,
    RenderStyle,
    SafeArea,
    BlockPlacement,
    FrameLayout,
    TextLayout,
)
from .splitter import TextMeasurer


class LayoutEngine:
    """布局引擎

    负责安全区域计算、有效约束推导、单 block 文本布局、空间判断等。
    """

    def __init__(
        self,
        constraint: RenderConstraint,
        style: RenderStyle,
        measurer: TextMeasurer,
    ):
        self.constraint = constraint
        self.style = style
        self.measurer = measurer

    def compute_safe_area(self) -> SafeArea:
        """根据 constraint + style 计算有效的内容安全区域

        扣除 padding、mask_offset、stroke_size 后的区域。
        确保 content + 2*(padding + mask_offset + stroke_size) <= constraint 尺寸。
        """
        extra_width = (self.style.padding[0] * 2) + (self.style.mask_offset[0] * 2)
        extra_height = (
            (self.style.padding[1] * 2)
            + (self.style.mask_offset[1] * 2)
            + (self.style.stroke_size * 2)
        )

        safe_width = max(1, self.constraint.max_width - extra_width)
        safe_height = (
            0
            if self.constraint.max_height == 0
            else max(1, self.constraint.max_height - extra_height)
        )

        return SafeArea(
            x=self.style.padding[0] + self.style.mask_offset[0],
            y=self.style.padding[1] + self.style.mask_offset[1],
            width=safe_width,
            height=safe_height,
        )

    def compute_effective_constraint(self) -> RenderConstraint:
        """计算扣除样式边距后的有效约束

        替代原 pipeline.py 中分散的 effective_constraint 计算。
        """
        safe_area = self.compute_safe_area()
        return RenderConstraint(
            max_width=safe_area.width,
            max_height=safe_area.height,
        )

    def compute_text_layout(
        self,
        block: ColoredSubtitleBlock,
        align: str = "center",
        vertical_align: str = "top",
        target_width: int = 0,
        target_height: int = 0,
    ) -> TextLayout:
        """计算单个 block 的内部文本布局

        从 renderer.py 中抽取坐标计算逻辑。
        输出 TextLayout 供 Render 层使用。

        Args:
            block: 字幕块数据
            align: 水平对齐 - "left", "center", "right"
            vertical_align: 垂直对齐 - "top", "middle", "bottom"
            target_width: 目标图片宽度，0 = 自适应
            target_height: 目标图片高度，0 = 自适应
        """
        padding_x, padding_y = self.style.padding
        mask_offset_x, mask_offset_y = self.style.mask_offset
        stroke_size = self.style.stroke_size
        default_font_size = self.measurer.font_spec.font_size

        # RTL 模式强制右对齐
        effective_align = align
        if block.rtl_mode:
            effective_align = "right"

        # 计算图片尺寸
        mask_content_width = block.width + mask_offset_x * 2
        mask_content_height = block.height + mask_offset_y * 2 + stroke_size * 2
        img_width = mask_content_width + padding_x * 2
        img_height = mask_content_height + padding_y * 2

        if target_width > 0 and target_width > img_width:
            img_width = target_width
        if target_height > 0 and target_height > img_height:
            img_height = target_height

        # 计算每行的 metrics
        line_metrics = []
        total_text_height = 0

        for line in block.lines:
            max_ascent = 0
            max_descent = 0

            if not line:
                a, d = self.measurer.get_metrics(default_font_size)
                max_ascent = a
                max_descent = d
            else:
                for cword in line:
                    font_size = cword.font_size or default_font_size
                    ascent, descent = self.measurer.get_metrics(font_size, cword.word)
                    max_ascent = max(max_ascent, ascent)
                    max_descent = max(max_descent, descent)

            current_height = max_ascent + max_descent
            line_metrics.append((max_ascent, max_descent, current_height))
            total_text_height += current_height

        if len(line_metrics) > 1:
            total_text_height += (len(line_metrics) - 1) * self.measurer.line_spacing

        total_offset_y = padding_y + mask_offset_y + stroke_size

        # 计算垂直对齐偏移
        content_area_height = img_height - total_offset_y * 2
        if vertical_align == "middle":
            base_y = total_offset_y + (content_area_height - total_text_height) // 2
        elif vertical_align == "bottom":
            base_y = total_offset_y + (content_area_height - total_text_height)
        else:  # top (default)
            base_y = total_offset_y

        # 计算每行的位置
        line_positions = []
        temp_y = base_y

        for line_idx, line in enumerate(block.lines):
            ascent, descent, height = line_metrics[line_idx]

            line_width = 0
            for i, cword in enumerate(line):
                word_width = self.measurer.measure_word(cword.word, cword.font_size)
                line_width += word_width
                if i < len(line) - 1:
                    space_width = self.measurer.measure_word(" ", cword.font_size)
                    line_width += space_width

            total_offset_x = padding_x + mask_offset_x
            content_area_width = img_width - total_offset_x * 2
            if effective_align == "center":
                line_x = total_offset_x + (content_area_width - line_width) // 2
            elif effective_align == "right":
                line_x = total_offset_x + content_area_width - line_width
            else:  # left
                line_x = total_offset_x

            line_positions.append(
                {
                    "x": line_x,
                    "y": temp_y,
                    "width": line_width,
                    "height": height,
                    "ascent": ascent,
                }
            )

            temp_y += height + self.measurer.line_spacing

        return TextLayout(
            line_positions=line_positions,
            content_width=block.width,
            content_height=total_text_height,
            image_width=img_width,
            image_height=img_height,
        )

    def can_fit_block(
        self,
        current_blocks: List[ColoredSubtitleBlock],
        next_block: ColoredSubtitleBlock,
        max_height: int,
        spacing: int = 10,
    ) -> bool:
        """判断是否可以在当前帧中添加下一个字幕块

        原 timing.py 的 can_fit_next_block() 移至此处。
        这是布局层的职责——基于空间尺寸做判断。

        Args:
            current_blocks: 当前帧已包含的字幕块列表
            next_block: 待添加的字幕块
            max_height: 最大高度限制
            spacing: 字幕块之间的间距（像素）

        Returns:
            bool: 是否可以添加
        """
        if max_height == 0:
            return True

        if not current_blocks:
            return next_block.image_height <= max_height

        current_height = sum(b.image_height for b in current_blocks) + spacing * (
            len(current_blocks) - 1
        )
        needed_height = current_height + spacing + next_block.image_height

        return needed_height <= max_height


class AutoArrange:
    """自动排布器 - 计算多个 block 在一帧中的坐标"""

    def __init__(self, layout_engine: LayoutEngine):
        self.engine = layout_engine

    def arrange_vertical(
        self,
        blocks: List[ColoredSubtitleBlock],
        spacing: int = 10,
        align: str = "center",
        max_height: int = 0,
    ) -> FrameLayout:
        """垂直方向自动排布多个 block

        用于重叠字幕帧的坐标计算。
        当总高度超出 max_height 时，自动计算缩放因子。

        Args:
            blocks: 待排布的字幕块列表
            spacing: 块之间的垂直间距
            align: 水平对齐方式
            max_height: 最大高度限制，超出则缩放。0 = 不缩放
        """
        if not blocks:
            return FrameLayout(placements=[], total_width=0, total_height=0)

        raw_total_height = sum(b.image_height for b in blocks) + spacing * (
            len(blocks) - 1
        )
        raw_max_width = max(b.image_width for b in blocks)

        # 计算缩放因子
        scale = 1.0
        if max_height > 0 and raw_total_height > max_height:
            scale = max_height / raw_total_height

        placements = []
        current_y = 0

        for i, block in enumerate(blocks):
            scaled_w = int(block.image_width * scale)
            scaled_h = int(block.image_height * scale)
            scaled_max_w = int(raw_max_width * scale)

            if align == "center":
                x = (scaled_max_w - scaled_w) // 2
            elif align == "right":
                x = scaled_max_w - scaled_w
            else:
                x = 0

            placements.append(
                BlockPlacement(
                    block_index=i,
                    x=x,
                    y=current_y,
                    width=scaled_w,
                    height=scaled_h,
                )
            )
            current_y += scaled_h + int(spacing * scale)

        final_width = int(raw_max_width * scale)
        final_height = int(raw_total_height * scale)
        if max_height > 0 and final_height > max_height:
            final_height = max_height

        return FrameLayout(
            placements=placements,
            total_width=final_width,
            total_height=final_height,
            scale=round(scale, 4),
        )
