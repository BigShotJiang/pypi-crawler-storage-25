"""Reading time calculation and timeline subtitle utilities.

基于手机屏幕英语字幕阅读研究的阅读速度常量和时间计算工具。
参考: 成人字幕阅读速度通常为 120-180 WPM
默认值根据语言自动调整。
"""

from typing import List, Optional

from .models import (
    ColoredSubtitleBlock,
    FrameSubtitle,
    BlockTiming,
    OverlappingFrameSubtitle,
)
from .lang_constants import DEFAULT_WPM, WPM_MAP, get_wpm_for_language

# 阅读时间限制常量
MIN_DISPLAY_TIME = 2.0  # 最短显示时间(秒)，确保用户有时间注意到字幕
MAX_DISPLAY_TIME = 8.0  # 最长显示时间(秒)，避免单帧停留过久
SECONDS_PER_WORD = 60.0 / DEFAULT_WPM  # 约 0.4 秒/单词


def count_words(block: ColoredSubtitleBlock) -> int:
    """统计字幕块中的单词数量"""
    return len(block.colored_words)


def calculate_read_time(block: ColoredSubtitleBlock, wpm: float = DEFAULT_WPM) -> float:
    """
    计算字幕块的阅读时间

    基于手机屏幕上成年人阅读英语小说字幕的速度研究:
    - 舒适阅读速度: 120–150 WPM (无音频辅助)
    - 标准阅读速度: 160–180 WPM
    - SDH字幕推荐: 160 WPM

    Args:
        block: ColoredSubtitleBlock 字幕块
        wpm: 每分钟阅读单词数，默认150

    Returns:
        float: 阅读时间(秒)
    """
    word_count = count_words(block)

    # 计算基础阅读时间
    seconds_per_word = 60.0 / wpm
    base_time = word_count * seconds_per_word

    # 应用最小时间限制（无最大时间限制）
    read_time = max(MIN_DISPLAY_TIME, base_time)

    return round(read_time, 2)


def calculate_read_times(
    blocks: List[ColoredSubtitleBlock], wpm: float = DEFAULT_WPM
) -> List[float]:
    """
    批量计算多个字幕块的阅读时间

    Args:
        blocks: 字幕块列表
        wpm: 每分钟阅读单词数

    Returns:
        List[float]: 对应的阅读时间列表(秒)
    """
    return [calculate_read_time(block, wpm) for block in blocks]


def create_frame_subtitles(
    blocks: List[ColoredSubtitleBlock], save_paths: List[str], wpm: float = DEFAULT_WPM
) -> List[FrameSubtitle]:
    """
    创建时间轴字幕帧列表

    Args:
        blocks: 字幕块列表
        save_paths: 对应的PNG图片路径列表
        wpm: 阅读速度

    Returns:
        List[FrameSubtitle]: 带阅读时间的字幕帧列表
    """
    if len(blocks) != len(save_paths):
        raise ValueError(
            f"blocks数量({len(blocks)})与save_paths数量({len(save_paths)})不匹配"
        )

    return [
        FrameSubtitle(
            block=block,
            save_path=path,
            read_time=calculate_read_time(block, wpm),
            image_width=block.image_width,
            image_height=block.image_height,
        )
        for block, path in zip(blocks, save_paths)
    ]


def can_fit_next_block(
    current_blocks: List[ColoredSubtitleBlock],
    next_block: ColoredSubtitleBlock,
    max_height: int,
    spacing: int = 10,
) -> bool:
    """
    判断是否可以在当前帧中添加下一个字幕块

    Args:
        current_blocks: 当前帧已包含的字幕块列表
        next_block: 待添加的字幕块
        max_height: 最大高度限制
        spacing: 字幕块之间的间距（像素）

    Returns:
        bool: 是否可以添加
    """
    if max_height == 0:
        # 高度无限制
        return True

    if not current_blocks:
        return next_block.image_height <= max_height

    # 计算当前已占用高度（包含间距），使用图片尺寸而非文字尺寸
    current_height = sum(b.image_height for b in current_blocks) + spacing * (
        len(current_blocks) - 1
    )
    # 计算添加下一个块后所需高度
    needed_height = current_height + spacing + next_block.image_height

    return needed_height <= max_height


def create_overlapping_frame_subtitles(
    blocks: List[ColoredSubtitleBlock],
    save_paths: List[str],
    max_height: int,
    wpm: float = DEFAULT_WPM,
    spacing: int = 10,
    max_blocks_per_frame: int = 0,
) -> List[OverlappingFrameSubtitle]:
    """
    创建支持重叠的时间轴字幕帧列表

    策略：
    1. 计算每个字幕块的阅读时间
    2. 尝试将多个字幕块合并到同一帧（如果空间允许且未超过最大块数）
    3. 合并帧中每个块保持原始开始时间，共享相同的结束时间
    4. 总时长保持不变

    Args:
        blocks: 字幕块列表
        save_paths: 对应的PNG图片路径列表
        max_height: 最大高度限制（用于判断是否可合并）
        wpm: 阅读速度
        spacing: 字幕块之间的间距（像素）
        max_blocks_per_frame: 每帧最多可展示的 block 数量，0 表示无限制

    Returns:
        List[OverlappingFrameSubtitle]: 支持重叠的字幕帧列表
    """
    if len(blocks) != len(save_paths):
        raise ValueError(
            f"blocks数量({len(blocks)})与save_paths数量({len(save_paths)})不匹配"
        )

    if not blocks:
        return []

    # 计算每个块的阅读时间
    read_times = calculate_read_times(blocks, wpm)

    # 计算每个块的原始开始和结束时间
    block_times: List[tuple] = []  # (start_time, end_time, read_time)
    current_time = 0.0
    for read_time in read_times:
        start_time = current_time
        end_time = current_time + read_time
        block_times.append((start_time, end_time, read_time))
        current_time = end_time

    # 创建重叠帧
    result: List[OverlappingFrameSubtitle] = []
    cursor = 0

    while cursor < len(blocks):
        # 当前帧的块列表
        frame_blocks: List[ColoredSubtitleBlock] = [blocks[cursor]]
        frame_paths: List[str] = [save_paths[cursor]]
        frame_indices: List[int] = [cursor]

        # 尝试合并后续块
        next_idx = cursor + 1
        while next_idx < len(blocks):
            # 检查是否已达到每帧最大块数限制
            if max_blocks_per_frame > 0 and len(frame_blocks) >= max_blocks_per_frame:
                break
            if can_fit_next_block(frame_blocks, blocks[next_idx], max_height, spacing):
                frame_blocks.append(blocks[next_idx])
                frame_paths.append(save_paths[next_idx])
                frame_indices.append(next_idx)
                next_idx += 1
            else:
                break

        # 计算帧的统一结束时间（最后一个块的结束时间）
        last_idx = frame_indices[-1]
        frame_end_time = block_times[last_idx][1]

        # 创建 BlockTiming 列表
        block_timings = [
            BlockTiming(
                block=blocks[idx],
                save_path=save_paths[idx],
                start_time=round(block_times[idx][0], 2),
                end_time=round(frame_end_time, 2),
                image_width=blocks[idx].image_width,
                image_height=blocks[idx].image_height,
            )
            for idx in frame_indices
        ]

        result.append(
            OverlappingFrameSubtitle(
                block_timings=block_timings,
                frame_end_time=round(frame_end_time, 2),
            )
        )

        cursor = next_idx

    return result
