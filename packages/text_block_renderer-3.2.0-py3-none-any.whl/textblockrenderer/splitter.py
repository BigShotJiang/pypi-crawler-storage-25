"""Text splitting utilities for breaking text into blocks that fit within constraints."""

from typing import List, Optional, Tuple
from PIL import Image, ImageDraw, ImageFont
import emoji
import re

from .models import (
    FontSpec,
    RenderConstraint,
    SubtitleBlock,
    ColoredSubtitleBlock,
    ColoredWord,
    SplitConfig,
)
from .htmlparser import parse_html_text
from .lang_constants import (
    CONJUNCTIONS_MAP,
    EN_CONJUNCTIONS,
    DEFAULT_SENTENCE_END,
    DEFAULT_COMMA_END,
    SENTENCE_END_MAP,
    COMMA_END_MAP,
    RTL_LANGUAGES,
)
from .rtl_processor import (
    is_rtl_language,
    is_rtl_text,
    process_rtl_word,
    batch_process_rtl_words,
    RTL_AVAILABLE,
)


class TextMeasurer:
    """文本测量器，支持多字号和增量式测量"""

    def __init__(self, font_spec: FontSpec, stroke_size: int = 0):
        self.font_spec = font_spec
        self.font = ImageFont.truetype(font_spec.font_path, font_spec.font_size)
        self.emoji_font = ImageFont.truetype("seguiemj.ttf", font_spec.font_size)
        self.stroke_size = stroke_size  # 描边尺寸，影响文本测量

        self._font_cache: dict[int, ImageFont.FreeTypeFont] = {
            font_spec.font_size: self.font
        }
        self._emoji_font_cache: dict[int, ImageFont.FreeTypeFont] = {
            font_spec.font_size: self.emoji_font
        }

        # dummy image for measurement
        self.image = Image.new("RGB", (10, 10))
        self.draw = ImageDraw.Draw(self.image)

        # 验证并限制 line_spacing，防止文字重叠
        # 获取默认字号的 ascent 和 descent
        ascent, descent = self.font.getmetrics()

        # line_spacing 的有效范围：
        # - 最小值：-descent（确保上一行的 descent 不会与下一行的 ascent 重叠）
        # - 没有最大值限制
        min_line_spacing = -descent

        if font_spec.line_spacing < min_line_spacing:
            print(
                f"警告: line_spacing={font_spec.line_spacing} 超过临界值 {min_line_spacing}，"
                f"已强制设置为 {min_line_spacing} 以防止文字重叠"
            )
            self.line_spacing = min_line_spacing
        else:
            self.line_spacing = font_spec.line_spacing

        # 增量测量状态
        self._inc_max_width = 0
        self._inc_lines: List[List[ColoredWord]] = []
        self._inc_line_heights: List[int] = []
        self._inc_current_line: List[ColoredWord] = []
        self._inc_current_width = 0
        self._inc_current_max_ascent = 0
        self._inc_current_max_descent = 0
        self._inc_max_line_width = 0
        self._inc_total_height = 0

    @staticmethod
    def has_emoji(text: str) -> bool:
        return emoji.emoji_count(text) > 0

    @staticmethod
    def split_text_runs(text: str) -> List[Tuple[str, bool]]:
        matches = emoji.emoji_list(text)
        if not matches:
            return [(text, False)] if text else []

        runs: List[Tuple[str, bool]] = []
        offset = 0
        for match in matches:
            start = match["match_start"]
            end = match["match_end"]
            if start > offset:
                runs.append((text[offset:start], False))
            runs.append((text[start:end], True))
            offset = end
        if offset < len(text):
            runs.append((text[offset:], False))
        return runs

    def get_font(
        self, size: Optional[int] = None, text: Optional[str] = None
    ) -> ImageFont.FreeTypeFont:
        """获取指定字号的字体对象"""
        runs = self.split_text_runs(text) if text is not None else []
        if len(runs) == 1 and runs[0][1]:
            return self.get_emoji_font(size)
        if size is None:
            return self.font
        if size not in self._font_cache:
            self._font_cache[size] = ImageFont.truetype(self.font_spec.font_path, size)
        return self._font_cache[size]

    def get_emoji_font(self, size: Optional[int] = None) -> ImageFont.FreeTypeFont:
        if size is None:
            return self.emoji_font
        if size not in self._emoji_font_cache:
            self._emoji_font_cache[size] = ImageFont.truetype("seguiemj.ttf", size)
        return self._emoji_font_cache[size]

    def get_font_for_run(
        self, size: Optional[int] = None, is_emoji: bool = False
    ) -> ImageFont.FreeTypeFont:
        if is_emoji:
            return self.get_emoji_font(size)
        return self.get_font(size)

    def measure_text_run(
        self, text: str, font_size: Optional[int] = None, is_emoji: bool = False
    ) -> int:
        font = self.get_font_for_run(font_size, is_emoji)
        bbox = self.draw.textbbox((0, 0), text, font=font)
        width = bbox[2] - bbox[0]
        if not text.strip() or is_emoji:
            return width
        return width + (2 * self.stroke_size)

    def measure_word(self, word: str, font_size: Optional[int] = None) -> int:
        """测量单词宽度，包含描边扩展"""
        return sum(
            self.measure_text_run(text, font_size, is_emoji)
            for text, is_emoji in self.split_text_runs(word)
        )

    def get_metrics(
        self, font_size: Optional[int] = None, text: Optional[str] = None
    ) -> Tuple[int, int]:
        if text is None:
            font = self.get_font(font_size)
            return font.getmetrics()

        max_ascent = 0
        max_descent = 0
        for _, is_emoji in self.split_text_runs(text):
            font = self.get_font_for_run(font_size, is_emoji)
            ascent, descent = font.getmetrics()
            max_ascent = max(max_ascent, ascent)
            max_descent = max(max_descent, descent)
        return max_ascent, max_descent

    def measure_text(self, text: str, max_width: int):
        """单词级 wrap，不拆词"""
        words = text.split()
        lines: List[str] = []

        current_line: List[str] = []
        current_width = 0
        space_width = self.measure_word(" ")

        max_line_width = 0

        # 纯文本模式使用默认字号 metrics
        ascent, descent = self.get_metrics(self.font_spec.font_size)
        line_base_height = ascent + descent

        for word in words:
            word_width = self.measure_word(word)

            projected = (
                current_width + (space_width if current_line else 0) + word_width
            )

            if projected <= max_width:
                current_line.append(word)
                current_width = projected
            else:
                line_text = " ".join(current_line)
                lines.append(line_text)
                max_line_width = max(max_line_width, current_width)

                current_line = [word]
                current_width = word_width

        if current_line:
            line_text = " ".join(current_line)
            lines.append(line_text)
            max_line_width = max(max_line_width, current_width)

        # 高度计算
        if lines:
            total_height = line_base_height * len(lines) + self.line_spacing * (
                len(lines) - 1
            )
        else:
            total_height = 0

        return {
            "lines": lines,
            "width": max_line_width,
            "height": total_height,
        }

    def measure_colored_text(
        self, colored_words: List[ColoredWord], max_width: int
    ) -> dict:
        """对带颜色和字号的单词进行换行测量"""
        # 使用增量式测量实现，保证逻辑一致性
        self.reset_incremental(max_width)
        for word in colored_words:
            self.add_word(word)
        return self.finalize_incremental()

    # === 增量式测量方法 ===

    def reset_incremental(self, max_width: int):
        """重置增量测量状态"""
        # 每个单词已包含描边尺寸，这里不再统一扣除，直接使用 max_width
        self._inc_max_width = max_width
        self._inc_lines = []
        self._inc_line_heights = []
        self._inc_current_line = []
        self._inc_current_width = 0
        self._inc_current_max_ascent = 0
        self._inc_current_max_descent = 0
        self._inc_max_line_width = 0
        self._inc_total_height = 0

    def _finalize_current_line(self):
        """完成当前行，将其加入已完成列表"""
        if not self._inc_current_line:
            return

        self._inc_lines.append(self._inc_current_line)
        line_height = self._inc_current_max_ascent + self._inc_current_max_descent
        self._inc_line_heights.append(line_height)
        self._inc_max_line_width = max(
            self._inc_max_line_width, self._inc_current_width
        )

        # 更新总高度
        if len(self._inc_lines) == 1:
            self._inc_total_height = line_height
        else:
            self._inc_total_height += self.line_spacing + line_height

        # 重置当前行状态
        self._inc_current_line = []
        self._inc_current_width = 0
        self._inc_current_max_ascent = 0
        self._inc_current_max_descent = 0

    def add_word(self, colord_word: ColoredWord) -> int:
        """增量添加一个单词，返回添加后的总高度"""
        if not colord_word.word:
            # 空单词是换行标记
            self._finalize_current_line()
            # 添加一个空行的高度（使用默认字号）
            if colord_word.force_newline:
                ascent, descent = self.get_metrics(
                    colord_word.font_size or self.font_spec.font_size
                )
                line_height = ascent + descent
                self._inc_lines.append([])  # 添加空行
                self._inc_line_heights.append(line_height)
                if len(self._inc_lines) == 1:
                    self._inc_total_height = line_height
                else:
                    self._inc_total_height += self.line_spacing + line_height
            return self.get_current_height()

        word_font_size = colord_word.font_size or self.font_spec.font_size
        word_width = self.measure_word(colord_word.word, colord_word.font_size)
        space_width = self.measure_word(" ", colord_word.font_size)
        ascent, descent = self.get_metrics(word_font_size, colord_word.word)

        projected = (
            self._inc_current_width
            + (space_width if self._inc_current_line else 0)
            + word_width
        )

        if projected <= self._inc_max_width:
            self._inc_current_line.append(colord_word)
            self._inc_current_width = projected
            self._inc_current_max_ascent = max(self._inc_current_max_ascent, ascent)
            self._inc_current_max_descent = max(self._inc_current_max_descent, descent)
        else:
            # 换行
            self._finalize_current_line()

            self._inc_current_line = [colord_word]
            self._inc_current_width = word_width
            self._inc_current_max_ascent = ascent
            self._inc_current_max_descent = descent

        # 如果该单词后有强制换行符，立即完成当前行
        if colord_word.force_newline:
            self._finalize_current_line()

        return self.get_current_height()

    def get_current_height(self) -> int:
        """获取当前增量测量的总高度"""
        if not self._inc_current_line:
            return self._inc_total_height
        current_line_height = (
            self._inc_current_max_ascent + self._inc_current_max_descent
        )
        if self._inc_lines:
            return self._inc_total_height + self.line_spacing + current_line_height
        else:
            return current_line_height

    def finalize_incremental(self) -> dict:
        """完成增量测量，返回最终结果"""
        # 完成当前行
        self._finalize_current_line()

        return {
            "lines": self._inc_lines,
            "line_heights": self._inc_line_heights,
            "width": self._inc_max_line_width,
            "height": self._inc_total_height,
        }

    def get_snapshot(self) -> dict:
        """获取当前增量测量状态的快照"""
        lines = self._inc_lines.copy()
        line_heights = self._inc_line_heights.copy()
        max_width = self._inc_max_line_width
        height = self._inc_total_height

        if self._inc_current_line:
            lines.append(self._inc_current_line.copy())
            current_line_height = (
                self._inc_current_max_ascent + self._inc_current_max_descent
            )
            line_heights.append(current_line_height)
            max_width = max(max_width, self._inc_current_width)
            if len(lines) == 1:
                height = current_line_height
            else:
                height += self.line_spacing + current_line_height

        return {
            "lines": lines,
            "line_heights": line_heights,
            "width": max_width,
            "height": height,
        }


def find_semantic_break(
    words: List[str], start: int, end: int, min_words: int, language: str = "EN"
):
    """在 [start + min_words, end) 区间内向前找最佳语义断点"""
    candidates = []

    conjunctions = CONJUNCTIONS_MAP.get(language, EN_CONJUNCTIONS)

    # 获取语言特定的标点正则
    sentence_end_re = SENTENCE_END_MAP.get(language, DEFAULT_SENTENCE_END)
    comma_end_re = COMMA_END_MAP.get(language, DEFAULT_COMMA_END)

    for i in range(start + min_words, end + 1):
        w = words[i - 1].lower()

        if sentence_end_re.search(w):
            candidates.append((1, i))
        elif comma_end_re.search(w):
            candidates.append((2, i))
        elif w in conjunctions:
            candidates.append((3, i))

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[0], -x[1]))
    return candidates[0][1]


def split_paragraph_to_blocks(
    paragraph: str,
    measurer: TextMeasurer,
    constraint: RenderConstraint,
    config: SplitConfig,
) -> List[SubtitleBlock]:
    """将纯文本段落分割为字幕块"""

    words = paragraph.split()
    cursor = 0
    blocks: List[SubtitleBlock] = []

    unlimited_height = constraint.max_height == 0
    max_area = (
        constraint.max_width * constraint.max_height if not unlimited_height else 0
    )

    while cursor < len(words):
        candidate_end = cursor
        last_valid_end = None
        last_valid_measure = None

        # 贪心填充
        while candidate_end < len(words):
            text = " ".join(words[cursor : candidate_end + 1])
            measured = measurer.measure_text(text, constraint.max_width)

            if unlimited_height or measured["height"] <= constraint.max_height:
                last_valid_end = candidate_end + 1
                last_valid_measure = measured
                candidate_end += 1
            else:
                break

        if last_valid_end is None:
            raise ValueError(f"Single word cannot fit screen: {words[cursor]}")

        # 语义回退
        semantic_end = find_semantic_break(
            words, cursor, last_valid_end, config.min_words_per_block, config.language
        )

        final_end = semantic_end or last_valid_end

        # 最低词数回退
        if final_end - cursor < config.min_words_per_block:
            final_end = min(cursor + config.min_words_per_block, last_valid_end)

        text = " ".join(words[cursor:final_end])
        measured = measurer.measure_text(text, constraint.max_width)

        area_used = measured["width"] * measured["height"]

        block = SubtitleBlock(
            text=text,
            lines=measured["lines"],
            width=measured["width"],
            height=measured["height"],
            area_used=area_used,
            area_remaining=max_area - area_used,
        )

        blocks.append(block)
        cursor = final_end

    return blocks


def find_colored_semantic_break(
    colored_words: List[ColoredWord],
    start: int,
    end: int,
    min_words: int,
    language: str = "EN",
) -> Optional[int]:
    """在带颜色的单词列表中寻找语义断点"""
    candidates = []

    conjunctions = CONJUNCTIONS_MAP.get(language, EN_CONJUNCTIONS)
    sentence_end_re = SENTENCE_END_MAP.get(language, DEFAULT_SENTENCE_END)
    comma_end_re = COMMA_END_MAP.get(language, DEFAULT_COMMA_END)

    # RTL 语言的连接词需要预处理以匹配已处理的单词文本
    if is_rtl_language(language) and RTL_AVAILABLE:
        conjunctions = {process_rtl_word(c) for c in conjunctions}

    for i in range(start + min_words, end + 1):
        w = colored_words[i - 1].word.lower()

        if sentence_end_re.search(w):
            candidates.append((1, i))
        elif comma_end_re.search(w):
            candidates.append((2, i))
        elif w in conjunctions:
            candidates.append((3, i))

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x[0], -x[1]))
    return candidates[0][1]


def split_html_to_colored_blocks(
    html_paragraph: str,
    measurer: TextMeasurer,
    constraint: RenderConstraint,
    config: SplitConfig,
    base_font_size: int = 18,  # HTML 字号基准
) -> List[ColoredSubtitleBlock]:
    """
    将HTML格式的段落分割为带样式的字幕块（优化版本）

    使用增量式测量，时间复杂度 O(n)，每个单词只测量一次。

    Args:
        html_paragraph: HTML 格式的段落文本
        measurer: 文本测量器
        constraint: 渲染约束（最大宽高）
        config: 分割配置
        base_font_size: HTML 中的字号基准，用于计算相对字号比例
    """
    # 解析HTML获取带样式的单词列表，按比例缩放字号
    target_font_size = measurer.font_spec.font_size
    plain_text, colored_words = parse_html_text(
        html_paragraph, base_font_size, target_font_size
    )

    if not colored_words:
        return []

    # RTL 文本处理：批量处理所有单词（高效版本）
    rtl_mode = is_rtl_language(config.language)
    if rtl_mode and RTL_AVAILABLE:
        # 提取所有单词文本
        word_texts = [cw.word for cw in colored_words]
        # 批量处理
        processed_texts = batch_process_rtl_words(word_texts)
        # 更新回 colored_words
        for cw, processed in zip(colored_words, processed_texts):
            cw.word = processed

    unlimited_height = constraint.max_height == 0
    max_area = (
        constraint.max_width * constraint.max_height if not unlimited_height else 0
    )

    blocks: List[ColoredSubtitleBlock] = []
    cursor = 0

    while cursor < len(colored_words):
        measurer.reset_incremental(constraint.max_width)
        last_valid_end = None
        last_valid_snapshot = None

        # 贪心填充：逐词添加，每个单词只测量一次
        for i in range(cursor, len(colored_words)):
            word = colored_words[i]
            current_height = measurer.add_word(word)

            # 检查高度约束
            if unlimited_height or current_height <= constraint.max_height:
                last_valid_end = i + 1
                # 保存当前有效状态的快照（只在最后一次循环时使用）
                last_valid_snapshot = measurer.get_snapshot()
            else:
                break

        if last_valid_end is None:
            raise ValueError(
                f"Single word cannot fit screen: {colored_words[cursor].word}"
            )

        # 语义回退：仅在需要分屏时进行（即高度限制导致无法放下所有剩余内容）
        # 如果所有剩余单词都能放下（last_valid_end == len(colored_words)），无需语义回退
        needs_split = last_valid_end < len(colored_words)

        if unlimited_height or not needs_split:
            # 高度无限制 或 一屏能显示完，不进行语义分割
            final_end = last_valid_end
        else:
            # 需要分屏时，进行语义回退避免句子被切分
            semantic_end = find_colored_semantic_break(
                colored_words,
                cursor,
                last_valid_end,
                config.min_words_per_block,
                config.language,
            )
            final_end = semantic_end or last_valid_end

        # 最低词数回退
        if final_end - cursor < config.min_words_per_block:
            final_end = min(cursor + config.min_words_per_block, last_valid_end)

        # 获取最终测量结果
        if final_end == last_valid_end and last_valid_snapshot:
            # 使用保存的快照，无需重新测量
            measured = last_valid_snapshot
        else:
            # 经过语义回退，需要重新测量较短的范围
            slice_words = colored_words[cursor:final_end]
            measured = measurer.measure_colored_text(slice_words, constraint.max_width)

        slice_words = colored_words[cursor:final_end]
        area_used = measured["width"] * measured["height"]
        plain = " ".join(w.word for w in slice_words)

        block = ColoredSubtitleBlock(
            plain_text=plain,
            colored_words=slice_words,
            lines=measured["lines"],
            line_heights=measured.get("line_heights", []),
            width=measured["width"],
            height=measured["height"],
            area_used=area_used,
            area_remaining=max_area - area_used,
            rtl_mode=rtl_mode,
        )

        blocks.append(block)
        cursor = final_end

    return blocks
