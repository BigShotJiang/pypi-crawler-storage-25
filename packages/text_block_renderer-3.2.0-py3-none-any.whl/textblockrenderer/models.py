"""Shared data models for text block rendering."""

from enum import Enum
from typing import List, Optional, Tuple
from pydantic import BaseModel, Field, ConfigDict, computed_field
from dataclasses import dataclass


@dataclass
class ColoredSpan:
    """带颜色和字号的文本片段"""

    text: str
    color: Optional[str] = None
    font_size: Optional[int] = None  # 字号（像素）


@dataclass
class ColoredWord:
    """单个单词及其样式"""

    word: str
    color: Optional[str] = None
    font_size: Optional[int] = None  # 字号（像素），None 表示使用默认字号
    force_newline: bool = False  # 该单词后是否强制换行
    leading_space: bool = False  # 该单词前是否有前导空格（用于 HTML 还原）


class AdjustMode(str, Enum):
    """绘制调整模式

    Attributes:
        WIDTH: 固定宽度，高度自适应直到全部绘制
        HEIGHT_EXTEND: 固定高度绘制，宽度可增加到上限；仍放不下则延伸高度
        ADAPT: 固定区域内绘制，超出则缩小字号/行距，最终截断
    """

    WIDTH = "WIDTH"
    HEIGHT_EXTEND = "HEIGHT_EXTEND"
    ADAPT = "ADAPT"


class VerticalAlignment(str, Enum):
    """垂直对齐方式

    当内容高度小于图片高度时，文本在垂直方向的对齐方式。
    """

    TOP = "TOP"
    MIDDLE = "MIDDLE"
    BOTTOM = "BOTTOM"


class TrackMode(str, Enum):
    """帧内轨道时间模式

    控制单个帧内多个 block 的时间显示方式。

    Attributes:
        SEQUENTIAL: 每个轨道按照自己的时间轴依次显示（默认）
        SYNCHRONIZED: 所有轨道使用同一个开始时间和最长的结束时间，同时显示
    """

    SEQUENTIAL = "SEQUENTIAL"
    SYNCHRONIZED = "SYNCHRONIZED"


class FontSpec(BaseModel):
    """字体配置"""

    font_path: str
    font_size: int
    line_spacing: int = 4  # 额外行距


class RenderConstraint(BaseModel):
    """渲染约束

    Attributes:
        max_width: 最大宽度（像素）
        max_height: 最大高度（像素），绝对上限，超出则缩放。0 表示无限制
        preferred_height: 最佳显示区域高度（像素），帧合并判断用。0 表示使用 max_height
        min_width: 最小宽度（像素），用于 HEIGHT_EXTEND 模式的初始宽度，0 表示自动
    """

    max_width: int
    max_height: int = 0
    preferred_height: int = 0  # 0 = 退化为 max_height
    min_width: int = 0


class SubtitleBlock(BaseModel):
    """纯文本字幕块"""

    text: str
    lines: List[str]

    width: int
    height: int

    area_used: int
    area_remaining: int


class ColoredSubtitleBlock(BaseModel):
    """支持颜色和字号的字幕块"""

    plain_text: str  # 纯文本（去除HTML标签）
    colored_words: List[ColoredWord]  # 带样式的单词列表
    lines: List[List[ColoredWord]]  # 按行分组的带样式单词
    line_heights: List[int] = []  # 每行的高度（支持不同字号）
    width: int  # 文字内容宽度
    height: int  # 文字内容高度
    area_used: int
    area_remaining: int
    rtl_mode: bool = False  # 是否为 RTL（右到左）文本
    image_width: int = 0  # 渲染后图片宽度（包含边距）
    image_height: int = 0  # 渲染后图片高度（包含边距）

    @computed_field  # type: ignore[prop-decorator]
    @property
    def html_text(self) -> str:
        """将带样式的单词列表组合成 HTML 字符串"""
        from .pipeline import block_to_html

        return block_to_html(self.colored_words)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class SplitConfig(BaseModel):
    """分割配置"""

    min_words_per_block: int = Field(3, ge=1)
    language: str = "EN"


class RenderStyle(BaseModel):
    """渲染样式配置

    用于统一管理字幕图片的渲染参数。

    Attributes:
        text_color: 默认文本颜色 (十六进制格式)
        bg_color: 背景颜色, None表示透明背景
        alignment: 对齐方式 ("left", "center", "right")
        padding: 内边距 (水平, 垂直)
        mask_mode: 遮罩模式 (0=无遮罩, 1=多边形遮罩, 2=矩形遮罩)
        mask_color: 遮罩颜色 (R, G, B, A)
        mask_offset: 遮罩偏移量 (x, y)
        corner_radius: 背景圆角半径
        stroke_size: 描边尺寸 (像素), 0表示无描边
        stroke_color: 描边颜色 (R, G, B, A)
    """

    text_color: str | Tuple[int, int, int, int] = "#FFFFFF"
    bg_color: Optional[str | Tuple[int, int, int, int]] = None
    alignment: str = "center"
    padding: Tuple[int, int] = (10, 10)
    mask_mode: int = 0
    mask_color: str | Tuple[int, int, int, int] = (0, 0, 0, 180)
    mask_offset: Tuple[int, int] = (0, 0)
    corner_radius: int = 0
    stroke_size: int = 0
    stroke_color: str | Tuple[int, int, int, int] = (0, 0, 0, 255)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class FrameSubtitle(BaseModel):
    """时间轴字幕帧"""

    block: ColoredSubtitleBlock
    save_path: str  # PNG图片路径
    read_time: float  # 阅读时间(秒)

    image_width: int  # 图片宽度(像素)
    image_height: int  # 图片高度(像素)

    model_config = ConfigDict(arbitrary_types_allowed=True)


@dataclass
class BlockTiming:
    """单个字幕块的时间信息

    在重叠帧中，每个字幕块有独立的开始时间，但共享相同的结束时间。
    """

    block: ColoredSubtitleBlock
    save_path: str
    start_time: float  # 该块的开始时间
    end_time: float  # 该块的结束时间（合并帧中所有块共享相同的 end_time）
    image_width: int = 0  # 图片宽度(像素)
    image_height: int = 0  # 图片高度(像素)


class OverlappingFrameSubtitle(BaseModel):
    """支持重叠的时间轴字幕帧

    允许多个字幕块在同一帧中同时显示，每个块有独立的开始时间，
    但共享相同的结束时间。布局/坐标由外部计算。
    """

    block_timings: List[BlockTiming]  # 该帧包含的多个字幕块及其时间信息
    frame_end_time: float  # 帧的统一结束时间

    @computed_field  # type: ignore[prop-decorator]
    @property
    def frame_start_time(self) -> float:
        """帧的最早开始时间（取所有 block 中最小的 start_time）"""
        if not self.block_timings:
            return 0.0
        return min(t.start_time for t in self.block_timings)

    model_config = ConfigDict(arbitrary_types_allowed=True)


# ========== 三层架构新增模型 ==========


@dataclass
class TrackSlot:
    """轨道上的一个时间槽位

    表示单个 block 在时间轴上的时间区间。
    """

    block_index: int  # 对应 blocks 列表中的索引
    start_time: float  # 开始时间(秒)
    end_time: float  # 结束时间(秒)
    track_id: int = 0  # 所属轨道编号


@dataclass
class TimelineFrame:
    """时间轴上的一帧（某个时间点的快照）

    描述在某个时间区间内同时显示的所有 slot。
    """

    slots: List[TrackSlot]  # 该帧同时显示的所有 slot
    frame_start: float  # 帧开始时间
    frame_end: float  # 帧结束时间


@dataclass
class SafeArea:
    """安全区域定义

    表示扣除 padding/mask_offset/stroke 后的有效内容区域。
    """

    x: int = 0  # 安全区域左上角 x
    y: int = 0  # 安全区域左上角 y
    width: int = 0  # 安全区域宽度
    height: int = 0  # 安全区域高度（0 = 无高度限制）


@dataclass
class BlockPlacement:
    """单个 block 的放置结果"""

    block_index: int  # 对应 blocks 列表索引
    x: int  # 放置的 x 坐标
    y: int  # 放置的 y 坐标
    width: int  # 占用宽度
    height: int  # 占用高度


@dataclass
class FrameLayout:
    """一帧的布局信息"""

    placements: List[BlockPlacement]
    total_width: int  # 帧总宽度
    total_height: int  # 帧总高度


@dataclass
class TextLayout:
    """单个 block 内部的文本布局

    由 Layout 层计算，传递给 Render 层使用。
    """

    line_positions: List[dict]  # 每行的 x, y, width, height, ascent
    content_width: int  # 文字内容宽度
    content_height: int  # 文字内容高度
    image_width: int  # 含 padding 的最终图片宽度
    image_height: int  # 含 padding 的最终图片高度


# ========== 三层架构新增模型 ==========


@dataclass
class TrackSlot:
    """轨道上的一个时间槽位

    表示单个 block 在时间轴上的时间区间。
    """

    block_index: int  # 对应 blocks 列表中的索引
    start_time: float  # 开始时间(秒)
    end_time: float  # 结束时间(秒)
    track_id: int = 0  # 所属轨道编号


@dataclass
class TimelineFrame:
    """时间轴上的一帧（某个时间点的快照）

    描述在某个时间区间内同时显示的所有 slot。
    """

    slots: List[TrackSlot]  # 该帧同时显示的所有 slot
    frame_start: float  # 帧开始时间
    frame_end: float  # 帧结束时间


@dataclass
class SafeArea:
    """安全区域定义

    表示扣除 padding/mask_offset/stroke 后的有效内容区域。
    """

    x: int = 0  # 安全区域左上角 x
    y: int = 0  # 安全区域左上角 y
    width: int = 0  # 安全区域宽度
    height: int = 0  # 安全区域高度（0 = 无高度限制）


@dataclass
class BlockPlacement:
    """单个 block 的放置结果"""

    block_index: int  # 对应 blocks 列表索引
    x: int  # 放置的 x 坐标
    y: int  # 放置的 y 坐标
    width: int  # 占用宽度
    height: int  # 占用高度


@dataclass
class FrameLayout:
    """一帧的布局信息"""

    placements: List[BlockPlacement]
    total_width: int  # 帧总宽度
    total_height: int  # 帧总高度
    scale: float = 1.0  # 缩放因子，< 1.0 表示需缩放 PNG


@dataclass
class TextLayout:
    """单个 block 内部的文本布局

    由 Layout 层计算，传递给 Render 层使用。
    """

    line_positions: List[dict]  # 每行的 x, y, width, height, ascent
    content_width: int  # 文字内容宽度
    content_height: int  # 文字内容高度
    image_width: int  # 含 padding 的最终图片宽度
    image_height: int  # 含 padding 的最终图片高度
