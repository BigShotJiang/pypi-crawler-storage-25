"""Timeline layer for text block rendering.

负责：
- 时间轴管理
- 轨道管理
- 阅读时间计算
- 帧组装与重叠控制

Timeline 层不关心像素坐标、图片尺寸、渲染样式。
它只关心"哪些 block 在什么时间出现/消失"。
"""

from typing import List, Optional, Tuple, Callable

from .models import (
    ColoredSubtitleBlock,
    FrameSubtitle,
    BlockTiming,
    OverlappingFrameSubtitle,
    TrackSlot,
    TimelineFrame,
)
from .lang_constants import DEFAULT_WPM, WPM_MAP, get_wpm_for_language

# 阅读时间限制常量
MIN_DISPLAY_TIME = 2.0  # 最短显示时间(秒)，确保用户有时间注意到字幕
MAX_DISPLAY_TIME = 8.0  # 最长显示时间(秒)，避免单帧停留过久
SECONDS_PER_WORD = 60.0 / DEFAULT_WPM  # 约 0.4 秒/单词


# ========== 新类架构 ==========


class TimeCalculator:
    """阅读时间计算器"""

    def __init__(self, wpm: float = DEFAULT_WPM):
        self.wpm = wpm

    def calculate_read_time(self, block: ColoredSubtitleBlock) -> float:
        """计算单个 block 的阅读时间

        Args:
            block: 字幕块

        Returns:
            float: 阅读时间(秒)
        """
        word_count = count_words(block)
        seconds_per_word = 60.0 / self.wpm
        base_time = word_count * seconds_per_word
        read_time = max(MIN_DISPLAY_TIME, base_time)
        return round(read_time, 2)

    def calculate_read_times(self, blocks: List[ColoredSubtitleBlock]) -> List[float]:
        """批量计算阅读时间

        Args:
            blocks: 字幕块列表

        Returns:
            List[float]: 对应的阅读时间列表(秒)
        """
        return [self.calculate_read_time(block) for block in blocks]


class TimelineTrack:
    """单轨道时间轴

    管理一组按顺序播放的字幕块的时间信息。
    """

    def __init__(self, read_times: List[float]):
        self.read_times = read_times

    def build_sequential_slots(self) -> List[TrackSlot]:
        """构建顺序播放的时间槽位

        Returns:
            List[TrackSlot]: 按时间顺序排列的槽位列表
        """
        slots = []
        current_time = 0.0
        for i, read_time in enumerate(self.read_times):
            start_time = current_time
            end_time = current_time + read_time
            slots.append(
                TrackSlot(
                    block_index=i,
                    start_time=round(start_time, 2),
                    end_time=round(end_time, 2),
                )
            )
            current_time = end_time
        return slots

    def get_timestamps(self) -> List[Tuple[float, float]]:
        """获取每个 block 的 (start, end) 时间戳

        Returns:
            List[Tuple[float, float]]: 时间戳列表
        """
        timestamps = []
        current_time = 0.0
        for read_time in self.read_times:
            start_time = current_time
            end_time = current_time + read_time
            timestamps.append((round(start_time, 2), round(end_time, 2)))
            current_time = end_time
        return timestamps

    def get_total_duration(self) -> float:
        """获取总时长

        Returns:
            float: 总时长(秒)
        """
        return round(sum(self.read_times), 2)


class FrameAssembler:
    """帧组装器 - 控制哪些 block 合并到同一帧

    通过 can_merge_fn 回调将空间判断委托给 Layout 层，
    Timeline 层只负责时间逻辑。
    """

    def __init__(
        self,
        can_merge_fn: Callable[[List[int], int], bool],
    ):
        """
        Args:
            can_merge_fn: 外部提供的合并判断函数
                         (当前帧的block索引列表, 候选block索引) -> 是否可合并
                         这个函数由 Layout 层提供，Timeline 层不关心判断细节
        """
        self.can_merge_fn = can_merge_fn

    def assemble_overlapping_frames(
        self,
        slots: List[TrackSlot],
        max_blocks_per_frame: int = 0,
    ) -> List[TimelineFrame]:
        """将顺序 slots 合并为重叠帧

        策略：
        1. 检查每帧最大块数限制
        2. 通过 can_merge_fn 回调判断空间是否允许合并
        3. 合并帧内所有 slot 共享相同的结束时间

        Args:
            slots: 按顺序排列的时间槽位列表
            max_blocks_per_frame: 每帧最多可展示的 block 数量，0 = 无限制

        Returns:
            List[TimelineFrame]: 合并后的帧列表
        """
        if not slots:
            return []

        result: List[TimelineFrame] = []
        cursor = 0

        while cursor < len(slots):
            frame_indices: List[int] = [slots[cursor].block_index]
            frame_slots: List[TrackSlot] = [slots[cursor]]

            next_idx = cursor + 1
            while next_idx < len(slots):
                if 0 < max_blocks_per_frame <= len(frame_indices):
                    break

                candidate_index = slots[next_idx].block_index
                if self.can_merge_fn(frame_indices, candidate_index):
                    frame_indices.append(candidate_index)
                    frame_slots.append(slots[next_idx])
                    next_idx += 1
                else:
                    break

            # 帧的结束时间为最后一个 slot 的结束时间
            frame_end = frame_slots[-1].end_time
            # 更新所有 slot 共享帧结束时间
            unified_slots = [
                TrackSlot(
                    block_index=s.block_index,
                    start_time=s.start_time,
                    end_time=frame_end,
                    track_id=s.track_id,
                )
                for s in frame_slots
            ]

            result.append(
                TimelineFrame(
                    slots=unified_slots,
                    frame_start=frame_slots[0].start_time,
                    frame_end=frame_end,
                )
            )

            cursor = next_idx

        return result


# ========== 兼容包装函数（保留原有 API） ==========


def count_words(block: ColoredSubtitleBlock) -> int:
    """统计字幕块中的单词数量"""
    return sum(1 for word in block.colored_words if word.word)


def calculate_read_time(block: ColoredSubtitleBlock, wpm: float = DEFAULT_WPM) -> float:
    """计算字幕块的阅读时间（兼容包装）

    内部委托给 TimeCalculator。
    """
    calc = TimeCalculator(wpm)
    return calc.calculate_read_time(block)


def calculate_read_times(
    blocks: List[ColoredSubtitleBlock], wpm: float = DEFAULT_WPM
) -> List[float]:
    """批量计算阅读时间（兼容包装）"""
    calc = TimeCalculator(wpm)
    return calc.calculate_read_times(blocks)


def create_frame_subtitles(
    blocks: List[ColoredSubtitleBlock],
    save_paths: List[str],
    wpm: float = DEFAULT_WPM,
) -> List[FrameSubtitle]:
    """创建时间轴字幕帧列表（兼容包装）"""
    if len(blocks) != len(save_paths):
        raise ValueError(
            f"blocks数量({len(blocks)})与save_paths数量({len(save_paths)})不匹配"
        )

    calc = TimeCalculator(wpm)
    read_times = calc.calculate_read_times(blocks)

    return [
        FrameSubtitle(
            block=block,
            save_path=path,
            read_time=read_time,
            image_width=block.image_width,
            image_height=block.image_height,
        )
        for block, path, read_time in zip(blocks, save_paths, read_times)
    ]


def can_fit_next_block(
    current_blocks: List[ColoredSubtitleBlock],
    next_block: ColoredSubtitleBlock,
    max_height: int,
    spacing: int = 10,
) -> bool:
    """判断是否可以在当前帧中添加下一个字幕块（兼容包装）

    注意：此函数保留以向后兼容。新代码应使用 layout.LayoutEngine.can_fit_block()。
    """
    if max_height == 0:
        return True

    if not current_blocks:
        return next_block.image_height <= max_height

    current_height = sum(b.image_height for b in current_blocks) + spacing * (
        len(current_blocks) - 1
    )
    needed_height = current_height + spacing + next_block.image_height

    return needed_height <= max_height


def create_overlapping_frame_subtitles(
    blocks: List[ColoredSubtitleBlock],
    save_paths: List[str],
    max_height: int,
    wpm: float = DEFAULT_WPM,
    spacing: int = 10,
    max_blocks_per_frame: int = 0,
    preferred_height: int = 0,
) -> List[OverlappingFrameSubtitle]:
    """创建支持重叠的时间轴字幕帧列表（兼容包装）

    内部使用新的 TimeCalculator, TimelineTrack, FrameAssembler 实现。

    Args:
        preferred_height: 帧合并高度阈值，0 = 使用 max_height
    """
    if len(blocks) != len(save_paths):
        raise ValueError(
            f"blocks数量({len(blocks)})与save_paths数量({len(save_paths)})不匹配"
        )

    if not blocks:
        return []

    # 帧合并用 preferred_height，不传则用 max_height
    merge_height = preferred_height if preferred_height > 0 else max_height

    # 使用新类架构
    calc = TimeCalculator(wpm)
    read_times = calc.calculate_read_times(blocks)
    track = TimelineTrack(read_times)
    slots = track.build_sequential_slots()

    # 空间判断回调（委托给布局逻辑）
    def can_merge(current_indices: List[int], next_index: int) -> bool:
        current_blocks_list = [blocks[i] for i in current_indices]
        return can_fit_next_block(
            current_blocks_list, blocks[next_index], merge_height, spacing
        )

    assembler = FrameAssembler(can_merge_fn=can_merge)
    frames = assembler.assemble_overlapping_frames(slots, max_blocks_per_frame)

    # 转换为 OverlappingFrameSubtitle（向后兼容）
    result: List[OverlappingFrameSubtitle] = []
    for frame in frames:
        block_timings = [
            BlockTiming(
                block=blocks[slot.block_index],
                save_path=save_paths[slot.block_index],
                start_time=slot.start_time,
                end_time=slot.end_time,
                image_width=blocks[slot.block_index].image_width,
                image_height=blocks[slot.block_index].image_height,
            )
            for slot in frame.slots
        ]

        result.append(
            OverlappingFrameSubtitle(
                block_timings=block_timings,
                frame_end_time=round(frame.frame_end, 2),
            )
        )

    return result
