"""Language constants for text splitting."""

import re

# 默认英语连词
EN_CONJUNCTIONS = {
    "and",
    "but",
    "or",
    "so",
    "because",
    "however",
    "although",
    "therefore",
    "if",
    "then",
    "else",
    "when",
    "while",
    "since",
    "until",
    "unless",
    "whether",
    "either",
    "neither",
    "nor",
    "yet",
    "for",
    "as",
}

# 默认标点正则
DEFAULT_SENTENCE_END = re.compile(r"[.!?]$")
DEFAULT_COMMA_END = re.compile(r",$")

# 希腊语问号是 ; (0x037E)
EL_SENTENCE_END = re.compile(r"[.!?\u037E]$")

# 语言特定的句子结束符正则
SENTENCE_END_MAP = {
    "EL": EL_SENTENCE_END,
}

# 语言特定的逗号正则
COMMA_END_MAP = {
    # 可以在这里添加特定语言的逗号正则，目前全使用默认
}

# RTL (Right-to-Left) 语言代码集合
RTL_LANGUAGES = {"AR", "HE", "FA", "UR"}

# 阿拉伯语标点正则 (Arabic punctuation)
# 注意：bidi 处理后标点可能在开头或结尾，所以需要匹配两种情况
AR_SENTENCE_END = re.compile(r"(^[.!?؟。]|[.!?؟。]$)")
AR_COMMA_END = re.compile(r"(^[,،、]|[,،、]$)")

# 希伯来语标点正则 (Hebrew punctuation)
# 注意：bidi 处理后标点可能在开头或结尾
HE_SENTENCE_END = re.compile(r"(^[.!?]|[.!?]$)")
HE_COMMA_END = re.compile(r"(^[,]|[,]$)")

# 更新语言特定的映射
SENTENCE_END_MAP["AR"] = AR_SENTENCE_END
SENTENCE_END_MAP["HE"] = HE_SENTENCE_END
COMMA_END_MAP["AR"] = AR_COMMA_END
COMMA_END_MAP["HE"] = HE_COMMA_END

# 多语言连词映射
CONJUNCTIONS_MAP = {
    "EN": EN_CONJUNCTIONS,
    "CS": {  # 捷克语
        "a",
        "ale",
        "nebo",
        "tak",
        "protože",
        "však",
        "ačkoli",
        "proto",
        "pokud",
        "pak",
        "jinak",
        "když",
        "zatímco",
        "od",
        "dokud",
        "zda",
        "buď",
        "ani",
        "přesto",
        "pro",
        "jako",
    },
    "PL": {  # 波兰语
        "i",
        "ale",
        "lub",
        "więc",
        "ponieważ",
        "jednak",
        "chociaż",
        "dlatego",
        "jeśli",
        "wtedy",
        "inaczej",
        "kiedy",
        "podczas",
        "odkąd",
        "dopóki",
        "czy",
        "albo",
        "ani",
        "mimo",
        "dla",
        "jak",
    },
    "DE": {  # 德语
        "und",
        "aber",
        "oder",
        "so",
        "weil",
        "jedoch",
        "obwohl",
        "deshalb",
        "wenn",
        "dann",
        "sonst",
        "wann",
        "während",
        "seit",
        "bis",
        "ob",
        "entweder",
        "weder",
        "noch",
        "doch",
        "für",
        "als",
    },
    "IT": {  # 意大利语
        "e",
        "ma",
        "o",
        "quindi",
        "perché",
        "tuttavia",
        "bbene",
        "perciò",
        "se",
        "allora",
        "altrimenti",
        "quando",
        "mentre",
        "da",
        "fino",
        "che",
        "o",
        "né",
        "ancora",
        "per",
        "come",
    },
    "TR": {  # 土耳其语
        "ve",
        "ama",
        "veya",
        "bu",
        "çünkü",
        "ancak",
        "rağmen",
        "nedenle",
        "eğer",
        "sonra",
        "aksi",
        "ne",
        "iken",
        "beri",
        "kadar",
        "olup",
        "ya",
        "ne",
        "henüz",
        "için",
        "olarak",
    },
    "HU": {  # 匈牙利语
        "és",
        "de",
        "vagy",
        "tehát",
        "mert",
        "azonban",
        "bár",
        "ezért",
        "ha",
        "akkor",
        "különben",
        "amikor",
        "miközben",
        "mióta",
        "amíg",
        "hogy",
        "vagy",
        "sem",
        "mégis",
        "számára",
        "mint",
    },
    "BG": {  # 保加利亚语
        "и",
        "но",
        "или",
        "така",
        "защото",
        "обаче",
        "въпреки",
        "следователно",
        "ако",
        "тогава",
        "иначе",
        "когато",
        "докато",
        "откакто",
        "докато",
        "дали",
        "или",
        "нито",
        "все",
        "за",
        "като",
    },
    "RU": {  # 俄语
        "и",
        "но",
        "или",
        "так",
        "потому",
        "однако",
        "хотя",
        "поэтому",
        "если",
        "то",
        "иначе",
        "когда",
        "пока",
        "с",
        "до",
        "ли",
        "либо",
        "ни",
        "еще",
        "для",
        "как",
    },
    "EL": {  # 希腊语
        "και",
        "αλλά",
        "ή",
        "έτσι",
        "επειδή",
        "όμως",
        "αν",
        "επομένως",
        "αν",
        "τότε",
        "αλλιώς",
        "πότε",
        "ενώ",
        "από",
        "μέχρι",
        "είτε",
        "είτε",
        "ούτε",
        "ακόμα",
        "για",
        "όπως",
    },
    "RO": {  # 罗马尼亚语
        "și",
        "dar",
        "sau",
        "deci",
        "pentru",
        "totuși",
        "deși",
        "prin",
        "dacă",
        "atunci",
        "altfel",
        "când",
        "în",
        "de",
        "până",
        "fie",
        "fie",
        "nici",
        "încă",
        "pentru",
        "ca",
    },
    "UK": {  # 乌克兰语
        "і",
        "але",
        "або",
        "так",
        "тому",
        "проте",
        "хоча",
        "тому",
        "якщо",
        "тоdi",
        "інакше",
        "коли",
        "поки",
        "з",
        "доки",
        "чи",
        "або",
        "ні",
        "ще",
        "для",
        "як",
    },
    "FR": {  # 法语
        "et",
        "mais",
        "ou",
        "donc",
        "parce",
        "cependant",
        "bien",
        "conséquent",
        "si",
        "alors",
        "sinon",
        "quand",
        "pendant",
        "depuis",
        "jusqu'à",
        "sauf",
        "que",
        "soit",
        "ni",
        "pourtant",
        "pour",
        "comme",
    },
    "PT": {  # 葡萄牙语
        "e",
        "mas",
        "ou",
        "então",
        "porque",
        "entanto",
        "embora",
        "portanto",
        "se",
        "então",
        "senão",
        "quando",
        "enquanto",
        "desde",
        "até",
        "se",
        "ou",
        "nem",
        "ainda",
        "para",
        "como",
    },
    "HR": {  # 克罗地亚语
        "i",
        "ali",
        "ili",
        "pa",
        "jer",
        "međutim",
        "iako",
        "stoga",
        "ako",
        "onda",
        "inače",
        "kada",
        "dok",
        "od",
        "dok",
        "bilo",
        "bilo",
        "ni",
        "još",
        "za",
        "kao",
    },
    "NL": {  # 荷兰语
        "en",
        "maar",
        "of",
        "dus",
        "omdat",
        "echter",
        "hoewel",
        "daarom",
        "als",
        "dan",
        "anders",
        "wanneer",
        "terwijl",
        "sinds",
        "totdat",
        "of",
        "ofwel",
        "noch",
        "toch",
        "voor",
        "kzoals",
    },
    "DA": {  # 丹麦语
        "og",
        "men",
        "eller",
        "så",
        "fordi",
        "imidlertid",
        "skønt",
        "derfor",
        "hvis",
        "så",
        "ellers",
        "når",
        "mens",
        "siden",
        "indtil",
        "om",
        "enten",
        "hverken",
        "endnu",
        "for",
        "som",
    },
    "LT": {  # 立陶宛语
        "ir",
        "bet",
        "arba",
        "tad",
        "nes",
        "tačiau",
        "nors",
        "todėl",
        "jei",
        "tada",
        "kitaip",
        "kada",
        "kol",
        "nuo",
        "iki",
        "ar",
        "arba",
        "nei",
        "vis",
        "dėl",
        "kaip",
    },
    "NO": {  # 挪威语
        "og",
        "men",
        "eller",
        "så",
        "fordi",
        "imidlertid",
        "skjønt",
        "derfor",
        "hvis",
        "så",
        "ellers",
        "når",
        "mens",
        "siden",
        "inntil",
        "om",
        "enten",
        "verken",
        "ennå",
        "for",
        "som",
    },
    "AR": {  # 阿拉伯语
        "و",  # and
        "أو",  # or
        "لكن",  # but
        "ثم",  # then
        "إذا",  # if
        "لأن",  # because
        "حتى",  # until/so that
        "عندما",  # when
        "بينما",  # while
        "إلا",  # except
        "مع",  # with
        "على",  # on/upon
        "من",  # from
        "في",  # in
        "إلى",  # to
        "أن",  # that
    },
    "HE": {  # 希伯来语
        "ו",  # and
        "או",  # or
        "אבל",  # but
        "אז",  # then
        "כי",  # because
        "אם",  # if
        "עד",  # until
        "כאשר",  # when
        "בזמן",  # while
        "אלא",  # except
        "עם",  # with
        "על",  # on
        "מ",  # from
        "ב",  # in
        "ל",  # to
        "ש",  # that
    },
}

# 各语言默认阅读速度 (WPM - Words Per Minute)
# 基于不同语言的阅读速度研究和字幕行业标准
# 参考:
# - 拉丁字母语言: 170-180 WPM
# - 西里尔字母语言: 130-180 WPM
# - RTL语言（阿拉伯语、希伯来语）: 100-120 WPM
# - 默认值: 180 WPM
DEFAULT_WPM = 180

WPM_MAP = {
    # 拉丁字母语言 - 较快阅读速度
    "EN": 180,  # 英语
    "DE": 170,  # 德语 - 复合词较长
    "FR": 180,  # 法语
    "ES": 185,  # 西班牙语
    "IT": 180,  # 意大利语
    "PT": 180,  # 葡萄牙语
    "NL": 175,  # 荷兰语
    "DA": 180,  # 丹麦语
    "NO": 180,  # 挪威语
    "SV": 180,  # 瑞典语
    "FI": 170,  # 芬兰语 - 复合词
    "PL": 170,  # 波兰语
    "CS": 170,  # 捷克语
    "HR": 170,  # 克罗地亚语
    "RO": 175,  # 罗马尼亚语
    "HU": 165,  # 匈牙利语 - 复杂语法
    "TR": 170,  # 土耳其语
    "LT": 170,  # 立陶宛语
    # 西里尔字母语言 - 稍慢
    "RU": 165,  # 俄语
    "UK": 165,  # 乌克兰语
    "BG": 165,  # 保加利亚语
    # 希腊语
    "EL": 165,  # 希腊语
    # RTL语言 - 较慢阅读速度
    "AR": 150,  # 阿拉伯语 - 复杂书写系统
    "HE": 160,  # 希伯来语
}


def get_wpm_for_language(language: str) -> int:
    """
    获取指定语言的默认阅读速度 (WPM)

    Args:
        language: 语言代码 (如 "EN", "AR", "ZH")

    Returns:
        int: 每分钟单词数
    """
    return WPM_MAP.get(language.upper(), DEFAULT_WPM)
