"""Text Block Renderer - A library for parsing HTML text, splitting text into blocks, and rendering blocks to PNG images."""

from .models import (
    ColoredSpan,
    ColoredWord,
    FontSpec,
    RenderConstraint,
    SubtitleBlock,
    ColoredSubtitleBlock,
    SplitConfig,
    RenderStyle,
    FrameSubtitle,
    BlockTiming,
    OverlappingFrameSubtitle,
    AdjustMode,
    VerticalAlignment,
    TrackMode,
    # 三层架构新增模型
    TrackSlot,
    TimelineFrame,
    SafeArea,
    BlockPlacement,
    FrameLayout,
    TextLayout,
)
from .htmlparser import (
    ColorHTMLParser,
    parse_html_text,
    split_html_paragraphs,
)
from .splitter import (
    TextMeasurer,
    find_semantic_break,
    split_paragraph_to_blocks,
    find_colored_semantic_break,
    split_html_to_colored_blocks,
)
from .renderer import (
    optimize_polygon_x_alignment,
    round_polygon_corners,
    render_colored_block,
)
from .rtl_processor import (
    is_rtl_language,
    is_rtl_text,
    process_rtl_text,
    RTL_AVAILABLE,
)
from .timeline import (
    DEFAULT_WPM,
    WPM_MAP,
    get_wpm_for_language,
    MIN_DISPLAY_TIME,
    MAX_DISPLAY_TIME,
    SECONDS_PER_WORD,
    count_words,
    calculate_read_time,
    calculate_read_times,
    create_frame_subtitles,
    can_fit_next_block,
    create_overlapping_frame_subtitles,
    # 三层架构新增类
    TimeCalculator,
    TimelineTrack,
    FrameAssembler,
)
from .layout import (
    LayoutEngine,
    AutoArrange,
)
from .render import (
    ImageRenderer,
    StyleResolver,
    WebRenderer,
)
from .pipeline import (
    text_to_timeline_subtitles,
    blocks_to_timeline_subtitles,
    calculate_total_duration,
    get_timestamps,
    export_to_srt,
    build_overlapping_timeline,
    text_to_overlapping_subtitles,
    render_and_layout_frames,
    block_to_html,
    rebuild_block_from_html,
    get_overlapping_total_duration,
    export_overlapping_to_srt,
    text_to_long_image,
    render_text_image,
)

__version__ = "3.2.0"

__all__ = [
    # Models
    "ColoredSpan",
    "ColoredWord",
    "FontSpec",
    "RenderConstraint",
    "SubtitleBlock",
    "ColoredSubtitleBlock",
    "SplitConfig",
    "RenderStyle",
    "FrameSubtitle",
    "BlockTiming",
    "OverlappingFrameSubtitle",
    "AdjustMode",
    "VerticalAlignment",
    "TrackMode",
    # 三层架构新增模型
    "TrackSlot",
    "TimelineFrame",
    "SafeArea",
    "BlockPlacement",
    "FrameLayout",
    "TextLayout",
    # HTML Parser
    "ColorHTMLParser",
    "parse_html_text",
    "split_html_paragraphs",
    # Splitter
    "TextMeasurer",
    "find_semantic_break",
    "split_paragraph_to_blocks",
    "find_colored_semantic_break",
    "split_html_to_colored_blocks",
    # Renderer (兼容)
    "optimize_polygon_x_alignment",
    "round_polygon_corners",
    "render_colored_block",
    # RTL Utilities
    "is_rtl_language",
    "is_rtl_text",
    "process_rtl_text",
    "RTL_AVAILABLE",
    # Timeline 层
    "DEFAULT_WPM",
    "WPM_MAP",
    "get_wpm_for_language",
    "MIN_DISPLAY_TIME",
    "MAX_DISPLAY_TIME",
    "SECONDS_PER_WORD",
    "count_words",
    "calculate_read_time",
    "calculate_read_times",
    "create_frame_subtitles",
    "can_fit_next_block",
    "create_overlapping_frame_subtitles",
    "TimeCalculator",
    "TimelineTrack",
    "FrameAssembler",
    # Layout 层
    "LayoutEngine",
    "AutoArrange",
    # Render 层
    "ImageRenderer",
    "StyleResolver",
    "WebRenderer",
    # Pipeline
    "text_to_timeline_subtitles",
    "blocks_to_timeline_subtitles",
    "calculate_total_duration",
    "get_timestamps",
    "export_to_srt",
    "text_to_overlapping_subtitles",
    "build_overlapping_timeline",
    "render_and_layout_frames",
    "block_to_html",
    "rebuild_block_from_html",
    "get_overlapping_total_duration",
    "export_overlapping_to_srt",
    "text_to_long_image",
    "render_text_image",
]
