"""
Total Recall — On-chain memory infrastructure for AI agents.
https://www.totalrecallagent.com
"""

from .client import TotalRecallClient, TotalRecallError, MemoryEntry, SpaceClient, SpaceError

__all__ = [
    "TotalRecallClient",
    "TotalRecallError",
    "MemoryEntry",
    "SpaceClient",
    "SpaceError",
]
__version__ = "0.3.0"
