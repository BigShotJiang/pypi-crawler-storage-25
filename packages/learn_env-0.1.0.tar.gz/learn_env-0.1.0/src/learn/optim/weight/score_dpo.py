"""
---
title: ScoreDPO — Score-Weighted Direct Preference Optimization
summary: >
    Score-based preference optimization that up-weights high-contrast
    preference pairs via d(s_w, s_l) = (s_w - s_l)^alpha. Extends DPO
    with score-conditioned reward scaling and weighted sampling. Port of
    ScoreFlow's Score-DPO from arXiv:2502.04306.
---

# ScoreDPO — Score-Based Preference Optimization

Port of **ScoreFlow** (Wang et al., 2025 — arXiv:2502.04306), specifically
the **Score-DPO** training objective from Theorem 3.2.

## Key Idea

Standard DPO treats all preference pairs equally.  Score-DPO up-weights
pairs with large score gaps via an enhanced sampling distribution and
conditions the reward signals on absolute scores:

$$\\mathcal{L}_{\\text{Score-DPO}} =
    -\\mathbb{E}_{(w,l)\\sim P^*}[\\log\\sigma(f(s_w)\\cdot r_w - (1-f(s_l))\\cdot r_l)]$$

where:
- $P^*(w,l) \\propto d(s_w, s_l) \\cdot P(w,l)$, $\\quad d(x,y)=(x-y)^\\alpha$
- $f(x)=x$ by default (identity score transform)
- $r_w \\approx s_w$ (score as proxy reward)

## Algorithm

1. **Generate candidates**: For each input, run ``predict_fn`` $k$ times
2. **Score**: Each candidate gets a score $s \\in [0, 1]$
3. **Construct pairs**: All $\\binom{k}{2}$ pairs, weight by $(s_w - s_l)^\\alpha$
4. **Weighted sampling**: Sample $S$ pairs proportional to weights
5. **Fine-tune**: Format as DPO data and call ``engine.finetune()``

## PyTorch Analogy

| PyTorch | ScoreDPO |
|---------|----------|
| Weighted sampler | Score-gap weighted pair sampling |
| Custom loss | Score-DPO loss with f(s) scaling |
| ``optimizer.step()`` | ``engine.finetune(DPO_CHAT)`` |

## Usage

```python
from learn.optim.weight.score_dpo import ScoreDPO

opt = ScoreDPO(
    params=[prompt_param],
    engine=engine,
    beta=0.1,
    alpha=3.0,         # d(x,y) = (x-y)^alpha
    num_candidates=8,  # workflows/responses per problem
)
opt.compile(
    predict_fn=predict,
    dataset=[...],
    metric=lambda ex, pred: exact_match(pred, ex["expected"]),
)
```
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from itertools import combinations
from typing import TYPE_CHECKING, Any, Callable

from learn.optim.weight.base import (
    WeightOptimizer,
    collect_traces,
)

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# Preference pair data structure
# ---------------------------------------------------------------------------


@dataclass
class ScoredPreferencePair:
    r"""A preference pair $(w, l)$ with score-based weighting.

    From Section 3.3 of ScoreFlow: $d(s_w, s_l) = (s_w - s_l)^\alpha$
    is used to up-weight high-contrast pairs.
    """
    input_text: str
    chosen_output: str
    rejected_output: str
    chosen_score: float
    rejected_score: float
    weight: float = 0.0  # d(s_w, s_l) sampling weight
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------


def score_dpo_loss(
    pairs: list[ScoredPreferencePair],
    beta: float = 0.1,
) -> float:
    r"""Compute Score-DPO loss (Theorem 3.2).

    $$\mathcal{L} = -\frac{1}{N}\sum_{(w,l)}
        \log\sigma(f(s_w) \cdot s_w - (1 - f(s_l)) \cdot s_l)$$

    where default $f(x) = x$ (identity transform).

    Uses numerically stable log-sigmoid: $\log\sigma(x) = x - \log(1 + e^x)$.
    """
    if not pairs:
        return 0.0
    total = 0.0
    for pair in pairs:
        s_w = pair.chosen_score
        s_l = pair.rejected_score
        # Modified reward signals: r*_w = f(s_w) * s_w, r*_l = (1-f(s_l)) * s_l
        r_star_w = s_w * s_w
        r_star_l = (1.0 - s_l) * s_l
        logit = beta * (r_star_w - r_star_l)
        # Numerically stable log-sigmoid
        if logit > 20:
            log_sigma = 0.0
        elif logit < -20:
            log_sigma = logit
        else:
            log_sigma = logit - math.log(1.0 + math.exp(logit))
        total += -log_sigma
    return total / len(pairs)


def construct_pairs(
    scored_outputs: list[tuple[str, float]],
    input_text: str,
    alpha: float = 3.0,
) -> list[ScoredPreferencePair]:
    r"""Construct all C(k,2) preference pairs from scored outputs.

    Weight each pair by $d(s_w, s_l) = (s_w - s_l)^\alpha$.

    Args:
        scored_outputs: List of (output_text, score) tuples.
        input_text: The input this was generated for.
        alpha: Weighting exponent (paper uses alpha=3).

    Returns:
        List of preference pairs sorted by weight (descending).
    """
    pairs: list[ScoredPreferencePair] = []
    for (out_i, score_i), (out_j, score_j) in combinations(scored_outputs, 2):
        if abs(score_i - score_j) < 1e-6:
            continue  # Skip ties
        if score_i > score_j:
            chosen, chs, rejected, rjs = out_i, score_i, out_j, score_j
        else:
            chosen, chs, rejected, rjs = out_j, score_j, out_i, score_i

        delta = chs - rjs
        weight = delta ** alpha
        pairs.append(ScoredPreferencePair(
            input_text=input_text,
            chosen_output=chosen,
            rejected_output=rejected,
            chosen_score=chs,
            rejected_score=rjs,
            weight=weight,
        ))
    pairs.sort(key=lambda p: p.weight, reverse=True)
    return pairs


def weighted_sample_pairs(
    all_pairs: list[ScoredPreferencePair],
    num_samples: int,
) -> list[ScoredPreferencePair]:
    r"""Sample preference pairs according to $P^*(w,l) \propto d(s_w, s_l)$.

    Weighted sampling with replacement.  Falls back to uniform sampling if
    all weights are zero.
    """
    if not all_pairs:
        return []
    weights = [p.weight for p in all_pairs]
    total = sum(weights)
    if total < 1e-12:
        return random.sample(all_pairs, min(num_samples, len(all_pairs)))
    indices = random.choices(range(len(all_pairs)), weights=weights, k=num_samples)
    return [all_pairs[i] for i in indices]


def format_score_dpo_data(
    pairs: list[ScoredPreferencePair],
    system_prompt: str | None = None,
) -> list[dict[str, Any]]:
    """Format scored preference pairs as DPO chat training data.

    Produces ``{"messages": [...], "chosen": {...}, "rejected": {...}}``
    format compatible with ``TrainDataFormat.DPO_CHAT``.

    Each example is weighted by its ``pair.weight`` in metadata.
    """
    training_data: list[dict[str, Any]] = []
    for pair in pairs:
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": pair.input_text})

        training_data.append({
            "messages": messages,
            "chosen": {"role": "assistant", "content": pair.chosen_output},
            "rejected": {"role": "assistant", "content": pair.rejected_output},
            # Score metadata for downstream logging
            "chosen_score": pair.chosen_score,
            "rejected_score": pair.rejected_score,
            "pair_weight": pair.weight,
        })

    return training_data


# ---------------------------------------------------------------------------
# ScoreDPO optimizer
# ---------------------------------------------------------------------------


class ScoreDPO(WeightOptimizer):
    r"""
    ## ScoreDPO — Score-Based Preference Optimization

    Extends DPO with score-conditioned preference weighting from the
    ScoreFlow paper (Wang et al., arXiv:2502.04306).

    Key improvements over plain DPO:
    1. **Weighted sampling**: $P^* \propto (s_w - s_l)^\alpha$ — trains on
       the most informative (high-contrast) preference pairs first.
    2. **Score-conditioned rewards**: $r^*_w = f(s_w) r_w$, so
       high-confidence chosen outputs get stronger positive signal.

    ```python
    opt = ScoreDPO(
        params=[prompt_param],
        engine=engine,
        beta=0.1,
        alpha=3.0,
        num_candidates=8,
        num_preference_samples=200,
    )
    opt.compile(
        predict_fn=predict,
        dataset=dataset,
        metric=lambda ex, pred: float(pred.strip() == ex["expected"]),
    )
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        beta: float = 0.1,
        alpha: float = 3.0,
        num_candidates: int = 8,
        num_preference_samples: int = 200,
        min_score_diff: float = 1e-6,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Args:
            params: Parameters to optimize (tracked, but weight updates
                happen through ``engine.finetune()``).
            engine: LLM engine that supports ``engine.finetune()``.
            beta: DPO temperature (default 0.1).
            alpha: Score-gap weighting exponent (paper uses 3.0).
            num_candidates: Number of outputs to generate per input.
            num_preference_samples: Pairs to sample per training step.
            min_score_diff: Minimum score difference to form a pair.
            system_prompt: Optional system prompt for formatting training data.
        """
        super().__init__(params, engine=engine, **kwargs)
        self.beta = beta
        self.alpha = alpha
        self.num_candidates = num_candidates
        self.num_preference_samples = num_preference_samples
        self.min_score_diff = min_score_diff
        self.system_prompt = system_prompt
        self._all_pairs: list[ScoredPreferencePair] = []

    def record_pairs(self, pairs: list[ScoredPreferencePair]) -> None:
        """Accumulate pre-computed preference pairs for the next step."""
        self._all_pairs.extend(pairs)

    def clear_data(self) -> None:
        """Clear all accumulated data."""
        super().clear_data()
        self._all_pairs.clear()

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        input_field: str = "input",
        **kwargs: Any,
    ) -> Any:
        """Full ScoreDPO pipeline: generate → score → construct pairs → finetune.

        For each example in the dataset:
        1. Generates ``num_candidates`` outputs
        2. Scores each output via ``metric``
        3. Constructs $\\binom{k}{2}$ preference pairs with $\\alpha$-weighting
        4. Samples ``num_preference_samples`` pairs via $P^*$
        5. Formats as DPO data and calls ``engine.finetune(DPO_CHAT)``

        Args:
            predict_fn: A callable that takes ``**example`` → output.
            dataset: Input examples.
            metric: Scoring function ``(example, prediction) -> float``.
            input_field: Key for input text in example dicts.
        """
        if predict_fn is not None and dataset is not None:
            # Collect num_candidates outputs per input
            expanded = [ex for ex in dataset for _ in range(self.num_candidates)]
            traces = collect_traces(predict_fn, expanded, metric)
            self._trace_data.extend(traces)

        return self._run_finetune(input_field)

    def _run_finetune(self, input_field: str = "input") -> Any:
        """Construct pairs from trace data and submit to engine."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        # Build (input → list of (output, score)) mapping from traces
        if not self._all_pairs and self._trace_data:
            by_input: dict[str, list[tuple[str, float]]] = {}
            for trace in self._trace_data:
                if trace.get("prediction") is None:
                    continue
                key = str(trace["example"].get(input_field, ""))
                if key not in by_input:
                    by_input[key] = []
                score = float(trace.get("score", 0.0))
                by_input[key].append((str(trace["prediction"]), score))

            # Construct preference pairs for each input
            for inp_text, outputs in by_input.items():
                pairs = construct_pairs(outputs, inp_text, alpha=self.alpha)
                self._all_pairs.extend(pairs)

        if not self._all_pairs and not self._training_data:
            return None

        # Weighted sampling
        if self._all_pairs:
            sampled = weighted_sample_pairs(self._all_pairs, self.num_preference_samples)
            train_data = format_score_dpo_data(sampled, system_prompt=self.system_prompt)
        else:
            train_data = list(self._training_data)

        if not train_data:
            return None

        job = self.engine.finetune(
            train_data=train_data,
            train_data_format=TrainDataFormat.DPO_CHAT,
            train_kwargs=self.train_kwargs,
        )
        self._training_jobs.append(job)
        return job

    def step(self) -> None:
        """Run one ScoreDPO step: construct pairs and fine-tune."""
        self._run_finetune()

    def compute_loss(self, pairs: list[ScoredPreferencePair] | None = None) -> float:
        """Compute the Score-DPO loss on the current pairs.

        Useful for monitoring training without actually fine-tuning.

        Args:
            pairs: If None, uses accumulated ``_all_pairs``.
        """
        target_pairs = pairs if pairs is not None else self._all_pairs
        return score_dpo_loss(target_pairs, beta=self.beta)
