"""
---
title: learn.optim.weight — Weight-Space Optimizers
summary: >
    Weight-space optimization methods (SFT, DPO, PPO, GRPO, REINFORCE, ScoreDPO)
    ported from DSPy and reference frameworks. Real training through
    engine.finetune() and engine.reinforce().
---
"""
from learn.optim.weight.base import (
    DPO,
    GRPO,
    PPO,
    REINFORCE,
    SFT,
    LoRAAdapter,
    WeightOptimizer,
    WeightTrainer,
    collect_traces,
    format_dpo_data,
    format_grpo_data,
    format_reinforce_data,
    format_sft_data,
)
from learn.optim.weight.score_dpo import (
    ScoreDPO,
    ScoredPreferencePair,
    construct_pairs,
    format_score_dpo_data,
    score_dpo_loss,
    weighted_sample_pairs,
)

__all__ = [
    "DPO",
    "GRPO",
    "LoRAAdapter",
    "PPO",
    "REINFORCE",
    "SFT",
    "ScoreDPO",
    "ScoredPreferencePair",
    "WeightOptimizer",
    "WeightTrainer",
    "collect_traces",
    "construct_pairs",
    "format_dpo_data",
    "format_grpo_data",
    "format_reinforce_data",
    "format_score_dpo_data",
    "format_sft_data",
    "score_dpo_loss",
    "weighted_sample_pairs",
]
