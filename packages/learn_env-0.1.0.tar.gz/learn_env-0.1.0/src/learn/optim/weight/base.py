"""
---
title: WeightOptimizer — Real Weight-Space Optimization
summary: >
    Weight-space optimization methods (SFT, DPO, PPO, GRPO, REINFORCE)
    ported from DSPy and other reference frameworks. These are REAL
    algorithm ports that perform actual fine-tuning and RL training
    through the engine's training API — not prompt-rewriting simulations.
---

# Weight-Space Optimizers

Each optimizer implements the actual algorithm from its reference codebase:

| Optimizer | Reference | Algorithm |
|-----------|-----------|-----------|
| ``SFT`` | DSPy BootstrapFinetune | Collect traces -> format chat data -> ``engine.finetune()`` |
| ``DPO`` | DSPy/TRL DPO | Collect preference pairs -> format DPO data -> ``engine.finetune()`` |
| ``PPO`` | Schulman et al. | Scored rollouts -> surrogate objective -> ``engine.finetune()`` |
| ``GRPO`` | DSPy GRPO / DeepSeek-R1 | Group rollouts -> relative rewards -> ``engine.reinforce()`` |
| ``REINFORCE`` | Williams 1992 | Reward-weighted samples -> ``engine.finetune()`` |

## Data Collection

``collect_traces()`` is the learn equivalent of DSPy's
``bootstrap_trace_data()``. It runs a predict function on a dataset,
captures execution traces, and scores them via a metric function.

## Training Data Formats

Uses ``TrainDataFormat`` from ``learn.env.engine.base``:

- ``SFT_CHAT``: ``{"messages": [...]}`` — standard chat fine-tuning
- ``DPO_CHAT``: ``{"messages": [...], "chosen": {...}, "rejected": {...}}``
- ``GRPO_CHAT``: ``{"messages": [...], "completion": {...}, "reward": float}``
"""
from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# Trace data collection — port of DSPy's bootstrap_trace_data()
# ---------------------------------------------------------------------------


def collect_traces(
    predict_fn: Callable[..., Any],
    dataset: list[dict[str, Any]],
    metric: Callable[[dict[str, Any], Any], float] | None = None,
    num_threads: int = 1,
) -> list[dict[str, Any]]:
    """Collect execution traces from a predict function over a dataset.

    Port of DSPy's ``bootstrap_trace_data()``. Runs ``predict_fn`` on
    each example, captures the output, and optionally scores it.

    Args:
        predict_fn: A callable that takes ``**example`` and returns
            a prediction (string or structured output).
        dataset: List of input dicts. Each dict is unpacked as kwargs
            to ``predict_fn``.
        metric: Optional scoring function ``(example, prediction) -> float``.
            If ``None``, all traces get score ``1.0``.
        num_threads: Number of threads for parallel execution.
            Currently sequential (threading planned).

    Returns:
        List of trace dicts, each containing:
        - ``"example"``: The input dict.
        - ``"prediction"``: The output from predict_fn.
        - ``"score"``: The metric score (or 1.0 if no metric).
        - ``"example_ind"``: Index in the dataset.
    """
    traces: list[dict[str, Any]] = []

    for idx, example in enumerate(dataset):
        try:
            prediction = predict_fn(**example)
        except Exception:
            traces.append({
                "example": example,
                "prediction": None,
                "score": 0.0,
                "example_ind": idx,
            })
            continue

        score = 1.0
        if metric is not None:
            try:
                score = float(metric(example, prediction))
            except Exception:
                score = 0.0

        traces.append({
            "example": example,
            "prediction": prediction,
            "score": score,
            "example_ind": idx,
        })

    return traces


# ---------------------------------------------------------------------------
# Training data formatting
# ---------------------------------------------------------------------------


def format_sft_data(
    traces: list[dict[str, Any]],
    input_field: str = "input",
    output_field: str = "output",
    system_prompt: str | None = None,
) -> list[dict[str, Any]]:
    """Format trace data as SFT chat training data.

    Converts (input, output) pairs from successful traces into the
    ``{"messages": [...]}`` format expected by ``TrainDataFormat.SFT_CHAT``.
    """
    training_data: list[dict[str, Any]] = []

    for trace in traces:
        if trace.get("prediction") is None:
            continue
        if trace.get("score", 0.0) <= 0.0:
            continue

        example = trace["example"]
        user_input = example.get(input_field, "")
        output = example.get(output_field, str(trace["prediction"]))

        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": str(user_input)})
        messages.append({"role": "assistant", "content": str(output)})

        training_data.append({"messages": messages})

    return training_data


def format_dpo_data(
    chosen_traces: list[dict[str, Any]],
    rejected_traces: list[dict[str, Any]],
    input_field: str = "input",
    system_prompt: str | None = None,
) -> list[dict[str, Any]]:
    """Format paired traces as DPO training data.

    Creates ``{"messages": [...], "chosen": {...}, "rejected": {...}}``
    format for ``TrainDataFormat.DPO_CHAT``.
    """
    chosen_by_input: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for t in chosen_traces:
        key = str(t["example"].get(input_field, ""))
        chosen_by_input[key].append(t)

    rejected_by_input: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for t in rejected_traces:
        key = str(t["example"].get(input_field, ""))
        rejected_by_input[key].append(t)

    training_data: list[dict[str, Any]] = []
    for inp_key in chosen_by_input:
        if inp_key not in rejected_by_input:
            continue
        for chosen in chosen_by_input[inp_key]:
            for rejected in rejected_by_input[inp_key]:
                messages: list[dict[str, str]] = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.append({"role": "user", "content": inp_key})

                training_data.append({
                    "messages": messages,
                    "chosen": {
                        "role": "assistant",
                        "content": str(chosen.get("prediction", "")),
                    },
                    "rejected": {
                        "role": "assistant",
                        "content": str(rejected.get("prediction", "")),
                    },
                })

    return training_data


def format_grpo_data(
    traces: list[dict[str, Any]],
    input_field: str = "input",
    system_prompt: str | None = None,
) -> list[list[dict[str, Any]]]:
    """Format trace data as GRPO training groups.

    Groups rollouts by input and creates batches where each group
    contains multiple completions with rewards for the same input.
    """
    by_input: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for trace in traces:
        key = str(trace["example"].get(input_field, ""))
        by_input[key].append(trace)

    groups: list[list[dict[str, Any]]] = []
    for inp_key, inp_traces in by_input.items():
        group: list[dict[str, Any]] = []
        for trace in inp_traces:
            messages: list[dict[str, str]] = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": inp_key})

            prediction_str = str(trace.get("prediction", ""))
            group.append({
                "messages": messages,
                "completion": {
                    "role": "assistant",
                    "content": prediction_str,
                },
                "reward": float(trace.get("score", 0.0)),
            })

        if group:
            groups.append(group)

    return groups


def format_reinforce_data(
    traces: list[dict[str, Any]],
    input_field: str = "input",
    system_prompt: str | None = None,
    baseline: float | None = None,
) -> list[dict[str, Any]]:
    """Format trace data as REINFORCE training data.

    Each example is a chat message with a reward-weighted signal.
    The advantage (reward - baseline) determines the update weight.
    """
    rewards = [t.get("score", 0.0) for t in traces if t.get("prediction") is not None]
    if baseline is None and rewards:
        baseline = sum(rewards) / len(rewards)
    elif baseline is None:
        baseline = 0.0

    training_data: list[dict[str, Any]] = []
    for trace in traces:
        if trace.get("prediction") is None:
            continue

        example = trace["example"]
        reward = float(trace.get("score", 0.0))
        advantage = reward - baseline

        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": str(example.get(input_field, ""))})

        training_data.append({
            "messages": messages,
            "completion": {
                "role": "assistant",
                "content": str(trace.get("prediction", "")),
            },
            "reward": reward,
            "advantage": advantage,
        })

    return training_data


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class WeightOptimizer(Optimizer):
    r"""
    ## WeightOptimizer

    Base class for weight-space optimization. Subclasses collect
    training data (via ``collect_traces()`` or ``record()``) and
    submit it to the engine's training API (``finetune()`` or
    ``reinforce()``) for actual model weight updates.

    This is NOT text-space optimization — it performs real training
    through the engine's provider (OpenAI, local trainer, etc.).
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        train_kwargs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine)
        self.train_kwargs = train_kwargs or {}
        self._training_data: list[dict[str, Any]] = []
        self._trace_data: list[dict[str, Any]] = []
        self._training_jobs: list[Any] = []

    def record(self, data: list[dict[str, Any]]) -> None:
        """Append pre-formatted training data for the next step."""
        self._training_data.extend(data)

    def record_traces(self, traces: list[dict[str, Any]]) -> None:
        """Record raw trace data from ``collect_traces()``."""
        self._trace_data.extend(traces)

    def clear_data(self) -> None:
        """Clear all accumulated training and trace data."""
        self._training_data.clear()
        self._trace_data.clear()

    @property
    def last_job(self) -> Any:
        """The most recent training job, if any."""
        return self._training_jobs[-1] if self._training_jobs else None

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Collect traces, format data, and launch training."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# SFT — Supervised Fine-Tuning
# ---------------------------------------------------------------------------


class SFT(WeightOptimizer):
    r"""
    ## SFT — Supervised Fine-Tuning

    Port of DSPy's ``BootstrapFinetune``. Collects execution traces
    from a component, formats them as chat training data, and calls
    ``engine.finetune()`` to perform actual supervised fine-tuning.

    ### Algorithm (from DSPy BootstrapFinetune)

    1. **Collect traces**: Run component on dataset via ``collect_traces()``
    2. **Filter by metric**: Keep only successful traces (score > 0)
    3. **Format as chat**: Convert to ``{"messages": [...]}`` format
    4. **Call finetune**: ``engine.finetune(train_data, SFT_CHAT)``
    5. **Wait for result**: ``job.result()`` returns fine-tuned model ID
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        exclude_demos: bool = False,
        multitask: bool = True,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine, **kwargs)
        self.exclude_demos = exclude_demos
        self.multitask = multitask
        self.system_prompt = system_prompt

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        input_field: str = "input",
        output_field: str = "output",
        **kwargs: Any,
    ) -> Any:
        """Collect traces, format, and launch fine-tuning."""
        if predict_fn is not None and dataset is not None:
            traces = collect_traces(predict_fn, dataset, metric)
            self._trace_data.extend(traces)

        return self._run_finetune(input_field, output_field)

    def _run_finetune(
        self,
        input_field: str = "input",
        output_field: str = "output",
    ) -> Any:
        """Format trace data and submit to engine."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        if self._training_data:
            train_data = list(self._training_data)
        elif self._trace_data:
            train_data = format_sft_data(
                self._trace_data,
                input_field=input_field,
                output_field=output_field,
                system_prompt=self.system_prompt,
            )
        else:
            return None

        if not train_data:
            return None

        job = self.engine.finetune(
            train_data=train_data,
            train_data_format=TrainDataFormat.SFT_CHAT,
            train_kwargs=self.train_kwargs,
        )
        self._training_jobs.append(job)
        return job

    def step(self) -> None:
        """Run one SFT step: format data and launch fine-tuning."""
        self._run_finetune()


# ---------------------------------------------------------------------------
# DPO — Direct Preference Optimization
# ---------------------------------------------------------------------------


class DPO(WeightOptimizer):
    r"""
    ## DPO — Direct Preference Optimization

    Collects (chosen, rejected) preference pairs and submits them
    for DPO training via ``engine.finetune()``.

    ### Algorithm

    1. **Collect paired traces**: Run component, collect traces
    2. **Split by score**: High-scoring chosen, low-scoring rejected
    3. **Format as DPO**: ``{"messages": [...], "chosen": {...}, "rejected": {...}}``
    4. **Call finetune**: ``engine.finetune(train_data, DPO_CHAT)``
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        beta: float = 0.1,
        score_threshold: float = 0.5,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine, **kwargs)
        self.beta = beta
        self.score_threshold = score_threshold
        self.system_prompt = system_prompt

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        input_field: str = "input",
        score_threshold: float | None = None,
        num_samples: int = 2,
        **kwargs: Any,
    ) -> Any:
        """Collect traces, split into chosen/rejected, and fine-tune."""
        if predict_fn is not None and dataset is not None:
            expanded = [ex for ex in dataset for _ in range(num_samples)]
            traces = collect_traces(predict_fn, expanded, metric)
            self._trace_data.extend(traces)

        return self._run_finetune(
            input_field,
            score_threshold if score_threshold is not None else self.score_threshold,
        )

    def _run_finetune(
        self,
        input_field: str = "input",
        score_threshold: float | None = None,
    ) -> Any:
        """Format preference data and submit to engine."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        threshold = score_threshold if score_threshold is not None else self.score_threshold

        if self._training_data:
            train_data = list(self._training_data)
        elif self._trace_data:
            chosen = [t for t in self._trace_data if t.get("score", 0.0) >= threshold]
            rejected = [t for t in self._trace_data if t.get("score", 0.0) < threshold]
            train_data = format_dpo_data(
                chosen, rejected,
                input_field=input_field,
                system_prompt=self.system_prompt,
            )
        else:
            return None

        if not train_data:
            return None

        train_kwargs = {**self.train_kwargs, "beta": self.beta}
        job = self.engine.finetune(
            train_data=train_data,
            train_data_format=TrainDataFormat.DPO_CHAT,
            train_kwargs=train_kwargs,
        )
        self._training_jobs.append(job)
        return job

    def step(self) -> None:
        """Run one DPO step."""
        self._run_finetune()


# ---------------------------------------------------------------------------
# GRPO — Group Relative Policy Optimization
# ---------------------------------------------------------------------------


class GRPO(WeightOptimizer):
    r"""
    ## GRPO — Group Relative Policy Optimization

    Port of DSPy's ``GRPO``. For each input, generates K rollouts,
    groups them, computes relative rewards within each group, and
    submits the groups for RL training via ``engine.reinforce()``.

    ### Algorithm (from DSPy GRPO / DeepSeek-R1)

    1. **Create ReinforceJob**: ``engine.reinforce(train_kwargs)``
    2. **Training loop** (for each step):
       a. Sample training examples from dataset
       b. Generate K rollouts per example via predict_fn
       c. Score each rollout via metric
       d. Format as GRPO groups
       e. Submit batch: ``job.step(train_data, GRPO_CHAT)``
    3. **Terminate**: ``job.terminate()``
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        num_rollouts: int = 4,
        num_examples_per_step: int = 1,
        failure_score: float = 0.0,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine, **kwargs)
        self.num_rollouts = num_rollouts
        self.num_examples_per_step = num_examples_per_step
        self.failure_score = failure_score
        self.system_prompt = system_prompt
        self._reinforce_job: Any = None
        self._group_data: list[list[dict[str, Any]]] = []

    def record_groups(self, groups: list[dict[str, Any]]) -> None:
        """Record pre-structured group data.

        Each group: ``{"input": str, "rollouts": [{"output": str, "reward": float}]}``
        """
        for group in groups:
            inp = str(group.get("input", ""))
            rollouts = group.get("rollouts", [])
            formatted_group: list[dict[str, Any]] = []
            for rollout in rollouts:
                messages: list[dict[str, str]] = []
                if self.system_prompt:
                    messages.append({"role": "system", "content": self.system_prompt})
                messages.append({"role": "user", "content": inp})
                formatted_group.append({
                    "messages": messages,
                    "completion": {
                        "role": "assistant",
                        "content": str(rollout.get("output", "")),
                    },
                    "reward": float(rollout.get("reward", 0.0)),
                })
            if formatted_group:
                self._group_data.append(formatted_group)

    def record(self, data: list[dict[str, Any]]) -> None:
        """Record flat data and auto-group by input."""
        by_input: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for item in data:
            by_input[str(item.get("input", ""))].append(item)

        for inp, items in by_input.items():
            group: list[dict[str, Any]] = []
            for item in items:
                messages: list[dict[str, str]] = []
                if self.system_prompt:
                    messages.append({"role": "system", "content": self.system_prompt})
                messages.append({"role": "user", "content": inp})
                group.append({
                    "messages": messages,
                    "completion": {
                        "role": "assistant",
                        "content": str(item.get("output", "")),
                    },
                    "reward": float(item.get("reward", 0.0)),
                })
            if group:
                self._group_data.append(group)

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        num_train_steps: int = 10,
        input_field: str = "input",
        **kwargs: Any,
    ) -> Any:
        """Run the full GRPO training loop."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        train_kwargs = {
            **self.train_kwargs,
            "num_generations": self.num_rollouts,
        }
        job = self.engine.reinforce(train_kwargs=train_kwargs)
        self._reinforce_job = job

        if predict_fn is None or dataset is None:
            if self._group_data:
                status = job.get_status()
                batch_ids = status["pending_batch_ids"]
                train_data = []
                for i, group in enumerate(self._group_data):
                    if i < len(batch_ids):
                        train_data.append({
                            "batch_id": batch_ids[i],
                            "group": group,
                        })
                if train_data:
                    job.step(
                        train_data=train_data,
                        train_data_format=TrainDataFormat.GRPO_CHAT,
                    )
                self._group_data.clear()
            job.terminate()
            return job

        fulfilled_batch_ids: set[int] = set()

        for step_idx in range(num_train_steps):
            start = (step_idx * self.num_examples_per_step) % len(dataset)
            examples = []
            for i in range(self.num_examples_per_step):
                idx = (start + i) % len(dataset)
                examples.append(dataset[idx])

            expanded = [ex for ex in examples for _ in range(self.num_rollouts)]
            traces = collect_traces(predict_fn, expanded, metric)

            groups = format_grpo_data(
                traces,
                input_field=input_field,
                system_prompt=self.system_prompt,
            )

            if not groups:
                continue

            status = job.get_status()
            pending_ids = status["pending_batch_ids"]
            available_ids = [
                bid for bid in pending_ids if bid not in fulfilled_batch_ids
            ]

            if not available_ids:
                continue

            train_data = []
            for i, group in enumerate(groups):
                if i >= len(available_ids):
                    break
                batch_id = available_ids[i]
                while len(group) < self.num_rollouts and group:
                    group.extend(group[: self.num_rollouts - len(group)])
                train_data.append({
                    "batch_id": batch_id,
                    "group": group,
                })
                fulfilled_batch_ids.add(batch_id)

            if train_data:
                job.step(
                    train_data=train_data,
                    train_data_format=TrainDataFormat.GRPO_CHAT,
                )

        job.terminate()
        return job

    def step(self) -> None:
        """Run one GRPO step using recorded group data."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None or not self._group_data:
            return

        if self._reinforce_job is None:
            train_kwargs = {
                **self.train_kwargs,
                "num_generations": self.num_rollouts,
            }
            self._reinforce_job = self.engine.reinforce(train_kwargs=train_kwargs)

        job = self._reinforce_job
        status = job.get_status()
        pending_ids = status["pending_batch_ids"]

        train_data = []
        for i, group in enumerate(self._group_data):
            if i >= len(pending_ids):
                break
            train_data.append({
                "batch_id": pending_ids[i],
                "group": group,
            })

        if train_data:
            job.step(
                train_data=train_data,
                train_data_format=TrainDataFormat.GRPO_CHAT,
            )

        self._group_data.clear()

    def clear_data(self) -> None:
        """Clear group and training data."""
        super().clear_data()
        self._group_data.clear()


# ---------------------------------------------------------------------------
# PPO — Proximal Policy Optimization
# ---------------------------------------------------------------------------


class PPO(WeightOptimizer):
    r"""
    ## PPO — Proximal Policy Optimization

    Collects scored rollouts and submits them for fine-tuning with
    a clipping constraint. The ``clip_epsilon`` parameter limits how
    much the policy can change in a single step.

    ### Algorithm

    1. **Collect rollouts**: Generate outputs and score them
    2. **Compute advantages**: reward - baseline
    3. **Format training data**: Include clipping metadata
    4. **Call finetune**: ``engine.finetune(train_data, train_kwargs)``
       with ``clip_epsilon`` in train_kwargs
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        clip_epsilon: float = 0.2,
        baseline: float | None = None,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine, **kwargs)
        self.clip_epsilon = clip_epsilon
        self.baseline = baseline
        self.system_prompt = system_prompt
        self._reward_history: list[float] = []

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        input_field: str = "input",
        **kwargs: Any,
    ) -> Any:
        """Collect rollouts and launch PPO fine-tuning."""
        if predict_fn is not None and dataset is not None:
            traces = collect_traces(predict_fn, dataset, metric)
            self._trace_data.extend(traces)

        return self._run_finetune(input_field)

    def _run_finetune(self, input_field: str = "input") -> Any:
        """Format data with PPO constraints and submit."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        if self._training_data:
            train_data = list(self._training_data)
        elif self._trace_data:
            train_data = format_reinforce_data(
                self._trace_data,
                input_field=input_field,
                system_prompt=self.system_prompt,
                baseline=self.baseline,
            )
            rewards = [
                t.get("score", 0.0)
                for t in self._trace_data
                if t.get("prediction") is not None
            ]
            self._reward_history.extend(rewards)
        else:
            return None

        if not train_data:
            return None

        train_kwargs = {
            **self.train_kwargs,
            "clip_epsilon": self.clip_epsilon,
            "algorithm": "ppo",
        }

        job = self.engine.finetune(
            train_data=train_data,
            train_data_format=TrainDataFormat.SFT_CHAT,
            train_kwargs=train_kwargs,
        )
        self._training_jobs.append(job)
        return job

    def step(self) -> None:
        """Run one PPO step."""
        self._run_finetune()


# ---------------------------------------------------------------------------
# REINFORCE — Policy Gradient
# ---------------------------------------------------------------------------


class REINFORCE(WeightOptimizer):
    r"""
    ## REINFORCE — Policy Gradient

    Classic REINFORCE (Williams 1992): collects (output, reward) samples,
    computes advantages relative to a baseline, and submits for training.

    ### Algorithm

    1. **Collect rollouts**: Generate outputs and score them
    2. **Compute baseline**: Running mean of rewards (or explicit)
    3. **Compute advantages**: reward - baseline
    4. **Format training data**: Reward-weighted chat examples
    5. **Call finetune**: ``engine.finetune(train_data)``
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        baseline: float | None = None,
        system_prompt: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(params, engine=engine, **kwargs)
        self.baseline = baseline
        self.system_prompt = system_prompt
        self._reward_history: list[float] = []

    def compile(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        input_field: str = "input",
        **kwargs: Any,
    ) -> Any:
        """Collect rollouts and launch REINFORCE training."""
        if predict_fn is not None and dataset is not None:
            traces = collect_traces(predict_fn, dataset, metric)
            self._trace_data.extend(traces)

        return self._run_finetune(input_field)

    def _run_finetune(self, input_field: str = "input") -> Any:
        """Format data with reward weighting and submit."""
        from learn.env.engine.base import TrainDataFormat

        if self.engine is None:
            return None

        baseline = self.baseline
        if baseline is None and self._reward_history:
            baseline = sum(self._reward_history) / len(self._reward_history)

        if self._training_data:
            train_data = list(self._training_data)
        elif self._trace_data:
            train_data = format_reinforce_data(
                self._trace_data,
                input_field=input_field,
                system_prompt=self.system_prompt,
                baseline=baseline,
            )
            rewards = [
                t.get("score", 0.0)
                for t in self._trace_data
                if t.get("prediction") is not None
            ]
            self._reward_history.extend(rewards)
        else:
            return None

        if not train_data:
            return None

        train_kwargs = {
            **self.train_kwargs,
            "algorithm": "reinforce",
        }

        job = self.engine.finetune(
            train_data=train_data,
            train_data_format=TrainDataFormat.SFT_CHAT,
            train_kwargs=train_kwargs,
        )
        self._training_jobs.append(job)
        return job

    def step(self) -> None:
        """Run one REINFORCE step."""
        self._run_finetune()


# ---------------------------------------------------------------------------
# LoRAAdapter
# ---------------------------------------------------------------------------


class LoRAAdapter:
    """Configuration for parameter-efficient fine-tuning.

    Stores LoRA hyperparameters (rank, alpha, target modules).
    Passed via ``train_kwargs`` to the engine's ``finetune()`` method.
    """

    def __init__(
        self,
        rank: int = 8,
        alpha: float = 16.0,
        target_modules: list[str] | None = None,
    ) -> None:
        self.rank = rank
        self.alpha = alpha
        self.target_modules = target_modules or []

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for passing as train_kwargs."""
        return {
            "lora_rank": self.rank,
            "lora_alpha": self.alpha,
            "lora_target_modules": self.target_modules,
        }


# ---------------------------------------------------------------------------
# WeightTrainer
# ---------------------------------------------------------------------------


class WeightTrainer:
    r"""
    ## WeightTrainer

    Orchestrates the data-collection + optimizer compile/step loop.
    Manages epochs, batching, and validation.
    """

    def __init__(
        self,
        optimizer: WeightOptimizer | None = None,
        lora: LoRAAdapter | None = None,
        validation_fn: Optional[Callable[[], float]] = None,
    ) -> None:
        self.optimizer = optimizer
        self.lora = lora
        self.validation_fn = validation_fn
        self.history: list[dict[str, Any]] = []

        if lora is not None and optimizer is not None:
            optimizer.train_kwargs.update(lora.to_dict())

    def train(
        self,
        predict_fn: Callable[..., Any] | None = None,
        dataset: list[dict[str, Any]] | None = None,
        metric: Callable[[dict[str, Any], Any], float] | None = None,
        data: list[dict[str, Any]] | None = None,
        epochs: int = 1,
        batch_size: int | None = None,
    ) -> list[dict[str, Any]]:
        """Run the training loop."""
        if self.optimizer is None:
            return self.history

        if data is None and predict_fn is None:
            return self.history

        for epoch in range(epochs):
            if predict_fn is not None and dataset is not None:
                if batch_size and batch_size < len(dataset):
                    start = (epoch * batch_size) % len(dataset)
                    batch_ds = dataset[start: start + batch_size]
                else:
                    batch_ds = dataset

                self.optimizer.compile(
                    predict_fn=predict_fn,
                    dataset=batch_ds,
                    metric=metric,
                )
            elif data is not None:
                if batch_size and batch_size < len(data):
                    start = (epoch * batch_size) % len(data)
                    batch_data = data[start: start + batch_size]
                else:
                    batch_data = data

                self.optimizer.record(batch_data)
                self.optimizer.step()

            self.optimizer.clear_data()

            val_score = None
            if self.validation_fn is not None:
                val_score = self.validation_fn()

            record: dict[str, Any] = {"epoch": epoch, "val_score": val_score}
            if self.optimizer.last_job is not None:
                record["job_status"] = self.optimizer.last_job.status()
            self.history.append(record)

        return self.history
