"""
---
title: ExperienceBuffer — Round-Based Experience for MCTS
summary: >
    Stores (round, score, parent, modification) tuples for
    tree-search-based optimization.
---
"""
from __future__ import annotations

from typing import Any

from learn.optim.memory.base import OptimizerMemory


class ExperienceBuffer(OptimizerMemory):
    r"""
    ## ExperienceBuffer — Round-Based Experience Memory

    Stores optimization experiences as (round, score, parent, modification)
    tuples. Used by MCTSEvolution and AFlow.
    """

    def __init__(
        self,
        max_size: int = 500,
        mode: str = "use_and_store",
    ) -> None:
        super().__init__(mode=mode)
        self.max_size = max_size
        self._buffer: list[dict[str, Any]] = []

    def store(self, entry: dict[str, Any]) -> None:
        """Store an experience entry."""
        if not self.can_store():
            return
        self._buffer.append(entry)
        if len(self._buffer) > self.max_size:
            # Prune: keep entries with above-median scores
            scores = [e.get("score", 0.0) for e in self._buffer]
            median = sorted(scores)[len(scores) // 2]
            self._buffer = [
                e for e in self._buffer if e.get("score", 0.0) >= median
            ]

    def retrieve(self, query: Any = None, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve k most recent or relevant entries."""
        if not self.can_retrieve():
            return []

        if query is None:
            return self._buffer[-k:]

        # Simple keyword matching
        query_words = set(str(query).lower().split())
        scored = []
        for entry in self._buffer:
            entry_text = str(entry).lower()
            entry_words = set(entry_text.split())
            overlap = len(query_words & entry_words)
            scored.append((overlap, entry))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:k]]

    @property
    def size(self) -> int:
        return len(self._buffer)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["buffer"] = list(self._buffer)
        state["max_size"] = self.max_size
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._buffer = state.get("buffer", [])
        self.max_size = state.get("max_size", self.max_size)
