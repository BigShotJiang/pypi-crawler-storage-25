"""
---
title: HessianProxyKB — Quasi-Newton Knowledge Base
summary: >
    Stores (gradient, operator, old_value, new_value) tuples.
    Retrieval by gradient text similarity.
---
"""
from __future__ import annotations

from typing import Any

from learn.optim.memory.base import OptimizerMemory


class HessianProxyKB(OptimizerMemory):
    r"""
    ## HessianProxyKB — Hessian-Proxy Knowledge Base

    Stores (gradient, operator, old_value, new_value, improvement) tuples.
    Retrieves by gradient text similarity (keyword overlap).

    Used by: TextBFGS.
    """

    def __init__(
        self,
        max_size: int = 200,
        mode: str = "use_and_store",
    ) -> None:
        super().__init__(mode=mode)
        self.max_size = max_size
        self._entries: list[dict[str, Any]] = []

    def store(self, entry: dict[str, Any]) -> None:
        """Store a gradient-update pair."""
        if not self.can_store():
            return
        self._entries.append(entry)
        # Keep entries with best improvement
        self._entries.sort(
            key=lambda e: e.get("improvement", 0.0), reverse=True
        )
        self._entries = self._entries[: self.max_size]

    def retrieve(self, query: Any = None, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve entries most similar to the query gradient text."""
        if not self.can_retrieve():
            return []
        if query is None:
            return self._entries[:k]

        query_words = set(str(query).lower().split())
        scored = []
        for entry in self._entries:
            grad_text = entry.get("gradient", "")
            entry_words = set(grad_text.lower().split())
            overlap = len(query_words & entry_words)
            scored.append((overlap, entry))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:k]]

    @property
    def size(self) -> int:
        return len(self._entries)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["entries"] = list(self._entries)
        state["max_size"] = self.max_size
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._entries = state.get("entries", [])
        self.max_size = state.get("max_size", self.max_size)
