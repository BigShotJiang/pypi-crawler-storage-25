"""
---
title: OptimizerMemory — Base for Optimizer Memory
summary: >
    Abstract base for optimizer-owned persistent state.
    Separate from agent memory — stores optimization trajectories.
---
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class OptimizerMemory(ABC):
    r"""
    ## OptimizerMemory — Base for Optimizer Memory

    Modes:
    * ``use_and_store`` — read from and write to memory (default)
    * ``use_only`` — read but don't write (frozen)
    * ``store_only`` — write but don't read (collection phase)
    * ``none`` — disabled
    """

    def __init__(self, mode: str = "use_and_store") -> None:
        if mode not in ("use_and_store", "use_only", "store_only", "none"):
            raise ValueError(f"Unknown mode: {mode}")
        self.mode = mode

    @abstractmethod
    def store(self, entry: dict[str, Any]) -> None:
        """Store an entry."""
        ...

    @abstractmethod
    def retrieve(self, query: Any, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve k relevant entries."""
        ...

    def can_store(self) -> bool:
        return self.mode in ("use_and_store", "store_only")

    def can_retrieve(self) -> bool:
        return self.mode in ("use_and_store", "use_only")

    def state_dict(self) -> dict[str, Any]:
        return {"mode": self.mode}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self.mode = state.get("mode", self.mode)
