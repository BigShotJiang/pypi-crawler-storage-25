"""
---
title: FitnessArchive — Quality-Diversity Fitness Store
summary: >
    Stores (genotype, fitness, behavior_descriptor) for quality-diversity
    evolutionary optimization.
---
"""
from __future__ import annotations

from typing import Any

from learn.optim.memory.base import OptimizerMemory


class FitnessArchive(OptimizerMemory):
    r"""
    ## FitnessArchive — Quality-Diversity Fitness Store

    Stores (genotype, fitness, behavior_descriptor) tuples for
    quality-diversity evolutionary optimization.
    """

    def __init__(
        self,
        max_size: int = 200,
        mode: str = "use_and_store",
    ) -> None:
        super().__init__(mode=mode)
        self.max_size = max_size
        self._entries: list[dict[str, Any]] = []

    def store(self, entry: dict[str, Any]) -> None:
        """Store a genotype with its fitness and behavior."""
        if not self.can_store():
            return
        self._entries.append(entry)
        self._entries.sort(
            key=lambda e: e.get("fitness", 0.0), reverse=True
        )
        self._entries = self._entries[: self.max_size]

    def retrieve(self, query: Any = None, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve top-k entries by fitness."""
        if not self.can_retrieve():
            return []
        return self._entries[:k]

    @property
    def size(self) -> int:
        return len(self._entries)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["entries"] = list(self._entries)
        state["max_size"] = self.max_size
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._entries = state.get("entries", [])
        self.max_size = state.get("max_size", self.max_size)
