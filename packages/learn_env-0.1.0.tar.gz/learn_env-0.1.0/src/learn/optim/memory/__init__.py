"""
---
title: learn.optim.memory — Optimizer Memory
summary: >
    Persistent memory stores for optimizers: trajectory buffers,
    experience memories, caches.
---
"""
from learn.optim.memory.archive import FitnessArchive
from learn.optim.memory.base import OptimizerMemory
from learn.optim.memory.cache import EvaluationCache
from learn.optim.memory.experience import ExperienceBuffer
from learn.optim.memory.hessian_kb import HessianProxyKB
from learn.optim.memory.trajectory import TrajectoryBuffer

__all__ = [
    "EvaluationCache",
    "ExperienceBuffer",
    "FitnessArchive",
    "HessianProxyKB",
    "OptimizerMemory",
    "TrajectoryBuffer",
]
