"""
---
title: EvaluationCache — SHA-256 Keyed Evaluation Cache
summary: >
    Caches evaluation results keyed by SHA-256 hash of inputs
    to prevent redundant evaluations.
---
"""
from __future__ import annotations

import hashlib
from typing import Any

from learn.optim.memory.base import OptimizerMemory


class EvaluationCache(OptimizerMemory):
    r"""
    ## EvaluationCache — SHA-256 Keyed Evaluation Cache

    Caches (input, program, output, score) keyed by SHA-256 hash.
    Prevents redundant evaluations across optimization iterations.
    """

    def __init__(
        self,
        max_size: int = 10000,
        mode: str = "use_and_store",
    ) -> None:
        super().__init__(mode=mode)
        self.max_size = max_size
        self._cache: dict[str, dict[str, Any]] = {}

    @staticmethod
    def _make_key(input_text: str, program_id: str = "") -> str:
        """Create a SHA-256 key from input and program."""
        content = f"{program_id}:{input_text}"
        return hashlib.sha256(content.encode()).hexdigest()

    def store(self, entry: dict[str, Any]) -> None:
        """Cache an evaluation result."""
        if not self.can_store():
            return
        key = self._make_key(
            entry.get("input", ""), entry.get("program_id", "")
        )
        self._cache[key] = entry

        # Evict oldest if over capacity
        if len(self._cache) > self.max_size:
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]

    def lookup(self, input_text: str, program_id: str = "") -> dict[str, Any] | None:
        """Look up a cached evaluation result."""
        if not self.can_retrieve():
            return None
        key = self._make_key(input_text, program_id)
        return self._cache.get(key)

    def retrieve(self, query: Any = None, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve recent cache entries."""
        if not self.can_retrieve():
            return []
        entries = list(self._cache.values())
        return entries[-k:]

    @property
    def size(self) -> int:
        return len(self._cache)

    @property
    def hit_rate(self) -> float:
        """Would need tracking, placeholder."""
        return 0.0

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["cache"] = dict(self._cache)
        state["max_size"] = self.max_size
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._cache = state.get("cache", {})
        self.max_size = state.get("max_size", self.max_size)
