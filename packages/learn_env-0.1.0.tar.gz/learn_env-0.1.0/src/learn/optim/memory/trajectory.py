"""
---
title: TrajectoryBuffer — Score-Sorted (Solution, Score) Pairs
summary: >
    Maintains a sorted buffer of (solution, score) pairs for
    trajectory-based optimization like OPRO.
---
"""
from __future__ import annotations

from typing import Any

from learn.optim.memory.base import OptimizerMemory


class TrajectoryBuffer(OptimizerMemory):
    r"""
    ## TrajectoryBuffer — Score-Sorted Trajectory Memory

    Stores (solution, score) pairs sorted by score. Score-gated
    insertion prevents polluting the buffer with bad solutions.

    Used by: OproOptimizer, AFlow.
    """

    def __init__(
        self,
        max_size: int = 100,
        mode: str = "use_and_store",
        score_gate: float | None = None,
    ) -> None:
        super().__init__(mode=mode)
        self.max_size = max_size
        self.score_gate = score_gate
        self._buffer: list[dict[str, Any]] = []

    def store(self, entry: dict[str, Any]) -> None:
        """Store an entry if it passes the score gate."""
        if not self.can_store():
            return

        score = entry.get("score", 0.0)
        if self.score_gate is not None and score < self.score_gate:
            return

        self._buffer.append(entry)
        self._buffer.sort(key=lambda e: e.get("score", 0.0))
        if len(self._buffer) > self.max_size:
            self._buffer = self._buffer[-self.max_size :]

    def retrieve(self, query: Any = None, k: int = 5) -> list[dict[str, Any]]:
        """Retrieve top-k entries by score."""
        if not self.can_retrieve():
            return []
        return self._buffer[-k:]

    @property
    def best(self) -> dict[str, Any] | None:
        return self._buffer[-1] if self._buffer else None

    @property
    def size(self) -> int:
        return len(self._buffer)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["buffer"] = list(self._buffer)
        state["max_size"] = self.max_size
        state["score_gate"] = self.score_gate
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._buffer = state.get("buffer", [])
        self.max_size = state.get("max_size", self.max_size)
        self.score_gate = state.get("score_gate", self.score_gate)
