"""
---
title: Offline Rollout — Trajectory Simulation API
summary: >
    Branching rollout from intermediate states for step-level reward
    estimation. Addresses API Issue #21.
---

# Offline Rollout

Process-supervised methods need to:
1. Extract intermediate states from a trajectory
2. Roll out completions from each state
3. Score each rollout to estimate step-level rewards

Used by pDPO, MCTS, and tool-use RL.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from learn.agent.base import Agent


@dataclass
class RolloutStep:
    """A single step in a trajectory."""

    state: str
    action: str
    reward: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Trajectory:
    """A sequence of steps from initial state to terminal."""

    steps: list[RolloutStep] = field(default_factory=list)
    total_reward: float = 0.0

    def add_step(self, state: str, action: str, reward: float = 0.0) -> None:
        """Add a step to the trajectory."""
        self.steps.append(RolloutStep(state=state, action=action, reward=reward))
        self.total_reward += reward

    def get_prefix(self, step_idx: int) -> str:
        """Get the trajectory prefix up to (excluding) step_idx."""
        parts = []
        for s in self.steps[:step_idx]:
            parts.append(f"{s.state}\n{s.action}")
        return "\n".join(parts)


class RolloutEngine:
    r"""
    <a id="RolloutEngine"></a>

    ## RolloutEngine

    Performs offline rollouts from intermediate trajectory states.

    ```python
    rollout = RolloutEngine(
        agent=generator,
        reward_fn=lambda state: score(state),
        n_rollouts=5,
    )
    # Estimate step-level rewards from a trajectory
    step_rewards = rollout.estimate_step_rewards(trajectory)
    ```
    """

    def __init__(
        self,
        agent: Agent,
        reward_fn: Callable[[str], float],
        n_rollouts: int = 5,
        max_steps: int = 10,
    ) -> None:
        self.agent = agent
        self.reward_fn = reward_fn
        self.n_rollouts = n_rollouts
        self.max_steps = max_steps

    def rollout_from_state(self, state: str) -> list[float]:
        """Perform n rollouts from a given state and return rewards.

        Args:
            state: The starting state text.

        Returns:
            List of rewards from each rollout.
        """
        from learn.env.program.variable import TextState

        rewards = []
        for _ in range(self.n_rollouts):
            current = state
            for _ in range(self.max_steps):
                text_state = TextState(observation=current)
                output = self.agent(text_state)
                current = output.observation
                # Check if terminal (simple heuristic: agent produces
                # short response or repeats)
                if len(current.strip()) < 5:
                    break
            rewards.append(self.reward_fn(current))
        return rewards

    def estimate_step_rewards(self, trajectory: Trajectory) -> list[float]:
        """Estimate per-step rewards via Monte Carlo rollouts.

        For each step in the trajectory, branches from that state
        and averages rollout rewards to estimate step-level value.

        Args:
            trajectory: The trajectory to evaluate.

        Returns:
            List of estimated rewards, one per step.
        """
        step_rewards = []
        for i in range(len(trajectory.steps)):
            prefix = trajectory.get_prefix(i)
            if not prefix:
                prefix = trajectory.steps[i].state
            rollout_rewards = self.rollout_from_state(prefix)
            avg_reward = sum(rollout_rewards) / max(len(rollout_rewards), 1)
            step_rewards.append(avg_reward)
        return step_rewards

    def rollout_from_trajectory(
        self,
        trajectory: Trajectory,
        step_idx: int,
    ) -> list[float]:
        """Branch rollouts from a specific step in a trajectory.

        Args:
            trajectory: Source trajectory.
            step_idx: Step index to branch from.

        Returns:
            List of rewards from each rollout.
        """
        prefix = trajectory.get_prefix(step_idx)
        return self.rollout_from_state(prefix)
