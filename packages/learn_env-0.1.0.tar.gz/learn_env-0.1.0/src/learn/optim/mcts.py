"""
---
title: MCTS — Monte Carlo Tree Search Framework
summary: >
    General-purpose MCTS implementation for LLM-based search.
    Addresses API Issue #24: each example reimplementing 300+ lines
    of MCTS boilerplate.
---

# Monte Carlo Tree Search

MCTS with UCB1/PUCT selection, configurable expansion and simulation
functions. Used by Optima (conversation search), ToolEVO (tool search),
and DPO trajectory extraction.

Selection: $\\text{UCB1}(s) = \\frac{Q(s)}{N(s)} + c\\sqrt{\\frac{\\ln N(\\text{parent})}{N(s)}}$
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, TypeVar

T = TypeVar("T")


@dataclass
class MCTSNode(Generic[T]):
    """A node in the MCTS tree.

    Attributes:
        state: Application-specific state at this node.
        parent: Parent node (None for root).
        children: List of child nodes.
        visits: Number of times this node was visited.
        value: Cumulative value from simulations.
        prior: Prior probability (for PUCT).
        action: Action that led to this node from parent.
    """

    state: T
    parent: MCTSNode[T] | None = None
    children: list[MCTSNode[T]] = field(default_factory=list)
    visits: int = 0
    value: float = 0.0
    prior: float = 1.0
    action: Any = None

    @property
    def q_value(self) -> float:
        """Average value (exploitation term)."""
        return self.value / max(self.visits, 1)

    def is_leaf(self) -> bool:
        return len(self.children) == 0

    def is_root(self) -> bool:
        return self.parent is None

    def best_child(self, c: float = 1.414) -> MCTSNode[T]:
        """Select child with highest UCB1 score.

        Args:
            c: Exploration constant.

        Returns:
            Child with highest UCB1 value.
        """
        if not self.children:
            raise ValueError("No children to select from")

        def ucb1(child: MCTSNode[T]) -> float:
            if child.visits == 0:
                return float("inf")
            exploit = child.q_value
            explore = c * math.sqrt(math.log(self.visits) / child.visits)
            return exploit + explore

        return max(self.children, key=ucb1)

    def best_child_puct(self, c: float = 1.0) -> MCTSNode[T]:
        """Select child with highest PUCT score (AlphaGo-style).

        $$\\text{PUCT}(s) = Q(s) + c \\cdot P(s) \\cdot
        \\frac{\\sqrt{N(\\text{parent})}}{1 + N(s)}$$
        """
        if not self.children:
            raise ValueError("No children to select from")

        def puct(child: MCTSNode[T]) -> float:
            exploit = child.q_value
            explore = c * child.prior * math.sqrt(self.visits) / (1 + child.visits)
            return exploit + explore

        return max(self.children, key=puct)

    def backpropagate(self, reward: float) -> None:
        """Propagate reward up to root."""
        node: MCTSNode[T] | None = self
        while node is not None:
            node.visits += 1
            node.value += reward
            node = node.parent


class MCTS(Generic[T]):
    r"""
    <a id="MCTS"></a>

    ## MCTS

    General-purpose Monte Carlo Tree Search.

    ```python
    mcts = MCTS(
        expand_fn=lambda node: generate_children(node.state),
        simulate_fn=lambda state: run_to_completion(state),
        reward_fn=lambda state: score(state),
        n_iterations=100,
    )
    best = mcts.search(initial_state)
    ```
    """

    def __init__(
        self,
        expand_fn: Callable[[MCTSNode[T]], list[tuple[T, Any]]],
        simulate_fn: Callable[[T], T] | None = None,
        reward_fn: Callable[[T], float] | None = None,
        n_iterations: int = 100,
        exploration_constant: float = 1.414,
        selection_policy: str = "ucb1",
        max_depth: int = 50,
    ) -> None:
        """Initialize MCTS.

        Args:
            expand_fn: Given a node, returns list of (child_state, action)
                pairs for expansion.
            simulate_fn: Given a state, simulates to terminal and returns
                final state. If None, uses reward_fn directly on leaf.
            reward_fn: Scores a state. Returns float reward.
            n_iterations: Number of search iterations.
            exploration_constant: UCB1/PUCT exploration parameter.
            selection_policy: "ucb1" or "puct".
            max_depth: Maximum tree depth.
        """
        self.expand_fn = expand_fn
        self.simulate_fn = simulate_fn
        self.reward_fn = reward_fn or (lambda s: 0.0)
        self.n_iterations = n_iterations
        self.c = exploration_constant
        self.selection_policy = selection_policy
        self.max_depth = max_depth

    def _select(self, node: MCTSNode[T]) -> MCTSNode[T]:
        """Selection phase: traverse tree using selection policy."""
        depth = 0
        while not node.is_leaf() and depth < self.max_depth:
            if self.selection_policy == "puct":
                node = node.best_child_puct(self.c)
            else:
                node = node.best_child(self.c)
            depth += 1
        return node

    def _expand(self, node: MCTSNode[T]) -> MCTSNode[T]:
        """Expansion phase: add children to a leaf node."""
        children_specs = self.expand_fn(node)
        for child_state, action in children_specs:
            child = MCTSNode(
                state=child_state,
                parent=node,
                action=action,
            )
            node.children.append(child)

        # Return a random child for simulation
        if node.children:
            return random.choice(node.children)
        return node

    def _simulate(self, node: MCTSNode[T]) -> float:
        """Simulation phase: roll out to terminal state."""
        state = node.state
        if self.simulate_fn:
            state = self.simulate_fn(state)
        return self.reward_fn(state)

    def search(self, initial_state: T) -> MCTSNode[T]:
        """Run MCTS from the initial state.

        Args:
            initial_state: Root state to search from.

        Returns:
            The root node with search statistics populated.
        """
        root = MCTSNode(state=initial_state)

        for _ in range(self.n_iterations):
            # Select
            leaf = self._select(root)
            # Expand
            child = self._expand(leaf)
            # Simulate
            reward = self._simulate(child)
            # Backpropagate
            child.backpropagate(reward)

        return root

    def best_action(self, root: MCTSNode[T]) -> Any:
        """Return the action of the most-visited child."""
        if not root.children:
            return None
        best = max(root.children, key=lambda c: c.visits)
        return best.action

    def best_path(self, root: MCTSNode[T]) -> list[MCTSNode[T]]:
        """Return the path following most-visited children."""
        path = [root]
        node = root
        while node.children:
            node = max(node.children, key=lambda c: c.visits)
            path.append(node)
        return path

    def extract_preference_pairs(
        self,
        root: MCTSNode[T],
        min_gap: float = 0.1,
    ) -> list[tuple[T, T]]:
        """Extract (preferred, rejected) pairs for DPO training.

        Compares sibling nodes: the higher-value sibling is preferred.

        Args:
            root: Root of the search tree.
            min_gap: Minimum value gap to form a pair.

        Returns:
            List of (preferred_state, rejected_state) tuples.
        """
        pairs: list[tuple[T, T]] = []
        self._collect_pairs(root, min_gap, pairs)
        return pairs

    def _collect_pairs(
        self,
        node: MCTSNode[T],
        min_gap: float,
        pairs: list[tuple[T, T]],
    ) -> None:
        """Recursively collect preference pairs from siblings."""
        if len(node.children) >= 2:
            scored = [
                (c.q_value, c) for c in node.children if c.visits > 0
            ]
            scored.sort(key=lambda x: x[0], reverse=True)
            for i in range(len(scored)):
                for j in range(i + 1, len(scored)):
                    if scored[i][0] - scored[j][0] >= min_gap:
                        pairs.append((scored[i][1].state, scored[j][1].state))

        for child in node.children:
            self._collect_pairs(child, min_gap, pairs)
