"""
---
title: Population — Fitness-Sorted Collection of Genotypes
summary: >
    Thread-safe, fitness-sorted collection of candidate genotypes
    with selection, sampling, and diversity metrics.
---
"""
from __future__ import annotations

import random
from typing import Any

from learn.optim.evol.genotype import Genotype


class Population:
    r"""
    ## Population

    Fitness-sorted collection of candidate genotypes.
    Supports add, remove, select, and diversity metrics.
    """

    def __init__(self, max_size: int = 100) -> None:
        self.max_size = max_size
        self._members: list[Genotype] = []

    def add(self, genotype: Genotype) -> None:
        """Add a genotype, evicting the worst if at capacity."""
        self._members.append(genotype)
        self._members.sort(
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
            reverse=True,
        )
        if len(self._members) > self.max_size:
            self._members = self._members[: self.max_size]

    def remove(self, genotype: Genotype) -> None:
        """Remove a specific genotype."""
        self._members = [g for g in self._members if g is not genotype]

    def select(self, k: int) -> list[Genotype]:
        """Select top-k genotypes by fitness."""
        return self._members[:k]

    def sample(self, k: int) -> list[Genotype]:
        """Randomly sample k genotypes."""
        k = min(k, len(self._members))
        return random.sample(self._members, k)

    def best(self) -> Genotype | None:
        """Return the best genotype."""
        return self._members[0] if self._members else None

    def diversity_score(self) -> float:
        """Compute a simple diversity metric based on prompt uniqueness."""
        if len(self._members) <= 1:
            return 0.0
        prompts = set()
        for g in self._members:
            for v in g.prompts.values():
                prompts.add(v)
        return len(prompts) / max(len(self._members), 1)

    @property
    def size(self) -> int:
        return len(self._members)

    @property
    def members(self) -> list[Genotype]:
        return list(self._members)

    def state_dict(self) -> dict[str, Any]:
        return {
            "max_size": self.max_size,
            "members": [g.to_dict() for g in self._members],
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self.max_size = state.get("max_size", self.max_size)
        self._members = [
            Genotype.from_dict(d) for d in state.get("members", [])
        ]

    def __len__(self) -> int:
        return len(self._members)

    def __iter__(self):
        return iter(self._members)
