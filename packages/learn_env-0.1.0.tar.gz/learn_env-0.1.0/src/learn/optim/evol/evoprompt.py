"""
---
title: EvoPrompt — GA and DE Prompt Optimizers
summary: >
    Discrete prompt optimization via evolutionary algorithms. LLMs
    serve as the evolutionary operators (crossover, mutation) on
    natural language prompts. Implements both the GA and DE variants
    from Guo et al., ICLR 2024.
---

# EvoPrompt — Connecting LLMs with Evolutionary Algorithms

Port of **EvoPrompt** (Guo, Wang et al., 2024) — arXiv:2309.08532, ICLR 2024.

## Intuition

Prompt engineering is combinatorial search over natural language space.
EvoPrompt applies evolutionary algorithms (GA, DE) to this search space,
using the LLM itself as the crossover/mutation operator.

The LLM is given a 1-shot example of how the evolutionary operator works,
then asked to apply the same operation to the actual prompts.

## Algorithms

### Genetic Algorithm (GA)

1. **Selection:** Roulette-wheel selection (fitness-proportional) picks
   two parents $p_1, p_2$.
2. **Crossover + Mutation** (single LLM call using ``GA_TEMPLATE``):
   The LLM first crosses over $p_1$ and $p_2$, then mutates the result.
3. **Update:** Merge parent population and offspring; keep top-$N$.

### Differential Evolution (DE)

1. For each target $x_i$ in population:
2. **Donor:** Identify differences between $p_a$ and $p_b$; mutate those
   differences; combine with $x_{\\text{best}}$ → donor vector.
3. **Trial:** Crossover donor with $x_i$ (using ``DE_TEMPLATE``).
4. **Selection:** Keep better of $\\{x_i, \\text{trial}\\}$ (greedy).

## PyTorch Analogy

| PyTorch | EvoPrompt |
|---------|-----------| 
| ``nn.Parameter`` | ``Genotype.prompts["system_prompt"]`` |
| SGD step | GA/DE evolution step |
| Loss function | ``fitness_fn`` (dev-set accuracy) |

## Usage

```python
from learn.optim.evol.evoprompt import GAOptimizer, DEOptimizer

# GA
ga = GAOptimizer(
    params=[prompt_param],
    engine=engine,
    fitness_fn=lambda g: evaluate_prompt(g.prompts["system_prompt"], ...),
    population_size=10,
    num_generations=20,
)
ga.seed([Genotype(prompts={"system_prompt": init_prompt})])
best = ga.run()

# DE
de = DEOptimizer(
    params=[prompt_param],
    engine=engine,
    fitness_fn=lambda g: evaluate_prompt(g.prompts["system_prompt"], ...),
    population_size=10,
    num_generations=20,
)
de.seed([Genotype(prompts={"system_prompt": init_prompt})])
best = de.run()
```
"""
from __future__ import annotations

import random
import re
from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# 1-shot prompt templates — faithfully reproduced from the original repo
# (data/template_ga.py and data/template_de.py for the "cls" / "sim" variants)
# ---------------------------------------------------------------------------

GA_TEMPLATE = """\
Please follow the instruction step-by-step to generate a better prompt.
1. Crossover the following prompts and generate a new prompt:
Prompt 1: Rewrite the input text into simpler text.
Prompt 2: Rewrite my complex sentence in simpler terms, but keep the meaning.
2. Mutate the prompt generated in Step 1 and generate a final prompt \
bracketed with <prompt> and </prompt>.

1. Crossover Prompt: Rewrite the complex text into simpler text while \
keeping its meaning.
2. <prompt>Transform the provided text into simpler language, \
maintaining its essence.</prompt>

Please follow the instruction step-by-step to generate a better prompt.
1. Crossover the following prompts and generate a new prompt:
Prompt 1: {prompt1}
Prompt 2: {prompt2}
2. Mutate the prompt generated in Step 1 and generate a final prompt \
bracketed with <prompt> and </prompt>.

1. """

DE_TEMPLATE = """\
Please follow the instruction step-by-step to generate a better prompt.
1. Identify the different parts between the Prompt 1 and Prompt 2:
Prompt 1: Rewrite the input text into simpler text.
Prompt 2: Rewrite my complex sentence in simpler terms, but keep the meaning.
2. Randomly mutate the different parts
3. Combine the different parts with Prompt 3, selectively replace it \
with the different parts in step 2 and generate a new prompt.
Prompt 3: Rewrite the given input text into simpler English sentences \
while preserving the same meaning, so it can be understood by non-native \
English speakers.
4. Crossover the prompt in the step3 with the following basic prompt \
and generate a final prompt bracketed with <prompt> and </prompt>:
Basic Prompt: Make the sentence easier for people who do not speak \
English fluently to comprehend.

1. "input text into simpler text" vs "my complex sentence in simpler \
terms, but keep the meaning"
2. "input content into basic language" vs "my hard paragraph in easier \
words, while retaining the sense"
3. Rewrite the given input content into basic English language while \
retaining the same sense, so it can be understood by non-native English \
speakers.
4. <prompt>Simplify the given text for easier understanding by \
non-native speakers.</prompt>

Please follow the instruction step-by-step to generate a better prompt.
1. Identify the different parts between the Prompt 1 and Prompt 2:
Prompt 1: {prompt1}
Prompt 2: {prompt2}
2. Randomly mutate the different parts
3. Combine the different parts with Prompt 3, selectively replace it \
with the different parts in step 2 and generate a new prompt.
Prompt 3: {prompt3}
4. Crossover the prompt in the step3 with the following basic prompt \
and generate a final prompt bracketed with <prompt> and </prompt>:
Basic Prompt: {prompt0}

1. """

PARAPHRASE_TEMPLATE = """\
Generate a variation of the following instruction while keeping the \
semantic meaning.
Input: {sentence}
Output:"""


def _extract_prompt(text: str) -> str:
    """Extract text between ``<prompt>`` tags; fall back to stripped text."""
    match = re.search(r"<prompt>(.*?)</prompt>", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()


def _prompt_key(genotype: Genotype, key: str = "system_prompt") -> str:
    """Return the primary prompt string from a genotype."""
    prompts = genotype.prompts
    if key in prompts:
        return prompts[key]
    # Fallback: first available prompt
    return next(iter(prompts.values()), "")


def _roulette_wheel_select(population: Population) -> Genotype:
    """Fitness-proportional (roulette-wheel) selection.

    Paper Section 3.2: probability $p_i = s_i / \\sum s_j$.
    Falls back to uniform random if all fitness values are zero.
    """
    candidates = [g for g in population if g.fitness is not None]
    if not candidates:
        return random.choice(list(population))
    total = sum(g.fitness for g in candidates)  # type: ignore[arg-type]
    if total <= 0:
        return random.choice(candidates)
    r = random.uniform(0, total)
    cumsum = 0.0
    for g in candidates:
        cumsum += g.fitness  # type: ignore[operator]
        if cumsum >= r:
            return g
    return candidates[-1]


def _generate_paraphrase(engine: EngineLM, prompt: str) -> str:
    """Generate a paraphrase of a prompt for population initialization."""
    response = engine.generate(PARAPHRASE_TEMPLATE.format(sentence=prompt))
    return response.strip() or prompt


# ---------------------------------------------------------------------------
# GAOptimizer
# ---------------------------------------------------------------------------


class GAOptimizer(EvolOptimizer):
    r"""
    ## GAOptimizer — EvoPrompt Genetic Algorithm

    Optimizes prompts using a genetic algorithm where the LLM serves as
    the crossover+mutation operator.  Uses a 1-shot template that
    instructs the LLM to (1) crossover two parent prompts and (2) mutate
    the result in a single call.

    **Selection:** Roulette-wheel (fitness-proportional).

    **Update:** Merge offspring with parents; keep top-$N$ by fitness.

    Reference: EvoPrompt GA (Guo et al., ICLR 2024) arXiv:2309.08532

    ```python
    ga = GAOptimizer(
        params=[param], engine=engine,
        fitness_fn=lambda g: score(g, val_data),
        population_size=10, num_generations=20,
    )
    ga.seed([Genotype(prompts={"system_prompt": "Answer the question."})])
    best = ga.run()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        fitness_fn: Callable[[Genotype], float] | None = None,
        population_size: int = 10,
        num_generations: int = 20,
        prompt_key: str = "system_prompt",
        seed_with_paraphrase: bool = True,
    ) -> None:
        super().__init__(params, engine=engine)
        self.fitness_fn = fitness_fn
        self.population_size = population_size
        self.num_generations = num_generations
        self.prompt_key = prompt_key
        self.seed_with_paraphrase = seed_with_paraphrase
        self.population = Population(max_size=population_size)
        self._generation = 0
        self.best: Genotype | None = None

    def seed(self, genotypes: list[Genotype]) -> None:
        """Add initial genotypes to the population.

        If ``seed_with_paraphrase`` is True and population needs to grow,
        paraphrases of the provided genotypes are generated to fill it.
        """
        for g in genotypes:
            self.population.add(g)

        # Fill population with paraphrases if needed
        if self.seed_with_paraphrase and self.engine is not None:
            existing = list(self.population)
            while len(self.population) < self.population_size and existing:
                base = random.choice(existing)
                base_prompt = _prompt_key(base, self.prompt_key)
                new_prompt = _generate_paraphrase(self.engine, base_prompt)
                self.population.add(
                    Genotype(
                        prompts={self.prompt_key: new_prompt},
                        generation=0,
                    )
                )

    def _ga_step(self) -> Genotype:
        """One GA step: select two parents → crossover+mutate via LLM.

        Uses the original 1-shot ``GA_TEMPLATE`` (Appendix B of the paper).
        """
        assert self.engine is not None
        p1 = _roulette_wheel_select(self.population)
        p2 = _roulette_wheel_select(self.population)

        prompt1 = _prompt_key(p1, self.prompt_key)
        prompt2 = _prompt_key(p2, self.prompt_key)

        request = GA_TEMPLATE.format(prompt1=prompt1, prompt2=prompt2)
        response = self.engine.generate(request)
        child_prompt = _extract_prompt(response)

        return Genotype(
            prompts={self.prompt_key: child_prompt},
            parent_ids=[id(p1), id(p2)],  # type: ignore[list-item]
            generation=self._generation,
        )

    def evolve_step(self) -> None:
        """Run one generation: generate ``population_size`` offspring → update.

        Paper Section 3.2: generates N new prompts, merges with parent
        population, keeps top-N.
        """
        offspring: list[Genotype] = []
        for _ in range(self.population_size):
            child = self._ga_step()
            if self.fitness_fn is not None:
                child.fitness = self.fitness_fn(child)
            offspring.append(child)

        # Evaluate unevaluated parents
        for g in self.population:
            if g.fitness is None and self.fitness_fn is not None:
                g.fitness = self.fitness_fn(g)

        # Merge and keep top-N
        all_candidates = list(self.population) + offspring
        all_candidates.sort(
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
            reverse=True,
        )
        self.population = Population(max_size=self.population_size)
        for g in all_candidates[: self.population_size]:
            self.population.add(g)

        # Update best
        top = all_candidates[0] if all_candidates else None
        if top is not None and (
            self.best is None
            or (top.fitness is not None and (self.best.fitness or 0) < top.fitness)
        ):
            self.best = top

        self._generation += 1

    def step(self) -> None:
        """Alias for ``evolve_step()``."""
        self.evolve_step()

    def run(self) -> Genotype | None:
        """Run ``num_generations`` evolution steps and return the best genotype."""
        for _ in range(self.num_generations):
            self.evolve_step()
        return self.best

    def parameters(self):
        return iter(self.params)


# ---------------------------------------------------------------------------
# DEOptimizer
# ---------------------------------------------------------------------------


class DEOptimizer(EvolOptimizer):
    r"""
    ## DEOptimizer — EvoPrompt Differential Evolution

    Optimizes prompts using a DE/best/1 variant where the LLM implements
    the four DE steps via a 1-shot template:

    1. Identify differences between $p_a$ and $p_b$
    2. Randomly mutate those differences
    3. Combine mutated parts with best prompt $x_{\\text{best}}$
    4. Crossover with target prompt $x_i$

    **Selection:** Greedy — keep the better of target vs. trial.

    Reference: EvoPrompt DE (Guo et al., ICLR 2024) arXiv:2309.08532

    ```python
    de = DEOptimizer(
        params=[param], engine=engine,
        fitness_fn=lambda g: score(g, val_data),
        population_size=10, num_generations=20,
    )
    de.seed([Genotype(prompts={"system_prompt": "Answer the question."})])
    best = de.run()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        fitness_fn: Callable[[Genotype], float] | None = None,
        population_size: int = 10,
        num_generations: int = 20,
        prompt_key: str = "system_prompt",
        seed_with_paraphrase: bool = True,
    ) -> None:
        super().__init__(params, engine=engine)
        self.fitness_fn = fitness_fn
        self.population_size = population_size
        self.num_generations = num_generations
        self.prompt_key = prompt_key
        self.seed_with_paraphrase = seed_with_paraphrase
        self.population = Population(max_size=population_size)
        self._generation = 0
        self.best: Genotype | None = None

    def seed(self, genotypes: list[Genotype]) -> None:
        """Add initial genotypes; fill with paraphrases if needed."""
        for g in genotypes:
            self.population.add(g)

        if self.seed_with_paraphrase and self.engine is not None:
            existing = list(self.population)
            while len(self.population) < self.population_size and existing:
                base = random.choice(existing)
                base_prompt = _prompt_key(base, self.prompt_key)
                new_prompt = _generate_paraphrase(self.engine, base_prompt)
                self.population.add(
                    Genotype(
                        prompts={self.prompt_key: new_prompt},
                        generation=0,
                    )
                )

    def _de_trial(
        self,
        target: Genotype,
        donor_a: Genotype,
        donor_b: Genotype,
        best: Genotype,
    ) -> Genotype:
        """Generate one DE trial vector.

        Uses the original 1-shot ``DE_TEMPLATE``:
        - ``prompt1`` / ``prompt2``: the two randomly selected prompts
          (analogous to $x_a - x_b$ — their differences)
        - ``prompt3``: the best prompt (analogous to $x_{\\text{best}}$)
        - ``prompt0``: the target prompt $x_i$ (for crossover in step 4)
        """
        assert self.engine is not None
        request = DE_TEMPLATE.format(
            prompt1=_prompt_key(donor_a, self.prompt_key),
            prompt2=_prompt_key(donor_b, self.prompt_key),
            prompt3=_prompt_key(best, self.prompt_key),
            prompt0=_prompt_key(target, self.prompt_key),
        )
        response = self.engine.generate(request)
        trial_prompt = _extract_prompt(response)
        return Genotype(
            prompts={self.prompt_key: trial_prompt},
            parent_ids=[id(target), id(best)],  # type: ignore[list-item]
            generation=self._generation,
        )

    def _get_best(self) -> Genotype:
        """Return the genotype with the highest fitness in current population."""
        candidates = [g for g in self.population if g.fitness is not None]
        if not candidates:
            return next(iter(self.population))
        return max(candidates, key=lambda g: g.fitness)  # type: ignore[arg-type]

    def evolve_step(self) -> None:
        """Run one DE generation: for each target generate trial, greedily select.

        Paper Section 3.3: each prompt $x_i$ generates a corresponding
        trial $x'_i$; the better of the two is retained.
        """
        members = list(self.population)
        if len(members) < 3:
            return  # Need at least 3 for DE

        # Evaluate unevaluated members first
        for g in members:
            if g.fitness is None and self.fitness_fn is not None:
                g.fitness = self.fitness_fn(g)

        best = self._get_best()
        new_population = Population(max_size=self.population_size)

        for target in members:
            # Sample two distinct donors (not the target itself)
            others = [g for g in members if g is not target]
            if len(others) < 2:
                new_population.add(target)
                continue
            donor_a, donor_b = random.sample(others, 2)

            trial = self._de_trial(target, donor_a, donor_b, best)
            if self.fitness_fn is not None:
                trial.fitness = self.fitness_fn(trial)

            # Greedy selection: keep better of target vs trial
            if trial.fitness is not None and (
                target.fitness is None or trial.fitness > target.fitness
            ):
                new_population.add(trial)
            else:
                new_population.add(target)

        self.population = new_population

        # Update best
        top = self._get_best()
        if self.best is None or (
            top.fitness is not None
            and (self.best.fitness is None or top.fitness > self.best.fitness)
        ):
            self.best = top

        self._generation += 1

    def step(self) -> None:
        """Alias for ``evolve_step()``."""
        self.evolve_step()

    def run(self) -> Genotype | None:
        """Run ``num_generations`` evolution steps and return the best genotype."""
        for _ in range(self.num_generations):
            self.evolve_step()
        return self.best

    def parameters(self):
        return iter(self.params)
