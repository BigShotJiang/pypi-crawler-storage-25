"""
---
title: CoEvolution — Co-Evolving Environments and Agents
summary: >
    Evolves environments alongside agents for robust optimization.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class CoEvolution(EvolOptimizer):
    r"""
    ## CoEvolution — Co-Evolutionary Optimization

    Maintains two populations: agents and environments. Agents are
    evaluated on environments and vice versa.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        agent_population_size: int = 10,
        env_population_size: int = 10,
        fitness_fn: Callable[[Genotype, Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.agent_pop = Population(max_size=agent_population_size)
        self.env_pop = Population(max_size=env_population_size)
        self.fitness_fn = fitness_fn

    def step(self) -> None:
        """One co-evolutionary step."""
        # Evaluate agent-environment pairs
        if self.fitness_fn and self.agent_pop.size > 0 and self.env_pop.size > 0:
            for agent in self.agent_pop.members:
                scores = []
                for env in self.env_pop.members:
                    scores.append(self.fitness_fn(agent, env))
                agent.fitness = sum(scores) / len(scores) if scores else 0.0

    def propose(self) -> None:
        best = self.agent_pop.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])
