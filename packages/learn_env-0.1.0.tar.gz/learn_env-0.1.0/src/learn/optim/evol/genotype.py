"""
---
title: Genotype — Serializable Agent/Program Configuration
summary: >
    A complete specification of an agent or program configuration,
    including prompts, structure, hyperparameters, and fitness.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Genotype:
    r"""
    ## Genotype

    Serializable specification of a complete agent/program configuration.
    The evolutionary analog of a neural architecture description +
    weight initialization.

    Fields:
    * ``prompts`` — agent name → prompt text
    * ``graph_structure`` — node → list of downstream node names
    * ``hyperparams`` — temperature, max_tokens, etc.
    * ``routing_weights`` — for MoE/router configs
    * ``fitness`` — evaluation score (None if unevaluated)
    * ``parent_ids`` — lineage tracking
    * ``generation`` — which generation created this
    * ``metadata`` — arbitrary additional info
    """

    prompts: dict[str, str] = field(default_factory=dict)
    graph_structure: dict[str, list[str]] = field(default_factory=dict)
    hyperparams: dict[str, Any] = field(default_factory=dict)
    routing_weights: dict[str, list[float]] = field(default_factory=dict)
    fitness: float | None = None
    parent_ids: list[str] = field(default_factory=list)
    generation: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "prompts": dict(self.prompts),
            "graph_structure": {k: list(v) for k, v in self.graph_structure.items()},
            "hyperparams": dict(self.hyperparams),
            "routing_weights": {k: list(v) for k, v in self.routing_weights.items()},
            "fitness": self.fitness,
            "parent_ids": list(self.parent_ids),
            "generation": self.generation,
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Genotype:
        """Deserialize from dictionary."""
        return cls(
            prompts=data.get("prompts", {}),
            graph_structure=data.get("graph_structure", {}),
            hyperparams=data.get("hyperparams", {}),
            routing_weights=data.get("routing_weights", {}),
            fitness=data.get("fitness"),
            parent_ids=data.get("parent_ids", []),
            generation=data.get("generation", 0),
            metadata=data.get("metadata", {}),
        )

    def clone(self) -> Genotype:
        """Create a deep copy."""
        return Genotype.from_dict(self.to_dict())
