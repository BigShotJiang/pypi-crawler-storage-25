"""
---
title: EvolOptimizer — Base for Evolutionary Optimizers
summary: >
    Abstract base for population-based evolutionary optimization.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class EvolOptimizer(Optimizer):
    r"""
    ## EvolOptimizer

    Base class for evolutionary optimization. Extends Optimizer with
    population-based search semantics.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
