"""
---
title: LinearEvolution — Simplified Single-Population Evolution
summary: >
    Simple evolutionary loop: seed → evaluate → select → mutate/crossover.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import (
    CrossoverOperator,
    LLMCrossover,
    LLMMutation,
    MutationOperator,
    SelectionOperator,
    TournamentSelection,
)
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class LinearEvolution(EvolOptimizer):
    r"""
    ## LinearEvolution — Simple Evolutionary Loop

    Single-population evolution: select parents → crossover → mutate →
    evaluate → add to population.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        population_size: int = 20,
        mutation: MutationOperator | None = None,
        crossover: CrossoverOperator | None = None,
        selection: SelectionOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.population = Population(max_size=population_size)
        self.mutation = mutation or LLMMutation()
        self.crossover = crossover or LLMCrossover()
        self.selection = selection or TournamentSelection()
        self.fitness_fn = fitness_fn
        self._generation = 0

    def seed(self, genotypes: list[Genotype]) -> None:
        """Add initial genotypes."""
        for g in genotypes:
            self.population.add(g)

    def evolve_step(self) -> None:
        """One evolution generation."""
        if self.population.size < 2:
            return

        parents = self.selection.select(self.population, 2)
        if len(parents) < 2:
            return

        child = self.crossover.crossover(parents[0], parents[1], self.engine)
        child = self.mutation.mutate(child, self.engine)

        if self.fitness_fn is not None:
            child.fitness = self.fitness_fn(child)

        self.population.add(child)
        self._generation += 1

    def step(self) -> None:
        self.evolve_step()

    def propose(self) -> None:
        best = self.population.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])

    def best(self) -> Genotype | None:
        return self.population.best()
