"""
---
title: IslandModel — Multi-Population with Migration
summary: >
    Multiple sub-populations (islands) evolving independently with
    periodic migration of top individuals between islands.
---
"""
from __future__ import annotations

import random
from typing import TYPE_CHECKING, Any, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import (
    CrossoverOperator,
    LLMCrossover,
    LLMMutation,
    MutationOperator,
    SelectionOperator,
    TournamentSelection,
)
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class IslandModel(EvolOptimizer):
    r"""
    ## IslandModel — Multi-Population with Migration

    Maintains multiple sub-populations that evolve independently.
    Periodically, top individuals migrate between islands.

    Migration policies: ring, random, fitness-based.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        num_islands: int = 3,
        island_size: int = 20,
        migration_rate: int = 5,
        migration_size: int = 2,
        migration_policy: str = "ring",
        mutation: MutationOperator | None = None,
        crossover: CrossoverOperator | None = None,
        selection: SelectionOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.num_islands = num_islands
        self.migration_rate = migration_rate
        self.migration_size = migration_size
        self.migration_policy = migration_policy
        self.mutation = mutation or LLMMutation()
        self.crossover = crossover or LLMCrossover()
        self.selection = selection or TournamentSelection()
        self.fitness_fn = fitness_fn
        self._generation = 0

        self.islands = [Population(max_size=island_size) for _ in range(num_islands)]

    def seed(self, genotypes: list[Genotype]) -> None:
        """Distribute initial genotypes across islands."""
        for i, g in enumerate(genotypes):
            self.islands[i % self.num_islands].add(g)

    def evolve_step(self) -> None:
        """One generation: select, crossover, mutate, evaluate on each island."""
        for island in self.islands:
            if island.size < 2:
                continue

            # Select parents
            parents = self.selection.select(island, 2)
            if len(parents) < 2:
                continue

            # Crossover
            child = self.crossover.crossover(parents[0], parents[1], self.engine)

            # Mutate
            child = self.mutation.mutate(child, self.engine)

            # Evaluate if we have a fitness function
            if self.fitness_fn is not None:
                child.fitness = self.fitness_fn(child)

            island.add(child)

        self._generation += 1

        # Migrate
        if self._generation % self.migration_rate == 0:
            self._migrate()

    def _migrate(self) -> None:
        """Migrate top individuals between islands."""
        if self.migration_policy == "ring":
            self._ring_migration()
        elif self.migration_policy == "random":
            self._random_migration()
        else:
            self._ring_migration()

    def _ring_migration(self) -> None:
        """Ring migration: island i → island (i+1) % n."""
        migrants = []
        for island in self.islands:
            top = island.select(self.migration_size)
            migrants.append([g.clone() for g in top])

        for i, island_migrants in enumerate(migrants):
            target = (i + 1) % self.num_islands
            for g in island_migrants:
                self.islands[target].add(g)

    def _random_migration(self) -> None:
        """Random migration: each migrant goes to a random other island."""
        for i, island in enumerate(self.islands):
            top = island.select(self.migration_size)
            for g in top:
                targets = [j for j in range(self.num_islands) if j != i]
                if targets:
                    target = random.choice(targets)
                    self.islands[target].add(g.clone())

    def best(self) -> Genotype | None:
        """Return the best genotype across all islands."""
        all_best = [island.best() for island in self.islands]
        valid = [g for g in all_best if g is not None]
        if not valid:
            return None
        return max(
            valid,
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
        )

    def step(self) -> None:
        """Perform one evolution step."""
        self.evolve_step()

    def propose(self) -> None:
        """Propose updates using the best genotype."""
        best = self.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["islands"] = [isl.state_dict() for isl in self.islands]
        state["generation"] = self._generation
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        for isl, isl_state in zip(self.islands, state.get("islands", [])):
            isl.load_state_dict(isl_state)
        self._generation = state.get("generation", 0)
