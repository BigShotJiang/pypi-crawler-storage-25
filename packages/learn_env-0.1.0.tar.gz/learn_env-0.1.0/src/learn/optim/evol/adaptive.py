"""
---
title: AdaptiveControl — Improvement-Signal Driven Adaptation
summary: >
    Adapts mutation rate and exploration intensity based on
    improvement signal.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AdaptiveControl:
    r"""
    ## AdaptiveControl — Adaptive Exploration Controller

    Monitors improvement rate and adjusts mutation intensity.
    If improvements stall, increases exploration; if improving
    rapidly, decreases exploration.
    """

    initial_rate: float = 0.5
    min_rate: float = 0.1
    max_rate: float = 0.9
    patience: int = 5
    increase_factor: float = 1.2
    decrease_factor: float = 0.8

    _current_rate: float = field(init=False)
    _stall_count: int = field(init=False, default=0)
    _last_best: float = field(init=False, default=float("-inf"))
    _history: list[float] = field(init=False, default_factory=list)

    def __post_init__(self) -> None:
        self._current_rate = self.initial_rate

    @property
    def mutation_rate(self) -> float:
        return self._current_rate

    def update(self, best_fitness: float) -> None:
        """Update based on improvement signal."""
        self._history.append(best_fitness)

        if best_fitness > self._last_best:
            # Improvement — decrease exploration
            self._current_rate = max(
                self.min_rate, self._current_rate * self.decrease_factor
            )
            self._stall_count = 0
            self._last_best = best_fitness
        else:
            # No improvement — increase exploration
            self._stall_count += 1
            if self._stall_count >= self.patience:
                self._current_rate = min(
                    self.max_rate, self._current_rate * self.increase_factor
                )
                self._stall_count = 0

    def state_dict(self) -> dict[str, Any]:
        return {
            "current_rate": self._current_rate,
            "stall_count": self._stall_count,
            "last_best": self._last_best,
            "history": list(self._history),
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._current_rate = state.get("current_rate", self.initial_rate)
        self._stall_count = state.get("stall_count", 0)
        self._last_best = state.get("last_best", float("-inf"))
        self._history = state.get("history", [])
