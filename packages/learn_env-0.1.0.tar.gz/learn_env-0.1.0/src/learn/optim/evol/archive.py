"""
---
title: Archive — MAP-Elites Quality-Diversity Store
summary: >
    Organizes solutions by behavior characterization, storing the best
    solution for each behavioral niche.
---
"""
from __future__ import annotations

from typing import Any

from learn.optim.evol.genotype import Genotype


class Archive:
    r"""
    ## Archive — MAP-Elites Quality-Diversity Store

    Organizes solutions by behavior characterization. Each cell stores
    the best-fitness solution with that behavior descriptor.
    """

    def __init__(self, behavior_dims: list[str] | None = None) -> None:
        self.behavior_dims = behavior_dims or []
        # Map behavior descriptor tuple → best genotype
        self._elites: dict[tuple[Any, ...], Genotype] = {}

    def add(
        self, genotype: Genotype, behavior_descriptor: tuple[Any, ...]
    ) -> bool:
        """Add a genotype to the archive. Returns True if it was stored."""
        existing = self._elites.get(behavior_descriptor)
        if existing is None or (
            genotype.fitness is not None
            and (existing.fitness is None or genotype.fitness > existing.fitness)
        ):
            self._elites[behavior_descriptor] = genotype
            return True
        return False

    def sample_parents(self, k: int) -> list[Genotype]:
        """Sample k parents from the archive."""
        import random

        elites = list(self._elites.values())
        k = min(k, len(elites))
        return random.sample(elites, k) if elites else []

    def get_inspirations(
        self, query: Genotype, k: int = 3
    ) -> list[Genotype]:
        """Get k diverse solutions as inspiration for mutation."""
        # Sort by fitness, return top-k
        sorted_elites = sorted(
            self._elites.values(),
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
            reverse=True,
        )
        return sorted_elites[:k]

    @property
    def size(self) -> int:
        return len(self._elites)

    @property
    def best(self) -> Genotype | None:
        """Return the best-fitness genotype in the archive."""
        if not self._elites:
            return None
        return max(
            self._elites.values(),
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
        )

    def state_dict(self) -> dict[str, Any]:
        return {
            "behavior_dims": self.behavior_dims,
            "elites": {
                str(k): v.to_dict() for k, v in self._elites.items()
            },
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self.behavior_dims = state.get("behavior_dims", [])
        # Note: keys are serialized as strings
        self._elites = {}
        for k, v in state.get("elites", {}).items():
            self._elites[eval(k)] = Genotype.from_dict(v)  # noqa: S307

    def __len__(self) -> int:
        return len(self._elites)
