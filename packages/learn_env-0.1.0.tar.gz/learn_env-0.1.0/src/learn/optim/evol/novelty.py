"""
---
title: NoveltySearch — Embedding-Based Diversity Maintenance
summary: >
    Promotes diversity by selecting for novelty rather than fitness alone.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import LLMMutation, MutationOperator
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class NoveltySearch(EvolOptimizer):
    r"""
    ## NoveltySearch — Diversity-Driven Evolution

    Promotes diversity by rewarding novelty (distance from existing
    solutions) rather than fitness alone.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        population_size: int = 20,
        mutation: MutationOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
        novelty_weight: float = 0.5,
    ) -> None:
        super().__init__(params, engine=engine)
        self.population = Population(max_size=population_size)
        self.mutation = mutation or LLMMutation()
        self.fitness_fn = fitness_fn
        self.novelty_weight = novelty_weight
        self._archive: list[Genotype] = []

    def seed(self, genotypes: list[Genotype]) -> None:
        for g in genotypes:
            self.population.add(g)

    def _novelty_score(self, genotype: Genotype) -> float:
        """Compute novelty as average word-level distance to archive."""
        if not self._archive:
            return 1.0

        g_words = set()
        for v in genotype.prompts.values():
            g_words.update(v.lower().split())

        distances = []
        for a in self._archive:
            a_words = set()
            for v in a.prompts.values():
                a_words.update(v.lower().split())
            if g_words or a_words:
                jaccard = len(g_words & a_words) / max(len(g_words | a_words), 1)
                distances.append(1.0 - jaccard)
            else:
                distances.append(0.0)

        return sum(distances) / len(distances) if distances else 0.0

    def evolve_step(self) -> None:
        if self.population.size == 0:
            return

        members = self.population.members
        import random

        parent = random.choice(members)
        child = self.mutation.mutate(parent, self.engine)

        fitness = 0.0
        if self.fitness_fn:
            fitness = self.fitness_fn(child)
        novelty = self._novelty_score(child)

        # Combined score
        child.fitness = (
            (1 - self.novelty_weight) * fitness + self.novelty_weight * novelty
        )
        self.population.add(child)
        self._archive.append(child)

    def step(self) -> None:
        self.evolve_step()

    def propose(self) -> None:
        best = self.population.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])
