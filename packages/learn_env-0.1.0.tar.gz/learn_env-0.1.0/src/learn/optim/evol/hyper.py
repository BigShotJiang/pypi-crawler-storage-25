"""
---
title: HyperEvolution — SEW-Style Mutation Prompt Evolution
summary: >
    Evolves the mutation prompts themselves alongside the solutions.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import LLMMutation, MutationOperator
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class HyperEvolution(EvolOptimizer):
    r"""
    ## HyperEvolution — SEW-Style Self-Evolving Mutations

    Evolves the mutation prompts themselves. A meta-population
    of mutation strategies competes alongside the solution population.

    Reference: ShinkaEvolve SEW
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        population_size: int = 20,
        mutation: MutationOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.population = Population(max_size=population_size)
        self.mutation = mutation or LLMMutation()
        self.fitness_fn = fitness_fn
        # Meta-population of mutation prompts
        self._mutation_prompts: list[str] = []

    def seed(self, genotypes: list[Genotype]) -> None:
        for g in genotypes:
            self.population.add(g)

    def step(self) -> None:
        """Evolve both solution and mutation strategy."""
        if self.population.size == 0:
            return

        import random

        parent = random.choice(self.population.members)
        child = self.mutation.mutate(parent, self.engine)

        if self.fitness_fn:
            child.fitness = self.fitness_fn(child)
        self.population.add(child)

    def propose(self) -> None:
        best = self.population.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])
