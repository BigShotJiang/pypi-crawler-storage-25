"""
---
title: CMAESEvolution — Continuous-Space Covariance Matrix Adaptation
summary: >
    Continuous-space search with covariance matrix adaptation.
    Operates on hyperparameters (numerical) alongside LLM-based
    prompt mutations.
---
"""
from __future__ import annotations

import random
from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class CMAESEvolution(EvolOptimizer):
    r"""
    ## CMAESEvolution — CMA-ES Style Evolution

    Adapts hyperparameters using covariance matrix-like adaptation
    of the search distribution, while prompts are mutated via LLM.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        population_size: int = 10,
        sigma: float = 0.3,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.population = Population(max_size=population_size)
        self.sigma = sigma
        self.fitness_fn = fitness_fn

    def seed(self, genotypes: list[Genotype]) -> None:
        for g in genotypes:
            self.population.add(g)

    def evolve_step(self) -> None:
        """Generate candidates by perturbing hyperparams."""
        if self.population.size == 0:
            return

        best = self.population.best()
        if best is None:
            return

        child = best.clone()
        for key in child.hyperparams:
            val = child.hyperparams[key]
            if isinstance(val, float):
                child.hyperparams[key] = val + random.gauss(0, self.sigma)
            elif isinstance(val, int):
                child.hyperparams[key] = val + round(random.gauss(0, self.sigma))

        child.fitness = None
        if self.fitness_fn:
            child.fitness = self.fitness_fn(child)
        self.population.add(child)

    def step(self) -> None:
        self.evolve_step()

    def propose(self) -> None:
        best = self.population.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])
