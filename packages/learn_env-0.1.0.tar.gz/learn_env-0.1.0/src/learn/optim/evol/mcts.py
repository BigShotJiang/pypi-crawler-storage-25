"""
---
title: MCTSEvolution — Monte Carlo Tree Search Over Programs
summary: >
    MCTS over program graphs with experience-guided tree search.
---
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import LLMMutation, MutationOperator

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class _MCTSNode:
    """Internal MCTS tree node."""

    def __init__(self, genotype: Genotype, parent: _MCTSNode | None = None):
        self.genotype = genotype
        self.parent = parent
        self.children: list[_MCTSNode] = []
        self.visits = 0
        self.total_reward = 0.0

    @property
    def ucb(self) -> float:
        if self.visits == 0:
            return float("inf")
        exploit = self.total_reward / self.visits
        if self.parent is None or self.parent.visits == 0:
            return exploit
        explore = math.sqrt(2 * math.log(self.parent.visits) / self.visits)
        return exploit + explore


class MCTSEvolution(EvolOptimizer):
    r"""
    ## MCTSEvolution — MCTS Over Program Graphs

    Uses Monte Carlo Tree Search to explore the space of program
    configurations. Each tree node is a genotype; edges are mutations.

    Reference: AFlow
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        max_iterations: int = 100,
        max_depth: int = 5,
        mutation: MutationOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_iterations = max_iterations
        self.max_depth = max_depth
        self.mutation = mutation or LLMMutation()
        self.fitness_fn = fitness_fn
        self._root: _MCTSNode | None = None
        self._best: Genotype | None = None
        self._best_fitness: float = float("-inf")

    def seed(self, genotype: Genotype) -> None:
        """Set the root genotype for MCTS."""
        self._root = _MCTSNode(genotype)

    def _select(self, node: _MCTSNode) -> _MCTSNode:
        """Select a leaf node using UCB."""
        current = node
        depth = 0
        while current.children and depth < self.max_depth:
            current = max(current.children, key=lambda n: n.ucb)
            depth += 1
        return current

    def _expand(self, node: _MCTSNode) -> _MCTSNode:
        """Expand a node by creating a child via mutation."""
        child_genotype = self.mutation.mutate(node.genotype, self.engine)
        child_node = _MCTSNode(child_genotype, parent=node)
        node.children.append(child_node)
        return child_node

    def _simulate(self, node: _MCTSNode) -> float:
        """Evaluate the genotype at this node."""
        if self.fitness_fn is not None:
            fitness = self.fitness_fn(node.genotype)
            node.genotype.fitness = fitness
            return fitness
        return 0.0

    def _backpropagate(self, node: _MCTSNode, reward: float) -> None:
        """Propagate reward up the tree."""
        current: _MCTSNode | None = node
        while current is not None:
            current.visits += 1
            current.total_reward += reward
            current = current.parent

    def evolve_step(self) -> None:
        """One MCTS iteration: select, expand, simulate, backpropagate."""
        if self._root is None:
            return

        leaf = self._select(self._root)
        child = self._expand(leaf)
        reward = self._simulate(child)
        self._backpropagate(child, reward)

        if reward > self._best_fitness:
            self._best_fitness = reward
            self._best = child.genotype

    def step(self) -> None:
        self.evolve_step()

    def propose(self) -> None:
        """Propose updates using the best genotype found."""
        if self._best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in self._best.prompts:
                param.update(self._best.prompts[param.name])

    def best(self) -> Genotype | None:
        return self._best
