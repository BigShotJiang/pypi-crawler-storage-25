"""
---
title: EPEvolution — MermaidFlow-style Evolutionary Programming
summary: >
    Evolutionary programming with proposal-based mutation and population
    management.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.operators import LLMMutation, MutationOperator
from learn.optim.evol.population import Population

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class EPEvolution(EvolOptimizer):
    r"""
    ## EPEvolution — Evolutionary Programming

    Mutation-only evolutionary strategy (no crossover).
    Each individual generates offspring via mutation; the best
    from parents + offspring survive.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        population_size: int = 20,
        mutation: MutationOperator | None = None,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.population = Population(max_size=population_size)
        self.mutation = mutation or LLMMutation()
        self.fitness_fn = fitness_fn

    def seed(self, genotypes: list[Genotype]) -> None:
        for g in genotypes:
            self.population.add(g)

    def evolve_step(self) -> None:
        """Mutate each member, evaluate, keep best."""
        if self.population.size == 0:
            return

        for parent in list(self.population.members):
            child = self.mutation.mutate(parent, self.engine)
            if self.fitness_fn is not None:
                child.fitness = self.fitness_fn(child)
            self.population.add(child)

    def step(self) -> None:
        self.evolve_step()

    def propose(self) -> None:
        best = self.population.best()
        if best is None:
            return
        for param in self.params:
            if param.requires_opt and param.name in best.prompts:
                param.update(best.prompts[param.name])
