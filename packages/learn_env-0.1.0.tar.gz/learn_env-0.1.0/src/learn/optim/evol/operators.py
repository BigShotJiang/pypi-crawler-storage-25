"""
---
title: Evolutionary Operators — Selection, Mutation, Crossover
summary: >
    Abstract base classes and concrete implementations for
    evolutionary operators.
---
"""
from __future__ import annotations

import random
import re
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from learn.optim.evol.genotype import Genotype

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.optim.evol.population import Population


# ===================================================================
# Selection Operators
# ===================================================================


class SelectionOperator(ABC):
    """Abstract selection operator."""

    @abstractmethod
    def select(self, population: Population, k: int) -> list[Genotype]:
        """Select k genotypes from the population."""
        ...


class TournamentSelection(SelectionOperator):
    """Tournament selection — pick best from random subsets."""

    def __init__(self, tournament_size: int = 3) -> None:
        self.tournament_size = tournament_size

    def select(self, population: Population, k: int) -> list[Genotype]:
        selected = []
        members = population.members
        for _ in range(k):
            if not members:
                break
            t_size = min(self.tournament_size, len(members))
            tournament = random.sample(members, t_size)
            winner = max(
                tournament,
                key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
            )
            selected.append(winner)
        return selected


class RouletteSelection(SelectionOperator):
    """Fitness-proportional roulette wheel selection."""

    def select(self, population: Population, k: int) -> list[Genotype]:
        members = population.members
        if not members:
            return []

        fitnesses = [
            g.fitness if g.fitness is not None else 0.0 for g in members
        ]
        # Shift to non-negative
        min_f = min(fitnesses)
        if min_f < 0:
            fitnesses = [f - min_f for f in fitnesses]
        total = sum(fitnesses)
        if total == 0:
            return random.sample(members, min(k, len(members)))

        selected = []
        for _ in range(k):
            r = random.uniform(0, total)
            cumulative = 0.0
            for g, f in zip(members, fitnesses):
                cumulative += f
                if cumulative >= r:
                    selected.append(g)
                    break
            else:
                selected.append(members[-1])
        return selected


class TruncationSelection(SelectionOperator):
    """Select top-k by fitness."""

    def select(self, population: Population, k: int) -> list[Genotype]:
        return population.select(k)


class ParetoSelection(SelectionOperator):
    """Multi-objective Pareto-based selection.

    Uses fitness and diversity as two objectives.
    """

    def select(self, population: Population, k: int) -> list[Genotype]:
        members = population.members
        if len(members) <= k:
            return list(members)

        # Simple: sort by fitness, return top-k
        sorted_members = sorted(
            members,
            key=lambda g: g.fitness if g.fitness is not None else float("-inf"),
            reverse=True,
        )
        return sorted_members[:k]


# ===================================================================
# Mutation Operators
# ===================================================================


class MutationOperator(ABC):
    """Abstract mutation operator."""

    @abstractmethod
    def mutate(
        self, genotype: Genotype, engine: EngineLM | None = None
    ) -> Genotype:
        """Mutate a genotype, returning a new one."""
        ...


class LLMMutation(MutationOperator):
    """LLM-guided mutation — asks LLM to modify a genotype's prompts."""

    MUTATE_PROMPT = """\
Here is a prompt that needs a creative variation:

<PROMPT>
{prompt}
</PROMPT>

Generate a modified version that keeps the core intent but makes one \
meaningful change. Output ONLY the new version between tags:

<IMPROVED_VARIABLE>
[Your modified version]
</IMPROVED_VARIABLE>"""

    def mutate(
        self, genotype: Genotype, engine: EngineLM | None = None
    ) -> Genotype:
        child = genotype.clone()
        if not engine or not child.prompts:
            return child

        # Mutate one random prompt
        key = random.choice(list(child.prompts.keys()))
        prompt = self.MUTATE_PROMPT.format(prompt=child.prompts[key])
        response = engine.generate(prompt)
        child.prompts[key] = _extract_improved_variable(response)
        child.fitness = None  # needs re-evaluation
        child.parent_ids = [str(id(genotype))]
        child.generation += 1
        return child


class PerturbationMutation(MutationOperator):
    """Small random perturbation to hyperparameters."""

    def __init__(self, perturbation_scale: float = 0.1) -> None:
        self.perturbation_scale = perturbation_scale

    def mutate(
        self, genotype: Genotype, engine: EngineLM | None = None
    ) -> Genotype:
        child = genotype.clone()
        for key in child.hyperparams:
            val = child.hyperparams[key]
            if isinstance(val, (int, float)):
                delta = random.gauss(0, self.perturbation_scale * abs(val + 1e-6))
                child.hyperparams[key] = type(val)(val + delta)
        child.fitness = None
        child.parent_ids = [str(id(genotype))]
        child.generation += 1
        return child


class StructuredMutation(MutationOperator):
    """Structural mutation: add/remove/rewire nodes."""

    def mutate(
        self, genotype: Genotype, engine: EngineLM | None = None
    ) -> Genotype:
        child = genotype.clone()
        if not child.graph_structure:
            return child

        # Randomly remove or add an edge
        action = random.choice(["add_edge", "remove_edge"])
        nodes = list(child.graph_structure.keys())

        if action == "add_edge" and len(nodes) >= 2:
            src, dst = random.sample(nodes, 2)
            if dst not in child.graph_structure[src]:
                child.graph_structure[src].append(dst)
        elif action == "remove_edge":
            nodes_with_edges = [n for n in nodes if child.graph_structure[n]]
            if nodes_with_edges:
                src = random.choice(nodes_with_edges)
                edge = random.choice(child.graph_structure[src])
                child.graph_structure[src].remove(edge)

        child.fitness = None
        child.parent_ids = [str(id(genotype))]
        child.generation += 1
        return child


# ===================================================================
# Crossover Operators
# ===================================================================


class CrossoverOperator(ABC):
    """Abstract crossover operator."""

    @abstractmethod
    def crossover(
        self,
        parent_a: Genotype,
        parent_b: Genotype,
        engine: EngineLM | None = None,
    ) -> Genotype:
        """Combine two parents into a child genotype."""
        ...


class LLMCrossover(CrossoverOperator):
    """LLM reads both parents and produces a child combining strengths."""

    CROSSOVER_PROMPT = """\
Here are two prompts. Combine their strengths into a new prompt:

<PARENT_A>
{parent_a}
</PARENT_A>

<PARENT_B>
{parent_b}
</PARENT_B>

Output ONLY the combined prompt between tags:

<IMPROVED_VARIABLE>
[Your combined version]
</IMPROVED_VARIABLE>"""

    def crossover(
        self,
        parent_a: Genotype,
        parent_b: Genotype,
        engine: EngineLM | None = None,
    ) -> Genotype:
        child = parent_a.clone()
        child.parent_ids = [str(id(parent_a)), str(id(parent_b))]
        child.generation = max(parent_a.generation, parent_b.generation) + 1
        child.fitness = None

        if not engine:
            # Uniform crossover without engine
            for key in set(parent_a.prompts) | set(parent_b.prompts):
                if key in parent_a.prompts and key in parent_b.prompts:
                    child.prompts[key] = random.choice(
                        [parent_a.prompts[key], parent_b.prompts[key]]
                    )
            return child

        # LLM-guided crossover
        for key in set(parent_a.prompts) | set(parent_b.prompts):
            pa = parent_a.prompts.get(key, "")
            pb = parent_b.prompts.get(key, "")
            if pa and pb:
                prompt = self.CROSSOVER_PROMPT.format(parent_a=pa, parent_b=pb)
                response = engine.generate(prompt)
                child.prompts[key] = _extract_improved_variable(response)
            elif pa:
                child.prompts[key] = pa
            else:
                child.prompts[key] = pb

        return child


class SubgraphCrossover(CrossoverOperator):
    """Swap subgraph regions between parents."""

    def crossover(
        self,
        parent_a: Genotype,
        parent_b: Genotype,
        engine: EngineLM | None = None,
    ) -> Genotype:
        child = parent_a.clone()
        child.parent_ids = [str(id(parent_a)), str(id(parent_b))]
        child.generation = max(parent_a.generation, parent_b.generation) + 1
        child.fitness = None

        # Merge graph structures: take some edges from parent_b
        for key in parent_b.graph_structure:
            if random.random() < 0.5:
                child.graph_structure[key] = list(parent_b.graph_structure[key])

        # Uniform crossover for hyperparams
        for key in parent_b.hyperparams:
            if random.random() < 0.5:
                child.hyperparams[key] = parent_b.hyperparams[key]

        return child


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
