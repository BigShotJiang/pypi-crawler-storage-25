"""
---
title: MemeticOptimizer — Evolutionary + Local Search
summary: >
    Alternates between evolutionary (outer) and textual/numerical
    (inner) optimization loops.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.optim.evol.base import EvolOptimizer
from learn.optim.evol.genotype import Genotype
from learn.optim.evol.linear import LinearEvolution

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter
    from learn.optim.base import Optimizer


class MemeticOptimizer(EvolOptimizer):
    r"""
    ## MemeticOptimizer — Evolutionary + Local Optimization

    Outer loop: evolutionary search over configurations.
    Inner loop: num/txt optimization per configuration.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        outer_optimizer: EvolOptimizer | None = None,
        inner_optimizer: Optimizer | None = None,
        inner_steps: int = 3,
        fitness_fn: Callable[[Genotype], float] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.outer = outer_optimizer or LinearEvolution(params, engine)
        self.inner = inner_optimizer
        self.inner_steps = inner_steps
        self.fitness_fn = fitness_fn

    def step(self) -> None:
        """One memetic step: evolve then locally optimize."""
        # Outer: evolutionary step
        self.outer.step()

        # Inner: local optimization on best individual
        if self.inner is not None:
            for _ in range(self.inner_steps):
                self.inner.step()

    def propose(self) -> None:
        self.outer.propose()
