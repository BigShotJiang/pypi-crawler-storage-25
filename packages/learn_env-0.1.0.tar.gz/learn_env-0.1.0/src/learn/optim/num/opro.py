"""
---
title: OPRO — Optimization by PROmpting
summary: >
    Trajectory-based meta-prompt optimization. Maintains a sorted buffer
    of (prompt, score) pairs and asks an LLM to propose a better prompt.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.num.base import NumOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


OPRO_META_PROMPT = """\
Below are some prompts along with their scores. The score indicates \
how well the prompt performed (higher is better).

{trajectory}

Generate a new prompt that is likely to score higher than the ones above. \
Think about what patterns make high-scoring prompts work well.

Output ONLY the improved prompt between the tags below:

<IMPROVED_VARIABLE>
[Your new prompt here]
</IMPROVED_VARIABLE>"""

OPRO_SYSTEM_PROMPT = """\
You are an expert prompt optimizer. Analyze the trajectory of prompts \
and their scores to identify patterns, then propose a new prompt that \
is likely to score even higher."""


class OproOptimizer(NumOptimizer):
    r"""
    ## OPRO — Optimization by PROmpting

    Maintains a sorted trajectory of (prompt_text, score) pairs.
    The LLM reads the trajectory and proposes a new prompt likely
    to score higher.

    $$p_{t+1} = \text{LLM}(\text{trajectory}: [(p_1, s_1), \ldots, (p_t, s_t)])$$

    Reference: OPRO (Yang et al., 2024)

    ```python
    opro = OproOptimizer(params=[prompt_param], engine=engine, max_history=20)
    # After evaluation:
    opro.record(score=0.85)
    opro.step()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_history: int = 20,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_history = max_history
        # List of (prompt_text, score) pairs, sorted ascending by score
        self.history: list[tuple[str, float]] = []

    def record(self, score: float) -> None:
        """Record the current parameter values with their score."""
        for param in self.params:
            if not param.requires_opt:
                continue
            self.history.append((param.data, score))
        # Sort by score ascending (best at end for recency bias)
        self.history.sort(key=lambda x: x[1])
        # Trim to max_history
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history :]

    def propose(self) -> None:
        """Propose new parameter values based on trajectory."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            if not self.history:
                # No history yet — nothing to do
                continue

            # Build trajectory text
            trajectory_lines = []
            for prompt_text, score in self.history:
                trajectory_lines.append(
                    f"Prompt: {prompt_text}\nScore: {score:.4f}\n"
                )
            trajectory = "\n".join(trajectory_lines)

            prompt = OPRO_META_PROMPT.format(trajectory=trajectory)
            response = self.engine.generate(
                prompt, system_prompt=OPRO_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

    def step(self) -> None:
        """Propose updates."""
        self.propose()

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["history"] = list(self.history)
        state["max_history"] = self.max_history
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self.history = state.get("history", [])
        self.max_history = state.get("max_history", self.max_history)


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags."""
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
