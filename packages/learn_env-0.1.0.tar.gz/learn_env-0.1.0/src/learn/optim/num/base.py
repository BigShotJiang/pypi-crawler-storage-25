"""
---
title: NumOptimizer — Base for Numerical Optimizers
summary: >
    Abstract base for optimizers driven by scalar scores.
    Extends Optimizer with propose() and score-tracking semantics.
---
"""
from __future__ import annotations

from abc import abstractmethod
from typing import TYPE_CHECKING

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class NumOptimizer(Optimizer):
    r"""
    ## NumOptimizer

    Base class for numerically-driven text optimization.
    These optimizers treat the problem as a black box: they observe
    (prompt, score) pairs and propose better prompts.

    Subclasses must implement ``propose()`` and ``step()``.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
    ) -> None:
        super().__init__(params, engine=engine)
        if engine is None:
            raise ValueError("NumOptimizer requires an engine.")

    @abstractmethod
    def propose(self) -> None:
        """Propose new candidate values for each parameter."""
        ...
