"""
---
title: CAPO — Comparative A/B Prompt Optimization
summary: >
    A/B comparative prompt optimization. Generates candidate prompts,
    evaluates via pairwise comparison, uses win-rate to select winners.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.num.base import NumOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

CAPO_CANDIDATE_PROMPT = """\
Here is the current prompt:

<CURRENT>
{current}
</CURRENT>

Generate an alternative version that might perform better. \
Be creative but maintain the core intent.

Output ONLY the alternative between the tags:

<IMPROVED_VARIABLE>
[Your alternative here]
</IMPROVED_VARIABLE>"""

CAPO_COMPARE_PROMPT = """\
Compare these two prompts for the task described below:

<PROMPT_A>
{prompt_a}
</PROMPT_A>

<PROMPT_B>
{prompt_b}
</PROMPT_B>

Which prompt is better? Respond with ONLY "A" or "B"."""


class CAPO(NumOptimizer):
    r"""
    ## CAPO — Comparative A/B Prompt Optimization

    Generates candidate prompts, evaluates them via pairwise A/B tests,
    and uses win-rate statistics to select winners.

    Reference: CAPO (2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        num_candidates: int = 3,
        num_comparisons: int = 3,
    ) -> None:
        super().__init__(params, engine=engine)
        self.num_candidates = num_candidates
        self.num_comparisons = num_comparisons
        self.candidates: list[tuple[str, int]] = []  # (text, wins)

    def propose(self) -> None:
        """Generate candidates, compare pairwise, select winner."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            # Generate candidates
            candidates = [param.data]
            for _ in range(self.num_candidates):
                prompt = CAPO_CANDIDATE_PROMPT.format(current=param.data)
                response = self.engine.generate(prompt)
                candidates.append(_extract_improved_variable(response))

            # Pairwise comparisons — round robin
            wins = {c: 0 for c in range(len(candidates))}
            for i in range(len(candidates)):
                for j in range(i + 1, len(candidates)):
                    for _ in range(self.num_comparisons):
                        compare = CAPO_COMPARE_PROMPT.format(
                            prompt_a=candidates[i],
                            prompt_b=candidates[j],
                        )
                        result = self.engine.generate(compare).strip().upper()
                        if "A" in result:
                            wins[i] += 1
                        else:
                            wins[j] += 1

            # Select winner
            best_idx = max(wins, key=lambda k: wins[k])
            param.update(candidates[best_idx])

    def step(self) -> None:
        """Propose updates."""
        self.propose()


class BanditSelector(NumOptimizer):
    r"""
    ## BanditSelector — UCB Multi-Armed Bandit

    Tracks (choice, reward) history and balances exploration/exploitation
    using Upper Confidence Bound (UCB) selection.

    Used for: optimizer selection, model selection, strategy selection.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        choices: list[str] | None = None,
        exploration_weight: float = 1.41,
    ) -> None:
        super().__init__(params, engine=engine)
        self.choices = choices or []
        self.exploration_weight = exploration_weight
        # Track rewards per choice
        self._counts: dict[str, int] = {c: 0 for c in self.choices}
        self._total_rewards: dict[str, float] = {c: 0.0 for c in self.choices}
        self._total_pulls: int = 0

    def select(self) -> str:
        """Select the best choice using UCB1."""
        import math

        self._total_pulls += 1

        # Try each arm at least once
        for choice in self.choices:
            if self._counts[choice] == 0:
                return choice

        # UCB1
        best_val = float("-inf")
        best_choice = self.choices[0]
        for choice in self.choices:
            avg = self._total_rewards[choice] / self._counts[choice]
            ucb = avg + self.exploration_weight * math.sqrt(
                math.log(self._total_pulls) / self._counts[choice]
            )
            if ucb > best_val:
                best_val = ucb
                best_choice = choice
        return best_choice

    def record(self, choice: str, reward: float) -> None:
        """Record the reward for a choice."""
        if choice not in self._counts:
            self._counts[choice] = 0
            self._total_rewards[choice] = 0.0
        self._counts[choice] += 1
        self._total_rewards[choice] += reward

    def propose(self) -> None:
        """Select best choice and update parameters."""
        if not self.choices:
            return
        best = self.select()
        for param in self.params:
            if param.requires_opt:
                param.update(best)

    def step(self) -> None:
        self.propose()

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["counts"] = dict(self._counts)
        state["total_rewards"] = dict(self._total_rewards)
        state["total_pulls"] = self._total_pulls
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._counts = state.get("counts", self._counts)
        self._total_rewards = state.get("total_rewards", self._total_rewards)
        self._total_pulls = state.get("total_pulls", 0)


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags."""
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
