"""
---
title: BanditSelector — Multi-Armed Bandit for Configuration Selection
summary: >
    UCB1 and Thompson Sampling bandits for selecting between
    configurations (engines, prompts, strategies).
---

# Bandit Selector

Multi-armed bandit algorithms for adaptive selection:
- UCB1: Upper Confidence Bound
- Thompson Sampling: Bayesian approach using Beta distributions

$$\\text{UCB1}(a) = \\bar{r}_a + c\\sqrt{\\frac{\\ln N}{n_a}}$$
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass



@dataclass
class ArmStats:
    """Statistics for a single bandit arm."""

    name: str
    pulls: int = 0
    total_reward: float = 0.0
    # For Thompson sampling
    alpha: float = 1.0
    beta: float = 1.0

    @property
    def mean_reward(self) -> float:
        return self.total_reward / max(self.pulls, 1)


class BanditSelector:
    r"""
    <a id="BanditSelector"></a>

    ## BanditSelector

    Multi-armed bandit for selecting between configurations.

    ```python
    bandit = BanditSelector(
        arms=["gpt-4", "llama-3", "claude"],
        strategy="ucb1",
    )
    chosen = bandit.select()  # Returns best arm
    bandit.update(chosen, reward=0.85)
    ```
    """

    def __init__(
        self,
        arms: list[str],
        strategy: str = "ucb1",
        exploration_constant: float = 1.414,
    ) -> None:
        """Initialize bandit.

        Args:
            arms: List of arm names (configurations to select from).
            strategy: Selection strategy — "ucb1" or "thompson".
            exploration_constant: UCB1 exploration parameter.
        """
        self.strategy = strategy
        self.c = exploration_constant
        self._arms: dict[str, ArmStats] = {
            name: ArmStats(name=name) for name in arms
        }
        self._total_pulls = 0

    def select(self) -> str:
        """Select an arm using the configured strategy.

        Returns:
            Name of the selected arm.
        """
        if self.strategy == "thompson":
            return self._thompson_select()
        return self._ucb1_select()

    def _ucb1_select(self) -> str:
        """UCB1 selection."""
        # Pull each arm at least once
        for name, stats in self._arms.items():
            if stats.pulls == 0:
                return name

        def ucb1_score(stats: ArmStats) -> float:
            exploit = stats.mean_reward
            explore = self.c * math.sqrt(
                math.log(self._total_pulls) / stats.pulls
            )
            return exploit + explore

        return max(self._arms.values(), key=ucb1_score).name

    def _thompson_select(self) -> str:
        """Thompson Sampling selection using Beta distributions."""
        samples = {
            name: random.betavariate(stats.alpha, stats.beta)
            for name, stats in self._arms.items()
        }
        return max(samples, key=samples.get)  # type: ignore[arg-type]

    def update(self, arm: str, reward: float) -> None:
        """Update arm statistics after observing a reward.

        Args:
            arm: Name of the pulled arm.
            reward: Observed reward (typically 0-1).
        """
        if arm not in self._arms:
            self._arms[arm] = ArmStats(name=arm)

        stats = self._arms[arm]
        stats.pulls += 1
        stats.total_reward += reward
        self._total_pulls += 1

        # Update Beta distribution (for Thompson)
        if reward > 0.5:
            stats.alpha += 1
        else:
            stats.beta += 1

    def get_stats(self) -> dict[str, dict[str, float]]:
        """Return statistics for all arms."""
        return {
            name: {
                "pulls": stats.pulls,
                "mean_reward": stats.mean_reward,
                "alpha": stats.alpha,
                "beta": stats.beta,
            }
            for name, stats in self._arms.items()
        }

    def best_arm(self) -> str:
        """Return the arm with highest mean reward."""
        return max(
            self._arms.values(),
            key=lambda s: s.mean_reward,
        ).name

    def add_arm(self, name: str) -> None:
        """Add a new arm."""
        if name not in self._arms:
            self._arms[name] = ArmStats(name=name)
