"""
---
title: MIPROv2 — Bayesian Instruction + Demo Optimization
summary: >
    Bayesian search over instruction + demonstration combinations.
    Generates candidate instructions and demo subsets, evaluates each,
    and selects the best combination.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.num.base import NumOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

MIPRO_INSTRUCTION_PROMPT = """\
Here is the current instruction for a task:

<CURRENT_INSTRUCTION>
{current}
</CURRENT_INSTRUCTION>

{history_text}\
Generate a new, improved instruction. Be creative and think about \
what might work better.

Output ONLY the new instruction between the tags:

<IMPROVED_VARIABLE>
[Your new instruction here]
</IMPROVED_VARIABLE>"""


class MIPROv2(NumOptimizer):
    r"""
    ## MIPROv2 — Multi-prompt Instruction Proposal Optimization v2

    Searches the joint space of instruction candidates and demo subsets.
    For each trial:
    1. Generate or select an instruction candidate
    2. Select a demo subset
    3. Evaluate the combination
    4. Track (instruction, demos, score) tuples

    Reference: MIPROv2 (Opsahl-Ong et al., 2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        num_candidates: int = 5,
        max_demos: int = 3,
        demos_pool: list[dict[str, str]] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.num_candidates = num_candidates
        self.max_demos = max_demos
        self.demos_pool: list[dict[str, str]] = demos_pool or []
        # Track (instruction, demos_indices, score)
        self.trials: list[dict[str, Any]] = []
        self._best_instruction: str | None = None
        self._best_demos: list[dict[str, str]] = []
        self._best_score: float = float("-inf")

    def record(self, score: float) -> None:
        """Record the score of the current configuration."""
        for param in self.params:
            if not param.requires_opt:
                continue
            self.trials.append({
                "instruction": param.data,
                "score": score,
            })
            if score > self._best_score:
                self._best_score = score
                self._best_instruction = param.data

    def propose(self) -> None:
        """Generate a new instruction candidate."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            # Build history text from trials
            history_text = ""
            if self.trials:
                sorted_trials = sorted(
                    self.trials, key=lambda t: t["score"]
                )
                history_lines = []
                for t in sorted_trials[-5:]:
                    history_lines.append(
                        f"Instruction: {t['instruction']}\n"
                        f"Score: {t['score']:.4f}\n"
                    )
                history_text = (
                    "Previous attempts and their scores:\n\n"
                    + "\n".join(history_lines)
                    + "\n"
                )

            prompt = MIPRO_INSTRUCTION_PROMPT.format(
                current=param.data,
                history_text=history_text,
            )
            response = self.engine.generate(prompt)
            improved = _extract_improved_variable(response)
            param.update(improved)

    def step(self) -> None:
        """Propose a new candidate."""
        self.propose()

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["trials"] = list(self.trials)
        state["best_score"] = self._best_score
        state["best_instruction"] = self._best_instruction
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self.trials = state.get("trials", [])
        self._best_score = state.get("best_score", float("-inf"))
        self._best_instruction = state.get("best_instruction", None)


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags."""
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
