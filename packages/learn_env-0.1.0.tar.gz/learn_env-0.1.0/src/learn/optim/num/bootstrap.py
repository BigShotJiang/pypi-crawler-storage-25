"""
---
title: Bootstrap — Teacher-Model Demonstration Generation
summary: >
    Uses a teacher model to generate demonstrations, filters by score
    threshold, and stores the best as few-shot examples.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.optim.num.base import NumOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class Bootstrap(NumOptimizer):
    r"""
    ## Bootstrap — Few-Shot Demonstration Generation

    Uses a teacher model (or the same engine) to generate candidate
    demonstrations. Filters by a score function, and stores the best
    as few-shot examples for the parameter.

    Reference: DSPy BootstrapFewShot (Khattab et al., 2023)

    ```python
    bootstrap = Bootstrap(
        params=[demo_param], engine=engine,
        max_demos=5, score_fn=exact_match,
    )
    bootstrap.step()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_demos: int = 5,
        max_rounds: int = 3,
        score_threshold: float = 0.8,
        score_fn: Optional[Callable[[str, str], float]] = None,
        teacher_engine: Optional[EngineLM] = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_demos = max_demos
        self.max_rounds = max_rounds
        self.score_threshold = score_threshold
        self.score_fn = score_fn
        self.teacher_engine = teacher_engine or engine
        self.approved_demos: list[dict[str, str]] = []

    def add_example(
        self, input_text: str, output_text: str, score: float
    ) -> None:
        """Add a scored example. Only keeps it if above threshold."""
        if score >= self.score_threshold:
            self.approved_demos.append(
                {"input": input_text, "output": output_text, "score": str(score)}
            )
            # Keep only the best max_demos
            self.approved_demos.sort(
                key=lambda x: float(x.get("score", "0")), reverse=True
            )
            self.approved_demos = self.approved_demos[: self.max_demos]

    def propose(self) -> None:
        """Update parameters with collected demonstrations."""
        for param in self.params:
            if not param.requires_opt:
                continue
            if not self.approved_demos:
                continue
            # Format demos into the parameter
            demo_text = self._format_demos()
            param.update(demo_text)

    def step(self) -> None:
        """Propose updates."""
        self.propose()

    def _format_demos(self) -> str:
        """Format approved demos into a few-shot prompt string."""
        lines = []
        for i, demo in enumerate(self.approved_demos, 1):
            lines.append(f"Example {i}:")
            lines.append(f"Input: {demo['input']}")
            lines.append(f"Output: {demo['output']}")
            lines.append("")
        return "\n".join(lines)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["approved_demos"] = list(self.approved_demos)
        state["max_demos"] = self.max_demos
        state["score_threshold"] = self.score_threshold
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self.approved_demos = state.get("approved_demos", [])
        self.max_demos = state.get("max_demos", self.max_demos)
        self.score_threshold = state.get("score_threshold", self.score_threshold)
