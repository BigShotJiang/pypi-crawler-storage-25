"""
---
title: Numerical Loss Functions
summary: >
    Loss functions for numerical optimizers: ScalarLoss and PairwiseLoss.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class LossValue:
    """Result of a loss computation.

    * ``score`` — numerical scalar for comparison
    * ``feedback`` — optional textual feedback for textual optimizers
    * ``metadata`` — arbitrary additional information
    """

    score: float
    feedback: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


class ScalarLoss:
    """Wraps numeric metrics: accuracy, F1, pass@k.

    Produces LossValue with score only (no textual feedback).

    ```python
    loss_fn = ScalarLoss(eval_fn=lambda pred, ref: 1.0 if pred == ref else 0.0)
    loss = loss_fn("42", "42")
    assert loss.score == 1.0
    ```
    """

    def __init__(self, eval_fn: Callable[[str, str], float]) -> None:
        self.eval_fn = eval_fn

    def compute(self, prediction: str, reference: str, **kwargs: Any) -> LossValue:
        """Compute scalar loss."""
        score = self.eval_fn(prediction, reference)
        return LossValue(score=score, metadata=kwargs)


class PairwiseLoss:
    """A/B comparison producing win-rate scores.

    Uses an LLM to compare two outputs and returns which is better.

    ```python
    loss_fn = PairwiseLoss(engine=engine)
    result = loss_fn.compare("Answer A", "Answer B", reference="42")
    ```
    """

    def __init__(self, engine: Any = None) -> None:
        self.engine = engine

    def compare(
        self, output_a: str, output_b: str, reference: str = ""
    ) -> LossValue:
        """Compare two outputs and return a score for A (1.0 = A wins, 0.0 = B wins)."""
        if self.engine is None:
            # Without an engine, do simple string similarity
            score_a = 1.0 if output_a.strip() == reference.strip() else 0.0
            score_b = 1.0 if output_b.strip() == reference.strip() else 0.0
            if score_a > score_b:
                return LossValue(score=1.0, feedback="A is better")
            elif score_b > score_a:
                return LossValue(score=0.0, feedback="B is better")
            return LossValue(score=0.5, feedback="Tie")

        prompt = (
            f"Compare these two outputs:\n\n"
            f"Output A: {output_a}\n\n"
            f"Output B: {output_b}\n\n"
        )
        if reference:
            prompt += f"Reference: {reference}\n\n"
        prompt += "Which is better? Respond with ONLY 'A' or 'B'."

        result = self.engine.generate(prompt)
        if "A" in result.upper():
            return LossValue(score=1.0, feedback="A is better")
        return LossValue(score=0.0, feedback="B is better")

    def compute(self, prediction: str, reference: str, **kwargs: Any) -> LossValue:
        """Compute similarity between prediction and reference as a score."""
        score = 1.0 if prediction.strip() == reference.strip() else 0.0
        return LossValue(score=score)
