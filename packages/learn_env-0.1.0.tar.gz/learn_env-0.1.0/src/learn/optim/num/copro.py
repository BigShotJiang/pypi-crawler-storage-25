"""
---
title: COPRO — Coordinate-Wise Prompt Optimization
summary: >
    Iterative coordinate descent on prompt components. Optimizes each
    parameter (instruction / system prompt) independently by generating
    candidate improvements, evaluating them on a dev set, and selecting
    the best. Port from DSPy's COPRO teleprompter.
---

# COPRO — Coordinate-Wise Prompt Optimization

Port of **COPRO** (Khattab et al., 2022 / DSPy teleprompter).

## Intuition

Optimizing a prompt is a coordinate descent problem in discrete text
space: fix all other components, improve one at a time.  COPRO sweeps
over each parameter (instruction, system prompt, prefix) and performs
a local search using an LLM-based proposal followed by dev-set
evaluation.

## Algorithm

For ``max_rounds`` rounds:
  1. For each optimizable parameter $\\theta_i$:
     a. Generate ``num_candidates`` candidate improvements by prompting
        an optimizer LLM with the current value + dev-set failure cases.
     b. Evaluate each candidate on the dev set using ``metric``.
     c. Accept the best candidate (if it beats the current value).
  2. Repeat.

## PyTorch Analogy

| PyTorch | COPRO |
|---------|-------|
| Coordinate descent | Per-parameter sequential update |
| ``optim.step()`` | One round over all params |
| Gradient | LLM-generated candidate + dev-set score |
| Learning rate | ``num_candidates`` search width |

## Usage

```python
from learn.optim.num.copro import COPRO

copro = COPRO(
    params=[prompt_param, instruction_param],
    engine=engine,
    metric=lambda pred, tgt: exact_match(pred, tgt),
    num_candidates=5,
    max_rounds=3,
)
copro.compile(train_data=dataset, predict_fn=predict)
```
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.optim.num.base import NumOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

COPRO_PROPOSE_SYSTEM_PROMPT = """\
You are an expert prompt engineer. Your task is to improve an instruction \
or system prompt based on examples where it failed to produce the correct \
output. Generate improved versions that are more likely to succeed."""

COPRO_PROPOSE_PROMPT = """\
The following instruction did not perform well on these examples:

<CURRENT_INSTRUCTION>
{current_value}
</CURRENT_INSTRUCTION>

Examples where it failed (input → expected but got wrong output):
{failure_cases}

Generate {num_candidates} diverse improved versions of the instruction. \
Each improved instruction should address the failure patterns shown above.

Format your response as:
[1] <improved instruction 1>
[2] <improved instruction 2>
...
[{num_candidates}] <improved instruction {num_candidates}>"""

COPRO_SINGLE_PROPOSAL_PROMPT = """\
The following instruction did not perform well on these examples:

<CURRENT_INSTRUCTION>
{current_value}
</CURRENT_INSTRUCTION>

Examples where it failed (input → expected but got wrong output):
{failure_cases}

Generate ONE improved version of the instruction that addresses the \
failure patterns shown above.

Output ONLY the improved instruction between these tags:
<IMPROVED_INSTRUCTION>
[your improved instruction here]
</IMPROVED_INSTRUCTION>"""


class COPRO(NumOptimizer):
    r"""
    ## COPRO — Coordinate-Wise Prompt Optimization

    Iterative coordinate descent on prompt components.  Sweeps over
    each parameter in sequence, generating ``num_candidates`` candidate
    improvements, evaluating each on the dev set via ``metric``, and
    accepting the best-scoring candidate.

    Reference: DSPy COPRO teleprompter (Khattab et al., 2022)

    ```python
    copro = COPRO(
        params=[param],
        engine=engine,
        metric=lambda pred, tgt: float(pred.strip() == tgt.strip()),
        num_candidates=5,
        max_rounds=2,
    )
    # Manual loop:
    for sample in train_data:
        output = predict_fn(param.data, sample.input)
        if metric(output, sample.expected_output) < 1.0:
            copro.record_failure(sample.input, sample.expected_output, output)
    copro.step()

    # Or all-in-one:
    copro.compile(train_data, predict_fn)
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        metric: Optional[Callable[[str, str], float]] = None,
        num_candidates: int = 5,
        max_rounds: int = 1,
        max_failure_cases: int = 10,
    ) -> None:
        super().__init__(params, engine=engine)
        self.metric = metric
        self.num_candidates = num_candidates
        self.max_rounds = max_rounds
        self.max_failure_cases = max_failure_cases

        # Accumulated failure cases per parameter index
        self._failures: dict[int, list[dict[str, str]]] = {}

    def record_failure(
        self,
        input_text: str,
        expected: str,
        actual: str,
        param_index: int = 0,
    ) -> None:
        """Record a failure case for a specific parameter.

        Called by the user (or ``compile()``) to accumulate examples that
        drove the score below threshold.

        Args:
            input_text: The input that caused the failure.
            expected: The expected output.
            actual: What the model actually produced.
            param_index: Which parameter index this failure corresponds to.
        """
        if param_index not in self._failures:
            self._failures[param_index] = []
        failures = self._failures[param_index]
        if len(failures) < self.max_failure_cases:
            failures.append(
                {"input": input_text, "expected": expected, "actual": actual}
            )

    def clear_failures(self) -> None:
        """Clear all accumulated failure cases."""
        self._failures.clear()

    def _format_failures(self, failures: list[dict[str, str]]) -> str:
        """Format failure cases for the proposal prompt."""
        if not failures:
            return "(No failure cases recorded — optimizing from current value.)"
        parts = []
        for i, f in enumerate(failures[: self.max_failure_cases], 1):
            parts.append(
                f"  {i}. Input: {f['input'][:200]}\n"
                f"     Expected: {f['expected'][:100]}\n"
                f"     Got: {f['actual'][:100]}"
            )
        return "\n".join(parts)

    def _propose_candidates(
        self, param: Parameter, param_idx: int
    ) -> list[str]:
        """Generate candidate improvements for one parameter.

        Uses the optimizer LLM with failure cases as context.

        Returns a list of ``num_candidates`` candidate strings.
        """
        assert self.engine is not None
        failures = self._failures.get(param_idx, [])
        failure_text = self._format_failures(failures)

        candidates: list[str] = []
        if self.num_candidates == 1:
            prompt = COPRO_SINGLE_PROPOSAL_PROMPT.format(
                current_value=param.data,
                failure_cases=failure_text,
            )
            response = self.engine.generate(
                prompt, system_prompt=COPRO_PROPOSE_SYSTEM_PROMPT
            )
            extracted = _extract_single_candidate(response)
            candidates.append(extracted)
        else:
            prompt = COPRO_PROPOSE_PROMPT.format(
                current_value=param.data,
                failure_cases=failure_text,
                num_candidates=self.num_candidates,
            )
            response = self.engine.generate(
                prompt, system_prompt=COPRO_PROPOSE_SYSTEM_PROMPT
            )
            candidates = _extract_numbered_candidates(response, self.num_candidates)
            # Ensure we have at least one candidate
            if not candidates:
                candidates.append(response.strip())

        return candidates

    def propose(self) -> None:
        """One coordinate-descent round over all parameters.

        For each parameter: generate candidates → keep the same or updated
        value. Score evaluation is done inside ``compile()`` or must be
        done externally via ``record_score()``.
        """
        for idx, param in enumerate(self.params):
            if not param.requires_opt:
                continue
            candidates = self._propose_candidates(param, idx)
            if candidates:
                # Accept first candidate if no evaluation mechanism is set
                param.update(candidates[0])

    def step(self) -> None:
        """One coordinate-descent round (propose + clear failures)."""
        self.propose()
        self.clear_failures()

    def compile(
        self,
        train_data: Any,
        predict_fn: Callable[[str, str], str],
    ) -> None:
        """Full coordinate-descent optimization over ``max_rounds`` rounds.

        For each round and each parameter:
        1. Collect failures from ``train_data``
        2. Generate ``num_candidates`` improvements
        3. Evaluate each candidate on ``train_data``
        4. Accept the best-scoring candidate

        Args:
            train_data: Iterable of ``AgentSample``-like objects with
                ``input`` and ``expected_output`` fields.
            predict_fn: A callable ``(param_value: str, input: str) -> str``
                that runs inference with a specific parameter value.
        """
        assert self.engine is not None

        for _round in range(self.max_rounds):
            for param_idx, param in enumerate(self.params):
                if not param.requires_opt:
                    continue

                # --- Collect failures ---
                self._failures[param_idx] = []
                all_samples = list(train_data)
                for sample in all_samples:
                    output = predict_fn(param.data, sample.input)
                    score = self.metric(output, sample.expected_output) if self.metric else 0.0
                    if score < 1.0:
                        self.record_failure(
                            sample.input,
                            sample.expected_output,
                            output,
                            param_index=param_idx,
                        )

                # Evaluate current parameter
                current_score = self._evaluate_param(
                    param.data, all_samples, predict_fn
                )

                # --- Generate and evaluate candidates ---
                candidates = self._propose_candidates(param, param_idx)
                best_score = current_score
                best_value = param.data

                for candidate in candidates:
                    score = self._evaluate_param(candidate, all_samples, predict_fn)
                    if score > best_score:
                        best_score = score
                        best_value = candidate

                if best_value != param.data:
                    param.update(best_value)

        self.clear_failures()

    def _evaluate_param(
        self,
        param_value: str,
        samples: list[Any],
        predict_fn: Callable[[str, str], str],
    ) -> float:
        """Evaluate a candidate parameter value on all samples."""
        if not samples or self.metric is None:
            return 0.0
        scores = []
        for sample in samples:
            output = predict_fn(param_value, sample.input)
            scores.append(self.metric(output, sample.expected_output))
        return sum(scores) / len(scores) if scores else 0.0

    def state_dict(self) -> dict[str, Any]:
        base = super().state_dict()
        base["num_candidates"] = self.num_candidates
        base["max_rounds"] = self.max_rounds
        return base


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


def _extract_single_candidate(response: str) -> str:
    """Extract between ``<IMPROVED_INSTRUCTION>`` tags."""
    match = re.search(
        r"<IMPROVED_INSTRUCTION>\s*(.*?)\s*</IMPROVED_INSTRUCTION>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()


def _extract_numbered_candidates(response: str, n: int) -> list[str]:
    """Extract ``[1] ...``, ``[2] ...`` style numbered candidates."""
    pattern = re.compile(r"\[(\d+)\]\s*(.*?)(?=\[\d+\]|$)", re.DOTALL)
    matches = pattern.findall(response)
    candidates = []
    for _, text in sorted(matches, key=lambda x: int(x[0])):
        cleaned = text.strip()
        if cleaned:
            candidates.append(cleaned)
    if not candidates:
        # Fallback: split on newlines numbered 1. or 1)
        lines = response.strip().splitlines()
        for line in lines:
            stripped = re.sub(r"^\d+[\.\)]\s*", "", line).strip()
            if stripped:
                candidates.append(stripped)
    return candidates[:n]
