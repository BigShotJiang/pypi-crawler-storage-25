"""
---
title: MetaOptimizer — Optimize the Optimizer
summary: >
    Meta-level optimization that treats the inner optimizer's prompts
    and strategies as parameters to optimize. Includes MetaOptimizer
    (strategy-level updates), MetaTrainer (nested training loop),
    BiLevelOptimizer (outer/inner time-scale separation), and
    OptimizerFusion (LLM-guided multi-optimizer combination).
---

# Meta-Level Optimization

Meta-optimizers operate on the optimizer itself rather than on the
task parameters directly. They observe inner optimization behavior
(score trajectories, update patterns) and use that signal to improve
the optimization strategy.

| Class | Analog | Role |
|-------|--------|------|
| ``MetaOptimizer`` | Learning rate scheduler | Adapts inner optimizer via LLM |
| ``MetaTrainer`` | Hyper-training loop | Nested outer/inner training |
| ``BiLevelOptimizer`` | Bi-level optimization | Two time-scale loops |
| ``OptimizerFusion`` | Optimizer ensemble | LLM-guided combination |
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

META_SYSTEM_PROMPT = """\
You are an expert optimization strategist. Your task is to analyze how \
an optimizer has been performing and suggest improvements to its strategy, \
prompts, or hyperparameters."""

META_ANALYZE_PROMPT = """\
Here is the current state of an optimization process:

<OPTIMIZER_TYPE>
{optimizer_type}
</OPTIMIZER_TYPE>

<TARGET>
{target}
</TARGET>

<SCORE_TRAJECTORY>
{trajectory_text}
</SCORE_TRAJECTORY>

<CURRENT_STRATEGY>
{strategy_text}
</CURRENT_STRATEGY>

Based on the score trajectory, analyze:
1. Is the optimizer converging, diverging, or oscillating?
2. What aspects of the strategy should change?
3. What concrete modifications would improve performance?

Provide a revised strategy between the tags below:

<IMPROVED_STRATEGY>
[Your improved strategy here]
</IMPROVED_STRATEGY>"""

FUSION_SYSTEM_PROMPT = """\
You are an expert at combining optimization strategies. Given proposals \
from multiple optimizers, produce a single unified update that captures \
the best aspects of each proposal."""

FUSION_PROMPT = """\
Here is the current parameter value:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

Multiple optimizers have proposed different updates:

<PROPOSALS>
{proposals_text}
</PROPOSALS>

{scores_text}\
Select the best aspects of each proposal. Produce a single improved \
version that combines the strengths of the proposals.

Output ONLY the improved text between the tags below:

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


def _extract_tag(response: str, tag: str) -> str:
    """Extract text between XML-style tags."""
    pattern = rf"<{tag}>\s*(.*?)\s*</{tag}>"
    match = re.search(pattern, response, re.DOTALL)
    if match:
        return match.group(1).strip()
    return response.strip()


# ---------------------------------------------------------------------------
# MetaOptimizer
# ---------------------------------------------------------------------------


class MetaOptimizer(Optimizer):
    r"""
    ## MetaOptimizer

    Wraps another optimizer and treats its behavior as a signal for
    meta-level adaptation. After each inner optimization cycle, the
    MetaOptimizer analyzes the score trajectory and proposes changes
    to the inner optimizer's strategy.

    Targets:
    - ``"prompts"`` — rewrites the inner optimizer's prompt templates
    - ``"strategy"`` — adjusts the optimization approach
    - ``"hyperparams"`` — suggests hyperparameter changes

    .. code-block:: python

        inner = TGD(params=[p], engine=engine)
        meta = MetaOptimizer(
            params=[p], engine=engine,
            inner_optimizer=inner,
        )
        # Inner loop
        for step in range(5):
            loss.backward(engine)
            inner.step()
            meta.record_score(evaluate())
        # Meta step
        meta.step()
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        inner_optimizer: Optimizer | None = None,
        target: str = "prompts",  # "prompts" | "strategy" | "hyperparams"
        max_history: int = 50,
    ) -> None:
        super().__init__(params, engine=engine)
        self.inner = inner_optimizer
        self.target = target
        self.max_history = max_history
        self._score_history: list[float] = []
        self._strategy_text: str = ""

    def record_score(self, score: float) -> None:
        """Record an evaluation score after an inner optimizer step."""
        self._score_history.append(score)
        if len(self._score_history) > self.max_history:
            self._score_history = self._score_history[-self.max_history :]

    def step(self) -> None:
        """Analyze inner optimizer performance and adapt strategy.

        If no engine is available, falls back to running inner.step().
        """
        if self.engine is None or not self._score_history:
            # Fallback: just run inner optimizer
            if self.inner is not None:
                self.inner.step()
            return

        # Build trajectory text
        trajectory_lines: list[str] = []
        for i, score in enumerate(self._score_history):
            trajectory_lines.append(f"Step {i + 1}: {score:.4f}")
        trajectory_text = "\n".join(trajectory_lines)

        # Get optimizer type info
        optimizer_type = type(self.inner).__name__ if self.inner else "Unknown"

        # Current strategy
        strategy_text = self._strategy_text or f"Default {optimizer_type} strategy"

        prompt = META_ANALYZE_PROMPT.format(
            optimizer_type=optimizer_type,
            target=self.target,
            trajectory_text=trajectory_text,
            strategy_text=strategy_text,
        )

        response = self.engine.generate(
            prompt, system_prompt=META_SYSTEM_PROMPT
        )
        self._strategy_text = _extract_tag(response, "IMPROVED_STRATEGY")

        # Run inner optimizer with updated strategy context
        if self.inner is not None:
            self.inner.step()

    def propose(self) -> None:
        """Propose strategy changes without committing inner step."""
        if self.inner is not None:
            self.inner.propose()

    def state_dict(self) -> dict[str, Any]:
        """Return meta-optimizer state."""
        state = super().state_dict()
        state["score_history"] = list(self._score_history)
        state["strategy_text"] = self._strategy_text
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore meta-optimizer state."""
        super().load_state_dict(state)
        self._score_history = state.get("score_history", [])
        self._strategy_text = state.get("strategy_text", "")


# ---------------------------------------------------------------------------
# MetaTrainer
# ---------------------------------------------------------------------------


class MetaTrainer:
    r"""
    ## MetaTrainer

    Nested training: outer loop optimizes optimizer strategy,
    inner loop uses it to optimize task parameters.

    Each outer step:
    1. Run inner optimizer for ``inner_steps`` steps
    2. Evaluate performance
    3. Call ``meta_optimizer.step()`` to adapt strategy

    .. code-block:: python

        meta = MetaOptimizer(params=[p], engine=engine, inner_optimizer=tgd)
        trainer = MetaTrainer(meta_optimizer=meta, inner_steps=5)
        trainer.train(
            num_outer_steps=10,
            eval_fn=lambda: evaluate_on_val_set(),
            step_fn=lambda: (loss.backward(engine), tgd.step()),
        )
    """

    def __init__(
        self,
        meta_optimizer: MetaOptimizer | None = None,
        inner_steps: int = 5,
    ) -> None:
        self.meta_optimizer = meta_optimizer
        self.inner_steps = inner_steps
        self.history: list[dict[str, Any]] = []

    def train(
        self,
        num_outer_steps: int = 10,
        eval_fn: Optional[Callable[[], float]] = None,
        step_fn: Optional[Callable[[], None]] = None,
    ) -> list[dict[str, Any]]:
        """Run nested training loop.

        Args:
            num_outer_steps: Number of meta-optimization rounds.
            eval_fn: Evaluation function returning a score.
            step_fn: Inner optimization step function. If ``None``,
                calls ``meta_optimizer.inner.step()``.

        Returns:
            History of ``{"outer_step": int, "scores": [float], ...}``.
        """
        if self.meta_optimizer is None:
            return self.history

        for outer in range(num_outer_steps):
            inner_scores: list[float] = []

            # Inner loop
            for _inner in range(self.inner_steps):
                if step_fn is not None:
                    step_fn()
                elif self.meta_optimizer.inner is not None:
                    self.meta_optimizer.inner.step()

                # Evaluate after each inner step
                if eval_fn is not None:
                    score = eval_fn()
                    inner_scores.append(score)
                    self.meta_optimizer.record_score(score)

            # Meta step — adapt strategy based on trajectory
            self.meta_optimizer.step()

            record: dict[str, Any] = {
                "outer_step": outer,
                "scores": inner_scores,
            }
            if inner_scores:
                record["best_score"] = max(inner_scores)
                record["last_score"] = inner_scores[-1]
            self.history.append(record)

        return self.history


# ---------------------------------------------------------------------------
# BiLevelOptimizer
# ---------------------------------------------------------------------------


class BiLevelOptimizer(Optimizer):
    r"""
    ## BiLevelOptimizer

    Two optimization loops at different time scales:
    outer optimizes strategy/structure, inner optimizes content/prompts.

    Each ``step()`` runs the full inner loop then one outer step.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        outer: Optimizer | None = None,
        inner: Optimizer | None = None,
        inner_steps: int = 5,
    ) -> None:
        super().__init__(params, engine=engine)
        self.outer = outer
        self.inner = inner
        self.inner_steps = inner_steps

    def step(self) -> None:
        """One bi-level step: full inner loop then one outer step."""
        # Inner loop
        if self.inner:
            for _ in range(self.inner_steps):
                self.inner.step()
        # Outer step
        if self.outer:
            self.outer.step()


# ---------------------------------------------------------------------------
# OptimizerFusion
# ---------------------------------------------------------------------------


class OptimizerFusion(Optimizer):
    r"""
    ## OptimizerFusion

    Collects update proposals from multiple child optimizers and uses
    the LLM engine to select and combine the best aspects into a
    single unified update.

    Without an engine, falls back to sequential execution (last
    optimizer's update wins).

    .. code-block:: python

        fusion = OptimizerFusion(
            params=[p], engine=engine,
            optimizers=[tgd, opro, gepa],
        )
        fusion.step()
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM | None = None,
        optimizers: list[Optimizer] | None = None,
        score_fn: Optional[Callable[[], float]] = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.optimizers = optimizers or []
        self.score_fn = score_fn

    def step(self) -> None:
        """Collect proposals from all child optimizers and fuse them.

        For each parameter, each child optimizer proposes an update.
        The engine then combines the proposals into a single update.
        If no engine is available, runs optimizers sequentially.
        """
        if not self.optimizers:
            return

        if self.engine is None:
            # Fallback: sequential execution
            for opt in self.optimizers:
                opt.step()
            return

        # Collect proposals from each optimizer
        for param in self.params:
            if not param.requires_opt:
                continue

            original_data = param.data
            proposals: list[dict[str, Any]] = []

            for opt in self.optimizers:
                # Propose via each optimizer
                param.update(original_data)  # Reset to original
                opt.step()
                proposal_data = param.data

                # Score the proposal if scoring function available
                score = None
                if self.score_fn is not None:
                    score = self.score_fn()

                proposals.append(
                    {
                        "optimizer": type(opt).__name__,
                        "proposal": proposal_data,
                        "score": score,
                    }
                )

            # Reset to original before fusion
            param.update(original_data)

            # Build fusion prompt
            proposals_text = "\n\n".join(
                f"--- Proposal from {p['optimizer']} ---\n{p['proposal']}"
                for p in proposals
            )

            scores_text = ""
            if any(p["score"] is not None for p in proposals):
                scores_lines = [
                    f"{p['optimizer']}: {p['score']:.4f}"
                    for p in proposals
                    if p["score"] is not None
                ]
                scores_text = (
                    "Proposal scores (higher is better):\n"
                    + "\n".join(scores_lines)
                    + "\n\n"
                )

            prompt = FUSION_PROMPT.format(
                role=param.role_description,
                current_value=original_data,
                proposals_text=proposals_text,
                scores_text=scores_text,
            )

            response = self.engine.generate(
                prompt, system_prompt=FUSION_SYSTEM_PROMPT
            )
            fused = _extract_tag(response, "IMPROVED_VARIABLE")
            param.update(fused)
