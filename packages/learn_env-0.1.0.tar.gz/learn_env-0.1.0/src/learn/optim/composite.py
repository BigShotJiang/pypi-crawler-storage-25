"""
---
title: CompositeOptimizer — Multi-Strategy Parameter Routing
summary: >
    Routes different parameter groups to different optimizers,
    enabling mixed optimization strategies (e.g., gradient-based
    for prompts + discrete search for few-shot demos).
    Addresses API Issue #4.
---

# CompositeOptimizer

AdalFlow-style parameter routing: different parameter types get
different optimizers. The CompositeOptimizer calls each sub-optimizer
on its assigned parameter group.

$$\\text{CompositeOptimizer} = \\{(\\text{opt}_i, \\text{params}_i)\\}_{i=1}^{k}$$
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class CompositeOptimizer(Optimizer):
    r"""
    <a id="CompositeOptimizer"></a>

    ## CompositeOptimizer

    Maps parameter groups to different optimizer instances. Each group
    is optimized independently using its assigned strategy.

    ```python
    prompt_opt = TGD(params=prompt_params, engine=engine)
    demo_opt = OPRO(params=demo_params, engine=engine)
    composite = CompositeOptimizer(groups=[
        (prompt_opt, prompt_params),
        (demo_opt, demo_params),
    ])
    composite.step()  # Calls each sub-optimizer
    ```
    """

    def __init__(
        self,
        groups: list[tuple[Optimizer, list[Parameter]]] | None = None,
        engine: EngineLM | None = None,
    ) -> None:
        all_params = []
        self.groups: list[tuple[Optimizer, list[Parameter]]] = groups or []
        for _, params in self.groups:
            all_params.extend(params)
        super().__init__(all_params, engine=engine)

    def add_group(self, optimizer: Optimizer, params: list[Parameter]) -> None:
        """Add a new optimizer-parameter group.

        Args:
            optimizer: The optimizer for this group.
            params: Parameters managed by this optimizer.
        """
        self.groups.append((optimizer, params))
        self.params.extend(params)

    def step(self) -> None:
        """Run one step on each optimizer group."""
        for opt, _ in self.groups:
            opt.step()

    def zero_grad(self) -> None:
        """Clear gradients on all optimizer groups."""
        for opt, _ in self.groups:
            opt.zero_grad()

    def propose(self) -> None:
        """Propose updates for each group."""
        for opt, _ in self.groups:
            opt.propose()

    def state_dict(self) -> dict[str, Any]:
        """Serialize all sub-optimizer states."""
        return {
            "groups": [
                {
                    "optimizer_state": opt.state_dict(),
                    "param_data": [p.data for p in params],
                }
                for opt, params in self.groups
            ]
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore all sub-optimizer states."""
        for (opt, params), group_state in zip(
            self.groups, state.get("groups", [])
        ):
            opt.load_state_dict(group_state.get("optimizer_state", {}))
            for p, d in zip(params, group_state.get("param_data", [])):
                p.update(d)
