"""
---
title: Optimizer Base Classes
summary: >
    Abstract base classes for all optimizers in the learn framework.
    Mirrors ``torch.optim.Optimizer`` with text-appropriate semantics.
---

# Optimizer Base

Two optimizer ABCs:

* ``Optimizer`` — general base (holds params, zero_grad, step)
* ``LossFunction`` — evaluates a prediction against a target
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class Optimizer(ABC):
    r"""
    <a id="Optimizer"></a>

    ## Optimizer

    Base class for all optimizers — the textual analog of
    ``torch.optim.Optimizer``.

    | ``torch.optim.Optimizer`` | ``Optimizer`` |
    |--------------------------|---------------|
    | ``__init__(params, lr)`` | ``__init__(params, engine)`` |
    | ``zero_grad()`` | ``zero_grad()`` |
    | ``step()`` | ``step()`` |
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: Optional[EngineLM] = None,
    ) -> None:
        self.params = list(params)
        self.engine = engine

    def zero_grad(self) -> None:
        """Clear gradients on all parameters."""
        for p in self.params:
            p.zero_grad()

    @abstractmethod
    def step(self) -> None:
        """Perform one optimization step."""
        ...

    def propose(self) -> None:
        """Propose updates without committing (optional override)."""
        self.step()

    def revert(self) -> None:
        """Revert proposed updates on all parameters."""
        for p in self.params:
            p.revert()

    def state_dict(self) -> dict[str, Any]:
        """Return optimizer state for serialization."""
        return {"param_data": [p.data for p in self.params]}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore optimizer state."""
        for p, data in zip(self.params, state.get("param_data", [])):
            p.update(data)
