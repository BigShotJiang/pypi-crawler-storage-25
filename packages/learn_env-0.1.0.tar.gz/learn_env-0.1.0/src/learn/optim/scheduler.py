"""
---
title: OptimizationScheduler — Multi-Optimizer Orchestration
summary: >
    Orchestrates multiple optimizers in sequence, interleaved,
    or adaptive modes.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from learn.optim.base import Optimizer


class OptimizationScheduler:
    r"""
    ## OptimizationScheduler — Multi-Optimizer Orchestration

    Strategies:
    * ``sequential`` — run each optimizer in order per step
    * ``interleaved`` — alternate between optimizers across steps
    * ``adaptive`` — choose optimizer based on improvement signal

    ```python
    scheduler = OptimizationScheduler(
        optimizers=[tgd, opro],
        strategy="sequential",
    )
    scheduler.step()
    ```
    """

    def __init__(
        self,
        optimizers: list[Optimizer],
        strategy: str = "sequential",
    ) -> None:
        if strategy not in ("sequential", "interleaved", "adaptive"):
            raise ValueError(f"Unknown strategy: {strategy}")
        self.optimizers = optimizers
        self.strategy = strategy
        self._step_count = 0

    def step(self) -> None:
        """Perform one optimization step."""
        if self.strategy == "sequential":
            self._sequential_step()
        elif self.strategy == "interleaved":
            self._interleaved_step()
        elif self.strategy == "adaptive":
            self._adaptive_step()

        self._step_count += 1

    def _sequential_step(self) -> None:
        """Run all optimizers in sequence."""
        for opt in self.optimizers:
            opt.step()

    def _interleaved_step(self) -> None:
        """Run one optimizer per step, cycling through."""
        if not self.optimizers:
            return
        idx = self._step_count % len(self.optimizers)
        self.optimizers[idx].step()

    def _adaptive_step(self) -> None:
        """For now, same as interleaved. Full implementation needs
        improvement tracking."""
        self._interleaved_step()

    def zero_grad(self) -> None:
        """Clear gradients on all optimizers."""
        for opt in self.optimizers:
            opt.zero_grad()

    @property
    def step_count(self) -> int:
        return self._step_count
