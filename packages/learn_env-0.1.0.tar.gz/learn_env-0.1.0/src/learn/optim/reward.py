"""
---
title: Composite Reward Framework
summary: >
    Weighted multi-component reward composition for RL-style optimization.
    Addresses API Issue #23: examples manually computing and combining
    2-4 reward components.
---

# Composite Reward

Modern RL-for-LLM methods use multi-component rewards:
- R-Zero: $r = 1 - 2|\\hat{p} - 0.5|$ (uncertainty) + repetition penalty
- Optima: $R = R_{\\text{task}} - \\lambda_t R_{\\text{token}} + \\lambda_l / R_{\\text{loss}}$

This module provides composable reward functions with built-in normalization.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Callable

# Reward function type: takes context dict, returns float
RewardFn = Callable[[dict[str, Any]], float]


@dataclass
class RewardSignal:
    """Single reward component with optional normalization."""

    name: str
    value: float = 0.0
    weight: float = 1.0
    raw_value: float = 0.0

    @property
    def weighted(self) -> float:
        return self.value * self.weight


class RewardNormalizer:
    """Online reward normalization using running statistics.

    $$\\hat{r} = \\frac{r - \\mu}{\\sigma + \\epsilon}$$
    """

    def __init__(self, method: str = "zscore", epsilon: float = 1e-8) -> None:
        self.method = method
        self.epsilon = epsilon
        self._count = 0
        self._mean = 0.0
        self._m2 = 0.0
        self._min = float("inf")
        self._max = float("-inf")

    def update(self, value: float) -> None:
        """Update running statistics with a new value."""
        self._count += 1
        delta = value - self._mean
        self._mean += delta / self._count
        delta2 = value - self._mean
        self._m2 += delta * delta2
        self._min = min(self._min, value)
        self._max = max(self._max, value)

    @property
    def std(self) -> float:
        if self._count < 2:
            return 1.0
        return math.sqrt(self._m2 / (self._count - 1))

    def normalize(self, value: float) -> float:
        """Normalize a value using the configured method."""
        self.update(value)
        if self.method == "zscore":
            return (value - self._mean) / (self.std + self.epsilon)
        elif self.method == "minmax":
            rng = self._max - self._min
            if rng < self.epsilon:
                return 0.0
            return (value - self._min) / rng
        return value


class CompoundReward:
    r"""
    <a id="CompoundReward"></a>

    ## CompoundReward

    Composable multi-component reward with automatic normalization.

    ```python
    reward = CompoundReward()
    reward.add_component("accuracy", weight=1.0)
    reward.add_component("cost", weight=-0.5, normalize="zscore")
    reward.add_component("length_bonus", weight=0.1)

    total = reward.compute({
        "accuracy": 0.85,
        "cost": 0.002,
        "length_bonus": 1.0,
    })
    ```
    """

    def __init__(self) -> None:
        self._components: dict[str, float] = {}
        self._normalizers: dict[str, RewardNormalizer] = {}
        self._custom_fns: dict[str, RewardFn] = {}
        self._history: list[dict[str, RewardSignal]] = []

    def add_component(
        self,
        name: str,
        weight: float = 1.0,
        normalize: str | None = None,
        fn: RewardFn | None = None,
    ) -> None:
        """Add a reward component.

        Args:
            name: Component name (must match key in compute dict).
            weight: Multiplier for this component.
            normalize: Normalization method ("zscore", "minmax", or None).
            fn: Optional custom function to compute this component.
        """
        self._components[name] = weight
        if normalize:
            self._normalizers[name] = RewardNormalizer(method=normalize)
        if fn:
            self._custom_fns[name] = fn

    def compute(self, values: dict[str, Any]) -> float:
        """Compute the weighted composite reward.

        Args:
            values: Dict mapping component names to raw reward values
                (or context dict for custom functions).

        Returns:
            Weighted sum of all components.
        """
        signals: dict[str, RewardSignal] = {}
        total = 0.0

        for name, weight in self._components.items():
            # Get raw value from custom fn or direct value
            if name in self._custom_fns:
                raw = self._custom_fns[name](values)
            else:
                raw = float(values.get(name, 0.0))

            # Normalize if configured
            normalized = raw
            if name in self._normalizers:
                normalized = self._normalizers[name].normalize(raw)

            signal = RewardSignal(
                name=name,
                value=normalized,
                weight=weight,
                raw_value=raw,
            )
            signals[name] = signal
            total += signal.weighted

        self._history.append(signals)
        return total

    def compute_advantages(
        self,
        rewards: list[float],
        epsilon: float = 1e-8,
    ) -> list[float]:
        r"""Compute group-relative advantages (GRPO-style).

        $$A_i = \frac{r_i - \bar{r}}{\sigma_r + \epsilon}$$

        Args:
            rewards: List of raw rewards for a group.
            epsilon: Stability constant.

        Returns:
            List of advantages.
        """
        if not rewards:
            return []
        mean = sum(rewards) / len(rewards)
        var = sum((r - mean) ** 2 for r in rewards) / max(len(rewards) - 1, 1)
        std = math.sqrt(var)
        return [(r - mean) / (std + epsilon) for r in rewards]

    @property
    def history(self) -> list[dict[str, RewardSignal]]:
        return self._history
