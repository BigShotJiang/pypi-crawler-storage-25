"""
---
title: EvalToLoss — Numeric Evaluation to Textual Loss Bridge
summary: >
    Converts a scalar metric into a textual feedback signal
    that textual optimizers can use.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class EvalToLoss:
    r"""
    ## EvalToLoss — Numeric → Textual Bridge

    Converts a scalar metric (accuracy, F1, etc.) into a textual feedback
    signal that textual optimizers like TGD can use.

    ```python
    bridge = EvalToLoss(engine=engine)
    feedback = bridge.convert(
        prediction="The answer is 5",
        target="42",
        score=0.0,
    )
    # feedback is a string with actionable improvement suggestions
    ```
    """

    def __init__(self, engine: Optional[EngineLM] = None) -> None:
        self.engine = engine

    def convert(
        self,
        prediction: str,
        target: str,
        score: float,
        metric_name: str = "score",
    ) -> str:
        """Convert a numeric evaluation result to textual feedback."""
        if score >= 1.0:
            return f"The output is correct ({metric_name}: {score:.4f}). No changes needed."

        # Default feedback without engine
        default_feedback = (
            f"The {metric_name} was {score:.4f} out of 1.0. "
            f"The prediction was: {prediction}\n"
            f"The target was: {target}\n"
            f"Please improve the output to better match the target."
        )

        if self.engine is None:
            return default_feedback

        prompt = (
            f"An evaluation produced the following result:\n"
            f"Metric: {metric_name}\n"
            f"Score: {score:.4f} (out of 1.0)\n"
            f"Prediction: {prediction}\n"
            f"Target: {target}\n\n"
            f"Provide specific, actionable feedback on what went wrong "
            f"and how the prediction could be improved."
        )
        return self.engine.generate(prompt)
