"""
---
title: FeedbackDescent — Pairwise Comparison Optimizer
summary: >
    Generates two candidate updates, asks LLM to compare them,
    uses the comparison rationale as the update signal.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT, TGD_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

COMPARE_PROMPT = """\
Here are two candidate improvements for a variable:

<CANDIDATE_A>
{candidate_a}
</CANDIDATE_A>

<CANDIDATE_B>
{candidate_b}
</CANDIDATE_B>

<ORIGINAL_FEEDBACK>
{gradient_text}
</ORIGINAL_FEEDBACK>

Which candidate better addresses the feedback? Respond with ONLY \
"A" or "B", followed by a brief rationale."""


class FeedbackDescent(TextOptimizer):
    r"""
    ## FeedbackDescent — Pairwise Comparison Optimizer

    Generates two candidate updates, asks LLM to compare them,
    and selects the winner. The comparison rationale can inform
    future updates.

    Reference: Feedback Descent (Ye et al., 2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
    ) -> None:
        super().__init__(params, engine=engine)
        self._rationales: list[str] = []

    def propose(self) -> None:
        """Generate two candidates and select the better one."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            constraints_text = ""
            if param.constraints:
                constraints_text = (
                    "Constraints to follow:\n"
                    + "\n".join(f"- {c}" for c in param.constraints)
                    + "\n\n"
                )

            # Generate two candidates
            base_prompt = TGD_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                constraints_text=constraints_text,
            )

            resp_a = self.engine.generate(
                base_prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            candidate_a = _extract_improved_variable(resp_a)

            resp_b = self.engine.generate(
                base_prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            candidate_b = _extract_improved_variable(resp_b)

            # Compare
            compare = COMPARE_PROMPT.format(
                candidate_a=candidate_a,
                candidate_b=candidate_b,
                gradient_text=gradient_text,
            )
            result = self.engine.generate(compare)
            self._rationales.append(result)

            if result.strip().upper().startswith("A"):
                param.update(candidate_a)
            else:
                param.update(candidate_b)


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
