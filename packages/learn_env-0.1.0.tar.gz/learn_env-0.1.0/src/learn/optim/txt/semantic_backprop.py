"""
---
title: SemanticBackpropagation — Neighborhood-Conditioned Gradient Descent
summary: >
    Correct textual gradient descent for agentic graphs: the backward
    function for each predecessor node conditions on ALL sibling predecessors
    (the full neighborhood), not just the single node. Includes the
    validation-gated Semantic Gradient Descent update rule (Algorithm 2).
---

# Semantic Backpropagation with Neighborhood Conditioning

Port of **"How to Correctly Do Semantic Backpropagation on Language-Based
Agentic Systems"** (Wang, Alyahya, Ashley, Serikov, Khizbullin, Faccio,
Schmidhuber, KAUST/IDSIA), December 2024 — arXiv:2412.03624.

## Key Insight

Standard TGD / TextGrad computes gradients for each variable independently,
ignoring sibling predecessor nodes.  This violates the chain rule: when
node $w$ has predecessors $\\{v_1, v_2, \\ldots\\}$, the backward function for
$v_i$ should condition on **all** predecessors, not just $v_i$ alone.

$$\\nabla_{v}^{w}\\,\\ell_Q =
    \\hat{h}_w^v\\bigl(\\mathrm{Predecessors}(w),\\; w,\\; \\nabla_w\\ell_Q\\bigr)$$

## PyTorch Analogy

| PyTorch | SemanticBackpropagation |
|---------|-------------------------|
| ``loss.backward()`` | ``compute_gradients()`` passing all neighbors |
| ``optimizer.step()`` | ``step()`` with validation gate |
| Gradient tensor | Per-node gradient string |
| Computation graph | ``NodeContext`` dict |

## Usage

```python
from learn.optim.txt.semantic_backprop import SemanticBackpropagation

opt = SemanticBackpropagation(
    params=[hint1_param, hint2_param],
    engine=engine,
    validation_fn=lambda: evaluate(engine, val_data, ...),
)

for question, expected in train_data:
    forwards = run_forward_pass(engine, question, [hint1_param, hint2_param])
    opt.record_error(
        question=question,
        expected=expected,
        prediction=forwards["answer"],
        hint_texts=forwards["hints"],
        raw_output=forwards["raw_output"],
        agg_instruction=agg_param.data,
    )

opt.step()  # update if validation score doesn't drop
```
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Optional

from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# Prompt templates — faithful reproductions from the original codebase
# ---------------------------------------------------------------------------

NEIGHBORHOOD_BACKWARD_PROMPT = """\
A task is performed given a question and some hints.

Task:
    {instruction}

Question:
    {question}

Hints:
{hints_text}

Output attempt in response to the task:
    {output}

Feedback on the output:
    {feedback}

Based on the feedback, how each hint should be changed?
Respond one line per hint. Start with "Hint x" for the xth line."""

NO_NEIGHBORHOOD_BACKWARD_PROMPT = """\
A task is performed given a context and some hints.
One of the hints is:
{hint}

Answered: {answer}

However, the desired answer is {desired}.

How the hint needs to be changed to get the desired output? Respond one line."""

UPDATE_PROMPT = """\
I'm trying to write a task-specific question answering assistant.

My current prompt is:
"{current_instruction}"

Here are some examples that it did not answer well:
{error_examples}

Based on the above examples, write an improved prompt.
Show your reasoning steps.
Do not include the keyword "feedback" or any example-specific content \
in the prompt.
Finish with the improved prompt wrapped by <prompt> and </prompt>."""

LOSS_FEEDBACK_TEMPLATE = 'The expected output is: "{expected}".'


def _extract_prompt(text: str) -> str:
    """Extract improved instruction from ``<prompt>...</prompt>`` tags."""
    match = re.search(r"<prompt>(.*?)</prompt>", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()


# ---------------------------------------------------------------------------
# Data container
# ---------------------------------------------------------------------------


@dataclass
class ErrorExample:
    """A single training error used to compute gradients.

    Attributes:
        question: The input text (query).
        expected: Ground-truth answer.
        prediction: What the model produced.
        hint_texts: The intermediate hint texts generated in the forward pass.
        raw_output: The raw aggregation-layer output.
        agg_instruction: The aggregation instruction text at time of inference.
        gradients: Per-hint-index gradient text (populated during backward).
    """
    question: str
    expected: str
    prediction: str
    hint_texts: list[str] = field(default_factory=list)
    raw_output: str = ""
    agg_instruction: str = ""
    gradients: dict[int, str] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Core backward functions (can also be used standalone)
# ---------------------------------------------------------------------------


def compute_neighborhood_gradients(
    engine: EngineLM,
    question: str,
    hint_texts: list[str],
    raw_output: str,
    expected: str,
    agg_instruction: str,
) -> dict[int, str]:
    r"""Backward pass WITH neighborhood conditioning (Algorithm 1).

    The backward function sees ALL hints simultaneously.  This is the key
    contribution: conditioning on the full predecessor set gives the LLM
    enough context to produce useful, non-redundant per-hint gradients.

    Returns:
        Dict mapping hint_index → gradient string.
    """
    feedback = LOSS_FEEDBACK_TEMPLATE.format(expected=expected)
    hints_formatted = "\n".join(
        f"    {i + 1}. {h}" for i, h in enumerate(hint_texts)
    )
    prompt = NEIGHBORHOOD_BACKWARD_PROMPT.format(
        instruction=agg_instruction,
        question=question,
        hints_text=hints_formatted,
        output=raw_output,
        feedback=feedback,
    )
    gradient_text = engine.generate(prompt)

    gradients: dict[int, str] = {}
    for i in range(len(hint_texts)):
        pattern = rf"Hint\s*{i + 1}[\s:]*(.+)"
        match = re.search(pattern, gradient_text, re.IGNORECASE)
        if match:
            gradients[i] = match.group(1).strip()
        else:
            gradients[i] = gradient_text  # fallback

    return gradients


def compute_naive_gradients(
    engine: EngineLM,
    hint_texts: list[str],
    raw_output: str,
    expected: str,
) -> dict[int, str]:
    r"""Backward pass WITHOUT neighborhood conditioning (TextGrad-style).

    Each hint gradient is computed independently, ignoring sibling hints.
    This is the ablation baseline — corresponds to ``fdbk_prompt_no_sibling``
    in the original codebase.

    Returns:
        Dict mapping hint_index → gradient string.
    """
    gradients: dict[int, str] = {}
    for i, hint in enumerate(hint_texts):
        # Extract the final answer from the raw output for comparison
        answer_match = re.search(
            r"<output statement>(.*?)</output statement>", raw_output, re.DOTALL
        )
        answer = answer_match.group(1).strip() if answer_match else raw_output.strip()
        prompt = NO_NEIGHBORHOOD_BACKWARD_PROMPT.format(
            hint=hint,
            answer=answer,
            desired=expected,
        )
        gradient_text = engine.generate(prompt)
        gradients[i] = gradient_text

    return gradients


# ---------------------------------------------------------------------------
# Optimizer class
# ---------------------------------------------------------------------------


class SemanticBackpropagation(TextOptimizer):
    r"""
    ## SemanticBackpropagation

    Neighborhood-conditioned textual gradient descent optimizer.

    The backward pass for each hint parameter conditions on ALL predecessor
    hint texts (the neighborhood), rather than computing each gradient in
    isolation as TextGrad does.  The update step (Algorithm 2) includes a
    **validation gate**: the new parameter values are accepted only if the
    validation score does not decrease.

    ```python
    opt = SemanticBackpropagation(
        params=[hint1_param, hint2_param],
        engine=engine,
        validation_fn=lambda: evaluate_accuracy(engine, val_samples, ...),
    )

    for q, expected in train_samples:
        fwd = forward_pass(engine, q, hint_params, agg_param)
        if fwd.score < 1.0:
            opt.record_error(
                question=q,
                expected=expected,
                prediction=fwd.answer,
                hint_texts=fwd.hints,
                raw_output=fwd.raw_output,
                agg_instruction=agg_param.data,
            )

    opt.step()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        validation_fn: Optional[Callable[[], float]] = None,
        use_neighborhood: bool = True,
        max_error_examples: int = 10,
    ) -> None:
        """
        Args:
            params: The prompt parameters to optimize (hint instructions).
            engine: The LLM engine used for both backward and update passes.
            validation_fn: Called before and after update; if provided, new
                values are only accepted when new_score >= old_score.
            use_neighborhood: If True (default), conditions gradients on all
                sibling hints.  If False, uses naive per-hint gradients
                (TextGrad ablation baseline).
            max_error_examples: Maximum error examples to accumulate per step.
        """
        super().__init__(params, engine=engine)
        self.validation_fn = validation_fn
        self.use_neighborhood = use_neighborhood
        self.max_error_examples = max_error_examples
        self._error_examples: list[ErrorExample] = []

    def record_error(
        self,
        question: str,
        expected: str,
        prediction: str,
        hint_texts: list[str],
        raw_output: str,
        agg_instruction: str,
    ) -> None:
        """Accumulate an error example for the backward pass.

        Call this for each training sample that was predicted incorrectly.

        Args:
            question: The input text.
            expected: Ground-truth answer.
            prediction: Model prediction.
            hint_texts: List of intermediate hint outputs (one per hint param).
            raw_output: Raw aggregation-node output before extraction.
            agg_instruction: Current text of the aggregation instruction.
        """
        if len(self._error_examples) < self.max_error_examples:
            self._error_examples.append(
                ErrorExample(
                    question=question,
                    expected=expected,
                    prediction=prediction,
                    hint_texts=hint_texts,
                    raw_output=raw_output,
                    agg_instruction=agg_instruction,
                )
            )

    def clear_errors(self) -> None:
        """Clear accumulated error examples."""
        self._error_examples.clear()

    def compute_gradients(self) -> None:
        """Backward pass: compute per-node gradients for all error examples.

        Populates ``example.gradients[i]`` for each example and each hint
        parameter index using either neighborhood or naive backward.
        """
        assert self.engine is not None
        for example in self._error_examples:
            if self.use_neighborhood:
                example.gradients = compute_neighborhood_gradients(
                    engine=self.engine,
                    question=example.question,
                    hint_texts=example.hint_texts,
                    raw_output=example.raw_output,
                    expected=example.expected,
                    agg_instruction=example.agg_instruction,
                )
            else:
                example.gradients = compute_naive_gradients(
                    engine=self.engine,
                    hint_texts=example.hint_texts,
                    raw_output=example.raw_output,
                    expected=example.expected,
                )

    def propose(self) -> None:
        """Compute gradients then propose new parameter values.

        For each parameter $\\theta_i$:
        1. Format all error examples with gradients for that hint.
        2. Prompt the LLM with ``UPDATE_PROMPT`` to produce a new instruction.
        3. Extract the improved instruction from ``<prompt>...</prompt>`` tags.

        The actual ``update()`` is deferred to ``step()`` which applies the
        validation gate.
        """
        assert self.engine is not None
        if not self._error_examples:
            return

        self.compute_gradients()
        self._pending_values: list[str] = []

        for param_idx, param in enumerate(self.params):
            examples_text_parts = []
            for j, ex in enumerate(self._error_examples):
                gradient = ex.gradients.get(param_idx, "N/A")
                examples_text_parts.append(
                    f"\n    ## Example {j + 1}\n"
                    f"    Input: {ex.question}\n"
                    f"    My output: {ex.prediction}\n"
                    f"    Feedback received on my output: {gradient}\n"
                )

            if not examples_text_parts:
                self._pending_values.append(param.data)
                continue

            prompt = UPDATE_PROMPT.format(
                current_instruction=param.data,
                error_examples="".join(examples_text_parts),
            )
            response = self.engine.generate(prompt)
            improved = _extract_prompt(response)
            self._pending_values.append(improved)

    def step(self) -> None:
        """Semantic Gradient Descent update step (Algorithm 2).

        1. Evaluate baseline validation score (if ``validation_fn`` set).
        2. Compute gradients and propose new parameter values.
        3. Tentatively apply updates.
        4. Evaluate new validation score.
        5. If new_score < old_score → revert all parameter updates.
        6. Clear error examples.
        """
        assert self.engine is not None

        # --- Baseline validation score ---
        baseline_score: float | None = None
        if self.validation_fn is not None:
            baseline_score = self.validation_fn()

        # --- Propose new values (computes gradients internally) ---
        self.propose()

        if not hasattr(self, "_pending_values") or not self._pending_values:
            self.clear_errors()
            return

        # --- Save old values and apply updates ---
        old_values: list[str] = [p.data for p in self.params]
        for param, new_val in zip(self.params, self._pending_values):
            if new_val and new_val != param.data:
                param.update(new_val)

        # --- Validation gate ---
        if self.validation_fn is not None and baseline_score is not None:
            new_score = self.validation_fn()
            if new_score < baseline_score:
                # Revert all updates
                for param, old_val in zip(self.params, old_values):
                    param.update(old_val)

        del self._pending_values
        self.clear_errors()
