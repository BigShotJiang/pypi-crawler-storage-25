"""
---
title: TGD — Textual Gradient Descent
summary: >
    The simplest textual optimizer: takes each parameter's gradient,
    asks the optimizer LLM to produce an improved version, and updates
    the parameter. Analogous to vanilla SGD.
---

# Textual Gradient Descent (TGD)

TGD follows the same loop as SGD but in text space:

$$\\theta_{t+1} = \\text{LLM}_{\\text{opt}}\\bigl(
  \\theta_t, \\nabla_{\\text{text}} \\theta_t\\bigr)$$

1. Read current parameter value and its textual gradient
2. Format them into an optimizer prompt
3. Call the optimizer LLM to produce an improved version
4. Extract the improved text from ``<IMPROVED_VARIABLE>`` tags
5. Update the parameter
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Callable, Optional

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT, TGD_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class TGD(TextOptimizer):
    r"""
    <a id="TGD"></a>

    ## TGD — Textual Gradient Descent

    Vanilla textual SGD. For each parameter with gradients:

    1. Format gradient + current value into a prompt
    2. Call optimizer engine
    3. Extract ``<IMPROVED_VARIABLE>`` content
    4. Update the parameter

    Supports optional **validation gate**: when ``validation_fn`` is
    provided, proposed updates are evaluated before committing.
    Uses the ``Parameter.propose()`` / ``commit()`` / ``rollback()``
    protocol.

    ```python
    optimizer = TGD(params=[prompt_param], engine=engine)
    loss.backward(engine)
    optimizer.step()

    # With validation gate:
    optimizer = TGD(
        params=[prompt_param], engine=engine,
        validation_fn=lambda: evaluate_on_val_set(),
    )
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        validation_fn: Optional[Callable[[], float]] = None,
    ) -> None:
        super().__init__(params, engine=engine)
        self.validation_fn = validation_fn
        self._last_val_score: float = float("-inf")

    def propose(self) -> None:
        """Generate improved values for all parameters with gradients.

        When ``validation_fn`` is set, uses propose/commit/rollback
        semantics — the update is only accepted if the validation
        score improves.
        """
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Build constraints text
            constraints_text = ""
            if param.constraints:
                constraints_text = (
                    "Constraints to follow:\n"
                    + "\n".join(f"- {c}" for c in param.constraints)
                    + "\n\n"
                )

            prompt = TGD_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                constraints_text=constraints_text,
            )

            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )

            # Extract improved variable from response
            improved = _extract_improved_variable(response)

            if self.validation_fn is not None:
                # Validation gate: propose → evaluate → commit or rollback
                param.propose(improved)
                new_score = self.validation_fn()
                if new_score >= self._last_val_score:
                    param.commit()
                    self._last_val_score = new_score
                else:
                    param.rollback()
            else:
                # Direct update (original behavior)
                param.update(improved)


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags.

    Falls back to the full response if tags are not found.
    """
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
