"""
---
title: REVOLVE — Response-Evolution-Tracking Textual Optimizer
summary: >
    Second-order textual optimizer that tracks how responses evolve
    between consecutive iterations. Extends TGD with an evolution
    signal that detects stagnation or instability, then augments
    the gradient accordingly.
---

# REVOLVE — Optimizing AI Systems by Tracking Response Evolution

Port of **REVOLVE** (Zhang, Jin, Hu et al., 2025) — arXiv:2412.03092.

## Intuition

Standard TGD (TextGrad) is first-order: it only uses the gradient from
the *current* iteration to update parameters.  REVOLVE adds a
**second-order signal** by tracking how responses evolve across
iterations:

$$\\text{REVOLVE}(L(r(p_t))) =
    \\frac{\\tilde{\\partial} L(r(p_t)) + S(r(p_t), r(p_{t-1}))}{\\tilde{\\partial} p_t}$$

where the similarity function $S$ is:

$$S(r(p_t), r(p_{t-1})) =
    \\frac{\\| L(r(p_t)) - L(r(p_{t-1})) \\|}{\\| p_t - p_{t-1} \\|}$$

Under the small-step assumption this reduces to
$\\tilde{\\partial}^2 L / \\tilde{\\partial} p_t^2$, i.e. a curvature term.

## Three Delta Types

1. **Stagnating** (high similarity > 0.85): consecutive responses nearly
   identical → push harder, try a very different approach.
2. **Unstable** (low similarity < 0.25): drastic changes each iteration →
   refine carefully, make targeted incremental improvements.
3. **Evolving** (moderate): healthy progress → continue the trajectory.

## PyTorch Analogy

| PyTorch | REVOLVE |
|---------|---------|
| Momentum SGD | REVOLVE with trajectory memory |
| Second-order curvature | Evolution signal $S$ |
| Gradient accumulation | Past iterations context |

## Usage

```python
from learn.optim.txt.revolve import REVOLVE

optimizer = REVOLVE(params=[prompt_param], engine=engine)

for step in range(num_steps):
    optimizer.zero_grad()
    output = agent(input)
    # Record response for evolution tracking
    optimizer.record_response(key=input_key, response=output)
    loss = eval_fn(output, target)
    loss.backward(engine)
    optimizer.step()  # augments gradient with evolution signal before update
```
"""
from __future__ import annotations

import re
from collections import defaultdict
from typing import TYPE_CHECKING

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT, TGD_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


# ---------------------------------------------------------------------------
# Prompt templates — from REVOLVE paper Appendix A
# ---------------------------------------------------------------------------

REVOLVE_EVOLUTION_PREFIX = """\
<EVOLUTION_SIGNAL>
{signal}
</EVOLUTION_SIGNAL>

"""

REVOLVE_PAST_ITERATIONS_PREFIX = """\
{past_block}

"""


# ---------------------------------------------------------------------------
# Similarity helpers (Section 3.4)
# ---------------------------------------------------------------------------


def _token_jaccard(a: str, b: str) -> float:
    """Token-level Jaccard similarity between two strings."""
    a = a or ""
    b = b or ""
    ta = set(a.lower().split())
    tb = set(b.lower().split())
    if not ta and not tb:
        return 1.0  # both empty → identical
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def _char_ngram_similarity(a: str, b: str, n: int = 3) -> float:
    """Character n-gram Jaccard similarity (lightweight embedding proxy)."""
    a = a or ""
    b = b or ""

    def _ngrams(text: str) -> set[str]:
        text = text.lower()
        return {text[i : i + n] for i in range(max(len(text) - n + 1, 0))}

    ga, gb = _ngrams(a), _ngrams(b)
    if not ga and not gb:
        return 1.0  # both empty → identical
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def response_similarity(r_curr: str, r_prev: str) -> float:
    """Compute $S(r(p_t), r(p_{t-1}))$ — paper Section 3.4.

    Blends token-level and character n-gram similarities as a lightweight
    approximation of the BERTScore-style comparison in the paper.

    Returns a float in [0, 1]; higher = more similar.
    """
    return 0.5 * _token_jaccard(r_curr, r_prev) + 0.5 * _char_ngram_similarity(
        r_curr, r_prev
    )


def compute_evolution_feedback(
    curr_response: str,
    prev_response: str,
    iteration: int,
    stagnation_threshold: float = 0.85,
    instability_threshold: float = 0.25,
) -> tuple[str, str, float]:
    """Generate the REVOLVE evolution signal text.

    Returns ``(delta_type, feedback_text, similarity)`` where ``delta_type``
    is one of ``"stagnating"``, ``"unstable"``, or ``"evolving"``.

    Paper Section 3.4 + Appendix A system prompt:
    - High similarity → stagnating → push harder, try a very different approach
    - Low similarity  → unstable   → refine carefully, make incremental changes
    - Moderate        → evolving   → continue with measured adjustments
    """
    # No previous response at iteration 0
    if prev_response is None:
        return "initial", "", 0.0

    sim = response_similarity(curr_response, prev_response)

    if sim > stagnation_threshold:
        delta_type = "stagnating"
        feedback = (
            f"[REVOLVE Iter {iteration}] Similarity={sim:.3f} — STAGNATING. "
            "Consecutive responses are nearly identical; optimization is stuck. "
            "Make a significantly different attempt: restructure the instructions, "
            "adopt a new strategy, or explore an alternative decomposition."
        )
    elif sim < instability_threshold:
        delta_type = "unstable"
        feedback = (
            f"[REVOLVE Iter {iteration}] Similarity={sim:.3f} — UNSTABLE. "
            "The optimization is making erratic, large changes between iterations. "
            "Refine the current approach carefully — preserve what works and make "
            "targeted, incremental improvements rather than drastic shifts."
        )
    else:
        delta_type = "evolving"
        feedback = (
            f"[REVOLVE Iter {iteration}] Similarity={sim:.3f} — EVOLVING. "
            "Continue this trajectory with thoughtful, measured adjustments "
            "that build on previous progress."
        )

    return delta_type, feedback, sim


# ---------------------------------------------------------------------------
# Response trajectory tracker
# ---------------------------------------------------------------------------


class ResponseTrajectory:
    """Per-input response history for computing evolution signals.

    Stores (iteration, response) pairs keyed by an arbitrary string key
    (e.g. the input hash or input text itself for short inputs).
    """

    def __init__(self) -> None:
        self._history: dict[str, list[tuple[int, str]]] = defaultdict(list)

    def record(self, key: str, response: str, iteration: int) -> str | None:
        """Record a response and return the previous response (or None)."""
        hist = self._history[key]
        prev = hist[-1][1] if hist else None
        hist.append((iteration, response))
        return prev

    def get_latest(self, key: str) -> str | None:
        """Return the most recent response for *key*."""
        hist = self._history.get(key, [])
        return hist[-1][1] if hist else None

    def get_history(self, key: str) -> list[str]:
        """Return all responses for *key* in chronological order."""
        return [r for _, r in self._history.get(key, [])]

    def format_past_iterations(self, key: str, max_history: int = 5) -> str:
        """Format prior responses as ``<PAST_ITERATIONS>`` block.

        Used in the REVOLVE optimizer prompt (Appendix A) to give the
        TGD update access to the full response trajectory.
        """
        hist = self.get_history(key)
        if len(hist) <= 1:
            return ""
        recent = hist[-(max_history + 1) : -1]
        parts = [f"  Iteration {i + 1}: {r[:200]}" for i, r in enumerate(recent)]
        return "<PAST_ITERATIONS>\n" + "\n".join(parts) + "\n</PAST_ITERATIONS>"

    def clear(self) -> None:
        """Reset all stored history."""
        self._history.clear()


# ---------------------------------------------------------------------------
# REVOLVE Optimizer
# ---------------------------------------------------------------------------


class REVOLVE(TextOptimizer):
    r"""
    ## REVOLVE — Second-Order Textual Optimizer

    Extends TGD by augmenting each textual gradient with an **evolution
    signal** derived from comparing the current response to the previous
    response for the same input.

    **Algorithm (per step):**

    1. For each parameter: retrieve gradient text
    2. Look up the most recent evolution signal for this parameter
       (set by calling ``record_response()`` before ``step()``)
    3. Prepend the evolution feedback and past iterations context to the
       gradient text → this is the REVOLVE augmented gradient
    4. Call TGD update with the augmented gradient
    5. Archive gradients

    **Key difference from TGD:**
    REVOLVE detects when optimization is stagnating (high inter-iteration
    response similarity) or unstable (low similarity) and injects an
    adaptive instruction that guides the LLM optimizer accordingly.

    Reference: REVOLVE (Zhang, Jin, Hu et al., 2025) arXiv:2412.03092

    ```python
    optimizer = REVOLVE(params=[p], engine=engine)

    for step in range(5):
        optimizer.zero_grad()
        output = agent(input_state)
        optimizer.record_response(key=input_key, response=output.observation, iteration=step)
        loss.backward(engine)
        optimizer.step()
    ```
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        stagnation_threshold: float = 0.85,
        instability_threshold: float = 0.25,
        max_history: int = 5,
    ) -> None:
        super().__init__(params, engine=engine)
        self.stagnation_threshold = stagnation_threshold
        self.instability_threshold = instability_threshold
        self.max_history = max_history

        # Trajectory tracker: keyed by user-supplied response keys
        self.trajectory = ResponseTrajectory()

        # Per-parameter evolution signals set by record_response()
        # Maps param_name → (delta_type, feedback_text, similarity)
        self._evolution_signals: dict[str, tuple[str, str, float]] = {}
        self._past_contexts: dict[str, str] = {}

        # Iteration counter (used for signal labels)
        self._iteration: int = 0

    def record_response(
        self,
        key: str,
        response: str,
        iteration: int | None = None,
    ) -> tuple[str, str, float] | None:
        """Record a response for a given input key.

        Call this **before** ``step()`` to provide the trajectory context
        needed for the evolution signal.

        Returns the ``(delta_type, feedback_text, similarity)`` triple if
        there was a previous response to compare against, else ``None``.

        Args:
            key: Identifier for this input (e.g. hash or input text).
            response: The model's response at the current iteration.
            iteration: Iteration number for labelling; defaults to
                ``self._iteration``.
        """
        it = iteration if iteration is not None else self._iteration
        prev = self.trajectory.record(key, response, it)
        if prev is None:
            return None

        delta_type, feedback, sim = compute_evolution_feedback(
            response, prev, it, self.stagnation_threshold, self.instability_threshold
        )

        # Store under *key* — will be consumed by propose() for each param
        self._evolution_signals[key] = (delta_type, feedback, sim)
        self._past_contexts[key] = self.trajectory.format_past_iterations(
            key, max_history=self.max_history
        )
        return delta_type, feedback, sim

    def _get_augmented_gradient(self, gradient_text: str) -> str:
        """Augment gradient text with all available evolution signals.

        Merges all per-key signals collected since the last step.
        In batch mode multiple keys may exist; all signals are included.
        """
        parts = [gradient_text]

        # Collect unique evolution feedback texts
        seen: set[str] = set()
        for key, (_, feedback, _) in self._evolution_signals.items():
            if feedback not in seen:
                parts.append(REVOLVE_EVOLUTION_PREFIX.format(signal=feedback).strip())
                seen.add(feedback)

        # Append any past-iterations context
        for key, past_block in self._past_contexts.items():
            if past_block:
                parts.append(
                    REVOLVE_PAST_ITERATIONS_PREFIX.format(
                        past_block=past_block
                    ).strip()
                )
                break  # only one past-block needed (they're the same param)

        return "\n\n".join(parts)

    def propose(self) -> None:
        """Generate improved parameter values, augmented with evolution signals.

        For each parameter that has gradients, augments the gradient text
        with the REVOLVE evolution signal (if available), then calls the
        TGD update prompt.
        """
        assert self.engine is not None

        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Augment gradient with REVOLVE evolution signal
            augmented = self._get_augmented_gradient(gradient_text)

            # Build constraints text
            constraints_text = ""
            if param.constraints:
                constraints_text = (
                    "Constraints to follow:\n"
                    + "\n".join(f"- {c}" for c in param.constraints)
                    + "\n\n"
                )

            prompt = TGD_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=augmented,
                constraints_text=constraints_text,
            )

            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

    def step(self) -> None:
        """Propose updates with REVOLVE augmentation, then archive gradients."""
        self.propose()
        for p in self.params:
            p.archive_gradients()
        # Advance iteration counter; clear consumed signals
        self._iteration += 1
        self._evolution_signals.clear()
        self._past_contexts.clear()

    def zero_grad(self) -> None:
        """Clear gradients on all parameters."""
        for p in self.params:
            p.gradients.clear()

    def state_dict(self) -> dict:
        """Return serializable state for checkpointing."""
        base = super().state_dict()
        base["iteration"] = self._iteration
        base["stagnation_threshold"] = self.stagnation_threshold
        base["instability_threshold"] = self.instability_threshold
        base["max_history"] = self.max_history
        return base


def _extract_improved_variable(response: str) -> str:
    """Extract text between ``<IMPROVED_VARIABLE>`` tags.

    Falls back to the stripped full response if tags are absent.
    """
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
