"""
---
title: TextBFGS — Quasi-Newton Text Optimizer
summary: >
    Quasi-Newton optimizer with a Hessian-Proxy Knowledge Base.
    Retrieves similar past gradients and their successful updates
    to inform the current optimization step.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

TEXT_BFGS_PROMPT = """\
Here is a variable that needs to be improved:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

Here is feedback about how to improve it:

<FEEDBACK>
{gradient_text}
</FEEDBACK>

{history_text}\
Based on the feedback and historical improvements, produce an improved \
version of the variable. Learn from what worked before.

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class TextBFGS(TextOptimizer):
    r"""
    ## TextBFGS — Quasi-Newton Text Optimizer

    Uses a knowledge base of (gradient, old_value, new_value, improvement)
    tuples to approximate second-order information. When a new gradient
    arrives, retrieves similar past gradients and their successful update
    patterns to inform the current update.

    Reference: TextBFGS (Pandey et al., 2025)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_kb_size: int = 50,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_kb_size = max_kb_size
        # Knowledge base: list of {gradient, old, new, improvement}
        self._kb: list[dict[str, Any]] = []

    def record_update(
        self,
        gradient: str,
        old_value: str,
        new_value: str,
        improvement: float,
    ) -> None:
        """Record a successful update for future reference."""
        self._kb.append({
            "gradient": gradient,
            "old": old_value,
            "new": new_value,
            "improvement": improvement,
        })
        # Keep only the best entries
        self._kb.sort(key=lambda x: x["improvement"], reverse=True)
        self._kb = self._kb[: self.max_kb_size]

    def _retrieve_similar(self, gradient_text: str, k: int = 3) -> list[dict[str, Any]]:
        """Retrieve similar past updates using keyword overlap."""
        if not self._kb:
            return []

        gradient_words = set(gradient_text.lower().split())
        scored = []
        for entry in self._kb:
            entry_words = set(entry["gradient"].lower().split())
            overlap = len(gradient_words & entry_words)
            scored.append((overlap, entry))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [entry for _, entry in scored[:k]]

    def propose(self) -> None:
        """Generate improved values using KB-informed updates."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Retrieve similar past improvements
            similar = self._retrieve_similar(gradient_text)
            history_text = ""
            if similar:
                history_lines = []
                for entry in similar:
                    history_lines.append(
                        f"Previous similar feedback: {entry['gradient'][:100]}\n"
                        f"Old value: {entry['old'][:100]}\n"
                        f"New value: {entry['new'][:100]}\n"
                        f"Improvement: {entry['improvement']:.4f}\n"
                    )
                history_text = (
                    "Historical improvements for similar feedback:\n\n"
                    + "\n".join(history_lines)
                    + "\n"
                )

            prompt = TEXT_BFGS_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                history_text=history_text,
            )

            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["kb"] = list(self._kb)
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._kb = state.get("kb", [])


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags."""
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
