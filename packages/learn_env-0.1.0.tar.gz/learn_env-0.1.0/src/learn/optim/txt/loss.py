"""
---
title: Loss Functions — TextLoss, EvalFnToTextLoss
summary: >
    Loss functions for the textual optimization pipeline. TextLoss uses
    an LLM as a judge. EvalFnToTextLoss bridges numeric evaluation
    functions to textual gradients.
---

# Loss Functions

Two primary loss types:

* ``TextLoss`` — LLM-as-judge: evaluates prediction quality via LLM
* ``EvalFnToTextLoss`` — bridges ``fn(pred, target) → float`` to
  textual gradients with optional LLM feedback
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Optional

from learn.env.program.variable import Variable
from learn.optim.txt.autograd.function import BackwardContext
from learn.optim.txt.autograd.llm_call import LLMCall
from learn.optim.txt.autograd.prompts import (
    PASSTHROUGH_GRADIENT_TEMPLATE,
    TEXT_LOSS_PROMPT,
    TEXT_LOSS_SYSTEM_PROMPT,
)

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class TextLoss:
    r"""
    <a id="TextLoss"></a>

    ## TextLoss — LLM-as-Judge

    Uses an LLM to evaluate a prediction, producing a loss Variable
    that can be backpropagated through the computation graph.

    $$\text{loss} = \text{LLM}_{\text{judge}}(\text{prediction},
    \text{eval\_instruction})$$

    ```python
    loss_fn = TextLoss(engine, eval_instruction="Is this answer correct?")
    loss = loss_fn(prediction_variable)
    loss.backward(engine)
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        eval_instruction: str = "Evaluate the quality of this response.",
    ) -> None:
        self.engine = engine
        self.eval_instruction = eval_instruction
        self._llm_call = LLMCall(engine)

    def __call__(self, prediction: Variable) -> Variable:
        """Evaluate the prediction and return a loss Variable."""
        # Build the evaluation prompt
        eval_prompt = Variable(
            data=TEXT_LOSS_PROMPT.format(
                prediction=prediction.data,
                eval_instruction=self.eval_instruction,
            ),
            role_description="loss evaluation prompt",
            requires_grad=False,
        )

        # Use LLMCall to make this differentiable
        # We pass both prediction and eval_prompt so gradients flow back
        loss_var = self._llm_call.forward(
            prediction,
            eval_prompt,
            system_prompt=TEXT_LOSS_SYSTEM_PROMPT,
        )
        loss_var.role_description = "loss"

        return loss_var


class EvalFnToTextLoss:
    r"""
    <a id="EvalFnToTextLoss"></a>

    ## EvalFnToTextLoss — Numeric → Textual Bridge

    Bridges a numeric evaluation function to textual gradients.
    Computes a score, then (optionally) uses an LLM to generate
    feedback as a passthrough gradient.

    ```python
    def exact_match(pred: str, target: str) -> float:
        return 1.0 if pred.strip() == target.strip() else 0.0

    loss_fn = EvalFnToTextLoss(eval_fn=exact_match, engine=engine)
    loss = loss_fn(prediction_variable, target="42")
    loss.backward(engine)
    ```
    """

    def __init__(
        self,
        eval_fn: Callable[[str, str], float],
        engine: Optional[EngineLM] = None,
    ) -> None:
        self.eval_fn = eval_fn
        self.engine = engine

    def __call__(
        self,
        prediction: Variable,
        target: str,
    ) -> Variable:
        """Evaluate prediction against target, return loss Variable."""
        score = self.eval_fn(prediction.data, target)

        loss_text = (
            f"Score: {score:.4f}\n"
            f"Prediction: {prediction.data}\n"
            f"Target: {target}"
        )

        # Create loss Variable with predecessors for backprop
        predecessors = [prediction] if prediction.requires_grad else []
        loss_var = Variable(
            data=loss_text,
            role_description="evaluation loss",
            requires_grad=bool(predecessors),
            predecessors=predecessors,
        )

        # Install a passthrough backward that generates feedback
        if prediction.requires_grad:
            loss_var.grad_fn = BackwardContext(
                self._backward,
                prediction=prediction,
                score=score,
                target=target,
            )

        return loss_var

    def _backward(
        self,
        prediction: Variable,
        score: float,
        target: str,
        backward_engine: EngineLM | None = None,
    ) -> None:
        """Generate a passthrough gradient for the prediction."""
        engine = backward_engine or self.engine

        if score >= 1.0:
            # Perfect score — no gradient needed
            return

        feedback_text = (
            f"The prediction scored {score:.4f} out of 1.0. "
            f"The target was: {target}. "
            f"Please improve the output to better match the target."
        )

        # If we have an engine, ask for more detailed feedback
        if engine is not None:
            detailed = engine.generate(
                f"The prediction was: {prediction.data}\n"
                f"The target was: {target}\n"
                f"The score was: {score:.4f}\n"
                f"Provide specific feedback on how to improve.",
                system_prompt="You are an evaluation assistant.",
            )
            feedback_text = detailed

        gradient = Variable(
            data=PASSTHROUGH_GRADIENT_TEMPLATE.format(
                role=prediction.role_description,
                gradient_text=feedback_text,
            ),
            role_description=f"gradient for {prediction.role_description}",
            requires_grad=False,
        )
        prediction.gradients.append(gradient)
