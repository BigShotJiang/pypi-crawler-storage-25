"""
---
title: GEPA — Reflective Pareto-Based Evolutionary Prompt Search
summary: >
    Combines evolutionary search with reflection-based improvement,
    maintaining a Pareto frontier of solutions.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

GEPA_PROMPT = """\
Here is a variable that needs to be improved:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<FEEDBACK>
{gradient_text}
</FEEDBACK>

{frontier_text}\
Produce a new version that aims to be on the Pareto frontier — \
improving on as many dimensions as possible without degrading others.

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class GEPA(TextOptimizer):
    r"""
    ## GEPA — Reflective Pareto-Based Evolutionary Prompt Search

    Combines evolutionary search with reflection-based improvement,
    maintaining a Pareto frontier of solutions across multiple
    evaluation criteria.

    Reference: GEPA (2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_frontier_size: int = 10,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_frontier_size = max_frontier_size
        # Pareto frontier: list of (value, scores_dict)
        self._frontier: list[tuple[str, dict[str, float]]] = []

    def record(self, value: str, scores: dict[str, float]) -> None:
        """Record a solution with multi-dimensional scores."""
        self._frontier.append((value, scores))
        self._frontier = self._prune_to_pareto(self._frontier)

    def _prune_to_pareto(
        self,
        frontier: list[tuple[str, dict[str, float]]],
    ) -> list[tuple[str, dict[str, float]]]:
        """Keep only Pareto-optimal solutions."""
        if not frontier:
            return []

        result = []
        for i, (val_i, scores_i) in enumerate(frontier):
            dominated = False
            for j, (val_j, scores_j) in enumerate(frontier):
                if i == j:
                    continue
                # j dominates i if j >= i on all dims and > i on at least one
                if all(
                    scores_j.get(k, 0) >= scores_i.get(k, 0) for k in scores_i
                ) and any(
                    scores_j.get(k, 0) > scores_i.get(k, 0) for k in scores_i
                ):
                    dominated = True
                    break
            if not dominated:
                result.append((val_i, scores_i))

        # Limit size
        return result[: self.max_frontier_size]

    def propose(self) -> None:
        """Generate improved values considering Pareto frontier."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Build frontier text
            frontier_text = ""
            if self._frontier:
                frontier_lines = []
                for val, scores in self._frontier[:5]:
                    score_str = ", ".join(
                        f"{k}={v:.3f}" for k, v in scores.items()
                    )
                    frontier_lines.append(
                        f"Solution: {val[:80]}...\nScores: {score_str}\n"
                    )
                frontier_text = (
                    "Current Pareto frontier:\n\n"
                    + "\n".join(frontier_lines)
                    + "\n"
                )

            prompt = GEPA_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                frontier_text=frontier_text,
            )
            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["frontier"] = list(self._frontier)
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._frontier = state.get("frontier", [])


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
