"""
---
title: GradientAggregator — Batch Gradient Accumulation
summary: >
    Aggregates multiple textual gradients for the same parameter into a
    single coherent gradient signal.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from learn.env.program.variable import Variable

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM

SUMMARIZE_PROMPT = """\
Here are multiple pieces of feedback about a variable with role "{role}":

{gradient_texts}

Summarize these into a single, coherent piece of feedback. Preserve \
the most important and actionable suggestions. Remove redundancy."""


class GradientAggregator:
    r"""
    ## GradientAggregator — Batch Gradient Accumulation

    When multiple samples produce gradients for the same parameter,
    this aggregates them into a single gradient signal.

    Strategies:
    * ``concat`` — concatenate all gradients
    * ``summarize`` — use LLM to summarize all gradients
    * ``weighted`` — weight gradients by importance scores
    * ``error_only`` — keep only gradients from failing examples
    """

    def __init__(
        self,
        strategy: str = "concat",
        engine: Optional[EngineLM] = None,
    ) -> None:
        if strategy not in ("concat", "summarize", "weighted", "error_only"):
            raise ValueError(f"Unknown strategy: {strategy}")
        self.strategy = strategy
        self.engine = engine

    def aggregate(
        self,
        gradients: list[Variable],
        role: str = "",
        scores: list[float] | None = None,
    ) -> Variable:
        """Aggregate multiple gradients into one."""
        if not gradients:
            return Variable(data="", role_description="empty gradient")

        if len(gradients) == 1:
            return gradients[0]

        if self.strategy == "concat":
            return self._concat(gradients, role)
        elif self.strategy == "summarize":
            return self._summarize(gradients, role)
        elif self.strategy == "weighted":
            return self._weighted(gradients, role, scores)
        elif self.strategy == "error_only":
            return self._error_only(gradients, role, scores)
        else:
            return self._concat(gradients, role)

    def _concat(self, gradients: list[Variable], role: str) -> Variable:
        """Concatenate all gradient texts."""
        combined = "\n\n---\n\n".join(g.data for g in gradients)
        return Variable(
            data=combined,
            role_description=f"aggregated gradient for {role}",
        )

    def _summarize(self, gradients: list[Variable], role: str) -> Variable:
        """Use LLM to summarize gradients."""
        if self.engine is None:
            return self._concat(gradients, role)

        texts = "\n\n".join(
            f"Feedback {i + 1}:\n{g.data}" for i, g in enumerate(gradients)
        )
        prompt = SUMMARIZE_PROMPT.format(role=role, gradient_texts=texts)
        result = self.engine.generate(prompt)
        return Variable(
            data=result,
            role_description=f"summarized gradient for {role}",
        )

    def _weighted(
        self,
        gradients: list[Variable],
        role: str,
        scores: list[float] | None,
    ) -> Variable:
        """Weight gradients by importance (lower score = higher weight)."""
        if scores is None or len(scores) != len(gradients):
            return self._concat(gradients, role)

        # Lower score = more important (needs more fixing)
        weighted_parts = []
        for grad, score in sorted(zip(gradients, scores), key=lambda x: x[1]):
            weight = 1.0 - score
            if weight > 0.1:
                weighted_parts.append(
                    f"[importance={weight:.2f}] {grad.data}"
                )

        if not weighted_parts:
            return self._concat(gradients, role)

        combined = "\n\n".join(weighted_parts)
        return Variable(
            data=combined,
            role_description=f"weighted gradient for {role}",
        )

    def _error_only(
        self,
        gradients: list[Variable],
        role: str,
        scores: list[float] | None,
    ) -> Variable:
        """Keep only gradients from failing examples."""
        if scores is None or len(scores) != len(gradients):
            return self._concat(gradients, role)

        error_grads = [g for g, s in zip(gradients, scores) if s < 1.0]
        if not error_grads:
            return Variable(data="No errors detected.", role_description=role)
        return self._concat(error_grads, role)
