"""
---
title: TEP — Textual Equilibrium Propagation
summary: >
    Local optimization replacing global backpropagation.
    Each node optimizes locally using energy-based equilibrium.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

TEP_PROMPT = """\
Here is a variable that should be locally optimized:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<LOCAL_FEEDBACK>
{gradient_text}
</LOCAL_FEEDBACK>

Optimize this variable based ONLY on the local feedback above. \
Do not consider the global pipeline — just make this variable \
as good as possible based on the local signals.

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class TEP(TextOptimizer):
    r"""
    ## TEP — Textual Equilibrium Propagation

    Local optimization replacing global backpropagation.
    Each node optimizes locally using local feedback signals,
    avoiding the need for end-to-end gradient chains.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        num_local_steps: int = 1,
    ) -> None:
        super().__init__(params, engine=engine)
        self.num_local_steps = num_local_steps

    def propose(self) -> None:
        """Locally optimize each parameter."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            for _ in range(self.num_local_steps):
                prompt = TEP_PROMPT.format(
                    role=param.role_description,
                    current_value=param.data,
                    gradient_text=gradient_text,
                )
                response = self.engine.generate(
                    prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
                )
                improved = _extract_improved_variable(response)
                param.update(improved)


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
