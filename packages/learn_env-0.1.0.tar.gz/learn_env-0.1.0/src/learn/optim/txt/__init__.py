"""
---
title: learn.optim.txt — Text-Gradient Optimizers
summary: >
    Optimizers that use textual gradients (LLM-generated feedback)
    to update text parameters.
---
"""
from learn.optim.txt.aggregator import GradientAggregator
from learn.optim.txt.base import TextOptimizer
from learn.optim.txt.etgpo import ETGPO
from learn.optim.txt.eval_to_loss import EvalToLoss
from learn.optim.txt.feedback import FeedbackDescent
from learn.optim.txt.gdpo import GDPO
from learn.optim.txt.gepa import GEPA
from learn.optim.txt.loss import EvalFnToTextLoss, TextLoss
from learn.optim.txt.remo import REMO
from learn.optim.txt.revolve import REVOLVE, ResponseTrajectory, response_similarity
from learn.optim.txt.semantic_backprop import (
    SemanticBackpropagation,
    compute_naive_gradients,
    compute_neighborhood_gradients,
)
from learn.optim.txt.text_bfgs import TextBFGS
from learn.optim.txt.text_resnet import TextResNet
from learn.optim.txt.tep import TEP
from learn.optim.txt.tgd import TGD
from learn.optim.txt.tsgd_m import TSGD_M
from learn.optim.txt.validation import (
    ScoreGatedStorage,
    TwoStageValidation,
    ValidationRevert,
)

__all__ = [
    "ETGPO",
    "EvalFnToTextLoss",
    "EvalToLoss",
    "FeedbackDescent",
    "GDPO",
    "GEPA",
    "GradientAggregator",
    "REMO",
    "REVOLVE",
    "ResponseTrajectory",
    "ScoreGatedStorage",
    "SemanticBackpropagation",
    "TEP",
    "TGD",
    "TSGD_M",
    "TextBFGS",
    "TextLoss",
    "TextOptimizer",
    "TextResNet",
    "TwoStageValidation",
    "ValidationRevert",
    "compute_naive_gradients",
    "compute_neighborhood_gradients",
    "response_similarity",
]