"""
---
title: Graph Utilities — DAG Inspection
summary: >
    Utility functions for inspecting the textual computation graph:
    topological sort, cycle detection, and graph building.
---
"""
from __future__ import annotations

from learn.env.program.variable import Variable


def topological_sort(root: Variable) -> list[Variable]:
    """Return a topological ordering of the computation graph.

    Nodes with no predecessors appear first; the root appears last.
    """
    visited: set[int] = set()
    order: list[Variable] = []

    def _visit(node: Variable) -> None:
        node_id = id(node)
        if node_id in visited:
            return
        visited.add(node_id)
        for pred in node.predecessors:
            _visit(pred)
        order.append(node)

    _visit(root)
    return order


def has_cycle(root: Variable) -> bool:
    """Check if the computation graph rooted at *root* has a cycle."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[int, int] = {}

    def _dfs(node: Variable) -> bool:
        nid = id(node)
        color[nid] = GRAY
        for pred in node.predecessors:
            pid = id(pred)
            c = color.get(pid, WHITE)
            if c == GRAY:
                return True
            if c == WHITE and _dfs(pred):
                return True
        color[nid] = BLACK
        return False

    return _dfs(root)
