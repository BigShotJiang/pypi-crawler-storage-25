"""
---
title: Backward Pass — Textual Autograd
summary: >
    Implements the reverse-mode textual gradient computation.
    The textual analog of ``torch.autograd.backward()``.
---

# Backward Pass

The backward pass mirrors PyTorch's autograd:

1. Topologically sort the computation graph
2. Traverse in reverse order (from loss toward leaves)
3. At each node, if multiple gradients exist, reduce them
4. Call ``grad_fn(backward_engine=engine)`` to propagate
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.optim.txt.autograd.graph import topological_sort
from learn.optim.txt.autograd.prompts import (
    REDUCE_MEAN_PROMPT,
    REDUCE_MEAN_SYSTEM_PROMPT,
)

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Variable


def backward(root: Variable, engine: EngineLM) -> None:
    r"""Perform reverse topological traversal from *root*, calling grad_fn.

    This is the textual analog of ``loss.backward()`` in PyTorch.

    $$\text{For each node } v \text{ in reverse topo order:}$$
    $$\quad v.\text{grad\_fn}(\text{backward\_engine}=\text{engine})$$

    Args:
        root: The loss variable (starting point of backward pass).
        engine: The LLM engine used for gradient generation.
    """
    topo_order = topological_sort(root)

    for node in reversed(topo_order):
        # If multiple gradients, reduce them to a single summary
        if len(node.gradients) > 1:
            _reduce_gradients(node, engine)

        # Propagate gradients through the backward function
        if node.grad_fn is not None:
            node.grad_fn(backward_engine=engine)


def _reduce_gradients(node: Variable, engine: EngineLM) -> None:
    """Reduce multiple gradients to a single summary via LLM.

    When a variable receives gradients from multiple downstream nodes,
    they are summarized into a coherent single gradient.
    """
    from learn.env.program.variable import Variable as Var

    gradient_texts = "\n\n---\n\n".join(
        f"Feedback {i+1}: {g.data}" for i, g in enumerate(node.gradients)
    )

    prompt = REDUCE_MEAN_PROMPT.format(
        role=node.role_description,
        gradient_texts=gradient_texts,
    )

    reduced_text = engine.generate(prompt, system_prompt=REDUCE_MEAN_SYSTEM_PROMPT)

    reduced_gradient = Var(
        data=reduced_text,
        role_description=f"reduced gradient for {node.role_description}",
        requires_grad=False,
    )

    node.gradients = [reduced_gradient]
