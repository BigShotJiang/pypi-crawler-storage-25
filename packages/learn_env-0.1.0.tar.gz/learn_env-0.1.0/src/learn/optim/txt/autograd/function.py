"""
---
title: Function & BackwardContext — Autograd Primitives
summary: >
    ``Function`` is the textual analog of ``torch.autograd.Function``.
    ``BackwardContext`` captures the backward closure + arguments.
---

# Autograd Function

Every differentiable operation (LLM call, loss eval, text transform)
subclasses ``Function`` and implements ``forward`` + ``backward``.

| ``torch.autograd.Function`` | ``Function`` |
|-----------------------------|-------------|
| ``forward(ctx, *args)`` | ``forward(*args) → Variable`` |
| ``backward(ctx, grad)`` | ``backward(**kwargs) → None`` |
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable

from learn.env.program.variable import Variable


class BackwardContext:
    """Captures a backward function with its bound arguments.

    Stored as ``Variable.grad_fn`` and called during the backward pass.
    """

    def __init__(self, backward_fn: Callable[..., None], **kwargs: Any) -> None:
        self.backward_fn = backward_fn
        self.kwargs = kwargs

    def __call__(self, **extra_kwargs: Any) -> None:
        merged = {**self.kwargs, **extra_kwargs}
        self.backward_fn(**merged)


class Function(ABC):
    r"""
    <a id="Function"></a>

    ## Function

    Abstract base for differentiable operations in the textual autograd
    graph. Each subclass defines ``forward`` (builds the graph) and
    ``backward`` (propagates textual gradients).
    """

    @abstractmethod
    def forward(self, *args: Any, **kwargs: Any) -> Variable:
        """Execute the forward operation and return an output Variable."""
        ...

    @abstractmethod
    def backward(self, *args: Any, **kwargs: Any) -> None:
        """Compute textual gradients for predecessor Variables."""
        ...

    def __call__(self, *args: Any, **kwargs: Any) -> Variable:
        """Convenience: delegates to ``forward``."""
        return self.forward(*args, **kwargs)
