"""
---
title: LLMCall — Differentiable LLM Operation
summary: >
    Wraps an LLM engine call as a differentiable ``Function`` in the
    textual autograd graph. The core primitive connecting forward and
    backward passes through LLM inference.
---

# LLMCall

The fundamental differentiable primitive. Every time an LLM is called
during the forward pass, it goes through ``LLMCall``, which:

1. Calls ``engine.generate()`` to produce text
2. Creates an output ``Variable`` connected to input predecessors
3. Installs a ``BackwardContext`` that computes textual gradients
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.env.program.variable import Variable
from learn.optim.txt.autograd.function import BackwardContext, Function
from learn.optim.txt.autograd.prompts import (
    BACKWARD_SYSTEM_PROMPT,
    BASE_BACKWARD_PROMPT,
    CHAIN_BACKWARD_PROMPT,
    NEIGHBORHOOD_BACKWARD_PROMPT,
    NEIGHBORHOOD_BASE_BACKWARD_PROMPT,
)

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class LLMCall(Function):
    r"""
    <a id="LLMCall"></a>

    ## LLMCall

    Differentiable LLM call. Wraps ``engine.generate()`` and installs
    backward hooks for textual gradient computation.

    ### Forward

    ```
    output = LLMCall(engine)(input_variable, system_prompt=...)
    ```

    ### Backward

    For each predecessor variable with ``requires_grad=True``, generates
    a textual gradient using the backward engine:

    $$\text{grad}(x_i) = \text{LLM}_{\text{bwd}}\bigl(
      \text{prompt}(x_i, \text{output}, \text{upstream\_grad})\bigr)$$
    """

    def __init__(self, engine: EngineLM, neighborhood_aware: bool = False) -> None:
        self.engine = engine
        self.neighborhood_aware = neighborhood_aware

    def forward(
        self,
        *inputs: Variable,
        system_prompt: str | None = None,
    ) -> Variable:
        """Call the engine and wire the output into the computation graph.

        Args:
            *inputs: Input Variables whose ``.data`` is concatenated.
            system_prompt: Optional system prompt for the engine.

        Returns:
            A new Variable containing the engine's response.
        """
        # Build the prompt from inputs
        prompt = "\n\n".join(v.data for v in inputs if v.data)

        # Forward pass: call the engine
        response = self.engine.generate(prompt, system_prompt=system_prompt)

        # Determine predecessors (only those needing gradients)
        predecessors = [v for v in inputs if v.requires_grad]

        # Create output Variable wired into the graph
        output = Variable(
            data=response,
            role_description="LLM response",
            requires_grad=bool(predecessors),
            predecessors=predecessors,
        )

        # Install backward context
        output.grad_fn = BackwardContext(
            self.backward,
            inputs=list(inputs),
            output=output,
        )

        return output

    def backward(
        self,
        inputs: list[Variable],
        output: Variable,
        backward_engine: EngineLM | None = None,
    ) -> None:
        """Compute textual gradients for each predecessor.

        When ``neighborhood_aware=True``, includes sibling input context
        in the backward prompt. This implements the Jacobian conditioning
        from semantic backpropagation: $J_{h_w^v}$ fixes all predecessors
        except the one being differentiated.

        Args:
            inputs: The input Variables from forward pass.
            output: The output Variable from forward pass.
            backward_engine: The engine to use for gradient generation.
                Falls back to ``self.engine`` if not provided.
        """
        engine = backward_engine or self.engine

        for inp in inputs:
            if not inp.requires_grad:
                continue

            # Build sibling context for neighborhood-aware mode
            sibling_context = ""
            if self.neighborhood_aware and len(inputs) > 1:
                siblings = [
                    f"<SIBLING role=\"{v.role_description}\">\n"
                    f"{v.data}\n</SIBLING>"
                    for v in inputs
                    if v is not inp
                ]
                sibling_context = "\n\n".join(siblings)

            # Choose prompt based on mode
            if self.neighborhood_aware and sibling_context:
                if output.gradients:
                    upstream = output.get_gradient_text()
                    prompt = NEIGHBORHOOD_BACKWARD_PROMPT.format(
                        role=inp.role_description,
                        variable_value=inp.data,
                        sibling_context=sibling_context,
                        output_value=output.data,
                        upstream_gradient=upstream,
                    )
                else:
                    prompt = NEIGHBORHOOD_BASE_BACKWARD_PROMPT.format(
                        role=inp.role_description,
                        variable_value=inp.data,
                        sibling_context=sibling_context,
                        output_value=output.data,
                        loss_value=output.data,
                    )
            elif output.gradients:
                # Chain mode: use upstream gradient
                upstream = output.get_gradient_text()
                prompt = CHAIN_BACKWARD_PROMPT.format(
                    role=inp.role_description,
                    variable_value=inp.data,
                    output_value=output.data,
                    upstream_gradient=upstream,
                )
            else:
                # Base mode: at the loss boundary
                prompt = BASE_BACKWARD_PROMPT.format(
                    role=inp.role_description,
                    variable_value=inp.data,
                    output_value=output.data,
                    loss_value=output.data,
                )

            # Generate the textual gradient
            gradient_text = engine.generate(
                prompt, system_prompt=BACKWARD_SYSTEM_PROMPT
            )

            # Create gradient Variable and attach to predecessor
            gradient = Variable(
                data=gradient_text,
                role_description=f"gradient for {inp.role_description}",
                requires_grad=False,
            )
            inp.gradients.append(gradient)
            inp.gradients_context[gradient] = output.data
