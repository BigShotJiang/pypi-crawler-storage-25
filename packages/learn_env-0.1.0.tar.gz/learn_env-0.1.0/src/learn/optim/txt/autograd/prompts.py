"""
---
title: Autograd Prompt Templates
summary: >
    Prompt templates used by the textual autograd system. These prompts
    instruct the backward engine on how to generate textual gradients.
---
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# Backward system prompt (the "meta-instruction" for generating gradients)
# ---------------------------------------------------------------------------

BACKWARD_SYSTEM_PROMPT = """\
You are an expert prompt engineer analyzing the quality of LLM outputs.
Your task is to provide feedback on how to improve a specific variable
(a piece of text) to produce a better outcome.

Be specific, actionable, and concise in your feedback.
Focus on the variable you are asked to improve — do not suggest changes
to other parts of the pipeline."""

# ---------------------------------------------------------------------------
# Base mode — gradient at the loss boundary
# ---------------------------------------------------------------------------

BASE_BACKWARD_PROMPT = """\
Here is a conversation where a variable was used to produce an output,
and then evaluated:

<VARIABLE role="{role}">
{variable_value}
</VARIABLE>

<OUTPUT>
{output_value}
</OUTPUT>

<EVALUATION>
{loss_value}
</EVALUATION>

Provide specific, actionable feedback on how the variable (with role: \
"{role}") should be changed to improve the output and the evaluation. \
Focus only on the variable — do not suggest changes to the evaluation \
criteria."""

# ---------------------------------------------------------------------------
# Chain mode — interior node with upstream gradient
# ---------------------------------------------------------------------------

CHAIN_BACKWARD_PROMPT = """\
Here is a conversation where a variable was used, and an upstream \
gradient (feedback) has been provided about the output:

<VARIABLE role="{role}">
{variable_value}
</VARIABLE>

<OUTPUT>
{output_value}
</OUTPUT>

<UPSTREAM_GRADIENT>
{upstream_gradient}
</UPSTREAM_GRADIENT>

Based on the upstream gradient, provide specific, actionable feedback \
on how the variable (with role: "{role}") should be changed. Focus \
only on the variable."""

# ---------------------------------------------------------------------------
# Neighborhood-aware mode — includes sibling input context
# ---------------------------------------------------------------------------

NEIGHBORHOOD_BACKWARD_PROMPT = """\
Here is a conversation where multiple variables were used together to \
produce an output, and an upstream gradient (feedback) has been provided:

<TARGET_VARIABLE role="{role}">
{variable_value}
</TARGET_VARIABLE>

<SIBLING_CONTEXT>
{sibling_context}
</SIBLING_CONTEXT>

<OUTPUT>
{output_value}
</OUTPUT>

<UPSTREAM_GRADIENT>
{upstream_gradient}
</UPSTREAM_GRADIENT>

Based on the upstream gradient, provide specific, actionable feedback \
on how the TARGET variable (with role: "{role}") should be changed \
to improve the output. Consider how it interacts with the sibling \
variables shown above, but focus your feedback only on the target."""

NEIGHBORHOOD_BASE_BACKWARD_PROMPT = """\
Here is a conversation where multiple variables were used together to \
produce an output and evaluation:

<TARGET_VARIABLE role="{role}">
{variable_value}
</TARGET_VARIABLE>

<SIBLING_CONTEXT>
{sibling_context}
</SIBLING_CONTEXT>

<OUTPUT>
{output_value}
</OUTPUT>

<EVALUATION>
{loss_value}
</EVALUATION>

Provide specific, actionable feedback on how the TARGET variable \
(with role: "{role}") should be changed to improve the output \
and evaluation. Consider the sibling context, but focus your \
feedback only on the target variable."""

# ---------------------------------------------------------------------------
# Gradient reduction (when multiple gradients exist)
# ---------------------------------------------------------------------------

REDUCE_MEAN_SYSTEM_PROMPT = """\
You are summarizing multiple pieces of feedback about a variable."""

REDUCE_MEAN_PROMPT = """\
Here are multiple feedback items about a variable with role "{role}":

{gradient_texts}

Summarize these into a single, coherent piece of feedback. Preserve \
the most important and actionable suggestions. Remove redundancy."""

# ---------------------------------------------------------------------------
# TGD optimizer prompts
# ---------------------------------------------------------------------------

OPTIMIZER_SYSTEM_PROMPT = """\
You are an expert prompt optimizer. Your task is to improve a variable \
(a piece of text) based on feedback (gradients). You will be given the \
current value and feedback, and you must produce an improved version."""

TGD_PROMPT = """\
Here is a variable that needs to be improved:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

{constraints_text}\
Here is feedback about how to improve it:

<FEEDBACK>
{gradient_text}
</FEEDBACK>

Based on the feedback, produce an improved version of the variable. \
Output ONLY the improved text between the tags below:

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""

# ---------------------------------------------------------------------------
# Passthrough gradient (for nodes that don't transform the gradient)
# ---------------------------------------------------------------------------

PASSTHROUGH_GRADIENT_TEMPLATE = """\
Here is feedback about the output, which applies to the variable \
"{role}":

{gradient_text}"""

# ---------------------------------------------------------------------------
# Loss evaluation prompts
# ---------------------------------------------------------------------------

TEXT_LOSS_SYSTEM_PROMPT = """\
You are an evaluator. Given a prediction and evaluation criteria, \
provide a detailed assessment of the prediction quality."""

TEXT_LOSS_PROMPT = """\
<PREDICTION>
{prediction}
</PREDICTION>

<EVALUATION_CRITERIA>
{eval_instruction}
</EVALUATION_CRITERIA>

Evaluate the prediction according to the criteria above. Be specific."""
