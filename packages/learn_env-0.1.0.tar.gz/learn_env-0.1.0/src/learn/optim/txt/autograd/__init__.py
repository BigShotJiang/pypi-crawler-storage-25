"""
---
title: learn.optim.txt.autograd — Textual Autograd Engine
summary: >
    Reverse-mode automatic differentiation for text — the textual analog
    of ``torch.autograd``. Provides Function, LLMCall, backward, and
    graph utilities.
---
"""
from learn.optim.txt.autograd.backward import backward
from learn.optim.txt.autograd.function import BackwardContext, Function
from learn.optim.txt.autograd.graph import has_cycle, topological_sort
from learn.optim.txt.autograd.llm_call import LLMCall

__all__ = [
    "BackwardContext",
    "Function",
    "LLMCall",
    "backward",
    "has_cycle",
    "topological_sort",
]