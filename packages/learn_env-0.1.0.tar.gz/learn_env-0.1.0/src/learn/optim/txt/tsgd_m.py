"""
---
title: TSGD-M — Stochastic TGD with Momentum
summary: >
    Minibatch stochastic TGD with gradient momentum. Samples minibatches,
    computes gradients on each, and selects the best among accumulated
    gradients for the update.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT, TGD_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class TSGD_M(TextOptimizer):
    r"""
    ## TSGD-M — Stochastic TGD with Momentum

    Extends TGD with:
    * Minibatch gradient sampling
    * Momentum buffer that keeps top-k gradients across iterations

    Reference: TSGD-M (Nie et al., 2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        momentum_size: int = 3,
        num_candidates: int = 3,
    ) -> None:
        super().__init__(params, engine=engine)
        self.momentum_size = momentum_size
        self.num_candidates = num_candidates
        # Momentum buffer: keeps top gradients across iterations
        self._momentum: dict[str, list[str]] = {}

    def propose(self) -> None:
        """Generate multiple candidates using momentum and select the best."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Add to momentum buffer
            param_key = param.name
            if param_key not in self._momentum:
                self._momentum[param_key] = []
            self._momentum[param_key].append(gradient_text)
            # Trim momentum buffer
            self._momentum[param_key] = self._momentum[param_key][
                -self.momentum_size :
            ]

            # Combine current + momentum gradients
            combined_gradient = "\n\n".join(self._momentum[param_key])

            # Generate multiple candidates
            candidates = []
            for _ in range(self.num_candidates):
                constraints_text = ""
                if param.constraints:
                    constraints_text = (
                        "Constraints to follow:\n"
                        + "\n".join(f"- {c}" for c in param.constraints)
                        + "\n\n"
                    )

                prompt = TGD_PROMPT.format(
                    role=param.role_description,
                    current_value=param.data,
                    gradient_text=combined_gradient,
                    constraints_text=constraints_text,
                )
                response = self.engine.generate(
                    prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
                )
                candidates.append(_extract_improved_variable(response))

            # Select the first candidate (in practice, would evaluate)
            if candidates:
                param.update(candidates[0])

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["momentum"] = dict(self._momentum)
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._momentum = state.get("momentum", {})


def _extract_improved_variable(response: str) -> str:
    """Extract text between <IMPROVED_VARIABLE> tags."""
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
