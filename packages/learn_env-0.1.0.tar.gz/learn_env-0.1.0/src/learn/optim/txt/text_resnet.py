"""
---
title: TextResNet — Additive Semantic Deltas
summary: >
    Instead of replacing the entire prompt, generates a small semantic
    delta that is appended to the existing prompt.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

TEXT_RESNET_PROMPT = """\
Here is a variable that needs a small improvement:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<FEEDBACK>
{gradient_text}
</FEEDBACK>

Instead of rewriting the entire variable, generate a SMALL additive \
clarification or refinement that should be APPENDED to the existing \
text. This delta should address the feedback without changing what \
already works.

<DELTA>
[Your small additive refinement here]
</DELTA>"""


class TextResNet(TextOptimizer):
    r"""
    ## TextResNet — Additive Semantic Deltas

    Instead of replacing the entire prompt, generates a small semantic
    delta that is added to the existing prompt. Stabilizes deep
    optimization chains.

    $$x_{t+1} = x_t + \Delta_t$$
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_deltas: int = 5,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_deltas = max_deltas
        self._delta_count: dict[str, int] = {}

    def propose(self) -> None:
        """Generate semantic delta and append to current value."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Check delta count
            key = param.name
            count = self._delta_count.get(key, 0)
            if count >= self.max_deltas:
                continue

            prompt = TEXT_RESNET_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
            )
            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            delta = _extract_delta(response)

            # Append delta to current value
            new_value = param.data + "\n" + delta
            param.update(new_value)
            self._delta_count[key] = count + 1


def _extract_delta(response: str) -> str:
    """Extract text between <DELTA> tags."""
    match = re.search(
        r"<DELTA>\s*(.*?)\s*</DELTA>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
