"""
---
title: GDPO — Graph-Aware Gradient Propagation
summary: >
    Peer-aware graph gradient propagation for multi-component pipelines.
    Propagates gradients through a DAG of components, considering peer
    gradients from sibling nodes.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

GDPO_PROMPT = """\
Here is a variable in a multi-component pipeline:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<OWN_FEEDBACK>
{gradient_text}
</OWN_FEEDBACK>

{peer_text}\
Consider both your own feedback and the feedback from peer components. \
Produce an improved version that works well in the overall pipeline.

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class GDPO(TextOptimizer):
    r"""
    ## GDPO — Graph-Aware Gradient Propagation

    Extends TGD by incorporating peer gradients from sibling nodes
    in a DAG. Each parameter receives its own gradient plus
    context from peer parameters at the same pipeline level.

    Reference: LLM-AutoDiff/GDPO (2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        peer_groups: dict[str, list[str]] | None = None,
    ) -> None:
        super().__init__(params, engine=engine)
        # Map param name → list of peer param names
        self.peer_groups = peer_groups or {}
        self._param_by_name: dict[str, Parameter] = {p.name: p for p in params}

    def propose(self) -> None:
        """Generate improved values considering peer gradients."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Collect peer gradients
            peer_text = ""
            peers = self.peer_groups.get(param.name, [])
            if peers:
                peer_lines = []
                for peer_name in peers:
                    peer = self._param_by_name.get(peer_name)
                    if peer:
                        peer_grad = peer.get_gradient_text()
                        if peer_grad:
                            peer_lines.append(
                                f"Peer '{peer_name}' feedback: {peer_grad[:200]}"
                            )
                if peer_lines:
                    peer_text = (
                        "Feedback from peer components:\n\n"
                        + "\n".join(peer_lines)
                        + "\n\n"
                    )

            prompt = GDPO_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                peer_text=peer_text,
            )
            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
