"""
---
title: Validation & Revert Semantics
summary: >
    Validation strategies for accepting or reverting optimizer updates.
    ValidationRevert, TwoStageValidation, ScoreGatedStorage.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from learn.env.program.variable import Parameter


class ValidationRevert:
    r"""
    ## ValidationRevert — Try, Validate, Accept/Revert

    1. Checkpoint current parameter values
    2. Apply proposed update
    3. Evaluate on validation set
    4. If improved: commit. If degraded: revert.

    ```python
    vr = ValidationRevert(eval_fn=my_eval)
    improved = vr.validate_update(param, new_value="better prompt")
    ```
    """

    def __init__(
        self,
        eval_fn: Callable[..., float],
    ) -> None:
        self.eval_fn = eval_fn
        self._history: list[dict[str, Any]] = []

    def validate_update(
        self,
        param: Parameter,
        new_value: str,
        eval_args: tuple[Any, ...] = (),
        eval_kwargs: dict[str, Any] | None = None,
    ) -> bool:
        """Apply update, evaluate, accept or revert.

        Returns True if the update was accepted.
        """
        if eval_kwargs is None:
            eval_kwargs = {}

        # Score before
        old_value = param.data
        old_score = self.eval_fn(*eval_args, **eval_kwargs)

        # Apply update
        param.propose(new_value)
        new_score = self.eval_fn(*eval_args, **eval_kwargs)

        if new_score >= old_score:
            param.commit()
            self._history.append({
                "old_value": old_value,
                "new_value": new_value,
                "old_score": old_score,
                "new_score": new_score,
                "accepted": True,
            })
            return True
        else:
            param.rollback()
            self._history.append({
                "old_value": old_value,
                "new_value": new_value,
                "old_score": old_score,
                "new_score": new_score,
                "accepted": False,
            })
            return False

    @property
    def history(self) -> list[dict[str, Any]]:
        """Return validation history."""
        return list(self._history)


class TwoStageValidation:
    r"""
    ## TwoStageValidation — Fast Pre-Check + Full Validation

    Stage 1: Quick check on small batch (fast reject bad updates)
    Stage 2: Full validation if Stage 1 passes
    """

    def __init__(
        self,
        quick_eval_fn: Callable[..., float],
        full_eval_fn: Callable[..., float],
        quick_threshold: float = 0.0,
    ) -> None:
        self.quick_eval_fn = quick_eval_fn
        self.full_eval_fn = full_eval_fn
        self.quick_threshold = quick_threshold

    def validate_update(
        self,
        param: Parameter,
        new_value: str,
        quick_args: tuple[Any, ...] = (),
        full_args: tuple[Any, ...] = (),
    ) -> bool:
        """Two-stage validation: quick check then full evaluation."""
        old_value = param.data

        # Stage 1: Quick check
        param.propose(new_value)
        quick_score = self.quick_eval_fn(*quick_args)

        if quick_score < self.quick_threshold:
            param.rollback()
            return False

        # Stage 2: Full validation
        old_data_backup = old_value
        full_new_score = self.full_eval_fn(*full_args)

        param.rollback()
        param.propose(old_data_backup)
        # Evaluate old
        full_old_score = self.full_eval_fn(*full_args)
        param.rollback()

        if full_new_score >= full_old_score:
            param.update(new_value)
            return True
        return False


class ScoreGatedStorage:
    r"""
    ## ScoreGatedStorage — Store Only if Score Improves

    Only stores optimization trajectory entries when score improves.
    Prevents polluting trajectory memory with failed attempts.
    """

    def __init__(self, min_improvement: float = 0.0) -> None:
        self.min_improvement = min_improvement
        self._best_score: float = float("-inf")
        self._stored: list[dict[str, Any]] = []

    def should_store(self, score: float) -> bool:
        """Check if this score warrants storage."""
        return score > self._best_score + self.min_improvement

    def store(self, entry: dict[str, Any], score: float) -> bool:
        """Store entry if score improves. Returns True if stored."""
        if self.should_store(score):
            self._best_score = score
            entry["score"] = score
            self._stored.append(entry)
            return True
        return False

    @property
    def entries(self) -> list[dict[str, Any]]:
        """Return all stored entries."""
        return list(self._stored)

    @property
    def best_score(self) -> float:
        """Return the best score seen so far."""
        return self._best_score
