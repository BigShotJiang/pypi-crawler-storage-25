"""
---
title: TextOptimizer — Base for Gradient-Based Text Optimizers
summary: >
    Abstract base for optimizers that use textual gradients to update
    Parameters. Extends Optimizer with an engine requirement.
---
"""
from __future__ import annotations

from abc import abstractmethod
from typing import TYPE_CHECKING

from learn.optim.base import Optimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter


class TextOptimizer(Optimizer):
    r"""
    <a id="TextOptimizer"></a>

    ## TextOptimizer

    Base for gradient-based text optimizers. Requires an engine for
    generating improved parameter values from textual gradients.

    Subclasses must implement ``propose()`` (generate candidates)
    and optionally override ``step()`` (propose + archive).
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
    ) -> None:
        super().__init__(params, engine=engine)
        if engine is None:
            raise ValueError("TextOptimizer requires an engine.")

    @abstractmethod
    def propose(self) -> None:
        """Generate updated values for all parameters with gradients."""
        ...

    def step(self) -> None:
        """Propose updates then archive gradients."""
        self.propose()
        for p in self.params:
            p.archive_gradients()
