"""
---
title: REMO — Reflection-Enhanced Meta-Optimization
summary: >
    Maintains a memory of past mistakes and their corrections.
    Uses reflection to generate meta-level improvement plans.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

REMO_REFLECT_PROMPT = """\
Here is a variable and feedback about its performance:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<FEEDBACK>
{gradient_text}
</FEEDBACK>

{mistake_text}\
First, reflect on what went wrong and why. What pattern of mistakes \
do you see? Then produce an improved version.

<REFLECTION>
[Your analysis of the mistakes and patterns]
</REFLECTION>

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class REMO(TextOptimizer):
    r"""
    ## REMO — Reflection-Enhanced Meta-Optimization

    Maintains a memory of past mistakes and their corrections.
    Uses reflection to generate meta-level improvement plans before
    proposing updates.
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_mistakes: int = 10,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_mistakes = max_mistakes
        self._mistakes: list[dict[str, str]] = []

    def record_mistake(
        self, old_value: str, feedback: str, correction: str
    ) -> None:
        """Record a mistake and its correction for future reflection."""
        self._mistakes.append({
            "old_value": old_value,
            "feedback": feedback,
            "correction": correction,
        })
        # Keep only recent mistakes
        self._mistakes = self._mistakes[-self.max_mistakes :]

    def propose(self) -> None:
        """Generate improved values using reflection on past mistakes."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Build mistake history
            mistake_text = ""
            if self._mistakes:
                mistake_lines = []
                for m in self._mistakes[-5:]:
                    mistake_lines.append(
                        f"Previous mistake: {m['feedback'][:100]}\n"
                        f"Correction applied: {m['correction'][:100]}\n"
                    )
                mistake_text = (
                    "Past mistakes and corrections:\n\n"
                    + "\n".join(mistake_lines)
                    + "\n"
                )

            prompt = REMO_REFLECT_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                mistake_text=mistake_text,
            )

            old_value = param.data
            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

            # Record the change for future reflection
            self.record_mistake(old_value, gradient_text, improved)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["mistakes"] = list(self._mistakes)
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._mistakes = state.get("mistakes", [])


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
