"""
---
title: ETGPO — Error Taxonomy-Guided Prompt Optimization
summary: >
    Classifies errors by type, maintains per-type fix patterns,
    and applies targeted corrections.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from learn.optim.txt.autograd.prompts import OPTIMIZER_SYSTEM_PROMPT
from learn.optim.txt.base import TextOptimizer

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Parameter

CLASSIFY_PROMPT = """\
Classify this feedback into an error type category:

<FEEDBACK>
{gradient_text}
</FEEDBACK>

Choose ONE category from: formatting, factual, reasoning, completeness, \
relevance, clarity, other.

Respond with ONLY the category name."""

ETGPO_PROMPT = """\
Here is a variable that needs to be improved:

<CURRENT_VALUE role="{role}">
{current_value}
</CURRENT_VALUE>

<FEEDBACK>
{gradient_text}
</FEEDBACK>

<ERROR_TYPE>
{error_type}
</ERROR_TYPE>

{patterns_text}\
Based on the error type and known fix patterns, produce an improved \
version that specifically addresses this type of error.

<IMPROVED_VARIABLE>
[Your improved version here]
</IMPROVED_VARIABLE>"""


class ETGPO(TextOptimizer):
    r"""
    ## ETGPO — Error Taxonomy-Guided Prompt Optimization

    Classifies errors by type, maintains per-type fix patterns,
    and applies targeted corrections based on the error taxonomy.

    Reference: ETGPO (2024)
    """

    def __init__(
        self,
        params: list[Parameter],
        engine: EngineLM,
        max_patterns_per_type: int = 5,
    ) -> None:
        super().__init__(params, engine=engine)
        self.max_patterns_per_type = max_patterns_per_type
        # Error type → list of fix patterns
        self._patterns: dict[str, list[str]] = {}

    def _classify_error(self, gradient_text: str) -> str:
        """Classify the error type using LLM."""
        assert self.engine is not None
        prompt = CLASSIFY_PROMPT.format(gradient_text=gradient_text)
        result = self.engine.generate(prompt).strip().lower()
        # Normalize
        valid = {"formatting", "factual", "reasoning", "completeness",
                 "relevance", "clarity", "other"}
        for v in valid:
            if v in result:
                return v
        return "other"

    def record_pattern(self, error_type: str, pattern: str) -> None:
        """Record a fix pattern for an error type."""
        if error_type not in self._patterns:
            self._patterns[error_type] = []
        self._patterns[error_type].append(pattern)
        self._patterns[error_type] = self._patterns[error_type][
            -self.max_patterns_per_type :
        ]

    def propose(self) -> None:
        """Generate improved values using error-type-specific guidance."""
        assert self.engine is not None
        for param in self.params:
            if not param.requires_opt:
                continue

            gradient_text = param.get_gradient_text()
            if not gradient_text:
                continue

            # Classify error
            error_type = self._classify_error(gradient_text)

            # Look up patterns
            patterns_text = ""
            patterns = self._patterns.get(error_type, [])
            if patterns:
                patterns_text = (
                    f"Known fix patterns for '{error_type}' errors:\n"
                    + "\n".join(f"- {p}" for p in patterns)
                    + "\n\n"
                )

            prompt = ETGPO_PROMPT.format(
                role=param.role_description,
                current_value=param.data,
                gradient_text=gradient_text,
                error_type=error_type,
                patterns_text=patterns_text,
            )
            response = self.engine.generate(
                prompt, system_prompt=OPTIMIZER_SYSTEM_PROMPT
            )
            improved = _extract_improved_variable(response)
            param.update(improved)

    def state_dict(self) -> dict[str, Any]:
        state = super().state_dict()
        state["patterns"] = dict(self._patterns)
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        super().load_state_dict(state)
        self._patterns = state.get("patterns", {})


def _extract_improved_variable(response: str) -> str:
    match = re.search(
        r"<IMPROVED_VARIABLE>\s*(.*?)\s*</IMPROVED_VARIABLE>",
        response,
        re.DOTALL,
    )
    if match:
        return match.group(1).strip()
    return response.strip()
