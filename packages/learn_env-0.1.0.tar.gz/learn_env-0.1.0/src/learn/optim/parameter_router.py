"""
---
title: ParameterRouter — Routes Parameters to Optimizers by Type
summary: >
    Dispatches parameters to different optimizers based on their
    ParameterType classification.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.env.program.types import ParameterType

if TYPE_CHECKING:
    from learn.env.program.variable import Parameter
    from learn.optim.base import Optimizer


class ParameterRouter:
    r"""
    ## ParameterRouter — Type-Based Parameter Routing

    Routes parameters to optimizers by their ParameterType:
    * PROMPT → TGD
    * DEMOS → Bootstrap
    * STRUCTURE → MCTSEvolution

    ```python
    router = ParameterRouter({
        ParameterType.PROMPT: tgd,
        ParameterType.DEMOS: bootstrap,
    })
    router.step(params)
    ```
    """

    def __init__(
        self,
        routes: dict[ParameterType, Optimizer],
        default: Optimizer | None = None,
    ) -> None:
        self.routes = routes
        self.default = default

    def step(self, parameters: list[Parameter] | None = None) -> None:
        """Route each parameter to its designated optimizer and step."""
        if parameters is None:
            # Step all optimizers without parameter filtering
            for opt in self.routes.values():
                opt.step()
            return

        # Group parameters by type
        grouped: dict[ParameterType, list[Parameter]] = {}
        for param in parameters:
            if param.param_type not in grouped:
                grouped[param.param_type] = []
            grouped[param.param_type].append(param)

        # Route to appropriate optimizer
        for ptype, params in grouped.items():
            optimizer = self.routes.get(ptype, self.default)
            if optimizer is not None:
                # Temporarily set the optimizer's params
                old_params = optimizer.params
                optimizer.params = params
                optimizer.step()
                optimizer.params = old_params

    def zero_grad(self, parameters: list[Parameter]) -> None:
        """Clear gradients on all parameters."""
        for p in parameters:
            p.zero_grad()
