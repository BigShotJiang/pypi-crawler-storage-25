"""
---
title: Evaluation Protocols
summary: >
    Abstract evaluation protocol and concrete implementations for
    single-pass and multi-run evaluation with statistical aggregation.
---
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from learn.benchmark.eval.scoring import ScoringFunction
    from learn.benchmark.task.sample import AgentDataset, AgentSample


class EvaluationProtocol(ABC):
    """Abstract base for evaluation protocols."""

    @abstractmethod
    def evaluate(
        self,
        predict_fn: Callable[[AgentSample], str],
        dataset: AgentDataset,
        scorer: ScoringFunction,
    ) -> dict[str, Any]:
        """Run the evaluation and return summary statistics."""
        ...


class StandardProtocol(EvaluationProtocol):
    """Standard single-pass evaluation.

    Runs ``predict_fn`` on every sample, scores against expected output,
    and returns aggregated statistics.
    """

    def evaluate(
        self,
        predict_fn: Callable[[AgentSample], str],
        dataset: AgentDataset,
        scorer: ScoringFunction,
    ) -> dict[str, Any]:
        predictions = [predict_fn(s) for s in dataset.samples]
        expected = [s.expected_output for s in dataset.samples]
        return scorer.batch_score(predictions, expected)


class MultiRunProtocol(EvaluationProtocol):
    """Run evaluation N times and compute variance statistics.

    Useful for measuring stability of non-deterministic systems.
    """

    def __init__(self, n_runs: int = 5) -> None:
        self.n_runs = n_runs

    def evaluate(
        self,
        predict_fn: Callable[[AgentSample], str],
        dataset: AgentDataset,
        scorer: ScoringFunction,
    ) -> dict[str, Any]:
        run_means: list[float] = []
        for _ in range(self.n_runs):
            predictions = [predict_fn(s) for s in dataset.samples]
            expected = [s.expected_output for s in dataset.samples]
            stats = scorer.batch_score(predictions, expected)
            run_means.append(stats["mean"])

        overall = sum(run_means) / len(run_means) if run_means else 0.0
        variance = (
            sum((m - overall) ** 2 for m in run_means) / len(run_means)
            if run_means
            else 0.0
        )
        return {
            "primary": overall,
            "mean": overall,
            "variance": variance,
            "n_runs": self.n_runs,
            "run_scores": run_means,
        }
