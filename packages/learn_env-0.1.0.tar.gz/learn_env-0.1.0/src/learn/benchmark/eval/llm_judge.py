"""
---
title: LLMJudge — LLM-as-a-Judge Evaluation
summary: >
    Uses an LLM engine to score predictions or compare response pairs.
    Supports numeric scoring on a 1-10 scale and pairwise preference.
---
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM

_SCORE_PROMPT = """\
Evaluate the following response against the reference answer.
Criteria: {criteria}

Reference: {reference}
Response: {prediction}

Provide a numeric score from 1 to 10. Output ONLY the number."""

_PAIRWISE_PROMPT = """\
Given the following prompt, determine which response is better.
Criteria: {criteria}

Prompt: {prompt}

Response A: {response_a}
Response B: {response_b}

Which response is better? Answer with ONLY "A" or "B"."""


class LLMJudge:
    """LLM-as-a-judge evaluation using an engine.

    ```python
    judge = LLMJudge(engine=my_engine, criteria="accuracy")
    score = judge.score("Paris", "Paris")  # → ~9.0-10.0
    winner = judge.pairwise("Good answer", "Bad answer", "What is 2+2?")
    ```
    """

    def __init__(self, engine: EngineLM, criteria: str = "accuracy and helpfulness") -> None:
        self.engine = engine
        self.criteria = criteria

    def score(self, prediction: str, reference: str) -> float:
        """Ask the LLM to rate the prediction on a 1-10 scale.

        Returns:
            A float score in [1.0, 10.0], normalized to [0.0, 1.0].
        """
        prompt = _SCORE_PROMPT.format(
            criteria=self.criteria,
            reference=reference,
            prediction=prediction,
        )
        response = self.engine.generate(prompt)
        return self._parse_score(response)

    def pairwise(self, response_a: str, response_b: str, prompt: str) -> str:
        """Ask the LLM which response is better.

        Returns:
            ``"A"`` or ``"B"``.
        """
        judge_prompt = _PAIRWISE_PROMPT.format(
            criteria=self.criteria,
            prompt=prompt,
            response_a=response_a,
            response_b=response_b,
        )
        response = self.engine.generate(judge_prompt)
        cleaned = response.strip().upper()
        return "A" if "A" in cleaned else "B"

    @staticmethod
    def _parse_score(response: str) -> float:
        """Extract a numeric score from LLM output, normalize to [0, 1]."""
        match = re.search(r"(\d+(?:\.\d+)?)", response)
        if match:
            raw = float(match.group(1))
            # Clamp to [1, 10] then normalize to [0, 1]
            return max(0.0, min((raw - 1.0) / 9.0, 1.0))
        return 0.0
