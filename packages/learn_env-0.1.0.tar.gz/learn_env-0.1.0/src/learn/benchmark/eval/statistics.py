"""
---
title: Statistical Utilities for Evaluation
summary: >
    Bootstrap confidence intervals and Cohen's d effect size computation.
    Uses only stdlib (math, random) — no numpy/scipy dependency.
---
"""
from __future__ import annotations

import math
import random


class BootstrapCI:
    """Bootstrap confidence intervals for evaluation scores.

    ```python
    mean, lo, hi = BootstrapCI.compute([0.8, 0.9, 0.7, 0.85])
    ```
    """

    @staticmethod
    def compute(
        scores: list[float],
        n_bootstrap: int = 1000,
        confidence: float = 0.95,
        seed: int | None = None,
    ) -> tuple[float, float, float]:
        """Compute bootstrap confidence interval.

        Args:
            scores: List of numeric scores.
            n_bootstrap: Number of bootstrap resamples.
            confidence: Confidence level (e.g. 0.95 for 95% CI).
            seed: Optional random seed for reproducibility.

        Returns:
            Tuple of (mean, lower_bound, upper_bound).
        """
        if not scores:
            return (0.0, 0.0, 0.0)

        rng = random.Random(seed)
        n = len(scores)
        means: list[float] = []

        for _ in range(n_bootstrap):
            sample = [rng.choice(scores) for _ in range(n)]
            means.append(sum(sample) / n)

        means.sort()
        alpha = (1.0 - confidence) / 2.0
        lo_idx = int(alpha * len(means))
        hi_idx = int((1.0 - alpha) * len(means)) - 1
        lo_idx = max(0, lo_idx)
        hi_idx = min(len(means) - 1, hi_idx)

        overall_mean = sum(scores) / n
        return (overall_mean, means[lo_idx], means[hi_idx])


class EffectSize:
    """Cohen's d effect size computation.

    ```python
    d = EffectSize.cohens_d([0.8, 0.9, 0.7], [0.5, 0.6, 0.4])
    ```
    """

    @staticmethod
    def cohens_d(group1: list[float], group2: list[float]) -> float:
        """Compute Cohen's d between two groups.

        Returns:
            Cohen's d effect size. Positive means group1 > group2.
        """
        if not group1 or not group2:
            return 0.0

        n1, n2 = len(group1), len(group2)
        mean1 = sum(group1) / n1
        mean2 = sum(group2) / n2

        var1 = sum((x - mean1) ** 2 for x in group1) / max(n1 - 1, 1)
        var2 = sum((x - mean2) ** 2 for x in group2) / max(n2 - 1, 1)

        # Pooled standard deviation
        pooled_var = ((n1 - 1) * var1 + (n2 - 1) * var2) / max(n1 + n2 - 2, 1)
        pooled_sd = math.sqrt(pooled_var)

        if pooled_sd == 0.0:
            return 0.0

        return (mean1 - mean2) / pooled_sd
