"""
---
title: BenchmarkRegistry — Decorator-Based Benchmark Registration
summary: >
    Fairseq-style registry for benchmark tasks and evaluators.
    Use ``@register_benchmark("name")`` to register new benchmarks.
---

# Benchmark Registry

Auto-discovery registry for benchmark tasks, scoring functions,
and evaluation protocols.
"""
from __future__ import annotations

from typing import Callable, TypeVar

T = TypeVar("T")

# Global registries
_BENCHMARK_REGISTRY: dict[str, type] = {}
_SCORER_REGISTRY: dict[str, type] = {}
_LOADER_REGISTRY: dict[str, type] = {}


def register_benchmark(name: str) -> Callable[[type[T]], type[T]]:
    """Register a benchmark loader class.

    ```python
    @register_benchmark("gsm8k")
    class GSM8KLoader(DatasetLoader):
        ...
    ```
    """

    def decorator(cls: type[T]) -> type[T]:
        _BENCHMARK_REGISTRY[name] = cls
        return cls

    return decorator


def register_scorer(name: str) -> Callable[[type[T]], type[T]]:
    """Register a scoring function class.

    ```python
    @register_scorer("exact_match")
    class ExactMatch(ScoringFunction):
        ...
    ```
    """

    def decorator(cls: type[T]) -> type[T]:
        _SCORER_REGISTRY[name] = cls
        return cls

    return decorator


def register_loader(name: str) -> Callable[[type[T]], type[T]]:
    """Register a dataset loader class.

    ```python
    @register_loader("gsm8k")
    class GSM8KLoader(DatasetLoader):
        ...
    ```
    """

    def decorator(cls: type[T]) -> type[T]:
        _LOADER_REGISTRY[name] = cls
        return cls

    return decorator


def get_benchmark(name: str) -> type:
    """Retrieve a registered benchmark by name.

    Raises:
        KeyError: If benchmark not found.
    """
    if name not in _BENCHMARK_REGISTRY:
        available = ", ".join(sorted(_BENCHMARK_REGISTRY.keys()))
        raise KeyError(
            f"Benchmark '{name}' not found. Available: {available}"
        )
    return _BENCHMARK_REGISTRY[name]


def get_scorer(name: str) -> type:
    """Retrieve a registered scorer by name."""
    if name not in _SCORER_REGISTRY:
        available = ", ".join(sorted(_SCORER_REGISTRY.keys()))
        raise KeyError(
            f"Scorer '{name}' not found. Available: {available}"
        )
    return _SCORER_REGISTRY[name]


def get_loader(name: str) -> type:
    """Retrieve a registered loader by name."""
    if name not in _LOADER_REGISTRY:
        available = ", ".join(sorted(_LOADER_REGISTRY.keys()))
        raise KeyError(
            f"Loader '{name}' not found. Available: {available}"
        )
    return _LOADER_REGISTRY[name]


def list_benchmarks() -> list[str]:
    """List all registered benchmark names."""
    return sorted(_BENCHMARK_REGISTRY.keys())


def list_scorers() -> list[str]:
    """List all registered scorer names."""
    return sorted(_SCORER_REGISTRY.keys())


def list_loaders() -> list[str]:
    """List all registered loader names."""
    return sorted(_LOADER_REGISTRY.keys())
