"""
---
title: ScoringFunction ABC + ExactMatch, F1
summary: >
    Abstract base for scoring functions and two concrete implementations.
    All scoring functions: ``(prediction, ground_truth) → float ∈ [0, 1]``.
---
"""
from __future__ import annotations

import re
import string
from abc import ABC, abstractmethod
from collections import Counter


class ScoringFunction(ABC):
    """Abstract base class for scoring functions.

    All scorers take ``(prediction: str, ground_truth: str) → float``.
    Scores are in [0.0, 1.0] where 1.0 is perfect.
    """

    @abstractmethod
    def score(self, prediction: str, ground_truth: str) -> float:
        """Score a single prediction against ground truth."""
        ...

    def batch_score(
        self,
        predictions: list[str],
        ground_truths: list[str],
    ) -> dict[str, float]:
        """Score a batch and return summary statistics."""
        scores = [
            self.score(p, g) for p, g in zip(predictions, ground_truths)
        ]
        mean = sum(scores) / len(scores) if scores else 0.0
        return {
            "primary": mean,
            "mean": mean,
            "count": len(scores),
        }

    def __call__(self, prediction: str, ground_truth: str) -> float:
        return self.score(prediction, ground_truth)


def _normalize_text(text: str) -> str:
    """SQuAD-style text normalization.

    Lowercase → remove punctuation → remove articles → collapse whitespace.
    """
    text = text.lower()
    text = text.translate(str.maketrans("", "", string.punctuation))
    # Remove articles
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    # Collapse whitespace
    text = " ".join(text.split())
    return text.strip()


class ExactMatch(ScoringFunction):
    """Normalized exact match scoring.

    Applies SQuAD-style normalization before comparison.
    """

    def score(self, prediction: str, ground_truth: str) -> float:
        return 1.0 if _normalize_text(prediction) == _normalize_text(ground_truth) else 0.0


class TokenF1(ScoringFunction):
    """Token-level F1 scoring (bag-of-words).

    Computes precision, recall, and F1 over normalized token sets.
    """

    def score(self, prediction: str, ground_truth: str) -> float:
        pred_tokens = _normalize_text(prediction).split()
        gold_tokens = _normalize_text(ground_truth).split()

        if not gold_tokens and not pred_tokens:
            return 1.0
        if not gold_tokens or not pred_tokens:
            return 0.0

        pred_counts = Counter(pred_tokens)
        gold_counts = Counter(gold_tokens)

        common = sum((pred_counts & gold_counts).values())

        if common == 0:
            return 0.0

        precision = common / sum(pred_counts.values())
        recall = common / sum(gold_counts.values())

        return 2 * precision * recall / (precision + recall)
