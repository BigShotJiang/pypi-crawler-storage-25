"""
---
title: ComparisonMatrix — Cross-Benchmark Method Comparison
summary: >
    Compare multiple methods across multiple benchmarks.
    Stores scores in a method × benchmark matrix and renders
    Markdown tables.
---
"""
from __future__ import annotations


class ComparisonMatrix:
    """Compare multiple methods across benchmarks.

    ```python
    matrix = ComparisonMatrix()
    matrix.add_result("OPRO", "GSM8K", 0.85)
    matrix.add_result("TextGrad", "GSM8K", 0.78)
    print(matrix.to_table())
    ```
    """

    def __init__(self) -> None:
        self._results: dict[str, dict[str, float]] = {}

    def add_result(self, method: str, benchmark: str, score: float) -> None:
        """Record a score for a method on a benchmark."""
        if method not in self._results:
            self._results[method] = {}
        self._results[method][benchmark] = score

    def to_table(self) -> str:
        """Render as a Markdown table."""
        if not self._results:
            return "*(empty)*"

        benchmarks = sorted(
            {b for scores in self._results.values() for b in scores}
        )
        header = "| Method | " + " | ".join(benchmarks) + " |"
        sep = "|--------|" + "|".join("------" for _ in benchmarks) + "|"

        rows: list[str] = [header, sep]
        for method in sorted(self._results):
            cells = [
                f"{self._results[method].get(b, float('nan')):.4f}"
                for b in benchmarks
            ]
            rows.append(f"| {method} | " + " | ".join(cells) + " |")
        return "\n".join(rows)

    def best_method(self, benchmark: str) -> str:
        """Return the method with the highest score on a benchmark."""
        best_name = ""
        best_score = -1.0
        for method, scores in self._results.items():
            if benchmark in scores and scores[benchmark] > best_score:
                best_score = scores[benchmark]
                best_name = method
        return best_name
