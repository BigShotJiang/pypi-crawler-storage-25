"""
---
title: LeaderboardTable — Ranked Method Leaderboard
summary: >
    Maintain a leaderboard of methods ranked by aggregate scores.
    Supports ranking by any score key and Markdown rendering.
---
"""
from __future__ import annotations

from typing import Any


class LeaderboardTable:
    """Ranked leaderboard of methods.

    ```python
    lb = LeaderboardTable()
    lb.add_entry("OPRO", {"gsm8k": 0.85, "mmlu": 0.72})
    lb.add_entry("TextGrad", {"gsm8k": 0.78, "mmlu": 0.80})
    print(lb.to_markdown())
    ```
    """

    def __init__(self) -> None:
        self._entries: list[dict[str, Any]] = []

    def add_entry(
        self,
        method: str,
        scores: dict[str, float],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Add a method entry with its scores."""
        entry: dict[str, Any] = {"method": method, "scores": scores}
        if metadata:
            entry["metadata"] = metadata
        self._entries.append(entry)

    def rank(self, by: str = "mean") -> list[dict[str, Any]]:
        """Rank entries by a specific score key or by mean of all scores."""
        def _sort_key(entry: dict[str, Any]) -> float:
            scores = entry["scores"]
            if by == "mean":
                return sum(scores.values()) / len(scores) if scores else 0.0
            return scores.get(by, 0.0)

        ranked = sorted(self._entries, key=_sort_key, reverse=True)
        for i, entry in enumerate(ranked, 1):
            entry["rank"] = i
        return ranked

    def to_markdown(self, by: str = "mean") -> str:
        """Render the ranked leaderboard as a Markdown table."""
        ranked = self.rank(by=by)
        if not ranked:
            return "*(empty)*"

        score_keys = sorted(
            {k for e in self._entries for k in e["scores"]}
        )
        header = "| Rank | Method | " + " | ".join(score_keys) + " |"
        sep = "|------|--------|" + "|".join("------" for _ in score_keys) + "|"

        rows: list[str] = [header, sep]
        for entry in ranked:
            cells = [f"{entry['scores'].get(k, 0.0):.4f}" for k in score_keys]
            rows.append(
                f"| {entry['rank']} | {entry['method']} | "
                + " | ".join(cells)
                + " |"
            )
        return "\n".join(rows)
