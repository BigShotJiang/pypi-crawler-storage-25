"""
---
title: Dataset Loaders
summary: >
    Abstract DatasetLoader and concrete implementations for loading
    AgentDataset from in-memory samples or JSON files.
---
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any

from learn.benchmark.task.sample import AgentDataset, AgentSample


class DatasetLoader(ABC):
    """Abstract base for dataset loaders."""

    @abstractmethod
    def load(self, split: str = "test") -> AgentDataset:
        """Load and return an AgentDataset."""
        ...


class InMemoryLoader(DatasetLoader):
    """Load from pre-constructed samples.

    ```python
    loader = InMemoryLoader([
        AgentSample(input="2+2", expected_output="4"),
    ])
    dataset = loader.load()
    ```
    """

    def __init__(self, samples: list[AgentSample], name: str = "custom") -> None:
        self.samples = samples
        self.name = name

    def load(self, split: str = "test") -> AgentDataset:
        return AgentDataset(name=self.name, samples=self.samples, split=split)


class JSONLoader(DatasetLoader):
    """Load AgentDataset from a JSON file.

    Expected JSON format::

        [
            {"input": "...", "expected_output": "...", "metadata": {}},
            ...
        ]
    """

    def __init__(self, path: str, name: str = "json_dataset") -> None:
        self.path = path
        self.name = name

    def load(self, split: str = "test") -> AgentDataset:
        """Read JSON file and parse into AgentSamples."""
        with open(self.path, encoding="utf-8") as f:
            raw: list[dict[str, Any]] = json.load(f)

        samples = [
            AgentSample(
                input=entry["input"],
                expected_output=entry.get("expected_output", ""),
                metadata=entry.get("metadata", {}),
            )
            for entry in raw
        ]
        return AgentDataset(name=self.name, samples=samples, split=split)
