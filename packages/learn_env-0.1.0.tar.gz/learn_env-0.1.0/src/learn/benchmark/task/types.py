"""
---
title: Benchmark Types — Task and Difficulty Enums
summary: >
    Enumerations for task classification and difficulty levels
    used across the benchmark framework.
---
"""
from __future__ import annotations

from enum import Enum


class TaskType(Enum):
    """Classification of benchmark task types."""

    MATH = "math"
    CODE = "code"
    QA = "qa"
    CLASSIFICATION = "classification"
    MULTIPLE_CHOICE = "multiple_choice"
    GENERATION = "generation"
    AGENT = "agent"
    TOOL = "tool"


class TaskDifficulty(Enum):
    """Difficulty tiers for benchmark tasks."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"
