"""
---
title: AgentSample, AgentDataset — Benchmark Data Containers
summary: >
    ``AgentSample`` is a single benchmark example with input, expected
    output, and metadata. ``AgentDataset`` is a collection of samples
    with splitting and subsampling utilities.
---
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Iterator

from learn.benchmark.task.types import TaskType


@dataclass
class AgentSample:
    """A single benchmark example.

    Attributes:
        input: The task input text.
        expected_output: The ground truth answer.
        metadata: Arbitrary key-value pairs (id, difficulty, etc.).
        task_type: Classification of the task.
    """

    input: str
    expected_output: str
    metadata: dict[str, Any] = field(default_factory=dict)
    task_type: TaskType = TaskType.QA


class AgentDataset:
    """A collection of benchmark samples with utility methods.

    ```python
    dataset = AgentDataset(
        name="my_benchmark",
        samples=[AgentSample(input="2+2", expected_output="4")],
    )
    train, test = dataset.split(ratio=0.8, seed=42)
    subset = dataset.subsample(n=10, seed=42)
    ```
    """

    def __init__(
        self,
        name: str,
        samples: list[AgentSample] | None = None,
        split: str = "test",
    ) -> None:
        self.name = name
        self.samples: list[AgentSample] = samples or []
        self.split = split

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> AgentSample:
        return self.samples[idx]

    def __iter__(self) -> Iterator[AgentSample]:
        return iter(self.samples)

    def subsample(self, n: int, seed: int = 42) -> AgentDataset:
        """Return a reproducible random subset of *n* samples."""
        rng = random.Random(seed)
        n = min(n, len(self.samples))
        selected = rng.sample(self.samples, n)
        return AgentDataset(
            name=f"{self.name}_sub{n}",
            samples=selected,
            split=self.split,
        )

    def split_dataset(
        self, ratio: float = 0.8, seed: int = 42
    ) -> tuple[AgentDataset, AgentDataset]:
        """Split into two datasets by ratio.

        Args:
            ratio: Fraction for the first split.
            seed: Random seed for reproducibility.

        Returns:
            (train_dataset, test_dataset)
        """
        rng = random.Random(seed)
        shuffled = list(self.samples)
        rng.shuffle(shuffled)
        split_idx = int(len(shuffled) * ratio)
        return (
            AgentDataset(
                name=f"{self.name}_train",
                samples=shuffled[:split_idx],
                split="train",
            ),
            AgentDataset(
                name=f"{self.name}_test",
                samples=shuffled[split_idx:],
                split="test",
            ),
        )

    def __repr__(self) -> str:
        return f"AgentDataset(name={self.name!r}, split={self.split!r}, n={len(self)})"
