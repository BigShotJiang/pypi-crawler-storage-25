"""
---
title: BenchmarkRunner — Evaluation Pipeline
summary: >
    Runs a callable (agent/program) over a dataset and collects scores.
    Pure evaluation — optimization is the Trainer's job.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from learn.benchmark.eval.scoring import ScoringFunction
from learn.benchmark.task.sample import AgentDataset


@dataclass
class BenchmarkResult:
    """Results from a benchmark run.

    Attributes:
        dataset_name: Name of the dataset evaluated.
        scores: Per-sample scores.
        aggregate: Summary statistics from the scorer.
        predictions: Per-sample predictions.
        metadata: Additional run metadata.
    """

    dataset_name: str
    scores: list[float] = field(default_factory=list)
    aggregate: dict[str, float] = field(default_factory=dict)
    predictions: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def primary_score(self) -> float:
        """The primary aggregate score."""
        return self.aggregate.get("primary", 0.0)


class BenchmarkRunner:
    r"""
    <a id="BenchmarkRunner"></a>

    ## BenchmarkRunner

    Runs a callable over a dataset and scores predictions.

    ```python
    runner = BenchmarkRunner(scorer=ExactMatch())
    result = runner.run(predict_fn, dataset)
    print(result.primary_score)
    ```

    The ``predict_fn`` takes an input string and returns a prediction string.
    """

    def __init__(self, scorer: ScoringFunction) -> None:
        self.scorer = scorer

    def run(
        self,
        predict_fn: Callable[[str], str],
        dataset: AgentDataset,
    ) -> BenchmarkResult:
        """Evaluate predict_fn on every sample in the dataset.

        Args:
            predict_fn: ``(input: str) → prediction: str``
            dataset: The dataset to evaluate on.

        Returns:
            BenchmarkResult with per-sample and aggregate scores.
        """
        predictions: list[str] = []
        scores: list[float] = []

        for sample in dataset:
            pred = predict_fn(sample.input)
            predictions.append(pred)
            score = self.scorer.score(pred, sample.expected_output)
            scores.append(score)

        aggregate = self.scorer.batch_score(
            predictions,
            [s.expected_output for s in dataset],
        )

        return BenchmarkResult(
            dataset_name=dataset.name,
            scores=scores,
            aggregate=aggregate,
            predictions=predictions,
        )
