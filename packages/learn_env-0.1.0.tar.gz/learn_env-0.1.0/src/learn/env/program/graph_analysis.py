"""
---
title: Graph Analysis Utilities
summary: >
    Tools for analyzing program DAG structure: topological sort, depth,
    width, critical path detection, and structural comparison.
---
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING

from learn.env.program.types import EdgeRelation

if TYPE_CHECKING:
    from learn.env.program.program import Program


class GraphAnalyzer:
    """Analyze the DAG structure of a Program."""

    def __init__(self, program: Program) -> None:
        self._program = program

    def topological_sort(self) -> list[str]:
        """Return nodes in topological order (Kahn's algorithm)."""
        nodes = self._program.get_nodes()
        edges = self._program.get_edges()

        in_degree: dict[str, int] = {n: 0 for n in nodes}
        adj: dict[str, list[str]] = defaultdict(list)
        for e in edges:
            if e.relation == EdgeRelation.DATAFLOW:
                adj[e.source].append(e.target)
                in_degree[e.target] += 1

        queue: deque[str] = deque(n for n, d in in_degree.items() if d == 0)
        order: list[str] = []
        while queue:
            node = queue.popleft()
            order.append(node)
            for s in adj[node]:
                in_degree[s] -= 1
                if in_degree[s] == 0:
                    queue.append(s)
        return order

    def depth(self) -> int:
        """Longest path length (number of edges) in the DAG."""
        order = self.topological_sort()
        if not order:
            return 0
        dist: dict[str, int] = {n: 0 for n in order}
        edges = self._program.get_edges()
        for node in order:
            for e in edges:
                if e.source == node and e.relation == EdgeRelation.DATAFLOW:
                    dist[e.target] = max(dist[e.target], dist[node] + 1)
        return max(dist.values()) if dist else 0

    def width(self) -> int:
        """Maximum number of nodes at any depth level."""
        order = self.topological_sort()
        if not order:
            return 0
        level: dict[str, int] = {n: 0 for n in order}
        edges = self._program.get_edges()
        for node in order:
            for e in edges:
                if e.source == node and e.relation == EdgeRelation.DATAFLOW:
                    level[e.target] = max(level[e.target], level[node] + 1)
        counts: dict[int, int] = defaultdict(int)
        for lv in level.values():
            counts[lv] += 1
        return max(counts.values()) if counts else 0

    def critical_path(self) -> list[str]:
        """Return the longest path through the DAG (by node count)."""
        order = self.topological_sort()
        if not order:
            return []
        dist: dict[str, int] = {n: 1 for n in order}
        prev: dict[str, str | None] = {n: None for n in order}
        edges = self._program.get_edges()
        for node in order:
            for e in edges:
                if e.source == node and e.relation == EdgeRelation.DATAFLOW:
                    if dist[node] + 1 > dist[e.target]:
                        dist[e.target] = dist[node] + 1
                        prev[e.target] = node
        end = max(order, key=lambda n: dist[n])
        path: list[str] = []
        cur: str | None = end
        while cur is not None:
            path.append(cur)
            cur = prev[cur]
        path.reverse()
        return path

    def is_dag(self) -> bool:
        """Return True if the DATAFLOW edges form a DAG."""
        return len(self.topological_sort()) == len(self._program.get_nodes())


class GraphComparator:
    """Compare two programs structurally."""

    @staticmethod
    def similarity(p1: Program, p2: Program) -> float:
        """Jaccard similarity of edge sets (source, target pairs)."""
        edges1 = {(e.source, e.target) for e in p1.get_edges()}
        edges2 = {(e.source, e.target) for e in p2.get_edges()}
        if not edges1 and not edges2:
            return 1.0
        intersection = edges1 & edges2
        union = edges1 | edges2
        return len(intersection) / len(union) if union else 1.0

    @staticmethod
    def diff(p1: Program, p2: Program) -> dict[str, set[tuple[str, str]]]:
        """Return edges added/removed between p1 and p2."""
        edges1 = {(e.source, e.target) for e in p1.get_edges()}
        edges2 = {(e.source, e.target) for e in p2.get_edges()}
        return {
            "added": edges2 - edges1,
            "removed": edges1 - edges2,
        }
