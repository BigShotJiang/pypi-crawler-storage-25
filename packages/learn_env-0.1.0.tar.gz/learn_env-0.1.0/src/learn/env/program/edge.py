"""
---
title: Edge — Typed Connections Between Agents
summary: >
    Edges connect agent nodes in a Program DAG. Each edge has a relation
    type (DATAFLOW, CONTROL_FLOW, etc.) and optional learnable parameters
    for importance weighting and active/inactive toggling.
---

# Edges

An Edge connects a source agent to a target agent with typed semantics.
The ``EdgeRelation`` enum (defined in ``types.py``) classifies the
connection type.

| Relation | Data transfer? | Creates cycle? |
|----------|---------------|----------------|
| DATAFLOW | Yes | No |
| CONTROL_FLOW | No | No |
| CONDITIONAL | Conditional | No |
| COMMUNICATION | Yes (side-channel) | No |
| DELEGATION | Yes | No |
| FEEDBACK | Yes (critique) | Logical yes |
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from learn.env.program.types import EdgeRelation


@dataclass
class Edge:
    r"""
    <a id="Edge"></a>

    ## Edge

    A typed connection between two named agent nodes in a Program DAG.

    ```python
    edge = Edge(
        source="solver",
        target="reviewer",
        relation=EdgeRelation.DATAFLOW,
    )
    ```
    """

    source: str
    target: str
    relation: EdgeRelation = EdgeRelation.DATAFLOW
    transform: Optional[Callable[[Any], Any]] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"Edge({self.source!r} → {self.target!r}, "
            f"relation={self.relation.name})"
        )

    def __hash__(self) -> int:
        return hash((self.source, self.target, self.relation))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Edge):
            return NotImplemented
        return (
            self.source == other.source
            and self.target == other.target
            and self.relation == other.relation
        )
