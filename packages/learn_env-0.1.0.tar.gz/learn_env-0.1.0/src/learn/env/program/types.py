"""
---
title: Shared Types and Enums
summary: >
    Shared type aliases and enumerations used across the learn framework.
    Includes ParameterType, EdgeRelation, and common type aliases.
---

# Shared Types and Enums

These types are the vocabulary of the framework — they appear in method
signatures across ``env``, ``agent``, ``optim``, and ``benchmark``.

The ``ParameterType`` enum classifies every ``Parameter`` by its role
in the agent pipeline, informing how optimizers should treat it.
"""
from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from learn.env.program.variable import Parameter, Variable


# ---------------------------------------------------------------------------
# Parameter type classification
# ---------------------------------------------------------------------------


class ParameterType(Enum):
    r"""
    <a id="ParameterType"></a>

    ## Parameter Type Classification

    Classifies each ``Parameter`` by its role in the agent pipeline.
    The optimizer uses this to decide *how* to update the parameter:

    - **PROMPT** parameters are updated via textual gradient descent (TGD).
    - **INSTRUCTION** parameters are task-specific guidance text.
    - **DEMOS** parameters are updated via few-shot bootstrap optimizers.
    - **STRUCTURE** parameters represent graph topology decisions.
    - **INPUT** / **OUTPUT** are data-flow variables, not directly optimized.

    | Type | Trainable | Typical Optimizer |
    |------|-----------|-------------------|
    | PROMPT | Yes | TGD, TSGD-M, TextBFGS, OPRO |
    | INSTRUCTION | Yes | TGD, OPRO |
    | DEMOS | Yes | Bootstrap, MIPROv2 |
    | STRUCTURE | Yes | MCTSEvolution, REINFORCE |
    | INPUT | No | — |
    | OUTPUT | No | — |
    | HYPERPARAM | No | — |
    | LOSS_OUTPUT | No | — |
    """

    PROMPT = ("prompt", "Instruction text for the LLM.", True)
    INSTRUCTION = ("instruction", "Task-specific guidance text.", True)
    DEMOS = ("demos", "Few-shot demonstration examples.", True)
    STRUCTURE = ("structure", "Graph topology / structural decision.", True)
    INPUT = ("input", "Runtime input data.", False)
    OUTPUT = ("output", "Generated output.", False)
    HYPERPARAM = ("hyperparam", "Numeric or categorical configuration.", False)
    LOSS_OUTPUT = ("loss_output", "Loss / evaluation output.", False)

    def __init__(self, value: str, description: str, trainable: bool) -> None:
        self._value_ = value
        self.description = description
        self.trainable = trainable

    def __str__(self) -> str:
        return f"{self.value} ({self.description})"

    def __repr__(self) -> str:
        return f"<ParameterType.{self.name}: {self.value!r}>"


# ---------------------------------------------------------------------------
# Edge relation types
# ---------------------------------------------------------------------------


class EdgeRelation(Enum):
    """Types of edges connecting agents in a Program DAG.

    | Relation | Semantics |
    |----------|-----------|
    | DATAFLOW | output → input (default) |
    | CONTROL_FLOW | must_complete_before |
    | CONDITIONAL | branch_on(predicate) |
    | COMMUNICATION | message_passing |
    | DELEGATION | delegated_task |
    | FEEDBACK | refinement_signal (creates logical cycle) |
    """

    DATAFLOW = "dataflow"
    CONTROL_FLOW = "control_flow"
    CONDITIONAL = "conditional"
    COMMUNICATION = "communication"
    DELEGATION = "delegation"
    FEEDBACK = "feedback"


# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

ParamsT = Union[list["Parameter"], list["Variable"]]
GradientMap = dict["Variable", set["Variable"]]
