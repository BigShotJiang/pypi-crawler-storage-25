"""
---
title: Program Codec — Serialization Formats
summary: >
    Abstract codec interface and concrete implementations for
    serializing/deserializing programs to JSON and Mermaid formats.
---
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from learn.env.program.program import Program


class ProgramCodec(ABC):
    """Abstract base for program serialization codecs."""

    @abstractmethod
    def encode(self, program: Program) -> str:
        """Serialize a program to a string representation."""
        ...

    @abstractmethod
    def decode(self, text: str) -> dict[str, Any]:
        """Deserialize a string representation to a node/edge dict."""
        ...


class JSONCodec(ProgramCodec):
    """Serialize programs to/from JSON.

    Output format::

        {
            "nodes": ["solver", "reviewer"],
            "edges": [{"source": "solver", "target": "reviewer", "relation": "DATAFLOW"}]
        }
    """

    def encode(self, program: Program) -> str:
        """Serialize program nodes and edges to JSON."""
        nodes = list(program.get_nodes().keys())
        edges = [
            {
                "source": e.source,
                "target": e.target,
                "relation": e.relation.name,
            }
            for e in program.get_edges()
        ]
        return json.dumps({"nodes": nodes, "edges": edges}, indent=2)

    def decode(self, text: str) -> dict[str, Any]:
        """Parse JSON into a node/edge dictionary."""
        return json.loads(text)


class MermaidCodec(ProgramCodec):
    """Serialize programs to/from Mermaid flowchart syntax.

    Output format::

        graph TD
            solver --> reviewer
    """

    def encode(self, program: Program) -> str:
        """Generate Mermaid flowchart from program structure."""
        lines = ["graph TD"]
        edges = program.get_edges()
        if not edges:
            # Just list nodes
            for name in program.get_nodes():
                lines.append(f"    {name}")
        else:
            for e in edges:
                label = e.relation.name
                if label == "DATAFLOW":
                    lines.append(f"    {e.source} --> {e.target}")
                else:
                    lines.append(f"    {e.source} -->|{label}| {e.target}")
        return "\n".join(lines)

    def decode(self, text: str) -> dict[str, Any]:
        """Parse basic Mermaid flowchart into node/edge dict."""
        nodes: set[str] = set()
        edges: list[dict[str, str]] = []
        for line in text.strip().splitlines():
            line = line.strip()
            if line.startswith("graph") or not line:
                continue
            if "-->" in line:
                # Handle "A -->|label| B" and "A --> B"
                parts = line.replace("|", " ").split("-->")
                source = parts[0].strip().split()[-1]
                target = parts[1].strip().split()[0]
                nodes.add(source)
                nodes.add(target)
                edges.append({"source": source, "target": target})
            else:
                nodes.add(line.strip())
        return {"nodes": sorted(nodes), "edges": edges}
