"""
---
title: Topology Presets for Multi-Agent Programs
summary: >
    Factory methods for common communication topologies: complete graph,
    star, chain, and ring patterns over named agent nodes.
---
"""
from __future__ import annotations

from learn.env.program.types import EdgeRelation


class TopologyPreset:
    """Communication topology presets for multi-agent programs.

    Each method returns a list of ``(source, target, relation)`` tuples
    ready to be passed to ``Program.add_edge``.
    """

    @staticmethod
    def complete(
        agent_names: list[str],
    ) -> list[tuple[str, str, EdgeRelation]]:
        """All-to-all communication between every pair of agents."""
        return [
            (a, b, EdgeRelation.COMMUNICATION)
            for a in agent_names
            for b in agent_names
            if a != b
        ]

    @staticmethod
    def star(
        center: str, leaves: list[str],
    ) -> list[tuple[str, str, EdgeRelation]]:
        """Hub-and-spoke: center communicates with all leaves."""
        edges: list[tuple[str, str, EdgeRelation]] = []
        for leaf in leaves:
            edges.append((center, leaf, EdgeRelation.DATAFLOW))
            edges.append((leaf, center, EdgeRelation.FEEDBACK))
        return edges

    @staticmethod
    def chain(
        agent_names: list[str],
    ) -> list[tuple[str, str, EdgeRelation]]:
        """Sequential pipeline: each agent feeds the next."""
        return [
            (agent_names[i], agent_names[i + 1], EdgeRelation.DATAFLOW)
            for i in range(len(agent_names) - 1)
        ]

    @staticmethod
    def ring(
        agent_names: list[str],
    ) -> list[tuple[str, str, EdgeRelation]]:
        """Circular topology: chain plus last→first edge."""
        if len(agent_names) < 2:
            return []
        edges = TopologyPreset.chain(agent_names)
        edges.append(
            (agent_names[-1], agent_names[0], EdgeRelation.FEEDBACK)
        )
        return edges
