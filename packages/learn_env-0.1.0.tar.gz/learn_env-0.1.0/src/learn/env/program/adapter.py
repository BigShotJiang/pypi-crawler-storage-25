"""
---
title: Adapter — Program Input/Output Adapters
summary: >
    Adapters for converting between different data formats (JSON, XML,
    Chat) and the framework's TextState/Variable types.
---

# Adapters

Transform external data formats into framework-native types and back.
Used by Program nodes to standardize I/O across heterogeneous agents.
"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from typing import Any


class Adapter(ABC):
    """Base class for I/O format adapters."""

    @abstractmethod
    def encode(self, data: Any) -> str:
        """Convert structured data to text format."""
        ...

    @abstractmethod
    def decode(self, text: str) -> Any:
        """Convert text format back to structured data."""
        ...


class JSONAdapter(Adapter):
    """Adapter for JSON-formatted I/O.

    ```python
    adapter = JSONAdapter()
    text = adapter.encode({"key": "value"})
    data = adapter.decode(text)
    ```
    """

    def __init__(self, indent: int | None = 2) -> None:
        self.indent = indent

    def encode(self, data: Any) -> str:
        return json.dumps(data, indent=self.indent, ensure_ascii=False)

    def decode(self, text: str) -> Any:
        # Strip markdown fences
        fenced = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
        if fenced:
            text = fenced.group(1)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to find JSON object/array
            for pattern in [r"\{.*\}", r"\[.*\]"]:
                match = re.search(pattern, text, re.DOTALL)
                if match:
                    try:
                        return json.loads(match.group(0))
                    except json.JSONDecodeError:
                        continue
            return {"_raw": text}


class XMLAdapter(Adapter):
    """Adapter for XML-tagged I/O.

    ```python
    adapter = XMLAdapter(root_tag="response")
    text = adapter.encode({"field": "value"})
    data = adapter.decode("<response><field>value</field></response>")
    ```
    """

    def __init__(self, root_tag: str = "data") -> None:
        self.root_tag = root_tag

    def encode(self, data: Any) -> str:
        if isinstance(data, dict):
            inner = "".join(
                f"<{k}>{v}</{k}>" for k, v in data.items()
            )
            return f"<{self.root_tag}>{inner}</{self.root_tag}>"
        return f"<{self.root_tag}>{data}</{self.root_tag}>"

    def decode(self, text: str) -> dict[str, str]:
        result: dict[str, str] = {}
        # First try to extract content within root tag
        root_match = re.search(
            rf"<{re.escape(self.root_tag)}>(.*?)</{re.escape(self.root_tag)}>",
            text, re.DOTALL,
        )
        inner = root_match.group(1) if root_match else text
        for match in re.finditer(r"<(\w+)>(.*?)</\1>", inner, re.DOTALL):
            tag, content = match.group(1), match.group(2).strip()
            result[tag] = content
        return result if result else {"_raw": text}


class ChatAdapter(Adapter):
    """Adapter for chat-format messages.

    Converts between list of ``{role, content}`` dicts and
    a formatted text string.

    ```python
    adapter = ChatAdapter()
    text = adapter.encode([
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi!"},
    ])
    messages = adapter.decode(text)
    ```
    """

    def encode(self, data: Any) -> str:
        if isinstance(data, list):
            parts = []
            for msg in data:
                role = msg.get("role", "unknown")
                content = msg.get("content", "")
                parts.append(f"[{role}]: {content}")
            return "\n\n".join(parts)
        return str(data)

    def decode(self, text: str) -> list[dict[str, str]]:
        messages = []
        for match in re.finditer(
            r"\[(\w+)\]:\s*(.*?)(?=\n\n\[|\Z)", text, re.DOTALL
        ):
            messages.append({
                "role": match.group(1),
                "content": match.group(2).strip(),
            })
        return messages if messages else [{"role": "user", "content": text}]


class PromptTemplate:
    """Simple string template with named placeholders.

    ```python
    template = PromptTemplate(
        "You are a {role}. Answer: {question}"
    )
    prompt = template.format(role="tutor", question="What is 2+2?")
    ```
    """

    def __init__(self, template: str) -> None:
        self.template = template

    def format(self, **kwargs: Any) -> str:
        """Fill template placeholders."""
        return self.template.format(**kwargs)

    @property
    def variables(self) -> list[str]:
        """Extract placeholder names from the template."""
        return re.findall(r"\{(\w+)\}", self.template)
