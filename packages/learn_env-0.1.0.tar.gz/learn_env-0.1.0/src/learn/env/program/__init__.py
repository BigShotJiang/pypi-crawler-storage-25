"""
---
title: learn.env.program — Program Composition
summary: >
    Core primitives for computation and program composition.
    A program is a DAG of agent nodes connected by typed edges.
---
"""
from learn.env.program.adapter import (
    Adapter,
    ChatAdapter,
    JSONAdapter,
    PromptTemplate,
    XMLAdapter,
)
from learn.env.program.codec import JSONCodec, MermaidCodec
from learn.env.program.dynamic import (
    ConditionalProgram,
    DynamicProgram,
    IterativeProgram,
)
from learn.env.program.edge import Edge
from learn.env.program.graph_analysis import GraphAnalyzer, GraphComparator
from learn.env.program.program import Program
from learn.env.program.shared_memory import SharedMemory
from learn.env.program.topology import TopologyPreset
from learn.env.program.types import EdgeRelation, ParameterType
from learn.env.program.variable import (
    Component,
    Parameter,
    Signature,
    TextState,
    Variable,
)

__all__ = [
    "Adapter",
    "ChatAdapter",
    "Component",
    "ConditionalProgram",
    "DynamicProgram",
    "Edge",
    "EdgeRelation",
    "GraphAnalyzer",
    "GraphComparator",
    "IterativeProgram",
    "JSONAdapter",
    "JSONCodec",
    "MermaidCodec",
    "Parameter",
    "ParameterType",
    "Program",
    "PromptTemplate",
    "SharedMemory",
    "Signature",
    "TextState",
    "TopologyPreset",
    "Variable",
    "XMLAdapter",
]