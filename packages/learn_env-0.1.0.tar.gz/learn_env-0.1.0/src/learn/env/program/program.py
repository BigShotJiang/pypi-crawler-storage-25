"""
---
title: Program — DAG Composition of Agents
summary: >
    A Program is a directed acyclic graph of Agent nodes connected by
    Edges. Execution follows topological order. Supports sequential,
    parallel, and arbitrary DAG topologies via edge patterns. Includes
    skill-aware convenience constructors for unified composition.
---

# Program

The Program is the top-level composition unit. It owns:

* A set of named agent nodes
* A set of typed edges connecting them
* Optional shared memory for inter-agent communication

Execution uses Kahn's algorithm for topological sort:

1. Nodes with no incoming edges receive the input TextState
2. Each node executes ``agent(state)``
3. Outputs are merged for fan-in nodes
4. The final node's output is the Program output

## Skill-Program Unification

Skills and Programs are two composition axes:

* **Skill topologies** (``SkillSequential``, ``SkillGraph``, …) compose
  *skills* using the ``Skill`` hierarchy — each composite is itself a Skill.
* **Programs** compose *agents* (which includes skills) into a DAG with
  typed edges and shared memory.

The ``from_skills`` and ``from_skill_topology`` class methods bridge
these two worlds, letting users convert between them freely.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING, Any

from learn.env.program.edge import Edge
from learn.env.program.shared_memory import SharedMemory
from learn.env.program.types import EdgeRelation
from learn.env.program.variable import Component, TextState

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.agent.skill.base import Skill


class Program(Component):
    r"""
    <a id="Program"></a>

    ## Program

    A DAG of Agent nodes connected by typed Edges.

    ```python
    program = Program()
    program.add_node("solver", solver_agent)
    program.add_node("reviewer", reviewer_agent)
    program.add_edge("solver", "reviewer")
    output = program(TextState(observation="Solve 2+2"))
    ```
    """

    def __init__(self, name: str | None = None) -> None:
        super().__init__(name=name or "Program")
        self._nodes: dict[str, Agent] = {}
        self._edges: list[Edge] = []
        self.shared_memory = SharedMemory()

    # ------------------------------------------------------------------
    # Graph construction
    # ------------------------------------------------------------------

    def add_node(self, name: str, agent: Agent) -> None:
        """Add an agent node to the program.

        Also registers it as a child Component for parameter discovery.
        """
        if name in self._nodes:
            raise ValueError(f"Node {name!r} already exists.")
        self._nodes[name] = agent
        self.register_component(name, agent)

    def add_edge(
        self,
        source: str,
        target: str,
        relation: EdgeRelation = EdgeRelation.DATAFLOW,
        **kwargs: Any,
    ) -> Edge:
        """Add a typed edge between two nodes.

        Args:
            source: Name of the source node.
            target: Name of the target node.
            relation: Edge relation type.

        Returns:
            The created Edge.
        """
        if source not in self._nodes:
            raise ValueError(f"Source node {source!r} not found.")
        if target not in self._nodes:
            raise ValueError(f"Target node {target!r} not found.")

        edge = Edge(source=source, target=target, relation=relation, **kwargs)
        self._edges.append(edge)
        return edge

    # ------------------------------------------------------------------
    # Graph queries
    # ------------------------------------------------------------------

    def get_nodes(self) -> dict[str, Agent]:
        """Return all nodes."""
        return dict(self._nodes)

    def get_edges(self) -> list[Edge]:
        """Return all edges."""
        return list(self._edges)

    def get_predecessors(self, node_name: str) -> list[str]:
        """Return names of nodes with DATAFLOW edges into this node."""
        return [
            e.source
            for e in self._edges
            if e.target == node_name and e.relation == EdgeRelation.DATAFLOW
        ]

    def get_successors(self, node_name: str) -> list[str]:
        """Return names of nodes with DATAFLOW edges from this node."""
        return [
            e.target
            for e in self._edges
            if e.source == node_name and e.relation == EdgeRelation.DATAFLOW
        ]

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def __call__(self, state: TextState, **kwargs: Any) -> TextState:
        """Execute the program: topologically sort nodes, run each."""
        order = self._topological_sort()

        # Track outputs per node
        node_outputs: dict[str, TextState] = {}

        for node_name in order:
            agent = self._nodes[node_name]
            preds = self.get_predecessors(node_name)

            if preds:
                # Merge predecessor outputs
                pred_states = [node_outputs[p] for p in preds if p in node_outputs]
                if pred_states:
                    input_state = TextState.merge(*pred_states)
                else:
                    input_state = state
            else:
                input_state = state

            node_outputs[node_name] = agent(input_state)

        # Return the output of the last node in topological order
        if order:
            return node_outputs[order[-1]]
        return state

    def _topological_sort(self) -> list[str]:
        """Kahn's algorithm for topological sorting."""
        # Build adjacency from DATAFLOW edges only
        in_degree: dict[str, int] = {name: 0 for name in self._nodes}
        adjacency: dict[str, list[str]] = defaultdict(list)

        for edge in self._edges:
            if edge.relation == EdgeRelation.DATAFLOW:
                adjacency[edge.source].append(edge.target)
                in_degree[edge.target] = in_degree.get(edge.target, 0) + 1

        # Start with nodes having no incoming edges
        queue: deque[str] = deque(
            name for name, deg in in_degree.items() if deg == 0
        )
        order: list[str] = []

        while queue:
            node = queue.popleft()
            order.append(node)
            for successor in adjacency.get(node, []):
                in_degree[successor] -= 1
                if in_degree[successor] == 0:
                    queue.append(successor)

        if len(order) != len(self._nodes):
            raise RuntimeError(
                "Cycle detected in DATAFLOW edges — "
                "cannot topologically sort the program."
            )

        return order

    # ------------------------------------------------------------------
    # Skill-aware constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_skills(
        cls,
        skills: list[Skill] | dict[str, Skill],
        *,
        topology: str = "chain",
        name: str | None = None,
    ) -> Program:
        r"""Build a Program from a list or dict of skills.

        Convenience constructor that wires skills into a Program DAG
        using a named topology pattern.

        Args:
            skills: Skills to compose. If a list, names are taken from
                ``skill.spec.name``. If a dict, keys are the node names.
            topology: One of ``"chain"`` (sequential DATAFLOW),
                ``"parallel"`` (all receive input, merge at end),
                ``"star"`` (first skill is hub, rest are spokes).
            name: Optional program name.

        Returns:
            A ``Program`` with the skills wired according to the
            chosen topology.

        ```python
        program = Program.from_skills(
            [extract_skill, summarize_skill],
            topology="chain",
        )
        output = program(TextState(observation="..."))
        ```
        """
        if isinstance(skills, list):
            skill_dict: dict[str, Skill] = {}
            for skill in skills:
                # Use spec.name if available, else fall back to class name
                sname = getattr(skill, "spec", None)
                key = sname.name if sname else skill.__class__.__name__
                # Avoid duplicate keys by appending suffix
                if key in skill_dict:
                    i = 1
                    while f"{key}_{i}" in skill_dict:
                        i += 1
                    key = f"{key}_{i}"
                skill_dict[key] = skill
        else:
            skill_dict = dict(skills)

        program = cls(name=name or f"SkillProgram({topology})")

        keys = list(skill_dict.keys())
        for k, skill in skill_dict.items():
            program.add_node(k, skill)

        if topology == "chain":
            for i in range(len(keys) - 1):
                program.add_edge(keys[i], keys[i + 1], EdgeRelation.DATAFLOW)

        elif topology == "parallel":
            # No edges — all nodes receive the input independently.
            # The last node in the dict is treated as the merge point
            # by default (topological order returns it last since it has
            # no incoming edges and dict order is preserved).
            pass

        elif topology == "star":
            if len(keys) < 2:
                raise ValueError("Star topology needs at least 2 skills.")
            hub = keys[0]
            for spoke in keys[1:]:
                program.add_edge(hub, spoke, EdgeRelation.DATAFLOW)

        else:
            raise ValueError(
                f"Unknown topology {topology!r}. "
                "Choose 'chain', 'parallel', or 'star'."
            )

        return program

    @classmethod
    def from_skill_topology(
        cls,
        skill_composite: Skill,
        *,
        name: str | None = None,
    ) -> Program:
        r"""Wrap a composite Skill topology into a single-node Program.

        This is the simplest bridge: the composite skill (e.g. a
        ``SkillSequential`` or ``SkillGraph``) becomes a single node.
        The resulting Program inherits the skill's parameters via
        component registration.

        For finer-grained node-per-skill Programs, use ``from_skills``
        with a skill list instead.

        Args:
            skill_composite: A composite skill (any ``Skill`` subclass).
            name: Optional program name.

        Returns:
            A single-node ``Program`` wrapping the composite.
        """
        topo_name = name or f"Program({skill_composite.spec.name})"
        program = cls(name=topo_name)
        program.add_node(skill_composite.spec.name, skill_composite)
        return program
