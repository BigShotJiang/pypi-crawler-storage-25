"""
---
title: Variable, Parameter, Component, TextState, Signature
summary: >
    Core computational primitives for the learn framework. Variable is the
    text container and computation graph node (torch.Tensor analog).
    Parameter is the learnable text variable (nn.Parameter analog).
    Component is the base module class (nn.Module analog). TextState is the
    structured agent context. Signature is the typed I/O specification.
---

# Core Computational Primitives

These five types form the foundation used by ALL teams:

* ``Variable`` — text container with gradient history (``torch.Tensor``)
* ``Parameter`` — learnable text variable with update/revert (``nn.Parameter``)
* ``Component`` — base container for parameters and sub-components (``nn.Module``)
* ``TextState`` — structured agent context (activation)
* ``Signature`` — declarative typed I/O specification
"""
from __future__ import annotations

import uuid
from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Iterator,
)

from learn.env.program.types import ParameterType

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# ===================================================================
# Variable — Computation Graph Node
# ===================================================================


class Variable:
    r"""
    <a id="Variable"></a>

    ## Variable

    A node in the textual computation graph. Holds a string ``data`` and,
    when ``requires_grad=True``, accumulates textual gradients during the
    backward pass.

    This is the textual analog of ``torch.Tensor``:

    | ``torch.Tensor`` | ``Variable`` |
    |-----------------|-------------|
    | Numeric value | ``data`` (str) |
    | ``.grad`` | ``.gradients`` (list of textual critiques) |
    | ``.grad_fn`` | ``.grad_fn`` (backward callable) |
    | ``.requires_grad`` | ``.requires_grad`` |
    | ``.backward()`` | ``.backward()`` |

    ### Key equation (TextGrad Eq. 3)

    $$\text{grad}(x) = \text{LLM}\bigl(\text{"How should } x \text{ change
    to improve the output?"}\bigr)$$
    """

    def __init__(
        self,
        data: str = "",
        *,
        role_description: str = "",
        requires_grad: bool = False,
        predecessors: list[Variable] | None = None,
    ) -> None:
        if predecessors is None:
            predecessors = []

        self.data: str = str(data)
        self.role_description: str = role_description
        self.requires_grad: bool = requires_grad

        # Computation graph edges
        self.predecessors: set[Variable] = set(predecessors)
        self.grad_fn: Callable[..., None] | None = None

        # Accumulated textual gradients
        self.gradients: list[Variable] = []

        # Optional context per gradient
        self.gradients_context: dict[Variable, str | None] = defaultdict(lambda: None)

        # Auto-install passthrough grad_fn when predecessors are provided
        # and requires_grad is True. This ensures backward() propagates
        # gradients to predecessors even without an explicit LLMCall.
        # Analogous to torch's identity grad_fn for leaf tensors.
        if self.predecessors and self.requires_grad and self.grad_fn is None:
            self._install_passthrough_grad_fn()

    # ------------------------------------------------------------------
    # Passthrough gradient function
    # ------------------------------------------------------------------

    def _install_passthrough_grad_fn(self) -> None:
        """Install a grad_fn that copies this variable's gradients to predecessors.

        Used when a Variable has predecessors but no explicit backward
        function (e.g., manually constructed ``pred_var`` with
        ``predecessors=agent.parameters()``). Without this, backward()
        stops here and gradients never reach the parameters.
        """
        var = self  # capture reference

        def _passthrough(**kwargs: Any) -> None:
            for pred in var.predecessors:
                if pred.requires_grad:
                    for g in var.gradients:
                        pred.gradients.append(g)

        from learn.optim.txt.autograd.function import BackwardContext

        self.grad_fn = BackwardContext(_passthrough)

    # ------------------------------------------------------------------
    # Backward pass
    # ------------------------------------------------------------------

    def backward(self, engine: EngineLM) -> None:
        r"""Trigger textual gradient computation through the graph.

        Performs a reverse topological traversal starting from this variable
        (typically a loss variable), calling ``grad_fn`` at each node.
        This is the textual analog of ``loss.backward()`` in PyTorch.

        Args:
            engine: the LLM used for gradient computation.
        """
        from learn.optim.txt.autograd.backward import backward

        backward(self, engine)

    def zero_grad(self) -> None:
        """Clear all accumulated gradients on this variable."""
        self.gradients = []
        self.gradients_context = defaultdict(lambda: None)

    # ------------------------------------------------------------------
    # Gradient management
    # ------------------------------------------------------------------

    def get_gradient_text(self) -> str:
        """Return all gradients concatenated as a single string."""
        if not self.gradients:
            return ""
        return "\n\n".join(g.data for g in self.gradients)

    def set_grad_fn(self, fn: Callable[..., None]) -> None:
        """Register the backward function for this variable."""
        self.grad_fn = fn

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        grad_count = len(self.gradients)
        preview = self.data[:60] + "…" if len(self.data) > 60 else self.data
        return (
            f"Variable(data={preview!r}, "
            f"role={self.role_description!r}, "
            f"grads={grad_count})"
        )

    def __str__(self) -> str:
        return self.data

    def __add__(self, other: Variable | str) -> Variable:
        """Concatenate two variables, tracking both as predecessors."""
        if isinstance(other, str):
            other = Variable(
                data=other,
                role_description="appended text",
                requires_grad=False,
            )

        predecessors: list[Variable] = []
        if self.requires_grad:
            predecessors.append(self)
        if other.requires_grad:
            predecessors.append(other)

        return Variable(
            data=self.data + other.data,
            role_description=(
                f"concatenation of [{self.role_description}] "
                f"and [{other.role_description}]"
            ),
            requires_grad=bool(predecessors),
            predecessors=predecessors,
        )


# ===================================================================
# Parameter — Learnable Text Variable
# ===================================================================


class Parameter(Variable):
    r"""
    <a id="Parameter"></a>

    ## Parameter

    A learnable text variable — the textual analog of ``nn.Parameter``.

    Adds to ``Variable``:

    * ``param_type`` — a ``ParameterType`` enum (PROMPT, DEMOS, INSTRUCTION, STRUCTURE)
    * ``_checkpoint`` — previous value for revert semantics
    * ``constraints`` — natural-language update constraints
    * ``requires_opt`` — whether the optimizer should propose updates

    | PyTorch | learn |
    |---------|-------|
    | ``nn.Parameter`` | ``Parameter`` |
    | ``requires_grad`` | ``requires_opt`` |
    | Weight snapshot | ``_checkpoint`` |
    """

    def __init__(
        self,
        data: str = "",
        *,
        param_type: ParameterType = ParameterType.PROMPT,
        role_description: str = "",
        requires_opt: bool = True,
        name: str | None = None,
        constraints: list[str] | None = None,
        instruction_to_optimizer: str | None = None,
        instruction_to_backward_engine: str | None = None,
    ) -> None:
        super().__init__(
            data=data,
            role_description=role_description,
            requires_grad=requires_opt,
        )

        self.id: str = str(uuid.uuid4())
        self.param_type: ParameterType = param_type
        self.requires_opt: bool = requires_opt
        self.constraints: list[str] = constraints or []

        # Human-readable name
        if name:
            self.name = name
        elif role_description:
            self.name = role_description.replace(" ", "_")[:30]
        else:
            self.name = f"param_{self.id[:8]}"

        # Optimizer-facing instructions
        self.instruction_to_optimizer: str | None = instruction_to_optimizer
        self.instruction_to_backward_engine: str | None = instruction_to_backward_engine

        # Checkpoint for revert semantics
        self._checkpoint: str | None = None

        # Gradient history for context-aware optimization
        self.gradient_history: list[Variable] = []

        # Proposed value (for propose → validate → commit/rollback)
        self._proposed: str | None = None

    # ------------------------------------------------------------------
    # Update / Revert semantics
    # ------------------------------------------------------------------

    def update(self, new_data: str) -> None:
        """Update the parameter's data, saving old value as checkpoint."""
        self._checkpoint = self.data
        self.data = str(new_data)

    def revert(self) -> None:
        """Revert to the checkpoint (undo the last update)."""
        if self._checkpoint is not None:
            self.data = self._checkpoint
            self._checkpoint = None

    def propose(self, new_data: str) -> None:
        """Tentative update — must be followed by commit() or rollback()."""
        self._checkpoint = self.data
        self._proposed = str(new_data)
        self.data = self._proposed

    def commit(self) -> None:
        """Accept the proposed value."""
        self._proposed = None
        # Keep checkpoint for potential future revert

    def rollback(self) -> None:
        """Reject the proposed value, restore checkpoint."""
        if self._checkpoint is not None:
            self.data = self._checkpoint
        self._proposed = None

    # ------------------------------------------------------------------
    # Gradient management
    # ------------------------------------------------------------------

    def archive_gradients(self) -> None:
        """Move current gradients into history and clear them."""
        self.gradient_history.extend(self.gradients)
        self.zero_grad()

    def reset_gradients(self) -> None:
        """Clear both current gradients and history."""
        self.zero_grad()
        self.gradient_history.clear()

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        preview = self.data[:60] + "…" if len(self.data) > 60 else self.data
        return (
            f"Parameter(name={self.name!r}, "
            f"type={self.param_type.name}, "
            f"data={preview!r}, "
            f"requires_opt={self.requires_opt})"
        )


# ===================================================================
# Component — Base Module Class (nn.Module analog)
# ===================================================================


class Component:
    r"""
    <a id="Component"></a>

    ## Component

    Base class for all framework components — the textual analog of
    ``nn.Module``.

    Uses ``__setattr__`` to automatically register child ``Component``
    instances and ``Parameter`` instances when assigned as attributes.

    | ``nn.Module`` | ``Component`` |
    |--------------|--------------|
    | ``self._modules`` | ``self._components`` |
    | ``self._parameters`` | ``self._parameters`` |
    | ``parameters()`` | ``parameters()`` |
    | ``train()`` / ``eval()`` | ``train()`` / ``eval()`` |
    | ``state_dict()`` | ``state_dict()`` |
    """

    _version: int = 1

    def __init__(self, name: str | None = None) -> None:
        object.__setattr__(self, "_components", OrderedDict())
        object.__setattr__(self, "_parameters", OrderedDict())
        object.__setattr__(self, "training", True)
        object.__setattr__(self, "name", name or self.__class__.__name__)

    # ------------------------------------------------------------------
    # Auto-registration via __setattr__
    # ------------------------------------------------------------------

    def __setattr__(self, name: str, value: Any) -> None:
        if isinstance(value, Parameter):
            self._parameters[name] = value
        elif isinstance(value, Component):
            self._components[name] = value
        object.__setattr__(self, name, value)

    # ------------------------------------------------------------------
    # Registration helpers
    # ------------------------------------------------------------------

    def register_parameter(self, name: str, param: Parameter) -> None:
        """Explicitly register a Parameter under the given name."""
        if not isinstance(param, Parameter):
            raise TypeError(f"Expected a Parameter, got {type(param).__name__}")
        self._parameters[name] = param
        object.__setattr__(self, name, param)

    def register_component(self, name: str, component: Component) -> None:
        """Explicitly register a child Component under the given name."""
        if not isinstance(component, Component):
            raise TypeError(f"Expected a Component, got {type(component).__name__}")
        self._components[name] = component
        object.__setattr__(self, name, component)

    # ------------------------------------------------------------------
    # Iteration over parameters and children
    # ------------------------------------------------------------------

    def parameters(self, recursive: bool = True) -> Iterator[Parameter]:
        """Yield all Parameters, optionally including those in children."""
        yield from self._parameters.values()
        if recursive:
            for child in self._components.values():
                yield from child.parameters(recursive=True)

    def named_parameters(
        self, prefix: str = "", recursive: bool = True
    ) -> Iterator[tuple[str, Parameter]]:
        """Yield ``(name, Parameter)`` pairs."""
        for name, param in self._parameters.items():
            full_name = f"{prefix}.{name}" if prefix else name
            yield full_name, param
        if recursive:
            for child_name, child in self._components.items():
                child_prefix = f"{prefix}.{child_name}" if prefix else child_name
                yield from child.named_parameters(prefix=child_prefix, recursive=True)

    def children(self) -> Iterator[Component]:
        """Yield immediate child Components."""
        yield from self._components.values()

    def named_children(self) -> Iterator[tuple[str, Component]]:
        """Yield ``(name, Component)`` pairs for immediate children."""
        yield from self._components.items()

    # ------------------------------------------------------------------
    # Train / eval mode
    # ------------------------------------------------------------------

    def train(self, mode: bool = True) -> Component:
        """Set this component and all children to training mode."""
        self.training = mode
        for child in self._components.values():
            child.train(mode)
        return self

    def eval(self) -> Component:
        """Set this component and all children to evaluation mode."""
        return self.train(False)

    # ------------------------------------------------------------------
    # State serialization
    # ------------------------------------------------------------------

    def state_dict(self) -> dict[str, Any]:
        """Return the component's state as a nested dictionary."""
        state: dict[str, Any] = {}
        for name, param in self._parameters.items():
            state[name] = param.data
        for name, child in self._components.items():
            state[name] = child.state_dict()
        return state

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore state from a dictionary produced by ``state_dict()``."""
        for name, value in state.items():
            if name in self._parameters:
                self._parameters[name].update(value)
            elif name in self._components:
                if isinstance(value, dict):
                    self._components[name].load_state_dict(value)

    # ------------------------------------------------------------------
    # Dunder methods
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        lines = [f"{self.__class__.__name__}("]
        for name, param in self._parameters.items():
            lines.append(f"  ({name}): {param!r}")
        for name, child in self._components.items():
            child_repr = repr(child).replace("\n", "\n  ")
            lines.append(f"  ({name}): {child_repr}")
        lines.append(")")
        return "\n".join(lines)


# ===================================================================
# TextState — Structured Agent Context
# ===================================================================


@dataclass
class TextState:
    r"""
    <a id="TextState"></a>

    ## TextState

    Structured context that flows through the agent pipeline — the
    textual analog of an activation tensor.

    Each agent's ``forward`` receives a ``TextState`` and returns a new
    ``TextState``.

    ### Fields

    * ``observation`` — the primary input text
    * ``scratchpad`` — intermediate reasoning or working notes
    * ``tool_results`` — structured results from tool calls
    * ``memory_context`` — retrieved memory relevant to current task
    * ``metadata`` — arbitrary key-value pairs
    """

    observation: str = ""
    scratchpad: str = ""
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    memory_context: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_prompt_str(self) -> str:
        """Render the state as a prompt-ready string."""
        parts: list[str] = []
        if self.observation:
            parts.append(f"<OBSERVATION>\n{self.observation}\n</OBSERVATION>")
        if self.scratchpad:
            parts.append(f"<SCRATCHPAD>\n{self.scratchpad}\n</SCRATCHPAD>")
        if self.tool_results:
            tool_strs = "\n".join(str(r) for r in self.tool_results)
            parts.append(f"<TOOL_RESULTS>\n{tool_strs}\n</TOOL_RESULTS>")
        if self.memory_context:
            mem_str = "\n".join(self.memory_context)
            parts.append(f"<MEMORY>\n{mem_str}\n</MEMORY>")
        return "\n\n".join(parts) if parts else ""

    def update(self, **kwargs: Any) -> TextState:
        """Return a new ``TextState`` with the specified fields replaced."""
        current = {
            "observation": self.observation,
            "scratchpad": self.scratchpad,
            "tool_results": list(self.tool_results),
            "memory_context": list(self.memory_context),
            "metadata": dict(self.metadata),
        }
        current.update(kwargs)
        return TextState(**current)

    @staticmethod
    def merge(*states: TextState) -> TextState:
        """Merge multiple TextStates, concatenating text fields."""
        observations = [s.observation for s in states if s.observation]
        scratchpads = [s.scratchpad for s in states if s.scratchpad]
        tool_results: list[dict[str, Any]] = []
        memory_context: list[str] = []
        metadata: dict[str, Any] = {}
        for s in states:
            tool_results.extend(s.tool_results)
            memory_context.extend(s.memory_context)
            metadata.update(s.metadata)
        return TextState(
            observation="\n\n".join(observations),
            scratchpad="\n\n".join(scratchpads),
            tool_results=tool_results,
            memory_context=memory_context,
            metadata=metadata,
        )


# ===================================================================
# Signature — Typed I/O Specification
# ===================================================================


@dataclass
class Signature:
    r"""
    <a id="Signature"></a>

    ## Signature

    Declarative typed I/O specification for agents and operators.
    Enables type-checking at edge boundaries.

    ### Fields

    * ``inputs`` — mapping of input field names to expected types
    * ``outputs`` — mapping of output field names to expected types
    * ``description`` — human-readable description
    """

    inputs: dict[str, type] = field(default_factory=dict)
    outputs: dict[str, type] = field(default_factory=dict)
    description: str = ""

    def check_input(self, state: TextState) -> bool:
        """Validate that the TextState satisfies input requirements."""
        for field_name in self.inputs:
            if not getattr(state, field_name, None):
                return False
        return True
