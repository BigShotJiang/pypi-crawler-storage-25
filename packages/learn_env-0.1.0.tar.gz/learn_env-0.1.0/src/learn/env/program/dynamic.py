"""
---
title: Dynamic Program Variants
summary: >
    Program subclasses that modify topology at runtime, iterate until
    convergence, or conditionally select sub-programs.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.env.program.program import Program
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    from learn.agent.base import Agent


class DynamicProgram(Program):
    """Program that can modify its topology at runtime.

    Nodes can be added or removed between executions, allowing the
    graph structure to evolve during training or inference.
    """

    def add_node_at_runtime(self, name: str, agent: Agent) -> None:
        """Add a node without validation against existing edges."""
        if name in self._nodes:
            raise ValueError(f"Node {name!r} already exists.")
        self._nodes[name] = agent
        self.register_component(name, agent)

    def remove_node(self, name: str) -> None:
        """Remove a node and all its connected edges."""
        if name not in self._nodes:
            raise ValueError(f"Node {name!r} not found.")
        del self._nodes[name]
        self._edges = [
            e for e in self._edges
            if e.source != name and e.target != name
        ]

    def execute(self, input: TextState, **kwargs: Any) -> TextState:
        """Execute after dynamic adjustments."""
        return self(input, **kwargs)


class IterativeProgram(Program):
    """Repeats execution until convergence or max iterations.

    The ``convergence_fn`` receives ``(previous_state, current_state)``
    and returns ``True`` when the loop should stop early.
    """

    def __init__(
        self,
        max_iterations: int = 3,
        convergence_fn: Optional[Callable[[TextState, TextState], bool]] = None,
        name: str | None = None,
    ) -> None:
        super().__init__(name=name)
        self.max_iterations = max_iterations
        self.convergence_fn = convergence_fn

    def execute(self, input: TextState, **kwargs: Any) -> TextState:
        """Run the program iteratively."""
        state = input
        for _ in range(self.max_iterations):
            output = self(state, **kwargs)
            if self.convergence_fn and self.convergence_fn(state, output):
                return output
            state = output
        return state


class ConditionalProgram(Program):
    """Selects a sub-program based on an input condition.

    The ``selector_fn`` maps the input to a branch key. If no selector
    is provided, the ``"default"`` branch is used.
    """

    def __init__(
        self,
        branches: dict[str, Program],
        selector_fn: Optional[Callable[[TextState], str]] = None,
        name: str | None = None,
    ) -> None:
        super().__init__(name=name)
        self.branches = branches
        self.selector_fn = selector_fn

    def execute(self, input: TextState, **kwargs: Any) -> TextState:
        """Route input to the selected branch program."""
        branch_key = self.selector_fn(input) if self.selector_fn else "default"
        program = self.branches.get(
            branch_key, next(iter(self.branches.values()))
        )
        return program(input, **kwargs)
