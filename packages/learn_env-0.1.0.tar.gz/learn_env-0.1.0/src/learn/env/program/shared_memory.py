"""
---
title: SharedMemory — Key-Value Store for Inter-Agent Communication
summary: >
    A simple key-value store enabling agents within a Program to share
    state beyond the primary TextState data flow.
---
"""
from __future__ import annotations

from typing import Any


class SharedMemory:
    """Key-value store for inter-agent communication within a Program.

    ```python
    mem = SharedMemory()
    mem.write("context", "important background info")
    value = mem.read("context")
    ```
    """

    def __init__(self) -> None:
        self._store: dict[str, Any] = {}

    def write(self, key: str, value: Any) -> None:
        """Write a value to the shared memory."""
        self._store[key] = value

    def read(self, key: str, default: Any = None) -> Any:
        """Read a value from the shared memory."""
        return self._store.get(key, default)

    def has(self, key: str) -> bool:
        """Check if a key exists in the shared memory."""
        return key in self._store

    def delete(self, key: str) -> None:
        """Remove a key from the shared memory."""
        self._store.pop(key, None)

    def clear(self) -> None:
        """Clear all entries."""
        self._store.clear()

    def keys(self) -> list[str]:
        """Return all keys."""
        return list(self._store.keys())

    def __repr__(self) -> str:
        return f"SharedMemory(keys={self.keys()})"
