"""
---
title: CodeSandbox — Safe Code Execution
summary: >
    Sandboxed Python code execution with namespace persistence,
    output capture, and safety controls. Addresses API Issue #25.
---

# Code Sandbox

Provides safe code execution for agents that need to run Python code
(ReTool REPL, MLGym commands, STE API simulation).
"""
from __future__ import annotations

import contextlib
import io
from dataclasses import dataclass
from typing import Any


@dataclass
class ExecutionResult:
    """Result of a sandboxed code execution."""

    stdout: str = ""
    stderr: str = ""
    return_value: Any = None
    success: bool = True
    error_type: str = ""
    error_message: str = ""

    @property
    def output(self) -> str:
        """Combined stdout output."""
        return self.stdout.strip()


class CodeSandbox:
    r"""
    <a id="CodeSandbox"></a>

    ## CodeSandbox

    Safe Python code execution with persistent namespace.

    ```python
    sandbox = CodeSandbox()
    result = sandbox.execute("x = 2 + 2")
    assert result.success
    result = sandbox.execute("print(x)")
    assert result.stdout.strip() == "4"
    ```

    Supports:
    - Persistent namespace across calls
    - stdout/stderr capture
    - Configurable allowed builtins
    - Timeout (via signal on Unix)
    - Error isolation
    """

    # Safe subset of builtins — excludes dangerous functions
    SAFE_BUILTINS = {
        "abs", "all", "any", "bin", "bool", "chr", "dict", "dir",
        "divmod", "enumerate", "filter", "float", "format", "frozenset",
        "getattr", "hasattr", "hash", "hex", "int", "isinstance",
        "issubclass", "iter", "len", "list", "map", "max", "min", "next",
        "oct", "ord", "pow", "print", "range", "repr", "reversed",
        "round", "set", "slice", "sorted", "str", "sum", "tuple", "type",
        "zip", "True", "False", "None",
    }

    def __init__(
        self,
        allowed_builtins: set[str] | None = None,
        max_output_chars: int = 10_000,
        restrict_builtins: bool = False,
    ) -> None:
        """Initialize the sandbox.

        Args:
            allowed_builtins: Set of allowed builtin names. If None and
                restrict_builtins=True, uses SAFE_BUILTINS.
            max_output_chars: Max characters captured from stdout/stderr.
            restrict_builtins: If True, restricts available builtins.
        """
        import builtins

        self._namespace: dict[str, Any] = {}
        self._max_output = max_output_chars

        if restrict_builtins:
            allowed = allowed_builtins or self.SAFE_BUILTINS
            safe_b = {
                k: getattr(builtins, k)
                for k in allowed
                if hasattr(builtins, k)
            }
            safe_b["__import__"] = _restricted_import
            self._namespace["__builtins__"] = safe_b
        else:
            self._namespace["__builtins__"] = __builtins__

    def execute(self, code: str) -> ExecutionResult:
        """Execute Python code in the sandbox.

        Args:
            code: Python code string to execute.

        Returns:
            ExecutionResult with stdout, stderr, success status.
        """
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()

        try:
            with contextlib.redirect_stdout(stdout_capture), \
                 contextlib.redirect_stderr(stderr_capture):

                # Try exec for statements, eval for expressions
                try:
                    # First try as expression (returns value)
                    result = eval(code, self._namespace)
                    return ExecutionResult(
                        stdout=stdout_capture.getvalue()[:self._max_output],
                        stderr=stderr_capture.getvalue()[:self._max_output],
                        return_value=result,
                        success=True,
                    )
                except SyntaxError:
                    # Fall back to exec for statements
                    exec(code, self._namespace)  # noqa: S102
                    return ExecutionResult(
                        stdout=stdout_capture.getvalue()[:self._max_output],
                        stderr=stderr_capture.getvalue()[:self._max_output],
                        success=True,
                    )
        except Exception as e:
            return ExecutionResult(
                stdout=stdout_capture.getvalue()[:self._max_output],
                stderr=stderr_capture.getvalue()[:self._max_output],
                success=False,
                error_type=type(e).__name__,
                error_message=str(e),
            )

    def reset(self) -> None:
        """Clear the namespace."""
        builtins_backup = self._namespace.get("__builtins__")
        self._namespace.clear()
        if builtins_backup is not None:
            self._namespace["__builtins__"] = builtins_backup

    def get_variable(self, name: str) -> Any:
        """Get a variable from the namespace."""
        return self._namespace.get(name)

    def set_variable(self, name: str, value: Any) -> None:
        """Set a variable in the namespace."""
        self._namespace[name] = value

    @property
    def namespace_keys(self) -> list[str]:
        """List non-dunder variable names in the namespace."""
        return [k for k in self._namespace if not k.startswith("__")]


# Safe import whitelist
_ALLOWED_MODULES = {
    "math", "statistics", "collections", "itertools", "functools",
    "operator", "json", "re", "string", "textwrap", "datetime",
    "random", "copy", "dataclasses", "typing", "enum",
}


def _restricted_import(name: str, *args: Any, **kwargs: Any) -> Any:
    """Import restriction — only allows whitelisted modules."""
    if name not in _ALLOWED_MODULES:
        raise ImportError(
            f"Import of '{name}' is not allowed in the sandbox. "
            f"Allowed: {', '.join(sorted(_ALLOWED_MODULES))}"
        )
    return __import__(name, *args, **kwargs)
