"""
---
title: Environment — Training Context Manager
summary: >
    High-level context manager that ties together training components
    (engine, cost tracking, experiment tracking).
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.env.management.cost import CostTracker
from learn.env.management.tracker import ExperimentTracker

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Environment:
    """Training environment context manager.

    ```python
    with Environment(engine=engine, budget=5.0) as env:
        trainer = Trainer(
            component=agent,
            optimizer=optimizer,
            predict_fn=predict_fn,
        )
        result = trainer.fit(train_data)
    ```
    """

    def __init__(
        self,
        engine: EngineLM | None = None,
        experiment_name: str = "default",
        budget: float | None = None,
    ) -> None:
        self.engine = engine
        self.tracker = ExperimentTracker(experiment_name=experiment_name)
        self.cost_tracker = CostTracker(budget=budget)

    def __enter__(self) -> Environment:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        pass

    def __repr__(self) -> str:
        return (
            f"Environment(experiment={self.tracker.experiment_name!r}, "
            f"cost={self.cost_tracker.total_cost:.4f})"
        )
