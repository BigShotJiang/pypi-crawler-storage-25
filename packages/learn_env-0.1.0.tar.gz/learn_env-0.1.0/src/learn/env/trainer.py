"""
---
title: Trainer — Training Loop Orchestrator
summary: >
    PyTorch-style training loop that ties together a program/agent,
    optimizer, loss function, and benchmark evaluation.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

from learn.env.management.callbacks import BaseCallback, CallbackList
from learn.env.management.tracker import ExperimentTracker

if TYPE_CHECKING:
    from learn.benchmark.eval.scoring import ScoringFunction
    from learn.benchmark.task.sample import AgentDataset
    from learn.env.engine.base import EngineLM
    from learn.env.program.variable import Component
    from learn.optim.base import Optimizer


@dataclass
class TrainResult:
    """Result of a training run."""

    best_score: float = 0.0
    best_step: int = 0
    history: list[dict[str, Any]] = field(default_factory=list)
    tracker: ExperimentTracker | None = None


class Trainer:
    """Orchestrates the full training loop.

    ```python
    trainer = Trainer(
        component=agent,
        optimizer=tgd,
        predict_fn=lambda sample: agent(sample.input),
        loss_fn=text_loss,
        backward_engine=engine,
    )
    result = trainer.fit(
        train_data=train_dataset,
        val_data=val_dataset,
        scorer=exact_match,
        n_steps=10,
        batch_size=4,
    )
    ```
    """

    def __init__(
        self,
        component: Component,
        optimizer: Optimizer,
        predict_fn: Callable,
        loss_fn: Callable | None = None,
        backward_engine: EngineLM | None = None,
        callbacks: list[BaseCallback] | None = None,
        experiment_name: str = "default",
        backward_condition: Callable[[Any, float], bool] | None = None,
        score_fn: Callable[[Any, str], float] | None = None,
    ) -> None:
        self.component = component
        self.optimizer = optimizer
        self.predict_fn = predict_fn
        self.loss_fn = loss_fn
        self.backward_engine = backward_engine
        self.callback_list = CallbackList(callbacks)
        self.tracker = ExperimentTracker(experiment_name=experiment_name)
        # Optional: only run backward when this returns True.
        # Signature: (prediction, score) → bool. Enables error-selective
        # backward (AdalFlow-style: only backprop on errors).
        self.backward_condition = backward_condition
        # Optional: score function for score-based optimizers (OPRO, MIPROv2).
        # When set, the trainer calls optimizer.record(score) before step().
        # Signature: (prediction, expected_output) → float
        self.score_fn = score_fn

    def fit(
        self,
        train_data: AgentDataset,
        val_data: AgentDataset | None = None,
        scorer: ScoringFunction | None = None,
        n_steps: int = 10,
        batch_size: int = 1,
    ) -> TrainResult:
        """Run the training loop.

        Each step:
            1. Sample a batch from train_data
            2. Forward pass (predict_fn on each sample)
            3. Compute loss (loss_fn)
            4. Backward pass (if backward_engine set)
            5. Optimizer step
            6. Evaluate on val_data (if provided)
        """
        result = TrainResult(tracker=self.tracker)
        best_state: dict[str, Any] | None = None

        locals_ = {"trainer": self, "result": result, "n_steps": n_steps}
        self.callback_list.on_optimization_start(locals_)

        self.component.train()

        for step in range(n_steps):
            locals_["step"] = step
            self.callback_list.on_iteration_start(locals_)

            # --- Batch sampling ---
            batch = train_data.subsample(batch_size)

            # --- Forward + loss on batch ---
            total_loss_value = 0.0
            total_score = 0.0
            loss_var = None
            should_backward = True
            for sample in batch:
                prediction = self.predict_fn(sample)

                # Score-based mode: compute score and record
                if self.score_fn is not None:
                    sample_score = self.score_fn(
                        prediction, sample.expected_output,
                    )
                    total_score += sample_score

                    # Check backward condition (error-selective)
                    if self.backward_condition is not None:
                        if not self.backward_condition(prediction, sample_score):
                            should_backward = False

                    # Record score if optimizer supports it
                    if hasattr(self.optimizer, "record"):
                        self.optimizer.record(sample_score)

                if self.loss_fn is not None:
                    loss_var = self.loss_fn(prediction, sample.expected_output)
                    if hasattr(loss_var, "data"):
                        try:
                            total_loss_value += float(loss_var.data)
                        except (ValueError, TypeError):
                            pass

            # --- Backward ---
            if (
                loss_var is not None
                and self.backward_engine is not None
                and should_backward
            ):
                if hasattr(loss_var, "backward"):
                    loss_var.backward(self.backward_engine)

            # --- Optimizer step ---
            self.optimizer.step()
            self.optimizer.zero_grad()

            avg_loss = total_loss_value / max(len(batch), 1)
            self.tracker.log("train_loss", avg_loss, step=step)

            # --- Callbacks on_step ---
            locals_["loss"] = avg_loss
            should_continue = self.callback_list.on_step(locals_)

            # --- Validation ---
            val_score: float | None = None
            if val_data is not None and scorer is not None:
                val_score = self._evaluate(val_data, scorer)
                self.tracker.log("val_score", val_score, step=step)
                locals_["val_score"] = val_score
                self.callback_list.on_evaluation_complete(locals_)

                if val_score > result.best_score:
                    result.best_score = val_score
                    result.best_step = step
                    best_state = self.component.state_dict()

            result.history.append({
                "step": step,
                "train_loss": avg_loss,
                "val_score": val_score,
            })

            self.callback_list.on_iteration_end(locals_)

            if not should_continue:
                break

        # Restore best state
        if best_state is not None:
            self.component.load_state_dict(best_state)

        self.component.eval()
        self.callback_list.on_optimization_end(locals_)

        return result

    def _evaluate(
        self,
        dataset: AgentDataset,
        scorer: ScoringFunction,
    ) -> float:
        """Evaluate the component on a dataset."""
        self.component.eval()
        predictions = [self.predict_fn(sample) for sample in dataset]
        expected = [sample.expected_output for sample in dataset]
        stats = scorer.batch_score(predictions, expected)
        self.component.train()
        return stats["mean"]
