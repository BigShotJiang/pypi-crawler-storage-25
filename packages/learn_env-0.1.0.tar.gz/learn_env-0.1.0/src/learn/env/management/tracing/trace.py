"""
---
title: Trace — Workflow-Level Trace Container
summary: >
    Groups related Spans into a single trace representing an entire
    workflow execution (e.g., one training step, one agent pipeline run).
    Implements context manager protocol for automatic scope management.
---

# Trace

A Trace is a collection of Spans representing one logical workflow.
It automatically registers itself as the current trace via ContextVar
when used as a context manager:

```python
from learn.env.management.tracing import Trace, SpanKind

with Trace("training_step") as trace:
    with trace.start_span("forward", SpanKind.AGENT) as span:
        result = agent(input_data)
    with trace.start_span("backward", SpanKind.ENGINE) as span:
        loss.backward(engine)

print(trace.summary())
```
"""
from __future__ import annotations

import time
import uuid
from typing import Any

from learn.env.management.tracing.scope import (
    get_current_trace,
    set_current_trace,
)
from learn.env.management.tracing.span import Span, SpanKind


class Trace:
    """Container for a group of related Spans.

    Attributes:
        trace_id: Unique identifier for this trace.
        name: Human-readable name (e.g., "training_step_5").
        spans: Ordered list of spans in this trace.
        start_time: When the trace was started.
        end_time: When the trace was ended.
        metadata: Free-form metadata dictionary.
    """

    def __init__(self, name: str = "unnamed") -> None:
        self.trace_id: str = uuid.uuid4().hex[:16]
        self.name = name
        self.spans: list[Span] = []
        self.start_time: float = 0.0
        self.end_time: float = 0.0
        self.metadata: dict[str, Any] = {}
        self._previous_trace: Trace | None = None

    @property
    def duration_ms(self) -> float:
        """Total trace duration in milliseconds."""
        if self.end_time > 0:
            return (self.end_time - self.start_time) * 1000.0
        return 0.0

    def start_span(
        self,
        name: str,
        kind: SpanKind = SpanKind.OTHER,
        parent_id: str | None = None,
    ) -> Span:
        """Create and register a new Span within this trace.

        The span should be used as a context manager.

        Args:
            name: Human-readable span name.
            kind: Category of the operation.
            parent_id: Optional parent span ID for nesting.

        Returns:
            A new Span instance (not yet started).
        """
        span = Span(name=name, kind=kind, parent_id=parent_id)
        self.spans.append(span)
        return span

    def summary(self) -> dict[str, Any]:
        """Return a summary of the trace and its spans."""
        return {
            "trace_id": self.trace_id,
            "name": self.name,
            "duration_ms": round(self.duration_ms, 2),
            "num_spans": len(self.spans),
            "spans": [s.to_dict() for s in self.spans],
            "metadata": self.metadata,
        }

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full trace for export."""
        return self.summary()

    def __enter__(self) -> Trace:
        self.start_time = time.perf_counter()
        # Save and replace the current trace context
        self._previous_trace = get_current_trace()
        set_current_trace(self)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.end_time = time.perf_counter()
        # Restore previous trace context
        set_current_trace(self._previous_trace)

    def __repr__(self) -> str:
        return (
            f"Trace({self.name!r}, spans={len(self.spans)}, "
            f"duration={self.duration_ms:.1f}ms)"
        )
