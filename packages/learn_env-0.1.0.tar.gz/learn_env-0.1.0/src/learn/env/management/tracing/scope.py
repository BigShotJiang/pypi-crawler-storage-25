"""
---
title: Scope — ContextVar-Based Trace Scope Management
summary: >
    Uses Python ContextVar to track the current active Trace across
    function calls without explicit passing. Thread-safe by design.
---

# Scope

This module manages the implicit "current trace" context using
``contextvars.ContextVar``. Any code that creates a ``Trace`` context
manager automatically becomes the active trace for the scope.

This mirrors OpenTelemetry's context propagation pattern but is
much simpler — no baggage, no W3C headers, just a stack of traces.
"""
from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from learn.env.management.tracing.trace import Trace

_current_trace: ContextVar[Trace | None] = ContextVar(
    "current_trace", default=None
)


def get_current_trace() -> Trace | None:
    """Return the currently active Trace, or None if outside a trace."""
    return _current_trace.get()


def set_current_trace(trace: Trace | None) -> None:
    """Set the active trace (used internally by Trace.__enter__)."""
    _current_trace.set(trace)
