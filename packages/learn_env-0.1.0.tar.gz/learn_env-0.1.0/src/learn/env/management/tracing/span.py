"""
---
title: Span — Operation-Level Trace Unit
summary: >
    Represents a single operation (engine call, agent invocation, etc.)
    within a Trace. Records timing, metadata, and optional parent-child
    relationships.
---

# Span

Each Span captures one logical operation:

| Field | Description |
|-------|-------------|
| ``name`` | Human-readable operation name |
| ``kind`` | SpanKind enum (ENGINE, AGENT, OPTIMIZER, OTHER) |
| ``start_time`` | Wall-clock start (perf_counter) |
| ``end_time`` | Wall-clock end |
| ``attributes`` | Free-form metadata dict |
| ``parent_id`` | ID of parent span (for nesting) |

Spans are created by ``Trace.start_span()`` and should be used as
context managers:

```python
with trace.start_span("engine_call", kind=SpanKind.ENGINE) as span:
    result = engine.generate(prompt)
    span.set_attribute("tokens", engine.usage.total_tokens)
```
"""
from __future__ import annotations

import time
import uuid
from enum import Enum
from typing import Any


class SpanKind(Enum):
    """Category of operation a span represents."""

    ENGINE = "engine"
    AGENT = "agent"
    OPTIMIZER = "optimizer"
    PROGRAM = "program"
    OTHER = "other"


class Span:
    """A single timed operation within a Trace.

    Should be used as a context manager to automatically record
    start/end times.

    Attributes:
        span_id: Unique identifier.
        name: Human-readable name.
        kind: Category of the operation.
        start_time: Start timestamp (seconds, perf_counter).
        end_time: End timestamp (seconds, perf_counter).
        attributes: Metadata dictionary.
        parent_id: ID of the parent span, if nested.
        error: Exception that occurred during the span, if any.
    """

    def __init__(
        self,
        name: str,
        kind: SpanKind = SpanKind.OTHER,
        parent_id: str | None = None,
    ) -> None:
        self.span_id: str = uuid.uuid4().hex[:16]
        self.name = name
        self.kind = kind
        self.start_time: float = 0.0
        self.end_time: float = 0.0
        self.attributes: dict[str, Any] = {}
        self.parent_id = parent_id
        self.error: BaseException | None = None

    @property
    def duration_ms(self) -> float:
        """Duration in milliseconds (0 if not yet completed)."""
        if self.end_time > 0:
            return (self.end_time - self.start_time) * 1000.0
        return 0.0

    def set_attribute(self, key: str, value: Any) -> None:
        """Record a metadata attribute on this span."""
        self.attributes[key] = value

    def to_dict(self) -> dict[str, Any]:
        """Serialize span to a dictionary for export."""
        d: dict[str, Any] = {
            "span_id": self.span_id,
            "name": self.name,
            "kind": self.kind.value,
            "duration_ms": round(self.duration_ms, 2),
            "attributes": self.attributes,
        }
        if self.parent_id:
            d["parent_id"] = self.parent_id
        if self.error:
            d["error"] = str(self.error)
        return d

    def __enter__(self) -> Span:
        self.start_time = time.perf_counter()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.end_time = time.perf_counter()
        if exc_val is not None:
            self.error = exc_val

    def __repr__(self) -> str:
        return (
            f"Span({self.name!r}, kind={self.kind.value}, "
            f"duration={self.duration_ms:.1f}ms)"
        )
