"""
---
title: learn.env.management.tracing — Distributed Tracing
summary: >
    Lightweight tracing system for LLM workflows. Provides Trace (workflow-level)
    and Span (operation-level) abstractions with ContextVar-based scope management.
    Inspired by AdalFlow's GeneratorCallTrace and OpenTelemetry concepts.
---
"""
from learn.env.management.tracing.scope import get_current_trace, set_current_trace
from learn.env.management.tracing.span import Span, SpanKind
from learn.env.management.tracing.trace import Trace

__all__ = [
    "Span",
    "SpanKind",
    "Trace",
    "get_current_trace",
    "set_current_trace",
]
