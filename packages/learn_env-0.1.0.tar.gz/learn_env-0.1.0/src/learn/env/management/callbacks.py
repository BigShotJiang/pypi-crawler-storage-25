"""
---
title: Callbacks — Training & Engine Lifecycle Hooks
summary: >
    SB3-style callback system for the training loop and engine calls.
    Callbacks observe and can control training progress. Engine-level
    and agent-level hooks enable fine-grained monitoring.
---

# Callbacks

Two tiers of hooks:

1. **Training hooks** (original) — optimization lifecycle:
   ``on_optimization_start/end``, ``on_iteration_start/end``,
   ``on_step``, ``on_evaluation_complete``

2. **Engine hooks** (new) — per-API-call observability:
   ``on_engine_call_start``, ``on_engine_call_end``, ``on_engine_error``

3. **Agent hooks** (new) — per-agent-invocation observability:
   ``on_agent_start``, ``on_agent_end``

All new hooks have no-op defaults for full backward compatibility.
"""
from __future__ import annotations

from abc import ABC
from typing import Any


class BaseCallback(ABC):
    """Base class for training and engine callbacks.

    Override any hook method to observe or control the lifecycle.
    Return ``False`` from ``on_step`` to request early stopping.
    """

    # --- Training lifecycle hooks (original) ---

    def on_optimization_start(self, locals_: dict[str, Any]) -> None:
        """Called once at the start of optimization."""

    def on_iteration_start(self, locals_: dict[str, Any]) -> None:
        """Called at the start of each iteration."""

    def on_step(self, locals_: dict[str, Any]) -> bool:
        """Called after each optimization step. Return False to stop."""
        return True

    def on_evaluation_complete(self, locals_: dict[str, Any]) -> None:
        """Called after each evaluation."""

    def on_iteration_end(self, locals_: dict[str, Any]) -> None:
        """Called at the end of each iteration."""

    def on_optimization_end(self, locals_: dict[str, Any]) -> None:
        """Called once at the end of optimization."""

    # --- Engine-level hooks ---

    def on_engine_call_start(
        self,
        engine: Any,
        prompt: str,
        system_prompt: str | None,
        kwargs: dict[str, Any],
    ) -> None:
        """Called before each engine generate() call."""

    def on_engine_call_end(
        self,
        engine: Any,
        result: str,
        usage: Any | None,
        latency_ms: float,
    ) -> None:
        """Called after each engine generate() call completes.

        Args:
            engine: The engine instance that was called.
            result: The generated text.
            usage: UsageStats from the call, if available.
            latency_ms: Wall-clock time in milliseconds.
        """

    def on_engine_error(
        self,
        engine: Any,
        error: BaseException,
    ) -> None:
        """Called when an engine generate() call raises an exception."""

    # --- Agent-level hooks ---

    def on_agent_start(
        self,
        agent: Any,
        inputs: dict[str, Any],
    ) -> None:
        """Called before an agent processes inputs."""

    def on_agent_end(
        self,
        agent: Any,
        outputs: dict[str, Any],
    ) -> None:
        """Called after an agent finishes processing."""


class CallbackList(BaseCallback):
    """Composite callback that delegates to a list of callbacks."""

    def __init__(self, callbacks: list[BaseCallback] | None = None) -> None:
        self.callbacks: list[BaseCallback] = callbacks or []

    # --- Training hooks ---

    def on_optimization_start(self, locals_: dict[str, Any]) -> None:
        for cb in self.callbacks:
            cb.on_optimization_start(locals_)

    def on_iteration_start(self, locals_: dict[str, Any]) -> None:
        for cb in self.callbacks:
            cb.on_iteration_start(locals_)

    def on_step(self, locals_: dict[str, Any]) -> bool:
        return all(cb.on_step(locals_) for cb in self.callbacks)

    def on_evaluation_complete(self, locals_: dict[str, Any]) -> None:
        for cb in self.callbacks:
            cb.on_evaluation_complete(locals_)

    def on_iteration_end(self, locals_: dict[str, Any]) -> None:
        for cb in self.callbacks:
            cb.on_iteration_end(locals_)

    def on_optimization_end(self, locals_: dict[str, Any]) -> None:
        for cb in self.callbacks:
            cb.on_optimization_end(locals_)

    # --- Engine hooks ---

    def on_engine_call_start(
        self,
        engine: Any,
        prompt: str,
        system_prompt: str | None,
        kwargs: dict[str, Any],
    ) -> None:
        for cb in self.callbacks:
            cb.on_engine_call_start(engine, prompt, system_prompt, kwargs)

    def on_engine_call_end(
        self,
        engine: Any,
        result: str,
        usage: Any | None,
        latency_ms: float,
    ) -> None:
        for cb in self.callbacks:
            cb.on_engine_call_end(engine, result, usage, latency_ms)

    def on_engine_error(
        self,
        engine: Any,
        error: BaseException,
    ) -> None:
        for cb in self.callbacks:
            cb.on_engine_error(engine, error)

    # --- Agent hooks ---

    def on_agent_start(
        self,
        agent: Any,
        inputs: dict[str, Any],
    ) -> None:
        for cb in self.callbacks:
            cb.on_agent_start(agent, inputs)

    def on_agent_end(
        self,
        agent: Any,
        outputs: dict[str, Any],
    ) -> None:
        for cb in self.callbacks:
            cb.on_agent_end(agent, outputs)
