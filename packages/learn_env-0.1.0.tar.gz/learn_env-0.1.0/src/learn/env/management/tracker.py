"""
---
title: ExperimentTracker — Metric Logging
summary: >
    Simple in-memory metric tracker for experiments. Logs scalar metrics
    per step and provides history retrieval.
---
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any


class ExperimentTracker:
    """In-memory metric tracker for training experiments.

    ```python
    tracker = ExperimentTracker(experiment_name="exp1")
    tracker.log("loss", 0.5, step=1)
    tracker.log("accuracy", 0.8, step=1)
    history = tracker.get_history("loss")
    ```
    """

    def __init__(self, experiment_name: str = "default") -> None:
        self.experiment_name = experiment_name
        self._metrics: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self._step: int = 0

    def log(self, name: str, value: float, step: int | None = None) -> None:
        """Log a scalar metric value."""
        if step is not None:
            self._step = step
        self._metrics[name].append({"step": self._step, "value": value})

    def get_history(self, name: str) -> list[dict[str, Any]]:
        """Return the full history of a metric."""
        return list(self._metrics.get(name, []))

    def get_latest(self, name: str) -> float | None:
        """Return the most recent value of a metric."""
        history = self._metrics.get(name)
        if history:
            return history[-1]["value"]
        return None

    def get_best(self, name: str, mode: str = "max") -> float | None:
        """Return the best value of a metric.

        Args:
            name: Metric name.
            mode: "max" or "min".
        """
        history = self._metrics.get(name)
        if not history:
            return None
        values = [entry["value"] for entry in history]
        return max(values) if mode == "max" else min(values)

    def summary(self) -> dict[str, Any]:
        """Return a summary of all tracked metrics."""
        result: dict[str, Any] = {"experiment": self.experiment_name}
        for name, history in self._metrics.items():
            values = [e["value"] for e in history]
            result[name] = {
                "latest": values[-1] if values else None,
                "best": max(values) if values else None,
                "count": len(values),
            }
        return result

    def __repr__(self) -> str:
        return f"ExperimentTracker({self.experiment_name!r}, metrics={list(self._metrics.keys())})"
