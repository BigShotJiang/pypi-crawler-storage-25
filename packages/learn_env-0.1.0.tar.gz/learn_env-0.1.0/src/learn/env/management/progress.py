"""
---
title: ProgressMonitor — Training Progress Tracking
summary: >
    Lightweight progress monitor with optional console output.
    Tracks step count, computes fractional progress, and logs messages.
---
"""
from __future__ import annotations

import sys
from typing import Any


class ProgressMonitor:
    """Track training progress with optional console output.

    ```python
    monitor = ProgressMonitor(total_steps=100, verbose=True)
    for batch in data:
        train(batch)
        monitor.step(metrics={"loss": 0.5})
    ```
    """

    def __init__(self, total_steps: int, verbose: bool = True) -> None:
        self.total_steps = total_steps
        self.verbose = verbose
        self._current = 0
        self._history: list[dict[str, Any]] = []

    def step(self, metrics: dict[str, Any] | None = None) -> None:
        """Advance by one step and optionally record metrics."""
        self._current += 1
        entry = {"step": self._current}
        if metrics:
            entry.update(metrics)
        self._history.append(entry)
        if self.verbose:
            pct = self.progress * 100
            msg = f"[{self._current}/{self.total_steps}] {pct:.1f}%"
            if metrics:
                parts = [f"{k}={v}" for k, v in metrics.items()]
                msg += " " + " ".join(parts)
            print(msg, file=sys.stderr)

    def log(self, message: str) -> None:
        """Print a log message if verbose is enabled."""
        if self.verbose:
            print(message, file=sys.stderr)

    @property
    def progress(self) -> float:
        """Fractional progress from 0.0 to 1.0."""
        if self.total_steps <= 0:
            return 1.0
        return min(self._current / self.total_steps, 1.0)
