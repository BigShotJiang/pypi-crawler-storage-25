"""
---
title: CheckpointManager — State Save/Load
summary: >
    Saves and restores Component state_dict to/from JSON files.
---
"""
from __future__ import annotations

import json
from pathlib import Path

from learn.env.program.variable import Component


class CheckpointManager:
    """Manages saving and loading component state.

    ```python
    mgr = CheckpointManager(checkpoint_dir="./checkpoints")
    mgr.save(component, "step_10")
    mgr.load(component, "step_10")
    ```
    """

    def __init__(self, checkpoint_dir: str = "./checkpoints") -> None:
        self.checkpoint_dir = Path(checkpoint_dir)

    def save(self, component: Component, name: str) -> Path:
        """Save component state to a JSON file.

        Returns:
            The path to the saved checkpoint file.
        """
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        path = self.checkpoint_dir / f"{name}.json"
        state = component.state_dict()
        path.write_text(json.dumps(state, indent=2, default=str))
        return path

    def load(self, component: Component, name: str) -> None:
        """Load component state from a JSON file."""
        path = self.checkpoint_dir / f"{name}.json"
        if not path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {path}")
        state = json.loads(path.read_text())
        component.load_state_dict(state)

    def list_checkpoints(self) -> list[str]:
        """List available checkpoint names."""
        if not self.checkpoint_dir.exists():
            return []
        return sorted(p.stem for p in self.checkpoint_dir.glob("*.json"))
