"""
---
title: ConfigManager — Experiment Configuration
summary: >
    Simple hierarchical configuration manager for learn experiments.
    Supports nested key access, merging, and dict round-tripping.
---
"""
from __future__ import annotations

from typing import Any


class ConfigManager:
    """Simple configuration manager for learn experiments.

    ```python
    config = ConfigManager(defaults={"lr": 0.01, "epochs": 10})
    config.set("lr", 0.005)
    assert config.get("lr") == 0.005
    ```
    """

    def __init__(self, defaults: dict[str, Any] | None = None) -> None:
        self._config: dict[str, Any] = dict(defaults) if defaults else {}

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by key, with optional default."""
        return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a config value."""
        self._config[key] = value

    def update(self, d: dict[str, Any]) -> None:
        """Merge a dict into the config."""
        self._config.update(d)

    def to_dict(self) -> dict[str, Any]:
        """Return a shallow copy of the config as a dict."""
        return dict(self._config)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ConfigManager:
        """Create a ConfigManager from a dict."""
        return cls(defaults=d)

    def __contains__(self, key: str) -> bool:
        return key in self._config

    def __repr__(self) -> str:
        return f"ConfigManager({self._config!r})"
