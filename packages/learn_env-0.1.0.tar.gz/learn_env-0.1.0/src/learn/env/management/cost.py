"""
---
title: CostTracker — LLM API Cost Tracking
summary: >
    Tracks cumulative cost of LLM API calls for budget management.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CostTracker:
    """Tracks cumulative LLM API costs.

    ```python
    tracker = CostTracker(budget=10.0)
    tracker.add(0.02, tokens=500, label="forward")
    if tracker.over_budget:
        stop_training()
    ```
    """

    budget: float | None = None
    total_cost: float = 0.0
    total_tokens: int = 0
    entries: list[dict] = field(default_factory=list)

    def add(
        self,
        cost: float,
        tokens: int = 0,
        label: str = "",
    ) -> None:
        """Record a cost entry."""
        self.total_cost += cost
        self.total_tokens += tokens
        self.entries.append({
            "cost": cost,
            "tokens": tokens,
            "label": label,
            "cumulative_cost": self.total_cost,
        })

    @property
    def over_budget(self) -> bool:
        """Check if the total cost exceeds the budget."""
        if self.budget is None:
            return False
        return self.total_cost > self.budget

    @property
    def remaining_budget(self) -> float | None:
        """Return remaining budget, or None if no budget set."""
        if self.budget is None:
            return None
        return max(0.0, self.budget - self.total_cost)

    def summary(self) -> dict:
        """Return a cost summary."""
        return {
            "total_cost": self.total_cost,
            "total_tokens": self.total_tokens,
            "budget": self.budget,
            "remaining": self.remaining_budget,
            "over_budget": self.over_budget,
            "num_entries": len(self.entries),
        }
