"""
---
title: Exporters — Metric and Trace Export Backends
summary: >
    Pluggable backends for persisting metrics and traces.
    JSONExporter writes to files; ConsoleExporter prints summaries.
---

# Exporters

Each exporter implements ``export_trace()`` and ``export_metrics()``
for unified output of monitoring data. The design follows the
OpenTelemetry exporter pattern but is much simpler.
"""
from __future__ import annotations

import json
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from learn.env.management.tracing.trace import Trace


class BaseExporter(ABC):
    """Abstract base for monitoring exporters."""

    @abstractmethod
    def export_trace(self, trace: Trace) -> None:
        """Export a completed trace."""

    @abstractmethod
    def export_metrics(self, metrics: dict[str, Any]) -> None:
        """Export a metrics dictionary."""


class JSONExporter(BaseExporter):
    """Exports traces and metrics to JSON files.

    ```python
    exporter = JSONExporter(output_dir="./logs")
    with Trace("step_1") as trace:
        ...
    exporter.export_trace(trace)
    ```

    File naming:
    - Traces: ``trace_{trace_id}.json``
    - Metrics: ``metrics_{timestamp}.json``
    """

    def __init__(self, output_dir: str | Path = "./learn_logs") -> None:
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_trace(self, trace: Trace) -> None:
        """Write trace to a JSON file."""
        path = self.output_dir / f"trace_{trace.trace_id}.json"
        data = trace.to_dict()
        path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )

    def export_metrics(self, metrics: dict[str, Any]) -> None:
        """Write metrics to a JSON file."""
        import time

        ts = int(time.time())
        path = self.output_dir / f"metrics_{ts}.json"
        path.write_text(
            json.dumps(metrics, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )


class ConsoleExporter(BaseExporter):
    """Prints traces and metrics to stderr.

    Useful for debugging and development. Not suitable for production
    monitoring — use JSONExporter or a custom backend instead.
    """

    def export_trace(self, trace: Trace) -> None:
        """Print trace summary to stderr."""
        print(
            f"[Trace] {trace.name} "
            f"(id={trace.trace_id}, "
            f"spans={len(trace.spans)}, "
            f"duration={trace.duration_ms:.1f}ms)",
            file=sys.stderr,
        )
        for span in trace.spans:
            status = "ERROR" if span.error else "OK"
            print(
                f"  [{span.kind.value}] {span.name}: "
                f"{span.duration_ms:.1f}ms ({status})",
                file=sys.stderr,
            )

    def export_metrics(self, metrics: dict[str, Any]) -> None:
        """Print metrics to stderr."""
        print("[Metrics]", file=sys.stderr)
        for key, value in metrics.items():
            print(f"  {key}: {value}", file=sys.stderr)
