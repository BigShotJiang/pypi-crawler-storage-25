"""
---
title: learn.env.engine — LLM Engine Backends
summary: >
    Abstract LLM interface and concrete backends.
    All engines share the same ``generate(prompt, system_prompt) → str`` contract.
    Each engine tracks token usage via ``UsageStats`` for observability.
    Includes registry, caching, retry, and instrumentation wrappers.
---
"""
from learn.env.engine.base import (
    EngineLM,
    GenerateResult,
    ReinforceJob,
    TrainDataFormat,
    TrainingJob,
    UsageStats,
)
from learn.env.engine.cache import CachedEngine
from learn.env.engine.config import EngineConfig
from learn.env.engine.instrumented import InstrumentedEngine
from learn.env.engine.mock import MockEngine
from learn.env.engine.openai_compatible import OpenAICompatibleEngine
from learn.env.engine.openrouter import OpenRouterEngine
from learn.env.engine.pool import EnginePool
from learn.env.engine.registry import EngineRegistry, get_engine
from learn.env.engine.retry import RetryEngine

__all__ = [
    "CachedEngine",
    "EngineConfig",
    "EngineLM",
    "EnginePool",
    "EngineRegistry",
    "GenerateResult",
    "InstrumentedEngine",
    "MockEngine",
    "OpenAICompatibleEngine",
    "OpenRouterEngine",
    "ReinforceJob",
    "RetryEngine",
    "TrainDataFormat",
    "TrainingJob",
    "UsageStats",
    "get_engine",
]