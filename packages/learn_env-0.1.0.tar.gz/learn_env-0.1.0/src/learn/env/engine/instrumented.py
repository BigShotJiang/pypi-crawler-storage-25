"""
---
title: InstrumentedEngine — Auto-Monitoring Engine Wrapper
summary: >
    Wraps any EngineLM to automatically fire callback hooks, record
    usage to CostTracker, and create tracing spans on every generate()
    call. This is the bridge between engines and the monitoring system.
---

# InstrumentedEngine

The central piece connecting engines to monitoring. Wraps any engine
and transparently adds:

1. **Callback firing** — ``on_engine_call_start/end/error``
2. **Cost tracking** — auto-records to a ``CostTracker`` if provided
3. **Tracing** — creates a ``Span`` in the current ``Trace`` if active

All of this is opt-in and zero-overhead when no callbacks/tracker are set.

```python
from learn.env.engine import OpenRouterEngine
from learn.env.engine.instrumented import InstrumentedEngine
from learn.env.management import CostTracker

tracker = CostTracker(budget=1.0)
engine = InstrumentedEngine(
    OpenRouterEngine(model="openai/gpt-4o-mini"),
    cost_tracker=tracker,
)
result = engine("Hello!")
print(tracker.summary())
```
"""
from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Optional

from learn.env.engine.base import EngineLM, UsageStats

if TYPE_CHECKING:
    from learn.env.management.callbacks import CallbackList
    from learn.env.management.cost import CostTracker


class InstrumentedEngine(EngineLM):
    """Monitoring wrapper that instruments every ``generate()`` call.

    Attributes:
        wrapped: The underlying engine.
        callbacks: Optional CallbackList to fire engine hooks on.
        cost_tracker: Optional CostTracker for automatic cost recording.
        total_calls: Number of generate() calls made.
        total_tokens: Cumulative tokens across all calls.
        total_latency_ms: Cumulative latency across all calls.
    """

    def __init__(
        self,
        wrapped: EngineLM,
        callbacks: CallbackList | None = None,
        cost_tracker: CostTracker | None = None,
    ) -> None:
        self.wrapped = wrapped
        self._model_name = wrapped.model_name
        self.callbacks = callbacks
        self.cost_tracker = cost_tracker

        # Cumulative statistics
        self.total_calls: int = 0
        self.total_tokens: int = 0
        self.total_latency_ms: float = 0.0

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        # --- Pre-call hooks ---
        if self.callbacks:
            self.callbacks.on_engine_call_start(
                self.wrapped, prompt, system_prompt, kwargs
            )

        # --- Trace span (if active trace exists) ---
        span = None
        try:
            from learn.env.management.tracing.scope import get_current_trace
            from learn.env.management.tracing.span import SpanKind

            trace = get_current_trace()
            if trace is not None:
                span = trace.start_span(
                    f"engine:{self.wrapped.model_name}",
                    kind=SpanKind.ENGINE,
                )
                span.__enter__()
        except ImportError:
            pass

        # --- Engine call ---
        t0 = time.perf_counter()
        try:
            result = self.wrapped.generate(
                prompt, system_prompt=system_prompt, **kwargs
            )
        except BaseException as e:
            latency_ms = (time.perf_counter() - t0) * 1000.0
            if self.callbacks:
                self.callbacks.on_engine_error(self.wrapped, e)
            if span is not None:
                span.__exit__(type(e), e, e.__traceback__)
            raise

        latency_ms = (time.perf_counter() - t0) * 1000.0

        # --- Collect usage ---
        usage = self.wrapped.usage or UsageStats(
            model=self.wrapped.model_name,
            latency_ms=latency_ms,
        )
        self._last_usage = usage

        # --- Update cumulative stats ---
        self.total_calls += 1
        self.total_tokens += usage.total_tokens
        self.total_latency_ms += latency_ms

        # --- Cost tracker ---
        if self.cost_tracker is not None:
            self.cost_tracker.add(
                cost=usage.cost,
                tokens=usage.total_tokens,
                label=f"engine:{self.wrapped.model_name}",
            )

        # --- Post-call hooks ---
        if self.callbacks:
            self.callbacks.on_engine_call_end(
                self.wrapped, result, usage, latency_ms
            )

        # --- Close trace span ---
        if span is not None:
            span.set_attribute("tokens", usage.total_tokens)
            span.set_attribute("latency_ms", round(latency_ms, 2))
            span.__exit__(None, None, None)

        return result

    def summary(self) -> dict[str, Any]:
        """Return a summary of instrumented engine statistics."""
        return {
            "model": self.wrapped.model_name,
            "total_calls": self.total_calls,
            "total_tokens": self.total_tokens,
            "total_latency_ms": round(self.total_latency_ms, 2),
            "avg_latency_ms": (
                round(self.total_latency_ms / self.total_calls, 2)
                if self.total_calls > 0
                else 0.0
            ),
        }

    def __repr__(self) -> str:
        return (
            f"InstrumentedEngine(wrapped={self.wrapped!r}, "
            f"calls={self.total_calls})"
        )
