"""
---
title: EnginePool — Multi-Engine Selection
summary: >
    A pool of LLM engines with round-robin, random, or named selection.
    Implements the EngineLM interface so it can be used as a drop-in
    replacement for a single engine.
---
"""
from __future__ import annotations

import random
from typing import Optional

from learn.env.engine.base import EngineLM


class EnginePool(EngineLM):
    """Multi-engine pool with configurable selection strategy.

    Strategies:
        - ``"round_robin"`` — cycle through engines sequentially
        - ``"random"`` — pick a random engine each call

    ```python
    pool = EnginePool(
        engines={"gpt4": gpt4_engine, "claude": claude_engine},
        strategy="round_robin",
    )
    result = pool.generate("Hello")
    ```
    """

    def __init__(
        self,
        engines: dict[str, EngineLM],
        strategy: str = "round_robin",
    ) -> None:
        if not engines:
            raise ValueError("EnginePool requires at least one engine.")
        self.engines = engines
        self.strategy = strategy
        self._names = list(engines.keys())
        self._idx = 0
        self._model_name = f"pool({','.join(self._names)})"

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> str:
        """Generate using the selected engine."""
        engine = self._select_engine()
        return engine.generate(prompt, system_prompt=system_prompt, **kwargs)

    def _select_engine(self) -> EngineLM:
        """Pick an engine according to the configured strategy."""
        if self.strategy == "random":
            return self.engines[random.choice(self._names)]

        # Default: round_robin
        name = self._names[self._idx % len(self._names)]
        self._idx += 1
        return self.engines[name]

    def get_engine(self, name: str) -> EngineLM:
        """Retrieve a specific engine by name."""
        if name not in self.engines:
            raise KeyError(f"Engine {name!r} not found in pool.")
        return self.engines[name]

    def __repr__(self) -> str:
        return (
            f"EnginePool(engines={self._names!r}, "
            f"strategy={self.strategy!r})"
        )
