"""
---
title: RetryEngine — Resilient Engine Wrapper
summary: >
    Wraps any EngineLM with exponential-backoff retry logic.
    Catches transient errors (connection, timeout, rate-limit)
    and retries automatically.
---

# RetryEngine

Production LLM APIs frequently return transient errors: rate limits,
timeouts, server errors. This wrapper handles these transparently.

The retry delay follows truncated exponential backoff:

$$d_k = \\min(d_0 \\cdot 2^k + \\text{jitter},\\; d_{\\max})$$

where $k$ is the retry attempt number.
"""
from __future__ import annotations

import logging
import random
import time
from typing import Any, Optional, Sequence, Type

from learn.env.engine.base import EngineLM

logger = logging.getLogger(__name__)

# Default exceptions to retry on
_DEFAULT_RETRYABLE: tuple[Type[BaseException], ...] = (
    ConnectionError,
    TimeoutError,
    OSError,
)


class RetryEngine(EngineLM):
    """Retry wrapper with exponential backoff for any EngineLM.

    ```python
    from learn.env.engine import OpenRouterEngine
    from learn.env.engine.retry import RetryEngine

    engine = RetryEngine(
        OpenRouterEngine(model="openai/gpt-4o-mini"),
        max_retries=3,
        base_delay=1.0,
    )
    result = engine("Hello!")  # auto-retries on transient errors
    ```

    Attributes:
        wrapped: The underlying engine.
        max_retries: Maximum retry attempts (0 = no retries).
        base_delay: Base delay in seconds before first retry.
        max_delay: Maximum delay between retries.
        retryable_exceptions: Tuple of exception types to retry on.
    """

    def __init__(
        self,
        wrapped: EngineLM,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        retryable_exceptions: Sequence[Type[BaseException]] | None = None,
    ) -> None:
        self.wrapped = wrapped
        self._model_name = wrapped.model_name
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retryable_exceptions: tuple[Type[BaseException], ...] = (
            tuple(retryable_exceptions) if retryable_exceptions
            else _DEFAULT_RETRYABLE
        )
        self.total_retries: int = 0

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        last_error: BaseException | None = None

        for attempt in range(self.max_retries + 1):
            try:
                result = self.wrapped.generate(
                    prompt, system_prompt=system_prompt, **kwargs
                )
                # Propagate usage from the wrapped engine
                self._last_usage = self.wrapped.usage
                return result
            except self.retryable_exceptions as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = min(
                        self.base_delay * (2 ** attempt)
                        + random.uniform(0, 0.5),
                        self.max_delay,
                    )
                    self.total_retries += 1
                    logger.warning(
                        "RetryEngine: attempt %d/%d failed (%s: %s), "
                        "retrying in %.1fs",
                        attempt + 1,
                        self.max_retries,
                        type(e).__name__,
                        e,
                        delay,
                    )
                    time.sleep(delay)

        # All retries exhausted
        raise last_error  # type: ignore[misc]

    def __repr__(self) -> str:
        return (
            f"RetryEngine(wrapped={self.wrapped!r}, "
            f"max_retries={self.max_retries})"
        )
