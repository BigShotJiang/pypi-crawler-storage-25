"""
---
title: EngineConfig — Engine Configuration Dataclass
summary: >
    Provider-agnostic configuration for LLM engines. Supports
    serialization to/from dictionaries for checkpoint and registry use.
---

# EngineConfig

A simple dataclass holding all common engine parameters. This serves as
the canonical configuration format for ``EngineRegistry.create()`` and
for serializing/deserializing engine state in checkpoints.

$$\\text{config} \\mapsto \\text{Engine}$$
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EngineConfig:
    """Configuration for constructing an LLM engine.

    Attributes:
        provider: Provider/engine class name (e.g., ``"openrouter"``,
            ``"openai_compatible"``).
        model: Model identifier (e.g., ``"openai/gpt-4o-mini"``).
        api_key: API key. If empty, resolved from environment.
        base_url: API base URL. Provider-specific default used if empty.
        temperature: Sampling temperature.
        max_tokens: Maximum tokens to generate.
        extra: Any additional provider-specific parameters.
    """

    provider: str = ""
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    temperature: float = 0.7
    max_tokens: int = 2048
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dictionary (JSON-safe)."""
        d: dict[str, Any] = {
            "provider": self.provider,
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        if self.base_url:
            d["base_url"] = self.base_url
        if self.extra:
            d["extra"] = self.extra
        # Intentionally omit api_key from serialization for security
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EngineConfig:
        """Deserialize from a dictionary."""
        return cls(
            provider=data.get("provider", ""),
            model=data.get("model", ""),
            api_key=data.get("api_key", ""),
            base_url=data.get("base_url", ""),
            temperature=data.get("temperature", 0.7),
            max_tokens=data.get("max_tokens", 2048),
            extra=data.get("extra", {}),
        )
