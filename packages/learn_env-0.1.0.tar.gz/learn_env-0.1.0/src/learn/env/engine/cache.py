"""
---
title: CachedEngine — Response Caching Wrapper
summary: >
    Wraps any EngineLM to cache responses on disk. Cache key is derived
    from the model, prompt, system prompt, and generation parameters.
    Inspired by textgrad's response caching pattern.
---

# CachedEngine

Wraps any engine to provide transparent disk caching. On a cache hit,
the wrapped engine is not called at all — the cached response is
returned immediately.

$$\\text{key} = \\text{hash}(\\text{model} \\| \\text{prompt} \\| \\text{system\\_prompt} \\| \\text{sorted}(\\text{kwargs}))$$

Cache files are stored as JSON in ``~/.cache/learn/`` by default.
Each file is named ``{hex_digest}.json``.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Optional

from learn.env.engine.base import EngineLM


class CachedEngine(EngineLM):
    """Caching wrapper for any EngineLM instance.

    ```python
    from learn.env.engine import OpenRouterEngine
    from learn.env.engine.cache import CachedEngine

    engine = CachedEngine(OpenRouterEngine(model="openai/gpt-4o-mini"))
    result = engine("Hello!")   # → API call (cache miss)
    result = engine("Hello!")   # → Instant (cache hit)
    ```

    Attributes:
        wrapped: The underlying engine being cached.
        cache_dir: Directory for cache files.
        hits: Number of cache hits since creation.
        misses: Number of cache misses since creation.
    """

    def __init__(
        self,
        wrapped: EngineLM,
        cache_dir: str | Path | None = None,
        enabled: bool = True,
    ) -> None:
        self.wrapped = wrapped
        self._model_name = wrapped.model_name
        self.cache_dir = Path(
            cache_dir or os.path.expanduser("~/.cache/learn")
        )
        self.enabled = enabled
        self.hits: int = 0
        self.misses: int = 0

        if self.enabled:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_key(
        self,
        prompt: str,
        system_prompt: Optional[str],
        **kwargs: Any,
    ) -> str:
        """Compute a deterministic cache key."""
        key_parts = {
            "model": self.wrapped.model_name,
            "prompt": prompt,
            "system_prompt": system_prompt or "",
            "kwargs": sorted(
                (k, str(v)) for k, v in kwargs.items()
            ),
        }
        key_str = json.dumps(key_parts, sort_keys=True)
        return hashlib.sha256(key_str.encode()).hexdigest()

    def _cache_path(self, key: str) -> Path:
        return self.cache_dir / f"{key}.json"

    def _read_cache(self, key: str) -> str | None:
        """Try to read a cached response. Returns None on miss."""
        path = self._cache_path(key)
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                return data.get("response")
            except (json.JSONDecodeError, KeyError):
                return None
        return None

    def _write_cache(self, key: str, response: str) -> None:
        """Write a response to the cache."""
        path = self._cache_path(key)
        data = {
            "model": self.wrapped.model_name,
            "response": response,
        }
        path.write_text(
            json.dumps(data, ensure_ascii=False), encoding="utf-8"
        )

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        if not self.enabled:
            return self.wrapped.generate(
                prompt, system_prompt=system_prompt, **kwargs
            )

        key = self._cache_key(prompt, system_prompt, **kwargs)
        cached = self._read_cache(key)

        if cached is not None:
            self.hits += 1
            return cached

        self.misses += 1
        response = self.wrapped.generate(
            prompt, system_prompt=system_prompt, **kwargs
        )

        # Propagate usage from the wrapped engine
        self._last_usage = self.wrapped.usage

        self._write_cache(key, response)
        return response

    def clear_cache(self) -> int:
        """Delete all cache files. Returns the number of files removed."""
        count = 0
        if self.cache_dir.exists():
            for f in self.cache_dir.glob("*.json"):
                f.unlink()
                count += 1
        self.hits = 0
        self.misses = 0
        return count

    @property
    def cache_size(self) -> int:
        """Number of entries currently in the cache."""
        if not self.cache_dir.exists():
            return 0
        return sum(1 for _ in self.cache_dir.glob("*.json"))

    def __repr__(self) -> str:
        return (
            f"CachedEngine(wrapped={self.wrapped!r}, "
            f"hits={self.hits}, misses={self.misses})"
        )
