"""
---
title: OpenRouter Engine
summary: >
    Convenience engine for the OpenRouter API (openrouter.ai).
    Extends OpenAICompatibleEngine with the OpenRouter base URL
    and API key resolution.
---
"""
from __future__ import annotations

import os
from typing import Any, Optional

from learn.env.engine.openai_compatible import OpenAICompatibleEngine

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


class OpenRouterEngine(OpenAICompatibleEngine):
    """Engine that routes through OpenRouter.

    ```python
    engine = OpenRouterEngine(model="openai/gpt-4o-mini")
    response = engine.generate("Hello!")
    ```

    API key resolution order:
        1. ``api_key`` constructor argument
        2. ``OPENROUTER_API_KEY`` environment variable
    """

    def __init__(
        self,
        model: str = "openai/gpt-4o-mini",
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs: Any,
    ) -> None:
        resolved_key = api_key or os.environ.get("OPENROUTER_API_KEY", "")
        super().__init__(
            base_url=OPENROUTER_BASE_URL,
            model=model,
            api_key=resolved_key,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )

    def __repr__(self) -> str:
        return f"OpenRouterEngine(model={self.model!r})"
