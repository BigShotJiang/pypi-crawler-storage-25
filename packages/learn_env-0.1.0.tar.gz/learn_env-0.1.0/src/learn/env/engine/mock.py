"""
---
title: MockEngine — Deterministic Test Engine
summary: >
    A mock LLM engine for deterministic testing. Matches prompts against
    a dictionary of substrings and returns canned responses.
---
"""
from __future__ import annotations

from typing import Any, Optional

from learn.env.engine.base import (
    EngineLM,
    GenerateResult,
    ReinforceJob,
    TrainDataFormat,
    TrainingJob,
)


class MockEngine(EngineLM):
    r"""
    <a id="MockEngine"></a>

    ## MockEngine

    Deterministic test engine. Looks up the prompt in a substring→response
    dictionary and returns the first match, or a numbered default.

    ```python
    engine = MockEngine(responses={"math": "42"})
    assert engine("Solve the math problem") == "42"
    assert engine("Hello") == "Mock response #2"
    ```
    """

    def __init__(
        self,
        responses: dict[str, str] | None = None,
        default_response: str | None = None,
    ) -> None:
        self.responses: dict[str, str] = responses or {}
        self.default_response: str | None = default_response
        self._model_name = "mock"

        # Training capability flags
        self.finetunable: bool = True
        self.reinforceable: bool = True

        # Call tracking for test assertions
        self.call_count: int = 0
        self.last_prompt: str | None = None
        self.last_system_prompt: str | None = None
        self.call_history: list[dict[str, str | None]] = []

        # Training tracking
        self.finetune_calls: list[dict[str, Any]] = []
        self.reinforce_calls: list[dict[str, Any]] = []

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> str:
        """Return the first matching response or a numbered default."""
        self.call_count += 1
        self.last_prompt = prompt
        self.last_system_prompt = system_prompt
        self.call_history.append(
            {"prompt": prompt, "system_prompt": system_prompt}
        )

        for substring, response in self.responses.items():
            if substring in prompt:
                return response

        if self.default_response is not None:
            return self.default_response
        return f"Mock response #{self.call_count}"

    def reset(self) -> None:
        """Reset call tracking counters."""
        self.call_count = 0
        self.last_prompt = None
        self.last_system_prompt = None
        self.call_history.clear()
        self.finetune_calls.clear()
        self.reinforce_calls.clear()

    def generate_with_logprobs(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> GenerateResult:
        """Generate with mock logprobs (uniform -1.0 per token).

        Useful for testing MCTS PUCT selection and other logprob-
        dependent features without a real LLM backend.
        """
        text = self.generate(prompt, system_prompt=system_prompt, **kwargs)
        # Simulate token-level logprobs: split on whitespace, assign -1.0
        tokens = text.split()
        logprobs = [(token, -1.0) for token in tokens]
        return GenerateResult(text=text, logprobs=logprobs)

    def finetune(
        self,
        train_data: list[dict[str, Any]],
        train_data_format: TrainDataFormat | None = None,
        train_kwargs: dict[str, Any] | None = None,
    ) -> TrainingJob:
        """Mock fine-tuning — immediately completes with a mock model ID.

        Records the call for test assertions. Returns a ``TrainingJob``
        that is already done with ``fine_tuned_model = "mock-ft-{N}"``.
        """
        call_record = {
            "train_data": train_data,
            "train_data_format": train_data_format,
            "train_kwargs": train_kwargs or {},
            "num_examples": len(train_data),
        }
        self.finetune_calls.append(call_record)

        job = TrainingJob(
            model=self._model_name,
            train_data=train_data,
            train_data_format=train_data_format,
            train_kwargs=train_kwargs or {},
        )
        ft_model_id = f"mock-ft-{len(self.finetune_calls)}"
        job.set_result(ft_model_id)
        return job

    def reinforce(
        self,
        train_kwargs: dict[str, Any] | None = None,
    ) -> ReinforceJob:
        """Mock RL training — creates a ``ReinforceJob`` with mock batch IDs.

        Records the call for test assertions.
        """
        call_record = {
            "train_kwargs": train_kwargs or {},
        }
        self.reinforce_calls.append(call_record)

        job = ReinforceJob(
            model=self._model_name,
            train_kwargs=train_kwargs or {},
        )
        job.initialize()
        return job
