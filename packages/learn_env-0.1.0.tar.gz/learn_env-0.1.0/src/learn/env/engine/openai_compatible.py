"""
---
title: OpenAI-Compatible Engine
summary: >
    Engine for any OpenAI-API-compatible backend (OpenAI, OpenRouter,
    vLLM, Ollama, etc.). Uses the openai Python SDK with configurable
    base_url. Automatically tracks token usage via ``UsageStats``.
---
"""
from __future__ import annotations

import os
import time
from typing import Any, Optional

from learn.env.engine.base import EngineLM, UsageStats


class OpenAICompatibleEngine(EngineLM):
    """Engine for any service that exposes the OpenAI chat completions API.

    ```python
    engine = OpenAICompatibleEngine(
        base_url="http://localhost:8000/v1",
        model="my-model",
        api_key="sk-...",
    )
    response = engine.generate("Hello!")
    print(engine.usage)  # UsageStats(prompt_tokens=5, ...)
    ```
    """

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        **kwargs: Any,
    ) -> None:
        self.base_url = base_url
        self.model = model
        self._model_name = model
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.extra_kwargs = kwargs
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                import openai
            except ImportError as e:
                raise ImportError(
                    "openai package required. Install with: "
                    "uv pip install openai"
                ) from e
            self._client = openai.OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    def _parse_usage(self, response: Any, latency_ms: float) -> UsageStats:
        """Extract UsageStats from an OpenAI-style API response."""
        usage = getattr(response, "usage", None)
        if usage is None:
            return UsageStats(model=self.model, latency_ms=latency_ms)
        return UsageStats(
            prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
            total_tokens=getattr(usage, "total_tokens", 0) or 0,
            latency_ms=latency_ms,
            model=self.model,
        )

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        client = self._get_client()
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        call_kwargs: dict[str, Any] = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            **self.extra_kwargs,
            **kwargs,
        }
        t0 = time.perf_counter()
        response = client.chat.completions.create(
            messages=messages, **call_kwargs
        )
        latency_ms = (time.perf_counter() - t0) * 1000.0

        self._last_usage = self._parse_usage(response, latency_ms)
        return response.choices[0].message.content or ""

    def to_config(self) -> dict[str, Any]:
        """Serialize engine configuration."""
        return {
            "class": type(self).__name__,
            "model": self.model,
            "base_url": self.base_url,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

    def __repr__(self) -> str:
        return f"OpenAICompatibleEngine(model={self.model!r}, base_url={self.base_url!r})"
