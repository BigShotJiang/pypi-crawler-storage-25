"""
---
title: EngineRegistry — Name-Based Engine Construction
summary: >
    Fairseq-style registry for engines. Register engine classes with
    decorators or explicit calls, then create instances by name.
---

# EngineRegistry

Provides a global lookup from provider names (e.g., ``"openrouter"``,
``"openai_compatible"``) to engine constructors. This enables
configuration-driven engine creation:

```python
engine = EngineRegistry.create("openrouter", model="openai/gpt-4o-mini")
```

The registry also supports a convenience function ``get_engine()`` that
mirrors the textgrad ``get_engine()`` API:

```python
engine = get_engine("openai/gpt-4o-mini")  # auto-detects OpenRouter
```
"""
from __future__ import annotations

from typing import Any, Callable, Type

from learn.env.engine.base import EngineLM


class EngineRegistry:
    """Global registry mapping provider names to engine classes.

    Built-in providers are registered at module load time.
    Users can register custom providers via ``register()``.
    """

    _registry: dict[str, Type[EngineLM]] = {}

    @classmethod
    def register(
        cls, name: str
    ) -> Callable[[Type[EngineLM]], Type[EngineLM]]:
        """Decorator to register an engine class under a provider name.

        ```python
        @EngineRegistry.register("my_provider")
        class MyEngine(EngineLM):
            ...
        ```
        """

        def decorator(engine_cls: Type[EngineLM]) -> Type[EngineLM]:
            cls._registry[name] = engine_cls
            return engine_cls

        return decorator

    @classmethod
    def register_class(cls, name: str, engine_cls: Type[EngineLM]) -> None:
        """Explicitly register an engine class (non-decorator form)."""
        cls._registry[name] = engine_cls

    @classmethod
    def create(cls, provider: str, **kwargs: Any) -> EngineLM:
        """Create an engine instance by provider name.

        Args:
            provider: Registered provider name (e.g., ``"openrouter"``).
            **kwargs: Constructor arguments forwarded to the engine class.

        Raises:
            KeyError: If the provider is not registered.
        """
        if provider not in cls._registry:
            available = ", ".join(sorted(cls._registry.keys()))
            raise KeyError(
                f"Unknown engine provider {provider!r}. "
                f"Available: [{available}]"
            )
        return cls._registry[provider](**kwargs)

    @classmethod
    def create_from_config(cls, config: dict[str, Any]) -> EngineLM:
        """Create an engine from a serialized config dictionary.

        The dictionary should have a ``"provider"`` or ``"class"`` key.
        Remaining keys are passed as constructor arguments.
        """
        config = dict(config)  # Don't mutate the original
        provider = config.pop("provider", "") or config.pop("class", "")
        if not provider:
            raise ValueError(
                "Config must have a 'provider' or 'class' key."
            )
        # Normalize common class names → provider names
        provider_map = {
            "OpenRouterEngine": "openrouter",
            "OpenAICompatibleEngine": "openai_compatible",
            "MockEngine": "mock",
            "EnginePool": "pool",
        }
        provider = provider_map.get(provider, provider)
        return cls.create(provider, **config)

    @classmethod
    def list_providers(cls) -> list[str]:
        """Return sorted list of registered provider names."""
        return sorted(cls._registry.keys())

    @classmethod
    def get(cls, name: str) -> Type[EngineLM] | None:
        """Look up a registered engine class by name (None if not found)."""
        return cls._registry.get(name)


# ===================================================================
# Built-in registrations
# ===================================================================

def _register_builtins() -> None:
    """Register all built-in engines. Called once at import time."""
    from learn.env.engine.mock import MockEngine
    from learn.env.engine.openai_compatible import OpenAICompatibleEngine
    from learn.env.engine.openrouter import OpenRouterEngine
    from learn.env.engine.pool import EnginePool

    EngineRegistry.register_class("mock", MockEngine)
    EngineRegistry.register_class("openai_compatible", OpenAICompatibleEngine)
    EngineRegistry.register_class("openrouter", OpenRouterEngine)
    EngineRegistry.register_class("pool", EnginePool)


_register_builtins()


# ===================================================================
# Convenience function
# ===================================================================


def get_engine(
    model_string: str,
    **kwargs: Any,
) -> EngineLM:
    """Create an engine from a model string (textgrad-style convenience).

    The model string format determines the provider:

    - ``"openai/gpt-4o-mini"`` → OpenRouter (slash in name)
    - ``"anthropic/claude-3-haiku"`` → OpenRouter
    - ``"mock"`` → MockEngine

    For full control, use ``EngineRegistry.create()`` directly.

    Args:
        model_string: Model identifier. If it contains ``/``, uses
            OpenRouter. If ``"mock"``, uses MockEngine.
        **kwargs: Additional constructor arguments.

    Returns:
        An EngineLM instance ready to use.
    """
    if model_string == "mock":
        return EngineRegistry.create("mock", **kwargs)

    # Slash-separated model names go through OpenRouter
    if "/" in model_string:
        return EngineRegistry.create(
            "openrouter", model=model_string, **kwargs
        )

    # Fall back to trying the string as a provider name
    if model_string in EngineRegistry._registry:
        return EngineRegistry.create(model_string, **kwargs)

    raise ValueError(
        f"Cannot resolve engine for {model_string!r}. "
        f"Use EngineRegistry.create() for explicit construction."
    )
