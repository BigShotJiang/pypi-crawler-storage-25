"""
---
title: EngineLM — Abstract LLM Engine Interface
summary: >
    Defines the abstract base class for all LLM backends.
    Concrete engines (OpenAI, Anthropic, vLLM, etc.) implement this.
    The interface is intentionally minimal: text in → text out.
    Also provides UsageStats for tracking token usage and costs.
---

# Engine Interface

The engine is the lowest-level LLM abstraction. Everything else —
autograd, optimizers, agents — depends only on
``generate(prompt, system_prompt) → str``.

## Observability

Each engine tracks usage through ``UsageStats``, accessible via the
``usage`` property after any ``generate()`` call. This enables
automatic cost/token tracking when combined with ``InstrumentedEngine``.
"""
from __future__ import annotations

import enum
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class UsageStats:
    """Token usage and cost statistics from a single engine call.

    Populated automatically by engines that parse API response metadata.
    Used by ``InstrumentedEngine`` and ``CostTracker`` for automatic
    cost tracking.

    Attributes:
        prompt_tokens: Number of tokens in the prompt/input.
        completion_tokens: Number of tokens in the completion/output.
        total_tokens: Total tokens (prompt + completion).
        cost: Estimated cost in USD for this call.
        latency_ms: Wall-clock time in milliseconds.
        model: The model identifier used for this call.
    """

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0
    latency_ms: float = 0.0
    model: str = ""

    def __add__(self, other: UsageStats) -> UsageStats:
        """Aggregate two usage stats (for batch tracking)."""
        return UsageStats(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
            cost=self.cost + other.cost,
            latency_ms=self.latency_ms + other.latency_ms,
            model=self.model or other.model,
        )


@dataclass
class GenerateResult:
    """Structured result from ``generate()`` when extra outputs are requested.

    Returned instead of plain ``str`` when ``logprobs=True`` or other
    structured output modes are enabled.

    Attributes:
        text: The generated text (same as the plain ``str`` return).
        logprobs: Per-token log probabilities, if requested. Each entry
            is ``(token, logprob)`` in generation order.
        finish_reason: Why generation stopped (e.g., "stop", "length").
        usage: Token usage statistics from the API response.
    """

    text: str
    logprobs: list[tuple[str, float]] = field(default_factory=list)
    finish_reason: str = ""
    usage: UsageStats = field(default_factory=UsageStats)

    def __str__(self) -> str:
        return self.text

    @property
    def total_logprob(self) -> float:
        """Sum of all token log probabilities."""
        return sum(lp for _, lp in self.logprobs) if self.logprobs else 0.0


# ---------------------------------------------------------------------------
# Training Data Formats
# ---------------------------------------------------------------------------


class TrainDataFormat(enum.Enum):
    """Training data format specifiers for fine-tuning and RL.

    Ported from DSPy's ``TrainDataFormat`` to maintain compatibility.

    | Format | Use case |
    |--------|----------|
    | ``SFT_CHAT`` | Supervised fine-tuning with chat messages |
    | ``DPO_CHAT`` | Direct preference optimization with chosen/rejected |
    | ``GRPO_CHAT`` | Group relative policy optimization with rewards |
    """

    SFT_CHAT = "sft_chat"
    DPO_CHAT = "dpo_chat"
    GRPO_CHAT = "grpo_chat"


# ---------------------------------------------------------------------------
# Training Jobs
# ---------------------------------------------------------------------------


class TrainingJob:
    """Async fine-tuning job returned by ``EngineLM.finetune()``.

    Wraps a background thread that performs the actual training.
    Call ``.result()`` to block until completion and get the
    fine-tuned model identifier or engine.

    Ported from DSPy's ``TrainingJob`` pattern: the optimizer calls
    ``engine.finetune()`` which returns a ``TrainingJob``, then
    ``job.result()`` blocks until the provider finishes.

    Attributes:
        model: The base model being fine-tuned.
        train_data: The training data submitted.
        train_data_format: The format of the training data.
        train_kwargs: Additional training hyperparameters.
        provider_job_id: Provider-specific job identifier (set during training).
        fine_tuned_model: The result model ID (set after completion).
    """

    def __init__(
        self,
        model: str = "",
        train_data: list[dict[str, Any]] | None = None,
        train_data_format: TrainDataFormat | None = None,
        train_kwargs: dict[str, Any] | None = None,
        thread: threading.Thread | None = None,
    ) -> None:
        self.model = model
        self.train_data = train_data or []
        self.train_data_format = train_data_format
        self.train_kwargs = train_kwargs or {}
        self.thread = thread
        self.provider_job_id: str | None = None
        self.fine_tuned_model: str | None = None
        self._result: Any = None
        self._error: Exception | None = None
        self._done = threading.Event()

    def result(self, timeout: float | None = None) -> Any:
        """Block until the training job completes and return the result.

        Returns:
            The fine-tuned model identifier or engine instance.

        Raises:
            RuntimeError: If the training job failed.
        """
        if self.thread is not None:
            self.thread.join(timeout=timeout)
        self._done.wait(timeout=timeout)
        if self._error is not None:
            raise RuntimeError(f"Training job failed: {self._error}") from self._error
        return self._result

    def set_result(self, result: Any) -> None:
        """Set the job result (called by the engine/provider)."""
        self._result = result
        self.fine_tuned_model = str(result) if result else None
        self._done.set()

    def set_error(self, error: Exception) -> None:
        """Set the job error (called by the engine/provider)."""
        self._error = error
        self._done.set()

    @property
    def done(self) -> bool:
        """Whether the job has completed (successfully or with error)."""
        return self._done.is_set()

    def status(self) -> dict[str, Any]:
        """Return job status information."""
        return {
            "model": self.model,
            "done": self.done,
            "provider_job_id": self.provider_job_id,
            "fine_tuned_model": self.fine_tuned_model,
            "error": str(self._error) if self._error else None,
        }


class ReinforceJob:
    """Async RL training job returned by ``EngineLM.reinforce()``.

    Manages a multi-step reinforcement learning session. Unlike
    ``TrainingJob`` (one-shot fine-tuning), ``ReinforceJob`` supports
    iterative ``step()`` calls that submit batches of training data.

    Ported from DSPy's ``ReinforceJob`` pattern used by GRPO:
    the optimizer creates the job, then submits training batches
    via ``step()``, checking ``get_status()`` for pending batch IDs.

    Attributes:
        model: The base model being trained.
        train_kwargs: Training hyperparameters.
    """

    def __init__(
        self,
        model: str = "",
        train_kwargs: dict[str, Any] | None = None,
    ) -> None:
        self.model = model
        self.train_kwargs = train_kwargs or {}
        self._steps: list[dict[str, Any]] = []
        self._batch_counter: int = 0
        self._terminated: bool = False
        self._pending_batch_ids: list[int] = []

    def initialize(self) -> None:
        """Initialize the RL training session.

        Called automatically by ``EngineLM.reinforce()``. Sets up
        initial batch IDs that the optimizer can fill.
        """
        num_generations = self.train_kwargs.get("num_generations", 4)
        self._pending_batch_ids = list(range(num_generations))
        self._batch_counter = num_generations

    def get_status(self) -> dict[str, Any]:
        """Return current job status including pending batch IDs.

        Returns:
            Dict with ``"pending_batch_ids"`` (list of available IDs),
            ``"steps_completed"`` (number of steps done), and
            ``"terminated"`` flag.
        """
        return {
            "pending_batch_ids": list(self._pending_batch_ids),
            "steps_completed": len(self._steps),
            "terminated": self._terminated,
        }

    def step(
        self,
        train_data: list[dict[str, Any]],
        train_data_format: TrainDataFormat = TrainDataFormat.GRPO_CHAT,
    ) -> None:
        """Submit one RL training step with batch data.

        Args:
            train_data: List of dicts, each with ``"batch_id"`` and
                ``"group"`` (list of message/completion/reward dicts).
            train_data_format: The format of the training data.
        """
        if self._terminated:
            raise RuntimeError("ReinforceJob has been terminated")

        # Track submitted batch IDs
        submitted_ids = [item.get("batch_id") for item in train_data]
        self._pending_batch_ids = [
            bid for bid in self._pending_batch_ids
            if bid not in submitted_ids
        ]

        # Replenish batch IDs
        new_ids = list(range(
            self._batch_counter,
            self._batch_counter + len(submitted_ids),
        ))
        self._pending_batch_ids.extend(new_ids)
        self._batch_counter += len(submitted_ids)

        self._steps.append({
            "train_data": train_data,
            "train_data_format": train_data_format,
            "batch_ids_submitted": submitted_ids,
        })

    def terminate(self) -> None:
        """Terminate the RL training session."""
        self._terminated = True

    def save_checkpoint(self, checkpoint_name: str) -> None:
        """Save a training checkpoint (provider-specific)."""
        # Default: no-op. Providers override for real checkpointing.
        pass


class EngineLM(ABC):
    r"""
    <a id="EngineLM"></a>

    ## EngineLM

    Abstract base class for LLM backends. Each backend (OpenAI, Anthropic,
    vLLM, Ollama, etc.) must implement ``generate``.

    | Method | Purpose |
    |--------|---------|
    | ``generate`` | Core text generation (abstract) |
    | ``generate_with_logprobs`` | Generation with per-token logprobs |
    | ``generate_n`` | Generate multiple completions |
    | ``__call__`` | Convenience wrapper around ``generate`` |
    | ``model_name`` | Property returning the model identifier |
    | ``usage`` | Property returning last call's UsageStats |
    | ``finetune`` | Launch async fine-tuning job |
    | ``reinforce`` | Launch async RL training job |
    | ``to_config`` / ``from_config`` | Serialization support |
    """

    # Subclasses should set this in __init__ for observability.
    _model_name: str = ""
    _last_usage: UsageStats | None = None

    # Training capability flags — subclasses override to enable.
    finetunable: bool = False
    reinforceable: bool = False

    @property
    def model_name(self) -> str:
        """The model identifier for this engine."""
        return self._model_name

    @property
    def usage(self) -> UsageStats | None:
        """Usage statistics from the most recent ``generate()`` call.

        Returns ``None`` if no call has been made yet or the backend
        does not report usage.
        """
        return self._last_usage

    @abstractmethod
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> str:
        """Generate a text completion from the given prompt.

        Args:
            prompt: The user/input prompt text.
            system_prompt: Optional system-level instruction.
            **kwargs: Backend-specific parameters.

        Returns:
            The generated text response.
        """
        ...

    def generate_with_logprobs(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> GenerateResult:
        """Generate text with per-token log probabilities.

        Default implementation calls ``generate()`` and wraps the result
        with empty logprobs. Backends that support logprobs (OpenAI,
        OpenRouter, vLLM) should override this.

        Args:
            prompt: The user/input prompt text.
            system_prompt: Optional system-level instruction.
            **kwargs: Backend-specific parameters.

        Returns:
            GenerateResult with text and optionally logprobs.
        """
        text = self.generate(prompt, system_prompt=system_prompt, **kwargs)
        return GenerateResult(text=text)

    def generate_n(
        self,
        prompt: str,
        n: int = 1,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> list[str]:
        """Generate ``n`` completions for the same prompt.

        Default implementation calls ``generate()`` ``n`` times.
        Backends that support ``n`` parameter (OpenAI, OpenRouter) should
        override this for efficiency.

        Args:
            prompt: The user/input prompt text.
            n: Number of completions to generate.
            system_prompt: Optional system-level instruction.
            **kwargs: Backend-specific parameters.

        Returns:
            List of ``n`` generated text responses.
        """
        return [
            self.generate(prompt, system_prompt=system_prompt, **kwargs)
            for _ in range(n)
        ]

    def __call__(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs: object,
    ) -> str:
        """Convenience wrapper — delegates to ``generate``."""
        return self.generate(prompt, system_prompt=system_prompt, **kwargs)

    # ------------------------------------------------------------------
    # Training API — fine-tuning and reinforcement learning
    # ------------------------------------------------------------------

    def finetune(
        self,
        train_data: list[dict[str, Any]],
        train_data_format: TrainDataFormat | None = None,
        train_kwargs: dict[str, Any] | None = None,
    ) -> TrainingJob:
        """Launch an asynchronous fine-tuning job.

        Ported from DSPy's ``LM.finetune()`` — collects formatted
        training data and dispatches to the provider for actual
        weight updates (SFT, DPO).

        Args:
            train_data: List of training examples in the specified format.
            train_data_format: Format specifier (SFT_CHAT, DPO_CHAT, etc.).
            train_kwargs: Provider-specific training hyperparameters
                (e.g., epochs, learning_rate, batch_size).

        Returns:
            A ``TrainingJob`` whose ``.result()`` yields the fine-tuned
            model identifier or engine.

        Raises:
            NotImplementedError: If this engine does not support fine-tuning.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support fine-tuning. "
            f"Use an engine with finetunable=True."
        )

    def reinforce(
        self,
        train_kwargs: dict[str, Any] | None = None,
    ) -> ReinforceJob:
        """Create an RL training session for multi-step training.

        Ported from DSPy's ``LM.reinforce()`` — creates a session
        that accepts iterative ``step()`` calls with GRPO-formatted
        training batches.

        Args:
            train_kwargs: Training hyperparameters including
                ``num_generations`` (rollouts per input).

        Returns:
            A ``ReinforceJob`` for submitting training steps.

        Raises:
            NotImplementedError: If this engine does not support RL.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support reinforcement learning. "
            f"Use an engine with reinforceable=True."
        )

    def to_config(self) -> dict[str, Any]:
        """Serialize engine configuration to a dictionary.

        Default implementation returns the class name and model. Subclasses
        should override to include provider-specific parameters.
        """
        return {
            "class": type(self).__name__,
            "model": self.model_name,
        }

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> EngineLM:
        """Reconstruct an engine from a config dictionary.

        Uses the ``EngineRegistry`` (if available) to resolve the class.
        Subclasses may override for custom deserialization.
        """
        # Lazy import to avoid circular dependency
        from learn.env.engine.registry import EngineRegistry

        return EngineRegistry.create_from_config(config)
