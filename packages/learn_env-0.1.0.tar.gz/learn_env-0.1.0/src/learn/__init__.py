"""
---
title: learn — Learning Environment for Agent Reasoning Networks
summary: >
    Unified framework for specifying, composing, optimizing, and evaluating
    LLM-based systems through natural language.
---

# learn — Learning Environment for Agent Reasoning Networks

One API for every Natural Language Programming process.

* [learn.env](env/) — The learning environment: programs, engines, management
* [learn.agent](agent/) — Autonomous agents: memory, tools, reasoning, profiles
* [learn.optim](optim/) — Optimization: numerical, textual, evolutionary, weight-space, meta
* [learn.benchmark](benchmark/) — Evaluation: tasks, scoring, protocols, statistics
"""
from __future__ import annotations

__version__ = "0.1.0"

# Convenience re-exports of the most commonly used primitives
from learn.env.program import Component, Parameter, Signature, TextState, Variable
from learn.env.engine import EngineLM, MockEngine
from learn.agent import Generator

__all__ = [
    "__version__",
    "Component",
    "EngineLM",
    "Generator",
    "MockEngine",
    "Parameter",
    "Signature",
    "TextState",
    "Variable",
]
