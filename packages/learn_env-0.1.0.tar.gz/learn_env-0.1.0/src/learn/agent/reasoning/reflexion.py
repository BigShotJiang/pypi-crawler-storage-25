"""
---
title: Reflexion Strategy
summary: >
    Generate → evaluate → reflect → retry loop. The agent reflects on
    failures and prepends the reflection to the next attempt.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

EVAL_PREFIX = "Evaluate this response on a scale of 1-10 and explain why:\n\n"
REFLECT_PREFIX = (
    "The response was not good enough. Reflect on what went wrong and "
    "suggest a concrete improvement strategy:\n\n"
)


class Reflexion(ReasoningStrategy):
    """Reflexion: generate → evaluate → reflect → retry.

    ```python
    strategy = Reflexion(max_iterations=3)
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(self, max_iterations: int = 3, threshold: float = 7.0) -> None:
        self.max_iterations = max_iterations
        self.threshold = threshold

    def apply(self, agent: Agent, state: TextState) -> TextState:
        current = agent.forward(state)

        for _ in range(self.max_iterations):
            if agent.engine is None:
                break

            # Evaluate
            eval_prompt = EVAL_PREFIX + current.observation
            evaluation = agent.engine.generate(eval_prompt)

            # Check if score meets threshold
            score = self._parse_score(evaluation)
            if score >= self.threshold:
                break

            # Reflect
            reflect_prompt = REFLECT_PREFIX + current.observation + "\n\nEvaluation: " + evaluation
            reflection = agent.engine.generate(reflect_prompt)

            # Retry with reflection context
            modified = state.update(
                observation=f"Previous reflection: {reflection}\n\n{state.observation}",
            )
            current = agent.forward(modified)

        return current

    @staticmethod
    def _parse_score(evaluation: str) -> float:
        """Extract a numeric score from the evaluation text."""
        for token in evaluation.split():
            try:
                val = float(token.strip(".,;:!/"))
                if 0 <= val <= 10:
                    return val
            except ValueError:
                continue
        return 0.0

    def __repr__(self) -> str:
        return f"Reflexion(max_iterations={self.max_iterations})"
