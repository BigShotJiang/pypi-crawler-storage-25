"""
---
title: LATS — Language Agent Tree Search
summary: >
    Tree search over agent reasoning traces with reflection-guided
    expansion and value estimation.
---

# LATS

Language Agent Tree Search combines MCTS-style search with
LLM-based value estimation and reflection for improved
reasoning over complex tasks.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


@dataclass
class LATSNode:
    """Node in the LATS search tree."""

    state: str
    parent: LATSNode | None = None
    children: list[LATSNode] = field(default_factory=list)
    visits: int = 0
    value: float = 0.0
    reflection: str = ""
    depth: int = 0

    @property
    def q_value(self) -> float:
        return self.value / max(self.visits, 1)

    def is_leaf(self) -> bool:
        return len(self.children) == 0


class LATS(ReasoningStrategy):
    r"""
    <a id="LATS"></a>

    ## LATS — Language Agent Tree Search

    ```python
    strategy = LATS(
        n_expansions=3,
        max_depth=5,
        n_iterations=10,
    )
    output = strategy.apply(agent, state)
    ```
    """

    VALUE_PROMPT = (
        "Evaluate how promising this reasoning trace is for solving "
        "the problem. Rate from 0.0 (hopeless) to 1.0 (very promising).\n\n"
        "Problem: {problem}\n\n"
        "Current reasoning:\n{trace}\n\n"
        "Rating (just the number):"
    )

    REFLECT_PROMPT = (
        "Reflect on this failed reasoning attempt. What went wrong?\n\n"
        "Problem: {problem}\n\n"
        "Attempt:\n{trace}\n\n"
        "Reflection:"
    )

    def __init__(
        self,
        n_expansions: int = 3,
        max_depth: int = 5,
        n_iterations: int = 10,
    ) -> None:
        self.n_expansions = n_expansions
        self.max_depth = max_depth
        self.n_iterations = n_iterations

    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply LATS search.

        Args:
            agent: The agent for generation and evaluation.
            state: Input state with problem in ``observation``.

        Returns:
            TextState with the best found answer.
        """
        problem = state.observation
        root = LATSNode(state=problem)

        for _ in range(self.n_iterations):
            # Select leaf node
            leaf = self._select(root)

            if leaf.depth >= self.max_depth:
                continue

            # Expand: generate multiple continuations
            children = self._expand(agent, state, leaf, problem)
            leaf.children.extend(children)

            # Evaluate each child
            for child in children:
                value = self._evaluate(agent, state, child, problem)
                child.value = value
                child.visits = 1
                # Backpropagate
                self._backpropagate(child, value)

        # Return the best path
        best_leaf = self._best_leaf(root)
        return state.update(
            observation=best_leaf.state,
            metadata={**state.metadata, "_lats_root": root},
        )

    def _select(self, node: LATSNode) -> LATSNode:
        """Select a leaf node using UCB1."""
        import math

        while not node.is_leaf():
            # UCB1 selection
            best_score = float("-inf")
            best_child = node.children[0]
            for child in node.children:
                if child.visits == 0:
                    return child
                exploit = child.q_value
                explore = 1.414 * math.sqrt(
                    math.log(node.visits) / child.visits
                )
                score = exploit + explore
                if score > best_score:
                    best_score = score
                    best_child = child
            node = best_child
        return node

    def _expand(
        self,
        agent: Agent,
        state: TextState,
        node: LATSNode,
        problem: str,
    ) -> list[LATSNode]:
        """Generate multiple continuations from a node."""
        children = []
        context = f"Problem: {problem}\n\nCurrent progress:\n{node.state}"
        if node.reflection:
            context += f"\n\nReflection from previous attempt:\n{node.reflection}"

        for _ in range(self.n_expansions):
            expand_state = state.update(observation=context)
            output = agent.forward(expand_state)
            child = LATSNode(
                state=output.observation,
                parent=node,
                depth=node.depth + 1,
            )
            children.append(child)
        return children

    def _evaluate(
        self,
        agent: Agent,
        state: TextState,
        node: LATSNode,
        problem: str,
    ) -> float:
        """Estimate the value of a node."""
        prompt = self.VALUE_PROMPT.format(
            problem=problem, trace=node.state,
        )
        eval_state = state.update(observation=prompt)
        output = agent.forward(eval_state)
        try:
            return float(output.observation.strip().split()[0])
        except (ValueError, IndexError):
            return 0.5

    def _backpropagate(self, node: LATSNode, value: float) -> None:
        """Propagate value up to root."""
        current: LATSNode | None = node
        while current is not None:
            current.visits += 1
            current.value += value
            current = current.parent

    def _best_leaf(self, root: LATSNode) -> LATSNode:
        """Find the highest-value leaf in the tree."""
        best = root
        stack = [root]
        while stack:
            node = stack.pop()
            if node.is_leaf() and node.q_value > best.q_value:
                best = node
            stack.extend(node.children)
        return best
