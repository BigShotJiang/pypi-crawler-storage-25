"""
---
title: PlanAndSolve — Plan-and-Solve Reasoning Strategy
summary: >
    Decomposes complex problems into subtask plans, then executes
    each subtask sequentially using the agent.
---

# Plan-and-Solve

Two-stage reasoning:
1. **Plan**: Ask the LLM to decompose the problem into steps
2. **Solve**: Execute each step, feeding results from previous steps

"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


class PlanAndSolve(ReasoningStrategy):
    r"""
    <a id="PlanAndSolve"></a>

    ## PlanAndSolve

    ```python
    strategy = PlanAndSolve(max_steps=5)
    output = strategy.apply(agent, state)
    ```
    """

    PLAN_PREFIX = (
        "Let's first understand the problem and devise a plan to solve it. "
        "Then, let's carry out the plan step by step.\n\n"
        "Problem: {problem}\n\n"
        "Plan (list numbered steps):"
    )

    STEP_PREFIX = (
        "You are solving a problem step by step.\n\n"
        "Original problem: {problem}\n\n"
        "Plan:\n{plan}\n\n"
        "Steps completed so far:\n{completed}\n\n"
        "Now execute step {step_num}: {step_description}\n"
        "Provide only the result for this step."
    )

    def __init__(self, max_steps: int = 10) -> None:
        self.max_steps = max_steps

    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply plan-and-solve to the agent's execution.

        Args:
            agent: The agent to use for each step.
            state: Input state with the problem in ``observation``.

        Returns:
            TextState with the final answer.
        """
        problem = state.observation

        # Phase 1: Generate plan
        plan_prompt = self.PLAN_PREFIX.format(problem=problem)
        plan_state = state.update(observation=plan_prompt)
        plan_output = agent.forward(plan_state)
        plan_text = plan_output.observation

        # Parse steps from plan
        steps = self._parse_steps(plan_text)
        if not steps:
            return plan_output

        # Phase 2: Execute each step
        completed: list[str] = []
        for i, step_desc in enumerate(steps[: self.max_steps], 1):
            completed_text = "\n".join(
                f"Step {j}: {c}" for j, c in enumerate(completed, 1)
            ) or "(none yet)"

            step_prompt = self.STEP_PREFIX.format(
                problem=problem,
                plan=plan_text,
                completed=completed_text,
                step_num=i,
                step_description=step_desc,
            )
            step_state = state.update(observation=step_prompt)
            step_output = agent.forward(step_state)
            completed.append(step_output.observation)

        # Return the final step result
        final = completed[-1] if completed else plan_output.observation
        return state.update(
            observation=final,
            metadata={
                **state.metadata,
                "_plan": plan_text,
                "_steps": completed,
            },
        )

    @staticmethod
    def _parse_steps(plan_text: str) -> list[str]:
        """Extract numbered steps from plan text."""
        import re

        steps = []
        for match in re.finditer(r"^\s*\d+[\.\)]\s*(.+)$", plan_text, re.MULTILINE):
            steps.append(match.group(1).strip())
        return steps
