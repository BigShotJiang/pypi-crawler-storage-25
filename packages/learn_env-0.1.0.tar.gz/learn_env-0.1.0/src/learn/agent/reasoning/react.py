"""
---
title: ReAct Strategy — Interleaved Reasoning and Acting
summary: >
    Prepends ReAct-style reasoning instructions to the agent's input,
    encouraging interleaved thought and action traces.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

REACT_INSTRUCTION = (
    "Use the following format:\n"
    "{thought_prefix}<your reasoning about what to do>\n"
    "{action_prefix}<the action to take>\n"
    "Observation: <result of the action>\n"
    "... (repeat as needed)\n"
    "Final Answer: <your final answer>\n\n"
)


class ReAct(ReasoningStrategy):
    """ReAct: interleaved reasoning and acting.

    ```python
    strategy = ReAct(max_steps=5)
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(
        self,
        max_steps: int = 5,
        thought_prefix: str = "Thought: ",
        action_prefix: str = "Action: ",
    ) -> None:
        self.max_steps = max_steps
        self.thought_prefix = thought_prefix
        self.action_prefix = action_prefix

    def apply(self, agent: Agent, state: TextState) -> TextState:
        instruction = REACT_INSTRUCTION.format(
            thought_prefix=self.thought_prefix,
            action_prefix=self.action_prefix,
        )
        modified = state.update(
            observation=instruction + state.observation,
        )
        return agent.forward(modified)

    def __repr__(self) -> str:
        return f"ReAct(max_steps={self.max_steps})"
