"""
---
title: BeamSearch — Beam Search Reasoning Strategy
summary: >
    Maintains k best reasoning paths at each step, exploring
    multiple candidates before selecting the best final answer.
---

# Beam Search

Maintains a beam of ``k`` candidate solutions at each reasoning step.
Each candidate is extended by the agent, scored, and the top-k are
kept for the next iteration.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


@dataclass
class BeamCandidate:
    """A candidate in the beam."""

    text: str
    score: float = 0.0
    steps: list[str] = field(default_factory=list)


class BeamSearch(ReasoningStrategy):
    r"""
    <a id="BeamSearch"></a>

    ## BeamSearch

    ```python
    strategy = BeamSearch(
        beam_width=3,
        max_steps=5,
        score_fn=lambda text: evaluate(text),
    )
    output = strategy.apply(agent, state)
    ```
    """

    EXTEND_PROMPT = (
        "Continue solving this problem. Build on the partial solution.\n\n"
        "Problem: {problem}\n\n"
        "Partial solution:\n{partial}\n\n"
        "Next step:"
    )

    def __init__(
        self,
        beam_width: int = 3,
        max_steps: int = 5,
        score_fn: Callable[[str], float] | None = None,
        expansions_per_beam: int = 2,
    ) -> None:
        self.beam_width = beam_width
        self.max_steps = max_steps
        self.score_fn = score_fn
        self.expansions_per_beam = expansions_per_beam

    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply beam search reasoning.

        Args:
            agent: The agent for generating continuations.
            state: Input state with problem in ``observation``.

        Returns:
            TextState with the best-scoring answer.
        """
        problem = state.observation

        # Initialize beam from initial generation
        beam: list[BeamCandidate] = []
        for _ in range(self.beam_width):
            output = agent.forward(state)
            candidate = BeamCandidate(
                text=output.observation,
                steps=[output.observation],
            )
            candidate.score = self._score(candidate.text)
            beam.append(candidate)

        # Iterative beam expansion
        for step in range(1, self.max_steps):
            all_candidates: list[BeamCandidate] = []

            for candidate in beam:
                for _ in range(self.expansions_per_beam):
                    prompt = self.EXTEND_PROMPT.format(
                        problem=problem,
                        partial=candidate.text,
                    )
                    extend_state = state.update(observation=prompt)
                    output = agent.forward(extend_state)

                    new_text = candidate.text + "\n" + output.observation
                    new_candidate = BeamCandidate(
                        text=new_text,
                        steps=candidate.steps + [output.observation],
                    )
                    new_candidate.score = self._score(new_text)
                    all_candidates.append(new_candidate)

            # Keep top-k
            all_candidates.sort(key=lambda c: c.score, reverse=True)
            beam = all_candidates[: self.beam_width]

        # Return best
        best = max(beam, key=lambda c: c.score)
        return state.update(
            observation=best.text,
            metadata={
                **state.metadata,
                "_beam_score": best.score,
                "_beam_steps": best.steps,
            },
        )

    def _score(self, text: str) -> float:
        """Score a candidate."""
        if self.score_fn:
            return self.score_fn(text)
        # Default: longer = better (crude heuristic)
        return len(text.split())
