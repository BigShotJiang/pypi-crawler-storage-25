"""Agent reasoning strategies."""
from learn.agent.reasoning.adaptive import AdaptiveReasoning
from learn.agent.reasoning.base import ReasoningStrategy
from learn.agent.reasoning.beam import BeamSearch
from learn.agent.reasoning.composite import CompositeReasoning, ConditionalReasoning
from learn.agent.reasoning.consistency import SelfConsistency
from learn.agent.reasoning.cot import ChainOfThought, ZeroShotCoT
from learn.agent.reasoning.lats import LATS
from learn.agent.reasoning.plan_solve import PlanAndSolve
from learn.agent.reasoning.react import ReAct
from learn.agent.reasoning.reflexion import Reflexion
from learn.agent.reasoning.self_refine import SelfRefine
from learn.agent.reasoning.tree import TreeOfThoughts

__all__ = [
    "AdaptiveReasoning",
    "BeamSearch",
    "ChainOfThought",
    "CompositeReasoning",
    "ConditionalReasoning",
    "LATS",
    "PlanAndSolve",
    "ReAct",
    "ReasoningStrategy",
    "Reflexion",
    "SelfConsistency",
    "SelfRefine",
    "TreeOfThoughts",
    "ZeroShotCoT",
]
