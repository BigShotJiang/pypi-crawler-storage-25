"""
---
title: Self-Refine Strategy
summary: >
    Generate → self-critique → refine loop. Runs N iterations.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

CRITIQUE_PREFIX = "Review the following response and provide constructive feedback:\n\n"
REFINE_PREFIX = "Improve the following response based on the feedback:\n\nOriginal: {original}\n\nFeedback: {feedback}\n\nImproved response:"


class SelfRefine(ReasoningStrategy):
    """Self-refine: generate → critique → refine loop.

    ```python
    agent = Generator(engine=engine)
    strategy = SelfRefine(max_iterations=2)
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(self, max_iterations: int = 2) -> None:
        self.max_iterations = max_iterations

    def apply(self, agent: Agent, state: TextState) -> TextState:
        # Initial generation
        current = agent.forward(state)

        for _ in range(self.max_iterations):
            if agent.engine is None:
                break

            # Self-critique
            critique_prompt = CRITIQUE_PREFIX + current.observation
            feedback = agent.engine.generate(critique_prompt)

            # Refine
            refine_prompt = REFINE_PREFIX.format(
                original=current.observation,
                feedback=feedback,
            )
            refined = agent.engine.generate(refine_prompt)
            current = current.update(observation=refined)

        return current

    def __repr__(self) -> str:
        return f"SelfRefine(max_iterations={self.max_iterations})"
