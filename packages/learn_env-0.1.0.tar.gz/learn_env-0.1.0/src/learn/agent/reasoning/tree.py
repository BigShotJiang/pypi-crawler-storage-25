"""
---
title: Tree of Thoughts — BFS/DFS Search Over Reasoning Paths
summary: >
    Generates multiple candidate continuations at each depth level,
    evaluates them, and expands the best paths. Supports BFS and DFS.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

EVAL_PROMPT = "Rate the following partial solution on a scale of 1-10:\n\n{text}\n\nScore:"


class TreeOfThoughts(ReasoningStrategy):
    """Tree of Thoughts: BFS/DFS over reasoning paths.

    ```python
    strategy = TreeOfThoughts(max_depth=3, branching_factor=3, strategy="bfs")
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(
        self,
        max_depth: int = 3,
        branching_factor: int = 3,
        strategy: str = "bfs",
    ) -> None:
        self.max_depth = max_depth
        self.branching_factor = branching_factor
        self.strategy = strategy

    def apply(self, agent: Agent, state: TextState) -> TextState:
        if self.strategy == "dfs":
            return self._dfs(agent, state, depth=0)
        return self._bfs(agent, state)

    def _bfs(self, agent: Agent, state: TextState) -> TextState:
        """Breadth-first search over reasoning paths."""
        candidates: list[TextState] = [state]

        for _ in range(self.max_depth):
            next_candidates: list[tuple[float, TextState]] = []
            for cand in candidates:
                for _ in range(self.branching_factor):
                    result = agent.forward(cand)
                    score = self._evaluate(agent, result)
                    next_candidates.append((score, result))
            # Keep top candidates
            next_candidates.sort(key=lambda x: -x[0])
            candidates = [s for _, s in next_candidates[: self.branching_factor]]

        # Return the best
        best = candidates[0] if candidates else state
        return best

    def _dfs(self, agent: Agent, state: TextState, depth: int) -> TextState:
        """Depth-first search with backtracking."""
        if depth >= self.max_depth:
            return state

        best_score = -1.0
        best_result = state

        for _ in range(self.branching_factor):
            result = agent.forward(state)
            expanded = self._dfs(agent, result, depth + 1)
            score = self._evaluate(agent, expanded)
            if score > best_score:
                best_score = score
                best_result = expanded

        return best_result

    def _evaluate(self, agent: Agent, state: TextState) -> float:
        """Use the engine to score a partial solution."""
        if agent.engine is None:
            return 0.0
        prompt = EVAL_PROMPT.format(text=state.observation)
        response = agent.engine.generate(prompt)
        for token in response.split():
            try:
                val = float(token.strip(".,;:!/"))
                if 0 <= val <= 10:
                    return val
            except ValueError:
                continue
        return 5.0

    def __repr__(self) -> str:
        return (
            f"TreeOfThoughts(depth={self.max_depth}, "
            f"branch={self.branching_factor}, strategy={self.strategy!r})"
        )
