"""
---
title: Chain-of-Thought Reasoning
summary: >
    Prepends "Think step by step" to the agent's input to elicit
    structured reasoning traces.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

COT_PREFIX = "Let's think step by step.\n\n"


class ChainOfThought(ReasoningStrategy):
    """Chain-of-thought prompting strategy.

    Prepends a reasoning prompt to the observation before
    calling the agent's forward method.
    """

    def __init__(self, prefix: str = COT_PREFIX) -> None:
        self.prefix = prefix

    def apply(self, agent: Agent, state: TextState) -> TextState:
        modified = state.update(
            observation=self.prefix + state.observation,
        )
        return agent.forward(modified)

    def __repr__(self) -> str:
        return "ChainOfThought()"


class ZeroShotCoT(ChainOfThought):
    """Zero-shot chain-of-thought (no examples needed)."""

    def __init__(self) -> None:
        super().__init__(prefix="Let's think step by step.\n\n")
