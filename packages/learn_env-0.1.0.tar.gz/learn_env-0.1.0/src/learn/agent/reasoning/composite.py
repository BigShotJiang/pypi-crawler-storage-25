"""
---
title: CompositeReasoning — Chain Multiple Strategies
summary: >
    Combines multiple reasoning strategies into a pipeline.
    The output of one strategy feeds into the next.
---

# Composite Reasoning

Sequential or conditional composition of reasoning strategies.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


class CompositeReasoning(ReasoningStrategy):
    r"""
    <a id="CompositeReasoning"></a>

    ## CompositeReasoning

    Chains multiple reasoning strategies sequentially.

    ```python
    strategy = CompositeReasoning(strategies=[
        PlanAndSolve(),
        SelfRefine(max_iterations=2),
    ])
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(self, strategies: list[ReasoningStrategy] | None = None) -> None:
        self.strategies = strategies or []

    def add(self, strategy: ReasoningStrategy) -> None:
        """Add a strategy to the pipeline."""
        self.strategies.append(strategy)

    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply all strategies in sequence.

        Each strategy receives the output of the previous one.
        """
        current = state
        for strategy in self.strategies:
            current = strategy.apply(agent, current)
        return current


class ConditionalReasoning(ReasoningStrategy):
    r"""
    ## ConditionalReasoning

    Selects a reasoning strategy based on a condition function.

    ```python
    strategy = ConditionalReasoning(
        condition=lambda state: "math" in state.observation.lower(),
        if_true=PlanAndSolve(),
        if_false=ChainOfThought(),
    )
    ```
    """

    def __init__(
        self,
        condition: Callable[[TextState], bool],
        if_true: ReasoningStrategy,
        if_false: ReasoningStrategy,
    ) -> None:
        self.condition = condition
        self.if_true = if_true
        self.if_false = if_false

    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply the appropriate strategy based on the condition."""
        if self.condition(state):
            return self.if_true.apply(agent, state)
        return self.if_false.apply(agent, state)
