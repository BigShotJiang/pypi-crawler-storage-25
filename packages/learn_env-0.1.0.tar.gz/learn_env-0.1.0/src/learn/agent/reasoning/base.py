"""
---
title: ReasoningStrategy ABC
summary: >
    Abstract base class for cognitive strategies that wrap an agent's
    forward pass with structured reasoning patterns.
---
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


class ReasoningStrategy(ABC):
    """Base class for reasoning strategies.

    A strategy wraps an agent's forward pass with structured
    reasoning (e.g., chain-of-thought, self-refine, tree search).

    ```python
    class MyStrategy(ReasoningStrategy):
        def apply(self, agent, state):
            # Modify state, call agent.forward, postprocess
            return agent.forward(modified_state)
    ```
    """

    @abstractmethod
    def apply(self, agent: Agent, state: TextState) -> TextState:
        """Apply this reasoning strategy to the agent's execution."""
        ...

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"
