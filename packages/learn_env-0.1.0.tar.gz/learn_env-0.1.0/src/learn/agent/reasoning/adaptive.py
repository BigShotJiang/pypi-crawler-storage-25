"""
---
title: Adaptive Reasoning — Complexity-Based Strategy Selection
summary: >
    Selects a reasoning strategy based on task complexity. Asks the
    engine to classify the task, then dispatches to the appropriate strategy.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState

CLASSIFY_PROMPT = (
    "Classify the complexity of this task as exactly one of: simple, moderate, complex.\n\n"
    "Task: {task}\n\nComplexity:"
)


class AdaptiveReasoning(ReasoningStrategy):
    """Select reasoning strategy based on task complexity.

    ```python
    strategy = AdaptiveReasoning()
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(self, strategies: dict[str, ReasoningStrategy | None] | None = None) -> None:
        if strategies is not None:
            self.strategies = strategies
        else:
            from learn.agent.reasoning.cot import ChainOfThought
            from learn.agent.reasoning.self_refine import SelfRefine

            self.strategies: dict[str, ReasoningStrategy | None] = {
                "simple": None,
                "moderate": ChainOfThought(),
                "complex": SelfRefine(),
            }

    def apply(self, agent: Agent, state: TextState) -> TextState:
        complexity = self._classify(agent, state)
        strategy = self.strategies.get(complexity)
        if strategy is None:
            return agent.forward(state)
        return strategy.apply(agent, state)

    def _classify(self, agent: Agent, state: TextState) -> str:
        """Ask the engine to classify task complexity."""
        if agent.engine is None:
            return "simple"
        prompt = CLASSIFY_PROMPT.format(task=state.observation[:500])
        response = agent.engine.generate(prompt).strip().lower()
        for level in ("complex", "moderate", "simple"):
            if level in response:
                return level
        return "moderate"

    def __repr__(self) -> str:
        return f"AdaptiveReasoning(strategies={list(self.strategies.keys())})"
