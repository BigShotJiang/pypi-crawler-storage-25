"""
---
title: Self-Consistency Strategy — Majority Vote
summary: >
    Generates multiple candidate answers and picks the most common
    one via majority vote. Improves robustness on reasoning tasks.
---
"""
from __future__ import annotations

from collections import Counter
from typing import TYPE_CHECKING

from learn.agent.reasoning.base import ReasoningStrategy

if TYPE_CHECKING:
    from learn.agent.base import Agent
    from learn.env.program.variable import TextState


class SelfConsistency(ReasoningStrategy):
    """Self-consistency: majority vote over multiple generations.

    ```python
    strategy = SelfConsistency(n_samples=5)
    output = strategy.apply(agent, state)
    ```
    """

    def __init__(self, n_samples: int = 5) -> None:
        self.n_samples = n_samples

    def apply(self, agent: Agent, state: TextState) -> TextState:
        outputs: list[str] = []
        for _ in range(self.n_samples):
            result = agent.forward(state)
            outputs.append(result.observation)

        # Majority vote — normalize whitespace for comparison
        normalized = [o.strip() for o in outputs]
        counter = Counter(normalized)
        best_answer, _ = counter.most_common(1)[0]

        # Return the state with the majority answer
        return state.update(observation=best_answer)

    def __repr__(self) -> str:
        return f"SelfConsistency(n_samples={self.n_samples})"
