"""
---
title: Tool ABC + ToolRegistry
summary: >
    Abstract base class for tools and a dynamic registry for
    tool discovery and prompt rendering.
---
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


class Tool(ABC):
    """Base class for all tools.

    ```python
    class Calculator(Tool):
        name = "calculator"
        description = "Evaluate math expressions."

        def execute(self, input: dict) -> dict:
            return {"result": str(eval(input["expression"]))}
    ```
    """

    name: str = ""
    description: str = ""

    @abstractmethod
    def execute(self, input: dict[str, Any]) -> dict[str, Any]:
        """Execute the tool with the given input."""
        ...

    def __call__(self, input: dict[str, Any]) -> dict[str, Any]:
        return self.execute(input)

    def __repr__(self) -> str:
        return f"Tool({self.name!r})"


@dataclass
class NLToolSpec:
    """Natural-language tool specification for LLM prompt inclusion."""

    name: str
    description: str
    parameters: list[dict[str, str]] = field(default_factory=list)
    returns: str = ""

    def to_prompt(self) -> str:
        """Render as a string for LLM consumption."""
        parts = [f"- **{self.name}**: {self.description}"]
        if self.parameters:
            params = ", ".join(
                f"{p.get('name', '?')}: {p.get('type', 'str')}"
                for p in self.parameters
            )
            parts.append(f"  Parameters: {params}")
        if self.returns:
            parts.append(f"  Returns: {self.returns}")
        return "\n".join(parts)


class ToolRegistry:
    """Dynamic catalog of available tools.

    ```python
    registry = ToolRegistry()
    registry.register(Calculator())
    tool = registry.get("calculator")
    prompt_text = registry.to_prompt()
    ```
    """

    def __init__(self, tools: list[Tool] | None = None) -> None:
        self._tools: dict[str, Tool] = {}
        for tool in (tools or []):
            self.register(tool)

    def register(self, tool: Tool) -> None:
        """Register a tool by its name."""
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        """Get a tool by name."""
        if name not in self._tools:
            raise KeyError(f"Tool not found: {name!r}")
        return self._tools[name]

    def list_tools(self) -> list[str]:
        """Return names of all registered tools."""
        return list(self._tools.keys())

    def to_prompt(self) -> str:
        """Render all tool descriptions for LLM prompt inclusion."""
        specs = [
            NLToolSpec(name=t.name, description=t.description)
            for t in self._tools.values()
        ]
        return "\n".join(s.to_prompt() for s in specs)

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        return f"ToolRegistry(tools={self.list_tools()})"
