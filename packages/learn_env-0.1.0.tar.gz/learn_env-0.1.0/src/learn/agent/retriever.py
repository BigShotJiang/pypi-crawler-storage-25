"""
---
title: Retriever Agent
summary: >
    Agent that retrieves relevant information from a corpus or
    callable retrieval function.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from learn.agent.base import Agent
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Retriever(Agent):
    """Retrieves relevant information given an observation.

    ```python
    def my_search(query: str) -> list[str]:
        return ["result 1", "result 2"]

    agent = Retriever(retrieval_fn=my_search, top_k=3)
    output = agent(TextState(observation="What is X?"))
    # output.observation contains concatenated retrieval results
    ```
    """

    def __init__(
        self,
        retrieval_fn: Callable[[str], list[str]],
        top_k: int = 5,
        engine: EngineLM | None = None,
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Retriever", skills=skills)
        self.retrieval_fn = retrieval_fn
        self.top_k = top_k

    def forward(self, state: TextState) -> TextState:
        results = self.retrieval_fn(state.observation)[:self.top_k]
        formatted = "\n\n".join(f"[{i+1}] {r}" for i, r in enumerate(results))
        return state.update(observation=formatted)
