"""
---
title: Reviewer Agent
summary: >
    Agent that evaluates and critiques input, producing feedback.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState, Variable
from learn.optim.txt.autograd.llm_call import LLMCall

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Reviewer(Agent):
    """Reviews and critiques input, producing structured feedback.

    ```python
    reviewer = Reviewer(engine=engine, criteria="clarity, accuracy")
    output = reviewer(TextState(observation="draft text..."))
    # output.observation contains the review/feedback
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        criteria: str = "quality, accuracy, clarity",
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Reviewer", skills=skills)
        self._llm_call = LLMCall(engine)

        self.system_prompt = Parameter(
            data="You are an expert reviewer. Provide constructive feedback.",
            param_type=ParameterType.PROMPT,
            role_description="reviewer system prompt",
            requires_opt=True,
        )

        self.criteria = Parameter(
            data=criteria,
            param_type=ParameterType.INSTRUCTION,
            role_description="review criteria",
            requires_opt=True,
        )

    def forward(self, state: TextState) -> TextState:
        prompt = (
            f"Review the following content on these criteria: {self.criteria.data}\n\n"
            f"Content:\n{state.observation}"
        )
        input_var = Variable(
            data=prompt,
            role_description="review input",
            requires_grad=False,
        )
        output_var = self._llm_call.forward(
            input_var, system_prompt=self.system_prompt.data,
        )
        return state.update(observation=output_var.data)
