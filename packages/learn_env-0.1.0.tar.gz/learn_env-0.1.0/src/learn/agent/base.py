"""
---
title: Agent ABC — Base Agent Class
summary: >
    Abstract base class for all agents. Extends Component with engine,
    forward/call semantics, skill bindings, and optional sub-systems
    (memory, tools, reasoning, profile).
---

# Agent Base

The Agent is a higher-level wrapper around Component that owns:

* ``engine`` — LLM backend for text generation
* ``skills`` — named Skill instances the agent can dispatch to
* ``forward()`` — core logic (must override)
* ``__call__()`` — applies reasoning strategy if present, else forward()

| ``nn.Module`` | ``Agent`` |
|--------------|----------|
| ``forward()`` | ``forward(state) → TextState`` |
| ``__call__()`` | ``__call__(state) → TextState`` |
| ``self.training`` | ``self.training`` |

## Skill Integration

Agents can be initialized with a dictionary of named skills. Each skill
is auto-registered as a sub-component (so ``parameters(recursive=True)``
discovers skill prompts) and is accessible via ``get_skill(name)`` or
``dispatch_skill(name, state)``.

```python
agent = MyAgent(
    engine=engine,
    skills={"summarize": summarize_skill, "classify": classify_skill},
)
# Skills are registered as sub-components
list(agent.parameters(recursive=True))  # includes skill parameters
# Dispatch to a specific skill
output = agent.dispatch_skill("summarize", state)
```
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Optional

from learn.env.program.variable import Component, TextState

if TYPE_CHECKING:
    from learn.agent.skill.base import Skill
    from learn.env.engine.base import EngineLM


class Agent(Component, ABC):
    r"""
    <a id="Agent"></a>

    ## Agent

    Abstract base class for all agents in the learn framework.
    Extends ``Component`` with an engine, skill bindings, and
    forward/call semantics.

    Subclasses must implement ``forward(state: TextState) → TextState``.

    ```python
    class MyAgent(Agent):
        def forward(self, state: TextState) -> TextState:
            response = self.engine.generate(state.observation)
            return state.update(observation=response)

    agent = MyAgent(engine=engine)
    output = agent(TextState(observation="Hello"))
    ```

    ### Skill-Aware Agent

    ```python
    agent = MyAgent(
        engine=engine,
        skills={"summarize": summarize_skill, "lookup": retrieval_skill},
    )
    # Dispatch to a named skill
    result = agent.dispatch_skill("summarize", state)
    # All skill parameters are discoverable
    list(agent.parameters(recursive=True))
    ```
    """

    def __init__(
        self,
        engine: Optional[EngineLM] = None,
        *,
        name: str | None = None,
        skills: dict[str, Skill] | None = None,
    ) -> None:
        super().__init__(name=name)
        self.engine = engine

        # Tracing for debugging / optimization
        self.tracing: bool = False
        self._trace_log: list[tuple[TextState, TextState]] = []

        # --- Skill bindings ---
        # Skills are registered as sub-components so that
        # ``parameters(recursive=True)`` includes skill Parameters
        # (e.g. ``skill_prompt`` in LLMSkill).
        self._skills: dict[str, Skill] = {}
        if skills:
            for skill_name, skill in skills.items():
                self.add_skill(skill_name, skill)

    # ------------------------------------------------------------------
    # Skill management
    # ------------------------------------------------------------------

    def add_skill(self, skill_name: str, skill: Skill) -> None:
        """Register a named skill on this agent.

        The skill is stored in ``_skills`` *and* registered as a
        sub-component under ``skill_{name}`` so that
        ``parameters(recursive=True)`` discovers its learnable prompts.

        Args:
            skill_name: Short identifier (e.g. ``"summarize"``).
            skill: A ``Skill`` instance.
        """
        self._skills[skill_name] = skill
        self.register_component(f"skill_{skill_name}", skill)

    def get_skill(self, skill_name: str) -> Skill:
        """Look up a registered skill by name.

        Raises:
            KeyError: If no skill with that name is registered.
        """
        if skill_name not in self._skills:
            raise KeyError(
                f"Agent {self.name!r} has no skill named {skill_name!r}. "
                f"Available: {list(self._skills)}"
            )
        return self._skills[skill_name]

    def list_skills(self) -> list[str]:
        """Return the names of all registered skills."""
        return list(self._skills)

    def has_skill(self, skill_name: str) -> bool:
        """Check whether a named skill is registered."""
        return skill_name in self._skills

    def dispatch_skill(
        self,
        skill_name: str,
        state: TextState,
        **kwargs: Any,
    ) -> TextState:
        """Execute a named skill on the given state.

        This is the primary API for agents to invoke their skills during
        ``forward()``. The skill's ``__call__`` is used so tracing and
        callbacks propagate correctly.

        Args:
            skill_name: Name of the skill to dispatch to.
            state: Input TextState.
            **kwargs: Passed through to the skill.

        Returns:
            Output TextState from the skill.
        """
        skill = self.get_skill(skill_name)
        return skill(state, **kwargs)

    def get_skills(self) -> dict[str, Skill]:
        """Return a copy of the registered skills dict."""
        return dict(self._skills)

    # ------------------------------------------------------------------
    # Core abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def forward(self, state: TextState) -> TextState:
        """Core agent logic. Must be overridden by subclasses.

        Args:
            state: Input TextState.

        Returns:
            Output TextState with updated fields.
        """
        ...

    def __call__(self, state: TextState, **kwargs: Any) -> TextState:
        """Run the agent, optionally through a reasoning strategy.

        Args:
            state: Input TextState.
            **kwargs: Passed to forward().

        Returns:
            Output TextState.
        """
        output = self.forward(state, **kwargs)

        if self.tracing:
            self._trace_log.append((state, output))

        return output

    def get_trace(self) -> list[tuple[TextState, TextState]]:
        """Return the trace log (input, output) pairs."""
        return list(self._trace_log)

    def clear_trace(self) -> None:
        """Clear the trace log."""
        self._trace_log.clear()
