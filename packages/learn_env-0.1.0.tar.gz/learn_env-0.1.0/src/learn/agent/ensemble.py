"""
---
title: Ensemble Agent
summary: >
    Aggregates outputs from multiple upstream agents using strategies
    like majority vote, merge, or best-of-n.
---
"""
from __future__ import annotations

from collections import Counter
from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Ensemble(Agent):
    """Aggregates outputs from multiple agents.

    ```python
    ensemble = Ensemble(
        agents=[agent1, agent2, agent3],
        strategy="majority_vote",
    )
    output = ensemble(TextState(observation="What is 2+2?"))
    ```
    """

    def __init__(
        self,
        agents: list[Agent],
        strategy: str = "majority_vote",
        engine: EngineLM | None = None,
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Ensemble", skills=skills)
        self.agents = agents
        self.strategy = strategy

    def forward(self, state: TextState) -> TextState:
        outputs = [agent(state) for agent in self.agents]
        responses = [o.observation for o in outputs]

        if self.strategy == "majority_vote":
            result = self._majority_vote(responses)
        elif self.strategy == "concat":
            result = self._concat(responses)
        elif self.strategy == "best_of_n" and self.engine is not None:
            result = self._best_of_n(responses, state.observation)
        else:
            result = self._concat(responses)

        return state.update(
            observation=result,
            metadata={**state.metadata, "_ensemble_count": len(responses)},
        )

    @staticmethod
    def _majority_vote(responses: list[str]) -> str:
        normalized = [r.strip().lower() for r in responses]
        counter = Counter(normalized)
        winner = counter.most_common(1)[0][0]
        # Return the original-cased version
        for r in responses:
            if r.strip().lower() == winner:
                return r
        return responses[0]

    @staticmethod
    def _concat(responses: list[str]) -> str:
        parts = [f"Response {i+1}: {r}" for i, r in enumerate(responses)]
        return "\n\n".join(parts)

    def _best_of_n(self, responses: list[str], question: str) -> str:
        """Use LLM to pick the best response."""
        candidates = "\n\n".join(
            f"Option {i+1}: {r}" for i, r in enumerate(responses)
        )
        prompt = (
            f"Question: {question}\n\n"
            f"{candidates}\n\n"
            "Which option is the best answer? Reply with only the option number."
        )
        choice = self.engine.generate(prompt).strip()
        # Parse the number
        for i, r in enumerate(responses):
            if str(i + 1) in choice:
                return r
        return responses[0]
