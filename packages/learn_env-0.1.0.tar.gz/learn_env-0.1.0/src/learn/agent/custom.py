"""
---
title: Custom Agent — Configurable Agent with Multiple Parameters
summary: >
    A flexible agent that can be configured with multiple learnable
    parameters: system prompt, instruction, and output format.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState, Variable
from learn.optim.txt.autograd.llm_call import LLMCall

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Custom(Agent):
    r"""
    <a id="Custom"></a>

    ## Custom Agent

    A flexible agent with multiple learnable parameters that can be
    independently optimized.

    ```python
    agent = Custom(
        engine=engine,
        system_prompt="You are a math solver.",
        instruction="Solve step by step.",
        output_format="Answer: {answer}",
    )
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        system_prompt: str = "You are a helpful assistant.",
        instruction: str = "",
        output_format: str = "",
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Custom", skills=skills)
        self._llm_call = LLMCall(engine)

        self.system_prompt = Parameter(
            data=system_prompt,
            param_type=ParameterType.PROMPT,
            role_description="system prompt",
            requires_opt=True,
        )

        self.instruction = Parameter(
            data=instruction,
            param_type=ParameterType.INSTRUCTION,
            role_description="task instruction",
            requires_opt=bool(instruction),
        )

        self.output_format = Parameter(
            data=output_format,
            param_type=ParameterType.INSTRUCTION,
            role_description="output format specification",
            requires_opt=bool(output_format),
        )

    def forward(self, state: TextState) -> TextState:
        """Build a prompt from learnable parameters and call the LLM."""
        parts: list[str] = []

        if self.instruction.data:
            parts.append(f"Instruction: {self.instruction.data}")

        parts.append(state.observation)

        if self.output_format.data:
            parts.append(f"Output format: {self.output_format.data}")

        combined = "\n\n".join(parts)

        input_var = Variable(
            data=combined,
            role_description="formatted input",
            requires_grad=False,
        )

        output_var = self._llm_call.forward(
            input_var,
            system_prompt=self.system_prompt.data,
        )

        return state.update(
            observation=output_var.data,
            metadata={**state.metadata, "_last_output_var": output_var},
        )
