"""
---
title: AgentMessage — Multi-Agent Communication Protocol
summary: >
    Typed message passing for multi-agent systems with topology-based
    routing. Addresses API Issue #17.
---

# Multi-Agent Communication

Provides a typed message protocol and agent topology for structured
multi-agent interaction (GenoMAS-style).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable


class MessageType(Enum):
    """Standard message types for multi-agent communication."""

    TASK = auto()
    RESPONSE = auto()
    CODE = auto()
    REVIEW = auto()
    REVISION = auto()
    PLANNING = auto()
    STATUS = auto()
    ERROR = auto()
    TIMEOUT = auto()
    CUSTOM = auto()


@dataclass
class AgentMessage:
    """A typed message between agents.

    Attributes:
        sender: Name/ID of the sending agent.
        receiver: Name/ID of the intended receiver (or ``"*"`` for broadcast).
        msg_type: Category of the message.
        content: Message body text.
        metadata: Additional key-value data.
    """

    sender: str
    receiver: str
    msg_type: MessageType
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentTopology:
    r"""
    <a id="AgentTopology"></a>

    ## AgentTopology

    Directed graph constraining which agents can communicate. Edges
    define allowed (sender → receiver) channels.

    ```python
    topo = AgentTopology()
    topo.add_agent("reviewer")
    topo.add_agent("coder")
    topo.allow("reviewer", "coder")  # reviewer can send to coder
    topo.can_send("reviewer", "coder")  # True
    topo.can_send("coder", "reviewer")  # False
    ```
    """

    def __init__(self) -> None:
        self._agents: set[str] = set()
        self._edges: set[tuple[str, str]] = set()

    def add_agent(self, name: str) -> None:
        """Register an agent in the topology."""
        self._agents.add(name)

    def allow(self, sender: str, receiver: str) -> None:
        """Allow ``sender`` to send messages to ``receiver``."""
        self._agents.add(sender)
        self._agents.add(receiver)
        self._edges.add((sender, receiver))

    def allow_bidirectional(self, a: str, b: str) -> None:
        """Allow communication in both directions."""
        self.allow(a, b)
        self.allow(b, a)

    def can_send(self, sender: str, receiver: str) -> bool:
        """Check if ``sender`` is allowed to message ``receiver``."""
        return (sender, receiver) in self._edges

    def receivers_for(self, sender: str) -> list[str]:
        """All agents that ``sender`` can message."""
        return [r for s, r in self._edges if s == sender]

    def senders_for(self, receiver: str) -> list[str]:
        """All agents that can message ``receiver``."""
        return [s for s, r in self._edges if r == receiver]

    @property
    def agents(self) -> list[str]:
        return sorted(self._agents)


class MessageBus:
    r"""
    <a id="MessageBus"></a>

    ## MessageBus

    Central message queue for multi-agent systems. Enforces topology
    constraints and dispatches messages to registered handlers.

    ```python
    bus = MessageBus(topology=topo)
    bus.register_handler("coder", handle_coder_messages)
    bus.send(AgentMessage("reviewer", "coder", MessageType.REVIEW, "LGTM"))
    ```
    """

    def __init__(self, topology: AgentTopology | None = None) -> None:
        self.topology = topology
        self._handlers: dict[str, Callable[[AgentMessage], None]] = {}
        self._queue: list[AgentMessage] = []
        self._history: list[AgentMessage] = []

    def register_handler(
        self,
        agent_name: str,
        handler: Callable[[AgentMessage], None],
    ) -> None:
        """Register a message handler for an agent."""
        self._handlers[agent_name] = handler

    def send(self, message: AgentMessage) -> bool:
        """Send a message, respecting topology constraints.

        Returns:
            True if message was delivered, False if blocked by topology.
        """
        if self.topology and not self.topology.can_send(
            message.sender, message.receiver
        ):
            return False

        self._history.append(message)

        # Broadcast
        if message.receiver == "*":
            for name, handler in self._handlers.items():
                if name != message.sender:
                    handler(message)
            return True

        # Direct delivery
        handler = self._handlers.get(message.receiver)
        if handler:
            handler(message)
        else:
            self._queue.append(message)
        return True

    def get_history(
        self,
        agent: str | None = None,
        msg_type: MessageType | None = None,
    ) -> list[AgentMessage]:
        """Retrieve message history with optional filters."""
        result = self._history
        if agent:
            result = [
                m for m in result
                if m.sender == agent or m.receiver == agent
            ]
        if msg_type:
            result = [m for m in result if m.msg_type == msg_type]
        return result

    def pending_for(self, agent: str) -> list[AgentMessage]:
        """Get and clear pending messages for an agent."""
        pending = [m for m in self._queue if m.receiver == agent]
        self._queue = [m for m in self._queue if m.receiver != agent]
        return pending
