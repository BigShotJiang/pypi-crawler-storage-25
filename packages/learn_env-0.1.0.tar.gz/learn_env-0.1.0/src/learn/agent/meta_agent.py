"""
---
title: MetaAgent — Self-Modifying Agent Wrapper
summary: >
    Wraps another agent and can modify its parameters or strategy
    based on execution feedback. Enables meta-learning loops.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from learn.agent.base import Agent
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM

REFLECT_PROMPT = (
    "The inner agent produced the following output for the given input.\n\n"
    "Input: {input}\nOutput: {output}\n\n"
    "Suggest a one-sentence improvement to the agent's system prompt to "
    "produce better results:"
)


class MetaAgent(Agent):
    """Agent that wraps and adapts another agent.

    ```python
    inner = Generator(engine=engine)
    meta = MetaAgent(inner_agent=inner, engine=engine)
    output = meta(TextState(observation="Solve x^2 = 4"))
    ```
    """

    def __init__(
        self,
        inner_agent: Agent,
        engine: Optional[EngineLM] = None,
        *,
        name: str | None = None,
        auto_reflect: bool = False,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine or inner_agent.engine, name=name or "MetaAgent", skills=skills)
        self.inner_agent = inner_agent
        self.auto_reflect = auto_reflect

    def forward(self, state: TextState) -> TextState:
        output = self.inner_agent(state)

        if self.auto_reflect and self.engine is not None:
            self._reflect_and_adapt(state, output)

        return output

    def _reflect_and_adapt(self, input_state: TextState, output_state: TextState) -> None:
        """Reflect on the inner agent's output and adapt its system prompt."""
        prompt = REFLECT_PROMPT.format(
            input=input_state.observation[:300],
            output=output_state.observation[:300],
        )
        suggestion = self.engine.generate(prompt).strip()

        # Apply suggestion to inner agent's system prompt if it has one
        if hasattr(self.inner_agent, "system_prompt"):
            current = self.inner_agent.system_prompt.data
            self.inner_agent.system_prompt.data = f"{current}\nNote: {suggestion}"

    def parameters(self):
        """Expose inner agent parameters for optimization."""
        yield from self.inner_agent.parameters()
