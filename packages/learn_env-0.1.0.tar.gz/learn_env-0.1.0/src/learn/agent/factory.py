"""
---
title: AgentFactory — Create Agents from Specs
summary: >
    Registry-based factory for creating agents by type name or from
    an AgentProfile specification.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from learn.agent.base import Agent

if TYPE_CHECKING:
    from learn.agent.profile.profile import AgentProfile
    from learn.env.engine.base import EngineLM


class AgentFactory:
    """Create agents by type name or profile.

    ```python
    AgentFactory.register("coder", Programmer)
    agent = AgentFactory.create("coder", engine=engine)
    ```
    """

    _registry: dict[str, type] = {}

    @classmethod
    def register(cls, name: str, agent_cls: type) -> None:
        """Register an agent class under a name."""
        cls._registry[name] = agent_cls

    @classmethod
    def create(cls, agent_type: str, **kwargs: Any) -> Agent:
        """Create an agent by registered type name."""
        if agent_type not in cls._registry:
            msg = f"Unknown agent type: {agent_type!r}. Registered: {list(cls._registry)}"
            raise KeyError(msg)
        return cls._registry[agent_type](**kwargs)

    @classmethod
    def from_profile(cls, profile: AgentProfile, engine: EngineLM | None = None) -> Agent:
        """Create a Generator agent from an AgentProfile."""
        from learn.agent.generator import Generator

        system_prompt = profile.to_prompt() or "You are a helpful assistant."
        return Generator(
            engine=engine,
            system_prompt=system_prompt,
            name=profile.role.title or "Agent",
        )

    @classmethod
    def list_registered(cls) -> list[str]:
        """Return all registered agent type names."""
        return list(cls._registry.keys())
