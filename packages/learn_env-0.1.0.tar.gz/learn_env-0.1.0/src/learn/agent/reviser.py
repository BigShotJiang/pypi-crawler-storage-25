"""
---
title: Reviser Agent
summary: >
    Agent that rewrites content based on feedback or constraints.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState, Variable
from learn.optim.txt.autograd.llm_call import LLMCall

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Reviser(Agent):
    """Revises content based on feedback.

    Expects ``state.scratchpad`` to contain review feedback.

    ```python
    reviser = Reviser(engine=engine)
    state = TextState(
        observation="original draft",
        scratchpad="feedback: needs more detail",
    )
    output = reviser(state)
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Reviser", skills=skills)
        self._llm_call = LLMCall(engine)

        self.system_prompt = Parameter(
            data="You are an expert editor. Revise content based on feedback.",
            param_type=ParameterType.PROMPT,
            role_description="reviser system prompt",
            requires_opt=True,
        )

    def forward(self, state: TextState) -> TextState:
        feedback = state.scratchpad or "No specific feedback."
        prompt = (
            f"Original content:\n{state.observation}\n\n"
            f"Feedback:\n{feedback}\n\n"
            f"Please revise the content based on the feedback above."
        )
        input_var = Variable(
            data=prompt,
            role_description="revision input",
            requires_grad=False,
        )
        output_var = self._llm_call.forward(
            input_var, system_prompt=self.system_prompt.data,
        )
        return state.update(observation=output_var.data)
