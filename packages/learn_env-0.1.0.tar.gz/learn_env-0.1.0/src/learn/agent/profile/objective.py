"""
---
title: ObjectiveSpec — Agent Objective Specification
summary: >
    Re-export of ObjectiveSpec from profile.py for modular imports.
---
"""
from learn.agent.profile.profile import ObjectiveSpec

__all__ = ["ObjectiveSpec"]
