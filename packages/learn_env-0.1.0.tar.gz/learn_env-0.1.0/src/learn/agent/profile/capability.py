"""
---
title: CapabilitySpec — Agent Capability Specification
summary: >
    Re-export of CapabilitySpec from profile.py for modular imports.
---
"""
from learn.agent.profile.profile import CapabilitySpec

__all__ = ["CapabilitySpec"]
