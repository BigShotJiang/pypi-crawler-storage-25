"""
---
title: ConstraintSpec — Agent Constraint Specification
summary: >
    Re-export of ConstraintSpec from profile.py for modular imports.
---
"""
from learn.agent.profile.profile import ConstraintSpec

__all__ = ["ConstraintSpec"]
