"""
---
title: CommunicationSpec — Agent Communication Specification
summary: >
    Specifies how an agent communicates: protocols, channels, formats.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CommunicationSpec:
    """How the agent communicates with other agents.

    Attributes:
        allowed_recipients: Agent names this agent can message.
        allowed_senders: Agent names that can message this agent.
        message_format: Expected message format (e.g., "json", "text").
        max_message_length: Token limit per message.
        protocols: Communication protocols supported.
    """

    allowed_recipients: list[str] = field(default_factory=list)
    allowed_senders: list[str] = field(default_factory=list)
    message_format: str = "text"
    max_message_length: int | None = None
    protocols: list[str] = field(default_factory=list)
