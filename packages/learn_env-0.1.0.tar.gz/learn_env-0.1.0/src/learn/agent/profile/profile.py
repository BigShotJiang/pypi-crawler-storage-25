"""
---
title: AgentProfile — Identity Specification
summary: >
    Dataclasses for declarative agent identity: role, capabilities,
    constraints, and objectives.
---
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RoleSpec:
    """What the agent does — title, responsibilities, expertise."""

    title: str = ""
    responsibilities: list[str] = field(default_factory=list)
    expertise: list[str] = field(default_factory=list)


@dataclass
class CapabilitySpec:
    """What the agent can do — tools, memory, reasoning."""

    tools: list[str] = field(default_factory=list)
    memory_types: list[str] = field(default_factory=list)
    reasoning_strategies: list[str] = field(default_factory=list)


@dataclass
class ConstraintSpec:
    """What the agent must not do — safety, resource limits."""

    forbidden_actions: list[str] = field(default_factory=list)
    max_tokens: int | None = None
    timeout_seconds: float | None = None


@dataclass
class ObjectiveSpec:
    """What the agent should optimize — metrics, criteria."""

    primary_metric: str = ""
    secondary_metrics: list[str] = field(default_factory=list)
    success_threshold: float | None = None


@dataclass
class AgentProfile:
    """Declarative specification of an agent's identity.

    ```python
    profile = AgentProfile(
        role=RoleSpec(title="Math Tutor", expertise=["algebra"]),
        capabilities=CapabilitySpec(tools=["calculator"]),
    )
    ```
    """

    role: RoleSpec = field(default_factory=RoleSpec)
    capabilities: CapabilitySpec = field(default_factory=CapabilitySpec)
    constraints: ConstraintSpec = field(default_factory=ConstraintSpec)
    objectives: ObjectiveSpec = field(default_factory=ObjectiveSpec)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_prompt(self) -> str:
        """Render profile as a prompt string for LLM consumption."""
        parts: list[str] = []
        if self.role.title:
            parts.append(f"Role: {self.role.title}")
        if self.role.responsibilities:
            parts.append(f"Responsibilities: {', '.join(self.role.responsibilities)}")
        if self.role.expertise:
            parts.append(f"Expertise: {', '.join(self.role.expertise)}")
        if self.capabilities.tools:
            parts.append(f"Available tools: {', '.join(self.capabilities.tools)}")
        if self.constraints.forbidden_actions:
            parts.append(f"Constraints: {', '.join(self.constraints.forbidden_actions)}")
        if self.objectives.primary_metric:
            parts.append(f"Objective: optimize {self.objectives.primary_metric}")
        return "\n".join(parts)
