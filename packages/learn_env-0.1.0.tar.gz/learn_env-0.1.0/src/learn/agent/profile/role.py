"""
---
title: RoleSpec — Agent Role Specification
summary: >
    Re-export of RoleSpec from profile.py for modular imports.
---
"""
from learn.agent.profile.profile import RoleSpec

__all__ = ["RoleSpec"]
