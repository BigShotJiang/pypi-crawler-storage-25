"""
---
title: SkillEvaluator — Multi-Dimensional Skill Scoring
summary: >
    LLM-judge-backed evaluator for skills, inspired by SkillNet's
    5-dimensional rubric (Safety, Completeness, Executability,
    Maintainability, Cost-awareness). Adapted to the ``learn`` agent
    setting with dimensions that map to framework-native quantities.
---

# SkillEvaluator

A ``SkillEvaluator`` answers the question *"is this skill any good?"*
along multiple axes. Unlike the benchmark-team scorers (which live in
``learn.benchmark`` and must not be imported here), the evaluator is
a pure ``learn.agent`` component: it takes an engine, a skill, and a
list of test cases, and returns a dict of floats.

| Dimension | What it measures |
|-----------|------------------|
| ``correctness`` | Does the output match the expected answer? |
| ``completeness`` | Does the skill cover edge cases? |
| ``efficiency`` | Resource use — tokens, calls, tool invocations. |
| ``reusability`` | Does the skill transfer to related tasks? |
| ``composability`` | How well it chains with other skills. |

The evaluator is self-contained (no ``learn.benchmark`` import) so it
respects the dependency rules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional

from learn.agent.skill.base import Skill
from learn.env.program.variable import Component, TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# =====================================================================
# TestCase — a single input/expected pair
# =====================================================================


@dataclass
class SkillTestCase:
    r"""
    <a id="SkillTestCase"></a>

    ## SkillTestCase

    One evaluation sample. ``input_state`` is fed to the skill and the
    output is compared against ``expected`` (if provided) or scored in
    isolation by an LLM judge.
    """

    input_state: TextState
    expected: Optional[str] = None
    tags: list[str] = field(default_factory=list)


# =====================================================================
# Evaluator
# =====================================================================


_RUBRIC_PROMPT = """You are a strict but fair skill evaluator.

Given:
- The DESCRIPTION of a skill
- A TEST INPUT the skill was run on
- The SKILL OUTPUT produced
- (Optional) the EXPECTED output

Score the output on these five dimensions. Each score is a float in
[0.0, 1.0] where 1.0 is perfect. Respond as plain `dimension: score`
lines, nothing else.

Dimensions:
- correctness:   did the output solve the task correctly?
- completeness:  did it cover the important aspects?
- efficiency:    is the output concise (no waste)?
- reusability:   would this skill work on similar future tasks?
- composability: does the output play nicely with other skills (clean
                 formatting, no stray metadata)?

SKILL DESCRIPTION: {description}

TEST INPUT:
{input}

SKILL OUTPUT:
{output}

EXPECTED:
{expected}

Respond with exactly 5 lines of `dimension: score`.
"""


class SkillEvaluator(Component):
    r"""
    <a id="SkillEvaluator"></a>

    ## SkillEvaluator

    LLM-judge-based evaluator. Calls the engine once per test case
    with the rubric prompt, parses per-dimension scores, and averages
    across cases.

    ```python
    judge = SkillEvaluator(engine=engine)
    scores = judge.evaluate(
        skill=my_skill,
        test_cases=[
            SkillTestCase(TextState(observation="Translate: hello"), "hola"),
        ],
    )
    # → {"correctness": 0.9, ...}
    ```

    The rubric is deliberately conservative — all five dimensions
    share the ``[0.0, 1.0]`` convention so a composite score is just
    the arithmetic mean.
    """

    DIMENSIONS: tuple[str, ...] = (
        "correctness",
        "completeness",
        "efficiency",
        "reusability",
        "composability",
    )

    def __init__(self, engine: EngineLM) -> None:
        super().__init__(name="SkillEvaluator")
        self.engine = engine

    # ------------------------------------------------------------------
    # Single-skill evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self,
        skill: Skill,
        test_cases: list[SkillTestCase],
    ) -> dict[str, float]:
        """Run the skill on each test case and average per-dimension scores.

        Args:
            skill: The skill to evaluate.
            test_cases: Non-empty list of ``SkillTestCase``.

        Returns:
            Mapping from dimension name to mean score in ``[0.0, 1.0]``.
            A ``"composite"`` entry is added as the arithmetic mean.
        """
        if not test_cases:
            raise ValueError("SkillEvaluator.evaluate requires test_cases.")

        sums = {dim: 0.0 for dim in self.DIMENSIONS}
        count = 0

        for case in test_cases:
            output_state = skill(case.input_state)
            scores = self._score_one(
                description=skill.spec.description,
                input_text=case.input_state.observation,
                output_text=output_state.observation,
                expected=case.expected or "(none)",
            )
            for dim in self.DIMENSIONS:
                sums[dim] += scores.get(dim, 0.0)
            count += 1

        result: dict[str, float] = {dim: sums[dim] / count for dim in self.DIMENSIONS}
        result["composite"] = sum(result.values()) / len(self.DIMENSIONS)
        return result

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _score_one(
        self,
        description: str,
        input_text: str,
        output_text: str,
        expected: str,
    ) -> dict[str, float]:
        """Call the LLM judge once and parse the rubric response."""
        prompt = _RUBRIC_PROMPT.format(
            description=description,
            input=input_text,
            output=output_text,
            expected=expected,
        )
        raw = self.engine.generate(prompt).strip()
        return self._parse_rubric(raw)

    @classmethod
    def _parse_rubric(cls, text: str) -> dict[str, float]:
        r"""Parse a block of ``dimension: score`` lines. Missing or
        unparseable dimensions default to ``0.0`` — a conservative
        choice that penalizes judges who fail to follow the format.
        """
        out = {dim: 0.0 for dim in cls.DIMENSIONS}
        for line in text.splitlines():
            if ":" not in line:
                continue
            dim, _, raw_score = line.partition(":")
            dim = dim.strip().lower()
            if dim not in out:
                continue
            cleaned = raw_score.strip().rstrip(",").rstrip(".")
            try:
                value = float(cleaned.split()[0])
            except (ValueError, IndexError):
                continue
            out[dim] = max(0.0, min(1.0, value))
        return out
