"""
---
title: Leaf Skills — LLMSkill, ToolSkill, RetrievalSkill
summary: >
    The three atomic skill types: a pure LLM call with a learnable
    prompt (``LLMSkill``), a thin wrapper around an external callable
    (``ToolSkill``), and a retrieval shim that injects documents into
    the agent's memory context (``RetrievalSkill``). These are the
    skill analogs of ``nn.Linear`` — the building blocks from which
    every composite topology is assembled.
---

# Leaf Skills

Leaf skills are indivisible: they do not contain other skills. The
three concrete leaves cover the three kinds of atomic action an agent
can take — *think* (LLM call), *act* (tool call), and *look up*
(retrieve knowledge). Everything else in the skill package is a
composition of leaves.

| Leaf | What it wraps | Learnable? |
|------|---------------|-----------|
| ``LLMSkill`` | a single ``engine.generate`` call | ``skill_prompt: Parameter`` |
| ``ToolSkill`` | an arbitrary ``Callable[[str], str]`` | No (add a Parameter if needed) |
| ``RetrievalSkill`` | a ``Callable[[str], list[str]]`` | No |
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.agent.skill.base import ExecutionMode, Skill, SkillSpec
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# =====================================================================
# LLMSkill — a single LLM call with a learnable prompt
# =====================================================================


class LLMSkill(Skill):
    r"""
    <a id="LLMSkill"></a>

    ## LLMSkill

    The skill analog of ``nn.Linear``: one LLM call, one learnable
    prompt, one output. The prompt is a ``Parameter`` so it is
    automatically picked up by ``parameters()`` and optimizable by any
    text-space optimizer:

    $$x_{t+1} = \text{LLM}(\text{skill\_prompt}_t, x_t)$$

    ```python
    skill = LLMSkill(
        spec=SkillSpec(name="summarizer",
                       description="Condense a passage to key points."),
        engine=engine,
        prompt="Summarize the following text in two sentences:",
    )
    out = skill(TextState(observation="Long text..."))
    ```

    The user-facing prompt template is:

        {skill_prompt}

        {state.to_prompt_str()}

    — i.e. the skill prompt is rendered as a system-style preamble and
    the ``TextState`` contents follow.
    """

    def __init__(
        self,
        spec: SkillSpec,
        engine: EngineLM,
        prompt: str,
        *,
        requires_opt: bool = True,
        name: Optional[str] = None,
    ) -> None:
        super().__init__(spec=spec, engine=engine, name=name)

        # The skill's system prompt is the *only* learnable surface of
        # a leaf LLMSkill. It is registered automatically by
        # ``Component.__setattr__``.
        self.skill_prompt = Parameter(
            data=prompt,
            param_type=ParameterType.PROMPT,
            role_description=f"skill prompt for {spec.name}",
            requires_opt=requires_opt,
            name=f"{spec.name}_prompt",
        )

    def forward(self, state: TextState) -> TextState:
        """Call the engine with ``skill_prompt`` as system prompt and
        the rendered ``TextState`` as user prompt.
        """
        if self.engine is None:
            raise RuntimeError(
                f"LLMSkill {self.spec.name!r} has no engine attached."
            )

        user_prompt = state.to_prompt_str() or state.observation or ""
        response = self.engine.generate(
            prompt=user_prompt,
            system_prompt=self.skill_prompt.data,
        )

        return state.update(observation=response)


# =====================================================================
# ToolSkill — a thin wrapper over an external callable
# =====================================================================


class ToolSkill(Skill):
    r"""
    <a id="ToolSkill"></a>

    ## ToolSkill

    Wraps an arbitrary ``Callable[[str], str]`` as a skill. The default
    mode is ``EXECUTABLE`` because a tool skill performs a concrete
    action rather than producing advice text.

    ```python
    def calculator(expr: str) -> str:
        return str(eval(expr, {"__builtins__": {}}))

    skill = ToolSkill(
        spec=SkillSpec(
            name="calculator",
            description="Evaluate a simple arithmetic expression.",
            execution_mode=ExecutionMode.EXECUTABLE,
        ),
        tool_fn=calculator,
    )
    ```

    The callable signature is intentionally the simplest possible —
    string in, string out — matching how ``Tool`` is wrapped elsewhere
    in ``learn.agent.tool``. A richer typed signature can be exposed
    via ``SkillSpec.signature``.
    """

    def __init__(
        self,
        spec: SkillSpec,
        tool_fn: Callable[[str], str],
        *,
        input_field: str = "observation",
        name: Optional[str] = None,
    ) -> None:
        # ToolSkill is inherently executable; upgrade the mode if the
        # caller left it as the KNOWLEDGE default so downstream safety
        # checks see the right value. Mutate in place (dataclass) to
        # keep any typed ``Signature`` object intact.
        if spec.execution_mode is ExecutionMode.KNOWLEDGE:
            spec.execution_mode = ExecutionMode.EXECUTABLE

        super().__init__(spec=spec, engine=None, name=name)
        self.tool_fn = tool_fn
        self.input_field = input_field

    def forward(self, state: TextState) -> TextState:
        """Run the wrapped tool on ``state.<input_field>`` and append
        the result to ``state.tool_results``.
        """
        argument = getattr(state, self.input_field, state.observation)
        result = self.tool_fn(argument)

        tool_results = list(state.tool_results) + [
            {"tool": self.spec.name, "input": argument, "result": result}
        ]
        return state.update(observation=result, tool_results=tool_results)


# =====================================================================
# RetrievalSkill — inject retrieved documents into the state
# =====================================================================


class RetrievalSkill(Skill):
    r"""
    <a id="RetrievalSkill"></a>

    ## RetrievalSkill

    Wraps a retriever callable ``Callable[[str], list[str]]`` as a
    skill. Unlike ``ToolSkill`` it does not overwrite the observation;
    it appends retrieved documents to both ``state.memory_context``
    and ``state.scratchpad`` so downstream skills can see them.

    ```python
    def retriever(query: str) -> list[str]:
        return vector_store.search(query, k=5)

    skill = RetrievalSkill(
        spec=SkillSpec(
            name="doc-lookup",
            description="Look up relevant documents for a query.",
        ),
        retriever=retriever,
    )
    ```
    """

    def __init__(
        self,
        spec: SkillSpec,
        retriever: Callable[[str], list[str]],
        *,
        top_k: int = 5,
        name: Optional[str] = None,
    ) -> None:
        super().__init__(spec=spec, engine=None, name=name)
        self.retriever = retriever
        self.top_k = top_k

    def forward(self, state: TextState) -> TextState:
        """Retrieve documents for ``state.observation`` and append them
        to ``state.memory_context`` (structured) and
        ``state.scratchpad`` (flattened).
        """
        query = state.observation
        docs = self.retriever(query)[: self.top_k]

        joined = "\n".join(f"- {d}" for d in docs)
        new_scratch = (
            state.scratchpad + f"\n[retrieved by {self.spec.name}]\n{joined}"
            if state.scratchpad
            else f"[retrieved by {self.spec.name}]\n{joined}"
        )
        return state.update(
            memory_context=list(state.memory_context) + list(docs),
            scratchpad=new_scratch,
        )


# =====================================================================
# Convenience constructor on LLMSkill
# =====================================================================


def _llm_skill_from_generator(
    generator: Any,
    spec: SkillSpec,
) -> LLMSkill:
    """Wrap an existing ``Generator`` as an ``LLMSkill`` that shares
    its system prompt.

    This is a convenience for turning a legacy agent into a skill
    without copying prompt text.
    """
    skill = LLMSkill(
        spec=spec,
        engine=generator.engine,
        prompt=generator.system_prompt.data,
    )
    skill.skill_prompt = generator.system_prompt
    return skill


# Attach as a classmethod after the fact to avoid a forward reference
# to ``Generator`` (which lives in ``learn.agent.generator``).
LLMSkill.from_generator = classmethod(  # type: ignore[attr-defined]
    lambda cls, generator, spec: _llm_skill_from_generator(generator, spec)
)
