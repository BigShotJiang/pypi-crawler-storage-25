"""
---
title: SkillRegistry — Catalog + Pluggable Retrieval
summary: >
    An in-memory catalog of ``Skill`` instances with pluggable search
    strategies. Supports exact name lookup, keyword scoring, and
    LLM-guided selection (SkillNet §2.1). Designed so ecosystem-scale
    retrieval backends (hierarchical trees, vector stores, remote
    services) can be added later as ``SearchStrategy`` plugins without
    touching the core API.
---

# SkillRegistry

The registry is the skill equivalent of ``torch.hub``: a central place
to register reusable building blocks and look them up later. Concrete
retrieval is implemented as a strategy so the same registry can serve
a 10-skill toy app and a 280 000-skill production deployment.

| Strategy | Cost | Good for |
|----------|------|----------|
| ``ExactMatchStrategy`` | O(1) | Known names, tests |
| ``KeywordStrategy`` | O(n) | Small–medium catalogs |
| ``LLMSearchStrategy`` | 1 LLM call | Semantic matching |
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Iterator, Optional

from learn.agent.skill.base import Skill, SkillSpec

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# =====================================================================
# SearchStrategy — plug-in interface
# =====================================================================


class SearchStrategy(ABC):
    r"""
    <a id="SearchStrategy"></a>

    ## SearchStrategy

    Abstract base class for skill retrieval strategies. A strategy is
    a pure function of ``(query, catalog) -> list[Skill]``.
    """

    @abstractmethod
    def search(
        self,
        query: str,
        catalog: dict[str, Skill],
        k: int = 5,
    ) -> list[Skill]:
        """Return up to ``k`` skills ranked by relevance to ``query``."""
        ...


class ExactMatchStrategy(SearchStrategy):
    """Look up a skill by its exact name (case-insensitive)."""

    def search(
        self,
        query: str,
        catalog: dict[str, Skill],
        k: int = 5,
    ) -> list[Skill]:
        lower = query.lower().strip()
        hits: list[Skill] = []
        for name, skill in catalog.items():
            if name.lower() == lower:
                hits.append(skill)
        return hits[:k]


class KeywordStrategy(SearchStrategy):
    r"""
    ## KeywordStrategy

    Simple bag-of-words scoring over the skill name, description, and
    tags. Good enough for catalogs up to a few thousand skills and
    zero-dependency (no embedding model required).

    Score contributions (additive):

    * +3.0 per query token that appears in the name,
    * +1.0 per query token in the description,
    * +2.0 per query token matching a tag exactly.
    """

    def search(
        self,
        query: str,
        catalog: dict[str, Skill],
        k: int = 5,
    ) -> list[Skill]:
        tokens = [t for t in query.lower().split() if t]
        if not tokens:
            return []

        scored: list[tuple[float, Skill]] = []
        for skill in catalog.values():
            name_l = skill.spec.name.lower()
            desc_l = skill.spec.description.lower()
            tags_l = {t.lower() for t in skill.spec.tags}
            score = 0.0
            for tok in tokens:
                if tok in name_l:
                    score += 3.0
                if tok in desc_l:
                    score += 1.0
                if tok in tags_l:
                    score += 2.0
            if score > 0:
                scored.append((score, skill))
        scored.sort(key=lambda x: (-x[0], x[1].spec.name))
        return [s for _, s in scored[:k]]


class LLMSearchStrategy(SearchStrategy):
    r"""
    ## LLMSearchStrategy

    SkillNet-style LLM-guided retrieval: format the whole catalog as a
    numbered list and ask the engine to pick the ``k`` best matches.
    Works for a few hundred skills; beyond that, cascade with
    ``KeywordStrategy`` first.

    ```python
    strat = LLMSearchStrategy(engine=engine)
    hits = registry.search("how do I summarize a PDF?", strategy=strat)
    ```
    """

    _PROMPT_TEMPLATE = (
        "You are a skill router. Given a user query and a catalog of "
        "available skills (each shown as `INDEX. name — description`), "
        "return the indexes of the up to {k} most relevant skills, "
        "separated by commas, in order from best to worst. Respond with "
        "ONLY the comma-separated indexes, nothing else.\n\n"
        "QUERY: {query}\n\n"
        "CATALOG:\n{catalog}\n\n"
        "ANSWER (comma-separated indexes):"
    )

    def __init__(self, engine: EngineLM) -> None:
        self.engine = engine

    def search(
        self,
        query: str,
        catalog: dict[str, Skill],
        k: int = 5,
    ) -> list[Skill]:
        if not catalog:
            return []

        skills = list(catalog.values())
        lines = [
            f"{i}. {s.spec.name} — {s.spec.description}"
            for i, s in enumerate(skills)
        ]
        prompt = self._PROMPT_TEMPLATE.format(
            k=k,
            query=query,
            catalog="\n".join(lines),
        )
        response = self.engine.generate(prompt).strip()

        # Parse comma-separated indexes, tolerate noise and dots.
        hits: list[Skill] = []
        for token in response.replace(".", ",").split(","):
            token = token.strip()
            if not token:
                continue
            try:
                idx = int(token)
            except ValueError:
                continue
            if 0 <= idx < len(skills):
                hits.append(skills[idx])
            if len(hits) >= k:
                break
        return hits


# =====================================================================
# SkillRegistry — the catalog
# =====================================================================


class SkillRegistry:
    r"""
    <a id="SkillRegistry"></a>

    ## SkillRegistry

    Central catalog of ``Skill`` instances. Supports name-based get,
    category filters, and pluggable retrieval.

    ```python
    registry = SkillRegistry()
    registry.register(summarizer_skill)
    registry.register(translator_skill)

    # Exact lookup
    skill = registry.get("summarizer")

    # Retrieval (default = KeywordStrategy)
    hits = registry.search("shorten this article", k=3)

    # Switch strategies
    registry.set_default_strategy(LLMSearchStrategy(engine))
    ```

    Duplicate registration raises ``KeyError`` by default; pass
    ``overwrite=True`` to replace an existing entry.
    """

    def __init__(
        self,
        default_strategy: Optional[SearchStrategy] = None,
    ) -> None:
        self._catalog: dict[str, Skill] = {}
        self._default_strategy: SearchStrategy = (
            default_strategy or KeywordStrategy()
        )

    # ------------------------------------------------------------------
    # Basic catalog operations
    # ------------------------------------------------------------------

    def register(self, skill: Skill, *, overwrite: bool = False) -> None:
        """Add a skill to the catalog."""
        name = skill.spec.name
        if name in self._catalog and not overwrite:
            raise KeyError(
                f"Skill {name!r} is already registered; "
                "pass overwrite=True to replace."
            )
        self._catalog[name] = skill

    def unregister(self, name: str) -> None:
        """Remove a skill by name. No-op if absent."""
        self._catalog.pop(name, None)

    def get(self, name: str) -> Optional[Skill]:
        """Return a skill by name, or None if absent."""
        return self._catalog.get(name)

    def __contains__(self, name: str) -> bool:
        return name in self._catalog

    def __len__(self) -> int:
        return len(self._catalog)

    def __iter__(self) -> Iterator[Skill]:
        return iter(self._catalog.values())

    # ------------------------------------------------------------------
    # Listing and filtering
    # ------------------------------------------------------------------

    def list_all(self) -> list[SkillSpec]:
        """Return every registered skill's spec."""
        return [s.spec for s in self._catalog.values()]

    def filter_by_category(self, category: str) -> list[Skill]:
        """Return all skills in the given category (prefix match)."""
        return [s for s in self._catalog.values() if s.matches_category(category)]

    def filter_by_tag(self, tag: str) -> list[Skill]:
        """Return all skills carrying the given tag."""
        return [s for s in self._catalog.values() if tag in s.spec.tags]

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def set_default_strategy(self, strategy: SearchStrategy) -> None:
        """Swap the default search strategy."""
        self._default_strategy = strategy

    def search(
        self,
        query: str,
        *,
        k: int = 5,
        strategy: Optional[SearchStrategy] = None,
    ) -> list[Skill]:
        """Retrieve up to ``k`` skills matching ``query``."""
        strat = strategy or self._default_strategy
        return strat.search(query, self._catalog, k=k)

    # ------------------------------------------------------------------
    # Relationships
    # ------------------------------------------------------------------

    def find_dependencies(self, name: str) -> list[Skill]:
        """Return the declared dependency skills of ``name``, in order."""
        skill = self.get(name)
        if skill is None:
            return []
        out: list[Skill] = []
        for dep in skill.spec.dependencies:
            dep_skill = self.get(dep)
            if dep_skill is not None:
                out.append(dep_skill)
        return out
