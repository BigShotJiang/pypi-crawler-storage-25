"""
---
title: SkillLearner — Optimization = Learning for Skills
summary: >
    A unified interface that treats skill optimization as a learning
    process. Wraps a Skill (or composite), an optimizer, and evaluation
    feedback into a tight improve loop. The Memento-Skills Read-Write
    pattern and the TGD prompt-tuning loop are both special cases.
---

# Skill Learner

In ``learn``, *optimization IS learning*: the agent improves its
skills by iteratively executing, evaluating, receiving feedback, and
updating its learnable prompts. ``SkillLearner`` encapsulates this
loop as a first-class object.

| Concept | PyTorch | learn |
|---------|---------|-------|
| What improves | weights | ``Parameter`` (prompt text) |
| Gradient | ``loss.backward()`` | ``loss.backward(engine)`` |
| Optimizer step | ``optimizer.step()`` | ``optimizer.step()`` |
| Training loop | ``for epoch …`` | ``SkillLearner.learn()`` |

## Design

``SkillLearner`` does NOT duplicate ``Trainer`` — it is a lightweight
facade that:

1. Owns a ``Skill`` (the learnable component).
2. Owns an optimizer for the skill's parameters.
3. Provides a ``learn()`` method that runs N improvement steps.
4. Optionally persists improvements to a ``SkillVocabulary``.
5. Tracks competence scores via EMA for warm-restart.

The key insight: in Memento-Skills, skills IMPROVE BY EXECUTING.
The feedback from execution is the "gradient". ``SkillLearner``
formalizes this as:

$$\\theta_{t+1} = \\text{Optimizer}(\\theta_t, \\nabla_{\\text{text}} L)$$

where $\\theta_t$ is the skill prompt at step $t$ and
$\\nabla_{\\text{text}} L$ is the textual gradient from the backward
engine.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.agent.skill.base import Skill
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    from learn.agent.skill.vocabulary import SkillVocabulary
    from learn.env.engine.base import EngineLM
    from learn.optim.base import Optimizer


# =====================================================================
# LearnResult — what a learning session returns
# =====================================================================


@dataclass
class LearnResult:
    r"""
    <a id="LearnResult"></a>

    ## LearnResult

    Summary of a ``SkillLearner.learn()`` run.

    * ``scores`` — per-step evaluation scores.
    * ``best_score`` — highest score achieved.
    * ``best_step`` — step at which ``best_score`` was achieved.
    * ``improved`` — whether the skill improved vs. initial score.
    * ``metadata`` — any extra information from the learner.
    """

    scores: list[float] = field(default_factory=list)
    best_score: float = 0.0
    best_step: int = 0
    improved: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


# =====================================================================
# SkillLearner — the learning loop
# =====================================================================


class SkillLearner:
    r"""
    <a id="SkillLearner"></a>

    ## SkillLearner

    Treats skill optimization as a learning process. This is the
    unified interface for:

    * **TGD prompt tuning:** backward pass + optimizer step.
    * **Memento-Skills reflective loop:** execute → evaluate → rewrite.
    * **Score-based optimization (OPRO):** score → propose → accept/reject.

    ```python
    learner = SkillLearner(
        skill=summarize_skill,
        optimizer=TGD(params=list(summarize_skill.parameters()),
                      engine=backward_engine),
        eval_fn=lambda out: float("good" in out.observation.lower()),
    )
    result = learner.learn(
        train_states=[TextState(observation="Long text...")],
        n_steps=5,
    )
    print(f"Improved: {result.improved}, Best: {result.best_score:.2f}")
    ```

    ### With Backward Engine (TGD-style)

    When ``backward_engine`` and ``loss_fn`` are set, the learner
    computes textual gradients and runs a proper backward pass at each
    step. Otherwise, it uses score-only optimization.

    ### With Vocabulary Persistence

    When ``vocabulary`` is set, each improvement is saved for
    warm-starting future skills of the same category/role.
    """

    def __init__(
        self,
        skill: Skill,
        optimizer: Optimizer,
        eval_fn: Callable[[TextState], float],
        *,
        backward_engine: Optional[EngineLM] = None,
        loss_fn: Optional[Callable[[TextState, str | None], Any]] = None,
        vocabulary: Optional[SkillVocabulary] = None,
    ) -> None:
        self.skill = skill
        self.optimizer = optimizer
        self.eval_fn = eval_fn
        self.backward_engine = backward_engine
        self.loss_fn = loss_fn
        self.vocabulary = vocabulary

    def learn(
        self,
        train_states: list[TextState],
        *,
        n_steps: int = 5,
        expected_outputs: list[str] | None = None,
    ) -> LearnResult:
        r"""Run the learning loop for ``n_steps`` improvement steps.

        Each step:

        1. **Execute** — run the skill on each train state.
        2. **Evaluate** — compute score via ``eval_fn``.
        3. **Backward** — if ``loss_fn`` and ``backward_engine`` are set,
           compute textual gradients. Otherwise, record score for
           score-based optimizers.
        4. **Step** — call ``optimizer.step()`` to update skill prompts.
        5. **Persist** — if a ``SkillVocabulary`` is attached, save the
           best prompt text.

        Args:
            train_states: Input states to practice on.
            n_steps: Number of improvement steps.
            expected_outputs: Optional expected outputs (one per state)
                for loss computation.

        Returns:
            ``LearnResult`` with per-step scores and improvement flag.
        """
        result = LearnResult()
        best_state_dict: dict[str, Any] | None = None

        # Record initial performance
        self.skill.train()

        for step in range(n_steps):
            # --- Execute + Evaluate ---
            step_score = 0.0
            loss_var = None

            for i, state in enumerate(train_states):
                output = self.skill(state)
                step_score += self.eval_fn(output)

                # --- Backward path (TGD-style) ---
                expected = (
                    expected_outputs[i]
                    if expected_outputs and i < len(expected_outputs)
                    else None
                )
                if self.loss_fn is not None and self.backward_engine is not None:
                    loss_var = self.loss_fn(output, expected)
                    if hasattr(loss_var, "backward"):
                        loss_var.backward(self.backward_engine)

                # --- Score-based path ---
                if hasattr(self.optimizer, "record"):
                    sample_score = self.eval_fn(output)
                    self.optimizer.record(sample_score)

            avg_score = step_score / max(len(train_states), 1)
            result.scores.append(avg_score)

            # --- Optimizer step ---
            self.optimizer.step()
            self.optimizer.zero_grad()

            # --- Track best ---
            if avg_score > result.best_score:
                result.best_score = avg_score
                result.best_step = step
                best_state_dict = self.skill.state_dict()

            # --- Vocabulary persistence ---
            if self.vocabulary is not None:
                for param in self.skill.parameters():
                    self.vocabulary.update(
                        category=self.skill.category,
                        role=param.name if hasattr(param, "name") else "default",
                        prompt_text=param.data,
                        score=avg_score,
                    )

        # Determine if improved
        if len(result.scores) >= 2:
            result.improved = result.best_score > result.scores[0]

        # Restore best state
        if best_state_dict is not None:
            self.skill.load_state_dict(best_state_dict)

        self.skill.eval()
        return result

    def learn_from_feedback(
        self,
        state: TextState,
        feedback: str,
    ) -> TextState:
        r"""Single-step reflective improvement (Memento-Skills style).

        Execute the skill, inject feedback into the scratchpad,
        re-execute, and evaluate. This is the "Read-Write" pattern:
        the skill reads the task, acts, receives feedback, and
        rewrites its response.

        Args:
            state: Input state.
            feedback: Natural-language feedback on the skill's output.

        Returns:
            Improved output TextState.
        """
        # First execution
        output = self.skill(state)

        # Inject feedback and re-execute
        feedback_state = state.update(
            scratchpad=(
                f"{state.scratchpad}\n\n"
                f"[feedback on previous attempt]\n{feedback}\n\n"
                f"[previous output]\n{output.observation}"
            ).strip(),
        )
        improved_output = self.skill(feedback_state)

        return improved_output
