"""
---
title: Skill Topology Primitives
summary: >
    Nine composition primitives for skills, mirroring the internal
    reference codebase and the ``nn.Sequential``/``nn.ModuleList``
    family of PyTorch containers. Every primitive is itself a Skill,
    so compositions nest arbitrarily.
---

# Skill Topology Primitives

All primitives implement ``forward(TextState) -> TextState`` and carry
their own ``SkillSpec`` — which means a composite skill is itself a
valid leaf in a larger composition. This fractal property is what lets
users construct arbitrarily deep agent architectures from a small set
of building blocks.

| Primitive | Semantics | PyTorch analog |
|-----------|-----------|----------------|
| ``SkillSequential`` | Chain: ``s_n(…s_1(x))`` | ``nn.Sequential`` |
| ``SkillParallel`` | Fan-out + merge | Ensemble |
| ``SkillSwitch`` | Route with a predicate | MoE gate |
| ``SkillLoop`` | Iterate until halt | ReAct loop |
| ``SkillResidual`` | ``merge(x, skill(x))`` | ResNet skip |
| ``SkillTree`` | Tree-of-Thoughts beam | ToT |
| ``SkillGraph`` | DAG over skills | Graph-of-Thoughts |
| ``SkillRecursive`` | Recursive decompose / compose | Divide-and-conquer |
| ``SkillDebate`` | Multi-agent debate | Debate |
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Optional

from learn.agent.skill.base import ExecutionMode, Skill, SkillSpec
from learn.env.program.variable import TextState

if TYPE_CHECKING:
    pass


# =====================================================================
# Helpers
# =====================================================================


def _auto_spec(name: str, description: str) -> SkillSpec:
    """Return a composite-skill spec with a sensible default category."""
    return SkillSpec(
        name=name,
        description=description,
        category="composite",
        execution_mode=ExecutionMode.KNOWLEDGE,
    )


def _register_children(parent: Skill, children: list[Skill], prefix: str) -> None:
    """Register each child skill under ``{prefix}_{i}`` so they show up
    in ``Component.parameters(recursive=True)``.
    """
    for i, child in enumerate(children):
        parent.register_component(f"{prefix}_{i}", child)


# =====================================================================
# SkillSequential — chain of skills
# =====================================================================


class SkillSequential(Skill):
    r"""
    <a id="SkillSequential"></a>

    ## SkillSequential

    Run a list of skills in order, piping the output ``TextState`` of
    one into the next. The textual analog of ``nn.Sequential``.

    ```python
    pipeline = SkillSequential(
        [extract_skill, summarize_skill, translate_skill],
        name="extract-summarize-translate",
    )
    ```
    """

    def __init__(
        self,
        skills: list[Skill],
        *,
        name: str = "sequential",
        description: str = "Run a sequence of skills in order.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if not skills:
            raise ValueError("SkillSequential requires at least one skill.")
        self.skills = skills
        _register_children(self, skills, "step")

    def forward(self, state: TextState) -> TextState:
        for skill in self.skills:
            state = skill(state)
        return state


# =====================================================================
# SkillParallel — fan-out + merge
# =====================================================================


class SkillParallel(Skill):
    r"""
    <a id="SkillParallel"></a>

    ## SkillParallel

    Run each child on the *same* input state and merge the resulting
    states via ``TextState.merge``. An ensemble of skills.

    The default merge is concatenation of observations and scratchpads;
    callers can pass a custom ``merge_fn`` to e.g. take a majority vote.
    """

    def __init__(
        self,
        skills: list[Skill],
        *,
        merge_fn: Optional[Callable[[list[TextState]], TextState]] = None,
        name: str = "parallel",
        description: str = "Run skills in parallel and merge outputs.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if not skills:
            raise ValueError("SkillParallel requires at least one skill.")
        self.skills = skills
        self.merge_fn = merge_fn
        _register_children(self, skills, "branch")

    def forward(self, state: TextState) -> TextState:
        outputs = [skill(state) for skill in self.skills]
        if self.merge_fn is not None:
            return self.merge_fn(outputs)
        return TextState.merge(*outputs)


# =====================================================================
# SkillSwitch — conditional dispatch
# =====================================================================


class SkillSwitch(Skill):
    r"""
    <a id="SkillSwitch"></a>

    ## SkillSwitch

    Select exactly one child skill at runtime via a router callable.
    The router receives the incoming ``TextState`` and returns either
    the *name* of a branch (``str``) or the *index* (``int``).

    ```python
    def router(state):
        return "math" if "+" in state.observation else "text"

    switch = SkillSwitch(
        router=router,
        branches={"math": calc_skill, "text": summarizer_skill},
    )
    ```

    This is the MoE gate of the skill world: only the selected branch
    is executed, so compute cost scales with depth not width.
    """

    def __init__(
        self,
        router: Callable[[TextState], Any],
        branches: dict[str, Skill],
        *,
        default: Optional[Skill] = None,
        name: str = "switch",
        description: str = "Dispatch to one of several branches.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if not branches:
            raise ValueError("SkillSwitch requires at least one branch.")
        self.router = router
        self.branches = dict(branches)
        self.default = default

        for branch_name, branch_skill in self.branches.items():
            self.register_component(f"branch_{branch_name}", branch_skill)
        if default is not None:
            self.register_component("default", default)

    def forward(self, state: TextState) -> TextState:
        selection = self.router(state)

        if isinstance(selection, int):
            # Index-based routing: dictionaries are order-preserving.
            keys = list(self.branches.keys())
            if 0 <= selection < len(keys):
                return self.branches[keys[selection]](state)
        elif isinstance(selection, str) and selection in self.branches:
            return self.branches[selection](state)

        if self.default is not None:
            return self.default(state)
        raise KeyError(
            f"SkillSwitch router returned {selection!r}, which is not a "
            f"branch name and no default is set."
        )


# =====================================================================
# SkillLoop — iterate until halt
# =====================================================================


class SkillLoop(Skill):
    r"""
    <a id="SkillLoop"></a>

    ## SkillLoop

    Apply a body skill repeatedly until either

    * ``halt_fn(state)`` returns ``True``, or
    * ``max_iter`` iterations have elapsed.

    This is the skill-level ReAct loop. If ``halt_fn`` is omitted the
    loop runs for exactly ``max_iter`` iterations.
    """

    def __init__(
        self,
        body: Skill,
        *,
        halt_fn: Optional[Callable[[TextState], bool]] = None,
        max_iter: int = 5,
        name: str = "loop",
        description: str = "Iterate a body skill until halt condition.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if max_iter < 1:
            raise ValueError("max_iter must be >= 1.")
        self.body = body
        self.halt_fn = halt_fn
        self.max_iter = max_iter
        self.register_component("body", body)

    def forward(self, state: TextState) -> TextState:
        for i in range(self.max_iter):
            state = self.body(state)
            # Record iteration count in metadata for downstream inspection.
            state.metadata["_loop_iter"] = i + 1
            if self.halt_fn is not None and self.halt_fn(state):
                break
        return state


# =====================================================================
# SkillResidual — additive skip
# =====================================================================


class SkillResidual(Skill):
    r"""
    <a id="SkillResidual"></a>

    ## SkillResidual

    Apply a child skill and merge its output with the original input
    state — the textual ResNet skip connection:

    $$y = \text{merge}(x, f(x))$$

    Default merge: concatenate the original observation and the new
    one with a separator. Callers can pass a custom ``merge_fn`` that
    receives ``(original_state, child_state)``.
    """

    def __init__(
        self,
        skill: Skill,
        *,
        merge_fn: Optional[Callable[[TextState, TextState], TextState]] = None,
        name: str = "residual",
        description: str = "Additive skip around a child skill.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        self.skill = skill
        self.merge_fn = merge_fn
        self.register_component("inner", skill)

    def forward(self, state: TextState) -> TextState:
        child_state = self.skill(state)
        if self.merge_fn is not None:
            return self.merge_fn(state, child_state)

        combined_obs = (
            f"{state.observation}\n---\n{child_state.observation}"
            if state.observation and child_state.observation
            else (state.observation or child_state.observation)
        )
        return child_state.update(observation=combined_obs)


# =====================================================================
# SkillTree — Tree of Thoughts
# =====================================================================


class SkillTree(Skill):
    r"""
    <a id="SkillTree"></a>

    ## SkillTree

    Beam-search generation on top of a generator/evaluator pair —
    the skill analog of Tree-of-Thoughts.

    At each level:

    1. ``generator(state)`` is called ``branching`` times.
    2. ``evaluator(candidate_state) -> float`` scores each candidate.
    3. The top-``beam_width`` states advance to the next level.
    4. After ``depth`` levels the best state is returned.
    """

    def __init__(
        self,
        generator: Skill,
        evaluator: Callable[[TextState], float],
        *,
        branching: int = 3,
        beam_width: int = 2,
        depth: int = 2,
        name: str = "tree",
        description: str = "Tree-of-thoughts beam search.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if branching < 1 or beam_width < 1 or depth < 1:
            raise ValueError("branching, beam_width, and depth must be >= 1.")
        self.generator = generator
        self.evaluator = evaluator
        self.branching = branching
        self.beam_width = beam_width
        self.depth = depth
        self.register_component("generator", generator)

    def forward(self, state: TextState) -> TextState:
        beam: list[TextState] = [state]
        for _ in range(self.depth):
            candidates: list[TextState] = []
            for parent in beam:
                for _ in range(self.branching):
                    candidates.append(self.generator(parent))
            scored = sorted(
                candidates, key=self.evaluator, reverse=True
            )[: self.beam_width]
            if not scored:
                break
            beam = scored
        return beam[0]


# =====================================================================
# SkillGraph — arbitrary DAG
# =====================================================================


class SkillGraph(Skill):
    r"""
    <a id="SkillGraph"></a>

    ## SkillGraph

    Run a set of named skills in topological order, feeding each node
    the merged output of its predecessors. The graph is specified as a
    mapping ``node_name -> (skill, predecessors)``.

    ```python
    graph = SkillGraph({
        "extract": (extract_skill, []),
        "classify": (classify_skill, ["extract"]),
        "summarize": (summarize_skill, ["extract"]),
        "merge": (merge_skill, ["classify", "summarize"]),
    })
    ```

    Kahn's algorithm is used for the topological sort; cycles raise
    ``ValueError``.
    """

    def __init__(
        self,
        nodes: dict[str, tuple[Skill, list[str]]],
        *,
        name: str = "graph",
        description: str = "Arbitrary DAG of skills.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if not nodes:
            raise ValueError("SkillGraph requires at least one node.")
        self.nodes = dict(nodes)
        self._order = self._topo_sort()

        for node_name, (skill, _) in self.nodes.items():
            self.register_component(f"node_{node_name}", skill)

    def _topo_sort(self) -> list[str]:
        """Kahn's algorithm. Raises ``ValueError`` on cycles."""
        in_degree: dict[str, int] = {n: 0 for n in self.nodes}
        for _, (_, preds) in self.nodes.items():
            for p in preds:
                if p not in self.nodes:
                    raise ValueError(
                        f"SkillGraph: unknown predecessor {p!r}."
                    )
                in_degree[p] = in_degree.get(p, 0)
        # in_degree is *outgoing edges count* from the predecessor side
        # we compute incoming edges for Kahn's:
        incoming: dict[str, int] = {n: 0 for n in self.nodes}
        for node_name, (_, preds) in self.nodes.items():
            incoming[node_name] = len(preds)
        queue = [n for n, d in incoming.items() if d == 0]
        order: list[str] = []
        while queue:
            cur = queue.pop(0)
            order.append(cur)
            for other, (_, preds) in self.nodes.items():
                if cur in preds:
                    incoming[other] -= 1
                    if incoming[other] == 0:
                        queue.append(other)
        if len(order) != len(self.nodes):
            raise ValueError("SkillGraph contains a cycle.")
        return order

    def forward(self, state: TextState) -> TextState:
        outputs: dict[str, TextState] = {}
        for node_name in self._order:
            skill, preds = self.nodes[node_name]
            if not preds:
                inp = state
            else:
                inp = TextState.merge(*(outputs[p] for p in preds))
            outputs[node_name] = skill(inp)
        # Return the merge of all terminal nodes (those that are no
        # one's predecessor).
        preds_set = {p for _, (_, ps) in self.nodes.items() for p in ps}
        terminals = [n for n in self.nodes if n not in preds_set]
        if len(terminals) == 1:
            return outputs[terminals[0]]
        return TextState.merge(*(outputs[t] for t in terminals))


# =====================================================================
# SkillRecursive — recursive decompose / compose
# =====================================================================


class SkillRecursive(Skill):
    r"""
    <a id="SkillRecursive"></a>

    ## SkillRecursive

    Recursive decomposition pattern:

    1. ``should_stop(state)`` — base case predicate.
    2. ``decomposer(state) -> list[TextState]`` — split into sub-problems.
    3. Recurse on each sub-state.
    4. ``composer(list[TextState]) -> TextState`` — combine the
       sub-results.

    A recursion depth limit protects against runaway splits.
    """

    def __init__(
        self,
        base: Skill,
        decomposer: Callable[[TextState], list[TextState]],
        composer: Callable[[list[TextState]], TextState],
        *,
        should_stop: Callable[[TextState], bool],
        max_depth: int = 4,
        name: str = "recursive",
        description: str = "Recursive decomposition of a task.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        self.base = base
        self.decomposer = decomposer
        self.composer = composer
        self.should_stop = should_stop
        self.max_depth = max_depth
        self.register_component("base", base)

    def forward(self, state: TextState) -> TextState:
        return self._recurse(state, depth=0)

    def _recurse(self, state: TextState, depth: int) -> TextState:
        if depth >= self.max_depth or self.should_stop(state):
            return self.base(state)
        sub_states = self.decomposer(state)
        if not sub_states:
            return self.base(state)
        sub_results = [self._recurse(s, depth + 1) for s in sub_states]
        return self.composer(sub_results)


# =====================================================================
# SkillDebate — multi-agent debate
# =====================================================================


class SkillDebate(Skill):
    r"""
    <a id="SkillDebate"></a>

    ## SkillDebate

    Multi-agent debate. Each *debater* is given the shared state plus
    the running transcript and is expected to produce an argument. A
    *judge* skill is then called once on the final transcript to
    produce the winning answer.

    This is the textual cousin of multi-head attention: each head
    (debater) proposes an opinion, and a gating head (judge)
    aggregates them.
    """

    def __init__(
        self,
        debaters: list[Skill],
        judge: Skill,
        *,
        rounds: int = 2,
        name: str = "debate",
        description: str = "Multi-agent debate with a judge.",
    ) -> None:
        super().__init__(spec=_auto_spec(name, description))
        if not debaters:
            raise ValueError("SkillDebate requires at least one debater.")
        if rounds < 1:
            raise ValueError("rounds must be >= 1.")
        self.debaters = debaters
        self.judge = judge
        self.rounds = rounds
        _register_children(self, debaters, "debater")
        self.register_component("judge", judge)

    def forward(self, state: TextState) -> TextState:
        transcript: list[str] = []
        base_obs = state.observation
        for rnd in range(self.rounds):
            for i, debater in enumerate(self.debaters):
                turn_state = state.update(
                    observation=base_obs,
                    scratchpad=(
                        f"round {rnd + 1}, debater {i + 1}\n"
                        f"transcript so far:\n" + "\n".join(transcript)
                    ),
                )
                out = debater(turn_state)
                transcript.append(
                    f"[debater {i + 1}, round {rnd + 1}]: {out.observation}"
                )
        judge_state = state.update(
            observation=base_obs,
            scratchpad="\n".join(transcript),
        )
        return self.judge(judge_state)
