"""
---
title: SkillCreator — LLM-Driven Skill Generation
summary: >
    Constructs ``LLMSkill`` instances from a natural-language
    description, an execution trajectory, or a code snippet. This is
    the ``learn`` analog of SkillNet's ``SkillCreator`` — the
    bootstrap path for populating a fresh ``SkillRegistry``.
---

# SkillCreator

A ``SkillCreator`` turns informal inputs into formal skills. It
produces ``LLMSkill`` instances because those are the learnable leaf
type; more specialized creators (e.g. a ``ToolSkillCreator`` that
emits executable code) can be added later without touching the base.

| Input | Method |
|-------|--------|
| A natural language *request* (e.g. "summarize long docs") | ``from_description`` |
| A sequence of ``TextState`` observations from a successful run | ``from_trajectory`` |
| A Python function / code snippet | ``from_code`` |

All three methods ultimately call the engine once with a tailored
prompt and expect a JSON blob ``{"name", "description", "prompt"}``
back. Malformed responses fall through to a conservative default.
"""
from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Optional

from learn.agent.skill.base import ExecutionMode, SkillSpec
from learn.agent.skill.leaf import LLMSkill
from learn.env.program.variable import Component, TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# =====================================================================
# Prompt templates
# =====================================================================


_FROM_DESCRIPTION_PROMPT = """You are a skill author. Design a reusable
agent skill based on the user's request. Return a single JSON object
with exactly these keys:

- "name": a kebab-case identifier for the skill
- "description": one sentence explaining when to use this skill
- "prompt": the system prompt the skill should send to the LLM

USER REQUEST: {description}

Respond with ONLY the JSON object, no commentary, no code fences.
"""

_FROM_TRAJECTORY_PROMPT = """You are a skill author. Study the following
agent trajectory (a sequence of state observations from a successful
run) and distill a reusable skill that could reproduce the key step.
Return a single JSON object with keys:

- "name": a kebab-case identifier
- "description": when this skill should be applied
- "prompt": the system prompt the skill should use

TRAJECTORY:
{trajectory}

Respond with ONLY the JSON object.
"""

_FROM_CODE_PROMPT = """You are a skill author. Study the code snippet
below and produce a *knowledge-mode* skill that captures the same
intent as a natural-language recipe (not as runnable code). Return a
single JSON object with keys:

- "name": a kebab-case identifier
- "description": when this skill should be applied
- "prompt": the system prompt the skill should use

CODE:
```
{code}
```

Respond with ONLY the JSON object.
"""


# =====================================================================
# Helper — robust JSON extraction
# =====================================================================


_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json(text: str) -> Optional[dict]:
    """Best-effort JSON extraction from an LLM response.

    LLMs often wrap JSON in code fences or add prose around it. We try:

    1. ``json.loads`` on the raw text,
    2. ``json.loads`` on the first ``{...}`` substring.
    """
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    match = _JSON_OBJECT_RE.search(text)
    if match is None:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None


def _coerce_spec(
    raw: Optional[dict],
    fallback_name: str,
    fallback_description: str,
    category: str = "generated",
) -> tuple[SkillSpec, str]:
    """Turn a possibly-malformed LLM response into a (spec, prompt) pair.

    Returns a fallback spec if ``raw`` is missing or unusable. The
    caller always receives a valid skill.
    """
    if raw is None:
        return (
            SkillSpec(
                name=fallback_name,
                description=fallback_description,
                category=category,
                execution_mode=ExecutionMode.KNOWLEDGE,
            ),
            fallback_description,
        )

    name = str(raw.get("name") or fallback_name).strip()
    description = str(raw.get("description") or fallback_description).strip()
    prompt = str(raw.get("prompt") or description).strip()
    return (
        SkillSpec(
            name=name or fallback_name,
            description=description or fallback_description,
            category=category,
            execution_mode=ExecutionMode.KNOWLEDGE,
        ),
        prompt,
    )


# =====================================================================
# SkillCreator
# =====================================================================


class SkillCreator(Component):
    r"""
    <a id="SkillCreator"></a>

    ## SkillCreator

    LLM-driven constructor for ``LLMSkill`` instances. The creator
    itself holds no learnable parameters — it is a *factory*, not a
    module in the differentiable sense.

    ```python
    creator = SkillCreator(engine=engine)
    skill = creator.from_description(
        "Translate English text to formal Japanese.",
    )
    ```
    """

    def __init__(self, engine: EngineLM) -> None:
        super().__init__(name="SkillCreator")
        self.engine = engine

    # ------------------------------------------------------------------
    # Creation paths
    # ------------------------------------------------------------------

    def from_description(self, description: str) -> LLMSkill:
        """Generate a skill from a one-line request."""
        raw = _extract_json(
            self.engine.generate(
                _FROM_DESCRIPTION_PROMPT.format(description=description),
            )
        )
        spec, prompt = _coerce_spec(
            raw,
            fallback_name="generated-skill",
            fallback_description=description,
        )
        return LLMSkill(spec=spec, engine=self.engine, prompt=prompt)

    def from_trajectory(self, trajectory: list[TextState]) -> LLMSkill:
        """Generate a skill by studying a successful execution trace."""
        rendered = "\n---\n".join(
            f"step {i + 1}: {s.observation}" for i, s in enumerate(trajectory)
        )
        raw = _extract_json(
            self.engine.generate(
                _FROM_TRAJECTORY_PROMPT.format(trajectory=rendered),
            )
        )
        spec, prompt = _coerce_spec(
            raw,
            fallback_name="trajectory-skill",
            fallback_description=(
                f"Reproduce the key step from a {len(trajectory)}-step trace."
            ),
        )
        return LLMSkill(spec=spec, engine=self.engine, prompt=prompt)

    def from_code(self, code: str) -> LLMSkill:
        """Generate a knowledge-mode skill from a Python snippet."""
        raw = _extract_json(
            self.engine.generate(
                _FROM_CODE_PROMPT.format(code=code),
            )
        )
        spec, prompt = _coerce_spec(
            raw,
            fallback_name="code-skill",
            fallback_description="Skill distilled from a code snippet.",
        )
        return LLMSkill(spec=spec, engine=self.engine, prompt=prompt)
