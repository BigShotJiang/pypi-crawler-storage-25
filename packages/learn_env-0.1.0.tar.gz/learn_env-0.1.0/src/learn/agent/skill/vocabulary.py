"""
---
title: SkillVocabulary — Persistent Learned-Prompt Store
summary: >
    JSON-backed key-value store that remembers the best-known prompt
    text for each ``(category, role)`` pair. Skills use the vocabulary
    to *warm-start* their learnable prompts — a direct analog of the
    internal reference codebase's ``SkillVocabulary``.
---

# SkillVocabulary

When a training run finishes, the optimized ``skill_prompt`` values
are worth more than the training trajectory itself — they are the
concrete learned artifact. The vocabulary stores them keyed by
``(category, role)`` so a subsequent run can bootstrap from where the
last one left off.

```
vocab.update("text/summarization", "step_1", "Given a passage...", score=0.84)
vocab.lookup("text/summarization", "step_1")
# → "Given a passage..."
```

The store is deliberately flat (one JSON file) because skill prompts
are small and infrequent compared to model weights. For larger
deployments swap the ``save`` / ``load`` methods for a database
backend.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


# =====================================================================
# VocabEntry — one learned prompt record
# =====================================================================


@dataclass
class VocabEntry:
    r"""
    <a id="VocabEntry"></a>

    ## VocabEntry

    One record in a ``SkillVocabulary``. Carries the prompt text along
    with enough metadata to drive a "use the best known prompt" policy:

    * ``prompt_text`` — the actual learned prompt string.
    * ``usage_count`` — how many training runs have written to this slot.
    * ``avg_score`` — exponential moving average of validation scores.
    * ``best_score`` — best validation score ever achieved.
    * ``history`` — append-only list of past prompts, for rollback and
      A/B comparison (capped to keep the JSON small).
    """

    prompt_text: str
    usage_count: int = 0
    avg_score: float = 0.0
    best_score: float = 0.0
    history: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    _HISTORY_CAP = 10

    def record(self, new_text: str, score: float, alpha: float = 0.3) -> None:
        """Accept a new training result. ``alpha`` is the EMA weight."""
        # Keep previous text in history before overwriting.
        if self.prompt_text and self.prompt_text != new_text:
            self.history.append(self.prompt_text)
            if len(self.history) > self._HISTORY_CAP:
                self.history = self.history[-self._HISTORY_CAP :]
        self.prompt_text = new_text
        self.usage_count += 1
        # Initialize EMA on the first update.
        if self.usage_count == 1:
            self.avg_score = score
        else:
            self.avg_score = alpha * score + (1 - alpha) * self.avg_score
        if score > self.best_score:
            self.best_score = score


# =====================================================================
# SkillVocabulary — the store
# =====================================================================


class SkillVocabulary:
    r"""
    <a id="SkillVocabulary"></a>

    ## SkillVocabulary

    JSON-backed lookup table keyed by ``(category, role)`` pairs.
    Provides warm-start semantics for newly created ``LLMSkill``
    instances:

    ```python
    vocab = SkillVocabulary.load("skills.json")
    seed = vocab.lookup("text/summarization", "step_1") or "Summarize..."
    skill = LLMSkill(spec=spec, engine=engine, prompt=seed)
    ```
    """

    def __init__(self) -> None:
        self._entries: dict[str, VocabEntry] = {}

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _make_key(category: str, role: str) -> str:
        """Compose the internal composite key."""
        return f"{category}::{role}"

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def lookup(self, category: str, role: str) -> Optional[str]:
        """Return the best-known prompt for a slot, or None if absent."""
        entry = self._entries.get(self._make_key(category, role))
        return entry.prompt_text if entry is not None else None

    def get_entry(self, category: str, role: str) -> Optional[VocabEntry]:
        """Return the full entry (text + stats) for a slot."""
        return self._entries.get(self._make_key(category, role))

    def update(
        self,
        category: str,
        role: str,
        prompt_text: str,
        score: float,
    ) -> None:
        """Record a new training result for ``(category, role)``."""
        key = self._make_key(category, role)
        entry = self._entries.get(key)
        if entry is None:
            entry = VocabEntry(prompt_text=prompt_text)
            self._entries[key] = entry
        entry.record(prompt_text, score)

    def merge(self, other: SkillVocabulary) -> None:
        """Merge another vocabulary into this one.

        On collision, the entry with the higher ``best_score`` wins.
        """
        for key, entry in other._entries.items():
            cur = self._entries.get(key)
            if cur is None or entry.best_score > cur.best_score:
                self._entries[key] = entry

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, key: tuple[str, str]) -> bool:
        category, role = key
        return self._make_key(category, role) in self._entries

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dictionary."""
        return {
            "version": 1,
            "entries": {
                key: asdict(entry) for key, entry in self._entries.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SkillVocabulary:
        """Reconstruct from a dictionary produced by ``to_dict``."""
        vocab = cls()
        for key, raw in data.get("entries", {}).items():
            vocab._entries[key] = VocabEntry(**raw)
        return vocab

    def save(self, path: str | Path) -> None:
        """Persist the vocabulary to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> SkillVocabulary:
        """Load a vocabulary from disk; return an empty one if missing."""
        path = Path(path)
        if not path.exists():
            return cls()
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)
