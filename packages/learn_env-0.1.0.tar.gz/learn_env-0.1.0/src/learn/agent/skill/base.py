"""
---
title: Skill Base — SkillSpec, ExecutionMode, Skill ABC
summary: >
    Core abstractions for the skill sub-package. ``SkillSpec`` is the
    structured metadata record that makes a skill discoverable and
    evaluable. ``Skill`` is the abstract base class — an ``Agent`` with
    a spec attached — and all leaf / topology skills descend from it.
---

# Skill Base

A *skill* is a reusable, composable, optimizable unit of agent
capability. In PyTorch terms, a skill is to ``learn`` what a
specialized ``nn.Module`` — say, ``nn.TransformerEncoderLayer`` — is to
PyTorch: a well-known recipe that users combine and optimize.

| PyTorch | learn |
|---------|-------|
| ``nn.Module`` | ``Agent`` |
| Named ``nn.Module`` recipe (``nn.LSTM``, ``nn.MultiheadAttention``) | ``Skill`` |
| Registry of recipes (``torch.hub``) | ``SkillRegistry`` |

## What a skill carries beyond an agent

Every ``Skill`` carries a ``SkillSpec`` — a small dataclass with:

* ``name`` / ``description`` — the *discovery* surface,
* ``signature`` — typed I/O for routing and validation,
* ``category`` / ``tags`` — hierarchical organization,
* ``execution_mode`` — ``KNOWLEDGE`` (pure prompt) vs. ``EXECUTABLE``
  (runnable code/tool),
* ``allowed_tools`` / ``dependencies`` — safety and composition hints.

The description is not a comment — it is the primary *retrieval
parameter* and is often itself optimized by a textual-gradient
optimizer (see §4.5 of ``SKILL-INTEGRATION.md``).
"""
from __future__ import annotations

from abc import abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional

from learn.agent.base import Agent
from learn.env.program.variable import Signature, TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


# =====================================================================
# ExecutionMode — how a skill delivers value
# =====================================================================


class ExecutionMode(Enum):
    r"""
    <a id="ExecutionMode"></a>

    ## ExecutionMode

    How the skill delivers its capability at runtime.

    * ``KNOWLEDGE`` — the skill is a *prompt recipe*; calling it amounts
      to injecting its content into an LLM context. SkillNet's
      markdown-only skills and most of Memento-Skills' playbook skills
      fall here.
    * ``EXECUTABLE`` — the skill wraps concrete code / a tool /
      a retriever that is invoked directly. ToolSkill and
      RetrievalSkill use this mode.

    The mode influences evaluation (an executable skill should be
    checked for runtime safety) and composition (a ``KNOWLEDGE`` skill
    can always be inlined into a larger prompt).
    """

    KNOWLEDGE = "knowledge"
    EXECUTABLE = "executable"


# =====================================================================
# SkillSpec — structured metadata for discovery and evaluation
# =====================================================================


@dataclass
class SkillSpec:
    r"""
    <a id="SkillSpec"></a>

    ## SkillSpec

    Structured metadata that makes a ``Skill`` discoverable, evaluable,
    and serializable. Think of it as the *header* of the skill package
    format described in ``SKILL-INTEGRATION.md`` §4.3.2.

    ### Fields

    * ``name`` — kebab-case identifier; unique within a ``SkillRegistry``.
    * ``description`` — natural-language *when-to-use* trigger; optimized
      for retrieval quality.
    * ``signature`` — optional typed I/O spec (``Signature``).
    * ``category`` — hierarchical path like ``"text/summarization"``.
    * ``tags`` — free-form labels for filtering and faceted search.
    * ``execution_mode`` — ``KNOWLEDGE`` or ``EXECUTABLE``.
    * ``allowed_tools`` — whitelist of tool names the skill may call;
      enforced by executors (Memento-Skills §2.2).
    * ``dependencies`` — other skills required before this one runs.
    * ``metadata`` — arbitrary key-value extension point.
    """

    name: str
    description: str
    signature: Optional[Signature] = None
    category: str = "general"
    tags: list[str] = field(default_factory=list)
    execution_mode: ExecutionMode = ExecutionMode.KNOWLEDGE
    allowed_tools: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dictionary.

        The ``signature`` field is dropped because ``Signature`` carries
        Python ``type`` objects, which are not JSON-serializable. Callers
        that need signature roundtrip should handle it separately.
        """
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "tags": list(self.tags),
            "execution_mode": self.execution_mode.value,
            "allowed_tools": list(self.allowed_tools),
            "dependencies": list(self.dependencies),
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SkillSpec:
        """Build a ``SkillSpec`` from a dictionary produced by ``to_dict``."""
        return cls(
            name=data["name"],
            description=data["description"],
            category=data.get("category", "general"),
            tags=list(data.get("tags", [])),
            execution_mode=ExecutionMode(
                data.get("execution_mode", ExecutionMode.KNOWLEDGE.value)
            ),
            allowed_tools=list(data.get("allowed_tools", [])),
            dependencies=list(data.get("dependencies", [])),
            metadata=dict(data.get("metadata", {})),
        )


# =====================================================================
# Skill — abstract base class
# =====================================================================


class Skill(Agent):
    r"""
    <a id="Skill"></a>

    ## Skill

    Abstract base class for all framework skills. A ``Skill`` is an
    ``Agent`` that additionally owns a ``SkillSpec``. Concrete skills
    implement ``forward(TextState) -> TextState`` exactly as any other
    agent does.

    ```python
    class SummarizerSkill(Skill):
        def forward(self, state: TextState) -> TextState:
            summary = self.engine.generate(
                f"Summarize: {state.observation}",
            )
            return state.update(observation=summary)

    skill = SummarizerSkill(
        spec=SkillSpec(
            name="summarizer",
            description="Condense a text passage to its key points.",
        ),
        engine=engine,
    )
    out = skill(TextState(observation="..."))
    ```

    Because ``Skill`` extends ``Agent``, it is a valid node inside a
    ``Program`` DAG. Because it inherits ``Component`` via ``Agent``,
    any ``Parameter`` attributes (e.g. a learnable prompt) are
    automatically surfaced by ``parameters()`` and optimizable by TGD,
    OPRO, or evolutionary optimizers.
    """

    def __init__(
        self,
        spec: SkillSpec,
        *,
        engine: Optional[EngineLM] = None,
        name: Optional[str] = None,
    ) -> None:
        super().__init__(engine=engine, name=name or spec.name)
        self.spec = spec

    # ------------------------------------------------------------------
    # Core contract
    # ------------------------------------------------------------------

    @abstractmethod
    def forward(self, state: TextState) -> TextState:
        """Apply the skill to an input state.

        Args:
            state: Input ``TextState`` — the skill may read any field.

        Returns:
            Updated ``TextState`` with the skill's effect applied.
        """
        ...

    # ------------------------------------------------------------------
    # Spec conveniences
    # ------------------------------------------------------------------

    @property
    def description(self) -> str:
        """Shortcut for ``self.spec.description``."""
        return self.spec.description

    @property
    def category(self) -> str:
        """Shortcut for ``self.spec.category``."""
        return self.spec.category

    def matches_category(self, category: str) -> bool:
        """Return True if this skill is in the given category or a child
        of it (prefix match on the hierarchical path).
        """
        return self.spec.category == category or self.spec.category.startswith(
            f"{category}/"
        )

    def check_tools_allowed(self, requested: list[str]) -> bool:
        """Return True iff every requested tool is in ``allowed_tools``.

        When ``allowed_tools`` is empty the whitelist is *unrestricted*
        (following Memento-Skills' convention).
        """
        if not self.spec.allowed_tools:
            return True
        allowed = set(self.spec.allowed_tools)
        return all(t in allowed for t in requested)

    # ------------------------------------------------------------------
    # Debug
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(name={self.spec.name!r}, "
            f"category={self.spec.category!r}, "
            f"mode={self.spec.execution_mode.value})"
        )
