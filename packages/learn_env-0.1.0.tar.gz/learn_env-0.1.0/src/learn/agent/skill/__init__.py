"""
---
title: learn.agent.skill — Agent Skills Subsystem
summary: >
    First-class, composable, optimizable agent skills. A Skill is the
    ``learn`` analog of an ``nn.Module`` specialized for *reusable agent
    capabilities* — each Skill carries a searchable SkillSpec and follows
    the standard ``forward(TextState) -> TextState`` contract.
---

# Agent Skills

Skills are the framework's answer to the question *"what does my agent
know how to do?"*. They unify four research lines (SkillNet,
Memento-Skills, AgentSkillOS, Agent Lightning) under the PyTorch mental
model that drives the rest of ``learn``.

| Layer | Module | Role |
|-------|--------|------|
| Base | [base](base.html) | ``Skill``, ``SkillSpec``, ``ExecutionMode`` |
| Leaf | [leaf](leaf.html) | ``LLMSkill``, ``ToolSkill``, ``RetrievalSkill`` |
| Topology | [topology](topology.html) | Sequential / Parallel / Switch / Loop / Residual / Tree / Graph / Recursive / Debate |
| Registry | [registry](registry.html) | In-memory catalog with pluggable retrieval strategies |
| Vocabulary | [vocabulary](vocabulary.html) | Persistent learned-prompt store |
| Evaluator | [evaluator](evaluator.html) | Multi-dimensional skill scoring |
| Creator | [creator](creator.html) | LLM-driven skill generation |

Every primitive below descends from ``Skill`` (a subclass of
``Agent``), which means:

* all skills are valid nodes inside a ``Program`` DAG,
* all skills expose their learnable prompts via ``parameters()``,
* every framework optimizer (TGD, OPRO, evolutionary, …) works on a
  Skill with zero modification.
"""
from learn.agent.skill.base import (
    ExecutionMode,
    Skill,
    SkillSpec,
)
from learn.agent.skill.creator import SkillCreator
from learn.agent.skill.evaluator import SkillEvaluator
from learn.agent.skill.leaf import (
    LLMSkill,
    RetrievalSkill,
    ToolSkill,
)
from learn.agent.skill.learner import LearnResult, SkillLearner
from learn.agent.skill.registry import (
    ExactMatchStrategy,
    KeywordStrategy,
    LLMSearchStrategy,
    SearchStrategy,
    SkillRegistry,
)
from learn.agent.skill.topology import (
    SkillDebate,
    SkillGraph,
    SkillLoop,
    SkillParallel,
    SkillRecursive,
    SkillResidual,
    SkillSequential,
    SkillSwitch,
    SkillTree,
)
from learn.agent.skill.vocabulary import SkillVocabulary, VocabEntry

__all__ = [
    # Base
    "ExecutionMode",
    "Skill",
    "SkillSpec",
    # Leaf
    "LLMSkill",
    "RetrievalSkill",
    "ToolSkill",
    # Topology
    "SkillDebate",
    "SkillGraph",
    "SkillLoop",
    "SkillParallel",
    "SkillRecursive",
    "SkillResidual",
    "SkillSequential",
    "SkillSwitch",
    "SkillTree",
    # Registry
    "ExactMatchStrategy",
    "KeywordStrategy",
    "LLMSearchStrategy",
    "SearchStrategy",
    "SkillRegistry",
    # Vocabulary
    "SkillVocabulary",
    "VocabEntry",
    # Learner
    "LearnResult",
    "SkillLearner",
    # Evaluator / Creator
    "SkillCreator",
    "SkillEvaluator",
]
