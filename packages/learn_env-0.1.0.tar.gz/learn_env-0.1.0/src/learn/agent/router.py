"""
---
title: Router Agent
summary: >
    Dispatches input to one of several downstream agents based on
    LLM-based or rule-based content analysis.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Router(Agent):
    """Routes input to one of several named agents.

    ```python
    router = Router(
        engine=engine,
        routes={"math": math_agent, "code": code_agent},
    )
    output = router(TextState(observation="Solve x+2=5"))
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        routes: dict[str, Agent],
        *,
        name: str | None = None,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Router", skills=skills)
        self.routes = routes
        self.route_names = list(routes.keys())

        self.routing_prompt = Parameter(
            data=(
                "Given the following input, decide which route to use. "
                f"Available routes: {', '.join(self.route_names)}. "
                "Reply with only the route name."
            ),
            param_type=ParameterType.PROMPT,
            role_description="routing decision prompt",
            requires_opt=True,
        )

    def forward(self, state: TextState) -> TextState:
        # Ask the LLM to choose a route
        prompt = f"{self.routing_prompt.data}\n\nInput: {state.observation}"
        decision = self.engine.generate(prompt).strip().lower()

        # Find matching route (fuzzy: first route name that appears in the response)
        selected_name = self.route_names[0]  # default to first
        for name in self.route_names:
            if name.lower() in decision:
                selected_name = name
                break

        selected_agent = self.routes[selected_name]
        output = selected_agent(state)

        return output.update(
            metadata={**output.metadata, "_routed_to": selected_name},
        )
