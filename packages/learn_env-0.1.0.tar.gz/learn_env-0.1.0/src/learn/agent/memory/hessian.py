"""
---
title: HessianMemory — Hessian-Proxy Knowledge Base for Optimization
summary: >
    Stores curvature estimates (second-order gradient information)
    to guide optimization. Used by TextBFGS and advanced optimizers.
---

# Hessian Memory

Maintains a knowledge base of parameter update histories and their
outcomes to approximate second-order information in text space.

The Hessian proxy captures: "when parameter X was changed from A to B,
the loss changed by delta" — enabling quasi-Newton-style updates.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from learn.agent.memory.base import Memory


@dataclass
class HessianEntry:
    """A record of a parameter update and its effect.

    Attributes:
        param_name: Name of the parameter that was updated.
        old_value: Previous parameter value.
        new_value: Updated parameter value.
        gradient: The textual gradient that motivated the update.
        loss_before: Loss before the update.
        loss_after: Loss after the update.
        delta_loss: Change in loss (negative = improvement).
    """

    param_name: str
    old_value: str
    new_value: str
    gradient: str = ""
    loss_before: float = 0.0
    loss_after: float = 0.0
    delta_loss: float = 0.0

    @property
    def improved(self) -> bool:
        return self.delta_loss < 0


class HessianMemory(Memory):
    r"""
    <a id="HessianMemory"></a>

    ## HessianMemory

    Knowledge base that tracks parameter update outcomes to approximate
    curvature information in text space.

    ```python
    memory = HessianMemory(max_entries=100)
    memory.store("prompt", entry, metadata={"step": 1})

    # Retrieve successful updates for guidance
    good_updates = memory.retrieve("prompt", k=5)

    # Get summary for optimizer prompt
    summary = memory.format_update_history("prompt")
    ```
    """

    def __init__(self, max_entries: int = 100) -> None:
        self._entries: list[HessianEntry] = []
        self._by_param: dict[str, list[HessianEntry]] = {}
        self._max_entries = max_entries

    def store(
        self,
        key: str,
        value: Any,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Store a Hessian entry.

        Args:
            key: Parameter name.
            value: HessianEntry or dict with entry fields.
        """
        if isinstance(value, dict):
            entry = HessianEntry(param_name=key, **value)
        elif isinstance(value, HessianEntry):
            entry = value
        else:
            entry = HessianEntry(param_name=key, old_value="", new_value=str(value))

        self._entries.append(entry)
        if key not in self._by_param:
            self._by_param[key] = []
        self._by_param[key].append(entry)

        # Evict oldest if over capacity
        if len(self._entries) > self._max_entries:
            removed = self._entries.pop(0)
            param_list = self._by_param.get(removed.param_name, [])
            if removed in param_list:
                param_list.remove(removed)

    def retrieve(self, query: str, k: int = 5) -> list[HessianEntry]:
        """Retrieve the most relevant entries for a parameter.

        Returns entries sorted by recency, preferring successful updates.

        Args:
            query: Parameter name to query.
            k: Number of entries to return.

        Returns:
            List of HessianEntry objects.
        """
        entries = self._by_param.get(query, [])
        # Sort: successful updates first, then by recency
        scored = sorted(
            entries,
            key=lambda e: (e.improved, entries.index(e)),
            reverse=True,
        )
        return scored[:k]

    def consolidate(self) -> None:
        """Remove entries with minimal information content."""
        # Keep only entries with meaningful loss deltas
        self._entries = [
            e for e in self._entries
            if abs(e.delta_loss) > 0.001 or e.improved
        ]
        # Rebuild index
        self._by_param.clear()
        for entry in self._entries:
            if entry.param_name not in self._by_param:
                self._by_param[entry.param_name] = []
            self._by_param[entry.param_name].append(entry)

    def clear(self) -> None:
        """Clear all entries."""
        self._entries.clear()
        self._by_param.clear()

    def format_update_history(self, param_name: str, k: int = 3) -> str:
        """Format recent update history for inclusion in optimizer prompts.

        Args:
            param_name: Parameter to format history for.
            k: Number of recent entries to include.

        Returns:
            Formatted string describing past updates and their effects.
        """
        entries = self.retrieve(param_name, k=k)
        if not entries:
            return "No update history available."

        parts = ["Previous update attempts:"]
        for i, entry in enumerate(entries, 1):
            outcome = "improved" if entry.improved else "worsened"
            parts.append(
                f"{i}. Changed to: {entry.new_value[:100]}... "
                f"→ loss {outcome} by {abs(entry.delta_loss):.4f}"
            )
            if entry.gradient:
                parts.append(f"   Gradient: {entry.gradient[:100]}...")
        return "\n".join(parts)

    def state_dict(self) -> dict[str, Any]:
        """Serialize memory state."""
        return {
            "entries": [
                {
                    "param_name": e.param_name,
                    "old_value": e.old_value,
                    "new_value": e.new_value,
                    "gradient": e.gradient,
                    "loss_before": e.loss_before,
                    "loss_after": e.loss_after,
                    "delta_loss": e.delta_loss,
                }
                for e in self._entries
            ]
        }

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore memory state."""
        self.clear()
        for entry_dict in state.get("entries", []):
            entry = HessianEntry(**entry_dict)
            self.store(entry.param_name, entry)
