"""
---
title: ReflectiveMemory — Lessons Learned Store
summary: >
    Stores insights and lessons learned from past experiences.
    Supports keyword-based retrieval and basic deduplication.
---
"""
from __future__ import annotations

import time
from typing import Any

from learn.agent.memory.base import Memory


class ReflectiveMemory(Memory):
    """Memory for storing reflective insights.

    ```python
    mem = ReflectiveMemory()
    mem.store("math", "Always check for division by zero.")
    insights = mem.retrieve("math", k=3)
    ```
    """

    def __init__(self, max_insights: int = 100) -> None:
        self._insights: list[dict[str, Any]] = []
        self.max_insights = max_insights

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        insight = {
            "topic": key,
            "insight": value,
            "metadata": metadata or {},
            "timestamp": time.time(),
        }
        self._insights.append(insight)

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Keyword search over topics and insight text."""
        q_lower = query.lower()
        scored: list[tuple[float, dict]] = []
        for ins in self._insights:
            score = 0.0
            if q_lower in ins["topic"].lower():
                score += 2.0
            if q_lower in str(ins["insight"]).lower():
                score += 1.0
            if score > 0:
                scored.append((score, ins))
        scored.sort(key=lambda x: -x[0])
        return [ins for _, ins in scored[:k]]

    def consolidate(self) -> None:
        """Merge similar insights — keeps newest when topics match exactly."""
        seen: dict[str, dict] = {}
        for ins in self._insights:
            topic = ins["topic"].lower()
            if topic not in seen or ins["timestamp"] > seen[topic]["timestamp"]:
                seen[topic] = ins
        self._insights = list(seen.values())[-self.max_insights :]

    def clear(self) -> None:
        self._insights.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"insights": list(self._insights)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._insights = list(state.get("insights", []))

    def __len__(self) -> int:
        return len(self._insights)
