"""
---
title: SemanticMemory — Keyword-Based Fact Store
summary: >
    Stores facts with keyword-based retrieval. Simple implementation
    with no embedding dependencies — uses tag and text matching.
---
"""
from __future__ import annotations

import time
from typing import Any

from learn.agent.memory.base import Memory


class SemanticMemory(Memory):
    """Fact store with keyword/tag-based retrieval.

    ```python
    mem = SemanticMemory()
    mem.store("python", "Python is dynamically typed.", {"tags": ["language"]})
    facts = mem.retrieve("typed", k=3)
    ```
    """

    def __init__(self, max_facts: int = 1000) -> None:
        self._facts: list[dict[str, Any]] = []
        self.max_facts = max_facts

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        meta = metadata or {}
        fact = {
            "key": key,
            "value": value,
            "tags": meta.get("tags", []),
            "metadata": meta,
            "timestamp": time.time(),
        }
        self._facts.append(fact)

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Keyword match on key, value, and tags."""
        q_lower = query.lower()
        scored: list[tuple[float, dict]] = []
        for fact in self._facts:
            score = 0.0
            if q_lower in fact["key"].lower():
                score += 2.0
            if q_lower in str(fact["value"]).lower():
                score += 1.0
            if any(q_lower in t.lower() for t in fact["tags"]):
                score += 1.5
            if score > 0:
                scored.append((score, fact))
        scored.sort(key=lambda x: -x[0])
        return [f for _, f in scored[:k]]

    def consolidate(self) -> None:
        if len(self._facts) > self.max_facts:
            self._facts = self._facts[-self.max_facts :]

    def clear(self) -> None:
        self._facts.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"facts": list(self._facts)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._facts = list(state.get("facts", []))

    def __len__(self) -> int:
        return len(self._facts)
