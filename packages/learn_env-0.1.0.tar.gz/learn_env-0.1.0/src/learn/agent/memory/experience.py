"""
---
title: ExperienceMemory — Experience Replay Store
summary: >
    Stores (input, output, score) tuples for experience replay.
    Supports sampling, top-k retrieval, and score-based consolidation.
---
"""
from __future__ import annotations

import random
import time
from typing import Any

from learn.agent.memory.base import Memory


class ExperienceMemory(Memory):
    """Memory for storing scored experiences for replay.

    ```python
    mem = ExperienceMemory(max_experiences=500)
    mem.store("task_1", {"input": "q", "output": "a", "score": 0.9})
    top = mem.best(n=3)
    ```
    """

    def __init__(self, max_experiences: int = 500) -> None:
        self._experiences: list[dict[str, Any]] = []
        self.max_experiences = max_experiences

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        entry = {
            "key": key,
            "value": value,
            "score": value.get("score", 0.0) if isinstance(value, dict) else 0.0,
            "metadata": metadata or {},
            "timestamp": time.time(),
        }
        self._experiences.append(entry)

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Return top-k experiences by score, optionally filtered by keyword."""
        pool = self._experiences
        if query.strip():
            q_lower = query.lower()
            pool = [
                e for e in self._experiences
                if q_lower in e["key"].lower() or q_lower in str(e["value"]).lower()
            ]
        sorted_pool = sorted(pool, key=lambda e: -e["score"])
        return sorted_pool[:k]

    def consolidate(self) -> None:
        """Keep only the top experiences by score."""
        if len(self._experiences) > self.max_experiences:
            self._experiences.sort(key=lambda e: -e["score"])
            self._experiences = self._experiences[: self.max_experiences]

    def clear(self) -> None:
        self._experiences.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"experiences": list(self._experiences)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._experiences = list(state.get("experiences", []))

    def sample(self, n: int = 5) -> list[dict[str, Any]]:
        """Random sample of *n* experiences."""
        return random.sample(self._experiences, min(n, len(self._experiences)))

    def best(self, n: int = 5) -> list[dict[str, Any]]:
        """Top *n* experiences by score."""
        return sorted(self._experiences, key=lambda e: -e["score"])[:n]

    def __len__(self) -> int:
        return len(self._experiences)
