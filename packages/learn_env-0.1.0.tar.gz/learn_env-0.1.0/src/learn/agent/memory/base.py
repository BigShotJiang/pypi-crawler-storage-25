"""
---
title: Memory ABC — Agent Memory Base Class
summary: >
    Abstract base class for all agent memory types. Defines the
    store/retrieve/consolidate interface.
---
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Memory(ABC):
    """Base class for all agent memory types.

    ```python
    class MyMemory(Memory):
        def store(self, key, value, metadata=None):
            ...
        def retrieve(self, query, k=5):
            ...
        def consolidate(self):
            ...
    ```
    """

    @abstractmethod
    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        """Add information to memory."""
        ...

    @abstractmethod
    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Query memory and return top-k results."""
        ...

    @abstractmethod
    def consolidate(self) -> None:
        """Periodic maintenance: compress, summarize, forget."""
        ...

    def clear(self) -> None:
        """Clear all stored memories. Override for specific behavior."""
        ...

    def state_dict(self) -> dict[str, Any]:
        """Serialize memory state."""
        return {}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        """Restore memory state."""
