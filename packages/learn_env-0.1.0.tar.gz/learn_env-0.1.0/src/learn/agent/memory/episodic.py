"""
---
title: EpisodicMemory — Long-Term Episode Store
summary: >
    Stores time-stamped per-episode experiences. Searchable by
    keyword similarity.
---
"""
from __future__ import annotations

import time
from typing import Any

from learn.agent.memory.base import Memory


class EpisodicMemory(Memory):
    """Long-term memory for per-episode experiences.

    ```python
    mem = EpisodicMemory(max_episodes=500)
    mem.store("task_42", {"input": "...", "output": "...", "score": 0.9})
    recent = mem.retrieve("task", k=3)
    ```
    """

    def __init__(self, max_episodes: int = 1000) -> None:
        self.max_episodes = max_episodes
        self._episodes: list[dict[str, Any]] = []

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        episode = {
            "key": key,
            "value": value,
            "metadata": metadata or {},
            "timestamp": time.time(),
        }
        self._episodes.append(episode)
        # Evict oldest when over capacity
        if len(self._episodes) > self.max_episodes:
            self._episodes = self._episodes[-self.max_episodes:]

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Retrieve episodes matching query (keyword match on key + value str)."""
        scored: list[tuple[float, dict]] = []
        q_lower = query.lower()
        for ep in self._episodes:
            score = 0.0
            if q_lower in ep["key"].lower():
                score += 2.0
            val_str = str(ep["value"]).lower()
            if q_lower in val_str:
                score += 1.0
            if score > 0:
                scored.append((score, ep))
        scored.sort(key=lambda x: (-x[0], -x[1].get("timestamp", 0)))
        return [ep for _, ep in scored[:k]]

    def consolidate(self) -> None:
        """Keep only the most recent max_episodes entries."""
        if len(self._episodes) > self.max_episodes:
            self._episodes = self._episodes[-self.max_episodes:]

    def clear(self) -> None:
        self._episodes.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"episodes": list(self._episodes)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._episodes = list(state.get("episodes", []))

    def __len__(self) -> int:
        return len(self._episodes)
