"""
---
title: ProceduralMemory — Named Procedure/Skill Store
summary: >
    Stores named procedures (skills) as key-value entries with
    keyword-based retrieval. Useful for tool-use and plan reuse.
---
"""
from __future__ import annotations

from typing import Any

from learn.agent.memory.base import Memory


class ProceduralMemory(Memory):
    """Registry of named procedures/skills.

    ```python
    mem = ProceduralMemory()
    mem.store("web_search", {"steps": ["query", "parse", "extract"], "desc": "Search the web"})
    mem.get_procedure("web_search")
    ```
    """

    def __init__(self) -> None:
        self._procedures: dict[str, dict[str, Any]] = {}

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        self._procedures[key] = {
            "name": key,
            "value": value,
            "metadata": metadata or {},
        }

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Keyword match on procedure names and descriptions."""
        q_lower = query.lower()
        scored: list[tuple[float, dict]] = []
        for proc in self._procedures.values():
            score = 0.0
            if q_lower in proc["name"].lower():
                score += 2.0
            if q_lower in str(proc["value"]).lower():
                score += 1.0
            if score > 0:
                scored.append((score, proc))
        scored.sort(key=lambda x: -x[0])
        return [p for _, p in scored[:k]]

    def consolidate(self) -> None:
        """No-op — procedures are explicitly managed."""

    def clear(self) -> None:
        self._procedures.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"procedures": dict(self._procedures)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._procedures = dict(state.get("procedures", {}))

    def get_procedure(self, name: str) -> dict[str, Any] | None:
        """Return a specific procedure by name, or None."""
        return self._procedures.get(name)

    def list_procedures(self) -> list[str]:
        """Return all procedure names."""
        return list(self._procedures.keys())

    def __len__(self) -> int:
        return len(self._procedures)
