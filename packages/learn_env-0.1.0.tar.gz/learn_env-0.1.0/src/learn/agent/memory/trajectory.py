"""
---
title: TrajectoryMemory — Step-by-Step Execution Traces
summary: >
    Stores step-by-step execution traces for multi-step agents.
    Each step is a dict with action, observation, and metadata.
---
"""
from __future__ import annotations

import time
from typing import Any

from learn.agent.memory.base import Memory


class TrajectoryMemory(Memory):
    """Memory that stores sequential execution traces.

    ```python
    mem = TrajectoryMemory(max_steps=100)
    mem.store("step_1", {"action": "search", "result": "..."})
    history = mem.format_history(n=3)
    ```
    """

    def __init__(self, max_steps: int = 1000) -> None:
        self._trajectory: list[dict[str, Any]] = []
        self.max_steps = max_steps

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        step = {
            "key": key,
            "value": value,
            "metadata": metadata or {},
            "timestamp": time.time(),
            "step_idx": len(self._trajectory),
        }
        self._trajectory.append(step)

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Return last k steps matching query, or just last k if query is empty."""
        if not query.strip():
            return self._trajectory[-k:]
        q_lower = query.lower()
        matched = [
            s for s in self._trajectory
            if q_lower in s["key"].lower() or q_lower in str(s["value"]).lower()
        ]
        return matched[-k:]

    def consolidate(self) -> None:
        if len(self._trajectory) > self.max_steps:
            self._trajectory = self._trajectory[-self.max_steps :]

    def clear(self) -> None:
        self._trajectory.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"trajectory": list(self._trajectory)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._trajectory = list(state.get("trajectory", []))

    def get_trajectory(self) -> list[dict[str, Any]]:
        """Return the full trajectory."""
        return list(self._trajectory)

    def format_history(self, n: int = 5) -> str:
        """Format the last *n* steps as a readable string."""
        steps = self._trajectory[-n:]
        lines = []
        for s in steps:
            lines.append(f"[{s['key']}] {s['value']}")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self._trajectory)
