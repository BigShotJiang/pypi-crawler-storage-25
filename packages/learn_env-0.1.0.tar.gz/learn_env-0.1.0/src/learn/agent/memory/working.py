"""
---
title: WorkingMemory — Short-Term Task Context
summary: >
    In-memory key-value store for current task context.
    Cleared after each execution or explicitly by the agent.
---
"""
from __future__ import annotations

from typing import Any

from learn.agent.memory.base import Memory


class WorkingMemory(Memory):
    """Short-term memory for current task context.

    ```python
    mem = WorkingMemory()
    mem.store("plan", "Step 1: read input. Step 2: solve.")
    results = mem.retrieve("plan")  # [{"key": "plan", "value": "..."}]
    ```
    """

    def __init__(self, max_entries: int = 100) -> None:
        self.max_entries = max_entries
        self._store: dict[str, dict[str, Any]] = {}

    def store(self, key: str, value: Any, metadata: dict | None = None) -> None:
        self._store[key] = {
            "key": key,
            "value": value,
            "metadata": metadata or {},
        }
        # Evict oldest if over capacity
        if len(self._store) > self.max_entries:
            oldest = next(iter(self._store))
            del self._store[oldest]

    def retrieve(self, query: str, k: int = 5) -> list[Any]:
        """Retrieve by exact key match, or return all entries containing query."""
        if query in self._store:
            return [self._store[query]]
        # Substring search fallback
        results = [
            entry for key, entry in self._store.items()
            if query.lower() in key.lower()
        ]
        return results[:k]

    def consolidate(self) -> None:
        """No-op for working memory (short-lived)."""

    def clear(self) -> None:
        self._store.clear()

    def state_dict(self) -> dict[str, Any]:
        return {"entries": dict(self._store)}

    def load_state_dict(self, state: dict[str, Any]) -> None:
        self._store = dict(state.get("entries", {}))

    def __len__(self) -> int:
        return len(self._store)

    def __repr__(self) -> str:
        return f"WorkingMemory(entries={len(self._store)}, max={self.max_entries})"
