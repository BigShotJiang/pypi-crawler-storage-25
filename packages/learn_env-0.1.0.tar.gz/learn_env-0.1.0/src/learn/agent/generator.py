"""
---
title: Generator Agent — Simple LLM Call Agent
summary: >
    The simplest agent: takes input, calls the LLM, returns output.
    Owns a learnable system prompt Parameter for optimization.
---

# Generator Agent

The most basic agent — a single LLM call with an optimizable system prompt.
Analogous to a single linear layer in a neural network.

$$\\text{output} = \\text{LLM}(\\text{system\\_prompt}, \\text{observation})$$
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState, Variable
from learn.optim.txt.autograd.llm_call import LLMCall

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM


class Generator(Agent):
    r"""
    <a id="Generator"></a>

    ## Generator

    Simple agent that wraps a single LLM call with a learnable
    system prompt.

    ```python
    gen = Generator(
        engine=engine,
        system_prompt="You are a helpful math tutor.",
    )
    output = gen(TextState(observation="What is 2+2?"))
    ```

    The system prompt is a ``Parameter`` that can be optimized via TGD:

    ```python
    optimizer = TGD(params=list(gen.parameters()), engine=engine)
    loss = loss_fn(output_var)
    loss.backward(engine)
    optimizer.step()
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        system_prompt: str = "You are a helpful assistant.",
        *,
        name: str | None = None,
        output_role: str = "response",
        requires_opt: bool = True,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Generator", skills=skills)
        self.output_role = output_role
        self._llm_call = LLMCall(engine)

        # Learnable system prompt — set requires_opt=False for agents
        # used in fixed-prompt settings (e.g., search, evaluation).
        self.system_prompt = Parameter(
            data=system_prompt,
            param_type=ParameterType.PROMPT,
            role_description="system prompt for the generator",
            requires_opt=requires_opt,
        )

    def forward(self, state: TextState) -> TextState:
        """Call the LLM with the system prompt and observation.

        Args:
            state: Input TextState with ``observation`` set.

        Returns:
            New TextState with the LLM's response as ``observation``.
        """
        input_var = Variable(
            data=state.observation,
            role_description="user input",
            requires_grad=False,
        )

        output_var = self._llm_call.forward(
            input_var,
            system_prompt=self.system_prompt.data,
        )
        output_var.role_description = self.output_role

        return state.update(
            observation=output_var.data,
            metadata={**state.metadata, "_last_output_var": output_var},
        )

    def generate_n(self, state: TextState, n: int = 1) -> list[TextState]:
        """Generate ``n`` responses for the same input.

        Useful for sampling-based strategies (ToT value evaluation,
        self-consistency, best-of-n).

        Args:
            state: Input TextState with ``observation`` set.
            n: Number of completions to generate.

        Returns:
            List of ``n`` TextState outputs.
        """
        responses = self.engine.generate_n(
            state.observation,
            n=n,
            system_prompt=self.system_prompt.data,
        )
        return [
            state.update(observation=r)
            for r in responses
        ]
