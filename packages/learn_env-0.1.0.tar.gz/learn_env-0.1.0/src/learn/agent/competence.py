"""
---
title: Bayesian Competence Tracker
summary: >
    Per-(agent, skill) competence tracking using Beta distributions
    with online Bayesian updating. Addresses API Issue #31.
---

# Competence Tracker

SkillOrchestra-style competence profiling: maintain Beta(α,β)
distributions per (agent, skill) pair, updated from execution traces.

$$P(\\theta | \\alpha, \\beta) = \\text{Beta}(\\alpha, \\beta)$$
$$E[\\theta] = \\frac{\\alpha}{\\alpha + \\beta}$$
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass


@dataclass
class BetaDistribution:
    """Beta distribution with online updating.

    $$\\text{expected value} = \\frac{\\alpha}{\\alpha + \\beta}$$
    $$\\text{variance} = \\frac{\\alpha\\beta}{(\\alpha+\\beta)^2(\\alpha+\\beta+1)}$$
    """

    alpha: float = 1.0
    beta: float = 1.0

    @property
    def mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def variance(self) -> float:
        ab = self.alpha + self.beta
        return (self.alpha * self.beta) / (ab * ab * (ab + 1))

    @property
    def std(self) -> float:
        return math.sqrt(self.variance)

    def update(self, success: bool) -> None:
        """Update with a Bernoulli observation."""
        if success:
            self.alpha += 1
        else:
            self.beta += 1

    def sample(self) -> float:
        """Thompson sampling: draw from the Beta distribution."""
        return random.betavariate(self.alpha, self.beta)


class CompetenceTracker:
    r"""
    <a id="CompetenceTracker"></a>

    ## CompetenceTracker

    Tracks per-(agent, skill) competence via Beta distributions.

    ```python
    tracker = CompetenceTracker()
    tracker.register_agent("coder", skills=["python", "testing"])
    tracker.update("coder", "python", success=True)
    tracker.update("coder", "python", success=False)

    # Select best agent for a skill
    best = tracker.select_agent("python")

    # Get competence summary
    summary = tracker.competence_matrix()
    ```
    """

    def __init__(self) -> None:
        self._competences: dict[tuple[str, str], BetaDistribution] = {}
        self._agents: dict[str, list[str]] = {}

    def register_agent(
        self,
        agent_name: str,
        skills: list[str] | None = None,
    ) -> None:
        """Register an agent with optional skill list.

        Args:
            agent_name: Unique agent identifier.
            skills: List of skill names the agent can perform.
        """
        self._agents[agent_name] = skills or []
        for skill in (skills or []):
            key = (agent_name, skill)
            if key not in self._competences:
                self._competences[key] = BetaDistribution()

    def update(self, agent: str, skill: str, success: bool) -> None:
        """Update competence based on execution outcome.

        Args:
            agent: Agent name.
            skill: Skill name.
            success: Whether the task was completed successfully.
        """
        key = (agent, skill)
        if key not in self._competences:
            self._competences[key] = BetaDistribution()
            if agent not in self._agents:
                self._agents[agent] = []
            if skill not in self._agents[agent]:
                self._agents[agent].append(skill)
        self._competences[key].update(success)

    def get_competence(self, agent: str, skill: str) -> float:
        """Get expected competence (mean of Beta distribution)."""
        key = (agent, skill)
        if key in self._competences:
            return self._competences[key].mean
        return 0.5  # Uninformative prior

    def select_agent(
        self,
        skill: str,
        method: str = "thompson",
    ) -> str:
        """Select the best agent for a skill.

        Args:
            skill: The skill to select for.
            method: Selection method — "thompson" (sampling) or
                "greedy" (highest mean).

        Returns:
            Name of the selected agent.
        """
        candidates = [
            (agent, (agent, skill))
            for agent in self._agents
            if (agent, skill) in self._competences
        ]
        if not candidates:
            # Return any registered agent
            agents = list(self._agents.keys())
            return agents[0] if agents else ""

        if method == "thompson":
            samples = [
                (self._competences[key].sample(), agent)
                for agent, key in candidates
            ]
            return max(samples, key=lambda x: x[0])[1]
        else:  # greedy
            scores = [
                (self._competences[key].mean, agent)
                for agent, key in candidates
            ]
            return max(scores, key=lambda x: x[0])[1]

    def competence_matrix(self) -> dict[str, dict[str, float]]:
        """Return competence matrix as nested dict.

        Returns:
            ``{agent: {skill: expected_competence}}``
        """
        result: dict[str, dict[str, float]] = {}
        for (agent, skill), dist in self._competences.items():
            if agent not in result:
                result[agent] = {}
            result[agent][skill] = dist.mean
        return result

    def uncertain_skills(self, agent: str, threshold: float = 0.2) -> list[str]:
        """Find skills where competence is most uncertain.

        Args:
            agent: Agent name.
            threshold: Variance threshold above which skill is uncertain.

        Returns:
            List of skill names with high uncertainty.
        """
        uncertain = []
        for skill in self._agents.get(agent, []):
            key = (agent, skill)
            if key in self._competences:
                if self._competences[key].variance > threshold:
                    uncertain.append(skill)
        return uncertain
