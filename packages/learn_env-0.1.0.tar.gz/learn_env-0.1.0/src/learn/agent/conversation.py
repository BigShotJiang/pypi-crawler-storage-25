"""
---
title: Multi-Agent Conversation
summary: >
    Turn-based conversation abstraction for multi-agent dialogue.
    Addresses API Issue #22: each example reimplementing turn alternation,
    context building, stopping criteria, and answer extraction.
---

# Multi-Agent Conversation

Provides structured turn-based dialogue between agents with pluggable
stopping criteria and automatic context management.

```python
conv = Conversation(
    agents={"alice": alice_gen, "bob": bob_gen},
    turn_order=["alice", "bob"],
    max_turns=10,
    stop_condition=lambda msg: "[ANSWER:" in msg,
)
result = conv.run("Solve this problem together.")
```
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from learn.agent.base import Agent


@dataclass
class Message:
    """A single message in a conversation."""

    role: str
    content: str
    turn: int
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConversationResult:
    """Result of a multi-agent conversation."""

    messages: list[Message] = field(default_factory=list)
    final_answer: str = ""
    total_turns: int = 0
    stopped_by: str = ""  # "max_turns" | "stop_condition" | "consensus"

    def format_transcript(self) -> str:
        """Format the conversation as a readable transcript."""
        lines = []
        for msg in self.messages:
            lines.append(f"[Turn {msg.turn}] {msg.role}: {msg.content}")
        return "\n\n".join(lines)


class Conversation:
    r"""
    <a id="Conversation"></a>

    ## Conversation

    Multi-agent turn-based dialogue manager.

    ```python
    conv = Conversation(
        agents={"solver": solver, "critic": critic},
        turn_order=["solver", "critic"],
        max_turns=6,
    )
    result = conv.run("What is 2+2?")
    print(result.final_answer)
    ```
    """

    def __init__(
        self,
        agents: dict[str, Agent],
        turn_order: list[str] | None = None,
        max_turns: int = 10,
        stop_condition: Callable[[str], bool] | None = None,
        context_window: int | None = None,
        answer_extractor: Callable[[str], str] | None = None,
    ) -> None:
        """Initialize conversation.

        Args:
            agents: Named agents participating in the conversation.
            turn_order: Order of agent turns (cycles). Defaults to
                dict key order.
            max_turns: Maximum number of turns before stopping.
            stop_condition: Function that takes the latest message content
                and returns True to stop the conversation.
            context_window: Max recent messages to include as context.
                None means include all.
            answer_extractor: Function to extract final answer from the
                last message. Defaults to returning the full message.
        """
        self.agents = agents
        self.turn_order = turn_order or list(agents.keys())
        self.max_turns = max_turns
        self.stop_condition = stop_condition
        self.context_window = context_window
        self.answer_extractor = answer_extractor or (lambda x: x)

    def _build_context(self, messages: list[Message], current_role: str) -> str:
        """Build context string from conversation history.

        Args:
            messages: All messages so far.
            current_role: The agent about to speak.

        Returns:
            Formatted context string.
        """
        window = messages
        if self.context_window is not None:
            window = messages[-self.context_window :]

        parts: list[str] = []
        for msg in window:
            parts.append(f"{msg.role}: {msg.content}")
        return "\n\n".join(parts)

    def run(self, prompt: str) -> ConversationResult:
        """Run the conversation.

        Args:
            prompt: Initial prompt to start the conversation.

        Returns:
            ConversationResult with messages and final answer.
        """
        from learn.env.program.variable import TextState

        messages: list[Message] = []
        stopped_by = "max_turns"

        for turn in range(self.max_turns):
            role = self.turn_order[turn % len(self.turn_order)]
            agent = self.agents[role]

            # Build input: initial prompt + conversation context
            if not messages:
                observation = prompt
            else:
                context = self._build_context(messages, role)
                observation = f"{prompt}\n\nConversation so far:\n{context}"

            # Call the agent
            state = TextState(observation=observation)
            output = agent(state)
            content = output.observation

            messages.append(Message(
                role=role,
                content=content,
                turn=turn,
            ))

            # Check stopping condition
            if self.stop_condition and self.stop_condition(content):
                stopped_by = "stop_condition"
                break

        final_answer = ""
        if messages:
            final_answer = self.answer_extractor(messages[-1].content)

        return ConversationResult(
            messages=messages,
            final_answer=final_answer,
            total_turns=len(messages),
            stopped_by=stopped_by,
        )
