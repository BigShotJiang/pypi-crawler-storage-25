"""
---
title: Programmer Agent — Code Generation
summary: >
    Agent specialized in code generation. Owns a learnable system
    prompt tuned for producing code in a specified language.
---
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from learn.agent.base import Agent
from learn.env.program.types import ParameterType
from learn.env.program.variable import Parameter, TextState, Variable
from learn.optim.txt.autograd.llm_call import LLMCall

if TYPE_CHECKING:
    from learn.env.engine.base import EngineLM

CODE_SYSTEM_PROMPT = (
    "You are an expert {language} programmer. Write clean, correct, "
    "well-structured {language} code. Include brief comments only where "
    "the logic is non-obvious. Return code only, no extra explanation."
)


class Programmer(Agent):
    """Code-generation agent with a learnable system prompt.

    ```python
    coder = Programmer(engine=engine, language="python")
    output = coder(TextState(observation="Write a binary search function"))
    ```
    """

    def __init__(
        self,
        engine: EngineLM,
        language: str = "python",
        *,
        name: str | None = None,
        requires_opt: bool = True,
        skills: dict | None = None,
    ) -> None:
        super().__init__(engine=engine, name=name or "Programmer", skills=skills)
        self.language = language
        self._llm_call = LLMCall(engine)

        self.system_prompt = Parameter(
            data=CODE_SYSTEM_PROMPT.format(language=language),
            param_type=ParameterType.PROMPT,
            role_description=f"system prompt for {language} code generation",
            requires_opt=requires_opt,
        )

    def forward(self, state: TextState) -> TextState:
        input_var = Variable(
            data=state.observation,
            role_description="code generation request",
            requires_grad=False,
        )
        output_var = self._llm_call.forward(
            input_var,
            system_prompt=self.system_prompt.data,
        )
        output_var.role_description = "generated code"

        return state.update(
            observation=output_var.data,
            metadata={**state.metadata, "_last_output_var": output_var},
        )
