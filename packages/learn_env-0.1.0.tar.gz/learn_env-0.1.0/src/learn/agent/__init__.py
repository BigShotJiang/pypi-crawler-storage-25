"""
---
title: learn.agent — Agent Subsystem
summary: >
    All agent types and capabilities: memory, tools, reasoning, profiles.
    Each agent is a Component with forward(TextState) → TextState.
---
"""
from learn.agent.base import Agent
from learn.agent.custom import Custom
from learn.agent.ensemble import Ensemble
from learn.agent.factory import AgentFactory
from learn.agent.generator import Generator
from learn.agent.meta_agent import MetaAgent
from learn.agent.programmer import Programmer
from learn.agent.retriever import Retriever
from learn.agent.reviewer import Reviewer
from learn.agent.reviser import Reviser
from learn.agent.router import Router

__all__ = [
    "Agent",
    "AgentFactory",
    "Custom",
    "Ensemble",
    "Generator",
    "MetaAgent",
    "Programmer",
    "Retriever",
    "Reviewer",
    "Reviser",
    "Router",
]