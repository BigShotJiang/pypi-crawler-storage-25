"""
---
title: Structured Output Parsing Utilities
summary: >
    Parsing helpers for extracting structured data from LLM outputs.
    Addresses API Issue #20: every example reimplementing custom regex
    parsing with try-except fallbacks.
---

# Structured Output Parsing

LLMs produce natural language with embedded structured data (JSON, XML tags,
delimited markers). These utilities provide robust extraction with fallbacks.
"""
from __future__ import annotations

import json
import re
from typing import Any


def parse_json(text: str, fallback: Any = None) -> Any:
    """Extract and parse JSON from LLM output.

    Handles cases where the LLM wraps JSON in markdown code fences
    or adds prefix/suffix text around the JSON object.

    Args:
        text: Raw LLM output that may contain JSON.
        fallback: Value to return if parsing fails entirely.

    Returns:
        Parsed JSON object, or ``fallback`` if extraction fails.

    Examples:
        >>> parse_json('{"key": "value"}')
        {'key': 'value'}
        >>> parse_json('Here is the result:\\n```json\\n{"x": 1}\\n```')
        {'x': 1}
        >>> parse_json('not json', fallback={})
        {}
    """
    # Strip markdown code fences
    fenced = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
    if fenced:
        text = fenced.group(1)

    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to find a JSON object or array in the text
    for pattern in [
        r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}",  # nested objects
        r"\[.*?\]",  # arrays
    ]:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError:
                continue

    return fallback


def parse_tagged(text: str, tag: str, default: str = "") -> str:
    """Extract content between XML-style tags.

    Args:
        text: Text containing tagged content.
        tag: Tag name (e.g., ``"answer"``, ``"code"``).
        default: Value if tag not found.

    Returns:
        Content between ``<tag>`` and ``</tag>``, stripped.

    Examples:
        >>> parse_tagged('<answer>42</answer>', 'answer')
        '42'
        >>> parse_tagged('no tags here', 'answer', 'N/A')
        'N/A'
    """
    pattern = rf"<{re.escape(tag)}>(.*?)</{re.escape(tag)}>"
    match = re.search(pattern, text, re.DOTALL)
    return match.group(1).strip() if match else default


def parse_delimited(
    text: str,
    start: str,
    end: str,
    default: str = "",
) -> str:
    """Extract content between arbitrary delimiters.

    Args:
        text: Text to search.
        start: Opening delimiter (e.g., ``"[ANSWER: "``).
        end: Closing delimiter (e.g., ``"]"``).
        default: Fallback value.

    Returns:
        Content between delimiters, stripped.

    Examples:
        >>> parse_delimited('The answer is [ANSWER: 42].', '[ANSWER: ', ']')
        '42'
    """
    s_idx = text.find(start)
    if s_idx == -1:
        return default
    s_idx += len(start)
    e_idx = text.find(end, s_idx)
    if e_idx == -1:
        return text[s_idx:].strip() or default
    return text[s_idx:e_idx].strip() or default


def parse_sections(
    text: str,
    section_pattern: str = r"^##?\s+(.+)$",
) -> dict[str, str]:
    """Parse markdown-style sections from text.

    Args:
        text: Text with section headers.
        section_pattern: Regex for section headers (must have 1 group).

    Returns:
        Dict mapping section titles to their content.
    """
    sections: dict[str, str] = {}
    current_title = ""
    current_lines: list[str] = []

    for line in text.split("\n"):
        match = re.match(section_pattern, line, re.MULTILINE)
        if match:
            if current_title:
                sections[current_title] = "\n".join(current_lines).strip()
            current_title = match.group(1).strip()
            current_lines = []
        else:
            current_lines.append(line)

    if current_title:
        sections[current_title] = "\n".join(current_lines).strip()

    return sections


def parse_list(text: str, marker: str = r"[-*\d.]") -> list[str]:
    """Extract list items from LLM output.

    Args:
        text: Text containing a list.
        marker: Regex for list markers (default: bullets or numbers).

    Returns:
        List of extracted items.

    Examples:
        >>> parse_list('- item1\\n- item2\\n- item3')
        ['item1', 'item2', 'item3']
    """
    pattern = rf"^\s*{marker}+\s*\.?\s*(.+)$"
    return [
        m.group(1).strip()
        for m in re.finditer(pattern, text, re.MULTILINE)
    ]


def parse_key_value(text: str, sep: str = ":") -> dict[str, str]:
    """Extract key-value pairs from structured LLM output.

    Args:
        text: Text with ``key: value`` lines.
        sep: Separator between key and value.

    Returns:
        Dict of extracted pairs.

    Examples:
        >>> parse_key_value('Name: Alice\\nAge: 30')
        {'Name': 'Alice', 'Age': '30'}
    """
    result: dict[str, str] = {}
    for line in text.strip().split("\n"):
        if sep in line:
            key, _, value = line.partition(sep)
            key = key.strip()
            value = value.strip()
            if key:
                result[key] = value
    return result


def extract_code_blocks(text: str, language: str | None = None) -> list[str]:
    """Extract fenced code blocks from markdown-style text.

    Args:
        text: Text containing code blocks.
        language: If given, only extract blocks with this language tag.

    Returns:
        List of code block contents.
    """
    if language:
        pattern = rf"```{re.escape(language)}\s*\n(.*?)\n\s*```"
    else:
        pattern = r"```(?:\w+)?\s*\n(.*?)\n\s*```"
    return [m.group(1) for m in re.finditer(pattern, text, re.DOTALL)]
