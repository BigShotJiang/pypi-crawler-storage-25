from __future__ import annotations

import logging
import pathlib
import re
from abc import ABC, abstractmethod
from collections.abc import Generator
from dataclasses import dataclass

log = logging.getLogger(__name__)


ACCEPTED_VIDEO_SUFFIXES = {".mkv", ".m4v"}
RESOLUTION_PATTERN = re.compile(r"\d{3,4}[pi]$")


@dataclass
class MovieInfo:
    """Metadata for the whole movie"""

    title: str
    year: str | None = None
    provider: str | None = None
    movie_id: str | None = None


@dataclass
class VideoInfo:
    """Metadata for a single video file"""

    extension: str
    edition: str | None = None
    resolution: str | None = None
    tags: set[str] | None = None


class MediaLibrary(ABC):
    def __init__(self, base_dir: pathlib.Path):
        self.base_dir = base_dir.resolve()

    @classmethod
    @abstractmethod
    def shortname(cls) -> str: ...

    @abstractmethod
    def movie_name(self, movie: MovieInfo) -> str: ...

    def movie_path(self, movie: MovieInfo) -> pathlib.Path:
        return self.base_dir / self.movie_name(movie)

    @abstractmethod
    def video_name(self, movie: MovieInfo, video: VideoInfo) -> str: ...

    def video_path(self, movie: MovieInfo, video: VideoInfo) -> pathlib.Path:
        return self.movie_path(movie) / self.video_name(movie, video)

    @abstractmethod
    def parse_movie_path(self, path: pathlib.Path) -> MovieInfo | None: ...

    @abstractmethod
    def parse_video_path(self, path: pathlib.Path) -> VideoInfo: ...

    def scan(self) -> Generator[tuple[pathlib.Path, MovieInfo], None, None]:
        for entry in self.base_dir.glob("*"):
            if not entry.is_dir():
                continue

            movie = self.parse_movie_path(entry)
            if not movie:
                log.warning("Ignoring folder with unparsable name: %s", entry.name)
                continue

            yield entry, movie
