"""Integration tests against the live CardShowData API.

Run with: pytest tests/test_integration.py -v
Requires CSD_TEST_API_KEY env var (or set in repo .env).
"""

import os

import pytest

# Load .env from repo root if running locally
_env_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", ".env")
if os.path.exists(_env_path):
    for line in open(_env_path):
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

API_KEY = os.environ.get("CSD_TEST_API_KEY")
if not API_KEY:
    pytest.skip("CSD_TEST_API_KEY not set — skipping integration tests", allow_module_level=True)

from cardshowdata import (
    AsyncCardShowData,
    AuthenticationError,
    CardShowData,
    NotFoundError,
)


@pytest.fixture(scope="module")
def client():
    c = CardShowData(api_key=API_KEY, base_url="https://api.cardshowdata.com")
    yield c
    c.close()


# ── Cards ────────────────────────────────────────────────────────────

class TestCardsIntegration:
    def test_get_card_by_pretty_id(self, client):
        card = client.cards.get("pk_bs_004")
        assert card.name is not None
        assert card.csd_product_id is not None
        assert card.expansion is not None

    def test_get_card_with_include(self, client):
        card = client.cards.get("pk_bs_004", include=["details"])
        assert card.details is not None

    def test_search_cards(self, client):
        page = client.cards.search(tcg="pk", q="name:charizard", page_size=5)
        assert len(page.data) > 0
        assert page.pagination.total_count > 0
        assert page.data[0].name is not None

    def test_search_cards_pagination(self, client):
        page1 = client.cards.search(tcg="pk", page=1, page_size=2)
        assert len(page1.data) == 2
        assert page1.pagination.total_pages > 1

    def test_list_by_expansion(self, client):
        # Expansion IDs use TCGPlayer group names like "base1"
        page = client.cards.list_by_expansion("base1", page_size=5)
        assert len(page.data) > 0


# ── Pricing ──────────────────────────────────────────────────────────

class TestPricingIntegration:
    def test_get_pricing(self, client):
        card = client.cards.get("pk_bs_004")
        price = client.pricing.get(card.csd_product_id)
        assert price.product_id == card.csd_product_id
        assert price.as_of_date is not None

    def test_bulk_pricing(self, client):
        card = client.cards.get("pk_bs_004")
        prices = client.pricing.bulk([card.csd_product_id])
        assert len(prices) == 1

    def test_pricing_history(self, client):
        card = client.cards.get("pk_bs_004")
        history = client.pricing.history(card.csd_product_id, days=7)
        assert isinstance(history, list)


# ── Catalog ──────────────────────────────────────────────────────────

class TestCatalogIntegration:
    def test_list_tcgs(self, client):
        tcgs = client.catalog.list_tcgs()
        assert len(tcgs) >= 16
        slugs = [t.tcg_slug for t in tcgs]
        assert "pokemon" in slugs
        assert "magic-the-gathering" in slugs

    def test_list_sets(self, client):
        sets = client.catalog.list_sets("pokemon")
        assert len(sets) > 0
        assert sets[0].set_code is not None

    def test_get_taxonomy(self, client):
        tax = client.catalog.get_taxonomy("pokemon")
        assert tax.tcg_slug == "pokemon"

    def test_list_products_cursor(self, client):
        page = client.catalog.list_products("pokemon", limit=5)
        assert len(page.items) > 0
        assert page.items[0].csd_product_id is not None

    def test_resolve(self, client):
        results = client.catalog.resolve(["pk_bs_004"])
        assert len(results) == 1
        assert results[0].csd_product_id is not None

    def test_search(self, client):
        results = client.catalog.search("charizard")
        assert len(results) > 0


# ── Usage ────────────────────────────────────────────────────────────

class TestUsageIntegration:
    def test_get_usage(self, client):
        usage = client.usage.get()
        assert "account_id" in usage.account
        assert "calls_today" in usage.daily


# ── Rate Limit Tracking ─────────────────────────────────────────────

class TestRateLimitIntegration:
    def test_rate_limit_populated(self, client):
        client.catalog.list_tcgs()
        assert client.rate_limit.limit is not None
        assert client.rate_limit.limit > 0
        assert client.rate_limit.remaining is not None


# ── Error Handling ───────────────────────────────────────────────────

class TestErrorsIntegration:
    def test_invalid_key(self):
        bad = CardShowData(api_key="csd_invalid_key_000", max_retries=0)
        with pytest.raises(AuthenticationError):
            bad.usage.get()
        bad.close()

    def test_not_found(self, client):
        with pytest.raises(NotFoundError):
            client.cards.get("pk_nonexistent_999")


# ── Async ────────────────────────────────────────────────────────────

class TestAsyncIntegration:
    @pytest.mark.asyncio
    async def test_async_get_card(self):
        async with AsyncCardShowData(api_key=API_KEY) as c:
            card = await c.cards.get("pk_bs_004")
            assert card.name is not None

    @pytest.mark.asyncio
    async def test_async_list_tcgs(self):
        async with AsyncCardShowData(api_key=API_KEY) as c:
            tcgs = await c.catalog.list_tcgs()
            assert len(tcgs) >= 16
