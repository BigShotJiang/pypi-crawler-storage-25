__version__ = "1.0.0"
API_VERSION = "v1"
