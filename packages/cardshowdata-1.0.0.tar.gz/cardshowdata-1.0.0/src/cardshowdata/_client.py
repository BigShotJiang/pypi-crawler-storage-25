"""Low-level HTTP client wrappers around httpx with retry, error mapping, and rate-limit tracking."""

from __future__ import annotations

import os
import random
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from ._exceptions import (
    ApiError,
    AuthenticationError,
    CardShowDataError,
    NotFoundError,
    PermissionError,
    RateLimitError,
)
from ._version import __version__

_DEFAULT_BASE_URL = "https://api.cardshowdata.com"
_DEFAULT_TIMEOUT = 30
_DEFAULT_MAX_RETRIES = 3
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503}


@dataclass
class RateLimitInfo:
    """Snapshot of the most recent rate-limit headers."""

    limit: int | None = None
    remaining: int | None = None
    reset: int | None = None


def _parse_error_detail(response: httpx.Response) -> str:
    try:
        body = response.json()
        if isinstance(body, dict) and "detail" in body:
            return str(body["detail"])
    except Exception:
        pass
    return response.text or f"HTTP {response.status_code}"


def _map_error(response: httpx.Response) -> CardShowDataError:
    detail = _parse_error_detail(response)
    status = response.status_code

    if status == 401:
        return AuthenticationError(detail)
    if status == 403:
        return PermissionError(detail)
    if status == 404:
        return NotFoundError(detail)
    if status == 429:
        limit = _int_header(response, "x-ratelimit-limit")
        remaining = _int_header(response, "x-ratelimit-remaining")
        reset = _int_header(response, "x-ratelimit-reset")
        retry_after: float | None = None
        if reset is not None:
            retry_after = max(0, reset - time.time())
        return RateLimitError(
            detail, retry_after=retry_after, limit=limit, remaining=remaining, reset=reset
        )
    return ApiError(detail, status_code=status)


def _int_header(response: httpx.Response, name: str) -> int | None:
    val = response.headers.get(name)
    if val is None:
        return None
    try:
        return int(val)
    except ValueError:
        return None


def _backoff_wait(attempt: int, response: httpx.Response | None) -> float:
    """Calculate wait time with jitter for retries."""
    if response is not None and response.status_code == 429:
        reset = _int_header(response, "x-ratelimit-reset")
        if reset is not None:
            wait = max(0, reset - time.time()) + random.uniform(0.1, 0.5)
            return wait
    base = min(2**attempt, 8)
    return base + random.uniform(0, base * 0.5)


def _resolve_api_key(api_key: str | None) -> str:
    key = api_key or os.environ.get("CSD_API_KEY")
    if not key:
        raise AuthenticationError("No API key provided. Pass api_key or set CSD_API_KEY env var.")
    return key


def _build_headers(api_key: str) -> dict[str, str]:
    return {
        "X-API-Key": api_key,
        "User-Agent": f"cardshowdata-python/{__version__}",
        "Accept": "application/json",
    }


def _update_rate_limit(rate_limit: RateLimitInfo, response: httpx.Response) -> None:
    rate_limit.limit = _int_header(response, "x-ratelimit-limit") or rate_limit.limit
    rate_limit.remaining = _int_header(response, "x-ratelimit-remaining")
    rate_limit.reset = _int_header(response, "x-ratelimit-reset") or rate_limit.reset


class SyncHttpClient:
    """Synchronous HTTP client with retry logic."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._api_key = _resolve_api_key(api_key)
        self._max_retries = max_retries
        self.rate_limit = RateLimitInfo()
        self._client = httpx.Client(
            base_url=base_url,
            headers=_build_headers(self._api_key),
            timeout=timeout,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        raw_response: bool = False,
    ) -> Any:
        last_exc: Exception | None = None
        last_response: httpx.Response | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_response is not None:
                wait = _backoff_wait(attempt - 1, last_response)
                time.sleep(wait)

            try:
                response = self._client.request(
                    method, path, params=params, json=json, data=data, files=files
                )
            except httpx.TimeoutException as e:
                last_exc = ApiError(f"Request timed out: {e}", status_code=None)
                last_response = None
                if attempt < self._max_retries:
                    continue
                raise last_exc from e

            _update_rate_limit(self.rate_limit, response)

            if response.status_code < 400:
                if raw_response:
                    return response
                return response.json()

            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                last_response = response
                last_exc = _map_error(response)
                continue

            raise _map_error(response)

        raise last_exc  # type: ignore[misc]

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SyncHttpClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncHttpClient:
    """Asynchronous HTTP client with retry logic."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._api_key = _resolve_api_key(api_key)
        self._max_retries = max_retries
        self.rate_limit = RateLimitInfo()
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=_build_headers(self._api_key),
            timeout=timeout,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        raw_response: bool = False,
    ) -> Any:
        import asyncio

        last_exc: Exception | None = None
        last_response: httpx.Response | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_response is not None:
                wait = _backoff_wait(attempt - 1, last_response)
                await asyncio.sleep(wait)

            try:
                response = await self._client.request(
                    method, path, params=params, json=json, data=data, files=files
                )
            except httpx.TimeoutException as e:
                last_exc = ApiError(f"Request timed out: {e}", status_code=None)
                last_response = None
                if attempt < self._max_retries:
                    continue
                raise last_exc from e

            _update_rate_limit(self.rate_limit, response)

            if response.status_code < 400:
                if raw_response:
                    return response
                return response.json()

            if response.status_code in _RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                last_response = response
                last_exc = _map_error(response)
                continue

            raise _map_error(response)

        raise last_exc  # type: ignore[misc]

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncHttpClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
