"""Exception hierarchy for the CardShowData SDK."""

from __future__ import annotations


class CardShowDataError(Exception):
    """Base exception for all CardShowData SDK errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(CardShowDataError):
    """Raised on 401 — missing or invalid API key."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, status_code=401)


class PermissionError(CardShowDataError):
    """Raised on 403 — insufficient entitlements or inactive account."""

    def __init__(self, message: str = "Permission denied") -> None:
        super().__init__(message, status_code=403)


class NotFoundError(CardShowDataError):
    """Raised on 404 — resource not found."""

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message, status_code=404)


class RateLimitError(CardShowDataError):
    """Raised on 429 — rate limit exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
        limit: int | None = None,
        remaining: int | None = None,
        reset: int | None = None,
    ) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining
        self.reset = reset


class ApiError(CardShowDataError):
    """Raised on 5xx or other unexpected errors."""

    pass
