# OSMP Python SDK

Reference implementation of the Octid Semantic Mesh Protocol. Encodes, decodes, composes, and validates agentic AI instructions using SAL (Semantic Assembly Language). 352 opcodes across 26 namespaces. SALComposer for deterministic NL-to-SAL composition (95.7% opcode coverage). MacroRegistry for pre-validated chain templates (16 Meshtastic macros shipped). Inference-free decode by table lookup.

## Install

```
pip install osmp
```

Zero dependencies beyond Python standard library (optional `zstandard` for D:PACK).

## Tier 1: Two Functions, Zero Setup

```python
from osmp import encode, decode

sal = encode(["H:HR@NODE1>120", "H:CASREP", "M:EVA@*"])
# "H:HR@NODE1>120;H:CASREP;M:EVA@*"

text = decode("H:HR@NODE1>120;H:CASREP;M:EVA@*")
# "(clinical) [clinical] heart rate above 120 at NODE1, then [clinical] casualty report, then [emergency] evacuation at all nodes"
```

Three lines. No instantiation. Module-level singleton, cached on first call.

### Additional Tier 1 Functions

```python
from osmp import validate, lookup, byte_size

result = validate("R:MOV@BOT1⚠")
print(result.valid)    # False -- ⚠ requires I:§ precondition

definition = lookup("R:WPT")
# "waypoint"

print(byte_size("H:HR@NODE1>120"))
# 15
```

## Tier 2: Class-Based Interface

For configuration beyond defaults (custom ASD floor, pre-loaded dependency rules, direct ASD access):

```python
from osmp.core import OSMP

o = OSMP()
sal = o.encode(["H:HR@NODE1>120", "H:CASREP"])
text = o.decode(sal)
result = o.validate(sal)
definition = o.lookup("H", "HR")
```

## Tier 3: Full Protocol Access

Direct access to encoder, decoder, ASD, and all protocol internals:

```python
from osmp.protocol import SALEncoder, SALDecoder, AdaptiveSharedDictionary, validate_composition

asd = AdaptiveSharedDictionary()
enc = SALEncoder(asd)
dec = SALDecoder(asd)

sal = enc.encode_frame("R", "MOV", target="BOT1", cc="↺")
result = dec.decode_frame(sal)
# result.namespace = "R"
# result.opcode = "MOV"
# result.opcode_meaning = "move"
# result.consequence_class_name = "REVERSIBLE"
```

## Composition Validation

Eight deterministic rules enforced before any instruction hits the wire:

1. **Hallucination check** -- every opcode must exist in the ASD
2. **Namespace-as-target** -- `@` must not be followed by `NS:OPCODE`
3. **R namespace consequence class** -- mandatory except `R:ESTOP`
4. **I:§ precondition** -- ⚠ and ⊘ require `I:§` in the chain
5. **Byte check** -- SAL bytes must not exceed NL bytes (exception: R safety chains)
6. **Slash rejection** -- `/` is not a SAL operator
7. **Mixed-mode check** -- no natural language embedded in SAL frames
8. **Regulatory dependency** -- REQUIRES rules from loaded MDR corpora

## Domain Code Resolution

```python
from osmp.protocol import BlockCompressor

bc = BlockCompressor()
bc.load("mdr/icd10cm/MDR-ICD10CM-FY2026-blk.dpack")
result = bc.resolve("J93.0")
# "Spontaneous tension pneumothorax"
```

Three corpora bundled: ICD-10-CM (74,719 codes), ISO 20022 (47,835 codes), MITRE ATT&CK (1,661 codes).

## MCP Server

The MCP server is a separate package that wraps this SDK:

```
pip install osmp-mcp
osmp-mcp
```

Nine tools for AI client integration. Connect from Claude Code (`claude mcp add osmp -- osmp-mcp`), Claude Desktop, Cursor, or any MCP-compatible client.

## License

Apache 2.0. Patent pending. Filed March 17, 2026.

## SALBridge: Mixed Environment Integration

When your agents communicate with non-OSMP peers, the bridge handles boundary translation.

```python
from osmp import bridge

b = bridge("MY_NODE")
b.register_peer("GPT_AGENT", attempt_fnp=False)

# Outbound: SAL decoded to NL, annotated with SAL equivalent
out = b.send("H:HR@NODE1>120", "GPT_AGENT")

# Inbound: scanned for SAL acquisition
result = b.receive("A:ACK", "GPT_AGENT")

# Metrics and comparison
metrics = b.get_metrics("GPT_AGENT")
comparison = b.get_comparison("GPT_AGENT")
```

The bridge annotates outbound messages with SAL, seeding the remote agent's context. When the remote agent starts producing valid SAL through exposure, FNP transitions from FALLBACK to ACQUIRED. OSMP spreads by contact, not installation.
