from swarm.config.loader import ConfigLoader


class TestConfigLoader:
    def test_load_maps_environment_variables_to_expected_keys(self) -> None:
        config = ConfigLoader.load(
            env={
                "OPENAI_API_KEY": "openai-key",
                "OPENAI_ORGANIZATION": "org-123",
                "OPENAI_PROJECT": "proj-123",
                "ANTHROPIC_API_KEY": "anthropic-key",
                "GOOGLE_API_KEY": "google-key",
                "VERTEX_PROJECT_ID": "vertex-project",
                "VERTEX_LOCATION": "europe-west1",
            }
        )

        assert config == {
            "openai_api_key": "openai-key",
            "openai_organization": "org-123",
            "openai_project": "proj-123",
            "anthropic_api_key": "anthropic-key",
            "google_api_key": "google-key",
            "vertex_project": "vertex-project",
            "vertex_location": "europe-west1",
        }

    def test_load_uses_empty_defaults_and_preserves_vertex_location_default(
        self,
    ) -> None:
        config = ConfigLoader.load(env={})

        assert config == {
            "openai_api_key": "",
            "openai_organization": "",
            "openai_project": "",
            "anthropic_api_key": "",
            "google_api_key": "",
            "vertex_project": "",
            "vertex_location": "us-east1",
        }
