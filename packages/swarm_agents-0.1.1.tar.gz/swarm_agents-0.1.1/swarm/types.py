"""Core shared types for the Swarm framework."""

from enum import StrEnum


# Enums (from app/api/models/common_types.py)
class MessageRole(StrEnum):
    # Base roles
    ASSISTANT = "assistant"
    USER = "user"
    # Completion message roles
    TOOL = "tool"
    SYSTEM = "system"


class ContentType(StrEnum):
    TEXT = "text"
    IMAGE = "image"
    FILE = "file"
    INTERACTIVE = "interactive"
    RICH = "rich"
    AUDIO = "audio"
