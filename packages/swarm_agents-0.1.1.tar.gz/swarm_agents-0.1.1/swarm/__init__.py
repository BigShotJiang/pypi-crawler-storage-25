"""
Swarm Framework - A lightweight OpenAI-compatible agent orchestration framework.

Swarm provides tools for building conversational AI agents with:
- Function calling and tool execution
- Agent handoffs and context management
- Streaming responses
- Provider-agnostic model routing via LiteLLM
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("swarm-agents")
except (
    PackageNotFoundError
):  # pragma: no cover - source tree without installed metadata
    __version__ = "0.0.0"

# Core Agent Types
from swarm.agent import Agent

# Chunk Types (for streaming)
from swarm.chunk import (
    AssistantMessageChunk,
    ChunkType,
    DelimiterChunk,
    ExecutionMetadata,
    ToolCallChunk,
    ToolResponseChunk,
)
from swarm.client import Swarm

# Config and provider wiring
from swarm.config.loader import ConfigLoader

# Guardrails
from swarm.guardrails import (
    GuardrailResult,
    InputGuardrail,
    InputGuardrailTripped,
    OutputGuardrail,
    OutputGuardrailContext,
    OutputGuardrailTripped,
)

# Lifecycle Hooks
from swarm.hooks import LifecycleHook

# Message Types
from swarm.message import (
    SwarmAssistantMessage,
    SwarmMessage,
    SwarmToolMessage,
    SwarmUserMessage,
    to_swarm_message,
)

# Provider Wiring
from swarm.providers.factory import ProviderFactory
from swarm.providers.protocols import ModelRouterProtocol
from swarm.providers.router import ModelRouter

# Provider Types
from swarm.providers.types import CompletionRequest, ToolCallDelta

# Runners
from swarm.runners.agent import AgentRunner, AgentRunResult, AgentSignal
from swarm.runners.dialogue import DialogueRunner

# Tool Types and Utilities
from swarm.tool import Result, ToolExecutionResponse, execute_tool, function_to_json

__all__ = [
    # Core
    "Agent",
    "Swarm",
    "ConfigLoader",
    "ModelRouter",
    "ModelRouterProtocol",
    "ProviderFactory",
    # Messages
    "SwarmAssistantMessage",
    "SwarmMessage",
    "SwarmToolMessage",
    "SwarmUserMessage",
    "to_swarm_message",
    # Tools
    "Result",
    "ToolExecutionResponse",
    "execute_tool",
    "function_to_json",
    # Runners
    "AgentRunner",
    "AgentRunResult",
    "AgentSignal",
    "DialogueRunner",
    # Chunks
    "AssistantMessageChunk",
    "ChunkType",
    "DelimiterChunk",
    "ExecutionMetadata",
    "ToolCallChunk",
    "ToolResponseChunk",
    # Lifecycle Hooks
    "LifecycleHook",
    # Guardrails
    "GuardrailResult",
    "InputGuardrail",
    "InputGuardrailTripped",
    "OutputGuardrail",
    "OutputGuardrailContext",
    "OutputGuardrailTripped",
    # Provider Types
    "CompletionRequest",
    "ToolCallDelta",
]
