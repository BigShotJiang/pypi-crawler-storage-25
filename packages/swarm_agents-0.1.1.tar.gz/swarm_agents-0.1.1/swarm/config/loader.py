"""Configuration loader for provider credentials."""

import os
from collections.abc import Mapping


class ConfigLoader:
    """Loads provider configs from environment."""

    @staticmethod
    def load(env: Mapping[str, str] | None = None) -> dict[str, str]:
        """Load all provider configs from an environment mapping.

        When ``env`` is omitted, the current process environment is used.

        Returns:
            Dict containing all provider API keys and settings
        """
        env_source = os.environ if env is None else env
        return {
            "openai_api_key": env_source.get("OPENAI_API_KEY", ""),
            "openai_organization": env_source.get("OPENAI_ORGANIZATION", ""),
            "openai_project": env_source.get("OPENAI_PROJECT", ""),
            "anthropic_api_key": env_source.get("ANTHROPIC_API_KEY", ""),
            "google_api_key": env_source.get("GOOGLE_API_KEY", ""),
            # Preserve the config keys expected by ProviderFactory.
            "vertex_project": env_source.get("VERTEX_PROJECT_ID", ""),
            "vertex_location": env_source.get("VERTEX_LOCATION", "us-east1"),
        }
