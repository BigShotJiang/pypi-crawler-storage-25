from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from swarm.agent import Agent
from swarm.message import SwarmMessage


class RunResult(BaseModel):
    """Result of a run."""

    messages: List[SwarmMessage]
    context_variables: Dict[str, Any]
    agent: Optional[Agent] = None
