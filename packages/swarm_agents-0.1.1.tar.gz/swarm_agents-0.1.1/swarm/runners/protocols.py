"""
Protocol definitions for swarm runners.

These protocols define the interfaces required by swarm runners,
allowing dependency injection and decoupling from specific implementations.
"""

from typing import Any, Dict, List, Protocol

from swarm.message import SwarmMessage


class DialogueContextProtocol(Protocol):
    """
    Protocol for dialogue context used by DialogueRunner.

    This interface defines the minimal contract required for
    any context object to work with the DialogueRunner.
    """

    @property
    def conversation_id(self) -> str:
        """
        Get the conversation ID.

        Returns:
            The unique identifier for this conversation as a string.
        """
        ...

    @property
    def current_context_variables(self) -> Dict[str, Any]:
        """
        Get current context variables.

        Returns:
            Dictionary of context variables for the current conversation state.
        """
        ...

    def get_history_for_completion(self) -> List[SwarmMessage]:
        """
        Get message history formatted for completion.

        Returns:
            List of SwarmMessage objects for completion requests.
        """
        ...


# Future: WorkflowContextProtocol can be added here when needed
