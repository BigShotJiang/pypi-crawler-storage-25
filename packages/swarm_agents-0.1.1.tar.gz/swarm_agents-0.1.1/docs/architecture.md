# Swarm Architecture

## Overview

`swarm-agents` is a lightweight runtime for LLM-driven agents with:

- provider-agnostic model routing
- tool execution
- lifecycle hooks
- input/output guardrails
- streaming dialogue execution
- autonomous batch execution

The package import path is `swarm`. The beginner-facing entry point is
`Swarm(...)`, which composes provider configuration and router wiring for common
use cases. Power users can still wire the lower-level types directly.

## Main Building Blocks

### `Agent`

`Agent` defines the LLM-facing behavior:

- `name`
- `model`
- `instructions`
- `tools`
- `hooks`
- `input_guardrails`
- `output_guardrails`

`Agent.model` accepts either:

- a single model string
- a list of models in fallback order

When a list is provided, the router tries each model in sequence until one
succeeds or all fail.

### `Swarm`

`Swarm` is the package facade for common consumers.

It composes:

1. `ConfigLoader.load()`
2. `ProviderFactory(config=...)`
3. `ModelRouter(factory=...)`
4. `RunContext(..., router=...)`

Use it when you want the package to handle provider/router wiring but still want
full control over your application-specific runtime protocols.

### `RunContext`

`RunContext` carries runtime dependencies into the runners and tools:

- `deps`
- `stream_manager`
- `message_store`
- `router`
- optional `retry_policy`

The runtime protocols are intentionally application-owned. `swarm-agents` does
not ship default in-memory implementations for these dependencies.

## Execution Model

There are two runner modes:

### `DialogueRunner`

`DialogueRunner.run_streamed(...)` is the streaming path.

It:

- converts messages into model input
- streams assistant output incrementally
- executes tool calls
- returns structured chunks to the caller
- treats output guardrails as advisory

This is the mode used behind `Swarm.run_streamed(...)`.

### `AgentRunner`

`AgentRunner.run_batch(...)` is the autonomous batch path.

It:

- runs the same core loop without streaming
- executes tools and model turns until completion or pause
- returns a structured `AgentRunResult`
- treats output guardrails as blocking

This is the mode used behind `Swarm.run_batch(...)`.

## Tool Execution

Tools are plain callables wrapped with `function_tool`.

During execution:

1. the model emits tool calls
2. `execute_tools(...)` resolves the requested tools
3. arguments are validated and parsed
4. each tool returns a `Result`
5. results become `SwarmToolMessage` objects that flow back into the loop

Important semantics:

- unknown tool names become error tool messages
- invalid tool-call JSON becomes error tool messages
- malformed tool calls missing a usable id or function name are skipped
- hook callbacks fire per individual tool call, not per batch

## Hooks

Hooks are observational only. They do not alter control flow.

Available boundaries:

- `on_llm_start`
- `on_llm_end`
- `on_tool_start`
- `on_tool_end`

Hook failures are caught and logged. They do not crash the runner.

Typical uses:

- logging
- tracing
- metrics
- latency measurement

## Guardrails

Guardrails validate either:

- input before the first model call
- output after the loop completes

### Input guardrails

- run once before the first LLM call
- tripwires halt execution immediately

### Output guardrails

- in `AgentRunner`: blocking
- in `DialogueRunner`: advisory, surfaced on final execution metadata

This split is intentional. Streaming content may already have been emitted by
the time output validation runs.

## Retry Model

Package-level retry focuses on tool execution via `ToolRetryExecutor`.

It is:

- result-based, not exception-based
- driven by `Result.is_error` and `Result.error_type`
- configured by a caller-supplied `RetryPolicyProtocol`

This keeps retry behavior explicit and injectable. Broader workflow/task retry
policies belong in the consuming application.

## Provider Routing

Provider access is layered:

1. `ConfigLoader` reads provider config from environment or an injected mapping
2. `ProviderFactory` builds provider clients from explicit config
3. `ModelRouter` chooses the correct provider for a model string
4. the runner calls the router for completions or streaming

The core package uses explicit dependency injection:

- `ProviderFactory` requires config
- `ModelRouter` requires a factory
- `RunContext` requires a router

The facade lives above these types. It does not reintroduce hidden defaults
inside the core runtime.

## Manual Wiring

For advanced integrations, wire the package directly:

```python
from swarm import Agent, ConfigLoader, DialogueRunner, ModelRouter, ProviderFactory
from swarm.context import RunContext

config = ConfigLoader.load()
router = ModelRouter(factory=ProviderFactory(config=config))

run_context = RunContext(
    deps=your_context,
    stream_manager=your_stream_manager,
    message_store=your_message_store,
    router=router,
    retry_policy=your_retry_policy,
)

runner = DialogueRunner()
```

This is the recommended path for:

- tests
- custom routers
- nonstandard provider wiring
- framework integrations that already own composition
