# Swarm Error Handling

## Overview

`swarm-agents` handles errors in three distinct places:

1. tool execution
2. guardrail validation
3. provider/model routing

The package is designed so that failures are:

- typed where possible
- visible to the caller
- safe for LLM loops
- compatible with caller-supplied retry policy

## Tool Errors

Tool functions communicate expected failures through `Result`:

```python
from swarm.tool import ErrorType, Result

return Result(
    value="Project not found.",
    is_error=True,
    error_type=ErrorType.BUSINESS,
)
```

This is the preferred path for application-level failures because it keeps the
tool loop structured and lets the retry layer make explicit decisions.

### Error categories

`ErrorType` classifies tool failures into five groups:

| ErrorType | Meaning | Retryable by default | LLM sees raw message |
|-----------|---------|----------------------|----------------------|
| `INTERNAL` | Bug or unexpected failure | No | No, sanitized |
| `TRANSIENT` | Timeout/network/service flake | Yes | No |
| `VALIDATION` | Bad tool arguments from the model | No | Yes |
| `BUSINESS` | Expected business rule failure | No | Yes |
| `USER_INPUT` | User must correct input | No | Yes |

### How retries work

`ToolRetryExecutor` is the package retry mechanism.

It:

- checks `Result.is_error`
- maps `ErrorType` to retry policy categories
- applies constant, linear, or exponential backoff
- optionally adds jitter
- stops after `max_retries`

Retry behavior is injected through `RetryPolicyProtocol`. The package does not
create a default retry policy on its own.

## Exception Handling in Tools

Unexpected exceptions raised by tools are caught and converted into structured
error results during execution.

The high-level behavior is:

- validation exceptions become validation errors
- timeout / connection / OS-style transport issues become transient errors
- everything else becomes internal error

Internal errors are sanitized before they are surfaced back to the model.

## Guardrail Failures

Guardrails use explicit tripwire exceptions rather than generic booleans.

### Input guardrails

If an input guardrail trips:

- execution stops before the first LLM call
- the runner raises `InputGuardrailTripped`

### Output guardrails

If an output guardrail trips:

- `AgentRunner` raises `OutputGuardrailTripped`
- `DialogueRunner` reports the result as advisory metadata on the final chunk

This difference exists because streaming output may already be visible by the
time output validation completes.

## Hook Failures

Hooks are observational only. Hook exceptions never control the run.

If a hook raises:

- the exception is caught
- the failure is logged
- execution continues

This applies to both model and tool boundaries.

## Tool Call Edge Cases

The tool executor handles malformed or invalid tool calls defensively:

- unknown tool name -> error tool message
- invalid JSON arguments -> error tool message
- missing tool id or missing tool function name -> skip the malformed call

Hook semantics remain consistent:

- valid tool calls fire per-call hook boundaries
- malformed calls that lack a usable id/name are skipped entirely

## Provider and Routing Failures

Provider failures surface at the model-routing layer.

Important package behavior:

- a single `Agent.model` string routes to one provider/model target
- a list of models is treated as fallback order
- the router tries each configured model in sequence until one succeeds or all
  fail

This allows callers to build resilience at the model-selection layer without
embedding fallback logic in application code.

## What the Package Does Not Own

`swarm-agents` does not implement broader application workflow retry or HTTP/API
error translation.

Those concerns belong in the consuming system:

- API exception mapping
- database error translation
- background job retry
- workflow node retry policies

The package boundary is intentionally narrower:

- model/tool loop orchestration
- structured tool failures
- guardrail tripwires
- tool retry policy

## Practical Guidance

Use the following rule of thumb:

- expected tool/business failure -> return `Result(is_error=True, error_type=...)`
- model supplied bad arguments -> return validation error
- user must change input -> return user-input error
- flaky dependency -> transient error
- actual bug -> let it classify as internal

That keeps retry, sanitization, and model feedback aligned with the package’s
execution model.
