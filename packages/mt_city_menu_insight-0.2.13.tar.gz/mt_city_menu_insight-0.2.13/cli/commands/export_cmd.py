"""export ranking - 生成 Excel 并上传"""
import sys
import typer
import httpx
from rich.console import Console
from cli.local import store, auth

console = Console()

SERVER_URL = auth.get_server_url()

_DT_WINDOW_TO_DATE_TYPE = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "30d": 30}

_IS_INTERACTIVE = sys.stdin.isatty()


def export_ranking(
    run_id: str = typer.Option(..., "--run-id"),
):
    data = store.load(run_id)
    rk = data.get("active_ranking", "rank_by_main")
    items = data.get(rk, [])

    # ── 导出前检查服务端缓存 ──────────────────────────────────────
    _check_server_cache_before_export(data)

    dt_window = data.get("dt_window", "1d")
    date_type = _DT_WINDOW_TO_DATE_TYPE.get(dt_window, 30)
    sort_by = data.get("sort_by", "orders_main")
    sort_type = "ORDER_SPACE_DESC" if sort_by == "order_space" else "SALES_DESC"

    try:
        resp = httpx.post(
            f"{SERVER_URL}/api/insight/opportunity/v1/export",
            headers=auth.get_headers(),
            json={
                "cityName": data.get("city", ""),
                "categoryName": data.get("category", ""),
                "topN": data.get("top_n", 50),
                "dateType": date_type,
                "sortType": sort_type,
                "productList": items,
            },
            timeout=30,
        )
        resp.raise_for_status()
        result = resp.json()
        url = result.get("data", {}).get("downloadUrl", "")
    except Exception as e:
        console.print(f"[red]上传失败：{e}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[green]导出成功[/green]")
    console.print(f"链接：{url}")

    data["export_url"] = url
    store.save(run_id, data)


def _check_server_cache_before_export(data: dict):
    """导出前静默查询服务端缓存状态，若有缓存则提示用户确认是否覆盖。
    请求失败时静默忽略，不影响导出流程。"""
    try:
        dt_window = data.get("dt_window", "1d")
        date_type = _DT_WINDOW_TO_DATE_TYPE.get(dt_window, 30)
        sort_by = data.get("sort_by", "orders_main")
        sort_type = "ORDER_SPACE_DESC" if sort_by == "order_space" else "SALES_DESC"
        price_min = data.get("price_min")
        price_max = data.get("price_max")

        payload = {
            "dt": data.get("dt", ""),
            "cityName": data.get("city", ""),
            "categoryName": data.get("category", ""),
            "topN": data.get("top_n", 50),
            "sortType": sort_type,
            "minPrice": int(price_min) if price_min is not None else 0,
            "dateType": date_type,
        }
        if price_max is not None:
            payload["maxPrice"] = int(price_max)

        resp = httpx.post(
            f"{SERVER_URL}/api/insight/opportunity/v1/list/query",
            headers=auth.get_headers(),
            json=payload,
            timeout=15,
        )
        resp.raise_for_status()
        result = resp.json()
        if str(result.get("code", "0")) != "0":
            return

        source = result.get("data", {}).get("source", "NEW_QUERY").upper()
        if source != "CACHED":
            return

        version_info = result.get("data", {}).get("versionInfo") or {}
        cached_dt = version_info.get("dt", "")
        creator = version_info.get("creatorMis", "")
        console.print(f"[yellow]服务端已有该清单的缓存（dt={cached_dt}，操作人：{creator}），是否覆盖？[/yellow]")

        if _IS_INTERACTIVE:
            confirmed = typer.confirm("覆盖导出？", default=False)
            if not confirmed:
                console.print("[yellow]已取消导出。[/yellow]")
                raise typer.Exit(0)
        # Skill 端：非交互式时，输出提示后继续导出（由 Skill 在 SKILL.md 中说明此行为）

    except typer.Exit:
        raise
    except Exception:
        pass  # 静默忽略，不影响导出
