"""cli/commands/config_cmd.py - 配置管理命令"""
import shutil
import typer
from pathlib import Path
from cli.local.auth import save_config, get_mis, get_token

_OUTPUTS_DIR = Path.home() / ".local" / "share" / "tsp-ops" / "outputs"


def config_auth_login():
    """触发大象 App 授权，获取并缓存 token"""
    try:
        get_token()
        typer.echo("授权成功。")
    except Exception as e:
        typer.echo(f"授权失败：{e}")
        raise typer.Exit(1)


def config_set_mis(mis: str = typer.Argument(..., help="美团 MIS ID")):
    """写入 MIS ID 到配置文件"""
    save_config(mis=mis.strip())
    typer.echo(f"MIS ID 已写入配置文件：{mis.strip()}")


def config_show():
    """显示当前配置"""
    mis = get_mis()
    typer.echo(f"mis: {mis if mis else '(未配置)'}")


def config_clear_cache(
    yes: bool = typer.Option(False, "--yes", "-y", help="跳过确认直接删除"),
):
    """清理所有本地榜单缓存（~/.local/share/tsp-ops/outputs/）"""
    if not _OUTPUTS_DIR.exists():
        typer.echo("本地缓存目录不存在，无需清理。")
        return

    runs = list(_OUTPUTS_DIR.iterdir())
    if not runs:
        typer.echo("本地缓存为空，无需清理。")
        return

    typer.echo(f"将删除 {len(runs)} 条本地榜单缓存：{_OUTPUTS_DIR}")
    if not yes:
        typer.confirm("确认删除？", abort=True)

    shutil.rmtree(_OUTPUTS_DIR)
    typer.echo("已清理。")
