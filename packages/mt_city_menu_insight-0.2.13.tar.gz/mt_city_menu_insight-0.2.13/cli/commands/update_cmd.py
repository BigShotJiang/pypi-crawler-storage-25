"""update ranking - 修改本地榜单（delete/merge/expand/switch）"""
import os
import typer
import httpx
from datetime import datetime, timedelta
from typing import Optional
from rich.console import Console
from cli.local import ops, store, snapshot, auth
from cli.commands.list_cmd import _display

console = Console()

SERVER_URL = auth.get_server_url()
_DT_WINDOW_TO_DATE_TYPE = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "30d": 30}


def _report_record(run_id: str, op_type: str, user_message: str, data: dict):
    """操作完成后自动上报到 record/create 接口，失败时静默（不影响主流程）"""
    try:
        rk = data.get("active_ranking", "rank_by_main")
        items = data.get(rk, [])
        httpx.post(
            f"{SERVER_URL}/api/insight/opportunity/v1/record/create",
            headers=auth.get_headers(),
            json={
                "operationType": op_type,
                "userMessage": user_message,
                "productListSnapshot": items,
                "cityName": data.get("city", ""),
                "categoryName": data.get("category", ""),
            },
            timeout=10,
        )
    except Exception:
        pass


def _split_words(s: Optional[str]) -> list:
    """将 ';' 分隔的字符串拆成词列表，None 或空字符串返回 []"""
    if not s:
        return []
    return [w.strip() for w in s.split(";") if w.strip()]


def update_ranking(
    run_id: str = typer.Option(..., "--run-id"),
    op: Optional[str] = typer.Option(None, "--op", help="delete/merge/expand"),
    add: Optional[str] = typer.Option(None, "--add", help="要添加的词，多个用 ; 分隔"),
    delete: Optional[str] = typer.Option(None, "--del", help="要删除的词，多个用 ; 分隔"),
    switch: Optional[str] = typer.Option(None, "--switch", help="orders_main/order_space"),
):
    add_list = _split_words(add)
    del_list = _split_words(delete)

    if switch:
        try:
            data = ops.switch(run_id, switch, SERVER_URL)
            console.print(f"[green]已切换到 {switch} 排名[/green]")
            snapshot.save(run_id, f"switch: {switch}")
            _report_record(run_id, "QUERY", f"切换排名 {switch}", data)
            _display(run_id, data, "markdown")
        except Exception as e:
            console.print(f"[red]切换失败：{e}[/red]")
            raise typer.Exit(1)
        return

    if not op:
        console.print("[red]需要 --op 参数（delete/merge/expand）或 --switch 参数[/red]")
        raise typer.Exit(1)

    if op == "delete":
        if len(del_list) != 1:
            console.print("[red]delete 操作需要恰好一个 --del 参数[/red]")
            raise typer.Exit(1)
        data = ops.delete(run_id, del_list[0])
        console.print(f"[green]已删除：{del_list[0]}[/green]")
        snapshot.save(run_id, f"delete: {del_list[0]}")
        _report_record(run_id, "EXCLUDE", f"删除 {del_list[0]}", data)
        _display(run_id, data, "markdown")

    elif op == "merge":
        if not del_list or len(add_list) != 1:
            console.print("[red]merge 操作需要 --del 词1;词2 --add 新词[/red]")
            raise typer.Exit(1)
        data = ops.merge(run_id, del_list, add_list[0])
        console.print(f"[green]已合并：{del_list} → {add_list[0]}[/green]")
        snapshot.save(run_id, f"merge: {';'.join(del_list)} → {add_list[0]}")
        _report_record(run_id, "MERGE", f"合并 {del_list} → {add_list[0]}", data)
        _display(run_id, data, "markdown")

    elif op == "expand":
        if len(del_list) != 1:
            console.print("[red]expand 操作需要恰好一个 --del 参数[/red]")
            raise typer.Exit(1)
        parent_key = del_list[0]
        ranking_data = store.load(run_id)
        dt = ranking_data.get("dt") or (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
        try:
            resp = httpx.post(f"{SERVER_URL}/api/insight/opportunity/v1/product/query", headers=auth.get_headers(), json={
                "dt": dt,
                "products": [parent_key],
                "level": 1,
                "cityName": ranking_data.get("city", ""),
                "categoryName": ranking_data["category"],
                "dateType": _DT_WINDOW_TO_DATE_TYPE.get(ranking_data.get("dt_window", "1d"), 30),
            }, timeout=30)
            resp.raise_for_status()
        except Exception as e:
            console.print(f"[red]服务端请求失败：{e}[/red]")
            raise typer.Exit(1)

        result = resp.json()
        if str(result.get("code", "0")) != "0":
            console.print(f"[red]服务端错误：{result.get('message')}[/red]")
            raise typer.Exit(1)

        product_metrics = result["data"]["productMetrics"]
        all_items = product_metrics.get(parent_key, [])
        raw_sub_items = all_items  # level=1 返回的全是子词，无父词聚合行

        # 将 subProductName 映射为 productName（子词的展示名）
        sub_items = []
        for x in raw_sub_items:
            item = dict(x)
            if item.get("subProductName") and item["subProductName"] != "-":
                item["productName"] = item["subProductName"]
            sub_items.append(item)

        if add_list:
            add_set = set(add_list)
            sub_items = [x for x in sub_items if x["productName"] in add_set]
            found = {x["productName"] for x in sub_items}
            missing = add_set - found
            if missing:
                console.print(f"[yellow]警告：以下子词在数据库中不存在，已跳过：{missing}[/yellow]")

        if not sub_items:
            console.print("[red]无可用子词数据，expand 操作取消[/red]")
            raise typer.Exit(1)

        data = ops.expand(run_id, parent_key, sub_items)
        console.print(f"[green]已下钻：{parent_key} → {[x['productName'] for x in sub_items]}[/green]")
        snapshot.save(run_id, f"expand: {parent_key}")
        _report_record(run_id, "EXPAND", f"下钻 {parent_key}", data)
        _display(run_id, data, "markdown")

    else:
        console.print(f"[red]未知 op：{op}，可选 delete/merge/expand[/red]")
        raise typer.Exit(1)
