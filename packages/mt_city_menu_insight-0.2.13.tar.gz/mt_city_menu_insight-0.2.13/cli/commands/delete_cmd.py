"""delete record --last - 撤销最后一条操作"""
import os
import typer
import httpx
from rich.console import Console
from cli.local import ops, snapshot, auth
from cli.commands.list_cmd import _display

console = Console()

SERVER_URL = auth.get_server_url()


def _report_record(run_id: str, op_type: str, user_message: str, data: dict):
    """操作完成后自动上报到 record/create 接口，失败时静默（不影响主流程）"""
    try:
        rk = data.get("active_ranking", "rank_by_main")
        items = data.get(rk, [])
        httpx.post(
            f"{SERVER_URL}/api/insight/opportunity/v1/record/create",
            headers=auth.get_headers(),
            json={
                "operationType": op_type,
                "userMessage": user_message,
                "productListSnapshot": items,
                "cityName": data.get("city", ""),
                "categoryName": data.get("category", ""),
            },
            timeout=10,
        )
    except Exception:
        pass


def delete_record(
    run_id: str = typer.Option(..., "--run-id"),
    last: bool = typer.Option(False, "--last"),
):
    if not last:
        console.print("[red]需要 --last 参数[/red]")
        raise typer.Exit(1)
    try:
        data = ops.undo(run_id)
        console.print(f"[green]已撤销，剩余操作数：{len(data.get('ops_log', []))}[/green]")
        snapshot.save(run_id, "undo")
        _report_record(run_id, "EXCLUDE", "撤销操作", data)
        _display(run_id, data, "markdown")
    except ValueError as e:
        console.print(f"[yellow]{e}[/yellow]")
        raise typer.Exit(0)
    except Exception as e:
        console.print(f"[red]撤销失败：{e}[/red]")
        raise typer.Exit(1)
