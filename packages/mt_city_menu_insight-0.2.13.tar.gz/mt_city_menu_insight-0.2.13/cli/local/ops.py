"""cli/local/ops.py - 本地榜单操作执行（delete/merge/expand/undo）"""
from datetime import datetime, timezone, timedelta
from typing import List, Optional
from cli.local import store

_TZ = timezone(timedelta(hours=8))

ALL_RANKING_KEYS = ["rank_by_main", "rank_by_space"]
SORT_METRIC = {"rank_by_main": "wmSales", "rank_by_space": "orderSpace"}

_DT_WINDOW_TO_DATE_TYPE = {"1d": 1, "3d": 3, "7d": 7, "14d": 14, "30d": 30}


def _dt_window_to_date_type(dt_window: str) -> int:
    return _DT_WINDOW_TO_DATE_TYPE.get(dt_window, 30)


def _rerank(items: List[dict]) -> List[dict]:
    for i, item in enumerate(items, 1):
        item["rank"] = i
    return items


def _pool_key(rk: str) -> str:
    return rk + "_pool"


def _fill_from_pool(items: List[dict], pool: List[dict], top_n: int) -> tuple:
    while len(items) < top_n and pool:
        items.append(dict(pool.pop(0)))
    return _rerank(items), list(pool)


def _insert_by_metric(items: List[dict], new_item: dict, rk: str) -> List[dict]:
    metric = SORT_METRIC.get(rk, "wmSales")
    val = new_item.get(metric, 0)
    insert_idx = len(items)
    for i, item in enumerate(items):
        if item.get(metric, 0) < val:
            insert_idx = i
            break
    items.insert(insert_idx, new_item)
    return _rerank(items)


def _now_iso() -> str:
    return datetime.now(_TZ).isoformat()


def _apply_op(rk: str, items: List[dict], pool: List[dict], op: dict, top_n: int) -> tuple:
    """对单个 ranking 重放一条 ops_log 记录，返回 (items, pool)"""
    op_type = op["op"]
    params = op.get("params", {})

    if op_type == "delete":
        key = params["delete_key"]
        items = [x for x in items if x["productName"] != key]
        items = _rerank(items)
        items, pool = _fill_from_pool(items, pool, top_n)

    elif op_type == "merge":
        delete_keys = set(params["delete_keys"])
        insert_key = params["insert_key"]
        # 找插入位置（被删词中最高排名）
        ranks = [x["rank"] for x in items if x["productName"] in delete_keys]
        insert_rank = min(ranks) if ranks else len(items) + 1
        # 从 items 中取被删词指标（用于构建合并词）
        del_items = [x for x in items if x["productName"] in delete_keys]
        items = [x for x in items if x["productName"] not in delete_keys]
        if del_items:
            new_item = _calc_merge_item(insert_key, del_items)
            insert_idx = min(insert_rank - 1, len(items))
            items.insert(insert_idx, new_item)
        items = _rerank(items)
        items, pool = _fill_from_pool(items, pool, top_n)

    elif op_type == "expand":
        delete_key = params["delete_key"]
        sub_items = params.get("_sub_items", [])  # replay 时从 params 里读
        items = [x for x in items if x["productName"] != delete_key]
        for si in sub_items:
            items = _insert_by_metric(items, dict(si), rk)
        while len(items) > top_n:
            evicted = items.pop()
            pool.insert(0, evicted)
        items = _rerank(items)
        items, pool = _fill_from_pool(items, pool, top_n)

    return items, pool


def _calc_merge_item(insert_key: str, del_items: List[dict]) -> dict:
    wm_sales = sum(x["wmSales"] for x in del_items)
    phf_sales = sum(x["phfSales"] for x in del_items)
    total_orders = wm_sales + phf_sales
    if total_orders > 0:
        price = sum(x.get("wmAvgPrice", 0) * (x["wmSales"] + x["phfSales"]) for x in del_items) / total_orders
    else:
        price = del_items[0].get("wmAvgPrice", 0.0) if del_items else 0.0

    # 占比加总（小数格式）
    wm_ratio = round(sum(x.get("wmOrderRatio", 0) for x in del_items), 6)
    phf_ratio = round(sum(x.get("phfOrderRatio", 0) for x in del_items), 6)
    order_space = round(max(0.0, wm_ratio - phf_ratio), 6)

    # standFoodName 取第一个被删词的非空值
    stand_food_name = ""
    for x in del_items:
        sfn = x.get("standFoodName", "")
        if sfn:
            stand_food_name = sfn
            break

    # isOnlineMustItem：三态值 True / False / "-"（不知道）
    # 所有被合并词均为 True → True；任一为 False → False；其余（含 "-"）→ "-"
    must_values = [x.get("isOnlineMustItem") for x in del_items]
    if all(v is True for v in must_values):
        is_online_must = True
    elif any(v is False for v in must_values):
        is_online_must = False
    else:
        is_online_must = "-"

    # isNewDiscovery：wm 有销量但 phf 销量为零
    isNewDiscovery = wm_sales > 0 and phf_sales == 0

    return {
        "productName": insert_key,
        "wmSales": wm_sales,
        "phfSales": phf_sales,
        "tbsgSales": 0,
        "wmAvgPrice": round(price, 1),
        "phfAvgPrice": 0.0,
        "tbsgAvgPrice": 0.0,
        "wmOrderRatio": wm_ratio,
        "phfOrderRatio": phf_ratio,
        "tbsgOrderRatio": 0.0,
        "orderSpace": order_space,
        "standFoodName": stand_food_name,
        "isOnlineMustItem": is_online_must,
        "isNewDiscovery": isNewDiscovery,
    }


def replay_ops(rk: str, items: List[dict], pool: List[dict], ops_log: list, top_n: int) -> tuple:
    items = [dict(x) for x in items]
    pool = [dict(x) for x in pool]
    for op in ops_log:
        items, pool = _apply_op(rk, items, pool, op, top_n)
    items = _rerank(items)
    return items, pool


def delete(run_id: str, key: str, user_message: str = "") -> dict:
    data = store.load(run_id)
    rk = data["active_ranking"]
    top_n = data.get("top_n", 50)
    items = data.get(rk, [])
    pool = data.get(_pool_key(rk), [])

    items = [x for x in items if x["productName"] != key]
    items = _rerank(items)
    items, pool = _fill_from_pool(items, pool, top_n)

    seq = len(data.get("ops_log", [])) + 1
    log_entry = {
        "seq": seq,
        "op": "delete",
        "active_ranking": rk,
        "params": {"delete_key": key},
        "user_message": user_message,
        "timestamp": _now_iso(),
    }
    data[rk] = items
    data[_pool_key(rk)] = pool
    data.setdefault("ops_log", []).append(log_entry)
    store.save(run_id, data)
    return data


def merge(run_id: str, delete_keys: List[str], insert_key: str, user_message: str = "") -> dict:
    data = store.load(run_id)
    rk = data["active_ranking"]
    top_n = data.get("top_n", 50)
    items = data.get(rk, [])
    pool = data.get(_pool_key(rk), [])

    del_items = [x for x in items if x["productName"] in delete_keys]
    ranks = [x["rank"] for x in del_items]
    insert_rank = min(ranks) if ranks else len(items) + 1

    new_item = _calc_merge_item(insert_key, del_items)
    items = [x for x in items if x["productName"] not in delete_keys]
    insert_idx = min(insert_rank - 1, len(items))
    items.insert(insert_idx, new_item)
    items = _rerank(items)
    items, pool = _fill_from_pool(items, pool, top_n)

    seq = len(data.get("ops_log", [])) + 1
    log_entry = {
        "seq": seq,
        "op": "merge",
        "active_ranking": rk,
        "params": {"delete_keys": delete_keys, "insert_key": insert_key},
        "user_message": user_message,
        "timestamp": _now_iso(),
    }
    data[rk] = items
    data[_pool_key(rk)] = pool
    data.setdefault("ops_log", []).append(log_entry)
    store.save(run_id, data)
    return data


def expand(run_id: str, delete_key: str, sub_items: List[dict], user_message: str = "") -> dict:
    data = store.load(run_id)
    rk = data["active_ranking"]
    top_n = data.get("top_n", 50)
    items = data.get(rk, [])
    pool = data.get(_pool_key(rk), [])

    items = [x for x in items if x["productName"] != delete_key]
    for si in sub_items:
        items = _insert_by_metric(items, dict(si), rk)
    while len(items) > top_n:
        evicted = items.pop()
        pool.insert(0, evicted)
    items = _rerank(items)
    items, pool = _fill_from_pool(items, pool, top_n)

    seq = len(data.get("ops_log", [])) + 1
    log_entry = {
        "seq": seq,
        "op": "expand",
        "active_ranking": rk,
        "params": {
            "delete_key": delete_key,
            "insert_keys": [x["productName"] for x in sub_items],
            "_sub_items": sub_items,  # 存储完整指标供 replay 使用
        },
        "user_message": user_message,
        "timestamp": _now_iso(),
    }
    data[rk] = items
    data[_pool_key(rk)] = pool
    data.setdefault("ops_log", []).append(log_entry)
    store.save(run_id, data)
    return data


def undo(run_id: str) -> dict:
    data = store.load(run_id)
    ops_log = data.get("ops_log", [])
    if not ops_log:
        raise ValueError("没有可撤销的操作")

    ops_log = ops_log[:-1]
    orig = store.load_original(run_id)
    top_n = data.get("top_n", 50)

    for rk in ALL_RANKING_KEYS:
        if not data.get(rk):
            continue
        original_items = orig.get(rk, [])
        if not original_items:
            continue
        original_pool = orig.get(_pool_key(rk), [])
        items, pool = replay_ops(rk, original_items, original_pool, ops_log, top_n)
        data[rk] = items
        data[_pool_key(rk)] = pool

    data["ops_log"] = ops_log
    store.save(run_id, data)
    return data


def switch(run_id: str, to_sort_by: str, server_url: Optional[str] = None) -> dict:
    """切换排名维度；目标不存在时调服务端生成后重放 ops_log"""
    import httpx
    from cli.local.auth import get_headers, get_server_url
    if server_url is None:
        server_url = get_server_url()
    data = store.load(run_id)
    rk_map = {"orders_main": "rank_by_main", "order_space": "rank_by_space"}
    to_rk = rk_map.get(to_sort_by)
    if not to_rk:
        raise ValueError(f"未知排名维度：{to_sort_by}")

    if not data.get(to_rk):
        # 调服务端生成
        dt = data.get("dt") or (datetime.now(_TZ) - timedelta(days=1)).strftime("%Y%m%d")
        price_min = data.get("price_min")
        price_max = data.get("price_max")
        payload = {
            "dt": dt,
            "cityName": data["city"],
            "categoryName": data["category"],
            "topN": data.get("top_n", 50),
            "sortType": "ORDER_SPACE_DESC" if to_sort_by == "order_space" else "SALES_DESC",
            "minPrice": int(price_min) if price_min is not None else 0,
            "dateType": _dt_window_to_date_type(data.get("dt_window", "1d")),
        }
        if price_max is not None:
            payload["maxPrice"] = int(price_max)
        resp = httpx.post(f"{server_url}/api/insight/opportunity/v1/list/query", headers=get_headers(), json=payload, timeout=30)
        resp.raise_for_status()
        result = resp.json()
        data_obj = result.get("data", {})
        original_items = data_obj.get("mainList", [])
        original_pool = data_obj.get("bufferList", [])
        # 按目标维度的排序指标重新排序（服务端返回顺序不可靠）
        sort_metric = SORT_METRIC.get(to_rk, "wmSales")
        original_items.sort(key=lambda x: x.get(sort_metric, 0), reverse=True)
        original_pool.sort(key=lambda x: x.get(sort_metric, 0), reverse=True)
        for i, item in enumerate(original_items, 1):
            item["rank"] = i
            item["isNewDiscovery"] = item.get("wmSales", 0) > 0 and item.get("phfSales", 0) == 0
        for item in original_pool:
            item["isNewDiscovery"] = item.get("wmSales", 0) > 0 and item.get("phfSales", 0) == 0

        # 写入 original
        orig = store.load_original(run_id)
        orig[to_rk] = original_items
        orig[_pool_key(to_rk)] = original_pool
        store._run_dir(run_id).mkdir(parents=True, exist_ok=True)
        import json
        (store._run_dir(run_id) / "ranking_original.json").write_text(
            json.dumps(orig, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        # 重放 ops_log
        ops_log = data.get("ops_log", [])
        top_n = data.get("top_n", 50)
        items, pool = replay_ops(to_rk, original_items, original_pool, ops_log, top_n)
        data[to_rk] = items
        data[_pool_key(to_rk)] = pool

    data["active_ranking"] = to_rk
    store.save(run_id, data)
    return data
