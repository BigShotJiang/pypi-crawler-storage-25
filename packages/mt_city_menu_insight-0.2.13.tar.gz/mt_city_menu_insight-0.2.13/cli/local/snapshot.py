"""cli/local/snapshot.py - 快照管理"""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from cli.local import store

_TZ = timezone(timedelta(hours=8))


def _snap_dir(run_id: str) -> Path:
    return store._run_dir(run_id) / "snapshots"


def _meta_path(run_id: str) -> Path:
    return _snap_dir(run_id) / "meta.json"


def save(run_id: str, desc: str = "") -> str:
    data = store.load(run_id)
    snap_dir = _snap_dir(run_id)
    snap_dir.mkdir(parents=True, exist_ok=True)
    meta_path = _meta_path(run_id)
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {"versions": []}

    version = len(meta["versions"]) + 1
    version_str = f"v{version:03d}"
    snap_file = snap_dir / f"{version_str}.json"
    snap_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    meta["versions"].append({
        "version": version_str,
        "desc": desc,
        "saved_at": datetime.now(_TZ).isoformat(),
    })
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return version_str


def list_snapshots(run_id: str) -> list:
    meta_path = _meta_path(run_id)
    if not meta_path.exists():
        return []
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    return meta.get("versions", [])


def restore(run_id: str, version: str):
    snap_file = _snap_dir(run_id) / f"{version}.json"
    if not snap_file.exists():
        raise FileNotFoundError(f"快照不存在：{snap_file}")
    data = json.loads(snap_file.read_text(encoding="utf-8"))
    store.save(run_id, data)
