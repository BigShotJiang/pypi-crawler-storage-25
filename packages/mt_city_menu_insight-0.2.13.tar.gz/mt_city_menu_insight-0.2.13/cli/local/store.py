"""cli/local/store.py - 本地 ranking.json 读写"""
import json
from pathlib import Path
from typing import Optional

_OUTPUTS_DIR = Path.home() / ".local" / "share" / "tsp-ops" / "outputs"


def _run_dir(run_id: str) -> Path:
    return _OUTPUTS_DIR / run_id


def _ranking_path(run_id: str) -> Path:
    return _run_dir(run_id) / "ranking.json"


def _original_path(run_id: str) -> Path:
    return _run_dir(run_id) / "ranking_original.json"


def load(run_id: str) -> dict:
    path = _ranking_path(run_id)
    if not path.exists():
        raise FileNotFoundError(f"ranking.json 不存在：{path}")
    return json.loads(path.read_text(encoding="utf-8"))


def save(run_id: str, data: dict):
    d = _run_dir(run_id)
    d.mkdir(parents=True, exist_ok=True)
    _ranking_path(run_id).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def save_original(run_id: str, data: dict):
    """只写一次；若已存在则跳过"""
    path = _original_path(run_id)
    if path.exists():
        return
    _run_dir(run_id).mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_original(run_id: str) -> dict:
    path = _original_path(run_id)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def list_runs() -> list:
    if not _OUTPUTS_DIR.exists():
        return []
    runs = []
    for d in _OUTPUTS_DIR.iterdir():
        if not d.is_dir():
            continue
        p = d / "ranking.json"
        if not p.exists():
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            runs.append({
                "run_id": d.name,
                "city": data.get("city", ""),
                "category": data.get("category", ""),
                "dt": data.get("dt", ""),
                "dt_window": data.get("dt_window", ""),
                "top_n": data.get("top_n", 50),
                "sort_by": data.get("sort_by", ""),
                "price_min": data.get("price_min"),
                "price_max": data.get("price_max"),
                "generated_at": data.get("generated_at", ""),
                "ops_count": len(data.get("ops_log", [])),
            })
        except Exception:
            pass
    runs.sort(key=lambda x: x.get("generated_at", ""), reverse=True)
    return runs


def find_local_cache(city: str, category: str, top_n: int, price_min, price_max, sort_by: str, dt_window: str, dt: str) -> Optional[dict]:
    """按查询参数精确匹配本地缓存，返回最新匹配的 run dict 或 None"""
    for run in list_runs():
        if (run["city"] == city
                and run["category"] == category
                and run["top_n"] == top_n
                and run["price_min"] == price_min
                and run["price_max"] == price_max
                and run["sort_by"] == sort_by
                and run["dt_window"] == dt_window
                and run.get("dt") == dt):
            return run
    return None
