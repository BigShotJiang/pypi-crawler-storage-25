# 城市菜单洞察 API v2 Spec

> api-v2.1 版本。对接线上 OpportunityListController，提供机会清单查询、单菜品指标查询、清单导出和操作记录上报等功能。

---

## 一、整体架构

```
用户 / Skill
  │
  ▼
CLI（uv run tsp-ops-menu）
  ├─ 查询类 ──────────────────► 线上服务端（Doris）
  │   ├─ list ranking              /api/insight/opportunity/v1/list/query
  │   └─ get product               /api/insight/opportunity/v1/product/query
  │
  ├─ 本地操作（无网络）
  │   ├─ update ranking --op       上聚 / 下钻 / 删除
  │   ├─ update ranking --switch   切换排名维度（目标不存在时内部调 list/query）
  │   └─ delete record --last      撤销
  │
  └─ 上传类 ──────────────────► 线上服务端
      ├─ export ranking            传 productList JSON → 服务端生成 Excel → 返回 S3 链接
      └─ （自动）record/create      每次操作完成后静默上报
```

### 职责划分

| 职责 | 执行方 | 说明 |
|------|--------|------|
| 查询机会清单 | 服务端 | 缓存由后端判断（source: CACHED/NEW_QUERY） |
| 查询单菜品指标 | 服务端 | 支持 level=0/1 |
| run_id 生成与管理 | CLI | 格式 `{city}_{category}_{yyyyMMddHHmmss}` |
| 本地榜单文件读写 | CLI | `ranking.json`、`ranking_original.json` |
| 上聚 / 下钻 / 删除 / 撤销 / 切换排名 | CLI | 全部本地文件操作，维护 `ops_log` |
| Excel 生成 | 服务端 | CLI 传 productList JSON，服务端生成并返回 S3 下载链接 |
| 操作记录上报 | CLI → 服务端 | 每次操作完成后自动静默上报 |

---

## 二、CLI 命令设计

命令名：`tsp-ops-menu`，通过 `uv run tsp-ops-menu` 执行，遵循 `<cli> <动词> <资源>` 结构。

### 2.1 命令总览

| 命令 | 说明 | 调用服务端 |
|------|------|-----------|
| `list ranking` | 查询榜单（含两层缓存逻辑） | 是（含本地缓存检查） |
| `list runs` | 展示所有本地历史榜单 | 否 |
| `get product` | 查询单个本质词指标（含子词） | 是 |
| `update ranking --op` | 上聚 / 下钻 / 删除 | 否（下钻时内部调 product/query） |
| `update ranking --switch` | 切换排名维度 | 否（目标排名不存在时内部调 list/query） |
| `delete record --last` | 撤销最后一条操作 | 否 |
| `export ranking` | 生成 Excel 并返回 S3 链接（含服务端缓存检查） | 是 |

---

### 2.2 `list ranking` — 查询榜单

```bash
uv run tsp-ops-menu list ranking \
  --city 成都 \
  --category 饭类 \
  --top-n 50 \
  --dt-window 30d \
  --dt 20260406 \
  [--price-min 0] \
  [--price-max 30] \
  [--min-sales 0] \
  [--sort orders_main|order_space] \
  [--no-cache]
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `--city` | string | 是 | 城市名称（如 北京、成都） |
| `--category` | string | 是 | 拼好饭一级品类（西快小吃/饮品甜点/粉面粥饺/饭类） |
| `--top-n` | int | 否 | 榜单条目数，默认 50 |
| `--dt-window` | string | 否 | 时间窗口，默认 `1d`，可选：`1d/3d/7d/14d/30d` |
| `--dt` | string | 否 | 数据日期（yyyyMMdd），默认 **T-1（昨天）**（今天数据当天不可用） |
| `--price-min` | float | 否 | 价格带下限（含），None→传 0 |
| `--price-max` | float | 否 | 价格带上限（含），**None→不传该字段**（传 null 后端返回空数据） |
| `--min-sales` | int | 否 | 最低销量过滤，默认 0 |
| `--sort` | string | 否 | 排序方式，默认 `orders_main`，可选 `order_space` |
| `--run-id` | string | 否 | 直接展示已有本地榜单，不调服务端 |
| `--no-cache` | flag | 否 | 跳过本地缓存检查，强制保存新查询结果 |

**两层缓存逻辑：**

```
调用服务端 POST /list/query
  │
  ├─ source == "CACHED"（服务端缓存命中）
  │    → 输出黄色提示"命中服务端缓存（dt=..., 操作人：...）"
  │    → 终端模式：询问是否使用（服务端缓存无法强制绕过，始终使用）
  │    → Skill 模式：直接使用缓存数据
  │    → 保存为新 run_id，展示
  │
  └─ source == "NEW_QUERY"
       → 若未传 --no-cache：检查本地缓存（city+category+top_n+price_min+price_max+sort_by+dt_window+dt 全匹配）
            ├─ 命中本地缓存
            │    → 输出青色提示"命中本地缓存（run_id: ..., 生成时间：...）"
            │    → 终端模式：询问是否使用（y→展示已有，n→保存新结果）
            │    → Skill 模式：**自动使用本地缓存**，直接展示
            └─ 未命中 / 传了 --no-cache → 保存新 run_id，展示
```

**ranking.json 新增 `dt` 字段**（数据日期，用于本地缓存匹配）。

---

### 2.3 `list runs` — 查看历史榜单

```bash
uv run tsp-ops-menu list runs
```

列出所有本地历史榜单，输出表格：run_id | 城市 | 品类 | 数据日期 | 时间窗口 | Top N | 排名方式 | 价格带 | 生成时间 | 操作数。按生成时间降序排列。

---

### 2.4 `get product` — 查询本质词指标

```bash
uv run tsp-ops-menu get product \
  --query "(奶茶,0);(咖啡,1)" \
  --city 成都 \
  --category 饮品甜点 \
  [--dt-window 30d]
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `--query` | string | 是 | 查询列表，`;` 分隔，每项格式 `(词,level)`，`level=0` 聚合指标，`level=1` 含子词 |
| `--city` | string | 是 | 城市名称 |
| `--category` | string | 是 | 品类名称 |
| `--dt-window` | string | 否 | 时间窗口，默认 `1d` |

---

### 2.5 `update ranking` — 修改本地榜单

```bash
# 删除
uv run tsp-ops-menu update ranking --run-id {run_id} --op delete --del 豆浆

# 合并
uv run tsp-ops-menu update ranking --run-id {run_id} --op merge --del "美式咖啡;拿铁咖啡" --add 咖啡系列

# 下钻（展开所有子词）
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶

# 切换排名维度
uv run tsp-ops-menu update ranking --run-id {run_id} --switch order_space
```

每次操作完成后自动静默上报 `record/create`。

---

### 2.6 `delete record --last` — 撤销

```bash
uv run tsp-ops-menu delete record --last --run-id {run_id}
```

从原始榜单重放剩余 ops_log，不调服务端。完成后自动上报。

---

### 2.7 `export ranking` — 导出 Excel

```bash
uv run tsp-ops-menu export ranking --run-id {run_id}
```

**导出流程**：

```
1. 加载本地 ranking.json
2. 静默调用 POST /list/query（相同参数）检查服务端缓存状态
   ├─ source == "CACHED"
   │    → 输出提示"服务端已有该清单的缓存（dt=..., 操作人：...），是否覆盖？"
   │    → 终端模式：y→继续导出，n→取消 exit(0)
   │    → Skill 模式：输出提示后自动继续导出（非阻塞）
   └─ source == "NEW_QUERY" 或请求失败（静默忽略）→ 直接导出
3. 传 productList JSON 给服务端，服务端生成 Excel，返回 S3 下载链接
4. 将 export_url 写回 ranking.json
```

---

## 三、服务端 API 接口

**基础信息：**
- **服务端地址**: `https://productop.waimai.st.sankuai.com`（测试环境，可通过 `TSP_OPS_SERVER_URL` 环境变量覆盖）
- **基础路径**: `/api/insight/opportunity/v1`
- **Content-Type**: `application/json`
- **认证**: `access-token` header，由 `@it/oa-skills-shared` 动态获取
- **响应格式**: `{code: "0", message: "success", data: {...}}`（注意 code 为**字符串**）

---

### 3.1 `POST /api/insight/opportunity/v1/list/query` — 查询机会清单

#### 请求体

```json
{
  "dt": "20260406",
  "cityName": "成都",
  "categoryName": "饭类",
  "minPrice": 0,
  "minSales": 0,
  "topN": 50,
  "dateType": 30,
  "sortType": "SALES_DESC"
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `dt` | string | 是 | - | 数据日期（yyyyMMdd） |
| `cityName` | string | 是 | - | 城市名称 |
| `categoryName` | string | 是 | - | 品类名称 |
| `minPrice` | integer | 否 | 0 | 价格区间下限（元） |
| `maxPrice` | integer | 否 | 不传 | 价格区间上限（元）；**不传和传 null 行为不同，None 时必须省略此字段** |
| `minSales` | integer | 否 | 0 | 最低销量过滤 |
| `topN` | integer | 否 | 50 | 返回 TOP N 条数据 |
| `dateType` | integer | 否 | 30 | 日期类型：1/3/7/14/30（天） |
| `sortType` | string | 否 | SALES_DESC | `SALES_DESC`（销量降序）、`ORDER_SPACE_DESC`（下单空间降序） |

#### 响应体

```json
{
  "code": "0",
  "message": "success",
  "data": {
    "source": "NEW_QUERY",
    "versionInfo": null,
    "mainList": [
      {
        "date": "20260405",
        "cityName": "成都",
        "categoryName": "饭类",
        "productName": "虎皮青椒",
        "subProductName": "-",
        "standFoodName": "其他卤味小吃",
        "isOnlineMustItem": false,
        "dateType": 30,
        "wmSales": 2,
        "phfSales": 1,
        "tbsgSales": 1,
        "wmAvgPrice": 16.0,
        "phfAvgPrice": 15.0,
        "tbsgAvgPrice": 15.0,
        "wmOrderRatio": 8.0,
        "phfOrderRatio": 4.0,
        "tbsgOrderRatio": 4.0,
        "orderSpace": 4.0
      }
    ],
    "bufferList": []
  }
}
```

**重要**：`wmOrderRatio`/`phfOrderRatio`/`tbsgOrderRatio`/`orderSpace` 均为**百分比值**（8.0 = 8%），显示时直接使用，不需要乘 100。

**data 字段说明：**
- `source` - `CACHED`（缓存命中）或 `NEW_QUERY`（新查询）
- `versionInfo` - 仅 source=CACHED 时返回，含 `dt`/`creatorMis` 等
- `mainList` - 主列表（TOP N 条）
- `bufferList` - 候选池（第 N+1 到 2N 条），source=CACHED 时可能为空

---

### 3.2 `POST /api/insight/opportunity/v1/product/query` — 查询单菜品指标

#### 请求体

```json
{
  "dt": "20260406",
  "products": ["奶茶", "咖啡"],
  "level": 1,
  "cityName": "成都",
  "categoryName": "饮品甜点",
  "dateType": 30
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `dt` | string | 是 | 数据日期（yyyyMMdd） |
| `products` | array[string] | 是 | 菜品名称列表 |
| `level` | integer | 否 | 0=聚合本质词粒度，1=本质词粒度（含子词） |
| `cityName` | string | 是 | 城市名称 |
| `categoryName` | string | 是 | 品类名称 |
| `dateType` | integer | 否 | 日期类型，默认 30 |

#### 响应体

```json
{
  "code": "0",
  "message": "success",
  "data": {
    "productMetrics": {
      "奶茶": [
        { "productName": "奶茶", "subProductName": "-", ... },
        { "productName": "奶茶", "subProductName": "珍珠奶茶", ... }
      ],
      "咖啡": []
    }
  }
}
```

**level=1 时**，每个 product 对应列表为 `[父词自身, 子词1, 子词2, ...]`；不存在的词对应空列表 `[]`。子词行 `subProductName` 为子词名，父词行 `subProductName` 为 `"-"`。

---

### 3.3 `POST /api/insight/opportunity/v1/export` — 导出清单

#### 请求体

```json
{
  "cityName": "成都",
  "categoryName": "饭类",
  "topN": 50,
  "dateType": 30,
  "sortType": "SALES_DESC",
  "productList": [ /* ProductListItem 数组 */ ]
}
```

#### 响应体

```json
{
  "code": "0",
  "message": "success",
  "data": {
    "downloadUrl": "https://mss.vip.sankuai.com/..."
  }
}
```

---

### 3.4 `POST /api/insight/opportunity/v1/record/create` — 上报操作记录

每次 update/delete/export 操作完成后由 CLI **自动静默调用**，失败不影响主流程。

#### 请求体

```json
{
  "operationType": "MERGE",
  "userMessage": "合并 ['干炒肉', '炒土豆'] → 炒菜类",
  "productListSnapshot": [ /* 操作后当前榜单 */ ],
  "cityName": "成都",
  "categoryName": "饭类"
}
```

| operationType | 触发时机 |
|--------------|---------|
| `QUERY` | 切换排名维度 |
| `EXCLUDE` | 删除词、撤销 |
| `MERGE` | 合并词 |
| `EXPAND` | 下钻展开 |

#### 响应体

```json
{
  "code": "0",
  "message": "success",
  "data": { "acknowledged": true }
}
```

---

## 四、ProductListItem 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `productName` | string | 聚合本质词（榜单展示单元） |
| `subProductName` | string | 子本质词名；list/query 固定 `"-"`，product/query level=1 子词行为实际子词名 |
| `date` | string | 数据日期（yyyyMMdd） |
| `cityName` | string | 城市名称 |
| `categoryName` | string | 品类名称 |
| `dateType` | int | 时间维度（1/3/7/14/30） |
| `wmSales` | int | 主站销量 |
| `phfSales` | int | 拼好饭销量 |
| `tbsgSales` | int | TBSG 销量 |
| `wmAvgPrice` | float | 主站均价（元，可为 null） |
| `phfAvgPrice` | float | 拼好饭均价（元，可为 null） |
| `tbsgAvgPrice` | float | TBSG 均价（元，可为 null） |
| `wmOrderRatio` | float | 主站下单率（**百分比**，8.0 = 8%） |
| `phfOrderRatio` | float | 拼好饭下单率（百分比） |
| `tbsgOrderRatio` | float | TBSG 下单率（百分比） |
| `orderSpace` | float | 订单空间（百分比，可为负） |
| `standFoodName` | string | 标准菜名 |
| `isOnlineMustItem` | bool/string | 是否线上必上菜（`true`/`false`/`"-"`=不知道）；合并词：全为 `true` → `true`，任一 `false` → `false`，其余 → `"-"` |
| `is_new_find` | bool | CLI 本地计算：`wmSales > 0 and phfSales == 0`（主站有销量但拼好饭销量为零） |
| `rank` | int | 排名（CLI 本地填充，服务端不返回） |

---

## 五、本地文件结构

```
~/.local/share/tsp-ops/
├── config.json                       # MIS ID 配置
└── outputs/
    └── {run_id}/
        ├── ranking.json              # 当前榜单（含 ops_log，每次操作后更新）
        ├── ranking_original.json     # 原始榜单（只写一次，用于 undo 重放）
        └── snapshots/
            ├── meta.json
            └── v001.json, v002.json, ...
```

**ranking.json 结构：**

```json
{
  "run_id": "成都_饭类_20260408103000",
  "city": "成都",
  "category": "饭类",
  "dt_window": "30d",
  "top_n": 50,
  "sort_by": "orders_main",
  "price_min": null,
  "price_max": null,
  "generated_at": "2026-04-08 10:30:00",
  "active_ranking": "rank_by_main",
  "rank_by_main": [],
  "rank_by_main_pool": [],
  "rank_by_space": [],
  "rank_by_space_pool": [],
  "ops_log": []
}
```

**ops_log 语义操作类型：**

| op | params 字段 |
|----|------------|
| `delete` | `delete_key: string` |
| `merge` | `delete_keys: string[]`，`insert_key: string` |
| `expand` | `delete_key: string`，`insert_keys: string[]`，`_sub_items: Item[]` |
