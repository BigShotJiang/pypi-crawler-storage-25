# Skill 自动化评测方案

> 目标：验证 SKILL.md 在 agent 产品中的实际表现，通过完整执行流程 + 模型评判，自动化评估 skill 的正确性和合理性。

---

## 一、整体架构

```
test_cases.json
      │
      ▼
runner.py（主循环）
      │
      ├─ 1. 构造对话上下文（SKILL.md + 用户输入）
      │
      ├─ 2. 调用被测模型 → 模型输出（含 CLI 命令）
      │
      ├─ 3. 解析输出，提取 CLI 命令
      │
      ├─ 4. subprocess 执行命令，收集 stdout / stderr / exit code
      │
      ├─ 5. 将执行结果追加到对话上下文，继续下一轮
      │
      └─ 6. 多轮结束后，收集完整轨迹写入 traces/
              │
              ▼
      evaluator.py
              │
              └─ 调用评判模型，输出评分 + 分析报告
```

---

## 二、目录结构

```
eval/
├── test_cases.json          # 测试用例定义
├── runner.py                # 主循环：驱动多轮对话 + 执行命令
├── evaluator.py             # 评判模型：读取 trace，输出报告
├── traces/                  # 每次运行的完整轨迹（自动生成）
│   └── {case_name}_{timestamp}.json
└── reports/                 # 评判报告（自动生成）
    └── {timestamp}.md
```

---

## 三、测试用例格式

每个用例描述一个完整的用户使用场景，包含多轮用户输入和期望的最终状态。

```json
[
  {
    "name": "查询并上聚咖啡类",
    "turns": [
      "查一下饮品甜点的热销榜单",
      "把美式咖啡和拿铁合并成咖啡系列",
      "导出清单"
    ],
    "expected": "用户完成了上聚操作，咖啡系列出现在榜单中，美式咖啡和拿铁被删除，最终成功导出"
  },
  {
    "name": "查询并下钻奶茶",
    "turns": [
      "查一下饮品甜点的热销榜单",
      "奶茶下面有哪些子词",
      "把奶茶展开到榜单里"
    ],
    "expected": "用户先查看了奶茶的子词列表，确认后执行了下钻，奶茶被替换为子词列表"
  },
  {
    "name": "缓存命中只读提示",
    "turns": [
      "查一下饮品甜点的热销榜单",
      "再查一次饮品甜点的热销榜单"
    ],
    "expected": "第二次查询命中缓存，模型提示用户数据为只读状态，不允许修改"
  },
  {
    "name": "删除后撤销",
    "turns": [
      "查一下饮品甜点的热销榜单",
      "删掉豆浆",
      "撤销刚才的操作"
    ],
    "expected": "删除豆浆后执行撤销，豆浆重新出现在榜单中，榜单恢复到删除前的状态"
  }
]
```

---

## 四、runner.py 设计

### 4.1 主流程

```
for each test_case:
    1. 重置环境（清空 outputs/ 目录）
    2. 初始化对话上下文：
       - system prompt = SKILL.md 内容
       - messages = []
    3. for each turn in test_case.turns:
       a. 追加用户消息到 messages
       b. 调用被测模型 API，得到模型回复
       c. 从模型回复中提取 CLI 命令列表
       d. 依次执行每条命令，收集执行结果
       e. 将执行结果格式化后追加到 messages（作为 tool result 或 user message）
       f. 记录本轮轨迹
    4. 将完整轨迹写入 traces/{case_name}_{timestamp}.json
```

### 4.2 命令提取

在 system prompt 中规定模型输出格式：CLI 命令必须放在 `<cmd>` 标签中，每条命令一个标签。

```
<cmd>tsp-ops-menu list ranking --category 饮品甜点</cmd>
<cmd>tsp-ops-menu update ranking --run-id xxx --op delete --del 豆浆</cmd>
```

用正则提取：`re.findall(r'<cmd>(.*?)</cmd>', response)`

### 4.3 执行结果反馈格式

将执行结果以固定格式追加到对话上下文，让模型知道命令执行情况：

```
[执行结果]
$ tsp-ops-menu list ranking --category 饮品甜点
exit_code: 0
stdout:
run_id: 福州_饮品甜点_20260401103000
...（命令输出）

$ tsp-ops-menu update ranking ...
exit_code: 0
stdout: ...
```

### 4.4 轨迹格式

```json
{
  "case_name": "查询并上聚咖啡类",
  "started_at": "2026-04-01T10:30:00+08:00",
  "turns": [
    {
      "turn": 1,
      "user_input": "查一下饮品甜点的热销榜单",
      "model_response": "...",
      "commands": [
        {
          "cmd": "tsp-ops-menu list ranking --category 饮品甜点",
          "exit_code": 0,
          "stdout": "...",
          "stderr": ""
        }
      ]
    },
    {
      "turn": 2,
      "user_input": "把美式咖啡和拿铁合并成咖啡系列",
      "model_response": "...",
      "commands": [...]
    }
  ],
  "final_ranking": {}
}
```

---

## 五、evaluator.py 设计

### 5.1 输入

- 完整轨迹文件（`traces/*.json`）
- 对应测试用例的 `expected` 描述

### 5.2 评判 prompt 结构

```
你是一个评判模型，负责评估 AI agent 完成任务的质量。

## 任务描述
{test_case.expected}

## 完整执行轨迹
{trace 的完整内容，包含每轮用户输入、模型回复、命令、执行结果}

## 评分维度
请从以下维度打分（每项 1-5 分）并给出理由：

1. **意图完成度**：最终结果是否符合用户意图
2. **步骤合理性**：中间步骤是否合理，有无多余或错误的操作
3. **关键节点正确性**：关键操作是否按正确顺序执行（如下钻前先查询子词）
4. **错误处理**：遇到错误时模型是否正确处理

## 输出格式
{
  "scores": {
    "intent_completion": 5,
    "step_rationality": 4,
    "key_steps_correctness": 5,
    "error_handling": 3
  },
  "total": 17,
  "summary": "...",
  "issues": ["...", "..."]
}
```

### 5.3 报告格式

所有用例评判完成后，生成 Markdown 报告：

```markdown
# Skill 评测报告 {timestamp}

## 总体结果

| 用例 | 意图完成 | 步骤合理 | 关键节点 | 错误处理 | 总分 |
|------|---------|---------|---------|---------|------|
| 查询并上聚咖啡类 | 5 | 4 | 5 | - | 14/15 |
| ...  | ...     | ...     | ...     | ...     | ...  |

## 各用例详情

### 查询并上聚咖啡类
...
```

---

## 六、环境隔离

每个测试用例执行前：
1. 清空 `outputs/` 目录（保留目录本身）
2. 确保服务端已启动（检查 `/health`，未启动则自动启动）
3. 记录用例开始时间

---

## 七、待确认

- [ ] 被测模型：Claude API（具体 model id 待定）
- [ ] 评判模型：同 Claude API 还是单独指定
- [ ] 测试用例数量和覆盖场景
- [ ] 是否需要并发执行多个用例（当前设计为串行）
