# 两层缓存 + list runs + 导出缓存检查

## Context

用户需要在 `list ranking` 命令中加入两层缓存判断逻辑，新增 `list runs` 命令查看历史榜单，并在 `export ranking` 时检查服务端缓存状态。目标是让用户能够复用已有查询结果（减少重复调用），同时对导出操作有更清晰的状态感知。

---

## 一、修改清单

### 1. `cli/local/store.py`
- `list_runs()` 新增返回 `dt` 字段（需要先在 ranking.json 中存储 `dt`）
- 新增 `find_local_cache(city, category, top_n, price_min, price_max, sort_by, dt_window, dt)` 函数：遍历本地 runs，按 8 个字段精确匹配，返回最新匹配的 run（或 None）

### 2. `cli/commands/list_cmd.py`
**核心流程改造**（仅在无 `--run-id` 模式下）：

```
调用服务端 POST /list/query
  │
  ├─ source == "CACHED"
  │    → 黄色提示服务端缓存信息（dt, creator）
  │    → 询问用户：直接使用 / 重新查询
  │         ├─ 直接使用 → 用服务端返回的 mainList 生成新 run_id，保存，展示
  │         └─ 重新查询 → 服务端缓存无法绕过，告知用户，仍使用缓存数据
  │
  └─ source == "NEW_QUERY"
       → 检查本地缓存（store.find_local_cache）
            ├─ 命中 → 青色提示本地缓存信息（run_id, generated_at）
            │         → --no-cache 未传时：询问用户：直接使用 / 保存新结果
            │              ├─ 直接使用 → 加载并展示该 run_id（不覆盖）
            │              └─ 保存新结果 → 正常保存新 run_id，展示
            │         → --no-cache 已传时：跳过提示，直接保存新结果
            └─ 未命中 → 正常保存新 run_id，展示
```

**Skill 端注意**：CLI 加 `--no-cache` 参数（布尔 flag）。Skill 默认不传（使用本地缓存，直接加载展示，不询问）；用户说"重新查询"时 Skill 加 `--no-cache`。

**新增**：ranking.json 中存储 `dt` 字段（数据日期，用于本地缓存匹配）

### 3. `cli/commands/list_cmd.py` — 新增 `list_runs_cmd`

```python
def list_runs_cmd():
    """展示所有本地榜单记录"""
    runs = store.list_runs()
    # 用 rich Table 展示：run_id | city | category | dt | dt_window | top_n | sort_by | price_min | price_max | generated_at | ops_count
```

### 4. `cli/main.py`
```python
from cli.commands.list_cmd import list_ranking, list_runs_cmd
list_app.command("runs")(list_runs_cmd)
```

### 5. `cli/commands/export_cmd.py`
**导出前检查服务端缓存**：

```
加载本地 ranking.json
  │
  调用 POST /list/query（相同参数：city, category, topN, sortType, dateType, minPrice, maxPrice）
    │
    ├─ source == "CACHED"
    │    → 提示："服务端已有该清单的缓存（dt={dt}, 操作人：{creator}），是否覆盖？"
    │         ├─ 是（覆盖）→ 继续导出
    │         └─ 否（取消）→ exit(0)
    │
    └─ source == "NEW_QUERY" 或请求失败（静默忽略）
         → 直接继续导出
```

**注意**：export 的缓存检查请求失败时静默忽略（不影响导出流程），因为这只是一个提示性检查。

**同时修复**：`round(item.get("wmOrderRatio", 0) * 100, 2)` → `round(item.get("wmOrderRatio", 0), 2)`（已是百分比）

---

## 二、ranking.json 新增 `dt` 字段

在 `list_cmd.py` 保存数据时，加入：

```python
data = {
    ...
    "dt": dt,  # 新增，数据日期 yyyyMMdd
    ...
}
```

`store.list_runs()` 新增读取 `dt` 字段并返回。

---

## 三、本地缓存匹配逻辑

`store.find_local_cache(city, category, top_n, price_min, price_max, sort_by, dt_window, dt)` 返回最新匹配的 run 或 None：

```python
def find_local_cache(city, category, top_n, price_min, price_max, sort_by, dt_window, dt):
    for run in list_runs():  # 已按 generated_at 降序
        if (run["city"] == city
            and run["category"] == category
            and run["top_n"] == top_n
            and run["price_min"] == price_min  # None vs None OK
            and run["price_max"] == price_max
            and run["sort_by"] == sort_by
            and run["dt_window"] == dt_window
            and run.get("dt") == dt):
            return run
    return None
```

---

## 四、用户交互提示文案

**服务端缓存命中**（CACHED）：
```
[yellow]命中服务端缓存（dt={dt}，操作人：{creator}）[/yellow]
是否直接使用？(y/n) [y]:
```
- y → 用服务端返回数据生成新 run_id 保存，展示
- n → 提示"服务端缓存无法强制绕过，将使用缓存数据"，仍保存展示

**本地缓存命中**（NEW_QUERY 且本地有匹配，且未传 --no-cache）：
```
[cyan]命中本地缓存（run_id: {run_id}，生成时间：{generated_at}）[/cyan]
是否直接使用？(y/n) [y]:
```
- y → 加载并展示该 run_id
- n → 保存新的查询结果（新 run_id），展示

**导出时服务端缓存命中**：
```
[yellow]服务端已有该清单的缓存（dt={dt}，操作人：{creator}），是否覆盖？(y/n) [n]:[/yellow]
```
- y → 继续导出
- n → 取消，exit(0)

---

## 五、Skill 端适配

Skill 端（Claude agent）执行 CLI 命令是非交互式的，无法响应 stdin 提示。处理方式：

- **本地缓存命中**：CLI 加 `--no-cache` 参数。Skill 默认不传（默认使用本地缓存，直接加载展示，不询问）；用户在对话中说"重新查询"时，Skill 加 `--no-cache`。
- **服务端缓存命中**：服务端 CACHED 时无法强制绕过，Skill 直接使用缓存数据，在输出中告知用户"当前命中服务端缓存（...）"。
- **导出缓存检查**：Skill 端导出时，若服务端有缓存，CLI 会输出提示并等待输入。需要 Skill 在 SKILL.md 中说明：导出前会检查服务端缓存，若有缓存会询问是否覆盖。

---

## 六、文件修改清单（精确）

| 文件 | 改动 |
|------|------|
| `cli/local/store.py` | `list_runs()` 加 `dt` 字段；新增 `find_local_cache()` |
| `cli/commands/list_cmd.py` | 两层缓存逻辑；`--no-cache` 参数；ranking.json 加 `dt`；新增 `list_runs_cmd` 函数 |
| `cli/commands/export_cmd.py` | 导出前服务端缓存检查；修复 `*100` bug |
| `cli/main.py` | 注册 `list runs` 命令 |
| `SKILL.md` | 更新缓存逻辑、`--no-cache` 用法、`list runs` 命令、导出缓存检查说明 |
| `docs/api_v2_spec.md` | 更新缓存逻辑说明、list runs 命令、export 缓存检查 |
| `docs/user_paths.md` | 更新所有相关用户路径 |

---

## 七、验证

```bash
# 1. 测试服务端缓存命中（需要后端有已标记清单）
uv run tsp-ops-menu list ranking --city 成都 --category 饭类 --dt 20260406

# 2. 测试本地缓存命中（先查一次，再查相同参数）
uv run tsp-ops-menu list ranking --city 成都 --category 饭类 --dt 20260406 --dt-window 30d
# 再次运行相同命令 → 应提示本地缓存命中

# 3. 测试 --no-cache 跳过本地缓存
uv run tsp-ops-menu list ranking --city 成都 --category 饭类 --dt 20260406 --dt-window 30d --no-cache

# 4. 测试 list runs
uv run tsp-ops-menu list runs

# 5. 测试导出缓存检查
uv run tsp-ops-menu export ranking --run-id {run_id}
```
