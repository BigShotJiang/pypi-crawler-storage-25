# PyPI 发布指南

## 前置配置

`~/.pypirc` 已配置 PyPI token，无需每次输入认证信息。

## 发布新版本

**第一步：修改版本号**

编辑 `pyproject.toml`：

```toml
version = "0.3.0"
```

**第二步：构建**

```bash
uv build
```

产出 `dist/mt_city_menu_insight-{version}.tar.gz` 和 `.whl`。

**第三步：发布**

```bash
uv publish
```
