# OpportunityListController API 详细文档

## 域名

https://productop.st.waimai.sankuai.com

## 概述

OpportunityListController 提供机会清单相关的功能，为 SKILL CLI 提供 HTTP 接口，支持机会清单查询、单菜品指标查询、清单导出和操作记录上报等功能。

## 基础信息

- **基础路径**: `/api/insight/opportunity/v1`
- **Content-Type**: `application/json`
- **认证方式**: Token 认证
- **响应格式**: 统一使用 `ApiResponse<T>` 格式

---

## 1. 查询机会清单

### 接口信息

- **接口名称**: 查询机会清单
- **请求路径**: `POST /api/insight/opportunity/v1/list/query`
- **请求方法**: POST
- **功能描述**: 按城市、品类、价格区间、最低销量查询"必上菜候选清单"，支持缓存命中逻辑

### 请求体

```json
{
  "cityName": "北京",
  "categoryName": "川菜",
  "minPrice": 0,
  "maxPrice": 30,
  "minSales": 10,
  "topN": 50,
  "dateType": 30,
  "sortType": "SALES_DESC"
}
```

### 请求参数说明

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| cityName | string | 是 | - | 城市名称 |
| categoryName | string | 是 | - | 品类名称 |
| minPrice | integer | 否 | 0 | 价格区间下限（单位：元） |
| maxPrice | integer | 否 | 30 | 价格区间上限（单位：元） |
| minSales | integer | 否 | 10 | 最低销量过滤条件 |
| topN | integer | 否 | 50 | 返回 TOP N 条数据 |
| dateType | integer | 否 | 30 | 日期类型，可选值：1/3/7/14/30 天 |
| sortType | string | 否 | SALES_DESC | 排序类型：SALES_DESC（销量降序）、ORDER_SPACE_DESC（下单空间降序） |

### 响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "source": "NEW_QUERY",
    "versionInfo": null,
    "mainList": [
      {
        "date": "20260401",
        "cityName": "北京",
        "categoryName": "川菜",
        "productName": "宫保鸡丁",
        "extractResultKey": "gongbaojiding_001",
        "standFoodName": "宫保鸡丁",
        "dateType": 30,
        "wmSales": 1000,
        "phfSales": 800,
        "tbsgSales": 500,
        "wmAvgPrice": 28.5,
        "phfAvgPrice": 26.0,
        "tbsgAvgPrice": 25.0,
        "wmOrderRatio": 0.15,
        "phfOrderRatio": 0.12,
        "tbsgOrderRatio": 0.08,
        "orderSpace": 0.03
      }
    ],
    "bufferList": []
  }
}
```

### 响应参数说明

**data 对象字段:**
- `source` (string) - 数据来源：`CACHED`（缓存命中）、`NEW_QUERY`（新查询）
- `versionInfo` (object, optional) - 版本信息，仅当 source 为 CACHED 时返回
  - `dt` (string) - 日期
  - `cityName` (string) - 城市名称
  - `categoryName` (string) - 品类名称
  - `topN` (integer) - TOP N
  - `creatorMis` (string) - 创建者 MIS
- `mainList` (array) - 主列表（TOP N 条）
- `bufferList` (array, optional) - 缓冲列表（第 N+1 到 2N 条），仅当 source 为 NEW_QUERY 时返回

**ProductListItem 字段:**
- `date` (string) - 日期
- `cityName` (string) - 城市名称
- `categoryName` (string) - 品类名称
- `productName` (string) - 菜品名称（聚合本质词）
- `extractResultKey` (string) - 本质词 Key
- `standFoodName` (string) - 标准菜名
- `dateType` (integer) - 日期类型
- `wmSales` (integer) - 主站销量
- `phfSales` (integer) - PHF 销量
- `tbsgSales` (integer) - TBSG 销量
- `wmAvgPrice` (double) - 主站均价
- `phfAvgPrice` (double) - PHF 均价
- `tbsgAvgPrice` (double) - TBSG 均价
- `wmOrderRatio` (double) - 主站下单率
- `phfOrderRatio` (double) - PHF 下单率
- `tbsgOrderRatio` (double) - TBSG 下单率
- `orderSpace` (double) - 下单空间（主站下单率 - PHF 下单率）

### 错误响应

```json
{
  "code": 500,
  "message": "QUERY_FAILED",
  "data": "查询失败：具体错误信息"
}
```

---

## 2. 查询单菜品指标

### 接口信息

- **接口名称**: 查询单菜品指标
- **请求路径**: `POST /api/insight/opportunity/v1/product/query`
- **请求方法**: POST
- **功能描述**: 查询指定菜品的多渠道指标，支持层级参数

### 请求体

```json
{
  "products": ["宫保鸡丁", "麻婆豆腐", "鱼香肉丝"],
  "level": 0,
  "cityName": "北京",
  "categoryName": "川菜",
  "dateType": 30
}
```

### 请求参数说明

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| products | array[string] | 是 | - | 菜品名称列表 |
| level | integer | 否 | 0 | 层级参数：0=聚合本质词粒度，1=本质词粒度 |
| cityName | string | 否 | - | 城市名称（可选过滤） |
| categoryName | string | 否 | - | 品类名称（可选过滤） |
| dateType | integer | 否 | 30 | 日期类型，可选值：1/3/7/14/30 天 |

### 响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "productMetrics": {
      "宫保鸡丁": [
        {
          "date": "20260401",
          "cityName": "北京",
          "categoryName": "川菜",
          "productName": "宫保鸡丁",
          "extractResultKey": "gongbaojiding_001",
          "standFoodName": "宫保鸡丁",
          "dateType": 30,
          "wmSales": 1000,
          "phfSales": 800,
          "tbsgSales": 500,
          "wmAvgPrice": 28.5,
          "phfAvgPrice": 26.0,
          "tbsgAvgPrice": 25.0,
          "wmOrderRatio": 0.15,
          "phfOrderRatio": 0.12,
          "tbsgOrderRatio": 0.08,
          "orderSpace": 0.03
        }
      ],
      "麻婆豆腐": [],
      "鱼香肉丝": []
    }
  }
}
```

### 响应参数说明

**data 对象字段:**
- `productMetrics` (object) - 菜品指标映射
  - key: 菜品名称（与请求中的 products 参数对应）
  - value: 该菜品的指标列表（若无数据则为空数组）

### 错误响应

```json
{
  "code": 500,
  "message": "QUERY_FAILED",
  "data": "查询失败：具体错误信息"
}
```

---

## 3. 导出清单

### 接口信息

- **接口名称**: 导出清单
- **请求路径**: `POST /api/insight/opportunity/v1/export`
- **请求方法**: POST
- **功能描述**: 将清单导出为 Excel 文件并上传至 S3，同时保存已标记清单版本

### 请求体

```json
{
  "cityName": "北京",
  "categoryName": "川菜",
  "topN": 50,
  "dateType": 30,
  "sortType": "SALES_DESC",
  "productList": []
}
```

### 请求参数说明

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| cityName | string | 是 | - | 城市名称 |
| categoryName | string | 是 | - | 品类名称 |
| topN | integer | 是 | - | TOP N 条数据 |
| dateType | integer | 否 | 30 | 日期类型 |
| sortType | string | 否 | - | 排序类型 |
| productList | array | 是 | - | 完整清单数据（ProductListItem 数组） |

### 响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "downloadUrl": "https://s3.example.com/xxx/opportunity_list_北京_川菜_50.xlsx?signature=xxx"
  }
}
```

### 响应参数说明

**data 对象字段:**
- `downloadUrl` (string) - S3 预签名下载链接（有效期 60 分钟）

### 错误响应

```json
{
  "code": 500,
  "message": "EXPORT_FAILED",
  "data": "导出失败：具体错误信息"
}
```

---

## 4. 上报用户操作记录

### 接口信息

- **接口名称**: 上报用户操作记录
- **请求路径**: `POST /api/insight/opportunity/v1/record/create`
- **请求方法**: POST
- **功能描述**: 记录用户的操作行为，用于追溯和审计

### 请求体

```json
{
  "operationType": "MERGE",
  "userMessage": "把宫保鸡丁和麻婆豆腐合并",
  "productListSnapshot": [],
  "cityName": "北京",
  "categoryName": "川菜"
}
```

### 请求参数说明

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| operationType | string | 是 | - | 操作类型：QUERY/MERGE/EXPAND/EXCLUDE/EXPORT |
| userMessage | string | 是 | - | 用户本轮对话发送的消息 |
| productListSnapshot | array | 是 | - | 操作后的最新清单快照 |
| cityName | string | 否 | - | 关联城市名称 |
| categoryName | string | 否 | - | 关联品类名称 |

### 响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "acknowledged": true
  }
}
```

### 响应参数说明

**data 对象字段:**
- `acknowledged` (boolean) - 是否记录成功

### 错误响应

```json
{
  "code": 500,
  "message": "RECORD_FAILED",
  "data": "记录创建失败：具体错误信息"
}
```

---

## 业务逻辑说明

### 缓存命中机制

1. 查询机会清单时，系统会先查找是否存在已标记的清单版本
2. 如果存在，直接返回缓存的清单数据（source=CACHED），不包含 bufferList
3. 如果不存在，查询 Doris 并返回新数据（source=NEW_QUERY），包含 mainList 和 bufferList

### 导出触发标记

1. 导出操作会触发保存已标记清单（只保存 TOP N 主列表）
2. 后续相同条件的查询会命中缓存，直接返回已标记的清单

### 操作类型说明

| 操作类型 | 说明 |
|----------|------|
| QUERY | 查询操作 |
| MERGE | 合并菜品操作 |
| EXPAND | 展开菜品操作 |
| EXCLUDE | 排除菜品操作 |
| EXPORT | 导出操作（系统自动创建） |

