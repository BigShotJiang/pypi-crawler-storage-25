# 用户路径与系统判断文档

> 基于 api-v2.1 分支当前实现，描述所有可能的用户操作路径、系统判断逻辑和 CLI 行为。

---

## 一、全局前置条件

### 1.1 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `TSP_OPS_SERVER_URL` | `https://productop.waimai.st.sankuai.com` | 服务端地址（可通过环境变量切换环境） |

### 1.2 认证流程

Token 由 CLI 在每次请求时通过 `@it/oa-skills-shared` 动态获取，自动缓存和刷新，无需手动管理。

配置文件 `~/.local/share/tsp-ops/config.json` 只存储 MIS ID：

```bash
uv run tsp-ops-menu config set-mis {mis_id}
```

首次使用时 CLI 会触发大象 App 授权，Token 自动缓存在 `~/.cache/openclaw-auth/auth-cache.json`，后续自动续期。

---

## 二、功能一：查询榜单（`list ranking`）

### 2.1 路径 A：直接展示已有本地榜单

**触发条件**：用户传 `--run-id` 参数

```bash
uv run tsp-ops-menu list ranking --run-id 成都_饮品甜点_20260407103000
```

**系统判断**：

1. 从 `outputs/{run_id}/ranking.json` 加载数据
2. 读取 `active_ranking` 字段（`rank_by_main` 或 `rank_by_space`）
3. 取对应列表展示

**可能的错误**：

| 错误 | 原因 | 表现 |
|------|------|------|
| `FileNotFoundError` | run_id 不存在 | 红色提示"找不到 run_id：xxx" + exit(1) |

---

### 2.2 路径 B：查询新榜单（调服务端，含两层缓存）

**触发条件**：传 `--city` 和 `--category`，不传 `--run-id`

```bash
uv run tsp-ops-menu list ranking \
  --city 成都 \
  --category 饮品甜点 \
  --top-n 50 \
  --dt-window 7d \
  --dt 20260406 \
  [--price-min 0] \
  [--price-max 30] \
  [--min-sales 10] \
  [--sort orders_main|order_space] \
  [--no-cache]
```

**参数转换**：

| CLI 参数 | 接口字段 | 转换规则 |
|----------|----------|----------|
| `--dt` | `dt` | yyyyMMdd 字符串，默认 **T-1（昨天）** |
| `--dt-window 1d` | `dateType: 1` | `{1d:1, 3d:3, 7d:7, 14d:14, 30d:30}` |
| `--sort orders_main` | `sortType: "SALES_DESC"` | orders_main→SALES_DESC，order_space→ORDER_SPACE_DESC |
| `--price-min` | `minPrice` | float→int，None→0 |
| `--price-max` | `maxPrice` | float→int，**None 时不传该字段**（传 null 后端返回空数据） |
| `--min-sales` | `minSales` | 直接传，默认 0 |
| `--no-cache` | — | 跳过本地缓存检查，强制保存新结果 |

**系统判断流程**：

```
调用 POST /api/insight/opportunity/v1/list/query
  │
  ├─ HTTP 错误 → 红色"服务端请求失败：{e}" + exit(1)
  │
  └─ 响应 code != 0 → 红色"服务端错误：{message}" + exit(1)
       │
       └─ code == 0
            │
            ├─ source == "CACHED"（层一：服务端缓存命中）
            │    → 黄色"命中服务端缓存（dt={dt}，操作人：{creator}）"
            │    → 终端模式：询问是否使用（服务端缓存无法强制绕过，始终使用）
            │    → Skill 模式：直接使用
            │    → 保存为新 run_id，展示
            │
            └─ source == "NEW_QUERY"
                 → 若未传 --no-cache：检查本地缓存
                 │   匹配条件：city + category + top_n + price_min + price_max + sort_by + dt_window + dt 全部相等
                 │
                 ├─ 命中本地缓存（层二）
                 │    → 青色"命中本地缓存（run_id: ..., 生成时间：...）"
                 │    → 终端模式：询问是否使用（y→展示已有，n→保存新结果）
                 │    → Skill 模式：自动使用本地缓存，直接展示
                 │
                 └─ 未命中 / 传了 --no-cache
                      → 写入本地文件（mainList 作为榜单，bufferList 作为候选池）
                      → 补充 rank 字段（服务端不返回，CLI 本地按序填充 1..N）
                      → 展示 mainList
```

**本地文件写入**（`~/.local/share/tsp-ops/outputs/{run_id}/ranking.json`）：

```json
{
  "run_id": "成都_饮品甜点_20260407103000",
  "city": "成都",
  "category": "饮品甜点",
  "dt": "20260406",
  "dt_window": "7d",
  "top_n": 50,
  "sort_by": "orders_main",
  "price_min": null,
  "price_max": null,
  "generated_at": "2026-04-07 10:30:00",
  "active_ranking": "rank_by_main",
  "rank_by_main": [ /* mainList，含 rank 字段 */ ],
  "rank_by_main_pool": [ /* bufferList */ ],
  "rank_by_space": [],
  "rank_by_space_pool": [],
  "ops_log": []
}
```

同时写入 `ranking_original.json`（只写一次，用于 undo 重放）。

---

### 2.3 路径 C：缺少必要参数

**触发条件**：既没有 `--run-id`，也没有 `--category` 或 `--city`

**系统行为**：红色"需要 --category 参数"或"需要 --city 参数" + exit(1)

---

## 三、功能二：查看历史榜单（`list runs`）

```bash
uv run tsp-ops-menu list runs
```

**系统判断**：

1. 扫描 `~/.local/share/tsp-ops/outputs/` 下所有目录
2. 读取每个 `ranking.json`，提取元信息
3. 按 `generated_at` 降序展示表格：run_id | 城市 | 品类 | 数据日期 | 时间窗口 | Top N | 排名方式 | 价格带 | 生成时间 | 操作数

用户可从表格中找到历史 run_id，再用 `list ranking --run-id {run_id}` 加载继续操作。

---

## 四、功能三：查询本质词指标（`get product`）


### 3.1 路径 A：查聚合指标（level=0）

```bash
uv run tsp-ops-menu get product --query "(奶茶,0)" --city 成都 --category 饮品甜点
```

**系统判断**：

1. 解析 `(奶茶,0)` → `{key: "奶茶", depth: 0}`
2. 按 depth 分组，`level=0` 的词合并一次请求
3. 调用 `POST /api/insight/opportunity/v1/product/query`，`level=0`
4. 从响应 `data.productMetrics["奶茶"]` 取结果
5. 结果为单元素列表 → 展示"奶茶 聚合指标"

| 结果 | 展示 |
|------|------|
| 有数据 | 展示指标表格（wmSales/phfSales/wmOrderRatio/phfOrderRatio/orderSpace/wmAvgPrice） |
| 空列表 | 黄色"奶茶（depth=0）：数据库中不存在" |

---

### 3.2 路径 B：查子词列表（level=1）

```bash
uv run tsp-ops-menu get product --query "(咖啡,1)" --city 成都 --category 饮品甜点
```

**系统判断**：

1. 调用 `level=1`
2. 响应 `productMetrics["咖啡"]` 为列表：`[父词自身, 子词1, 子词2, ...]`
3. `items[0]` = 父词自身（`subProductName="-"`），`items[1:]` = 子词（`subProductName` = 子本质词名）
4. 展示时：父词行显示 `productName`，子词行显示 `productName / subProductName`
5. 展示"咖啡 及子词（共 N 个子词）"，列出所有元素

| 结果 | 展示 |
|------|------|
| 只有父词（无子词） | "咖啡 及子词（共 0 个子词）" |
| 有子词 | 父词 + 子词全部展示在同一表格 |
| 空列表 | 黄色"咖啡（depth=1）：数据库中不存在" |

---

### 3.3 路径 C：批量混合查询

```bash
uv run tsp-ops-menu get product --query "(奶茶,0);(咖啡,1);(豆浆,0)" --city 成都 --category 饮品甜点
```

**系统判断**：

1. 解析所有词，按 depth 分组：`{0: ["奶茶","豆浆"], 1: ["咖啡"]}`
2. 对每个 depth 组发一次请求（共 2 次请求）
3. 合并 `all_metrics` 字典
4. 按原始查询顺序依次展示每个词的结果

---

## 五、功能四：操作榜单（`update ranking`）

所有操作需要有效的 `run_id`（本地 `ranking.json` 存在）。操作完成后**自动**上报操作记录到服务端（静默失败，不影响主流程）。

### 4.1 路径 A：切换排名维度（switch）

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --switch orders_main
uv run tsp-ops-menu update ranking --run-id {run_id} --switch order_space
```

**系统判断**：

```
读取本地 ranking.json
  │
  ├─ 目标排名已存在（如 rank_by_space 非空）
  │    → 直接切换 active_ranking，保存，展示
  │
  └─ 目标排名不存在（如 rank_by_space 为空列表）
       → 调用 POST /api/insight/opportunity/v1/list/query（相同参数，不同 sortType）
       → 写入 ranking_original.json 的对应 key
       → 重放 ops_log（将已有操作应用到新排名）
       → 切换 active_ranking，保存，展示
```

**自动上报**：`operationType="QUERY"`，`userMessage="切换排名 {orders_main|order_space}"`

---

### 4.2 路径 B：删除（delete）

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op delete --del 豆浆
```

**参数校验**：`--del` 必须恰好一个词，否则报错退出。

**系统判断**：

1. 从 `active_ranking` 对应列表中移除该词
2. 从候选池（`rank_by_main_pool` 或 `rank_by_space_pool`）补位，保持 top_n 数量
3. 重新编号 rank（1..N）
4. 追加 ops_log：`{op:"delete", params:{delete_key:"豆浆"}}`
5. 保存，展示，上报

**自动上报**：`operationType="EXCLUDE"`，`userMessage="删除 {词}"`

**候选池耗尽时**：条目数 < top_n，正常展示，不报错。

---

### 4.3 路径 C：上聚/合并（merge）

```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op merge --del "美式咖啡;拿铁咖啡" --add 咖啡系列
```

**参数校验**：`--del` 至少一个词，`--add` 恰好一个词，否则报错退出。

**系统判断**：

1. 找出被删词中排名最高的位置（insert_rank）
2. 从 active_ranking 中移除所有被删词
3. 本地计算合并词指标（不调服务端）：
   - `wmSales` = 被删词 wmSales 之和
   - `phfSales` = 被删词 phfSales 之和
   - `wmOrderRatio` = 被删词 wmOrderRatio 之和
   - `phfOrderRatio` = 被删词 phfOrderRatio 之和
   - `orderSpace` = max(0, wmOrderRatio - phfOrderRatio)
   - `wmAvgPrice` = 加权均价（按 wmSales+phfSales 加权）
   - `standFoodName` = 第一个被删词的 standFoodName（非空则取）
   - `isOnlineMustItem` = 所有被合并词均为 `true` → `true`；任一为 `false` → `false`；其余 → `"-"`
   - `is_new_find` = `wmSales > 0 and phfSales == 0`
4. 将合并词插入 insert_rank - 1 位置
5. 从候选池补位到 top_n
6. 重新编号，追加 ops_log，保存，展示，上报

**自动上报**：`operationType="MERGE"`，`userMessage="合并 {del_list} → {新词}"`

---

### 4.4 路径 D：下钻/展开（expand）

```bash
# 展开所有子词
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶

# 展开指定子词
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶 --add "珍珠奶茶;芋泥奶茶"
```

**参数校验**：`--del` 恰好一个词，否则报错退出。

**系统判断**：

```
调用 POST /api/insight/opportunity/v1/product/query
  products=["奶茶"], level=1
  │
  ├─ HTTP 错误 → 红色报错 + exit(1)
  ├─ code != 0 → 红色报错 + exit(1)
  │
  └─ 正常响应
       productMetrics["奶茶"] = [父词自身, 子词1, 子词2, ...]
       sub_items = items[1:]  # 去掉父词自身
       │
       ├─ 若指定了 --add
       │    → 将子词的 subProductName 映射为 productName（子词展示名）
       │    → 过滤 sub_items，只保留 productName 在 add_list 中的
       │    → 不在数据库中的词：黄色警告"已跳过：{missing}"
       │
       └─ sub_items 为空 → 红色"无可用子词数据，expand 操作取消" + exit(1)

本地操作：
  1. 从 active_ranking 移除父词
  2. 按 SORT_METRIC 将每个子词插入正确位置（保序）
  3. 若 items 超过 top_n，多余的词移到候选池头部
  4. 从候选池补位到 top_n
  5. 追加 ops_log（含 _sub_items 完整指标，供 undo replay）
  6. 保存，展示，上报
```

**自动上报**：`operationType="EXPAND"`，`userMessage="下钻 {父词}"`

---

## 六、功能五：撤销（`delete record --last`）

```bash
uv run tsp-ops-menu delete record --last --run-id {run_id}
```

**参数校验**：必须传 `--last`，否则报错退出。

**系统判断**：

```
读取 ops_log
  │
  ├─ ops_log 为空 → 黄色"没有可撤销的操作" + exit(0)
  │
  └─ 弹出最后一条 ops_log
       从 ranking_original.json 读取原始榜单
       对每个已存在的 ranking key（rank_by_main / rank_by_space）：
         replay_ops(original_items, original_pool, 剩余 ops_log)
       保存重建后的榜单
       展示当前清单
       上报（operationType="EXCLUDE"，userMessage="撤销操作"）
```

**注意**：撤销是全量重放（从原始榜单重新应用所有剩余操作），不是单步回退。

---

## 七、功能六：导出清单（`export ranking`）

```bash
uv run tsp-ops-menu export ranking --run-id {run_id}
```

**系统判断**：

```
1. 加载本地 ranking.json
2. 取 active_ranking 对应的 items 列表
3. 静默调用 POST /list/query（相同参数）检查服务端缓存状态
   ├─ source == "CACHED"
   │    → 黄色"服务端已有该清单的缓存（dt={dt}，操作人：{creator}），是否覆盖？"
   │    → 终端模式：y→继续，n→取消 exit(0)
   │    → Skill 模式：输出提示后自动继续导出（非阻塞）
   └─ source == "NEW_QUERY" 或请求失败（静默忽略）→ 直接继续
4. 本地生成 Excel（openpyxl）：
   列：排名 | 聚合本质词 | 是否新发现 | 是否线上必上菜 | 主站销量 | 拼好饭销量 |
       主站下单率% | 拼好饭下单率% | 订单空间% | 主站均价 | 标准菜名
   注：wmOrderRatio 等字段已是百分比，直接写入，不需要 ×100
5. 调用 POST /api/insight/opportunity/v1/export，传 productList JSON
   │
   ├─ 失败 → 红色"上传失败：{e}" + exit(1)
   │
   └─ 成功 → 取 data.downloadUrl
6. 打印"导出成功"+ 链接
7. 将 export_url 写回 ranking.json
```

**注意**：CLI 本地用 BytesIO 构建 Excel 数据，不落盘；Excel 文件由服务端生成并上传 S3，返回下载链接。

---

## 八、操作记录自动上报（`record/create`）

每次 update ranking / delete record 操作完成后，**自动静默上报**：

| 操作 | operationType | userMessage |
|------|--------------|-------------|
| delete | EXCLUDE | "删除 {词}" |
| merge | MERGE | "合并 {del_list} → {新词}" |
| expand | EXPAND | "下钻 {父词}" |
| switch | QUERY | "切换排名 {orders_main\|order_space}" |
| undo | EXCLUDE | "撤销操作" |

上报失败时静默忽略（try/except pass），不影响主流程。

上报内容：
```json
{
  "operationType": "EXCLUDE",
  "userMessage": "删除 豆浆",
  "productListSnapshot": [ /* 操作后的当前榜单 */ ],
  "cityName": "福州",
  "categoryName": "饮品甜点"
}
```

---

## 九、本地文件结构与生命周期

```
~/.local/share/tsp-ops/outputs/
└── {run_id}/
    ├── ranking.json          # 当前榜单（含 ops_log，每次操作后更新）
    ├── ranking_original.json # 原始榜单（只写一次，用于 undo 重放）
    └── snapshots/
        ├── meta.json         # 快照索引
        └── v001.json, v002.json, ...
```

**ranking.json 顶层字段**（不随 Item 字段变化）：

| 字段 | 说明 |
|------|------|
| `run_id` | 格式：`{city}_{category}_{yyyyMMddHHmmss}` |
| `city` | 用户传入的城市名 |
| `category` | 品类名 |
| `dt` | 数据日期（yyyyMMdd），用于本地缓存匹配 |
| `dt_window` | CLI 参数（"1d"/"7d" 等） |
| `top_n` | 榜单条目数 |
| `sort_by` | "orders_main" 或 "order_space" |
| `price_min` / `price_max` | 价格带 |
| `generated_at` | 生成时间（"YYYY-MM-DD HH:MM:SS"） |
| `active_ranking` | "rank_by_main" 或 "rank_by_space" |
| `rank_by_main` | 主站销量排名列表（ProductListItem[]） |
| `rank_by_main_pool` | 主站排名候选池 |
| `rank_by_space` | 订单空间排名列表（切换后才生成） |
| `rank_by_space_pool` | 订单空间候选池 |
| `ops_log` | 操作记录列表 |
| `export_url` | 导出后写入 |

---

## 十、ProductListItem 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `productName` | string | 聚合本质词（榜单展示单元） |
| `subProductName` | string | 子本质词名；list/query 和 level=0 时固定为 `"-"`，level=1 子词行为实际子词名 |
| `date` | string | 数据日期（yyyyMMdd） |
| `cityName` | string | 城市名 |
| `categoryName` | string | 品类名 |
| `dateType` | int | 时间维度（1/3/7/14/30） |
| `wmSales` | int | 主站销量 |
| `phfSales` | int | 拼好饭销量 |
| `tbsgSales` | int | TBSG 销量 |
| `wmAvgPrice` | float | 主站加权均价（元） |
| `phfAvgPrice` | float | 拼好饭均价 |
| `tbsgAvgPrice` | float | TBSG 均价 |
| `wmOrderRatio` | float | 主站下单率（百分比，如 8.0 = 8%） |
| `phfOrderRatio` | float | 拼好饭下单率（百分比） |
| `tbsgOrderRatio` | float | TBSG 下单率（百分比） |
| `orderSpace` | float | 订单空间（百分比，可为负，= wmOrderRatio - phfOrderRatio） |
| `standFoodName` | string | 标准菜名（单字符串，无则空字符串） |
| `isOnlineMustItem` | bool/string | 是否线上必上菜（`true`/`false`/`"-"`=不知道）；合并词：全为 `true` → `true`，任一 `false` → `false`，其余 → `"-"` |
| `is_new_find` | bool | CLI 本地计算：`wmSales > 0 and phfSales == 0` |
| `rank` | int | 排名（CLI 本地填充，服务端不返回） |

---

## 十、错误处理汇总

| 场景 | 错误信息 | exit code |
|------|---------|-----------|
| 网络不通 / 服务异常 | "服务端请求失败：{e}" | 1 |
| 服务返回 code != 0 | "服务端错误：{message}" | 1 |
| run_id 不存在 | "找不到 run_id：{run_id}" | 1 |
| delete 参数错误 | "delete 操作需要恰好一个 --del 参数" | 1 |
| merge 参数错误 | "merge 操作需要 --del 词1;词2 --add 新词" | 1 |
| expand 参数错误 | "expand 操作需要恰好一个 --del 参数" | 1 |
| expand 子词不存在 | "无可用子词数据，expand 操作取消" | 1 |
| expand 部分子词缺失 | "警告：以下子词在数据库中不存在，已跳过：{set}" | 继续执行 |
| undo 无可撤销操作 | "没有可撤销的操作" | 0 |
| 缺少 --last 参数 | "需要 --last 参数" | 1 |
| openpyxl 未安装 | "缺少 openpyxl，请 pip install openpyxl" | 1 |
| 导出上传失败 | "上传失败：{e}" | 1 |
| 自动上报失败 | 静默忽略 | 不影响主流程 |
