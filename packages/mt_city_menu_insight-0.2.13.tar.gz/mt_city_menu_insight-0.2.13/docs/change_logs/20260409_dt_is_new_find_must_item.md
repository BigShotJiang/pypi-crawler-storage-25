# 变更记录：dt 默认值、is_new_find 逻辑、isOnlineMustItem 合并逻辑

**日期**：2026-04-09  
**分支**：api-v2.1  
**涉及文件**：`cli/commands/list_cmd.py`、`cli/local/ops.py`

---

## 1. `--dt` 默认值改为 T-1

**变更前**：`dt` 默认传当天（`now.strftime("%Y%m%d")`）  
**变更后**：`dt` 默认传昨天（`(now - timedelta(days=1)).strftime("%Y%m%d")`）

**原因**：今天的数据当天还没有，默认传今天会导致服务端返回空数据。

**同步修复**：`ops.py` 中 `switch` 命令拉取新排名维度时，原来从 `generated_at`（生成时间）截取日期，改为直接读取 `ranking.json` 中的 `dt` 字段（数据日期）。若 `dt` 为空则回退到 T-1。

---

## 2. `is_new_find` 逻辑变更

**变更前**：`is_new_find = (standFoodName == "")`（标准菜名为空则标记为新发现）  
**变更后**：`is_new_find = (wmSales > 0 and phfSales == 0)`（主站有销量但拼好饭销量为零）

**影响范围**：
- `list ranking` 保存时：对 `main_list` 和 `buffer_list` 所有 item 补充计算 `is_new_find`
- `update ranking --op merge` 合并词：合并后的新词也按新逻辑计算

---

## 3. `isOnlineMustItem` 合并逻辑变更

**变更前**：合并词 `isOnlineMustItem` 写死为 `False`  
**变更后**：
- 所有被合并词均为 `True` → 合并词为 `True`
- 任意一个被合并词为 `False` → 合并词为 `False`
- 其余情况（含 `"-"`/不知道）→ 合并词为 `"-"`

**原因**：服务端返回三态值（`true`/`false`/`"-"`），合并时应保留语义最严格的判断。导出 Excel 时三态分别写入"是"/"否"/"-"。
