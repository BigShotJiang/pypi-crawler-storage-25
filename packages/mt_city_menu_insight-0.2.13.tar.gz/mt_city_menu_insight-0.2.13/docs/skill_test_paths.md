# SKILL.md 标准测试路径

> 覆盖 SKILL.md 所有功能分支的对话测试用例。每条路径描述：触发语句 → 期望的 CLI 命令 → 期望的系统行为。

---

## 一、鉴权

### T-AUTH-1：MIS 未配置
**用户输入**：查一下成都饮品甜点的热销品  
**前置条件**：`~/.local/share/tsp-ops/config.json` 不存在或 `mis` 为空  
**期望行为**：
- Skill 先 `cat ~/.local/share/tsp-ops/config.json` 检查
- 询问用户"请问你的美团 MIS ID 是什么？"
- 用户回复后执行 `uv run tsp-ops-menu config set-mis {mis}`
- 继续执行查询

### T-AUTH-2：MIS 已配置，直接跳过
**用户输入**：查一下成都饮品甜点的热销品  
**前置条件**：config.json 中 `mis` 非空  
**期望行为**：
- `cat` 检查后直接执行 `list ranking`，不询问 MIS

---

## 二、功能一：获取清单

### T-LIST-1：完整参数直接查询
**用户输入**：帮我查一下杭州粉面粥饺的热销品，top 20  
**期望命令**：
```bash
uv run tsp-ops-menu list ranking --city 杭州 --category 粉面粥饺 --top-n 20
```
**期望行为**：
- 展示 top20 清单（含 🆕 标记）
- 输出后置引导（切换排名 / 价格带 / 上聚 / 下钻 / 删除 / 撤销 / 导出）

### T-LIST-2：city 不明确，暂停询问
**用户输入**：帮我查一下粉面粥饺的热销品  
**期望行为**：
- 不执行命令
- 询问"请问是哪个城市？"
- 用户回复"杭州"后再执行

### T-LIST-3：category 不明确，暂停询问
**用户输入**：帮我查一下杭州的热销品  
**期望行为**：
- 询问"请问是哪个品类？（西快小吃 / 饮品甜点 / 粉面粥饺 / 饭类）"
- 用户回复后再执行

### T-LIST-4：指定价格带
**用户输入**：查一下上海饭类 10-30 元的热销品  
**期望命令**：
```bash
uv run tsp-ops-menu list ranking --city 上海 --category 饭类 --price-min 10 --price-max 30
```

### T-LIST-5：指定时间窗口
**用户输入**：查一下北京西快小吃 7 天的榜单  
**期望命令**：
```bash
uv run tsp-ops-menu list ranking --city 北京 --category 西快小吃 --dt-window 7d
```

### T-LIST-6：指定排名方式为订单空间
**用户输入**：查一下成都饮品甜点按机会品排的榜单  
**期望命令**：
```bash
uv run tsp-ops-menu list ranking --city 成都 --category 饮品甜点 --sort order_space
```

### T-LIST-7：命中服务端缓存（CACHED）
**用户输入**：查一下成都饭类的热销品  
**前置条件**：服务端返回 `source: "CACHED"`  
**期望行为**：
- CLI 输出黄色"命中服务端缓存（dt=..., 操作人：...）"
- Skill 直接使用缓存数据展示，不询问用户
- 输出后置引导

### T-LIST-8：命中本地缓存（NEW_QUERY + 本地有匹配）
**用户输入**：查一下成都饭类的热销品（第二次，参数相同）  
**前置条件**：服务端返回 `source: "NEW_QUERY"`，本地有相同参数的 run_id  
**期望行为**：
- CLI 输出青色"命中本地缓存（run_id: ..., 生成时间：...）"
- Skill 自动使用本地缓存，直接展示已有 run_id，不生成新 run_id

### T-LIST-9：用户明确要求重新查询
**用户输入**：重新查一下，不要用缓存  
**期望命令**：
```bash
uv run tsp-ops-menu list ranking --city {city} --category {category} --no-cache ...
```

---

## 三、功能二：查看历史榜单

### T-RUNS-1：查看所有历史
**用户输入**：我有哪些历史榜单  
**期望命令**：
```bash
uv run tsp-ops-menu list runs
```
**期望行为**：展示历史记录表格（run_id / 城市 / 品类 / 数据日期 / 生成时间 / 操作数）

### T-RUNS-2：加载指定历史
**用户输入**：刚刚那个杭州粉面粥饺的清单  
**期望流程**：
1. `uv run tsp-ops-menu list runs` 列出历史
2. 找到匹配的 run_id
3. `uv run tsp-ops-menu list ranking --run-id {run_id}`
4. 更新会话 `current_run_id`，展示清单

### T-RUNS-3：上次的清单（无 list runs，直接加载）
**用户输入**：上次的清单  
**前置条件**：会话中已有 `current_run_id`  
**期望行为**：
- 直接 `list ranking --run-id {current_run_id}`，不重新 `list runs`

---

## 四、功能三：查询本质词指标

### T-GET-1：查聚合指标（depth=0）
**用户输入**：看看奶茶的指标  
**期望命令**：
```bash
uv run tsp-ops-menu get product --query "(奶茶,0)" --city {city} --category {category}
```
**期望行为**：展示奶茶聚合指标表格（wmSales / phfSales / wmOrderRatio / orderSpace / wmAvgPrice）

### T-GET-2：查子词列表（depth=1）
**用户输入**：奶茶下面有哪些子词  
**期望命令**：
```bash
uv run tsp-ops-menu get product --query "(奶茶,1)" --city {city} --category {category}
```
**期望行为**：展示父词 + 所有子词（`productName / subProductName` 格式）

### T-GET-3：词不存在
**用户输入**：看看"火星奶茶"的指标  
**期望行为**：CLI 输出黄色"火星奶茶（depth=0）：数据库中不存在"，Skill 告知用户

### T-GET-4：批量查询
**用户输入**：同时看看奶茶和咖啡的指标，咖啡要看子词  
**期望命令**：
```bash
uv run tsp-ops-menu get product --query "(奶茶,0);(咖啡,1)" --city {city} --category {category}
```

---

## 五、功能四：操作清单

### T-OP-0：无 current_run_id 时操作
**用户输入**：删掉豆浆  
**前置条件**：会话中没有 `current_run_id`  
**期望行为**：提示"请先查询一个清单，再执行操作"，不执行命令

### T-OP-SWITCH-1：切换到订单空间排名（已有 rank_by_space）
**用户输入**：切换到订单空间排名  
**前置条件**：本地 `rank_by_space` 非空  
**期望命令**：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --switch order_space
```
**期望行为**：直接切换，展示新清单 + 后置引导

### T-OP-SWITCH-2：切换到订单空间排名（需调服务端）
**用户输入**：切换到订单空间排名  
**前置条件**：本地 `rank_by_space` 为空  
**期望行为**：
- CLI 自动调服务端生成 rank_by_space
- 重放 ops_log
- 展示新清单 + 后置引导

### T-OP-SWITCH-3：切换回主站销量
**用户输入**：换回主站销量排名  
**期望命令**：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --switch orders_main
```

### T-OP-DELETE-1：删除单个词
**用户输入**：删掉豆浆  
**期望命令**：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op delete --del 豆浆
```
**期望行为**：删除后候选池补位，展示更新后清单 + 后置引导

### T-OP-DELETE-2：删除词不在榜单中
**用户输入**：删掉火星奶茶  
**期望行为**：CLI 报错，Skill 告知用户"火星奶茶不在当前清单中"

### T-OP-MERGE-1：合并两个词，用户指定新名称
**用户输入**：把美式咖啡和拿铁咖啡合并成咖啡系列  
**期望流程**：
1. Skill 告知用户：将合并 `["美式咖啡", "拿铁咖啡"]` → `咖啡系列`，确认？
2. 用户确认后：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op merge --del "美式咖啡;拿铁咖啡" --add 咖啡系列
```
3. 展示变更（合并词在第几位，指标汇总）+ 后置引导

### T-OP-MERGE-2：合并词，Skill 建议名称
**用户输入**：把咖啡类的几个词合并一下  
**期望流程**：
1. Skill 询问要合并哪些词、合并后叫什么
2. 用户确认后执行

### T-OP-MERGE-3：合并词中有不在榜单的词
**用户输入**：把美式咖啡和宇宙拿铁合并  
**期望行为**：执行前 Skill 应验证词是否在榜单中，提示"宇宙拿铁不在当前清单"

### T-OP-EXPAND-1：展开所有子词
**用户输入**：展开奶茶  
**期望流程**：
1. 先查子词：
```bash
uv run tsp-ops-menu get product --query "(奶茶,1)" --city {city} --category {category}
```
2. 展示子词列表，告知用户"确认展开所有子词？"
3. 用户确认后：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶
```
4. 展示变更（展开了哪些子词、插入位置）+ 后置引导

### T-OP-EXPAND-2：展开指定子词
**用户输入**：展开奶茶，只要珍珠奶茶和芋泥奶茶  
**期望流程**：
1. 先查子词（同上）
2. 用户确认后：
```bash
uv run tsp-ops-menu update ranking --run-id {run_id} --op expand --del 奶茶 --add "珍珠奶茶;芋泥奶茶"
```

### T-OP-EXPAND-3：展开词无子词
**用户输入**：展开豆浆  
**期望行为**：查子词后 CLI 输出"无可用子词数据，expand 操作取消"，Skill 告知用户

### T-OP-EXPAND-4：指定子词中有不存在的
**用户输入**：展开奶茶，只要珍珠奶茶和宇宙奶茶  
**期望行为**：CLI 输出黄色"警告：以下子词在数据库中不存在，已跳过：{'宇宙奶茶'}"，Skill 告知用户并继续执行

### T-OP-UNDO-1：撤销最后一步
**用户输入**：撤销  
**期望命令**：
```bash
uv run tsp-ops-menu delete record --last --run-id {run_id}
```
**期望行为**：展示撤销后清单 + 后置引导

### T-OP-UNDO-2：无可撤销操作
**用户输入**：撤销  
**前置条件**：ops_log 为空  
**期望行为**：CLI 输出"没有可撤销的操作"，Skill 告知用户

### T-OP-UNDO-3：连续撤销两步
**用户输入**：再撤销一次（在已撤销一次后）  
**期望行为**：再次执行 `delete record --last`，展示再次撤销后的状态

---

## 六、功能五：导出清单

### T-EXPORT-1：正常导出（无服务端缓存）
**用户输入**：导出清单  
**期望命令**：
```bash
uv run tsp-ops-menu export ranking --run-id {run_id}
```
**期望行为**：导出成功，输出 S3 下载链接，询问是否还有其他操作

### T-EXPORT-2：导出时服务端有缓存
**用户输入**：导出清单  
**前置条件**：服务端返回 `source: "CACHED"`  
**期望行为**：
- CLI 输出"服务端已有该清单的缓存（dt=..., 操作人：...），是否覆盖？"
- Skill 非交互式，CLI 自动继续导出
- Skill 在输出中告知用户"已检测到服务端有缓存，本次导出将覆盖"

### T-EXPORT-3：无 current_run_id 时导出
**用户输入**：导出清单  
**前置条件**：会话中没有 `current_run_id`  
**期望行为**：提示"请先查询一个清单，再执行导出"

---

## 七、复合路径（多轮对话）

### T-FLOW-1：完整标准流程
```
用户：查一下杭州粉面粥饺 top50
  → list ranking --city 杭州 --category 粉面粥饺 --top-n 50
用户：删掉烧麦
  → update --op delete --del 烧麦
用户：把猪肉饺子和西芹鲜肉水饺合并成饺子系列
  → [确认] → update --op merge --del "猪肉饺子;西芹鲜肉水饺" --add 饺子系列
用户：导出
  → export ranking
```
**期望**：全程 `current_run_id` 保持一致，最终导出成功

### T-FLOW-2：查看子词后展开
```
用户：查一下成都饮品甜点 top30
  → list ranking --city 成都 --category 饮品甜点 --top-n 30
用户：奶茶下面有哪些子词
  → get product --query "(奶茶,1)" --city 成都 --category 饮品甜点
用户：展开奶茶，只要珍珠奶茶和芋泥奶茶
  → update --op expand --del 奶茶 --add "珍珠奶茶;芋泥奶茶"
用户：撤销
  → delete record --last
```
**期望**：撤销后奶茶回到原位，ops_log 恢复为 0

### T-FLOW-3：切换排名后操作再撤销
```
用户：查一下上海饭类 top20
  → list ranking --city 上海 --category 饭类 --top-n 20
用户：切换到订单空间排名
  → update --switch order_space
用户：删掉排第一的那个
  → update --op delete --del {第一名词}
用户：撤销
  → delete record --last
```
**期望**：撤销后 rank_by_space 恢复，第一名回来

### T-FLOW-4：历史榜单加载后继续操作
```
用户：我有哪些历史榜单
  → list runs
用户：加载杭州粉面粥饺那个
  → list ranking --run-id {run_id}
用户：删掉豆浆
  → update --op delete --del 豆浆（使用加载的 run_id）
```
**期望**：操作基于加载的历史 run_id，而非新建

### T-FLOW-5：本地缓存命中后重新查询
```
用户：查一下成都饭类
  → list ranking --city 成都 --category 饭类（第一次，生成新 run_id）
用户：再查一次成都饭类
  → list ranking --city 成都 --category 饭类（命中本地缓存，展示旧 run_id）
用户：不要缓存，重新查
  → list ranking --city 成都 --category 饭类 --no-cache（生成新 run_id）
```
**期望**：第三次生成新 run_id，会话 current_run_id 更新

### T-FLOW-6：多次上聚后撤销到初始状态
```
用户：查一下北京西快小吃 top50
用户：把美式咖啡和拿铁合并成咖啡系列
用户：把豆浆和豆腐脑合并成豆类饮品
用户：撤销
  → delete record --last（撤销第二次合并）
用户：撤销
  → delete record --last（撤销第一次合并）
```
**期望**：两次撤销后榜单恢复到初始状态，ops_log 为空

---

## 八、边界与异常路径

### T-ERR-1：服务端请求失败
**前置条件**：网络不通或服务异常  
**期望行为**：CLI 输出红色"服务端请求失败：{e}"，Skill 告知用户稍后重试

### T-ERR-2：服务端返回 code != 0
**前置条件**：服务端返回错误码  
**期望行为**：CLI 输出红色"服务端错误：{message}"，Skill 透传错误信息给用户

### T-ERR-3：run_id 不存在
**用户输入**：list ranking --run-id 不存在的ID  
**期望行为**：CLI 输出"找不到 run_id：xxx"，Skill 提示用户先查询

### T-ERR-4：expand 后候选池耗尽，条目数 < top_n
**前置条件**：expand 插入了很多子词，候选池不够补位  
**期望行为**：正常展示（条目数 < top_n），不报错，Skill 告知用户"当前清单共 N 条（候选池已耗尽）"

### T-ERR-5：必上菜查询
**用户输入**：饭类有哪些必上菜  
**期望行为**：
- 触发 skill（description 中有覆盖）
- 执行 `list ranking`，在结果中筛选/标注 `isOnlineMustItem == true` 的条目
- 展示必上菜清单
