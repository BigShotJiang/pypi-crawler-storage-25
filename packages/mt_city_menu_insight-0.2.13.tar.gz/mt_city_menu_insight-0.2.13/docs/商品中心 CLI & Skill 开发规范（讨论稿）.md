# 商品中心 CLI & Skill 开发规范（讨论稿）

****
**前言**<br>
本规范适用于交易系统平台部-商品中心所有 CLI 工具的设计、开发、发布与维护。规范的目标是：

●	统一命令风格，降低跨组学习成本<br>
●	建立安全防护机制，防止高风险操作（价格变更、规则部署）引发资损<br>
●	提升运维效率，将原本依赖人工的数据查询、配置变更、故障排查收敛到工具链<br>
●	形成治理闭环，建立命令目录、质量分级和废弃机制


**参考文档**


- **公司级 CLI 规范：**(https://km.sankuai.com/collabpage/2751446707 "业务研发平台CLI开发规范（草稿）")
- **商品中心 CLI 规范化：**(https://km.sankuai.com/collabpage/2752091810 "商品中心 CLI 规范化")
- **CLI 简述：**(https://km.sankuai.com/collabpage/2752652725 "CLI简述")

## 一、 命令设计规范

### 1.1 命令结构

所有命令统一采用以下结构：

**`<cli工具> <动词> <资源>  `**


> 示例：<br>
> `ops-insight get prcing --id 10086 --env prod`<br>
> `tsp-std-similar list cspu --name 饮料 --format json`
>
>


### 1.2 动词词汇表

动词必须从以下受控词汇表中选取，禁止使用 do、run、handle、exec 等模糊动词。


| 动词 | 说明 | 示例 |
| --- | --- | --- |
| get | 获取单条资源 | <业务标识>-cli get sku --id 123 |
| list | 获取资源列表 | <业务标识>-cli list sku --category 饮料 |
| create | 创建资源 | <业务标识>-cli create rule --file rule.json |
| update | 更新资源 | <业务标识>-cli update price --sku-id 123 --price 9.9 |
| delete | 删除资源（谨慎） | <业务标识>-cli delete rule --id R001 --yes |
| sync | 触发数据同步 | <业务标识>-cli sync boom-sku --date 2024-01-15 |
| deploy | 发布/部署配置 | <业务标识>-cli deploy rule --id R001 --env prod |
| check | 健康检查/校验 | <业务标识>-cli check index --name boom_sku |
| describe | 查看详细信息 | <业务标识>-cli describe rule --id R001 |
| export | 导出数据 | <业务标识>-cli export sku --format csv |
| import | 导入数据 | <业务标识>-cli import sku --file data.csv |

**补充要求**


- 历史命令如已使用 `query`、`run` 等非标准动词，需通过兼容别名保留迁移期
- 废弃命令必须在 `--help` 中标记 `Deprecated`
- 新增命令不得继续扩展词汇表之外的动词

### 1.3 资源命名表

资源名称统一使用小写短横线风格（kebab-case），各组可在此基础上扩展，但公共资源不得重复定义。

// 各团队补充


| 参数 | 说明 | 示例 |
| --- | --- | --- |
| --env | 目标环境（必须显式声明） | --env prod / --env staging |
| --format | 输出格式 | --format json / table / yaml |
| --yes / -y | 跳过二次确认（写操作必须） | --yes |
| --dry-run | 预演模式，不实际执行 | --dry-run |
| --page / --size | 分页控制 | --page 1 --size 50 |
| #VALUE! | 过滤条件 | --filter status=active |
| --output / -o | 输出文件路径 | --output result.json |
| --verbose / -v | 详细输出模式 | --verbose |
| --timeout | 超时时间（秒） | --timeout 30 |

 

### 1.4 标准参数规范

以下参数为全局标准参数，所有命令必须按统一约定实现，不得自行重命名或改变语义。


| 参数 | 说明 | 示例 |
| --- | --- | --- |
| --env | 目标环境（必须显式声明） | --env prod / --env staging |
| --format | 输出格式 | --format json / table / yaml |
| --yes / -y | 跳过二次确认（写操作必须） | --yes |
| --dry-run | 预演模式，不实际执行 | --dry-run |
| --page / --size | 分页控制 | --page 1 --size 50 |
| #VALUE! | 过滤条件 | --filter status=active |
| --output / -o | 输出文件路径 | --output result.json |
| --verbose / -v | 详细输出模式 | --verbose |
| --timeout | 超时时间（秒） | --timeout 30 |

### 1.5 命令分层设计

为避免 CLI 命令膨胀、不可维护，需进行分层设计：


| 层级 | 说明 | 示例 |
| --- | --- | --- |
| 核心命令层 | 标准 CRUD / 操作命令 | `get / list / create / update / delete` |
| 业务语义层 | 封装业务能力 | `compare / pricing / audit` |
| 运维辅助层 | 排查、诊断、导出 | `check / diagnose / export` |

**规范要求：**


- 优先使用「动词 + 资源」组合表达能力
- 复杂业务能力需沉淀为独立资源，而不是扩展 flag
- 禁止出现“万能命令”（如 `run-task`）

### 1.6 命令粒度规范

CLI 命令必须满足以下原则：


- ✅ 单一职责：一个命令只做一件事
- ✅ 可组合：支持 pipeline / script 编排
- ❌ 禁止大而全：一个命令完成多个业务步骤

示例：

```Markdown
// 代码块
# ❌ 错误（耦合多个动作）
product-cli process-order --id 123

# ✅ 正确（拆分）
product-cli get order --id 123
product-cli update order --status paid
```


### 1.7 输出规范

CLI 输出必须结构化，支持机器消费：


| 类型 | 规范 |
| --- | --- |
| 默认输出 | table（人类友好） |
| JSON输出 | 必须支持 `--format json` |
| 错误输出 | 标准 error code + message |
| Exit Code | 成功=0，失败≠0 |

示例：

```JSON
// 代码块
{
  "code": 0,
  "message": "success",
  "data": {...}
}
```

## 二、Help 文档规范

CLI 的 `help` 是用户的第一使用入口，需具备**可理解、可执行、可排错**三项基本能力。帮助信息应优先说明命令用途和高频使用路径，而不是单纯堆砌参数列表，确保用户能够通过 `help` 快速完成首次使用、常见操作和问题定位。

### 2.1 必须包含的要素


| 项目 | 规范要求 |
| --- | --- |
| 一句话描述 | 使用动词开头，直接说明命令作用，如“查询商品价格” |
| Usage | 使用 `<arg>` 表示必填参数，`` 表示可选参数 |
| Examples | 提供 2~4 个高频示例，优先覆盖最常用场景 |
| Arguments | 说明位置参数的业务含义，不仅描述字段名 |
| Flags | 说明参数用途、类型、默认值、可选值 |
| 默认行为 | 明确未传参时的系统行为，如默认环境为 `test` |
| 错误提示 | 必填参数缺失、参数非法时，应提示用户执行对应 `--help` |
| 企业补充 | O涉及环境、鉴权、输出格式、写操作风险时，必须补充说明 |

### 2.2 Help 文档示例模板

```YAML
// 代码块
product-cli - 商品运营工具集

Usage:
  product-cli 
  product-cli price query --sku <skuId> 

Examples:
  product-cli price query --sku 12345
  product-cli compare run --biz sqs --date 2026-03-24
  product-cli export supply phf --output ./result.csv

Arguments:
  <skuId>        商品 SKU ID

Flags:
  -h, --help             查看帮助
      --env string       运行环境，可选值: dev, test, prod (默认: test)
      --date string      业务日期，格式: YYYY-MM-DD (默认: 当天)
      --format string    输出格式，可选值: table, json, csv (默认: table)
      --output string    输出文件路径 (默认: 当前目录)

Commands:
  price       定价相关命令
  compare     比价相关命令
  export      数据导出命令
  version     查看版本信息

Auth:
  默认读取本地登录态或环境变量 PRODUCT_TOKEN

Warning:
  部分写操作命令可能影响线上数据，执行前请确认目标环境

Run "product-cli  --help" for more information about a command.
```

## 三、安全与权限规范

### 3.1 鉴权机制

提供cli后端能力的服务通常包含http/https、thrift、mcp三种，http/https是目前主流的cli交互形式，因此鉴权主要围绕http展开，http鉴权通常是用户请求维度，公司提供四套鉴权能力：


- Passport：C端用户权限认证服务
- Epassport：商家端用户权限服务；
- SSO：公司员工权限认证
- UAC：SSO之上的精准权限控制


### 3.2 鉴权服务资料

Passport：(https://docs.sankuai.com/mt/us/user_doc/master/interface/retrieve/ "美团用户中心后端")、(https://km.sankuai.com/collabpage/424785005 "https://km.sankuai.com/collabpage/424785005")

Epassport：、(https://docs.sankuai.com/mt/sjst/epassport-docs/master/backend/thrift/ "epassport-docs")

SSO：(https://km.sankuai.com/collabpage/2184190949 "https://km.sankuai.com/collabpage/2184190949")、(https://km.sankuai.com/collabpage/424855443 "https://km.sankuai.com/collabpage/424855443")

UAC：(https://km.sankuai.com/page/12735674#id-%E4%BA%8C%E3%80%81%E4%BC%81%E4%B8%9A%E7%BB%9F%E4%B8%80%E6%9D%83%E9%99%90%E7%AE%A1%E7%90%86%E7%B3%BB%E7%BB%9F-UAC "https://km.sankuai.com/page/12735674#id-%E4%BA%8C%E3%80%81%E4%BC%81%E4%B8%9A%E7%BB%9F%E4%B8%80%E6%9D%83%E9%99%90%E7%AE%A1%E7%90%86%E7%B3%BB%E7%BB%9F-UAC")、(https://km.sankuai.com/collabpage/424829114 "https://km.sankuai.com/collabpage/424829114")

牧羊人http（thrift->http）:(https://km.sankuai.com/collabpage/1219593232 "https://km.sankuai.com/collabpage/1219593232")


## 3.3 高风险操作规范

涉及以下操作必须增加保护：


- 删除（delete）
- 发布（deploy）
- 价格变更（update price）

**强制要求：**


- 必须支持 `--dry-run`
- 必须二次确认（除非 --yes）
- 必须记录操作日志 

```JSON
// 代码块
product-cli update price --sku 123 --price 9.9

⚠️ 该操作将修改生产环境价格，请确认
Type YES to continue:
```


## 3.4 审计与追踪

所有 CLI 操作必须具备可追踪能力：


| 项 | 说明 |
| --- | --- |
| 操作人 | SSO |
| 时间 | 时间戳 |
| 请求参数 | 完整记录 |
| requestId | 服务返回 |
| 结果 | success / fail |

## 四、开发规范

### 4.1 Node开发

**脚手架核心能力**
推荐使用cli开发脚手架：(https://km.sankuai.com/collabpage/2751017046 "Skill开发脚手架（如何基于MCP和线上API接口快速创建Skill）")

脚手架能力：


- 快速创建可运行Skill项目，支持线上Ajax接口或者MCP直接生成Skill
- 集成了统一鉴权能力和统一CLI能力
- AI Coding友好
- 支持本地调试和线上调试

#### 4.1.1 初始化node项目

```Shell
// 代码块
// 创建项目执行下面的命令，直接复制->执行，不用修改
mnpm create @it/oa-skill@latest

// 环境要求：
// node.js > 18
// npm >= 9.0.0
// TypeScript 5.0+
```

```Shell
// 项目结构
your-skills/
src/
├── skill-demo/      # skill对应cli代码实现
skills/
├── skill-demo/     # 对应 skill 定义 (SKILL.md)
└── ...           # 其他 skill 定义
tools/
├── list-mcp-tools.ts # MCP 工具列表查看器
└── mcp-to-cli.ts     # MCP 转 CLI 生成器
└── ajax-to-cli.ts    # ajax 转 CLI 生成器
docs/              # 教程及AI coding文档
└── mcp-to-skill-tutorial.md   # MCP 转换教程
└── mcp-to-skill-agent.md      # MCP转换 AI Coding文档
└── ajax-to-skill-tutorial.md  # ajax 转换教程
└── ajax-to-skill-agent.md     # ajax转换 AI Coding文档
spec/              # 规范文档
template/          # Skill 模板
```

#### 4.1.2 功能开发

**开发规范 📖（先读完再动手，会省很多事～）**
**scope：**已在公司内部 npm registry 申请统一 scope：**`@tsp-product`**

```Json
{
  "name": "@tsp-product/ops-data-sync",
  "version": "1.0.0",
  "bin": { "tsp-ops-data-sync": "./src/cli.js" },
  "publishConfig": { "registry": "http://r.npm.sankuai.com" }
}
```


**包名：**`@tsp-product/<组织缩写>-<工具名>` **命令**：`tsp-<组织缩写>-<工具名>`


| 规则 | 正确 | 错误 |
| --- | --- | --- |
| 全小写，连字符分隔 | `ops-data-sync` | `OpsDataSync` |
| 使用约定缩写 | `ops-data-sync` | `yunying-data-sync` |
| 语义清晰 | `mgr-sku-audit` | `mgr-tool1` |
| 通用工具不加组织前缀 | `@tsp-product/config` | `@tsp-product/common-config` |

组织缩写对照


| 组织 | 缩写 |  |
| --- | --- | --- |
| 商品运营 | `ops` | (https://x.sankuai.com/chat/2100531) |
| 商品管理 | `mgr` | (https://x.sankuai.com/chat/21547958) |
| 商品标准化 | `std` | (https://x.sankuai.com/chat/22899782) |
| 导购交易 | `trade` | (https://x.sankuai.com/chat/90420) |
| 跨组通用 | 无前缀 |  |

##### 4.1.2.1 鉴权

(https://km.sankuai.com/collabpage/2750788449 "https://km.sankuai.com/collabpage/2750788449")

##### 4.1.2.2 基于线上API接口创建Skill（推荐）

****
.md包含了cli创建和skill集成两部分能力

可以参考`/docs/ajax-to-skill-tutorial.md`的详细说明文档，也可以基于`/docs/ajax-to-skill-agent.md`让agent直接执行

##### 4.1.2.2 基于MCP创建Skill

可以参考`/docs/mcp-to-skill-tutorial.md`的详细说明文档，也可以基于`/docs/mcp-to-skill-agent.md`让agent直接执行


#### 4.1.3 发布

##### 4.1.3.1 cli发布

**1）发布npm包命令（**遇到问题参考：(https://km.sankuai.com/collabpage/127620956 "https://km.sankuai.com/collabpage/127620956")**）**

```Shell
// 代码块
mnpm run publish
```

发布完成后可以在(https://npm.sankuai.com/v2/pkg "https://npm.sankuai.com/v2/pkg")搜到您发布的包，可以根目录直接执行`mnpm view`查看

!(https://km.sankuai.com/api/file/cdn/2752751714/228307444596?contentType=1&isNewContent=false)



**2）cli注册（让其他人可以看到cli）**

注册Cli到(https://friday.sankuai.com/skills/cli-market "Friday Cli广场")：填写基础信息、安装信息、命令行说明。

**入口**
!(https://km.sankuai.com/api/file/cdn/2752751714/228323308464?contentType=1&isNewContent=false)




##### 4.1.3.2 skill发布

发布Skill到(https://friday.sankuai.com/mcp/skills-market "Friday Skill市场")：把/skill/your-skill文件夹压缩为zip包，上传到你创建的Skill里，Skill需要**创建在组织空间**

**入口**
!(https://km.sankuai.com/api/file/cdn/2752751714/228324545995?contentType=1&isNewContent=false)




### 4.2 Python开发

// 待补充

(https://km.sankuai.com/collabpage/2713219855 "https://km.sankuai.com/collabpage/2713219855")



## 五、PRFAQ

### 5.1 mnpm的scope如何申请权限？

需要发送tt让npm平台同学添加，详见：(https://km.sankuai.com/collabpage/862548571 "https://km.sankuai.com/collabpage/862548571")

### 5.2 Skill发布时看不到组织空间？

缺少组织空间管理员权限，联系空间管理员添加。

**如何查看管理员**
!(https://km.sankuai.com/api/file/cdn/2752751714/228323025434?contentType=1)






**附录一：CLI命令规范调研**

**详情**
**一、按参数语法规范分类（底层格式）**

这是最底层的分类，决定了 `-f`、`--flag`、`=` 怎么写。

**POSIX 风格**（最严格）

POSIX 规范要求工具名称使用 2–9 个字符的小写字母和数字；选项必须是单个字母前缀一个连字符（`-f`）；选项与参数可合写（`-ofoo`）或分开（`-o foo`）；选项必须出现在操作数之前，不允许混排；`--` 用于明确分隔选项与非选项参数。 (https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap12.html "The Open Group")

**GNU 扩展风格**（POSIX 的超集，最广泛）

GNU 标准在 POSIX 基础上要求为每个短选项定义等价的长选项（如 `-v` 对应 `--verbose`），并允许选项与操作数混排而无需 `--` 分隔。GNU 要求所有程序支持 `--version` 和 `--help` 两个标准选项。 (https://www.gnu.org/prep/standards/html_node/Command_002dLine-Interfaces.html "GNU")

长选项以两个连字符开头，后接一个或多个小写字母单词，单词之间用连字符分隔（如 `--output-file`）；带参数时支持 `--option=value` 或 `--option value` 两种写法。 (https://nullprogram.com/blog/2020/08/01/ "Nullprogram")

**Go flag 风格**（非标准，有争议）

Go 的 `flag` 包只支持长选项语义，却用单连字符（`-verbose`），导致无法支持短选项分组，且合并选项与参数只能用 `=`，偏离了主流约定。 (https://nullprogram.com/blog/2020/08/01/ "Nullprogram")


---

**二、按命令结构组织方式分类（架构层面）**

这是对工具设计影响最大的分类。

**1. 单命令风格（Unix 传统工具）**

`grep  pattern  ls -la /tmp`

适合功能单一的工具。参数、选项直接跟在命令名后，没有子命令层级。代表工具：`grep`、`ls`、`curl`、`wget`。


---

**2. Git 风格：****`工具 <动词>  `**

`git commit -m "msg" git push origin main`

Git 风格中，主程序本身可以有全局选项，子命令紧随其后，子命令的选项只跟在子命令之后；全局选项与子命令选项之间不能互换位置：`program -a -b subcommand -x -y`。 (https://nullprogram.com/blog/2020/08/01/ "Nullprogram")

特点是**动词优先**，先说动作再说对象，适合动作种类多、资源类型少的场景。代表工具：`git`、`npm`、`yarn`、`cargo`。


---

**3. kubectl 风格：****`工具 <动词> <名词> `**

`kubectl get pods --namespace=prod kubectl delete deployment my-app`

kubectl 的语法中，`command` 指定对资源执行的操作（如 create、get、describe、delete），`TYPE` 指定资源类型，资源类型不区分大小写，可使用单数、复数或缩写形式（`pod`/`pods`/`po` 等价）。 (https://kubernetes.io/docs/reference/kubectl/ "Kubernetes")

特点是**动词-名词正交组合**，资源类型和操作都标准化，用户学会一种组合就能推导其他。kubectl 的这种一致性命令层级使用户可以根据已知命令猜测新命令：知道 `kubectl get pods` 后自然能推出 `kubectl get deployments`，连 flag 的用法也遵循同样的原理。 (https://lucasfcosta.com/2022/06/01/ux-patterns-cli-tools.html "Lucas F. Costa")

适合资源类型多、对每种资源都有 CRUD 操作的平台工具。


---

**4. Docker 风格：****`工具 <名词> <动词> `**

`docker container create --name myapp nginx docker volume inspect myvolume`

Docker 采用两级子命令，一级是名词（资源对象），二级是动词（操作），如 `docker container create`。这种模式适合软件有大量对象且每个对象有多种操作的场景，关键是对不同对象类型保持动词一致。 (https://clig.dev/ "Clig")

与 kubectl 风格相反，先说资源后说动作，更接近自然语言"对 container 执行 create"。


---

**5. Heroku 风格：****`工具 <名词:动词>`**** （冒号分隔）**

`heroku apps:create my-app heroku pg:credentials:rotate`

Heroku CLI 用冒号定义子命令层级（如 `heroku apps:favorites:add`），命令名称只能是单个小写单词，不允许空格、连字符或下划线，多级资源用冒号串联。根命令通常直接列出该资源对象，不需要额外的 `:list` 子命令。 (https://devcenter.heroku.com/articles/cli-style-guide "Heroku Dev Center")

优点是命名空间清晰、Tab 补全体验好；缺点是与其他工具风格差异较大，不够直观。


---

**6. CF CLI 风格：****`工具 <动词-名词>`**** （连字符拼接）**

cf create-app myapp cf delete-buildpack my-bp cf set-space-role (mailto:user@example.com "user@example.com") myorg myspace SpaceManager

Cloud Foundry CLI 采用 VERB-NOUN 顺序将动词与名词连字符拼接为一个单词（如 `create-buildpack`）。这种方式的优势是 Tab 补全时输入 `cf cr<tab>` 可以直接看到所有"create"类命令，而无需再输入额外分隔符。 (https://github.com/cloudfoundry/cli/wiki/CF-CLI-Style-Guide "GitHub")

适合命令数量不多、强调命令可读性（能被直接朗读为英文指令）的场景。


---

**三、分类对比总览**


| 风格 | 结构 | 典型工具 | 适用场景 |
| --- | --- | --- | --- |
| POSIX 单命令 | `cmd  ` | `ls`、`grep`、`curl` | 功能单一的工具 |
| GNU 扩展 | `cmd --long-opt ` | `tar`、`find` | 通用 Unix 工具 |
| Git 动词优先 | `tool <verb> ` | `git`、`npm`、`cargo` | 动作多、资源少 |
| kubectl 动-名 | `tool <verb> <noun> ` | `kubectl`、`aws` | 多资源 × 多操作平台 |
| Docker 名-动 | `tool <noun> <verb> ` | `docker`、`podman` | 多资源对象管理 |
| Heroku 冒号 | `tool <noun:verb>` | `heroku`、`sf`（Salesforce CLI） | 深层命名空间 |
| CF 连字符 | `tool <verb-noun>` | `cf`、部分 Azure CLI | 命令数量有限的平台 |


**附录二：Help编写规范调研**

业界目前没有单一强制标准，但 (https://clig.dev "CLIG（Command Line Interface Guidelines）")、(https://developers.google.com/style/code-syntax "Google CLI 文档规范")和 (https://fuchsia.dev/fuchsia-src/development/api/cli_help "Fuchsia CLI Help Requirements") 对 Help 文档的要求高度一致，文档范以此为基础制定。

**脚注**：

 交易系统平台部-商品中心：美团/核心本地商业/业务研发平台/交易系统平台部/商品中心


