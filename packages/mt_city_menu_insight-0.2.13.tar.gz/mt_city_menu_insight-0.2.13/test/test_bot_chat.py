"""
test/test_bot_chat.py - 1024 Agent 机器人对话接口

接口文档：https://km.sankuai.com/collabpage/2749645045
API：POST https://reactmind.sankuai.com/openapi-v2/react/chat（非流式）

用法：
    # 单轮对话
    uv run python test/test_bot_chat.py "你好，介绍一下你自己"

    # 指定会话 ID（多轮对话）
    uv run python test/test_bot_chat.py "上面结果里排第一的品是什么" --conversation-id 20260408_xxx

    # 运行内置三轮测试
    uv run python test/test_bot_chat.py --test
"""

import sys
import httpx
import json
import argparse

API_URL = "https://reactmind.sankuai.com/openapi-v2/react/chat"
API_KEY = "rmk_ccafa8dc42904b4aaac1a06b57eb7d13"
MIS = "sunwantong"

# 内置测试的初始会话 ID
INIT_CONVERSATION_ID = "20260408_1775646132308_4c1afd6c"


def chat(message: str, conversation_id: str | None = None) -> tuple[str, str]:
    """
    发送一条消息，等待完整响应。
    返回 (完整回答文本, conversationId)
    """
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": API_KEY,
    }
    payload = {
        "contentList": [{"type": "TEXT", "content": message}],
        "mis": MIS,
    }
    if conversation_id:
        payload["conversationId"] = conversation_id

    resp = httpx.post(API_URL, headers=headers, json=payload, timeout=None)
    resp.raise_for_status()

    data = resp.json()
    result = data.get("result", {})
    full_answer = result.get("message", "")
    returned_conversation_id = result.get("conversationId", conversation_id or "")

    print(full_answer)
    return full_answer, returned_conversation_id


def run_test():
    """内置三轮对话测试"""
    print("=" * 60)
    print("1024 Agent 机器人对话测试")
    print(f"API Key: {API_KEY[:20]}...")
    print(f"MIS: {MIS}")
    print("=" * 60)

    conv_id = INIT_CONVERSATION_ID

    # 第一轮：打招呼
    print(f"\n{'='*60}")
    print(f"[用户] 你好，你是什么机器人？能简单介绍一下你的功能吗？")
    print(f"[conversationId] {conv_id}")
    print(f"[机器人]")
    _, conv_id = chat("你好，你是什么机器人？能简单介绍一下你的功能吗？", conversation_id=conv_id)
    print(f"[conversationId 返回] {conv_id}")

    # 第二轮：skill 调用
    print(f"\n{'='*60}")
    msg2 = "帮我用 tsp-ops-menu 工具查询杭州粉面粥饺品类的机会品清单，top 10，dt-window 用 1d"
    print(f"[用户] {msg2}")
    print(f"[conversationId] {conv_id}")
    print(f"[机器人]")
    _, conv_id = chat(msg2, conversation_id=conv_id)
    print(f"[conversationId 返回] {conv_id}")

    # 第三轮：多轮上下文
    print(f"\n{'='*60}")
    msg3 = "上面结果里排第一的品是什么？销量是多少？"
    print(f"[用户] {msg3}")
    print(f"[conversationId] {conv_id}")
    print(f"[机器人]")
    _, conv_id = chat(msg3, conversation_id=conv_id)
    print(f"[conversationId 返回] {conv_id}")

    print("\n" + "=" * 60)
    print("测试完成")
    print(f"最终 conversationId: {conv_id}")


def main():
    parser = argparse.ArgumentParser(description="1024 Agent 机器人对话命令行工具")
    parser.add_argument("message", nargs="?", help="发送给机器人的消息")
    parser.add_argument("--conversation-id", "-c", default=None, help="会话 ID（多轮对话时传入上一轮返回的 ID）")
    parser.add_argument("--test", action="store_true", help="运行内置三轮测试")
    args = parser.parse_args()

    if args.test:
        run_test()
        return

    if not args.message:
        parser.print_help()
        sys.exit(1)

    _, conv_id = chat(args.message, conversation_id=args.conversation_id)
    # 将 conversationId 输出到 stderr，方便脚本捕获
    print(f"conversationId: {conv_id}", file=sys.stderr)


if __name__ == "__main__":
    main()
