"""Mock mcpgateway.common package."""
