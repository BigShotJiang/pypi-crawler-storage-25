"""Mock mcpgateway.plugins package."""
