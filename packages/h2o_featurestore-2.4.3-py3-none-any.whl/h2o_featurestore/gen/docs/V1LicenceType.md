# V1LicenceType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | defaults to "LICENCE_TYPE_UNSPECIFIED",  must be one of ["LICENCE_TYPE_UNSPECIFIED", "LICENCE_TYPE_FEATURE_STORE", "LICENCE_TYPE_DRIVERLESS_AI", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


