import os
from os.path import expanduser

from jproperties import Properties


class ConfigUtils:
    INTERACTIVE_LOGGING = "progress.logging.console"
    INTERNAL_STORAGE_URI = "storage.internal.uri"
    _props = Properties()

    @staticmethod
    def collect_properties():
        file = ConfigUtils.get_properties_path()
        if not os.path.isfile(file):
            open(file, "a").close()
        with open(file, "rb") as f:
            ConfigUtils._props.load(f, "utf-8")
        return ConfigUtils._props

    @staticmethod
    def store_properties(props):
        with open(ConfigUtils.get_properties_path(), "wb") as f:
            props.store(f, encoding="utf-8")

    @staticmethod
    def delete_property(props, key):
        del props[key]
        ConfigUtils.store_properties(props)

    @staticmethod
    def store_property(props, key, value):
        props[key] = value
        ConfigUtils.store_properties(props)

    @staticmethod
    def set_property(props, key, value):
        props[key] = value
        ConfigUtils.store_properties(props)

    @staticmethod
    def get_property(key):
        return ConfigUtils._props[key].data

    @staticmethod
    def is_interactive_print_enabled():
        return (
            ConfigUtils._props.get(ConfigUtils.INTERACTIVE_LOGGING) is None
            or ConfigUtils._props[ConfigUtils.INTERACTIVE_LOGGING].data.lower() == "true"
        )

    @staticmethod
    def is_internal_storage_enabled():
        return (
            ConfigUtils._props.get(ConfigUtils.INTERNAL_STORAGE_URI) is not None
            and ConfigUtils._props[ConfigUtils.INTERNAL_STORAGE_URI].data.lower() == "true"
        )

    @staticmethod
    def get_properties_path():
        if os.environ.get("FEATURESTORE_USER_CONFIG") is not None:
            return os.environ.get("FEATURESTORE_USER_CONFIG")
        else:
            return expanduser("~") + os.path.sep + ".featurestore.config"
