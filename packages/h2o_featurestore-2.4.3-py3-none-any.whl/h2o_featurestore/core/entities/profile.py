from typing import List
from typing import Optional

from h2o_featurestore.gen.api.core_service_api import CoreServiceApi
from h2o_featurestore.gen.model.core_service_update_ingest_profile_request import (
    CoreServiceUpdateIngestProfileRequest,
)
from h2o_featurestore.gen.model.v1_service_account_mapping import (
    V1ServiceAccountMapping,
)

from ..utils import Utils


class IngestProfile:
    def __init__(self, stub: CoreServiceApi, profile):
        self._profile = profile
        self._stub = stub

    @property
    def id(self):
        return self._profile.id

    @property
    def name(self):
        return self._profile.name

    @property
    def display_name(self):
        return self._profile.display_name

    @property
    def assigned_oidc_roles_enabled(self):
        return self._profile.assigned_oidc_roles_enabled

    @property
    def assigned_oidc_roles(self):
        return self._profile.assigned_oidc_roles

    @property
    def created_at(self):
        return Utils.timestamp_to_string(self._profile.created_at)

    @property
    def updated_at(self):
        return Utils.timestamp_to_string(self._profile.updated_at)

    @property
    def service_account_mapping(self):
        if self._profile.service_account_mapping:
            return ServiceAccountMapping(self._profile.service_account_mapping)
        return None
    
    def update(
        self,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        assigned_oidc_roles_enabled: Optional[bool] = None,
        assigned_oidc_roles: Optional[List[str]] = None,
        service_account: Optional[str] = None,
        azure_client_id: Optional[str] = None,
        azure_tenant_id: Optional[str] = None,
    ):
        """Update an existing ingest profile as an administrator.

        Args:
            profile_id: (str) The ID of the profile to update.
            display_name: (str) Updated display name.
            description: (str) Updated description.
            assigned_oidc_roles_enabled: (bool) Whether OIDC role assignment is enabled.
            assigned_oidc_roles: (List[str]) Updated list of OIDC roles.
            service_account: (str) Updated service account.
            azure_client_id: (str) Updated Azure client ID.
            azure_tenant_id: (str) Updated Azure tenant ID.

        Returns:
            IngestProfile: The updated ingest profile.

        Typical example:
            client.admin_ingest_profiles.update(
                profile_id="profile-123",
                display_name="Updated Profile Name",
                description="Updated description"
            )
        """
        profile = CoreServiceUpdateIngestProfileRequest()
        field_mask = []

        if display_name is not None:
            profile.display_name = display_name
            field_mask.append("display_name")

        if description is not None:
            profile.description = description
            field_mask.append("description")

        if assigned_oidc_roles_enabled is not None:
            profile.assigned_oidc_roles_enabled = assigned_oidc_roles_enabled
            field_mask.append("assigned_oidc_roles_enabled")

        if assigned_oidc_roles is not None:
            profile.assigned_oidc_roles = assigned_oidc_roles
            field_mask.append("assigned_oidc_roles")

        if service_account is not None or azure_client_id is not None or azure_tenant_id is not None:
            service_account_mapping = self._profile.service_account_mapping
            field_mask.append("service_account_mapping")
            if not service_account_mapping:
                service_account_mapping = V1ServiceAccountMapping()
            if service_account is not None:
                service_account_mapping.service_account = service_account
            if azure_client_id is not None:
                service_account_mapping.azure_client_id = azure_client_id
            if azure_tenant_id is not None:
                service_account_mapping.azure_tenant_id = azure_tenant_id
            profile.service_account_mapping = service_account_mapping
        self._stub.core_service_update_ingest_profile(profile_id=self.id, update_mask=",".join(field_mask), profile=profile)
        self._refresh()

    def delete(self) -> None:
        """Delete this ingest profile.

        This method deletes the current ingest profile. After deletion, this object
        should not be used anymore.

        Typical example:
            profile = client.ingest_profiles.get("profile-123")
            profile.delete()
        """
        self._stub.core_service_delete_ingest_profile(id=self.id)

    def _refresh(self):
        response = self._stub.core_service_get_ingest_profile(id=self._profile.id)
        self._profile = response.profile

    def __repr__(self):
        return Utils.pretty_print_proto(self._profile)

    def __str__(self):
        return (
            f"ID           : {self.id} \n"
            f"Name         : {self.name} \n"
            f"Display Name : {self.display_name} \n"
            f"Created At   : {self.created_at} \n"
            f"Updated At   : {self.updated_at} \n"
        )

class ServiceAccountMapping:
    def __init__(self, mapping):
        self._mapping = mapping

    @property
    def service_account(self):
        return self._mapping.service_account

    @property
    def azure_client_id(self):
        return self._mapping.azure_client_id

    @property
    def azure_tenant_id(self):
        return self._mapping.azure_tenant_id

    def __repr__(self):
        return Utils.pretty_print_proto(self._mapping)

    def __str__(self):
        return (
            f"Service Account : {self.service_account} \n"
            f"Azure Client ID : {self.azure_client_id} \n"
            f"Azure Tenant ID : {self.azure_tenant_id} \n"
        )

    