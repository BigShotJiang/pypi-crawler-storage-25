import json

from h2o_featurestore.core.config_utils import ConfigUtils

from .base_job import BaseJob


class BatchRetrieveJob(BaseJob):
    def _response_method(self, job_id):
        response = self._stub.core_service_get_batch_retrieve_output(job_id=job_id.job_id, internal_uri=ConfigUtils.is_internal_storage_enabled())
        return response

    def __repr__(self):
        return json.dumps(
            {
                "job_id": self._job.job_id,
                "job_type": str(self._job.job_type),
                "job_done": bool(self._job.done),
                "child_job_ids": list(map(str, self._job.child_job_ids)),
            }
        )
