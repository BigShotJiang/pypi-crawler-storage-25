from typing import Iterator
from typing import List
from typing import Optional

from h2o_featurestore.gen.api.core_service_api import CoreServiceApi
from h2o_featurestore.gen.model.core_service_update_ingest_profile_request import (
    CoreServiceUpdateIngestProfileRequest,
)
from h2o_featurestore.gen.model.v1_create_ingest_profile_request import (
    V1CreateIngestProfileRequest,
)
from h2o_featurestore.gen.model.v1_profile import V1Profile
from h2o_featurestore.gen.model.v1_service_account_mapping import (
    V1ServiceAccountMapping,
)

from ..entities.profile import IngestProfile


class AdminIngestProfiles:
    def __init__(self, stub: CoreServiceApi):
        self._stub = stub

    def list(self) -> Iterator[IngestProfile]:
        """List all ingest profiles as an administrator.

        Returns:
            Iterator[IngestProfile]: A generator iterator object consists of ingest profiles.

        Typical example:
            client.admin_ingest_profiles.list()

        For more details:
            https://docs.h2o.ai/featurestore/api/admin_api.html#listing-ingest-profiles
        """
        response = self._stub.core_service_admin_list_ingest_profiles()
        for profile in response.profiles:
            yield IngestProfile(self._stub, profile)

    def create(
        self,
        name: str,
        display_name: str,
        description: str = "",
        assigned_oidc_roles_enabled: bool = False,
        assigned_oidc_roles: Optional[List[str]] = None,
        service_account: Optional[str] = None,
        azure_client_id: Optional[str] = None,
        azure_tenant_id: Optional[str] = None,
    ) -> IngestProfile:
        """Create a new ingest profile as an administrator.

        Args:
            name: (str) A unique name for the ingest profile.
            display_name: (str) A human-readable display name.
            description: (str) A description of the ingest profile.
            assigned_oidc_roles_enabled: (bool) Whether OIDC role assignment is enabled.
            assigned_oidc_roles: (List[str]) List of OIDC roles assigned to this profile.
            service_account: (str) Service account for the profile.
            azure_client_id: (str) Azure client ID for service account mapping.
            azure_tenant_id: (str) Azure tenant ID for service account mapping.

        Returns:
            IngestProfile: The newly created ingest profile.

        Typical example:
            client.admin_ingest_profiles.create(
                name="my-profile",
                display_name="My Profile",
                description="Profile for data ingestion"
            )
        """
        profile = V1Profile(
            name=name,
            display_name=display_name,
            description=description,
            assigned_oidc_roles_enabled=assigned_oidc_roles_enabled,
        )

        if assigned_oidc_roles:
            profile.assigned_oidc_roles = assigned_oidc_roles

        if service_account or azure_client_id or azure_tenant_id:
            service_account_mapping = V1ServiceAccountMapping(
                service_account=service_account or "",
                azure_client_id=azure_client_id or "",
                azure_tenant_id=azure_tenant_id or "",
            )
            profile.service_account_mapping = service_account_mapping

        request = V1CreateIngestProfileRequest(profile=profile)
        response = self._stub.core_service_create_ingest_profile(request)
        return IngestProfile(self._stub, response.profile)
