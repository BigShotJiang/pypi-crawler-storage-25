from typing import Iterator

from h2o_featurestore.gen.api.core_service_api import CoreServiceApi

from ..entities.profile import IngestProfile
from .admin_ingest_profiles import AdminIngestProfiles


class IngestProfiles:
    def __init__(self, stub: CoreServiceApi, admin: AdminIngestProfiles):
        self._stub = stub
        self.admin = admin

    def list(self) -> Iterator[IngestProfile]:
        """Return a generator which obtains the ingest profiles, lazily.

        Returns:
            Iterator[IngestProfile]: A generator iterator object consists of ingest profiles.

        Typical example:
            client.ingest_profiles.list()
        """
        response = self._stub.core_service_list_ingest_profiles()
        for profile in response.profiles:
            yield IngestProfile(self._stub, profile)

    def get(self, profile_id: str) -> IngestProfile:
        """Obtain a particular ingest profile.

        Args:
            profile_id: (str) A unique id of an ingest profile.

        Returns:
            IngestProfile: An ingest profile object.

        Typical example:
            client.ingest_profiles.get("profile_id")
        """
        response = self._stub.core_service_get_ingest_profile(id=profile_id)
        return IngestProfile(self._stub, response.profile)

    def __repr__(self):
        return "This class wraps together methods working with Ingest Profiles"
