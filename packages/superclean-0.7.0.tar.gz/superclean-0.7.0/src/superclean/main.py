import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from typing import Optional

from . import __version__
from .utils import format_size, parse_size
from .registry import get_registry, get_useful_tools
from .commands.status import show_status
from .commands.info import show_info
from .commands.check import run_check
from .commands.cron import manage_cron
from .commands.explore import run_explore
from .commands.projects import scan_projects

app = typer.Typer(help="Universal CLI tool to clean development caches.")
console = Console()


def version_callback(value: bool):
    if value:
        console.print(f"SuperClean version: [bold cyan]{__version__}[/bold cyan]")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show the version and exit.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-d",
        help="Preview changes without deleting any files.",
    ),
):
    """
    SuperClean (sclean) - Reclaim your disk space.
    """
    ctx.obj = {"dry_run": dry_run}
    if ctx.invoked_subcommand is None:
        console.print("[bold blue]SuperClean (sclean)[/bold blue]")
        if dry_run:
            console.print("[bold yellow][DRY RUN MODE][/bold yellow]")
        console.print("Use `sclean --help` for available commands.\n")
        list_cleaners(ctx)


@app.command()
def status(
    ctx: typer.Context,
    min_size: str = typer.Option(None, "--min-size", help="Only show cleaners if potential savings > threshold"),
):
    """Show a high-level dashboard of system health and potential savings."""
    registry = get_registry()
    show_status(registry, min_size, get_useful_tools())


@app.command()
def check():
    """Check if useful developer tools are installed and their versions."""
    run_check(get_useful_tools())


@app.command()
def info():
    """Show detailed system information."""
    show_info()


@app.command()
def list_cleaners(ctx: typer.Context):
    """List all available cleaners and potential space savings."""
    registry = get_registry()
    dry_run = ctx.obj.get("dry_run", False)
    title = "Available Cleaners"
    if dry_run:
        title += " [yellow](Dry Run Mode)[/yellow]"

    table = Table(title=title)
    table.add_column("App", style="cyan")
    table.add_column("Description", style="green")
    table.add_column("Potential Savings", justify="right", style="magenta")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Calculating space...", total=len(registry.get_all()))
        for cleaner in registry.get_all():
            space = cleaner.check_space()
            table.add_row(cleaner.name, cleaner.description, format_size(space))
            progress.advance(task)

    console.print(table)


@app.command()
def cron(
    ctx: typer.Context,
    install: bool = typer.Option(False, "--install", help="Install weekly cron job"),
    uninstall: bool = typer.Option(False, "--uninstall", help="Remove sclean cron job"),
):
    """Manage weekly maintenance automation (via crontab)."""
    manage_cron(install, uninstall)


@app.command()
def explore(path: str = typer.Argument(".", help="Directory to explore")):
    """Interactive disk usage explorer (ncdu-like)."""
    run_explore(path)


@app.command()
def projects(
    ctx: typer.Context,
    path: str = typer.Argument(".", help="Directory to scan"),
    delete: bool = typer.Option(False, "--delete", "-X", help="Delete found folders"),
    recursive: bool = typer.Option(True, help="Scan recursively"),
):
    """Scan for local project development folders (node_modules, venv, etc.) and optionally delete them."""
    dry_run = ctx.obj.get("dry_run", False)
    scan_projects(path, delete, recursive, dry_run)


@app.command()
def all(
    ctx: typer.Context,
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    interactive: bool = typer.Option(False, "--interactive", "-i", help="Select cleaners interactively"),
    min_size: str = typer.Option(None, "--min-size", help="Only clean if potential savings > threshold (e.g. 500MB)"),
):
    """Clean all detected application caches."""
    registry = get_registry()
    dry_run = ctx.obj.get("dry_run", False)
    threshold_bytes = parse_size(min_size) if min_size else 0

    cleaners_to_run = registry.get_all()

    # Pre-calculate space for threshold or interactive mode
    if interactive or threshold_bytes > 0:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Analyzing caches...", total=len(cleaners_to_run))
            valid_cleaners = []
            for cleaner in cleaners_to_run:
                space = cleaner.check_space()
                if space >= threshold_bytes:
                    valid_cleaners.append((cleaner, space))
                progress.advance(task)
            
            if interactive:
                import questionary
                choices = [
                    questionary.Choice(
                        title=f"{c.name} ({format_size(s)})",
                        value=c
                    ) for c, s in valid_cleaners
                ]
                if not choices:
                    console.print("[yellow]No cleaners found meeting the threshold.[/yellow]")
                    return
                
                selected = questionary.checkbox(
                    "Select cleaners to run:",
                    choices=choices,
                    default=[c.value for c in choices]
                ).ask()
                
                if not selected:
                    console.print("No cleaners selected. Aborting.")
                    return
                cleaners_to_run = selected
            else:
                cleaners_to_run = [c for c, s in valid_cleaners]

    if not cleaners_to_run:
        console.print("[yellow]No caches to clean based on current filters.[/yellow]")
        return

    if not force and not dry_run and not interactive:
        confirm = typer.confirm("Are you sure you want to clean all caches?")
        if not confirm:
            raise typer.Abort()

    if dry_run:
        console.print("[bold yellow][DRY RUN][/bold yellow] Previewing clean up...")

    total_reclaimed = 0
    for cleaner in cleaners_to_run:
        console.print(f"Cleaning [bold cyan]{cleaner.name}[/bold cyan]...")
        result = cleaner.clean(dry_run=dry_run)
        if result.success:
            total_reclaimed += result.space_reclaimed
            if result.message:
                console.print(f"  [dim]{result.message}[/dim]")
        else:
            console.print(f"  [bold red]Error:[/bold red] {result.message}")

    if dry_run:
        console.print(
            f"\n[bold yellow]Dry run complete.[/bold yellow] Estimated savings: [bold green]{format_size(total_reclaimed)}[/bold green]"
        )
    else:
        console.print(
            f"\n[bold green]Success![/bold green] Total reclaimed: [bold green]{format_size(total_reclaimed)}[/bold green]"
        )


@app.command()
def python(ctx: typer.Context):
    """Clean Python caches."""
    _clean_specific(ctx, "python")


@app.command()
def node(ctx: typer.Context):
    """Clean Node.js caches."""
    _clean_specific(ctx, "node")


@app.command()
def docker(ctx: typer.Context):
    """Clean Docker resources."""
    _clean_specific(ctx, "docker")


@app.command()
def nix(ctx: typer.Context):
    """Clean Nix garbage."""
    _clean_specific(ctx, "nix")


@app.command()
def system(ctx: typer.Context):
    """Clean system temp files."""
    _clean_specific(ctx, "system")


@app.command()
def brew(ctx: typer.Context):
    """Clean Homebrew versions."""
    _clean_specific(ctx, "brew")


@app.command()
def xcode(ctx: typer.Context):
    """Clean Xcode caches."""
    _clean_specific(ctx, "xcode")


@app.command()
def cargo(ctx: typer.Context):
    """Clean Cargo caches."""
    _clean_specific(ctx, "cargo")


@app.command()
def conda(ctx: typer.Context):
    """Clean Conda caches."""
    _clean_specific(ctx, "conda")


def _clean_specific(ctx: typer.Context, name: str):
    registry = get_registry()
    dry_run = ctx.obj.get("dry_run", False)
    cleaner = registry.get_by_name(name)
    if not cleaner:
        console.print(f"[bold red]Error:[/bold red] Cleaner '{name}' not found.")
        return

    if dry_run:
        console.print(
            f"[bold yellow][DRY RUN][/bold yellow] Previewing clean for [bold cyan]{cleaner.name}[/bold cyan]..."
        )
    else:
        console.print(f"Cleaning [bold cyan]{cleaner.name}[/bold cyan]...")

    result = cleaner.clean(dry_run=dry_run)
    if result.success:
        msg = (
            f"Reclaimed {format_size(result.space_reclaimed)}"
            if not dry_run
            else "Preview complete"
        )
        console.print(f"[bold green]Done![/bold green] {msg}")
        if result.message:
            console.print(f"  [dim]{result.message}[/dim]")
    else:
        console.print(f"[bold red]Failed:[/bold red] {result.message}")


if __name__ == "__main__":
    app()
