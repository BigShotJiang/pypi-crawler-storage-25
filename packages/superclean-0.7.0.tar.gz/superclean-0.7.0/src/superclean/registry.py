from .core import CleanerRegistry
from .cleaners.python_node import PythonCleaner, NodeCleaner
from .cleaners.docker_nix import DockerCleaner, NixCleaner
from .cleaners.system import SystemCleaner
from .cleaners.dev_tools import BrewCleaner, XcodeCleaner, CargoCleaner, CondaCleaner
from .cleaners.utilities import LazyGitCleaner, LazyDockerCleaner

def get_registry():
    registry = CleanerRegistry()
    registry.register(PythonCleaner())
    registry.register(NodeCleaner())
    registry.register(DockerCleaner())
    registry.register(NixCleaner())
    registry.register(SystemCleaner())
    registry.register(BrewCleaner())
    registry.register(XcodeCleaner())
    registry.register(CargoCleaner())
    registry.register(CondaCleaner())
    registry.register(LazyGitCleaner())
    registry.register(LazyDockerCleaner())
    return registry

def get_useful_tools():
    """List of tools to check for installation and version."""
    return [
        ("rg", "ripgrep"),
        ("uv", "uv"),
        ("lazygit", "lazygit"),
        ("lazydocker", "lazydocker"),
        ("fzf", "fzf"),
        ("gh", "GitHub CLI"),
        ("jq", "jq"),
        ("fd", "fd"),
        ("bat", "bat"),
        ("tldr", "tldr"),
    ]
