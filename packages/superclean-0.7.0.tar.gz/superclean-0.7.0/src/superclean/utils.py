import math
import re
import os
from typing import Optional

def format_size(size_bytes: int) -> str:
    if size_bytes == 0:
        return "0 B"
    size_name = ("B", "KB", "MB", "GB", "TB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

def parse_size(size_str: str) -> int:
    """Parse human readable size strings into bytes (e.g., 500MB, 1.2GB)."""
    if not size_str:
        return 0
    size_str = size_str.upper().strip()
    
    match = re.match(r"^([\d.]+)\s*([A-Z]+)$", size_str)
    if not match:
        try:
            return int(size_str) # Assume bytes if no unit
        except ValueError:
            return 0
            
    value = float(match.group(1))
    unit = match.group(2)
    
    units = {
        "B": 1,
        "K": 1024, "KB": 1024,
        "M": 1024**2, "MB": 1024**2,
        "G": 1024**3, "GB": 1024**3,
        "T": 1024**4, "TB": 1024**4,
    }
    
    return int(value * units.get(unit, 1))

def get_dir_size(path: str) -> int:
    """Helper to calculate directory size."""
    total = 0
    if not os.path.exists(path):
        return 0
    try:
        for entry in os.scandir(path):
            if entry.is_file():
                total += entry.stat().st_size
            elif entry.is_dir():
                total += get_dir_size(entry.path)
    except (PermissionError, OSError):
        pass
    return total
