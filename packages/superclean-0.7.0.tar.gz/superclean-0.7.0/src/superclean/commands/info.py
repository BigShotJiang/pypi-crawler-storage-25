import psutil
import platform
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from ..utils import format_size

console = Console()

def show_info():
    """Show detailed system information."""
    table = Table(title="System Information", show_header=False, box=None)
    table.add_column("Property", style="bold cyan")
    table.add_column("Value")

    # OS Info
    table.add_row("OS", f"{platform.system()} {platform.release()}")
    table.add_row("Machine", platform.machine())
    table.add_row("Processor", platform.processor())
    table.add_row("Python", platform.python_version())

    # CPU Info
    cpu_count = psutil.cpu_count(logical=False)
    logical_cpu = psutil.cpu_count(logical=True)
    table.add_row("CPU Cores", f"{cpu_count} physical, {logical_cpu} logical")
    table.add_row("CPU Usage", f"{psutil.cpu_percent(interval=0.1)}%")

    # Memory Info
    mem = psutil.virtual_memory()
    used_mem = mem.total - mem.available
    table.add_row("Memory Total", format_size(mem.total))
    table.add_row("Memory Used", f"{format_size(used_mem)} ({mem.percent}%)")
    table.add_row("Memory Free", format_size(mem.available))

    # Disk Info
    disk = psutil.disk_usage('/')
    table.add_row("Disk Total", format_size(disk.total))
    table.add_row("Disk Used", f"{format_size(disk.used)} ({disk.percent}%)")
    table.add_row("Disk Free", format_size(disk.free))

    console.print(Panel(table, expand=False, border_style="cyan"))
