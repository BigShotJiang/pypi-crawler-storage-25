# Command handlers for SuperClean
