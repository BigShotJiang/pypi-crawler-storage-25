import os
import shutil
import subprocess
import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils import format_size, get_dir_size

console = Console()

TARGET_NAMES = {
    "node_modules",
    "venv",
    ".venv",
    "__pycache__",
    "target",
    "build",
    "dist",
    ".next",
    ".svelte-kit",
    "bin",
    "obj",
}

def scan_projects(path: str = ".", delete: bool = False, recursive: bool = True, dry_run: bool = False):
    """Scan for local project development folders and optionally delete them."""
    found_folders = []
    abs_path = os.path.abspath(path)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task(f"Scanning {path}...", total=None)

        # Optimization: use 'fd' if available
        fd_path = shutil.which("fd")
        if fd_path and recursive:
            targets_regex = "|".join([f"^{n}$" for n in TARGET_NAMES])
            cmd = [fd_path, "-H", "-t", "d", targets_regex, abs_path]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, check=True)
                found_folders = [line.strip() for line in result.stdout.splitlines() if line.strip()]
            except subprocess.CalledProcessError:
                pass
        
        if not found_folders:
            for root, dirs, files in os.walk(abs_path):
                i = 0
                while i < len(dirs):
                    d = dirs[i]
                    if d in TARGET_NAMES:
                        full_path = os.path.join(root, d)
                        found_folders.append(full_path)
                        dirs.pop(i)
                    else:
                        i += 1
                if not recursive:
                    break
                progress.advance(task)

    if not found_folders:
        console.print("[yellow]No project development folders found.[/yellow]")
        return

    table = Table(title=f"Found Project Folders in {path}")
    table.add_column("Path", style="cyan")
    table.add_column("Size", justify="right", style="magenta")

    total_size = 0
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Calculating sizes...", total=len(found_folders))
        for p in found_folders:
            size = get_dir_size(p)
            total_size += size
            table.add_row(p, format_size(size))
            progress.advance(task)

    console.print(table)
    console.print(
        f"\nTotal potential savings: [bold green]{format_size(total_size)}[/bold green]"
    )

    if delete:
        if dry_run:
            console.print(
                "\n[bold yellow][DRY RUN][/bold yellow] Would delete all found folders."
            )
            return

        confirm = typer.confirm("\nAre you sure you want to delete all these folders?")
        if not confirm:
            raise typer.Abort()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Deleting...", total=len(found_folders))
            for p in found_folders:
                shutil.rmtree(p, ignore_errors=True)
                progress.advance(task)

        console.print("\n[bold green]Success![/bold green] All folders deleted.")
