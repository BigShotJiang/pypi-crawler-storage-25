import os
import shutil
import time
import typer
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils import format_size, get_dir_size

console = Console()

def run_explore(path: str = "."):
    """Interactive disk usage explorer (ncdu-like)."""
    current_path = os.path.abspath(path)
    
    while True:
        console.clear()
        console.print(Panel(f"[bold cyan]{current_path}[/bold cyan]", title="Exploring"))
        
        items = []
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
            ) as progress:
                task = progress.add_task("Scanning directory...", total=None)
                for entry in os.scandir(current_path):
                    size = entry.stat().st_size if entry.is_file() else get_dir_size(entry.path)
                    items.append({
                        "name": entry.name,
                        "path": entry.path,
                        "is_dir": entry.is_dir(),
                        "size": size
                    })
                    progress.advance(task)
        except PermissionError:
            console.print("[bold red]Permission Denied[/bold red]")
            time.sleep(1)
            current_path = os.path.dirname(current_path)
            continue

        # Sort by size descending
        items.sort(key=lambda x: x["size"], reverse=True)

        table = Table(box=None, expand=True)
        table.add_column("Type", width=6)
        table.add_column("Name", style="cyan")
        table.add_column("Size", justify="right", style="magenta")

        choices = []
        # Add "Go Back" if not at root
        if current_path != "/":
            choices.append(questionary.Choice(title=" .. (Go Back)", value="BACK"))
            table.add_row("DIR", "..", "")

        for item in items:
            type_str = "DIR" if item["is_dir"] else "FILE"
            table.add_row(type_str, item["name"], format_size(item["size"]))
            
            # Choice formatting
            prefix = "📁" if item["is_dir"] else "📄"
            choices.append(questionary.Choice(
                title=f"{prefix} {item['name']:<40} {format_size(item['size']):>10}",
                value=item
            ))

        console.print(table)
        choices.append(questionary.Choice(title="[Exit Explorer]", value="EXIT"))
        
        action = questionary.select(
            "Select an item to enter or manage:",
            choices=choices,
            style=questionary.Style([
                ('highlighted', 'fg:cyan bold'),
                ('pointer', 'fg:cyan bold'),
            ])
        ).ask()

        if action == "EXIT" or action is None:
            break
        elif action == "BACK":
            current_path = os.path.dirname(current_path)
        elif isinstance(action, dict):
            if action["is_dir"]:
                sub_action = questionary.select(
                    f"Action for {action['name']}:",
                    choices=[
                        questionary.Choice("Enter Directory", "ENTER"),
                        questionary.Choice(f"DELETE {action['name']}", "DELETE"),
                        "Cancel"
                    ]
                ).ask()
                
                if sub_action == "ENTER":
                    current_path = action["path"]
                elif sub_action == "DELETE":
                    if typer.confirm(f"Are you sure you want to delete {action['name']}?"):
                        shutil.rmtree(action["path"], ignore_errors=True)
            else:
                sub_action = questionary.select(
                    f"Action for {action['name']}:",
                    choices=[
                        questionary.Choice(f"DELETE {action['name']}", "DELETE"),
                        "Cancel"
                    ]
                ).ask()
                
                if sub_action == "DELETE":
                    if typer.confirm(f"Are you sure you want to delete {action['name']}?"):
                        os.remove(action["path"])
