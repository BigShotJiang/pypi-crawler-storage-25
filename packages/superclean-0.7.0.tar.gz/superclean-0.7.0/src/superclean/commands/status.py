import psutil
import platform
import shutil
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..utils import format_size, parse_size
from .. import __version__

console = Console()

def show_status(registry, min_size: str = None, useful_tools = None):
    """Show a high-level dashboard of system health and potential savings."""
    category_savings = {}
    total_savings = 0
    threshold_bytes = parse_size(min_size) if min_size else 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Analyzing system health...", total=len(registry.get_all()))
        for cleaner in registry.get_all():
            space = cleaner.check_space()
            if space >= threshold_bytes:
                cat = cleaner.category
                category_savings[cat] = category_savings.get(cat, 0) + space
                total_savings += space
            progress.advance(task)

    # Hero Panel
    console.print(
        Panel(
            f"[bold green]{format_size(total_savings)}[/bold green]",
            title="Total Potential Savings",
            subtitle="Run `sclean all` to reclaim",
            style="cyan",
        )
    )

    # Category Panels
    panels = []
    for cat, space in category_savings.items():
        color = "green" if space > 0 else "dim"
        panels.append(
            Panel(
                f"[bold {color}]{format_size(space)}[/bold {color}]",
                title=cat,
                border_style="blue",
            )
        )
    
    console.print(Columns(panels))

    # System Resources Panel
    try:
        cpu_usage = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        def get_bar(pct):
            filled = int(pct / 10)
            return f"[{'#' * filled}{' ' * (10 - filled)}] {pct}%"

        res_table = Table.grid(expand=True)
        res_table.add_column(style="cyan")
        res_table.add_column(justify="right")

        res_table.add_row("CPU Usage", get_bar(cpu_usage))
        res_table.add_row("RAM Usage", get_bar(mem.percent))
        res_table.add_row("Disk Usage", get_bar(disk.percent))

        # Tool Health check
        if useful_tools:
            installed_count = sum(1 for cmd, name in useful_tools if shutil.which(cmd))
            res_table.add_row("Toolbox", f"[bold green]{installed_count}/{len(useful_tools)}[/bold green] tools installed")

        console.print(Panel(res_table, title="System Resources & Tools", border_style="magenta"))
    except Exception:
        pass

    # System Info Footer
    sys_info = f"OS: [cyan]{platform.system()} {platform.release()}[/cyan] | SuperClean: [cyan]{__version__}[/cyan]"
    console.print(f"\n[dim]{sys_info}[/dim]")
