import shutil
import subprocess
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

def run_check(useful_tools):
    """Check if useful developer tools are installed and their versions."""
    table = Table(title="Developer Tools Health Check")
    table.add_column("Status", justify="center")
    table.add_column("Tool", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Version", style="magenta")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Checking tools...", total=len(useful_tools))
        
        for cmd, name in useful_tools:
            path = shutil.which(cmd)
            status = "[bold green]✅[/bold green]" if path else "[bold red]❌[/bold red]"
            version = "N/A"
            
            if path:
                try:
                    v_cmd = [cmd, "--version"]
                    proc = subprocess.run(v_cmd, capture_output=True, text=True, timeout=1)
                    if proc.returncode == 0:
                        version = proc.stdout.split('\n')[0].strip()
                        if len(version) > 40:
                            version = version[:37] + "..."
                except Exception:
                    version = "Found"

            table.add_row(status, cmd, name, version)
            progress.advance(task)

    console.print(table)
