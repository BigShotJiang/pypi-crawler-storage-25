import os
import sys
import shutil
import subprocess
from rich.console import Console

console = Console()

def manage_cron(install: bool = False, uninstall: bool = False):
    """Manage weekly maintenance automation (via crontab)."""
    sclean_path = shutil.which("sclean")
    if not sclean_path:
        sclean_path = os.path.abspath(sys.argv[0])

    cron_cmd = f"0 0 * * 0 {sclean_path} all --force > /dev/null 2>&1"
    
    try:
        current_cron = subprocess.check_output(["crontab", "-l"], text=True, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        current_cron = ""

    if uninstall:
        new_cron = "\n".join([line for line in current_cron.splitlines() if "sclean" not in line and "superclean" not in line])
        process = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
        process.communicate(input=new_cron)
        console.print("[bold green]Success![/bold green] sclean cron job removed.")
        return

    if install:
        if "sclean" in current_cron or "superclean" in current_cron:
            console.print("[yellow]sclean cron job is already installed.[/yellow]")
            return
        
        new_cron = current_cron.strip() + "\n" + cron_cmd + "\n"
        process = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
        process.communicate(input=new_cron)
        console.print("[bold green]Success![/bold green] Weekly cleanup scheduled (Sundays at midnight).")
        return

    # Default: view
    sclean_jobs = [line for line in current_cron.splitlines() if "sclean" in line or "superclean" in line]
    if sclean_jobs:
        console.print("[bold blue]Current sclean cron jobs:[/bold blue]")
        for job in sclean_jobs:
            console.print(f"  {job}")
    else:
        console.print("[yellow]No sclean cron jobs found.[/yellow]\nUse `sclean cron --install` to set up weekly cleanup.")
