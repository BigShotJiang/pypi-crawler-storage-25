# v3.1.0 — Product fixes + Context cache discovery

## Resumo

Correção dos 3 problemas críticos descobertos em produção real (sessão de teste no Copilot Chat com produto 10000 da MOOUI):

1. **`update_product_data` bugado** — fazia POST quando devia ser PUT, e endpoint errado. Tool nunca funcionou na prática.
2. **`update_product_price` exigia `valueType` mas não documentava** — gerava erro `EmptyField ValueType` em cada chamada.
3. **`context_cache` carregando vazio** — `priceTypes` e `costTypes` ficavam `[]`. LLM tinha que adivinhar tabelas existentes.

Bonus: `get_context` retornava 313KB (insustentável). Agora retorna ~5KB no modo slim.

## O que mudou

### Bug fixes

**`tools/product.py`:**
- `update_product_data` refatorado: agora auto-roteia entre `PUT /products/{code}/{branchCode}` (modo simples, validado pela MOOUI em produção) e `PUT /data` (modo batch com filtros).
- `update_product_price` mantido por compat, mas agora detecta `valueType` automaticamente. Sem `valueType`, assume `Price`. Aceita aliases `P`/`C`.

### Novas tools

**Preço/Custo separados:**
- `update_product_price_only` — injeta `valueType='Price'` automaticamente. Faz upsert (update→create).
- `update_product_cost` — injeta `valueType='Cost'`. Mesma lógica.

**Update de produto explícito:**
- `update_product_simple` — alias claro pro endpoint simples (PUT /products/{code}/{branchCode}).
- `update_product_branch_info_batch` — update em lote por filial via PUT /branch-info/{branchCode}.

### Context cache

**`context_cache.py` reescrito:**
- Descobre `priceTypes` e `costTypes` consultando os 20 produtos mais vendidos no último mês. Antes vinha vazio.
- `get_slim_context()` retorna ~5KB com top 5 de cada lista. `get_full_context()` mantém comportamento antigo.
- Carregamento resiliente: falha em um endpoint não impede outros.

**Tool `totvs_get_context`:**
- Novo parâmetro `verbose` (default `false`). Slim por padrão.

### Schemas enriquecidos

**`totvs_update_product_data`** ganhou todos os campos suportados pela API: `weight`, `ncmCode`, `cstCode`, `cestCode`, `prefixEanGtin`, `measuredUnit`, `isInactive`, `isFinishedProduct`, `isRawMaterial`, `isBulkMaterial`, `isOwnProduction`.

**`totvs_search_prices`** ganhou `filter.change` e `option.prices` (descobertos no script `consultar_precos.py` da MOOUI).

### Utility

**`tools/_value_types.py`** (novo): normaliza Price/Cost aceitando aliases `P`/`C`, variações de caixa, espaços. Compatibilidade com como os scripts MOOUI escrevem.

## Não quebra nada

Todas as tools existentes continuam funcionando. `update_product_price` ainda aceita os mesmos args, só ficou mais robusta.

## Testes

26 novos. Total do projeto: **117 tests passing**.

- 8 em `test_value_types.py`
- 11 em `test_product_v31.py`
- 7 em `test_context_cache.py`

## Validado em produção

Os endpoints e payloads foram validados contra os scripts reais da MOOUI:
- `alterar_peso.py` (PUT /products/{code}/{branchCode})
- `atualizar_precos_planilha.py` e `atualizar_precos_terminal.py` (POST /values/update + create fallback)
- `consultar_precos.py` (POST /prices/search com filter.change + option.prices)

## Migração

Sem ações necessárias além de aplicar os patches. Suas chamadas antigas continuam funcionando — só não vão mais dar erro.

## Ainda pendente (próxima fase v3.2 ou v3.3)

Os 18 endpoints faltantes do módulo `product` (`update_barcode`, `create_reference`, `create_grid`, `upsert_color`, etc.) ficam pra próxima fase. Esta v3.1 focou apenas no que estava quebrado.
