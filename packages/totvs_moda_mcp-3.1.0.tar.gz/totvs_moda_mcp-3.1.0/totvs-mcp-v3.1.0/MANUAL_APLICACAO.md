# Manual de aplicação v3.1.0

> Hotfix dos 3 problemas descobertos em produção + fix do context_cache.

## Resumo do que essa versão resolve

1. **Bug crítico** no `update_product_price`: faltava `valueType` obrigatório → erros 400 que vimos na sessão de teste
2. **Bug crítico** no `update_product_data`: era `POST` mas devia ser `PUT`, e endpoint errado → tool nunca funcionou
3. **Schemas pobres**: peso, NCM, CST, etc. não estavam no schema do `update_product_data`
4. **`context_cache` carregando vazio**: priceTypes/costTypes nunca eram populados
5. **`get_context` retornando 313KB**: insustentável pro LLM

---

## Pré-requisitos

```powershell
cd C:\Users\mooui\mcp-servers\totvs-moda-mcp
git status   # deve estar limpo
git checkout -b v3.1.0-fixes  # branch nova
PYTHONPATH=. python -m pytest tests/ -v   # 91 passing antes de começar
```

Se algum teste já estiver falhando, **resolver antes**.

---

## Etapa 1 — Adicionar arquivos novos

Do pacote v3.1.0:

```powershell
# Nova utility
Copy-Item .\v3.1.0_delivery\tools\_value_types.py tools\
# Tests novos
Copy-Item .\v3.1.0_delivery\tests\test_value_types.py tests\
Copy-Item .\v3.1.0_delivery\tests\test_product_v31.py tests\
Copy-Item .\v3.1.0_delivery\tests\test_context_cache.py tests\
# Context cache refatorado (ATENÇÃO: substitui o existente)
Copy-Item .\v3.1.0_delivery\context_cache.py . -Force
```

**Validar:**
```powershell
python -m py_compile tools\_value_types.py
python -m py_compile context_cache.py
PYTHONPATH=. python -m pytest tests\test_value_types.py tests\test_context_cache.py -v
```

Esperado: 15 testes passando (8 value_types + 7 context_cache).

---

## Etapa 2 — Atualizar `tools/product.py`

São **3 mudanças** no arquivo. Faça uma de cada vez e teste entre elas.

### 2a. Adicionar imports no topo

Localizar:
```python
from totvs_client import TotvsClient
```

Adicionar abaixo:
```python
from tools._defaults import inject_branch_defaults
from tools._value_types import normalize_value_type
```

### 2b. Refatorar `update_product_price` e adicionar 3 métodos novos

Localizar o método `update_product_price` atual (~linha 177) e SUBSTITUIR por:

```python
async def update_product_price(self, args: dict[str, Any]) -> Any:
    """⚠️ DEPRECATED em v3.1 — use update_product_price_only ou update_product_cost.

    Mantida por retrocompatibilidade. Detecta valueType e delega.
    Aceita aliases 'P'/'C' como atalhos de 'Price'/'Cost'.
    Sem valueType, assume 'Price' (default histórico).
    """
    args = dict(args)
    vt = normalize_value_type(args.get("valueType"))
    if vt == "Cost":
        return await self.update_product_cost(args)
    return await self.update_product_price_only(args)

async def update_product_price_only(self, args: dict[str, Any]) -> Any:
    """POST /values/update — ⚠️ Atualiza PREÇO DE VENDA. valueType='Price' injetado.

    Faz upsert: tenta UPDATE; se NotFound, faz CREATE.
    """
    return await self._upsert_product_value(args, value_type="Price")

async def update_product_cost(self, args: dict[str, Any]) -> Any:
    """POST /values/update — ⚠️ Atualiza CUSTO. valueType='Cost' injetado.

    Faz upsert: tenta UPDATE; se NotFound, faz CREATE.
    """
    return await self._upsert_product_value(args, value_type="Cost")

async def _upsert_product_value(self, args: dict[str, Any], value_type: str) -> Any:
    """Helper interno para upsert de Price ou Cost.

    Força valueType ao tipo passado (sobrescreve qualquer coisa que vier).
    """
    args = inject_branch_defaults(args)
    branch = args.get("branchCode")

    if args.get("products"):
        products = args["products"]
        for p in products:
            for v in p.get("values", []):
                v["valueType"] = value_type
                if "branchCode" not in v and branch is not None:
                    v["branchCode"] = branch
    else:
        if not all(k in args for k in ("productCode", "valueCode", "value")):
            raise ValueError(
                "Modo simples requer productCode, valueCode e value. "
                "Para lote use products=[{productCode, values:[...]}]"
            )
        products = [{
            "productCode": args["productCode"],
            "values": [{
                "branchCode": branch,
                "valueType": value_type,
                "valueCode": args["valueCode"],
                "value": args["value"],
            }]
        }]

    body = {"products": products}
    return await self.client.upsert(
        update_path=f"{BASE}/values/update",
        create_path=f"{BASE}/values/create",
        body=body,
    )
```

**Testar:**
```powershell
python -m py_compile tools\product.py
PYTHONPATH=. python -m pytest tests\test_product_v31.py::test_update_price_only_injects_Price tests\test_product_v31.py::test_update_cost_injects_Cost -v
```

### 2c. Refatorar `update_product_data` e adicionar 2 métodos novos

Localizar o método `update_product_data` atual (~linha 199) e SUBSTITUIR por:

```python
async def update_product_data(self, args: dict[str, Any]) -> Any:
    """⚠️ Atualiza dados de produto (peso, NCM, CST, etc).

    Auto-roteamento:
    - Se passar productCode (singular) → PUT /products/{code}/{branchCode} (simples)
    - Se passar productCodeList ou outros filtros → PUT /data (lote)

    Endpoint simples valida em produção pela MOOUI (alterar_peso.py).
    """
    args = inject_branch_defaults(args)

    # Modo simples
    if args.get("productCode") and not args.get("productCodeList"):
        code = args["productCode"]
        branch = args["branchCode"]
        excluded = {"productCode", "branchCode", "productCodeList",
                   "barCodeList", "groupCode", "referenceCode"}
        body = {k: v for k, v in args.items()
                if k not in excluded and v is not None}
        return await self.client.put(
            f"{BASE}/products/{code}/{branch}", body
        )

    # Modo batch
    filter_keys = {"productCodeList", "barCodeList",
                   "groupCode", "referenceCode"}
    flt = {}
    payload = {}
    for k, v in args.items():
        if v is None:
            continue
        if k == "branchCode":
            continue
        if k in filter_keys:
            flt[k] = v
        else:
            payload[k] = v

    if not flt:
        raise ValueError(
            "Modo batch requer pelo menos um filtro: "
            "productCodeList, barCodeList, groupCode ou referenceCode."
        )

    body = {"filter": flt, **payload}
    return await self.client.put(f"{BASE}/data", body)

async def update_product_simple(self, args: dict[str, Any]) -> Any:
    """PUT /products/{code}/{branchCode} — ⚠️ Update unitário simples.

    Endpoint validado pela MOOUI em produção.
    """
    args = inject_branch_defaults(args)
    if not args.get("productCode"):
        raise ValueError("update_product_simple requer productCode.")

    code = args["productCode"]
    branch = args["branchCode"]
    excluded = {"productCode", "branchCode", "productCodeList"}
    body = {k: v for k, v in args.items()
            if k not in excluded and v is not None}

    return await self.client.put(f"{BASE}/products/{code}/{branch}", body)

async def update_product_branch_info_batch(self, args: dict[str, Any]) -> Any:
    """PUT /branch-info/{branchCode} — ⚠️ Atualização em lote por filial."""
    args = inject_branch_defaults(args)
    branch = args["branchCode"]

    filter_keys = {"productCodeList", "barCodeList",
                   "groupCode", "referenceCode"}
    flt = {}
    payload = {}
    for k, v in args.items():
        if v is None:
            continue
        if k in ("branchCode",):
            continue
        if k in filter_keys:
            flt[k] = v
        else:
            payload[k] = v

    if not flt:
        raise ValueError(
            "update_product_branch_info_batch requer pelo menos um "
            "filtro: productCodeList, barCodeList, groupCode ou referenceCode."
        )

    body = {"filter": flt, **payload}
    return await self.client.put(f"{BASE}/branch-info/{branch}", body)
```

**Testar:**
```powershell
PYTHONPATH=. python -m pytest tests\test_product_v31.py -v
```

Esperado: 11 testes passando.

---

## Etapa 3 — Atualizar `server.py`

Abrir o arquivo `SCHEMAS.txt` do pacote v3.1.0 — contém os schemas prontos.

Aplicar **6 mudanças** seguindo o que está no SCHEMAS.txt:

1. **SUBSTITUIR** schema de `totvs_update_product_price`
2. **ADICIONAR** schema de `totvs_update_product_price_only`
3. **ADICIONAR** schema de `totvs_update_product_cost`
4. **SUBSTITUIR** schema de `totvs_update_product_data`
5. **ADICIONAR** schema de `totvs_update_product_simple`
6. **ADICIONAR** schema de `totvs_update_product_branch_info_batch`
7. **SUBSTITUIR** schema de `totvs_search_prices`
8. **SUBSTITUIR** schema de `totvs_get_context`

**No ROUTING dict, ADICIONAR:**

```python
"totvs_update_product_price_only":         ("product", "update_product_price_only"),
"totvs_update_product_cost":               ("product", "update_product_cost"),
"totvs_update_product_simple":             ("product", "update_product_simple"),
"totvs_update_product_branch_info_batch":  ("product", "update_product_branch_info_batch"),
```

**No handler de `totvs_get_context`** (procurar onde a tool é tratada na função call_tool), substituir pra:

```python
elif name == "totvs_get_context":
    if args.get("verbose"):
        result = context_cache.get_full_context()
    else:
        result = context_cache.get_slim_context()
    return [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False, default=str))]
```

**Atualizar versão:**
- Linha do logger: `"TOTVS Moda MCP Server v3.1 — ..."`
- `InitializationOptions(server_version="3.1.0", ...)`

---

## Etapa 4 — Atualizar `pyproject.toml`

```toml
version = "3.1.0"
```

---

## Etapa 5 — Atualizar `CHANGELOG.md`

Adicionar no topo:

```markdown
## [3.1.0] — 2026-04-25

### Corrigido
- `update_product_data` estava com bug crítico: usava POST quando devia ser PUT, e endpoint errado. Tool nunca funcionou. Refatorada com auto-roteamento (simples vs batch).
- `update_product_price` exigia `valueType` mas não documentava no schema. Adicionado fallback pra Price quando omitido. Aliases P/C aceitos.

### Adicionado
- `tools/_value_types.py` — normalização de Price/Cost com aliases P/C.
- `update_product_price_only` — atualiza preço com valueType='Price' injetado.
- `update_product_cost` — atualiza custo com valueType='Cost' injetado.
- `update_product_simple` — alias claro pro PUT /products/{code}/{branchCode}.
- `update_product_branch_info_batch` — update em lote por filial.
- Schema enriquecido de `update_product_data` (weight, ncmCode, CST, flags).
- Schema enriquecido de `search_prices` (filter.change, option.prices, digitalPromotionPrices).

### Mudado
- `context_cache.py` agora descobre `priceTypes` e `costTypes` reais via top 20 produtos vendidos. Antes vinha vazio.
- `get_context` ganhou parâmetro `verbose` (default false). Slim mode retorna ~5KB; verbose retorna cache completo.
- Carregamento do cache agora é resiliente: falha em um endpoint não impede os outros.

### Testes
- 26 testes novos. Total do projeto: 117.
```

---

## Etapa 6 — Reinstalar e validar

```powershell
pip install -e .
pip show totvs-moda-mcp   # Version: 3.1.0

PYTHONPATH=. python -m pytest tests/ -v
```

Esperado: **117 passed** (91 antigos + 26 novos).

---

## Etapa 7 — Reiniciar VS Code

Fechar completamente e reabrir.

---

## Etapa 8 — Validação no Copilot Chat (Agent mode)

### Validar slim context

```
Pergunta: "Mostra o contexto da empresa (slim)"
Esperado: resposta pequena com branches, priceTypes, costTypes,
top 5 operations, top 5 paymentConditions.
Tamanho: ~3-8KB, não 313KB.
```

### Validar discovery de priceTypes

```
Verificar que priceTypes não está vazio
Esperado: pelo menos 1 entrada como {"priceCode": 1, "priceName": "VENDA VAREJO BR"}
Se vier vazio, é porque os 20 produtos top do mês não têm preço cadastrado
(improvável). Caso contrário, hipóteses:
- Endpoint /prices/search com problema → testar manual via consultar_precos.py
- Sem pedidos no último mês → ajustar período de busca em context_cache.py
```

### Validar update de peso

```
Pergunta: "Atualiza o peso do produto 10000 para 1.5kg"
Esperado: resposta de sucesso, sem erros 400.
LLM deve usar totvs_update_product_simple ou totvs_update_product_data
(ambos vão pro mesmo endpoint internamente).
```

### Validar update de preço

```
Pergunta: "Atualiza o preço de venda do produto 10000 valueCode 1 para 357.50"
Esperado: LLM usa totvs_update_product_price_only.
Não deve dar EmptyField ValueType (porque é injetado automático).
```

### Validar update de custo

```
Pergunta: "Atualiza o custo do produto 10000 valueCode 1 para 200"
Esperado: LLM usa totvs_update_product_cost.
```

---

## Etapa 9 — Commit e tag

```powershell
git add tools/_value_types.py tools/product.py
git add tests/test_value_types.py tests/test_product_v31.py tests/test_context_cache.py
git add context_cache.py server.py pyproject.toml CHANGELOG.md

git commit -m "v3.1.0: fix product update bugs + context_cache discovery

- update_product_data was POST/wrong endpoint - fixed to PUT with auto-routing
- update_product_price required undocumented valueType - now injected by
  new tools update_product_price_only and update_product_cost
- context_cache now discovers priceTypes/costTypes via top 20 sold products
- get_context now defaults to slim mode (~5KB instead of 313KB)
- Added 26 tests, total 117"

git push origin v3.1.0-fixes

# Merge na main
git checkout main
git merge v3.1.0-fixes
git push origin main
git tag v3.1.0
git push origin v3.1.0
```

---

## Etapa 10 — Publicar no PyPI (opcional)

```powershell
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue
hatch build
twine check dist/*
twine upload dist/*
```

---

## Tempo estimado

45-60 minutos (mecânico mas atento aos detalhes do server.py).

## Se algo der errado

**Teste falhando em test_context_cache:** seu `context_cache.py` antigo tinha estrutura diferente. Revisar.

**Erro de import circular:** o `tools/_defaults.py` faz lazy import de `context_cache`. Se quebrar, é problema do _defaults — verificar que está fazendo `import context_cache` lazy dentro da função.

**`get_context` ainda retornando 313KB:** o handler no server.py não está chamando `get_slim_context()`. Conferir Etapa 3.

**`priceTypes` continua vazio mesmo após v3.1:** seus pedidos top do mês não têm preço cadastrado, ou os endpoints `/prices/search` retornam erro. Olhar logs.
