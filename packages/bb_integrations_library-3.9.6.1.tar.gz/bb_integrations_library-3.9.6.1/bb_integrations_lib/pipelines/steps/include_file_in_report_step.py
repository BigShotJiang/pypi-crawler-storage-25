from io import BytesIO

from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import RawData


class IncludeFileInReportStep(Step):
    def describe(self) -> str:
        return "Include file in process report"

    async def execute(self, i: RawData | list[RawData]) -> RawData | list[RawData]:
        for item in i if isinstance(i, list) else [i]:
            content = item.data.getvalue() if isinstance(item.data, BytesIO) else item.data
            if isinstance(content, bytes):
                content = content.decode("utf-8", errors="replace")
            self.pipeline_context.included_files[item.file_name] = content
        return i