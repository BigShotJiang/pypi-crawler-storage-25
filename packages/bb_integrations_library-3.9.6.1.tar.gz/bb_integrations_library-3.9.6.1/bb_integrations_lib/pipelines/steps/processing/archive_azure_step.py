import os
import uuid
from io import BytesIO

import pandas as pd
from azure.storage.blob import ContentSettings
from azure.storage.blob.aio import ContainerClient
from loguru import logger

from bb_integrations_lib.models.pipeline_structs import BolExportResults
from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import RawData, FileConfigRawData


class ArchiveAzureBlobStep(Step):
    def __init__(
        self,
        container: ContainerClient,
        prefix: str = "",
        field_sep: str = ",",
        content_type: str = "",
        error_on_exists: bool = False,
        *args,
        **kwargs,
    ) -> None:
        """
        Archive a file (RawData or BolExportResults) to an Azure Blob Storage container.

        :param container: An azure-storage-blob async ContainerClient, already scoped
          to the target container by its SAS URL.
        :param prefix: Optional path prefix inside the container. If a FileConfigRawData
          is passed to the step, the source_system is appended to the prefix, before the
          file name. (prefix/source_system/file_name)
        :param field_sep: Field separator when uploading BolExportResults.
        :param content_type: Optional - explicitly specify the content type of the file.
        :param error_on_exists: Whether to raise an exception if the blob exists.
        """
        super().__init__(*args, **kwargs)

        self.container = container
        self.prefix = prefix.strip("/")
        self.field_sep = field_sep
        self.content_type = content_type
        self.error_on_exists = error_on_exists

    def describe(self):
        return "Archiving file in Azure Blob Storage"

    async def execute(
        self, i: RawData | FileConfigRawData | BolExportResults
    ) -> RawData:
        def blob_path(base_name: str) -> str:
            parts = [p for p in [self.prefix] if p]
            if isinstance(i, FileConfigRawData):
                parts.append(i.file_config.source_system)
            parts.append(base_name)
            return "/".join(parts)

        # Will be used to change the name if a duplicate is detected.
        # Don't want to change it directly on the original object because that str will get used by later steps.
        file_name = i.file_name

        if isinstance(i, BolExportResults):
            df = pd.DataFrame.from_records(i.orders)
            csv_text = df.to_csv(index=False, sep=self.field_sep)
            self.content_type = (
                "text/csv" if not self.content_type else self.content_type
            )
            contents = csv_text.encode("utf-8")
        else:
            contents = i.data

        if isinstance(contents, BytesIO):
            contents = contents.getvalue()

        if await self.container.get_blob_client(blob_path(file_name)).exists():
            if self.error_on_exists:
                raise Exception(
                    f"Blob '{self.container.container_name}/{blob_path(file_name)}' already exists"
                )
            old_file_name = file_name
            file_name = f"DUPLICATE_{uuid.uuid4()}_{file_name}"
            logger.debug(
                f"Blob named '{old_file_name}' already exists; archiving '{file_name}' to Azure (backup attempt)"
            )
        else:
            logger.debug(f"Archiving '{file_name}' to Azure")

        kwargs = {}
        if self.content_type:
            kwargs["content_settings"] = ContentSettings(content_type=self.content_type)

        await self.container.upload_blob(
            name=blob_path(file_name),
            data=contents or b"",
            overwrite=False,
            **kwargs,
        )

        return i
