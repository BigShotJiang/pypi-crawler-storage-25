from typing import Any, AsyncIterator, Optional

from azure.storage.blob.aio import ContainerClient
from loguru import logger

from bb_integrations_lib.protocols.pipelines import GeneratorStep
from bb_integrations_lib.shared.model import RawData


class DownloadAzureBlobsStep(GeneratorStep):
    def __init__(
        self,
        container: ContainerClient,
        prefix: str = "",
        extension: Optional[str] = None,
        *args,
        **kwargs,
    ) -> None:
        """
        List and download every blob in an Azure Blob Storage "directory" (prefix)
        and yield one ``RawData`` per blob.

        :param container: An azure-storage-blob async ContainerClient, already scoped
          to the target container by its SAS URL. Needs SAS permissions ``r`` and ``l``.
        :param prefix: The virtual directory inside the container to scan, e.g.
          ``"inbox/"`` or ``"exports/2026/"``. An empty string lists the whole container.
        :param extension: Optional case-insensitive extension filter (e.g. ``".csv"``).
          When set, only blobs whose name ends with this extension are downloaded.
        """
        super().__init__(*args, **kwargs)
        self.container = container
        self.prefix = prefix
        self.extension = extension.lower() if extension else None

    def describe(self) -> str:
        return f"Downloading Azure blobs from '{self.prefix}'"

    async def generator(self, i: Any) -> AsyncIterator[RawData]:
        matched = 0
        total = 0
        async for blob in self.container.list_blobs(name_starts_with=self.prefix or None):
            total += 1
            if self.extension and not blob.name.lower().endswith(self.extension):
                logger.debug(
                    f"Skipping '{blob.name}': does not end with '{self.extension}'"
                )
                continue
            logger.info(f"Downloading '{blob.name}' ({blob.size} bytes)")
            stream = await self.container.get_blob_client(blob.name).download_blob()
            data = await stream.readall()
            matched += 1
            yield RawData(file_name=blob.name, data=data)

        logger.info(
            f"Downloaded {matched}/{total} blob(s) from '{self.container.container_name}/{self.prefix}'"
        )
