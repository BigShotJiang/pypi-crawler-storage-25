import json
from typing import Callable, override

from bb_integrations_lib.gravitate.sd_api import GravitateSDAPI
from bb_integrations_lib.models.pipeline_structs import NoPipelineData
from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import GetFreightInvoicesRequest
from loguru import logger


class GetFreightInvoicesStep(Step):
    """Fetch freight invoices from S&D, optionally filtering with a custom filter."""

    @override
    def __init__(
        self,
        sd_client: GravitateSDAPI,
        freight_payload: GetFreightInvoicesRequest,
        invoice_filter: Callable[[list[dict]], list[dict]] | None = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.sd_client = sd_client
        self.freight_payload = freight_payload
        self.invoice_filter = invoice_filter

    def describe(self) -> str:
        return "Fetch freight invoices from S&D"

    async def execute(self, i: None) -> list[dict]:
        invoices = await self.get_invoices()
        if not invoices:
            raise NoPipelineData("No freight invoices to export")

        if self.invoice_filter:
            logger.info("Filtering freight invoices")
            invoices = self.invoice_filter(invoices)
            if not invoices:
                raise NoPipelineData("No freight invoices after filtering")

        self.pipeline_context.included_files["freight response"] = json.dumps(invoices)

        logger.info(f"Fetched {len(invoices)} freight invoices")
        return invoices

    async def get_invoices(self) -> list[dict]:
        try:
            payload = self.freight_payload.model_dump(mode="json")
            resp = await self.sd_client.get_freight_invoices(self.freight_payload)
            resp.raise_for_status()
            self.pipeline_context.included_files["freight payload"] = json.dumps(
                payload
            )
            return resp.json()
        except Exception as e:
            logger.error(f"Failed to fetch freight invoices: {e}")
            raise NoPipelineData(str(e))
