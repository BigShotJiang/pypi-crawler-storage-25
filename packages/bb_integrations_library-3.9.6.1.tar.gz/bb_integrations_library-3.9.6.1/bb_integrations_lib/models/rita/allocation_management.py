from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class DirectiveStatus(str, Enum):
    incomplete = "incomplete"
    complete = "complete"
    synced = "synced"


class SDReference(BaseModel):
    id: str
    name: str


class GroupBase(BaseModel):
    source_system: str
    source_id: str
    name: str
    members: list[SDReference] = Field(default_factory=list)


class Directive(BaseModel):
    id: str | None = None
    name: str
    terminal_ids: list[str] | None = None
    product_ids: list[str] | None = None
    supplier_ids: list[str] | None = None
    contract_id: str | None = None
    sd_directive_id: str | None = None


class ResolvedDirective(Directive):
    effective_terminals: list[SDReference] = Field(default_factory=list)
    effective_products: list[SDReference] = Field(default_factory=list)
    effective_suppliers: list[SDReference] = Field(default_factory=list)
    status: DirectiveStatus = DirectiveStatus.incomplete
    orphaned_terminal_ids: list[str] = Field(default_factory=list)
    orphaned_product_ids: list[str] = Field(default_factory=list)
    orphaned_supplier_ids: list[str] = Field(default_factory=list)


class ExternalAllocationBase(BaseModel):
    source_system: str
    allocation_id: str
    name: str
    consignee: str
    supplier: str
    terminal: str
    terminal_source_id: str
    product_group: str
    product_group_source_id: str
    supplier_source_id: str | None = None
    directives: list[Directive] = Field(default_factory=list)


class ExternalAllocationResponse(ExternalAllocationBase):
    id: str
    directives: list[ResolvedDirective] = Field(default_factory=list)
    linked: bool = False
    linked_to: int = 0
    created_on: datetime | None = None
    updated_on: datetime | None = None


class SyncError(BaseModel):
    source_system: str
    source_id: str | None = None
    allocation_id: str | None = None
    error: str


class SyncResult(BaseModel):
    created: int = 0
    updated: int = 0
    unchanged: int = 0
    errors: list[SyncError] = Field(default_factory=list)


class BulkSetSDDirectiveIdItem(BaseModel):
    id: str
    directive_id: str
    sd_directive_id: str


class BulkSetSDDirectiveIdError(BaseModel):
    id: str
    directive_id: str
    error: str


class BulkSetSDDirectiveIdResult(BaseModel):
    updated: int = 0
    unchanged: int = 0
    errors: list[BulkSetSDDirectiveIdError] = Field(default_factory=list)
