"""Modal Cloud GPU worker for maestro-economics jobs."""

from __future__ import annotations

import json
import shutil
import time
import traceback
import zipfile
from pathlib import Path
from typing import Any

import modal

from maestro_economics.runtime.handler import _CancelledError, execute_job

economics_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "jax[cuda12]==0.5.0",
        "jaxlib==0.5.0",
        "jaxopt>=0.8",
        "numpy>=1.26",
        "pandas>=2.2",
        "scipy>=1.12",
        "pyarrow>=15.0",
        "cma>=4.0",
        "httpx>=0.27",
        "fastapi[standard]",
        "statsmodels>=0.14",
        "scikit-learn>=1.4",
        "duckdb>=0.10",
        "matplotlib>=3.8",
    )
    .add_local_python_source("maestro_economics")
)

r2_bucket = modal.CloudBucketMount(
    bucket_name="ra-compute-prod",
    bucket_endpoint_url="https://4a6e409c279e108484bed901bf0f2ddb.r2.cloudflarestorage.com",
    secret=modal.Secret.from_name("r2-credentials"),
)

app = modal.App("maestro-economics", image=economics_image)

R2_MOUNT = Path("/r2")
LOCAL_WORK = Path("/tmp/mecon_job")

GPU_SPECS: dict[str, tuple[str, float]] = {
    "T4": ("T4", 16.0),
    "L4": ("L4", 24.0),
    "A10G": ("A10G", 24.0),
    "L40S": ("L40S", 48.0),
    "A100": ("A100", 80.0),
    "H100": ("H100", 80.0),
}


def _report_status(
    callback_url: str,
    job_id: str,
    status: str,
    progress: float = 0.0,
    message: str = "",
    gpu_seconds: float | None = None,
    result: dict[str, Any] | None = None,
    error: str | None = None,
) -> None:
    import httpx

    payload: dict[str, Any] = {
        "job_id": job_id,
        "status": status,
        "progress": progress,
        "message": message,
    }
    if result is not None:
        payload["result"] = result
    if gpu_seconds is not None:
        payload["gpu_seconds"] = gpu_seconds
    if error is not None:
        payload["error"] = error

    try:
        httpx.post(callback_url, json=payload, timeout=30)
    except Exception:
        pass


def _run_job(payload: dict[str, Any]) -> dict[str, Any]:
    job_id: str = payload["job_id"]
    callback_url: str = payload["callback_url"]
    gpu_type: str = payload.get("gpu_type", "L4")
    timeout_sec: int = payload.get("timeout", 3600)
    config: dict[str, Any] = payload.get("config", {})

    _, gpu_memory = GPU_SPECS.get(gpu_type, ("L4", 24.0))

    r2_uploads = R2_MOUNT / "uploads" / job_id
    local_code = LOCAL_WORK / "code"
    if local_code.exists():
        shutil.rmtree(local_code)
    local_code.mkdir(parents=True, exist_ok=True)

    _report_status(callback_url, job_id, "downloading", 0.0, "Loading code from R2")

    workspace_path = payload.get("workspace_path")
    r2_run_history = None
    script_path = local_code / "run.py"
    data_dir = local_code / "data"
    data_dir.mkdir(parents=True, exist_ok=True)

    if workspace_path:
        r2_workspace = R2_MOUNT / workspace_path
        entry = config.pop("entry", "run.py")
        for file in r2_workspace.rglob("*"):
            if file.is_file():
                rel = file.relative_to(r2_workspace)
                if str(rel).startswith("output"):
                    continue
                if file.suffix in (".py", ".json", ".yaml", ".toml", ".txt"):
                    dest = local_code / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(file, dest)
        script_path = local_code / entry
        ws_data = r2_workspace / "data"
        if ws_data.exists() and any(ws_data.iterdir()):
            data_dir = ws_data
        import datetime as dt

        ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
        r2_output = r2_workspace / "output"
        r2_output.mkdir(parents=True, exist_ok=True)
        r2_run_history = r2_workspace / "runs" / f"{ts}_{job_id[:8]}"
        r2_run_history.mkdir(parents=True, exist_ok=True)
        r2_checkpoints = r2_workspace / "checkpoints"
        r2_checkpoints.mkdir(parents=True, exist_ok=True)
        r2_logs = r2_workspace / "logs"
        r2_logs.mkdir(parents=True, exist_ok=True)
        meta = {"job_id": job_id, "gpu_type": gpu_type, "timeout": timeout_sec, "config": config}
        (r2_run_history / "meta.json").write_text(json.dumps(meta, indent=2))
    else:
        r2_job = R2_MOUNT / "jobs" / job_id
        r2_output = r2_job / "output"
        r2_checkpoints = r2_job / "checkpoints"
        r2_logs = r2_job / "logs"
        for directory in (r2_output, r2_checkpoints, r2_logs):
            directory.mkdir(parents=True, exist_ok=True)
        meta = {"job_id": job_id, "gpu_type": gpu_type, "timeout": timeout_sec, "config": config}
        (r2_job / "meta.json").write_text(json.dumps(meta, indent=2))

        zip_file = None
        script_file = None
        if r2_uploads.exists():
            for file in r2_uploads.iterdir():
                if file.suffix == ".zip":
                    zip_file = file
                elif file.suffix == ".py":
                    script_file = file

        if zip_file:
            with zipfile.ZipFile(zip_file, "r") as archive:
                archive.extractall(local_code)
            entry = config.pop("entry", "run.py")
            entry_path = local_code / entry
            if not entry_path.exists():
                py_files = list(local_code.rglob("*.py"))
                raise ValueError(f"Entry point '{entry}' not found. Files: {py_files}")
            script_path = entry_path
            proj_data = local_code / "data"
            if proj_data.exists():
                data_dir = proj_data
        elif script_file:
            shutil.copy2(script_file, script_path)
        elif config.get("script_code"):
            script_path.write_text(config.pop("script_code"))
        else:
            raise ValueError(f"No script found in uploads for job {job_id}")

    _report_status(callback_url, job_id, "running", 0.05, "Starting execution")

    def progress_cb(pct: float, msg: str) -> None:
        scaled = 0.05 + pct * 0.85
        _report_status(callback_url, job_id, "running", scaled, msg)

    started_at = time.monotonic()

    try:
        result = execute_job(
            script_path=str(script_path),
            data_dir=str(data_dir),
            output_dir=str(r2_output),
            config=config,
            progress_cb=progress_cb,
            gpu_type=gpu_type,
            gpu_memory_gb=gpu_memory,
            timeout=timeout_sec,
            checkpoint_dir=str(r2_checkpoints),
            log_dir=str(r2_logs),
        )
    except _CancelledError:
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(callback_url, job_id, "cancelled", 0.0, "Job cancelled -- logs flushed", gpu_seconds=elapsed)
        return {"status": "cancelled", "message": "Graceful shutdown completed"}
    except TimeoutError as exc:
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(
            callback_url,
            job_id,
            "failed",
            0.0,
            str(exc),
            gpu_seconds=elapsed,
            error=str(exc),
        )
        return {"status": "timeout", "error": str(exc)}
    except Exception as exc:
        tb = traceback.format_exc()
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(
            callback_url,
            job_id,
            "failed",
            0.0,
            str(exc),
            gpu_seconds=elapsed,
            error=tb,
        )
        return {"status": "error", "error": tb}

    if workspace_path and r2_run_history:
        for file in r2_output.iterdir():
            if file.is_file():
                shutil.copy2(file, r2_run_history / file.name)

    elapsed = max(0.0, time.monotonic() - started_at)
    callback_result = result if isinstance(result, dict) else None
    _report_status(callback_url, job_id, "completed", 1.0, "Job finished", gpu_seconds=elapsed, result=callback_result)
    return {"status": "completed", "result": result}


@app.function(gpu="T4", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_t4(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "T4")
    return _run_job(payload)


@app.function(gpu="L4", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_l4(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "L4")
    return _run_job(payload)


@app.function(gpu="A10G", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_a10g(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "A10G")
    return _run_job(payload)


@app.function(gpu="L40S", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_l40s(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "L40S")
    return _run_job(payload)


@app.function(gpu="A100", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_a100(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "A100")
    return _run_job(payload)


@app.function(gpu="H100", timeout=7200, retries=0, volumes={"/r2": r2_bucket})
def run_job_h100(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "H100")
    return _run_job(payload)


GPU_FUNCTIONS = {
    "T4": run_job_t4,
    "L4": run_job_l4,
    "A10G": run_job_a10g,
    "L40S": run_job_l40s,
    "A100": run_job_a100,
    "H100": run_job_h100,
}


def dispatch(payload: dict[str, Any]) -> dict[str, Any]:
    gpu_type = payload.get("gpu_type", "L4")
    fn = GPU_FUNCTIONS.get(gpu_type)
    if fn is None:
        raise ValueError(f"Unknown gpu_type: {gpu_type}. Valid: {list(GPU_FUNCTIONS)}")
    return fn.remote(payload)


@app.function(timeout=60)
@modal.fastapi_endpoint(method="POST")
def submit_job(payload: dict[str, Any]) -> dict[str, Any]:
    gpu_type = payload.get("gpu_type", "L4")
    fn = GPU_FUNCTIONS.get(gpu_type)
    if fn is None:
        return {"error": f"Unknown gpu_type: {gpu_type}", "valid": list(GPU_FUNCTIONS)}

    call = fn.spawn(payload)
    return {"call_id": call.object_id, "gpu_type": gpu_type, "status": "spawned"}
