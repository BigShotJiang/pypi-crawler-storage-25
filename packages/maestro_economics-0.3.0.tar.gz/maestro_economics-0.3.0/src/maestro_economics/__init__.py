"""Maestro Economics -- econometric analysis engine for agents."""
__version__ = "0.3.0"
