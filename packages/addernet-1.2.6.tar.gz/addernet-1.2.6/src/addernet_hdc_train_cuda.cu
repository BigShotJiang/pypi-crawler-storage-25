#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cuda_runtime.h>

extern "C" {
#include "hdc_core.h"
#include "addernet_hdc.h"
}

// ---------------------------------------------------------
// CUDA Kernel: Treinamento / Retrain Epoch
// ---------------------------------------------------------
__global__ void hdc_retrain_epoch_kernel(
    const uint64_t* __restrict__ sample_hvs,
    const int* __restrict__ y,
    const uint64_t* __restrict__ codebook,
    int* __restrict__ cb_counts,
    int n_samples, int n_classes,
    int hv_words, int hv_dim,
    int margin, int lr_int)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n_samples) return;

    int true_c = y[i];
    if (true_c < 0 || true_c >= n_classes) return;

    const uint64_t* sample = &sample_hvs[i * hv_words];

    int best_c = -1;
    int best_d = 0x7FFFFFFF;
    int true_d = 0;

    // Busca o mais próximo (Hamming distance)
    for (int c = 0; c < n_classes; c++) {
        const uint64_t* cb = &codebook[c * hv_words];
        int d = 0;
        for (int w = 0; w < hv_words; w++) {
            d += __popcll(sample[w] ^ cb[w]);
        }
        
        if (c == true_c) {
            true_d = d;
        } else if (d < best_d) {
            best_d = d;
            best_c = c;
        }
    }

    // Se errou ou margem foi violada, atualiza os contadores
    if (best_c != -1 && true_d > best_d - margin) {
        for (int w = 0; w < hv_words; w++) {
            uint64_t word = sample[w];
            for (int b = 0; b < 64; b++) {
                int bit_idx = w * 64 + b;
                if (bit_idx >= hv_dim) break;
                
                int bit_val = (word >> b) & 1;
                int update = bit_val ? lr_int : -lr_int;
                
                atomicAdd(&cb_counts[true_c * hv_dim + bit_idx], update);
                atomicAdd(&cb_counts[best_c * hv_dim + bit_idx], -update);
            }
        }
    }
}

__global__ void hdc_rebuild_codebook_kernel(
    const int* __restrict__ cb_counts,
    uint64_t* __restrict__ codebook,
    int n_classes, int hv_words, int hv_dim)
{
    int c = blockIdx.y;
    int w = blockIdx.x * blockDim.x + threadIdx.x;
    
    if (c >= n_classes || w >= hv_words) return;
    
    uint64_t word = 0;
    for (int b = 0; b < 64; b++) {
        int bit_idx = w * 64 + b;
        if (bit_idx >= hv_dim) break;
        
        if (cb_counts[c * hv_dim + bit_idx] > 0) {
            word |= (1ULL << b);
        }
    }
    
    codebook[c * hv_words + w] = word;
}


// ---------------------------------------------------------
// Wrapper C 
// ---------------------------------------------------------
extern "C" int an_hdc_retrain_cuda(
    an_hdc_model *m, const double *X, const int *y, 
    int n_samples, int n_iter, float lr, int margin, 
    int patience, int verbose, int *epochs_run_out) 
{
    if (!m || !X || !y || n_samples <= 0) return -1;

    int hv_words = m->hv_words;
    int hv_dim = m->hv_dim;
    int n_classes = m->n_classes;
    int lr_int = (int)(lr * 100.0f);
    if (lr_int < 1) lr_int = 1;

    // 1. Pre-encode all samples on Host (CPU)
    uint64_t *sample_hvs = (uint64_t *)aligned_alloc(64, n_samples * hv_words * sizeof(uint64_t));
    if (!sample_hvs) return -1;

    for (int i = 0; i < n_samples; i++) {
        const double *x = &X[i * m->n_vars];
        uint64_t **pairs = (uint64_t **)malloc(m->n_vars * sizeof(uint64_t *));
        
        uint64_t *val_hv = (uint64_t *)malloc(hv_words * sizeof(uint64_t));
        for (int v = 0; v < m->n_vars; v++) {
            pairs[v] = (uint64_t *)malloc(hv_words * sizeof(uint64_t));
            int bin = ((int)x[v] + m->bias[v]) & m->table_mask;

            
            if (m->use_circulant && m->circulant.circulant_ready) {
                hv_from_circulant(val_hv, &m->circulant, v, bin, hv_words, hv_dim);
            } else if (m->use_hadamard) {
                hv_from_hadamard(val_hv, v, bin, hv_words, hv_dim);
            } else {
                hv_from_seed(val_hv, (uint64_t)v * 100003ULL + (uint64_t)bin, hv_words);
            }
            
            hv_bind(pairs[v], &m->position_hvs[v * hv_words], val_hv, hv_words);
        }

        hv_bundle(&sample_hvs[i * hv_words], (const_hv_t *)pairs, m->n_vars, hv_words, hv_dim);
        
        for (int v = 0; v < m->n_vars; v++) free(pairs[v]);
        free(pairs);
        free(val_hv);
    }

    // 2. Initialize cb_counts
    int *h_cb_counts = (int *)calloc(n_classes * hv_dim, sizeof(int));
    for (int c = 0; c < n_classes; c++) {
        for (int w = 0; w < hv_words; w++) {
            uint64_t word = m->codebook[c * hv_words + w];
            for (int b = 0; b < 64; b++) {
                int bit_idx = w * 64 + b;
                if (bit_idx >= hv_dim) break;
                h_cb_counts[c * hv_dim + bit_idx] = ((word >> b) & 1) ? 1000 : -1000;
            }
        }
    }

    // 3. Allocate device memory
    uint64_t *d_sample_hvs, *d_codebook, *d_cb_best;
    int *d_y, *d_cb_counts;
    
    cudaMalloc((void**)&d_sample_hvs, n_samples * hv_words * sizeof(uint64_t));
    cudaMalloc((void**)&d_y, n_samples * sizeof(int));
    cudaMalloc((void**)&d_codebook, n_classes * hv_words * sizeof(uint64_t));
    cudaMalloc((void**)&d_cb_best, n_classes * hv_words * sizeof(uint64_t));
    cudaMalloc((void**)&d_cb_counts, n_classes * hv_dim * sizeof(int));

    cudaMemcpy(d_sample_hvs, sample_hvs, n_samples * hv_words * sizeof(uint64_t), cudaMemcpyHostToDevice);
    cudaMemcpy(d_y, y, n_samples * sizeof(int), cudaMemcpyHostToDevice);
    cudaMemcpy(d_codebook, m->codebook, n_classes * hv_words * sizeof(uint64_t), cudaMemcpyHostToDevice);
    cudaMemcpy(d_cb_best, m->codebook, n_classes * hv_words * sizeof(uint64_t), cudaMemcpyHostToDevice);
    cudaMemcpy(d_cb_counts, h_cb_counts, n_classes * hv_dim * sizeof(int), cudaMemcpyHostToDevice);

    int block_size = 256;
    int grid_size = (n_samples + block_size - 1) / block_size;
    
    dim3 rebuild_block(256);
    dim3 rebuild_grid((hv_words + 255) / 256, n_classes);

    int best_acc = 0;
    int no_improve = 0;
    int ep = 0;

    for (ep = 0; ep < n_iter; ep++) {
        // Run Retrain Kernel
        hdc_retrain_epoch_kernel<<<grid_size, block_size>>>(
            d_sample_hvs, d_y, d_codebook, d_cb_counts, 
            n_samples, n_classes, hv_words, hv_dim, margin, lr_int);
        
        cudaDeviceSynchronize();

        // Rebuild Codebook Kernel
        hdc_rebuild_codebook_kernel<<<rebuild_grid, rebuild_block>>>(
            d_cb_counts, d_codebook, n_classes, hv_words, hv_dim);
        
        cudaDeviceSynchronize();

        // Calculate accuracy (on host or device. We do on host for simplicity here by fetching codebook)
        cudaMemcpy(m->codebook, d_codebook, n_classes * hv_words * sizeof(uint64_t), cudaMemcpyDeviceToHost);
        
        int correct = 0;
        for (int i = 0; i < n_samples; i++) {
            int true_c = y[i];
            int best_c = -1;
            int min_d = 0x7FFFFFFF;
            for (int c = 0; c < n_classes; c++) {
                int d = hv_hamming(&sample_hvs[i * hv_words], &m->codebook[c * hv_words], hv_words);
                if (d < min_d) { min_d = d; best_c = c; }
            }
            if (best_c == true_c) correct++;
        }

        if (verbose) printf("Epoch %d - CUDA Acc: %.2f%%\n", ep + 1, 100.0f * correct / n_samples);

        if (correct > best_acc) {
            best_acc = correct;
            no_improve = 0;
            cudaMemcpy(d_cb_best, d_codebook, n_classes * hv_words * sizeof(uint64_t), cudaMemcpyDeviceToDevice);
        } else {
            no_improve++;
            if (no_improve >= patience) break;
        }
    }

    if (epochs_run_out) *epochs_run_out = ep;

    // Load best codebook back to host
    cudaMemcpy(m->codebook, d_cb_best, n_classes * hv_words * sizeof(uint64_t), cudaMemcpyDeviceToHost);

    cudaFree(d_sample_hvs);
    cudaFree(d_y);
    cudaFree(d_codebook);
    cudaFree(d_cb_best);
    cudaFree(d_cb_counts);
    free(sample_hvs);
    free(h_cb_counts);

    return 0;
}
