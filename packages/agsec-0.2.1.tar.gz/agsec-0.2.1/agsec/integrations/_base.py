"""Shared policy checker for all integrations."""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger("agsec")

from ..audit import AuditStore
from ..exceptions import PolicyViolationError
from ..policy import PolicyEngine
from ..policy.engine import LayeredPolicyEngine
from ..types import ActionExecutionResult, PolicyResult, PolicyStatus


def _get_agent_policy_dir(agent: str) -> Optional[str]:
    """Return ~/.agsec/agents/{agent}/ if it exists."""
    path = os.path.join(os.path.expanduser("~"), ".agsec", "agents", agent)
    if os.path.isdir(path):
        return path
    return None


def _find_project_policy_dir(start_dir: Optional[str] = None) -> Optional[str]:
    """Find project-level policies/ directory by walking up."""
    env_dir = os.environ.get("AGSEC_POLICY_DIR")
    if env_dir and os.path.isdir(env_dir):
        return os.path.abspath(env_dir)

    start = os.path.abspath(start_dir or os.getcwd())
    current = start
    for _ in range(20):
        for candidate in ("policies", os.path.join(".agsec", "policies")):
            path = os.path.join(current, candidate)
            if os.path.isdir(path):
                return path
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return None


class PolicyChecker:
    """Reusable policy checker for all integrations.

    Loads project-level policies + optional agent-level overlay.
    Deny from either layer wins (IAM semantics).
    """

    def __init__(
        self,
        policy_dir: Optional[str] = None,
        agent: Optional[str] = None,
        audit: bool = True,
    ):
        self.engine = PolicyEngine()
        self._audit_store = None
        self._loaded = False
        self._policy_dir = policy_dir
        self._agent = agent
        self._audit_enabled = audit

    def _ensure_loaded(self) -> None:
        """Lazy-load policies on first check. Uses IAM-style layered evaluation."""
        if self._loaded:
            return

        layered = LayeredPolicyEngine()

        # 1. Project-level policies (like IAM Permission Boundary)
        project_dir = self._policy_dir or _find_project_policy_dir()
        if project_dir:
            try:
                project_engine = PolicyEngine()
                project_engine.load_from_directory(project_dir)
                layered.add_layer("project", project_engine)
            except (ValueError, FileNotFoundError) as e:
                logger.warning("Failed to load project policies from %s: %s", project_dir, e)

        # 2. Agent-level policies (like IAM Identity Policy — can only restrict)
        # Agent layer defaults to ALLOW so it only adds restrictions (explicit denies),
        # not requiring its own allow list for every action.
        if self._agent:
            agent_dir = _get_agent_policy_dir(self._agent)
            if agent_dir:
                try:
                    agent_engine = PolicyEngine()
                    agent_engine.load_from_directory(agent_dir)
                    agent_engine._default = PolicyStatus.ALLOW
                    layered.add_layer("agent", agent_engine)
                except (ValueError, FileNotFoundError) as e:
                    logger.warning("Failed to load agent policies from %s: %s", agent_dir, e)

        self.engine = layered

        # 3. Audit store
        if self._audit_enabled:
            try:
                agsec_dir = os.path.join(os.path.expanduser("~"), ".agsec")
                os.makedirs(agsec_dir, mode=0o700, exist_ok=True)
                db_path = os.environ.get(
                    "AGSEC_AUDIT_DB", os.path.join(agsec_dir, "audit.db")
                )
                self._audit_store = AuditStore(db_path)
            except Exception:
                pass

        self._loaded = True

    def close(self) -> None:
        """Close the audit store connection."""
        if self._audit_store:
            self._audit_store.close()

    def check(
        self, action: str, params: Dict[str, Any], context: Optional[Dict[str, Any]] = None
    ) -> PolicyResult:
        """Check policy. Returns PolicyResult."""
        self._ensure_loaded()
        context = dict(context or {})
        if self._agent:
            context.setdefault("agent", self._agent)
        result = self.engine.evaluate(action, params, context)
        self._log(action, params, result, context)
        return result

    async def acheck(
        self, action: str, params: Dict[str, Any], context: Optional[Dict[str, Any]] = None
    ) -> PolicyResult:
        """Async check. Same logic, non-blocking compatible."""
        return self.check(action, params, context)

    def check_or_raise(
        self, action: str, params: Dict[str, Any], context: Optional[Dict[str, Any]] = None
    ) -> PolicyResult:
        """Check policy. Raises PolicyViolationError if blocked."""
        result = self.check(action, params, context)
        if result.status == PolicyStatus.BLOCK:
            raise PolicyViolationError(
                result.reason, action, result.status.value,
                policy_id=result.metadata.get("sid"),
            )
        if result.status == PolicyStatus.REVIEW:
            raise PolicyViolationError(
                f"[REVIEW REQUIRED] {result.reason}", action, result.status.value,
                policy_id=result.metadata.get("sid"),
            )
        return result

    async def acheck_or_raise(
        self, action: str, params: Dict[str, Any], context: Optional[Dict[str, Any]] = None
    ) -> PolicyResult:
        """Async version of check_or_raise."""
        return self.check_or_raise(action, params, context)

    def _log(
        self, action: str, params: Dict[str, Any], result: PolicyResult,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Log to audit store (swallow errors)."""
        if not self._audit_store:
            return
        try:
            exec_result = ActionExecutionResult(
                action=action, params=params, result=None, policy=result,
            )
            self._audit_store.log_execution(exec_result, context)
        except Exception as e:
            logger.debug("Audit logging failed in PolicyChecker: %s", e)


# ---------------------------------------------------------------------------
# Shared helpers for OpenAI / Anthropic integrations
# ---------------------------------------------------------------------------


def build_engine(rules, policy_dir=None, agent=None):
    """Build a layered policy engine from inline rules + optional YAML policies.

    Layers (IAM-style, all must allow):
      1. project — YAML policies from policy_dir
      2. inline — rules passed via code (allow/deny/review)
      3. agent — per-agent policies from ~/.agsec/agents/{agent}/
    """
    from .conditions import compile_rules

    layered = LayeredPolicyEngine()

    # Project layer (like IAM Permission Boundary)
    if policy_dir:
        try:
            project_engine = PolicyEngine()
            project_engine.load_from_directory(policy_dir)
            layered.add_layer("project", project_engine)
        except (ValueError, FileNotFoundError):
            pass

    # Inline rules layer (like IAM Identity Policy)
    inline_engine = PolicyEngine(default="deny")
    inline_engine._iam_loaded = True
    if rules:
        for stmt in compile_rules(rules):
            inline_engine.add_statement(stmt)
    layered.add_layer("inline", inline_engine)

    # Agent layer (can only restrict, never widen)
    # Defaults to ALLOW so it only adds restrictions via explicit deny/review.
    if agent:
        agent_dir = _get_agent_policy_dir(agent)
        if agent_dir:
            try:
                agent_engine = PolicyEngine()
                agent_engine.load_from_directory(agent_dir)
                agent_engine._default = PolicyStatus.ALLOW
                layered.add_layer("agent", agent_engine)
            except (ValueError, FileNotFoundError):
                pass

    return layered


def check_tool(engine, name, arguments):
    """Check a single tool call against policies. Returns (status, reason, metadata).

    Handles both dict arguments and JSON string arguments.
    Blocks on malformed/unparseable arguments (fail safe).
    """
    import json

    action = f"tool.{name}"
    params = {}

    if isinstance(arguments, str):
        try:
            params = json.loads(arguments)
        except (json.JSONDecodeError, TypeError):
            return PolicyStatus.BLOCK, "Tool arguments could not be parsed", {"matched_by": "parse_error"}
    elif isinstance(arguments, dict):
        params = arguments

    result = engine.evaluate(action, params)
    return result.status, result.reason, result.metadata
