import sqlite3
import subprocess
from pathlib import Path

import pandas as pd
from dataretrieval import nwis


def backup(original: Path):
    backup_path = original.with_suffix(".bak")
    if original.exists() and not backup_path.exists():
        original.rename(f"{backup_path.expanduser().resolve().absolute()}")


def restore(original: Path):
    backup_path = original.with_suffix(".bak")
    if original.exists():
        original.unlink()
    if backup_path.exists():
        backup_path.rename(f"{original.expanduser().resolve().absolute()}")


def temp_output(output: str = "output"):
    output_config_file = Path.home() / ".ngiab" / "preprocessor"
    backup(output_config_file)
    with open(output_config_file, "w") as f:
        f.write(f"/home/josh/code/JoshCu/sifan_cal/{output}/")


def run(cmd: str, suppress_output: bool = True):
    result = subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL if suppress_output else None)
    if result.returncode != 0:
        raise RuntimeError(f"Command '{cmd}' failed with exit code {result.returncode}")


def process_usgs_streamflow(
    site, start, end, output_path=None, interpolate_method="linear", max_gap=30 * 24
):
    adjusted_start = pd.to_datetime(start) - pd.Timedelta(days=1)
    adjusted_end = pd.to_datetime(end) + pd.Timedelta(days=1)
    adjusted_start = adjusted_start.strftime("%Y-%m-%d")
    adjusted_end = adjusted_end.strftime("%Y-%m-%d")

    dfo_usgs = nwis.get_record(sites=site, service="iv", start=adjusted_start, end=adjusted_end)
    dfo_usgs.index = pd.to_datetime(dfo_usgs.index)
    dfo_usgs["Time"] = dfo_usgs.index.floor("h")
    dfo_usgs["00060"] = pd.to_numeric(dfo_usgs["00060"], errors="coerce")

    dfo_usgs_hr = dfo_usgs.groupby("Time")["00060"].mean().reset_index()
    dfo_usgs_hr["values"] = dfo_usgs_hr["00060"] / 35.3147
    dfo_usgs_hr = dfo_usgs_hr[["Time", "values"]]
    dfo_usgs_hr = dfo_usgs_hr.rename(columns={"Time": "time", "values": "obs(m^3/s)"})
    dfo_usgs_hr = dfo_usgs_hr.set_index("time")

    # Create complete hourly index and reindex to expose gaps
    full_index = pd.date_range(start=dfo_usgs_hr.index.min(), end=dfo_usgs_hr.index.max(), freq="h")
    dfo_usgs_hr = dfo_usgs_hr.reindex(full_index)

    # Interpolate missing values
    dfo_usgs_hr["obs(m^3/s)"] = dfo_usgs_hr["obs(m^3/s)"].interpolate(
        method=interpolate_method,
        limit=max_gap,  # None = no limit, or set max consecutive NaNs to fill
    )

    dfo_usgs_hr.index = dfo_usgs_hr.index.strftime("%Y-%m-%d %H:%M:%S")
    dfo_usgs_hr.index.name = "time"

    # Filter to original date range
    dfo_usgs_hr = dfo_usgs_hr[(dfo_usgs_hr.index >= start) & (dfo_usgs_hr.index <= end)]

    if output_path:
        dfo_usgs_hr.to_csv(output_path)
    return dfo_usgs_hr


def restore_output():
    restore(Path.home() / ".ngiab" / "preprocessor")


def get_area_from_gpkg(gpkg_path: Path):
    with sqlite3.connect(gpkg_path) as conn:
        sql = "SELECT divide_id, areasqkm FROM 'divides'"
        results = conn.execute(sql).fetchall()
    return dict(results)
