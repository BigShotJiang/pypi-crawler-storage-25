import datetime
import json
import multiprocessing
import shutil
from pathlib import Path

import docker
import numpy as np
import typer
import xarray as xr
from rich import print

from .create_realization import (
    configure_troute,
    get_model_attributes,
    make_cfe_config,
    make_ngen_realization_json,
    make_noahowp_config,
)
from .file_paths import FilePaths
from .hydrofabric import GeoPackage
from .utils import backup, restore

app = typer.Typer()


def _get_dates(realization: Path) -> tuple[datetime.datetime, datetime.datetime]:
    with open(realization, "r") as f:
        realization = json.load(f)
        # format = "%Y-%m-%d %H:%M:%S"
        return (
            datetime.datetime.strptime(realization["time"]["start_time"].split(" ")[0], "%Y-%m-%d"),
            datetime.datetime.strptime(realization["time"]["end_time"].split(" ")[0], "%Y-%m-%d"),
        )


def _get_new_folder(hf_path: Path, target_area: float) -> Path:
    return hf_path.parent.parent / "rescale" / f"{target_area:.0f}km2"


def _get_new_gpkg_path(hf_path: Path, target_area: float) -> Path:
    return (
        hf_path.parent.parent
        / "rescale"
        / f"{target_area:.0f}km2"
        / "config"
        / f"{hf_path.stem.replace('_subset', '')}_{target_area:.0f}km2.gpkg"
    )


@app.command()
def rescale(hf_path: Path, target_area: float = 50.0):
    """Rescale hydrofabric catchments to a target area."""
    hf = GeoPackage(hf_path)
    groups = hf.group_catchments(target_area)
    print(f"Target area: {target_area} km²")
    print(f"Number of groups: {len(groups)}")
    hf.merge(groups)
    new_folder = _get_new_folder(hf_path, target_area)
    new_name = _get_new_gpkg_path(hf_path, target_area)
    new_name.parent.mkdir(parents=True, exist_ok=True)
    with open(new_folder / "mapping.json", "w") as f:
        json.dump(groups, f)
    hf.save(save_as=new_name)
    print(f"Saved to {new_name}")


@app.command()
def configure(hf_path: Path, target_area: float = 50.0):
    """Generate config files for a hydrofabric"""
    config_dir = hf_path.parent
    while config_dir.name != "config":
        config_dir = config_dir.parent
    realization = config_dir / "realization.json"
    new_gpkg = _get_new_gpkg_path(hf_path, target_area)
    # copy the original hf to the new folder
    shutil.copy(hf_path, new_gpkg.parent / "original.gpkg")

    # get the start and end dates from realization.json
    start_time, end_time = _get_dates(realization)
    data_root = _get_new_folder(hf_path, target_area)
    paths = FilePaths(output_dir=data_root)
    conf_df = get_model_attributes(new_gpkg)

    gw_levels = dict()

    make_cfe_config(conf_df, paths, gw_levels)
    make_noahowp_config(paths.config_dir, conf_df, start_time, end_time)
    configure_troute("original", paths.config_dir, start_time, end_time)
    make_ngen_realization_json(
        paths.config_dir, paths.template_cfe_nowpm_realization_config, start_time, end_time
    )
    ngen_output = data_root / "outputs" / "ngen"
    ngen_output.mkdir(parents=True, exist_ok=True)
    t_route_output = data_root / "outputs" / "troute"
    t_route_output.mkdir(parents=True, exist_ok=True)

    new_realization = data_root / "config" / "realization.json"
    config = json.loads(new_realization.read_text())
    config["no_routing"] = config.pop("routing", False)
    with open(new_realization, "w") as f:
        json.dump(config, f, indent=4)
    new_folder = _get_new_folder(hf_path, target_area)
    mapping = json.loads((new_folder / "mapping.json").read_text())
    remap_folder = data_root / "outputs" / "remap"
    remap_folder.mkdir(parents=True, exist_ok=True)
    for file in remap_folder.glob("*.csv"):
        file.unlink()
    for new_id, catchments in enumerate(mapping):
        new_output = ngen_output / f"cat-{new_id}.csv"
        new_output.touch()
        for cat_id in catchments:
            old_id = remap_folder / f"cat-{cat_id}.csv"
            old_id.hardlink_to(new_output)


@app.command()
def forcings(hf_path: Path, target_area: float = 50.0):
    """Merge forcings for a hydrofabric"""
    from .utils import get_area_from_gpkg

    # Load mapping and original forcings
    new_folder = _get_new_folder(hf_path, target_area)
    mapping = json.loads((new_folder / "mapping.json").read_text())

    forcings_dir = hf_path.parent.parent / "forcings"
    ds = xr.open_dataset(forcings_dir / "forcings.nc")

    # Build lookup from cat id string -> catchment-id dimension index
    ids = ds["ids"].values
    id_to_idx = {cat_id: i for i, cat_id in enumerate(ids)}

    # Get areas from the original gpkg
    areas = get_area_from_gpkg(hf_path)

    # Identify forcing variables (everything except ids and Time)
    forcing_vars = [v for v in ds.data_vars if v not in ("ids", "Time")]
    n_groups = len(mapping)
    n_time = ds.sizes["time"]

    # Build merged arrays
    merged = {v: np.zeros((n_groups, n_time), dtype=np.float64) for v in forcing_vars}

    for group_idx, group in enumerate(mapping):
        cat_ids = [f"cat-{cid}" for cid in group]
        indices = [id_to_idx[cid] for cid in cat_ids]
        group_areas = np.array([areas[cid] for cid in cat_ids])
        weights = group_areas / group_areas.sum()

        for v in forcing_vars:
            data = ds[v].values[indices, :]  # (n_cats_in_group, n_time)
            merged[v][group_idx, :] = np.average(data, axis=0, weights=weights)

    # Build new dataset
    new_ids = [f"cat-{i}" for i in range(n_groups)]
    new_ds = xr.Dataset(
        {v: (("catchment-id", "time"), merged[v].astype(np.float32)) for v in forcing_vars}
        | {
            "ids": (("catchment-id",), new_ids),
            "Time": (("catchment-id", "time"), np.tile(ds["Time"].values[0, :], (n_groups, 1))),
        }
    )

    # Save
    out_path = new_folder / "forcings"
    out_path.mkdir(parents=True, exist_ok=True)
    new_ds.to_netcdf(out_path / "forcings.nc")
    print(f"Saved merged forcings to {out_path / 'forcings.nc'}")


@app.command()
def run(hf_path: Path, target_area: float = 50.0):
    """Run a simulation using a selected hydrofabric"""
    data_root = _get_new_folder(hf_path, target_area)
    client = docker.from_env()
    original_gpkg = data_root / "config" / "original.gpkg"
    try:
        backup(original_gpkg)
        client.containers.run(
            "awiciroh/ngiab:latest",
            volumes={str(data_root.absolute()): {"bind": "/ngen/ngen/data", "mode": "rw"}},
            command=["/ngen/ngen/data", "auto", f"{multiprocessing.cpu_count()}", "local"],
            auto_remove=True,
        )
    finally:
        restore(original_gpkg)

    client.containers.run(
        "awiciroh/ngiab:latest",
        auto_remove=True,
        volumes={str(data_root.absolute()): {"bind": "/ngen/ngen/data", "mode": "rw"}},
        entrypoint=["python"],
        command=["-m", "nwm_routing", "-f", "./config/troute.yaml"],
        working_dir="/ngen/ngen/data",
    )


@app.command()
def all(hf_path: Path, target_area: float = 50.0):
    rescale(hf_path, target_area)
    configure(hf_path, target_area)
    forcings(hf_path, target_area)


def cli():
    app()
