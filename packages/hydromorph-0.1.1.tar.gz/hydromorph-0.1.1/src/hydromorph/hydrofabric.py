import sqlite3
from enum import Enum
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import xarray as xr

from .weighted_functions import weighted_circ_mean, weighted_mode


def _calculate_upstream_area(divides, headwaters):
    for id in headwaters:
        toid = divides[id]["toid"]
        area = divides[id]["area"]

        while toid in divides.keys():
            divides[toid]["upstream_area"] += area
            toid = divides[toid]["toid"]

    return divides


def _recalculate_upstream_area(divides, start_point: int):
    removed_area = divides[start_point]["upstream_area"]
    next_id = start_point
    while next_id in divides.keys():
        divides[next_id]["upstream_area"] = max(0, divides[next_id]["upstream_area"] - removed_area)
        next_id = divides[next_id]["toid"]

    return divides


class Layers(Enum):
    DIVIDES = "divides"
    SUBDIVIDES = "subdivides"
    DIVIDE_ATTRIBUTES = "divide-attributes"
    FLOWPATH_ATTRIBUTES = "flowpath-attributes"
    FLOWPATHS = "flowpaths"
    NEXUS = "nexus"
    NETWORK = "network"


class GeoPackage:
    gpkg_path: Path
    divides: gpd.GeoDataFrame
    subdivides: gpd.GeoDataFrame | None
    divide_attributes: pd.DataFrame
    flowpath_attributes: pd.DataFrame
    flowpaths: gpd.GeoDataFrame
    nexus: gpd.GeoDataFrame
    network: pd.DataFrame | None

    def __init__(self, gpkg_path: Path):
        self.gpkg_path = gpkg_path
        self.divides = gpd.read_file(gpkg_path, layer=Layers.DIVIDES.value)
        self.divide_attributes = gpd.read_file(
            gpkg_path, layer=Layers.DIVIDE_ATTRIBUTES.value
        ).set_index("divide_id")
        self.flowpath_attributes = (
            gpd.read_file(gpkg_path, layer=Layers.FLOWPATH_ATTRIBUTES.value)
            .set_index("id")
            .drop(columns=["link", "to", "toid", "gage_nex_id", "vpuid"], errors="ignore")
        )

        self.flowpaths = gpd.read_file(gpkg_path, layer=Layers.FLOWPATHS.value)
        self.nexus = gpd.read_file(gpkg_path, layer=Layers.NEXUS.value)
        self.network = pd.DataFrame(columns=["new_id", "id"])

    @property
    def layers(self) -> dict[str, gpd.GeoDataFrame]:
        layers = {
            Layers.DIVIDES.value: self.divides,
            Layers.DIVIDE_ATTRIBUTES.value: self.divide_attributes,
            Layers.FLOWPATHS.value: self.flowpaths,
            Layers.FLOWPATH_ATTRIBUTES.value: self.flowpath_attributes,
            Layers.NEXUS.value: self.nexus,
            Layers.NETWORK.value: self.network,
        }
        return layers

    def save(self, save_as: Path = Path("/dev/null")):
        if save_as == Path("/dev/null"):
            save_as = Path(f"{self.gpkg_path.stem}_modified.gpkg")

        for name, gdf in self.layers.items():
            if name not in ["divides", "nexus", "divide-attributes"]:
                continue
            columns_to_drop = gdf.columns.tolist()
            if name == "divides":
                columns_to_drop.remove("divide_id")
                columns_to_drop.remove("toid")
            elif name == "divide-attributes":
                columns_to_drop = []
            else:
                columns_to_drop.remove("id")
                columns_to_drop.remove("toid")

            if isinstance(gdf, gpd.GeoDataFrame):
                gdf.to_file(save_as, layer=name, driver="GPKG")
            elif isinstance(gdf, pd.DataFrame):
                with sqlite3.connect(save_as) as conn:
                    gdf.to_sql(name, conn, if_exists="replace", index=True)

    def execute_sql(self, sql: str) -> list:
        with sqlite3.connect(self.gpkg_path) as conn:
            return conn.execute(sql).fetchall()

    def _get_areasqkm_dict(self):
        sql = "SELECT divide_id, areasqkm FROM 'divides'"
        results = self.execute_sql(sql)
        return dict(results)

    def _get_areasqkm_xarray(self):
        weights_dict = self._get_areasqkm_dict()
        da = xr.DataArray.from_dict(
            {
                "dims": ["divide_id"],
                "coords": {"divide_id": {"dims": ["divide_id"], "data": list(weights_dict.keys())}},
                "data": list(weights_dict.values()),
            }
        )
        return da

    def _merge_divide_attributes(self, ids: list[str], new_id: str):
        if not new_id:
            raise ValueError("new_id must be provided")
        df = self.divide_attributes.loc[ids]
        xr_ds = xr.Dataset().from_dataframe(df)
        # make the coordinate be divide_id
        all_weights = self._get_areasqkm_dict()
        for id in list(all_weights.keys()):
            if id not in ids:
                all_weights.pop(id)
        weights = [all_weights[id] for id in ids]
        # all_weights = self._get_areasqkm_xarray()
        # xr_weights = all_weights.sel

        # variables are named mode.var mean.var circ_mean.var geom_mean.var etc depending on how they should be aggregated
        # new_entry = {}
        largest_cat = max(ids, key=lambda x: all_weights[x])
        for name in xr_ds.data_vars.keys():
            if name.startswith("mean."):
                self.divide_attributes.loc[new_id, name] = (
                    # xr_ds[name].weighted(xr_weights).mean().values
                    np.average(xr_ds[name].values, weights=weights)
                )
            elif name.startswith("mode."):
                self.divide_attributes.loc[new_id, name] = weighted_mode(df[name], all_weights)
            elif name.startswith("geom_mean."):
                self.divide_attributes.loc[new_id, name] = (
                    # xr_ds[name].weighted(xr_weights).mean().values
                    np.average(xr_ds[name].values, weights=weights)
                )
            elif name.startswith("circ_mean."):
                self.divide_attributes.loc[new_id, name] = weighted_circ_mean(df[name], all_weights)
            elif name.startswith("dist_4.twi"):
                self.divide_attributes.loc[new_id, name] = df.loc[largest_cat][name]
            elif name.startswith("vpuid"):
                self.divide_attributes.loc[new_id, name] = weighted_mode(df[name], all_weights)
            elif name.startswith("centroid"):
                self.divide_attributes.loc[new_id, name] = (
                    # xr_ds[name].weighted(xr_weights).mean().values
                    np.average(xr_ds[name].values, weights=weights)
                )
            else:
                print(f"Unknown variable type: {name}")

        # remove the old divides
        if new_id in ids:
            ids.remove(new_id)
        self.divide_attributes.drop(ids, inplace=True)

    def _merge_divides(self, ids: list[str], new_id: str):
        if not new_id:
            raise ValueError("new_id must be provided")

        aggregation = {
            # "divide_id": "last",
            "toid": "first",
            "type": "last",
            "ds_id": "last",
            "areasqkm": "sum",
            "id": "last",
            "lengthkm": "sum",
            "tot_drainage_areasqkm": "sum",
            "has_flowline": "max",
            "vpuid": "last",
        }

        geom_to_merge = self.divides[self.divides["divide_id"].isin(ids)]

        # merge the attributes first
        self._merge_divide_attributes(ids, new_id)

        if geom_to_merge.empty:
            print(f"No divides found matching IDs: {ids}")
            return

        temp_divides = self.divides.copy()

        temp_divides.loc[temp_divides["divide_id"].isin(ids), "divide_id"] = new_id
        result = temp_divides.dissolve(by="divide_id", aggfunc=aggregation, as_index=False)
        self.divides = result
        for id in ids:
            self.network.loc[-1] = [new_id, id]

    def merge(self, ids: list[str | list[str]]) -> None:
        # convert wb ids to cat ids

        for i, id_sublist in enumerate(ids):
            sub = ["cat-" + str(id).split("-")[-1] for id in id_sublist]

            cat_ids = list(set(sub))

            if len(cat_ids) > 1:
                self._merge_divides(cat_ids, f"cat-{i}")

        self.divides["toid"] = "nex-1"

        self.nexus = self.nexus.drop(self.nexus.index.to_list()[1:], axis=0)
        self.nexus["id"] = "nex-1"

    def detect_flying_water(self) -> list[str | list[str]]:
        # for every flowpath, check if the final point in the geometry is within some distance of the nexus it flows to
        nexuses_to_merge = set()
        flowpaths_to_merge = set()
        for i in range(len(self.flowpaths)):
            flowpath = self.flowpaths.iloc[i]

            out_nexus_point = self.nexus[self.nexus["id"].eq(flowpath.toid)].geometry
            if flowpath.geometry.distance(out_nexus_point).min() > 100:
                print(f"Flowpath {flowpath.id} has a flying water issue")
                print(f"distance: {flowpath.geometry.distance(out_nexus_point).min()}")
                nexuses_to_merge.add(flowpath.toid)

        # return a list of lists of catchments
        cats_to_merge = []
        for nexus_id in nexuses_to_merge:
            print(f"Fixing flying water for nexus {nexus_id}")
            cats_to_merge.append(self.divides[self.divides["toid"].eq(nexus_id)].divide_id.tolist())
        # if len(cats_to_merge) > 0:
        #     self.merge(cats_to_merge)
        detected_flying_water = []
        detected_flying_water.extend(cats_to_merge)

        while True:
            flowpaths_to_merge = []
            merged_flowpaths = set()
            for id in self.flowpaths.id:
                flowpath = self.flowpaths[self.flowpaths["id"].eq(id)].iloc[0]
                if flowpath.id in merged_flowpaths:
                    continue
                # check if the first or last point is within 100m of the nexus it flows to
                in_nexus_point = self.nexus[self.nexus["toid"].eq(flowpath.id)].geometry
                if len(in_nexus_point) == 0:
                    continue
                distance_along_line = flowpath.geometry.line_locate_point(in_nexus_point).min()
                if distance_along_line > 100:
                    print(f"Flowpath {flowpath.id} has a nexus in the middle of it")
                    print(f"distance: {distance_along_line}")
                    local_merge = []
                    upstream_nex_id = self.nexus[self.nexus["toid"].eq(flowpath.id)].iloc[0].id

                    upstream_flowpath_ids = self.flowpaths[
                        self.flowpaths["toid"].eq(upstream_nex_id)
                    ].id
                    local_merge.append(flowpath.id)
                    merged_flowpaths.add(flowpath.id)
                    for up_id in upstream_flowpath_ids:
                        local_merge.append(up_id)
                        merged_flowpaths.add(up_id)
                    if len(local_merge) > 1:
                        flowpaths_to_merge.append(local_merge)

            cats_to_merge = []
            for group in flowpaths_to_merge:
                wb_set = list(set(group))

                if len(wb_set) > 1:
                    cats_to_merge.append([f"cat-{i.split('-')[1]}" for i in group])
            if len(cats_to_merge) == 0:
                break
            # self.merge(cats_to_merge)
            detected_flying_water.extend(cats_to_merge)

        return detected_flying_water

    def group_catchments(self, target_area: float = 330.0):
        result = self.execute_sql("SELECT divide_id, toid, areasqkm FROM divides")
        divides = {}
        headwaters = set()
        for divide_id, nex_id, area in result:
            id = int(divide_id.split("-")[-1])
            toid = int(nex_id.split("-")[-1])
            area = float(area)
            headwaters.add(id)
            divide = {"toid": toid, "area": area, "upstream_area": area}
            divides[id] = divide

        for id in divides.keys():
            toid = divides[id]["toid"]
            if toid in headwaters:
                headwaters.remove(toid)
            try:
                upstreams = divides[toid].get("upstreams", [])
                upstreams.append(id)
                divides[toid]["upstreams"] = upstreams
            except KeyError:
                print(f"no downstream found for {toid}")

        divides = _calculate_upstream_area(divides, set(divides.keys()))
        merges = []
        while max(divide["upstream_area"] for divide in divides.values()) > target_area:
            # find the upstream area closes to target_area
            closest_id = None
            closest_area = float("inf")
            for id, divide in divides.items():
                area_diff = abs(divide["upstream_area"] - target_area)
                if area_diff < closest_area:
                    closest_id = id
                    closest_area = area_diff

            to_check = divides[closest_id]["upstreams"]
            upstreams = []
            while len(to_check) > 0:
                next_check = []
                for id in to_check:
                    if id in divides.keys():
                        next_check.extend(divides[id].get("upstreams", []))
                        upstreams.append(id)
                to_check = next_check
            merges.append(upstreams)
            divides = _recalculate_upstream_area(divides, closest_id)

            for id in upstreams:
                divides.pop(id)

            # recursively get every id upstream of that id
            # remove all those ids from the divides dict
            # recalculate upstream area t rerun
        # one final merge to pick up stragglers
        merges.append(list(divides.keys()))
        print(f"{len(merges)} cats remaining")
        return merges
