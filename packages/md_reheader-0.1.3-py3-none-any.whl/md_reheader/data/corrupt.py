import random
import re

STRATEGIES = ["flatten", "random", "shift"]


def corrupt_flatten_all(md_text: str) -> str:
    return re.sub(r"^(#{1,6})\s+", "# ", md_text, flags=re.MULTILINE)


def corrupt_random_levels(md_text: str, seed: int | None = None) -> str:
    rng = random.Random(seed)

    def replace_heading(match: re.Match) -> str:
        level = rng.randint(1, 4)
        return "#" * level + " "

    return re.sub(r"^#{1,6}\s+", replace_heading, md_text, flags=re.MULTILINE)


def corrupt_shift_levels(md_text: str, shift: int = 1) -> str:
    def replace_heading(match: re.Match) -> str:
        original_level = len(match.group(0).rstrip())
        new_level = max(1, min(6, original_level + shift))
        return "#" * new_level + " "

    return re.sub(r"^#{1,6}\s+", replace_heading, md_text, flags=re.MULTILINE)


def corrupt_document(md_text: str, strategy: str = "mixed", seed: int | None = None) -> str:
    rng = random.Random(seed)

    if strategy == "mixed":
        strategy = rng.choice(STRATEGIES)

    if strategy == "flatten":
        return corrupt_flatten_all(md_text)
    elif strategy == "random":
        return corrupt_random_levels(md_text, seed=seed)
    elif strategy == "shift":
        return corrupt_shift_levels(md_text, shift=1)
    else:
        raise ValueError(f"Unknown corruption strategy: {strategy}")
