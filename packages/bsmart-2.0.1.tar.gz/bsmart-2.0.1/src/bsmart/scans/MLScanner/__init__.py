"""
MLScanner scan collection 

MLScanner 
---------


This is a collection of scans based on machine learning models based on code from 

* `<https://github.com/AHamamd150/MLscanner>`_
* `<https://arxiv.org/abs/2207.09959>`_

The scans are:

.. autosummary::
   :toctree: .
   :template: custom-module-template.rst
   :recursive:

   MLS_DNNC
   MLS_DNNR
   MLS_GBR
   MLS_RFC
   MLS_RFR
   MLS_SVR_Poly
   MLS_SVR_RBF

"""
