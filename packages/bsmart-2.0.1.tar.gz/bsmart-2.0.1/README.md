General purpose lightweight scanning tool for HEP projects, originally intended for SARAH/SPheno workflows.

Requires python 3.

Optional packages (for e.g. MPI, used with MultiNest/Diver, or pytorch for ML scans) are in installable separately:

pip3 install 'bsmart[all]'
pip3 install 'bsmart[cmaes-nd]'


It is preferable to create a directory for your scan to run from, and place in it a .json file with the necessary options; and a template input file for SPheno, if required (scans can be performed without this, for example if you are supplying spectrum files from a directory or the input files are already prepared, or if you are running a pure python scan). You then type

BSMArt <template>.json

and that's it! If you have problems, add the --debug tag to see warning messages; otherwise, the logs will be stored on either /dev/shm/BSMArt_Temp (if /dev/shm exists) or in subdirectory Temp. You can also consult the several example input files, or use the QuickStart script as an example.

To generate models and set up a json file with all the tools, it is convenient to use the BSMArt-InstallHEPtools and BSMArt-PrepareModel scripts provided as part of the package. 

A QuickStart script runs via

BSMArt-QuickStart

and installable examples run via

BSMArt-BuildExamples

A repository of scans and tools is available at

https://github.com/BSMArt-HEP/examples

More information can be found at

https://goodsell.pages.in2p3.fr/bsmart/