"""
LLM Client — provider-agnostic interface with automatic fallback.

Providers: Anthropic (w/ extended thinking + computer use), OpenAI, Replicate, OpenRouter
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Any, Generator

from dotenv import load_dotenv

load_dotenv()

# ── Model catalogs ────────────────────────────────────────────────────
ANTHROPIC_MODELS = {
    "opus": "claude-opus-4-6",
    "sonnet": "claude-sonnet-4-6",
    "haiku": "claude-haiku-4-5",
    "sonnet-4-5": "claude-sonnet-4-5",
}
OPENAI_MODELS = {
    "gpt-5.4": "gpt-5.4",
    "gpt-5.4-mini": "gpt-5.4-mini",
    "gpt-5.4-nano": "gpt-5.4-nano",
    "o3": "o3",
    "o3-mini": "o3-mini",
    "o4-mini": "o4-mini",
}
GOOGLE_MODELS = {
    "gemini-3.1-pro": "gemini-3.1-pro-preview",
    "gemini-3-flash": "gemini-3-flash-preview",
    "gemini-2.5-pro": "gemini-2.5-pro",
    "gemini-2.5-flash": "gemini-2.5-flash",
    "gemini-2.5-flash-lite": "gemini-2.5-flash-lite",
}
PERPLEXITY_MODELS = {
    "sonar-pro": "sonar-pro",
    "sonar": "sonar",
    "sonar-reasoning-pro": "sonar-reasoning-pro",
    "sonar-deep-research": "sonar-deep-research",
}
REPLICATE_MODELS = {
    "llama-4-maverick": "meta/llama-4-maverick-instruct",
    "llama-4-scout": "meta/llama-4-scout-instruct",
    "llama-3.3-70b": "meta/meta-llama-3.3-70b-instruct",
}
OPENROUTER_MODELS = {
    "qwen-3.6-plus-free": "qwen/qwen3.6-plus:free",
    "nemotron-3-super-free": "nvidia/nemotron-3-super-120b-a12b:free",
    "gemma-4-26b": "google/gemma-4-26b-a4b-it",
    "llama-4-maverick-free": "meta-llama/llama-4-maverick:free",
    "deepseek-r1-free": "deepseek/deepseek-r1:free",
    "mistral-large": "mistralai/mistral-large",
}

DEFAULT_MODELS = {
    "anthropic": ANTHROPIC_MODELS["sonnet"],
    "openai": OPENAI_MODELS["gpt-5.4"],
    "google": GOOGLE_MODELS["gemini-2.5-flash"],  # stable, best price-performance
    "perplexity": PERPLEXITY_MODELS["sonar-pro"],
    "replicate": REPLICATE_MODELS["llama-4-maverick"],
    "openrouter": OPENROUTER_MODELS["qwen-3.6-plus-free"],
}

ALL_ANTHROPIC_MODELS = list(ANTHROPIC_MODELS.values())
ALL_OPENAI_MODELS = list(OPENAI_MODELS.values())
ALL_GOOGLE_MODELS = list(GOOGLE_MODELS.values())
ALL_PERPLEXITY_MODELS = list(PERPLEXITY_MODELS.values())
ALL_REPLICATE_MODELS = list(REPLICATE_MODELS.values())
ALL_OPENROUTER_MODELS = list(OPENROUTER_MODELS.values())

PROVIDER_ENV_KEYS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
    "perplexity": "PERPLEXITY_API_KEY",
    "replicate": "REPLICATE_API_TOKEN",
    "openrouter": "OPENROUTER_API_KEY",
}

FALLBACK_ORDER = ["anthropic", "openai", "google", "perplexity", "replicate", "openrouter"]


def resolve_provider(preferred: str = "") -> tuple[str, str]:
    """Return (provider, api_key) trying preferred first, then fallback order."""
    order = [preferred] + [p for p in FALLBACK_ORDER if p != preferred] if preferred else FALLBACK_ORDER
    for p in order:
        env_var = PROVIDER_ENV_KEYS.get(p, "")
        key = os.environ.get(env_var, "") if env_var else ""
        if key:
            return p, key
    return preferred or "anthropic", ""


@dataclass(frozen=True)
class LLMConfig:
    provider: str = "anthropic"
    model: str = ""
    api_key: str = ""
    max_tokens: int = 8192
    temperature: float = 0.7
    system_prompt: str = ""
    extended_thinking: bool = False
    thinking_budget: int = 10000
    computer_use: bool = False

    @property
    def resolved_model(self) -> str:
        return self.model or DEFAULT_MODELS.get(self.provider, DEFAULT_MODELS["anthropic"])

    @property
    def resolved_key(self) -> str:
        if self.api_key:
            return self.api_key
        env_var = PROVIDER_ENV_KEYS.get(self.provider, "")
        return os.environ.get(env_var, "") if env_var else ""

    @property
    def is_configured(self) -> bool:
        return bool(self.resolved_key)


@dataclass(frozen=True)
class LLMResponse:
    content: str
    input_tokens: int
    output_tokens: int
    model: str
    stop_reason: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    thinking: str = ""
    thinking_tokens: int = 0


@dataclass
class LLMClient:
    config: LLMConfig = field(default_factory=LLMConfig)

    def complete(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        dispatch = {
            "anthropic": self._complete_anthropic,
            "openai": self._complete_openai,
            "google": self._complete_google,
            "perplexity": self._complete_perplexity,
            "replicate": self._complete_replicate,
            "openrouter": self._complete_openrouter,
        }
        fn = dispatch.get(self.config.provider, self._complete_openai)
        return fn(messages, tools)

    # ── Anthropic ─────────────────────────────────────────────────────

    def _complete_anthropic(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        import anthropic

        client = anthropic.Anthropic(api_key=self.config.resolved_key)
        kwargs: dict = dict(
            model=self.config.resolved_model,
            max_tokens=self.config.max_tokens,
            messages=messages,
        )
        if self.config.system_prompt:
            kwargs["system"] = self.config.system_prompt

        # Extended thinking support
        if self.config.extended_thinking:
            kwargs["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.config.thinking_budget,
            }
            # Temperature must be 1 when thinking is enabled
            kwargs.pop("temperature", None)
        else:
            if self.config.temperature is not None:
                kwargs["temperature"] = self.config.temperature

        # Computer use support
        betas = []
        if self.config.computer_use:
            betas.append("computer-use-2025-11-24")
            # Add computer use tool to the tools list
            cu_tools = [
                {
                    "type": "computer_20251124",
                    "name": "computer",
                    "display_width_px": 1280,
                    "display_height_px": 800,
                },
                {
                    "type": "text_editor_20250728",
                    "name": "str_replace_based_edit_tool",
                },
                {
                    "type": "bash_20250124",
                    "name": "bash",
                },
            ]
            if tools:
                kwargs["tools"] = cu_tools + tools
            else:
                kwargs["tools"] = cu_tools
        elif tools:
            kwargs["tools"] = tools

        if betas:
            response = client.beta.messages.create(**kwargs, betas=betas)
        else:
            response = client.messages.create(**kwargs)

        text_content = ""
        thinking_content = ""
        thinking_tokens = 0
        tool_calls = []
        for block in response.content:
            if hasattr(block, "text") and block.type == "text":
                text_content += block.text
            elif hasattr(block, "thinking") and block.type == "thinking":
                thinking_content += block.thinking
            elif block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "arguments": block.input,
                })

        # Extract thinking tokens if available
        usage = response.usage
        if hasattr(usage, "thinking_tokens"):
            thinking_tokens = usage.thinking_tokens or 0

        return LLMResponse(
            content=text_content,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            model=response.model,
            stop_reason=response.stop_reason or "end_turn",
            tool_calls=tool_calls,
            thinking=thinking_content,
            thinking_tokens=thinking_tokens,
        )

    # ── OpenAI ────────────────────────────────────────────────────────

    def _complete_openai(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        from openai import OpenAI

        client = OpenAI(api_key=self.config.resolved_key)
        kwargs: dict = dict(
            model=self.config.resolved_model,
            max_completion_tokens=self.config.max_tokens,
            messages=messages,
        )
        if self.config.temperature is not None:
            kwargs["temperature"] = self.config.temperature
        if self.config.system_prompt:
            kwargs["messages"] = [{"role": "system", "content": self.config.system_prompt}] + messages
        if tools:
            openai_tools = []
            for t in tools:
                openai_tools.append({
                    "type": "function",
                    "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]},
                })
            kwargs["tools"] = openai_tools

        response = client.chat.completions.create(**kwargs)
        choice = response.choices[0]
        text = choice.message.content or ""
        tool_calls = []
        if choice.message.tool_calls:
            for tc in choice.message.tool_calls:
                tool_calls.append({
                    "id": tc.id,
                    "name": tc.function.name,
                    "arguments": json.loads(tc.function.arguments),
                })

        return LLMResponse(
            content=text,
            input_tokens=response.usage.prompt_tokens if response.usage else 0,
            output_tokens=response.usage.completion_tokens if response.usage else 0,
            model=response.model or self.config.resolved_model,
            stop_reason=choice.finish_reason or "stop",
            tool_calls=tool_calls,
        )

    # ── Google Gemini ───────────────────────────────────────────────────

    def _complete_google(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        import requests

        api_messages = []
        system_instruction = None
        if self.config.system_prompt:
            system_instruction = {"parts": [{"text": self.config.system_prompt}]}
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"
                )
            role = "model" if msg.get("role") == "assistant" else "user"
            api_messages.append({"role": role, "parts": [{"text": content}]})

        body: dict = {
            "contents": api_messages,
            "generationConfig": {
                "maxOutputTokens": self.config.max_tokens,
                "temperature": self.config.temperature,
            },
        }
        if system_instruction:
            body["systemInstruction"] = system_instruction

        model = self.config.resolved_model
        resp = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={self.config.resolved_key}",
            json=body,
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()

        candidates = data.get("candidates", [{}])
        text = ""
        if candidates:
            parts = candidates[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts)

        usage = data.get("usageMetadata", {})
        return LLMResponse(
            content=text,
            input_tokens=usage.get("promptTokenCount", 0),
            output_tokens=usage.get("candidatesTokenCount", 0),
            model=model,
            stop_reason=candidates[0].get("finishReason", "STOP") if candidates else "STOP",
        )

    # ── Perplexity ────────────────────────────────────────────────────

    def _complete_perplexity(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        import requests

        api_messages = []
        if self.config.system_prompt:
            api_messages.append({"role": "system", "content": self.config.system_prompt})
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"
                )
            api_messages.append({"role": msg.get("role", "user"), "content": content})

        resp = requests.post(
            "https://api.perplexity.ai/chat/completions",
            headers={
                "Authorization": f"Bearer {self.config.resolved_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.config.resolved_model,
                "messages": api_messages,
                "max_tokens": self.config.max_tokens,
                "temperature": self.config.temperature,
            },
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()

        choice = data.get("choices", [{}])[0]
        text = choice.get("message", {}).get("content", "")
        usage = data.get("usage", {})

        return LLMResponse(
            content=text,
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
            model=data.get("model", self.config.resolved_model),
            stop_reason=choice.get("finish_reason", "stop"),
        )

    # ── Replicate ─────────────────────────────────────────────────────

    def _complete_replicate(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        import requests

        prompt_parts = []
        if self.config.system_prompt:
            prompt_parts.append(f"System: {self.config.system_prompt}\n\n")
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"
                )
            prompt_parts.append(f"{role.title()}: {content}\n")
        prompt_parts.append("Assistant:")
        full_prompt = "\n".join(prompt_parts)

        resp = requests.post(
            "https://api.replicate.com/v1/predictions",
            headers={"Authorization": f"Bearer {self.config.resolved_key}", "Content-Type": "application/json"},
            json={"model": self.config.resolved_model, "input": {"prompt": full_prompt, "max_tokens": self.config.max_tokens}},
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()

        # Poll for completion
        import time
        for _ in range(120):
            if data.get("status") in ("succeeded", "failed", "canceled"):
                break
            time.sleep(1)
            poll_resp = requests.get(
                data["urls"]["get"],
                headers={"Authorization": f"Bearer {self.config.resolved_key}"},
                timeout=30,
            )
            data = poll_resp.json()

        output = data.get("output", "")
        if isinstance(output, list):
            output = "".join(output)

        return LLMResponse(
            content=output,
            input_tokens=len(full_prompt.split()),
            output_tokens=len(output.split()),
            model=self.config.resolved_model,
            stop_reason="end_turn",
        )

    # ── OpenRouter ────────────────────────────────────────────────────

    def _complete_openrouter(self, messages: list[dict], tools: list[dict] | None = None) -> LLMResponse:
        import requests

        api_messages = []
        if self.config.system_prompt:
            api_messages.append({"role": "system", "content": self.config.system_prompt})
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"
                )
            api_messages.append({"role": msg.get("role", "user"), "content": content})

        resp = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {self.config.resolved_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.config.resolved_model,
                "messages": api_messages,
                "max_tokens": self.config.max_tokens,
                "temperature": self.config.temperature,
            },
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()

        choice = data.get("choices", [{}])[0]
        text = choice.get("message", {}).get("content", "")
        usage = data.get("usage", {})

        return LLMResponse(
            content=text,
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
            model=data.get("model", self.config.resolved_model),
            stop_reason=choice.get("finish_reason", "stop"),
        )
