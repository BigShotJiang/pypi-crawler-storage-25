"""
Agent Tools — real executable tools for the agentic loop.

12 tools: bash, file_read, file_write, file_edit, python_exec, web_fetch,
list_directory, grep_search, glob_search, web_search, multi_file_edit, notebook_edit
All file operations are confined to the workspace root.
"""
from __future__ import annotations

import fnmatch
import glob as globmod
import html.parser
import json
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Default workspace root — overridden by callers
WORKSPACE_ROOT = Path.cwd()

MAX_OUTPUT_CHARS = 60_000
MAX_FILE_READ_CHARS = 100_000


def set_workspace_root(path: str | Path) -> None:
    """Set the workspace root for all tool operations."""
    global WORKSPACE_ROOT
    WORKSPACE_ROOT = Path(path).resolve()


def _truncate(text: str, limit: int = MAX_OUTPUT_CHARS) -> str:
    if len(text) > limit:
        return text[:limit] + f"\n\n... (truncated, {len(text)} total chars)"
    return text


@dataclass
class ToolResult:
    tool_use_id: str
    name: str
    output: str
    is_error: bool = False


# ── Tool schemas (Anthropic format) ──────────────────────────────────

TOOL_SCHEMAS = [
    {
        "name": "bash",
        "description": (
            "Run a shell command in the workspace directory and return stdout+stderr. "
            "Use this for: running programs, installing packages, git operations, "
            "searching files with grep/find/ripgrep, system tasks, and anything "
            "you'd do in a terminal. Commands run with a 120s timeout."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The shell command to execute."}
            },
            "required": ["command"],
        },
    },
    {
        "name": "file_read",
        "description": "Read the contents of a file. Returns the full file or a line range.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path, relative to workspace root or absolute."},
                "start_line": {"type": "integer", "description": "Optional 1-based start line."},
                "end_line": {"type": "integer", "description": "Optional 1-based end line."},
            },
            "required": ["path"],
        },
    },
    {
        "name": "file_write",
        "description": "Create or overwrite a file with the given content. Creates parent directories automatically.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path, relative to workspace root or absolute."},
                "content": {"type": "string", "description": "The full content to write to the file."},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "file_edit",
        "description": "Edit a file by replacing an exact string with a new string. The old_string must appear exactly once.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path."},
                "old_string": {"type": "string", "description": "The exact text to find (must appear exactly once)."},
                "new_string": {"type": "string", "description": "The replacement text."},
            },
            "required": ["path", "old_string", "new_string"],
        },
    },
    {
        "name": "python_exec",
        "description": "Execute a Python code snippet and return its stdout/stderr output.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute."}
            },
            "required": ["code"],
        },
    },
    {
        "name": "web_fetch",
        "description": "Fetch a URL and return its text content. For HTML pages, extracts readable text.",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The URL to fetch."}
            },
            "required": ["url"],
        },
    },
    {
        "name": "list_directory",
        "description": "List files and folders in a directory.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path. Defaults to '.'."}
            },
            "required": [],
        },
    },
    {
        "name": "grep_search",
        "description": (
            "Search for a pattern in file contents across the workspace. "
            "Supports regex. Returns matching lines with file paths and line numbers. "
            "Use this to find code patterns, function definitions, imports, etc."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex pattern to search for."},
                "path": {"type": "string", "description": "Directory or file to search in. Defaults to '.'."},
                "include": {"type": "string", "description": "Glob pattern to filter files (e.g. '*.py')."},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "glob_search",
        "description": (
            "Find files matching a glob pattern in the workspace. "
            "Use this to discover project structure, find specific file types, etc."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Glob pattern (e.g. '**/*.py', 'src/**/*.ts')."},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "web_search",
        "description": (
            "Search the web using DuckDuckGo and return results. "
            "Returns titles, URLs, and snippets for top results."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query."},
                "num_results": {"type": "integer", "description": "Number of results (default 5, max 10)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "multi_file_edit",
        "description": (
            "Apply multiple file edits in a single operation. Each edit specifies a file path, "
            "old_string, and new_string. All edits are validated before any are applied."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "edits": {
                    "type": "array",
                    "description": "Array of edit operations.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string"},
                            "old_string": {"type": "string"},
                            "new_string": {"type": "string"},
                        },
                        "required": ["path", "old_string", "new_string"],
                    },
                },
            },
            "required": ["edits"],
        },
    },
    {
        "name": "notebook_edit",
        "description": (
            "Edit a Jupyter notebook (.ipynb). Supports: insert_cell, replace_cell, delete_cell. "
            "Use this for modifying notebook files programmatically."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the .ipynb file."},
                "action": {"type": "string", "enum": ["insert_cell", "replace_cell", "delete_cell"]},
                "cell_index": {"type": "integer", "description": "0-based cell index."},
                "cell_type": {"type": "string", "enum": ["code", "markdown"], "description": "Cell type (for insert/replace)."},
                "source": {"type": "string", "description": "Cell content (for insert/replace)."},
            },
            "required": ["path", "action", "cell_index"],
        },
    },
]


def get_openai_tools() -> list[dict]:
    """Convert schemas to OpenAI function-calling format."""
    return [
        {"type": "function", "name": t["name"], "description": t["description"], "parameters": t["input_schema"]}
        for t in TOOL_SCHEMAS
    ]


# ── Simple HTML text extractor ────────────────────────────────────────

class _HTMLTextExtractor(html.parser.HTMLParser):
    _SKIP_TAGS = {"script", "style", "noscript", "svg", "head"}

    def __init__(self):
        super().__init__()
        self._pieces: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth += 1
        if tag.lower() in ("br", "p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr"):
            self._pieces.append("\n")

    def handle_endtag(self, tag):
        if tag.lower() in self._SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)

    def handle_data(self, data):
        if self._skip_depth == 0:
            self._pieces.append(data)

    def get_text(self) -> str:
        raw = "".join(self._pieces)
        lines = [line.strip() for line in raw.splitlines()]
        return "\n".join(line for line in lines if line)


def _html_to_text(html_content: str) -> str:
    parser = _HTMLTextExtractor()
    parser.feed(html_content)
    return parser.get_text()


# ── Path resolution with safety ──────────────────────────────────────

def _resolve_path(path_str: str) -> Path:
    """Resolve a path relative to workspace root, confined to WORKSPACE_ROOT."""
    p = Path(path_str)
    if not p.is_absolute():
        p = WORKSPACE_ROOT / p
    resolved = p.resolve()
    try:
        resolved.relative_to(WORKSPACE_ROOT)
    except ValueError:
        raise PermissionError(f"Access denied: {path_str!r} resolves outside workspace root")
    return resolved


# ── Tool execution ────────────────────────────────────────────────────

def execute_tool(name: str, arguments: dict[str, Any], tool_use_id: str = "") -> ToolResult:
    """Execute a tool by name with the given arguments."""
    try:
        dispatch = {
            "bash": _exec_bash,
            "file_read": _exec_file_read,
            "file_write": _exec_file_write,
            "file_edit": _exec_file_edit,
            "python_exec": _exec_python,
            "web_fetch": _exec_web_fetch,
            "list_directory": _exec_list_directory,
            "grep_search": _exec_grep_search,
            "glob_search": _exec_glob_search,
            "web_search": _exec_web_search,
            "multi_file_edit": _exec_multi_file_edit,
            "notebook_edit": _exec_notebook_edit,
        }
        fn = dispatch.get(name)
        if fn is None:
            return ToolResult(tool_use_id, name, f"Unknown tool: {name}", is_error=True)
        return fn(arguments, tool_use_id)
    except Exception as e:
        return ToolResult(tool_use_id, name, f"Error: {type(e).__name__}: {e}", is_error=True)


def _exec_bash(args: dict, tid: str) -> ToolResult:
    command = args.get("command", "")
    if not command:
        return ToolResult(tid, "bash", "No command provided.", is_error=True)
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=120,
            cwd=str(WORKSPACE_ROOT), env={**os.environ, "TERM": "dumb"},
        )
        parts = []
        if result.stdout:
            parts.append(result.stdout)
        if result.stderr:
            parts.append(f"[stderr]\n{result.stderr}")
        if result.returncode != 0:
            parts.append(f"[exit code: {result.returncode}]")
        output = "\n".join(parts) if parts else "(no output)"
    except subprocess.TimeoutExpired:
        return ToolResult(tid, "bash", "Command timed out after 120 seconds.", is_error=True)
    return ToolResult(tid, "bash", _truncate(output))


def _exec_file_read(args: dict, tid: str) -> ToolResult:
    path = _resolve_path(args.get("path", ""))
    if not path.is_file():
        return ToolResult(tid, "file_read", f"File not found: {path}", is_error=True)
    try:
        content = path.read_text(errors="replace")
    except Exception as e:
        return ToolResult(tid, "file_read", f"Cannot read file: {e}", is_error=True)
    start = args.get("start_line")
    end = args.get("end_line")
    if start is not None or end is not None:
        lines = content.splitlines(keepends=True)
        s = max(0, (start or 1) - 1)
        e = end or len(lines)
        content = "".join(lines[s:e])
    return ToolResult(tid, "file_read", _truncate(content, MAX_FILE_READ_CHARS))


def _exec_file_write(args: dict, tid: str) -> ToolResult:
    path = _resolve_path(args.get("path", ""))
    content = args.get("content", "")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return ToolResult(tid, "file_write", f"Wrote {len(content)} chars to {path}")


def _exec_file_edit(args: dict, tid: str) -> ToolResult:
    path = _resolve_path(args.get("path", ""))
    old_string = args.get("old_string", "")
    new_string = args.get("new_string", "")
    if not path.is_file():
        return ToolResult(tid, "file_edit", f"File not found: {path}", is_error=True)
    content = path.read_text()
    count = content.count(old_string)
    if count == 0:
        return ToolResult(tid, "file_edit", "old_string not found in file.", is_error=True)
    if count > 1:
        return ToolResult(tid, "file_edit", f"old_string found {count} times — must be unique.", is_error=True)
    new_content = content.replace(old_string, new_string, 1)
    path.write_text(new_content)
    return ToolResult(tid, "file_edit", f"Edited {path} — replaced 1 occurrence.")


def _exec_python(args: dict, tid: str) -> ToolResult:
    code = args.get("code", "")
    if not code:
        return ToolResult(tid, "python_exec", "No code provided.", is_error=True)
    try:
        result = subprocess.run(
            ["python3", "-c", code], capture_output=True, text=True,
            timeout=120, cwd=str(WORKSPACE_ROOT),
        )
        parts = []
        if result.stdout:
            parts.append(result.stdout)
        if result.stderr:
            parts.append(f"[stderr]\n{result.stderr}")
        if result.returncode != 0:
            parts.append(f"[exit code: {result.returncode}]")
        output = "\n".join(parts) if parts else "(no output)"
    except subprocess.TimeoutExpired:
        return ToolResult(tid, "python_exec", "Execution timed out after 120s.", is_error=True)
    return ToolResult(tid, "python_exec", _truncate(output))


def _exec_web_fetch(args: dict, tid: str) -> ToolResult:
    import urllib.request
    import urllib.error

    url = args.get("url", "")
    if not url:
        return ToolResult(tid, "web_fetch", "No URL provided.", is_error=True)
    if not url.startswith(("http://", "https://")):
        return ToolResult(tid, "web_fetch", "URL must start with http:// or https://", is_error=True)
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) StAgentChat/1.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        })
        with urllib.request.urlopen(req, timeout=30) as resp:
            content_type = resp.headers.get("Content-Type", "")
            raw = resp.read(500_000)
            charset = "utf-8"
            if "charset=" in content_type:
                charset = content_type.split("charset=")[-1].split(";")[0].strip()
            text = raw.decode(charset, errors="replace")
        if "html" in content_type.lower():
            text = _html_to_text(text)
        return ToolResult(tid, "web_fetch", _truncate(text))
    except urllib.error.HTTPError as e:
        return ToolResult(tid, "web_fetch", f"HTTP {e.code}: {e.reason}", is_error=True)
    except urllib.error.URLError as e:
        return ToolResult(tid, "web_fetch", f"URL error: {e.reason}", is_error=True)
    except Exception as e:
        return ToolResult(tid, "web_fetch", f"Fetch failed: {type(e).__name__}: {e}", is_error=True)


def _exec_list_directory(args: dict, tid: str) -> ToolResult:
    path = _resolve_path(args.get("path", "."))
    if not path.is_dir():
        return ToolResult(tid, "list_directory", f"Not a directory: {path}", is_error=True)
    entries = sorted(path.iterdir())
    lines = []
    for entry in entries[:200]:
        suffix = "/" if entry.is_dir() else ""
        lines.append(f"{entry.name}{suffix}")
    if len(entries) > 200:
        lines.append(f"... and {len(entries) - 200} more")
    return ToolResult(tid, "list_directory", "\n".join(lines))


def _exec_grep_search(args: dict, tid: str) -> ToolResult:
    pattern = args.get("pattern", "")
    if not pattern:
        return ToolResult(tid, "grep_search", "No pattern provided.", is_error=True)
    search_path = _resolve_path(args.get("path", "."))
    include = args.get("include", "")
    try:
        compiled = re.compile(pattern, re.IGNORECASE)
    except re.error as e:
        return ToolResult(tid, "grep_search", f"Invalid regex: {e}", is_error=True)

    results = []
    max_results = 100

    def _search_file(fp: Path):
        try:
            content = fp.read_text(errors="replace")
            for i, line in enumerate(content.splitlines(), 1):
                if compiled.search(line):
                    rel = fp.relative_to(WORKSPACE_ROOT)
                    results.append(f"{rel}:{i}: {line.rstrip()}")
                    if len(results) >= max_results:
                        return
        except (PermissionError, OSError):
            pass

    if search_path.is_file():
        _search_file(search_path)
    elif search_path.is_dir():
        for root, dirs, files in os.walk(search_path):
            dirs[:] = [d for d in dirs if d not in ('.git', '__pycache__', 'node_modules', '.venv', 'venv')]
            for f in files:
                if include and not fnmatch.fnmatch(f, include):
                    continue
                fp = Path(root) / f
                try:
                    fp.relative_to(WORKSPACE_ROOT)
                except ValueError:
                    continue
                _search_file(fp)
                if len(results) >= max_results:
                    break
            if len(results) >= max_results:
                break
    else:
        return ToolResult(tid, "grep_search", f"Path not found: {search_path}", is_error=True)

    if not results:
        return ToolResult(tid, "grep_search", "No matches found.")
    output = "\n".join(results)
    if len(results) >= max_results:
        output += f"\n... (limited to {max_results} matches)"
    return ToolResult(tid, "grep_search", _truncate(output))


def _exec_glob_search(args: dict, tid: str) -> ToolResult:
    pattern = args.get("pattern", "")
    if not pattern:
        return ToolResult(tid, "glob_search", "No pattern provided.", is_error=True)
    base = str(WORKSPACE_ROOT)
    full_pattern = os.path.join(base, pattern)
    matches = sorted(globmod.glob(full_pattern, recursive=True))
    # Filter to workspace
    safe_matches = []
    for m in matches:
        mp = Path(m).resolve()
        try:
            mp.relative_to(WORKSPACE_ROOT)
            rel = mp.relative_to(WORKSPACE_ROOT)
            suffix = "/" if mp.is_dir() else ""
            safe_matches.append(f"{rel}{suffix}")
        except ValueError:
            continue
    if not safe_matches:
        return ToolResult(tid, "glob_search", "No files matched.")
    output = "\n".join(safe_matches[:500])
    if len(safe_matches) > 500:
        output += f"\n... and {len(safe_matches) - 500} more"
    return ToolResult(tid, "glob_search", output)


def _exec_web_search(args: dict, tid: str) -> ToolResult:
    import urllib.request
    import urllib.parse
    import urllib.error

    query = args.get("query", "")
    if not query:
        return ToolResult(tid, "web_search", "No search query provided.", is_error=True)
    num = min(args.get("num_results", 5), 10)

    try:
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) StAgentChat/1.0",
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            html_content = resp.read(200_000).decode("utf-8", errors="replace")

        results = []
        # Extract result links and snippets from DDG HTML
        result_blocks = re.findall(
            r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>.*?'
            r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
            html_content, re.DOTALL
        )
        for href, title_html, snippet_html in result_blocks[:num]:
            title = re.sub(r'<[^>]+>', '', title_html).strip()
            snippet = re.sub(r'<[^>]+>', '', snippet_html).strip()
            # DDG wraps URLs in redirects
            actual_url = href
            if 'uddg=' in href:
                match = re.search(r'uddg=([^&]+)', href)
                if match:
                    actual_url = urllib.parse.unquote(match.group(1))
            results.append(f"**{title}**\n{actual_url}\n{snippet}\n")

        if not results:
            return ToolResult(tid, "web_search", f"No results found for: {query}")
        return ToolResult(tid, "web_search", "\n".join(results))
    except Exception as e:
        return ToolResult(tid, "web_search", f"Search failed: {type(e).__name__}: {e}", is_error=True)


def _exec_multi_file_edit(args: dict, tid: str) -> ToolResult:
    edits = args.get("edits", [])
    if not edits:
        return ToolResult(tid, "multi_file_edit", "No edits provided.", is_error=True)

    # Validation pass
    for i, edit in enumerate(edits):
        path = _resolve_path(edit.get("path", ""))
        if not path.is_file():
            return ToolResult(tid, "multi_file_edit", f"Edit {i}: file not found: {path}", is_error=True)
        content = path.read_text()
        old_string = edit.get("old_string", "")
        count = content.count(old_string)
        if count == 0:
            return ToolResult(tid, "multi_file_edit", f"Edit {i}: old_string not found in {path}", is_error=True)
        if count > 1:
            return ToolResult(tid, "multi_file_edit", f"Edit {i}: old_string found {count} times in {path}", is_error=True)

    # Apply all edits
    applied = []
    for edit in edits:
        path = _resolve_path(edit["path"])
        content = path.read_text()
        new_content = content.replace(edit["old_string"], edit["new_string"], 1)
        path.write_text(new_content)
        applied.append(str(path.relative_to(WORKSPACE_ROOT)))

    return ToolResult(tid, "multi_file_edit", f"Applied {len(applied)} edits: {', '.join(applied)}")


def _exec_notebook_edit(args: dict, tid: str) -> ToolResult:
    path = _resolve_path(args.get("path", ""))
    action = args.get("action", "")
    cell_index = args.get("cell_index", 0)

    if not path.is_file():
        return ToolResult(tid, "notebook_edit", f"File not found: {path}", is_error=True)
    if not str(path).endswith(".ipynb"):
        return ToolResult(tid, "notebook_edit", "Not a notebook file (.ipynb required).", is_error=True)

    try:
        nb = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        return ToolResult(tid, "notebook_edit", f"Invalid notebook JSON: {e}", is_error=True)

    cells = nb.get("cells", [])

    if action == "delete_cell":
        if cell_index < 0 or cell_index >= len(cells):
            return ToolResult(tid, "notebook_edit", f"Cell index {cell_index} out of range (0-{len(cells)-1}).", is_error=True)
        cells.pop(cell_index)
        nb["cells"] = cells
        path.write_text(json.dumps(nb, indent=1, ensure_ascii=False))
        return ToolResult(tid, "notebook_edit", f"Deleted cell {cell_index}.")

    cell_type = args.get("cell_type", "code")
    source = args.get("source", "")
    new_cell = {
        "cell_type": cell_type,
        "metadata": {},
        "source": source.splitlines(keepends=True),
    }
    if cell_type == "code":
        new_cell["execution_count"] = None
        new_cell["outputs"] = []

    if action == "insert_cell":
        idx = max(0, min(cell_index, len(cells)))
        cells.insert(idx, new_cell)
        nb["cells"] = cells
        path.write_text(json.dumps(nb, indent=1, ensure_ascii=False))
        return ToolResult(tid, "notebook_edit", f"Inserted {cell_type} cell at index {idx}.")

    if action == "replace_cell":
        if cell_index < 0 or cell_index >= len(cells):
            return ToolResult(tid, "notebook_edit", f"Cell index {cell_index} out of range.", is_error=True)
        cells[cell_index] = new_cell
        nb["cells"] = cells
        path.write_text(json.dumps(nb, indent=1, ensure_ascii=False))
        return ToolResult(tid, "notebook_edit", f"Replaced cell {cell_index} with {cell_type} cell.")

    return ToolResult(tid, "notebook_edit", f"Unknown action: {action}", is_error=True)


def summarize_args(args: dict) -> str:
    """Create a short summary of tool arguments for display."""
    if not args:
        return ""
    if "command" in args:
        cmd = args["command"]
        return cmd[:80] + ("…" if len(cmd) > 80 else "")
    if "pattern" in args:
        p = args["pattern"]
        return p[:60] + ("…" if len(p) > 60 else "")
    if "query" in args:
        q = args["query"]
        return q[:60] + ("…" if len(q) > 60 else "")
    if "path" in args:
        return args["path"]
    if "url" in args:
        return args["url"][:60]
    if "code" in args:
        code = args["code"]
        return code.split("\n")[0][:60] + ("…" if len(code) > 60 else "")
    if "edits" in args:
        return f"{len(args['edits'])} file edits"
    if "action" in args:
        return f"{args['action']} @ cell {args.get('cell_index', '?')}"
    return str(args)[:60]
