"""
AgentEngine — the agentic tool loop.

Manages multi-turn LLM ↔ tool conversations with streaming, extended thinking,
computer use, session persistence, and subagent support.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Generator
from uuid import uuid4

from .tools import TOOL_SCHEMAS, ToolResult, execute_tool, set_workspace_root, summarize_args
from .llm import LLMClient, LLMConfig, resolve_provider

MAX_AGENT_TURNS = 25


@dataclass(frozen=True)
class UsageSummary:
    input_tokens: int = 0
    output_tokens: int = 0
    thinking_tokens: int = 0

    def add(self, input_tokens: int, output_tokens: int, thinking_tokens: int = 0) -> "UsageSummary":
        return UsageSummary(
            self.input_tokens + input_tokens,
            self.output_tokens + output_tokens,
            self.thinking_tokens + thinking_tokens,
        )


@dataclass(frozen=True)
class AgentResult:
    output: str
    usage: UsageSummary
    tool_calls: list[dict[str, Any]]
    stop_reason: str
    thinking: str = ""


# ── Session persistence ──────────────────────────────────────────────

def _sessions_dir(workspace: str) -> Path:
    d = Path(workspace).resolve() / ".agent_sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_session(workspace: str, session_id: str, messages: list[dict], usage: UsageSummary) -> Path:
    """Persist a session to disk."""
    d = _sessions_dir(workspace)
    path = d / f"{session_id}.json"
    data = {
        "session_id": session_id,
        "messages": messages,
        "usage": {"input_tokens": usage.input_tokens, "output_tokens": usage.output_tokens, "thinking_tokens": usage.thinking_tokens},
        "saved_at": time.time(),
    }
    path.write_text(json.dumps(data, indent=2, default=str))
    return path


def load_session(workspace: str, session_id: str) -> dict | None:
    """Load a session from disk."""
    path = _sessions_dir(workspace) / f"{session_id}.json"
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def list_sessions(workspace: str) -> list[dict]:
    """List all saved sessions."""
    d = _sessions_dir(workspace)
    sessions = []
    for f in sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            data = json.loads(f.read_text())
            sessions.append({
                "session_id": data.get("session_id", f.stem),
                "message_count": len(data.get("messages", [])),
                "saved_at": data.get("saved_at", 0),
            })
        except (json.JSONDecodeError, OSError):
            continue
    return sessions


# ── Subagent ─────────────────────────────────────────────────────────

@dataclass
class SubagentConfig:
    """Configuration for a subagent with restricted tools and custom prompt."""
    name: str = "subagent"
    system_prompt: str = ""
    allowed_tools: list[str] | None = None  # None = all tools
    model: str = ""
    max_turns: int = 10


@dataclass
class AgentEngine:
    """Self-contained agentic engine with tool execution loop."""

    workspace: str = "."
    provider: str = ""
    model: str = ""
    api_key: str = ""
    max_turns: int = MAX_AGENT_TURNS
    max_tokens: int = 8192
    temperature: float = 0.7
    system_prompt: str = ""
    extended_thinking: bool = False
    thinking_budget: int = 10000
    computer_use: bool = False
    messages: list[dict] = field(default_factory=list)
    usage: UsageSummary = field(default_factory=UsageSummary)
    session_id: str = field(default_factory=lambda: uuid4().hex[:12])
    _client: LLMClient | None = field(default=None, repr=False)

    def __post_init__(self):
        ws = Path(self.workspace).resolve()
        ws.mkdir(parents=True, exist_ok=True)
        set_workspace_root(ws)

        # Auto-detect provider if none specified
        if not self.provider:
            self.provider, _ = resolve_provider("")

    @property
    def client(self) -> LLMClient:
        if self._client is None:
            cfg = LLMConfig(
                provider=self.provider,
                model=self.model,
                api_key=self.api_key,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                system_prompt=self._build_system_prompt(),
                extended_thinking=self.extended_thinking,
                thinking_budget=self.thinking_budget,
                computer_use=self.computer_use,
            )
            self._client = LLMClient(config=cfg)
        return self._client

    @property
    def is_configured(self) -> bool:
        cfg = LLMConfig(provider=self.provider, model=self.model, api_key=self.api_key)
        return cfg.is_configured

    def set_provider(self, provider: str, model: str = "", api_key: str = "") -> None:
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self._client = None  # Reset client to pick up new config

    def _build_system_prompt(self) -> str:
        if self.system_prompt:
            return self.system_prompt
        ws = Path(self.workspace).resolve()
        tools_section = (
            "YOUR TOOLS:\n"
            "- bash: Run any shell command (120s timeout)\n"
            "- file_read: Read files (full or line ranges, 100KB max)\n"
            "- file_write: Create or overwrite files (auto-creates directories)\n"
            "- file_edit: Search-and-replace in files (requires exact unique match)\n"
            "- python_exec: Execute Python code in a subprocess\n"
            "- web_fetch: Fetch and extract text from URLs\n"
            "- web_search: Search the web via DuckDuckGo\n"
            "- list_directory: List files and folders\n"
            "- grep_search: Search file contents with regex patterns\n"
            "- glob_search: Find files by glob pattern (e.g. **/*.py)\n"
            "- multi_file_edit: Apply multiple file edits atomically\n"
            "- notebook_edit: Edit Jupyter notebook cells\n"
        )
        return (
            "You are a powerful AI coding agent with full access to the user's development environment.\n\n"
            f"{tools_section}\n"
            f"WORKSPACE: {ws}\n\n"
            "GUIDELINES:\n"
            "- ALWAYS use tools to accomplish tasks. Don't say you can't — try it.\n"
            "- Chain multiple tool calls for complex tasks.\n"
            "- Be proactive — take action rather than just suggesting.\n"
            "- Read files before editing them to understand context.\n"
            "- Use grep_search and glob_search to explore unfamiliar codebases.\n"
            "- Use web_search to find documentation, examples, and solutions.\n"
            "- After making changes, verify they work (run tests, check syntax).\n"
            "- If one approach fails, try another — be persistent.\n"
            "- Keep responses focused and actionable.\n"
        )

    def reset(self) -> None:
        """Clear conversation history."""
        self.messages = []
        self.usage = UsageSummary()
        self.session_id = uuid4().hex[:12]
        self._client = None

    def save(self) -> Path:
        """Save the current session to disk."""
        return save_session(self.workspace, self.session_id, self.messages, self.usage)

    def load(self, session_id: str) -> bool:
        """Load a session from disk. Returns True if successful."""
        data = load_session(self.workspace, session_id)
        if not data:
            return False
        self.session_id = data["session_id"]
        self.messages = data.get("messages", [])
        u = data.get("usage", {})
        self.usage = UsageSummary(
            u.get("input_tokens", 0),
            u.get("output_tokens", 0),
            u.get("thinking_tokens", 0),
        )
        return True

    def _get_tool_schemas(self, allowed_tools: list[str] | None = None) -> list[dict]:
        """Get tool schemas, optionally filtered."""
        if allowed_tools is None:
            return TOOL_SCHEMAS
        return [t for t in TOOL_SCHEMAS if t["name"] in allowed_tools]

    def submit(self, prompt: str) -> AgentResult:
        """Submit a message and run the full agentic tool loop."""
        return self._run_loop(prompt, TOOL_SCHEMAS, self.max_turns)

    def run_subagent(self, prompt: str, config: SubagentConfig | None = None) -> AgentResult:
        """Run a subagent with optionally restricted tools and custom prompt."""
        cfg = config or SubagentConfig()
        schemas = self._get_tool_schemas(cfg.allowed_tools)
        max_t = cfg.max_turns or 10

        # Temporarily override system prompt and model if specified
        saved_prompt = self.system_prompt
        saved_model = self.model
        saved_client = self._client

        if cfg.system_prompt:
            self.system_prompt = cfg.system_prompt
            self._client = None
        if cfg.model:
            self.model = cfg.model
            self._client = None

        try:
            result = self._run_loop(prompt, schemas, max_t, use_session=False)
        finally:
            self.system_prompt = saved_prompt
            self.model = saved_model
            self._client = saved_client

        return result

    def _run_loop(self, prompt: str, tool_schemas: list[dict], max_turns: int, use_session: bool = True) -> AgentResult:
        """Core agentic tool loop with thinking support."""
        if not self.is_configured:
            return AgentResult(
                output="No LLM provider configured. Set an API key in your environment.",
                usage=self.usage, tool_calls=[], stop_reason="no_provider",
            )

        client = self.client
        if use_session:
            messages = list(self.messages[-20:])
        else:
            messages = []
        messages.append({"role": "user", "content": prompt})

        full_output = ""
        full_thinking = ""
        total_in = 0
        total_out = 0
        total_think = 0
        all_tool_calls: list[dict] = []
        stop_reason = "end_turn"
        is_anthropic = self.provider == "anthropic"

        for _turn in range(max_turns):
            response = client.complete(messages, tools=tool_schemas)
            total_in += response.input_tokens
            total_out += response.output_tokens
            total_think += response.thinking_tokens
            stop_reason = response.stop_reason

            if response.thinking:
                full_thinking += response.thinking

            if response.content:
                full_output += response.content

            if not response.tool_calls:
                break

            all_tool_calls.extend(response.tool_calls)

            if is_anthropic:
                assistant_content = []
                if response.thinking:
                    assistant_content.append({"type": "thinking", "thinking": response.thinking})
                if response.content:
                    assistant_content.append({"type": "text", "text": response.content})
                for tc in response.tool_calls:
                    assistant_content.append({
                        "type": "tool_use", "id": tc["id"],
                        "name": tc["name"], "input": tc["arguments"],
                    })
                messages.append({"role": "assistant", "content": assistant_content})
                tool_results = []
                for tc in response.tool_calls:
                    result = execute_tool(tc["name"], tc["arguments"], tc["id"])
                    tool_results.append({
                        "type": "tool_result", "tool_use_id": tc["id"],
                        "content": result.output, "is_error": result.is_error,
                    })
                messages.append({"role": "user", "content": tool_results})
            else:
                openai_tcs = [{
                    "id": tc["id"], "type": "function",
                    "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])},
                } for tc in response.tool_calls]
                messages.append({
                    "role": "assistant", "content": response.content or None,
                    "tool_calls": openai_tcs,
                })
                for tc in response.tool_calls:
                    result = execute_tool(tc["name"], tc["arguments"], tc["id"])
                    messages.append({"role": "tool", "tool_call_id": tc["id"], "content": result.output})

        if use_session:
            self.usage = self.usage.add(total_in, total_out, total_think)
            self.messages.append({"role": "user", "content": prompt})
            self.messages.append({"role": "assistant", "content": full_output})
            if len(self.messages) > 40:
                self.messages = self.messages[-30:]

        return AgentResult(
            output=full_output, usage=self.usage if use_session else UsageSummary(total_in, total_out, total_think),
            tool_calls=all_tool_calls, stop_reason=stop_reason, thinking=full_thinking,
        )

    def stream_submit(self, prompt: str) -> Generator[dict, None, None]:
        """Stream a response, yielding events for UI rendering."""
        if not self.is_configured:
            yield {"type": "error", "text": "No LLM provider configured."}
            return

        client = self.client
        messages = list(self.messages[-20:])
        messages.append({"role": "user", "content": prompt})

        full_output = ""
        total_in = 0
        total_out = 0
        total_think = 0
        is_anthropic = self.provider == "anthropic"

        yield {"type": "start", "session_id": self.session_id}

        for _turn in range(self.max_turns):
            response = client.complete(messages, tools=TOOL_SCHEMAS)
            total_in += response.input_tokens
            total_out += response.output_tokens
            total_think += response.thinking_tokens

            if response.thinking:
                yield {"type": "thinking", "text": response.thinking}

            if response.content:
                full_output += response.content
                yield {"type": "text", "text": response.content}

            if not response.tool_calls:
                break

            for tc in response.tool_calls:
                yield {
                    "type": "tool_start",
                    "name": tc["name"],
                    "args": tc["arguments"],
                    "summary": summarize_args(tc["arguments"]),
                }

            if is_anthropic:
                assistant_content = []
                if response.thinking:
                    assistant_content.append({"type": "thinking", "thinking": response.thinking})
                if response.content:
                    assistant_content.append({"type": "text", "text": response.content})
                for tc in response.tool_calls:
                    assistant_content.append({
                        "type": "tool_use", "id": tc["id"],
                        "name": tc["name"], "input": tc["arguments"],
                    })
                messages.append({"role": "assistant", "content": assistant_content})
                tool_results = []
                for tc in response.tool_calls:
                    result = execute_tool(tc["name"], tc["arguments"], tc["id"])
                    tool_results.append({
                        "type": "tool_result", "tool_use_id": tc["id"],
                        "content": result.output, "is_error": result.is_error,
                    })
                    yield {
                        "type": "tool_result",
                        "name": tc["name"],
                        "output": result.output[:500],
                        "success": not result.is_error,
                    }
                messages.append({"role": "user", "content": tool_results})
            else:
                openai_tcs = [{
                    "id": tc["id"], "type": "function",
                    "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])},
                } for tc in response.tool_calls]
                messages.append({
                    "role": "assistant", "content": response.content or None,
                    "tool_calls": openai_tcs,
                })
                for tc in response.tool_calls:
                    result = execute_tool(tc["name"], tc["arguments"], tc["id"])
                    messages.append({"role": "tool", "tool_call_id": tc["id"], "content": result.output})
                    yield {
                        "type": "tool_result",
                        "name": tc["name"],
                        "output": result.output[:500],
                        "success": not result.is_error,
                    }

        self.usage = self.usage.add(total_in, total_out, total_think)
        self.messages.append({"role": "user", "content": prompt})
        self.messages.append({"role": "assistant", "content": full_output})

        if len(self.messages) > 40:
            self.messages = self.messages[-30:]

        yield {
            "type": "done",
            "usage": {
                "input_tokens": self.usage.input_tokens,
                "output_tokens": self.usage.output_tokens,
                "thinking_tokens": self.usage.thinking_tokens,
            },
        }
