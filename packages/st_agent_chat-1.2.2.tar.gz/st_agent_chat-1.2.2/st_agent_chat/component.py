"""
st_agent_chat.component — Drop-in agentic AI chat widget for Streamlit.

Zero config needed — API keys can be entered inline. No sidebar. No .env required.
Everything self-contained in one sleek, modern component.

Usage:
    from st_agent_chat import agent_chat
    agent_chat(workspace=".")
"""
from __future__ import annotations

import html as html_mod
import os
from pathlib import Path

import streamlit as st

from .engine import AgentEngine, SubagentConfig, list_sessions
from .llm import (
    ALL_ANTHROPIC_MODELS,
    ALL_OPENAI_MODELS,
    ALL_GOOGLE_MODELS,
    ALL_PERPLEXITY_MODELS,
    ALL_REPLICATE_MODELS,
    ALL_OPENROUTER_MODELS,
    PROVIDER_ENV_KEYS,
    LLMConfig,
    resolve_provider,
)
from .tools import summarize_args


# ── CSS — modern glass-morphism, fully scoped with .sac- prefix ──────

_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&family=Inter:wght@300;400;500;600;700&display=swap');

:root {
    --sac-bg: #08090d;
    --sac-surface: #0c1017;
    --sac-surface2: #111820;
    --sac-surface3: #171f2b;
    --sac-glass: rgba(12, 16, 23, 0.72);
    --sac-glass2: rgba(17, 24, 32, 0.65);
    --sac-border: rgba(255, 255, 255, 0.06);
    --sac-border-bright: rgba(255, 255, 255, 0.10);
    --sac-border-focus: rgba(96, 165, 250, 0.35);
    --sac-text: #e8ecf1;
    --sac-text-dim: #8b95a5;
    --sac-text-muted: #505b6b;
    --sac-accent: #6ea8fe;
    --sac-accent-glow: rgba(110, 168, 254, 0.12);
    --sac-green: #3ddba0;
    --sac-green-glow: rgba(61, 219, 160, 0.10);
    --sac-orange: #f0b54a;
    --sac-orange-glow: rgba(240, 181, 74, 0.10);
    --sac-red: #f27272;
    --sac-cyan: #3dd8e8;
    --sac-purple: #a78bfa;
    --sac-r: 14px;
    --sac-r-sm: 10px;
    --sac-r-xs: 6px;
    --sac-shadow: 0 2px 12px rgba(0,0,0,0.25);
    --sac-shadow-lg: 0 8px 32px rgba(0,0,0,0.35);
    --sac-transition: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

/* ── Top bar ── */
.sac-bar {
    background: var(--sac-glass);
    backdrop-filter: blur(24px) saturate(170%);
    -webkit-backdrop-filter: blur(24px) saturate(170%);
    border: 1px solid var(--sac-border);
    border-radius: var(--sac-r);
    padding: 7px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    margin-bottom: 10px;
    box-shadow: var(--sac-shadow);
    position: relative;
    overflow: visible;
}
.sac-bar::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent 0%, rgba(110,168,254,0.20) 50%, transparent 100%);
    border-radius: var(--sac-r) var(--sac-r) 0 0;
}
.sac-logo {
    display: flex; align-items: center; gap: 6px;
    font-size: 14px; font-weight: 700;
    color: var(--sac-text);
    letter-spacing: -0.3px;
    user-select: none;
}
.sac-logo span { color: var(--sac-accent); }
.sac-sep {
    width: 1px; height: 16px;
    background: var(--sac-border-bright);
    flex-shrink: 0;
}
.sac-pill {
    background: var(--sac-glass2);
    border: 1px solid var(--sac-border);
    border-radius: 100px;
    padding: 3px 9px;
    font-size: 10px;
    font-weight: 500;
    font-family: 'JetBrains Mono', monospace;
    color: var(--sac-text-muted);
    display: inline-flex;
    align-items: center;
    gap: 5px;
    transition: all var(--sac-transition);
    white-space: nowrap;
}
.sac-pill.on { color: var(--sac-green); border-color: rgba(61,219,160,0.18); }
.sac-pill.think { color: var(--sac-orange); border-color: rgba(240,181,74,0.18); }
.sac-dot {
    width: 6px; height: 6px; border-radius: 50%;
    display: inline-block; flex-shrink: 0;
}
.sac-dot.green { background: var(--sac-green); box-shadow: 0 0 6px var(--sac-green-glow); }
.sac-dot.amber { background: var(--sac-orange); box-shadow: 0 0 6px var(--sac-orange-glow); }
.sac-dot.off { background: var(--sac-text-muted); }
.sac-spacer { flex: 1; }
.sac-sid {
    font-family: 'JetBrains Mono', monospace;
    font-size: 9px; color: var(--sac-text-muted);
    opacity: 0.5;
}

/* ── Onboarding / key entry ── */
.sac-onboard {
    background: var(--sac-glass);
    backdrop-filter: blur(24px) saturate(170%);
    -webkit-backdrop-filter: blur(24px) saturate(170%);
    border: 1px solid var(--sac-border);
    border-radius: var(--sac-r);
    padding: 28px 24px;
    text-align: center;
    font-family: 'Inter', sans-serif;
    box-shadow: var(--sac-shadow-lg);
    position: relative;
    overflow: hidden;
}
.sac-onboard::before {
    content: '';
    position: absolute;
    top: -50%; left: -50%; width: 200%; height: 200%;
    background: radial-gradient(ellipse at center, var(--sac-accent-glow) 0%, transparent 65%);
    pointer-events: none;
}
.sac-onboard h3 {
    font-size: 18px; font-weight: 700; color: var(--sac-text);
    margin: 0 0 4px; letter-spacing: -0.3px;
}
.sac-onboard p {
    font-size: 12px; color: var(--sac-text-dim);
    margin: 0 0 16px; line-height: 1.5;
}
.sac-onboard .sac-hint {
    font-size: 10px; color: var(--sac-text-muted);
    margin-top: 12px;
    font-family: 'JetBrains Mono', monospace;
}

/* ── Tool cards ── */
.sac-tc {
    background: var(--sac-glass2);
    border: 1px solid var(--sac-border);
    border-radius: var(--sac-r-sm);
    padding: 10px 14px;
    margin: 8px 0;
    font-family: 'JetBrains Mono', monospace;
    transition: border-color var(--sac-transition);
}
.sac-tc:hover { border-color: var(--sac-border-bright); }
.sac-tc .sac-tc-head {
    display: flex; align-items: center; gap: 6px;
    margin-bottom: 4px;
}
.sac-tc .sac-tc-name {
    font-size: 11px; font-weight: 600; color: var(--sac-cyan);
}
.sac-tc .sac-tc-icon { font-size: 12px; }
.sac-tc .sac-tc-args {
    font-size: 10px; color: var(--sac-text-muted);
}
.sac-tc .sac-tc-out {
    background: var(--sac-bg);
    border-radius: var(--sac-r-xs);
    padding: 8px 10px;
    margin-top: 6px;
    font-size: 10.5px;
    color: var(--sac-text-dim);
    max-height: 110px;
    overflow-y: auto;
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.45;
}
.sac-tc.ok { border-left: 2px solid var(--sac-green); }
.sac-tc.err { border-left: 2px solid var(--sac-red); }

/* ── Thinking block ── */
.sac-think {
    background: linear-gradient(135deg, var(--sac-glass2), rgba(240,181,74,0.04));
    border: 1px solid var(--sac-border);
    border-left: 2px solid var(--sac-orange);
    border-radius: var(--sac-r-sm);
    padding: 10px 14px;
    margin: 8px 0;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--sac-text-dim);
    max-height: 140px;
    overflow-y: auto;
    white-space: pre-wrap;
    line-height: 1.5;
}
.sac-think-label {
    font-size: 10px; font-weight: 600;
    color: var(--sac-orange);
    margin-bottom: 6px;
    display: flex; align-items: center; gap: 5px;
    letter-spacing: 0.3px; text-transform: uppercase;
}

/* ── Cost footer ── */
.sac-cost {
    text-align: right;
    font-size: 10px;
    color: var(--sac-text-muted);
    font-family: 'JetBrains Mono', monospace;
    margin-top: 8px;
    opacity: 0.7;
}
</style>
"""

_TOOL_ICONS = {
    "bash": "⚡", "file_read": "📖", "file_write": "✏️", "file_edit": "🔧",
    "python_exec": "🐍", "web_fetch": "🌐", "web_search": "🔍",
    "list_directory": "📂", "grep_search": "🔎", "glob_search": "📁",
    "multi_file_edit": "📝", "notebook_edit": "📓",
}


def _format_tool_card(name: str, args_summary: str, output: str, success: bool) -> str:
    cls = "ok" if success else "err"
    icon = _TOOL_ICONS.get(name, "🔧")
    safe_output = html_mod.escape((output or "")[:500])
    safe_args = html_mod.escape(args_summary or "")
    return (
        f'<div class="sac-tc {cls}">'
        f'<div class="sac-tc-head"><span class="sac-tc-icon">{icon}</span>'
        f'<span class="sac-tc-name">{name}</span></div>'
        f'<div class="sac-tc-args">{safe_args}</div>'
        f'<div class="sac-tc-out">{safe_output}</div>'
        f'</div>'
    )


def _format_thinking_card(thinking: str) -> str:
    safe = html_mod.escape((thinking or "")[:800])
    return (
        '<div class="sac-think">'
        '<div class="sac-think-label">🧠 Extended Thinking</div>'
        f'{safe}'
        '</div>'
    )


_ALL_PROVIDERS = {
    "anthropic": ("Anthropic (Claude)", ALL_ANTHROPIC_MODELS, "ANTHROPIC_API_KEY"),
    "openai": ("OpenAI (GPT / o-series)", ALL_OPENAI_MODELS, "OPENAI_API_KEY"),
    "google": ("Google (Gemini)", ALL_GOOGLE_MODELS, "GOOGLE_API_KEY"),
    "perplexity": ("Perplexity (Sonar)", ALL_PERPLEXITY_MODELS, "PERPLEXITY_API_KEY"),
    "replicate": ("Replicate (Llama)", ALL_REPLICATE_MODELS, "REPLICATE_API_TOKEN"),
    "openrouter": ("OpenRouter (Multi)", ALL_OPENROUTER_MODELS, "OPENROUTER_API_KEY"),
}


def agent_chat(
    workspace: str = ".",
    provider: str = "",
    model: str = "",
    api_key: str = "",
    max_turns: int = 25,
    max_tokens: int = 8192,
    temperature: float = 0.7,
    system_prompt: str = "",
    extended_thinking: bool = False,
    thinking_budget: int = 10000,
    computer_use: bool = False,
    show_config: bool = True,
    show_cost: bool = True,
    key: str | None = None,
) -> None:
    """Render a self-contained agentic AI chat interface.

    Everything renders inline — no sidebar. API keys can be entered
    directly in the UI, no .env file required. Drop it into any
    Streamlit column, tab, or container.
    """
    wk = key or "sac"

    # ── Inject CSS once ──
    if f"{wk}_css_injected" not in st.session_state:
        st.session_state[f"{wk}_css_injected"] = True
    st.markdown(_CSS, unsafe_allow_html=True)

    # ── Session state ──
    sk = f"{wk}_state"
    if sk not in st.session_state:
        det_prov = provider
        if not det_prov:
            det_prov, _ = resolve_provider("")
        st.session_state[sk] = {
            "engine": AgentEngine(
                workspace=workspace, provider=det_prov, model=model,
                api_key=api_key, max_turns=max_turns, max_tokens=max_tokens,
                temperature=temperature, system_prompt=system_prompt,
                extended_thinking=extended_thinking,
                thinking_budget=thinking_budget, computer_use=computer_use,
            ),
            "messages": [],
            "turn_count": 0,
            "tool_calls": 0,
        }

    state = st.session_state[sk]
    engine: AgentEngine = state["engine"]
    llm_on = engine.is_configured

    # ── Top bar ──
    model_display = (
        LLMConfig(provider=engine.provider, model=engine.model).resolved_model
        if llm_on else "no key"
    )
    u = engine.usage
    total_tok = u.input_tokens + u.output_tokens + u.thinking_tokens
    dot_cls = "green" if llm_on else "off"
    pill_cls = "on" if llm_on else ""
    think_part = f' <span class="sac-pill think">🧠 {u.thinking_tokens:,}</span>' if u.thinking_tokens else ""

    st.markdown(f"""
    <div class="sac-bar">
        <div class="sac-logo">⚡ Agent<span>Chat</span></div>
        <div class="sac-sep"></div>
        <span class="sac-pill {pill_cls}"><span class="sac-dot {dot_cls}"></span>{model_display}</span>
        <span class="sac-spacer"></span>
        <span class="sac-pill">{total_tok:,} tok · T{state['turn_count']}</span>{think_part}
        <span class="sac-sid">{engine.session_id}</span>
    </div>
    """, unsafe_allow_html=True)

    # ── Settings + API key entry (inline, no sidebar) ──
    if show_config:
        with st.popover("⚙ Settings", use_container_width=False):
            # Provider & model
            prov_labels = list(_ALL_PROVIDERS.keys())
            cur_idx = prov_labels.index(engine.provider) if engine.provider in prov_labels else 0
            sel_prov = st.selectbox(
                "Provider", prov_labels, index=cur_idx,
                format_func=lambda x: _ALL_PROVIDERS[x][0],
                key=f"{wk}_prov",
            )
            model_opts = _ALL_PROVIDERS[sel_prov][1]
            cur_mod = model_opts.index(engine.model) if engine.model in model_opts else 0
            sel_model = st.selectbox("Model", model_opts, index=cur_mod, key=f"{wk}_model")

            # ── Inline API key entry ──
            env_var = _ALL_PROVIDERS[sel_prov][2]
            has_env_key = bool(os.environ.get(env_var, ""))
            if has_env_key:
                st.caption(f"✅ `{env_var}` found in environment")
            entered_key = st.text_input(
                f"API Key ({_ALL_PROVIDERS[sel_prov][0]})",
                type="password",
                placeholder=f"Paste your {env_var} here…" if not has_env_key else "Override env key (optional)",
                key=f"{wk}_apikey",
                label_visibility="collapsed" if has_env_key else "visible",
            )

            c1, c2 = st.columns(2)
            with c1:
                if st.button("⚡ Connect", use_container_width=True, key=f"{wk}_connect"):
                    final_key = entered_key.strip() or ""
                    engine.set_provider(sel_prov, sel_model, final_key)
                    # Also set in environment so LLMConfig.resolved_key finds it
                    if final_key:
                        os.environ[env_var] = final_key
                    engine._client = None
                    st.rerun()
            with c2:
                if st.button("🔄 New Chat", use_container_width=True, key=f"{wk}_new"):
                    engine.reset()
                    state["messages"] = []
                    state["turn_count"] = 0
                    state["tool_calls"] = 0
                    st.rerun()

            # ── Advanced toggles ──
            st.divider()
            t1, t2 = st.columns(2)
            with t1:
                think_on = st.toggle("🧠 Thinking", value=engine.extended_thinking, key=f"{wk}_think")
                if think_on != engine.extended_thinking:
                    engine.extended_thinking = think_on
                    engine._client = None
            with t2:
                comp_on = st.toggle("🖥️ Computer", value=engine.computer_use, key=f"{wk}_comp")
                if comp_on != engine.computer_use:
                    engine.computer_use = comp_on
                    engine._client = None
            if think_on:
                budget = st.slider(
                    "Thinking budget", 1000, 50000,
                    engine.thinking_budget, 1000, key=f"{wk}_budget",
                )
                if budget != engine.thinking_budget:
                    engine.thinking_budget = budget
                    engine._client = None

            # ── Sessions ──
            st.divider()
            sc1, sc2 = st.columns(2)
            with sc1:
                if st.button("💾 Save", use_container_width=True, key=f"{wk}_save"):
                    engine.save()
                    st.toast(f"Saved: {engine.session_id}")
            with sc2:
                sessions = list_sessions(engine.workspace)
                if sessions:
                    sel_session = st.selectbox(
                        "Session", [s["session_id"] for s in sessions],
                        key=f"{wk}_load_sel", label_visibility="collapsed",
                    )
                    if st.button("📂 Load", use_container_width=True, key=f"{wk}_load"):
                        if engine.load(sel_session):
                            state["messages"] = []
                            state["turn_count"] = 0
                            state["tool_calls"] = 0
                            st.toast(f"Loaded: {sel_session}")
                            st.rerun()

    # ── Onboarding: prominent API key entry when not configured ──
    if not llm_on:
        st.markdown("""
        <div class="sac-onboard">
            <h3>Welcome to AgentChat</h3>
            <p>Connect an AI provider to get started. Enter your API key below.</p>
        </div>
        """, unsafe_allow_html=True)

        # Inline key entry — right in the main body, impossible to miss
        ob_prov_labels = list(_ALL_PROVIDERS.keys())
        ob_cur = ob_prov_labels.index(engine.provider) if engine.provider in ob_prov_labels else 0
        ob_sel = st.selectbox(
            "Provider", ob_prov_labels, index=ob_cur,
            format_func=lambda x: _ALL_PROVIDERS[x][0],
            key=f"{wk}_ob_prov",
        )
        ob_models = _ALL_PROVIDERS[ob_sel][1]
        ob_model = st.selectbox("Model", ob_models, key=f"{wk}_ob_model")
        ob_env = _ALL_PROVIDERS[ob_sel][2]
        ob_key = st.text_input(
            f"🔑 {ob_env}",
            type="password",
            placeholder=f"Paste your {ob_env} here…",
            key=f"{wk}_ob_key",
        )
        if st.button("⚡ Connect", use_container_width=True, key=f"{wk}_ob_connect", type="primary"):
            final = ob_key.strip()
            if final:
                os.environ[ob_env] = final
                engine.set_provider(ob_sel, ob_model, final)
                engine._client = None
                st.rerun()
            else:
                st.error("Please paste an API key above.")
        st.caption("Keys stay in memory only — never written to disk.")
        return  # Don't render chat until connected

    # ── Render messages ──
    for msg in state["messages"]:
        role = msg["role"]
        if role == "user":
            with st.chat_message("user", avatar="👤"):
                st.markdown(msg["content"])
        elif role == "assistant":
            with st.chat_message("assistant", avatar="⚡"):
                st.markdown(msg["content"], unsafe_allow_html=True)

    # ── Chat input ──
    if prompt := st.chat_input("Ask anything…", key=f"{wk}_input"):
        state["messages"].append({"role": "user", "content": prompt})
        with st.chat_message("user", avatar="👤"):
            st.markdown(prompt)

        with st.chat_message("assistant", avatar="⚡"):
            with st.spinner(""):
                result = engine.submit(prompt)

            state["turn_count"] += 1
            parts = []

            if result.thinking:
                parts.append(_format_thinking_card(result.thinking))

            if result.tool_calls:
                for tc in result.tool_calls:
                    state["tool_calls"] += 1

            parts.append(result.output)

            if show_cost:
                think_info = f" · 🧠{result.usage.thinking_tokens:,}" if result.usage.thinking_tokens else ""
                parts.append(
                    f'<div class="sac-cost">'
                    f'{result.usage.input_tokens:,}↓ {result.usage.output_tokens:,}↑{think_info}'
                    f' · T{state["turn_count"]} · {state["tool_calls"]} calls</div>'
                )

            full = "\n".join(parts)
            st.markdown(full, unsafe_allow_html=True)
            state["messages"].append({"role": "assistant", "content": full})
