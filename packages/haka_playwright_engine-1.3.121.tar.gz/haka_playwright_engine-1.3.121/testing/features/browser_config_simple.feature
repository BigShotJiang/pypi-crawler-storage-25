Feature: Simple Browser Configuration Test
  As a QA engineer
  I want to verify basic browser configuration functionality
  So that I can ensure the browser configuration system works

  @browser_config @simple @smoke
  Scenario: Basic browser configuration test
    Given I clear all browser arguments
    And I clear all browser preferences
    When I set browser argument "--no-sandbox"
    And I set browser argument "--disable-dev-shm-usage"
    And I show current browser configuration
    Then I should see browser configuration output

  @browser_config @simple @chrome_flags
  Scenario: Chrome flags configuration test
    Given I clear all browser arguments
    When I set Chrome flag "disable-web-security" to "true"
    And I set Chrome flag "log-level" to "INFO"
    And I show current browser configuration
    Then I should see browser configuration output

  @browser_config @simple @preferences
  Scenario: Browser preferences test
    Given I clear all browser preferences
    When I set browser preference "profile.default_content_setting_values.notifications" to "2"
    And I set browser preference "download.prompt_for_download" to "false"
    And I show current browser configuration
    Then I should see browser configuration output

  @browser_config @simple @performance
  Scenario: Performance mode test
    Given I clear all browser arguments
    When I enable browser performance mode
    And I show current browser configuration
    Then I should see browser configuration output

  @browser_config @simple @mobile
  Scenario: Mobile configuration test
    Given I clear all browser arguments
    When I configure browser for mobile testing
    And I show current browser configuration
    Then I should see browser configuration output

  @browser_config @simple @config_file
  Scenario: Load configuration from file test
    Given I clear all browser arguments
    And I clear all browser preferences
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/chrome_performance.json"
    And I show current browser configuration
    Then I should see browser configuration output