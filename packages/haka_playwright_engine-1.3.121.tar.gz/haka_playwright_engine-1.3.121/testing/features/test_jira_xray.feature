# language: es
@PROD-145
Feature: Testing de integración Jira/Xray
  Como desarrollador del framework
  Quiero probar la integración automática con Jira/Xray
  Para verificar que los tests se vinculan correctamente a la HU

  @PROD-146
  Scenario: Test básico de navegación
    Given voy a la url "https://example.com"
    When tomo un screenshot con nombre "test_navegacion"
    Then debería ver el elemento "h1" con identificador "tag"

  @PROD-147
  Scenario: Test de verificación de título
    Given voy a la url "https://httpbin.org"
    When tomo un screenshot con nombre "test_titulo"
    Then el título de la página debería contener "httpbin"

  @PROD-148
  Scenario: Test que falla intencionalmente
    Given voy a la url "https://example.com"
    When tomo un screenshot con nombre "test_fallo"
    Then debería ver el elemento "elemento_inexistente" con identificador "id"