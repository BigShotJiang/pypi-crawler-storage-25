Feature: Browser Configuration Validation
  As a QA engineer
  I want to validate that browser configuration options work correctly
  So that I can ensure proper browser setup for different testing scenarios

  Background:
    Given I clear all browser arguments
    And I clear all browser preferences

  @browser_config @smoke
  Scenario: Validate basic browser argument configuration
    When I set browser argument "--no-sandbox"
    And I set browser argument "--disable-dev-shm-usage"
    And I show current browser configuration
    Then the browser should have 2 arguments configured

  @browser_config @chrome_flags
  Scenario: Validate Chrome flag configuration
    When I set Chrome flag "disable-web-security" to "true"
    And I set Chrome flag "log-level" to "INFO"
    And I show current browser configuration
    Then the browser should have Chrome flags configured correctly

  @browser_config @experimental_features
  Scenario: Validate Chrome experimental features
    When I enable Chrome experimental feature "WebUIDarkMode"
    And I disable Chrome experimental feature "AutofillServerCommunication"
    And I show current browser configuration
    Then the browser should have experimental features configured

  @browser_config @preferences
  Scenario: Validate browser preferences configuration
    When I set browser preference "profile.default_content_setting_values.notifications" to "2"
    And I set browser preference "download.prompt_for_download" to "false"
    And I set browser preference "safebrowsing.enabled" to "true"
    And I show current browser configuration
    Then the browser should have 3 preferences configured

  @browser_config @download_behavior
  Scenario: Validate download behavior configuration
    When I set browser download behavior to "auto" with path "test_downloads"
    And I show current browser configuration
    Then the browser should have download configuration set

  @browser_config @proxy
  Scenario: Validate proxy configuration
    When I set browser proxy to "http://proxy.example.com:8080"
    And I show current browser configuration
    Then the browser should have proxy configured

  @browser_config @security_disabled
  Scenario: Validate security features disabled configuration
    When I disable browser security features
    And I show current browser configuration
    Then the browser should have security features disabled

  @browser_config @performance_mode
  Scenario: Validate performance mode configuration
    When I enable browser performance mode
    And I show current browser configuration
    Then the browser should have performance optimizations enabled

  @browser_config @memory_limit
  Scenario: Validate memory limit configuration
    When I set browser memory limit to "2048" MB
    And I show current browser configuration
    Then the browser should have memory limit configured

  @browser_config @mobile_testing
  Scenario: Validate mobile testing configuration
    When I configure browser for mobile testing
    And I show current browser configuration
    Then the browser should be configured for mobile testing

  @browser_config @cicd_environment
  Scenario: Validate CI/CD environment configuration
    When I configure browser for CI/CD environment
    And I show current browser configuration
    Then the browser should be configured for CI/CD

  @browser_config @preset_performance
  Scenario: Validate performance preset configuration
    Given I set environment variable "BROWSER_CONFIG_PRESET" to "performance"
    When I load browser configuration from preset
    And I show current browser configuration
    Then the browser should have performance preset applied

  @browser_config @preset_mobile
  Scenario: Validate mobile preset configuration
    Given I set environment variable "BROWSER_CONFIG_PRESET" to "mobile"
    When I load browser configuration from preset
    And I show current browser configuration
    Then the browser should have mobile preset applied

  @browser_config @preset_cicd
  Scenario: Validate CI/CD preset configuration
    Given I set environment variable "BROWSER_CONFIG_PRESET" to "cicd"
    When I load browser configuration from preset
    And I show current browser configuration
    Then the browser should have CI/CD preset applied

  @browser_config @preset_security_disabled
  Scenario: Validate security disabled preset configuration
    Given I set environment variable "BROWSER_CONFIG_PRESET" to "security_disabled"
    When I load browser configuration from preset
    And I show current browser configuration
    Then the browser should have security disabled preset applied

  @browser_config @config_file_performance
  Scenario: Validate configuration from performance JSON file
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/chrome_performance.json"
    And I show current browser configuration
    Then the browser should have configuration loaded from performance file

  @browser_config @config_file_mobile
  Scenario: Validate configuration from mobile JSON file
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/chrome_mobile.json"
    And I show current browser configuration
    Then the browser should have configuration loaded from mobile file

  @browser_config @config_file_cicd
  Scenario: Validate configuration from CI/CD JSON file
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/chrome_cicd.json"
    And I show current browser configuration
    Then the browser should have configuration loaded from CI/CD file

  @browser_config @config_file_security_disabled
  Scenario: Validate configuration from security disabled JSON file
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/chrome_security_disabled.json"
    And I show current browser configuration
    Then the browser should have configuration loaded from security disabled file

  @browser_config @config_file_firefox
  Scenario: Validate configuration from Firefox JSON file
    When I load browser configuration from file "hakalab_framework/templates/browser_configs/firefox_standard.json"
    And I show current browser configuration
    Then the browser should have configuration loaded from Firefox file

  @browser_config @save_load_config
  Scenario: Validate save and load custom configuration
    When I set browser argument "--custom-test-arg"
    And I set browser preference "test.custom.setting" to "true"
    And I save current browser configuration to file "test_custom_config.json"
    And I clear all browser arguments
    And I clear all browser preferences
    And I load browser configuration from file "test_custom_config.json"
    And I show current browser configuration
    Then the browser should have custom configuration restored

  @browser_config @environment_variables
  Scenario: Validate environment variable configuration
    Given I set environment variable "BROWSER_ARGS" to "--test-env-arg1,--test-env-arg2"
    And I set environment variable "BROWSER_MEMORY_LIMIT" to "3072"
    And I set environment variable "BROWSER_PROXY" to "http://env-proxy:9090"
    When I load browser configuration from environment variables
    And I show current browser configuration
    Then the browser should have environment variable configuration applied

  @browser_config @complex_scenario
  Scenario: Validate complex configuration scenario
    When I set browser argument "--no-sandbox"
    And I set Chrome flag "disable-web-security" to "true"
    And I enable Chrome experimental feature "WebUIDarkMode"
    And I set browser preference "profile.default_content_setting_values.notifications" to "2"
    And I set browser download behavior to "auto" with path "complex_downloads"
    And I set browser proxy to "http://complex-proxy:8080"
    And I set browser memory limit to "4096" MB
    And I show current browser configuration
    Then the browser should have complex configuration applied

  @browser_config @error_handling
  Scenario: Validate error handling for invalid configuration file
    When I try to load browser configuration from file "non_existent_config.json"
    Then I should get an error about missing configuration file

  @browser_config @clear_configuration
  Scenario: Validate clearing configuration
    Given I set browser argument "--test-clear-arg"
    And I set browser preference "test.clear.setting" to "true"
    When I clear all browser arguments
    And I clear all browser preferences
    And I show current browser configuration
    Then the browser should have no configuration set