#!/usr/bin/env python3
"""Extrae todos los @step en español de los archivos de steps"""
import re
import os
import ast

steps_dir = "hakalab_framework/steps"
results = {}

for filename in sorted(os.listdir(steps_dir)):
    if not filename.endswith('.py') or filename == '__init__.py':
        continue
    
    filepath = os.path.join(steps_dir, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Buscar todos los @step('...') con texto en español
    # Patrón: @step('texto') seguido opcionalmente de otro @step y luego def
    lines = content.split('\n')
    
    category = filename.replace('.py', '').replace('_steps', '').replace('_', ' ').title()
    steps_list = []
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        # Buscar líneas con @step(
        match = re.match(r"@step\(['\"](.+?)['\"]\)", line)
        if match:
            step_text = match.group(1)
            
            # Detectar si es español (heurística simple)
            spanish_words = ['voy', 'hago', 'verifico', 'espero', 'debería', 'el elemento', 
                           'la url', 'escribo', 'relleno', 'arrastro', 'cargo', 'guardo',
                           'establezco', 'obtengo', 'muestro', 'genero', 'creo', 'elimino',
                           'envío', 'extraigo', 'filtro', 'ordeno', 'busco', 'exporto',
                           'marco', 'desmarco', 'selecciono', 'acepto', 'rechazo',
                           'cambio', 'cierro', 'abro', 'recargo', 'maximizo',
                           'inicio', 'detengo', 'configuro', 'habilito', 'deshabilito',
                           'limpio', 'subo', 'descargo', 'conecto', 'desconecto',
                           'ejecuto', 'cuento', 'valido', 'comparo', 'capturo',
                           'tomo', 'presiono', 'mantengo', 'suelto', 'muevo',
                           'redimensiono', 'navego', 'la variable', 'el campo',
                           'la página', 'el texto', 'el botón', 'la tabla',
                           'el archivo', 'la imagen', 'el valor', 'el atributo',
                           'petición', 'respuesta', 'consulta', 'registro',
                           'transacción', 'conexión', 'el navegador', 'la ventana',
                           'pestaña', 'el modal', 'la alerta', 'el iframe',
                           'el checkbox', 'el radio', 'el select', 'el combobox',
                           'el formulario', 'la lista', 'la celda', 'la fila',
                           'la columna', 'el enlace', 'el menú', 'el spinner',
                           'el tooltip', 'el dropdown', 'el slider', 'el switch',
                           'la cookie', 'el storage', 'la sesión', 'el token',
                           'la base de datos', 'la consulta', 'el resultado',
                           'la descarga', 'la carga', 'el video', 'el screenshot',
                           'la captura', 'el reporte', 'el log', 'el error',
                           'la excepción', 'el timeout', 'la espera', 'el cronómetro',
                           'la medición', 'el rendimiento', 'la velocidad',
                           'deberia', 'no debería', 'no deberia',
                           'activo', 'escucha', 'intercepto', 'monitoreo',
                           'la respuesta', 'el header', 'el cuerpo', 'el estado',
                           'el código', 'el tipo', 'el contenido', 'el array',
                           'el JSON', 'el CSV', 'el PDF', 'el XML',
                           'la propiedad', 'el estilo', 'la clase', 'el id',
                           'el nombre', 'el placeholder', 'el título',
                           'soft assert', 'verificación suave', 'aserción suave']
            
            english_starts = ['I ', 'the ', 'a ', 'an ']
            
            is_english = any(step_text.startswith(w) for w in english_starts)
            is_spanish = any(w in step_text.lower() for w in spanish_words)
            
            if is_spanish and not is_english:
                # Buscar la función def y su docstring
                desc = ""
                j = i + 1
                while j < len(lines) and j < i + 5:
                    if lines[j].strip().startswith('def '):
                        # Buscar docstring
                        k = j + 1
                        while k < len(lines) and k < j + 5:
                            docline = lines[k].strip()
                            if docline.startswith('"""') or docline.startswith("'''"):
                                desc = docline.strip('"""').strip("'''").strip()
                                break
                            k += 1
                        break
                    j += 1
                
                steps_list.append((step_text, desc))
        
        i += 1
    
    if steps_list:
        results[category] = steps_list

# Imprimir resultados
for category, steps in results.items():
    print(f"\n=== {category} === ({len(steps)} pasos)")
    for step_text, desc in steps:
        print(f"  STEP: {step_text}")
        if desc:
            print(f"  DESC: {desc}")
        print()
