"""
Extract validation steps: steps whose function body contains assert/raise/verify logic.
Uses a two-pass approach: first find all functions, then check their bodies.
"""
import re
import os
import glob

steps_dir = 'hakalab_framework/steps'
files = sorted(glob.glob(os.path.join(steps_dir, '*.py')))

CATEGORY_MAP = {
    'accessibility_steps.py': 'Accesibilidad',
    'advanced_input_steps.py': 'Entrada Avanzada',
    'advanced_steps.py': 'Avanzado',
    'api_json_validation_steps.py': 'Validación JSON de API',
    'api_testing_steps.py': 'API Testing',
    'assertion_steps.py': 'Aserciones',
    'browser_advanced_config_steps.py': 'Configuración Avanzada del Navegador',
    'browser_control_steps.py': 'Control del Navegador',
    'combobox_steps.py': 'Combobox y Select',
    'combobox_validation_steps.py': 'Validación de Combobox',
    'csv_file_steps.py': 'Archivos CSV',
    'data_extraction_steps.py': 'Extracción de Datos',
    'database_steps.py': 'Base de Datos',
    'drag_drop_steps.py': 'Drag and Drop',
    'email_steps.py': 'Email',
    'environment_steps.py': 'Variables de Entorno',
    'file_steps.py': 'Archivos',
    'form_handling_steps.py': 'Manejo de Formularios',
    'genai_advanced_steps.py': 'GenAI Avanzado',
    'genai_evaluation_steps.py': 'Evaluación GenAI',
    'iframe_steps.py': 'Iframes',
    'interaction_steps.py': 'Interacción',
    'jira_xray_steps.py': 'Jira y Xray',
    'keyboard_mouse_steps.py': 'Teclado y Mouse',
    'modal_steps.py': 'Modales',
    'navigation_steps.py': 'Navegación',
    'ocr_steps.py': 'OCR',
    'pdf_steps.py': 'PDF',
    'performance_steps.py': 'Rendimiento',
    'responsive_steps.py': 'Responsive',
    'salesforce_steps.py': 'Salesforce',
    'scroll_steps.py': 'Scroll',
    'semantic_advanced_steps.py': 'Análisis Semántico Avanzado',
    'semantic_nlp_steps.py': 'NLP Semántico',
    'semantic_validation_steps.py': 'Validación Semántica',
    'supabase_vector_steps.py': 'Supabase y Vectores',
    'table_steps.py': 'Tablas',
    'timing_steps.py': 'Timing y Cronómetros',
    'validation_steps.py': 'Validaciones Avanzadas',
    'variable_steps.py': 'Variables',
    'wait_steps.py': 'Esperas',
    'web_elements_steps.py': 'Elementos Web',
    'window_steps.py': 'Ventanas y Alertas',
}

VALIDATION_KEYWORDS = [
    'assert ', 'assert(', 'assertequal', 'asserttrue', 'assertfalse',
    'assertin', 'assertnotin', 'assertraises',
    'raise assertionerror', 'raise valueerror', 'raise exception',
    'expect(', '.to_be_visible', '.to_be_hidden', '.to_have_text',
    '.to_contain_text', '.to_have_value', '.to_have_attribute',
    '.to_have_class', '.to_be_enabled', '.to_be_disabled',
    '.to_be_checked', '.to_have_count', '.to_have_url', '.to_have_title',
    'soft_assert', 'add_soft_assert',
    'assertionerror',
]

def has_validation(body):
    body_lower = body.lower()
    for kw in VALIDATION_KEYWORDS:
        if kw in body_lower:
            return True
    if re.search(r'if\s+.*?:\s*\n\s*raise\s', body):
        return True
    if re.search(r'assert\s+', body):
        return True
    return False

def extract_steps_with_bodies(filepath):
    """Extract step text -> function body mapping."""
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    results = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # Collect all consecutive @step decorators
        step_texts = []
        while i < len(lines) and lines[i].strip().startswith('@'):
            decorator = lines[i].strip()
            # Extract step text from decorator
            m = re.search(r"@(?:step|given|when|then)\(['\"](.+?)['\"]\)", decorator)
            if m:
                step_texts.append(m.group(1))
            i += 1
        
        # Check if next line is a def
        if i < len(lines) and lines[i].strip().startswith('def '):
            i += 1  # skip def line
            # Collect function body (indented lines)
            body_lines = []
            while i < len(lines):
                if lines[i].strip() == '' or lines[i][0] in (' ', '\t'):
                    body_lines.append(lines[i])
                    i += 1
                else:
                    break
            body = ''.join(body_lines)
            
            if step_texts and has_validation(body):
                for st in step_texts:
                    results.append(st)
        else:
            i += 1
    
    return results

total = 0
all_results = {}

for f in files:
    basename = os.path.basename(f)
    if basename == '__init__.py':
        continue
    
    vsteps = extract_steps_with_bodies(f)
    
    # Filter only Spanish, deduplicate
    seen = set()
    unique = []
    for s in vsteps:
        if s[0].isupper() or s.startswith('I '):
            continue
        base = s[4:] if s.startswith('que ') else s
        if base not in seen:
            seen.add(base)
            if not s.startswith('que '):
                unique.append(s)
    
    if unique:
        cat = CATEGORY_MAP.get(basename, basename.replace('_steps.py', '').title())
        all_results[cat] = (basename, unique)
        total += len(unique)

for cat in sorted(all_results.keys()):
    basename, unique = all_results[cat]
    print("=== " + cat + " (" + str(len(unique)) + " pasos) ===")
    print("FILE: " + basename)
    for s in unique:
        print("  STEP: " + s)
    print()

print("TOTAL VALIDATION STEPS: " + str(total))
