#!/usr/bin/env python3
"""
Appium Manager - Automatizacion de aplicaciones moviles (iOS y Android)
Compatible con pruebas puras mobile y pruebas mixtas (web + mobile).
Requiere: pip install Appium-Python-Client
"""

import os
import json
import time
import logging
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime
from pathlib import Path

try:
    from appium import webdriver as appium_webdriver
    from appium.webdriver.common.appiumby import AppiumBy
    from appium.options.android import UiAutomator2Options
    from appium.options.ios import XCUITestOptions
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import (
        TimeoutException, NoSuchElementException, WebDriverException
    )
    APPIUM_AVAILABLE = True
except ImportError:
    APPIUM_AVAILABLE = False


class AppiumManager:
    """
    Manager para automatizacion de aplicaciones moviles con Appium.
    Soporta Android e iOS, apps nativas, hibridas y web mobile.
    Soporta localizadores JSON con notacion $.PAGINA.elemento
    """

    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.appium')
        self.driver = None
        self.screenshots_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
        self.default_timeout = float(os.getenv('ELEMENT_WAIT_TIMEOUT', os.getenv('APPIUM_TIMEOUT', '10')))
        self.appium_url = os.getenv('APPIUM_SERVER_URL', os.getenv('APPIUM_URL', 'http://localhost:4723'))
        self.json_poms_path = os.getenv('JSON_POMS_PATH', 'json_poms')
        self.platform_name = os.getenv('APPIUM_PLATFORM_NAME', 'Android')
        self.device_name = os.getenv('APPIUM_DEVICE_NAME', 'emulator-5554')
        self.app_path = os.getenv('APPIUM_APP_PATH', '')
        self.app_id = os.getenv('APPIUM_APP_ID', '')
        self.reset_strategy = os.getenv('RESET_STRATEGY', 'restart')
        self._pom_cache: Dict[str, Dict[str, Any]] = {}
        self._current_bundle: Optional[str] = None
        self._current_app_path: Optional[str] = None
        Path(self.screenshots_dir).mkdir(exist_ok=True)

    def _require_appium(self):
        if not APPIUM_AVAILABLE:
            raise ImportError(
                "Appium-Python-Client no esta instalado. "
                "Ejecuta: pip install Appium-Python-Client"
            )

    def _require_driver(self):
        if self.driver is None:
            raise AssertionError(
                "No hay sesion Appium activa. "
                "Usa 'uso el modo mobile' primero."
            )

    def setup_from_env(self) -> None:
        """
        Configura todo desde el .env: conecta, verifica/instala la app,
        y aplica la estrategia de reset. Un solo método que lo hace todo.
        """
        self._require_appium()

        # Si ya hay sesión activa, aplicar estrategia de reset
        if self.driver:
            self._apply_reset_strategy()
            return

        # Construir capabilities desde el .env
        caps: Dict[str, Any] = {
            'platformName': self.platform_name,
            'deviceName': self.device_name,
            'automationName': 'UiAutomator2' if self.platform_name.lower() == 'android' else 'XCUITest',
            'newCommandTimeout': 300,
        }

        # Determinar si usar app path o app id
        app_id = self.app_id
        app_path = self.app_path

        if app_path:
            # Verificar si la app ya está instalada
            if app_id:
                self._current_bundle = app_id
                caps['appPackage'] = app_id
                # Conectar primero sin app para verificar instalación
                caps_check = dict(caps)
                caps_check['autoLaunch'] = False
                try:
                    self.logger.info(f"Conectando a Appium en {self.appium_url}")
                    options = self._build_options(caps_check)
                    self.driver = appium_webdriver.Remote(self.appium_url, options=options)
                    self.driver.implicitly_wait(self.default_timeout)

                    if not self.driver.is_app_installed(app_id):
                        self.logger.info(f"App no instalada, instalando desde {app_path}...")
                        self.driver.install_app(app_path)
                        self.logger.info(f"App instalada: {app_id}")
                    else:
                        self.logger.info(f"App ya instalada: {app_id}")

                    # Activar la app
                    self.driver.activate_app(app_id)
                    self.logger.info(f"Modo mobile listo (bundle: {app_id})")
                    return
                except Exception:
                    # Si falla, intentar con app path directo
                    if self.driver:
                        try:
                            self.driver.quit()
                        except Exception:
                            pass
                        self.driver = None

            # Fallback: usar app path directo en capabilities
            caps['app'] = app_path
            if app_id:
                caps['appPackage'] = app_id
        elif app_id:
            # Solo app id, la app ya debe estar instalada
            self._current_bundle = app_id
            caps['appPackage'] = app_id

        self.logger.info(f"Conectando a Appium en {self.appium_url}")
        options = self._build_options(caps)
        self.driver = appium_webdriver.Remote(self.appium_url, options=options)
        self.driver.implicitly_wait(self.default_timeout)

        # Resolver bundle si no lo tenemos
        if not self._current_bundle:
            session_caps = self.driver.capabilities or {}
            for key in ('appPackage', 'bundleId', 'appium:appPackage', 'appium:bundleId'):
                val = session_caps.get(key)
                if val:
                    self._current_bundle = val
                    break

        self._current_app_path = app_path
        self.logger.info(f"Modo mobile listo (bundle: {self._current_bundle})")

    def _apply_reset_strategy(self) -> None:
        """Aplica la estrategia de reset entre escenarios."""
        strategy = self.reset_strategy.lower().strip()
        bundle = self._current_bundle

        if strategy == 'restart' and bundle:
            try:
                self.driver.terminate_app(bundle)
            except Exception:
                pass
            self.driver.activate_app(bundle)
            self.logger.info("Reset: app reiniciada (restart)")
        elif strategy == 'full_reset':
            if self._current_app_path:
                if bundle:
                    try:
                        self.driver.remove_app(bundle)
                    except Exception:
                        pass
                self.driver.install_app(self._current_app_path)
                if bundle:
                    self.driver.activate_app(bundle)
                self.logger.info("Reset: app reinstalada (full_reset)")
        elif strategy == 'no_reset':
            self.logger.info("Reset: sin reset (no_reset)")
        else:
            self.logger.info(f"Reset: estrategia '{strategy}' no reconocida, sin acción")

    # ------------------------------------------------------------------
    # CONEXION Y SESION
    # ------------------------------------------------------------------

    def _extract_bundle_from_apk(self, app_path: str) -> Optional[str]:
        """Extrae el bundle ID (package name) de un archivo APK usando aapt."""
        import subprocess as _sp
        import shutil as _sh

        aapt = _sh.which('aapt') or _sh.which('aapt2')
        if not aapt:
            android_home = os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT', '')
            if android_home:
                bt = os.path.join(android_home, 'build-tools')
                if os.path.isdir(bt):
                    versions = sorted(os.listdir(bt), reverse=True)
                    for v in versions:
                        candidate = os.path.join(bt, v, 'aapt')
                        if os.path.isfile(candidate) or os.path.isfile(candidate + '.exe'):
                            aapt = candidate
                            break
        if not aapt:
            self.logger.warning("aapt no encontrado. No se puede extraer bundle del APK.")
            return None

        try:
            result = _sp.run(
                [aapt, 'dump', 'badging', app_path],
                capture_output=True, text=True, timeout=30
            )
            for line in result.stdout.splitlines():
                if line.startswith('package:'):
                    # package: name='com.example.app' versionCode='1' ...
                    for part in line.split():
                        if part.startswith("name='"):
                            return part.split("'")[1]
        except Exception as e:
            self.logger.warning(f"Error extrayendo bundle del APK: {e}")
        return None

    def _resolve_bundle(self) -> str:
        """Obtiene el bundle ID actual. Lo extrae de las capabilities o del APK."""
        if self._current_bundle:
            return self._current_bundle

        if self.driver:
            # Intentar obtener de las capabilities de la sesion activa
            caps = self.driver.capabilities or {}
            for key in ('appPackage', 'bundleId', 'appium:appPackage', 'appium:bundleId'):
                val = caps.get(key)
                if val:
                    self._current_bundle = val
                    return val

        raise AssertionError(
            "No se pudo determinar el bundle ID de la aplicación. "
            "Asegúrate de conectar con un APK o con appPackage en las capacidades."
        )

    def _build_options(self, capabilities: Dict[str, Any]):
        """Convierte un dict de capabilities a un objeto Options de Appium."""
        platform = capabilities.get('platformName', self.platform_name).lower()
        if platform == 'ios':
            options = XCUITestOptions()
        else:
            options = UiAutomator2Options()
        options.load_capabilities(capabilities)
        return options

    def connect(self, capabilities: Dict[str, Any], appium_url: Optional[str] = None) -> None:
        """Inicia una sesion Appium con las capacidades indicadas."""
        self._require_appium()
        url = appium_url or self.appium_url

        # Extraer bundle del APK si se proporciona la ruta
        app_path = capabilities.get('app') or capabilities.get('appium:app')
        if app_path:
            self._current_app_path = app_path
            bundle = self._extract_bundle_from_apk(app_path)
            if bundle:
                self._current_bundle = bundle
                self.logger.info(f"Bundle extraído del APK: {bundle}")

        self.logger.info(f"Conectando a Appium en {url}")
        options = self._build_options(capabilities)
        self.driver = appium_webdriver.Remote(url, options=options)
        self.driver.implicitly_wait(self.default_timeout)

        # Si no se extrajo del APK, intentar de las capabilities de la sesion
        if not self._current_bundle:
            caps = self.driver.capabilities or {}
            for key in ('appPackage', 'bundleId', 'appium:appPackage', 'appium:bundleId'):
                val = caps.get(key)
                if val:
                    self._current_bundle = val
                    break

        self.logger.info(f"Sesion Appium iniciada (bundle: {self._current_bundle})")

    def disconnect(self) -> None:
        """Cierra la sesion Appium."""
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None
            self._current_bundle = None
            self._current_app_path = None
            self.logger.info("Sesion Appium cerrada")

    def reset_app(self) -> None:
        """Reinicia la aplicacion sin cerrar la sesion."""
        self._require_driver()
        self.driver.reset()
        self.logger.info("App reiniciada")

    def launch_app(self) -> None:
        """Lanza la app configurada en las capacidades."""
        self._require_driver()
        self.driver.launch_app()
        self.logger.info("App lanzada")

    def close_app(self) -> None:
        """Cierra la app sin cerrar la sesion."""
        self._require_driver()
        self.driver.close_app()
        self.logger.info("App cerrada")

    def install_app(self, app_path: str) -> None:
        """Instala una app en el dispositivo y guarda su bundle ID."""
        self._require_driver()
        self._current_app_path = app_path
        bundle = self._extract_bundle_from_apk(app_path)
        if bundle:
            self._current_bundle = bundle
        self.driver.install_app(app_path)
        self.logger.info(f"App instalada: {app_path} (bundle: {self._current_bundle})")

    def remove_app(self, bundle_id: Optional[str] = None) -> None:
        """Desinstala la app actual o una específica del dispositivo."""
        self._require_driver()
        bid = bundle_id or self._resolve_bundle()
        self.driver.remove_app(bid)
        self.logger.info(f"App desinstalada: {bid}")

    def is_app_installed(self, bundle_id: Optional[str] = None) -> bool:
        """Verifica si la app actual o una específica esta instalada."""
        self._require_driver()
        bid = bundle_id or self._resolve_bundle()
        return self.driver.is_app_installed(bid)

    def activate_app(self, bundle_id: Optional[str] = None) -> None:
        """Activa (trae al frente) la app actual o una específica."""
        self._require_driver()
        bid = bundle_id or self._resolve_bundle()
        self.driver.activate_app(bid)
        self.logger.info(f"App activada: {bid}")

    def terminate_app(self, bundle_id: Optional[str] = None) -> None:
        """Termina la app actual o una específica en segundo plano."""
        self._require_driver()
        bid = bundle_id or self._resolve_bundle()
        self.driver.terminate_app(bid)
        self.logger.info(f"App terminada: {bid}")

    def ensure_app_installed(self, app_path: str) -> None:
        """Verifica si la app está instalada; si no, la instala."""
        self._require_driver()
        bundle = self._extract_bundle_from_apk(app_path)
        if bundle and self.driver.is_app_installed(bundle):
            self._current_bundle = bundle
            self._current_app_path = app_path
            self.logger.info(f"App ya instalada: {bundle}")
        else:
            self.install_app(app_path)
            self.logger.info(f"App instalada: {app_path}")

    # ------------------------------------------------------------------
    # LOCALIZACION JSON POM ($.PAGINA.elemento)
    # ------------------------------------------------------------------

    def _load_pom(self, page_name: str) -> Dict[str, Any]:
        """Carga un archivo JSON de page object y lo cachea."""
        if page_name in self._pom_cache:
            return self._pom_cache[page_name]

        json_file = os.path.join(self.json_poms_path, f'{page_name}.json')
        if not os.path.isfile(json_file):
            raise FileNotFoundError(
                f"Archivo de page object no encontrado: {json_file}"
            )
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self._pom_cache[page_name] = data
        self.logger.info(f"POM cargado: {page_name}.json ({len(data)} elementos)")
        return data

    def _resolve_pom_locator(self, identifier: str) -> Tuple[str, str]:
        """
        Resuelve un identificador $.PAGINA.elemento a una tupla (by, value).

        El JSON puede tener dos formatos:
          1. Diccionario con by/value:
             {"input": {"by": "accessibility_id", "value": "Username"}}
          2. String simple con prefijo (retrocompatible):
             {"input": "id=com.app:id/username"}

        Args:
            identifier: Formato $.PAGINA.elemento o $.PAGINA.elemento=valor_dinamico

        Returns:
            Tuple[str, str]: (AppiumBy strategy, value)
        """
        # Extraer valor dinámico si existe ($.PAGE.elem=valor)
        dynamic_value = None
        if '=' in identifier.split('.')[-1]:
            last_part = identifier.split('.')[-1]
            if '=' in last_part:
                elem_name, dynamic_value = last_part.rsplit('=', 1)
                identifier = identifier[:identifier.rfind('=')] 

        if not identifier.startswith('$.'):
            raise ValueError(
                f"Identificador POM debe empezar con '$.' - Recibido: {identifier}"
            )

        parts = identifier[2:].split('.', 1)
        if len(parts) != 2:
            raise ValueError(
                f"Formato inválido. Esperado: $.PAGINA.elemento - Recibido: {identifier}"
            )

        page_name, element_name = parts
        pom_data = self._load_pom(page_name)

        if element_name not in pom_data:
            raise KeyError(
                f"Elemento '{element_name}' no encontrado en '{page_name}.json'. "
                f"Elementos disponibles: {list(pom_data.keys())}"
            )

        element_data = pom_data[element_name]

        # Formato 1: dict con "by" y "value"
        if isinstance(element_data, dict):
            by_str = element_data.get('by', 'xpath')
            value = element_data.get('value', '')
        # Formato 2: string simple con prefijo (id=xxx, xpath=xxx, etc.)
        elif isinstance(element_data, str):
            return self._parse_locator(element_data)
        else:
            raise ValueError(
                f"Formato de elemento no soportado para '{element_name}': {type(element_data)}"
            )

        # Reemplazar placeholder dinámico si existe
        if dynamic_value is not None:
            value = value.replace('<valor>', dynamic_value)
            value = value.replace('<value>', dynamic_value)
            value = value.replace('{valor}', dynamic_value)
            value = value.replace('{value}', dynamic_value)

        by_mapping = {
            'id': AppiumBy.ID,
            'xpath': AppiumBy.XPATH,
            'text': AppiumBy.ANDROID_UIAUTOMATOR,
            'accessibility_id': AppiumBy.ACCESSIBILITY_ID,
            'class': AppiumBy.CLASS_NAME,
            'class_name': AppiumBy.CLASS_NAME,
            'uiautomator': AppiumBy.ANDROID_UIAUTOMATOR,
            'ios_predicate': AppiumBy.IOS_PREDICATE,
            'ios_class_chain': AppiumBy.IOS_CLASS_CHAIN,
            'name': AppiumBy.NAME,
            'tag': AppiumBy.TAG_NAME,
        }

        by_key = by_str.strip().lower()
        if by_key == 'text':
            value = f'new UiSelector().text("{value}")'

        appium_by = by_mapping.get(by_key)
        if appium_by is None:
            raise ValueError(
                f"Estrategia de localización no soportada: '{by_str}'. "
                f"Opciones: {list(by_mapping.keys())}"
            )

        return appium_by, value

    def reload_pom_cache(self) -> None:
        """Limpia el caché de page objects para forzar recarga."""
        self._pom_cache.clear()
        self.logger.info("Caché de POM limpiado")

    # ------------------------------------------------------------------
    # LOCALIZACION DE ELEMENTOS
    # ------------------------------------------------------------------

    def _find_element(self, locator: str, timeout: Optional[float] = None):
        """Encuentra un elemento. Soporta: $.PAGINA.elem, id=, xpath=, text=, accessibility_id=, class="""
        self._require_driver()
        t = timeout or self.default_timeout
        if locator.startswith('$.'):
            by, value = self._resolve_pom_locator(locator)
        else:
            by, value = self._parse_locator(locator)
        try:
            return WebDriverWait(self.driver, t).until(
                EC.presence_of_element_located((by, value))
            )
        except TimeoutException:
            raise AssertionError(
                f"Elemento no encontrado en {t}s: {locator}"
            )

    def _find_elements(self, locator: str) -> list:
        """Encuentra todos los elementos que coinciden con el locator."""
        self._require_driver()
        if locator.startswith('$.'):
            by, value = self._resolve_pom_locator(locator)
        else:
            by, value = self._parse_locator(locator)
        return self.driver.find_elements(by, value)

    def _parse_locator(self, locator: str) -> Tuple[str, str]:
        """
        Parsea un locator con prefijo:
          id=com.app:id/button
          xpath=//android.widget.Button[@text='OK']
          text=Aceptar
          accessibility_id=login_button
          class=android.widget.EditText
          uiautomator=new UiSelector().text("OK")
          ios_predicate=name == 'login'
          ios_class_chain=**/XCUIElementTypeButton[`name == 'OK'`]
        """
        if '=' in locator:
            prefix, value = locator.split('=', 1)
            prefix = prefix.strip().lower()
            value = value.strip()
            mapping = {
                'id': AppiumBy.ID,
                'xpath': AppiumBy.XPATH,
                'text': AppiumBy.ANDROID_UIAUTOMATOR,
                'accessibility_id': AppiumBy.ACCESSIBILITY_ID,
                'class': AppiumBy.CLASS_NAME,
                'uiautomator': AppiumBy.ANDROID_UIAUTOMATOR,
                'ios_predicate': AppiumBy.IOS_PREDICATE,
                'ios_class_chain': AppiumBy.IOS_CLASS_CHAIN,
                'name': AppiumBy.NAME,
                'tag': AppiumBy.TAG_NAME,
            }
            if prefix == 'text':
                value = f'new UiSelector().text("{value}")'
            return mapping.get(prefix, AppiumBy.XPATH), value
        # Sin prefijo: asumir xpath
        return AppiumBy.XPATH, locator

    def _wait_visible(self, locator: str, timeout: Optional[float] = None):
        """Espera a que un elemento sea visible."""
        self._require_driver()
        t = timeout or self.default_timeout
        if locator.startswith('$.'):
            by, value = self._resolve_pom_locator(locator)
        else:
            by, value = self._parse_locator(locator)
        try:
            return WebDriverWait(self.driver, t).until(
                EC.visibility_of_element_located((by, value))
            )
        except TimeoutException:
            raise AssertionError(f"Elemento no visible en {t}s: {locator}")

    def is_element_visible(self, locator: str, timeout: float = 3) -> bool:
        """Retorna True si el elemento es visible."""
        try:
            self._wait_visible(locator, timeout)
            return True
        except (AssertionError, Exception):
            return False

    def is_element_present(self, locator: str) -> bool:
        """Retorna True si el elemento existe en el DOM."""
        try:
            self._find_element(locator, timeout=3)
            return True
        except (AssertionError, Exception):
            return False

    # ------------------------------------------------------------------
    # CLICKS Y TAPS
    # ------------------------------------------------------------------

    def tap(self, locator: str, timeout: Optional[float] = None) -> None:
        """Tap en un elemento."""
        el = self._find_element(locator, timeout)
        el.click()
        self.logger.info(f"Tap en: {locator}")

    def double_tap(self, locator: str) -> None:
        """Doble tap en un elemento."""
        from appium.webdriver.common.touch_action import TouchAction
        el = self._find_element(locator)
        action = TouchAction(self.driver)
        action.tap(el, count=2).perform()
        self.logger.info(f"Doble tap en: {locator}")

    def long_press(self, locator: str, duration_ms: int = 1000) -> None:
        """Tap largo en un elemento."""
        from appium.webdriver.common.touch_action import TouchAction
        el = self._find_element(locator)
        action = TouchAction(self.driver)
        action.long_press(el, duration=duration_ms).release().perform()
        self.logger.info(f"Tap largo en: {locator} ({duration_ms}ms)")

    def tap_at_coordinates(self, x: int, y: int) -> None:
        """Tap en coordenadas absolutas de pantalla."""
        from appium.webdriver.common.touch_action import TouchAction
        self._require_driver()
        action = TouchAction(self.driver)
        action.tap(x=x, y=y).perform()
        self.logger.info(f"Tap en coordenadas ({x}, {y})")

    def tap_by_text(self, text: str) -> None:
        """Tap en el primer elemento que contiene el texto exacto."""
        self.tap(f'text={text}')

    def tap_by_accessibility_id(self, accessibility_id: str) -> None:
        """Tap usando el accessibility id del elemento."""
        self.tap(f'accessibility_id={accessibility_id}')

    # ------------------------------------------------------------------
    # ESCRITURA DE TEXTO
    # ------------------------------------------------------------------

    def type_text(self, locator: str, text: str, clear_first: bool = True) -> None:
        """Escribe texto en un campo."""
        el = self._find_element(locator)
        if clear_first:
            el.clear()
        el.send_keys(text)
        self.logger.info(f"Texto escrito en '{locator}': '{text[:30]}'")

    def clear_field(self, locator: str) -> None:
        """Limpia el contenido de un campo."""
        el = self._find_element(locator)
        el.clear()
        self.logger.info(f"Campo limpiado: {locator}")

    def append_text(self, locator: str, text: str) -> None:
        """Agrega texto al campo sin borrar el contenido existente."""
        el = self._find_element(locator)
        el.send_keys(text)
        self.logger.info(f"Texto agregado en '{locator}': '{text[:30]}'")

    def hide_keyboard(self) -> None:
        """Oculta el teclado virtual."""
        self._require_driver()
        try:
            self.driver.hide_keyboard()
            self.logger.info("Teclado ocultado")
        except Exception as e:
            self.logger.warning(f"No se pudo ocultar el teclado: {e}")

    def press_key(self, key_code: int) -> None:
        """Presiona una tecla por codigo (Android KeyEvent)."""
        self._require_driver()
        self.driver.press_keycode(key_code)
        self.logger.info(f"Tecla presionada: {key_code}")

    # ------------------------------------------------------------------
    # SCROLL Y SWIPE
    # ------------------------------------------------------------------

    def scroll_down(self, swipes: int = 1) -> None:
        """Scroll hacia abajo en la pantalla."""
        self._require_driver()
        size = self.driver.get_window_size()
        w, h = size['width'], size['height']
        for _ in range(swipes):
            self.driver.swipe(w // 2, int(h * 0.7), w // 2, int(h * 0.3), 500)
        self.logger.info(f"Scroll abajo x{swipes}")

    def scroll_up(self, swipes: int = 1) -> None:
        """Scroll hacia arriba en la pantalla."""
        self._require_driver()
        size = self.driver.get_window_size()
        w, h = size['width'], size['height']
        for _ in range(swipes):
            self.driver.swipe(w // 2, int(h * 0.3), w // 2, int(h * 0.7), 500)
        self.logger.info(f"Scroll arriba x{swipes}")

    def scroll_left(self, swipes: int = 1) -> None:
        """Scroll hacia la izquierda."""
        self._require_driver()
        size = self.driver.get_window_size()
        w, h = size['width'], size['height']
        for _ in range(swipes):
            self.driver.swipe(int(w * 0.7), h // 2, int(w * 0.3), h // 2, 500)
        self.logger.info(f"Scroll izquierda x{swipes}")

    def scroll_right(self, swipes: int = 1) -> None:
        """Scroll hacia la derecha."""
        self._require_driver()
        size = self.driver.get_window_size()
        w, h = size['width'], size['height']
        for _ in range(swipes):
            self.driver.swipe(int(w * 0.3), h // 2, int(w * 0.7), h // 2, 500)
        self.logger.info(f"Scroll derecha x{swipes}")

    def scroll_to_element(self, locator: str, max_swipes: int = 10) -> None:
        """Hace scroll hasta encontrar un elemento."""
        for i in range(max_swipes):
            if self.is_element_visible(locator, timeout=2):
                return
            self.scroll_down()
        raise AssertionError(f"Elemento no encontrado tras {max_swipes} scrolls: {locator}")

    def scroll_to_text(self, text: str, max_swipes: int = 10) -> None:
        """Hace scroll hasta encontrar un texto en pantalla."""
        self.scroll_to_element(f'text={text}', max_swipes)

    def swipe(self, start_x: int, start_y: int, end_x: int, end_y: int,
              duration_ms: int = 500) -> None:
        """Swipe entre dos coordenadas."""
        self._require_driver()
        self.driver.swipe(start_x, start_y, end_x, end_y, duration_ms)
        self.logger.info(f"Swipe ({start_x},{start_y}) -> ({end_x},{end_y})")

    def swipe_element_left(self, locator: str) -> None:
        """Swipe hacia la izquierda sobre un elemento."""
        el = self._find_element(locator)
        loc = el.location
        size = el.size
        x = loc['x'] + size['width'] // 2
        y = loc['y'] + size['height'] // 2
        self.driver.swipe(x, y, x - size['width'] // 2, y, 500)

    def swipe_element_right(self, locator: str) -> None:
        """Swipe hacia la derecha sobre un elemento."""
        el = self._find_element(locator)
        loc = el.location
        size = el.size
        x = loc['x'] + size['width'] // 2
        y = loc['y'] + size['height'] // 2
        self.driver.swipe(x, y, x + size['width'] // 2, y, 500)

    def pinch(self, locator: str) -> None:
        """Gesto de pinch (zoom out) sobre un elemento."""
        from appium.webdriver.common.multi_action import MultiAction
        from appium.webdriver.common.touch_action import TouchAction
        el = self._find_element(locator)
        action1 = TouchAction(self.driver)
        action2 = TouchAction(self.driver)
        ma = MultiAction(self.driver, el)
        action1.press(el, 0.1, 0.5).move_to(el, 0.5, 0.5).release()
        action2.press(el, 0.9, 0.5).move_to(el, 0.5, 0.5).release()
        ma.add(action1, action2)
        ma.perform()

    def zoom(self, locator: str) -> None:
        """Gesto de zoom (zoom in) sobre un elemento."""
        from appium.webdriver.common.multi_action import MultiAction
        from appium.webdriver.common.touch_action import TouchAction
        el = self._find_element(locator)
        action1 = TouchAction(self.driver)
        action2 = TouchAction(self.driver)
        ma = MultiAction(self.driver, el)
        action1.press(el, 0.5, 0.5).move_to(el, 0.1, 0.5).release()
        action2.press(el, 0.5, 0.5).move_to(el, 0.9, 0.5).release()
        ma.add(action1, action2)
        ma.perform()

    # ------------------------------------------------------------------
    # ESPERAS
    # ------------------------------------------------------------------

    def wait_for_element(self, locator: str, timeout: Optional[float] = None) -> None:
        """Espera hasta que un elemento sea visible."""
        self._wait_visible(locator, timeout)
        self.logger.info(f"Elemento visible: {locator}")

    def wait_for_element_to_disappear(self, locator: str,
                                       timeout: Optional[float] = None) -> None:
        """Espera hasta que un elemento desaparezca."""
        self._require_driver()
        t = timeout or self.default_timeout
        if locator.startswith('$.'):
            by, value = self._resolve_pom_locator(locator)
        else:
            by, value = self._parse_locator(locator)
        try:
            WebDriverWait(self.driver, t).until(
                EC.invisibility_of_element_located((by, value))
            )
            self.logger.info(f"Elemento desaparecio: {locator}")
        except TimeoutException:
            raise AssertionError(f"Elemento no desaparecio en {t}s: {locator}")

    def wait_for_text(self, text: str, timeout: Optional[float] = None) -> None:
        """Espera hasta que un texto sea visible en pantalla."""
        self.wait_for_element(f'text={text}', timeout)

    def wait_seconds(self, seconds: float) -> None:
        """Pausa la ejecucion el numero de segundos indicado."""
        time.sleep(seconds)
        self.logger.info(f"Espera de {seconds}s")

    # ------------------------------------------------------------------
    # VERIFICACIONES
    # ------------------------------------------------------------------

    def get_text(self, locator: str) -> str:
        """Obtiene el texto de un elemento."""
        el = self._find_element(locator)
        text = el.text
        self.logger.info(f"Texto de '{locator}': '{text}'")
        return text

    def get_attribute(self, locator: str, attribute: str) -> str:
        """Obtiene el valor de un atributo de un elemento."""
        el = self._find_element(locator)
        value = el.get_attribute(attribute)
        self.logger.info(f"Atributo '{attribute}' de '{locator}': '{value}'")
        return value

    def is_element_enabled(self, locator: str) -> bool:
        """Retorna True si el elemento esta habilitado."""
        el = self._find_element(locator)
        return el.is_enabled()

    def is_element_selected(self, locator: str) -> bool:
        """Retorna True si el elemento esta seleccionado (checkbox, radio)."""
        el = self._find_element(locator)
        return el.is_selected()

    def get_element_count(self, locator: str) -> int:
        """Retorna el numero de elementos que coinciden con el locator."""
        return len(self._find_elements(locator))

    # ------------------------------------------------------------------
    # NAVEGACION
    # ------------------------------------------------------------------

    def go_back(self) -> None:
        """Presiona el boton Atras del dispositivo."""
        self._require_driver()
        self.driver.back()
        self.logger.info("Boton Atras presionado")

    def go_home(self) -> None:
        """Presiona el boton Home del dispositivo."""
        self._require_driver()
        self.driver.press_keycode(3)  # Android HOME
        self.logger.info("Boton Home presionado")

    def open_notifications(self) -> None:
        """Abre el panel de notificaciones (Android)."""
        self._require_driver()
        self.driver.open_notifications()
        self.logger.info("Panel de notificaciones abierto")

    def set_orientation(self, orientation: str) -> None:
        """Cambia la orientacion: PORTRAIT o LANDSCAPE."""
        self._require_driver()
        self.driver.orientation = orientation.upper()
        self.logger.info(f"Orientacion: {orientation}")

    def get_orientation(self) -> str:
        """Retorna la orientacion actual."""
        self._require_driver()
        return self.driver.orientation

    # ------------------------------------------------------------------
    # ALERTAS Y DIALOGOS
    # ------------------------------------------------------------------

    def accept_alert(self) -> None:
        """Acepta una alerta nativa."""
        self._require_driver()
        self.driver.switch_to.alert.accept()
        self.logger.info("Alerta aceptada")

    def dismiss_alert(self) -> None:
        """Cancela/descarta una alerta nativa."""
        self._require_driver()
        self.driver.switch_to.alert.dismiss()
        self.logger.info("Alerta descartada")

    def get_alert_text(self) -> str:
        """Obtiene el texto de una alerta nativa."""
        self._require_driver()
        text = self.driver.switch_to.alert.text
        self.logger.info(f"Texto de alerta: '{text}'")
        return text

    def type_in_alert(self, text: str) -> None:
        """Escribe texto en el campo de una alerta nativa."""
        self._require_driver()
        self.driver.switch_to.alert.send_keys(text)

    # ------------------------------------------------------------------
    # CONTEXTOS (nativo / webview)
    # ------------------------------------------------------------------

    def get_contexts(self) -> List[str]:
        """Retorna los contextos disponibles (NATIVE_APP, WEBVIEW_xxx)."""
        self._require_driver()
        return self.driver.contexts

    def switch_to_webview(self, index: int = 0) -> None:
        """Cambia al contexto WebView."""
        self._require_driver()
        contexts = self.driver.contexts
        webviews = [c for c in contexts if 'WEBVIEW' in c]
        if not webviews:
            raise AssertionError("No hay contextos WebView disponibles")
        self.driver.switch_to.context(webviews[index])
        self.logger.info(f"Cambiado a WebView: {webviews[index]}")

    def switch_to_native(self) -> None:
        """Cambia al contexto nativo."""
        self._require_driver()
        self.driver.switch_to.context('NATIVE_APP')
        self.logger.info("Cambiado a contexto nativo")

    def get_current_context(self) -> str:
        """Retorna el contexto actual."""
        self._require_driver()
        return self.driver.current_context

    # ------------------------------------------------------------------
    # SCREENSHOTS
    # ------------------------------------------------------------------

    def take_screenshot(self, name: str = "mobile") -> str:
        """Toma screenshot del dispositivo y lo guarda."""
        self._require_driver()
        timestamp = datetime.now().strftime("%H%M%S")
        clean_name = name.replace(' ', '_').replace(':', '_')
        filename = f"{clean_name}_{timestamp}.png"
        filepath = os.path.join(self.screenshots_dir, filename)
        self.driver.save_screenshot(filepath)
        self.logger.info(f"Screenshot guardado: {filepath}")
        return filepath

    def take_element_screenshot(self, locator: str, name: str = "element") -> str:
        """Toma screenshot de un elemento especifico."""
        el = self._find_element(locator)
        timestamp = datetime.now().strftime("%H%M%S")
        clean_name = name.replace(' ', '_')
        filename = f"{clean_name}_{timestamp}.png"
        filepath = os.path.join(self.screenshots_dir, filename)
        el.screenshot(filepath)
        self.logger.info(f"Screenshot de elemento guardado: {filepath}")
        return filepath

    # ------------------------------------------------------------------
    # INFORMACION DEL DISPOSITIVO
    # ------------------------------------------------------------------

    def get_device_info(self) -> Dict[str, Any]:
        """Retorna informacion del dispositivo."""
        self._require_driver()
        return {
            'platform': self.driver.capabilities.get('platformName', ''),
            'version': self.driver.capabilities.get('platformVersion', ''),
            'device': self.driver.capabilities.get('deviceName', ''),
            'orientation': self.driver.orientation,
            'window_size': self.driver.get_window_size(),
        }

    def get_window_size(self) -> Dict[str, int]:
        """Retorna el tamano de la pantalla."""
        self._require_driver()
        return self.driver.get_window_size()

    def get_page_source(self) -> str:
        """Retorna el XML/HTML de la pantalla actual."""
        self._require_driver()
        return self.driver.page_source

    def execute_script(self, script: str, *args) -> Any:
        """Ejecuta un script JavaScript (en contexto WebView)."""
        self._require_driver()
        return self.driver.execute_script(script, *args)

    def execute_mobile_command(self, command: str, args: Dict = None) -> Any:
        """Ejecuta un comando mobile especifico de Appium."""
        self._require_driver()
        return self.driver.execute_script(f'mobile: {command}', args or {})

    # ------------------------------------------------------------------
    # MODO MIXTO
    # ------------------------------------------------------------------

    def switch_to_mobile_mode(self, context) -> None:
        """Activa el modo mobile en el contexto del framework."""
        context.mobile_mode = True
        context.appium_manager = self
        context.report_mode = 'mobile'
        self.logger.info("Modo mobile activado")

    def switch_to_web_mode(self, context) -> None:
        """Vuelve al modo web en el contexto del framework."""
        context.mobile_mode = False
        context.report_mode = 'web'
        self.logger.info("Modo web restaurado")
