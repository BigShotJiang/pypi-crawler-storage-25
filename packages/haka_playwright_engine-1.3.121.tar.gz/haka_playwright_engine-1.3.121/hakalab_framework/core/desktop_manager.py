#!/usr/bin/env python3
"""
Desktop Manager - Automatización de aplicaciones de escritorio con PyAutoGUI
Soporta búsqueda de elementos por coordenadas y por imagen de referencia.
Compatible con pruebas puras de escritorio y pruebas mixtas (web + escritorio).
"""

import os
import time
import subprocess
import logging
import platform
from typing import Optional, Tuple, List, Dict, Any
from datetime import datetime
from pathlib import Path

try:
    import pyautogui
    pyautogui.FAILSAFE = True   # Mover mouse a esquina superior izquierda detiene el script
    pyautogui.PAUSE = float(os.getenv('DESKTOP_ACTION_PAUSE', '0.3'))
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False

try:
    from PIL import Image, ImageGrab
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


class DesktopActionResult:
    """Resultado de una acción de escritorio"""

    def __init__(self, success: bool, message: str, location: Optional[Tuple] = None,
                 screenshot_path: Optional[str] = None):
        self.success = success
        self.message = message
        self.location = location          # (x, y) o (x, y, w, h)
        self.screenshot_path = screenshot_path

    def __str__(self):
        return f"DesktopActionResult(success={self.success}, message='{self.message}')"


class DesktopManager:
    """
    Manager para automatización de aplicaciones de escritorio.

    Modos de localización de elementos:
      - Por coordenadas absolutas (x, y)
      - Por imagen de referencia (template matching con OpenCV o PyAutoGUI)
      - Por región de pantalla (x, y, width, height)

    Integración con reportes:
      - Captura screenshots automáticos antes/después de acciones
      - Guarda en el mismo directorio que los screenshots web
    """

    def __init__(self):
        self.logger = logging.getLogger('hakalab_framework.desktop')
        self._check_dependencies()
        self.screenshots_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
        self.images_dir = os.getenv('DESKTOP_IMAGES_DIR', 'desktop_images')
        self.action_pause = float(os.getenv('DESKTOP_ACTION_PAUSE', '0.3'))
        self.search_confidence = float(os.getenv('DESKTOP_IMAGE_CONFIDENCE', '0.85'))
        self.search_timeout = float(os.getenv('DESKTOP_SEARCH_TIMEOUT', '10.0'))
        self.typing_interval = float(os.getenv('DESKTOP_TYPING_INTERVAL', '0.05'))
        Path(self.screenshots_dir).mkdir(exist_ok=True)
        Path(self.images_dir).mkdir(exist_ok=True)

    # ------------------------------------------------------------------
    # Verificación de dependencias
    # ------------------------------------------------------------------

    def _check_dependencies(self):
        if not PYAUTOGUI_AVAILABLE:
            self.logger.warning(
                "PyAutoGUI no está instalado. Ejecuta: pip install pyautogui pillow"
            )
        if not PIL_AVAILABLE:
            self.logger.warning(
                "Pillow no está instalado. Ejecuta: pip install pillow"
            )

    def _require_pyautogui(self):
        if not PYAUTOGUI_AVAILABLE:
            raise ImportError(
                "PyAutoGUI es necesario para automatización de escritorio. "
                "Instala con: pip install pyautogui pillow"
            )

    # ------------------------------------------------------------------
    # Gestión de aplicaciones
    # ------------------------------------------------------------------

    def launch_application(self, app_path: str, args: Optional[List[str]] = None,
                           wait_seconds: float = 2.0) -> subprocess.Popen:
        """Lanza una aplicación de escritorio y espera que cargue"""
        cmd = [app_path] + (args or [])
        self.logger.info(f"Lanzando aplicación: {' '.join(cmd)}")
        process = subprocess.Popen(cmd)
        time.sleep(wait_seconds)
        return process

    def close_application_by_name(self, process_name: str):
        """Cierra una aplicación por nombre de proceso o ruta completa"""
        system = platform.system()
        # Si se pasa ruta completa, extraer solo el nombre del ejecutable
        exe_name = os.path.basename(process_name)
        if system == 'Windows':
            # Intentar con el nombre del ejecutable
            result = subprocess.run(
                ['taskkill', '/F', '/IM', exe_name],
                capture_output=True, text=True
            )
            if result.returncode != 0:
                # Fallback: intentar con la ruta completa via /FI
                subprocess.run(
                    ['taskkill', '/F', '/FI', f'IMAGENAME eq {exe_name}'],
                    capture_output=True
                )
        elif system in ('Linux', 'Darwin'):
            subprocess.run(['pkill', '-f', exe_name], capture_output=True)
        self.logger.info(f"Aplicación cerrada: {exe_name}")

    def bring_window_to_front(self, window_title: str) -> bool:
        """Intenta traer una ventana al frente por título (Windows)"""
        try:
            if platform.system() == 'Windows':
                import ctypes
                user32 = ctypes.windll.user32

                def enum_windows_callback(hwnd, windows):
                    if user32.IsWindowVisible(hwnd):
                        length = user32.GetWindowTextLengthW(hwnd)
                        buff = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buff, length + 1)
                        if window_title.lower() in buff.value.lower():
                            windows.append(hwnd)
                    return True

                windows = []
                ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.POINTER(ctypes.c_int),
                                   ctypes.POINTER(ctypes.c_int))(enum_windows_callback)
                # Usar EnumWindows directamente
                EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
                user32.EnumWindows(EnumWindowsProc(enum_windows_callback), 0)
                if windows:
                    user32.SetForegroundWindow(windows[0])
                    time.sleep(0.3)
                    return True
        except Exception as e:
            self.logger.warning(f"No se pudo traer ventana al frente: {e}")
        return False

    # ------------------------------------------------------------------
    # Screenshots de escritorio
    # ------------------------------------------------------------------

    def take_desktop_screenshot(self, name: str = "desktop") -> str:
        """Toma screenshot de toda la pantalla y lo guarda"""
        self._require_pyautogui()
        timestamp = datetime.now().strftime("%H%M%S")
        clean_name = name.replace(' ', '_').replace(':', '_').replace('/', '_')
        filename = f"{clean_name}_{timestamp}.png"
        filepath = os.path.join(self.screenshots_dir, filename)
        screenshot = pyautogui.screenshot()
        screenshot.save(filepath)
        self.logger.info(f"📸 Screenshot de escritorio guardado: {filepath}")
        return filepath

    def take_region_screenshot(self, x: int, y: int, width: int, height: int,
                               name: str = "region") -> str:
        """Toma screenshot de una región específica de la pantalla"""
        self._require_pyautogui()
        timestamp = datetime.now().strftime("%H%M%S")
        clean_name = name.replace(' ', '_')
        filename = f"{clean_name}_{timestamp}.png"
        filepath = os.path.join(self.screenshots_dir, filename)
        screenshot = pyautogui.screenshot(region=(x, y, width, height))
        screenshot.save(filepath)
        self.logger.info(f"📸 Screenshot de región guardado: {filepath}")
        return filepath

    # ------------------------------------------------------------------
    # Localización de elementos por imagen
    # ------------------------------------------------------------------

    def _resolve_image_path(self, image_name: str) -> str:
        """Resuelve el path de una imagen de referencia"""
        if os.path.isabs(image_name) and os.path.exists(image_name):
            return image_name
        # Buscar en directorio de imágenes de escritorio
        candidate = os.path.join(self.images_dir, image_name)
        if os.path.exists(candidate):
            return candidate
        # Buscar con extensión .png si no la tiene
        if not image_name.endswith('.png'):
            candidate_png = os.path.join(self.images_dir, image_name + '.png')
            if os.path.exists(candidate_png):
                return candidate_png
        # Devolver tal cual (puede fallar después con mensaje claro)
        return candidate

    def find_element_by_image(self, image_name: str,
                              confidence: Optional[float] = None,
                              timeout: Optional[float] = None,
                              region: Optional[Tuple] = None) -> Optional[Tuple]:
        """
        Busca un elemento en pantalla por imagen de referencia.
        Retorna (x, y) del centro del elemento encontrado, o None.
        """
        self._require_pyautogui()
        conf = confidence or self.search_confidence
        tout = timeout or self.search_timeout
        image_path = self._resolve_image_path(image_name)

        if not os.path.exists(image_path):
            raise FileNotFoundError(
                f"Imagen de referencia no encontrada: {image_path}\n"
                f"Coloca la imagen en: {self.images_dir}/"
            )

        start = time.time()
        while time.time() - start < tout:
            try:
                kwargs = {'confidence': conf}
                if region:
                    kwargs['region'] = region
                location = pyautogui.locateCenterOnScreen(image_path, **kwargs)
                if location:
                    self.logger.info(
                        f"✓ Elemento encontrado por imagen '{image_name}' en {location}"
                    )
                    return (location.x, location.y)
            except pyautogui.ImageNotFoundException:
                pass
            except Exception as e:
                self.logger.debug(f"Error buscando imagen: {e}")
            time.sleep(0.5)

        self.logger.warning(
            f"Elemento '{image_name}' no encontrado en pantalla "
            f"(timeout: {tout}s, confidence: {conf})"
        )
        return None

    def find_all_elements_by_image(self, image_name: str,
                                   confidence: Optional[float] = None) -> List[Tuple]:
        """Busca todas las ocurrencias de una imagen en pantalla"""
        self._require_pyautogui()
        conf = confidence or self.search_confidence
        image_path = self._resolve_image_path(image_name)

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Imagen de referencia no encontrada: {image_path}")

        try:
            locations = list(pyautogui.locateAllOnScreen(image_path, confidence=conf))
            centers = [pyautogui.center(loc) for loc in locations]
            result = [(c.x, c.y) for c in centers]
            self.logger.info(f"Encontradas {len(result)} ocurrencias de '{image_name}'")
            return result
        except Exception as e:
            self.logger.warning(f"Error buscando todas las ocurrencias: {e}")
            return []

    def wait_for_image(self, image_name: str, timeout: Optional[float] = None,
                       confidence: Optional[float] = None) -> bool:
        """Espera hasta que aparezca una imagen en pantalla"""
        location = self.find_element_by_image(image_name, confidence=confidence, timeout=timeout)
        return location is not None

    def wait_for_image_to_disappear(self, image_name: str,
                                    timeout: Optional[float] = None,
                                    confidence: Optional[float] = None) -> bool:
        """Espera hasta que una imagen desaparezca de pantalla"""
        self._require_pyautogui()
        conf = confidence or self.search_confidence
        tout = timeout or self.search_timeout
        image_path = self._resolve_image_path(image_name)

        start = time.time()
        while time.time() - start < tout:
            try:
                location = pyautogui.locateCenterOnScreen(image_path, confidence=conf)
                if location is None:
                    return True
            except pyautogui.ImageNotFoundException:
                return True
            except Exception:
                pass
            time.sleep(0.5)
        return False

    # ------------------------------------------------------------------
    # Acciones de mouse - por coordenadas
    # ------------------------------------------------------------------

    def click_at_coordinates(self, x: int, y: int, button: str = 'left',
                             clicks: int = 1, interval: float = 0.1):
        """Click en coordenadas absolutas"""
        self._require_pyautogui()
        self.logger.info(f"Click en coordenadas ({x}, {y}) - botón: {button}")
        pyautogui.click(x, y, button=button, clicks=clicks, interval=interval)

    def double_click_at_coordinates(self, x: int, y: int):
        """Doble click en coordenadas absolutas"""
        self._require_pyautogui()
        self.logger.info(f"Doble click en coordenadas ({x}, {y})")
        pyautogui.doubleClick(x, y)

    def right_click_at_coordinates(self, x: int, y: int):
        """Click derecho en coordenadas absolutas"""
        self._require_pyautogui()
        self.logger.info(f"Click derecho en coordenadas ({x}, {y})")
        pyautogui.rightClick(x, y)

    def move_to_coordinates(self, x: int, y: int, duration: float = 0.3):
        """Mueve el mouse a coordenadas absolutas"""
        self._require_pyautogui()
        pyautogui.moveTo(x, y, duration=duration)

    def drag_from_coordinates_to_coordinates(self, x1: int, y1: int,
                                              x2: int, y2: int,
                                              duration: float = 0.5):
        """Arrastra desde unas coordenadas a otras"""
        self._require_pyautogui()
        self.logger.info(f"Drag de ({x1},{y1}) a ({x2},{y2})")
        pyautogui.moveTo(x1, y1)
        pyautogui.dragTo(x2, y2, duration=duration, button='left')

    # ------------------------------------------------------------------
    # Acciones de mouse - por imagen
    # ------------------------------------------------------------------

    def click_on_image(self, image_name: str, button: str = 'left',
                       confidence: Optional[float] = None,
                       timeout: Optional[float] = None,
                       offset_x: int = 0, offset_y: int = 0):
        """Click en un elemento encontrado por imagen"""
        location = self.find_element_by_image(image_name, confidence=confidence, timeout=timeout)
        if location is None:
            raise AssertionError(
                f"No se pudo hacer click: imagen '{image_name}' no encontrada en pantalla"
            )
        x, y = location[0] + offset_x, location[1] + offset_y
        self.logger.info(f"Click en imagen '{image_name}' en ({x}, {y})")
        pyautogui.click(x, y, button=button)

    def double_click_on_image(self, image_name: str,
                              confidence: Optional[float] = None,
                              timeout: Optional[float] = None):
        """Doble click en un elemento encontrado por imagen"""
        location = self.find_element_by_image(image_name, confidence=confidence, timeout=timeout)
        if location is None:
            raise AssertionError(
                f"No se pudo hacer doble click: imagen '{image_name}' no encontrada"
            )
        self.logger.info(f"Doble click en imagen '{image_name}' en {location}")
        pyautogui.doubleClick(location[0], location[1])

    def right_click_on_image(self, image_name: str,
                             confidence: Optional[float] = None,
                             timeout: Optional[float] = None):
        """Click derecho en un elemento encontrado por imagen"""
        location = self.find_element_by_image(image_name, confidence=confidence, timeout=timeout)
        if location is None:
            raise AssertionError(
                f"No se pudo hacer click derecho: imagen '{image_name}' no encontrada"
            )
        self.logger.info(f"Click derecho en imagen '{image_name}' en {location}")
        pyautogui.rightClick(location[0], location[1])

    def hover_on_image(self, image_name: str,
                       confidence: Optional[float] = None,
                       timeout: Optional[float] = None):
        """Mueve el mouse sobre un elemento encontrado por imagen"""
        location = self.find_element_by_image(image_name, confidence=confidence, timeout=timeout)
        if location is None:
            raise AssertionError(
                f"No se pudo hacer hover: imagen '{image_name}' no encontrada"
            )
        pyautogui.moveTo(location[0], location[1], duration=0.3)

    def drag_image_to_image(self, source_image: str, target_image: str,
                            confidence: Optional[float] = None,
                            duration: float = 0.5):
        """Arrastra desde un elemento imagen a otro elemento imagen"""
        source = self.find_element_by_image(source_image, confidence=confidence)
        if source is None:
            raise AssertionError(f"Imagen origen '{source_image}' no encontrada")
        target = self.find_element_by_image(target_image, confidence=confidence)
        if target is None:
            raise AssertionError(f"Imagen destino '{target_image}' no encontrada")
        self.logger.info(f"Drag de '{source_image}' a '{target_image}'")
        pyautogui.moveTo(source[0], source[1])
        pyautogui.dragTo(target[0], target[1], duration=duration, button='left')

    def drag_image_to_coordinates(self, source_image: str, target_x: int, target_y: int,
                                  confidence: Optional[float] = None,
                                  duration: float = 0.5):
        """Arrastra desde un elemento imagen a coordenadas específicas"""
        source = self.find_element_by_image(source_image, confidence=confidence)
        if source is None:
            raise AssertionError(f"Imagen origen '{source_image}' no encontrada")
        pyautogui.moveTo(source[0], source[1])
        pyautogui.dragTo(target_x, target_y, duration=duration, button='left')

    # ------------------------------------------------------------------
    # Acciones de teclado
    # ------------------------------------------------------------------

    def type_text(self, text: str, interval: Optional[float] = None):
        """Escribe texto en el elemento activo"""
        self._require_pyautogui()
        iv = interval or self.typing_interval
        self.logger.info(f"Escribiendo texto: '{text[:30]}{'...' if len(text) > 30 else ''}'")
        pyautogui.typewrite(text, interval=iv)

    def type_text_with_clipboard(self, text: str):
        """
        Escribe texto usando el portapapeles (más rápido y soporta caracteres especiales).
        Útil para texto con tildes, ñ, etc.
        """
        self._require_pyautogui()
        import pyperclip
        pyperclip.copy(text)
        pyautogui.hotkey('ctrl', 'v')
        self.logger.info(f"Texto pegado desde portapapeles: '{text[:30]}'")

    def press_key(self, key: str):
        """Presiona una tecla especial"""
        self._require_pyautogui()
        self.logger.info(f"Presionando tecla: {key}")
        pyautogui.press(key)

    def press_hotkey(self, *keys: str):
        """Presiona una combinación de teclas"""
        self._require_pyautogui()
        self.logger.info(f"Combinación de teclas: {'+'.join(keys)}")
        pyautogui.hotkey(*keys)

    def key_down(self, key: str):
        """Mantiene presionada una tecla"""
        self._require_pyautogui()
        pyautogui.keyDown(key)

    def key_up(self, key: str):
        """Suelta una tecla"""
        self._require_pyautogui()
        pyautogui.keyUp(key)

    def clear_field_and_type(self, text: str):
        """Limpia el campo activo y escribe texto (Ctrl+A + Delete + typewrite)"""
        self._require_pyautogui()
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.1)
        pyautogui.press('delete')
        time.sleep(0.1)
        self.type_text(text)

    def click_on_image_and_type(self, image_name: str, text: str,
                                clear_first: bool = True,
                                confidence: Optional[float] = None,
                                timeout: Optional[float] = None):
        """Click en un campo (por imagen) y escribe texto"""
        self.click_on_image(image_name, confidence=confidence, timeout=timeout)
        time.sleep(0.2)
        if clear_first:
            self.clear_field_and_type(text)
        else:
            self.type_text(text)

    def click_at_coordinates_and_type(self, x: int, y: int, text: str,
                                      clear_first: bool = True):
        """Click en coordenadas y escribe texto"""
        self.click_at_coordinates(x, y)
        time.sleep(0.2)
        if clear_first:
            self.clear_field_and_type(text)
        else:
            self.type_text(text)

    # ------------------------------------------------------------------
    # Scroll
    # ------------------------------------------------------------------

    def scroll_up(self, clicks: int = 3, x: Optional[int] = None, y: Optional[int] = None):
        """Scroll hacia arriba"""
        self._require_pyautogui()
        if x and y:
            pyautogui.scroll(clicks, x=x, y=y)
        else:
            pyautogui.scroll(clicks)

    def scroll_down(self, clicks: int = 3, x: Optional[int] = None, y: Optional[int] = None):
        """Scroll hacia abajo"""
        self._require_pyautogui()
        if x and y:
            pyautogui.scroll(-clicks, x=x, y=y)
        else:
            pyautogui.scroll(-clicks)

    def scroll_on_image(self, image_name: str, direction: str = 'down',
                        clicks: int = 3, confidence: Optional[float] = None):
        """Scroll sobre un elemento encontrado por imagen"""
        location = self.find_element_by_image(image_name, confidence=confidence)
        if location is None:
            raise AssertionError(f"Imagen '{image_name}' no encontrada para scroll")
        amount = -clicks if direction == 'down' else clicks
        pyautogui.scroll(amount, x=location[0], y=location[1])

    # ------------------------------------------------------------------
    # Esperas
    # ------------------------------------------------------------------

    def wait_seconds(self, seconds: float):
        """Espera un número de segundos"""
        self.logger.info(f"Esperando {seconds} segundos...")
        time.sleep(seconds)

    def wait_for_element_by_image(self, image_name: str,
                                  timeout: Optional[float] = None,
                                  confidence: Optional[float] = None) -> bool:
        """Espera hasta que aparezca un elemento por imagen"""
        return self.wait_for_image(image_name, timeout=timeout, confidence=confidence)

    # ------------------------------------------------------------------
    # Verificaciones visuales
    # ------------------------------------------------------------------

    def is_image_visible(self, image_name: str,
                         confidence: Optional[float] = None) -> bool:
        """Verifica si una imagen está visible en pantalla"""
        self._require_pyautogui()
        conf = confidence or self.search_confidence
        image_path = self._resolve_image_path(image_name)
        if not os.path.exists(image_path):
            return False
        try:
            location = pyautogui.locateCenterOnScreen(image_path, confidence=conf)
            return location is not None
        except pyautogui.ImageNotFoundException:
            return False
        except Exception:
            return False

    def get_screen_size(self) -> Tuple[int, int]:
        """Retorna el tamaño de la pantalla (width, height)"""
        self._require_pyautogui()
        return pyautogui.size()

    def get_mouse_position(self) -> Tuple[int, int]:
        """Retorna la posición actual del mouse"""
        self._require_pyautogui()
        pos = pyautogui.position()
        return (pos.x, pos.y)

    # ------------------------------------------------------------------
    # Portapapeles
    # ------------------------------------------------------------------

    def copy_to_clipboard(self, text: str):
        """Copia texto al portapapeles"""
        try:
            import pyperclip
            pyperclip.copy(text)
            self.logger.info(f"Texto copiado al portapapeles: '{text[:30]}'")
        except ImportError:
            raise ImportError("pyperclip no está instalado. Ejecuta: pip install pyperclip")

    def get_clipboard_content(self) -> str:
        """Obtiene el contenido del portapapeles"""
        try:
            import pyperclip
            return pyperclip.paste()
        except ImportError:
            raise ImportError("pyperclip no está instalado. Ejecuta: pip install pyperclip")

    def copy_selected_text(self) -> str:
        """Copia el texto seleccionado y lo retorna"""
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(0.3)
        return self.get_clipboard_content()

    def read_text_from_screen_ocr(self, min_confidence: float = 50.0) -> str:
        """Lee todo el texto visible en pantalla usando OCR"""
        path = self.take_desktop_screenshot("ocr_read")
        try:
            from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
            ocr = OCRManagerSimple()
            return ocr.get_all_text(path, min_confidence=min_confidence)
        except Exception as e:
            self.logger.error(f"Error en OCR: {e}")
            return ""

    def read_text_from_region_ocr(self, x: int, y: int, width: int, height: int,
                                   min_confidence: float = 50.0) -> str:
        """Lee texto de una región específica de pantalla usando OCR"""
        path = self.take_region_screenshot(x, y, width, height, "ocr_region_read")
        try:
            from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
            ocr = OCRManagerSimple()
            return ocr.get_all_text(path, min_confidence=min_confidence)
        except Exception as e:
            self.logger.error(f"Error en OCR de región: {e}")
            return ""

    def select_all_and_copy(self) -> str:
        """Selecciona todo el contenido del elemento activo y lo copia"""
        self._require_pyautogui()
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.2)
        pyautogui.hotkey('ctrl', 'c')
        time.sleep(0.3)
        return self.get_clipboard_content()

    # ------------------------------------------------------------------
    # Utilidades de contexto mixto (web + escritorio)
    # ------------------------------------------------------------------

    def switch_to_desktop_mode(self, context) -> None:
        """
        Marca el contexto como modo escritorio.
        Guarda el estado del navegador web si existe.
        """
        context.desktop_mode = True
        context.desktop_manager = self
        if hasattr(context, 'page') and context.page:
            context._saved_web_page = context.page
            self.logger.info("🖥️ Cambiado a modo escritorio (página web guardada)")
        else:
            self.logger.info("🖥️ Modo escritorio activado")

    def switch_to_web_mode(self, context) -> None:
        """
        Restaura el modo web.
        Recupera la página del navegador si fue guardada.
        """
        context.desktop_mode = False
        if hasattr(context, '_saved_web_page') and context._saved_web_page:
            context.page = context._saved_web_page
            self.logger.info("🌐 Cambiado a modo web (página web restaurada)")
        else:
            self.logger.info("🌐 Modo web activado")
