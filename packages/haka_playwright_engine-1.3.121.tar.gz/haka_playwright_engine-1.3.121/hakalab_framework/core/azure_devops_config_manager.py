"""
Gestor de configuración Azure DevOps desde archivo JSON.

Carga y valida azure_devops_config.json ubicado en la raíz del proyecto
para determinar qué adjuntos enviar, qué campos actualizar por tipo de
work item, y cómo se comporta la integración con Azure DevOps.

Estructura homóloga a JiraConfigManager.
"""
import json
import os
from typing import Any, Dict, List, Optional


DEFAULT_CONFIG_FILENAME = "azure_devops_config.json"


class AzureDevOpsConfigManager:
    """Carga, valida y expone la configuración de Azure DevOps desde un JSON."""

    def __init__(self, config_path: str = None):
        self.config_path = config_path or self._find_config_file()
        self._raw: Dict[str, Any] = {}
        self._loaded = False
        self._errors: List[str] = []

        if self.config_path and os.path.exists(self.config_path):
            self._load()

    # ------------------------------------------------------------------
    # Propiedades
    # ------------------------------------------------------------------

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    @property
    def errors(self) -> List[str]:
        return list(self._errors)

    @property
    def comentario(self) -> str:
        return self._raw.get("comentario", "")

    @property
    def configuracion(self) -> Dict[str, Any]:
        return self._raw.get("configuracion", {})

    @property
    def adjuntar_html(self) -> bool:
        return self.configuracion.get("adjuntar_html", False)

    @property
    def adjuntar_video(self) -> bool:
        return self.configuracion.get("adjuntar_video", False)

    @property
    def adjuntar_screenshots(self) -> bool:
        return self.configuracion.get("adjuntar_screenshots", False)

    @property
    def comentar_resultado(self) -> bool:
        return self.configuracion.get("comentar_resultado", True)

    @property
    def crear_issue_on_failure(self) -> bool:
        return self.configuracion.get("crear_issue_on_failure", False)

    @property
    def tipo_issue_on_failure(self) -> str:
        return self.configuracion.get("tipo_issue_on_failure", "")

    @property
    def tags(self) -> List[Dict[str, Any]]:
        return self._raw.get("tags", [])

    # ------------------------------------------------------------------
    # Métodos públicos
    # ------------------------------------------------------------------

    def get_tag_config(self, tipo: str) -> Optional[Dict[str, Any]]:
        """Obtiene la configuración de campos para un tipo de work item."""
        for tag in self.tags:
            if tag.get("tipo", "").lower() == tipo.lower():
                return tag
        return None

    def get_campos_por_tipo(self, tipo: str) -> List[Dict[str, Any]]:
        """Retorna la lista de campos configurados para un tipo de work item."""
        tag_config = self.get_tag_config(tipo)
        if tag_config:
            return tag_config.get("campos", [])
        return []

    def get_valores_campo(self, tipo: str, campo_id: str) -> List[str]:
        """Retorna los valores permitidos para un campo de un tipo de work item."""
        campos = self.get_campos_por_tipo(tipo)
        for campo in campos:
            if campo.get("id") == campo_id:
                return campo.get("valores", [])
        return []

    def get_tipos_disponibles(self) -> List[str]:
        """Retorna los tipos de work item configurados."""
        return [tag.get("tipo", "") for tag in self.tags if tag.get("tipo")]

    def to_dict(self) -> Dict[str, Any]:
        """Retorna la configuración completa como diccionario."""
        return dict(self._raw)

    # ------------------------------------------------------------------
    # Métodos privados
    # ------------------------------------------------------------------

    def _find_config_file(self) -> Optional[str]:
        """Busca azure_devops_config.json en la raíz del proyecto."""
        candidate = os.path.join(os.getcwd(), DEFAULT_CONFIG_FILENAME)
        if os.path.exists(candidate):
            return candidate

        current = os.getcwd()
        for _ in range(5):
            path = os.path.join(current, DEFAULT_CONFIG_FILENAME)
            if os.path.exists(path):
                return path
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent

        return None

    def _load(self):
        """Carga y valida el archivo JSON."""
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                self._raw = json.load(f)
            self._validate()
            if not self._errors:
                self._loaded = True
                print(f"✅ Configuración Azure DevOps cargada desde: {self.config_path}")
            else:
                print(f"⚠️ Configuración Azure DevOps con errores: {', '.join(self._errors)}")
        except json.JSONDecodeError as e:
            self._errors.append(f"JSON inválido: {e}")
            print(f"❌ Error al parsear {self.config_path}: {e}")
        except Exception as e:
            self._errors.append(str(e))
            print(f"❌ Error al cargar configuración Azure DevOps: {e}")

    def _validate(self):
        """Valida la estructura del JSON."""
        if not isinstance(self._raw, dict):
            self._errors.append("El JSON raíz debe ser un objeto")
            return

        config = self._raw.get("configuracion")
        if config is not None and not isinstance(config, dict):
            self._errors.append("'configuracion' debe ser un objeto")

        tags = self._raw.get("tags")
        if tags is not None:
            if not isinstance(tags, list):
                self._errors.append("'tags' debe ser una lista")
            else:
                for i, tag in enumerate(tags):
                    self._validate_tag(tag, i)

    def _validate_tag(self, tag: Dict, index: int):
        """Valida un elemento de la lista de tags."""
        if not isinstance(tag, dict):
            self._errors.append(f"tags[{index}] debe ser un objeto")
            return

        if "tipo" not in tag:
            self._errors.append(f"tags[{index}] requiere el campo 'tipo'")

        campos = tag.get("campos", [])
        if not isinstance(campos, list):
            self._errors.append(f"tags[{index}].campos debe ser una lista")
            return

        for j, campo in enumerate(campos):
            if not isinstance(campo, dict):
                self._errors.append(f"tags[{index}].campos[{j}] debe ser un objeto")
                continue
            if "id" not in campo:
                self._errors.append(f"tags[{index}].campos[{j}] requiere 'id'")
            if "valores" in campo and not isinstance(campo["valores"], list):
                self._errors.append(f"tags[{index}].campos[{j}].valores debe ser una lista")
