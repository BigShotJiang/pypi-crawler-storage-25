"""
Template de environment.py para haka-playwright-engine v1.3.23+
Enfoque simple y limpio - Sistema de screenshots independiente
INCLUYE: Soft Assertions para validaciones continuas

CARACTERÍSTICAS:
- Sistema de reintentos automáticos de escenarios fallidos
- Soft Assertions: Continuar validaciones incluso después de fallos
- Configuración mediante variables de entorno:
  * RETRY_FAILED_SCENARIOS=true/false
  * MAX_SCENARIO_RETRIES=1-5

Versiones soportadas:
- Playwright >= 1.57.0
- Behave >= 1.3.3  
"""

from hakalab_framework import (
    setup_framework_context,
    setup_scenario_context
)
from hakalab_framework.core.screenshot_manager import take_screenshot_on_failure, take_screenshot
from hakalab_framework.core.environment_config import auto_after_scenario
from hakalab_framework.core.soft_assertion_hooks import (
    before_scenario_soft_assertions,
    after_step_soft_assertions,
    after_scenario_soft_assertions
)

# Importar steps directamente para que Behave los reconozca
from hakalab_framework.steps import *

def before_all(context):
    """Configuración inicial - El framework hace todo el trabajo"""
    try:
        # Limpiar archivos antiguos si está habilitado
        from hakalab_framework.core.screenshot_manager import cleanup_directories
        cleanup_directories()
        
        setup_framework_context(context)
    except Exception as e:
        print(f"Error en before_all: {e}")
        raise

def before_scenario(context, scenario):
    """Configuración por escenario - El framework maneja todo"""
    try:
        # Verificar si el escenario tiene el tag @no_browser
        if hasattr(scenario, 'tags') and 'no_browser' in [tag.lower() for tag in scenario.tags]:
            context.browser_disabled = True
            context.logger.info("🚫 Tag @no_browser detectado - navegador desactivado")
        
        setup_scenario_context(context, scenario)
        
        # Inicializar soft assertions si el escenario tiene el tag
        before_scenario_soft_assertions(context, scenario)
        
    except Exception as e:
        print(f"Error en before_scenario: {e}")
        raise

def after_step(context, step):
    """Capturar screenshot después de cada paso y manejar soft assertions"""
    try:
        # Manejar soft assertions ANTES de capturar screenshot
        after_step_soft_assertions(context, step)
        
        if hasattr(context, 'page') and context.page:
            # Generar nombre del screenshot basado en el paso
            step_name = step.name.replace(' ', '_').replace('"', '').replace("'", '')
            screenshot_name = f"step_{step.line}_{step_name[:50]}"
            
            # Capturar screenshot usando el framework
            take_screenshot(context, screenshot_name)
    except Exception as e:
        print(f"Error capturando screenshot en step: {e}")

def after_scenario(context, scenario):
    """
    Hook después de cada escenario
    
    Maneja:
    - Soft Assertions: Verificar errores acumulados
    - Screenshots en caso de fallo
    - Sistema de reintentos automáticos (si está habilitado)
    - Limpieza de recursos
    """
    # Verificar soft assertions PRIMERO
    try:
        after_scenario_soft_assertions(context, scenario)
    except AssertionError:
        # El escenario ya está marcado como failed
        pass
    
    try:
        take_screenshot_on_failure(context, scenario)
    except:
        pass
    
    # Ejecutar lógica de reintentos automáticos del framework
    try:
        auto_after_scenario(context, scenario)
    except Exception as e:
        print(f"⚠️ Error en sistema de reintentos: {e}")
    
    # Cerrar página actual para liberar memoria (solo si no hay reintentos pendientes)
    try:
        if hasattr(context, 'page') and context.page:
            # No cerrar la página si hay un reintento pendiente
            if not getattr(scenario, '_retry_requested', False):
                context.page.close()
                context.page = None
    except:
        pass

def after_all(context):
    """Cerrar Playwright y mostrar resumen"""
    # Cerrar Playwright
    try:
        if hasattr(context, 'framework_config') and context.framework_config:
            context.framework_config.cleanup()
            print("✅ Playwright cerrado correctamente")
    except Exception as e:
        print(f"❌ Error cerrando Playwright: {e}")
    
    # Mostrar resumen de screenshots
    try:
        from hakalab_framework.core.screenshot_manager import get_screenshots_summary
        summary = get_screenshots_summary()
        if summary["total"] > 0:
            print(f"📸 Screenshots generados: {summary['total']} total, {summary['failed']} fallos")
    except:
        pass