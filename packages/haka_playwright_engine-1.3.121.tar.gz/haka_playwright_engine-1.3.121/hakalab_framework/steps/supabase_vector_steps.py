"""
Steps para integración con Supabase Vector Database
Permite búsqueda semántica en bases de datos vectorizadas usando Gemini
"""
from behave import step
import os
import json

# Importación lazy de dependencias opcionales
def get_supabase_client():
    """Obtiene el cliente de Supabase con auto-instalación"""
    try:
        from supabase import create_client, Client
        return create_client
    except ImportError:
        raise ImportError(
            "Supabase no está instalado. Instala con: pip install supabase"
        )

def get_gemini_client():
    """Obtiene el cliente de Gemini para embeddings"""
    try:
        from google import genai
        from google.genai import types
        return genai, types
    except ImportError:
        raise ImportError(
            "Google GenAI no está instalado. Instala con: pip install google-genai"
        )


def _load_context_to_gemini_from_text(context, context_name, content):
    """Carga un contexto de texto directamente en Gemini
    
    Esta función interna permite cargar contexto desde Supabase sin necesidad de archivos .txt
    
    Args:
        context: Contexto de Behave
        context_name: Nombre del contexto para Gemini
        content: Contenido del contexto (texto)
    """
    try:
        from google.genai import types
    except ImportError:
        raise ImportError(
            "La librería 'google-genai' no está instalada.\n"
            "Para usar Gemini, instálala con: pip install google-genai"
        )
    
    # Inicializar estructuras si no existen
    if not hasattr(context, 'genai_contexts'):
        context.genai_contexts = {}
    
    if not hasattr(context, 'genai_caches'):
        context.genai_caches = {}
    
    # Obtener modelo configurado
    model_name = os.environ.get('GEMINI_JUDGE_MODEL', 'gemini-2.5-pro')
    
    # Contar tokens aproximados
    token_count = len(content) // 4
    
    # Obtener umbral de caching configurado
    cache_threshold = int(os.environ.get('GEMINI_CACHE_THRESHOLD', '32000'))
    
    # Decidir estrategia según tamaño
    if token_count >= cache_threshold:
        # Usar Context Caching
        print(f"🔄 Usando Context Caching (tokens >= {cache_threshold})")
        
        # Crear caché
        import hashlib
        cache_key = hashlib.md5(content.encode('utf-8')).hexdigest()
        
        if cache_key in context.genai_caches:
            print(f"✓ Reutilizando caché existente: {cache_key[:8]}...")
            cached_content = context.genai_caches[cache_key]
        else:
            try:
                cached_content = context.genai_client.caches.create(
                    model=model_name,
                    config=types.CreateCachedContentConfig(
                        display_name=f'context_{context_name}',
                        system_instruction=(
                            "Eres un Auditor de Calidad estricto. "
                            "Tu trabajo es evaluar respuestas de IA contra el contexto de negocio proporcionado. "
                            "Debes ser objetivo, preciso y crítico."
                        ),
                        contents=[
                            types.Content(
                                role='user',
                                parts=[types.Part(text=content)]
                            )
                        ],
                        ttl='3600s',
                    )
                )
                context.genai_caches[cache_key] = cached_content
                print(f"✓ Caché creado exitosamente")
            except Exception as e:
                raise Exception(f"Error creando Context Cache: {e}")
        
        context.genai_contexts[context_name] = {
            'type': 'cache',
            'cache': cached_content,
            'cache_key': cache_key,
            'token_count': token_count,
            'source': 'supabase',
            'original_content': content  # NUEVO: Guardar contenido original para validaciones
        }
    else:
        # Usar System Instruction (sin caché)
        print(f"📝 Usando System Instruction (tokens < {cache_threshold})")
        
        context.genai_contexts[context_name] = {
            'type': 'system_instruction',
            'content': content,
            'token_count': token_count,
            'source': 'supabase'
        }
    
    # Establecer contexto activo
    context.active_context_name = context_name


# ============================================================================
# CONEXIÓN A SUPABASE
# ============================================================================

@step('me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"')
@step('que me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"')
def step_connect_to_supabase(context, supabase_url, supabase_key):
    """Conecta a Supabase usando URL y API key
    
    Args:
        supabase_url: URL del proyecto Supabase
        supabase_key: API key de Supabase (anon o service_role)
    
    Ejemplo:
        Given me conecto a Supabase con URL "${SUPABASE_URL}" y key "${SUPABASE_KEY}"
    """
    create_client = get_supabase_client()
    
    # Resolver variables
    resolved_url = context.variable_manager.resolve_variables(supabase_url)
    resolved_key = context.variable_manager.resolve_variables(supabase_key)
    
    try:
        context.supabase_client = create_client(resolved_url, resolved_key)
        print(f"✓ Conectado a Supabase: {resolved_url}")
    except Exception as e:
        raise AssertionError(f"Error conectando a Supabase: {e}")


@step('me conecto a Supabase usando variables de entorno')
@step('que me conecto a Supabase usando variables de entorno')
def step_connect_to_supabase_from_env(context):
    """Conecta a Supabase usando variables de entorno SUPABASE_URL y SUPABASE_KEY
    
    Variables requeridas:
        - SUPABASE_URL: URL del proyecto
        - SUPABASE_KEY: API key
    
    Ejemplo:
        Given me conecto a Supabase usando variables de entorno
    """
    supabase_url = os.getenv('SUPABASE_URL')
    supabase_key = os.getenv('SUPABASE_KEY')
    
    if not supabase_url or not supabase_key:
        raise AssertionError(
            "Variables SUPABASE_URL y SUPABASE_KEY deben estar definidas en .env"
        )
    
    step_connect_to_supabase(context, supabase_url, supabase_key)


# ============================================================================
# BÚSQUEDA VECTORIAL
# ============================================================================

@step('busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"')
@step('que busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"')
def step_search_vector_context(context, table_name, query, variable_name):
    """Busca contexto similar usando búsqueda vectorial en Supabase con Gemini
    
    IMPORTANTE: Este paso ahora carga automáticamente el contexto en Gemini para validación.
    El contexto se guarda con el nombre especificado en variable_name.
    
    Args:
        table_name: Nombre de la tabla con embeddings
        query: Texto de búsqueda
        variable_name: Variable donde guardar el resultado Y nombre del contexto en Gemini
    
    Nota: Requiere que la tabla tenga una función RPC para búsqueda vectorial
    
    Ejemplo:
        When busco en la tabla "knowledge_base" el contexto más similar a "política de devoluciones" y lo guardo en "context"
        # Ahora puedes usar directamente:
        Then valido con Gemini que según el contexto para la pregunta "..." la respuesta "..." es válida con umbral 0.8
    """
    if not hasattr(context, 'supabase_client'):
        raise AssertionError("No hay conexión a Supabase. Usa 'me conecto a Supabase' primero.")
    
    # Resolver variables
    resolved_query = context.variable_manager.resolve_variables(query)
    resolved_table = context.variable_manager.resolve_variables(table_name)
    
    try:
        # Generar embedding para la query usando Gemini
        genai, types = get_gemini_client()
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise AssertionError("GEMINI_API_KEY no está definida en .env")
        
        client = genai.Client(api_key=api_key)
        
        # Guardar cliente en contexto si no existe
        if not hasattr(context, 'genai_client'):
            context.genai_client = client
        
        # Usar modelo de embeddings de Gemini (gemini-embedding-001 es el modelo correcto para la nueva API)
        result = client.models.embed_content(
            model="gemini-embedding-001",
            contents=resolved_query
        )
        query_embedding = result.embeddings[0].values
        
        # Buscar en Supabase usando función RPC
        # Asume que existe una función match_documents(query_embedding, match_threshold, match_count)
        result = context.supabase_client.rpc(
            'match_documents',
            {
                'query_embedding': query_embedding,
                'match_threshold': 0.7,
                'match_count': 5
            }
        ).execute()
        
        if result.data:
            # Concatenar los documentos encontrados
            context_text = "\n\n".join([doc['content'] for doc in result.data])
            context.variable_manager.set_variable(variable_name, context_text)
            print(f"✓ Encontrados {len(result.data)} documentos similares")
            print(f"✓ Contexto guardado en variable '{variable_name}'")
            
            # NUEVO: Cargar automáticamente el contexto en Gemini
            # Esto permite usar directamente los pasos de validación sin pasos intermedios
            _load_context_to_gemini_from_text(context, variable_name, context_text)
            print(f"✓ Contexto cargado automáticamente en Gemini como '{variable_name}'")
            
        else:
            print("⚠️ No se encontraron documentos similares")
            context.variable_manager.set_variable(variable_name, "")
            raise AssertionError(f"No se encontró contexto relevante en Supabase para: {resolved_query}")
            
    except Exception as e:
        if "AssertionError" in str(type(e)):
            raise
        raise AssertionError(f"Error en búsqueda vectorial: {e}")


@step('busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"')
@step('que busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"')
def step_search_multiple_vector_contexts(context, table_name, count, query, variable_name):
    """Busca múltiples contextos similares usando búsqueda vectorial con Gemini
    
    IMPORTANTE: Este paso ahora carga automáticamente el contexto en Gemini para validación.
    El contexto se guarda con el nombre especificado en variable_name.
    
    Args:
        table_name: Nombre de la tabla con embeddings
        count: Número de resultados a retornar
        query: Texto de búsqueda
        variable_name: Variable donde guardar los resultados Y nombre del contexto en Gemini
    
    Ejemplo:
        When busco en la tabla "knowledge_base" los 3 contextos más similares a "política de devoluciones" y los guardo en "contexts"
        # Ahora puedes usar directamente:
        Then valido con Gemini que según el contexto para la pregunta "..." la respuesta "..." es válida con umbral 0.8
    """
    if not hasattr(context, 'supabase_client'):
        raise AssertionError("No hay conexión a Supabase. Usa 'me conecto a Supabase' primero.")
    
    # Resolver variables
    resolved_query = context.variable_manager.resolve_variables(query)
    resolved_table = context.variable_manager.resolve_variables(table_name)
    match_count = int(count)
    
    try:
        # Generar embedding para la query usando Gemini
        genai, types = get_gemini_client()
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise AssertionError("GEMINI_API_KEY no está definida en .env")
        
        client = genai.Client(api_key=api_key)
        
        # Guardar cliente en contexto si no existe
        if not hasattr(context, 'genai_client'):
            context.genai_client = client
        
        result = client.models.embed_content(
            model="gemini-embedding-001",
            contents=resolved_query
        )
        query_embedding = result.embeddings[0].values
        
        # Buscar en Supabase
        result = context.supabase_client.rpc(
            'match_documents',
            {
                'query_embedding': query_embedding,
                'match_threshold': 0.7,
                'match_count': match_count
            }
        ).execute()
        
        if result.data:
            # Guardar como lista de documentos
            context.variable_manager.set_variable(variable_name, result.data)
            print(f"✓ Encontrados {len(result.data)} documentos similares")
            print(f"✓ Documentos guardados en variable '{variable_name}'")
            
            # NUEVO: Concatenar documentos y cargar automáticamente en Gemini
            context_text = "\n\n".join([doc['content'] for doc in result.data])
            _load_context_to_gemini_from_text(context, variable_name, context_text)
            print(f"✓ Contexto cargado automáticamente en Gemini como '{variable_name}'")
            
        else:
            print("⚠️ No se encontraron documentos similares")
            context.variable_manager.set_variable(variable_name, [])
            raise AssertionError(f"No se encontró contexto relevante en Supabase para: {resolved_query}")
            
    except Exception as e:
        if "AssertionError" in str(type(e)):
            raise
        raise AssertionError(f"Error en búsqueda vectorial: {e}")


@step('cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"')
@step('que cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"')
def step_load_supabase_context_to_gemini(context, table_name, query, context_name):
    """Busca contexto en Supabase y lo carga directamente en Gemini
    
    Args:
        table_name: Tabla de Supabase con embeddings
        query: Query de búsqueda
        context_name: Nombre del contexto para Gemini
    
    Ejemplo:
        Given cargo el contexto de Supabase tabla "knowledge_base" para la query "políticas de atención" en el contexto de Gemini "customer_service"
    """
    if not hasattr(context, 'supabase_client'):
        raise AssertionError("No hay conexión a Supabase. Usa 'me conecto a Supabase' primero.")
    
    # Resolver variables
    resolved_query = context.variable_manager.resolve_variables(query)
    resolved_table = context.variable_manager.resolve_variables(table_name)
    
    try:
        # Generar embedding y buscar usando Gemini
        genai, types = get_gemini_client()
        api_key = os.getenv('GEMINI_API_KEY')
        if not api_key:
            raise AssertionError("GEMINI_API_KEY no está definida en .env")
        
        client = genai.Client(api_key=api_key)
        
        result = client.models.embed_content(
            model="gemini-embedding-001",
            contents=resolved_query
        )
        query_embedding = result.embeddings[0].values
        
        # Buscar en Supabase
        result = context.supabase_client.rpc(
            'match_documents',
            {
                'query_embedding': query_embedding,
                'match_threshold': 0.7,
                'match_count': 5
            }
        ).execute()
        
        if not result.data:
            raise AssertionError(f"No se encontró contexto relevante en Supabase para: {resolved_query}")
        
        # Concatenar documentos
        context_content = "\n\n".join([doc['content'] for doc in result.data])
        
        # Cargar en Gemini usando el step existente
        # Guardar temporalmente en archivo
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
            f.write(context_content)
            temp_file = f.name
        
        try:
            # Importar el step de carga de contexto de Gemini
            from hakalab_framework.steps.genai_evaluation_steps import step_load_business_context
            step_load_business_context(context, context_name, temp_file)
            print(f"✓ Contexto de Supabase cargado en Gemini como '{context_name}'")
            print(f"✓ {len(result.data)} documentos encontrados y cargados")
        finally:
            # Limpiar archivo temporal
            import os
            os.unlink(temp_file)
            
    except Exception as e:
        raise AssertionError(f"Error cargando contexto de Supabase a Gemini: {e}")


# ============================================================================
# CONSULTAS DIRECTAS A TABLAS
# ============================================================================

@step('consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"')
@step('que consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"')
def step_query_supabase_table(context, table_name, variable_name):
    """Consulta una tabla de Supabase y guarda el resultado
    
    Args:
        table_name: Nombre de la tabla
        variable_name: Variable donde guardar el resultado
    
    Ejemplo:
        When consulto la tabla "products" en Supabase y guardo el resultado en "products_list"
    """
    if not hasattr(context, 'supabase_client'):
        raise AssertionError("No hay conexión a Supabase. Usa 'me conecto a Supabase' primero.")
    
    resolved_table = context.variable_manager.resolve_variables(table_name)
    
    try:
        result = context.supabase_client.table(resolved_table).select("*").execute()
        context.variable_manager.set_variable(variable_name, result.data)
        print(f"✓ Consultados {len(result.data)} registros de '{resolved_table}'")
    except Exception as e:
        raise AssertionError(f"Error consultando tabla: {e}")


@step('consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"')
@step('que consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"')
def step_query_supabase_table_filtered(context, table_name, column, value, variable_name):
    """Consulta una tabla de Supabase con filtro
    
    Args:
        table_name: Nombre de la tabla
        column: Columna para filtrar
        value: Valor del filtro
        variable_name: Variable donde guardar el resultado
    
    Ejemplo:
        When consulto la tabla "products" filtrando por "category" igual a "electronics" y guardo en "electronics"
    """
    if not hasattr(context, 'supabase_client'):
        raise AssertionError("No hay conexión a Supabase. Usa 'me conecto a Supabase' primero.")
    
    resolved_table = context.variable_manager.resolve_variables(table_name)
    resolved_column = context.variable_manager.resolve_variables(column)
    resolved_value = context.variable_manager.resolve_variables(value)
    
    try:
        result = context.supabase_client.table(resolved_table).select("*").eq(resolved_column, resolved_value).execute()
        context.variable_manager.set_variable(variable_name, result.data)
        print(f"✓ Encontrados {len(result.data)} registros donde {resolved_column}={resolved_value}")
    except Exception as e:
        raise AssertionError(f"Error consultando tabla con filtro: {e}")
