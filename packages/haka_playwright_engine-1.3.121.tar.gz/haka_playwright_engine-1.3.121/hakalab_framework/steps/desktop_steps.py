﻿#!/usr/bin/env python3
import os, time
from behave import step

def _dm(context):
    if not hasattr(context, 'desktop_manager') or context.desktop_manager is None:
        from hakalab_framework.core.desktop_manager import DesktopManager
        context.desktop_manager = DesktopManager()
    # Marcar que el step actual es de escritorio para que el reporte use PyAutoGUI
    context._current_step_is_desktop = True
    return context.desktop_manager

def _r(context, value):
    if hasattr(context, 'variable_manager'):
        return context.variable_manager.resolve_variables(str(value))
    return str(value)

def _log(context, msg):
    if hasattr(context, 'logger'): context.logger.info(msg)
    else: print(msg)


# ===========================================================================
# SECCION 1 - GESTION DE APLICACIONES
# Regla: cada variante tiene un VERBO distinto al inicio
# ===========================================================================

@step('I launch application "{app_path}"')
@step('abro la aplicacion "{app_path}"')
@step('que abro la aplicacion "{app_path}"')
def step_launch_application(context, app_path):
    """Lanza una aplicacion y espera 2 segundos."""
    _dm(context).launch_application(_r(context, app_path), wait_seconds=2.0)
    _log(context, f"Aplicacion lanzada: {app_path}")


@step('I launch and wait "{seconds}" seconds for application "{app_path}"')
@step('lanzo y espero "{seconds}" segundos la aplicacion "{app_path}"')
@step('que lanzo y espero "{seconds}" segundos la aplicacion "{app_path}"')
def step_launch_application_wait(context, seconds, app_path):
    """Lanza una aplicacion y espera el tiempo indicado."""
    _dm(context).launch_application(_r(context, app_path), wait_seconds=float(seconds))
    _log(context, f"Aplicacion lanzada: {app_path} (espera: {seconds}s)")


@step('I launch with arguments "{args}" the application "{app_path}"')
@step('lanzo con argumentos "{args}" la aplicacion "{app_path}"')
@step('que lanzo con argumentos "{args}" la aplicacion "{app_path}"')
def step_launch_application_with_args(context, args, app_path):
    """Lanza una aplicacion con argumentos de linea de comandos."""
    _dm(context).launch_application(_r(context, app_path), args=_r(context, args).split(), wait_seconds=2.0)
    _log(context, f"Aplicacion lanzada: {app_path} args={args}")


@step('I close application "{process_name}"')
@step('cierro la aplicacion "{process_name}"')
@step('que cierro la aplicacion "{process_name}"')
def step_close_application(context, process_name):
    """Cierra una aplicacion por nombre de proceso."""
    _dm(context).close_application_by_name(_r(context, process_name))
    _log(context, f"Aplicacion cerrada: {process_name}")


@step('I bring window "{window_title}" to front')
@step('traigo la ventana "{window_title}" al frente')
@step('que traigo la ventana "{window_title}" al frente')
def step_bring_window_to_front(context, window_title):
    """Trae una ventana al frente por su titulo."""
    _dm(context).bring_window_to_front(_r(context, window_title))
    _log(context, f"Ventana '{window_title}' al frente")


# ===========================================================================
# SECCION 2 - CLICKS POR COORDENADAS
# Regla: cada variante tiene verbo distinto al inicio
# ===========================================================================

@step('I click at coordinates "{x}" "{y}"')
@step('hago click en las coordenadas "{x}" "{y}"')
@step('que hago click en las coordenadas "{x}" "{y}"')
def step_click_at_coordinates(context, x, y):
    """Click izquierdo en coordenadas absolutas."""
    _dm(context).click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Click en ({x},{y})")


@step('I double click at coordinates "{x}" "{y}"')
@step('hago doble click en las coordenadas "{x}" "{y}"')
@step('que hago doble click en las coordenadas "{x}" "{y}"')
def step_double_click_at_coordinates(context, x, y):
    """Doble click en coordenadas absolutas."""
    _dm(context).double_click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Doble click en ({x},{y})")


@step('I right click at coordinates "{x}" "{y}"')
@step('hago click derecho en las coordenadas "{x}" "{y}"')
@step('que hago click derecho en las coordenadas "{x}" "{y}"')
def step_right_click_at_coordinates(context, x, y):
    """Click derecho en coordenadas absolutas."""
    _dm(context).right_click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Click derecho en ({x},{y})")


@step('I move mouse to coordinates "{x}" "{y}"')
@step('muevo el mouse a las coordenadas "{x}" "{y}"')
@step('que muevo el mouse a las coordenadas "{x}" "{y}"')
def step_move_mouse_to_coordinates(context, x, y):
    """Mueve el mouse a coordenadas sin hacer click."""
    _dm(context).move_to_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Mouse movido a ({x},{y})")


@step('I type at coordinates "{x}" "{y}" the text "{text}"')
@step('escribo en las coordenadas "{x}" "{y}" el texto "{text}"')
@step('que escribo en las coordenadas "{x}" "{y}" el texto "{text}"')
def step_click_coordinates_and_type(context, x, y, text):
    """Click en coordenadas y escribe texto, limpiando el campo antes."""
    _dm(context).click_at_coordinates_and_type(int(_r(context, x)), int(_r(context, y)), _r(context, text))
    _log(context, f"Click en ({x},{y}) y texto: '{text}'")


@step('I drag from coordinates "{x1}" "{y1}" to coordinates "{x2}" "{y2}"')
@step('arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"')
@step('que arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"')
def step_drag_coordinates_to_coordinates(context, x1, y1, x2, y2):
    """Arrastra el mouse de unas coordenadas a otras."""
    _dm(context).drag_from_coordinates_to_coordinates(
        int(_r(context, x1)), int(_r(context, y1)),
        int(_r(context, x2)), int(_r(context, y2))
    )
    _log(context, f"Drag ({x1},{y1}) -> ({x2},{y2})")


# ===========================================================================
# SECCION 3 - CLICKS POR IMAGEN
# Regla: variantes con parametros extra usan VERBO distinto al inicio
# ===========================================================================

@step('I click on image "{image_name}"')
@step('hago click en la imagen "{image_name}"')
@step('que hago click en la imagen "{image_name}"')
def step_click_on_image(context, image_name):
    """Click izquierdo en elemento encontrado por imagen."""
    _dm(context).click_on_image(_r(context, image_name))
    _log(context, f"Click en imagen '{image_name}'")


@step('I double click on image "{image_name}"')
@step('hago doble click en la imagen "{image_name}"')
@step('que hago doble click en la imagen "{image_name}"')
def step_double_click_on_image(context, image_name):
    """Doble click en elemento encontrado por imagen."""
    _dm(context).double_click_on_image(_r(context, image_name))
    _log(context, f"Doble click en imagen '{image_name}'")


@step('I right click on image "{image_name}"')
@step('hago click derecho en la imagen "{image_name}"')
@step('que hago click derecho en la imagen "{image_name}"')
def step_right_click_on_image(context, image_name):
    """Click derecho en elemento encontrado por imagen."""
    _dm(context).right_click_on_image(_r(context, image_name))
    _log(context, f"Click derecho en imagen '{image_name}'")


@step('I hover over image "{image_name}"')
@step('paso el mouse sobre la imagen "{image_name}"')
@step('que paso el mouse sobre la imagen "{image_name}"')
def step_hover_on_image(context, image_name):
    """Hover sobre elemento encontrado por imagen."""
    _dm(context).hover_on_image(_r(context, image_name))
    _log(context, f"Hover sobre imagen '{image_name}'")


@step('I click with confidence "{confidence}" on image "{image_name}"')
@step('hago click con confianza "{confidence}" en la imagen "{image_name}"')
@step('que hago click con confianza "{confidence}" en la imagen "{image_name}"')
def step_click_on_image_with_confidence(context, confidence, image_name):
    """Click en imagen con nivel de confianza personalizado (0.0 a 1.0)."""
    _dm(context).click_on_image(_r(context, image_name), confidence=float(confidence))
    _log(context, f"Click con confianza {confidence} en imagen '{image_name}'")


@step('I click with offset "{offset_x}" "{offset_y}" on image "{image_name}"')
@step('hago click con desplazamiento "{offset_x}" "{offset_y}" en la imagen "{image_name}"')
@step('que hago click con desplazamiento "{offset_x}" "{offset_y}" en la imagen "{image_name}"')
def step_click_on_image_with_offset(context, offset_x, offset_y, image_name):
    """Click en imagen con desplazamiento en pixeles desde el centro."""
    _dm(context).click_on_image(
        _r(context, image_name),
        offset_x=int(_r(context, offset_x)),
        offset_y=int(_r(context, offset_y))
    )
    _log(context, f"Click con offset ({offset_x},{offset_y}) en imagen '{image_name}'")


@step('I type at image "{image_name}" the text "{text}"')
@step('escribo en la imagen "{image_name}" el texto "{text}"')
@step('que escribo en la imagen "{image_name}" el texto "{text}"')
def step_click_image_and_type(context, image_name, text):
    """Click en campo por imagen y escribe texto (limpia el campo antes)."""
    _dm(context).click_on_image_and_type(_r(context, image_name), _r(context, text), clear_first=True)
    _log(context, f"Texto '{text}' escrito en imagen '{image_name}'")


@step('I append at image "{image_name}" the text "{text}"')
@step('agrego en la imagen "{image_name}" el texto "{text}"')
@step('que agrego en la imagen "{image_name}" el texto "{text}"')
def step_click_image_and_append(context, image_name, text):
    """Click en campo por imagen y agrega texto sin borrar el contenido existente."""
    _dm(context).click_on_image_and_type(_r(context, image_name), _r(context, text), clear_first=False)
    _log(context, f"Texto '{text}' agregado en imagen '{image_name}'")


@step('I drag image "{source_image}" to image "{target_image}"')
@step('arrastro la imagen "{source_image}" hacia la imagen "{target_image}"')
@step('que arrastro la imagen "{source_image}" hacia la imagen "{target_image}"')
def step_drag_image_to_image(context, source_image, target_image):
    """Arrastra desde imagen origen a imagen destino."""
    _dm(context).drag_image_to_image(_r(context, source_image), _r(context, target_image))
    _log(context, f"Drag imagen '{source_image}' -> imagen '{target_image}'")


@step('I drag image "{source_image}" to coordinates "{x}" "{y}"')
@step('arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"')
@step('que arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"')
def step_drag_image_to_coordinates(context, source_image, x, y):
    """Arrastra desde imagen origen a coordenadas especificas."""
    _dm(context).drag_image_to_coordinates(_r(context, source_image), int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Drag imagen '{source_image}' -> ({x},{y})")


# ===========================================================================
# SECCION 4 - TECLADO Y TEXTO
# ===========================================================================

@step('I type text "{text}"')
@step('escribo el texto "{text}"')
@step('que escribo el texto "{text}"')
def step_type_text(context, text):
    """Escribe texto caracter a caracter en el elemento activo."""
    _dm(context).type_text(_r(context, text))
    _log(context, f"Texto escrito: '{text}'")


@step('I paste text "{text}" using clipboard')
@step('pego el texto "{text}" usando el portapapeles')
@step('que pego el texto "{text}" usando el portapapeles')
def step_type_text_clipboard(context, text):
    """Escribe texto via portapapeles (soporta tildes, enie, caracteres especiales)."""
    _dm(context).type_text_with_clipboard(_r(context, text))
    _log(context, f"Texto pegado: '{text}'")


@step('I clear field and type "{text}"')
@step('limpio el campo y escribo "{text}"')
@step('que limpio el campo y escribo "{text}"')
def step_clear_and_type(context, text):
    """Selecciona todo, borra y escribe texto nuevo en el campo activo."""
    _dm(context).clear_field_and_type(_r(context, text))
    _log(context, f"Campo limpiado y texto escrito: '{text}'")


@step('I press desktop key "{key}"')
@step('presiono en escritorio la tecla "{key}"')
@step('que presiono en escritorio la tecla "{key}"')
def step_press_key(context, key):
    """Presiona una tecla especial en escritorio (enter, tab, escape, f5, delete, etc.)."""
    _dm(context).press_key(_r(context, key))
    _log(context, f"Tecla: {key}")


@step('I press desktop hotkey "{key1}" and "{key2}"')
@step('presiono en escritorio las teclas "{key1}" y "{key2}"')
@step('que presiono en escritorio las teclas "{key1}" y "{key2}"')
def step_press_hotkey_two(context, key1, key2):
    """Presiona combinacion de dos teclas en escritorio (ctrl+c, alt+f4, etc.)."""
    _dm(context).press_hotkey(_r(context, key1), _r(context, key2))
    _log(context, f"Hotkey: {key1}+{key2}")


@step('I press desktop three keys "{key1}" and "{key2}" and "{key3}"')
@step('presiono en escritorio las teclas "{key1}" mas "{key2}" mas "{key3}"')
@step('que presiono en escritorio las teclas "{key1}" mas "{key2}" mas "{key3}"')
def step_press_hotkey_three(context, key1, key2, key3):
    """Presiona combinacion de tres teclas en escritorio (ctrl+shift+s, etc.)."""
    _dm(context).press_hotkey(_r(context, key1), _r(context, key2), _r(context, key3))
    _log(context, f"Hotkey: {key1}+{key2}+{key3}")


@step('I hold desktop key "{key}" down')
@step('mantengo presionada en escritorio la tecla "{key}"')
@step('que mantengo presionada en escritorio la tecla "{key}"')
def step_key_down(context, key):
    """Mantiene presionada una tecla en escritorio."""
    _dm(context).key_down(_r(context, key))
    _log(context, f"Tecla mantenida: {key}")


@step('I release desktop key "{key}"')
@step('suelto en escritorio la tecla "{key}"')
@step('que suelto en escritorio la tecla "{key}"')
def step_key_up(context, key):
    """Suelta una tecla en escritorio."""
    _dm(context).key_up(_r(context, key))
    _log(context, f"Tecla soltada: {key}")


@step('I press desktop Enter key')
@step('presiono Enter en escritorio')
@step('que presiono Enter en escritorio')
def step_press_enter(context):
    _dm(context).press_key('enter')
    _log(context, "Enter")


@step('I press desktop Tab key')
@step('presiono Tab en escritorio')
@step('que presiono Tab en escritorio')
def step_press_tab(context):
    _dm(context).press_key('tab')
    _log(context, "Tab")


@step('I press desktop Escape key')
@step('presiono Escape en escritorio')
@step('que presiono Escape en escritorio')
def step_press_escape(context):
    _dm(context).press_key('escape')
    _log(context, "Escape")


@step('I press copy shortcut')
@step('presiono el atajo de escritorio copiar')
@step('que presiono el atajo de escritorio copiar')
def step_press_copy(context):
    _dm(context).press_hotkey('ctrl', 'c')
    _log(context, "Ctrl+C")


@step('I press paste shortcut')
@step('presiono el atajo de escritorio pegar')
@step('que presiono el atajo de escritorio pegar')
def step_press_paste(context):
    _dm(context).press_hotkey('ctrl', 'v')
    _log(context, "Ctrl+V")


@step('I press select all shortcut')
@step('presiono el atajo de escritorio seleccionar todo')
@step('que presiono el atajo de escritorio seleccionar todo')
def step_press_select_all(context):
    _dm(context).press_hotkey('ctrl', 'a')
    _log(context, "Ctrl+A")


@step('I press save shortcut')
@step('presiono el atajo de escritorio guardar')
@step('que presiono el atajo de escritorio guardar')
def step_press_save(context):
    _dm(context).press_hotkey('ctrl', 's')
    _log(context, "Ctrl+S")


@step('I press undo shortcut')
@step('presiono el atajo de escritorio deshacer')
@step('que presiono el atajo de escritorio deshacer')
def step_press_undo(context):
    _dm(context).press_hotkey('ctrl', 'z')
    _log(context, "Ctrl+Z")


# ===========================================================================
# SECCION 5 - SCROLL
# Regla: variantes con coordenadas/imagen tienen verbo distinto al inicio
# ===========================================================================

@step('I scroll up "{clicks}" times')
@step('hago scroll hacia arriba "{clicks}" veces')
@step('que hago scroll hacia arriba "{clicks}" veces')
def step_scroll_up(context, clicks):
    _dm(context).scroll_up(int(_r(context, clicks)))
    _log(context, f"Scroll arriba {clicks}")


@step('I scroll down "{clicks}" times')
@step('hago scroll hacia abajo "{clicks}" veces')
@step('que hago scroll hacia abajo "{clicks}" veces')
def step_scroll_down(context, clicks):
    _dm(context).scroll_down(int(_r(context, clicks)))
    _log(context, f"Scroll abajo {clicks}")


@step('I scroll up "{clicks}" times at position "{x}" "{y}"')
@step('hago scroll arriba "{clicks}" veces en la posicion "{x}" "{y}"')
@step('que hago scroll arriba "{clicks}" veces en la posicion "{x}" "{y}"')
def step_scroll_up_at_coordinates(context, clicks, x, y):
    _dm(context).scroll_up(int(_r(context, clicks)), x=int(_r(context, x)), y=int(_r(context, y)))
    _log(context, f"Scroll arriba {clicks} en ({x},{y})")


@step('I scroll down "{clicks}" times at position "{x}" "{y}"')
@step('hago scroll abajo "{clicks}" veces en la posicion "{x}" "{y}"')
@step('que hago scroll abajo "{clicks}" veces en la posicion "{x}" "{y}"')
def step_scroll_down_at_coordinates(context, clicks, x, y):
    _dm(context).scroll_down(int(_r(context, clicks)), x=int(_r(context, x)), y=int(_r(context, y)))
    _log(context, f"Scroll abajo {clicks} en ({x},{y})")


@step('I scroll up at image "{image_name}" "{clicks}" times')
@step('hago scroll arriba "{clicks}" veces sobre la imagen "{image_name}"')
@step('que hago scroll arriba "{clicks}" veces sobre la imagen "{image_name}"')
def step_scroll_up_on_image(context, image_name, clicks):
    _dm(context).scroll_on_image(_r(context, image_name), direction='up', clicks=int(_r(context, clicks)))
    _log(context, f"Scroll arriba {clicks} sobre imagen '{image_name}'")


@step('I scroll down at image "{image_name}" "{clicks}" times')
@step('hago scroll abajo "{clicks}" veces sobre la imagen "{image_name}"')
@step('que hago scroll abajo "{clicks}" veces sobre la imagen "{image_name}"')
def step_scroll_down_on_image(context, image_name, clicks):
    _dm(context).scroll_on_image(_r(context, image_name), direction='down', clicks=int(_r(context, clicks)))
    _log(context, f"Scroll abajo {clicks} sobre imagen '{image_name}'")


# ===========================================================================
# SECCION 6 - ESPERAS
# Regla: variantes con timeout usan "con timeout" ANTES del parametro imagen
# ===========================================================================

@step('I wait "{seconds}" seconds on desktop')
@step('espero "{seconds}" segundos en escritorio')
@step('que espero "{seconds}" segundos en escritorio')
def step_wait_seconds_desktop(context, seconds):
    _dm(context).wait_seconds(float(_r(context, seconds)))
    _log(context, f"Espera {seconds}s")


@step('I wait for image "{image_name}" to appear')
@step('espero a que aparezca la imagen "{image_name}"')
@step('que espero a que aparezca la imagen "{image_name}"')
def step_wait_for_image(context, image_name):
    """Espera hasta que una imagen aparezca en pantalla (timeout por defecto)."""
    found = _dm(context).wait_for_image(_r(context, image_name))
    assert found, f"La imagen '{image_name}' no aparecio en pantalla"
    _log(context, f"Imagen '{image_name}' aparecio")


@step('I wait with timeout "{timeout}" seconds for image "{image_name}" to appear')
@step('espero con timeout "{timeout}" segundos a que aparezca la imagen "{image_name}"')
@step('que espero con timeout "{timeout}" segundos a que aparezca la imagen "{image_name}"')
def step_wait_for_image_timeout(context, timeout, image_name):
    """Espera hasta que una imagen aparezca con timeout personalizado."""
    found = _dm(context).wait_for_image(_r(context, image_name), timeout=float(_r(context, timeout)))
    assert found, f"La imagen '{image_name}' no aparecio en {timeout}s"
    _log(context, f"Imagen '{image_name}' aparecio (timeout: {timeout}s)")


@step('I wait for image "{image_name}" to disappear')
@step('espero a que desaparezca la imagen "{image_name}"')
@step('que espero a que desaparezca la imagen "{image_name}"')
def step_wait_for_image_disappear(context, image_name):
    """Espera hasta que una imagen desaparezca de pantalla."""
    gone = _dm(context).wait_for_image_to_disappear(_r(context, image_name))
    assert gone, f"La imagen '{image_name}' no desaparecio"
    _log(context, f"Imagen '{image_name}' desaparecio")


@step('I wait with timeout "{timeout}" seconds for image "{image_name}" to disappear')
@step('espero con timeout "{timeout}" segundos a que desaparezca la imagen "{image_name}"')
@step('que espero con timeout "{timeout}" segundos a que desaparezca la imagen "{image_name}"')
def step_wait_for_image_disappear_timeout(context, timeout, image_name):
    """Espera hasta que una imagen desaparezca con timeout personalizado."""
    gone = _dm(context).wait_for_image_to_disappear(_r(context, image_name), timeout=float(_r(context, timeout)))
    assert gone, f"La imagen '{image_name}' no desaparecio en {timeout}s"
    _log(context, f"Imagen '{image_name}' desaparecio (timeout: {timeout}s)")


# ===========================================================================
# SECCION 7 - VERIFICACIONES VISUALES
# ===========================================================================

@step('I should see image "{image_name}" on screen')
@step('deberia ver la imagen "{image_name}" en pantalla')
@step('que deberia ver la imagen "{image_name}" en pantalla')
def step_should_see_image(context, image_name):
    visible = _dm(context).is_image_visible(_r(context, image_name))
    assert visible, f"La imagen '{image_name}' no esta visible en pantalla"
    _log(context, f"Imagen '{image_name}' visible")


@step('I should not see image "{image_name}" on screen')
@step('no deberia ver la imagen "{image_name}" en pantalla')
@step('que no deberia ver la imagen "{image_name}" en pantalla')
def step_should_not_see_image(context, image_name):
    visible = _dm(context).is_image_visible(_r(context, image_name))
    assert not visible, f"La imagen '{image_name}' esta visible cuando no deberia"
    _log(context, f"Imagen '{image_name}' no visible (correcto)")


@step('I verify with confidence "{confidence}" that image "{image_name}" is visible')
@step('verifico con confianza "{confidence}" que la imagen "{image_name}" es visible')
@step('que verifico con confianza "{confidence}" que la imagen "{image_name}" es visible')
def step_should_see_image_confidence(context, confidence, image_name):
    """Verifica que una imagen este visible con nivel de confianza personalizado."""
    visible = _dm(context).is_image_visible(_r(context, image_name), confidence=float(confidence))
    assert visible, f"La imagen '{image_name}' no visible (confianza: {confidence})"
    _log(context, f"Imagen '{image_name}' visible (confianza: {confidence})")


@step('I store location of image "{image_name}" in variable "{variable_name}"')
@step('guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"')
@step('que guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"')
def step_store_image_location(context, image_name, variable_name):
    location = _dm(context).find_element_by_image(_r(context, image_name))
    assert location is not None, f"Imagen '{image_name}' no encontrada"
    context.variable_manager.set_variable(variable_name, location)
    _log(context, f"Ubicacion de '{image_name}' en '{variable_name}': {location}")


@step('I count occurrences of image "{image_name}" and store in variable "{variable_name}"')
@step('cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"')
@step('que cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"')
def step_count_image_occurrences(context, image_name, variable_name):
    locations = _dm(context).find_all_elements_by_image(_r(context, image_name))
    context.variable_manager.set_variable(variable_name, len(locations))
    _log(context, f"Ocurrencias de '{image_name}': {len(locations)}")


@step('I verify screen size is "{width}" by "{height}"')
@step('verifico que el tamano de pantalla es "{width}" por "{height}"')
@step('que verifico que el tamano de pantalla es "{width}" por "{height}"')
def step_verify_screen_size(context, width, height):
    w, h = _dm(context).get_screen_size()
    assert w == int(width) and h == int(height), f"Pantalla: {w}x{h}, esperado: {width}x{height}"
    _log(context, f"Tamano de pantalla verificado: {width}x{height}")


# ===========================================================================
# SECCION 8 - SCREENSHOTS
# Regla: cada variante tiene verbo distinto al inicio
# ===========================================================================

@step('I take a desktop screenshot')
@step('tomo una captura del escritorio')
@step('que tomo una captura del escritorio')
def step_take_desktop_screenshot(context):
    """Toma screenshot de toda la pantalla y lo registra en el reporte HTML."""
    dm = _dm(context)
    name = getattr(getattr(context, 'scenario', None), 'name', 'desktop')[:40].replace(' ', '_')
    path = dm.take_desktop_screenshot(name)
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    context._last_desktop_screenshot = path
    if path and hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(path, "Captura de escritorio")
    _log(context, f"Screenshot: {path}")


@step('I take a named desktop screenshot "{name}"')
@step('capturo el escritorio con nombre "{name}"')
@step('que capturo el escritorio con nombre "{name}"')
def step_take_desktop_screenshot_named(context, name):
    """Toma screenshot con nombre personalizado y lo registra en el reporte HTML."""
    path = _dm(context).take_desktop_screenshot(_r(context, name))
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    # Registrar para que after_step_html lo incluya en el reporte
    context._last_desktop_screenshot = path
    # Registrar directamente en el reporte si ya paso el after_step
    if path and hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(path, f"Captura: {_r(context, name)}")
    _log(context, f"Screenshot '{name}': {path}")


@step('I take a before screenshot "{action_name}"')
@step('tomo una captura antes de la accion "{action_name}"')
@step('que tomo una captura antes de la accion "{action_name}"')
def step_take_screenshot_before_action(context, action_name):
    """Toma screenshot antes de una accion y lo registra en el reporte HTML."""
    path = _dm(context).take_desktop_screenshot(f"antes_{_r(context, action_name)}")
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    context._last_desktop_screenshot = path
    if path and hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(path, f"Antes de: {_r(context, action_name)}")
    _log(context, f"Screenshot previo a '{action_name}'")


@step('I take an after screenshot "{action_name}"')
@step('tomo una captura despues de la accion "{action_name}"')
@step('que tomo una captura despues de la accion "{action_name}"')
def step_take_screenshot_after_action(context, action_name):
    """Toma screenshot despues de una accion y lo registra en el reporte HTML."""
    path = _dm(context).take_desktop_screenshot(f"despues_{_r(context, action_name)}")
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    context._last_desktop_screenshot = path
    if path and hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(path, f"Despues de: {_r(context, action_name)}")
    _log(context, f"Screenshot posterior a '{action_name}'")


@step('I take a region screenshot "{x}" "{y}" "{width}" "{height}" named "{name}"')
@step('tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"')
@step('que tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"')
def step_take_region_screenshot(context, x, y, width, height, name):
    """Toma screenshot de una region especifica de la pantalla."""
    path = _dm(context).take_region_screenshot(
        int(_r(context, x)), int(_r(context, y)),
        int(_r(context, width)), int(_r(context, height)),
        _r(context, name)
    )
    if not hasattr(context, 'desktop_screenshots'): context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot region: {path}")


# ===========================================================================
# SECCION 9 - PORTAPAPELES
# ===========================================================================

@step('I copy text "{text}" to clipboard')
@step('copio el texto "{text}" al portapapeles')
@step('que copio el texto "{text}" al portapapeles')
def step_copy_to_clipboard(context, text):
    _dm(context).copy_to_clipboard(_r(context, text))
    _log(context, f"Copiado al portapapeles: '{text}'")


@step('I get clipboard content and store in variable "{variable_name}"')
@step('obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"')
@step('que obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"')
def step_get_clipboard(context, variable_name):
    content = _dm(context).get_clipboard_content()
    context.variable_manager.set_variable(variable_name, content)
    _log(context, f"Portapapeles en '{variable_name}': '{content[:50]}'")


@step('I copy selected text and store in variable "{variable_name}"')
@step('copio el texto seleccionado y lo guardo en la variable "{variable_name}"')
@step('que copio el texto seleccionado y lo guardo en la variable "{variable_name}"')
def step_copy_selected_text(context, variable_name):
    content = _dm(context).copy_selected_text()
    context.variable_manager.set_variable(variable_name, content)
    _log(context, f"Texto seleccionado en '{variable_name}': '{content[:50]}'")


@step('I should see clipboard contains "{expected_text}"')
@step('deberia ver que el portapapeles contiene "{expected_text}"')
@step('que deberia ver que el portapapeles contiene "{expected_text}"')
def step_verify_clipboard_contains(context, expected_text):
    content = _dm(context).get_clipboard_content()
    resolved = _r(context, expected_text)
    assert resolved.lower() in content.lower(), f"Portapapeles no contiene '{resolved}'. Actual: '{content}'"
    _log(context, f"Portapapeles contiene '{expected_text}'")


# ===========================================================================
# SECCION 10 - MODO MIXTO (WEB + ESCRITORIO)
# ===========================================================================

@step('I switch to desktop mode')
@step('uso el modo desktop')
@step('que uso el modo desktop')
def step_switch_to_desktop_mode(context):
    """Activa modo escritorio guardando el estado del navegador web.
    Las capturas del reporte usaran PyAutoGUI en lugar de Playwright."""
    _dm(context).switch_to_desktop_mode(context)
    context.report_mode = 'desktop'
    _log(context, "Modo desktop activado")


@step('I switch to web mode')
@step('uso el modo web')
@step('que uso el modo web')
def step_switch_to_web_mode(context):
    """Vuelve al modo web restaurando la pagina del navegador.
    Las capturas del reporte vuelven a usar Playwright."""
    _dm(context).switch_to_web_mode(context)
    context.report_mode = 'web'
    _log(context, "Modo web restaurado")


@step('I switch to api mode')
@step('uso el modo api')
@step('que uso el modo api')
def step_switch_to_api_mode(context):
    """Activa modo API: el reporte mostrara request/response en lugar de screenshots.
    Los steps de API guardaran automaticamente sus datos en el reporte."""
    context.report_mode = 'api'
    context.api_mode_active = True
    _log(context, "Modo API activado - el reporte mostrara request/response")


@step('I switch to desktop app "{app_path}" from web test')
@step('cambio a la aplicacion de escritorio "{app_path}" desde la prueba web')
@step('que cambio a la aplicacion de escritorio "{app_path}" desde la prueba web')
def step_switch_to_desktop_app_from_web(context, app_path):
    """Lanza app de escritorio y activa modo escritorio sin cerrar el navegador."""
    dm = _dm(context)
    dm.switch_to_desktop_mode(context)
    context.report_mode = 'desktop'
    dm.launch_application(_r(context, app_path), wait_seconds=2.0)
    _log(context, f"Cambiado a app de escritorio: {app_path}")


@step('I return to web browser after desktop interaction')
@step('vuelvo al navegador web despues de la interaccion con escritorio')
@step('que vuelvo al navegador web despues de la interaccion con escritorio')
def step_return_to_web_browser(context):
    """Vuelve al navegador web y lo trae al frente."""
    _dm(context).switch_to_web_mode(context)
    for title in ['Chrome', 'Firefox', 'Edge', 'Chromium']:
        if _dm(context).bring_window_to_front(title):
            break
    _log(context, "Regresado al navegador web")


@step('I take desktop screenshot and return to web named "{name}"')
@step('capturo el escritorio y vuelvo al navegador con nombre "{name}"')
@step('que capturo el escritorio y vuelvo al navegador con nombre "{name}"')
def step_screenshot_and_continue_web(context, name):
    """Toma screenshot del escritorio y devuelve el foco al navegador."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot(_r(context, name))
    if not hasattr(context, 'desktop_screenshots'): context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    for title in ['Chrome', 'Firefox', 'Edge', 'Chromium']:
        if dm.bring_window_to_front(title):
            break
    _log(context, f"Screenshot tomado y foco al navegador: {path}")


# ===========================================================================
# SECCION 11 - OCR EN ESCRITORIO
# ===========================================================================

@step('I take desktop screenshot and extract text into variable "{variable_name}"')
@step('capturo el escritorio y extraigo texto en la variable "{variable_name}"')
@step('que capturo el escritorio y extraigo texto en la variable "{variable_name}"')
def step_desktop_screenshot_ocr_to_variable(context, variable_name):
    """Toma screenshot del escritorio, aplica OCR y guarda el texto en variable."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_desktop")
    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    text = OCRManagerSimple().get_all_text(path)
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"OCR de escritorio en '{variable_name}'")


@step('I should see text "{expected_text}" on desktop using OCR')
@step('deberia ver el texto "{expected_text}" en el escritorio usando OCR')
@step('que deberia ver el texto "{expected_text}" en el escritorio usando OCR')
def step_should_see_text_on_desktop_ocr(context, expected_text):
    """Toma screenshot del escritorio y verifica texto via OCR."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_verify")
    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    text = OCRManagerSimple().get_all_text(path)
    resolved = _r(context, expected_text)
    assert resolved.lower() in text.lower(), f"Texto '{resolved}' no encontrado via OCR. Detectado: '{text[:200]}'"
    _log(context, f"Texto '{expected_text}' verificado via OCR")


@step('I should not see text "{unexpected_text}" on desktop using OCR')
@step('no deberia ver el texto "{unexpected_text}" en el escritorio usando OCR')
@step('que no deberia ver el texto "{unexpected_text}" en el escritorio usando OCR')
def step_should_not_see_text_on_desktop_ocr(context, unexpected_text):
    """Toma screenshot del escritorio y verifica que el texto NO este presente via OCR."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_verify_not")
    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    text = OCRManagerSimple().get_all_text(path)
    resolved = _r(context, unexpected_text)
    assert resolved.lower() not in text.lower(), f"Texto '{resolved}' encontrado cuando no deberia"
    _log(context, f"Texto '{unexpected_text}' correctamente ausente")


@step('I take region "{x}" "{y}" "{width}" "{height}" screenshot and extract text into variable "{variable_name}"')
@step('capturo la region "{x}" "{y}" "{width}" "{height}" y extraigo texto en la variable "{variable_name}"')
@step('que capturo la region "{x}" "{y}" "{width}" "{height}" y extraigo texto en la variable "{variable_name}"')
def step_region_screenshot_ocr(context, x, y, width, height, variable_name):
    """Toma screenshot de una region especifica y aplica OCR."""
    dm = _dm(context)
    path = dm.take_region_screenshot(
        int(_r(context, x)), int(_r(context, y)),
        int(_r(context, width)), int(_r(context, height)),
        "ocr_region"
    )
    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    text = OCRManagerSimple().get_all_text(path)
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"OCR de region en '{variable_name}': '{text[:80]}'")


# ===========================================================================
# SECCION 12 - CONFIGURACION Y UTILIDADES
# ===========================================================================

@step('I store mouse position in variable "{variable_name}"')
@step('guardo la posicion del mouse en la variable "{variable_name}"')
@step('que guardo la posicion del mouse en la variable "{variable_name}"')
def step_store_mouse_position(context, variable_name):
    pos = _dm(context).get_mouse_position()
    context.variable_manager.set_variable(variable_name, pos)
    _log(context, f"Posicion del mouse en '{variable_name}': {pos}")


@step('I store screen size in variable "{variable_name}"')
@step('guardo el tamano de pantalla en la variable "{variable_name}"')
@step('que guardo el tamano de pantalla en la variable "{variable_name}"')
def step_store_screen_size(context, variable_name):
    size = _dm(context).get_screen_size()
    context.variable_manager.set_variable(variable_name, size)
    _log(context, f"Tamano de pantalla en '{variable_name}': {size}")


@step('I set desktop action pause to "{seconds}" seconds')
@step('establezco la pausa entre acciones en "{seconds}" segundos')
@step('que establezco la pausa entre acciones en "{seconds}" segundos')
def step_set_action_pause(context, seconds):
    import pyautogui
    pyautogui.PAUSE = float(_r(context, seconds))
    _log(context, f"Pausa entre acciones: {seconds}s")


@step('I set image search confidence to "{confidence}"')
@step('establezco la confianza de busqueda de imagenes en "{confidence}"')
@step('que establezco la confianza de busqueda de imagenes en "{confidence}"')
def step_set_image_confidence(context, confidence):
    _dm(context).search_confidence = float(_r(context, confidence))
    _log(context, f"Confianza de busqueda: {confidence}")


@step('I set image search timeout to "{seconds}" seconds')
@step('establezco el timeout de busqueda de imagenes en "{seconds}" segundos')
@step('que establezco el timeout de busqueda de imagenes en "{seconds}" segundos')
def step_set_image_timeout(context, seconds):
    _dm(context).search_timeout = float(_r(context, seconds))
    _log(context, f"Timeout de busqueda: {seconds}s")

# ===========================================================================
# SECCION 13 - LECTURA Y EXTRACCION DE TEXTO
#
# Tres enfoques distintos, sin ambiguedad entre ellos:
#   A) OCR pantalla completa  → "leo el texto de la pantalla..."
#   B) OCR por region         → "leo el texto de la region..."
#   C) Portapapeles           → "copio y leo el texto..."
#   D) Seleccionar todo       → "selecciono todo y leo el texto..."
# ===========================================================================

# --- A) OCR PANTALLA COMPLETA ---

@step('I read screen text and store in variable "{variable_name}"')
@step('leo el texto de la pantalla y lo guardo en la variable "{variable_name}"')
@step('que leo el texto de la pantalla y lo guardo en la variable "{variable_name}"')
def step_read_screen_text_ocr(context, variable_name):
    """
    Toma screenshot de toda la pantalla, aplica OCR y guarda el texto en una variable.
    Util para leer cualquier texto visible sin necesidad de seleccionarlo.
    """
    text = _dm(context).read_text_from_screen_ocr()
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"Texto de pantalla guardado en '{variable_name}': '{text[:80]}'")


@step('I read screen text with min confidence "{confidence}" and store in variable "{variable_name}"')
@step('leo el texto de la pantalla con confianza minima "{confidence}" y lo guardo en la variable "{variable_name}"')
@step('que leo el texto de la pantalla con confianza minima "{confidence}" y lo guardo en la variable "{variable_name}"')
def step_read_screen_text_ocr_confidence(context, confidence, variable_name):
    """
    OCR de pantalla completa con nivel de confianza minimo personalizado.
    Valores mas altos (ej: 80) filtran texto poco legible.
    """
    text = _dm(context).read_text_from_screen_ocr(min_confidence=float(_r(context, confidence)))
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"Texto (confianza>={confidence}) guardado en '{variable_name}': '{text[:80]}'")


# --- B) OCR POR REGION ---

@step('I read text from region "{x}" "{y}" "{width}" "{height}" and store in variable "{variable_name}"')
@step('leo el texto de la region "{x}" "{y}" "{width}" "{height}" y lo guardo en la variable "{variable_name}"')
@step('que leo el texto de la region "{x}" "{y}" "{width}" "{height}" y lo guardo en la variable "{variable_name}"')
def step_read_region_text_ocr(context, x, y, width, height, variable_name):
    """
    Toma screenshot de una region especifica (x, y, ancho, alto en pixeles),
    aplica OCR y guarda el texto. Ideal para leer un campo concreto de la app.
    """
    text = _dm(context).read_text_from_region_ocr(
        int(_r(context, x)), int(_r(context, y)),
        int(_r(context, width)), int(_r(context, height))
    )
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"Texto de region ({x},{y},{width},{height}) en '{variable_name}': '{text[:80]}'")


# --- C) PORTAPAPELES (seleccion manual previa) ---

@step('I copy and read selected text and store in variable "{variable_name}"')
@step('copio y leo el texto seleccionado y lo guardo en la variable "{variable_name}"')
@step('que copio y leo el texto seleccionado y lo guardo en la variable "{variable_name}"')
def step_copy_and_read_selected(context, variable_name):
    """
    Copia el texto actualmente seleccionado en pantalla (Ctrl+C) y lo guarda.
    Requiere que el texto ya este seleccionado antes de ejecutar este step.
    """
    text = _dm(context).copy_selected_text()
    context.variable_manager.set_variable(variable_name, text)
    _log(context, f"Texto seleccionado guardado en '{variable_name}': '{text[:80]}'")


@step('I click image "{image_name}" copy and read text and store in variable "{variable_name}"')
@step('leo el campo imagen "{image_name}" y guardo el texto en la variable "{variable_name}"')
@step('que leo el campo imagen "{image_name}" y guardo el texto en la variable "{variable_name}"')
def step_click_copy_read(context, image_name, variable_name):
    """
    Click en un elemento por imagen, selecciona todo su contenido (Ctrl+A),
    lo copia (Ctrl+C) y guarda el texto en una variable.
    Util para leer el contenido de un campo de texto.
    """
    dm = _dm(context)
    dm.click_on_image(_r(context, image_name))
    time.sleep(0.2)
    text = dm.select_all_and_copy()
    context.variable_manager.set_variable(variable_name, text)
    _log(context, f"Texto del campo '{image_name}' guardado en '{variable_name}': '{text[:80]}'")


@step('I click coordinates "{x}" "{y}" copy and read text and store in variable "{variable_name}"')
@step('leo el campo en las coordenadas "{x}" "{y}" y guardo el texto en la variable "{variable_name}"')
@step('que leo el campo en las coordenadas "{x}" "{y}" y guardo el texto en la variable "{variable_name}"')
def step_click_coords_copy_read(context, x, y, variable_name):
    """
    Click en coordenadas, selecciona todo el contenido del campo (Ctrl+A),
    lo copia (Ctrl+C) y guarda el texto en una variable.
    """
    dm = _dm(context)
    dm.click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    time.sleep(0.2)
    text = dm.select_all_and_copy()
    context.variable_manager.set_variable(variable_name, text)
    _log(context, f"Texto en ({x},{y}) guardado en '{variable_name}': '{text[:80]}'")


# --- D) SELECCIONAR TODO Y LEER ---

@step('I select all and read active field text and store in variable "{variable_name}"')
@step('selecciono todo y leo el texto del campo activo y lo guardo en la variable "{variable_name}"')
@step('que selecciono todo y leo el texto del campo activo y lo guardo en la variable "{variable_name}"')
def step_select_all_read(context, variable_name):
    """
    En el campo que tiene el foco actualmente: selecciona todo (Ctrl+A),
    copia (Ctrl+C) y guarda el texto. No requiere click previo.
    """
    text = _dm(context).select_all_and_copy()
    context.variable_manager.set_variable(variable_name, text)
    _log(context, f"Texto del campo activo guardado en '{variable_name}': '{text[:80]}'")


# --- VERIFICACIONES DE TEXTO LEIDO ---

@step('I should see variable "{variable_name}" contains "{expected_text}"')
@step('el texto leido en la variable "{variable_name}" deberia contener "{expected_text}"')
@step('que el texto leido en la variable "{variable_name}" deberia contener "{expected_text}"')
def step_verify_read_text_contains(context, variable_name, expected_text):
    """
    Verifica que el texto guardado en una variable contiene el texto esperado.
    Complemento natural de los steps de lectura anteriores.
    """
    value = str(context.variable_manager.get_variable(variable_name))
    resolved = _r(context, expected_text)
    assert resolved.lower() in value.lower(), (
        f"El texto leido en '{variable_name}' no contiene '{resolved}'.\n"
        f"Valor actual: '{value}'"
    )
    _log(context, f"Variable '{variable_name}' contiene '{expected_text}' ✓")


@step('I should see variable "{variable_name}" equals "{expected_text}"')
@step('el texto leido en la variable "{variable_name}" deberia ser exactamente "{expected_text}"')
@step('que el texto leido en la variable "{variable_name}" deberia ser exactamente "{expected_text}"')
def step_verify_read_text_equals(context, variable_name, expected_text):
    """
    Verifica que el texto guardado en una variable es exactamente igual al esperado.
    """
    value = str(context.variable_manager.get_variable(variable_name)).strip()
    resolved = _r(context, expected_text).strip()
    assert value == resolved, (
        f"El texto leido en '{variable_name}' no es '{resolved}'.\n"
        f"Valor actual: '{value}'"
    )
    _log(context, f"Variable '{variable_name}' es exactamente '{expected_text}' ✓")
