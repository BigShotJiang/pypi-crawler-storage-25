#!/usr/bin/env python3
"""
Steps para automatización mobile con Appium.
Soporta Android e iOS, apps nativas, híbridas y web mobile.
Requiere: pip install Appium-Python-Client

Categorías de pasos:
  1. Conexión y Sesión (10 pasos)
  2. Taps y Clicks (15 pasos)
  3. Entrada de Texto y Teclado (14 pasos)
  4. Scroll y Swipe (18 pasos)
  5. Navegación del Dispositivo (10 pasos)
  6. Verificación de Elementos (20 pasos)
  7. Obtención de Datos y Variables (12 pasos)
  8. Alertas y Diálogos (8 pasos)
  9. Esperas (10 pasos)
  10. Screenshots y Reportes (6 pasos)
  11. Ejecución de Scripts y Comandos (5 pasos)
  12. Contextos y Modo Mixto (6 pasos)
"""
import json
from behave import step


# ============================================================================
# FUNCIONES HELPER
# ============================================================================

def _am(context):
    """Obtiene o crea el AppiumManager en el contexto."""
    if not hasattr(context, 'appium_manager') or context.appium_manager is None:
        from hakalab_framework.core.appium_manager import AppiumManager
        context.appium_manager = AppiumManager()
    context._current_step_is_mobile = True
    return context.appium_manager


def _r(context, value):
    """Resuelve variables del framework."""
    if hasattr(context, 'variable_manager'):
        return context.variable_manager.resolve_variables(str(value))
    return str(value)


def _log(context, msg):
    if hasattr(context, 'logger'):
        context.logger.info(msg)
    else:
        print(msg)


def _screenshot_to_report(context, path, description=''):
    """Registra un screenshot en el reporte HTML."""
    if path and hasattr(context, 'html_reporter'):
        context.html_reporter.add_screenshot(path, description)
    context._last_mobile_screenshot = path


# ============================================================================
# 1. CONEXIÓN Y SESIÓN
# ============================================================================

@step('uso el modo mobile')
def step_use_mobile_mode(context):
    """
    Paso principal para iniciar pruebas mobile.
    Lee toda la configuración del .env (APPIUM_*), conecta al dispositivo,
    verifica si la app está instalada (si no, la instala), y aplica la
    estrategia de reset configurada.
    """
    am = _am(context)
    am.setup_from_env()
    _log(context, "✓ Modo mobile activo")


@step('desconecto del dispositivo móvil')
def step_disconnect(context):
    """Cierra la sesión Appium."""
    am = _am(context)
    am.disconnect()
    _log(context, "✓ Desconectado del dispositivo")


@step('reinicio la aplicación móvil')
def step_reset_app(context):
    """Reinicia la app sin cerrar la sesión."""
    am = _am(context)
    am.reset_app()
    _log(context, "✓ Aplicación reiniciada")


@step('lanzo la aplicación móvil')
def step_launch_app(context):
    """Lanza la app configurada en las capacidades."""
    am = _am(context)
    am.launch_app()
    _log(context, "✓ Aplicación lanzada")


@step('cierro la aplicación móvil')
def step_close_app(context):
    """Cierra la app sin cerrar la sesión."""
    am = _am(context)
    am.close_app()
    _log(context, "✓ Aplicación cerrada")


@step('instalo la aplicación desde la ruta "{app_path}"')
def step_install_app(context, app_path):
    """Instala una app en el dispositivo."""
    resolved = _r(context, app_path)
    am = _am(context)
    am.install_app(resolved)
    _log(context, f"✓ Aplicación instalada desde {resolved}")


@step('desinstalo la aplicación móvil')
def step_remove_app(context):
    """Desinstala la app actual del dispositivo."""
    am = _am(context)
    am.remove_app()
    _log(context, "✓ Aplicación desinstalada")


@step('activo la aplicación móvil en primer plano')
def step_activate_app(context):
    """Trae al frente la app actual."""
    am = _am(context)
    am.activate_app()
    _log(context, "✓ Aplicación activada")


@step('termino la aplicación móvil en segundo plano')
def step_terminate_app(context):
    """Termina la app actual en segundo plano."""
    am = _am(context)
    am.terminate_app()
    _log(context, "✓ Aplicación terminada")


# ============================================================================
# 2. TAPS Y CLICKS (15 pasos)
# ============================================================================

@step('hago tap simple en el elemento móvil "{locator}"')
def step_tap_element(context, locator):
    """Tap en un elemento."""
    resolved = _r(context, locator)
    am = _am(context)
    am.tap(resolved)
    _log(context, f"✓ Tap en: {resolved}")


@step('hago doble tap en el elemento móvil "{locator}"')
def step_double_tap(context, locator):
    """Doble tap en un elemento."""
    resolved = _r(context, locator)
    am = _am(context)
    am.double_tap(resolved)
    _log(context, f"✓ Doble tap en: {resolved}")


@step('hago tap largo simple en el elemento móvil "{locator}"')
def step_long_press(context, locator):
    """Long press con duración por defecto (1s)."""
    resolved = _r(context, locator)
    am = _am(context)
    am.long_press(resolved)
    _log(context, f"✓ Tap largo en: {resolved}")


@step('hago tap largo en el elemento móvil "{locator}" por "{ms}" milisegundos')
def step_long_press_duration(context, locator, ms):
    """Long press con duración específica."""
    resolved = _r(context, locator)
    duration = int(_r(context, ms))
    am = _am(context)
    am.long_press(resolved, duration)
    _log(context, f"✓ Tap largo en {resolved} durante {duration}ms")


@step('hago tap en las coordenadas móvil "{x}" y "{y}"')
def step_tap_coordinates(context, x, y):
    """Tap en coordenadas absolutas de pantalla."""
    rx, ry = int(_r(context, x)), int(_r(context, y))
    am = _am(context)
    am.tap_at_coordinates(rx, ry)
    _log(context, f"✓ Tap en coordenadas ({rx}, {ry})")


@step('hago tap en el texto móvil "{text}"')
def step_tap_by_text(context, text):
    """Tap en el primer elemento que contiene el texto exacto."""
    resolved = _r(context, text)
    am = _am(context)
    am.tap_by_text(resolved)
    _log(context, f"✓ Tap en texto: {resolved}")


@step('hago tap en el accessibility id "{acc_id}"')
def step_tap_accessibility_id(context, acc_id):
    """Tap usando el accessibility ID del elemento."""
    resolved = _r(context, acc_id)
    am = _am(context)
    am.tap_by_accessibility_id(resolved)
    _log(context, f"✓ Tap en accessibility ID: {resolved}")


@step('hago tap en el elemento móvil "{locator}" con timeout de "{seconds}" segundos')
def step_tap_with_timeout(context, locator, seconds):
    """Tap con timeout personalizado."""
    resolved = _r(context, locator)
    timeout = float(_r(context, seconds))
    am = _am(context)
    am.tap(resolved, timeout)
    _log(context, f"✓ Tap en {resolved} (timeout {timeout}s)")


@step('hago tap en el primer elemento de la lista "{locator}"')
def step_tap_first_in_list(context, locator):
    """Tap en el primer elemento de una lista de coincidencias."""
    resolved = _r(context, locator)
    am = _am(context)
    elements = am._find_elements(resolved)
    assert len(elements) > 0, f"No se encontraron elementos: {resolved}"
    elements[0].click()
    _log(context, f"✓ Tap en primer elemento de: {resolved}")


@step('hago tap en el último elemento de la lista "{locator}"')
def step_tap_last_in_list(context, locator):
    """Tap en el último elemento de una lista de coincidencias."""
    resolved = _r(context, locator)
    am = _am(context)
    elements = am._find_elements(resolved)
    assert len(elements) > 0, f"No se encontraron elementos: {resolved}"
    elements[-1].click()
    _log(context, f"✓ Tap en último elemento de: {resolved}")


@step('hago tap en el elemento número "{index}" de la lista "{locator}"')
def step_tap_by_index(context, index, locator):
    """Tap en un elemento por su índice (base 0)."""
    resolved = _r(context, locator)
    idx = int(_r(context, index))
    am = _am(context)
    elements = am._find_elements(resolved)
    assert idx < len(elements), f"Índice {idx} fuera de rango ({len(elements)} elementos)"
    elements[idx].click()
    _log(context, f"✓ Tap en elemento #{idx} de: {resolved}")


@step('hago tap en el elemento móvil "{locator}" tras hacer scroll')
def step_tap_after_scroll(context, locator):
    """Scroll hasta encontrar el elemento y luego tap."""
    resolved = _r(context, locator)
    am = _am(context)
    am.scroll_to_element(resolved)
    am.tap(resolved)
    _log(context, f"✓ Scroll + tap en: {resolved}")


@step('hago tap múltiple "{times}" veces en el elemento móvil "{locator}"')
def step_tap_multiple(context, times, locator):
    """Múltiples taps consecutivos en un elemento."""
    resolved = _r(context, locator)
    n = int(_r(context, times))
    am = _am(context)
    for _ in range(n):
        am.tap(resolved)
        am.wait_seconds(0.15)
    _log(context, f"✓ {n} taps en: {resolved}")


@step('hago tap en el elemento móvil "{locator}" esperando "{seconds}" segundos')
def step_tap_and_wait(context, locator, seconds):
    """Tap en un elemento y espera un tiempo."""
    resolved = _r(context, locator)
    secs = float(_r(context, seconds))
    am = _am(context)
    am.tap(resolved)
    am.wait_seconds(secs)
    _log(context, f"✓ Tap en {resolved} y espera {secs}s")


@step('hago tap en el elemento móvil "{locator}" solo si existe')
def step_tap_if_exists(context, locator):
    """Tap en un elemento solo si existe, sin fallar si no está."""
    resolved = _r(context, locator)
    am = _am(context)
    if am.is_element_present(resolved):
        am.tap(resolved)
        _log(context, f"✓ Tap en elemento existente: {resolved}")
    else:
        _log(context, f"⚠ Elemento no encontrado, se omite tap: {resolved}")


# ============================================================================
# 3. ENTRADA DE TEXTO Y TECLADO (14 pasos)
# ============================================================================

@step('escribo texto "{text}" en el campo móvil "{locator}"')
def step_type_text(context, text, locator):
    """Escribe texto en un campo (limpia primero)."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.type_text(resolved_loc, resolved_text)
    _log(context, f"✓ Texto escrito en {resolved_loc}")


@step('escribo "{text}" en el campo móvil "{locator}" manteniendo contenido')
def step_type_text_no_clear(context, text, locator):
    """Escribe texto sin limpiar el campo primero."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.type_text(resolved_loc, resolved_text, clear_first=False)
    _log(context, f"✓ Texto agregado en {resolved_loc}")


@step('limpio el campo móvil "{locator}"')
def step_clear_field(context, locator):
    """Limpia el contenido de un campo."""
    resolved = _r(context, locator)
    am = _am(context)
    am.clear_field(resolved)
    _log(context, f"✓ Campo limpiado: {resolved}")


@step('agrego texto "{text}" al campo móvil "{locator}"')
def step_append_text(context, text, locator):
    """Agrega texto al final sin borrar el existente."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.append_text(resolved_loc, resolved_text)
    _log(context, f"✓ Texto agregado a {resolved_loc}")


@step('limpio y escribo "{text}" en el campo móvil "{locator}"')
def step_clear_and_type(context, text, locator):
    """Limpia explícitamente y luego escribe."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.clear_field(resolved_loc)
    am.type_text(resolved_loc, resolved_text, clear_first=False)
    _log(context, f"✓ Campo limpiado y texto escrito en {resolved_loc}")


@step('escribo "{text}" en el campo móvil "{locator}" ocultando teclado')
def step_type_and_hide_keyboard(context, text, locator):
    """Escribe texto y oculta el teclado."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.type_text(resolved_loc, resolved_text)
    am.hide_keyboard()
    _log(context, f"✓ Texto escrito y teclado ocultado")


@step('escribo "{text}" en el campo móvil "{locator}" presionando enter')
def step_type_and_press_enter(context, text, locator):
    """Escribe texto y presiona la tecla Enter."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.type_text(resolved_loc, resolved_text)
    am.press_key(66)  # KEYCODE_ENTER
    _log(context, f"✓ Texto escrito y Enter presionado")


@step('escribo "{text}" en el campo móvil "{locator}" presionando buscar')
def step_type_and_press_search(context, text, locator):
    """Escribe texto y presiona la tecla Search."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.type_text(resolved_loc, resolved_text)
    am.press_key(84)  # KEYCODE_SEARCH
    _log(context, f"✓ Texto escrito y Search presionado")


@step('escribo "{text}" en el campo móvil "{locator}" letra por letra')
def step_type_char_by_char(context, text, locator):
    """Escribe texto carácter por carácter (útil para campos con autocompletado)."""
    resolved_text = _r(context, text)
    resolved_loc = _r(context, locator)
    am = _am(context)
    am.clear_field(resolved_loc)
    for char in resolved_text:
        am.append_text(resolved_loc, char)
        am.wait_seconds(0.05)
    _log(context, f"✓ Texto escrito carácter por carácter en {resolved_loc}")


@step('oculto el teclado del dispositivo')
def step_hide_keyboard(context):
    """Oculta el teclado virtual."""
    am = _am(context)
    am.hide_keyboard()
    _log(context, "✓ Teclado ocultado")


@step('presiono la tecla con código "{key_code}" en el dispositivo')
def step_press_keycode(context, key_code):
    """Presiona una tecla por su código Android KeyEvent."""
    code = int(_r(context, key_code))
    am = _am(context)
    am.press_key(code)
    _log(context, f"✓ Tecla presionada: código {code}")


@step('presiono la tecla Enter en el dispositivo')
def step_press_enter(context):
    """Presiona la tecla Enter."""
    am = _am(context)
    am.press_key(66)
    _log(context, "✓ Tecla Enter presionada")


@step('presiono la tecla Back en el dispositivo')
def step_press_back_key(context):
    """Presiona la tecla Back del dispositivo."""
    am = _am(context)
    am.press_key(4)  # KEYCODE_BACK
    _log(context, "✓ Tecla Back presionada")


@step('presiono la tecla Tab en el dispositivo')
def step_press_tab(context):
    """Presiona la tecla Tab."""
    am = _am(context)
    am.press_key(61)  # KEYCODE_TAB
    _log(context, "✓ Tecla Tab presionada")


# ============================================================================
# 4. SCROLL Y SWIPE (18 pasos)
# ============================================================================

@step('hago scroll hacia abajo en el dispositivo')
def step_scroll_down(context):
    """Scroll hacia abajo una vez."""
    am = _am(context)
    am.scroll_down()
    _log(context, "✓ Scroll hacia abajo")


@step('hago scroll abajo en el dispositivo "{n}" veces')
def step_scroll_down_n(context, n):
    """Scroll hacia abajo N veces."""
    times = int(_r(context, n))
    am = _am(context)
    am.scroll_down(times)
    _log(context, f"✓ Scroll hacia abajo x{times}")


@step('hago scroll hacia arriba en el dispositivo')
def step_scroll_up(context):
    """Scroll hacia arriba una vez."""
    am = _am(context)
    am.scroll_up()
    _log(context, "✓ Scroll hacia arriba")


@step('hago scroll arriba en el dispositivo "{n}" veces')
def step_scroll_up_n(context, n):
    """Scroll hacia arriba N veces."""
    times = int(_r(context, n))
    am = _am(context)
    am.scroll_up(times)
    _log(context, f"✓ Scroll hacia arriba x{times}")


@step('hago scroll hacia la izquierda en el dispositivo')
def step_scroll_left(context):
    """Scroll hacia la izquierda una vez."""
    am = _am(context)
    am.scroll_left()
    _log(context, "✓ Scroll hacia la izquierda")


@step('hago scroll izquierda en el dispositivo "{n}" veces')
def step_scroll_left_n(context, n):
    """Scroll hacia la izquierda N veces."""
    times = int(_r(context, n))
    am = _am(context)
    am.scroll_left(times)
    _log(context, f"✓ Scroll hacia la izquierda x{times}")


@step('hago scroll hacia la derecha en el dispositivo')
def step_scroll_right(context):
    """Scroll hacia la derecha una vez."""
    am = _am(context)
    am.scroll_right()
    _log(context, "✓ Scroll hacia la derecha")


@step('hago scroll derecha en el dispositivo "{n}" veces')
def step_scroll_right_n(context, n):
    """Scroll hacia la derecha N veces."""
    times = int(_r(context, n))
    am = _am(context)
    am.scroll_right(times)
    _log(context, f"✓ Scroll hacia la derecha x{times}")


@step('hago scroll hasta el elemento móvil "{locator}"')
def step_scroll_to_element(context, locator):
    """Scroll hasta que el elemento sea visible."""
    resolved = _r(context, locator)
    am = _am(context)
    am.scroll_to_element(resolved)
    _log(context, f"✓ Scroll hasta elemento: {resolved}")


@step('hago scroll hasta encontrar el elemento móvil "{locator}" limitando a "{max_sw}" intentos')
def step_scroll_to_element_max(context, locator, max_sw):
    """Scroll hasta el elemento con límite de intentos."""
    resolved = _r(context, locator)
    mx = int(_r(context, max_sw))
    am = _am(context)
    am.scroll_to_element(resolved, mx)
    _log(context, f"✓ Scroll hasta elemento (máx {mx}): {resolved}")


@step('hago scroll hasta encontrar el texto móvil "{text}"')
def step_scroll_to_text(context, text):
    """Scroll hasta que un texto sea visible."""
    resolved = _r(context, text)
    am = _am(context)
    am.scroll_to_text(resolved)
    _log(context, f"✓ Scroll hasta texto: {resolved}")


@step('hago swipe del elemento móvil "{locator}" hacia la izquierda')
def step_swipe_element_left(context, locator):
    """Swipe izquierda sobre un elemento (ej: para eliminar)."""
    resolved = _r(context, locator)
    am = _am(context)
    am.swipe_element_left(resolved)
    _log(context, f"✓ Swipe izquierda en: {resolved}")


@step('hago swipe del elemento móvil "{locator}" hacia la derecha')
def step_swipe_element_right(context, locator):
    """Swipe derecha sobre un elemento."""
    resolved = _r(context, locator)
    am = _am(context)
    am.swipe_element_right(resolved)
    _log(context, f"✓ Swipe derecha en: {resolved}")


@step('hago swipe desde "{x1}" "{y1}" hasta "{x2}" "{y2}" en el dispositivo')
def step_swipe_coordinates(context, x1, y1, x2, y2):
    """Swipe entre dos coordenadas absolutas."""
    sx, sy = int(_r(context, x1)), int(_r(context, y1))
    ex, ey = int(_r(context, x2)), int(_r(context, y2))
    am = _am(context)
    am.swipe(sx, sy, ex, ey)
    _log(context, f"✓ Swipe ({sx},{sy}) → ({ex},{ey})")


@step('hago swipe desde "{x1}" "{y1}" hasta "{x2}" "{y2}" con duración "{ms}" ms')
def step_swipe_coordinates_duration(context, x1, y1, x2, y2, ms):
    """Swipe entre coordenadas con duración específica."""
    sx, sy = int(_r(context, x1)), int(_r(context, y1))
    ex, ey = int(_r(context, x2)), int(_r(context, y2))
    duration = int(_r(context, ms))
    am = _am(context)
    am.swipe(sx, sy, ex, ey, duration)
    _log(context, f"✓ Swipe ({sx},{sy}) → ({ex},{ey}) en {duration}ms")


@step('hago pinch en el elemento móvil "{locator}"')
def step_pinch(context, locator):
    """Gesto de pinch (zoom out) sobre un elemento."""
    resolved = _r(context, locator)
    am = _am(context)
    am.pinch(resolved)
    _log(context, f"✓ Pinch en: {resolved}")


@step('hago zoom en el elemento móvil "{locator}"')
def step_zoom(context, locator):
    """Gesto de zoom (zoom in) sobre un elemento."""
    resolved = _r(context, locator)
    am = _am(context)
    am.zoom(resolved)
    _log(context, f"✓ Zoom en: {resolved}")


@step('hago scroll hasta el final de la pantalla del dispositivo')
def step_scroll_to_bottom(context):
    """Scroll hasta el final de la pantalla (máximo 20 swipes)."""
    am = _am(context)
    am.scroll_down(20)
    _log(context, "✓ Scroll hasta el final de la pantalla")


# ============================================================================
# 5. NAVEGACIÓN DEL DISPOSITIVO (10 pasos)
# ============================================================================

@step('presiono atrás en el dispositivo')
def step_go_back(context):
    """Presiona el botón Atrás del dispositivo."""
    am = _am(context)
    am.go_back()
    _log(context, "✓ Botón Atrás presionado")


@step('presiono el botón home del dispositivo')
def step_go_home(context):
    """Presiona el botón Home del dispositivo."""
    am = _am(context)
    am.go_home()
    _log(context, "✓ Botón Home presionado")


@step('abro el panel de notificaciones del dispositivo')
def step_open_notifications(context):
    """Abre el panel de notificaciones (Android)."""
    am = _am(context)
    am.open_notifications()
    _log(context, "✓ Panel de notificaciones abierto")


@step('cambio la orientación del dispositivo a "{orientation}"')
def step_set_orientation(context, orientation):
    """Cambia la orientación: PORTRAIT o LANDSCAPE."""
    resolved = _r(context, orientation)
    am = _am(context)
    am.set_orientation(resolved)
    _log(context, f"✓ Orientación cambiada a: {resolved}")


@step('cambio la orientación del dispositivo a horizontal')
def step_set_landscape(context):
    """Cambia a orientación horizontal."""
    am = _am(context)
    am.set_orientation('LANDSCAPE')
    _log(context, "✓ Orientación cambiada a LANDSCAPE")


@step('cambio la orientación del dispositivo a vertical')
def step_set_portrait(context):
    """Cambia a orientación vertical."""
    am = _am(context)
    am.set_orientation('PORTRAIT')
    _log(context, "✓ Orientación cambiada a PORTRAIT")


@step('presiono el botón atrás del dispositivo repetidamente "{n}" veces')
def step_go_back_n(context, n):
    """Presiona el botón Atrás N veces."""
    times = int(_r(context, n))
    am = _am(context)
    for _ in range(times):
        am.go_back()
        am.wait_seconds(0.3)
    _log(context, f"✓ Botón Atrás presionado {times} veces")


@step('activo el modo web en el contexto')
def step_switch_to_web_mode(context):
    """Vuelve al modo web en el framework (para pruebas mixtas)."""
    am = _am(context)
    am.switch_to_web_mode(context)
    _log(context, "✓ Modo web restaurado")


@step('abro la url "{url}" en el navegador del dispositivo')
def step_open_url_in_device(context, url):
    """Abre una URL en el navegador del dispositivo."""
    resolved = _r(context, url)
    am = _am(context)
    am._require_driver()
    am.driver.get(resolved)
    _log(context, f"✓ URL abierta en dispositivo: {resolved}")


# ============================================================================
# 6. VERIFICACIÓN DE ELEMENTOS (20 pasos)
# ============================================================================

@step('verifico que el elemento móvil "{locator}" es visible')
def step_verify_visible(context, locator):
    """Verifica que un elemento sea visible."""
    resolved = _r(context, locator)
    am = _am(context)
    assert am.is_element_visible(resolved), \
        f"El elemento no es visible: {resolved}"
    _log(context, f"✓ Elemento visible: {resolved}")


@step('verifico que el elemento móvil "{locator}" no es visible')
def step_verify_not_visible(context, locator):
    """Verifica que un elemento NO sea visible."""
    resolved = _r(context, locator)
    am = _am(context)
    assert not am.is_element_visible(resolved, timeout=3), \
        f"El elemento es visible cuando no debería: {resolved}"
    _log(context, f"✓ Elemento no visible: {resolved}")


@step('verifico que el elemento móvil "{locator}" existe')
def step_verify_present(context, locator):
    """Verifica que un elemento exista en el DOM."""
    resolved = _r(context, locator)
    am = _am(context)
    assert am.is_element_present(resolved), \
        f"El elemento no existe: {resolved}"
    _log(context, f"✓ Elemento existe: {resolved}")


@step('verifico que el elemento móvil "{locator}" no existe')
def step_verify_not_present(context, locator):
    """Verifica que un elemento NO exista en el DOM."""
    resolved = _r(context, locator)
    am = _am(context)
    assert not am.is_element_present(resolved), \
        f"El elemento existe cuando no debería: {resolved}"
    _log(context, f"✓ Elemento no existe: {resolved}")


@step('verifico que el elemento móvil "{locator}" está habilitado')
def step_verify_enabled(context, locator):
    """Verifica que un elemento esté habilitado."""
    resolved = _r(context, locator)
    am = _am(context)
    assert am.is_element_enabled(resolved), \
        f"El elemento no está habilitado: {resolved}"
    _log(context, f"✓ Elemento habilitado: {resolved}")


@step('verifico que el elemento móvil "{locator}" está deshabilitado')
def step_verify_disabled(context, locator):
    """Verifica que un elemento esté deshabilitado."""
    resolved = _r(context, locator)
    am = _am(context)
    assert not am.is_element_enabled(resolved), \
        f"El elemento está habilitado cuando no debería: {resolved}"
    _log(context, f"✓ Elemento deshabilitado: {resolved}")


@step('verifico que el elemento móvil "{locator}" está seleccionado')
def step_verify_selected(context, locator):
    """Verifica que un elemento esté seleccionado (checkbox, radio)."""
    resolved = _r(context, locator)
    am = _am(context)
    assert am.is_element_selected(resolved), \
        f"El elemento no está seleccionado: {resolved}"
    _log(context, f"✓ Elemento seleccionado: {resolved}")


@step('verifico que el elemento móvil "{locator}" no está seleccionado')
def step_verify_not_selected(context, locator):
    """Verifica que un elemento NO esté seleccionado."""
    resolved = _r(context, locator)
    am = _am(context)
    assert not am.is_element_selected(resolved), \
        f"El elemento está seleccionado cuando no debería: {resolved}"
    _log(context, f"✓ Elemento no seleccionado: {resolved}")


@step('verifico que el texto del elemento móvil "{locator}" es "{expected}"')
def step_verify_text_exact(context, locator, expected):
    """Verifica que el texto de un elemento sea exactamente el esperado."""
    resolved_loc = _r(context, locator)
    resolved_exp = _r(context, expected)
    am = _am(context)
    actual = am.get_text(resolved_loc)
    assert actual == resolved_exp, \
        f"Texto esperado: '{resolved_exp}', obtenido: '{actual}'"
    _log(context, f"✓ Texto verificado: '{actual}'")


@step('verifico que el texto del elemento móvil "{locator}" contiene "{expected}"')
def step_verify_text_contains(context, locator, expected):
    """Verifica que el texto de un elemento contenga un substring."""
    resolved_loc = _r(context, locator)
    resolved_exp = _r(context, expected)
    am = _am(context)
    actual = am.get_text(resolved_loc)
    assert resolved_exp in actual, \
        f"Texto '{actual}' no contiene '{resolved_exp}'"
    _log(context, f"✓ Texto contiene '{resolved_exp}'")


@step('verifico que el texto del elemento móvil "{locator}" no contiene "{unexpected}"')
def step_verify_text_not_contains(context, locator, unexpected):
    """Verifica que el texto de un elemento NO contenga un substring."""
    resolved_loc = _r(context, locator)
    resolved_unexp = _r(context, unexpected)
    am = _am(context)
    actual = am.get_text(resolved_loc)
    assert resolved_unexp not in actual, \
        f"Texto '{actual}' contiene '{resolved_unexp}' cuando no debería"
    _log(context, f"✓ Texto no contiene '{resolved_unexp}'")


@step('verifico que el texto del elemento móvil "{locator}" no está vacío')
def step_verify_text_not_empty(context, locator):
    """Verifica que el texto de un elemento no esté vacío."""
    resolved = _r(context, locator)
    am = _am(context)
    actual = am.get_text(resolved)
    assert actual and actual.strip(), \
        f"El texto del elemento está vacío: {resolved}"
    _log(context, f"✓ Texto no vacío: '{actual}'")


@step('verifico que el atributo "{attr}" del elemento móvil "{locator}" es "{expected}"')
def step_verify_attribute_exact(context, attr, locator, expected):
    """Verifica el valor exacto de un atributo."""
    resolved_loc = _r(context, locator)
    resolved_attr = _r(context, attr)
    resolved_exp = _r(context, expected)
    am = _am(context)
    actual = am.get_attribute(resolved_loc, resolved_attr)
    assert actual == resolved_exp, \
        f"Atributo '{resolved_attr}' esperado: '{resolved_exp}', obtenido: '{actual}'"
    _log(context, f"✓ Atributo '{resolved_attr}' = '{actual}'")


@step('verifico que el atributo "{attr}" del elemento móvil "{locator}" contiene "{expected}"')
def step_verify_attribute_contains(context, attr, locator, expected):
    """Verifica que un atributo contenga un substring."""
    resolved_loc = _r(context, locator)
    resolved_attr = _r(context, attr)
    resolved_exp = _r(context, expected)
    am = _am(context)
    actual = am.get_attribute(resolved_loc, resolved_attr)
    assert actual and resolved_exp in actual, \
        f"Atributo '{resolved_attr}' no contiene '{resolved_exp}'"
    _log(context, f"✓ Atributo '{resolved_attr}' contiene '{resolved_exp}'")


@step('verifico que hay "{count}" elementos móviles "{locator}"')
def step_verify_element_count(context, count, locator):
    """Verifica la cantidad exacta de elementos."""
    resolved = _r(context, locator)
    expected_count = int(_r(context, count))
    am = _am(context)
    actual_count = am.get_element_count(resolved)
    assert actual_count == expected_count, \
        f"Cantidad esperada: {expected_count}, obtenida: {actual_count}"
    _log(context, f"✓ Cantidad de elementos: {actual_count}")


@step('verifico que hay al menos "{count}" elementos móviles "{locator}"')
def step_verify_element_count_min(context, count, locator):
    """Verifica que haya al menos N elementos."""
    resolved = _r(context, locator)
    min_count = int(_r(context, count))
    am = _am(context)
    actual_count = am.get_element_count(resolved)
    assert actual_count >= min_count, \
        f"Se esperaban al menos {min_count} elementos, hay {actual_count}"
    _log(context, f"✓ Al menos {min_count} elementos ({actual_count} encontrados)")


@step('verifico que la orientación del dispositivo es "{orientation}"')
def step_verify_orientation(context, orientation):
    """Verifica la orientación actual del dispositivo."""
    resolved = _r(context, orientation).upper()
    am = _am(context)
    actual = am.get_orientation()
    assert actual == resolved, \
        f"Orientación esperada: {resolved}, actual: {actual}"
    _log(context, f"✓ Orientación verificada: {actual}")


# ============================================================================
# 7. OBTENCIÓN DE DATOS Y VARIABLES (12 pasos)
# ============================================================================

@step('obtengo el texto del elemento móvil "{locator}" y lo guardo en la variable "{var}"')
def step_get_text_to_var(context, locator, var):
    """Obtiene el texto de un elemento y lo guarda en una variable."""
    resolved = _r(context, locator)
    am = _am(context)
    text = am.get_text(resolved)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, text)
    _log(context, f"✓ Texto '{text}' guardado en variable '{var}'")


@step('obtengo el atributo "{attr}" del elemento móvil "{locator}" y lo guardo en la variable "{var}"')
def step_get_attr_to_var(context, attr, locator, var):
    """Obtiene un atributo de un elemento y lo guarda en una variable."""
    resolved_loc = _r(context, locator)
    resolved_attr = _r(context, attr)
    am = _am(context)
    value = am.get_attribute(resolved_loc, resolved_attr)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, value)
    _log(context, f"✓ Atributo '{resolved_attr}' = '{value}' guardado en '{var}'")


@step('obtengo la cantidad de elementos móviles "{locator}" y la guardo en la variable "{var}"')
def step_get_count_to_var(context, locator, var):
    """Cuenta los elementos y guarda el resultado en una variable."""
    resolved = _r(context, locator)
    am = _am(context)
    count = am.get_element_count(resolved)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, str(count))
    _log(context, f"✓ Cantidad {count} guardada en variable '{var}'")


@step('obtengo la orientación del dispositivo y la guardo en la variable "{var}"')
def step_get_orientation_to_var(context, var):
    """Obtiene la orientación actual y la guarda en una variable."""
    am = _am(context)
    orientation = am.get_orientation()
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, orientation)
    _log(context, f"✓ Orientación '{orientation}' guardada en '{var}'")


@step('obtengo el tamaño de la pantalla del dispositivo y lo guardo en las variables "{w_var}" y "{h_var}"')
def step_get_window_size_to_vars(context, w_var, h_var):
    """Obtiene el tamaño de pantalla y guarda ancho y alto en variables."""
    am = _am(context)
    size = am.get_window_size()
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(w_var, str(size['width']))
        context.variable_manager.set_variable(h_var, str(size['height']))
    _log(context, f"✓ Pantalla {size['width']}x{size['height']} guardada en '{w_var}' y '{h_var}'")


@step('obtengo la información del dispositivo y la guardo en la variable "{var}"')
def step_get_device_info_to_var(context, var):
    """Obtiene información del dispositivo y la guarda como JSON."""
    am = _am(context)
    info = am.get_device_info()
    info_str = json.dumps(info, ensure_ascii=False)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, info_str)
    _log(context, f"✓ Info del dispositivo guardada en '{var}'")


@step('obtengo el contexto actual del dispositivo y lo guardo en la variable "{var}"')
def step_get_current_context_to_var(context, var):
    """Obtiene el contexto actual (NATIVE_APP o WEBVIEW) y lo guarda."""
    am = _am(context)
    ctx = am.get_current_context()
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, ctx)
    _log(context, f"✓ Contexto '{ctx}' guardado en '{var}'")


@step('obtengo los contextos disponibles del dispositivo y los guardo en la variable "{var}"')
def step_get_contexts_to_var(context, var):
    """Obtiene la lista de contextos disponibles y la guarda."""
    am = _am(context)
    contexts = am.get_contexts()
    contexts_str = json.dumps(contexts)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, contexts_str)
    _log(context, f"✓ Contextos {contexts} guardados en '{var}'")


@step('obtengo el código fuente de la pantalla del dispositivo y lo guardo en la variable "{var}"')
def step_get_page_source_to_var(context, var):
    """Obtiene el XML/HTML de la pantalla actual y lo guarda."""
    am = _am(context)
    source = am.get_page_source()
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, source)
    _log(context, f"✓ Código fuente guardado en '{var}' ({len(source)} chars)")


@step('imprimo la información del dispositivo')
def step_print_device_info(context):
    """Imprime la información del dispositivo en el log."""
    am = _am(context)
    info = am.get_device_info()
    _log(context, f"📱 Dispositivo: {json.dumps(info, indent=2, ensure_ascii=False)}")


@step('imprimo los contextos disponibles del dispositivo')
def step_print_contexts(context):
    """Imprime los contextos disponibles en el log."""
    am = _am(context)
    contexts = am.get_contexts()
    _log(context, f"📱 Contextos disponibles: {contexts}")


@step('imprimo el código fuente de la pantalla del dispositivo')
def step_print_page_source(context):
    """Imprime el XML/HTML de la pantalla actual en el log."""
    am = _am(context)
    source = am.get_page_source()
    _log(context, f"📱 Código fuente de pantalla:\n{source[:2000]}")


# ============================================================================
# 8. ALERTAS Y DIÁLOGOS (8 pasos)
# ============================================================================

@step('acepto la alerta nativa del dispositivo')
def step_accept_alert(context):
    """Acepta una alerta nativa."""
    am = _am(context)
    am.accept_alert()
    _log(context, "✓ Alerta aceptada")


@step('rechazo la alerta del dispositivo')
def step_dismiss_alert(context):
    """Rechaza/descarta una alerta nativa."""
    am = _am(context)
    am.dismiss_alert()
    _log(context, "✓ Alerta rechazada")


@step('obtengo el texto de la alerta del dispositivo y lo guardo en la variable "{var}"')
def step_get_alert_text_to_var(context, var):
    """Obtiene el texto de una alerta y lo guarda en una variable."""
    am = _am(context)
    text = am.get_alert_text()
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, text)
    _log(context, f"✓ Texto de alerta '{text}' guardado en '{var}'")


@step('escribo el texto "{text}" en la alerta del dispositivo')
def step_type_in_alert(context, text):
    """Escribe texto en el campo de una alerta nativa."""
    resolved = _r(context, text)
    am = _am(context)
    am.type_in_alert(resolved)
    _log(context, f"✓ Texto escrito en alerta: {resolved}")


@step('escribo "{text}" en la alerta del dispositivo y la acepto')
def step_type_in_alert_and_accept(context, text):
    """Escribe texto en una alerta y la acepta."""
    resolved = _r(context, text)
    am = _am(context)
    am.type_in_alert(resolved)
    am.accept_alert()
    _log(context, f"✓ Texto escrito en alerta y aceptada")


@step('verifico que el texto de la alerta del dispositivo es "{expected}"')
def step_verify_alert_text_exact(context, expected):
    """Verifica que el texto de la alerta sea exactamente el esperado."""
    resolved = _r(context, expected)
    am = _am(context)
    actual = am.get_alert_text()
    assert actual == resolved, \
        f"Texto de alerta esperado: '{resolved}', obtenido: '{actual}'"
    _log(context, f"✓ Texto de alerta verificado: '{actual}'")


@step('verifico que el texto de la alerta del dispositivo contiene "{expected}"')
def step_verify_alert_text_contains(context, expected):
    """Verifica que el texto de la alerta contenga un substring."""
    resolved = _r(context, expected)
    am = _am(context)
    actual = am.get_alert_text()
    assert resolved in actual, \
        f"Texto de alerta '{actual}' no contiene '{resolved}'"
    _log(context, f"✓ Texto de alerta contiene '{resolved}'")


@step('acepto la alerta del dispositivo solo si existe')
def step_accept_alert_if_exists(context):
    """Acepta una alerta si existe, sin fallar si no hay alerta."""
    am = _am(context)
    try:
        am.accept_alert()
        _log(context, "✓ Alerta aceptada")
    except Exception:
        _log(context, "⚠ No hay alerta presente, se omite")


# ============================================================================
# 9. ESPERAS (10 pasos)
# ============================================================================

@step('espero "{seconds}" segundos en el dispositivo')
def step_wait_seconds(context, seconds):
    """Pausa la ejecución N segundos."""
    secs = float(_r(context, seconds))
    am = _am(context)
    am.wait_seconds(secs)
    _log(context, f"✓ Espera de {secs}s completada")


@step('espero que el elemento móvil "{locator}" sea visible')
def step_wait_element_visible(context, locator):
    """Espera hasta que un elemento sea visible (timeout por defecto)."""
    resolved = _r(context, locator)
    am = _am(context)
    am.wait_for_element(resolved)
    _log(context, f"✓ Elemento visible: {resolved}")


@step('espero a que el elemento móvil "{locator}" sea visible en máximo "{seconds}" segundos')
def step_wait_element_visible_timeout(context, locator, seconds):
    """Espera hasta que un elemento sea visible con timeout específico."""
    resolved = _r(context, locator)
    timeout = float(_r(context, seconds))
    am = _am(context)
    am.wait_for_element(resolved, timeout)
    _log(context, f"✓ Elemento visible en {timeout}s: {resolved}")


@step('espero que el elemento móvil "{locator}" desaparezca')
def step_wait_element_disappear(context, locator):
    """Espera hasta que un elemento desaparezca."""
    resolved = _r(context, locator)
    am = _am(context)
    am.wait_for_element_to_disappear(resolved)
    _log(context, f"✓ Elemento desapareció: {resolved}")


@step('espero a que el elemento móvil "{locator}" desaparezca en máximo "{seconds}" segundos')
def step_wait_element_disappear_timeout(context, locator, seconds):
    """Espera hasta que un elemento desaparezca con timeout específico."""
    resolved = _r(context, locator)
    timeout = float(_r(context, seconds))
    am = _am(context)
    am.wait_for_element_to_disappear(resolved, timeout)
    _log(context, f"✓ Elemento desapareció en {timeout}s: {resolved}")


@step('espero que el texto móvil "{text}" sea visible')
def step_wait_text_visible(context, text):
    """Espera hasta que un texto sea visible en pantalla."""
    resolved = _r(context, text)
    am = _am(context)
    am.wait_for_text(resolved)
    _log(context, f"✓ Texto visible: {resolved}")


@step('espero a que el texto móvil "{text}" sea visible en máximo "{seconds}" segundos')
def step_wait_text_visible_timeout(context, text, seconds):
    """Espera hasta que un texto sea visible con timeout específico."""
    resolved = _r(context, text)
    timeout = float(_r(context, seconds))
    am = _am(context)
    am.wait_for_text(resolved, timeout)
    _log(context, f"✓ Texto visible en {timeout}s: {resolved}")


@step('espero que el elemento móvil "{locator}" exista')
def step_wait_element_present(context, locator):
    """Espera hasta que un elemento exista en el DOM."""
    resolved = _r(context, locator)
    am = _am(context)
    am._find_element(resolved)
    _log(context, f"✓ Elemento presente: {resolved}")


@step('espero a que el elemento móvil "{locator}" exista en máximo "{seconds}" segundos')
def step_wait_element_present_timeout(context, locator, seconds):
    """Espera hasta que un elemento exista con timeout específico."""
    resolved = _r(context, locator)
    timeout = float(_r(context, seconds))
    am = _am(context)
    am._find_element(resolved, timeout)
    _log(context, f"✓ Elemento presente en {timeout}s: {resolved}")


@step('espero a que la pantalla del dispositivo esté estable durante "{seconds}" segundos')
def step_wait_screen_stable(context, seconds):
    """Espera a que la pantalla no cambie durante N segundos (útil para animaciones)."""
    secs = float(_r(context, seconds))
    am = _am(context)
    source1 = am.get_page_source()
    am.wait_seconds(secs)
    source2 = am.get_page_source()
    assert source1 == source2, "La pantalla cambió durante la espera"
    _log(context, f"✓ Pantalla estable durante {secs}s")


# ============================================================================
# 10. SCREENSHOTS Y REPORTES (6 pasos)
# ============================================================================

@step('tomo screenshot del dispositivo')
def step_take_screenshot(context):
    """Toma un screenshot del dispositivo y lo agrega al reporte."""
    am = _am(context)
    path = am.take_screenshot()
    _screenshot_to_report(context, path, "Screenshot del dispositivo")
    _log(context, f"✓ Screenshot guardado: {path}")


@step('tomo un screenshot nombrado "{name}" del dispositivo')
def step_take_screenshot_named(context, name):
    """Toma un screenshot con un nombre específico."""
    resolved = _r(context, name)
    am = _am(context)
    path = am.take_screenshot(resolved)
    _screenshot_to_report(context, path, resolved)
    _log(context, f"✓ Screenshot '{resolved}' guardado: {path}")


@step('tomo un screenshot del elemento móvil "{locator}"')
def step_take_element_screenshot(context, locator):
    """Toma un screenshot de un elemento específico."""
    resolved = _r(context, locator)
    am = _am(context)
    path = am.take_element_screenshot(resolved)
    _screenshot_to_report(context, path, f"Elemento: {resolved}")
    _log(context, f"✓ Screenshot de elemento guardado: {path}")


@step('tomo un screenshot nombrado "{name}" del elemento móvil "{locator}"')
def step_take_element_screenshot_named(context, name, locator):
    """Toma un screenshot de un elemento con nombre específico."""
    resolved_loc = _r(context, locator)
    resolved_name = _r(context, name)
    am = _am(context)
    path = am.take_element_screenshot(resolved_loc, resolved_name)
    _screenshot_to_report(context, path, resolved_name)
    _log(context, f"✓ Screenshot '{resolved_name}' guardado: {path}")


@step('tomo un screenshot del dispositivo guardándolo en la variable "{var}"')
def step_take_screenshot_to_var(context, var):
    """Toma un screenshot y guarda la ruta en una variable."""
    am = _am(context)
    path = am.take_screenshot()
    _screenshot_to_report(context, path, "Screenshot")
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, path)
    _log(context, f"✓ Screenshot guardado en variable '{var}': {path}")


@step('tomo un screenshot del dispositivo por fallo del paso anterior')
def step_take_screenshot_on_failure(context):
    """Toma un screenshot solo si el escenario tiene errores."""
    if hasattr(context, 'scenario') and context.scenario.status == 'failed':
        am = _am(context)
        path = am.take_screenshot("fallo")
        _screenshot_to_report(context, path, "Screenshot de fallo")
        _log(context, f"✓ Screenshot de fallo guardado: {path}")
    else:
        _log(context, "⚠ No hay fallo, se omite screenshot")


# ============================================================================
# 11. EJECUCIÓN DE SCRIPTS Y COMANDOS (5 pasos)
# ============================================================================

@step('ejecuto el script "{script}" solo en el dispositivo')
def step_execute_script(context, script):
    """Ejecuta un script JavaScript (en contexto WebView)."""
    resolved = _r(context, script)
    am = _am(context)
    result = am.execute_script(resolved)
    context._last_script_result = result
    _log(context, f"✓ Script ejecutado, resultado: {result}")


@step('ejecuto el script "{script}" en el dispositivo guardando resultado en la variable "{var}"')
def step_execute_script_to_var(context, script, var):
    """Ejecuta un script y guarda el resultado en una variable."""
    resolved = _r(context, script)
    am = _am(context)
    result = am.execute_script(resolved)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, str(result))
    _log(context, f"✓ Script ejecutado, resultado guardado en '{var}'")


@step('ejecuto el comando mobile "{command}" solo en el dispositivo')
def step_execute_mobile_command(context, command):
    """Ejecuta un comando mobile específico de Appium."""
    resolved = _r(context, command)
    am = _am(context)
    result = am.execute_mobile_command(resolved)
    context._last_mobile_command_result = result
    _log(context, f"✓ Comando mobile '{resolved}' ejecutado")


@step('ejecuto el comando mobile "{command}" con argumentos en el dispositivo')
def step_execute_mobile_command_with_args(context, command):
    """Ejecuta un comando mobile con argumentos de tabla Gherkin."""
    resolved = _r(context, command)
    am = _am(context)
    args = {}
    if context.table:
        for row in context.table:
            args[row['key']] = row['value']
    result = am.execute_mobile_command(resolved, args)
    context._last_mobile_command_result = result
    _log(context, f"✓ Comando mobile '{resolved}' ejecutado con {len(args)} argumentos")


@step('ejecuto el comando mobile "{command}" en el dispositivo guardando resultado en la variable "{var}"')
def step_execute_mobile_command_to_var(context, command, var):
    """Ejecuta un comando mobile y guarda el resultado en una variable."""
    resolved = _r(context, command)
    am = _am(context)
    result = am.execute_mobile_command(resolved)
    if hasattr(context, 'variable_manager'):
        context.variable_manager.set_variable(var, str(result))
    _log(context, f"✓ Comando mobile '{resolved}' ejecutado, resultado en '{var}'")


# ============================================================================
# 12. CONTEXTOS Y MODO MIXTO (6 pasos)
# ============================================================================

@step('cambio al contexto webview del dispositivo')
def step_switch_to_webview(context):
    """Cambia al primer contexto WebView disponible."""
    am = _am(context)
    am.switch_to_webview()
    _log(context, "✓ Cambiado a contexto WebView")


@step('cambio al contexto webview número "{index}" del dispositivo')
def step_switch_to_webview_index(context, index):
    """Cambia a un contexto WebView específico por índice."""
    idx = int(_r(context, index))
    am = _am(context)
    am.switch_to_webview(idx)
    _log(context, f"✓ Cambiado a WebView #{idx}")


@step('cambio al contexto nativo del dispositivo')
def step_switch_to_native(context):
    """Cambia al contexto nativo (NATIVE_APP)."""
    am = _am(context)
    am.switch_to_native()
    _log(context, "✓ Cambiado a contexto nativo")


@step('verifico que el contexto actual del dispositivo es "{expected}"')
def step_verify_current_context(context, expected):
    """Verifica el contexto actual del dispositivo."""
    resolved = _r(context, expected)
    am = _am(context)
    actual = am.get_current_context()
    assert resolved in actual, \
        f"Contexto esperado: '{resolved}', actual: '{actual}'"
    _log(context, f"✓ Contexto verificado: {actual}")


@step('verifico que hay contextos webview disponibles en el dispositivo')
def step_verify_webview_available(context):
    """Verifica que haya al menos un contexto WebView disponible."""
    am = _am(context)
    contexts = am.get_contexts()
    webviews = [c for c in contexts if 'WEBVIEW' in c]
    assert len(webviews) > 0, \
        f"No hay contextos WebView disponibles. Contextos: {contexts}"
    _log(context, f"✓ WebViews disponibles: {webviews}")


@step('verifico que el contexto actual del dispositivo es nativo')
def step_verify_native_context(context):
    """Verifica que el contexto actual sea NATIVE_APP."""
    am = _am(context)
    actual = am.get_current_context()
    assert actual == 'NATIVE_APP', \
        f"Contexto esperado: NATIVE_APP, actual: {actual}"
    _log(context, "✓ Contexto nativo verificado")
