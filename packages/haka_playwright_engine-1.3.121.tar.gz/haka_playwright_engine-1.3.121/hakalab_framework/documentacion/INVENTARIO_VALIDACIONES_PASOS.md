# Inventario de Pasos de Validación - Haka Playwright Engine

Documento generado a partir del código fuente real del framework.
Contiene únicamente los pasos que realizan validaciones, aserciones o verificaciones.
Cada paso fue verificado directamente en los archivos de la carpeta `steps/`.

---

## --- Accesibilidad ---

step: verifico que el elemento "{element_name}" tiene etiqueta ARIA "{expected_label}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una etiqueta ARIA específica (aria-label) para garantizar accesibilidad con lectores de pantalla.

step: verifico que el elemento "{element_name}" tiene rol ARIA "{expected_role}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un rol ARIA específico asignado para tecnologías asistivas.

step: verifico que el elemento "{element_name}" es accesible por teclado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento puede recibir foco y es navegable por teclado, comprobando que el tabindex no sea negativo.

step: verifico que el elemento "{element_name}" tiene texto alt "{expected_alt}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen tiene un texto alternativo específico para accesibilidad.

step: verifico que el elemento "{element_name}" tiene jerarquía de encabezados correcta con identificador "{identifier}"
descripcion: Este paso permite verificar que los encabezados de la página siguen una jerarquía correcta sin saltar niveles (h1, h2, h3...).

step: verifico que el formulario tiene etiquetas apropiadas para todos los campos
descripcion: Este paso permite verificar que todos los campos de formulario tienen etiquetas asociadas mediante label, aria-label o aria-labelledby.

step: verifico que el elemento "{element_name}" tiene contraste de color suficiente con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento cumple con el ratio mínimo de contraste de color de 4.5:1 según WCAG AA.

step: verifico que la página tiene estructura de documento apropiada
descripcion: Este paso permite verificar que la página tiene título, un solo h1, y elementos main o role="main" para estructura semántica correcta.

step: verifico que el elemento "{element_name}" es anunciado por lector de pantalla con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento será anunciado por lectores de pantalla, comprobando que no tenga aria-hidden="true" y tenga contenido accesible.

step: verifico que el elemento "{element_name}" tiene texto de enlace descriptivo con identificador "{identifier}"
descripcion: Este paso permite verificar que un enlace tiene texto descriptivo y no genérico como "click aquí" o "más".

step: verifico que las imágenes tienen texto alternativo apropiado
descripcion: Este paso permite verificar que todas las imágenes de la página tienen atributo alt y que no sea solo el nombre del archivo.

---

## --- Análisis Semántico Avanzado ---

step: el sentimiento del texto "{text}" debe ser "{expected_sentiment}"
descripcion: Este paso permite analizar el sentimiento de un texto usando modelos semánticos y verificar que coincida con el esperado (positivo, negativo o neutral).

step: el sentimiento de la variable "{var_name}" debe ser "{expected_sentiment}"
descripcion: Este paso permite analizar el sentimiento del texto almacenado en una variable y verificar que sea el esperado.

step: clasifico el texto "{text}" en las categorías "{categories}" y guardo el resultado en "{var_name}"
descripcion: Este paso permite clasificar un texto en una de las categorías proporcionadas usando similitud semántica y guardar el resultado en una variable.

step: el texto "{text}" debe pertenecer a la categoría "{expected_category}" de "{categories}"
descripcion: Este paso permite verificar que un texto pertenece a una categoría específica dentro de un conjunto de categorías usando clasificación semántica.

step: el idioma del texto "{text}" debe ser "{expected_language}"
descripcion: Este paso permite verificar que un texto está escrito en el idioma esperado (español, inglés, portugués, francés o alemán) usando similitud semántica.

step: busco el texto más similar a "{query}" en la lista "{text_list}" y lo guardo en "{var_name}"
descripcion: Este paso permite buscar el texto más similar a una consulta dentro de una lista de textos usando búsqueda semántica y guardar el resultado.

---

## --- API Testing ---

step: verifico que el código de estado de la respuesta API es "{expected_status}"
descripcion: Este paso permite verificar que el código de estado HTTP de la última respuesta API coincide con el esperado.

step: verifico que la respuesta API contiene "{key}" con valor "{expected_value}"
descripcion: Este paso permite verificar que la respuesta JSON de la API contiene una clave específica con un valor esperado, soportando notación de punto para claves anidadas.

step: extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor de la respuesta JSON de la API usando notación de punto y guardarlo en una variable para uso posterior.

step: verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos
descripcion: Este paso permite verificar que el tiempo de respuesta de la última petición API no excede un límite máximo en segundos.

step: verifico que la respuesta API es JSON válido
descripcion: Este paso permite verificar que el cuerpo de la última respuesta API puede ser parseado como JSON válido.

step: verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"
descripcion: Este paso permite verificar que un header específico de la respuesta API tiene exactamente el valor esperado.

step: verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"
descripcion: Este paso permite verificar que un header de la respuesta API contiene un texto parcial específico.

step: verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"
descripcion: Este paso permite verificar que el cuerpo de texto de la respuesta API contiene un texto específico.

step: verifico que el array JSON de respuesta API tiene "{expected_length}" elementos
descripcion: Este paso permite verificar que la respuesta API es un array JSON con una cantidad exacta de elementos.

step: verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"
descripcion: Este paso permite verificar que un elemento específico de un array JSON tiene una clave con el valor esperado.

step: verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"
descripcion: Este paso permite verificar que el código de estado HTTP está dentro de un rango numérico específico.

step: verifico que el tipo de contenido de respuesta API es "{expected_content_type}"
descripcion: Este paso permite verificar que el header Content-Type de la respuesta API coincide con el tipo esperado.

step: guardo el cuerpo de respuesta API en el archivo "{file_path}"
descripcion: Este paso permite guardar el cuerpo completo de la respuesta API en un archivo para análisis posterior.

step: verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"
descripcion: Este paso permite verificar que la respuesta JSON cumple con un esquema JSON Schema definido en un archivo.

step: envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"
descripcion: Este paso permite enviar múltiples peticiones API definidas en un archivo y guardar todos los resultados en una variable.

step: verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"
descripcion: Este paso permite comparar la respuesta API completa con una respuesta esperada almacenada en un archivo.

step: verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"
descripcion: Este paso permite verificar que la respuesta API incluye información de paginación con el total y página esperados.

step: verifico que los headers de rate limit están presentes en la respuesta API
descripcion: Este paso permite verificar que la respuesta API incluye headers de rate limiting como X-RateLimit-Limit y X-RateLimit-Remaining.

step: verifico que el endpoint API "{endpoint}" soporta CORS
descripcion: Este paso permite verificar que un endpoint API responde correctamente a peticiones CORS con los headers Access-Control apropiados.

step: verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"
descripcion: Este paso permite verificar que la respuesta API cumple con las convenciones REST estándar para el método HTTP utilizado.

step: mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"
descripcion: Este paso permite medir el rendimiento de un endpoint API ejecutando múltiples peticiones y guardando métricas como tiempo promedio y percentiles.

step: verifico que la respuesta API tiene headers de seguridad
descripcion: Este paso permite verificar que la respuesta API incluye headers de seguridad como X-Content-Type-Options, X-Frame-Options, etc.

step: verifico que se realizó una llamada a la API en "{api_url}"
descripcion: Este paso permite verificar que se capturó una llamada de red a una URL específica durante la ejecución del test.

step: verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"
descripcion: Este paso permite verificar que se capturó una llamada de red a una URL específica con un método HTTP determinado.

step: verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"
descripcion: Este paso permite verificar que una llamada API capturada incluye un parámetro de query string con un valor específico.

step: verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"
descripcion: Este paso permite verificar que una llamada API capturada incluye un header específico con el valor esperado.

step: verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"
descripcion: Este paso permite verificar que se realizó un número exacto de llamadas a una URL específica durante el test.

step: guardo los datos de la llamada a API en la variable "{variable_name}"
descripcion: Este paso permite guardar los datos completos de la última llamada API capturada en una variable.

step: verifico que NO se realizó una llamada a la API "{api_url}"
descripcion: Este paso permite verificar que no se realizó ninguna llamada de red a una URL específica durante el test.

step: obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor de la respuesta de una llamada API capturada usando una ruta JSON y guardarlo en una variable.

---

## --- Archivos ---

step: subo el archivo "{file_path}" al elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite subir un archivo a un elemento input de tipo file usando su ruta y localizador.

step: subo el archivo de descargas "{filename}" haciendo click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite subir un archivo desde la carpeta de descargas haciendo click en un elemento que abre el diálogo de archivos.

step: subo el archivo de descargas "{filename}" haciendo click en el input con id "{input_id}"
descripcion: Este paso permite subir un archivo desde la carpeta de descargas directamente a un input identificado por su id HTML.

step: subo múltiples archivos "{file_paths}" al elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite subir múltiples archivos simultáneamente a un elemento input de tipo file.

step: subo el archivo "{file_path}" haciendo click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite subir un archivo haciendo click en un elemento que abre el diálogo de selección de archivos.

step: espero a que complete la descarga
descripcion: Este paso permite esperar a que se complete una descarga de archivo iniciada en el navegador.

step: guardo la descarga como "{filename}"
descripcion: Este paso permite guardar el archivo descargado con un nombre específico en la carpeta de descargas del test.

step: verifico que existe el archivo descargado
descripcion: Este paso permite verificar que se descargó un archivo correctamente durante el test.

step: verifico que el nombre del archivo descargado es "{expected_filename}"
descripcion: Este paso permite verificar que el nombre del archivo descargado coincide con el esperado.

step: verifico que el tamaño del archivo descargado es mayor a "{min_size}" bytes
descripcion: Este paso permite verificar que el archivo descargado tiene un tamaño mínimo en bytes.

step: verifico que el archivo descargado contiene el texto "{text}"
descripcion: Este paso permite verificar que el contenido del archivo descargado incluye un texto específico.

step: verifico que la descarga es JSON válido
descripcion: Este paso permite verificar que el archivo descargado contiene JSON válido que puede ser parseado.

step: verifico que el JSON descargado contiene la clave "{key}" con valor "{value}"
descripcion: Este paso permite verificar que el JSON del archivo descargado contiene una clave con un valor específico.

step: verifico que la descarga es CSV válido con "{expected_columns}" columnas
descripcion: Este paso permite verificar que el archivo descargado es un CSV válido con el número esperado de columnas.

step: verifico que el CSV descargado tiene "{expected_rows}" filas
descripcion: Este paso permite verificar que el CSV descargado tiene un número exacto de filas de datos.

step: extraigo y verifico que el ZIP contiene los archivos "{expected_files}"
descripcion: Este paso permite extraer un archivo ZIP descargado y verificar que contiene los archivos esperados.

step: verifico que el archivo "{filename}" existe en el directorio "{directory}"
descripcion: Este paso permite verificar que un archivo específico existe en un directorio dado.

step: obtengo el tamaño del archivo "{filename}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el tamaño en bytes de un archivo y guardarlo en una variable.

---

## --- Archivos CSV ---

step: verifico que el archivo CSV "{file_path}" existe
descripcion: Este paso permite verificar que un archivo CSV existe en la ruta especificada.

step: verifico que el archivo CSV "{file_path}" tiene un peso de al menos {min_size:d} bytes
descripcion: Este paso permite verificar que un archivo CSV tiene un tamaño mínimo en bytes.

step: cargo el archivo CSV "{file_path}" en la variable "{variable_name}"
descripcion: Este paso permite cargar un archivo CSV completo en una variable como estructura de datos para análisis posterior.

step: busco en el CSV "{csv_variable}" el valor "{search_value}" en la columna "{column_name}"
descripcion: Este paso permite buscar un valor específico en una columna de un CSV cargado previamente en una variable.

step: obtengo el valor de la fila {row_index:d} columna "{column_name}" del CSV "{csv_variable}" y lo guardo en "{result_variable}"
descripcion: Este paso permite extraer un valor específico de una celda del CSV por índice de fila y nombre de columna.

step: filtro el CSV "{csv_variable}" donde "{column_name}" contiene "{filter_value}" y guardo como "{result_variable}"
descripcion: Este paso permite filtrar las filas de un CSV donde una columna contiene un valor específico.

step: verifico que el CSV "{csv_variable}" tiene {expected_rows:d} filas
descripcion: Este paso permite verificar que un CSV cargado tiene un número exacto de filas.

step: verifico que el CSV "{csv_variable}" contiene las columnas "{column_list}"
descripcion: Este paso permite verificar que un CSV contiene todas las columnas esperadas.

step: exporto el CSV "{csv_variable}" a "{output_path}"
descripcion: Este paso permite exportar un CSV procesado a un archivo en la ruta especificada.

step: muestro un resumen del CSV "{csv_variable}"
descripcion: Este paso permite mostrar un resumen estadístico del CSV incluyendo número de filas, columnas y tipos de datos.

step: busco en el CSV "{csv_variable}" múltiples valores "{values_list}" en columna "{column_name}"
descripcion: Este paso permite buscar múltiples valores en una columna del CSV y verificar cuáles se encuentran.

step: ordeno el CSV "{csv_variable}" por columna "{column_name}" de forma "{order_type}" y guardo como "{result_variable}"
descripcion: Este paso permite ordenar un CSV por una columna específica de forma ascendente o descendente.

---

## --- Aserciones ---

step: debería ver el texto "{text}"
descripcion: Este paso permite verificar que un texto exacto sea visible en la página actual.

step: debería ver el texto que contiene "{text}"
descripcion: Este paso permite verificar que un texto parcial sea visible en algún lugar de la página.

step: debería ver en la página el texto {text_with_variable}
descripcion: Este paso permite verificar que un texto parcial sea visible en la página, soportando variables sin comillas directamente.

step: no debería ver el texto "{text}"
descripcion: Este paso permite verificar que un texto específico no sea visible en la página actual.

step: el título de la página debería ser "{title}"
descripcion: Este paso permite verificar que el título de la página coincide exactamente con el texto esperado.

step: el título de la página debería contener "{text}"
descripcion: Este paso permite verificar que el título de la página contiene un texto parcial específico.

step: el elemento "{element_name}" debería existir con identificador "{identifier}" y valor "{value}"
descripcion: Este paso permite verificar que un elemento existe en el DOM usando un localizador dinámico con valor.

step: el elemento "{element_name}" debería existir en identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento existe en el DOM, sin importar si es visible o no.

step: el elemento "{element_name}" no debería existir con identificador "{identifier}" y valor "{value}"
descripcion: Este paso permite verificar que un elemento NO existe en el DOM usando un localizador dinámico con valor.

step: el elemento "{element_name}" no debería existir en identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO existe en el DOM.

step: debería ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento sea visible en la página.

step: no debería ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento no sea visible en la página.

step: el elemento "{element_name}" debería contener el texto "{text}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento contenga un texto específico dentro de su contenido.

step: el elemento "{element_name}" debería tener el texto exacto "{text}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento sea exactamente igual al esperado.

step: el campo "{field_name}" debería tener el valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario tiene un valor específico.

step: el campo "{field_name}" no debería tener el valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario NO tiene un valor específico.

step: el campo "{field_name}" debería estar vacío con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario está vacío.

step: el campo "{field_name}" no debería estar vacío con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario NO está vacío y tiene algún valor.

step: el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está habilitado para interacción.

step: el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está deshabilitado y no permite interacción.

step: el checkbox "{checkbox_name}" debería estar marcado con identificador "{identifier}"
descripcion: Este paso permite verificar que un checkbox está marcado (checked).

step: el checkbox "{checkbox_name}" no debería estar marcado con identificador "{identifier}"
descripcion: Este paso permite verificar que un checkbox NO está marcado.

step: la url actual debería ser "{url}"
descripcion: Este paso permite verificar que la URL actual del navegador coincide exactamente con la esperada.

step: la url actual debería contener "{url_part}"
descripcion: Este paso permite verificar que la URL actual contiene un texto parcial específico.

step: debería haberse abierto una nueva ventana con url que contiene "{url_part}"
descripcion: Este paso permite verificar que se abrió una nueva ventana cuya URL contiene el texto especificado.

step: debería haberse abierto una nueva ventana con título que contiene "{title}"
descripcion: Este paso permite verificar que se abrió una nueva ventana cuyo título contiene el texto especificado.

step: debería haber {count:d} ventanas abiertas
descripcion: Este paso permite verificar que hay un número exacto de ventanas del navegador abiertas.

step: el elemento "{element_name}" debería tener la clase "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una clase CSS específica.

step: el elemento "{element_name}" no debería tener la clase "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO tiene una clase CSS específica.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" en identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un atributo HTML específico presente.

step: el elemento "{element_name}" no debería tener el atributo "{attribute}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO tiene un atributo HTML específico.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un atributo con un valor exacto.

step: el elemento "{element_name}" debería tener el atributo "{attribute}" que contiene "{value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un atributo de un elemento contiene un valor parcial.

step: el elemento "{element_name}" debería ser de solo lectura con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es de solo lectura (readonly).

step: el elemento "{element_name}" no debería ser de solo lectura con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO es de solo lectura.

step: el elemento "{element_name}" debería ser requerido con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario es requerido (required).

step: el elemento "{element_name}" no debería ser requerido con identificador "{identifier}"
descripcion: Este paso permite verificar que un campo de formulario NO es requerido.

step: el elemento "{element_name}" debería estar oculto con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está oculto en la página.

step: el elemento "{element_name}" debería estar adjunto al DOM con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está presente en el DOM aunque no sea visible.

step: el elemento "{element_name}" debería ser editable con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es editable por el usuario.

step: el input "{element_name}" debería tener valor mínimo "{min_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input numérico tiene el atributo min con el valor esperado.

step: el input "{element_name}" debería tener valor máximo "{max_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input numérico tiene el atributo max con el valor esperado.

step: el input "{element_name}" debería tener longitud máxima "{maxlength}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input tiene el atributo maxlength con el valor esperado.

step: el input "{element_name}" debería tener patrón "{pattern}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input tiene el atributo pattern con la expresión regular esperada.

step: el input "{element_name}" debería tener placeholder "{placeholder}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input tiene el placeholder con el texto esperado.

step: el input "{element_name}" debería tener tipo "{input_type}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un input tiene el atributo type con el valor esperado.

step: debería haber exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que hay un número exacto de elementos que coinciden con un localizador.

step: debería haber al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que hay al menos una cantidad mínima de elementos que coinciden con un localizador.

step: debería haber como máximo {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que hay como máximo una cantidad de elementos que coinciden con un localizador.

step: el elemento "{element_name}" debería tener aria-label "{aria_label}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo aria-label con el valor esperado.

step: el elemento "{element_name}" debería tener rol "{role}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo role con el valor esperado.

step: el elemento "{element_name}" debería tener aria-expanded "{state}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo aria-expanded con el estado esperado.

step: el elemento "{element_name}" debería tener atributo data "{data_attr}" con valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un atributo data-* con un valor específico.

step: el enlace "{element_name}" debería tener href "{href}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un enlace tiene el atributo href con la URL exacta esperada.

step: el enlace "{element_name}" debería tener href que contiene "{href_part}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un enlace tiene un href que contiene un texto parcial.

step: la imagen "{element_name}" debería tener src "{src}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen tiene el atributo src con la URL exacta esperada.

step: la imagen "{element_name}" debería tener alt "{alt}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen tiene el atributo alt con el texto esperado.

step: el elemento "{element_name}" debería tener título "{title}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo title con el texto esperado.

step: el elemento "{element_name}" debería tener nombre "{name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo name con el valor esperado.

step: el elemento "{element_name}" debería tener id "{element_id}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el atributo id con el valor esperado.

step: el select "{element_name}" debería tener la opción seleccionada "{option_text}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un select tiene una opción específica seleccionada.

step: el select "{element_name}" debería tener {count:d} opciones con identificador "{identifier}"
descripcion: Este paso permite verificar que un select tiene un número exacto de opciones disponibles.

---

## --- Avanzado ---

step: emulo el dispositivo "{device_name}"
descripcion: Este paso permite emular un dispositivo específico en el navegador configurando viewport, user agent y características del dispositivo.

---

## --- Base de Datos ---

step: me conecto a la base de datos "{db_name}"
descripcion: Este paso permite establecer una conexión a una base de datos usando el nombre de configuración proporcionado.

step: me conecto a la base de datos SQLite "{db_path}"
descripcion: Este paso permite establecer una conexión a una base de datos SQLite usando la ruta del archivo.

step: me conecto a la base de datos usando configuración del entorno
descripcion: Este paso permite establecer una conexión a la base de datos usando las variables de entorno configuradas.

step: creo base de datos de prueba con datos de ejemplo
descripcion: Este paso permite crear una base de datos SQLite temporal con tablas y datos de ejemplo para testing.

step: ejecuto la consulta SQL "{query}" y guardo el resultado en la variable "{variable_name}"
descripcion: Este paso permite ejecutar una consulta SQL SELECT y guardar los resultados en una variable.

step: ejecuto la actualización SQL "{query}"
descripcion: Este paso permite ejecutar una sentencia SQL de modificación (INSERT, UPDATE, DELETE) en la base de datos.

step: verifico que el resultado de la consulta SQL tiene "{expected_count}" filas
descripcion: Este paso permite verificar que el resultado de la última consulta SQL tiene un número exacto de filas.

step: verifico que el resultado SQL contiene una fila con "{column}" igual a "{expected_value}"
descripcion: Este paso permite verificar que el resultado SQL contiene al menos una fila donde una columna tiene un valor específico.

step: obtengo el valor del resultado SQL de la columna "{column}" fila "{row_index}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor específico del resultado SQL por columna e índice de fila.

step: creo la tabla "{table_name}" con columnas "{columns_definition}"
descripcion: Este paso permite crear una tabla en la base de datos con la definición de columnas proporcionada.

step: inserto datos de prueba en la tabla "{table_name}" con valores "{values}"
descripcion: Este paso permite insertar datos de prueba en una tabla de la base de datos.

step: elimino la tabla "{table_name}"
descripcion: Este paso permite eliminar una tabla de la base de datos.

step: hago backup de la base de datos al archivo "{backup_file}"
descripcion: Este paso permite crear un backup de la base de datos actual en un archivo.

---

## --- Combobox y Select ---

step: verifico que el combobox "{element_name}" tiene seleccionada la opción "{option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene una opción específica seleccionada actualmente.

step: verifico que el combobox "{element_name}" contiene las opciones "{options}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox contiene todas las opciones esperadas en su lista.

step: navego las opciones del combobox con flechas y selecciono la opción "{option}" de "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite navegar las opciones de un combobox usando teclas de flecha y seleccionar una opción específica.

step: verifico que el combobox "{element_name}" tiene la opción "{option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una opción específica existe dentro de las opciones del combobox.

---

## --- Configuración Avanzada del Navegador ---

step: cargo la configuración del navegador desde el archivo "{config_file}"
descripcion: Este paso permite cargar configuración avanzada del navegador desde un archivo JSON o YAML.

---

## --- Control del Navegador ---

step: ejecuto el siguiente JavaScript y guardo el resultado en la variable "{variable_name}"
descripcion: Este paso permite ejecutar código JavaScript en el navegador y guardar el resultado en una variable.

---

## --- Drag and Drop ---

step: arrastro el elemento "{source_element}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite arrastrar un elemento y soltarlo sobre otro elemento usando sus identificadores.

step: arrastro el elemento "{element_name}" por desplazamiento x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Este paso permite arrastrar un elemento por un desplazamiento relativo en píxeles.

step: arrastro el elemento "{element_name}" a las coordenadas x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Este paso permite arrastrar un elemento a coordenadas absolutas específicas en la página.

step: paso el mouse sobre el elemento antes de arrastrar "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer hover sobre un elemento antes de iniciar una operación de arrastre.

step: arrastro lentamente el elemento "{element_name}" al elemento "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite arrastrar un elemento lentamente con pasos intermedios para simular un arrastre humano.

step: verifico que el drag and drop fue exitoso comprobando la posición del elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una operación de drag and drop fue exitosa comprobando la nueva posición del elemento.

step: verifico que el elemento "{element_name}" está en la posición x="{x}" y="{y}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está en coordenadas específicas de la página.

step: arrastro y suelto el archivo "{file_path}" al elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite simular el arrastre de un archivo desde el sistema de archivos a un elemento de la página.

step: arrastro el elemento "{source_element}" al elemento "{target_element}" usando API nativa con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite realizar drag and drop usando la API nativa de eventos del navegador.

step: realizo drag and drop avanzado desde "{source_element}" hasta "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite realizar drag and drop avanzado con eventos mousedown, mousemove y mouseup simulados.

step: simulo drag and drop con HTML5 desde "{source_element}" hasta "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite simular drag and drop usando la API HTML5 Drag and Drop con eventos dataTransfer.

---

## --- Email ---

step: selecciono la carpeta de email "{folder}"
descripcion: Este paso permite seleccionar una carpeta específica del buzón de correo para operaciones posteriores.

step: busco emails con asunto que contiene "{subject_text}" y guardo el conteo en la variable "{variable_name}"
descripcion: Este paso permite buscar emails por asunto y guardar la cantidad encontrada en una variable.

step: obtengo el contenido del email más reciente y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el contenido completo del email más reciente y guardarlo en una variable.

step: verifico que se recibió un email con asunto "{subject}" dentro de "{timeout}" segundos
descripcion: Este paso permite verificar que se recibió un email con un asunto específico dentro de un tiempo límite.

step: elimino emails con asunto que contiene "{subject_text}"
descripcion: Este paso permite eliminar emails cuyo asunto contiene un texto específico.

step: extraigo el código de verificación del cuerpo del email y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un código de verificación numérico del cuerpo de un email usando expresiones regulares.

---

## --- Entrada Avanzada ---

step: verifico que puedo escribir en el campo "{selector}"
descripcion: Este paso permite verificar que un campo de texto es editable y acepta entrada de texto.

step: escribo texto multilínea en "{selector}"
descripcion: Este paso permite escribir texto con múltiples líneas en un campo de texto usando la tabla de datos del paso.

---

## --- Evaluación GenAI ---

step: el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"
descripcion: Este paso permite cargar un archivo de reglas de negocio como contexto para evaluaciones con Gemini.

step: cambio al contexto de reglas de negocio "{context_name}"
descripcion: Este paso permite cambiar al contexto de reglas de negocio activo para las evaluaciones.

step: cargo la respuesta del SUT desde el archivo "{file_path}"
descripcion: Este paso permite cargar la respuesta del sistema bajo prueba desde un archivo para evaluación.

step: genero la respuesta con Gemini para el prompt "{user_query}"
descripcion: Este paso permite generar una respuesta usando Gemini AI para un prompt específico.

step: el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold:f}
descripcion: Este paso permite que el Juez Gemini evalúe la respuesta del SUT contra las reglas de negocio con un umbral de aprobación.

step: el Juez Gemini valida la respuesta con umbral {threshold:f}
descripcion: Este paso permite validar la respuesta usando el Juez Gemini con un umbral de score mínimo.

step: el Juez Gemini debe validar la respuesta
descripcion: Este paso permite que el Juez Gemini evalúe la respuesta usando el umbral por defecto.

step: guardo la evaluación del Juez en el archivo "{file_path}"
descripcion: Este paso permite guardar los resultados de la evaluación del Juez Gemini en un archivo.

step: el score de la última evaluación debe ser mayor o igual a {min_score:f}
descripcion: Este paso permite verificar que el score de la última evaluación del Juez cumple con un mínimo requerido.

---

## --- GenAI Avanzado ---

step: valido que la respuesta del SUT está en idioma "{language}"
descripcion: Este paso permite validar que la respuesta del sistema bajo prueba está escrita en el idioma esperado usando Gemini.

step: verifico que la respuesta está en "{language}"
descripcion: Este paso permite verificar el idioma de la respuesta del SUT de forma simplificada.

step: valido que la respuesta del SUT es un JSON válido
descripcion: Este paso permite validar que la respuesta del sistema bajo prueba es un JSON válido y parseable.

step: verifico que la respuesta es JSON válido
descripcion: Este paso permite verificar de forma simplificada que la respuesta es JSON válido.

step: valido que el JSON de respuesta tiene la estructura "{schema_file}"
descripcion: Este paso permite validar que el JSON de respuesta cumple con un esquema definido en un archivo.

step: verifico que el JSON cumple con el esquema "{schema_file}"
descripcion: Este paso permite verificar de forma simplificada que el JSON cumple con un esquema.

step: valido que la intención de la respuesta es "{expected_intent}"
descripcion: Este paso permite validar que la intención detectada en la respuesta del SUT coincide con la esperada usando Gemini.

step: verifico que la intención detectada es "{expected_intent}"
descripcion: Este paso permite verificar de forma simplificada la intención de la respuesta.

step: valido que la respuesta rechaza el prompt adversarial
descripcion: Este paso permite validar que el SUT rechaza correctamente intentos de prompt injection o jailbreaking.

step: verifico que la IA rechaza el intento de jailbreaking
descripcion: Este paso permite verificar de forma simplificada que la IA rechaza intentos de jailbreaking.

step: valido que la respuesta no contiene alucinaciones según el contexto
descripcion: Este paso permite validar que la respuesta del SUT no contiene información inventada que no está en el contexto proporcionado.

step: verifico que no hay hallucinations en la respuesta
descripcion: Este paso permite verificar de forma simplificada que no hay alucinaciones en la respuesta.

step: valido que la respuesta no contiene sesgos de "{bias_type}"
descripcion: Este paso permite validar que la respuesta del SUT no contiene sesgos del tipo especificado (género, raza, edad, etc.).

step: verifico que no hay sesgo de "{bias_type}" en la respuesta
descripcion: Este paso permite verificar de forma simplificada la ausencia de sesgos en la respuesta.

step: valido que la respuesta no contiene lenguaje tóxico
descripcion: Este paso permite validar que la respuesta del SUT no contiene lenguaje ofensivo, tóxico o inapropiado.

step: verifico que la respuesta es profesional y respetuosa
descripcion: Este paso permite verificar de forma simplificada que la respuesta mantiene un tono profesional.

step: valido que las respuestas "{var1}" y "{var2}" son consistentes
descripcion: Este paso permite validar que dos respuestas del SUT son semánticamente consistentes entre sí.

step: verifico consistencia entre "{var1}" y "{var2}"
descripcion: Este paso permite verificar de forma simplificada la consistencia entre dos respuestas.

step: valido que la respuesta cita fuentes correctamente
descripcion: Este paso permite validar que la respuesta del SUT incluye citaciones de fuentes verificables.

step: verifico que hay citación de fuentes en la respuesta
descripcion: Este paso permite verificar de forma simplificada que la respuesta incluye citaciones.

---

## --- Iframes ---

step: cambio al iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Este paso permite cambiar el contexto de ejecución a un iframe específico usando su localizador.

step: cambio al iframe por nombre "{name}"
descripcion: Este paso permite cambiar al iframe usando su atributo name.

step: cambio al iframe por src que contiene "{src_part}"
descripcion: Este paso permite cambiar al iframe cuyo atributo src contiene un texto parcial.

step: cambio al iframe por índice "{index}"
descripcion: Este paso permite cambiar al iframe por su posición numérica en la página.

step: hago click en el elemento "{element_name}" dentro del iframe con identificador "{identifier}"
descripcion: Este paso permite hacer click en un elemento que está dentro del iframe activo.

step: relleno el campo "{field_name}" con "{text}" dentro del iframe con identificador "{identifier}"
descripcion: Este paso permite rellenar un campo de texto dentro del iframe activo.

step: debería ver texto "{text}" dentro del iframe
descripcion: Este paso permite verificar que un texto específico es visible dentro del iframe activo.

step: debería ver el elemento "{element_name}" dentro del iframe con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible dentro del iframe activo.

step: espero a que cargue el iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar a que un iframe termine de cargar su contenido.

step: ejecuto javascript "{script}" dentro del iframe
descripcion: Este paso permite ejecutar código JavaScript dentro del contexto del iframe activo.

step: verifico que existe el iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un iframe existe en el DOM de la página.

step: verifico que el iframe "{iframe_name}" tiene src "{expected_src}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un iframe tiene el atributo src con la URL esperada.

---

## --- Interacción ---

step: remuevo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite remover un atributo HTML de un elemento usando JavaScript.

step: establezco el atributo "{attribute_name}" a "{attribute_value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite establecer o modificar un atributo HTML de un elemento usando JavaScript.

step: verifico que el elemento "{element_name}" con identificador "{identifier}" tiene el atributo "{attribute_name}"
descripcion: Este paso permite verificar que un elemento tiene un atributo HTML específico presente.

step: verifico que el elemento "{element_name}" con identificador "{identifier}" no tiene el atributo "{attribute_name}"
descripcion: Este paso permite verificar que un elemento NO tiene un atributo HTML específico.

step: obtengo el atributo "{attribute_name}" del elemento "{element_name}" con identificador "{identifier}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el valor de un atributo HTML de un elemento y guardarlo en una variable.

---

## --- Jira y Xray ---

step: verifico la conexión con Jira
descripcion: Este paso permite verificar que la conexión con el servidor Jira está configurada y funcional.

step: verifico que la issue "{issue_key}" existe en Jira
descripcion: Este paso permite verificar que una issue específica existe en Jira usando su clave.

step: agrego un comentario "{comment}" a la issue "{issue_key}"
descripcion: Este paso permite agregar un comentario a una issue existente en Jira.

step: adjunto el archivo "{file_path}" a la issue "{issue_key}"
descripcion: Este paso permite adjuntar un archivo a una issue en Jira.

step: verifico la configuración de Xray
descripcion: Este paso permite verificar que la configuración de Xray para test management está correcta.

step: creo un test execution "{summary}" en Xray
descripcion: Este paso permite crear un nuevo test execution en Xray con un resumen descriptivo.

step: agrego los tests "{test_keys}" al test execution actual
descripcion: Este paso permite agregar tests existentes al test execution activo en Xray.

step: actualizo el estado del test "{test_key}" a "{status}" en el test execution actual
descripcion: Este paso permite actualizar el estado de un test en el test execution activo de Xray.

step: verifico que el test "{test_key}" es de tipo Test en Jira
descripcion: Este paso permite verificar que una issue en Jira es de tipo Test para Xray.

step: busco issues en Jira con JQL "{jql}"
descripcion: Este paso permite buscar issues en Jira usando una consulta JQL y guardar los resultados.

step: verifico que la búsqueda JQL encontró "{expected_count}" issues
descripcion: Este paso permite verificar que una búsqueda JQL retornó el número esperado de resultados.

---

## --- Manejo de Formularios ---

step: valido el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite validar un formulario completo verificando que todos los campos requeridos están completos.

step: verifico los campos requeridos en el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que todos los campos marcados como requeridos en un formulario tienen valores.

---

## --- Modales ---

step: espero a que aparezca el modal "{modal_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar a que un modal sea visible en la página.

step: espero a que desaparezca el modal "{modal_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar a que un modal deje de ser visible en la página.

step: verifico que el modal "{modal_name}" es visible con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal está actualmente visible en la página.

step: verifico que el modal "{modal_name}" no es visible con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal no está visible en la página.

step: verifico que el modal "{modal_name}" tiene el título "{expected_title}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el título de un modal coincide con el texto esperado.

step: hago click en el botón "{button_text}" del modal "{modal_name}" con identificador de modal "{modal_id}"
descripcion: Este paso permite hacer click en un botón específico dentro de un modal.

step: relleno el campo "{field_name}" con "{text}" en el modal "{modal_name}" con identificadores modal="{modal_id}" campo="{field_id}"
descripcion: Este paso permite rellenar un campo de texto dentro de un modal usando identificadores separados.

step: verifico que el modal "{modal_name}" contiene el texto "{text}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal contiene un texto específico en su contenido.

step: espero a que aparezca cualquier modal
descripcion: Este paso permite esperar a que cualquier modal sea visible en la página.

step: verifico que no hay modales visibles
descripcion: Este paso permite verificar que no hay ningún modal visible en la página.

step: obtengo el mensaje del diálogo guardado
descripcion: Este paso permite obtener el mensaje del último diálogo del navegador que fue capturado.

step: el mensaje del diálogo capturado debería contener "{expected_text}"
descripcion: Este paso permite verificar que el mensaje del diálogo capturado contiene un texto específico.

step: el mensaje del diálogo capturado debería ser "{expected_text}"
descripcion: Este paso permite verificar que el mensaje del diálogo capturado es exactamente igual al texto esperado.

step: guardo el mensaje del diálogo capturado en la variable "{variable_name}"
descripcion: Este paso permite guardar el mensaje del último diálogo capturado en una variable.

---

## --- Navegación ---

step: voy a la url "{url}"
descripcion: Este paso permite navegar a una URL específica en el navegador, soportando variables en la URL.

---

## --- NLP Semántico ---

step: verifico que el texto "{text}" contiene una entidad de tipo "{entity_type}"
descripcion: Este paso permite verificar que un texto contiene una entidad nombrada de un tipo específico usando análisis NLP.

step: genero un resumen de la variable "{var_name}" con máximo {max_words:d} palabras y lo guardo en "{output_var}"
descripcion: Este paso permite generar un resumen automático del texto almacenado en una variable con un límite de palabras.

step: traduzco el texto "{text}" de "{source_lang}" a "{target_lang}" y lo guardo en "{var_name}"
descripcion: Este paso permite traducir un texto de un idioma a otro usando modelos semánticos y guardar el resultado.

step: verifico que el texto "{text}" no es tóxico
descripcion: Este paso permite verificar que un texto no contiene lenguaje tóxico, ofensivo o inapropiado.

step: agrupo los textos "{text_list}" en {num_clusters:d} clusters y guardo los resultados en "{var_name}"
descripcion: Este paso permite agrupar una lista de textos en clusters semánticos usando algoritmos de clustering.

---

## --- OCR ---

step: extraigo texto del screenshot "{screenshot_name}" usando OCR
descripcion: Este paso permite extraer texto de una captura de pantalla usando reconocimiento óptico de caracteres.

step: debería encontrar el texto "{expected_text}" en los resultados OCR
descripcion: Este paso permite verificar que un texto específico fue encontrado en los resultados del último análisis OCR.

step: no debería encontrar el texto "{unexpected_text}" en los resultados OCR
descripcion: Este paso permite verificar que un texto específico NO fue encontrado en los resultados OCR.

step: verifico que la calidad del texto OCR es al menos "{min_confidence}" por ciento
descripcion: Este paso permite verificar que la confianza del reconocimiento OCR alcanza un porcentaje mínimo.

step: tomo screenshot y extraigo texto con OCR usando engine "{engine}"
descripcion: Este paso permite tomar una captura de pantalla y extraer texto usando un motor OCR específico.

step: busco el texto "{search_text}" en la página actual usando OCR
descripcion: Este paso permite buscar un texto en la página actual usando OCR sobre una captura de pantalla.

step: verifico que el texto es legible en screenshot "{screenshot_name}" con confianza mínima "{min_confidence}"
descripcion: Este paso permite verificar que el texto en una captura es legible con un nivel mínimo de confianza.

step: comparo texto OCR con texto esperado "{expected_text}" con umbral de similitud "{threshold}" por ciento
descripcion: Este paso permite comparar el texto extraído por OCR con un texto esperado usando un umbral de similitud.

step: guardo resultados OCR en archivo "{filename}"
descripcion: Este paso permite guardar los resultados completos del análisis OCR en un archivo.

---

## --- PDF ---

step: verifico que el archivo PDF "{filename}" contiene el texto "{text}"
descripcion: Este paso permite verificar que un archivo PDF contiene un texto específico en cualquiera de sus páginas.

step: verifico que el PDF "{filename}" de la carpeta "{directory}" contiene el texto "{text}"
descripcion: Este paso permite verificar que un PDF en una carpeta específica contiene un texto determinado.

step: verifico que el archivo PDF "{filename}" no contiene el texto "{text}"
descripcion: Este paso permite verificar que un archivo PDF NO contiene un texto específico.

step: verifico que el archivo PDF "{filename}" tiene "{expected_pages}" páginas
descripcion: Este paso permite verificar que un archivo PDF tiene un número exacto de páginas.

step: verifico que la página "{page_number}" del PDF "{filename}" contiene el texto "{text}"
descripcion: Este paso permite verificar que una página específica de un PDF contiene un texto determinado.

step: extraigo el texto de la página "{page_number}" del PDF "{filename}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer el texto completo de una página específica de un PDF y guardarlo en una variable.

step: verifico que el archivo PDF "{filename}" está encriptado
descripcion: Este paso permite verificar que un archivo PDF está protegido con encriptación.

step: verifico que el archivo PDF "{filename}" no está encriptado
descripcion: Este paso permite verificar que un archivo PDF NO está encriptado.

step: verifico que el PDF "{filename}" tiene metadato "{key}" con valor "{value}"
descripcion: Este paso permite verificar que un PDF tiene un metadato específico con el valor esperado.

step: verifico que el PDF "{filename}" contiene texto que coincide con el patrón "{pattern}"
descripcion: Este paso permite verificar que el texto de un PDF coincide con una expresión regular.

---

## --- Rendimiento ---

step: verifico que la página carga en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que el tiempo de carga completa de la página no excede un límite máximo.

step: verifico que el elemento "{element_name}" aparece en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento se vuelve visible dentro de un tiempo máximo.

step: verifico que el tiempo de respuesta del click en elemento "{element_name}" es menor a "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que la respuesta visual después de hacer click en un elemento ocurre dentro del tiempo límite.

step: verifico que las peticiones de red se completan en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que todas las peticiones de red pendientes se completan dentro del tiempo límite.

step: verifico que el tiempo de respuesta del envío de formulario es menor a "{max_seconds}" segundos
descripcion: Este paso permite verificar que el envío de un formulario y su respuesta ocurren dentro del tiempo límite.

step: verifico que los resultados de búsqueda aparecen en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que los resultados de una búsqueda se muestran dentro del tiempo límite.

step: verifico que la imagen "{image_name}" carga en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen se carga completamente dentro del tiempo límite.

step: verifico que la animación se completa en menos de "{max_seconds}" segundos en elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una animación CSS o JavaScript se completa dentro del tiempo límite.

step: verifico que el modal "{modal_name}" se abre en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal se abre y es visible dentro del tiempo límite.

step: verifico que el dropdown "{dropdown_name}" se expande en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un dropdown se expande completamente dentro del tiempo límite.

step: verifico que el rendimiento del scroll de página es suave
descripcion: Este paso permite verificar que el scroll de la página se ejecuta de forma fluida sin jank o stuttering.

step: verifico que el uso de memoria es aceptable después de "{actions_count}" acciones
descripcion: Este paso permite verificar que el uso de memoria del navegador se mantiene en niveles aceptables después de múltiples acciones.

---

## --- Responsive ---

step: verifico que el elemento "{element_name}" es visible en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible cuando el viewport está en tamaño móvil.

step: verifico que el elemento "{element_name}" está oculto en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está oculto cuando el viewport está en tamaño móvil.

step: verifico que el elemento "{element_name}" se adapta a cambios de viewport con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento se adapta correctamente cuando cambia el tamaño del viewport.

step: verifico que el menú de navegación se colapsa en móvil
descripcion: Este paso permite verificar que el menú de navegación se transforma en un menú hamburguesa en viewport móvil.

step: verifico que el texto es legible en tamaño móvil
descripcion: Este paso permite verificar que el tamaño de fuente del texto es legible en viewport móvil (mínimo 12px).

step: verifico que los botones son amigables al tacto en móvil
descripcion: Este paso permite verificar que los botones tienen un tamaño mínimo adecuado para interacción táctil (44x44px).

step: verifico que no hay scroll horizontal
descripcion: Este paso permite verificar que la página no tiene scroll horizontal no deseado en el viewport actual.

step: verifico que las imágenes se escalan apropiadamente en móvil
descripcion: Este paso permite verificar que las imágenes se redimensionan correctamente sin desbordar el viewport móvil.

step: verifico que el elemento "{element_name}" se apila verticalmente en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento cambia a disposición vertical (stack) en viewport móvil.

step: verifico el comportamiento del breakpoint en "{width}" píxeles
descripcion: Este paso permite verificar el comportamiento responsive de la página en un ancho de breakpoint específico.

step: verifico que el elemento "{element_name}" tiene tamaño de fuente responsive con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento ajusta su tamaño de fuente según el viewport.

---

## --- Salesforce ---

step: creo un nuevo registro de Salesforce para el objeto "{object_name}"
descripcion: Este paso permite iniciar la creación de un nuevo registro en Salesforce para un objeto específico.

step: relleno el campo de Salesforce "{field_name}" con "{value}"
descripcion: Este paso permite rellenar un campo en un formulario de Salesforce con un valor específico.

step: selecciono la opción "{option}" del picklist "{field_name}" de Salesforce
descripcion: Este paso permite seleccionar una opción de un campo picklist en Salesforce.

step: busco y selecciono el lookup "{field_name}" de Salesforce con "{search_term}"
descripcion: Este paso permite buscar y seleccionar un valor en un campo lookup de Salesforce.

step: guardo el registro de Salesforce
descripcion: Este paso permite guardar el registro actual en Salesforce haciendo click en el botón Save.

step: verifico que el campo "{field_name}" del registro de Salesforce contiene "{expected_value}"
descripcion: Este paso permite verificar que un campo del registro de Salesforce contiene el valor esperado.

step: hago click en la pestaña "{tab_name}" de Salesforce
descripcion: Este paso permite hacer click en una pestaña específica de la interfaz de Salesforce.

step: edito el registro de Salesforce
descripcion: Este paso permite iniciar la edición del registro actual en Salesforce.

step: busco en la búsqueda global de Salesforce con "{search_term}"
descripcion: Este paso permite realizar una búsqueda global en Salesforce usando un término de búsqueda.

---

## --- Supabase y Vectores ---

step: me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"
descripcion: Este paso permite establecer una conexión con Supabase usando URL y clave de API proporcionadas.

step: me conecto a Supabase usando variables de entorno
descripcion: Este paso permite establecer una conexión con Supabase usando las variables de entorno SUPABASE_URL y SUPABASE_KEY.

step: busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"
descripcion: Este paso permite buscar el registro más similar semánticamente a una consulta en una tabla de Supabase con vectores.

step: busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"
descripcion: Este paso permite buscar los N registros más similares a una consulta en una tabla de Supabase con vectores.

step: cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"
descripcion: Este paso permite cargar contexto relevante desde Supabase directamente en un contexto de Gemini para evaluación.

step: consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"
descripcion: Este paso permite consultar todos los registros de una tabla en Supabase y guardar el resultado.

step: consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"
descripcion: Este paso permite consultar una tabla en Supabase con un filtro de igualdad y guardar el resultado.

---

## --- Tablas ---

step: verifico que la tabla "{table_name}" tiene "{expected_rows}" filas con identificador "{identifier}"
descripcion: Este paso permite verificar que una tabla HTML tiene un número exacto de filas de datos.

step: verifico que la tabla "{table_name}" tiene "{expected_columns}" columnas con identificador "{identifier}"
descripcion: Este paso permite verificar que una tabla HTML tiene un número exacto de columnas.

step: hago click en la celda de la fila "{row}" columna "{column}" de la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer click en una celda específica de una tabla identificada por fila y columna.

step: verifico que la celda de la fila "{row}" columna "{column}" contiene "{expected_text}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una celda específica de una tabla contiene el texto esperado.

step: ordeno la tabla "{table_name}" por la columna "{column_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer click en el header de una columna para ordenar la tabla.

step: filtro la tabla "{table_name}" por la columna "{column_name}" con valor "{filter_value}" con identificador "{identifier}"
descripcion: Este paso permite filtrar los datos de una tabla por el valor de una columna específica.

step: selecciono la fila "{row_number}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una fila específica de una tabla haciendo click en ella.

step: verifico que la fila "{row_number}" de la tabla "{table_name}" está seleccionada con identificador "{identifier}"
descripcion: Este paso permite verificar que una fila específica de la tabla está actualmente seleccionada.

step: verifico que la fila "{row_number}" de la tabla "{table_name}" tiene los siguientes datos con identificador "{identifier}"
descripcion: Este paso permite verificar que una fila de la tabla contiene los datos esperados proporcionados en una tabla de datos.

step: verifico que el header de la tabla "{table_name}" tiene las siguientes columnas con identificador "{identifier}"
descripcion: Este paso permite verificar que el encabezado de la tabla contiene las columnas esperadas.

step: verifico que la fila "{row_number}" de la tabla "{table_name}" tiene datos con formato con identificador "{identifier}"
descripcion: Este paso permite verificar que los datos de una fila tienen el formato esperado según patrones definidos.

step: edito la celda de la fila "{row}" columna "{column}" con valor "{new_value}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite editar el contenido de una celda específica de una tabla.

---

## --- Teclado y Mouse ---

step: hago scroll con la rueda del mouse "{direction}" por "{steps}" pasos
descripcion: Este paso permite simular el scroll con la rueda del mouse en una dirección específica por un número de pasos.

step: presiono la tecla de flecha "{direction}"
descripcion: Este paso permite simular la pulsación de una tecla de flecha (up, down, left, right).

---

## --- Timing y Cronómetros ---

step: espero hasta que haya en total {count_text} elementos "{selector}"
descripcion: Este paso permite esperar hasta que exista un número específico de elementos que coincidan con un selector.

step: verifico que el cronómetro "{timer_name}" no exceda {max_seconds:d} segundos
descripcion: Este paso permite verificar que un cronómetro previamente iniciado no ha excedido un tiempo máximo.

step: espero progresivamente: {wait_pattern}
descripcion: Este paso permite realizar esperas progresivas con un patrón configurable de tiempos incrementales.

---

## --- Validación de Combobox ---

step: verifico que el combobox "{element_name}" contiene exactamente "{expected_options}" opciones con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox contiene exactamente las opciones listadas, en el orden especificado.

step: verifico que el combobox "{element_name}" tiene "{expected_count}" opciones con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene un número exacto de opciones disponibles.

step: verifico que la primera opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que la primera opción de un combobox es la esperada.

step: verifico que la última opción del combobox "{element_name}" es "{expected_option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que la última opción de un combobox es la esperada.

step: verifico que las opciones del combobox "{element_name}" están ordenadas alfabéticamente con identificador "{identifier}"
descripcion: Este paso permite verificar que las opciones de un combobox están en orden alfabético.

step: verifico que el combobox "{element_name}" no tiene opciones duplicadas con identificador "{identifier}"
descripcion: Este paso permite verificar que no hay opciones repetidas en un combobox.

step: verifico que el combobox "{element_name}" contiene la opción "{expected_option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una opción específica existe en la lista del combobox.

step: verifico que el combobox "{element_name}" no contiene la opción "{unexpected_option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una opción específica NO existe en la lista del combobox.

step: verifico que la selección por defecto del combobox "{element_name}" es "{expected_selection}" con identificador "{identifier}"
descripcion: Este paso permite verificar cuál es la opción seleccionada por defecto en un combobox.

step: verifico que el combobox "{element_name}" permite selección múltiple con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene el atributo multiple habilitado.

step: verifico que el combobox "{element_name}" no permite selección múltiple con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox NO tiene el atributo multiple.

step: verifico que el combobox "{element_name}" es campo requerido con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene el atributo required.

step: verifico que el placeholder del combobox "{element_name}" es "{expected_placeholder}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el placeholder de un combobox coincide con el texto esperado.

step: verifico que las opciones del combobox "{element_name}" contienen los valores "{expected_values}" con identificador "{identifier}"
descripcion: Este paso permite verificar que las opciones del combobox incluyen todos los valores esperados.

step: verifico que el combobox "{element_name}" se puede filtrar escribiendo "{filter_text}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox soporta filtrado por texto y muestra opciones filtradas.

---

## --- Validación JSON de API ---

step: verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"
descripcion: Este paso permite verificar que la respuesta JSON cumple con un esquema JSON Schema Draft 7 definido en un archivo.

step: verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"
descripcion: Este paso permite verificar que la respuesta JSON es exactamente igual al contenido de un archivo esperado.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden
descripcion: Este paso permite verificar que la respuesta JSON coincide con un archivo esperado sin considerar el orden de arrays.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"
descripcion: Este paso permite verificar que la respuesta JSON coincide con un archivo esperado excluyendo campos específicos.

step: verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"
descripcion: Este paso permite verificar que un campo del JSON tiene un tipo de dato específico (string, number, boolean, array, object, null).

step: verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"
descripcion: Este paso permite verificar que un campo del JSON coincide con una expresión regular.

step: verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}
descripcion: Este paso permite verificar que un campo numérico del JSON está dentro de un rango específico.

step: verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"
descripcion: Este paso permite verificar que un array del JSON contiene al menos un elemento con un campo y valor específicos.

step: verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"
descripcion: Este paso permite verificar que todos los elementos de un array JSON tienen un campo específico presente.

step: verifico que el JSON de respuesta API no tiene valores nulos
descripcion: Este paso permite verificar que la respuesta JSON no contiene ningún valor null en toda su estructura.

step: guardo el JSON de respuesta API en el archivo "{file_path}"
descripcion: Este paso permite guardar la respuesta JSON formateada en un archivo para análisis posterior.

step: cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"
descripcion: Este paso permite cargar un JSON desde un archivo y enviarlo como cuerpo de una petición POST.

---

## --- Validación Semántica ---

step: establezco el umbral de similitud semántica en {threshold:f}
descripcion: Este paso permite configurar el umbral mínimo de similitud para las comparaciones semánticas posteriores.

step: el texto "{actual_text}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que dos textos son semánticamente similares usando modelos de embeddings.

step: el texto de la variable "{var_name}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que el texto almacenado en una variable es semánticamente similar a un texto esperado.

step: el texto del elemento "{element_name}" con identificador "{locator}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que el texto de un elemento web es semánticamente similar a un texto esperado.

---

## --- Validaciones Avanzadas ---

step: deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible en la página usando expect de Playwright.

step: no deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento no es visible en la página.

step: deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento existe en el DOM aunque no sea visible.

step: no deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento no existe en el DOM.

step: verifico que el elemento "{element_name}" tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una clase CSS específica asignada.

step: verifico que el elemento "{element_name}" no tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO tiene una clase CSS específica.

step: verifico que el elemento "{element_name}" tiene el atributo "{attribute}" con valor "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un atributo HTML con un valor exacto.

step: verifico que el atributo "{attribute}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el valor de un atributo coincide con una expresión regular.

step: verifico que el texto del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento coincide con una expresión regular.

step: verifico que el texto del elemento "{element_name}" tiene formato de email válido con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene formato de dirección de email válida.

step: verifico que el texto del elemento "{element_name}" tiene formato de teléfono válido con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene formato de número de teléfono válido.

step: verifico que el texto del elemento "{element_name}" tiene formato de fecha válido "{date_format}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene un formato de fecha válido según el patrón especificado.

step: verifico que el texto del elemento "{element_name}" es numérico con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento contiene solo caracteres numéricos.

step: verifico que la longitud del texto del elemento "{element_name}" es "{expected_length}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene una longitud exacta de caracteres.

step: verifico que la longitud del texto del elemento "{element_name}" está entre "{min_length}" y "{max_length}" con identificador "{identifier}"
descripcion: Este paso permite verificar que la longitud del texto de un elemento está dentro de un rango.

step: verifico que el elemento "{element_name}" está dentro del viewport con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible dentro del área visible del navegador.

step: verifico que el elemento "{element_name}" tiene el foco con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el foco del teclado actualmente.

step: verifico que el color de fondo del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el color de fondo de un elemento coincide con el valor CSS esperado.

step: verifico que el color del texto del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el color del texto de un elemento coincide con el valor CSS esperado.

step: verifico que el tamaño de fuente del elemento "{element_name}" es "{expected_size}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el tamaño de fuente de un elemento coincide con el valor esperado.

step: verifico que el ancho del elemento "{element_name}" es "{expected_width}" píxeles con identificador "{identifier}"
descripcion: Este paso permite verificar que el ancho de un elemento en píxeles coincide con el valor esperado.

step: verifico que la altura del elemento "{element_name}" es "{expected_height}" píxeles con identificador "{identifier}"
descripcion: Este paso permite verificar que la altura de un elemento en píxeles coincide con el valor esperado.

step: verifico que el elemento "{element_name}" está posicionado en x="{expected_x}" y="{expected_y}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está en coordenadas específicas de la página.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" es "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una propiedad CSS computada de un elemento tiene el valor exacto esperado.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" contiene "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una propiedad CSS de un elemento contiene un valor parcial.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" no existe con identificador "{identifier}"
descripcion: Este paso permite verificar que una propiedad CSS no está definida para un elemento.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una propiedad CSS coincide con una expresión regular.

step: verifico que el elemento "{element_name}" tiene la propiedad CSS "{property}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una propiedad CSS definida con algún valor.

step: verifico que el elemento "{element_name}" no tiene la propiedad CSS "{property}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento no tiene una propiedad CSS específica definida.

---

## --- Variables ---

step: verifico que la variable "{variable_name}" contiene "{expected_value}"
descripcion: Este paso permite verificar que una variable del contexto contiene un valor específico como subcadena.

step: verifico que la variable "{variable_name}" es igual a "{expected_value}"
descripcion: Este paso permite verificar que una variable del contexto es exactamente igual al valor esperado.

---

## --- Variables de Entorno ---

step: obtengo variable de entorno "{var_name}" y la guardo en variable "{variable_name}"
descripcion: Este paso permite obtener el valor de una variable de entorno del sistema y guardarlo en una variable del contexto.

step: verifico que existe la variable de entorno "{var_name}"
descripcion: Este paso permite verificar que una variable de entorno específica está definida en el sistema.

step: verifico que la variable de entorno "{var_name}" es igual a "{expected_value}"
descripcion: Este paso permite verificar que una variable de entorno tiene exactamente el valor esperado.

step: navego a la URL de entorno "{env_var_name}"
descripcion: Este paso permite navegar a la URL almacenada en una variable de entorno.

step: relleno el campo "{field_name}" con la variable de entorno "{env_var_name}" usando identificador "{identifier}"
descripcion: Este paso permite rellenar un campo de formulario con el valor de una variable de entorno.

step: uso credenciales de entorno para login con usuario "{username_var}" y contraseña "{password_var}"
descripcion: Este paso permite realizar login usando credenciales almacenadas en variables de entorno.

step: hago click en el botón de login
descripcion: Este paso permite hacer click en el botón de login del formulario de autenticación.

step: restauro la variable de entorno "{var_name}" desde el backup "{backup_name}"
descripcion: Este paso permite restaurar una variable de entorno desde un backup previamente guardado.

---

## --- Ventanas y Alertas ---

step: cambio a la nueva ventana
descripcion: Este paso permite cambiar el contexto del navegador a la ventana o pestaña más recientemente abierta.

step: cambio a la ventana con título "{title}"
descripcion: Este paso permite cambiar a una ventana específica identificada por su título.

step: cambio a la ventana con url que contiene "{url_part}"
descripcion: Este paso permite cambiar a una ventana cuya URL contiene un texto parcial específico.

step: el mensaje de la alerta debería ser "{expected_text}"
descripcion: Este paso permite verificar que el mensaje de una alerta del navegador es exactamente igual al texto esperado.

step: el mensaje de la alerta debería contener "{expected_text}"
descripcion: Este paso permite verificar que el mensaje de una alerta del navegador contiene un texto específico.

step: extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo
descripcion: Este paso permite capturar el texto de un diálogo del navegador, guardarlo en una variable y cerrar el diálogo.

---



---

## --- Validaciones de Escritorio (Desktop Steps) ---

step: deberia ver la imagen "{image_name}" en pantalla
descripcion: Verifica que una imagen de referencia este visible en pantalla. Falla si no la encuentra con la confianza por defecto (0.85).

step: no deberia ver la imagen "{image_name}" en pantalla
descripcion: Verifica que una imagen de referencia NO este visible en pantalla. Falla si la encuentra.

step: verifico con confianza "{confidence}" que la imagen "{image_name}" es visible
descripcion: Verifica que una imagen este visible con nivel de confianza personalizado entre 0.0 y 1.0. Usar cuando la imagen tiene variaciones visuales menores.

step: verifico que el tamano de pantalla es "{width}" por "{height}"
descripcion: Verifica que la resolucion de pantalla sea exactamente la indicada. Util para garantizar condiciones de ejecucion consistentes.

step: deberia ver que el portapapeles contiene "{expected_text}"
descripcion: Verifica que el portapapeles del sistema contiene el texto esperado (busqueda parcial, sin distinguir mayusculas).

step: deberia ver el texto "{expected_text}" en el escritorio usando OCR
descripcion: Toma screenshot del escritorio y verifica que el texto esperado este presente via OCR. Util para apps sin accesibilidad.

step: no deberia ver el texto "{unexpected_text}" en el escritorio usando OCR
descripcion: Toma screenshot del escritorio y verifica que el texto NO este presente via OCR.

step: espero a que aparezca la imagen "{image_name}"
descripcion: Espera y verifica que una imagen aparezca en pantalla dentro del timeout por defecto (10s). Falla si no aparece.

step: espero con timeout "{timeout}" segundos a que aparezca la imagen "{image_name}"
descripcion: Espera y verifica que una imagen aparezca con timeout personalizado. Falla si no aparece en el tiempo indicado.

step: espero a que desaparezca la imagen "{image_name}"
descripcion: Espera y verifica que una imagen desaparezca de pantalla. Util para confirmar que un dialogo o spinner se cerro.

step: espero con timeout "{timeout}" segundos a que desaparezca la imagen "{image_name}"
descripcion: Espera y verifica que una imagen desaparezca con timeout personalizado.

step: el texto leido en la variable "{variable_name}" deberia contener "{expected_text}"
descripcion: Verifica que el texto guardado en una variable (leido con OCR o portapapeles) contiene el texto esperado. Busqueda parcial sin distinguir mayusculas.

step: el texto leido en la variable "{variable_name}" deberia ser exactamente "{expected_text}"
descripcion: Verifica que el texto guardado en una variable es exactamente igual al esperado (con trim). Util para validar valores numericos, codigos o textos precisos.

---

## --- Validaciones Mobile (Appium Steps) ---

step: verifico que el elemento móvil "{locator}" es visible
descripcion: Verifica que un elemento sea visible en la pantalla del dispositivo.

step: verifico que el elemento móvil "{locator}" no es visible
descripcion: Verifica que un elemento NO sea visible.

step: verifico que el elemento móvil "{locator}" existe
descripcion: Verifica que un elemento exista en el DOM del dispositivo.

step: verifico que el elemento móvil "{locator}" no existe
descripcion: Verifica que un elemento NO exista en el DOM.

step: verifico que el elemento móvil "{locator}" está habilitado
descripcion: Verifica que un elemento esté habilitado para interacción.

step: verifico que el elemento móvil "{locator}" está deshabilitado
descripcion: Verifica que un elemento esté deshabilitado.

step: verifico que el elemento móvil "{locator}" está seleccionado
descripcion: Verifica que un checkbox o radio esté seleccionado.

step: verifico que el elemento móvil "{locator}" no está seleccionado
descripcion: Verifica que un checkbox o radio NO esté seleccionado.

step: verifico que el texto del elemento móvil "{locator}" es "{expected}"
descripcion: Verifica que el texto de un elemento sea exactamente el esperado.

step: verifico que el texto del elemento móvil "{locator}" contiene "{expected}"
descripcion: Verifica que el texto contenga un substring.

step: verifico que el texto del elemento móvil "{locator}" no contiene "{unexpected}"
descripcion: Verifica que el texto NO contenga un substring.

step: verifico que el texto del elemento móvil "{locator}" no está vacío
descripcion: Verifica que el texto no esté vacío.

step: verifico que el atributo "{attr}" del elemento móvil "{locator}" es "{expected}"
descripcion: Verifica el valor exacto de un atributo.

step: verifico que el atributo "{attr}" del elemento móvil "{locator}" contiene "{expected}"
descripcion: Verifica que un atributo contenga un valor.

step: verifico que hay "{count}" elementos móviles "{locator}"
descripcion: Verifica la cantidad exacta de elementos.

step: verifico que hay al menos "{count}" elementos móviles "{locator}"
descripcion: Verifica que haya al menos N elementos.

step: verifico que la orientación del dispositivo es "{orientation}"
descripcion: Verifica la orientación actual (PORTRAIT o LANDSCAPE).

step: verifico que el texto de la alerta del dispositivo es "{expected}"
descripcion: Verifica el texto exacto de una alerta nativa.

step: verifico que el texto de la alerta del dispositivo contiene "{expected}"
descripcion: Verifica que la alerta contenga un texto.

step: verifico que el contexto actual del dispositivo es "{expected}"
descripcion: Verifica el contexto actual (NATIVE_APP o WEBVIEW).

step: verifico que hay contextos webview disponibles en el dispositivo
descripcion: Verifica que haya al menos un contexto WebView.

step: verifico que el contexto actual del dispositivo es nativo
descripcion: Verifica que el contexto sea NATIVE_APP.
