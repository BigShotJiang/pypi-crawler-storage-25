﻿# language: es
# ==============================================================================
# Ejemplo Completo de Automatizacion de Escritorio
# Todos los steps usan los nombres EXACTOS definidos en desktop_steps.py v1.3.107+
#
# REGLA DE MODOS:
#   - Prueba pura desktop (@no_browser): no necesitas declarar nada
#   - Prueba pura web: no necesitas declarar nada
#   - Prueba pura API: no necesitas declarar nada
#   - Prueba MIXTA: usa "uso el modo desktop/web/api" para cambiar entre modos
#
# RUTAS: usar forward slashes  C:/Program Files/App/app.exe
# IMAGENES: colocar en desktop_images/subcarpeta/nombre.png
#           usar como "subcarpeta/nombre" en el step
# ==============================================================================

# ==============================================================================
# FEATURE 1 - PRUEBA PURA DE ESCRITORIO
# ==============================================================================

@desktop
Caracteristica: Automatizacion de Aplicaciones de Escritorio

  # ============================================================================
  # ESCENARIO 1: Abrir y verificar aplicacion
  # lanzo y espero "{seconds}" segundos la aplicacion "{app_path}"
  # abro la aplicacion "{app_path}"  (espera 2s por defecto)
  # cierro la aplicacion "{process_name}"  (acepta nombre o ruta completa)
  # ============================================================================

  @desktop @no_browser
  Escenario: Abrir la Calculadora de Windows y verificar que esta lista
    Dado que lanzo y espero "2" segundos la aplicacion "calc.exe"
    Y capturo el escritorio con nombre "calculadora_abierta"

    Entonces deberia ver la imagen "calculadora/pantalla" en pantalla
    Y deberia ver la imagen "calculadora/boton_0" en pantalla

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 2: Clicks por imagen de referencia
  # hago click en la imagen "{image_name}"
  # hago doble click en la imagen "{image_name}"
  # hago click derecho en la imagen "{image_name}"
  # paso el mouse sobre la imagen "{image_name}"
  # hago click con confianza "{confidence}" en la imagen "{image_name}"
  # hago click con desplazamiento "{offset_x}" "{offset_y}" en la imagen "{image_name}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Realizar una suma en la Calculadora usando imagenes de referencia
    Dado que lanzo y espero "2" segundos la aplicacion "calc.exe"
    Y tomo una captura antes de la accion "suma"

    Cuando hago click en la imagen "calculadora/boton_1"
    Y hago click en la imagen "calculadora/boton_2"
    Y hago click en la imagen "calculadora/boton_5"
    Y hago click en la imagen "calculadora/boton_mas"
    Y hago click en la imagen "calculadora/boton_7"
    Y hago click en la imagen "calculadora/boton_5"
    Y hago click en la imagen "calculadora/boton_igual"

    Y tomo una captura despues de la accion "suma"

    Entonces deberia ver el texto "200" en el escritorio usando OCR
    Y capturo el escritorio con nombre "resultado_suma_200"

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 3: Clicks por coordenadas absolutas
  # hago click en las coordenadas "{x}" "{y}"
  # hago doble click en las coordenadas "{x}" "{y}"
  # hago click derecho en las coordenadas "{x}" "{y}"
  # muevo el mouse a las coordenadas "{x}" "{y}"
  # establezco la pausa entre acciones en "{seconds}" segundos
  # ============================================================================

  @desktop @no_browser
  Escenario: Realizar una multiplicacion usando coordenadas de pantalla
    Dado que lanzo y espero "2" segundos la aplicacion "calc.exe"
    Y establezco la pausa entre acciones en "0.2" segundos

    Cuando hago click en las coordenadas "320" "450"
    Y hago click en las coordenadas "270" "400"
    Y hago click en las coordenadas "370" "450"
    Y hago click en las coordenadas "320" "500"
    Y hago click en las coordenadas "420" "550"

    Entonces capturo el escritorio y extraigo texto en la variable "resultado_calc"
    Y deberia ver el texto "96" en el escritorio usando OCR

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 4: Escritura de texto y atajos de teclado
  # escribo el texto "{text}"                    (caracter a caracter)
  # pego el texto "{text}" usando el portapapeles (via Ctrl+V, soporta tildes)
  # limpio el campo y escribo "{text}"            (Ctrl+A + Delete + escribir)
  # escribo en la imagen "{image_name}" el texto "{text}"
  # escribo en las coordenadas "{x}" "{y}" el texto "{text}"
  # presiono en escritorio la tecla "{key}"       (enter, tab, escape, f5, etc.)
  # presiono en escritorio las teclas "{k1}" y "{k2}"
  # presiono en escritorio las teclas "{k1}" mas "{k2}" mas "{k3}"
  # presiono Enter en escritorio
  # presiono Tab en escritorio
  # presiono Escape en escritorio
  # presiono el atajo de escritorio guardar/copiar/pegar/deshacer/seleccionar todo
  # ============================================================================

  @desktop @no_browser
  Escenario: Llenar y guardar un documento en el Bloc de Notas
    Dado que lanzo y espero "1" segundos la aplicacion "notepad.exe"
    Y capturo el escritorio con nombre "notepad_abierto"

    # pego el texto usa portapapeles: soporta tildes, enie, caracteres especiales
    Cuando pego el texto "Informe de Pruebas Automatizadas" usando el portapapeles
    Y presiono Enter en escritorio
    Y presiono Enter en escritorio
    Y pego el texto "Fecha: 2024-01-15" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Estado: Completado" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Resultado: EXITOSO" usando el portapapeles

    Y capturo el escritorio con nombre "notepad_contenido"

    Entonces deberia ver el texto "Informe de Pruebas" en el escritorio usando OCR
    Y deberia ver el texto "EXITOSO" en el escritorio usando OCR

    # Guardar con Ctrl+S
    Cuando presiono el atajo de escritorio guardar
    Y espero "1" segundos en escritorio

    Y espero con timeout "3" segundos a que aparezca la imagen "notepad/dialogo_guardar"
    Y escribo en la imagen "notepad/campo_nombre_archivo" el texto "reporte_prueba"
    Y presiono Enter en escritorio

    Y capturo el escritorio con nombre "notepad_guardado"
    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 5: Portapapeles y lectura de texto
  # copio el texto "{text}" al portapapeles
  # obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"
  # copio el texto seleccionado y lo guardo en la variable "{variable_name}"
  # deberia ver que el portapapeles contiene "{expected_text}"
  # presiono el atajo de escritorio seleccionar todo / copiar
  # ============================================================================

  @desktop @no_browser
  Escenario: Navegar por una aplicacion usando solo el teclado
    Dado que lanzo y espero "1" segundos la aplicacion "notepad.exe"

    Cuando pego el texto "Primera linea de texto para prueba de teclado" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Segunda linea con mas contenido de ejemplo" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Tercera linea final del documento de prueba" usando el portapapeles

    Y presiono el atajo de escritorio seleccionar todo
    Y presiono el atajo de escritorio copiar

    Entonces deberia ver que el portapapeles contiene "Primera linea"
    Y deberia ver que el portapapeles contiene "Segunda linea"

    Cuando obtengo el contenido del portapapeles y lo guardo en la variable "contenido_documento"

    Y presiono el atajo de escritorio deshacer
    Y presiono el atajo de escritorio deshacer

    Y capturo el escritorio con nombre "navegacion_teclado"
    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 6: Scroll
  # hago scroll hacia arriba "{clicks}" veces
  # hago scroll hacia abajo "{clicks}" veces
  # hago scroll arriba "{clicks}" veces en la posicion "{x}" "{y}"
  # hago scroll abajo "{clicks}" veces en la posicion "{x}" "{y}"
  # hago scroll arriba "{clicks}" veces sobre la imagen "{image_name}"
  # hago scroll abajo "{clicks}" veces sobre la imagen "{image_name}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Hacer scroll en una aplicacion de escritorio
    Dado que lanzo y espero "1" segundos la aplicacion "notepad.exe"

    Cuando pego el texto "Linea 1 - Contenido de prueba para scroll" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Linea 2 - Mas contenido para generar scroll" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Linea 3 - Continuando con el contenido" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Linea 4 - Penultima linea del documento" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Linea 5 - Ultima linea visible del documento" usando el portapapeles

    Y hago scroll hacia arriba "5" veces
    Y capturo el escritorio con nombre "scroll_arriba"

    Y hago scroll hacia abajo "5" veces
    Y capturo el escritorio con nombre "scroll_abajo"

    Y hago scroll arriba "3" veces sobre la imagen "notepad/area_texto"

    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 7: Drag and Drop
  # arrastro la imagen "{source_image}" hacia la imagen "{target_image}"
  # arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"
  # arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Arrastrar y soltar elementos en una aplicacion
    Dado que lanzo y espero "3" segundos la aplicacion "${ENV.APP_CON_DRAG_DROP}"
    Y tomo una captura antes de la accion "drag_drop"

    Cuando arrastro la imagen "app/elemento_origen" hacia la imagen "app/zona_destino"
    Y espero "1" segundos en escritorio
    Y tomo una captura despues de la accion "drag_drop"

    Entonces deberia ver la imagen "app/elemento_en_destino" en pantalla
    Y no deberia ver la imagen "app/elemento_origen" en pantalla

    Cuando arrastro desde las coordenadas "200" "300" hasta las coordenadas "600" "300"
    Y capturo el escritorio con nombre "drag_coordenadas"

    Y cierro la aplicacion "${ENV.APP_CON_DRAG_DROP}"


  # ============================================================================
  # ESCENARIO 8: Esperas inteligentes por imagen
  # espero a que aparezca la imagen "{image_name}"
  # espero con timeout "{timeout}" segundos a que aparezca la imagen "{image_name}"
  # espero a que desaparezca la imagen "{image_name}"
  # espero con timeout "{timeout}" segundos a que desaparezca la imagen "{image_name}"
  # espero "{seconds}" segundos en escritorio
  # ============================================================================

  @desktop @no_browser
  Escenario: Esperar que cargue una aplicacion pesada y verificar elementos
    Dado que lanzo y espero "1" segundos la aplicacion "${ENV.APP_PESADA}"

    Y espero con timeout "5" segundos a que aparezca la imagen "app/splash_screen"
    Y espero con timeout "30" segundos a que desaparezca la imagen "app/splash_screen"
    Y espero con timeout "10" segundos a que aparezca la imagen "app/pantalla_principal"
    Y capturo el escritorio con nombre "app_cargada"

    Entonces deberia ver la imagen "app/menu_archivo" en pantalla
    Y deberia ver la imagen "app/barra_herramientas" en pantalla

    Y cierro la aplicacion "${ENV.APP_PESADA}"


  # ============================================================================
  # ESCENARIO 9: OCR - leer texto de pantalla
  # capturo el escritorio y extraigo texto en la variable "{variable_name}"
  # capturo la region "{x}" "{y}" "{width}" "{height}" y extraigo texto en la variable "{variable_name}"
  # deberia ver el texto "{text}" en el escritorio usando OCR
  # no deberia ver el texto "{text}" en el escritorio usando OCR
  # ============================================================================

  @desktop @no_browser
  Escenario: Leer datos de campos especificos usando OCR por region
    Dado que lanzo y espero "3" segundos la aplicacion "${ENV.APP_LEGACY}"
    Y capturo el escritorio con nombre "app_legacy_inicial"

    Cuando hago click en la imagen "legacy/menu_consultas"
    Y espero a que aparezca la imagen "legacy/formulario_consulta"
    Y escribo en la imagen "legacy/campo_codigo" el texto "CLI-001"
    Y presiono Enter en escritorio
    Y espero "2" segundos en escritorio

    # Leer campos por region (x, y, ancho, alto en pixeles)
    Y capturo la region "100" "200" "300" "30" y extraigo texto en la variable "nombre_cliente"
    Y capturo la region "100" "240" "300" "30" y extraigo texto en la variable "rut_cliente"

    Entonces deberia ver el texto "CLI-001" en el escritorio usando OCR
    Y no deberia ver el texto "ERROR" en el escritorio usando OCR

    Y capturo el escritorio con nombre "datos_cliente_leidos"
    Y cierro la aplicacion "${ENV.APP_LEGACY}"


  # ============================================================================
  # ESCENARIO 10: Verificaciones visuales con confianza
  # deberia ver la imagen "{image_name}" en pantalla
  # no deberia ver la imagen "{image_name}" en pantalla
  # verifico con confianza "{confidence}" que la imagen "{image_name}" es visible
  # cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"
  # guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"
  # verifico que el tamano de pantalla es "{width}" por "{height}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Verificar elementos con diferentes niveles de confianza
    Dado que lanzo y espero "2" segundos la aplicacion "calc.exe"

    Entonces deberia ver la imagen "calculadora/boton_igual" en pantalla
    Y verifico con confianza "0.95" que la imagen "calculadora/boton_igual" es visible
    Y verifico con confianza "0.75" que la imagen "calculadora/display" es visible

    Cuando cuento las ocurrencias de la imagen "calculadora/boton_numerico" y las guardo en la variable "total_botones"
    Y guardo la ubicacion de la imagen "calculadora/boton_igual" en la variable "pos_boton_igual"

    Y capturo el escritorio con nombre "verificaciones_confianza"
    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 11: Configuracion del motor de busqueda
  # establezco la confianza de busqueda de imagenes en "{confidence}"
  # establezco el timeout de busqueda de imagenes en "{seconds}" segundos
  # establezco la pausa entre acciones en "{seconds}" segundos
  # guardo el tamano de pantalla en la variable "{variable_name}"
  # guardo la posicion del mouse en la variable "{variable_name}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Ajustar configuracion de busqueda segun condiciones del entorno
    Dado que establezco la confianza de busqueda de imagenes en "0.80"
    Y establezco el timeout de busqueda de imagenes en "15" segundos
    Y establezco la pausa entre acciones en "0.5" segundos

    Y guardo el tamano de pantalla en la variable "resolucion_pantalla"
    Y guardo la posicion del mouse en la variable "posicion_inicial_mouse"

    Cuando lanzo y espero "2" segundos la aplicacion "calc.exe"

    Entonces deberia ver la imagen "calculadora/pantalla" en pantalla
    Y capturo el escritorio con nombre "entorno_configurado"

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 12: Lectura de texto - OCR pantalla completa y por region
  # leo el texto de la pantalla y lo guardo en la variable "{variable_name}"
  # leo el texto de la pantalla con confianza minima "{confidence}" y lo guardo en la variable "{variable_name}"
  # leo el texto de la region "{x}" "{y}" "{width}" "{height}" y lo guardo en la variable "{variable_name}"
  # el texto leido en la variable "{variable_name}" deberia contener "{expected_text}"
  # el texto leido en la variable "{variable_name}" deberia ser exactamente "{expected_text}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Leer texto de pantalla completa y por region con OCR
    Dado que lanzo y espero "3" segundos la aplicacion "${ENV.APP_LEGACY}"

    Cuando leo el texto de la pantalla y lo guardo en la variable "texto_completo"
    Entonces el texto leido en la variable "texto_completo" deberia contener "Bienvenido"

    Cuando leo el texto de la region "100" "200" "300" "30" y lo guardo en la variable "nombre_usuario"
    Entonces el texto leido en la variable "nombre_usuario" deberia contener "Admin"

    Cuando leo el texto de la pantalla con confianza minima "75" y lo guardo en la variable "texto_confiable"
    Entonces el texto leido en la variable "texto_confiable" deberia contener "Sistema"

    Y cierro la aplicacion "${ENV.APP_LEGACY}"


  # ============================================================================
  # ESCENARIO 13: Lectura de texto - portapapeles
  # leo el campo imagen "{image_name}" y guardo el texto en la variable "{variable_name}"
  # leo el campo en las coordenadas "{x}" "{y}" y guardo el texto en la variable "{variable_name}"
  # selecciono todo y leo el texto del campo activo y lo guardo en la variable "{variable_name}"
  # copio y leo el texto seleccionado y lo guardo en la variable "{variable_name}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Leer contenido de campos de texto usando portapapeles
    Dado que lanzo y espero "2" segundos la aplicacion "notepad.exe"

    Cuando pego el texto "Valor de prueba: 12345" usando el portapapeles
    Y presiono Enter en escritorio
    Y pego el texto "Estado: Activo" usando el portapapeles

    # Click en campo por imagen, selecciona todo (Ctrl+A) y copia (Ctrl+C)
    Cuando leo el campo imagen "notepad/area_texto" y guardo el texto en la variable "contenido_campo"
    Entonces el texto leido en la variable "contenido_campo" deberia contener "12345"
    Y el texto leido en la variable "contenido_campo" deberia contener "Activo"

    # Click en coordenadas y lee el campo
    Cuando leo el campo en las coordenadas "400" "300" y guardo el texto en la variable "texto_coords"
    Entonces el texto leido en la variable "texto_coords" deberia contener "Valor de prueba"

    # Lee el campo que ya tiene el foco (sin click previo)
    Cuando selecciono todo y leo el texto del campo activo y lo guardo en la variable "campo_activo"
    Entonces el texto leido en la variable "campo_activo" deberia contener "Estado"

    # Seleccion manual previa + copiar
    Y presiono el atajo de escritorio seleccionar todo
    Y copio y leo el texto seleccionado y lo guardo en la variable "texto_manual"
    Entonces el texto leido en la variable "texto_manual" deberia ser exactamente "Valor de prueba: 12345\nEstado: Activo"

    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 14: Screenshots para reporte
  # tomo una captura del escritorio
  # capturo el escritorio con nombre "{name}"
  # tomo una captura antes de la accion "{action_name}"
  # tomo una captura despues de la accion "{action_name}"
  # tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"
  # ============================================================================

  @desktop @no_browser
  Escenario: Documentar flujo con capturas en cada paso critico
    Dado que lanzo y espero "2" segundos la aplicacion "notepad.exe"
    Y tomo una captura del escritorio

    Cuando tomo una captura antes de la accion "escribir_contenido"
    Y pego el texto "Contenido de prueba" usando el portapapeles
    Y tomo una captura despues de la accion "escribir_contenido"

    Y tomo una captura de la region "0" "0" "400" "200" con nombre "region_superior"
    Y capturo el escritorio con nombre "estado_final"

    Y cierro la aplicacion "notepad.exe"


# ==============================================================================
# FEATURE 2 - PRUEBA MIXTA (web + desktop + api)
# Solo en pruebas mixtas se necesita declarar el modo
# uso el modo desktop / uso el modo web / uso el modo api
# ==============================================================================

Caracteristica: Prueba Mixta Web Desktop y API

  # ============================================================================
  # ESCENARIO 15: Web + Desktop
  # uso el modo desktop  → capturas con PyAutoGUI
  # uso el modo web      → capturas con Playwright
  # cambio a la aplicacion de escritorio "{app_path}" desde la prueba web
  # vuelvo al navegador web despues de la interaccion con escritorio
  # capturo el escritorio y vuelvo al navegador con nombre "{name}"
  # traigo la ventana "{window_title}" al frente
  # ============================================================================

  Escenario: Descargar reporte desde web y verificar en app de escritorio
    # --- PARTE WEB (capturas Playwright automaticas) ---
    Dado que navego a "${ENV.BASE_URL}/reportes"
    Y espero que el elemento con css ".reports-table" sea visible
    Y tomo una captura de pantalla con nombre "web_lista_reportes"

    Cuando hago click en el elemento "descargar_reporte" con identificador "#btn-download-excel"
    Y espero "3" segundos

    Entonces verifico que el elemento con css ".download-success" es visible

    # --- CAMBIO A DESKTOP (capturas PyAutoGUI automaticas) ---
    Cuando uso el modo desktop
    Y cambio a la aplicacion de escritorio "C:/Program Files/Microsoft Office/root/Office16/EXCEL.EXE" desde la prueba web
    Y espero con timeout "15" segundos a que aparezca la imagen "excel/excel_listo"
    Y capturo el escritorio con nombre "excel_abierto"

    Entonces deberia ver el texto "Reporte" en el escritorio usando OCR
    Y deberia ver la imagen "excel/celda_encabezado" en pantalla

    Y capturo la region "500" "300" "200" "30" y extraigo texto en la variable "total_reporte"

    # Cerrar Excel con Alt+F4
    Y presiono en escritorio las teclas "alt" y "f4"
    Y espero "1" segundos en escritorio

    # --- VOLVER A WEB (capturas Playwright automaticas) ---
    Cuando uso el modo web
    Y vuelvo al navegador web despues de la interaccion con escritorio
    Entonces verifico que el elemento con css "h1" es visible
    Y tomo una captura de pantalla con nombre "web_restaurada"


  # ============================================================================
  # ESCENARIO 16: Web + API + Desktop (los tres modos)
  # uso el modo api  → muestra request/response en reporte, sin screenshot
  # ============================================================================

  Escenario: Flujo completo con los tres modos
    # --- WEB ---
    Dado que navego a "${ENV.BASE_URL}/login"
    Cuando ingreso "${ENV.TEST_USER}" en el campo con id "username"
    Y ingreso "${ENV.TEST_PASSWORD}" en el campo con id "password"
    Y hago click en el boton con css "button[type='submit']"
    Entonces espero que el elemento con css ".dashboard" sea visible

    # --- API (request/response en reporte, sin screenshot) ---
    Cuando uso el modo api
    Y envío petición GET a "${ENV.API_URL}/users/me" y guardo la respuesta en la variable "user_data"
    Entonces la respuesta debería tener código 200

    # --- DESKTOP (capturas PyAutoGUI) ---
    Cuando uso el modo desktop
    Y lanzo y espero "3" segundos la aplicacion "${ENV.APP_CLIENTE}"
    Y espero con timeout "10" segundos a que aparezca la imagen "app/pantalla_principal"
    Y capturo el escritorio con nombre "app_abierta"

    Entonces deberia ver la imagen "app/menu_principal" en pantalla

    # --- VOLVER A WEB ---
    Cuando uso el modo web
    Y navego a "${ENV.BASE_URL}/dashboard"
    Entonces verifico que el elemento con css ".dashboard" es visible
    Y tomo una captura de pantalla con nombre "dashboard_final"


  # ============================================================================
  # ESCENARIO 17: Token de web a app de escritorio
  # copio el texto "{text}" al portapapeles
  # presiono el atajo de escritorio pegar
  # ============================================================================

  Escenario: Autenticar en web y transferir token a app de escritorio
    Dado que navego a "${ENV.BASE_URL}/login"
    Cuando ingreso "${ENV.TEST_USER}" en el campo con id "username"
    Y ingreso "${ENV.TEST_PASSWORD}" en el campo con id "password"
    Y hago click en el boton con css "button[type='submit']"
    Entonces espero que el elemento con css ".dashboard" sea visible

    Cuando extraigo el texto del elemento con css "[data-testid='api-token']" y lo guardo en "api_token"

    # Cambiar a desktop y pegar el token
    Y uso el modo desktop
    Y lanzo y espero "3" segundos la aplicacion "${ENV.APP_CLIENTE_API}"
    Y espero a que aparezca la imagen "app/campo_token"

    Cuando copio el texto "${api_token}" al portapapeles
    Y hago click en la imagen "app/campo_token"
    Y presiono el atajo de escritorio pegar
    Y hago click en la imagen "app/boton_conectar"

    Y espero con timeout "10" segundos a que aparezca la imagen "app/estado_conectado"
    Entonces deberia ver la imagen "app/estado_conectado" en pantalla
    Y capturo el escritorio con nombre "app_conectada"

    Cuando uso el modo web
    Entonces verifico que el elemento con css ".dashboard" es visible
