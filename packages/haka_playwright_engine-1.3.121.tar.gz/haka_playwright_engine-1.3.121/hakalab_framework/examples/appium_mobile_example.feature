# language: es
# ==============================================================================
# Ejemplo Completo de Automatización Mobile con Appium
# Todos los steps usan los nombres EXACTOS definidos en appium_steps.py
#
# CONFIGURACIÓN (.env):
#   APPIUM_PLATFORM_NAME=Android
#   APPIUM_DEVICE_NAME=emulator-5554
#   APPIUM_APP_PATH=apps/MiApp.apk
#   APPIUM_APP_ID=com.miapp.package
#   APPIUM_SERVER_URL=http://127.0.0.1:4723
#   ELEMENT_WAIT_TIMEOUT=10
#   RESET_STRATEGY=restart
#
# LOCATORS:
#   $.PAGINA.elemento  → JSON POM desde json_poms/PAGINA.json
#   Formato JSON: {"elemento": {"by": "accessibility_id", "value": "Login"}}
# ==============================================================================

@mobile
Característica: Automatización de aplicaciones móviles con Appium
  Como QA de aplicaciones móviles
  Quiero automatizar pruebas funcionales en dispositivos Android e iOS
  Para garantizar la calidad de la aplicación

  # ============================================================================
  # CONEXIÓN Y SESIÓN
  # El paso "uso el modo mobile" lee el .env, conecta al dispositivo,
  # verifica/instala la app y aplica la estrategia de reset automáticamente.
  # ============================================================================

  @session
  Scenario: Iniciar sesión mobile y gestionar ciclo de vida de la app
    # Conecta, instala si es necesario, aplica RESET_STRATEGY del .env
    Given uso el modo mobile
    # Cerrar y relanzar la app manualmente
    When cierro la aplicación móvil
    And espero "2" segundos en el dispositivo
    And lanzo la aplicación móvil
    # Reiniciar la app (reset sin cerrar sesión)
    And reinicio la aplicación móvil
    # Terminar y activar la app (segundo plano / primer plano)
    And termino la aplicación móvil en segundo plano
    And espero "1" segundos en el dispositivo
    And activo la aplicación móvil en primer plano
    Then tomo screenshot del dispositivo

  @disconnect
  Scenario: Desconectar del dispositivo al finalizar
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.HOME.btn_action"
    Then desconecto del dispositivo móvil

  # ============================================================================
  # TAPS Y CLICKS
  # Todos los tipos de tap disponibles para interactuar con elementos.
  # ============================================================================

  @tap_basic
  Scenario: Tap simple en elementos usando JSON POM
    Given uso el modo mobile
    # Tap usando localizador desde JSON POM
    When hago tap simple en el elemento móvil "$.LOGIN.btn_login"
    # Tap por texto visible en pantalla
    And hago tap en el texto móvil "Iniciar Sesión"
    # Tap por accessibility ID directo
    And hago tap en el accessibility id "login_button"
    Then verifico que el elemento móvil "$.HOME.main_screen" es visible

  @tap_advanced
  Scenario: Taps avanzados - doble tap, long press, coordenadas
    Given uso el modo mobile
    # Doble tap (ej: zoom en imagen)
    When hago doble tap en el elemento móvil "$.HOME.image_view"
    And espero "1" segundos en el dispositivo
    # Long press con duración por defecto (1 segundo)
    And hago tap largo simple en el elemento móvil "$.HOME.list_item_1"
    And espero "1" segundos en el dispositivo
    # Long press con duración específica en milisegundos
    And hago tap largo en el elemento móvil "$.HOME.draggable" por "2000" milisegundos
    # Tap en coordenadas absolutas de pantalla
    And hago tap en las coordenadas móvil "540" y "960"
    Then tomo screenshot del dispositivo

  @tap_lists
  Scenario: Taps en listas de elementos
    Given uso el modo mobile
    # Tap en el primer elemento encontrado
    When hago tap en el primer elemento de la lista "$.SEARCH.result_item"
    And espero "1" segundos en el dispositivo
    And presiono atrás en el dispositivo
    # Tap en el último elemento encontrado
    And hago tap en el último elemento de la lista "$.SEARCH.result_item"
    And espero "1" segundos en el dispositivo
    And presiono atrás en el dispositivo
    # Tap en un elemento por índice (base 0)
    And hago tap en el elemento número "2" de la lista "$.SEARCH.result_item"
    Then verifico que el elemento móvil "$.PRODUCT.detail_screen" es visible

  @tap_special
  Scenario: Taps con timeout, scroll, múltiples y condicionales
    Given uso el modo mobile
    # Tap con timeout personalizado (espera hasta 15s a que aparezca)
    When hago tap en el elemento móvil "$.GENERAL.slow_button" con timeout de "15" segundos
    # Tap después de hacer scroll automático hasta encontrar el elemento
    And hago tap en el elemento móvil "$.GENERAL.hidden_button" tras hacer scroll
    # Tap múltiple (3 veces seguidas)
    And hago tap múltiple "3" veces en el elemento móvil "$.GENERAL.counter_btn"
    # Tap con espera posterior (útil para animaciones)
    And hago tap en el elemento móvil "$.GENERAL.submit_btn" esperando "2" segundos
    # Tap condicional: no falla si el elemento no existe
    And hago tap en el elemento móvil "$.GENERAL.optional_popup_close" solo si existe
    Then verifico que el elemento móvil "$.GENERAL.result" es visible

  # ============================================================================
  # ENTRADA DE TEXTO Y TECLADO
  # Escribir, limpiar, agregar texto y presionar teclas.
  # ============================================================================

  @text_input
  Scenario: Escribir texto en campos de formulario
    Given uso el modo mobile
    # Escribir texto (limpia el campo primero)
    When escribo texto "usuario@email.com" en el campo móvil "$.LOGIN.email"
    # Escribir sin limpiar (agrega al contenido existente)
    And escribo ".mx" en el campo móvil "$.LOGIN.email" manteniendo contenido
    # Limpiar un campo
    And limpio el campo móvil "$.LOGIN.email"
    # Limpiar y escribir en un solo paso
    And limpio y escribo "nuevo@email.com" en el campo móvil "$.LOGIN.email"
    # Agregar texto al final sin borrar
    And agrego texto " extra" al campo móvil "$.FORM.name_input"
    Then verifico que el texto del elemento móvil "$.LOGIN.email" contiene "nuevo@email.com"

  @text_keyboard_actions
  Scenario: Escribir texto con acciones de teclado automáticas
    Given uso el modo mobile
    # Escribir y ocultar teclado automáticamente
    When escribo "Mi Usuario" en el campo móvil "$.LOGIN.email" ocultando teclado
    # Escribir y presionar Enter (enviar formulario)
    And escribo "MiPassword123" en el campo móvil "$.LOGIN.password" presionando enter
    Then espero que el elemento móvil "$.HOME.main_screen" sea visible

  @text_search
  Scenario: Búsqueda con texto y tecla buscar
    Given uso el modo mobile
    # Escribir y presionar botón de búsqueda
    When escribo "zapatos deportivos" en el campo móvil "$.SEARCH.search_box" presionando buscar
    And espero "2" segundos en el dispositivo
    Then verifico que hay al menos "1" elementos móviles "$.SEARCH.result_item"

  @text_autocomplete
  Scenario: Escribir carácter por carácter para autocompletado
    Given uso el modo mobile
    # Útil para campos con sugerencias de autocompletado
    When escribo "Buenos Aires" en el campo móvil "$.GENERAL.city_input" letra por letra
    And espero "1" segundos en el dispositivo
    And hago tap en el texto móvil "Buenos Aires, Argentina"
    Then oculto el teclado del dispositivo

  @keyboard_keys
  Scenario: Presionar teclas específicas del dispositivo
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.input_field"
    # Teclas individuales
    And presiono la tecla Tab en el dispositivo
    And presiono la tecla Enter en el dispositivo
    And presiono la tecla Back en el dispositivo
    # Tecla por código Android KeyEvent (84=Search, 66=Enter, 4=Back, 3=Home)
    And presiono la tecla con código "84" en el dispositivo

  # ============================================================================
  # SCROLL Y SWIPE
  # Desplazamiento vertical/horizontal, scroll a elementos y gestos.
  # ============================================================================

  @scroll_basic
  Scenario: Scroll básico en todas las direcciones
    Given uso el modo mobile
    When hago scroll hacia abajo en el dispositivo
    And hago scroll abajo en el dispositivo "3" veces
    And hago scroll hacia arriba en el dispositivo
    And hago scroll arriba en el dispositivo "2" veces
    And hago scroll hasta el final de la pantalla del dispositivo
    Then tomo screenshot del dispositivo

  @scroll_horizontal
  Scenario: Scroll horizontal para carruseles y tabs
    Given uso el modo mobile
    When hago scroll hacia la izquierda en el dispositivo
    And hago scroll izquierda en el dispositivo "2" veces
    And hago scroll hacia la derecha en el dispositivo
    And hago scroll derecha en el dispositivo "2" veces
    Then tomo screenshot del dispositivo

  @scroll_to_element
  Scenario: Scroll hasta encontrar un elemento o texto
    Given uso el modo mobile
    # Scroll automático hasta que el elemento sea visible
    When hago scroll hasta el elemento móvil "$.GENERAL.footer_button"
    And hago tap simple en el elemento móvil "$.GENERAL.footer_button"
    And presiono atrás en el dispositivo
    # Scroll con límite máximo de intentos
    And hago scroll hasta encontrar el elemento móvil "$.GENERAL.rare_element" limitando a "5" intentos
    # Scroll hasta encontrar un texto en pantalla
    And hago scroll hasta encontrar el texto móvil "Términos y Condiciones"
    Then tomo screenshot del dispositivo

  @swipe_elements
  Scenario: Swipe en elementos para revelar acciones
    Given uso el modo mobile
    # Swipe izquierda sobre un elemento (ej: revelar botón eliminar)
    When hago swipe del elemento móvil "$.HOME.list_item_1" hacia la izquierda
    And espero "1" segundos en el dispositivo
    # Swipe derecha para deshacer
    And hago swipe del elemento móvil "$.HOME.list_item_1" hacia la derecha
    Then tomo screenshot del dispositivo

  @swipe_coordinates
  Scenario: Swipe con coordenadas específicas
    Given uso el modo mobile
    # Swipe personalizado entre coordenadas absolutas
    When hago swipe desde "540" "1500" hasta "540" "500" en el dispositivo
    # Swipe con duración específica (más lento)
    And hago swipe desde "540" "500" hasta "540" "1500" con duración "1000" ms
    Then tomo screenshot del dispositivo

  @gestures
  Scenario: Gestos de pinch y zoom en imágenes o mapas
    Given uso el modo mobile
    # Zoom in
    When hago zoom en el elemento móvil "$.GENERAL.map_view"
    And espero "1" segundos en el dispositivo
    # Zoom out (pinch)
    And hago pinch en el elemento móvil "$.GENERAL.map_view"
    Then tomo screenshot del dispositivo

  # ============================================================================
  # NAVEGACIÓN DEL DISPOSITIVO
  # Botones físicos, orientación, notificaciones y modo mixto.
  # ============================================================================

  @navigation
  Scenario: Navegación con botones del dispositivo
    Given uso el modo mobile
    # Botón atrás
    When presiono atrás en el dispositivo
    And espero "1" segundos en el dispositivo
    # Botón atrás múltiples veces
    And presiono el botón atrás del dispositivo repetidamente "3" veces
    # Botón home
    And presiono el botón home del dispositivo
    And espero "2" segundos en el dispositivo
    # Volver a la app
    And activo la aplicación móvil en primer plano
    Then espero que el elemento móvil "$.HOME.main_screen" sea visible

  @notifications
  Scenario: Abrir y verificar notificaciones
    Given uso el modo mobile
    When abro el panel de notificaciones del dispositivo
    And espero "1" segundos en el dispositivo
    And tomo screenshot del dispositivo
    And presiono atrás en el dispositivo
    Then espero que el elemento móvil "$.HOME.main_screen" sea visible

  @orientation
  Scenario: Cambiar y verificar orientación del dispositivo
    Given uso el modo mobile
    Then verifico que la orientación del dispositivo es "PORTRAIT"
    # Cambiar a horizontal con paso directo
    When cambio la orientación del dispositivo a horizontal
    And espero "1" segundos en el dispositivo
    Then verifico que la orientación del dispositivo es "LANDSCAPE"
    # Volver a vertical
    When cambio la orientación del dispositivo a vertical
    Then verifico que la orientación del dispositivo es "PORTRAIT"
    # También se puede usar con parámetro libre
    When cambio la orientación del dispositivo a "LANDSCAPE"
    And cambio la orientación del dispositivo a "PORTRAIT"

  @open_url
  Scenario: Abrir una URL en el navegador del dispositivo
    Given uso el modo mobile
    When abro la url "https://www.google.com" en el navegador del dispositivo
    And espero "3" segundos en el dispositivo
    Then tomo screenshot del dispositivo

  @mixed_mode
  Scenario: Prueba mixta mobile + web
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_action"
    And tomo screenshot del dispositivo
    # Cambiar a modo web para continuar con pruebas Playwright
    And activo el modo web en el contexto

  # ============================================================================
  # VERIFICACIÓN DE ELEMENTOS
  # Validar visibilidad, estado, texto, atributos y cantidad.
  # ============================================================================

  @verify_visibility
  Scenario: Verificar visibilidad y existencia de elementos
    Given uso el modo mobile
    Then verifico que el elemento móvil "$.GENERAL.header" es visible
    And verifico que el elemento móvil "$.GENERAL.loading_spinner" no es visible
    And verifico que el elemento móvil "$.GENERAL.hidden_data" existe
    And verifico que el elemento móvil "$.GENERAL.hidden_element" no existe

  @verify_state
  Scenario: Verificar estado de elementos (habilitado, seleccionado)
    Given uso el modo mobile
    # Verificar habilitado/deshabilitado
    Then verifico que el elemento móvil "$.GENERAL.submit_btn" está habilitado
    And verifico que el elemento móvil "$.GENERAL.disabled_btn" está deshabilitado
    # Verificar seleccionado (checkbox, radio)
    When hago tap simple en el elemento móvil "$.FORM.terms_checkbox"
    Then verifico que el elemento móvil "$.FORM.terms_checkbox" está seleccionado
    When hago tap simple en el elemento móvil "$.FORM.terms_checkbox"
    Then verifico que el elemento móvil "$.FORM.terms_checkbox" no está seleccionado

  @verify_text
  Scenario: Verificar texto de elementos
    Given uso el modo mobile
    # Texto exacto
    Then verifico que el texto del elemento móvil "$.GENERAL.title" es "Bienvenido"
    # Texto parcial
    And verifico que el texto del elemento móvil "$.GENERAL.description" contiene "usuario"
    # Texto que NO debe contener
    And verifico que el texto del elemento móvil "$.GENERAL.status" no contiene "error"
    # Texto no vacío
    And verifico que el texto del elemento móvil "$.GENERAL.user_name" no está vacío

  @verify_attributes
  Scenario: Verificar atributos de elementos
    Given uso el modo mobile
    # Atributo exacto
    Then verifico que el atributo "content-desc" del elemento móvil "$.GENERAL.icon_profile" es "Icono de perfil"
    # Atributo parcial
    And verifico que el atributo "text" del elemento móvil "$.GENERAL.price" contiene "$"

  @verify_count
  Scenario: Verificar cantidad de elementos
    Given uso el modo mobile
    # Cantidad exacta
    Then verifico que hay "5" elementos móviles "$.GENERAL.tab_item"
    # Cantidad mínima
    And verifico que hay al menos "3" elementos móviles "$.SEARCH.result_item"

  @verify_orientation
  Scenario: Verificar orientación del dispositivo
    Given uso el modo mobile
    Then verifico que la orientación del dispositivo es "PORTRAIT"

  # ============================================================================
  # OBTENCIÓN DE DATOS Y VARIABLES
  # Extraer datos de elementos y guardarlos en variables del framework.
  # ============================================================================

  @get_data
  Scenario: Obtener texto y atributos de elementos
    Given uso el modo mobile
    # Guardar texto de un elemento en variable
    When obtengo el texto del elemento móvil "$.GENERAL.user_name" y lo guardo en la variable "nombre_usuario"
    # Guardar atributo en variable
    And obtengo el atributo "content-desc" del elemento móvil "$.GENERAL.avatar" y lo guardo en la variable "desc_avatar"
    # Guardar cantidad de elementos en variable
    And obtengo la cantidad de elementos móviles "$.SEARCH.result_item" y la guardo en la variable "total_resultados"
    # Usar la variable en una verificación
    Then verifico que el texto del elemento móvil "$.GENERAL.greeting" contiene "{nombre_usuario}"

  @get_device_info
  Scenario: Obtener información del dispositivo
    Given uso el modo mobile
    When obtengo la orientación del dispositivo y la guardo en la variable "orientacion"
    And obtengo el tamaño de la pantalla del dispositivo y lo guardo en las variables "ancho" y "alto"
    And obtengo la información del dispositivo y la guardo en la variable "info_device"
    And obtengo el contexto actual del dispositivo y lo guardo en la variable "contexto"
    And obtengo los contextos disponibles del dispositivo y los guardo en la variable "contextos"
    And obtengo el código fuente de la pantalla del dispositivo y lo guardo en la variable "page_source"
    Then imprimo la información del dispositivo

  @debug_info
  Scenario: Imprimir información de debug en el log
    Given uso el modo mobile
    When imprimo la información del dispositivo
    And imprimo los contextos disponibles del dispositivo
    And imprimo el código fuente de la pantalla del dispositivo

  # ============================================================================
  # ALERTAS Y DIÁLOGOS
  # Manejar alertas nativas del sistema operativo.
  # ============================================================================

  @alert_accept
  Scenario: Aceptar una alerta nativa
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.ALERTS.btn_show_alert"
    And espero "1" segundos en el dispositivo
    Then verifico que el texto de la alerta del dispositivo contiene "¿Está seguro?"
    And acepto la alerta nativa del dispositivo

  @alert_dismiss
  Scenario: Rechazar una alerta nativa
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.ALERTS.btn_delete"
    And espero "1" segundos en el dispositivo
    Then verifico que el texto de la alerta del dispositivo es "¿Desea eliminar este elemento?"
    And rechazo la alerta del dispositivo
    And verifico que el elemento móvil "$.HOME.list_item_1" es visible

  @alert_prompt
  Scenario: Escribir texto en una alerta tipo prompt
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.ALERTS.btn_rename"
    And espero "1" segundos en el dispositivo
    And escribo el texto "Nuevo Nombre" en la alerta del dispositivo
    And acepto la alerta nativa del dispositivo
    Then verifico que el texto del elemento móvil "$.ALERTS.item_name" es "Nuevo Nombre"

  @alert_type_and_accept
  Scenario: Escribir texto en alerta y aceptar en un solo paso
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.ALERTS.btn_input_dialog"
    And espero "1" segundos en el dispositivo
    And escribo "Mi Respuesta" en la alerta del dispositivo y la acepto
    Then verifico que el elemento móvil "$.ALERTS.result_text" es visible

  @alert_save_text
  Scenario: Guardar texto de una alerta en variable
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.ALERTS.btn_info"
    And espero "1" segundos en el dispositivo
    And obtengo el texto de la alerta del dispositivo y lo guardo en la variable "mensaje_alerta"
    And acepto la alerta nativa del dispositivo

  @alert_conditional
  Scenario: Aceptar alerta solo si existe (no falla si no hay)
    Given uso el modo mobile
    # Útil cuando no sabes si aparecerá un popup
    When acepto la alerta del dispositivo solo si existe
    And hago tap simple en el elemento móvil "$.ALERTS.continue_btn"

  # ============================================================================
  # ESPERAS
  # Esperas explícitas por tiempo, elementos, texto y estabilidad.
  # ============================================================================

  @wait_time
  Scenario: Espera explícita por tiempo
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_load"
    And espero "3" segundos en el dispositivo
    Then verifico que el elemento móvil "$.GENERAL.content" es visible

  @wait_element
  Scenario: Esperar a que elementos aparezcan o desaparezcan
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_load_data"
    # Esperar a que el spinner desaparezca
    And espero que el elemento móvil "$.GENERAL.loading_spinner" desaparezca
    # Esperar a que el contenido sea visible
    And espero que el elemento móvil "$.GENERAL.data_list" sea visible
    Then verifico que hay al menos "1" elementos móviles "$.GENERAL.data_item"

  @wait_timeout
  Scenario: Esperas con timeout personalizado
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_slow_action"
    # Esperar visible con timeout largo
    And espero a que el elemento móvil "$.GENERAL.result" sea visible en máximo "30" segundos
    # Esperar desaparición con timeout
    And espero a que el elemento móvil "$.GENERAL.progress_bar" desaparezca en máximo "20" segundos
    # Esperar existencia en el DOM
    And espero que el elemento móvil "$.GENERAL.hidden_element" exista
    # Esperar existencia con timeout
    And espero a que el elemento móvil "$.GENERAL.lazy_element" exista en máximo "10" segundos
    Then tomo screenshot del dispositivo

  @wait_text
  Scenario: Esperar a que un texto aparezca en pantalla
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_process"
    And espero que el texto móvil "Proceso completado" sea visible
    And espero a que el texto móvil "Listo" sea visible en máximo "15" segundos
    Then tomo screenshot del dispositivo

  @wait_stable
  Scenario: Esperar a que la pantalla esté estable (sin animaciones)
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.GENERAL.btn_animate"
    And espero a que la pantalla del dispositivo esté estable durante "2" segundos
    Then tomo screenshot del dispositivo

  # ============================================================================
  # SCREENSHOTS Y REPORTES
  # Capturar pantalla completa o de elementos específicos.
  # ============================================================================

  @screenshots
  Scenario: Tomar screenshots del dispositivo y elementos
    Given uso el modo mobile
    # Screenshot de toda la pantalla
    When tomo screenshot del dispositivo
    # Screenshot con nombre personalizado
    And tomo un screenshot nombrado "pantalla_principal" del dispositivo
    # Screenshot de un elemento específico
    And tomo un screenshot del elemento móvil "$.GENERAL.product_card"
    # Screenshot de elemento con nombre
    And tomo un screenshot nombrado "tarjeta_producto" del elemento móvil "$.GENERAL.product_card"
    # Screenshot guardando la ruta en variable
    And tomo un screenshot del dispositivo guardándolo en la variable "ruta_screenshot"
    # Screenshot condicional (solo si el escenario falló)
    And tomo un screenshot del dispositivo por fallo del paso anterior

  # ============================================================================
  # EJECUCIÓN DE SCRIPTS Y COMANDOS
  # Ejecutar JavaScript en WebView o comandos mobile de Appium.
  # ============================================================================

  @scripts_webview
  Scenario: Ejecutar scripts JavaScript en contexto WebView
    Given uso el modo mobile
    And cambio al contexto webview del dispositivo
    When ejecuto el script "return document.title" solo en el dispositivo
    And ejecuto el script "return document.querySelector('h1').textContent" en el dispositivo guardando resultado en la variable "titulo"
    And cambio al contexto nativo del dispositivo

  @mobile_commands
  Scenario: Ejecutar comandos mobile de Appium
    Given uso el modo mobile
    # Comando simple
    When ejecuto el comando mobile "getDeviceTime" solo en el dispositivo
    # Comando guardando resultado
    And ejecuto el comando mobile "getDeviceTime" en el dispositivo guardando resultado en la variable "hora"
    # Comando con argumentos (tabla Gherkin)
    And ejecuto el comando mobile "shell" con argumentos en el dispositivo
      | key     | value           |
      | command | dumpsys battery |

  # ============================================================================
  # CONTEXTOS Y MODO MIXTO (APPS HÍBRIDAS)
  # Cambiar entre contexto nativo y WebView.
  # ============================================================================

  @contexts
  Scenario: Cambiar entre contextos nativo y webview
    Given uso el modo mobile
    Then verifico que el contexto actual del dispositivo es nativo
    And verifico que hay contextos webview disponibles en el dispositivo
    When cambio al contexto webview del dispositivo
    And verifico que el contexto actual del dispositivo es "WEBVIEW"
    And espero "2" segundos en el dispositivo
    And cambio al contexto nativo del dispositivo
    Then verifico que el contexto actual del dispositivo es nativo

  @contexts_multiple
  Scenario: Manejar múltiples webviews por índice
    Given uso el modo mobile
    When cambio al contexto webview número "0" del dispositivo
    And espero "1" segundos en el dispositivo
    And tomo screenshot del dispositivo
    And cambio al contexto nativo del dispositivo

  # ============================================================================
  # FLUJOS COMPLETOS DE EJEMPLO
  # Escenarios reales que combinan múltiples pasos.
  # ============================================================================

  @flow_login
  Scenario: Flujo completo de login en app móvil
    Given uso el modo mobile
    # Esperar carga inicial
    And espero que el elemento móvil "$.LOGIN.splash_screen" desaparezca
    And espero que el elemento móvil "$.LOGIN.login_screen" sea visible
    # Llenar formulario
    When escribo texto "usuario@test.com" en el campo móvil "$.LOGIN.email"
    And escribo "Password123!" en el campo móvil "$.LOGIN.password" ocultando teclado
    And tomo un screenshot nombrado "login_formulario" del dispositivo
    # Enviar
    And hago tap simple en el elemento móvil "$.LOGIN.btn_login"
    And espero a que el elemento móvil "$.HOME.main_screen" sea visible en máximo "10" segundos
    # Verificar
    Then verifico que el elemento móvil "$.HOME.welcome_message" es visible
    And verifico que el texto del elemento móvil "$.HOME.welcome_message" contiene "Bienvenido"
    And obtengo el texto del elemento móvil "$.HOME.user_display_name" y lo guardo en la variable "nombre"
    And tomo un screenshot nombrado "login_exitoso" del dispositivo

  @flow_ecommerce
  Scenario: Flujo de compra en app de e-commerce
    Given uso el modo mobile
    And espero que el elemento móvil "$.HOME.main_screen" sea visible
    # Buscar producto
    When escribo "Laptop Gaming" en el campo móvil "$.SEARCH.search_box" presionando buscar
    And espero a que el elemento móvil "$.SEARCH.results_container" sea visible en máximo "5" segundos
    And verifico que hay al menos "1" elementos móviles "$.SEARCH.result_item"
    # Seleccionar primer producto
    And hago tap en el primer elemento de la lista "$.SEARCH.result_item"
    And espero que el elemento móvil "$.PRODUCT.detail_screen" sea visible
    # Verificar detalles
    And verifico que el texto del elemento móvil "$.PRODUCT.name" no está vacío
    And obtengo el texto del elemento móvil "$.PRODUCT.price" y lo guardo en la variable "precio"
    And tomo un screenshot nombrado "detalle_producto" del dispositivo
    # Agregar al carrito
    And hago scroll hacia abajo en el dispositivo
    And hago scroll hasta encontrar el texto móvil "Agregar al carrito"
    And hago tap en el texto móvil "Agregar al carrito"
    And acepto la alerta del dispositivo solo si existe
    And espero "1" segundos en el dispositivo
    # Verificar carrito
    And hago tap simple en el elemento móvil "$.HOME.cart_icon"
    And espero que el elemento móvil "$.CART.cart_screen" sea visible
    Then verifico que hay al menos "1" elementos móviles "$.CART.cart_item"
    And tomo un screenshot nombrado "carrito_con_producto" del dispositivo

  @flow_form
  Scenario: Flujo de llenado de formulario complejo
    Given uso el modo mobile
    When hago tap simple en el elemento móvil "$.FORM.btn_new_form"
    And espero que el elemento móvil "$.FORM.screen" sea visible
    # Llenar campos
    And escribo texto "Juan Pérez" en el campo móvil "$.FORM.name_input"
    And presiono la tecla Tab en el dispositivo
    And escribo texto "juan@email.com" en el campo móvil "$.FORM.email_input"
    And presiono la tecla Tab en el dispositivo
    And escribo texto "+54 11 1234-5678" en el campo móvil "$.FORM.phone_input"
    And oculto el teclado del dispositivo
    # Seleccionar país
    And hago tap simple en el elemento móvil "$.FORM.dropdown_country"
    And espero "1" segundos en el dispositivo
    And hago scroll hasta encontrar el texto móvil "Argentina"
    And hago tap en el texto móvil "Argentina"
    # Dirección con autocompletado
    And hago scroll hacia abajo en el dispositivo
    And escribo "Av. Corrientes 1234" en el campo móvil "$.FORM.address_input" letra por letra
    And espero "2" segundos en el dispositivo
    And hago tap en el elemento móvil "$.FORM.suggestion_1" solo si existe
    And oculto el teclado del dispositivo
    # Aceptar términos y enviar
    And hago tap simple en el elemento móvil "$.FORM.terms_checkbox"
    And verifico que el elemento móvil "$.FORM.terms_checkbox" está seleccionado
    And hago tap simple en el elemento móvil "$.FORM.btn_submit"
    And espero a que el elemento móvil "$.FORM.success_message" sea visible en máximo "10" segundos
    Then verifico que el texto del elemento móvil "$.FORM.success_message" contiene "enviado"
    And tomo un screenshot nombrado "formulario_enviado" del dispositivo
    And desconecto del dispositivo móvil
