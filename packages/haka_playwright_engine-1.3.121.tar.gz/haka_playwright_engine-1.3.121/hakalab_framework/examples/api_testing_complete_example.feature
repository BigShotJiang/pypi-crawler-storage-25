# ==============================================================================
# Ejemplo Completo de Testing de APIs REST
# Todos los steps usan los nombres EXACTOS definidos en api_testing_steps.py
#
# NOTA: No necesitas declarar "uso el modo api" en pruebas puras de API.
#       El reporte detecta automaticamente que es API y muestra request/response.
#
# URL de prueba: https://jsonplaceholder.typicode.com (API publica gratuita)
# ==============================================================================

@no_browser
Feature: Testing Completo de APIs REST

  # ============================================================================
  # ESCENARIO 1: Configuracion de sesion y GET basico
  #
  # configuro la API base en "{url}"
  # configuro el header "{name}" con valor "{value}"
  # realizo GET a "{url}"
  # la respuesta deberia tener codigo "{status}"
  # el campo "{path}" de la respuesta deberia ser "{value}"
  # el campo "{path}" de la respuesta deberia contener "{value}"
  # el campo "{path}" de la respuesta no deberia estar vacio
  # el campo "{path}" deberia existir en la respuesta
  # la respuesta deberia ser un objeto JSON
  # verifico que la respuesta API es JSON valido
  # ============================================================================

  Scenario: GET basico con configuracion de sesion
    Given configuro la API base en "https://jsonplaceholder.typicode.com"
    And configuro el header "Accept" con valor "application/json"
    And configuro el header "Content-Type" con valor "application/json"

    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"
    And el campo "id" de la respuesta deberia ser "1"
    And el campo "name" de la respuesta deberia ser "Leanne Graham"
    And el campo "email" de la respuesta deberia contener "@"
    And el campo "name" de la respuesta no deberia estar vacio
    And el campo "id" deberia existir en la respuesta
    And la respuesta deberia ser un objeto JSON
    And verifico que la respuesta API es JSON valido


  # ============================================================================
  # ESCENARIO 2: Autenticacion Bearer Token
  #
  # configuro el token Bearer "{token}"
  # ============================================================================

  Scenario: GET con autenticacion Bearer Token
    Given configuro el token Bearer "${ENV.API_TOKEN}"
    And configuro el header "Accept" con valor "application/json"

    When realizo GET a "${ENV.API_BASE_URL}/protected/resource"

    Then la respuesta deberia tener codigo "200"
    And el campo "data" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 3: Autenticacion Basic Auth
  #
  # configuro autenticacion basica usuario "{user}" contrasena "{pass}"
  # ============================================================================

  Scenario: GET con autenticacion Basic Auth
    Given configuro autenticacion basica usuario "${ENV.API_USER}" contrasena "${ENV.API_PASSWORD}"

    When realizo GET a "${ENV.API_BASE_URL}/secure/data"

    Then la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 4: Autenticacion API Key en header
  #
  # configuro API key en el header "{header}" con valor "{key}"
  # ============================================================================

  Scenario: GET con API Key en header personalizado
    Given configuro API key en el header "X-API-Key" con valor "${ENV.API_KEY}"

    When realizo GET a "${ENV.API_BASE_URL}/data"

    Then la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 5: GET con query parameters
  #
  # realizo GET con parametros "{json}" a "{url}"
  # la respuesta deberia ser un array JSON
  # el array "{path}" de la respuesta deberia tener "{n}" elementos
  # el tiempo de respuesta deberia ser menor a "{ms}" milisegundos
  # ============================================================================

  Scenario: GET con query parameters y validacion de array
    When realizo GET con parametros '{"userId": "1"}' a "https://jsonplaceholder.typicode.com/posts"

    Then la respuesta deberia tener codigo "200"
    And la respuesta deberia ser un array JSON
    And el array "" de la respuesta deberia tener "10" elementos
    And el tiempo de respuesta deberia ser menor a "3000" milisegundos


  # ============================================================================
  # ESCENARIO 6: POST con body inline
  #
  # realizo POST a "{url}" con body "{body}"
  # guardo el campo "{path}" de la respuesta en la variable "{var}"
  # ============================================================================

  Scenario: POST con body inline y extraccion de ID
    When realizo POST a "https://jsonplaceholder.typicode.com/posts" con body '{"title": "Test Post", "body": "Contenido", "userId": 1}'

    Then la respuesta deberia tener codigo "201"
    And el campo "title" de la respuesta deberia ser "Test Post"
    And el campo "id" deberia existir en la respuesta

    When guardo el campo "id" de la respuesta en la variable "post_id"
    Then verifico que la variable "post_id" contiene "1"


  # ============================================================================
  # ESCENARIO 7: POST con body JSON multilinea (DocString)
  #
  # envio JSON body a "{url}" via POST
  # (el body se define como DocString debajo del step)
  # ============================================================================

  Scenario: POST con body JSON multilinea como DocString
    When envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {
        "title": "Articulo de prueba",
        "body": "Contenido del articulo",
        "userId": 1
      }
      """

    Then la respuesta deberia tener codigo "201"
    And el campo "title" de la respuesta deberia ser "Articulo de prueba"


  # ============================================================================
  # ESCENARIO 8: POST con body desde archivo externo
  #
  # cargo y envio POST a "{url}" con body del archivo "{file}"
  # ============================================================================

  Scenario: POST con body cargado desde archivo JSON
    When cargo y envio POST a "https://jsonplaceholder.typicode.com/posts" con body del archivo "payloads/create_post.json"

    Then la respuesta deberia tener codigo "201"
    And el campo "id" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 9: PUT - actualizar recurso completo
  #
  # realizo PUT a "{url}" con body "{body}"
  # envio JSON body a "{url}" via PUT  (DocString)
  # cargo y envio PUT a "{url}" con body del archivo "{file}"
  # ============================================================================

  Scenario: PUT para actualizar un recurso completo
    When envio JSON body a "https://jsonplaceholder.typicode.com/posts/1" via PUT
      """
      {
        "id": 1,
        "title": "Titulo actualizado",
        "body": "Contenido actualizado",
        "userId": 1
      }
      """

    Then la respuesta deberia tener codigo "200"
    And el campo "title" de la respuesta deberia ser "Titulo actualizado"
    And el campo "id" de la respuesta deberia ser "1"


  # ============================================================================
  # ESCENARIO 10: PATCH - actualizar parcialmente
  #
  # realizo PATCH a "{url}" con body "{body}"
  # envio JSON body a "{url}" via PATCH  (DocString)
  # cargo y envio PATCH a "{url}" con body del archivo "{file}"
  # ============================================================================

  Scenario: PATCH para actualizar parcialmente un recurso
    When realizo PATCH a "https://jsonplaceholder.typicode.com/posts/1" con body '{"title": "Solo el titulo cambia"}'

    Then la respuesta deberia tener codigo "200"
    And el campo "title" de la respuesta deberia ser "Solo el titulo cambia"


  # ============================================================================
  # ESCENARIO 11: DELETE
  #
  # realizo DELETE a "{url}"
  # ============================================================================

  Scenario: DELETE de un recurso
    When realizo DELETE a "https://jsonplaceholder.typicode.com/posts/1"

    Then la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 12: Flujo CRUD completo encadenando requests
  # ============================================================================

  Scenario: Flujo CRUD completo
    Given configuro el header "Content-Type" con valor "application/json"

    # CREATE
    When envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {"title": "Post CRUD", "body": "Contenido inicial", "userId": 1}
      """
    Then la respuesta deberia tener codigo "201"
    And guardo el campo "id" de la respuesta en la variable "nuevo_id"

    # READ
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"
    Then la respuesta deberia tener codigo "200"
    And el campo "userId" de la respuesta deberia ser "1"
    And guardo el campo "title" de la respuesta en la variable "titulo_original"

    # UPDATE
    When realizo PATCH a "https://jsonplaceholder.typicode.com/posts/1" con body '{"title": "Titulo modificado"}'
    Then la respuesta deberia tener codigo "200"
    And el campo "title" de la respuesta deberia ser "Titulo modificado"

    # DELETE
    When realizo DELETE a "https://jsonplaceholder.typicode.com/posts/1"
    Then la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 13: Guardar y reutilizar valores entre requests
  #
  # guardo el campo "{path}" de la respuesta en la variable "{var}"
  # guardo el body completo de la respuesta en la variable "{var}"
  # guardo el status code de la respuesta en la variable "{var}"
  # guardo el header "{header}" de la respuesta en la variable "{var}"
  # ============================================================================

  Scenario: Extraer y reutilizar datos entre requests
    When realizo GET a "https://jsonplaceholder.typicode.com/posts"
    Then guardo el campo "0.id" de la respuesta en la variable "primer_post_id"
    And guardo el campo "0.userId" de la respuesta en la variable "user_id"
    And guardo el status code de la respuesta en la variable "status_lista"
    And guardo el body completo de la respuesta en la variable "body_completo"

    When realizo GET a "https://jsonplaceholder.typicode.com/posts/${primer_post_id}"
    Then la respuesta deberia tener codigo "200"
    And el campo "id" de la respuesta deberia ser "${primer_post_id}"
    And el campo "userId" de la respuesta deberia ser "${user_id}"
    And verifico que la variable "status_lista" es igual a "200"


  # ============================================================================
  # ESCENARIO 14: Validacion de headers de respuesta
  #
  # verifico que el header de respuesta API "{header}" es igual a "{value}"
  # verifico que el header de respuesta API "{header}" contiene "{text}"
  # guardo el header "{header}" de la respuesta en la variable "{var}"
  # ============================================================================

  Scenario: Validar headers de respuesta
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Then la respuesta deberia tener codigo "200"
    And verifico que el header de respuesta API "Content-Type" contiene "application/json"
    And guardo el header "Content-Type" de la respuesta en la variable "content_type"
    And verifico que la variable "content_type" contiene "json"


  # ============================================================================
  # ESCENARIO 15: Validacion de tiempo y performance
  #
  # el tiempo de respuesta deberia ser menor a "{ms}" milisegundos
  # verifico que el tiempo de respuesta de la API es menor a "{s}" segundos
  # ============================================================================

  Scenario: Validar performance de la API
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Then la respuesta deberia tener codigo "200"
    And el tiempo de respuesta deberia ser menor a "5000" milisegundos
    And verifico que el tiempo de respuesta de la API es menor a "5" segundos


  # ============================================================================
  # ESCENARIO 16: POST con form data y multipart
  #
  # envio form data "{data}" a "{url}"
  # subo archivo "{file}" a "{url}" en campo "{field}"
  # ============================================================================

  Scenario: POST con form data
    When envio form data '{"username": "testuser", "action": "login"}' a "${ENV.API_BASE_URL}/form-endpoint"

    Then la respuesta deberia tener codigo "200"


  Scenario: POST subiendo un archivo
    When subo archivo "test_files/documento.pdf" a "${ENV.API_BASE_URL}/upload" en campo "file"

    Then la respuesta deberia tener codigo "200"
    And el campo "filename" deberia existir en la respuesta


  # ============================================================================
  # ESCENARIO 17: Validacion de esquema JSON
  #
  # verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema}"
  # verifico que el JSON de respuesta API coincide con el archivo "{file}" ignorando orden
  # verifico que el JSON de respuesta API coincide con el archivo "{file}" ignorando campos "{campos}"
  # ============================================================================

  Scenario: Validar respuesta contra esquema JSON Schema
    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"
    And verifico que el JSON de respuesta API coincide con el esquema del archivo "schemas/user_schema.json"


  Scenario: Comparar respuesta con archivo esperado
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Then la respuesta deberia tener codigo "200"
    And verifico que el JSON de respuesta API coincide con el archivo "expected/post_1.json" ignorando orden
    And verifico que el JSON de respuesta API coincide con el archivo "expected/post_1.json" ignorando campos "created_at,updated_at"


  # ============================================================================
  # ESCENARIO 18: Validaciones avanzadas de campos JSON
  #
  # verifico que el JSON de respuesta API tiene el campo "{field}" con tipo "{type}"
  # verifico que el campo "{field}" del JSON de respuesta API coincide con el patron "{regex}"
  # verifico que el campo "{field}" del JSON de respuesta API esta en el rango {min} a {max}
  # ============================================================================

  Scenario: Validaciones avanzadas de tipos y formatos
    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"
    And verifico que el JSON de respuesta API tiene el campo "id" con tipo "integer"
    And verifico que el JSON de respuesta API tiene el campo "name" con tipo "string"
    And verifico que el JSON de respuesta API tiene el campo "address" con tipo "object"
    And verifico que el campo "email" del JSON de respuesta API coincide con el patron "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    And verifico que el campo "id" del JSON de respuesta API esta en el rango 1 a 100


  # ============================================================================
  # ESCENARIO 19: Manejo de errores HTTP
  # ============================================================================

  Scenario: Verificar manejo de errores 404
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/99999"

    Then la respuesta deberia tener codigo "404"


  Scenario: Verificar rango de status codes exitosos
    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"

    Then verifico que el estado de respuesta API esta en el rango "200" a "299"


  # ============================================================================
  # ESCENARIO 20: Guardar respuesta en archivo
  #
  # guardo el cuerpo de respuesta API en el archivo "{file}"
  # ============================================================================

  Scenario: Guardar respuesta en archivo para analisis posterior
    When realizo GET a "https://jsonplaceholder.typicode.com/users"

    Then la respuesta deberia tener codigo "200"
    And guardo el cuerpo de respuesta API en el archivo "reports/users_response.json"


  # ============================================================================
  # ESCENARIO 21: Limpiar sesion y cambiar configuracion
  #
  # limpio los headers de sesion API
  # establezco el header de API "{header}" a "{value}"
  # establezco el timeout de API a "{timeout}" segundos
  # ============================================================================

  Scenario: Cambiar configuracion de sesion entre requests
    Given configuro el token Bearer "token-inicial"
    And configuro el header "X-Custom" con valor "valor1"

    When realizo GET a "https://jsonplaceholder.typicode.com/posts/1"
    Then la respuesta deberia tener codigo "200"

    When limpio los headers de sesion API
    And establezco el header de API "Authorization" a "Bearer token-nuevo"
    And establezco el timeout de API a "10" segundos

    When realizo GET a "https://jsonplaceholder.typicode.com/posts/2"
    Then la respuesta deberia tener codigo "200"
    And el campo "id" de la respuesta deberia ser "2"


  # ============================================================================
  # ESCENARIO 22: Flujo de autenticacion con token dinamico
  # ============================================================================

  Scenario: Obtener token y usarlo en siguientes requests
    Given configuro el header "Content-Type" con valor "application/json"

    When envio JSON body a "${ENV.AUTH_URL}/token" via POST
      """
      {
        "username": "${ENV.TEST_USER}",
        "password": "${ENV.TEST_PASSWORD}",
        "grant_type": "password"
      }
      """
    Then la respuesta deberia tener codigo "200"
    And guardo el campo "access_token" de la respuesta en la variable "auth_token"

    When configuro el token Bearer "${auth_token}"
    And realizo GET a "${ENV.API_BASE_URL}/me"
    Then la respuesta deberia tener codigo "200"
    And el campo "username" de la respuesta deberia ser "${ENV.TEST_USER}"


  # ============================================================================
  # ESCENARIO 23: Peticiones en lote desde archivo
  #
  # envio peticiones API en lote desde archivo "{file}" y guardo resultados en variable "{var}"
  # ============================================================================

  Scenario: Ejecutar multiples peticiones desde archivo de configuracion
    When envío peticiones API en lote desde archivo "batch/requests.json" y guardo resultados en variable "batch_results"

    Then verifico que la variable "batch_results" contiene "status_code"


  # ============================================================================
  # ESCENARIO 24: Peticiones concurrentes
  #
  # envio peticiones API concurrentes "{n}" veces a "{url}" y verifico que todas tengan exito
  # ============================================================================

  Scenario: Verificar que la API soporta carga concurrente
    When envío peticiones API concurrentes "5" veces a "https://jsonplaceholder.typicode.com/posts/1" y verifico que todas tengan éxito

    Then la respuesta deberia tener codigo "200"


  # ============================================================================
  # ESCENARIO 25: Verificaciones de seguridad y CORS
  #
  # verifico que la respuesta API tiene headers de seguridad
  # verifico que el endpoint API "{endpoint}" soporta CORS
  # ============================================================================

  Scenario: Verificar headers de seguridad
    When realizo GET a "${ENV.API_BASE_URL}/secure"

    Then la respuesta deberia tener codigo "200"
    And verifico que la respuesta API tiene headers de seguridad


  Scenario: Verificar soporte CORS del endpoint
    Then verifico que el endpoint API "https://jsonplaceholder.typicode.com/posts" soporta CORS


  # ============================================================================
  # ESCENARIO 26: JSONPath - existencia y tipos
  #
  # la respuesta tiene el campo "$.campo"
  # la respuesta no tiene el campo "$.campo"
  # el campo "$.campo" en la respuesta es de tipo "string/number/integer/boolean/array/object/null"
  # ============================================================================

  Scenario: Verificar existencia y tipos con JSONPath
    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"

    # Existencia
    And existe el campo "$.id" en la respuesta
    And existe el campo "$.address.city" en la respuesta
    And existe el campo "$.address.geo.lat" en la respuesta
    And no existe el campo "$.password" en la respuesta

    # Tipos
    And el campo "$.id" en la respuesta es de tipo "integer"
    And el campo "$.name" en la respuesta es de tipo "string"
    And el campo "$.address" en la respuesta es de tipo "object"


  # ============================================================================
  # ESCENARIO 27: JSONPath - valores exactos y parciales
  #
  # la respuesta tiene el campo "$.campo" con valor "valor"
  # la respuesta tiene el campo "$.campo" que contiene "texto"
  # el campo "$.campo" en la respuesta es nulo / no es nulo
  # el campo "$.campo" en la respuesta esta vacio / no esta vacio
  # ============================================================================

  Scenario: Verificar valores con notacion JSONPath
    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"
    And verifico que el campo "$.id" en la respuesta vale "1"
    And verifico que el campo "$.username" en la respuesta vale "Bret"
    And verifico que el campo "$.email" en la respuesta contiene "@"
    And el campo "$.name" en la respuesta no es nulo
    And el campo "$.name" en la respuesta no esta vacio


  # ============================================================================
  # ESCENARIO 28: JSONPath - comparaciones numericas
  #
  # el campo "$.campo" en la respuesta es mayor que "valor"
  # el campo "$.campo" en la respuesta es menor que "valor"
  # el campo "$.campo" en la respuesta esta entre "min" y "max"
  # ============================================================================

  Scenario: Verificar rangos numericos con JSONPath
    When realizo GET a "https://jsonplaceholder.typicode.com/users/5"

    Then la respuesta deberia tener codigo "200"
    And el campo "$.id" en la respuesta es de tipo "integer"
    And el campo "$.id" en la respuesta es mayor que "0"
    And el campo "$.id" en la respuesta es menor que "100"
    And el campo "$.id" en la respuesta esta entre "1" y "10"


  # ============================================================================
  # ESCENARIO 29: JSONPath - expresiones regulares
  #
  # el campo "$.campo" en la respuesta coincide con el patron "regex"
  # ============================================================================

  Scenario: Verificar formatos con expresiones regulares
    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    Then la respuesta deberia tener codigo "200"
    And el campo "$.email" en la respuesta coincide con el patron "^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$"
    And el campo "$.website" en la respuesta coincide con el patron "\\."


  # ============================================================================
  # ESCENARIO 30: JSONPath - arrays
  #
  # el arreglo "$.campo" deberia tener "N" elementos
  # el arreglo "$.campo" deberia tener al menos "N" elementos
  # en el arreglo "$.campo" en la posicion "N" encuentro "$.campo" con valor "valor"
  # en el arreglo "$.campo" en la posicion "N" encuentro el campo "$.campo"
  # el arreglo "$.campo" deberia contener un elemento con "$.campo" igual a "valor"
  # todos los elementos del arreglo "$.campo" deberian tener el campo "$.campo"
  # ============================================================================

  Scenario: Verificar arrays con notacion JSONPath
    When realizo GET a "https://jsonplaceholder.typicode.com/users"

    Then la respuesta deberia tener codigo "200"
    And la respuesta deberia ser un array JSON

    # Conteo
    And el arreglo "$" deberia tener "10" elementos
    And el arreglo "$" deberia tener al menos "5" elementos

    # Elemento en posicion especifica
    And en el arreglo "$" en la posicion "0" encuentro "$.id" con valor "1"
    And en el arreglo "$" en la posicion "0" encuentro el campo "$.name"
    And en el arreglo "$" en la posicion "9" encuentro "$.id" con valor "10"

    # Buscar elemento con valor especifico
    And el arreglo "$" deberia contener un elemento con "$.username" igual a "Bret"

    # Todos los elementos tienen un campo
    And todos los elementos del arreglo "$" deberian tener el campo "$.id"
    And todos los elementos del arreglo "$" deberian tener el campo "$.email"


  # ============================================================================
  # ESCENARIO 31: JSONPath - extraccion y reutilizacion
  #
  # guardo el campo "$.campo" de la respuesta en la variable "{var}"
  # ============================================================================

  Scenario: Extraer valores con JSONPath y usarlos en siguientes requests
    When realizo GET a "https://jsonplaceholder.typicode.com/posts"
    Then la respuesta deberia tener codigo "200"
    And guardo el campo "$.0.id" de la respuesta en la variable "primer_id"
    And guardo el campo "$.0.userId" de la respuesta en la variable "user_id"

    When realizo GET a "https://jsonplaceholder.typicode.com/posts/${primer_id}"
    Then la respuesta deberia tener codigo "200"
    And la respuesta deberia tener el campo "$.id" con valor "${primer_id}"
    And la respuesta deberia tener el campo "$.userId" con valor "${user_id}"


  # ============================================================================
  # ESCENARIO 32: Flujo completo con JSONPath - crear y verificar
  # ============================================================================

  Scenario: Crear recurso y verificar estructura completa con JSONPath
    Given configuro el header "Content-Type" con valor "application/json"

    When envio JSON body a "https://jsonplaceholder.typicode.com/posts" via POST
      """
      {
        "title": "Post de prueba JSONPath",
        "body": "Contenido del post",
        "userId": 1
      }
      """

    Then la respuesta deberia tener codigo "201"
    And existe el campo "$.id" en la respuesta
    And el campo "$.id" en la respuesta es de tipo "integer"
    And verifico que el campo "$.title" en la respuesta vale "Post de prueba JSONPath"
    And el campo "$.title" en la respuesta no esta vacio
    And el campo "$.userId" en la respuesta es mayor que "0"
    And guardo el campo "$.id" de la respuesta en la variable "nuevo_post_id"
    And guardo el campo "$.title" de la respuesta en la variable "titulo_creado"


  # ============================================================================
  # ESCENARIO 33: Combinacion de steps legacy y nuevos en el mismo escenario
  # ============================================================================

  Scenario: Usar steps legacy y nuevos juntos
    Given configuro el header "Accept" con valor "application/json"

    When realizo GET a "https://jsonplaceholder.typicode.com/users/1"

    # Steps legacy (siguen funcionando)
    Then verifico que el código de estado de la respuesta API es "200"
    And verifico que la respuesta API contiene "name" con valor "Leanne Graham"
    And extraigo el valor de la respuesta API "id" y lo guardo en la variable "user_id_legacy"

    # Steps nuevos simplificados
    And la respuesta deberia tener codigo "200"
    And el campo "name" de la respuesta deberia ser "Leanne Graham"
    And guardo el campo "id" de la respuesta en la variable "user_id_nuevo"

    # Steps JSONPath
    And verifico que el campo "$.id" en la respuesta vale "1"
    And el campo "$.name" en la respuesta es de tipo "string"
    And guardo el campo "$.email" de la respuesta en la variable "email_usuario"
