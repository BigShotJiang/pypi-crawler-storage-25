# language: es
Característica: Procesamiento de Lenguaje Natural con IA
  Como tester avanzado de QA
  Quiero usar capacidades completas de NLP
  Para análisis profundo de textos, traducción, generación y más

  @no_browser
  Escenario: Extracción de entidades nombradas (NER)
    # Tag @no_browser desactiva el navegador para pruebas de NLP sin UI
    
    # Extraer personas, lugares, organizaciones, etc.
    Then extraigo las entidades del texto "Juan García visitó Madrid el 15 de enero de 2024" y las guardo en "entidades"
    And muestro en consola el valor de la variable "entidades"
    
    # Verificar que contiene entidades específicas
    Then verifico que el texto "María López trabaja en Google" contiene una entidad de tipo "PER"
    Then verifico que el texto "María López trabaja en Google" contiene una entidad de tipo "ORG"

  Escenario: Resumen automático de textos largos
    Given guardo "Python es un lenguaje de programación de alto nivel. Es muy popular para ciencia de datos, desarrollo web y automatización. Fue creado por Guido van Rossum en 1991. Python es conocido por su sintaxis clara y legible." en la variable "articulo"
    
    # Generar resumen
    Then genero un resumen de la variable "articulo" con máximo 20 palabras y lo guardo en "resumen"
    And muestro en consola el valor de la variable "resumen"

  Escenario: Traducción automática entre idiomas
    # Traducir de inglés a español
    Then traduzco el texto "Hello, how are you today?" de "en" a "es" y lo guardo en "traduccion_es"
    And muestro en consola el valor de la variable "traduccion_es"
    
    # Traducir de español a inglés
    Then traduzco el texto "Buenos días, ¿cómo estás?" de "es" a "en" y lo guardo en "traduccion_en"
    And muestro en consola el valor de la variable "traduccion_en"
    
    # Traducir de inglés a francés
    Then traduzco el texto "Thank you very much" de "en" a "fr" y lo guardo en "traduccion_fr"
    And muestro en consola el valor de la variable "traduccion_fr"

  Escenario: Generación de texto automática
    # Generar respuesta a una pregunta
    Then genero una respuesta para "The benefits of automation testing are" y la guardo en "respuesta_generada"
    And muestro en consola el valor de la variable "respuesta_generada"

  Escenario: Análisis de toxicidad y contenido ofensivo
    # Verificar que textos normales no son tóxicos
    Then verifico que el texto "Thank you for your help" no es tóxico
    Then verifico que el texto "Great product, highly recommended" no es tóxico
    
    # Analizar y guardar resultado
    Then analizo la toxicidad del texto "This is a normal comment" y guardo el resultado en "es_toxico"
    And muestro en consola el valor de la variable "es_toxico"

  Escenario: Extracción de palabras clave
    Given guardo "Python is a high-level programming language. It is widely used for data science, web development, and automation. Python was created by Guido van Rossum." en la variable "texto_python"
    
    # Extraer keywords
    Then extraigo las palabras clave del texto "${texto_python}" y las guardo en "keywords"
    And muestro en consola el valor de la variable "keywords"

  Escenario: Clustering de textos similares
    # Agrupar mensajes en categorías automáticamente
    Then agrupo los textos "Error de red,Fallo de conexión,Problema de servidor,Pago exitoso,Transacción aprobada,Operación completada" en 2 clusters y guardo los resultados en "grupos"
    And muestro en consola el valor de la variable "grupos"

  Escenario: Question Answering (Responder preguntas sobre un texto)
    Given guardo "Francia es un país europeo. Su capital es París. La Torre Eiffel es uno de sus monumentos más famosos. Francia es conocida por su gastronomía y vinos." en la variable "contexto_francia"
    
    # Responder preguntas basadas en el contexto
    Then respondo la pregunta "¿Cuál es la capital de Francia?" basándome en el contexto "${contexto_francia}" y guardo la respuesta en "respuesta1"
    And muestro en consola el valor de la variable "respuesta1"
    
    Then respondo la pregunta "¿Por qué es famosa Francia?" basándome en el contexto "${contexto_francia}" y guardo la respuesta en "respuesta2"
    And muestro en consola el valor de la variable "respuesta2"

  Escenario: Flujo completo de análisis de comentario de usuario
    Given navego a "https://example.com/reviews"
    And uso la configuración semántica por defecto
    
    # Extraer comentario
    When extraigo el texto del elemento "Comentario" con identificador "$.REVIEW.comment" y lo guardo en "comentario"
    
    # 1. Detectar idioma
    Then detecto el idioma del texto "${comentario}" y lo guardo en "idioma"
    
    # 2. Analizar sentimiento
    Then el sentimiento de la variable "comentario" debe ser "positivo"
    
    # 3. Extraer entidades (nombres, lugares, etc.)
    Then extraigo las entidades del texto "${comentario}" y las guardo en "entidades"
    
    # 4. Extraer palabras clave
    Then extraigo las palabras clave del texto "${comentario}" y las guardo en "keywords"
    
    # 5. Verificar que no es tóxico
    Then verifico que el texto "${comentario}" no es tóxico
    
    # 6. Clasificar tema
    Then clasifico el texto "${comentario}" en las categorías "producto,servicio,precio,entrega" y guardo el resultado en "tema"
    
    # Mostrar todos los resultados
    Then muestro en consola el valor de la variable "idioma"
    Then muestro en consola el valor de la variable "entidades"
    Then muestro en consola el valor de la variable "keywords"
    Then muestro en consola el valor de la variable "tema"

  Escenario: Validación de chatbot multilingüe con traducción
    Given uso la configuración semántica por defecto
    
    # Usuario escribe en español
    When escribo "¿Cómo puedo resetear mi contraseña?" en el chat
    And espero 2 segundos
    
    # Extraer respuesta del bot
    And extraigo el texto del elemento "Respuesta Bot" con identificador "$.CHAT.response" y lo guardo en "respuesta_bot"
    
    # Traducir respuesta a inglés para análisis
    Then traduzco el texto "${respuesta_bot}" de "es" a "en" y lo guardo en "respuesta_en"
    
    # Validar semánticamente en inglés
    Then el texto de la variable "respuesta_en" debe ser semánticamente similar a "You can reset your password from the login page"
    
    # Verificar que la respuesta es útil (sentimiento positivo/neutral)
    Then el sentimiento de la variable "respuesta_bot" debe ser "positivo"

  Escenario: Análisis de documentación técnica
    Given guardo "This API endpoint allows you to create new users. It requires authentication via API key. The endpoint accepts POST requests with JSON payload containing user details." en la variable "doc_api"
    
    # Extraer información clave
    Then extraigo las palabras clave del texto "${doc_api}" y las guardo en "conceptos_clave"
    
    # Generar resumen
    Then genero un resumen de la variable "doc_api" con máximo 15 palabras y lo guardo en "resumen_doc"
    
    # Responder preguntas sobre la documentación
    Then respondo la pregunta "What does this endpoint do?" basándome en el contexto "${doc_api}" y guardo la respuesta en "que_hace"
    Then respondo la pregunta "What authentication is required?" basándome en el contexto "${doc_api}" y guardo la respuesta en "autenticacion"
    
    # Mostrar resultados
    Then muestro en consola el valor de la variable "conceptos_clave"
    Then muestro en consola el valor de la variable "resumen_doc"
    Then muestro en consola el valor de la variable "que_hace"
    Then muestro en consola el valor de la variable "autenticacion"

  Escenario: Moderación de contenido en tiempo real
    Given navego a "https://example.com/forum"
    And uso la configuración semántica por defecto
    
    # Usuario publica un comentario
    When escribo "Este es un comentario de prueba" en el formulario
    And hago click en "Publicar"
    And espero 1 segundo
    
    # Extraer comentario publicado
    And extraigo el texto del elemento "Último comentario" con identificador "$.FORUM.last_comment" y lo guardo en "comentario_publicado"
    
    # Análisis de moderación
    Then verifico que el texto "${comentario_publicado}" no es tóxico
    Then el sentimiento de la variable "comentario_publicado" debe ser "positivo"
    
    # Si pasa las validaciones, el comentario es aceptable

  Escenario: Agrupación automática de tickets de soporte
    # Simular múltiples tickets
    Given guardo "No puedo acceder a mi cuenta,Error al iniciar sesión,Olvidé mi contraseña,El producto llegó dañado,Quiero devolver un artículo,El paquete no llegó,¿Cómo cambio mi email?,¿Dónde está mi pedido?" en la variable "todos_tickets"
    
    # Agrupar en 3 categorías automáticamente
    Then agrupo los textos "${todos_tickets}" en 3 clusters y guardo los resultados en "categorias_tickets"
    And muestro en consola el valor de la variable "categorias_tickets"
    
    # Los tickets se agruparán automáticamente en:
    # - Cluster 1: Problemas de cuenta/acceso
    # - Cluster 2: Problemas con productos/entregas
    # - Cluster 3: Consultas generales

  Escenario: Validación de respuestas de LLM con múltiples criterios
    Given uso la configuración semántica por defecto
    And guardo "Our return policy allows you to return items within 30 days of purchase. Items must be in original condition with tags attached. Refunds are processed within 5-7 business days." en la variable "respuesta_llm"
    
    # 1. Verificar idioma correcto
    Then el idioma del texto "${respuesta_llm}" debe ser "inglés"
    
    # 2. Verificar que no es tóxico
    Then verifico que el texto "${respuesta_llm}" no es tóxico
    
    # 3. Verificar sentimiento apropiado
    Then el sentimiento de la variable "respuesta_llm" debe ser "neutral"
    
    # 4. Verificar similitud semántica con respuesta esperada
    Then el texto de la variable "respuesta_llm" debe ser semánticamente similar a "You can return products within 30 days"
    
    # 5. Extraer información clave
    Then extraigo las palabras clave del texto "${respuesta_llm}" y las guardo en "puntos_clave"
    
    # 6. Responder pregunta específica sobre la respuesta
    Then respondo la pregunta "How many days do I have to return?" basándome en el contexto "${respuesta_llm}" y guardo la respuesta en "dias_devolucion"
    
    # Mostrar resultados
    Then muestro en consola el valor de la variable "puntos_clave"
    Then muestro en consola el valor de la variable "dias_devolucion"

  Escenario: Traducción y validación multilingüe
    # Texto original en inglés
    Given guardo "Welcome to our application. Please login to continue." en la variable "texto_original"
    
    # Traducir a múltiples idiomas
    Then traduzco el texto "${texto_original}" de "en" a "es" y lo guardo en "texto_es"
    Then traduzco el texto "${texto_original}" de "en" a "fr" y lo guardo en "texto_fr"
    Then traduzco el texto "${texto_original}" de "en" a "de" y lo guardo en "texto_de"
    
    # Verificar que todas las traducciones son semánticamente similares al original
    Then el texto de la variable "texto_es" debe ser semánticamente similar a "${texto_original}"
    Then el texto de la variable "texto_fr" debe ser semánticamente similar a "${texto_original}"
    Then el texto de la variable "texto_de" debe ser semánticamente similar a "${texto_original}"
    
    # Mostrar traducciones
    Then muestro en consola el valor de la variable "texto_es"
    Then muestro en consola el valor de la variable "texto_fr"
    Then muestro en consola el valor de la variable "texto_de"
