"""
Script para vectorizar documentos y cargarlos en Supabase Vector Database
Usa Gemini para generar embeddings y Supabase para almacenarlos

Uso:
    python vectorize_documents_supabase.py

Requisitos:
    - pip install supabase google-genai
    - Variables de entorno: SUPABASE_URL, SUPABASE_KEY, GEMINI_API_KEY
"""

import os
from google import genai
from supabase import create_client
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración
SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

# Validar variables
if not all([SUPABASE_URL, SUPABASE_KEY, GEMINI_API_KEY]):
    raise ValueError("Faltan variables de entorno: SUPABASE_URL, SUPABASE_KEY, GEMINI_API_KEY")

# Conectar a Supabase
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
print(f"✓ Conectado a Supabase: {SUPABASE_URL}")

# Conectar a Gemini
client = genai.Client(api_key=GEMINI_API_KEY)
print("✓ Conectado a Gemini API")

# ============================================================================
# DOCUMENTOS A VECTORIZAR
# ============================================================================
# Estos son chunks de tu knowledge base
# En producción, estos vendrían de archivos, bases de datos, APIs, etc.

documents = [
    {
        "content": "Política de devoluciones: Los clientes pueden devolver productos dentro de 30 días desde la fecha de compra. Los productos deben estar sin usar y con etiquetas originales. Se requiere el recibo original. El reembolso se procesa en 5-7 días hábiles.",
        "metadata": {
            "category": "devoluciones",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Horarios de atención: Lunes a Viernes de 9:00 AM a 6:00 PM. Sábados de 10:00 AM a 2:00 PM. Domingos y festivos cerrado. Contacto: teléfono 555-1234, email soporte@empresa.com",
        "metadata": {
            "category": "horarios",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Métodos de pago aceptados: Tarjetas de crédito (Visa, Mastercard, American Express), tarjetas de débito, PayPal, transferencia bancaria para compras mayores a $500, y efectivo en tienda física.",
        "metadata": {
            "category": "pagos",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Política de envío: Envío GRATIS en compras mayores a $50. Envío estándar 3-5 días hábiles ($5.99). Envío express 1-2 días hábiles ($15.99). Envío internacional 7-14 días hábiles. Seguimiento disponible para todos los envíos.",
        "metadata": {
            "category": "envios",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Garantía de productos: Todos los productos tienen garantía de 1 año contra defectos de fabricación. La garantía NO cubre daños por mal uso o accidentes. Para hacer válida la garantía, contactar a soporte@empresa.com con comprobante de compra.",
        "metadata": {
            "category": "garantia",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Soporte técnico: Disponible 24/7 por chat, email y teléfono. Tiempo de respuesta promedio: 2 horas. Para problemas urgentes, llamar al 555-URGENTE. Base de conocimientos en https://empresa.com/ayuda",
        "metadata": {
            "category": "soporte",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Proceso de compra: 1) Agregar productos al carrito, 2) Revisar carrito y aplicar cupones, 3) Ingresar dirección de envío, 4) Seleccionar método de envío, 5) Ingresar información de pago, 6) Confirmar pedido, 7) Recibir confirmación por email.",
        "metadata": {
            "category": "compras",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Quejas y reclamos: Todas las quejas se toman en serio. Tiempo de respuesta: 24-48 horas. Enviar email a quejas@empresa.com con número de pedido. Escalamiento a supervisor disponible. Compensación evaluada caso por caso.",
        "metadata": {
            "category": "quejas",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Términos y condiciones: Edad mínima 18 años. Los precios pueden cambiar sin previo aviso. Nos reservamos el derecho de cancelar pedidos sospechosos. Ver términos completos en https://empresa.com/terminos",
        "metadata": {
            "category": "terminos",
            "source": "manual_politicas",
            "language": "es"
        }
    },
    {
        "content": "Return policy: Customers can return products within 30 days from purchase date. Products must be unused with original tags. Original receipt required. Refund processed in 5-7 business days.",
        "metadata": {
            "category": "returns",
            "source": "policy_manual",
            "language": "en"
        }
    }
]

# ============================================================================
# GENERAR EMBEDDINGS Y CARGAR A SUPABASE
# ============================================================================

print(f"\n📝 Procesando {len(documents)} documentos...")

for i, doc in enumerate(documents, 1):
    try:
        # Generar embedding usando Gemini
        result = client.models.embed_content(
            model="gemini-embedding-001",
            contents=doc["content"]
        )
        embedding = result.embeddings[0].values
        
        # Insertar en Supabase
        data = {
            "content": doc["content"],
            "metadata": doc["metadata"],
            "embedding": embedding
        }
        
        response = supabase.table("knowledge_base").insert(data).execute()
        
        print(f"✓ [{i}/{len(documents)}] Documento vectorizado y cargado: {doc['metadata']['category']}")
        
    except Exception as e:
        print(f"✗ [{i}/{len(documents)}] Error procesando documento: {e}")

print("\n✅ Proceso completado!")
print(f"📊 Total documentos procesados: {len(documents)}")
print(f"🔍 Puedes buscar usando: busco en la tabla 'knowledge_base' el contexto más similar a 'tu query'")

# ============================================================================
# EJEMPLO DE BÚSQUEDA (OPCIONAL)
# ============================================================================

print("\n" + "="*80)
print("EJEMPLO DE BÚSQUEDA")
print("="*80)

query = "¿Cuál es la política de devoluciones?"
print(f"\n🔍 Query: {query}")

# Generar embedding de la query
result = client.models.embed_content(
    model="gemini-embedding-001",
    contents=query
)
query_embedding = result.embeddings[0].values

# Buscar en Supabase
result = supabase.rpc(
    'match_documents',
    {
        'query_embedding': query_embedding,
        'match_threshold': 0.7,
        'match_count': 3
    }
).execute()

if result.data:
    print(f"\n📄 Encontrados {len(result.data)} documentos similares:\n")
    for i, doc in enumerate(result.data, 1):
        print(f"{i}. Similitud: {doc.get('similarity', 0):.4f}")
        print(f"   Categoría: {doc.get('metadata', {}).get('category', 'N/A')}")
        print(f"   Contenido: {doc['content'][:100]}...")
        print()
else:
    print("⚠️ No se encontraron documentos similares")

print("\n💡 Tip: Usa este script para cargar tu propia knowledge base a Supabase")
print("💡 Luego usa los steps de Behave para testing automatizado")
