# Ejemplo de Generación de Respuestas con Gemini
# Útil para crear golden answers, testing de RAG, y comparación con tu IA

Feature: Generación de Respuestas con Gemini

  # ============================================================================
  # CASO DE USO 1: Generar Golden Answers (Respuestas de Referencia)
  # ============================================================================
  
  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Generar respuesta de referencia sobre horarios
    When Gemini genera la respuesta para el prompt "¿Cuál es el horario de atención al cliente?"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/golden_horarios.json"

  Scenario: Generar respuesta de referencia sobre devoluciones
    When Gemini genera la respuesta para el prompt "¿Cómo puedo devolver un producto?"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación del Juez en el archivo "evaluations/golden_devoluciones.json"

  # ============================================================================
  # CASO DE USO 2: Testing de RAG - Comparar tu IA vs Gemini
  # ============================================================================

Feature: Comparación de Respuestas: Tu IA vs Gemini

  Background:
    Given el contexto de reglas de negocio "product_docs" está cargado desde el archivo "context/product_documentation.txt"

  Scenario: Comparar respuesta de tu chatbot con Gemini
    # Generar respuesta de referencia con Gemini
    When Gemini genera la respuesta para el prompt "¿Cómo instalo el producto?"
    And guardo el valor de la variable "sut_response" en "gemini_answer"
    
    # Obtener respuesta de tu chatbot (implementa tu lógica aquí)
    When establezco la respuesta del SUT como "Para instalar el producto, descarga el instalador desde nuestra web, ejecútalo y sigue las instrucciones en pantalla. El proceso toma aproximadamente 5 minutos."
    
    # Comparar ambas respuestas
    Then el texto de la variable "sut_response" debe ser semánticamente similar a "{gemini_answer}"

  Scenario: Validar que tu IA responde tan bien como Gemini
    # Generar respuesta de referencia
    When Gemini genera la respuesta para el prompt "¿Qué garantía tiene el producto?"
    And guardo el valor de la variable "sut_response" en "gemini_answer"
    
    # Tu IA responde
    When establezco la respuesta del SUT como "El producto tiene garantía de 2 años contra defectos de fabricación. Puedes extenderla a 3 años comprando la garantía extendida."
    
    # Evaluar tu respuesta contra el contexto
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.85

  # ============================================================================
  # CASO DE USO 3: Generar Dataset de Entrenamiento
  # ============================================================================

Feature: Generar Dataset de Q&A para Entrenamiento

  Background:
    Given el contexto de reglas de negocio "faq" está cargado desde el archivo "context/faq_knowledge_base.txt"

  Scenario Outline: Generar múltiples pares pregunta-respuesta
    When Gemini genera la respuesta para el prompt "<pregunta>"
    And guardo el valor de la variable "sut_response" en "answer_<id>"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    And guardo la evaluación del Juez en el archivo "dataset/qa_pair_<id>.json"

    Examples:
      | id | pregunta                                    |
      | 01 | ¿Cuáles son los métodos de pago aceptados? |
      | 02 | ¿Cuánto tarda el envío?                     |
      | 03 | ¿Puedo cancelar mi pedido?                  |
      | 04 | ¿Ofrecen envío internacional?              |
      | 05 | ¿Cómo puedo rastrear mi pedido?            |

  # ============================================================================
  # CASO DE USO 4: Testing de Consistencia de Respuestas
  # ============================================================================

Feature: Validar Consistencia de Respuestas

  Background:
    Given el contexto de reglas de negocio "policies" está cargado desde el archivo "context/company_policies.txt"

  Scenario: Validar que preguntas similares obtienen respuestas consistentes
    # Primera pregunta
    When Gemini genera la respuesta para el prompt "¿Cuál es su política de privacidad?"
    And guardo el valor de la variable "sut_response" en "answer_1"
    
    # Pregunta similar con diferente redacción
    When Gemini genera la respuesta para el prompt "¿Cómo manejan mis datos personales?"
    And guardo el valor de la variable "sut_response" en "answer_2"
    
    # Las respuestas deben ser semánticamente similares
    Then el texto de la variable "answer_1" debe ser semánticamente similar a "{answer_2}"

  # ============================================================================
  # CASO DE USO 5: Testing con Múltiples Contextos
  # ============================================================================

Feature: Generación con Diferentes Contextos

  Scenario: Respuesta técnica vs respuesta para usuario final
    # Contexto técnico
    Given el contexto de reglas de negocio "technical" está cargado desde el archivo "context/technical_docs.txt"
    When Gemini genera la respuesta para el prompt "¿Cómo funciona la autenticación?"
    And guardo el valor de la variable "sut_response" en "technical_answer"
    
    # Contexto para usuario final
    Given el contexto de reglas de negocio "user_friendly" está cargado desde el archivo "context/user_guide.txt"
    When Gemini genera la respuesta para el prompt "¿Cómo funciona la autenticación?"
    And guardo el valor de la variable "sut_response" en "user_answer"
    
    # Ambas respuestas deben ser válidas pero con diferente nivel técnico
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.8

  # ============================================================================
  # CASO DE USO 6: Generación y Guardado de Respuestas
  # ============================================================================

Feature: Generar y Guardar Respuestas para Reutilización

  Background:
    Given el contexto de reglas de negocio "support" está cargado desde el archivo "context/support_knowledge.txt"

  Scenario: Generar respuestas y guardarlas en archivos
    When Gemini genera la respuesta para el prompt "¿Cómo reseteo mi contraseña?"
    And guardo el valor de la variable "sut_response" en el archivo "generated_answers/reset_password.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9
    
    When Gemini genera la respuesta para el prompt "¿Cómo actualizo mi perfil?"
    And guardo el valor de la variable "sut_response" en el archivo "generated_answers/update_profile.txt"
    Then el Juez Gemini debe validar la respuesta con un umbral mínimo de 0.9

# ============================================================================
# NOTAS DE USO
# ============================================================================

# Este ejemplo demuestra cómo usar Gemini para:
# 1. Generar respuestas de referencia (golden answers)
# 2. Comparar tu IA con Gemini
# 3. Crear datasets de entrenamiento
# 4. Validar consistencia de respuestas
# 5. Testing de RAG (Retrieval Augmented Generation)

# Ventajas:
# - No necesitas escribir manualmente las respuestas esperadas
# - Gemini genera respuestas basadas en tu documentación
# - Puedes comparar tu IA contra un modelo de referencia
# - Útil para crear datasets de Q&A automáticamente

# Flujo típico:
# 1. Cargar contexto de negocio (documentación, políticas, etc.)
# 2. Gemini genera respuesta basada en ese contexto
# 3. Evaluar la calidad de la respuesta generada
# 4. Opcionalmente: Comparar con respuesta de tu propia IA

  # ============================================================================
  # CASO DE USO 7: Validación Directa de Pregunta-Respuesta (NUEVO)
  # ============================================================================

Feature: Validación Directa de Respuestas del SUT

  Background:
    Given el contexto de reglas de negocio "customer_service" está cargado desde el archivo "context/customer_service_rules.txt"

  Scenario: Validar múltiples respuestas de tu chatbot de forma rápida
    # Validar respuesta sobre horarios
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es el horario de atención?" la respuesta "Lunes a viernes de 9am a 6pm, sábados de 10am a 2pm" es válida con umbral 0.8
    
    # Validar respuesta sobre devoluciones
    And el Juez Gemini valida que para la pregunta "¿Puedo devolver un producto?" la respuesta "Sí, aceptamos devoluciones dentro de 30 días con recibo original" es correcta con umbral 0.8
    
    # Validar respuesta sobre métodos de pago
    And valido con Gemini que según el contexto para la pregunta "¿Qué métodos de pago aceptan?" la respuesta "Aceptamos tarjetas de crédito, débito, PayPal y transferencia bancaria" es válida con umbral 0.8

  Scenario: Validar respuestas técnicas de tu sistema
    Given el contexto de reglas de negocio "tech_support" está cargado desde el archivo "context/tech_support_rules.txt"
    
    # Validar respuesta sobre instalación
    Then el Juez Gemini valida que para la pregunta "¿Cómo instalo el software?" la respuesta "Descarga el instalador desde nuestra web, ejecútalo como administrador y sigue el asistente de instalación" es correcta con umbral 0.85
    
    # Validar respuesta sobre requisitos del sistema
    And valido con Gemini que según el contexto para la pregunta "¿Qué requisitos necesito?" la respuesta "Windows 10 o superior, 8GB RAM, 2GB espacio en disco" es válida con umbral 0.85

  Scenario: Detectar respuestas incorrectas de tu chatbot
    # Esta respuesta debería fallar si el contexto dice que no están abiertos 24/7
    Then valido con Gemini que según el contexto para la pregunta "¿Están abiertos los fines de semana?" la respuesta "Sí, estamos abiertos 24/7 todos los días del año" es válida con umbral 0.8
    # Este test debería fallar y mostrar los errores detectados por Gemini

  Scenario: Comparar respuesta generada vs respuesta del SUT
    # Generar respuesta de referencia con Gemini
    When Gemini genera la respuesta para el prompt "¿Cuál es su política de envíos?"
    And guardo el valor de la variable "sut_response" en "gemini_reference"
    
    # Validar que la respuesta de tu chatbot es correcta
    Then valido con Gemini que según el contexto para la pregunta "¿Cuál es su política de envíos?" la respuesta "Envío gratis en pedidos superiores a 50€. Entrega en 24-48 horas en península" es válida con umbral 0.85
    
    # Opcionalmente: Comparar semánticamente ambas respuestas
    And el texto "Envío gratis en pedidos superiores a 50€. Entrega en 24-48 horas en península" debe ser semánticamente similar a "{gemini_reference}"

# ============================================================================
# NOTAS DE USO ACTUALIZADAS
# ============================================================================

# Este ejemplo demuestra cómo usar Gemini para:
# 1. Generar respuestas de referencia (golden answers)
# 2. Comparar tu IA con Gemini
# 3. Crear datasets de entrenamiento
# 4. Validar consistencia de respuestas
# 5. Testing de RAG (Retrieval Augmented Generation)
# 6. Validación directa de pares pregunta-respuesta (NUEVO)

# Ventajas del nuevo paso de validación directa:
# - Valida pregunta y respuesta en un solo paso
# - Ideal para testing rápido de FAQs
# - No necesitas pasos intermedios para establecer pregunta/respuesta
# - Perfecto para validar múltiples respuestas de tu chatbot

# Flujo típico con validación directa:
# 1. Cargar contexto de negocio (documentación, políticas, etc.)
# 2. Validar directamente pregunta + respuesta de tu SUT
# 3. Gemini evalúa si la respuesta es correcta según el contexto
# 4. Obtener score, errores críticos y sugerencias de mejora

# Flujo típico con generación:
# 1. Cargar contexto de negocio (documentación, políticas, etc.)
# 2. Gemini genera respuesta basada en ese contexto
# 3. Evaluar la calidad de la respuesta generada
# 4. Opcionalmente: Comparar con respuesta de tu propia IA
