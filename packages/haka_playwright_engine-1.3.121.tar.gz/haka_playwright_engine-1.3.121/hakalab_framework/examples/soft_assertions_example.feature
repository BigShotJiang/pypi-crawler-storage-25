# language: es
@soft_assertions_examples
Característica: Ejemplos de Soft Assertions
  Como tester
  Quiero ejecutar múltiples validaciones incluso si algunas fallan
  Para obtener un reporte completo de todos los problemas

  Antecedentes:
    Dado que navego a "https://the-internet.herokuapp.com/login"

  @soft_assertions @test1
  Escenario: Validar múltiples campos del formulario de login
    Cuando ingreso "tomsmith" en el campo con id "username"
    Y ingreso "SuperSecretPassword!" en el campo con id "password"
    Y hago click en el botón con css "button[type='submit']"
    Entonces verifico que el elemento con css ".flash.success" está visible
    Y verifico que el texto del elemento con css ".flash" contiene "You logged into a secure area!"
    Y verifico que el elemento con css "a[href='/logout']" está visible
    Y verifico que el texto del elemento con css "h2" contiene "Secure Area"

  @soft_assertions @test2
  Escenario: Validar formulario con credenciales inválidas (múltiples errores)
    Cuando ingreso "usuario_invalido" en el campo con id "username"
    Y ingreso "password_invalido" en el campo con id "password"
    Y hago click en el botón con css "button[type='submit']"
    # Estas validaciones fallarán pero todas se ejecutarán
    Entonces verifico que el elemento con css ".flash.success" está visible
    Y verifico que el texto del elemento con css ".flash" contiene "You logged into a secure area!"
    Y verifico que el elemento con css "a[href='/logout']" está visible

  @soft_assertions @test3
  Escenario: Validar múltiples elementos de la página de login
    Entonces verifico que el elemento con css "h2" está visible
    Y verifico que el texto del elemento con css "h2" contiene "Login Page"
    Y verifico que el elemento con id "username" está visible
    Y verifico que el elemento con id "password" está visible
    Y verifico que el elemento con css "button[type='submit']" está visible
    Y verifico que el elemento con css ".subheader" está visible

  @soft_assertions @test4
  Escenario: Validar atributos de elementos del formulario
    Entonces verifico que el elemento con id "username" tiene el atributo "type" con valor "text"
    Y verifico que el elemento con id "password" tiene el atributo "type" con valor "password"
    Y verifico que el elemento con css "button[type='submit']" tiene el atributo "type" con valor "submit"
    Y verifico que el elemento con css "button" contiene el texto "Login"

  @soft_assertions @test5
  Escenario: Validar API con múltiples campos (ejemplo con JSONPlaceholder)
    Dado que navego a "https://jsonplaceholder.typicode.com/users/1"
    Cuando extraigo el texto del elemento con css "pre" y lo guardo en "api_response"
    # Nota: Este es un ejemplo conceptual, en producción usarías steps de API
    Entonces verifico que la variable "api_response" contiene "Leanne Graham"
    Y verifico que la variable "api_response" contiene "Sincere@april.biz"
    Y verifico que la variable "api_response" contiene "1-770-736-8031"
    Y verifico que la variable "api_response" contiene "Kulas Light"

  @soft_assertions @test6
  Escenario: Validar tabla de datos (ejemplo con tabla HTML)
    Dado que navego a "https://the-internet.herokuapp.com/tables"
    Entonces verifico que el elemento con css "table#table1" está visible
    Y verifico que el elemento con xpath "//table[@id='table1']//th[text()='Last Name']" está visible
    Y verifico que el elemento con xpath "//table[@id='table1']//th[text()='First Name']" está visible
    Y verifico que el elemento con xpath "//table[@id='table1']//th[text()='Email']" está visible
    Y verifico que el elemento con xpath "//table[@id='table1']//th[text()='Due']" está visible

  @soft_assertions @test7
  Escenario: Validar navegación y elementos de múltiples páginas
    Dado que navego a "https://the-internet.herokuapp.com"
    Entonces verifico que el elemento con css "h1" está visible
    Y verifico que el texto del elemento con css "h1" contiene "Welcome to the-internet"
    Y verifico que el elemento con xpath "//a[contains(text(),'A/B Testing')]" está visible
    Y verifico que el elemento con xpath "//a[contains(text(),'Checkboxes')]" está visible
    Y verifico que el elemento con xpath "//a[contains(text(),'Dropdown')]" está visible

  @soft_assertions @test8
  Escenario: Validar formulario con campos vacíos (errores esperados)
    Cuando hago click en el botón con css "button[type='submit']"
    # Estas validaciones fallarán porque no ingresamos credenciales
    Entonces verifico que el elemento con css ".flash.success" está visible
    Y verifico que el texto del elemento con css ".flash" contiene "You logged into a secure area!"
    # Esta validación pasará
    Y verifico que el elemento con css ".flash.error" está visible
