"""
Plugin para integración con Jira y Xray.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.integrations import behave_hooks as _bh
from hakalab_framework.integrations.behave_hooks import (
    before_all_jira_xray,
    before_feature_jira_xray,
    after_scenario_jira_xray,
    after_feature_jira_xray
)


class JiraXrayPlugin(BasePlugin):
    """Plugin para integración con Jira y Xray."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si JIRA_ENABLED=true."""
        return os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Configura la integración con Jira/Xray."""
        if self.enabled:
            before_all_jira_xray(context)
    
    def before_feature(self, context, feature) -> None:
        """Hook antes de cada feature."""
        if self.enabled:
            before_feature_jira_xray(context, feature)
    
    def after_scenario(self, context, scenario) -> None:
        """Recopila resultados del escenario para Jira/Xray."""
        if self.enabled:
            after_scenario_jira_xray(context, scenario)
    
    def after_feature(self, context, feature) -> None:
        """Finaliza la feature en Jira/Xray."""
        if self.enabled:
            after_feature_jira_xray(context, feature)
    
    def after_all(self, context) -> None:
        """Procesa la integración con Jira/Xray.
        
        Si JiraConfigPlugin ya procesó adjuntos y comentarios, se salta
        la parte de Jira para evitar duplicados. Xray se procesa siempre.
        """
        if not self.enabled or not hasattr(context, 'jira_xray_hooks'):
            return

        hooks = context.jira_xray_hooks

        try:
            if getattr(context, '_jira_config_processed', False):
                # JiraConfigPlugin ya procesó adjuntos/comentarios de Jira
                print("\nℹ️ JiraConfigPlugin ya procesó adjuntos, saltando en JiraXrayPlugin")
                # Solo procesar Xray si está configurado
                if hasattr(hooks, 'xray') and hooks.xray and hooks.xray.is_configured:
                    # _last_feature es variable de módulo, no atributo de instancia
                    last_feature = _bh._last_feature
                    if last_feature:
                        hooks._process_xray_integration(last_feature)
            else:
                # Sin JiraConfigPlugin → flujo completo (Jira + Xray)
                hooks.after_all(context)

            print("\n✅ Integración Jira/Xray completada")
        except Exception as e:
            print(f"❌ Error en integración Jira/Xray: {e}")
