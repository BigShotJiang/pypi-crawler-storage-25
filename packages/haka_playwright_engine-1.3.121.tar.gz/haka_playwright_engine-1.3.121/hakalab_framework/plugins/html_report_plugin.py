"""
Plugin para generación de reportes HTML.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.core.behave_html_integration import (
    setup_html_reporting,
    before_feature_html,
    after_feature_html,
    before_scenario_html,
    after_scenario_html,
    after_step_html,
    generate_html_report
)


class HtmlReportPlugin(BasePlugin):
    """Plugin para reportes HTML personalizados."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si USE_HTML_REPORT=true."""
        return os.getenv('USE_HTML_REPORT', 'true').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Inicializa el sistema de reportes HTML."""
        if self.enabled:
            setup_html_reporting(context)
    
    def before_feature(self, context, feature) -> None:
        """Hook antes de cada feature."""
        if self.enabled:
            before_feature_html(context, feature)
    
    def before_scenario(self, context, scenario) -> None:
        """Hook antes de cada escenario."""
        if self.enabled:
            before_scenario_html(context, scenario)
    
    def after_step(self, context, step) -> None:
        """Registra el step en el reporte."""
        if self.enabled:
            after_step_html(context, step)
    
    def after_scenario(self, context, scenario) -> None:
        """Finaliza el escenario en el reporte."""
        if self.enabled:
            after_scenario_html(context, scenario)
    
    def after_feature(self, context, feature) -> None:
        """Finaliza la feature en el reporte."""
        if self.enabled:
            after_feature_html(context, feature)
    
    def after_all(self, context) -> None:
        """Genera el reporte HTML final."""
        if self.enabled:
            report_path = generate_html_report(context)
            if report_path:
                context.html_report_path = report_path
                print(f"\n📊 Reporte HTML generado: {report_path}")
