"""
Plugin para configuración de Jira desde archivo JSON.

Lee jira_config.json de la raíz del proyecto y aplica la configuración
para determinar qué adjuntos enviar, qué campos están disponibles,
y cómo se comporta la integración con Jira en cada hook.
"""
import os
import glob
from .base_plugin import BasePlugin
from hakalab_framework.core.jira_config_manager import JiraConfigManager
from hakalab_framework.integrations.jira_integration import JiraIntegration


class JiraConfigPlugin(BasePlugin):
    """Plugin que aplica la configuración de jira_config.json."""

    def __init__(self):
        self.config_manager = None
        self.jira = None
        super().__init__()

    def _is_enabled(self) -> bool:
        """Habilitado si JIRA_ENABLED=true y existe jira_config.json."""
        jira_enabled = os.getenv('JIRA_ENABLED', 'false').lower() == 'true'
        if not jira_enabled:
            return False
        # Intentar cargar la configuración
        self.config_manager = JiraConfigManager()
        return self.config_manager.is_loaded

    def before_all(self, context) -> None:
        """Carga la configuración y la expone en el contexto de Behave."""
        if not self.enabled or not self.config_manager:
            return

        # Exponer el config manager en el contexto
        context.jira_config = self.config_manager

        # Inicializar la integración con Jira
        self.jira = JiraIntegration()
        if not self.jira.is_configured:
            print("⚠️ JiraConfigPlugin: Jira no está configurado (variables de entorno)")
            return

        print(f"🔧 JiraConfigPlugin activo — adjuntar_html={self.config_manager.adjuntar_html}, "
              f"adjuntar_video={self.config_manager.adjuntar_video}, "
              f"adjuntar_screenshots={self.config_manager.adjuntar_screenshots}")
        tipos = self.config_manager.get_tipos_disponibles()
        if tipos:
            print(f"   Tipos de issue configurados: {', '.join(tipos)}")

    def after_scenario(self, context, scenario) -> None:
        """Recopila info del escenario con mapeo posicional de tags.

        Convención de tags por posición:
          1er tag Jira → tipo del tags[0] en jira_config.json (ej: Test)
          2do tag Jira → tipo del tags[1] en jira_config.json (ej: Historia)
          3er tag Jira → tipo del tags[2] en jira_config.json (ej: Bug)
        """
        if not self.enabled or not self.config_manager:
            return

        if not hasattr(context, '_jira_config_scenario_results'):
            context._jira_config_scenario_results = []

        # Extraer solo los tags que son issue keys de Jira (ej: PROJ-123)
        jira_tags = []
        for tag in (scenario.tags or []):
            key = self.jira.extract_issue_key_from_tag(tag) if self.jira else None
            if key:
                jira_tags.append(key)

        # Mapear por posición a los tipos del JSON
        tag_type_map = {}
        tipos_config = self.config_manager.tags  # lista ordenada del JSON
        for i, issue_key in enumerate(jira_tags):
            if i < len(tipos_config):
                tipo = tipos_config[i].get("tipo", "Desconocido")
                tag_type_map[issue_key] = tipo

        context._jira_config_scenario_results.append({
            'name': scenario.name,
            'status': scenario.status.name if hasattr(scenario.status, 'name') else str(scenario.status),
            'tags': list(scenario.tags) if scenario.tags else [],
            'jira_tags': jira_tags,
            'tag_type_map': tag_type_map,
            'feature': scenario.feature.name if scenario.feature else '',
        })

    def after_all(self, context) -> None:
        """Adjunta reportes y videos a las issues según la configuración.

        Usa el mapeo posicional de tags para saber qué tipo de issue es cada
        tag y aplicar la configuración correspondiente.

        Adjuntos (HTML, video, screenshots) van al Test (1er tag) y a la
        Historia (2do tag).  El comentario consolidado solo al Test.
        """
        if not self.enabled or not self.config_manager:
            return

        if not self.jira or not self.jira.is_configured:
            return

        print("\n📎 JiraConfigPlugin: Procesando según jira_config.json...")

        results = getattr(context, '_jira_config_scenario_results', [])
        if not results:
            print("   ℹ️ No hay resultados de escenarios para procesar")
            return

        # Consolidar el mapeo issue_key → tipo desde todos los escenarios
        # Usar lista ordenada para mantener el orden posicional
        seen_keys = set()
        ordered_tags = []  # [(issue_key, tipo), ...]
        for result in results:
            for key, tipo in result.get('tag_type_map', {}).items():
                if key not in seen_keys:
                    seen_keys.add(key)
                    ordered_tags.append((key, tipo))

        if not ordered_tags:
            print("   ℹ️ No se encontraron issue keys de Jira en los tags")
            return

        # Construir dict para acceso rápido
        global_tag_map = {k: t for k, t in ordered_tags}

        # Determinar qué tags reciben adjuntos (Test y Historia, posiciones 0 y 1)
        tags_para_adjuntos = []
        for issue_key, tipo in ordered_tags[:2]:  # Solo los 2 primeros
            if self.jira.issue_exists(issue_key):
                tags_para_adjuntos.append(issue_key)

        # Adjuntar HTML, video y screenshots a Test e Historia
        for issue_key in tags_para_adjuntos:
            self._adjuntar_html(context, issue_key)
            self._adjuntar_video(context, issue_key)
            self._adjuntar_screenshots(context, issue_key)

        # Comentario consolidado solo en el primer tag (Test)
        if tags_para_adjuntos:
            self._comentar_resultado(context, tags_para_adjuntos[0], results)

        # Procesar cada issue según su tipo (solo campos, sin adjuntos)
        for issue_key, tipo in ordered_tags:
            if not self.jira.issue_exists(issue_key):
                print(f"   ⚠️ Issue {issue_key} no existe en Jira, saltando")
                continue

            print(f"\n   🔗 Procesando {issue_key} (tipo: {tipo})")

            # Actualizar campos custom según el tipo
            self._actualizar_campos(issue_key, tipo, results)

        # Crear issues automáticas para escenarios fallidos sin 3er tag
        self._crear_issues_on_failure(context, results)

        # Marcar que JiraConfigPlugin ya procesó adjuntos y comentarios
        context._jira_config_processed = True

        print("\n✅ JiraConfigPlugin: Procesamiento completado")

    # ------------------------------------------------------------------
    # Métodos privados de adjuntos
    # ------------------------------------------------------------------

    def _adjuntar_html(self, context, issue_key: str):
        """Adjunta el reporte HTML si está configurado."""
        if not self.config_manager.adjuntar_html:
            return

        report_path = self._get_html_report_path(context)
        if report_path and os.path.exists(report_path):
            success = self.jira.attach_file_to_issue(issue_key, report_path)
            if success:
                print(f"   📄 Reporte HTML adjuntado a {issue_key}")
            else:
                print(f"   ❌ Error adjuntando reporte HTML a {issue_key}")
        else:
            print(f"   ⚠️ Reporte HTML no encontrado para adjuntar a {issue_key}")

    def _adjuntar_video(self, context, issue_key: str):
        """Adjunta el video de la ejecución si está configurado.

        Busca primero en context.saved_videos (videos renombrados por el framework)
        y como fallback busca el más reciente en VIDEO_DIR, ignorando archivos
        con nombre tipo UUID (temporales de Playwright).

        Si el archivo local tiene nombre UUID (fallback extremo), genera un
        nombre descriptivo para el adjunto en Jira.
        """
        if not self.config_manager.adjuntar_video:
            return

        video_path = self._get_latest_video(context)
        if not video_path or not os.path.exists(video_path):
            print(f"   ⚠️ Video no encontrado para adjuntar a {issue_key}")
            return

        import re
        video_basename = os.path.basename(video_path)

        # Si el archivo tiene nombre temporal (UUID con guiones o hash hex),
        # generar un nombre descriptivo para el adjunto en Jira
        temp_pattern = re.compile(
            r'^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}\.'  # UUID con guiones
            r'|^[0-9a-f]{20,}\.',                              # Hash hex largo sin guiones
            re.IGNORECASE
        )
        if temp_pattern.match(video_basename):
            import time
            ext = os.path.splitext(video_basename)[1]
            video_basename = f"video_ejecucion_{time.strftime('%Y%m%d_%H%M%S')}{ext}"

        success = self.jira.attach_file_to_issue(issue_key, video_path, filename=video_basename)
        if success:
            print(f"   🎬 Video adjuntado a {issue_key}: {video_basename}")
        else:
            print(f"   ❌ Error adjuntando video a {issue_key}")

    def _adjuntar_screenshots(self, context, issue_key: str):
        """Adjunta screenshots si está configurado."""
        if not self.config_manager.adjuntar_screenshots:
            return

        screenshots_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
        if not os.path.exists(screenshots_dir):
            print(f"   ⚠️ Directorio de screenshots no encontrado: {screenshots_dir}")
            return

        patterns = [os.path.join(screenshots_dir, f"*.{ext}") for ext in ("png", "jpg", "jpeg")]
        files = []
        for pattern in patterns:
            files.extend(glob.glob(pattern))

        if not files:
            print(f"   ⚠️ No se encontraron screenshots en {screenshots_dir}")
            return

        # Adjuntar los más recientes (máximo 10)
        files.sort(key=os.path.getmtime, reverse=True)
        for screenshot in files[:10]:
            success = self.jira.attach_file_to_issue(issue_key, screenshot)
            if success:
                print(f"   📸 Screenshot adjuntado a {issue_key}: {os.path.basename(screenshot)}")

    def _comentar_resultado(self, context, issue_key: str, results: list):
        """Agrega un comentario único consolidado con mensaje QA + resumen de resultados.

        Unifica en un solo comentario:
          - El mensaje de JIRA_COMMENT_MESSAGE con timestamp
          - El resumen de escenarios (passed/failed/skipped)
          - Detalle de escenarios fallidos (si los hay)
        """
        if not self.config_manager.comentar_resultado:
            return

        from datetime import datetime

        total = len(results)
        passed = sum(1 for r in results if r['status'] == 'passed')
        failed = sum(1 for r in results if r['status'] == 'failed')
        skipped = total - passed - failed

        # Mensaje QA con timestamp (antes venía de attach_report_to_issue)
        qa_message = self.jira.jira_comment_message if self.jira else 'Reporte prueba de QA'
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        comment = (
            f"{qa_message} - {timestamp}\n\n"
            f"📊 Resultado de ejecución automatizada\n\n"
            f"Total: {total} | ✅ Passed: {passed} | ❌ Failed: {failed} | ⏭️ Skipped: {skipped}\n\n"
        )

        if failed > 0:
            comment += "Escenarios fallidos:\n"
            for r in results:
                if r['status'] == 'failed':
                    comment += f"  - {r['name']}\n"

        success = self.jira.add_comment_to_issue(issue_key, comment)
        if success:
            print(f"   💬 Comentario consolidado agregado a {issue_key}")

    def _actualizar_campos(self, issue_key: str, tipo: str, results: list):
        """Actualiza campos custom de la issue según el tipo y los resultados.

        Usa los campos definidos en jira_config.json para el tipo correspondiente.
        Solo considera los escenarios que referencian esta issue_key en sus tags,
        para no contaminar el estado de una issue con resultados de otros escenarios.
        """
        campos = self.config_manager.get_campos_por_tipo(tipo)
        if not campos:
            return

        # Filtrar solo los escenarios que referencian esta issue
        relevant = [r for r in results if issue_key in r.get('jira_tags', [])]
        if not relevant:
            relevant = results  # Fallback si no hay match (no debería pasar)

        # Determinar el estado basado SOLO en los escenarios relevantes
        all_passed = all(r['status'] == 'passed' for r in relevant)
        has_failed = any(r['status'] == 'failed' for r in relevant)

        for campo in campos:
            campo_id = campo.get("id", "")
            valores = campo.get("valores", [])

            if not campo_id or not valores:
                continue

            # Determinar el valor a asignar según el campo
            valor = self._resolver_valor_campo(campo_id, valores, all_passed, has_failed)

            if valor:
                success = self.jira.update_issue_field(issue_key, campo_id, valor)
                if success:
                    print(f"   📝 Campo '{campo_id}' de {issue_key} actualizado a '{valor}'")
                else:
                    print(f"   ⚠️ No se pudo actualizar campo '{campo_id}' de {issue_key}")

    def _crear_issues_on_failure(self, context, results: list):
        """Crea issues automáticas para escenarios fallidos y las vincula con Test e Historia.

        Reglas:
          1. crear_issue_on_failure debe ser true
          2. tipo_issue_on_failure debe estar definido (ej: "Bug")
          3. Si el escenario NO tiene 3er tag Jira → crear la issue
          4. Si el escenario tiene 3er tag Jira → consultar el tipo real vía API:
             - Si es del mismo tipo que tipo_issue_on_failure → NO crear (ya existe)
             - Si es de otro tipo (Task, Ejecución, etc.) → SÍ crear
          5. Si vincular_bug_con_tags es true → vincular el Bug con Test e Historia
        """
        if not self.config_manager.crear_issue_on_failure:
            return

        tipo_issue = self.config_manager.tipo_issue_on_failure
        if not tipo_issue:
            print("   ⚠️ crear_issue_on_failure activo pero tipo_issue_on_failure no definido")
            return

        failed_scenarios = [r for r in results if r['status'] == 'failed']
        if not failed_scenarios:
            return

        vincular = self.config_manager.vincular_bug_con_tags
        tipo_vinculo = self.config_manager.tipo_vinculo

        print(f"\n   🐛 Evaluando creación automática de issues tipo '{tipo_issue}'...")

        for scenario in failed_scenarios:
            jira_tags = scenario.get('jira_tags', [])
            scenario_name = scenario.get('name', 'Sin nombre')

            # Verificar el 3er tag (posición del tipo Bug en el JSON)
            tercer_tag = jira_tags[2] if len(jira_tags) >= 3 else None

            if tercer_tag:
                # Consultar el tipo real de la issue vía API REST
                tipo_real = self.jira.get_issue_type(tercer_tag)
                if tipo_real and tipo_real.lower() == tipo_issue.lower():
                    print(f"   ℹ️ Escenario '{scenario_name}' ya tiene {tipo_issue} "
                          f"asociado ({tercer_tag}), no se crea duplicado")
                    continue
                else:
                    print(f"   ℹ️ Escenario '{scenario_name}' tiene tag {tercer_tag} "
                          f"de tipo '{tipo_real}' (no es {tipo_issue}), creando issue...")
            else:
                print(f"   ℹ️ Escenario '{scenario_name}' sin 3er tag, creando {tipo_issue}...")

            # Construir descripción
            feature_name = scenario.get('feature', 'Feature desconocida')
            description = (
                f"Issue creada automáticamente por fallo en prueba automatizada.\n\n"
                f"Feature: {feature_name}\n"
                f"Escenario: {scenario_name}\n"
                f"Tags: {', '.join(scenario.get('tags', []))}"
            )

            # Crear la issue
            issue_key = self.jira.create_issue(
                summary=f"[Auto] Fallo en: {scenario_name}",
                description=description,
                issue_type=tipo_issue,
                priority="Medium",
                labels=["automated-test", "auto-created"]
            )

            if issue_key:
                print(f"   ✅ Issue {issue_key} creada para escenario '{scenario_name}'")

                # Vincular el Bug con Test e Historia (los primeros 2 tags)
                if vincular:
                    for target_key in jira_tags[:2]:
                        if self.jira.issue_exists(target_key):
                            tipo_target = scenario.get('tag_type_map', {}).get(target_key, 'Desconocido')
                            success = self.jira.link_issues(issue_key, target_key, tipo_vinculo)
                            if success:
                                print(f"   🔗 {tipo_issue} {issue_key} vinculado con "
                                      f"{tipo_target} {target_key} ({tipo_vinculo})")
                            else:
                                print(f"   ⚠️ No se pudo vincular {issue_key} con {target_key}")

                # Adjuntar reporte y video a la nueva issue también
                self._adjuntar_html(context, issue_key)
                self._adjuntar_video(context, issue_key)
            else:
                print(f"   ❌ No se pudo crear issue para escenario '{scenario_name}'")

    def _resolver_valor_campo(self, campo_id: str, valores: list,
                               all_passed: bool, has_failed: bool) -> str:
        """Determina qué valor asignar a un campo según el resultado.

        Lógica:
          - Si el campo tiene "Passed"/"Failed" en sus valores → usa el resultado
          - Si el campo tiene un solo valor → lo usa directamente (ej: "Automatizado")
          - Si el campo tiene "Sí"/"No" → usa "Sí" si pasó, "No" si falló
        """
        valores_lower = [v.lower() for v in valores]

        # Campos de estado (Passed/Failed)
        if "passed" in valores_lower and "failed" in valores_lower:
            if all_passed:
                return next(v for v in valores if v.lower() == "passed")
            elif has_failed:
                return next(v for v in valores if v.lower() == "failed")

        # Campos booleanos (Sí/No)
        if "sí" in valores_lower and "no" in valores_lower:
            return "Sí" if all_passed else "No"

        # Campos con un solo valor (se asigna siempre, ej: "Automatizado")
        if len(valores) == 1:
            return valores[0]

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_html_report_path(self, context) -> str:
        """Obtiene la ruta del reporte HTML más reciente."""
        if hasattr(context, 'html_report_path'):
            return context.html_report_path

        html_reports_dir = os.getenv('HTML_REPORTS_DIR', 'html-reports')
        if os.path.exists(html_reports_dir):
            html_files = glob.glob(os.path.join(html_reports_dir, "*.html"))
            if html_files:
                return max(html_files, key=os.path.getmtime)

        for path in ['reports/report.html', 'report.html']:
            if os.path.exists(path):
                return path
        return None

    def _get_latest_video(self, context) -> str:
        """Obtiene la ruta del video más reciente.

        Prioridad:
          1. video_manager.last_consolidated_video (video con intro, ya renombrado)
          2. context.saved_videos (videos renombrados por el framework)
          3. context.video_path
          4. Buscar en VIDEO_DIR excluyendo base.mp4
        """
        # 1. Video consolidado con intro
        try:
            from hakalab_framework.core.video_manager import last_consolidated_video
            if last_consolidated_video and os.path.exists(last_consolidated_video):
                return last_consolidated_video
        except ImportError:
            pass

        # 2. Videos guardados por el framework
        if hasattr(context, 'saved_videos') and context.saved_videos:
            for video in reversed(context.saved_videos):
                if os.path.exists(video):
                    return video

        # 3. Video path explícito en contexto
        if hasattr(context, 'video_path') and context.video_path:
            if os.path.exists(context.video_path):
                return context.video_path

        # 4. Buscar en VIDEO_DIR, excluyendo base.mp4 (video intro)
        video_dir = os.getenv('VIDEO_DIR', 'videos')
        if os.path.exists(video_dir):
            video_files = []
            for ext in ("webm", "mp4", "avi"):
                for f in glob.glob(os.path.join(video_dir, f"*.{ext}")):
                    basename = os.path.basename(f)
                    if basename.lower() == 'base.mp4':
                        continue
                    video_files.append(f)

            if video_files:
                return max(video_files, key=os.path.getmtime)

        return None
