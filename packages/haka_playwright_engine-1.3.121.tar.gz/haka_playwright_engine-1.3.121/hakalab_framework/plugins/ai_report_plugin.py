"""
Plugin para generación de reportes de validaciones IA.
"""
import os
from .base_plugin import BasePlugin


class AIReportPlugin(BasePlugin):
    """Plugin para reportes de validaciones IA (Gemini, Semántica, RAG)."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si GENERATE_AI_REPORT=true."""
        return os.getenv('GENERATE_AI_REPORT', 'true').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Inicializa el generador de reportes IA."""
        if self.enabled:
            from hakalab_framework.core.ai_report_generator import AIReportGenerator
            context.ai_report_generator = AIReportGenerator()
            context.logger.info("✅ Generador de reportes IA inicializado")
    
    def after_all(self, context) -> None:
        """Genera el reporte de validaciones IA."""
        if self.enabled and hasattr(context, 'ai_report_generator'):
            try:
                # Generar el reporte (el generador usa AI_REPORT_PATH del .env)
                output_path = context.ai_report_generator.generate_report()
                
                if output_path:
                    context.ai_report_path = output_path
                    print(f"\n📊 Reporte de validaciones IA generado: {output_path}")
                else:
                    context.logger.info("ℹ️  No se generó reporte IA (sin evaluaciones)")
            except Exception as e:
                context.logger.error(f"⚠️ Error generando reporte de IA: {e}")
