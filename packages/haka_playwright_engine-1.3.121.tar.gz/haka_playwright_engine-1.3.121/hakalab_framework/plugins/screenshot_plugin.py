"""
Plugin para captura de screenshots.
"""
import os
from .base_plugin import BasePlugin
from hakalab_framework.core.screenshot_manager import (
    take_screenshot,
    take_screenshot_on_failure,
    cleanup_directories,
    get_screenshots_summary
)


class ScreenshotPlugin(BasePlugin):
    """Plugin para captura automática de screenshots."""
    
    def _is_enabled(self) -> bool:
        """Plugin habilitado si HTML_REPORT_CAPTURE_ALL_STEPS=true."""
        return os.getenv('HTML_REPORT_CAPTURE_ALL_STEPS', 'true').lower() == 'true'
    
    def before_all(self, context) -> None:
        """Limpia directorios de screenshots si está configurado."""
        if self.enabled:
            cleanup_directories()
    
    def after_step(self, context, step) -> None:
        """Captura screenshot después de cada step (web, escritorio o mobile)."""
        if not self.enabled:
            return
        try:
            step_name = step.name.replace(' ', '_').replace('"', '').replace("'", '')
            screenshot_name = f"step_{step.line}_{step_name[:50]}"

            # Modo mobile: capturar con Appium
            if getattr(context, '_current_step_is_mobile', False) or getattr(context, 'report_mode', None) == 'mobile':
                if hasattr(context, 'appium_manager') and context.appium_manager and getattr(context.appium_manager, 'driver', None):
                    path = context.appium_manager.take_screenshot(screenshot_name)
                    if path and hasattr(context, 'html_reporter'):
                        context._last_mobile_screenshot = path
                return

            # Modo escritorio: capturar pantalla completa con PyAutoGUI
            if getattr(context, 'desktop_mode', False):
                if hasattr(context, 'desktop_manager') and context.desktop_manager:
                    path = context.desktop_manager.take_desktop_screenshot(screenshot_name)
                    # Registrar en el reporte HTML
                    if path and hasattr(context, 'html_reporter'):
                        context._last_desktop_screenshot = path
                return

            # Modo web: capturar con Playwright
            if hasattr(context, 'page') and context.page:
                take_screenshot(context, screenshot_name)
        except Exception as e:
            if hasattr(context, 'logger'):
                context.logger.debug(f"Error capturando screenshot: {e}")
    
    def after_scenario(self, context, scenario) -> None:
        """Captura screenshot en caso de fallo (web, escritorio o mobile)."""
        if not self.enabled:
            return
        try:
            # Modo mobile: capturar con Appium en fallo
            if getattr(context, 'report_mode', None) == 'mobile' or (hasattr(context, 'appium_manager') and context.appium_manager and getattr(context.appium_manager, 'driver', None)):
                if scenario.status.name in ('failed', 'error'):
                    context.appium_manager.take_screenshot(f"FALLO_{scenario.name[:40]}")
                return

            # Modo escritorio: capturar pantalla completa en fallo
            if getattr(context, 'desktop_mode', False):
                if scenario.status.name in ('failed', 'error'):
                    if hasattr(context, 'desktop_manager') and context.desktop_manager:
                        context.desktop_manager.take_desktop_screenshot(
                            f"FALLO_{scenario.name[:40]}"
                        )
                return

            # Modo web: comportamiento original
            take_screenshot_on_failure(context, scenario)
        except Exception as e:
            if hasattr(context, 'logger'):
                context.logger.debug(f"Error capturando screenshot de fallo: {e}")
    
    def after_all(self, context) -> None:
        """Muestra resumen de screenshots capturados."""
        if self.enabled:
            try:
                summary = get_screenshots_summary()
                if summary["total"] > 0:
                    print(f"\n📸 Screenshots: {summary['total']} total, {summary['failed']} fallos")
            except Exception as e:
                context.logger.debug(f"Error obteniendo resumen de screenshots: {e}")
