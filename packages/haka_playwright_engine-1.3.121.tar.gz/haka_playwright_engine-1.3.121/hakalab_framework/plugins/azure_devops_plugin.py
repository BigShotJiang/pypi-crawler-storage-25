#!/usr/bin/env python3
"""
Plugin para integración con Azure DevOps basado en azure_devops_config.json.

Sigue la misma lógica que JiraConfigPlugin:
  - Mapeo posicional de tags a tipos de work item
  - Adjuntos (HTML, video, screenshots) a los 2 primeros tags
  - Actualización de campos custom por tipo de work item
  - Comentario consolidado solo al 1er tag (Test Case)
"""
import os
import re
import glob
from datetime import datetime
from .base_plugin import BasePlugin
from hakalab_framework.core.azure_devops_config_manager import AzureDevOpsConfigManager
from hakalab_framework.core.azure_devops_manager import AzureDevOpsManager


class AzureDevOpsPlugin(BasePlugin):
    """Plugin que aplica la configuración de azure_devops_config.json."""

    def __init__(self):
        self.config_manager = None
        self.azure = None
        super().__init__()

    def _is_enabled(self) -> bool:
        enabled = os.getenv('AZURE_DEVOPS_ENABLED', 'false').lower() == 'true'
        if not enabled:
            return False
        self.config_manager = AzureDevOpsConfigManager()
        return self.config_manager.is_loaded

    def before_all(self, context) -> None:
        if not self.enabled or not self.config_manager:
            return
        self.azure = AzureDevOpsManager(context)
        if not self.azure.enabled:
            print("⚠️ AzureDevOpsPlugin: configuración incompleta")
            return
        context.azure_devops_config = self.config_manager
        context.azure_devops = self.azure

        print(f"🔵 AzureDevOpsPlugin activo — html={self.config_manager.adjuntar_html}, "
              f"video={self.config_manager.adjuntar_video}")
        tipos = self.config_manager.get_tipos_disponibles()
        if tipos:
            print(f"   Tipos de work item: {', '.join(tipos)}")

    def after_scenario(self, context, scenario) -> None:
        """Recopila info del escenario con mapeo posicional de tags."""
        if not self.enabled or not self.config_manager or not self.azure:
            return
        if not self.azure.enabled:
            return
        if not hasattr(context, '_azure_config_scenario_results'):
            context._azure_config_scenario_results = []

        wi_tags = []
        for tag in (scenario.tags or []):
            wid = self.azure._extract_work_item_id(tag)
            if wid:
                wi_tags.append(wid)

        tag_type_map = {}
        tipos_config = self.config_manager.tags
        for i, wid in enumerate(wi_tags):
            if i < len(tipos_config):
                tag_type_map[wid] = tipos_config[i].get("tipo", "Desconocido")

        context._azure_config_scenario_results.append({
            'name': scenario.name,
            'status': scenario.status.name if hasattr(scenario.status, 'name') else str(scenario.status),
            'tags': list(scenario.tags) if scenario.tags else [],
            'wi_tags': wi_tags,
            'tag_type_map': tag_type_map,
            'feature': scenario.feature.name if scenario.feature else '',
        })

    def after_all(self, context) -> None:
        """Adjunta reportes/video y actualiza campos según el JSON."""
        if not self.enabled or not self.config_manager:
            return
        if not self.azure or not self.azure.enabled:
            return

        print("\n📎 AzureDevOpsPlugin: Procesando según azure_devops_config.json...")

        results = getattr(context, '_azure_config_scenario_results', [])
        if not results:
            print("   ℹ️ No hay resultados de escenarios para procesar")
            return

        # Consolidar mapeo wid → tipo (orden posicional)
        seen = set()
        ordered_tags = []
        for r in results:
            for wid, tipo in r.get('tag_type_map', {}).items():
                if wid not in seen:
                    seen.add(wid)
                    ordered_tags.append((wid, tipo))

        if not ordered_tags:
            print("   ℹ️ No se encontraron work item IDs en los tags")
            return

        # Adjuntos van a los 2 primeros tags (Test Case y User Story)
        tags_para_adjuntos = [wid for wid, _ in ordered_tags[:2]]

        for wid in tags_para_adjuntos:
            self._adjuntar_html(context, wid)
            self._adjuntar_video(context, wid)
            self._adjuntar_screenshots(context, wid)

        # Comentario consolidado solo al 1er tag
        if tags_para_adjuntos:
            self._comentar_resultado(context, tags_para_adjuntos[0], results)

        # Actualizar campos por tipo de work item
        for wid, tipo in ordered_tags:
            print(f"\n   🔗 Procesando work item {wid} (tipo: {tipo})")
            self._actualizar_campos(wid, tipo, results)

        # Crear issues automáticas para escenarios fallidos
        self._crear_issues_on_failure(context, results)

        print("\n✅ AzureDevOpsPlugin: Procesamiento completado")

    # ------------------------------------------------------------------
    # Métodos privados de adjuntos
    # ------------------------------------------------------------------

    def _adjuntar_html(self, context, wid: int):
        if not self.config_manager.adjuntar_html:
            return
        report_path = self._get_html_report_path(context)
        if report_path and os.path.exists(report_path):
            success = self.azure.attach_file_to_work_item(
                wid, report_path,
                comment=f"Reporte HTML - {self._timestamp()}"
            )
            if success:
                print(f"   📄 Reporte HTML adjuntado a work item {wid}")
            else:
                print(f"   ❌ Error adjuntando HTML a work item {wid}")
        else:
            print(f"   ⚠️ Reporte HTML no encontrado")

    def _adjuntar_video(self, context, wid: int):
        if not self.config_manager.adjuntar_video:
            return
        video_path = self._get_latest_video(context)
        if not video_path or not os.path.exists(video_path):
            print(f"   ⚠️ Video no encontrado para work item {wid}")
            return

        video_basename = os.path.basename(video_path)
        temp_pattern = re.compile(
            r'^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}\.'
            r'|^[0-9a-f]{20,}\.',
            re.IGNORECASE
        )
        if temp_pattern.match(video_basename):
            import time
            ext = os.path.splitext(video_basename)[1]
            video_basename = f"video_ejecucion_{time.strftime('%Y%m%d_%H%M%S')}{ext}"

        success = self.azure.attach_file_to_work_item(
            wid, video_path,
            comment=f"Video de ejecución - {self._timestamp()}"
        )
        if success:
            print(f"   🎬 Video adjuntado a work item {wid}: {video_basename}")
        else:
            print(f"   ❌ Error adjuntando video a work item {wid}")

    def _adjuntar_screenshots(self, context, wid: int):
        if not self.config_manager.adjuntar_screenshots:
            return
        screenshots_dir = os.getenv('SCREENSHOTS_DIR', 'screenshots')
        if not os.path.exists(screenshots_dir):
            return
        patterns = [os.path.join(screenshots_dir, f"*.{ext}") for ext in ("png", "jpg", "jpeg")]
        files = []
        for p in patterns:
            files.extend(glob.glob(p))
        if not files:
            return
        files.sort(key=os.path.getmtime, reverse=True)
        for screenshot in files[:10]:
            success = self.azure.attach_file_to_work_item(
                wid, screenshot,
                comment=f"Screenshot - {self._timestamp()}"
            )
            if success:
                print(f"   📸 Screenshot adjuntado a {wid}: {os.path.basename(screenshot)}")

    def _comentar_resultado(self, context, wid: int, results: list):
        """Agrega comentario consolidado con resumen de resultados."""
        if not self.config_manager.comentar_resultado:
            return
        total = len(results)
        passed = sum(1 for r in results if r['status'] == 'passed')
        failed = sum(1 for r in results if r['status'] == 'failed')
        skipped = total - passed - failed

        comment = (
            f"Resultado de ejecución automatizada - {self._timestamp()}\n\n"
            f"Total: {total} | Passed: {passed} | Failed: {failed} | Skipped: {skipped}\n\n"
        )
        if failed > 0:
            comment += "Escenarios fallidos:\n"
            for r in results:
                if r['status'] == 'failed':
                    comment += f"  - {r['name']}\n"

        success = self.azure.add_comment_to_work_item(wid, comment)
        if success:
            print(f"   💬 Comentario consolidado agregado a work item {wid}")

    def _actualizar_campos(self, wid: int, tipo: str, results: list):
        """Actualiza campos custom del work item según el tipo y resultados."""
        campos = self.config_manager.get_campos_por_tipo(tipo)
        if not campos:
            return

        all_passed = all(r['status'] == 'passed' for r in results)
        has_failed = any(r['status'] == 'failed' for r in results)

        for campo in campos:
            campo_id = campo.get("id", "")
            valores = campo.get("valores", [])
            if not campo_id or not valores:
                continue

            valor = self._resolver_valor_campo(valores, all_passed, has_failed)
            if valor:
                success = self.azure.update_work_item_field(wid, campo_id, valor)
                if success:
                    print(f"   📝 Campo '{campo_id}' de {wid} actualizado a '{valor}'")
                else:
                    print(f"   ⚠️ No se pudo actualizar campo '{campo_id}' de {wid}")

    # ------------------------------------------------------------------
    # Creación automática de issues en caso de error
    # ------------------------------------------------------------------

    def _crear_issues_on_failure(self, context, results: list):
        """Crea work items automáticos para escenarios fallidos.

        Reglas:
          1. crear_issue_on_failure debe ser true en el JSON
          2. tipo_issue_on_failure define el tipo (ej: "Bug")
          3. Solo se crean para escenarios con status 'failed'
          4. Se adjunta HTML y video al work item creado
          5. Se vincula el Bug con los work items existentes del escenario
        """
        if not self.config_manager.crear_issue_on_failure:
            return

        tipo_issue = self.config_manager.tipo_issue_on_failure
        if not tipo_issue:
            print("   ⚠️ crear_issue_on_failure activo pero tipo_issue_on_failure no definido")
            return

        failed_scenarios = [r for r in results if r['status'] == 'failed']
        if not failed_scenarios:
            return

        print(f"\n   🐛 Evaluando creación automática de work items tipo '{tipo_issue}'...")

        for scenario in failed_scenarios:
            scenario_name = scenario.get('name', 'Sin nombre')
            feature_name = scenario.get('feature', 'Feature desconocida')
            tags_str = ', '.join(scenario.get('tags', []))
            wi_tags = scenario.get('wi_tags', [])

            description = (
                f"<b>Work item creado automáticamente por fallo en prueba automatizada.</b><br><br>"
                f"<b>Feature:</b> {feature_name}<br>"
                f"<b>Escenario:</b> {scenario_name}<br>"
                f"<b>Tags:</b> {tags_str}<br>"
                f"<b>Fecha:</b> {self._timestamp()}"
            )

            wi_id = self.azure.create_work_item(
                work_item_type=tipo_issue,
                title=f"[Auto] Fallo en: {scenario_name}",
                description=description
            )

            if wi_id:
                print(f"   ✅ Work item {wi_id} ({tipo_issue}) creado para '{scenario_name}'")

                # Vincular con los work items existentes del escenario
                for target_wid in wi_tags:
                    tipo_target = scenario.get('tag_type_map', {}).get(target_wid, 'Desconocido')
                    success = self.azure.link_work_items(wi_id, target_wid)
                    if success:
                        print(f"   🔗 {tipo_issue} {wi_id} vinculado con {tipo_target} {target_wid}")

                self._adjuntar_html(context, wi_id)
                self._adjuntar_video(context, wi_id)
            else:
                print(f"   ❌ No se pudo crear work item para escenario '{scenario_name}'")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _timestamp() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def _resolver_valor_campo(valores: list, all_passed: bool, has_failed: bool) -> str:
        """Determina qué valor asignar a un campo según el resultado."""
        valores_lower = [v.lower() for v in valores]

        # Campos de estado (Passed/Failed)
        if "passed" in valores_lower and "failed" in valores_lower:
            if all_passed:
                return next(v for v in valores if v.lower() == "passed")
            elif has_failed:
                return next(v for v in valores if v.lower() == "failed")

        # Campos booleanos (Sí/No)
        if "sí" in valores_lower and "no" in valores_lower:
            return "Sí" if all_passed else "No"

        # Campos con un solo valor (se asigna siempre)
        if len(valores) == 1:
            return valores[0]

        return None

    def _get_html_report_path(self, context) -> str:
        """Obtiene la ruta del reporte HTML más reciente."""
        if hasattr(context, 'html_report_path'):
            return context.html_report_path

        html_reports_dir = os.getenv('HTML_REPORTS_DIR', 'html-reports')
        if os.path.exists(html_reports_dir):
            html_files = glob.glob(os.path.join(html_reports_dir, "*.html"))
            if html_files:
                return max(html_files, key=os.path.getmtime)

        for path in ['reports/report.html', 'report.html']:
            if os.path.exists(path):
                return path
        return None

    @staticmethod
    def _get_latest_video(context) -> str:
        """Obtiene la ruta del video más reciente.

        Prioridad:
          1. video_manager.last_consolidated_video (video con intro, ya renombrado)
          2. context.saved_videos
          3. context.video_path
          4. Buscar en VIDEO_DIR excluyendo base.mp4
        """
        # 1. Video consolidado con intro
        try:
            from hakalab_framework.core.video_manager import last_consolidated_video
            if last_consolidated_video and os.path.exists(last_consolidated_video):
                return last_consolidated_video
        except ImportError:
            pass

        # 2. Videos renombrados por el framework
        if hasattr(context, 'saved_videos') and context.saved_videos:
            for video in reversed(context.saved_videos):
                if os.path.exists(video):
                    return video

        # 3. Video path explícito
        if hasattr(context, 'video_path') and context.video_path:
            if os.path.exists(context.video_path):
                return context.video_path

        # 4. Buscar en VIDEO_DIR, excluyendo base.mp4
        video_dir = os.getenv('VIDEO_DIR', 'videos')
        if not os.path.exists(video_dir):
            return None

        video_files = []
        for ext in ("webm", "mp4", "avi"):
            for f in glob.glob(os.path.join(video_dir, f"*.{ext}")):
                basename = os.path.basename(f)
                if basename.lower() == 'base.mp4':
                    continue
                video_files.append(f)

        if video_files:
            return max(video_files, key=os.path.getmtime)

        return None
