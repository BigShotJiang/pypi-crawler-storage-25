#!/usr/bin/env python3
"""
Script de debug para verificar la configuración de SCREENSHOT_FULL_PAGE
"""
import os
from dotenv import load_dotenv
from pathlib import Path

# Cargar .env
if Path('.env').exists():
    load_dotenv('.env')
    print("✅ Archivo .env encontrado y cargado")
else:
    print("❌ Archivo .env NO encontrado")

# Leer la variable
screenshot_full_page_raw = os.getenv('SCREENSHOT_FULL_PAGE', 'NOT_SET')
print(f"\n📋 Valor RAW de SCREENSHOT_FULL_PAGE: '{screenshot_full_page_raw}'")
print(f"   Tipo: {type(screenshot_full_page_raw)}")

# Procesar como lo hace el framework
if screenshot_full_page_raw != 'NOT_SET':
    full_page = screenshot_full_page_raw.lower() == 'true'
    print(f"\n🔍 Procesamiento del framework:")
    print(f"   .lower() = '{screenshot_full_page_raw.lower()}'")
    print(f"   .lower() == 'true' = {full_page}")
    print(f"\n{'✅' if not full_page else '❌'} Screenshot será: {'VIEWPORT' if not full_page else 'FULL PAGE'}")
else:
    print(f"\n⚠️  Variable NO definida, usando default: FULL PAGE")

# Mostrar todas las variables de entorno relacionadas
print("\n📝 Otras variables relacionadas:")
print(f"   SCREENSHOTS_DIR = {os.getenv('SCREENSHOTS_DIR', 'screenshots')}")
print(f"   HTML_REPORT_CAPTURE_ALL_STEPS = {os.getenv('HTML_REPORT_CAPTURE_ALL_STEPS', 'false')}")
