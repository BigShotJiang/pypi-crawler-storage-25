#!/usr/bin/env python3
"""
Script para probar screenshots reales con la configuración actual
"""
import os
from dotenv import load_dotenv
from pathlib import Path
from playwright.sync_api import sync_playwright

# Cargar .env
if Path('.env').exists():
    load_dotenv('.env')
    print("✅ Archivo .env cargado")

# Leer configuración
full_page_config = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
print(f"\n📋 Configuración SCREENSHOT_FULL_PAGE: {full_page_config}")
print(f"   Screenshot será: {'FULL PAGE' if full_page_config else 'VIEWPORT ONLY'}")

# Crear directorio de prueba
test_dir = Path('test_screenshots')
test_dir.mkdir(exist_ok=True)

print(f"\n🌐 Iniciando navegador para prueba real...")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    
    # Crear contexto con viewport específico
    context = browser.new_context(
        viewport={'width': 1280, 'height': 720}
    )
    page = context.new_page()
    
    # Navegar a una página larga
    print("📄 Navegando a página de prueba (larga)...")
    page.goto('https://example.com')
    
    # Inyectar contenido largo para hacer scroll
    page.evaluate("""
        document.body.innerHTML += '<div style="height: 3000px; background: linear-gradient(red, blue);"><h1 style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);">CONTENIDO LARGO PARA SCROLL</h1></div>';
    """)
    
    print(f"\n📸 Tomando screenshots...")
    
    # Screenshot 1: Con full_page según configuración
    screenshot_config = test_dir / f'screenshot_config_{full_page_config}.png'
    page.screenshot(path=str(screenshot_config), full_page=full_page_config)
    print(f"   ✅ Screenshot con configuración (.env): {screenshot_config}")
    
    # Screenshot 2: Forzar viewport (para comparar)
    screenshot_viewport = test_dir / 'screenshot_viewport_forced.png'
    page.screenshot(path=str(screenshot_viewport), full_page=False)
    print(f"   ✅ Screenshot viewport forzado: {screenshot_viewport}")
    
    # Screenshot 3: Forzar full page (para comparar)
    screenshot_fullpage = test_dir / 'screenshot_fullpage_forced.png'
    page.screenshot(path=str(screenshot_fullpage), full_page=True)
    print(f"   ✅ Screenshot full page forzado: {screenshot_fullpage}")
    
    # Comparar tamaños
    from PIL import Image
    
    img_config = Image.open(screenshot_config)
    img_viewport = Image.open(screenshot_viewport)
    img_fullpage = Image.open(screenshot_fullpage)
    
    print(f"\n📏 Comparación de tamaños:")
    print(f"   Config (.env):     {img_config.size} - {'VIEWPORT' if img_config.size == img_viewport.size else 'FULL PAGE'}")
    print(f"   Viewport forzado:  {img_viewport.size}")
    print(f"   Full page forzado: {img_fullpage.size}")
    
    if img_config.size == img_viewport.size:
        print(f"\n✅ La configuración está funcionando correctamente (VIEWPORT)")
    elif img_config.size == img_fullpage.size:
        print(f"\n❌ La configuración NO está funcionando (tomando FULL PAGE)")
    else:
        print(f"\n⚠️  Tamaño inesperado")
    
    browser.close()

print(f"\n✅ Prueba completada. Revisa las imágenes en: {test_dir}")
