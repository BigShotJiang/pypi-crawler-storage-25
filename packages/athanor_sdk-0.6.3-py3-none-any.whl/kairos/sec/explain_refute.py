"""ATH-1106: parse EBMC counterexample into structured JSON.

Customer agent gets REFUTED and needs actionable information:
which signal diverges, at what cycle, gold vs gate values,
and what to try next.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class RefuteExplanation:
    divergence_cycle: int | None = None
    divergent_signals: list[dict[str, str]] = field(default_factory=list)
    property_name: str | None = None
    total_cycles: int | None = None
    summary: str = ""
    suggested_fixes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "divergence_cycle": self.divergence_cycle,
            "divergent_signals": self.divergent_signals,
            "property_name": self.property_name,
            "total_cycles": self.total_cycles,
            "summary": self.summary,
            "suggested_fixes": self.suggested_fixes,
        }


def explain_refute(
    counterexample_text: str,
    property_name: str | None = None,
    gold_module: str | None = None,
    gate_module: str | None = None,
) -> RefuteExplanation:
    """Parse raw EBMC counterexample trace into structured explanation."""
    exp = RefuteExplanation(property_name=property_name)

    if not counterexample_text:
        exp.summary = "No counterexample trace available."
        exp.suggested_fixes = ["Re-run with --verbose to capture the full trace."]
        return exp

    lines = counterexample_text.strip().splitlines()

    signal_values: dict[int, dict[str, str]] = {}
    current_cycle: int | None = None
    max_cycle = 0

    for line in lines:
        cycle_match = re.match(r".*(?:State|Cycle|step)\s*(\d+)", line, re.IGNORECASE)
        if cycle_match:
            current_cycle = int(cycle_match.group(1))
            max_cycle = max(max_cycle, current_cycle)
            continue

        assign_match = re.match(r"\s*(\S+)\s*=\s*(\S+)", line)
        if assign_match and current_cycle is not None:
            sig_name = assign_match.group(1)
            sig_val = assign_match.group(2)
            if current_cycle not in signal_values:
                signal_values[current_cycle] = {}
            signal_values[current_cycle][sig_name] = sig_val

    exp.total_cycles = max_cycle + 1 if max_cycle > 0 else None

    gold_prefix = f"{gold_module}." if gold_module else "gold."
    gate_prefix = f"{gate_module}." if gate_module else "gate."

    for cycle in sorted(signal_values.keys()):
        sigs = signal_values[cycle]
        gold_sigs = {k: v for k, v in sigs.items() if gold_prefix in k or k.startswith("gold")}
        gate_sigs = {k: v for k, v in sigs.items() if gate_prefix in k or k.startswith("gate")}

        for gsig, gval in gold_sigs.items():
            base = gsig.replace(gold_prefix, "").replace("gold.", "")
            gate_key_candidates = [
                f"{gate_prefix}{base}",
                f"gate.{base}",
                base,
            ]
            for gk in gate_key_candidates:
                if gk in gate_sigs and gate_sigs[gk] != gval:
                    exp.divergent_signals.append({
                        "signal": base,
                        "cycle": str(cycle),
                        "gold_value": gval,
                        "gate_value": gate_sigs[gk],
                    })
                    if exp.divergence_cycle is None:
                        exp.divergence_cycle = cycle
                    break

    if not exp.divergent_signals:
        for cycle in sorted(signal_values.keys()):
            for sig, val in signal_values[cycle].items():
                exp.divergent_signals.append({
                    "signal": sig,
                    "cycle": str(cycle),
                    "value": val,
                })
            if len(exp.divergent_signals) >= 10:
                break

    n_div = len(exp.divergent_signals)
    if exp.divergence_cycle is not None:
        exp.summary = (
            f"Equivalence refuted at cycle {exp.divergence_cycle}. "
            f"{n_div} signal(s) diverge between gold and gate."
        )
    else:
        exp.summary = (
            f"Counterexample trace spans {exp.total_cycles or '?'} cycles. "
            f"{n_div} signal value(s) extracted."
        )

    exp.suggested_fixes = _suggest_fixes(exp, counterexample_text)
    return exp


def _suggest_fixes(exp: RefuteExplanation, raw: str) -> list[str]:
    fixes = []
    raw_lower = raw.lower()

    if exp.divergence_cycle == 0:
        fixes.append(
            "Divergence at cycle 0 suggests a reset mismatch. "
            "Check that gold and gate have the same reset behavior."
        )
    elif exp.divergence_cycle is not None and exp.divergence_cycle <= 2:
        fixes.append(
            "Early-cycle divergence often indicates an initialization difference. "
            "Verify that both modules start from the same state after reset."
        )

    if "overflow" in raw_lower or "underflow" in raw_lower:
        fixes.append("Arithmetic overflow/underflow detected. Check bit-width matching.")

    if any(d.get("signal", "").endswith(("_ptr", "ptr", "count", "cnt")) for d in exp.divergent_signals):
        fixes.append("Pointer/counter signal diverges. Check index arithmetic and boundary conditions.")

    if not fixes:
        fixes.append(
            "Review the divergent signals at the reported cycle. "
            "Compare gold vs gate RTL at the divergence point."
        )

    return fixes
