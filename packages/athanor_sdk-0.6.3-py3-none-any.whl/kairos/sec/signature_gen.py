"""RTL → signature.json generator (ATH-1063 Phase 0b).

Parses an RTL module file (.v / .sv) into the signature.json schema used
by `kairos.sec.closed_loop` bundles. Replaces hand-written signature.json
authoring with deterministic harvest from the RTL itself.

Harvested fields:
  * target_module — module name from `module <name>` declaration
  * ports — name + direction (input/output/inout) + width expression
  * parameters — name + default value + type inference
  * clock_port + reset_port + reset_active_low — heuristic detection from
    `posedge clk` / `negedge rst_n` candidates
  * is_combinational — true when no `always @(posedge clk)` / no clocked
    register declarations are found
  * formal_invariants_primer — extracted from `formal_sst_verif_only` ifdef
    blocks. Each ASSERT_NEVER / ASSERT_ALWAYS / ASSERT_IMPL becomes one
    primer entry the LLM proposer reads as bridge-invariant starter set.

Per ATH-1063 Phase 0b acceptance: validates against the three Phase 1
hand-written signature.json fixtures at
`examples/customer/annapurna_basic_cells/<BLOCK>/signature.json`.

This is intentionally a focused regex-based parser, not a full Verilog
compiler. It handles the Verilog-2001 + SV-2017 subset that appears in
Annapurna's basic_cells library. Edge cases that don't parse cleanly
should fall back to hand-edited signature.json — surfaced as
ATH-1063 dogfood gap when hit.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ───────────────────────────────────────────────────────────────────
# Module / port / parameter extraction
# ───────────────────────────────────────────────────────────────────

# `module <name> #(...)? (port_list);` — captures the name. Module body
# extends from here to the matching `endmodule`.
_MODULE_RE = re.compile(r"\bmodule\s+(\w+)\b")

# `parameter <name> = <default>` and `localparam <name> = <expr>`. Captures
# name + default-or-expr text. Multi-line continuations handled by the
# upstream pre-process (collapse line continuations + strip comments).
_PARAM_RE = re.compile(
    r"\b(parameter|localparam)\s+(\w+)\s*=\s*([^,;\n)]+)"
)

# Port declaration shapes:
#   `input  [WIDTH-1:0] name`
#   `output [N-1:0] name`
#   `input  name`
#   `output reg [N-1:0] name`
#   `input wire name`
# Captures direction + optional reg/wire + optional width-expr + name.
_PORT_RE = re.compile(
    r"\b(input|output|inout)(?:\s+(reg|wire|logic))?\s*"
    r"(?:\[\s*([^\]]+?)\s*\])?\s*"
    r"(\w+)\s*[,;)]"
)

# Clocked-register detection. If any of these appear, the block has
# sequential logic; otherwise it's combinational.
_CLOCKED_PATTERNS = [
    re.compile(r"\balways\s*@\s*\(\s*posedge\s+\w+\s*\)"),
    re.compile(r"\balways\s*@\s*\(\s*negedge\s+\w+\s*\)"),
    re.compile(r"\balways_ff\s*@"),
    re.compile(r"\bAP_DFF\w*\b"),  # Annapurna flop primitives
    re.compile(r"\bAP_LDFF\w*\b"),
]

# Reset-active-low detection. `negedge rst_n` or `negedge reset_n` ⇒
# active-low; `posedge rst` or `posedge reset` (without _n) ⇒ active-high.
_RESET_NEGEDGE_RE = re.compile(r"\bnegedge\s+(\w+)\b")
_RESET_POSEDGE_RE = re.compile(
    r"\bposedge\s+\w+\s+or\s+posedge\s+(\w+)\b"
)


# ───────────────────────────────────────────────────────────────────
# formal_sst_verif_only invariant extraction
# ───────────────────────────────────────────────────────────────────

# `ifdef formal_sst_verif_only` block boundary. Block extends to the
# matching `endif` (handle nested ifdefs by counting depth).
_FORMAL_BLOCK_OPEN_RE = re.compile(r"`ifdef\s+formal_sst_verif_only\b")
_IFDEF_RE = re.compile(r"`ifdef\b|`ifndef\b")
_ENDIF_RE = re.compile(r"`endif\b")

# ASSERT_NEVER name(.expr(EXPR),.*);
_ASSERT_NEVER_RE = re.compile(
    r"ASSERT_NEVER\s+(\w+)\s*\(\s*\.expr\s*\(\s*(.+?)\s*\)\s*,\s*\.\*\s*\)\s*;",
    re.DOTALL,
)

# ASSERT_ALWAYS name(.expr(EXPR),.*);
_ASSERT_ALWAYS_RE = re.compile(
    r"ASSERT_ALWAYS\s+(\w+)\s*\(\s*\.expr\s*\(\s*(.+?)\s*\)\s*,\s*\.\*\s*\)\s*;",
    re.DOTALL,
)

# ASSERT_IMPL name(.antec(ANTEC),.cons(CONS),.*);
_ASSERT_IMPL_RE = re.compile(
    r"ASSERT_IMPL\s+(\w+)\s*\(\s*\.antec\s*\(\s*(.+?)\s*\)\s*,\s*"
    r"\.cons\s*\(\s*(.+?)\s*\)\s*,\s*\.\*\s*\)\s*;",
    re.DOTALL,
)


# ───────────────────────────────────────────────────────────────────
# Pre-processing (comment strip)
# ───────────────────────────────────────────────────────────────────

_LINE_COMMENT_RE = re.compile(r"//[^\n]*")
_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)


def _strip_comments(text: str) -> str:
    """Strip // and /* */ comments. Preserves newlines for line-number tracking."""
    text = _BLOCK_COMMENT_RE.sub(
        lambda m: "\n" * m.group(0).count("\n"), text
    )
    text = _LINE_COMMENT_RE.sub("", text)
    return text


# ───────────────────────────────────────────────────────────────────
# Result dataclasses
# ───────────────────────────────────────────────────────────────────


@dataclass
class Port:
    name: str
    direction: str  # "input" | "output" | "inout"
    width: Any  # int (1) or str (expression like "DATA_WIDTH-1:0" → "DATA_WIDTH")


@dataclass
class Parameter:
    name: str
    default: Any
    must_override: bool = False


@dataclass
class FormalInvariant:
    name: str
    kind: str  # "ASSERT_NEVER" | "ASSERT_ALWAYS" | "ASSERT_IMPL"
    expr: str | None = None
    antec: str | None = None
    cons: str | None = None
    source_line: int = 0


@dataclass
class Signature:
    target_module: str
    gold_sv: str
    block_class: str  # "fifo" | "combinational_alu" | "generic"
    is_combinational: bool
    ports: list[Port] = field(default_factory=list)
    parameters: list[Parameter] = field(default_factory=list)
    clock_port: str | None = None
    reset_port: str | None = None
    reset_active_low: bool | None = None
    formal_invariants_primer: list[FormalInvariant] = field(
        default_factory=list
    )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to signature.json shape (dict; caller writes JSON)."""
        d: dict[str, Any] = {
            "target_module": self.target_module,
            "gold_sv": self.gold_sv,
            "gate_v": None,
            "block_class": self.block_class,
            "ports": [
                {"name": p.name, "direction": p.direction, "width": p.width}
                for p in self.ports
            ],
            "parameters": [
                {
                    "name": p.name,
                    "default": p.default,
                    **({"must_override": True} if p.must_override else {}),
                }
                for p in self.parameters
            ],
            "clock_port": self.clock_port,
            "reset_port": self.reset_port,
            "reset_active_low": self.reset_active_low,
        }
        if self.is_combinational:
            d["is_combinational"] = True
            d["ebmc_bound"] = 0
            d["ebmc_mode"] = "bmc_combinational"
        d["formal_invariants_primer"] = [
            {
                "name": inv.name,
                "kind": inv.kind,
                **({"expr": inv.expr} if inv.expr is not None else {}),
                **({"antec": inv.antec} if inv.antec is not None else {}),
                **({"cons": inv.cons} if inv.cons is not None else {}),
                "source_line": inv.source_line,
            }
            for inv in self.formal_invariants_primer
        ]
        return d


# ───────────────────────────────────────────────────────────────────
# Parser primitives
# ───────────────────────────────────────────────────────────────────


def _extract_module_name(text: str) -> str:
    m = _MODULE_RE.search(text)
    if m is None:
        raise ValueError("No `module <name>` declaration found")
    return m.group(1)


def _extract_ports(text: str) -> list[Port]:
    """Parse port declarations.

    Walks the module body and collects every `(input|output|inout) ...`
    declaration. Width expression is preserved as a string when
    parameterized (e.g. `DATA_WIDTH-1:0` → just keep `DATA_WIDTH`); bare
    width is normalized to int 1.
    """
    ports: list[Port] = []
    seen: set[str] = set()
    for m in _PORT_RE.finditer(text):
        direction = m.group(1)
        width_expr = m.group(3)
        name = m.group(4)
        # Skip Verilog reserved words that match the regex but aren't ports
        if name in {"reg", "wire", "logic", "signed", "unsigned"}:
            continue
        if name in seen:
            continue
        seen.add(name)
        if width_expr is None:
            width: Any = 1
        else:
            width = _normalize_width(width_expr)
        ports.append(Port(name=name, direction=direction, width=width))
    return ports


def _normalize_width(width_expr: str) -> Any:
    """Convert width expression `[N-1:0]` → simplified form.

    Examples:
      - `DATA_WIDTH-1:0`        → "DATA_WIDTH"
      - `7:0`                   → 8
      - `(NUM_OF_INPUTS * DATA_WIDTH) - 1 : 0` → "NUM_OF_INPUTS * DATA_WIDTH"
      - bare digit               → int
    """
    expr = width_expr.strip()
    # `<HIGH>:0` shape
    msb_lsb = re.match(r"^(.+?)\s*:\s*0\s*$", expr)
    if msb_lsb:
        msb = msb_lsb.group(1).strip()
        # Bare integer high index
        m_int = re.match(r"^(\d+)$", msb)
        if m_int:
            return int(m_int.group(1)) + 1
        # `<expr> - 1` shape — strip the trailing -1
        m_minus_one = re.match(r"^\(?(.+?)\)?\s*-\s*1\s*$", msb)
        if m_minus_one:
            return m_minus_one.group(1).strip().strip("()")
        return msb
    return expr


def _extract_parameters(text: str) -> list[Parameter]:
    """Parse parameter declarations.

    Skips `localparam` (those are derived; not customer-overrideable).
    """
    params: list[Parameter] = []
    seen: set[str] = set()
    for m in _PARAM_RE.finditer(text):
        kind = m.group(1)
        if kind == "localparam":
            continue
        name = m.group(2)
        default_text = m.group(3).strip()
        if name in seen:
            continue
        seen.add(name)
        # Try to parse as int; otherwise keep as string (Verilog literal)
        default: Any
        try:
            default = int(default_text)
        except ValueError:
            default = default_text.strip().strip("'\"")
        # `must be overridden` heuristic: default == 0 with comment annotation
        # (the AP_REG_FIFO family uses `parameter FIFO_DEPTH = 0; // must be overridden`)
        params.append(Parameter(name=name, default=default))
    return params


_CLK_PORT_NAMES = {"clk", "clock", "clk_in", "i_clk"}
_RESET_PORT_NAMES_ACTIVE_LOW = {"reset_n", "rst_n", "resetn", "rstn", "i_rst_n"}
_RESET_PORT_NAMES_ACTIVE_HIGH = {"reset", "rst", "i_rst"}


def _detect_clock_reset(
    text: str, ports: list["Port"]
) -> tuple[str | None, str | None, bool | None, bool]:
    """Detect clock + reset + reset polarity + combinational-ness.

    Two-tier detection:
      (1) Direct `always @(posedge clk)` / `always_ff` / negedge in body.
      (2) Port-name heuristic on the module's port list. Annapurna RTL
          frequently instantiates flop primitives (AP_LDFFR_US etc.) and
          has no inline always blocks; the only signal of clocked-ness
          is then the port list containing `clk` and `reset_n`.

    Tier (2) is decisive when tier (1) is silent — sequential by default
    if the module exposes a clock port. Customer engineers can override
    via signature.json `is_combinational: true` when they know better.

    Returns (clock_port, reset_port, reset_active_low, is_combinational).
    """
    # Tier 1: inline clocked patterns
    is_seq_tier1 = any(p.search(text) for p in _CLOCKED_PATTERNS)

    # Tier 2: port-name heuristic
    port_names = {p.name for p in ports}
    clk_port_match = port_names & _CLK_PORT_NAMES
    rst_low_match = port_names & _RESET_PORT_NAMES_ACTIVE_LOW
    rst_high_match = port_names & _RESET_PORT_NAMES_ACTIVE_HIGH
    is_seq_tier2 = bool(clk_port_match)

    is_seq = is_seq_tier1 or is_seq_tier2
    if not is_seq:
        return (None, None, None, True)

    # Pick clock port: tier-1 (posedge match) takes precedence; otherwise
    # the port-name match.
    clk_m = re.search(r"\bposedge\s+(\w+)\b", text)
    if clk_m and clk_m.group(1) in port_names:
        clock_port = clk_m.group(1)
    elif clk_port_match:
        clock_port = sorted(clk_port_match)[0]
    elif clk_m:
        clock_port = clk_m.group(1)
    else:
        clock_port = None

    # Reset detection: tier-1 inline negedge / posedge → preferred;
    # tier-2 port-name → fallback.
    neg_m = _RESET_NEGEDGE_RE.search(text)
    if neg_m and neg_m.group(1) in port_names:
        return (clock_port, neg_m.group(1), True, False)
    pos_reset_m = _RESET_POSEDGE_RE.search(text)
    if pos_reset_m and pos_reset_m.group(1) in port_names:
        return (clock_port, pos_reset_m.group(1), False, False)

    if rst_low_match:
        return (clock_port, sorted(rst_low_match)[0], True, False)
    if rst_high_match:
        return (clock_port, sorted(rst_high_match)[0], False, False)

    return (clock_port, None, None, False)


def _extract_formal_invariants(text: str) -> list[FormalInvariant]:
    """Extract `formal_sst_verif_only` ifdef block invariants.

    Returns ASSERT_NEVER / ASSERT_ALWAYS / ASSERT_IMPL invariants in
    source order. Each becomes one primer entry the LLM proposer reads.
    """
    invariants: list[FormalInvariant] = []

    # Find the opening of the formal_sst_verif_only block
    m = _FORMAL_BLOCK_OPEN_RE.search(text)
    if m is None:
        return invariants

    block_start = m.end()
    # Walk forward, tracking ifdef nesting depth, until matching endif
    depth = 1
    pos = block_start
    while depth > 0 and pos < len(text):
        next_ifdef = _IFDEF_RE.search(text, pos)
        next_endif = _ENDIF_RE.search(text, pos)
        if next_endif is None:
            break
        if next_ifdef is not None and next_ifdef.start() < next_endif.start():
            depth += 1
            pos = next_ifdef.end()
        else:
            depth -= 1
            if depth == 0:
                block_end = next_endif.start()
                break
            pos = next_endif.end()
    else:
        block_end = len(text)
    if depth > 0:
        block_end = len(text)

    block_text = text[block_start:block_end]

    # Compute line offset for source-line tracking
    line_offset = text.count("\n", 0, block_start) + 1

    def _line_of(match_start: int) -> int:
        return line_offset + block_text.count("\n", 0, match_start)

    for m_never in _ASSERT_NEVER_RE.finditer(block_text):
        invariants.append(
            FormalInvariant(
                name=m_never.group(1),
                kind="ASSERT_NEVER",
                expr=_clean_expr(m_never.group(2)),
                source_line=_line_of(m_never.start()),
            )
        )
    for m_always in _ASSERT_ALWAYS_RE.finditer(block_text):
        invariants.append(
            FormalInvariant(
                name=m_always.group(1),
                kind="ASSERT_ALWAYS",
                expr=_clean_expr(m_always.group(2)),
                source_line=_line_of(m_always.start()),
            )
        )
    for m_impl in _ASSERT_IMPL_RE.finditer(block_text):
        invariants.append(
            FormalInvariant(
                name=m_impl.group(1),
                kind="ASSERT_IMPL",
                antec=_clean_expr(m_impl.group(2)),
                cons=_clean_expr(m_impl.group(3)),
                source_line=_line_of(m_impl.start()),
            )
        )

    invariants.sort(key=lambda inv: inv.source_line)
    return invariants


def _clean_expr(expr: str) -> str:
    """Collapse internal whitespace to single spaces; strip surrounding."""
    return re.sub(r"\s+", " ", expr).strip()


# ───────────────────────────────────────────────────────────────────
# Block-class heuristic
# ───────────────────────────────────────────────────────────────────


def _classify_block(module_name: str, is_combinational: bool, port_names: list[str]) -> str:
    name_lower = module_name.lower()
    if "fifo" in name_lower:
        return "fifo"
    if is_combinational and "alu" in name_lower:
        return "combinational_alu"
    if is_combinational:
        return "combinational"
    return "generic"


# ───────────────────────────────────────────────────────────────────
# Public API
# ───────────────────────────────────────────────────────────────────


def generate_signature(
    rtl_path: str | Path,
    target_module: str | None = None,
    gold_sv_relative: str | None = None,
) -> dict[str, Any]:
    """Generate signature.json dict from an RTL module file.

    Parameters
    ----------
    rtl_path:
        Filesystem path to a .v or .sv RTL source. The file should
        contain at least one `module ... endmodule` declaration.
    target_module:
        Module name to target. If None, use the FIRST module declared
        in the file. Useful when a file declares multiple modules.
    gold_sv_relative:
        Path to write into ``signature.gold_sv`` (relative to the
        bundle directory). Defaults to ``inputs/<basename>``.

    Returns
    -------
    dict matching the signature.json schema. Caller serializes via
    ``json.dump(d, f, indent=2)``.

    Raises
    ------
    ValueError
        If no module declaration is found in the file.
    FileNotFoundError
        If ``rtl_path`` does not exist.
    """
    path = Path(rtl_path)
    raw_text = path.read_text()
    text = _strip_comments(raw_text)

    module_name = target_module or _extract_module_name(text)

    ports = _extract_ports(text)
    parameters = _extract_parameters(text)
    clock_port, reset_port, reset_active_low, is_combinational = (
        _detect_clock_reset(text, ports)
    )
    # Use raw_text (not stripped) for invariant extraction so source_line
    # mapping references the on-disk file
    invariants = _extract_formal_invariants(raw_text)
    block_class = _classify_block(
        module_name, is_combinational, [p.name for p in ports]
    )

    if gold_sv_relative is None:
        gold_sv_relative = f"inputs/{path.name}"

    sig = Signature(
        target_module=module_name,
        gold_sv=gold_sv_relative,
        block_class=block_class,
        is_combinational=is_combinational,
        ports=ports,
        parameters=parameters,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
        formal_invariants_primer=invariants,
    )
    return sig.to_dict()


def main() -> None:
    """CLI entry-point: `kairos signature-gen <rtl-path> [-o signature.json]`."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Generate signature.json from an RTL module file."
    )
    parser.add_argument("rtl_path", help="Path to .v or .sv source file")
    parser.add_argument(
        "--target-module",
        default=None,
        help="Module name to target (defaults to first module in file)",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output path (defaults to <rtl_dir>/../signature.json)",
    )
    args = parser.parse_args()

    sig = generate_signature(args.rtl_path, target_module=args.target_module)
    output = args.output
    if output is None:
        rtl_dir = Path(args.rtl_path).parent
        output = str(rtl_dir.parent / "signature.json")
    Path(output).write_text(json.dumps(sig, indent=2) + "\n")
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
