"""kairos.sec._miter — generate a SystemVerilog miter for SEC.

A *miter* is a wrapper module that instantiates two designs (gold +
gate) sharing the same primary inputs and asserts that their primary
outputs agree at every cycle. Sequential equivalence checking
discharges the assertions: PROVED means the two designs are
behaviorally equivalent across the proof's reachable-state set;
REFUTED means the SAT / induction engine found an input sequence
where the outputs diverge.

The miter is generated as plain SystemVerilog for two reasons:

1. EBMC consumes SystemVerilog directly. No intermediate format.
2. Customers can read the generated miter and audit the
   equivalence claim by inspection.

Generated miter shape (illustrative, fifo_widget pair):

.. code-block:: systemverilog

   module sec_miter (
       input  logic clk,
       input  logic rst_n,
       input  logic push,
       input  logic [27:0] push_data,
       input  logic pop
   );
     // Gold instance — original SystemVerilog.
     logic [27:0] gold_pop_data;
     logic gold_full, gold_empty;
     fifo_widget gold (
       .clk(clk), .rst_n(rst_n),
       .push(push), .push_data(push_data), .pop(pop),
       .pop_data(gold_pop_data), .full(gold_full), .empty(gold_empty)
     );

     // Gate instance — Clash-emitted Verilog.
     logic [27:0] gate_pop_data;
     logic gate_full, gate_empty;
     fifo_widget_gate gate (
       .clk(clk), .rst_n(rst_n),
       .push(push), .push_data(push_data), .pop(pop),
       .pop_data(gate_pop_data), .full(gate_full), .empty(gate_empty)
     );

     // Per-output equivalence checks: one labelled property per output
     // (pop_data_match, full_match, empty_match), each posedge-clk
     // sampled with a disable-on-reset guard so cycles where rst_n is
     // low do not contribute to the proof. The SV body uses the
     // standard concurrent-assertion form; the actual emitter
     // generates the literal text. See _sv_assertion below.
   endmodule

The reset guard excludes cycles where rst_n is low, matching
SV-design convention that registers are settled only after reset
deasserts. EBMC's k-induction proof respects this guard.

Caveat on Clash gate name collision
-----------------------------------

When the Clash gate uses the same module name as the SV gold
(typical when both target ``fifo_widget`` post-Synthesize annotation),
the miter must rename one side to avoid a multiple-definition error
in the EBMC parser. :func:`build_miter` handles this by renaming the
gate to ``<gold_name>_gate`` in the emitted miter; the caller's
build pipeline must produce the gate Verilog with a matching renamed
module declaration. This is a known ergonomic wrinkle; the next
iteration introduces a parser-level rename pass so callers don't
have to pre-rename.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Literal


PortDirection = Literal["input", "output"]


@dataclass(frozen=True)
class MiterPort:
    """One port of the miter's instantiated designs.

    Both gold and gate must agree on ports + widths + directions.
    The miter routes inputs from primary to both instances, then
    asserts equality across both instances' outputs at every cycle
    (modulo reset guard).
    """

    name: str
    direction: PortDirection
    width: int = 1  # 1-bit unless explicitly multi-bit

    def sv_decl(self) -> str:
        """SystemVerilog port declaration for the miter's port list."""
        if self.width == 1:
            return f"{self.direction:<6} logic {self.name}"
        return f"{self.direction:<6} logic [{self.width - 1}:0] {self.name}"

    def sv_signal(self, prefix: str) -> str:
        """SystemVerilog wire declaration for an output capture wire."""
        if self.width == 1:
            return f"  logic {prefix}_{self.name};"
        return f"  logic [{self.width - 1}:0] {prefix}_{self.name};"


@dataclass(frozen=True)
class MiterSignature:
    """The shared signature gold + gate must match at the miter's
    instantiation boundary."""

    gold_module: str
    gate_module: str
    ports: tuple[MiterPort, ...]
    clock_port: str = "clk"
    reset_port: str = "rst_n"
    reset_active_low: bool = True

    def primary_inputs(self) -> tuple[MiterPort, ...]:
        return tuple(p for p in self.ports if p.direction == "input")

    def primary_outputs(self) -> tuple[MiterPort, ...]:
        return tuple(p for p in self.ports if p.direction == "output")


@dataclass(frozen=True)
class MiterSpec:
    """Generated miter description.

    Returned by :func:`build_miter`. ``sv_text`` is the full
    SystemVerilog source ready to feed into EBMC; ``property_labels``
    are the per-output assertion names EBMC will report verdicts
    against.
    """

    sv_text: str
    property_labels: tuple[str, ...]
    signature: MiterSignature
    miter_top: str = "sec_miter"


def _sv_inputs_block(sig: MiterSignature, indent: str = "    ") -> str:
    """Format the miter's port list."""
    lines = []
    for p in sig.primary_inputs():
        lines.append(f"{indent}{p.sv_decl()}")
    return ",\n".join(lines)


def _sv_instance(
    sig: MiterSignature, *, instance_module: str, instance_name: str,
    output_prefix: str,
) -> str:
    """Format one design instantiation inside the miter."""
    lines = [f"  {instance_module} {instance_name} ("]
    bindings: list[str] = []
    for p in sig.ports:
        if p.direction == "input":
            bindings.append(f"    .{p.name}({p.name})")
        else:
            bindings.append(f"    .{p.name}({output_prefix}_{p.name})")
    lines.append(",\n".join(bindings))
    lines.append("  );")
    return "\n".join(lines)


def _sv_assertion(sig: MiterSignature, port: MiterPort, combo_only: bool = False) -> tuple[str, str]:
    """Format one equivalence assertion. Returns (label, sv_text)."""
    label = f"{port.name}_match"
    if combo_only:
        sv = (
            f"  {label}: assert property ("
            f"gold_{port.name} == gate_{port.name});"
        )
    elif not sig.reset_port:
        # Sequential block with no reset — clocked assertion, no disable-iff
        sv = (
            f"  {label}: assert property (@(posedge {sig.clock_port}) "
            f"gold_{port.name} == gate_{port.name});"
        )
    else:
        reset_guard = (
            f"!{sig.reset_port}" if sig.reset_active_low else f"{sig.reset_port}"
        )
        sv = (
            f"  {label}: assert property (@(posedge {sig.clock_port}) "
            f"disable iff ({reset_guard})\n"
            f"    gold_{port.name} == gate_{port.name});"
        )
    return label, sv


def build_miter(
    *,
    gold_module: str,
    gate_module: str,
    ports: Iterable[MiterPort],
    clock_port: str = "clk",
    reset_port: str = "rst_n",
    reset_active_low: bool = True,
    miter_top: str = "sec_miter",
    initial_state_registers: tuple[str, ...] = (),
) -> MiterSpec:
    """Generate a SystemVerilog miter wrapping a gold and gate pair.

    :param gold_module: SV module name of the gold (reference) design.
    :param gate_module: Module name of the gate (under-test) design.
        Must differ from ``gold_module`` in the EBMC input set; if the
        Clash-emitted Verilog uses the same name as the SV gold, the
        caller must rename the gate's module declaration before
        feeding to EBMC. The miter assumes the rename is already done.
    :param ports: Iterable of :class:`MiterPort` describing the shared
        signature. Must include the clock + reset ports plus all
        functional inputs/outputs.
    :param clock_port: Name of the clock primary input.
    :param reset_port: Name of the reset primary input.
    :param reset_active_low: When True, assertions are guarded by
        ``disable iff (!rst_n)``; when False, ``disable iff (rst)``.
    :param miter_top: Top-module name of the generated miter.

    :returns: :class:`MiterSpec` with the SystemVerilog text and the
        list of property labels EBMC will report verdicts against.

    :raises ValueError: When ``gold_module == gate_module`` (would
        produce a duplicate-instance error in EBMC) or when ``ports``
        omits the clock/reset.
    """
    if gold_module == gate_module:
        raise ValueError(
            f"gold_module and gate_module must differ at the miter "
            f"boundary (got both = {gold_module!r}). Rename the gate's "
            f"module declaration before passing to build_miter."
        )

    port_tuple = tuple(ports)
    sig = MiterSignature(
        gold_module=gold_module,
        gate_module=gate_module,
        ports=port_tuple,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
    )
    port_names = {p.name for p in port_tuple}
    # Skip clock/reset validation for combo blocks (no clock in port list)
    if clock_port in port_names and reset_port and reset_port not in port_names:
        raise ValueError(f"reset_port {reset_port!r} not in port list")

    inputs_block = _sv_inputs_block(sig)
    gold_inst = _sv_instance(
        sig, instance_module=gold_module, instance_name="gold",
        output_prefix="gold",
    )
    gate_inst = _sv_instance(
        sig, instance_module=gate_module, instance_name="gate",
        output_prefix="gate",
    )

    output_decls = "\n".join(
        p.sv_signal("gold") + "\n" + p.sv_signal("gate")
        for p in sig.primary_outputs()
    )

    # Detect combo-only: if clock_port is not in the port list, use
    # non-clocked assertions (pure combinational equivalence).
    port_names = {p.name for p in sig.ports}
    combo_only = sig.clock_port not in port_names

    assertion_lines: list[str] = []
    labels: list[str] = []
    for p in sig.primary_outputs():
        label, line = _sv_assertion(sig, p, combo_only=combo_only)
        labels.append(label)
        assertion_lines.append(line)

    # ATH-1109 initial-state correspondence: when the caller supplies
    # internal register names extracted from the elaborated modules,
    # emit `initial assume` blocks tying each gold register to its
    # gate counterpart. Without these, EBMC BMC explores independently-
    # arbitrary initial states for the two instances, producing spurious
    # dout refutes on designs with un-reset memory arrays.
    initial_assume_lines: list[str] = []
    if initial_state_registers:
        initial_assume_lines.append(
            "  // Initial-state correspondence — gold and gate internal"
        )
        initial_assume_lines.append(
            "  // registers start from the same arbitrary value."
        )
        for reg_name in initial_state_registers:
            # Escaped Verilog identifiers (starting with \) MUST be
            # terminated by whitespace. Without the space before `);`,
            # EBMC's parser treats `)` as part of the identifier name
            # → syntax error. The space after the last identifier
            # token is load-bearing.
            initial_assume_lines.append(
                f"  initial assume ("
                f"gold.{reg_name} == gate.{reg_name} );"
            )
    initial_block = (
        "\n" + "\n".join(initial_assume_lines) + "\n"
        if initial_assume_lines
        else ""
    )

    sv_text = f"""// Auto-generated by kairos.sec.build_miter — do not hand-edit.
// Wrapper module asserting gold-vs-gate output equivalence at every
// cycle, modulo reset guard. EBMC reports one verdict per assertion
// label below.

module {miter_top} (
{inputs_block}
);

  // Output capture wires (per-instance prefix to disambiguate).
{output_decls}

  // Gold instance ({gold_module}).
{gold_inst}

  // Gate instance ({gate_module}).
{gate_inst}
{initial_block}
  // Equivalence assertions — one per primary output.
{chr(10).join(assertion_lines)}

endmodule
"""

    return MiterSpec(
        sv_text=sv_text,
        property_labels=tuple(labels),
        signature=sig,
        miter_top=miter_top,
    )


def extract_internal_registers(elaborated_v_text: str) -> tuple[str, ...]:
    """Extract internal register names from yosys-elaborated Verilog.

    Scans for ``reg [N:0] \\escaped_name ;`` declarations in the
    elaborated output. These are the internal registers that need
    initial-state correspondence assumes in the miter.

    Returns escaped register names suitable for hierarchical reference
    in the miter: ``gold.<name> == gate.<name>``.
    """
    regs: list[str] = []
    for line in elaborated_v_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("reg "):
            # Extract the register name (possibly escaped with backslash).
            parts = stripped.rstrip(";").split()
            if len(parts) >= 3:
                # reg [31:0] \name ; → name is parts[2]
                name = parts[2].rstrip(";").strip()
                if name:
                    regs.append(name)
            elif len(parts) == 2:
                # reg name; → name is parts[1]
                name = parts[1].rstrip(";").strip()
                if name:
                    regs.append(name)
    return tuple(regs)
