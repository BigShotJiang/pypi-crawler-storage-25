"""Inject ``assume property`` invariants into an existing miter.sv.

The closed-loop invariant-generation harness in
:mod:`kairos.sec.closed_loop._invariant_gen` proposes candidate
inductive invariants in SystemVerilog assertion syntax, then
re-runs EBMC k-induction on the miter with the candidate added as
an ``assume property``. If induction now closes, the candidate is
sufficient; if it doesn't, the counter-example feeds back to the
LLM for a strengthened proposal.

This module owns the mechanics of the injection: take an existing
miter.sv, an :class:`InjectionTarget` describing where to splice
the assume statement, and emit a new miter.sv text with the assume
inserted before the closing ``endmodule``.

Today's shape is deliberately string-based. Once the spike
validates the approach, a v1 follow-up swaps to a small SV
parser (or reuses :mod:`kairos.sv` AST infrastructure) for
robustness against miter-format drift.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class InjectionTarget:
    """Describes where + how to splice an ``assume property`` into miter.sv.

    Attributes
    ----------
    miter_module_name:
        The SV module name whose body receives the assume. The
        injector locates the matching ``module <name>`` ...
        ``endmodule`` block and inserts before the closing
        ``endmodule``. Defaults to ``"sec_miter"`` matching the
        :func:`kairos.sec.build_miter` output.
    clock_signal:
        The clock signal name used in the miter. Inserted assumes
        wrap the candidate expression in
        ``@(posedge <clock_signal>)``. Defaults to ``"clk"``.
    reset_disable_expr:
        The reset-disable expression used by the miter's existing
        assertions, wrapped in ``disable iff (...)`` to mirror the
        existing assertion shape. Defaults to ``"!rst_n"`` matching
        the v2 toy_fifo_chain miter convention.
    """

    miter_module_name: str = "sec_miter"
    clock_signal: str = "clk"
    reset_disable_expr: str = "!rst_n"


_ENDMODULE_RE = re.compile(r"^\s*endmodule\b", re.MULTILINE)


def inject_assume_property(
    miter_text: str,
    invariant_sv: str,
    *,
    label: str,
    target: InjectionTarget | None = None,
) -> str:
    """Return a copy of ``miter_text`` with ``invariant_sv`` injected as an assume.

    The output adds, just before the closing ``endmodule``, a line
    of the form::

        <label>: assume property (@(posedge <clk>) disable iff (<rst>) <invariant_sv>);

    Mirroring the assertion shape already used by the miter's
    equivalence properties so EBMC parses both consistently.

    Parameters
    ----------
    miter_text:
        Source text of the miter.sv to modify. The text is not
        mutated; a new string is returned.
    invariant_sv:
        The candidate inductive invariant in SV expression syntax
        (without the ``assume property`` wrapper). Example:
        ``"gold.count == gate.count"``.
    label:
        SV-legal label for the inserted assume. Used as the
        property name EBMC reports in its log. Example:
        ``"inv_count_eq"``.
    target:
        Module/clock/reset details. Defaults match
        :func:`kairos.sec.build_miter` output.

    Returns
    -------
    str
        The miter text with the assume inserted. If the injector
        cannot locate an ``endmodule`` for the named module, the
        output is the original text and the caller should treat
        the injection as failed (planned: raise a typed exception
        in the v1 hardening pass).

    Notes
    -----
    The injector is intentionally permissive about what
    ``invariant_sv`` contains; SV-syntax validation is EBMC's job,
    surfaced through its parse-error output. Garbage in -> EBMC
    parse error in the next k-induction pass -> counter-example
    feedback to the LLM for the next attempt.
    """
    target = target or InjectionTarget()

    assume_line = (
        f"  {label}: assume property (@(posedge {target.clock_signal}) "
        f"disable iff ({target.reset_disable_expr}) {invariant_sv});\n"
    )

    # Find the LAST endmodule (in case the file has multiple module
    # bodies — the gold and gate bodies if the miter is
    # self-contained). The last endmodule closes the wrapper.
    matches = list(_ENDMODULE_RE.finditer(miter_text))
    if not matches:
        return miter_text
    last_em = matches[-1]
    splice_at = last_em.start()

    return miter_text[:splice_at] + assume_line + miter_text[splice_at:]


def inject_into_path(
    miter_path: Path,
    invariant_sv: str,
    *,
    label: str,
    out_path: Path,
    target: InjectionTarget | None = None,
) -> Path:
    """Read ``miter_path``, inject, write to ``out_path``, return the path.

    Convenience wrapper for the common bundle-file shape used by
    the spike harness.
    """
    text = miter_path.read_text()
    new_text = inject_assume_property(
        text, invariant_sv, label=label, target=target
    )
    out_path.write_text(new_text)
    return out_path
