"""Centralized prompt library for kairos.sec.closed_loop.

Edit the .txt files in this directory to iterate on prompts.
The source modules read from here at import time — no code
change needed for prompt iteration.
"""
from pathlib import Path

_PROMPTS_DIR = Path(__file__).parent


def load_prompt(name: str) -> str:
    """Load a prompt template by name (without .txt extension)."""
    path = _PROMPTS_DIR / f"{name}.txt"
    if not path.is_file():
        raise FileNotFoundError(f"prompt template not found: {path}")
    return path.read_text()
