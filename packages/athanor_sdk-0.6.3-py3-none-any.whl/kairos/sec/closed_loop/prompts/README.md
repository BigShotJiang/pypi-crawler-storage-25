# Prompt Library: kairos.sec.closed_loop

Centralized prompt templates. Edit here, not in source files.

| File | Used by | Purpose |
|------|---------|---------|
| `proposer_system.txt` | `_proposer.py` | Main proposer system prompt |
| `mining_system.txt` | `mine_assumptions.py` | Assertion mining system prompt |
| `diff_mode_addendum.txt` | `diff_proposer.py` | Diff-mode constraint block |
| `refinement_guidance.txt` | `refine_after_refutation.py` | Anti-pattern + retry guidance |

## How to edit

1. Modify the `.txt` file.
2. The source module reads from the file at import time.
3. No code change needed for prompt iteration.
