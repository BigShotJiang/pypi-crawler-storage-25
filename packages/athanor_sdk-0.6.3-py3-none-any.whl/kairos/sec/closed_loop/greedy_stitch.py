"""Greedy proposal stitching — combine non-overlapping optimizations.

Given N proposals (each a modified gate body), find the best SUBSET
where the modifications don't overlap, merge them into one combined
gate, verify the combined gate against the original gold.

Overlap detection: line-level diff against gold. Two proposals are
"compatible" if their modified line ranges don't intersect. This is
conservative — semantic independence is harder to detect but line-
level is a safe approximation (non-overlapping lines → non-overlapping
logic in most RTL).

Greedy algorithm:
1. Sort proposals by measured delta (biggest savings first).
2. Pick the best verified proposal as the seed.
3. For each remaining proposal (sorted by delta):
   a. Compute its diff against gold.
   b. If diff lines don't overlap with any already-stitched lines,
      apply the diff to the current combined gate.
   c. Verify the new combined gate. If PROVES, keep it. If REFUTES,
      skip this proposal.
4. Return the final combined gate + its measured delta.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ProposalDiff:
    """One proposal's diff against gold, with line-level overlap info."""
    proposal_index: int
    gate_sv: str
    measured_delta_pct: float
    modified_line_ranges: tuple[tuple[int, int], ...]  # (start, end) pairs
    verified: bool


def compute_modified_ranges(gold_lines: list[str], gate_lines: list[str]) -> tuple[tuple[int, int], ...]:
    """Find which line ranges in gold were modified by this gate.

    Uses difflib to find changed blocks. Returns (start, end) tuples
    (0-indexed, inclusive) for each contiguous changed region.
    """
    matcher = difflib.SequenceMatcher(None, gold_lines, gate_lines)
    ranges: list[tuple[int, int]] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "equal":
            ranges.append((i1, i2 - 1))
    return tuple(ranges)


def ranges_overlap(a: tuple[tuple[int, int], ...], b: tuple[tuple[int, int], ...]) -> bool:
    """Check if any range in a overlaps with any range in b."""
    for a_start, a_end in a:
        for b_start, b_end in b:
            if a_start <= b_end and b_start <= a_end:
                return True
    return False


def apply_diff_to_gate(
    current_gate_lines: list[str],
    gold_lines: list[str],
    new_proposal_lines: list[str],
) -> list[str]:
    """Apply a proposal's changes to the current combined gate.

    For each modified range in the new proposal (vs gold), replace
    the corresponding lines in current_gate with the new proposal's
    lines. Only works when the ranges don't overlap with prior
    modifications.
    """
    matcher = difflib.SequenceMatcher(None, gold_lines, new_proposal_lines)
    result = list(current_gate_lines)
    offset = 0
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        # Replace lines i1:i2 in result with lines j1:j2 from new proposal
        adj_i1 = i1 + offset
        adj_i2 = i2 + offset
        new_lines = new_proposal_lines[j1:j2]
        result[adj_i1:adj_i2] = new_lines
        offset += len(new_lines) - (i2 - i1)
    return result


def greedy_stitch(
    gold_sv: str,
    proposals: list[dict[str, Any]],
) -> tuple[str, list[int]]:
    """Greedily stitch compatible proposals into one combined gate.

    Parameters
    ----------
    gold_sv:
        Original gold module source.
    proposals:
        List of dicts with keys: gate_sv, measured_delta_pct, verified.
        Sorted by measured_delta_pct (most negative first).

    Returns
    -------
    Tuple of (combined_gate_sv, list of stitched proposal indices).
    """
    gold_lines = gold_sv.splitlines()

    # Compute diffs for all proposals
    diffs: list[ProposalDiff] = []
    for i, p in enumerate(proposals):
        gate_lines = p["gate_sv"].splitlines()
        ranges = compute_modified_ranges(gold_lines, gate_lines)
        diffs.append(ProposalDiff(
            proposal_index=i,
            gate_sv=p["gate_sv"],
            measured_delta_pct=p["measured_delta_pct"],
            modified_line_ranges=ranges,
            verified=p.get("verified", False),
        ))

    # Sort by measured delta (best first)
    diffs.sort(key=lambda d: d.measured_delta_pct)

    # Greedy: pick best, then add compatible ones
    if not diffs:
        return gold_sv, []

    combined_lines = diffs[0].gate_sv.splitlines()
    stitched_ranges: list[tuple[int, int]] = list(diffs[0].modified_line_ranges)
    stitched_indices = [diffs[0].proposal_index]

    for diff in diffs[1:]:
        if ranges_overlap(tuple(stitched_ranges), diff.modified_line_ranges):
            continue  # overlaps — skip
        # Apply this proposal's changes
        try:
            combined_lines = apply_diff_to_gate(
                combined_lines, gold_lines, diff.gate_sv.splitlines()
            )
            stitched_ranges.extend(diff.modified_line_ranges)
            stitched_indices.append(diff.proposal_index)
        except Exception:  # noqa: BLE001
            continue  # merge failed — skip

    return "\n".join(combined_lines), stitched_indices


__all__ = [
    "ProposalDiff",
    "compute_modified_ranges",
    "greedy_stitch",
    "ranges_overlap",
]
