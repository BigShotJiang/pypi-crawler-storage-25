"""ATH-1143: kairos watch mode — continuous formal verification on RTL changes.

Monitors a git repository for changes to RTL files. When a verified
block's source changes, re-runs verification to confirm the
optimization still holds. Alerts if the optimization regresses.

Usage:
    kairos watch /path/to/rtl/dir --interval 60

Or programmatically:
    from kairos.sec.closed_loop.watch import watch_and_reverify
    watch_and_reverify("/path/to/rtl/dir", interval_sec=60)
"""
from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class WatchEvent:
    block: str
    rtl_path: str
    event: str
    old_hash: str | None = None
    new_hash: str | None = None
    reverify_result: str | None = None
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "block": self.block,
            "rtl_path": self.rtl_path,
            "event": self.event,
            "old_hash": self.old_hash,
            "new_hash": self.new_hash,
            "reverify_result": self.reverify_result,
            "timestamp": self.timestamp,
        }


def _file_hash(path: Path) -> str:
    import hashlib
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def _find_rtl_files(rtl_dir: Path) -> dict[str, Path]:
    """Map block name -> RTL file path for all .v/.sv files."""
    blocks = {}
    for ext in ("*.v", "*.sv"):
        for f in rtl_dir.rglob(ext):
            if f.name.startswith(".") or "__pycache__" in str(f):
                continue
            blocks[f.stem] = f
    return blocks


def _load_baseline(rtl_dir: Path) -> dict[str, str]:
    """Load the hash baseline from .kairos_watch_baseline.json."""
    baseline_path = rtl_dir / ".kairos_watch_baseline.json"
    if baseline_path.is_file():
        try:
            return json.loads(baseline_path.read_text())
        except Exception:  # noqa: BLE001
            pass
    return {}


def _save_baseline(rtl_dir: Path, baseline: dict[str, str]) -> None:
    path = rtl_dir / ".kairos_watch_baseline.json"
    path.write_text(json.dumps(baseline, indent=2) + "\n")


def _reverify_block(rtl_path: Path, timeout_sec: int = 300) -> str:
    """Re-run kairos optimize on a changed block. Returns verdict."""
    try:
        from kairos.sec.closed_loop.optimize_cli import optimize
        result = optimize(
            rtl_path=str(rtl_path),
            max_proposals=1,
            timeout_sec=timeout_sec,
        )
        if result.n_accepted() > 0:
            return "still_valid"
        return f"regression:{result.halt_reason}"
    except Exception as e:  # noqa: BLE001
        return f"error:{type(e).__name__}"


def scan_once(
    rtl_dir: str | Path,
    *,
    reverify: bool = True,
    timeout_sec: int = 300,
) -> list[WatchEvent]:
    """Scan for changed RTL files since last baseline. Returns events."""
    rtl_dir = Path(rtl_dir)
    blocks = _find_rtl_files(rtl_dir)
    baseline = _load_baseline(rtl_dir)
    events: list[WatchEvent] = []
    new_baseline = dict(baseline)
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

    for name, path in sorted(blocks.items()):
        current_hash = _file_hash(path)
        old_hash = baseline.get(name)

        if old_hash is None:
            new_baseline[name] = current_hash
            events.append(WatchEvent(
                block=name, rtl_path=str(path),
                event="new_block", new_hash=current_hash,
                timestamp=ts,
            ))
        elif current_hash != old_hash:
            reverify_result = None
            if reverify:
                reverify_result = _reverify_block(path, timeout_sec)
            new_baseline[name] = current_hash
            events.append(WatchEvent(
                block=name, rtl_path=str(path),
                event="changed", old_hash=old_hash, new_hash=current_hash,
                reverify_result=reverify_result, timestamp=ts,
            ))

    _save_baseline(rtl_dir, new_baseline)
    return events


def watch_and_reverify(
    rtl_dir: str | Path,
    *,
    interval_sec: int = 60,
    max_cycles: int | None = None,
    reverify: bool = True,
    on_event: Any = None,
) -> None:
    """Watch loop: scan for changes, reverify, repeat.

    Args:
        rtl_dir: directory to monitor
        interval_sec: seconds between scans
        max_cycles: stop after N cycles (None = run forever)
        reverify: if True, re-run optimize on changed blocks
        on_event: callback(event: WatchEvent) for each change detected
    """
    rtl_dir = Path(rtl_dir)
    cycle = 0

    while max_cycles is None or cycle < max_cycles:
        events = scan_once(rtl_dir, reverify=reverify)
        for ev in events:
            if on_event:
                on_event(ev)
            if ev.event == "changed":
                status = ev.reverify_result or "not_checked"
                print(
                    f"[kairos watch] {ev.block}: RTL changed "
                    f"({ev.old_hash} -> {ev.new_hash}) "
                    f"reverify={status}"
                )
                if status.startswith("regression:"):
                    print(
                        f"  WARNING: optimization may have regressed. "
                        f"Reason: {status}"
                    )
        cycle += 1
        if max_cycles is not None and cycle >= max_cycles:
            break
        time.sleep(interval_sec)
