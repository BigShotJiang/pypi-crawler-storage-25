"""Claude subagent proposer — uses Claude Code subagents instead of litellm API.

ATH-1172: Fleet-as-default. Instead of calling Azure Foundry / Bedrock
for LLM proposals, spawn a Claude subagent that reads the RTL, reasons
about it, and returns optimized gate Verilog.

Uses the same ProposerStrategy protocol as custom engines. The existing
litellm path stays untouched — this is an opt-in alternative activated
via --proposer-backend claude-agent.

The subagent gets the full prompt (system + block memory + cross-block
hints + port constraints) as a structured user message. Output is
parsed via the same JSON extraction fallback already in _proposer.py.
"""
from __future__ import annotations

import json
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any


# ATH-1212a: per-tool subprocess env allowlist canonical lives in
# `kairos.security.env_allowlist`. The `_safe_env` symbol below is a
# thin re-export so the 4 existing callsites
# (this file's claude_propose, sec/closed_loop/mine_assumptions.py:415,
# model_client/claude_subagent.py:89, sv/counterexample.py:132) keep
# working without textual change. New code should import the factory
# directly from kairos.security.env_allowlist.
from kairos.security.env_allowlist import safe_env_for_claude_subagent as _safe_env

import re as _re

_AUTH_ERROR_PATTERNS = _re.compile(
    r"AuthenticationError|authentication_error|invalid.api" r".key|"
    r"\b401\b.*(?:Unauthorized|invalid|denied)|"
    r"(?:api|auth).*(?:key|token).*(?:invalid|expired|missing)",
    _re.IGNORECASE,
)


class ProposerAuthenticationError(Exception):
    """Raised when a subagent subprocess fails due to API key / auth issues."""


def claude_propose(
    gold_sv: str,
    sig: dict[str, Any],
    max_proposals: int = 1,
    system_prompt: str = "",
    timeout_sec: int = 120,
) -> list[dict[str, Any]]:
    """Propose optimizations via Claude Code subagent.

    Writes the prompt to a temp file, invokes claude CLI as a
    subprocess, parses the JSON response.

    Returns list of proposal dicts matching ProposerStrategy protocol.
    """
    prompt = _build_subagent_prompt(gold_sv, sig, system_prompt, max_proposals)

    prompt_file = Path(tempfile.mktemp(suffix=".md"))
    prompt_file.write_text(prompt)

    try:
        result = subprocess.run(
            [
                "claude", "-p", prompt,
                "--output-format", "text",
                "--max-turns", "1",
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=_safe_env(),
        )
        response = result.stdout or ""
        if result.returncode != 0 and _AUTH_ERROR_PATTERNS.search(
            result.stderr or ""
        ):
            raise ProposerAuthenticationError(
                (result.stderr or "").strip()[:300]
            )
    except subprocess.TimeoutExpired:
        return []
    except FileNotFoundError:
        return []
    finally:
        prompt_file.unlink(missing_ok=True)

    return _parse_proposals(response, max_proposals)


def _build_subagent_prompt(
    gold_sv: str,
    sig: dict[str, Any],
    system_prompt: str,
    max_proposals: int,
) -> str:
    """Build the full prompt for the Claude subagent."""
    module = sig.get("target_module", "unknown")
    ports = sig.get("ports", [])
    port_list = "\n".join(
        f"  {p['name']} ({p['direction']}, width={p.get('width', 1)})"
        for p in ports
    )

    is_sequential = bool(sig.get("clock_port"))
    seq_hint = ""
    if is_sequential:
        seq_hint = (
            "\n\nThis is a SEQUENTIAL block (has clock + reset). "
            "Sequential optimization strategies: encoding swap (one-hot→binary), "
            "FSM re-encoding, pointer width narrowing, register sharing, clock gating. "
            "These changes preserve cycle-by-cycle behavior while reducing flip-flop count.\n"
        )

    return f"""You are a hardware optimization expert. Your task is to propose area-reducing
optimizations for a Verilog/SystemVerilog module. The optimization must be
FUNCTIONALLY EQUIVALENT to the original — formal verification will check this.
{seq_hint}
{system_prompt}

## Target Module: {module}

## Port Interface (MUST preserve exactly):
{port_list}

## Gold RTL:
```systemverilog
{gold_sv}
```

## Instructions:
Propose up to {max_proposals} optimization(s). For each, return a JSON object:

```json
{{
  "gate_sv": "<complete optimized Verilog module>",
  "transformation_class": "<one of: parameterization, structural, impl_swap>",
  "claimed_area_delta_pct": <negative number, e.g. -15.0>,
  "rationale": "<one sentence explaining the optimization>"
}}
```

CRITICAL RULES:
- The gate module MUST have the EXACT same port names, directions, and widths as the gold.
- Rename the gate module to {module}_gate.
- Only change internal logic. Do NOT add, remove, or rename ports.
- Return ONLY the JSON. No explanation outside the JSON block.
"""


def _extract_json_objects(text: str) -> list[str]:
    """Extract top-level JSON objects handling nested braces."""
    results = []
    i = 0
    while i < len(text):
        if text[i] == '{':
            depth = 1
            start = i
            i += 1
            in_string = False
            while i < len(text) and depth > 0:
                c = text[i]
                if c == '\\' and in_string:
                    i += 2
                    continue
                if c == '"':
                    in_string = not in_string
                elif not in_string:
                    if c == '{':
                        depth += 1
                    elif c == '}':
                        depth -= 1
                i += 1
            if depth == 0:
                candidate = text[start:i]
                if '"gate_sv"' in candidate:
                    results.append(candidate)
        else:
            i += 1
    return results


def _parse_proposals(response: str, max_proposals: int) -> list[dict[str, Any]]:
    """Parse proposals from Claude subagent response."""
    proposals = []

    json_blocks = _extract_json_objects(response)

    for block in json_blocks[:max_proposals]:
        try:
            parsed = json.loads(block)
            if "gate_sv" in parsed:
                proposals.append({
                    "gate_sv": parsed["gate_sv"],
                    "transformation_class": parsed.get(
                        "transformation_class", "generic"
                    ),
                    "claimed_area_delta_pct": float(
                        parsed.get("claimed_area_delta_pct", -5.0)
                    ),
                    "rationale": parsed.get("rationale", ""),
                })
        except (json.JSONDecodeError, ValueError, KeyError):
            continue

    return proposals


__all__ = ["claude_propose"]
