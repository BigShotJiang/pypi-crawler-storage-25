"""ATH-1110 — require active observe session for critical SDK functions.

Structural enforcement: proposer + verify_sec refuse to run without
an active kairos.observe session. Prevents ad-hoc scripts from
bypassing the audit trail (result persistence, Supabase events,
cert tarball generation).

The guard checks _CURRENT_CONTEXT from kairos.observe. If None,
raises RuntimeError with instructions to use the orchestrator.

Test code should use the `test_session()` context manager which
opens a no-op observe session satisfying the guard without needing
real Supabase credentials.
"""
from __future__ import annotations

import contextlib
import os
from typing import Generator


def require_active_session(caller_name: str) -> None:
    """Raise if no kairos.observe session is active.

    Called at the top of propose_transformations, verify_sec, and
    other critical SDK functions. Skipped when KAIROS_TEST_MODE=1
    is set (for unit tests that don't need observe).
    """
    if os.environ.get("KAIROS_TEST_MODE") == "1":
        return
    if os.environ.get("KAIROS_DEV_NO_SESSION_CHECK") == "1":
        return

    try:
        from kairos.observe import _CURRENT_CONTEXT
        ctx = _CURRENT_CONTEXT.get(None)
        if ctx is not None:
            return
    except ImportError:
        return  # observe not available — skip check

    raise RuntimeError(
        f"{caller_name} called without an active kairos.observe session. "
        f"Results will NOT be persisted to Supabase or the dashboard. "
        f"Use run_closed_loop_orchestration() or kairos_optimize_block() "
        f"which open an observe session automatically. "
        f"For tests, set KAIROS_TEST_MODE=1 or use the test_session() "
        f"context manager."
    )


@contextlib.contextmanager
def test_session() -> Generator[None, None, None]:
    """No-op observe session for tests. Satisfies the session guard."""
    os.environ["KAIROS_TEST_MODE"] = "1"
    try:
        yield
    finally:
        os.environ.pop("KAIROS_TEST_MODE", None)


__all__ = ["require_active_session", "test_session"]
