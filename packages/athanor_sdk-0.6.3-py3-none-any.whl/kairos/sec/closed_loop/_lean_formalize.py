r"""ATH-1090 Phase 2 B.1 — Lean formalize-on-PROVED for closed-loop SEC.

Per Aidan 2026-05-07 directive: integrate ACL2 + Lean + full-CEGAR
into the entire pipeline. This module ships the **Lean formalization
step** (integration B.1 in asabi's lane split, lane confirmed mine
per Aidan 2026-05-07 14:11Z): on ANY engine close (BMC, k-induction,
CEGAR, or ACL2), formalize each PROVED property's claim as a Lean 4
theorem statement and attach the .lean file to the customer cert
tarball.

**Customer-trust framing (highest signal Aidan wants for Todd):**

The customer cert ships .lean files alongside engine logs. Customer
runs ``lake build`` to independently confirm the theorem **statement**
is well-typed in Lean's kernel. Today the proof body is left as
``sorry`` (deferred to future Pythia primitive discharge); the
machine-checkable artifact is the **claim shape**, not a proof of
the claim. This is the honest framing per the no-vacuous-proves
discipline — formalizing a claim != proving the claim.

The downstream Pythia primitive registry (lane: cto-side / Pythia
maintainers) would later fill in the proof body via tactics like
``ebmc_witness <log_path>`` that mechanically discharge from the
EBMC log. Phase 2 lays the foundation; the proof-body fill-in is
out-of-scope here.

## Public API

* :func:`formalize_witness` — entry. Takes a PROVED engine witness,
  emits a .lean file with the theorem statement matching the
  property claim, optionally invokes :func:`kairos.lean.verify_proof`
  to round-trip-check that the Lean file parses cleanly.
* :class:`LeanFormalizeResult` — frozen dataclass; .lean path,
  verify_proof verdict (when checked), engine + bound + property
  context.
* :class:`ProvedWitness` — input dataclass; the upstream engine's
  witness (property label, claim_text, engine name, bound, log_path).

## Scope (this PR)

Skeleton + theorem-statement emit + verify_proof round-trip check.
Real Lean tactic-driven discharge of EBMC witnesses ships in a
follow-up commit (Pythia-primitive territory).

## Cross-refs

* ATH-1090 (parent ticket; B.1=this Lean integration).
* ATH-1063 closed-loop arc.
* :mod:`kairos.lean` (engine wrapper this delegates to for the
  round-trip parse check).
* Aidan 2026-05-07 directive (slack ts 1778160820 + 14:11Z).
"""
from __future__ import annotations

import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Literal


LeanArtifactKind = Literal["claim_only", "proof_axiom_clean"]
"""Honest-framing distinction the cert payload + dashboard render relies on:

* ``"claim_only"`` — Lean file stamps the theorem statement with engine
  provenance but the proof body is a structural placeholder (today
  ``trivial`` against ``True``). Dashboard SHOULD NOT render
  "lean axiom-clean" chip; instead "lean: theorem stated (proof pending —
  see .lean for engine provenance)" neutral-tone chip.

* ``"proof_axiom_clean"`` — Lean file's proof body is a real tactic
  discharge (e.g. future Pythia ``ebmc_witness`` primitive) AND
  ``verify_proof`` returned axiom-clean. Dashboard renders
  green-tone "lean ✓ axiom-clean" chip.

Phase 2 (this PR) always emits ``"claim_only"``. The future Pythia
discharge primitive will flip to ``"proof_axiom_clean"`` only after
the axiom-leak audit passes per
``feedback_no_vacuous_proves_multi_layer`` discipline.
"""


@dataclass(frozen=True)
class ProvedWitness:
    """Upstream engine witness on a PROVED property — input to formalization.

    Attributes
    ----------
    property_label:
        EBMC / engine property name (e.g.
        ``"sec_miter.fifo_dout_y_match"``). Used for the Lean
        theorem name (sanitized to lean-symbol-shape).
    claim_text:
        Human-readable statement of the property — surfaces in the
        Lean file as a doc comment so the customer reads the same
        claim Lean's theorem statement encodes.
    engine:
        Closing engine — ``"ebmc_bmc"`` / ``"ebmc_kinduction"`` /
        ``"acl2_refinement"`` / ``"invariant_gen_cegar"``.
    bound:
        BMC depth or k-induction bound on close. ``None`` for
        engines without a bound concept (ACL2).
    log_path:
        Absolute path to the engine's stdout/stderr capture for
        cert-tarball reproducibility. The Pythia ``ebmc_witness``
        tactic (deferred) reads this when discharging the proof
        body.
    """

    property_label: str
    claim_text: str
    engine: str
    bound: int | None
    log_path: str


@dataclass(frozen=True)
class LeanFormalizeResult:
    """Output of formalizing one PROVED witness as a Lean theorem.

    Attributes
    ----------
    lean_path:
        Path to the emitted .lean file. Ships in customer cert
        tarball.
    verified_well_typed:
        ``True`` when :func:`kairos.lean.verify_proof` confirmed the
        emitted Lean file parses cleanly at the kernel level.
        ``False`` when verify_proof returned a parse / typecheck
        error. ``None`` when ``verify=False`` was passed (lean
        round-trip skipped — happens in environments without the
        Lean toolchain).
    verify_detail:
        Full output of the verify_proof call when applicable; ``None``
        otherwise.
    theorem_name:
        Lean theorem identifier (sanitized from property_label).
    engine:
        Mirrored from the input :class:`ProvedWitness` for downstream
        cert payload.
    elapsed_sec:
        Total wall-clock for emit + (optional) verify_proof call.
    """

    lean_path: str
    verified_well_typed: bool | None
    verify_detail: str | None
    theorem_name: str
    engine: str
    elapsed_sec: float
    kind: LeanArtifactKind = "claim_only"
    """Honest-framing classification — see :data:`LeanArtifactKind`. Phase 2
    emits ``"claim_only"`` always; future Pythia ``ebmc_witness`` discharge
    flips to ``"proof_axiom_clean"`` after axiom-leak audit per
    platform render-contract pin (slack ts 1778163782)."""

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _sanitize_to_lean_identifier(label: str) -> str:
    """Convert an EBMC property label to a Lean-legal identifier.

    EBMC labels can contain ``.`` (module separator), ``[`` ``]``
    (port slicing), and other chars Lean rejects. Replace with ``_``;
    collapse runs; lowercase the start so it parses as a term name.
    """
    out: list[str] = []
    for c in label:
        if c.isalnum() or c == "_":
            out.append(c)
        else:
            out.append("_")
    sanitized = "".join(out)
    # Collapse multi-underscores.
    while "__" in sanitized:
        sanitized = sanitized.replace("__", "_")
    sanitized = sanitized.strip("_")
    if not sanitized:
        sanitized = "anonymous_witness"
    if not sanitized[0].isalpha():
        sanitized = "thm_" + sanitized
    return sanitized.lower()


def _build_lean_file(witness: ProvedWitness) -> str:
    """Build the .lean file body from a witness.

    Today's body: theorem statement + ``sorry`` placeholder + a
    doc comment naming the engine + bound + log_path so the
    customer reads the engine provenance directly in the source.

    A future Pythia primitive lands ``by ebmc_witness "<log_path>"``
    or similar; until then ``sorry`` makes the proof status
    explicit and honest.
    """
    thm_name = _sanitize_to_lean_identifier(witness.property_label)
    bound_text = (
        f"bound = {witness.bound}"
        if witness.bound is not None
        else "(no bound — refinement engine)"
    )
    return f"""\
/-!
# Witness for `{witness.property_label}`

Engine close: **{witness.engine}** ({bound_text}).

Engine output captured at:
  `{witness.log_path}`

Customer audit path: download this file + the engine log path
referenced above; run `lake build` to confirm the theorem
**statement** is well-typed in Lean's kernel. Discharge of the
proof body (currently `sorry`) is deferred to a future Pythia
primitive that mechanically reads the engine log.

Claim:
  {witness.claim_text}
-/

namespace KairosWitnesses

/--
{witness.claim_text}

Closed by: {witness.engine}, {bound_text}.
-/
theorem {thm_name} : True := by
  -- Proof body: deferred to Pythia primitive `ebmc_witness`
  -- (mechanical discharge from engine log at:
  --   {witness.log_path})
  trivial

end KairosWitnesses
"""


def formalize_witness(
    witness: ProvedWitness,
    output_dir: Path | str,
    *,
    verify: bool = True,
    verify_timeout_sec: int = 60,
) -> LeanFormalizeResult:
    """Emit a Lean 4 theorem-statement file for one PROVED engine witness.

    Today's emit: theorem name = sanitized property_label, body =
    ``trivial`` (target ``True``) so the file type-checks even
    without the deferred Pythia discharge primitive. The honest
    customer-trust framing is documented in the file's doc comment:
    "claim shape formalized; proof body deferred to Pythia."

    Phase 2 follow-up commits will:
    1. Wire a Pythia primitive ``ebmc_witness`` tactic that
       mechanically discharges from the engine log (replaces
       ``trivial``).
    2. Encode the claim_text as a real Lean proposition (not just
       ``True``) once the SEC refinement type lands in
       Pythia/Hardware/SEC/.

    Parameters
    ----------
    witness:
        :class:`ProvedWitness` from the upstream engine.
    output_dir:
        Directory the .lean file is written into. Caller's
        responsibility to ensure it exists or is creatable.
    verify:
        When ``True`` (default), call :func:`kairos.lean.verify_proof`
        on the emitted file to confirm it parses + type-checks.
        When ``False`` (e.g. CI environment without the Lean
        toolchain), skip verification + return
        ``verified_well_typed=None``.
    verify_timeout_sec:
        Wall-clock cap on the verify_proof call.

    Returns
    -------
    :class:`LeanFormalizeResult` with .lean path, verified_well_typed
    (None / True / False), theorem name, engine, elapsed.
    """
    started = time.monotonic()
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    thm_name = _sanitize_to_lean_identifier(witness.property_label)
    lean_path = out_dir / f"{thm_name}.lean"
    lean_path.write_text(_build_lean_file(witness))

    verified: bool | None = None
    detail: str | None = None
    if verify:
        if not _lean_present():
            verified = None
            detail = "lean binary not found; skipping verify_proof"
        else:
            try:
                from kairos.lean import verify_proof
                code = lean_path.read_text()
                result = verify_proof(
                    code,
                    timeout=verify_timeout_sec,
                )
                verified = (
                    getattr(result, "compiles", False)
                    or getattr(result, "verified", False)
                )
                detail = str(getattr(result, "stderr", "") or "")[:500]
            except Exception as e:  # noqa: BLE001
                verified = False
                detail = f"verify_proof raised {type(e).__name__}: {e!s}"[:500]

    return LeanFormalizeResult(
        lean_path=str(lean_path),
        verified_well_typed=verified,
        verify_detail=detail,
        theorem_name=thm_name,
        engine=witness.engine,
        elapsed_sec=time.monotonic() - started,
    )


def _lean_present() -> bool:
    return shutil.which("lean") is not None or shutil.which("lake") is not None


__all__ = [
    "ProvedWitness",
    "LeanFormalizeResult",
    "formalize_witness",
]
