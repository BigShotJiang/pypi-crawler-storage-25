"""Lean citation chain for optimization certs.

Maps optimization classes to Pythia/Hardware theorems so the cert
is self-contained: "PROVED by yosys equiv + backed by Lean theorem X
proving optimization class Y is sound."

The mapping is declarative — research updates it as new theorems land.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LeanCitation:
    """One Lean theorem citation for a cert."""
    theorem_name: str
    module_path: str
    statement_summary: str
    pythia_version: str = ""


# Optimization class -> Lean theorem mapping.
# Research updates this as new theorems land in Pythia.
OPTIMIZATION_CLASS_CITATIONS: dict[str, LeanCitation] = {
    "arithmetic_sharing": LeanCitation(
        theorem_name="ArithmeticSharing.sub_eq_add_not_plus_one",
        module_path="Pythia/Hardware/ArithmeticSharing.lean",
        statement_summary=(
            "Shared ADD/SUB via two's complement preserves equivalence: "
            "a - b = a + (~b + 1)"
        ),
    ),
    "xor_tree_restructuring": LeanCitation(
        theorem_name="XORTreeRestructuring.shared_xor_equiv",
        module_path="Pythia/Hardware/XORTreeRestructuring.lean",
        statement_summary=(
            "Factoring common XOR sub-expressions across check-bit "
            "computations preserves the generator matrix product"
        ),
    ),
    # Re-added: research proved all 5 (c8535f5). grep-verified on MissingCitations.lean.
    "find_first_set_algebraic": LeanCitation(
        theorem_name="MissingCitations.isolate_lowest_set_bit",
        module_path="Pythia/Hardware/MissingCitations.lean",
        statement_summary="din & (~din + 1) = din & (-din) (two's complement identity)",
        pythia_version="c8535f5",
    ),
    "onehot_to_binary": LeanCitation(
        theorem_name="MissingCitations.onehot_binary_equiv",
        module_path="Pythia/Hardware/MissingCitations.lean",
        statement_summary="One-hot and binary encoding represent the same state space",
        pythia_version="c8535f5",
    ),
    "opcode_grouping": LeanCitation(
        theorem_name="MissingCitations.opcode_group_equiv",
        module_path="Pythia/Hardware/MissingCitations.lean",
        statement_summary="Grouping opcodes by function preserves decode equivalence",
        pythia_version="c8535f5",
    ),
    "mux_reduction": LeanCitation(
        theorem_name="MissingCitations.mux_reduction_equiv",
        module_path="Pythia/Hardware/MissingCitations.lean",
        statement_summary="Reducing mux fan-in by merging identical select cases",
        pythia_version="c8535f5",
    ),
    "gated_input": LeanCitation(
        theorem_name="MissingCitations.gated_input_equiv",
        module_path="Pythia/Hardware/MissingCitations.lean",
        statement_summary="AND-gating unused inputs preserves output when gate is inactive",
        pythia_version="c8535f5",
    ),
    "operand_isolation": LeanCitation(
        theorem_name="PowerGatedRegister.gated_updates_when_enabled",
        module_path="Pythia/Hardware/PowerGatedRegister.lean",
        statement_summary=(
            "AND-gating datapath inputs with enable preserves output "
            "when enable is active"
        ),
    ),
    "opcode_factoring": LeanCitation(
        theorem_name="ArithmeticSharing.mask_merge_equiv",
        module_path="Pythia/Hardware/ArithmeticSharing.lean",
        statement_summary=(
            "Grouping mutually-exclusive operations into subgroups "
            "with shared decode preserves the case-statement semantics"
        ),
    ),
    "mux_simplification": LeanCitation(
        theorem_name="GatedClockEquivalence.clock_gate_functional_equiv",
        module_path="Pythia/Hardware/GatedClockEquivalence.lean",
        statement_summary="Reducing mux fan-in by eliminating dead select cases",
    ),
    "fp8_conversion": LeanCitation(
        theorem_name="FP8Conversion.fp8_fp32_roundtrip_error",
        module_path="Pythia/Hardware/FP8Conversion.lean",
        statement_summary=(
            "FP8 E4M3/E5M2 to FP32 upconversion is exact; "
            "FP32 to FP8 RNE rounding error <= eps_fp8 * |x|"
        ),
    ),
    "engine_contract": LeanCitation(
        theorem_name="EngineContract.engine_cert_valid",
        module_path="Pythia/Hardware/EngineContract.lean",
        statement_summary=(
            "Any engine satisfying EngineSoundness typeclass produces "
            "valid certs: verified output matches gold semantics"
        ),
    ),
    "abc_synthesis": LeanCitation(
        theorem_name="ABCSynthesisSoundness.resyn2_then_cec_sound",
        module_path="Pythia/Hardware/ABCSynthesisSoundness.lean",
        statement_summary=(
            "ABC resyn2 sequence preserves Boolean function when "
            "AllFunctionPreserving holds for each rewrite step"
        ),
    ),
    "toggle_power": LeanCitation(
        theorem_name="TogglePowerPreservation.fewer_gates_fewer_toggles",
        module_path="Pythia/Hardware/TogglePowerPreservation.lean",
        statement_summary=(
            "Fewer gates with same function implies toggle count "
            "of optimized circuit <= toggle count of original"
        ),
    ),
    "decompose_recompose": LeanCitation(
        theorem_name="DecomposeRecompose.decompose_recompose_sound",
        module_path="Pythia/Hardware/DecomposeRecompose.lean",
        statement_summary=(
            "Decompose a design into sub-blocks, optimize each independently, "
            "recompose: the composition is equivalent to the original"
        ),
    ),
    "pipeline_hazard": LeanCitation(
        theorem_name="PipelineHazard.forwarding_correct",
        module_path="Pythia/Hardware/PipelineHazard.lean",
        statement_summary=(
            "Data forwarding in pipelined CPUs preserves program semantics: "
            "forwarded value equals the value that would be read after writeback"
        ),
    ),
    "memory_consistency": LeanCitation(
        theorem_name="MemoryConsistency.fence_restores_sc",
        module_path="Pythia/Hardware/MemoryConsistency.lean",
        statement_summary=(
            "Fence instruction drains the store buffer and restores "
            "sequential consistency (real store buffer model, FIFO drain)"
        ),
    ),
    "sequential_equiv_bisimulation": LeanCitation(
        theorem_name="SequentialEquivFull.bisimulation_implies_trace_equiv",
        module_path="Pythia/Hardware/SequentialEquivFull.lean",
        statement_summary=(
            "Bisimilar FSMs produce identical output traces for all inputs"
        ),
    ),
    "ic3_pdr_soundness": LeanCitation(
        theorem_name="IC3PDRSoundness.ic3_soundness",
        module_path="Pythia/Hardware/IC3PDRSoundness.lean",
        statement_summary=(
            "IC3/PDR frame sequence implies no bad state is reachable "
            "(Bradley 2011 formalized)"
        ),
    ),
    "timing_arc_monotone": LeanCitation(
        theorem_name="PhysicalDesign.timing_arc_monotone",
        module_path="Pythia/Hardware/PhysicalDesign.lean",
        statement_summary="Gate delay is monotone in load capacitance",
    ),
    "slack_preservation": LeanCitation(
        theorem_name="PhysicalDesign.slack_preservation",
        module_path="Pythia/Hardware/PhysicalDesign.lean",
        statement_summary=(
            "Removing gates on non-critical paths preserves "
            "critical path slack"
        ),
    ),
    "fanout_delay": LeanCitation(
        theorem_name="PhysicalDesign.fanout_delay_logical_effort",
        module_path="Pythia/Hardware/PhysicalDesign.lean",
        statement_summary="Delay is linear in fanout (logical effort model)",
    ),
    "clock_skew": LeanCitation(
        theorem_name="PhysicalDesign.clock_skew_bounded",
        module_path="Pythia/Hardware/PhysicalDesign.lean",
        statement_summary="Clock tree synthesis maintains skew within budget",
    ),
    "burch_dill_refinement": LeanCitation(
        theorem_name="BurchDillRefinement.burch_dill_n_steps",
        module_path="Pythia/Hardware/BurchDillRefinement.lean",
        statement_summary=(
            "Burch-Dill processor verification: pipelined implementation "
            "refines sequential spec for all n steps"
        ),
    ),
    "burch_dill_compose": LeanCitation(
        theorem_name="BurchDillRefinement.burch_dill_compose",
        module_path="Pythia/Hardware/BurchDillRefinement.lean",
        statement_summary=(
            "Burch-Dill compositionality: if pipeline stages A and B each "
            "refine their specs, their composition A;B refines the composed "
            "spec. Enables per-stage verification of multi-stage pipelines."
        ),
    ),
    "uf_preserves_refinement": LeanCitation(
        theorem_name="BurchDillUF.uf_preserves_refinement",
        module_path="Pythia/Hardware/BurchDillUF.lean",
        statement_summary=(
            "Uninterpreted function abstraction preserves the refinement "
            "relation: if impl refines spec under UF-abstracted datapath "
            "operators, then impl refines spec under any concrete "
            "interpretation of those operators."
        ),
        pythia_version="f1246eb",
    ),
    "uf_abstraction_sound": LeanCitation(
        theorem_name="BurchDillUF.uf_abstraction_sound",
        module_path="Pythia/Hardware/BurchDillUF.lean",
        statement_summary=(
            "Soundness of UF abstraction for arithmetic operators: "
            "replacing +, *, / with uninterpreted functions preserves "
            "the congruence axiom (same inputs -> same outputs) and "
            "the verification result is valid for all concrete implementations."
        ),
        pythia_version="f1246eb",
    ),
    "uf_cegar_terminates": LeanCitation(
        theorem_name="BurchDillUF.uf_cegar_terminates",
        module_path="Pythia/Hardware/BurchDillUF.lean",
        statement_summary=(
            "CEGAR with UF abstraction terminates: remaining spurious "
            "counterexamples strictly decrease each iteration"
        ),
        pythia_version="b0eb199",
    ),
    "bmc_depth_monotone": LeanCitation(
        theorem_name="BMCCompleteness.bmc_depth_monotone",
        module_path="Pythia/Hardware/BMCCompleteness.lean",
        statement_summary=(
            "BMC depth monotonicity: if a property holds at bound K, "
            "it holds at all bounds <= K."
        ),
        pythia_version="09f9176",
    ),
    "bmc_finite_complete": LeanCitation(
        theorem_name="BMCCompleteness.bmc_finite_complete",
        module_path="Pythia/Hardware/BMCCompleteness.lean",
        statement_summary=(
            "BMC completeness for finite-state systems: if a property "
            "holds, BMC at sufficient depth will confirm it."
        ),
        pythia_version="09f9176",
    ),
    # diameter_bounded: REPLACED by diameter_bounded_complete (PR #109).
    # Old version proved k <= |S| (trivially). New version proves
    # bmcSafe(|S|) → ∀n ¬bad via pigeonhole. qa 4-check verified.
    "bmc_diameter_bounded_complete": LeanCitation(
        theorem_name="BMCCompleteness.diameter_bounded_complete",
        module_path="Pythia/Hardware/BMCCompleteness.lean",
        statement_summary=(
            "BMC completeness via pigeonhole: if no bad state is "
            "reachable within |S| steps, no bad state is reachable "
            "at any depth. Real completeness, not trivial bound."
        ),
        pythia_version="8a7f3cf",
    ),
    "fp_noise_convergence": LeanCitation(
        theorem_name="FPNoiseConvergence.fp_sgd_converges",
        module_path="Pythia/Numerical/FPNoiseConvergence.lean",
        statement_summary=(
            "SGD with FP arithmetic converges when per-step noise "
            "vanishes — proved under the physically reasonable assumption "
            "that FP rounding error shrinks as iterates approach the limit."
        ),
        pythia_version="6604730",
    ),
    "spectre_non_interference": LeanCitation(
        theorem_name="SpectreNonInterference.full_non_interference",
        module_path="Pythia/Hardware/SpectreNonInterference.lean",
        statement_summary=(
            "Spectre-class side-channel safety: architectural + timing "
            "non-interference under speculative execution"
        ),
    ),
    "compute_kernel_general": LeanCitation(
        theorem_name="ComputeKernelGeneral.warp_reduction_correct",
        module_path="Pythia/Numerical/ComputeKernelGeneral.lean",
        statement_summary=(
            "Domain-general accelerator verification: parallel reduction, "
            "bank-conflict-free shared memory, grid-stride coverage, "
            "systolic matmul correctness. Covers CUDA/Pallas/NKI/ROCm."
        ),
    ),
    "tlb_coherence": LeanCitation(
        theorem_name="TLBCoherence.invalidate_then_refill_correct",
        module_path="Pythia/Hardware/TLBCoherence.lean",
        statement_summary=(
            "TLB invalidation preserves coherence: invalidate removes "
            "mapping, preserves others, refill after invalidate is correct"
        ),
    ),
    "pipeline_stall_freedom": LeanCitation(
        theorem_name="PipelineStallFreedom.stall_free_balanced",
        module_path="Pythia/Hardware/PipelineStallFreedom.lean",
        statement_summary=(
            "Balanced pipeline stages do not introduce stalls: removing "
            "logic does not create new pipeline bubbles"
        ),
    ),
    "interrupt_safety": LeanCitation(
        theorem_name="InterruptSafety.mask_disables",
        module_path="Pythia/Hardware/InterruptSafety.lean",
        statement_summary=(
            "Interrupt mask disables delivery, ack clears pending, "
            "mask preserves other pending interrupts"
        ),
    ),
    "fifo_backpressure": LeanCitation(
        theorem_name="FIFOBackpressure.backpressure_prevents_overflow",
        module_path="Pythia/Hardware/FIFOBackpressure.lean",
        statement_summary="Backpressure prevents FIFO overflow",
    ),
    "bus_protocol": LeanCitation(
        theorem_name="BusProtocol.stable_valid_eventual_transfer",
        module_path="Pythia/Hardware/BusProtocol.lean",
        statement_summary="Bus protocol handshake correctness",
    ),
    "watchdog": LeanCitation(
        theorem_name="Watchdog.watchdog_fires_at_timeout",
        module_path="Pythia/Hardware/Watchdog.lean",
        statement_summary="Watchdog timer fires on expiry",
    ),
    "formal_refinement": LeanCitation(
        theorem_name="FormalRefinement.refinement_preserves_safety",
        module_path="Pythia/Hardware/FormalRefinement.lean",
        statement_summary=(
            "Refinement preserves safety: if spec is safe and impl "
            "refines spec, then impl is safe"
        ),
    ),
    "ecc_secded": LeanCitation(
        theorem_name="ECC_SECDED.sec_corrects_single_error",
        module_path="Pythia/Hardware/ECC_SECDED.lean",
        statement_summary=(
            "SECDED: single error correction via syndrome decode, "
            "double error detection via overall parity"
        ),
    ),
    "power_state_machine": LeanCitation(
        theorem_name="PowerStateMachine.wake_path_exists",
        module_path="Pythia/Hardware/PowerStateMachine.lean",
        statement_summary=(
            "Power state machine: no direct active-to-sleep transition, "
            "wake path always exists from any sleep state"
        ),
    ),
    "flow_control": LeanCitation(
        theorem_name="FlowControl.send_preserves_credits",
        module_path="Pythia/Hardware/FlowControl.lean",
        statement_summary=(
            "Credit-based flow control: send preserves credit count, "
            "no send on zero credits"
        ),
    ),
    "clock_gating_cell": LeanCitation(
        theorem_name="ClockGatingCell.clock_gate_functional_equiv",
        module_path="Pythia/Hardware/ClockGatingCell.lean",
        statement_summary="Clock gating cell preserves functional behavior when enabled",
    ),
    "register_file_safety": LeanCitation(
        theorem_name="RegisterFileSafety.read_after_write",
        module_path="Pythia/Hardware/RegisterFileSafety.lean",
        statement_summary="Register file read-after-write returns written value",
    ),
    "axi_protocol": LeanCitation(
        theorem_name="AXIProtocol.stable_valid_eventual_transfer",
        module_path="Pythia/Hardware/AXIProtocol.lean",
        statement_summary="AXI VALID/READY deadlock freedom: stable valid leads to transfer",
    ),
    "sram_model": LeanCitation(
        theorem_name="SRAMModel.sram_write_read_same",
        module_path="Pythia/Hardware/SRAMModel.lean",
        statement_summary="SRAM write-read-same: read after write to same address returns written value",
    ),
}

# NKI kernel theorem citations (research PR #97, all sorry-free).
NKI_THEOREM_CITATIONS: dict[str, LeanCitation] = {
    "softmax_shift_invariance": LeanCitation(
        theorem_name="Softmax.softmax_shift_invariant",
        module_path="Pythia/Numerical/Softmax.lean",
        statement_summary="softmax(x) = softmax(x - c) for any c in R",
    ),
    "online_softmax_eq_offline": LeanCitation(
        theorem_name="LogSumExpStable.log_sum_exp_shift",
        module_path="Pythia/Numerical/Accelerator/LogSumExpStable.lean",
        statement_summary=(
            "Exact-arithmetic equivalence between online and offline "
            "softmax-attention via log-sum-exp shift stability"
        ),
    ),
    "fp_running_rescale_bound": LeanCitation(
        theorem_name="MixedPrecision.mixed_precision_inner_product_error",
        module_path="Pythia/Numerical/Accelerator/MixedPrecision.lean",
        statement_summary=(
            "8 * TILE_COUNT * eps * max(|out|) worst-case FP error bound "
            "for the running-rescale recurrence"
        ),
    ),
    "softcap_lipschitz": LeanCitation(
        theorem_name="Accelerator.softcap_lipschitz",
        module_path="Pythia/Numerical/Accelerator.lean",
        statement_summary="softcap(x, c) is Lipschitz-1 for all c > 0",
    ),
    "rope_orthogonal_rotation": LeanCitation(
        theorem_name="RoPE.rotation_transpose_mul_self",
        module_path="Pythia/Numerical/RoPE.lean",
        statement_summary=(
            "RoPE rotation matrix is orthogonal: R^T * R = I, "
            "preserving inner products under rotary position embedding"
        ),
    ),
}


def cite_optimization(transformation_class: str, rationale: str = "") -> LeanCitation | None:
    """Look up the Lean citation for an optimization class.

    Tries exact match first, then keyword match against the rationale.
    Returns None if no citation is available.
    """
    if transformation_class in OPTIMIZATION_CLASS_CITATIONS:
        return OPTIMIZATION_CLASS_CITATIONS[transformation_class]

    rationale_lower = rationale.lower()
    keyword_map = {
        "shared add": "arithmetic_sharing",
        "complement": "arithmetic_sharing",
        "xor tree": "xor_tree_restructuring",
        "xor sharing": "xor_tree_restructuring",
        "hamming": "xor_tree_restructuring",
        "din & (~din": "find_first_set_algebraic",
        "find first": "find_first_set_algebraic",
        "isolate lowest": "find_first_set_algebraic",
        "one-hot": "onehot_to_binary",
        "onehot": "onehot_to_binary",
        "operand isolation": "operand_isolation",
        "and-gate": "operand_isolation",
        "gating": "operand_isolation",
        "opcode factor": "opcode_factoring",
        "group decode": "opcode_factoring",
        "mux simpl": "mux_simplification",
        "mux reduc": "mux_simplification",
        "fp8": "fp8_conversion",
        "fp32": "fp8_conversion",
        "abc": "abc_synthesis",
        "resyn": "abc_synthesis",
        "aig rewrite": "abc_synthesis",
        "toggle power": "toggle_power",
        "fewer gates": "toggle_power",
        "decompose": "decompose_recompose",
        "recompose": "decompose_recompose",
        "sub-block": "decompose_recompose",
        "pipeline hazard": "pipeline_hazard",
        "forwarding": "pipeline_hazard",
        "data forward": "pipeline_hazard",
    }
    for keyword, class_name in keyword_map.items():
        if keyword in rationale_lower:
            return OPTIMIZATION_CLASS_CITATIONS.get(class_name)

    return None


def format_citation_for_cert(citation: LeanCitation) -> dict[str, str]:
    """Format a citation for inclusion in the cert payload."""
    return {
        "lean_theorem": citation.theorem_name,
        "lean_module": citation.module_path,
        "lean_statement": citation.statement_summary,
    }


def cite_nki_theorem(theorem_key: str) -> LeanCitation | None:
    """Look up a Pythia NKI theorem by key."""
    return NKI_THEOREM_CITATIONS.get(theorem_key)


__all__ = [
    "LeanCitation",
    "OPTIMIZATION_CLASS_CITATIONS",
    "NKI_THEOREM_CITATIONS",
    "cite_optimization",
    "cite_nki_theorem",
    "format_citation_for_cert",
]
