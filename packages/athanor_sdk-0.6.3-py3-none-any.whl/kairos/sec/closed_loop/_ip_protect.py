"""ATH-995: IP protection manifest for Cython compilation.

Lists high-IP modules that must be compiled to .so before
shipping customer wheels. Source .py files are excluded from
the wheel; only compiled .so files ship.

The build pipeline (build_cython.py) reads this manifest and
compiles each listed module via Cython.
"""
from __future__ import annotations

# Modules containing proprietary IP that must be Cython-compiled
# before customer wheel shipping. Source .py is stripped from wheel.
HIGH_IP_MODULES: list[str] = [
    "kairos.sec.closed_loop._proposer",      # prompt templates + taxonomy
    "kairos.sec.closed_loop.prompt_composer", # block-class hints + ECC swap
    "kairos.sec.closed_loop._orchestrator",   # decision logic + gates
    "kairos.sec.closed_loop.ecc_decompose",   # ABC optimization path
    "kairos.sec.closed_loop.flow_guard",      # safety validation
    "kairos.sec.closed_loop.flow_config",     # flow configuration
]

# Modules that are medium-IP (optimization logic, not prompts)
MEDIUM_IP_MODULES: list[str] = [
    "kairos.sec.closed_loop.verify_pipeline",
    "kairos.sec.closed_loop.measurement",
    "kairos.sec.closed_loop.toggle_power",
    "kairos.sec.closed_loop.yosys_equiv",
    "kairos.sec.closed_loop.bundle_loader",
    "kairos.sec.closed_loop.fifo_encoding_swap",
    "kairos.sec.closed_loop.lean_citations",
]


def get_cython_targets(include_medium: bool = True) -> list[str]:
    """Return list of module paths to compile via Cython."""
    targets = list(HIGH_IP_MODULES)
    if include_medium:
        targets.extend(MEDIUM_IP_MODULES)
    return targets


def module_to_path(module: str) -> str:
    """Convert dotted module name to source file path."""
    return "src/" + module.replace(".", "/") + ".py"


__all__ = [
    "HIGH_IP_MODULES",
    "MEDIUM_IP_MODULES",
    "get_cython_targets",
    "module_to_path",
]
