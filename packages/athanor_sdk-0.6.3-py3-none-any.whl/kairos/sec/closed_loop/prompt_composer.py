"""Dynamic prompt composition for the proposer.

Instead of one static prompt file + hardcoded addendums, compose
the prompt from modular sections based on what we know about the
design. Each section is optional and fires based on design analysis.

This is the "elegant orchestrator" pattern Aidan asked for: the MCP
dynamically adapts the prompt to the problem, not the other way around.
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

_memory_loaded_flag = threading.local()


def compose_system_prompt(
    *,
    gold_sv: str,
    sig: dict[str, Any],
    synth_report: str | None = None,
    pattern_invariants: list | None = None,
    prior_attempts: list[dict] | None = None,
    block_class: str | None = None,
) -> str:
    """Compose a tailored system prompt for this specific block.

    Sections are added based on design analysis:
    - Base prompt (always)
    - Synthesis baseline (when available — tells proposer the real bar)
    - Block-class hints (ECC, FIFO, ALU, arbiter — different strategies)
    - Pattern invariants (constraints the optimization must preserve)
    - Prior attempt feedback (what didn't work — don't repeat)
    """
    sections = []

    # 1. Base prompt from file
    try:
        from kairos.sec.closed_loop.prompts import load_prompt
        sections.append(load_prompt("proposer_system"))
    except (FileNotFoundError, ImportError):
        from kairos.sec.closed_loop._proposer import _PROPOSER_SYSTEM_PROMPT
        sections.append(_PROPOSER_SYSTEM_PROMPT)

    # 1b. Port preservation constraint (all block classes)
    ports = sig.get("ports", [])
    if ports:
        port_list = ", ".join(
            f"{p['name']} ({p['direction']}, w={p.get('width', 1)})"
            for p in ports
        )
        sections.append(
            f"\n## MANDATORY PORT INTERFACE (copy verbatim)\n"
            f"Your gate module MUST preserve these exact port names, "
            f"directions, and widths: {port_list}\n"
            f"The verification miter binds gold and gate by port name. "
            f"Any port rename, removal, or width change causes "
            f"verification failure. Copy the module header from gold."
        )

    # 2. Synthesis baseline — concrete cell count target
    if synth_report:
        sections.append(
            f"\n## Synthesis baseline (yosys synth_stat on gold)\n"
            f"{synth_report}\n"
            f"Your gate MUST have fewer cells than the gold after synthesis. "
            f"The structural gate enforces this before verification."
        )

    # 2b. FIFO encoding swap auto-detect
    detected_class = block_class or _detect_block_class(gold_sv, sig)
    if detected_class == "fifo":
        try:
            from kairos.sec.closed_loop.fifo_encoding_swap import detect_fifo_encoding
            fifo_analysis = detect_fifo_encoding(gold_sv, sig)
            if fifo_analysis.get("swap_recommended"):
                ptrs = fifo_analysis["onehot_pointers"]
                ptr_names = ", ".join(p["name"] for p in ptrs)
                sections.append(
                    f"\n## DETECTED ONE-HOT POINTERS (auto-analyzed)\n"
                    f"These pointers are one-hot encoded at width {fifo_analysis['onehot_width']}: "
                    f"{ptr_names}\n"
                    f"Binary encoding needs only {fifo_analysis['binary_width']} bits.\n"
                    f"SWAP THESE to binary. Use transformation_class: impl_swap.\n"
                )
        except Exception:  # noqa: BLE001
            pass

    # 2c. Scoped memory — global → class → block (ATH scope tags)
    # ATH-1168: Anti-forgetting gate — set flag to confirm memory was loaded
    _memory_loaded_flag.loaded = True
    try:
        from kairos.sec.closed_loop.block_memory import format_for_proposer_scoped
        if gold_sv:
            import hashlib as _hl
            _block_hash = _hl.sha256(gold_sv.encode()).hexdigest()[:16]
            _block_path = f"<content:{_block_hash}>"
            scoped_ctx = format_for_proposer_scoped(
                block_path=_block_path,
                block_class=detected_class if detected_class and detected_class != "generic" else None,
            )
            if scoped_ctx:
                sections.append(f"\n{scoped_ctx}")
    except Exception:  # noqa: BLE001
        pass

    # 3. Block-class-specific hints
    hint = _CLASS_HINTS.get(detected_class)
    if hint:
        sections.append(f"\n## Block-class optimization guidance\n{hint}")

    # 3b. Mined assumptions — proved structural invariants for this block
    mined = sig.get("mined_assumptions", [])
    if mined:
        sections.append("\n## PROVED ASSUMPTIONS (you may rely on these)")
        for a in mined[:8]:
            sections.append(f"- {a}")
        sections.append(
            "\nThese properties are formally proved to hold on the gold design. "
            "Your optimization may ASSUME them — they narrow the verification "
            "space and allow transformations that are correct under normal "
            "operating conditions."
        )

    # 4. Pattern invariants from ATH-1114
    if pattern_invariants:
        from kairos.sec.closed_loop.pattern_invariants import format_for_proposer
        inv_text = format_for_proposer(pattern_invariants)
        if inv_text:
            sections.append(f"\n{inv_text}")

    # 4b. Agent hints from message queue
    agent_hints = sig.get("proposer_hints", [])
    if agent_hints:
        sections.append("\n## AGENT HINTS (from customer agent mid-flow)")
        for h in agent_hints[-5:]:
            sections.append(f"- {h}")
        sections.append("")

    # 5. Prior attempt feedback — don't repeat failures
    if prior_attempts:
        feedback = _format_prior_attempts(prior_attempts)
        if feedback:
            sections.append(f"\n## Prior attempts (DO NOT repeat these)\n{feedback}")

    return "\n".join(sections)


def _detect_block_class(gold_sv: str, sig: dict) -> str:
    """Auto-detect the block class from RTL content."""
    low = gold_sv.lower()
    module = sig.get("target_module", "").lower()

    if "hamming" in module or "ecc" in module or "parity" in low:
        return "ecc"
    if "fifo" in module or "push" in low and "pop" in low:
        return "fifo"
    if "alu" in module or "opcode" in low:
        return "alu"
    if "arbiter" in module or "grant" in low:
        return "arbiter"
    if "mux" in module:
        return "mux"
    if "mem" in module or "sram" in low:
        return "memory"
    if not sig.get("clock_port"):
        return "combo"
    return "generic"


_CLASS_HINTS: dict[str, str] = {
    "ecc": (
        "This is a parity/ECC block. XOR operations are associative and "
        "commutative. Look for shared intermediate XOR results across "
        "check-bit computations. The generator matrix can be factored to "
        "share sub-expressions.\n\n"
        "CRITICAL PORT PRESERVATION: Your gate module MUST have EXACTLY "
        "the same port names, directions, and widths as the gold module. "
        "Copy the port list verbatim. Only change the internal logic "
        "(assign statements, wire declarations). The verification miter "
        "binds gold and gate by port name — any port rename causes "
        "verification failure.\n\n"
        "DECOMPOSITION STRATEGY: Optimize one check-bit computation at "
        "a time. Each check_out[i] = XOR of a subset of data_in bits. "
        "Find common XOR sub-expressions between check_out[i] and "
        "check_out[j], extract them into shared wires, and reuse. "
        "Do NOT restructure the entire module at once — factor one "
        "group of check bits, verify it preserves the generator matrix, "
        "then factor the next group."
    ),
    "alu": (
        "This is an ALU with multiple operations. Target: shared arithmetic "
        "units across mutually-exclusive operations (one adder for ADD and "
        "SUB via complement input). Opcode factoring (group operations into "
        "subgroups with shared decode) reduces mux depth. This class has "
        "proven -27% compound area reduction."
    ),
    "fifo": (
        "This is a FIFO. Two optimization strategies:\n\n"
        "STRATEGY 1 — REMOVE REDUNDANT COUNT REGISTER:\n"
        "If the FIFO has a separate count register tracking occupancy, "
        "REMOVE it. Derive count from pointer difference: "
        "count = (wr_ptr - rd_ptr). This saves the count register FFs "
        "plus the count update mux/adder logic. Derive full = "
        "(count == DEPTH), empty = (count == 0) from the pointer diff.\n\n"
        "STRATEGY 2 — ENCODING SWAP:\n"
        "If pointers use one-hot encoding, convert to binary. "
        "One-hot uses DEPTH bits per pointer, binary uses "
        "ceil(log2(DEPTH)). At DEPTH=4: 4 bits -> 2 bits.\n\n"
        "CRITICAL: Preserve ALL output behaviors: "
        "push/pop/full/empty/dout/count. The gate module must have "
        "EXACTLY the same ports as the gold.\n\n"
        "Use transformation_class: structural."
    ),
    "arbiter": (
        "This is an arbiter. The grant signal MUST remain one-hot "
        "($onehot0(grant)). Fairness properties must be preserved. "
        "Look for: priority encoder simplification, round-robin state "
        "compression, grant-mask sharing."
    ),
    "mux": (
        "This is a mux. The one-hot NAND-NAND implementation is often "
        "already optimal. Binary-encoded mux may save area but changes "
        "behavior when select has multiple bits set. Only propose binary "
        "encoding if the select is guaranteed one-hot."
    ),
    "memory": (
        "This is a memory wrapper. Look for: address/data bus gating "
        "when chip-enable is inactive (operand isolation for power), "
        "redundant register stages that synthesis can't remove."
    ),
    "combo": (
        "This is a pure combinational block. No sequential state. "
        "Focus on: boolean minimization, shared sub-expressions, "
        "width narrowing, dead-branch elimination. yosys equiv will "
        "verify in seconds."
    ),
    "generic": (
        "This is a sequential block with clock and reset. "
        "Sequential optimization strategies:\n\n"
        "1. ENCODING SWAP: if registers use one-hot encoding, "
        "convert to binary. One-hot uses N bits, binary uses "
        "ceil(log2(N)). This is the biggest area win on sequential blocks.\n\n"
        "2. FSM RE-ENCODING: if a state machine uses wide one-hot "
        "states, re-encode to binary or gray code. Fewer flip-flops, "
        "smaller next-state logic.\n\n"
        "3. POINTER OPTIMIZATION: if counters or pointers are wider "
        "than needed (e.g., 32-bit counter for a max count of 15), "
        "narrow to the minimum width (4 bits).\n\n"
        "4. REGISTER SHARING: if two registers are never live at the "
        "same time (mutually exclusive enables), merge them into one "
        "register with a muxed input.\n\n"
        "5. CLOCK GATING: if a register bank only updates on specific "
        "conditions, add a clock-enable gate to reduce dynamic power "
        "without changing function.\n\n"
        "Use transformation_class: impl_swap for encoding changes, "
        "structural for everything else."
    ),
}


def _format_prior_attempts(attempts: list[dict]) -> str:
    """Format prior failed attempts as anti-patterns."""
    lines = []
    for i, a in enumerate(attempts[:5]):
        reason = a.get("outcome_reason", "unknown")
        delta = a.get("claimed_area_delta_pct", 0)
        lines.append(
            f"{i+1}. Claimed {delta}% but FAILED: {reason[:150]}"
        )
    return "\n".join(lines)


def was_memory_loaded() -> bool:
    """Check if memory was loaded during the last compose_system_prompt call."""
    return getattr(_memory_loaded_flag, "loaded", False)


def reset_memory_flag() -> None:
    """Reset the memory-loaded flag (call before compose)."""
    _memory_loaded_flag.loaded = False


__all__ = [
    "compose_system_prompt",
    "reset_memory_flag",
    "was_memory_loaded",
]
