"""kairos.sec.closed_loop — closed-loop SEC orchestration (ATH-988).

Scaffolded against the Annapurna chief-architect ask in
:issue:`ATH-988` (parent epic) for an LLM-orchestrated RTL
area-optimization flow that closes formal-equivalence-verification
in a propose-verify-adjust loop.

This package is the SEC-flavored grouping of the four closed-loop
children (per asabi's lane-naming nudge 2026-05-04 in #dev-sdk):

* :mod:`._proposer` — LLM-driven area-optimization proposer
  (:issue:`ATH-989`).
* :mod:`._ranker`   — target identification + ranking with
  openSTA-aware timing weight (:issue:`ATH-990`).
* :mod:`._orchestrator` — the propose-verify-adjust state machine
  (:issue:`ATH-991`).
* :mod:`._invariant_gen` — LLM-driven inductive-invariant generation
  bridging k-induction INCONCLUSIVE outputs to discharged proofs
  (:issue:`ATH-992`).

Today this scaffold ships only :mod:`._invariant_gen` + its
:mod:`._miter_inject` helper, sized as the W1 D-spike target
against the two v2 ``toy_fifo_chain_v2_sec`` INCONCLUSIVE
properties (``full_match``, ``empty_match``). The other three
submodules land in W1 (proposer + ranker) and W2 (orchestrator)
per the W1/W2/W3 cadence in the triage thread.

The harness here is *deliberately not* customer-facing yet. The
build-tarball pre-flight gates that ship customer-facing artifacts
will need an additional class — ``area-delta vs verdict
consistency cross-check`` — before any closed-loop output is
shipped to a customer (see the qa-side flag in the triage
thread). That gate is not in this scaffold.
"""
from __future__ import annotations

from kairos.sec.closed_loop._invariant_gen import (
    InvariantCandidate,
    InvariantGenAttempt,
    InvariantGenResult,
    generate_invariant,
)
from kairos.sec.closed_loop._miter_inject import (
    InjectionTarget,
    inject_assume_property,
)
from kairos.sec.closed_loop._orchestrator import (
    ClosedLoopResult,
    DisplayMode,
    IterationRecord,
    IterationState,
    OrchestratorHaltReason,
    OrchestratorRunResult,
    derive_display_mode,
    run_closed_loop_orchestration,
)
from kairos.sec.closed_loop._proposer import (
    ProposalRunResult,
    TransformationClass,
    TransformationProposal,
    propose_transformations,
)
from kairos.sec.closed_loop._ranker import (
    RankedTarget,
    RankerResult,
    StaticBlockMetrics,
    TimingProfile,
)
from kairos.sec.closed_loop._retry_harness import (
    InnerAttemptStatus,
    InnerRetryAttempt,
    with_inner_retry,
)

__all__ = [
    "InvariantCandidate",
    "InvariantGenAttempt",
    "InvariantGenResult",
    "generate_invariant",
    "InjectionTarget",
    "inject_assume_property",
    # ATH-991 orchestrator state-machine exports
    "DisplayMode",
    "IterationRecord",
    "IterationState",
    "OrchestratorHaltReason",
    "OrchestratorRunResult",
    "derive_display_mode",
    # ATH-1063 Phase 0a-wiring public entry point
    "ClosedLoopResult",
    "run_closed_loop_orchestration",
    # ATH-989 proposer exports
    "ProposalRunResult",
    "TransformationClass",
    "TransformationProposal",
    "propose_transformations",
    # ATH-990 ranker exports
    "RankedTarget",
    "RankerResult",
    "StaticBlockMetrics",
    "TimingProfile",
    # ATH-1089 retry-harness primitive
    "InnerAttemptStatus",
    "InnerRetryAttempt",
    "with_inner_retry",
]
