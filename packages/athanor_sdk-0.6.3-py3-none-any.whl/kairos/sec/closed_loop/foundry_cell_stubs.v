// Behavioral blackbox stubs for foundry standard cells used in Annapurna's
// basic_cells library (/common/rtl/anpa_lib_us/basic_cells/).
//
// These cells are NDA-protected (TSMC/Samsung) but are simple standard gates,
// flip-flops, clock muxes, and clock gates.  The stubs provide behavioral
// Verilog so that yosys can parse the 29 previously-blocked basic_cells
// modules without access to the foundry PDK.
//
// Port names and functional behavior are extracted from instantiation sites
// in the Annapurna RTL.  Each cell family is grouped by function; process/
// voltage/drive-strength variants share the same behavioral body.
//
// Cell count: 109 unique cell names across 16 functional classes.
//
// Conventions:
//   - Active-high clear  : CD  (clear/reset, active high)
//   - Active-low set     : SDN (set-not, active low)
//   - Active-low reset   : RD  (reset, active low — HSBLVT FDPRBQ family)
//   - Scan ports (SI, SE, SO) are accepted but ignored in behavioral model.

// ============================================================================
// 1. TWO-INPUT AND  (CKAN2 family)
//    Ports: .A1, .A2 inputs; .Z output
//    Function: Z = A1 & A2
// ============================================================================

module CKAN2D1BWP210H6P51CNODULVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D1BWP240H8P57PDLVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D1BWP300H8P64PDLVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D2BWP130HPNPN3P48CPDULVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D2BWP143M169H3P48CPDULVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D2BWP156HPNPN3P48CPDULVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D2BWP169H3P48CPDULVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2D4BWP16P90CPDLVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

module CKAN2KAD1BWP280H6P57CNODLVT (input A1, input A2, output Z);
  assign Z = A1 & A2;
endmodule

// ============================================================================
// 2. TWO-INPUT AND  (HSBLVT AN2 family)
//    Ports: .A1, .A2 inputs; .X output
//    Function: X = A1 & A2
// ============================================================================

module HSBLVT16_AN2_MM_4 (input A1, input A2, output X);
  assign X = A1 & A2;
endmodule

// ============================================================================
// 3. FOUR-INPUT AND  (HSBLVT AN4)
//    Ports: .A1, .A2, .A3, .A4 inputs; .X output
//    Function: X = A1 & A2 & A3 & A4
// ============================================================================

module HSBLVT16_AN4_4 (input A1, input A2, input A3, input A4, output X);
  assign X = A1 & A2 & A3 & A4;
endmodule

// ============================================================================
// 4. BUFFER  (HSBLVT/HSBULT BUF family)
//    Ports: .A input; .X output
//    Function: X = A
// ============================================================================

module HSBLVT16_BUF_S_8 (input A, output X);
  assign X = A;
endmodule

module HSBULT16_BUF_S_4 (input A, output X);
  assign X = A;
endmodule

// ============================================================================
// 5. INVERTER  (HSBLVT/HSBULT/HSBSVT INV family)
//    Ports: .A input; .X output
//    Function: X = ~A
// ============================================================================

module HSBLVT16_INV_S_8 (input A, output X);
  assign X = ~A;
endmodule

module HSBULT16_INV_S_2 (input A, output X);
  assign X = ~A;
endmodule

module HSBSVT20_INV_1 (input A, output X);
  assign X = ~A;
endmodule

// ============================================================================
// 6. TWO-INPUT XOR  (HSBLVT EO2)
//    Ports: .A1, .A2 inputs; .X output
//    Function: X = A1 ^ A2
// ============================================================================

module HSBLVT16_EO2_4 (input A1, input A2, output X);
  assign X = A1 ^ A2;
endmodule

// ============================================================================
// 7. TWO-INPUT OR  (HSBLVT OR2)
//    Ports: .A1, .A2 inputs; .X output
//    Function: X = A1 | A2
// ============================================================================

module HSBLVT16_OR2_4 (input A1, input A2, output X);
  assign X = A1 | A2;
endmodule

// ============================================================================
// 8. OR4B — 4-input OR with one inverted input
//    Ports: .A (inverted), .B1, .B2, .B3 inputs; .X output
//    Function: X = ~A | B1 | B2 | B3
// ============================================================================

module HSBLVT16_OR4B_4 (input A, input B1, input B2, input B3, output X);
  assign X = (~A) | B1 | B2 | B3;
endmodule

module HSBSVT16_OR4B_1 (input A, input B1, input B2, input B3, output X);
  assign X = (~A) | B1 | B2 | B3;
endmodule

// ============================================================================
// 9. TWO-INPUT NAND  (HSBLVT/HSBSVT ND2 family)
//    Ports: .A1, .A2 inputs; .X output
//    Function: X = ~(A1 & A2)
// ============================================================================

module HSBLVT16_ND2_MM_4 (input A1, input A2, output X);
  assign X = ~(A1 & A2);
endmodule

module HSBSVT16_ND2_1 (input A1, input A2, output X);
  assign X = ~(A1 & A2);
endmodule

module HSBSVT20_ND2_1 (input A1, input A2, output X);
  assign X = ~(A1 & A2);
endmodule

// ============================================================================
// 10. FOUR-INPUT NAND  (HSBLVT ND4)
//     Ports: .A1, .A2, .A3, .A4 inputs; .X output
//     Function: X = ~(A1 & A2 & A3 & A4)
// ============================================================================

module HSBLVT16_ND4_2 (input A1, input A2, input A3, input A4, output X);
  assign X = ~(A1 & A2 & A3 & A4);
endmodule

// ============================================================================
// 11. THREE-INPUT NAND  (HSBSVT ND3)
//     Ports: .A1, .A2, .A3 inputs; .X output
//     Function: X = ~(A1 & A2 & A3)
// ============================================================================

module HSBSVT20_ND3_MM_1 (input A1, input A2, input A3, output X);
  assign X = ~(A1 & A2 & A3);
endmodule

// ============================================================================
// 12. TWO-INPUT NOR  (HSBSVT NR2 family)
//     Ports: .A1, .A2 inputs; .X output
//     Function: X = ~(A1 | A2)
// ============================================================================

module HSBSVT20_NR2_1 (input A1, input A2, output X);
  assign X = ~(A1 | A2);
endmodule

module HSBSVT20_NR2_MM_1 (input A1, input A2, output X);
  assign X = ~(A1 | A2);
endmodule

// ============================================================================
// 13. NR2XB — NOR with one inverted input
//     Ports: .A (non-inverted), .B (inverted before NOR); .X output
//     Function: X = ~(A | ~B)  = ~A & B
// ============================================================================

module HSBSVT20_NR2XB_1 (input A, input B, output X);
  assign X = (~A) & B;
endmodule

module HSBSVT20_NR2XB_VM2_2 (input A, input B, output X);
  assign X = (~A) & B;
endmodule

// ============================================================================
// 14. ND2B — NAND with one inverted input
//     Ports: .A (inverted), .B (non-inverted); .X output
//     Function: X = ~(~A & B)  = A | ~B
// ============================================================================

module HSBSVT20_ND2B_UV1_1 (input A, input B, output X);
  assign X = A | (~B);
endmodule

// ============================================================================
// 15. TWO-INPUT AND  (HSBSVT AN2)
//     Ports: .A1, .A2 inputs; .X output
//     Function: X = A1 & A2
// ============================================================================

module HSBSVT20_AN2_1 (input A1, input A2, output X);
  assign X = A1 & A2;
endmodule

// ============================================================================
// 16. AN3B — 3-input AND with one inverted input
//     Ports: .A (inverted), .B1, .B2 inputs; .X output
//     Function: X = ~A & B1 & B2
// ============================================================================

module HSBSVT16_AN3B_1 (input A, input B1, input B2, output X);
  assign X = (~A) & B1 & B2;
endmodule

// ============================================================================
// 17. OR2_N — 2-input OR (same as OR2)
//     Ports: .A1, .A2 inputs; .X output
//     Function: X = A1 | A2
// ============================================================================

module HSBSVT20_OR2_N_1 (input A1, input A2, output X);
  assign X = A1 | A2;
endmodule

// ============================================================================
// 18. AO21B — AND-OR-INV: (A1 & A2) | ~B
//     Ports: .A1, .A2, .B inputs; .X output
//     Function: X = (A1 & A2) | ~B
// ============================================================================

module HSBSVT20_AO21B_1 (input A1, input A2, input B, output X);
  assign X = (A1 & A2) | (~B);
endmodule

// ============================================================================
// 19. OAI22 — OR-AND-INV: ~((A1|A2) & (B1|B2))
//     Ports: .A1, .A2, .B1, .B2 inputs; .X output
//     Function: X = ~((A1 | A2) & (B1 | B2))
// ============================================================================

module HSBSVT20_OAI22_MM_1 (input A1, input A2, input B1, input B2, output X);
  assign X = ~((A1 | A2) & (B1 | B2));
endmodule

// ============================================================================
// 20. OA211 — OR-AND: (A1|A2) & B1 & B2
//     Ports: .A1, .A2, .B1, .B2 inputs; .X output
//     Function: X = (A1 | A2) & B1 & B2
// ============================================================================

module HSBSVT16_OA211_1 (input A1, input A2, input B1, input B2, output X);
  assign X = (A1 | A2) & B1 & B2;
endmodule

// ============================================================================
// 21. TWO-INPUT MUX  (CKMUX2 family — clock mux)
//     Ports: .I0, .I1 inputs; .S select; .Z output
//     Function: Z = S ? I1 : I0
// ============================================================================

module CKMUX2D2BWP130HPNPN3P48CPDULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D2BWP143M169H3P48CPDULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D2BWP156HPNPN3P48CPDULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D2BWP169H3P48CPDULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D4BWP16P90CPDLVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D4BWP240H8P57PDLVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D4BWP300H8P64PDLVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2D8BWP210H6P51CNODULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2KAD4BWP280H6P57CNODLVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module CKMUX2KAD4BWP280H6P57CNODULVT (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

// ============================================================================
// 22. TWO-INPUT MUX  (HSBLVT/HSBULT/HSBSVT MUX2 family — data mux)
//     Ports: .D0, .D1 inputs; .S select; .X output
//     Function: X = S ? D1 : D0
// ============================================================================

module HSBLVT16_MUX2_4 (input D0, input D1, input S, output X);
  assign X = S ? D1 : D0;
endmodule

module HSBLVT16_MUX2_MM_4 (input D0, input D1, input S, output X);
  assign X = S ? D1 : D0;
endmodule

module HSBULT16_MUX2_MM_2 (input D0, input D1, input S, output X);
  assign X = S ? D1 : D0;
endmodule

module HSBSVT16_MUX2_MM_4 (input D0, input D1, input S, output X);
  assign X = S ? D1 : D0;
endmodule

// ============================================================================
// 23. LEVEL-SENSITIVE LATCH  (HSBLVT LDNQ — active-low enable)
//     Ports: .D data; .G enable (active low); .Q output
//     Function: when G==0: Q follows D (transparent); when G==1: Q holds
// ============================================================================

module HSBLVT16_LDNQ_4 (input D, input G, output reg Q);
  always @(*) begin
    if (~G) Q = D;
  end
endmodule

// ============================================================================
// 24. DFF WITH ACTIVE-LOW ASYNC RESET  (HSBLVT FDPRBQ family)
//     Ports: .D data; .CK clock; .RD reset (active low); .Q output
//     Function: posedge CK => Q <= D;  RD==0 => Q <= 0
// ============================================================================

module HSBLVT16_FDPRBQ_2 (input D, input CK, input RD, output reg Q);
  always @(posedge CK or negedge RD) begin
    if (!RD)
      Q <= 1'b0;
    else
      Q <= D;
  end
endmodule

module HSBLVT08_FDPRBQ_V2Y2_2 (input D, input CK, input RD, output reg Q);
  always @(posedge CK or negedge RD) begin
    if (!RD)
      Q <= 1'b0;
    else
      Q <= D;
  end
endmodule

// ============================================================================
// 25. DFF WITH ACTIVE-LOW ASYNC SET AND RESET + ENABLE  (HSBLVT FDPHRBSBQ)
//     Ports: .D data; .CK clock; .RD reset (active low); .SD set (active low);
//            .EN enable (active low = enabled); .Q output
//     Function: RD==0 => Q<=0; SD==0 => Q<=1; posedge CK && EN==0 => Q<=D
// ============================================================================

module HSBLVT16_FDPHRBSBQ_1 (input D, input CK, input RD, input SD, input EN,
                              output reg Q);
  always @(posedge CK or negedge RD or negedge SD) begin
    if (!RD)
      Q <= 1'b0;
    else if (!SD)
      Q <= 1'b1;
    else if (!EN)
      Q <= D;
  end
endmodule

// ============================================================================
// 26. SCAN DFF WITH ACTIVE-LOW ASYNC RESET + SCAN OUT  (HSBLVT FSDPRBQO)
//     Ports: .D data; .CK clock; .RD reset (active low);
//            .SI scan in; .SE scan enable; .Q output; .SO scan out
//     Function: posedge CK => Q <= SE ? SI : D;  RD==0 => Q<=0
//               SO mirrors Q (scan chain stitching)
// ============================================================================

module HSBLVT16_FSDPRBQO_V2_1 (input D, input CK, input RD,
                                 input SI, input SE,
                                 output reg Q, output SO);
  assign SO = Q;
  always @(posedge CK or negedge RD) begin
    if (!RD)
      Q <= 1'b0;
    else
      Q <= SE ? SI : D;
  end
endmodule

module HSBLVT16_FSDPRBQO_V2M_1 (input D, input CK, input RD,
                                   input SI, input SE,
                                   output reg Q, output SO);
  assign SO = Q;
  always @(posedge CK or negedge RD) begin
    if (!RD)
      Q <= 1'b0;
    else
      Q <= SE ? SI : D;
  end
endmodule

// ============================================================================
// 27. SCAN DFF (no reset)  (HSBLVT/HSBSVT FSDNQ — D flip-flop, no reset)
//     Ports: .D data; .CK clock; .SI scan in; .SE scan enable; .Q output
//     Function: posedge CK => Q <= SE ? SI : D
// ============================================================================

module HSBLVT20_FSDNQ_V2_2 (input D, input CK, input SI, input SE,
                              output reg Q);
  always @(posedge CK) begin
    Q <= SE ? SI : D;
  end
endmodule

module HSBSVT20_FSDNQ_V2_1 (input D, input CK, input SI, input SE,
                              output reg Q);
  always @(posedge CK) begin
    Q <= SE ? SI : D;
  end
endmodule

// ============================================================================
// 28. SCAN DFF WITH SCAN OUT (no reset)  (HSBSVT FSDPQO)
//     Ports: .D data; .CK clock; .SI scan in; .SE scan enable;
//            .Q output; .SO scan out
//     Function: posedge CK => Q <= SE ? SI : D;  SO = Q
// ============================================================================

module HSBSVT20_FSDPQO_D_1 (input D, input CK, input SI, input SE,
                              output reg Q, output SO);
  assign SO = Q;
  always @(posedge CK) begin
    Q <= SE ? SI : D;
  end
endmodule

// ============================================================================
// 29. SCAN DFF WITH INVERTED OUTPUT (no reset)  (HSBSVT FSDPQB)
//     Ports: .D data; .CK clock; .SI scan in; .SE scan enable; .QN output
//     Function: posedge CK => QN <= ~(SE ? SI : D)
// ============================================================================

module HSBSVT20_FSDPQB_V2_1 (input D, input CK, input SI, input SE,
                               output reg QN);
  always @(posedge CK) begin
    QN <= ~(SE ? SI : D);
  end
endmodule

// ============================================================================
// 30. CLOCK GATE  (HSBLVT/HSBULT/SEN/STN CKGTPLT family)
//     Ports: .CK clock; .EN enable; .SE scan enable; .Q gated clock
//     Function: Q = CK & (latched_EN | SE)
//     The enable is latched on the negative edge of CK to prevent glitches.
// ============================================================================

module HSBLVT16_CKGTPLT_V5_6 (input CK, input EN, input SE, output Q);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = EN | SE;
  end
  assign Q = CK & en_latched;
endmodule

module HSBULT16_CKGTPLT_V5_2 (input CK, input EN, input SE, output Q);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = EN | SE;
  end
  assign Q = CK & en_latched;
endmodule

module SEN_CKGTPLT_V5_6 (input CK, input EN, input SE, output Q);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = EN | SE;
  end
  assign Q = CK & en_latched;
endmodule

module STN_CKGTPLT_V5_6 (input CK, input EN, input SE, output Q);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = EN | SE;
  end
  assign Q = CK & en_latched;
endmodule

// ============================================================================
// 31. INTEGRATED CLOCK GATE  (PREICG family — ARM style)
//     Ports: .CK clock; .E enable; .SE scan enable; .ECK gated clock
//     Function: ECK = CK & (latched_E | SE)
//     Same as CKGTPLT but with different port names (E/ECK vs EN/Q).
// ============================================================================

module PREICG_X4R_A9TL_C16 (input CK, input E, input SE, output ECK);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = E | SE;
  end
  assign ECK = CK & en_latched;
endmodule

module PREICG_X4R_A9TUL_C16 (input CK, input E, input SE, output ECK);
  reg en_latched;
  always @(*) begin
    if (~CK) en_latched = E | SE;
  end
  assign ECK = CK & en_latched;
endmodule

// ============================================================================
// 32. SCAN DFF WITH ACTIVE-HIGH ASYNC CLEAR  (SDFSYNC RPQ family)
//     Ports: .D data; .CP clock; .CD clear (active high); .SI scan in;
//            .SE scan enable; .Q output
//     Function: posedge CP => Q <= SE ? SI : D;  CD==1 => Q <= 0
//
//     RPQ = Reset-P (active-high clear via CD pin).
//     The digit after SDFSYNC (1-4) is the cell's stage count / drive
//     variant — all share the same port interface.
// ============================================================================

module SDFSYNC1RPQD1BWP240H8P57PDLVT (input D, input CP, input CD,
                                        input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQD1BWP300H8P64PDLVT (input D, input CP, input CD,
                                        input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQD1BWP210H6P51CNODULVT (input D, input CP, input CD,
                                           input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQKAD1BWP280H6P57CNODLVT (input D, input CP, input CD,
                                            input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQSXGD1BWP143M169H3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1RPQSXGD1BWP169H3P48CPDULVT (input D, input CP, input CD,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2RPQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2RPQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2RPQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2RPQSXGD1BWP169H3P48CPDULVT (input D, input CP, input CD,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3RPQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3RPQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3RPQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3RPQSXGD1BWP169H3P48CPDULVT (input D, input CP, input CD,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4RPQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4RPQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4RPQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input CD,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4RPQSXGD1BWP169H3P48CPDULVT (input D, input CP, input CD,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or posedge CD) begin
    if (CD) Q <= 1'b0;
    else    Q <= SE ? SI : D;
  end
endmodule

// ============================================================================
// 33. SCAN DFF WITH ACTIVE-LOW ASYNC SET  (SDFSYNC SNQ family)
//     Ports: .D data; .CP clock; .SDN set (active low); .SI scan in;
//            .SE scan enable; .Q output
//     Function: posedge CP => Q <= SE ? SI : D;  SDN==0 => Q <= 1
//
//     SNQ = Set-N (active-low set via SDN pin).
// ============================================================================

module SDFSYNC1SNQD1BWP240H8P57PDLVT (input D, input CP, input SDN,
                                        input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQD1BWP300H8P64PDLVT (input D, input CP, input SDN,
                                        input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQD1BWP210H6P51CNODULVT (input D, input CP, input SDN,
                                           input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQKAD1BWP280H6P57CNODLVT (input D, input CP, input SDN,
                                            input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQSXGD1BWP143M169H3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC1SNQSXGD1BWP169H3P48CPDULVT (input D, input CP, input SDN,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2SNQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2SNQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2SNQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC2SNQSXGD1BWP169H3P48CPDULVT (input D, input CP, input SDN,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3SNQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3SNQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3SNQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC3SNQSXGD1BWP169H3P48CPDULVT (input D, input CP, input SDN,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4SNQSXGD1BWP130HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4SNQSXGD1BWP143M286H3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4SNQSXGD1BWP156HPNPN3P48CPDULVT (input D, input CP, input SDN,
                                                  input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

module SDFSYNC4SNQSXGD1BWP169H3P48CPDULVT (input D, input CP, input SDN,
                                              input SI, input SE, output reg Q);
  always @(posedge CP or negedge SDN) begin
    if (!SDN) Q <= 1'b1;
    else      Q <= SE ? SI : D;
  end
endmodule

// ============================================================================
// 34. SCAN DFF WITH ACTIVE-LOW ASYNC CLEAR (CDN pin)  (SDFCNQ family)
//     Ports: .D data; .CP clock; .CDN clear (active low); .SI scan in;
//            .SE scan enable; .Q output
//     Function: posedge CP => Q <= SE ? SI : D;  CDN==0 => Q <= 0
// ============================================================================

module SDFCNQD1BWP16P90CPDLVT (input D, input CP, input CDN,
                                input SI, input SE, output reg Q);
  always @(posedge CP or negedge CDN) begin
    if (!CDN) Q <= 1'b0;
    else      Q <= SE ? SI : D;
  end
endmodule
