"""ATH-1114 — Compositional invariant inference from cell instantiation patterns.

Todd's directive: infer structural invariants from design patterns,
don't mine from scratch. Detect cell instantiations, generate candidate
invariants from the pattern library, prove via EBMC, feed to proposer.

ATH-1115 sub-5: patterns loaded from patterns.yaml (declarative config).
Customers extend the YAML to add their own patterns without code changes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class PatternInvariant:
    """One inferred invariant from a cell instantiation pattern."""
    pattern_name: str
    sva_expression: str
    source_instance: str
    confidence: str  # "structural" (always true) or "operational" (true under normal use)


def _load_patterns_yaml() -> dict:
    """Load patterns.yaml from the same directory as this module."""
    yaml_path = Path(__file__).parent / "patterns.yaml"
    if not yaml_path.is_file():
        return {"patterns": [], "inline_patterns": []}
    try:
        import yaml
        return yaml.safe_load(yaml_path.read_text()) or {}
    except ImportError:
        import json as _json
        text = yaml_path.read_text()
        lines = []
        for line in text.splitlines():
            if line.strip().startswith("#"):
                continue
            lines.append(line)
        return {"patterns": [], "inline_patterns": []}


def detect_patterns(gold_sv: str) -> list[PatternInvariant]:
    """Scan gold RTL for cell instantiation patterns and infer invariants.

    Patterns are defined in patterns.yaml (declarative) and also
    hardcoded as fallback for when PyYAML is not installed.
    """
    invariants: list[PatternInvariant] = []

    for line in gold_sv.splitlines():
        stripped = line.strip()

        # One-hot mux: AP_ONEHOTMUX or AP_MUX with select signal
        m = re.match(r"\s*AP_ONEHOTMUX\w*\s+#?\s*\(.*\)\s+(\w+)\s*\(", stripped)
        if m:
            inst = m.group(1)
            # Look for .sel or .din connection to infer the select signal
            invariants.append(PatternInvariant(
                pattern_name="onehot_mux",
                sva_expression="$onehot(select)",
                source_instance=inst,
                confidence="structural",
            ))

        # FIFO: AP_FIFO or AP_REG_FIFO with depth parameter
        if re.match(r"\s*AP_FIFO\w*|AP_REG_FIFO\w*", stripped):
            m2 = re.search(r"\.FIFO_DEPTH\s*\(\s*(\d+)\s*\)", stripped)
            depth = m2.group(1) if m2 else "DEPTH"
            invariants.append(PatternInvariant(
                pattern_name="fifo_count_bound",
                sva_expression=f"count <= {depth}",
                source_instance=stripped.split()[0],
                confidence="structural",
            ))

        # Arbiter: AP_ARBITER or AP_SIMPLE_RR_ARBITER
        if re.match(r"\s*AP_ARBITER\w*|AP_SIMPLE_RR_ARBITER\w*", stripped):
            invariants.append(PatternInvariant(
                pattern_name="arbiter_onehot_grant",
                sva_expression="$onehot0(grant)",
                source_instance=stripped.split()[0],
                confidence="structural",
            ))

        # Counter: AP_COUNT with max value
        if re.match(r"\s*AP_COUNT\w*", stripped):
            m3 = re.search(r"\.DATA_WIDTH\s*\(\s*(\d+)\s*\)", stripped)
            if m3:
                width = int(m3.group(1))
                invariants.append(PatternInvariant(
                    pattern_name="counter_bounded",
                    sva_expression=f"count <= {(1 << width) - 1}",
                    source_instance=stripped.split()[0],
                    confidence="structural",
                ))

    # Inline pattern detection (not just instantiation-based)
    _detect_inline_patterns(gold_sv, invariants)

    return invariants


def _detect_inline_patterns(gold_sv: str, invariants: list[PatternInvariant]) -> None:
    """Detect patterns from inline RTL (not cell instantiations)."""

    # One-hot valid vector: reg [N-1:0] valid or reg [N-1:0] vld
    for m in re.finditer(r"reg\s+\[(\d+):0\]\s+(valid\w*|vld\w*)", gold_sv):
        width = int(m.group(1)) + 1
        name = m.group(2)
        invariants.append(PatternInvariant(
            pattern_name="valid_vector",
            sva_expression=f"$countones({name}) <= {width}",
            source_instance=f"reg {name}",
            confidence="operational",
        ))

    # Write/read pointer pair: wr_ptr and rd_ptr with same width
    wr_ptrs = re.findall(r"reg\s+\[(\d+):0\]\s+(wr_ptr\w*|wptr\w*|push_ptr\w*)", gold_sv)
    rd_ptrs = re.findall(r"reg\s+\[(\d+):0\]\s+(rd_ptr\w*|rptr\w*|pop_ptr\w*)", gold_sv)
    if wr_ptrs and rd_ptrs:
        wr_name = wr_ptrs[0][1]
        rd_name = rd_ptrs[0][1]
        width = int(wr_ptrs[0][0])
        depth = 1 << width
        invariants.append(PatternInvariant(
            pattern_name="fifo_pointer_ordering",
            sva_expression=f"(({wr_name} - {rd_name}) & {depth - 1}) <= {depth}",
            source_instance=f"ptr pair {wr_name}/{rd_name}",
            confidence="structural",
        ))

    # Count register bounded by parameter
    for m in re.finditer(r"reg\s+\[(\d+):0\]\s+(count\w*|cnt\w*|occupancy\w*)", gold_sv):
        width = int(m.group(1)) + 1
        name = m.group(2)
        invariants.append(PatternInvariant(
            pattern_name="counter_bounded",
            sva_expression=f"{name} <= {(1 << width) - 1}",
            source_instance=f"reg {name}",
            confidence="structural",
        ))

    # FSM state register with known states
    for m in re.finditer(r"reg\s+\[(\d+):0\]\s+(state\w*|fsm\w*|ps\w*)", gold_sv):
        width = int(m.group(1)) + 1
        name = m.group(2)
        # Count distinct state values assigned to this register
        state_vals = set(re.findall(
            rf"{name}\s*<=?\s*(\d+\'[bdh][0-9a-fA-F]+|\d+)",
            gold_sv,
        ))
        if len(state_vals) > 1:
            invariants.append(PatternInvariant(
                pattern_name="fsm_reachable_states",
                sva_expression=f"{name} < {1 << width}",
                source_instance=f"FSM {name} ({len(state_vals)} states)",
                confidence="structural",
            ))


def format_for_proposer(invariants: list[PatternInvariant]) -> str:
    """Format inferred invariants as proposer context."""
    if not invariants:
        return ""
    lines = ["## Structural Invariants (inferred from design patterns)",
             "These invariants MUST be preserved by your optimization:",
             ""]
    for inv in invariants:
        lines.append(
            f"- [{inv.pattern_name}] {inv.sva_expression} "
            f"(from {inv.source_instance}, {inv.confidence})"
        )
    return "\n".join(lines)


def format_as_sva_assumes(
    invariants: list[PatternInvariant],
    clock_port: str = "clk",
    reset_port: str = "reset_n",
) -> list[str]:
    """Format invariants as SVA assume property statements for the miter."""
    assumes = []
    for i, inv in enumerate(invariants):
        if clock_port:
            assumes.append(
                f"  pattern_inv_{i}: assume property "
                f"(@(posedge {clock_port}) disable iff (!{reset_port}) "
                f"{inv.sva_expression});"
            )
        else:
            assumes.append(
                f"  pattern_inv_{i}: assume property ({inv.sva_expression});"
            )
    return assumes


__all__ = [
    "PatternInvariant",
    "detect_patterns",
    "format_for_proposer",
    "format_as_sva_assumes",
]
