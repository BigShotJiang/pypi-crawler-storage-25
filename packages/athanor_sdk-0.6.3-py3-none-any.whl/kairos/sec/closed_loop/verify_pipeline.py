"""ATH-1115 sub-2c: verification pipeline utilities.

Pre-verification gates (structural + toggle), engine selection,
and EBMC outcome classification. Extracted from _orchestrator.py
to keep verification logic independently testable.

The main _emit_iteration_arc_for_proposal function remains in
_orchestrator.py but delegates to these utilities.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from kairos.sec.closed_loop.measurement import measure_synthesis, measure_toggle_power

# ATH-1212a: per-tool subprocess env allowlists. This module invokes both
# yosys (timing gate at check_timing_gate) and ebmc (capture_ebmc_subprocess)
# in separate subprocess sites; each gets its own factory so credentials
# stay tool-scoped.
from kairos.security.env_allowlist import safe_env_for_ebmc, safe_env_for_yosys


def check_structural_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
) -> tuple[bool, int | None, int | None]:
    """Pre-verification gate: reject proposals that don't reduce cells.

    Returns (passes, gold_cells, gate_cells). When passes=False, the
    proposal is cosmetic and should be rejected before verification.
    """
    gold_cells = measure_synthesis(gold_path, gold_module)
    gate_cells = measure_synthesis(gate_path, gate_module)
    if gold_cells and gate_cells and gate_cells >= gold_cells:
        return False, gold_cells, gate_cells
    return True, gold_cells, gate_cells


def check_toggle_power_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    sig: dict[str, Any],
    work_dir: Path,
    threshold_pct: float = 20.0,
) -> tuple[bool, dict | None]:
    """Pre-verification gate: reject proposals that regress power >threshold.

    Only runs when structural gate passed (gate_cells < gold_cells).
    Returns (passes, toggle_result).
    """
    tp = measure_toggle_power(
        gold_path=gold_path,
        gate_path=gate_path,
        gold_module=gold_module,
        gate_module=gate_module,
        sig=sig,
        work_dir=work_dir,
    )
    if tp and tp.get("toggle_delta_pct", 0) > threshold_pct:
        return False, tp
    return True, tp


def check_timing_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    timing_constraint_ns: float | None = None,
) -> tuple[bool, dict | None]:
    """Pre-verification gate: reject proposals that violate timing.

    Uses yosys to estimate critical path delay via ABC. If the gate's
    critical path exceeds the gold's by more than 5%, reject.

    Backed by PhysicalDesign.slack_preservation: removing gates on
    non-critical paths preserves critical path slack.

    Returns (passes, timing_result).
    """
    import re
    import shutil
    import subprocess

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return True, None

    results = {}
    for label, path, module in [
        ("gold", gold_path, gold_module),
        ("gate", gate_path, gate_module),
    ]:
        script = (
            f"read_verilog -sv {path}; "
            f"proc; opt; techmap; opt; "
            f"abc -liberty /dev/null -D 1000; "
            f"tee -q /dev/stdout stat"
        )
        try:
            r = subprocess.run(
                [yosys_bin, "-p", script],
                capture_output=True, text=True, timeout=30,
                env=safe_env_for_yosys(),  # ATH-1212a
            )
            m = re.search(r"Delay\s*=\s*([0-9.]+)", r.stdout + r.stderr)
            if m:
                results[label] = float(m.group(1))
        except Exception:  # noqa: BLE001
            pass

    if "gold" not in results or "gate" not in results:
        return True, results

    gold_delay = results["gold"]
    gate_delay = results["gate"]
    timing_result = {
        "gold_delay": gold_delay,
        "gate_delay": gate_delay,
        "delay_delta_pct": round((gate_delay - gold_delay) / gold_delay * 100, 1)
            if gold_delay > 0 else 0,
    }

    if timing_constraint_ns and gate_delay > timing_constraint_ns:
        timing_result["violation"] = f"gate delay {gate_delay}ns exceeds constraint {timing_constraint_ns}ns"
        return False, timing_result

    if gold_delay > 0 and gate_delay > gold_delay * 1.05:
        timing_result["violation"] = (
            f"gate delay {gate_delay:.1f} exceeds gold {gold_delay:.1f} by "
            f"{timing_result['delay_delta_pct']}% (>5% threshold)"
        )
        return False, timing_result

    return True, timing_result


def select_engine(sig: dict[str, Any]) -> str:
    """Select the verification engine based on design characteristics.

    Returns "combo" or "sequential". Combo blocks (no clock) route to
    yosys equiv. Sequential blocks route to EBMC BMC + k-induction.
    """
    if not sig.get("clock_port"):
        return "combo"
    return "sequential"


def classify_bmc_outcome(
    property_verdicts: dict[str, str],
) -> tuple[str, str]:
    """Classify per-property BMC verdicts into an overall outcome.

    Returns (result_str, diagnostic_class) where result_str is one of:
    PASS, FAIL, INCONCLUSIVE, SETUP_ERROR.

    FAIL (any property REFUTED) takes priority over INCONCLUSIVE.
    PASS requires ALL properties PROVED.
    """
    if not property_verdicts:
        return "INCONCLUSIVE", "empty_verdicts"

    verdicts = [v.upper() for v in property_verdicts.values()]

    if any(v == "REFUTED" for v in verdicts):
        return "FAIL", "bmc_counterexample"
    if all(v == "PROVED" for v in verdicts):
        return "PASS", "bmc_proved"
    return "INCONCLUSIVE", "bmc_inconclusive"


def diagnose_ebmc_outcome(
    proved: bool,
    refuted: bool,
    has_inconclusive_props: bool,
) -> tuple[str, str | None]:
    """Map (proved, refuted, has_inconclusive) to (result, diagnostic_class).

    EBMC per-property verdicts can mix; the iteration verdict is the
    weakest across properties (one REFUTED makes the whole iteration
    refuted; INCONCLUSIVE wins over PASS).
    """
    if refuted:
        return "FAIL", "bmc_counterexample"
    if has_inconclusive_props:
        return "INCONCLUSIVE", "missing_inductive_invariant"
    if proved:
        return "PASS", None
    return "INCONCLUSIVE", "kinduction_inconclusive"


def iteration_outcome_from_bmc_result(
    bmc_result: Any,
) -> tuple[str, str | None]:
    """Compute (result_str, diagnostic_class) from a SecVerifyResult.

    ATH-1102: per-property REFUTE escalates to FAIL even when
    bmc_result.refuted (whole-result aggregate) is False, so the
    counterexample-feedback retry loop fires on partial refutes.
    """
    verdicts = bmc_result.property_verdicts
    has_inconclusive = any(
        v.lower() == "inconclusive" for v in verdicts.values()
    )
    has_refute = any(
        v.upper() == "REFUTED" for v in verdicts.values()
    )
    return diagnose_ebmc_outcome(
        proved=bmc_result.proved,
        refuted=bmc_result.refuted or has_refute,
        has_inconclusive_props=has_inconclusive,
    )


def capture_ebmc_subprocess(
    *,
    miter_path: Path,
    gold_path: Path,
    gate_path: Path,
    work_dir: Path,
    mode: str,
    bound: int,
    top_module: str,
    reset_expr: str,
    timeout_sec: int,
    label: str,
) -> None:
    """Run ebmc as a subprocess and capture stdout/stderr/exitcode/cmdline
    to work_dir for customer-facing cert tarball audit trail."""
    import subprocess
    cmd = [
        "ebmc", str(miter_path), str(gold_path), str(gate_path),
        "--bound", str(bound), "--module", top_module,
        "--reset", reset_expr,
    ]
    if mode == "k_induction":
        cmd.append("--k-induction")
    work_dir.mkdir(parents=True, exist_ok=True)
    try:
        res = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_ebmc(),  # ATH-1212a
        )
        stdout, stderr, exitcode = res.stdout, res.stderr, res.returncode
    except subprocess.TimeoutExpired as e:
        stdout = (
            e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        )
        stderr = (
            e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
        )
        stderr += f"\n[capture] subprocess.TimeoutExpired after {timeout_sec}s\n"
        exitcode = -1
    except Exception as e:  # noqa: BLE001
        stdout = ""
        stderr = f"[capture] subprocess error: {type(e).__name__}: {e}\n"
        exitcode = -2
    (work_dir / f"ebmc_{label}.cmdline").write_text(" ".join(cmd) + "\n")
    (work_dir / f"ebmc_{label}.stdout").write_text(stdout)
    (work_dir / f"ebmc_{label}.stderr").write_text(stderr)
    (work_dir / f"ebmc_{label}.exitcode").write_text(str(exitcode) + "\n")


__all__ = [
    "check_structural_gate",
    "check_toggle_power_gate",
    "select_engine",
    "classify_bmc_outcome",
    "diagnose_ebmc_outcome",
    "iteration_outcome_from_bmc_result",
    "capture_ebmc_subprocess",
]
