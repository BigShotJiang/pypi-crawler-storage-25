"""ATH-1115 sub-3: mock verification engines for CI testing.

When yosys/EBMC/iverilog are not installed, these mocks let the
orchestrator logic be tested without external tools. The mocks
return deterministic results based on the input files so tests
can assert on orchestrator behavior.

Usage: monkeypatch the real functions with these mocks in tests.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any


class MockSynthesisResult:
    """Deterministic mock for measure_synthesis.

    Returns cell count based on file size (deterministic, no yosys).
    Gold files get a higher count than gate files so the structural
    gate passes in tests.
    """

    def __call__(self, design_path: Path, module_name: str) -> int | None:
        if not Path(design_path).is_file():
            return None
        text = Path(design_path).read_text()
        base = len(text.splitlines()) * 3
        if "gate" in module_name.lower():
            return max(1, base - 5)
        return max(2, base)


class MockTogglePower:
    """Deterministic mock for measure_toggle_power.

    Returns a fixed -10% toggle delta (improvement) so the toggle
    gate passes in tests.
    """

    def __call__(self, **kwargs: Any) -> dict[str, Any] | None:
        return {
            "gold_toggles": 100,
            "gate_toggles": 90,
            "toggle_delta_pct": -10.0,
        }


class MockYosysEquiv:
    """Deterministic mock for verify_combo_equiv.

    Returns PROVED when gold and gate have different content (optimization).
    Returns REFUTED when they're identical (no change).
    """

    def __call__(self, **kwargs: Any) -> Any:
        from kairos.sec.closed_loop.yosys_equiv import YosysEquivResult
        gold = Path(kwargs["gold_path"]).read_text()
        gate = Path(kwargs["gate_path"]).read_text()
        if gold == gate:
            return YosysEquivResult(
                proved=False, refuted=True,
                proven_cells=0, unproven_cells=1,
                elapsed_seconds=0.01,
                method="mock_yosys_equiv",
                detail="mock: identical designs",
            )
        return YosysEquivResult(
            proved=True, refuted=False,
            proven_cells=10, unproven_cells=0,
            elapsed_seconds=0.01,
            method="mock_yosys_dual_engine",
            detail="mock: designs differ, PROVED",
        )


mock_synthesis = MockSynthesisResult()
mock_toggle_power = MockTogglePower()
mock_yosys_equiv = MockYosysEquiv()


__all__ = [
    "MockSynthesisResult",
    "MockTogglePower",
    "MockYosysEquiv",
    "mock_synthesis",
    "mock_toggle_power",
    "mock_yosys_equiv",
]
