"""ATH-1118 deliverables 2+3+6: flow guard, prompt safety, advisory API.

Structural enforcement layer between customer agent and orchestrator.
Rejects bad flows with structured errors + suggests corrections.
Validates prompt adjustments don't disable safety requirements.

This is NOT a prompt — it is code-level validation that cannot be
bypassed. The customer's agent gets a clear rejection + suggestion,
not a silent failure.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from kairos.sec.closed_loop.flow_config import FlowConfig


@dataclass(frozen=True)
class FlowAdvice:
    """Result of flow validation. Returned by advise_flow()."""
    valid: bool
    errors: list[str]
    suggestions: list[str]
    config: FlowConfig | None = None


# Hard safety constraints that CANNOT be overridden by customer config.
# These are the invariants Lean proves (ATH-1118 deliverable 5).
SAFETY_INVARIANTS = {
    "verify_before_ship": (
        "Every optimization MUST be formally verified before shipping. "
        "Disabling verification produces unverified results that could "
        "break the customer's design."
    ),
    "measure_matches_verify": (
        "The measured artifact MUST be the same artifact that was verified. "
        "Measuring a different file produces fake area/power numbers."
    ),
    "multi_engine_minimum": (
        "At least 2 independent verification engines MUST agree before "
        "declaring PROVED. Single-engine verification has blind spots."
    ),
    "structural_gate_required": (
        "The structural gate (reject gate_cells >= gold_cells) MUST be "
        "enabled. Without it, proposals that increase area pass verification "
        "and waste customer resources."
    ),
}


def validate_flow(config: FlowConfig) -> FlowAdvice:
    """Validate a customer's flow configuration against safety invariants.

    Returns FlowAdvice with valid=True if safe, or valid=False with
    errors explaining what's wrong and suggestions for fixing it.
    """
    errors = []
    suggestions = []

    # Hard constraint: structural gate cannot be disabled
    if not config.structural_gate_enabled:
        errors.append(
            f"REJECTED: structural_gate_enabled=False. "
            f"{SAFETY_INVARIANTS['structural_gate_required']}"
        )
        suggestions.append(
            "Set structural_gate_enabled=True (default). The gate runs "
            "in <1s and catches 100% of cosmetic/zero-delta proposals."
        )

    # Hard constraint: multi-engine cannot be disabled
    if not config.require_multi_engine:
        errors.append(
            f"REJECTED: require_multi_engine=False. "
            f"{SAFETY_INVARIANTS['multi_engine_minimum']}"
        )
        suggestions.append(
            "Set require_multi_engine=True (default). Dual-engine "
            "verification catches tool-specific blind spots."
        )

    # Hard constraint: elaboration should be on for parameterized blocks
    # (soft warning, not rejection)
    if not config.elaborate_gold:
        suggestions.append(
            "WARNING: elaborate_gold=False. Parameterized blocks may "
            "measure with wrong default parameters (the -76.4% fake "
            "result bug). Consider elaborate_gold=True."
        )

    # Budget sanity checks
    if config.max_cost_usd > 50:
        suggestions.append(
            f"WARNING: max_cost_usd={config.max_cost_usd}. A typical "
            f"optimization run costs $1-5. Budget >$50 may indicate "
            f"a configuration error."
        )

    if config.k_induction_bound < 10:
        suggestions.append(
            f"WARNING: k_induction_bound={config.k_induction_bound}. "
            f"Low bounds may miss bugs. Recommended: 32+ per Aidan "
            f"directive."
        )

    if config.max_inner_retries > 10:
        suggestions.append(
            f"WARNING: max_inner_retries={config.max_inner_retries}. "
            f"High retry counts waste tokens on impossible optimizations. "
            f"Recommended: 3-5."
        )

    # Hard constraint: verification timeout cannot be < 30s
    if config.verification_timeout_sec != 0 and config.verification_timeout_sec < 30:
        errors.append(
            f"REJECTED: verification_timeout_sec={config.verification_timeout_sec}. "
            f"Timeouts below 30s cause false INCONCLUSIVE on blocks that would "
            f"otherwise PROVE. Minimum: 30s."
        )
        suggestions.append("Set verification_timeout_sec >= 30 or 0 (adaptive).")

    # Hard constraint: proposer_mode must be valid
    if config.proposer_mode not in ("full", "preserve_datapath", "diff"):
        errors.append(
            f"REJECTED: proposer_mode='{config.proposer_mode}' is not valid. "
            f"Must be one of: full, preserve_datapath, diff."
        )
        suggestions.append("Use proposer_mode='full' for maximum flexibility.")

    # Dangerous combination: CEGAR + low bound
    if config.cegar_escalation and config.k_induction_bound < 3:
        errors.append(
            f"REJECTED: cegar_escalation=True with k_induction_bound="
            f"{config.k_induction_bound}. CEGAR needs meaningful BMC "
            f"depth to find useful counterexamples. Minimum: 5."
        )
        suggestions.append("Set k_induction_bound >= 5 when using CEGAR.")

    return FlowAdvice(
        valid=len(errors) == 0,
        errors=errors,
        suggestions=suggestions,
        config=config if len(errors) == 0 else None,
    )


def validate_proposal(
    proposal: dict[str, Any],
    gold_ports: list[dict[str, Any]] | None = None,
    target_module: str | None = None,
) -> FlowAdvice:
    """Validate a transformation proposal before verification.

    Structural rejection of malformed proposals — catches bad agent
    output before wasting verifier time.
    """
    errors = []
    suggestions = []

    if not proposal.get("gate_sv"):
        errors.append("REJECTED: proposal has no gate_sv (empty or missing Verilog)")
        suggestions.append("The proposal must include complete gate Verilog source.")
        return FlowAdvice(valid=False, errors=errors, suggestions=suggestions)

    gate_sv = proposal["gate_sv"]

    if "module " not in gate_sv and "module\n" not in gate_sv:
        errors.append("REJECTED: gate_sv has no module declaration")
        suggestions.append("The gate Verilog must contain a 'module <name>' declaration.")

    if target_module and f"module {target_module}" not in gate_sv and f"module {target_module}_gate" not in gate_sv:
        errors.append(
            f"REJECTED: gate module name does not match target ({target_module}). "
            f"Expected 'module {target_module}' or 'module {target_module}_gate'."
        )
        suggestions.append("Rename the gate module to match the target.")

    if "endmodule" not in gate_sv:
        errors.append("REJECTED: gate_sv missing endmodule")
        suggestions.append("The gate Verilog must end with 'endmodule'.")

    if gold_ports:
        for port in gold_ports:
            port_name = port.get("name", "")
            if port_name and port_name not in gate_sv:
                errors.append(f"REJECTED: port '{port_name}' missing from gate Verilog")
                suggestions.append(
                    f"The gate module must preserve port '{port_name}' "
                    f"({port.get('direction', '?')}, width={port.get('width', '?')})."
                )
                break

    delta = proposal.get("claimed_area_delta_pct", 0)
    if isinstance(delta, (int, float)) and delta >= 0:
        errors.append(
            f"REJECTED: claimed_area_delta_pct={delta}% (non-negative). "
            f"Optimizations must claim area REDUCTION (negative delta)."
        )
        suggestions.append("Set claimed_area_delta_pct to a negative number (e.g., -10.0).")

    return FlowAdvice(
        valid=len(errors) == 0,
        errors=errors,
        suggestions=suggestions,
    )


def validate_prompt_adjustments(prompt_text: str) -> FlowAdvice:
    """Validate customer-adjusted prompt doesn't disable safety.

    ATH-1118 deliverable 2: prompt safety layer.
    """
    errors = []
    suggestions = []

    dangerous_patterns = [
        ("skip verification", "Prompt suggests skipping verification"),
        ("don't verify", "Prompt suggests skipping verification"),
        ("skip measurement", "Prompt suggests skipping measurement"),
        ("don't measure", "Prompt suggests skipping measurement"),
        ("ignore the structural gate", "Prompt tries to bypass structural gate"),
        ("bypass", "Prompt uses bypass language"),
        ("no need to prove", "Prompt discourages formal proof"),
    ]

    prompt_lower = prompt_text.lower()
    for pattern, reason in dangerous_patterns:
        if pattern in prompt_lower:
            errors.append(f"REJECTED: {reason} (found '{pattern}')")
            suggestions.append(
                "Remove the dangerous instruction. kairos always verifies "
                "and measures. These steps cannot be skipped."
            )

    return FlowAdvice(
        valid=len(errors) == 0,
        errors=errors,
        suggestions=suggestions,
    )


def advise_flow(
    config_dict: dict[str, Any] | None = None,
    prompt_text: str | None = None,
) -> dict[str, Any]:
    """MCP tool: kairos_advise_flow.

    ATH-1118 deliverable 6: customer advisory API.
    Customer's agent calls this to validate a proposed flow BEFORE
    running it. Returns structured advice.
    """
    from kairos.sec.closed_loop.flow_config import load_flow_config

    result: dict[str, Any] = {"valid": True, "errors": [], "suggestions": []}

    # Validate flow config
    if config_dict is not None:
        try:
            config = load_flow_config(**config_dict)
            advice = validate_flow(config)
            if not advice.valid:
                result["valid"] = False
            result["errors"].extend(advice.errors)
            result["suggestions"].extend(advice.suggestions)
        except ValueError as e:
            result["valid"] = False
            result["errors"].append(f"Invalid config: {e}")

    # Validate prompt
    if prompt_text is not None:
        prompt_advice = validate_prompt_adjustments(prompt_text)
        if not prompt_advice.valid:
            result["valid"] = False
        result["errors"].extend(prompt_advice.errors)
        result["suggestions"].extend(prompt_advice.suggestions)

    if result["valid"]:
        result["message"] = "Flow is safe to execute."
    else:
        result["message"] = (
            "Flow REJECTED. Fix the errors above before running. "
            "kairos enforces these safety constraints structurally — "
            "they cannot be bypassed."
        )

    return result


__all__ = [
    "FlowAdvice",
    "SAFETY_INVARIANTS",
    "validate_flow",
    "validate_prompt_adjustments",
    "advise_flow",
]
