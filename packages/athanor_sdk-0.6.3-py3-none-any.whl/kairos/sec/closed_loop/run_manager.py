"""ATH-1166 Layer 2: Background mode + run persistence.

Manages run sessions on disk so customers can:
- Launch optimization in background (--bg)
- Check status of running/completed runs (kairos status <run-id>)
- List all runs (kairos runs)
- Persist partial results on crash
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


RUNS_DIR = Path.home() / ".kairos" / "runs"


@dataclass
class RunState:
    run_id: str
    block_name: str
    status: str  # "running" | "proved" | "failed" | "aborted"
    phase: str = "starting"
    start_time: float = 0.0
    elapsed_sec: float = 0.0
    n_proposals: int = 0
    n_accepted: int = 0
    area_delta_pct: float | None = None
    error: str | None = None
    result_path: str | None = None


def _run_dir(run_id: str) -> Path:
    d = RUNS_DIR / run_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def save_run_state(state: RunState) -> Path:
    """Persist run state to disk. Called at each phase boundary."""
    d = _run_dir(state.run_id)
    state_path = d / "state.json"
    state_path.write_text(json.dumps(asdict(state), indent=2))
    return state_path


def load_run_state(run_id: str) -> RunState | None:
    state_path = RUNS_DIR / run_id / "state.json"
    if not state_path.is_file():
        return None
    data = json.loads(state_path.read_text())
    return RunState(**data)


def list_runs(limit: int = 20) -> list[RunState]:
    """List recent runs, newest first."""
    if not RUNS_DIR.is_dir():
        return []
    runs = []
    for d in sorted(RUNS_DIR.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        state = load_run_state(d.name)
        if state:
            runs.append(state)
        if len(runs) >= limit:
            break
    return runs


def save_result(run_id: str, result: Any) -> Path:
    """Save the final ClosedLoopResult to disk."""
    d = _run_dir(run_id)
    result_path = d / "result.json"
    try:
        data = {
            "halt_reason": result.halt_reason,
            "n_accepted": result.n_accepted(),
            "iteration_summaries": result.iteration_summaries,
            "summary": result.summary(),
        }
        result_path.write_text(json.dumps(data, indent=2, default=str))
    except Exception:  # noqa: BLE001
        result_path.write_text(json.dumps({"error": "serialization failed"}, indent=2))
    return result_path


def format_runs_table(runs: list[RunState]) -> str:
    """Format runs as a readable table."""
    if not runs:
        return "No runs found."
    lines = [f"{'RUN ID':<12} {'STATUS':<10} {'BLOCK':<25} {'DELTA':<10} {'ELAPSED':<10}"]
    lines.append("-" * 67)
    for r in runs:
        delta = f"{r.area_delta_pct:+.1f}%" if r.area_delta_pct is not None else "-"
        elapsed = f"{r.elapsed_sec:.0f}s" if r.elapsed_sec else "-"
        lines.append(f"{r.run_id[:12]:<12} {r.status:<10} {r.block_name[:25]:<25} {delta:<10} {elapsed:<10}")
    return "\n".join(lines)


__all__ = [
    "RunState",
    "save_run_state",
    "load_run_state",
    "list_runs",
    "save_result",
    "format_runs_table",
    "RUNS_DIR",
]
