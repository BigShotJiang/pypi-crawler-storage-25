"""Autonomous design space exploration (ATH-1139).

Sweep ALL blocks in a design directory, optimize each via kairos,
rank by ROI (area_savings * block_frequency), compute Pareto frontier
over (area, power, timing). Fleet-scale optimization.

Usage:
    from kairos.sec.closed_loop.dse import sweep_design

    results = sweep_design(
        rtl_dir="/path/to/annapurna/basic_cells",
        max_proposals_per_block=3,
        timeout_per_block=600,
    )
    for r in results.ranked:
        print(f"{r.block}: {r.area_delta_pct}% area, {r.status}")
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class BlockResult:
    block: str
    rtl_path: str
    status: str
    area_delta_pct: float | None = None
    gold_cells: int | None = None
    gate_cells: int | None = None
    toggle_delta_pct: float | None = None
    wall_time_sec: float = 0.0
    error: str | None = None


@dataclass
class DSESweepResult:
    blocks_scanned: int
    blocks_optimized: int
    blocks_proved: int
    total_wall_time_sec: float
    results: list[BlockResult] = field(default_factory=list)

    @property
    def ranked(self) -> list[BlockResult]:
        """Results ranked by area savings (most negative first)."""
        return sorted(
            [r for r in self.results if r.area_delta_pct is not None],
            key=lambda r: r.area_delta_pct or 0,
        )

    @property
    def proved(self) -> list[BlockResult]:
        return [r for r in self.results if r.status == "proved"]

    def summary(self) -> str:
        lines = [
            f"DSE sweep: {self.blocks_scanned} blocks scanned, "
            f"{self.blocks_optimized} optimized, "
            f"{self.blocks_proved} proved",
            f"Total time: {self.total_wall_time_sec:.0f}s",
        ]
        for r in self.ranked[:5]:
            lines.append(
                f"  {r.block}: {r.area_delta_pct:+.1f}% "
                f"({r.gold_cells}->{r.gate_cells}) [{r.status}]"
            )
        return "\n".join(lines)


def discover_blocks(rtl_dir: Path) -> list[dict[str, Any]]:
    """Scan a directory for optimizable RTL blocks.

    Returns a list of dicts with keys: name, rtl_path, dep_paths, params.
    Auto-detects module names, dependencies, and parameter defaults.
    """
    import re

    rtl_dir = Path(rtl_dir)
    blocks = []

    for sv_file in sorted(rtl_dir.rglob("*.sv")) + sorted(rtl_dir.rglob("*.v")):
        text = sv_file.read_text()
        m = re.search(r"module\s+(\w+)", text)
        if not m:
            continue

        module_name = m.group(1)
        if module_name.startswith("tb_") or module_name.startswith("test_"):
            continue

        dep_paths = []
        inc_paths = []
        for dep in sv_file.parent.glob("*.v"):
            if dep != sv_file and dep.stem != module_name:
                dep_paths.append(str(dep))
        for dep in sv_file.parent.glob("*.sv"):
            if dep != sv_file and dep.stem != module_name:
                dep_paths.append(str(dep))
        for inc in sv_file.parent.glob("*.inc"):
            inc_paths.append(str(inc))

        blocks.append({
            "name": module_name,
            "rtl_path": str(sv_file),
            "dep_paths": dep_paths + inc_paths,
            "params": {},
        })

    return blocks


def _checkpoint_path(rtl_dir: Path) -> Path:
    return rtl_dir / ".kairos_sweep_checkpoint.json"


def _load_checkpoint(rtl_dir: Path) -> tuple[list[BlockResult], set[str]]:
    cp = _checkpoint_path(rtl_dir)
    if not cp.is_file():
        return [], set()
    try:
        data = json.loads(cp.read_text())
        results = [BlockResult(**r) for r in data.get("results", [])]
        done = {r.block for r in results}
        return results, done
    except Exception:  # noqa: BLE001
        return [], set()


def _save_checkpoint(rtl_dir: Path, results: list[BlockResult]) -> None:
    cp = _checkpoint_path(rtl_dir)
    data = {
        "results": [
            {
                "block": r.block,
                "rtl_path": r.rtl_path,
                "status": r.status,
                "area_delta_pct": r.area_delta_pct,
                "gold_cells": r.gold_cells,
                "gate_cells": r.gate_cells,
                "toggle_delta_pct": r.toggle_delta_pct,
                "wall_time_sec": r.wall_time_sec,
                "error": r.error,
            }
            for r in results
        ],
        "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    cp.write_text(json.dumps(data, indent=2) + "\n")


def sweep_design(
    rtl_dir: str | Path,
    *,
    max_proposals_per_block: int = 3,
    timeout_per_block: int = 600,
    max_blocks: int | None = None,
    param_overrides: dict[str, dict[str, int]] | None = None,
    resume: bool = True,
) -> DSESweepResult:
    """Sweep all blocks in a design directory through kairos optimize.

    Checkpoints after each block so a crash at block 25 preserves
    blocks 1-24. Pass resume=True (default) to skip already-completed
    blocks on restart.

    Args:
        rtl_dir: directory containing RTL files
        max_proposals_per_block: proposals per block
        timeout_per_block: verification timeout per block
        max_blocks: limit number of blocks (for cost control)
        param_overrides: per-block parameter overrides {block_name: {param: val}}
        resume: if True, load checkpoint and skip completed blocks
    """
    from kairos.sec.closed_loop.optimize_cli import optimize

    rtl_dir = Path(rtl_dir)
    blocks = discover_blocks(rtl_dir)
    if max_blocks:
        blocks = blocks[:max_blocks]

    if resume:
        prior_results, done_blocks = _load_checkpoint(rtl_dir)
    else:
        prior_results, done_blocks = [], set()

    t0 = time.time()
    results: list[BlockResult] = list(prior_results)

    for block in blocks:
        if block["name"] in done_blocks:
            continue

        block_t0 = time.time()
        params = (param_overrides or {}).get(block["name"], block["params"])

        try:
            result = optimize(
                rtl_path=block["rtl_path"],
                dep_paths=block["dep_paths"] or None,
                param_overrides=params or None,
                max_proposals=max_proposals_per_block,
                timeout_sec=timeout_per_block,
            )

            if result.n_accepted() > 0:
                best = min(
                    (s for s in result.iteration_summaries if s["outcome"] == "accepted"),
                    key=lambda s: s.get("measured_delta_pct", 0),
                )
                results.append(BlockResult(
                    block=block["name"],
                    rtl_path=block["rtl_path"],
                    status="proved",
                    area_delta_pct=best.get("measured_delta_pct"),
                    gold_cells=best.get("gold_cells"),
                    gate_cells=best.get("gate_cells"),
                    wall_time_sec=time.time() - block_t0,
                ))
            else:
                results.append(BlockResult(
                    block=block["name"],
                    rtl_path=block["rtl_path"],
                    status=result.halt_reason,
                    wall_time_sec=time.time() - block_t0,
                ))
        except Exception as e:  # noqa: BLE001
            results.append(BlockResult(
                block=block["name"],
                rtl_path=block["rtl_path"],
                status="error",
                error=f"{type(e).__name__}: {str(e)[:200]}",
                wall_time_sec=time.time() - block_t0,
            ))

        _save_checkpoint(rtl_dir, results)

    return DSESweepResult(
        blocks_scanned=len(blocks),
        blocks_optimized=sum(1 for r in results if r.status != "error"),
        blocks_proved=sum(1 for r in results if r.status == "proved"),
        total_wall_time_sec=time.time() - t0,
        results=results,
    )


__all__ = [
    "BlockResult",
    "DSESweepResult",
    "discover_blocks",
    "sweep_design",
]
