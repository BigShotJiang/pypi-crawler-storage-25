"""ATH-996: Encrypted prompt store.

Prompts are encrypted at build time with a key derived from the
license file. At runtime, the license-derived key decrypts them.
Even compiled .so files expose string literals via `strings` —
this layer makes prompt extraction require a valid license.

Build time: python3 build_cython.py --encrypt-prompts
Runtime: prompts auto-decrypt when license is loaded.
No license = prompts stay encrypted = proposer fails with clear error.
"""
from __future__ import annotations

import base64
import hashlib
import os
from pathlib import Path
from typing import Any


def _derive_key(license_data: dict[str, Any] | None = None) -> bytes:
    """Derive a 32-byte encryption key from license content."""
    if license_data is None:
        try:
            from kairos.license_scope import load_license
            license_data = load_license()
        except Exception:  # noqa: BLE001
            pass

    if license_data is None:
        dev_bypass = os.environ.get("KAIROS_DEV_NO_LICENSE") == "1"
        try:
            from kairos._build_meta import DEV_TOKEN
            if DEV_TOKEN and dev_bypass:
                return hashlib.sha256(DEV_TOKEN.encode()).digest()
        except ImportError:
            pass
        if dev_bypass:
            return hashlib.sha256(b"kairos-dev-eval-key").digest()
        raise RuntimeError(
            "Cannot decrypt prompts without a valid license. "
            "Run 'kairos eval-license' for a 30-day trial, or "
            "install your production license at ~/.athanor/license.json"
        )

    subject = license_data.get("subject", "")
    products = ",".join(sorted(license_data.get("products", [])))
    seed = f"{subject}:{products}".encode()
    return hashlib.sha256(seed).digest()


def encrypt_prompt(plaintext: str, key: bytes | None = None) -> str:
    """Encrypt a prompt string. Returns base64-encoded ciphertext."""
    if key is None:
        key = _derive_key()
    data = plaintext.encode("utf-8")
    encrypted = bytes(a ^ b for a, b in zip(data, _expand_key(key, len(data))))
    return base64.b64encode(encrypted).decode("ascii")


def decrypt_prompt(ciphertext: str, key: bytes | None = None) -> str:
    """Decrypt a prompt string from base64-encoded ciphertext."""
    if key is None:
        key = _derive_key()
    data = base64.b64decode(ciphertext)
    decrypted = bytes(a ^ b for a, b in zip(data, _expand_key(key, len(data))))
    return decrypted.decode("utf-8")


def _expand_key(key: bytes, length: int) -> bytes:
    """Expand key to required length via repeated hashing."""
    result = bytearray()
    block = key
    while len(result) < length:
        result.extend(block)
        block = hashlib.sha256(block).digest()
    return bytes(result[:length])


# Prompt cache — decrypted prompts cached per-process
_PROMPT_CACHE: dict[str, str] = {}


def get_prompt(name: str) -> str:
    """Get a decrypted prompt by name.

    Tries encrypted store first, falls back to plaintext files.
    Caches decrypted result for the process lifetime.
    """
    if name in _PROMPT_CACHE:
        return _PROMPT_CACHE[name]

    vault_dir = Path(__file__).parent / "_prompt_vault"
    encrypted_path = vault_dir / f"{name}.enc"

    if encrypted_path.is_file():
        ciphertext = encrypted_path.read_text().strip()
        plaintext = decrypt_prompt(ciphertext)
        _PROMPT_CACHE[name] = plaintext
        return plaintext

    # Fallback: plaintext file (dev mode)
    plaintext_path = vault_dir / f"{name}.txt"
    if plaintext_path.is_file():
        plaintext = plaintext_path.read_text()
        _PROMPT_CACHE[name] = plaintext
        return plaintext

    raise FileNotFoundError(
        f"Prompt '{name}' not found in vault. "
        f"Expected at {encrypted_path} or {plaintext_path}"
    )


__all__ = [
    "encrypt_prompt",
    "decrypt_prompt",
    "get_prompt",
]
