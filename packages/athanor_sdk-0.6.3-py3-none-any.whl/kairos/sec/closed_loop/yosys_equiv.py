"""Yosys combinational equivalence checking for combo blocks.

ATH-1112: EBMC BMC times out on wide combinational ALUs (178-bit,
900s). yosys equiv_struct + equiv_simple + equiv_induct proves the
same equivalence in seconds. This module provides the yosys-based
verification path for pure combinational designs (clock_port empty).
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

# ATH-1212a: strip Athanor + customer credentials from the yosys subprocess env.
from kairos.security.env_allowlist import safe_env_for_yosys


@dataclass(frozen=True)
class YosysEquivResult:
    proved: bool
    refuted: bool
    proven_cells: int
    unproven_cells: int
    elapsed_seconds: float
    method: str
    detail: str = ""


def _adaptive_timeout(gold_path: str | Path, default: int) -> int:
    """Compute adaptive timeout based on file size (proxy for cell count).

    Larger designs need more SAT solver time. Rule: max(default, lines * 2).
    A 150-line block (ALU, ~5800 cells post-elab) gets 300s.
    """
    try:
        lines = len(Path(gold_path).read_text().splitlines())
        return max(default, int(lines * 2))
    except Exception:  # noqa: BLE001
        return default


def verify_combo_equiv(
    *,
    gold_path: str | Path,
    gate_path: str | Path,
    gold_module: str,
    gate_module: str,
    timeout_sec: int = 120,
) -> YosysEquivResult:
    """Prove combinational equivalence via yosys equiv passes.

    Uses equiv_make + equiv_struct + equiv_simple + equiv_induct.
    Falls back to SAT miter if equiv passes leave unproven cells.
    Timeout adapts to design size (larger blocks get more time).
    """
    timeout_sec = _adaptive_timeout(gold_path, timeout_sec)
    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return YosysEquivResult(
            proved=False, refuted=False,
            proven_cells=0, unproven_cells=0,
            elapsed_seconds=0.0, method="yosys_equiv",
            detail="yosys not found on PATH",
        )

    gold = Path(gold_path).resolve()
    gate = Path(gate_path).resolve()

    t0 = time.time()

    # techmap normalizes function/generate blocks to primitive gates
    # BEFORE equiv matching. Without this, designs with different
    # structural representations (flat assigns vs generate blocks)
    # time out on equiv. With techmap, the -59.4% Hamming compound
    # proved in 0.38s instead of timing out at 120s.
    script = (
        f"read_verilog -sv {gold} {gate}; "
        f"proc; opt; techmap; opt; "
        f"equiv_make {gold_module} {gate_module} equiv; "
        f"equiv_struct; equiv_simple -seq 10; equiv_induct; "
        f"equiv_status"
    )

    try:
        r = subprocess.run(
            [yosys_bin, "-p", script],
            capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_yosys(),  # ATH-1212a
        )
    except subprocess.TimeoutExpired:
        return YosysEquivResult(
            proved=False, refuted=False,
            proven_cells=0, unproven_cells=0,
            elapsed_seconds=time.time() - t0,
            method="yosys_equiv",
            detail=f"yosys timed out after {timeout_sec}s",
        )

    elapsed = time.time() - t0
    output = r.stdout + r.stderr

    proven = 0
    unproven = 0
    m = re.search(
        r"Of those cells (\d+) are proven and (\d+) are unproven",
        output,
    )
    if m:
        proven = int(m.group(1))
        unproven = int(m.group(2))

    # Always run SAT miter as cross-check (multi-engine requirement per
    # Aidan directive: "battle tested extremely rigorously"). Even when
    # equiv closes all cells, SAT miter provides independent confirmation.
    # ATH-1111: multi-verifier gate requires dual-engine for combo blocks.
    # SAT timeout must be sufficient for elaborated designs.
    equiv_proved = (unproven == 0 and proven > 0)

    sat_timeout = max(timeout_sec, 300)
    sat_script = (
        f"read_verilog -sv {gold} {gate}; "
        f"proc; opt; techmap; opt; "
        f"miter -equiv {gold_module} {gate_module} miter; "
        f"flatten miter; "
        f"sat -verify -prove trigger 0 miter"
    )
    sat_proved = False
    sat_refuted = False
    try:
        r2 = subprocess.run(
            [yosys_bin, "-p", sat_script],
            capture_output=True, text=True, timeout=sat_timeout,
            env=safe_env_for_yosys(),  # ATH-1212a
        )
        sat_output = r2.stdout + r2.stderr
        sat_proved = "SUCCESS" in sat_output
        sat_refuted = ("FAIL" in sat_output or "proof did fail" in sat_output) and not sat_proved
    except subprocess.TimeoutExpired:
        pass

    elapsed = time.time() - t0

    if equiv_proved and sat_proved:
        return YosysEquivResult(
            proved=True, refuted=False,
            proven_cells=proven, unproven_cells=0,
            elapsed_seconds=elapsed,
            method="yosys_dual_engine",
            detail=f"DUAL VERIFIED: equiv {proven}/{proven} cells + SAT miter SUCCESS",
        )
    elif sat_proved and not equiv_proved:
        return YosysEquivResult(
            proved=True, refuted=False,
            proven_cells=proven, unproven_cells=unproven,
            elapsed_seconds=elapsed,
            method="yosys_sat_miter",
            detail=f"SAT miter proved (equiv had {unproven} unproven cells)",
        )
    elif equiv_proved and not sat_proved:
        return YosysEquivResult(
            proved=True, refuted=False,
            proven_cells=proven, unproven_cells=0,
            elapsed_seconds=elapsed,
            method="yosys_equiv_only",
            detail=f"equiv {proven}/{proven} cells proved (SAT miter did not confirm)",
        )
    elif sat_refuted:
        return YosysEquivResult(
            proved=False, refuted=True,
            proven_cells=proven, unproven_cells=unproven,
            elapsed_seconds=elapsed,
            method="yosys_sat_miter",
            detail="SAT miter found counterexample (designs NOT equivalent)",
        )

    return YosysEquivResult(
        proved=False, refuted=False,
        proven_cells=proven, unproven_cells=unproven,
        elapsed_seconds=elapsed,
        method="yosys_equiv",
        detail=f"{unproven} unproven cells remain after all passes",
    )


__all__ = ["verify_combo_equiv", "YosysEquivResult"]
