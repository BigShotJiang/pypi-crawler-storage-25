"""Curriculum-staged proposer manifest (ATH-1088).

Locks the four-stage difficulty ladder that governs curriculum
staging of the closed-loop proposer, per asabi's 2026-05-07
specification (slack ts 1778159289).

Stage structure:

* :data:`STAGE_MANIFEST` — immutable tuple of four
  :class:`CurriculumStage` entries, ordered from easiest to hardest.
* :func:`next_stage` — returns the next :class:`CurriculumStage` if
  the observed close-rate meets the current stage's advancement
  threshold, otherwise ``None``.
* :func:`to_json_serializable` — stage tuple → list of dicts, safe
  for :func:`json.dumps` without a custom encoder.
* :func:`from_json_serializable` — round-trip parse from list of dicts.

Cross-stage assumption transfer: each stage's PROVEN transformations
join the subsequent stage's miter assumption set. This module defines
the manifest data structure only; the orchestrator wiring that
implements assumption promotion lands in a separate PR post-greenlight.

Stage ↔ ``REMOVE_CLASSES`` mapping rationale:

* Stage 1 EASY — line-edit class: small blast radius, k=32 almost
  always sufficient. Three entries: "dead-logic-removal",
  "constant-propagation", "width-reduction".
* Stage 2 MEDIUM — mid-blast-radius: requires invariant mining or
  proven mutex assumptions. Four entries.
* Stage 3 HARD — broader structural rewrites: cross-block CSE + shift
  replacement. Two entries, k=64 default.
* Stage 4 BOSS — ``impl_swap`` and bridge-invariant-required rewrites.
  ``transformation_class_ids`` is intentionally empty for this release;
  ``impl_swap`` is its own class outside ``REMOVE_CLASSES`` and will be
  wired in post-Aidan-greenlight once bridge-invariant scaffolding
  lands.

This module is data-only. No orchestrator or proposer code is touched.
"""
from __future__ import annotations

from dataclasses import dataclass, fields, asdict


@dataclass(frozen=True)
class CurriculumStage:
    """One entry in the curriculum-stage manifest.

    Parameters
    ----------
    stage_id:
        Machine-stable identifier, e.g. ``"stage_1_easy"``.
    difficulty_label:
        Human-readable display label: ``"EASY"`` / ``"MEDIUM"`` /
        ``"HARD"`` / ``"BOSS"``.
    transformation_class_ids:
        Subset of ``REMOVE_CLASSES`` IDs from
        :mod:`kairos.sec.transformation_taxonomy` that this stage
        targets. Empty tuple is valid (see Stage 4 BOSS).
    n_proposals:
        Number of transformation proposals generated per iteration in
        this stage.
    k_bound:
        Default k-induction bound for formal equivalence verification
        in this stage. May be escalated by the orchestrator's bound
        ladder; this is the baseline.
    advancement_threshold_pct:
        Minimum close-rate percentage (0.0 – 100.0) required for the
        stage to advance to the next stage. The close-rate is the
        fraction of proposed transformations that discharge formally
        equivalent.
    requires_bridge_invariants:
        When ``True``, the orchestrator must supply bridge invariants
        before firing formal verification. Defaults to ``False``.
    """

    stage_id: str
    difficulty_label: str
    transformation_class_ids: tuple[str, ...]
    n_proposals: int
    k_bound: int
    advancement_threshold_pct: float
    requires_bridge_invariants: bool = False


# ---------------------------------------------------------------------------
# Manifest — locked per asabi 2026-05-07 (slack ts 1778159289).
# ---------------------------------------------------------------------------

STAGE_MANIFEST: tuple[CurriculumStage, ...] = (
    CurriculumStage(
        stage_id="stage_1_easy",
        difficulty_label="EASY",
        # Line-edit class: dead wires, constants, widths.
        # Small blast radius; k=32 is nearly always sufficient.
        transformation_class_ids=(
            "dead-logic-removal",
            "constant-propagation",
            "width-reduction",
        ),
        n_proposals=3,
        k_bound=32,
        advancement_threshold_pct=50.0,
    ),
    CurriculumStage(
        stage_id="stage_2_medium",
        difficulty_label="MEDIUM",
        # Mid-blast-radius: mutex-to-parallel-OR requires mutex_invariant
        # assumption; comparison-narrowing requires signal_range assumption;
        # redundant-guard-removal adds guard-condition tautology proofs.
        transformation_class_ids=(
            "mutual-exclusion-parallel-or",
            "common-subexpression-sharing",
            "comparison-narrowing",
            "redundant-guard-removal",
        ),
        n_proposals=5,
        k_bound=32,
        advancement_threshold_pct=50.0,
    ),
    CurriculumStage(
        stage_id="stage_3_hard",
        difficulty_label="HARD",
        # Broader structural rewrites: cross-block CSE via
        # dead-condition-elimination + shift-instead-of-multiply.
        # Lower advancement threshold (30%) reflects expected difficulty.
        transformation_class_ids=(
            "dead-condition-elimination",
            "shift-instead-of-multiply",
        ),
        n_proposals=8,
        k_bound=64,
        advancement_threshold_pct=30.0,
    ),
    CurriculumStage(
        stage_id="stage_4_boss",
        difficulty_label="BOSS",
        # impl_swap and bridge-invariant-required rewrites land here.
        # transformation_class_ids is intentionally empty: impl_swap is
        # its own class outside REMOVE_CLASSES and will be registered
        # post-Aidan-greenlight once bridge-invariant scaffolding is live.
        transformation_class_ids=(),
        n_proposals=10,
        k_bound=64,
        advancement_threshold_pct=30.0,
        requires_bridge_invariants=True,
    ),
)


# ---------------------------------------------------------------------------
# Advancement helper
# ---------------------------------------------------------------------------

def next_stage(
    current_stage_id: str,
    close_rate_pct: float,
) -> CurriculumStage | None:
    """Return the next :class:`CurriculumStage` if advancement criteria are met.

    Parameters
    ----------
    current_stage_id:
        The ``stage_id`` of the stage that just completed an iteration.
    close_rate_pct:
        Observed close-rate for the current iteration, expressed as a
        percentage (0.0 – 100.0). A transformation "closes" when formal
        equivalence verification succeeds at or within ``k_bound``.

    Returns
    -------
    CurriculumStage | None
        The next stage in :data:`STAGE_MANIFEST` if
        ``close_rate_pct >= current_stage.advancement_threshold_pct``,
        otherwise ``None``.

        Returns ``None`` when ``current_stage_id`` is the last stage in
        the manifest (no further stage to advance to), regardless of
        ``close_rate_pct``.

    Raises
    ------
    ValueError
        If ``current_stage_id`` is not found in the manifest.
    """
    stage_ids = [s.stage_id for s in STAGE_MANIFEST]
    try:
        idx = stage_ids.index(current_stage_id)
    except ValueError:
        raise ValueError(
            f"unknown stage_id {current_stage_id!r}; "
            f"valid IDs: {stage_ids}"
        )

    current = STAGE_MANIFEST[idx]
    if close_rate_pct < current.advancement_threshold_pct:
        return None

    next_idx = idx + 1
    if next_idx >= len(STAGE_MANIFEST):
        return None

    return STAGE_MANIFEST[next_idx]


# ---------------------------------------------------------------------------
# JSON serialization — mirrors transformation_taxonomy.py pattern
# ---------------------------------------------------------------------------

def to_json_serializable(
    stages: tuple[CurriculumStage, ...],
) -> list[dict[str, object]]:
    """Convert a stage tuple to a JSON-serializable list of dicts.

    Tuple-valued fields (``transformation_class_ids``) are converted to
    lists so :func:`json.dumps` accepts the result without a custom
    encoder. Suitable for shipping in cert tarballs or proposer-prompt
    literals.
    """
    out: list[dict[str, object]] = []
    for s in stages:
        d = asdict(s)
        for k, v in list(d.items()):
            if isinstance(v, tuple):
                d[k] = list(v)
        out.append(d)
    return out


def from_json_serializable(
    payload: list[dict[str, object]],
) -> tuple[CurriculumStage, ...]:
    """Round-trip parse of a list-of-dicts back into a stage tuple.

    Lists are converted back to tuples for ``transformation_class_ids``.
    Unknown keys are silently ignored to allow forward-compatible
    extensions without breaking existing readers.
    """
    field_names = {f.name for f in fields(CurriculumStage)}
    out: list[CurriculumStage] = []
    for d in payload:
        kwargs: dict[str, object] = {}
        for k in field_names:
            if k not in d:
                continue
            v = d[k]
            if isinstance(v, list):
                v = tuple(v)
            kwargs[k] = v
        out.append(CurriculumStage(**kwargs))
    return tuple(out)


__all__ = [
    "CurriculumStage",
    "STAGE_MANIFEST",
    "next_stage",
    "to_json_serializable",
    "from_json_serializable",
]
