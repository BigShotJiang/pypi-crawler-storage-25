"""Target identification + ranking for area-optimization candidates (ATH-990, B v0).

Given an SoC source tree (multi-module RTL design) plus an
optional openSTA report, identify which blocks have area-
optimization headroom and rank them by:

* *static signals* — register count, gate count, fan-in/fan-out
  metrics extracted from the IR;
* *timing-aware weight* — when an openSTA report is available,
  blocks not on the critical timing path get higher area-
  optimization priority (we can shrink them without breaking
  timing; critical-path blocks have less area headroom because
  shrinking risks timing closure);
* *LLM judgment overlay* — natural-language reasoning over the
  block's role + structural shape (e.g. \"control-plane FSM with
  one-hot encoding has predictable area-shrinkability\").

The ranking output feeds the orchestrator (:mod:`._orchestrator`,
ATH-991, W2 work), which iterates targets in order and runs the
proposer (:mod:`._proposer`) + closed-loop verify on each.

Today's commit ships the dataclass shapes + the openSTA report
parser stub. The actual openSTA invocation (`kairos.opensta`
wrapper, mirror of `kairos.ebmc` / `kairos.sv` pattern) +
LLM-judgment overlay land in follow-up commits.

Cross-refs
----------

* :issue:`ATH-988` — parent epic, Annapurna ask.
* :issue:`ATH-990` — this child (ranker).
* :mod:`kairos.opensta` — *not yet shipped*; the openSTA wrapper
  this ranker invokes lives in its own namespace mirror of
  :mod:`kairos.ebmc`. Lane: kairos.* SDK side per ATH-988
  triage thread.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence


@dataclass(frozen=True)
class StaticBlockMetrics:
    """Static-analysis metrics for one RTL block.

    Attributes
    ----------
    module_name:
        SV module name. The unique identity for the block in this
        ranker's output.
    register_count:
        Number of state-bearing flops in the module body. Includes
        all flops the flop-correspondence audit
        (:mod:`kairos.sec._flop_audit`) would extract.
    combinational_gate_count:
        Estimated count of combinational primitives. v0 uses a
        rough heuristic (assignment count + comparator count);
        v1 hooks the openSTA element count for a real number.
    fanin_max:
        Maximum fan-in of any combinational signal in the block.
        High fan-in suggests datapath-heavy logic with potential
        for shared-sub-expression hoisting.
    fanout_max:
        Maximum fan-out. High fan-out flags heavily-broadcast
        signals that may be candidates for register-pipelining
        retiming.
    """

    module_name: str
    register_count: int
    combinational_gate_count: int
    fanin_max: int = 0
    fanout_max: int = 0


@dataclass(frozen=True)
class TimingProfile:
    """openSTA-derived timing snapshot for one block.

    Empty fields when openSTA is not available; the ranker
    handles the no-timing case by falling back to static-only
    ranking.

    Attributes
    ----------
    module_name:
        SV module name.
    on_critical_path:
        Whether any path through this block touches the
        worst-negative-slack path. Critical-path blocks rank
        LOWER for area optimization (shrink-without-timing-
        regression is harder).
    worst_slack_ns:
        Worst slack in nanoseconds across the block's input/output
        timing arcs. ``None`` if openSTA was not run.
    """

    module_name: str
    on_critical_path: bool = False
    worst_slack_ns: float | None = None


@dataclass(frozen=True)
class RankedTarget:
    """One block in the ranked area-optimization-target list.

    Attributes
    ----------
    module_name:
        SV module name.
    score:
        Aggregate score (higher == better target). Combines static
        metrics + timing-aware penalty + LLM-judgment overlay.
    static_metrics:
        Static-analysis snapshot.
    timing_profile:
        openSTA snapshot (may be empty).
    llm_rationale:
        Natural-language explanation of why this block ranks
        where it does. Surfaced in the customer-facing
        certificate.
    """

    module_name: str
    score: float
    static_metrics: StaticBlockMetrics
    timing_profile: TimingProfile
    llm_rationale: str = ""


@dataclass(frozen=True)
class RankerResult:
    """Output of one ranker invocation on an SoC source tree.

    Attributes
    ----------
    targets:
        :class:`RankedTarget` list, ordered most-promising-first.
    skipped_modules:
        Module names the ranker chose to skip — e.g. test
        infrastructure, vendor IP we shouldn't touch, pure-
        wiring modules with no area headroom. Each carries a
        one-line skip reason for the customer-facing report.
    used_opensta:
        ``True`` if the timing-aware overlay was applied.
        ``False`` falls back to static-only ranking with an
        explicit note in the customer artifact.
    """

    targets: Sequence[RankedTarget] = field(default_factory=list)
    skipped_modules: dict[str, str] = field(default_factory=dict)
    used_opensta: bool = False

    def top_n(self, n: int) -> list[RankedTarget]:
        """Return the top-n targets, capped at the available count."""
        return list(self.targets[:n])
