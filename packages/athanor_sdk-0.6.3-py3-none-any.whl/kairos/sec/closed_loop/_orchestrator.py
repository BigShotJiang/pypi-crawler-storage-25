"""Closed-loop propose-verify-adjust orchestrator (ATH-991, C v0).

.. note:: --verbose logging

   When ``logging.getLogger("kairos").level <= INFO``, the orchestrator
   prints real-time progress: phase headers, proposer model + class,
   verifier engine + verdict, per-iteration timing. Activated via
   ``kairos optimize --verbose``.

State machine that drives the autonomous iteration loop the
Annapurna chief architect asked for:

* takes a target RTL block + (optional) an openSTA report;
* runs the ranker (:mod:`._ranker`) to score targets;
* for each target in order, runs the proposer (:mod:`._proposer`)
  to generate candidate optimizations;
* for each proposal, runs SEC verification (:func:`kairos.sec.verify_sec`)
  in dual mode (BMC + k-induction);
* on INCONCLUSIVE under k-induction, hands off to the
  invariant-gen harness (:mod:`._invariant_gen`) for a bridge
  invariant + re-verification;
* halts when a verified-equivalent-and-area-reduced variant
  lands, OR a documented halt condition fires (max iterations,
  hard-refute, human-review-needed).

Trace event emission goes through :mod:`kairos.observe` so the
state machine produces one parent ``solve_run`` row plus per-iteration
child ``sdk_agent_events``. Platform's ATH-993 surface
(``/analytics/area-optimization``) consumes the
per-iteration emits to render the delta-cell + state-bucket dashboard
for the customer (per asabi tone-pass + ATH-987 honest-framing
discipline).
"""
from __future__ import annotations

import logging as _logging

_log = _logging.getLogger("kairos.optimize")


def _vlog(msg: str) -> None:
    """Verbose log: prints when kairos optimize --verbose is active."""
    _log.info(msg)


def _poll_agent_messages(run_id: str) -> dict[str, list]:
    """Poll message queue at phase boundary. Returns messages by type."""
    try:
        from kairos.sec.closed_loop.message_queue import poll_messages
        msgs = poll_messages(run_id)
        result: dict[str, list] = {"hint": [], "config": [], "control": []}
        for m in msgs:
            result[m.msg_type].append(m)
            _vlog(f"  [msg] {m.msg_type} from {m.target}: {m.content[:80]}")
        return result
    except Exception:  # noqa: BLE001
        return {"hint": [], "config": [], "control": []}

import json as _json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal, Sequence

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL
from kairos.sec.closed_loop._invariant_gen import InvariantGenResult
from kairos.sec.closed_loop._proposer import TransformationProposal
from kairos.sec.closed_loop._ranker import RankedTarget


DisplayMode = Literal["chosen_on_top", "refuted_on_top", "equal_weight"]


class IterationState(str, Enum):
    """States the orchestrator's per-iteration cursor passes through.

    The state machine progresses through these in order. A
    halt-condition state aborts forward motion and surfaces the
    iteration's final state to the customer-facing report.
    """

    RANKED = "ranked"
    """Ranker emitted ordered targets; cursor at first target."""

    PROPOSED = "proposed"
    """Proposer emitted ordered transformation proposals for the
    current target."""

    BMC_BOUNDED = "bmc_bounded"
    """BMC pass on the proposed variant ran; result captured."""

    KINDUCTION_TRIED = "kinduction_tried"
    """K-induction pass on the proposed variant ran; result captured.
    May be PROVED, REFUTED, or INCONCLUSIVE."""

    INVARIANT_GEN_TRIED = "invariant_gen_tried"
    """K-induction was INCONCLUSIVE; invariant-gen harness ran on
    the open property. May close the proof or fail to."""

    HALTED_PROVED = "halted_proved"
    """Variant proved equivalent under either k-induction directly
    or k-induction + invariant-gen bridge. Customer-success state."""

    HALTED_REFUTED = "halted_refuted"
    """BMC or k-induction returned a counter-example trace. The
    variant is NOT equivalent. Loop advances to the next proposal."""

    HALTED_HUMAN_REVIEW = "halted_human_review"
    """Invariant-gen exhausted attempts without closing the proof,
    OR proposer signaled hard-block, OR the verdict set
    inconsistent.

    *Final-disposition state, not a mid-loop pause.* Per Todd's
    2026-05-05 spec lock-in (asabi relayed): the orchestrator is
    an AUTONOMOUS loop — "propose, prove, measure, repeat" until
    convergence or budget exhaustion. The engineer reviews the
    final winner (or top-3 candidates), not every intermediate
    step. This state is the iteration's terminal disposition
    when the engine cannot make progress; the customer-facing
    cert surfaces the stuck-state with full context (proposer
    rationale + BMC trace + k-induction state + invariant-gen
    attempts), and the customer reviews POST-HOC. The loop does
    NOT pause-and-wait for human input."""


class OrchestratorHaltReason(str, Enum):
    """Why the whole orchestrator (not a single iteration) halted."""

    PROVED_EQUIVALENT_VARIANT_FOUND = "proved_equivalent_variant_found"
    """A proposal closed the SEC + (if needed) invariant-gen +
    produced an area delta. The customer-facing certificate ships
    the variant + the assumption stack."""

    NO_PROPOSAL_CLOSED = "no_proposal_closed"
    """All proposals tried; none produced a verified equivalent
    variant. Customer-facing report names the halt + the trace
    + the proposer's reasoning per :issue:`ATH-991` deliverable."""

    MAX_ITERATIONS = "max_iterations"
    """Iteration cap reached (default 10) before any proposal
    closed. Customer-facing report names the halt + the
    best-attempt-so-far."""

    HUMAN_REVIEW_NEEDED = "human_review_needed"
    """Invariant-gen exhausted attempts on a candidate variant
    that BMC said was promising; surfaced explicitly so the
    customer can decide whether to spend engineer-hours on a
    manually-supplied invariant."""


@dataclass(frozen=True)
class IterationRecord:
    """One iteration's full trace, emitted as a child sdk_agent_events row.

    Attributes
    ----------
    iteration_index:
        0-indexed iteration counter within the orchestrator run.
    target:
        :class:`RankedTarget` the proposer was asked to optimize.
    proposal:
        :class:`TransformationProposal` the proposer emitted.
        ``None`` if the proposer halted without proposing
        (proposer-halt handled separately).
    bmc_verdict:
        EBMC BMC result label: ``"PROVED"`` / ``"REFUTED"`` /
        ``"INCONCLUSIVE"`` / ``"SKIPPED"``.
    kinduction_verdict:
        EBMC k-induction result label.
    invariant_gen_result:
        :class:`InvariantGenResult` if invariant-gen ran;
        ``None`` if k-induction closed without it.
    final_state:
        Terminal :class:`IterationState` for this iteration.
    measured_area_delta_pct:
        Post-verify *measured* area delta (vs the proposer's
        *claimed* delta). Populated from openSTA / synthesis
        report when available; ``None`` otherwise. The pre-flight
        gate cross-checks this against the proposer's claim.
    """

    iteration_index: int
    target: RankedTarget
    proposal: TransformationProposal | None
    bmc_verdict: str
    kinduction_verdict: str
    invariant_gen_result: InvariantGenResult | None = None
    final_state: IterationState = IterationState.RANKED
    measured_area_delta_pct: float | None = None

    def is_auto_acceptable(self) -> bool:
        """Whether the orchestrator may auto-accept this iteration as
        the chosen variant without human approval.

        Per Todd's 2026-05-05 customer-trust signal: "we trust the
        equivalence proof — if EBMC says it's equivalent, it is."
        Customer trust rests on the verifier verdict; if the verdict
        was conditional on an unproven assume-property bridge
        invariant (D-spike harness produced a candidate but no
        Lean theorem discharges it), auto-accept would silently
        promote an UNPROVEN claim into the customer cert. That is
        the v1-incident class applied at the engine accept gate.

        The structural rule:

        * Iteration must have terminated in :attr:`IterationState.HALTED_PROVED`.
        * If invariant-gen ran (``invariant_gen_result is not None``),
          its chosen candidate's :attr:`InvariantCandidate.proves_obligation`
          must be non-null (a real Lean theorem name discharges
          the bridge invariant).
        * If invariant-gen did not run (k-induction PROVED standalone),
          the iteration is auto-acceptable — the verifier verdict
          stands on its own.

        Returns ``True`` if all conditions hold; ``False`` otherwise.

        Callers (orchestrator's chosen-iteration selection logic
        and the cert-emit pre-flight gate) should refuse to mark
        a non-auto-acceptable iteration as ``chosen`` without
        explicit customer-facing assumption-stack disclosure +
        founder approval.
        """
        if self.final_state != IterationState.HALTED_PROVED:
            return False
        if self.invariant_gen_result is None:
            return True
        chosen_inv = self.invariant_gen_result.chosen
        if chosen_inv is None:
            return False
        return chosen_inv.proves_obligation is not None


@dataclass(frozen=True)
class OrchestratorRunResult:
    """Final result of one orchestrator invocation.

    Attributes
    ----------
    parent_run_id:
        ``solve_runs.run_id`` for the parent row that aggregates
        the per-iteration child events.
    iterations:
        Ordered :class:`IterationRecord` list, one per attempted
        proposal.
    chosen:
        :class:`IterationRecord` whose proposal landed as the
        verified-equivalent + area-reducing variant. ``None`` if
        the run halted without finding one.
    halt_reason:
        Why the orchestrator halted overall.
    customer_report_path:
        Path to the customer-facing certificate the orchestrator
        emitted, in the same shape as the v2.5 toy_fifo_chain
        SEC certificate. ``None`` if no proposal closed (the
        report is still emitted with the halt reason but does
        not get the customer-success framing).
    """

    parent_run_id: str
    iterations: Sequence[IterationRecord] = field(default_factory=list)
    chosen: IterationRecord | None = None
    halt_reason: OrchestratorHaltReason = OrchestratorHaltReason.MAX_ITERATIONS
    display_mode: DisplayMode = "equal_weight"
    customer_report_path: str | None = None

    def closed_count(self) -> int:
        return sum(
            1
            for r in self.iterations
            if r.final_state == IterationState.HALTED_PROVED
        )

    def refuted_count(self) -> int:
        return sum(
            1
            for r in self.iterations
            if r.final_state == IterationState.HALTED_REFUTED
        )

    def human_review_count(self) -> int:
        return sum(
            1
            for r in self.iterations
            if r.final_state == IterationState.HALTED_HUMAN_REVIEW
        )


def derive_display_mode(
    halt_reason: OrchestratorHaltReason,
    iterations: Sequence[IterationRecord],
) -> DisplayMode:
    """Derive the dashboard's parent-page composition mode from halt + iterations.

    Per consensus 2026-05-04 (qa proposed, platform +1, asabi
    architect-call), `halt_reason` and `display_mode` answer
    different questions on different axes:

    * `halt_reason` is the **temporal/causal axis** — "why did the
      orchestrator stop?"
    * `display_mode` is the **customer-attention axis** — "what
      should the dashboard emphasize first?"

    Decoupling the two lets the dashboard add new display modes
    without forcing engine-taxonomy churn, and lets the engine
    refine halt-reason semantics without forcing dashboard
    rendering churn.

    Set-once at run-close (in the same code path that sets
    halt_reason). Never recomputed on dashboard read — that's
    where engine-vs-dashboard drift creeps in.

    The rule:

    1. ``halt_reason == PROVED_EQUIVALENT_VARIANT_FOUND`` →
       ``"chosen_on_top"`` (the chosen iteration's three-card
       panel is the customer-trust signal).
    2. Else, if any iteration ended ``HALTED_REFUTED`` with a
       non-null counter-example trace → ``"refuted_on_top"``
       (the refuted iteration's counter-example IS the
       customer-trust signal even when no proposal closed).
    3. Else (max_iterations / no_proposal_closed /
       human_review_needed without a refuted-with-cex iteration)
       → ``"equal_weight"`` (no chosen, no counter-example trust
       signal; render iterations equal-weight).

    Pinned invariants (engine-side test fixtures):

    * ``display_mode=chosen_on_top`` ⇒
      ``halt_reason == proved_equivalent_variant_found``
    * ``display_mode=chosen_on_top`` and at-least-one
      ``HALTED_REFUTED`` iteration → engine bug (impossible
      co-occurrence; dashboard renders question-mark + soft
      alert per the same convention used for forward-state
      iterations that should not appear in finished runs)
    * ``display_mode=refuted_on_top`` ⇒ at least one iteration
      ``HALTED_REFUTED`` with non-null
      ``counter_example_text``
    * ``display_mode=equal_weight`` ⇒ no iteration
      ``HALTED_REFUTED`` with non-null
      ``counter_example_text``
    """
    if halt_reason == OrchestratorHaltReason.PROVED_EQUIVALENT_VARIANT_FOUND:
        return "chosen_on_top"

    has_refuted_with_cex = any(
        it.final_state == IterationState.HALTED_REFUTED
        and _iteration_has_counterexample(it)
        for it in iterations
    )
    if has_refuted_with_cex:
        return "refuted_on_top"

    return "equal_weight"


def _iteration_has_counterexample(it: IterationRecord) -> bool:
    """A HALTED_REFUTED iteration carries a non-null cex when EBMC
    (BMC or k-induction) returned a concrete trace, NOT when
    invariant-gen halted via REFUTED-on-an-attempt.

    The distinction matters for display_mode: a true EBMC
    counter-example is the customer-trust signal worth surfacing
    on top; an invariant-gen attempt's counter-example is a
    diagnostic of the proposer-loop, not of the variant under
    test.
    """
    if it.bmc_verdict.startswith("REFUTED") or it.kinduction_verdict.startswith(
        "REFUTED"
    ):
        return True
    return False


# ---------------------------------------------------------------------------
# Iteration-arc helpers (moved from examples/customer/.../demo_driver.py per
# Phase 0a-wiring commit 2a). The library now owns the proposer-verifier-
# bridge-iterate emit chain so other surfaces (MCP `kairos_optimize_block`,
# in-process callers, future cert-mint scripts) reuse the same code path
# the v2.7 demo dogfooded. Path constants that used to live as module-level
# `INPUTS_DIR` / `WORK_DIR` are now explicit parameters.
# ---------------------------------------------------------------------------


from kairos.sec.closed_loop.verify_pipeline import (
    capture_ebmc_subprocess as _capture_ebmc_subprocess,
    diagnose_ebmc_outcome as _diagnose_ebmc_outcome,
    iteration_outcome_from_bmc_result as _iteration_outcome_from_bmc_result,
)


def _emit_iteration_arc_for_proposal(
    *,
    obs: Any,
    iteration_index: int,
    proposal: Any,  # TransformationProposal
    parent_run_id: str,
    sig: dict[str, Any],
    inputs_dir: Path,
    work_dir: Path,
    bound: int,
    timeout_sec: int,
    repo_root: Path | None = None,
    max_proposer_inner_retries: int = 5,
    proposer_model: str = DEFAULT_SEC_PROPOSER_MODEL,
    proposer_timeout_sec: int = 360,
    custom_engine: str | None = None,
) -> dict[str, Any]:
    """Run one proposal end-to-end + emit the iteration-arc event chain.

    Returns a dict summarising the outcome for cert-prose aggregation.

    Parameters
    ----------
    inputs_dir:
        Directory containing the original signature.gold_sv file. Used as
        the source for shutil.copy into the per-iteration bundle.
    work_dir:
        Directory under which per-iteration bundles
        (``iter_<n>_bundle/``) and tmp gate files are written.
    repo_root:
        Optional path used as the anchor for relative-path display in
        emitted event payloads (``gate_sv_path`` field). When ``None``,
        absolute paths are emitted.
    """
    from kairos.sec import verify_sec
    from kairos.sec.closed_loop import generate_invariant
    from kairos.sec._adapter import _ports_from_signature

    ports = _ports_from_signature(sig)
    gold_module = sig["gold_module"]
    gate_module = sig["gate_module"]

    # Write the LLM's proposed gate_sv to a tmp file inside work_dir.
    # Module-rename the proposed gate to gate_module if needed (LLM may
    # have kept the gold module name).
    proposed_gate_text = proposal.gate_sv
    if (
        f"module {gold_module}" in proposed_gate_text
        and f"module {gate_module}" not in proposed_gate_text
    ):
        proposed_gate_text = proposed_gate_text.replace(
            f"module {gold_module}",
            f"module {gate_module}",
            1,
        )
        proposed_gate_text = proposed_gate_text.replace(
            f"endmodule // {gold_module}",
            f"endmodule // {gate_module}",
        )

    work_dir.mkdir(parents=True, exist_ok=True)
    tmp_gate = work_dir / f"iter_{iteration_index}_proposed_gate.v"
    tmp_gate.write_text(proposed_gate_text)

    # Construct a per-iteration bundle directory so generate_invariant()
    # (which reads bundle/signature.json + bundle/_sec_work/miter.sv) can
    # operate on the PROPOSED gate, not the original gate.v. The bundle
    # copies signature.json + gold.sv + writes the proposed gate under
    # signature.gate_v's filename. verify_sec generates miter.sv into
    # bundle/_sec_work/ as a side effect of the BMC call, which
    # generate_invariant then reads for the bridge-invariant injection.
    iter_bundle = work_dir / f"iter_{iteration_index}_bundle"
    iter_bundle.mkdir(parents=True, exist_ok=True)
    iter_sig = dict(sig)
    iter_sig["gate_v"] = "gate.v"
    (iter_bundle / "signature.json").write_text(_json.dumps(iter_sig, indent=2))
    # Copy gold into the iter_bundle. When a pre-elaborated gold exists
    # (_gold_elab_sv), copy BOTH the original (for proposer context) and
    # the elaborated (for EBMC verification). gold_sv stays the original
    # human-readable source; _gold_elab_sv is the yosys-flattened form.
    gold_dst = iter_bundle / sig["gold_sv"]
    gold_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(inputs_dir / sig["gold_sv"], gold_dst)
    gold_elab_key = sig.get("_gold_elab_sv")
    if gold_elab_key:
        gold_elab_dst = iter_bundle / gold_elab_key
        gold_elab_dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(inputs_dir / gold_elab_key, gold_elab_dst)
    # Prepend .inc/.v function-library deps to the gate body so yosys
    # can resolve functions like AP_LOG2 that are defined in shared
    # include files. The gold has these pre-concatenated; the proposer's
    # gate body doesn't. Without this, yosys errors on function calls.
    gate_text_with_deps = proposed_gate_text
    for dep_rel in sig.get("dep_files") or []:
        dep_path = inputs_dir / dep_rel
        if dep_path.is_file() and dep_path.suffix in (".inc", ".v"):
            dep_content = dep_path.read_text()
            if "function" in dep_content and "module" not in dep_content.split("function")[0][:200]:
                gate_text_with_deps = dep_content + "\n" + gate_text_with_deps
    (iter_bundle / "gate.v").write_text(gate_text_with_deps)

    # Multi-module bundles (ATH-1074): when signature.dep_files lists
    # sub-module RTL files, copy them verbatim into the iter_bundle.
    # Both gold-side and gate-side share the same dep modules; only
    # the top module differs. EBMC needs all of them in rtl_inputs.
    dep_files_iter: list[Path] = []
    for dep_rel in sig.get("dep_files") or []:
        src = inputs_dir / dep_rel
        dst = iter_bundle / dep_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, dst)
        dep_files_iter.append(dst)

    # ATH-1115 sub-5: When gold was pre-elaborated (elaborate_gold=True),
    # sig["dep_files"] was cleared to [] because the gold is self-contained.
    # But the LLM proposer's gate may still reference sub-modules (e.g.
    # AP_DFFR_US, AP_LDFFR_US). Recover original dep files from the
    # bundle's inputs/ directory so gate elaboration can resolve them.
    # Also stored in sig["_original_dep_files"] if available.
    if not dep_files_iter and sig.get("_gold_pre_elaborated", False):
        original_deps = sig.get("_original_dep_files") or []
        if not original_deps:
            # Fallback: scan inputs_dir for .v files that aren't the gold
            gold_name = Path(sig["gold_sv"]).name
            inputs_subdir = inputs_dir / "inputs"
            scan_dir = inputs_subdir if inputs_subdir.is_dir() else inputs_dir
            for vf in sorted(scan_dir.glob("*.v")):
                if vf.name != gold_name:
                    original_deps.append(
                        str(vf.relative_to(inputs_dir))
                    )
        for dep_rel in original_deps:
            src = inputs_dir / dep_rel
            if src.is_file():
                dst = iter_bundle / dep_rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(src, dst)
                dep_files_iter.append(dst)

    # ATH-1076: yosys-elaborate-first preprocessing. EBMC 5.10's SV
    # parser doesn't accept several constructs yosys handles cleanly
    # (genvar `++`, `\`include` inside `\`ifdef`, `logic` keyword,
    # named generate blocks). Elaborate gold + gate via yosys to plain
    # Verilog before passing to verify_sec. Only fires when
    # signature.dep_files is non-empty (multi-module bundles); single-
    # file bundles like the v2.7 toy_fifo_chain skip elaboration to
    # preserve byte-stable cert reproduction.
    # Use pre-elaborated gold for verification when available (params
    # already baked in, clean Verilog-2001). Fall back to raw gold_sv.
    _gold_elab_sv = sig.get("_gold_elab_sv")
    gold_for_verify = (
        iter_bundle / _gold_elab_sv if _gold_elab_sv
        else iter_bundle / sig["gold_sv"]
    )
    gate_for_verify = iter_bundle / "gate.v"
    deps_for_verify: list[Path] | None = dep_files_iter or None
    param_overrides: dict[str, str | int] = {}
    for p in sig.get("parameters", []):
        name = p.get("name")
        if not name:
            continue
        v = p.get("concrete_for_sec")
        if v is None:
            continue
        param_overrides[name] = v
    gold_pre_elaborated = sig.get("_gold_pre_elaborated", False)
    if dep_files_iter or param_overrides or gold_pre_elaborated:
        from kairos.sec.preprocess import yosys_elaborate_to_verilog

        elab_dir = iter_bundle / "_elab"
        elab_dir.mkdir(parents=True, exist_ok=True)
        # Skip gold re-elaboration when it was pre-elaborated (already
        # clean Verilog-2001 with params baked in). Re-elaborating a
        # yosys-output file with chparam fails on escaped identifiers.
        if not gold_pre_elaborated:
            gold_elab = yosys_elaborate_to_verilog(
                rtl_path=gold_for_verify,
                top_module=gold_module,
                dep_files=dep_files_iter,
                output_path=elab_dir / "gold_elab.v",
                log_dir=elab_dir,
                timeout_sec=timeout_sec,
                parameter_overrides=param_overrides or None,
            )
            gold_for_verify = Path(gold_elab.elaborated_path)
        try:
            gate_elab = yosys_elaborate_to_verilog(
                rtl_path=gate_for_verify,
                top_module=gate_module,
                dep_files=dep_files_iter,
                output_path=elab_dir / "gate_elab.v",
                log_dir=elab_dir,
                timeout_sec=timeout_sec,
                parameter_overrides=param_overrides or None,
                flatten=False,
            )
        except Exception as elab_err:  # noqa: BLE001
            obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "ebmc_bmc",
                "bound": 0,
                "result": "SETUP_ERROR",
                "elapsed_sec": 0.0,
                "diagnostic_class": "setup_error",
                "detail": f"Gate elaboration failed: {str(elab_err)[:200]}",
            })
            return {
                "iteration_index": iteration_index,
                "outcome": "errored",
                "outcome_reason": f"gate_elaborate_failed: {str(elab_err)[:300]}",
                "transformation_class": proposal.transformation_class.value,
                "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
                "bridges_used": [],
                "property_verdicts": {},
            }
        gate_for_verify = Path(gate_elab.elaborated_path)
        # After flatten, dep modules are inlined into the elaborated
        # form — EBMC reads only the elaborated gold + gate, no deps.
        deps_for_verify = None

    if repo_root is not None:
        try:
            gate_sv_path_field = str(tmp_gate.relative_to(repo_root))
        except ValueError:
            gate_sv_path_field = str(tmp_gate)
    else:
        gate_sv_path_field = str(tmp_gate)

    obs.emit(
        "transformation_proposed",
        run_subtype="theorem_proving",
        payload={
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "transformation_class": proposal.transformation_class.value,
            "transformation_description": (
                proposal.rationale.split("\n\n", 1)[0]
                if "\n\n" in proposal.rationale
                else proposal.rationale[:160]
            ),
            "proposer_model": proposer_model,
            "estimated_area_delta_pct": proposal.claimed_area_delta_pct,
            "gate_sv_path": gate_sv_path_field,
            # ATH-1083 Phase A: surface concrete_for_sec parameter overrides
            # so the platform-side IterationRow can render the 4-way honest-
            # framing distinction (verbatim / silent / partial WARN / full WARN).
            # None when sig.parameters carries no concrete_for_sec entries.
            "parameter_overrides": (param_overrides or None),
            # Disambiguates parameter-free RTL (b) from parameterized-RTL-
            # without-overrides (c). count = len(sig.parameters) regardless
            # of whether each entry has concrete_for_sec set. Platform reads
            # count + parameter_overrides.keys() to compute partial vs full
            # WARN. Per platform render-side flag on PR #532 scope-pass.
            "rtl_parameter_count": len(sig.get("parameters", []) or []),
        },
    )

    # Pre-verification gates (verify_pipeline.py)
    from kairos.sec.closed_loop.verify_pipeline import (
        check_structural_gate,
        check_toggle_power_gate,
        select_engine,
    )
    gate_passes, gold_cells_pre, gate_cells_pre = check_structural_gate(
        gold_for_verify, gate_for_verify, gold_module, gate_module,
    )
    if not gate_passes:
        return {
            "iteration_index": iteration_index,
            "outcome": "inconclusive",
            "outcome_reason": (
                f"structural_gate_rejected: gate ({gate_cells_pre} cells) "
                f">= gold ({gold_cells_pre} cells). No area reduction after "
                f"synthesis — proposal is cosmetic, not structural."
            ),
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": [],
            "property_verdicts": {},
        }

    if gold_cells_pre and gate_cells_pre and gate_cells_pre < gold_cells_pre:
        tp_passes, tp = check_toggle_power_gate(
            gold_for_verify, gate_for_verify, gold_module, gate_module,
            sig, iter_bundle,
        )
        if not tp_passes:
            return {
                "iteration_index": iteration_index,
                "outcome": "inconclusive",
                "outcome_reason": (
                    f"toggle_power_gate_rejected: gate toggles "
                    f"{tp['toggle_delta_pct']:+.1f}% vs gold. "
                    f"Area improved but power regressed significantly."
                ),
                "transformation_class": proposal.transformation_class.value,
                "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
                "bridges_used": [],
                "property_verdicts": {},
            }

    # Tag block class for cross-block learning
    try:
        from kairos.sec.closed_loop.block_memory import save_block_class
        from kairos.sec.closed_loop.prompt_composer import _detect_block_class
        _gold_text = (inputs_dir / sig["gold_sv"]).read_text() if sig.get("gold_sv") else ""
        _bc = _detect_block_class(_gold_text, sig)
        if _bc and sig.get("gold_sv"):
            save_block_class(str(inputs_dir / sig["gold_sv"]), _bc)
    except Exception:  # noqa: BLE001
        pass

    # Engine selection — custom engine overrides auto-detect
    if custom_engine:
        from kairos.sec.closed_loop.engine_registry import get_registry
        reg = get_registry()
        eng = reg.get(custom_engine)
        if eng is None:
            raise ValueError(
                f"Custom engine '{custom_engine}' not registered. "
                f"Call kairos.register_engine('{custom_engine}', your_engine) first."
            )
        _vlog(f"  Custom engine: {custom_engine}")
        t0 = time.time()
        custom_result = eng.callable(
            gold_path=gold_for_verify,
            gate_path=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            timeout_sec=timeout_sec,
        )
        elapsed = time.time() - t0
        proved = bool(custom_result.get("proved"))
        refuted = bool(custom_result.get("refuted"))
        result_str = "PASS" if proved else "FAIL" if refuted else "INCONCLUSIVE"
        property_verdicts = {custom_engine: result_str}
        bmc_result_data: dict[str, Any] = {
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "engine": custom_engine,
            "bound": 0,
            "elapsed_sec": elapsed,
            "result": result_str,
            "detail": custom_result.get("detail", ""),
            "diagnostic_class": f"custom_{custom_engine}",
        }
        obs.emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)
        if proved:
            outcome = "accepted"
            outcome_reason = f"{custom_engine} proved equivalence"
        elif refuted:
            outcome = "inconclusive"
            outcome_reason = f"{custom_engine} refuted: {custom_result.get('detail', '')}"
        else:
            outcome = "inconclusive"
            outcome_reason = f"{custom_engine} inconclusive: {custom_result.get('detail', '')}"
        return {
            "iteration_index": iteration_index,
            "outcome": outcome,
            "outcome_reason": outcome_reason,
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": [],
            "property_verdicts": property_verdicts,
            "gold_cells": gold_cells_pre,
            "gate_cells": gate_cells_pre,
            "measured_delta_pct": (
                round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
                if gold_cells_pre and gate_cells_pre else None
            ),
        }

    combo_only = select_engine(sig) == "combo"
    if combo_only:
        from kairos.sec.closed_loop.yosys_equiv import verify_combo_equiv
        yosys_t0 = time.time()
        yeq = verify_combo_equiv(
            gold_path=gold_for_verify,
            gate_path=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            timeout_sec=timeout_sec,
        )
        elapsed = time.time() - yosys_t0
        bmc_result_data: dict[str, Any] = {
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "engine": yeq.method,
            "bound": 0,
            "elapsed_sec": elapsed,
        }
        property_verdicts = {
            "combo_equiv": "PROVED" if yeq.proved else ("REFUTED" if yeq.refuted else "INCONCLUSIVE"),
        }
        if yeq.proved:
            result_str = "PASS"
            diag_class = "yosys_combo_equiv"
            bmc_result_data["result"] = "PASS"
            bmc_result_data["detail"] = yeq.detail
        elif yeq.refuted:
            result_str = "FAIL"
            diag_class = "yosys_combo_refuted"
            bmc_result_data["result"] = "FAIL"
            bmc_result_data["detail"] = yeq.detail
        else:
            result_str = "INCONCLUSIVE"
            diag_class = "yosys_combo_inconclusive"
            bmc_result_data["result"] = "INCONCLUSIVE"
            bmc_result_data["detail"] = yeq.detail
        bmc_result_data["diagnostic_class"] = diag_class
        obs.emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)

        # EBMC 60s confirmatory cross-check (asabi directive: two
        # independent engines). yosys is primary, EBMC is confirmatory.
        ebmc_confirmatory = "not_run"
        if yeq.proved:
            try:
                ebmc_confirm = verify_sec(
                    gold_sv=gold_for_verify,
                    gate_v=gate_for_verify,
                    gold_module=gold_module,
                    gate_module=gate_module,
                    ports=ports,
                    mode="bmc",
                    bound=min(bound, 5),
                    clock_port="",
                    reset_port="",
                    reset_active_low=True,
                    timeout_sec=60,
                    work_dir=iter_bundle / "_sec_work",
                    dep_files=deps_for_verify,
                )
                if ebmc_confirm.proved:
                    ebmc_confirmatory = "PROVED"
                elif ebmc_confirm.refuted:
                    ebmc_confirmatory = "REFUTED"
                else:
                    ebmc_confirmatory = "INCONCLUSIVE"
            except Exception:  # noqa: BLE001
                ebmc_confirmatory = "timeout_or_error"
            property_verdicts["ebmc_confirmatory"] = ebmc_confirmatory
            # Emit EBMC confirmatory as a separate verify_attempt so the
            # dashboard shows both engines (yosys full proof + EBMC status)
            ebmc_result_mapped = {
                "PROVED": "PASS", "REFUTED": "FAIL",
            }.get(ebmc_confirmatory, "INCONCLUSIVE")
            obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "ebmc_bmc_confirmatory",
                "bound": min(bound, 5),
                "result": ebmc_result_mapped,
                "elapsed_sec": round(time.time() - yosys_t0, 2),
                "diagnostic_class": "combo_ebmc_confirmatory",
                "detail": f"EBMC 60s confirmatory on combo block: {ebmc_confirmatory}",
            })

        bridges_used: list[str] = []
        if result_str == "PASS":
            if ebmc_confirmatory == "REFUTED":
                outcome = "errored"
                outcome_reason = "ENGINE DISAGREEMENT: yosys PROVED but EBMC REFUTED — investigate before shipping"
            elif ebmc_confirmatory == "PROVED":
                outcome = "accepted"
                outcome_reason = f"yosys combo equiv proved ({yeq.proven_cells} cells, {yeq.method}) + EBMC PROVED"
            elif yeq.method == "yosys_dual_engine":
                outcome = "accepted"
                ebmc_note = f" + EBMC {ebmc_confirmatory}" if ebmc_confirmatory != "not_run" else ""
                outcome_reason = f"yosys dual-engine proved (equiv + SAT miter){ebmc_note}"
            else:
                outcome = "inconclusive"
                outcome_reason = (
                    f"yosys PROVED but EBMC did not confirm ({ebmc_confirmatory}). "
                    f"Multi-verifier gate requires 2 independent engines to agree. "
                    f"Try --timeout <longer> for EBMC confirmatory."
                )
        elif result_str == "FAIL":
            outcome = "inconclusive"
            outcome_reason = f"yosys combo equiv refuted: {yeq.detail}"
        else:
            outcome = "inconclusive"
            outcome_reason = f"yosys combo equiv inconclusive: {yeq.detail}"

        # ATH-1167: Record combo-path result into block memory
        try:
            from kairos.sec.closed_loop.block_memory import (
                record_refutation as _combo_rec_ref,
                record_success as _combo_rec_succ,
            )
            _combo_gold = str(inputs_dir / sig["gold_sv"]) if sig.get("gold_sv") else ""
            _combo_elapsed = elapsed if "elapsed" in dir() else 0.0
            if _combo_gold:
                if outcome == "accepted" and gold_cells_pre and gate_cells_pre:
                    _combo_rec_succ(
                        block_path=_combo_gold,
                        transformation_class=proposal.transformation_class.value,
                        measured_delta_pct=round(
                            (gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2
                        ),
                        gold_cells=gold_cells_pre,
                        gate_cells=gate_cells_pre,
                        engine="yosys_equiv",
                        elapsed_seconds=_combo_elapsed,
                    )
                elif outcome in ("inconclusive",):
                    _combo_rec_ref(
                        block_path=_combo_gold,
                        transformation_class=proposal.transformation_class.value,
                        claimed_delta_pct=proposal.claimed_area_delta_pct,
                        refutation_reason=outcome_reason[:200],
                        elapsed_seconds=_combo_elapsed,
                    )
        except Exception:  # noqa: BLE001
            pass

        return {
            "iteration_index": iteration_index,
            "outcome": outcome,
            "outcome_reason": outcome_reason,
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": bridges_used,
            "property_verdicts": property_verdicts,
            "gold_cells": gold_cells_pre,
            "gate_cells": gate_cells_pre,
            "measured_delta_pct": (
                round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
                if gold_cells_pre and gate_cells_pre else None
            ),
        }

    # Real BMC verify: catch all EBMC failure modes, including parse
    # errors from LLM-generated SV. The verifier IS the safety net.
    bmc_result_data: dict[str, Any] = {
        "iteration_index": iteration_index,
        "parent_run_id": parent_run_id,
        "engine": "ebmc_bmc",
        "bound": bound,
    }
    bmc_t0 = time.time()
    try:
        bmc_result = verify_sec(
            gold_sv=gold_for_verify,
            gate_v=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            ports=ports,
            mode="bmc",
            bound=bound,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=sig.get("reset_active_low", True),
            timeout_sec=timeout_sec,
            work_dir=iter_bundle / "_sec_work",
            dep_files=deps_for_verify,
        )
        miter_path_for_capture = iter_bundle / "_sec_work" / "miter.sv"
        if miter_path_for_capture.exists():
            reset_expr = (
                f"!{sig.get('reset_port', 'rst_n')}"
                if sig.get("reset_active_low", True)
                else sig.get("reset_port", "rst_n")
            )
            _capture_ebmc_subprocess(
                miter_path=miter_path_for_capture,
                gold_path=gold_for_verify,
                gate_path=gate_for_verify,
                work_dir=iter_bundle / "_sec_work",
                mode="bmc",
                bound=bound,
                top_module="sec_miter",
                reset_expr=reset_expr,
                timeout_sec=timeout_sec,
                label="bmc",
            )
            _capture_ebmc_subprocess(
                miter_path=miter_path_for_capture,
                gold_path=gold_for_verify,
                gate_path=gate_for_verify,
                work_dir=iter_bundle / "_sec_work",
                mode="k_induction",
                bound=bound,
                top_module="sec_miter",
                reset_expr=reset_expr,
                timeout_sec=timeout_sec,
                label="kinduction_bare",
            )
        elapsed = time.time() - bmc_t0
        # ATH-1102: outcome-from-result helper escalates per-property
        # REFUTE to FAIL even when bmc_result.refuted (whole-result
        # aggregate) is False, so the counterexample-feedback retry
        # loop (ATH-1086) fires on partial refutes.
        result_str, diag_class = _iteration_outcome_from_bmc_result(bmc_result)
        bmc_result_data["result"] = result_str
        bmc_result_data["diagnostic_class"] = diag_class
        bmc_result_data["elapsed_sec"] = elapsed
        property_verdicts = dict(bmc_result.property_verdicts)
    except Exception as e:  # noqa: BLE001
        elapsed = time.time() - bmc_t0
        # Classify the exception: setup-class (license/config) vs
        # verifier-unavailable (toolchain parse/exit error / not
        # installed). NEITHER is a real BMC counter-example. Per
        # platform PR #503 honest-framing catch + cluster meta-rule
        # instance #11 + customer-claim engine-cross-check meta-rule:
        # don't mislabel setup-class errors as bmc_counterexample.
        exc_name = type(e).__name__
        if exc_name in ("LicenseScopeError", "ConfigurationError"):
            result_str = "SETUP_ERROR"
            diag_class = "setup_error"
        elif exc_name in (
            "EbmcRunFailure",
            "EbmcRunTimeoutError",
            "FileNotFoundError",
            "PermissionError",
        ):
            result_str = "SETUP_ERROR"
            diag_class = "verifier_unavailable"
        else:
            result_str = "SETUP_ERROR"
            diag_class = "verifier_unavailable"
        bmc_result_data["result"] = result_str
        bmc_result_data["diagnostic_class"] = diag_class
        bmc_result_data["elapsed_sec"] = elapsed
        bmc_result_data["error"] = f"{exc_name}: {str(e)[:300]}"
        property_verdicts = {}
    obs.emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)

    # ATH-1144: Waveform analysis on BMC FAIL — deterministic, no LLM.
    # Extracts first divergent signal + cycle from EBMC counterexample
    # trace so the customer agent knows exactly what broke.
    if result_str == "FAIL":
        try:
            from kairos.sv.waveform import analyze_from_ebmc_result
            wf = analyze_from_ebmc_result(bmc_result)
            if wf.violations:
                v = wf.violations[0]
                bmc_result_data["first_divergent_signal"] = v.first_divergent_signal
                bmc_result_data["first_divergent_cycle"] = v.first_divergent_cycle
                bmc_result_data["signals_observed_count"] = len(wf.signals_observed)
                bmc_result_data["counterexample_summary"] = wf.format_human_readable()
                _vlog(
                    f"  [cex] First divergence: {v.first_divergent_signal} "
                    f"at cycle {v.first_divergent_cycle}"
                )
                # ATH-1144: LLM explanation of counterexample
                try:
                    from kairos.sv.counterexample import explain as _explain_cex
                    cex_explanation = _explain_cex(
                        ebmc_stdout=getattr(bmc_result, "stdout", "") or "",
                        ebmc_stderr=getattr(bmc_result, "stderr", "") or "",
                        counterexample=str(getattr(bmc_result, "counterexample", "") or ""),
                        spec_context=f"equivalence check: {sig.get('target_module', 'unknown')} gold vs gate",
                        timeout_sec=30,
                    )
                    if cex_explanation.explanation and cex_explanation.grounded:
                        bmc_result_data["counterexample_explanation"] = cex_explanation.explanation
                        _vlog(f"  [cex] Explanation: {cex_explanation.explanation[:150]}")
                except Exception:  # noqa: BLE001
                    pass
        except Exception:  # noqa: BLE001
            pass

    # Decide outcome from BMC result. PASS = accepted; FAIL = refuted;
    # SETUP_ERROR = errored (verifier didn't actually run); INCONCLUSIVE
    # = try k-induction with bridge invariant.
    bridges_used: list[str] = []
    if result_str == "PASS":
        outcome = "accepted"
        outcome_reason = "EBMC BMC verifier proved equivalence at bound k"
    elif result_str == "SETUP_ERROR":
        outcome = "errored"
        outcome_reason = (
            f"verifier did not run ({diag_class}): "
            f"{bmc_result_data.get('error', 'unknown')}"
        )
    else:
        # Initialize outcome/reason — the FAIL/INCONCLUSIVE escalation
        # paths below set these before falling through to the
        # iteration_verdict emit.
        outcome = "inconclusive"
        outcome_reason = "BMC FAIL/INCONCLUSIVE; escalation pending"
        # BMC FAIL or INCONCLUSIVE -> escalate to k-induction with
        # bridge invariant proposal. Per asabi 2026-05-06 Option B:
        # FAIL escalation is the propose-verify-ADJUST-re-verify arc
        # Todd asked for. Interface-preserving structural variants
        # often BMC-FAIL from non-reachable transient states; k-
        # induction with a bridge invariant tying gate's internal
        # state encoding to gold's typically closes them. Real-FAIL
        # (semantic divergence) stays refuted: generate_invariant
        # halts on hard_refute.
        if result_str == "FAIL":
            target_property = next(
                (p for p, v in property_verdicts.items() if v.lower() == "refuted"),
                "sec_miter.full_match",
            )
        else:  # INCONCLUSIVE
            target_property = next(
                (
                    p for p, v in property_verdicts.items()
                    if v.lower() == "inconclusive"
                ),
                "sec_miter.full_match",
            )

        # ATH-1086 — counterexample-feedback proposer retry loop on
        # BMC FAIL. When max_proposer_inner_retries > 0 AND BMC came
        # back REFUTED, ask the proposer to refine using the EBMC
        # counterexample BEFORE escalating to invariant_gen (which is
        # for INCONCLUSIVE — bridge invariants can't fix REFUTE).
        # On any retry that PASSES, set outcome=accepted + skip
        # invariant_gen. On retry exhaustion or non-PASS, fall through
        # to the existing INCONCLUSIVE-path invariant_gen escalation.
        # Default max_proposer_inner_retries=0 preserves prior behavior.
        proposer_inner_retry_history: list[dict[str, Any]] = []
        if (
            max_proposer_inner_retries > 0
            and result_str == "FAIL"
        ):
            from kairos.sec.closed_loop.refine_after_refutation import (
                CounterexampleFeedback,
                refine_proposal_after_refutation,
            )
            current_proposal = proposal
            # ATH-1103 — accumulate every prior REFUTED attempt's
            # feedback as the retry chain advances, so each subsequent
            # call to refine_proposal_after_refutation sees the FULL
            # history. This makes the retry non-amnesic: proposer
            # recognizes "I already tried THIS specific approach 2
            # attempts ago, switch strategies."
            cumulative_prior_attempts: list[CounterexampleFeedback] = []
            for retry_idx in range(max_proposer_inner_retries):
                cex_summary = (
                    str(getattr(bmc_result, "counterexample", "") or "")[:300]
                )
                feedback = CounterexampleFeedback(
                    refuted_class=current_proposal.transformation_class,
                    refuted_gate_sv=tmp_gate.read_text(),
                    counterexample_summary=cex_summary or "<no counterexample text>",
                    ebmc_log_path=str(bmc_result_data.get("subprocess_log_path") or ""),
                    refuted_at_property=target_property,
                    prior_attempt_index=retry_idx,
                    prior_attempts=tuple(cumulative_prior_attempts),
                )
                attempt_t0 = time.time()
                refined: Any
                try:
                    refined = refine_proposal_after_refutation(
                        bundle_path=inputs_dir,
                        target_module=gold_module,
                        feedback=feedback,
                        model=proposer_model,
                        max_proposals=1,
                        timeout_sec=proposer_timeout_sec,
                    )
                except Exception as e:  # noqa: BLE001
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "PARSE_ERROR",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": (
                            f"refine_proposal_after_refutation raised "
                            f"{type(e).__name__}: {str(e)[:200]}"
                        ),
                    })
                    break
                if refined.halt_reason != "ok" or not refined.proposals:
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "PARSE_ERROR",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": f"refine halt_reason={refined.halt_reason}",
                    })
                    break
                refined_proposal = refined.proposals[0]
                # Write refined gate to tmp_gate, re-elaborate, re-run BMC.
                try:
                    tmp_gate.write_text(refined_proposal.gate_sv)
                    # Re-elaborate the refined gate; re-build miter via
                    # verify_sec which handles miter generation internally.
                    if dep_files_iter:
                        from kairos.sec.preprocess import (
                            yosys_elaborate_to_verilog as _refined_elab,
                        )
                        new_gate_elab = _refined_elab(
                            rtl_path=tmp_gate,
                            top_module=gate_module,
                            dep_files=dep_files_iter,
                            output_path=elab_dir / "gate_elab.v",
                            log_dir=elab_dir,
                            timeout_sec=timeout_sec,
                            parameter_overrides=param_overrides or None,
                        )
                        retry_gate_for_verify = Path(new_gate_elab.elaborated_path)
                    else:
                        retry_gate_for_verify = tmp_gate
                    retry_t0 = time.time()
                    retry_bmc = verify_sec(
                        gold_sv=gold_for_verify,
                        gate_v=retry_gate_for_verify,
                        gold_module=gold_module,
                        gate_module=gate_module,
                        ports=ports,
                        mode="bmc",
                        bound=bound,
                        clock_port=sig.get("clock_port", "clk"),
                        reset_port=sig.get("reset_port", "rst_n"),
                        reset_active_low=sig.get("reset_active_low", True),
                        timeout_sec=timeout_sec,
                        work_dir=iter_bundle / "_sec_work",
                        dep_files=deps_for_verify,
                    )
                    retry_elapsed = time.time() - retry_t0
                    # ATH-1102: same property-level escalation on the
                    # retry-side verdict so successive retries keep
                    # firing as long as any property still refutes.
                    retry_str, _ = _iteration_outcome_from_bmc_result(retry_bmc)
                    property_verdicts = dict(retry_bmc.property_verdicts)
                    bmc_result = retry_bmc
                    gate_for_verify = retry_gate_for_verify
                except Exception as e:  # noqa: BLE001
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "EBMC_RUN_FAILURE",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": (
                            f"refined-gate retry raised {type(e).__name__}: "
                            f"{str(e)[:200]}"
                        ),
                    })
                    continue
                proposer_inner_retry_history.append({
                    "attempt_index": retry_idx,
                    "attempt_status": (
                        "PROVED" if retry_str == "PASS" else
                        "REFUTED" if retry_str == "FAIL" else
                        "INCONCLUSIVE"
                    ),
                    "elapsed_sec": retry_elapsed,
                    "transformation_class": (
                        refined_proposal.transformation_class.value
                    ),
                    "claimed_area_delta_pct": (
                        refined_proposal.claimed_area_delta_pct
                    ),
                })
                if retry_str == "PASS":
                    proposal = refined_proposal
                    result_str = "PASS"
                    outcome = "accepted"
                    outcome_reason = (
                        f"EBMC BMC verifier proved equivalence at bound k "
                        f"after {retry_idx + 1} counterexample-feedback "
                        f"retry attempt(s)"
                    )
                    break
                if retry_str == "INCONCLUSIVE":
                    result_str = "INCONCLUSIVE"
                    break
                # retry_str == "FAIL": continue retry loop. ATH-1103 —
                # snapshot this attempt's feedback into the cumulative
                # history BEFORE the next iteration, so retry_idx+1's
                # feedback carries every prior attempt including this
                # one.
                cumulative_prior_attempts.append(feedback)
                current_proposal = refined_proposal
            # End of retry loop. If outcome was set to "accepted" above,
            # skip the invariant_gen escalation. If retry loop exhausted
            # all attempts with FAIL still standing, fall through to
            # invariant_gen as the original code does (for completeness),
            # though invariant_gen typically halts on hard_refute.

        # CEGAR escalation — fires before invariant_gen when k-induction
        # is INCONCLUSIVE. CEGAR uses EBMC + LLM to propose assume
        # property hypotheses that close the refutation.
        if outcome != "accepted":
            try:
                from kairos.sv.cegar import cegar as run_cegar, CegarResult
                miter_path = iter_bundle / "_sec_work" / "miter.sv"
                if miter_path.is_file():
                    cegar_result = run_cegar(
                        spec=str(miter_path),
                        top_module="sec_miter",
                        bound=min(bound, 10),
                        max_iter=3,
                        budget_usd=2.0,
                        walltime_sec=min(timeout_sec, 300),
                        auto_accept_environmental=True,
                        clk=sig.get("clock_port", "clk"),
                        extra_files=[str(gold_for_verify), str(gate_for_verify)],
                    )
                    if cegar_result.terminated_reason == "proved":
                        outcome = "accepted"
                        outcome_reason = (
                            f"CEGAR closed proof after {cegar_result.iterations} "
                            f"iterations (${cegar_result.total_cost_usd:.2f})"
                        )
                        bridges_used.append("cegar_refinement")
            except Exception:  # noqa: BLE001
                pass  # CEGAR is best-effort escalation

        # Existing logic — only fires if CEGAR + counterexample-feedback
        # retry loop above didn't already accept the iteration.
        ig_result = None
        if outcome != "accepted":
            try:
                ig_result = generate_invariant(
                    bundle_path=iter_bundle,
                    target_property=target_property,
                    bound=bound,
                    timeout_sec=timeout_sec,
                )
            except Exception as e:  # noqa: BLE001
                outcome = "inconclusive"
                outcome_reason = (
                    f"Bridge-invariant generator raised "
                    f"{type(e).__name__} before producing a closeable "
                    f"candidate; verifier did not get a chance to discharge "
                    f"this iteration. Re-run may close it."
                )
        if ig_result is not None:
            for attempt in ig_result.attempts:
                obs.emit(
                    "bridge_invariant_proposed",
                    run_subtype="theorem_proving",
                    payload={
                        "iteration_index": iteration_index,
                        "parent_run_id": parent_run_id,
                        "bridge_label": attempt.candidate.label,
                        "bridge_text": attempt.candidate.sv_expression,
                        "proposer_model": proposer_model,
                        "lean_theorem_ref": attempt.candidate.proves_obligation,
                    },
                )
            kind_data: dict[str, Any] = {
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "ebmc_kinduction",
                "bound": bound,
                "result": "PASS" if ig_result.closed else "INCONCLUSIVE",
                "diagnostic_class": (
                    None if ig_result.closed else "kinduction_inconclusive"
                ),
                "elapsed_sec": 0.0,
            }
            obs.emit(
                "verify_attempt", run_subtype="theorem_proving", payload=kind_data,
            )
            if ig_result.closed and ig_result.chosen is not None:
                bridges_used.append(ig_result.chosen.label)
                outcome = "accepted"
                outcome_reason = (
                    f"k-induction PASS under assume-property bridge "
                    f"{ig_result.chosen.label} "
                    f"(BMC initial verdict: {result_str})"
                )
                # Lean formalization: discharge the bridge invariant
                # assumption via Lean type-check. The bridge is
                # ASSUMED by EBMC — Lean PROVES it holds, completing
                # the multi-layer defense-in-depth chain.
                try:
                    from kairos.sec.closed_loop._lean_formalize import (
                        formalize_witness,
                    )
                    lean_result = formalize_witness(
                        bridge_label=ig_result.chosen.label,
                        bridge_sv_expression=ig_result.chosen.sv_expression,
                        gold_module=gold_module,
                        gate_module=gate_module,
                    )
                    obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                        "iteration_index": iteration_index,
                        "parent_run_id": parent_run_id,
                        "engine": "lean_formalize",
                        "result": lean_result.kind,
                        "elapsed_sec": 0.0,
                    })
                    if lean_result.kind == "proof_axiom_clean":
                        outcome_reason += " + Lean proof discharged (axiom-clean)"
                except Exception:  # noqa: BLE001
                    pass  # Lean is best-effort enhancement
            elif ig_result.halt_reason == "hard_refute":
                outcome = "refuted"
                outcome_reason = (
                    f"k-induction hard_refute under bridge attempts: "
                    f"semantic divergence (BMC initial verdict: {result_str})"
                )
            else:
                outcome = "inconclusive"
                halt = ig_result.halt_reason or ""
                halt_lower = halt.lower()
                if any(
                    pat in halt_lower
                    for pat in (
                        "overloaded", "rate_limit", "rate-limit",
                        "ratelimiterror", "429", "503", "504",
                        "timeout", "timed out", "connection",
                    )
                ):
                    outcome_reason = (
                        "Bridge generation interrupted by transient LLM "
                        "provider availability; retry budget exhausted "
                        "without producing a closeable invariant. Re-run "
                        "may close this iteration accept-or-refute. "
                        f"(BMC initial verdict: {result_str})"
                    )
                elif "max_attempts" in halt_lower or "exhausted" in halt_lower:
                    outcome_reason = (
                        "Bridge proposer exhausted retry budget without "
                        "producing an invariant that closes k-induction. "
                        "The proposed transformation may be closeable "
                        "with a stronger bridge or a different proposer "
                        f"prompt. (BMC initial verdict: {result_str})"
                    )
                elif "parse_failure" in halt_lower or "parse failure" in halt_lower:
                    outcome_reason = (
                        "Bridge proposer LLM returned malformed JSON; "
                        "parser fail-closed without injecting an "
                        "invariant. Re-run may produce a parseable "
                        f"candidate. (BMC initial verdict: {result_str})"
                    )
                else:
                    halt_short = halt[:80] + ("..." if len(halt) > 80 else "")
                    outcome_reason = (
                        f"Bridge generation halted: {halt_short} "
                        f"(BMC initial verdict: {result_str})"
                    )

    # ACL2 algebraic discharge — final fallback when EBMC + invariant_gen
    # leave the iteration INCONCLUSIVE. ACL2's VL+FGL pipeline handles
    # algebraic equivalence that SAT-based methods can't scale to.
    if outcome == "inconclusive" and gold_for_verify.is_file() and gate_for_verify.is_file():
        try:
            from kairos.sec.closed_loop._acl2_discharge import acl2_discharge
            acl2_result = acl2_discharge(
                gold_sv=gold_for_verify,
                gate_v=gate_for_verify,
                gold_module=gold_module,
                gate_module=gate_module,
                timeout_sec=timeout_sec,
            )
            obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "acl2_discharge",
                "result": "PASS" if acl2_result.proved else "INCONCLUSIVE",
                "elapsed_sec": acl2_result.elapsed_sec,
            })
            if acl2_result.proved:
                outcome = "accepted"
                outcome_reason = (
                    "ACL2 algebraic discharge PROVED equivalence "
                    f"(EBMC was {result_str}, invariant_gen was inconclusive)"
                )
                bridges_used.append("acl2_algebraic_discharge")
        except Exception:  # noqa: BLE001
            pass  # ACL2 fallback is best-effort

    obs.emit(
        "iteration_verdict",
        run_subtype="theorem_proving",
        payload={
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "outcome": outcome,
            "outcome_reason": outcome_reason,
            "area_delta_pct": (
                proposal.claimed_area_delta_pct if outcome == "accepted" else None
            ),
            "bridges_used": bridges_used,
        },
    )

    # ATH-1167: Record iteration result into block memory so future runs
    # learn from this attempt. Refutations become "DO NOT REPEAT" rules;
    # successes reset the synthesis-floor counter.
    try:
        from kairos.sec.closed_loop.block_memory import (
            record_refutation,
            record_success,
        )
        gold_path_for_mem = str(inputs_dir / sig["gold_sv"]) if sig.get("gold_sv") else ""
        if gold_path_for_mem:
            iter_elapsed = elapsed if "elapsed" in dir() else 0.0
            if outcome == "accepted" and gold_cells_pre and gate_cells_pre:
                record_success(
                    block_path=gold_path_for_mem,
                    transformation_class=proposal.transformation_class.value,
                    measured_delta_pct=round(
                        (gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2
                    ),
                    gold_cells=gold_cells_pre,
                    gate_cells=gate_cells_pre,
                    engine="ebmc_bmc",
                    elapsed_seconds=iter_elapsed,
                )
            elif outcome in ("refuted", "inconclusive") and outcome != "errored":
                record_refutation(
                    block_path=gold_path_for_mem,
                    transformation_class=proposal.transformation_class.value,
                    claimed_delta_pct=proposal.claimed_area_delta_pct,
                    refutation_reason=outcome_reason[:200],
                    counterexample_summary=(
                        str(getattr(bmc_result, "counterexample", "") or "")[:200]
                        if "bmc_result" in dir() else ""
                    ),
                    elapsed_seconds=iter_elapsed,
                )
    except Exception:  # noqa: BLE001
        pass

    # Auto-capture: record optimization result to knowledge_entries
    try:
        from kairos.auto_capture import auto_capture_optimization_result, write_to_knowledge_entries
        _ac_outcome = "proved" if outcome == "accepted" else outcome
        record = auto_capture_optimization_result(
            block_name=sig.get("target_module", "unknown"),
            outcome=_ac_outcome,
            delta_pct=round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2) if gold_cells_pre and gate_cells_pre else None,
            engine="ebmc_bmc",
            run_id=parent_run_id,
            agent_id=os.environ.get("KAIROS_AGENT_ID", "unknown"),
        )
        write_to_knowledge_entries(record)
    except Exception:  # noqa: BLE001
        pass

    return {
        "iteration_index": iteration_index,
        "outcome": outcome,
        "outcome_reason": outcome_reason,
        "transformation_class": proposal.transformation_class.value,
        "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
        "bridges_used": bridges_used,
        "property_verdicts": property_verdicts,
        "gold_cells": gold_cells_pre,
        "gate_cells": gate_cells_pre,
        "measured_delta_pct": (
            round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
            if gold_cells_pre and gate_cells_pre else None
        ),
    }


from kairos.sec.closed_loop.measurement import (
    build_cert_payload as _build_cert_payload,
)


# ---------------------------------------------------------------------------
# Public entry point (ATH-1063 Phase 0a-wiring commit 2b).
#
# `run_closed_loop_orchestration` is the canonical library function that
# the v2.7 demo, MCP `kairos_optimize_block`, and any future cert-mint
# script call to drive the propose-verify-bridge-iterate arc end-to-end.
# Wraps proposer + per-iteration helper + halt-reason aggregation +
# cert-payload assembly + observe-event emission, returning a structured
# :class:`ClosedLoopResult` for the caller to render / serialize / ship.
#
# The function takes a bundle dir + target module + LLM model + bound +
# timeout knobs and emits the canonical event chain:
#
#   transformation_proposed (per proposal)
#       → verify_attempt (engine=ebmc_bmc)
#       → optional bridge_invariant_proposed (per bridge attempt)
#       → optional verify_attempt (engine=ebmc_kinduction)
#       → iteration_verdict (per proposal)
#   → iteration_complete (once per run)
#   → customer_block_certificate_complete (once per run)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ClosedLoopResult:
    """Public result of :func:`run_closed_loop_orchestration`.

    Attributes
    ----------
    parent_run_id:
        ``solve_runs.run_id`` for the orchestrator parent row that aggregates
        per-iteration child events. Caller surfaces this as the
        ``/analytics/silicon-blocks/<run_id>`` deeplink.
    halt_reason:
        Terminal halt reason as it lands on the
        ``iteration_complete.halt_reason`` event payload field. One of:

        * ``"proved_equivalent_variant_found"`` — at least one proposal
          closed under EBMC BMC or k-induction-with-bridge.
        * ``"no_proposal_closed"`` — proposer returned proposals but none
          closed.
        * ``"proposer_halt"`` — proposer aborted before producing any
          proposal (LLM rate-limit / parse-failure / empty response).
    iteration_summaries:
        Ordered per-iteration outcome dicts with keys ``iteration_index``,
        ``outcome``, ``outcome_reason``, ``transformation_class``,
        ``claimed_area_delta_pct``, ``bridges_used``, ``property_verdicts``.
    cert_payload:
        ``customer_block_certificate_complete`` event payload built by
        :func:`_build_cert_payload`. Caller may serialize this into the
        v2.7-style cert prose / cert tarball.
    proposer_halt_reason:
        Verbatim ``halt_reason`` from
        :class:`ProposerRun`. ``None`` on success;
        a concrete proposer-side halt class string when
        :attr:`halt_reason` is ``"proposer_halt"``.
    """

    parent_run_id: str
    halt_reason: str
    iteration_summaries: list[dict[str, Any]] = field(default_factory=list)
    cert_payload: dict[str, Any] = field(default_factory=dict)
    proposer_halt_reason: str | None = None
    proposer_halt_reason_class: str = ""

    def n_accepted(self) -> int:
        return sum(
            1 for s in self.iteration_summaries if s["outcome"] == "accepted"
        )

    def n_refuted(self) -> int:
        return sum(
            1 for s in self.iteration_summaries if s["outcome"] == "refuted"
        )

    def n_inconclusive(self) -> int:
        return sum(
            1 for s in self.iteration_summaries if s["outcome"] == "inconclusive"
        )

    def summary(self) -> str:
        """Customer-readable summary of the optimization result."""
        lines = []
        if self.halt_reason == "proved_equivalent_variant_found":
            accepted = [s for s in self.iteration_summaries if s["outcome"] == "accepted"]
            best = min(accepted, key=lambda s: s.get("measured_delta_pct", 0))
            delta = best.get("measured_delta_pct", "?")
            gold = best.get("gold_cells", "?")
            gate = best.get("gate_cells", "?")
            lines.append(f"PROVED: {delta}% area reduction ({gold} -> {gate} cells)")
            lines.append(f"{len(accepted)} proposal(s) formally verified equivalent.")
        elif self.halt_reason == "no_proposal_closed":
            n = len(self.iteration_summaries)
            lines.append(f"No verified optimization found ({n} proposals tried).")
            reasons_seen: set[str] = set()
            for s in self.iteration_summaries:
                reason = s.get("outcome_reason", "")
                if "structural_gate_rejected" in reason and "structural" not in reasons_seen:
                    lines.append("  Suggestion: proposals did not reduce area after synthesis.")
                    reasons_seen.add("structural")
                elif "toggle_power_gate_rejected" in reason and "power" not in reasons_seen:
                    lines.append("  Suggestion: area improved but dynamic power increased. Try with --allow-power-increase.")
                    reasons_seen.add("power")
                elif "timing" in reason.lower() and "timing" not in reasons_seen:
                    lines.append("  Suggestion: optimization violated timing constraints. Try a less aggressive transformation.")
                    reasons_seen.add("timing")
                elif ("yosys combo equiv inconclusive" in reason or "unproven cells" in reason) and "equiv" not in reasons_seen:
                    lines.append("  Suggestion: equivalence checker could not close proof. Try --timeout <longer>.")
                    reasons_seen.add("equiv")
                elif ("ebmc_timeout" in reason or "EBMC" in reason) and "ebmc" not in reasons_seen:
                    lines.append("  Suggestion: EBMC verification timed out (design may be too large for current bound). Try --timeout <longer> or --k-bound <higher>.")
                    reasons_seen.add("ebmc")
                elif ("gate_elaborate_failed" in reason or "SETUP_ERROR" in reason) and "elab" not in reasons_seen:
                    lines.append("  Suggestion: proposed RTL did not compile. Check for missing dependencies (--deps).")
                    reasons_seen.add("elab")
                elif ("REFUTED" in s.get("outcome", "").upper() or "refuted" in reason.lower()) and "refuted" not in reasons_seen:
                    lines.append("  Proposal was functionally incorrect (NOT equivalent to gold).")
                    lines.append("  The SAT miter found an input where gold and gate produce different outputs.")
                    lines.append("  Suggestions:")
                    lines.append("    - Try --proposer-mode diff (smaller, more conservative changes)")
                    lines.append("    - Try --proposer-mode preserve_datapath (locks output assignments)")
                    lines.append("    - Increase --max-proposals for more candidates (best-of-N)")
                    reasons_seen.add("refuted")
        elif self.halt_reason == "proposer_halt":
            reason = self.proposer_halt_reason or "unknown"
            if self.proposer_halt_reason_class == "auth":
                lines.append("Authentication failed.")
                lines.append("  For direct API: check ANTHROPIC_API_KEY")
                lines.append("  For Azure: check ANTHROPIC_API_KEY + ANTHROPIC_BASE_URL")
                lines.append("  For Bedrock: check AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION")
                lines.append("  Run 'kairos doctor' to diagnose.")
            elif "empty response" in reason:
                lines.append("LLM returned empty response. May be a transient issue; retry.")
            else:
                lines.append(f"Proposer failed: {reason[:200]}")
        else:
            lines.append(f"Optimization halted: {self.halt_reason}")
        return "\n".join(lines)

    def n_errored(self) -> int:
        return sum(
            1 for s in self.iteration_summaries if s["outcome"] == "errored"
        )


def run_closed_loop_orchestration(
    *,
    bundle_path: Path,
    target_module: str,
    block_name: str | None = None,
    model: str = DEFAULT_SEC_PROPOSER_MODEL,
    max_proposals: int = 3,
    k_induction_bound: int = 32,
    timeout_sec: int = 1800,
    proposer_timeout_sec: int = 360,
    max_proposer_inner_retries: int = 5,
    parallel_proposer_count: int = 1,
    parallel_proposer_models: tuple[str, ...] | None = None,
    proposer_mode: str = "preserve_datapath",
    proposer_backend: str = "litellm",
    n_enrichment_rounds: int = 1,
    mine_before_propose: bool = False,
    elaborate_gold: bool = False,
    work_dir: Path | None = None,
    repo_root: Path | None = None,
    fleet_agent_role: str = "qa",
    vertical: str = "silicon_block_sec",
    task_id: str | None = None,
    custom_engine: str | None = None,
) -> ClosedLoopResult:
    """Run the propose-verify-bridge-iterate arc end-to-end.

    Opens a :func:`kairos.observe.observe` context (parent ``solve_runs``
    row), calls the LLM proposer, drives the per-iteration arc via
    :func:`_emit_iteration_arc_for_proposal`, then emits
    ``iteration_complete`` + ``customer_block_certificate_complete``.

    Parameters
    ----------
    bundle_path:
        Path to the input bundle directory containing ``signature.json``,
        ``gold.sv``, and ``gate.v``. The proposer reads ``signature.json``
        for the optimization target context. Per-iteration bundles are
        written under ``work_dir`` (default: ``bundle_path / "_sec_work"``).
    target_module:
        Top-level RTL module name passed to the proposer + EBMC. Must match
        the ``gold_module`` field in ``signature.json``.
    block_name:
        Display name for the cert payload's ``block_name`` field. Defaults
        to ``target_module``.
    model:
        LLM model id for proposer + bridge-invariant generation. Default
        ``anthropic/claude-opus-4-6``.
    max_proposals:
        Number of candidate transformations to ask the proposer for.
        Default 3.
    k_induction_bound:
        EBMC BMC + k-induction bound. Default 32 per Aidan's k-bound fleet
        directive (push higher whenever possible — soundness signal scales
        with bound; cost is wrong axis).
    timeout_sec:
        Per-EBMC-mode wall-clock timeout in seconds. Default 120.
    proposer_timeout_sec:
        Wall-clock timeout for the LLM proposer call. Default 180.
    work_dir:
        Where per-iteration bundles + tmp gates land. Default
        ``bundle_path / "_sec_work"``.
    repo_root:
        Optional anchor for relative-path display in emitted event payloads.
        When ``None``, absolute paths are emitted.
    fleet_agent_role:
        ``solve_runs.fleet_agent_role`` field. Default ``"qa"``.
    vertical:
        ``solve_runs.vertical`` field. Default ``"silicon_block_sec"``.
    task_id:
        Optional ``solve_runs.task_id`` field. Defaults to
        ``f"closed_loop_{target_module}"``.

    Returns
    -------
    :class:`ClosedLoopResult` with the parent ``run_id`` + per-iteration
    summaries + cert payload.

    Raises
    ------
    FileNotFoundError:
        When ``bundle_path / "signature.json"`` is missing.
    """
    import sys

    import kairos.observe  # noqa: F401
    from kairos.sec.closed_loop import propose_transformations
    from kairos.sec.closed_loop.bundle_loader import (
        load_signature,
        detect_and_inject_pattern_invariants,
        elaborate_gold_to_verilog,
    )

    bundle_path = Path(bundle_path)
    sig = load_signature(bundle_path)
    work_dir_resolved = (
        Path(work_dir) if work_dir is not None else bundle_path / "_sec_work"
    )
    block_name_resolved = block_name if block_name is not None else target_module
    task_id_resolved = (
        task_id if task_id is not None else f"closed_loop_{target_module}"
    )

    detect_and_inject_pattern_invariants(sig, bundle_path)

    if elaborate_gold:
        elaborate_gold_to_verilog(sig, bundle_path, target_module, work_dir_resolved)

    obs_mod = sys.modules["kairos.observe"]

    # Enrichment outer loop: N rounds of mine → propose → verify.
    # Each round accumulates proved assertions for the next round's
    # proposer context. Default n_enrichment_rounds=1 preserves
    # single-pass behavior.
    best_result: ClosedLoopResult | None = None

    for enrichment_round in range(n_enrichment_rounds):
        # Mining pre-step (optional): mine structural assertions,
        # prove via EBMC Mode 1, enrich the proposer context.
        _mined_assumptions: list[str] = []
        if mine_before_propose:
            try:
                from kairos.sec.closed_loop.mine_assumptions import mine_assumptions
                mining = mine_assumptions(
                    bundle_path=bundle_path,
                    target_module=target_module,
                    model=model,
                    max_assertions=8,
                    k_bound=k_induction_bound,
                    timeout_sec=60,
                )
                _mined_assumptions = [a.sva_text for a in mining.proved]
                if _mined_assumptions:
                    sig["mined_assumptions"] = _mined_assumptions
                    _vlog(f"  [mining] {len(_mined_assumptions)} assumptions proved, injecting into proposer + verifier")
                    obs_mod.emit("assumption_mining_complete", run_subtype="theorem_proving", payload={
                        "n_mined": len(mining.proved) + len(mining.refuted) + len(mining.inconclusive),
                        "n_proved": len(mining.proved),
                        "n_applied": len(_mined_assumptions),
                        "assumptions": [a.sva_text for a in mining.proved],
                    })
            except Exception:  # noqa: BLE001
                pass  # Mining is best-effort

        with obs_mod.observe(
            run_subtype="theorem_proving",
            spawn_reason="closed_loop_orchestration",
            fleet_agent_role=fleet_agent_role,
            vertical=vertical,
            task_id=task_id_resolved,
        ) as ctx:
            run_id = ctx.run_id

            if not os.environ.get("ATHANOR_SYNC_TOKEN"):
                _vlog(
                    "  [warn] ATHANOR_SYNC_TOKEN not set — traces are local-only. "
                    "Set it to see results on the dashboard."
                )

            _vlog(f"=== Optimizing {target_module} ===")

            # ATH-1131: ABC deterministic optimization — try on ALL combo
            # blocks before the LLM proposer. ABC resyn2 finds algebraic
            # optimizations (XOR sharing, redundant logic, AIG rewriting)
            # with zero LLM cost and zero port mangling risk.
            from kairos.sec.closed_loop.verify_pipeline import select_engine
            engine_class = select_engine(sig)
            _vlog(f"  Engine class: {engine_class}")
            _abc_iteration = None
            if engine_class == "combo":
                _vlog("  Phase 1: ABC deterministic optimization...")
                try:
                    from kairos.sec.closed_loop.ecc_decompose import abc_optimize_any_block
                    abc_result = abc_optimize_any_block(
                        gold_path=bundle_path / sig["gold_sv"],
                        target_module=target_module,
                        dep_files=[bundle_path / d for d in sig.get("dep_files") or []],
                        timeout_sec=min(timeout_sec, 120),
                    )
                    if abc_result and abc_result.get("proved"):
                        _vlog(f"  ABC PROVED: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells ({abc_result.get('area_delta_pct')}%)")
                        obs_mod.emit("verify_attempt", run_subtype="theorem_proving", payload={
                            "iteration_index": 0,
                            "parent_run_id": run_id,
                            "engine": "abc_resyn2",
                            "result": "PASS",
                            "elapsed_sec": abc_result.get("elapsed_sec", 0),
                            "detail": f"ABC deterministic: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells",
                        })
                        _abc_iteration = {
                            "iteration_index": 0,
                            "outcome": "accepted",
                            "outcome_reason": f"ABC resyn2 PROVED equivalent: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells",
                            "transformation_class": "structural",
                            "claimed_area_delta_pct": abc_result.get("area_delta_pct", 0),
                            "measured_delta_pct": abc_result.get("area_delta_pct", 0),
                            "gold_cells": abc_result.get("gold_cells"),
                            "gate_cells": abc_result.get("gate_cells"),
                            "bridges_used": [],
                            "property_verdicts": {},
                        }
                except Exception:  # noqa: BLE001
                    pass  # ABC is best-effort, fall through to LLM proposer

            # Pre-proposer phase boundary: poll for hint messages and
            # inject into sig so prompt_composer picks them up.
            pre_msgs = _poll_agent_messages(run_id)
            hint_texts = [m.content for m in pre_msgs.get("hint", [])]
            if hint_texts:
                sig["proposer_hints"] = sig.get("proposer_hints", []) + hint_texts
                (bundle_path / "signature.json").write_text(
                    _json.dumps(sig, indent=2)
                )
                _vlog(f"  [hint] {len(hint_texts)} hint(s) injected into proposer context")

            # ATH-1168: Anti-forgetting gate. If block has past memories,
            # verify they were loaded into the prompt pipeline. Makes it
            # IMPOSSIBLE to skip memory — same pattern as session guard.
            try:
                from kairos.sec.closed_loop.block_memory import load_memory as _afg_load
                _afg_gold = str(bundle_path / sig["gold_sv"]) if sig.get("gold_sv") else ""
                if _afg_gold:
                    _afg_mem = _afg_load(_afg_gold)
                    _afg_total = len(_afg_mem.refutations) + len(_afg_mem.successes)
                    if _afg_total > 0:
                        _memory_context = _afg_mem.format_for_proposer()
                        _vlog(
                            f"  [memory] Block has {len(_afg_mem.refutations)} refutations, "
                            f"{len(_afg_mem.successes)} successes loaded. "
                            f"Floor confidence: {_afg_mem.synthesis_floor_confidence:.0%}"
                        )
                        if _afg_mem.is_at_floor():
                            _vlog(
                                f"  [memory] WARNING: Block at synthesis floor "
                                f"({_afg_mem.consecutive_refutations} consecutive refutations). "
                                f"Consider moving to a different block."
                            )
            except Exception:  # noqa: BLE001
                pass

            # ATH-1168: Reset memory flag before proposer — structural enforcement
            try:
                from kairos.sec.closed_loop.prompt_composer import reset_memory_flag
                reset_memory_flag()
            except Exception:  # noqa: BLE001
                pass

            # Zero-budget gate: max_proposals=0 means ABC-only, no LLM.
            if max_proposals == 0:
                _vlog("  Phase 2: SKIPPED (max_proposals=0, zero-cost mode)")
                from kairos.sec.closed_loop._proposer import ProposalRunResult
                proposal_run = ProposalRunResult(
                    target_module=target_module,
                    proposals=[],
                    halt_reason="zero_budget",
                )
            # ATH-1172: Claude subagent fleet — spawn N parallel Claude
            # subagents as proposers. Zero API key cost.
            elif proposer_backend == "claude-agent":
                from kairos.sec.closed_loop._proposer import (
                    ProposalRunResult,
                    TransformationProposal,
                    TransformationClass,
                )
                from kairos.sec.closed_loop.claude_proposer import (
                    claude_propose,
                    ProposerAuthenticationError,
                )
                from kairos.sec.closed_loop.prompt_composer import compose_system_prompt
                from concurrent.futures import ThreadPoolExecutor as _FleetTPE
                import contextvars as _fleet_ctx

                gold_text = (bundle_path / sig["gold_sv"]).read_text()
                # Claude subagent works best with focused prompts, not kitchen sink
                _is_seq = bool(sig.get("clock_port"))
                _seq_hint = "Sequential block. Try: encoding swap, pointer narrowing, register sharing." if _is_seq else ""
                system_prompt = f"Optimize this RTL for area reduction. {_seq_hint}"
                agent_configs = [
                    ("proposer-conservative", "Focus on safe, minimal optimizations. preserve_datapath mode."),
                    ("proposer-aggressive", "Maximize area reduction. Try bold restructuring."),
                    ("proposer-specialist", "Look for XOR sharing, arithmetic sharing, encoding swaps."),
                ][:max_proposals]

                _vlog(f"  Phase 2: Claude subagent fleet ({len(agent_configs)} agents, zero API cost)...")
                fleet_proposals: list[TransformationProposal] = []
                _fleet_auth_errors: list[str] = []

                def _fleet_propose(agent_id_hint):
                    aid, extra = agent_id_hint
                    raw = claude_propose(
                        gold_sv=gold_text, sig=sig,
                        max_proposals=1,
                        system_prompt=f"{system_prompt}\n\n## AGENT ROLE: {extra}",
                        timeout_sec=proposer_timeout_sec,
                    )
                    results = []
                    for r in raw:
                        try:
                            tc = TransformationClass(r.get("transformation_class", "structural"))
                        except ValueError:
                            tc = TransformationClass.STRUCTURAL
                        results.append(TransformationProposal(
                            target_module=target_module,
                            gate_sv=r["gate_sv"],
                            transformation_class=tc,
                            claimed_area_delta_pct=r.get("claimed_area_delta_pct", -5.0),
                            rationale=r.get("rationale", ""),
                        ))
                    return aid, results

                if len(agent_configs) == 1:
                    try:
                        aid, props = _fleet_propose(agent_configs[0])
                        _vlog(f"    [{aid}] returned {len(props)} proposal(s)")
                        for p in props:
                            fleet_proposals.append(p)
                            _vlog(f"    [{aid}] {p.transformation_class.value}: {p.claimed_area_delta_pct:+.1f}%")
                            obs_mod.emit("transformation_proposed", run_subtype="theorem_proving", payload={
                                "iteration_index": len(fleet_proposals) - 1,
                                "parent_run_id": run_id,
                                "agent_id": aid,
                                "transformation_class": p.transformation_class.value,
                                "claimed_area_delta_pct": p.claimed_area_delta_pct,
                            })
                    except ProposerAuthenticationError as e:
                        _fleet_auth_errors.append(str(e)[:300])
                        _vlog(f"    [fleet] agent AUTH ERROR: {e}")
                    except Exception as e:  # noqa: BLE001
                        _vlog(f"    [fleet] agent EXCEPTION: {type(e).__name__}: {str(e)[:200]}")
                else:
                    with _FleetTPE(max_workers=min(len(agent_configs), 3)) as pool:
                        futures = [
                            pool.submit(
                                _fleet_ctx.copy_context().run,
                                _fleet_propose, cfg,
                            )
                            for cfg in agent_configs
                        ]
                        for fut in futures:
                            try:
                                aid, props = fut.result(timeout=proposer_timeout_sec + 10)
                                for p in props:
                                    fleet_proposals.append(p)
                                    _vlog(f"    [{aid}] {p.transformation_class.value}: {p.claimed_area_delta_pct:+.1f}%")
                                    obs_mod.emit("transformation_proposed", run_subtype="theorem_proving", payload={
                                        "iteration_index": len(fleet_proposals) - 1,
                                        "parent_run_id": run_id,
                                        "agent_id": aid,
                                        "transformation_class": p.transformation_class.value,
                                        "claimed_area_delta_pct": p.claimed_area_delta_pct,
                                    })
                            except ProposerAuthenticationError as e:
                                _fleet_auth_errors.append(str(e)[:300])
                                _vlog(f"    [fleet] agent AUTH ERROR: {e}")
                            except Exception as e:  # noqa: BLE001
                                _vlog(f"    [fleet] agent failed: {e}")

                _vlog(f"  Fleet: {len(fleet_proposals)} proposals from {len(agent_configs)} agents")
                if _fleet_auth_errors and not fleet_proposals:
                    _fleet_halt = (
                        f"AuthenticationError: {_fleet_auth_errors[0]}"
                    )
                else:
                    _fleet_halt = (
                        "ok" if fleet_proposals else "fleet_no_proposals"
                    )
                proposal_run = ProposalRunResult(
                    target_module=target_module,
                    proposals=fleet_proposals,
                    halt_reason=_fleet_halt,
                    halt_reason_class="auth" if _fleet_auth_errors and not fleet_proposals else "",
                )
            # ATH-1104 — when parallel_proposer_count > 1, dispatch K
            # proposer calls in parallel across multiple model classes.
            elif parallel_proposer_count > 1:
                from kairos.sec.closed_loop.parallel_proposer import (
                    ParallelProposalResult,
                    propose_in_parallel,
                )
                parallel_run = propose_in_parallel(
                    bundle_path=bundle_path,
                    target_module=target_module,
                    K=parallel_proposer_count,
                    models=parallel_proposer_models,
                    timeout_sec=proposer_timeout_sec,
                    max_proposals_per_branch=max_proposals,
                )
                from kairos.sec.closed_loop._proposer import ProposalRunResult
                proposal_run = ProposalRunResult(
                    target_module=target_module,
                    proposals=list(parallel_run.proposals),
                    halt_reason=parallel_run.halt_reason,
                )
            else:
                _vlog(f"  Phase 2: LLM proposer ({model}, {max_proposals} proposals, mode={proposer_mode})...")
                proposal_run = propose_transformations(
                    bundle_path=bundle_path,
                    target_module=target_module,
                    model=model,
                    max_proposals=max_proposals,
                    timeout_sec=proposer_timeout_sec,
                    proposer_mode=proposer_mode,
                )
                _vlog(f"  Proposer: {len(proposal_run.proposals)} proposals, halt={proposal_run.halt_reason}")
                for i, p in enumerate(proposal_run.proposals):
                    _vlog(f"    [{i}] {p.transformation_class.value}: {p.claimed_area_delta_pct:+.1f}% claimed")

            # ATH-1168: Verify memory was loaded — structural rejection.
            # Single-proposer path: compose_system_prompt runs on main
            # thread, so was_memory_loaded() is reliable → ABORT on miss.
            # Parallel path: compose runs on worker threads, flag is
            # thread-local, main thread can't see it → EVENT only.
            try:
                from kairos.sec.closed_loop.prompt_composer import was_memory_loaded
                if _afg_total > 0 and not was_memory_loaded():
                    if parallel_proposer_count <= 1:
                        raise RuntimeError(
                            f"Memory gate rejection: block has {_afg_total} "
                            f"memory entries but prompt_composer did not load "
                            f"them. This is a code path bug — memory must be "
                            f"injected before proposer runs."
                        )
                    else:
                        _vlog(
                            f"  [memory] Parallel path — flag is thread-local, "
                            f"skipping abort (memory loaded on worker threads)"
                        )
            except NameError:
                pass  # _afg_total not set (gold_sv missing)
            except RuntimeError:
                raise  # re-raise the gate rejection
            except Exception:  # noqa: BLE001
                pass

            # Phase boundary: poll agent messages before verification
            phase_msgs = _poll_agent_messages(run_id)
            if any(m.content == "abort" for m in phase_msgs.get("control", [])):
                _vlog("  [control] Abort requested by customer agent")
                return ClosedLoopResult(
                    parent_run_id=run_id,
                    halt_reason="aborted",
                    iteration_summaries=[],
                    cert_payload={},
                )
            # Apply config overrides from agent messages
            for cfg_msg in phase_msgs.get("config", []):
                try:
                    overrides = _json.loads(cfg_msg.content)
                    if "timeout_sec" in overrides:
                        timeout_sec = int(overrides["timeout_sec"])
                        _vlog(f"  [config] timeout_sec -> {timeout_sec}")
                    if "k_induction_bound" in overrides:
                        k_induction_bound = int(overrides["k_induction_bound"])
                        _vlog(f"  [config] k_induction_bound -> {k_induction_bound}")
                except Exception:  # noqa: BLE001
                    pass

            if proposal_run.halt_reason != "ok" or not proposal_run.proposals:
                abc_summaries = [_abc_iteration] if _abc_iteration is not None else []
                halt = "abc_proved" if abc_summaries else "proposer_halt"
                cert_payload = _build_cert_payload(
                    parent_run_id=run_id,
                    block_name=block_name_resolved,
                    iteration_summaries=abc_summaries,
                    bundle_path=str(bundle_path),
                )
                obs_mod.emit(
                    "iteration_complete",
                    run_subtype="theorem_proving",
                    payload={
                        "iteration_index": -1,
                        "parent_run_id": run_id,
                        "halt_reason": halt,
                        "halt_reason_human": (
                            f"ABC deterministic optimization PROVED: "
                            f"{_abc_iteration.get('gold_cells')} -> {_abc_iteration.get('gate_cells')} cells "
                            f"({_abc_iteration.get('measured_delta_pct')}%)"
                        ) if abc_summaries else (
                            "kairos backend authentication failed — check API key "
                            "configuration. Run 'kairos doctor' to diagnose."
                            if proposal_run.is_auth_error
                            else (
                                f"The LLM proposer could not generate a valid optimization "
                                f"for this block ({proposal_run.halt_reason}). "
                                f"Try a different model or increase proposer_timeout_sec."
                            )
                        ),
                        "no_optimization_attempted": not abc_summaries,
                        "proposer_halt_reason": proposal_run.halt_reason,
                    },
                )
                ctx.mark_pipeline_outcome(
                    "abc_proved" if abc_summaries else "no_optimization_attempted",
                    reason=(
                        f"ABC PROVED: {_abc_iteration.get('measured_delta_pct')}% area reduction"
                        if abc_summaries else
                        f"Proposer did not produce proposals: {proposal_run.halt_reason}"
                    ),
                )
                return ClosedLoopResult(
                    parent_run_id=run_id,
                    halt_reason=halt,
                    iteration_summaries=abc_summaries,
                    cert_payload=cert_payload,
                    proposer_halt_reason=proposal_run.halt_reason,
                    proposer_halt_reason_class=proposal_run.halt_reason_class,
                )

            iteration_summaries: list[dict[str, Any]] = []
            if _abc_iteration is not None:
                iteration_summaries.append(_abc_iteration)
            import copy as _copy
            from concurrent.futures import ThreadPoolExecutor as _TPE, as_completed

            def _verify_one(i_proposal):
                i, proposal = i_proposal
                sig_copy = _copy.deepcopy(sig)
                return _emit_iteration_arc_for_proposal(
                    obs=obs_mod,
                    iteration_index=i,
                    proposal=proposal,
                    parent_run_id=run_id,
                    sig=sig_copy,
                    inputs_dir=bundle_path,
                    work_dir=work_dir_resolved,
                    bound=k_induction_bound,
                    timeout_sec=timeout_sec,
                    repo_root=repo_root,
                    max_proposer_inner_retries=max_proposer_inner_retries,
                    proposer_model=model,
                    proposer_timeout_sec=proposer_timeout_sec,
                    custom_engine=custom_engine,
                )

            n_proposals = len(proposal_run.proposals)
            if n_proposals > 1:
                import contextvars as _ctxvars
                def _verify_in_context(args):
                    return _ctxvars.copy_context().run(_verify_one, args)
                with _TPE(max_workers=min(n_proposals, 5)) as pool:
                    futures = {
                        pool.submit(_verify_in_context, (i, p)): i
                        for i, p in enumerate(proposal_run.proposals)
                    }
                    results_by_idx: dict[int, dict] = {}
                    for fut in as_completed(futures):
                        idx = futures[fut]
                        try:
                            results_by_idx[idx] = fut.result()
                        except Exception as e:  # noqa: BLE001
                            results_by_idx[idx] = {
                                "iteration_index": idx,
                                "outcome": "errored",
                                "outcome_reason": f"parallel_verify_error: {e}",
                                "transformation_class": "unknown",
                                "claimed_area_delta_pct": 0,
                                "bridges_used": [],
                                "property_verdicts": {},
                            }
                    iteration_summaries = [
                        results_by_idx[i] for i in range(n_proposals)
                    ]
                    _vlog("  Phase 3: Verification results:")
                    for s in iteration_summaries:
                        o = s.get("outcome", "?")
                        d = s.get("measured_delta_pct", s.get("claimed_area_delta_pct", "?"))
                        gc = s.get("gold_cells", "?")
                        gatec = s.get("gate_cells", "?")
                        _vlog(f"    [{s.get('iteration_index', '?')}] {o}: {d}% ({gc}->{gatec})")
            else:
                for i, proposal in enumerate(proposal_run.proposals):
                    iteration_summaries.append(_verify_one((i, proposal)))
    
            if any(s["outcome"] == "accepted" for s in iteration_summaries):
                halt = "proved_equivalent_variant_found"
            else:
                halt = "no_proposal_closed"
    
            _HALT_HUMAN: dict[str, str] = {
                "proved_equivalent_variant_found": (
                    "Found a verified-equivalent optimization with area reduction."
                ),
                "no_proposal_closed": (
                    "All proposals were tried but none passed formal equivalence "
                    "verification. The block may already be near-optimal, or try "
                    "a different proposer model or increase max_proposals."
                ),
                "max_iterations": (
                    "Iteration cap reached before finding a verified optimization. "
                    "Increase max_proposals in kairos.yaml to explore more candidates."
                ),
            }
            obs_mod.emit(
                "iteration_complete",
                run_subtype="theorem_proving",
                payload={
                    "iteration_index": len(iteration_summaries) - 1,
                    "parent_run_id": run_id,
                    "halt_reason": halt,
                    "halt_reason_human": _HALT_HUMAN.get(halt, halt),
                },
            )
    
            bundle_display = (
                str(bundle_path.relative_to(repo_root))
                if repo_root is not None and _is_subpath(bundle_path, repo_root)
                else str(bundle_path)
            )
            cert_payload = _build_cert_payload(
                parent_run_id=run_id,
                block_name=block_name_resolved,
                iteration_summaries=iteration_summaries,
                bundle_path=bundle_display,
            )
            # ATH-1101 — auto-emit cert tarball + stamp tarball metadata
            # onto the cert_payload BEFORE emitting the event. Customer
            # dashboard reads cert_tarball_path / sha256 / size_bytes /
            # format_version from the event payload to surface a
            # "Download cert tarball" button + SHA-256 verification chip.
            # Best-effort: tarball-build failures don't crash the fire —
            # cert_payload still emits without the tarball metadata so
            # the event payload always lands.
            try:
                from kairos.sec.closed_loop.cert_tarball import (
                    CERT_TARBALL_FORMAT_VERSION,
                    build_cert_tarball,
                )
                tarball_path = work_dir_resolved / f"{block_name_resolved}_kairos_cert.tar.gz"
                sec_work_root = bundle_path / "_sec_work"
                if sec_work_root.is_dir():
                    build_cert_tarball(
                        cert_payload=cert_payload,
                        bundle_path=bundle_path,
                        sec_work_dir=sec_work_root,
                        output_path=tarball_path,
                        iteration_count=cert_payload["total_properties"],
                    )
                    cert_payload["cert_tarball_path"] = str(tarball_path)
                    cert_payload["cert_tarball_sha256"] = _sha256_of_file(tarball_path)
                    cert_payload["cert_tarball_size_bytes"] = tarball_path.stat().st_size
                    cert_payload["cert_tarball_format_version"] = (
                        CERT_TARBALL_FORMAT_VERSION
                    )
            except Exception:  # noqa: BLE001
                # Cert tarball build is best-effort. Honest-framing: if
                # the tarball can't be built (missing inputs, IP-leak gate
                # fired, etc), the cert_payload still emits without
                # cert_tarball_* fields. Customer UI reads the absence as
                # "no tarball available" and falls back gracefully.
                pass
    
            n_proved = sum(1 for s in iteration_summaries if s["outcome"] == "accepted")
            if n_proved > 0:
                obs_mod.emit(
                    "customer_block_certificate_complete",
                    run_subtype="theorem_proving",
                    payload=cert_payload,
                )

            this_result = ClosedLoopResult(
                parent_run_id=run_id,
                halt_reason=halt,
                iteration_summaries=iteration_summaries,
                cert_payload=cert_payload,
                proposer_halt_reason=None,
            )
    
            # Save result permanently (ATH-1110 prevention)
            try:
                from kairos.sec.closed_loop.result_store import save_result
                for idx, s in enumerate(iteration_summaries):
                    if s.get("outcome") == "accepted":
                        gate_path = work_dir_resolved / f"iter_{idx}_bundle" / "gate.v"
                        if not gate_path.is_file():
                            gate_path = work_dir_resolved / "iter_0_bundle" / "gate.v"
                        if gate_path.is_file():
                            gold_elab = work_dir_resolved / "_gold_elab" / "gold_elab.v"
                            has_params = bool(sig.get("parameters"))
                            if gold_elab.is_file():
                                gold_sv_path = gold_elab
                            elif has_params:
                                # ATH-1115 sub-1: NEVER measure raw
                                # parameterized gold. The -76.4% fake
                                # result came from measuring gold with
                                # default params vs gate with concrete
                                # params. If we have parameters but no
                                # elaborated gold, skip measurement
                                # rather than produce a wrong number.
                                gold_sv_path = None
                            else:
                                gold_sv_path = bundle_path / sig.get("gold_sv", "")
                            gate_elab = work_dir_resolved / f"iter_{idx}_bundle" / "_elab" / "gate_elab.v"
                            gate_measure = gate_elab if gate_elab.is_file() else gate_path
                            if gold_sv_path is None:
                                gold_cells = 0
                                gate_cells = 0
                            else:
                                gold_cells = _measure_synthesis(
                                    gold_sv_path, target_module,
                                ) or 0
                                gate_cells = _measure_synthesis(
                                    gate_measure, f"{target_module}_gate",
                                ) or 0
                            if gold_cells > 0:
                                measured_delta = round(
                                    (gate_cells - gold_cells) / gold_cells * 100, 2,
                                )
                            else:
                                measured_delta = s.get("claimed_area_delta_pct", 0)

                            toggle_result = _measure_toggle_power(
                                gold_path=gold_sv_path,
                                gate_path=gate_path,
                                gold_module=target_module,
                                gate_module=f"{target_module}_gate",
                                sig=sig,
                                work_dir=work_dir_resolved,
                            )

                            save_result(
                                block_name=block_name_resolved,
                                gate_sv=gate_path.read_text(),
                                gold_cells=gold_cells,
                                gate_cells=gate_cells,
                                measured_delta_pct=measured_delta,
                                verified=True,
                                model=model,
                                transformation_class=s.get("transformation_class", ""),
                                rationale=_json.dumps(toggle_result) if toggle_result else "",
                            )
            except Exception:  # noqa: BLE001
                pass

            # Track best across enrichment rounds
            if best_result is None:
                best_result = this_result
            elif halt == "proved_equivalent_variant_found":
                best_result = this_result
    
            # If this round found a proved variant, we're done
            if halt == "proved_equivalent_variant_found":
                break
    
    return best_result or this_result


from kairos.sec.closed_loop.measurement import (
    measure_synthesis as _measure_synthesis,
    measure_toggle_power as _measure_toggle_power,
    sha256_of_file as _sha256_of_file,
    is_subpath as _is_subpath,
)
