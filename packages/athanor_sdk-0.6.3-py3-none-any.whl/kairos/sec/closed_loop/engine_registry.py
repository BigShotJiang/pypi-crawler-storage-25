"""MCP tool plugin registry for verification + measurement engines.

Customers register their own engines (JasperGold, Synopsys DC, etc.)
alongside kairos built-in engines (yosys, EBMC). The orchestrator
calls engines through the registry, not hardcoded imports.

Built-in engines are pre-registered. Customer engines load from
flow_config.yaml custom_engines section.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Protocol


class VerifyEngine(Protocol):
    """Interface for verification engines."""
    def verify(
        self, gold_path: Path, gate_path: Path,
        gold_module: str, gate_module: str,
        timeout_sec: int,
    ) -> dict[str, Any]:
        """Returns dict with keys: proved (bool), refuted (bool), detail (str)."""
        ...


class MeasureEngine(Protocol):
    """Interface for measurement engines."""
    def measure(self, design_path: Path, module_name: str) -> dict[str, Any]:
        """Returns dict with keys: cells (int), detail (str)."""
        ...


class ProposerStrategy(Protocol):
    """Interface for custom proposer strategies.

    Customers implement this to add domain-specific optimization
    patterns (e.g. a team that knows their ECC encoding can propose
    XOR-tree restructurings that preserve the generator matrix).
    """
    def propose(
        self, gold_sv: str, sig: dict[str, Any],
        max_proposals: int,
    ) -> list[dict[str, Any]]:
        """Returns list of dicts with keys: gate_sv, transformation_class,
        claimed_area_delta_pct, rationale."""
        ...


@dataclass
class RegisteredEngine:
    """One registered engine with metadata."""
    name: str
    engine_type: str  # "verify" or "measure"
    provider: str  # "builtin" or "customer"
    callable: Callable
    description: str = ""


class EngineRegistry:
    """Registry of verification + measurement engines.

    Built-in engines registered at import time. Customer engines
    registered from flow_config.yaml at runtime.
    """

    def __init__(self) -> None:
        self._engines: dict[str, RegisteredEngine] = {}
        self._register_builtins()

    def _register_builtins(self) -> None:
        self.register(
            name="yosys_equiv",
            engine_type="verify",
            provider="builtin",
            callable=_builtin_yosys_equiv,
            description="yosys structural equivalence (combo, full proof)",
        )
        self.register(
            name="yosys_sat_miter",
            engine_type="verify",
            provider="builtin",
            callable=_builtin_yosys_sat,
            description="yosys SAT miter (combo, full proof)",
        )
        self.register(
            name="ebmc_bmc",
            engine_type="verify",
            provider="builtin",
            callable=_builtin_ebmc_bmc,
            description="EBMC bounded model check (sequential)",
        )
        self.register(
            name="yosys_synth",
            engine_type="measure",
            provider="builtin",
            callable=_builtin_yosys_synth,
            description="yosys synthesis cell count",
        )
        self.register(
            name="iverilog_toggle",
            engine_type="measure",
            provider="builtin",
            callable=_builtin_iverilog_toggle,
            description="iverilog VCD toggle-activity power",
        )

    def register(
        self, *, name: str, engine_type: str,
        provider: str, callable: Callable,
        description: str = "",
    ) -> None:
        if engine_type not in ("verify", "measure", "propose"):
            raise ValueError(f"engine_type must be 'verify', 'measure', or 'propose', got '{engine_type}'")
        self._engines[name] = RegisteredEngine(
            name=name, engine_type=engine_type,
            provider=provider, callable=callable,
            description=description,
        )

    def get(self, name: str) -> RegisteredEngine | None:
        return self._engines.get(name)

    def list_engines(self, engine_type: str | None = None) -> list[RegisteredEngine]:
        engines = list(self._engines.values())
        if engine_type:
            engines = [e for e in engines if e.engine_type == engine_type]
        return engines

    def verify_engines(self) -> list[str]:
        return [e.name for e in self.list_engines("verify")]

    def measure_engines(self) -> list[str]:
        return [e.name for e in self.list_engines("measure")]


# Built-in engine callables (thin wrappers around existing modules)

def _builtin_yosys_equiv(
    gold_path: Path, gate_path: Path,
    gold_module: str, gate_module: str,
    timeout_sec: int = 120,
) -> dict[str, Any]:
    from kairos.sec.closed_loop.yosys_equiv import verify_combo_equiv
    r = verify_combo_equiv(
        gold_path=gold_path, gate_path=gate_path,
        gold_module=gold_module, gate_module=gate_module,
        timeout_sec=timeout_sec,
    )
    return {"proved": r.proved, "refuted": r.refuted, "detail": r.detail}


def _builtin_yosys_sat(
    gold_path: Path, gate_path: Path,
    gold_module: str, gate_module: str,
    timeout_sec: int = 120,
) -> dict[str, Any]:
    from kairos.sec.closed_loop.yosys_equiv import verify_combo_equiv
    r = verify_combo_equiv(
        gold_path=gold_path, gate_path=gate_path,
        gold_module=gold_module, gate_module=gate_module,
        timeout_sec=timeout_sec,
    )
    return {"proved": r.proved, "refuted": r.refuted, "detail": r.detail}


def _builtin_ebmc_bmc(
    gold_path: Path, gate_path: Path,
    gold_module: str, gate_module: str,
    timeout_sec: int = 120,
) -> dict[str, Any]:
    return {"proved": False, "refuted": False, "detail": "EBMC requires full adapter setup"}


def _builtin_yosys_synth(
    design_path: Path, module_name: str,
) -> dict[str, Any]:
    from kairos.sec.closed_loop.measurement import measure_synthesis
    cells = measure_synthesis(design_path, module_name)
    return {"cells": cells, "detail": f"yosys synth: {cells} cells"}


def _builtin_iverilog_toggle(
    design_path: Path, module_name: str,
) -> dict[str, Any]:
    return {"cells": None, "detail": "toggle measurement requires gold+gate pair"}


# Module-level singleton
_default_registry: EngineRegistry | None = None


def get_registry() -> EngineRegistry:
    global _default_registry
    if _default_registry is None:
        _default_registry = EngineRegistry()
    return _default_registry


def register_engine(
    name: str,
    engine: VerifyEngine | MeasureEngine | ProposerStrategy,
    *,
    engine_type: str | None = None,
    description: str = "",
) -> None:
    """Customer-facing API: register a custom engine.

    Usage::

        from kairos import register_engine

        class MyFormalTool:
            def verify(self, gold_path, gate_path, gold_module, gate_module, timeout_sec):
                # ... run your tool ...
                return {"proved": True, "refuted": False, "detail": "my_tool proved"}

        register_engine("my_formal_tool", MyFormalTool())

    Then: ``kairos optimize --engine my_formal_tool``
    """
    if engine_type is None:
        if hasattr(engine, "verify"):
            engine_type = "verify"
        elif hasattr(engine, "measure"):
            engine_type = "measure"
        elif hasattr(engine, "propose"):
            engine_type = "propose"
        else:
            raise TypeError(
                f"Cannot detect engine_type for {type(engine).__name__}. "
                f"Implement verify(), measure(), or propose(), or pass engine_type explicitly."
            )
    reg = get_registry()
    reg.register(
        name=name,
        engine_type=engine_type,
        provider="customer",
        callable=engine.verify if engine_type == "verify"
                 else engine.measure if engine_type == "measure"
                 else engine.propose,
        description=description or f"Customer engine: {name}",
    )


__all__ = [
    "EngineRegistry",
    "RegisteredEngine",
    "VerifyEngine",
    "MeasureEngine",
    "ProposerStrategy",
    "get_registry",
    "register_engine",
]
