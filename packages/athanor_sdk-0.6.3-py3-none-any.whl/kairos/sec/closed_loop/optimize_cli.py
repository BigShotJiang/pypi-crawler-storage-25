"""ATH-1115 sub-4: one-command fire CLI for customer agents.

Usage:
    kairos optimize --rtl AP_ALU_US.sv --deps AP_MUX_US.v --params DATA_WIDTH=8

Auto-detects clock/reset ports, auto-elaborates, auto-selects
verification engine (combo vs sequential). Builds the bundle,
runs the orchestrator, reports results.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any


def auto_detect_clock_reset(rtl_text: str) -> tuple[str, str, bool]:
    """Detect clock and reset ports from RTL source.

    Two-tier detection:
    1. Port declarations: input [wire|logic|reg] <name> matching clock/reset patterns
    2. Always blocks: posedge/negedge usage (definitive for sequential)

    Returns (clock_port, reset_port, reset_active_low).
    """
    clock_port = ""
    reset_port = ""
    reset_active_low = True

    _CLK_NAMES = re.compile(r"\b(\w*clk\w*|\w*clock\w*|aclk|pclk|hclk|fclk)\b", re.IGNORECASE)
    _RST_NAMES = {
        "reset_n": True, "rst_n": True, "rstn": True, "areset_n": True,
        "reset": False, "rst": False, "areset": False,
    }

    for line in rtl_text.splitlines():
        low = line.strip().lower()
        if re.search(r"\binput\b", low):
            m = _CLK_NAMES.search(low)
            if m and not clock_port:
                clock_port = m.group(1)
            for name, active_low in _RST_NAMES.items():
                if re.search(rf"\b{name}\b", low):
                    reset_port = name
                    reset_active_low = active_low
                    break

        m_posedge = re.search(r"posedge\s+(\w+)", low)
        if m_posedge:
            sig = m_posedge.group(1)
            if _CLK_NAMES.match(sig) and not clock_port:
                clock_port = sig

        m_negedge = re.search(r"negedge\s+(\w+)", low)
        if m_negedge:
            sig = m_negedge.group(1)
            if sig in _RST_NAMES:
                reset_port = sig
                reset_active_low = _RST_NAMES[sig]

    return clock_port, reset_port, reset_active_low


def auto_extract_module_name(rtl_text: str) -> str | None:
    """Extract the first module name from RTL source."""
    for line in rtl_text.splitlines():
        m = re.match(r"\s*module\s+(\w+)", line)
        if m:
            return m.group(1)
    return None


def auto_extract_params(rtl_text: str) -> dict[str, int]:
    """Extract parameter names and default values."""
    params = {}
    for m in re.finditer(r"parameter\s+(\w+)\s*=\s*(\d+)", rtl_text):
        params[m.group(1)] = int(m.group(2))
    return params


def build_bundle_from_rtl(
    *,
    rtl_path: str | Path,
    dep_paths: list[str | Path] | None = None,
    param_overrides: dict[str, int] | None = None,
    output_dir: str | Path | None = None,
) -> Path:
    """Build a kairos SEC bundle from raw RTL files.

    This is the customer-facing entry point. Auto-detects everything
    the orchestrator needs: module name, ports, clock/reset, parameters.
    """
    rtl = Path(rtl_path).resolve()
    if not rtl.is_file():
        raise FileNotFoundError(f"RTL file not found: {rtl}")

    rtl_text = rtl.read_text()

    # Bundle cache: skip rebuild if RTL content unchanged (only when no explicit output_dir)
    import hashlib as _hl
    _content_hash = _hl.sha256(rtl_text.encode()).hexdigest()[:16]
    _cache_dir = Path(tempfile.gettempdir()) / f"kairos_bundle_cache_{_content_hash}"
    if output_dir is None and _cache_dir.is_dir() and (_cache_dir / "signature.json").is_file():
        return _cache_dir

    module_name = auto_extract_module_name(rtl_text)
    if not module_name:
        raise ValueError(
            f"No module declaration found in {rtl}. "
            f"Ensure the file contains 'module <name>(...);' "
            f"(Verilog-2001 or SystemVerilog)."
        )

    clock_port, reset_port, reset_active_low = auto_detect_clock_reset(rtl_text)

    default_params = auto_extract_params(rtl_text)
    concrete_params = {**default_params, **(param_overrides or {})}
    if not param_overrides:
        for k, v in list(concrete_params.items()):
            if isinstance(v, int) and v > 64:
                concrete_params[k] = 16

    if output_dir is None:
        output_dir = _cache_dir
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    inputs_dir = output_dir / "inputs"
    inputs_dir.mkdir(exist_ok=True)
    gold_dest = inputs_dir / rtl.name
    gold_dest.write_text(rtl_text)

    dep_list = []
    for dep in (dep_paths or []):
        dp = Path(dep).resolve()
        if dp.is_file():
            dest = inputs_dir / dp.name
            dest.write_text(dp.read_text())
            dep_list.append(f"inputs/{dp.name}")

    yosys_bin = shutil.which("yosys")
    ports: list[dict[str, Any]] = []
    if yosys_bin:
        rtl_files = [str(gold_dest)]
        inc_dirs: set[str] = set()
        for d in dep_list:
            fp = inputs_dir / Path(d).name
            if fp.suffix in (".inc", ".vh", ".svh"):
                inc_dirs.add(str(fp.parent))
            else:
                rtl_files.append(str(fp))
        inc_flags = " ".join(f"-I{d}" for d in sorted(inc_dirs))
        chparam = ""
        if concrete_params:
            pstr = " ".join(f"-set {k} {v}" for k, v in concrete_params.items())
            chparam = f"chparam {pstr} {module_name}; "
        json_out = output_dir / "_yosys_ports.json"
        r = subprocess.run(
            [yosys_bin, "-p",
             f"read_verilog -sv {inc_flags} {' '.join(rtl_files)}; "
             f"{chparam}"
             f"hierarchy -check -top {module_name}; "
             f"proc; opt; write_json {json_out}"],
            capture_output=True, text=True, timeout=30,
        )
        if r.returncode == 0 and json_out.is_file():
            data = json.loads(json_out.read_text())
            mod_data = data.get("modules", {}).get(module_name, {})
            ports = [
                {"name": pn, "direction": pi["direction"],
                 "width": len(pi["bits"])}
                for pn, pi in mod_data.get("ports", {}).items()
            ]

    sig = {
        "target_module": module_name,
        "gold_module": module_name,
        "gate_module": f"{module_name}_gate",
        "gold_sv": f"inputs/{rtl.name}",
        "dep_files": dep_list,
        "ports": ports,
        "parameters": [
            {"name": k, "default": v, "concrete_for_sec": v}
            for k, v in concrete_params.items()
        ],
        "clock_port": clock_port,
        "reset_port": reset_port,
        "reset_active_low": reset_active_low,
        "formal_invariants_primer": [],
        "proposer_hints": [],
    }
    (output_dir / "signature.json").write_text(json.dumps(sig, indent=2))
    return output_dir


def optimize(
    *,
    rtl_path: str | Path,
    dep_paths: list[str | Path] | None = None,
    param_overrides: dict[str, int] | None = None,
    config_path: str | Path | None = None,
    model: str | None = None,
    max_proposals: int | None = None,
    timeout_sec: int | None = None,
    engine: str | None = None,
    proposer_mode: str | None = None,
    proposer_backend: str = "litellm",
    preset: str | None = None,
    **config_overrides: Any,
) -> Any:
    """One-command optimization: build bundle + run orchestrator.

    Requires paid license with 'solve' product access.

    Args:
        engine: Custom verification engine name (registered via
            ``kairos.register_engine``). If None, uses the default
            engine selection (yosys for combo, EBMC for sequential).
        proposer_mode: Proposer mode override ('full', 'diff',
            'preserve_datapath'). If None, uses flow_config default.

    Customer configures behavior via kairos.yaml or keyword args.
    Every parameter has a safe default with structural validation.
    """
    from kairos.sec.closed_loop.flow_config import load_flow_config, load_preset
    # abc_only (max_cost_usd=0) uses only local yosys/ABC — no LLM,
    # no paid features. Skip license check for zero-cost evaluation.
    _skip_license = False
    if preset:
        _pre_config = load_preset(preset)
        if _pre_config.max_cost_usd == 0:
            _skip_license = True
    if not _skip_license:
        from kairos.license_scope import require_product
        require_product("solve")
    from kairos.sec.closed_loop.flow_guard import validate_flow
    if preset and not config_path:
        config = load_preset(preset, **config_overrides)
    else:
        config = load_flow_config(config_path=config_path, **config_overrides)

    advice = validate_flow(config)
    if not advice.valid:
        raise ValueError(
            f"Flow rejected by safety guard: {'; '.join(advice.errors)}. "
            f"Suggestions: {'; '.join(advice.suggestions)}"
        )

    bundle = build_bundle_from_rtl(
        rtl_path=rtl_path,
        dep_paths=dep_paths,
        param_overrides=param_overrides,
    )
    module_name = auto_extract_module_name(Path(rtl_path).read_text())
    if not module_name:
        raise ValueError(
            f"Could not extract a module name from {rtl_path}. "
            f"Ensure the file contains a valid Verilog/SystemVerilog "
            f"'module <name>' declaration."
        )

    from kairos.sec.closed_loop._orchestrator import run_closed_loop_orchestration
    effective_proposals = max_proposals or config.max_proposals
    if config.max_cost_usd == 0:
        effective_proposals = 0
    return run_closed_loop_orchestration(
        bundle_path=bundle,
        target_module=module_name,
        model=model or config.models[0],
        elaborate_gold=config.elaborate_gold,
        max_proposals=effective_proposals,
        max_proposer_inner_retries=config.max_inner_retries,
        k_induction_bound=config.k_induction_bound,
        timeout_sec=timeout_sec or config.verification_timeout_sec or 1800,
        proposer_timeout_sec=config.proposer_timeout_sec,
        proposer_mode=proposer_mode or config.proposer_mode,
        proposer_backend=proposer_backend,
        mine_before_propose=config.mine_before_propose,
        custom_engine=engine,
    )


__all__ = [
    "auto_detect_clock_reset",
    "auto_extract_module_name",
    "auto_extract_params",
    "build_bundle_from_rtl",
    "optimize",
]
