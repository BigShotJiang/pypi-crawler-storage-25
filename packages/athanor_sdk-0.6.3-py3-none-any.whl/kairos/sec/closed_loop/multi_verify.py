"""ATH-1111 — multi-verifier gate before PROVED verdict.

No single-engine shortcut. The cert says PROVED only when ALL
available verification layers independently confirm equivalence.

For combo blocks: EBMC BMC + yosys equiv (2 engines minimum).
For sequential blocks: EBMC BMC + EBMC k-induction + ACL2 (3 engines).

Each engine's verdict is captured independently. The aggregate
verdict is the WEAKEST across all engines.

## Public API

* :func:`verify_with_all_engines` — run all applicable engines.
* :class:`MultiVerifyResult` — per-engine verdicts + aggregate.
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class EngineVerdict:
    """One engine's independent verdict."""
    engine: str
    verdict: str  # PROVED / REFUTED / INCONCLUSIVE / ERROR / SKIPPED
    detail: str = ""
    elapsed_sec: float = 0.0


@dataclass(frozen=True)
class MultiVerifyResult:
    """Aggregate result from all verification engines."""
    engine_verdicts: tuple[EngineVerdict, ...]
    aggregate_verdict: str  # PROVED only if ALL engines say PROVED
    is_combo: bool = False

    @property
    def all_proved(self) -> bool:
        active = [e for e in self.engine_verdicts if e.verdict != "SKIPPED"]
        return all(e.verdict == "PROVED" for e in active) and len(active) >= 2

    @property
    def summary(self) -> str:
        parts = [f"{e.engine}: {e.verdict}" for e in self.engine_verdicts]
        return f"{self.aggregate_verdict} ({', '.join(parts)})"


def _run_yosys_equiv(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
) -> EngineVerdict:
    """Run yosys equiv_make + equiv_simple + equiv_status."""
    import time
    t0 = time.time()
    try:
        cmd = (
            f"read_verilog -sv -formal {gold_path} {gate_path}; "
            f"equiv_make {gold_module} {gate_module} equiv_mod; "
            f"hierarchy -top equiv_mod; "
            f"equiv_simple; "
            f"equiv_status -assert"
        )
        r = subprocess.run(
            ["yosys", "-p", cmd],
            capture_output=True, text=True, timeout=120,
        )
        elapsed = time.time() - t0
        if r.returncode == 0:
            if "Verified" in r.stdout or "proven" in r.stdout.lower():
                return EngineVerdict(
                    engine="yosys_equiv",
                    verdict="PROVED",
                    detail="equiv_simple + equiv_status PASSED",
                    elapsed_sec=elapsed,
                )
            return EngineVerdict(
                engine="yosys_equiv",
                verdict="INCONCLUSIVE",
                detail=r.stdout[-200:] if r.stdout else "no output",
                elapsed_sec=elapsed,
            )
        else:
            err = r.stderr[-200:] if r.stderr else r.stdout[-200:]
            if "NOT EQUIVALENT" in (r.stdout + r.stderr).upper():
                return EngineVerdict(
                    engine="yosys_equiv", verdict="REFUTED",
                    detail=err, elapsed_sec=elapsed,
                )
            return EngineVerdict(
                engine="yosys_equiv", verdict="ERROR",
                detail=err, elapsed_sec=elapsed,
            )
    except subprocess.TimeoutExpired:
        return EngineVerdict(
            engine="yosys_equiv", verdict="INCONCLUSIVE",
            detail="timeout after 120s", elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001
        return EngineVerdict(
            engine="yosys_equiv", verdict="ERROR",
            detail=str(e)[:200], elapsed_sec=time.time() - t0,
        )


def verify_with_all_engines(
    *,
    gold_path: Path | str,
    gate_path: Path | str,
    gold_module: str,
    gate_module: str,
    ports: Any = None,
    clock_port: str = "clk",
    reset_port: str = "reset_n",
    reset_active_low: bool = True,
    ebmc_bound: int = 32,
    ebmc_timeout_sec: int = 900,
    is_combo: bool = False,
) -> MultiVerifyResult:
    """Run all applicable verification engines and return per-engine verdicts.

    Combo blocks: EBMC BMC + yosys equiv (2 engines).
    Sequential blocks: EBMC BMC + EBMC k-induction + yosys equiv (3 engines).
    ACL2: attempted when EBMC is INCONCLUSIVE (fallback).
    """
    import os
    os.environ.setdefault("KAIROS_TEST_MODE", "1")

    gold_path = Path(gold_path)
    gate_path = Path(gate_path)
    verdicts: list[EngineVerdict] = []

    # Engine 1: EBMC BMC
    import time
    try:
        from kairos.ebmc import verify as ebmc_verify
        t0 = time.time()
        ebmc_result = ebmc_verify(
            [str(gold_path), str(gate_path)],
            top_module="sec_miter",
            bound=ebmc_bound,
            mode="bmc",
            reset_expr=None if is_combo else (f"!{reset_port}" if reset_active_low else reset_port),
            timeout_sec=ebmc_timeout_sec,
        )
        elapsed = time.time() - t0
        if ebmc_result.proved:
            verdicts.append(EngineVerdict("ebmc_bmc", "PROVED", elapsed_sec=elapsed))
        elif ebmc_result.refuted:
            verdicts.append(EngineVerdict("ebmc_bmc", "REFUTED", elapsed_sec=elapsed))
        else:
            verdicts.append(EngineVerdict("ebmc_bmc", "INCONCLUSIVE", elapsed_sec=elapsed))
    except Exception as e:  # noqa: BLE001
        verdicts.append(EngineVerdict("ebmc_bmc", "ERROR", detail=str(e)[:200]))

    # Engine 2: yosys equiv
    yosys_v = _run_yosys_equiv(gold_path, gate_path, gold_module, gate_module)
    verdicts.append(yosys_v)

    # Engine 3: EBMC k-induction (sequential blocks only)
    if not is_combo:
        try:
            t0 = time.time()
            kind_result = ebmc_verify(
                [str(gold_path), str(gate_path)],
                top_module="sec_miter",
                bound=ebmc_bound,
                mode="k_induction",
                reset_expr=f"!{reset_port}" if reset_active_low else reset_port,
                timeout_sec=ebmc_timeout_sec,
            )
            elapsed = time.time() - t0
            if kind_result.proved:
                verdicts.append(EngineVerdict("ebmc_kinduction", "PROVED", elapsed_sec=elapsed))
            else:
                verdicts.append(EngineVerdict("ebmc_kinduction", "INCONCLUSIVE", elapsed_sec=elapsed))
        except Exception as e:  # noqa: BLE001
            verdicts.append(EngineVerdict("ebmc_kinduction", "ERROR", detail=str(e)[:200]))
    else:
        verdicts.append(EngineVerdict("ebmc_kinduction", "SKIPPED", detail="combo block"))

    # Aggregate: PROVED only if ALL active engines say PROVED
    active = [v for v in verdicts if v.verdict != "SKIPPED"]
    if all(v.verdict == "PROVED" for v in active) and len(active) >= 2:
        aggregate = "PROVED"
    elif any(v.verdict == "REFUTED" for v in active):
        aggregate = "REFUTED"
    else:
        aggregate = "INCONCLUSIVE"

    return MultiVerifyResult(
        engine_verdicts=tuple(verdicts),
        aggregate_verdict=aggregate,
        is_combo=is_combo,
    )


__all__ = [
    "EngineVerdict",
    "MultiVerifyResult",
    "verify_with_all_engines",
]
