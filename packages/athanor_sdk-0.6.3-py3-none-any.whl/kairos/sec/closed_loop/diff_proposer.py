"""ATH-1107 — diff-mode proposer (line-diffs against gold, not rewrites).

2026-05-07 dogfood validated: every model class rewrites the entire
module body including data-read-path logic the optimization doesn't
need to touch, introducing encoding mismatches that survive all retry
+ prompt strategies. The fix: constrain the proposer to emit unified
diffs instead of full gate bodies. Lines outside the diff stay
IDENTICAL to gold by construction.

## Why this closes dout_y_match

Most area optimizations (dead-logic removal, constant-prop, width-
reduction, comparison-narrowing) affect CONTROL-PATH logic: full/empty
detection, pointer arithmetic, guard conditions. The DATA-PATH
(mem read → fifo_dout_y) stays identical to gold in a diff-mode
proposal because the proposer has no reason to touch it. 5/5 PROVED
by construction: control-path changes verified correct (proposer
already handles 4/5 at baseline), data-path preserved by identity.

## Public API

* :func:`apply_diff` — parse a unified diff + apply to gold text.
* :func:`build_diff_mode_system_prompt` — system prompt addendum
  that constrains the proposer to emit diffs.
* :func:`build_diff_mode_user_prompt` — user prompt with gold source
  + diff-emit instructions.
* :data:`DIFF_MODE_SYSTEM_ADDENDUM` — the constraint block.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


DIFF_MODE_SYSTEM_ADDENDUM = """\

## DIFF MODE — CRITICAL CONSTRAINT

You are modifying an EXISTING module, not writing a new one from scratch.

Output a unified diff showing ONLY the lines you change:

```diff
--- gold
+++ gate
@@ -<start>,<count> +<start>,<count> @@
 <context line (unchanged)>
-<removed line from gold>
+<replacement line for gate>
 <context line (unchanged)>
```

Rules:
1. Everything NOT in your diff stays IDENTICAL to the gold source.
2. Do NOT touch lines unrelated to your optimization.
3. Do NOT rewrite data-path read logic (e.g. fifo_dout_y assignment,
   memory read expressions) unless your optimization specifically
   targets that path. Most area optimizations only affect control-path
   logic — full/empty detection, pointer arithmetic, guard conditions.
4. Include at least 2 lines of unchanged context around each hunk so
   the diff can be applied unambiguously.
5. The module declaration line and endmodule line must NOT appear in
   your diff — they stay identical to gold.
6. After your diff block, include the standard JSON proposals block
   with transformation_class, rationale, claimed_area_delta_pct.
   Set gate_sv to the literal string "DIFF_MODE" — the orchestrator
   applies your diff to produce the actual gate_sv.
"""


@dataclass(frozen=True)
class DiffHunk:
    """One hunk from a parsed unified diff."""

    gold_start: int
    gold_count: int
    gate_start: int
    gate_count: int
    lines: tuple[str, ...]


class DiffParseError(ValueError):
    """Raised when the LLM's diff output can't be parsed."""


class DiffApplyError(ValueError):
    """Raised when a parsed diff can't be applied to the gold text."""


_HUNK_HEADER_RE = re.compile(
    r"^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@"
)


def parse_unified_diff(diff_text: str) -> list[DiffHunk]:
    """Parse a unified diff into a list of DiffHunk.

    Accepts standard unified diff format with ``---``/``+++`` header
    lines (optional — LLMs sometimes omit them) and ``@@`` hunk
    headers. Context lines (space-prefixed), removed lines
    (``-``-prefixed), and added lines (``+``-prefixed) are preserved.

    Raises :class:`DiffParseError` if no hunks found or a hunk header
    is malformed.
    """
    lines = diff_text.splitlines()
    hunks: list[DiffHunk] = []
    current_lines: list[str] = []
    current_header: tuple[int, int, int, int] | None = None

    def _flush() -> None:
        nonlocal current_header, current_lines
        if current_header is not None and current_lines:
            hunks.append(DiffHunk(
                gold_start=current_header[0],
                gold_count=current_header[1],
                gate_start=current_header[2],
                gate_count=current_header[3],
                lines=tuple(current_lines),
            ))
        current_lines = []
        current_header = None

    for line in lines:
        if line.startswith("---") or line.startswith("+++"):
            continue
        m = _HUNK_HEADER_RE.match(line)
        if m:
            _flush()
            current_header = (
                int(m.group(1)),
                int(m.group(2) or "1"),
                int(m.group(3)),
                int(m.group(4) or "1"),
            )
            continue
        if current_header is not None:
            if line.startswith((" ", "-", "+")):
                current_lines.append(line)
            elif line.strip() == "":
                current_lines.append(" ")
    _flush()

    if not hunks:
        raise DiffParseError(
            "no hunks found in diff output — expected at least one "
            "@@ hunk header"
        )
    return hunks


def apply_diff(gold_text: str, diff_text: str) -> str:
    """Apply a unified diff to gold_text, returning the patched gate text.

    The diff is parsed via :func:`parse_unified_diff`, then each hunk
    is applied in reverse order (last hunk first) so line-number
    offsets from earlier hunks don't invalidate later hunks' positions.

    Raises :class:`DiffApplyError` if a hunk's context lines don't
    match the gold text at the specified position (fuzzy ±2 line
    tolerance for LLM off-by-one).
    """
    hunks = parse_unified_diff(diff_text)
    gold_lines = gold_text.splitlines(keepends=True)
    # Apply in reverse so earlier hunks don't shift later positions.
    for hunk in reversed(hunks):
        start = hunk.gold_start - 1  # 1-indexed → 0-indexed
        # Build the removed and added line lists from the hunk.
        removed: list[str] = []
        added: list[str] = []
        for line in hunk.lines:
            if line.startswith("-"):
                removed.append(line[1:])
            elif line.startswith("+"):
                added.append(line[1:])
            elif line.startswith(" "):
                removed.append(line[1:])
                added.append(line[1:])

        # Context-match verification with ±2 line fuzzy tolerance.
        best_offset = 0
        best_score = -1
        for offset in range(-2, 3):
            pos = start + offset
            if pos < 0 or pos + len(removed) > len(gold_lines):
                continue
            score = sum(
                1 for r, g in zip(removed, gold_lines[pos:pos + len(removed)])
                if r.strip() == g.strip()
            )
            if score > best_score:
                best_score = score
                best_offset = offset
        actual_start = start + best_offset
        if best_score < len(removed) * 0.5 and len(removed) > 0:
            raise DiffApplyError(
                f"hunk at gold line {hunk.gold_start} doesn't match "
                f"gold text (best context-match score "
                f"{best_score}/{len(removed)} at offset {best_offset})"
            )
        # Replace the removed lines with added lines.
        added_with_newlines = [
            (l + "\n" if not l.endswith("\n") else l) for l in added
        ]
        gold_lines[actual_start:actual_start + len(removed)] = added_with_newlines

    return "".join(gold_lines)


def extract_diff_from_response(response_text: str) -> str | None:
    """Extract the fenced diff block from an LLM response.

    Looks for ```diff ... ``` fencing. Returns the content between
    fences, or None if no diff block found.
    """
    m = re.search(r"```diff\s*\n(.*?)```", response_text, re.DOTALL)
    if m:
        return m.group(1)
    m = re.search(r"```\s*\n(---.*?)```", response_text, re.DOTALL)
    if m:
        return m.group(1)
    return None


__all__ = [
    "DIFF_MODE_SYSTEM_ADDENDUM",
    "DiffApplyError",
    "DiffHunk",
    "DiffParseError",
    "apply_diff",
    "extract_diff_from_response",
    "parse_unified_diff",
]
