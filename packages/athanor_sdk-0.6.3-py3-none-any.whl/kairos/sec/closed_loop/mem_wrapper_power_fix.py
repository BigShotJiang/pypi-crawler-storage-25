"""ATH-1117 deliverable 3: fleet-wide mem_wrapper power fix.

Scans wrapper RTL files for ungated bus pass-through patterns
(ADDR/WDATA/BWE assigned directly without chip-enable gating).
Generates the AND-gated fix for each instance.

The fix: AND-gate each output bus with the chip-enable signal (req/CE/ME)
so the bus doesn't toggle when the memory is idle. 26.6% ADDR toggle
reduction measured on swrp_port at 50% idle duty.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True)
class UngatedBus:
    """One ungated bus pass-through found in a wrapper file."""
    file_path: str
    line_number: int
    original_line: str
    bus_name: str
    source_signal: str
    width_expr: str


@dataclass(frozen=True)
class PowerFix:
    """A proposed AND-gate fix for an ungated bus."""
    bus: UngatedBus
    enable_signal: str
    fixed_line: str


def scan_for_ungated_buses(rtl_dir: Path) -> list[UngatedBus]:
    """Scan a directory tree for ungated bus pass-through patterns."""
    results = []
    for rtl_file in sorted(rtl_dir.rglob("*.v")):
        _scan_file(rtl_file, results)
    for rtl_file in sorted(rtl_dir.rglob("*.sv")):
        _scan_file(rtl_file, results)
    return results


def _scan_file(rtl_file: Path, results: list[UngatedBus]) -> None:
    """Scan one file for ungated assign patterns."""
    text = rtl_file.read_text()
    for i, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        # Pattern: assign ADDR[W-1:0] = addr[W-1:0];
        # or: assign WDATA = wdata;
        # or: assign BWE = bwe;
        m = re.match(
            r"assign\s+(\w+)"
            r"(\[[\w\-:]+\])?"
            r"\s*=\s*"
            r"(\w+)"
            r"(\[[\w\-:]+\])?"
            r"\s*;",
            stripped,
        )
        if not m:
            continue
        bus_name = m.group(1).upper()
        source = m.group(3)
        width = m.group(2) or ""
        if bus_name in ("ADDR", "WDATA", "BWE", "WE", "DIN", "DATA_IN"):
            # Check this isn't already gated (contains & or ?)
            if "&" not in stripped and "?" not in stripped:
                results.append(UngatedBus(
                    file_path=str(rtl_file),
                    line_number=i,
                    original_line=stripped,
                    bus_name=bus_name,
                    source_signal=source,
                    width_expr=width,
                ))


def find_enable_signal(rtl_text: str) -> str | None:
    """Find the chip-enable signal in a wrapper file."""
    for pattern in [
        r"input\s+.*\b(req)\b",
        r"input\s+.*\b(CE)\b",
        r"input\s+.*\b(ME)\b",
        r"input\s+.*\b(ce)\b",
        r"input\s+.*\b(me)\b",
        r"input\s+.*\b(chip_en)\b",
        r"input\s+.*\b(ren|wen)\b",
    ]:
        m = re.search(pattern, rtl_text)
        if m:
            return m.group(1)
    return None


def generate_fix(bus: UngatedBus, enable_signal: str) -> PowerFix:
    """Generate the AND-gated fix for one ungated bus."""
    width = bus.width_expr
    if width:
        # Check parameterized width first ([PARAM-1:0])
        m_param = re.search(r"\[(\w+)-1:0\]", width)
        n = re.match(r"\[(\d+):0\]", width)
        if m_param and not m_param.group(1).isdigit():
            gate_expr = f"{{{m_param.group(1)}{{{enable_signal}}}}}"
        elif n:
            w = int(n.group(1)) + 1
            gate_expr = f"{{{w}{{{enable_signal}}}}}"
        else:
            gate_expr = f"{{{enable_signal}}}"
        gated = (
            f"assign {bus.bus_name}{width} = "
            f"{bus.source_signal}{width} & {gate_expr};"
        )
    else:
        gated = (
            f"assign {bus.bus_name} = "
            f"{bus.source_signal} & {enable_signal};"
        )
    return PowerFix(
        bus=bus,
        enable_signal=enable_signal,
        fixed_line=gated,
    )


def generate_fixes_for_directory(rtl_dir: Path) -> list[PowerFix]:
    """Scan directory and generate fixes for all ungated buses."""
    buses = scan_for_ungated_buses(rtl_dir)
    fixes = []
    for bus in buses:
        rtl_text = Path(bus.file_path).read_text()
        enable = find_enable_signal(rtl_text)
        if enable:
            fixes.append(generate_fix(bus, enable))
    return fixes


def apply_fix(fix: PowerFix) -> str:
    """Apply a fix to the source file, returning the modified text."""
    path = Path(fix.bus.file_path)
    text = path.read_text()
    return text.replace(fix.bus.original_line, fix.fixed_line)


__all__ = [
    "UngatedBus",
    "PowerFix",
    "scan_for_ungated_buses",
    "find_enable_signal",
    "generate_fix",
    "generate_fixes_for_directory",
    "apply_fix",
]
