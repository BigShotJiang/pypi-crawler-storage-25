"""ATH-1117: FIFO encoding swap optimizer.

Generates a binary-encoded FIFO gate from a one-hot-encoded gold,
with bridge invariants that prove the encoding swap preserves
behavior. This is the impl_swap optimization class.

The bridge invariant maps one-hot state to binary:
  binary_ptr = $clog2(onehot_ptr)
  onehot_valid[i] iff binary_ptr == i

EBMC k-induction proves the swap under this mapping.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def detect_fifo_encoding(gold_sv: str, sig: dict[str, Any]) -> dict[str, Any]:
    """Detect if a FIFO uses one-hot pointers that could be binary.

    Returns analysis dict with encoding info and swap recommendation.
    """
    module = sig.get("target_module", "")
    params = {p["name"]: p.get("concrete_for_sec", p.get("default"))
              for p in sig.get("parameters", [])}
    depth = params.get("FIFO_DEPTH", params.get("DEPTH", 0))

    if not depth or depth < 4:
        return {"swap_recommended": False, "reason": "depth too small"}

    # Detect one-hot pointer patterns (reg or wire, numeric or parameterized width)
    onehot_ptrs = []
    seen = set()
    for m in re.finditer(
        r"(?:reg|wire)\s+\[([^]]+):0\]\s+(\w*(?:ptr|pointer)\w*)", gold_sv,
    ):
        width_expr = m.group(1).strip()
        name = m.group(2)
        if name in seen:
            continue
        seen.add(name)

        # Check if width matches DEPTH (numeric or parameterized)
        try:
            width = int(width_expr) + 1
            if width == depth:
                onehot_ptrs.append({"name": name, "width": width})
        except ValueError:
            if "FIFO_DEPTH" in width_expr or "DEPTH" in width_expr:
                onehot_ptrs.append({"name": name, "width": depth})

    # Also detect the rotate pattern {ptr[N-2:0], ptr[N-1]} (one-hot increment)
    if not onehot_ptrs:
        for m in re.finditer(
            r"\{(\w+)\[.*?:0\]\s*,\s*\1\[.*?\]\}", gold_sv,
        ):
            name = m.group(1)
            if "ptr" in name.lower() and name not in seen:
                seen.add(name)
                onehot_ptrs.append({"name": name, "width": depth})

    if not onehot_ptrs:
        return {"swap_recommended": False, "reason": "no one-hot pointers detected"}

    binary_width = (depth - 1).bit_length()
    cells_saved_estimate = sum(
        p["width"] - binary_width for p in onehot_ptrs
    )

    return {
        "swap_recommended": True,
        "encoding": "one_hot",
        "target_encoding": "binary",
        "depth": depth,
        "onehot_pointers": onehot_ptrs,
        "onehot_width": depth,
        "binary_width": binary_width,
        "estimated_cells_saved": cells_saved_estimate,
        "bridge_invariant": _generate_bridge_invariant(onehot_ptrs, depth),
    }


def _generate_bridge_invariant(
    ptrs: list[dict[str, Any]], depth: int,
) -> str:
    """Generate SVA bridge invariant for one-hot to binary encoding swap."""
    binary_width = (depth - 1).bit_length()
    lines = []
    for p in ptrs:
        name = p["name"]
        lines.append(
            f"// Bridge invariant: {name} one-hot maps to binary\n"
            f"// $onehot({name}) && (binary_{name} == $clog2({name}))"
        )
    return "\n".join(lines)


def generate_binary_fifo_gate(
    gold_sv: str,
    sig: dict[str, Any],
    analysis: dict[str, Any],
) -> str | None:
    """Generate a binary-encoded FIFO gate from one-hot gold.

    Returns gate RTL string or None if swap is not applicable.
    """
    if not analysis.get("swap_recommended"):
        return None

    module = sig.get("target_module", "")
    gate_module = sig.get("gate_module", f"{module}_gate")
    depth = analysis["depth"]
    binary_width = analysis["binary_width"]

    # Extract the module header (ports preserved exactly)
    header_match = re.search(
        r"(module\s+" + re.escape(module) + r".*?\);)",
        gold_sv, re.DOTALL,
    )
    if not header_match:
        return None

    header = header_match.group(1).replace(
        f"module {module}", f"module {gate_module}", 1,
    )

    # Replace one-hot pointer declarations with binary
    body = gold_sv[header_match.end():]
    endmod = body.rfind("endmodule")
    if endmod < 0:
        return None
    body = body[:endmod]

    for ptr in analysis["onehot_pointers"]:
        name = ptr["name"]
        old_width = ptr["width"]
        body = re.sub(
            rf"reg\s+\[{old_width - 1}:0\]\s+{re.escape(name)}",
            f"reg [{binary_width - 1}:0] {name}",
            body,
        )
        # Replace one-hot increment (ptr <= {ptr[N-2:0], ptr[N-1]})
        # with binary increment (ptr <= ptr + 1)
        body = re.sub(
            rf"{re.escape(name)}\s*<=\s*\{{" + r".*?\}",
            f"{name} <= {name} + 1",
            body,
        )
        # Replace one-hot reset (ptr <= N'b1 or {DEPTH{1'b0}})
        body = re.sub(
            rf"{re.escape(name)}\s*<=\s*\d+'b0*1\s*;",
            f"{name} <= {binary_width}'b0;",
            body,
        )

    return f"{header}\n{body}\nendmodule\n"


__all__ = [
    "detect_fifo_encoding",
    "generate_binary_fifo_gate",
]
