"""ATH-1115 Gap A: sha256-chain verification of artifact provenance.

Tracks the chain: gold source -> elaborated gold -> miter -> EBMC input
-> measurement input. At each step, records the sha256 of the file used.
If any link in the chain doesn't match, we verified/measured the wrong
file.

The -76.4% fake result came from measuring raw gold (sha256_A) while
verifying elaborated gold (sha256_B). A chain check would have caught
sha256_A != sha256_B before shipping.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ArtifactChain:
    """Tracks sha256 at each stage of the verification pipeline."""
    gold_source_sha: str = ""
    gold_elaborated_sha: str = ""
    gate_source_sha: str = ""
    gate_elaborated_sha: str = ""
    miter_sha: str = ""
    gold_measured_sha: str = ""
    gate_measured_sha: str = ""

    def record_gold_source(self, path: Path) -> None:
        self.gold_source_sha = _sha256(path)

    def record_gold_elaborated(self, path: Path) -> None:
        self.gold_elaborated_sha = _sha256(path)

    def record_gate_source(self, path: Path) -> None:
        self.gate_source_sha = _sha256(path)

    def record_gate_elaborated(self, path: Path) -> None:
        self.gate_elaborated_sha = _sha256(path)

    def record_miter(self, path: Path) -> None:
        self.miter_sha = _sha256(path)

    def record_gold_measured(self, path: Path) -> None:
        self.gold_measured_sha = _sha256(path)

    def record_gate_measured(self, path: Path) -> None:
        self.gate_measured_sha = _sha256(path)

    def check_gold_consistency(self) -> str | None:
        """Verify the gold file used for measurement matches verification.

        Returns None if consistent, error message if not.
        """
        if not self.gold_measured_sha:
            return None
        if self.gold_elaborated_sha:
            if self.gold_measured_sha != self.gold_elaborated_sha:
                return (
                    f"GOLD MISMATCH: measured sha={self.gold_measured_sha[:12]}... "
                    f"but verified sha={self.gold_elaborated_sha[:12]}... "
                    f"(measured a different file than what was verified)"
                )
        elif self.gold_source_sha:
            if self.gold_measured_sha != self.gold_source_sha:
                return (
                    f"GOLD MISMATCH: measured sha={self.gold_measured_sha[:12]}... "
                    f"but source sha={self.gold_source_sha[:12]}..."
                )
        return None

    def check_gate_consistency(self) -> str | None:
        """Verify the gate file used for measurement matches verification."""
        if not self.gate_measured_sha:
            return None
        if self.gate_elaborated_sha:
            if self.gate_measured_sha != self.gate_elaborated_sha:
                return (
                    f"GATE MISMATCH: measured sha={self.gate_measured_sha[:12]}... "
                    f"but verified sha={self.gate_elaborated_sha[:12]}..."
                )
        elif self.gate_source_sha:
            if self.gate_measured_sha != self.gate_source_sha:
                return (
                    f"GATE MISMATCH: measured sha={self.gate_measured_sha[:12]}... "
                    f"but source sha={self.gate_source_sha[:12]}..."
                )
        return None

    def validate(self) -> list[str]:
        """Run all consistency checks. Returns list of errors (empty = clean)."""
        errors = []
        gold_err = self.check_gold_consistency()
        if gold_err:
            errors.append(gold_err)
        gate_err = self.check_gate_consistency()
        if gate_err:
            errors.append(gate_err)
        return errors

    def as_dict(self) -> dict[str, str]:
        """Export for cert payload inclusion."""
        return {
            "gold_source_sha256": self.gold_source_sha,
            "gold_elaborated_sha256": self.gold_elaborated_sha,
            "gate_source_sha256": self.gate_source_sha,
            "gate_elaborated_sha256": self.gate_elaborated_sha,
            "miter_sha256": self.miter_sha,
            "gold_measured_sha256": self.gold_measured_sha,
            "gate_measured_sha256": self.gate_measured_sha,
        }


def _sha256(path: Path) -> str:
    if not path.is_file():
        return ""
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


__all__ = ["ArtifactChain"]
