"""kairos.sec — Sequential Equivalence Checking harness (ATH-983).

Per Todd's 2026-05-04 lock-in directive on the Annapurna engagement,
the silicon-block verification flow pivots from EQY-based combinational
equivalence to EBMC-based Sequential Equivalence Checking with proper
uninitialized-flops handling. EQY's hard-coded ``-set-init-undef`` in
its sat strategy made unconstrained-initial-state semantics
unavoidable; EBMC handles initial state cleanly.

Public surface
--------------

* :func:`build_miter` — generate a SystemVerilog miter wrapping a gold
  module and a gate module so EBMC can run sequential equivalence
  against them. Returns a :class:`MiterSpec` describing the
  generated wrapper plus the asserted properties.

* :func:`verify_sec` — run :func:`kairos.ebmc.verify` on a miter in
  BMC or k-induction mode. Returns a :class:`SecVerifyResult` with
  the per-property verdicts plus the underlying EBMC result.

* :func:`run_sec_bundle` — bundle-shaped adapter analogous to
  :func:`kairos.nki.run_bundle`: accepts a directory containing
  ``gold.sv``, ``gate.v``, ``signature.json``, opens an
  :func:`kairos.observe.observe` session, runs the miter + verify in
  both BMC and k-induction modes, emits one ``sec_block_verified``
  trace event with the dual-verdict payload, returns the run_id.

Run-subtype convention
----------------------

Trace events emit under ``run_subtype="theorem_proving"`` to match
the silicon-block customer-block-certificate flow on the dashboard.
SEC verification is not theorem-proving in the strict Lean sense, but
the dashboard's per-block render aggregates SEC + EQY + Lean all
under the same subtype so the Verification Coverage card can present
a single per-block verdict.

Why a separate ``kairos.sec`` namespace
---------------------------------------

* ``kairos.ebmc`` already ships the engine surface (BMC + k-induction)
  and is correctly fenced as paid-tier. ``kairos.sec`` reuses that
  engine, adding the **miter construction** + **dual-mode invocation**
  + **bundle-shape adapter** layer on top.
* ``kairos.sv`` is the SV-property verification surface (single-design
  property checking). SEC is a two-design comparison; the customer-
  facing semantics differ enough to merit a sibling namespace rather
  than overloading ``kairos.sv``.

Cross-refs
----------

* ATH-983 (the SEC pivot ticket).
* :mod:`kairos.ebmc` (engine).
* :mod:`kairos.nki._adapter` (adapter pattern this module mirrors).
* asabi's ``Pythia/Hardware/SEC/`` Lean per-block contracts (the
  obligation-discharge counterpart).
"""
from __future__ import annotations

from kairos.sec._adapter import (
    RunSecResult,
    SecVerifyResult,
    run_sec_bundle,
    verify_sec,
)
from kairos.sec._flop_audit import (
    FlopAuditResult,
    audit_flop_correspondence,
    extract_flops,
)
from kairos.sec._miter import MiterPort, MiterSignature, MiterSpec, build_miter

__all__ = [
    "build_miter",
    "verify_sec",
    "run_sec_bundle",
    "audit_flop_correspondence",
    "extract_flops",
    "MiterPort",
    "MiterSignature",
    "MiterSpec",
    "SecVerifyResult",
    "RunSecResult",
    "FlopAuditResult",
]
