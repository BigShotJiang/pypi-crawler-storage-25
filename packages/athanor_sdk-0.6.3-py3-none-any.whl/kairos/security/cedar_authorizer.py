"""Cedar runtime authorizer for env_allowlist decisions (ATH-1259 Phase 2).

Three-layer resolution order:
  1. Rust crate (kairos_env_allowlist) — fastest, compile-time verified
  2. Cedar CLI (cedar authorize) — policy-verified, Lean-proved
  3. Python frozensets — runtime fallback

Each layer is backed by the one below it. The Rust crate is the
preferred path when maturin-built; Cedar CLI is the verified fallback;
Python frozensets are the always-available baseline.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
from pathlib import Path

_log = logging.getLogger(__name__)

_CEDAR_DIR = Path(__file__).parent / "cedar"
_CEDAR_BIN_CANDIDATES = [
    shutil.which("cedar"),
    str(Path.home() / "agents/platform/kairos-cedar/cedar-spec/cedar/target/release/cedar"),
]


def _find_cedar() -> str | None:
    for candidate in _CEDAR_BIN_CANDIDATES:
        if candidate and Path(candidate).is_file():
            return candidate
    return None


try:
    from kairos_env_allowlist import env_is_allowed as _rust_authorize  # type: ignore[import-not-found,import-untyped,unused-ignore]
    _HAS_RUST = True
    _log.info("env_allowlist: Rust crate loaded — primary layer active")
except ImportError:
    _HAS_RUST = False
    _log.info("env_allowlist: Rust crate not installed — Cedar/Python fallback")


def cedar_authorize(tool: str, env_var: str) -> bool:
    """Ask: may this tool forward this env var?

    Resolution order: Rust crate → Cedar CLI → Python frozensets.
    """
    if _HAS_RUST:
        try:
            result: bool = _rust_authorize(tool, env_var)
            _log.debug("env_allowlist layer=rust tool=%s var=%s decision=%s", tool, env_var, result)
            return result
        except (ValueError, TypeError):
            _log.debug("env_allowlist layer=rust tool=%s var=%s fallthrough=true", tool, env_var)

    cedar_bin = _find_cedar()
    if not cedar_bin:
        return _python_fallback(tool, env_var)

    request = {
        "principal": f'Tool::"{tool}"',
        "action": 'Action::"forward"',
        "resource": f'EnvVar::"{env_var}"',
        "context": {},
    }

    try:
        proc = subprocess.run(
            [
                cedar_bin, "authorize",
                "--policies", str(_CEDAR_DIR / "env_allowlist.cedar"),
                "--entities", str(_CEDAR_DIR / "entities.json"),
                "--schema", str(_CEDAR_DIR / "env_allowlist.cedarschema"),
                "--request-json", "/dev/stdin",
            ],
            input=json.dumps(request),
            capture_output=True,
            text=True,
            timeout=5,
        )
        decision = proc.stdout.strip()
        if decision == "ALLOW":
            _log.debug("env_allowlist layer=cedar tool=%s var=%s decision=True", tool, env_var)
            return True
        if decision == "DENY":
            _log.debug("env_allowlist layer=cedar tool=%s var=%s decision=False", tool, env_var)
            return False
        _log.warning("cedar authorize returned unexpected: %s", decision)
        return _python_fallback(tool, env_var)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        _log.warning("cedar authorize failed: %s, falling back to Python", e)
        return _python_fallback(tool, env_var)


def _python_fallback(tool: str, env_var: str) -> bool:
    from kairos.security.env_allowlist import (
        _BASELINE, _LEAN_EXTRA, _CEDAR_EXTRA, _ACL2_EXTRA,
        _VERILATOR_EXTRA, _CLAUDE_SUBAGENT_EXTRA,
        _DOCKER_TRANSPORT_VARS,
    )
    tool_allowlists = {
        "yosys": _BASELINE,
        "ebmc": _BASELINE,
        "lean": _BASELINE | _LEAN_EXTRA,
        "lake": _BASELINE | _LEAN_EXTRA,
        "acl2": _BASELINE | _ACL2_EXTRA,
        "verilator": _BASELINE | _VERILATOR_EXTRA,
        "cedar": _BASELINE | _CEDAR_EXTRA,
        "claude_subagent": _BASELINE | _CLAUDE_SUBAGENT_EXTRA,
        "eval_bash_host": _BASELINE,
        "eval_bash_sandbox": _BASELINE | _DOCKER_TRANSPORT_VARS,
        # NOTE: git's GIT_* prefix match (safe_env_for_git) cannot be
        # modeled here — Cedar/Rust layers also conservatively deny
        # prefix vars. Baseline-only is consistent across all 3 layers.
        "git": _BASELINE,
    }
    allowlist = tool_allowlists.get(tool, _BASELINE)
    result = env_var in allowlist
    _log.debug("env_allowlist layer=python tool=%s var=%s decision=%s", tool, env_var, result)
    return result
