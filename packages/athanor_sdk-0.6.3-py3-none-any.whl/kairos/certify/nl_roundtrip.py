"""ATH-722 — Lean term → English summary via BYO-LLM (Guard E).

Layer-3 LLM-defensive certification check that catches the
autoformalization failure mode "I asked for X, the SDK proved Y."
After `simple_prove` produces a Lean term, generate a deterministic
English summary of *what was actually proved* using BYO-LLM, and
surface a drift report against the customer's original hypothesis.

## Why kairos-natural

* Reverse direction (Lean → English) needs an LLM call.
* `kairos.llm_byo` already ships the BYO-key dispatcher for forward
  direction (NL → Lean); reusing it keeps the no-Athanor-key contract.
* No Lean kernel access required — pure post-hoc summarization.

## Customer surface

```python
from kairos.certify import summarize

result = summarize(
    lean_source=open("spec.lean").read(),
    original_hypothesis="prove etaHR is non-negative",
)
print(result.english_summary)
if result.drift_warnings:
    print("Drift:", result.drift_warnings)
```

When no BYO-LLM key is configured, `summarize` returns a
`RoundtripResult` with `english_summary=""` and a single drift warning
explaining the skip — never raises.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class RoundtripResult:
    """Structured outcome of one Lean → English round-trip.

    `english_summary` is the LLM's plain-English description of what
    the Lean theorem proves. `drift_warnings` enumerates discrepancies
    between the original hypothesis (when supplied) and what Lean
    actually states. `match_score` is a 0..1 word-overlap Jaccard
    score — None when no comparison was possible (no original
    hypothesis, or empty summary).
    """

    english_summary: str
    drift_warnings: list[str] = field(default_factory=list)
    match_score: float | None = None
    raw_llm_output: str = ""


_SUMMARY_PROMPT = (
    "You are a Lean 4 theorem summarizer for the Athanor SDK. Given a "
    "Lean source containing a `theorem` or `example` declaration, "
    "produce a plain-English summary of what the theorem proves.\n\n"
    "Output requirements:\n"
    "1. ONE sentence describing what was proved (what mathematical claim).\n"
    "2. NO Lean syntax in the output — translate every symbol to its "
    "English name (e.g. `≤` → 'is at most').\n"
    "3. NO meta commentary like 'this theorem proves' — just state the "
    "claim directly.\n"
    "4. Mention the supporting Pythia/Mathlib lemma the proof relies on "
    "if you can identify it from the proof body (e.g. `etaHR_nonneg`).\n\n"
    "Lean source:\n```lean\n{lean_source}\n```\n\n"
    "English summary:"
)

_DRIFT_PROMPT = (
    "You are a specification-drift checker. The customer wrote a "
    "hypothesis in English. The SDK then formalized it as Lean and "
    "proved it. Compare the two and list any drift — places where the "
    "Lean theorem says something different from what the customer "
    "asked for.\n\n"
    "Customer's original hypothesis:\n{original}\n\n"
    "What Lean actually proved (English summary of the Lean term):\n{summary}\n\n"
    "Output a JSON list of drift warnings — one short string per "
    "warning. If there is no drift, output an empty list `[]`. "
    "Output ONLY the JSON, no prose, no markdown fences:"
)


def summarize(
    lean_source: str,
    *,
    original_hypothesis: str | None = None,
    max_tokens: int = 400,
) -> RoundtripResult:
    """ATH-722: round-trip the Lean source back to English via BYO-LLM.

    Args:
        lean_source: the generated Lean theorem source (full file or just
            the declaration). Passed verbatim to the LLM.
        original_hypothesis: the customer's original English hypothesis.
            When supplied, the LLM also produces a structured drift
            report comparing the two.
        max_tokens: upper bound on the LLM response length. Default 400
            is enough for one-sentence summary + a small drift list.

    Returns:
        :class:`RoundtripResult`. Never raises — when the BYO key is
        missing or the LLM call fails, returns a result with an empty
        summary and a single drift warning explaining the skip.
    """
    from kairos import llm_byo

    if not llm_byo.is_available():
        return RoundtripResult(
            english_summary="",
            drift_warnings=[
                "no BYO-LLM key configured; round-trip skipped — set "
                "ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY"
            ],
            match_score=None,
        )

    summary_prompt = _SUMMARY_PROMPT.format(lean_source=lean_source.strip())
    try:
        english_summary = llm_byo.complete(
            summary_prompt, max_tokens=max_tokens, temperature=0.0,
        ).strip()
    except Exception as e:  # noqa: BLE001
        return RoundtripResult(
            english_summary="",
            drift_warnings=[f"LLM summarization failed: {e}"],
            match_score=None,
        )

    drift_warnings: list[str] = []
    match_score: float | None = None
    raw_drift = ""
    if original_hypothesis and english_summary:
        match_score = _jaccard_word_overlap(original_hypothesis, english_summary)
        # Always ask the LLM for a structured drift report regardless of
        # match_score — Jaccard is too coarse to gate the LLM check.
        drift_prompt = _DRIFT_PROMPT.format(
            original=original_hypothesis.strip(),
            summary=english_summary,
        )
        try:
            raw_drift = llm_byo.complete(
                drift_prompt, max_tokens=300, temperature=0.0,
            ).strip()
            drift_warnings = _parse_drift_warnings(raw_drift)
        except Exception as e:  # noqa: BLE001
            drift_warnings = [f"LLM drift check failed: {e}"]

    return RoundtripResult(
        english_summary=english_summary,
        drift_warnings=drift_warnings,
        match_score=match_score,
        raw_llm_output=raw_drift,
    )


def _jaccard_word_overlap(a: str, b: str) -> float:
    """Cheap deterministic similarity. Stop-word-filtered word-set
    Jaccard. 0.0 = no overlap, 1.0 = identical bag-of-words.
    """
    stop = {
        "the", "a", "an", "is", "are", "be", "of", "for", "in", "on",
        "to", "and", "or", "with", "as", "at", "by", "from", "that",
        "this", "it", "its", "prove", "proof", "show", "shows",
    }
    def toks(s: str) -> set[str]:
        return {
            w.strip(".,;:()[]{}'\"") for w in s.lower().split()
            if w.strip(".,;:()[]{}'\"") and w.strip(".,;:()[]{}'\"") not in stop
        }
    sa, sb = toks(a), toks(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _parse_drift_warnings(raw: str) -> list[str]:
    """Extract a JSON list of drift warning strings from LLM output.

    LLMs sometimes wrap output in markdown fences despite instruction
    to the contrary; tolerate that. Returns an empty list on parse
    failure rather than raising — drift warnings are advisory.
    """
    import json
    import re
    stripped = re.sub(
        r"^```[a-z]*\n|```$", "", raw.strip(), flags=re.MULTILINE,
    ).strip()
    if not stripped:
        return []
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    return [str(w) for w in parsed if isinstance(w, (str, int, float))]


__all__ = ["RoundtripResult", "summarize"]
