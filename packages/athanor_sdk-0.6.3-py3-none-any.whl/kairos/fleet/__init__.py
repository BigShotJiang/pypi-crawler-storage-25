"""kairos.fleet — agent-fleet orchestration primitives.

The single place in the SDK for "how does a fleet of models cooperate to
close a spec". Two entry points:

* :class:`Orchestrator` — the low-level :class:`OrchestratorPlugin`
  implementation. Used by :class:`kairos.spec.pipeline.SpecPipeline` to
  plan one run. Replaces the old ``OpusOrchestrator``; the model is
  now a plain constructor kwarg (default ``anthropic/claude-opus-4-6``)
  instead of being locked into the class name.

* :func:`orchestrate` — the high-level convenience function. Takes an
  intent + model settings, builds a SpecPipeline with an
  :class:`Orchestrator`, runs it, returns the result. Supports
  multi-worker fleets via ``worker_models=[...]`` — the planner
  spreads workers across tiers when provided.

Customers who want the single-agent shape use the class. Customers
who want a one-line fleet call use the function. Both routes flow
through the same implementation.
"""

from __future__ import annotations

from kairos.fleet.orchestrator import Orchestrator, orchestrate

# ATH-749 containerized drafter fan-out. Distinct from the
# SpecPipeline `Orchestrator` above: `Orchestrator` plans one run
# (model selection, tier ordering, tool set); `FleetOrchestrator`
# parallelizes one target across multiple ISOLATED drafter
# containers (anti-cheat, anti-collision).
from kairos.fleet.containerized_drafter import (
    ContainerizedDrafter,
    DrafterMounts,
    FakeContainerizedDrafter,
)
from kairos.fleet.fleet_orchestrator import (
    FleetOrchestrator,
    FleetRunSummary,
)
from kairos.fleet.stdio_proxy import StdioProxyClient, StdioProxyError

__all__ = [
    "Orchestrator",
    "orchestrate",
    # ATH-749 fleet-isolation surface.
    "ContainerizedDrafter",
    "DrafterMounts",
    "FakeContainerizedDrafter",
    "FleetOrchestrator",
    "FleetRunSummary",
    "StdioProxyClient",
    "StdioProxyError",
]
