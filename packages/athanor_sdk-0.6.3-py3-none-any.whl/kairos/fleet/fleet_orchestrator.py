"""kairos.fleet.fleet_orchestrator — fan-out drafters across one target.

A :class:`FleetOrchestrator` composes multiple drafters (any object
that exposes a ``.cycle_prove(target, **kwargs) -> CycleResult``
method — the :class:`ContainerizedDrafter` /
:class:`FakeContainerizedDrafter` shape) and dispatches a single
target to all of them in parallel via ThreadPoolExecutor.

Aggregation is intentionally minimal: callers get back a dict mapping
each drafter alias to its CycleResult plus a summary, and decide for
themselves what "the fleet closed it" means (any drafter closes? all
agree? cheapest closer wins?). Library code does not commit to a
verdict-policy; that's a customer call.

Example:

    from kairos.fleet import (
        ContainerizedDrafter, DrafterMounts, FleetOrchestrator,
    )

    fleet = FleetOrchestrator(drafters=[
        ContainerizedDrafter(
            alias="sonnet", model_id="anthropic/claude-sonnet-4-6",
            image="ghcr.io/athanor-ai/fleet-drafter:2026.04.27",
            mounts=DrafterMounts(
                readonly_lake=Path("/host/lake-readonly"),
                writable_workdir=Path("/host/work-sonnet"),
            ),
        ),
        ContainerizedDrafter(alias="kimi", ...),
    ])
    summary = fleet.run(target, max_rounds=4)
    if summary.any_closed:
        print(summary.first_closer())
"""
from __future__ import annotations

import logging
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Optional

from kairos.fleet.drafter_protocol import DrafterProtocol
from kairos.lean_cycle import CycleResult, CycleTarget


_logger = logging.getLogger(__name__)


# ATH-1233 phase 3 commit 2: v1.2 9-event taxonomy. The 9 event types
# below are emitted at the documented sites in :meth:`FleetOrchestrator.run`.
# Helper wraps :func:`kairos.observe.emit` with ``silent_if_no_session=True``
# so a fleet run outside of an explicit ``observe()`` context is a no-op
# (preserves the v1.0/v1.1 standalone-fleet contract).
_FLEET_EVENT_TYPES: frozenset[str] = frozenset({
    "fleet_run_started",
    "fleet_cost_estimate_total",
    "fleet_health_check_started",
    "fleet_health_check_complete",
    "drafter_attempt_started",
    "drafter_attempt_complete",
    "drafter_attempt_skipped",
    "fleet_cleanup_complete",
    "fleet_run_complete",
})


def _emit_fleet_event(event_type: str, payload: dict[str, Any]) -> None:
    """Emit one fleet-orchestrator event via :func:`kairos.observe.emit`.

    Uses ``silent_if_no_session=True`` so a fleet run outside any
    ``observe()`` context is a no-op (matches the pre-phase-3
    standalone-fleet behavior). Customer drivers that wrap
    ``fleet.run()`` in ``with observe()`` get the full 9-event
    timeline.

    Per the v1.2 design lock: emit MUST NOT raise. We catch broad
    exceptions from the emit-path (sink errors, schema-strict
    rejection, etc.) and log them — never propagate.
    """
    if event_type not in _FLEET_EVENT_TYPES:
        # Self-defense: a typo in event_type wouldn't be caught by
        # the schema-permissive emit() default. Log + drop so a
        # future refactor that adds a new event must update the
        # frozenset above.
        _logger.warning(
            "FleetOrchestrator: unknown fleet event_type %r; expected "
            "one of %r — dropping the event. Update _FLEET_EVENT_TYPES "
            "if adding a new v1.2+ event.", event_type, sorted(_FLEET_EVENT_TYPES),
        )
        return
    try:
        from kairos.observe import emit as _obs_emit
        _obs_emit(
            event_type,
            payload,
            run_subtype="theorem_proving",
            silent_if_no_session=True,
        )
    except Exception as e:  # noqa: BLE001 — emit MUST NOT raise per contract
        _logger.warning(
            "FleetOrchestrator: emit(%r) raised %s; swallowing per "
            "feedback_silent_failure_mode-pattern (emit must not break "
            "the fleet run).", event_type, e,
        )


def _maybe_call_cleanup(drafter: Any) -> None:
    """Best-effort cleanup invocation on a drafter. Swallows + logs
    exceptions per the DrafterProtocol.cleanup contract (MUST NOT
    raise). Returns ``None`` always.
    """
    cleanup_fn = getattr(drafter, "cleanup", None)
    if cleanup_fn is None:
        return
    try:
        cleanup_fn()
    except Exception as e:  # noqa: BLE001 — log + swallow per contract
        _logger.warning(
            "FleetOrchestrator: cleanup() raised for alias=%r: %s; "
            "swallowing per DrafterProtocol contract.",
            getattr(drafter, "alias", "?"), e,
        )


# ATH-1233 phase 2 commit 2: narrow the orchestrator's private contract
# to the public DrafterProtocol. Pre-uplift this was a private
# ``_DrafterProtocol`` (alias + cycle_prove only); the public protocol
# adds ``model_id: str`` so preflight callers can rely on attribute
# existence without the getattr(d, "model_id", None) fallback class.
# Alias kept as a module-private name so dependents that referenced
# ``fleet_orchestrator._DrafterProtocol`` directly stay green; new
# code should import :class:`kairos.fleet.drafter_protocol.DrafterProtocol`.
_DrafterProtocol = DrafterProtocol


@dataclass
class FleetRunSummary:
    """Aggregate of one fleet.run() invocation.

    `outcomes` maps drafter alias → either CycleResult (success) or
    a dict {"error": "..."} on failure. `any_closed` is True iff at
    least one drafter returned a CycleResult with closed=True.
    `wall_seconds` is the wall-clock time of the longest drafter.
    """
    target_id: str
    outcomes: dict[str, Any]
    wall_seconds: float
    fleet_aliases: list[str] = field(default_factory=list)

    @property
    def any_closed(self) -> bool:
        return any(
            isinstance(o, CycleResult) and o.closed
            for o in self.outcomes.values()
        )

    @property
    def all_closed(self) -> bool:
        """True iff every drafter produced a CycleResult AND each
        one closed. Drafters that errored (outcome is a dict with
        'error') count as not closed.
        """
        if not self.outcomes:
            return False
        for outcome in self.outcomes.values():
            if not isinstance(outcome, CycleResult):
                return False
            if not outcome.closed:
                return False
        return True

    def first_closer(self) -> Optional[str]:
        """Alias of the fastest drafter that closed (smallest
        ``total_wall_sec``). None when nobody closed."""
        winners: list[tuple[float, str]] = []
        for alias, outcome in self.outcomes.items():
            if isinstance(outcome, CycleResult) and outcome.closed:
                winners.append((outcome.total_wall_sec, alias))
        if not winners:
            return None
        winners.sort()
        return winners[0][1]

    def summarize(self) -> str:
        lines = [
            f"FleetRunSummary: target={self.target_id} "
            f"wall={self.wall_seconds:.1f}s any_closed={self.any_closed}",
        ]
        for alias in self.fleet_aliases:
            outcome = self.outcomes.get(alias)
            if isinstance(outcome, CycleResult):
                tag = "★ CLOSED" if outcome.closed else "...unresolved"
                lines.append(
                    f"  {alias:<10s} {tag} "
                    f"rounds={outcome.round_count} "
                    f"wall={outcome.total_wall_sec:.1f}s"
                )
            elif isinstance(outcome, dict) and "error" in outcome:
                lines.append(f"  {alias:<10s} ERROR: {outcome['error'][:200]}")
            else:
                lines.append(f"  {alias:<10s} (no outcome)")
        return "\n".join(lines)


@dataclass
class FleetOrchestrator:
    """Fan out one target across multiple drafters in parallel.

    Args:
        drafters: list of drafter handles. Each must expose
            ``.alias: str`` and
            ``.cycle_prove(target, **kwargs) -> CycleResult``.

    Raises:
        ValueError: if two drafters share the same alias. The summary
            keys outcomes by alias, so duplicates would silently
            clobber each other.
    """
    drafters: list[_DrafterProtocol]

    def __post_init__(self) -> None:
        # Aidan 2026-04-27: swarm + agent orchestration is paid-tier
        # only. Same gate as Orchestrator (the older sibling) +
        # sorry_swarm + prove + sv.swarm. Free-tier customers can
        # still call cycle_prove directly with one drafter; the swarm
        # fan-out shape is what's gated.
        from kairos.license_scope import require_product
        require_product("solve")

        seen: set[str] = set()
        for d in self.drafters:
            if d.alias in seen:
                raise ValueError(
                    f"FleetOrchestrator: duplicate drafter alias "
                    f"{d.alias!r}; aliases must be unique because "
                    f"the run summary keys outcomes by alias"
                )
            seen.add(d.alias)

    def run(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
        on_outcome: Optional[Any] = None,
        preflight: bool = True,
        preflight_lake_project: Optional[str] = None,
        preflight_module_path: Optional[str] = None,
    ) -> FleetRunSummary:
        """Dispatch ``target`` to every drafter in parallel and
        return the aggregate.

        ``on_outcome``, when supplied, is called once per drafter as
        their result lands: ``on_outcome(alias, outcome)``.
        ``outcome`` is a CycleResult on success or
        ``{"error": "..."}`` on failure.

        ``preflight=True`` (default) runs ``kairos.preflight.fleet_gate``
        on the host-side ModelClients for every drafter before fan-out
        — catches a broken adapter / stale deployment / bad lake project
        on call 1 instead of after the loop has burned customer money.
        Pass ``preflight=False`` (or set ``KAIROS_FLEET_NO_PREFLIGHT=1``)
        to skip; the skip path raises a loud :class:`PreflightSkipped`
        warning.

        When ``preflight_lake_project`` is supplied (with
        ``preflight_module_path``), the gate also runs a verify
        round-trip on a generic Lean smoke against that project.
        Defaults to ``target.lake_project`` / a synthesized smoke
        module.
        """
        # ATH-1233 phase 3 commit 2: 9-event taxonomy. Each emit uses
        # silent_if_no_session=True so a fleet running without an
        # observe() session (the existing FleetOrchestrator test path)
        # is a no-op. Customer drivers that wrap fleet.run() in
        # ``with observe()`` get a full event timeline.
        _emit_fleet_event(
            "fleet_run_started",
            {
                "target_id": target.tid,
                "fleet_aliases": [d.alias for d in self.drafters],
                "fleet_size": len(self.drafters),
                "max_rounds": max_rounds,
                "preflight": preflight,
            },
        )

        # Phase 3 cost-estimate aggregation. Sums per-drafter
        # cost_estimate() into a fleet_cost_estimate_total event so
        # customer dashboards can show pre-fan-out budget impact.
        fleet_cost_total = 0.0
        per_drafter_costs: dict[str, float] = {}
        for d in self.drafters:
            est_fn = getattr(d, "cost_estimate", None)
            if est_fn is not None:
                try:
                    cost = float(
                        est_fn(target, max_rounds=max_rounds, max_tokens=max_tokens)
                    )
                except Exception as e:  # noqa: BLE001 — log + skip
                    _logger.warning(
                        "FleetOrchestrator: cost_estimate raised for "
                        "alias=%r: %s; recording 0.0", d.alias, e,
                    )
                    cost = 0.0
            else:
                cost = 0.0
            per_drafter_costs[d.alias] = cost
            fleet_cost_total += cost
        _emit_fleet_event(
            "fleet_cost_estimate_total",
            {
                "target_id": target.tid,
                "total_usd": fleet_cost_total,
                "per_drafter": per_drafter_costs,
            },
        )

        if preflight:
            _emit_fleet_event(
                "fleet_health_check_started",
                {
                    "target_id": target.tid,
                    "fleet_aliases": [d.alias for d in self.drafters],
                },
            )
            self._run_preflight_gate(
                target=target,
                lake_project=preflight_lake_project,
                module_path=preflight_module_path,
            )
            _emit_fleet_event(
                "fleet_health_check_complete",
                {
                    "target_id": target.tid,
                    "passed": True,  # _run_preflight_gate raises on fail
                },
            )
        if not self.drafters:
            _emit_fleet_event(
                "fleet_run_complete",
                {
                    "target_id": target.tid,
                    "wall_seconds": 0.0,
                    "any_closed": False,
                    "fleet_aliases": [],
                },
            )
            return FleetRunSummary(
                target_id=target.tid, outcomes={},
                wall_seconds=0.0, fleet_aliases=[],
            )

        # Phase 3 health_check gate per drafter (skip non-ready
        # drafters from the fan-out). Pre-phase-3 every drafter went
        # straight into pool.submit; now drafters whose health_check
        # returns False get a synthetic skipped-outcome and an explicit
        # drafter_attempt_skipped event.
        skipped: dict[str, str] = {}
        active_drafters: list[_DrafterProtocol] = []
        for d in self.drafters:
            health_fn = getattr(d, "health_check", None)
            if health_fn is None:
                active_drafters.append(d)
                continue
            try:
                ok = bool(health_fn())
            except Exception as e:  # noqa: BLE001 — log + treat as not-ready
                _logger.warning(
                    "FleetOrchestrator: health_check raised for alias=%r: "
                    "%s; treating as not-ready", d.alias, e,
                )
                ok = False
            if ok:
                active_drafters.append(d)
            else:
                skipped[d.alias] = "health_check_returned_false"
                _emit_fleet_event(
                    "drafter_attempt_skipped",
                    {
                        "target_id": target.tid,
                        "drafter_alias": d.alias,
                        "reason": "health_check_returned_false",
                    },
                )

        outcomes: dict[str, Any] = {}
        # Pre-populate skipped drafters in outcomes so the summary
        # still keys by every fleet alias.
        for alias, reason in skipped.items():
            outcomes[alias] = {"error": f"skipped: {reason}"}
        aliases = [d.alias for d in self.drafters]
        t0 = time.time()

        if not active_drafters:
            # Edge case: every drafter health-check-failed. Skip the
            # ThreadPoolExecutor (empty max_workers=0 raises).
            for d in self.drafters:
                _maybe_call_cleanup(d)
            _emit_fleet_event(
                "fleet_cleanup_complete",
                {"target_id": target.tid, "drafters_cleaned": len(self.drafters)},
            )
            _emit_fleet_event(
                "fleet_run_complete",
                {
                    "target_id": target.tid,
                    "wall_seconds": 0.0,
                    "any_closed": False,
                    "fleet_aliases": aliases,
                    "skipped_count": len(skipped),
                },
            )
            return FleetRunSummary(
                target_id=target.tid,
                outcomes=outcomes,
                wall_seconds=0.0,
                fleet_aliases=aliases,
            )

        with ThreadPoolExecutor(max_workers=len(active_drafters)) as pool:
            fut_to_alias: dict[Future, str] = {}
            for d in active_drafters:
                _emit_fleet_event(
                    "drafter_attempt_started",
                    {
                        "target_id": target.tid,
                        "drafter_alias": d.alias,
                        "max_rounds": max_rounds,
                    },
                )
                fut = pool.submit(
                    _run_one_drafter,
                    drafter=d,
                    target=target,
                    max_rounds=max_rounds,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                fut_to_alias[fut] = d.alias
            for fut in as_completed(fut_to_alias):
                alias = fut_to_alias[fut]
                try:
                    outcome = fut.result()
                    closed = bool(getattr(outcome, "closed", False))
                except Exception as e:  # noqa: BLE001 — broad-catch fallback
                    outcome = {
                        "error": f"{type(e).__name__}: {e!s:.300}",
                    }
                    closed = False
                outcomes[alias] = outcome
                _emit_fleet_event(
                    "drafter_attempt_complete",
                    {
                        "target_id": target.tid,
                        "drafter_alias": alias,
                        "closed": closed,
                    },
                )
                if on_outcome is not None:
                    try:
                        on_outcome(alias, outcome)
                    except Exception:
                        _logger.exception(
                            "FleetOrchestrator: on_outcome callback raised "
                            "for alias=%r", alias,
                        )

        # Phase 3 cleanup pass + cleanup_complete event. Per
        # DrafterProtocol contract, cleanup() must not raise; we swallow
        # exceptions and log.
        for d in self.drafters:
            _maybe_call_cleanup(d)
        _emit_fleet_event(
            "fleet_cleanup_complete",
            {"target_id": target.tid, "drafters_cleaned": len(self.drafters)},
        )

        wall_seconds = time.time() - t0
        any_closed = any(
            getattr(o, "closed", False) is True
            for o in outcomes.values()
        )
        _emit_fleet_event(
            "fleet_run_complete",
            {
                "target_id": target.tid,
                "wall_seconds": wall_seconds,
                "any_closed": any_closed,
                "fleet_aliases": aliases,
                "skipped_count": len(skipped),
            },
        )
        return FleetRunSummary(
            target_id=target.tid,
            outcomes=outcomes,
            wall_seconds=wall_seconds,
            fleet_aliases=aliases,
        )

    def _run_preflight_gate(
        self,
        *,
        target: CycleTarget,
        lake_project: Optional[str],
        module_path: Optional[str],
    ) -> None:
        """Build host-side ModelClients for every drafter (deduped by
        ``model_id``) and run ``kairos.preflight.fleet_gate``. Raises
        ``PreflightFailure`` on a failed gate; honors
        ``KAIROS_FLEET_NO_PREFLIGHT=1`` via fleet_gate's own skip path.
        """
        from kairos.preflight import fleet_gate, PreflightFailure, PreflightSkipped

        # Honor caller-supplied client_factory on each drafter when
        # present, falling back to the SDK default. Dedup by model_id
        # so a fleet of {Sonnet, Sonnet, Kimi} only smokes 2 keys.
        #
        # 2026-04-27 (research smoke compose-test): the
        # `_DrafterProtocol` only requires ``.alias`` +
        # ``.cycle_prove``; ``.model_id`` is a contract attribute on
        # the SDK's own ContainerizedDrafter shape but not on every
        # conforming drafter. When NO drafter exposes ``.model_id``,
        # the dedup filter silently drops the whole list,
        # ``clients=[]`` reaches ``fleet_gate``, and the gate fires
        # "no clients supplied (empty fleet)" even though the caller
        # passed N drafters. Post-fix: emit a loud
        # :class:`PreflightSkipped` warning + skip preflight rather
        # than fail. Drafters that DO expose ``.model_id`` are
        # smoked normally.
        clients: list[Any] = []
        seen: set[str] = set()
        for d in self.drafters:
            model_id = getattr(d, "model_id", None)
            if not isinstance(model_id, str) or model_id in seen:
                continue
            seen.add(model_id)
            factory = getattr(d, "client_factory", None)
            if factory is None:
                from kairos.fleet.containerized_drafter import (
                    _default_client_factory,
                )
                factory = _default_client_factory
            try:
                clients.append(factory(model_id))
            except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                _logger.warning(
                    "preflight: client_factory(%r) raised %s — gate will "
                    "fail this drafter on call 1", model_id, e,
                )
                continue

        if not clients and self.drafters:
            import warnings
            warnings.warn(
                f"FleetOrchestrator preflight skipped: "
                f"{len(self.drafters)} drafter(s) supplied but none "
                f"expose `.model_id` for host-side smoke. Aliases: "
                f"{[getattr(d, 'alias', '?') for d in self.drafters]!r}. "
                f"Run will proceed without preflight. To force "
                f"preflight, add `.model_id: str` to your drafter "
                f"shape; to opt out explicitly, pass "
                f"`preflight=False` to `.run()`.",
                PreflightSkipped,
                stacklevel=3,
            )
            return

        # Default the verify shape to the target's lake_project + a
        # synthesized smoke module path under the target's namespace.
        eff_lake = lake_project if lake_project is not None else (
            str(target.lake_project) if target.lake_project else None
        )
        eff_module = module_path or (
            f"{target.scratch_namespace}.PreflightSmoke"
            if eff_lake else None
        )

        result = fleet_gate(
            clients,
            lake_project=eff_lake,
            module_path=eff_module,
        )
        if not result.passed:
            raise PreflightFailure(result.failures)


def _run_one_drafter(
    *,
    drafter: _DrafterProtocol,
    target: CycleTarget,
    max_rounds: int,
    temperature: float,
    max_tokens: int,
) -> CycleResult:
    """Worker invoked inside the thread pool. Pulled out of `.run()`
    so it's testable and so the future picks up exceptions cleanly."""
    return drafter.cycle_prove(
        target,
        max_rounds=max_rounds,
        temperature=temperature,
        max_tokens=max_tokens,
    )
