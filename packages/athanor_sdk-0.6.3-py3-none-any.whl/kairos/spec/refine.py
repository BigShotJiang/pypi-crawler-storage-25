"""ATH-1120: iterative spec refinement loop.

Automates Todd's VCF babysitting: DUT + initial classifier spec ->
formal verify -> counterexample -> LLM refines spec -> repeat until
converged (no more counterexamples) or budget exhausted.

Four compression moves available at each iteration:
1. Symbolic anchor: fix an anchor variable to reduce state space
2. Induction: k-induction with bridging invariants
3. Cross-instance symmetry: share spec across symmetric DUT instances
4. Gating: clock/enable gating constraints from pattern detection
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from kairos.model_presets import DEFAULT_PROVE_DRAFTER_MODEL


@dataclass(frozen=True)
class SpecIteration:
    """One iteration of the spec refinement loop."""
    iteration_index: int
    spec_text: str
    verify_result: str  # "PASS" | "FAIL" | "INCONCLUSIVE" | "ERROR"
    counterexample: str | None = None
    refinement_rationale: str = ""
    compression_moves_applied: tuple[str, ...] = ()
    elapsed_sec: float = 0.0


@dataclass(frozen=True)
class SpecRefinementResult:
    """Result of the full spec refinement loop."""
    converged: bool
    iterations: tuple[SpecIteration, ...]
    final_spec: str
    total_elapsed_sec: float
    halt_reason: str  # "converged" | "budget_exhausted" | "max_iterations" | "error"
    compression_moves_used: tuple[str, ...] = ()

    def n_iterations(self) -> int:
        return len(self.iterations)


def refine_spec(
    *,
    dut_path: str | Path,
    initial_spec: str,
    verify_engine: str = "ebmc",
    refine_model: str = DEFAULT_PROVE_DRAFTER_MODEL,
    max_iterations: int = 10,
    budget_usd: float = 10.0,
    timeout_sec: int = 600,
    top_module: str = "",
    clock_port: str = "clk",
    reset_port: str = "reset_n",
    compression_moves: tuple[str, ...] = ("induction", "gating"),
) -> SpecRefinementResult:
    """Run the iterative spec refinement loop.

    1. Write initial_spec to a temp file alongside DUT
    2. Run verify_engine on DUT + spec
    3. If PASS: converged (spec matches DUT behavior)
    4. If FAIL: extract counterexample, ask LLM to refine spec
    5. Repeat until converged, budget exhausted, or max iterations
    """
    from kairos.sec.closed_loop._session_guard import require_active_session
    require_active_session("refine_spec")

    dut = Path(dut_path).resolve()
    if not dut.is_file():
        raise FileNotFoundError(f"DUT file not found: {dut}")

    try:
        from kairos.observe import emit as _emit
    except ImportError:
        def _emit(*a: Any, **kw: Any) -> None:  # noqa: ARG001
            return None  # observe not available — emit is a no-op

    iterations: list[SpecIteration] = []
    current_spec = initial_spec
    t0 = time.time()
    moves_used: set[str] = set()

    quality = check_spec_quality(initial_spec)
    if quality.is_degenerate:
        _emit("spec_refinement_iteration", payload={
            "iteration_index": -1,
            "verify_result": "DEGENERATE",
            "is_vacuous": quality.is_vacuous,
            "is_tautological": quality.is_tautological,
            "warnings": list(quality.warnings),
            "assert_count": quality.assert_count,
        })

    for i in range(max_iterations):
        if time.time() - t0 > timeout_sec:
            _emit("spec_refinement_complete", payload={
                "converged": False,
                "halt_reason": "budget_exhausted",
                "n_iterations": len(iterations),
                "total_elapsed_sec": round(time.time() - t0, 2),
            })
            return SpecRefinementResult(
                converged=False,
                iterations=tuple(iterations),
                final_spec=current_spec,
                total_elapsed_sec=time.time() - t0,
                halt_reason="budget_exhausted",
                compression_moves_used=tuple(sorted(moves_used)),
            )

        iter_t0 = time.time()

        verify_result, counterexample = _verify_spec(
            dut_path=dut,
            spec_text=current_spec,
            engine=verify_engine,
            top_module=top_module,
            clock_port=clock_port,
            timeout_sec=min(timeout_sec // max_iterations, 120),
        )

        iter_elapsed = time.time() - iter_t0

        _emit("spec_refinement_iteration", payload={
            "iteration_index": i,
            "verify_result": verify_result,
            "has_counterexample": counterexample is not None,
            "elapsed_sec": round(iter_elapsed, 2),
            "engine": verify_engine,
            "spec_length": len(current_spec),
            "compression_moves_applied": list(moves_used),
        })

        if verify_result == "PASS":
            iterations.append(SpecIteration(
                iteration_index=i,
                spec_text=current_spec,
                verify_result="PASS",
                elapsed_sec=iter_elapsed,
                compression_moves_applied=tuple(sorted(moves_used)),
            ))
            _emit("spec_refinement_complete", payload={
                "converged": True,
                "halt_reason": "converged",
                "n_iterations": i + 1,
                "total_elapsed_sec": round(time.time() - t0, 2),
                "compression_moves_used": sorted(moves_used),
            })
            return SpecRefinementResult(
                converged=True,
                iterations=tuple(iterations),
                final_spec=current_spec,
                total_elapsed_sec=time.time() - t0,
                halt_reason="converged",
                compression_moves_used=tuple(sorted(moves_used)),
            )

        refined_spec, rationale, moves = _refine_with_llm(
            dut_text=dut.read_text(),
            current_spec=current_spec,
            counterexample=counterexample or "",
            model=refine_model,
            available_moves=compression_moves,
            iteration=i,
        )

        iterations.append(SpecIteration(
            iteration_index=i,
            spec_text=current_spec,
            verify_result=verify_result,
            counterexample=counterexample,
            refinement_rationale=rationale,
            compression_moves_applied=moves,
            elapsed_sec=iter_elapsed,
        ))

        moves_used.update(moves)
        current_spec = refined_spec

    _emit("spec_refinement_complete", payload={
        "converged": False,
        "halt_reason": "max_iterations",
        "n_iterations": max_iterations,
        "total_elapsed_sec": round(time.time() - t0, 2),
        "compression_moves_used": sorted(moves_used),
    })
    return SpecRefinementResult(
        converged=False,
        iterations=tuple(iterations),
        final_spec=current_spec,
        total_elapsed_sec=time.time() - t0,
        halt_reason="max_iterations",
        compression_moves_used=tuple(sorted(moves_used)),
    )


def _verify_spec(
    *,
    dut_path: Path,
    spec_text: str,
    engine: str,
    top_module: str,
    clock_port: str,
    timeout_sec: int,
) -> tuple[str, str | None]:
    """Verify a spec against the DUT. Returns (result, counterexample)."""
    import tempfile
    spec_file = Path(tempfile.mktemp(suffix=".sv", prefix="spec_"))
    spec_file.write_text(spec_text)

    try:
        from kairos.sec.closed_loop.engine_registry import get_registry
        reg = get_registry()
        engine_entry = reg.get(engine)
        if engine_entry and engine_entry.engine_type == "verify":
            result = engine_entry.callable(
                gold_path=dut_path, gate_path=spec_file,
                gold_module=top_module, gate_module=f"{top_module}_spec",
                timeout_sec=timeout_sec,
            )
            if result.get("proved"):
                return "PASS", None
            elif result.get("refuted"):
                return "FAIL", result.get("detail", "counterexample found")
            else:
                return "INCONCLUSIVE", result.get("detail")

        return "ERROR", f"engine '{engine}' not found in registry"
    except Exception as e:  # noqa: BLE001
        return "ERROR", str(e)
    finally:
        spec_file.unlink(missing_ok=True)


def _refine_with_llm(
    *,
    dut_text: str,
    current_spec: str,
    counterexample: str,
    model: str,
    available_moves: tuple[str, ...],
    iteration: int,
) -> tuple[str, str, tuple[str, ...]]:
    """Ask LLM to refine the spec based on the counterexample.

    Returns (refined_spec, rationale, moves_applied).
    """
    prompt = (
        f"You are refining a formal specification to match a DUT's behavior.\n\n"
        f"## DUT (the design under test)\n```\n{dut_text[:2000]}\n```\n\n"
        f"## Current spec (iteration {iteration})\n```\n{current_spec}\n```\n\n"
        f"## Counterexample from formal verifier\n{counterexample[:1000]}\n\n"
        f"## Available compression moves: {', '.join(available_moves)}\n\n"
        f"Refine the spec so it no longer triggers this counterexample.\n"
        f"Apply compression moves where applicable.\n"
        f"Return the refined spec in a ```systemverilog code block."
    )

    try:
        from kairos.model_client._backoff import call_with_backoff
        response = call_with_backoff(
            primary_model=model,
            system_prompt="You are a formal verification expert refining state classifier specs.",
            user_prompt=prompt,
            timeout_sec=120,
        )
        if response.content:
            import re
            m = re.search(r"```(?:systemverilog|sv)?\n(.*?)```", response.content, re.DOTALL)
            if m:
                return m.group(1).strip(), response.content[:200], ()
            return response.content, "raw response", ()
        return current_spec, "empty LLM response", ()
    except Exception as e:  # noqa: BLE001
        return current_spec, f"LLM error: {e}", ()


@dataclass(frozen=True)
class SpecQualityReport:
    """Result of spec quality analysis."""
    is_vacuous: bool
    is_tautological: bool
    warnings: tuple[str, ...]
    assert_count: int
    assume_count: int
    cover_count: int

    @property
    def is_degenerate(self) -> bool:
        return self.is_vacuous or self.is_tautological or self.assert_count == 0


def check_spec_quality(spec_text: str) -> SpecQualityReport:
    """Detect degenerate specs before burning verification budget.

    Catches:
    - Vacuous specs (no assertions)
    - Tautological assertions (assert 1, assert property (1))
    - Over-constrained assumptions that make assertions trivially true
    - Missing cover points (spec might prove but be unreachable)
    """
    import re

    lines = spec_text.split('\n')
    warnings: list[str] = []

    assert_count = len(re.findall(r'\bassert\b', spec_text, re.IGNORECASE))
    assume_count = len(re.findall(r'\bassume\b', spec_text, re.IGNORECASE))
    cover_count = len(re.findall(r'\bcover\b', spec_text, re.IGNORECASE))

    is_vacuous = assert_count == 0
    if is_vacuous:
        warnings.append("spec has no assertions; any DUT will pass vacuously")

    tautology_patterns = [
        r'assert\s*\(\s*1\s*\)',
        r'assert\s+property\s*\(\s*1\s*\)',
        r'assert\s*\(\s*1\'b1\s*\)',
        r'assert\s+property\s*\(\s*1\'b1\s*\)',
    ]
    is_tautological = any(
        re.search(pat, spec_text, re.IGNORECASE)
        for pat in tautology_patterns
    )
    if is_tautological:
        warnings.append("spec contains tautological assertion (assert 1)")

    if assume_count > assert_count and assert_count > 0:
        warnings.append(
            f"spec has {assume_count} assumes vs {assert_count} asserts; "
            f"over-constrained assumptions may make assertions trivially true"
        )

    if assert_count > 0 and cover_count == 0:
        warnings.append(
            "spec has assertions but no cover points; "
            "assertions may pass on unreachable states"
        )

    return SpecQualityReport(
        is_vacuous=is_vacuous,
        is_tautological=is_tautological,
        warnings=tuple(warnings),
        assert_count=assert_count,
        assume_count=assume_count,
        cover_count=cover_count,
    )


__all__ = [
    "refine_spec",
    "SpecRefinementResult",
    "SpecIteration",
    "SpecQualityReport",
    "check_spec_quality",
]
