"""kairos.spec — spec-pipeline primitives (ATH-492 + ATH-493 + Gate 5).

Gate 5 (ATH-497) surface: 6 spec-layer plugin protocols +
SpecPipeline orchestration + default impls + config resolver.
Trace sink protocol lives at kairos.trace (ATH-498 PR #109).

Public surface:

    # Integrity (ATH-493 PR #107)
    from kairos.spec import (
        canonical_hash, sign, verify, is_signed,
        IntegrityError, IntegrityMissing, IntegrityMismatch,
    )

    # Pipeline + protocols (Gate 5)
    from kairos.spec import (
        SpecPipeline,
        RunResult,
        VerifierRegistry,
        DEFAULT_REGISTRY,
        # 6 plugin protocols
        OrchestratorPlugin,
        PromptLoader,
        ScoringFn,
        ToolRegistryPlugin,
        ModelSelectorPlugin,
        # verdict carriers
        Verdict,
        Counterexample,
        CounterexampleKind,
        OrchestrationChoice,
        # config
        KairosConfig,
        resolve_config,
        Purity,
        # exceptions
        PromptMissing,
        OrchestrationMalformed,
        OrchestrationInvalidPlugin,
        # default impls
        DefaultRoundRobinOrchestrator,
        DefaultToolRegistry,
        DEFAULT_TOOL_REGISTRY,
        DefaultScoring,
        DefaultModelSelector,
        FilesystemPromptLoader,
    )
"""

from __future__ import annotations

from kairos.spec.defaults import (
    DEFAULT_TOOL_REGISTRY,
    DefaultModelSelector,
    DefaultRoundRobinOrchestrator,
    DefaultScoring,
    DefaultToolRegistry,
    FilesystemPromptLoader,
)
from kairos.spec.integrity import (
    INTEGRITY_VERSION,
    IntegrityError,
    IntegrityMismatch,
    IntegrityMissing,
    canonical_hash,
    is_signed,
    sign,
    verify,
)
from kairos.spec.pipeline import (
    DEFAULT_REGISTRY,
    RunResult,
    SpecPipeline,
    VerifierRegistry,
)
from kairos.spec.types import (
    Counterexample,
    CounterexampleKind,
    KairosConfig,
    ModelSelectorPlugin,
    OrchestrationChoice,
    OrchestrationInvalidPlugin,
    OrchestrationMalformed,
    OrchestratorPlugin,
    PromptLoader,
    PromptMissing,
    Purity,
    ScoringFn,
    ToolRegistryPlugin,
    Verdict,
    VerifierPlugin,
    resolve_config,
)

__all__ = [
    # Integrity (ATH-493)
    "INTEGRITY_VERSION",
    "IntegrityError",
    "IntegrityMismatch",
    "IntegrityMissing",
    "canonical_hash",
    "is_signed",
    "sign",
    "verify",
    # Pipeline (Gate 5)
    "SpecPipeline",
    "RunResult",
    "VerifierRegistry",
    "DEFAULT_REGISTRY",
    # Protocols
    "VerifierPlugin",
    "OrchestratorPlugin",
    "PromptLoader",
    "ScoringFn",
    "ToolRegistryPlugin",
    "ModelSelectorPlugin",
    # Verdict + choice
    "Verdict",
    "Counterexample",
    "CounterexampleKind",
    "OrchestrationChoice",
    # Config
    "KairosConfig",
    "resolve_config",
    "Purity",
    # Exceptions
    "PromptMissing",
    "OrchestrationMalformed",
    "OrchestrationInvalidPlugin",
    # Default impls
    "DefaultRoundRobinOrchestrator",
    "DefaultToolRegistry",
    "DEFAULT_TOOL_REGISTRY",
    "DefaultScoring",
    "DefaultModelSelector",
    "FilesystemPromptLoader",
    # Spec refinement (ATH-1120)
    "refine_spec",
    "SpecRefinementResult",
]

try:
    from kairos.spec.refine import SpecRefinementResult, refine_spec
except ImportError:
    pass
