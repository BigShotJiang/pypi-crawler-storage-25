"""kairos.spec.health_check — auto-enabled spec sanity gate.

When a customer hands an English requirement to kairos and we
autoformalize it into Lean, the most expensive failure mode is NOT
"the proof attempt fails" — it's "the proof attempt SUCCEEDS on the
wrong spec". A wrong spec that proves vacuously, or that the LLM
silently distorted, returns a pass verdict but doesn't actually
verify what the customer asked. Catching this BEFORE the proof
attempt saves the customer the cost of a misleading "verified"
output that wouldn't actually load-bear the claim they care about.

This module wedges a sanity gate between autoformalization and
proof. Default-on in `simple_prove` and `SpecPipeline.run()`. The
gate runs a battery of probes and surfaces a `SpecHealthReport`
with per-probe outcomes and an aggregate score; if the score is
below `block_threshold` (default 0.6) OR any probe is in
`report.block_on`, the pipeline raises `SpecHealthError` BEFORE
attempting the proof. The customer sees the autoformalization
problem immediately rather than burning compute on a wrong spec.

The probes (v1):

  1. nl_roundtrip       — existing kairos.certify.nl_roundtrip;
                          re-renders the Lean theorem to English
                          and Jaccard-overlaps with the original
                          intent. Catches outright distortion.
  2. cross_model_agreement — SAME spec re-summarized by a SECOND
                          LLM family; compute Jaccard between the
                          two summaries. If A and B disagree, the
                          spec is ambiguous OR one model
                          hallucinated. Bigger Jaccard = better.
  3. vacuous_audit      — string-level scan for `False.elim`,
                          `macro sorry`, custom `axiom`. From the
                          existing simple_prove machinery (ATH-720).
  4. type_sanity        — count-shaped binders (`n`, `k`, `count`,
                          `size`) typed as Real instead of Nat.
                          From #validate_types (ATH-725); we run
                          the static-string version (no lake build).

Future probes (v2, deferred):

  - counterexample_probe (Z3 via Pythia.Tactic.Disprove)
  - positive_witness_probe / negative_witness_probe (auto-generate
    instances from spec, decide on each)
  - spec_mutation (perturb the Lean source, expect verdict to flip)
  - history_check (when customer's intent overlaps a prior intent
    they checked in, expect the autoformalization to be similar)

The contribution surface is intentionally small and side-effect-free
beyond LLM calls. Probes that would call lake build are deferred so
the gate stays cheap (~1-2 extra LLM calls, ~$0.01 budget per call).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

_logger = logging.getLogger(__name__)


# Severity → reason scoring weights. The aggregate `score` is computed
# as 1.0 minus the sum of (weight × failure-fraction) per probe; below
# `block_threshold` (default 0.6 in callers) the pipeline halts.
_PROBE_WEIGHTS = {
    "nl_roundtrip": 0.30,
    "cross_model_agreement": 0.25,
    "vacuous_audit": 0.25,
    "type_sanity": 0.20,
}

_BLOCK_ON_DEFAULT = (
    "vacuous_audit",  # vacuous proof = wrong proof, never publishable
)


@dataclass(frozen=True)
class ProbeOutcome:
    """One probe's verdict.

    `score` ∈ [0, 1] — 1 is healthy, 0 is failed. `severity`:
        - 'pass': probe ran cleanly, no concern
        - 'warn': probe ran but flagged something the user should see
        - 'fail': probe says the spec is broken and the pipeline
                  should halt (when this probe is in block_on)
        - 'skip': probe couldn't run (missing key, missing dep, etc.)
    """
    name: str
    score: float
    severity: str  # 'pass' | 'warn' | 'fail' | 'skip'
    detail: str = ""
    raw: dict = field(default_factory=dict)


@dataclass(frozen=True)
class SpecHealthReport:
    """Aggregate outcome of all probes.

    `score` ∈ [0, 1] — weighted average across probes. `block_on`
    enumerates probes whose 'fail' severity should halt the pipeline.
    `warnings` is the human-readable summary list (one bullet per
    non-pass probe).
    """
    score: float
    probes: list[ProbeOutcome]
    block_on: list[str]
    warnings: list[str]

    def summarize(self) -> str:
        """Render a customer-facing one-paragraph summary."""
        lines = [f"Spec health: {self.score:.2f}"]
        if self.block_on:
            lines.append(f"  BLOCKED on: {', '.join(self.block_on)}")
        for p in self.probes:
            tag = {"pass": "✓", "warn": "⚠", "fail": "✗", "skip": "○"}[p.severity]
            lines.append(f"  {tag} {p.name}: {p.detail}" if p.detail
                         else f"  {tag} {p.name}: score={p.score:.2f}")
        return "\n".join(lines)


class SpecHealthError(Exception):
    """Raised by callers when the health report's score is below
    threshold or any block_on probe failed. Carries the report so
    integrators can render structured diagnostics.
    """
    def __init__(self, report: SpecHealthReport, message: str = ""):
        super().__init__(message or report.summarize())
        self.report = report


# ─────────────────────────────────────────────────────────────────────
# Individual probes
# ─────────────────────────────────────────────────────────────────────


def _probe_nl_roundtrip(
    lean_source: str, intent_nl: str | None,
) -> ProbeOutcome:
    """ATH-722 reuse. Renders Lean → English via the configured BYO
    LLM and Jaccard-overlaps with the customer's original intent.
    """
    from kairos.certify.nl_roundtrip import summarize

    if not intent_nl or not intent_nl.strip():
        return ProbeOutcome(
            name="nl_roundtrip", score=1.0, severity="skip",
            detail="no intent_nl provided; round-trip skipped",
        )

    try:
        result = summarize(lean_source, original_hypothesis=intent_nl)
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return ProbeOutcome(
            name="nl_roundtrip", score=0.5, severity="skip",
            detail=f"summarize() raised {type(e).__name__}: {e!s:.150}",
        )

    if not result.english_summary:
        # llm_byo unavailable or model declined — soft skip.
        return ProbeOutcome(
            name="nl_roundtrip", score=0.5, severity="skip",
            detail=" / ".join(result.drift_warnings) or "empty summary",
        )

    score = result.match_score if result.match_score is not None else 0.5
    if result.drift_warnings:
        sev = "warn" if score >= 0.5 else "fail"
        detail = (
            f"Jaccard={score:.2f}; drift: "
            f"{'; '.join(result.drift_warnings[:3])}"
        )
    elif score < 0.4:
        sev = "warn"
        detail = f"Jaccard={score:.2f} (low overlap with intent)"
    else:
        sev = "pass"
        detail = f"Jaccard={score:.2f}"
    return ProbeOutcome(
        name="nl_roundtrip", score=score, severity=sev, detail=detail,
        raw={"english_summary": result.english_summary,
             "drift": list(result.drift_warnings)},
    )


def _probe_cross_model_agreement(
    lean_source: str,
    *,
    primary_model: str | None = None,
    secondary_model: str | None = None,
) -> ProbeOutcome:
    """Re-summarize the Lean source via TWO independent model
    families and Jaccard-compare their NL outputs. If A and B agree
    on what the Lean theorem says, the autoformalization is at
    least internally coherent across model perspectives. If they
    diverge, either the spec is ambiguous OR one model
    hallucinated; flag for the user.
    """
    try:
        from kairos.model_client import get_client
    except ImportError:
        return ProbeOutcome(
            name="cross_model_agreement", score=0.5, severity="skip",
            detail="kairos.model_client unavailable",
        )

    summary_prompt = (
        "Summarize what this Lean 4 theorem proves in ONE plain-English "
        "sentence. No Lean syntax in the output. No meta commentary.\n\n"
        f"```lean\n{lean_source.strip()}\n```\n\nSummary:"
    )

    # ATH-816: resolve None defaults from the central preset module so
    # the literal lives in one auditable place. Lazy import keeps
    # health_check importable without pulling presets into every cold
    # path.
    if primary_model is None or secondary_model is None:
        from kairos.model_presets import (
            DEFAULT_HEALTH_CHECK_PRIMARY_MODEL,
            DEFAULT_HEALTH_CHECK_SECONDARY_MODEL,
        )
        if primary_model is None:
            primary_model = DEFAULT_HEALTH_CHECK_PRIMARY_MODEL
        if secondary_model is None:
            secondary_model = DEFAULT_HEALTH_CHECK_SECONDARY_MODEL

    summaries: dict[str, str] = {}
    skipped: list[str] = []
    for alias, model_id in (
        ("primary", primary_model),
        ("secondary", secondary_model),
    ):
        try:
            client = get_client(model_id)
            resp = client.call(
                messages=client.format_messages(
                    "You are a terse Lean 4 theorem summarizer.",
                    summary_prompt,
                ),
                temperature=0.0, max_tokens=400,
            )
            text = (resp.content or "").strip()
            if text:
                summaries[alias] = text
            else:
                skipped.append(f"{alias}={model_id}: empty content")
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            skipped.append(f"{alias}={model_id}: {type(e).__name__}")

    if len(summaries) < 2:
        return ProbeOutcome(
            name="cross_model_agreement", score=0.5, severity="skip",
            detail=f"need 2 summaries, got {len(summaries)}: {'; '.join(skipped)}",
        )

    s1 = summaries["primary"]
    s2 = summaries["secondary"]
    score = _jaccard(s1, s2)
    if score >= 0.6:
        sev = "pass"
        detail = f"Jaccard={score:.2f} between {primary_model} and {secondary_model}"
    elif score >= 0.4:
        sev = "warn"
        detail = (
            f"Jaccard={score:.2f}; models disagree on what the spec "
            f"says. primary='{s1[:120]!s}'; secondary='{s2[:120]!s}'"
        )
    else:
        sev = "fail"
        detail = (
            f"Jaccard={score:.2f}; SIGNIFICANT divergence. "
            f"primary='{s1[:120]!s}'; secondary='{s2[:120]!s}'"
        )
    return ProbeOutcome(
        name="cross_model_agreement", score=score, severity=sev,
        detail=detail, raw={"primary_summary": s1, "secondary_summary": s2},
    )


_VACUOUS_PATTERNS = (
    (re.compile(r"\bsorry\b"), "sorry tactic"),
    (re.compile(r"False\.elim\b"), "False.elim closer (vacuous)"),
    (re.compile(r"@\[macro_sorry\]"), "macro_sorry attribute"),
    (re.compile(r"^\s*axiom\s+\w", re.MULTILINE), "custom axiom declaration"),
)


def _probe_vacuous_audit(lean_source: str) -> ProbeOutcome:
    """ATH-720 reuse. Static-string scan for vacuous-proof
    fingerprints. Catches `sorry`, `False.elim`, `macro_sorry`,
    custom `axiom` declarations. These bypass real proof
    obligation; never accept them.
    """
    findings: list[str] = []
    for pattern, label in _VACUOUS_PATTERNS:
        if pattern.search(lean_source):
            findings.append(label)
    if not findings:
        return ProbeOutcome(
            name="vacuous_audit", score=1.0, severity="pass",
            detail="no vacuous-proof markers detected",
        )
    return ProbeOutcome(
        name="vacuous_audit", score=0.0, severity="fail",
        detail=f"detected: {', '.join(findings)}",
        raw={"findings": findings},
    )


# Common count-shaped binder names that should be Nat / ℕ, not Real / ℝ.
_COUNT_NAMES = {
    "n", "k", "m", "i", "j", "count", "size", "len", "length",
    "num", "idx", "index", "iter", "step",
}

# Approximate binder regex: captures `(name : Type)` and `{name : Type}`
# at top level of the theorem header. Single binder per match; multi-
# binder forms like `(a b : ℝ)` are caught by the multi-name extension.
_BINDER_RE = re.compile(
    r"[({]\s*([a-zA-Z_][a-zA-Z0-9_'\s]*?)\s*:\s*"
    r"(ℝ|ℝ≥0|ℝ≥0∞|Real|NNReal|ENNReal)\s*[)}]"
)


def _probe_type_sanity(lean_source: str) -> ProbeOutcome:
    """ATH-725 static reuse. Walks ∀-binders and flags count-like
    names (n, k, count, ...) that are typed as Real-family instead
    of Nat. This usually means the autoformalizer mis-typed a
    count-shaped variable.
    """
    findings: list[str] = []
    for m in _BINDER_RE.finditer(lean_source):
        names_blob = m.group(1)
        ty = m.group(2)
        for name in names_blob.split():
            name = name.strip()
            if name and name in _COUNT_NAMES:
                findings.append(f"`{name} : {ty}` (count-shaped name typed as real)")

    if not findings:
        return ProbeOutcome(
            name="type_sanity", score=1.0, severity="pass",
            detail="no suspicious count-typed-as-real binders",
        )
    score = max(0.2, 1.0 - 0.25 * len(findings))
    return ProbeOutcome(
        name="type_sanity", score=score, severity="warn",
        detail=f"{len(findings)} suspicious binder(s): {findings[0]}"
               + (f" (and {len(findings)-1} more)" if len(findings) > 1 else ""),
        raw={"findings": findings},
    )


# ─────────────────────────────────────────────────────────────────────
# Aggregation
# ─────────────────────────────────────────────────────────────────────


def _jaccard(a: str, b: str) -> float:
    """Jaccard over lowercased word tokens. Punctuation-stripped."""
    aw = set(re.findall(r"\b[a-z][a-z0-9_]+\b", a.lower()))
    bw = set(re.findall(r"\b[a-z][a-z0-9_]+\b", b.lower()))
    if not aw or not bw:
        return 0.0
    return len(aw & bw) / len(aw | bw)


def health_check(
    lean_source: str,
    intent_nl: Optional[str] = None,
    *,
    block_on: tuple[str, ...] = _BLOCK_ON_DEFAULT,
    enable_cross_model: bool = True,
) -> SpecHealthReport:
    """Run the v1 spec-health probe battery.

    Args:
        lean_source: the autoformalized Lean theorem source. Required.
        intent_nl: customer's original English requirement. Used by
            the nl_roundtrip probe; when None, that probe skips.
        block_on: probe names whose 'fail' severity halts the pipeline
            (caller treats as `SpecHealthError`). Default: vacuous_audit.
        enable_cross_model: skip the cross-model probe when False
            (saves 1 LLM call when the customer is offline / on a
            tight budget). Default True.

    Returns:
        :class:`SpecHealthReport`. Never raises — callers decide
        whether to halt based on `report.block_on` and
        `report.score`. The pipeline integrators (simple_prove,
        SpecPipeline.run) wrap this and raise SpecHealthError on
        threshold violation.
    """
    probes: list[ProbeOutcome] = []

    probes.append(_probe_nl_roundtrip(lean_source, intent_nl))
    if enable_cross_model:
        probes.append(_probe_cross_model_agreement(lean_source))
    probes.append(_probe_vacuous_audit(lean_source))
    probes.append(_probe_type_sanity(lean_source))

    # Weighted aggregate. Skipped probes contribute their full
    # weight at score=1.0 (we don't penalize what we couldn't run).
    total_weight = sum(_PROBE_WEIGHTS.get(p.name, 0.0) for p in probes)
    if total_weight == 0:
        weighted = 0.0
    else:
        weighted = sum(
            _PROBE_WEIGHTS.get(p.name, 0.0) * p.score for p in probes
        ) / total_weight

    block_now = [
        p.name for p in probes
        if p.name in block_on and p.severity == "fail"
    ]
    warnings = [
        f"{p.name}: {p.detail}"
        for p in probes if p.severity in ("warn", "fail")
    ]
    return SpecHealthReport(
        score=weighted,
        probes=probes,
        block_on=block_now,
        warnings=warnings,
    )
