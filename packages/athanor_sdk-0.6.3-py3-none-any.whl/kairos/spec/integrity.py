"""kairos.spec.integrity — hash-lock primitive for IntentV1.

Answers Todd's direct demo feedback (2026-04-22): "once a spec is
formalized, the fleet cannot mess with it". This module is the
mechanical guarantee that an IntentV1 reaching Stage G / mode_fleet
is byte-identical to the IntentV1 that exited Stage B coherence.

Usage:

    from kairos.spec import sign, verify, IntegrityError
    from kairos.spec_compiler import compile as compile_intent

    intent = compile_intent(spec)      # SpecV1 -> IntentV1
    intent = sign(intent)              # embeds meta.integrity_hash
    # ...intent may pass through fleet agents...
    verify(intent)                     # raises IntegrityError if tampered

Design:

    * Hash scope = IntentV1 MINUS the `audit_meta` branch MINUS
      `meta.integrity_hash` itself. Rationale: audit fields (timestamps,
      run_id, submitter) are legitimately time-varying; including them
      in the hash defeats re-signing semantics. Excluding
      `meta.integrity_hash` avoids the chicken-and-egg case.

    * Canonicalization = json.dumps with sort_keys=True, compact
      separators, ensure_ascii=False. Stable across Python versions.

    * Algorithm = SHA256 (stdlib hashlib, no crypto deps). Versioned
      via meta.integrity_version = "sha256-v1" so future rotation is
      a non-breaking field change.

    * Sign returns a NEW dict (does not mutate input). Callers may
      choose to discard the old reference.

    * Verify raises on (a) no hash present, (b) hash present but
      wrong. Never returns False — force callers to handle via
      try/except so silent acceptance is not an option.
"""

from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import Any, Mapping


# Hashing scheme tag. Bump this string when the canonicalization or
# algorithm changes so old + new hashes can coexist in mixed fleets.
INTEGRITY_VERSION = "sha256-v1"

# Top-level keys we exclude from the hash.
#
# `audit_meta`  — the ephemeral-fields home (timestamps, run_id,
#                 submitter, anything time-varying). Callers write
#                 there freely without invalidating the hash.
# `meta`        — partially hashed: its `integrity_hash` and
#                 `integrity_version` subfields are excluded (see
#                 `_canonical_subset`), but any OTHER fields under
#                 `meta` ARE hashed. Keep `meta` intentionally small.
_EXCLUDED_TOP_LEVEL_KEYS: frozenset[str] = frozenset({"audit_meta"})
_EXCLUDED_META_KEYS: frozenset[str] = frozenset({"integrity_hash", "integrity_version"})


# ═══════════════════════════════════════════════════════════════════════
# Exceptions
# ═══════════════════════════════════════════════════════════════════════


class IntegrityError(Exception):
    """Base class for spec-integrity failures."""


class IntegrityMissing(IntegrityError):
    """Raised by verify() when no integrity_hash is present on the intent."""


class IntegrityMismatch(IntegrityError):
    """Raised by verify() when the stored hash does not match the recomputed hash.

    The `expected` and `actual` attributes hold the two hex digests so
    callers can log them for postmortem without re-hashing.
    """

    def __init__(self, expected: str, actual: str) -> None:
        super().__init__(
            f"IntentV1 integrity-hash mismatch — tampering detected. "
            f"Stored: {expected[:16]}..., recomputed: {actual[:16]}..."
        )
        self.expected = expected
        self.actual = actual


# ═══════════════════════════════════════════════════════════════════════
# Internal: canonicalization + hashing
# ═══════════════════════════════════════════════════════════════════════


def _canonical_subset(intent: Mapping[str, Any]) -> dict[str, Any]:
    """Return a deep-copied, hash-scope subset of the intent.

    Strips `audit_meta` at the top level and `meta.integrity_hash` +
    `meta.integrity_version` within `meta` (if `meta` is present). All
    other fields are retained.
    """
    subset: dict[str, Any] = {
        k: deepcopy(v)
        for k, v in intent.items()
        if k not in _EXCLUDED_TOP_LEVEL_KEYS
    }
    meta = subset.get("meta")
    if isinstance(meta, dict):
        subset["meta"] = {
            k: v for k, v in meta.items() if k not in _EXCLUDED_META_KEYS
        }
        # If meta becomes empty after stripping, drop it entirely —
        # avoids a spurious {} affecting the canonical representation
        # on round-trips.
        if not subset["meta"]:
            subset.pop("meta")
    return subset


def _canonical_json(obj: Any) -> str:
    """Stable JSON serialization for hashing.

    Sort keys, compact separators, no ensure_ascii (so unicode
    content hashes identically across Python versions + locales).
    """
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


# ═══════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════


def canonical_hash(intent: Mapping[str, Any]) -> str:
    """Compute the hex-encoded SHA256 of the hashed-subset IntentV1.

    The hashed subset excludes `audit_meta` (top-level) and
    `meta.integrity_hash` / `meta.integrity_version` (within `meta`).
    See module docstring for the rationale.

    Returns a 64-character lowercase hex string.
    """
    subset = _canonical_subset(intent)
    payload = _canonical_json(subset).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sign(intent: Mapping[str, Any]) -> dict[str, Any]:
    """Return a new IntentV1 dict with `meta.integrity_hash` populated.

    Input is not mutated. The returned dict is a deep copy with the
    `meta` branch augmented (or created if absent).

    Re-signing an already-signed intent is idempotent at the payload
    level: the hash is computed from the hashed-subset which excludes
    the old hash, so calling `sign(sign(intent))` produces the same
    final hash as `sign(intent)`.
    """
    signed: dict[str, Any] = deepcopy(dict(intent))
    digest = canonical_hash(signed)
    meta = signed.get("meta")
    if not isinstance(meta, dict):
        meta = {}
    meta["integrity_hash"] = digest
    meta["integrity_version"] = INTEGRITY_VERSION
    signed["meta"] = meta
    return signed


def is_signed(intent: Mapping[str, Any]) -> bool:
    """True iff `meta.integrity_hash` is present and non-empty.

    Does NOT verify the hash is correct; use `verify()` for that.
    Cheap boolean check for branching logic.
    """
    meta = intent.get("meta")
    if not isinstance(meta, dict):
        return False
    stored = meta.get("integrity_hash")
    return bool(stored)


def verify(intent: Mapping[str, Any]) -> None:
    """Assert the intent's stored `integrity_hash` matches the recomputed hash.

    Raises:
        IntegrityMissing: no hash on the intent at all.
        IntegrityMismatch: hash present but does not match recomputation.

    Does not return a value on success — callers that need a boolean
    should use `try/except` and swallow the exception explicitly.
    This design forces tamper-detection to be a conscious control-flow
    decision, not a silent `if verify(x): ...` that defaults to safe
    when the call itself is wrong.
    """
    meta = intent.get("meta")
    stored: str | None = None
    if isinstance(meta, dict):
        stored = meta.get("integrity_hash")
    if not stored:
        raise IntegrityMissing(
            "IntentV1 has no meta.integrity_hash — call sign() after Stage B "
            "coherence before passing the intent downstream."
        )
    actual = canonical_hash(intent)
    if stored != actual:
        raise IntegrityMismatch(expected=stored, actual=actual)
