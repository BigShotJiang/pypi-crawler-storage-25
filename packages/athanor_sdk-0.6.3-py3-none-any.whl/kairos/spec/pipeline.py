"""kairos.spec.pipeline — SpecPipeline MVP (Gate 5, ATH-497).

Ties together the 7 plugin protocols into the spec-closing pipeline.

Constructor takes **all 7 plugins as injected dependencies** (per the
2026-04-23 Aidan extensibility directive). Every configuration point
has a sane built-in default; customers override to bring their own
config / tool / model / prompt.

Gate 5 MVP scope: the class exists, the contract is testable, and the
``.run()`` method exposes the happy-path orchestration. Deep
stage-by-stage integration with the existing spec_compiler happens
inline with Gate 6 prompts + Gate 9 kairos.fleet.Orchestrator. Gate 5 ships
the shape + defaults + tests.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any, Mapping

from kairos.spec.defaults import (
    DEFAULT_TOOL_REGISTRY,
    DefaultModelSelector,
    DefaultRoundRobinOrchestrator,
    DefaultScoring,
    FilesystemPromptLoader,
)
from kairos.spec.integrity import (
    INTEGRITY_VERSION,
    IntegrityError,
    IntegrityMissing,
    verify as _verify_integrity,
)
from kairos.spec.types import (
    KairosConfig,
    ModelSelectorPlugin,
    OrchestrationChoice,
    OrchestratorPlugin,
    PromptLoader,
    ScoringFn,
    ToolRegistryPlugin,
    Verdict,
    resolve_config,
)
from kairos.trace import (
    EscalationEvent,
    NoopTraceSink,
    TraceEvent,
    TraceSink,
)

logger = logging.getLogger(__name__)


def _default_trace_sink() -> "TraceSink":
    """Pick the default TraceSink based on env.

    Contract (2026-04-23, closes pipeline-ready gap 2):

    - ``KAIROS_TRACE_SINK=supabase`` (+ ``SUPABASE_SERVICE_ROLE_KEY``
      env set) → SupabaseTraceSink. Fleet-mode default.
    - ``KAIROS_TRACE_SINK=noop`` or unset → NoopTraceSink. Customer-
      wheel default (preserves zero-phone-home privacy).
    - Any other value → NoopTraceSink + WARN log. Fail-safe toward the
      privacy default; never crash on bad env.

    The env-var path keeps the customer-wheel default zero-config
    (NoopTraceSink; no accidental DB writes) while giving fleet runs
    a single-env-var opt-in. Explicit ``trace_sink=`` kwarg on
    SpecPipeline() always wins.
    """
    import os

    sink_name = os.environ.get("KAIROS_TRACE_SINK", "").strip().lower()
    if not sink_name or sink_name == "noop":
        return NoopTraceSink()
    if sink_name == "supabase":
        try:
            from kairos.trace import SupabaseTraceSink
            # SupabaseTraceSink constructor is best-effort — if env is
            # missing SUPABASE_SERVICE_ROLE_KEY, it falls back internally
            # to a no-op mode. We do not swallow its constructor exceptions
            # to surface misconfiguration loudly.
            return SupabaseTraceSink()
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.warning(
                "KAIROS_TRACE_SINK=supabase set but SupabaseTraceSink "
                "failed to construct (%s: %s). Falling back to "
                "NoopTraceSink to preserve customer-wheel privacy "
                "default. Set SUPABASE_SERVICE_ROLE_KEY + "
                "SUPABASE_URL for fleet-mode trace persistence.",
                type(exc).__name__, exc,
            )
            return NoopTraceSink()
    logger.warning(
        "KAIROS_TRACE_SINK=%r is not a recognized sink name "
        "(expected 'noop' or 'supabase'). Falling back to NoopTraceSink.",
        sink_name,
    )
    return NoopTraceSink()


# ── VerifierRegistry ──────────────────────────────────────────────────


class VerifierRegistry:
    """Thin registry mapping tier_name -> VerifierPlugin instance.

    Customer plugins register their VerifierPlugin at import via
    ``DEFAULT_REGISTRY.register(plugin)``. The registry reads the
    plugin's ``tier_name`` attribute — plugins that fail to set it
    are rejected at registration.
    """

    def __init__(self) -> None:
        self._plugins: dict[str, Any] = {}

    def register(self, plugin: Any, /) -> None:
        """Add ``plugin`` to the registry under its ``tier_name``
        attribute.

        Raises ``ValueError`` when the plugin has no string
        ``tier_name`` (every VerifierPlugin must declare one) OR when
        the tier is already held by a DIFFERENT instance. Re-registering
        the SAME instance is a no-op — that lets
        :func:`kairos.verticals.register_defaults` be idempotent.

        ATH-526: when ``plugin.is_stub`` is True, emits a WARN log so
        the operator notices a stub-mode plugin is in the registry.
        Customers who want stub plugins in production must register
        them explicitly (i.e. not via ``register_defaults()``); a
        WARN every time keeps the no-mocks-no-lying contract visible.
        """
        tier_name = getattr(plugin, "tier_name", None)
        if not isinstance(tier_name, str) or not tier_name:
            raise ValueError(
                f"VerifierPlugin {plugin!r} has no string tier_name — "
                f"required for registration"
            )
        if tier_name in self._plugins and self._plugins[tier_name] is not plugin:
            raise ValueError(
                f"tier_name collision: {tier_name!r} already "
                f"registered as {self._plugins[tier_name]!r}"
            )
        # ATH-526: surface stub-mode registrations. Treat missing attr
        # as False (don't break existing customer plugins that haven't
        # adopted the new field yet).
        if getattr(plugin, "is_stub", False):
            logger.warning(
                "VerifierPlugin %r registered as is_stub=True (tier=%s); "
                "verify() will not close the declared tier. "
                "Excluded from register_defaults() — explicit registration only.",
                type(plugin).__name__, tier_name,
            )
        self._plugins[tier_name] = plugin

    def lookup(self, tier_name: str, /) -> Any:
        """Return the plugin registered under ``tier_name``.

        Raises ``KeyError`` when no plugin is registered for that tier;
        the error message lists the known tiers so customers see what
        IS available (pipeline's tolerance of unregistered tiers via
        SpecPipeline.run lives one layer up; this is the raw lookup).
        """
        if tier_name not in self._plugins:
            raise KeyError(
                f"no VerifierPlugin registered for tier {tier_name!r}; "
                f"known tiers: {sorted(self._plugins)}"
            )
        return self._plugins[tier_name]

    def registered_tiers(self) -> list[str]:
        """Return the sorted list of tier names with plugins registered.

        Deterministic ordering so introspection output (used in
        diagnostic log messages + customer dashboards) is stable
        across runs.
        """
        return sorted(self._plugins)


DEFAULT_REGISTRY = VerifierRegistry()


# ── SpecPipeline ──────────────────────────────────────────────────────


@dataclass
class RunResult:
    """Output of one SpecPipeline.run().

    Carries the orchestration choice, per-tier Verdicts, any
    escalations fired, and the final aggregated score.
    """

    orchestration: OrchestrationChoice
    verdicts_by_tier: dict[str, Verdict]
    score: float
    escalations: list[EscalationEvent] = field(default_factory=list)
    # Stream D (ATH-519): cumulative LLM spend for this run, in USD.
    # Reported on every run; 0.0 when no orchestrator tracked cost
    # (e.g. DefaultRoundRobinOrchestrator has no LLM calls).
    cost_usd: float = 0.0
    # True when the run halted early because cost_budget_usd was set on
    # run() and the cumulative spend exceeded it. Tiers that did not
    # dispatch are missing from verdicts_by_tier; an EscalationEvent
    # with trigger='budget_exhausted' is present in escalations.
    budget_exhausted: bool = False
    # ATH-526: tier_names of stub-mode plugins (is_stub=True) consulted
    # during this run. Empty when no stub plugins fired. Customer
    # dashboards can show a "stub plugin" badge — the verdict on those
    # tiers does NOT close the declared tier; it's a dry-run probe.
    used_stub_plugins: list[str] = field(default_factory=list)


class SpecPipeline:
    """Top-level spec-closing pipeline. 7 injected plugin protocols.

    All 7 plugin protocols are injected via constructor kwargs with
    sane defaults. Customer wheels override any combination.

    Defaults:
        orchestrator      = kairos.fleet.Orchestrator()   # LLM-backed, model=opus-4.6 by default (ATH-570)
        trace_sink        = NoopTraceSink()           # customer privacy default
        verifier_registry = DEFAULT_REGISTRY          # shared module registry
        prompt_loader     = FilesystemPromptLoader()  # reads from bundled prompts
        scoring_fn        = DefaultScoring()          # verdict-outcome -> score
        tool_registry     = DEFAULT_TOOL_REGISTRY     # shared module registry
        model_selector    = DefaultModelSelector(config)  # tier -> model_id

    Customer-agent callers who want the no-LLM path pass
    ``orchestrator=DefaultRoundRobinOrchestrator(config)`` explicitly.
    Swap the planner model via ``Orchestrator(model="openai/kimi-k2.6-1")``
    or use :func:`kairos.fleet.orchestrate` for the one-line fleet call.

    Config resolution (when ``config`` is not passed):
        explicit kwargs > KAIROS_CONFIG env > pyproject.toml > defaults

    Example:

        from kairos.spec.pipeline import SpecPipeline
        from kairos.spec.defaults import DefaultRoundRobinOrchestrator
        from kairos.spec.types import KairosConfig

        config = KairosConfig(drafter_model="openai/gpt-5")
        pipeline = SpecPipeline(
            orchestrator=DefaultRoundRobinOrchestrator(config),
            config=config,
        )
        result = pipeline.run(spec)
    """

    def __init__(
        self,
        *,
        orchestrator: OrchestratorPlugin | None = None,
        trace_sink: TraceSink | None = None,
        verifier_registry: VerifierRegistry | None = None,
        prompt_loader: PromptLoader | None = None,
        scoring_fn: ScoringFn | None = None,
        tool_registry: ToolRegistryPlugin | None = None,
        model_selector: ModelSelectorPlugin | None = None,
        config: KairosConfig | None = None,
    ) -> None:
        # Resolve config once; defaults that need it see the resolved value.
        self.config: KairosConfig = resolve_config(explicit=config)

        # Default orchestrator is kairos.fleet.Orchestrator (ATH-570).
        # Lazy import keeps spec.pipeline free of a top-level dependency
        # on kairos.fleet (which imports from spec.types itself).
        if orchestrator is not None:
            self.orchestrator: OrchestratorPlugin = orchestrator
        else:
            from kairos.fleet import Orchestrator as _FleetOrchestrator
            self.orchestrator = _FleetOrchestrator(config=self.config)
        self.trace_sink: TraceSink = (
            trace_sink if trace_sink is not None
            else _default_trace_sink()
        )
        self.verifier_registry: VerifierRegistry = (
            verifier_registry if verifier_registry is not None
            else DEFAULT_REGISTRY
        )
        self.prompt_loader: PromptLoader = (
            prompt_loader if prompt_loader is not None
            else FilesystemPromptLoader(self.config.prompts_dir)
        )
        self.scoring_fn: ScoringFn = (
            scoring_fn if scoring_fn is not None else DefaultScoring()
        )
        self.tool_registry: ToolRegistryPlugin = (
            tool_registry if tool_registry is not None
            else DEFAULT_TOOL_REGISTRY
        )
        self.model_selector: ModelSelectorPlugin = (
            model_selector if model_selector is not None
            else DefaultModelSelector(self.config)
        )

    def run(
        self,
        intent: Mapping[str, Any],
        /,
        *,
        run_id: str | None = None,
        cost_budget_usd: float | None = None,
    ) -> RunResult:
        """Close a spec by running the full verifier-tier dispatch.

        Gate 5 MVP: happy-path orchestration. Deep budget / cancel /
        retry / escalation-trigger firing lands inline with Gate 6
        prompts + Gate 9 kairos.fleet.Orchestrator.

        Sequence:
            1. Orchestrator plans tier_dispatch + tool/model/prompt choices
            2. For each tier, look up VerifierPlugin + invoke .verify()
            3. Collect Verdicts into RunResult
            4. Score via ScoringFn
            5. Emit trace events to TraceSink at each step

        The method tolerates an empty tier_registry (returns a
        score-0 RunResult with an empty verdicts dict) so tests can
        exercise the plumbing without registering real verifiers.

        Emits typed TraceEvent objects (ATH-498 kairos.trace) to the
        configured TraceSink. Caller-supplied ``run_id`` is used
        as the FK to solve_runs; if omitted, a fresh UUID is
        generated so every pipeline run has a stable handle.

        ``cost_budget_usd`` (Stream D / ATH-519) sets a cumulative-spend
        cap for this run. The cap is enforced between tier dispatches —
        if the orchestrator's cumulative LLM cost (as reported via
        ``OrchestrationChoice.rationale`` or a ``cost_usd`` attribute
        on the orchestrator) exceeds the budget, the pipeline fires
        an ``EscalationEvent(trigger='budget_exhausted')`` and
        short-circuits remaining tiers. Set ``cost_budget_usd=None``
        (the default) to disable the cap. Cumulative cost is always
        surfaced via ``RunResult.cost_usd`` regardless of whether a
        cap was set.
        """
        resolved_run_id = run_id or str(uuid.uuid4())
        sequence = 0  # monotonic per-run
        # Stream D: cumulative per-run spend. Populated by `_cost_so_far`
        # which reads from the orchestrator if it exposes a cost signal.
        budget_exhausted = False
        # Track escalations early so the budget-exhausted path can add to
        # the same list that's returned on the RunResult.
        escalations: list[EscalationEvent] = []

        # 0. Integrity gate (Todd 2026-04-22 demo + Aidan 2026-04-24 21:00Z):
        # If the intent carries an integrity_hash (meaning the customer or an
        # upstream sign() step hash-locked it), verify the hash BEFORE any
        # orchestrator / verifier touches the intent. Tampered intents short-
        # circuit with an integrity_violation escalation + an empty-verdicts
        # RunResult. Unsigned intents (no hash present) pass through — signing
        # remains opt-in; once signed, verification is mandatory.
        integrity_violation = self._check_integrity(intent, resolved_run_id)
        if integrity_violation is not None:
            escalations.append(integrity_violation)
            self._emit_trace(
                run_id=resolved_run_id,
                sequence=sequence,
                event_type="integrity_violation",
                payload={
                    "reason": integrity_violation.context.get("reason", ""),
                    "integrity_version": integrity_violation.context.get(
                        "integrity_version", INTEGRITY_VERSION,
                    ),
                },
            )
            # Return a bare RunResult so callers don't have to special-case
            # the raise path. verdicts_by_tier is empty + score is 0.
            stub_choice = OrchestrationChoice(
                tier_dispatch=[], tool_selection=[],
                model_selection={}, prompt_selection={},
                rationale="integrity_violation_short_circuit",
            )
            return RunResult(
                orchestration=stub_choice,
                verdicts_by_tier={},
                score=0.0,
                escalations=escalations,
                cost_usd=0.0,
            )

        # 1. Plan.
        choice = self.orchestrator.orchestrate(
            intent,
            tier_registry=self.verifier_registry,
            tool_registry=self.tool_registry,
            model_selector=self.model_selector,
            prompt_loader=self.prompt_loader,
        )
        # ATH-818 G4: when the LLM-backed orchestrator fell back to
        # DefaultRoundRobinOrchestrator, surface WHY in the trace so
        # /solve-runs/[id] doesn't render the round-robin dispatch as
        # if the customer chose it. The rationale on the choice itself
        # describes round-robin's pick; this event explains the failure
        # that caused the LLM-tier-planner to be skipped.
        if getattr(choice, "fallback_reason", None):
            primary_model = getattr(self.orchestrator, "model", None)
            self._emit_trace(
                run_id=resolved_run_id,
                sequence=sequence,
                event_type="orchestrator_fallback",
                payload={
                    "primary_model": primary_model,
                    "fallback_to": "DefaultRoundRobinOrchestrator",
                    "reason": choice.fallback_reason,
                },
            )
            sequence += 1
        self._emit_trace(
            run_id=resolved_run_id,
            sequence=sequence,
            event_type="orchestration_choice",
            payload={
                "tier_dispatch": list(choice.tier_dispatch),
                "cache_hit": choice.cache_hit,
                "rationale": choice.rationale,
            },
        )
        sequence += 1

        # 2. Dispatch each tier. Skip tiers that have no registered plugin
        # (logged, not fatal) so plugin authors can extend incrementally.
        verdicts_by_tier: dict[str, Verdict] = {}
        # ATH-526: collect tier_names of any stub-mode plugins consulted
        # so the RunResult exposes them to customer dashboards.
        used_stub_plugins: list[str] = []
        # ATH-657 sub-b: when the orchestrator emits a refinement_chain
        # (multi-level Lean → ... → RTL), iterate hops and thread
        # per-hop artifacts via the registry's per-hop input dict; halt
        # at the first non-proved verdict (refinement is sequential by
        # construction). Otherwise fall through to the flat
        # tier_dispatch loop preserved below.
        if choice.refinement_chain:
            chain_artifacts: dict[str, Any] = {}
            for hop in choice.refinement_chain:
                tier = hop.tier
                try:
                    plugin = self.verifier_registry.lookup(tier)
                except KeyError:
                    logger.info(
                        "SpecPipeline: refinement_chain hop %r has no "
                        "VerifierPlugin; skipping", tier,
                    )
                    continue
                if getattr(plugin, "is_stub", False):
                    used_stub_plugins.append(tier)
                hop_input: dict[str, Any] = {
                    "lean_module": hop.lean_module,
                    "ebmc_target": hop.ebmc_target,
                }
                if hop.proof_artifact_in and hop.proof_artifact_in in chain_artifacts:
                    hop_input["proof_artifact_in"] = chain_artifacts[hop.proof_artifact_in]
                try:
                    verdict = plugin.verify(intent, hop_input)
                except Exception as exc:  # noqa: BLE001 — broad-catch fallback
                    verdict = Verdict(
                        source=getattr(plugin, "tier_name", "unknown"),
                        outcome="error",
                        reason=f"plugin raised {type(exc).__name__}: {exc}",
                        details={"exception_type": type(exc).__name__},
                    )
                verdicts_by_tier[tier] = verdict
                self._emit_trace(
                    run_id=resolved_run_id,
                    sequence=sequence,
                    event_type="refinement_hop_verdict",
                    payload={
                        "tier": tier,
                        "lean_module": hop.lean_module,
                        "ebmc_target": hop.ebmc_target,
                        "outcome": verdict.outcome,
                        "cost_usd": self._cost_so_far(),
                    },
                )
                sequence += 1
                # Carry the hop's emitted artifact forward.
                if hop.proof_artifact_out:
                    chain_artifacts[hop.proof_artifact_out] = verdict.details
                # Halt at first non-proved — refinement chain is sequential.
                if verdict.outcome != "proved":
                    self._emit_trace(
                        run_id=resolved_run_id,
                        sequence=sequence,
                        event_type="refinement_chain_halted",
                        payload={
                            "halted_at_tier": tier,
                            "outcome": verdict.outcome,
                            "reason": verdict.reason,
                            "hops_completed": [t for t in verdicts_by_tier],
                        },
                    )
                    sequence += 1
                    break
            # Skip the flat tier_dispatch loop below — chain dispatch handled it.
            tiers_to_dispatch: list[str] = []
        else:
            tiers_to_dispatch = list(choice.tier_dispatch)
        for tier in tiers_to_dispatch:
            # Stream D: budget gate before each tier. Check cumulative
            # cost against the cap BEFORE dispatching the next tier so
            # one tier's overage doesn't compound; fire escalation +
            # break out of the loop on exhaustion.
            current_cost = self._cost_so_far()
            if (
                cost_budget_usd is not None
                and current_cost > cost_budget_usd
            ):
                budget_exhausted = True
                escalations.append(
                    self._emit_escalation(
                        run_id=resolved_run_id,
                        sequence=sequence,
                        trigger="budget_exhausted",
                        plugin_type="orchestrator",
                        context={
                            "reason": "cumulative_cost_exceeded_budget",
                            "cost_usd": current_cost,
                            "budget_usd": cost_budget_usd,
                            "tiers_completed": list(verdicts_by_tier),
                            "tiers_skipped": [
                                t for t in choice.tier_dispatch
                                if t not in verdicts_by_tier
                            ],
                        },
                    )
                )
                sequence += 1
                break

            try:
                plugin = self.verifier_registry.lookup(tier)
            except KeyError:
                logger.info(
                    "SpecPipeline: no VerifierPlugin for tier %r; skipping",
                    tier,
                )
                continue
            # ATH-526: track stub plugins consulted on this run so the
            # RunResult can carry the badge to customer dashboards.
            if getattr(plugin, "is_stub", False):
                used_stub_plugins.append(tier)
            try:
                verdict = plugin.verify(intent, {})
            except Exception as exc:  # plugin exception -> Verdict.error  # noqa: BLE001 — broad-catch fallback
                verdict = Verdict(
                    source=getattr(plugin, "tier_name", "unknown"),
                    outcome="error",
                    reason=f"plugin raised {type(exc).__name__}: {exc}",
                    details={"exception_type": type(exc).__name__},
                )
            verdicts_by_tier[tier] = verdict
            # ATH-834: include verdict.reason + verdict.details so the
            # platform can render the actual proof artifacts. Pre-fix
            # only {tier, outcome, source, cost_usd} reached Supabase
            # — customers saw "outcome: proved" with no per-property
            # breakdown (BMC: property_verdicts + bound_k; Lean:
            # compiles + has_sorry + axiom_audit_match; refuted runs:
            # the counterexample). The data exists locally on the
            # Verdict dataclass; just thread it into the payload.
            self._emit_trace(
                run_id=resolved_run_id,
                sequence=sequence,
                event_type="tier_verdict",
                payload={
                    "tier": tier,
                    "outcome": verdict.outcome,
                    "source": verdict.source,
                    "cost_usd": self._cost_so_far(),
                    "reason": verdict.reason,
                    # Permissive — verifier-specific shape. trace_schema
                    # registers tier_verdict as _LooseProbe (ATH-818 G1)
                    # so no schema bump needed. Defensive dict() in case
                    # the verdict was constructed with an unhashable
                    # Mapping subclass.
                    "details": dict(verdict.details) if verdict.details else {},
                },
            )
            sequence += 1

        # 3. Must-use-tool-before-handoff gate (ATH-499 Tier 1 slice 2).
        # If the pipeline returns without at least one non-error verdict,
        # the orchestrator handed off without any VerifierPlugin actually
        # running — classic effort-gaming shape. Fire an escalation so a
        # reviewer is forced to look. Non-fatal (RunResult still returned)
        # so tests + customer plumbing can observe the signal instead of
        # swallowing an exception.
        # Budget exhaustion short-circuits the must-use-tool gate — the
        # pipeline halted because of cost, not because the orchestrator
        # misbehaved; the budget escalation is already in the list.
        valid_outcomes = {"proved", "refuted", "unknown", "vacuous"}
        n_valid = sum(
            1 for v in verdicts_by_tier.values() if v.outcome in valid_outcomes
        )
        if n_valid == 0 and not budget_exhausted:
            escalations.append(
                self._emit_escalation(
                    run_id=resolved_run_id,
                    sequence=sequence,
                    trigger="reviewer_flagged",
                    plugin_type="orchestrator",
                    context={
                        "reason": "handoff_without_valid_verifier_invocation",
                        "tier_dispatch": list(choice.tier_dispatch),
                        "verdicts_outcomes": {
                            t: v.outcome for t, v in verdicts_by_tier.items()
                        },
                    },
                )
            )
            sequence += 1

        # 4. Score. Aggregate across tiers = max of per-tier scores
        # (any tier that proves is a success). Plugins that want
        # different aggregation (min, weighted avg) subclass ScoringFn.
        per_tier_scores = [
            self.scoring_fn.score(v, {}) for v in verdicts_by_tier.values()
        ]
        final_score = max(per_tier_scores) if per_tier_scores else 0.0

        return RunResult(
            orchestration=choice,
            verdicts_by_tier=verdicts_by_tier,
            score=final_score,
            escalations=escalations,
            cost_usd=self._cost_so_far(),
            budget_exhausted=budget_exhausted,
            used_stub_plugins=used_stub_plugins,
        )

    def _check_integrity(
        self, intent: Mapping[str, Any], run_id: str,
    ) -> EscalationEvent | None:
        """Gate the run on a hash-signed intent (Aidan 2026-04-24 21:00Z).

        Returns ``None`` when the intent is unsigned (no ``meta.integrity_hash``)
        or verifies cleanly. Returns an :class:`EscalationEvent` with
        ``trigger='stakes_above_threshold'`` when verification fails; callers
        short-circuit on that signal.

        Signing remains opt-in; once a caller has signed the intent with
        :func:`kairos.spec.integrity.sign`, the pipeline refuses to run a
        tampered copy. That matches Todd's 2026-04-22 demo ask ("once a
        spec is formalized, the fleet cannot mess with it").
        """
        meta = intent.get("meta") if isinstance(intent, Mapping) else None
        has_hash = (
            isinstance(meta, Mapping)
            and meta.get("integrity_hash") is not None
        )
        if not has_hash:
            return None
        try:
            _verify_integrity(intent)
            return None
        except IntegrityError as exc:
            # Reuse the stakes_above_threshold trigger from Q3 plumbing —
            # spec tampering is a stakes-elevation signal. Specific reason
            # lives in context.
            theorem_id = ""
            try:
                intent_map = intent if isinstance(intent, Mapping) else {}
                ident = intent_map.get("identifier") or {}
                if isinstance(ident, Mapping):
                    theorem_id = str(
                        ident.get("name") or ident.get("id") or ""
                    )
            except Exception:  # noqa: BLE001 — theorem ident dict shape varies across drafters; default empty string
                pass
            return EscalationEvent(
                run_id=run_id,
                theorem_id=theorem_id,
                trigger="stakes_above_threshold",
                plugin_type="builtin",
                context={
                    "reason": str(exc),
                    "integrity_error_class": type(exc).__name__,
                    "integrity_version": INTEGRITY_VERSION,
                },
            )

    def _cost_so_far(self) -> float:
        """Cumulative LLM spend for the current pipeline run, in USD.

        Reads from the orchestrator's optional ``cost_usd`` attribute
        OR its optional ``cost_tracker.total_cost_usd`` property, whichever
        is present. Orchestrators that track no cost (e.g. the default
        round-robin, which makes no LLM calls) return 0.0. Missing
        attributes are a feature not a bug — customer orchestrators can
        opt into budget gating by exposing either shape.
        """
        orch = self.orchestrator
        # Preferred shape: orchestrator.cost_usd (simple float attribute).
        cost = getattr(orch, "cost_usd", None)
        if isinstance(cost, (int, float)):
            return float(cost)
        # Alternate shape: orchestrator.cost_tracker (kairos.builder.
        # cost_tracker.CostTracker with .total_cost_usd property).
        tracker = getattr(orch, "cost_tracker", None)
        if tracker is not None:
            total = getattr(tracker, "total_cost_usd", None)
            if isinstance(total, (int, float)):
                return float(total)
        return 0.0

    def _emit_trace(
        self, *, run_id: str, sequence: int, event_type: str,
        payload: Mapping[str, Any],
    ) -> None:
        """Build a TraceEvent and forward to the configured TraceSink.

        Swallows any sink exceptions (the Protocol contract is that
        sinks never raise, but a buggy plugin might). TraceSink
        failures must not block pipeline progress.
        """
        event = TraceEvent(
            run_id=run_id,
            run_type="sdk_orchestration",
            run_subtype="spec_pipeline",
            event_type=event_type,
            sequence=sequence,
            payload=dict(payload),
        )
        try:
            self.trace_sink.emit(event)
        except Exception:  # pragma: no cover — defence in depth
            logger.exception(
                "TraceSink.emit raised on event %r; "
                "this is a Protocol violation — plugin should catch+log, not raise",
                event,
            )

    def _emit_escalation(
        self,
        *,
        run_id: str,
        sequence: int,
        trigger: str,
        plugin_type: str,
        context: Mapping[str, Any],
    ) -> EscalationEvent:
        """Build an EscalationEvent, forward to TraceSink, return it.

        Caller appends the returned event to RunResult.escalations so the
        in-process consumer sees the same object as the out-of-process
        TraceSink. Sink exceptions are swallowed — escalation visibility
        to the customer's trace store is best-effort, pipeline never
        fails because a sink misbehaves.
        """
        event = EscalationEvent(
            run_id=run_id,
            theorem_id=str(context.get("theorem_id", "")) or "unknown",
            trigger=trigger,  # type: ignore[arg-type]  -- Literal narrowed at call site
            plugin_type=plugin_type,  # type: ignore[arg-type]
            context=dict(context),
        )
        try:
            self.trace_sink.emit_escalation(event)
        except Exception:  # pragma: no cover — defence in depth
            logger.exception(
                "TraceSink.emit_escalation raised on event %r; "
                "sink should catch+log, not raise",
                event,
            )
        return event
