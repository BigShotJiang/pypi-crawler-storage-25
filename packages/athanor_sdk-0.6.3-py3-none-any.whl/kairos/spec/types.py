"""kairos.spec.types — 7 plugin protocols + KairosConfig (Gate 5, ATH-497).

Per the 2026-04-23 scope-lock (Aidan extensibility directive + platform
7-protocol lock) every configuration point in the SDK exposes an
extension hook. This module defines the Protocol surfaces customer
plugins + default impls conform to.

The purity taxonomy (qa ConformanceSuite consumes these at test-
collection time):

- **PURE**: same input -> same output, no side effects, cache-safe.
- **IMPURE_LOOKUP**: reads from a registry; lookup result cacheable
  but underlying registry may mutate across process lifetime.
- **IMPURE_DETERMINISTIC**: subprocess / GPU / model calls; same
  input -> same output modulo wall-time and transient failures.
- **IMPURE_SIDE_EFFECTFUL**: DB writes, file writes, network POSTs.
  Must be idempotent on duplicate input.

Each Protocol's docstring carries explicit ``:purity:`` /
``:idempotence:`` / ``:side_effects:`` tags. qa's
ConformanceSuite reads these at test-collection and dispatches to
the matching fixture family. See
tests/test_every_plugin_protocol_has_purity_tag — grep-test that
ensures no new Protocol lands without the taxonomy metadata.

Single source of truth: if a Protocol's semantics change, edit the
docstring here first, then reconcile the conformance suite fixtures.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping, Protocol, TYPE_CHECKING, runtime_checkable

# TraceSink + event dataclasses + escalation types live canonically in
# kairos.trace (ATH-498, PR #109). Gate 5 re-exports them here so
# downstream callers that grab types.py as the "one place for spec
# types" have a single import path. kairos.trace is source of truth.
from kairos.trace import (
    EscalationEvent,
    EscalationTrigger,
    NoopTraceSink,
    PluginTypeTag,
    TraceEvent,
    TraceSink,
)

if TYPE_CHECKING:
    from kairos.spec_v1 import IntentV1


# ── Purity taxonomy ────────────────────────────────────────────────────


class Purity(str, enum.Enum):
    """Purity classes qa's ConformanceSuite dispatches on.

    Inherits from ``str`` so the enum value serialises directly into
    docstring-tags + JSON logs without a separate ``.value`` call.
    """

    PURE = "PURE"
    IMPURE_LOOKUP = "IMPURE_LOOKUP"
    IMPURE_DETERMINISTIC = "IMPURE_DETERMINISTIC"
    IMPURE_SIDE_EFFECTFUL = "IMPURE_SIDE_EFFECTFUL"


# ── Verdict / OrchestrationChoice carriers ────────────────────────────


CounterexampleKind = Literal[
    "bmc_trace",          # raw trace block from EBMC/CBMC — payload.trace carries the text
    "compile_error",      # Lean / type-checker failed to compile — payload.errors is a list[str]
    "axiom_violation",    # Lean proof used a banned token — payload.banned is the token
    "process_failure",    # verifier subprocess exited non-zero — payload has exit_code + stderr_tail
    "policy_diverge",     # policy engines (cedar-policy vs cedar-go) diverged — payload has per-engine outcome
    "other",              # plugin-specific shape; see payload
]


@dataclass(frozen=True)
class Counterexample:
    """Unified carrier for verifier refutation evidence (ATH-523).

    When a VerifierPlugin returns ``Verdict.outcome == 'refuted'``, it
    MUST populate ``details['counterexample']`` with a Counterexample
    instance. Before ATH-523 each plugin shoved an ad-hoc dict shape
    into ``details`` and downstream callers (prove.refined_prompt_suggestion,
    refiner agents) had to sniff plugin-specific keys; the unified
    shape lets any reader pull a one-line ``summary`` for prompts +
    dig into ``payload`` only for tier-specific debugging.

    Serialises via :meth:`as_dict` — use that (not ``dataclasses.asdict``)
    when the Counterexample is nested inside ``Verdict.details`` so the
    downstream dict stays JSON-friendly.

    :purity: N/A (dataclass, not a callable)
    """

    kind: CounterexampleKind
    # One-line, prompt-safe summary. Callers feed this directly to
    # refiner LLMs; keep it under ~200 chars, no trailing newline,
    # no ANSI colour. Plugin-specific extras go in payload.
    summary: str
    payload: Mapping[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-safe dict representation of this Counterexample."""
        return {
            "kind": self.kind,
            "summary": self.summary,
            "payload": dict(self.payload),
        }


@dataclass(frozen=True)
class Verdict:
    """Canonical outcome of a verifier / orchestrator call.

    The outcome taxonomy is closed and lives here so every plugin
    reports the same five shapes. Downstream gates switch on
    ``outcome`` + dig into ``details`` when they need engine / bound /
    tier metadata.

    When ``outcome == 'refuted'`` the plugin MUST populate
    ``details['counterexample']`` with a :class:`Counterexample`
    instance (ATH-523 unified shape). Older plugin-specific keys like
    ``details['errors']`` / ``details['banned']`` remain available as
    payload contents inside the Counterexample.

    :purity: N/A (dataclass, not a callable)
    """

    source: str                            # plugin name or backend identifier
    outcome: Literal["proved", "refuted", "unknown", "error", "timeout"]
    reason: str
    wall_seconds: float = 0.0
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RefinementHop:
    """One hop in a multi-level Lean → ... → RTL refinement chain.

    ATH-657 sub-b. When a customer's spec describes a stack of
    abstraction levels (M0 functional → M1 pipeline → M2 microarch →
    M3 RTL) the Orchestrator emits a list of these in
    ``OrchestrationChoice.refinement_chain`` and ``SpecPipeline.run``
    iterates them in order, threading each hop's verdict-details into
    the next hop's input via ``proof_artifact_in``/``out`` keys.
    """

    tier: str                              # e.g. "lean_machines_proved" / "bmc_kind"
    lean_module: str | None = None         # "LeanMachinesExamples.MyChain.M1"
    ebmc_target: str | None = None         # "rtl/cpu_top.sv:cpu_top"
    proof_artifact_in: str | None = None   # key from prior hop's Verdict.details
    proof_artifact_out: str = ""           # key the hop emits for the next


@dataclass(frozen=True)
class OrchestrationChoice:
    """Output of an OrchestratorPlugin's planning step.

    ``kairos.fleet.Orchestrator`` returns one of these; the no-LLM
    :class:`DefaultRoundRobinOrchestrator` also returns one. Customer
    plugins may subclass if they need to carry extra per-choice
    metadata.
    """

    tier_dispatch: list[str]               # ordered tier names to attempt
    tool_selection: list[str]              # ordered tool names for this run
    model_selection: Mapping[str, str]     # tier_name -> model_id
    prompt_selection: Mapping[str, str]    # tier_name -> prompt_template_name
    rationale: str                         # human-readable; goes to TraceSink
    cache_hit: bool = False                # True when served from cache
    # ATH-657 sub-b: optional multi-level refinement chain. When set,
    # SpecPipeline.run iterates hops in order rather than dispatching
    # tier_dispatch flatly. tier_dispatch stays as the fallback path
    # for non-refinement specs.
    refinement_chain: tuple[RefinementHop, ...] | None = None
    # ATH-818 G4: when an LLM-backed orchestrator (kairos.fleet.Orchestrator)
    # fails to call its model and degrades to DefaultRoundRobinOrchestrator,
    # it sets this field on the choice it returns so SpecPipeline can emit
    # an `orchestrator_fallback` trace event explaining WHY the LLM-tier-
    # planner didn't fire. None when no fallback occurred (cache hit, LLM
    # success, or DefaultRoundRobinOrchestrator was the explicit choice).
    # Format: "<ExcType>: <truncated message>" so downstream renderers can
    # split on ": " for the type vs the cause.
    fallback_reason: str | None = None


# TraceSink + TraceEvent + EscalationEvent + EscalationTrigger +
# PluginTypeTag + NoopTraceSink are imported above from kairos.trace.
# Don't redefine here — qa's PR #109 (ATH-498) is the source of truth.


# ── The 7 plugin protocols ────────────────────────────────────────────


@runtime_checkable
class VerifierPlugin(Protocol):
    """Run a verifier against an IntentV1 witness, return a Verdict.

    :purity: IMPURE_DETERMINISTIC
    :idempotence: same (intent, witness) -> same Verdict modulo
        wall_seconds + transient subprocess errors
    :side_effects: subprocess / GPU / model calls; no database
        writes, no file writes outside declared working dir

    Returns Verdict with outcome in the closed 5-value taxonomy.
    Plugins that close a new evidence tier register the tier via
    ``kairos.spec_v1.register_tier(tier_name)`` at import so the
    KNOWN_TIERS registry + validate_tier() helper pick it up.

    When outcome == "proved", Verdict.details SHOULD carry
    ``proved_label`` (see ATH-491 PROVED_BMC_BOUNDED vs
    PROVED_KIND_UNBOUNDED example) + ``bound_k`` when applicable.
    Downstream gates consume those without re-plumbing call args.
    """

    tier_name: str
    """Evidence tier this plugin produces. Registered into
    ``kairos.spec_v1.KNOWN_TIERS`` at module import.

    ATH-526 — optional ``is_stub: bool`` convention: plugins MAY
    declare a class attribute ``is_stub = True`` to mark themselves as
    witness-validation / dry-run-probe placeholders that do NOT close
    their declared tier (see ATH-514 cedar plugin during the
    implementation-pending phase). When set:

      * :meth:`VerifierRegistry.register` emits a WARN log so the
        operator notices a stub-mode plugin is in the registry.
      * :func:`kairos.verticals.register_defaults` skips the plugin —
        customers who want stub plugins must register them explicitly.
      * :class:`RunResult.used_stub_plugins` lists tier_names of stub
        plugins consulted so customer dashboards can show a badge.

    The convention is read via ``getattr(plugin, 'is_stub', False)``
    so older plugins that don't declare the attribute still register
    cleanly (treated as non-stub). Production plugins SHOULD set
    ``is_stub = False`` explicitly so the no-mocks-no-lying intent is
    visible at the call site. Kept off the runtime Protocol surface
    deliberately — adding it as a required attribute would break
    isinstance() for every existing plugin that hasn't yet adopted
    the annotation."""

    def verify(
        self, intent: "IntentV1", witness: Mapping[str, Any], /,
        *, timeout_sec: float | None = None,
    ) -> Verdict:
        """Run the verifier; return a Verdict. Raise only on
        unrecoverable internal errors (not on 'theorem refuted' —
        that's a Verdict.outcome == 'refuted', not an exception)."""
        ...


@runtime_checkable
class OrchestratorPlugin(Protocol):
    """Plan which tiers + tools + models + prompts to run for a spec.

    :purity: IMPURE_DETERMINISTIC (when backed by an LLM agent like
        :class:`kairos.fleet.Orchestrator`) or PURE (when backed by a
        deterministic policy like :class:`DefaultRoundRobinOrchestrator`)
    :idempotence: MAY be cached by (theorem_hash, tier_registry_version,
        tool_registry_version). Plugins that cache should populate
        OrchestrationChoice.cache_hit.
    :side_effects: LLM calls when impure; none when pure

    Subsumes the earlier ReviewerSequencer + Arbitrator roles per
    2026-04-23 scope consolidation. Orchestrator owns per-run
    strategy; Verifiers own per-tier proof mechanics.
    """

    def orchestrate(
        self, intent: "IntentV1", /,
        *, tier_registry: "VerifierRegistry",
        tool_registry: "ToolRegistryPlugin",
        model_selector: "ModelSelectorPlugin",
        prompt_loader: "PromptLoader",
    ) -> OrchestrationChoice:
        """Return one OrchestrationChoice; never raise on
        well-formed input. On transient failures (LLM 5xx, network),
        impure orchestrators fall back to a deterministic default
        and set ``rationale`` to explain the degradation."""
        ...


# TraceSink Protocol imported from kairos.trace (see top of file).
# Keeps this module focused on the 6 spec-layer protocols; trace +
# escalation wiring is qa's kairos.trace module (ATH-498 PR #109).


@runtime_checkable
class PromptLoader(Protocol):
    """Load a prompt template by (tier, template_name) key.

    :purity: PURE
    :idempotence: same (tier, template_name) -> same string always,
        cache-safe for the process lifetime
    :side_effects: none at lookup time (template files may be read
        on first-miss but are effectively-immutable post-ship)

    FilesystemPromptLoader ships as default (reads from
    ``solve/shared/prompts/``). Customer plugins override to ship
    entirely different prompt suites.
    """

    def load(self, tier: str, template_name: str, /) -> str:
        """Return the template string. Raise PromptMissing when
        the (tier, template_name) pair is not registered for this
        loader — never return empty string silently."""
        ...


@runtime_checkable
class ScoringFn(Protocol):
    """Score a completed Verdict against its acceptance criteria.

    :purity: PURE
    :idempotence: same (verdict, criteria) -> same Score always
    :side_effects: none

    Customer plugins define domain-specific scoring beyond our
    built-in verdict taxonomy. Score values stay in a known range
    (callers document); plugin raises on invalid criteria shape.
    """

    def score(
        self, verdict: Verdict, criteria: Mapping[str, Any], /,
    ) -> float:
        """Return a scalar score. Raise ValueError on malformed
        criteria — never silently return 0.0 on bad input."""
        ...


@runtime_checkable
class ToolRegistryPlugin(Protocol):
    """Look up an invocable tool by name.

    :purity: IMPURE_LOOKUP
    :idempotence: same tool_name -> same Tool object (cacheable)
    :side_effects: none at lookup time — side effects live in the
        Tool itself when it's invoked

    Customer extensibility: plugins add custom SMT solvers,
    proprietary DSLs, or internal IR front-ends by registering
    here. Orchestrators select tool_names via OrchestrationChoice.
    """

    def lookup(self, tool_name: str, /) -> Any:
        """Return the invocable Tool (opaque object) for the given
        name. Raise KeyError when tool_name is not registered —
        never return None silently."""
        ...

    def list_tools(self) -> list[str]:
        """Enumerate registered tool names. Stable ordering so
        callers can key-seed deterministic choices off this."""
        ...


@runtime_checkable
class ModelSelectorPlugin(Protocol):
    """Pick an LLM model id for a tier.

    :purity: PURE
    :idempotence: same (tier, theorem_shape) -> same model_id always
    :side_effects: none

    Customer override: customers with provisioned Claude/GPT/local-
    Ollama inference want to pin specific models per tier. Default
    impl reads from KairosConfig.drafter_model / reviewer_model.
    """

    def select(
        self, tier: str, theorem_shape: Mapping[str, Any], /,
    ) -> str:
        """Return a model id string. Raise ValueError on unknown
        tier."""
        ...


# ── KairosConfig + resolver ────────────────────────────────────────────


@dataclass
class KairosConfig:
    """Resolved configuration for a SpecPipeline run.

    Resolution priority (highest first):
    1. Explicit kwargs passed to SpecPipeline()
    2. KAIROS_CONFIG env var pointing at a TOML/JSON file
    3. [tool.kairos] table in pyproject.toml in cwd or a parent
    4. Built-in defaults (this dataclass's field defaults)

    Matches the black/ruff/mypy config-resolution shape so customer
    expectations transfer.
    """

    # ATH-816: defaults sourced from kairos.model_presets so the literal
    # lives in one auditable place. Lazy import keeps the spec types
    # module light at import time.
    drafter_model: str = field(
        default_factory=lambda: __import__(
            "kairos.model_presets", fromlist=["DEFAULT_PROVE_DRAFTER_MODEL"]
        ).DEFAULT_PROVE_DRAFTER_MODEL
    )
    reviewer_model: str = field(
        default_factory=lambda: __import__(
            "kairos.model_presets", fromlist=["DEFAULT_PROVE_REVIEWER_MODEL"]
        ).DEFAULT_PROVE_REVIEWER_MODEL
    )
    default_tier_dispatch: tuple[str, ...] = (
        "lean_proved", "bmc_bounded", "empirical",
    )
    budget_usd: float = 6.0
    walltime_sec: int = 1800
    escalation_stakes: Literal["internal", "customer-facing"] = "internal"
    prompts_dir: Path | None = None        # None -> use FilesystemPromptLoader default

    # Plugin registry keys (string IDs resolved at pipeline-init time
    # against the respective registries). Keeping these as strings
    # lets TOML config files reference plugins without importing
    # Python objects.
    #
    # ``orchestrator_plugin`` legacy values: "opus" historically meant
    # the LLM-backed orchestrator (now ``kairos.fleet.Orchestrator``,
    # ATH-570 rename) and "round_robin" meant
    # ``DefaultRoundRobinOrchestrator``. The default below preserves
    # back-compat for any TOML config still using "opus"; new callers
    # should pass an Orchestrator instance to SpecPipeline directly.
    orchestrator_plugin: str = "opus"      # "opus" | "round_robin" | custom
    tool_registry_plugin: str = "default"
    model_selector_plugin: str = "default"


def resolve_config(
    *, explicit: KairosConfig | None = None,
    env_var: str = "KAIROS_CONFIG",
    pyproject_path: Path | None = None,
) -> KairosConfig:
    """Produce a KairosConfig from the resolution-order hierarchy.

    Explicit kwargs win; env-var-pointed file overrides pyproject;
    pyproject overrides defaults. File-loading failures fall through
    to the next tier (never hard-fail on a missing optional source).

    :purity: IMPURE_LOOKUP (reads files + env)
    """
    if explicit is not None:
        return explicit

    import os
    # tomllib is stdlib on 3.11+; fall back to tomli on 3.10 so the
    # SDK loads on both CI matrix rows (3.10 + 3.12). tomli is in
    # dev-deps via transitive pull from pytest-toml tooling or can be
    # skipped entirely — we catch ImportError and degrade to no
    # pyproject / env-var config reading (returns defaults).
    try:
        import tomllib  # type: ignore[import-not-found]
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[import-not-found]
        except ImportError:
            # No TOML reader available — degrade gracefully.
            return KairosConfig()

    config_data: dict[str, Any] = {}

    # Tier 3: pyproject.toml [tool.kairos] (lowest-priority file source)
    if pyproject_path is None:
        pyproject_path = _find_pyproject(Path.cwd())
    if pyproject_path is not None and pyproject_path.exists():
        try:
            with pyproject_path.open("rb") as f:
                data = tomllib.load(f)
            kairos_cfg = data.get("tool", {}).get("kairos", {})
            config_data.update(kairos_cfg)
        except (OSError, tomllib.TOMLDecodeError):
            pass  # fall through — pyproject reading is best-effort

    # Tier 2: env-var-pointed file (overrides pyproject)
    env_path = os.environ.get(env_var)
    if env_path:
        p = Path(env_path)
        if p.exists():
            try:
                with p.open("rb") as f:
                    config_data.update(tomllib.load(f))
            except (OSError, tomllib.TOMLDecodeError):
                pass  # fall through — env pointer is best-effort

    return _dict_to_config(config_data)


def _find_pyproject(start: Path) -> Path | None:
    """Walk up from `start` looking for pyproject.toml; return
    the first hit or None. Stops at filesystem root."""
    for parent in (start, *start.parents):
        candidate = parent / "pyproject.toml"
        if candidate.exists():
            return candidate
    return None


def _dict_to_config(data: Mapping[str, Any]) -> KairosConfig:
    """Project a loose dict onto KairosConfig fields. Unknown keys
    are ignored (LENIENT — forward-compat with future config fields
    via old pipeline versions).
    """
    known_fields = {f for f in KairosConfig.__dataclass_fields__}
    filtered = {k: v for k, v in data.items() if k in known_fields}
    # default_tier_dispatch in TOML is a list; cast to tuple.
    if "default_tier_dispatch" in filtered:
        filtered["default_tier_dispatch"] = tuple(filtered["default_tier_dispatch"])
    # prompts_dir as str -> Path
    if "prompts_dir" in filtered and filtered["prompts_dir"] is not None:
        filtered["prompts_dir"] = Path(filtered["prompts_dir"])
    return KairosConfig(**filtered)


# ── Exception surface ────────────────────────────────────────────────


class PromptMissing(KeyError):
    """Raised by PromptLoader.load when (tier, template_name) has
    no registered template. Distinct from generic KeyError so
    callers can catch the narrow case without swallowing real bugs.
    """


class OrchestrationMalformed(ValueError):
    """Raised by OrchestratorPlugin.orchestrate when an LLM-backed
    orchestrator returns an un-parseable or invalid
    OrchestrationChoice. Distinct from ValueError so the fallback
    path can catch it specifically.
    """


class OrchestrationInvalidPlugin(ValueError):
    """Raised when an orchestrator returns a plugin/tier name not
    present in the registry (LLM hallucination failure mode).
    """
