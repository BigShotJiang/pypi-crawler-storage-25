"""kairos.spec.defaults — default plugin implementations for SpecPipeline.

Five defaults ship with the SDK. The LLM-backed orchestrator lives in
:mod:`kairos.fleet` (``kairos.fleet.Orchestrator``, ATH-570 2026-04-24)
— not here, so ``kairos.spec.defaults`` stays the no-LLM-dep home and
``kairos.fleet`` is the one place to find orchestration.

Customer wheels that don't register their own plugins get these as the
``smart-by-default`` path.

Design invariant: every default impl passes the matching ConformanceSuite
subclass. That's how customer plugin authors know "conform to the same
contract as the default" — the default is the reference implementation
qa's suite measures against.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping

from kairos.spec.types import (
    KairosConfig,
    OrchestrationChoice,
    OrchestratorPlugin,
    PromptLoader,
    PromptMissing,
    ModelSelectorPlugin,
    ScoringFn,
    ToolRegistryPlugin,
    TraceSink,
    Verdict,
)
# NoopTraceSink lives in kairos.trace (ATH-498 PR #109); re-export for
# convenience so callers that grab kairos.spec.defaults as the "default
# plugins" module have one import path. kairos.trace is source of truth.

logger = logging.getLogger(__name__)


# ── PromptLoader ───────────────────────────────────────────────────────


class FilesystemPromptLoader:
    """Load prompt templates from a directory on disk.

    :purity: PURE (modulo filesystem contents, which are
        effectively-immutable post-ship)
    :idempotence: same (tier, template_name) -> same string every time
    :side_effects: filesystem read on first-miss (cached thereafter)

    Directory layout:

        <prompts_dir>/<tier>/<template_name>.md

    Example:

        solve/shared/prompts/lean_proved/spec_draft_llm.md
        solve/shared/prompts/bmc_bounded/spec_coherence_llm.md
    """

    def __init__(self, prompts_dir: Path | None = None) -> None:
        if prompts_dir is None:
            # Default to the repo-local solve/shared/prompts/ path. For
            # customer wheels this is the bundled prompt directory.
            from kairos import spec as _spec_pkg
            prompts_dir = Path(_spec_pkg.__file__).parent / "prompts"
        self._prompts_dir = prompts_dir
        self._cache: dict[tuple[str, str], str] = {}

    def load(self, tier: str, template_name: str, /) -> str:
        key = (tier, template_name)
        if key in self._cache:
            return self._cache[key]
        path = self._prompts_dir / tier / f"{template_name}.md"
        if not path.exists():
            raise PromptMissing(
                f"no prompt template at {path} — "
                f"tier={tier!r} template_name={template_name!r} "
                f"prompts_dir={self._prompts_dir!r}"
            )
        text = path.read_text()
        if not text.strip():
            raise PromptMissing(
                f"prompt file is empty at {path} — "
                f"tier={tier!r} template_name={template_name!r}"
            )
        self._cache[key] = text
        return text


# ── ModelSelector ──────────────────────────────────────────────────────


class DefaultModelSelector:
    """Reads per-tier model from KairosConfig.

    :purity: PURE
    :idempotence: same (tier, shape) -> same model_id
    :side_effects: none

    Tier 'lean_proved' + 'kind_unbounded' use reviewer_model (Opus
    by default); 'bmc_bounded' + 'empirical' use drafter_model
    (Sonnet by default). Customer plugins override to pin specific
    models per tier.
    """

    # Tier -> which KairosConfig field to pick the model from.
    _TIER_TO_CONFIG_FIELD: Mapping[str, str] = {
        "lean_proved": "reviewer_model",
        "kind_unbounded": "reviewer_model",
        "bmc_bounded": "drafter_model",
        "empirical": "drafter_model",
    }

    def __init__(self, config: KairosConfig) -> None:
        self._config = config

    def select(
        self, tier: str, theorem_shape: Mapping[str, Any], /,
    ) -> str:
        del theorem_shape  # default ignores shape; customer plugins may not
        field_name = self._TIER_TO_CONFIG_FIELD.get(tier)
        if field_name is None:
            # Unknown tier (plugin-registered) falls back to drafter.
            # Customer plugins that want different default behavior
            # implement their own ModelSelectorPlugin.
            return self._config.drafter_model
        return getattr(self._config, field_name)


# ── ScoringFn ─────────────────────────────────────────────────────────


class DefaultScoring:
    """Built-in scoring function: 1.0 for proved, 0.5 for unknown,
    0.0 for refuted/error/timeout.

    :purity: PURE
    :idempotence: same (verdict, criteria) -> same score
    :side_effects: none
    """

    _OUTCOME_SCORES: Mapping[str, float] = {
        "proved": 1.0,
        "unknown": 0.5,
        "refuted": 0.0,
        "error": 0.0,
        "timeout": 0.0,
    }

    def score(
        self, verdict: Verdict, criteria: Mapping[str, Any], /,
    ) -> float:
        del criteria  # default scoring ignores criteria; customer plugins don't
        if verdict.outcome not in self._OUTCOME_SCORES:
            raise ValueError(
                f"unknown Verdict.outcome={verdict.outcome!r} — "
                f"expected one of {sorted(self._OUTCOME_SCORES)}"
            )
        return self._OUTCOME_SCORES[verdict.outcome]


# ── ToolRegistry ──────────────────────────────────────────────────────


class DefaultToolRegistry:
    """In-memory tool registry. Customer plugins extend by calling
    ``register(name, tool)`` at import time.

    :purity: IMPURE_LOOKUP
    :idempotence: same name -> same tool object
    :side_effects: none at lookup
    """

    def __init__(self) -> None:
        self._tools: dict[str, Any] = {}

    def register(self, name: str, tool: Any, /) -> None:
        """Idempotent-on-same-object registration. Raise when a
        different object is registered under an existing name
        (collision) so customers catch drift early."""
        if name in self._tools and self._tools[name] is not tool:
            raise ValueError(
                f"tool name collision: {name!r} already registered "
                f"as {self._tools[name]!r}; refusing to overwrite"
            )
        self._tools[name] = tool

    def lookup(self, tool_name: str, /) -> Any:
        if tool_name not in self._tools:
            raise KeyError(
                f"tool {tool_name!r} not registered; "
                f"known: {sorted(self._tools)}"
            )
        return self._tools[tool_name]

    def list_tools(self) -> list[str]:
        return sorted(self._tools)


# Seed the shared default registry at module load. Customer plugins
# `from kairos.spec.defaults import DEFAULT_TOOL_REGISTRY` and call
# `.register()` on it at import time.
DEFAULT_TOOL_REGISTRY = DefaultToolRegistry()


# ── OrchestratorPlugin — two impls ───────────────────────────────────


class DefaultRoundRobinOrchestrator:
    """Fixed-sequence orchestrator — canary path + safe fallback.

    :purity: PURE
    :idempotence: same intent -> same OrchestrationChoice always
    :side_effects: none

    Stays in the SDK as the fallback when the smart LLM-backed
    :class:`kairos.fleet.Orchestrator` hits transient errors. Tier
    dispatch follows ``KairosConfig.default_tier_dispatch``.
    """

    def __init__(self, config: KairosConfig) -> None:
        self._config = config

    def orchestrate(
        self,
        intent: Any, /,
        *,
        tier_registry: Any,
        tool_registry: ToolRegistryPlugin,
        model_selector: ModelSelectorPlugin,
        prompt_loader: PromptLoader,
    ) -> OrchestrationChoice:
        del tier_registry, prompt_loader  # round-robin doesn't introspect these

        # If IntentV1 carries an explicit `vertical` field AND it maps
        # to a known tier in _VERTICAL_TO_TIER, narrow dispatch to that
        # tier. Unknown / absent → fall back to default_tier_dispatch.
        # This lets `kairos prove --nl` target a single vertical while
        # preserving legacy callers' default fan-out behaviour.
        vertical = None
        if isinstance(intent, Mapping):
            v = intent.get("vertical")
            if isinstance(v, str) and v and v in _VERTICAL_TO_TIER:
                vertical = _VERTICAL_TO_TIER[v]

        if vertical:
            tier_dispatch = [vertical]
            rationale_suffix = (
                f" — routed to intent.vertical → tier {vertical!r}."
            )
        else:
            tier_dispatch = list(self._config.default_tier_dispatch)
            rationale_suffix = (
                " — intent.vertical not in _VERTICAL_TO_TIER; "
                "using default_tier_dispatch."
            )

        model_selection = {
            tier: model_selector.select(tier, {}) for tier in tier_dispatch
        }
        # Default round-robin uses every registered tool, in order.
        tool_selection = tool_registry.list_tools()
        return OrchestrationChoice(
            tier_dispatch=tier_dispatch,
            tool_selection=tool_selection,
            model_selection=model_selection,
            prompt_selection={
                tier: "spec_draft_llm" for tier in tier_dispatch
            },
            rationale=(
                "DefaultRoundRobinOrchestrator"
                + rationale_suffix
                + " No per-theorem LLM-tier planning; "
                "kairos.fleet.Orchestrator adds that (ATH-570)."
            ),
        )


# Vertical-name → tier-name map. Used by DefaultRoundRobinOrchestrator
# when IntentV1.vertical is set. Kept in one place so nl_frontend +
# verticals registry share a single source of truth.
#
# Keys match kairos.verticals.nl_frontend._VERTICAL_TEMPLATES; values
# match the plugin tier_name in kairos.verticals.*.
_VERTICAL_TO_TIER: dict[str, str] = {
    "ebmc": "bmc_bounded",       # sv_cbmc template → SysVerilogEBMCPlugin
    "lean": "lean_proved",          # lean template → LeanProofPlugin
    # NKI has no nl_frontend template yet; falls through to
    # default_tier_dispatch when the intent doesn't carry `vertical`.
}

