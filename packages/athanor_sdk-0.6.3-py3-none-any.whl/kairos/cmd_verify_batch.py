"""ATH-701 + ATH-679 — `kairos verify-batch <dir>` CLI for bulk Lean verification.

Walks a directory of `.lean` files, runs each through
`kairos.lean.verify_proof`, and reports a summary. Free tier
(no license required — `verify_proof` is free per the tier doc).

## Usage

    kairos verify-batch ./proofs/
    kairos verify-batch ./proofs/ --recursive
    kairos verify-batch ./proofs/ --json
    kairos verify-batch ./proofs/ --summary
    kairos verify-batch ./proofs/ --out report.csv --timeout 120 --workers 8
    kairos verify-batch ./proofs/ --lake-project ./my-pythia/ --recursive

## Output formats

- Default: tabular human-readable. One line per file with
  PASS / FAIL / SORRY status + sorry count + filename.
- `--json`: one parseable JSON object per line. For CI / scripting.
- `--summary`: same tabular shape as default but minus the per-file
  detail — just the aggregate (`N files, M proved, K failed, X with
  sorry`).
- `--out report.csv`: CSV with the columns the ATH-679 spec calls
  out: `path, compiles, has_sorry, sorry_count, score, banned,
  errors_first_line, elapsed_sec`. Opens cleanly in Excel + pandas.

## Parallelism + incremental writes (ATH-679)

`--workers N` (default 4) runs verify_proof calls through a
``ThreadPoolExecutor``. CSV writes flush after every completion so a
Ctrl-C still leaves a partial-but-readable file. The parallel path
keeps tabular / JSON / summary outputs deterministic by sorting
results by file path before rendering.

## Exit codes

- 0: every file passed (proof compiles, no banned constructs).
- 1: at least one file failed.
- 2: invalid CLI usage (missing dir, malformed flag).

## Why a separate module

The handler is non-trivial (path walking + per-file verify + render
across formats + parallel + incremental CSV) so I'm putting it in a
dedicated module rather than inlining in `cli.py`.
"""
from __future__ import annotations

import argparse
import csv
import fnmatch
import json
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import IO, Callable, Optional


_DEFAULT_TIMEOUT_SEC = 120
_DEFAULT_WORKERS = 4
# CSV column order matches ATH-679 §Output exactly so customers
# scripting against the report don't have to guess.
_CSV_COLUMNS = (
    "path", "compiles", "has_sorry", "sorry_count", "score",
    "banned", "errors_first_line", "elapsed_sec",
)


@dataclass
class _FileResult:
    """One verify-batch row. Used internally + serialized to JSON / CSV."""
    file: str
    status: str  # "proved" | "failed" | "sorry" | "error"
    score: float
    sorry_count: int
    error: str = ""
    # ATH-679 additions — CSV needs separate compiles / banned / wall.
    compiles: bool = False
    has_sorry: bool = False
    banned: bool = False
    errors_first_line: str = ""
    elapsed_sec: float = 0.0


def _walk_lean_files(directory: Path, recursive: bool) -> list[Path]:
    """Return every `.lean` file in `directory`. Recursive when flagged."""
    if not directory.is_dir():
        return []
    pattern = "**/*.lean" if recursive else "*.lean"
    return sorted(directory.glob(pattern))


def _read_gitignore_patterns(directory: Path) -> list[str]:
    """Return `.gitignore` glob patterns rooted at ``directory``.

    Honors only the directory-root ``.gitignore`` (not nested ones —
    that requires the full git pathspec engine and isn't worth the
    dependency cost for a CLI helper). Empty list when no file exists
    or it can't be read. Comment lines (``#``) and blanks are dropped.
    """
    gi = directory / ".gitignore"
    if not gi.is_file():
        return []
    try:
        text = gi.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    patterns: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Negation patterns (`!foo`) aren't supported; skip them rather
        # than misapply.
        if line.startswith("!"):
            continue
        patterns.append(line)
    return patterns


def _matches_gitignore(rel_path: Path, patterns: list[str]) -> bool:
    """True iff ``rel_path`` matches any of ``patterns`` (fnmatch-style).

    Match is checked against the path itself + every parent directory
    component, mirroring how git resolves a single pattern against a
    nested file. Trailing-slash patterns (``build/``) are treated as
    directory matches: any descendant under that name is excluded.
    """
    s = rel_path.as_posix()
    for pat in patterns:
        # Directory-only pattern (`foo/`) → match any path component.
        if pat.endswith("/"):
            stripped = pat.rstrip("/")
            for part in rel_path.parts:
                if fnmatch.fnmatch(part, stripped):
                    return True
            continue
        if fnmatch.fnmatch(s, pat):
            return True
        # Also match the basename — git applies leaf patterns to any
        # depth.
        if fnmatch.fnmatch(rel_path.name, pat):
            return True
    return False


def _imports_pythia(path: Path) -> bool:
    """ATH-700: True iff the file's source contains an `import Pythia.X`
    line at the top.

    Scoped to a tiny linear scan — we only need to know whether the
    file is Pythia-flavored, not parse the Lean import graph fully.
    Tolerant of leading whitespace + Lean line comments. False on read
    failure (caller skips from the Pythia-only filter).
    """
    try:
        text = path.read_text()
    except OSError:
        return False
    for line in text.splitlines():
        stripped = line.lstrip()
        if not stripped or stripped.startswith("--"):
            continue
        if stripped.startswith("import "):
            target = stripped.split(maxsplit=1)[1]
            if target.startswith("Pythia"):
                return True
            continue
        return False
    return False


def _verify_one(
    path: Path,
    *,
    lake_project: Optional[Path] = None,
    timeout: int = _DEFAULT_TIMEOUT_SEC,
) -> _FileResult:
    """Run `verify_proof` on one file. NEVER raises — captures
    failure into the result row.

    ``lake_project``, when set, is forwarded to ``verify_proof`` so
    the Lean file resolves project-internal imports (Mathlib +
    project deps) instead of being checked as a bare file.
    """
    from kairos.lean import verify_proof

    t_start = time.time()
    try:
        source = path.read_text()
    except OSError as e:
        return _FileResult(
            file=str(path), status="error", score=0.0,
            sorry_count=0, error=f"read failed: {e}",
            errors_first_line=f"read failed: {e}",
            elapsed_sec=time.time() - t_start,
        )

    kwargs: dict = {"timeout": timeout}
    if lake_project is not None:
        kwargs["lake_project"] = str(lake_project)
        # The standard convention: module path = relative file path
        # under lake_project, with separators → dots, .lean stripped.
        try:
            rel = path.resolve().relative_to(lake_project.resolve())
            kwargs["module_path"] = str(rel.with_suffix("")).replace("/", ".")
        except ValueError:
            # File is outside lake_project; fall through to bare-file
            # mode by clearing the lake_project kwarg.
            kwargs.pop("lake_project", None)

    try:
        result = verify_proof(source, **kwargs)
    except Exception as e:  # noqa: BLE001
        return _FileResult(
            file=str(path), status="error", score=0.0,
            sorry_count=0, error=f"verify_proof raised: {e}",
            errors_first_line=f"verify_proof raised: {type(e).__name__}",
            elapsed_sec=time.time() - t_start,
        )

    compiles = bool(getattr(result, "compiles", False))
    proved = compiles or bool(getattr(result, "proved", False))
    has_sorry = bool(getattr(result, "has_sorry", False))
    sorry_count = int(getattr(result, "sorry_count", 0)
                       or (1 if has_sorry else 0))
    score = float(getattr(result, "score", 0.0))
    banned_field = getattr(result, "banned", None)
    banned = bool(banned_field)

    if proved and sorry_count == 0 and not banned:
        status = "proved"
    elif proved and sorry_count > 0:
        status = "sorry"
    else:
        status = "failed"

    err_text = ""
    first_line = ""
    errs = getattr(result, "errors", None)
    if errs:
        # ``errors`` may be a list[str] or a stringified blob. Normalize
        # to "first line" + "joined string truncated to 200" so both
        # CSV and tabular views render readably.
        if isinstance(errs, (list, tuple)) and errs:
            first_line = str(errs[0])[:300]
            err_text = "; ".join(str(e) for e in errs)[:200]
        else:
            err_text = str(errs)[:200]
            first_line = err_text.splitlines()[0] if err_text else ""

    return _FileResult(
        file=str(path), status=status, score=score,
        sorry_count=sorry_count, error=err_text,
        compiles=compiles, has_sorry=has_sorry, banned=banned,
        errors_first_line=first_line,
        elapsed_sec=time.time() - t_start,
    )


def _to_csv_row(r: _FileResult) -> dict:
    """Project a _FileResult into the ATH-679 CSV column shape."""
    return {
        "path": r.file,
        "compiles": "true" if r.compiles else "false",
        "has_sorry": "true" if r.has_sorry else "false",
        "sorry_count": r.sorry_count,
        "score": f"{r.score:.4f}",
        "banned": "true" if r.banned else "false",
        "errors_first_line": r.errors_first_line,
        "elapsed_sec": f"{r.elapsed_sec:.3f}",
    }


def _open_csv_writer(out_path: Path) -> tuple[IO[str], "csv.DictWriter"]:
    """Open ``out_path`` for line-buffered CSV writes + emit the header.

    Line buffering (``buffering=1``) means every ``writer.writerow``
    that follows lands on disk after the underlying ``\\n`` so a
    Ctrl-C leaves the partial CSV intact. Writer + handle returned;
    caller is responsible for closing.
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fh = out_path.open("w", buffering=1, encoding="utf-8", newline="")
    writer = csv.DictWriter(fh, fieldnames=list(_CSV_COLUMNS))
    writer.writeheader()
    fh.flush()
    return fh, writer


def _run_verifications(
    files: list[Path],
    *,
    lake_project: Optional[Path],
    timeout: int,
    workers: int,
    csv_writer: Optional["csv.DictWriter"] = None,
    csv_flush: Optional[Callable[[], None]] = None,
) -> list[_FileResult]:
    """Execute verify_proof across ``files`` with up to ``workers``
    threads. When ``csv_writer`` is supplied, write each row as it
    completes + flush after every write so an interrupted run leaves a
    partial-but-readable CSV.

    Returned list is sorted by file path so downstream tabular / JSON /
    summary renderers stay deterministic regardless of completion
    order.
    """
    if not files:
        return []
    workers = max(1, min(workers, len(files)))
    rows: list[_FileResult] = []
    csv_lock = threading.Lock()

    def _task(p: Path) -> _FileResult:
        return _verify_one(p, lake_project=lake_project, timeout=timeout)

    if workers == 1:
        # Single-threaded path: simpler stack frames + matches old
        # ATH-701 ordering for tabular output.
        for p in files:
            r = _task(p)
            rows.append(r)
            if csv_writer is not None:
                csv_writer.writerow(_to_csv_row(r))
                if csv_flush is not None:
                    csv_flush()
        return rows

    with ThreadPoolExecutor(max_workers=workers) as pool:
        fut_to_path = {pool.submit(_task, p): p for p in files}
        for fut in as_completed(fut_to_path):
            r = fut.result()
            rows.append(r)
            if csv_writer is not None:
                with csv_lock:
                    csv_writer.writerow(_to_csv_row(r))
                    if csv_flush is not None:
                        csv_flush()

    rows.sort(key=lambda r: r.file)
    return rows


def _render_tabular(rows: list[_FileResult]) -> str:
    """Default human-readable rendering."""
    if not rows:
        return "(no .lean files found)"
    headers = ("STATUS", "SCORE", "SORRY", "FILE")
    lines = [headers]
    for r in rows:
        status_disp = {
            "proved": "PASS",
            "sorry":  "SORRY",
            "failed": "FAIL",
            "error":  "ERROR",
        }[r.status]
        lines.append((
            status_disp,
            f"{r.score:.2f}",
            str(r.sorry_count) if r.sorry_count else "-",
            r.file,
        ))
    widths = [
        max(len(line[i]) for line in lines)
        for i in range(len(headers))
    ]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    out = [fmt.format(*line) for line in lines]
    proved = sum(1 for r in rows if r.status == "proved")
    sorry_n = sum(1 for r in rows if r.status == "sorry")
    failed = sum(1 for r in rows if r.status in ("failed", "error"))
    out.append("")
    out.append(
        f"summary: {len(rows)} files — {proved} proved, "
        f"{sorry_n} sorry, {failed} failed"
    )
    return "\n".join(out)


def _render_summary_only(rows: list[_FileResult]) -> str:
    """Just the aggregate, no per-file detail."""
    if not rows:
        return "0 files"
    proved = sum(1 for r in rows if r.status == "proved")
    sorry_n = sum(1 for r in rows if r.status == "sorry")
    failed = sum(1 for r in rows if r.status in ("failed", "error"))
    return (
        f"{len(rows)} files — {proved} proved, "
        f"{sorry_n} sorry, {failed} failed"
    )


def _auto_detect_lake_project(directory: Path) -> Path | None:
    """Walk up from directory to find lakefile.toml or lakefile.lean."""
    d = directory.resolve()
    for _ in range(20):
        if (d / "lakefile.toml").exists() or (d / "lakefile.lean").exists():
            return d
        parent = d.parent
        if parent == d:
            break
        d = parent
    return None


def cmd_verify_batch(args: argparse.Namespace) -> int:
    """`kairos verify-batch` entry. Returns shell exit code."""
    directory = Path(args.directory)
    if not directory.exists():
        print(f"error: directory not found: {directory}", file=sys.stderr)
        return 2
    if not directory.is_dir():
        print(f"error: not a directory: {directory}", file=sys.stderr)
        return 2

    files = _walk_lean_files(directory, recursive=args.recursive)

    if args.pythia_only:
        files = [p for p in files if _imports_pythia(p)]

    # ATH-679: respect .gitignore if the directory has one. Cuts out
    # build/ + .lake/ + tmp test artifacts that would otherwise dominate
    # a recursive sweep on a real project.
    if not getattr(args, "no_gitignore", False):
        patterns = _read_gitignore_patterns(directory)
        if patterns:
            base = directory.resolve()
            files = [
                p for p in files
                if not _matches_gitignore(p.resolve().relative_to(base), patterns)
            ]

    out_path: Optional[Path] = None
    if getattr(args, "out", None):
        out_path = Path(args.out)

    csv_fh: Optional[IO[str]] = None
    csv_writer: Optional["csv.DictWriter"] = None
    csv_flush: Optional[Callable[[], None]] = None
    try:
        if out_path is not None:
            csv_fh, csv_writer = _open_csv_writer(out_path)
            csv_flush = csv_fh.flush

        lake_project_arg = getattr(args, "lake_project", None)
        if lake_project_arg:
            lake_project = Path(lake_project_arg)
        else:
            lake_project = _auto_detect_lake_project(directory)
            if lake_project is not None:
                print(
                    f"[verify-batch] auto-detected lake project: {lake_project}",
                    file=sys.stderr,
                )
        rows = _run_verifications(
            files,
            lake_project=lake_project,
            timeout=int(getattr(args, "timeout", _DEFAULT_TIMEOUT_SEC)),
            workers=int(getattr(args, "workers", _DEFAULT_WORKERS)),
            csv_writer=csv_writer, csv_flush=csv_flush,
        )
    finally:
        if csv_fh is not None:
            csv_fh.close()

    if args.json_out:
        for r in rows:
            print(json.dumps(asdict(r)))
    elif args.summary:
        print(_render_summary_only(rows))
    elif out_path is not None:
        # When writing CSV, the human-facing console output is the
        # one-line summary so the operator sees what landed on disk.
        print(f"wrote {len(rows)} row(s) to {out_path}")
        print(_render_summary_only(rows))
    else:
        print(_render_tabular(rows))

    has_failure = any(r.status in ("failed", "error") for r in rows)
    return 1 if has_failure else 0


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Register `verify-batch` on a top-level subparsers action."""
    p = sub.add_parser(
        "verify-batch",
        help="Bulk-verify every .lean file in a directory (free tier).",
    )
    p.add_argument(
        "directory",
        help="Directory containing .lean files to verify.",
    )
    p.add_argument(
        "--recursive", action="store_true",
        help="Walk subdirectories. Default: top-level only.",
    )
    p.add_argument(
        "--json", action="store_true", dest="json_out",
        help="One JSON object per file, for CI scripting.",
    )
    p.add_argument(
        "--summary", action="store_true",
        help="Aggregate-only output (one line: total / proved / sorry / failed).",
    )
    p.add_argument(
        "--pythia-only", action="store_true", dest="pythia_only",
        help="Filter to .lean files that `import Pythia.X` (ATH-700). "
             "Useful for sweeping a customer's existing Pythia-flavored "
             "proofs without churning on unrelated Lean modules.",
    )
    # ATH-679 additions.
    p.add_argument(
        "--out", metavar="REPORT.CSV", default=None,
        help="Write a CSV report to the given path. Columns: "
             + ", ".join(_CSV_COLUMNS) + ". Writes are flushed per-row "
             "so a Ctrl-C leaves a partial-but-readable file.",
    )
    p.add_argument(
        "--timeout", type=int, default=_DEFAULT_TIMEOUT_SEC,
        help=f"Per-file verify_proof timeout in seconds. "
             f"Default {_DEFAULT_TIMEOUT_SEC}.",
    )
    p.add_argument(
        "--lake-project", metavar="PATH", default=None,
        help="Treat .lean files as members of this Lake project so "
             "Mathlib + project deps resolve. When unset, files are "
             "verified as bare Lean source (no imports beyond core).",
    )
    p.add_argument(
        "--workers", type=int, default=_DEFAULT_WORKERS,
        help=f"Parallel verify_proof workers. Default {_DEFAULT_WORKERS}; "
             f"set to 1 for deterministic ordering.",
    )
    p.add_argument(
        "--no-gitignore", action="store_true", dest="no_gitignore",
        help="Don't honor the directory-root .gitignore when walking. "
             "Default: skip files matching .gitignore patterns.",
    )


__all__ = [
    "add_subparser",
    "cmd_verify_batch",
]
