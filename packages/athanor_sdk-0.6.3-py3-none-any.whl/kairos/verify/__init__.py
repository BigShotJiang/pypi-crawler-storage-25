"""kairos.verify — verification infrastructure for VerifierPlugins.

Umbrella package for the SDK's verification subsystem:

* :mod:`kairos.verify.plugin` — ``VerifierPlugin`` Protocol, the 7
  ConformanceSuite contract tests (Gate 7 / ATH-497), and the Tier-1
  source-code anti-cheat detectors (ATH-499) used at PR-review time
  + publish-gate.

Why it's a separate package from ``kairos.spec``:

``kairos.spec`` owns the pipeline + orchestration contract (how
verifiers are dispatched). ``kairos.verify`` owns the verifier
surface itself (Protocol contract, conformance tests, anti-cheat
detection). Keeping them separate lets customers who only need the
Protocol definitions import ``from kairos.verify.plugin import
VerifierPlugin`` without pulling the whole spec-pipeline graph.

Cross-ref:

* ATH-497 — Gate 7 ConformanceSuite (merged PR #113)
* ATH-499 — Tier 1 anti-cheat detectors (merged PR #116, #118, #124)
* docs/agent-capability-model.md — the platform-side design doc this
  verification layer anchors to (ATH-501)
"""
