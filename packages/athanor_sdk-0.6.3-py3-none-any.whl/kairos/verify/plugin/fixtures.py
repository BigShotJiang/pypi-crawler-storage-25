"""kairos.verify.plugin.fixtures — shared mock factories for ConformanceSuites.

Building blocks subclass suites reuse for contract tests. Kept in one
module so a change to IntentV1 / Verdict / TraceEvent shapes only
requires updating one place — drift protection.
"""

from __future__ import annotations

from typing import Any, Mapping
from uuid import uuid4


def make_intent(
    *,
    target_file: str = "HowardBridge/MasterTheorem.lean",
    target_name: str = "master_sharp_slack_avg_univ",
    kind: str = "theorem",
    vertical: str = "lean",
    evidence_tier: str = "lean_proved",
) -> dict:
    """Minimal IntentV1-shaped dict for conformance-suite drivers.

    Uses dict + str keys rather than the IntentV1 TypedDict so the
    fixture is resilient across (uncommon) TypedDict rename/restructure
    churn. Subsitute with a real IntentV1 in production paths.
    """
    return {
        "intent_version": "1.1",
        "planner_role": "lean_theorem_prover_generic",
        "target": {"file": target_file, "name": target_name, "kind": kind},
        "goal": {"lemma_closed": True},
        "vertical": vertical,
        "budget": {"wall_seconds": 1800, "usd": 6.00},
        "evidence_tier": evidence_tier,
        "bound_k": 10,
        "meta": {},  # integrity_hash populated later by sign()
    }


def make_witness(**overrides: Any) -> Mapping[str, Any]:
    """Minimal witness dict for VerifierPlugin.verify(intent, witness).

    Witness shape is plugin-specific; the conformance suite doesn't
    assume much. Callers can pass overrides to exercise specific
    code paths (e.g. a 'proof_content' key for Lean verifiers).
    """
    base = {"witness_id": str(uuid4())}
    base.update(overrides)
    return base


def make_trace_event(*, sequence: int = 0, **overrides: Any) -> "Any":
    """Construct a TraceEvent for TraceSinkConformance tests.

    Lazily imports kairos.trace.TraceEvent so this fixtures module
    doesn't force the import graph when unused (subtle: keeps
    fixtures.py cheap for suites that don't touch traces).
    """
    from kairos.trace import TraceEvent
    return TraceEvent(
        run_id=overrides.pop("run_id", "conformance-run"),
        run_type=overrides.pop("run_type", "sdk_orchestration"),
        run_subtype=overrides.pop("run_subtype", "spec_pipeline"),
        event_type=overrides.pop("event_type", "conformance_probe"),
        sequence=sequence,
        payload=overrides.pop("payload", {}),
        **overrides,
    )


def make_escalation_event(
    *,
    trigger: str = "axiom_introducing",
    plugin_type: str = "verifier",
    **overrides: Any,
) -> "Any":
    """Construct an EscalationEvent for TraceSinkConformance tests."""
    from kairos.trace import EscalationEvent
    return EscalationEvent(
        run_id=overrides.pop("run_id", "conformance-run"),
        theorem_id=overrides.pop("theorem_id", "conformance-theorem"),
        trigger=trigger,  # type: ignore[arg-type]  -- Literal narrowed in caller context
        plugin_type=plugin_type,  # type: ignore[arg-type]
        context=overrides.pop("context", {}),
        **overrides,
    )


def make_verdict(
    *,
    outcome: str = "proved",
    source: str = "test-plugin",
    **overrides: Any,
) -> "Any":
    """Construct a Verdict dataclass for ScoringFnConformance tests."""
    from kairos.spec.types import Verdict
    return Verdict(
        source=source,
        outcome=outcome,  # type: ignore[arg-type]
        reason=overrides.pop("reason", "conformance test"),
        wall_seconds=overrides.pop("wall_seconds", 0.01),
        details=overrides.pop("details", {}),
    )
