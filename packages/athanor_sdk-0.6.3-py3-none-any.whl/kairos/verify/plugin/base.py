"""kairos.verify.plugin.base — ConformanceSuite base class (ATH-497 Gate 7).

Per Aidan's 2026-04-23 extensibility directive: every Protocol in
kairos.spec.types (+ TraceSink from kairos.trace) is customer-extensible.
qa's contract: one conformance suite per purity class, any plugin
runs it and the dispatch is keyed on the `:purity:` docstring tag.

The base class does three things:

  1. Introspect a target Protocol's `__doc__` for the `:purity:` tag.
     Refuse to construct if the tag is absent or invalid — platform's
     Gate 5 `test_protocol_has_purity_tag` grep test catches this at
     platform-PR-review time, but this is the runtime backstop.

  2. Expose a unified API (run / failures / summary) for test harnesses
     to invoke conformance over any plugin, regardless of purity.

  3. Delegate purity-specific assertions to subclasses. Each subclass
     owns the contract for ONE purity class — fixtures, invariants,
     expected-behavior under each test case shape.

Purity classes (4 total, per 2026-04-23 scope lock):

    PURE                   — referentially transparent; same input → same output always.
                              Examples: PromptLoader, ScoringFn, ModelSelectorPlugin.

    IMPURE_DETERMINISTIC   — side effects that don't change outputs; same input → same output
                              modulo timing. Examples: VerifierPlugin, OrchestratorPlugin.

    IMPURE_LOOKUP          — lookup-table impure; same key → same value (cacheable) but the
                              returned object itself is side-effectful when invoked.
                              Example: ToolRegistryPlugin.

    IMPURE_SIDE_EFFECTFUL  — writes to durable sinks; idempotence guaranteed only at the
                              identity-key level (e.g. same event.id → single row).
                              Example: TraceSink.

Usage pattern (test author):

    from kairos.verify.plugin import PromptLoaderConformance

    def test_my_custom_loader():
        suite = PromptLoaderConformance(MyLoader())
        suite.run()  # raises AssertionError on first failure, or returns None

    # Or parametrized across multiple plugins:
    @pytest.mark.parametrize("loader", [MyLoaderA(), MyLoaderB()])
    def test_any_loader(loader):
        PromptLoaderConformance(loader).run()
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from typing import Any

# Canonical purity enum lives in kairos.spec.types (Gate 5 / ATH-497 2026-04-23);
# re-export under the PurityClass name that the conformance suite + Gate 7
# tests use, so both import paths resolve to a single source of truth.
# Same reconciliation pattern Gate 5 used with TraceSink post-ATH-498 merge.
from kairos.spec.types import Purity as PurityClass  # noqa: F401 — public re-export


class MalformedProtocolDocstring(ValueError):
    """Raised when a target Protocol's docstring is missing or has an
    invalid `:purity:` tag. The runtime backstop for the platform-side
    `test_protocol_has_purity_tag` grep test — if that test regresses
    we still catch here before any conformance assertions run."""


# Matches `:purity: CLASS_NAME` where CLASS_NAME is ALL_CAPS + underscores.
# Tolerates trailing context on the line (some Protocols have nuance,
# e.g. OrchestratorPlugin declares `IMPURE_DETERMINISTIC (when backed by
# an LLM agent) or PURE (when backed by deterministic policy)`. The
# regex captures the FIRST purity-class identifier, then `extract_purity`
# resolves it against the PurityClass enum — unknown identifiers still
# raise MalformedProtocolDocstring. Keeps the tag authoritative while
# tolerating the dual-implementation case.
_PURITY_TAG_RE = re.compile(r"(?m)^\s*:purity:\s+([A-Z][A-Z_]+)")


def extract_purity(proto_cls: type) -> PurityClass:
    """Introspect a Protocol class's docstring for the `:purity:` tag.

    Returns the corresponding PurityClass enum value. Raises
    MalformedProtocolDocstring if the tag is missing, malformed, or
    names an unknown purity class. Never returns None — callers must
    handle the exception explicitly.

    Args:
        proto_cls: a Protocol class (typically from kairos.spec.types
            or kairos.trace). Must have a non-empty ``__doc__``.

    Raises:
        MalformedProtocolDocstring: no docstring / no tag / unknown
            purity class name.

    Example:

        >>> from kairos.trace import TraceSink
        >>> extract_purity(TraceSink)
        <PurityClass.IMPURE_SIDE_EFFECTFUL: 'IMPURE_SIDE_EFFECTFUL'>
    """
    doc = proto_cls.__doc__
    if not doc:
        raise MalformedProtocolDocstring(
            f"{proto_cls.__name__} has no docstring — cannot extract "
            f":purity: tag. Platform's Gate 5 test_protocol_has_purity_tag "
            f"should have caught this at PR review time; update the "
            f"Protocol's docstring with a :purity: tag."
        )
    match = _PURITY_TAG_RE.search(doc)
    if not match:
        raise MalformedProtocolDocstring(
            f"{proto_cls.__name__} docstring lacks a well-formed "
            f":purity: tag. Expected a line of the form "
            f"':purity: <CLASS_NAME>' where CLASS_NAME is one of "
            f"{', '.join(p.value for p in PurityClass)}."
        )
    tag_value = match.group(1)
    try:
        return PurityClass(tag_value)
    except ValueError:
        raise MalformedProtocolDocstring(
            f"{proto_cls.__name__}'s :purity: tag is {tag_value!r}; "
            f"must be one of {[p.value for p in PurityClass]}. If "
            f"you're introducing a new purity class, add the enum "
            f"member in kairos.verify.plugin.base.PurityClass first + "
            f"define a subclass ConformanceSuite that covers it."
        ) from None


class ConformanceSuite(ABC):
    """Abstract base for per-protocol conformance suites.

    Subclasses MUST:
      - Declare ``protocol_type`` (class attribute) = the target Protocol.
      - Declare ``expected_purity`` (class attribute) = the PurityClass
        the target Protocol's docstring must carry. Guard-rail: subclass
        refuses to construct if the actual tag doesn't match.
      - Implement ``_run_contract_tests(plugin)`` with the purity-specific
        assertions.

    Subclasses MAY:
      - Override ``_run_isolation_tests(plugin)`` to add plugin-type-
        specific isolation tests (misbehaving plugin, sys.path tampering,
        secret-reading — taxonomy keyed on purity class).

    Base class owns:
      - Purity-tag introspection + validation at __init__.
      - Public ``run()`` driver that runs contract + isolation in order.
      - Failure accumulator so callers can see every violation, not just
        the first.
    """

    # Subclass MUST set these two class attrs.
    protocol_type: type
    expected_purity: PurityClass

    def __init__(self, plugin: Any) -> None:
        """Construct the suite for a specific plugin instance.

        Verifies the subclass's ``protocol_type`` docstring actually
        declares the expected purity, refuses to run otherwise.

        Args:
            plugin: the plugin instance to test. Should satisfy
                ``isinstance(plugin, self.protocol_type)`` (Protocol
                is runtime_checkable); base class checks and raises
                TypeError if not.
        """
        cls = type(self)
        if not hasattr(cls, "protocol_type") or not hasattr(cls, "expected_purity"):
            raise TypeError(
                f"{cls.__name__} is incomplete: missing 'protocol_type' "
                f"and/or 'expected_purity' class attribute. ConformanceSuite "
                f"subclasses MUST declare both."
            )

        actual_purity = extract_purity(cls.protocol_type)
        if actual_purity != cls.expected_purity:
            raise MalformedProtocolDocstring(
                f"{cls.__name__} expects protocol {cls.protocol_type.__name__} "
                f"to carry :purity: {cls.expected_purity.value}, but its "
                f"docstring declares :purity: {actual_purity.value}. Either "
                f"fix the Protocol's docstring or use a different "
                f"ConformanceSuite subclass that matches the declared purity."
            )

        if not isinstance(plugin, cls.protocol_type):
            raise TypeError(
                f"{cls.__name__} requires a plugin that implements "
                f"{cls.protocol_type.__name__} (runtime_checkable "
                f"Protocol). Got {type(plugin).__name__}."
            )

        self.plugin = plugin
        self.failures: list[str] = []

    # ─── Public API ────────────────────────────────────────────────────

    def run(self) -> None:
        """Run contract + isolation tests; raise on first-collection failure.

        Unlike pytest's fail-first, this runs ALL tests + accumulates
        failures into ``self.failures``, then raises a single
        AssertionError with the full list. Callers that want the
        fail-first behaviour can pass ``fail_fast=True`` to ``run()``
        (TODO: expose kwarg when a caller needs it — simplest default
        is collect-all).

        Raises:
            AssertionError: if any contract or isolation test failed.
                The exception message enumerates every failure.
        """
        self.failures = []
        self._run_contract_tests(self.plugin)
        self._run_isolation_tests(self.plugin)
        if self.failures:
            lines = [f"{type(self).__name__}: {len(self.failures)} failure(s)"]
            lines.extend(f"  - {f}" for f in self.failures)
            raise AssertionError("\n".join(lines))

    def summary(self) -> dict[str, Any]:
        """Diagnostic dict — what was tested, what failed, which purity."""
        return {
            "suite": type(self).__name__,
            "protocol": type(self).protocol_type.__name__,
            "purity": type(self).expected_purity.value,
            "plugin_class": type(self.plugin).__name__,
            "failures": list(self.failures),
        }

    # ─── Subclass hooks ────────────────────────────────────────────────

    @abstractmethod
    def _run_contract_tests(self, plugin: Any) -> None:
        """Purity-specific contract tests. Subclass implements.

        Record failures via ``self._fail("reason")``. Do NOT raise
        AssertionError directly — the base class does that once at the
        end of ``run()`` to present all failures together.
        """

    def _run_isolation_tests(self, plugin: Any) -> None:
        """Base-class default: no isolation tests. Subclasses that have
        specific isolation cases (misbehaving plugin, resource leaks)
        override. Keeping default as no-op means subclasses that don't
        care get zero overhead."""
        return None

    # ─── Subclass helpers ──────────────────────────────────────────────

    def _fail(self, reason: str) -> None:
        """Record a contract or isolation failure without raising.

        Called by subclass assertions. Accumulates into ``self.failures``
        so callers see every issue, not just the first.
        """
        self.failures.append(reason)
