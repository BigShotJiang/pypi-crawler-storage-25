"""Detector: macro_sorry fingerprint.

Catches Lean source (``.lean`` files) containing a macro that
expands to ``sorry`` — the classic "hide-the-admit" cheat. A naive
``grep -w sorry`` over the source misses this because the offending
token sits inside a ``macro_rules`` / ``macro`` body that rewrites
to ``sorry`` at elaboration time.

Detection strategy (regex, conservative):

    1. Line-by-line scan. Track ``macro`` / ``macro_rules`` /
       ``syntax`` declarations (they span multiple lines — we
       enter a "macro-body" state when we see the opening
       ``|`` → ``=>`` arrow and stay in it until the next
       top-level declaration or end-of-block brace/paren match.
    2. Inside a macro body, any ``sorry`` / ``admit`` /
       ``Sorry`` token is flagged.

Additional patterns (belt-and-braces):

    * ``axiom <name> : ...`` declarations — even outside macros,
      axioms-in-theorem-file are the `axiom_introducing` escalation
      trigger. Flag as a separate DetectorMatch with fingerprint
      `banned_construct` (not macro_sorry) because semantically
      distinct.
    * ``native_decide`` in tactic-mode — flagged as `proof_bypass`.

Non-goals: we are NOT running the Lean elaborator here. A macro that
expands to ``sorry`` VIA INTERMEDIATE STEPS (e.g., expands to a
helper that expands to sorry) is not caught; Tier-3 runtime detector
would need to invoke the Lean elaborator. This is a best-effort
pre-elaboration regex gate — ATH-501 §4 flags full Lean-native impl
as post-MVP.

Cross-ref: audit doc §7a cheat categories `macro_sorry` +
`banned_construct` (`axiom` in shipped .lean) +
`proof_bypass` (`native_decide`).
"""

from __future__ import annotations

import re

from kairos.verify.plugin.detectors.types import DetectorMatch


_FINGERPRINT_MACRO_SORRY = "macro_sorry"
_FINGERPRINT_BANNED = "banned_construct"
_FINGERPRINT_PROOF_BYPASS = "proof_bypass"

# Regex: start of a macro / macro_rules / syntax decl. We don't try
# to parse Lean; we just spot the keyword at start-of-line (possibly
# after whitespace).
_MACRO_DECL_RE = re.compile(
    r"""
    ^\s*
    (?:
        macro_rules
      | macro
      | syntax
      | scoped\s+macro
      | scoped\s+macro_rules
      | local\s+macro
      | local\s+macro_rules
    )
    \b
    """,
    re.VERBOSE,
)

# Lines that signal we've exited the macro body. Crude: any top-level
# Lean declaration keyword at the start of a line.
_TOP_LEVEL_DECL_RE = re.compile(
    r"""
    ^\s*
    (?:
        theorem
      | lemma
      | def
      | instance
      | class
      | structure
      | inductive
      | namespace
      | end
      | section
      | import
      | open
      | #check
      | #eval
      | #print
    )
    \b
    """,
    re.VERBOSE,
)

# Inside a macro body, match sorry / admit. `sorry` is the canonical
# bypass; `admit` is the same concept in tactic-mode.
_SORRY_RE = re.compile(r"\b(sorry|admit)\b")

# Outside macro bodies: axiom decl (banned in verifier source).
_AXIOM_DECL_RE = re.compile(r"^\s*axiom\s+\w+")

# native_decide / decide on anything (conservative: flag any usage).
# `decide` alone is sometimes legit for decidable propositions; we
# only flag `native_decide` + `decide` that's explicitly in a by-
# block after no prior reasoning. Keep simple: flag `native_decide`.
_NATIVE_DECIDE_RE = re.compile(r"\bnative_decide\b")


def _strip_line_comment(line: str) -> str:
    """Remove a trailing `--` comment from a Lean line. Does NOT
    handle nested block comments `/- ... -/` — those are rare in
    macro bodies + the false-positive is "miss a sorry inside a
    comment", which is the safer failure mode."""
    # `--` only counts if not inside a string. Cheap approximation:
    # if the line contains `"`, bail (don't strip comments).
    if '"' in line:
        return line
    idx = line.find("--")
    return line if idx == -1 else line[:idx]


def detect(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Scan Lean `source` for macro-bodies that expand to sorry/admit,
    for axiom declarations, and for native_decide usage.

    Non-Lean source (no ``.lean`` extension hint + no Lean-ish
    signature) is ignored — macro_sorry is Lean-specific. If the
    filename ends with ``.lean`` we scan; otherwise we sniff for
    ``theorem`` / ``lemma`` / ``macro`` at start-of-line.
    """
    is_lean = filename.endswith(".lean") or any(
        line.lstrip().startswith(("theorem ", "lemma ", "macro ", "macro_rules"))
        for line in source.splitlines()[:100]
    )
    if not is_lean:
        return []

    matches: list[DetectorMatch] = []
    in_macro_body = False
    macro_start_line = 0

    for lineno, raw_line in enumerate(source.splitlines(), start=1):
        line = _strip_line_comment(raw_line)

        if _MACRO_DECL_RE.match(line):
            in_macro_body = True
            macro_start_line = lineno
            # Same-line sorry? e.g., `macro "foo" : tactic => `(tactic| sorry)`
            if _SORRY_RE.search(line):
                matches.append(
                    DetectorMatch(
                        fingerprint=_FINGERPRINT_MACRO_SORRY,
                        filename=filename,
                        line=lineno,
                        col=0,
                        reason=(
                            f"Lean macro declaration on line {lineno} expands "
                            f"to 'sorry'/'admit'. A macro that rewrites to "
                            f"sorry bypasses a naive grep-sorry publish gate."
                        ),
                        snippet=line.strip()[:200],
                        metadata={"shape": "macro_same_line_sorry"},
                    )
                )
            continue

        # Exit macro body on a top-level declaration keyword.
        if in_macro_body and _TOP_LEVEL_DECL_RE.match(line):
            in_macro_body = False

        if in_macro_body and _SORRY_RE.search(line):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_MACRO_SORRY,
                    filename=filename,
                    line=lineno,
                    col=0,
                    reason=(
                        f"'sorry'/'admit' inside macro body (macro opens on "
                        f"line {macro_start_line}). A macro that expands to "
                        f"sorry bypasses a naive grep-sorry publish gate."
                    ),
                    snippet=line.strip()[:200],
                    metadata={
                        "shape": "macro_body_sorry",
                        "macro_start_line": macro_start_line,
                    },
                )
            )

        # Non-macro checks: axiom decl + native_decide.
        if _AXIOM_DECL_RE.match(line):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_BANNED,
                    filename=filename,
                    line=lineno,
                    col=0,
                    reason=(
                        f"axiom declaration on line {lineno}. Axioms in "
                        f"verifier source are the 'axiom_introducing' "
                        f"escalation trigger; the fleet requires "
                        f"axiom_audit_match on any such introduction."
                    ),
                    snippet=line.strip()[:200],
                    metadata={"shape": "axiom_decl"},
                )
            )
        if _NATIVE_DECIDE_RE.search(line):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_PROOF_BYPASS,
                    filename=filename,
                    line=lineno,
                    col=0,
                    reason=(
                        f"'native_decide' usage on line {lineno}. "
                        f"native_decide compiles to runtime-code and "
                        f"bypasses the kernel trust path; disallowed in "
                        f"verifier-ship Lean source."
                    ),
                    snippet=line.strip()[:200],
                    metadata={"shape": "native_decide"},
                )
            )

    matches.sort(key=lambda m: (m.line, m.col, m.fingerprint))
    return matches
