"""Shared types for kairos.verify.plugin.detectors (ATH-499 Tier 1).

Keeps the DetectorMatch dataclass + cheat-category taxonomy in one
place so individual detectors import a single module. Mirrors the
athanor-builder solve/core/anti_cheat/detectors/types.py shape — same
fingerprint-string convention so customer-side tooling reading
match.fingerprint works across both surfaces without a translation
table.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# The 13-category taxonomy from the knowledge-bank enrichment
# (audit doc §7a). Keep in sync if platform extends via ATH-500 work.
CheatFingerprint = Literal[
    "stub_detection",
    "signature_modified",
    "assertion_tampering",
    "banned_construct",
    "proof_bypass",
    "symlink_escape",
    "file_not_found",
    "file_empty",
    "interface_violation",
    "null_implementation",
    "effort_gaming",
    "sandbox_escape",
    "macro_sorry",
    # Tier-1 SDK-layer additions:
    "literal_verdict",
    "reference_module_import",
]


@dataclass(frozen=True)
class DetectorMatch:
    """One recorded violation from an AST/regex detector pass.

    `fingerprint` is the stable string the conformance suite + publish-
    gate + customer tooling all use to identify the cheat class. `line`
    + `col` locate the offense in the source file for human review.
    `reason` is a 1-2-sentence explanation for PR-review comments.
    """

    fingerprint: CheatFingerprint
    filename: str
    line: int
    reason: str
    col: int = 0
    # Optional snippet of the offending AST node / source region, capped
    # at ~200 chars so it round-trips cleanly through PR-comment UI.
    snippet: str = ""
    # Per-detector extras (e.g. the specific return-value shape that
    # tripped literal_verdict). Dict so new detectors can attach data
    # without widening this dataclass.
    metadata: dict = field(default_factory=dict)


__all__ = ["CheatFingerprint", "DetectorMatch"]
