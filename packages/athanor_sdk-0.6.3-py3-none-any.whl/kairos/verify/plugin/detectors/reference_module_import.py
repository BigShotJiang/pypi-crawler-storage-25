"""Detector: reference_module_import fingerprint.

Catches plugin code that imports from non-public kairos surface or
from builder-internal `solve.*` modules. The knowledge-bank's
"reference-import ban" 7-layer-anti-cheat entry: a student (or
customer plugin) must not import the reference implementation to
crib answers.

Applied to SDK plugins: the canonical non-public namespaces are
``kairos._*_impl`` (Cython internals) and anything under ``solve.*``
(athanor-builder internal, should never appear in an SDK-side
plugin). Customer plugins importing these are either:

  1. Reaching into private API that we'll break (stability tax), or
  2. Copying reference impl logic (cheat-scoring).

Either way — flag + refuse at publish-gate.

Cross-ref: audit doc §2 RL-env pattern map row "reference-import
guard" + 7-layer-anti-cheat layer 3.
"""

from __future__ import annotations

import ast

from kairos.verify.plugin.detectors.types import DetectorMatch


_FINGERPRINT = "reference_module_import"

# Banned namespaces. Prefix match (so `kairos._scoring_impl.foo` hits
# `kairos._`).
_BANNED_PREFIXES = (
    "kairos._",
    "solve.",
    "solve",        # bare `import solve` — rare but block
    "athanor_builder",  # pre-rename legacy pattern
    "athanor_builder.",
)

# Allowed exceptions — kairos.* public surface is fine. List kept empty
# for now; add named modules here if a future refactor creates a
# legitimate private-import carve-out.
_ALLOWLIST: tuple[str, ...] = ()


def _is_banned(module: str) -> bool:
    """Match `module` against the banned prefixes, honoring the
    allowlist. Works for both `import x.y` and `from x.y import z`."""
    if not module:
        return False
    if any(module == a or module.startswith(a + ".") for a in _ALLOWLIST):
        return False
    return any(module.startswith(p) or module == p.rstrip(".") for p in _BANNED_PREFIXES)


def detect(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Scan `source` for forbidden imports.

    Returns one DetectorMatch per offending import statement.
    """
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError:
        return []  # stub_body handles syntax errors

    matches: list[DetectorMatch] = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                mod = alias.name
                if _is_banned(mod):
                    matches.append(
                        DetectorMatch(
                            fingerprint=_FINGERPRINT,
                            filename=filename,
                            line=node.lineno,
                            col=node.col_offset,
                            reason=(
                                f"import of non-public module {mod!r}. Plugin "
                                f"code must not depend on private kairos "
                                f"internals (`kairos._*`) or builder-side "
                                f"`solve.*` — these are unstable + "
                                f"reference-implementation surface that plugins "
                                f"should not access."
                            ),
                            snippet=f"import {mod}",
                            metadata={"module": mod, "import_form": "plain"},
                        )
                    )
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            # `from . import x` has module=''; relative imports can
            # still target banned namespaces if the package root is
            # under kairos._*. Detect conservatively: we flag any
            # `from .` with no absolute path, since the package root
            # at plugin-load time is effectively opaque.
            if not mod and node.level > 0:
                matches.append(
                    DetectorMatch(
                        fingerprint=_FINGERPRINT,
                        filename=filename,
                        line=node.lineno,
                        col=node.col_offset,
                        reason=(
                            "relative import (`from .`) in plugin code — "
                            "plugins should use absolute imports only; "
                            "relative imports can silently resolve into "
                            "private namespaces depending on package layout."
                        ),
                        snippet="from . import ...",
                        metadata={"module": "<relative>", "level": node.level},
                    )
                )
                continue
            if _is_banned(mod):
                matches.append(
                    DetectorMatch(
                        fingerprint=_FINGERPRINT,
                        filename=filename,
                        line=node.lineno,
                        col=node.col_offset,
                        reason=(
                            f"import from non-public module {mod!r}. Same "
                            f"rationale as `import {mod}` — reference-surface "
                            f"access should not appear in plugin code."
                        ),
                        snippet=f"from {mod} import ...",
                        metadata={"module": mod, "import_form": "from"},
                    )
                )

    matches.sort(key=lambda m: (m.line, m.col))
    return matches
