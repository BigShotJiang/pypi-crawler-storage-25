"""Detector: witness_file_check fingerprint.

Catches VerifierPlugin source that returns ``Verdict(outcome='proved', ...)``
WITHOUT first validating that the witness file it was handed exists
and is non-empty. This is the plugin-source-time analog of the
knowledge-bank `file_not_found` / `file_empty` cheat categories: a
plugin that trusts the caller-supplied witness path and emits a
proved verdict without even opening the file.

Detection strategy (conservative, AST-level):

    * Find functions in _WATCHED_FNS (verify, score).
    * Check whether the function body contains ANY of:
        - a call to ``os.path.exists`` / ``pathlib.Path.exists``
        - a call to ``.stat()`` or ``os.stat`` or ``os.path.getsize``
        - ``.read_text()`` / ``.read_bytes()`` / ``open(...)`` — reading
          the file IS witness validation; if read fails, Python raises.
        - a direct ``size`` / ``len`` / emptiness check on witness contents
    * Check whether the function returns ``outcome='proved'`` (literal
      keyword in a Verdict(...) call).
    * If proved IS returned but NO witness-validation call is present,
      flag.

False-positive guard: if the function delegates to a helper (e.g.
``self._load_witness(...)``), we can't prove the helper doesn't
validate — so we only flag when the function body is SELF-CONTAINED
(no method calls other than the Verdict constructor and trivial
attribute accesses). Conservative false-negative rate is the tradeoff;
this detector is Tier-1 best-effort, not airtight.

Cross-ref: audit doc §7a cheat categories `file_not_found` +
`file_empty`. Companion to runtime-side conformance-suite check that
runs INSIDE VerifierPlugin.verify() — that check sees actual FS state;
this static check sees the PR-time source. Both layers catch.
"""

from __future__ import annotations

import ast

from kairos.verify.plugin.detectors.types import DetectorMatch


_FINGERPRINT = "file_not_found"

_WATCHED_FNS = frozenset({"verify", "score"})

# Call names / attributes we treat as "validated the witness file".
# Presence of any of these in the function body clears the flag.
_VALIDATION_CALL_ATTRS = frozenset({
    "exists",
    "is_file",
    "stat",
    "getsize",
    "size",
    "read_text",
    "read_bytes",
    "read",
    "readlines",
    "open",
    "getmtime",
    "getatime",
})

_VALIDATION_CALL_NAMES = frozenset({
    "open",
    "getsize",
    "stat",
})


def _collect_local_str_assignments(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
) -> dict[str, str]:
    """Return a {var_name: string_value} map of simple local
    ``name = 'literal_str'`` assignments inside ``fn``. Used to close
    W1 bypass (`outcome_val = 'proved'; return Verdict(outcome=outcome_val, ...)`).

    Skips tuple-unpacking, aug-assigns, subscript targets, non-str
    Constant values. Conservative — only STRENGTHENS detection, never
    silences it.
    """
    assignments: dict[str, str] = {}
    for stmt in ast.walk(fn):
        if not isinstance(stmt, ast.Assign):
            continue
        if len(stmt.targets) != 1:
            continue
        tgt = stmt.targets[0]
        if not isinstance(tgt, ast.Name):
            continue
        val = stmt.value
        if isinstance(val, ast.Constant) and isinstance(val.value, str):
            assignments[tgt.id] = val.value
    return assignments


def _resolve_to_str(
    expr: ast.expr, local_strs: dict[str, str],
) -> str | None:
    """Static str value of ``expr``, or None if not statically known.

    Handles ast.Constant(str) + ast.Name resolved via local_strs.
    """
    if isinstance(expr, ast.Constant) and isinstance(expr.value, str):
        return expr.value
    if isinstance(expr, ast.Name) and expr.id in local_strs:
        return local_strs[expr.id]
    return None


def _call_target_is_verdict(call: ast.Call) -> bool:
    """Best-effort check that a Call's func is Verdict(...). Matches
    ``Verdict(...)`` and ``<module>.Verdict(...)``. False negatives
    are OK — only used to OPT-IN to positional matching.
    """
    func = call.func
    if isinstance(func, ast.Name) and func.id == "Verdict":
        return True
    if isinstance(func, ast.Attribute) and func.attr == "Verdict":
        return True
    return False


def _body_emits_proved(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """True iff any Return in ``fn`` constructs a Verdict with
    ``outcome='proved'``.

    Detection (platform slice 3, closes PR #121 W1 + W3 bypasses):

    1. ``Verdict(outcome='proved', ...)`` — kwarg as Constant str.
    2. ``outcome_val = 'proved'; Verdict(outcome=outcome_val, ...)``
       — kwarg as Name, resolved via local string-assignment tracking
       (W1 bypass closure).
    3. ``Verdict('x', 'proved', ...)`` — positional arg at index 1
       (matches Verdict dataclass field order source/outcome/reason).
       Only fires when the Call's target resembles ``Verdict``
       (W3 bypass closure).
    """
    local_strs = _collect_local_str_assignments(fn)
    for node in ast.walk(fn):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        for sub in ast.walk(node.value):
            if not isinstance(sub, ast.Call):
                continue
            # Kwarg path — Constant OR Name-resolved-to-string.
            for kw in sub.keywords:
                if kw.arg != "outcome":
                    continue
                if _resolve_to_str(kw.value, local_strs) == "proved":
                    return True
            # Positional path — only for Verdict-shaped calls so
            # arbitrary 3-arg Calls don't false-positive.
            if _call_target_is_verdict(sub) and len(sub.args) >= 2:
                if _resolve_to_str(sub.args[1], local_strs) == "proved":
                    return True
    return False


def _body_validates_witness(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """True iff `fn` contains any call that looks like witness-file
    validation (exists / stat / read / open / size check).
    """
    for node in ast.walk(fn):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr in _VALIDATION_CALL_ATTRS:
            return True
        if isinstance(func, ast.Name) and func.id in _VALIDATION_CALL_NAMES:
            return True
    return False


def detect(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Scan `source` for verify()/score() functions that return
    ``outcome='proved'`` without any visible witness-file validation.
    """
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError:
        # stub_body owns the syntax-error fingerprint; no double-report.
        return []

    matches: list[DetectorMatch] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name not in _WATCHED_FNS:
            continue
        if not _body_emits_proved(node):
            continue
        if _body_validates_witness(node):
            continue
        matches.append(
            DetectorMatch(
                fingerprint=_FINGERPRINT,
                filename=filename,
                line=node.lineno,
                col=node.col_offset,
                reason=(
                    f"function {node.name!r} returns a 'proved' Verdict "
                    f"but the body contains no visible witness-file "
                    f"validation (no open/exists/stat/read/size check). "
                    f"A plugin that trusts the caller-supplied witness path "
                    f"without opening the file can emit proved verdicts on "
                    f"non-existent or empty witnesses — file_not_found / "
                    f"file_empty cheat shape."
                ),
                metadata={
                    "function": node.name,
                    "shape": "proved_without_witness_read",
                },
            )
        )

    matches.sort(key=lambda m: (m.line, m.col))
    return matches
