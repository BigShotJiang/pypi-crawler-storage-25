"""kairos.verify.plugin.detectors — source-code anti-cheat detectors (ATH-499 Tier 1).

Per the 2026-04-23 anti-cheat audit (docs/sdk-agent-anti-cheat-audit.md)
+ knowledge-bank enrichment, every customer-registered plugin source
file runs through a ladder of AST / regex detectors at PR-review time +
check_sdk_ip.py publish-gate.

Detectors shipped (Tier 1, 2026-04-23):

    stub_body                — function bodies that are `pass` /
                               `raise NotImplementedError(...)` /
                               `pytest.fail("implement later")`.
                               Cross-ref: stub_detection,
                               null_implementation cheat categories.

    literal_verdict          — VerifierPlugin.verify() that always
                               returns the same Verdict.outcome
                               regardless of input. Cross-ref:
                               effort_gaming, interface_violation.

    reference_module_import  — plugin code that imports from
                               kairos._*_impl or solve.* (non-public
                               surface). Cross-ref: reference-import-
                               ban (from the 7-layer anti-cheat enum).

    witness_file_check       — verify()/score() that returns
                               outcome='proved' without any visible
                               witness-file validation call. Cross-ref:
                               file_not_found, file_empty categories.

    macro_sorry              — Lean macro that expands to sorry/admit;
                               plus axiom decl (banned_construct) +
                               native_decide (proof_bypass) belt-and-
                               braces checks. Cross-ref: macro_sorry,
                               banned_construct, proof_bypass.

Each detector follows the same shape:

    def detect(source: str, filename: str) -> list[DetectorMatch]

Returns zero matches on clean source; one `DetectorMatch` per
violation. Plugin-conformance suite + publish-gate both consume.

Usage:

    from kairos.verify.plugin.detectors import run_all_detectors
    matches = run_all_detectors(source="...", filename="plugin.py")
    if matches:
        for m in matches:
            print(f"{m.fingerprint} at line {m.line}: {m.reason}")
"""

from __future__ import annotations

from kairos.verify.plugin.detectors.literal_verdict import (
    detect as detect_literal_verdict,
)
from kairos.verify.plugin.detectors.macro_sorry import detect as detect_macro_sorry
from kairos.verify.plugin.detectors.reference_module_import import (
    detect as detect_reference_module_import,
)
from kairos.verify.plugin.detectors.stub_body import detect as detect_stub_body
from kairos.verify.plugin.detectors.types import DetectorMatch
from kairos.verify.plugin.detectors.witness_file_check import (
    detect as detect_witness_file_check,
)

_ALL_DETECTORS = (
    detect_stub_body,
    detect_literal_verdict,
    detect_reference_module_import,
    detect_witness_file_check,
    detect_macro_sorry,
)


def run_all_detectors(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Run every registered detector against `source`; collect matches.

    Does not short-circuit — callers see every violation across every
    detector. Matches the fail-closed accumulator pattern from
    ConformanceSuite.run().
    """
    matches: list[DetectorMatch] = []
    for detect_fn in _ALL_DETECTORS:
        matches.extend(detect_fn(source, filename))
    return matches


__all__ = [
    "DetectorMatch",
    "detect_literal_verdict",
    "detect_macro_sorry",
    "detect_reference_module_import",
    "detect_stub_body",
    "detect_witness_file_check",
    "run_all_detectors",
]
