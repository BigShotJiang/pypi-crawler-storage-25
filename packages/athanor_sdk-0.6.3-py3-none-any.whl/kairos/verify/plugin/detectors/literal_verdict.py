"""Detector: literal_verdict fingerprint.

Catches VerifierPlugin / ScoringFn / similar plugins whose return
value is a LITERAL constant — same value regardless of input. The
quintessential effort-gaming shape for a VerifierPlugin is
``verify() -> Verdict(source='x', outcome='proved', reason='')``
unconditionally, regardless of the spec + witness actually passed in.

Detection strategy: AST-walk function bodies; if the only path through
the function is a single ``return`` whose value is a literal /
call-with-literal-args that depends on NONE of the function's
parameters, flag as literal_verdict.

Cross-ref: audit doc §7a `effort_gaming` + `interface_violation` cheat
categories. Complements the runtime-side ConformanceSuite's determinism
check (which catches different outputs across calls but NOT identical
outputs across calls with different inputs).
"""

from __future__ import annotations

import ast

from kairos.verify.plugin.detectors.types import DetectorMatch


_FINGERPRINT = "literal_verdict"

# Function names we care about — these are the Protocol-contract entry
# points where literal-return = effort gaming.
_WATCHED_FNS = frozenset({
    "verify",
    "score",
    "load",
    "select",
    "orchestrate",
    "emit",
    "emit_escalation",
})


def _returns_are_literal_or_input_independent(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
) -> tuple[bool, str]:
    """Return (True, snippet) iff every `return` statement in `fn`
    produces a value that does NOT reference any of `fn`'s parameters.

    Keyword args count as parameters. Catches:
        def verify(self, intent, witness): return Verdict(source='x', ...)
    where neither `intent` nor `witness` flows into the return.
    """
    # Collect parameter names. Include self, positional, kw-only, varargs.
    param_names: set[str] = set()
    for arg in fn.args.args:
        param_names.add(arg.arg)
    for arg in fn.args.kwonlyargs:
        param_names.add(arg.arg)
    for arg in fn.args.posonlyargs:
        param_names.add(arg.arg)
    if fn.args.vararg:
        param_names.add(fn.args.vararg.arg)
    if fn.args.kwarg:
        param_names.add(fn.args.kwarg.arg)

    # Walk for Return statements.
    returns = [n for n in ast.walk(fn) if isinstance(n, ast.Return)]
    if not returns:
        return (False, "")

    # Check 1: if the function body references a parameter in control
    # flow (branch conditions, loops, side-effect expressions outside
    # returns), the function IS input-dependent even if individual
    # return values are literals. Don't flag.
    #
    # Strategy: collect the id()s of all ast nodes that live inside a
    # Return subtree, then walk the whole function and look for
    # parameter-name Name nodes that are NOT in the return subtrees.
    return_subtree_ids: set[int] = set()
    for ret in returns:
        for sub in ast.walk(ret):
            return_subtree_ids.add(id(sub))

    for sub in ast.walk(fn):
        if isinstance(sub, ast.Name) and sub.id in param_names:
            if id(sub) not in return_subtree_ids:
                # Parameter used in control flow — not literal_verdict.
                return (False, "")

    # Check 2: any return whose value references a parameter is
    # input-dependent; abort.
    for ret in returns:
        if ret.value is None:
            continue
        for sub in ast.walk(ret.value):
            if isinstance(sub, ast.Name) and sub.id in param_names:
                return (False, "")

    # All returns are input-independent. For the snippet, pick the
    # first return's text (ast.unparse works in 3.9+).
    try:
        snippet = ast.unparse(returns[0].value) if returns[0].value else "None"
    except Exception:  # noqa: BLE001 — broad-catch fallback
        snippet = "<literal>"
    return (True, snippet[:200])


def detect(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Scan `source` for Protocol-entry-point functions whose return
    value is independent of all parameters.

    Fires on each watched function name (verify / score / load / select
    / orchestrate / emit / emit_escalation) that satisfies the
    "all returns ignore parameters" predicate. Non-watched functions
    (helpers, internal state mutation) are ignored — they legitimately
    can be parameter-free.
    """
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError:
        # Don't double-report; stub_body detector's SyntaxError handler
        # is the canonical site for malformed-source flags.
        return []

    matches: list[DetectorMatch] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name not in _WATCHED_FNS:
            continue
        is_literal, snippet = _returns_are_literal_or_input_independent(node)
        if is_literal:
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT,
                    filename=filename,
                    line=node.lineno,
                    col=node.col_offset,
                    reason=(
                        f"Protocol-entry-point function {node.name!r} returns "
                        f"a value that does not depend on any parameter — "
                        f"classic effort-gaming shape. The plugin satisfies "
                        f"the Protocol runtime_checkable probe but ignores "
                        f"its inputs. Snippet: {snippet!r}."
                    ),
                    snippet=snippet,
                    metadata={
                        "function": node.name,
                        "shape": "input_independent_return",
                    },
                )
            )

    matches.sort(key=lambda m: (m.line, m.col))
    return matches
