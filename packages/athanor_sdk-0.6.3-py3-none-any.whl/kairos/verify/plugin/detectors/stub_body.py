"""Detector: stub_body fingerprint.

Catches function bodies that are effectively no-ops:

    * A lone ``pass`` statement (possibly preceded by a docstring).
    * ``raise NotImplementedError(...)`` as the entire body.
    * ``pytest.fail("implement later")`` and close variants (qa's own
      Gate 4 skeleton-pivot lesson — the exact regex that caught me).
    * ``return None`` / bare ``return`` as the entire body, unless the
      function's return annotation is ``None`` (genuine null-returning
      function is fine).

Rationale: customer-registered plugins shipping with stub bodies are
the most common "effort-gaming" shape — they satisfy the Protocol
runtime_checkable probe + the conformance suite's structural checks
but don't DO anything. Static AST inspection catches at PR-review
time before the plugin ships.

Cross-ref: audit doc §7a cheat categories `stub_detection` +
`null_implementation`. Also triggers on qa's own file pattern (learned
from the ATH-492 skeleton-pivot incident — my scaffolded stubs with
``pytest.fail("implement once ATH-492 validator ships")`` would have
tripped this detector at publish-gate if we'd pushed them live).
"""

from __future__ import annotations

import ast

from kairos.verify.plugin.detectors.types import DetectorMatch


_FINGERPRINT_STUB = "stub_detection"
_FINGERPRINT_NULL = "null_implementation"

# pytest.fail arg patterns that signal "deliberately-pending stub".
_STUB_FAIL_MARKERS = (
    "implement later",
    "implement once",
    "TODO",
    "todo",
    "not yet implemented",
    "stub",
)


def _body_without_docstring(body: list) -> list:
    """Strip a leading docstring if present. Returns a copy of `body`
    with the docstring Expr removed; does not mutate the original."""
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        return body[1:]
    return list(body)


def _is_trivial_pass_body(body: list) -> bool:
    """Body is just `pass` (optionally preceded by docstring)."""
    stripped = _body_without_docstring(body)
    return len(stripped) == 1 and isinstance(stripped[0], ast.Pass)


def _is_notimplemented_body(body: list) -> bool:
    """Body is `raise NotImplementedError(...)` as the only statement."""
    stripped = _body_without_docstring(body)
    if len(stripped) != 1:
        return False
    stmt = stripped[0]
    if not isinstance(stmt, ast.Raise):
        return False
    exc = stmt.exc
    if exc is None:
        return False
    # `raise NotImplementedError` (no call).
    if isinstance(exc, ast.Name) and exc.id == "NotImplementedError":
        return True
    # `raise NotImplementedError(...)` (called).
    if isinstance(exc, ast.Call) and isinstance(exc.func, ast.Name):
        return exc.func.id == "NotImplementedError"
    return False


def _is_pytest_fail_stub(body: list) -> tuple[bool, str]:
    """Body is `pytest.fail("implement later")` or close variant.

    Returns (True, arg_string) if matched, else (False, "").
    """
    stripped = _body_without_docstring(body)
    if len(stripped) != 1:
        return (False, "")
    stmt = stripped[0]
    if not isinstance(stmt, ast.Expr) or not isinstance(stmt.value, ast.Call):
        return (False, "")
    call = stmt.value
    # pytest.fail(...) or .fail(...)
    func = call.func
    is_pytest_fail = False
    if isinstance(func, ast.Attribute) and func.attr == "fail":
        if isinstance(func.value, ast.Name) and func.value.id == "pytest":
            is_pytest_fail = True
    if not is_pytest_fail:
        return (False, "")
    # Check the first positional arg for a stub marker.
    if not call.args:
        return (False, "")
    first = call.args[0]
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        msg = first.value.lower()
        for marker in _STUB_FAIL_MARKERS:
            if marker.lower() in msg:
                return (True, first.value)
    return (False, "")


def _is_trivial_return_none(body: list, returns: ast.expr | None) -> bool:
    """Body is just `return None` or bare `return` AND the function's
    return annotation is NOT explicitly `None` (= functions that
    ANNOTATE a non-None return but actually return None)."""
    stripped = _body_without_docstring(body)
    if len(stripped) != 1:
        return False
    stmt = stripped[0]
    if not isinstance(stmt, ast.Return):
        return False
    returns_none = (
        stmt.value is None
        or (isinstance(stmt.value, ast.Constant) and stmt.value.value is None)
    )
    if not returns_none:
        return False
    # If annotation is `None`, this is legitimate.
    if returns is None:
        return True  # no annotation + lone return None IS a stub signal
    if isinstance(returns, ast.Constant) and returns.value is None:
        return False  # -> None annotation, legitimate no-op
    if isinstance(returns, ast.Name) and returns.id == "None":
        return False
    # -> AnyOtherType + return None = stub
    return True


def detect(source: str, filename: str = "<plugin>") -> list[DetectorMatch]:
    """Scan `source` for stub-body violations.

    Returns one DetectorMatch per offending function / method body.
    Deterministic ordering by (line, col) so callers get reproducible
    regression-testable output.
    """
    # Python-only AST detector. Non-Python source (Lean, SV, etc.)
    # is handled by other detectors — skip cleanly instead of
    # flagging SyntaxError.
    if filename.endswith((".lean", ".sv", ".svh", ".v", ".c", ".rs", ".ts")):
        return []

    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError as exc:
        # Unparseable Python source is its own problem, but not a stub
        # cheat. Report once so caller can route to syntax-error lane.
        return [
            DetectorMatch(
                fingerprint="null_implementation",
                filename=filename,
                line=exc.lineno or 0,
                col=exc.offset or 0,
                reason=(
                    f"source failed to parse: {exc.msg!r}. Can't distinguish "
                    f"stub from non-stub — treating as null_implementation."
                ),
                snippet=(source[:200] if source else ""),
            )
        ]

    matches: list[DetectorMatch] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        fn_name = node.name
        body = node.body
        returns = getattr(node, "returns", None)

        if _is_trivial_pass_body(body):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_STUB,
                    filename=filename,
                    line=node.lineno,
                    col=node.col_offset,
                    reason=(
                        f"function {fn_name!r} has a stub body (lone `pass`). "
                        f"Plugin must implement the contract; an empty body "
                        f"is an effort-gaming signal."
                    ),
                    metadata={"function": fn_name, "shape": "pass"},
                )
            )
            continue

        if _is_notimplemented_body(body):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_STUB,
                    filename=filename,
                    line=node.lineno,
                    col=node.col_offset,
                    reason=(
                        f"function {fn_name!r} body raises NotImplementedError. "
                        f"NotImplementedError in shipped plugin code is a stub marker — "
                        f"replace with real impl or mark the plugin as incomplete + "
                        f"skip registration."
                    ),
                    metadata={"function": fn_name, "shape": "raise_notimplemented"},
                )
            )
            continue

        is_fail_stub, fail_msg = _is_pytest_fail_stub(body)
        if is_fail_stub:
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_STUB,
                    filename=filename,
                    line=node.lineno,
                    col=node.col_offset,
                    reason=(
                        f"function {fn_name!r} body is "
                        f"pytest.fail({fail_msg!r}) — deliberately-pending "
                        f"scaffolding stub. Fill in the implementation or "
                        f"skip/parametrize-skip the test, don't ship with "
                        f"pytest.fail as the body."
                    ),
                    metadata={
                        "function": fn_name,
                        "shape": "pytest_fail_stub",
                        "fail_message": fail_msg,
                    },
                )
            )
            continue

        if _is_trivial_return_none(body, returns):
            matches.append(
                DetectorMatch(
                    fingerprint=_FINGERPRINT_NULL,
                    filename=filename,
                    line=node.lineno,
                    col=node.col_offset,
                    reason=(
                        f"function {fn_name!r} body is `return None` (or bare "
                        f"return) but the annotated return type is not None. "
                        f"Likely a stub waiting on real impl."
                    ),
                    metadata={"function": fn_name, "shape": "return_none_vs_anno"},
                )
            )

    # Deterministic ordering.
    matches.sort(key=lambda m: (m.line, m.col, m.fingerprint))
    return matches
