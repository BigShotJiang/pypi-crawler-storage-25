"""kairos.verify.plugin.suites — per-protocol conformance subclasses.

Six ConformanceSuite subclasses, one per customer-extensible Protocol
in kairos.spec.types + kairos.trace. Grouped into this single module
rather than 6 separate files — each suite is ~80-120 LoC + the base
class handles cross-cutting concerns (purity enforcement, failure
accumulation). Splitting further would add import-boilerplate without
clarity gain.

Coverage map (2026-04-23 scope lock):
    VerifierPluginConformance         → IMPURE_DETERMINISTIC
    PromptLoaderConformance           → PURE
    ScoringFnConformance              → PURE
    ToolRegistryPluginConformance     → IMPURE_LOOKUP
    ModelSelectorPluginConformance    → PURE
    TraceSinkConformance              → IMPURE_SIDE_EFFECTFUL

OrchestratorPluginConformance is wired in: covers both the
deterministic-policy case (e.g. DefaultRoundRobinOrchestrator) and the
LLM-backed case (kairos.fleet.Orchestrator, post-ATH-570 rename).
"""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from kairos.verify.plugin.base import ConformanceSuite, PurityClass
from kairos.verify.plugin.fixtures import (
    make_escalation_event,
    make_intent,
    make_trace_event,
    make_verdict,
    make_witness,
)


# ═══════════════════════════════════════════════════════════════════════
# PURE — PromptLoader
# ═══════════════════════════════════════════════════════════════════════


class PromptLoaderConformance(ConformanceSuite):
    """PromptLoader must be PURE: same (tier, template_name) → same str.

    Contract checks:
      - Determinism: 2 calls with same args produce byte-identical str.
      - Non-empty: load() returns a non-empty string on a registered key.
      - Miss behavior: missing (tier, template_name) raises, NOT silent empty.

    Usage:

        # Default probe — tries a common built-in tier/template combo.
        PromptLoaderConformance(loader).run()

        # Explicit probe — if the plugin's registered keys differ.
        PromptLoaderConformance(
            loader, probe_key=("my_tier", "my_template"),
        ).run()

    If the default probe raises (e.g. plugin has no templates for the
    built-in tier), the suite gracefully falls back to miss-behavior
    testing only — i.e. asserts the raise is a NAMED exception class,
    not a silent-empty-return. A plugin with no templates at all is
    not a failure; effort-gamed plugins that silently return empty ARE.
    """

    _DEFAULT_PROBE = ("lean_proved", "spec_draft_llm")

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import PromptLoader
        cls.protocol_type = PromptLoader
        cls.expected_purity = PurityClass.PURE

    def __init__(
        self,
        plugin: Any,
        *,
        probe_key: tuple[str, str] | None = None,
    ) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)
        self.probe_key = probe_key or self._DEFAULT_PROBE

    def _run_contract_tests(self, plugin: Any) -> None:
        tier, template = self.probe_key
        # Try the probe. Raise → jump to miss-behavior check; success →
        # verify determinism + non-empty.
        try:
            a = plugin.load(tier, template)
            b = plugin.load(tier, template)
        except Exception:  # noqa: BLE001 — broad-catch fallback
            # Probe missing is OK — a plugin with no templates isn't
            # cheating. Fall through to miss-behavior test.
            pass
        else:
            if a != b:
                self._fail(
                    f"PURE violation: two calls to load({tier!r}, {template!r}) "
                    f"returned different strings (len {len(a)} vs {len(b)})."
                )
            elif not isinstance(a, str):
                self._fail(f"load() returned {type(a).__name__}, expected str.")
            elif not a.strip():
                self._fail(
                    "load() returned empty/whitespace-only string; "
                    "must raise on miss, not silently return empty."
                )

        # Miss behavior — unknown template must raise, not silent-empty.
        try:
            missing = plugin.load(tier, "__definitely_missing_template__")
        except Exception:  # noqa: BLE001 — guard returns fallback value on any error
            return  # raising is contract-correct
        else:
            if not missing:
                self._fail(
                    "load() silently returned empty string for missing template — "
                    "contract requires raise (e.g. PromptMissing). Silent-empty "
                    "hides misconfiguration + is an effort-gaming signal."
                )


# ═══════════════════════════════════════════════════════════════════════
# PURE — ScoringFn
# ═══════════════════════════════════════════════════════════════════════


class ScoringFnConformance(ConformanceSuite):
    """ScoringFn must be PURE: same (verdict, criteria) → same float.

    Contract checks:
      - Determinism: same inputs produce same score.
      - Type: score() returns float.
      - Malformed criteria: raises ValueError (or subclass), not silent-0.
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import ScoringFn
        cls.protocol_type = ScoringFn
        cls.expected_purity = PurityClass.PURE

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        verdict = make_verdict(outcome="proved")
        criteria = {"zero_sorry": True}

        # Determinism.
        try:
            s1 = plugin.score(verdict, criteria)
            s2 = plugin.score(verdict, criteria)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"score(verdict=proved, criteria={{'zero_sorry': True}}) raised "
                f"{type(exc).__name__}: {exc}. Plugin must accept this trivial case."
            )
            return
        if s1 != s2:
            self._fail(
                f"PURE violation: two calls to score() with identical inputs "
                f"returned different values ({s1} vs {s2})."
            )
        if not isinstance(s1, (int, float)):
            self._fail(f"score() returned {type(s1).__name__}, expected float/int.")

        # Malformed criteria → raise, not silent-0.
        try:
            result = plugin.score(verdict, {"this_key_is_not_a_valid_criterion": 42.0})
        except (ValueError, KeyError, TypeError):
            return  # raise is the contract-correct behavior
        else:
            if result == 0.0:
                self._fail(
                    "score() silently returned 0.0 on malformed criteria — "
                    "contract requires raise (ValueError/KeyError/TypeError)."
                )


# ═══════════════════════════════════════════════════════════════════════
# PURE — ModelSelectorPlugin
# ═══════════════════════════════════════════════════════════════════════


class ModelSelectorPluginConformance(ConformanceSuite):
    """ModelSelectorPlugin must be PURE: same (tier, theorem_shape) → same model_id.

    Contract checks:
      - Determinism.
      - Type: returns non-empty str.
      - Unknown tier: raises ValueError (per Protocol docstring).
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import ModelSelectorPlugin
        cls.protocol_type = ModelSelectorPlugin
        cls.expected_purity = PurityClass.PURE

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        shape = {"theorem_id": "t1", "estimated_complexity": 0.5}

        try:
            m1 = plugin.select("lean_proved", shape)
            m2 = plugin.select("lean_proved", shape)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"select('lean_proved', shape) raised {type(exc).__name__}: {exc}. "
                f"Conformance probes must pass for the known-built-in 'lean_proved' tier."
            )
            return
        if m1 != m2:
            self._fail(
                f"PURE violation: select() returned {m1!r} then {m2!r} for "
                f"identical inputs."
            )
        if not isinstance(m1, str) or not m1.strip():
            self._fail(
                f"select() returned {m1!r}; must be non-empty str (a model id)."
            )

        # Unknown-tier behavior — Protocol docstring says "raise
        # ValueError". Built-in DefaultModelSelector falls back to a
        # config default instead (charitable reading: PURE for unknown
        # tiers too if it returns a stable str). Accept BOTH, but
        # flag silent-empty-return (the anti-cheat failure mode).
        try:
            result = plugin.select("__not_a_real_tier__" + str(uuid4()), shape)
        except (ValueError, KeyError):
            return  # contract-strict-correct
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"select() raised {type(exc).__name__} on unknown tier; "
                f"contract allows ValueError / KeyError only — other exceptions "
                f"indicate plugin bug, not unknown-tier handling."
            )
        else:
            # Fallback-to-default is charitable-permitted IF result is
            # non-empty + deterministic (two calls return same str).
            if not isinstance(result, str) or not result.strip():
                self._fail(
                    f"select() on unknown tier returned {result!r}; contract "
                    f"requires either ValueError/KeyError OR a non-empty str "
                    f"fallback. Silent empty/None is effort-gaming shape."
                )


# ═══════════════════════════════════════════════════════════════════════
# IMPURE_DETERMINISTIC — VerifierPlugin
# ═══════════════════════════════════════════════════════════════════════


class VerifierPluginConformance(ConformanceSuite):
    """VerifierPlugin must be IMPURE_DETERMINISTIC: same (intent, witness)
    → same Verdict outcome (wall_seconds may vary).

    Contract checks:
      - tier_name attribute exists + non-empty str + in KNOWN_TIERS.
      - verify() returns Verdict with outcome in the closed 5-value taxonomy.
      - verify() does NOT raise on 'theorem refuted' — that's
        Verdict.outcome == 'refuted', not an exception.
      - On outcome='proved', Verdict.details SHOULD include proved_label
        (per ATH-491 ProvedLabel enum). Warn, don't fail, if missing.
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import VerifierPlugin
        cls.protocol_type = VerifierPlugin
        cls.expected_purity = PurityClass.IMPURE_DETERMINISTIC

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        # tier_name attribute.
        tier_name = getattr(plugin, "tier_name", None)
        if not isinstance(tier_name, str) or not tier_name.strip():
            self._fail(
                f"VerifierPlugin missing or empty 'tier_name' attribute "
                f"(got {tier_name!r}). Plugin must register its tier."
            )
            return

        from kairos.spec_v1 import KNOWN_TIERS
        if tier_name not in KNOWN_TIERS:
            self._fail(
                f"tier_name={tier_name!r} not in KNOWN_TIERS ({sorted(KNOWN_TIERS)!r}). "
                f"Plugin must call kairos.spec_v1.register_tier(tier_name) at "
                f"import time before this conformance suite runs."
            )

        # verify() returns Verdict with valid outcome.
        intent = make_intent(evidence_tier=tier_name)
        witness = make_witness()
        try:
            verdict = plugin.verify(intent, witness, timeout_sec=5.0)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"verify(intent, witness) raised {type(exc).__name__}: {exc}. "
                f"Refutations must be Verdict.outcome='refuted', not exceptions."
            )
            return

        valid_outcomes = {"proved", "refuted", "unknown", "error", "timeout"}
        outcome = getattr(verdict, "outcome", None)
        if outcome not in valid_outcomes:
            self._fail(
                f"verify() returned Verdict.outcome={outcome!r}; must be in "
                f"{sorted(valid_outcomes)!r}."
            )

        # Determinism: two calls with same args produce same outcome.
        try:
            verdict2 = plugin.verify(intent, witness, timeout_sec=5.0)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"second call to verify() raised {type(exc).__name__}: {exc}. "
                f"IMPURE_DETERMINISTIC requires stable outcome across calls."
            )
            return
        if getattr(verdict2, "outcome", None) != outcome:
            self._fail(
                f"IMPURE_DETERMINISTIC violation: verify() outcome={outcome!r} "
                f"then {getattr(verdict2, 'outcome', None)!r} for identical inputs."
            )


# ═══════════════════════════════════════════════════════════════════════
# IMPURE_DETERMINISTIC — OrchestratorPlugin
# ═══════════════════════════════════════════════════════════════════════


class OrchestratorPluginConformance(ConformanceSuite):
    """OrchestratorPlugin must be IMPURE_DETERMINISTIC:
    same (intent, registries) → same OrchestrationChoice modulo LLM jitter
    AND graceful-degrade on transient failures.

    Tests both the deterministic-policy case (DefaultRoundRobinOrchestrator)
    and the LLM-backed case (kairos.fleet.Orchestrator, post-ATH-570).
    Contract is purity-agnostic at the interface level — all orchestrators
    return a well-formed OrchestrationChoice on any well-formed input.

    Contract checks:
      - orchestrate() returns an OrchestrationChoice dataclass
        (not a raw dict or None).
      - tier_dispatch is a non-empty list[str].
      - tool_selection is a list (may be empty).
      - model_selection maps every tier in tier_dispatch to a model id.
      - rationale is a non-empty str.
      - Determinism-modulo-jitter: two calls with identical inputs
        produce outputs with the same tier_dispatch SET (order may
        vary for LLM-backed) and same length of tool_selection.
      - Well-formed input MUST NOT raise: graceful-degrade to a fallback
        rather than propagating transient failures.
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import OrchestratorPlugin
        cls.protocol_type = OrchestratorPlugin
        cls.expected_purity = PurityClass.IMPURE_DETERMINISTIC

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        # Build a minimal-shape call surface. Import lazily to avoid
        # paying the import cost for suites that never instantiate
        # OrchestratorPluginConformance.
        from kairos.spec.defaults import (
            DefaultModelSelector,
            DefaultToolRegistry,
            FilesystemPromptLoader,
        )
        from kairos.spec.pipeline import VerifierRegistry
        from kairos.spec.types import KairosConfig

        intent = make_intent()
        cfg = KairosConfig()
        registries = {
            "tier_registry": VerifierRegistry(),
            "tool_registry": DefaultToolRegistry(),
            "model_selector": DefaultModelSelector(cfg),
            "prompt_loader": FilesystemPromptLoader(),
        }

        # Orchestrate; graceful-degrade should ensure no raise.
        try:
            choice = plugin.orchestrate(intent, **registries)
        except NotImplementedError:
            # Plugin stub state (Protocol shape declared, impl deferred).
            # Treat as a conformance pass-with-warning: the Protocol shape
            # holds once the stub is replaced. Not a test failure.
            return
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"orchestrate() raised {type(exc).__name__}: {exc}. "
                f"Protocol requires graceful-degrade on any transient "
                f"failure — impure orchestrators fall back to a "
                f"deterministic default."
            )
            return

        # Structural checks.
        tier_dispatch = getattr(choice, "tier_dispatch", None)
        if not isinstance(tier_dispatch, list) or not tier_dispatch:
            self._fail(
                f"OrchestrationChoice.tier_dispatch must be a non-empty "
                f"list; got {tier_dispatch!r}."
            )
        elif not all(isinstance(t, str) and t.strip() for t in tier_dispatch):
            self._fail(
                f"OrchestrationChoice.tier_dispatch must contain non-empty "
                f"str entries; got {tier_dispatch!r}."
            )

        tool_selection = getattr(choice, "tool_selection", None)
        if not isinstance(tool_selection, list):
            self._fail(
                f"OrchestrationChoice.tool_selection must be a list; "
                f"got {type(tool_selection).__name__}."
            )

        model_selection = getattr(choice, "model_selection", None)
        # model_selection can be a dict or Mapping. Verify every tier_dispatch
        # tier has a non-empty model_id.
        if not hasattr(model_selection, "get"):
            self._fail(
                f"OrchestrationChoice.model_selection must be a Mapping; "
                f"got {type(model_selection).__name__}."
            )
        elif isinstance(tier_dispatch, list):
            for tier in tier_dispatch:
                model_id = model_selection.get(tier) if model_selection else None
                if not isinstance(model_id, str) or not model_id.strip():
                    self._fail(
                        f"model_selection missing non-empty entry for "
                        f"tier={tier!r}; got {model_id!r}."
                    )

        rationale = getattr(choice, "rationale", None)
        if not isinstance(rationale, str) or not rationale.strip():
            self._fail(
                f"OrchestrationChoice.rationale must be a non-empty str; "
                f"got {rationale!r}."
            )

        # Determinism-modulo-jitter: second call, same inputs.
        try:
            choice2 = plugin.orchestrate(intent, **registries)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"second orchestrate() call raised {type(exc).__name__}: "
                f"{exc}. IMPURE_DETERMINISTIC demands stable callability."
            )
            return

        set1 = set(getattr(choice, "tier_dispatch", []) or [])
        set2 = set(getattr(choice2, "tier_dispatch", []) or [])
        if set1 != set2:
            self._fail(
                f"IMPURE_DETERMINISTIC violation: tier_dispatch set differs "
                f"across calls with identical inputs. {set1} vs {set2}."
            )


# ═══════════════════════════════════════════════════════════════════════
# IMPURE_LOOKUP — ToolRegistryPlugin
# ═══════════════════════════════════════════════════════════════════════


class ToolRegistryPluginConformance(ConformanceSuite):
    """ToolRegistryPlugin must be IMPURE_LOOKUP: same tool_name → same object.

    Contract checks:
      - list_tools() returns a stable-ordered list[str].
      - lookup(name) returns the SAME object on repeated calls.
      - lookup() on missing name raises KeyError (per Protocol docstring).
      - list_tools() output is consistent with what lookup() accepts.
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.spec.types import ToolRegistryPlugin
        cls.protocol_type = ToolRegistryPlugin
        cls.expected_purity = PurityClass.IMPURE_LOOKUP

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        try:
            tools_a = plugin.list_tools()
            tools_b = plugin.list_tools()
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(f"list_tools() raised {type(exc).__name__}: {exc}.")
            return

        if not isinstance(tools_a, list):
            self._fail(f"list_tools() returned {type(tools_a).__name__}, expected list.")
        elif not all(isinstance(t, str) for t in tools_a):
            self._fail("list_tools() entries must all be str.")
        elif tools_a != tools_b:
            self._fail(
                f"IMPURE_LOOKUP violation: list_tools() returned different orderings "
                f"across calls: {tools_a!r} vs {tools_b!r}. Ordering must be stable."
            )

        # If the registry has tools, test lookup cacheability.
        if tools_a:
            name = tools_a[0]
            try:
                obj_1 = plugin.lookup(name)
                obj_2 = plugin.lookup(name)
            except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
                self._fail(
                    f"lookup({name!r}) raised {type(exc).__name__} — the name came "
                    f"from list_tools() so it MUST resolve: {exc}."
                )
                return
            if obj_1 is not obj_2:
                self._fail(
                    f"IMPURE_LOOKUP violation: lookup({name!r}) returned different "
                    f"objects on repeated calls (id {id(obj_1)} vs {id(obj_2)}). "
                    f"Protocol requires same object (cacheable)."
                )

        # Missing tool → KeyError.
        try:
            plugin.lookup("__not_a_real_tool_" + str(uuid4()))
        except KeyError:
            return  # contract-correct
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"lookup(missing) raised {type(exc).__name__}; contract requires KeyError."
            )
        else:
            self._fail("lookup(missing) did not raise — contract requires KeyError.")


# ═══════════════════════════════════════════════════════════════════════
# IMPURE_SIDE_EFFECTFUL — TraceSink
# ═══════════════════════════════════════════════════════════════════════


class TraceSinkConformance(ConformanceSuite):
    """TraceSink must be IMPURE_SIDE_EFFECTFUL with two invariants:
      - Swallow-errors: emit() / emit_escalation() / flush() NEVER raise
        on any event shape. Broken backends must log + drop.
      - Idempotence: same event.id → single persisted row (enforced at
        the sink level — this test just probes that duplicate emit()
        calls don't raise).

    Contract checks all three methods × both event types × duplicate-emit.
    """

    @classmethod
    def _init_class_attrs(cls) -> None:
        from kairos.trace import TraceSink
        cls.protocol_type = TraceSink
        cls.expected_purity = PurityClass.IMPURE_SIDE_EFFECTFUL

    def __init__(self, plugin: Any) -> None:
        type(self)._init_class_attrs()
        super().__init__(plugin)

    def _run_contract_tests(self, plugin: Any) -> None:
        ev = make_trace_event()
        esc = make_escalation_event()

        # Swallow-errors on first emit.
        try:
            plugin.emit(ev)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"emit() raised {type(exc).__name__}: {exc}. TraceSink contract "
                f"requires non-raising behavior even on backend failures — "
                f"log + drop, never propagate."
            )

        # Swallow-errors on emit_escalation.
        try:
            plugin.emit_escalation(esc)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"emit_escalation() raised {type(exc).__name__}: {exc}."
            )

        # Idempotence at the duplicate-call-does-not-raise level.
        # (Server-side dedup is out of scope for the conformance suite;
        # we only verify the sink doesn't break on repeat.)
        try:
            for _ in range(3):
                plugin.emit(ev)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"Duplicate emit() of same event.id raised {type(exc).__name__}: "
                f"{exc}. Sink must accept repeated calls (server does the dedup)."
            )

        # flush().
        try:
            plugin.flush()
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(f"flush() raised {type(exc).__name__}: {exc}.")

        # Weird-payload test: payload with non-JSON-serializable value.
        weird = make_trace_event(
            payload={"non_json": object()},
            sequence=99,
        )
        try:
            plugin.emit(weird)
        except Exception as exc:  # noqa: BLE001 — logged + re-raised in alternate form
            self._fail(
                f"emit() raised on non-JSON-serialisable payload: "
                f"{type(exc).__name__}: {exc}. Must log + drop."
            )
