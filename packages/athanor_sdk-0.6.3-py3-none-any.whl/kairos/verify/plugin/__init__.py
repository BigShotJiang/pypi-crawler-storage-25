"""kairos.verify.plugin — Protocol conformance suites + anti-cheat detectors.

One conformance suite per purity class, one detector per recorded
cheat fingerprint. Public API:

    from kairos.verify.plugin import (
        # Base + taxonomy
        ConformanceSuite, PurityClass, MalformedProtocolDocstring,
        extract_purity,
        # 6 per-protocol subclasses (OrchestratorPlugin lands post-Gate-9)
        VerifierPluginConformance,
        PromptLoaderConformance,
        ScoringFnConformance,
        ModelSelectorPluginConformance,
        ToolRegistryPluginConformance,
        TraceSinkConformance,
    )

Scope per ATH-497 Gate 7 / 2026-04-23 extensibility scope-lock. See
``docs/sdk-agent-anti-cheat-audit.md`` for the 9-mechanism taxonomy
that complements this Protocol-conformance surface.
"""

from __future__ import annotations

from kairos.verify.plugin.base import (
    ConformanceSuite,
    MalformedProtocolDocstring,
    PurityClass,
    extract_purity,
)
from kairos.verify.plugin.suites import (
    ModelSelectorPluginConformance,
    OrchestratorPluginConformance,
    PromptLoaderConformance,
    ScoringFnConformance,
    ToolRegistryPluginConformance,
    TraceSinkConformance,
    VerifierPluginConformance,
)

__all__ = [
    "ConformanceSuite",
    "MalformedProtocolDocstring",
    "ModelSelectorPluginConformance",
    "OrchestratorPluginConformance",
    "PromptLoaderConformance",
    "PurityClass",
    "ScoringFnConformance",
    "ToolRegistryPluginConformance",
    "TraceSinkConformance",
    "VerifierPluginConformance",
    "extract_purity",
]
