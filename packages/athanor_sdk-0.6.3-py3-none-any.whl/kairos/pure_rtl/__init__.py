"""kairos.pure_rtl — PureRTL methodology surface (ATH-944).

Customer-2 (Annapurna/Todd) PureRTL methodology, Todd's 2026-05-01
#project-annapurna design:

* **Source-of-truth in Lean** (refinement-style spec via lean-machines —
  see :mod:`kairos.lean_machines`).
* **Codegen via Clash** — Lean → Haskell/Clash → SystemVerilog. The
  ``clash_codegen`` submodule wraps the Clash compiler.
* **Round-trip equivalence** — original SV ≡ regenerated SV via
  :mod:`kairos.eqy` (open-source) or SLEC (commercial). The
  ``roundtrip`` submodule composes the codegen + equivalence steps.
* **Optimizations proven first** — every payload-table /
  state-reduction / pipeline restructuring transformation is proven
  in Lean before the regenerated SV is shipped.

This is the v0 surface — Lean → Clash bridge is a deliberate manual
step (asabi 2026-05-01 14:08), and SV → Lean extraction is out of
scope (asabi 12:29 — "the riskiest hop"). Each lands in a follow-up
ticket once round-trip on one proven block is concrete.

Public surface::

    from kairos.pure_rtl import clash_codegen, roundtrip
    from kairos.pure_rtl.clash_codegen import generate_sv, ClashCodegenResult
    from kairos.pure_rtl.roundtrip import run_roundtrip, RoundtripResult
"""
from __future__ import annotations

__all__: list[str] = []
