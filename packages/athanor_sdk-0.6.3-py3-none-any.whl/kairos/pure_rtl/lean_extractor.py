"""kairos.pure_rtl.lean_extractor — SV → Lean source-of-truth extraction.

ATH-947 (Aidan green-lit 2026-05-03). The customer on-ramp half of
the PureRTL methodology: take an existing hand-written SystemVerilog
block plus the customer's pre-existing FV properties, and produce a
Lean source-of-truth that captures the SV semantics AND supports the
customer's properties.

Architecture: two gates, not one. asabi 2026-05-01 12:29 flagged
SV → Lean as "the riskiest hop" because LLMs can produce a Lean spec
that's a literal gate-level transcription of the SV — it passes
sequential equivalence but expresses nothing the customer can refine
or prove invariants over. Tautology specs cascade garbage downstream
into the optimization proposer.

  * **Gate 1 — EQY equivalence** (mandatory). The LLM produces both
    a Lean spec AND a matching Clash bridge; gate 1 reuses
    :func:`kairos.pure_rtl.clash_codegen.generate_sv` +
    :func:`kairos.eqy.verify` to prove
    ``original_sv ≡ Clash(LLM-proposed-Lean)``. Catches semantics
    drift between proposed Lean and the SV ground truth.
  * **Gate 2 — Property preservation** (mandatory). The customer's
    pre-existing FV properties (the ones their original SV was
    already proven against, expressed as Lean theorems) must prove
    against the LLM-proposed spec. Implemented as
    :func:`kairos.lean.verify_proof` over each property; rejected if
    any is unprovable. Catches the tautology class.

Both gates required. Either alone produces low-quality output.

Iteration loop:

1. LLM proposes Lean spec + Clash bridge from SV + property hints.
2. Gate 1: codegen + EQY equiv. If fail → feed counterexample to LLM,
   retry up to ``max_iterations``.
3. Gate 2: Lake build + property check. If fail → feed unprovable-
   property to LLM, retry.
4. Both gates pass → return spec.lean. Either gate exhausts iteration
   budget → return rejected.

Trace emit:

  * ``pure_rtl_lean_extraction_iter`` — per LLM round, with proposed
    Lean (truncated) + both gate verdicts.
  * ``pure_rtl_lean_extraction_complete`` — composite, final verdict
    + path to the chosen spec (or ``None`` on rejection).

Both registered in :data:`kairos.trace_schema.REGISTRY` per ATH-932
emit-registry gate.

Errors:

  * Missing API key → :class:`LeanExtractionResult` with
    ``verdict='error'``. Never raises ProviderError up to the caller.
  * Missing Clash / eqy / lake binary → ``verdict='error'`` with the
    underlying gate's stderr surfaced. Same contract as
    :func:`kairos.eqy.verify` and :func:`kairos.lean.verify_proof`.

Cross-ref:
  * :mod:`kairos.pure_rtl.roundtrip` — the other half of the loop
    (Lean → Clash → SV → EQY round-trip).
  * :func:`kairos.lean.verify_proof` — gate 2's property checker.
  * :mod:`kairos.eqy` + :mod:`kairos.pure_rtl.clash_codegen` — gate 1.
  * docs/internal/pure-rtl-qa-harness-draft.md — qa-harness corpus
    spec these extraction results feed into.
"""
from __future__ import annotations

import logging
import re
import textwrap
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.eqy import EqyResult, verify as eqy_verify
from kairos.model_presets import DEFAULT_PLANNER_MODEL
from kairos.pure_rtl.clash_codegen import ClashCodegenResult, generate_sv


_logger = logging.getLogger(__name__)


# ── Public types ─────────────────────────────────────────────────────


@dataclass
class LeanProperty:
    """One customer-supplied FV property the extracted Lean must support.

    The ``statement`` is a complete Lean theorem source in the style of
    ``theorem <name> ... := by ...`` (or ``:= by sorry`` if the LLM
    must close the proof). It MAY reference identifiers from the
    extracted spec (``CpuAdder.step``, ``CpuAdder.REG``, etc.) — the
    extractor passes the spec source into the lake project the
    property is verified against.
    """

    name: str
    statement: str


@dataclass
class IterationOutcome:
    """One LLM round + the verdicts of both gates against its proposal."""

    iteration: int
    proposed_lean: str
    proposed_clash: str
    gate1_verdict: str
    """``"proved"`` / ``"refuted"`` / ``"unknown"`` / ``"error"`` /
    ``"not_run"`` (the latter when gate 1 was skipped because codegen
    itself failed before EQY could run)."""

    gate1_codegen_success: bool
    gate2_property_verdicts: dict[str, str]
    """Per-property verdict map: name → ``"proved"`` / ``"refuted"`` /
    ``"error"``. Empty when gate 2 didn't run."""

    elapsed_sec: float
    feedback_for_next_iter: str | None
    """The counterexample / unprovable-property message fed back to
    the LLM on the next round. ``None`` when both gates passed."""


@dataclass
class LeanExtractionResult:
    """Composite outcome of one extraction run."""

    verdict: str
    """``"extracted"`` (both gates passed), ``"rejected"`` (iteration
    budget exhausted with at least one gate still failing), or
    ``"error"`` (toolchain / API failure)."""

    spec_lean_path: Path | None
    """Path to the validated Lean source-of-truth, when extracted.
    ``None`` on rejection or error."""

    iterations: list[IterationOutcome] = field(default_factory=list)
    elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def extracted(self) -> bool:
        return self.verdict == "extracted"


# ── LLM proposer ─────────────────────────────────────────────────────


_SYSTEM_PROMPT = """\
You are a formal-methods engineer extracting a Lean 4 source-of-truth
specification from existing SystemVerilog. Your output is validated
by two independent gates:

1. EQY sequential-equivalence between the original SV and a Clash
   compilation of your Lean spec. The Clash module you write must
   compile and produce SV that is sequentially equivalent to the
   original.
2. The customer's existing FV properties, written as Lean theorems
   referencing your spec, must prove (no `sorry`, no axioms beyond
   `propext`/`Quot.sound`/`Classical.choice`).

A Lean spec that is a literal gate-level transcription of the SV
will pass gate 1 but fail gate 2. Aim for a refinement-style spec
expressing the design's *intent*: a `step (state, input) -> (state', output)`
Mealy function over a small register record `REG`, with derived
operations factored out.

Output format: emit two fenced code blocks, in order, with these
exact fence labels:

```lean
-- Spec.lean
<your Lean source>
```

```haskell
-- Spec.hs (Clash)
<your Clash bridge>
```

The Clash module must declare `topEntity` with the same port names
and widths as the original SV's top module. Use `Clash.Prelude`'s
`mealy` combinator with the same `step` shape as your Lean spec.

No prose between or after the blocks. Concise comments inside the
code are fine.
"""


_USER_PROMPT_TEMPLATE = """\
Extract a Lean 4 spec for this SystemVerilog block:

SystemVerilog source (top module: `{top_module}`):
```systemverilog
{sv_source}
```

The customer's existing FV properties (each must prove against your
spec):
{property_list}

{previous_iteration_feedback}
"""


def _build_property_list(properties: Sequence[LeanProperty]) -> str:
    if not properties:
        return "(none)"
    lines = []
    for p in properties:
        lines.append(f"- `{p.name}`:")
        lines.append("```lean")
        lines.append(p.statement.strip())
        lines.append("```")
    return "\n".join(lines)


def _build_user_prompt(
    sv_source: str,
    top_module: str,
    properties: Sequence[LeanProperty],
    previous_feedback: str | None,
) -> str:
    feedback_block = ""
    if previous_feedback:
        feedback_block = (
            "Your previous proposal failed validation. Specific feedback:\n"
            f"{previous_feedback}\n\n"
            "Revise the spec to address the failure. Keep what worked; "
            "change only what's needed."
        )
    return _USER_PROMPT_TEMPLATE.format(
        top_module=top_module,
        sv_source=sv_source.strip(),
        property_list=_build_property_list(properties),
        previous_iteration_feedback=feedback_block,
    )


_LEAN_FENCE_RE = re.compile(
    r"```lean\s*\n(.*?)\n```",
    re.DOTALL | re.IGNORECASE,
)
_CLASH_FENCE_RE = re.compile(
    r"```haskell\s*\n(.*?)\n```",
    re.DOTALL | re.IGNORECASE,
)


def _extract_blocks(content: str) -> tuple[str | None, str | None]:
    """Pull the ```lean and ```haskell blocks out of the LLM response."""
    lean_match = _LEAN_FENCE_RE.search(content)
    clash_match = _CLASH_FENCE_RE.search(content)
    lean_src = lean_match.group(1).strip() if lean_match else None
    clash_src = clash_match.group(1).strip() if clash_match else None
    return lean_src, clash_src


def _call_llm(
    *,
    sv_source: str,
    top_module: str,
    properties: Sequence[LeanProperty],
    previous_feedback: str | None,
    model: str,
    timeout_sec: int,
) -> tuple[str | None, str | None, str | None]:
    """One LLM call. Returns ``(lean_src, clash_src, error)``.

    On any provider error or missing fenced block, returns
    ``(None, None, error_message)``. The caller decides whether to
    surface that as a failed iteration or a hard error.
    """
    try:
        from kairos.model_client import get_client
    except ImportError as e:  # pragma: no cover — kairos.model_client is core
        return None, None, f"kairos.model_client unavailable: {e}"

    try:
        client = get_client(model)
    except Exception as e:  # noqa: BLE001 — provider/registry surface is broad
        return None, None, f"get_client({model!r}) failed: {e}"

    user_prompt = _build_user_prompt(
        sv_source=sv_source,
        top_module=top_module,
        properties=properties,
        previous_feedback=previous_feedback,
    )

    try:
        messages = client.format_messages(_SYSTEM_PROMPT, user_prompt)
        response = client.call(messages=messages, timeout=timeout_sec)
    except Exception as e:  # noqa: BLE001 — provider surfaces are broad
        return None, None, f"LLM call failed: {e}"

    if response.error:
        return None, None, f"LLM transient error: {response.error}"
    if not response.content:
        return None, None, "LLM returned empty content"

    lean_src, clash_src = _extract_blocks(response.content)
    if lean_src is None:
        return None, None, "LLM response missing ```lean block"
    if clash_src is None:
        return lean_src, None, "LLM response missing ```haskell block"
    return lean_src, clash_src, None


# ── Gate 1: EQY equivalence ──────────────────────────────────────────


def _run_gate1(
    *,
    sv_file: Path,
    proposed_clash: str,
    top_module: str,
    iter_workdir: Path,
    timeout_sec_codegen: int,
    timeout_sec_equiv: int,
) -> tuple[str, ClashCodegenResult, EqyResult | None]:
    """Compile the proposed Clash and EQY-verify against the original SV.

    Returns ``(verdict, codegen_result, eqy_result)`` where ``verdict``
    is one of ``"proved" / "refuted" / "unknown" / "error" / "not_run"``.
    ``"not_run"`` means codegen itself failed; eqy_result is ``None``
    in that case.
    """
    hs_path = iter_workdir / "Spec.hs"
    hs_path.write_text(proposed_clash)

    codegen = generate_sv(
        hs_path,
        top_module=top_module,
        output_dir=iter_workdir / "clash-out",
        timeout_sec=timeout_sec_codegen,
        emit_trace=False,
    )
    if not codegen.success or codegen.output_sv_file is None:
        return "not_run", codegen, None

    eqy_res = eqy_verify(
        sv_file,
        codegen.output_sv_file,
        top_module=top_module,
        workdir=iter_workdir / "eqy",
        timeout_sec=timeout_sec_equiv,
        emit_trace=False,
    )
    return eqy_res.verdict, codegen, eqy_res


# ── Gate 2: property preservation ────────────────────────────────────


def _run_gate2(
    *,
    proposed_lean: str,
    properties: Sequence[LeanProperty],
    iter_workdir: Path,
    lake_project: Path | None,
    timeout_sec_per_property: int,
) -> dict[str, str]:
    """Verify each customer property against the proposed Lean spec.

    Builds a scratch lake project (or uses ``lake_project`` if
    supplied), drops ``Spec.lean`` + a ``<name>.lean`` per property
    that imports Spec and asserts the property as a theorem, then
    runs :func:`kairos.lean.verify_proof` on each.

    Returns a ``{property_name: verdict}`` map where each verdict is
    ``"proved"`` / ``"refuted"`` / ``"error"``.
    """
    from kairos.lean import verify_proof

    spec_path = iter_workdir / "Spec.lean"
    spec_path.write_text(proposed_lean)

    verdicts: dict[str, str] = {}
    for prop in properties:
        # Frame the property as a self-contained Lean source: import
        # the spec module (by including it as a prelude), then assert
        # the theorem. verify_proof checks compiles + no-sorry +
        # axiom audit.
        full_source = f"{proposed_lean}\n\n{prop.statement}\n"
        try:
            result = verify_proof(
                full_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_property,
            )
        except Exception as e:  # noqa: BLE001 — lake / lean surfaces are broad
            verdicts[prop.name] = "error"
            _logger.warning("gate2 property %r raised: %s", prop.name, e)
            continue

        # Verdict mapping (precedence top-to-bottom). Unsound proofs
        # MUST surface as "refuted" not "error" so the iteration
        # loop's feedback path keeps pressing the LLM to produce a
        # sound proof, instead of silently giving up on a property
        # that compiled but used a banned construct / forbidden axiom.
        if not result.compiles:
            # Compile failure on a property is a refutation against
            # *this* proposed spec — could be a missing identifier,
            # type error, etc. The next iteration gets a chance to
            # fix it.
            verdicts[prop.name] = "refuted"
        elif result.has_sorry:
            # Compiled with `sorry` — proof is incomplete.
            verdicts[prop.name] = "refuted"
        elif result.banned:
            # ATH-947 follow-up: banned constructs (axiom decls, unsafe
            # defs, Mathlib import, etc.) bypass the proof obligation.
            # Surface as refuted so the LLM gets feedback.
            verdicts[prop.name] = "refuted"
        elif result.axiom_clean is False:
            # ATH-947 follow-up: transitive axiom audit found a
            # non-allowlist axiom (e.g. sorryAx leak from a vacuous
            # self-reference). Same soundness class as `banned` — refute.
            verdicts[prop.name] = "refuted"
        elif result.score >= 1.0:
            verdicts[prop.name] = "proved"
        else:
            # Compiled, no sorry, no banned, no forbidden axioms, but
            # score < 1.0. This combination is not supposed to happen
            # with the current ProofResult contract — surface as error
            # so we notice if the contract drifts.
            verdicts[prop.name] = "error"

    return verdicts


# ── Iteration loop helpers ───────────────────────────────────────────


def _build_feedback(
    *,
    gate1_verdict: str,
    codegen: ClashCodegenResult,
    eqy_res: EqyResult | None,
    gate2_verdicts: dict[str, str],
) -> str | None:
    """Construct the counterexample / unprovable-property message fed
    back to the LLM for the next iteration. ``None`` when nothing to
    report (i.e., both gates passed)."""
    parts: list[str] = []

    if gate1_verdict == "not_run":
        # Codegen failed before EQY ran.
        parts.append(
            "Gate 1 (EQY equivalence): could NOT run because Clash "
            "codegen failed.\n"
            f"Clash stderr (truncated):\n{codegen.stderr[-1500:]}"
        )
    elif gate1_verdict == "refuted":
        snippet = (eqy_res.stdout if eqy_res else "")[-1500:]
        parts.append(
            "Gate 1 (EQY equivalence): REFUTED. Your proposed Clash "
            "compiles to SV that is NOT sequentially equivalent to "
            "the original SV.\n"
            f"EQY transcript (truncated):\n{snippet}"
        )
    elif gate1_verdict in ("unknown", "error"):
        parts.append(
            f"Gate 1 (EQY equivalence): verdict={gate1_verdict}. "
            "Your proposal could not be conclusively verified."
        )

    if gate2_verdicts:
        unprovable = [
            (n, v) for n, v in gate2_verdicts.items() if v != "proved"
        ]
        if unprovable:
            details = "\n".join(
                f"  - {n}: {v}" for n, v in unprovable
            )
            parts.append(
                "Gate 2 (property preservation): the following customer "
                "properties did NOT prove against your spec:\n"
                f"{details}\n"
                "Revise the spec so each unprovable property becomes a "
                "valid theorem."
            )

    if not parts:
        return None
    return "\n\n".join(parts)


# ── Public extract entry point ───────────────────────────────────────


def extract(
    sv_file: str | Path,
    customer_properties: Sequence[LeanProperty],
    *,
    top_module: str,
    workdir: str | Path,
    max_iterations: int = 5,
    model: str = DEFAULT_PLANNER_MODEL,
    lake_project: str | Path | None = None,
    timeout_sec_llm: int = 300,
    timeout_sec_codegen: int = 600,
    timeout_sec_equiv: int = 600,
    timeout_sec_per_property: int = 300,
    emit_trace: bool = True,
) -> LeanExtractionResult:
    """Run the SV → Lean two-gate iterative extractor.

    Args:
        sv_file: path to the original SystemVerilog source.
        customer_properties: list of :class:`LeanProperty` the
            extracted spec must support. Each ``statement`` is a
            complete Lean theorem.
        top_module: top module name in ``sv_file``. Used for the
            EQY equivalence target on both sides.
        workdir: directory for per-iteration scratch (``iter-<N>/``).
            Created if missing. Final ``Spec.lean`` lands at
            ``<workdir>/Spec.lean`` on success.
        max_iterations: cap on LLM rounds. Default 5.
        model: model ID passed to :func:`kairos.model_client.get_client`.
        lake_project: optional pre-existing Lake project to verify
            properties against. ``None`` → :func:`kairos.lean.verify_proof`
            uses its container path (no lake project).
        timeout_sec_llm: per-LLM-call wall-clock cap.
        timeout_sec_codegen: per-Clash-call cap.
        timeout_sec_equiv: per-EQY-call cap.
        timeout_sec_per_property: per-Lean-verification cap.
        emit_trace: when True (default), emit ``pure_rtl_lean_extraction_iter``
            per round and ``pure_rtl_lean_extraction_complete`` at the end.

    Returns:
        :class:`LeanExtractionResult` with the verdict + iteration log.
        Never raises for missing toolchain or API errors — those
        surface as ``verdict='error'``.
    """
    sv_path = Path(sv_file).resolve()
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)
    lake_project_path = Path(lake_project).resolve() if lake_project else None

    if not sv_path.exists():
        return LeanExtractionResult(
            verdict="error",
            spec_lean_path=None,
            error_message=f"sv_file does not exist: {sv_path}",
        )

    sv_source = sv_path.read_text()
    iterations: list[IterationOutcome] = []
    feedback: str | None = None
    chosen_lean: str | None = None
    t0 = time.monotonic()

    for i in range(1, max_iterations + 1):
        iter_workdir = workdir_path / f"iter-{i:02d}"
        iter_workdir.mkdir(parents=True, exist_ok=True)
        iter_t0 = time.monotonic()

        lean_src, clash_src, llm_error = _call_llm(
            sv_source=sv_source,
            top_module=top_module,
            properties=customer_properties,
            previous_feedback=feedback,
            model=model,
            timeout_sec=timeout_sec_llm,
        )
        if lean_src is None or clash_src is None:
            outcome = IterationOutcome(
                iteration=i,
                proposed_lean=lean_src or "",
                proposed_clash=clash_src or "",
                gate1_verdict="not_run",
                gate1_codegen_success=False,
                gate2_property_verdicts={},
                elapsed_sec=round(time.monotonic() - iter_t0, 3),
                feedback_for_next_iter=llm_error,
            )
            iterations.append(outcome)
            if emit_trace:
                _emit_iter(outcome, sv_path=sv_path, top_module=top_module)
            # LLM hard error → bail; don't burn more budget on a
            # broken provider.
            return LeanExtractionResult(
                verdict="error",
                spec_lean_path=None,
                iterations=iterations,
                elapsed_sec=round(time.monotonic() - t0, 3),
                error_message=llm_error,
            )

        # Persist the proposed sources for diffability.
        (iter_workdir / "Spec.lean").write_text(lean_src)
        (iter_workdir / "Spec.hs").write_text(clash_src)

        # Gate 1: EQY equivalence.
        gate1_verdict, codegen, eqy_res = _run_gate1(
            sv_file=sv_path,
            proposed_clash=clash_src,
            top_module=top_module,
            iter_workdir=iter_workdir,
            timeout_sec_codegen=timeout_sec_codegen,
            timeout_sec_equiv=timeout_sec_equiv,
        )

        # Gate 2: only run when gate 1 passed (a proven-equivalent
        # spec is the prerequisite for the property check to mean
        # anything).
        gate2_verdicts: dict[str, str] = {}
        if gate1_verdict == "proved":
            gate2_verdicts = _run_gate2(
                proposed_lean=lean_src,
                properties=customer_properties,
                iter_workdir=iter_workdir,
                lake_project=lake_project_path,
                timeout_sec_per_property=timeout_sec_per_property,
            )

        feedback = _build_feedback(
            gate1_verdict=gate1_verdict,
            codegen=codegen,
            eqy_res=eqy_res,
            gate2_verdicts=gate2_verdicts,
        )

        outcome = IterationOutcome(
            iteration=i,
            proposed_lean=lean_src,
            proposed_clash=clash_src,
            gate1_verdict=gate1_verdict,
            gate1_codegen_success=codegen.success,
            gate2_property_verdicts=gate2_verdicts,
            elapsed_sec=round(time.monotonic() - iter_t0, 3),
            feedback_for_next_iter=feedback,
        )
        iterations.append(outcome)
        if emit_trace:
            _emit_iter(outcome, sv_path=sv_path, top_module=top_module)

        # Both gates pass when feedback is None.
        if feedback is None:
            chosen_lean = lean_src
            break

    elapsed = round(time.monotonic() - t0, 3)

    if chosen_lean is not None:
        spec_path = workdir_path / "Spec.lean"
        spec_path.write_text(chosen_lean)
        result = LeanExtractionResult(
            verdict="extracted",
            spec_lean_path=spec_path,
            iterations=iterations,
            elapsed_sec=elapsed,
        )
    else:
        result = LeanExtractionResult(
            verdict="rejected",
            spec_lean_path=None,
            iterations=iterations,
            elapsed_sec=elapsed,
        )

    if emit_trace:
        _emit_complete(result, sv_path=sv_path, top_module=top_module)

    return result


# ── Trace emit helpers ───────────────────────────────────────────────


def _truncate(text: str, cap: int = 2000) -> str:
    """Cap a string to ``cap`` chars with a ``…<truncated>`` suffix."""
    if len(text) <= cap:
        return text
    return text[:cap] + f"…<truncated, full length {len(text)}>"


def _emit_iter(
    outcome: IterationOutcome,
    *,
    sv_path: Path,
    top_module: str,
) -> None:
    try:
        from kairos.observe import emit
        emit(
            "pure_rtl_lean_extraction_iter",
            {
                "sv_file": str(sv_path),
                "top_module": top_module,
                "iteration": outcome.iteration,
                "gate1_verdict": outcome.gate1_verdict,
                "gate1_codegen_success": outcome.gate1_codegen_success,
                "gate2_property_verdicts": dict(outcome.gate2_property_verdicts),
                "elapsed_sec": outcome.elapsed_sec,
                "proposed_lean_preview": _truncate(outcome.proposed_lean),
                "proposed_clash_preview": _truncate(outcome.proposed_clash),
                "feedback_preview": (
                    _truncate(outcome.feedback_for_next_iter)
                    if outcome.feedback_for_next_iter
                    else None
                ),
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break extract()
        pass


def _emit_complete(
    result: LeanExtractionResult,
    *,
    sv_path: Path,
    top_module: str,
) -> None:
    try:
        from kairos.observe import emit
        emit(
            "pure_rtl_lean_extraction_complete",
            {
                "sv_file": str(sv_path),
                "top_module": top_module,
                "verdict": result.verdict,
                "spec_lean_path": (
                    str(result.spec_lean_path) if result.spec_lean_path else None
                ),
                "iterations_taken": len(result.iterations),
                "elapsed_sec": result.elapsed_sec,
                "error_message": result.error_message,
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break extract()
        pass


__all__ = [
    "LeanProperty",
    "IterationOutcome",
    "LeanExtractionResult",
    "extract",
]
