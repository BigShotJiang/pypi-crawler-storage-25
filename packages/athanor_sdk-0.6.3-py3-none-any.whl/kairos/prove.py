"""kairos.prove — Tier 1 customer-facing Python API.

Per Aidan 2026-04-23 two-tier framing:

  - Tier 1 (this module): customer brings their own agent (Opus 4.7 /
    Claude Code / Cursor / Aider). Agent drafts code, calls
    ``kairos.prove(...)``, branches on the returned Verdict, iterates.
    No kairos-side orchestration loop — the agent owns the loop.

  - Tier 2 (kairos.spec.pipeline.SpecPipeline directly): fleet-mode
    orchestration via :class:`kairos.fleet.Orchestrator` — kairos does
    the LLM tier planning + multi-tier dispatch. For hard problems
    where the customer wants us to drive.

Tier 1 shape:

    from kairos import prove, session
    result = prove(
        "reno_cca.cwnd stays ≥ MSS on reset",
        vertical="ebmc",
        target_file="reno.sv",
    )
    if result.outcome == "proved":
        ...  # agent's loop continues
    elif result.outcome == "refuted":
        agent_receives(result.refined_prompt_suggestion())

    # Multi-iteration work on the same logical task — trace all
    # prove() calls under one session_id so Supabase dashboards can
    # group the iterations.
    with session(task_id="cedar-gen-2026-04-23") as sess:
        for iteration in range(20):
            draft = agent.draft_code(feedback=last_result)
            last_result = sess.prove(draft, vertical="lean",
                                     target_file="Generator.lean")
            if last_result.outcome == "proved":
                break

Trace events flow through :class:`kairos.spec.pipeline.SpecPipeline`'s
default TraceSink (NoopTraceSink by default; SupabaseTraceSink when
``KAIROS_TRACE_SINK=supabase`` is set). See
:func:`kairos.spec.pipeline._default_trace_sink` for the env-var
contract.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterator, Mapping
from uuid import UUID, uuid4


def _validate_run_id_uuid(run_id: str | None) -> str:
    """ATH-650 P1#1: ensure run_id begins with a UUID prefix before it
    reaches the DB layer. Pre-fix, callers passing semantic labels (e.g.
    ``"swarm-ablation-quantization_error"``) made it through to
    ``open_run`` which HTTP-400'd on the ``solve_runs.id uuid`` column,
    but child events still POSTed via ``sdk_agent_events.run_id text``,
    silently producing orphans. Research's swarm sweeps were the visible
    accumulator (~20 events orphaned per non-UUID label, daily).

    Accepted shapes:
      * ``None`` / ``""`` ⇒ fresh UUID4 generated.
      * ``"<uuid>"`` ⇒ canonicalised (dashed lowercase) and returned.
      * ``"<uuid>:<suffix>"`` ⇒ canonicalised UUID + literal colon +
        suffix preserved. The session iteration mechanism uses this
        ``<session_id>:iter-N`` shape; the suffix is metadata, not a
        join key, so the prefix UUID is what matters for the
        parent-row contract.

    A non-empty input that does NOT begin with a valid UUID raises
    :class:`RuntimeError` to match #205's ``_resolve_organization_id``
    waterfall — both are session-init boundary checks that should fail
    loud, not silently produce ill-formed parent rows.
    """
    if run_id is None or run_id == "":
        return str(uuid4())
    head, sep, tail = run_id.partition(":")
    try:
        canonical = str(UUID(head))
    except (ValueError, AttributeError, TypeError) as exc:
        raise RuntimeError(
            f"run_id must begin with a UUID (RFC 4122). Got: {run_id!r}. "
            f"Accepted shapes: '<uuid>' OR '<uuid>:<suffix>' "
            f"(the iteration shape '<session_id>:iter-N' is supported). "
            f"Pre-ATH-650 fix, semantic labels like "
            f"'swarm-ablation-quantization_error' silently produced "
            f"orphan sdk_agent_events rows because solve_runs.id "
            f"(uuid column) HTTP-400'd while child events POST'd "
            f"successfully. See ATH-650 finding #1."
        ) from exc
    return canonical + sep + tail if sep else canonical

from kairos.spec.pipeline import RunResult, SpecPipeline
from kairos.spec.types import KairosConfig, Verdict


# ═══════════════════════════════════════════════════════════════════════
# Result shape
# ═══════════════════════════════════════════════════════════════════════


@dataclass
class ProveResult:
    """Tier 1 return type — a flat view on SpecPipeline's RunResult.

    Agent-friendly: the most useful fields are top-level, the full
    run details are reachable via ``run_result`` for deeper access.
    """

    # Primary outcome — most agents branch on this.
    outcome: str  # "proved" | "refuted" | "unknown" | "error"
    # Human-readable reason string (carries counterexample for refuted,
    # sorry-count for unknown, error message for error).
    reason: str
    # Aggregate score: 1.0 proved, 0.5 unknown, 0.0 refuted/error.
    score: float
    # Cumulative LLM spend in USD for this prove() call.
    cost_usd: float
    # Which tier closed the result (e.g. "bmc_bounded", "lean_proved",
    # "nki_kernel"). Reads the first tier that returned a non-error
    # verdict; fallback to the dispatched tier name.
    tier: str
    # Per-tier details dict (proved_count, counterexample, bound_k,
    # property_verdicts, etc.). Agent-opaque shape — read for tier-
    # specific features.
    details: dict[str, Any] = field(default_factory=dict)
    # Unique run_id for this invocation. When inside a session(), the
    # session_id is the prefix; otherwise a fresh UUID.
    run_id: str = ""
    # Session grouping key (None when no session was active).
    session_id: str | None = None
    # Escalation events fired during the run (budget_exhausted,
    # handoff_without_verifier, etc.). Non-fatal signals.
    escalations: list[dict[str, Any]] = field(default_factory=list)
    # Full underlying RunResult for callers that need the complete
    # orchestration + tier-by-tier shape. Agents rarely need this.
    run_result: RunResult | None = None

    def as_dict(self) -> dict[str, Any]:
        """Serialise to a plain dict — safe to hand to json.dumps().

        Omits the ``run_result`` field (RunResult contains dataclass
        instances; use ``run_result.orchestration.tier_dispatch`` etc
        directly if you need the raw structured form).
        """
        d = asdict(self)
        # run_result is asdict-expanded recursively; drop it for a
        # flat JSON-friendly shape.
        d.pop("run_result", None)
        return d

    def refined_prompt_suggestion(self) -> str:
        """Generate a one-paragraph suggestion for the next agent
        iteration based on this outcome.

        Agents call this to get a feedback string they can feed into
        their next draft prompt — lifts some of the work off the
        agent's reasoning chain.

        Returns an empty string when no iteration is needed
        (outcome='proved' with score 1.0).
        """
        if self.outcome == "proved" and self.score >= 1.0:
            return ""  # Nothing to refine — proof closes.

        if self.outcome == "refuted":
            # ATH-523 unified Counterexample shape — prefer .summary when a
            # plugin emits the canonical dataclass; fall back to the legacy
            # string keys for any pre-523 plugin still returning ad-hoc
            # details. Import locally to avoid pulling spec.types at module
            # import time (ProveResult is part of the hot path).
            from kairos.spec.types import Counterexample as _CE

            cex = self.details.get("counterexample")
            if isinstance(cex, _CE):
                cex_summary: Any = cex.summary
            else:
                cex_summary = cex or self.details.get("refutation_summary")
            cex_str = f" Counterexample: {cex_summary}" if cex_summary else ""
            return (
                f"Your draft was refuted by the verifier. "
                f"Reason: {self.reason}{cex_str} "
                f"Adjust the draft to handle the failing case, then "
                f"resubmit via kairos.prove()."
            )

        if self.outcome == "unknown":
            sorry_count = self.details.get("sorry_count")
            sorry_str = (
                f" {sorry_count} `sorry` markers remain."
                if sorry_count else ""
            )
            return (
                f"Verifier reached a bounded or partial result — "
                f"your draft compiles but is not fully closed.{sorry_str} "
                f"Fill in the remaining gaps or raise bound/depth "
                f"(witness['bound']) and resubmit."
            )

        # error case
        return (
            f"Verifier errored: {self.reason}. Check the witness "
            f"shape (sv_file / lean_file / bundle_path as required "
            f"by the vertical) and resubmit."
        )


# ═══════════════════════════════════════════════════════════════════════
# prove() — single-shot Tier 1 entry
# ═══════════════════════════════════════════════════════════════════════


def prove(
    hypothesis: str,
    *,
    vertical: str,
    target_file: str | Path,
    target_name: str | None = None,
    target_kind: str = "theorem",
    bound_k: int | None = None,
    witness: Mapping[str, Any] | None = None,
    cost_budget_usd: float | None = None,
    config: KairosConfig | None = None,
    run_id: str | None = None,
    session_id: str | None = None,
) -> ProveResult:
    """Prove a natural-language hypothesis against a spec file.

    Tier 1 customer-agent entry. Calls
    :func:`kairos.verticals.nl_frontend.nl_to_intent` to build an
    IntentV1, constructs a default SpecPipeline, dispatches, returns
    the first meaningful Verdict as a :class:`ProveResult`.

    Args:
        hypothesis: free-text claim ("prove reno_cca.cwnd stays ≥ MSS
            on reset", "prove forbid overrides permit in the Cedar
            policy above").
        vertical: nl_frontend template name. Current options:
            ``"ebmc"`` (SystemVerilog + EBMC) or ``"lean"``
            (Lean 4 proof via ``lake build``). Extend via
            :data:`kairos.verticals.nl_frontend._VERTICAL_TEMPLATES`.
        target_file: path to the spec / kernel / proof file.
        target_name: logical name of the target (property, theorem,
            kernel). Optional — for ebmc we auto-detect the top
            module from the file when omitted.
        target_kind: ``"theorem"`` (default), ``"property"``, ``"kernel"``.
        bound_k: for ebmc, BMC depth. Default per vertical template.
        witness: optional overrides to the witness dict passed to the
            VerifierPlugin (e.g. ``{"bound": 30}`` for ebmc).
        cost_budget_usd: optional cumulative LLM spend cap. Halts
            mid-run with budget_exhausted escalation if exceeded.
        config: optional KairosConfig override.
        run_id: optional stable run id (for retry semantics). Default
            is a fresh UUID4.
        session_id: optional grouping key — used by :func:`session`
            under the hood. Customers typically don't set this directly.

    Returns:
        :class:`ProveResult` with ``outcome``, ``reason``, ``score``,
        ``cost_usd``, per-tier ``details``, and a ``refined_prompt_suggestion()``
        helper for the agent's next iteration.

    Example:

        >>> result = prove(
        ...     "reno_cca passes all invariants",
        ...     vertical="ebmc",
        ...     target_file="reno_hardened.sv",
        ... )
        >>> print(result.outcome, result.score)
        proved 1.0

    Tier classification: paid (requires the ``solve`` product).
    Raises :class:`kairos.license_scope.LicenseScopeError` when
    ``~/.athanor/license.json`` is missing or its products don't
    include ``solve``. Free-tier callers should use
    :func:`kairos.simple_prove` or :func:`kairos.simple_prove_template`.
    """
    # ATH-686 P1: paid-tier programmatic API → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    from kairos.verticals import register_defaults
    from kairos.verticals.nl_frontend import nl_to_intent

    register_defaults()

    # For ebmc, auto-detect the top module from the file when
    # target_name is omitted — same logic the `kairos prove` CLI uses.
    resolved_target_name = target_name
    if resolved_target_name is None and vertical == "ebmc":
        import re as _re
        try:
            text = Path(target_file).read_text()
            m = _re.search(r"^\s*module\s+(\w+)", text, _re.MULTILINE)
            if m:
                resolved_target_name = m.group(1)
        except OSError:
            pass

    intent = nl_to_intent(
        hypothesis,
        vertical=vertical,
        target_file=str(target_file),
        target_name=resolved_target_name,
        target_kind=target_kind,
        bound_k=bound_k,
    )
    # Layer witness overrides by tucking them under intent['witness']
    # (the plugins read witness directly from SpecPipeline's .verify(
    # intent, witness) second arg; SpecPipeline passes {} today, so
    # customer overrides land in intent for plugin fallback).
    if witness:
        intent = {**intent, "witness": dict(witness)}

    # ATH-819: resolve a single sink for both SpecPipeline and the
    # function_inputs capture below so customer reads of /solve-runs/[id]
    # see what `kairos.prove(...)` was called with. Defaults to Noop
    # unless `KAIROS_TRACE_SINK=supabase` (privacy contract preserved).
    from kairos.trace import default_sink_from_env, emit_function_inputs
    _resolved_sink = default_sink_from_env()
    pipeline = SpecPipeline(config=config, trace_sink=_resolved_sink)
    run_uuid = _validate_run_id_uuid(run_id)

    emit_function_inputs(
        _resolved_sink,
        run_id=run_uuid,
        run_subtype="spec_pipeline",
        function_name="kairos.prove",
        args={
            "hypothesis": hypothesis,
            "vertical": vertical,
            "target_file": str(target_file),
            "target_name": resolved_target_name,
            "target_kind": target_kind,
            "bound_k": bound_k,
            "witness": dict(witness) if witness else None,
            "cost_budget_usd": cost_budget_usd,
        },
    )

    run_result = pipeline.run(intent, run_id=run_uuid,
                               cost_budget_usd=cost_budget_usd)
    return _result_from_run(run_result, session_id=session_id, run_id=run_uuid)


# ═══════════════════════════════════════════════════════════════════════
# session() — grouped multi-iteration context
# ═══════════════════════════════════════════════════════════════════════


class Session:
    """Groups multiple prove() calls under one logical task.

    Agents typically iterate — draft, prove, refine, re-prove. Without
    grouping, each iteration appears as an independent run in the
    trace store. A Session stamps a shared ``session_id`` so customer
    dashboards can roll up the iterations as one task, with
    per-iteration rows underneath.

    Use via the :func:`session` context manager:

        with session(task_id="cedar-gen-2026-04-23") as sess:
            for i in range(20):
                r = sess.prove(draft, vertical="lean",
                               target_file="Gen.lean")
                if r.outcome == "proved":
                    break

    The ``task_id`` is a customer-facing label (their name for the
    task). The ``session_id`` is the UUID used as the trace-row prefix.
    ``task_id`` goes into the session's metadata so dashboards can
    surface it.
    """

    def __init__(self, task_id: str, *, config: KairosConfig | None = None):
        import itertools as _it
        import threading as _thr

        self.task_id = task_id
        self.session_id = str(uuid4())
        self._config = config
        self._iterations: list[ProveResult] = []
        # ATH-625-follow-up: emit helper state. The session() context
        # manager populates _sink + _default_run_subtype after Session
        # construction so callers can invoke session.emit(...) from
        # worker threads without juggling run_id / sink themselves.
        # Pre-populated here so .emit() on a bare-constructed Session
        # is a graceful no-op (returns False) rather than AttributeError.
        self._sink: Any = None
        self._default_run_subtype: str | None = None
        # Monotonic sequence counter, thread-safe via itertools.count
        # which has GIL-protected next(). Worker threads can call .emit()
        # concurrently and each row gets a unique sequence number.
        self._sequence_counter = _it.count(start=1)
        # A reentrant lock would be overkill — we only protect the
        # sink-set assignment from session() to avoid torn writes.
        self._lock = _thr.Lock()

    # ATH-625-follow-up: session-aware emit helper. Worker threads call
    #
    #     session.emit(event_type='swarm_attempt', payload={...})
    #
    # without needing to capture session_id, sink, or run_subtype
    # themselves. Returns True on a successful (non-Noop) emit, False
    # when the sink is absent or a Noop. Exceptions are swallowed per
    # the TraceSink Protocol's non-raising contract.
    def emit(
        self,
        *,
        event_type: str,
        payload: Mapping[str, Any] | None = None,
        sequence: int | None = None,
        run_subtype: str | None = None,
    ) -> bool:
        """Emit a TraceEvent under this session's run_id.

        Convenience wrapper that fills run_id from ``self.session_id``,
        run_subtype from ``self._default_run_subtype`` (set by the
        :func:`kairos.session` context manager from its kwarg), and
        sequence from a thread-safe internal counter when the caller
        omits it. Worker threads can call this concurrently.

        Returns True when the event reached a real sink; False when
        the session has no sink (offline / NoopTraceSink path) so the
        caller can branch on it for fallback persistence if needed.
        """
        from kairos.trace import NoopTraceSink, TraceEvent

        sink = self._sink
        if sink is None or isinstance(sink, NoopTraceSink):
            return False

        # Sequence: caller-supplied wins; otherwise pull next from the
        # internal monotonic counter. itertools.count.__next__ is atomic
        # under the GIL so concurrent worker threads each get a unique
        # value with no explicit lock.
        seq = sequence if sequence is not None else next(self._sequence_counter)

        # run_subtype: caller-supplied wins (event-specific override);
        # otherwise fall back to the session's default (set from
        # kairos.session(..., run_subtype=...) on enter). None is fine
        # — the schema accepts NULL.
        rs = run_subtype if run_subtype is not None else self._default_run_subtype

        event = TraceEvent(
            run_id=self.session_id,
            event_type=event_type,
            sequence=seq,
            run_subtype=rs,
            payload=dict(payload) if payload else {},
        )
        try:
            sink.emit(event)
        except Exception:  # pragma: no cover — Protocol says non-raising
            import logging as _lg
            _lg.getLogger(__name__).exception(
                "session.emit: sink.emit raised — swallowed per Protocol"
            )
            return False
        return True

    @property
    def iteration_count(self) -> int:
        return len(self._iterations)

    @property
    def total_cost_usd(self) -> float:
        """Sum of cost_usd across every prove() call in this session."""
        return sum(r.cost_usd for r in self._iterations)

    @property
    def outcomes(self) -> list[str]:
        """Ordered list of outcomes across iterations — useful for
        'did we converge?' analysis."""
        return [r.outcome for r in self._iterations]

    def prove(
        self,
        hypothesis: str,
        *,
        vertical: str,
        target_file: str | Path,
        target_name: str | None = None,
        target_kind: str = "theorem",
        bound_k: int | None = None,
        witness: Mapping[str, Any] | None = None,
        cost_budget_usd: float | None = None,
    ) -> ProveResult:
        """Invoke :func:`prove` stamped with this session's id."""
        # Build a per-iteration run_id prefixed with session_id so
        # trace rows group cleanly in Supabase.
        iter_run_id = (
            f"{self.session_id}:iter-{self.iteration_count + 1}"
        )
        result = prove(
            hypothesis,
            vertical=vertical,
            target_file=target_file,
            target_name=target_name,
            target_kind=target_kind,
            bound_k=bound_k,
            witness=witness,
            cost_budget_usd=cost_budget_usd,
            config=self._config,
            run_id=iter_run_id,
            session_id=self.session_id,
        )
        self._iterations.append(result)
        return result

    def summary(self) -> dict[str, Any]:
        """Machine-readable summary of the session — for logging /
        dashboards. Not emitted to TraceSink unless the caller passes
        it into the next prove()'s witness."""
        return {
            "task_id": self.task_id,
            "session_id": self.session_id,
            "iteration_count": self.iteration_count,
            "total_cost_usd": self.total_cost_usd,
            "outcomes": self.outcomes,
            "converged_to_proved": any(
                r.outcome == "proved" for r in self._iterations
            ),
        }

    # ATH-626 sub-3: cross-agent handoff event helper.
    #
    #     orchestrator_agent.plan(task)
    #     session.emit_handoff(from_agent='orchestrator', to_agent='drafter',
    #                          payload={'plan': plan_summary})
    #     drafter_agent.draft(plan)
    #     session.emit_handoff(from_agent='drafter', to_agent='verifier',
    #                          payload={'candidate_first_300': candidate[:300]})
    #
    # Closes Aidan's "agent handoff" ask in ATH-626. Distinct event_type
    # so dashboards can filter / count cross-agent boundaries instead of
    # inferring them from event ordering.
    def emit_handoff(
        self,
        *,
        from_agent: str,
        to_agent: str,
        payload: Mapping[str, Any] | None = None,
        sequence: int | None = None,
        run_subtype: str | None = None,
    ) -> bool:
        """Emit an ``agent_handoff`` TraceEvent stamped with this
        session's run_id. Returns True on a successful (non-Noop)
        emit; False when the sink is absent.

        ``from_agent`` / ``to_agent`` are free-form strings — typical
        values: 'orchestrator', 'drafter', 'verifier', 'reviewer',
        'arbitrator'. Any extra context (plan summary, candidate
        snippet, verdict reason) goes in ``payload``.
        """
        merged: dict[str, Any] = {"from": from_agent, "to": to_agent}
        if payload:
            # Caller payload wins on collision EXCEPT for from/to which
            # are the canonical handoff fields — preserve them.
            for k, v in payload.items():
                if k not in ("from", "to"):
                    merged[k] = v
        return self.emit(
            event_type="agent_handoff",
            payload=merged,
            sequence=sequence,
            run_subtype=run_subtype,
        )


@contextmanager
def session(
    task_id: str,
    *,
    config: KairosConfig | None = None,
    trace_sink: Any = None,  # None = auto-detect (ATH-550); explicit NoopTraceSink() = opt-out
    events_path: str | Path | None = None,
    run_type: str = "sdk_orchestration",
    run_subtype: str = "autoformalize",
    vertical: str = "other",
    builder_model: str | None = None,
    name_for_display: str | None = None,
    workdir: str | Path | None = None,
    organization_id: str | None = None,
) -> Iterator[Session]:
    """Context manager grouping multiple prove() calls under one
    task_id / session_id.

    ATH-524: when ``trace_sink`` or ``events_path`` is passed, the session
    auto-wraps :func:`kairos.observe.observe` so ANY LLM call in the
    ``with`` block — litellm, native Anthropic SDK, or routed through the
    model_client — is traced under this session's ``session_id``. One
    stream, one stitch.

    ATH-544: when ``trace_sink`` is passed, the session ALSO opens a
    parent ``solve_runs`` row on enter and closes it on exit — so the
    platform dashboards at ``/solve-runs`` and ``/runs`` surface
    SDK-originated runs alongside the legacy solve pipeline.

    When neither ``trace_sink`` nor ``events_path`` is passed, the
    session behaves as it did pre-ATH-524: no LLM-call observation,
    no parent row, just prove()-level tracing via the plugin pipeline.
    Customers who don't want phone-home (the common case) pay nothing.

    Args:
        task_id: customer-facing label for the task.
        config: optional :class:`KairosConfig` override.
        trace_sink: optional :class:`kairos.trace.TraceSink` to receive
            per-LLM-call TraceEvents + parent-row open/close. When
            ``None``, auto-observation is off (prove() still runs normally).
        events_path: optional path to append a JSONL event line per LLM
            call (picks up by ``trace_uploader``). Passed through to
            :func:`kairos.observe.observe`.
        run_type / run_subtype: routed to the observe context so
            sdk_agent_events rows are tagged correctly.
        vertical: one of the ``solve_runs.vertical`` CHECK values
            (``neuron`` | ``bio`` | ``action_cred`` | ``sysverilog`` |
            ``auth`` | ``networking`` | ``distributed_systems`` |
            ``systems_migration`` | ``hardware`` | ``other``). Drives
            how the dashboard groups the run. Default ``other``.
        builder_model: optional LLM model id for the solve_runs row.
        name_for_display: optional human-readable label stuffed into
            ``solve_runs.target`` so the /solve-runs dashboard shows
            something skim-friendly instead of a UUID (ATH-572). When
            unset, the session_id is used (pre-ATH-572 behaviour).
            Platform's read-side synthesis (PR #253) fills the legacy
            rows; this kwarg fixes it at the write side so new rows
            don't need synthesis at all.
        organization_id: optional org UUID stamped on the parent
            ``solve_runs`` row (ATH-648). When omitted, the
            SupabaseTraceSink resolves via ``ATHANOR_ORG_ID`` env, then
            ``ATHANOR_SYNC_TOKEN`` lookup, then fail-loud raises. Pre-
            ATH-648 this column was never written and 132 internal-fleet
            rows accumulated as NULL.

    See :class:`Session` for usage.

    Tier classification: paid (requires the ``solve`` product).
    Raises :class:`kairos.license_scope.LicenseScopeError` on enter
    when ``~/.athanor/license.json`` is missing or its products
    don't include ``solve``. Free-tier callers grouping multiple
    free-tier calls should pair :func:`kairos.simple_prove` with
    :func:`kairos.observe` instead — observe() is the unified
    free wrapper that captures litellm + Anthropic native calls
    under one TraceSink.
    """
    import time as _time
    from kairos.trace import NoopTraceSink as _Noop

    # ATH-686 P1: paid-tier programmatic API → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    s = Session(task_id, config=config)
    session_started_at = _time.monotonic()
    # ATH-625-follow-up: stash sink + run_subtype on the Session so worker
    # threads can call session.emit(event_type=..., payload=...) without
    # capturing run_id / sink themselves. Set BEFORE auto-detect resolution
    # so even Noop fallback paths populate cleanly (emit() will then short-
    # circuit gracefully).
    with s._lock:
        s._sink = trace_sink
        s._default_run_subtype = run_subtype

    # ATH-550: when caller omits trace_sink, auto-detect from env.
    # The kwarg default is None; callers wanting cloud trace persistence
    # pass `trace_sink=default_sink_from_env()` explicitly.
    #
    # ATH-681 followup: even with no caller-supplied sink, session()
    # writes locally to ~/.athanor/runs/<session_id>/ via
    # LocalOutputTraceSink so free-tier customers get a copy of every
    # event + a manifest.json. Local writes are privacy-safe (no
    # phone-home) so the original "quiet by default" privacy guarantee
    # is preserved. Customers who want zero filesystem writes set
    # KAIROS_LOCAL_OUTPUT_DISABLE=1.
    #
    # When trace_sink IS supplied (e.g. SupabaseTraceSink for paid
    # cloud writes), session() composes a MultiSink that fans out to
    # BOTH the caller's sink AND LocalOutputTraceSink — that's the
    # §3.6 "local copy as backup" pattern for paid runs.
    import os as _os
    _local_output_disabled = _os.environ.get(
        "KAIROS_LOCAL_OUTPUT_DISABLE", ""
    ).strip().lower() in {"1", "true", "yes", "on"}
    # ATH-681 followup, qa #277 review: also auto-disable under pytest
    # so the SDK's own test suite doesn't pollute ~/.athanor/runs/. The
    # `PYTEST_CURRENT_TEST` env is set by pytest per-test. We honor it
    # UNLESS the test explicitly opts back in by setting
    # `KAIROS_LOCAL_OUTPUT_DIR` (the LocalOutputTraceSink test fixtures
    # set this to a tmpdir, signaling they actually want local writes
    # to land + verify).
    _under_pytest = (
        _os.environ.get("PYTEST_CURRENT_TEST", "") != ""
        and _os.environ.get("KAIROS_LOCAL_OUTPUT_DIR", "") == ""
    )
    if _local_output_disabled or _under_pytest:
        # Customer opted out via env, OR running under pytest without
        # an explicit local-output dir override. Honor the legacy
        # zero-filesystem behavior so existing test suites don't
        # break and CI runs don't pollute disk.
        resolved_sink = trace_sink
    else:
        from kairos.local_output import LocalOutputTraceSink as _LocalSink
        from kairos.trace import MultiSink as _MultiSink
        _local_sink = _LocalSink(run_id=s.session_id)
        if trace_sink is None or isinstance(trace_sink, _Noop):
            # No caller sink (or explicit Noop): local-only.
            resolved_sink = _local_sink
        else:
            # Caller supplied a sink (typically SupabaseTraceSink).
            # Tee both so paid runs get cloud + local backup.
            resolved_sink = _MultiSink([_local_sink, trace_sink])

    auto_observe = (resolved_sink is not None) or (events_path is not None)
    # Treat NoopTraceSink as "no sink" for observability gating — there's
    # no reason to install monkey-patches + open solve_runs rows when the
    # sink discards everything.
    sink_is_noop = isinstance(resolved_sink, _Noop)
    open_parent = resolved_sink is not None and not sink_is_noop

    # Open the solve_runs parent row BEFORE entering observe, so a sink
    # that raises on open_run doesn't leave the observe state half-set.
    # open_run is Protocol-level non-raising, so this is a belt-and-braces.
    _parent_row_opened = False
    if open_parent:
        # ATH-934: probe engine versions at session start so the
        # solve_runs row carries Lean / EBMC / ACL2 / Pythia / kairos
        # version strings. Pre-stages against ATH-933 (platform-side
        # schema migration adds the engine_versions jsonb column);
        # SupabaseTraceSink gates the actual POST behind
        # KAIROS_SOLVE_RUNS_ENGINE_VERSIONS=1 until the column lands.
        try:
            from kairos.trace import _probe_engine_versions
            _engine_versions = _probe_engine_versions()
        except Exception:  # noqa: BLE001 — engine probe must not crash session start
            _engine_versions = {}
        try:
            resolved_sink.open_run(
                s.session_id,
                vertical=vertical,
                builder_model=builder_model,
                # ATH-572: caller-supplied label wins so /solve-runs renders
                # a skim-friendly string; falls back to session_id otherwise.
                target=name_for_display or s.session_id,
                # ATH-648: kwarg → env → sync-token waterfall lives in the
                # sink. We pass through whatever the session() caller gave;
                # SupabaseTraceSink resolves None into the env/token lookup.
                organization_id=organization_id,
                engine_versions=_engine_versions,
            )
            _parent_row_opened = True
        except Exception:  # pragma: no cover — Protocol says non-raising
            import logging as _lg
            _lg.getLogger(__name__).exception(
                "session: trace_sink.open_run raised — continuing"
            )
        if _parent_row_opened:
            # ATH-587 slice A: emit a session_open child event right after
            # the parent row lands so the detail page has a boundary
            # marker with the full config snapshot. Gated on open_run
            # success so test-shim sinks that don't implement open_run
            # also skip the lifecycle emit (keeps them emitting only
            # what they explicitly asked for).
            _emit_session_lifecycle(
                sink=resolved_sink,
                session_id=s.session_id,
                event_type="session_open",
                run_type=run_type,
                run_subtype=run_subtype,
                payload={
                    "task_id": task_id,
                    "vertical": vertical,
                    "run_type": run_type,
                    "run_subtype": run_subtype,
                    "model": builder_model,
                    "session_id": s.session_id,
                },
            )

    def _close_parent_row(status: str) -> None:
        if not open_parent or not _parent_row_opened:
            return
        wall = _time.monotonic() - session_started_at
        # ATH-587 slice A: emit session_close BEFORE close_run so it
        # lands alongside the parent PATCH (close_run also runs the
        # reconciliation check from ATH-585 and prunes counters, so the
        # session_close event needs to be in-flight before then). Gated
        # on _parent_row_opened so test-shim sinks without open_run stay
        # quiet.
        _emit_session_lifecycle(
            sink=resolved_sink,
            session_id=s.session_id,
            event_type="session_close",
            run_type=run_type,
            run_subtype=run_subtype,
            payload={
                "task_id": task_id,
                "status": status,
                "prove_count": s.iteration_count,
                "wall_time_seconds": float(wall),
                "cost_usd": s.total_cost_usd,
                "elapsed_sec": float(wall),
                "session_id": s.session_id,
            },
        )
        try:
            resolved_sink.close_run(
                s.session_id,
                status=status,
                token_cost_usd=s.total_cost_usd,
                wall_time_seconds=wall,
            )
        except Exception:  # pragma: no cover — Protocol says non-raising
            import logging as _lg
            _lg.getLogger(__name__).exception(
                "session: trace_sink.close_run raised — swallowed"
            )

        # ATH-626 sub-4: upload workdir tarball to solve_artifacts so the
        # platform's /solve-runs/[id] detail page renders a download link.
        # Off when the caller didn't pass workdir=, or the sink doesn't
        # implement upload_workdir_tarball (e.g. NoopTraceSink, customer
        # BYO sinks). Non-raising — failure logs + drops the artifact,
        # never breaks the close-run path.
        if workdir is not None and hasattr(resolved_sink, "upload_workdir_tarball"):
            try:
                resolved_sink.upload_workdir_tarball(s.session_id, workdir)
            except Exception:  # pragma: no cover — Protocol non-raising
                import logging as _lg
                _lg.getLogger(__name__).exception(
                    "session: trace_sink.upload_workdir_tarball raised — swallowed"
                )

    # ATH-551: publish the session on the contextvar so nested
    # ATH-971 Phase 4: legacy ``kairos.trace.CURRENT_SESSION`` write
    # removed. The canonical ``with _observe(...)`` block below
    # populates ``kairos.observe._CURRENT_CONTEXT`` with the same
    # (session_id, task_id, sink, vertical) fields; downstream
    # detectors call ``kairos.observe.active_session_context()``.
    if auto_observe:
        # Lazy-import to avoid paying observe's import cost in the
        # common (no-sink) path -- keeps prove() startup fast.
        from kairos.observe import observe as _observe

        status_for_close = "succeeded"
        try:
            with _observe(
                run_id=s.session_id,
                session_id=s.session_id,
                sink=resolved_sink,
                events_path=events_path,
                run_type=run_type,  # type: ignore[arg-type]
                run_subtype=run_subtype,  # type: ignore[arg-type]
                task_id=task_id,
                vertical=vertical,
                # prove.session() already opened the parent row above
                # with richer data (organization_id, engine_versions,
                # builder_model, name_for_display target). Tell observe
                # to skip its own open/close so the sink sees exactly
                # one solve_runs row, not two.
                skip_parent_row=_parent_row_opened,
            ):
                try:
                    yield s
                except BaseException:
                    status_for_close = "failed"
                    raise
        finally:
            _close_parent_row(status_for_close)
    else:
        # ATH-971 Phase 4: even when auto_observe is off (no-sink
        # session), the canonical _CURRENT_CONTEXT must still be
        # populated so downstream detectors (
        # kairos.observe.active_session_context, the 5 Phase-3
        # readers) see the session. Pre-Phase-4 the legacy
        # CURRENT_SESSION dict carried this; we replace that single
        # source-of-truth with a lightweight _CURRENT_CONTEXT set/reset
        # that does NOT install the litellm wrapper (that side of
        # _observe() is what auto_observe is gating).
        from kairos.observe import _ObserveContext, _CURRENT_CONTEXT
        _ctx = _ObserveContext(
            run_id=s.session_id,
            session_id=s.session_id,
            sink=resolved_sink if resolved_sink is not None else _Noop(),
            events_path=None,
            run_type=run_type,  # type: ignore[arg-type]
            run_subtype=run_subtype,  # type: ignore[arg-type]
            task_id=task_id,
            vertical=vertical,
        )
        _ctx_token = _CURRENT_CONTEXT.set(_ctx)
        status_for_close = "succeeded"
        try:
            yield s
        except BaseException:
            status_for_close = "failed"
            raise
        finally:
            _CURRENT_CONTEXT.reset(_ctx_token)
            _close_parent_row(status_for_close)


# ═══════════════════════════════════════════════════════════════════════
# Internals
# ═══════════════════════════════════════════════════════════════════════


def _emit_session_lifecycle(
    *,
    sink: Any,
    session_id: str,
    event_type: str,
    run_type: str,
    run_subtype: str,
    payload: Mapping[str, Any],
) -> None:
    """ATH-587 slice A: emit a session_open / session_close child event
    via ``sink.emit``.

    Swallows any exception — ``sink`` is Protocol-non-raising per
    :mod:`kairos.trace`, but we add a belt-and-braces catch so a sink
    bug can't abort the session body. The sequence field is a UUID-
    derived hash of the session_id + event_type so it sorts stably
    alongside other per-session events (dashboard displays).
    """
    try:
        from kairos.trace import TraceEvent

        sink.emit(
            TraceEvent(
                run_id=session_id,
                run_type=run_type,  # type: ignore[arg-type]
                run_subtype=run_subtype,  # type: ignore[arg-type]
                event_type=event_type,
                sequence=0 if event_type == "session_open" else 999999,
                payload=dict(payload),
            )
        )
    except Exception:  # pragma: no cover — sink Protocol says non-raising
        import logging as _lg

        _lg.getLogger(__name__).exception(
            "session: %s lifecycle emit raised — swallowed", event_type,
        )


def _result_from_run(
    run: RunResult, *, session_id: str | None, run_id: str,
) -> ProveResult:
    """Flatten a SpecPipeline RunResult to a ProveResult."""
    # Pick the first non-error tier as the "headline" verdict, else
    # fall back to the first tier (which may be error).
    tier, verdict = _pick_headline_verdict(run.verdicts_by_tier)
    return ProveResult(
        outcome=verdict.outcome if verdict else "error",
        reason=verdict.reason if verdict else (
            "no tier dispatched — check SpecPipeline orchestrator + "
            "registered plugins"
        ),
        score=run.score,
        cost_usd=run.cost_usd,
        tier=tier or "unknown",
        details=dict(verdict.details) if verdict and verdict.details else {},
        run_id=run_id,
        session_id=session_id,
        escalations=[
            {"trigger": e.trigger, "context": dict(e.context)}
            for e in run.escalations
        ],
        run_result=run,
    )


def _pick_headline_verdict(
    verdicts_by_tier: dict[str, Verdict],
) -> tuple[str | None, Verdict | None]:
    """Choose which tier's Verdict represents the overall prove() answer.

    Priority:
      1. Any tier with outcome='proved' — proof closed.
      2. Any tier with outcome='refuted' — CEX found.
      3. Any tier with outcome='unknown' — partial / bounded.
      4. Any tier with outcome='error' — plugin failed.
      5. None — no tier dispatched.

    Within each priority band the first tier encountered wins.
    """
    priority = ("proved", "refuted", "unknown", "error")
    for target_outcome in priority:
        for tier, verdict in verdicts_by_tier.items():
            if verdict.outcome == target_outcome:
                return tier, verdict
    # No verdicts at all.
    return None, None
