"""kairos.stim_gen — driver/stimulus generator for SEC closed-loop verification.

Per the ATH-1005-1008 PPA optimization-loop addition (Todd's 2026-05-05
spec) + asabi's 2026-05-05 lock-in on ATH-1006: the v0/v1 stim_gen is a
*4-template-only* generator. Given a target RTL block's port list, it
classifies the block under one of four well-known interface idioms +
emits a deterministic stimulus driver:

* :class:`InterfaceTemplate.FIFO` — push/pop/full/empty/data-in/data-out
* :class:`InterfaceTemplate.ARBITER` — N source request lines + grant out
* :class:`InterfaceTemplate.REGFILE` — read/write address + data bus
* :class:`InterfaceTemplate.HANDSHAKE` — valid/ready pair on each direction

Ambiguous-port classifications raise :class:`AmbiguousPortClassification`.
*The v0/v1 stim_gen does NOT fall through to LLM-judgment-on-ambiguous-
ports* per Todd's 2026-05-05 directive: "don't build the LLM-judgment-
fallback yet — too much hallucination risk on ambiguous ports."

This package ships:

* :func:`classify_ports` — port-list -> :class:`InterfaceTemplate` |
  raise :class:`AmbiguousPortClassification`.
* :func:`generate_stim` — :class:`InterfaceTemplate` + port list ->
  SystemVerilog driver source as a string.

Cross-refs
----------

* :issue:`ATH-988` — parent epic, Annapurna PPA optimization-loop.
* :issue:`ATH-1006` — this child (stim_gen, K).
* Todd 2026-05-05 spec lock-in (asabi relay): 4-template-only,
  no LLM-judgment-fallback, raise structured error on ambiguous ports.
* :mod:`kairos.verilator` — sibling consumer (J, ATH-1005); the
  generated stim drives verilator runs.
* :mod:`kairos.sec.closed_loop._orchestrator` — orchestrator
  consumer that wires stim_gen into the propose-verify-adjust
  loop's verilator pass.
"""
from __future__ import annotations

from kairos.stim_gen._classifier import (
    AmbiguousPortClassification,
    InterfaceTemplate,
    PortClassification,
    classify_ports,
)
from kairos.stim_gen._generator import (
    StimulusDriver,
    generate_stim,
)
from kairos.stim_gen._port_signature import PortDirection, PortSignature

__all__ = [
    "AmbiguousPortClassification",
    "InterfaceTemplate",
    "PortClassification",
    "PortDirection",
    "PortSignature",
    "StimulusDriver",
    "classify_ports",
    "generate_stim",
]
