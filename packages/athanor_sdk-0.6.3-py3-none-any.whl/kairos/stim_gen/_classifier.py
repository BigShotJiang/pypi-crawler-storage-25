"""4-template port classifier (ATH-1006 v0/v1 lock-in).

Per Todd's 2026-05-05 spec lock-in (asabi relay 2026-05-05):
*4-template-only*, NO LLM-judgment-fallback. Ambiguous-port lists
raise :class:`AmbiguousPortClassification` rather than
hallucinating an interface assignment.

The four templates:

* :attr:`InterfaceTemplate.FIFO`     — push, pop, full, empty,
  push_data, pop_data
* :attr:`InterfaceTemplate.ARBITER`  — N source request lines +
  grant output (binary or one-hot)
* :attr:`InterfaceTemplate.REGFILE`  — read/write address + data
  bus + write enable
* :attr:`InterfaceTemplate.HANDSHAKE` — valid/ready pair on each
  data direction
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Sequence

from kairos.stim_gen._port_signature import (
    PortDirection,
    PortSignature,
    signature_summary,
)


class InterfaceTemplate(str, Enum):
    FIFO = "fifo"
    ARBITER = "arbiter"
    REGFILE = "regfile"
    HANDSHAKE = "handshake"


@dataclass(frozen=True)
class PortClassification:
    """Result of a successful classify_ports call.

    Attributes
    ----------
    template:
        Which :class:`InterfaceTemplate` the port list matched.
    role_assignments:
        Mapping from template-role-name (e.g. ``"push"``,
        ``"pop_data"``, ``"req_lines"``) to the actual
        :class:`PortSignature` filling that role. Used by
        :func:`generate_stim` to bind the template to the
        concrete port names.
    """

    template: InterfaceTemplate
    role_assignments: dict[str, PortSignature]


class AmbiguousPortClassification(ValueError):
    """Raised when the 4-template classifier cannot uniquely fit the port
    list to exactly one of FIFO / ARBITER / REGFILE / HANDSHAKE.

    Per Todd's 2026-05-05 spec: do NOT fall through to LLM-judgment;
    surface the ambiguity to the caller as a structured error so the
    caller can either (a) supply a manual classification, (b) skip
    the block in the loop with a documented reason, or (c) wait for
    a future v2 that adds either an LLM-judgment-with-confidence
    fallback or additional templates.

    Attributes
    ----------
    candidates:
        Templates that partially matched. Empty if no template
        matched at all.
    reason:
        Human-readable explanation of why the classifier could not
        uniquely fit. Surfaced in customer-facing error messages
        + the orchestrator's halt-reason context.
    port_summary:
        Compact summary of the port list for diagnostic context.
    """

    candidates: tuple[InterfaceTemplate, ...]
    reason: str
    port_summary: str

    def __init__(
        self,
        candidates: Sequence[InterfaceTemplate],
        reason: str,
        port_summary: str,
    ) -> None:
        self.candidates = tuple(candidates)
        self.reason = reason
        self.port_summary = port_summary
        super().__init__(
            f"Ambiguous port classification: {reason}. "
            f"Candidates: {[c.value for c in candidates]}. "
            f"Ports: {port_summary}"
        )


_FIFO_PATTERNS = {
    "push": re.compile(r"^(push|wr_en|write|enq|put)$", re.IGNORECASE),
    "pop": re.compile(r"^(pop|rd_en|read|deq|get)$", re.IGNORECASE),
    "full": re.compile(r"^(full|wr_full|fifo_full)$", re.IGNORECASE),
    "empty": re.compile(r"^(empty|rd_empty|fifo_empty)$", re.IGNORECASE),
    "push_data": re.compile(
        r"^(push_data|wr_data|write_data|data_in|din|enq_data)$",
        re.IGNORECASE,
    ),
    "pop_data": re.compile(
        r"^(pop_data|rd_data|read_data|data_out|dout|deq_data)$",
        re.IGNORECASE,
    ),
}

_ARBITER_PATTERNS = {
    "req": re.compile(r"^(req|request|req_\d+)(_\d+)?$", re.IGNORECASE),
    "grant": re.compile(r"^(grant|gnt|grant_\d+)$", re.IGNORECASE),
}

_REGFILE_PATTERNS = {
    "wr_addr": re.compile(r"^(wr_addr|write_addr|waddr)$", re.IGNORECASE),
    "rd_addr": re.compile(r"^(rd_addr|read_addr|raddr)$", re.IGNORECASE),
    "wr_data": re.compile(r"^(wr_data|write_data|wdata)$", re.IGNORECASE),
    "rd_data": re.compile(r"^(rd_data|read_data|rdata)$", re.IGNORECASE),
    "wr_en": re.compile(r"^(wr_en|write_en|we|wen)$", re.IGNORECASE),
}

_HANDSHAKE_PATTERNS = {
    "valid_in": re.compile(r"^(.*_)?(valid_in|in_valid|s_valid)$", re.IGNORECASE),
    "ready_in": re.compile(r"^(.*_)?(ready_in|in_ready|s_ready)$", re.IGNORECASE),
    "valid_out": re.compile(r"^(.*_)?(valid_out|out_valid|m_valid)$", re.IGNORECASE),
    "ready_out": re.compile(r"^(.*_)?(ready_out|out_ready|m_ready)$", re.IGNORECASE),
}


def _match_fifo(ports: Sequence[PortSignature]) -> dict[str, PortSignature] | None:
    matched: dict[str, PortSignature] = {}
    for role, pat in _FIFO_PATTERNS.items():
        for p in ports:
            if p.is_clock or p.is_reset:
                continue
            if pat.match(p.name):
                matched[role] = p
                break
    required = {"push", "pop", "full", "empty", "push_data", "pop_data"}
    if required.issubset(matched.keys()):
        return matched
    return None


def _match_arbiter(
    ports: Sequence[PortSignature],
) -> dict[str, PortSignature] | None:
    req_ports = [
        p
        for p in ports
        if not p.is_clock
        and not p.is_reset
        and _ARBITER_PATTERNS["req"].match(p.name)
        and p.direction == PortDirection.INPUT
    ]
    grant_ports = [
        p
        for p in ports
        if not p.is_clock
        and not p.is_reset
        and _ARBITER_PATTERNS["grant"].match(p.name)
        and p.direction == PortDirection.OUTPUT
    ]
    if not req_ports or not grant_ports:
        return None
    matched: dict[str, PortSignature] = {}
    for i, p in enumerate(req_ports):
        matched[f"req_{i}"] = p
    for i, p in enumerate(grant_ports):
        matched[f"grant_{i}"] = p
    return matched


def _match_regfile(
    ports: Sequence[PortSignature],
) -> dict[str, PortSignature] | None:
    matched: dict[str, PortSignature] = {}
    for role, pat in _REGFILE_PATTERNS.items():
        for p in ports:
            if p.is_clock or p.is_reset:
                continue
            if pat.match(p.name):
                matched[role] = p
                break
    required = {"wr_addr", "rd_addr", "wr_data", "rd_data", "wr_en"}
    if required.issubset(matched.keys()):
        return matched
    return None


# Distinctive non-handshake-canonical signals. If any of these appear in
# the port list, HANDSHAKE does NOT match — those signals indicate the
# block's interface is FIFO/ARBITER/REGFILE-shaped, with valid/ready
# ports in service of that interface rather than a pure handshake.
# Per asabi 2026-05-05 tightening on the v0 classifier patterns:
# default-deny shape, false-positive worse than false-negative per the
# meta-rule (silent-misclassify violates customer trust; structured
# AmbiguousPortClassification error is cheap for the customer to resolve).
_NON_HANDSHAKE_DISTINCTIVE = (
    re.compile(r"^(full|empty|wr_full|fifo_full|rd_empty|fifo_empty)$", re.IGNORECASE),
    re.compile(r"^(push|pop|enq|deq|wr_en|rd_en|we|wen)$", re.IGNORECASE),
    re.compile(r"^(req|grant|gnt|request)(_\d+)?$", re.IGNORECASE),
    re.compile(r"^(wr_addr|rd_addr|waddr|raddr|write_addr|read_addr)$", re.IGNORECASE),
)


def _has_non_handshake_distinctive_signal(
    ports: Sequence[PortSignature],
) -> bool:
    for p in ports:
        if p.is_clock or p.is_reset:
            continue
        for excl in _NON_HANDSHAKE_DISTINCTIVE:
            if excl.match(p.name):
                return True
    return False


def _match_handshake(
    ports: Sequence[PortSignature],
) -> dict[str, PortSignature] | None:
    if _has_non_handshake_distinctive_signal(ports):
        return None

    matched: dict[str, PortSignature] = {}
    for role, pat in _HANDSHAKE_PATTERNS.items():
        for p in ports:
            if p.is_clock or p.is_reset:
                continue
            if pat.match(p.name):
                matched[role] = p
                break
    if not matched:
        return None
    has_in = "valid_in" in matched and "ready_in" in matched
    has_out = "valid_out" in matched and "ready_out" in matched
    if has_in or has_out:
        return matched
    return None


def classify_ports(ports: Sequence[PortSignature]) -> PortClassification:
    """Classify the port list under exactly one of the four v0/v1 templates.

    Returns :class:`PortClassification` on success.

    Raises :class:`AmbiguousPortClassification` when:

    * No template matches (no candidates).
    * More than one template matches (the port list is fluent
      enough in multiple idioms that the classifier can't pick
      without LLM-judgment).

    Per Todd's 2026-05-05 spec lock-in: NO LLM-judgment-fallback
    in v0/v1; surface the ambiguity as a structured error.
    """
    candidates: list[tuple[InterfaceTemplate, dict[str, PortSignature]]] = []

    fifo = _match_fifo(ports)
    if fifo is not None:
        candidates.append((InterfaceTemplate.FIFO, fifo))

    arbiter = _match_arbiter(ports)
    if arbiter is not None:
        candidates.append((InterfaceTemplate.ARBITER, arbiter))

    regfile = _match_regfile(ports)
    if regfile is not None:
        candidates.append((InterfaceTemplate.REGFILE, regfile))

    handshake = _match_handshake(ports)
    if handshake is not None:
        candidates.append((InterfaceTemplate.HANDSHAKE, handshake))

    summary = signature_summary(ports)

    if len(candidates) == 0:
        raise AmbiguousPortClassification(
            candidates=[],
            reason=(
                "No 4-template idiom matched. Port names did not fit "
                "FIFO (push/pop/full/empty/push_data/pop_data), ARBITER "
                "(req/grant), REGFILE (rd/wr_addr/data/en), or HANDSHAKE "
                "(valid/ready pair). Manual classification or block skip "
                "required."
            ),
            port_summary=summary,
        )
    if len(candidates) > 1:
        raise AmbiguousPortClassification(
            candidates=[c[0] for c in candidates],
            reason=(
                "Port list fluent in multiple template idioms; the "
                "classifier cannot pick without LLM-judgment, which "
                "v0/v1 deliberately disallows per Todd 2026-05-05 spec. "
                "Manual classification required."
            ),
            port_summary=summary,
        )

    template, role_assignments = candidates[0]
    return PortClassification(
        template=template,
        role_assignments=role_assignments,
    )
