"""Port signature shape for stim_gen classification + generation."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence


class PortDirection(str, Enum):
    INPUT = "input"
    OUTPUT = "output"
    INOUT = "inout"


@dataclass(frozen=True)
class PortSignature:
    """One port on the RTL module under test.

    Attributes
    ----------
    name:
        Port identifier exactly as it appears in the SV/Verilog
        source. Case-sensitive; we don't normalize.
    direction:
        :class:`PortDirection`.
    width:
        Bit width. ``1`` for scalar; >1 for buses.
    is_clock:
        Hint flag for the classifier: ports named ``clk``,
        ``clock``, ``c_clk`` etc. are flagged separately so the
        classifier doesn't try to fit them into one of the four
        templates. The caller populates this; default False.
    is_reset:
        Hint flag for reset ports (``rst``, ``rst_n``, ``reset``).
        Same role as ``is_clock``.
    """

    name: str
    direction: PortDirection
    width: int
    is_clock: bool = False
    is_reset: bool = False


def signature_summary(ports: Sequence[PortSignature]) -> str:
    """Compact one-line summary of a port list, for error messages
    + customer-facing report context."""
    parts: list[str] = []
    for p in ports:
        tag = ""
        if p.is_clock:
            tag = " [clk]"
        elif p.is_reset:
            tag = " [rst]"
        parts.append(f"{p.direction.value} {p.name}[{p.width}]{tag}")
    return ", ".join(parts)
