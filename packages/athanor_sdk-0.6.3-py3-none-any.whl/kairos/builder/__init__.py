"""kairos.builder — vendored builder-core utilities for the SDK.

This sub-package is the first slice of ATH-# "fold solve/shared into SDK".
Only the pure, IP-safe utility pieces land here initially:

    CostTracker            — stateful token/USD accumulator (I1-I5 invariants)
    redact_for_customer    — deterministic system-prompt stripper for bundles

Follow-up PRs will add mode_fleet, phase_runner, ebmc_wrapper, etc.
These sit in ``src/kairos/builder/`` so that:

  * they can be Cython-shimmed behind .so (same pattern as lint/scoring)
  * customers running ``pip install athanor-kairos`` get them first-party
    instead of needing an out-of-tree ``mode_fleet`` binary
  * the public API surface is ``from kairos.builder import ...``
"""
from __future__ import annotations

from kairos.builder.cost_tracker import CostTracker
from kairos.builder.redactor import REDACTED_MARKER, redact_for_customer

__all__ = ["CostTracker", "REDACTED_MARKER", "redact_for_customer"]
