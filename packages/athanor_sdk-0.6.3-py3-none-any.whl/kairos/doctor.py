"""kairos.doctor — one-shot environment validation (ATH-844).

Aidan 2026-04-28 customer-UX dogfood pass: top friction-per-line ask was
``kairos doctor``, a CLI that validates everything a customer needs
before firing a sweep:

* kairos version + python version
* license file present + product list
* lake binary on PATH + version
* Supabase trace sink reachable (env vars + 1s HEAD)
* Per provider: env var present + (default-on) live 1-token ping
* Optional: ``--check-vllm`` (verify vllm import + GPU + model path)
* Optional: ``--check-aristotle`` (verify CLI + key)

Today's calibration sweep had 4+ silent-fail modes that this catches in
30s: gemini-3-flash typo, missing license bypass env, missing supabase
env, lake-on-PATH drift.

Customer-trust framing per @asabi: this is the SDK-level surface of the
``feedback_fleet_preflight_always.md`` rule — the SDK boundary's own
preflight, not just the run-script wrapper. Catches typos before the
sweep eats wall time + cloud spend.

Exit codes:

* ``0`` — all checks passed (skipped checks are OK in default mode)
* ``1`` — any check FAILed
* ``2`` — strict mode + any check SKIPPED

Output formats:

* default (table) — pretty terminal output with ✓ / ✗ / ─ markers
* ``--json`` — JSON-Lines per check, suitable for CI / automation
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Optional, TypedDict

# Status sentinels — use literals not enum to keep Python 3.9-ish compat
# the rest of kairos targets.
STATUS_PASS = "pass"
STATUS_FAIL = "fail"
STATUS_SKIP = "skip"
_GLYPH = {STATUS_PASS: "✓", STATUS_FAIL: "✗", STATUS_SKIP: "─"}


@dataclass
class CheckResult:
    """Outcome of a single doctor check."""
    name: str
    status: str  # pass | fail | skip
    detail: str = ""
    elapsed_sec: float = 0.0
    fix_hint: str = ""

    def is_pass(self) -> bool:
        return self.status == STATUS_PASS

    def is_fail(self) -> bool:
        return self.status == STATUS_FAIL

    def is_skip(self) -> bool:
        return self.status == STATUS_SKIP


def _check_kairos_version() -> CheckResult:
    """Sanity: kairos package is importable + has a __version__."""
    t0 = time.time()
    try:
        import kairos
        ver = getattr(kairos, "__version__", None)
        if ver is None:
            # Fall back to distribution metadata.
            try:
                from importlib.metadata import version as _ver
                ver = _ver("athanor-sdk")
            except Exception:  # noqa: BLE001 — broad-catch fallback
                ver = "unknown"
        return CheckResult(
            name="kairos version",
            status=STATUS_PASS,
            detail=ver,
            elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="kairos version",
            status=STATUS_FAIL,
            detail=f"{type(e).__name__}: {e}",
            elapsed_sec=time.time() - t0,
            fix_hint="re-install: `pip install athanor-sdk`",
        )


def _check_python_version(min_major: int = 3, min_minor: int = 9) -> CheckResult:
    t0 = time.time()
    cur = sys.version_info
    ver = f"{cur.major}.{cur.minor}.{cur.micro}"
    if (cur.major, cur.minor) >= (min_major, min_minor):
        return CheckResult(
            name="python version",
            status=STATUS_PASS,
            detail=ver,
            elapsed_sec=time.time() - t0,
        )
    return CheckResult(
        name="python version",
        status=STATUS_FAIL,
        detail=f"{ver} (need >= {min_major}.{min_minor})",
        elapsed_sec=time.time() - t0,
        fix_hint=f"upgrade to Python {min_major}.{min_minor}+",
    )


def _check_license() -> CheckResult:
    """License file present + product list. Honors KAIROS_DEV_NO_LICENSE."""
    t0 = time.time()
    if os.environ.get("KAIROS_DEV_NO_LICENSE"):
        return CheckResult(
            name="license",
            status=STATUS_PASS,
            detail="dev bypass (KAIROS_DEV_NO_LICENSE=1)",
            elapsed_sec=time.time() - t0,
        )
    try:
        from kairos.license_scope import load_license, LicenseScopeError
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="license",
            status=STATUS_FAIL,
            detail=f"kairos.license_scope import failed: {type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
            fix_hint="re-install kairos",
        )
    try:
        lic = load_license()
    except LicenseScopeError:
        # No license file is a valid free-tier state — SKIP, not FAIL.
        return CheckResult(
            name="license",
            status=STATUS_SKIP,
            detail="no license file (free tier)",
            elapsed_sec=time.time() - t0,
            fix_hint="paid features need ~/.athanor/license.json. Free tier OK.",
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="license",
            status=STATUS_FAIL,
            detail=f"{type(e).__name__}: {str(e)[:120]}",
            elapsed_sec=time.time() - t0,
            fix_hint="see kairos.license_scope docs",
        )
    if lic is None:
        return CheckResult(
            name="license",
            status=STATUS_SKIP,
            detail="no license file (free tier)",
            elapsed_sec=time.time() - t0,
            fix_hint="paid features need ~/.athanor/license.json. Free tier OK.",
        )
    products = lic.products if hasattr(lic, "products") else lic.get("products", [])
    prod_str = ", ".join(products) if products else "no products"
    return CheckResult(
        name="license",
        status=STATUS_PASS,
        detail=f"paid ({prod_str})",
        elapsed_sec=time.time() - t0,
    )


def _check_lake_binary() -> CheckResult:
    """`lake` on PATH + reports a Lean toolchain version."""
    t0 = time.time()
    lake = shutil.which("lake")
    if not lake:
        return CheckResult(
            name="lake binary",
            status=STATUS_SKIP,
            detail="not found on PATH (optional — needed for Lean proofs, not RTL optimization)",
            elapsed_sec=time.time() - t0,
            fix_hint="install elan: https://leanprover.github.io/installation/",
        )
    try:
        res = subprocess.run(
            [lake, "--version"],
            capture_output=True, text=True, timeout=5,
        )
        ver = (res.stdout or res.stderr).strip().splitlines()[0][:80]
        return CheckResult(
            name="lake binary",
            status=STATUS_PASS,
            detail=f"{lake} ({ver})",
            elapsed_sec=time.time() - t0,
        )
    except subprocess.TimeoutExpired:
        return CheckResult(
            name="lake binary",
            status=STATUS_FAIL,
            detail=f"{lake} hung on --version (timeout 5s)",
            elapsed_sec=time.time() - t0,
            fix_hint="try `lake clean` or reinstall elan",
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="lake binary",
            status=STATUS_FAIL,
            detail=f"{type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
        )


def _check_run_history() -> CheckResult:
    """ATH-1201: report Postgres run-history persistence status.

    Three reporting modes:
    - PASS: db_url persisted, file perms OK; show redacted url + engine
            label (config-read-only — no live psycopg2 call here;
            rerun `kairos config db <conn>` to re-verify against AWS).
    - SKIP: no db_url configured (local SQLite fallback at
            ~/.athanor/runs.sqlite).
    - FAIL: db_url persisted but config file has loose perms.
    """
    t0 = time.time()
    try:
        from kairos.config import (
            db_url_redacted,
            file_permissions_ok,
        )
    except ImportError:
        return CheckResult(
            name="run history",
            status=STATUS_SKIP,
            detail="kairos.config unavailable",
            elapsed_sec=time.time() - t0,
        )

    redacted = db_url_redacted()
    if redacted is None:
        return CheckResult(
            name="run history",
            status=STATUS_SKIP,
            detail="not configured (local SQLite fallback at ~/.athanor/runs.sqlite)",
            elapsed_sec=time.time() - t0,
            fix_hint="Run: kairos config db <postgres-conn-string>",
        )

    if not file_permissions_ok():
        return CheckResult(
            name="run history",
            status=STATUS_FAIL,
            detail=(
                f"configured ({redacted}) but ~/.athanor/config.json has "
                "loose permissions"
            ),
            elapsed_sec=time.time() - t0,
            fix_hint="chmod 600 ~/.athanor/config.json",
        )

    return CheckResult(
        name="run history",
        status=STATUS_PASS,
        detail=(
            f"configured ({redacted}) — run `kairos config db <conn>` "
            "to re-verify with psycopg2"
        ),
        elapsed_sec=time.time() - t0,
    )


def _check_s3_trace_sink() -> CheckResult:
    """ATH-1200: report S3 trace-upload status.

    Three reporting modes:
    - PASS: bucket persisted in ~/.athanor/config.json, perms OK; report
            bucket + region (does NOT make a live S3 call — that's
            verify-time cost, not doctor-time cost).
    - SKIP: no bucket configured (traces stay local).
    - FAIL: bucket configured but config file has loose permissions.
    """
    t0 = time.time()
    try:
        from kairos.config import get_s3_trace_bucket, file_permissions_ok
    except ImportError:
        return CheckResult(
            name="s3 trace sink",
            status=STATUS_SKIP,
            detail="kairos.config unavailable",
            elapsed_sec=time.time() - t0,
        )

    cfg_s3 = get_s3_trace_bucket()
    if cfg_s3 is None:
        return CheckResult(
            name="s3 trace sink",
            status=STATUS_SKIP,
            detail="not configured (traces stored locally only)",
            elapsed_sec=time.time() - t0,
            fix_hint="Run: kairos config s3 <bucket> [--region <region>]",
        )

    if not file_permissions_ok():
        return CheckResult(
            name="s3 trace sink",
            status=STATUS_FAIL,
            detail=(
                f"configured (s3://{cfg_s3['bucket']}, "
                f"region={cfg_s3.get('region') or 'default'}) but "
                "~/.athanor/config.json has loose permissions"
            ),
            elapsed_sec=time.time() - t0,
            fix_hint="chmod 600 ~/.athanor/config.json",
        )

    region_label = cfg_s3.get("region") or "default"
    return CheckResult(
        name="s3 trace sink",
        status=STATUS_PASS,
        detail=(
            f"configured (s3://{cfg_s3['bucket']}, region={region_label}) — "
            "run `kairos config s3 {bucket}` to re-verify with boto3"
        ).format(bucket=cfg_s3['bucket']),
        elapsed_sec=time.time() - t0,
    )


def _check_supabase_trace_sink() -> CheckResult:
    """Supabase trace sink reachable (env vars + 1s HEAD probe).

    ATH-1048 Gap F: ATHANOR_SYNC_TOKEN is auth-equivalent to
    SUPABASE_SERVICE_ROLE_KEY per the SDK→DB contract gate
    (kairos.trace.default_sink_from_env line 975-981). Either
    satisfies the auth check; pre-fix this only read
    SUPABASE_SERVICE_ROLE_KEY so a customer with only
    ATHANOR_SYNC_TOKEN saw STATUS_SKIP "missing env vars" even
    though the run WOULD route to Supabase correctly.
    """
    t0 = time.time()
    url = os.environ.get("SUPABASE_URL") or os.environ.get("NEXT_PUBLIC_SUPABASE_URL")
    key = (
        os.environ.get("ATHANOR_SYNC_TOKEN")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    )
    if not url or not key:
        missing = []
        if not url: missing.append("SUPABASE_URL (or NEXT_PUBLIC_SUPABASE_URL)")
        if not key: missing.append("ATHANOR_SYNC_TOKEN (or SUPABASE_SERVICE_ROLE_KEY)")
        return CheckResult(
            name="supabase trace sink",
            status=STATUS_SKIP,
            detail=f"missing env vars: {', '.join(missing)}",
            elapsed_sec=time.time() - t0,
            fix_hint=(
                "export SUPABASE_URL + (ATHANOR_SYNC_TOKEN OR "
                "SUPABASE_SERVICE_ROLE_KEY) OR run offline"
            ),
        )
    # Resolvability check — DNS + TCP only, NOT a full auth round-trip.
    # Supabase REST endpoints return 401 on unauthenticated HEAD even
    # when the URL is correct + reachable, so we treat 401 as "host is
    # up". Only pure network failures (DNS, connection refused, TLS
    # handshake errors) flag as FAIL.
    try:
        import urllib.request
        import urllib.error
        req = urllib.request.Request(url.rstrip("/") + "/rest/v1/", method="HEAD")
        try:
            urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError:
            # Got an HTTP response code — host is up. Auth-required is fine.
            pass
        return CheckResult(
            name="supabase trace sink",
            status=STATUS_PASS,
            detail=url,
            elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="supabase trace sink",
            status=STATUS_FAIL,
            detail=f"{url} unreachable: {type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
            fix_hint="check SUPABASE_URL value + network reachability",
        )


def _check_provider_env(env_var: str, ping_model: Optional[str] = None,
                       *, live_ping: bool = True, ping_timeout: int = 10) -> CheckResult:
    """Generic per-provider env+ping check.

    Args:
        env_var: env var name (e.g. ANTHROPIC_API_KEY).
        ping_model: kairos model_id to live-ping (e.g. ``"anthropic/claude-sonnet-4-6"``).
            None to skip the live ping (env-presence check only).
        live_ping: if True AND ping_model provided AND env var set → make
            a 1-token call. Catches typoed model names + auth issues.
        ping_timeout: per-call timeout for the live ping.
    """
    t0 = time.time()
    if not os.environ.get(env_var):
        return CheckResult(
            name=env_var,
            status=STATUS_SKIP,
            detail="not set",
            elapsed_sec=time.time() - t0,
            fix_hint=f"export {env_var}=... to enable this provider",
        )
    if not (live_ping and ping_model):
        return CheckResult(
            name=env_var,
            status=STATUS_PASS,
            detail="set (no live ping)",
            elapsed_sec=time.time() - t0,
        )
    # Live ping via kairos.preflight_fleet which already does the right
    # 1-token call shape with retries on transient errors.
    try:
        from kairos.preflight_fleet import ping_model as _ping
        ok, msg = _ping(ping_model, timeout=ping_timeout, retries=1)
        if ok:
            return CheckResult(
                name=env_var,
                status=STATUS_PASS,
                detail=f"set + {ping_model} resolves",
                elapsed_sec=time.time() - t0,
            )
        return CheckResult(
            name=env_var,
            status=STATUS_FAIL,
            detail=f"{ping_model} failed: {msg[:120]}",
            elapsed_sec=time.time() - t0,
            fix_hint=(
                f"check the model name in kairos.model_presets matches the "
                f"provider's current catalog. Renamed/removed?"
            ),
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name=env_var,
            status=STATUS_FAIL,
            detail=f"ping raised {type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
        )


def _check_vllm() -> CheckResult:
    """vllm install + GPU presence (opt-in via --check-vllm)."""
    t0 = time.time()
    try:
        import vllm  # noqa: F401 — presence check only
    except ImportError as e:
        return CheckResult(
            name="vllm",
            status=STATUS_FAIL,
            detail=f"not installed: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
            fix_hint="`pip install athanor-sdk[vllm]` (requires CUDA + matching torch wheel)",
        )
    # Check for at least one CUDA GPU via nvidia-smi.
    nvidia_smi = shutil.which("nvidia-smi")
    if not nvidia_smi:
        return CheckResult(
            name="vllm",
            status=STATUS_FAIL,
            detail="vllm installed but nvidia-smi not found — no GPU?",
            elapsed_sec=time.time() - t0,
            fix_hint="vllm requires a CUDA GPU. Use ModelClientDrafter for cloud models.",
        )
    try:
        res = subprocess.run(
            [nvidia_smi, "--query-gpu=name,memory.total", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=3,
        )
        if res.returncode != 0:
            return CheckResult(
                name="vllm",
                status=STATUS_FAIL,
                detail=f"nvidia-smi rc={res.returncode}",
                elapsed_sec=time.time() - t0,
            )
        gpu_line = (res.stdout or "").strip().splitlines()[0] if res.stdout else "unknown"
        return CheckResult(
            name="vllm",
            status=STATUS_PASS,
            detail=f"installed + GPU: {gpu_line}",
            elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name="vllm",
            status=STATUS_FAIL,
            detail=f"GPU probe raised {type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
        )


def _check_aristotle() -> CheckResult:
    """Aristotle CLI + API key (opt-in via --check-aristotle)."""
    t0 = time.time()
    if not os.environ.get("ARISTOTLE_API_KEY"):
        return CheckResult(
            name="aristotle",
            status=STATUS_SKIP,
            detail="ARISTOTLE_API_KEY not set",
            elapsed_sec=time.time() - t0,
            fix_hint="export ARISTOTLE_API_KEY for harmonic.fun access",
        )
    aristotle = shutil.which("aristotle")
    if not aristotle:
        return CheckResult(
            name="aristotle",
            status=STATUS_FAIL,
            detail="API key set but `aristotle` CLI not on PATH",
            elapsed_sec=time.time() - t0,
            fix_hint="install aristotlelib + add to PATH",
        )
    return CheckResult(
        name="aristotle",
        status=STATUS_PASS,
        detail=f"{aristotle} (API key set)",
        elapsed_sec=time.time() - t0,
    )


def _check_anthropic_backend(*, live_ping: bool = True) -> CheckResult:
    """Detect which Anthropic backend is configured and verify it works.

    Supports all three customer-facing paths (direct / azure / bedrock).
    Detection mirrors ``kairos.model_client.registry._anthropic_factory``
    so the doctor validates the same routing the actual SDK call will use.

    Output tells the customer exactly which path is active + whether
    the 1-token ping succeeded, so they know at a glance if their
    specific auth surface works before burning sweep money.
    """
    t0 = time.time()
    env_choice = os.environ.get("KAIROS_ANTHROPIC_BACKEND", "").strip().lower()
    base_url = os.environ.get("ANTHROPIC_BASE_URL") or os.environ.get("AZURE_AI_API_BASE") or ""
    has_anthropic_key = bool(os.environ.get("ANTHROPIC_API_KEY"))
    has_aws_key = bool(os.environ.get("AWS_ACCESS_KEY_ID"))

    if env_choice == "bedrock":
        backend_label = "bedrock"
        # ATH-1199: bedrock auth resolves from one of 3 sources.
        # Report which one the SDK will pick up so the customer can
        # debug "why is my key not being used" without us echoing it.
        try:
            from kairos.config import (
                resolve_bedrock_source,
                bedrock_key_fingerprint,
                file_permissions_ok,
                BEDROCK_SOURCE_ENV,
                BEDROCK_SOURCE_CONFIG,
                BEDROCK_SOURCE_UNSET,
            )
            bedrock_source = resolve_bedrock_source()
            bedrock_fp = bedrock_key_fingerprint()
            perms_ok = file_permissions_ok()
        except ImportError:
            bedrock_source = BEDROCK_SOURCE_UNSET = "unset"
            BEDROCK_SOURCE_ENV = "env"
            BEDROCK_SOURCE_CONFIG = "config"
            bedrock_fp = None
            perms_ok = True

        if bedrock_source == BEDROCK_SOURCE_ENV:
            if not os.environ.get("AWS_SECRET_ACCESS_KEY"):
                return CheckResult(
                    name="anthropic (bedrock)",
                    status=STATUS_FAIL,
                    detail="AWS_ACCESS_KEY_ID set but AWS_SECRET_ACCESS_KEY missing",
                    elapsed_sec=time.time() - t0,
                    fix_hint="export AWS_SECRET_ACCESS_KEY (required for Bedrock auth)",
                )
            # env-triad source — pass through to live-ping.
        elif bedrock_source == BEDROCK_SOURCE_CONFIG:
            # Config-file fallback active. Surface fingerprint + perms warning.
            if not perms_ok:
                return CheckResult(
                    name="anthropic (bedrock)",
                    status=STATUS_FAIL,
                    detail=(
                        f"bedrock-key persisted ({bedrock_fp}) but "
                        "~/.athanor/config.json has loose permissions"
                    ),
                    elapsed_sec=time.time() - t0,
                    fix_hint="chmod 600 ~/.athanor/config.json",
                )
            # config-file source — pass through to live-ping. backend_label
            # is annotated below with the source for the live-ping success path.
        else:
            # bedrock backend selected but no auth source resolves.
            return CheckResult(
                name="anthropic (bedrock)",
                status=STATUS_FAIL,
                detail=(
                    "KAIROS_ANTHROPIC_BACKEND=bedrock but no auth source "
                    "(env AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY unset, "
                    "~/.athanor/config.json bedrock-key unset)"
                ),
                elapsed_sec=time.time() - t0,
                fix_hint=(
                    "export AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION, "
                    "or run: kairos config set bedrock-key <key>"
                ),
            )
        # Keep the canonical "bedrock" backend label so consumers like
        # `list_available_models` that match on `(bedrock)` substring
        # still work. The bedrock-source (env / config) flows through
        # the `detail` field below instead of mangling the name. Pre-
        # ATH-1199 contract: `r.name == "anthropic (bedrock)"`.
        backend_label = "bedrock"
        backend_label_with_source = f"bedrock · {bedrock_source}"
    elif env_choice == "azure" or (not env_choice and "azure" in base_url):
        backend_label = "azure"
        if not has_anthropic_key:
            return CheckResult(
                name="anthropic (azure)",
                status=STATUS_FAIL,
                detail="azure backend detected but ANTHROPIC_API_KEY not set",
                elapsed_sec=time.time() - t0,
                fix_hint="export ANTHROPIC_API_KEY with your Azure tenant key",
            )
    elif env_choice == "direct" or has_anthropic_key:
        backend_label = "direct"
    else:
        return CheckResult(
            name="anthropic",
            status=STATUS_SKIP,
            detail="no Anthropic env configured",
            elapsed_sec=time.time() - t0,
            fix_hint=(
                "Direct API: set ANTHROPIC_API_KEY (sk-ant-... key). "
                "Azure: set ANTHROPIC_API_KEY + ANTHROPIC_BASE_URL (both required). "
                "Bedrock: set AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION"
            ),
        )

    # Use the source-annotated label (e.g. "bedrock · config") in the
    # detail string so doctor output surfaces which auth source resolves,
    # while the name stays canonical for substring-matching consumers.
    detail_label = (
        backend_label_with_source
        if backend_label == "bedrock"
        else backend_label
    )

    if not live_ping:
        return CheckResult(
            name=f"anthropic ({backend_label})",
            status=STATUS_PASS,
            detail=f"env set — routing via {detail_label} (no live ping)",
            elapsed_sec=time.time() - t0,
        )

    try:
        from kairos.preflight_fleet import ping_model as _ping
        ok, msg = _ping("anthropic/claude-sonnet-4-6", timeout=10, retries=1)
        if ok:
            return CheckResult(
                name=f"anthropic ({backend_label})",
                status=STATUS_PASS,
                detail=f"key works — sonnet resolves via {detail_label}",
                elapsed_sec=time.time() - t0,
            )
        return CheckResult(
            name=f"anthropic ({backend_label})",
            status=STATUS_FAIL,
            detail=f"key set but sonnet ping failed via {backend_label}: {msg[:120]}",
            elapsed_sec=time.time() - t0,
            fix_hint=(
                f"check your {backend_label} credentials — "
                f"azure: verify ANTHROPIC_BASE_URL; "
                f"bedrock: verify AWS_REGION + IAM; "
                f"direct: verify sk-ant-... key"
            ),
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return CheckResult(
            name=f"anthropic ({backend_label})",
            status=STATUS_FAIL,
            detail=f"ping raised {type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
        )


# Provider → (env_var, default-ping-model).
# Anthropic handled separately by _check_anthropic_backend() which
# detects the active backend (direct/azure/bedrock) and reports it.
_PROVIDER_PINGS = [
    ("GEMINI_API_KEY", "gemini/gemini-3-flash-preview"),
    ("AZURE_API_KEY", "azure_ai/claude-sonnet-4-6"),
    ("OPENAI_API_KEY", None),
]


def _check_strict_sink_routing() -> CheckResult:
    """ATH-1048: emit a synthetic test event + verify it lands in Supabase.

    Per asabi 2026-05-05 22:34Z directive — pre-launch diagnostic that
    catches the silent-emit-no-op class research hit (run 113ad480).
    Sink resolution at import time is necessary but NOT sufficient;
    only an actual round-trip emit + read-back proves the routing
    works end-to-end.

    Flow:
    1. Open `kairos.observe.observe()` with a fresh run_id.
    2. Emit one verify_proof_attempt event.
    3. Wait for batch flush (default >5s SupabaseTraceSink batching).
    4. Query Supabase REST `/rest/v1/sdk_agent_events?run_id=eq.<rid>&select=count`.
    5. PASS if 3 events landed (agent_start + verify_proof_attempt +
       pipeline_complete). FAIL otherwise with the specific failure
       class (auth-401 / batch-flush-stuck / journal-fallthrough).

    Skipped when env vars unset (free-tier customers; the basic
    `_check_supabase_trace_sink` already flags that).
    """
    t0 = time.time()
    url = os.environ.get("SUPABASE_URL") or os.environ.get("NEXT_PUBLIC_SUPABASE_URL")
    key = (
        os.environ.get("ATHANOR_SYNC_TOKEN")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    )
    if not url or not key:
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_SKIP,
            detail="no Supabase env (free-tier path)",
            elapsed_sec=time.time() - t0,
        )

    try:
        from kairos.observe import emit, observe
        from kairos.trace import default_sink_from_env
    except Exception as e:  # noqa: BLE001 — guard returns fallback
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_FAIL,
            detail=f"kairos.observe import failed: {type(e).__name__}: {e}",
            elapsed_sec=time.time() - t0,
        )

    sink_name = type(default_sink_from_env()).__name__
    if sink_name != "SupabaseTraceSink":
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_FAIL,
            detail=(
                f"sink resolved as {sink_name}, not SupabaseTraceSink; "
                f"customer events would land in journal, not dashboard"
            ),
            elapsed_sec=time.time() - t0,
            fix_hint=(
                "Set ATHANOR_SYNC_TOKEN + NEXT_PUBLIC_SUPABASE_URL BEFORE "
                "importing kairos. Restart Python after fixing env."
            ),
        )

    import uuid
    test_run_id = str(uuid.uuid4())
    try:
        with observe(
            run_id=test_run_id,
            fleet_agent_role=os.environ.get("KAIROS_FLEET_ROLE", "doctor-strict-sink"),
            spawn_reason="kairos_doctor_strict_sink_smoke",
        ):
            emit("verify_proof_attempt", {"compiles": True})
    except Exception as e:  # noqa: BLE001 — guard fallback
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_FAIL,
            detail=f"observe()/emit() raised: {type(e).__name__}: {str(e)[:120]}",
            elapsed_sec=time.time() - t0,
        )

    # Wait for batch flush (SupabaseTraceSink _BATCH_MAX_AGE_SEC=5; give
    # it 15s headroom for cross-Atlantic RTT).
    import time as _time
    _time.sleep(15)

    # Round-trip read: query Supabase for the events we just emitted.
    try:
        import urllib.parse
        import urllib.request
        params = urllib.parse.urlencode({
            "run_id": f"eq.{test_run_id}",
            "select": "event_type,sequence",
        })
        req = urllib.request.Request(
            f"{url.rstrip('/')}/rest/v1/sdk_agent_events?{params}",
            headers={
                "apikey": key,
                "Authorization": f"Bearer {key}",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
        rows = json.loads(raw)
    except Exception as e:  # noqa: BLE001 — guard fallback
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_FAIL,
            detail=f"read-back query raised: {type(e).__name__}: {str(e)[:120]}",
            elapsed_sec=time.time() - t0,
            fix_hint="check ATHANOR_SYNC_TOKEN value + Supabase URL value",
        )

    n_events = len(rows)
    expected = 3  # agent_start + verify_proof_attempt + pipeline_complete
    if n_events == expected:
        return CheckResult(
            name="strict sink routing (round-trip)",
            status=STATUS_PASS,
            detail=f"{n_events}/{expected} events landed in {test_run_id[:8]}...",
            elapsed_sec=time.time() - t0,
        )
    return CheckResult(
        name="strict sink routing (round-trip)",
        status=STATUS_FAIL,
        detail=(
            f"only {n_events}/{expected} events landed for test run "
            f"{test_run_id} after 15s wait. Either emit no-op'd, batch "
            f"never flushed, or auth 401-silently."
        ),
        elapsed_sec=time.time() - t0,
        fix_hint=(
            "Verify ATHANOR_SYNC_TOKEN matches the project at "
            "NEXT_PUBLIC_SUPABASE_URL. Re-run with KAIROS_TRACE_STRICT=1 "
            "to see the batch flush error directly."
        ),
    )


def _check_git_fetch_refspec() -> CheckResult:
    """Verify the current repo (if any) has a remote.origin.fetch refspec configured.

    Symptom this catches: silent ``git fetch`` no-op when the standard
    ``+refs/heads/*:refs/remotes/origin/*`` refspec is missing from the
    git config. ``git fetch`` reports success but ``origin/main`` does
    not advance, so ``git pull`` says "Already up to date" against a
    stale remote-tracking ref. The worst-of-both failure mode for any
    ``gh pr merge`` workflow: admin-merge succeeds remotely, local
    state lies about it.

    Detection: run ``git config --get-all remote.origin.fetch`` from
    the current working directory. Any non-empty output that includes
    a ``refs/heads`` mapping is PASS. Empty output is FAIL with a
    one-line ``git config --add`` fix hint.

    Skip-clean: if the current working directory is not a git checkout
    (no ``.git`` directory or worktree pointer reachable), skip silently
    rather than fail-loud — customer engineers running ``kairos doctor``
    outside a repo (the standard onboarding posture per Phase 0e
    customer guide section 2) shouldn't see a spurious failure.

    Tracked under ATH-1059. Fleet-wide diagnostic worth running by
    default since the failure mode is silent.
    """
    t0 = time.time()
    canonical_refspec = "+refs/heads/*:refs/remotes/origin/*"

    # Skip if we're not in a git repo. Use `git rev-parse` which is
    # cheap + handles worktrees, submodules, and bare-repo-pointer
    # files correctly (where `.git` is a file not a directory).
    try:
        rev_parse = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return CheckResult(
            name="git fetch refspec",
            status=STATUS_SKIP,
            detail=f"git binary not available: {type(e).__name__}",
            elapsed_sec=time.time() - t0,
        )
    if rev_parse.returncode != 0:
        return CheckResult(
            name="git fetch refspec",
            status=STATUS_SKIP,
            detail="not a git repository",
            elapsed_sec=time.time() - t0,
        )

    try:
        config_get = subprocess.run(
            ["git", "config", "--get-all", "remote.origin.fetch"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return CheckResult(
            name="git fetch refspec",
            status=STATUS_FAIL,
            detail="git config command timed out",
            elapsed_sec=time.time() - t0,
            fix_hint=(
                "git config --add remote.origin.fetch "
                "'+refs/heads/*:refs/remotes/origin/*'"
            ),
        )

    refspec_output = config_get.stdout.strip()
    if not refspec_output:
        return CheckResult(
            name="git fetch refspec",
            status=STATUS_FAIL,
            detail=(
                "remote.origin.fetch is empty; `git fetch origin main` "
                "will silent-no-op for new commits on origin/main"
            ),
            elapsed_sec=time.time() - t0,
            fix_hint=(
                f"git config --add remote.origin.fetch "
                f"'{canonical_refspec}' && git fetch origin"
            ),
        )

    # Verify at least one configured refspec maps refs/heads to a remote-tracking ref.
    has_heads_mapping = any(
        "refs/heads" in line and "refs/remotes" in line
        for line in refspec_output.splitlines()
    )
    if not has_heads_mapping:
        return CheckResult(
            name="git fetch refspec",
            status=STATUS_FAIL,
            detail=(
                f"remote.origin.fetch configured but does not map "
                f"refs/heads/ to a remote-tracking ref: "
                f"{refspec_output!r}"
            ),
            elapsed_sec=time.time() - t0,
            fix_hint=(
                f"git config --add remote.origin.fetch "
                f"'{canonical_refspec}' && git fetch origin"
            ),
        )

    return CheckResult(
        name="git fetch refspec",
        status=STATUS_PASS,
        detail=refspec_output.replace("\n", "; "),
        elapsed_sec=time.time() - t0,
    )


def _check_yosys_binary() -> CheckResult:
    """yosys on PATH + reports version."""
    t0 = time.time()
    yosys = shutil.which("yosys")
    if not yosys:
        return CheckResult(
            name="yosys binary",
            status=STATUS_FAIL,
            detail="not found on PATH",
            elapsed_sec=time.time() - t0,
            fix_hint="apt install yosys (Ubuntu) or brew install yosys (macOS)",
        )
    try:
        res = subprocess.run(
            [yosys, "--version"],
            capture_output=True, text=True, timeout=5,
        )
        ver = (res.stdout or res.stderr).strip().splitlines()[0][:80]
        return CheckResult(
            name="yosys binary",
            status=STATUS_PASS,
            detail=f"{yosys} ({ver})",
            elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001
        return CheckResult(
            name="yosys binary",
            status=STATUS_FAIL,
            detail=f"{type(e).__name__}: {str(e)[:80]}",
            elapsed_sec=time.time() - t0,
        )


def _check_ebmc_binary() -> CheckResult:
    """ebmc on PATH."""
    t0 = time.time()
    ebmc = shutil.which("ebmc")
    if not ebmc:
        return CheckResult(
            name="ebmc binary",
            status=STATUS_SKIP,
            detail="not found on PATH (optional for combo-only blocks)",
            elapsed_sec=time.time() - t0,
            fix_hint="download from github.com/diffblue/hw-cbmc/releases",
        )
    try:
        res = subprocess.run(
            [ebmc, "--version"],
            capture_output=True, text=True, timeout=5,
        )
        ver = (res.stdout or res.stderr or "installed").strip().splitlines()[0][:80]
        return CheckResult(
            name="ebmc binary",
            status=STATUS_PASS,
            detail=f"{ebmc} ({ver})",
            elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001
        return CheckResult(
            name="ebmc binary",
            status=STATUS_PASS,
            detail=f"{ebmc} (version check failed, binary exists)",
            elapsed_sec=time.time() - t0,
        )


def _check_model_env_sanity() -> CheckResult:
    """Warn if model env vars are misconfigured. Covers Azure, Bedrock,
    and direct API routing with clear diagnostics per path."""
    litellm_base = os.environ.get("LITELLM_API_BASE", "")
    anthropic_base = os.environ.get("ANTHROPIC_BASE_URL", "")
    azure_base = os.environ.get("AZURE_AI_API_BASE", "")
    has_any_key = bool(
        os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("LITELLM_API_KEY")
        or os.environ.get("AZURE_AI_API_KEY")
    )
    has_aws = bool(os.environ.get("AWS_ACCESS_KEY_ID"))

    if has_aws:
        region = os.environ.get(
            "AWS_BEDROCK_REGION",
            os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "not set")),
        )
        has_secret = bool(os.environ.get("AWS_SECRET_ACCESS_KEY"))
        has_session = bool(os.environ.get("AWS_SESSION_TOKEN"))
        parts = [f"region={region}"]
        if not has_secret:
            parts.append("WARNING: AWS_SECRET_ACCESS_KEY missing")
        if has_session:
            parts.append("session-token present (assumed role)")
        backend_choice = os.environ.get("KAIROS_ANTHROPIC_BACKEND", "").strip().lower()
        if backend_choice != "bedrock":
            parts.append("HINT: set KAIROS_ANTHROPIC_BACKEND=bedrock to route Claude via Bedrock")
        detail = "; ".join(parts)
        status = STATUS_PASS if has_secret else STATUS_FAIL
        return CheckResult(
            name="model env vars (bedrock)",
            status=status,
            detail=f"AWS creds detected ({detail})",
            fix_hint="export AWS_SECRET_ACCESS_KEY + KAIROS_ANTHROPIC_BACKEND=bedrock" if not has_secret else "",
        )

    if litellm_base and not anthropic_base and not azure_base:
        return CheckResult(
            name="model env vars",
            status=STATUS_SKIP,
            detail=(
                f"LITELLM_API_BASE is set ({litellm_base[:40]}...) but "
                f"ANTHROPIC_BASE_URL is not. LITELLM_API_BASE routes "
                f"Kimi/Mistral (OpenAI-compatible), not Claude."
            ),
            fix_hint=(
                "For Claude on Azure: set ANTHROPIC_BASE_URL. "
                "For Bedrock: set AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + KAIROS_ANTHROPIC_BACKEND=bedrock"
            ),
        )
    if has_any_key and not (anthropic_base or azure_base or litellm_base):
        return CheckResult(
            name="model env vars",
            status=STATUS_PASS,
            detail="Direct Anthropic API (no base URL override)",
        )
    if anthropic_base and "azure" in anthropic_base:
        return CheckResult(
            name="model env vars",
            status=STATUS_PASS,
            detail=f"Azure routing configured ({anthropic_base[:40]}...)",
        )
    if anthropic_base:
        return CheckResult(
            name="model env vars",
            status=STATUS_PASS,
            detail=f"Custom endpoint ({anthropic_base[:40]}...)",
        )
    if has_any_key:
        return CheckResult(
            name="model env vars",
            status=STATUS_PASS,
            detail="Direct Anthropic API",
        )
    return CheckResult(
        name="model env vars",
        status=STATUS_FAIL,
        detail="No model API key or AWS credentials set",
        fix_hint=(
            "Set ANTHROPIC_API_KEY for direct API, or "
            "AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + KAIROS_ANTHROPIC_BACKEND=bedrock for Bedrock"
        ),
    )


def run_all_checks(
    *,
    live_ping: bool = True,
    check_vllm: bool = False,
    check_aristotle: bool = False,
    strict_sink_routing: bool = False,
) -> list[CheckResult]:
    """Run the standard check battery + optional opt-in checks."""
    results: list[CheckResult] = []
    results.append(_check_kairos_version())
    results.append(_check_python_version())
    results.append(_check_license())
    results.append(_check_lake_binary())
    results.append(_check_supabase_trace_sink())
    results.append(_check_s3_trace_sink())
    results.append(_check_run_history())
    results.append(_check_yosys_binary())
    results.append(_check_ebmc_binary())
    results.append(_check_anthropic_backend(live_ping=live_ping))
    for env_var, model in _PROVIDER_PINGS:
        results.append(_check_provider_env(env_var, model, live_ping=live_ping))
    # ATH-1059: silent-fetch-no-op detection. PASS / SKIP cheap (~50ms);
    # FAIL is rare but high-impact (admin-merge succeeds remotely,
    # local state lies about it). Run by default.
    results.append(_check_git_fetch_refspec())
    results.append(_check_model_env_sanity())
    if check_vllm:
        results.append(_check_vllm())
    if check_aristotle:
        results.append(_check_aristotle())
    if strict_sink_routing:
        # ATH-1048: opt-in expensive (~15s sleep + Supabase round-trip)
        # check that emit-and-verify actually lands in the dashboard.
        results.append(_check_strict_sink_routing())
    return results


def format_table(results: list[CheckResult]) -> str:
    """Pretty-print results as an aligned table."""
    name_w = max(len(r.name) for r in results) + 2
    out_lines = []
    for r in results:
        glyph = _GLYPH.get(r.status, "?")
        line = f"{glyph} {r.name.ljust(name_w)} {r.detail}"
        out_lines.append(line)
        if r.is_fail() and r.fix_hint:
            out_lines.append(f"  ↳ fix: {r.fix_hint}")
    n_pass = sum(1 for r in results if r.is_pass())
    n_fail = sum(1 for r in results if r.is_fail())
    n_skip = sum(1 for r in results if r.is_skip())
    out_lines.append("")
    out_lines.append(
        f"{n_pass} passed, {n_fail} failed, {n_skip} skipped of {len(results)} checks"
    )
    return "\n".join(out_lines)


def format_json(results: list[CheckResult]) -> str:
    """JSON-lines output, one CheckResult per line."""
    return "\n".join(
        json.dumps({
            "name": r.name,
            "status": r.status,
            "detail": r.detail,
            "elapsed_sec": round(r.elapsed_sec, 3),
            "fix_hint": r.fix_hint,
        })
        for r in results
    )


def compute_exit_code(results: list[CheckResult], strict: bool = False) -> int:
    """Map check outcomes to process exit code.

    * 0 — all pass (skips OK in default mode)
    * 1 — any fail
    * 2 — strict + any skip
    """
    if any(r.is_fail() for r in results):
        return 1
    if strict and any(r.is_skip() for r in results):
        return 2
    return 0


def _check_sslmode_permissive() -> CheckResult:
    """ATH-1261: warn on persisted sslmode=disable in Supabase/Postgres URLs.

    Customers with stale sslmode=disable continue functioning but silently
    skip TLS verification. Doctor surfaces this as a WARN so they know
    to upgrade.
    """
    import os
    from kairos.config import _extract_sslmode, _PERMISSIVE_SSLMODES

    urls_to_check = [
        ("SUPABASE_URL", os.environ.get("SUPABASE_URL", "")),
        ("DATABASE_URL", os.environ.get("DATABASE_URL", "")),
        ("KAIROS_TRACE_SINK_URL", os.environ.get("KAIROS_TRACE_SINK_URL", "")),
    ]
    permissive_found = []
    for env_name, url in urls_to_check:
        if not url:
            continue
        mode = _extract_sslmode(url)
        if mode and mode in _PERMISSIVE_SSLMODES:
            permissive_found.append((env_name, mode))

    if not permissive_found:
        return CheckResult("sslmode-security", "ok",
                          "no permissive sslmode in connection URLs")
    details = "; ".join(f"${name} has sslmode={mode}" for name, mode in permissive_found)
    return CheckResult("sslmode-security", "warn",
                      f"permissive sslmode detected: {details}. "
                      f"Upgrade to sslmode=verify-full for TLS verification.")


def run_doctor(
    *,
    live_ping: bool = True,
    check_vllm: bool = False,
    check_aristotle: bool = False,
    strict_sink_routing: bool = False,
    strict: bool = False,
    json_output: bool = False,
) -> int:
    """Top-level entry point — run + print + return exit code."""
    results = run_all_checks(
        live_ping=live_ping,
        check_vllm=check_vllm,
        check_aristotle=check_aristotle,
        strict_sink_routing=strict_sink_routing,
    )
    if json_output:
        print(format_json(results))
    else:
        print(format_table(results))
    return compute_exit_code(results, strict=strict)


# ────────────────────────────────────────────────────────────────────
# ATH-1037 additions: list_available_models + collision detection + help()
#
# Discovery path:
# - 4 pain points caught in 2026-05-05 research dogfood
# - Aidan ts=1778001151: "preflight should catch all issues before launching"
# - Aidan ts=1778001823: "customers don't have keys.md, that is for internal.
#   Customers will put in their own api keys (from maybe anthropic, or oai,
#   or litellm, or bedrock. but probably bedrock since customer right now is
#   amazon). Make absolute sure everything still works."
#
# These additions sit on top of the ATH-844 doctor module so the customer-
# facing diagnostic is a single SSOT (`python -m kairos doctor`) + the
# programmatic surface for MCP integration (`kairos.list_available_models`).
# ────────────────────────────────────────────────────────────────────


class AvailableModel(TypedDict):
    """Model the customer can call given current env (ATH-1037).

    Returned by :func:`list_available_models` so customer agent code (and
    MCP integration) only ever asks for a model that will route cleanly.

    ATH-1290 (2026-05-14): typed as ``TypedDict`` rather than
    ``@dataclass`` so the public API surface is JSON-serializable by
    default — MCP integration + any caller doing
    ``json.dumps(list_available_models())`` works without a custom
    encoder. The dict shape doubles as the wire format: callers access
    fields by key (``m["model_id"]``) rather than attribute (``m.model_id``).

    Mutation receipt: revert this class to ``@dataclass`` and
    ``test_list_available_models_exposed_on_kairos_module`` fails again
    with ``TypeError: Object of type AvailableModel is not JSON
    serializable``.
    """

    model_id: str           # litellm-style id (e.g. "anthropic/claude-sonnet-4-6")
    provider: str           # "anthropic" | "gemini" | "openai" | ...
    backend: str            # "direct" | "azure" | "bedrock" | "openai-compat"
    notes: str


# Sample models per backend. Caller is expected to have the corresponding
# provider env in green doctor state. Anthropic dispatches the same model
# ids across all three backends (direct/azure/bedrock); registry resolves.
_BACKEND_MODELS: dict[str, list[str]] = {
    "anthropic-direct": [
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-7",
        "anthropic/claude-haiku-4-5",
    ],
    "anthropic-azure": [
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-7",
    ],
    "anthropic-bedrock": [
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-7",
        "anthropic/claude-haiku-4-5",
    ],
    "gemini-direct": [
        "gemini/gemini-2.5-flash",
        "gemini/gemini-3-flash-preview",
    ],
    "azure-openai": [
        "openai/kimi-k2.5",
        "openai/mistral-large-3",
    ],
    "openai-direct": [
        "openai/gpt-4o",
    ],
}


def detect_routing_collisions(env: Optional[dict[str, str]] = None) -> list[str]:
    """Warn about ambiguous env-var combinations that confuse litellm.

    Pre-fix: research's 2026-05-05 dogfood hit ``api-version query parameter
    not allowed when using /v1 path`` because ANTHROPIC_BASE_URL (Azure-
    Anthropic) and AZURE_OPENAI_BASE_URL were both set; litellm couldn't
    pick a routing path. The doctor surfaces these collisions explicitly
    rather than letting them surface as opaque litellm errors at first call.

    Returns a list of human-readable warnings. Empty list = no collisions.
    """
    if env is None:
        env = dict(os.environ)
    warnings: list[str] = []

    anthropic_base = env.get("ANTHROPIC_BASE_URL", "").strip()
    openai_base = env.get("OPENAI_API_BASE", "").strip()
    azure_ai_base = env.get("AZURE_AI_API_BASE", "").strip()
    azure_openai_base = env.get("AZURE_OPENAI_BASE_URL", "").strip()
    backend_choice = env.get("KAIROS_ANTHROPIC_BACKEND", "").strip().lower()
    has_anthropic_key = bool(env.get("ANTHROPIC_API_KEY", "").strip())
    has_aws_keys = bool(
        env.get("AWS_ACCESS_KEY_ID", "").strip()
        and env.get("AWS_SECRET_ACCESS_KEY", "").strip()
    )

    azure_anthropic_active = bool(
        anthropic_base and "azure" in anthropic_base.lower()
    )

    if azure_anthropic_active and backend_choice == "bedrock":
        warnings.append(
            "ANTHROPIC_BASE_URL points at Azure but KAIROS_ANTHROPIC_BACKEND=bedrock. "
            "Pick one: unset ANTHROPIC_BASE_URL for Bedrock, or unset "
            "KAIROS_ANTHROPIC_BACKEND for Azure-Anthropic."
        )
    if azure_anthropic_active and azure_openai_base and azure_openai_base != anthropic_base:
        warnings.append(
            "ANTHROPIC_BASE_URL and AZURE_OPENAI_BASE_URL point at different Azure "
            "tenants. Unset one (or set both to the same tenant URL) — pre-2026-05-05 "
            "research hit `api-version query parameter not allowed when using /v1 path` "
            "from this exact collision."
        )
    if has_anthropic_key and backend_choice == "bedrock" and not anthropic_base:
        warnings.append(
            "ANTHROPIC_API_KEY (looks like a direct key) is set AND "
            "KAIROS_ANTHROPIC_BACKEND=bedrock. The Bedrock path uses AWS credentials, "
            "not ANTHROPIC_API_KEY — unset ANTHROPIC_API_KEY to silence ambiguity."
        )
    if has_aws_keys and has_anthropic_key and not anthropic_base and backend_choice not in {"bedrock", "direct"}:
        warnings.append(
            "Both ANTHROPIC_API_KEY (direct) and AWS_* (Bedrock) credentials are set "
            "without KAIROS_ANTHROPIC_BACKEND specified. Set KAIROS_ANTHROPIC_BACKEND=direct "
            "or KAIROS_ANTHROPIC_BACKEND=bedrock to disambiguate."
        )
    has_session_token = bool(env.get("AWS_SESSION_TOKEN", "").strip())
    if has_session_token and not has_aws_keys:
        warnings.append(
            "AWS_SESSION_TOKEN is set but AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY are missing. "
            "Session tokens only work alongside access key credentials."
        )
    has_region = bool(
        env.get("AWS_BEDROCK_REGION", "").strip()
        or env.get("AWS_REGION", "").strip()
        or env.get("AWS_DEFAULT_REGION", "").strip()
    )
    if has_aws_keys and backend_choice == "bedrock" and not has_region:
        warnings.append(
            "KAIROS_ANTHROPIC_BACKEND=bedrock with AWS credentials but no region set. "
            "Set AWS_REGION or AWS_BEDROCK_REGION (e.g. us-west-2, us-east-1)."
        )

    return warnings


def list_available_models(
    env: Optional[dict[str, str]] = None,
) -> list[AvailableModel]:
    """Enumerate models the customer can actually call given current env.

    Pure (no-network): runs the doctor check battery in ``live_ping=False``
    mode + emits one :class:`AvailableModel` per (provider, model) pair
    whose provider check passes. Empty list ⇒ no provider configured;
    customer must run ``python -m kairos doctor`` for setup help.

    Powers MCP integration: customer agent calls this and never asks for
    a model whose provider would 401/404.

    Args:
        env: optional env dict for testability. Defaults to a snapshot
            of os.environ.
    """
    if env is None:
        env = dict(os.environ)
    # Run the existing battery in no-live-ping mode so this is fast +
    # offline-safe (MCP integration may call this every turn).
    saved_environ = os.environ
    try:
        os.environ = env  # type: ignore[assignment]
        results = run_all_checks(live_ping=False)
    finally:
        os.environ = saved_environ  # type: ignore[assignment]

    out: list[AvailableModel] = []
    for r in results:
        if not r.is_pass():
            continue
        # The ATH-844 anthropic check names itself "anthropic (direct)" /
        # "anthropic (azure)" / "anthropic (bedrock)" depending on routing.
        if r.name.startswith("anthropic"):
            backend = "direct"
            if "(azure)" in r.name:
                backend = "azure"
            elif "(bedrock)" in r.name:
                backend = "bedrock"
            for m in _BACKEND_MODELS.get(f"anthropic-{backend}", []):
                out.append(AvailableModel(
                    model_id=m, provider="anthropic", backend=backend,
                    notes="",
                ))
        elif "GEMINI" in r.name or r.name.lower().startswith("gemini"):
            for m in _BACKEND_MODELS["gemini-direct"]:
                out.append(AvailableModel(
                    model_id=m, provider="gemini", backend="direct",
                    notes="",
                ))
        elif "AZURE_API_KEY" in r.name or r.name.lower().startswith("azure"):
            for m in _BACKEND_MODELS["azure-openai"]:
                out.append(AvailableModel(
                    model_id=m, provider="openai-compat", backend="azure",
                    notes="",
                ))
        elif "OPENAI_API_KEY" in r.name or r.name.lower().startswith("openai"):
            for m in _BACKEND_MODELS["openai-direct"]:
                out.append(AvailableModel(
                    model_id=m, provider="openai", backend="direct",
                    notes="",
                ))
    return out


def help() -> str:  # noqa: A001 — public surface intentionally shadows builtin
    """Programmatic counterpart to ``python -m kairos doctor``.

    Returns the formatted output string the CLI prints, so customer code
    can ``print(kairos.help())`` from a notebook before any prove() call
    to verify the env is ready.

    Includes the ATH-1037 routing-collision warnings appended below the
    standard check table so customer sees both layers in one render.
    """
    results = run_all_checks(live_ping=False)
    out = format_table(results)
    collisions = detect_routing_collisions()
    if collisions:
        out += "\n\nRouting collisions (pick one path):\n"
        for w in collisions:
            out += f"  ! {w}\n"
    if not results or not any(r.is_pass() for r in results):
        out += (
            "\nNo provider configured. See docs/customer-onboarding.md "
            "for the env vars required per provider (anthropic-direct, "
            "anthropic-azure, bedrock, openai-direct, azure-openai, gemini).\n"
        )
    return out


__all__ = [
    "CheckResult",
    "STATUS_PASS",
    "STATUS_FAIL",
    "STATUS_SKIP",
    "compute_exit_code",
    "format_json",
    "format_table",
    "run_all_checks",
    "run_doctor",
    # ATH-1037 customer-onboarding additions
    "AvailableModel",
    "detect_routing_collisions",
    "list_available_models",
    "help",
]
