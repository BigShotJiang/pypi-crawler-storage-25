"""kairos.autoformalize — multi-tier autoformalize pipeline (PR #10 MVP).

Gate 9 scaffold. Public API re-exports the 7 Protocols + key types
from `protocols.py`; default implementations live in `defaults.*`
(shipped separately in subsequent commits).

See `athanor-sdk/docs/pr-10-autoformalize-design.md` for the full
architecture + `athanor-sdk/docs/pr-10-autoformalize-drafter-prompts.md`
for the drafter/reviewer/orchestrator prompt templates extracted
from ATH-495 preview.
"""
from __future__ import annotations

from kairos.autoformalize.protocols import (
    # Shared types
    CoverageGap,
    DrafterContext,
    OrchestrationChoice,
    ParsedNL,
    ReviewConcern,
    ReviewContext,
    ReviewResult,
    Score,
    TierSpec,
    Verdict,
    # The 7 Protocols
    ModelSelectorPlugin,
    OrchestratorPlugin,
    PromptLoader,
    ScoringFn,
    ToolRegistryPlugin,
    TraceSink,
    VerifierPlugin,
    # Registry + exceptions
    KNOWN_TIERS,
    BudgetExceeded,
    OrchestrationInvalidPlugin,
    OrchestrationMalformed,
    PromptMissing,
    ToolAlreadyRegistered,
    ToolNotFound,
    UnknownTier,
)

__all__ = [
    # Types
    "CoverageGap",
    "DrafterContext",
    "OrchestrationChoice",
    "ParsedNL",
    "ReviewConcern",
    "ReviewContext",
    "ReviewResult",
    "Score",
    "TierSpec",
    "Verdict",
    # Protocols
    "ModelSelectorPlugin",
    "OrchestratorPlugin",
    "PromptLoader",
    "ScoringFn",
    "ToolRegistryPlugin",
    "TraceSink",
    "VerifierPlugin",
    # Registry + exceptions
    "KNOWN_TIERS",
    "BudgetExceeded",
    "OrchestrationInvalidPlugin",
    "OrchestrationMalformed",
    "PromptMissing",
    "ToolAlreadyRegistered",
    "ToolNotFound",
    "UnknownTier",
]
