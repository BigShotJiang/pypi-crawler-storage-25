"""Default implementations for the 7 autoformalize Protocols.

Each default is the "smart / strong / reasonable" choice per the
design doc (§13b.1 table). Customers can swap in custom
implementations without touching the defaults.

Purity taxonomy (QA 2026-04-22) echoed:
  Pure:          BuiltinPromptLoader, VerdictEnumScoringFn, DefaultModelSelector
  Impure:        kairos.fleet.Orchestrator (LLM call; ATH-570 rename of OpusOrchestrator),
                 BuiltinToolRegistry (lookup)
  Impure+side-effectful:  NoopTraceSink / SupabaseTraceSink

See `kairos.autoformalize.protocols` for Protocol contracts.
"""
from __future__ import annotations

from kairos.autoformalize.defaults.orchestrator import (
    DefaultRuleBasedOrchestrator,
    Orchestrator,
)

__all__ = [
    "DefaultRuleBasedOrchestrator",
    "Orchestrator",
]
