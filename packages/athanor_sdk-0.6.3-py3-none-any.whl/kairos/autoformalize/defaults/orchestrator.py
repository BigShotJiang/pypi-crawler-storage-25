"""Autoformalize orchestrator defaults — thin re-exports.

**ATH-570 (2026-04-24):** the LLM-backed orchestrator moved from
`kairos.spec.defaults.OpusOrchestrator` to `kairos.fleet.Orchestrator`
and now takes a `model=` kwarg (default opus-4.6). This module
re-exports under the autoformalize namespace so downstream code that
imports from `kairos.autoformalize.defaults.*` keeps working with the
new name.

`DefaultRuleBasedOrchestrator` is an alias for
`DefaultRoundRobinOrchestrator` — same semantics (fixed tier dispatch
from KairosConfig.default_tier_dispatch), separate name preserved for
the autoformalize pipeline's historical prompt-documentation.
"""
from __future__ import annotations

from kairos.fleet import Orchestrator
from kairos.spec.defaults import DefaultRoundRobinOrchestrator

# Legacy name — `DefaultRuleBasedOrchestrator` used in the ATH-495
# preview and early design doc before Gate 5 canonicalization renamed
# it to `DefaultRoundRobinOrchestrator`. Alias kept so
# `kairos.autoformalize.__init__` + any customer wheels importing the
# old name continue to resolve.
DefaultRuleBasedOrchestrator = DefaultRoundRobinOrchestrator

__all__ = [
    "DefaultRoundRobinOrchestrator",
    "DefaultRuleBasedOrchestrator",
    "Orchestrator",
]
