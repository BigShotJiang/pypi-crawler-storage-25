"""kairos.synth — yosys-driven gate-count measurement (ATH-1063 Phase 0c).

Verified gate-count delta hook required by ATH-1061 ambition pin: every
shipped optimization cert flips from "claimed -X%" (proposer estimate)
to "verified -N gates" (synth-tool measured) before any customer-bound
package mints. This module is the synth-tool side; the cert prose
generator consumes the result and emits the verified delta verbatim.

## Public API

- :func:`yosys_gate_count` — run yosys synth + ABC technology mapping
  on an RTL file, return the post-synth gate count + verbatim subprocess
  log path. Pure-function over (rtl_path, top_module).
- :class:`YosysGateCountResult` — frozen dataclass result.
- :class:`YosysSynthError` — raised on subprocess failure / timeout /
  yosys-binary-missing.

## Why pure-function

Same shape as :mod:`kairos.cert._bundle_audit`: pre-tape-out cert audit
demands deterministic, side-effect-free measurement. The customer-trust
contract on a verified gate-count delta requires the synth log shipped
verbatim in the cert tarball, so the customer can independently re-run
yosys + reproduce the count. This module produces the log; the bundle
build script copies it into the tarball.

## yosys binary requirement

Requires ``yosys`` on ``$PATH``. Tested against yosys 0.44 (locally)
and the version pinned in CI. Detection happens on first call; missing
binary raises :class:`YosysSynthError` with a clear remediation hint
("install yosys via apt / brew / from source").
"""
from __future__ import annotations

from kairos.synth._yosys import (
    YosysGateCountResult,
    YosysSynthError,
    yosys_gate_count,
)

__all__ = [
    "YosysGateCountResult",
    "YosysSynthError",
    "yosys_gate_count",
]
