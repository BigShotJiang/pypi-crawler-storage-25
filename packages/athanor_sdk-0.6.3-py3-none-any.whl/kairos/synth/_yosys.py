"""yosys-driven gate-count measurement (ATH-1063 Phase 0c).

Runs yosys synth + ABC technology mapping on an RTL file, parses the
post-mapping cell count from yosys stat output, captures the verbatim
subprocess log for cert-tarball reproducibility.

The gate count returned is the sum of all primitive cells reported by
yosys ``stat`` after generic synthesis + ABC mapping. This is the
proxy metric for power per Todd's rule-of-thumb (lower gates = lower
dynamic power); per-cell area weighting is a follow-up that requires
a Liberty file customers ship in (out of scope for v2.8).

The default ABC script is ``synth -auto-top; abc -fast`` which produces
a generic-cell post-mapping result. Customers can pass a custom script
to map against their internal stdcell library.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path


# Match yosys stat output's "Number of cells: N" header line.
# Format from yosys 0.44+: "   Number of cells:                  N"
_CELLS_HEADER_RE = re.compile(
    r"^\s*Number of cells:\s+(\d+)\s*$",
    re.MULTILINE,
)


# Default yosys script: read RTL, generic synth, ABC fast pass, stat.
# Customers can override via abc_script kwarg.
#
# Multi-module bundles (ATH-1074): {dep_reads} expands to additional
# `read_verilog -sv -formal <dep_path>` lines for each dep file. When
# no deps, expands to empty string.
_DEFAULT_YOSYS_SCRIPT = """
{dep_reads}read_verilog -sv -formal {rtl_path}
hierarchy -check -top {top_module}
proc; opt; fsm; opt; memory; opt
synth -auto-top
abc -fast
opt_clean
stat
"""


class YosysSynthError(RuntimeError):
    """Raised when yosys synth + ABC fails for any reason.

    The customer-trust contract on a verified gate-count cert demands
    that synth failures fail-loud rather than silently produce a default
    or zero count. Any caller that catches this should fall back to
    "claimed -X%" framing on the cert and disclose the synth failure
    explicitly in the cert prose.
    """


@dataclass(frozen=True)
class YosysGateCountResult:
    """Verbatim yosys synth + ABC gate-count measurement.

    Attributes
    ----------
    gate_count:
        Total primitive cell count after generic synth + ABC mapping.
    rtl_path:
        Absolute path to the RTL source file synthesized.
    top_module:
        Top-level module name passed to yosys ``hierarchy``.
    log_path:
        Absolute path to the yosys subprocess stdout/stderr capture.
        Ships in cert tarballs verbatim so customers can independently
        re-run yosys + reproduce the count.
    exit_code:
        yosys subprocess exit code. 0 on success.
    runtime_sec:
        Wall-clock seconds for the yosys subprocess.
    yosys_version:
        First-line yosys version banner (e.g. ``"Yosys 0.44 (git sha1
        80ba43d26, ...)"``). Recorded for cross-version-drift audit.
    """

    gate_count: int
    rtl_path: str
    top_module: str
    log_path: str
    exit_code: int
    runtime_sec: float
    yosys_version: str = ""


def _build_script(
    rtl_path: Path,
    top_module: str,
    *,
    abc_script: str | None,
    dep_files: list[Path] | None = None,
) -> str:
    """Render the yosys script with rtl_path + top_module substituted.

    When ``abc_script`` is provided, replace the default ``synth -auto-top;
    abc -fast`` line with the customer's script.

    When ``dep_files`` is non-empty, prepend ``read_verilog -sv -formal``
    lines for each dep file so yosys's ``hierarchy -check -top`` resolves
    sub-module instantiations (ATH-1074).
    """
    if dep_files:
        dep_reads = "".join(
            f"read_verilog -sv -formal {dep}\n" for dep in dep_files
        )
    else:
        dep_reads = ""
    script = _DEFAULT_YOSYS_SCRIPT.format(
        rtl_path=str(rtl_path), top_module=top_module, dep_reads=dep_reads
    )
    if abc_script is not None:
        # Replace the synth + abc lines with the custom script. Caller
        # is responsible for ending with `stat` (we always need the
        # stat output to parse).
        script = (
            f"{dep_reads}"
            f"read_verilog -sv -formal {rtl_path}\n"
            f"hierarchy -check -top {top_module}\n"
            f"{abc_script}\n"
            f"stat\n"
        )
    return script


def parse_yosys_stat(stdout: str) -> int:
    """Extract the post-mapping cell count from yosys ``stat`` output.

    yosys ``stat`` prints a header ``Number of cells:`` followed by the
    breakdown per cell type. We sum the header line as the canonical
    post-mapping count. Multiple ``stat`` invocations in one log
    (e.g. pre- and post-mapping) produce multiple matches; the LAST
    match wins (post-mapping is what we ship as the verified count).

    Raises :class:`YosysSynthError` when no cell-count line is found,
    which means yosys did not reach the ``stat`` step (typically a
    parse error on the RTL or a hierarchy mismatch).
    """
    matches = _CELLS_HEADER_RE.findall(stdout)
    if not matches:
        raise YosysSynthError(
            "yosys did not produce a 'Number of cells:' line in stdout. "
            "Likely causes: RTL parse error, hierarchy mismatch on "
            "top_module, or yosys subprocess crash before stat. Check "
            "the log file for the actual error."
        )
    return int(matches[-1])


def _extract_yosys_version(stdout: str) -> str:
    """First-line yosys version banner. Empty string if not parseable."""
    for line in stdout.splitlines():
        if line.startswith("Yosys "):
            return line.strip()
    return ""


def yosys_gate_count(
    rtl_path: Path | str,
    top_module: str,
    *,
    abc_script: str | None = None,
    timeout_sec: int = 300,
    log_dir: Path | str | None = None,
    dep_files: list[Path | str] | None = None,
) -> YosysGateCountResult:
    """Run yosys synth + ABC on the RTL, return verified gate count.

    Parameters
    ----------
    rtl_path:
        Path to a SystemVerilog or Verilog file. Must contain
        ``top_module``.
    top_module:
        Top-level module name. Passed to yosys ``hierarchy -check -top``.
    abc_script:
        Optional yosys script body that replaces the default
        ``synth -auto-top; abc -fast`` step. Caller MUST end with a
        ``stat`` command (we parse the count from stat output).
    timeout_sec:
        Wall-clock subprocess timeout. Default 300s. Larger blocks
        (e.g. async FIFO with deep state) may need 600+.
    log_dir:
        Where to write the yosys subprocess stdout/stderr capture.
        Default: ``$TMPDIR/kairos_yosys_<rtl_basename>_<pid>.log``.
        For cert tarballs, callers should pass the bundle's
        ``_sec_work/`` subdirectory so the log ships verbatim with the
        cert.
    dep_files:
        Optional list of additional RTL files containing sub-module
        dependencies. Required for multi-module bundles (ATH-1074)
        where ``rtl_path``'s top module instantiates sub-modules
        defined in sibling files. Yosys's ``hierarchy -check`` fails
        without them.

    Returns
    -------
    :class:`YosysGateCountResult` with gate count + log path.

    Raises
    ------
    :class:`YosysSynthError`
        On any of: missing yosys binary, subprocess timeout, nonzero
        exit, parse failure on yosys output.
    """
    rtl = Path(rtl_path).resolve()
    if not rtl.is_file():
        raise YosysSynthError(f"rtl_path not found: {rtl}")
    deps_resolved: list[Path] = []
    if dep_files:
        for dep in dep_files:
            dep_p = Path(dep).resolve()
            if not dep_p.is_file():
                raise YosysSynthError(f"dep_files entry not found: {dep_p}")
            deps_resolved.append(dep_p)

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        raise YosysSynthError(
            "yosys binary not found on $PATH. Install via apt "
            "('apt install yosys'), brew ('brew install yosys'), or "
            "from source (https://github.com/YosysHQ/yosys). The "
            "verified-gate-count cert flip per ATH-1061 ambition pin "
            "requires yosys; without it the cert ships claimed-only."
        )

    # Allocate log path
    if log_dir is not None:
        log_dir_p = Path(log_dir).resolve()
        log_dir_p.mkdir(parents=True, exist_ok=True)
    else:
        log_dir_p = Path(tempfile.gettempdir())
    log_path = log_dir_p / f"kairos_yosys_{rtl.stem}.log"

    script_body = _build_script(
        rtl, top_module, abc_script=abc_script,
        dep_files=deps_resolved or None,
    )

    start = time.monotonic()
    try:
        # No -q: that flag suppresses stat output along with info
        # messages, breaking the parser. Verbose output ships in the
        # log so customers can audit the full synth invocation.
        proc = subprocess.run(
            [yosys_bin, "-p", script_body],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise YosysSynthError(
            f"yosys timed out after {timeout_sec}s on {rtl} "
            f"(top_module={top_module!r}). Larger / deeper-state RTL "
            f"may need a higher timeout_sec value."
        ) from exc

    runtime_sec = time.monotonic() - start
    combined = proc.stdout + "\n--- STDERR ---\n" + proc.stderr
    log_path.write_text(combined)

    if proc.returncode != 0:
        raise YosysSynthError(
            f"yosys exited with code {proc.returncode} on {rtl} "
            f"(top_module={top_module!r}). Subprocess log captured at "
            f"{log_path}. Review the log for the specific error."
        )

    gate_count = parse_yosys_stat(proc.stdout)
    yosys_version = _extract_yosys_version(proc.stdout)

    return YosysGateCountResult(
        gate_count=gate_count,
        rtl_path=str(rtl),
        top_module=top_module,
        log_path=str(log_path),
        exit_code=proc.returncode,
        runtime_sec=runtime_sec,
        yosys_version=yosys_version,
    )
