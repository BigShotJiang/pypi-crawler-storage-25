"""Auto-capture hooks for kairos memory.

Inspired by agentmemory's passive capture pattern: key events
are recorded to knowledge_entries automatically, without agents
remembering to write them explicitly.

Hooks fire on:
- Optimization result (PROVED / REFUTED / synthesis floor)
- Adversarial finding (composition bug, phantom citation, etc.)
- Pain point filed

Uses the existing knowledge_entries table via the observe sink.
Zero new dependencies.

ATH-1173: content-hash tying, sanitization, retention policy.
"""
from __future__ import annotations

import hashlib
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RETENTION_DAYS_INCONCLUSIVE = 30


def _content_hash(rtl_path: str | None) -> str | None:
    """SHA256 of RTL file content. Ties memory to content, not name."""
    if not rtl_path:
        return None
    try:
        return hashlib.sha256(Path(rtl_path).read_bytes()).hexdigest()[:16]
    except Exception:  # noqa: BLE001
        return None


def _sanitize(text: str) -> str:
    """Strip prompt-injection patterns. Only for names/descriptions, NOT RTL content."""
    text = re.sub(r"[;\]\}\)\n].*", "", text)
    text = re.sub(r"(?i)(ignore|forget|disregard|override).*", "", text)
    return text[:200].strip()


def _is_permanent(outcome: str) -> bool:
    """PROVED and REFUTED are permanent. Everything else expires."""
    return outcome in ("proved", "refuted", "synthesis_floor")


def _infer_block_class(block_name: str) -> str:
    """Infer block class from name pattern."""
    low = block_name.lower()
    if any(k in low for k in ("hamming", "ecc", "parity", "crc", "secded")):
        return "ecc"
    if any(k in low for k in ("fifo", "queue", "buffer")):
        return "fifo"
    if any(k in low for k in ("alu", "adder", "mult", "arith")):
        return "alu"
    if any(k in low for k in ("arbiter", "grant", "priority")):
        return "arbiter"
    if any(k in low for k in ("fence", "spectre", "security")):
        return "security"
    if any(k in low for k in ("systolic", "mac", "pe_tile")):
        return "compute"
    if any(k in low for k in ("credit", "flow", "counter")):
        return "flow_control"
    return "generic"


def auto_capture_optimization_result(
    block_name: str,
    outcome: str,
    delta_pct: float | None = None,
    engine: str | None = None,
    run_id: str | None = None,
    agent_id: str = "unknown",
    rtl_path: str | None = None,
    org_id: str | None = None,
    block_class: str | None = None,
) -> dict[str, Any]:
    """Build a knowledge_entries record from an optimization result.

    Three scope tags:
    - scope:block — tied to content-hash, expires when RTL changes
    - scope:class — tied to block type (ecc/fifo/alu), persists across RTL changes
    - scope:global — universal lessons, never expires
    """
    safe_name = _sanitize(block_name)
    content_hash = _content_hash(rtl_path)
    inferred_class = block_class or _infer_block_class(block_name)

    if outcome == "proved" and delta_pct is not None:
        text = f"Optimization PROVED on {safe_name}: {delta_pct:+.1f}% area via {engine or 'unknown'}"
    elif outcome == "synthesis_floor":
        text = f"Block {safe_name} at synthesis floor — no optimization headroom"
    elif outcome == "refuted":
        text = f"Optimization REFUTED on {safe_name} — proposal not equivalent"
    else:
        text = f"Optimization {outcome} on {safe_name}"

    # Determine scope: block-specific results are scope:block,
    # class-level patterns (synthesis_floor on a class) are scope:class,
    # universal lessons are scope:global
    scope = "block"
    if outcome == "synthesis_floor":
        scope = "class"

    return {
        "text": text,
        "source": "kairos_auto_capture",
        "tags": [
            f"outcome:{outcome}",
            f"block:{safe_name}",
            f"agent:{agent_id}",
            f"scope:{scope}",
            f"class:{inferred_class}",
        ],
        "added_by": agent_id,
        "provenance": {
            "block_name": safe_name,
            "block_class": inferred_class,
            "scope": scope,
            "outcome": outcome,
            "delta_pct": delta_pct,
            "engine": engine,
            "run_id": run_id,
            "content_hash": content_hash,
            "org_id": org_id,
            "permanent": _is_permanent(outcome),
            "expires_at": None if _is_permanent(outcome) else (
                datetime.now(timezone.utc).isoformat()
            ),
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "auto",
        },
    }


def auto_capture_adversarial_finding(
    finding: str,
    severity: str = "medium",
    found_by: str = "unknown",
    fixed_commit: str | None = None,
) -> dict[str, Any]:
    """Build a knowledge_entries record from an adversarial review finding."""
    safe_finding = _sanitize(finding)
    return {
        "text": f"Adversarial finding ({severity}): {safe_finding}",
        "source": "kairos_auto_capture",
        "tags": ["adversarial_finding", f"severity:{severity}", f"agent:{found_by}"],
        "added_by": found_by,
        "provenance": {
            "finding": safe_finding,
            "severity": severity,
            "found_by": found_by,
            "fixed_commit": fixed_commit,
            "permanent": True,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "auto",
        },
    }


def auto_capture_pain_point(
    description: str,
    ticket_id: str | None = None,
    found_by: str = "unknown",
) -> dict[str, Any]:
    """Build a knowledge_entries record from a dogfood pain point."""
    safe_desc = _sanitize(description)
    return {
        "text": f"Pain point: {safe_desc}",
        "source": "kairos_auto_capture",
        "tags": ["pain_point", f"agent:{found_by}"],
        "added_by": found_by,
        "provenance": {
            "description": safe_desc,
            "ticket_id": ticket_id,
            "found_by": found_by,
            "permanent": True,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "auto",
        },
    }


def is_expired(record_provenance: dict[str, Any]) -> bool:
    """Check if a non-permanent record has expired (30-day TTL)."""
    if record_provenance.get("permanent", False):
        return False
    captured = record_provenance.get("captured_at")
    if not captured:
        return False
    try:
        captured_dt = datetime.fromisoformat(captured.replace("Z", "+00:00"))
        age_days = (datetime.now(timezone.utc) - captured_dt).days
        return age_days > RETENTION_DAYS_INCONCLUSIVE
    except Exception:  # noqa: BLE001
        return False


def auto_capture_aggregated_result(
    block_name: str,
    results: list[dict[str, Any]],
    agent_id: str = "unknown",
    rtl_path: str | None = None,
    org_id: str | None = None,
) -> dict[str, Any]:
    """Aggregate multiple results into one record per block.

    Instead of N separate entries, produces: "3 refutations, 1 proved on block X."
    Records transformation_class even on refutation (proposer debugging signal).
    """
    safe_name = _sanitize(block_name)
    content_hash = _content_hash(rtl_path)

    proved = [r for r in results if r.get("outcome") == "proved"]
    refuted = [r for r in results if r.get("outcome") == "refuted"]
    inconclusive = [r for r in results if r.get("outcome") not in ("proved", "refuted")]

    parts = []
    if proved:
        best = min(proved, key=lambda r: r.get("delta_pct", 0))
        parts.append(f"{len(proved)} proved (best {best.get('delta_pct', 0):+.1f}%)")
    if refuted:
        parts.append(f"{len(refuted)} refuted")
    if inconclusive:
        parts.append(f"{len(inconclusive)} inconclusive")

    text = f"Block {safe_name}: {', '.join(parts)}" if parts else f"Block {safe_name}: no results"

    transformation_classes = list(set(
        r.get("transformation_class", "unknown")
        for r in results if r.get("transformation_class")
    ))

    return {
        "text": text,
        "source": "kairos_auto_capture",
        "tags": [f"block:{safe_name}", f"agent:{agent_id}", "aggregated"],
        "added_by": agent_id,
        "provenance": {
            "block_name": safe_name,
            "n_proved": len(proved),
            "n_refuted": len(refuted),
            "n_inconclusive": len(inconclusive),
            "best_delta_pct": min((r.get("delta_pct", 0) for r in proved), default=None),
            "transformation_classes_attempted": transformation_classes,
            "content_hash": content_hash,
            "org_id": org_id,
            "permanent": len(proved) > 0 or len(refuted) > 0,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "aggregated",
        },
    }


def auto_capture_theorem_verified(
    theorem_name: str,
    module_path: str,
    gates_passed: list[str],
    result: str = "proved",
    agent_id: str = "unknown",
) -> dict[str, Any] | None:
    """Record a Lean theorem ONLY after three-gate verification.

    Dumb recorder — does not check vacuity itself. Listens for
    the three_gate_verified signal from the runner. Refuses to
    record if gates_passed does not include all 3 gates.
    """
    required_gates = {"compile", "vacuity", "review"}
    passed = set(gates_passed)
    if not required_gates.issubset(passed):
        return None

    safe_name = _sanitize(theorem_name)
    return {
        "text": f"Theorem VERIFIED (3-gate): {safe_name} in {module_path}",
        "source": "kairos_auto_capture",
        "tags": ["theorem_verified", f"agent:{agent_id}"],
        "added_by": agent_id,
        "provenance": {
            "theorem_name": safe_name,
            "module_path": module_path,
            "gates_passed": sorted(passed),
            "result": result,
            "permanent": True,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "three_gate_verified",
        },
    }


def dispute_memory(
    block_name: str,
    reason: str,
    disputed_by: str = "unknown",
    original_outcome: str | None = None,
) -> dict[str, Any]:
    """Dispute a memory entry (e.g., refutation from a flaky run).

    Does not delete — appends a dispute record. Consumer
    (format_for_proposer) sees both the original and the dispute,
    giving the proposer the full picture: "this was refuted but
    the refutation was disputed because [reason]."

    Prevents memory amplification from flaky entries.
    """
    safe_name = _sanitize(block_name)
    safe_reason = _sanitize(reason)
    return {
        "text": f"DISPUTED: {safe_name} — {safe_reason}",
        "source": "kairos_auto_capture",
        "tags": [f"block:{safe_name}", "disputed", f"agent:{disputed_by}"],
        "added_by": disputed_by,
        "provenance": {
            "block_name": safe_name,
            "dispute_reason": safe_reason,
            "original_outcome": original_outcome,
            "disputed_by": disputed_by,
            "permanent": True,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "capture_type": "dispute",
        },
    }


def write_to_knowledge_entries(record: dict[str, Any]) -> bool:
    """Write an auto-captured record to knowledge_entries via Supabase.

    Atomic dedup via ON CONFLICT on content_sha256 unique index.
    No race condition — the DB enforces uniqueness at the constraint
    level. Concurrent writes with the same hash: one wins, others
    silently skip.

    Returns True on success, False on failure (silent — auto-capture
    must never block the main flow).
    """
    import os
    try:
        url = os.environ.get("SUPABASE_URL") or os.environ.get("NEXT_PUBLIC_SUPABASE_URL")
        key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY") or os.environ.get("ATHANOR_SYNC_TOKEN")
        if not url or not key:
            return False

        import json
        import urllib.request

        content_sha = hashlib.sha256(
            json.dumps(record.get("text", "")).encode()
        ).hexdigest()
        record["content_sha256"] = content_sha

        req = urllib.request.Request(
            f"{url}/rest/v1/knowledge_entries?on_conflict=content_sha256",
            data=json.dumps(record).encode(),
            headers={
                "apikey": key,
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "Prefer": "return=minimal,resolution=ignore-duplicates",
            },
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
        return True
    except Exception:  # noqa: BLE001
        return False
