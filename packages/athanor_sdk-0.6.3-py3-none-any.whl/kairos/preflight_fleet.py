"""Fleet preflight — model reachability check before an expensive run.

Reads a task config, extracts every model string the run will invoke
(`phase_models` + any `--extra-model` passthroughs), and makes a 1-token
ping against each one. Retries transient Azure errors a few times before
declaring a model unreachable.

Why: the 5-model × 10-env heatmap runs and the solve/ multi-agent fleet
runs cost real money. An Azure deployment drift or rotated key can silently
burn a whole run before the first phase completes. This catches it in a
few seconds for pennies.

Port of athanor-builder/scripts/preflight_fleet.py (origin/main commit
8886260) with the solve/shared/env_keys.sh dependency removed — SDK users
set their own env vars. Gated behind the `multi-model` optional extra
because it imports litellm.

Usage from the CLI:
    athanor preflight --models path/to/task_config.json
    athanor preflight --models env_dir task_slug

Usage from Python:
    from kairos.preflight_fleet import check_fleet
    ok, report = check_fleet(task_config, extra_models=["anthropic/claude-sonnet-4-6"])
    if not ok:
        sys.exit(2)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path


# Providers we know how to probe. Each entry is a tuple of env var names;
# the check passes as long as AT LEAST ONE of them is set (any-of semantics)
# because litellm itself accepts multiple aliases for most providers.
_PROVIDER_ENV_KEYS: dict[str, tuple[str, ...]] = {
    "anthropic/": ("ANTHROPIC_API_KEY", "AZURE_AI_API_KEY", "ANTHROPIC_FOUNDRY_API_KEY", "AWS_ACCESS_KEY_ID"),
    "azure_ai/":  ("ANTHROPIC_API_KEY", "AZURE_AI_API_KEY", "ANTHROPIC_FOUNDRY_API_KEY"),
    "bedrock/":   ("AWS_ACCESS_KEY_ID",),
    "gemini/":    ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    "openai/":    ("OPENAI_API_KEY",),
    "azure/":     ("AZURE_API_KEY",),
}

_TRANSIENT_ERROR_CLASSES = frozenset({
    "NotFoundError",          # Azure deployment lookup flake
    "RateLimitError",         # transient 429 from concurrent capacity
    "APIError",               # generic upstream blip
    "InternalServerError",    # 500 from the upstream provider
    "ServiceUnavailableError",
    "Timeout",
    "APIConnectionError",
})


def load_task_config(arg1: str, arg2: str | None) -> tuple[dict, str]:
    """Accept either a direct config path or (env_dir, task_slug)."""
    p = Path(arg1)
    if p.suffix == ".json" and p.exists():
        return json.loads(p.read_text()), p.stem
    if arg2 is None:
        raise SystemExit(f"error: {arg1} is not a config file and no task slug given")
    env = Path(arg1)
    cfg_path = env / "root_data" / "eval" / "configs" / f"{arg2}.json"
    if not cfg_path.exists():
        raise SystemExit(f"error: config not found at {cfg_path}")
    return json.loads(cfg_path.read_text()), arg2


def extract_models(cfg: dict, extra: list[str] | None = None) -> list[str]:
    """Collect every model string the fleet run will invoke, de-duplicated."""
    models: list[str] = []
    if "phase_models" in cfg:
        for m in cfg["phase_models"] or []:
            if m and m not in models:
                models.append(m)
    for m in extra or []:
        if m and m not in models:
            models.append(m)
    return models


def _provider_families(models: list[str]) -> list[str]:
    """Return the distinct provider prefixes (e.g. 'gemini/', 'anthropic/')
    actually used by the models in this task. Used to decide which env-var
    families to check."""
    seen: list[str] = []
    for m in models:
        for prefix in _PROVIDER_ENV_KEYS:
            if m.startswith(prefix) and prefix not in seen:
                seen.append(prefix)
                break
    return seen


def _check_env(models: list[str]) -> list[str]:
    """Return a list of missing env-var groups for the providers in `models`.

    Each returned string describes one provider family whose required env
    vars are all unset — e.g. "GEMINI_API_KEY or GOOGLE_API_KEY". Returns []
    when every provider family the task uses has at least one key set.
    """
    missing: list[str] = []
    for prefix in _provider_families(models):
        keys = _PROVIDER_ENV_KEYS[prefix]
        if not any(os.environ.get(k) for k in keys):
            label = prefix.rstrip("/")
            if len(keys) == 1:
                missing.append(f"{label}: {keys[0]}")
            else:
                missing.append(f"{label}: one of ({', '.join(keys)})")
    return missing


def _one_call(model: str, timeout: int) -> tuple[bool, str, str | None]:
    """Model availability probe via get_client(). Returns (ok, message, error_class)."""
    try:
        from kairos.model_client.registry import get_client
    except ImportError:
        return False, "kairos model_client not available", "ImportError"

    try:
        client = get_client(model)
        resp = client.call(
            [
                {"role": "system", "content": "You are a model availability probe."},
                {"role": "user", "content": "Reply with exactly the word: ok"},
            ],
            max_tokens=4,
            timeout=timeout,
        )
        toks = resp.completion_tokens
        choices = [resp.assistant_turn()] if resp.assistant_turn() else []
        if not choices:
            return False, "empty choices in response", "EmptyResponse"
        content = (choices[0].message.content or "").strip()[:30] if hasattr(choices[0], "message") else ""
        return True, f"OK ({toks} tok, replied {content!r})", None
    except Exception as e:  # noqa: BLE001 — broad-catch fallback
        etype = type(e).__name__
        msg = str(e).split("\n")[0][:200]
        return False, f"{etype}: {msg}", etype


# Minimal dummy tool schema — the simplest shape litellm/openai tool-use
# accepts. We don't care whether the model *chooses* to call it; we only
# care that the tool-bearing request round-trips without being silently
# dropped by the provider routing.
_DUMMY_BASH_TOOL = {
    "type": "function",
    "function": {
        "name": "bash",
        "description": "Run a bash command in a sandboxed container.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The bash command to execute.",
                },
            },
            "required": ["command"],
        },
    },
}


def _tool_use_call(model: str, timeout: int) -> tuple[bool, str, str | None]:
    """Tool-use capability probe (ATH-235 #4, filed after ATH-248).

    A model is "reachable" to `_one_call` if it can complete a zero-tool
    4-token ping. That's necessary but not sufficient — several bug
    classes only show up on tool-bearing calls:

      - ATH-227: Azure deployment routes `anthropic/*` to the OpenAI-compat
        surface, which 200s with 0 tokens and 0 tool_calls.
      - ATH-248: the old `anthropic/* → azure_ai/*` rewrite hit that same
        OpenAI-compat surface even with an Anthropic passthrough endpoint,
        so tool_use requests came back empty at $0 cost.
      - Provider routing drops tools silently: some litellm providers
        accept the tools= kwarg, discard it, and return a text-only reply.
      - Reasoning budget too small: some models burn all their output
        tokens on hidden reasoning and emit 0 visible tokens on a tiny
        max_tokens call.

    Pass criteria: the call returns AT LEAST ONE of:
      - `completion_tokens > 0` (model produced visible output), OR
      - `tool_calls` list on the first choice (model invoked the tool).

    If both are zero, the provider routing is silently swallowing the
    request — same silent-failure class as ATH-227/ATH-248.
    """
    try:
        import litellm
    except ImportError:
        return False, "litellm not installed (pip install 'athanor-sdk[multi-model]')", "ImportError"

    try:
        litellm.suppress_debug_info = True
    except Exception:  # noqa: BLE001 — litellm.suppress_debug_info attribute may not exist on all versions
        pass

    # Floor of 2000 tokens so reasoning models (Kimi 2.6, o1,
    # deepseek-r1) have room to burn on hidden reasoning before
    # emitting the tool call. ATH-530 + 2026-04-23 Aidan dogfood
    # observation: Kimi 2.6 probe with max_tokens=128 returned
    # content=None because 70+ tokens went to reasoning_content
    # alone, never reaching the tool_call. Per-model cap still
    # honoured above the floor.
    try:
        from kairos.eval_harness import _max_tokens_for  # type: ignore
        budget = min(_max_tokens_for(model), 2000)
    except Exception:  # noqa: BLE001 — broad-catch fallback
        budget = 2000

    try:
        resp = litellm.completion(
            model=model,
            messages=[
                {"role": "system", "content": "You are a model availability probe. If asked, call the bash tool."},
                {"role": "user", "content": "Call the bash tool with command='echo ok'."},
            ],
            tools=[_DUMMY_BASH_TOOL],
            tool_choice="auto",
            max_tokens=budget,
            timeout=timeout,
        )
        usage = getattr(resp, "usage", None)
        toks = getattr(usage, "completion_tokens", 0) if usage else 0
        choices = getattr(resp, "choices", None) or []
        if not choices:
            return False, "tool-use probe: empty choices in response", "EmptyResponse"
        msg0 = getattr(choices[0], "message", None)
        tool_calls = getattr(msg0, "tool_calls", None) or []
        if toks == 0 and not tool_calls:
            # The ATH-227/ATH-248 silent-drop signature.
            return (
                False,
                "tool-use probe: 0 completion_tokens AND 0 tool_calls — "
                "provider silently dropped the tool-bearing request "
                "(ATH-227/ATH-248 class)",
                "SilentToolDrop",
            )
        shape = (
            f"tool_calls={len(tool_calls)}" if tool_calls else f"{toks} tok text"
        )
        return True, f"tool-use OK ({shape})", None
    except Exception as e:  # noqa: BLE001 — broad-catch fallback
        etype = type(e).__name__
        msg = str(e).split("\n")[0][:200]
        return False, f"tool-use probe {etype}: {msg}", etype


def ping_model(model: str, timeout: int = 30, retries: int = 2,
               retry_delay: float = 4.0, check_tool_use: bool = True) -> tuple[bool, str]:
    """Ping a model with retries on transient errors.

    Azure deployment lookups occasionally return NotFoundError or
    RateLimitError on a single call even when the deployment is healthy.
    Retry up to `retries` times with a short delay before declaring the
    model unreachable.

    When `check_tool_use=True` (default), ALSO runs `_tool_use_call` after
    a successful basic ping. A model that passes the reachability ping
    but fails the tool-use probe is worse than useless for solve/ runs —
    it'll burn the whole budget emitting empty responses. See
    `_tool_use_call` docstring for the bug classes this catches.

    Returns (ok, message) where ok=True only if at least one attempt came
    back with a real completion AND, if check_tool_use, the tool-use probe
    also succeeded. The message includes the attempt count when retries
    were used.
    """
    last_msg = "no attempts"
    for attempt in range(retries + 1):
        ok, msg, err_class = _one_call(model, timeout)
        if ok:
            base_msg = f"{msg} after {attempt + 1} attempts" if attempt > 0 else msg
            if not check_tool_use:
                return True, base_msg
            # Tool-use probe runs once — transient flakes on the reachability
            # ping have already been retried above; retrying the tool probe
            # on top would double the preflight cost for little signal.
            tool_ok, tool_msg, _tool_err = _tool_use_call(model, timeout)
            if tool_ok:
                return True, f"{base_msg}; {tool_msg}"
            return False, f"{base_msg} BUT {tool_msg}"
        last_msg = msg
        # Only retry on known-transient classes; permanent errors (auth,
        # 401, BadRequest) bail out immediately.
        if err_class not in _TRANSIENT_ERROR_CLASSES:
            return False, msg
        if attempt < retries:
            time.sleep(retry_delay)

    return False, f"{last_msg} (after {retries + 1} attempts)"


def check_fleet(cfg: dict, extra_models: list[str] | None = None,
                timeout: int = 30) -> tuple[bool, dict]:
    """Programmatic entry point — returns (all_green, report).

    `report` is a dict with keys: `models`, `missing_env`, `failed`, `passed`.
    """
    models = extract_models(cfg, extra_models)
    missing_env = _check_env(models)
    failed: list[tuple[str, str]] = []
    passed: list[tuple[str, str]] = []

    if missing_env:
        return False, {
            "models": models,
            "missing_env": missing_env,
            "failed": [],
            "passed": [],
        }

    for m in models:
        ok, msg = ping_model(m, timeout=timeout)
        if ok:
            passed.append((m, msg))
        else:
            failed.append((m, msg))

    return (len(failed) == 0), {
        "models": models,
        "missing_env": [],
        "failed": failed,
        "passed": passed,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", help="path/to/config.json OR env_dir")
    parser.add_argument("task_slug", nargs="?", help="task slug if env_dir given")
    parser.add_argument(
        "--extra-model",
        action="append",
        default=[],
        help="additional model string to ping (e.g. the --model arg of solve/run.sh)",
    )
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args(argv)

    cfg, slug = load_task_config(args.target, args.task_slug)
    models = extract_models(cfg, args.extra_model)

    if not models:
        print(f"[preflight] task {slug}: no models in phase_models; nothing to ping")
        return 0

    print(f"[preflight] task: {slug}")
    print(f"[preflight] checking {len(models)} model(s):")

    missing_env = _check_env(models)
    if missing_env:
        print(f"[preflight] FAIL: missing env vars: {missing_env}")
        print("[preflight] set the provider keys for the models in phase_models")
        return 2

    failed: list[tuple[str, str]] = []
    for m in models:
        ok, msg = ping_model(m, args.timeout, retries=2, retry_delay=4.0)
        mark = "  OK  " if ok else " FAIL "
        print(f"[preflight] {mark} {m:45s}  {msg}")
        if not ok:
            failed.append((m, msg))

    print()
    if failed:
        print(f"[preflight] RESULT: {len(failed)}/{len(models)} models unreachable")
        print("[preflight] DO NOT launch the fleet run until these are fixed:")
        for m, msg in failed:
            print(f"  - {m}")
            print(f"    -> {msg}")
        print()
        print("[preflight] Likely causes:")
        print("  1. Azure deployment name drift (check Azure portal for the")
        print("     exact deployment name, update task config phase_models)")
        print("  2. API key rotation")
        print("  3. Endpoint URL change (update *_API_BASE env vars)")
        return 2

    print(f"[preflight] RESULT: all {len(models)} models green. Safe to launch.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
