"""Exponential-backoff + model-fallback helper for kairos.model_client.

Per Aidan 2026-05-06 ts=1778082728 directive: when LLM calls hit
``overloaded_error`` / Azure rate-limits / transient 5xx, retry with
exponential backoff AND optionally fall back to alternate models. Print
a user-visible status line during stalls so customers see what's
happening rather than blocking silently.

Customer portability (Aidan 2026-05-06 follow-up): fallback model chain
is opt-in by kwarg or by ``KAIROS_LLM_FALLBACK_MODELS`` env var. Default
is **no fallback** — pure backoff retry on the primary model. Customers
who only have one model provider key (e.g. Anthropic-only) get clean
backoff behavior without the SDK assuming gemini/kimi/etc. keys are
present. Customers with multiple keys can opt in via env var
or constructor kwarg.

Usage::

    from kairos.model_client._backoff import call_with_backoff

    # Pure backoff (default, customer-portable)
    response = call_with_backoff(
        primary_model="anthropic/claude-opus-4-6",
        system_prompt=sys_msg,
        user_prompt=user_msg,
    )

    # Multi-provider fallback (opt-in)
    response = call_with_backoff(
        primary_model="anthropic/claude-opus-4-6",
        system_prompt=sys_msg,
        user_prompt=user_msg,
        fallback_models=("anthropic/claude-sonnet-4-6",),
    )

    # Env-driven fallback (KAIROS_LLM_FALLBACK_MODELS=`a,b,c`):
    response = call_with_backoff(
        primary_model="anthropic/claude-opus-4-6",
        system_prompt=sys_msg,
        user_prompt=user_msg,
    )  # picks up env-listed models if set, else no fallback

The helper:

1. Calls the primary model. If response.error matches a transient class
   (overloaded_error / rate_limit / 429 / 5xx), backs off with
   exponential delay (5s, 15s, 45s) and retries up to ``max_retries``
   times.
2. On exhausted retries, falls back to the next model in
   ``fallback_models`` and starts a fresh backoff loop.
3. On exhausted fallbacks, returns the last ModelResponse with
   ``error`` populated so the caller can surface it.
4. Prints a one-line status to stderr on each retry/fallback so the
   user knows the LLM is stalling, not their code.
"""
from __future__ import annotations

import os
import sys
import time
from typing import Iterable

from kairos.model_client.base import ModelResponse


def _resolve_fallback_models(
    explicit: Iterable[str] | None,
) -> tuple[str, ...]:
    """Resolve the fallback model chain.

    Priority:
    1. Explicit ``fallback_models`` kwarg (highest).
    2. ``KAIROS_LLM_FALLBACK_MODELS`` env var (comma-separated).
    3. Empty tuple (no fallback; pure-backoff on primary).

    Default is empty so customers without multi-provider keys get clean
    backoff behavior on the primary alone.
    """
    if explicit is not None:
        chain = tuple(explicit)
        if chain:
            return chain
    env = os.environ.get("KAIROS_LLM_FALLBACK_MODELS", "").strip()
    if env:
        return tuple(m.strip() for m in env.split(",") if m.strip())
    return ()


_TRANSIENT_PATTERNS = (
    "overloaded",
    "overloaded_error",
    "rate_limit",
    "rate-limit",
    "ratelimiterror",
    "429",
    "503",
    "504",
    "timeout",
    "timed out",
    "connection error",
    "connection reset",
    "service unavailable",
)


def _is_transient_error(err: str | None) -> bool:
    if not err:
        return False
    s = str(err).lower()
    return any(pat in s for pat in _TRANSIENT_PATTERNS)


def call_with_backoff(
    primary_model: str,
    *,
    system_prompt: str,
    user_prompt: str,
    timeout_sec: int = 120,
    max_retries_per_model: int = 3,
    backoff_seconds: tuple[int, ...] = (5, 15, 45),
    fallback_models: Iterable[str] | None = None,
    progress_stream=sys.stderr,
    tools: list[dict] | None = None,
) -> ModelResponse:
    """Call ``primary_model`` with exponential backoff on transient errors,
    falling back to ``fallback_models`` on persistent failure.

    Returns the first ``ModelResponse`` that succeeds, or the last
    ``ModelResponse`` with ``error`` populated if all models exhausted.
    Never raises (transient failures get retried; permanent failures
    populate response.error per the model_client contract).

    Parameters
    ----------
    primary_model:
        First model to try. Most-preferred. e.g. ``anthropic/claude-opus-4-6``.
    system_prompt:
        System message text. Sent as the system role.
    user_prompt:
        User message text. Sent as the user role.
    timeout_sec:
        Per-call timeout. Total wall-clock can be much higher with retries.
    max_retries_per_model:
        How many backoff retries per model before falling back. Default 3.
    backoff_seconds:
        Per-retry delay schedule. Length should match max_retries_per_model.
    fallback_models:
        Ordered list of fallback model ids. Tried in order on primary
        exhaustion. ``None`` (default) consults the
        ``KAIROS_LLM_FALLBACK_MODELS`` env var for a comma-separated
        list; empty tuple means no fallback. Customer-portable:
        default is no fallback so single-provider customers don't
        have to maintain unused keys.
    progress_stream:
        Where to print the user-visible status lines. Defaults to stderr.
    """
    from kairos.model_client import get_client

    resolved_fallbacks = _resolve_fallback_models(fallback_models)
    chain = [primary_model, *resolved_fallbacks]
    last_response: ModelResponse | None = None

    for model_idx, model_id in enumerate(chain):
        client = get_client(model_id)
        messages = client.format_messages(system_prompt, user_prompt)

        if model_idx > 0:
            print(
                f"[kairos.model_client] primary model {primary_model!r} "
                f"exhausted retries; falling back to {model_id!r}",
                file=progress_stream,
                flush=True,
            )

        for attempt in range(max_retries_per_model):
            try:
                response = client.call(messages=messages, timeout=timeout_sec, tools=tools)
            except Exception as e:  # noqa: BLE001
                # Provider raised; treat as transient if pattern matches.
                err_str = f"{type(e).__name__}: {e}"
                response = ModelResponse(
                    model=model_id, content="", tool_calls=[],
                    prompt_tokens=0, completion_tokens=0, error=err_str,
                )

            last_response = response
            if not response.error and (response.content or response.tool_calls):
                # Success.
                if attempt > 0 or model_idx > 0:
                    print(
                        f"[kairos.model_client] {model_id!r} succeeded "
                        f"on attempt {attempt + 1}/{max_retries_per_model}"
                        f"{' (after fallback)' if model_idx > 0 else ''}",
                        file=progress_stream,
                        flush=True,
                    )
                return response

            if not _is_transient_error(response.error):
                # Permanent error on this model — no backoff retry; try
                # next fallback if available.
                print(
                    f"[kairos.model_client] {model_id!r} permanent error: "
                    f"{response.error!r}; not retrying this model",
                    file=progress_stream,
                    flush=True,
                )
                break

            # Transient. Backoff and retry.
            if attempt < max_retries_per_model - 1:
                delay = backoff_seconds[
                    min(attempt, len(backoff_seconds) - 1)
                ]
                print(
                    f"[kairos.model_client] {model_id!r} hit transient error "
                    f"(attempt {attempt + 1}/{max_retries_per_model}): "
                    f"{response.error!r}; backing off {delay}s before retry",
                    file=progress_stream,
                    flush=True,
                )
                time.sleep(delay)
            else:
                print(
                    f"[kairos.model_client] {model_id!r} exhausted "
                    f"{max_retries_per_model} retries on transient errors",
                    file=progress_stream,
                    flush=True,
                )

    # All models exhausted. Return last response (which has .error set).
    if last_response is None:
        # Should not happen — chain is non-empty by construction.
        return ModelResponse(
            model="none", content="", tool_calls=[],
            prompt_tokens=0, completion_tokens=0,
            error="call_with_backoff: empty model chain",
        )
    return last_response
