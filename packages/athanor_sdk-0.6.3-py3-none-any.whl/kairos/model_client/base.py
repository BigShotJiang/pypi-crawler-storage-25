"""ModelClient base class + the data types every adapter speaks.

The agent loop never needs to know which provider is on the other end
of a `client.call()`. All provider-specific behavior is encapsulated
inside the concrete subclass.

Five things every adapter is responsible for:

1. `max_tokens_default` — per-model output budget cap. Reasoning models
   like gemini-3-flash-preview burn 3000-5000 tokens on internal reasoning
   per turn before emitting any visible output, so 8192 is too low.
2. `format_messages(system, user)` — initial messages in the format the
   provider accepts. Anthropic wraps content in blocks with
   `cache_control` for prompt caching; Gemini sends plain strings (because
   passing CachedContent + tools to Vertex 400s).
3. `call(messages, tools, max_tokens=None)` — the actual completion call.
   Wraps `litellm.completion` internally; subclass adds provider quirks.
4. `normalize_tool_call(tc)` — sanitize a tool_call before it goes back
   into the next-turn request. Default impl round-trips arguments
   through `json.loads(strict=False) → json.dumps()` so literal control
   characters (newlines, tabs) get escaped properly. Subclasses can
   override for additional native parsing (e.g. KimiClient reparses the
   `<|tool_call_begin|>` text format).
5. `min_tokens_for_reasoning` — minimum max_tokens budget below which
   the model is likely to silently fail. Defaults to 0; reasoning models
   override to a real number.

Why this is a class hierarchy and not a flat function dict: each concern
is per-provider and per-model variant, and we want subclassing for the
common case (every Anthropic model shares cache_control behavior; only
the model_id and max_tokens differ). A flat dispatcher would re-implement
the same overrides for every model.
"""
from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable


class BACKEND(str, Enum):
    """How a provider is routed.

    DIRECT      — provider's native API (Anthropic, Google AI Studio, OpenAI)
    BEDROCK     — AWS Bedrock (Anthropic models, Llama, Titan)
    AZURE       — Azure OpenAI / Azure AI Foundry (covers our hosted Sonnet,
                  Opus, Kimi, Mistral)
    VERTEX_AI   — Google Cloud Vertex AI service-account auth
    OPENROUTER  — Routed via OpenRouter
    """
    DIRECT = "direct"
    BEDROCK = "bedrock"
    AZURE = "azure"
    VERTEX_AI = "vertex_ai"
    OPENROUTER = "openrouter"


class ProviderError(RuntimeError):
    """Raised when a provider call fails in a way the adapter can identify
    as a permanent issue (auth, model not found, malformed request).
    Transient errors (429, 5xx, timeouts) are NOT raised here — those go
    through the retry loop in `call_with_retries`.
    """
    def __init__(self, model: str, kind: str, message: str):
        self.model = model
        self.kind = kind
        super().__init__(f"[{model} / {kind}] {message}")


@dataclass
class ModelResponse:
    """Provider-agnostic result of a single `client.call(...)`.

    Subclasses populate this from the underlying `litellm.completion`
    response object. The agent loop never touches the raw response.
    """
    model: str
    content: str | None
    tool_calls: list[dict]
    prompt_tokens: int
    completion_tokens: int
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    reasoning_tokens: int = 0
    reasoning_content: str | None = None
    finish_reason: str | None = None
    error: str | None = None
    raw: Any = None  # optional for debugging, do NOT serialize this

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def assistant_turn(self) -> dict:
        """Return this response as an assistant message dict suitable for
        feeding back into the next turn's messages list."""
        msg: dict[str, Any] = {"role": "assistant"}
        if self.content is not None:
            msg["content"] = self.content
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        return msg


def _mask_key(key: str | None) -> str:
    """Redact all but last 4 chars of an API key for safe display."""
    if not key:
        return "None"
    if len(key) <= 8:
        return "****"
    return key[:4] + "****" + key[-4:]


@dataclass(repr=False)
class ProviderConfig:
    """Per-provider credentials + endpoint config.

    Adapters look up their backend config from a `ProviderConfig`
    instance instead of doing scattered `os.environ.get()` calls. The
    config is passed in at construction time (via `Registry.get(...,
    config=...)`) so tests can inject values without monkeypatching
    `os.environ`. The `from_env()` classmethod is the convenience
    factory the registry uses by default for production code.
    """
    api_key: str | None = None
    api_base: str | None = None
    region: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"ProviderConfig(api_key={_mask_key(self.api_key)!r}, "
            f"api_base={self.api_base!r}, region={self.region!r})"
        )

    def safe_dict(self) -> dict[str, Any]:
        """Serialization-safe dict with api_key masked. Use instead of __dict__."""
        return {
            "api_key": _mask_key(self.api_key),
            "api_base": self.api_base,
            "region": self.region,
        }

    @classmethod
    def from_env(cls, prefix: str) -> "ProviderConfig":
        """Build from env vars like `<PREFIX>_API_KEY`, `<PREFIX>_API_BASE`,
        `<PREFIX>_REGION`. Missing keys stay None.
        """
        return cls(
            api_key=os.environ.get(f"{prefix}_API_KEY"),
            api_base=os.environ.get(f"{prefix}_API_BASE"),
            region=os.environ.get(f"{prefix}_REGION"),
        )


def sanitize_tool_call_args(args_str: str) -> str:
    """Round-trip a tool-call argument string through strict JSON.

    Some providers (Kimi K2.5 most reliably, occasionally others) emit
    literal newlines / tabs / other control characters inside JSON string
    values when writing multi-line file contents via an
    `edit_file({"content": "<newlines>"})` tool call. The OpenAI client's
    strict JSON validator rejects raw control chars in strings, so when
    the tool-call message goes back as the assistant turn on the NEXT
    request, it 400s with:
        "unexpected control character in string: line 1 column N"

    Fix: parse with strict=False (which allows raw control chars on
    input) and re-dump with strict JSON encoding (which converts literal
    \\n / \\t / \\x?? in strings into proper escape sequences). Falls
    back to the original string if parsing fails entirely — better to
    send through and let the next-turn parse error surface than silently
    drop the tool call.

    See ATH-231 for the bug history. Available as a top-level helper so
    adapters that don't subclass `_normalize_tool_call_default` can still
    call it directly.
    """
    if not args_str:
        return args_str
    try:
        return json.dumps(json.loads(args_str, strict=False))
    except (ValueError, json.JSONDecodeError):
        return args_str


class ModelClient(ABC):
    """Provider-agnostic interface every model adapter implements.

    Subclasses MUST set `model_id`, `provider`, `max_tokens_default`,
    and override `format_messages` and `call`.
    """

    # ── Class-level overridables ───────────────────────────────────────
    provider: str = ""
    backend: BACKEND = BACKEND.DIRECT

    # Per-model output budget cap. Reasoning models override to a wider
    # value because they burn tokens on internal reasoning before emitting
    # any visible content. See ATH-231.
    max_tokens_default: int = 16_384

    # Minimum max_tokens budget below which the model is likely to
    # silently return 0 visible tokens. Override to a non-zero value for
    # reasoning models. Used by call() to refuse a too-small request and
    # by contract tests to verify there's no silent-fail mode.
    min_tokens_for_reasoning: int = 0

    def __init__(self, model_id: str, config: ProviderConfig | None = None):
        self.model_id = model_id
        self.config = config or ProviderConfig()

    def __repr__(self) -> str:
        return f"<{type(self).__name__} model_id={self.model_id!r} backend={self.backend.value}>"

    # ── Required overrides ────────────────────────────────────────────
    @abstractmethod
    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        """Build the initial system + user messages for a fresh phase.

        Anthropic adapters wrap content in blocks with `cache_control`;
        Gemini and OpenAI adapters return plain strings (passing
        cache_control to Vertex 400s with 'CachedContent + tools').
        """
        ...

    @abstractmethod
    def call(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        """Make one completion call and return the normalized response.

        Subclasses wrap `litellm.completion` (or the native provider SDK)
        and translate the raw response into a `ModelResponse`. Tool calls
        are normalized via `normalize_tool_call`. Permanent errors raise
        ProviderError; transient ones populate `response.error` and
        leave it to the caller's retry policy.

        `temperature` and `top_p` are forwarded to the provider when
        non-None. Required for sampling workloads (pass@N evals, greedy
        vs stochastic ablations, temperature sweeps). Default None means
        "use provider default" (typically 1.0 for temperature).
        """
        ...

    # ── Default implementations (subclass may override) ───────────────
    def normalize_tool_call(self, tc: dict) -> dict:
        """Sanitize a tool_call dict before it goes back into a next-turn
        message. Default: round-trip arguments through strict JSON to
        escape control chars.

        Subclasses can override for additional native parsing — e.g.
        KimiClient reparses the `<|tool_call_begin|>` text format that
        Kimi sometimes emits in `content` instead of in `tool_calls`.
        """
        out = dict(tc)
        fn = out.get("function")
        if isinstance(fn, dict) and isinstance(fn.get("arguments"), str):
            fn = dict(fn)
            fn["arguments"] = sanitize_tool_call_args(fn["arguments"])
            out["function"] = fn
        return out

    def normalize_tool_calls(self, tcs: Iterable[dict]) -> list[dict]:
        return [self.normalize_tool_call(tc) for tc in (tcs or [])]

    def effective_max_tokens(self, requested: int | None) -> int:
        """Resolve the max_tokens value for an outgoing call.

        - If the caller passed an explicit value, use it.
        - If the value is below `min_tokens_for_reasoning`, clamp UP and
          log a warning so the caller can fix it at the source.
        - If the caller passed None, return `max_tokens_default`.

        We log instead of raising because the old eval_harness call site
        passed `max_tokens=8192` blindly to every model. Raising would
        convert silent-failure-then into loud-crash-now, which is worse
        during the V2 rollout window. After V2 lands and callers stop
        passing fixed values, we can promote the warning to a raise.
        """
        if requested is None:
            return self.max_tokens_default
        if self.min_tokens_for_reasoning and requested < self.min_tokens_for_reasoning:
            import logging
            logging.warning(
                "%s: clamping max_tokens from %d up to %d "
                "(min_tokens_for_reasoning); set it explicitly to silence this",
                self.model_id, requested, self.min_tokens_for_reasoning,
            )
            return self.min_tokens_for_reasoning
        return requested
