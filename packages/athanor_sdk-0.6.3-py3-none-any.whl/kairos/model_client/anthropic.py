"""Anthropic Claude adapter (direct, Bedrock, Azure variants).

Anthropic-specific behavior:
- system + user content blocks get `cache_control: {type: ephemeral}`
  for prompt caching (cuts our cost ~3-5x on repeated agent loops)
- Azure backend rewrites the model id `anthropic/claude-X` to
  `azure_ai/claude-X` and supplies the Azure base URL + key explicitly
- Bedrock backend rewrites to `bedrock/anthropic.claude-X` and supplies
  region

Provider migration:
    AnthropicClient(model_id="claude-sonnet-4-6", backend=BACKEND.AZURE,
                    config=ProviderConfig(api_base=..., api_key=...))
    # Tomorrow:
    AnthropicClient(model_id="claude-sonnet-4-6", backend=BACKEND.BEDROCK,
                    config=ProviderConfig(region="us-west-2"))
"""
from __future__ import annotations

from typing import Any

from .base import BACKEND, ModelClient, ModelResponse, ProviderConfig, ProviderError


# Reasoning Anthropic models burn extended-thinking tokens; we don't use
# those in the agent loop yet, so 16k is fine for current Sonnet/Opus.
_DEFAULT_MAX_TOKENS = 16_384


class AnthropicClient(ModelClient):
    """Anthropic Claude family. Backends: direct, azure, bedrock."""

    provider = "anthropic"
    max_tokens_default = _DEFAULT_MAX_TOKENS

    def __init__(
        self,
        model_id: str,
        backend: BACKEND = BACKEND.DIRECT,
        config: ProviderConfig | None = None,
    ):
        super().__init__(model_id=model_id, config=config)
        self.backend = backend

    # ── Provider-specific routing ─────────────────────────────────────
    def _resolved_call_kwargs(self) -> dict[str, Any]:
        """Build the kwargs for the underlying litellm call based on
        backend. Each backend's translation lives here, NOT in the agent
        loop.
        """
        if self.backend == BACKEND.DIRECT:
            kwargs: dict[str, Any] = {"model": self.model_id}
            if self.config.api_key:
                kwargs["api_key"] = self.config.api_key
            return kwargs

        if self.backend == BACKEND.AZURE:
            base = (self.config.api_base or "").rstrip("/")
            api_base = base + "/v1" if base and not base.endswith("/v1") else base
            bare = self.model_id.split("/", 1)[-1]
            return {
                "model": f"azure_ai/{bare}",
                "api_base": api_base or None,
                "api_key": self.config.api_key,
            }

        if self.backend == BACKEND.BEDROCK:
            bare = self.model_id.split("/", 1)[-1]
            if bare.startswith("us.anthropic.") or bare.startswith("eu.anthropic."):
                kwargs = {"model": f"bedrock/{bare}"}
            else:
                kwargs = {"model": f"bedrock/anthropic.{bare}-v1:0"}
            if self.config.region:
                kwargs["aws_region_name"] = self.config.region
            if self.config.extra.get("aws_session_token"):
                kwargs["aws_session_token"] = self.config.extra["aws_session_token"]
            return kwargs

        raise ProviderError(self.model_id, "config",
                            f"unsupported backend: {self.backend}")

    # ── Required overrides ────────────────────────────────────────────
    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        """Wrap system + user in content blocks with ephemeral cache hints.

        Bedrock does not support prompt caching (cache_control fields cause
        ValidationException), so we strip them for the bedrock backend.
        Direct and Azure backends keep caching for the ~3-5x cost cut.
        """
        if self.backend == BACKEND.BEDROCK:
            return [
                {"role": "system", "content": [
                    {"type": "text", "text": system_prompt},
                ]},
                {"role": "user", "content": [
                    {"type": "text", "text": user_prompt},
                ]},
            ]
        return [
            {"role": "system", "content": [
                {"type": "text", "text": system_prompt,
                 "cache_control": {"type": "ephemeral"}},
            ]},
            {"role": "user", "content": [
                {"type": "text", "text": user_prompt,
                 "cache_control": {"type": "ephemeral"}},
            ]},
        ]

    def call(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        try:
            import litellm
        except ImportError as e:
            raise ProviderError(self.model_id, "import",
                                "litellm not installed; pip install athanor-sdk[multi-model]") from e

        kwargs = self._resolved_call_kwargs()
        kwargs.update({
            "messages": messages,
            "max_tokens": self.effective_max_tokens(max_tokens),
            "timeout": timeout,
        })
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if top_p is not None:
            kwargs["top_p"] = top_p

        try:
            r = litellm.completion(**kwargs)
        except Exception as e:
            err_name = type(e).__name__
            err_str = str(e)
            if err_name == "NotFoundError" or "is not found" in err_str or "model_not_found" in err_str:
                from kairos.errors import UnknownModelError
                raise UnknownModelError(
                    model_id=self.model_id,
                    provider="anthropic",
                ) from e
            if self.backend == BACKEND.BEDROCK and (
                "AccessDeniedException" in err_str
                or "UnrecognizedClientException" in err_str
                or "ExpiredTokenException" in err_str
            ):
                hint = ""
                if "ExpiredToken" in err_str:
                    hint = " (AWS session token expired; refresh with `aws sts get-session-token`)"
                elif "AccessDenied" in err_str:
                    hint = " (check IAM policy allows bedrock:InvokeModel)"
                return ModelResponse(
                    model=self.model_id,
                    content=None, tool_calls=[],
                    prompt_tokens=0, completion_tokens=0,
                    error=f"Bedrock auth error{hint}: {err_str[:250]}",
                )
            return ModelResponse(
                model=self.model_id,
                content=None, tool_calls=[],
                prompt_tokens=0, completion_tokens=0,
                error=f"{err_name}: {err_str[:300]}",
            )

        choice = r.choices[0]
        msg = choice.message
        usage = getattr(r, "usage", None)

        return ModelResponse(
            model=self.model_id,
            content=getattr(msg, "content", None),
            tool_calls=self.normalize_tool_calls(
                _model_dump_tool_calls(getattr(msg, "tool_calls", None))
            ),
            prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
            cache_creation_tokens=getattr(usage, "cache_creation_input_tokens", 0) or 0,
            cache_read_tokens=getattr(usage, "cache_read_input_tokens", 0) or 0,
            finish_reason=getattr(choice, "finish_reason", None),
            raw=r,
        )


def _model_dump_tool_calls(tcs: Any) -> list[dict]:
    """Convert litellm's tool_calls (pydantic objects) into plain dicts
    so they survive being put in a message list and serialized to JSON.
    """
    if not tcs:
        return []
    out = []
    for tc in tcs:
        if hasattr(tc, "model_dump"):
            out.append(tc.model_dump())
        elif hasattr(tc, "dict"):
            out.append(tc.dict())
        elif isinstance(tc, dict):
            out.append(dict(tc))
        else:
            # Best-effort manual extraction
            fn = getattr(tc, "function", None)
            out.append({
                "id": getattr(tc, "id", None),
                "type": getattr(tc, "type", "function"),
                "function": {
                    "name": getattr(fn, "name", None),
                    "arguments": getattr(fn, "arguments", "{}"),
                } if fn else {},
            })
    return out
