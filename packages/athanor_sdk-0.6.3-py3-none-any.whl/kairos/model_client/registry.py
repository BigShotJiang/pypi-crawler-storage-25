"""Registry + factory for ModelClient adapters.

Resolves a model_id like `anthropic/claude-sonnet-4-6` or
`gemini/gemini-3-flash-preview` to the right ModelClient subclass and
backend.

Test-friendly by construction:
- `get_client(model_id, *, backend=None, config=None)` accepts an
  optional `ProviderConfig`. When omitted, the factory falls back to
  `ProviderConfig.from_env(prefix)` lazily — so tests can pass a fake
  config without monkeypatching `os.environ`, and production callers
  get the convenient default.
- `Registry` is a plain dataclass: tests can construct their own with
  custom routes and never touch the module-level `default_registry`.

Default routing (matches what's on the gpu-agent VM today):
- anthropic/* and claude-* → AnthropicClient
  (Azure backend if AZURE_AI_API_BASE points at an azure host, else direct)
- gemini/* → GeminiClient direct via GEMINI_API_KEY
- openai/kimi-* → KimiClient on Azure OpenAI-compat endpoint
- openai/mistral-* → MistralClient same Azure endpoint
- openai/gpt-* → GPTClient direct via api.openai.com
- openai/o* (o1, o3, o4) → GPTClient direct
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Callable

from .anthropic import AnthropicClient
from .base import BACKEND, ModelClient, ProviderConfig
from .gemini import GeminiClient
from .openai_compat import GPTClient, KimiClient, MistralClient


# A factory takes (model_id, backend, config) and returns a concrete
# ModelClient. backend + config can be None — the factory chooses
# sensible defaults from env when they are.
ClientFactory = Callable[[str, "BACKEND | None", "ProviderConfig | None"], ModelClient]


# ── Per-provider factories ────────────────────────────────────────────


def _anthropic_factory(
    model_id: str, backend: BACKEND | None, config: ProviderConfig | None
) -> ModelClient:
    """anthropic/* → Anthropic Claude on one of three backends.

    Customer-facing routing supports all three Anthropic-Claude paths so
    customers can pick whichever auth surface they already have wired up:

    1. *Direct Anthropic API.* `api.anthropic.com` via an `sk-ant-...`
       key. Set `ANTHROPIC_API_KEY` (no base URL, or a base URL not
       containing "azure"); leave `KAIROS_ANTHROPIC_BACKEND` unset.

    2. *Azure-hosted Claude.* Azure AI Foundry / Azure AI Inference
       endpoint serving Sonnet / Opus. Set `ANTHROPIC_API_KEY` (the
       Azure-tenant key) + `ANTHROPIC_BASE_URL` or `AZURE_AI_API_BASE`
       to a URL containing "azure"; auto-detected. Or force with
       `KAIROS_ANTHROPIC_BACKEND=azure`.

    3. *AWS Bedrock.* Anthropic Claude via Bedrock. Set
       `KAIROS_ANTHROPIC_BACKEND=bedrock` (since Bedrock has no
       Anthropic-shaped env hint we can sniff) plus the standard AWS
       env: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`,
       `AWS_REGION` / `AWS_BEDROCK_REGION`. The factory plumbs the
       region into `ProviderConfig.region` so the client's Bedrock
       branch can pass `aws_region_name` through litellm.

    Backend resolution precedence:
        explicit `backend` arg  >  KAIROS_ANTHROPIC_BACKEND env  >
        auto-detect (azure if base contains "azure", else direct)
    """
    # Lazy env reads — at call time, not import time, so tests that
    # don't pass config don't accidentally inherit state.
    if config is None:
        # ANTHROPIC_BASE_URL and AZURE_AI_API_BASE are for Claude.
        # LITELLM_API_BASE is for OpenAI-compatible models (Kimi, Mistral)
        # and must NOT be used as a Claude fallback — different Azure
        # resources with different model deployments.
        base = (
            os.environ.get("ANTHROPIC_BASE_URL")
            or os.environ.get("AZURE_AI_API_BASE")
        )
        key = (
            os.environ.get("ANTHROPIC_API_KEY")
            or os.environ.get("AZURE_AI_API_KEY")
            or os.environ.get("ANTHROPIC_FOUNDRY_API_KEY")
        )
        region = (
            os.environ.get("AWS_BEDROCK_REGION")
            or os.environ.get("AWS_REGION")
            or os.environ.get("AWS_DEFAULT_REGION")
        )
        session_token = os.environ.get("AWS_SESSION_TOKEN")
        extra: dict[str, str] = {}
        if session_token:
            extra["aws_session_token"] = session_token
        config = ProviderConfig(api_base=base, api_key=key, region=region, extra=extra)
    if backend is None:
        env_choice = os.environ.get("KAIROS_ANTHROPIC_BACKEND", "").strip().lower()
        if env_choice == "bedrock":
            backend = BACKEND.BEDROCK
        elif env_choice == "azure":
            backend = BACKEND.AZURE
        elif env_choice == "direct":
            backend = BACKEND.DIRECT
        elif config.api_base and "azure" in config.api_base:
            backend = BACKEND.AZURE
        elif (
            not config.api_key
            and os.environ.get("AWS_ACCESS_KEY_ID")
            and os.environ.get("AWS_SECRET_ACCESS_KEY")
        ):
            backend = BACKEND.BEDROCK
        else:
            backend = BACKEND.DIRECT
    return AnthropicClient(model_id=model_id, backend=backend, config=config)


def _gemini_factory(
    model_id: str, backend: BACKEND | None, config: ProviderConfig | None
) -> ModelClient:
    """gemini/* → Google AI Studio direct via GEMINI_API_KEY."""
    if config is None:
        config = ProviderConfig(
            api_key=os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"),
        )
    return GeminiClient(model_id=model_id, backend=backend or BACKEND.DIRECT, config=config)


def _kimi_factory(
    model_id: str, backend: BACKEND | None, config: ProviderConfig | None
) -> ModelClient:
    """openai/kimi-* → Azure OpenAI-compat endpoint."""
    if config is None:
        config = ProviderConfig(
            api_base=os.environ.get("OPENAI_API_BASE"),
            api_key=os.environ.get("OPENAI_API_KEY"),
        )
    return KimiClient(model_id=model_id, backend=backend or BACKEND.AZURE, config=config)


def _mistral_factory(
    model_id: str, backend: BACKEND | None, config: ProviderConfig | None
) -> ModelClient:
    """openai/mistral-* → Azure OpenAI-compat endpoint (same as Kimi)."""
    if config is None:
        config = ProviderConfig(
            api_base=os.environ.get("OPENAI_API_BASE"),
            api_key=os.environ.get("OPENAI_API_KEY"),
        )
    return MistralClient(model_id=model_id, backend=backend or BACKEND.AZURE, config=config)


def _gpt_factory(
    model_id: str, backend: BACKEND | None, config: ProviderConfig | None
) -> ModelClient:
    """openai/gpt-* and openai/o* → api.openai.com direct."""
    if config is None:
        config = ProviderConfig(api_key=os.environ.get("OPENAI_API_KEY"))
    return GPTClient(model_id=model_id, backend=backend or BACKEND.DIRECT, config=config)


# Prefix → factory routing. Order matters (more specific first).
_DEFAULT_PREFIX_RULES: list[tuple[str, ClientFactory]] = [
    ("anthropic/", _anthropic_factory),
    ("claude-", _anthropic_factory),
    ("gemini/", _gemini_factory),
    ("openai/kimi", _kimi_factory),
    ("openai/mistral", _mistral_factory),
    ("openai/gpt", _gpt_factory),
    ("openai/o", _gpt_factory),  # o1, o3, o4
]


@dataclass
class Registry:
    """Mutable map model_id_prefix → factory. Tests can construct their
    own Registry and override the default routing or supply explicit
    overrides for individual model_ids."""
    prefix_rules: list[tuple[str, ClientFactory]] = field(
        default_factory=lambda: list(_DEFAULT_PREFIX_RULES)
    )
    explicit: dict[str, ClientFactory] = field(default_factory=dict)

    def register(self, model_id: str, factory: ClientFactory) -> None:
        self.explicit[model_id] = factory

    def get(
        self,
        model_id: str,
        *,
        backend: BACKEND | None = None,
        config: ProviderConfig | None = None,
    ) -> ModelClient:
        if model_id in self.explicit:
            return self.explicit[model_id](model_id, backend, config)
        for prefix, factory in self.prefix_rules:
            if model_id.startswith(prefix):
                return factory(model_id, backend, config)
        # Typo guard: if the model string looks like a misspelling of a
        # known prefix (Levenshtein ≤ 2), raise UnknownModelError with the
        # suggestion. Catches "anthropc/..." before litellm gives a cryptic error.
        suggestion = _closest_prefix(model_id, self.prefix_rules)
        if suggestion and _looks_like_typo(model_id, suggestion):
            from kairos.errors import UnknownModelError
            raise UnknownModelError(model_id=model_id, suggestion=suggestion)
        # Aidan 2026-05-13: customers bring ANY model. Fall through to
        # litellm passthrough — it supports 100+ providers natively.
        from kairos.model_client.passthrough import LiteLLMPassthroughClient
        return LiteLLMPassthroughClient(model_id=model_id, config=config)


def _closest_prefix(model_id: str, rules: list[tuple[str, ClientFactory]]) -> str | None:
    """Heuristic: find the rule prefix with the longest shared start."""
    best, best_len = None, 0
    for prefix, _ in rules:
        n = 0
        for a, b in zip(model_id, prefix):
            if a == b:
                n += 1
            else:
                break
        if n > best_len and n >= 3:
            best_len = n
            best = prefix
    return best


def _looks_like_typo(model_id: str, prefix: str) -> bool:
    """True if model_id's provider portion is within edit distance 2 of prefix."""
    provider = model_id.split("/")[0] + "/" if "/" in model_id else model_id
    target = prefix.rstrip("/") + "/" if not prefix.endswith("/") else prefix
    return _edit_distance(provider.lower(), target.lower()) <= 2


def _edit_distance(a: str, b: str) -> int:
    """Levenshtein distance, bounded at 3 (early exit for performance)."""
    if abs(len(a) - len(b)) > 2:
        return 3
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1] + [0] * len(b)
        for j, cb in enumerate(b):
            curr[j + 1] = min(
                prev[j + 1] + 1,
                curr[j] + 1,
                prev[j] + (0 if ca == cb else 1),
            )
        prev = curr
    return prev[-1]


# Module-level default registry. Most callers use this via get_client().
default_registry = Registry()


def get_client(
    model_id: str,
    *,
    backend: BACKEND | None = None,
    config: ProviderConfig | None = None,
) -> ModelClient:
    """Top-level factory. Resolves a model_id through the default registry.

    ATH-1180: Internal fleet calls (KAIROS_AGENT_ID set) route through
    ClaudeSubagentClient by default — zero API key, uses session OAuth.
    Customer calls route through the standard registry (Bedrock/litellm).

    Args:
        model_id: provider-prefixed model id, e.g. "anthropic/claude-sonnet-4-6"
        backend:  optional backend override (DIRECT/AZURE/BEDROCK/VERTEX_AI)
        config:   optional ProviderConfig. If omitted, factory builds one
                  from env vars at call time.

    Tests can pass `config=ProviderConfig(api_key="fake", api_base="https://...")`
    without monkeypatching `os.environ`.
    """
    import os
    if os.environ.get("KAIROS_AGENT_ID") and backend is None and config is None:
        try:
            from kairos.model_client.claude_subagent import ClaudeSubagentClient
            return ClaudeSubagentClient(model_id=model_id)
        except (ImportError, ModuleNotFoundError):
            pass  # Fall through to standard registry
    return default_registry.get(model_id, backend=backend, config=config)


def register(model_id: str, factory: ClientFactory) -> None:
    """Register an explicit override for one model_id on the default registry."""
    default_registry.register(model_id, factory)


# Useful for parametrized contract tests.
ALL_REGISTERED = (
    "anthropic/claude-sonnet-4-6",
    "anthropic/claude-opus-4-6",
    "anthropic/claude-opus-4-7",
    "anthropic/claude-haiku-4-5",
    "gemini/gemini-2.5-flash",
    "gemini/gemini-3-flash-preview",
    "gemini/gemini-3.1-pro-preview",
    "openai/kimi-k2.5",
    "openai/mistral-large-3",
    "openai/gpt-4o",
)
