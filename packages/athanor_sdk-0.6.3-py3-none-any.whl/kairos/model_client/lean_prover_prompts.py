"""Lean prover model registry + autocomplete-prompt routing.

Lean prover models (DeepSeek-Prover-V2 family, mathlib-tuned LLaMa
variants, future Aristotle-completion models) are *completion* models
trained on Lean theorem-proof autocompletion. They expect prompts in the
form

    {imports}\n\n{theorem_header} := <model continues>

and silently fail with chat-style instruction prompts ("Close this Lean
4 theorem with a clean proof…") — the failure mode is space-stripped
tokenizer output (`:=byintros;introx` instead of `:= by intros; intro x`)
that fails every `lake build`. This module gives the SDK a registry of
known Lean prover model identifiers and a `render_lean_prompt` helper
that auto-routes them to the correct autocomplete format.

Filed as ATH-717 by research after a 2-hour customer-side debug.

Default behaviour: unknown models are treated as `ModelFamily.CHAT`,
which matches the existing chat-style completion API used by Sonnet,
Kimi, Gemini, Mistral, and Opus. Only models registered as
`LEAN_COMPLETION` get the autocomplete-prompt rewrite. Add new prover
identifiers to `LEAN_COMPLETION_MODELS` as they ship.
"""
from __future__ import annotations

import warnings
from enum import Enum


class ModelFamily(str, Enum):
    """Coarse model-family classification used by Lean prompt routing."""
    LEAN_COMPLETION = "lean_completion"
    CHAT = "chat"


# Known Lean prover model identifiers. Stored as a set for O(1) membership
# but iterated as substrings in `detect_family` so subtle wrapper-prefixes
# (e.g. `openai/deepseek-ai/DeepSeek-Prover-V2-7B`) still resolve correctly.
LEAN_COMPLETION_MODELS: frozenset[str] = frozenset({
    "deepseek-ai/DeepSeek-Prover-V2-7B",
    "deepseek-ai/DeepSeek-Prover-V2-7B-GPTQ-int8",
    "deepseek-ai/DeepSeek-Prover-V2-7B-GPTQ-int4",
    "deepseek-ai/DeepSeek-Prover-V2-7B-AWQ",
    "deepseek-ai/DeepSeek-Prover-V1.5",
    "deepseek-ai/DeepSeek-Prover-V1.5-Base",
    "deepseek-ai/DeepSeek-Prover-V1",
    # extend as new Lean prover models ship
})


def detect_family(model_id: str) -> ModelFamily:
    """Return the model family for `model_id`.

    Substring match against `LEAN_COMPLETION_MODELS` so wrapper-prefixed
    identifiers (e.g. `vllm:/home/user/dspv2-gptq-int8` containing the
    canonical name) still classify correctly. Defaults to CHAT for
    unknown models.
    """
    if not model_id:
        return ModelFamily.CHAT
    needle = model_id.lower()
    for known in LEAN_COMPLETION_MODELS:
        if known.lower() in needle:
            return ModelFamily.LEAN_COMPLETION
    return ModelFamily.CHAT


def render_lean_prompt(
    model_id: str,
    theorem_header: str,
    *,
    imports: list[str] | None = None,
    user_template: str | None = None,
) -> str:
    """Render a Lean theorem-proving prompt for `model_id`.

    Lean completion models always get the autocomplete format
    (`{imports}\\n\\n{theorem_header} := `). If a user_template is
    supplied for a known completion model, it is ignored with a warning;
    the silent acceptance of a chat-style template on a completion model
    is the bug we are eliminating.

    Chat models pass `user_template` through verbatim with the theorem
    header substituted via `.format(theorem_statement=theorem_header)`.

    Args:
        model_id: provider-prefixed model identifier (e.g.
            `deepseek-ai/DeepSeek-Prover-V2-7B-GPTQ-int8`,
            `anthropic/claude-sonnet-4-6`).
        theorem_header: the full `theorem <name> ... : <type>` line
            (no trailing `:=`).
        imports: optional list of imports prepended to the autocomplete
            prompt. Defaults to `["Mathlib"]` when None.
        user_template: caller-supplied chat-style template for chat
            models (string with `{theorem_statement}` placeholder).
            Required for ChatModel; warned-and-ignored for
            LeanCompletion.

    Returns:
        The rendered prompt string ready to feed into the model.
    """
    family = detect_family(model_id)
    if family == ModelFamily.LEAN_COMPLETION:
        if user_template is not None:
            warnings.warn(
                f"Model {model_id!r} is a Lean completion model "
                f"(ModelFamily.LEAN_COMPLETION); ignoring caller-supplied "
                f"chat-style user_template and using autocomplete format. "
                f"Chat-style instructions silently produce space-stripped "
                f"output on this family — see ATH-717.",
                stacklevel=2,
            )
        imp_lines = "\n".join(f"import {m}" for m in (imports or ["Mathlib"]))
        return f"{imp_lines}\n\n{theorem_header} := "
    # chat path
    if user_template is None:
        # Default chat template; callers usually supply their own.
        user_template = (
            "Close this Lean 4 theorem with a clean proof. Output ONLY "
            "the proof body starting with `:=` (or `:= by`).\n\n"
            "# Theorem statement:\n{theorem_statement}\n\n"
            "# Proof body (start with `:=`):\n"
        )
    return user_template.format(theorem_statement=theorem_header)


def is_lean_completion(model_id: str) -> bool:
    """Convenience boolean predicate. True iff `model_id` is registered
    as `ModelFamily.LEAN_COMPLETION`."""
    return detect_family(model_id) == ModelFamily.LEAN_COMPLETION
