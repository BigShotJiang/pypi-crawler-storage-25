"""OpenAI-compatible adapter (gpt, kimi, mistral via OpenAI-compat endpoints).

OpenAI-compat behavior:
- All these models speak the same OpenAI Chat Completions wire format
- Plain string content (no cache_control)
- Kimi K2.5 has a quirk where it sometimes emits its tool calls inline
  in `content` using `<|tool_call_begin|>functions.NAME:ID...<|tool_call_end|>`
  delimiters instead of the proper `tool_calls` field. KimiClient
  subclasses to reparse those.
- Kimi (and occasionally other models) emit literal newlines/tabs inside
  JSON string values for multi-line file contents. The base class's
  `normalize_tool_call` round-trips through json.loads(strict=False) +
  json.dumps to escape them — applies to every adapter.

Backends:
- DIRECT — api.openai.com (gpt-* models, requires OPENAI_API_KEY)
- AZURE  — Azure-hosted OpenAI-compat endpoint (our Kimi + Mistral live
  here on athanor.services.ai.azure.com/models). Uses OPENAI_API_KEY +
  OPENAI_API_BASE.
"""
from __future__ import annotations

import re
from typing import Any

from .base import BACKEND, ModelClient, ModelResponse, ProviderConfig, ProviderError, sanitize_tool_call_args


# Per-model defaults for the families we ship today.
_KIMI_DEFAULT = 32_768
_MISTRAL_DEFAULT = 16_384
_GPT_DEFAULT = 16_384

# Kimi K2.5 reasoning floor. Below this, the model commonly burns the
# whole budget on internal reasoning_content and emits no `content`.
# Empirical from ATH-510 pythia bonferroni_fwer prompt: 4000 still hits
# length, 8000 finishes at ~4666 tokens. Floor at 6 KB.
_KIMI_REASONING_MIN = 6_144

# Kimi inline tool-call delimiter regex. See ATH-231.
_KIMI_TOOL_CALL_RE = re.compile(
    r"<\|tool_call_begin\|>functions\.(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r":(?P<id>\d+)"
    r"<\|tool_call_argument_begin\|>(?P<args>.*?)"
    r"(?:<\|tool_call_end\|>|$)",
    re.DOTALL,
)


class OpenAICompatClient(ModelClient):
    """Base for any OpenAI-compatible model. Subclasses pin per-model
    defaults; the wire format is the same.
    """
    provider = "openai"
    max_tokens_default = _GPT_DEFAULT

    def __init__(
        self,
        model_id: str,
        backend: BACKEND = BACKEND.DIRECT,
        config: ProviderConfig | None = None,
    ):
        super().__init__(model_id=model_id, config=config)
        self.backend = backend

    # ── Required overrides ────────────────────────────────────────────
    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def call(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        try:
            import litellm
        except ImportError as e:
            raise ProviderError(self.model_id, "import",
                                "litellm not installed; pip install athanor-sdk[multi-model]") from e

        kwargs: dict[str, Any] = {
            "model": self.model_id,
            "messages": messages,
            "max_tokens": self.effective_max_tokens(max_tokens),
            "timeout": timeout,
        }
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if top_p is not None:
            kwargs["top_p"] = top_p

        if self.backend == BACKEND.AZURE:
            if self.config.api_base:
                kwargs["api_base"] = self.config.api_base
            if self.config.api_key:
                kwargs["api_key"] = self.config.api_key
            else:
                import os
                if not os.environ.get("OPENAI_API_KEY"):
                    raise ProviderError(
                        self.model_id,
                        "missing-credentials",
                        "Azure OpenAI-compat backend requires api_key. "
                        "Pass via ProviderConfig(api_key=...) or set OPENAI_API_KEY env var. "
                        "Current config: api_base="
                        f"{self.config.api_base!r} api_key=None.",
                    )

        try:
            r = litellm.completion(**kwargs)
        except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
            return ModelResponse(
                model=self.model_id,
                content=None, tool_calls=[],
                prompt_tokens=0, completion_tokens=0,
                error=f"{type(e).__name__}: {str(e)[:300]}",
            )

        choice = r.choices[0]
        msg = choice.message
        usage = getattr(r, "usage", None)

        content = getattr(msg, "content", None)
        # Reasoning models (Kimi K2.5, OpenAI o-series via Azure) populate
        # `message.reasoning_content` separately. Surface it on
        # ModelResponse so callers can inspect / fall back when content is
        # None. We do NOT silently substitute reasoning_content for
        # content — they are semantically different (final answer vs
        # internal thinking), and the agent loop should reject empty
        # final-answer turns rather than treat thinking as the answer.
        reasoning_content = getattr(msg, "reasoning_content", None)
        raw_tool_calls = _model_dump_tool_calls(getattr(msg, "tool_calls", None))
        tool_calls = self.normalize_tool_calls(raw_tool_calls)

        # Subclass hook: reparse Kimi inline tool calls if the model put
        # them in `content` instead of `tool_calls`. Default no-op.
        content, extra_tcs = self._reparse_inline_tool_calls(content, len(tool_calls))
        if extra_tcs:
            tool_calls = tool_calls + self.normalize_tool_calls(extra_tcs)

        return ModelResponse(
            model=self.model_id,
            content=content,
            reasoning_content=reasoning_content,
            tool_calls=tool_calls,
            prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
            finish_reason=getattr(choice, "finish_reason", None),
            raw=r,
        )

    # ── Subclass hook ─────────────────────────────────────────────────
    def _reparse_inline_tool_calls(
        self, content: str | None, existing_tc_count: int
    ) -> tuple[str | None, list[dict]]:
        """Default no-op. KimiClient overrides to reparse the
        `<|tool_call_begin|>...<|tool_call_end|>` text format that Kimi
        sometimes emits in content instead of in tool_calls.
        """
        return content, []


class KimiClient(OpenAICompatClient):
    """Moonshot Kimi K2.5. Routed via our Azure OpenAI-compat endpoint.

    K2.5 is a reasoning model (the OpenAI-compat surface populates
    ``message.reasoning_content`` separately from ``message.content``). On
    a hard prompt with a tight budget the model can spend the entire
    completion budget thinking and never emit a final ``content`` token,
    so callers see ``content=None`` + ``finish_reason='length'``. ATH-510
    swarm sweep on pythia targets surfaced this: 50/50 Kimi attempts
    landed empty because the swarm passed ``max_tokens=800``.

    Mitigation: declare a 6 KB minimum reasoning budget so that the
    base ``ModelClient.normalize_max_tokens()`` clamps small requests
    UP to a safe floor before the API call. Empirical: at ``max_tokens=
    8000`` Kimi K2.5 finishes the bonferroni_fwer prompt with
    ``completion_tokens≈4666``, finish_reason='stop', and produces a
    real Lean calc proof. At 4000 it still hits length. Set the floor at
    6 KB so customers do not silently lose Kimi outputs on hard prompts.
    """

    max_tokens_default = _KIMI_DEFAULT

    @property
    def min_tokens_for_reasoning(self) -> int:
        return _KIMI_REASONING_MIN

    def _reparse_inline_tool_calls(
        self, content: str | None, existing_tc_count: int
    ) -> tuple[str | None, list[dict]]:
        """Kimi K2.5 native tool-call delimiters surface in `content`
        when the model can't use the structured tool_calls slot for some
        reason. Convert them back into proper tool-call dicts.
        """
        if not content or "<|tool_call_begin|>" not in content:
            return content, []
        if existing_tc_count > 0:
            # Already has structured tool_calls; assume Kimi is being
            # consistent and don't double-count.
            return content, []

        new_tcs = []
        for m in _KIMI_TOOL_CALL_RE.finditer(content):
            name = m.group("name")
            call_id = m.group("id")
            args_str = sanitize_tool_call_args(m.group("args").strip())
            new_tcs.append({
                "id": f"call_kimi_{call_id}_{name}",
                "type": "function",
                "function": {"name": name, "arguments": args_str},
            })

        cleaned = re.sub(
            r"<\|tool_calls_section_begin\|>.*$",
            "",
            content,
            flags=re.DOTALL,
        ).rstrip()
        return (cleaned or None), new_tcs


class MistralClient(OpenAICompatClient):
    """Mistral Large via the same Azure OpenAI-compat endpoint as Kimi."""
    max_tokens_default = _MISTRAL_DEFAULT


class GPTClient(OpenAICompatClient):
    """OpenAI gpt-* models. Direct endpoint."""
    max_tokens_default = _GPT_DEFAULT


def _model_dump_tool_calls(tcs: Any) -> list[dict]:
    if not tcs:
        return []
    out = []
    for tc in tcs:
        if hasattr(tc, "model_dump"):
            out.append(tc.model_dump())
        elif hasattr(tc, "dict"):
            out.append(tc.dict())
        elif isinstance(tc, dict):
            out.append(dict(tc))
        else:
            fn = getattr(tc, "function", None)
            out.append({
                "id": getattr(tc, "id", None),
                "type": getattr(tc, "type", "function"),
                "function": {
                    "name": getattr(fn, "name", None),
                    "arguments": getattr(fn, "arguments", "{}"),
                } if fn else {},
            })
    return out
