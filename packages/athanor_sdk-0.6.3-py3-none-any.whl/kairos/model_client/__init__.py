"""kairos.model_client — provider-agnostic adapter layer.

The agent loop talks to one interface; per-provider quirks live inside
the adapters. Add a new model = add an adapter file + register it.
Provider migration (Azure → Bedrock → direct) = swap one factory line.

Usage:
    from kairos.model_client import get_client
    client = get_client("anthropic/claude-sonnet-4-6")
    response = client.call(
        messages=client.format_messages("system prompt", "user prompt"),
        tools=[bash_tool_def],
    )

The library wraps `litellm.completion` internally so we keep its provider
catalog, but the leaky quirks (cache_control format, gemini reasoning
budget, kimi text tool-call format, control-char escaping) all live
inside the adapter — never in the agent loop.

See ATH-231 for the design doc and the bug history that motivated it.
"""
from .base import (
    BACKEND,
    ModelClient,
    ModelResponse,
    ProviderConfig,
    ProviderError,
    sanitize_tool_call_args,
)
from .lean_prover_prompts import (
    LEAN_COMPLETION_MODELS,
    ModelFamily,
    detect_family,
    is_lean_completion,
    render_lean_prompt,
)
from .registry import (
    ALL_REGISTERED,
    Registry,
    default_registry,
    get_client,
    register,
)

__all__ = [
    "ModelClient",
    "ModelResponse",
    "ProviderConfig",
    "ProviderError",
    "BACKEND",
    "sanitize_tool_call_args",
    "get_client",
    "register",
    "Registry",
    "ALL_REGISTERED",
    "default_registry",
    # ATH-717: Lean prover model registry + prompt routing
    "ModelFamily",
    "LEAN_COMPLETION_MODELS",
    "detect_family",
    "is_lean_completion",
    "render_lean_prompt",
]
