"""Subagent-as-proposer backend for kairos optimization.

Instead of calling Azure LLM APIs ($0.10-0.50 per proposal), uses
a local Claude Code subagent to generate RTL optimization proposals.
The subagent tokens are part of the parent session, significantly
cheaper than per-call API billing.

Usage: set model="subagent/claude" in the orchestrator to route
proposals through this backend instead of litellm.
"""
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any


def call_subagent_proposer(
    *,
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 4096,
    timeout_sec: int = 300,
) -> str:
    """Call a Claude Code subagent to generate an RTL optimization proposal.

    Writes the prompt to a temp file, invokes `claude` CLI in non-interactive
    mode, captures the JSON response.

    Returns the raw LLM response text (should contain a JSON code block
    with the proposals array).
    """
    prompt_file = Path(tempfile.mktemp(suffix=".txt", prefix="kairos_prompt_"))
    prompt_file.write_text(f"{system_prompt}\n\n---\n\n{user_prompt}")

    try:
        result = subprocess.run(
            [
                "claude",
                "--print",
                "--model", "sonnet",
                "--max-tokens", str(max_tokens),
                prompt_file.read_text(),
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            cwd="/tmp",
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"claude CLI failed (exit {result.returncode}): "
                f"{result.stderr[:200]}"
            )
        return result.stdout
    finally:
        prompt_file.unlink(missing_ok=True)


def is_subagent_model(model: str) -> bool:
    """Check if the model string requests the subagent backend."""
    return model.startswith("subagent/")


def subagent_model_name(model: str) -> str:
    """Extract the underlying model from a subagent/ prefix."""
    return model.removeprefix("subagent/")


__all__ = [
    "call_subagent_proposer",
    "is_subagent_model",
    "subagent_model_name",
]
