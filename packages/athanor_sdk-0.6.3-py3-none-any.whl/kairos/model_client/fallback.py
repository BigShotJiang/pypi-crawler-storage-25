"""ATH-1097 — model fallback ladder for transient/permanent failures.

When the primary LLM model returns a retryable error (rate-limit 429,
overloaded 503, transient timeout, AuthError that smells like a
config issue), the call falls through to the next model in a
pre-pinned chain. Customer's MCP install gets reliable behavior even
when one provider is down or the env routing is mis-configured.

Per Aidan 2026-05-07 cost-effective-fleet directive ("we also have
gemini and kimi 2.6 on az, not just sonnet") + 2026-05-07 dogfood
ATH-1096 pain point #9 — Sonnet routing AuthError on a customer-MCP
install must not crash the fire.

## Fallback chain shape

Default chain: Opus 4-6 → Sonnet 4-6 → Gemini Pro 3.1 → Kimi 2.6.
Each step downshifts in cost; per-step success surface = "first
that works." Customer's agent picks the model **class** (best /
balanced / fast); orchestrator picks the actual model from the
chain.

## Retryable vs permanent errors

Retryable (fall through to next):
* litellm.RateLimitError / 429
* litellm.ServiceUnavailableError / 503
* AuthenticationError (often a routing-config issue, not a real
  cred failure — fall through to a model on a different provider)
* timeout / connection-reset

Permanent (raise without retry):
* UnknownModelError (typo — don't waste fallback budget)
* explicit ProviderError class

## Public API

* :func:`call_with_fallback` — issue an LLM call against a chain of
  models, returning the first non-error response.
* :data:`DEFAULT_FALLBACK_CHAIN` — opinionated default ladder.
* :class:`FallbackResult` — final ModelResponse + per-step trace
  (which model handled it, which models fell through with what
  error).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from kairos.model_client.base import ModelResponse
from kairos.model_client.registry import get_client


DEFAULT_FALLBACK_CHAIN: tuple[str, ...] = (
    "anthropic/claude-sonnet-4-6",
    "google/gemini-pro-3-1-preview",
    "openai/kimi-2.6",
)


_RETRYABLE_ERROR_TOKENS: tuple[str, ...] = (
    "ratelimit",
    "rate_limit",
    "rate limit",
    "429",
    "503",
    "service_unavailable",
    "service unavailable",
    "overloaded",
    "authentication",  # often a routing-config issue
    "timeout",
    "connection reset",
    "connection refused",
)


def _is_retryable_error(error: str | None) -> bool:
    """Classify an error string as retryable (fall through to next
    model) or permanent (raise without trying more models).

    Heuristic-based: lowercase substring match against a pinned token
    list. Conservative — "authentication" is treated as retryable
    because customer-MCP-install routing failures often surface as
    AuthError on a downstream provider while a peer provider routes
    cleanly. UnknownModelError-style "typo" failures are NOT in the
    token list — those propagate up via ProviderError.
    """
    if not error:
        return False
    lower = error.lower()
    return any(tok in lower for tok in _RETRYABLE_ERROR_TOKENS)


@dataclass(frozen=True)
class FallbackStep:
    """One step in the fallback chain — which model was tried + outcome.

    ``elapsed_sec`` is wall-clock for that step's LLM call. ``error``
    is None if that step succeeded; otherwise the error string.
    """

    model_id: str
    success: bool
    error: str | None
    elapsed_sec: float


@dataclass(frozen=True)
class FallbackResult:
    """Outcome of a call_with_fallback invocation.

    ``response`` is the first successful ModelResponse, or the last
    failed response if every step in the chain failed. ``steps``
    carries per-step trace (all attempted models + error/success) so
    the caller can log/emit fallback telemetry.
    """

    response: ModelResponse
    steps: tuple[FallbackStep, ...]
    fallback_fired: bool = field(default=False)

    @property
    def model_used(self) -> str:
        """Model that produced the final response."""
        return self.response.model


def call_with_fallback(
    *,
    primary_model: str,
    messages: list[dict],
    fallback_chain: tuple[str, ...] | None = None,
    timeout: int = 120,
    temperature: float | None = None,
    top_p: float | None = None,
    max_tokens: int | None = None,
    tools: list[dict] | None = None,
) -> FallbackResult:
    """Call ``primary_model`` then walk ``fallback_chain`` on retryable
    errors. Returns the first successful ModelResponse + per-step trace.

    Parameters
    ----------
    primary_model:
        First model id to try (e.g. ``"anthropic/claude-opus-4-6"``).
    messages:
        Standard chat messages list.
    fallback_chain:
        Tuple of model ids to fall through to. Defaults to
        :data:`DEFAULT_FALLBACK_CHAIN` (Sonnet → Gemini → Kimi).
    timeout / temperature / top_p / max_tokens / tools:
        Standard LLM call params, applied identically to every step.

    Returns
    -------
    :class:`FallbackResult` with the final response + per-step trace.
    ``fallback_fired`` is True iff any non-primary step ran.

    Notes
    -----
    Per-step errors are captured in ``steps`` regardless of whether
    they were retryable or permanent. A non-retryable error halts
    the fallback walk early — a UnknownModelError on the primary
    propagates up rather than burning fallback budget.

    The chain is "best-effort": if every step fails, returns the
    last failed ModelResponse so caller can inspect; if the chain
    is empty, the primary's response (success or fail) is returned.
    """
    chain = fallback_chain if fallback_chain is not None else DEFAULT_FALLBACK_CHAIN
    full_chain = (primary_model, *chain)
    steps: list[FallbackStep] = []
    last_response: ModelResponse | None = None
    for i, model_id in enumerate(full_chain):
        t0 = time.time()
        try:
            client = get_client(model_id)
            response = client.call(
                messages=messages,
                tools=tools,
                max_tokens=max_tokens,
                timeout=timeout,
                temperature=temperature,
                top_p=top_p,
            )
        except Exception as e:  # noqa: BLE001
            elapsed = time.time() - t0
            err_str = f"{type(e).__name__}: {str(e)[:200]}"
            steps.append(FallbackStep(
                model_id=model_id,
                success=False,
                error=err_str,
                elapsed_sec=elapsed,
            ))
            last_response = ModelResponse(
                model=model_id,
                content=None,
                tool_calls=[],
                prompt_tokens=0,
                completion_tokens=0,
                error=err_str,
            )
            if not _is_retryable_error(err_str):
                # Permanent error — propagate up to caller. Don't
                # waste fallback budget on a typo'd model id.
                break
            continue
        elapsed = time.time() - t0
        if response.error is None:
            steps.append(FallbackStep(
                model_id=model_id,
                success=True,
                error=None,
                elapsed_sec=elapsed,
            ))
            return FallbackResult(
                response=response,
                steps=tuple(steps),
                fallback_fired=(i > 0),
            )
        # response.error is set — categorize.
        steps.append(FallbackStep(
            model_id=model_id,
            success=False,
            error=response.error,
            elapsed_sec=elapsed,
        ))
        last_response = response
        if not _is_retryable_error(response.error):
            # Permanent — halt fallback walk.
            break
    # Every step failed (or chain was empty + primary failed).
    return FallbackResult(
        response=last_response or ModelResponse(
            model=primary_model,
            content=None,
            tool_calls=[],
            prompt_tokens=0,
            completion_tokens=0,
            error="empty fallback chain + primary failed",
        ),
        steps=tuple(steps),
        fallback_fired=len(steps) > 1,
    )


__all__ = [
    "DEFAULT_FALLBACK_CHAIN",
    "FallbackResult",
    "FallbackStep",
    "call_with_fallback",
]
