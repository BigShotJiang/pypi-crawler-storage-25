"""Gemini adapter (Google AI Studio direct, Vertex AI service-account).

Gemini-specific behavior:
- Plain string content (NOT cache_control content blocks).
  Vertex 400s with 'CachedContent can not be used with GenerateContent
  request setting system_instruction, tools or tool_config' if you mix
  cache_control with tools.
- Reasoning preview models (gemini-3-flash-preview, gemini-3.1-pro-preview)
  burn 3000-5000 reasoning tokens per turn before emitting any visible
  output. Default max_tokens=8192 in the agent loop caused a silent-fail
  mode where the model returned content='' / tool_calls=[] / 0 visible
  tokens. We push max_tokens to 65536 for those models and refuse smaller
  budgets (`min_tokens_for_reasoning=16384`).
- `tool_choice="required"` on turn 0 nudges the model to actually call a
  tool instead of stalling on plain-text reasoning. Useful for builders.
"""
from __future__ import annotations

from typing import Any

from .base import BACKEND, ModelClient, ModelResponse, ProviderConfig, ProviderError


# Default for non-reasoning Gemini models (Gemini 2.5 Flash / Pro).
_GEMINI_2_5_DEFAULT = 8192

# Reasoning preview models need MUCH more headroom. See ATH-231.
_GEMINI_3_REASONING_DEFAULT = 65_536
_GEMINI_3_REASONING_MIN = 16_384


class GeminiClient(ModelClient):
    """Google Gemini family. Backends: direct (AI Studio), vertex_ai."""

    provider = "gemini"

    def __init__(
        self,
        model_id: str,
        backend: BACKEND = BACKEND.DIRECT,
        config: ProviderConfig | None = None,
    ):
        super().__init__(model_id=model_id, config=config)
        self.backend = backend

    @property
    def is_reasoning_model(self) -> bool:
        bare = self.model_id.split("/", 1)[-1]
        # The 3.x preview line is reasoning-mode by default. As Google
        # promotes more variants we'll add them here.
        return any(
            bare.startswith(p)
            for p in ("gemini-3", "gemini-3.1", "gemini-3-flash-preview")
        )

    @property
    def max_tokens_default(self) -> int:
        return (
            _GEMINI_3_REASONING_DEFAULT if self.is_reasoning_model
            else _GEMINI_2_5_DEFAULT
        )

    @property
    def min_tokens_for_reasoning(self) -> int:
        return _GEMINI_3_REASONING_MIN if self.is_reasoning_model else 0

    # ── Required overrides ────────────────────────────────────────────
    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        """Plain string content. NEVER add cache_control here — Vertex
        rejects CachedContent + tools.
        """
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def call(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        try:
            import litellm
        except ImportError as e:
            raise ProviderError(self.model_id, "import",
                                "litellm not installed; pip install athanor-sdk[multi-model]") from e

        kwargs: dict[str, Any] = {
            "model": self.model_id,
            "messages": messages,
            "max_tokens": self.effective_max_tokens(max_tokens),
            "timeout": timeout,
        }
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if top_p is not None:
            kwargs["top_p"] = top_p

        # Direct backend uses GEMINI_API_KEY from env (no api_base override).
        # Vertex backend passes a service account JSON path via vertex_credentials.
        if self.backend == BACKEND.VERTEX_AI:
            if self.config.extra.get("credentials_path"):
                kwargs["vertex_credentials"] = self.config.extra["credentials_path"]
            if self.config.region:
                kwargs["vertex_location"] = self.config.region

        try:
            r = litellm.completion(**kwargs)
        except Exception as e:
            # ATH-842: NotFoundError on a typo'd model name is NOT a
            # transient problem; it's a permanent config bug. Raising
            # UnknownModelError so customers' `except UnknownModelError`
            # branches catch it instead of silently getting content=None.
            err_name = type(e).__name__
            err_str = str(e)
            if err_name == "NotFoundError" or "is not found" in err_str:
                from kairos.errors import UnknownModelError
                raise UnknownModelError(
                    model_id=self.model_id,
                    provider="gemini",
                ) from e
            return ModelResponse(
                model=self.model_id,
                content=None, tool_calls=[],
                prompt_tokens=0, completion_tokens=0,
                error=f"{err_name}: {err_str[:300]}",
            )

        choice = r.choices[0]
        msg = choice.message
        usage = getattr(r, "usage", None)

        # Gemini exposes reasoning token count via prompt_tokens_details.
        reasoning_toks = 0
        ctd = getattr(usage, "completion_tokens_details", None) if usage else None
        if ctd is not None:
            reasoning_toks = getattr(ctd, "reasoning_tokens", 0) or 0

        return ModelResponse(
            model=self.model_id,
            content=getattr(msg, "content", None),
            tool_calls=self.normalize_tool_calls(
                _model_dump_tool_calls(getattr(msg, "tool_calls", None))
            ),
            prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            completion_tokens=getattr(usage, "completion_tokens", 0) or 0,
            reasoning_tokens=reasoning_toks,
            finish_reason=getattr(choice, "finish_reason", None),
            raw=r,
        )


def _model_dump_tool_calls(tcs: Any) -> list[dict]:
    """Same helper as in anthropic.py — duplicated to avoid cross-import."""
    if not tcs:
        return []
    out = []
    for tc in tcs:
        if hasattr(tc, "model_dump"):
            out.append(tc.model_dump())
        elif hasattr(tc, "dict"):
            out.append(tc.dict())
        elif isinstance(tc, dict):
            out.append(dict(tc))
        else:
            fn = getattr(tc, "function", None)
            out.append({
                "id": getattr(tc, "id", None),
                "type": getattr(tc, "type", "function"),
                "function": {
                    "name": getattr(fn, "name", None),
                    "arguments": getattr(fn, "arguments", "{}"),
                } if fn else {},
            })
    return out
