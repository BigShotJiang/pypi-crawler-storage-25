"""Passthrough ModelClient — forwards any model string to litellm as-is.

Aidan 2026-05-13: customers must be able to bring ANY model, including
locally hosted ones, as long as it works. Rejecting unknown model strings
is bad engineering design.

This client is the registry's fallback when no prefix rule matches.
litellm supports 100+ providers natively; we pass the model string
through and let litellm resolve the provider + endpoint.
"""
from __future__ import annotations

from kairos.model_client.base import (
    BACKEND,
    ModelClient,
    ModelResponse,
    ProviderConfig,
)


class LiteLLMPassthroughClient(ModelClient):
    """Forwards any model_id to litellm.completion() without transformation.

    Covers: ollama/*, together/*, fireworks/*, vllm/*, huggingface/*,
    any OpenAI-compatible endpoint, self-hosted models, and anything
    else litellm supports. The customer configures their endpoint via
    the standard litellm env vars (OPENAI_API_BASE, etc.).
    """

    provider = "passthrough"
    backend = BACKEND.DIRECT
    max_tokens_default = 4096

    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def call(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        try:
            import litellm
        except ImportError:
            return ModelResponse(
                content=None,
                error=(
                    f"litellm not installed — needed for model '{self.model_id}'. "
                    "pip install litellm"
                ),
            )

        kwargs: dict = {
            "model": self.model_id,
            "messages": messages,
            "max_tokens": max_tokens or self.max_tokens_default,
            "timeout": timeout,
        }
        if self.config.api_base:
            kwargs["api_base"] = self.config.api_base
        if self.config.api_key:
            kwargs["api_key"] = self.config.api_key
        if tools:
            kwargs["tools"] = tools
        if temperature is not None:
            kwargs["temperature"] = temperature
        if top_p is not None:
            kwargs["top_p"] = top_p

        try:
            r = litellm.completion(**kwargs)
            choice = r.choices[0]
            content = choice.message.content or ""
            return ModelResponse(
                content=content,
                prompt_tokens=getattr(r.usage, "prompt_tokens", 0),
                completion_tokens=getattr(r.usage, "completion_tokens", 0),
            )
        except Exception as e:  # noqa: BLE001 — surface provider errors as ModelResponse.error
            return ModelResponse(
                content=None,
                error=f"{type(e).__name__}: {str(e)[:500]}",
            )
