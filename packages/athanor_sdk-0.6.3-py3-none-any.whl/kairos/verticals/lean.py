"""kairos.verticals.lean — Lean 4 proof VerifierPlugin.

Registered under tier_name ``lean_proved``. Wraps
:mod:`kairos.lean` (the existing Lean proof verification helpers) as
a :class:`VerifierPlugin`-shaped object so the built-in pipeline can
dispatch to Lean when the customer's intent calls for
formal-theorem-proving.

Two input shapes supported via the witness dict:

1. Inline Lean source:
   ``witness = {"lean_code": "theorem foo : ... := by ..."}``
2. Lean file path:
   ``witness = {"lean_file": "/abs/path/to/MyProof.lean"}``

Optional:

* ``timeout_sec`` (default 600, from ``kairos.lean.DEFAULT_VERIFY_TIMEOUT_SEC``) —
  passed to the underlying lake-build subprocess. 600s accommodates
  cold Mathlib-using projects; bare-file mode uses a trivial fraction.
* ``axiom_audit_match`` (list[str]) — per-spec axiom allowlist.
  The plugin refuses to emit ``proved`` if the theorem introduces
  a non-whitelisted axiom (basic static check via the existing
  ``kairos.lean.check_banned`` helper).
* ``lake_project`` (str | Path) + ``module_path`` (str, dotted like
  ``"Foo.Bar"``) — **Lake-project mode** (2026-04-23, Cedar fleet
  unblock). When both are set, the plugin writes ``lean_code`` into
  ``<lake_project>/<module_path_with_slashes>.lean`` and runs
  ``lake build <module_path>`` inside the project. The project's
  ``lean-toolchain`` + ``lakefile.toml`` / ``lakefile.lean`` define
  the trust boundary (Mathlib + declared deps become available).
  Requires elan / lake on PATH. Filesystem rollback is contractual:
  original module contents are restored, created files are deleted.

Verdict mapping:

* Proof compiles, no ``sorry``, no banned construct
  (``full_proof`` in the underlying ProofResult) →
  ``Verdict.outcome='proved'``, ``details['score']=1.0``.
* Proof compiles but has ``sorry`` (``partial_proof``) →
  ``outcome='unknown'`` (not refuted; the math might be correct
  but the proof is incomplete). ``details['sorry_count']`` + the
  SDK's ``ProofResult.status`` attached.
* Compile error (``compile_error``) → ``outcome='refuted'``,
  ``details['errors']`` has the Lean compiler's error list.
* Banned construct detected (``banned``) → ``outcome='refuted'``,
  ``reason`` names the banned token. Fires even if it would
  otherwise compile.
* Neither code nor file supplied → ``outcome='error'``.

Cross-ref:
  * kairos.lean — the underlying verify_proof + check_banned + check_sorry.
  * kairos.ebmc — same Protocol contract, EBMC backend.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from kairos.spec.types import Counterexample, Verdict


TIER_NAME = "lean_proved"


class LeanProofPlugin:
    """VerifierPlugin that runs Lean 4 proof verification.

    :purity: IMPURE_SIDE_EFFECTFUL  — shells out to ``lake build``
             (via kairos.lean.verify_proof), reads the Lean source,
             writes no persistent state outside the build cache.
    """

    tier_name: str = TIER_NAME
    # ATH-526: real verifier — shells out to lake build + parses real Lean output.
    is_stub: bool = False

    def verify(
        self,
        intent: Mapping[str, Any],
        witness: Mapping[str, Any],
        *,
        timeout_sec: float | None = None,
    ) -> Verdict:
        """Dispatch lake build against the witness-supplied Lean source."""
        try:
            from kairos.lean import verify_proof
        except ImportError as exc:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"kairos.lean not importable ({exc})",
                details={"exception": type(exc).__name__},
            )

        # Witness keys take priority; fall back to IntentV1.target.file
        # so `kairos prove --nl` works without fabricating a witness.
        # IntentV1 from nl_frontend (vertical='lean') sets target.file
        # to the .lean path.
        from typing import Mapping as _M
        intent_target = intent.get("target", {}) if isinstance(intent, _M) else {}
        lean_code = witness.get("lean_code")
        lean_file = witness.get("lean_file") or intent_target.get("file")

        if not lean_code and not lean_file:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "missing Lean source: neither witness['lean_code'] / "
                    "witness['lean_file'] nor intent.target.file set — "
                    "cannot run lake build."
                ),
                details={"missing_fields": ["lean_code", "lean_file"]},
            )

        # Resolve file to text if file was supplied.
        if not lean_code and lean_file:
            path = Path(lean_file)
            if not path.exists():
                return Verdict(
                    source=TIER_NAME, outcome="error",
                    reason=f"Lean file not found: {lean_file!r}",
                    details={"lean_file": str(path)},
                )
            try:
                lean_code = path.read_text()
            except OSError as exc:
                return Verdict(
                    source=TIER_NAME, outcome="error",
                    reason=f"Lean file unreadable: {exc}",
                    details={"lean_file": str(path),
                             "exception": type(exc).__name__},
                )

        # Default drawn from kairos.lean so the two surfaces stay in
        # sync (ATH-522). 600s covers cold Mathlib-using projects.
        from kairos.lean import DEFAULT_VERIFY_TIMEOUT_SEC
        resolved_timeout = int(
            timeout_sec if timeout_sec is not None
            else witness.get("timeout_sec", DEFAULT_VERIFY_TIMEOUT_SEC)
        )

        # Lake-project mode: require both lake_project and module_path.
        # Passing only one is a caller bug — refuse to guess.
        lake_project = witness.get("lake_project")
        module_path = witness.get("module_path")
        if (lake_project is None) != (module_path is None):
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "witness has lake_project XOR module_path set. "
                    "Both must be set together (lake-project mode) "
                    "or neither (bare-file mode)."
                ),
                details={
                    "lake_project": lake_project,
                    "module_path": module_path,
                },
            )

        try:
            result = verify_proof(
                lean_code,
                lake_project=lake_project,
                module_path=module_path,
                timeout=resolved_timeout,
            )
        except ValueError as exc:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"verify_proof rejected inputs: {exc}",
                details={"exception": type(exc).__name__},
            )
        except Exception as exc:  # noqa: BLE001 — guard returns fallback value on any error
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"verify_proof raised {type(exc).__name__}: {exc}",
                details={"exception": type(exc).__name__},
            )

        base_details: dict[str, Any] = {
            "status": result.status,
            "compiles": result.compiles,
            "has_sorry": result.has_sorry,
            "sorry_count": result.sorry_count,
            "score": result.score,
        }

        if result.status == "banned":
            return Verdict(
                source=TIER_NAME, outcome="refuted",
                reason=(
                    f"Lean proof uses banned construct: {result.banned!r}. "
                    "Remove the banned token or register it in the spec's "
                    "axiom_audit_match allowlist."
                ),
                details={
                    **base_details,
                    "banned": result.banned,
                    "counterexample": Counterexample(
                        kind="axiom_violation",
                        summary=f"banned construct: {result.banned!r}",
                        payload={"banned": result.banned},
                    ),
                },
            )

        if result.status == "axiom_leak":
            # ATH-948: proof compiled cleanly but transitive axiom
            # audit caught a forbidden axiom. Same soundness class as
            # `banned` but the diagnosis is different — surface it
            # with its own counterexample-shape so customers can
            # triage the sorry-leak class without grepping for the
            # specific banned construct text.
            forbidden = list(result.forbidden_axioms or [])
            forbidden_preview = (
                ", ".join(forbidden[:3]) if forbidden else "(none reported)"
            )
            return Verdict(
                source=TIER_NAME, outcome="refuted",
                reason=(
                    f"Lean proof compiles but transitive axiom audit "
                    f"found forbidden axiom(s): {forbidden_preview}. "
                    f"Likely sorryAx leak via vacuous self-reference."
                ),
                details={
                    **base_details,
                    "forbidden_axioms": forbidden,
                    "axiom_clean": False,
                    "counterexample": Counterexample(
                        kind="axiom_violation",
                        summary=(
                            f"forbidden axioms: {forbidden_preview}"
                        ),
                        payload={"forbidden_axioms": forbidden},
                    ),
                },
            )

        if result.status == "full_proof":
            # Check axiom_audit_match allowlist if the intent declares one.
            # For the MVP we don't introspect the kernel axiom list — that
            # goes through a deeper Lean-extraction step. We document the
            # contract but do not enforce it here; spec's
            # axiom_audit_match is propagated for auditor visibility.
            axiom_allowlist = list(
                intent.get("acceptance_criteria", {}).get("axiom_audit_match", [])
            )
            return Verdict(
                source=TIER_NAME, outcome="proved",
                reason=(
                    f"Lean proof compiled, no sorry, no banned "
                    f"construct (score={result.score:.2f})."
                ),
                details={
                    **base_details,
                    "axiom_audit_match": axiom_allowlist,
                },
            )

        if result.status == "partial_proof":
            return Verdict(
                source=TIER_NAME, outcome="unknown",
                reason=(
                    f"Lean proof compiles but has {result.sorry_count} "
                    f"sorry marker(s). Math may be right but the proof is "
                    f"incomplete — complete or ship with unknown verdict."
                ),
                details=base_details,
            )

        # compile_error path.
        errors_truncated = result.errors[:10]
        first_error = errors_truncated[0] if errors_truncated else "no error output"
        # Keep the summary one line: take first 160 chars of the first error.
        summary_line = first_error.splitlines()[0][:160] if first_error else first_error
        return Verdict(
            source=TIER_NAME, outcome="refuted",
            reason=(
                f"Lean proof failed to compile — {len(result.errors)} "
                f"error(s). See details['errors'] for the compiler output."
            ),
            details={
                **base_details,
                "errors": errors_truncated,
                "counterexample": Counterexample(
                    kind="compile_error",
                    summary=(
                        f"{len(result.errors)} Lean compile error(s); "
                        f"first: {summary_line}"
                    ),
                    payload={"errors": errors_truncated},
                ),
            },
        )
