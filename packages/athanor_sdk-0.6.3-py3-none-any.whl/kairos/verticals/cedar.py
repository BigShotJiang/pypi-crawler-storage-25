"""kairos.verticals.cedar — Cedar fleet VerifierPlugin (ATH-514 stub).

Registered under tier_name ``cedar_diff_tested``. **Stub** — witness
validation + dry-run docker-command shape + honest error/unknown
verdict wiring. **Does not yet invoke real Palamedes generator
synthesis or real rust↔go diff** — that lands after:

1. The monolith ``ghcr.io/athanor-ai/kairos-cedar:latest`` image ships
   (platform ATH-512 subtask 4).
2. Palamedes Cedar-micro scaffolding lands in kairos-cedar repo
   (platform ATH-512 subtask 1).

The stub gives downstream code (SpecPipeline dispatch, tests, platform's
``solve/core/verticals/cedar.py`` phase body) a landing pad it can target
today; the real impl drops in later as a function-body swap.

## Witness shape (platform monolith pivot, Slack ts=1776973076)

    {
        "workspace_root": "/abs/path/to/kairos-cedar",
        "corpus_path": "/abs/path/to/corpus-tests.tar.gz",  # optional
        "dry_run": True,   # REQUIRED in V0 stub era
        "timeout_sec": 300,
    }

* ``workspace_root`` — kairos-cedar clone root. Must exist. The docker
  command mounts it at ``/work`` inside the monolith image.
* ``corpus_path`` — optional shipped corpus tarball. When unset, the
  stub still validates docker command shape but doesn't reference a
  corpus.
* ``dry_run`` — **required True in the stub era**. When False, the
  plugin returns ``outcome='error'`` with an explicit "real impl not
  wired yet" reason, so callers don't accidentally believe they ran a
  real generator synthesis.

## Verdict mapping (stub era)

* dry_run=True + valid workspace + docker available →
  ``outcome='unknown'``, ``details['stub_mode']=True``,
  ``details['docker_cmd']`` = the exact argv that would be run. This
  is honest: we have not verified anything; we've only validated the
  plumbing + command shape.
* dry_run=False → ``outcome='error'`` with reason pointing at the
  real-impl follow-up ticket.
* workspace_root missing / doesn't exist / docker not on PATH →
  ``outcome='error'`` with specific reason.

## Why not mock subprocess.run?

Earlier iteration (branch ``qa/ath-520-cedar-fleet-plugin``, deleted
2026-04-23) mocked ``subprocess.run`` + claimed 25 tests passed. Those
tests validated the plugin's own mocks, not real behavior. Per Aidan's
2026-04-23 directive "don't mock anything, this has cost us a lot,"
this rewrite commits to: only test pure functions + dry_run plumbing
with real filesystem, no mocks of the subject under test.

## Cross-ref

* ATH-514 (this ticket, qa) — https://linear.app/athanor-ai/issue/ATH-514
* ATH-512 parent — kairos-cedar V1
* Platform monolith pivot: Slack ts=1776973076
* Earlier overmock incident: feedback_no_mocks_real_tests_no_lying.md
* ``kairos.ebmc`` — Protocol-contract-shaped sibling
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any, Mapping

# ATH-1212a: strip Athanor + customer credentials from the cedar-via-docker
# subprocess env. The factory's allowlist includes DOCKER_HOST + DOCKER_CERT_PATH
# + DOCKER_TLS_VERIFY (docker-transport vars); see safe_env_for_cedar docstring.
from kairos.security.env_allowlist import safe_env_for_cedar
from kairos.spec.types import Verdict


TIER_NAME = "cedar_diff_tested"

# Monolith image tag (public as of 2026-04-23, ATH-518). Customers
# `docker pull` this to get lake + lean + rustc + go + cargo + dafny +
# verus + cedar all on PATH. Kept as a module-level constant so tests
# + platform's phase body can reference one name.
MONOLITH_IMAGE = "ghcr.io/athanor-ai/kairos-cedar:latest"

# Probe command the dry_run path executes inside the container to
# prove end-to-end docker wiring works. Stays harmless + side-effect-
# free. Emits toolchain versions so the Verdict.details carries
# something auditable.
_DRY_RUN_PROBE = (
    "echo 'kairos-cedar cedar-plugin dry-run probe' && "
    "lake --version 2>&1 | head -1 && "
    "rustc --version 2>&1 | head -1 && "
    "go version 2>&1 | head -1 && "
    "echo 'probe ok'"
)


class CedarDiffTestedPlugin:
    """VerifierPlugin for Cedar differential testing. Stub in the
    monolith-image era — honest dry-run + command-shape validation
    only. Real palamedes / rust↔go diff lands post-monolith.

    :purity: IMPURE_SIDE_EFFECTFUL  — would shell out to docker when
             wired to the real image; currently only reads the
             filesystem to validate witness + optionally inspect
             corpus path.
    """

    tier_name: str = TIER_NAME
    # ATH-526: STUB plugin — witness validation + dry-run probe only.
    # Does NOT actually close the cedar_diff_tested tier. The registry
    # WARN-logs on registration; register_defaults() excludes this
    # plugin so customers don't pick it up by accident.
    is_stub: bool = True

    def verify(
        self,
        intent: Mapping[str, Any],
        witness: Mapping[str, Any],
        *,
        timeout_sec: float | None = None,
    ) -> Verdict:
        """Validate witness + return stub Verdict. See module docstring."""
        workspace_root = witness.get("workspace_root")
        if not workspace_root:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason="witness missing 'workspace_root'",
                details={"missing_field": "workspace_root"},
            )

        ws = Path(workspace_root)
        if not ws.is_dir():
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"workspace_root not a directory: {ws}",
                details={"workspace_root": str(ws)},
            )

        corpus_path = witness.get("corpus_path")
        if corpus_path is not None:
            corpus = Path(corpus_path)
            if not corpus.exists():
                return Verdict(
                    source=TIER_NAME, outcome="error",
                    reason=f"corpus_path does not exist: {corpus}",
                    details={"corpus_path": str(corpus)},
                )

        dry_run = witness.get("dry_run")
        if dry_run is not True:
            # Explicit False or unset — refuse to pretend we ran a real
            # generator synthesis. This is the honesty guard.
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "cedar-fleet plugin is a STUB (ATH-514) in the "
                    "monolith-image era. Set witness['dry_run']=True "
                    "to exercise the command-shape wiring, OR wait for "
                    "ATH-512 subtask 1 (Palamedes scaffolding) + "
                    "subtask 4 (monolith image push) to land + a "
                    "real-impl follow-up ticket (ATH-515 or later)."
                ),
                details={"dry_run": dry_run, "stub_mode": True},
            )

        if shutil.which("docker") is None:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason="docker not on PATH — cedar-fleet needs docker",
                details={"stub_mode": True},
            )

        resolved_timeout = int(
            timeout_sec if timeout_sec is not None
            else witness.get("timeout_sec", 300)
        )

        # Build the docker command argv. Monolith image is public as of
        # ATH-518 (Aidan flipped visibility 2026-04-23), so we actually
        # shell out to it on dry_run=True. The probe is harmless +
        # side-effect-free — verifies each expected toolchain is on
        # PATH inside the container. Real palamedes synthesis is still
        # TBD (ATH-515+516+517 blockers) but the docker wiring is now
        # proven end-to-end.
        cmd = [
            "docker", "run", "--rm",
            "-v", f"{ws}:/work",
            "-w", "/work",
            MONOLITH_IMAGE,
            "bash", "-c", _DRY_RUN_PROBE,
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=resolved_timeout,
                env=safe_env_for_cedar(),  # ATH-1212a
            )
        except subprocess.TimeoutExpired:
            return Verdict(
                source=TIER_NAME, outcome="unknown",
                reason=(
                    f"dry-run probe timed out after {resolved_timeout}s "
                    f"in {MONOLITH_IMAGE}. If this is the first pull "
                    f"on the host, allow a longer timeout for the "
                    f"image download."
                ),
                details={
                    "stub_mode": True,
                    "timed_out": True,
                    "workspace_root": str(ws),
                    "docker_cmd": cmd,
                    "image": MONOLITH_IMAGE,
                },
            )
        except FileNotFoundError as exc:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"docker invocation failed: {exc}",
                details={"exception": type(exc).__name__},
            )

        if result.returncode != 0:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    f"dry-run probe in {MONOLITH_IMAGE} exited "
                    f"{result.returncode}. stderr tail: "
                    f"{result.stderr[-400:]!r}"
                ),
                details={
                    "stub_mode": True,
                    "exit_code": result.returncode,
                    "stderr_tail": result.stderr[-800:],
                    "docker_cmd": cmd,
                },
            )

        # Probe succeeded — real toolchain output captured.
        return Verdict(
            source=TIER_NAME, outcome="unknown",
            reason=(
                "cedar-fleet dry-run probe succeeded against real "
                f"{MONOLITH_IMAGE}. Toolchain versions captured in "
                "details['probe_stdout']. No semantic synthesis "
                "performed — real palamedes invocation TBD "
                "(ATH-515/516/517)."
            ),
            details={
                "stub_mode": True,
                "dry_run": True,
                "workspace_root": str(ws),
                "docker_cmd": cmd,
                "image": MONOLITH_IMAGE,
                "timeout_sec": resolved_timeout,
                "corpus_path": str(corpus) if corpus_path is not None else None,
                "probe_stdout": result.stdout,
                "probe_stderr_tail": result.stderr[-200:] if result.stderr else "",
            },
        )
