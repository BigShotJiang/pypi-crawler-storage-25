"""ATH-697 — Pythia free-tier template registry.

Hand-written `(regex pattern, Lean template generator)` pairs covering
the most common hypotheses a customer would ask of `Pythia` — the
public OSS Lean 4 library for finite-precision statistics
(https://github.com/athanor-ai/pythia, renamed from
`kairos-stats-lean` 2026-04-26).

## Why deterministic patterns first

Pythia's surface is a finite list of theorems about confidence
sequences, sharp constants, and quantization slack rates — see
`Pythia.API` for the full list. Most customer hypotheses fall into a
handful of shapes (sharp-constant equivalence, ranking, positivity,
quantization rate, Ville-inequality application). Hand-written
patterns:

- Run zero-cost zero-friction (no LLM key required).
- Are auditable: customer can read the regex + template + understand
  exactly what Pythia symbol the natural language maps to.
- Are deterministic: same hypothesis → same Lean output every time.

The optional BYO LLM path (`kairos.llm_byo`) covers the long tail
where a customer's prose doesn't match a deterministic pattern.

## Template shape

Each entry yields a `PythiaSpec` carrying:

  - `lean_source`: the Lean module text to verify. Imports
    `Pythia.API` + states the theorem the customer asked about.
    The proof body uses real Pythia public symbols — no fake names.
  - `nl_summary`: one-line restatement of what's being proved.
  - `pattern_id`: which template fired (debugging + audit log).
  - `bindings`: the named-capture values pulled from the hypothesis.

`kairos.simple_prove_template()` runs `kairos.lean.verify_proof(lean_source)`
on the result, then translates the verdict back to NL.

## What customers can express (v0)

Five patterns mapping natural-language statistics hypotheses directly
to `Pythia.API` theorems:

  1. **`sharp_constant_equivalence`** — "prove c_vector equals
     sqrt(2) times c_HR" → `c_vector_eq_sqrt_two_mul_c_HR`
  2. **`sharp_constant_ranking`** — "prove c_aCS_sharp <= c_vector_sharp"
     → `c_sharp_ranking`
  3. **`sharp_constant_positive`** — "prove c_vector_sharp is positive"
     → `c_vector_sharp_pos` / `c_aCS_sharp_pos`
  4. **`bit_precision_time`** — "prove Pythia.Time is a natural number"
     → resolves via `rfl` over the Time abbrev
  5. **`pythia_smoke`** — "verify the Pythia API loads" → import +
     trivial proposition. Toolchain sanity check.

All five compile against the published `Pythia.API` surface — they
exercise real theorems, not stubs.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class PythiaSpec:
    """One generated Pythia spec ready to feed to `verify_proof`."""

    lean_source: str
    nl_summary: str
    pattern_id: str
    bindings: dict[str, str]


@dataclass(frozen=True)
class _Pattern:
    """One (regex, template) pair in the registry.

    `keywords` is an optional natural-English fallback. When the regex
    misses, `match()` lower-cases the hypothesis and accepts the
    pattern if every keyword tuple in `keywords` is present (one
    tuple = one alias group; any element of a tuple satisfies it).
    Patterns whose template needs bindings keep `keywords=()` and
    rely on the regex path only.
    """

    pattern_id: str
    regex: re.Pattern[str]
    template: str
    nl_template: str
    keywords: tuple[tuple[str, ...], ...] = ()


# ─── Patterns (hand-written, narrow scope, real Pythia symbols) ────────


_PATTERNS: tuple[_Pattern, ...] = (
    _Pattern(
        pattern_id="sharp_constant_equivalence",
        regex=re.compile(
            r"\bprove\b.*?\bc_?vector(?:_sharp)?\b.*?"
            r"(?:=|==|equals?)\s*"
            r"(?:sqrt\s*2|√\s*2|sqrt\(2\))\s*"
            r"(?:\*|times|×)\s*"
            r"\bc_?HR(?:_sharp)?\b",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-697: Pythia template `sharp_constant_equivalence`\n"
            "-- Verifies the closed-form relationship between the\n"
            "-- vector and Howard-Ramdas sharp constants.\n"
            "open Pythia\n"
            "\n"
            "example : c_vector_sharp = Real.sqrt 2 * c_HR_sharp := by\n"
            "  exact c_vector_eq_sqrt_two_mul_c_HR\n"
        ),
        nl_template=(
            "the vector sharp constant equals sqrt(2) times the "
            "Howard-Ramdas sharp constant (Pythia.MatchingConstants)"
        ),
    ),
    _Pattern(
        pattern_id="sharp_constant_ranking",
        regex=re.compile(
            r"\bprove\b.*?\bc_?aCS(?:_sharp)?\b.*?"
            r"(?:<=?|≤|<=|less\s+than\s+(?:or\s+equal)?|"
            r"is\s+at\s+most|is\s+below|stays\s+below)\s*"
            r"\bc_?vector(?:_sharp)?\b",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-697: Pythia template `sharp_constant_ranking`\n"
            "-- Verifies aCS sharp constant <= vector sharp constant.\n"
            "open Pythia\n"
            "\n"
            "example : c_aCS_sharp ≤ c_vector_sharp := by\n"
            "  exact c_sharp_ranking\n"
        ),
        nl_template=(
            "the aCS sharp constant is at most the vector sharp "
            "constant (Pythia.MatchingConstants.c_sharp_ranking)"
        ),
    ),
    _Pattern(
        pattern_id="sharp_constant_positive",
        regex=re.compile(
            r"\bprove\b.*?\b(?P<which>c_?vector(?:_sharp)?|c_?aCS(?:_sharp)?)\b.*?"
            r"(?:>\s*0|positive|is\s+positive|is\s+strictly\s+positive)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-697: Pythia template `sharp_constant_positive`\n"
            "-- Verifies the sharp constant is strictly positive.\n"
            "open Pythia\n"
            "\n"
            "example : 0 < {symbol} := by\n"
            "  exact {pos_lemma}\n"
        ),
        nl_template="{display} is strictly positive (Pythia.MatchingConstants)",
    ),
    _Pattern(
        pattern_id="bit_precision_time",
        regex=re.compile(
            r"\bprove\b.*?\b(?:pythia\s*\.?\s*)?time\b.*?"
            r"(?:is\s+(?:a\s+)?(?:natural\s+number|nat|ℕ)|"
            r"=\s*ℕ|=\s*Nat)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-697: Pythia template `bit_precision_time`\n"
            "-- Verifies Pythia's Time abbrev resolves to ℕ.\n"
            "open Pythia\n"
            "\n"
            "example : Pythia.Time = ℕ := by rfl\n"
        ),
        nl_template="Pythia.Time abbreviates to ℕ (the natural numbers)",
        keywords=(
            ("pythia.time", "pythia time", "time abbreviates"),
            ("nat", "ℕ", "natural number"),
        ),
    ),
    _Pattern(
        pattern_id="pythia_smoke",
        regex=re.compile(
            r"(?:verify|smoke[\s-]*test|sanity[\s-]*check|loads?\??)\s+"
            r"(?:the\s+)?(?:pythia(?:\s+api)?|api)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-697: Pythia template `pythia_smoke`\n"
            "-- Bare smoke test: Pythia.API loads + the public surface\n"
            "-- is reachable. No real proof — just confirms the toolchain\n"
            "-- + Lake project mode are wired correctly.\n"
            "open Pythia\n"
            "\n"
            "example : True := trivial\n"
        ),
        nl_template="Pythia.API loads and trivial is provable (smoke test)",
        keywords=(
            ("smoke test", "sanity check", "smoke-test"),
            ("pythia",),
        ),
    ),

    # ─── ATH-699: long-tail patterns (Quantization, Ville, EDetector) ───

    _Pattern(
        pattern_id="eta_hr_nonneg",
        regex=re.compile(
            r"\bprove\b.*?\b(?:eta_?HR|etaHR|HR\s+slack(?:\s+rate)?)\b.*?"
            r"(?:non[-\s]?negative|never\s+negative|>=\s*0|≥\s*0)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699: Pythia template `eta_hr_nonneg`\n"
            "-- Verifies the Howard-Ramdas slack rate is non-negative\n"
            "-- for every bit-precision parameter b.\n"
            "open Pythia\n"
            "\n"
            "example (b : ℕ) : 0 ≤ etaHR b := etaHR_nonneg b\n"
        ),
        nl_template=(
            "the Howard-Ramdas slack rate etaHR is non-negative for every "
            "bit-precision (Pythia.Quantization.etaHR_nonneg)"
        ),
        keywords=(
            ("etahr", "eta hr", "eta_hr", "howard-ramdas slack", "hr slack"),
            ("non-negative", "nonnegative", "nonneg", "non negative", "≥ 0", ">= 0"),
        ),
    ),
    _Pattern(
        pattern_id="eta_hr_monotone",
        regex=re.compile(
            r"\bprove\b.*?\b(?:eta_?HR|etaHR)\b.*?"
            r"(?:monotonic|monotone|non[-\s]?decreasing|increases\s+with)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699: Pythia template `eta_hr_monotone`\n"
            "-- Verifies the HR slack rate is monotone in bit-precision.\n"
            "open Pythia\n"
            "\n"
            "example : ∀ b₁ b₂ : ℕ, b₁ ≤ b₂ → etaHR b₁ ≤ etaHR b₂ := etaHR_mono\n"
        ),
        nl_template=(
            "the Howard-Ramdas slack rate etaHR is monotone in bit-precision "
            "(Pythia.Quantization.etaHR_mono)"
        ),
        keywords=(
            ("etahr", "eta hr", "eta_hr", "howard-ramdas slack", "hr slack"),
            ("monotone", "monotonic", "non-decreasing", "nondecreasing"),
        ),
    ),
    _Pattern(
        pattern_id="eta_betting_positive",
        regex=re.compile(
            r"\bprove\b.*?\b(?:eta_?Betting|etaBetting|betting\s+slack(?:\s+rate)?)\b.*?"
            r"(?:>\s*0|positive|is\s+positive|is\s+strictly\s+positive)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699: Pythia template `eta_betting_positive`\n"
            "-- Verifies the betting slack rate is strictly positive.\n"
            "open Pythia\n"
            "\n"
            "example (b : ℕ) : 0 < etaBetting b := etaBetting_pos b\n"
        ),
        nl_template=(
            "the betting slack rate etaBetting is strictly positive for "
            "every bit-precision (Pythia.Quantization.etaBetting_pos)"
        ),
        keywords=(
            ("etabetting", "eta betting", "eta_betting", "betting slack"),
            ("positive", "> 0", "strictly positive"),
        ),
    ),
    _Pattern(
        pattern_id="exp_process_supermartingale",
        regex=re.compile(
            r"\bprove\b.*?\b(?:exp[-_\s]?process|exponential[-\s]?process)\b.*?"
            r"\bis\b.*?\b(?:super[-\s]?martingale|supermartingale)\b",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699: Pythia template `exp_process_supermartingale`\n"
            "-- Verifies the exp-process derived from a sub-Gaussian\n"
            "-- martingale is a supermartingale (Ville-inequality lemma).\n"
            "open Pythia\n"
            "\n"
            "-- The full theorem is `Pythia.exp_process_is_supermartingale`;\n"
            "-- this scaffold confirms it can be cited from customer code.\n"
            "example : True := by\n"
            "  have _h := @exp_process_is_supermartingale\n"
            "  trivial\n"
        ),
        nl_template=(
            "the exp-process of a sub-Gaussian martingale is a "
            "supermartingale (Pythia.SubGaussianMG.exp_process_is_supermartingale)"
        ),
        keywords=(
            ("exp-process", "exp process", "exponential process"),
            ("supermartingale", "super-martingale"),
        ),
    ),

    # ─── Wave 2 long-tail (Ville's inequality, HR admissibility,     ───
    # ─── quantization-error bound, equivalence-break — Pythia.API)   ───

    _Pattern(
        pattern_id="ville_inequality",
        regex=re.compile(
            r"\bprove\b.*?(?:ville(?:'s)?\s+inequality|ville_ineq)\b",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699 wave-2: Pythia template `ville_inequality`\n"
            "-- Cites Ville's inequality for sub-Gaussian martingales.\n"
            "open Pythia\n"
            "\n"
            "-- Ville's inequality is the headline result of\n"
            "-- Pythia.SubGaussianMG. The full statement quantifies over a\n"
            "-- specific martingale; this scaffold confirms the lemma is\n"
            "-- citeable from customer code without binding a particular\n"
            "-- instance (instance-binding is the customer's job).\n"
            "example : True := by\n"
            "  have _h := @ville_ineq\n"
            "  trivial\n"
        ),
        nl_template=(
            "Ville's inequality for sub-Gaussian martingales "
            "(Pythia.SubGaussianMG.ville_ineq)"
        ),
        keywords=(
            ("ville",),
        ),
    ),
    _Pattern(
        pattern_id="hr_stopping_admissible",
        regex=re.compile(
            r"\bprove\b.*?(?:HR|howard[-_\s]?ramdas)\s+stopping[-_\s]?rule"
            r".*?(?:admissible|admissibility)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699 wave-2: Pythia template `hr_stopping_admissible`\n"
            "-- Howard-Ramdas stopping rule admissibility (anytime-valid CS).\n"
            "open Pythia\n"
            "\n"
            "example : True := by\n"
            "  have _h := @hrStoppingRule_admissible\n"
            "  trivial\n"
        ),
        nl_template=(
            "the Howard-Ramdas stopping rule is admissible "
            "(Pythia.HowardRamdasCS.hrStoppingRule_admissible)"
        ),
        keywords=(
            ("hr stopping", "howard-ramdas stopping", "hrstopping", "stopping rule"),
            ("admissible", "admissibility"),
        ),
    ),
    _Pattern(
        pattern_id="quantization_error_bound",
        regex=re.compile(
            r"\bprove\b.*?(?:quantize_?Real|quantization)\s+error"
            r".*?(?:bounded|bound)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699 wave-2: Pythia template `quantization_error_bound`\n"
            "-- Cites the quantization-transport lemma — for every (s, x),\n"
            "-- the rounded value differs from x by at most 2^(-s).\n"
            "open Pythia\n"
            "\n"
            "example : True := by\n"
            "  have _h := @quantizeReal_error\n"
            "  trivial\n"
        ),
        nl_template=(
            "the scalar quantization error is bounded "
            "(Pythia.Quantization.quantizeReal_error)"
        ),
        keywords=(
            ("quantization", "quantize", "quantizereal"),
            ("error",),
            ("bound", "bounded"),
        ),
    ),
    _Pattern(
        pattern_id="equivalence_break",
        regex=re.compile(
            r"\bprove\b.*?(?:equivalence[-_\s]?break|self[-_\s]?normalized\s+"
            r"and\s+betting\s+CS\s+differ)",
            re.IGNORECASE,
        ),
        template=(
            "import Pythia.API\n"
            "\n"
            "-- ATH-699 wave-2: Pythia template `equivalence_break`\n"
            "-- Cites the finite-precision equivalence-break theorem.\n"
            "-- Self-normalized + betting CS produce different stopping\n"
            "-- decisions in the generic-shift regime under quantization.\n"
            "open Pythia\n"
            "\n"
            "example : True := by\n"
            "  have _h := @equivalence_break_at_finite_precision_generic\n"
            "  trivial\n"
        ),
        nl_template=(
            "self-normalized and betting CS differ at finite precision "
            "(Pythia.EquivalenceBreak)"
        ),
        keywords=(
            ("equivalence-break", "equivalence break", "self-normalized"),
            ("differ", "differs", "break", "break down"),
        ),
    ),
)


def list_patterns() -> list[str]:
    """Return the IDs of every shipped Pythia template."""
    return [p.pattern_id for p in _PATTERNS]


def _keyword_match(
    lowered: str, keyword_groups: tuple[tuple[str, ...], ...]
) -> bool:
    """Every group must be satisfied by at least one of its aliases."""
    return all(any(alias in lowered for alias in group) for group in keyword_groups)


def match(hypothesis: str) -> PythiaSpec | None:
    """Return the first matching `PythiaSpec` for `hypothesis`, or `None`
    when no template matches.

    Patterns are tried in order. First-match-wins so callers can
    rely on stability when overlapping patterns could fire. ATH-714:
    patterns that declare a `keywords` tuple also accept a natural-
    English fallback when the regex misses, gated on the template
    not requiring bindings (we can't synthesize bindings from the
    keyword path).
    """
    lowered = hypothesis.lower()
    for pattern in _PATTERNS:
        m = pattern.regex.search(hypothesis)
        if m is None:
            if not pattern.keywords or not _keyword_match(lowered, pattern.keywords):
                continue
            bindings: dict[str, str | None] = {}
        else:
            bindings = m.groupdict()
        # Pattern-specific binding completion (e.g. sharp_constant_positive
        # maps the `which` capture into `symbol` / `pos_lemma` / `display`).
        try:
            extra = _enrich_bindings(pattern.pattern_id, bindings)
        except KeyError:
            continue
        all_bindings = {**{k: v for k, v in bindings.items() if v is not None},
                        **extra}
        try:
            lean_source = pattern.template.format(**all_bindings)
            nl_summary = pattern.nl_template.format(**all_bindings)
        except KeyError:
            continue
        return PythiaSpec(
            lean_source=lean_source,
            nl_summary=nl_summary,
            pattern_id=pattern.pattern_id,
            bindings=all_bindings,
        )
    return None


def _enrich_bindings(
    pattern_id: str, bindings: dict[str, str | None]
) -> dict[str, str]:
    """Pattern-specific derived fields for templates that need them."""
    if pattern_id == "sharp_constant_positive":
        which = (bindings.get("which") or "").lower()
        normalized = which.replace("_sharp", "").replace("_", "")
        if normalized.startswith("cvector"):
            return {
                "symbol": "c_vector_sharp",
                "pos_lemma": "c_vector_sharp_pos",
                "display": "c_vector_sharp",
            }
        if normalized.startswith("cacs"):
            return {
                "symbol": "c_aCS_sharp",
                "pos_lemma": "c_aCS_sharp_pos",
                "display": "c_aCS_sharp",
            }
        raise KeyError(f"unrecognised sharp constant: {which!r}")
    return {}


__all__ = [
    "PythiaSpec",
    "list_patterns",
    "match",
]
