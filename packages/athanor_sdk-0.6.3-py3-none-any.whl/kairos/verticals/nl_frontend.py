"""kairos.verticals.nl_frontend — natural-language → IntentV1 template.

Slice-1 scope (2026-04-23 overnight E2E, general-not-niche directive):
**deterministic template**, no LLM. Customer types a free-text hypothesis
+ vertical hint, we emit a valid IntentV1 dict that can feed straight
into :meth:`kairos.spec.pipeline.SpecPipeline.run`.

Slice-2 will bolt on an LLM extraction stage (via kairos.fleet.Orchestrator
post-ATH-570) that turns truly free-form prose into IntentV1. For now
the template covers the customer-1 flow:

    from kairos.verticals import nl_frontend
    intent = nl_frontend.nl_to_intent(
        "prove reno_cca cwnd never drops below MSS",
        vertical="ebmc",
        target_file="reno.sv",
        target_name="p_cwnd_ge_mss",
    )
    # intent is a dict conforming to SpecV1 1.1 (see spec_schema.json)

Design:

* **No LLM.** Zero fleet spend. Customers who want free-form NL →
  structured intent call a hypothetical slice-2 layer; we deliberately
  keep the slice-1 shape deterministic + cheap.
* **Vertical-aware defaults.** Each registered vertical can register
  an IntentV1 template under ``_VERTICAL_TEMPLATES``. Customers override
  fields via the ``overrides`` kwarg.
* **Round-trip-able.** The returned dict passes
  :func:`kairos.spec.types.validate_intent_v1` (when available); the
  goal is that ``SpecPipeline(orchestrator=...).run(intent)`` succeeds
  for every return value of ``nl_to_intent``.
"""
from __future__ import annotations

import re
from typing import Any


_DEFAULT_BUDGET = {"wall_seconds": 600, "usd": 3.00}

# Per-vertical templates. Adding a vertical = adding an entry here.
# Keep each template minimal + overridable; customer tools can provide
# richer templates by patching this dict at import time.
_VERTICAL_TEMPLATES: dict[str, dict[str, Any]] = {
    "ebmc": {
        "planner_role": "sv_bmc_prover_generic",
        "vertical": "ebmc",
        "evidence_tier": "bmc_bounded",
        "bound_k": 10,
        "artifacts_expected": ["counterexample", "transcript"],
    },
    "lean": {
        "planner_role": "lean_theorem_prover_generic",
        "vertical": "lean",
        "evidence_tier": "lean_proved",
        "artifacts_expected": ["proof", "transcript"],
    },
}


def supported_verticals() -> tuple[str, ...]:
    """Verticals this frontend can template intents for."""
    return tuple(sorted(_VERTICAL_TEMPLATES))


def _slugify(text: str, *, maxlen: int = 60) -> str:
    """Emit a snake-case slug from free-text, capped at ``maxlen``."""
    slug = re.sub(r"[^A-Za-z0-9]+", "_", text.strip().lower()).strip("_")
    return slug[:maxlen] or "unnamed"


def nl_to_intent(
    hypothesis: str,
    *,
    vertical: str,
    target_file: str,
    target_name: str | None = None,
    target_kind: str = "theorem",
    bound_k: int | None = None,
    budget: dict | None = None,
    overrides: dict | None = None,
) -> dict:
    """Render a natural-language hypothesis into an IntentV1 dict.

    Args:
        hypothesis: free-text claim the customer wants proved/refuted,
            e.g. "prove reno_cca.cwnd never drops below MSS on reset".
        vertical: one of :func:`supported_verticals`.
        target_file: path to the artifact (SV source, Lean file, etc.).
        target_name: optional declared name of the property/theorem; if
            omitted, derived by slugifying the hypothesis.
        target_kind: ``'theorem'`` / ``'lemma'`` / ``'property'`` /
            ``'integration'`` (SpecV1 1.1 open enum).
        bound_k: BMC bound override (sv_cbmc only; otherwise ignored).
        budget: override the default wall-seconds + usd budget.
        overrides: extra fields merged into the final intent dict.
            Use for customer-specific 'meta' tags, hints, banned_tactics.

    Returns:
        A dict conforming to SpecV1 1.1. Drop straight into
        :meth:`SpecPipeline.run` — no separate validation step needed
        at this layer (validation happens inside SpecPipeline).

    Raises:
        ValueError: if ``vertical`` is not registered.
    """
    if vertical not in _VERTICAL_TEMPLATES:
        raise ValueError(
            f"unknown vertical {vertical!r}; supported: "
            f"{supported_verticals()}. Register a template in "
            f"kairos.verticals.nl_frontend._VERTICAL_TEMPLATES to extend."
        )

    template = dict(_VERTICAL_TEMPLATES[vertical])
    resolved_name = target_name or _slugify(hypothesis)
    intent: dict[str, Any] = {
        "intent_version": "1.1",
        "target": {
            "file": target_file,
            "name": resolved_name,
            "kind": target_kind,
        },
        "goal": {
            "hypothesis": hypothesis,
            "lemma_closed": True,
        },
        "budget": dict(budget or _DEFAULT_BUDGET),
        "meta": {"source": "nl_frontend", "slice": 1},
        **template,
    }

    if bound_k is not None and vertical == "ebmc":
        intent["bound_k"] = int(bound_k)

    if overrides:
        # Shallow merge; customer can override any top-level field.
        intent.update(overrides)

    return intent
