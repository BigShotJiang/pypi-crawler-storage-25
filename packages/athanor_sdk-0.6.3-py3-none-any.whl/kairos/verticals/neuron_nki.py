"""kairos.verticals.neuron_nki — NKI kernel VerifierPlugin.

Registered under tier_name ``nki_kernel``. Wraps a customer-supplied
NKI kernel bundle (the shape shipped under
``solve/neuron/catalog/<date>/<kernel>/``) as a
:class:`VerifierPlugin`-shaped object so the built-in pipeline can
dispatch to NKI when the customer's intent calls for kernel-port
verification (AWS Neuron NKI customers: fused attention, softmax,
matmul, Flash-style kernels).

The plugin reads the witness dict for:

* ``bundle_path`` (required) — absolute or cwd-relative path to a
  directory containing ``verify.py`` + ``kernel.py`` + optionally
  ``reports/*.json``.
* ``timeout_sec`` (optional, default 300) — wall-clock timeout.

Verdict mapping:

* ``verify.py`` exits 0 AND every report JSON under ``reports/``
  shows ``pass=true`` (or no reports are shipped) →
  ``Verdict.outcome='proved'``, ``details['reports']`` carries the
  per-report booleans.
* ``verify.py`` exits non-zero → ``outcome='refuted'``,
  ``details['exit_code']`` + ``details['stderr_tail']`` for triage.
* ``verify.py`` times out → ``outcome='unknown'``,
  ``details['timed_out']=True``.
* Bundle missing verify.py or kernel.py → ``outcome='error'``,
  ``reason`` names the missing file.

Cross-ref:
  * athanor-builder/solve/neuron/catalog/<date>/<kernel>/verify.py —
    the actual harness (property tests + fuzz + mutation + Lean-disclosure).
  * kairos.ebmc.SysVerilogEBMCPlugin — same Protocol,
    different backend.
  * kairos.spec.types.VerifierPlugin — Protocol contract.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

from kairos.spec.types import Counterexample, Verdict


TIER_NAME = "nki_kernel"

# Canonical reports the kernel bundle may ship. Absence is OK; presence
# with a non-pass result is a refutation signal beyond what verify.py's
# exit code reports.
_REPORT_FILES = (
    "summary.json",
    "test_report.json",
    "fuzz_report.json",
    "mutation_report.json",
)


class NeuronNKIPlugin:
    """VerifierPlugin that runs a NKI kernel bundle's verify.py.

    :purity: IMPURE_SIDE_EFFECTFUL  — shells out to ``python3 verify.py``
             inside the bundle, reads JSON reports, writes no persistent
             state outside the bundle's ``reports/`` directory.
    """

    tier_name: str = TIER_NAME
    # ATH-526: real verifier — shells out to bundle's verify.py + parses
    # JSON reports.
    is_stub: bool = False

    def verify(
        self,
        intent: Mapping[str, Any],
        witness: Mapping[str, Any],
        *,
        timeout_sec: float | None = None,
    ) -> Verdict:
        """Dispatch the bundle's verify.py against the kernel + reference."""
        # Witness takes priority; fall back to intent.target.file's parent
        # directory (nl_frontend sets target.file to the kernel.py path;
        # bundle_path is the parent containing verify.py + kernel.py +
        # reports/).
        from typing import Mapping as _M
        bundle_raw = witness.get("bundle_path")
        if not bundle_raw and isinstance(intent, _M):
            tf = intent.get("target", {}).get("file")
            if tf:
                # If intent.target.file is a .py file, bundle is its parent.
                tfp = Path(tf)
                bundle_raw = str(tfp.parent if tfp.suffix == ".py" else tfp)
        if not bundle_raw:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "neither witness['bundle_path'] nor intent.target.file "
                    "set — cannot run verify.py. Pass bundle_path as a dir."
                ),
                details={"missing_field": "bundle_path"},
            )

        # Resolve to absolute so the subprocess invocation below works
        # regardless of caller cwd. Without this, a relative bundle
        # path doubles up: cwd=bundle + script_arg=bundle/verify.py
        # turns into bundle/bundle/verify.py at exec time, exits with
        # "No such file or directory", and the bundle is mis-classified
        # as refuted with exit_code=2.
        bundle = Path(bundle_raw).resolve()
        if not bundle.is_dir():
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"bundle_path is not a directory: {bundle!s}",
                details={"bundle_path": str(bundle)},
            )

        verify_py = bundle / "verify.py"
        kernel_py = bundle / "kernel.py"
        if not verify_py.exists():
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"bundle missing verify.py: {verify_py!s}",
                details={"missing_file": "verify.py", "bundle_path": str(bundle)},
            )
        if not kernel_py.exists():
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"bundle missing kernel.py: {kernel_py!s}",
                details={"missing_file": "kernel.py", "bundle_path": str(bundle)},
            )

        resolved_timeout = int(
            timeout_sec if timeout_sec is not None
            else witness.get("timeout_sec", 300)
        )

        try:
            proc = subprocess.run(
                [sys.executable, str(verify_py)],
                cwd=str(bundle),
                capture_output=True,
                text=True,
                timeout=resolved_timeout,
            )
        except subprocess.TimeoutExpired:
            return Verdict(
                source=TIER_NAME, outcome="unknown",
                reason=(
                    f"verify.py timed out after {resolved_timeout}s on "
                    f"bundle {bundle.name!r}. Raise --timeout-sec to retry."
                ),
                details={
                    "timed_out": True,
                    "bundle_path": str(bundle),
                    "timeout_sec": resolved_timeout,
                },
            )
        except FileNotFoundError as exc:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"python3 not found: {exc}",
                details={"exception": "FileNotFoundError"},
            )

        # Parse any report JSONs the bundle ships; aggregate pass/fail
        # signals to compose the final verdict.
        reports: dict[str, Any] = {}
        reports_dir = bundle / "reports"
        for name in _REPORT_FILES:
            p = reports_dir / name
            if not p.exists():
                continue
            try:
                reports[name] = json.loads(p.read_text())
            except (OSError, json.JSONDecodeError) as exc:
                reports[name] = {"_parse_error": str(exc)}

        report_pass_flags = _collect_report_pass_flags(reports)

        if proc.returncode == 0 and all(report_pass_flags.values()):
            return Verdict(
                source=TIER_NAME, outcome="proved",
                reason=(
                    f"NKI bundle {bundle.name!r} verified clean — "
                    f"verify.py exit=0; {len(report_pass_flags)} report(s) pass."
                ),
                details={
                    "bundle_path": str(bundle),
                    "exit_code": 0,
                    "reports_pass": report_pass_flags,
                    "reports": reports,
                },
            )

        # Non-zero exit OR any report says fail.
        failed_reports = [name for name, passed in report_pass_flags.items() if not passed]
        if failed_reports:
            summary = (
                f"NKI bundle {bundle.name!r} failed {len(failed_reports)} "
                f"report(s): {', '.join(failed_reports[:3])}"
                f"{'...' if len(failed_reports) > 3 else ''}"
            )
        else:
            summary = (
                f"NKI bundle {bundle.name!r} verify.py exit={proc.returncode}"
            )
        stderr_tail = proc.stderr[-500:] if proc.stderr else ""
        return Verdict(
            source=TIER_NAME, outcome="refuted",
            reason=(
                f"NKI bundle {bundle.name!r} failed verification — "
                f"verify.py exit={proc.returncode}; see details for "
                f"report pass flags + stderr tail."
            ),
            details={
                "bundle_path": str(bundle),
                "exit_code": proc.returncode,
                "reports_pass": report_pass_flags,
                "reports": reports,
                "stderr_tail": stderr_tail,
                "counterexample": Counterexample(
                    kind="process_failure",
                    summary=summary,
                    payload={
                        "exit_code": proc.returncode,
                        "reports_pass": dict(report_pass_flags),
                        "stderr_tail": stderr_tail,
                    },
                ),
            },
        )


def _collect_report_pass_flags(reports: Mapping[str, Any]) -> dict[str, bool]:
    """Extract a per-report pass bool from the bundle's JSON reports.

    Reports ship in a few shapes; we accept the common ones:
      * ``{"pass": bool}`` — canonical (test_report, mutation_report).
      * ``{"overall_pass": bool}`` — summary.json shape in some bundles.
      * ``{"status": "pass"/"fail"}`` — string-shape some agents emit.
      * ``{"kill_rate": float, "pass_threshold": float}`` — mutation shape.

    Missing / malformed → absent from the returned dict rather than False,
    so the aggregator ("all True") isn't tripped by reports that simply
    don't exist in this bundle.
    """
    flags: dict[str, bool] = {}
    for name, body in reports.items():
        if not isinstance(body, dict) or "_parse_error" in body:
            continue
        if "pass" in body and isinstance(body["pass"], bool):
            flags[name] = body["pass"]
            continue
        if "overall_pass" in body and isinstance(body["overall_pass"], bool):
            flags[name] = body["overall_pass"]
            continue
        status = body.get("status")
        if isinstance(status, str):
            flags[name] = status.lower() == "pass"
            continue
        # Mutation-report shape: kill_rate >= threshold.
        kr = body.get("kill_rate")
        thr = body.get("pass_threshold", 0.75)
        if isinstance(kr, (int, float)) and isinstance(thr, (int, float)):
            flags[name] = kr >= thr
            continue
        # Unknown shape — don't gate on it.
    return flags
