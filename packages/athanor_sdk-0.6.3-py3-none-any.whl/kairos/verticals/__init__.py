"""kairos.verticals — built-in VerifierPlugin registrations.

Import this module (`import kairos.verticals`) to populate the
shared ``kairos.spec.pipeline.DEFAULT_REGISTRY`` with the SDK-shipped
built-in plugins. Customer plugins can register alongside; this
module only contains the plugins we ship + dogfood on.

Built-in verticals (2026-04-23, ATH-510 overnight E2E + Stream C):

  * ``kairos.ebmc``
    — SysVerilog + EBMC (bounded model checking) verifier. Wraps
      :mod:`kairos.sv.ebmc` + :mod:`kairos.sv.prove`. Tier name
      ``bmc_bounded``. Used for congestion-control (BBRv3 / CUBIC /
      Reno) + HW-verification customer demos.

  * ``kairos.verticals.neuron_nki``
    — NKI kernel verification. Wraps a bundle of ``verify.py`` +
      ``kernel.py`` + ``reports/*.json`` (shape shipped by
      ``solve/neuron/catalog/<date>/<kernel>/``). Tier name
      ``nki_kernel``. Used for AWS Neuron kernel port verification.

  * ``kairos.verticals.lean``
    — Lean 4 proof verification. Wraps :mod:`kairos.lean`
      (``verify_proof`` + banned-construct + sorry-scan). Tier name
      ``lean_proved``. Used for formal-theorem verification across
      every vertical that ships proofs alongside code.

Design rules (per 2026-04-23 Aidan general-not-niche directive):

  * Built-ins are thin adapters. Customers can swap them out wholesale
    via ``SpecPipeline(verifier_registry=my_registry)``. No hardcoded
    customer assumptions.
  * Zero new dependencies. Each vertical only imports from
    ``kairos.spec.types`` + its own ``kairos.<vertical>`` module.
  * Registration is explicit, not auto-magic. Customers who want the
    defaults call ``kairos.verticals.register_defaults()``; those who
    want a curated subset register individual plugins by hand.

Usage:

    import kairos.verticals
    from kairos.spec.pipeline import SpecPipeline, DEFAULT_REGISTRY

    kairos.verticals.register_defaults()
    pipeline = SpecPipeline()  # now has ebmc registered
    result = pipeline.run(intent)
"""
from __future__ import annotations

from kairos.spec.pipeline import DEFAULT_REGISTRY
from kairos.verticals.lean import LeanProofPlugin
from kairos.verticals.neuron_nki import NeuronNKIPlugin
from kairos.ebmc import SysVerilogEBMCPlugin

__all__ = [
    "LeanProofPlugin",
    "NeuronNKIPlugin",
    "SysVerilogEBMCPlugin",
    "register_defaults",
]


def register_defaults() -> None:
    """Register every SDK-shipped VerifierPlugin into
    :data:`kairos.spec.pipeline.DEFAULT_REGISTRY`.

    Idempotent — safe to call multiple times. A tier_name already
    registered (even with a different plugin instance of the same
    class) is skipped rather than raising; the first registration
    wins. Customers who want to override a built-in must use a
    per-pipeline ``VerifierRegistry`` instance passed explicitly to
    ``SpecPipeline(verifier_registry=...)`` — never re-register into
    the module-global.

    ATH-526: stub-mode plugins (``is_stub=True``) are skipped here so
    customers who call ``register_defaults()`` don't pick up a
    placeholder by accident. To use a stub plugin (e.g. the cedar
    fleet plugin during impl-pending phase), register it explicitly
    via ``DEFAULT_REGISTRY.register(CedarDiffTestedPlugin())``.
    """
    plugins = [
        SysVerilogEBMCPlugin(),
        NeuronNKIPlugin(),
        LeanProofPlugin(),
    ]
    already_registered = set(DEFAULT_REGISTRY.registered_tiers())
    for plugin in plugins:
        if getattr(plugin, "is_stub", False):
            continue  # ATH-526: stub plugins require explicit opt-in.
        if plugin.tier_name in already_registered:
            continue  # Idempotent — first-registration wins.
        DEFAULT_REGISTRY.register(plugin)
