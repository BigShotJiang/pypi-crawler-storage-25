"""ATH-1202: `kairos init aws` — top-level AWS-everything onboarding wizard.

Chains ATH-1199 (Bedrock key) + ATH-1200 (S3 trace bucket) + ATH-1201
(Postgres run-history) into a single 5-prompt onboarding for customers
who have AWS credentials + a budget but are NOT AWS experts.

Design principles (asabi 2026-05-13):
1. Athanor-domain language, NOT AWS-domain. "Trace storage" not "S3
   bucket"; "run-history database" not "RDS instance".
2. Defaults Just Work. Bucket auto-created with sane defaults. Aurora
   conn auto-tested. Bedrock model is the canonical proposer.
3. Errors framed as next-command actions ("Run `kairos config s3
   --check`" not "AccessDenied 403").
4. No AWS jargon in default prompts. `--advanced` flag exposes
   AWS-jargon options for power users.
5. Idempotent. Re-running `kairos init aws` skips already-configured
   entries unless they fail re-verification.
"""
from __future__ import annotations

from typing import Callable, Optional


# I/O is parameterized so tests can inject a fake input/output pair.
# Default uses stdin / stdout via builtins.
InputFn = Callable[[str], str]
PrintFn = Callable[[str], None]


_DEFAULT_BEDROCK_MODEL = "bedrock/anthropic.claude-3-5-sonnet-20241022-v2:0"


def _default_input(prompt: str) -> str:
    return input(prompt)


def _default_print(line: str) -> None:
    print(line)


def _secret_input(prompt: str) -> str:
    """Read a secret without echoing. Falls back to plain input if
    getpass is unavailable (test envs, CI without a tty)."""
    try:
        import getpass
        return getpass.getpass(prompt)
    except Exception:  # noqa: BLE001
        return input(prompt)


def run_init_aws_wizard(
    *,
    advanced: bool = False,
    input_fn: Optional[InputFn] = None,
    print_fn: Optional[PrintFn] = None,
    secret_input_fn: Optional[InputFn] = None,
) -> int:
    """Run the 5-prompt AWS onboarding wizard.

    Returns: 0 on completion (even if some steps were skipped); non-zero
    only on hard failures (e.g., config-file write denied).

    `advanced=True` enables AWS-jargon options (explicit IAM ARN entry,
    SSL mode override, bucket prefix override).
    """
    inp = input_fn or _default_input
    pr = print_fn or _default_print
    sec = secret_input_fn or _secret_input

    pr("")
    pr("Welcome. This sets up Kairos to run on your AWS account.")
    pr("You'll need: an AWS access key + secret + region.")
    pr("")

    # Step 1: AWS credentials (env-only; persistence happens via Bedrock
    # below + S3 boto3 picks them up from the same chain).
    pr("Step 1 of 4: AWS credentials")
    _ = inp("? AWS access key (or press enter to use existing env / "
            "~/.aws/credentials): ")
    # Note: we don't persist the raw AWS creds — boto3's standard
    # credential chain handles them. If customer pasted a value, prompt
    # them to export it as AWS_ACCESS_KEY_ID for this shell session.
    # The actual key persistence happens in step 2 (bedrock-key).
    pr("  (AWS access key + secret read from your env or ~/.aws/credentials. "
       "Run `aws configure` if you haven't set them up yet.)")
    pr("")

    # Step 2: Bedrock model key (ATH-1199)
    pr("Step 2 of 4: Bedrock API key for LLM calls")
    pr("  (This is the Amazon Bedrock API key, not the AWS access key.)")
    pr("  (Press enter to skip if you've already set this via "
       "`kairos config set bedrock-key`.)")
    bedrock_key = sec("? Bedrock API key: ")
    if bedrock_key and bedrock_key.strip():
        try:
            from kairos.config import set_bedrock_key, bedrock_key_fingerprint
            set_bedrock_key(bedrock_key)
            pr(f"  ✓ Bedrock key stored ({bedrock_key_fingerprint()}).")
        except ValueError as e:
            pr(f"  ✗ {e}")
        except Exception as e:  # noqa: BLE001
            pr(f"  ✗ failed to persist bedrock key: {e}")
    else:
        pr("  (skipped — using existing config / env)")
    pr("")

    # Step 3: S3 trace storage (ATH-1200)
    pr("Step 3 of 4: Trace storage bucket (S3)")
    pr("  (Kairos uploads run traces to your S3 bucket. "
       "Press enter to skip — traces stay local.)")
    bucket_default = "acme-kairos-traces" if advanced else ""
    bucket = inp(f"? Trace storage bucket name "
                 f"{'[' + bucket_default + ']: ' if bucket_default else ': '}")
    bucket = (bucket or bucket_default).strip()
    if bucket:
        region = inp("? AWS region for the bucket [us-east-1]: ").strip() or "us-east-1"
        try:
            from kairos.config import set_s3_trace_bucket
            set_s3_trace_bucket(bucket, region=region)
            pr(f"  ✓ Trace storage bucket configured "
               f"(s3://{bucket}, {region}).")
            pr("  (Run `kairos config s3 " + bucket +
               "` to verify with boto3 + check IAM policy.)")
        except ValueError as e:
            pr(f"  ✗ {e}")
        except Exception as e:  # noqa: BLE001
            pr(f"  ✗ failed to persist bucket: {e}")
    else:
        pr("  (skipped — traces stay in ~/.athanor/runs/<run-id>/)")
    pr("")

    # Step 4: Run-history database (ATH-1201) — optional
    pr("Step 4 of 4: Run-history database (Postgres / Aurora / RDS)")
    pr("  (Optional. Kairos can store run history in your Postgres-")
    pr("   compatible database. Press enter to use the local SQLite")
    pr("   fallback at ~/.athanor/runs.sqlite.)")
    if advanced:
        pr("  Format: postgresql://user:password@host:5432/dbname")
    conn = inp("? Run-history database conn string (or enter to skip): ").strip()
    if conn:
        try:
            from kairos.config import set_db_url, db_url_redacted
            set_db_url(conn)
            pr(f"  ✓ Run-history database configured ({db_url_redacted()}).")
            pr("  (Run `kairos config db <conn>` to verify with psycopg2 + "
               "create schema.)")
        except ValueError as e:
            pr(f"  ✗ {e}")
        except Exception as e:  # noqa: BLE001
            pr(f"  ✗ failed to persist conn string: {e}")
    else:
        pr("  (skipped — using local SQLite at ~/.athanor/runs.sqlite)")
    pr("")

    # Summary + next steps.
    pr("Setup complete. Run `kairos doctor` to verify all configured")
    pr("paths against your live AWS environment, or `kairos solve")
    pr("<your-design>.sv` to start a verification run.")
    pr("")
    pr("To change any setting later:")
    pr("  kairos config set bedrock-key <key>")
    pr("  kairos config s3 <bucket> [--region <r>]")
    pr("  kairos config db <postgres-conn>")
    pr("")
    return 0


__all__ = ["run_init_aws_wizard"]
