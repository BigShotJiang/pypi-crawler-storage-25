"""VerdictTier enum + typed result dataclasses (ATH-999 Child E).

Honest-framing-as-types: the type system refuses to render
TESTS_PASSED as PROVED. Each tier is a distinct dataclass so
cert-emit code cannot accidentally conflate verification strengths.

Tiers ordered strongest-to-weakest (overall_tier relies on this):

  THEOREM_PROVED      — Lean/Coq kernel-checked proof, no sorry
  EBMC_PROVED         — EBMC k-induction, no assumptions
  EQUIV_PROVED        — yosys combinational equivalence (SAT miter)
  EBMC_PROVED_ASSUME  — EBMC proved under explicit assumptions
  BOUNDED_PROVED      — BMC up to depth k, not unbounded
  TESTS_PASSED        — property-based or unit tests passed
  INCONCLUSIVE        — engine returned unknown / timeout
  REFUTED             — engine found a counterexample
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence


class VerdictTier(str, Enum):
    # Enum members MUST be ordered strongest-to-weakest;
    # overall_tier relies on index ordering.
    THEOREM_PROVED = "theorem_proved"
    EBMC_PROVED = "ebmc_proved"
    EQUIV_PROVED = "equiv_proved"
    EBMC_PROVED_ASSUME = "ebmc_proved_assume"
    BOUNDED_PROVED = "bounded_proved"
    TESTS_PASSED = "tests_passed"
    INCONCLUSIVE = "inconclusive"
    REFUTED = "refuted"

    @property
    def is_proved(self) -> bool:
        return self in (
            VerdictTier.THEOREM_PROVED,
            VerdictTier.EBMC_PROVED,
            VerdictTier.EQUIV_PROVED,
            VerdictTier.EBMC_PROVED_ASSUME,
            VerdictTier.BOUNDED_PROVED,
        )

    @property
    def cert_label(self) -> str:
        return _CERT_LABELS[self]


_CERT_LABELS: dict[VerdictTier, str] = {
    VerdictTier.THEOREM_PROVED: "PROVED (theorem, kernel-checked)",
    VerdictTier.EBMC_PROVED: "PROVED (k-induction, standalone)",
    VerdictTier.EQUIV_PROVED: "PROVED (combinational equivalence)",
    VerdictTier.EBMC_PROVED_ASSUME: "PROVED (k-induction, with assumptions)",
    VerdictTier.BOUNDED_PROVED: "PROVED (bounded, depth k)",
    VerdictTier.TESTS_PASSED: "TESTS PASSED (not formally proved)",
    VerdictTier.INCONCLUSIVE: "INCONCLUSIVE",
    VerdictTier.REFUTED: "REFUTED (counterexample found)",
}


@dataclass(frozen=True)
class PropertyVerdict:
    property_name: str
    tier: VerdictTier
    engine: str
    details: str = ""
    assumptions: tuple[str, ...] = ()
    bound_depth: int | None = None


@dataclass(frozen=True)
class CertResult:
    module_name: str
    verdicts: Sequence[PropertyVerdict]
    run_id: str = ""
    area_delta_pct: float | None = None
    lean_theorems: tuple[str, ...] = ()

    @property
    def overall_tier(self) -> VerdictTier:
        if not self.verdicts:
            return VerdictTier.INCONCLUSIVE
        tiers = [v.tier for v in self.verdicts]
        if VerdictTier.REFUTED in tiers:
            return VerdictTier.REFUTED
        if VerdictTier.INCONCLUSIVE in tiers:
            return VerdictTier.INCONCLUSIVE
        tier_order = list(VerdictTier)
        return max(tiers, key=lambda t: tier_order.index(t))

    @property
    def all_proved(self) -> bool:
        return all(v.tier.is_proved for v in self.verdicts)

    @property
    def has_assumptions(self) -> bool:
        return any(v.assumptions for v in self.verdicts)

    @property
    def assumption_stack(self) -> tuple[str, ...]:
        seen: set[str] = set()
        result: list[str] = []
        for v in self.verdicts:
            for a in v.assumptions:
                if a not in seen:
                    seen.add(a)
                    result.append(a)
        return tuple(result)
