"""Cert emission gates (ATH-999 Child F).

Runtime gates that validate a CertResult before a certificate can be
emitted. Each gate returns a list of violations; an empty list means
the gate passed. Customers call run_all_gates() which raises
CertGateError if any gate fails.

Gates mirror the build-tarball.sh Gate 1-5 + the third-instance
assumption-stack-disclosure gate + area-delta-vs-verdict consistency.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from kairos.cert.verdict_tier import CertResult, VerdictTier


@dataclass(frozen=True)
class GateViolation:
    gate_name: str
    message: str


class CertGateError(Exception):
    def __init__(self, violations: Sequence[GateViolation]) -> None:
        self.violations = list(violations)
        msgs = "; ".join(f"[{v.gate_name}] {v.message}" for v in violations)
        super().__init__(f"Cert emission blocked: {msgs}")


def gate_no_refuted(result: CertResult) -> list[GateViolation]:
    refuted = [v for v in result.verdicts if v.tier == VerdictTier.REFUTED]
    if refuted:
        names = ", ".join(v.property_name for v in refuted)
        return [GateViolation("no_refuted", f"refuted properties: {names}")]
    return []


def gate_no_inconclusive(result: CertResult) -> list[GateViolation]:
    inconclusive = [v for v in result.verdicts if v.tier == VerdictTier.INCONCLUSIVE]
    if inconclusive:
        names = ", ".join(v.property_name for v in inconclusive)
        return [GateViolation("no_inconclusive", f"inconclusive properties: {names}")]
    return []


def gate_assumptions_disclosed(result: CertResult) -> list[GateViolation]:
    undisclosed = []
    for v in result.verdicts:
        if v.tier == VerdictTier.EBMC_PROVED_ASSUME and not v.assumptions:
            undisclosed.append(v.property_name)
    if undisclosed:
        names = ", ".join(undisclosed)
        return [GateViolation(
            "assumptions_disclosed",
            f"EBMC_PROVED_ASSUME without listed assumptions: {names}",
        )]
    return []


def gate_area_delta_consistent(result: CertResult) -> list[GateViolation]:
    if result.area_delta_pct is None:
        return []
    if not result.all_proved and result.area_delta_pct != 0.0:
        return [GateViolation(
            "area_delta_consistent",
            f"area_delta_pct={result.area_delta_pct} but not all properties proved",
        )]
    return []


def gate_not_empty(result: CertResult) -> list[GateViolation]:
    if not result.verdicts:
        return [GateViolation("not_empty", "no property verdicts")]
    return []


def gate_tests_not_labeled_proved(result: CertResult) -> list[GateViolation]:
    violators = [
        v.property_name for v in result.verdicts
        if v.tier == VerdictTier.TESTS_PASSED and "proved" in v.details.lower()
    ]
    if violators:
        names = ", ".join(violators)
        return [GateViolation(
            "tests_not_labeled_proved",
            f"TESTS_PASSED verdicts with 'proved' in details: {names}",
        )]
    return []


_ALL_GATES = [
    gate_not_empty,
    gate_no_refuted,
    gate_no_inconclusive,
    gate_assumptions_disclosed,
    gate_area_delta_consistent,
    gate_tests_not_labeled_proved,
]


def run_all_gates(result: CertResult) -> list[GateViolation]:
    violations: list[GateViolation] = []
    for gate in _ALL_GATES:
        violations.extend(gate(result))
    return violations


def require_gates(result: CertResult) -> None:
    violations = run_all_gates(result)
    if violations:
        raise CertGateError(violations)
