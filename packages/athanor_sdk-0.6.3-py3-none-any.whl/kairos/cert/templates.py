"""Cert templates for customer-facing certificates (ATH-999 Child G).

Templates consume a CertResult (typed, gate-checked) and emit
customer-readable Markdown. Each template is a pure function:
CertResult -> str. The type system ensures TESTS_PASSED cannot
be rendered as PROVED because VerdictTier.cert_label encodes the
distinction.

Templates:
  sec_block_certificate  — SEC area-optimization loop certificate
  nki_kernel_certificate — NKI compute-kernel verification certificate
  generic_certificate    — domain-agnostic fallback
"""
from __future__ import annotations

from datetime import datetime, timezone

from kairos.cert.verdict_tier import CertResult, VerdictTier


def sec_block_certificate(result: CertResult) -> str:
    return _render(result, title="SEC Area-Optimization Certificate")


def nki_kernel_certificate(result: CertResult) -> str:
    return _render(result, title="NKI Kernel Verification Certificate")


def generic_certificate(result: CertResult) -> str:
    return _render(result, title="Verification Certificate")


def _render(result: CertResult, *, title: str) -> str:
    lines: list[str] = []
    lines.append(f"# {title} -- {result.module_name}")
    lines.append("")
    lines.append(f"**Overall verdict**: {result.overall_tier.cert_label}")
    lines.append("")
    if result.run_id:
        lines.append(f"**Run ID**: `{result.run_id}`")
        lines.append("")
    if result.area_delta_pct is not None:
        lines.append(f"**Area delta**: {result.area_delta_pct:.1f}%")
        lines.append("")

    lines.append("## Per-property verdicts")
    lines.append("")
    lines.append("| Property | Verdict | Engine | Assumptions |")
    lines.append("|----------|---------|--------|-------------|")
    for v in result.verdicts:
        assumptions = ", ".join(v.assumptions) if v.assumptions else "--"
        bound = f" (depth {v.bound_depth})" if v.bound_depth is not None else ""
        lines.append(
            f"| `{v.property_name}` | {v.tier.cert_label}{bound} "
            f"| {v.engine} | {assumptions} |"
        )
    lines.append("")

    if result.has_assumptions:
        lines.append("## Assumption stack")
        lines.append("")
        lines.append(
            "Each entry below is an assumption the verification step"
            " relied on. These are UNPROVEN until independently discharged."
        )
        lines.append("")
        for a in result.assumption_stack:
            lines.append(f"- {a}")
        lines.append("")

    if result.lean_theorems:
        lines.append("## Lean theorems")
        lines.append("")
        for thm in result.lean_theorems:
            lines.append(f"- `{thm}`")
        lines.append("")

    n_proved = sum(1 for v in result.verdicts if v.tier.is_proved)
    n_refuted = sum(1 for v in result.verdicts if v.tier == VerdictTier.REFUTED)
    n_inconclusive = sum(1 for v in result.verdicts if v.tier == VerdictTier.INCONCLUSIVE)
    n_tests = sum(1 for v in result.verdicts if v.tier == VerdictTier.TESTS_PASSED)

    lines.append("## Counts")
    lines.append("")
    lines.append(f"- Proved: {n_proved}")
    if n_tests:
        lines.append(f"- Tests passed (not proved): {n_tests}")
    lines.append(f"- Refuted: {n_refuted}")
    lines.append(f"- Inconclusive: {n_inconclusive}")
    lines.append(f"- Total: {len(result.verdicts)}")
    lines.append("")

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines.append(f"*Generated {ts} by kairos.cert*")
    lines.append("")
    return "\n".join(lines)
