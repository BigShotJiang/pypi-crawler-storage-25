"""Cert-authoring-time engine-output cross-check (ATH-1018).

The "did you re-run, or did you remember?" rule per the
`prior-run-carry-over` instance-1 sub-shape memory entry. Greps a
customer-block-certificate's prose for per-property verdict claims
+ re-derives the engine output from the bundle's inputs +
diffs. Mismatches fail-loud at cert-authoring time.

Today's v0 covers SEC verdict claims (PROVED-standalone /
PROVED-with-assume / REFUTED / INCONCLUSIVE on
``sec_miter.<property_name>``). NKI kernel verdicts + closed-loop
PPA-delta cross-checks land in v1+ as the cluster of cert types
expands.

Honest-framing rule applied here: cert prose is the customer-
facing claim; engine output is the source-of-truth. When they
disagree, the engine wins + the cert is rejected. The cert author
must either re-run + capture the new engine output OR correct the
cert prose to match the engine.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping, Sequence


# ───────────────────────────────────────────────────────────────────
# Datatypes
# ───────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CertVerdictClaim:
    """A single per-property verdict claim extracted from cert prose.

    Attributes
    ----------
    target_property:
        The SEC miter property the claim is about (e.g.
        ``"sec_miter.full_match"``).
    claimed_verdict:
        The verdict the cert claims for this property. One of
        ``"PROVED-standalone"`` / ``"PROVED-with-assume"`` /
        ``"REFUTED"`` / ``"INCONCLUSIVE"``.
    source_file:
        The cert file the claim was extracted from.
    source_line:
        Line number in the cert file where the claim appears.
    """

    target_property: str
    claimed_verdict: str
    source_file: str
    source_line: int


@dataclass(frozen=True)
class CertCrossCheckMismatch:
    """One mismatch between a cert claim and the engine's freshly-derived verdict.

    Attributes
    ----------
    claim:
        The cert claim that was found to be wrong.
    engine_verdict:
        What the engine actually output for this property when the
        cross-check ran.
    explanation:
        Human-readable explanation of the mismatch.
    """

    claim: CertVerdictClaim
    engine_verdict: str
    explanation: str


@dataclass(frozen=True)
class CertCrossCheckResult:
    """Full report from :func:`cross_check_against_engine_output`.

    Attributes
    ----------
    ok_for_ship:
        ``True`` when every cert claim matched the engine output.
        ``False`` when at least one mismatch was found — cert is
        NOT safe to ship; the cert author must reconcile.
    claims:
        Every claim extracted from the cert prose.
    mismatches:
        Every mismatch found. Empty when ``ok_for_ship=True``.
    engine_run_log:
        Path to the EBMC log file used as the source-of-truth.
    """

    ok_for_ship: bool
    claims: Sequence[CertVerdictClaim] = field(default_factory=list)
    mismatches: Sequence[CertCrossCheckMismatch] = field(default_factory=list)
    engine_run_log: str = ""


# ───────────────────────────────────────────────────────────────────
# Cert prose parsing
# ───────────────────────────────────────────────────────────────────


# Match table rows whose first cell is a property name (bare or
# `sec_miter.`-prefixed, with optional backticks). The verdict cell
# (second column) may contain descriptive prose around the verdict
# word; we extract the first verdict-keyword we find within it.
# Property names accepted in two forms:
#   - bare:   `pop_data_match` / pop_data_match
#   - prefixed: `sec_miter.pop_data_match` / sec_miter.pop_data_match
# Verdict keywords (case-sensitive): PROVED-standalone /
# PROVED-with-assume / PROVED / REFUTED / INCONCLUSIVE. The first
# matching keyword in the second cell wins.
_PROP_CELL_RE = re.compile(
    r"^\|\s*`?(?:sec_miter\.)?([a-zA-Z_][a-zA-Z0-9_]*?_match)`?\s*\|"
)
_VERDICT_KEYWORD_RE = re.compile(
    r"\b(PROVED-standalone|PROVED-with-assume|PROVED|REFUTED|INCONCLUSIVE)\b"
)


def extract_verdict_claims(cert_path: Path) -> list[CertVerdictClaim]:
    """Parse a cert markdown file for per-property verdict claims.

    Looks for markdown table rows whose first cell names a SEC
    property (e.g. ``pop_data_match`` / ``sec_miter.full_match``,
    backticked or not) and whose second cell contains a verdict
    keyword. The first verdict keyword in the second cell wins;
    descriptive prose around the keyword is preserved by the
    regex match but does not affect classification.

    Always normalizes the target_property to the
    ``sec_miter.<bare>`` form so cross-checking against EBMC log
    output (which uses the prefixed form) is shape-aligned.

    Returns an empty list if the cert has no recognizable claims.
    """
    if not cert_path.exists():
        return []
    claims: list[CertVerdictClaim] = []
    text = cert_path.read_text()
    for line_no, line in enumerate(text.splitlines(), start=1):
        prop_match = _PROP_CELL_RE.match(line)
        if prop_match is None:
            continue
        bare = prop_match.group(1)
        # Find the second cell (verdict cell)
        cells = line.split("|")
        if len(cells) < 3:
            continue
        verdict_cell = cells[2]
        verdict_match = _VERDICT_KEYWORD_RE.search(verdict_cell)
        if verdict_match is None:
            continue
        verdict = verdict_match.group(1)
        # Normalize property name to sec_miter.<bare> form
        normalized = f"sec_miter.{bare}"
        claims.append(
            CertVerdictClaim(
                target_property=normalized,
                claimed_verdict=verdict,
                source_file=str(cert_path),
                source_line=line_no,
            )
        )
    return claims


# ───────────────────────────────────────────────────────────────────
# Engine-output parsing
# ───────────────────────────────────────────────────────────────────


# Match EBMC log result lines:
#   `[sec_miter.full_match] always (...): PROVED`
_LOG_RESULT_RE = re.compile(
    r"\[\s*(sec_miter\.[a-zA-Z_][a-zA-Z0-9_]*)\s*\][^:]*:\s*"
    r"(PROVED|REFUTED|INCONCLUSIVE|UNKNOWN)"
)


def parse_ebmc_log_verdicts(log_path: Path) -> Mapping[str, str]:
    """Extract per-property verdicts from an EBMC log file.

    Returns a mapping ``{target_property: verdict}`` for every
    ``[sec_miter.<prop>] ... : VERDICT`` line in the log.
    """
    verdicts: dict[str, str] = {}
    if not log_path.exists():
        return verdicts
    text = log_path.read_text()
    for m in _LOG_RESULT_RE.finditer(text):
        verdicts[m.group(1)] = m.group(2)
    return verdicts


# ───────────────────────────────────────────────────────────────────
# Cross-check
# ───────────────────────────────────────────────────────────────────


def _claim_matches_verdict(claimed: str, engine: str) -> bool:
    """Whether the cert claim matches the engine's raw verdict.

    Cert prose carries finer-grained labels than EBMC's bare
    PROVED/REFUTED/INCONCLUSIVE — `PROVED-standalone` and
    `PROVED-with-assume` both correspond to the engine's `PROVED`
    output (the bare-miter run produces the standalone case; the
    with-assume miter run produces the with-assume case). This
    helper folds the prose-level granularity back to the engine
    granularity for the diff.
    """
    if engine == "PROVED" and claimed in (
        "PROVED",
        "PROVED-standalone",
        "PROVED-with-assume",
    ):
        return True
    return claimed == engine


def cross_check_against_engine_output(
    cert_path: Path,
    engine_run_log: Path,
    target_properties: Sequence[str] | None = None,
) -> CertCrossCheckResult:
    """Diff cert prose claims against engine output.

    Parameters
    ----------
    cert_path:
        Path to the cert markdown file (e.g.
        ``examples/customer/toy_fifo_chain_v2.5_sec/01-customer-block-certificate-v2.5.md``).
    engine_run_log:
        Path to the EBMC log capturing the freshly-derived engine
        output (e.g. ``sec-discharge-run/ebmc-induction-bare.log``).

    Returns
    -------
    :class:`CertCrossCheckResult` with ``ok_for_ship=False`` if any
    cert claim mismatches the engine output. Caller (the build
    script) refuses to build the tarball when ok_for_ship is False.

    Notes
    -----
    *This function does NOT itself re-run the engine.* The caller
    is responsible for ensuring ``engine_run_log`` is freshly
    captured (e.g. by running ``ebmc`` against the bundle's
    inputs/ before invoking this gate). The audit step the memory
    rule prescribes — "did you re-run, or did you remember?" —
    is enforced by the build script invocation order: re-run EBMC
    THEN call this cross-check.

    v0 only handles SEC verdict claims; NKI kernel verdicts +
    closed-loop PPA cross-checks land in v1+.
    """
    claims = extract_verdict_claims(cert_path)
    engine_verdicts = parse_ebmc_log_verdicts(engine_run_log)

    # Optional filter: only cross-check claims whose target_property
    # is in the provided set. Used when multiple per-property logs
    # exist (e.g. v2.5's bare log vs assume-full log vs assume-empty
    # log) and the caller wants to route each property to its
    # appropriate log without conflating verdicts across logs.
    if target_properties is not None:
        wanted = set(target_properties)
        claims = [c for c in claims if c.target_property in wanted]

    mismatches: list[CertCrossCheckMismatch] = []
    for claim in claims:
        engine_v = engine_verdicts.get(claim.target_property)
        if engine_v is None:
            mismatches.append(
                CertCrossCheckMismatch(
                    claim=claim,
                    engine_verdict="<missing>",
                    explanation=(
                        f"Cert claims {claim.claimed_verdict} for "
                        f"{claim.target_property} but engine log "
                        f"does not contain a verdict line for this "
                        f"property. Either the property name is "
                        f"wrong in the cert, or the engine run did "
                        f"not exercise this property (need a "
                        f"different miter or a fresh re-run)."
                    ),
                )
            )
            continue
        if not _claim_matches_verdict(claim.claimed_verdict, engine_v):
            mismatches.append(
                CertCrossCheckMismatch(
                    claim=claim,
                    engine_verdict=engine_v,
                    explanation=(
                        f"Cert claims {claim.claimed_verdict} for "
                        f"{claim.target_property} but engine output "
                        f"is {engine_v}. Re-run the engine OR "
                        f"correct the cert prose to match. The "
                        f"customer audit step is "
                        f"'did you re-run, or did you remember?'."
                    ),
                )
            )

    return CertCrossCheckResult(
        ok_for_ship=len(mismatches) == 0,
        claims=tuple(claims),
        mismatches=tuple(mismatches),
        engine_run_log=str(engine_run_log),
    )
