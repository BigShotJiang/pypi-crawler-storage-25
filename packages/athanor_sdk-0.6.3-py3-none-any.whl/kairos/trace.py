"""kairos.trace — TraceSink protocol + sinks for SDK-side agent runs (ATH-498).

Aidan 2026-04-23 directive: "SDK agent runs must emit to same Supabase
solve_runs + agent_traces tables as solve/neuron + solve/bio." Fleet
auto-uploads via SupabaseTraceSink; customer wheel defaults to
NoopTraceSink unless they hook up their own (S3 example in docs).

Public surface:

    from kairos.trace import (
        TraceSink,               # Protocol
        TraceEvent,              # dataclass
        EscalationEvent,         # dataclass — fires on the 7 Q3 triggers
        NoopTraceSink,           # customer-wheel default
        SupabaseTraceSink,       # fleet-internal (service-role key path)
        RunType, RunSubtype,     # Literal enums
    )

Purity taxonomy: TraceSink is IMPURE_SIDE_EFFECTFUL (DB / file / network
writes). Idempotence contract: same `event.id` → single persisted row;
duplicate emit must not create a second row. NoopTraceSink is trivially
idempotent (no-op × no-op = no-op). SupabaseTraceSink relies on Supabase
`upsert(on_conflict='id')` semantics.

Design principles:
  * TraceSink swallows errors — must not raise on any event shape. Bad
    events get logged at ERROR level and dropped. Rationale: customer
    pipelines must not fail because their trace backend is flaky.
  * SupabaseTraceSink uses SUPABASE_SERVICE_ROLE_KEY env var, mirrors the
    same path as athanor-builder/solve/shared/trace_uploader.py. Not
    bundled in customer wheel (check_sdk_ip.py blocks the URL leak).
  * S3TraceSink is docs-only example — customer BYO.
"""

from __future__ import annotations

import contextvars
import logging
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal, Mapping, Optional, Protocol, runtime_checkable
from uuid import uuid4


# ═══════════════════════════════════════════════════════════════════════
# Session contextvar — ATH-551
#
# Set by :func:`kairos.session` on ``__enter__`` so generator_synthesize
# (and future SDK orchestrators) can detect whether they're already
# inside a parent session or should auto-wrap.
#
# Value is a dict carrying session_id + sink + vertical so callers inside
# the session can read these without re-plumbing the session object.
# ═══════════════════════════════════════════════════════════════════════

CURRENT_SESSION: contextvars.ContextVar[Optional[dict]] = contextvars.ContextVar(
    "kairos_current_session", default=None,
)


# ═══════════════════════════════════════════════════════════════════════
# Enums + dataclasses
# ═══════════════════════════════════════════════════════════════════════


RunType = Literal[
    "solve_run",            # existing solve/neuron + solve/bio path
    "sdk_orchestration",    # ATH-498: SDK-side kairos.spec.pipeline runs
    "plugin_verifier",      # ATH-498: individual VerifierPlugin invocations
]


RunSubtype = Literal[
    "spec_pipeline",         # kairos.spec.pipeline.run
    "autoformalize",         # Stage 0 draft orchestration
    "cegar",                 # sysverilog/cegar/loop.py runs
    "swarm",                 # multi-proposer swarm
    "generator_synthesis",   # kairos.generator_synthesize (ATH-562 schema widening)
    "theorem_proving",       # Lean/Mathlib proof-solving loop (ATH-565 schema widening)
    "differential_test",     # kairos.differential.run (ATH-598 PLDI; DB CHECK widened
                             # 2026-04-25 via widen_sdk_agent_events_run_subtype migration).
                             # Platform contract: emits MUST use this exact string —
                             # not "differential_testing" or any -ing form — or strict-
                             # mode raises TraceSinkTransportError on the CHECK constraint.
]


EscalationTrigger = Literal[
    "axiom_introducing",        # trigger 1 — Lean proof adds a non-whitelisted axiom
    "bound_near_limit",         # trigger 2 — BMC PROVED at bound > 0.8 × declared max
    "verdict_diversity",        # trigger 3a — >=2 distinct verdicts across tiers
    "reviewer_flagged",         # trigger 3b — reviewer Concern.classification='SUSPICIOUS_VERDICT'
    "first_time_tier_combo",    # trigger 4 — novel (target_kind, evidence_tier) post warm-up
    "stakes_above_threshold",   # trigger 5 — --stakes=customer-facing OR cost_usd > $100
    "inter_run_instability",    # trigger 6 — same theorem, different verdicts within 24h
    "budget_exhausted",         # trigger 7 — cost_budget_usd exceeded mid-run (Stream D / ATH-519)
]


PluginTypeTag = Literal[
    "builtin",
    "verifier",
    "orchestrator",
    "trace_sink",
    "prompt_loader",
    "scoring",
    "tool_registry",
    "model_selector",
]


def _resolve_fleet_agent_role() -> str | None:
    """Resolve the fleet agent role from `KAIROS_FLEET_ROLE` env var.

    Per ATH-1028 Part A: every TraceEvent carries a fleet_agent_role
    field tagging which agent (cto / qa / platform / research) made
    the event happen. Customer-SDK-instance runs not part of the
    Athanor internal fleet leave the env var unset → field is None.

    Allowed values are free-form to leave room for future internal
    role expansion; canonical values are documented in
    `feedback_fleet_roles_2026_04_23.md` memory entry.
    """
    import os

    raw = os.environ.get("KAIROS_FLEET_ROLE", "").strip()
    return raw if raw else None


@dataclass
class TraceEvent:
    """One event emitted during a kairos run. Persisted in agent_traces table.

    Fields map to the agent_traces schema in athanor-platform:
        id          — unique event UUID, used for upsert idempotence
        run_id      — foreign key to solve_runs.id
        run_type    — categorises the containing run (defaults to
                      'sdk_orchestration' — the most common SDK caller)
        run_subtype — finer classification within run_type. Optional;
                      schema's CHECK constraint accepts NULL. Callers
                      with a session-level subtype should set it
                      explicitly (e.g. 'theorem_proving',
                      'differential_test', 'generator_synthesis')
        event_type  — free-form string ('stage_entered', 'llm_call',
                      'verdict', etc)
        sequence    — monotonic counter within the run, for ordering
        payload     — arbitrary JSONB payload (events.jsonl per-line shape)

    Field ordering: required fields (run_id, event_type, sequence) come
    first; defaults follow. ATH-545 follow-up — research's DSPv2 driver
    constructed TraceEvent without run_type/run_subtype kwargs and hit
    'TypeError: missing 2 required positional arguments' on every emit
    (240 attempts dropped before this default landed). Defaults match
    the SDK-orchestration majority case; non-SDK callers (foundry/neuron)
    pass run_type='solve_run' explicitly.
    """

    run_id: str
    event_type: str
    sequence: int
    run_type: RunType = "sdk_orchestration"
    run_subtype: RunSubtype | None = None
    payload: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid4()))
    # ATH-1028 Part A: fleet_agent_role tags which fleet agent
    # (cto / qa / platform / research) made the event happen.
    # Resolved lazily from `KAIROS_FLEET_ROLE` env var at
    # construction time. ``None`` when env var unset (e.g. customer-
    # SDK-instance runs not part of the Athanor internal fleet).
    # Closes the fleet-coordination-invisibility class per asabi
    # 2026-05-05 ATH-1024 audit.
    fleet_agent_role: str | None = field(
        default_factory=lambda: _resolve_fleet_agent_role()
    )
    # ATH-1063 Phase 0f: invocation_path tags the entry point that
    # fired this trace event ("mcp" / "sdk" / "cli"). Resolved on
    # observe() enter and stamped on every event in the session.
    # None when observe() ran without a kwarg or KAIROS_INVOCATION_PATH
    # env (free-tier / unflagged sessions).
    invocation_path: str | None = None
    captured_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class EscalationEvent:
    """Structured escalation record emitted by the 7 Q3 triggers.

    Written to <workdir>/escalations.jsonl for fleet-side cron forwarding
    to cto → #agent-founder. Customer-side surfaces via stderr + exit
    code 2 (see kairos CLI wiring in Gate 5 / 9).

    Per asabi 2026-04-23 Q3 plumbing spec: emitted at run-end, not streamed.
    """

    run_id: str
    theorem_id: str
    trigger: EscalationTrigger
    plugin_type: PluginTypeTag
    context: Mapping[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid4()))


# ═══════════════════════════════════════════════════════════════════════
# TraceSink Protocol
# ═══════════════════════════════════════════════════════════════════════


@runtime_checkable
class TraceSink(Protocol):
    """Protocol for writing trace events to a durable sink.

    :purity: IMPURE_SIDE_EFFECTFUL
    :idempotence: same event.id → single persisted row; duplicate emit
                  must not create a second row. NoopTraceSink is trivially
                  idempotent; SupabaseTraceSink uses upsert(on_conflict='id').
    :side_effects: DB writes / file appends / network POSTs
    :swallow: must NOT raise on any event shape; catch + log at ERROR
              level and drop the event. Pipelines must not fail because
              a trace backend is flaky.
    :plugin_type_tag: 'trace_sink' (for EscalationEvent.plugin_type)
    """

    def emit(self, event: TraceEvent) -> None:
        """Emit a single trace event. Non-raising."""
        ...

    def emit_escalation(self, event: EscalationEvent) -> None:
        """Emit an escalation event. Non-raising. Default backends persist
        these to the same or a parallel table; customer wheel's Noop
        implementation treats it as a no-op."""
        ...

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        """Open a parent run row (ATH-544).

        Called at session start so the platform dashboards at
        ``/solve-runs`` / ``/runs`` show SDK-originated runs alongside
        the legacy solve pipeline. Non-raising. Idempotent on duplicate
        call with the same ``run_id``.

        :param run_id: the free-form run identifier — matches
            ``TraceEvent.run_id`` so per-event rows in ``sdk_agent_events``
            can be joined to this parent on ``solve_runs.target =
            sdk_agent_events.run_id``.
        :param vertical: one of the solve_runs.vertical CHECK values
            (``neuron``, ``bio``, ``action_cred``, ``sysverilog``,
            ``auth``, ``networking``, ``distributed_systems``,
            ``systems_migration``, ``hardware``, ``other``). Default ``other``.
        :param builder_model: the LLM model the run will drive; nullable.
        :param target: human-readable target label; defaults to run_id.
        :param pipeline_version: pipeline identifier in the solve_runs row.
        :param organization_id: explicit org UUID. ATH-648: when omitted,
            backends that own a ``solve_runs.organization_id`` column
            resolve via env var → sync-token-lookup → fail-loud.
        :param engine_versions: ATH-934 — dict of verification-engine
            versions captured at session start (e.g. ``{"lean":
            "leanprover/lean4:v4.28.0", "ebmc": "5.10", "acl2": "8.7+",
            "pythia": "<git-rev>", "kairos": "0.4.x"}``). Pre-stages
            against the platform-side ``solve_runs.engine_versions
            jsonb`` column (ATH-933); SDK ships first per asabi
            2026-05-02. Falls through ``{}`` when probe yields nothing.
        """
        ...

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        """Close a parent run row (ATH-544).

        Called at session end / generator-synthesize completion.
        Non-raising. If :meth:`open_run` was never called for this
        ``run_id``, implementations must no-op (not crash).

        :param status: one of the solve_runs.status CHECK values —
            ``succeeded`` | ``refuted`` | ``failed`` | ``cancelled`` |
            ``spec_rejected`` | ``shipped`` | ``review_queue``.
        """
        ...

    def flush(self) -> None:
        """Force any buffered writes to land. Non-raising."""
        ...


# ═══════════════════════════════════════════════════════════════════════
# NoopTraceSink — customer-wheel default
# ═══════════════════════════════════════════════════════════════════════


class NoopTraceSink:
    """Default TraceSink for customer installs — drops every event.

    Rationale: customer wheel must not phone home to fleet-internal
    infrastructure. Customers who want trace persistence hook up their
    own (S3TraceSink pattern, or a custom subclass of this module's
    TraceSink Protocol).

    Trivially idempotent: no-op × no-op = no-op. Conformance suite
    treats this as the baseline — any other TraceSink implementation
    must behave the same at the "does not crash on any input" level.

    ATH-574: emit() still runs payload validation even though the event
    never ships. Warnings surface schema drift in CI + dev (where the
    customer-wheel is running under test). ``KAIROS_STRICT_PAYLOAD_SCHEMA=1``
    still raises. Zero-phone-home is preserved — validation is in-process
    only.
    """

    def __init__(self) -> None:
        # ATH-574: per-sink validation bookkeeping. Lazily imported to
        # keep kairos.trace_schema out of the hot startup path.
        from kairos.trace_schema import SessionValidationState
        self._validation_state = SessionValidationState()

    def emit(self, event: TraceEvent) -> None:
        """No-op emit — but still validates the payload (ATH-574)."""
        _maybe_validate_and_log(event, self._validation_state)
        return None

    def emit_escalation(self, event: EscalationEvent) -> None:
        """No-op — see :meth:`emit`."""
        return None

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        """No-op — see :meth:`emit`."""
        return None

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        """No-op — see :meth:`emit`."""
        return None

    def flush(self) -> None:
        """No-op — nothing buffered to flush."""
        return None


# ═══════════════════════════════════════════════════════════════════════
# JsonlTraceSink — free-tier local-only (ATH-707)
# ═══════════════════════════════════════════════════════════════════════


class JsonlTraceSink:
    """Local JSONL trace sink for free-tier customers without a DB sink.

    ATH-707: when no Supabase token is configured, free-tier customers
    auto-fall-through to this sink instead of NoopTraceSink. Customers
    get an audit trail under `~/.athanor/runs/<run_id>/events.jsonl`
    without phoning home; if they later upgrade to paid, they switch
    to SupabaseTraceSink without a code change.

    Format: one JSON object per line, fields = `TraceEvent` dataclass
    fields. Thread-safe via per-instance lock.

    Free tier: NEVER phones home. The local journal lives entirely on
    the customer's disk. Paid customers (with a token) skip this sink
    entirely and write directly to Supabase.
    """

    def __init__(self, runs_root: "Path | None" = None) -> None:
        from kairos.trace_schema import SessionValidationState
        from pathlib import Path
        import threading
        self._runs_root = runs_root or (Path.home() / ".athanor" / "runs")
        self._lock = threading.Lock()
        self._validation_state = SessionValidationState()

    def _events_path(self, run_id: str) -> "Path":
        from pathlib import Path
        run_dir = Path(self._runs_root) / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir / "events.jsonl"

    def _append(self, run_id: str, payload: dict) -> None:
        import json as _json
        path = self._events_path(run_id)
        line = _json.dumps(payload, default=str) + "\n"
        with self._lock:
            with path.open("a", encoding="utf-8") as f:
                f.write(line)

    def emit(self, event: TraceEvent) -> None:
        """Append one event to the local JSONL journal."""
        _maybe_validate_and_log(event, self._validation_state)
        try:
            from dataclasses import asdict
            self._append(event.run_id, {"kind": "event", **asdict(event)})
        except Exception:  # noqa: BLE001 — best-effort observability
            _logger.warning(
                "JsonlTraceSink.emit failed", exc_info=True,
            )

    def emit_escalation(self, event: EscalationEvent) -> None:
        try:
            from dataclasses import asdict
            self._append(
                event.run_id, {"kind": "escalation", **asdict(event)},
            )
        except Exception:  # noqa: BLE001
            _logger.warning(
                "JsonlTraceSink.emit_escalation failed", exc_info=True,
            )

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        try:
            self._append(run_id, {
                "kind": "open_run",
                "run_id": run_id,
                "vertical": vertical,
                "builder_model": builder_model,
                "target": target,
                "pipeline_version": pipeline_version,
                "organization_id": organization_id,
                # ATH-934: include engine_versions verbatim. Local replay
                # tooling (kairos.trace_replay) reads these back when a
                # customer wants to know which Lean / EBMC / ACL2 / Pythia
                # version produced a given run.
                "engine_versions": dict(engine_versions) if engine_versions else {},
            })
        except Exception:  # noqa: BLE001
            _logger.warning(
                "JsonlTraceSink.open_run failed", exc_info=True,
            )

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        try:
            self._append(run_id, {
                "kind": "close_run",
                "run_id": run_id,
                "status": status,
                "outcome_verdict": dict(outcome_verdict) if outcome_verdict else None,
                "final_score": final_score,
                "token_cost_usd": token_cost_usd,
                "wall_time_seconds": wall_time_seconds,
            })
        except Exception:  # noqa: BLE001
            _logger.warning(
                "JsonlTraceSink.close_run failed", exc_info=True,
            )

    def flush(self) -> None:
        """No-op — every emit writes immediately."""
        return None


# ═══════════════════════════════════════════════════════════════════════
# MultiSink — fan out to multiple TraceSinks (tee for dual-write)
# ═══════════════════════════════════════════════════════════════════════


class MultiSink:
    """``TraceSink`` adapter that fans out every call to a list of
    inner sinks. Used to dual-write paid runs to both
    :class:`SupabaseTraceSink` (cloud) AND
    :class:`kairos.local_output.LocalOutputTraceSink` (local backup),
    per the §3.6 paid-tier behavior in ``docs/sdk-tier-model.md``.

    :purity: IMPURE_SIDE_EFFECTFUL (each inner sink runs)
    :idempotence: each inner sink owns its own dedup contract
    :side_effects: union of inner sinks' side effects
    :swallow: outer never raises; if an inner raises, log it and
              continue to the next sink. One flaky sink never blocks
              the others.

    Construction:

        sink = MultiSink([LocalOutputTraceSink(run_id), SupabaseTraceSink()])
        sink.emit(event)   # writes to both, in order

    Inner sinks are called in the order they appear. Errors in any
    inner sink are caught and logged; the outer call continues to the
    remaining sinks. Empty list is allowed and behaves as a Noop.
    """

    def __init__(self, sinks: list["TraceSink"]) -> None:
        self._sinks = list(sinks)

    @property
    def sinks(self) -> list["TraceSink"]:
        """The configured inner sinks. Read-only view; modify via
        construction, not mutation."""
        return list(self._sinks)

    def emit(self, event: TraceEvent) -> None:
        for s in self._sinks:
            try:
                s.emit(event)
            except Exception:
                _logger.exception(
                    "MultiSink: inner sink %s.emit raised — continuing",
                    type(s).__name__,
                )

    def emit_escalation(self, event: EscalationEvent) -> None:
        for s in self._sinks:
            try:
                s.emit_escalation(event)
            except Exception:
                _logger.exception(
                    "MultiSink: inner sink %s.emit_escalation raised — continuing",
                    type(s).__name__,
                )

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        for s in self._sinks:
            try:
                s.open_run(
                    run_id,
                    vertical=vertical,
                    builder_model=builder_model,
                    target=target,
                    pipeline_version=pipeline_version,
                    organization_id=organization_id,
                    engine_versions=engine_versions,
                )
            except Exception:
                _logger.exception(
                    "MultiSink: inner sink %s.open_run raised — continuing",
                    type(s).__name__,
                )

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        for s in self._sinks:
            try:
                s.close_run(
                    run_id,
                    status=status,
                    outcome_verdict=outcome_verdict,
                    final_score=final_score,
                    token_cost_usd=token_cost_usd,
                    wall_time_seconds=wall_time_seconds,
                )
            except Exception:
                _logger.exception(
                    "MultiSink: inner sink %s.close_run raised — continuing",
                    type(s).__name__,
                )

    def flush(self) -> None:
        for s in self._sinks:
            try:
                s.flush()
            except Exception:
                _logger.exception(
                    "MultiSink: inner sink %s.flush raised — continuing",
                    type(s).__name__,
                )


# ═══════════════════════════════════════════════════════════════════════
# SupabaseTraceSink — fleet-internal
# ═══════════════════════════════════════════════════════════════════════


_logger = logging.getLogger(__name__)


# ATH-574: env var that flips payload validation from lenient-warn to raise.
# Set in CI + dev; never in prod. Checked lazily per-emit so tests can toggle
# it via monkeypatch without sink rebuild.
_STRICT_PAYLOAD_ENV = "KAIROS_STRICT_PAYLOAD_SCHEMA"


# ATH-585 Subtask 1: env var that raises on session-close reconciliation
# mismatch. Default behavior is WARN + journal. Strict mode is for CI +
# dev to catch drift early before it ships.
_STRICT_RECONCILE_ENV = "KAIROS_STRICT_SESSION_RECONCILE"

# 2026-04-25 (Sam directive): master switch for the two DATA-LOSS silent
# paths — sink-resolution fallback to Noop, and transport-failure journal-
# only. Customer wheel default OFF preserves the non-raising TraceSink
# Protocol contract; fleet bashrc sets it ON so missing creds / HTTP 4xx
# crash the script immediately instead of disappearing into the replay
# journal or Noop fallback.
#
# Scope is intentionally narrow: this switch DOES NOT auto-enable
# _STRICT_PAYLOAD_ENV or _STRICT_RECONCILE_ENV. Those stay opt-in for
# dev/CI because (a) unknown-event_type is a schema-drift signal, not a
# data-loss signal (payload still persists fully); and (b) reconcile
# strictness raises at session close rather than emit time, which
# belongs in CI runs but shouldn't crash a long-running fleet job mid-
# execution over a transient count mismatch. Fleet operators who want
# the full raise surface set all three envs together.
_STRICT_TRACE_ENV = "KAIROS_TRACE_STRICT"


class TraceSinkUnavailable(RuntimeError):
    """Raised when ``default_sink_from_env()`` is called in strict mode
    (``KAIROS_TRACE_STRICT=1``) but the required Supabase env vars
    (``SUPABASE_URL`` or ``NEXT_PUBLIC_SUPABASE_URL`` AND
    ``SUPABASE_SERVICE_ROLE_KEY``) are not set. Replaces the silent
    NoopTraceSink fallback that was eating fleet traces when bashrc
    drifted (root cause of 2026-04-25 cedar §8 data void, where every
    diff event hit Noop because the VM's bashrc never grew the exports).
    """


class TraceSinkTransportError(RuntimeError):
    """Raised by ``SupabaseTraceSink._post_upsert`` after retry exhaustion
    when ``KAIROS_TRACE_STRICT=1``. Replaces the journal-only path that
    silently absorbed CHECK constraint failures (root cause: 2026-04-25
    sdk_agent_events.run_subtype rejected 'differential_test' for days,
    every per-tuple emit landed in the journal nobody monitors). In
    strict mode, the script crashes loud so the operator notices.
    """


def _is_trace_strict() -> bool:
    """Master strict switch. Returns True if KAIROS_TRACE_STRICT is set
    to a truthy non-empty value (matches the convention used by the
    pre-existing strict envs in this module — empty = off, anything else
    = on)."""
    return bool(os.environ.get(_STRICT_TRACE_ENV, "").strip())


# ─── ATH-934: engine-version probe ────────────────────────────────────


def _probe_engine_versions() -> dict[str, str | None]:
    """Probe verification-engine versions at session start.

    asabi 2026-05-02 told Customer-2: "every solve run on tahoe records
    which Pythia commit, ACL2 version, EBMC version, Lean toolchain pin,
    etc." Pre-this-helper, that was aspirational — solve_runs only
    carried run_id/vertical/builder_model/target/pipeline_version/
    organization_id. This probe captures the missing four engines plus
    kairos itself; SDK passes the dict to ``open_run(engine_versions=...)``
    which lands in ``solve_runs.engine_versions jsonb`` once ATH-933's
    column migration ships.

    Returns: dict with keys lean / ebmc / acl2 / pythia / kairos.
    Per-engine value is the first line of ``<engine> --version`` (trimmed)
    or ``None`` when the engine isn't on PATH or ``--version`` failed.
    The probe never raises.

    Cached at session-start; the contract assumes engines don't get
    swapped mid-run.
    """
    import subprocess
    out: dict[str, str | None] = {}

    # kairos — module __version__, always present
    try:
        from kairos import __version__ as _kairos_version
        out["kairos"] = _kairos_version
    except Exception:  # noqa: BLE001 — best-effort; falls through to None on import edge cases
        out["kairos"] = None

    # lean / ebmc — short --version probe via PATH lookup
    for tool, key in (("lean", "lean"), ("ebmc", "ebmc")):
        try:
            res = subprocess.run(
                [tool, "--version"],
                capture_output=True, text=True, timeout=2,
            )
            line = (res.stdout or res.stderr or "").splitlines()
            out[key] = line[0].strip() if line else None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            out[key] = None
        except Exception:  # noqa: BLE001 — broad catch on subprocess; engine probe must not crash session start
            out[key] = None

    # acl2 — special handling on two counts:
    # 1. PATH lookup misses: the saved image lives at /tmp/acl2/saved_acl2
    #    by convention (apt install sbcl && git clone acl2 /tmp/acl2 &&
    #    make), not on PATH. Use kairos.acl2._find_acl2() which already
    #    knows the candidate paths.
    # 2. ACL2 has no --version flag — passing it boots SBCL which then
    #    errors on the unknown C-runtime flag. Instead, pipe `(quit)`
    #    into stdin: ACL2 boots, prints its banner (which carries
    #    "ACL2 Version 8.7+"), then exits. ~60ms in practice.
    # ATH-934 follow-up #3 (2026-05-02 platform smoke caught the path
    # gap; this commit also fixes the --version-doesn't-exist bug).
    try:
        from kairos.acl2 import _find_acl2 as _resolve_acl2_bin
        try:
            acl2_bin = _resolve_acl2_bin()
        except Exception:  # noqa: BLE001 — _find_acl2 raises ACL2NotFoundError on miss; treat as None
            acl2_bin = None
        if acl2_bin:
            res = subprocess.run(
                [acl2_bin],
                input="(quit)\n",
                capture_output=True, text=True, timeout=5,
            )
            # Banner format: lines decorated with leading "+" surrounding
            # version string. e.g. " + ACL2 Version 8.7+ (a development
            # snapshot based on ACL2 Version 8.7) +".
            for line in (res.stdout or "").splitlines():
                if "ACL2 Version" in line:
                    out["acl2"] = line.strip().strip("+").strip()
                    break
            else:
                out["acl2"] = None
        else:
            out["acl2"] = None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        out["acl2"] = None
    except Exception:  # noqa: BLE001 — broad catch on subprocess; engine probe must not crash session start
        out["acl2"] = None

    # pythia — vendored snapshot. Resolution order:
    #   1. PYTHIA_COMMIT manifest (ATH-936 — written by
    #      scripts/refresh-pythia-vendor.sh at snapshot time). Line 1
    #      is the full commit hash; we truncate to 8 chars for chip
    #      readability. This is the production path.
    #   2. .git rev-parse — works only when a contributor has cloned
    #      Pythia in place during dev (rare).
    #   3. None — honest fallback.
    # Originally this used .git rev-parse alone, but the vendored
    # snapshot has no .git (it's a rsync copy), and `git -C` walked
    # UP and returned the parent kairos repo's HEAD — customer-
    # misleading. PR #420 fixed that by gating on .git existence;
    # PR ATH-936 (this one) adds the manifest path which is the
    # actual production answer.
    try:
        from pathlib import Path
        pythia_dir = Path(__file__).parent / "_vendor" / "pythia"
        pythia_commit_file = pythia_dir / "PYTHIA_COMMIT"
        pythia_git = pythia_dir / ".git"

        if pythia_commit_file.is_file():
            # Manifest path: line 1 is full commit hash.
            try:
                first_line = pythia_commit_file.read_text().splitlines()[0].strip()
                # Truncate full hash to 8 chars for chip readability;
                # full hash recoverable from the manifest if needed
                # for forensic audit.
                out["pythia"] = first_line[:8] if first_line else None
            except (IndexError, OSError):
                out["pythia"] = None
        elif pythia_dir.is_dir() and pythia_git.exists():
            res = subprocess.run(
                ["git", "-C", str(pythia_dir), "rev-parse", "--short", "HEAD"],
                capture_output=True, text=True, timeout=2,
            )
            sha = (res.stdout or "").strip()
            out["pythia"] = sha or None
        else:
            out["pythia"] = None
    except Exception:  # noqa: BLE001 — best-effort vendored-snapshot probe
        out["pythia"] = None

    return out


def _is_payload_strict() -> bool:
    """Strict payload validation: opt-in via its own env var only. Not
    rolled into KAIROS_TRACE_STRICT because unknown event_type is a
    schema-drift warning, not a data-loss signal — the payload still
    persists in full."""
    return bool(os.environ.get(_STRICT_PAYLOAD_ENV, "").strip())


def _is_reconcile_strict() -> bool:
    """Strict session reconcile: opt-in via its own env var only. Not
    rolled into KAIROS_TRACE_STRICT because count drift surfaces at
    close time and crashing a long-running fleet job over a transient
    mismatch is worse than the warn-and-journal fallback."""
    return bool(os.environ.get(_STRICT_RECONCILE_ENV, "").strip())


def _sanitize_floats_for_json(value: Any) -> Any:
    """Recursively replace NaN / +Inf / -Inf with None.

    Python's :func:`json.dumps` defaults to ``allow_nan=True`` and emits
    bare ``NaN`` / ``Infinity`` tokens, but RFC 7159 §6 forbids them and
    PostgREST rejects the body with ``PGRST102 "Empty or invalid json"``.
    Caller payloads occasionally contain NaN from divide-by-zero in
    aggregate metrics (e.g. ``agreement_rate = agreements / compared``
    when ``compared == 0``); those events would silently land in the
    failed_events journal instead of the DB.

    Pre-walk the body so callers don't have to remember to guard every
    division. Out-of-band signals (NaN, Inf) become JSON null — the
    consumer side already treats null as "metric undefined."

    Defense layer 2 (orthogonal): all three remote POST sites also
    pass ``default=str`` to :func:`json.dumps` so non-JSON types
    (``datetime``, ``bytes``, ``set``, custom dataclasses) coerce to
    string repr instead of raising ``TypeError``. NaN/Inf still need
    the pre-walk because ``default=`` only fires for unknown types,
    not for floats that ``json.dumps`` already knows about.
    """
    import math
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    if isinstance(value, dict):
        return {k: _sanitize_floats_for_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_floats_for_json(v) for v in value]
    return value


class SessionReconcileError(Exception):
    """ATH-585: raised when session-close reconciliation detects drift
    between the sink's in-memory emit counter and the DB row count under
    ``KAIROS_STRICT_SESSION_RECONCILE=1``. Non-strict mode logs ERROR +
    journals a drift marker but does NOT raise (TraceSink non-raising
    contract).
    """


def _maybe_validate_and_log(
    event: TraceEvent,
    state: Any,  # kairos.trace_schema.SessionValidationState
) -> None:
    """Validate ``event.payload`` against the ATH-574 registry and log on
    violation. Rate-limited per ``(session_id, event_type)`` pair.

    Never raises in default mode — events always emit regardless of schema
    outcome (zero-data-loss invariant). When ``KAIROS_STRICT_PAYLOAD_SCHEMA=1``
    is set in the environment, raises :class:`PayloadSchemaError` after
    logging; callers that want to enforce the event still reach the sink must
    catch the exception at the boundary.

    ``session_id`` is read from ``payload.get("session_id")`` when present;
    unkeyed events (no session) use the string ``"__no_session__"`` so
    rate-limit bookkeeping still works.
    """
    from kairos.trace_schema import PayloadSchemaError, validate_payload

    result = validate_payload(event.run_subtype, event.event_type, event.payload)
    session_id = str(event.payload.get("session_id") or "__no_session__")
    strict = _is_payload_strict()

    if result.unknown:
        if state.should_warn_unknown(session_id, event.event_type):
            _logger.warning(
                "ATH-574 unknown event_type — no registry entry for "
                "(run_subtype=%s, event_type=%s). Event emits with payload "
                "preserved; add a registry entry in kairos.trace_schema to "
                "enable validation.",
                event.run_subtype, event.event_type,
            )
        return

    if result.ok:
        return

    violation_summary = "; ".join(result.violations) or "(no detail)"
    if strict:
        raise PayloadSchemaError(
            f"{event.run_subtype}/{event.event_type}: {violation_summary}"
        )

    if state.should_warn(session_id, event.event_type):
        _logger.debug(
            "ATH-574 payload violation — run_subtype=%s event_type=%s "
            "session_id=%s violations=%s",
            event.run_subtype, event.event_type, session_id, violation_summary,
        )


def _first_nonempty_env(names: tuple[str, ...]) -> str:
    """Return the first non-empty env-var value among ``names``, or ''.

    Used to accept multiple env-var aliases for the same config value —
    e.g., ``SUPABASE_URL`` vs ``NEXT_PUBLIC_SUPABASE_URL`` (the fleet
    exports the latter via ``~/.env.platform`` but the SDK historically
    only read the former). ATH-543.
    """
    for name in names:
        value = os.environ.get(name, "")
        if value:
            return value
    return ""


# Sentinel — distinguishes "user omitted trace_sink kwarg" (→ auto-detect
# from env per ATH-550) from "user explicitly passed trace_sink=None".
_TRACE_SINK_UNSET: Any = object()


def default_sink_from_env() -> "TraceSink":
    """Return the TraceSink the SDK should use when the caller didn't
    supply one.

    Sink-resolution waterfall (ATH-707, Aidan + asabi 2026-04-26 19:55Z
    "trace-on default, opt-out via --no-trace"):

    1. ``KAIROS_NO_TRACE=1`` → :class:`NoopTraceSink` (explicit opt-out;
       loud-printed by the CLI layer at launch).
    2. Token + URL configured → :class:`SupabaseTraceSink`. Paid path.
       Token = ``ATHANOR_SYNC_TOKEN`` or legacy ``SUPABASE_SERVICE_ROLE_KEY``.
    3. Otherwise → :class:`JsonlTraceSink` writing to
       ``~/.athanor/runs/<run_id>/events.jsonl``. Free-tier default.
       Local-only, no phone-home. Customer gets a real audit trail
       without paying for our DB infrastructure.

    Before ATH-707, the third rung was :class:`NoopTraceSink`, which
    caused silent data loss when an operator launched a sweep without
    setting Supabase creds. Flipping to JsonlTraceSink as the floor
    means an operator can't accidentally run un-traced; the worst case
    is a local journal that fills disk if ignored, which is loud.

    Customers can still force Noop via explicit
    ``trace_sink=NoopTraceSink()`` or ``KAIROS_NO_TRACE=1``.
    """
    # Rung 1: explicit opt-out.
    if os.environ.get("KAIROS_NO_TRACE", "").strip() in ("1", "true", "yes"):
        return NoopTraceSink()

    # Rung 2: token + URL → Supabase sink.
    url = _first_nonempty_env(("SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL"))
    # ATH-650 P1: ATHANOR_SYNC_TOKEN is auth-equivalent to
    # SUPABASE_SERVICE_ROLE_KEY per the SDK→DB contract gate (Aidan
    # 2026-04-24 02:43Z).
    key = (
        os.environ.get(_SYNC_TOKEN_ENV, "")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    )
    if url and key:
        return SupabaseTraceSink()
    if _is_trace_strict():
        raise TraceSinkUnavailable(
            "KAIROS_TRACE_STRICT=1 but trace-sink env vars are unset. "
            "Set SUPABASE_URL (or NEXT_PUBLIC_SUPABASE_URL) AND one of "
            "(ATHANOR_SYNC_TOKEN, SUPABASE_SERVICE_ROLE_KEY) in the "
            "environment, or unset KAIROS_TRACE_STRICT to fall back to "
            "JsonlTraceSink. (Customer installs leave KAIROS_TRACE_STRICT "
            "unset; fleet VMs export it so missing creds crash the script "
            "instead of silently dropping every event.)"
        )
    # Rung 3: free-tier local journal default (ATH-707).
    return JsonlTraceSink()


def resolve_trace_sink(sink_arg: Any) -> "TraceSink":
    """Resolve a caller-supplied ``trace_sink`` kwarg to a concrete sink.

    Three-way:
      * caller omitted kwarg (sentinel value) → :func:`default_sink_from_env`
      * caller passed ``None`` explicitly → :class:`NoopTraceSink`
        (preserves pre-ATH-550 explicit-opt-out semantics)
      * caller passed a sink instance → returned as-is

    Callers that want the ATH-550 auto-detection semantics use
    ``trace_sink=_TRACE_SINK_UNSET`` as the signature default.
    """
    if sink_arg is _TRACE_SINK_UNSET:
        return default_sink_from_env()
    if sink_arg is None:
        return NoopTraceSink()
    return sink_arg


# ═══════════════════════════════════════════════════════════════════════
# ATH-819 — function-input visibility on traces
# ═══════════════════════════════════════════════════════════════════════

# Cap on long-string args (e.g. Lean source) before they go into the
# function_inputs payload. Anything longer is reduced to
# {sha256, length, preview_first_<CAP>}. Mirrors the candidate_first_300
# pattern (ATH-794) — 300 chars is enough to confirm the shape without
# bloating the trace row.
_FUNCTION_INPUT_PREVIEW_CAP = 300


def reduce_long_arg(value: Any, *, preview_cap: int = _FUNCTION_INPUT_PREVIEW_CAP) -> Any:
    """Reduce a potentially-large argument to a digest+preview shape.

    Returns:
        - The original ``value`` when it's None or its serialised form is
          shorter than ``preview_cap``.
        - For strings + Path-likes longer than the cap: a dict
          ``{"sha256": str, "length": int, "preview_first_300": str,
          "truncated": True}``.

    Used by :func:`emit_function_inputs` to keep big inputs (Lean source,
    long prompts, file contents) from blowing up sdk_agent_events row
    sizes. Customers reading the trace see the digest + a recognisable
    preview; debugging by sha256 still works.
    """
    if value is None:
        return None
    # Path-likes: stringify before measuring.
    try:
        from pathlib import Path as _Path
        if isinstance(value, _Path):
            value = str(value)
    except ImportError:  # pragma: no cover
        pass
    if not isinstance(value, str) or len(value) <= preview_cap:
        return value
    import hashlib as _hashlib
    return {
        "sha256": _hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest(),
        "length": len(value),
        "preview_first_300": value[:preview_cap],
        "truncated": True,
    }


def emit_function_inputs(
    sink: "TraceSink",
    *,
    run_id: str,
    function_name: str,
    args: Mapping[str, Any],
    run_type: str = "sdk_orchestration",
    run_subtype: str | None = None,
    sequence: int = 0,
) -> None:
    """Emit one ``function_inputs`` TraceEvent capturing what an SDK
    helper was called with.

    ATH-819. Each tracked SDK helper (``simple_prove``,
    ``simple_prove_template``, ``generator_synthesize``, ``prove``,
    ``Orchestrator.orchestrate``) calls this once near function entry so
    a customer reading ``/solve-runs/[id]`` can see what the function
    received, not just what it returned.

    Big string args (Lean source, long prompts) should be passed through
    :func:`reduce_long_arg` first to avoid bloating sdk_agent_events
    row sizes. Scalars + small strings go in as-is.

    Non-raising: matches the ``TraceSink.emit`` Protocol contract. A
    sink that errors on emit logs + swallows; the SDK call continues.

    The event is registered as a permissive ``_LooseProbe`` in
    :mod:`kairos.trace_schema`, so payload shape is not validated —
    the helper-by-helper ``args`` dict is the contract. Page-side
    renders an "Inputs" subsection on the run-intent card.
    """
    from datetime import datetime, timezone as _tz
    payload: dict[str, Any] = {
        "function": function_name,
        "args": dict(args),
        "captured_at": datetime.now(tz=_tz.utc).isoformat(),
    }
    event = TraceEvent(
        run_id=run_id,
        event_type="function_inputs",
        sequence=sequence,
        run_type=run_type,
        run_subtype=run_subtype,
        payload=payload,
    )
    try:
        sink.emit(event)
    except Exception:  # pragma: no cover — Protocol says non-raising
        _logger.exception(
            "emit_function_inputs: sink.emit raised on function=%s; "
            "swallowed per TraceSink Protocol",
            function_name,
        )


# ═══════════════════════════════════════════════════════════════════════
# ATH-553 — fail-loud + rollback journal
#
# Aidan 2026-04-24 02:43Z: ATHANOR_SYNC_TOKEN present = every SDK op
# uploads, no silent drops. When the upload POST/PATCH fails, we must
# journal the event to ~/.kairos/failed_events.jsonl so an operator can
# replay the queue after a Supabase outage (see `kairos trace replay`,
# ATH-554). Journal writes themselves are non-raising — if we can't even
# write the journal, log at ERROR and move on; the caller must not crash
# on trace-backend trouble (TraceSink Protocol contract).
# ═══════════════════════════════════════════════════════════════════════


# SDK-DB contract gate (Aidan 2026-04-24). Presence implies the caller
# authorised uploads; takes precedence over SUPABASE_SERVICE_ROLE_KEY so
# dogfooding VMs can rotate the token without touching the role key.
_SYNC_TOKEN_ENV = "ATHANOR_SYNC_TOKEN"

# Env override for the replay journal path. Used by tests + operators
# who want the queue somewhere other than ~/.kairos/failed_events.jsonl.
_JOURNAL_PATH_ENV = "KAIROS_FAILED_EVENTS_JOURNAL"
_DEFAULT_JOURNAL_PATH = "~/.kairos/failed_events.jsonl"

# Cap per-entry response-body capture so a giant HTML error page can't
# blow up the journal. 4 KB is enough to recover a PostgREST error
# message (code + detail + hint) while staying disk-friendly.
_JOURNAL_RESPONSE_BODY_CAP = 4000


def _resolve_journal_path():
    """Return the Path where failed-upload events should be appended.

    Honours ``KAIROS_FAILED_EVENTS_JOURNAL`` env override if set,
    otherwise ``~/.kairos/failed_events.jsonl``. Does NOT create the
    file or its parent — that happens in :func:`_journal_failed_event`
    so the resolve call can stay pure.
    """
    from pathlib import Path

    override = os.environ.get(_JOURNAL_PATH_ENV, "").strip()
    if override:
        return Path(override)
    return Path(_DEFAULT_JOURNAL_PATH).expanduser()


def _journal_failed_event(
    *,
    table: str,
    body: Mapping[str, Any],
    method: str,
    response_status: int | None,
    response_body: str,
    exc: BaseException | None = None,
) -> None:
    """Append a JSONL entry describing a failed upload attempt.

    Non-raising: if the journal can't be written (permission denied,
    parent-is-a-file, disk full), log at ERROR and return. Callers rely
    on this being safe to invoke from inside a ``try/except`` fallback.

    Entry shape (stable for ATH-554 replay CLI):
        {
          "failed_at": ISO-8601 UTC,
          "table": "sdk_agent_events" | "solve_runs" | ...,
          "method": "POST" | "PATCH",
          "body": <the upload body dict, JSON-serialisable>,
          "response_status": int | null,    # HTTP status if known
          "response_body": str,             # capped at 4KB
          "exception_type": str | null,     # non-HTTP transport errors
          "exception_msg": str | null,
          "attempts": 1,                    # incremented by replay CLI
        }
    """
    import json as _json
    from datetime import datetime, timezone

    entry: dict[str, Any] = {
        "failed_at": datetime.now(timezone.utc).isoformat(),
        "table": table,
        "method": method,
        "body": dict(body),
        "response_status": response_status,
        "response_body": (response_body or "")[:_JOURNAL_RESPONSE_BODY_CAP],
        "exception_type": type(exc).__name__ if exc is not None else None,
        "exception_msg": str(exc) if exc is not None else None,
        "attempts": 1,
    }

    path = _resolve_journal_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fp:
            fp.write(_json.dumps(entry, default=str) + "\n")
    except Exception as write_exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.error(
            "journal write failed at %s: %s: %s — original upload "
            "failure to table=%s method=%s status=%s will be LOST",
            path, type(write_exc).__name__, write_exc,
            table, method, response_status,
        )


class SupabaseTraceSink:
    """Fleet-internal TraceSink: POSTs events to solve_runs + agent_traces.

    Uses SUPABASE_SERVICE_ROLE_KEY (env) — mirrors the existing
    athanor-builder/solve/shared/trace_uploader.py path, so SDK-side
    runs land in the same tables as solve/neuron + solve/bio.

    NOT bundled in the customer wheel (check_sdk_ip.py gate enforces).
    Internal fleet uses only.

    Idempotence: Supabase client's upsert(on_conflict='id') dedups on
    TraceEvent.id. Duplicate emit of the same event (same id) → single
    row. Achieved via REST `Prefer: resolution=merge-duplicates` header.

    Errors are swallowed — any network blip / schema mismatch / auth
    failure logs at ERROR and continues. Pipelines must not fail because
    the trace sink is flaky.
    """

    # Primary URL env var; first non-empty wins when multiple are set.
    # ATH-543: the fleet's .env.platform exports ``NEXT_PUBLIC_SUPABASE_URL``
    # (the Next.js-shaped name used by the dashboard), not ``SUPABASE_URL``.
    # Before ATH-543 the SDK only read ``SUPABASE_URL`` and silently fell
    # through to NoopTraceSink — platform's Phase A v1/v2/v2.1 runs produced
    # zero rows in sdk_agent_events despite calling kairos.generator_synthesize.
    _SUPABASE_URL_ENVS: tuple[str, ...] = ("SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL")
    _SUPABASE_KEY_ENV = "SUPABASE_SERVICE_ROLE_KEY"

    # Single source of truth for env vars that affect `_configured` state.
    # When any combination of these resolves to a non-empty URL + key, the
    # sink enters the configured state and `open_run` proceeds to the
    # org_id waterfall in `_resolve_organization_id`. Tests that need an
    # unconfigured sink (`_configured=False`) MUST clear every one of
    # these via `monkeypatch.delenv` — see test_trace_engine_versions.py
    # `TestAllSinksAcceptKwarg` for the canonical reference pattern.
    #
    # Force-rule: prefer this constant over hand-mirrored test lists.
    # When a new env var is added to the __init__ resolution chain, add
    # it here in the same PR — tests referencing this tuple stay honest
    # by construction.
    _CONFIGURATION_ENV_VARS: tuple[str, ...] = (
        *_SUPABASE_URL_ENVS,
        _SYNC_TOKEN_ENV,
        _SUPABASE_KEY_ENV,
    )

    def __init__(
        self,
        url: str | None = None,
        service_role_key: str | None = None,
    ) -> None:
        self._url = url or _first_nonempty_env(self._SUPABASE_URL_ENVS)
        # Auth precedence (ATH-553): caller-supplied key wins, then
        # ATHANOR_SYNC_TOKEN (the SDK→DB contract gate Aidan mandated
        # 2026-04-24), then legacy SUPABASE_SERVICE_ROLE_KEY. Giving the
        # sync token precedence means dogfooding VMs can rotate auth
        # without touching the role key.
        resolved_key = service_role_key
        if not resolved_key:
            resolved_key = os.environ.get(_SYNC_TOKEN_ENV, "") or os.environ.get(
                self._SUPABASE_KEY_ENV, "",
            )
        self._key = resolved_key
        self._configured = bool(self._url and self._key)
        if not self._configured:
            _logger.warning(
                "SupabaseTraceSink constructed without %s + (%s or %s) — "
                "emit() calls will be dropped until configured.",
                "|".join(self._SUPABASE_URL_ENVS),
                _SYNC_TOKEN_ENV,
                self._SUPABASE_KEY_ENV,
            )
        # ATH-574: per-event payload validation state. One bookkeeping object
        # per sink instance, keyed internally by (session_id, event_type).
        # Lazily imported to keep kairos.trace_schema out of the hot startup
        # path (it transitively imports pydantic).
        from kairos.trace_schema import SessionValidationState
        self._validation_state = SessionValidationState()
        # ATH-585 Subtask 1: per-session emit counter. Indexed by run_id
        # (== session_id for kairos.session), incremented inside
        # _post_upsert on every successful sdk_agent_events POST. Read by
        # close_run() for the reconciliation check against DB COUNT(*).
        self._emit_counts: dict[str, int] = {}
        # ATH-759: deferred parent-row INSERT bodies. open_run stashes
        # the solve_runs body here instead of posting immediately; the
        # first emit() / emit_escalation() flushes it before the event
        # write. Hand-rolled callers that bypass kairos.session() and
        # never emit (Cedar diff harness, dead test fixtures) stop
        # leaving zero-event stub rows in the dashboard. close_run on a
        # run_id that's still pending (open + close, no events) discards
        # the body and returns — symmetric 0-emit ⇒ 0-row contract.
        self._pending_opens: dict[str, dict[str, Any]] = {}
        # ATH-779: per-table buffer for bulk-INSERT batching. Only the
        # `sdk_agent_events` table is batched today — high-frequency hot
        # path with 10K-event Cedar dogfood sessions. solve_runs (1 per
        # session) and solve_run_escalations (one per trigger) stay on
        # the per-row _post_upsert path because batch overhead exceeds
        # benefit at low volume. Flushes on _BATCH_MAX_SIZE rows or
        # _BATCH_MAX_AGE_SEC (whichever first), and on every flush() /
        # close_run() so session_close reconciliation sees a consistent
        # DB state.
        self._batch_buffer: dict[str, list[dict[str, Any]]] = {}
        self._batch_last_flush: dict[str, float] = {}
        self._batch_lock = threading.Lock()
        # qa review on PR #281: register an atexit handler so a Python
        # process exiting cleanly without hitting close_run() / flush()
        # still drains the buffer. Customers writing one-off scripts
        # (`with kairos.session(...)` is the canonical path, but plenty
        # of dogfood scripts emit ad-hoc) get last-event durability for
        # free. atexit ordering is unreliable across forks; the handler
        # is best-effort and never raises.
        import atexit
        atexit.register(self._atexit_flush)

    def _count_events_in_db(self, run_id: str) -> int | None:
        """Return DB row count in ``sdk_agent_events`` for ``run_id``.

        ATH-585 Subtask 1: used by close_run() to reconcile against the
        in-memory emit counter. Returns None on transport failure — the
        caller treats None as "can't reconcile; do not raise."
        """
        if not self._configured:
            return None
        try:
            import urllib.request as _urlreq
            import urllib.parse as _urlparse

            # PostgREST: GET with `Prefer: count=exact` returns
            # Content-Range header carrying the count. Cheaper than
            # SELECT + len() when the session emitted >100 events.
            filter_q = (
                "run_id=eq." + _urlparse.quote(run_id, safe="")
                + "&select=id"
            )
            req = _urlreq.Request(
                f"{self._url}/rest/v1/sdk_agent_events?{filter_q}",
                headers={
                    "apikey": self._key,
                    "Authorization": f"Bearer {self._key}",
                    "Accept": "application/json",
                    "Prefer": "count=exact",
                    "Range-Unit": "items",
                    "Range": "0-0",  # Body empty; count via header.
                },
                method="GET",
            )
            with _urlreq.urlopen(req, timeout=10) as resp:
                content_range = resp.headers.get("Content-Range", "")
            # Content-Range shape: "0-0/42" or "*/0" for zero.
            if "/" in content_range:
                count_str = content_range.rsplit("/", 1)[1]
                if count_str.isdigit():
                    return int(count_str)
            return None
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.error(
                "SupabaseTraceSink._count_events_in_db(run_id=%s) "
                "failed: %s: %s",
                run_id, type(exc).__name__, exc,
            )
            return None

    def _reconcile_session(self, run_id: str) -> None:
        """ATH-585 Subtask 1: reconcile in-memory emit counter vs DB.

        Called from close_run. Compares the sink's in-memory
        ``_emit_counts[run_id]`` to a live ``SELECT COUNT(*)`` against
        ``sdk_agent_events``. Mismatch triggers:

        * ERROR log with ``(emitted, in_db, delta)``.
        * A single replay attempt of the journal (best-effort; if the
          journal is empty the missing events were silently dropped
          upstream of the sink — log a loud warning pointing at that).
        * When ``KAIROS_STRICT_SESSION_RECONCILE=1``: raise
          :class:`SessionReconcileError` so CI / dev catch the mismatch
          before prod ships.

        Match triggers an INFO log and no journal activity. Prune the
        counter entry for this run so long-lived sinks don't leak
        memory across many sessions.
        """
        expected = self._emit_counts.pop(run_id, 0)
        if expected == 0:
            # Session emitted zero events — nothing to reconcile. Common
            # for parent-only runs (open_run + close_run with no events
            # in between). Skip the DB round-trip.
            self._emit_reconciliation_event(
                run_id=run_id,
                emitted=0,
                in_db=None,
                status="skipped_empty",
            )
            return

        in_db = self._count_events_in_db(run_id)

        if in_db is None:
            # Couldn't reach the DB — fail-loud log but don't raise
            # (close_run is non-raising per TraceSink Protocol).
            _logger.warning(
                "ATH-585 reconcile(run_id=%s): DB count unavailable, "
                "cannot verify that emitted=%d events landed. Journal "
                "may contain pending events; run `kairos trace replay`.",
                run_id, expected,
            )
            self._emit_reconciliation_event(
                run_id=run_id,
                emitted=expected,
                in_db=None,
                status="db_unreachable",
            )
            return

        if in_db == expected:
            _logger.info(
                "ATH-585 reconcile(run_id=%s): emitted=%d in_db=%d — matched.",
                run_id, expected, in_db,
            )
            self._emit_reconciliation_event(
                run_id=run_id,
                emitted=expected,
                in_db=in_db,
                status="matched",
            )
            return

        delta = expected - in_db
        _logger.error(
            "ATH-585 reconcile(run_id=%s): emitted=%d in_db=%d delta=%d — "
            "some events are missing from the DB. Check "
            "~/.kairos/failed_events.jsonl for journal entries and run "
            "`kairos trace replay` to drain.",
            run_id, expected, in_db, delta,
        )
        # Journal a reconcile-drift marker so operators can trace which
        # session had the gap. The test_sentinel field is NOT set — this
        # is a real drift event + CI gate (subtask 3) should flag it.
        _journal_failed_event(
            table="__reconcile_drift__",
            body={
                "run_id": run_id,
                "emitted": expected,
                "in_db": in_db,
                "delta": delta,
                "note": "ATH-585 session-close reconciliation drift",
            },
            method="RECONCILE",
            response_status=None,
            response_body="",
            exc=SessionReconcileError(
                f"run_id={run_id}: emitted={expected} in_db={in_db}"
            ),
        )

        self._emit_reconciliation_event(
            run_id=run_id,
            emitted=expected,
            in_db=in_db,
            status="drift",
        )

        if _is_reconcile_strict():
            raise SessionReconcileError(
                f"run_id={run_id}: emitted={expected} in_db={in_db} "
                f"delta={delta}"
            )

    def _emit_reconciliation_event(
        self,
        *,
        run_id: str,
        emitted: int,
        in_db: int | None,
        status: str,
    ) -> None:
        """ATH-587 slice B: emit session_reconciliation trace event.

        Uses :meth:`_direct_post` so the event itself doesn't trigger a
        retry loop — reconciliation runs at session close, one shot, and
        we don't want to block close_run on retry sleeps.
        """
        if not self._configured:
            return
        evt = TraceEvent(
            run_id=run_id,
            run_type="sdk_orchestration",
            run_subtype="generator_synthesis",
            event_type="session_reconciliation",
            sequence=0,
            payload={
                "emitted_count": emitted,
                "in_db_count": in_db,
                "status": status,
                "session_id": run_id,
            },
        )
        try:
            from kairos.trace_schema import (
                EVENT_SCHEMA_VERSION,
                build_sdk_agent_event_body,
            )
            body = build_sdk_agent_event_body(evt)
            body["event_schema_version"] = EVENT_SCHEMA_VERSION
            self._direct_post(table="sdk_agent_events", body=body)
        except Exception:  # pragma: no cover — Protocol non-raising
            _logger.exception(
                "_emit_reconciliation_event: direct POST raised — "
                "event lost (reconciliation log line already written)"
            )

    def _sum_cost_from_events(self, run_id: str) -> float | None:
        """Aggregate ``cost_usd`` across all sdk_agent_events rows for
        a given run_id (ATH-548). Returns None on transport failure so
        the caller falls back to whatever the caller supplied.

        Fetches the payload column for every event under ``run_id``,
        parses each payload's ``cost_usd`` field, and sums. Single
        PostgREST call per session-close; bounded by the number of
        events emitted in the session (typically <100). Capped in
        practice by the sdk_agent_events schema's payload size cap.
        """
        if not self._configured:
            return None
        try:
            import urllib.request as _urlreq
            import urllib.parse as _urlparse
            import json as _json

            # PostgREST: GET /rest/v1/sdk_agent_events?run_id=eq.<id>
            #            &select=payload
            # Limit guards against pathological event floods (default
            # PostgREST limit is 1000, which is fine for session close).
            filter_q = (
                "run_id=eq." + _urlparse.quote(run_id, safe="")
                + "&select=payload"
            )
            req = _urlreq.Request(
                f"{self._url}/rest/v1/sdk_agent_events?{filter_q}",
                headers={
                    "apikey": self._key,
                    "Authorization": f"Bearer {self._key}",
                    "Accept": "application/json",
                },
                method="GET",
            )
            with _urlreq.urlopen(req, timeout=10) as resp:
                rows = _json.loads(resp.read().decode("utf-8"))
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.error(
                "SupabaseTraceSink._sum_cost_from_events(run_id=%s) "
                "failed: %s: %s",
                run_id, type(exc).__name__, exc,
            )
            return None

        total = 0.0
        found_any = False
        for row in rows:
            payload = row.get("payload") or {}
            cost = payload.get("cost_usd")
            if cost is None:
                continue
            try:
                total += float(cost)
                found_any = True
            except (TypeError, ValueError):
                continue
        # Return None when NO event in the run carried a cost_usd —
        # leave the caller's field-absent body PATCH alone rather than
        # pinning to 0.0 (which would falsely report "no cost" when in
        # fact we just didn't collect cost-bearing events).
        return total if found_any else None

    # ATH-585 Subtask 2: retry schedule before journalling. Tuned per
    # platform's 2026-04-24 07:38Z directive — fast first retry catches
    # transient 503s from Supabase's front-door without adding perceptible
    # latency to the happy path; later backoffs give slower outages room
    # to recover before we fall through to the journal (which is recovery-
    # only per the zero-loss contract, ATH-581).
    _RETRY_BACKOFF_SEC: tuple[float, ...] = (0.25, 1.0, 4.0)

    # ATH-779: per-table batching. _BATCHED_TABLES is the allowlist of
    # tables that go through `_post_upsert_batch` (a JSON-array POST).
    # Anything not in the set falls through to the per-row `_post_upsert`
    # path. Today only `sdk_agent_events` qualifies — it's the hot path
    # with 10K-event Cedar dogfood sessions; solve_runs (1 per session)
    # and solve_run_escalations (one per trigger) are too low-volume to
    # benefit. Tunables informed by the QA audit recommendation
    # (events.append; flush at >=100 OR age>5s).
    _BATCH_MAX_SIZE: int = 100
    _BATCH_MAX_AGE_SEC: float = 5.0
    _BATCHED_TABLES: frozenset[str] = frozenset({"sdk_agent_events"})

    def _emit_retry_summary(
        self,
        *,
        run_id: str,
        table: str,
        attempts: int,
        final_status: str,
    ) -> None:
        """ATH-587 slice B: emit a retry_attempt summary event once per
        _post_upsert that actually retried. Bypasses the retry loop
        internally (single-attempt direct POST) so we can't recurse into
        retries of the retry-attempt event itself.
        """
        # Only emit when at least one retry happened (attempts > 1).
        if attempts <= 1:
            return
        if not self._configured:
            return
        # Build TraceEvent inline; no recursive retry loop.
        evt = TraceEvent(
            run_id=run_id,
            run_type="sdk_orchestration",
            run_subtype="generator_synthesis",
            event_type="retry_attempt",
            sequence=0,
            payload={
                "table": table,
                "attempts": attempts,
                "final_status": final_status,
                "session_id": run_id,
            },
        )
        # Construct body directly to avoid another _post_upsert retry
        # loop. Best-effort single POST; journal on any failure.
        try:
            from kairos.trace_schema import (
                EVENT_SCHEMA_VERSION,
                build_sdk_agent_event_body,
            )
            body = build_sdk_agent_event_body(evt)
            body["event_schema_version"] = EVENT_SCHEMA_VERSION
            self._direct_post(table="sdk_agent_events", body=body)
        except Exception:  # pragma: no cover — Protocol non-raising
            _logger.exception(
                "_emit_retry_summary: direct POST raised — event lost "
                "(retry_attempt metadata only; core event already landed)"
            )

    def _direct_post(self, *, table: str, body: Mapping[str, Any]) -> None:
        """Single-attempt POST without retry. Used by
        :meth:`_emit_retry_summary` so the retry-summary event doesn't
        recurse into the retry loop. Journals on any failure.
        """
        import urllib.request as _urlreq
        import urllib.error as _urlerr
        import json as _json

        req = _urlreq.Request(
            f"{self._url}/rest/v1/{table}",
            data=_json.dumps(_sanitize_floats_for_json(body), default=str).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Prefer": "resolution=merge-duplicates",
            },
            method="POST",
        )
        try:
            with _urlreq.urlopen(req, timeout=10) as resp:
                _ = resp.read()
        except _urlerr.HTTPError as http_exc:
            try:
                resp_body = http_exc.read().decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001 — broad-catch fallback
                resp_body = ""
            _journal_failed_event(
                table=table, body=body, method="POST",
                response_status=http_exc.code, response_body=resp_body,
                exc=http_exc,
            )
        except Exception as exc:  # noqa: BLE001 — broad-catch fallback
            _journal_failed_event(
                table=table, body=body, method="POST",
                response_status=None, response_body="",
                exc=exc,
            )

    def _post_upsert(self, table: str, body: Mapping[str, Any]) -> None:
        """Internal: POST upsert to Supabase REST.

        ATH-585 retry-with-backoff: on 5xx or transport errors, retry up
        to 3 times with exponential backoff (250ms, 1s, 4s) before
        journalling. 4xx errors (malformed request / auth) skip retry and
        journal immediately — retrying won't change the outcome.

        ATH-553 fail-loud contract (still the fallback): HTTP failures and
        transport errors that survive retries are JOURNALLED to
        ``~/.kairos/failed_events.jsonl`` (override via
        ``KAIROS_FAILED_EVENTS_JOURNAL``) and logged at WARNING — not
        silently swallowed. Operators drain the journal via
        ``kairos trace replay`` (ATH-554) after outages. The call is
        still non-raising per TraceSink Protocol.

        Zero-data-loss guarantee (ATH-581): when `ATHANOR_SYNC_TOKEN` is
        set, every event either lands in Supabase via a successful retry
        OR lands in the journal for replay. Nothing gets silently
        dropped.
        """
        if not self._configured:
            return
        import time
        import urllib.request as _urlreq
        import urllib.error as _urlerr
        import json as _json
        req = _urlreq.Request(
            f"{self._url}/rest/v1/{table}",
            data=_json.dumps(_sanitize_floats_for_json(body), default=str).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Prefer": "resolution=merge-duplicates",
            },
            method="POST",
        )

        # Retry loop: (attempt 1) + (3 retries) = up to 4 total attempts.
        last_http_exc: _urlerr.HTTPError | None = None
        last_transport_exc: Exception | None = None
        last_resp_body: str = ""
        for attempt, backoff in enumerate([0.0, *self._RETRY_BACKOFF_SEC]):
            if backoff > 0:
                time.sleep(backoff)
            try:
                with _urlreq.urlopen(req, timeout=10) as resp:
                    _ = resp.read()
                # On successful emit, increment the counter so
                # session-close reconciliation (ATH-585 subtask 1) can
                # verify DB rows match what the sink thinks it sent.
                # Only count sdk_agent_events — solve_runs are parent
                # rows (one per session, counted separately) and
                # solve_run_escalations are escalations (different table).
                if table == "sdk_agent_events":
                    self._emit_counts[body.get("run_id", "")] = (
                        self._emit_counts.get(body.get("run_id", ""), 0) + 1
                    )
                # ATH-587 slice B: emit retry_attempt summary when we
                # actually retried (attempts > 1). Skipped when
                # emitting for the retry_attempt event itself (avoids
                # infinite recursion — _direct_post is the code path
                # for that).
                if attempt > 0 and table == "sdk_agent_events":
                    run_id = body.get("run_id", "")
                    self._emit_retry_summary(
                        run_id=run_id,
                        table=table,
                        attempts=attempt + 1,
                        final_status="success",
                    )
                return
            except _urlerr.HTTPError as http_exc:
                try:
                    resp_body = http_exc.read().decode("utf-8", errors="replace")
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    resp_body = ""
                last_http_exc = http_exc
                last_resp_body = resp_body
                # 4xx means the request is malformed — no retry (won't
                # change). 5xx means server-side transient — retry.
                if 400 <= http_exc.code < 500:
                    break
                if attempt < len(self._RETRY_BACKOFF_SEC):
                    _logger.info(
                        "SupabaseTraceSink._post_upsert(table=%s) HTTP %d "
                        "on attempt %d — retrying after %.3fs backoff",
                        table, http_exc.code, attempt + 1,
                        self._RETRY_BACKOFF_SEC[attempt],
                    )
                    continue
            except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                last_transport_exc = exc
                if attempt < len(self._RETRY_BACKOFF_SEC):
                    _logger.info(
                        "SupabaseTraceSink._post_upsert(table=%s) transport "
                        "%s on attempt %d — retrying after %.3fs backoff",
                        table, type(exc).__name__, attempt + 1,
                        self._RETRY_BACKOFF_SEC[attempt],
                    )
                    continue

        # All attempts exhausted — journal for replay.
        if last_http_exc is not None:
            _logger.warning(
                "SupabaseTraceSink._post_upsert(table=%s) HTTP %s after "
                "%d attempts — journalling for replay: %s",
                table, last_http_exc.code,
                1 + len(self._RETRY_BACKOFF_SEC),
                last_resp_body[:200],
            )
            _journal_failed_event(
                table=table, body=body, method="POST",
                response_status=last_http_exc.code,
                response_body=last_resp_body,
                exc=last_http_exc,
            )
        elif last_transport_exc is not None:
            _logger.warning(
                "SupabaseTraceSink._post_upsert(table=%s) transport error "
                "after %d attempts — journalling for replay: %s: %s",
                table, 1 + len(self._RETRY_BACKOFF_SEC),
                type(last_transport_exc).__name__, last_transport_exc,
            )
            _journal_failed_event(
                table=table, body=body, method="POST",
                response_status=None, response_body="",
                exc=last_transport_exc,
            )

        # 2026-04-25 (Sam directive): in strict mode, raise after retry
        # exhaustion + journal write so the script crashes loud instead
        # of silently absorbing the failure. The journal is still
        # populated above (no data loss either way), but strict callers
        # know IMMEDIATELY rather than after thousands of silent emits.
        if _is_trace_strict():
            if last_http_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink._post_upsert(table={table}) HTTP "
                    f"{last_http_exc.code} after retries (strict mode). "
                    f"Body preview: {last_resp_body[:200]}. "
                    f"Failed event journalled at "
                    f"{os.environ.get('KAIROS_FAILED_EVENTS_JOURNAL') or '~/.kairos/failed_events.jsonl'} "
                    f"for replay via `kairos trace replay` (ATH-554)."
                ) from last_http_exc
            if last_transport_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink._post_upsert(table={table}) "
                    f"transport error after retries (strict mode): "
                    f"{type(last_transport_exc).__name__}: "
                    f"{last_transport_exc}"
                ) from last_transport_exc

    def _post_upsert_batch(
        self, table: str, bodies: list[Mapping[str, Any]]
    ) -> None:
        """ATH-779: bulk-INSERT a JSON array of rows into the table.

        Mirrors :meth:`_post_upsert` (retry/journal/strict-mode contract)
        but POSTs a list payload instead of a single row. Idempotency via
        ``Prefer: resolution=merge-duplicates`` is preserved — PostgREST
        applies it per-row in the array, so duplicate event IDs across
        batches still dedupe correctly.

        On retry exhaustion, every body in the failed batch is journalled
        independently — replay tooling already iterates per-row, so a
        500-row batch failure produces 500 journal entries that can be
        retried one-at-a-time when ``kairos trace replay`` runs.
        """
        if not self._configured or not bodies:
            return
        import time
        import urllib.request as _urlreq
        import urllib.error as _urlerr
        import json as _json

        payload = _json.dumps(
            [_sanitize_floats_for_json(b) for b in bodies], default=str
        ).encode("utf-8")
        req = _urlreq.Request(
            f"{self._url}/rest/v1/{table}",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Prefer": "resolution=merge-duplicates",
            },
            method="POST",
        )

        last_http_exc: _urlerr.HTTPError | None = None
        last_transport_exc: Exception | None = None
        last_resp_body: str = ""
        for attempt, backoff in enumerate([0.0, *self._RETRY_BACKOFF_SEC]):
            if backoff > 0:
                time.sleep(backoff)
            try:
                with _urlreq.urlopen(req, timeout=10) as resp:
                    _ = resp.read()
                # Increment per-run reconcile counter once per body in
                # the batch. Mirrors the per-row _post_upsert behaviour
                # (ATH-585 subtask 1) — close-time reconciliation reads
                # from this dict and matches against DB COUNT(*).
                if table == "sdk_agent_events":
                    for body in bodies:
                        run_id = body.get("run_id", "")
                        self._emit_counts[run_id] = (
                            self._emit_counts.get(run_id, 0) + 1
                        )
                # ATH-587 slice B: emit retry_attempt summary per unique
                # run_id when at least one retry happened. _emit_retry_summary
                # uses _direct_post (single-row) so it can't recurse into
                # the batch path. Skip for non-sdk_agent_events tables.
                if attempt > 0 and table == "sdk_agent_events":
                    seen: set[str] = set()
                    for body in bodies:
                        run_id = body.get("run_id", "")
                        if run_id and run_id not in seen:
                            seen.add(run_id)
                            self._emit_retry_summary(
                                run_id=run_id,
                                table=table,
                                attempts=attempt + 1,
                                final_status="success",
                            )
                return
            except _urlerr.HTTPError as http_exc:
                try:
                    resp_body = http_exc.read().decode("utf-8", errors="replace")
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    resp_body = ""
                last_http_exc = http_exc
                last_resp_body = resp_body
                if 400 <= http_exc.code < 500:
                    break
                if attempt < len(self._RETRY_BACKOFF_SEC):
                    _logger.info(
                        "SupabaseTraceSink._post_upsert_batch(table=%s, "
                        "n=%d) HTTP %d on attempt %d — retrying after "
                        "%.3fs backoff",
                        table, len(bodies), http_exc.code, attempt + 1,
                        self._RETRY_BACKOFF_SEC[attempt],
                    )
                    continue
            except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                last_transport_exc = exc
                if attempt < len(self._RETRY_BACKOFF_SEC):
                    _logger.info(
                        "SupabaseTraceSink._post_upsert_batch(table=%s, "
                        "n=%d) transport %s on attempt %d — retrying "
                        "after %.3fs backoff",
                        table, len(bodies), type(exc).__name__,
                        attempt + 1, self._RETRY_BACKOFF_SEC[attempt],
                    )
                    continue

        # All attempts exhausted — journal each body individually.
        if last_http_exc is not None:
            _logger.warning(
                "SupabaseTraceSink._post_upsert_batch(table=%s, n=%d) "
                "HTTP %s after %d attempts — journalling each row for "
                "replay: %s",
                table, len(bodies), last_http_exc.code,
                1 + len(self._RETRY_BACKOFF_SEC),
                last_resp_body[:200],
            )
            for body in bodies:
                _journal_failed_event(
                    table=table, body=body, method="POST",
                    response_status=last_http_exc.code,
                    response_body=last_resp_body,
                    exc=last_http_exc,
                )
        elif last_transport_exc is not None:
            _logger.warning(
                "SupabaseTraceSink._post_upsert_batch(table=%s, n=%d) "
                "transport error after %d attempts — journalling each "
                "row for replay: %s: %s",
                table, len(bodies), 1 + len(self._RETRY_BACKOFF_SEC),
                type(last_transport_exc).__name__, last_transport_exc,
            )
            for body in bodies:
                _journal_failed_event(
                    table=table, body=body, method="POST",
                    response_status=None, response_body="",
                    exc=last_transport_exc,
                )

        if _is_trace_strict():
            if last_http_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink._post_upsert_batch(table={table}, "
                    f"n={len(bodies)}) HTTP {last_http_exc.code} after "
                    f"retries (strict mode). Body preview: "
                    f"{last_resp_body[:200]}. Failed rows journalled at "
                    f"{os.environ.get('KAIROS_FAILED_EVENTS_JOURNAL') or '~/.kairos/failed_events.jsonl'} "
                    f"for replay via `kairos trace replay` (ATH-554)."
                ) from last_http_exc
            if last_transport_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink._post_upsert_batch(table={table}, "
                    f"n={len(bodies)}) transport error after retries "
                    f"(strict mode): {type(last_transport_exc).__name__}: "
                    f"{last_transport_exc}"
                ) from last_transport_exc

    def _enqueue_batched(self, table: str, body: dict[str, Any]) -> None:
        """ATH-779: append a row to the per-table batch buffer.

        Flushes immediately when:
          * the buffer reaches ``_BATCH_MAX_SIZE`` rows, OR
          * more than ``_BATCH_MAX_AGE_SEC`` seconds have elapsed since
            the last flush for this table.

        Caller must NOT hold ``_batch_lock``. Method acquires it for the
        in-memory enqueue + drain, then RELEASES it before the network
        round-trip. qa review on PR #281: holding the lock during the
        cross-Atlantic POST would re-introduce the thread-pool stall
        ATH-738 just removed — concurrent emits would block waiting for
        the network. Drain-under-lock + POST-outside is the standard
        pattern; concurrent appends during the POST simply land in the
        next batch.
        """
        drained: list[dict[str, Any]] = []
        with self._batch_lock:
            drained = self._enqueue_and_maybe_drain_locked(table, body)
        if drained:
            self._post_upsert_batch(table, drained)

    def _enqueue_and_maybe_drain_locked(
        self, table: str, body: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Append + check thresholds + drain in one critical section.

        Caller MUST hold ``_batch_lock``. Returns the drained list when
        a flush threshold was hit (caller posts outside the lock); empty
        list otherwise.
        """
        import time
        buf = self._batch_buffer.setdefault(table, [])
        if table not in self._batch_last_flush:
            self._batch_last_flush[table] = time.monotonic()
        buf.append(body)
        size_hit = len(buf) >= self._BATCH_MAX_SIZE
        age_hit = (
            time.monotonic() - self._batch_last_flush[table]
            > self._BATCH_MAX_AGE_SEC
        )
        if size_hit or age_hit:
            return self._drain_batch_table_locked(table)
        return []

    def _atexit_flush(self) -> None:
        """ATH-779: best-effort drain at interpreter shutdown.

        Registered via :mod:`atexit` from :meth:`__init__`. Catches every
        exception so a half-shut-down interpreter (closed urllib pool,
        torn-down SSL context, etc.) can't crash the exit path. Never
        raises.
        """
        try:
            self.flush()
        except Exception:  # noqa: BLE001 — atexit must not raise
            pass

    def _drain_batch_table_locked(self, table: str) -> list[dict[str, Any]]:
        """ATH-779: pop one table's buffer atomically.

        Caller MUST hold ``_batch_lock``. Returns the drained list;
        caller posts it OUTSIDE the lock so the network round-trip
        doesn't serialize concurrent emits. The buffer + last-flush
        timestamp are reset before return so any concurrent
        :meth:`_enqueue_batched` lands in a fresh next batch.

        Returns ``[]`` for an empty buffer (no-op flush).
        """
        import time
        bodies = self._batch_buffer.get(table)
        if not bodies:
            return []
        self._batch_buffer[table] = []
        self._batch_last_flush[table] = time.monotonic()
        return bodies

    def emit(self, event: TraceEvent) -> None:
        """POST one TraceEvent to the ``sdk_agent_events`` table.

        Per-event target is ``sdk_agent_events`` (ATH-523 migration,
        2026-04-23) — NOT ``agent_traces``, which is the conversation-
        level table for solve/neuron + solve/bio full-trace dumps
        (``storage_path`` NOT NULL + UUID FK to runs.id). Body construction
        lives in :func:`kairos.trace_schema.build_sdk_agent_event_body` so
        the ATH-520 schema-drift CI gate can validate shape without mocks.

        ATH-574: emit-time payload validation against the per-event-type
        registry. Default mode logs WARN on violation (rate-limited MAX-3
        per ``(session_id, event_type)``) and emits anyway — zero drops.
        ``KAIROS_STRICT_PAYLOAD_SCHEMA=1`` raises ``PayloadSchemaError``
        instead (CI + dev only, never prod).

        ATH-779: hot-path emits to ``sdk_agent_events`` go through a
        per-table buffer; the actual POST happens in batches of
        ``_BATCH_MAX_SIZE`` rows or after ``_BATCH_MAX_AGE_SEC`` seconds,
        whichever first. Cross-Atlantic RTT cost was the dominant
        runtime cost the SDK paid (audit found 5 Cedar dogfood sessions
        emitted ~10K events each, one POST per event). :meth:`flush` and
        :meth:`close_run` drain the buffer so session_close
        reconciliation against DB COUNT(*) sees a consistent state.

        Errors logged + swallowed (TraceSink Protocol contract). Pydantic
        validation itself never raises from :func:`validate_payload`; only
        strict-mode conversion raises.
        """
        # Local import keeps kairos.trace_schema out of hot startup path
        # and avoids a circular-import pitfall: trace_schema imports
        # TraceEvent from this module.
        from kairos.trace_schema import (
            EVENT_SCHEMA_VERSION,
            build_sdk_agent_event_body,
        )

        # Run validation FIRST. Never drops the event — always emits.
        # Validation is lenient-warn in default mode; strict-raise only when
        # KAIROS_STRICT_PAYLOAD_SCHEMA=1. See _maybe_validate_and_log docstring.
        _maybe_validate_and_log(event, self._validation_state)

        # ATH-759: lazy-create the parent solve_runs row on first emit. The
        # parent INSERT must precede the event INSERT so the foreign-key
        # join (solve_runs.id = sdk_agent_events.run_id) is valid the
        # moment the event lands.
        self._maybe_flush_pending_open(event.run_id)

        body = build_sdk_agent_event_body(event)
        # ATH-574: stamp the registry version on the row so platform can
        # reason about schema evolution without re-parsing the payload.
        # Platform 2026-04-24 07:40Z confirmed the ALTER TABLE is live
        # (add_event_schema_version_to_sdk_agent_events migration).
        body["event_schema_version"] = EVENT_SCHEMA_VERSION
        if "sdk_agent_events" in self._BATCHED_TABLES:
            self._enqueue_batched("sdk_agent_events", body)
        else:  # pragma: no cover — currently always batched
            self._post_upsert("sdk_agent_events", body)

    def emit_escalation(self, event: EscalationEvent) -> None:
        """POST one EscalationEvent to ``solve_run_escalations``.

        Target table carries the 7-trigger Literal taxonomy + the
        per-escalation context payload. Errors logged + swallowed
        per Protocol contract.
        """
        # ATH-759: same lazy-flush as emit() — escalations are also
        # children of solve_runs and need the parent to exist first.
        self._maybe_flush_pending_open(event.run_id)
        self._post_upsert(
            "solve_run_escalations",
            {
                "id": event.id,
                "run_id": event.run_id,
                "theorem_id": event.theorem_id,
                "trigger": event.trigger,
                "plugin_type": event.plugin_type,
                "context": dict(event.context),
            },
        )

    def _engine_versions_supported(self) -> bool:
        """ATH-934: gate for the ``solve_runs.engine_versions jsonb`` column.

        Returns True when the platform-side schema migration (ATH-933) has
        landed and the column exists. Until then, returns False so the
        SDK doesn't POST a field PostgREST would 4xx on. SDK still
        captures the probe; it just doesn't send.

        Default contract: opt-in via ``KAIROS_SOLVE_RUNS_ENGINE_VERSIONS=1``
        so the SDK can ship before the platform column lands without
        flooding error logs. Platform flips the env on (or updates this
        default to True) the moment ATH-933 ships.
        """
        return os.environ.get("KAIROS_SOLVE_RUNS_ENGINE_VERSIONS", "").lower() in (
            "1", "true", "yes",
        )

    def _resolve_organization_id(
        self, organization_id_kwarg: str | None
    ) -> str:
        """ATH-648: resolve solve_runs.organization_id via a strict waterfall.

        Order (first hit wins):
            1. ``organization_id_kwarg`` — caller passed it explicitly.
            2. ``ATHANOR_ORG_ID`` env var.
            3. ``ATHANOR_SYNC_TOKEN`` → look up the owning org by
               SHA-256(token) against ``credentials.token_hash`` where
               ``provider='athanor_sync'`` AND ``is_active=true``. This
               mirrors the platform's ``verifySyncToken`` indexed-lookup
               path (see athanor-platform/src/lib/sync-auth.ts:62).
            4. None of the above → raise ``RuntimeError`` (fail-loud).

        Pre-ATH-648 the field was simply omitted and Supabase wrote NULL,
        so 132 internal-fleet rows accumulated without an owning org and
        platform's /solve-runs filtering broke. Fail-loud is intentional:
        a misconfigured emitter should crash the run, not silently corrupt
        the dashboard. Platform handles the backfill + NOT NULL constraint
        in a follow-up after this SDK fix lands.
        """
        # 1. Explicit kwarg wins.
        if organization_id_kwarg:
            return organization_id_kwarg

        # 2. ATH-688 Q2/Q3 (asabi-resolved): license.json may carry an
        # `organization_id` claim. License is the customer-installed
        # source of truth for who they are; reading it before the env
        # var means a customer doesn't need to set ATHANOR_ORG_ID at
        # all — dropping `~/.athanor/license.json` is sufficient.
        license_org = self._read_license_org_id()
        if license_org:
            return license_org

        # 3. Env-var override (handy for CI / one-off scripts that don't
        # carry a sync token but still want to write to a known org).
        env_org = os.environ.get("ATHANOR_ORG_ID", "").strip()
        if env_org:
            return env_org

        # 4. Sync-token lookup against credentials.token_hash. Only attempt
        # when we have both a sync token AND a configured Supabase URL —
        # otherwise we have no way to resolve and fall through to raise.
        sync_token = os.environ.get(_SYNC_TOKEN_ENV, "").strip()
        if sync_token and self._url:
            resolved = self._lookup_org_id_by_sync_token(sync_token)
            if resolved:
                return resolved

        # 5. Fail-loud — better to crash here than to write NULL.
        raise RuntimeError(
            "organization_id could not be resolved: pass organization_id= "
            "kwarg, install ~/.athanor/license.json with an "
            "organization_id claim, set ATHANOR_ORG_ID env, or set "
            "ATHANOR_SYNC_TOKEN bound to an org. None were available. "
            "(ATH-648, ATH-688)"
        )

    def _read_license_org_id(self) -> str | None:
        """ATH-688 Q2/Q3: read `organization_id` claim from
        `~/.athanor/license.json` if it exists.

        Returns the claim string, or None when:
            - No license file installed.
            - License file has no `organization_id` field.
            - License parsing raises (we never crash the trace pipeline
              on a corrupt license file — the policy gate
              `kairos.license_scope.load_license` is the source of
              truth for fail-closed behavior; this read is best-effort
              org-resolution only).

        ATH-695: short-circuit when ``KAIROS_DEV_NO_LICENSE=1`` is set.
        The dev-bypass License has no organization_id claim anyway, so
        calling ``load_license`` here would just emit one ``dev_bypass``
        audit-log row per ``open_run`` with no resolution benefit. CI
        workers running thousands of ``open_run`` calls with the bypass
        flag set were burying the real customer ``dev_bypass`` signal in
        their own noise.
        """
        if os.environ.get("KAIROS_DEV_NO_LICENSE") == "1":
            return None
        try:
            from kairos.license_scope import load_license
            license_ = load_license()
        except Exception:  # noqa: BLE001 — never crash trace on bad license
            return None
        org_id = license_.raw.get("organization_id")
        if isinstance(org_id, str) and org_id.strip():
            return org_id.strip()
        return None

    def _lookup_org_id_by_sync_token(self, sync_token: str) -> str | None:
        """Hash the token and look up ``credentials.organization_id``.

        Mirrors athanor-platform's verifySyncToken indexed path:
        SHA-256 hex of plaintext → ``credentials.token_hash`` lookup
        scoped to ``provider='athanor_sync'`` AND ``is_active=true``.
        Returns the owning org_id, or ``None`` on miss / transport error.

        Note: this method does NOT consult the legacy decrypt-and-scan
        fallback. The 2026-04-11 ATH-77 hash-write path has been live
        for two weeks; every active SDK token rotated through it. A
        legacy-token caller who hits this path would hit the fail-loud
        raise in :meth:`_resolve_organization_id` and learn to rotate.
        """
        if not self._configured:
            return None
        import hashlib
        import json as _json
        import urllib.parse as _urlparse
        import urllib.request as _urlreq

        token_hash = hashlib.sha256(sync_token.encode("utf-8")).hexdigest()
        filter_q = _urlparse.urlencode(
            {
                "select": "organization_id",
                "provider": "eq.athanor_sync",
                "is_active": "eq.true",
                "token_hash": f"eq.{token_hash}",
                "limit": "1",
            }
        )
        req = _urlreq.Request(
            f"{self._url}/rest/v1/credentials?{filter_q}",
            headers={
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Accept": "application/json",
            },
            method="GET",
        )
        try:
            with _urlreq.urlopen(req, timeout=10) as resp:
                rows = _json.loads(resp.read().decode("utf-8") or "[]")
        except Exception as exc:  # pragma: no cover — network-dependent  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.warning(
                "SupabaseTraceSink._lookup_org_id_by_sync_token failed: "
                "%s: %s", type(exc).__name__, exc,
            )
            return None
        if isinstance(rows, list) and rows:
            org_id = rows[0].get("organization_id")
            if isinstance(org_id, str) and org_id:
                return org_id
        return None

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        """Stash a deferred ``solve_runs`` parent-row body for ``run_id``.

        ATH-759: lazy contract — the row is INSERT'd on the *first*
        :meth:`emit` (or :meth:`emit_escalation`) call, not here.
        :meth:`close_run` on a still-pending ``run_id`` discards the body
        and writes nothing. The 2026-04-25 audit found 52 of 68 7d stub
        rows came from drivers (Cedar diff harness with a stale SDK,
        hand-rolled scripts) that called open_run + close_run with zero
        events between — those used to leave empty parent rows in the
        dashboard; now they leave nothing.

        Drivers using :func:`kairos.session` are unaffected: prove.py
        emits ``session_open`` synchronously after open_run, so the
        parent row still lands in the same tick. The lazy flush is
        idempotent + cheap (one dict pop on first emit).

        The parent row's ``target`` column is set to ``run_id`` so
        per-event ``sdk_agent_events`` rows join naturally via
        ``solve_runs.id = sdk_agent_events.run_id``. The row's own
        UUID is set to ``run_id`` (not auto-genned). ``status``
        starts as ``running``; close_run updates it on completion.

        Vertical must be one of the ``solve_runs.vertical`` CHECK
        values (``neuron`` | ``bio`` | ``action_cred`` | ``sysverilog``
        | ``auth`` | ``networking`` | ``distributed_systems`` |
        ``systems_migration`` | ``hardware`` | ``other``). SDK callers
        that don't map to a domain (research sweeps, generic
        generator_synthesize) use ``other`` — the default.

        ATH-648: ``organization_id`` is resolved via the strict waterfall
        in :meth:`_resolve_organization_id` (kwarg → env → sync-token
        lookup → fail-loud). Pre-ATH-648 this field was never set and
        every SDK ``kairos.session()`` wrote NULL — which broke the
        platform's per-org filtering on /solve-runs. Resolution is
        explicit + fail-loud rather than best-effort because a
        misconfigured emitter should crash the run, not corrupt the
        dashboard with orphan rows.

        ATH-649 (separate ticket, P1): the per-event REST emit path in
        :meth:`_post_upsert` is unbatched — one POST per event, which
        adds round-trip latency on the cross-Atlantic Cedar 10K-event
        sessions. NOT touched here; this PR is scoped to org_id only.
        """
        from datetime import datetime, timezone

        # 2026-04-25: pass id=run_id explicitly so solve_runs.id == the
        # session_id used by every event's run_id field. Without this,
        # Postgres auto-genned a fresh UUID and the JOIN
        # (solve_runs.id = sdk_agent_events.run_id) was broken — every
        # SDK-orchestrated session became orphan events. ATH-572's
        # name_for_display kwarg made it worse by re-purposing `target`
        # for display strings, so neither id nor target matched the
        # event run_ids. Now: id is the join key, target is the
        # human-readable label (display string when set, else run_id).

        # If the sink isn't configured (no URL / no key), the row would
        # be dropped by _post_upsert anyway. Skip the org_id resolution
        # waterfall too — there's no Supabase to talk to for the token
        # lookup, and we don't want to fail-loud on test fixtures that
        # construct an unconfigured sink to assert the silent-drop path.
        if not self._configured:
            return

        # ATH-677 v1.2: license gate on athanor-prod cloud writes.
        # Per docs/sdk-tier-model.md §3.6: writes to *.athanor-ai.com
        # are paid-tier (the SaaS dashboard); self-hosted Supabase
        # URLs (the customer's own instance) are allowed without
        # license. The gate fires here at row-open rather than at
        # construction so a free-tier customer who configures a
        # self-hosted Supabase URL is never asked for a license.
        if self._url and ".athanor-ai.com" in self._url:
            from kairos.license_scope import require_product
            require_product("solve")

        resolved_org_id = self._resolve_organization_id(organization_id)

        body: dict[str, Any] = {
            "id": run_id,
            "vertical": vertical,
            "target": target if target is not None else run_id,
            "agent_count_mode": "fleet",
            "pipeline_version": pipeline_version,
            "status": "running",
            "dry_run": False,
            "started_at": datetime.now(timezone.utc).isoformat(),
            "organization_id": resolved_org_id,
        }
        if builder_model is not None:
            body["builder_model"] = builder_model
        # ATH-934: pre-stage engine_versions JSON. Platform-side schema
        # migration (ATH-933) adds the `engine_versions jsonb` column;
        # until that lands, Supabase quietly accepts the field on rows
        # that don't have a corresponding column? — actually, REST PostgREST
        # rejects unknown columns. Guarded with a `_engine_versions_supported`
        # opt-in check below to avoid a flood of 4xx during the gap. Once
        # the platform column lands, set the env var or update the default
        # to True.
        if engine_versions:
            ev = {k: v for k, v in dict(engine_versions).items() if v is not None}
            if ev and self._engine_versions_supported():
                body["engine_versions"] = ev
        # ATH-759: stash the body; the first emit() / emit_escalation()
        # call for this run_id flushes it via _maybe_flush_pending_open.
        # Open-without-emit no longer creates parent rows.
        self._pending_opens[run_id] = body

    def _maybe_flush_pending_open(self, run_id: str) -> None:
        """ATH-759: flush a deferred parent solve_runs row, if any.

        Called from emit() and emit_escalation() — the first event for a
        run_id triggers the parent INSERT, then the event INSERT proceeds
        as normal. No-op when (a) this sink never had open_run called, or
        (b) the row was already flushed by a prior emit. Idempotent.
        """
        pending = self._pending_opens.pop(run_id, None)
        if pending is not None:
            self._post_upsert("solve_runs", pending)

    def upload_workdir_tarball(
        self,
        run_id: str,
        workdir: "str | Path",
        *,
        artifact_type: str = "workdir_tarball",
        filename: str = "workdir.tar.gz",
    ) -> bool:
        """ATH-626 sub-4: tar+gzip ``workdir`` and upload to the
        ``solve-artifacts`` Storage bucket; insert a ``solve_artifacts``
        row pointing at it so the platform's /solve-runs/[id] detail
        page can render a download link.

        Returns True on success, False on any failure (non-raising per
        the TraceSink Protocol; failures are logged + swallowed). Safe
        to call from :meth:`session` on context-manager exit even if
        the workdir is empty or missing — the no-up-side cases short-
        circuit cleanly.

        Storage layout:
            solve-artifacts/<run_id>/<filename>

        solve_artifacts row written via REST:
            solve_run_id = run_id    (= solve_runs.id, post-2026-04-25 contract)
            artifact_type, filename, storage_path, sha256, size_bytes

        File-size cap: 100 MiB (matches the bucket limit). Larger workdirs
        are skipped with a WARN. Customers with bigger workdirs should
        upload selectively via their own sink subclass.
        """
        from pathlib import Path as _Path
        import hashlib as _hashlib
        import subprocess as _sub
        import tempfile as _tempfile
        import urllib.request as _urlreq
        import urllib.error as _urlerr

        BUCKET = "solve-artifacts"
        SIZE_CAP_BYTES = 100 * 1024 * 1024  # 100 MiB

        wd = _Path(workdir)
        if not wd.exists() or not wd.is_dir():
            _logger.info(
                "SupabaseTraceSink.upload_workdir_tarball: skip — "
                "workdir %r does not exist or is not a directory", str(wd),
            )
            return False

        tar_path = _Path(_tempfile.mkstemp(suffix=".tar.gz", prefix="kairos_workdir_")[1])
        try:
            try:
                _sub.run(
                    ["tar", "-czf", str(tar_path), "-C", str(wd), "."],
                    check=True, capture_output=True, timeout=120,
                )
            except (_sub.CalledProcessError, _sub.TimeoutExpired) as exc:
                _logger.warning(
                    "SupabaseTraceSink.upload_workdir_tarball: tar "
                    "failed for %r: %s", str(wd), exc,
                )
                return False

            size = tar_path.stat().st_size
            if size > SIZE_CAP_BYTES:
                _logger.warning(
                    "SupabaseTraceSink.upload_workdir_tarball: tarball "
                    "size %d > cap %d for run_id=%s; skipping upload",
                    size, SIZE_CAP_BYTES, run_id,
                )
                return False

            h = _hashlib.sha256()
            with tar_path.open("rb") as fh:
                for chunk in iter(lambda: fh.read(64 * 1024), b""):
                    h.update(chunk)
            sha256 = h.hexdigest()
            storage_path = f"{run_id}/{filename}"

            with tar_path.open("rb") as fh:
                upload_req = _urlreq.Request(
                    f"{self._url}/storage/v1/object/{BUCKET}/{storage_path}",
                    data=fh.read(),
                    headers={
                        "Content-Type": "application/gzip",
                        "apikey": self._key,
                        "Authorization": f"Bearer {self._key}",
                        "x-upsert": "true",
                    },
                    method="POST",
                )
                try:
                    with _urlreq.urlopen(upload_req, timeout=60) as resp:
                        _ = resp.read()
                except _urlerr.HTTPError as http_exc:
                    body_preview = ""
                    try:
                        body_preview = http_exc.read().decode("utf-8", errors="replace")[:200]
                    except Exception:  # noqa: BLE001 — best-effort; failure swallowed
                        pass
                    _logger.warning(
                        "SupabaseTraceSink.upload_workdir_tarball: "
                        "storage POST HTTP %d for run_id=%s: %s",
                        http_exc.code, run_id, body_preview,
                    )
                    return False
                except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                    _logger.warning(
                        "SupabaseTraceSink.upload_workdir_tarball: "
                        "storage POST transport error for run_id=%s: %s: %s",
                        run_id, type(exc).__name__, exc,
                    )
                    return False

            self._post_upsert(
                "solve_artifacts",
                {
                    "solve_run_id": run_id,
                    "artifact_type": artifact_type,
                    "filename": filename,
                    "storage_path": storage_path,
                    "sha256": sha256,
                    "size_bytes": size,
                },
            )
            _logger.info(
                "SupabaseTraceSink.upload_workdir_tarball: uploaded "
                "%s (%d bytes, sha256=%s) for run_id=%s",
                storage_path, size, sha256[:12], run_id,
            )
            return True
        finally:
            try:
                tar_path.unlink()
            except OSError:
                pass

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        """PATCH the ``solve_runs`` row opened by :meth:`open_run` to
        record terminal state (ATH-544 / ATH-548).

        Matches the parent row by ``solve_runs.id = run_id`` (the join key
        post-2026-04-25 contract; ``target`` is now a human-readable
        display label, not a join key). The earlier ``target=eq.<run_id>``
        filter was the root cause of the 7 stuck-running rows that PR
        #290's 12h cron sweep had to clean up — the filter never matched
        when callers passed ``name_for_display=...``.

        When :meth:`open_run` was never called for this ``run_id``
        (e.g. NoopTraceSink parent, or a call site that skips open),
        the PATCH no-ops at the REST layer — zero rows updated, no
        error raised. Status must be one of the ``solve_runs.status``
        CHECK values.

        ATH-548: when ``token_cost_usd`` is not supplied by the caller
        (``None`` or ``0.0``), we aggregate the canonical cost from
        ``sdk_agent_events`` — summing ``payload->>'cost_usd'`` across
        every event with this ``run_id``. This closes the gap where
        ``kairos.session.total_cost_usd`` only sums ``sess.prove()``
        calls, missing costs from direct ``generator_synthesize``
        invocations that stamp the session_id as their run_id.
        """
        if not self._configured:
            return

        # ATH-779: drain the per-table batch buffer before reconciling.
        # _emit_counts is incremented inside _post_upsert_batch on a
        # successful POST (mirroring the per-row _post_upsert path), so
        # any in-buffer events haven't yet been counted. Reconcile would
        # otherwise compare 0 (or partial) against the rows that
        # _eventually_ land in DB on the next flush — false drift WARN.
        # flush() is non-raising; safe to call even on early-return paths.
        self.flush()

        # ATH-759: open_run + close_run with no events between them is the
        # "open-without-emit" stub case — no parent row was ever INSERT'd
        # (open_run only stashed a body in self._pending_opens). Drop the
        # pending body and return; PATCH would no-op at the REST layer
        # anyway, and the 0-emit ⇒ 0-row symmetry is the whole point of
        # the lazy contract. Reconciliation is also trivial here (0
        # in-memory emits, 0 expected DB rows), so skip _reconcile_session.
        if run_id in self._pending_opens:
            self._pending_opens.pop(run_id, None)
            return

        from datetime import datetime, timezone

        body: dict[str, Any] = {
            "status": status,
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        if outcome_verdict is not None:
            body["outcome_verdict"] = dict(outcome_verdict)
        if final_score is not None:
            body["final_score"] = float(final_score)
        # ATH-548: fall back to sdk_agent_events SUM when caller's
        # explicit cost is missing / zero (Session.total_cost_usd
        # returns 0 when only generator_synthesize produced costs).
        # When the fallback finds nothing either (no cost-bearing
        # events under this run_id), omit the field entirely rather
        # than falsely pinning to 0.0.
        if token_cost_usd is None or token_cost_usd == 0.0:
            aggregated = self._sum_cost_from_events(run_id)
            if aggregated is not None:
                body["token_cost_usd"] = float(aggregated)
            # else: omit the field — don't stamp a fake 0.0.
        else:
            body["token_cost_usd"] = float(token_cost_usd)
        if wall_time_seconds is not None:
            body["wall_time_seconds"] = float(wall_time_seconds)

        import urllib.request as _urlreq
        import urllib.parse as _urlparse
        import urllib.error as _urlerr
        import json as _json
        # 2026-04-25: PATCH on id, not target. ATH-572's name_for_display
        # overrode target with display strings, so target=eq.<run_id>
        # never matched. Now that open_run writes id=session_id, id is
        # the stable join key.
        filter_q = "id=eq." + _urlparse.quote(run_id, safe="")
        req = _urlreq.Request(
            f"{self._url}/rest/v1/solve_runs?{filter_q}",
            data=_json.dumps(_sanitize_floats_for_json(body), default=str).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Prefer": "return=minimal",
            },
            method="PATCH",
        )
        # Journal body carries the id filter so replay can re-issue
        # the PATCH against the same row. ATH-553.
        journal_body = dict(body)
        journal_body["_target_filter"] = filter_q
        # ATH-647 finding #5: strict-mode raise was previously POST-only via
        # _post_upsert (PR #183). The PATCH path here also has to fail loud
        # in strict mode, otherwise a session that successfully opens but
        # fails to close silently leaves the parent row in 'running' forever
        # — which is precisely the symptom the PR #290 12h sweep had to
        # paper over. Mirror _post_upsert's strict-mode behaviour: journal
        # always (zero-data-loss), then re-raise on the way out when strict.
        close_http_exc: _urlerr.HTTPError | None = None
        close_transport_exc: Exception | None = None
        close_resp_body: str = ""
        try:
            with _urlreq.urlopen(req, timeout=10) as resp:
                _ = resp.read()
        except _urlerr.HTTPError as http_exc:
            try:
                resp_body = http_exc.read().decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001 — broad-catch fallback
                resp_body = ""
            close_http_exc = http_exc
            close_resp_body = resp_body
            _logger.warning(
                "SupabaseTraceSink.close_run(run_id=%s) HTTP %s — "
                "journalling for replay: %s",
                run_id, http_exc.code, resp_body[:200],
            )
            _journal_failed_event(
                table="solve_runs", body=journal_body, method="PATCH",
                response_status=http_exc.code, response_body=resp_body,
                exc=http_exc,
            )
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            close_transport_exc = exc
            _logger.warning(
                "SupabaseTraceSink.close_run(run_id=%s) transport error — "
                "journalling for replay: %s: %s",
                run_id, type(exc).__name__, exc,
            )
            _journal_failed_event(
                table="solve_runs", body=journal_body, method="PATCH",
                response_status=None, response_body="",
                exc=exc,
            )

        # ATH-647 finding #5: in strict mode, raise after journal write so
        # the script crashes loud rather than absorbing a silent close
        # failure. The journal is still populated above (no data loss
        # either way), but strict callers know IMMEDIATELY rather than
        # discovering the stale 'running' row 12h later via the cron sweep.
        if _is_trace_strict():
            if close_http_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink.close_run(run_id={run_id}) HTTP "
                    f"{close_http_exc.code} (strict mode). "
                    f"Body preview: {close_resp_body[:200]}. "
                    f"Failed PATCH journalled at "
                    f"{os.environ.get('KAIROS_FAILED_EVENTS_JOURNAL') or '~/.kairos/failed_events.jsonl'} "
                    f"for replay via `kairos trace replay` (ATH-554)."
                ) from close_http_exc
            if close_transport_exc is not None:
                raise TraceSinkTransportError(
                    f"SupabaseTraceSink.close_run(run_id={run_id}) "
                    f"transport error (strict mode): "
                    f"{type(close_transport_exc).__name__}: "
                    f"{close_transport_exc}"
                ) from close_transport_exc

        # ATH-574: surface payload-violation summary for THIS session at run
        # close. close_run is called once per session (run_id == session_id per
        # ATH-572), so we scope both the log lines and the prune to keys whose
        # first element matches run_id. Multi-session sinks (long-lived
        # daemons running concurrent sessions) keep other sessions' state
        # intact.
        for key, total in list(self._validation_state.total_violations.items()):
            session_id, event_type = key
            if session_id != run_id:
                continue
            warned = self._validation_state.warn_counts.get(key, 0)
            silent = total - warned
            _logger.info(
                "ATH-574 session-close violation summary — session=%s "
                "event_type=%s violations_total=%d warned=%d silent=%d",
                session_id, event_type, total, warned, silent,
            )
            self._validation_state.total_violations.pop(key, None)
            self._validation_state.warn_counts.pop(key, None)
        self._validation_state.unknown_warned = {
            k for k in self._validation_state.unknown_warned if k[0] != run_id
        }

        # ATH-585 Subtask 1: reconcile the session's event count with the
        # DB after the parent-row PATCH. Runs AFTER the solve_runs PATCH
        # so the DB view is consistent (counts include the session-close
        # aggregate event if there was one). Mismatch triggers WARN +
        # drift marker (or raise in strict mode).
        self._reconcile_session(run_id)

    def flush(self) -> None:
        """ATH-779: drain every per-table batch buffer + POST outside the lock.

        Called by :meth:`close_run` before reconciliation, by
        :func:`kairos.session` on context-manager exit (so customer
        sessions never leave half-buffers behind), by anything
        explicit-flush'ing the sink (e.g. test fixtures), and by the
        atexit handler so a Python process exiting cleanly without
        hitting close_run still drains its buffer.

        Pre-ATH-779 this was a no-op because the REST client was
        synchronous per-call. Now ``sdk_agent_events`` rows are buffered
        and posted in batches, so flush is the explicit drain point.

        qa review on PR #281: drain-under-lock + POST-outside, so
        concurrent emits during the network round-trip don't stall
        waiting for the lock — they just land in a fresh next batch.
        """
        drained_per_table: list[tuple[str, list[dict[str, Any]]]] = []
        with self._batch_lock:
            for table in list(self._batch_buffer.keys()):
                bodies = self._drain_batch_table_locked(table)
                if bodies:
                    drained_per_table.append((table, bodies))
        for table, bodies in drained_per_table:
            self._post_upsert_batch(table, bodies)


# ═══════════════════════════════════════════════════════════════════════
# S3TraceSink — ATH-1200, customer-BYO bucket
# ═══════════════════════════════════════════════════════════════════════


class S3TraceSink:
    """Upload TraceEvents to a customer-owned S3 bucket (ATH-1200).

    Customer flow:
    1. `kairos config s3 <bucket> [--region <r>]` persists the bucket.
    2. `S3TraceSink.from_config()` instantiates a sink reading the
       config; returns None if no bucket configured.
    3. Customer passes the sink to `kairos.observe.observe(sink=...)`
       or to a Runner via the standard sink-injection path.

    Object layout:
        s3://<bucket>/customer-traces/<org-id-or-anon>/<run-id>/<kind>/<event-id>.json

    Each event becomes its own object. The platform UI generates 5-min
    signed URLs pointing at these objects for trace browsing. Per-event
    objects are simpler than batched JSONL: no multipart, no buffer-flush
    races, deletes/retention apply per-event.

    Errors are SWALLOWED (matches TraceSink contract). A flaky S3 must
    not crash the kairos call. _logger.warning surfaces upload failures
    so customers see them in `kairos run --verbose` output.

    boto3 is lazy-imported in `__init__`. Missing boto3 raises ImportError
    with a friendly hint; tests cover this.
    """

    _CUSTOMER_PREFIX = "customer-traces"
    _DEFAULT_ORG = "anon"

    def __init__(
        self,
        bucket: str,
        region: str | None = None,
        prefix: str | None = None,
    ) -> None:
        from kairos.trace_schema import SessionValidationState

        try:
            import boto3  # noqa: F401 — presence check
        except ImportError as e:
            from kairos.aws_s3_verify import BOTO3_MISSING_HINT
            raise ImportError(BOTO3_MISSING_HINT) from e

        self._bucket = bucket
        self._region = region
        self._prefix = prefix or self._CUSTOMER_PREFIX
        self._client = boto3.client(
            "s3", **({"region_name": region} if region else {})
        )
        self._validation_state = SessionValidationState()
        # run_id → organization_id (populated on open_run; consumed by emit).
        self._run_org_map: dict[str, str] = {}

    @classmethod
    def from_config(cls) -> "S3TraceSink | None":
        """Build an S3TraceSink from `~/.athanor/config.json`, or None.

        Returns None (not raising) when no bucket is persisted, so a
        caller doing `sink = S3TraceSink.from_config() or NoopTraceSink()`
        cleanly falls through.
        """
        from kairos.config import get_s3_trace_bucket
        cfg = get_s3_trace_bucket()
        if cfg is None:
            return None
        return cls(bucket=cfg["bucket"], region=cfg.get("region"))

    def _key_for(self, run_id: str, kind: str, event_id: str) -> str:
        org = self._run_org_map.get(run_id, self._DEFAULT_ORG)
        return f"{self._prefix}/{org}/{run_id}/{kind}/{event_id}.json"

    def _put(self, key: str, payload: dict) -> None:
        import json as _json
        try:
            self._client.put_object(
                Bucket=self._bucket,
                Key=key,
                Body=_json.dumps(payload, default=str).encode("utf-8"),
                ContentType="application/json",
            )
        except Exception:  # noqa: BLE001 — best-effort observability
            _logger.warning("S3TraceSink put failed: s3://%s/%s",
                            self._bucket, key, exc_info=True)

    def emit(self, event: TraceEvent) -> None:
        _maybe_validate_and_log(event, self._validation_state)
        try:
            from dataclasses import asdict
            self._put(
                self._key_for(event.run_id, "event", event.id),
                {"kind": "event", **asdict(event)},
            )
        except Exception:  # noqa: BLE001
            _logger.warning("S3TraceSink.emit failed", exc_info=True)

    def emit_escalation(self, event: EscalationEvent) -> None:
        try:
            from dataclasses import asdict
            self._put(
                self._key_for(event.run_id, "escalation", event.id),
                {"kind": "escalation", **asdict(event)},
            )
        except Exception:  # noqa: BLE001
            _logger.warning("S3TraceSink.emit_escalation failed", exc_info=True)

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        if organization_id:
            self._run_org_map[run_id] = organization_id
        try:
            self._put(
                self._key_for(run_id, "open_run", "manifest"),
                {
                    "kind": "open_run",
                    "run_id": run_id,
                    "vertical": vertical,
                    "builder_model": builder_model,
                    "target": target,
                    "pipeline_version": pipeline_version,
                    "organization_id": organization_id,
                    "engine_versions": dict(engine_versions) if engine_versions else {},
                },
            )
        except Exception:  # noqa: BLE001
            _logger.warning("S3TraceSink.open_run failed", exc_info=True)

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        try:
            self._put(
                self._key_for(run_id, "close_run", "summary"),
                {
                    "kind": "close_run",
                    "run_id": run_id,
                    "status": status,
                    "outcome_verdict": dict(outcome_verdict) if outcome_verdict else None,
                    "final_score": final_score,
                    "token_cost_usd": token_cost_usd,
                    "wall_time_seconds": wall_time_seconds,
                },
            )
            # Free the run_id → org_id mapping on close to bound memory.
            self._run_org_map.pop(run_id, None)
        except Exception:  # noqa: BLE001
            _logger.warning("S3TraceSink.close_run failed", exc_info=True)

    def flush(self) -> None:
        """No-op — every emit synchronously PUTs to S3."""
        return None
