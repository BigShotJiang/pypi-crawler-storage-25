"""kairos.lean_orchestrate — paid-tier Lean orchestration primitives.

ATH-829 Phase 1. Customer-facing entry points for Opus-driven Lean
proof orchestration:

* :func:`race` — fan out one target to multiple drafters in parallel,
  return first-success or all-fail. Wraps the existing
  :class:`kairos.fleet.fleet_orchestrator.FleetOrchestrator` for the
  per-target case (its current sole caller is
  :func:`kairos.sorry_swarm.sorry_swarm`, which loops over many
  targets).

* :func:`solve` — the Opus-driven decompose-and-conquer orchestrator.
  Tries cheap paths first (`simple_prove_template` w/ refinement),
  escalates to multi-drafter `race`, and on continued failure either
  (a) returns structured ``decompose_hints`` so the customer's outer
  Opus agent can drive the next decomposition step using its own
  context, or (b) when ``internal_planner_model`` is provided, calls
  that planner internally to generate sub-lemmas.

Both gated by :func:`kairos.license_scope.require_product` (``"solve"``).

## Why this layer exists

ATH-727 shipped the free-tier MCP surface (single-shot `simple_prove`
+ tactic dispatch + axiom certify). The orchestration value — multi-
drafter racing, decomposition, recurse-and-assemble — is the paid
tier. This module is the customer-facing wrapping that exposes it as
a public API + via MCP (see :mod:`kairos.mcp_pro_extensions`).

## Customer-Opus pattern (the default)

::

    # In a customer agent loop where the outer agent IS Opus 4.7:
    from kairos.lean_orchestrate import solve, RaceResult, SolveResult

    target = CycleTarget(...)
    result = solve(target)  # internal_planner_model omitted

    if result.proved:
        commit(result.closing_proof)
    elif result.decompose_hints:
        # Outer Opus uses its own context (file state, Mathlib hints,
        # prior failures) to expand the hints into concrete sub-targets,
        # then calls solve() on each.
        for hint in result.decompose_hints:
            sub_target = build_sub_target(target, hint)
            sub_result = solve(sub_target)
            ...

## Why ``internal_planner_model`` is opt-in

When the customer's outer agent IS already Opus, paying for an
internal Opus call inside ``solve()`` doubles the planner cost AND
loses high-bandwidth context the outer agent has (file state, repo
history, prior failed attempts). Default behavior (``internal_planner_model=None``)
hands decomposition back to the outer agent via structured
``decompose_hints``. Setting ``internal_planner_model`` is for the
non-Opus-agent case (e.g. a customer with a Sonnet agent who wants
kairos to bring its own Opus planner).

## Architectural decisions (research-locked 2026-04-27 with QA review)

* **Module name**: ``kairos.lean_orchestrate`` (sibling-module
  pattern, matching :mod:`kairos.lean_cycle`, :mod:`kairos.sorry_swarm`).
* **DecomposeHint shape**: concrete dataclass (per QA flag #1) so
  customer agent loops can branch reliably without parsing free-text.
* **Parameter name**: ``internal_planner_model`` (per QA flag #2),
  not ``planner`` — disambiguates from
  :class:`kairos.spec.defaults.OpusOrchestrator`-style planner concepts
  internal to ``cycle_prove``.
* **Per-verifier surface**: ``lean_orchestrate.race`` is Lean-only.
  EBMC/Dafny/CBMC/Verus get their own ``ebmc.race``, ``dafny.race``,
  etc. (per QA flag #4 + ATH-829 Phase 2).

## Cross-links

* ATH-829: ticket
* ATH-726: agentic-support epic (free-tier shipped, this extends to paid)
* ATH-727: free-tier MCP server (this module's paid-tier sibling)
* ATH-570: ``kairos.fleet.orchestrate`` (internal helper this layer composes)
* ATH-728: ``simple_prove_template(refine_on_failure=True)`` (cheap-first leg)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Protocol


# ── Drafter protocol — what `race` and `solve` accept ─────────────────


class _DrafterProtocol(Protocol):
    """Structural type the orchestration layer expects from each drafter.

    Mirrors :class:`kairos.fleet.fleet_orchestrator._DrafterProtocol`;
    re-declared here so the customer-facing module doesn't expose the
    internal fleet package as a hard dependency in type signatures.
    """
    alias: str

    def cycle_prove(
        self,
        target: Any,  # CycleTarget — keep loose to avoid heavy imports
        *,
        max_rounds: int = ...,
        temperature: float = ...,
        max_tokens: int = ...,
    ) -> Any:  # CycleResult
        ...


# ── ModelClientDrafter — in-process litellm-shaped drafter ───────────


@dataclass
class ModelClientDrafter:
    """`_DrafterProtocol` adapter for an in-process litellm-shaped model.

    Use when you have a litellm-compatible model (anthropic, gemini,
    openai, etc.) and want it as one drafter in :func:`race` / :func:`solve`.
    For docker-isolated drafters use :class:`kairos.fleet.ContainerizedDrafter`
    instead — that's the fleet/multi-host shape with stronger isolation.

    Customer pattern (the recommended use):

    ::

        from kairos.lean_orchestrate import solve, ModelClientDrafter

        flash  = ModelClientDrafter(alias="flash",  model_id="gemini/gemini-3-flash-preview")
        sonnet = ModelClientDrafter(alias="sonnet", model_id="anthropic/claude-sonnet-4-6")

        result = solve(
            target=cycle_target,
            drafters=[flash, sonnet],
            internal_planner_model="anthropic/claude-sonnet-4-6",
        )

    Each :meth:`cycle_prove` call delegates to
    :func:`kairos.lean_cycle.cycle_prove` with a fresh
    :func:`kairos.model_client.get_client` instance, so the drafter
    refinement loop (lake errors → drafter retries) is automatic.

    Why this exists (ATH-840 dogfood 2026-04-28): research's overnight
    sweep had to roll its own _DrafterProtocol-shaped class for every
    cheap-tier drafter — verbatim duplication across drivers. Lifting
    the wrapper into the SDK keeps customer code 2 lines instead of 30
    and removes the bypass-the-SDK temptation.

    :param alias: short identifier (e.g. ``"flash"``, ``"sonnet"``).
        Surfaces in trace events + RaceResult.outcomes_by_drafter keys.
    :param model_id: a litellm/kairos.model_client model identifier
        (e.g. ``"anthropic/claude-sonnet-4-6"``,
        ``"gemini/gemini-3-flash-preview"``,
        ``"openai/kimi-k2.5"``).
    """
    alias: str
    model_id: str

    def cycle_prove(
        self,
        target: Any,
        *,
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
    ) -> Any:
        from kairos.model_client import get_client
        from kairos.lean_cycle import cycle_prove as _cp
        client = get_client(self.model_id)
        return _cp(
            target,
            drafter=client,
            drafter_alias=self.alias,
            max_rounds=max_rounds,
            temperature=temperature,
            max_tokens=max_tokens,
        )


# ── DecomposeHint — what an outer agent uses to drive next-step ──────


@dataclass(frozen=True)
class DecomposeHint:
    """One actionable suggestion for an outer agent to decompose a
    target after :func:`solve` returns ``proved=False``.

    Per QA architecture review (ATH-829 flag #1): customer-agent loops
    branch on this list; ambiguity in the shape would require every
    customer to write their own parser. Concrete dataclass keeps the
    contract testable and the agent loop small.

    Attributes:
        sub_target_name: Suggested theorem/lemma name (Lean-identifier
            shape, no spaces). Customer may use it verbatim or as a
            naming starting-point.
        sub_target_source: Suggested Lean source for the sub-target —
            typically a theorem signature ending in ``:= by`` or a
            ``have <name> : <type> := ?_`` shape. May be partial; the
            outer agent fills in the proof.
        why_blocked: Plain-text rationale for why the parent target
            wasn't closed and how this sub-target unblocks it (e.g.
            "needs a measurability lemma we don't have", "needs the
            ENNReal arithmetic step factored out"). Surfaceable in
            the agent's loop messaging.
        suggested_drafters: Optional list of drafter aliases the
            ``race`` call on this sub-target should prioritize. None
            means "use the same drafter set as the parent target".
            Useful when one sub-target is autocomplete-friendly
            (Goedel) and another is chat-friendly (Sonnet).
    """
    sub_target_name: str
    sub_target_source: str
    why_blocked: str
    suggested_drafters: Optional[list[str]] = None


# ── RaceResult — return shape of `race` ──────────────────────────────


@dataclass(frozen=True)
class RaceResult:
    """Outcome of one :func:`race` call — fan-out across drafters.

    Attributes:
        target_id: ``CycleTarget.tid`` of the target raced.
        first_closer_alias: Drafter alias of the first one to close
            with ``compiles=True and not has_sorry and not banned``.
            None when no drafter closed.
        closing_candidate: The actual proof body the first-closer
            produced. None when no drafter closed.
        axiom_clean: Whether the closing candidate's axioms are a
            subset of ``{propext, Classical.choice, Quot.sound}``.
            None when no drafter closed.
        forbidden_axioms: List of non-allowlist axioms the closing
            candidate introduced. Empty when ``axiom_clean=True`` or
            when no drafter closed.
        outcomes_by_drafter: Per-drafter result, drafter alias →
            either a CycleResult-shape dict on success or
            ``{"error": "..."}`` on failure. Lets the agent loop
            inspect each drafter's behavior, not just the winner.
        wall_seconds: Wall-clock time of the longest drafter (the
            race's actual elapsed time, not sum-of-drafters).
        cost_usd: Aggregate API cost across all drafters. 0.0 when
            all drafters were local (Goedel-vLLM, llama-cpp).
    """
    target_id: str
    first_closer_alias: Optional[str]
    closing_candidate: Optional[str]
    axiom_clean: Optional[bool]
    forbidden_axioms: list[str] = field(default_factory=list)
    outcomes_by_drafter: dict[str, Any] = field(default_factory=dict)
    wall_seconds: float = 0.0
    cost_usd: float = 0.0

    @property
    def closed(self) -> bool:
        """True iff ``first_closer_alias`` is set (any drafter closed)."""
        return self.first_closer_alias is not None

    @property
    def closed_clean(self) -> bool:
        """True iff a drafter closed AND the closure is axiom-clean."""
        return self.closed and bool(self.axiom_clean)

    @property
    def proved(self) -> bool:
        """Customer-friendly alias for :attr:`closed_clean`.

        ATH-1040 (research dogfood pain point #6, 2026-05-05): customers
        reach for ``result.proved`` first — it matches the SolveResult
        and ProveResult fields. Aliased to ``closed_clean`` since
        "proved" only makes sense when the closure is axiom-clean.
        """
        return self.closed_clean


# ── SolveResult — return shape of `solve` ────────────────────────────


@dataclass(frozen=True)
class SolveResult:
    """Outcome of one :func:`solve` call — full decompose-and-conquer.

    Attributes:
        target_id: ``CycleTarget.tid`` of the target solved (or
            attempted).
        proved: True iff the target is closed and axiom-clean.
        closing_proof: The full Lean proof body that closed the
            target. None when not proved.
        path_taken: Which leg of the orchestration produced the
            result — one of ``"simple_prove"``, ``"race"``,
            ``"decompose"``, or ``"failed"``.
        race_result: The :class:`RaceResult` from the race leg, when
            taken. None when ``simple_prove`` closed it cheaply or
            when race wasn't reached.
        decompose_hints: When ``proved=False`` AND
            ``internal_planner_model=None``, this list tells the
            outer agent how to decompose the target. Empty when
            ``proved=True`` or when the planner ran internally.
        sub_solves: When ``internal_planner_model`` was provided AND
            decomposition was attempted, this is the per-sub-lemma
            recursive ``SolveResult`` list. Empty when decomposition
            was handed back to the outer agent.
        total_wall_seconds: Total wall-clock across all legs.
        total_cost_usd: Total API cost across all legs.
    """
    target_id: str
    proved: bool
    closing_proof: Optional[str]
    path_taken: str  # "simple_prove" | "race" | "decompose" | "failed"
    race_result: Optional[RaceResult] = None
    decompose_hints: list[DecomposeHint] = field(default_factory=list)
    sub_solves: list["SolveResult"] = field(default_factory=list)
    total_wall_seconds: float = 0.0
    total_cost_usd: float = 0.0


# ── Public API: race + solve ─────────────────────────────────────────


def race(
    target: Any,  # CycleTarget — typed loosely for forward-compat
    drafters: list[_DrafterProtocol],
    *,
    max_rounds: int = 4,
    temperature: float = 0.0,
    max_tokens: int = 800,
    preflight: bool = True,
    preflight_lake_project: Optional[str] = None,
    preflight_module_path: Optional[str] = None,
    axiom_audit: Optional[Any] = None,  # callable; default = default_axiom_audit
    organization_id: Optional[str] = None,
) -> RaceResult:
    """Fan out one target across multiple drafters in parallel; return
    the first-success or all-fail summary.

    This is the per-target race primitive. For multi-target sweeps,
    use :func:`kairos.sorry_swarm.sorry_swarm`.

    :purity: IMPURE_DETERMINISTIC (drafter LLM calls)
    :idempotence: NOT IDEMPOTENT (LLM sampling at temp > 0; drafter
        side effects)
    :side_effects: LLM calls per drafter; per-drafter scratch file
        writes via :func:`kairos.lean.verify_proof` (rolled back).

    :param target: The :class:`kairos.lean_cycle.CycleTarget` to race.
    :param drafters: Drafter handles; each must expose ``.alias: str``
        and ``.cycle_prove(target, **kwargs) -> CycleResult``.
    :param max_rounds: Per-drafter max refinement rounds (passed
        through to :func:`kairos.lean_cycle.cycle_prove`). Default 4.
    :param temperature: Sampling temperature for the first round.
        Default 0.0 (greedy).
    :param max_tokens: Max output tokens per drafter call. Default 800.
    :param preflight: When True, run a one-shot smoke per drafter
        before the actual race to catch deployment / credential / model
        mismatches early. Default True.
    :param preflight_lake_project: Required when ``preflight=True`` and
        any drafter expects to verify in lake-project mode (most pythia
        / cedar / customer targets).
    :param preflight_module_path: Required when ``preflight=True`` and
        any drafter expects lake-project mode.
    :param axiom_audit: Optional callable
        ``(CycleTarget, candidate_str) -> list[str]`` returning the
        list of non-allowlist axioms the candidate introduces. None
        means use :func:`kairos.sorry_swarm.default_axiom_audit`.
    :param organization_id: ATH-1236 — explicit customer org UUID stamped
        on the parent ``solve_runs`` row when ``race()`` auto-opens an
        ``observe()`` context (the direct-caller path; if the caller is
        already inside ``with observe()`` this kwarg is ignored because
        the parent row was already opened by the outer context). When
        set, forwarded to ``observe(organization_id=...)`` so the
        recorded row is tagged with the caller's customer org rather
        than falling through the env/license/sync-token waterfall to
        the host-VM ambient org. Customers running ``race()`` on their
        own infra should pass their own org UUID; ``None`` (default)
        preserves pre-ATH-1236 behavior (env/license/token waterfall).
        Mirror of the same kwarg on :func:`kairos.nki.run_bundle` and
        :func:`solve`; together they form the peer write-path
        propagation chain for customer-attribution.

    :returns: :class:`RaceResult` with ``first_closer_alias`` set when
        any drafter closed, plus per-drafter outcomes for
        introspection.

    :raises kairos.license_scope.LicenseScopeError: When the loaded
        license does not grant the ``"solve"`` product. Free-tier
        callers should use :func:`kairos.simple_prove` or
        :func:`kairos.simple_prove_template` instead.
    :raises ValueError: When two drafters share the same ``alias``
        (would silently clobber outcomes).

    Tier classification: paid (requires ``solve``).
    """
    # ATH-829: license gate at function entry. Mirrors `cycle_prove` /
    # `sorry_swarm` patterns. Fails fast before any drafter / network
    # / GPU resource is touched.
    from kairos.license_scope import require_product
    require_product("solve")

    # ATH-1040: when no observe() context is active, open one so direct
    # race() callers get full agent-arc events (agent_start +
    # lean_race_attempt + cycle_prove_attempt + verify_proof_attempt +
    # pipeline_complete) without manual observe() wrapping.
    # Customer-as-orchestrator pattern: customer decomposes, dispatches
    # one race per sub-lemma. Each direct race() call lands as its own
    # /solve-runs/[id] page.
    from kairos.observe import _CURRENT_CONTEXT, observe as _observe
    if _CURRENT_CONTEXT.get() is None:
        from kairos.trace import default_sink_from_env
        try:
            _wrapped_sink = default_sink_from_env()
        except Exception:  # noqa: BLE001 — best-effort sink resolution; fall through to None on any failure
            _wrapped_sink = None
        with _observe(
            spawn_reason="lean_orchestrate_race_direct",
            run_subtype="theorem_proving",
            sink=_wrapped_sink,
            organization_id=organization_id,  # ATH-1236
        ):
            # Recurse: now _CURRENT_CONTEXT is set so the body falls
            # through to the actual race work + emit.
            return race(
                target, drafters,
                max_rounds=max_rounds, temperature=temperature,
                max_tokens=max_tokens, preflight=preflight,
                preflight_lake_project=preflight_lake_project,
                preflight_module_path=preflight_module_path,
                axiom_audit=axiom_audit,
                organization_id=organization_id,
            )

    # Lazy import — keeps the module-level import graph compatible with
    # ATH-727's static-import-audit fence (this module is paid-tier;
    # the audit fence runs against `kairos.mcp` not `kairos.lean_orchestrate`).
    from kairos.fleet.fleet_orchestrator import FleetOrchestrator
    from kairos.sorry_swarm import default_axiom_audit
    from kairos.lean_cycle import CycleResult

    if axiom_audit is None:
        axiom_audit = default_axiom_audit()

    orchestrator = FleetOrchestrator(drafters=drafters)
    summary = orchestrator.run(
        target,
        max_rounds=max_rounds,
        temperature=temperature,
        max_tokens=max_tokens,
        preflight=preflight,
        preflight_lake_project=preflight_lake_project,
        preflight_module_path=preflight_module_path,
    )

    # Identify first-closer (the drafter alias whose CycleResult has
    # closed=True; ties broken by wall-clock fastest).
    first_closer_alias: Optional[str] = None
    closing_candidate: Optional[str] = None
    closer_total_cost = 0.0
    aggregate_cost = 0.0

    for alias, outcome in summary.outcomes.items():
        if isinstance(outcome, CycleResult) and outcome.closed:
            if first_closer_alias is None:
                first_closer_alias = alias
                if outcome.final_attempt is not None:
                    closing_candidate = outcome.final_attempt.candidate
        # Roll up costs from drafter response metadata where available.
        if isinstance(outcome, CycleResult):
            for r in outcome.rounds:
                meta = r.drafter_resp_meta or {}
                aggregate_cost += float(meta.get("cost_usd") or 0.0)

    # Axiom audit on the closing candidate.
    axiom_clean: Optional[bool] = None
    forbidden: list[str] = []
    if closing_candidate is not None:
        forbidden = list(axiom_audit(target, closing_candidate))
        axiom_clean = not forbidden

    race_result = RaceResult(
        target_id=getattr(target, "tid", "<unknown>"),
        first_closer_alias=first_closer_alias,
        closing_candidate=closing_candidate,
        axiom_clean=axiom_clean,
        forbidden_axioms=forbidden,
        outcomes_by_drafter=dict(summary.outcomes),
        wall_seconds=summary.wall_seconds,
        cost_usd=aggregate_cost,
    )

    # ATH-841 — default-on emit. Auto-bootstrap covers the bypass-
    # driver case; non-raising so race's return contract survives any
    # sink failure.
    try:
        from kairos.observe import emit as _emit
        _emit(
            "lean_race_attempt",
            {
                "target_id": race_result.target_id,
                "first_closer_alias": race_result.first_closer_alias,
                "closed": race_result.closed,
                "closed_clean": race_result.closed_clean,
                "axiom_clean": race_result.axiom_clean,
                "forbidden_axioms": race_result.forbidden_axioms,
                "n_drafters": len(race_result.outcomes_by_drafter),
                "wall_seconds": race_result.wall_seconds,
                "cost_usd": race_result.cost_usd,
            },
            run_subtype="theorem_proving",
        )
    except Exception:
        import logging as _logging
        _logging.getLogger(__name__).exception(
            "lean.race: ATH-841 emit failed — swallowing",
        )

    return race_result


def solve(
    target: Any,
    drafters: Optional[list[_DrafterProtocol]] = None,
    *,
    internal_planner_model: Optional[str] = None,
    try_simple_prove_first: bool = True,
    max_rounds: int = 4,
    n_per_drafter: int = 10,
    temperature: float = 0.7,
    max_tokens: int = 800,
    preflight: bool = True,
    preflight_lake_project: Optional[str] = None,
    preflight_module_path: Optional[str] = None,
    organization_id: Optional[str] = None,
) -> SolveResult:
    """ATH-841 wrapper around the real :func:`_solve_impl`. Calls the
    impl to get the SolveResult, then emits a `lean_solve_attempt`
    trace event so a bypass-driver call still produces traces.

    ATH-1040 (2026-05-05 research dogfood): when no `kairos.observe.observe()`
    context is active, this wrapper opens one internally so the canonical
    agent-arc events (agent_start + pipeline_complete) fire on direct
    callers — customers no longer need to know about observe() to get a
    full trace timeline on the dashboard. If a context IS already active
    (caller wrapped solve() in their own observe()), this wrapper is a
    pass-through; nesting would double-emit the bookends.

    See :func:`_solve_impl` for the parameter + return contract.

    :param organization_id: ATH-1236 — explicit customer org UUID stamped
        on the parent ``solve_runs`` row when ``solve()`` auto-opens an
        ``observe()`` context (the direct-caller path; see Nested-context
        behavior below). When set, forwarded to
        ``observe(organization_id=...)`` so the recorded row is tagged
        with the caller's customer org rather than falling through the
        env/license/sync-token waterfall to the host-VM ambient org.
        Customers running ``solve()`` on their own infra should pass
        their own org UUID; ``None`` (default) preserves pre-ATH-1236
        behavior (env/license/token waterfall). Mirror of the same
        kwarg on :func:`kairos.nki.run_bundle` and :func:`race`;
        together they form the peer write-path propagation chain for
        customer-attribution.

    Nested-context behavior (asabi 2026-05-14 cross-arm clarification):
        ``organization_id`` is honored ONLY on the direct-caller path
        (i.e. ``solve()`` opens its own ``observe()`` because the
        thread-local ``_CURRENT_CONTEXT`` is empty). When the caller is
        already inside a ``with observe(...)`` block, the parent
        ``solve_runs`` row was opened by the outer context using the
        outer context's ``organization_id`` — at that point the row
        already exists in the database and this wrapper does NOT amend
        or re-stamp it. Passing ``organization_id=X`` to ``solve()``
        from inside ``with observe(organization_id=Y):`` is silently
        ignored; the row is stamped with ``Y``. To override the org on
        a nested call, open a fresh ``observe()`` context with the
        desired org_id around the ``solve()`` invocation.
    """
    from kairos.observe import _CURRENT_CONTEXT, emit as _emit, observe

    def _do_solve_and_emit() -> SolveResult:
        result = _solve_impl(
            target,
            drafters,
            internal_planner_model=internal_planner_model,
            try_simple_prove_first=try_simple_prove_first,
            max_rounds=max_rounds,
            n_per_drafter=n_per_drafter,
            temperature=temperature,
            max_tokens=max_tokens,
            preflight=preflight,
            preflight_lake_project=preflight_lake_project,
            preflight_module_path=preflight_module_path,
        )
        try:
            _emit(
                "lean_solve_attempt",
                {
                    "target_id": result.target_id,
                    "proved": result.proved,
                    "path_taken": result.path_taken,
                    "n_decompose_hints": len(result.decompose_hints),
                    "n_sub_solves": len(result.sub_solves),
                    "internal_planner_model_set": (
                        internal_planner_model is not None
                    ),
                    "total_wall_seconds": result.total_wall_seconds,
                    "total_cost_usd": result.total_cost_usd,
                },
                run_subtype="theorem_proving",
            )
        except Exception:
            import logging as _logging
            _logging.getLogger(__name__).exception(
                "lean.solve: ATH-841 emit failed — swallowing",
            )
        # ATH-1040: surface the verdict on pipeline_complete.outcome via
        # the ATH-1038 mark_pipeline_outcome path. Direct caller gets an
        # honest pipeline_complete (proved → succeeded; otherwise the
        # path_taken text drives the outcome bucket).
        ctx = _CURRENT_CONTEXT.get()
        if ctx is not None:
            if result.proved:
                ctx.mark_pipeline_outcome("succeeded")
            else:
                ctx.mark_pipeline_outcome(
                    "errored" if result.path_taken == "failed" else "refuted",
                    reason=f"path_taken={result.path_taken}",
                )
        return result

    if _CURRENT_CONTEXT.get() is not None:
        # Caller already inside an observe() / session() context.
        # Single-emit: don't double-wrap.
        return _do_solve_and_emit()
    # No active context - open our own so agent_start + pipeline_complete
    # fire. spawn_reason names the SDK boundary the customer crossed so
    # the dashboard "why was this agent spawned" surface is honest.
    # Resolve sink from env (Supabase/JsonlTraceSink waterfall) so the
    # auto-wrapped session actually emits events; default-Noop on the
    # public observe() would silently drop them.
    from kairos.trace import default_sink_from_env
    try:
        _wrapped_sink = default_sink_from_env()
    except Exception:  # noqa: BLE001 — best-effort sink resolution; fall through to None on any failure
        _wrapped_sink = None
    with observe(
        spawn_reason="lean_orchestrate_solve_direct",
        run_subtype="theorem_proving",
        sink=_wrapped_sink,
        organization_id=organization_id,  # ATH-1236
    ):
        return _do_solve_and_emit()


def _solve_impl(
    target: Any,  # CycleTarget — typed loosely
    drafters: Optional[list[_DrafterProtocol]] = None,
    *,
    internal_planner_model: Optional[str] = None,
    try_simple_prove_first: bool = True,
    max_rounds: int = 4,
    n_per_drafter: int = 10,
    temperature: float = 0.7,
    max_tokens: int = 800,
    preflight: bool = True,
    preflight_lake_project: Optional[str] = None,
    preflight_module_path: Optional[str] = None,
) -> SolveResult:
    """Decompose-and-conquer Lean proof orchestrator.

    The customer-Opus default flow (``internal_planner_model=None``):

    1. (When ``try_simple_prove_first=True``)
       try :func:`kairos.simple_prove_template` with refinement —
       cheapest path, often closes scaffold-shaped lemmas in one
       pass. (NOTE: not yet wired in Phase 1; will land in a follow-up
       PR. Phase 1 ships the race + decompose-hints contract.)
    2. Race the supplied ``drafters`` via :func:`race`. First-success
       wins. Returns immediately on close.
    3. On all-drafter fail: emit structured ``decompose_hints`` so the
       outer agent (the customer's own Opus) can drive decomposition
       using its high-bandwidth context (file state, Mathlib hints,
       prior failures) WITHOUT spending an extra Opus call internally.

    The internal-planner flow (``internal_planner_model="anthropic/claude-opus-4-6"``):

    1+2. Same as above.
    3. Instead of returning hints, kairos calls the planner internally,
       receives a list of sub-lemma signatures, recursively calls
       ``solve`` on each, and assembles the result. ``sub_solves``
       captures the per-sub-target trajectory.

    :param target: The :class:`kairos.lean_cycle.CycleTarget` to solve.
    :param drafters: Drafters to race. When None, uses the internal
        Pythia-tuned default: Goedel-V2 + Gemini Flash + Sonnet, per
        :data:`kairos.model_presets.PRESET_INTERNAL_PYTHIA`.
    :param internal_planner_model: When set, kairos calls this model
        as the internal decomposition planner on race-fail. When None
        (default), structured ``decompose_hints`` go back to the
        outer agent. The agent-as-Opus default optimizes for the
        common case where the customer's outer Opus already has
        higher-bandwidth context than a fresh internal Opus call
        could rebuild.
    :param try_simple_prove_first: When True, attempt the cheap
        free-tier path before racing drafters. Default True. Set False
        to force a race (e.g. for benchmarking or when the caller
        already knows simple_prove won't close it).
    :param max_rounds: Passed to :func:`race` → :func:`cycle_prove`.
    :param n_per_drafter: Number of attempts per drafter in the race.
        (Currently a hint — :func:`race` runs one cycle per drafter;
        ``n_per_drafter`` is reserved for a future change that fans
        each drafter out to N parallel attempts via vLLM batching.)
    :param temperature: Sampling temperature. Default 0.7 (some
        diversity since multiple attempts).
    :param max_tokens: Max output tokens per drafter call.
    :param preflight: Run preflight check before race.
    :param preflight_lake_project: Required for lake-project verify mode.
    :param preflight_module_path: Required for lake-project verify mode.

    :returns: :class:`SolveResult`. ``proved=True`` when closed
        axiom-clean. ``proved=False`` with non-empty ``decompose_hints``
        when outer-agent decomposition is the next step.

    :raises kairos.license_scope.LicenseScopeError: When the loaded
        license does not grant the ``"solve"`` product.

    Tier classification: paid (requires ``solve``).
    """
    # ATH-829: license gate at function entry.
    from kairos.license_scope import require_product
    require_product("solve")

    import time
    t_start = time.time()

    # Resolve default drafters from the internal preset if caller
    # didn't supply any. Per kairos.model_presets contract: customers
    # ignore this preset and pass their own drafter list.
    if drafters is None:
        # Lazy import; preset is a tuple of model id strings, not
        # constructed drafters. The customer is responsible for
        # constructing drafters from these ids when they want the
        # preset; for an internal default we'd need a factory. For
        # Phase 1, require the caller to pass drafters explicitly when
        # they want a race.
        return SolveResult(
            target_id=getattr(target, "tid", "<unknown>"),
            proved=False,
            closing_proof=None,
            path_taken="failed",
            decompose_hints=[
                DecomposeHint(
                    sub_target_name="config_drafters_required",
                    sub_target_source="(no drafters supplied)",
                    why_blocked=(
                        "solve() called with drafters=None and no internal "
                        "default factory available in Phase 1. Pass an "
                        "explicit list of drafters constructed via "
                        "kairos.model_client.get_client(...) or use the "
                        "kairos.model_presets.PRESET_INTERNAL_PYTHIA "
                        "model-id list to build them."
                    ),
                ),
            ],
            total_wall_seconds=time.time() - t_start,
        )

    # Phase 1: simple_prove_template integration is a follow-up. For
    # now, skip directly to race when try_simple_prove_first=True is
    # set (we honor the flag in spirit by going straight to the cheaper
    # local-model leg of the race).
    # TODO(ATH-829 Phase 1.1): wire simple_prove_template here.

    # Race leg.
    race_result = race(
        target,
        drafters=drafters,
        max_rounds=max_rounds,
        temperature=temperature,
        max_tokens=max_tokens,
        preflight=preflight,
        preflight_lake_project=preflight_lake_project,
        preflight_module_path=preflight_module_path,
    )

    if race_result.closed_clean:
        return SolveResult(
            target_id=race_result.target_id,
            proved=True,
            closing_proof=race_result.closing_candidate,
            path_taken="race",
            race_result=race_result,
            total_wall_seconds=time.time() - t_start,
            total_cost_usd=race_result.cost_usd,
        )

    # Decompose leg.
    if internal_planner_model is None:
        # Default: hand back to outer agent.
        return SolveResult(
            target_id=race_result.target_id,
            proved=False,
            closing_proof=None,
            path_taken="decompose",
            race_result=race_result,
            decompose_hints=_default_decompose_hints(target, race_result),
            total_wall_seconds=time.time() - t_start,
            total_cost_usd=race_result.cost_usd,
        )

    # Internal-planner path (opt-in).
    sub_solves = _internal_decompose(
        target=target,
        race_result=race_result,
        planner_model=internal_planner_model,
        drafters=drafters,
        max_rounds=max_rounds,
        n_per_drafter=n_per_drafter,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    all_sub_proved = all(s.proved for s in sub_solves) if sub_solves else False

    # Phase 1.4: assemble + verify parent proof when all sub-lemmas
    # closed. The assembled proof is candidate-only — we verify it
    # atomically via kairos.lean.verify_proof before reporting proved=True.
    assembled_proof: Optional[str] = None
    parent_proved = False
    if all_sub_proved:
        assembled_proof = _assemble_parent_proof(target, sub_solves)
        if assembled_proof is not None:
            try:
                from kairos.lean import verify_proof
                # Build the full module text the way other call sites do.
                imports_block = "\n".join(
                    f"import {m}" for m in (getattr(target, "imports", []) or [])
                )
                opens_block = "\n".join(
                    f"open {o}" for o in (getattr(target, "opens", []) or [])
                )
                ns = getattr(target, "scratch_namespace", "Pythia.Scratch.Decomposed")
                header = getattr(target, "header", "")
                full_code = (
                    f"{imports_block}\n\n"
                    f"{opens_block}\n\n"
                    f"namespace {ns}\n\n"
                    f"{header} {assembled_proof}\n\n"
                    f"end {ns}\n"
                )
                lake_project = getattr(target, "lake_project", None)
                module_path = getattr(target, "module_path", None)
                if lake_project is not None and module_path is not None:
                    pr = verify_proof(
                        full_code,
                        lake_project=str(lake_project),
                        module_path=f"{module_path}_assembled",
                        timeout=getattr(target, "timeout_per_attempt", 180),
                    )
                    parent_proved = bool(
                        pr.compiles and not pr.has_sorry and not pr.banned
                    )
            except Exception:  # noqa: BLE001 — broad-catch fallback
                # Assembly verify failed — fall through with proved=False.
                # Caller can inspect sub_solves to retry assembly themselves.
                pass

    return SolveResult(
        target_id=race_result.target_id,
        proved=parent_proved,
        closing_proof=assembled_proof if parent_proved else None,
        path_taken="decompose",
        race_result=race_result,
        sub_solves=sub_solves,
        total_wall_seconds=time.time() - t_start,
        total_cost_usd=race_result.cost_usd + sum(s.total_cost_usd for s in sub_solves),
    )


# ── Helpers ──────────────────────────────────────────────────────────


def _default_decompose_hints(target: Any, race_result: RaceResult) -> list[DecomposeHint]:
    """Build a default ``decompose_hints`` list for outer-agent-driven
    decomposition. Phase 1 emits a single generic hint that points the
    agent at the parent target's signature + the race's per-drafter
    error tail. Future versions can mine common Mathlib gap patterns
    (missing instances, Lieb concavity, etc.) and emit specific hints.

    Per QA's risk call: this contract is what the customer agent's
    loop branches on, so keep it stable. Adding fields is fine; renaming
    or repurposing existing fields is a breaking change.
    """
    # Pull the most-actionable error tail from the race outcomes.
    error_summary_lines: list[str] = []
    for alias, outcome in (race_result.outcomes_by_drafter or {}).items():
        if isinstance(outcome, dict) and "error" in outcome:
            error_summary_lines.append(f"  {alias}: {str(outcome['error'])[:200]}")
        # CycleResult-shape outcomes — pull the last round's first error
        elif hasattr(outcome, "rounds") and outcome.rounds:
            last = outcome.rounds[-1]
            errs = getattr(last.proof_result, "errors", []) or []
            if errs:
                error_summary_lines.append(f"  {alias}: {str(errs[0])[:200]}")

    error_summary = "\n".join(error_summary_lines) or "(no per-drafter errors captured)"

    target_header = getattr(target, "header", "<unknown>")
    target_tid = getattr(target, "tid", "<unknown>")

    return [
        DecomposeHint(
            sub_target_name=f"{target_tid}__decompose",
            sub_target_source=(
                f"-- Parent target signature:\n{target_header}\n\n"
                f"-- Suggested decomposition: introduce one or more `have h_i : ... := ?_`\n"
                f"-- intermediate steps. The outer agent should:\n"
                f"--   1. Read the parent goal + all in-scope hypotheses\n"
                f"--   2. Identify 1-3 sub-lemmas that, when assumed, close the parent\n"
                f"--   3. Build a CycleTarget per sub-lemma and call solve() on each\n"
                f"--   4. Assemble closing tactics: `have h1 := <sub1>; have h2 := <sub2>; tac`\n"
            ),
            why_blocked=(
                "Race across all drafters did not produce an axiom-clean closure.\n"
                "Per-drafter error summary:\n" + error_summary
            ),
        ),
    ]


def _check_sublemma_signatures(
    target: Any,
    sublemmas: list,
    *,
    timeout: int = 60,
) -> list[str]:
    """Type-check each sublemma's ``type`` field as a ``:= by sorry`` stub.

    Returns a list aligned with ``sublemmas``: each entry is ``""`` when
    the sublemma's type parses + type-checks against the parent's lake
    project, or a short error string otherwise. Empty-string entries
    mean "ok"; non-empty mean "lake rejected this signature."

    Skips the check entirely (returns ``[""] * len(sublemmas)``) when:

    * The parent target has no ``lake_project`` set — bare-file lean
      can't resolve ``import Mathlib`` so a parse-only check would
      false-reject everything.
    * The ``kairos.lean.verify_proof`` import fails — defensive only.

    The cycle-engine refinement loop already enforces "until lake
    passes" for the actual proofs; this function is the equivalent
    enforcement at the decomposer layer (Aidan 2026-04-27: prompts
    can't enforce, only loops can — make sure decomposer can't emit
    decompositions whose sub-lemmas don't even type-check).

    :param target: parent ``CycleTarget`` (or any object with
        ``imports``, ``opens``, ``lake_project``, ``module_path``).
    :param sublemmas: list of dicts, each with ``name`` + ``type``
        keys (the planner's emitted decomposition).
    :param timeout: per-sublemma lake timeout in seconds.
    :returns: list of per-sublemma error strings (``""`` = ok).
    """
    parent_lake = getattr(target, "lake_project", None)
    if not parent_lake:
        # No lake project — skip the check (bare-file lean can't import
        # Mathlib). The drafter cycle still refinement-loops on actual
        # proofs, just not on the decomposer itself.
        return [""] * len(sublemmas)

    try:
        from kairos.lean import check_signature
    except Exception:  # noqa: BLE001 — guard returns empty container on any error
        return [""] * len(sublemmas)

    parent_imports = getattr(target, "imports", []) or []
    parent_opens = getattr(target, "opens", []) or []

    errors: list[str] = []
    for i, sub in enumerate(sublemmas):
        if not isinstance(sub, dict):
            errors.append(f"entry {i} is not a dict")
            continue
        name = str(sub.get("name") or f"h{i+1}")
        sub_type = sub.get("type")
        if not sub_type:
            errors.append(f"empty type field for {name}")
            continue

        result = check_signature(
            sub_type,
            imports=parent_imports,
            opens=parent_opens,
            lake_project=parent_lake,
            timeout=timeout,
        )
        if result.get("skipped"):
            errors.append("")  # treat skipped as ok
        elif result.get("ok"):
            errors.append("")
        else:
            err_msg = "; ".join(result.get("errors", [])[:3])[:500]
            errors.append(err_msg or "lake rejected stub (no error tail)")

    return errors


def _internal_decompose(
    target: Any,
    race_result: RaceResult,
    planner_model: str,
    drafters: list[_DrafterProtocol],
    max_rounds: int,
    n_per_drafter: int,
    temperature: float,
    max_tokens: int,
) -> list[SolveResult]:
    """Internal-planner decomposition path (opt-in via
    ``internal_planner_model``).

    Phase 1.4 implementation. Asks the planner model (typically Sonnet)
    to break the parent target into 1-3 sub-lemmas, builds a sub
    :class:`kairos.lean_cycle.CycleTarget` per lemma, recursively calls
    :func:`solve` on each (with the SAME drafters), and returns the
    per-sub-target :class:`SolveResult` list. The caller (``solve``)
    is responsible for assembling the parent proof from the closed
    sub-lemmas.

    Why Sonnet (and not Opus) is the typical planner choice:

    * Decomposition is reasoning-shaped (math intuition + Mathlib lemma
      knowledge) but doesn't need Opus-grade context. Sonnet 4.6 is the
      sweet spot.
    * Opus is reserved for the customer's OUTER agent — kairos's
      internal planner shouldn't compete with the customer's choice.
    * Sonnet is faster + cheaper than Opus per call, which matters when
      decomposition fans out (one decompose → N sub-solve recursions).

    Customers can override by passing ``internal_planner_model=
    "anthropic/claude-opus-4-7"`` if their use case demands deeper
    reasoning. Internal research-VM default sets the env var
    ``KAIROS_INTERNAL_PLANNER`` (typically ``"anthropic/claude-sonnet-4-6"``).

    :returns: list of :class:`SolveResult`, one per emitted sub-lemma.
        Empty when the planner emitted no parsable decomposition.
    """
    import json
    import re

    # Build the structured-decomposition prompt. The contract is
    # explicit JSON output — easier to parse than free-form Lean code,
    # and the planner can emit type signatures + rationale separately.
    target_header = getattr(target, "header", "")
    target_imports = getattr(target, "imports", []) or []
    target_opens = getattr(target, "opens", []) or []
    error_lines: list[str] = []
    if race_result is None:
        # Defensive: callers might pass None (e.g. when the parent target
        # is being decomposed before any race attempt). Return early so
        # we don't waste a planner call without context.
        return []
    for alias, outcome in (race_result.outcomes_by_drafter or {}).items():
        if isinstance(outcome, dict) and "error" in outcome:
            error_lines.append(f"{alias}: {str(outcome['error'])[:200]}")
        elif hasattr(outcome, "rounds") and outcome.rounds:
            last_round = outcome.rounds[-1]
            errs = getattr(last_round.proof_result, "errors", []) or []
            if errs:
                error_lines.append(f"{alias} (round {last_round.round}): {str(errs[0])[:200]}")
    error_summary = "\n".join(error_lines) or "(no per-drafter errors captured)"

    sys_msg = (
        "You are a Lean 4 proof decomposer for the kairos verification SDK "
        "running over Mathlib v4.28+. Your input is a theorem signature that "
        "the cheap-tier drafters failed to close. Propose 1-3 sub-lemmas that "
        "factor the parent into pieces closeable by the cheap tier, then a "
        "`combine` tactic that uses them to close the parent.\n\n"
        "WHO YOUR SUB-LEMMAS WILL BE TRIED BY:\n"
        "- Goedel-Prover-V2-8B Q6_K (local, batched, ~30 attempts/sub-lemma)\n"
        "- Gemini-3-flash (cloud, ~3 attempts)\n"
        "- Sonnet cycle-engine (only if both above fail; expensive)\n"
        "These models RELIABLY close: short algebraic identities, single-tactic\n"
        "Mathlib lookups (`exact mathlib_lemma`, `simp [lemma]`), `ring`, `linarith`,\n"
        "`omega`, `positivity`, `Finset.sum_*` rewrites, simple `norm_num`.\n"
        "These models DO NOT close: deep type-class instance constructions,\n"
        "long structured measure-theory arguments, manual integration-by-parts,\n"
        "anything needing more than ~5 tactic steps in the body.\n\n"
        "OUTPUT STRICT JSON ONLY. The FIRST non-whitespace character of your\n"
        "response MUST be `{`. ANY prose before the JSON (including 'Looking at\n"
        "this...', 'Let me think...', 'Wait, let me reconsider') voids your\n"
        "response and triggers the fallback path. Reason internally; output JSON.\n"
        "No markdown fences. No explanation. No multiple JSON blocks. Schema:\n"
        '{\n'
        '  "sublemmas": [\n'
        '    {"name": "h1", "type": "<Lean type expression>", "rationale": "<why cheap tier closes>"}\n'
        '  ],\n'
        '  "combine": "<Lean tactic line(s) that close the parent given h1..hN>"\n'
        "}\n\n"
        "WORKED EXAMPLE 1 (analytical inequality):\n"
        "  Parent: `theorem foo (x : ℝ) : x^2 + 2*x + 1 ≥ 0`\n"
        "  Decomposition:\n"
        '  {"sublemmas": [{"name": "sq_eq", "type": "∀ (x : ℝ), x^2 + 2*x + 1 = (x+1)^2",\n'
        '                  "rationale": "ring closes immediately"}],\n'
        '   "combine": "rw [sq_eq]; positivity"}\n\n'
        "WORKED EXAMPLE 2 (measure-theoretic glue):\n"
        "  Parent: `theorem bar (μ : Measure α) (h : μ Set.univ = 1) : IsProbabilityMeasure μ`\n"
        "  Decomposition:\n"
        '  {"sublemmas": [{"name": "univ_one", "type": "μ Set.univ = 1",\n'
        '                  "rationale": "matches hypothesis exactly via `exact h`"}],\n'
        '   "combine": "exact ⟨univ_one⟩"}\n\n'
        "WORKED EXAMPLE 3 (chain via two pieces):\n"
        "  Parent: `theorem baz (n : ℕ) : (∑ i in Finset.range n, (2:ℝ)*i) = n*(n-1)`\n"
        "  Decomposition:\n"
        '  {"sublemmas": [\n'
        '    {"name": "factor", "type": "∀ n : ℕ, (∑ i in Finset.range n, (2:ℝ)*i) = 2 * (∑ i in Finset.range n, (i:ℝ))",\n'
        '     "rationale": "Finset.mul_sum is a one-liner"},\n'
        '    {"name": "gauss", "type": "∀ n : ℕ, (∑ i in Finset.range n, (i:ℝ)) = n*(n-1)/2",\n'
        '     "rationale": "Finset.sum_range_id_mul_two — direct mathlib"}],\n'
        '   "combine": "rw [factor, gauss]; ring"}\n\n'
        "RULES:\n"
        "- Before emitting, MENTALLY TRY `simp`, `ring`, `norm_num`, `linarith`,\n"
        "  `omega`, `positivity`, `exact ?_` on each sub-lemma. If you can't see\n"
        "  a 1-3 line closure for it, do NOT include it.\n"
        "- The 'type' field is the Lean expression on the right of `:` "
        "  (no `theorem` prefix, no proof body, no quantifier-leading `∀` if the "
        "  parent already binds those variables — match the parent's binder shape).\n"
        "- The 'combine' tactic must be ≤3 lines. Prefer single-tactic forms:\n"
        "  `exact h1` / `simpa [h1] using h2` / `linarith [h1, h2]` / `rw [h1, h2]; ring`.\n"
        "- Prefer 1-2 sub-lemmas over 3. Each extra sub-lemma is another race the\n"
        "  cheap tier might lose.\n"
        "- ANTI-PATTERNS — DO NOT propose:\n"
        "  (a) a sub-lemma whose type is structurally the same as the parent's goal\n"
        "      (this is a rename, not a decomposition)\n"
        "  (b) a sub-lemma of form `P ↔ Q` where Q is the parent goal (vacuous)\n"
        "  (c) a sub-lemma that would need the parent to prove (circular)\n"
        "  (d) a sub-lemma whose proof obviously requires hand-crafted measure theory\n"
        "      or integration manipulations beyond cheap-tier reach\n"
        "- If you cannot find a tractable decomposition, output\n"
        "  `{\"sublemmas\": [], \"combine\": \"\"}` — the system will fall back to\n"
        "  agent-driven `decompose_hints`. An empty decomp is BETTER than a\n"
        "  fake one that wastes the cheap tier on intractable sub-lemmas."
    )
    user_msg = (
        "Parent theorem (failed to close in race):\n"
        f"```lean\n"
        + "\n".join(f"import {m}" for m in target_imports) + "\n"
        + "\n".join(f"open {o}" for o in target_opens) + "\n\n"
        f"{target_header} := by sorry\n"
        f"```\n\n"
        f"Per-drafter error tail from the race:\n{error_summary}\n\n"
        "Output the JSON decomposition."
    )

    # Refinement loop: planner call → parse → signature-check → retry on
    # bad signatures up to MAX_RETRIES total attempts. The signature check
    # type-checks each `sublemma.type` as a `:= by sorry` stub against the
    # parent's lake project; if any fail, the lake errors are fed back to
    # the planner and it re-emits. Without this loop, prompt-only guarding
    # leaks (Aidan caught 2026-04-27): the decomposer can emit Lean that
    # doesn't even parse and we'd silently waste the cheap tier on it.
    MAX_DECOMP_ATTEMPTS = 3

    try:
        from kairos.model_client import get_client
        client = get_client(planner_model)
    except Exception:  # noqa: BLE001 — guard returns empty container on any error
        return []

    sublemmas: list = []
    combine_tactic: str = "exact ?_"
    current_user_msg = user_msg

    for attempt in range(MAX_DECOMP_ATTEMPTS):
        try:
            resp = client.call(
                messages=client.format_messages(sys_msg, current_user_msg),
                temperature=0.0,
                max_tokens=2000,
            )
            text = (resp.content or "").strip()
        except Exception:  # noqa: BLE001 — guard returns empty container on any error
            return []

        # Strip markdown fences if the planner ignored the rules.
        fence_match = re.search(r"```(?:json)?\s*\n?(\{.*?\})\s*\n?```", text, re.DOTALL)
        if fence_match:
            text = fence_match.group(1)
        # Tolerate prose-then-JSON / revised-JSON leaks: enumerate every
        # balanced-brace block, prefer the LAST with sublemmas+combine.
        candidates: list[dict] = []
        depth = 0
        start = -1
        for i, ch in enumerate(text):
            if ch == '{':
                if depth == 0:
                    start = i
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0 and start >= 0:
                    blob = text[start:i+1]
                    try:
                        obj = json.loads(blob)
                    except json.JSONDecodeError:
                        obj = None
                    if isinstance(obj, dict):
                        candidates.append(obj)
                    start = -1
        parsed = None
        for c in reversed(candidates):
            if "sublemmas" in c and "combine" in c:
                parsed = c
                break
        if parsed is None and candidates:
            parsed = candidates[-1]
        if parsed is None:
            return []

        sublemmas = parsed.get("sublemmas") or []
        combine_tactic = parsed.get("combine") or "exact ?_"
        if not isinstance(sublemmas, list) or not sublemmas:
            # Planner explicitly opted out (or couldn't parse) — accept
            # and fall through to caller's fallback.
            return []

        # Signature-check each sublemma as a `:= by sorry` stub against
        # the parent's lake project. Skipped when no lake_project is
        # configured (bare-file mode can't resolve `import Mathlib`).
        sig_errors = _check_sublemma_signatures(target, sublemmas)
        if not any(sig_errors):
            break  # Clean decomposition — proceed to sub-target build.

        if attempt == MAX_DECOMP_ATTEMPTS - 1:
            # Out of retries — bail. Caller falls through to
            # agent-driven decompose_hints.
            return []

        # Build feedback for the planner: per-sublemma error tail.
        feedback_lines = []
        for i, err in enumerate(sig_errors):
            if err and i < len(sublemmas):
                name = sublemmas[i].get("name") if isinstance(sublemmas[i], dict) else f"h{i+1}"
                feedback_lines.append(f"- sublemma {name}: {err}")
        feedback = "\n".join(feedback_lines) or "(unknown signature errors)"
        current_user_msg = (
            user_msg
            + "\n\nYour previous decomposition had sub-lemmas whose types "
            "DID NOT TYPE-CHECK against the parent's `import` context. "
            "Fix the types and re-emit JSON. Errors:\n"
            + feedback
            + f"\n\n(Attempt {attempt + 2} of {MAX_DECOMP_ATTEMPTS}.)"
        )

    # Build sub-CycleTargets — each a fresh theorem with a unique tid +
    # module_path under the parent's scratch namespace.
    from kairos.lean_cycle import CycleTarget
    parent_tid = getattr(target, "tid", "target")
    parent_module = getattr(target, "module_path", "Pythia.Scratch.Decomposed")
    parent_scratch = getattr(target, "scratch_namespace", "Pythia.Scratch.Decomposed")
    parent_lake = getattr(target, "lake_project", None)

    sub_targets: list[Any] = []
    for i, sub in enumerate(sublemmas):
        if not isinstance(sub, dict):
            continue
        name = str(sub.get("name") or f"h{i+1}")
        sub_type = sub.get("type")
        if not sub_type:
            continue
        # Sanitize name to be a valid Lean identifier: alnum + underscore.
        safe_name = re.sub(r"[^A-Za-z0-9_]", "_", name)
        sub_header = f"theorem {parent_tid}_sub_{safe_name} : {sub_type}"
        sub_targets.append(CycleTarget(
            tid=f"{parent_tid}_sub_{safe_name}",
            imports=list(target_imports),
            opens=list(target_opens),
            header=sub_header,
            lake_project=parent_lake,
            module_path=f"{parent_module}_sub_{safe_name}",
            scratch_namespace=parent_scratch,
            timeout_per_attempt=getattr(target, "timeout_per_attempt", 180),
        ))

    if not sub_targets:
        return []

    # Recursively solve each sub-target. Sequential here — vLLM stays
    # warm across calls so per-sub-target latency is dominated by the
    # batched draft, not the model load. True cross-sub-target batching
    # (one vLLM call for all sub-prompts) is a Phase 1.5 optimization.
    sub_solves: list[SolveResult] = []
    for st in sub_targets:
        # Recurse with planner=None on the sub — once we're decomposed,
        # we expect each sub-lemma to be cheap-tier closeable. If a
        # sub-lemma also needs decomposition, the customer's outer
        # agent (or asabi-on-call) can take it from the returned hints.
        sr = solve(
            target=st,
            drafters=drafters,
            internal_planner_model=None,  # break the recursion at depth 1
            try_simple_prove_first=False,  # decomposed targets are race-shaped
            max_rounds=max_rounds,
            n_per_drafter=n_per_drafter,
            temperature=temperature,
            max_tokens=max_tokens,
            preflight=False,  # already preflighted at parent
        )
        sub_solves.append(sr)

    # Stash the combine tactic on the first sub_solve so the assembly
    # step can find it. (We could put it on every sub_solve, or add it
    # to a richer return shape — but for Phase 1.4 simplicity, attach
    # to sub_solves[0] via a side-channel field. Future shape: a
    # dedicated `Decomposition` dataclass alongside SolveResult.)
    if sub_solves:
        # Use the SolveResult's `closing_proof` slot on a SHADOW result
        # to carry the combine tactic. Actual assembly happens in solve().
        # Cleaner: attach to a list-of-attrs shape; for now, return the
        # tactic as the first sub_solve's `path_taken` suffix isn't
        # right — a proper field is needed. Let's stash on the first
        # sub_solve's _combine_tactic dynamic attribute via object.__setattr__
        # to bypass the frozen dataclass.
        try:
            object.__setattr__(sub_solves[0], "_combine_tactic", combine_tactic)
        except (AttributeError, TypeError):
            # Frozen dataclass may resist; fall through. Caller will
            # use a default combine tactic.
            pass

    return sub_solves


def _assemble_parent_proof(
    target: Any,
    sub_solves: list[SolveResult],
) -> Optional[str]:
    """Assemble the parent proof from closed sub-lemmas (Phase 1.4).

    Given the parent target + a list of solved sub-targets (each with
    a ``closing_proof`` body), build a ``by``-block that:

    1. Introduces each sub-lemma via ``have h_i : <type> := <closing_proof_i>``.
    2. Closes the parent via the combine tactic the planner emitted.

    Returns ``None`` when the assembly can't proceed (e.g. some
    sub-lemma didn't close, or the combine tactic wasn't captured).

    The returned string is a candidate proof body — the caller must
    verify it via ``kairos.lean.verify_proof`` before reporting success.
    """
    if not sub_solves or not all(s.proved for s in sub_solves):
        return None

    combine = getattr(sub_solves[0], "_combine_tactic", None) or "trivial"

    # Each sub_solve.target_id encodes the sub-lemma name suffix (after
    # `_sub_`). Use that to derive `have h_<name>` bindings.
    haves: list[str] = []
    for s in sub_solves:
        tid = s.target_id or ""
        # tid format: "<parent_tid>_sub_<name>"
        if "_sub_" in tid:
            sub_name = tid.rsplit("_sub_", 1)[-1]
        else:
            sub_name = f"h_{len(haves)}"
        # The sub_solve.closing_proof is the FULL theorem body the
        # drafter produced (including `:= by ...` or `:= <term>`).
        # Strip the leading `:=` and any leading `by ` so we can drop
        # it into a `have` binding.
        body = (s.closing_proof or "").strip()
        if body.startswith(":="):
            body = body[2:].lstrip()
        # Wrap in parens to be safe under `have ... := <expr>` scoping.
        haves.append(f"  have {sub_name} := ({body})")

    # combine tactic may be a single tactic line or multi-line;
    # normalize to indented block form.
    combine_lines = [f"  {ln}" for ln in combine.splitlines() if ln.strip()] or ["  trivial"]

    return ":= by\n" + "\n".join(haves) + "\n" + "\n".join(combine_lines) + "\n"


__all__ = [
    "DecomposeHint",
    "ModelClientDrafter",
    "RaceResult",
    "SolveResult",
    "race",
    "solve",
]
