"""Build-time metadata for license bypass control.

Customer wheels ship this file with DEV_TOKEN = None.
Internal dev/CI builds overwrite DEV_TOKEN via build_cython.py --dev.
"""
DEV_TOKEN: str | None = None
