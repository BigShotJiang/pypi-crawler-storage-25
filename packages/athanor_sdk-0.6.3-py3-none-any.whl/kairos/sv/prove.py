"""kairos.sv.prove — high-level `prove` convenience over run_ebmc.

Shape a customer wants is "give me a verdict, raise on failure":

    from kairos.sv import prove
    verdict = prove("telos_reno.sv", top_module="reno_cca", bound=100)
    # verdict.proved == total declared properties; verdict.refuted == 0.

prove() raises EbmcError on any REFUTED / UNKNOWN / timeout / nonzero
exit. Customers who want the raw EbmcResult without raising use
`run_ebmc` directly.

ATH-387 umbrella.

ATH-851: when called inside a kairos.session, prove() emits two trace
events to the active sink — `function_inputs` (with sv_source captured
+ digested via reduce_long_arg) before the EBMC run, and `ebmc_verdict`
(with proved/refuted counts, per-property verdicts, transcript +
counterexample previews) after. Both are silently no-op when no session
is active or the session's sink is a NoopTraceSink (zero-phone-home).

ATH-863 cleanup: the trace-emit + sv_source-digest helpers were
factored into :mod:`kairos.sv._trace_helpers` so the shape is shared
with `kairos.sv.cegar` (and the next sv-* helper to grow trace
coverage).
"""
from __future__ import annotations

from pathlib import Path

from kairos.observe import emit as _observe_emit
from kairos.sv.ebmc import EbmcResult, run_ebmc
from kairos.sv._trace_helpers import (
    emit_function_inputs_with_sv_source,
)

# Cap previews to keep sdk_agent_events row sizes bounded. EBMC transcripts
# can balloon to hundreds of KB when a refutation dumps a long counterexample;
# 4k is enough for the lead lines + property verdict block + first cycles of
# any cex, which is what an operator scanning /solve-runs/[id] cares about.
# *_first_4k convention: raw str slices, not reduce_long_arg digests —
# transcripts and counterexamples are output-side previews, not input-side
# inputs that benefit from a sha256 round-trip. See
# kairos.sv._trace_helpers module docstring for the input-vs-output rule.
_TRACE_PREVIEW_CAP = 16000


class EbmcError(RuntimeError):
    """Raised when `prove` can't certify the module.

    .result: the full EbmcResult for customers who want to inspect
    the counterexample or per-property verdicts.
    """

    def __init__(self, msg: str, result: EbmcResult):
        super().__init__(msg)
        self.result = result


def _emit_ebmc_verdict_to_active_session(payload: dict) -> None:
    """Emit one ``ebmc_verdict`` TraceEvent into the active session.

    Routed via :func:`kairos.observe.emit` with
    ``silent_if_no_session=True`` per ATH-971 Phase 4. Quiet-no-op
    when no session is active anywhere; preserves the privacy-fence.
    """
    _observe_emit("ebmc_verdict", payload, silent_if_no_session=True)


def _emit_function_inputs_for_prove(
    sv_path: Path,
    *,
    top_module: str,
    bound: int,
    mode: str,
    reset_expr: str | None,
    timeout_sec: int,
    extra_args: list[str] | None,
) -> None:
    """Capture prove() args + sv_source into a function_inputs event.

    Delegates to
    :func:`kairos.sv._trace_helpers.emit_function_inputs_with_sv_source`
    which handles the gate, the OSError-swallowing source read, and
    the SV-specific 50k preview cap. This wrapper just bundles the
    prove()-specific scalar args.
    """
    emit_function_inputs_with_sv_source(
        sv_path,
        function_name="kairos.sv.prove",
        args={
            "top_module": top_module,
            "bound": bound,
            "mode": mode,
            "reset_expr": reset_expr,
            "timeout_sec": timeout_sec,
            "extra_args": list(extra_args) if extra_args else None,
        },
    )


def prove(
    sv_file: "str | Path | list[str | Path]",
    *,
    top_module: str,
    bound: int = 10,
    mode: str = "bmc",
    reset_expr: str | None = None,
    timeout_sec: int = 60,
    extra_args: list[str] | None = None,
    filelist: "str | Path | None" = None,
    flatten: bool = False,
) -> EbmcResult:
    """Run EBMC and raise unless every declared property is PROVED.

    Args:
        sv_file: path(s) to SystemVerilog source files. Pass a single
            path or a list for multi-file packages.
        top_module: module name whose properties EBMC will try to prove.
        bound: k for bounded model checking.
        mode: ``"bmc"`` (default), ``"k_induction"`` (unbounded),
            ``"ic3"``, ``"bdd"``, ``"liveness"`` (liveness-to-safety),
            ``"liveness_buechi"``, or ``"liveness_ranking"``.
        reset_expr: reset signal expression (e.g., ``"reset"``,
            ``"rst"``). Defaults to None — EBMC considers every initial
            state. Set when verifying invariants that only hold from
            reset.
        timeout_sec: wall-clock timeout per EBMC invocation.
        extra_args: additional CLI flags passed to ebmc.
        filelist: path to an EBMC-style filelist (``-f``).
        flatten: when True, preprocess sources through
            :func:`kairos.sv.flatten.flatten_files` to replace packed
            structs with bit-vectors before passing to EBMC.

    The ebmc binary is auto-discovered via `shutil.which("ebmc")`;
    fallback runs against the pinned hw-cbmc:latest Docker image when
    ebmc isn't on PATH. Override the image with env var
    `EBMC_DOCKER_IMAGE`.

    Returns:
        EbmcResult with all properties PROVED, no REFUTED / UNKNOWN.

    Raises:
        EbmcError: on any REFUTED, UNKNOWN verdict, timeout, or nonzero
        exit code. The EbmcResult is attached as .result for inspection.
    """
    from kairos.license_scope import require_product
    require_product("solve")

    # ATH-851: capture inputs (with sv_source digested) before we hand
    # off to EBMC so /solve-runs/[id] shows what `prove` was given even
    # if the run dies on a missing-file / parse / timeout path. No-op
    # outside a kairos.session.
    if isinstance(sv_file, (str, Path)):
        sv_path = Path(sv_file).resolve()
    else:
        sv_path = Path(sv_file[0]).resolve() if sv_file else Path(".")
    _emit_function_inputs_for_prove(
        sv_path,
        top_module=top_module,
        bound=bound,
        mode=mode,
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
    )

    r = run_ebmc(
        sv_file,
        top_module=top_module,
        bound=bound,
        mode=mode,
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
        filelist=filelist,
        flatten=flatten,
    )

    # ATH-851: emit the verdict regardless of which raise-branch we'll
    # take below. EbmcError swallows nothing — but the trace event is
    # what /solve-runs/[id] renders, and a timeout/REFUTED is exactly
    # the case where the operator most needs the per-property verdict
    # map + counterexample preview to triage.
    cex = None
    try:
        cex = r.counterexample
    except Exception:  # pragma: no cover — defensive against parse drift  # noqa: BLE001 — broad-catch fallback
        cex = None
    _emit_ebmc_verdict_to_active_session({
        "function": "kairos.sv.prove",
        "top_module": top_module,
        "bound": bound,
        "mode": mode,
        "exit_code": r.exit_code,
        "elapsed_sec": r.elapsed_sec,
        "timed_out": r.timed_out,
        "proved": r.proved,
        "refuted": r.refuted,
        "property_verdicts": dict(r.property_verdicts or {}),
        "transcript_first_4k": (r.stdout or "")[:_TRACE_PREVIEW_CAP],
        "stderr_first_4k": (r.stderr or "")[:_TRACE_PREVIEW_CAP],
        "counterexample_first_4k": (cex[:_TRACE_PREVIEW_CAP] if cex else None),
    })

    if r.timed_out:
        raise EbmcError(f"ebmc timed out after {timeout_sec}s", r)
    if r.exit_code != 0 and r.refuted == 0 and r.proved == 0:
        raise EbmcError(
            f"ebmc exited {r.exit_code} with no verdicts parsed",
            r,
        )
    if r.refuted:
        covers = r.cover_properties or set()
        refuted_names = [
            n for n, v in (r.property_verdicts or {}).items()
            if v.upper() in ("REFUTED", "FAILED") and n not in covers
        ]
        if refuted_names:
            raise EbmcError(
                f"{len(refuted_names)} property/ies REFUTED: {refuted_names}",
                r,
            )
    unknown = {
        n: v for n, v in (r.property_verdicts or {}).items()
        if v.upper() == "UNKNOWN"
    }
    if unknown:
        raise EbmcError(f"{len(unknown)} property/ies UNKNOWN: {unknown}", r)
    if r.proved == 0:
        raise EbmcError(
            "ebmc reported no PROVED properties — is the module declaring any?",
            r,
        )
    return r
