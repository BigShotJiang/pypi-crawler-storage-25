"""kairos.sv.cegar — Python API for the CEGAR loop (ATH-401).

CEGAR = counterexample-guided abstraction refinement: EBMC refutes a
spec property → an LLM proposer drafts candidate `assume property(...)`
hypotheses that would close the refutation → deterministic vacuity
gate drops trivializing candidates → user (or callable, or
`--auto-accept-environmental`) accepts/rejects → loop until proved
or cap hit.

Mode B (customer-port) companion to `prove()` (single-shot EBMC
verification). See DESIGN notes at
`athanor-builder/solve/sysverilog/cegar/DESIGN.md`.

## Shape

    from kairos.sv import cegar, CegarError

    result = cegar(
        "weakened_spec.sv",
        top_module="reno_cca",
        bound=10,
        max_iter=5,
        budget_usd=5.0,
        walltime_sec=600,
        auto_accept_environmental=False,
        clk="clk",
    )
    # result.terminated_reason: Literal[...]
    # result.iterations: int
    # result.total_cost_usd: float
    # result.total_elapsed_sec: float
    # result.final_spec_path: str
    # result.final_spec: str
    # result.iter_artifacts: list[IterArtifact]

## Interaction modes

1. `auto_accept_environmental=False` (default), `user_decision=None`:
   the loop blocks on stdin for accept/reject. Same as the CLI
   interactive path.

2. `auto_accept_environmental=True`: non-interactive; accept every
   environmental-class candidate, reject the rest. CI-safe.

3. `user_decision=callable`: reserved for a future two-way IPC
   protocol. Not implemented in MVP; raises NotImplementedError.

## Subprocess boundary

`cegar()` subprocess-shells to `$ATHANOR_BUILDER_ROOT/solve/sysverilog/
cegar.sh` (the same wrapper the CLI dispatches to, ATH-398). Stdin
is inherited by default so interactive mode works without extra
wiring; callers who need to redirect must do so at the Python level
before calling `cegar()`.

## Failure semantics

The subprocess exit code maps to `CegarResult.terminated_reason`:

    0 -> "all_proved"       # success — every property PROVED
    1 -> "cap"              # max_iter / budget / walltime cap hit
    2 -> "validation"       # usually raises on the caller's side
                            # before subprocess fires
    3 -> "genuine_bug"      # classifier said "real RTL bug" —
                            # customer should triage, not accept
    4 -> "user_stop"        # user pressed Ctrl-C / typed "stop"
    other -> CegarError     # unexpected; raised

`CegarError` subclasses `RuntimeError` and carries `.result` for
post-hoc inspection (mirrors `EbmcError` in prove.py).

## What this module does NOT do

- Re-parse EBMC counterexamples itself (cegar.sh's `loop.py` owns
  that, per ATH-383 IP layering).
- Maintain state across calls. Each `cegar()` invocation is one
  loop; customer drives restarts.
- Implement the `user_decision=callable` protocol (MVP scope).

See ATH-398 (CLI), ATH-399 (max_tokens hardening), ATH-405
(eventual no-external-builder bundling).
"""
from __future__ import annotations

import json
import os

from kairos.envvars import getenv_dual
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Literal

from kairos.observe import emit as _observe_emit
from kairos.sv._trace_helpers import (
    emit_function_inputs_with_sv_source,
)


def _emit_active(event_type: str, payload: dict) -> None:
    """ATH-971 Phase 4 local helper: thin wrapper over
    ``kairos.observe.emit(silent_if_no_session=True)`` to keep the
    per-call sites tidy. Same shape as the deleted
    ``kairos.sv._trace_helpers.emit_to_active_session`` shim.
    """
    _observe_emit(event_type, payload, silent_if_no_session=True)


TerminatedReason = Literal[
    "all_proved", "cap", "genuine_bug", "user_stop",
    "probe_crashed", "unexpected",
]

# Exit-code → terminated_reason. 2 is a validation error on the
# subprocess side; we prefer to raise the ValueError ourselves before
# shelling out, so a 2 back from the subprocess is a surprise — mapped
# to "unexpected" below.
#
# ATH-862: 5 = probe_crashed. The vacuity progress-probe shells out
# its own EBMC invocation; when that EBMC instance SIGABRTs (e.g.,
# the cbmc/util/std_expr.h:2463 invariant violation seen 2026-04-28
# on a `counter < 16` probe), the loop driver halts rather than
# spinning to max_iter on the same broken probe shape. Customers
# seeing `probe_crashed` should file an EBMC bug + try a different
# spec shape, not bump --max-iter.
_EXIT_REASON: dict[int, TerminatedReason] = {
    0: "all_proved",
    1: "cap",
    3: "genuine_bug",
    4: "user_stop",
    5: "probe_crashed",
}


class CegarError(RuntimeError):
    """Raised when cegar.sh exits with an unexpected code.

    Mirrors `EbmcError` from prove.py. The partially-populated
    `CegarResult` is attached as `.result` for inspection.
    """

    def __init__(self, msg: str, result: "CegarResult"):
        super().__init__(msg)
        self.result = result


@dataclass(frozen=True)
class IterArtifact:
    """Per-iteration artifacts written by cegar.sh.

    Paths are absolute. Missing files are represented by paths that
    may not exist; `candidate_json` / `decision_json` are `None` on
    iterations where the proposer never reached that stage (e.g.
    max_iter hit during the EBMC call).
    """
    iter_dir: Path
    spec_path: Path
    ebmc_stdout: Path | None
    ebmc_stderr: Path | None
    candidate_json: Path | None
    decision_json: Path | None


@dataclass(frozen=True)
class CegarResult:
    """Structured outcome of one `cegar()` invocation."""
    terminated_reason: TerminatedReason
    iterations: int
    total_cost_usd: float
    total_elapsed_sec: float
    final_spec_path: str
    final_spec: str
    iter_artifacts: list[IterArtifact] = field(default_factory=list)
    # Raw JSON summary from cegar.sh's stdout (whatever fields beyond
    # the canonical set above; forward-compat for schema growth).
    raw_summary: dict = field(default_factory=dict)


def _resolve_cegar_sh() -> Path:
    """Find cegar.sh the same way cmd_cegar does."""
    builder_root = getenv_dual("BUILDER_ROOT", "/opt/athanor/builder")
    cegar_sh = Path(builder_root) / "solve" / "sysverilog" / "cegar.sh"
    if not cegar_sh.is_file():
        raise FileNotFoundError(
            f"cegar.sh not found at {cegar_sh}. "
            f"Set $ATHANOR_BUILDER_ROOT to your athanor-builder install root."
        )
    return cegar_sh


# ATH-863: per-iteration trace event payload size cap. EBMC transcripts
# can balloon to hundreds of KB when refutations dump long counterexamples;
# 4k is enough for the lead lines + property verdict block + first cycles
# of any cex, which is what an operator scanning /solve-runs/[id] cares
# about. Same convention as kairos.sv.prove (ATH-851): *_first_4k fields
# are raw str slices, not reduce_long_arg digests — output-side previews
# don't benefit from a sha256 round-trip the way input-side sv_source
# does. See kairos.sv._trace_helpers module docstring.
_TRACE_PREVIEW_CAP = 16000


def _emit_function_inputs_for_cegar(
    sv_path: Path,
    *,
    top_module: str,
    bound: int,
    mode_label: str,
    max_iter: int,
    budget_usd: float,
    walltime_sec: int,
    auto_accept_environmental: bool,
    clk: str,
) -> None:
    """Capture cegar() args + sv_source into a function_inputs event.

    Delegates to
    :func:`kairos.sv._trace_helpers.emit_function_inputs_with_sv_source`
    which handles the gate, the OSError-swallowing source read, and
    the SV-specific 50k preview cap. This wrapper just bundles the
    cegar()-specific scalar args.
    """
    emit_function_inputs_with_sv_source(
        sv_path,
        function_name="kairos.sv.cegar",
        args={
            "top_module": top_module,
            "bound": bound,
            "mode": mode_label,
            "max_iter": max_iter,
            "budget_usd": budget_usd,
            "walltime_sec": walltime_sec,
            "auto_accept_environmental": auto_accept_environmental,
            "clk": clk,
        },
    )


def _emit_per_iteration_summaries(
    workdir: Path,
    artifacts: list[IterArtifact],
) -> None:
    """Emit one cegar_iteration_summary event per iteration.

    Reads the loop driver's ``cegar_run.json`` summary (written by
    :func:`sysverilog.cegar.loop._persist_records`) for the structured
    per-iter record, plus each iter dir's ``ebmc.stdout`` and
    ``candidate.json`` for transcript / hypothesis previews. Loud
    failure on a missing ``cegar_run.json`` is unhelpful — the loop
    may have crashed before persisting; emit best-effort from the
    iter_artifacts alone in that case.

    **Payload nullability** (qa #326 review note): every field in the
    emitted payload except ``iteration`` and ``ebmc_transcript_first_4k``
    can be ``None``. The iteration number is always present (it's
    parsed from the iter_NN dir name); the transcript is normalized to
    ``None`` when empty; everything else uses ``record.get(...)`` /
    ``candidate.get(...)`` and falls through to ``None`` whenever the
    on-disk JSON predates the field, the loop crashed mid-iteration,
    or the proposer never reached the candidate-emit stage. Downstream
    consumers (platform renderers, replay tools) MUST handle ``None``
    for every field except ``iteration`` and ``event_type``.
    """
    # ATH-971 Phase 3: gate via the canonical session detector
    # instead of reading kairos.trace.CURRENT_SESSION directly. Skips
    # file IO + downstream emits when no session is active. The
    # actual emit calls below already use emit_to_active_session
    # (the ATH-969 transitional shim) so they route through
    # kairos.observe.emit transparently.
    import sys as _sys
    _observe_mod = _sys.modules.get("kairos.observe")
    if _observe_mod is None:  # pragma: no cover
        from kairos import observe as _observe_mod  # type: ignore[no-redef]
    if _observe_mod.active_session_context() is None:
        return

    summary_path = workdir / "cegar_run.json"
    iter_records: list[dict] = []
    if summary_path.is_file():
        try:
            iter_records = json.loads(summary_path.read_text()).get("iterations", [])
        except (OSError, ValueError):
            iter_records = []

    # Index records by iteration number for cheap lookup against artifacts.
    by_iter = {int(r.get("iteration", 0)): r for r in iter_records}

    for art in artifacts:
        # iter_NN → 0-pad-stripped int.
        try:
            iter_num = int(art.iter_dir.name.removeprefix("iter_"))
        except ValueError:
            continue
        record = by_iter.get(iter_num, {})
        candidate: dict = {}
        if art.candidate_json is not None:
            try:
                candidate = json.loads(art.candidate_json.read_text())
            except (OSError, ValueError):
                candidate = {}
        ebmc_transcript = ""
        if art.ebmc_stdout is not None:
            try:
                ebmc_transcript = art.ebmc_stdout.read_text()[:_TRACE_PREVIEW_CAP]
            except OSError:
                pass

        _emit_active("cegar_iteration_summary", {
            "iteration": iter_num,
            "user_decision": record.get("user_decision"),
            "vacuity_reason": record.get("vacuity_reason"),
            "ebmc_proved": record.get("ebmc_proved"),
            "ebmc_refuted": record.get("ebmc_refuted"),
            "ebmc_timed_out": record.get("ebmc_timed_out"),
            "ebmc_engine": record.get("ebmc_engine"),
            "ebmc_bound": record.get("ebmc_bound"),
            "elapsed_sec": record.get("elapsed_sec"),
            "cost_usd": record.get("cost_usd"),
            "candidate_classification": (
                record.get("candidate_classification") or candidate.get("classification")
            ),
            "candidate_hypothesis_sv": candidate.get("hypothesis_sv"),
            "candidate_rationale": candidate.get("rationale"),
            "candidate_target_property": candidate.get("target_property"),
            "candidate_confidence": candidate.get("confidence"),
            "ebmc_transcript_first_4k": ebmc_transcript or None,
        })


def _emit_accepted_invariants(workdir: Path) -> None:
    """Emit one cegar_invariant_accepted event per accepted hypothesis (ATH-908).

    Reads accepted_invariants.json written by loop.py's
    _persist_accepted_invariant. Each entry becomes a trace event
    that qa's kairos.acl2.import_ebmc_invariant can consume.
    """
    inv_file = workdir / "accepted_invariants.json"
    if not inv_file.is_file():
        return
    try:
        invariants = json.loads(inv_file.read_text())
    except (OSError, ValueError):
        return
    for inv in invariants:
        _emit_active("cegar_invariant_accepted", inv)


def _collect_iter_artifacts(workdir: Path) -> list[IterArtifact]:
    """Enumerate iter_NN/* subdirs left behind by cegar.sh."""
    artifacts: list[IterArtifact] = []
    if not workdir.is_dir():
        return artifacts
    for d in sorted(workdir.iterdir()):
        if not d.is_dir() or not d.name.startswith("iter_"):
            continue
        def _opt(name: str) -> Path | None:
            p = d / name
            return p if p.is_file() else None
        artifacts.append(IterArtifact(
            iter_dir=d,
            spec_path=d / "spec.sv",
            ebmc_stdout=_opt("ebmc.stdout"),
            ebmc_stderr=_opt("ebmc.stderr"),
            candidate_json=_opt("candidate.json"),
            decision_json=_opt("decision.json"),
        ))
    return artifacts


def cegar(
    spec: str | Path,
    *,
    top_module: str,
    bound: int = 10,
    max_iter: int = 5,
    budget_usd: float = 5.0,
    walltime_sec: int = 600,
    workdir: str | Path | None = None,
    auto_accept_environmental: bool = False,
    user_decision: Callable | None = None,
    clk: str = "clk",
    extra_files: "list[str | Path] | None" = None,
    extra_args: list[str] | None = None,
    flatten: bool = False,
) -> CegarResult:
    """Run the CEGAR loop against a SystemVerilog spec.

    Args:
        spec: path to the SV spec file. Resolved to an absolute path
            before dispatch so relative paths work from the caller's
            cwd (cegar.sh runs with cwd=builder_root).
        top_module: module whose properties EBMC tries to prove.
        bound: BMC bound k for each EBMC call.
        max_iter: maximum CEGAR iterations before giving up.
        budget_usd: LLM cost cap.
        walltime_sec: wall-clock cap for the whole loop.
        workdir: artifact directory (default: tempdir under $TMPDIR).
        auto_accept_environmental: if True, non-interactively accept
            every environmental-class candidate. Use this in CI.
        user_decision: reserved for future two-way IPC. Raises
            NotImplementedError in MVP.
        clk: clock signal name.
        extra_files: additional SV source files passed to EBMC alongside
            the spec. Required for multi-file designs where modules are
            defined across separate files (e.g. packages, RTL modules).
        extra_args: additional CLI flags passed through to EBMC via
            cegar.sh's ``--ebmc-extra-args`` (e.g. ``["+define+FOO"]``).
        flatten: when True, preprocess all source files through
            :func:`kairos.sv.flatten.flatten_files` before dispatch.

    Returns:
        CegarResult — always populated, even on cap / user_stop.

    Raises:
        FileNotFoundError: spec file missing or cegar.sh missing.
        NotImplementedError: `user_decision` is not None.
        CegarError: cegar.sh exited with an unexpected code (not
            0, 1, 3, or 4).
    """
    # ATH-686 P1: programmatic CEGAR entry → license gate. The CLI
    # `athanor cegar` already gates at cli.py:1156; this closes the
    # `from kairos.sv import cegar; cegar(...)` import-bypass.
    from kairos.license_scope import require_product
    require_product("solve")

    if user_decision is not None:
        raise NotImplementedError(
            "user_decision=callable is reserved for a future "
            "two-way IPC protocol. Use auto_accept_environmental=True "
            "for CI or leave user_decision=None for interactive stdin."
        )

    spec_path = Path(spec).resolve()
    if not spec_path.is_file():
        raise FileNotFoundError(f"spec file not found: {spec_path}")

    extra_paths = [Path(f).resolve() for f in (extra_files or [])]

    if flatten:
        import tempfile as _tf
        from kairos.sv.flatten import flatten_files as _flatten_files
        all_files = [spec_path] + extra_paths
        flat_dir = Path(_tf.mkdtemp(prefix="kairos_cegar_flat_"))
        _flatten_files(all_files, output_dir=flat_dir)
        spec_path = flat_dir / spec_path.name
        extra_paths = [flat_dir / p.name for p in extra_paths]

    _emit_function_inputs_for_cegar(
        spec_path,
        top_module=top_module,
        bound=bound,
        mode_label="cegar_loop",
        max_iter=max_iter,
        budget_usd=budget_usd,
        walltime_sec=walltime_sec,
        auto_accept_environmental=auto_accept_environmental,
        clk=clk,
    )

    cegar_sh = _resolve_cegar_sh()
    builder_root = cegar_sh.parent.parent.parent

    if workdir is None:
        import tempfile
        workdir_path = Path(tempfile.mkdtemp(prefix="cegar-"))
    else:
        workdir_path = Path(workdir).resolve()
        workdir_path.mkdir(parents=True, exist_ok=True)

    cmd: list[str] = [
        str(cegar_sh),
        "--spec", str(spec_path),
        "--top", top_module,
        "--bound", str(bound),
        "--max-iter", str(max_iter),
        "--budget-usd", str(budget_usd),
        "--walltime-sec", str(walltime_sec),
        "--workdir", str(workdir_path),
        "--clk", clk,
    ]
    if auto_accept_environmental:
        cmd.append("--auto-accept-environmental")
    for ef in extra_paths:
        cmd += ["--extra-file", str(ef)]
    if extra_args:
        cmd += ["--ebmc-extra-args"] + list(extra_args)

    # Explicitly propagate the full environment so ANTHROPIC_API_KEY,
    # ANTHROPIC_BASE_URL, and other model routing vars reach the LLM
    # proposer inside cegar.sh.
    env = os.environ.copy()

    proc = subprocess.run(
        cmd,
        cwd=str(builder_root),
        stdout=subprocess.PIPE,
        stderr=None,
        text=True,
        env=env,
    )

    summary: dict = {}
    # cegar.sh emits a JSON block as its final stdout. Older invocations
    # may have preceded it with log lines; grab the last JSON object.
    stdout = proc.stdout or ""
    _echoed = _extract_last_json_block(stdout)
    # Mirror everything to caller's stdout so callers aren't silenced.
    if stdout:
        sys.stdout.write(stdout)
        sys.stdout.flush()
    if _echoed is not None:
        summary = _echoed

    iter_artifacts = _collect_iter_artifacts(workdir_path)

    # Final spec content — cegar.sh writes final_spec.sv at workdir
    # root (per athanor-builder PR #82's cegar.sh contract).
    final_spec_path = summary.get("final_spec_path") or str(workdir_path / "final_spec.sv")
    final_spec = ""
    try:
        final_spec = Path(final_spec_path).read_text()
    except OSError:
        pass

    terminated_reason: TerminatedReason = _EXIT_REASON.get(
        proc.returncode, "unexpected",
    )
    result = CegarResult(
        terminated_reason=terminated_reason,
        iterations=int(summary.get("iterations", len(iter_artifacts))),
        total_cost_usd=float(summary.get("total_cost_usd", 0.0)),
        total_elapsed_sec=float(summary.get("total_elapsed_sec", 0.0)),
        final_spec_path=str(final_spec_path),
        final_spec=final_spec,
        iter_artifacts=iter_artifacts,
        raw_summary=summary,
    )

    # ATH-863: per-iteration summaries + terminal verdict. Fires
    # regardless of which raise-branch the caller takes below — the
    # operator most needs the iteration trail when terminated_reason
    # is "unexpected" / "probe_crashed" / "cap" (the failure cases).
    _emit_per_iteration_summaries(workdir_path, iter_artifacts)
    _emit_accepted_invariants(workdir_path)
    _emit_active("cegar_terminated", {
        "function": "kairos.sv.cegar",
        "top_module": top_module,
        "bound": bound,
        "max_iter": max_iter,
        "terminated_reason": terminated_reason,
        "exit_code": proc.returncode,
        "iterations": result.iterations,
        "total_cost_usd": result.total_cost_usd,
        "total_elapsed_sec": result.total_elapsed_sec,
        "final_spec_path": result.final_spec_path,
        "final_spec_first_4k": (final_spec or "")[:_TRACE_PREVIEW_CAP],
    })

    if terminated_reason == "unexpected":
        raise CegarError(
            f"cegar.sh exited with unexpected code {proc.returncode}. "
            f"Expected one of 0/1/3/4. Check the subprocess stderr for details.",
            result,
        )
    return result


def _extract_last_json_block(text: str) -> dict | None:
    """Pull the last top-level JSON object from a stdout stream.

    cegar.sh emits a summary like:

        [cegar] ...log lines...
        {
          "success": true,
          "terminated_reason": "all_proved",
          ...
        }

    We want the last JSON object. Simplest reliable approach: scan
    backwards for an object delimited by balanced braces.
    """
    # Find the last '}' then walk back to a matching '{' at depth 0.
    end = text.rfind("}")
    if end < 0:
        return None
    depth = 0
    start = -1
    for i in range(end, -1, -1):
        c = text[i]
        if c == "}":
            depth += 1
        elif c == "{":
            depth -= 1
            if depth == 0:
                start = i
                break
    if start < 0:
        return None
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None


__all__ = [
    "cegar",
    "CegarError",
    "CegarResult",
    "IterArtifact",
    "TerminatedReason",
]
