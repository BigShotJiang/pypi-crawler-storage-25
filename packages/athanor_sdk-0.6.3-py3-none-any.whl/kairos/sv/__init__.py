"""kairos.sv — SystemVerilog vertical for the hw-ebmc flagship customer.

Public surface, stable:

  run_ebmc(sv_file, top_module, bound, ...) -> EbmcResult
    Thin wrapper around the `ebmc` CLI. Parses PROVED/REFUTED counts
    and per-property verdicts.

  prove(sv_file, top_module, bound) -> EbmcResult
    Higher-level convenience that asserts the run succeeded and every
    declared property was PROVED. Raises EbmcError on any REFUTED or
    UNKNOWN verdict.

  cegar(spec, top_module, bound, ...) -> CegarResult  (ATH-401)
    CEGAR loop — spec-layer hypothesis strengthening. On EBMC
    refutation, an LLM proposes candidate `assume property(...)`
    hypotheses that, vacuity-gated, close the refutation. Mode B
    customer-port companion to prove(). Requires athanor-builder.

  EbmcResult / CegarResult
    Structured outcomes.

This module targets the hw-ebmc-flagship customer (someone driving
a whole fleet of SV-verification tasks). It exposes the same primitive
the internal solve pipeline uses, so customer code can adopt the same
proof artifacts reviewers audit internally.

ATH-387 umbrella: SDK SystemVerilog vertical expansion.
ATH-398 / ATH-401: CEGAR CLI + Python API.
"""
from kairos.sv.cegar import (  # noqa: F401
    CegarError,
    CegarResult,
    IterArtifact,
    cegar,
)
from kairos.sv.ebmc import (  # noqa: F401
    EbmcResult,
    EBMC_PROVED_RE,
    EBMC_REFUTED_RE,
    EBMC_PROPERTY_LINE_RE,
    run_ebmc,
)
from kairos.sv.multi import (  # noqa: F401
    AssertionVerdict,
    BACKENDS as MULTI_BACKENDS,
    LayerResult,
    LayerSpec,
    MultiResult,
    MultiSpec,
    load_spec,
    register_backend as register_multi_backend,
    registered_backends as registered_multi_backends,
    run_multi,
)
from kairos.sv.prove import EbmcError, prove  # noqa: F401
from kairos.sv.swarm import (  # noqa: F401
    ChainedRun,
    CycleSwarmResult,
    CycleVariantRun,
    HitState,
    StateSwarmResult,
    cycle_swarm,
    extract_hit_state,
    parse_trace_states,
    splice_cover_probe,
    splice_cycle_counter,
    splice_cycle_gate_on_asserts,
    splice_init_state_assumption,
    state_swarm,
)
from kairos.sv.mutations import (  # noqa: F401
    Mutant,
    SV_OPERATORS,
    SMV_OPERATORS,
    enumerate_mutants,
)
from kairos.sv.invariants import (  # noqa: F401
    CandidateVerdict,
    InvariantCandidate,
    InvariantDiscoveryResult,
    SurvivingMutant,
    discover_invariants,
    splice_assertion,
)

__all__ = [
    "EbmcResult",
    "EbmcError",
    "EBMC_PROVED_RE",
    "EBMC_REFUTED_RE",
    "EBMC_PROPERTY_LINE_RE",
    "run_ebmc",
    "prove",
    "cegar",
    "CegarError",
    "CegarResult",
    "IterArtifact",
    # ATH-409 state swarm
    "state_swarm",
    "StateSwarmResult",
    "ChainedRun",
    "HitState",
    "extract_hit_state",
    "parse_trace_states",
    "splice_cover_probe",
    "splice_init_state_assumption",
    # ATH-410 cycle swarm
    "cycle_swarm",
    "CycleSwarmResult",
    "CycleVariantRun",
    "splice_cycle_counter",
    "splice_cycle_gate_on_asserts",
    # ATH-412a multi-abstraction
    "run_multi",
    "load_spec",
    "MultiSpec",
    "LayerSpec",
    "MultiResult",
    "LayerResult",
    "AssertionVerdict",
    "MULTI_BACKENDS",
    "register_multi_backend",
    "registered_multi_backends",
    # ATH-411 reverse-mutation-kill
    "discover_invariants",
    "InvariantDiscoveryResult",
    "InvariantCandidate",
    "CandidateVerdict",
    "SurvivingMutant",
    "splice_assertion",
    "Mutant",
    "enumerate_mutants",
    "SV_OPERATORS",
    "SMV_OPERATORS",
]
