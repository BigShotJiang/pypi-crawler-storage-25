"""ATH-708 — goal-shape dispatcher for the OSS Sledgehammer chain.

Pattern-matches a goal payload against the shipped adapter chain
(cvc5, ebmc, cbmc, vampire, eprover, dafny) and dispatches to the
right binary wrapper. Returns a normalized result.

## Why a separate module

Each adapter (`kairos.sv.{cvc5, ebmc, cbmc, vampire, eprover, dafny}`)
owns its binary's invocation contract. The dispatcher owns the
*choice* of which adapter to fire. Keeping it separate means:

- Adapters stay independently testable + dockerizable.
- The dispatch policy (kind detection, fallback ordering) can evolve
  without touching adapter code.
- The dispatcher's no-paid-API regression fence pins the policy as
  free-tier OSS surface.

## Shape detection

Lightweight content-sniffing on the first non-comment, non-blank
line. Sufficient for the canonical input shapes; ambiguous goals
raise `DispatchError` so the caller can pick explicitly.

## Out of scope (v0)

- LLM-backed planning (paid; lives in `kairos.fleet.Orchestrator`).
- Lean kernel reconstruction (asabi-owned, pythia-side).
- Premise selection over `@[stat_lemma]` Mathlib + Pythia lemmas
  (asabi pythia-side).
- Best-of-N parallel dispatch + first-wins policy (kept simple in v0;
  v1 adds it).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


# ─── Public types ─────────────────────────────────────────────────────


@dataclass
class DispatchResult:
    """Normalized result from any adapter dispatch.

    Carries the verdict + the underlying adapter's raw result for any
    customer who wants per-prover detail. `adapter_used` lets the
    customer know which binary was fired (audit / reproducibility).
    """
    adapter_used: str  # "cvc5" | "ebmc" | "cbmc" | "vampire" | "eprover" | "dafny"
    verdict: str
    raw: Any = None
    transcript: str = ""
    error: str = ""


class DispatchError(RuntimeError):
    """Raised when the dispatcher can't pick an adapter for the goal.

    Customer should either reshape the goal, force a specific adapter,
    or fall through to a different layer (e.g. `kairos.simple_prove_template`
    for Lean / Pythia-template goals).
    """


# ─── Shape detection ──────────────────────────────────────────────────


# Mapping kind → adapter name. Public so callers can read the policy
# without grepping.
DISPATCH_TABLE: dict[str, str] = {
    "smt2": "cvc5",
    "tptp": "vampire",  # vampire chosen over E as default; both work
    "sv": "ebmc",
    "c": "cbmc",
    "dafny": "dafny",
}

# ATH-1288 cheap-win 1: Z3-decidable SMT logic classes. Goals in these
# logics can be decided by Z3 in ~5ms without LLM-drafter spend.
# Used by classify_goal_shape() to route z3_check BEFORE sonnet.
Z3_DECIDABLE_LOGICS: frozenset[str] = frozenset({
    "QF_LRA",    # quantifier-free linear real arithmetic
    "QF_LIA",    # quantifier-free linear integer arithmetic
    "QF_LIRA",   # quantifier-free linear integer+real
    "QF_RDL",    # quantifier-free real difference logic
    "QF_IDL",    # quantifier-free integer difference logic
    "QF_UF",     # quantifier-free uninterpreted functions
    "QF_BOOL",   # propositional (SAT)
    "QF_BV",     # quantifier-free bitvectors
    "QF_ABV",    # quantifier-free arrays + bitvectors
    "QF_AUFLIA", # quantifier-free arrays + uninterpreted + linear int
})


def classify_goal_shape(goal_text: str) -> str:
    """ATH-1288 cheap-win 1: classify a goal's shape for smart-routing.

    Returns one of:
    - "z3-decidable"  — QF_LRA/QF_LIA/etc; route to z3_check first
    - "smt-general"   — SMT but not Z3-decidable (nonlinear, quantified)
    - "first-order"   — TPTP first-order; route to eprover/vampire
    - "hardware"      — SystemVerilog/C; route to ebmc/cbmc
    - "proof-assistant" — Dafny/Lean; route to LLM-drafter
    - "unknown"       — can't classify; default dispatch

    Cost impact: z3-decidable goals close in ~5ms. Routing them to
    LLM-drafter wastes ~30s + API spend on something Z3 handles for free.
    """
    kind = detect_kind(goal_text)
    if kind == "smt2":
        logic = _extract_smt_logic(goal_text)
        if logic and logic in Z3_DECIDABLE_LOGICS:
            return "z3-decidable"
        return "smt-general"
    if kind == "tptp":
        return "first-order"
    if kind in ("sv", "c"):
        return "hardware"
    if kind == "dafny":
        return "proof-assistant"
    return "unknown"


def _extract_smt_logic(goal_text: str) -> str | None:
    """Extract the logic name from `(set-logic <LOGIC>)` in SMT2 input."""
    import re
    m = re.search(r"\(set-logic\s+(\S+)\s*\)", goal_text)
    return m.group(1) if m else None


# ATH-1288 cheap-win 3: smart-routing table. Maps goal-shape →
# preferred backend. The dispatcher uses this to pick the right
# adapter before falling back to LLM-drafter.
SMART_ROUTE_TABLE: dict[str, str] = {
    "z3-decidable": "z3",
    "smt-general": "cvc5",
    "first-order": "vampire",
    "hardware": "ebmc",
    "proof-assistant": "sonnet",
    "unknown": "sonnet",
}


def smart_route(goal_text: str) -> str:
    """ATH-1288 cheap-win 3: pick the best backend for a goal.

    Returns the adapter name from SMART_ROUTE_TABLE based on
    classify_goal_shape(). Callers can override by passing
    force_adapter to dispatch().
    """
    shape = classify_goal_shape(goal_text)
    return SMART_ROUTE_TABLE.get(shape, "sonnet")


def detect_kind(goal_text: str) -> str | None:
    """Sniff the goal's input shape from its leading content.

    Returns one of `"smt2"` / `"tptp"` / `"sv"` / `"c"` / `"dafny"` or
    `None` when no kind is recognized. Tolerant of leading whitespace
    + line/block comments. False on empty input.
    """
    if not goal_text or not goal_text.strip():
        return None

    # Look at the first non-comment, non-blank line for a discriminator.
    for raw_line in goal_text.splitlines():
        line = raw_line.lstrip()
        if not line:
            continue
        # Skip common comment leaders. `#` is tricky: `#include` /
        # `#define` are C preprocessor (a real kind discriminator),
        # but `# comment` (with trailing space/EOL) is a shell/Python
        # comment. So skip `#` only when followed by whitespace or
        # nothing — not when followed by an identifier char.
        if line.startswith(("//", "%", ";")):
            continue
        if line.startswith("#") and (len(line) == 1 or line[1].isspace()):
            continue
        if line.startswith("/*"):
            continue
        if line.startswith("--"):
            # Lean / Dafny / Haskell comment. Not a kind discriminator
            # by itself; keep scanning.
            continue
        # Got a real content line. Sniff.
        return _kind_of_line(line)
    return None


def _kind_of_line(line: str) -> str | None:
    """Pure dispatch on the first content line."""
    line = line.lstrip()
    # SMT-LIB scripts open with `(set-logic ...)`, `(declare-...)`,
    # `(assert ...)`, etc.
    if line.startswith(("(set-logic", "(set-info", "(set-option",
                          "(declare-", "(define-", "(assert",
                          "(check-sat")):
        return "smt2"
    # TPTP first-order: `fof(`, `cnf(`, `tff(`, `thf(`.
    if line.startswith(("fof(", "cnf(", "tff(", "thf(")):
        return "tptp"
    # SystemVerilog: `module ` declaration on the first content line.
    if line.startswith(("module ", "interface ", "package ",
                          "checker ", "primitive ")):
        return "sv"
    # C: preprocessor or function definition.
    if line.startswith(("#include", "#define", "#ifdef")):
        return "c"
    # Heuristic: `int main(...)` or `void func(...)` are C-ish.
    # Be conservative — must end with `{` or `;` to qualify.
    if line.startswith(("int ", "void ", "char ", "long ", "double ",
                          "float ", "static ", "extern ", "typedef ")):
        return "c"
    # Dafny: `method ...`, `function ...`, `lemma ...`, `predicate ...`.
    if line.startswith(("method ", "function ", "lemma ",
                          "predicate ", "datatype ", "ghost ")):
        return "dafny"
    return None


# ─── Public entry point ───────────────────────────────────────────────


def dispatch(
    goal_text: str | Path,
    *,
    force_adapter: str | None = None,
    timeout_sec: int = 60,
) -> DispatchResult:
    """Dispatch a goal to the appropriate adapter and return the result.

    Args:
        goal_text: the goal payload. Either inline content or a path.
            Path inputs are read + the kind is detected from content.
        force_adapter: bypass kind detection; force a specific adapter.
            One of `"cvc5"` / `"ebmc"` / `"cbmc"` / `"vampire"` /
            `"eprover"` / `"dafny"`.
        timeout_sec: wall timeout passed through to the adapter.

    Raises:
        DispatchError: when the kind can't be inferred AND no
            `force_adapter` was supplied.

    Free-tier (no license required). All adapters are OSS.
    """
    # Read content if a path was passed (so kind-detection sees text,
    # not a Path object).
    if isinstance(goal_text, Path) or (
        isinstance(goal_text, str) and len(goal_text) < 1024
        and "/" in goal_text and Path(goal_text).is_file()
    ):
        path = Path(goal_text)
        if path.is_file():
            content = path.read_text()
        else:
            content = str(goal_text)
    else:
        content = goal_text  # type: ignore[assignment]

    if force_adapter is not None:
        adapter_name = force_adapter
    else:
        kind = detect_kind(content)
        if kind is None:
            raise DispatchError(
                "could not detect goal kind from content. Force an "
                "adapter via force_adapter=... (one of: "
                f"{', '.join(sorted(set(DISPATCH_TABLE.values())))}).\n"
                f"First 100 chars: {content.strip()[:100]!r}"
            )
        adapter_name = DISPATCH_TABLE.get(kind)
        if adapter_name is None:
            raise DispatchError(
                f"detected kind {kind!r} has no registered adapter."
            )

    return _fire_adapter(adapter_name, content, timeout_sec=timeout_sec)


def _fire_adapter(
    adapter_name: str, content: str, *, timeout_sec: int,
) -> DispatchResult:
    """Call the named adapter + normalize the result."""
    if adapter_name == "cvc5":
        from kairos.sv.cvc5 import run_cvc5
        r = run_cvc5(content, timeout_sec=timeout_sec)
        return DispatchResult(
            adapter_used="cvc5",
            verdict=r.verdict,
            raw=r,
            transcript=r.transcript,
            error=r.error,
        )
    if adapter_name == "vampire":
        from kairos.sv.vampire import run_vampire
        r = run_vampire(content, time_limit=timeout_sec)
        return DispatchResult(
            adapter_used="vampire",
            verdict=r.verdict,
            raw=r,
            transcript=r.transcript,
            error=r.error,
        )
    if adapter_name == "eprover":
        from kairos.sv.eprover import run_eprover
        r = run_eprover(content, cpu_limit=timeout_sec)
        return DispatchResult(
            adapter_used="eprover",
            verdict=r.verdict,
            raw=r,
            transcript=r.transcript,
            error=r.error,
        )
    if adapter_name == "ebmc":
        # ebmc takes a file path, not inline content. Best-effort: write
        # the content to a temp .sv file, dispatch, clean up.
        import tempfile
        from kairos.sv.ebmc import run_ebmc
        fd, tmp = tempfile.mkstemp(suffix=".sv", prefix="kairos_dispatch_")
        try:
            with open(fd, "w") as f:
                f.write(content)
            r = run_ebmc(tmp, timeout_sec=timeout_sec)
        finally:
            try:
                Path(tmp).unlink()
            except OSError:
                pass
        # ebmc verdict is per-property; surface aggregate via proved/refuted.
        ebmc_verdict = (
            "proved" if r.proved > 0 and r.refuted == 0
            else "refuted" if r.refuted > 0
            else "unknown"
        )
        return DispatchResult(
            adapter_used="ebmc",
            verdict=ebmc_verdict,
            raw=r,
            transcript=r.transcript,
            error=r.stderr if r.exit_code != 0 else "",
        )
    if adapter_name == "cbmc":
        import tempfile
        from kairos.sv.cbmc import run_cbmc
        fd, tmp = tempfile.mkstemp(suffix=".c", prefix="kairos_dispatch_")
        try:
            with open(fd, "w") as f:
                f.write(content)
            r = run_cbmc(tmp, timeout_sec=timeout_sec)
        finally:
            try:
                Path(tmp).unlink()
            except OSError:
                pass
        return DispatchResult(
            adapter_used="cbmc",
            verdict=r.verdict,
            raw=r,
            transcript=r.transcript,
            error=r.error,
        )
    if adapter_name == "dafny":
        import tempfile
        from kairos.sv.dafny import run_dafny
        fd, tmp = tempfile.mkstemp(suffix=".dfy", prefix="kairos_dispatch_")
        try:
            with open(fd, "w") as f:
                f.write(content)
            r = run_dafny(tmp, timeout_sec=timeout_sec)
        finally:
            try:
                Path(tmp).unlink()
            except OSError:
                pass
        return DispatchResult(
            adapter_used="dafny",
            verdict=r.verdict,
            raw=r,
            transcript=r.transcript,
            error=r.error,
        )
    raise DispatchError(
        f"unknown adapter {adapter_name!r}. Valid: "
        f"{', '.join(sorted(set(DISPATCH_TABLE.values())))}"
    )


__all__ = [
    "DISPATCH_TABLE",
    "DispatchError",
    "DispatchResult",
    "detect_kind",
    "dispatch",
]
