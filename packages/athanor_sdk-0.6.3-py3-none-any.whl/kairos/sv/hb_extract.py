"""kairos.sv.hb_extract — SV source → HBGraph extractor (ATH-412 Part B slice 2).

Walks a (constrained) SystemVerilog source and populates an ``HBGraph``
from ``kairos.sv.hb_graph`` so downstream callers can run
``find_po_violations`` on the result.

## Supported SV subset

Pragmatic parser — regex + simple brace-balanced walks — targeting the
shape of SV our customer specs actually use today (hw-cbmc-style BMC
tasks, telos_reno/cubic CCA models, Amazon HW-verification demo):

- Single-file, single-module designs (ships first; multi-module is a
  follow-up within this ticket)
- ``always_ff @(posedge <clk> [or posedge <rst>])`` blocks with
  sequential assignments inside a ``begin ... end`` block (or a single
  statement)
- ``always @(*)`` combinational blocks (modeled as READ + WRITE events
  without clock edges — participate in observation HB edges)
- Blocking (``=``) and nonblocking (``<=``) assignments; both become
  WRITE events (the graph is edge-annotated; the SVA emitter in slice 3
  picks the right lowering per assignment kind)
- Plain ``if (...) ... else ...`` control flow (conservative: both
  branches add WRITE events; the HB edges follow source order)
- Port-list signals (``input``/``output``/``inout``) harvested as the
  canonical signal names

## What is explicitly NOT supported (slice 2 scope)

These raise ``HBExtractError`` with an actionable message. Follow-up
tickets handle each:

- ``case``/``casex``/``casez`` statements (ATH-412 Part B slice 2.1)
- ``for`` / ``while`` / ``repeat`` loops
- ``generate`` blocks / ``genvar``
- Multi-module designs / hierarchical instantiation
- Clock-domain crossings (``@(posedge clkA)`` → ``@(posedge clkB)``)
- ``fork`` / ``join``
- ``assign`` continuous statements (modeled as pure combinational
  edges without sequentiality)
- Tasks / functions / packages

The extractor is **honest about failure**: when the source trips an
unsupported construct, it raises with a source-line pointer rather
than silently emitting a partial graph.

## Producer/consumer handshake heuristic

Signals whose identifier matches the regex ``(valid|ready|ack|req)``
at word boundaries are classified as ``HANDSHAKE`` events when they
appear on either side of an assignment. Plain data signals stay as
WRITE / READ. This is a pragmatic shortcut; the SVA emitter (slice 3)
will use the classification to pick the right synchronization-edge
lowering.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from kairos.sv.hb_graph import EdgeKind, Event, EventKind, HBEdge, HBGraph


# ─── Error shape ─────────────────────────────────────────────────────


class HBExtractError(ValueError):
    """Raised on unsupported SV constructs or malformed input. Carries
    ``source_line`` so customers can jump to the offender."""

    def __init__(self, message: str, *, source_line: int | None = None):
        super().__init__(message)
        self.source_line = source_line


# ─── Token patterns ──────────────────────────────────────────────────


_HANDSHAKE_PATTERN = re.compile(
    r"(?:^|[_])(valid|ready|ack|req)(?:$|[_])",
    re.IGNORECASE,
)
_IDENT = r"[A-Za-z_][A-Za-z0-9_$]*"
_IDENT_RE = re.compile(rf"(?<![\w$])({_IDENT})(?![\w$])")

_MODULE_RE = re.compile(
    rf"^\s*module\s+({_IDENT})\s*(?:\(([^)]*)\))?\s*;",
    re.MULTILINE,
)
_ENDMODULE_RE = re.compile(r"\bendmodule\b")
_ALWAYS_FF_HEAD_RE = re.compile(
    r"\balways_ff\s*@\s*\(([^)]*)\)\s*(?=begin\b|\w)",
    re.IGNORECASE,
)
_ALWAYS_AT_HEAD_RE = re.compile(
    r"\balways\s*@\s*\(([^)]*)\)\s*(?=begin\b|\w)",
    re.IGNORECASE,
)
_NB_ASSIGN_RE = re.compile(rf"({_IDENT})\s*<=\s*([^;]+);")
_BL_ASSIGN_RE = re.compile(rf"({_IDENT})\s*=\s*([^;]+);")

# SV keywords that aren't signals (for RHS identifier filtering).
_SV_KEYWORDS = frozenset({
    "if", "else", "begin", "end", "case", "endcase", "default",
    "posedge", "negedge", "or", "and", "not", "xor", "module",
    "endmodule", "reg", "wire", "logic", "bit", "input", "output",
    "inout", "always", "always_ff", "always_comb", "initial",
    "assign", "function", "endfunction", "task", "endtask", "return",
    "integer", "real", "time", "true", "false", "null", "signed",
    "unsigned", "packed", "unpacked", "parameter", "localparam",
    "typedef", "struct", "enum", "for", "while", "repeat", "forever",
    "break", "continue", "fork", "join", "generate", "endgenerate",
    "genvar", "assert", "property", "assume", "cover", "disable", "iff",
})

# Unsupported keywords — if encountered outside of comments/strings,
# abort with HBExtractError per the slice-2 honesty contract.
_UNSUPPORTED_KEYWORDS = frozenset({
    "case", "casex", "casez", "for", "while", "repeat",
    "generate", "genvar", "fork", "join", "task", "function",
})


# ─── Comment stripping ───────────────────────────────────────────────


def _strip_comments(src: str) -> str:
    """Remove // line-comments and /* block comments */ but preserve
    line numbering (replace with spaces)."""
    out: list[str] = []
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if c == "/" and nxt == "/":
            # eat until newline
            while i < n and src[i] != "\n":
                out.append(" " if src[i] != "\n" else src[i])
                i += 1
        elif c == "/" and nxt == "*":
            # eat block comment preserving newlines
            i += 2
            while i + 1 < n and not (src[i] == "*" and src[i + 1] == "/"):
                out.append("\n" if src[i] == "\n" else " ")
                i += 1
            if i + 1 < n:
                i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


# ─── Module + block discovery ────────────────────────────────────────


@dataclass
class ParsedBlock:
    """A discovered ``always_ff`` / ``always @`` block."""

    block_id: str
    kind: str  # 'always_ff' | 'always'
    sensitivity: str  # raw sensitivity list text
    body: str  # the begin..end (or single-stmt) content
    start_line: int

    @property
    def is_clocked(self) -> bool:
        return self.kind == "always_ff" and "posedge" in self.sensitivity.lower()


def _line_of(src: str, offset: int) -> int:
    return src.count("\n", 0, offset) + 1


def _find_matching_end(src: str, begin_idx: int) -> int:
    """Given an index where 'begin' starts in src, return the index
    just past the matching 'end'. Handles nested begin/end."""
    depth = 0
    i = begin_idx
    n = len(src)
    while i < n:
        if src[i : i + 5] == "begin" and (
            i == 0 or not src[i - 1].isalnum() and src[i - 1] != "_"
        ) and (i + 5 >= n or not src[i + 5].isalnum() and src[i + 5] != "_"):
            depth += 1
            i += 5
        elif src[i : i + 3] == "end" and (
            i == 0 or not src[i - 1].isalnum() and src[i - 1] != "_"
        ) and (i + 3 >= n or not src[i + 3].isalnum() and src[i + 3] != "_"):
            depth -= 1
            i += 3
            if depth == 0:
                return i
        else:
            i += 1
    raise HBExtractError("unterminated begin/end block", source_line=_line_of(src, begin_idx))


def _check_unsupported(src: str) -> None:
    """Raise on unsupported SV constructs."""
    for kw in _UNSUPPORTED_KEYWORDS:
        m = re.search(rf"\b{kw}\b", src)
        if m:
            raise HBExtractError(
                f"unsupported SV construct: '{kw}'. "
                f"Slice 2 scope: always_ff / always @(*) / plain if-else only. "
                f"Follow-up ticket tracks {kw}.",
                source_line=_line_of(src, m.start()),
            )


def _find_blocks(src: str) -> list[ParsedBlock]:
    """Walk src, return every always_ff / always @ block as ParsedBlock."""
    blocks: list[ParsedBlock] = []

    for idx, match in enumerate(_ALWAYS_FF_HEAD_RE.finditer(src)):
        sensitivity = match.group(1).strip()
        after = match.end()
        body = _extract_block_body(src, after)
        blocks.append(ParsedBlock(
            block_id=f"ff_{idx}",
            kind="always_ff",
            sensitivity=sensitivity,
            body=body,
            start_line=_line_of(src, match.start()),
        ))

    # always @(*) or always @(posedge ...) — catch any 'always' not
    # captured above (always_ff matches first; we match any remaining).
    already_captured_heads = {b.start_line for b in blocks}
    for idx, match in enumerate(_ALWAYS_AT_HEAD_RE.finditer(src)):
        if match.group(0).strip().startswith("always_ff"):
            continue  # captured in prior pass
        line = _line_of(src, match.start())
        if line in already_captured_heads:
            continue
        sensitivity = match.group(1).strip()
        after = match.end()
        body = _extract_block_body(src, after)
        blocks.append(ParsedBlock(
            block_id=f"at_{idx}",
            kind="always",
            sensitivity=sensitivity,
            body=body,
            start_line=line,
        ))

    return blocks


def _extract_block_body(src: str, start_idx: int) -> str:
    """Starting at start_idx, extract begin...end body OR single stmt."""
    # Skip whitespace
    i = start_idx
    while i < len(src) and src[i].isspace():
        i += 1
    if src[i : i + 5] == "begin" and (
        i + 5 >= len(src) or not src[i + 5].isalnum() and src[i + 5] != "_"
    ):
        end_idx = _find_matching_end(src, i)
        # Body is between begin..end exclusive of both
        return src[i + 5 : end_idx - 3].strip()
    # Single statement — read until first ;
    j = i
    while j < len(src) and src[j] != ";":
        j += 1
    return src[i : j + 1].strip()


# ─── RHS signal extraction ──────────────────────────────────────────


def _rhs_signals(rhs: str, declared: set[str]) -> set[str]:
    """Pull identifier signals out of an assignment RHS."""
    out: set[str] = set()
    for m in _IDENT_RE.finditer(rhs):
        name = m.group(1)
        if name in _SV_KEYWORDS:
            continue
        if name in declared:
            out.add(name)
        # Identifiers not in the declared set are likely literals
        # or constant names — skip them.
    return out


def _event_kind_for(signal: str, assign: bool = True) -> EventKind:
    if _HANDSHAKE_PATTERN.search(signal):
        return EventKind.HANDSHAKE
    return EventKind.WRITE if assign else EventKind.READ


# ─── Top-level extractor ─────────────────────────────────────────────


def extract_hb_graph(source: str | Path) -> HBGraph:
    """Walk SV source, return populated HBGraph.

    Args:
        source: raw SV text, OR a path to an SV file.

    Returns:
        HBGraph with Event per discovered read/write/handshake + HBEdge
        per program-order pair. Does NOT run cycle detection — caller
        composes with ``find_po_violations``.

    Raises:
        HBExtractError on unsupported constructs or malformed SV.
    """
    if isinstance(source, Path):
        source = source.read_text()
    elif not isinstance(source, str):
        raise TypeError(f"source must be str or Path, got {type(source).__name__}")

    stripped = _strip_comments(source)
    _check_unsupported(stripped)

    module_match = _MODULE_RE.search(stripped)
    if not module_match:
        raise HBExtractError("no module declaration found", source_line=1)
    if _MODULE_RE.search(stripped, module_match.end()):
        raise HBExtractError(
            "multi-module designs not supported in slice 2 "
            "(see follow-up under ATH-412 Part B)",
            source_line=_line_of(stripped, _MODULE_RE.search(
                stripped, module_match.end()).start()),
        )

    port_list_raw = module_match.group(2) or ""
    declared: set[str] = set()
    for m in _IDENT_RE.finditer(port_list_raw):
        name = m.group(1)
        if name not in _SV_KEYWORDS:
            declared.add(name)
    # Also harvest top-level reg/wire/logic declarations inside the
    # module body so RHS reads resolve.
    body_start = module_match.end()
    body_end = stripped.find("endmodule", body_start)
    if body_end == -1:
        raise HBExtractError("no endmodule terminator found",
                             source_line=_line_of(stripped, body_start))
    module_body = stripped[body_start:body_end]

    for kw in ("reg", "wire", "logic"):
        # Match `<kw> [packed-range] name [, name]* ;`
        for m in re.finditer(
            rf"\b{kw}\b\s*(?:\[[^\]]*\])?\s*([^;]+);", module_body
        ):
            for nm in _IDENT_RE.finditer(m.group(1)):
                if nm.group(1) not in _SV_KEYWORDS:
                    declared.add(nm.group(1))

    # Discover always_ff / always @ blocks
    blocks = _find_blocks(module_body)

    graph = HBGraph()
    # Synthetic init event so every block has a predecessor (aids
    # downstream reachability analysis).
    init_evt = Event(
        event_id="_init",
        kind=EventKind.INIT,
        signal="",
        block="<initial>",
    )
    graph.add_event(init_evt)

    event_counter = 0

    for block in blocks:
        prev_evt_id: str | None = None
        # Local line-of-offset helper: line within block body +
        # block's start line
        for stmt_iter in _iter_statements(block.body):
            stmt_text, stmt_offset = stmt_iter
            stmt_line = block.start_line + block.body.count("\n", 0, stmt_offset)

            # Parse assignment: try nonblocking first, then blocking.
            nb = _NB_ASSIGN_RE.search(stmt_text)
            bl = None if nb else _BL_ASSIGN_RE.search(stmt_text)
            m = nb or bl
            if not m:
                continue

            lhs = m.group(1)
            rhs = m.group(2)
            if lhs not in declared:
                declared.add(lhs)

            # Extract if-condition signals as READ events. SV stmts
            # like `if (a && b) x <= c;` read a and b — both should
            # flow as READ events with PROGRAM_ORDER edges to the
            # LHS WRITE below.
            cond_signals: set[str] = set()
            for cond_match in re.finditer(r"\bif\s*\(([^)]*)\)", stmt_text):
                cond_signals |= _rhs_signals(cond_match.group(1), declared)

            # LHS → WRITE (or HANDSHAKE) event
            event_counter += 1
            eid = f"{block.block_id}#e{event_counter}"
            write_evt = Event(
                event_id=eid,
                kind=_event_kind_for(lhs, assign=True),
                signal=lhs,
                block=block.block_id,
                source_line=stmt_line,
            )
            graph.add_event(write_evt)

            # PROGRAM_ORDER edge from previous event in this block
            if prev_evt_id is None:
                graph.add_edge(HBEdge(
                    src=init_evt.event_id,
                    dst=eid,
                    kind=EdgeKind.INIT_EDGE,
                    reason=f"initial activation of {block.block_id}",
                ))
            else:
                graph.add_edge(HBEdge(
                    src=prev_evt_id,
                    dst=eid,
                    kind=EdgeKind.PROGRAM_ORDER,
                    reason=f"sequential stmt in {block.block_id}",
                ))
            prev_evt_id = eid

            # RHS reads + if-condition reads → READ / HANDSHAKE
            # events with PROGRAM_ORDER edges into the LHS WRITE. For
            # slice 2 we add the READ event but DON'T yet chase
            # cross-block observation edges — that's fixed-point
            # extension in slice 2.1.
            all_reads = _rhs_signals(rhs, declared) | cond_signals
            for read_sig in all_reads:
                if read_sig == lhs:
                    continue  # self-ref is a ff update, not a HB edge
                event_counter += 1
                read_eid = f"{block.block_id}#e{event_counter}"
                read_evt = Event(
                    event_id=read_eid,
                    kind=_event_kind_for(read_sig, assign=False),
                    signal=read_sig,
                    block=block.block_id,
                    source_line=stmt_line,
                )
                graph.add_event(read_evt)
                graph.add_edge(HBEdge(
                    src=read_eid,
                    dst=eid,
                    kind=EdgeKind.PROGRAM_ORDER,
                    reason=f"signal {read_sig} feeds LHS {lhs}",
                ))

    return graph


def _iter_statements(body: str) -> Iterator[tuple[str, int]]:
    """Yield (stmt_text, offset_in_body) for each ';'-terminated stmt.

    Naive: splits on ';' at the top level. Good enough for sequential
    if/else bodies; case/loop blocks are caught earlier by
    _check_unsupported.
    """
    depth = 0
    start = 0
    for i, c in enumerate(body):
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        elif c == ";" and depth == 0:
            stmt = body[start : i + 1].strip()
            if stmt:
                # Find actual offset of stripped stmt within original
                # body (skip leading whitespace).
                offset = start + len(body[start : i + 1]) - len(
                    body[start : i + 1].lstrip()
                )
                yield stmt, offset
            start = i + 1


# ─── Public surface ──────────────────────────────────────────────────


__all__ = [
    "HBExtractError",
    "ParsedBlock",
    "extract_hb_graph",
]
