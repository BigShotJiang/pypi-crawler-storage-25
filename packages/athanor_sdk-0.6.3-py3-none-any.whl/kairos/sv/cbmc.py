"""ATH-706 (chain ATH-697) — CBMC software bounded model-checker adapter.

CBMC verifies C / C++ programs by symbolically unwinding loops to a
fixed bound and checking assertions hold for all reachable states. This
adapter is the Python wrapper around the `cbmc` binary; same shape as
`kairos.sv.ebmc.run_ebmc` and `kairos.sv.cvc5.run_cvc5`.

## Free tier

CBMC is open source. This adapter ships as part of the OSS Sledgehammer
surface alongside `ebmc` (ATH-704 un-gated) and `cvc5` (ATH-705). No
license-gate calls.

## Output

`CbmcResult` carries:

  - `verdict`: `"verification_successful"` / `"verification_failed"` /
    `"timeout"` / `"error"`.
  - `failed_assertions`: list of `(file, line, description)` tuples
    when the verdict is failed.
  - `transcript`: full cbmc stdout for debugging.
  - `exit_code`, `stderr`, `elapsed_sec`: subprocess metadata.

## Failure modes

- `cbmc` not on PATH → `verdict="error"` with install hint.
- Subprocess timeout → `verdict="timeout"`.
- Source compile error → exit code nonzero, `verdict="error"` with
  cbmc's stderr surfaced.

## Why a separate module

Mirrors `kairos.sv.{ebmc, cvc5}` (one module per prover). The Pythia
goal-shape-dispatch orchestrator picks which adapter to fire upstream;
each adapter owns its binary's invocation contract.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CbmcResult:
    """Structured outcome from a single `cbmc` invocation."""

    verdict: str  # "verification_successful" | "verification_failed" | "timeout" | "error"
    failed_assertions: list[tuple[str, int, str]] = field(default_factory=list)
    transcript: str = ""
    stderr: str = ""
    exit_code: int = 0
    elapsed_sec: float = 0.0
    error: str = ""


def _is_cbmc_available() -> bool:
    return shutil.which("cbmc") is not None


# CBMC's failed-assertion line shape:
#   file.c function bar line 42 column 5: assertion <description>: FAILURE
# Patterns capture (file, line, description).
_FAILED_LINE_RE = re.compile(
    r"^(?P<file>\S+)\s+\S+\s+line\s+(?P<line>\d+)\b"
    r"[^:]*:\s*(?P<desc>[^:]+?):\s*FAILURE",
    re.MULTILINE,
)


def run_cbmc(
    c_file: str | Path,
    *,
    unwind: int = 10,
    function: str | None = None,
    timeout_sec: int = 60,
    extra_args: list[str] | None = None,
) -> CbmcResult:
    """Invoke `cbmc` on a C source file + return a structured verdict.

    Args:
        c_file: path to the C / C++ source.
        unwind: loop unwinding bound (`--unwind <N>`). Tighter bounds
            run faster but may miss deep bugs; loose bounds find more
            but cost CPU.
        function: optional `--function <name>` for whole-program-mode
            verification of a specific entry point.
        timeout_sec: hard wall timeout on the subprocess call.
        extra_args: additional CLI args appended verbatim
            (e.g. `["--bounds-check", "--pointer-check"]`).

    Free-tier (no license required). cbmc is open-source.
    """
    if not _is_cbmc_available():
        return CbmcResult(
            verdict="error",
            error="cbmc not on PATH. Install from "
                  "https://github.com/diffblue/cbmc",
        )

    src = Path(c_file)
    if not src.is_file():
        return CbmcResult(
            verdict="error",
            error=f"c_file does not exist: {src}",
        )

    cmd: list[str] = ["cbmc", str(src), "--unwind", str(unwind)]
    if function:
        cmd += ["--function", function]
    if extra_args:
        cmd += list(extra_args)

    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
    except subprocess.TimeoutExpired:
        return CbmcResult(
            verdict="timeout",
            error=f"cbmc timed out after {timeout_sec}s",
            elapsed_sec=float(timeout_sec),
        )

    elapsed = time.monotonic() - t0
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""

    verdict, failed = _parse_cbmc_output(stdout)

    # CBMC exit codes:
    #   0  = verification successful
    #   10 = verification failed (assertion(s) violated)
    #   nonzero non-10 = error (compile fail, internal error, etc).
    if proc.returncode not in (0, 10) and verdict != "verification_failed":
        return CbmcResult(
            verdict="error",
            transcript=stdout,
            stderr=stderr,
            exit_code=proc.returncode,
            elapsed_sec=elapsed,
            error=f"cbmc exit {proc.returncode}; "
                  f"stderr: {stderr.strip()[:300]}",
        )

    return CbmcResult(
        verdict=verdict,
        failed_assertions=failed,
        transcript=stdout,
        stderr=stderr,
        exit_code=proc.returncode,
        elapsed_sec=elapsed,
    )


def _parse_cbmc_output(stdout: str) -> tuple[str, list[tuple[str, int, str]]]:
    """Parse cbmc's stdout into `(verdict, failed_assertions)`.

    Looks for the canonical `VERIFICATION SUCCESSFUL` / `VERIFICATION
    FAILED` lines + collects `: FAILURE` assertion details.
    """
    failed: list[tuple[str, int, str]] = []

    if "VERIFICATION SUCCESSFUL" in stdout:
        return "verification_successful", failed

    if "VERIFICATION FAILED" in stdout:
        for m in _FAILED_LINE_RE.finditer(stdout):
            try:
                line_no = int(m.group("line"))
            except ValueError:
                continue
            failed.append((
                m.group("file"),
                line_no,
                m.group("desc").strip(),
            ))
        return "verification_failed", failed

    # No clear verdict — surface as error so caller doesn't mistake
    # silence for success.
    return "error", failed


__all__ = [
    "CbmcResult",
    "run_cbmc",
]
