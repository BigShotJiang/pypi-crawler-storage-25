"""kairos.sv.swarm — EBMC bug-hunting swarms.

Two orchestration patterns that chain BMC runs for deeper coverage
than a single fixed-bound invocation:

    state_swarm — cover → init-state chaining
        For each cover condition, find a reachable state that hits the
        cover, extract register values at the hit cycle, then re-run the
        original assertions with the initial state constrained to that
        hit state. Effectively explores 2·bound depth for O(bound)
        solver time per chain, because each cover-hit seeds a fresh
        bound-depth exploration.

    cycle_swarm — cycle-indexed assertion variants
        Given an assertion `A |-> B`, generate `cycle_count == k && A |-> B`
        variants for each k in a user-specified list. Each variant forces
        EBMC to surface invariants specific to that cycle. See
        solve/sysverilog/cegar/ for the sibling vacuity/progress-gate
        pattern this reuses.

Both entry points are pure-EBMC, zero-LLM, terminal-friendly. They
exist to complement `kairos.sv.prove`'s single-shot call with
systematic chaining / slicing patterns that would otherwise require
the customer to hand-script multiple EBMC runs.

Design mirror of CEGAR (kairos.sv.cegar / solve/sysverilog/cegar/):
same gate + run_ebmc wrapper, but the orchestration is
deterministic (no LLM proposer) so the code stays compact.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from kairos.sv.ebmc import EbmcResult, run_ebmc, summarize_refutations


# ─── Dataclasses ─────────────────────────────────────────────────────


@dataclass
class HitState:
    """Register values extracted at the cycle a cover assertion fired.

    `registers` is a mapping of register name (hierarchical, e.g.
    `reno_cca.cwnd`) to the string value EBMC reported at the hit
    cycle. Values are kept as strings to preserve EBMC's own
    formatting (decimal, hex, binary) — downstream splice logic
    converts per SV literal rules.
    """

    cover_expr: str
    hit_cycle: int
    registers: dict[str, str]

    def to_sva_assumption(self, top_module: str, init_gate: str = "__init_done") -> str:
        """Render this hit state as an SVA `assume property` string.

        The assumption is gated on `!init_gate` so it applies only at
        cycle 0 (the init_gate register is initialized to 0 and set to 1
        on the first posedge clk via an injected always_ff). See
        `splice_init_state_assumption` for the full injection.
        """
        # Strip the top_module prefix off register names if present —
        # the spec references them unqualified.
        clauses: list[str] = []
        prefix = f"{top_module}."
        for name, val in self.registers.items():
            local = name.removeprefix(prefix) if name.startswith(prefix) else name
            clauses.append(f"({local} == {val})")
        if not clauses:
            return "assume property (@(posedge clk) 1);"  # no-op
        body = " && ".join(clauses)
        return (
            f"assume property (@(posedge clk) !{init_gate} |-> ({body}));"
        )


@dataclass
class ChainedRun:
    """One cover's stage-1 + stage-2 result."""

    cover_expr: str
    reachable: bool
    hit_state: HitState | None = None
    stage2: EbmcResult | None = None
    stage2_proved: int = 0
    stage2_refuted: int = 0
    stage2_refuted_names: list[str] = field(default_factory=list)
    note: str = ""


@dataclass
class StateSwarmResult:
    """Full state-swarm outcome across all covers."""

    spec_path: Path
    top_module: str
    bound: int
    chain_depth: int
    covers_requested: int
    covers_reachable: int
    chained_runs: list[ChainedRun]
    overall: str  # "CLEAN" | "NEW_REFUTATION" | "PARTIAL"

    def summary_lines(self) -> list[str]:
        out = [
            f"state-swarm: {self.covers_requested} cover(s) "
            f"→ {self.covers_reachable} reachable within bound={self.bound}",
        ]
        for cr in self.chained_runs:
            tag = "✓" if cr.stage2_refuted == 0 else "✗"
            reach = "reachable" if cr.reachable else "unreachable"
            if cr.reachable:
                out.append(
                    f"  {tag} cover {cr.cover_expr!r}: {reach} at cycle "
                    f"{cr.hit_state.hit_cycle if cr.hit_state else '?'}, "
                    f"chained proved={cr.stage2_proved} refuted={cr.stage2_refuted}"
                    + (f" ({', '.join(cr.stage2_refuted_names)})"
                       if cr.stage2_refuted_names else "")
                )
            else:
                out.append(f"  - cover {cr.cover_expr!r}: {reach} within bound, skipped")
        out.append(f"overall: {self.overall}")
        return out


# ─── Hit-state extraction ────────────────────────────────────────────


# EBMC counterexample trace format (observed on hw-cbmc 5.10 with the
# `--trace` flag, which we pass per stage-1 run):
#
#   Counterexample:
#
#   Transition system state 0
#   ----------------------------------------------------
#     reno_cca.clk = ?
#     reno_cca.reset = 0
#     reno_cca.cwnd = 1 (00000001)
#
#   Transition system state 1
#   ----------------------------------------------------
#     reno_cca.cwnd = 2 (00000010)
#
# Values may be trailed by `(binary)` — we capture the decimal form.
# Older EBMC versions used "State N" / "Trace step N:" headers;
# accept all three to stay robust.

_STATE_HEADER_RE = re.compile(
    r"^(?:Transition system state|State|Trace step)\s+(\d+)"
    r"(?:\s*\(initial state\))?\s*$",
    re.MULTILINE,
)
# Signal assignment lines. Format: `<indent><name> = <value>[ (binary)]`.
# Values include bare literals (0, 1, 42) or `?` for unconstrained
# inputs. We capture the decimal value only; the optional trailing
# `(binary)` is discarded.
_ASSIGNMENT_RE = re.compile(
    r"^\s+([A-Za-z_][A-Za-z_0-9.]*)\s*=\s*(\S+?)(?:\s*\([01]+\))?\s*$",
    re.MULTILINE,
)

# `reg <name>` declarations in a spec. Covers internal regs and
# `output reg` variants. We use this to filter out input-signal
# assignments from the hit-state — pinning inputs would wrongly
# over-constrain the state-2 run (inputs are per-cycle free
# variables).
_REG_DECL_RE = re.compile(
    r"\b(?:output\s+)?reg\s+(?:\[[^\]]+\]\s+)?"
    r"(?P<names>[A-Za-z_][A-Za-z_0-9]*"
    r"(?:\s*,\s*[A-Za-z_][A-Za-z_0-9]*)*)",
)


def extract_register_names(spec_text: str) -> set[str]:
    """Return the set of register names declared in the spec.

    Used to filter the counterexample so only register-valued signals
    are pinned in the stage-2 init-state assumption. Input wires /
    clk / reset must remain free per-cycle variables.
    """
    names: set[str] = set()
    for m in _REG_DECL_RE.finditer(spec_text):
        for raw in m.group("names").split(","):
            names.add(raw.strip())
    return names


def parse_trace_states(counterexample: str) -> list[tuple[int, dict[str, str]]]:
    """Parse an EBMC counterexample trace into [(cycle, {reg: val}), ...].

    Cycles are 1-indexed per EBMC convention. Returns an empty list if
    no state headers are found (malformed or absent trace).
    """
    if not counterexample:
        return []
    # Split on state headers. Walk them in order + scoop assignments
    # between each pair.
    headers = list(_STATE_HEADER_RE.finditer(counterexample))
    out: list[tuple[int, dict[str, str]]] = []
    for i, m in enumerate(headers):
        cycle = int(m.group(1))
        start = m.end()
        end = headers[i + 1].start() if i + 1 < len(headers) else len(counterexample)
        block = counterexample[start:end]
        regs = {
            am.group(1): am.group(2)
            for am in _ASSIGNMENT_RE.finditer(block)
        }
        out.append((cycle, regs))
    return out


def extract_hit_state(
    counterexample: str,
    *,
    cover_expr: str,
    register_names: set[str] | None = None,
    top_module: str | None = None,
) -> HitState | None:
    """Return the register values at the cycle the cover fired.

    We take the LAST state in the trace as the hit cycle — EBMC's
    convention is that the counterexample terminates at the cycle
    where the (negated) cover assertion failed.

    If `register_names` is provided, only signals matching one of
    those names (hierarchically, with or without a `<top_module>.`
    prefix) are retained. Unconstrained signals (value `?`) and
    non-register signals are dropped — pinning them in stage 2
    would over-constrain the run.

    Returns None if the trace contains no state headers.
    """
    states = parse_trace_states(counterexample)
    if not states:
        return None
    hit_cycle, hit_regs = states[-1]
    if register_names is not None:
        prefix = f"{top_module}." if top_module else ""
        def is_reg(full_name: str) -> bool:
            local = full_name.removeprefix(prefix) if prefix else full_name
            return local in register_names
        hit_regs = {
            name: val for name, val in hit_regs.items()
            if is_reg(name) and val != "?"
        }
    return HitState(cover_expr=cover_expr, hit_cycle=hit_cycle, registers=hit_regs)


# ─── SV splice primitives ────────────────────────────────────────────


def splice_cover_probe(spec_text: str, cover_expr: str) -> str:
    """Append a `assert property (!cover_expr)` probe before endmodule.

    EBMC refutes this iff `cover_expr` is reachable within bound. The
    refutation's counterexample terminates at the hit cycle.
    """
    idx = spec_text.rfind("endmodule")
    if idx < 0:
        # ATH-845: typed exception so customers can `except
        # MalformedSystemVerilogSpec` instead of grepping the
        # message string.
        from kairos.errors import MalformedSystemVerilogSpec
        raise MalformedSystemVerilogSpec("spec has no `endmodule`")
    probe = (
        "\n  // state-swarm cover-reachability probe\n"
        f"  swarm_cover_probe:\n"
        f"    assert property (@(posedge clk) !({cover_expr}));\n"
    )
    return spec_text[:idx] + probe + spec_text[idx:]


def splice_init_state_assumption(
    spec_text: str,
    hit_state: HitState,
    top_module: str,
    *,
    init_gate_name: str = "__init_done",
) -> str:
    """Inject an init-gated `assume property` pinning initial state.

    Adds a 1-bit gate register that's 0 at cycle 0 and 1 thereafter,
    plus an `assume property (!gate |-> <reg == val && ...>)` clause.
    EBMC treats the gate as unconstrained SAT input otherwise, so we
    hand-force the initialization with `reg ... = 1'b0;`.

    Handles the case where the spec already has a register of the same
    name (no-op if matched gate by chance) — we use a double-underscore
    prefix to minimize collision risk.

    The splice inserts:

        reg __init_done = 1'b0;
        always @(posedge clk) __init_done <= 1'b1;
        assume property (@(posedge clk) !__init_done |->
                         (cwnd == 8'd1 && loss == 1'b0 && ...));

    right before `endmodule`.
    """
    idx = spec_text.rfind("endmodule")
    if idx < 0:
        # ATH-845: typed exception so customers can `except
        # MalformedSystemVerilogSpec` instead of grepping the
        # message string.
        from kairos.errors import MalformedSystemVerilogSpec
        raise MalformedSystemVerilogSpec("spec has no `endmodule`")

    gate_decl = f"  reg {init_gate_name} = 1'b0;\n"
    gate_update = (
        f"  always @(posedge clk) {init_gate_name} <= 1'b1;\n"
    )
    assumption = "  " + hit_state.to_sva_assumption(top_module, init_gate_name) + "\n"

    block = (
        "\n  // state-swarm stage-2: pin initial state to cover-hit values\n"
        + gate_decl
        + gate_update
        + assumption
    )
    return spec_text[:idx] + block + spec_text[idx:]


# ─── State swarm driver ──────────────────────────────────────────────


def state_swarm(
    spec_file: str | Path,
    *,
    top_module: str,
    covers: list[str],
    bound: int = 10,
    chain_depth: int | None = None,
    timeout_sec: int = 60,
) -> StateSwarmResult:
    """Run a state-swarm over the given covers.

    For each cover:
      1. Splice a `!cover` assertion and run EBMC at `bound`.
      2. If the cover is reachable (assertion refutes), extract the
         hit state from the counterexample.
      3. Splice an init-state assumption pinning those register values,
         and re-run the ORIGINAL (unmodified) assertions at
         `chain_depth` (default same as `bound`).
      4. Record per-cover results.

    Args:
        spec_file: Path to the spec. Contents must include a single
            `endmodule` (MVP — multi-module specs not supported).
        top_module: EBMC top-module name (passed to run_ebmc).
        covers: List of SV expressions to check reachability for,
            e.g. `["cwnd == 8'd1", "loss == 1'b1"]`. Each is
            interpreted as a safety property's negation for
            reachability.
        bound: Stage-1 BMC depth.
        chain_depth: Stage-2 BMC depth. Defaults to `bound`.
        timeout_sec: Per-EBMC-invocation wall timeout.

    Returns:
        StateSwarmResult with per-cover chained verdicts + overall
        status.

    Raises:
        FileNotFoundError: if spec_file doesn't exist.
        ValueError: if spec has no `endmodule` (bad SV).
    """
    # ATH-686 P1: programmatic state_swarm entry → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    spec_path = Path(spec_file)
    if not spec_path.is_file():
        raise FileNotFoundError(f"spec file not found: {spec_path}")
    base_text = spec_path.read_text()
    if chain_depth is None:
        chain_depth = bound

    # Used to filter the counterexample so we pin only registers,
    # never input signals.
    register_names = extract_register_names(base_text)

    chained: list[ChainedRun] = []
    covers_reachable = 0

    for cover in covers:
        # Stage 1: probe for reachability.
        probed = splice_cover_probe(base_text, cover)
        # EBMC runs on a file path, so we write the spliced text to a
        # tempfile next to the original (same dir → relative includes
        # resolve).
        import tempfile
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".sv", delete=False, dir=spec_path.parent,
            prefix=f".swarm_stage1_{_slugify(cover)}_",
        ) as tf:
            tf.write(probed)
            probe_path = Path(tf.name)
        try:
            # `--trace` makes EBMC emit the Counterexample block we parse.
            # Without it the refutation is reported but no state values
            # are printed.
            r1 = run_ebmc(
                probe_path,
                top_module=top_module, bound=bound, timeout_sec=timeout_sec,
                extra_args=["--trace"],
            )
        finally:
            probe_path.unlink(missing_ok=True)

        # If EBMC crashed on the splice, skip + log.
        if r1.exit_code != 0 and r1.proved == 0 and r1.refuted == 0 and not r1.timed_out:
            chained.append(ChainedRun(
                cover_expr=cover, reachable=False,
                note=f"EBMC crashed on probe (stderr: {r1.stderr[:150]})",
            ))
            continue

        # Cover unreachable within bound → no chaining.
        if r1.refuted == 0:
            chained.append(ChainedRun(
                cover_expr=cover, reachable=False,
                note=f"unreachable within bound={bound}",
            ))
            continue

        # Cover reachable — extract hit state (filtered to registers only).
        # Use the RAW stdout from the "Counterexample:" marker to end —
        # the shared `extract_counterexample` cuts at the first blank
        # line which discards everything after state 0 in --trace
        # output.
        cex = _extract_full_trace_block(r1.stdout)
        hit = extract_hit_state(
            cex, cover_expr=cover,
            register_names=register_names, top_module=top_module,
        )
        if hit is None:
            chained.append(ChainedRun(
                cover_expr=cover, reachable=True,
                note="cover reachable but no parseable trace states found",
            ))
            continue
        covers_reachable += 1

        # Stage 2: pin init-state, re-run original spec's assertions.
        stage2_text = splice_init_state_assumption(
            base_text, hit, top_module=top_module,
        )
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".sv", delete=False, dir=spec_path.parent,
            prefix=f".swarm_stage2_{_slugify(cover)}_",
        ) as tf:
            tf.write(stage2_text)
            stage2_path = Path(tf.name)
        try:
            r2 = run_ebmc(
                stage2_path,
                top_module=top_module, bound=chain_depth, timeout_sec=timeout_sec,
            )
        finally:
            stage2_path.unlink(missing_ok=True)

        refuted_names = [
            s["name"] for s in summarize_refutations(r2.stdout, max_props=16)
        ]
        chained.append(ChainedRun(
            cover_expr=cover, reachable=True,
            hit_state=hit, stage2=r2,
            stage2_proved=r2.proved, stage2_refuted=r2.refuted,
            stage2_refuted_names=refuted_names,
        ))

    total_refuted = sum(cr.stage2_refuted for cr in chained)
    overall = "NEW_REFUTATION" if total_refuted > 0 else (
        "CLEAN" if covers_reachable == len(covers) else "PARTIAL"
    )

    return StateSwarmResult(
        spec_path=spec_path,
        top_module=top_module,
        bound=bound,
        chain_depth=chain_depth,
        covers_requested=len(covers),
        covers_reachable=covers_reachable,
        chained_runs=chained,
        overall=overall,
    )


# ─── Cycle swarm (ATH-410) ───────────────────────────────────────────


@dataclass
class CycleVariantRun:
    """One cycle value's EBMC result.

    The original spec's existing `assert property` declarations are
    rewritten to fire only at `__cycle_count == k`, so EBMC can find
    refutations local to that cycle without masking them behind cycles
    where the property naturally holds.
    """

    cycle: int
    ebmc: EbmcResult | None = None
    proved: int = 0
    refuted: int = 0
    refuted_names: list[str] = field(default_factory=list)
    note: str = ""


@dataclass
class CycleSwarmResult:
    """Aggregate outcome of a cycle-swarm run."""

    spec_path: Path
    top_module: str
    bound: int
    cycles_requested: list[int]
    variant_runs: list[CycleVariantRun]
    overall: str  # "CLEAN" | "NEW_REFUTATION" | "PARTIAL"

    @property
    def total_refuted(self) -> int:
        return sum(v.refuted for v in self.variant_runs)

    def summary_lines(self) -> list[str]:
        out = [
            f"cycle-swarm: {len(self.cycles_requested)} cycle variant(s) "
            f"at bound={self.bound}",
        ]
        for v in self.variant_runs:
            tag = "✓" if v.refuted == 0 and not v.note else "✗" if v.refuted else "-"
            if v.note:
                out.append(f"  {tag} cycle {v.cycle}: {v.note}")
            else:
                out.append(
                    f"  {tag} cycle {v.cycle}: "
                    f"proved={v.proved} refuted={v.refuted}"
                    + (f" ({', '.join(v.refuted_names)})" if v.refuted_names else "")
                )
        out.append(f"overall: {self.overall}")
        return out


# Match `<label>:\s*assert\s+property\s*(\s*<body>\s*);` even when the
# body spans multiple lines. The label (e.g. `p_cwnd_halves_on_loss:`)
# is optional — EBMC accepts anonymous asserts. We capture the body
# through balanced parens; regex can't do arbitrary nesting, but spec
# assertions rarely nest more than the outermost pair, so a non-greedy
# match against the closing `);` works in practice for the spec
# families we ship (telos_reno / telos_cubic / hw-cbmc fixtures).
_ASSERT_PROPERTY_RE = re.compile(
    r"""(?P<indent>^[ \t]*)
        (?P<label>[A-Za-z_][A-Za-z_0-9]*\s*:\s*)?      # optional label
        (?P<kw>assert\s+property)                       # keyword
        \s*\(
        (?P<body>.*?)                                   # body (non-greedy)
        \)\s*;
    """,
    re.MULTILINE | re.DOTALL | re.VERBOSE,
)


def splice_cycle_counter(
    spec_text: str,
    *,
    counter_name: str = "__cycle_count",
    width: int = 32,
) -> str:
    """Inject a clock-tick cycle counter before `endmodule`."""
    idx = spec_text.rfind("endmodule")
    if idx < 0:
        # ATH-845: typed exception so customers can `except
        # MalformedSystemVerilogSpec` instead of grepping the
        # message string.
        from kairos.errors import MalformedSystemVerilogSpec
        raise MalformedSystemVerilogSpec("spec has no `endmodule`")
    zero = f"{{{width}{{1'b0}}}}"
    block = (
        f"\n  // cycle-swarm counter\n"
        f"  reg [{width - 1}:0] {counter_name} = {zero};\n"
        f"  always @(posedge clk) "
        f"{counter_name} <= {counter_name} + 1;\n"
    )
    return spec_text[:idx] + block + spec_text[idx:]


def splice_cycle_gate_on_asserts(
    spec_text: str,
    cycle: int,
    *,
    counter_name: str = "__cycle_count",
) -> str:
    """Rewrite every `assert property (BODY)` as `(count == cycle) |-> BODY`.

    The state-swarm cover probe (if any) is identified by its label
    prefix `swarm_cover_probe` and left unchanged — that assertion
    checks reachability, not a cycle-gated invariant.
    """
    counter_eq = f"({counter_name} == 32'd{cycle})"

    def _rewrite(match: re.Match[str]) -> str:
        indent = match.group("indent")
        label = match.group("label") or ""
        body = match.group("body").strip()
        if "swarm_cover_probe" in label:
            return match.group(0)
        return (
            f"{indent}{label}assert property "
            f"({counter_eq} |-> ({body}));"
        )

    return _ASSERT_PROPERTY_RE.sub(_rewrite, spec_text)


def cycle_swarm(
    spec_file: str | Path,
    *,
    top_module: str,
    cycles: list[int],
    bound: int | None = None,
    timeout_sec: int = 60,
    counter_width: int = 32,
) -> CycleSwarmResult:
    """Run a cycle-swarm over the given cycle values.

    For each k in cycles: splice a `__cycle_count` register, rewrite
    every `assert property (P)` to `(__cycle_count == k) |-> P`, run
    EBMC at `bound`, collect verdicts.

    `bound` defaults to `max(cycles) + 2` so the solver has room past
    the largest requested k. Duplicate + negative cycle values are
    dropped before the run.
    """
    # ATH-686 P1: programmatic cycle_swarm entry → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    spec_path = Path(spec_file)
    if not spec_path.is_file():
        raise FileNotFoundError(f"spec file not found: {spec_path}")
    base_text = spec_path.read_text()

    seen: set[int] = set()
    cycles_norm: list[int] = []
    for c in cycles:
        if c < 0 or c in seen:
            continue
        seen.add(c)
        cycles_norm.append(c)
    cycles_norm.sort()
    if not cycles_norm:
        raise ValueError("cycles list is empty after normalisation")

    if bound is None:
        bound = max(cycles_norm) + 2

    variant_runs: list[CycleVariantRun] = []

    for k in cycles_norm:
        variant_text = splice_cycle_counter(
            base_text, counter_name="__cycle_count", width=counter_width,
        )
        variant_text = splice_cycle_gate_on_asserts(
            variant_text, cycle=k, counter_name="__cycle_count",
        )
        import tempfile
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".sv", delete=False, dir=spec_path.parent,
            prefix=f".cycleswarm_k{k}_",
        ) as tf:
            tf.write(variant_text)
            variant_path = Path(tf.name)
        try:
            r = run_ebmc(
                variant_path,
                top_module=top_module, bound=bound, timeout_sec=timeout_sec,
            )
        finally:
            variant_path.unlink(missing_ok=True)

        if r.exit_code != 0 and r.proved == 0 and r.refuted == 0 and not r.timed_out:
            variant_runs.append(CycleVariantRun(
                cycle=k,
                note=f"EBMC crashed (stderr: {r.stderr[:150]})",
            ))
            continue

        refuted_names = [
            s["name"] for s in summarize_refutations(r.stdout, max_props=16)
        ]
        variant_runs.append(CycleVariantRun(
            cycle=k, ebmc=r,
            proved=r.proved, refuted=r.refuted,
            refuted_names=refuted_names,
        ))

    total_refuted = sum(v.refuted for v in variant_runs)
    crashed = sum(1 for v in variant_runs if v.note)
    overall = "NEW_REFUTATION" if total_refuted > 0 else (
        "PARTIAL" if crashed > 0 else "CLEAN"
    )

    return CycleSwarmResult(
        spec_path=spec_path,
        top_module=top_module,
        bound=bound,
        cycles_requested=cycles_norm,
        variant_runs=variant_runs,
        overall=overall,
    )


# ─── Helpers ─────────────────────────────────────────────────────────


def _slugify(text: str) -> str:
    """Produce a filesystem-safe slug for temp filenames."""
    return re.sub(r"[^A-Za-z0-9_]", "_", text)[:40]


def _extract_full_trace_block(stdout: str) -> str:
    """Return everything from `Counterexample:` through end-of-stream.

    The shared `ebmc.extract_counterexample` cuts at the first blank
    line, which discards all but the very first trace state when EBMC
    is run with `--trace`. State-swarm needs the whole block to find
    the hit cycle, so we take the tail.
    """
    m = re.search(r"^Counterexample:", stdout, re.MULTILINE)
    if not m:
        return ""
    return stdout[m.start():]
