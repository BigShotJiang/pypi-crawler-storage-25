"""kairos.sv.flatten — flatten packed structs to bit-vectors for EBMC.

EBMC 5.x cannot parse SystemVerilog packed struct member access through
array indices (e.g. ``rob[head].valid``).  This module rewrites SV source
to replace packed struct types with plain ``logic [W-1:0]`` vectors and
all ``.field`` accesses with ``[hi:lo]`` bit slicing.

Usage::

    from kairos.sv.flatten import flatten_sv, flatten_file

    flat_src = flatten_file("rtl/cpu_pipelined.sv")
    # or
    flat_src = flatten_sv(source_text)

The transformation is mechanical and preserves simulation semantics.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FieldDef:
    name: str
    width: int
    hi: int
    lo: int


@dataclass
class StructDef:
    name: str
    fields: list[FieldDef] = field(default_factory=list)
    total_width: int = 0


_STRUCT_BLOCK_RE = re.compile(
    r"typedef\s+struct\s+packed\s*\{([^}]+)\}\s*(\w+)\s*;",
    re.DOTALL,
)

_FIELD_RE = re.compile(
    r"^\s*(?:logic|reg|wire)\s*"
    r"(?:\[(\d+):(\d+)\]\s*)?"
    r"(\w+)\s*;",
    re.MULTILINE,
)

_ENUM_FIELD_RE = re.compile(
    r"^\s*(\w+)\s+(\w+)\s*;",
    re.MULTILINE,
)


def _parse_field_width(body: str, known_enums: dict[str, int] | None = None) -> list[tuple[str, int]]:
    """Extract (field_name, width) pairs from a struct body."""
    fields = []
    for line in body.split(";"):
        line = line.strip()
        if not line:
            continue
        m = re.match(r"(?:logic|reg|wire)\s*(?:\[(\d+):(\d+)\])?\s*(\w+)", line)
        if m:
            hi = int(m.group(1)) if m.group(1) is not None else 0
            lo = int(m.group(2)) if m.group(2) is not None else 0
            width = hi - lo + 1
            fields.append((m.group(3), width))
            continue
        m2 = re.match(r"(\w+)\s+(\w+)", line)
        if m2:
            type_name = m2.group(1)
            field_name = m2.group(2)
            if known_enums and type_name in known_enums:
                fields.append((field_name, known_enums[type_name]))
            else:
                fields.append((field_name, 4))
    return fields


def parse_struct_defs(
    source: str,
    enum_widths: dict[str, int] | None = None,
) -> dict[str, StructDef]:
    """Extract all ``typedef struct packed { ... } name;`` from source."""
    structs: dict[str, StructDef] = {}
    for m in _STRUCT_BLOCK_RE.finditer(source):
        body = m.group(1)
        type_name = m.group(2)
        raw_fields = _parse_field_width(body, enum_widths)
        bit_pos = sum(w for _, w in raw_fields)
        fields = []
        for fname, fwidth in raw_fields:
            bit_pos -= fwidth
            hi = bit_pos + fwidth - 1
            lo = bit_pos
            fields.append(FieldDef(fname, fwidth, hi, lo))
        sd = StructDef(type_name, fields, sum(w for _, w in raw_fields))
        structs[type_name] = sd
    return structs


def _find_enum_widths(source: str) -> dict[str, int]:
    """Find ``typedef enum logic [N:0] { ... } name;`` and return {name: width}."""
    widths: dict[str, int] = {}
    for m in re.finditer(
        r"typedef\s+enum\s+logic\s*\[(\d+):(\d+)\]\s*\{[^}]*\}\s*(\w+)\s*;",
        source,
        re.DOTALL,
    ):
        hi, lo, name = int(m.group(1)), int(m.group(2)), m.group(3)
        widths[name] = hi - lo + 1
    return widths


def _find_balanced_bracket(text: str, start: int) -> int:
    """Find the closing ] matching the [ at position start."""
    depth = 0
    i = start
    while i < len(text):
        if text[i] == "[":
            depth += 1
        elif text[i] == "]":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def _build_var_type_map(
    source: str,
    structs: dict[str, StructDef],
) -> dict[str, str]:
    """Scan declarations to find which variables have struct types."""
    var_map: dict[str, str] = {}
    for sname in structs:
        for m in re.finditer(
            rf"\b{re.escape(sname)}\s+(\w+)\s*(?:\[|;|,)",
            source,
        ):
            var_map[m.group(1)] = sname
    return var_map


def _slice_expr(fd: FieldDef) -> str:
    if fd.hi == fd.lo:
        return f"[{fd.hi}]"
    return f"[{fd.hi}:{fd.lo}]"


def flatten_sv(
    source: str,
    extra_enum_widths: dict[str, int] | None = None,
    extra_structs: dict[str, StructDef] | None = None,
) -> str:
    """Rewrite SV source replacing packed structs with bit-vectors.

    Args:
        source: SystemVerilog source text.
        extra_enum_widths: enum type widths from other files (e.g. packages).
        extra_structs: struct definitions from other files. Merged with
            any structs found in this source. Use this when struct types
            are defined in a package file but used in a different file.
    """
    enum_widths = _find_enum_widths(source)
    if extra_enum_widths:
        enum_widths.update(extra_enum_widths)

    structs = parse_struct_defs(source, enum_widths)
    if extra_structs:
        for k, v in extra_structs.items():
            structs.setdefault(k, v)
    if not structs:
        return source

    var_map = _build_var_type_map(source, structs)
    out = source

    # 1. Remove struct typedef blocks
    out = _STRUCT_BLOCK_RE.sub(lambda m: f"// [flattened] {m.group(2)} removed", out)

    # 2. Replace declarations: `type_name var [SIZE];` → `logic [W-1:0] var [SIZE];`
    #    and `type_name var;` → `logic [W-1:0] var;`
    for sname, sd in structs.items():
        w = sd.total_width
        out = re.sub(
            rf"\b{re.escape(sname)}\b(\s+)(\w+)(\s*\[[^\]]*\]\s*(?:\[[^\]]*\]\s*)*;)",
            rf"logic [{w-1}:0]\1\2\3",
            out,
        )
        out = re.sub(
            rf"\b{re.escape(sname)}\b(\s+)(\w+)(\s*;)",
            rf"logic [{w-1}:0]\1\2\3",
            out,
        )

    # 2b. ATH-973: Replace struct types in port lists. Yosys 0.44 cannot
    #     parse `input packet_t x` in port lists; replace with
    #     `input logic [W-1:0] x` per asabi 2026-05-04.
    #     Pattern: `<input|output|inout>  <struct_type>  <name>(,|)|;)
    for sname, sd in structs.items():
        w = sd.total_width
        out = re.sub(
            rf"(input|output|inout)(\s+)(?:logic\s+)?{re.escape(sname)}(\s+)(\w+)",
            rf"\1\2logic [{w-1}:0]\3\4",
            out,
        )

    # 2c. ATH-974: Replace struct types in local wire/reg comma-list
    #     declarations. Yosys 0.44 cannot parse `packet_t f1_out, f2_out;`
    #     even though it accepts the single-var form. Existing step 2
    #     handles `packet_t var;` (single-var); this handles the
    #     comma-list form by replacing the type prefix.
    for sname, sd in structs.items():
        w = sd.total_width
        # Match `packet_t  ident, ident, ...;` with multiple identifiers.
        # Replace just the type with `logic [W-1:0]`.
        out = re.sub(
            rf"\b{re.escape(sname)}(\s+\w+(?:\s*,\s*\w+)+\s*;)",
            rf"logic [{w-1}:0]\1",
            out,
        )

    # 2d. ATH-974: Strip instance type-parameter bindings.
    #     `fifo_widget #(.packet_t(packet_t), .DEPTH(4))` → `fifo_widget #(.DEPTH(4))`.
    #     The corresponding `parameter type packet_t = ...` was already
    #     stripped by strip_type_parameters; the binding is now an unbound
    #     parameter reference yosys can't resolve.
    for sname in structs:
        # Match `.packet_t(packet_t)` with optional trailing comma + space.
        # Three patterns: comma-after, comma-before (last item), and
        # only-binding (no commas).
        out = re.sub(
            rf"\.{re.escape(sname)}\s*\(\s*\w+\s*\)\s*,\s*",
            "",
            out,
        )
        out = re.sub(
            rf",\s*\.{re.escape(sname)}\s*\(\s*\w+\s*\)",
            "",
            out,
        )
        # Only binding: `#(.packet_t(packet_t))` → `#()`.
        # Drop the binding entirely since the parameter was stripped.
        out = re.sub(
            rf"#\s*\(\s*\.{re.escape(sname)}\s*\(\s*\w+\s*\)\s*\)",
            "",
            out,
        )

    # 3. Remove type casts: `type_name'(expr)` → `(expr)`
    for sname in structs:
        out = re.sub(rf"\b{re.escape(sname)}\s*'\s*\(", "(", out)

    # 4. Replace member accesses
    # We do this iteratively since we need to handle nested struct field
    # accesses as array indices (e.g. shadow_map[d_instr[di].rd])
    # Process from innermost outward by repeating until stable.
    for _pass in range(5):
        prev = out
        out = _replace_member_accesses(out, structs, var_map)
        if out == prev:
            break

    # 5. Unroll generate-for blocks with labeled assertions (EBMC limitation)
    out = _unroll_generate_for(out)

    # 6. Strip `automatic` keyword and hoist procedural variable
    #    declarations to module level — EBMC crashes on variable
    #    declarations inside procedural begin/end blocks
    out = _hoist_procedural_vars(out)

    # 7. Rename loop vars that appear in both always_comb and always_ff
    #    (EBMC: "conflicting assignment types") — BEFORE dedup so dedup
    #    sees the renamed vars
    out = _rename_comb_loop_vars(out)

    # 8. Deduplicate for-loop variable declarations (EBMC limitation)
    #    Runs AFTER rename so first `int i` in always_ff is preserved
    out = _dedup_loop_vars(out)

    # 9. Split dynamic for-loop guards so EBMC can statically evaluate
    #    the iteration count. Convert `for (v=0; v<N && GUARD; v++)`
    #    into `for (v=0; v<N; v++) if (GUARD)` and replace `break`
    #    with a skip flag.
    out = _split_dynamic_loop_guards(out)

    # 10. Rewrite SVA temporal operators to register-based equivalents.
    #     EBMC 5.x k-induction crashes on $rose, $fell, $changed, $stable,
    #     $past, and ##N delay operators inside assume/assert properties.
    out = _rewrite_sva_temporal(out)

    return out


def _replace_member_accesses(
    source: str,
    structs: dict[str, StructDef],
    var_map: dict[str, str],
) -> str:
    """Single pass: replace var.field and var[idx].field with bit slicing."""
    result = []
    i = 0
    n = len(source)

    while i < n:
        matched = False
        for vname, sname in var_map.items():
            sd = structs[sname]
            if not source[i:].startswith(vname):
                i_next = i
                continue
            vlen = len(vname)
            if i + vlen >= n:
                continue
            # Check word boundary before
            if i > 0 and (source[i - 1].isalnum() or source[i - 1] == "_"):
                continue
            j = i + vlen
            # Check word boundary after — next char must be [ or .
            if j >= n or source[j] not in "[.":
                continue

            # Case A: var[idx].field
            if source[j] == "[":
                bracket_end = _find_balanced_bracket(source, j)
                if bracket_end < 0:
                    continue
                idx_expr = source[j : bracket_end + 1]
                k = bracket_end + 1
                if k < n and source[k] == ".":
                    field_m = re.match(r"\.(\w+)", source[k:])
                    if field_m:
                        fname = field_m.group(1)
                        fd = _find_field(sd, fname)
                        if fd:
                            result.append(source[i:j])
                            result.append(idx_expr)
                            result.append(_slice_expr(fd))
                            i = k + field_m.end()
                            matched = True
                            break
                # array access without .field — pass through
                continue

            # Case B: var.field
            if source[j] == ".":
                field_m = re.match(r"\.(\w+)", source[j:])
                if field_m:
                    fname = field_m.group(1)
                    fd = _find_field(sd, fname)
                    if fd:
                        result.append(vname)
                        result.append(_slice_expr(fd))
                        i = j + field_m.end()
                        matched = True
                        break

        if not matched:
            result.append(source[i])
            i += 1

    return "".join(result)


def _dedup_loop_vars(source: str) -> str:
    """EBMC scopes for-loop variable declarations at module level.

    When multiple for-loops declare ``for (int i ...)``, EBMC errors
    with "variable 'i' is already declared."  Fix: within each module,
    keep only the first ``int`` declaration per variable name and strip
    it from subsequent for-loop headers.
    """
    for_decl_re = re.compile(r"\bfor\s*\(\s*int\s+(\w+)\s*=")
    # Also handle `integer di;` style declarations
    int_decl_re = re.compile(r"^\s*integer\s+(\w+)\s*;")
    module_re = re.compile(r"^\s*module\b")

    lines = source.split("\n")
    out_lines: list[str] = []
    seen_vars: set[str] = set()

    for line in lines:
        if module_re.match(line):
            seen_vars = set()

        # Track integer declarations
        m_int = int_decl_re.match(line)
        if m_int:
            seen_vars.add(m_int.group(1))

        m = for_decl_re.search(line)
        if m:
            varname = m.group(1)
            if varname in seen_vars:
                line = re.sub(
                    r"\bfor\s*\(\s*int\s+" + re.escape(varname) + r"\s*=",
                    f"for ({varname} =",
                    line,
                    count=1,
                )
            else:
                seen_vars.add(varname)

        out_lines.append(line)

    return "\n".join(out_lines)


def _hoist_procedural_vars(source: str) -> str:
    """Hoist variable declarations out of always blocks to module level.

    EBMC cannot handle variable declarations inside procedural blocks.
    This pass:
    1. Strips the ``automatic`` keyword
    2. Finds ``logic``/``reg`` declarations inside always blocks
    3. Moves declarations to just before the always block
    4. Converts initializers to assignments at the original location
    5. Removes bare ``begin/end`` blocks that existed only for scoping
    """
    source = re.sub(r"\bautomatic\s+", "", source)

    lines = source.split("\n")
    out_lines: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Detect always block start
        if re.match(r"\s*always_ff\b|always_comb\b|always\b", stripped):
            # Scan the always block to find its extent and extract declarations
            block_start = i
            depth = 0
            block_end = i
            decl_lines: list[str] = []
            modified_block: list[str] = []
            found_begin = False

            for j in range(i, len(lines)):
                bline = lines[j]
                bstripped = bline.strip()
                depth += bline.count("begin") - bline.count("end")

                if "begin" in bline:
                    found_begin = True

                # Check for variable declarations inside the block
                if j > i and found_begin:
                    decl_match = re.match(
                        r"(\s*)(?:logic|reg)\s*(\[[\d:]+\])?\s*(\w+)"
                        r"(\s*\[[\w\d:]+\])?\s*(=\s*[^;]+)?\s*;",
                        bline,
                    )
                    if decl_match:
                        indent = decl_match.group(1)
                        width = decl_match.group(2) or ""
                        vname = decl_match.group(3)
                        arr = decl_match.group(4) or ""
                        init = decl_match.group(5)

                        if width:
                            decl_lines.append(f"  logic {width} {vname}{arr};")
                        else:
                            decl_lines.append(f"  logic {vname}{arr};")

                        if init:
                            modified_block.append(f"{indent}{vname} {init};")
                        else:
                            modified_block.append("")
                        if j >= len(lines) - 1 or depth <= 0:
                            block_end = j
                            break
                        continue

                modified_block.append(bline)

                if depth <= 0 and j > i and found_begin:
                    block_end = j
                    break

            # Insert declarations before the always block
            for d in decl_lines:
                out_lines.append(d)

            out_lines.extend(modified_block)
            i = block_end + 1
        else:
            out_lines.append(line)
            i += 1

    # Remove bare begin/end blocks (not preceded by control statements)
    result = "\n".join(out_lines)
    # A bare begin is one where the previous non-whitespace line doesn't
    # end with ) or have if/for/case/else
    # Simpler approach: just remove standalone `begin` lines that follow
    # assignment or declaration lines
    result_lines = result.split("\n")
    final_lines: list[str] = []
    skip_matching_end: list[int] = []
    depth_track = 0

    for idx, line in enumerate(result_lines):
        stripped = line.strip()

        if stripped == "begin" and idx > 0:
            prev = result_lines[idx - 1].strip()
            if not re.search(r"\b(if|else|for|case|while)\b", prev) and not prev.endswith(")"):
                skip_matching_end.append(depth_track)
                depth_track += 1
                continue

        depth_track += line.count("begin") - line.count("end")

        if stripped == "end" and skip_matching_end and depth_track <= skip_matching_end[-1]:
            skip_matching_end.pop()
            continue

        final_lines.append(line)

    return "\n".join(final_lines)


def _rewrite_sva_temporal(source: str) -> str:
    """Rewrite SVA temporal operators to register-based equivalents.

    EBMC 5.x k-induction crashes on temporal operators inside
    assume/assert property blocks. This pass rewrites:
    - ``$rose(x)`` → ``(!_past_x && x)`` + register declaration
    - ``$fell(x)`` → ``(_past_x && !x)``
    - ``$stable(x)`` → ``(x == _past_x)``
    - ``$changed(x)`` → ``(x != _past_x)``
    - ``$past(x)`` → ``_past_x``
    - ``##1 expr`` → one-cycle-delayed register

    For each rewritten signal, a ``logic _past_<sig>`` register and
    corresponding ``always_ff`` block are inserted after the module
    port list.
    """
    past_regs: dict[str, str] = {}
    counter = [0]

    def _past_reg_name(sig: str) -> str:
        clean = re.sub(r"[^a-zA-Z0-9_]", "_", sig)
        name = f"_ebmc_past_{clean}"
        if name not in past_regs:
            past_regs[name] = sig
        return name

    def _rewrite_rose(m: re.Match) -> str:
        sig = m.group(1)
        preg = _past_reg_name(sig)
        return f"(!{preg} && {sig})"

    def _rewrite_fell(m: re.Match) -> str:
        sig = m.group(1)
        preg = _past_reg_name(sig)
        return f"({preg} && !{sig})"

    def _rewrite_stable(m: re.Match) -> str:
        sig = m.group(1)
        preg = _past_reg_name(sig)
        return f"({sig} == {preg})"

    def _rewrite_changed(m: re.Match) -> str:
        sig = m.group(1)
        preg = _past_reg_name(sig)
        return f"({sig} != {preg})"

    def _rewrite_past(m: re.Match) -> str:
        sig = m.group(1)
        return _past_reg_name(sig)

    out = source

    out = re.sub(r"\$rose\s*\(\s*([^)]+)\s*\)", _rewrite_rose, out)
    out = re.sub(r"\$fell\s*\(\s*([^)]+)\s*\)", _rewrite_fell, out)
    out = re.sub(r"\$stable\s*\(\s*([^)]+)\s*\)", _rewrite_stable, out)
    out = re.sub(r"\$changed\s*\(\s*([^)]+)\s*\)", _rewrite_changed, out)
    out = re.sub(r"\$past\s*\(\s*([^)]+)\s*\)", _rewrite_past, out)

    # Rewrite ##1 delay in property sequences:
    # ``expr |-> ##1 consequent`` → ``expr |-> _delayed_consequent``
    # This is a best-effort rewrite for simple single-delay patterns.
    delay_regs: dict[str, str] = {}

    def _rewrite_delay(m: re.Match) -> str:
        expr = m.group(1).strip()
        clean = re.sub(r"[^a-zA-Z0-9_]", "_", expr)
        name = f"_ebmc_delay1_{clean}"
        delay_regs[name] = expr
        return name

    out = re.sub(r"##1\s+(\w+(?:\s*&&\s*\w+)*)", _rewrite_delay, out)

    if not past_regs and not delay_regs:
        return out

    # Insert register declarations and always_ff block after port list
    decls = []
    ff_body = []

    for preg, sig in sorted(past_regs.items()):
        decls.append(f"  logic {preg};")
        ff_body.append(f"    {preg} <= {sig};")

    for dreg, expr in sorted(delay_regs.items()):
        decls.append(f"  logic {dreg};")
        ff_body.append(f"    {dreg} <= {expr};")

    insert = "\n".join(decls)
    if ff_body:
        insert += "\n  always_ff @(posedge clk) begin\n"
        insert += "    if (!rst_n) begin\n"
        for preg in sorted(list(past_regs.keys()) + list(delay_regs.keys())):
            insert += f"      {preg} <= '0;\n"
        insert += "    end else begin\n"
        insert += "\n".join(f"  {line}" for line in ff_body) + "\n"
        insert += "    end\n"
        insert += "  end\n"

    out = re.sub(
        r"(\)\s*;)",
        rf"\1\n{insert}",
        out,
        count=1,
    )

    return out


def _split_dynamic_loop_guards(source: str) -> str:
    """Convert ``for (v=S; v<N && GUARD; v++)`` to static-bound loops.

    EBMC can only synthesize loops with statically-evaluable bounds.
    This pass finds for-loops with mixed static/dynamic guards, splits
    them so the static bound stays in the for-header and the dynamic
    condition moves into the loop body as an if-guard.
    """
    pattern = re.compile(
        r"^(\s*)for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*(\d+)\s*;\s*"
        r"\2\s*<\s*(\w+)\s*&&\s*(.+?)\s*;\s*\2\s*\+\+\s*\)\s*begin\s*$"
    )

    lines = source.split("\n")
    out: list[str] = []
    skip_var_name: str | None = None
    in_rewritten_loop = False
    loop_depth = 0

    for line in lines:
        m = pattern.match(line)
        if m:
            indent = m.group(1)
            varname = m.group(2)
            start = m.group(3)
            limit = m.group(4)
            dynamic = m.group(5).strip()
            skip_var_name = f"_skip_loop_{varname}"
            out.append(f"{indent}{skip_var_name} = 0;")
            out.append(f"{indent}for ({varname} = {start}; {varname} < {limit}; {varname}++) begin")
            out.append(f"{indent}  if ({dynamic} && !{skip_var_name}) begin")
            in_rewritten_loop = True
            loop_depth = 1
            continue

        if in_rewritten_loop:
            stripped = line.strip()
            if stripped == "break;":
                indent = re.match(r"(\s*)", line).group(1)
                out.append(f"{indent}{skip_var_name} = 1;")
                continue
            loop_depth += line.count("begin") - line.count("end")
            if loop_depth <= 0:
                indent = re.match(r"(\s*)", line).group(1)
                out.append(f"{indent}end  // if guard")
                out.append(line)  # the original `end` for the for loop
                in_rewritten_loop = False
                skip_var_name = None
                continue

        out.append(line)

    # Declare the skip variables after the module port list
    result = "\n".join(out)
    skip_vars = set(re.findall(r"\b(_skip_loop_\w+)\b", result))
    if skip_vars:
        decls = "\n".join(f"  logic {sv};" for sv in sorted(skip_vars))
        # Insert after the first `);` that closes the port list
        result = re.sub(
            r"(\)\s*;)",
            rf"\1\n{decls}",
            result,
            count=1,
        )

    return result


def _rename_comb_loop_vars(source: str) -> str:
    """Rename loop variables in always_comb that collide with always_ff.

    EBMC errors with "conflicting assignment types" when a variable is
    assigned in both combinational and clocked blocks.  Rename the
    always_comb loop vars with a ``c_`` prefix.
    """
    lines = source.split("\n")
    out_lines: list[str] = []
    in_comb = False
    comb_depth = 0
    ff_vars: set[str] = set()
    comb_vars: set[str] = set()

    for_decl_re = re.compile(r"\bfor\s*\(\s*(?:int\s+)?(\w+)\s*=")

    # First pass: collect vars from always_ff blocks
    in_ff = False
    ff_depth = 0
    for line in lines:
        stripped = line.strip()
        if re.match(r"always_ff\b", stripped):
            in_ff = True
            ff_depth = 0
        if in_ff:
            ff_depth += line.count("begin") - line.count("end")
            m = for_decl_re.search(line)
            if m:
                ff_vars.add(m.group(1))
            if ff_depth <= 0 and "end" in stripped and ff_depth <= 0:
                in_ff = False

    # Second pass: collect always_comb blocks, rename colliding vars
    in_comb = False
    comb_depth = 0
    comb_start = -1
    comb_collisions: set[str] = set()

    for idx, line in enumerate(lines):
        stripped = line.strip()
        if re.match(r"always_comb\b", stripped):
            in_comb = True
            comb_depth = 0
            comb_start = idx
            comb_collisions = set()
            m = for_decl_re.search(line)
            if m and m.group(1) in ff_vars:
                comb_collisions.add(m.group(1))

        elif in_comb:
            comb_depth += line.count("begin") - line.count("end")
            m = for_decl_re.search(line)
            if m and m.group(1) in ff_vars:
                comb_collisions.add(m.group(1))

            if comb_depth <= 0 and "end" in stripped:
                # End of always_comb — do the renaming
                if comb_collisions:
                    for j in range(comb_start, idx + 1):
                        for old_var in comb_collisions:
                            new_var = f"c_{old_var}"
                            lines[j] = re.sub(
                                rf"\b{re.escape(old_var)}\b", new_var, lines[j]
                            )
                in_comb = False

    return "\n".join(lines)


def _unroll_generate_for(source: str) -> str:
    """Unroll ``generate for (gi = 0; gi < N; gi++)`` blocks.

    EBMC 5.x cannot handle labeled assertions/assumptions inside
    generate-for blocks (reports "identifier already used").  This pass
    finds small generate-for loops over known parameters and unrolls
    them into explicit copies with unique labels.
    """
    # Match genvar + generate-for pattern
    pattern = re.compile(
        r"genvar\s+(\w+)\s*;\s*\n"
        r"\s*generate\s*\n"
        r"\s*for\s*\(\s*\1\s*=\s*(\d+)\s*;\s*\1\s*<\s*(\w+)\s*;\s*\1\s*\+\+\s*\)\s*"
        r"begin\s*:\s*(\w+)\s*\n"
        r"(.*?)\n"
        r"\s*end\s*\n"
        r"\s*endgenerate",
        re.DOTALL,
    )

    known_params = {
        "IMEM_DEPTH": 32,
        "NUM_GPRS": 16,
    }

    def _expand(m: re.Match) -> str:
        gvar = m.group(1)
        start = int(m.group(2))
        limit_name = m.group(3)
        block_label = m.group(4)
        body = m.group(5)

        if limit_name.isdigit():
            limit = int(limit_name)
        elif limit_name in known_params:
            limit = known_params[limit_name]
        else:
            return m.group(0)  # can't resolve — leave unchanged

        lines = []
        for idx in range(start, limit):
            expanded = body.replace(gvar, str(idx))
            # Make labels unique by appending index
            expanded = re.sub(
                r"(\w+)\s*:\s*(assume|assert|cover)\b",
                rf"\1_{idx}: \2",
                expanded,
            )
            lines.append(expanded)
        return "\n".join(lines)

    return pattern.sub(_expand, source)


def _find_field(sd: StructDef, name: str) -> FieldDef | None:
    for f in sd.fields:
        if f.name == name:
            return f
    return None


def strip_type_parameters(source: str) -> str:
    """Strip `parameter type T = X` declarations and substitute T with X.

    ATH-972: Yosys 0.44 cannot parse type-parameterized modules. Replace
    each ``parameter type T = packet_t`` with the concrete type and remove
    the parameter line. Also fixes the trailing-comma case in the
    parameter list.
    """
    type_param_re = re.compile(
        r"^[ \t]*parameter\s+type\s+(\w+)\s*=\s*(\w+)\s*,?\s*$",
        re.MULTILINE,
    )
    substitutions: list[tuple[str, str]] = []
    for m in type_param_re.finditer(source):
        substitutions.append((m.group(1), m.group(2)))

    # Remove the parameter declarations (after collecting the substitutions).
    out = type_param_re.sub("", source)

    # Substitute T → packet_t everywhere (word-bounded to avoid false hits).
    for type_name, concrete in substitutions:
        out = re.sub(rf"\b{re.escape(type_name)}\b", concrete, out)

    # Fix dangling-comma in parameter lists: `parameter int X = 4,\n)(`
    out = re.sub(r",(\s*)\)(\s*)\(", r"\1)\2(", out)

    return out


def inline_functions_returning_struct(source: str, structs: dict[str, "StructDef"]) -> str:
    """Replace function-returns-struct with continuous-assign per-field.

    ATH-972: Yosys 0.44 cannot parse `function packet_t add_header(...);
    packet_t result; ... return result; endfunction`. Replace each such
    function with no-op (declarations stripped) and substitute callsites
    with the inlined per-field expression.

    For Phase 1.5 minimum: drop the function body entirely + drop callsites.
    Customers using the discharge pipeline will need to extract the function
    semantics into the Clash gate. Phase 2 (Lean→Clash) makes this automatic
    via lean_extractor.
    """
    # Find `function [automatic] <return_type> <name>(...);  ...  endfunction`
    # blocks where return_type is a struct type. Drop them. Handles the SV
    # `automatic` modifier (caught by Phase 1.6 toy_fifo discharge run).
    func_re = re.compile(
        r"function\s+(?:automatic\s+)?(\w+)\s+(\w+)\s*\([^)]*\)\s*;.*?endfunction",
        re.DOTALL,
    )
    out = source
    removed_funcs: list[tuple[str, int]] = []  # (name, return_type_width)
    for m in func_re.finditer(source):
        return_type = m.group(1)
        if return_type in structs:
            fname = m.group(2)
            removed_funcs.append((fname, structs[return_type].total_width))
            out = out.replace(m.group(0), f"// [flattened] function {fname} returning struct {return_type} removed")

    # Replace callsites of removed functions with a 0-width stub literal
    # of the right width so the consuming context still type-checks.
    # ATH-974: foo(a, b) → '0 (zero literal of correct width via concat).
    for fname, width in removed_funcs:
        # Match `fname(<args>)` — args may contain commas + nested calls,
        # but the toy SV uses simple identifier args. Conservative match:
        out = re.sub(
            rf"\b{re.escape(fname)}\s*\([^)]*\)",
            f"{{{width}{{1'b0}}}}",
            out,
        )

    return out


def flatten_file(path: str | Path) -> str:
    """Read a file and return flattened source.

    ATH-972: also runs strip_type_parameters + inline_functions_returning_struct
    so the output is yosys-0.44-parseable for the EQY discharge pipeline.
    """
    src = Path(path).read_text()
    src = strip_type_parameters(src)
    structs = parse_struct_defs(src, _find_enum_widths(src))
    if structs:
        src = inline_functions_returning_struct(src, structs)
    return flatten_sv(src)


def flatten_files(
    paths: list[str | Path],
    output_dir: str | Path | None = None,
) -> dict[str, str]:
    """Flatten multiple files, sharing struct definitions across them.

    When files share struct types via a package (like cpu_pkg.sv), call
    this to parse all struct defs from all files first, then apply
    flattening consistently.

    Returns {filename: flattened_source}.  When output_dir is set,
    also writes flattened files there.
    """
    combined = "\n".join(Path(p).read_text() for p in paths)
    enum_widths = _find_enum_widths(combined)
    all_structs = parse_struct_defs(combined, enum_widths)

    results: dict[str, str] = {}
    for p in paths:
        p = Path(p)
        flat = flatten_sv(p.read_text(), enum_widths, all_structs)
        results[p.name] = flat

        if output_dir:
            out_path = Path(output_dir) / p.name
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(flat)

    return results
