"""solve/shared/verilog/ebmc_wrapper.py — thin wrapper around the ebmc CLI.

Generic over hw-cbmc / any EBMC-driven env. Run `ebmc <source>
--bound <N> --module <top>`, parse the `[name] ... : PROVED/REFUTED`
lines out of stdout, and structure the result for downstream phases.

This file mirrors the parsing logic in
`hw-cbmc/root_data/eval/scoring.py::_run_ebmc` so agent-side runs see
the same PROVED/REFUTED counts the scorer will eventually see. If the
scoring regex changes in hw-cbmc, update `EBMC_PROVED_RE` and
`EBMC_REFUTED_RE` here in lock-step.

NOT tied to solve/sysverilog specifically. Any vertical that solves
EBMC tasks (SystemVerilog, NuSMV, or future SVA-only tasks) can import
this module.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


# Regex patterns kept in sync with hw-cbmc/root_data/eval/scoring.py.
# The scorer uses re.IGNORECASE; we match that here.
EBMC_PROVED_RE = re.compile(r":\s*PROVED\b", re.IGNORECASE)
EBMC_REFUTED_RE = re.compile(r":\s*(?:REFUTED|FAILED)\b", re.IGNORECASE)
# Per-property result line, emitted as:
#     [module.name] always (...): PROVED up to bound N
# We capture the name and the verdict for counterexample attribution.
EBMC_PROPERTY_LINE_RE = re.compile(
    r"\[([A-Za-z0-9_.]+)\]\s+.*?:\s*(PROVED|REFUTED|FAILED|UNKNOWN)",
    re.IGNORECASE,
)
EBMC_COVER_LINE_RE = re.compile(
    r"\[([A-Za-z0-9_.]+)\]\s+cover\b",
    re.IGNORECASE,
)


@dataclass
class EbmcResult:
    """Structured outcome from a single `ebmc` invocation."""

    exit_code: int
    proved: int
    refuted: int
    timed_out: bool
    stdout: str
    stderr: str
    elapsed_sec: float = 0.0
    property_verdicts: dict[str, str] | None = None
    cover_properties: set[str] | None = None

    @property
    def total(self) -> int:
        return self.proved + self.refuted

    @property
    def proved_fraction(self) -> float:
        total = self.total
        if total <= 0:
            return 0.0
        return self.proved / total

    # ── ATH-387 proof provenance surface ────────────────────────────
    #
    # Customer CI wants reproducible artifacts. Three convenience
    # surfaces on top of the already-captured EBMC output:

    @property
    def transcript(self) -> str:
        """The full EBMC stdout — same bytes the scorer parses.

        Semantic alias for `stdout`; customers writing CI harnesses prefer
        the `verdict.transcript` spelling over `verdict.stdout`.
        """
        return self.stdout

    @property
    def counterexample(self) -> str | None:
        """The first counterexample trace from EBMC, or None if not refuted.

        Returns the raw EBMC counterexample block (value assignments +
        trace). Customers can feed this back to a fix-loop, embed it
        verbatim in a bug report, or diff it across runs.
        """
        return extract_counterexample(self.stdout)

    def refutation_summary(self, max_props: int = 8) -> list[dict]:
        """Structured per-property refutations, up to `max_props` entries.

        Each entry: `{"property": str, "verdict": str, "line": str}`.
        Empty list if nothing was refuted. See `summarize_refutations`
        for the full signature.
        """
        return summarize_refutations(self.stdout, max_props=max_props)


def _common_parent(paths: list[Path]) -> Path:
    """Return the deepest common ancestor directory of all paths."""
    if len(paths) == 1:
        return paths[0].parent
    parts = [p.parts for p in paths]
    common: list[str] = []
    for level in zip(*parts):
        if len(set(level)) == 1:
            common.append(level[0])
        else:
            break
    return Path(*common) if common else Path("/")


def run_ebmc(
    sv_file: "str | Path | list[str | Path]",
    *,
    top_module: str = "",
    bound: int = 10,
    mode: str = "bmc",
    reset_expr: str | None = None,
    timeout_sec: int = 60,
    extra_args: list[str] | None = None,
    filelist: "str | Path | None" = None,
    flatten: bool = False,
) -> EbmcResult:
    """Invoke the `ebmc` binary and return a structured EbmcResult.

    Args:
        sv_file: path(s) to SystemVerilog or NuSMV source files. Pass a
            single path for simple cases, or a list of paths for
            multi-file packages. All paths are resolved to absolute.
        top_module: if set, passed as `--module <top>`. Empty string
            means let ebmc figure it out (rare; most configs set it).
        bound: bounded model check depth. Passed as `--bound <N>`.
            hw-cbmc configs use 10-20 typically.
        mode: proof engine. ``"bmc"`` (default) → plain bounded model
            checking; ``"k_induction"`` → adds ``--k-induction`` so a
            PROVED verdict is unbounded (property holds for all
            reachable states), not just up to ``bound``.
        reset_expr: reset signal expression passed to EBMC's
            ``--reset <expr>`` flag. Defaults to None (no flag → EBMC
            considers every initial state). Pass the module's reset
            signal name when verifying invariants that only hold from
            reset (e.g., ``"reset"``, ``"rst"``, ``"rst_n"``).
        timeout_sec: hard wall timeout on the subprocess call.
        extra_args: optional list of extra CLI args appended verbatim.
            Useful for defines (``["+define+TOY_CPU_ASSERT"]``) or
            include paths (``["-I", "/path/to/includes"]``).
        filelist: path to an EBMC-style filelist (one source file per
            line). When set, passed as the positional source and all
            files listed within are compiled. ``sv_file`` is still
            accepted alongside for the primary source / top-level file.

    Returns:
        EbmcResult with exit_code, proved/refuted counts, and the per-
        property verdicts map.
    """
    import time

    valid_modes = ("bmc", "k_induction", "ic3", "bdd",
                    "liveness", "liveness_buechi", "liveness_ranking")
    if mode not in valid_modes:
        raise ValueError(f"unknown ebmc mode: {mode!r} (expected one of {valid_modes})")

    # Normalise sv_file to a list of resolved Paths.
    if isinstance(sv_file, (str, Path)):
        sv_paths = [Path(sv_file).resolve()]
    else:
        sv_paths = [Path(f).resolve() for f in sv_file]
    if not sv_paths and filelist is None:
        raise ValueError("run_ebmc requires at least one sv_file or a filelist")

    filelist_path = Path(filelist).resolve() if filelist else None

    if flatten:
        import tempfile
        from kairos.sv.flatten import flatten_files as _flatten_files
        flat_dir = Path(tempfile.mkdtemp(prefix="kairos_flat_"))
        _flatten_files(sv_paths, output_dir=flat_dir)
        sv_paths = [flat_dir / p.name for p in sv_paths]

    host_ebmc = shutil.which("ebmc")
    image = os.environ.get("EBMC_DOCKER_IMAGE", "hw-cbmc:latest")

    engine_flags: list[str] = []
    if mode == "k_induction":
        engine_flags.append("--k-induction")
    elif mode == "ic3":
        engine_flags.append("--ic3")
    elif mode == "bdd":
        engine_flags.append("--bdd")
    elif mode == "liveness":
        engine_flags.append("--liveness-to-safety")
    elif mode == "liveness_buechi":
        engine_flags.append("--buechi")
    elif mode == "liveness_ranking":
        engine_flags.append("--ranking-function")
    if reset_expr is not None:
        engine_flags += ["--reset", reset_expr]

    if host_ebmc:
        cmd = ["ebmc"] + [str(p) for p in sv_paths] + ["--bound", str(bound)]
        if filelist_path:
            cmd += ["-f", str(filelist_path)]
        cmd += engine_flags
        if top_module:
            cmd += ["--module", top_module]
        if extra_args:
            cmd += list(extra_args)
    else:
        # For Docker, mount the common ancestor of all source files so
        # every path resolves inside the container.
        all_paths = list(sv_paths)
        if filelist_path:
            all_paths.append(filelist_path)
        mount_dir = _common_parent(all_paths)
        container_sources = [f"/work/{p.relative_to(mount_dir)}" for p in sv_paths]
        cmd = [
            "docker", "run", "--rm",
            "--network=none",
            "-v", f"{mount_dir}:/work:ro",
            image,
            "ebmc",
        ] + container_sources + ["--bound", str(bound)]
        if filelist_path:
            cmd += ["-f", f"/work/{filelist_path.relative_to(mount_dir)}"]
        cmd += engine_flags
        if top_module:
            cmd += ["--module", top_module]
        if extra_args:
            cmd += list(extra_args)

    t0 = time.monotonic()
    try:
        # cmd is the list-form [ebmc_bin, source_paths..., flags...]
        # built internally — paths come from the SV verticals' vetted
        # source dirs, not user-supplied. env-allowlist hardening at
        # the eval_harness layer (ATH-1212a + ATH-1230).
        res = subprocess.run(
            cmd,  # nosemgrep
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
        elapsed = time.monotonic() - t0
        stdout = res.stdout or ""
        stderr = res.stderr or ""
        exit_code = res.returncode
        timed_out = False
    except subprocess.TimeoutExpired:
        return EbmcResult(
            exit_code=-1,
            proved=0,
            refuted=0,
            timed_out=True,
            stdout="",
            stderr=f"EBMC timed out after {timeout_sec}s",
            elapsed_sec=float(timeout_sec),
            property_verdicts={},
        )
    except FileNotFoundError as e:
        which = "docker" if not host_ebmc else "ebmc"
        return EbmcResult(
            exit_code=-1,
            proved=0,
            refuted=0,
            timed_out=False,
            stdout="",
            stderr=f"{which} binary not found: {e}",
            elapsed_sec=0.0,
            property_verdicts={},
        )

    # Detect OS-level kills (SIGTERM=15, SIGKILL=9) as timeouts.
    # subprocess.TimeoutExpired only fires for Python-level timeouts;
    # when the OS or a parent process kills EBMC, we get a negative
    # exit code (-signal) or 128+signal.
    if exit_code in (-15, -9, 137, 143) or (exit_code < 0 and not stdout):
        timed_out = True

    proved = len(EBMC_PROVED_RE.findall(stdout))
    refuted = len(EBMC_REFUTED_RE.findall(stdout))
    verdicts: dict[str, str] = {}
    for m in EBMC_PROPERTY_LINE_RE.finditer(stdout):
        verdicts[m.group(1)] = m.group(2).upper()
    covers: set[str] = set()
    for m in EBMC_COVER_LINE_RE.finditer(stdout):
        covers.add(m.group(1))

    return EbmcResult(
        exit_code=exit_code,
        proved=proved,
        refuted=refuted,
        timed_out=timed_out,
        stdout=stdout,
        stderr=stderr,
        elapsed_sec=round(elapsed, 3),
        property_verdicts=verdicts,
        cover_properties=covers if covers else None,
    )


# ── Counterexample extraction ────────────────────────────────────────

# EBMC counterexamples begin with a "Counterexample:" header and
# interleave cycle numbers with signal=value lines. We don't parse each
# cycle (the prompt can feed the raw block to the LLM — that's what
# hw-cbmc's student agent does). Instead we extract the first such
# block, up to the next blank double-newline, for attachment.
EBMC_CEX_HEADER_RE = re.compile(r"^Counterexample:", re.MULTILINE)


def extract_counterexample(stdout: str) -> str | None:
    """Return the first Counterexample block from ebmc stdout, if present.

    Useful for Phase 3 refine prompts: give the LLM the literal cex trace
    and ask it to patch the source. Returns None if no counterexample
    was emitted (e.g. all properties proved).

    ATH-674 bug 4: EBMC 5.10 (current `ghcr.io/athanor-ai/hw-cbmc:latest`)
    emits `Counterexample:\\n\\n<body>` — a blank line BEFORE the body.
    Splitting on the first blank line returned just "Counterexample:" alone
    and the body never reached `parse_cex_trace`. Skip leading blank lines
    after the header; cut at the next blank line in the body proper.
    """
    m = EBMC_CEX_HEADER_RE.search(stdout)
    if not m:
        return None
    start = m.start()
    tail = stdout[start:]
    # Skip the header line + any consecutive blank lines that follow.
    after_header = tail[tail.find("\n") + 1:] if "\n" in tail else ""
    after_header = re.sub(r"\A(?:\s*\n)+", "", after_header)
    # Now cut at the next blank-line in the body proper. Reattach the
    # header so callers see "Counterexample:\n<body>" regardless of how
    # many blank lines EBMC inserted between header and body.
    parts = re.split(r"\n\s*\n", after_header, maxsplit=1)
    body = parts[0].strip() if parts else after_header.strip()
    if not body:
        # Header present but no body → still return the header line so
        # the caller's "is None" check correctly reflects "no cex".
        return tail[:tail.find("\n")].strip() if "\n" in tail else tail.strip()
    return f"Counterexample:\n{body}"


def summarize_refutations(stdout: str, max_props: int = 8) -> list[dict]:
    """Return a list of {name, verdict} dicts for REFUTED/FAILED lines.

    Prompt-friendly — each entry also carries a short excerpt from the
    property line so the LLM can see what was refuted without reading
    the full EBMC output.
    """
    out: list[dict] = []
    for m in EBMC_PROPERTY_LINE_RE.finditer(stdout):
        name = m.group(1)
        verdict = m.group(2).upper()
        if verdict in {"REFUTED", "FAILED", "UNKNOWN"}:
            line_start = stdout.rfind("\n", 0, m.start()) + 1
            line_end = stdout.find("\n", m.end())
            if line_end < 0:
                line_end = len(stdout)
            excerpt = stdout[line_start:line_end].strip()
            out.append({"name": name, "verdict": verdict, "line": excerpt})
            if len(out) >= max_props:
                break
    return out
