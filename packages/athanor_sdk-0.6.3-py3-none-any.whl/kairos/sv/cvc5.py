"""ATH-705 (chain ATH-697) — cvc5 prover adapter for OSS Sledgehammer.

Thin Python wrapper around the `cvc5` SMT-solver binary. Same shape as
`kairos.sv.ebmc.run_ebmc`: take goal text in, invoke the binary, parse
the result, return a structured verdict the Lean side can reconstruct
from.

## Free tier

cvc5 is open source. This adapter is part of the free-tier Sledgehammer
surface alongside `ebmc` (un-gated in ATH-704). The adapter does NOT
import any paid module and does NOT touch the license-gate surface.

## Invocation contract (asabi 2026-04-26 18:55Z)

A Sledgehammer-style adapter:

  (a) calls prover binary with `-smt2` input,
  (b) parses certificate response (unsat-core for SMT),
  (c) hands the certificate back to the Lean side for kernel
      reconstruction via `linarith` / `nlinarith` / `decide` /
      a custom reconstruction lemma.

This module owns (a) + (b). The reconstruction lemma is a Lean tactic
that lives downstream in Pythia or a customer's spec.

## Output

`Cvc5Result` carries:

  - `verdict`: one of `"unsat"` / `"sat"` / `"unknown"` / `"timeout"` /
    `"error"`.
  - `unsat_core`: list of asserted-formula names that participated in
    the refutation (when `verdict == "unsat"`).
  - `model`: when `verdict == "sat"`, the satisfying assignment as a
    raw string. Customers parse with their own SMT-LIB reader; we
    don't ship a model parser yet.
  - `transcript`: full cvc5 stdout for debugging.

## Failure modes

- `cvc5` not on PATH → `Cvc5Result(verdict="error", error="cvc5 not on PATH")`.
- Subprocess timeout → `verdict="timeout"`.
- Malformed SMT-LIB input → cvc5 returns nonzero; we surface as
  `verdict="error"` with stderr.

## Why a separate module

Mirrors `kairos.sv.ebmc` (one module per prover). When vampire / E /
cbmc / dafny adapters land they each get their own `kairos.sv.<X>`
module. The dispatch orchestrator (Pythia goal-shape-dispatch) lives
upstream and picks which adapter to fire.
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Cvc5Result:
    """Structured outcome from a single `cvc5` invocation."""

    verdict: str  # "unsat" | "sat" | "unknown" | "timeout" | "error"
    unsat_core: list[str] = field(default_factory=list)
    model: str = ""
    transcript: str = ""
    stderr: str = ""
    exit_code: int = 0
    elapsed_sec: float = 0.0
    error: str = ""


def _is_cvc5_available() -> bool:
    return shutil.which("cvc5") is not None


def run_cvc5(
    smt_input: str | Path,
    *,
    timeout_sec: int = 60,
    produce_unsat_cores: bool = True,
    produce_models: bool = False,
    extra_args: list[str] | None = None,
) -> Cvc5Result:
    """Run cvc5 on `smt_input` (path or raw SMT-LIB text) + return a
    structured verdict.

    Args:
        smt_input: either a path to a `.smt2` file, or the SMT-LIB
            content as a string. We auto-detect: if it starts with
            `(set-logic` or `(declare`, treated as content; otherwise
            treated as a path.
        timeout_sec: subprocess wall timeout.
        produce_unsat_cores: pass `--produce-unsat-cores` to cvc5.
            Required for the Sledgehammer reconstruction step.
        produce_models: pass `--produce-models`. Off by default since
            most Sledgehammer use cases only need unsat cores.
        extra_args: additional CLI args appended verbatim.

    Free-tier (no license required). cvc5 is open-source.
    """
    if not _is_cvc5_available():
        return Cvc5Result(
            verdict="error",
            error="cvc5 not on PATH. Install from https://cvc5.github.io/",
        )

    # Resolve input — write content to a temp file if needed.
    cleanup: Path | None = None
    if isinstance(smt_input, Path) or (
        isinstance(smt_input, str) and not smt_input.lstrip().startswith("(")
    ):
        smt_path = Path(smt_input)
        if not smt_path.is_file():
            return Cvc5Result(
                verdict="error",
                error=f"smt_input path does not exist: {smt_path}",
            )
    else:
        # Inline content — write to a temp file.
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".smt2", prefix="kairos_cvc5_")
        smt_path = Path(tmp)
        with open(fd, "w") as f:
            f.write(smt_input)
        cleanup = smt_path

    try:
        cmd = ["cvc5"]
        if produce_unsat_cores:
            cmd.append("--produce-unsat-cores")
        if produce_models:
            cmd.append("--produce-models")
        if extra_args:
            cmd += list(extra_args)
        cmd.append(str(smt_path))

        import time
        t0 = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
        except subprocess.TimeoutExpired:
            return Cvc5Result(
                verdict="timeout",
                error=f"cvc5 timed out after {timeout_sec}s",
                elapsed_sec=float(timeout_sec),
            )

        elapsed = time.monotonic() - t0
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""

        verdict, core, model = _parse_cvc5_output(stdout)
        if proc.returncode != 0 and verdict == "unknown":
            return Cvc5Result(
                verdict="error",
                transcript=stdout,
                stderr=stderr,
                exit_code=proc.returncode,
                elapsed_sec=elapsed,
                error=f"cvc5 exit {proc.returncode}; "
                      f"stderr: {stderr.strip()[:300]}",
            )
        return Cvc5Result(
            verdict=verdict,
            unsat_core=core,
            model=model,
            transcript=stdout,
            stderr=stderr,
            exit_code=proc.returncode,
            elapsed_sec=elapsed,
        )
    finally:
        if cleanup is not None:
            try:
                cleanup.unlink()
            except OSError:
                pass


def _parse_cvc5_output(stdout: str) -> tuple[str, list[str], str]:
    """Parse cvc5's stdout into (verdict, unsat_core, model).

    cvc5 emits the verdict on the first non-blank line. Unsat cores
    come as `(<name1> <name2> ...)` after the verdict. Models come
    as `(model (define-fun ...) ...)` blocks.
    """
    verdict = "unknown"
    core: list[str] = []
    model = ""

    lines = [ln.strip() for ln in stdout.splitlines() if ln.strip()]
    if not lines:
        return verdict, core, model

    # First non-blank line is the verdict.
    head = lines[0]
    if head == "unsat":
        verdict = "unsat"
    elif head == "sat":
        verdict = "sat"
    elif head == "unknown":
        verdict = "unknown"

    # Tail parsing: unsat-core (parens-delimited list of names) +
    # model (define-fun blocks). Naive but correct for cvc5's
    # default output shape.
    rest = "\n".join(lines[1:])
    if verdict == "unsat" and "(" in rest:
        # Find the first parens block — that's the core.
        start = rest.find("(")
        depth = 0
        end = start
        for i, ch in enumerate(rest[start:], start=start):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        core_block = rest[start:end].strip("()").strip()
        if core_block:
            # Names are whitespace-separated identifiers.
            core = [tok for tok in core_block.split() if tok]
    elif verdict == "sat":
        # Capture the model block verbatim.
        if "(" in rest:
            model = rest

    return verdict, core, model


__all__ = [
    "Cvc5Result",
    "run_cvc5",
]
