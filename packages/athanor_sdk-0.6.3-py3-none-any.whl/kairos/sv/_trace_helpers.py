"""kairos.sv._trace_helpers — shared trace-emit utilities for sv-* helpers.

ATH-863 cleanup: the per-helper `_emit_to_active_session` +
`_emit_function_inputs_for_*` patterns in `kairos.sv.prove` (ATH-851)
and `kairos.sv.cegar` (ATH-863) were near-identical copy-paste — same
CURRENT_SESSION + non-Noop-sink gate, same try/except for sink import,
same swallow-on-emit-raise. qa flagged on the #326 review that the
next sv-* helper to grow trace events (likely `kairos.sv.invariants`
when it gets the same treatment) would be the third copy.

Factor the shared shape here so future sv-* trace coverage is one
import + one call instead of a copy-pasted gate. Per-helper specifics
(event_type, args dict, function_name) stay in the call site.

Conventions for sv-* trace events (mirrors ATH-851):

* `run_subtype="theorem_proving"` — every sv-* helper emits under
  this run_subtype so the platform's renderer routing picks them up
  uniformly.
* `run_type="sdk_orchestration"` — TraceEvent contract default.
* `sequence=0` — events ordered by created_at, not by sequence.
* All emits gated on CURRENT_SESSION + non-Noop sink. Privacy fence
  intact — `pip install athanor-sdk` doesn't phone home unless the
  customer explicitly opens a session with a real sink.
* Sink emit raises swallowed per the TraceSink Protocol contract.

Shape mismatch worth noting (qa #326 non-blocker #2): `*_first_4k`
preview fields stay as raw str slices (transcript_first_4k,
counterexample_first_4k, final_spec_first_4k). `sv_source` and
similar long-narrative inputs go through reduce_long_arg with the
SV-specific 50k cap. The convention: input-side digest, output-side
raw slice. Consumers handle them as `str | None` (capped) vs
`str | dict | None` (digestable) respectively.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

# sv_source preview cap, separate from the generic reduce_long_arg
# default of 300 chars. See `kairos.sv.prove._SV_SOURCE_PREVIEW_CAP`
# for the size-distribution justification (5–80k typical, 50k cap
# means typical specs land verbatim).
_SV_SOURCE_PREVIEW_CAP = 50_000


# ATH-971 Phase 4: emit_to_active_session shim deleted. The 6
# callers (kairos.ebmc / kairos.acl2 / kairos.quantization /
# kairos.sv.prove / kairos.sv.cegar / kairos.sv.ghost_tag) now call
# kairos.observe.emit(..., silent_if_no_session=True) directly. See
# kairos.observe.active_session_context for callers that need to
# detect the active session without emitting.


def emit_function_inputs_with_sv_source(
    sv_path: Path,
    *,
    function_name: str,
    args: Mapping[str, Any],
    run_subtype: str = "theorem_proving",
) -> None:
    """Capture sv_source + scalar args into a function_inputs event.

    Reads ``sv_path`` (best-effort; OSError swallowed since EBMC will
    surface a missing-file error itself a few lines later) and feeds
    the contents through ``reduce_long_arg`` with the SV-specific
    50k cap so customer specs typically land verbatim while
    pathological multi-MB designs digest to
    ``{sha256, length, preview_first_300, truncated}``.

    The caller passes its function-specific scalar args dict. This
    helper tacks ``sv_file`` (str path) + ``sv_source`` (digested or
    verbatim) onto a shallow copy before delegating to
    :func:`kairos.trace.emit_function_inputs`.

    Quiet-no-op outside an active session or with a NoopTraceSink
    installed -- session presence detected via
    :func:`kairos.observe.active_session_context` per ATH-971 Phase 4
    (replaces the legacy ``kairos.trace.CURRENT_SESSION.get()`` read).
    """
    # Lazy import for circular-import safety: kairos.observe pulls
    # several heavy modules (litellm wrapper machinery) and
    # kairos.sv._trace_helpers may be imported during their init.
    import sys as _sys
    _observe_mod = _sys.modules.get("kairos.observe")
    if _observe_mod is None:  # pragma: no cover
        from kairos import observe as _observe_mod  # type: ignore[no-redef]
    try:
        from kairos.trace import emit_function_inputs, reduce_long_arg
    except ImportError:  # pragma: no cover
        return

    ctx = _observe_mod.active_session_context(run_subtype=run_subtype)
    if ctx is None:
        return
    if ctx.sink is None:  # pragma: no cover -- _ObserveContext always has a sink
        return
    from kairos.trace import NoopTraceSink
    if isinstance(ctx.sink, NoopTraceSink):
        return

    try:
        sv_source = sv_path.read_text(errors="replace")
    except OSError:
        sv_source = None

    full_args: dict[str, Any] = dict(args)
    full_args["sv_file"] = str(sv_path)
    full_args["sv_source"] = (
        reduce_long_arg(sv_source, preview_cap=_SV_SOURCE_PREVIEW_CAP)
        if sv_source is not None else None
    )

    emit_function_inputs(
        sink=ctx.sink,
        run_id=ctx.run_id,
        run_subtype=run_subtype,
        function_name=function_name,
        args=full_args,
    )
