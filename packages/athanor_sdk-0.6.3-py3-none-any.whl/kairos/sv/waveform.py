"""kairos.sv.waveform — mechanical signal extraction from EBMC traces.

ATH-884: parse EBMC counterexample traces, extract the signal that
violated first, identify the cycle of violation. Deterministic, no LLM.
Feeds into counterexample.explain as grounding input.

Free tier — deterministic parsing only.

Usage::

    from kairos.sv.waveform import analyze_counterexample

    analysis = analyze_counterexample(ebmc_result)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SignalTransition:
    """A signal value change at a specific cycle."""
    signal: str
    cycle: int
    value: str
    prev_value: str | None = None


@dataclass
class ViolationInfo:
    """Information about a property violation from an EBMC trace."""
    property_name: str
    cycle: int
    signals_at_violation: dict[str, str] = field(default_factory=dict)
    first_divergent_signal: str | None = None
    first_divergent_cycle: int | None = None
    transitions: list[SignalTransition] = field(default_factory=list)


@dataclass
class WaveformAnalysis:
    """Result of analyzing an EBMC counterexample trace."""
    violations: list[ViolationInfo] = field(default_factory=list)
    total_cycles: int = 0
    signals_observed: list[str] = field(default_factory=list)
    verification_status: str = "machine_verified"

    def to_dict(self) -> dict[str, Any]:
        return {
            "violations": [
                {
                    "property_name": v.property_name,
                    "cycle": v.cycle,
                    "first_divergent_signal": v.first_divergent_signal,
                    "first_divergent_cycle": v.first_divergent_cycle,
                    "signals_at_violation": v.signals_at_violation,
                    "transitions_count": len(v.transitions),
                }
                for v in self.violations
            ],
            "total_cycles": self.total_cycles,
            "signals_observed": self.signals_observed,
            "verification_status": self.verification_status,
        }

    def format_human_readable(self) -> str:
        """Concise summary for customer agents and CLI output."""
        if not self.violations:
            return "No violations found."
        parts = []
        for v in self.violations:
            lines = [f"Property {v.property_name} REFUTED at cycle {v.cycle}"]
            if v.first_divergent_signal:
                lines.append(
                    f"  First divergence: {v.first_divergent_signal} "
                    f"at cycle {v.first_divergent_cycle}"
                )
            if v.transitions[:5]:
                lines.append("  Signal transitions:")
                for t in v.transitions[:5]:
                    lines.append(
                        f"    cycle {t.cycle}: {t.signal} "
                        f"{t.prev_value} -> {t.value}"
                    )
                if len(v.transitions) > 5:
                    lines.append(f"    ... and {len(v.transitions) - 5} more")
            parts.append("\n".join(lines))
        return "\n\n".join(parts)


_PROPERTY_RE = re.compile(
    r"\[([^\]]+)\]\s+.*?:\s*(REFUTED|FAILED)",
    re.IGNORECASE,
)

_SIGNAL_RE = re.compile(
    r"^\s*(\S+)\s*=\s*(\S+)",
    re.MULTILINE,
)

_CYCLE_RE = re.compile(
    r"(?:^|\n)\s*(?:Cycle|State|@?)\s*#?(\d+)",
    re.IGNORECASE,
)

_TRANSITION_RE = re.compile(
    r"(\S+)\s+(\d+)\'([bh])([01xzXZ]+)",
)


def _parse_counterexample_signals(
    trace_text: str,
) -> list[tuple[int, dict[str, str]]]:
    """Parse cycle-by-cycle signal values from EBMC trace output."""
    cycles: list[tuple[int, dict[str, str]]] = []
    current_cycle = 0
    current_signals: dict[str, str] = {}

    for line in trace_text.split("\n"):
        cycle_m = _CYCLE_RE.match(line.strip())
        if cycle_m:
            if current_signals:
                cycles.append((current_cycle, dict(current_signals)))
            current_cycle = int(cycle_m.group(1))
            current_signals = {}
            continue

        sig_m = _SIGNAL_RE.match(line.strip())
        if sig_m:
            current_signals[sig_m.group(1)] = sig_m.group(2)

    if current_signals:
        cycles.append((current_cycle, dict(current_signals)))

    return cycles


def analyze_counterexample(
    ebmc_stdout: str,
    ebmc_stderr: str = "",
    *,
    counterexample: str | None = None,
) -> WaveformAnalysis:
    """Analyze an EBMC counterexample trace mechanically.

    Extracts:
    - Which properties were refuted
    - The cycle of violation for each
    - Signal values at the violation cycle
    - The first signal that diverged from expected

    This is deterministic — no LLM involved. The result carries
    ``verification_status="machine_verified"`` because all extraction
    is mechanical parsing of EBMC output.

    Args:
        ebmc_stdout: EBMC stdout containing property verdicts.
        ebmc_stderr: EBMC stderr (optional).
        counterexample: explicit counterexample text (if available
            separately from stdout).

    Returns:
        WaveformAnalysis with per-violation signal extraction.
    """
    analysis = WaveformAnalysis()
    combined = ebmc_stdout + "\n" + (counterexample or "")

    refuted_props = _PROPERTY_RE.findall(combined)

    trace_cycles = _parse_counterexample_signals(combined)
    analysis.total_cycles = len(trace_cycles)

    all_signals: set[str] = set()
    for _, sigs in trace_cycles:
        all_signals.update(sigs.keys())
    analysis.signals_observed = sorted(all_signals)

    for prop_name, _ in refuted_props:
        vi = ViolationInfo(property_name=prop_name, cycle=0)

        if trace_cycles:
            last_cycle_num, last_signals = trace_cycles[-1]
            vi.cycle = last_cycle_num
            vi.signals_at_violation = last_signals

            for i in range(1, len(trace_cycles)):
                prev_num, prev_sigs = trace_cycles[i - 1]
                curr_num, curr_sigs = trace_cycles[i]
                for sig in sorted(curr_sigs.keys()):
                    prev_val = prev_sigs.get(sig)
                    curr_val = curr_sigs[sig]
                    if prev_val is not None and prev_val != curr_val:
                        vi.transitions.append(SignalTransition(
                            signal=sig,
                            cycle=curr_num,
                            value=curr_val,
                            prev_value=prev_val,
                        ))
                        if vi.first_divergent_signal is None:
                            vi.first_divergent_signal = sig
                            vi.first_divergent_cycle = curr_num

        analysis.violations.append(vi)

    return analysis


def analyze_from_ebmc_result(ebmc_result: Any) -> WaveformAnalysis:
    """Convenience wrapper that takes an EbmcResult object."""
    cex = None
    try:
        cex = ebmc_result.counterexample
    except Exception:  # noqa: BLE001 — counterexample attr access; ebmc_result may not have it
        pass
    return analyze_counterexample(
        ebmc_result.stdout or "",
        ebmc_result.stderr or "",
        counterexample=cex,
    )
