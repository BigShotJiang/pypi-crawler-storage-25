"""kairos.sv.ghost_tag — ghost-state invariant instrumentation for EBMC.

ATH-908 Pattern 3: inject `ifdef`-guarded ghost tags into RTL at
dispatch points. Each instruction gets a monotonic tag at dispatch;
the tag propagates through every flop the instruction touches. Yields
4 invariant classes mechanically:

1. Uniqueness — no two in-flight instructions share the same tag
2. Location — tag at stage N implies instruction was dispatched
3. Ordering — tags at commit are monotonically ordered
4. Flow — tag propagates correctly through forwarding/bypass paths

The ghost tags are `ifdef KAIROS_GHOST_TAG` guarded so they have
zero impact on synthesis. EBMC sees them when invoked with
`+define+KAIROS_GHOST_TAG`.

Usage::

    from kairos.sv.ghost_tag import instrument_ghost_tags

    result = instrument_ghost_tags(
        source_files=["cpu_pkg.sv", "cpu_ooo.sv"],
        dispatch_signal="dispatch_valid",
        tag_width=8,
        output_dir="/tmp/ghosted/",
    )
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class GhostTagResult:
    """Result of ghost-tag instrumentation."""
    files_instrumented: int = 0
    tags_injected: int = 0
    invariant_templates: list[str] = field(default_factory=list)
    output_files: list[str] = field(default_factory=list)


def _find_dispatch_point(source: str, dispatch_signal: str) -> int | None:
    """Find the line number where the dispatch signal is referenced."""
    for i, line in enumerate(source.split("\n")):
        if dispatch_signal in line:
            return i
    return None


def _find_flop_declarations(source: str) -> list[str]:
    """Find all always_ff registered signal names."""
    signals = set()
    in_ff = False
    for line in source.split("\n"):
        stripped = line.strip()
        if re.match(r"always_ff\b", stripped):
            in_ff = True
        if in_ff:
            m = re.match(r"\s*(\w+)\s*<=", stripped)
            if m:
                signals.add(m.group(1))
            if stripped == "end" and in_ff:
                in_ff = False
    return sorted(signals)


def _generate_ghost_block(
    dispatch_signal: str,
    tag_width: int,
    flop_signals: list[str],
    clk: str = "clk",
    rst: str = "rst_n",
) -> str:
    """Generate the ifdef-guarded ghost-tag SV block."""
    lines = [
        "",
        "`ifdef KAIROS_GHOST_TAG",
        f"  // Ghost-tag instrumentation (kairos.sv.ghost_tag)",
        f"  logic [{tag_width-1}:0] _ghost_tag_counter;",
        f"  logic [{tag_width-1}:0] _ghost_tag_at_dispatch;",
    ]

    for sig in flop_signals:
        lines.append(f"  logic [{tag_width-1}:0] _ghost_tag_{sig};")

    lines.append(f"")
    lines.append(f"  always_ff @(posedge {clk} or negedge {rst}) begin")
    lines.append(f"    if (!{rst}) begin")
    lines.append(f"      _ghost_tag_counter <= '0;")
    lines.append(f"      _ghost_tag_at_dispatch <= '0;")
    for sig in flop_signals:
        lines.append(f"      _ghost_tag_{sig} <= '0;")
    lines.append(f"    end else begin")
    lines.append(f"      if ({dispatch_signal}) begin")
    lines.append(f"        _ghost_tag_counter <= _ghost_tag_counter + 1;")
    lines.append(f"        _ghost_tag_at_dispatch <= _ghost_tag_counter;")
    lines.append(f"      end")
    for sig in flop_signals:
        lines.append(f"      if ({dispatch_signal}) _ghost_tag_{sig} <= _ghost_tag_counter;")
    lines.append(f"    end")
    lines.append(f"  end")

    lines.append(f"")
    lines.append(f"  // Invariant templates")
    lines.append(f"  // Class 1: Uniqueness")
    lines.append(f"  // assert property (@(posedge {clk}) {dispatch_signal} |-> _ghost_tag_counter != _ghost_tag_at_dispatch);")
    lines.append(f"  // Class 3: Ordering (commit tags are monotonic)")
    lines.append(f"  // assert property (@(posedge {clk}) commit_valid |-> _ghost_tag_at_commit > $past(_ghost_tag_at_commit));")

    lines.append(f"`endif // KAIROS_GHOST_TAG")
    lines.append("")

    return "\n".join(lines)


def _generate_invariant_templates(
    dispatch_signal: str,
    flop_signals: list[str],
    clk: str = "clk",
) -> list[str]:
    """Generate the 4 invariant class templates as SVA strings."""
    templates = []

    templates.append(
        f"// Class 1: Uniqueness — no two in-flight instructions share a tag\n"
        f"assert property (@(posedge {clk}) {dispatch_signal} |-> "
        f"_ghost_tag_counter != _ghost_tag_at_dispatch);"
    )

    templates.append(
        f"// Class 2: Location — tag at stage implies dispatched\n"
        f"assert property (@(posedge {clk}) "
        f"(_ghost_tag_{flop_signals[0]} != 0) |-> "
        f"$past({dispatch_signal}));" if flop_signals else
        "// Class 2: Location — no flop signals found"
    )

    templates.append(
        f"// Class 3: Ordering — commit tags are monotonically ordered\n"
        f"assert property (@(posedge {clk}) commit_valid |-> "
        f"_ghost_tag_at_commit > $past(_ghost_tag_at_commit));"
    )

    templates.append(
        f"// Class 4: Flow — tag propagates through forwarding paths\n"
        f"assert property (@(posedge {clk}) forward_valid |-> "
        f"_ghost_tag_forward == _ghost_tag_at_dispatch);"
    )

    return templates


def instrument_ghost_tags(
    source_files: list[str | Path],
    *,
    dispatch_signal: str,
    tag_width: int = 8,
    max_flop_taggers: int = 16,
    output_dir: str | Path | None = None,
    clk: str = "clk",
    rst: str = "rst_n",
) -> GhostTagResult:
    """Instrument SV source files with ghost-tag tracking.

    Args:
        source_files: SV source files to instrument.
        dispatch_signal: signal name that indicates instruction dispatch.
        tag_width: bit width of the ghost tag (default 8 = 256 in-flight).
        output_dir: write instrumented files here. None = modify in place.
        clk: clock signal name.
        rst: active-low reset signal name.

    Returns:
        GhostTagResult with instrumentation statistics.
    """
    result = GhostTagResult()

    for src_path in source_files:
        p = Path(src_path)
        source = p.read_text()

        dispatch_line = _find_dispatch_point(source, dispatch_signal)
        if dispatch_line is None:
            continue

        flop_signals = _find_flop_declarations(source)
        ghost_block = _generate_ghost_block(
            dispatch_signal, tag_width, flop_signals[:max_flop_taggers], clk, rst,
        )

        idx = source.rfind("endmodule")
        if idx < 0:
            continue

        instrumented = source[:idx] + ghost_block + source[idx:]
        result.files_instrumented += 1
        result.tags_injected += len(flop_signals[:16]) + 2

        if output_dir:
            out_path = Path(output_dir) / p.name
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(instrumented)
            result.output_files.append(str(out_path))
        else:
            p.write_text(instrumented)
            result.output_files.append(str(p))

    result.invariant_templates = _generate_invariant_templates(
        dispatch_signal, _find_flop_declarations(Path(source_files[0]).read_text())[:max_flop_taggers], clk,
    )

    try:
        from kairos.observe import emit as _observe_emit
        _observe_emit(
            "ghost_tag_instrumented",
            {
                "files_instrumented": result.files_instrumented,
                "tags_injected": result.tags_injected,
                "invariant_template_count": len(result.invariant_templates),
                "dispatch_signal": dispatch_signal,
                "tag_width": tag_width,
                "max_flop_taggers": max_flop_taggers,
            },
            silent_if_no_session=True,
        )
    except ImportError:
        pass

    return result


__all__ = [
    "instrument_ghost_tags",
    "GhostTagResult",
]
