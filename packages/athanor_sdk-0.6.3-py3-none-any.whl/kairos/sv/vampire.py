"""ATH-705 — Vampire FOL ATP adapter (OSS Sledgehammer chain).

Vampire is a saturation-based first-order theorem prover; it takes
TPTP-format input + emits a refutation proof when the goal is
unsatisfiable. This adapter is the Python wrapper around the `vampire`
binary; same shape as kairos.sv.{ebmc, cvc5, cbmc}.

## Free tier

Vampire is open source (https://github.com/vprover/vampire). This
adapter ships in the free-tier OSS Sledgehammer surface. No
license-gate calls.

## Output

`VampireResult` carries:

  - `verdict`: `"unsat"` (refutation found, theorem proved) /
    `"sat"` (counter-model found) /
    `"unknown"` (gave up under time limit) /
    `"timeout"` / `"error"`.
  - `refutation`: refutation proof when `verdict == "unsat"` —
    Lean kernel reconstruction (asabi-owned) consumes this via
    premise-selection over `@[stat_lemma]`-tagged lemmas.
  - `transcript`, `stderr`, `exit_code`, `elapsed_sec`.

## Failure modes

- `vampire` not on PATH → `verdict="error"` with install hint.
- Subprocess timeout → `verdict="timeout"`.
- Malformed TPTP → vampire returns nonzero with a parse error.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VampireResult:
    """Structured outcome from a single `vampire` invocation."""

    verdict: str  # "unsat" | "sat" | "unknown" | "timeout" | "error"
    refutation: str = ""
    transcript: str = ""
    stderr: str = ""
    exit_code: int = 0
    elapsed_sec: float = 0.0
    error: str = ""


def _is_vampire_available() -> bool:
    return shutil.which("vampire") is not None


# Vampire's verdict line is one of these SZS-format strings (per TPTP).
_VAMPIRE_UNSAT = re.compile(r"SZS status (?:Theorem|Unsatisfiable)\b", re.I)
_VAMPIRE_SAT = re.compile(r"SZS status (?:Satisfiable|CounterSatisfiable)\b", re.I)
_VAMPIRE_UNKNOWN = re.compile(
    r"SZS status (?:GaveUp|ResourceOut|Timeout|Unknown)\b", re.I
)


def run_vampire(
    tptp_input: str | Path,
    *,
    time_limit: int = 60,
    proof: bool = True,
    extra_args: list[str] | None = None,
) -> VampireResult:
    """Invoke `vampire` on TPTP input + return a structured verdict.

    Args:
        tptp_input: path to a `.p` / `.tptp` file, or raw TPTP content.
            Auto-detected: starts with `fof(`/`cnf(` is content; else
            treated as a path.
        time_limit: soft time limit in seconds (passed as `-t`).
        proof: emit refutation proof when verdict is unsat
            (passed as `--proof tptp`).
        extra_args: additional CLI args appended verbatim.
    """
    if not _is_vampire_available():
        return VampireResult(
            verdict="error",
            error="vampire not on PATH. Install from "
                  "https://github.com/vprover/vampire",
        )

    cleanup: Path | None = None
    if isinstance(tptp_input, Path) or (
        isinstance(tptp_input, str)
        and not (
            tptp_input.lstrip().startswith(("fof(", "cnf(", "tff(", "thf("))
        )
    ):
        path = Path(tptp_input)
        if not path.is_file():
            return VampireResult(
                verdict="error",
                error=f"tptp_input path does not exist: {path}",
            )
    else:
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".p", prefix="kairos_vampire_")
        path = Path(tmp)
        with open(fd, "w") as f:
            f.write(tptp_input)
        cleanup = path

    try:
        cmd: list[str] = ["vampire", "-t", str(time_limit)]
        if proof:
            cmd += ["--proof", "tptp"]
        if extra_args:
            cmd += list(extra_args)
        cmd.append(str(path))

        t0 = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=time_limit + 10,
            )
        except subprocess.TimeoutExpired:
            return VampireResult(
                verdict="timeout",
                error=f"vampire wall-timeout after {time_limit + 10}s",
                elapsed_sec=float(time_limit + 10),
            )

        elapsed = time.monotonic() - t0
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""

        verdict, refutation = _parse_vampire_output(stdout)

        # Vampire exit codes: 0 (success), nonzero (error / interrupted).
        # Treat verdict-known + nonzero exit as still-meaningful (e.g.
        # "GaveUp" with nonzero exit is fine).
        if proc.returncode != 0 and verdict in ("error", "unknown"):
            return VampireResult(
                verdict="error",
                transcript=stdout,
                stderr=stderr,
                exit_code=proc.returncode,
                elapsed_sec=elapsed,
                error=f"vampire exit {proc.returncode}; "
                      f"stderr: {stderr.strip()[:300]}",
            )

        return VampireResult(
            verdict=verdict,
            refutation=refutation,
            transcript=stdout,
            stderr=stderr,
            exit_code=proc.returncode,
            elapsed_sec=elapsed,
        )
    finally:
        if cleanup is not None:
            try:
                cleanup.unlink()
            except OSError:
                pass


def _parse_vampire_output(stdout: str) -> tuple[str, str]:
    """Parse vampire's stdout into `(verdict, refutation)`.

    Vampire emits SZS status lines (per TPTP convention). The
    refutation block, when emitted, is bounded by `% SZS output start
    Proof` / `% SZS output end Proof`.
    """
    if _VAMPIRE_UNSAT.search(stdout):
        verdict = "unsat"
    elif _VAMPIRE_SAT.search(stdout):
        verdict = "sat"
    elif _VAMPIRE_UNKNOWN.search(stdout):
        verdict = "unknown"
    else:
        verdict = "error"

    refutation = ""
    if verdict == "unsat":
        start = stdout.find("% SZS output start Proof")
        end = stdout.find("% SZS output end Proof")
        if start != -1 and end != -1:
            refutation = stdout[start:end + len("% SZS output end Proof")]

    return verdict, refutation


__all__ = [
    "VampireResult",
    "run_vampire",
]
