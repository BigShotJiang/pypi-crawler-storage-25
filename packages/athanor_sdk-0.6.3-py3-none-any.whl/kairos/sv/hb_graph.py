"""kairos.sv.hb_graph — happens-before graph core (ATH-412 Part B, slice 1).

Models the happens-before relation between events in a hardware design
(writes, reads, synchronization tokens, fences). Edges are typed
(program-order, synchronization, observation) with per-edge justification
so downstream emitters can lower each edge to an SVA obligation the
EBMC backend can cross-check.

This slice ships the **graph core + cycle detection** only:

- ``Event`` / ``HBEdge`` / ``HBGraph`` dataclasses (immutable on ``event_id``;
  edges are an append-only collection).
- Tarjan's strongly-connected-components algorithm over the HB graph.
  A cycle in HB is a program-order violation by definition (Lamport
  1978): events cannot strictly precede themselves.
- Topological-sort helper for violation-free graphs (used by the SVA
  emitter in slice 3).

What is **not** in this slice (tracked as follow-up):

- **SV AST parser** that populates ``HBGraph`` from ``always_ff`` /
  ``always @`` / handshake tokens in real SystemVerilog source. Ships
  in slice 2 (``sv/hb_extract.py``).
- **SVA emitter** that lowers cycle witnesses to EBMC-interpretable
  assertions. Ships in slice 3.
- **Two-FIFO demo + CLI** (``athanor sv-hb-graph``). Ships in slice 4.

Each slice is a standalone complete module, not a stub. Per Aidan's
"no stubs" rule + the ATH-412 ticket: Part B ships in slices because
the full deliverable is 1-2 weeks; each slice is a complete library
unit useful on its own (e.g., external tooling could build an HBGraph
directly and call ``find_po_violations`` without needing the SV parser).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterator


# ─── Event + edge model ─────────────────────────────────────────────


class EventKind(str, Enum):
    """Kind of event at a node. Lamport 1978 §2 + standard HW-mem-model
    terminology."""

    WRITE = "write"
    READ = "read"
    FENCE = "fence"          # full memory-order barrier
    HANDSHAKE = "handshake"  # cross-process synchronization token
    INIT = "init"            # synthetic start-of-time node


class EdgeKind(str, Enum):
    """Justification for an HB edge. The SVA emitter picks a distinct
    lowering per kind (slice 3)."""

    PROGRAM_ORDER = "program_order"
    SYNCHRONIZATION = "synchronization"
    OBSERVATION = "observation"
    INIT_EDGE = "init_edge"  # synthetic edge from INIT to any event


@dataclass(frozen=True)
class Event:
    """A single event in the HB graph.

    Identified by ``event_id`` (caller-supplied, globally unique per
    graph). Two Events with the same ``event_id`` compare equal — the
    graph deduplicates on that field.

    Attributes:
        event_id: opaque stable identifier (string). Must be unique
            per-graph; the extractor (slice 2) uses
            ``"{block_id}#{line}"`` so each SV source line gets at most
            one Event.
        kind: WRITE / READ / FENCE / HANDSHAKE / INIT.
        signal: the signal or token name the event operates on. For
            FENCE this is the empty string.
        block: the ``always_ff`` / ``always @`` block id or
            ``"<initial>"`` for the synthetic INIT event.
        source_line: optional source-line number for error reporting.
    """

    event_id: str
    kind: EventKind
    signal: str
    block: str
    source_line: int | None = None


@dataclass(frozen=True)
class HBEdge:
    """A directed edge from ``src`` → ``dst`` with justification."""

    src: str  # event_id
    dst: str  # event_id
    kind: EdgeKind
    reason: str  # human-readable "why" for reports


@dataclass
class HBGraph:
    """Happens-before graph over a set of Events.

    Internally an adjacency map of event_id → list[HBEdge]. Mutable at
    construction time (add_event / add_edge) but no existing node/edge
    is mutated after insertion — caller can freeze by wrapping in a
    ``Proxy`` if needed downstream.

    The graph MUST have at most one Event per event_id; ``add_event``
    raises if a duplicate is added with a conflicting payload, and
    silently skips if the payload matches.
    """

    events: dict[str, Event] = field(default_factory=dict)
    # Outgoing adjacency; edges keyed by src event_id.
    _outgoing: dict[str, list[HBEdge]] = field(default_factory=dict)

    def add_event(self, event: Event) -> None:
        prior = self.events.get(event.event_id)
        if prior is not None and prior != event:
            raise ValueError(
                f"duplicate event_id {event.event_id!r} with conflicting "
                f"payload: existing={prior}, new={event}"
            )
        self.events[event.event_id] = event
        self._outgoing.setdefault(event.event_id, [])

    def add_edge(self, edge: HBEdge) -> None:
        if edge.src not in self.events:
            raise KeyError(f"edge source event not in graph: {edge.src}")
        if edge.dst not in self.events:
            raise KeyError(f"edge destination event not in graph: {edge.dst}")
        if edge.src == edge.dst:
            raise ValueError(
                f"self-loop on event {edge.src!r}; HB is strict order"
            )
        self._outgoing[edge.src].append(edge)

    def outgoing(self, event_id: str) -> list[HBEdge]:
        return list(self._outgoing.get(event_id, ()))

    def all_edges(self) -> Iterator[HBEdge]:
        for edges in self._outgoing.values():
            yield from edges

    def __len__(self) -> int:
        return len(self.events)


# ─── Tarjan SCC — PO-violation detection ────────────────────────────


@dataclass
class POViolation:
    """A detected program-order violation.

    A non-trivial strongly-connected component in the HB graph means
    some set of events all happen-before each other — impossible under
    Lamport's strict partial order axiom. The ``cycle_events`` list
    names every event_id in the offending SCC; ``cycle_edges`` lists
    every edge internal to the SCC (the witness of the cycle).
    """

    cycle_events: list[str]
    cycle_edges: list[HBEdge]

    @property
    def size(self) -> int:
        return len(self.cycle_events)


def find_po_violations(graph: HBGraph) -> list[POViolation]:
    """Run Tarjan's SCC algorithm, return all SCCs of size ≥ 2.

    Size-1 SCCs (a node with no self-loop) are not violations — HBGraph
    rejects self-loops at add_edge time, so the only way to get a
    size-1 SCC here is a node participating in no cycle. Those are
    filtered out.

    Complexity: O(|V| + |E|), single pass.

    Returns:
        POViolation per cycle SCC, ordered by first-discovered.
        Empty list when the graph is a proper DAG (no PO violations).
    """
    index_counter: list[int] = [0]
    stack: list[str] = []
    on_stack: dict[str, bool] = {}
    index: dict[str, int] = {}
    lowlink: dict[str, int] = {}
    sccs: list[list[str]] = []

    def strongconnect(v: str) -> None:
        index[v] = index_counter[0]
        lowlink[v] = index_counter[0]
        index_counter[0] += 1
        stack.append(v)
        on_stack[v] = True

        for edge in graph.outgoing(v):
            w = edge.dst
            if w not in index:
                strongconnect(w)
                lowlink[v] = min(lowlink[v], lowlink[w])
            elif on_stack.get(w):
                lowlink[v] = min(lowlink[v], index[w])

        if lowlink[v] == index[v]:
            scc: list[str] = []
            while True:
                w = stack.pop()
                on_stack[w] = False
                scc.append(w)
                if w == v:
                    break
            sccs.append(scc)

    for v in graph.events:
        if v not in index:
            strongconnect(v)

    violations: list[POViolation] = []
    for scc in sccs:
        if len(scc) < 2:
            continue
        member = set(scc)
        cycle_edges = [
            e for src in scc for e in graph.outgoing(src) if e.dst in member
        ]
        violations.append(
            POViolation(cycle_events=list(scc), cycle_edges=cycle_edges)
        )
    return violations


# ─── Topological sort (useful once graph is violation-free) ─────────


def topological_order(graph: HBGraph) -> list[str]:
    """Kahn's algorithm. Raises ``CycleError`` when a PO violation
    exists — callers are expected to check ``find_po_violations``
    first, but this gate is here so an unchecked call is loud.
    """
    indegree: dict[str, int] = {v: 0 for v in graph.events}
    for edge in graph.all_edges():
        indegree[edge.dst] += 1

    ready: list[str] = [v for v, d in indegree.items() if d == 0]
    result: list[str] = []
    while ready:
        v = ready.pop(0)
        result.append(v)
        for edge in graph.outgoing(v):
            indegree[edge.dst] -= 1
            if indegree[edge.dst] == 0:
                ready.append(edge.dst)

    if len(result) != len(graph.events):
        offending = [v for v, d in indegree.items() if d > 0]
        raise CycleError(
            f"cycle detected; {len(offending)} event(s) not orderable: "
            f"{sorted(offending)[:10]}"
            + ("..." if len(offending) > 10 else "")
        )
    return result


class CycleError(ValueError):
    """Raised by ``topological_order`` when the graph has a cycle."""


# ─── Public surface ──────────────────────────────────────────────────


__all__ = [
    "EventKind",
    "EdgeKind",
    "Event",
    "HBEdge",
    "HBGraph",
    "POViolation",
    "CycleError",
    "find_po_violations",
    "topological_order",
]
