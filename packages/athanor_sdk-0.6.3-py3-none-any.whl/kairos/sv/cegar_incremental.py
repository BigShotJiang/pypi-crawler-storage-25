"""kairos.sv.cegar_incremental — BTOR2-style incremental CEGAR.

Aliases (for cross-search):
* "BTOR2-append fast-CEGAR" — Todd's 2026-04 framing
* "incremental CEGAR" / "Todd's 10-step loop" — academic / asabi framing
* ATH-907 — Linear ticket

All four names describe THIS module. Naming-ambiguity retro
2026-05-02: platform almost reimplemented this work under the
BTOR2-append name because grep('btor2', 'src/kairos/') returned
0 hits. This alias block makes the cross-name search land here.

ATH-907: Todd's 10-step loop. Instead of re-elaborating the full
design on each CEGAR iteration, cache the base spec and only
append new lemmas. Key optimizations:

1. Flatten + preprocess once, cache the result
2. Each iteration appends the new lemma to the cached spec
3. Separate base-case check (BMC from reset) from inductive step
4. Track lemma provenance: which lemma closed which property

This is the SDK-level optimization. The builder's loop.py calls
this instead of run_ebmc directly when incremental=True.

See also: `kairos.sv.cegar` — the non-incremental CEGAR loop
(re-elaborates every iteration; use for small designs where the
cache cost dominates).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.sv.ebmc import run_ebmc, EbmcResult
from kairos.sv.flatten import flatten_files


@dataclass
class Lemma:
    """A candidate lemma proposed by the CEGAR loop."""
    hypothesis_sv: str
    iteration: int
    base_case_proved: bool = False
    inductive_step_proved: bool = False
    classification: str = ""

    @property
    def fully_proved(self) -> bool:
        return self.base_case_proved and self.inductive_step_proved


@dataclass
class IncrementalCegarResult:
    """Result of incremental CEGAR."""
    proved: bool = False
    iterations: int = 0
    lemmas: list[Lemma] = field(default_factory=list)
    elapsed_sec: float = 0.0
    base_elaboration_sec: float = 0.0
    per_iteration_sec: list[float] = field(default_factory=list)


def _prepare_base(
    source_files: list[str | Path],
    top_module: str,
    extra_args: list[str] | None = None,
    flatten: bool = True,
) -> tuple[list[str], float]:
    """Flatten and preprocess once. Returns (file_paths, elapsed_sec)."""
    t0 = time.monotonic()
    paths = [str(Path(f).resolve()) for f in source_files]

    if flatten:
        import tempfile
        flat_dir = Path(tempfile.mkdtemp(prefix="kairos_cegar_inc_"))
        flatten_files([Path(p) for p in paths], output_dir=flat_dir)
        paths = [str(flat_dir / Path(p).name) for p in paths]

    elapsed = time.monotonic() - t0
    return paths, elapsed


def _check_base_case(
    cached_files: list[str],
    top_module: str,
    lemma_sv: str,
    bound: int,
    reset_expr: str | None,
    extra_args: list[str] | None,
    timeout_sec: int = 60,
) -> EbmcResult:
    """Check lemma from reset (BMC, fast). Todd's step 5."""
    import tempfile
    spec = Path(cached_files[-1]).read_text()
    # Splice lemma before endmodule
    spliced = spec.rstrip()
    if "endmodule" in spliced:
        idx = spliced.rfind("endmodule")
        spliced = spliced[:idx] + f"\n  {lemma_sv}\n" + spliced[idx:]

    tmp = Path(tempfile.mkdtemp(prefix="cegar_base_"))
    spec_file = tmp / "spec_with_lemma.sv"
    spec_file.write_text(spliced)

    files = cached_files[:-1] + [str(spec_file)]
    return run_ebmc(
        files,
        top_module=top_module,
        bound=bound,
        mode="bmc",
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
    )


def _check_inductive_step(
    cached_files: list[str],
    top_module: str,
    all_lemmas_sv: list[str],
    bound: int,
    reset_expr: str | None,
    extra_args: list[str] | None,
    timeout_sec: int = 300,
) -> EbmcResult:
    """K-induction with all accepted lemmas. Todd's step 8."""
    import tempfile
    spec = Path(cached_files[-1]).read_text()
    spliced = spec.rstrip()
    if "endmodule" in spliced:
        idx = spliced.rfind("endmodule")
        lemmas_block = "\n".join(f"  {l}" for l in all_lemmas_sv)
        spliced = spliced[:idx] + f"\n{lemmas_block}\n" + spliced[idx:]

    tmp = Path(tempfile.mkdtemp(prefix="cegar_ind_"))
    spec_file = tmp / "spec_with_all_lemmas.sv"
    spec_file.write_text(spliced)

    files = cached_files[:-1] + [str(spec_file)]
    return run_ebmc(
        files,
        top_module=top_module,
        bound=bound,
        mode="k_induction",
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
    )


def incremental_cegar(
    source_files: list[str | Path],
    *,
    top_module: str,
    bound: int = 10,
    max_iter: int = 10,
    reset_expr: str | None = "!rst_n",
    extra_args: list[str] | None = None,
    flatten: bool = True,
    proposer: Any = None,
    timeout_per_step_sec: int = 300,
) -> IncrementalCegarResult:
    """Todd's 10-step BTOR2-style CEGAR loop.

    1. Flatten + preprocess once (cached)
    2. K-induction on base spec
    3. If stuck: LLM proposes lemma
    4. Check lemma from reset (BMC, fast)
    5. If passes: add to inductive step
    6. Retry k-induction with accumulated lemmas
    7. Repeat until proved or max_iter

    Args:
        source_files: SV source files.
        top_module: top module for EBMC.
        bound: k-induction depth.
        max_iter: maximum CEGAR iterations.
        reset_expr: reset signal.
        extra_args: extra EBMC flags.
        flatten: preprocess through flattener.
        proposer: LLM proposer function (takes counterexample, returns lemma).
        timeout_per_step_sec: per-EBMC-call timeout.

    Returns:
        IncrementalCegarResult with per-lemma provenance.
    """
    from kairos.observe import emit

    result = IncrementalCegarResult()
    t0 = time.monotonic()
    ea = list(extra_args or [])

    # Step 0: Flatten once
    cached_files, prep_time = _prepare_base(
        source_files, top_module, extra_args=ea, flatten=flatten,
    )
    result.base_elaboration_sec = prep_time

    emit("cegar_incremental_start", {
        "top_module": top_module,
        "bound": bound,
        "max_iter": max_iter,
        "base_elaboration_sec": round(prep_time, 1),
        "files": len(cached_files),
        "message": "Incremental CEGAR: flatten once, append lemmas incrementally.",
    }, run_subtype="cegar")

    accepted_lemmas: list[str] = []

    for iteration in range(1, max_iter + 1):
        iter_t0 = time.monotonic()
        result.iterations = iteration

        # Step 1/8: K-induction with all accepted lemmas
        t_kind = time.monotonic()
        ind_result = _check_inductive_step(
            cached_files, top_module, accepted_lemmas,
            bound, reset_expr, ea, timeout_per_step_sec,
        )
        kind_sec = time.monotonic() - t_kind

        # Filter cover properties
        real_refuted = sum(
            1 for n, v in (ind_result.property_verdicts or {}).items()
            if v.upper() in ("REFUTED", "FAILED") and "cover" not in n
        )

        if real_refuted == 0 and ind_result.proved > 0 and not ind_result.timed_out:
            result.proved = True
            result.per_iteration_sec.append(time.monotonic() - iter_t0)
            emit("cegar_incremental_proved", {
                "iteration": iteration,
                "lemmas_used": len(accepted_lemmas),
                "proved": ind_result.proved,
                "walltime_decomposition": {
                    "k_induction_sec": round(kind_sec, 3),
                    "total_sec": round(time.monotonic() - iter_t0, 3),
                },
            }, run_subtype="cegar")
            break

        if ind_result.timed_out:
            result.per_iteration_sec.append(time.monotonic() - iter_t0)
            emit("cegar_incremental_timeout", {
                "iteration": iteration,
                "message": "K-induction timed out. Design may be too large.",
                "walltime_decomposition": {
                    "k_induction_sec": round(kind_sec, 3),
                    "total_sec": round(time.monotonic() - iter_t0, 3),
                },
            }, run_subtype="cegar")
            break

        # Step 3: LLM proposes lemma (or use provided proposer)
        if proposer is None:
            result.per_iteration_sec.append(time.monotonic() - iter_t0)
            break

        t_propose = time.monotonic()
        cex = ind_result.stdout or ""
        lemma_sv = proposer(cex, iteration)
        propose_sec = time.monotonic() - t_propose
        if not lemma_sv:
            result.per_iteration_sec.append(time.monotonic() - iter_t0)
            break

        lemma = Lemma(
            hypothesis_sv=lemma_sv,
            iteration=iteration,
        )

        # Step 5: Check lemma from reset (BMC, fast)
        t_base = time.monotonic()
        base_result = _check_base_case(
            cached_files, top_module, lemma_sv,
            bound, reset_expr, ea, timeout_sec=60,
        )
        base_sec = time.monotonic() - t_base
        lemma.base_case_proved = (
            base_result.proved > 0 and base_result.refuted == 0
        )

        iter_total = time.monotonic() - iter_t0
        walltime_decomp = {
            "k_induction_sec": round(kind_sec, 3),
            "proposer_sec": round(propose_sec, 3),
            "base_case_sec": round(base_sec, 3),
            "total_sec": round(iter_total, 3),
        }

        if not lemma.base_case_proved:
            lemma.classification = "bad_lemma"
            result.lemmas.append(lemma)
            result.per_iteration_sec.append(iter_total)
            emit("cegar_incremental_iter", {
                "iteration": iteration,
                "classification": "bad_lemma",
                "walltime_decomposition": walltime_decomp,
            }, run_subtype="cegar")
            continue

        # Step 7: Accept lemma, add to inductive step
        accepted_lemmas.append(lemma_sv)
        lemma.classification = "accepted"
        result.lemmas.append(lemma)
        result.per_iteration_sec.append(iter_total)
        emit("cegar_incremental_iter", {
            "iteration": iteration,
            "classification": "accepted",
            "walltime_decomposition": walltime_decomp,
        }, run_subtype="cegar")

    result.elapsed_sec = time.monotonic() - t0

    emit("cegar_incremental_summary", {
        "proved": result.proved,
        "iterations": result.iterations,
        "lemmas_accepted": len(accepted_lemmas),
        "lemmas_rejected": sum(1 for l in result.lemmas if l.classification == "bad_lemma"),
        "elapsed_sec": round(result.elapsed_sec, 1),
        "base_elaboration_sec": round(result.base_elaboration_sec, 1),
        "per_iteration_sec": [round(s, 1) for s in result.per_iteration_sec],
    }, run_subtype="cegar")

    return result
