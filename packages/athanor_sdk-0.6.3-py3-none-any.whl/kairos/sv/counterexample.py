"""kairos.sv.counterexample — grounded explanation of EBMC counterexamples.

ATH-883: feed an EBMC counterexample trace to an LLM for root-cause
analysis. Guardrail: explanation must reference specific cycles and
signal values FROM the trace. Mechanically verify the explanation only
mentions signals present in the counterexample.

Paid tier — requires LLM call.

Usage::

    from kairos.sv.counterexample import explain

    result = explain(ebmc_result, spec_context="cpu_ooo equivalence")
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from kairos.model_presets import DEFAULT_CLI_PROPOSER_MODEL
from kairos.sv.waveform import WaveformAnalysis, analyze_counterexample


@dataclass
class GroundedExplanation:
    """LLM explanation with grounding verification."""
    explanation: str
    grounded: bool
    signals_referenced: list[str] = field(default_factory=list)
    signals_hallucinated: list[str] = field(default_factory=list)
    cycles_referenced: list[int] = field(default_factory=list)
    verification_status: str = "llm_explained"
    waveform_analysis: WaveformAnalysis | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "explanation": self.explanation,
            "grounded": self.grounded,
            "signals_referenced": self.signals_referenced,
            "signals_hallucinated": self.signals_hallucinated,
            "cycles_referenced": self.cycles_referenced,
            "verification_status": self.verification_status,
        }


def _extract_signal_references(text: str) -> list[str]:
    """Extract signal names referenced in an explanation."""
    refs = re.findall(r"`([a-zA-Z_]\w*(?:\.\w+)*(?:\[\d+(?::\d+)?\])?)`", text)
    refs += re.findall(r"signal\s+`?([a-zA-Z_]\w*(?:\.\w+)*)`?(?:\s+(?:was|is|changed|at|=))", text, re.IGNORECASE)
    return list(dict.fromkeys(refs))


def _extract_cycle_references(text: str) -> list[int]:
    """Extract cycle numbers referenced in an explanation."""
    cycles = re.findall(r"cycle\s+#?(\d+)", text, re.IGNORECASE)
    cycles += re.findall(r"at\s+(?:step|time|cycle)\s+#?(\d+)", text, re.IGNORECASE)
    return sorted(set(int(c) for c in cycles))


def _verify_grounding(
    explanation: str,
    analysis: WaveformAnalysis,
) -> tuple[bool, list[str], list[str]]:
    """Check that an explanation only references signals present in the trace."""
    referenced = _extract_signal_references(explanation)
    observed = set(analysis.signals_observed)

    # Also allow property names and partial matches
    valid = set()
    for sig in referenced:
        if sig in observed:
            valid.add(sig)
        elif any(sig in obs for obs in observed):
            valid.add(sig)
        elif any(obs.endswith(f".{sig}") for obs in observed):
            valid.add(sig)

    hallucinated = [s for s in referenced if s not in valid and s not in observed]
    grounded = len(hallucinated) == 0 or len(referenced) == 0

    return grounded, list(valid), hallucinated


def explain(
    ebmc_stdout: str,
    ebmc_stderr: str = "",
    *,
    counterexample: str | None = None,
    spec_context: str = "",
    model: str | None = None,
    timeout_sec: int = 30,
) -> GroundedExplanation:
    """Generate a grounded LLM explanation of an EBMC counterexample.

    The explanation is mechanically checked: every signal name
    referenced must appear in the actual EBMC trace. Hallucinated
    signals are flagged.

    Args:
        ebmc_stdout: EBMC stdout with property verdicts.
        ebmc_stderr: EBMC stderr.
        counterexample: explicit counterexample text.
        spec_context: description of what the spec checks (for the LLM).
        model: LLM model to use (default: Sonnet).
        timeout_sec: LLM call timeout.

    Returns:
        GroundedExplanation with grounding verification.
    """
    from kairos.observe import emit

    analysis = analyze_counterexample(
        ebmc_stdout, ebmc_stderr, counterexample=counterexample,
    )

    if not analysis.violations:
        return GroundedExplanation(
            explanation="No violations found in the EBMC output.",
            grounded=True,
            waveform_analysis=analysis,
        )

    violation = analysis.violations[0]
    prompt = _build_prompt(violation, analysis, spec_context)

    # Try claude subagent first (zero API cost), fall back to litellm
    explanation_text = ""
    try:
        import subprocess as _sp
        from kairos.sec.closed_loop.claude_proposer import _safe_env
        result = _sp.run(
            ["claude", "-p", prompt, "--output-format", "text", "--max-turns", "1"],
            capture_output=True, text=True, timeout=timeout_sec,
            env=_safe_env(),
        )
        explanation_text = result.stdout.strip() or ""
    except (FileNotFoundError, _sp.TimeoutExpired):
        pass

    if not explanation_text:
        try:
            from kairos.license_scope import require_product
            require_product("solve")
            from kairos.model_client.registry import get_client
            from kairos.observe import observe

            with observe(run_subtype="spec_pipeline", spawn_reason="manual_launch"):
                client = get_client(model or DEFAULT_CLI_PROPOSER_MODEL)
                resp = client.call(
                    [{"role": "user", "content": prompt}],
                    max_tokens=500,
                    timeout=timeout_sec,
                )
            explanation_text = resp.assistant_turn().get("content", "")
        except Exception as e:  # noqa: BLE001
            explanation_text = f"LLM explanation unavailable: {str(e)[:100]}"

    grounded, valid_refs, hallucinated = _verify_grounding(explanation_text, analysis)
    cycles = _extract_cycle_references(explanation_text)

    result = GroundedExplanation(
        explanation=explanation_text,
        grounded=grounded,
        signals_referenced=valid_refs,
        signals_hallucinated=hallucinated,
        cycles_referenced=cycles,
        waveform_analysis=analysis,
    )

    emit("counterexample_explanation", {
        "property": violation.property_name,
        "cycle": violation.cycle,
        "first_divergent_signal": violation.first_divergent_signal,
        "grounded": grounded,
        "hallucinated_signals": hallucinated,
        "verification_status": "llm_explained",
        "explanation_preview": explanation_text[:500],
    }, run_subtype="spec_pipeline")

    return result


def _build_prompt(
    violation: Any,
    analysis: WaveformAnalysis,
    spec_context: str,
) -> str:
    """Build the grounded explanation prompt."""
    signals_str = "\n".join(
        f"  {sig} = {val}"
        for sig, val in sorted(violation.signals_at_violation.items())
    ) if violation.signals_at_violation else "  (no signal values captured)"

    transitions_str = "\n".join(
        f"  cycle {t.cycle}: {t.signal} changed from {t.prev_value} to {t.value}"
        for t in violation.transitions[:10]
    ) if violation.transitions else "  (no transitions captured)"

    return f"""Analyze this EBMC counterexample. Your explanation must ONLY reference
signals and cycles that appear in the trace below. Do not invent signal names.

Property refuted: {violation.property_name}
Violation at cycle: {violation.cycle}
Context: {spec_context or "hardware equivalence verification"}

Signal values at violation:
{signals_str}

Signal transitions leading to violation:
{transitions_str}

First divergent signal: {violation.first_divergent_signal or "unknown"}
First divergent cycle: {violation.first_divergent_cycle or "unknown"}

Explain in 2-3 sentences: what went wrong, which signal caused it, and why.
Reference specific signal names and cycle numbers from the trace above."""
