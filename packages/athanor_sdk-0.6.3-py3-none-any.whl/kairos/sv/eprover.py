"""ATH-705 — E theorem prover (eprover) adapter (OSS Sledgehammer chain).

The E theorem prover is a saturation-based ATP for first-order
classical logic. Binary is `eprover`. Same SZS-format output as
Vampire so the parser shape is similar.

## Free tier

E is open source (https://github.com/eprover/eprover). Free-tier OSS
adapter; no license-gate calls.

## Output

`EProverResult` carries:

  - `verdict`: `"unsat"` (theorem proved) / `"sat"` /
    `"unknown"` / `"timeout"` / `"error"`.
  - `refutation`: when `verdict == "unsat"`, the SZS-format proof
    block. Lean kernel reconstruction (downstream) consumes this.
  - `transcript`, `stderr`, `exit_code`, `elapsed_sec`.

## Why a separate module from `vampire`

The Sledgehammer dispatch picks one prover per goal. E and Vampire
have different strength profiles (E faster on equational, Vampire
stronger on heavily-quantified). Separate modules let the dispatch
table key on the prover, not the binary, and keep test isolation
clean.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass
class EProverResult:
    """Structured outcome from a single `eprover` invocation."""

    verdict: str  # "unsat" | "sat" | "unknown" | "timeout" | "error"
    refutation: str = ""
    transcript: str = ""
    stderr: str = ""
    exit_code: int = 0
    elapsed_sec: float = 0.0
    error: str = ""


def _is_eprover_available() -> bool:
    return shutil.which("eprover") is not None


# Same SZS-format verdict patterns as Vampire (both emit TPTP-standard
# status lines).
_E_UNSAT = re.compile(r"SZS status (?:Theorem|Unsatisfiable)\b", re.I)
_E_SAT = re.compile(r"SZS status (?:Satisfiable|CounterSatisfiable)\b", re.I)
_E_UNKNOWN = re.compile(
    r"SZS status (?:GaveUp|ResourceOut|Timeout|Unknown)\b", re.I
)


def run_eprover(
    tptp_input: str | Path,
    *,
    cpu_limit: int = 60,
    auto_schedule: bool = True,
    proof: bool = True,
    extra_args: list[str] | None = None,
) -> EProverResult:
    """Invoke `eprover` on TPTP input + return a structured verdict.

    Args:
        tptp_input: path to a `.p` / `.tptp` file, or raw TPTP content.
        cpu_limit: CPU-seconds limit (passed as `--cpu-limit`).
        auto_schedule: pass `--auto-schedule` to use E's heuristic
            schedule. Disabling is rarely useful for Sledgehammer.
        proof: emit SZS-format proof block on unsat.
        extra_args: additional CLI args appended verbatim.
    """
    if not _is_eprover_available():
        return EProverResult(
            verdict="error",
            error="eprover not on PATH. Install from "
                  "https://github.com/eprover/eprover",
        )

    cleanup: Path | None = None
    if isinstance(tptp_input, Path) or (
        isinstance(tptp_input, str)
        and not (
            tptp_input.lstrip().startswith(("fof(", "cnf(", "tff(", "thf("))
        )
    ):
        path = Path(tptp_input)
        if not path.is_file():
            return EProverResult(
                verdict="error",
                error=f"tptp_input path does not exist: {path}",
            )
    else:
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=".p", prefix="kairos_eprover_")
        path = Path(tmp)
        with open(fd, "w") as f:
            f.write(tptp_input)
        cleanup = path

    try:
        cmd: list[str] = ["eprover", f"--cpu-limit={cpu_limit}"]
        if auto_schedule:
            cmd.append("--auto-schedule")
        if proof:
            cmd.append("--proof-object")
        if extra_args:
            cmd += list(extra_args)
        cmd.append(str(path))

        t0 = time.monotonic()
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=cpu_limit + 10,
            )
        except subprocess.TimeoutExpired:
            return EProverResult(
                verdict="timeout",
                error=f"eprover wall-timeout after {cpu_limit + 10}s",
                elapsed_sec=float(cpu_limit + 10),
            )

        elapsed = time.monotonic() - t0
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""

        verdict, refutation = _parse_eprover_output(stdout)

        if proc.returncode not in (0, 8) and verdict in ("error", "unknown"):
            return EProverResult(
                verdict="error",
                transcript=stdout,
                stderr=stderr,
                exit_code=proc.returncode,
                elapsed_sec=elapsed,
                error=f"eprover exit {proc.returncode}; "
                      f"stderr: {stderr.strip()[:300]}",
            )

        return EProverResult(
            verdict=verdict,
            refutation=refutation,
            transcript=stdout,
            stderr=stderr,
            exit_code=proc.returncode,
            elapsed_sec=elapsed,
        )
    finally:
        if cleanup is not None:
            try:
                cleanup.unlink()
            except OSError:
                pass


def _parse_eprover_output(stdout: str) -> tuple[str, str]:
    """Parse eprover's stdout into `(verdict, refutation)`.

    SZS format same as Vampire. Refutation block is bounded by
    `# SZS output start CNFRefutation` / `# SZS output end ...`.
    """
    if _E_UNSAT.search(stdout):
        verdict = "unsat"
    elif _E_SAT.search(stdout):
        verdict = "sat"
    elif _E_UNKNOWN.search(stdout):
        verdict = "unknown"
    else:
        verdict = "error"

    refutation = ""
    if verdict == "unsat":
        # E uses '#' as the SZS comment leader, not '%'.
        start = stdout.find("# SZS output start")
        end = stdout.find("# SZS output end")
        if start != -1 and end != -1:
            # Find the end of the line containing the end marker.
            line_end = stdout.find("\n", end)
            if line_end == -1:
                line_end = len(stdout)
            refutation = stdout[start:line_end]

    return verdict, refutation


__all__ = [
    "EProverResult",
    "run_eprover",
]
