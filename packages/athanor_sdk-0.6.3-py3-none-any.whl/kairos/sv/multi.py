"""kairos.sv.multi — multi-abstraction verification with the sandwich rule (ATH-412a).

Customer writes one YAML file with N layers (functional / performance /
block / etc.), each with an assertion set + backends list. SDK dispatches
per-layer, aggregates under the sandwich rule: each assertion must be
closed (PROVED) by ≥2 distinct backends with zero refutations across
any backend to earn SANDWICH_PROVED. Single-backend layers earn
SINGLE_PROVED (degraded, but explicit). Any refutation collapses the
layer to REFUTED.

Multi-engine sandwich: EBMC itself ships three engines (`bmc`,
`k-induction`, `ic3`) that are genuinely different decision procedures.
Two of them agreeing on an assertion is already a meaningful sandwich,
so this module ships with three EBMC-hosted backends registered:

    ebmc          — default (SAT + default EBMC solve loop)
    ebmc_kind     — forced k-induction (--k-induction)
    ebmc_ic3      — IC3 / PDR engine (--ic3)

Lean / Dafny / Hypothesis / Brian2 / NKI backends plug in later via
the same dispatch table; YAML consumers never care which engine lives
behind a backend name.

## YAML schema

```yaml
module: reno_cca            # top_module for every EBMC invocation
spec_file: TelosReno_k10.sv # path relative to the YAML, or absolute
bound: 10                    # default bound (can be overridden per layer)
timeout_sec: 60              # default timeout (can be overridden per layer)
layers:
  functional:
    assertions: [p_cwnd_ge_mss, p_cwnd_halves_on_loss]
    backends: [ebmc, ebmc_kind]
  performance:
    assertions: [p_no_starvation_within_k]
    backends: [ebmc, ebmc_ic3]
```
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Literal

import yaml  # type: ignore[import-not-found]

from kairos.sv.ebmc import EbmcResult, run_ebmc


# ─── YAML dataclasses ────────────────────────────────────────────────


@dataclass
class LayerSpec:
    """One layer of a multi-abstraction spec."""

    name: str
    assertions: list[str]
    backends: list[str]
    bound: int | None = None
    timeout_sec: int | None = None


@dataclass
class MultiSpec:
    """A parsed YAML multi-abstraction spec."""

    module: str
    spec_file: Path
    bound: int
    timeout_sec: int
    layers: list[LayerSpec]


def load_spec(yaml_path: str | Path) -> MultiSpec:
    """Parse a multi-abstraction YAML file.

    Resolves `spec_file` relative to the YAML's directory if not absolute.
    """
    # ATH-845: typed exceptions so `except MalformedYamlSpec`
    # branches cleanly. yaml_path included so customer sees which
    # file was malformed.
    from kairos.errors import MalformedYamlSpec

    yaml_path = Path(yaml_path)
    data = yaml.safe_load(yaml_path.read_text()) or {}
    module = data.get("module")
    spec_file_raw = data.get("spec_file")
    if not module or not spec_file_raw:
        raise MalformedYamlSpec(
            "must include top-level `module` and `spec_file`",
            yaml_path=str(yaml_path),
        )
    spec_file = Path(spec_file_raw)
    if not spec_file.is_absolute():
        spec_file = (yaml_path.parent / spec_file).resolve()

    raw_layers = data.get("layers") or {}
    if not isinstance(raw_layers, dict) or not raw_layers:
        raise MalformedYamlSpec(
            "must include non-empty `layers` mapping",
            yaml_path=str(yaml_path),
        )

    layers: list[LayerSpec] = []
    for name, cfg in raw_layers.items():
        if not isinstance(cfg, dict):
            raise MalformedYamlSpec(
                f"layer {name!r} must be a mapping",
                yaml_path=str(yaml_path),
            )
        assertions = cfg.get("assertions") or []
        backends = cfg.get("backends") or []
        if not assertions:
            raise MalformedYamlSpec(
                f"layer {name!r} needs at least one assertion",
                yaml_path=str(yaml_path),
            )
        if not backends:
            raise MalformedYamlSpec(
                f"layer {name!r} needs at least one backend",
                yaml_path=str(yaml_path),
            )
        layers.append(LayerSpec(
            name=str(name),
            assertions=[str(a) for a in assertions],
            backends=[str(b) for b in backends],
            bound=cfg.get("bound"),
            timeout_sec=cfg.get("timeout_sec"),
        ))

    return MultiSpec(
        module=str(module),
        spec_file=spec_file,
        bound=int(data.get("bound", 10)),
        timeout_sec=int(data.get("timeout_sec", 60)),
        layers=layers,
    )


# ─── Backend dispatch table ──────────────────────────────────────────

# A backend is a callable that, given (sv_file, top_module, bound,
# timeout_sec), returns an EbmcResult (or equivalent shape with
# `proved`, `refuted`, `property_verdicts`). Lean / Dafny / Hypothesis
# backends will grow this table without changing the dispatcher.
BackendFn = Callable[..., EbmcResult]


def _ebmc_default(sv_file: Path, top_module: str, bound: int, timeout_sec: int) -> EbmcResult:
    return run_ebmc(
        sv_file, top_module=top_module, bound=bound, timeout_sec=timeout_sec,
    )


def _ebmc_kind(sv_file: Path, top_module: str, bound: int, timeout_sec: int) -> EbmcResult:
    return run_ebmc(
        sv_file, top_module=top_module, bound=bound, timeout_sec=timeout_sec,
        extra_args=["--k-induction"],
    )


def _ebmc_ic3(sv_file: Path, top_module: str, bound: int, timeout_sec: int) -> EbmcResult:
    return run_ebmc(
        sv_file, top_module=top_module, bound=bound, timeout_sec=timeout_sec,
        extra_args=["--ic3"],
    )


BACKENDS: dict[str, BackendFn] = {
    # Distinct explicit names — anti-bloat §6.2: concrete distinct
    # behaviour gets a distinct name. `ebmc` (no suffix) stays registered
    # as an alias for back-compat with existing YAML specs; customers
    # adding variants in new specs should prefer the explicit names.
    "ebmc_bmc": _ebmc_default,
    "ebmc_kind": _ebmc_kind,
    "ebmc_ic3": _ebmc_ic3,
    # Back-compat alias: `ebmc` resolves to the default BMC engine
    # (what `ebmc` with no flags does — matches hw-cbmc's own default).
    "ebmc": _ebmc_default,
}


def register_backend(name: str, fn: BackendFn) -> None:
    """Register a new backend callable under `name`.

    External packages (dafny, lean, hypothesis wrappers) call this at
    import time to extend the sandwich rule's evidence set. When a
    tool ships multiple variants (e.g. `lean` + `lean_aristotle`), each
    variant registers under a distinct name — no variant kwargs. This
    matches the dispatcher's `--verifier name[,name...]` surface and
    keeps `registered_backends()` honest.
    """
    if not name or not callable(fn):
        raise ValueError("register_backend requires a non-empty name + callable fn")
    BACKENDS[name] = fn


def registered_backends() -> list[str]:
    """Return the sorted list of every currently-registered backend name.

    Used by `athanor sv-multi --list-backends` (and by downstream ATH-418
    SDK expose) to discover which engines are available without
    hard-coding the dispatch table.
    """
    return sorted(BACKENDS)


# ─── Per-layer aggregation ──────────────────────────────────────────


LayerOutcome = Literal[
    "SANDWICH_PROVED",  # ≥2 backends PROVED every named assertion, 0 refutations
    "SINGLE_PROVED",    # exactly 1 backend PROVED every named assertion
    "REFUTED",          # any backend refuted any named assertion
    "PARTIAL",          # ≥1 named assertion missing from EBMC output on some backend
    "ERROR",            # backend crash / unknown backend name
]


@dataclass
class AssertionVerdict:
    """Per-assertion, per-backend verdict."""

    assertion: str
    backend: str
    verdict: str  # "PROVED" | "REFUTED" | "MISSING" | "ERROR"


@dataclass
class LayerResult:
    """One layer's aggregated outcome."""

    name: str
    assertions: list[str]
    backends: list[str]
    per_assertion_verdicts: list[AssertionVerdict]
    outcome: LayerOutcome
    reason: str = ""
    elapsed_sec: float = 0.0


@dataclass
class MultiResult:
    """Full multi-abstraction run."""

    spec_file: Path
    module: str
    layers: list[LayerResult]
    overall: LayerOutcome  # worst-of-layers

    def summary_lines(self) -> list[str]:
        lines = [f"multi-abstraction: {self.module} ({self.spec_file.name})"]
        for lr in self.layers:
            lines.append(
                f"  {_glyph(lr.outcome)} {lr.name}: {lr.outcome}"
                + (f" — {lr.reason}" if lr.reason else "")
            )
            # Compact per-backend summary: one line per assertion.
            for a in lr.assertions:
                backend_line = ", ".join(
                    f"{v.backend}={v.verdict}"
                    for v in lr.per_assertion_verdicts
                    if v.assertion == a
                )
                lines.append(f"      {a}: {backend_line}")
        lines.append(f"overall: {self.overall}")
        return lines


def _glyph(outcome: LayerOutcome) -> str:
    return {
        "SANDWICH_PROVED": "✓✓",
        "SINGLE_PROVED": "✓",
        "REFUTED": "✗",
        "PARTIAL": "?",
        "ERROR": "!",
    }.get(outcome, "-")


def _aggregate_layer(
    layer: LayerSpec,
    per_assertion: list[AssertionVerdict],
) -> tuple[LayerOutcome, str]:
    """Apply the sandwich rule to per-assertion verdicts."""
    # Fast-fail: any REFUTED collapses the layer.
    refuted = [v for v in per_assertion if v.verdict == "REFUTED"]
    if refuted:
        names = ", ".join(sorted({v.assertion for v in refuted}))
        return "REFUTED", f"refuted by at least one backend: {names}"

    errored = [v for v in per_assertion if v.verdict == "ERROR"]
    if errored:
        names = ", ".join(sorted({v.backend for v in errored}))
        return "ERROR", f"backend error(s): {names}"

    # Every (assertion, backend) pair is either PROVED or MISSING.
    # For each assertion, count distinct backends that PROVED it.
    per_assertion_count: dict[str, set[str]] = {a: set() for a in layer.assertions}
    missing: list[str] = []
    for v in per_assertion:
        if v.verdict == "PROVED":
            per_assertion_count[v.assertion].add(v.backend)
        elif v.verdict == "MISSING":
            missing.append(f"{v.assertion}@{v.backend}")

    min_backends = min(
        (len(bs) for bs in per_assertion_count.values()),
        default=0,
    )
    distinct_backends = len(set(layer.backends))

    if missing:
        return (
            "PARTIAL",
            f"{len(missing)} (assertion, backend) pair(s) missing from EBMC output: "
            + ", ".join(missing[:5]) + ("…" if len(missing) > 5 else ""),
        )
    if min_backends >= 2:
        return "SANDWICH_PROVED", "every assertion proved by ≥2 backends"
    if min_backends == 1 and distinct_backends == 1:
        return "SINGLE_PROVED", (
            "one-backend layer (sandwich rule requires ≥2 distinct backends; "
            "upgrade by adding another backend under this layer)"
        )
    # distinct_backends > 1 but one of them failed to PROVE an assertion
    # without a REFUTED/MISSING — should not reach here, but keep the
    # guard honest.
    return "PARTIAL", "incomplete coverage across declared backends"


# ─── Driver ──────────────────────────────────────────────────────────


def run_multi(yaml_path: str | Path) -> MultiResult:
    """Run a multi-abstraction spec end-to-end.

    For each layer, dispatch each declared backend on the spec file,
    collect per-assertion verdicts, then aggregate under the sandwich
    rule. Returns a MultiResult with per-layer outcomes + an overall
    worst-of-layers verdict.
    """
    # ATH-686 P1: programmatic run_multi entry → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    import time

    spec = load_spec(yaml_path)
    if not spec.spec_file.is_file():
        raise FileNotFoundError(f"spec_file not found: {spec.spec_file}")

    layer_results: list[LayerResult] = []
    for layer in spec.layers:
        bound = layer.bound if layer.bound is not None else spec.bound
        timeout = layer.timeout_sec if layer.timeout_sec is not None else spec.timeout_sec

        per_assertion: list[AssertionVerdict] = []
        t0 = time.time()
        for backend_name in layer.backends:
            fn = BACKENDS.get(backend_name)
            if fn is None:
                for a in layer.assertions:
                    per_assertion.append(AssertionVerdict(
                        assertion=a, backend=backend_name, verdict="ERROR",
                    ))
                continue
            try:
                r = fn(spec.spec_file, spec.module, bound, timeout)
            except Exception:  # noqa: BLE001 — backend may raise varied
                for a in layer.assertions:
                    per_assertion.append(AssertionVerdict(
                        assertion=a, backend=backend_name, verdict="ERROR",
                    ))
                continue

            verdicts = r.property_verdicts or {}
            # Property names in EBMC output may be hierarchically
            # qualified (e.g. "reno_cca.p_cwnd_ge_mss"); match by
            # trailing suffix so YAML can use local names.
            for a in layer.assertions:
                match = None
                for full_name, v in verdicts.items():
                    if full_name == a or full_name.endswith("." + a):
                        match = v.upper()
                        break
                if match is None:
                    per_assertion.append(AssertionVerdict(
                        assertion=a, backend=backend_name, verdict="MISSING",
                    ))
                    continue
                if match in ("PROVED",):
                    verdict = "PROVED"
                elif match in ("REFUTED", "FAILED"):
                    verdict = "REFUTED"
                else:
                    verdict = match  # UNKNOWN / etc — aggregator treats as error
                per_assertion.append(AssertionVerdict(
                    assertion=a, backend=backend_name, verdict=verdict,
                ))

        outcome, reason = _aggregate_layer(layer, per_assertion)
        layer_results.append(LayerResult(
            name=layer.name,
            assertions=list(layer.assertions),
            backends=list(layer.backends),
            per_assertion_verdicts=per_assertion,
            outcome=outcome,
            reason=reason,
            elapsed_sec=time.time() - t0,
        ))

    # Worst-of rollup: REFUTED > ERROR > PARTIAL > SINGLE_PROVED > SANDWICH_PROVED.
    rank: dict[LayerOutcome, int] = {
        "SANDWICH_PROVED": 0,
        "SINGLE_PROVED": 1,
        "PARTIAL": 2,
        "ERROR": 3,
        "REFUTED": 4,
    }
    overall: LayerOutcome = "SANDWICH_PROVED"
    for lr in layer_results:
        if rank[lr.outcome] > rank[overall]:
            overall = lr.outcome

    return MultiResult(
        spec_file=spec.spec_file,
        module=spec.module,
        layers=layer_results,
        overall=overall,
    )
