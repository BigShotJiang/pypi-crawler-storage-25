"""kairos.sv.mutations — hardware-RTL mutation operator catalogue.

Customer-facing copy of the builder's internal mutation-sweep
catalogue (athanor-builder/solve/shared/verilog/mutation_catalogue.py).
Standard academic mutation-testing primitives — nothing proprietary.

Used by `kairos.sv.invariants.discover_invariants` (ATH-411) to
drive reverse-mutation-kill invariant discovery: enumerate mutants,
find the ones the customer's current property suite misses, then
propose new invariants that catch them.

--- original docstring below ---

hardware-RTL mutation operator catalogue.

Each operator takes a source string and returns a list of
`(mutated_source, description)` pairs — one per site where the mutation
can be applied. Phase 2 (mutation sweep) applies each mutant, re-runs
EBMC, and asserts the mutant gets caught by at least one `assert
property`. A strong fix kills > 75% of mutants.

Vertical-agnostic (runs against any SystemVerilog or NuSMV source).
Mirrors the shape of `solve/neuron/mutation_operators.py` but operates
on raw strings via regex substitutions — we don't have a proper Verilog
AST available in this sandbox, and the 1-char regex mutations used by
the hw-cbmc scorer's anti-cheat stubs are sufficient for killing the
interesting bug classes.

Each mutation targets a specific failure class known to produce
undetected bugs if the property suite is too weak:

- `flip_nonblocking_to_blocking` — `<=` → `=`. Should be caught by any
   pipelined property (forwarding / latency / 2-cycle consistency).
- `flip_add_to_sub` / `flip_sub_to_add` — arithmetic sign flips. Kills
   any counter or accumulator property.
- `flip_eq_to_neq` — `==` → `!=` and vice versa. Breaks compare logic.
- `flip_and_to_or` / `flip_or_to_and` — boolean logic swap. Catches
   combinational-gate wiring properties.
- `drop_reset_branch` — remove the `if (reset) begin ... end` initializer.
   Catches every reset-safety property.
- `off_by_one_bound` — `< N` → `<= N` and vice versa. Catches loop
   termination properties.
- `flip_left_right_shift` — `<<` → `>>`. Catches shift-register
   correctness properties.
- `flip_posedge_negedge` — `posedge clk` → `negedge clk`. Catches
   setup/hold / synchronous-write properties.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable


@dataclass
class Mutant:
    source: str             # mutated SV/SMV source
    description: str        # "line N: `<=` → `=`"
    operator: str           # e.g. "flip_nonblocking_to_blocking"
    original_line: str      # line from original source for the UI
    mutated_line: str       # corresponding line in the mutant


def _locate_line(source: str, offset: int) -> tuple[int, str]:
    """Return (1-based line number, line text) at byte offset."""
    line_no = source.count("\n", 0, offset) + 1
    line_start = source.rfind("\n", 0, offset) + 1
    line_end = source.find("\n", offset)
    if line_end < 0:
        line_end = len(source)
    return line_no, source[line_start:line_end]


def _apply_single_regex_mutation(
    source: str,
    pattern: re.Pattern,
    replacement: Callable[[re.Match], str],
    operator_name: str,
    human_op: str,
) -> list[Mutant]:
    """Emit one mutant per match of `pattern`.

    Each mutant substitutes exactly one occurrence of the pattern; the
    rest of the source is unchanged. This keeps the mutation sweep
    tractable (N mutants, one site each).
    """
    out: list[Mutant] = []
    matches = list(pattern.finditer(source))
    for m in matches:
        new_text = replacement(m)
        mutated = source[: m.start()] + new_text + source[m.end():]
        line_no, original_line = _locate_line(source, m.start())
        # Corresponding line in the mutant: same line number, but with the
        # substitution applied.
        _, mutated_line = _locate_line(mutated, m.start())
        out.append(
            Mutant(
                source=mutated,
                description=f"line {line_no}: {human_op}",
                operator=operator_name,
                original_line=original_line.strip(),
                mutated_line=mutated_line.strip(),
            )
        )
    return out


# ── Individual operators ──────────────────────────────────────────────


def flip_nonblocking_to_blocking(source: str) -> list[Mutant]:
    # Match `<=` NOT inside `<=`, `>=`, `==`, `!=`. The lookbehind rejects
    # the `<` of `<=` itself; also reject comparison operators.
    pat = re.compile(r"(?<![<>!=])<=(?!=)")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "=",
        "flip_nonblocking_to_blocking", "`<=` → `=`",
    )


def flip_blocking_to_nonblocking(source: str) -> list[Mutant]:
    # Match `=` used as a blocking assignment. We're picky here: only
    # when preceded by whitespace-then-identifier and followed by
    # whitespace (to avoid `==` or `<=`). Fires less than you'd expect
    # but fires cleanly on true blocking assigns in `always @(*)` blocks.
    pat = re.compile(r"(?<=[\w\]])\s*=(?![=<>])\s*")
    # Too aggressive; limit to lines matching `X = Y;` shape.
    pat = re.compile(r"^(\s*\w[\w\.\[\]:]*\s*)=(\s*[^;=<>!].*;)", re.MULTILINE)
    return _apply_single_regex_mutation(
        source, pat, lambda m: f"{m.group(1)}<={m.group(2)}",
        "flip_blocking_to_nonblocking", "`=` → `<=`",
    )


def flip_add_to_sub(source: str) -> list[Mutant]:
    # Only plain `+` — skip `++`, `+=`, `+:`.
    pat = re.compile(r"(?<![+:])\+(?![+=:])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "-",
        "flip_add_to_sub", "`+` → `-`",
    )


def flip_sub_to_add(source: str) -> list[Mutant]:
    # Only plain `-` — skip `--`, `-=`, `-:`, `->`.
    pat = re.compile(r"(?<![-:])-(?![-=:>])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "+",
        "flip_sub_to_add", "`-` → `+`",
    )


def flip_eq_to_neq(source: str) -> list[Mutant]:
    pat = re.compile(r"==(?!=)")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "!=",
        "flip_eq_to_neq", "`==` → `!=`",
    )


def flip_and_to_or(source: str) -> list[Mutant]:
    # Bitwise `&` (not `&&` — keep logical AND untouched). SV uses `&`
    # for combinational logic; breaking it changes the circuit.
    pat = re.compile(r"(?<![&])&(?![&=])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "|",
        "flip_and_to_or", "`&` → `|`",
    )


def flip_or_to_and(source: str) -> list[Mutant]:
    pat = re.compile(r"(?<![|])\|(?![|=])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "&",
        "flip_or_to_and", "`|` → `&`",
    )


def off_by_one_lt(source: str) -> list[Mutant]:
    # `<` → `<=` (off-by-one in loop bounds / compare). Skip the `<=` and
    # `<<` forms.
    pat = re.compile(r"(?<![<])<(?![<=])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "<=",
        "off_by_one_lt", "`<` → `<=` (off-by-one)",
    )


def off_by_one_gt(source: str) -> list[Mutant]:
    pat = re.compile(r"(?<![>])>(?![>=])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: ">=",
        "off_by_one_gt", "`>` → `>=` (off-by-one)",
    )


def flip_left_right_shift(source: str) -> list[Mutant]:
    pat = re.compile(r"<<(?![<=])")
    return _apply_single_regex_mutation(
        source, pat, lambda m: ">>",
        "flip_left_right_shift", "`<<` → `>>`",
    )


def flip_posedge_negedge(source: str) -> list[Mutant]:
    pat = re.compile(r"\bposedge\b")
    return _apply_single_regex_mutation(
        source, pat, lambda m: "negedge",
        "flip_posedge_negedge", "`posedge` → `negedge`",
    )


def drop_reset_branch(source: str) -> list[Mutant]:
    # Remove `if (reset) begin ... end` blocks. Used as a "does the fix
    # properly re-initialise state on reset?" test. Only removes the
    # first occurrence per-mutant.
    pat = re.compile(
        r"if\s*\(\s*reset\s*\)\s*begin\s+(.*?)\s+end\s+else\s+",
        re.DOTALL,
    )
    return _apply_single_regex_mutation(
        source, pat, lambda m: "",
        "drop_reset_branch", "remove `if (reset) begin ... end else`",
    )


# ── NuSMV-specific mutations ──────────────────────────────────────────


def flip_smv_case_arm(source: str) -> list[Mutant]:
    """Flip `token = pX : pY;` cycling in a NuSMV ASSIGN block.

    Substitutes `p0 → p1 → p2 → p0` with `p0 → p2` (dropping the
    intermediate state). Catches token-ring / mutual-exclusion
    properties on smv_ring3-class tasks.
    """
    # Look for `p0 : pN;` in a case statement and substitute `p0 : p0;`.
    pat = re.compile(r"\bp([012])\s*:\s*p([012])\s*;")
    def rep(m: re.Match) -> str:
        return f"p{m.group(1)} : p{m.group(1)};"
    return _apply_single_regex_mutation(
        source, pat, rep,
        "flip_smv_case_arm", "NuSMV ASSIGN: pX → pX (kill cycling)",
    )


# ── Catalogue ──────────────────────────────────────────────────────────


# SV operators: applied to .sv files.
SV_OPERATORS: list[Callable[[str], list[Mutant]]] = [
    flip_nonblocking_to_blocking,
    flip_blocking_to_nonblocking,
    flip_add_to_sub,
    flip_sub_to_add,
    flip_eq_to_neq,
    flip_and_to_or,
    flip_or_to_and,
    off_by_one_lt,
    off_by_one_gt,
    flip_left_right_shift,
    flip_posedge_negedge,
    drop_reset_branch,
]

# SMV operators: applied to .smv files.
SMV_OPERATORS: list[Callable[[str], list[Mutant]]] = [
    flip_smv_case_arm,
    flip_eq_to_neq,   # NuSMV uses `=` but `!=` patterns too; safe no-op if absent
]


def enumerate_mutants(source: str, *, is_smv: bool = False) -> list[Mutant]:
    """Apply every operator in the relevant catalogue, return flat list.

    Each operator may emit 0..N mutants. Phase 2 then compiles + runs
    EBMC on each and tallies the kill rate.
    """
    operators = SMV_OPERATORS if is_smv else SV_OPERATORS
    out: list[Mutant] = []
    for op in operators:
        try:
            out.extend(op(source))
        except Exception:  # pragma: no cover — don't crash on one bad site  # noqa: BLE001 — skip to next iteration on any error
            continue
    return out
