"""kairos.sv.invariants — reverse-mutation-kill invariant discovery (ATH-411).

Customer's problem: they've written a spec with some assertions. They
don't know what properties are MISSING. Current mutation testing tells
them "your property suite caught N of M mutants" — useful signal but
not actionable. They still have to hand-write new assertions to catch
the surviving mutants.

This module closes the loop. For each mutation that the current
property suite fails to catch, we ask an LLM to propose a new
`assert property (...)` that WOULD catch it. Each candidate goes
through two deterministic gates before reaching the customer:

  1. **Original-preservation gate** — does the proposed invariant
     hold on the ORIGINAL (unmutated) spec? If not, the candidate
     is over-strong (would break the real spec); drop.

  2. **Mutant-kill gate** — does the proposed invariant FAIL on the
     mutant? If not, the candidate doesn't actually detect the
     mutation; drop.

Only candidates that pass both gates are returned. Customers can
then manually review + paste into their spec.

Design mirrors `kairos.sv.cegar` — same proposer / gate scaffolding,
different end: CEGAR proposes `assume property` to close refutations,
this proposes `assert property` to catch mutations.

Public surface:

    from kairos.sv import (
        discover_invariants,
        InvariantDiscoveryResult,
        SurvivingMutant,
        InvariantCandidate,
        CandidateVerdict,
    )
"""
from __future__ import annotations

import json
import re
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from kairos.sv.ebmc import EbmcResult, run_ebmc
from kairos.sv.mutations import Mutant, enumerate_mutants


# ─── Dataclasses ─────────────────────────────────────────────────────


@dataclass
class SurvivingMutant:
    """A mutant that the current property suite fails to catch."""

    mutant: Mutant
    ebmc_result: EbmcResult  # every assertion PROVED under this mutation


@dataclass
class InvariantCandidate:
    """One LLM-proposed assertion aimed at killing a specific mutant."""

    assertion_sv: str  # e.g. `assert property (@(posedge clk) cwnd >= 8'd1);`
    rationale: str
    target_mutant: str  # description from Mutant.description
    confidence: float


@dataclass
class CandidateVerdict:
    """Outcome of running a candidate through the two gates."""

    candidate: InvariantCandidate
    holds_on_original: bool
    kills_mutant: bool
    accepted: bool
    rejection_reason: str = ""


@dataclass
class InvariantDiscoveryResult:
    """Full discovery run across enumerated mutants."""

    spec_path: Path
    top_module: str
    bound: int
    mutants_enumerated: int
    mutants_killed_by_existing: int
    mutants_surviving: int
    proposals: list[CandidateVerdict] = field(default_factory=list)
    total_cost_usd: float = 0.0
    total_elapsed_sec: float = 0.0
    overall: str = "UNKNOWN"  # FULL_COVERAGE | PARTIAL | NO_PROPOSALS | NO_SURVIVING

    def summary_lines(self) -> list[str]:
        out = [
            f"invariant-discovery: {self.mutants_enumerated} mutant(s) enumerated, "
            f"{self.mutants_killed_by_existing} killed by existing suite, "
            f"{self.mutants_surviving} surviving.",
        ]
        accepted = [v for v in self.proposals if v.accepted]
        for v in accepted:
            out.append(
                f"  ✓ kills {v.candidate.target_mutant!r}:\n"
                f"      {v.candidate.assertion_sv}\n"
                f"      reason: {v.candidate.rationale[:120]}"
            )
        rejected = [v for v in self.proposals if not v.accepted]
        for v in rejected:
            out.append(
                f"  ✗ rejected for {v.candidate.target_mutant!r}: {v.rejection_reason}"
            )
        out.append(f"overall: {self.overall}")
        return out


# ─── Proposer (LLM-backed) ───────────────────────────────────────────


ProposerFn = Callable[[str], tuple[InvariantCandidate, float]]
"""Signature: prompt_text → (candidate, cost_usd). Raises ValueError on parse failure."""


PROPOSER_PROMPT = """\
You are proposing a SystemVerilog `assert property` invariant to catch a mutation.

The customer's original spec is provided. Mutation testing identified
one specific change that their current assertion suite FAILS to catch
— EBMC proves the spec clean even with this bug injected. The
customer wants a new assertion that would have surfaced the bug.

## Original spec

```verilog
{{SPEC}}
```

## Mutation (what was changed)

Description: {{MUTANT_DESCRIPTION}}

Original line: `{{ORIGINAL_LINE}}`
Mutated line:  `{{MUTATED_LINE}}`

(Diff applied at: {{MUTANT_OPERATOR}})

## Prior attempts

{{PRIOR_ATTEMPTS}}

## Your task

Propose exactly ONE `assert property (...)` that:

1. **Holds on the original spec.** EBMC must prove it clean against
   the original (unmutated) source. Candidates that break the
   original spec are dropped silently.

2. **Fails on the mutated spec.** EBMC must refute it when the
   mutation is applied. That's the whole point — we need the
   assertion to EXPOSE the mutation.

3. **Is as specific as possible to the mutation.** Avoid broad
   invariants that coincidentally catch this mutation alongside
   many others; prefer invariants targeting the exact behavioral
   deviation the mutation introduces (e.g. if the mutation flips
   `+` to `-`, the invariant should probe the sum's correctness
   directly).

## Output contract

Emit exactly one JSON object. No surrounding prose.

```json
{
  "assertion_sv": "assert property (@(posedge clk) <body>);",
  "rationale": "One sentence: what this assertion checks and why the mutation breaks it.",
  "target_mutant": "<copy the mutation description verbatim>",
  "confidence": 0.0 to 1.0
}
```

## Hard rules

1. **Use `assert property (...)` not `assume property (...)`** — this
   is the inverse of CEGAR. We're DETECTING bad behavior, not
   assuming environmental constraints.
2. **Posedge clk** unless the property is combinational; match the
   clocking style of the existing spec.
3. **Use only signals declared in the original spec.** Don't invent
   new wires.
4. **Keep it short.** One clock, one concern.
5. **Never propose an assertion that's already in the spec.**
"""


def make_proposer(model: str | None = None) -> "ProposerFn":
    """Build a proposer callable bound to a specific model ID.

    Default sourced from
    ``kairos.model_presets.DEFAULT_INVARIANT_PROPOSER_MODEL``
    (currently Sonnet 4.6 — best quality, ~$0.01-0.02/call at 3K-in +
    500-out). For cheap-and-good-enough experiments, call with:
      make_proposer("openai/kimi-k2.5")          # ~10x cheaper
      make_proposer("gemini/gemini-2.5-flash")   # ~30x cheaper
    Reasoning models auto-get a 16k-token budget via ATH-399's
    model-aware default; no extra config needed.

    litellm is imported lazily inside the returned proposer — this
    module is transitively imported by `kairos.sv` (customer-facing
    surface), which must load cleanly when the multi-model extra is
    NOT installed (default `pip install athanor-sdk`).
    """
    # ATH-816: resolve default from the preset module.
    if model is None:
        from kairos.model_presets import DEFAULT_INVARIANT_PROPOSER_MODEL
        model = DEFAULT_INVARIANT_PROPOSER_MODEL
    # Resolve max_tokens via ATH-399's model-aware table so reasoning
    # models (kimi, gemini-2.5-*) don't silently truncate.
    from kairos.providers import default_max_tokens_for
    max_tokens = default_max_tokens_for(model)

    def _proposer(prompt_text: str) -> tuple[InvariantCandidate, float]:
        from kairos.model_client.registry import get_client

        client = get_client(model)
        resp = client.call(
            [{"role": "user", "content": prompt_text}],
            max_tokens=max_tokens,
            temperature=0.0,
        )
        content = resp.assistant_turn().get("content", "")
        cost = getattr(resp, "cost_usd", 0.0) or 0.0
        candidate = _parse_candidate_json(content, model=model)
        return candidate, float(cost)

    return _proposer


# Build on first access, not at module load (lazy — same rationale as
# the lazy litellm import in make_proposer above).
_default_proposer_cache: "ProposerFn | None" = None


def _get_default_proposer() -> "ProposerFn":
    global _default_proposer_cache
    if _default_proposer_cache is None:
        _default_proposer_cache = make_proposer()
    return _default_proposer_cache


_JSON_BLOCK_RE = re.compile(r"```json\s*(\{.*?\})\s*```", re.DOTALL)
_BARE_JSON_RE = re.compile(r"(\{(?:[^{}]|\{[^{}]*\})*\})", re.DOTALL)


def _parse_candidate_json(content: str, *, model: str = "<unknown>") -> InvariantCandidate:
    """Extract the first JSON object from the proposer's response.

    ATH-845: raises :class:`kairos.errors.LLMOutputParseError` on
    malformed/missing JSON so customers can `except
    LLMOutputParseError` to branch on proposer-failure vs other
    SDK errors. (Pre-fix: bare ``ValueError`` required string-match
    parsing of the message to disambiguate.)
    """
    from kairos.errors import LLMOutputParseError
    m = _JSON_BLOCK_RE.search(content)
    raw = m.group(1) if m else None
    if raw is None:
        m = _BARE_JSON_RE.search(content)
        if not m:
            raise LLMOutputParseError(
                model,
                raw_output_head=content,
                parse_error="no JSON block in proposer response",
            )
        raw = m.group(1)
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise LLMOutputParseError(
            model,
            raw_output_head=raw,
            parse_error=f"malformed JSON: {exc}",
        ) from exc
    return InvariantCandidate(
        assertion_sv=str(obj.get("assertion_sv", "")),
        rationale=str(obj.get("rationale", "")),
        target_mutant=str(obj.get("target_mutant", "")),
        confidence=float(obj.get("confidence", 0.5)),
    )


def _render_prompt(
    template: str,
    *,
    spec: str,
    mutant: Mutant,
    prior_attempts: str,
) -> str:
    return (
        template
        .replace("{{SPEC}}", spec)
        .replace("{{MUTANT_DESCRIPTION}}", mutant.description)
        .replace("{{ORIGINAL_LINE}}", mutant.original_line)
        .replace("{{MUTATED_LINE}}", mutant.mutated_line)
        .replace("{{MUTANT_OPERATOR}}", mutant.operator)
        .replace("{{PRIOR_ATTEMPTS}}", prior_attempts or "(none — first proposal)")
    )


# ─── Splice + gate primitives ────────────────────────────────────────


def splice_assertion(spec_text: str, assertion_sv: str) -> str:
    """Insert a candidate `assert property (...)` just before endmodule.

    The assertion must be a complete statement ending in `;`. If
    missing the trailing semicolon we add one. If the assertion is
    labelled (e.g. `p_new: assert property (...);`) we honor the
    label; otherwise we auto-name it `swarm_invariant_candidate`
    to keep EBMC's per-property verdicts legible.
    """
    idx = spec_text.rfind("endmodule")
    if idx < 0:
        # ATH-845: typed exception so customers can branch on
        # `except MalformedSystemVerilogSpec` cleanly.
        from kairos.errors import MalformedSystemVerilogSpec
        raise MalformedSystemVerilogSpec("spec has no `endmodule`")

    body = assertion_sv.strip()
    if not body.endswith(";"):
        body += ";"
    # If the caller didn't supply a label, auto-name it so EBMC's
    # per-property output is traceable.
    if not re.match(r"^\s*[A-Za-z_][A-Za-z_0-9]*\s*:\s*assert\s+property", body):
        body = f"swarm_invariant_candidate:\n    {body}"
    block = f"\n  // invariant-discovery candidate\n  {body}\n"
    return spec_text[:idx] + block + spec_text[idx:]


def _run_gate(
    source: str,
    top_module: str,
    bound: int,
    timeout_sec: int,
    label: str,
    spec_dir: Path,
) -> EbmcResult:
    """Write the spliced source to a tempfile in `spec_dir` + run EBMC."""
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".sv", delete=False, dir=spec_dir,
        prefix=f".inv_gate_{label}_",
    ) as tf:
        tf.write(source)
        path = Path(tf.name)
    try:
        return run_ebmc(path, top_module=top_module, bound=bound, timeout_sec=timeout_sec)
    finally:
        path.unlink(missing_ok=True)


# ─── Main driver ─────────────────────────────────────────────────────


def discover_invariants(
    spec_file: str | Path,
    *,
    top_module: str,
    bound: int = 10,
    max_mutants: int = 20,
    max_proposals_per_mutant: int = 2,
    timeout_sec: int = 60,
    proposer: ProposerFn | None = None,
    model: str | None = None,
    is_smv: bool = False,
) -> InvariantDiscoveryResult:
    """Run reverse-mutation-kill invariant discovery.

    For each mutation that the current property suite fails to catch,
    prompt the proposer for a new assertion and verify it kills the
    mutant without breaking the original spec.

    Args:
        spec_file: path to the SV/SMV spec
        top_module: EBMC top module
        bound: BMC bound k for the gates
        max_mutants: cap on mutants enumerated (large specs can produce
            hundreds; triage by prioritising the first `max_mutants`)
        max_proposals_per_mutant: how many proposer attempts per
            surviving mutant before giving up
        timeout_sec: per-EBMC-invocation timeout
        proposer: injection point for testing (stub LLM). Default
            uses Sonnet via Azure.
        is_smv: set True for NuSMV specs (uses the SMV operator set)

    Returns:
        InvariantDiscoveryResult with per-mutant verdicts.
    """
    # ATH-686 P1: programmatic discover_invariants entry → license gate.
    from kairos.license_scope import require_product
    require_product("solve")

    # ATH-614 phase 2: every solver path opens a session() so the
    # platform UI can synthesise what the run was doing. The proposer
    # below issues `litellm.completion(...)` per-mutant; this bracket
    # makes those calls observable end-to-end.
    from kairos.prove import session
    spec_path = Path(spec_file)
    with session(
        task_id=f"sv-invariants:{spec_path.stem}",
        name_for_display=f"sv-invariants/{spec_path.stem}",
        vertical="sysverilog",
        run_subtype="autoformalize",
    ):
        return _discover_invariants_unsessioned(
            spec_file=spec_file, top_module=top_module, bound=bound,
            max_mutants=max_mutants,
            max_proposals_per_mutant=max_proposals_per_mutant,
            timeout_sec=timeout_sec, proposer=proposer, model=model,
            is_smv=is_smv,
        )


def _discover_invariants_unsessioned(
    *,
    spec_file: str | Path,
    top_module: str,
    bound: int,
    max_mutants: int,
    max_proposals_per_mutant: int,
    timeout_sec: int,
    proposer: ProposerFn | None,
    model: str | None,
    is_smv: bool,
) -> InvariantDiscoveryResult:
    """Body of `discover_invariants`. Extracted so the public entry
    point can wrap it in `kairos.session()` (ATH-614 phase 2) without
    re-indenting 100 lines of EBMC dispatch."""

    spec_path = Path(spec_file)
    if not spec_path.is_file():
        raise FileNotFoundError(f"spec file not found: {spec_path}")
    original = spec_path.read_text()
    spec_dir = spec_path.parent
    t_start = time.monotonic()

    if proposer is None:
        proposer = make_proposer(model) if model else _get_default_proposer()

    # Enumerate mutants.
    all_mutants = enumerate_mutants(original, is_smv=is_smv)
    mutants_enumerated = len(all_mutants)
    mutants = all_mutants[:max_mutants]  # cap to keep run tractable

    # Step 1: run EBMC on each mutant; classify killed vs surviving.
    survivors: list[SurvivingMutant] = []
    killed_count = 0
    for mut in mutants:
        r = _run_gate(
            mut.source, top_module, bound, timeout_sec,
            label=f"mutant_{mut.operator}", spec_dir=spec_dir,
        )
        if r.refuted > 0:
            # Current suite catches this mutant.
            killed_count += 1
        elif r.exit_code != 0 and r.proved == 0 and not r.timed_out:
            # EBMC crashed — treat as "unknown", skip.
            continue
        else:
            survivors.append(SurvivingMutant(mutant=mut, ebmc_result=r))

    proposals: list[CandidateVerdict] = []
    total_cost = 0.0

    # Step 2: for each surviving mutant, propose → gate → accept/reject.
    for sm in survivors:
        prior_attempts = ""
        for attempt in range(max_proposals_per_mutant):
            prompt = _render_prompt(
                PROPOSER_PROMPT,
                spec=original, mutant=sm.mutant,
                prior_attempts=prior_attempts,
            )
            try:
                candidate, cost = proposer(prompt)
                total_cost += cost
            except Exception as exc:  # noqa: BLE001 — broad-catch fallback
                proposals.append(CandidateVerdict(
                    candidate=InvariantCandidate(
                        assertion_sv="", rationale="",
                        target_mutant=sm.mutant.description, confidence=0.0,
                    ),
                    holds_on_original=False, kills_mutant=False, accepted=False,
                    rejection_reason=f"proposer error: {type(exc).__name__}: {exc}",
                ))
                break

            # Gate 1: does it hold on the original?
            original_spliced = splice_assertion(original, candidate.assertion_sv)
            r_orig = _run_gate(
                original_spliced, top_module, bound, timeout_sec,
                label="hold_on_original", spec_dir=spec_dir,
            )
            # Accept iff swarm_invariant_candidate is PROVED (or labeled
            # assertion is PROVED) AND nothing else regressed. We treat
            # any new refutation as a fail.
            if r_orig.refuted > 0:
                verdict = CandidateVerdict(
                    candidate=candidate,
                    holds_on_original=False, kills_mutant=False, accepted=False,
                    rejection_reason="assertion does not hold on original spec",
                )
                proposals.append(verdict)
                prior_attempts += (
                    f"\n- attempt {attempt+1}: {candidate.assertion_sv!r} — "
                    f"rejected (breaks original spec)"
                )
                continue

            # Gate 2: does it kill the mutant?
            mutant_spliced = splice_assertion(sm.mutant.source, candidate.assertion_sv)
            r_mut = _run_gate(
                mutant_spliced, top_module, bound, timeout_sec,
                label="kill_mutant", spec_dir=spec_dir,
            )
            if r_mut.refuted == 0:
                verdict = CandidateVerdict(
                    candidate=candidate,
                    holds_on_original=True, kills_mutant=False, accepted=False,
                    rejection_reason="assertion holds on BOTH original AND mutant — no-op",
                )
                proposals.append(verdict)
                prior_attempts += (
                    f"\n- attempt {attempt+1}: {candidate.assertion_sv!r} — "
                    f"rejected (did not catch the mutant)"
                )
                continue

            # Both gates pass — accepted.
            proposals.append(CandidateVerdict(
                candidate=candidate,
                holds_on_original=True, kills_mutant=True, accepted=True,
            ))
            break  # done with this mutant; move to next

    total_elapsed = time.monotonic() - t_start
    accepted_count = sum(1 for v in proposals if v.accepted)
    if mutants_enumerated == 0:
        overall = "NO_PROPOSALS"
    elif not survivors:
        overall = "NO_SURVIVING"
    elif accepted_count == len(survivors):
        overall = "FULL_COVERAGE"
    elif accepted_count == 0:
        overall = "NO_PROPOSALS"
    else:
        overall = "PARTIAL"

    return InvariantDiscoveryResult(
        spec_path=spec_path,
        top_module=top_module,
        bound=bound,
        mutants_enumerated=mutants_enumerated,
        mutants_killed_by_existing=killed_count,
        mutants_surviving=len(survivors),
        proposals=proposals,
        total_cost_usd=round(total_cost, 4),
        total_elapsed_sec=round(total_elapsed, 2),
        overall=overall,
    )

# CI re-trigger 2026-04-21 03:30Z (force workflow on latest branch HEAD)
