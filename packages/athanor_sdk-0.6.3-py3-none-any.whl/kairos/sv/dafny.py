"""ATH-706 — Dafny adapter (final OSS Sledgehammer chain link).

Dafny verifies imperative methods against pre/post-conditions by
translating to Boogie IR + discharging via Z3. This adapter is the
Python wrapper around `dafny verify`; same shape as kairos.sv.{ebmc,
cvc5, cbmc, vampire, eprover}.

## Free tier

Dafny is open source (https://github.com/dafny-lang/dafny). Adapter
ships in the free-tier OSS Sledgehammer surface. No license-gate calls.

## Output

`DafnyResult` carries:

  - `verdict`: `"verified"` (all methods proved) /
    `"verification_failed"` / `"compile_error"` /
    `"timeout"` / `"error"`.
  - `failed_methods`: list of `(method_name, reason)` tuples when the
    verdict is failed.
  - `counterexample`: text block of any failing assertion's
    counter-model, if Dafny emitted one.
  - `transcript`, `stderr`, `exit_code`, `elapsed_sec`.

## Reconstruction note (asabi 1855Z)

Dafny outputs Boogie IR, not SMT-LIB direct. v0 scope here: surface
pass/fail per method + counterexample text. Full Boogie-to-Lean
kernel reconstruction is a v1 enhancement and likely lives on the
Lean side anyway. The Python adapter just wraps the binary
invocation.

## Failure modes

- `dafny` not on PATH → `verdict="error"` with install hint.
- Subprocess timeout → `verdict="timeout"`.
- Source compile error → `verdict="compile_error"`.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DafnyResult:
    """Structured outcome from a single `dafny verify` invocation."""

    verdict: str  # "verified" | "verification_failed" | "compile_error" | "timeout" | "error"
    failed_methods: list[tuple[str, str]] = field(default_factory=list)
    counterexample: str = ""
    transcript: str = ""
    stderr: str = ""
    exit_code: int = 0
    elapsed_sec: float = 0.0
    error: str = ""


def _is_dafny_available() -> bool:
    return shutil.which("dafny") is not None


# Dafny's failed-method line shape (Dafny 4.x):
#   foo.dfy(12,5): Error: a postcondition might not hold on this return path
# Subsequent lines often carry "Related location" + the assertion
# description. Conservatively capture (file, line) + the Error text.
_FAILED_LINE_RE = re.compile(
    r"^(?P<file>\S+\.dfy)\((?P<line>\d+),\d+\):\s*Error:\s*(?P<reason>.+)$",
    re.MULTILINE,
)


def run_dafny(
    dfy_file: str | Path,
    *,
    timeout_sec: int = 120,
    extra_args: list[str] | None = None,
) -> DafnyResult:
    """Invoke `dafny verify` on a `.dfy` file + return a structured verdict.

    Args:
        dfy_file: path to the Dafny source.
        timeout_sec: hard wall timeout. Dafny is slower than the SMT
            solvers it dispatches to; default 120s reflects that.
        extra_args: additional CLI args appended verbatim
            (e.g. `["--cores", "1"]`, `["--no-verify"]` for compile-only).

    Free-tier (no license required). Dafny is open-source.
    """
    if not _is_dafny_available():
        return DafnyResult(
            verdict="error",
            error="dafny not on PATH. Install from "
                  "https://github.com/dafny-lang/dafny",
        )

    src = Path(dfy_file)
    if not src.is_file():
        return DafnyResult(
            verdict="error",
            error=f"dfy_file does not exist: {src}",
        )

    cmd: list[str] = ["dafny", "verify", str(src)]
    if extra_args:
        cmd += list(extra_args)

    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
        )
    except subprocess.TimeoutExpired:
        return DafnyResult(
            verdict="timeout",
            error=f"dafny verify timed out after {timeout_sec}s",
            elapsed_sec=float(timeout_sec),
        )

    elapsed = time.monotonic() - t0
    stdout = proc.stdout or ""
    stderr = proc.stderr or ""

    verdict, failed, counterexample = _parse_dafny_output(stdout, stderr)

    # Dafny exit codes: 0 = success, 4 = verification failed,
    # other = parse / type / internal error. Map non-(0, 4) to error
    # when our parser didn't produce a positive verdict.
    if proc.returncode not in (0, 4) and verdict in ("verified",
                                                       "verification_failed"):
        # Unusual case: parser said pass/fail but Dafny exited weird.
        # Trust the parser; surface exit code in error string.
        pass
    if (
        proc.returncode not in (0, 4)
        and verdict not in ("verified", "verification_failed")
    ):
        return DafnyResult(
            verdict=(
                "compile_error" if "syntax error" in stderr.lower()
                or "syntax error" in stdout.lower()
                else "error"
            ),
            transcript=stdout,
            stderr=stderr,
            exit_code=proc.returncode,
            elapsed_sec=elapsed,
            error=f"dafny exit {proc.returncode}; "
                  f"stderr: {stderr.strip()[:300]}",
        )

    return DafnyResult(
        verdict=verdict,
        failed_methods=failed,
        counterexample=counterexample,
        transcript=stdout,
        stderr=stderr,
        exit_code=proc.returncode,
        elapsed_sec=elapsed,
    )


def _parse_dafny_output(
    stdout: str, stderr: str,
) -> tuple[str, list[tuple[str, str]], str]:
    """Parse dafny's stdout/stderr into `(verdict, failed_methods, counterexample)`."""
    failed: list[tuple[str, str]] = []
    combined = stdout + "\n" + stderr

    # Dafny emits a summary line: "Dafny program verifier finished
    # with N verified, M errors". Use that for the verdict.
    summary = re.search(
        r"Dafny program verifier finished with (\d+) verified, (\d+) errors",
        combined,
    )
    if summary:
        n_errors = int(summary.group(2))
        if n_errors == 0:
            return "verified", failed, ""
        verdict = "verification_failed"
    else:
        # No summary line — might be a compile error or our run didn't
        # reach verification.
        if any(
            t in combined for t in ("syntax error", "Parse error",
                                       "syntax errors")
        ):
            return "compile_error", failed, ""
        verdict = "error"

    # Collect failed assertion lines.
    for m in _FAILED_LINE_RE.finditer(combined):
        failed.append((m.group("file") + f":{m.group('line')}",
                       m.group("reason").strip()))

    # Dafny counterexample (when --get-counterexample passed): block
    # starts with "Counterexample:" or includes "Could not generate
    # counterexample". Best-effort capture.
    counterexample = ""
    cx_start = combined.find("Counterexample:")
    if cx_start != -1:
        cx_end = combined.find("\n\n", cx_start)
        if cx_end == -1:
            cx_end = len(combined)
        counterexample = combined[cx_start:cx_end]

    return verdict, failed, counterexample


__all__ = [
    "DafnyResult",
    "run_dafny",
]
