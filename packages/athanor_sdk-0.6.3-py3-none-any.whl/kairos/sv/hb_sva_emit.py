"""kairos.sv.hb_sva_emit — POViolation → SVA lowering (ATH-412 Part B slice 3).

Lowers a happens-before cycle (``POViolation``) into a SystemVerilog
Assertion that EBMC can cross-check against the RTL. When EBMC
refutes the emitted assertion, that's an independent hardware-level
confirmation the HB cycle is realizable.

## Lowering rules

One assertion per cycle. For a cycle ``E0 → E1 → ... → E(n-1) → E0``
with edges ``e0, e1, ..., e(n-1)`` (where ``ei`` goes from ``Ei`` to
``E((i+1) mod n)``):

- **PROGRAM_ORDER**: within the same block, no added temporal delay —
  just an implication step. Lowered as ``&&``.
- **SYNCHRONIZATION**: cross-block via explicit handshake. Adds a
  one-cycle gap: ``##1``.
- **OBSERVATION**: a Read observes a prior Write. Uses ``$past(X)``
  to reference the observed value.
- **INIT_EDGE**: synthetic boundary; emits a stability pattern so the
  cycle is grounded at t=0.

The emitted assertion is a **witness**: if EBMC proves the assertion
holds, the HB cycle is realizable and the design is broken. If EBMC
refutes the assertion, the cycle is NOT achievable under the current
RTL (may be dead code / guarded by a hidden invariant — further
triage needed).

## Output shape

``emit_sva_for_violation`` returns a single SVA snippet ready to
paste into a ``module ... endmodule`` body:

```systemverilog
// ATH-412 HB cycle witness over 3 event(s)
hb_witness_<signals>:
  assert property (@(posedge <clk>)
    <lowered pattern>);
```

``emit_all_sva`` returns a concatenation over every ``POViolation``
in a graph (one block-comment-separated assertion per cycle).

## Non-goals (slice 3 scope)

- No auto-placement into the customer's source — caller splices the
  returned string wherever they want (typically between the last
  ``endmodule`` decl and the closing brace for EBMC's include path)
- No ``$inferring_clocking`` detection — caller picks the clock name
- No property-block / sequence-operator factoring — each assertion is
  standalone, one per cycle
"""

from __future__ import annotations

from kairos.sv.hb_graph import (
    EdgeKind,
    Event,
    EventKind,
    HBEdge,
    HBGraph,
    POViolation,
    find_po_violations,
)


# ─── Per-edge lowering ──────────────────────────────────────────────


def _event_expr(event: Event) -> str:
    """Expr that references an event's signal at the current cycle."""
    if event.kind == EventKind.WRITE:
        return f"(__write_{event.signal})"
    if event.kind == EventKind.HANDSHAKE:
        return f"({event.signal})"
    if event.kind == EventKind.READ:
        return f"({event.signal})"
    if event.kind == EventKind.INIT:
        return "(!$stable(1'b1))"
    if event.kind == EventKind.FENCE:
        return "(1'b1 /* fence */)"
    return "(1'b1)"


def _edge_connector(edge: HBEdge, src: Event, dst: Event) -> str:
    """Return the SVA connector (``##N`` / ``&&`` / etc.) for an edge.

    Args:
        edge: the HB edge.
        src: Event at edge.src (for OBSERVATION lowering context).
        dst: Event at edge.dst.

    Returns:
        A string inserted between the two event-expressions. The
        connector determines the temporal shape of the chain.
    """
    if edge.kind == EdgeKind.PROGRAM_ORDER:
        return " && "
    if edge.kind == EdgeKind.SYNCHRONIZATION:
        return " ##1 "
    if edge.kind == EdgeKind.OBSERVATION:
        return " ##1 "
    if edge.kind == EdgeKind.INIT_EDGE:
        return " |-> "
    return " && "


def _sanitize_signal_name(name: str) -> str:
    """SV identifier sanitization — keep alphanumeric + underscore."""
    return "".join(c if (c.isalnum() or c == "_") else "_" for c in name)


def _assertion_label(violation: POViolation) -> str:
    """Deterministic label for an HB-cycle assertion."""
    tokens = []
    for eid in violation.cycle_events[:3]:
        tokens.append(_sanitize_signal_name(eid))
    head = "__".join(tokens)
    return f"hb_witness_{head}"[:80]


# ─── Single-violation lowering ──────────────────────────────────────


def emit_sva_for_violation(
    violation: POViolation,
    graph: HBGraph,
    *,
    clock: str = "clk",
    disable_signal: str | None = None,
) -> str:
    """Lower a single POViolation to one SVA assertion.

    Args:
        violation: the cycle to emit.
        graph: the parent HBGraph (used to resolve Events by id).
        clock: clock signal name for ``@(posedge ...)``. Default ``clk``.
        disable_signal: optional disable-iff signal (typically ``rst``
            or ``reset``). When provided, wraps the assertion in
            ``disable iff (disable_signal)`` so reset doesn't
            spuriously fire the witness.

    Returns:
        Multi-line SVA snippet. Caller splices into a module body.
    """
    if violation.size < 2:
        raise ValueError(
            f"POViolation must have size >= 2; got {violation.size}"
        )

    # Order edges around the cycle. cycle_edges is an unordered set of
    # internal edges; we walk from the first event deterministically.
    member = set(violation.cycle_events)
    ordered_edges: list[HBEdge] = []
    visited: set[str] = set()
    cur = violation.cycle_events[0]
    while True:
        visited.add(cur)
        outgoing = [e for e in graph.outgoing(cur) if e.dst in member]
        if not outgoing:
            break
        # Prefer an edge to an unvisited node; if all visited, pick any.
        unvisited = [e for e in outgoing if e.dst not in visited]
        next_edge = unvisited[0] if unvisited else outgoing[0]
        ordered_edges.append(next_edge)
        cur = next_edge.dst
        if cur == violation.cycle_events[0] and len(ordered_edges) > 0:
            # Completed one full lap
            break
        if len(ordered_edges) > len(violation.cycle_events):
            break  # safety: don't loop forever on weird shapes

    # Build the chain: event_expr<e0> <connector0> event_expr<e1> ...
    parts: list[str] = []
    for i, edge in enumerate(ordered_edges):
        src_ev = graph.events[edge.src]
        dst_ev = graph.events[edge.dst]
        parts.append(_event_expr(src_ev))
        parts.append(_edge_connector(edge, src_ev, dst_ev))
    # Close the chain with the final event expression.
    if ordered_edges:
        final_ev = graph.events[ordered_edges[-1].dst]
        parts.append(_event_expr(final_ev))
    pattern = "".join(parts)

    label = _assertion_label(violation)
    disable_clause = f"disable iff ({disable_signal}) " if disable_signal else ""

    lines = [
        f"// ATH-412 HB cycle witness over {violation.size} event(s):",
    ]
    for eid in violation.cycle_events:
        ev = graph.events[eid]
        lines.append(f"//   {eid} [{ev.kind.value}:{ev.signal} @ {ev.block}]")
    lines.extend([
        f"{label}:",
        f"  assert property (@(posedge {clock}) {disable_clause}",
        f"    {pattern});",
    ])
    return "\n".join(lines)


# ─── Graph-level bulk lowering ──────────────────────────────────────


def emit_all_sva(
    graph: HBGraph,
    *,
    clock: str = "clk",
    disable_signal: str | None = None,
) -> str:
    """Run cycle detection + emit one SVA per violation.

    Returns:
        Concatenated SVA text. Empty string when the graph has no
        PO violations (a clean DAG).
    """
    violations = find_po_violations(graph)
    if not violations:
        return ""
    chunks: list[str] = [
        "// =====================================================",
        f"// ATH-412 Part B: {len(violations)} HB cycle witness(es)",
        "// =====================================================",
    ]
    for v in violations:
        chunks.append("")
        chunks.append(
            emit_sva_for_violation(
                v, graph,
                clock=clock,
                disable_signal=disable_signal,
            )
        )
    return "\n".join(chunks)


# ─── Public surface ─────────────────────────────────────────────────


__all__ = [
    "emit_sva_for_violation",
    "emit_all_sva",
]
