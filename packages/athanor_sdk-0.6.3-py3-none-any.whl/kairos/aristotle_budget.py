"""ATH-1283 (sub-(c) of ATH-1274 Pillar 7) — Aristotle CLI cost-budget wrapper.

Wraps ``kairos.aristotle.submit_tarball`` with three structural cost defenses:

1. **Per-call cap** (wall-minutes + estimated-tokens). Sets the submit
   subprocess timeout to ``max_minutes * 60`` and pre-validates the
   estimated-token-cost against a per-call ceiling.
2. **Per-queue-day budget** (24h rolling, default ``$20``). Sums all
   recorded burn rows < 24h old; refuses dispatch when the sum + the
   estimated cost of THIS call would exceed the budget.
3. **Burn-row emit** on every dispatch (allow / deny_per_call /
   deny_per_day) for the standup-readout consumer.

v1 backend: JSONL file at ``~/.athanor/aristotle_burn.jsonl``. The
Supabase ``aristotle_queue_burn`` schema proposed in the ATH-1283 ticket
is the v2 backend; deferring it until research validates the schema
shape + writes a migration. The JSONL backend is wire-compatible with
the proposed schema (same field names + types), so v2 is a swap of the
read/write functions, not a re-design.

Why a thin wrapper module instead of patching ``submit_tarball``
directly: the existing ``submit_tarball`` is the SDK-customer-facing
entry; customers without licenses for Aristotle should keep getting a
clean fall-through. Budget-class refusals are a separate concern that
should only fire when the customer EXPLICITLY chose the budgeted path.
Wrapping keeps the policy gate opt-in and out of the customer hot
path.

## Refusal contract

``submit_with_budget`` raises :class:`AristotleCapBreach` (subclass of
:class:`LicenseScopeError` so existing audit-log wiring catches it) on
ANY cap breach. No silent fallback to ``submit_tarball``. The caller
decides whether to retry with reduced scope, wait for the budget
window to roll, or abandon the dispatch.

## Customer-facing critical

Every Aristotle-budgeted dispatch in kairos passes through this
wrapper. Blast radius:

* False ``allow`` → real cost overrun. The ATH-1266 90%-budget
  pressure-class is the prior incident.
* False ``deny_per_call`` → a legitimate Aristotle proof is rejected.
* False ``deny_per_day`` → all Aristotle dispatch is rejected for
  the rest of the 24h window.

Mutation receipts in the test suite exercise each refusal class.
"""
from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from kairos.errors import LicenseScopeError

logger = logging.getLogger(__name__)


# ─── config + constants ───────────────────────────────────────────────


_DEFAULT_BURN_LOG = Path.home() / ".athanor" / "aristotle_burn.jsonl"
_DEFAULT_DAY_BUDGET_USD = 20.00
_DEFAULT_PER_CALL_MAX_USD = 5.00
_DEFAULT_PER_CALL_MAX_MINUTES = 30
_DAY_WINDOW_SEC = 24 * 60 * 60


# ─── exception ────────────────────────────────────────────────────────


class AristotleCapBreach(LicenseScopeError):
    """Raised when an Aristotle dispatch would breach a cost cap.

    Extends :class:`LicenseScopeError` so existing audit-log wiring
    (``kairos.audit_log``) catches the refusal class without
    additional plumbing.

    The ``decision`` attribute names the breach class:
    ``"deny_per_call"`` (wall-time or token cap) or
    ``"deny_per_day"`` (24h rolling budget exhausted).
    """

    def __init__(self, message: str, *, decision: str, reason: str) -> None:
        super().__init__(message)
        self.decision = decision
        self.reason = reason


# ─── burn row ─────────────────────────────────────────────────────────


@dataclass
class BurnRow:
    """One row of the aristotle_queue_burn ledger.

    Field names + types intentionally match the proposed Supabase
    ``aristotle_queue_burn`` schema in ATH-1283 so the v2 backend swap
    is a read/write-function change, not a re-design.
    """

    agent: str
    call_class: str
    cost_usd: float
    wall_minutes: float
    decision: str
    reason: str = ""
    tokens_in: int | None = None
    tokens_out: int | None = None
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_jsonl(self) -> str:
        return json.dumps(asdict(self), separators=(",", ":"))


# ─── backend (JSONL v1; Supabase v2-deferred) ─────────────────────────


def _ensure_burn_log(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()


def record_burn(
    row: BurnRow,
    *,
    burn_log: Path = _DEFAULT_BURN_LOG,
) -> None:
    """Append ``row`` to the burn-log JSONL.

    Failure mode: log the I/O error to stderr + swallow. The cost
    tracker MUST NOT crash a dispatch because the ledger write failed
    (per the ``_audit_swallows_io_errors`` pattern in audit_log.py).
    """
    try:
        _ensure_burn_log(burn_log)
        # Concurrent appends are safe without an explicit lock: POSIX
        # O_APPEND atomically positions the cursor before each write,
        # and a single JSONL line is well under PIPE_BUF (~4 KB), so
        # writes don't interleave between concurrent processes. Per
        # AZURE-VM-RESEARCH cross-arm review on PR #668 (GitHub issuecomment-4452741958, 2026-05-14T16:49Z) — v1
        # discipline; revisit if rows ever exceed PIPE_BUF.
        with burn_log.open("a") as f:
            f.write(row.to_jsonl())
            f.write("\n")
    except OSError as e:
        logger.warning(
            "aristotle_budget: burn-row write to %s failed: %s. Dispatch "
            "continues; ledger is now stale for this row.",
            burn_log, e,
        )


def read_today_burn(
    *,
    agent: str | None = None,
    burn_log: Path = _DEFAULT_BURN_LOG,
    now: float | None = None,
) -> tuple[float, int]:
    """Return ``(total_cost_usd, call_count)`` over the last 24h.

    When ``agent`` is provided, filter to that agent only; otherwise
    sum across all agents (the per-queue-day cap is fleet-wide, not
    per-agent — agent filter is used by the standup-readout
    consumer).
    """
    if not burn_log.exists():
        return 0.0, 0
    threshold = (now if now is not None else time.time()) - _DAY_WINDOW_SEC
    total = 0.0
    count = 0
    try:
        with burn_log.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                row_ts = _parse_iso(row.get("created_at", ""))
                if row_ts is None or row_ts < threshold:
                    continue
                if agent is not None and row.get("agent") != agent:
                    continue
                if row.get("decision") != "allow":
                    # Refused dispatches don't burn budget; skip them
                    # from the rolling sum.
                    continue
                cost = row.get("cost_usd")
                if isinstance(cost, (int, float)):
                    total += float(cost)
                    count += 1
    except OSError as e:
        logger.warning(
            "aristotle_budget: burn-log read from %s failed: %s. "
            "Treating as empty for this dispatch (fail-open within "
            "this single read; subsequent reads retry).",
            burn_log, e,
        )
        return 0.0, 0
    return total, count


def _parse_iso(ts: str) -> float | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError):
        return None


# ─── public wrapper API ───────────────────────────────────────────────


def submit_with_budget(
    *,
    submit_callable: Callable[..., Any],
    submit_kwargs: dict[str, Any],
    estimated_cost_usd: float,
    call_class: str,
    agent: str,
    max_minutes: int = _DEFAULT_PER_CALL_MAX_MINUTES,
    max_per_call_usd: float = _DEFAULT_PER_CALL_MAX_USD,
    day_budget_usd: float | None = None,
    burn_log: Path = _DEFAULT_BURN_LOG,
) -> Any:
    """Wrap an Aristotle submit call with cost-budget enforcement.

    Args:
        submit_callable: typically ``kairos.aristotle.submit_tarball``.
            Injected for testability — the real wrapper passes
            ``submit_tarball`` here.
        submit_kwargs: kwargs forwarded to ``submit_callable``. The
            ``timeout_sec`` key is set to ``max_minutes * 60`` if not
            already provided.
        estimated_cost_usd: pre-call cost estimate (from
            ``solve_runs.token_cost_usd`` p90 for the matching
            call_class). Used for the per-call + per-day caps.
        call_class: the dispatch class label (e.g. ``"prove"``,
            ``"refine"``). Stored on the burn row for per-class p90
            calibration in future runs.
        agent: which agent is dispatching. Stored on the burn row for
            standup-readout per-agent attribution.
        max_minutes: per-call wall-time cap. Default 30 min.
        max_per_call_usd: per-call cost cap. Default $5.
        day_budget_usd: per-queue-day total cap. Default $20 from
            ``ARISTOTLE_DAY_BUDGET_USD`` env or constant.
        burn_log: JSONL ledger path. Default
            ``~/.athanor/aristotle_burn.jsonl``.

    Returns:
        Whatever ``submit_callable(**submit_kwargs)`` returns
        (typically :class:`kairos.aristotle.AristotleSubmission`).

    Raises:
        AristotleCapBreach with ``decision="deny_per_call"`` when the
            estimated cost exceeds ``max_per_call_usd``.
        AristotleCapBreach with ``decision="deny_per_day"`` when the
            24h rolling sum + estimated cost exceeds the day budget.
    """
    day_cap = (
        day_budget_usd
        if day_budget_usd is not None
        else _resolve_day_budget()
    )

    # Per-call cost cap (cheap check first).
    if estimated_cost_usd > max_per_call_usd:
        reason = (
            f"per_call_cost_cap_exceeded: estimated ${estimated_cost_usd:.2f} > "
            f"cap ${max_per_call_usd:.2f}"
        )
        record_burn(
            BurnRow(
                agent=agent, call_class=call_class,
                cost_usd=estimated_cost_usd, wall_minutes=0.0,
                decision="deny_per_call", reason=reason,
            ),
            burn_log=burn_log,
        )
        raise AristotleCapBreach(
            f"Aristotle dispatch blocked: {reason}",
            decision="deny_per_call", reason=reason,
        )

    # Per-queue-day budget check.
    today_total, _ = read_today_burn(burn_log=burn_log)
    projected = today_total + estimated_cost_usd
    if projected > day_cap:
        reason = (
            f"per_day_budget_exhausted: today ${today_total:.2f} + "
            f"estimated ${estimated_cost_usd:.2f} = ${projected:.2f} > "
            f"day_budget ${day_cap:.2f}"
        )
        record_burn(
            BurnRow(
                agent=agent, call_class=call_class,
                cost_usd=estimated_cost_usd, wall_minutes=0.0,
                decision="deny_per_day", reason=reason,
            ),
            burn_log=burn_log,
        )
        raise AristotleCapBreach(
            f"Aristotle dispatch blocked: {reason}",
            decision="deny_per_day", reason=reason,
        )

    # Set the submit-subprocess timeout to max_minutes if caller didn't
    # already set one tighter. submit_kwargs may have been pre-built by
    # the caller; respect a tighter explicit timeout.
    kwargs = dict(submit_kwargs)
    caller_timeout = kwargs.get("timeout_sec")
    max_minutes_sec = max_minutes * 60
    if caller_timeout is None or caller_timeout > max_minutes_sec:
        kwargs["timeout_sec"] = max_minutes_sec

    # Dispatch.
    start = time.monotonic()
    try:
        result = submit_callable(**kwargs)
    finally:
        wall_minutes = (time.monotonic() - start) / 60.0

    # Only successful dispatches reach this record_burn. If
    # submit_callable raises (e.g. subprocess.TimeoutExpired), the
    # finally above captures wall_minutes but the exception propagates,
    # so no ledger row is written. This is intentional — timeouts +
    # other dispatch failures do not count toward the per-day budget
    # (no successful dispatch occurred). Per AZURE-VM-RESEARCH cross-
    # arm 2026-05-14 ts 1778773... ; a failed-dispatch-tracking
    # extension is a v2 follow-up (separate ticket).
    record_burn(
        BurnRow(
            agent=agent, call_class=call_class,
            cost_usd=estimated_cost_usd, wall_minutes=wall_minutes,
            decision="allow", reason="",
        ),
        burn_log=burn_log,
    )

    return result


# ─── standup-readout (consumer) ───────────────────────────────────────


def standup_readout(
    *,
    burn_log: Path = _DEFAULT_BURN_LOG,
    now: float | None = None,
    agents: tuple[str, ...] = ("research", "qa", "platform"),
) -> str:
    """Build the per-agent Aristotle burn block for the standup body.

    Returns a markdown string suitable for direct injection into the
    standup-cron output.
    """
    day_cap = _resolve_day_budget()
    total_all, total_calls = read_today_burn(burn_log=burn_log, now=now)
    headroom_pct = (
        max(0.0, (1.0 - total_all / day_cap) * 100.0)
        if day_cap > 0 else 0.0
    )

    lines = ["Aristotle burn this cycle:"]
    for a in agents:
        agent_total, agent_calls = read_today_burn(
            agent=a, burn_log=burn_log, now=now,
        )
        lines.append(
            f"  {a}: ${agent_total:.2f} ({agent_calls} calls)"
        )
    lines.append(
        f"  TOTAL: ${total_all:.2f} / ${day_cap:.2f} budget "
        f"({headroom_pct:.0f}% headroom)"
    )
    return "\n".join(lines)


# ─── internal ─────────────────────────────────────────────────────────


def _resolve_day_budget() -> float:
    env = os.environ.get("ARISTOTLE_DAY_BUDGET_USD", "").strip()
    if env:
        try:
            return float(env)
        except ValueError:
            logger.warning(
                "aristotle_budget: ARISTOTLE_DAY_BUDGET_USD=%r is not "
                "numeric; falling back to default $%.2f.",
                env, _DEFAULT_DAY_BUDGET_USD,
            )
    return _DEFAULT_DAY_BUDGET_USD
