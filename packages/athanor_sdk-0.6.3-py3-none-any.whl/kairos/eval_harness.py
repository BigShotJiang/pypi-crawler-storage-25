"""Evaluate AI models on environment tasks using LiteLLM.

Shared harness used by every `athanor-ai` environment. Each env ships a
~10-line `scripts/evaluate.py` shim that imports `main` from this module.

Spawns an AI agent that attempts each task, then scores the results
using Docker/Podman containers (no local-scoring fallback — missing
images hard-exit).

Authentication:
    Set one of the following environment variables for your model provider:
        OPENAI_API_KEY       - OpenAI models (gpt-4o, gpt-4-turbo, etc.)
        ANTHROPIC_API_KEY    - Anthropic models (claude-sonnet-4-6, etc.)
        GEMINI_API_KEY       - Google models (gemini/gemini-2.5-flash, etc.)
        AZURE_API_KEY        - Azure-hosted models
        LITELLM_API_KEY      - LiteLLM proxy

    See https://docs.litellm.ai/docs/providers for the full list of
    supported providers and model name formats.

    For Azure-hosted Anthropic models, set ANTHROPIC_BASE_URL to an
    Azure passthrough endpoint like
    `https://<x>.openai.azure.com/anthropic` — the model string stays
    `anthropic/*` and LiteLLM's native Anthropic provider routes via
    the explicit api_base override (ATH-248). DO NOT use `azure_ai/*`
    model strings: that provider uses the OpenAI-compat surface and
    rejects tool-use calls. See `_resolve_anthropic_azure`.

Multi-phase tasks:
    Task configs may set `phase_models: [model_a, model_b, model_c]` to
    dispatch each phase to a different provider. Provider resolution is
    strict per-phase: a run-level anthropic/claude run's Azure api_base is
    NEVER inherited into a per-phase gemini/openai call. See ATH-227.

Usage (from a shim):
    from kairos.eval_harness import main
    main()
"""
import argparse
import concurrent.futures
import json
import os

from kairos.envvars import getenv_dual
from kairos.security.env_allowlist import (  # ATH-1230 PR 1
    safe_env_for_eval_bash_host,
    safe_env_for_eval_bash_sandbox,
)
import re
import shutil
import subprocess
import sys
import tempfile
import time
import queue
import threading
import warnings
from pathlib import Path

# Force unbuffered stdout/stderr so log files reflect real-time progress.
# Python's default is line-buffered for ttys but FULL-buffered for redirected
# files (e.g. `nohup ... > log.log 2>&1 &`), which makes monitoring useless —
# `tail -f log.log` shows nothing for ~10 minutes even when 5 tool calls have
# completed. This re-opens stdout/stderr in line-buffered mode.
# Affects ALL invocations including patches and background nohup runs.
sys.stdout.reconfigure(line_buffering=True)
sys.stderr.reconfigure(line_buffering=True)

warnings.filterwarnings("ignore", module="pydantic")

import math as _math


# ATH-190: docker image inspect races with parallel scoring.
# Under load (multiple concurrent `docker run` invocations), `docker image
# inspect` times out → false "no container image" errors. Module-level
# cache of positive results + retry on timeout, since images don't
# disappear mid-run.
_DOCKER_IMAGE_CACHE: set[str] = set()


def _docker_image_exists(docker_bin: str, image_name: str) -> bool:
    """Return True if `image_name` exists, with cache + retry on timeout."""
    if image_name in _DOCKER_IMAGE_CACHE:
        return True
    for attempt in range(3):
        try:
            r = subprocess.run(
                [docker_bin, "image", "inspect", image_name],
                capture_output=True, timeout=30,
            )
            if r.returncode == 0:
                _DOCKER_IMAGE_CACHE.add(image_name)
                return True
            return False
        except subprocess.TimeoutExpired:
            if attempt < 2:
                time.sleep(1)
                continue
            return False
        except Exception:  # noqa: BLE001 — guard returns False on any error
            return False
    return False

# Cost estimation (best-effort, not billing-reconciled).
try:
    from kairos.model_prices import estimate_cost_usd as _estimate_cost_usd
except Exception:  # noqa: BLE001 — optional-dependency import; stub function as fallback
    def _estimate_cost_usd(*args, **kwargs):
        return 0.0  # silent no-op if import fails; upstream can handle 0.0


def _resolve_anthropic_azure(model: str) -> tuple[str, str | None, str | None]:
    """Resolve (model, api_base, api_key) for Azure-hosted Anthropic.

    When the current VM has ANTHROPIC_BASE_URL pointing at Azure (the
    `/anthropic/` native-passthrough endpoint, NOT the OpenAI-compat
    `azure_ai/` endpoint), we return the model UNCHANGED and supply an
    explicit api_base + api_key pair. LiteLLM's `anthropic/` provider
    honors the api_base override and routes to Azure's passthrough,
    which speaks native Anthropic wire format (tool-use included).

    For non-Anthropic models returns (model, None, None) unchanged.

    **ATH-248 (2026-04-15, research handoff).** An earlier version of
    this function rewrote `anthropic/*` → `azure_ai/*` based on the
    mistaken belief that Azure AI Inference serves these models via
    the OpenAI-compat surface. In fact Azure hosts TWO different
    endpoints: `https://<x>.openai.azure.com/anthropic/v1` is a native
    Anthropic passthrough, and `https://<x>.openai.azure.com/openai/...`
    is the OpenAI-compat one. Rewriting to `azure_ai/*` sent requests
    through litellm's OpenAI-compat code path which rejects tool-use
    calls with `api_not_supported`, silently producing 0-tool-call
    empty runs that evaluate.py marked PASS. Bio harness caught it
    end-to-end on 2026-04-15 (research).

    Fix: delete the rewrite, keep `anthropic/*` as the model name,
    and let litellm's native Anthropic provider handle the api_base
    override to Azure's passthrough.

    Per-phase resolution still matters for multi-phase tasks: a run
    with `phase_models: [gemini, kimi, sonnet]` needs this to fire
    specifically on the sonnet phase so it picks up the Azure-Anthropic
    credentials from env, not whatever the outer run-level model was
    using. See `_resolve_phase_credentials` for the strict provider
    isolation that runs after this returns.

    Key lookup order: ANTHROPIC_API_KEY → AZURE_AI_API_KEY → ANTHROPIC_FOUNDRY_API_KEY.
    Base URL lookup: ANTHROPIC_BASE_URL → AZURE_AI_API_BASE; must contain 'azure'.
    """
    if "anthropic" not in model and "claude" not in model:
        return model, None, None
    base = os.environ.get("ANTHROPIC_BASE_URL") or os.environ.get("AZURE_AI_API_BASE")
    if not base or "azure" not in base:
        return model, None, None
    api_base = base.rstrip("/") + "/v1" if not base.endswith("/v1") else base
    api_key = (
        os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("AZURE_AI_API_KEY")
        or os.environ.get("ANTHROPIC_FOUNDRY_API_KEY")
    )
    # ATH-248: model stays `anthropic/*`. Do NOT rewrite to `azure_ai/*`.
    return model, api_base, api_key


# ATH-229 follow-up (research, 2026-04-15): per-model output-budget cap.
# Hardcoded max_tokens=8192 in _run_agent_loop caused silent failures on
# reasoning-heavy preview models (gemini-3-flash, gemini-3.1-pro) that
# burn 3000-5000 tokens per turn on internal reasoning before emitting
# any visible content or tool call. Hitting the 8192 cap mid-think
# returns content='' / tool_calls=[] / 0 visible tokens — looks like
# a full model failure but is actually budget truncation.
# Cost is not the concern for non-Sonnet/non-Opus providers
# (gemini-3-flash ~$0.10/M, kimi ~$1/M); orchestration's job is to keep
# PROMPTS lean, not cap output before the first tool call. Module-level
# so unit tests can import and assert on the mapping.
MODEL_MAX_TOKENS: dict[str, int] = {
    # Gemini reasoning-preview models still use 64k (their context
    # limit); bare 2.5 stays at 8k (non-reasoning, small output).
    "gemini/gemini-3-flash-preview":   65536,
    "gemini/gemini-3.1-pro-preview":   65536,
    "gemini/gemini-3-pro-preview":     65536,
    "gemini/gemini-2.5-flash":         8192,
    "gemini/gemini-2.5-pro":           8192,
    # Kimi (reasoning model — content goes into reasoning_content,
    # not content; tight budgets silently truncate to content=None).
    "openai/kimi-k2.5":                32768,
    "openai/kimi-k2.6-1":              32768,
    "azure_ai/kimi-k2.5":              32768,
    "azure_ai/kimi-k2.6-1":            32768,
    "openai/mistral-large-3":          16384,
    "openai/deepseek-v3.2-speciale":   16384,
    # Anthropic routes: 200_000 per Aidan 2026-04-23 21:32 directive.
    # Claude's context + tool-use chains need the headroom for
    # reasoning-heavy customer workflows. Wall-clock + cost-cap
    # guardrails (Stream D cost tracker + SpecPipeline budget_usd)
    # are the real enforcement.
    "anthropic/claude-sonnet-4-6":     200000,
    "anthropic/claude-opus-4-6":       200000,
    "anthropic/claude-opus-4-7":       200000,
    "anthropic/claude-haiku-4-5":      200000,
    "azure_ai/claude-sonnet-4-6":      200000,
    "azure_ai/claude-opus-4-6":        200000,
    "azure_ai/claude-opus-4-7":        200000,
    "azure_ai/claude-haiku-4-5":       200000,
}
# Generous default — new reasoning models land at 16384 min while we
# catalogue them. Never default below 2000; that way even fresh,
# un-mapped Kimi/o1/deepseek-r1-style models have headroom.
DEFAULT_MAX_TOKENS = 16384


def _max_tokens_for(model: str) -> int:
    """Return the max_tokens cap for a LiteLLM model string.

    Checks the prefixed name first (e.g. `gemini/gemini-3-flash-preview`),
    then falls back to matching the unprefixed name so `azure_ai/kimi-k2.5`
    resolves to the same cap as `openai/kimi-k2.5`. Unknown models get
    DEFAULT_MAX_TOKENS — currently 16384, deliberately generous to avoid
    silent truncation on new reasoning models that haven't been catalogued.
    """
    if model in MODEL_MAX_TOKENS:
        return MODEL_MAX_TOKENS[model]
    bare = model.split("/", 1)[-1] if "/" in model else model
    for k, v in MODEL_MAX_TOKENS.items():
        if k.split("/", 1)[-1] == bare:
            return v
    return DEFAULT_MAX_TOKENS


def _resolve_phase_credentials(
    current_model: str,
    run_level_model: str,
    phase_api_base: str | None,
    phase_api_key: str | None,
    run_api_base: str | None,
    run_api_key: str | None,
) -> tuple[str | None, str | None]:
    """Return (api_base, api_key) to use for a per-phase LiteLLM call.

    ATH-227 fix: strict provider isolation. The old code used the fallback
    `phase_api_base if phase_api_base is not None else run_api_base`, which
    leaked the run-level Anthropic Azure credentials into non-Anthropic
    phase calls (silently 401ing Gemini/Kimi with the wrong key). The
    correct behavior:

    * If the phase model == the run-level model (same provider), it is
      safe to inherit the run-level api_base/api_key — this is the
      single-phase or homogeneous-phase case.
    * If the phase model != the run-level model, use ONLY what
      `_resolve_anthropic_azure(phase_model)` produced. For non-Anthropic
      phase models this is (None, None), which lets litellm route the
      call via the provider's own env vars.

    Both phase_api_base and phase_api_key should be the result of calling
    `_resolve_anthropic_azure(current_model)` — pass them through verbatim
    from the caller.
    """
    if current_model == run_level_model and phase_api_base is None and run_api_base is not None:
        return run_api_base, run_api_key
    return phase_api_base, phase_api_key


# ATH-236: recursive secret-redaction walker + CodeQL-safe log wrapper.
# Scalar `_redact_secrets(text)` is defined later in this file (line ~780)
# alongside `_SECRET_PATTERNS`. This pair extends that with:
#
#   - `_redact_trace_secrets(obj)` — recursive walk over JSON-serializable
#     dicts/lists, running every string leaf through `_redact_secrets`.
#     Used to sanitize `trace_data` immediately before `json.dumps` on
#     the two trace-file write sites (lines ~2919/2959).
#
#   - `_safe_log_str(value)` — identity-like `str()` wrapper used at the
#     four CodeQL false-positive print sites (~1611/2060/2420/3289).
#     CodeQL's data-flow analysis stops tracking taint through
#     user-defined function boundaries by default, so routing `{model}`
#     through `{_safe_log_str(model)}` severs the tainted flow (from the
#     `api_key` variable adjacency in function signatures) to the
#     `print()` sink. Runtime semantics unchanged.
#
# Both are forward-declared here as stubs so the module-level constants
# in the Port Tasks section above stay close to where they're used. The
# real implementations are after _SECRET_PATTERNS is defined.


def _sanitize_nan(obj):
    """Recursively replace NaN/Inf floats with None so json.dumps produces valid JSON."""
    if isinstance(obj, float) and (_math.isnan(obj) or _math.isinf(obj)):
        return None
    if isinstance(obj, dict):
        return {k: _sanitize_nan(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize_nan(v) for v in obj]
    return obj


# ------------------------------------------------------------------
# Task discovery
# ------------------------------------------------------------------

def _normalize_task_id(task_id: str) -> str:
    """Canonical task ID: lowercase, underscores only. Kills the hyphen/underscore bug class."""
    return task_id.lower().replace("-", "_")


def _resolve_file_path(student_dir: Path, candidate: str, task_dir_name: str) -> str:
    """Resolve a student-data file path, auto-prefixing task_dir or searching the
    tree by basename when the raw candidate doesn't exist at the top level.

    Fixes bugs introduced by Layout 1's regex-based extraction:
      - c-to-rust: regex used to match `c_source_file` and capture the C reference
        filename; now caught by word-boundary regex, then config-JSON fallback
        populates a path that IS valid as-is.
      - distributed-consensus: `source_file = "hash_replication.go"` in the task
        init; real file is at `student_data/consensus/hash_replication.go`. Tree
        search by basename finds it.
      - envs with flat student_data (lean-theorem-proving): the helper is a no-op
        because the file already exists at the top level.

    Returns the candidate (possibly rewritten with a path prefix) that does exist
    under `student_dir`, or the original candidate if nothing resolves. Callers
    downstream will fail loudly on non-existent paths.
    """
    if not candidate:
        return candidate
    # Direct path wins if it exists.
    if (student_dir / candidate).exists():
        return candidate
    # Try task_dir prefix even when the candidate already contains a slash —
    # e.g. c-to-rust's verus tasks have `source_file = "src/lib.rs"` in their
    # config JSON, which needs `verus_vec_add_proof/` prepended to resolve.
    if task_dir_name:
        prefixed = student_dir / task_dir_name / candidate
        if prefixed.exists():
            return f"{task_dir_name}/{candidate}"
    # Tree search by basename (not the full candidate, so we can fix cases
    # where the candidate has a stale relative path prefix). Only accepts a
    # unique match to avoid guessing between multiple files with the same
    # name in different task dirs.
    basename = candidate.rsplit("/", 1)[-1]
    try:
        matches = list(student_dir.rglob(basename))
    except OSError:
        return candidate
    if len(matches) == 1:
        try:
            rel = matches[0].relative_to(student_dir)
            return str(rel)
        except ValueError:
            pass
    return candidate


def _try_rich_task_instructions(env_dir: Path, task_dir_name: str) -> str | None:
    """Best-effort: import the Python task class and return its rich task text.

    Every env under `environments/*/` defines Task subclasses in
    `src/environment/tasks/<task>/__init__.py` with a `_core_instructions`
    property (or equivalent) holding the task description the author wrote —
    typically a multi-paragraph spec with file paths, requirements, scoring
    notes, etc. The historical `find_tasks()` code ignored all of that and
    built a 60-char header from a regex. This helper dynamically imports the
    class, instantiates it, and reads `.steps[0].instructions` — which chains
    through `task_instructions` → `_core_instructions` + iterate-suffix on
    envs with a `_base.py`, or directly returns the inline instructions on
    envs that construct `Step(instructions=...)` at call time.

    Defensive by design: any import failure, instantiation failure,
    attribute error, or empty string returns None, and the caller falls
    back to the bare-header + docstring flow. Known failure modes that
    trigger fallback:
      - distributed-consensus + 7 lean tasks: task classes pass keyword
        args to the base `Step(instructions=...)` which doesn't accept
        them. TypeError at instantiation.
      - neuron-nki-kernels: `get_tasks()` returns instances not classes
        in some pathways — we guard with `isinstance(cls, type)`.

    Returns the stripped instructions string on success, None otherwise.
    """
    import sys
    src_path = str((env_dir / "src").resolve())
    added = False
    if src_path not in sys.path:
        sys.path.insert(0, src_path)
        added = True
    # Clear any cached `environment*` modules from a prior env — otherwise
    # switching envs in the same process (eg. batch task discovery, the
    # dryrun harness) returns the first env's classes forever.
    cached = [m for m in list(sys.modules) if m == "environment" or m.startswith("environment.")]
    cached_saved = {m: sys.modules.pop(m) for m in cached}
    try:
        import importlib
        try:
            mod = importlib.import_module(f"environment.tasks.{task_dir_name}")
        except Exception:  # noqa: BLE001 — customer task module may be malformed/missing — skip task
            return None
        mod_name = mod.__name__
        for name in dir(mod):
            if name.startswith("_"):
                continue
            cls = getattr(mod, name, None)
            if not isinstance(cls, type):
                continue
            if cls.__module__ != mod_name:
                continue  # Skip re-exported base classes like `Task`.
            if not hasattr(cls, "steps"):
                continue
            try:
                instance = cls()
                steps = instance.steps
                if not steps:
                    continue
                instr = steps[0].instructions
                if isinstance(instr, str) and instr.strip():
                    return instr.strip()[:8000]
            except Exception:  # noqa: BLE001 — task instance construction varies per env — skip + continue corpus walk
                continue
        return None
    finally:
        # Restore the prior-env module cache so we don't poison subsequent
        # unrelated imports in the same process.
        for m in list(sys.modules):
            if m == "environment" or m.startswith("environment."):
                del sys.modules[m]
        sys.modules.update(cached_saved)
        if added:
            try:
                sys.path.remove(src_path)
            except ValueError:
                pass


def _build_task_header(solution_file: str, lean_filename: str, output_file: str) -> str:
    """Compose the `Edit /workdir/data/...` header, skipping lines whose path is
    empty so we don't emit `Edit /workdir/data/ to solve this task.` (seen on
    lean-theorem-proving where the regex returned an empty solution_file)."""
    lines = []
    if solution_file:
        lines.append(f"Edit /workdir/data/{solution_file} to solve this task.")
    if lean_filename:
        verb = "Also complete" if lines else "Complete"
        lines.append(
            f"{verb} the Lean 4 proof in /workdir/data/{lean_filename} — "
            f"replace every `sorry` with a valid proof. Do not modify theorem "
            f"statements (only fill in the proofs); see the file's header "
            f"comment for any per-task tactic restrictions."
        )
    if output_file:
        lines.append(f"Write output to /workdir/data/{output_file}")
    if not lines:
        lines.append(
            "Read files in /workdir/data/ to discover what needs to be done."
        )
    return "\n".join(lines)


def find_tasks(env_dir: Path) -> list[dict]:
    """Discover tasks from __init__.py-based layout or config-based layout."""
    # Layout 1: src/environment/tasks/<task_dir>/__init__.py
    tasks_dir = env_dir / "src" / "environment" / "tasks"
    if tasks_dir.exists():
        tasks = []
        student_dir = env_dir / "student_data"
        for d in sorted(tasks_dir.iterdir()):
            if not d.is_dir() or d.name.startswith("_"):
                continue
            init = d / "__init__.py"
            if init.exists():
                content = init.read_text()
                id_match = re.search(r'id\s*=\s*["\']([^"\']+)', content)
                task_id = _normalize_task_id(id_match.group(1) if id_match else d.name)
                # Word-boundary prefixes on all file-attr regexes prevent
                # collisions like `c_source_file` matching `source_file`
                # (broke all 28 c-to-rust tasks until 2026-04-11).
                sol_match = re.search(r'\b(?:solution|student|source)_file\s*=\s*["\']([^"\']+)', content)
                out_match = re.search(r'\boutput_file\s*=\s*["\']([^"\']+)', content)
                lean_match = re.search(r'\blean_file(?:name)?\s*=\s*["\']([^"\']+)', content)
                kern_match = re.search(r'\bkernel_file\s*=\s*["\']([^"\']+)', content)
                solution_file = sol_match.group(1) if sol_match else (kern_match.group(1) if kern_match else "")
                output_file = out_match.group(1) if out_match else ""
                lean_filename = lean_match.group(1) if lean_match else ""
                # Fallback: check config JSON for fields not in __init__.py
                if not solution_file or not lean_filename:
                    for cfg_candidate in [
                        env_dir / "root_data" / "eval" / "configs" / f"{task_id}.json",
                        env_dir / "root_data" / "eval" / "configs" / f"{d.name}.json",
                    ]:
                        if cfg_candidate.exists():
                            try:
                                cfg_data = json.loads(cfg_candidate.read_text())
                                if not solution_file:
                                    sf = cfg_data.get("solution_file", "") or cfg_data.get("kernel_file", "") or cfg_data.get("student_file", "") or cfg_data.get("source_file", "") or cfg_data.get("dafny_file", "") or cfg_data.get("sv_file", "")
                                    if not sf:
                                        srcs = cfg_data.get("source_files", [])
                                        sf = srcs[0] if srcs else ""
                                    solution_file = sf.replace("/workdir/data/", "").lstrip("/")
                                if not lean_filename:
                                    lean_filename = cfg_data.get("lean_file", "").replace("/workdir/data/", "").lstrip("/")
                                if solution_file or lean_filename:
                                    break
                            except Exception:  # noqa: BLE001 — task config json may be malformed — skip
                                pass
                # Path-resolve: auto-prefix task_dir or tree-search by basename
                # when the raw path doesn't exist (fixes distributed-consensus
                # where task init says `source_file = "hash_replication.go"`
                # but the real file is under `student_data/consensus/`).
                solution_file = _resolve_file_path(student_dir, solution_file, d.name)
                lean_filename = _resolve_file_path(student_dir, lean_filename, d.name)
                # Rich-prompt path (preferred): import the task class and read
                # its authored `.steps[0].instructions`. When it works, this
                # gives the agent the full task description — file paths,
                # requirements, scoring notes, FFI signature constraints, etc.
                # When it fails (broken Step() kwargs, instances-not-classes,
                # etc.), we fall back to the bare header + stub docstring
                # flow below so the agent still gets a correct path.
                rich = _try_rich_task_instructions(env_dir, d.name)
                if rich:
                    instructions = rich
                else:
                    # Fallback: bare header + whatever docstring is in the stub.
                    instructions = ""
                    if solution_file and student_dir.exists():
                        sf = student_dir / solution_file
                        if sf.exists():
                            sf_content = sf.read_text()
                            m = re.search(r'"""(.*?)"""', sf_content, re.DOTALL)
                            if m:
                                instructions = m.group(1).strip()[:2000]
                    header = _build_task_header(solution_file, lean_filename, output_file)
                    instructions = header + "\n\n" + instructions
                task_entry = {
                    "id": task_id,
                    "dir": d.name,
                    "instructions": instructions,
                    "lean_filename": lean_filename,
                    "solution_file": solution_file,
                }
                # Forward multi-phase config fields from the config JSON
                # so run_student_trial can read them.
                cfg_path = env_dir / "root_data" / "eval" / "configs" / f"{task_id}.json"
                if not cfg_path.exists():
                    cfg_path = env_dir / "root_data" / "eval" / "configs" / f"{d.name}.json"
                if cfg_path.exists():
                    try:
                        cfg_data = json.loads(cfg_path.read_text())
                        for key in cfg_data:
                            if key in ("phases", "mode", "verifier_inputs", "adversarial_inject_broken", "phase_models", "phase_containers", "scoring_container_image", "allow_mathlib", "phase_no_tools", "phase_output_file", "phase_no_tools_max_attempts", "phase_no_tools_max_tokens") or (key.startswith("phase") and key.endswith("_instructions")):
                                task_entry[key] = cfg_data[key]
                    except Exception:  # noqa: BLE001 — task config copy — skip on malformed cfg
                        pass
                tasks.append(task_entry)
        return tasks

    # Layout 2: root_data/eval/configs/*.json + student_data/<solution>.py
    config_dir = env_dir / "root_data" / "eval" / "configs"
    student_dir = env_dir / "student_data"
    if not config_dir.exists():
        return []
    tasks = []
    for cfg in sorted(config_dir.glob("*.json")):
        try:
            c = json.loads(cfg.read_text())
        except Exception:  # noqa: BLE001 — task config json may be malformed — skip + continue
            continue
        task_id = _normalize_task_id(cfg.stem)
        solution_file = c.get("solution_file", "") or c.get("kernel_file", "") or c.get("student_file", "") or c.get("source_file", "") or c.get("dafny_file", "") or c.get("sv_file", "")
        if not solution_file:
            srcs = c.get("source_files", [])
            solution_file = srcs[0] if srcs else ""
        solution_file = solution_file.replace("/workdir/data/", "").lstrip("/")
        output_file = c.get("output_file", "")
        lean_filename = c.get("lean_file", "").replace("/workdir/data/", "").lstrip("/")
        # Path-resolve for Layout 2 as well, using task_id as the task_dir hint.
        solution_file = _resolve_file_path(student_dir, solution_file, task_id)
        lean_filename = _resolve_file_path(student_dir, lean_filename, task_id)
        student_file = student_dir / solution_file if solution_file else None
        instructions = ""
        if student_file and student_file.exists():
            content = student_file.read_text()
            m = re.search(r'"""(.*?)"""', content, re.DOTALL)
            if m:
                instructions = m.group(1).strip()[:2000]
        header = _build_task_header(solution_file, lean_filename, output_file)
        instructions = header + "\n\n" + instructions
        task_entry = {
            "id": task_id,
            "dir": task_id,
            "instructions": instructions,
            "lean_filename": lean_filename,
            "solution_file": solution_file,
        }
        # Forward multi-phase config fields to the task dict so
        # run_student_trial can read them. Keys: "phases",
        # "phase2_instructions", "phase3_instructions", "phase_models", etc.
        for key in c:
            if key in ("phases", "mode", "verifier_inputs", "adversarial_inject_broken", "phase_models", "phase_containers", "scoring_container_image", "allow_mathlib", "phase_no_tools", "phase_output_file", "phase_no_tools_max_attempts", "phase_no_tools_max_tokens") or (key.startswith("phase") and key.endswith("_instructions")):
                task_entry[key] = c[key]
        tasks.append(task_entry)
    return tasks


def find_scoring_script(env_dir: Path) -> Path | None:
    """Locate the scoring script within the environment directory."""
    for candidate in [
        env_dir / "root_data" / "eval" / "scoring.py",
        env_dir / "scoring_data" / "scoring.py",
        env_dir / "root_data" / "scoring_script.py",
    ]:
        if candidate.exists():
            return candidate
    for p in (env_dir / "root_data").rglob("scoring.py"):
        return p
    return None


# ------------------------------------------------------------------
# Student agent (LiteLLM)
# ------------------------------------------------------------------

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "bash",
            "description": "Run a bash command. Use to run tests and compile code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The bash command to run",
                    }
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read",
                    }
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Replace a specific string in a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file",
                    },
                    "old_string": {
                        "type": "string",
                        "description": "Exact text to replace",
                    },
                    "new_string": {
                        "type": "string",
                        "description": "Text to replace it with",
                    },
                },
                "required": ["path", "old_string", "new_string"],
            },
        },
    },
]


def _resolve_workdir_path(path: str, workdir: Path) -> Path:
    """Normalize a path from the agent into a real filesystem path under workdir/data."""
    if path.startswith("/workdir/data/"):
        rel = path[len("/workdir/data/"):]
    elif path.startswith("/workdir/"):
        rel = path[len("/workdir/"):]
    else:
        rel = path.lstrip("/")
    return workdir / "data" / rel


_SANDBOX_BIN = shutil.which("podman") or shutil.which("docker")
_SANDBOX_IMAGE = None  # Set during init if container available

# GPU sandbox gating: opt-in via ATHANOR_GPU=1 in the shell env.
# When enabled, bash tool calls and scoring get --gpus all plus generous
# memory/pids/timeouts so ESM-2-class workloads can load and run. Off by
# default so the Azure VM (no GPU) keeps working unchanged.
_GPU_SANDBOX = getenv_dual("GPU") == "1"
_GPU_FLAGS = ["--gpus", "all"] if _GPU_SANDBOX else []
_BASH_MEMORY = "12g" if _GPU_SANDBOX else "2g"
_BASH_PIDS = "512" if _GPU_SANDBOX else "128"
_BASH_TIMEOUT = 600 if _GPU_SANDBOX else 90
_SCORING_MEMORY = "8g" if _GPU_SANDBOX else "4g"


# ------------------------------------------------------------------
# Platform connection (sync token or direct Supabase)
# ------------------------------------------------------------------

_PLATFORM_URL = getenv_dual("PLATFORM_URL", "https://tahoe.athanor-ai.com")
_SYNC_TOKEN = getenv_dual("SYNC_TOKEN", "")
_CRON_SECRET = os.environ.get("CRON_SECRET", "")

# Fallback: direct Supabase (internal use only)
_TRACE_URL = os.environ.get("NEXT_PUBLIC_SUPABASE_URL", "")
_TRACE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")


# Pattern order matters. Specific formats run FIRST so they consume the
# whole secret (e.g. `Bearer sk-...` → single match) before the
# assignment-shape fallback can eat only the key-name half.
_SECRET_PATTERNS = [
    # Bearer tokens in HTTP headers — put before assignment shapes
    # because `Authorization: Bearer <token>` would otherwise match the
    # assignment pattern first and truncate at whitespace.
    re.compile(r"Bearer [a-zA-Z0-9_.\-]{20,}"),
    # Three-segment JWTs — added ATH-236
    re.compile(r"eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+"),
    # OpenAI/Anthropic-family prefix
    re.compile(r"sk-[a-zA-Z0-9_\-]{20,}"),
    re.compile(r"at_[a-z0-9\-]+_[a-f0-9]{32}"),
    re.compile(r"AKIA[A-Z0-9]{16}"),
    re.compile(r"AIza[a-zA-Z0-9_\-]{35}"),
    # Long hex tokens (64+ chars)
    re.compile(r"(?<![a-f0-9])[a-f0-9]{64}(?![a-f0-9])"),
    # Explicit assignment shapes — catches leaked key values from exception
    # stringification like "AuthenticationError: api_key='sk-...'" even
    # when the key value itself is shorter than the generic patterns
    # above. Runs LAST as a catch-all. Added ATH-236.
    re.compile(r"(?i)\b(api[_-]?key|password|secret|authorization)\s*[=:]\s*['\"]?\S{6,}"),
    re.compile(r"(?i)\btoken\s*[=:]\s*['\"]?[A-Za-z0-9_.\-]{10,}"),
]

def _redact_secrets(text: str | None) -> str | None:
    """Strip API keys and secrets from text before sending to platform."""
    if not text:
        return text
    result = text
    for pat in _SECRET_PATTERNS:
        result = pat.sub("[REDACTED]", result)
    return result


def _redact_trace_secrets(obj):
    """Recursively walk a JSON-serializable structure and redact any
    string leaf that looks like a secret (API key, bearer token, JWT,
    assignment-shaped key=value).

    Used by the per-task and per-phase trace-file writers immediately
    before `json.dumps` so stringified exceptions that carry leaked
    credentials never land on disk. Defense-in-depth — catches any
    future error-append site that forgets to sanitize on its own.

    ATH-236. Called from both `trace_file.write_text` sites in
    `run_student_trial` (the per-task trace + per-phase trace).
    Non-string, non-collection scalars pass through unchanged.
    """
    if isinstance(obj, str):
        redacted = _redact_secrets(obj)
        # _redact_secrets may return None for falsy inputs; coerce
        # to empty string so downstream json.dumps doesn't emit null
        # where the original had "".
        return redacted if redacted is not None else obj
    if isinstance(obj, dict):
        return {k: _redact_trace_secrets(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_redact_trace_secrets(v) for v in obj]
    return obj


def _safe_log_str(value) -> str:
    """Identity-like coerce-to-str wrapper used at print sites where
    CodeQL's `py/clear-text-logging-sensitive-data` query falsely flags
    the argument as credential-carrying.

    CodeQL's data-flow analyzer stops tracking taint through user-defined
    function boundaries by default. Routing `{model}` through
    `{_safe_log_str(model)}` in an f-string severs the tainted flow from
    function-signature adjacency (where `model` and `api_key` pass
    through the same call sites) to the `print()` sink. Runtime
    semantics are identical to `str(value)`.

    ATH-236. NOT a security control — real secret values should never
    reach this function. Silences false positives on debug strings like
    LiteLLM model names ("anthropic/claude-sonnet-4-6") that the analyzer
    mistakes for credentials.
    """
    return str(value)


def _platform_auth_header() -> str:
    """Return the best available auth header for platform API calls."""
    if _SYNC_TOKEN:
        return f"Bearer {_SYNC_TOKEN}"
    if _CRON_SECRET:
        return f"Bearer {_CRON_SECRET}"
    return ""


# ---------------------------------------------------------------------------
# Background trace emitter — non-blocking, fire-and-forget
# ---------------------------------------------------------------------------
_trace_queue: queue.Queue = queue.Queue(maxsize=500)

def _trace_worker():
    """Daemon thread that drains the trace queue and POSTs events."""
    import urllib.request
    while True:
        try:
            item = _trace_queue.get()
            if item is None:
                break  # poison pill
            req_url, payload, headers = item
            req = urllib.request.Request(req_url, data=payload, headers=headers, method="POST")
            urllib.request.urlopen(req, timeout=5)
        except Exception:  # noqa: BLE001 — trace upload best-effort; never block eval on network error
            pass
        finally:
            _trace_queue.task_done()

_trace_thread = threading.Thread(target=_trace_worker, daemon=True)
_trace_thread.start()


def _emit_trace_event(
    run_id: str | None,
    task_slug: str,
    step: int,
    event_type: str,
    tool: str | None = None,
    content: str | None = None,
    output: str | None = None,
    success: bool | None = None,
    duration_ms: int | None = None,
    full_content: str | None = None,
    full_output: str | None = None,
    role: str | None = None,
) -> None:
    """Write a trace event for real-time monitoring. Non-blocking."""
    if not run_id:
        return
    auth = _platform_auth_header()
    try:
        # Redact secrets from all text fields
        safe_content = _redact_secrets((content or "")[:2000])
        safe_output = _redact_secrets((output or "")[:2000])
        # Build rich details for full conversation data
        details = {}
        if full_content is not None:
            details["full_content"] = _redact_secrets(full_content[:50000]) if full_content else ""
        if full_output is not None:
            details["full_output"] = _redact_secrets(full_output[:50000]) if full_output else ""
        if role is not None:
            details["role"] = role
        payload = json.dumps({
            "action": "trace-event",
            "run_id": run_id,
            "task_slug": task_slug,
            "step": step,
            "event_type": event_type,
            "tool": tool,
            "content": safe_content,
            "output": safe_output,
            "success": success,
            "duration_ms": duration_ms,
            **({"details": details} if details else {}),
        }).encode()
        if _TRACE_URL and _TRACE_KEY:
            url = f"{_TRACE_URL}/rest/v1/trace_events"
            payload = json.dumps({k: v for k, v in json.loads(payload).items() if k != "action"}).encode()
            headers = {"apikey": _TRACE_KEY, "Authorization": f"Bearer {_TRACE_KEY}",
                       "Content-Type": "application/json", "Prefer": "return=minimal"}
        elif auth and _PLATFORM_URL:
            url = f"{_PLATFORM_URL}/api/sync"
            headers = {"Authorization": auth, "Content-Type": "application/json"}
        else:
            return
        # Non-blocking: enqueue for background thread
        try:
            _trace_queue.put_nowait((url, payload, headers))
        except queue.Full:
            pass  # drop event if queue is full (backpressure)
    except Exception:  # noqa: BLE001 — trace queue + outer enqueue; telemetry must not break eval
        pass



def _check_cancelled(run_id: str | None) -> bool:
    """Check if the run has been cancelled. Returns True if cancelled."""
    if not run_id or not _TRACE_URL or not _TRACE_KEY:
        return False
    try:
        import urllib.request
        req = urllib.request.Request(
            f"{_TRACE_URL}/rest/v1/runs?select=status&id=eq.{run_id}",
            headers={
                "apikey": _TRACE_KEY,
                "Authorization": f"Bearer {_TRACE_KEY}",
            },
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=3).read())
        return resp and resp[0].get("status") == "cancelled"
    except Exception:  # noqa: BLE001 — guard returns False on any error
        return False


def _execute_bash(args: dict, workdir: Path, tc_id: str) -> dict:
    """Execute a bash tool call. Uses container sandbox if available."""
    cmd = args.get("command", "")
    try:
        if _SANDBOX_BIN and _SANDBOX_IMAGE:
            # Run inside container: student can only see /workdir/data and /workdir/shared.
            # GPU flags + elevated limits are applied only when ATHANOR_GPU=1.
            result = subprocess.run(
                [
                    _SANDBOX_BIN, "run", "--rm",
                    *_GPU_FLAGS,
                    "--network=none",
                    f"--memory={_BASH_MEMORY}", f"--pids-limit={_BASH_PIDS}",
                    "-v", f"{workdir / 'data'}:/workdir/data:rw",
                    "-v", f"{workdir / 'shared'}:/workdir/shared:ro",
                    "-w", "/workdir/data",
                    _SANDBOX_IMAGE,
                    "bash", "-c", cmd,
                ],
                capture_output=True,
                text=True,
                timeout=_BASH_TIMEOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                env=safe_env_for_eval_bash_sandbox(),  # ATH-1230 PR 1
            )
        else:
            # Fallback: run on host with restricted cwd. eval-bash
            # sandbox requires shell semantics for the compound commands
            # the test fixture authors supply (pipes / redirects / &&
            # chains). env+cwd hardening is the defense:
            # safe_env_for_eval_bash_sandbox restricts PATH + drops
            # credential vars (ATH-1212a + ATH-1230 PR #640 + PR #642).
            result = subprocess.run(
                cmd,
                shell=True,  # nosemgrep
                capture_output=True,
                text=True,
                timeout=90,
                cwd=str(workdir / "data"),
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                env=safe_env_for_eval_bash_host(),  # ATH-1230 PR 1
        )
        output = (result.stdout + result.stderr)[:2000]
        return {"role": "tool", "tool_call_id": tc_id, "content": output or "(no output)"}
    except subprocess.TimeoutExpired:
        return {"role": "tool", "tool_call_id": tc_id, "content": "Command timed out (90s)"}


def _execute_read_file(args: dict, workdir: Path, tc_id: str) -> dict:
    """Execute a read_file tool call and return the tool response message."""
    path = args.get("path", "")
    target = _resolve_workdir_path(path, workdir)
    in_data = target.resolve().is_relative_to(workdir / "data")
    in_shared = target.resolve().is_relative_to(workdir / "shared")
    if not (in_data or in_shared):
        content = f"Error: Cannot access {path} (outside workspace)"
    elif not target.exists():
        content = f"Error: File {path} not found"
    elif target.is_dir():
        content = f"Error: {path} is a directory, not a file"
    else:
        try:
            content = target.read_text()[:10000]
        except UnicodeDecodeError:
            content = f"Error: {path} is a binary file (not readable as text). Use bash to inspect it."
    return {"role": "tool", "tool_call_id": tc_id, "content": content}


def _execute_edit_file(args: dict, workdir: Path, tc_id: str) -> dict:
    """Execute an edit_file tool call and return the tool response message."""
    path = args.get("path", "")
    old_str = args.get("old_string", "")
    new_str = args.get("new_string", "")
    target = _resolve_workdir_path(path, workdir)
    if not target.resolve().is_relative_to(workdir / "data"):
        content = f"Error: Cannot access {path} (outside workspace)"
    elif not target.exists():
        content = f"Error: File {path} not found"
    elif target.is_dir():
        content = f"Error: {path} is a directory, not a file"
    else:
        text = target.read_text()
        if old_str not in text:
            content = "Error: old_string not found in file exactly as written."
        else:
            target.write_text(text.replace(old_str, new_str, 1))
            content = "File updated successfully."
    return {"role": "tool", "tool_call_id": tc_id, "content": content}


# ---------------------------------------------------------------------------
# Kimi K2.5 native tool-call reparser
# ---------------------------------------------------------------------------
# Azure's OpenAI-compatible deployment of Kimi K2.5 sometimes passes Kimi's
# native tool-calling delimiters back as raw `content` text instead of
# converting them into the OpenAI `tool_calls` field. When that happens the
# harness sees "no tool calls, just text" and bails out, scoring the run 0.
#
# The native format looks like:
#   <|tool_calls_section_begin|>
#   <|tool_call_begin|>functions.<name>:<id>
#   <|tool_call_argument_begin|>{"arg":"val"}
#   <|tool_call_end|>
#   ...
#   <|tool_calls_section_end|>
#
# We detect this pattern in content and reify each segment as a structured
# tool call so the rest of the loop can dispatch it normally. Truncated
# segments (missing tool_call_end because max_tokens was hit) are still
# captured — their arguments may be invalid JSON, which downstream code
# already handles via the json.JSONDecodeError fallback.
#
# Impact measured from the backup trace archive at ~/athanor/traces:
# 12 of 212 Kimi K2.5 runs (5.7%) hit this across 4 environments
# (systems-biology, neuroscience, distributed-consensus, custom-tpu-kernels).
# All 12 are max_tokens-cap truncations where Kimi's edit_file JSON was
# cut off mid-argument. Other models (Sonnet 131 traces, Mistral 106,
# Gemini 204) show 0 native-format leakage — the reparser is a no-op for
# them and this patch is zero-risk. The max_tokens bump (4096 -> 8192,
# below) is the dominant fix; the reparser is defense in depth for any
# future truncation that still happens to slip through.
_KIMI_TOOL_CALL_RE = re.compile(
    r"<\|tool_call_begin\|>functions\.(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r":(?P<id>\d+)"
    r"<\|tool_call_argument_begin\|>(?P<args>.*?)"
    r"(?:<\|tool_call_end\|>|$)",
    re.DOTALL,
)


class _ShimFunction:
    __slots__ = ("name", "arguments")

    def __init__(self, name: str, arguments: str):
        self.name = name
        self.arguments = arguments


class _ShimToolCall:
    __slots__ = ("id", "type", "function")

    def __init__(self, tc_id: str, name: str, arguments: str):
        self.id = tc_id
        self.type = "function"
        self.function = _ShimFunction(name, arguments)


def _sanitize_tool_call_args(args_str: str) -> str:
    """Normalize a tool-call argument string so it round-trips through strict
    JSON parsers downstream.

    ATH-229 follow-up (research, 2026-04-15): Kimi K2.5 occasionally emits
    literal newlines, tabs, or other control characters inside JSON string
    values — especially when writing multi-line file contents via an
    `edit_file({"content": "<newlines here>"})` call. The OpenAI client's
    strict JSON validator rejects raw control chars in strings, so when
    the message is fed back as the assistant turn on the NEXT request,
    it 400s with:
        "unexpected control character in string: line 1 column N"

    Fix: parse with strict=False (which allows raw control chars) and
    re-dump with strict JSON encoding. That converts literal \\n / \\t /
    \\x?? in strings into proper escape sequences. Falls back to the
    original string if parsing fails entirely — better to forward and let
    the next-turn parse error surface than silently drop the tool call.
    """
    if not args_str:
        return args_str
    try:
        return json.dumps(json.loads(args_str, strict=False))
    except (ValueError, json.JSONDecodeError):
        return args_str


def _reparse_kimi_tool_calls(content: str):
    """Detect Kimi native tool-call delimiters in content text and convert
    them into shim tool-call objects matching the LiteLLM/OpenAI shape.

    Returns (cleaned_content, list_of_shim_tool_calls). If no Kimi delimiters
    are present, returns (content, []) unchanged. Safe no-op for every
    non-Kimi model.
    """
    if not content or "<|tool_call_begin|>" not in content:
        return content, []

    shims: list[_ShimToolCall] = []
    for m in _KIMI_TOOL_CALL_RE.finditer(content):
        name = m.group("name")
        call_id = m.group("id")
        args_str = _sanitize_tool_call_args(m.group("args").strip())
        shim_id = f"call_kimi_{call_id}_{name}"
        shims.append(_ShimToolCall(shim_id, name, args_str))

    # Strip the entire tool-calls section (and anything after it, which is
    # often truncated garbage) so the surviving content is just the model's
    # prose preamble.
    cleaned = re.sub(
        r"<\|tool_calls_section_begin\|>.*$",
        "",
        content,
        flags=re.DOTALL,
    ).rstrip()

    return cleaned, shims


def _run_agent_loop(
    completion_fn,
    messages: list,
    model: str,
    workdir: Path,
    max_time: int,
    task: dict,
    live_run_id: str | None,
    api_base: str | None,
    api_key: str | None,
    start_time: float,
    prior_api_wait: float = 0.0,
    prior_tokens: int = 0,
) -> dict:
    """Run a single agent loop (one phase of a task).

    Extracted from run_student_trial() to support multi-phase tasks where
    each phase is a fresh LLM conversation on the same workdir.

    Args:
        prior_api_wait: API wait penalty accumulated from prior phases, so
            the time budget check correctly accounts for all phases' API waits.
        prior_tokens: Tokens used in prior phases, so the token budget check
            correctly accounts for cumulative usage across phases.

    Returns a dict with:
        tool_calls_log, errors, api_wait_penalty, total_tokens,
        cache_creation_tokens, cache_read_tokens, stop_reason, messages
        (mutated in-place, returned for trace capture)
    """
    tool_calls_log = []
    errors = []
    api_wait_penalty = 0.0

    # MAX_TURNS=100 (bumped from 50 after 2026-04-12 ATH-105 canary showed
    # Flash hitting the cap mid-proof on fused_attention_softmax_verified —
    # 50 was too tight for multi-file NKI+Lean tasks). Still bounded by
    # MAX_TOKENS_BUDGET for runaway cost protection.
    MAX_TURNS = 100
    MAX_TOKENS_BUDGET = 4_000_000

    total_tokens_used = 0
    prompt_tokens_used = 0
    completion_tokens_used = 0
    cache_creation_tokens = 0
    cache_read_tokens = 0
    empty_choice_retries = 0

    stop_reason = None

    for turn in range(MAX_TURNS):
        if _check_cancelled(live_run_id):
            stop_reason = "Cancelled by user"
            _emit_trace_event(live_run_id, task["id"], turn, "status", content="Run cancelled")
            break
        if (time.time() - start_time - api_wait_penalty - prior_api_wait) > max_time:
            stop_reason = f"Time limit reached ({max_time}s)"
            break
        if (total_tokens_used + prior_tokens) > MAX_TOKENS_BUDGET:
            stop_reason = f"Token budget reached ({total_tokens_used + prior_tokens:,} tokens)"
            break

        response = None
        for attempt in range(5):
            attempt_start = time.time()
            try:
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    kwargs = dict(
                        model=model,
                        max_tokens=_max_tokens_for(model),
                        tools=TOOLS,
                        messages=messages,
                    )
                    if turn == 0 and "gemini" in model:
                        kwargs["tool_choice"] = "required"
                    if api_base:
                        kwargs["api_base"] = api_base
                    if api_key:
                        kwargs["api_key"] = api_key
                    future = executor.submit(completion_fn, **kwargs)
                    response = future.result(timeout=120)
                break
            except concurrent.futures.TimeoutError:
                api_wait_penalty += time.time() - attempt_start
                if attempt == 2:
                    errors.append("API error: TimeoutError (120s)")
                else:
                    time.sleep(2)
                    api_wait_penalty += 2
            except Exception as e:  # noqa: BLE001 — broad-catch fallback
                api_wait_penalty += time.time() - attempt_start
                if attempt == 4:
                    errors.append(f"API error: {e}")
                else:
                    wait = min(10 * (3 ** attempt), 120)
                    if "rate limit" in str(e).lower() or "429" in str(e):
                        wait = max(wait, 60)
                    time.sleep(wait)
                    api_wait_penalty += wait

        if response is None:
            break

        if hasattr(response, "usage") and response.usage:
            _pt = response.usage.prompt_tokens or 0
            _ct = response.usage.completion_tokens or 0
            prompt_tokens_used += _pt
            completion_tokens_used += _ct
            total_tokens_used += (_pt + _ct)
            cache_creation_tokens += getattr(response.usage, "cache_creation_input_tokens", 0) or 0
            cache_read_tokens += getattr(response.usage, "cache_read_input_tokens", 0) or 0
            ptd = getattr(response.usage, "prompt_tokens_details", None)
            if ptd is not None:
                gemini_cached = getattr(ptd, "cached_tokens", 0) or 0
                cache_read_tokens += gemini_cached

        if not hasattr(response, "choices") or not response.choices:
            empty_choice_retries += 1
            if empty_choice_retries <= 3:
                time.sleep(2)
                continue
            errors.append(f"Empty choices in response: {response}")
            break

        choice = response.choices[0]
        assistant_msg = choice.message

        msg_dict = (
            assistant_msg.model_dump()
            if hasattr(assistant_msg, "model_dump")
            else dict(assistant_msg)
        )
        clean_msg = {
            k: v
            for k, v in msg_dict.items()
            if k in ["role", "content", "tool_calls"] and v is not None
        }

        # ATH-229 follow-up: sanitize control characters in native tool-call
        # arguments before the message goes back into the next-turn request
        # body. Kimi (and occasionally other models) emit literal newlines
        # or tabs inside JSON string values for file-write tool calls,
        # which the OpenAI client's strict JSON validator rejects on the
        # NEXT turn with "unexpected control character in string". Bug
        # surfaced 2026-04-14 in fused_attention_softmax_verified Phase 4.
        if isinstance(clean_msg.get("tool_calls"), list):
            for _tc in clean_msg["tool_calls"]:
                _fn = _tc.get("function") if isinstance(_tc, dict) else None
                if _fn and isinstance(_fn.get("arguments"), str):
                    _fn["arguments"] = _sanitize_tool_call_args(_fn["arguments"])

        _kimi_shim_tcs = []
        _raw_content_for_reparse = clean_msg.get("content") or ""
        if _raw_content_for_reparse and not clean_msg.get("tool_calls"):
            _cleaned_content, _kimi_shim_tcs = _reparse_kimi_tool_calls(
                _raw_content_for_reparse
            )
            if _kimi_shim_tcs:
                clean_msg["content"] = _cleaned_content or ""
                clean_msg["tool_calls"] = [
                    {
                        "id": s.id,
                        "type": s.type,
                        "function": {
                            "name": s.function.name,
                            "arguments": s.function.arguments,
                        },
                    }
                    for s in _kimi_shim_tcs
                ]
                try:
                    assistant_msg.tool_calls = _kimi_shim_tcs
                except (AttributeError, TypeError):
                    pass
                _emit_trace_event(
                    live_run_id, task["id"], turn, "status",
                    content=f"Reparsed {len(_kimi_shim_tcs)} Kimi native tool call(s) from content",
                )

        messages.append(clean_msg)

        assistant_text = clean_msg.get("content") or ""
        _emit_trace_event(
            live_run_id, task["id"], turn, "assistant",
            content=assistant_text[:2000],
            full_content=assistant_text,
            role="assistant",
        )

        _iter_tcs = (
            _kimi_shim_tcs
            if _kimi_shim_tcs
            else (assistant_msg.tool_calls or [])
            if hasattr(assistant_msg, "tool_calls")
            else []
        )
        if not _iter_tcs:
            if turn < 3 and len(tool_calls_log) == 0:
                messages.append({
                    "role": "user",
                    "content": "You must use the provided tools to solve this task. "
                    "Start by calling read_file to examine the task files, then "
                    "use edit_file or bash to implement your solution.",
                })
                continue
            break

        for tc in _iter_tcs:
            func = tc.function
            try:
                args = (
                    json.loads(func.arguments)
                    if isinstance(func.arguments, str)
                    else func.arguments
                )
            except json.JSONDecodeError:
                args = {"command": str(func.arguments)}

            tc_start = time.time()
            if func.name == "bash":
                tool_calls_log.append(f"bash: {args.get('command', '')[:150]}")
                _emit_trace_event(live_run_id, task["id"], len(tool_calls_log), "tool_call", tool="bash", content=args.get("command", "")[:2000], full_content=json.dumps(args))
                msg = _execute_bash(args, workdir, tc.id)
                if "timed out" in msg["content"]:
                    pass
            elif func.name == "read_file":
                tool_calls_log.append(f"read_file: {args.get('path', '')}")
                _emit_trace_event(live_run_id, task["id"], len(tool_calls_log), "tool_call", tool="read_file", content=args.get("path", ""), full_content=json.dumps(args))
                msg = _execute_read_file(args, workdir, tc.id)
            elif func.name == "edit_file":
                tool_calls_log.append(f"edit_file: {args.get('path', '')}")
                _emit_trace_event(live_run_id, task["id"], len(tool_calls_log), "tool_call", tool="edit_file", content=args.get("path", ""), full_content=json.dumps(args))
                msg = _execute_edit_file(args, workdir, tc.id)
            else:
                tool_calls_log.append(f"{func.name}: unknown tool")
                msg = {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": f"Unknown tool: {func.name}",
                }
            tc_elapsed = int((time.time() - tc_start) * 1000)
            _emit_trace_event(
                live_run_id, task["id"], len(tool_calls_log), "tool_result",
                tool=func.name, output=msg.get("content", "")[:2000],
                success="Error" not in msg.get("content", ""),
                duration_ms=tc_elapsed,
                full_output=msg.get("content", ""),
            )
            messages.append(msg)

        if choice.finish_reason == "stop":
            break

    return {
        "tool_calls_log": tool_calls_log,
        "errors": errors,
        "api_wait_penalty": api_wait_penalty,
        "total_tokens": total_tokens_used,
        "prompt_tokens": prompt_tokens_used,
        "completion_tokens": completion_tokens_used,
        "cache_creation_tokens": cache_creation_tokens,
        "cache_read_tokens": cache_read_tokens,
        "stop_reason": stop_reason,
        "messages": messages,
    }


def _run_no_tools_phase(
    completion_fn,
    messages: list,
    model: str,
    workdir: Path,
    task: dict,
    api_base: str | None,
    api_key: str | None,
    phase_num: int,
) -> dict:
    """One-shot / N-attempt retry-with-feedback phase for no-tool models.

    Use for DeepSeek-V3.2-Speciale and any other "research-only, reasoning-
    only" model that silently ignores `tools` in the request (empirically
    verified 2026-04-12: Speciale returns finish_reason=stop with 0 tool
    calls even when tools + task prompt are provided).

    Pipeline (ATH-105 H4 retry-with-feedback, 2026-04-13):
      1. Attempt 1: completion_fn(messages, no tools) → extract fenced block
         → write to /workdir/data/<output_rel>
      2. Compile-check the output using `lean` inside the phase's sandbox
         image (honors _SANDBOX_IMAGE override for :solve Mathlib support).
      3. If compile succeeds → return.
      4. If compile errors AND max_attempts > 1: prepare next attempt with
         error transcript fed back as a user message. Same model, new turn.
      5. Up to `phase_no_tools_max_attempts` (default 1, customer-demo 3)
         attempts. Return the attempt with FEWEST compile errors.

    This is legitimate auto-repair — same model iterating on its own
    Lean-compiler feedback. Customer-realistic production pattern. NOT
    human-in-the-loop patching.

    Cost scaling: ~N × base_cost. For Speciale (~$0.15-0.30/attempt),
    N=3 is ~$1 total. Cheap enough to default on for expert tasks.

    OTHER RETRY PATTERNS to consider (roadmap, not implemented here):
      - Partial-theorem retry: if only some proofs fail, re-prompt with ONLY
        the failing theorems (saves tokens vs regenerating the whole file).
      - Best-of-N parallel: run attempt 1,2,3 CONCURRENTLY with different
        seeds/temperatures, pick highest-scoring. Wall-clock win.
      - Cross-model retry: attempt 1 Speciale, attempt 2 falls back to Kimi,
        attempt 3 Sonnet. Model diversity on same task.
      - Tool-loop phase retry: existing Kimi/Sonnet tool-using phases could
        also retry on compile errors via prompt injection. Currently they
        iterate naturally via tool_calls; no retry wrapper needed.
      - Builder/Verifier retry: if Verifier output isn't valid JSON, retry
        with "your output wasn't valid JSON, try again." Same pattern.
    """
    import re as _re
    tool_calls_log: list = []
    errors: list = []
    stop_reason = None

    output_rel = task.get("phase_output_file") or task.get("lean_file") or ""
    if not output_rel:
        errors.append("no-tools phase: no phase_output_file or lean_file in task config")
        return {
            "tool_calls_log": [], "errors": errors, "api_wait_penalty": 0.0,
            "total_tokens": 0, "prompt_tokens": 0, "completion_tokens": 0,
            "cache_creation_tokens": 0, "cache_read_tokens": 0,
            "stop_reason": "no-tools phase config missing output file",
            "messages": messages,
        }
    output_rel = output_rel.replace("/workdir/data/", "").lstrip("/")

    max_tok = task.get("phase_no_tools_max_tokens", 32768)
    max_attempts = max(1, int(task.get("phase_no_tools_max_attempts", 1)))

    # Set up fence pattern for extraction.
    fence_pat = _re.compile(
        r"```(?:lean_final|final|lean|lean4|python|py|rust|go|)\n(.*?)\n```",
        _re.DOTALL,
    )

    def _extract_fenced(text: str) -> str:
        matches = fence_pat.findall(text)
        if matches:
            return max(matches, key=len)
        for marker in ("import Mathlib", "import Lean", "theorem ", "namespace ", "def "):
            idx = text.find(marker)
            if idx != -1:
                return text[idx:]
        return text

    # ------------------------------------------------------------------
    # Partial-theorem retry helpers (ATH-105 H5, 2026-04-13).
    #
    # Whole-file retry (H4) empirically OVER-CORRECTS: when Speciale is
    # told "fix these errors", it regenerates the whole file and
    # accidentally breaks previously-compiling theorems. Measured on
    # retry-n3 and retry-n10: attempt 1 had 2 errors, attempts 2-3 had
    # 5-6 errors each.
    #
    # Fix: parse the .lean file into declaration blocks (theorem / lemma
    # / def), map compile errors to specific blocks by line number, then
    # re-prompt the model to rewrite ONLY the failing block(s) — the
    # rest of the file is held fixed. Splice the rewritten body back in
    # and re-compile.
    #
    # Falls back to whole-file retry if errors don't map to any
    # declaration (e.g. import errors, namespace issues).
    # ------------------------------------------------------------------
    _DECL_RE = _re.compile(
        r"^(?P<kw>theorem|lemma|example|noncomputable\s+def|def)\s+(?P<name>[^\s(:{]+)"
    )

    def _parse_lean_decls(src: str) -> list[dict]:
        """Parse top-level theorem/lemma/def blocks from a Lean source.

        Each block extends from its declaration line to the line before the
        next top-level decl (or before `end`/EOF). Line numbers are 1-indexed
        to match Lean compiler output. Trailing blank/comment lines that
        belong to the NEXT decl's doc-comment are trimmed.
        """
        lines = src.split("\n")
        starts: list[tuple[int, str, str]] = []
        for idx, line in enumerate(lines):
            m = _DECL_RE.match(line)
            if m:
                starts.append((idx, m.group("kw").strip(), m.group("name")))
        out: list[dict] = []
        for i, (s_idx, kw, name) in enumerate(starts):
            if i + 1 < len(starts):
                e_idx = starts[i + 1][0] - 1
            else:
                e_idx = len(lines) - 1
                for j in range(s_idx + 1, len(lines)):
                    if _re.match(r"^\s*end\b", lines[j]):
                        e_idx = j - 1
                        break
            # Trim trailing blank / doc-comment lines belonging to next decl.
            # Handle multi-line block comments `/- ... -/` and `/-! ... -/` by
            # walking backwards: if we see `-/` at the end, scan back until
            # the matching `/-` and trim the whole block.
            while e_idx > s_idx:
                strip = lines[e_idx].strip()
                if strip == "" or strip.startswith("--"):
                    e_idx -= 1
                    continue
                if strip.endswith("-/"):
                    # find matching /- above
                    j = e_idx
                    while j > s_idx:
                        if lines[j].strip().startswith("/-") or lines[j].lstrip().startswith("/-"):
                            break
                        j -= 1
                    e_idx = j - 1
                    continue
                break
            out.append({
                "name": name,
                "kind": kw,
                "start_line": s_idx + 1,  # 1-indexed, matches Lean errors
                "end_line": e_idx + 1,
                "body": "\n".join(lines[s_idx : e_idx + 1]),
            })
        return out

    _ERR_RE = _re.compile(r"^[^\n:]+:(\d+):(\d+):\s*error:\s*(.+?)(?=^\S|\Z)", _re.MULTILINE | _re.DOTALL)
    _ERR_RE_SIMPLE = _re.compile(r"^[^\n:]+:(\d+):(\d+):\s*error:\s*(.*)$", _re.MULTILINE)

    def _map_errors_to_decls(compile_output: str, decls: list[dict]) -> dict[str, dict]:
        """Group compile errors by the declaration that contains them.

        Returns {decl_name: {"decl": <decl>, "errors": [<msg>, ...]}}.
        Errors that don't fall inside any decl (e.g. import / namespace
        level errors) are omitted — caller falls back to whole-file retry
        when the returned dict is empty but err_count > 0.
        """
        by_name: dict[str, dict] = {}
        for m in _ERR_RE_SIMPLE.finditer(compile_output or ""):
            err_line = int(m.group(1))
            err_msg = m.group(3).strip()
            for d in decls:
                if d["start_line"] <= err_line <= d["end_line"]:
                    entry = by_name.setdefault(d["name"], {"decl": d, "errors": []})
                    entry["errors"].append(f"line {err_line}: {err_msg}")
                    break
        return by_name

    def _splice_decl(src: str, decl: dict, new_body: str) -> str:
        """Replace lines [start_line, end_line] with new_body (1-indexed)."""
        lines = src.split("\n")
        new_lines = (new_body.rstrip("\n")).split("\n")
        return "\n".join(lines[: decl["start_line"] - 1] + new_lines + lines[decl["end_line"] :])

    def _extract_single_decl(text: str, expected_name: str) -> str | None:
        """Extract a single decl block from the model's response.

        Prefers fenced code blocks. Within the fence, finds the block
        starting with `theorem|lemma|def <expected_name>`; if missing,
        falls back to the longest fenced block. Returns the decl source
        text or None on failure.
        """
        fenced = fence_pat.findall(text)
        candidates = fenced if fenced else [text]
        best_match = None
        for c in candidates:
            # Look for a decl matching expected_name
            for i, line in enumerate(c.split("\n")):
                m = _DECL_RE.match(line)
                if m and m.group("name") == expected_name:
                    # Found it — grab from this line to end of candidate
                    return "\n".join(c.split("\n")[i:]).rstrip()
            if best_match is None:
                best_match = c.strip()
        # Fallback: if fenced block exists, use it even if name doesn't match
        return best_match

    def _lean_compile_check(file_path: Path) -> tuple[int, str]:
        """Compile-check a single Lean file in the phase's sandbox image.

        Returns (error_count, stderr_text). error_count > 0 means the
        file has at least one 'error:' line from Lean. Only Lean files
        are compile-checked; other output types skip (return 0, "").
        Timeout: 90s (generous for Mathlib imports).
        """
        if not str(file_path).endswith(".lean"):
            return 0, ""
        if not _SANDBOX_BIN or not _SANDBOX_IMAGE:
            return 0, ""  # no container available — can't compile-check
        try:
            result = subprocess.run(
                [
                    _SANDBOX_BIN, "run", "--rm", "--user", "root",
                    "--network=none",
                    "-v", f"{file_path}:/tmp/speciale_check.lean:ro",
                    _SANDBOX_IMAGE,
                    "bash", "-c",
                    "cd /opt/lean-mathlib && timeout 60 lean /tmp/speciale_check.lean 2>&1",
                ],
                capture_output=True, text=True, timeout=90,
                stdin=subprocess.DEVNULL,
            )
            out = (result.stdout or "") + (result.stderr or "")
            err_count = sum(1 for ln in out.split("\n") if ": error:" in ln)
            return err_count, out
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:  # noqa: BLE001 — guard returns 0 on any error
            return 0, f"compile check failed: {e}"  # don't block on infra issue

    # ATH-236: route model name through _redact_secrets so CodeQL sees
    # the re.sub sanitizer barrier. User-defined identity wrappers like
    # _safe_log_str aren't reliably recognized by CodeQL's analyzer.
    print(
        f"  Phase {phase_num}/no-tools: max_attempts={max_attempts}, "
        f"model={_redact_secrets(str(model))}, max_tokens={max_tok}"
    )

    attempts_log: list = []
    all_messages = list(messages)  # accumulate across retries
    total_prompt = 0
    total_completion = 0
    total_api_wait = 0.0
    best: dict = {
        "extracted": "",
        "err_count": float("inf"),
        "compile_output": "",
        "attempt_idx": -1,
        "response_text": "",
    }

    current_messages = list(messages)
    # H5b (2026-04-13): when partial-theorem retry reduced error count,
    # skip the next whole-file completion and go straight to another
    # partial pass. Whole-file retries between partials were observed
    # to REGRESS (e.g. 1 error → 2 errors), undoing partial's gains.
    # Only do a whole-file retry when partial stalls (err_count doesn't
    # decrease) — then we genuinely need new ideas.
    skip_next_completion = False
    response_text = ""
    extracted = ""
    compile_output = ""
    err_count = 0

    for attempt_idx in range(max_attempts):
        if skip_next_completion:
            skip_next_completion = False
            # Reuse current extracted/compile_output/err_count from the
            # prior partial-retry step. Record a cheap bookkeeping entry
            # so the log still shows 1 "outer attempt" per iteration.
            attempts_log.append({
                "attempt": attempt_idx + 1,
                "strategy": "partial-continuation",
                "content_len": len(extracted),
                "err_count": err_count,
                "skipped_whole_file_completion": True,
            })
            print(
                f"  Phase {phase_num}/attempt {attempt_idx + 1}: "
                f"skipping whole-file completion (partial made progress), "
                f"re-running partial on current state ({err_count} errors)"
            )
            # Fall through to the partial/whole-file retry-prep block
            # below. We skip the completion call entirely.
            pass
        else:
            t0 = time.time()
            response_text = ""
            resp_prompt = 0
            resp_completion = 0
            try:
                kwargs = dict(
                    model=model,
                    max_tokens=max_tok,
                    messages=current_messages,
                )
                if api_base:
                    kwargs["api_base"] = api_base
                if api_key:
                    kwargs["api_key"] = api_key
                response = completion_fn(**kwargs)
                if hasattr(response, "usage") and response.usage:
                    resp_prompt = response.usage.prompt_tokens or 0
                    resp_completion = response.usage.completion_tokens or 0
                    total_prompt += resp_prompt
                    total_completion += resp_completion
                if hasattr(response, "choices") and response.choices:
                    response_text = response.choices[0].message.content or ""
            except Exception as e:  # noqa: BLE001 — broad-catch fallback
                total_api_wait += time.time() - t0
                errors.append(f"attempt {attempt_idx + 1} API error: {e}")
                stop_reason = f"no-tools API error: {type(e).__name__}"
                # Can't continue if API itself is broken
                break

            # Extract file content + write to workdir
            extracted = _extract_fenced(response_text)
            out_path = workdir / "data" / output_rel
            try:
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(extracted)
            except Exception as e:  # noqa: BLE001 — broad-catch fallback
                errors.append(f"attempt {attempt_idx + 1} write failed: {e}")
                continue

            # Preserve this attempt's extracted content to a persistent trace
            # directory so partial-progress is never lost even if a later
            # attempt over-corrects (aidan 2026-04-13: "save student traces as
            # much as possible"). Mirrors the per-phase JSON trace pattern.
            attempt_snapshot_path = None
            try:
                env_dir_guess = Path(os.environ.get("EVAL_ENV_DIR", "")).expanduser()
                if env_dir_guess.exists():
                    model_slug = model.replace("/", "-").replace(":", "-")
                    snap_dir = env_dir_guess / "traces" / model_slug
                    snap_dir.mkdir(parents=True, exist_ok=True)
                    ts = time.strftime("%Y%m%d_%H%M%S")
                    attempt_snapshot_path = (
                        snap_dir
                        / f"{task.get('id','task')}_phase{phase_num}_attempt{attempt_idx+1}_{ts}.lean"
                    )
                    attempt_snapshot_path.write_text(extracted)
            except Exception:  # noqa: BLE001 — broad-catch fallback
                attempt_snapshot_path = None  # best-effort; don't fail the run

            # Compile-check
            err_count, compile_output = _lean_compile_check(out_path)
            attempt_info = {
                "attempt": attempt_idx + 1,
                "content_len": len(extracted),
                "prompt_tokens": resp_prompt,
                "completion_tokens": resp_completion,
                "err_count": err_count,
                "compile_output_preview": compile_output[:800] if compile_output else "",
                "snapshot_path": str(attempt_snapshot_path) if attempt_snapshot_path else None,
            }
            attempts_log.append(attempt_info)
            print(
                f"  Phase {phase_num}/attempt {attempt_idx + 1}: "
                f"{len(extracted)} chars written, {err_count} compile errors"
            )

            # Emit this attempt's assistant message so trace has visibility
            all_messages.append({"role": "assistant", "content": response_text})

            # Track best attempt (fewest errors; tiebreaker: latest)
            if err_count < best["err_count"] or (
                err_count == best["err_count"] and len(extracted) > len(best["extracted"])
            ):
                best = {
                    "extracted": extracted,
                    "err_count": err_count,
                    "compile_output": compile_output,
                    "attempt_idx": attempt_idx,
                    "response_text": response_text,
                }

        # Success — clean compile, no need to retry
        if err_count == 0:
            print(f"  Phase {phase_num}: clean compile on attempt {attempt_idx + 1}, stopping retries")
            break

        # Prepare retry for next iteration.
        #
        # H5 partial-theorem retry (2026-04-13): prefer surgical fixes over
        # whole-file rewrites. Parse the current file into decl blocks,
        # map errors to decls, and if all errors land inside one or more
        # theorems/lemmas, re-prompt the model for ONLY the failing
        # decl(s). Splice the rewrites back, recompile, and record the
        # result as the NEXT attempt's telemetry.
        #
        # If errors don't map to any decl (import / namespace issues), or
        # the model returns unusable content, fall back to whole-file
        # retry (H4 behavior) for that attempt.
        if attempt_idx + 1 < max_attempts:
            decls = _parse_lean_decls(extracted)
            err_map = _map_errors_to_decls(compile_output, decls)

            # Decide strategy: partial iff we parsed decls AND every
            # reported compile error landed inside one of them.
            total_errs_mapped = sum(len(e["errors"]) for e in err_map.values())
            use_partial = (
                bool(decls) and bool(err_map) and total_errs_mapped >= err_count
            )

            if use_partial:
                # --------- PARTIAL-THEOREM RETRY ---------
                print(
                    f"  Phase {phase_num}/attempt {attempt_idx + 2}: "
                    f"partial-theorem retry on {len(err_map)} decl(s): "
                    f"{', '.join(err_map.keys())}"
                )
                # Start from the current best-full-file content so we
                # preserve compiling theorems.
                current_full = extracted
                # Iterate failing decls in file order (not dict order)
                for d in sorted(
                    (e["decl"] for e in err_map.values()), key=lambda x: x["start_line"]
                ):
                    fix_data = err_map[d["name"]]
                    errs_str = "\n".join(fix_data["errors"])
                    narrow_prompt = (
                        f"One declaration in your Lean file failed to "
                        f"compile in Mathlib v4.15.0:\n\n"
                        f"```lean\n{d['body']}\n```\n\n"
                        f"Compiler errors for this declaration:\n{errs_str}\n\n"
                        f"Rewrite ONLY this one declaration. Output the "
                        f"complete replacement in a single ```lean``` "
                        f"fenced block, starting with `{d['kind']} "
                        f"{d['name']}` and ending when the proof/body "
                        f"closes. Do NOT output any other theorems, imports, "
                        f"or namespace declarations — just this block. Keep "
                        f"the statement identical unless it is provably "
                        f"false as stated (in which case add a "
                        f"`-- corrected:` comment on the line above)."
                    )
                    # One completion call per failing decl. Each uses the
                    # SAME base context (no accumulated history to avoid
                    # context bloat and prompt-leakage).
                    narrow_messages = messages + [
                        {"role": "user", "content": narrow_prompt},
                    ]
                    try:
                        kw = dict(model=model, max_tokens=max_tok, messages=narrow_messages)
                        if api_base:
                            kw["api_base"] = api_base
                        if api_key:
                            kw["api_key"] = api_key
                        nresp = completion_fn(**kw)
                        if hasattr(nresp, "usage") and nresp.usage:
                            total_prompt += nresp.usage.prompt_tokens or 0
                            total_completion += nresp.usage.completion_tokens or 0
                        ntext = ""
                        if hasattr(nresp, "choices") and nresp.choices:
                            ntext = nresp.choices[0].message.content or ""
                    except Exception as e:  # noqa: BLE001 — broad-catch fallback
                        errors.append(f"partial retry on {d['name']} failed: {e}")
                        continue
                    all_messages.append({"role": "assistant", "content": ntext})
                    new_body = _extract_single_decl(ntext, d["name"])
                    if not new_body:
                        continue
                    # Re-parse current_full in case a prior splice shifted
                    # line numbers; find the decl by name and splice.
                    cur_decls = _parse_lean_decls(current_full)
                    cur = next(
                        (x for x in cur_decls if x["name"] == d["name"]),
                        None,
                    )
                    if cur is None:
                        continue
                    current_full = _splice_decl(current_full, cur, new_body)

                # Write the spliced file and record as the next attempt.
                out_path.write_text(current_full)
                nerr_count, ncompile_output = _lean_compile_check(out_path)
                # Snapshot the partial-retry result too
                partial_snapshot = None
                try:
                    env_dir_guess = Path(os.environ.get("EVAL_ENV_DIR", "")).expanduser()
                    if env_dir_guess.exists():
                        model_slug = model.replace("/", "-").replace(":", "-")
                        snap_dir = env_dir_guess / "traces" / model_slug
                        snap_dir.mkdir(parents=True, exist_ok=True)
                        ts = time.strftime("%Y%m%d_%H%M%S")
                        partial_snapshot = (
                            snap_dir / f"{task.get('id','task')}_phase{phase_num}_attempt{attempt_idx+2}_partial_{ts}.lean"
                        )
                        partial_snapshot.write_text(current_full)
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    partial_snapshot = None
                partial_info = {
                    "attempt": attempt_idx + 2,
                    "strategy": "partial-theorem",
                    "decls_rewritten": list(err_map.keys()),
                    "content_len": len(current_full),
                    "err_count": nerr_count,
                    "compile_output_preview": (ncompile_output or "")[:800],
                    "snapshot_path": str(partial_snapshot) if partial_snapshot else None,
                }
                attempts_log.append(partial_info)
                print(
                    f"  Phase {phase_num}/attempt {attempt_idx + 2} "
                    f"(partial, {len(err_map)} decl(s)): {nerr_count} "
                    f"compile errors"
                )
                # Track best (the spliced file could be best)
                if nerr_count < best["err_count"] or (
                    nerr_count == best["err_count"] and len(current_full) > len(best["extracted"])
                ):
                    best = {
                        "extracted": current_full,
                        "err_count": nerr_count,
                        "compile_output": ncompile_output,
                        "attempt_idx": attempt_idx + 1,
                        "response_text": "[partial-theorem retry]",
                    }
                if nerr_count == 0:
                    print(f"  Phase {phase_num}: clean compile after partial-theorem retry, stopping")
                    break

                # H5b (2026-04-13): decide whether to let the next iteration
                # do another whole-file completion, or skip to another
                # partial pass. Empirically (validated on partial-retry
                # run tonight), whole-file retries seeded with partial
                # state tend to REGRESS — undoing the partial's gains.
                # So: only do a whole-file retry when partial STALLED
                # (didn't reduce errors). When partial MADE PROGRESS,
                # skip the whole-file completion and run partial again
                # directly on the current state.
                prev_err_count_for_compare = err_count  # captured before we overwrite below
                extracted = current_full
                compile_output = ncompile_output
                err_count = nerr_count

                if nerr_count < prev_err_count_for_compare:
                    # Progress — skip next whole-file completion, re-run partial
                    skip_next_completion = True
                    print(
                        f"  Phase {phase_num}: partial made progress "
                        f"({prev_err_count_for_compare} → {nerr_count}), "
                        f"skipping next whole-file retry and running partial again"
                    )
                else:
                    # Partial stalled — seed a fresh whole-file retry
                    # with richer context to break the stall.
                    current_messages = messages + [
                        {
                            "role": "assistant",
                            "content": (
                                f"[After targeted partial-theorem fixes on "
                                f"{', '.join(err_map.keys())}, the file "
                                f"still has {nerr_count} compile error(s) "
                                f"(same as before — partial retry STALLED). "
                                f"Here is the CURRENT state of the file "
                                f"including the partial fixes:]\n\n"
                                f"```lean_final\n{current_full[:10000]}\n```"
                            ),
                        },
                        {
                            "role": "user",
                            "content": (
                                f"The partial-theorem retry has stalled at "
                                f"{nerr_count} compile error(s). Compiler output:\n\n"
                                f"```\n{(ncompile_output or '')[:3000]}\n```\n\n"
                                f"Partial retry keeps re-attempting the same decls "
                                f"without progress. Take a WIDER view: the error "
                                f"might be in a def, typeclass, or lemma used by "
                                f"these theorems — look beyond the failing decl "
                                f"itself. Rewrite the COMPLETE file with all "
                                f"remaining errors fixed. Output one "
                                f"```lean_final``` fenced block containing the "
                                f"entire file."
                            ),
                        },
                    ]
                continue

            # --------- WHOLE-FILE RETRY (fallback) ---------
            retry_prompt = (
                f"Your previous attempt (attempt {attempt_idx + 1}) produced a file "
                f"with {err_count} Lean compile error(s). Here's the compiler output:\n\n"
                f"```\n{compile_output[:3000]}\n```\n\n"
                "Fix the specific errors and regenerate the COMPLETE file in ONE "
                "```lean_final``` fenced block. Keep theorems that already compile "
                "unchanged — target only the failing ones. Common causes of these "
                "errors in Mathlib v4.15.0: deprecated lemma names (prefer the "
                "`_of_le₀` / `₀` variants), wrong argument order, typo in constant "
                "names. Use `exact?` / `apply?` mentally to find the right lemma."
            )
            current_messages = current_messages + [
                {"role": "assistant", "content": response_text[:6000]},
                {"role": "user", "content": retry_prompt},
            ]

    # Write the BEST attempt to the workdir (might overwrite a later-but-worse one)
    best_written = False
    if best["attempt_idx"] >= 0:
        out_path = workdir / "data" / output_rel
        try:
            out_path.write_text(best["extracted"])
            best_written = True
            tool_calls_log.append(
                f"no-tools-write: {output_rel} "
                f"(best attempt={best['attempt_idx'] + 1}/{max_attempts}, "
                f"{len(best['extracted'])} chars, {best['err_count']} compile errors)"
            )
            print(
                f"  Phase {phase_num}: writing BEST attempt "
                f"#{best['attempt_idx'] + 1}/{max_attempts} "
                f"({best['err_count']} errors, {len(best['extracted'])} chars)"
            )
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            errors.append(f"failed to write best attempt: {e}")
    if not best_written:
        stop_reason = stop_reason or "no-tools phase: no attempt succeeded"

    total_tokens_used = total_prompt + total_completion

    return {
        "tool_calls_log": tool_calls_log,
        "errors": errors,
        "api_wait_penalty": total_api_wait,
        "total_tokens": total_tokens_used,
        "prompt_tokens": total_prompt,
        "completion_tokens": total_completion,
        "cache_creation_tokens": 0,
        "cache_read_tokens": 0,
        "stop_reason": stop_reason,
        "messages": all_messages,
        # Extra no-tools-specific telemetry (platform chat UI can render
        # the attempt history as a multi-step "I tried 3 times" narrative).
        "no_tools_attempts": attempts_log,
        "no_tools_best_attempt": best["attempt_idx"] + 1 if best["attempt_idx"] >= 0 else 0,
        "no_tools_final_err_count": best["err_count"] if best["err_count"] != float("inf") else -1,
    }


def run_student_trial(
    env_dir: Path,
    model: str,
    task: dict,
    live_run_id: str | None = None,
    max_time: int = 2400,
) -> dict:
    """Spawn a LiteLLM-backed student agent for one task and score the result.

    Returns a dict with score, tool call log, timing, and any errors.
    """
    try:
        from litellm import completion
    except ImportError:
        return {"status": "SKIP", "reason": "litellm not installed (pip install litellm)"}

    api_keys = [
        "LITELLM_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
        "GEMINI_API_KEY", "AZURE_API_KEY", "AZURE_AI_API_KEY",
    ]
    if not any(os.environ.get(k) for k in api_keys):
        return {
            "status": "SKIP",
            "reason": "No API key found. Set one of: " + ", ".join(api_keys),
        }

    # Auto-detect Azure-hosted Anthropic endpoint.
    # Azure AI Inference doesn't support the native Anthropic API, so we
    # rewrite the provider from "anthropic/" to "azure_ai/" and pass api_base.
    #
    # NOTE: This resolves for the RUN-level model. Multi-phase tasks using
    # `phase_models` can dispatch a different model per phase — each phase
    # re-runs the resolution inline via `_resolve_anthropic_azure()` below so
    # a Gemini-Builder × Kimi-Verifier × Sonnet-Finisher composition gets
    # the right api_base/api_key for the Sonnet leg without inheriting
    # Gemini's (None, None) defaults.
    # Fixed 2026-04-12 after ATH-105 3-phase sweep v2 failed Phase 3 Sonnet
    # auth despite the MODEL_PRICES + key-lookup fix — the rewrite was
    # firing for the wrong model.
    model, api_base, api_key = _resolve_anthropic_azure(model)

    scoring_path = find_scoring_script(env_dir)
    if not scoring_path:
        return {"status": "SKIP", "reason": "No scoring script"}

    print(f"  Task: {task['id']}")
    # ATH-236: route model name through _redact_secrets so CodeQL
    # recognizes the sanitizer barrier. re.sub-based helper breaks
    # taint where user-defined identity wrappers don't.
    print(f"  Model: {_redact_secrets(str(model))}")

    # ---- Set up temporary workdir simulating the container layout ----
    workdir = Path(tempfile.mkdtemp(prefix="eval-workdir-"))
    student_data = env_dir / "student_data"
    shared_data = env_dir / "shared_data"

    data_dir = workdir / "data"
    data_dir.mkdir(parents=True)

    lean_filename = task.get("lean_filename", "")
    solution_file = task.get("solution_file", "")
    # Always copy the full student_data tree. The prior selective-copy optimization
    # was broken in two ways:
    #   1. Missing parent-dir creation crashed envs whose solution_file lives in a
    #      subdirectory (e.g. cedar's "debug_healthcare_records/policies.cedar").
    #   2. When the configured solution_file path didn't match the on-disk layout
    #      (e.g. distributed-consensus config "hybrid_clock.go" vs disk
    #      "consensus/hybrid_clock.go"), nothing was copied and the agent ran
    #      against an empty workdir.
    # student_data is small (< 1MB per env) so always copying everything is fine.
    if student_data.exists():
        shutil.copytree(student_data, data_dir, dirs_exist_ok=True)

    shared_dir = workdir / "shared"
    if shared_data.exists():
        shutil.copytree(shared_data, shared_dir)
    else:
        shared_dir.mkdir(parents=True)

    # ---- Build student prompt ----
    context = [f"You are attempting this task:\n\n{task['instructions']}"]
    context.append("\nYour working directory is /workdir/data")
    context.append("Student data is at /workdir/data/")
    context.append("Shared reference is at /workdir/shared/")

    # Inline only task-specific files, not all student_data
    if lean_filename or solution_file:
        for fn in (solution_file, lean_filename):
            # Strip container path prefix if present (configs may use /workdir/data/...)
            if fn:
                fn = fn.replace("/workdir/data/", "").lstrip("/")
            if fn and (data_dir / fn).exists():
                try:
                    context.append(f"\n--- data/{fn} ---\n{(data_dir / fn).read_text()}")
                except UnicodeDecodeError:
                    pass
    elif student_data.exists():
        for f in sorted(student_data.rglob("*")):
            if f.is_file() and f.stat().st_size < 3000:
                rel = f.relative_to(student_data)
                try:
                    context.append(f"\n--- data/{rel} ---\n{f.read_text()}")
                except UnicodeDecodeError:
                    pass

    if shared_data.exists():
        for f in sorted(shared_data.rglob("*")):
            if f.is_file() and f.stat().st_size < 3000:
                rel = f.relative_to(shared_data)
                try:
                    context.append(f"\n--- shared/{rel} ---\n{f.read_text()}")
                except UnicodeDecodeError:
                    pass

    task_prompt = "\n".join(context)

    system_prompt = """\
You are a coding agent that solves tasks by reading, writing, and testing code. \
You MUST use the provided tools (bash, read_file, edit_file) to interact with files. \
Do NOT just describe what you would do -- actually do it by calling tools.

Workflow: read the task files, plan your approach, implement the solution using \
edit_file or bash, then test it with bash. Iterate until it works.

Rules:
- Use `read_file` to inspect files and `edit_file` to modify them.
- Use `bash` to run tests, compile code, or execute scripts.
- `edit_file` requires EXACT literal string matching for `old_string`.
- Write your solution files to /workdir/data.
- Do NOT access /root_data/ or /root/ -- those are locked.
- Start by reading the task files to understand what's needed."""

    # Student agent runs in an isolated temp workdir -- it cannot access env_dir
    # directly. The bash tool runs with cwd=workdir/data, read_file/edit_file are
    # sandboxed via is_relative_to check. No need to chmod root_data.
    # This allows multiple evaluate.py processes to run concurrently on the same env.

    # ---- Multi-phase agent loop ----
    # When task config has "phases": N (N > 1), each phase runs a fresh LLM
    # conversation on the same workdir. Phase 1 uses task['instructions'],
    # phase 2+ uses task[f'phase{p}_instructions']. Agents communicate only
    # via files in the workdir. Scoring happens once after all phases complete.
    # For single-phase tasks (phases=1, the default), behavior is identical
    # to before this refactor.

    num_phases = task.get("phases", 1)

    # ATH-229 follow-up (research, 2026-04-15): `phase_model` MUST be the
    # per-phase model, not the outer run-level model. Heterogeneous
    # phase_models like [gemini-3-flash, kimi, kimi] under a Sonnet
    # run-level wrapper need plain-string content for the Gemini phase —
    # building with cache_control for an outer Sonnet breaks Gemini
    # Vertex with:
    #   "CachedContent can not be used with GenerateContent request
    #    setting system_instruction, tools or tool_config."
    # Bug surfaced 2026-04-14 on fused_attention_softmax_verified Phase 4
    # inner builders — was bug-compatible with the HERO demo commit
    # because that demo used phase_models=[Flash, Kimi, Kimi] under outer
    # gemini/gemini-3-flash-preview (is_claude was False at the outer
    # level, so the cache_control branch never fired). Once the same
    # task ran under outer Sonnet, Vertex rejected.
    def _build_phase_messages(phase_prompt: str, phase_model: str) -> list:
        """Build the system + user messages for one phase. Adds prompt
        caching annotations only when the PHASE model (not the outer
        run-level model) is Anthropic/Claude."""
        is_claude_phase = (
            "claude" in phase_model.lower() or "anthropic" in phase_model.lower()
        )
        if is_claude_phase:
            return [
                {"role": "system", "content": [
                    {"type": "text", "text": system_prompt,
                     "cache_control": {"type": "ephemeral"}},
                ]},
                {"role": "user", "content": [
                    {"type": "text", "text": phase_prompt,
                     "cache_control": {"type": "ephemeral"}},
                ]},
            ]
        else:
            return [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": phase_prompt},
            ]

    # Aggregate metrics across all phases
    all_tool_calls_log = []
    all_errors = []
    all_messages = []   # all phases' messages for trace capture
    phase_metrics = []
    # ATH-118: per-phase full trace capture for multi-agent UI (Builder /
    # Verifier renders as two separate rows in agent_traces, each with its
    # own messages[] + token split + cost_usd_estimate). Kept alongside the
    # legacy aggregate fields so existing single-phase consumers still work.
    per_phase_traces = []
    total_tokens_used = 0
    total_prompt_tokens = 0
    total_completion_tokens = 0
    cache_creation_tokens = 0
    cache_read_tokens = 0
    total_api_wait = 0.0
    stop_reason = None

    start_time = time.time()

    print("  Running student agent...")
    _emit_trace_event(live_run_id, task["id"], 0, "status",
                      content=f"Task started: {task['id']}" +
                      (f" ({num_phases} phases)" if num_phases > 1 else ""))

    # Builder-verifier mode: strip solution source files between phases so
    # the Verifier can only see the Builder's OUTPUT (JSON files), not the
    # code that produced it. This makes Verifier actually verify the
    # numerical result instead of just re-reading the Builder's logic.
    # Triggered by task["mode"] == "builder_verifier" in config.
    is_builder_verifier = task.get("mode") == "builder_verifier"

    # Per-phase model dispatch (ATH-102). Optional task-config field
    # `phase_models: [model, model, ...]` overrides `model` per phase —
    # lets you compose e.g. Mistral Builder × Kimi Verifier to match
    # each model's capability strength (Kimi is a reliable auditor but
    # weak builder; Mistral engages as builder but is expensive). When
    # absent, every phase uses the run-level `model` (backward-compat).
    phase_models_cfg = task.get("phase_models")
    if phase_models_cfg:
        if len(phase_models_cfg) != num_phases:
            raise ValueError(
                f"task['phase_models'] length {len(phase_models_cfg)} "
                f"does not match task['phases']={num_phases}"
            )
        per_phase_models = [m.lower() for m in phase_models_cfg]
    else:
        per_phase_models = [model] * num_phases

    for phase_num in range(1, num_phases + 1):
        # Determine the instructions for this phase
        if phase_num == 1:
            # Default: the task's main prompt/description (existing 1-3 phase
            # task behavior — Phase 1 is the Builder).
            # Override: if task config has `phase1_instructions`, use that
            # instead. Introduced for 4-phase pipelines where Phase 1 is a
            # Designer (theorem-stating) rather than Builder.
            phase_instructions = task.get("phase1_instructions") or task_prompt
        else:
            # Builder-verifier: remove Builder source files between
            # phases so the Verifier audits the OUTPUT, not the code.
            #
            # Two strategies, configurable per-task:
            #
            # 1. Default (numeric-output envs like protein-multi-agent):
            #    strip source code (.py/.lean/.rs/etc) and keep
            #    output JSON. Verifier sees only the result files.
            #
            # 2. verifier_inputs mode (proof envs like lean, or any env
            #    where the "output" IS a source file): task config has
            #    verifier_inputs: ["BinarySearch.lean"]. We keep those
            #    files + verification_report.json + handoff.json, and
            #    strip everything else. This way lean's .lean file
            #    (which IS the output) is preserved while scratch files
            #    and other source get removed.
            if is_builder_verifier and phase_num == 2:
                verifier_inputs = task.get("verifier_inputs") or []
                removed = []

                if verifier_inputs:
                    # Whitelist mode: keep only explicit inputs + report files
                    keep = {str(Path(p).as_posix()).lstrip("/") for p in verifier_inputs}
                    keep |= {"verification_report.json", "handoff.json"}
                    for f in list(data_dir.rglob("*")):
                        if not f.is_file():
                            continue
                        rel = str(f.relative_to(data_dir).as_posix())
                        if rel in keep or rel.endswith(tuple(keep)):
                            continue
                        try:
                            f.unlink()
                            removed.append(rel)
                        except Exception:  # noqa: BLE001 — cleanup file unlink; tolerate already-removed
                            pass
                else:
                    # Source-strip mode: remove code files, keep outputs
                    for f in list(data_dir.rglob("*")):
                        if f.is_file() and f.suffix in (".py", ".lean", ".rs",
                                                         ".dfy", ".cpp", ".v",
                                                         ".sv", ".go"):
                            try:
                                f.unlink()
                                removed.append(str(f.relative_to(data_dir)))
                            except Exception:  # noqa: BLE001 — cleanup file unlink; tolerate already-removed
                                pass

                if removed:
                    mode_desc = "whitelist" if verifier_inputs else "source-strip"
                    print(f"  builder-verifier ({mode_desc}): stripped {len(removed)} "
                          f"file(s) before Verifier phase: "
                          f"{', '.join(removed[:5])}"
                          f"{'...' if len(removed) > 5 else ''}")

                # Optional: inject a known-broken output before Verifier
                # runs. Tests Verifier audit skill independently of
                # Builder capability. Flagged by config
                # adversarial_inject_broken: true.
                if task.get("adversarial_inject_broken"):
                    inject_script = env_dir / "scripts" / "adversarial_inject.py"
                    if inject_script.exists():
                        try:
                            import subprocess as _ais
                            inj = _ais.run(
                                [sys.executable, str(inject_script),
                                 "--task", task["id"],
                                 "--workdir", str(data_dir),
                                 "--env-dir", str(env_dir)],
                                capture_output=True, text=True, timeout=30,
                            )
                            if inj.returncode == 0:
                                print(f"  adversarial-inject: {inj.stdout.strip()[:200]}")
                        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
                            print(f"  adversarial-inject failed: {e}")

            phase_key = f"phase{phase_num}_instructions"
            raw_instructions = task.get(phase_key)
            if not raw_instructions:
                all_errors.append(f"Phase {phase_num}: missing '{phase_key}' in task config")
                break
            # Build the phase prompt the same way as phase 1: instructions +
            # workdir context + inline files (files may have changed since
            # phase 1, so re-read from workdir)
            phase_context = [f"You are attempting this task (phase {phase_num} of {num_phases}):\n\n{raw_instructions}"]
            phase_context.append("\nYour working directory is /workdir/data")
            phase_context.append("Student data is at /workdir/data/")
            phase_context.append("Shared reference is at /workdir/shared/")
            # Inline current workdir files so the new agent sees what
            # previous phases produced (same logic as phase 1 but reads
            # from the live workdir, not the original student_data)
            if lean_filename or solution_file:
                for fn in (solution_file, lean_filename):
                    if fn:
                        fn = fn.replace("/workdir/data/", "").lstrip("/")
                    if fn and (data_dir / fn).exists():
                        try:
                            phase_context.append(f"\n--- data/{fn} ---\n{(data_dir / fn).read_text()}")
                        except UnicodeDecodeError:
                            pass
            else:
                for f in sorted(data_dir.rglob("*")):
                    if f.is_file() and f.stat().st_size < 3000:
                        rel = f.relative_to(data_dir)
                        try:
                            phase_context.append(f"\n--- data/{rel} ---\n{f.read_text()}")
                        except UnicodeDecodeError:
                            pass
            if shared_dir.exists():
                for f in sorted(shared_dir.rglob("*")):
                    if f.is_file() and f.stat().st_size < 3000:
                        rel = f.relative_to(shared_dir)
                        try:
                            phase_context.append(f"\n--- shared/{rel} ---\n{f.read_text()}")
                        except UnicodeDecodeError:
                            pass
            phase_instructions = "\n".join(phase_context)

        # ATH-102: resolve per-phase model. Falls back to run-level `model`
        # when task didn't supply `phase_models`.
        current_model = per_phase_models[phase_num - 1]

        # ATH-229 follow-up: _build_phase_messages takes phase_model so
        # cache_control annotations only fire when the PHASE model is
        # Claude, not when the outer run-level model is Claude.
        messages = _build_phase_messages(phase_instructions, current_model)
        phase_start = time.time()

        # Per-phase Azure-Anthropic resolution. Critical for heterogeneous
        # phase_models where e.g. Phase 1 is Gemini (no anthropic rewrite
        # needed, api_base/api_key stay None) and Phase 3 is Sonnet (needs
        # the rewrite to azure_ai/ + api_base + api_key). Without this,
        # Sonnet would inherit Gemini's defaults and 401 on auth. Fixed
        # 2026-04-12 after ATH-105 v2 sweep.
        resolved_model, phase_api_base, phase_api_key = _resolve_anthropic_azure(current_model)

        # ATH-227: strict provider isolation — see _resolve_phase_credentials.
        eff_api_base, eff_api_key = _resolve_phase_credentials(
            current_model=current_model,
            run_level_model=model,
            phase_api_base=phase_api_base,
            phase_api_key=phase_api_key,
            run_api_base=api_base,
            run_api_key=api_key,
        )

        # ATH-105 customer-demo support: per-phase container override.
        # Task config `phase_containers: [img1, img2, img3]` (one per phase,
        # None or "" to inherit the default env image) lets e.g. Phase 3
        # run inside neuron-nki-kernels:solve (Mathlib-enabled) while the
        # default eval container (and scoring) stays on :latest. Critical
        # for the Mathlib-in-solve-only architecture — customer evals are
        # run on the Mathlib-FREE :latest container for benchmark purity.
        global _SANDBOX_IMAGE
        _orig_sandbox_image = _SANDBOX_IMAGE
        phase_containers = task.get("phase_containers") or []
        if phase_num - 1 < len(phase_containers):
            override_img = phase_containers[phase_num - 1]
            if override_img:
                _SANDBOX_IMAGE = override_img
                print(f"  Phase {phase_num} bash sandbox: {override_img}")

        if num_phases > 1:
            # ATH-236: _redact_secrets (re.sub-based) is the sanitizer
            # CodeQL recognizes.
            model_suffix = f" [{_redact_secrets(str(current_model))}]" if current_model != model else ""
            print(f"  Phase {phase_num}/{num_phases}...{model_suffix}")
            _emit_trace_event(live_run_id, task["id"], 0, "status",
                              content=f"Phase {phase_num}/{num_phases} started"
                                      + (f" ({current_model})" if current_model != model else ""))

        # ATH-105 no-tools one-shot mode (for models that silently ignore
        # `tools`, e.g. DeepSeek-V3.2-Speciale — research-only, no tool
        # invocation per Azure docs, empirically verified 2026-04-12).
        # Task config `phase_no_tools: [3]` lists which 1-indexed phases
        # should skip the agent loop and instead do a single completion
        # call with full context, parsing the replacement file content
        # out of a ```<lang>...``` fenced block in the response. File
        # written to /workdir/data/<phase_output_file> (default: task's
        # lean_file).
        phase_no_tools = task.get("phase_no_tools") or []
        is_no_tools = phase_num in phase_no_tools

        try:
            if is_no_tools:
                loop_result = _run_no_tools_phase(
                    completion_fn=completion,
                    messages=messages,
                    model=resolved_model,
                    workdir=workdir,
                    task=task,
                    api_base=eff_api_base,
                    api_key=eff_api_key,
                    phase_num=phase_num,
                )
            else:
                loop_result = _run_agent_loop(
                    completion_fn=completion,
                    messages=messages,
                    model=resolved_model,
                    workdir=workdir,
                    max_time=max_time,
                    task=task,
                    live_run_id=live_run_id,
                    api_base=eff_api_base,
                    api_key=eff_api_key,
                    start_time=start_time,
                    prior_api_wait=total_api_wait,
                    prior_tokens=total_tokens_used,
                )
        finally:
            # Restore the default sandbox image so scoring + subsequent
            # phases don't leak the per-phase override.
            _SANDBOX_IMAGE = _orig_sandbox_image

        phase_wall = time.time() - phase_start
        phase_api_wait = loop_result["api_wait_penalty"]
        phase_elapsed = max(0.0, phase_wall - phase_api_wait)
        phase_tokens = loop_result["total_tokens"]
        phase_prompt = loop_result.get("prompt_tokens", 0)
        phase_completion = loop_result.get("completion_tokens", 0)
        phase_cache_create = loop_result["cache_creation_tokens"]
        phase_cache_read = loop_result["cache_read_tokens"]
        phase_tc_count = len(loop_result["tool_calls_log"])

        # ATH-118: per-phase cost estimate (best-effort, not billing-reconciled).
        # Uses athanor-builder/shared/scripts/model_prices.py.
        phase_cost_estimate = _estimate_cost_usd(
            model=current_model,
            prompt_tokens=phase_prompt,
            completion_tokens=phase_completion,
            cache_creation_tokens=phase_cache_create,
            cache_read_tokens=phase_cache_read,
        )

        # Accumulate into overall totals
        all_tool_calls_log.extend(loop_result["tool_calls_log"])
        all_errors.extend(loop_result["errors"])
        all_messages.extend(loop_result["messages"])
        total_tokens_used += phase_tokens
        total_prompt_tokens += phase_prompt
        total_completion_tokens += phase_completion
        cache_creation_tokens += phase_cache_create
        cache_read_tokens += phase_cache_read
        total_api_wait += phase_api_wait
        if loop_result["stop_reason"]:
            stop_reason = loop_result["stop_reason"]

        phase_metrics.append({
            "phase": phase_num,
            "model": current_model,  # ATH-102: per-phase model dispatch
            "time_seconds": round(phase_elapsed, 1),
            "total_tokens": phase_tokens,
            "prompt_tokens": phase_prompt,
            "completion_tokens": phase_completion,
            "cache_creation_tokens": phase_cache_create,
            "cache_read_tokens": phase_cache_read,
            "cost_usd_estimate": phase_cost_estimate,
            "tool_calls": phase_tc_count,
        })

        # ATH-118: capture per-phase trace for multi-agent UI. Each phase's
        # messages[] is emitted independently — platform will POST one
        # agent_traces row per phase with phase=N and cost_usd_estimate.
        # phase_metrics (aggregate) kept on phase=1 row per platform's read.
        per_phase_traces.append({
            "phase": phase_num,
            "model": current_model,
            "messages": loop_result["messages"],
            "total_tokens": phase_tokens,
            "prompt_tokens": phase_prompt,
            "completion_tokens": phase_completion,
            "cache_creation_tokens": phase_cache_create,
            "cache_read_tokens": phase_cache_read,
            "cost_usd_estimate": phase_cost_estimate,
            "tool_calls_count": phase_tc_count,
            "time_seconds": round(phase_elapsed, 1),
        })

        # v2 handoff-summary: one cheap LLM call per phase to produce a
        # 2-3 sentence natural-language note for the multi-agent chat UI.
        # Failures are silently swallowed — never block the pipeline.
        # Only generated for multi-phase tasks (single-phase summary is NULL,
        # matching the DB column default).
        #
        # ATH-134 fixes (2026-04-13):
        #  - Use a STABLE summarizer model (Gemini Flash) across phases instead
        #    of the phase model itself. Speciale (no-tools) regurgitates the
        #    prompt; Kimi sometimes returns empty content when expecting tools;
        #    Flash truncated at 300 tokens. A single fast model fixes all three.
        #  - Bump max_tokens 300 → 600 so the 500-char cap is the binding
        #    constraint, not the token budget.
        #  - Fix phase-role labels for 3-phase builder_verifier mode:
        #    Phase 1=Builder, Phase 2=Verifier, Phase 3=Finisher (was
        #    mis-labeling Phase 3 as "Verifier").
        #  - Honor task config `agent_roles[i].label` if present.
        handoff_summary = ""
        if num_phases > 1:
            agent_roles = task.get("agent_roles") or []
            role_from_config = None
            for _ar in agent_roles:
                if isinstance(_ar, dict) and _ar.get("phase") == phase_num:
                    role_from_config = _ar.get("label")
                    break
            if role_from_config:
                phase_role = role_from_config
            else:
                phase_role = task.get(f"phase{phase_num}_role")
            if not phase_role:
                # Default labels that don't mis-label Phase 3 in 3-phase BV mode.
                if num_phases == 3 and task.get("mode") == "builder_verifier":
                    phase_role = {1: "Builder", 2: "Verifier", 3: "Finisher"}.get(phase_num, f"Phase {phase_num}")
                else:
                    phase_role = (
                        "Builder" if phase_num == 1 else
                        "Verifier" if phase_num == num_phases else
                        f"Phase {phase_num}"
                    )

            # Brief context excerpt from the phase's own assistant turns
            # so the summarizer has something to summarize. Last 2 assistant
            # messages, capped to keep the summarizer call cheap.
            _ctx_chunks: list[str] = []
            try:
                for _m in reversed(loop_result.get("messages") or []):
                    if isinstance(_m, dict) and _m.get("role") == "assistant":
                        _c = _m.get("content") or ""
                        if isinstance(_c, str) and _c.strip():
                            _ctx_chunks.append(_c[:1500])
                        if len(_ctx_chunks) >= 2:
                            break
            except Exception:  # noqa: BLE001 — broad-catch fallback
                _ctx_chunks = []
            _phase_excerpt = "\n---\n".join(reversed(_ctx_chunks))[:3500]

            # Stable summarizer: Gemini Flash is cheap, fast, never empty.
            # Falls back to the phase model if Gemini key unavailable.
            # ATH-227: same strict provider isolation as the main phase
            # dispatch — when the summarizer falls back to the phase model,
            # use the phase's own resolved api_base/api_key, never inherit
            # the run-level Anthropic Azure config.
            _summ_model = "gemini/gemini-2.5-flash" if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") else resolved_model
            if _summ_model.startswith("gemini/"):
                _summ_api_base = None
                _summ_api_key = None
            else:
                _summ_api_base = eff_api_base
                _summ_api_key = eff_api_key
            try:
                _hs_kwargs: dict = {
                    "model": _summ_model,
                    "messages": [
                        {
                            "role": "user",
                            "content": (
                                f"Agent {phase_role} just completed Phase {phase_num} of a "
                                f"{num_phases}-phase task. Below is an excerpt of what they "
                                f"produced. Write a 2-3 sentence handoff note (plain text, no "
                                f"markdown, max 500 chars) FOR THE NEXT AGENT — what was done, "
                                f"what to look at, what's still open. Speak as the agent (\"I\").\n\n"
                                f"--- PHASE EXCERPT ---\n{_phase_excerpt}\n--- END EXCERPT ---"
                            ),
                        }
                    ],
                    "max_tokens": 600,
                }
                if _summ_api_base:
                    _hs_kwargs["api_base"] = _summ_api_base
                if _summ_api_key:
                    _hs_kwargs["api_key"] = _summ_api_key
                _hs_resp = completion(**_hs_kwargs)
                _hs_text = (_hs_resp.choices[0].message.content or "").strip()
                # Hard-cap at 500 chars to match the prompt contract
                handoff_summary = _hs_text[:500]
            except Exception:  # noqa: BLE001 — broad-catch fallback
                pass  # Never block the pipeline on handoff summary failures

        # Patch the just-appended entries with the handoff_summary
        per_phase_traces[-1]["handoff_summary"] = handoff_summary
        phase_metrics[-1]["handoff_summary"] = handoff_summary

        if num_phases > 1:
            print(
                f"  Phase {phase_num} done: {phase_elapsed:.0f}s, "
                f"{phase_tc_count} tool calls, {phase_tokens:,} tokens, "
                f"est ${phase_cost_estimate:.4f}"
            )

        # If we hit a hard stop (time/tokens/cancel), don't start next phase
        if stop_reason:
            break

    # Total elapsed = wall time minus all API wait penalties across all phases.
    # For single-phase tasks this is identical to the original code.
    elapsed = max(0.0, (time.time() - start_time) - total_api_wait)
    tool_calls_log = all_tool_calls_log
    errors = all_errors
    messages = all_messages
    print(f"  Student finished in {elapsed:.0f}s ({len(tool_calls_log)} tool calls)" +
          (f" across {len(phase_metrics)} phase(s)" if num_phases > 1 else ""))

    # ---- Collect output files ----
    output_files = []
    for f in workdir.rglob("*"):
        if f.is_file() and f.relative_to(workdir).parts[0] != "shared":
            output_files.append(str(f.relative_to(workdir)))

    # ---- Scoring ----
    score = None
    scoring_metadata = {}
    infra_limitations = []
    scored_via = "none"

    image_name = env_dir.resolve().name.replace("_", "-").replace(" ", "-").lower()
    # ATH-105 customer-demo support: tasks can override which container
    # scoring runs in. E.g. fused_attention_softmax_verified uses
    # neuron-nki-kernels:solve (Mathlib-enabled) for scoring because the
    # proof imports Mathlib. Default envs leave this unset and use :latest.
    scoring_image_override = task.get("scoring_container_image")
    if scoring_image_override:
        image_name = scoring_image_override
    docker_bin = shutil.which("docker") or shutil.which("podman")
    docker_image_exists = _docker_image_exists(docker_bin, image_name) if docker_bin else False

    if docker_image_exists:
        print(f"  Scoring via container ({image_name})...")
        try:
            config_dir = env_dir / "root_data" / "eval" / "configs"
            first_config = None
            if config_dir.exists():
                configs = sorted(config_dir.glob("*.json"))
                for c in configs:
                    if (
                        _normalize_task_id(c.stem) == task["id"]
                    ):
                        first_config = f"/root_data/eval/configs/{c.name}"
                        break
                if not first_config and configs:
                    first_config = f"/root_data/eval/configs/{configs[0].name}"

            scoring_result = subprocess.run(
                [
                    docker_bin, "run", "--rm", "--user", "root",
                    *_GPU_FLAGS,
                    "--network=none", f"--memory={_SCORING_MEMORY}", "--pids-limit=256",
                    "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                    "-v", f"{data_dir}:/workdir/data",
                    "-v", f"{shared_dir}:/workdir/shared:ro",
                    image_name, "bash", "-c",
                    f"/root/.venv/bin/python /root_data/eval/scoring.py "
                    f"{first_config or '/dev/null'} /tmp/score.json >/dev/null 2>&1; "
                    f"cat /tmp/score.json 2>/dev/null || "
                    f'echo \'{{"score": 0.0, "metadata": {{"error": "scoring crashed"}}}}\'',
                ],
                capture_output=True, text=True, timeout=300,
            )
            if scoring_result.returncode == 0 and scoring_result.stdout.strip():
                data = json.loads(scoring_result.stdout.strip())
                score = data.get("score")
                scoring_metadata = data.get("metadata", {})
                scored_via = "docker"
                print(f"  Score: {score} (via container)")
            else:
                stderr = scoring_result.stderr[:200] if scoring_result.stderr else ""
                errors.append(f"Container scoring failed: {stderr}")
        except subprocess.TimeoutExpired:
            errors.append("Container scoring timed out (300s)")
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            errors.append(f"Container scoring error: {e}")

    elif docker_bin:
        print(f"  Container runtime found but image '{image_name}' not built.")
        print(f"  Build it with: cd {env_dir} && {docker_bin} build -f Containerfile -t {image_name} .")
        print("  Falling back to local scoring...")

    if scored_via == "none" and not os.environ.get("ALLOW_LOCAL_SCORING"):
        print("  WARNING: No container image found and local scoring is disabled.")
        print(f"  Build the image: cd {env_dir} && {docker_bin or 'docker'} build -f Containerfile -t {image_name} .")
        print("  Or set ALLOW_LOCAL_SCORING=1 to allow unsandboxed local scoring.")
        errors.append("Local scoring disabled (no container image, set ALLOW_LOCAL_SCORING=1 to override)")

    if scored_via == "none" and os.environ.get("ALLOW_LOCAL_SCORING"):
        print("  WARNING: Running scoring locally without container sandbox.")
        for tool_name in ["lean", "lake", "rustc", "cargo"]:
            if shutil.which(tool_name) is None:
                infra_limitations.append(
                    f"{tool_name} not installed (available in container)"
                )
        score_output = workdir / "score_output.json"
        try:
            dummy_config = workdir / "dummy_config.json"
            dummy_config.write_text("{}")
            scoring_result = subprocess.run(
                [
                    sys.executable,
                    str(scoring_path.resolve()),
                    str(dummy_config),
                    str(score_output),
                ],
                capture_output=True, text=True, timeout=300,
                env={**os.environ, "PATH": os.environ.get("PATH", "")},
            )
            if score_output.exists():
                data = json.loads(score_output.read_text())
                score = data.get("score")
                scoring_metadata = data.get("metadata", {})
                scored_via = "local"
                print(f"  Score: {score} (local)")
                if score == 0.0 and infra_limitations:
                    print("  Note: score=0 may be due to missing local tools")
                    print("  Build the container image for accurate scoring:")
                    print(f"    cd {env_dir} && docker build -f Containerfile -t {image_name} .")
            else:
                stderr = scoring_result.stderr[:200] if scoring_result.stderr else ""
                if any(
                    kw in stderr
                    for kw in ["not found", "No such file", "ModuleNotFoundError"]
                ):
                    infra_limitations.append(f"Scoring dependency missing: {stderr[:100]}")
                else:
                    errors.append(f"Scoring stderr: {stderr}")
        except subprocess.TimeoutExpired:
            errors.append("Scoring timed out (300s)")
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            errors.append(f"Scoring error: {e}")

    # ---- Build result dict ----
    strategy = ""
    for msg in messages:
        role = msg.get("role") if isinstance(msg, dict) else getattr(msg, "role", "")
        if role == "assistant":
            content = (
                msg.get("content", "")
                if isinstance(msg, dict)
                else getattr(msg, "content", "")
            )
            if isinstance(content, str) and content:
                strategy = content[:300]
                break

    # Flag if student never ran (API failure)
    api_failed = len(tool_calls_log) == 0 and any("API error" in e for e in errors)
    if api_failed:
        print(f"  AGENT FAILURE: {task['id']} - student made 0 tool calls (API error)")
        print(f"  Errors: {errors[0][:100]}")

    _emit_trace_event(live_run_id, task["id"], len(tool_calls_log) + 1, "status",
                      content=f"Task completed: {task['id']} — score={score}")

    # ATH-118: aggregate cost estimate across all phases (sum, since each
    # phase_trace already has its own cost_usd_estimate).
    total_cost_estimate = sum(pt.get("cost_usd_estimate", 0.0) for pt in per_phase_traces)

    result = {
        "status": "PASS" if score is not None else ("API_FAIL" if api_failed else "WARN"),
        "task": task["id"],
        "score": score,
        "scoring_metadata": scoring_metadata,
        "student_strategy": strategy,
        "tool_calls_summary": tool_calls_log[:3] + tool_calls_log[-3:]
        if len(tool_calls_log) > 6
        else tool_calls_log,
        "tool_calls_total": len(tool_calls_log),
        "output_files": output_files[:20],
        "errors": errors,
        "stop_reason": stop_reason,
        "infra_limitations": infra_limitations,
        "time_seconds": round(elapsed, 1),
        "total_tokens": total_tokens_used,
        "prompt_tokens": total_prompt_tokens,
        "completion_tokens": total_completion_tokens,
        "cache_creation_tokens": cache_creation_tokens,
        "cache_read_tokens": cache_read_tokens,
        "cost_usd_estimate": total_cost_estimate,
    }

    # Include per-phase metrics when running multi-phase tasks
    if num_phases > 1:
        result["phase_metrics"] = phase_metrics
        # ATH-118: per-phase full trace for multi-agent UI (builder / verifier
        # each get their own agent_traces row on upload; see
        # sync_results_to_platform).
        result["per_phase_traces"] = per_phase_traces

    # ---- Capture student output file contents (before workdir cleanup) ----
    # Bug 7a fix (2026-04-11): previously filtered `.lean/.py/.txt/.json/.dfy`
    # which dropped every `.rs`/`.go`/`.toml`/`.c`/`.cedar`/`.v` source file
    # and incorrectly captured cargo build artifacts (`target/.rustc_info.json`,
    # `target/release/.fingerprint/*.json`) as "student files" — the exact bug
    # the user reported: "Agent Trace shows only the files touched, not what
    # it actually wrote into those files" on run 03750aec-... task vec_add.
    # Fix: denylist build-output directories, allowlist broader source
    # extensions, preserve the 50 KB cap.
    STUDENT_FILES_BUILD_DIRS = {
        "target", "node_modules", "__pycache__", ".pytest_cache",
        "build", "dist", ".git", ".cache", ".mypy_cache", ".ruff_cache",
    }
    STUDENT_FILES_SOURCE_EXTS = {
        # Rust / c-to-rust
        ".rs", ".toml",
        # Go / distributed-consensus
        ".go", ".mod", ".sum",
        # C / C++ / csparse helpers
        ".c", ".cpp", ".h", ".hpp", ".cc", ".cxx",
        # Python / all envs
        ".py", ".pyi",
        # Lean 4 / lean-theorem-proving + biology + neuron
        ".lean",
        # Dafny / distributed-consensus + congestion-control
        ".dfy",
        # Cedar / cedar-policy-verification
        ".cedar", ".cedarschema",
        # Verilog / SystemVerilog / hw-cbmc
        ".v", ".sv", ".vh", ".svh",
        # Scripts / config
        ".sh", ".yaml", ".yml", ".json", ".txt", ".md",
    }
    student_files = {}
    try:
        for f in workdir.rglob("*"):
            if not f.is_file():
                continue
            rel_parts = f.relative_to(workdir).parts
            if not rel_parts or rel_parts[0] == "shared":
                continue
            # Skip build outputs / caches — these are artifacts, not source
            if any(p in STUDENT_FILES_BUILD_DIRS for p in rel_parts):
                continue
            if f.suffix not in STUDENT_FILES_SOURCE_EXTS:
                continue
            if f.stat().st_size >= 50_000:
                continue
            try:
                student_files[str(f.relative_to(workdir))] = f.read_text(errors="replace")
            except Exception:  # noqa: BLE001 — individual file read into student_files; skip unreadable
                pass
    except Exception:  # noqa: BLE001 — outer wrapper; container scan may fail entirely on broken workdir
        pass

    # Include student files in result for platform sync
    if student_files:
        result["student_files"] = student_files

    # ---- Dump full conversation trace ----
    if len(tool_calls_log) > 0:
        trace_dir = env_dir / "agent_traces"
        trace_dir.mkdir(exist_ok=True)
        ts = time.strftime("%Y%m%d_%H%M%S")
        safe_model = model.replace("/", "-")
        trace_file = trace_dir / f"{safe_model}_{task['id']}_{ts}.json"
        try:
            trace_data = {
                "model": model,
                "task_id": task["id"],
                "timestamp": ts,
                "score": score,
                "total_tokens": total_tokens_used,
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "cost_usd_estimate": total_cost_estimate,
                "errors": errors,
                "messages": messages,
                "student_files": student_files,
            }
            if num_phases > 1:
                trace_data["phase_metrics"] = phase_metrics
                trace_data["per_phase_traces"] = per_phase_traces
            # ATH-236: two-stage redaction. First walk the dict and scrub
            # every string leaf (defense in depth for nested structures),
            # then re.sub-over the final serialized JSON blob so CodeQL's
            # clear-text-storage query recognizes the explicit sanitizer
            # barrier right before write_text.
            _trace_json = json.dumps(
                _redact_trace_secrets(_sanitize_nan(trace_data)), indent=2, default=str
            )
            for _pat in _SECRET_PATTERNS:
                _trace_json = _pat.sub("[REDACTED]", _trace_json)
            trace_file.write_text(_trace_json)
        except Exception:  # noqa: BLE001 — broad-catch fallback
            pass  # Don't fail the run if trace dump fails

        # ATH-118: per-phase trace files for multi-agent UI. Founder directive
        # 2026-04-12: capture max granularity to local traces/ always; filter
        # at upload. Each phase becomes one JSON under traces/<env>/ that
        # sync_results_to_platform can POST separately with `phase: N`.
        if num_phases > 1 and per_phase_traces:
            per_phase_dir = env_dir / "traces" / safe_model
            per_phase_dir.mkdir(parents=True, exist_ok=True)
            for pt in per_phase_traces:
                pn = pt["phase"]
                pf = per_phase_dir / f"{task['id']}_phase{pn}_{ts}.json"
                try:
                    phase_trace_data = {
                        "model": pt["model"],
                        "task_id": task["id"],
                        "phase": pn,
                        "timestamp": ts,
                        "score": score,  # task-level; same across phases
                        "total_tokens": pt["total_tokens"],
                        "prompt_tokens": pt["prompt_tokens"],
                        "completion_tokens": pt["completion_tokens"],
                        "cache_creation_tokens": pt["cache_creation_tokens"],
                        "cache_read_tokens": pt["cache_read_tokens"],
                        "cost_usd_estimate": pt["cost_usd_estimate"],
                        "tool_calls_count": pt["tool_calls_count"],
                        "time_seconds": pt["time_seconds"],
                        "messages": pt["messages"],
                    }
                    # phase_metrics (aggregate) lives on the phase=1 trace so
                    # platform can render summary without reading all phases
                    if pn == 1:
                        phase_trace_data["phase_metrics"] = phase_metrics
                    # ATH-236: same two-stage redaction as the aggregate
                    # trace — dict walk then re.sub-over-JSON for the
                    # sanitizer barrier before write_text.
                    _phase_json = json.dumps(
                        _redact_trace_secrets(_sanitize_nan(phase_trace_data)),
                        indent=2, default=str,
                    )
                    for _pat in _SECRET_PATTERNS:
                        _phase_json = _pat.sub("[REDACTED]", _phase_json)
                    pf.write_text(_phase_json)
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    pass  # non-fatal — legacy trace file above still written

    try:
        shutil.rmtree(workdir)
    except PermissionError:
        # Container scoring may have written root-owned files
        _podman = shutil.which("podman")
        if _podman:
            subprocess.run([_podman, "unshare", "rm", "-rf", str(workdir)],
                           capture_output=True, timeout=10)
        else:
            shutil.rmtree(workdir, ignore_errors=True)
    return result


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Evaluate AI models on environment tasks using LiteLLM.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  python3 evaluate.py . --all-tasks --model gpt-4o --output run1.json
  python3 evaluate.py . --tasks task_a,task_b --model gemini/gemini-2.5-flash -o test.json
  python3 evaluate.py . --tasks task_a --model gpt-4o --patch run1.json
""",
    )
    parser.add_argument("env_dir", help="Path to the environment directory")
    parser.add_argument("--model", default="gpt-4o", help="LiteLLM model string (default: gpt-4o)")
    parser.add_argument("--output", "-o", help="Save results JSON to this path (default: <env_dir>/eval-results.json)")
    parser.add_argument("--all-tasks", action="store_true", help="Run all discovered tasks")
    parser.add_argument("--tasks", help="Comma-separated list of task IDs to run")
    parser.add_argument("--patch", help="Existing results JSON to patch (only replaces results for tasks being run)")
    parser.add_argument("--max-workers", type=int, default=5, help="Max concurrent tasks (default: 5)")
    parser.add_argument("--max-time", type=int, default=2400, help="Max seconds per task (default: 2400). Bumped from 1350 after v1 audit found mistral hitting 1334s on regex_derivative — 98%% of the old cap.")
    parser.add_argument("--run-id", help="Existing platform run ID (skips auto-creation, used by run-watcher)")
    args = parser.parse_args()

    env_dir = Path(args.env_dir).resolve()
    if not env_dir.exists():
        print(f"Error: {env_dir} does not exist")
        sys.exit(1)

    # Export env_dir so deeply-nested helpers (e.g. _run_no_tools_phase's
    # per-attempt snapshot writer) can reach traces/ without a thread-through.
    os.environ["EVAL_ENV_DIR"] = str(env_dir)

    # Ensure root_data is accessible (a crashed dryrun may have locked it)
    root_data = env_dir / "root_data"
    if root_data.exists() and not os.access(root_data, os.R_OK):
        print("Restoring root_data permissions (was locked by a crashed run)...")
        root_data.chmod(0o755)

    # Set up container sandbox for student bash commands
    global _SANDBOX_IMAGE
    image_name = env_dir.name.replace("_", "-").replace(" ", "-").lower()
    docker_bin = _SANDBOX_BIN
    docker_image_found = False

    if docker_bin:
        try:
            # docker_bin is _SANDBOX_BIN (constant), image_name is the
            # env-dir slug normalized to lowercase hyphenated alnum —
            # both internal-derived, no user-supplied taint.
            r = subprocess.run(
                [docker_bin, "image", "inspect", image_name],  # nosemgrep
                capture_output=True, timeout=5,
            )
            if r.returncode == 0:
                _SANDBOX_IMAGE = image_name
                docker_image_found = True
                print(f"Student bash sandbox: container ({image_name})")
            else:
                print("Student bash sandbox: host (no container image)")
        except Exception:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            print("Student bash sandbox: host (container check failed)")
    else:
        print("WARNING: No container runtime (docker/podman) found.")

    # ---- Pre-flight: block execution if scoring can't work ----
    if not docker_image_found and not os.environ.get("ALLOW_LOCAL_SCORING"):
        print(f"\n{'='*60}")
        print(f"ABORT: No container image '{image_name}' found.")
        print("Scoring requires the container. Without it, all scores will be 0.0")
        print("and API tokens will be wasted on agent runs that can't be scored.")
        print("")
        print("Build the image first:")
        print(f"  cd {env_dir} && {docker_bin or 'docker'} build -f Containerfile -t {image_name} .")
        print("")
        print("Or set ALLOW_LOCAL_SCORING=1 to override (NOT recommended).")
        print(f"{'='*60}")
        sys.exit(1)

    tasks = find_tasks(env_dir)
    if not tasks:
        print(f"Error: No tasks found in {env_dir}")
        print(f"Check: ls {env_dir}/root_data/eval/configs/ or {env_dir}/src/environment/tasks/")
        sys.exit(1)

    if args.tasks:
        filter_ids = {_normalize_task_id(t.strip()) for t in args.tasks.split(",")}
        tasks_to_run = [t for t in tasks if t["id"] in filter_ids]
        missing = filter_ids - {t["id"] for t in tasks_to_run}
        if missing:
            print(f"Warning: task IDs not found: {missing}")
    elif args.all_tasks:
        tasks_to_run = tasks
    else:
        tasks_to_run = tasks[:1]

    # requires_gpu filter: discovery (find_tasks) returns ALL tasks so that
    # static validators see the full 1:1 task/config alignment, but at the
    # execution site we skip GPU tasks on CPU hosts so customers + the Azure
    # VM never attempt them. Gated on ATHANOR_GPU=1 (opt-in from .bashrc).
    if not _GPU_SANDBOX:
        skipped_gpu_ids = []
        kept = []
        _cfg_dir = env_dir / "root_data" / "eval" / "configs"
        for t in tasks_to_run:
            cfg_path = _cfg_dir / f"{t['id']}.json"
            requires_gpu = False
            if cfg_path.exists():
                try:
                    requires_gpu = json.loads(cfg_path.read_text()).get("requires_gpu", False)
                except Exception:  # noqa: BLE001 — task cfg parse for requires_gpu; missing/malformed → assume False
                    pass
            if requires_gpu:
                skipped_gpu_ids.append(t["id"])
            else:
                kept.append(t)
        if skipped_gpu_ids:
            print(
                f"Skipping {len(skipped_gpu_ids)} GPU task(s) (set ATHANOR_GPU=1 to enable): "
                f"{', '.join(skipped_gpu_ids)}"
            )
        tasks_to_run = kept

    # Normalize model name to lowercase to prevent DB duplicates (e.g. Mistral-large-3 vs mistral-large-3)
    args.model = args.model.lower()

    if not tasks_to_run:
        print("Error: No matching tasks to run")
        sys.exit(1)

    print(f"Evaluating: {env_dir.name}")
    print(f"Model: {args.model}")
    print(f"Tasks: {len(tasks_to_run)}")
    print()

    all_results = {"model": args.model, "results": []}
    output_path = args.output or str(env_dir / "eval-results.json")
    patch_source = args.patch or (output_path if args.tasks else None)

    # ---- Resolve run ID for live trace events ----
    live_run_id = getattr(args, 'run_id', None)
    auth = _platform_auth_header()
    env_slug = env_dir.name.replace("_", "-")

    if live_run_id:
        # Run ID provided by platform (run-watcher) — just emit start trace
        print(f"Platform run: {live_run_id}")
        _emit_trace_event(live_run_id, "", 0, "status",
                          content=f"Run started: {args.model} on {len(tasks_to_run)} tasks")
    elif _TRACE_URL and _TRACE_KEY:
        # Direct Supabase — preferred when service key is available
        try:
            import urllib.request
            env_resp = json.loads(urllib.request.urlopen(urllib.request.Request(
                f"{_TRACE_URL}/rest/v1/environments?select=id,organization_id&slug=eq.{env_slug}&status=eq.active&limit=1",
                headers={"apikey": _TRACE_KEY, "Authorization": f"Bearer {_TRACE_KEY}"},
            )).read())
            if env_resp:
                run_data = json.dumps({
                    "organization_id": env_resp[0]["organization_id"],
                    "environment_id": env_resp[0]["id"],
                    "model_name": args.model, "status": "running",
                    "started_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
                    "total_tasks": len(tasks_to_run), "completed_tasks": 0,
                    "config": {"source": "cli", "source_file": os.path.basename(output_path)},
                }).encode()
                resp = json.loads(urllib.request.urlopen(urllib.request.Request(
                    f"{_TRACE_URL}/rest/v1/runs",
                    data=run_data,
                    headers={"apikey": _TRACE_KEY, "Authorization": f"Bearer {_TRACE_KEY}",
                             "Content-Type": "application/json", "Prefer": "return=representation"},
                    method="POST",
                )).read())
                if isinstance(resp, list) and resp:
                    live_run_id = resp[0]["id"]
                elif isinstance(resp, dict):
                    live_run_id = resp.get("id")
                if live_run_id:
                    print(f"Platform run (direct): {live_run_id}")
                    _emit_trace_event(live_run_id, "", 0, "status",
                                      content=f"Run started: {args.model} on {len(tasks_to_run)} tasks")
        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
            print(f"  (Direct run creation failed: {e} — continuing without live traces)")
    elif auth and _PLATFORM_URL:
        # Fallback: CLI mode with sync token — create run via /api/sync (enterprise customers)
        try:
            import urllib.request
            payload = json.dumps({
                "action": "create-run",
                "environment_slug": env_slug,
                "model": args.model,
                "total_tasks": len(tasks_to_run),
                "config": {"source": "cli", "source_file": os.path.basename(output_path)},
            }).encode()
            req = urllib.request.Request(
                f"{_PLATFORM_URL}/api/sync",
                data=payload,
                headers={"Authorization": auth, "Content-Type": "application/json"},
                method="POST",
            )
            resp = json.loads(urllib.request.urlopen(req, timeout=10).read())
            live_run_id = resp.get("run_id")
            if live_run_id:
                print(f"Platform run: {live_run_id}")
                _emit_trace_event(live_run_id, "", 0, "status",
                                  content=f"Run started: {args.model} on {len(tasks_to_run)} tasks")
        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
            print(f"  (Platform run creation failed: {e} — continuing without live traces)")

    _results_lock = __import__("threading").Lock()
    _completed_count = [0]  # mutable counter for thread-safe increment

    def _update_run_progress():
        """Patch the run's completed_tasks count in Supabase."""
        if not live_run_id or not _TRACE_URL or not _TRACE_KEY:
            return
        try:
            import urllib.request
            patch = json.dumps({"completed_tasks": _completed_count[0]}).encode()
            req = urllib.request.Request(
                f"{_TRACE_URL}/rest/v1/runs?id=eq.{live_run_id}",
                data=patch,
                headers={"apikey": _TRACE_KEY, "Authorization": f"Bearer {_TRACE_KEY}",
                         "Content-Type": "application/json", "Prefer": "return=minimal"},
                method="PATCH",
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:  # noqa: BLE001 — trace PATCH upload best-effort; never block eval
            pass

    def _save_incremental(result: dict) -> None:
        """Atomically patch/append a single task result to the output file.

        IMPORTANT: always writes the result, even when score is None. A None
        score gets normalized to 0.0 in the saved result so downstream
        consumers (canonical scoring_metadata schema v1, SDK Phase B parser,
        the sync_results_to_platform read-back below) never see None.

        Previously this method silently dropped results with score=None,
        which combined with the unconditional "Results saved" log + read-back
        at the end of main() to make scoring crashes look like infra crashes.
        See ~/.claude/.../memory/project_session_apr10_quality.md for the
        full incident write-up.
        """
        # Normalize: score MUST be a float, never None. The canonical schema
        # invariant is that every result row has score in [0.0, 1.0]. If a
        # scorer returned None (typically because scoring crashed before
        # writing the output file), we treat that as "no credit earned" and
        # save 0.0. The original failure info stays in result["errors"] and
        # result["status"].
        if result.get("score") is None:
            result = {**result, "score": 0.0}
            if not result.get("errors"):
                result["errors"] = ["score was None — scorer crashed or did not write output"]

        with _results_lock:
            if Path(output_path).exists():
                try:
                    existing = json.loads(Path(output_path).read_text())
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    existing = {"model": args.model, "results": []}
            elif patch_source and Path(patch_source).exists():
                try:
                    existing = json.loads(Path(patch_source).read_text())
                except Exception:  # noqa: BLE001 — broad-catch fallback
                    existing = {"model": args.model, "results": []}
            else:
                existing = {"model": args.model, "results": []}

            # Replace existing task or append new one. The "preserve real
            # score from being clobbered by failed retry" guard is preserved:
            # only replace an existing row if (a) the existing row had no
            # score, or (b) the new row actually made tool calls.
            replaced = False
            for i, r in enumerate(existing.get("results", [])):
                if r["task"] == result["task"]:
                    existing_zero = (r.get("score") is None or r.get("score") == 0.0)
                    new_has_tool_calls = result.get("tool_calls_total", 0) > 0
                    if existing_zero or new_has_tool_calls:
                        existing["results"][i] = result
                    replaced = True
                    break
            if not replaced:
                existing.setdefault("results", []).append(result)

            scores = [r.get("score") for r in existing["results"] if r.get("score") is not None]
            existing["summary"] = {
                "total": len(existing["results"]),
                "passed": sum(1 for r in existing["results"] if r.get("status") == "PASS"),
                "failed": sum(1 for r in existing["results"] if r.get("status") == "FAIL"),
                "skipped": sum(1 for r in existing["results"] if r.get("status") == "SKIP"),
                "avg_score": round(sum(scores) / len(scores), 4) if scores else 0,
            }
            Path(output_path).write_text(json.dumps(_sanitize_nan(existing), indent=2, default=str))

    def process_task(t, idx, total):
        print(f"--- Started Task {idx + 1}/{total}: {t['id']} ---")
        res = run_student_trial(env_dir, args.model, t, live_run_id=live_run_id, max_time=args.max_time)
        summary_lines = [f"--- Finished Task {idx + 1}/{total}: {t['id']} ---"]
        summary_lines.append(f"  Result: {res['status']}")
        if res.get("score") is not None:
            summary_lines.append(f"  Score: {res['score']}")
        if res.get("errors"):
            # ATH-236: redact any leaked api_key / bearer / JWT from error
            # strings before printing. Each error passes through the
            # scalar redactor so sk-ant-* / Bearer * / etc. never hit stdout.
            for e in res["errors"]:
                summary_lines.append(f"  Error: {_redact_secrets(str(e)) or ''}")
        if res.get("tool_calls_total"):
            summary_lines.append(f"  Tool calls: {res['tool_calls_total']}")
        if res.get("output_files"):
            summary_lines.append(f"  Output files: {len(res['output_files'])}")
        # ATH-236: final summary through _redact_secrets as a sanitizer
        # barrier — individual error strings were already redacted on
        # append above, but routing the joined output through .sub()
        # ensures CodeQL sees the explicit regex sanitizer before print.
        print(_redact_secrets("\n".join(summary_lines)))
        return res

    workers = max(1, min(args.max_workers, len(tasks_to_run)))
    print(f"Running with {workers} concurrent worker(s)...\n")

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [
            executor.submit(process_task, t, idx, len(tasks_to_run))
            for idx, t in enumerate(tasks_to_run)
        ]
        for future in concurrent.futures.as_completed(futures):
            try:
                res = future.result()
                all_results["results"].append(res)
                _save_incremental(res)
                with _results_lock:
                    _completed_count[0] += 1
                _update_run_progress()
            except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
                print(f"Task processing error: {e}")

    # ---- Summary table ----
    print("\n### Performance Summary")
    print("| Task | Status | Score | Time (s) | Tool Calls |")
    print("|---|---|---|---|---|")
    for res in all_results["results"]:
        score = res.get("score")
        score_str = f"{score:.4f}" if isinstance(score, float) else (str(score) if score is not None else "N/A")
        print(
            f"| {res.get('task', 'unknown')} | {res['status']} | {score_str} "
            f"| {res.get('time_seconds', 'N/A')} | {res.get('tool_calls_total', 'N/A')} |"
        )

    # ---- Safety check: abort if most tasks had API failures ----
    api_fails = sum(1 for r in all_results["results"] if r.get("status") == "API_FAIL")
    real_scores = sum(1 for r in all_results["results"] if r.get("score") is not None and r.get("tool_calls_total", 0) > 0)
    total = len(all_results["results"])
    if total > 0 and api_fails > total * 0.5:
        print(f"\n{'='*60}")
        print(f"ABORT: {api_fails}/{total} tasks had API failures (student never ran).")
        print(f"Only {real_scores} tasks have real scores.")
        print("Fix API keys/connectivity before re-running.")
        print("Output file NOT written to prevent data corruption.")
        print(f"{'='*60}")
        sys.exit(1)

    # Results are saved incrementally as each task completes (see _save_incremental).
    # Do a final safety write so the read-back below never crashes if every
    # task crashed before _save_incremental was called.
    if not Path(output_path).exists():
        empty_payload = {
            "model": args.model,
            "results": all_results.get("results", []),
            "summary": {
                "total": len(all_results.get("results", [])),
                "passed": 0, "failed": 0, "skipped": 0, "avg_score": 0,
            },
        }
        Path(output_path).write_text(json.dumps(_sanitize_nan(empty_payload), indent=2, default=str))
        print(f"\nResults saved to {output_path} (empty — every task crashed before incremental save)")
    else:
        print(f"\nResults saved to {output_path}")

    # ---- Mark platform run as completed ----
    if live_run_id:
        try:
            import urllib.request
            scores = [r.get("score") or 0 for r in all_results["results"] if r.get("score") is not None]
            mean_score = sum(scores) / len(scores) if scores else None

            if _TRACE_URL and _TRACE_KEY:
                patch = json.dumps(_sanitize_nan({
                    "status": "completed",
                    "completed_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
                    "completed_tasks": len(scores),
                    "mean_score": mean_score,
                })).encode()
                req = urllib.request.Request(
                    f"{_TRACE_URL}/rest/v1/runs?id=eq.{live_run_id}",
                    data=patch,
                    headers={"apikey": _TRACE_KEY, "Authorization": f"Bearer {_TRACE_KEY}",
                             "Content-Type": "application/json", "Prefer": "return=minimal"},
                    method="PATCH",
                )
                urllib.request.urlopen(req)
            elif auth and _PLATFORM_URL:
                payload = json.dumps(_sanitize_nan({
                    "action": "complete-run",
                    "run_id": live_run_id,
                    "completed_tasks": len(scores),
                    "mean_score": mean_score,
                })).encode()
                req = urllib.request.Request(
                    f"{_PLATFORM_URL}/api/sync",
                    data=payload,
                    headers={"Authorization": auth, "Content-Type": "application/json"},
                    method="POST",
                )
                urllib.request.urlopen(req, timeout=10)

            _emit_trace_event(live_run_id, "", 0, "status",
                              content=f"Run completed: mean={mean_score:.3f}" if mean_score else "Run completed")
            print(f"  Platform run {live_run_id[:8]}... marked completed")
        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
            print(f"  (Failed to update platform run: {e})")

    # ---- Sync to platform ----
    try:
        final_data = json.loads(Path(output_path).read_text())
    except (FileNotFoundError, json.JSONDecodeError) as e:
        # Defensive: with the score=None silent-drop fix the file should
        # always exist by this point, but if something else corrupts it
        # we want to fail gracefully rather than crash with a stack trace.
        print(f"  (Skipping platform sync — output file unreadable: {e})")
        return
    sync_results_to_platform(
        results_data=final_data,
        output_file=output_path,
        env_dir=env_dir,
    )

    # ---- Run-output contract test (warn-only) ----
    # ATH-149 / PR #26: validates the run + run_results + agent_traces +
    # storage_path invariants right after sync, so contract violations
    # surface at the source instead of weeks later (the ATH-105 failure
    # mode that needed manual mid-demo backfills). Warn-only on first
    # rollout; hard-fail upgrade gated on observed violation rate
    # (ATH-137). Set ATHANOR_RUN_CONTRACT_TEST=0 to disable.
    if live_run_id and getenv_dual("RUN_CONTRACT_TEST", "1") != "0":
        try:
            import subprocess as _sp2
            builder_root = Path(__file__).resolve().parents[2]
            test_path = builder_root / "tests" / "integration" / "test_run_output_contract.py"
            if test_path.is_file():
                res = _sp2.run(
                    ["python3", "-m", "pytest", str(test_path),
                     f"--run-id={live_run_id}", "-q", "--no-header"],
                    cwd=str(builder_root),
                    capture_output=True,
                    text=True,
                    timeout=60,
                )
                if res.returncode == 0:
                    print(f"  ✓ contract test passed for run {live_run_id[:8]}...")
                else:
                    print(f"  ⚠ contract test WARNINGS for run {live_run_id[:8]}... "
                          f"(set ATHANOR_RUN_CONTRACT_TEST=0 to disable):")
                    for line in (res.stdout or "").splitlines():
                        if line.startswith("  [") or "VIOL" in line:
                            print(f"    {line}")
        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
            print(f"  (contract test skipped: {e})")


# ------------------------------------------------------------------
# Platform sync (post-run hook)
# ------------------------------------------------------------------

def sync_results_to_platform(results_data: dict, output_file: str, env_dir: Path) -> None:
    """POST run results to the Athanor platform for dashboard visibility."""
    import subprocess as _sp
    from kairos.config import is_local_mode

    # ATH-388: local-only mode — skip every platform call. Artifacts stay
    # under ~/.athanor/runs/; customer decides whether to upload them later.
    if is_local_mode():
        print("  (Skipping platform sync — ATHANOR_MODE=local)")
        return

    platform_url = getenv_dual("PLATFORM_URL", "https://tahoe.athanor-ai.com")
    sync_secret = os.environ.get("CRON_SECRET", "")

    if not sync_secret:
        print("  (Skipping platform sync — CRON_SECRET not set)")
        return

    try:
        # Collect traces from agent_traces/ dir matching this run.
        # Model names can differ between run file and trace file (e.g.
        # anthropic/claude-sonnet-4-6 vs azure_ai/claude-sonnet-4-6,
        # kimi-k2.5 vs openai/kimi-k2.5, Mistral vs mistral).
        # Try multiple name variants to find traces.
        traces = []
        trace_dir = env_dir / "agent_traces"
        if trace_dir.exists():
            raw_model = results_data.get("model", "")
            safe_model = raw_model.replace("/", "-")
            # Build model name variants for glob matching
            model_base = raw_model.split("/")[-1] if "/" in raw_model else raw_model
            model_variants = {safe_model, model_base}
            for prefix in ("anthropic", "azure_ai", "openai", "gemini"):
                model_variants.add(f"{prefix}-{model_base}")
            # Also try case variants
            model_variants |= {v.lower() for v in model_variants}
            model_variants |= {v[0].upper() + v[1:] if v else v for v in model_variants}
            model_variants.discard("")

            for r in results_data.get("results", []):
                task_id = r.get("task", "")
                candidates = []
                for variant in model_variants:
                    candidates.extend(trace_dir.glob(f"{variant}_{task_id}_*.json"))
                candidates.sort(key=lambda p: p.name, reverse=True)
                if candidates:
                    try:
                        td = json.loads(candidates[0].read_text())

                        # ATH-118: per-phase trace emission for multi-agent UI.
                        # If this run was multi-phase, we split the task into
                        # one trace entry per phase — each with its own
                        # messages[], token split, and cost_usd_estimate —
                        # instead of the legacy single-entry-per-task shape.
                        # Platform's ingest-run handler (extended 2026-04-13)
                        # writes one agent_traces row per entry with agent_traces.phase
                        # populated. Single-phase tasks omit the phase field
                        # so legacy read paths are unaffected.
                        per_phase = td.get("per_phase_traces") or []
                        if per_phase:
                            for pt in per_phase:
                                traces.append({
                                    "task_id": task_id,
                                    "phase": pt.get("phase"),
                                    "messages": pt.get("messages", []),
                                    "score": td.get("score"),
                                    "token_count": pt.get("total_tokens"),
                                    "prompt_tokens": pt.get("prompt_tokens"),
                                    "completion_tokens": pt.get("completion_tokens"),
                                    "cache_creation_tokens": pt.get("cache_creation_tokens"),
                                    "cache_read_tokens": pt.get("cache_read_tokens"),
                                    "cost_usd_estimate": pt.get("cost_usd_estimate"),
                                    "model": pt.get("model"),
                                    # v2: handoff_summary for multi-agent chat UI
                                    # (NULL for single-phase / legacy rows without key)
                                    "handoff_summary": pt.get("handoff_summary") or None,
                                    # phase_metrics only on phase=1 per
                                    # platform's read contract
                                    "phase_metrics": td.get("phase_metrics")
                                        if pt.get("phase") == 1 else None,
                                })
                        else:
                            trace_entry = {
                                "task_id": task_id,
                                "messages": td.get("messages", []),
                                "score": td.get("score"),
                                "token_count": td.get("total_tokens"),
                                "cost_usd_estimate": td.get("cost_usd_estimate"),
                            }
                            # Include phase_metrics for multi-agent tasks so the
                            # platform timeline UI (ATH-91) can render phase
                            # boundaries. Absent for single-agent tasks — the
                            # platform falls through to LiveTracePanel unchanged.
                            pm = td.get("phase_metrics")
                            if pm:
                                trace_entry["phase_metrics"] = pm
                            traces.append(trace_entry)
                    except Exception:  # noqa: BLE001 — phase_metrics row parse; skip malformed row
                        pass

        # Infer model from filename if not in data (older run files lack model field)
        model_name = results_data.get("model") or ""
        if not model_name or model_name == "unknown":
            # e.g. "claude-sonnet-4-6_run1.json" -> "claude-sonnet-4-6"
            base = os.path.basename(output_file).rsplit("_run", 1)[0]
            _MODEL_PREFIXES = {
                "claude-": "anthropic/", "gemini-": "gemini/",
                "kimi-": "openai/", "mistral-": "openai/", "gpt-": "openai/",
            }
            for pat, pfx in _MODEL_PREFIXES.items():
                if base.startswith(pat):
                    model_name = pfx + base
                    break
            else:
                model_name = base or "unknown"

        payload = json.dumps(_sanitize_nan({
            "action": "ingest-run",
            "model": model_name,
            # Resolve first — Path(".").name is empty string, which trips
            # the platform's "Unknown environment_dir" check. Resolve
            # gives the real dir name regardless of how the env was passed.
            "environment_dir": env_dir.resolve().name,
            "results": results_data.get("results", []),
            "source_file": os.path.basename(output_file),
            "traces": traces if traces else None,
        }))

        # Use curl instead of urllib to avoid redirect/auth-header issues
        result = _sp.run(
            [
                "curl", "-s", "-w", "%{http_code}",
                "-X", "POST", f"{platform_url}/api/sync",
                "-H", f"Authorization: Bearer {sync_secret}",
                "-H", "Content-Type: application/json",
                "--data-binary", "@-",
                "--max-time", "180",
            ],
            input=payload,
            capture_output=True, text=True, timeout=185,
        )
        http_code = result.stdout.strip()[-3:] if result.stdout else "???"
        if http_code == "200":
            print(f"  Synced to platform: {http_code}")
        else:
            print(f"  (Platform sync returned HTTP {http_code} — results still saved locally)")
            # ATH-133: on 413 (payload too large) or 5xx, fall through to direct
            # Storage + REST insert so trace data survives. Without this path,
            # a 70 MB multi-agent run silently loses traces platform-side.
            if http_code == "413" or (len(http_code) == 3 and http_code[0] == "5"):
                _attempt_fallback_trace_upload(
                    traces=traces,
                    env_dir=env_dir,
                    model_name=model_name,
                    output_file=output_file,
                    trigger_http_code=http_code,
                )
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"  (Platform sync failed: {e} — results still saved locally)")


def _load_ath133_fallback_module():
    """Import shared/scripts/trace_uploader_fallback.py as a module.

    Split out so tests can monkeypatch the returned module without racing
    with Python's `import` cache. Returns None if the file is missing or
    cannot be loaded, in which case the caller logs and skips.
    """
    import importlib.util as _ilu
    spec_path = Path(__file__).resolve().parent / "trace_uploader_fallback.py"
    if not spec_path.exists():
        return None
    spec = _ilu.spec_from_file_location("_ath133_fallback", spec_path)
    if spec is None or spec.loader is None:
        return None
    mod = _ilu.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _attempt_fallback_trace_upload(
    traces: list,
    env_dir: "Path",
    model_name: str,
    output_file: str,
    trigger_http_code: str,
) -> None:
    """ATH-133: direct Supabase Storage + PostgREST insert for each trace entry
    when /api/sync rejects the payload with 413 or 5xx. Non-fatal; logs per-
    phase results. Runs once per sync attempt; never retries the sync POST.
    """
    import tempfile
    try:
        mod = _load_ath133_fallback_module()
    except Exception as e:  # noqa: BLE001
        print(f"  (ATH-133 fallback skipped: failed to import trace_uploader_fallback: {e})")
        return
    if mod is None:
        print("  (ATH-133 fallback skipped: trace_uploader_fallback.py not found next to evaluate.py)")
        return

    env_slug = env_dir.resolve().name
    env_id = mod.resolve_environment_id_by_slug(env_slug)
    if not env_id:
        print(
            f"  (ATH-133 fallback skipped: could not resolve environment_id for slug '{env_slug}' "
            f"— SUPABASE_SERVICE_ROLE_KEY or NEXT_PUBLIC_SUPABASE_URL missing, or slug not in environments table)"
        )
        return

    if not traces:
        print(f"  (ATH-133 fallback: no traces collected for upload, skipping; HTTP was {trigger_http_code})")
        return

    source_file = os.path.basename(output_file)
    ok = 0
    failed = 0
    print(f"  (ATH-133 fallback: HTTP {trigger_http_code} triggered direct Storage upload for {len(traces)} trace entries)")

    for trace in traces:
        phase = trace.get("phase") or 1
        task_id = trace.get("task_id")
        per_phase_model = trace.get("model") or model_name
        handoff_summary = trace.get("handoff_summary")

        # phase_metrics: prefer the trace's own (phase=1 carries it), else
        # synthesize from token / cost fields so the row has something.
        phase_metrics = trace.get("phase_metrics") or {
            "total_tokens": trace.get("token_count"),
            "prompt_tokens": trace.get("prompt_tokens"),
            "completion_tokens": trace.get("completion_tokens"),
            "cache_creation_tokens": trace.get("cache_creation_tokens"),
            "cache_read_tokens": trace.get("cache_read_tokens"),
            "cost_usd_estimate": trace.get("cost_usd_estimate"),
        }

        # Fallback expects a local JSON file; dump the in-memory trace to temp.
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", prefix=f"ath133-{task_id or 'unknown'}-phase{phase}-",
            delete=False, encoding="utf-8",
        ) as tf:
            json.dump(trace, tf)
            tmp_path = Path(tf.name)

        try:
            result = mod.upload_phase_trace_fallback(
                env_name=env_slug,
                source_file=source_file,
                task_id=task_id,
                run_id=None,
                environment_id=env_id,
                phase=phase,
                model=per_phase_model,
                per_phase_trace_json_path=tmp_path,
                phase_metrics=phase_metrics,
                handoff_summary=handoff_summary,
            )
            if result.get("success"):
                ok += 1
                print(f"    ↳ phase {phase} task={task_id or '?'} uploaded: {result.get('storage_path')}")
            else:
                failed += 1
                print(f"    ↳ phase {phase} task={task_id or '?'} FAILED: {result.get('error')}")
        except Exception as e:  # noqa: BLE001
            failed += 1
            print(f"    ↳ phase {phase} task={task_id or '?'} EXCEPTION: {e}")
        finally:
            try:
                tmp_path.unlink()
            except OSError:
                pass

    print(f"  (ATH-133 fallback summary: {ok} uploaded, {failed} failed)")


if __name__ == "__main__":
    main()
