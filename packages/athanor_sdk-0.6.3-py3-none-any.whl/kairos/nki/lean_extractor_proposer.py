"""Production proposer adapter for kairos.nki.lean_extractor.

Wires the abstract ``llm_proposer`` callable that
:func:`kairos.nki.lean_extractor.extract_from_nki` accepts to a real
:func:`kairos.model_client.get_client` model. Lifted into a separate
module so the extractor itself stays test-friendly (no API-key
requirement at import time) and so callers building their own LLM
plumbing (rate limiters, custom retry, cost tracking) can compose with
the underlying ``ModelClient`` directly without going through this
adapter.
"""
from __future__ import annotations

import logging
from typing import Callable, Tuple

from kairos.model_client import get_client
from kairos.model_presets import ESCALATION_OPUS
from kairos.nki.lean_extractor import _extract_blocks


_logger = logging.getLogger(__name__)


def make_anthropic_proposer(
    *,
    model_id: str = ESCALATION_OPUS,
    max_tokens: int = 8_192,
    temperature: float | None = None,
    timeout: int = 300,
) -> Callable[[str, str], Tuple[str | None, str | None, str | None]]:
    """Build a proposer callable bound to an Anthropic-side client.

    Returns a function with the signature
    :class:`extract_from_nki`'s ``llm_proposer`` expects:
    ``(system_prompt, user_prompt) -> (lean_src, python_src, error)``.
    On a transient error the function returns
    ``(None, None, error_msg)`` rather than raising; the iteration
    loop's malformed-response feedback path handles that case.

    Args:
        model_id: passed to :func:`kairos.model_client.get_client`.
            Defaults to opus-4-7 since spec extraction is an
            intelligence-bound task per the SV-side experience.
        max_tokens: per-call output budget. Default 8K leaves headroom
            for moderately complex specs (the SV-side default is
            16K but NKI specs are smaller surface).
        temperature: passed through to the provider; ``None`` uses
            the model default.
        timeout: per-call wall-clock cap.
    """
    client = get_client(model_id)

    def _proposer(
        system_prompt: str, user_prompt: str
    ) -> Tuple[str | None, str | None, str | None]:
        try:
            messages = client.format_messages(system_prompt, user_prompt)
            response = client.call(
                messages,
                max_tokens=max_tokens,
                timeout=timeout,
                temperature=temperature,
            )
        except Exception as exc:  # noqa: BLE001 — provider surfaces vary
            _logger.warning("nki proposer raised: %s", exc)
            return None, None, f"{type(exc).__name__}: {exc}"

        if response.error:
            return None, None, f"LLM transient error: {response.error}"
        if not response.content:
            return None, None, "LLM returned empty content"

        lean_src, python_src = _extract_blocks(response.content)
        if lean_src is None:
            return None, None, "LLM response missing ```lean block"
        if python_src is None:
            return lean_src, None, "LLM response missing ```python block"
        return lean_src, python_src, None

    return _proposer


__all__ = ["make_anthropic_proposer"]
